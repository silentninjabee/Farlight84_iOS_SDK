#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct ActorSequence.ActorSequenceObjectReferenceMap
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FActorSequenceObjectReferenceMap {
	// Fields
	struct TArray<struct FGuid> BindingIds; // Offset: 0x0 | Size: 0x10
	struct TArray<struct FActorSequenceObjectReferences> References; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct ActorSequence.ActorSequenceObjectReferences
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FActorSequenceObjectReferences {
	// Fields
	struct TArray<struct FActorSequenceObjectReference> Array; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct ActorSequence.ActorSequenceObjectReference
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FActorSequenceObjectReference {
	// Fields
	enum class EActorSequenceObjectReferenceType Type; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	struct FGuid ActorId; // Offset: 0x4 | Size: 0x10
	char pad_0x14[0x4]; // Offset: 0x14 | Size: 0x4
	struct FString PathToComponent; // Offset: 0x18 | Size: 0x10
};

