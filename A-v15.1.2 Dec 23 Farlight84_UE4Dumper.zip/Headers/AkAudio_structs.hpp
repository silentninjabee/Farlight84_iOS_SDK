#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct AkAudio.AKWaapiJsonObject
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FAKWaapiJsonObject {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct AkAudio.AkWaapiSubscriptionId
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FAkWaapiSubscriptionId {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
};

// Object: ScriptStruct AkAudio.AkAdvancedInitializationSettings
// Inherited Bytes: 0x0 | Struct Size: 0x2c
struct FAkAdvancedInitializationSettings {
	// Fields
	uint32_t IO_MemorySize; // Offset: 0x0 | Size: 0x4
	uint32_t IO_Granularity; // Offset: 0x4 | Size: 0x4
	float TargetAutoStreamBufferLength; // Offset: 0x8 | Size: 0x4
	bool UseStreamCache; // Offset: 0xc | Size: 0x1
	char pad_0xD[0x3]; // Offset: 0xd | Size: 0x3
	uint32_t MaximumPinnedBytesInCache; // Offset: 0x10 | Size: 0x4
	bool EnableGameSyncPreparation; // Offset: 0x14 | Size: 0x1
	char pad_0x15[0x3]; // Offset: 0x15 | Size: 0x3
	uint32_t ContinuousPlaybackLookAhead; // Offset: 0x18 | Size: 0x4
	uint32_t MonitorQueuePoolSize; // Offset: 0x1c | Size: 0x4
	uint32_t MaximumHardwareTimeoutMs; // Offset: 0x20 | Size: 0x4
	bool DebugOutOfRangeCheckEnabled; // Offset: 0x24 | Size: 0x1
	char pad_0x25[0x3]; // Offset: 0x25 | Size: 0x3
	float DebugOutOfRangeLimit; // Offset: 0x28 | Size: 0x4
};

// Object: ScriptStruct AkAudio.AkAdvancedInitializationSettingsWithMultiCoreRendering
// Inherited Bytes: 0x2c | Struct Size: 0x30
struct FAkAdvancedInitializationSettingsWithMultiCoreRendering : FAkAdvancedInitializationSettings {
	// Fields
	bool EnableMultiCoreRendering; // Offset: 0x2c | Size: 0x1
	char pad_0x2D[0x3]; // Offset: 0x2d | Size: 0x3
};

// Object: ScriptStruct AkAudio.AkAndroidAdvancedInitializationSettings
// Inherited Bytes: 0x30 | Struct Size: 0x38
struct FAkAndroidAdvancedInitializationSettings : FAkAdvancedInitializationSettingsWithMultiCoreRendering {
	// Fields
	uint32_t AudioAPI; // Offset: 0x30 | Size: 0x4
	bool RoundFrameSizeToHardwareSize; // Offset: 0x34 | Size: 0x1
	char pad_0x35[0x3]; // Offset: 0x35 | Size: 0x3
};

// Object: ScriptStruct AkAudio.AkAudioSession
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FAkAudioSession {
	// Fields
	enum class EAkAudioSessionCategory AudioSessionCategory; // Offset: 0x0 | Size: 0x4
	uint32_t AudioSessionCategoryOptions; // Offset: 0x4 | Size: 0x4
	enum class EAkAudioSessionMode AudioSessionMode; // Offset: 0x8 | Size: 0x4
};

// Object: ScriptStruct AkAudio.AkExternalSourceInfo
// Inherited Bytes: 0x0 | Struct Size: 0x38
struct FAkExternalSourceInfo {
	// Fields
	struct FString ExternalSrcName; // Offset: 0x0 | Size: 0x10
	enum class AkCodecId CodecID; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x7]; // Offset: 0x11 | Size: 0x7
	struct FString Filename; // Offset: 0x18 | Size: 0x10
	struct UAkExternalMediaAsset* ExternalSourceAsset; // Offset: 0x28 | Size: 0x8
	bool IsStreamed; // Offset: 0x30 | Size: 0x1
	char pad_0x31[0x7]; // Offset: 0x31 | Size: 0x7
};

// Object: ScriptStruct AkAudio.AkSegmentInfo
// Inherited Bytes: 0x0 | Struct Size: 0x24
struct FAkSegmentInfo {
	// Fields
	int32_t CurrentPosition; // Offset: 0x0 | Size: 0x4
	int32_t PreEntryDuration; // Offset: 0x4 | Size: 0x4
	int32_t ActiveDuration; // Offset: 0x8 | Size: 0x4
	int32_t PostExitDuration; // Offset: 0xc | Size: 0x4
	int32_t RemainingLookAheadTime; // Offset: 0x10 | Size: 0x4
	float BeatDuration; // Offset: 0x14 | Size: 0x4
	float BarDuration; // Offset: 0x18 | Size: 0x4
	float GridDuration; // Offset: 0x1c | Size: 0x4
	float GridOffset; // Offset: 0x20 | Size: 0x4
};

// Object: ScriptStruct AkAudio.AkMidiEventBase
// Inherited Bytes: 0x0 | Struct Size: 0x2
struct FAkMidiEventBase {
	// Fields
	enum class EAkMidiEventType Type; // Offset: 0x0 | Size: 0x1
	char Chan; // Offset: 0x1 | Size: 0x1
};

// Object: ScriptStruct AkAudio.AkMidiProgramChange
// Inherited Bytes: 0x2 | Struct Size: 0x3
struct FAkMidiProgramChange : FAkMidiEventBase {
	// Fields
	char ProgramNum; // Offset: 0x2 | Size: 0x1
};

// Object: ScriptStruct AkAudio.AkMidiChannelAftertouch
// Inherited Bytes: 0x2 | Struct Size: 0x3
struct FAkMidiChannelAftertouch : FAkMidiEventBase {
	// Fields
	char Value; // Offset: 0x2 | Size: 0x1
};

// Object: ScriptStruct AkAudio.AkMidiNoteAftertouch
// Inherited Bytes: 0x2 | Struct Size: 0x4
struct FAkMidiNoteAftertouch : FAkMidiEventBase {
	// Fields
	char Note; // Offset: 0x2 | Size: 0x1
	char Value; // Offset: 0x3 | Size: 0x1
};

// Object: ScriptStruct AkAudio.AkMidiPitchBend
// Inherited Bytes: 0x2 | Struct Size: 0x8
struct FAkMidiPitchBend : FAkMidiEventBase {
	// Fields
	char ValueLsb; // Offset: 0x2 | Size: 0x1
	char ValueMsb; // Offset: 0x3 | Size: 0x1
	int32_t FullValue; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct AkAudio.AkMidiCc
// Inherited Bytes: 0x2 | Struct Size: 0x4
struct FAkMidiCc : FAkMidiEventBase {
	// Fields
	enum class EAkMidiCcValues Cc; // Offset: 0x2 | Size: 0x1
	char Value; // Offset: 0x3 | Size: 0x1
};

// Object: ScriptStruct AkAudio.AkMidiNoteOnOff
// Inherited Bytes: 0x2 | Struct Size: 0x4
struct FAkMidiNoteOnOff : FAkMidiEventBase {
	// Fields
	char Note; // Offset: 0x2 | Size: 0x1
	char Velocity; // Offset: 0x3 | Size: 0x1
};

// Object: ScriptStruct AkAudio.AkMidiGeneric
// Inherited Bytes: 0x2 | Struct Size: 0x4
struct FAkMidiGeneric : FAkMidiEventBase {
	// Fields
	char Param1; // Offset: 0x2 | Size: 0x1
	char Param2; // Offset: 0x3 | Size: 0x1
};

// Object: ScriptStruct AkAudio.AkOutputSettings
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FAkOutputSettings {
	// Fields
	struct FString AudioDeviceSharesetName; // Offset: 0x0 | Size: 0x10
	int32_t IdDevice; // Offset: 0x10 | Size: 0x4
	enum class PanningRule PanRule; // Offset: 0x14 | Size: 0x1
	enum class AkChannelConfiguration ChannelConfig; // Offset: 0x15 | Size: 0x1
	char pad_0x16[0x2]; // Offset: 0x16 | Size: 0x2
};

// Object: ScriptStruct AkAudio.AkChannelMask
// Inherited Bytes: 0x0 | Struct Size: 0x4
struct FAkChannelMask {
	// Fields
	int32_t ChannelMask; // Offset: 0x0 | Size: 0x4
};

// Object: ScriptStruct AkAudio.AkGeometrySurfaceOverride
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FAkGeometrySurfaceOverride {
	// Fields
	struct UAkAcousticTexture* AcousticTexture; // Offset: 0x0 | Size: 0x8
	char bEnableOcclusionOverride : 1; // Offset: 0x8 | Size: 0x1
	char pad_0x8_1 : 7; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x3]; // Offset: 0x9 | Size: 0x3
	float OcclusionValue; // Offset: 0xc | Size: 0x4
	float SurfaceArea; // Offset: 0x10 | Size: 0x4
	char pad_0x14[0x4]; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct AkAudio.AkGeometryData
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FAkGeometryData {
	// Fields
	struct TArray<struct FVector> Vertices; // Offset: 0x0 | Size: 0x10
	struct TArray<struct FAkAcousticSurface> Surfaces; // Offset: 0x10 | Size: 0x10
	struct TArray<struct FAkTriangle> Triangles; // Offset: 0x20 | Size: 0x10
	struct TArray<struct UPhysicalMaterial*> ToOverrideAcousticTexture; // Offset: 0x30 | Size: 0x10
	struct TArray<struct UPhysicalMaterial*> ToOverrideOcclusion; // Offset: 0x40 | Size: 0x10
};

// Object: ScriptStruct AkAudio.AkTriangle
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FAkTriangle {
	// Fields
	uint16_t Point0; // Offset: 0x0 | Size: 0x2
	uint16_t Point1; // Offset: 0x2 | Size: 0x2
	uint16_t Point2; // Offset: 0x4 | Size: 0x2
	uint16_t Surface; // Offset: 0x6 | Size: 0x2
};

// Object: ScriptStruct AkAudio.AkAcousticSurface
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FAkAcousticSurface {
	// Fields
	uint32_t Texture; // Offset: 0x0 | Size: 0x4
	float Occlusion; // Offset: 0x4 | Size: 0x4
	struct FString Name; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct AkAudio.AkHololensAdvancedInitializationSettings
// Inherited Bytes: 0x30 | Struct Size: 0x30
struct FAkHololensAdvancedInitializationSettings : FAkAdvancedInitializationSettingsWithMultiCoreRendering {
	// Fields
	bool UseHeadMountedDisplayAudioDevice; // Offset: 0x2d | Size: 0x1
};

// Object: ScriptStruct AkAudio.AkPluginInfo
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FAkPluginInfo {
	// Fields
	struct FString Name; // Offset: 0x0 | Size: 0x10
	uint32_t PluginID; // Offset: 0x10 | Size: 0x4
	char pad_0x14[0x4]; // Offset: 0x14 | Size: 0x4
	struct FString DLL; // Offset: 0x18 | Size: 0x10
};

// Object: ScriptStruct AkAudio.AkCommonInitializationSettings
// Inherited Bytes: 0x0 | Struct Size: 0x60
struct FAkCommonInitializationSettings {
	// Fields
	uint32_t MaximumNumberOfMemoryPools; // Offset: 0x0 | Size: 0x4
	uint32_t MaximumNumberOfPositioningPaths; // Offset: 0x4 | Size: 0x4
	uint32_t CommandQueueSize; // Offset: 0x8 | Size: 0x4
	uint32_t SamplesPerFrame; // Offset: 0xc | Size: 0x4
	struct FAkMainOutputSettings MainOutputSettings; // Offset: 0x10 | Size: 0x28
	float StreamingLookAheadRatio; // Offset: 0x38 | Size: 0x4
	uint16_t NumberOfRefillsInVoice; // Offset: 0x3c | Size: 0x2
	char pad_0x3E[0x2]; // Offset: 0x3e | Size: 0x2
	struct FAkSpatialAudioSettings SpatialAudioSettings; // Offset: 0x40 | Size: 0x20
};

// Object: ScriptStruct AkAudio.AkSpatialAudioSettings
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FAkSpatialAudioSettings {
	// Fields
	uint32_t MaxSoundPropagationDepth; // Offset: 0x0 | Size: 0x4
	float MovementThreshold; // Offset: 0x4 | Size: 0x4
	uint32_t NumberOfPrimaryRays; // Offset: 0x8 | Size: 0x4
	uint32_t ReflectionOrder; // Offset: 0xc | Size: 0x4
	float MaximumPathLength; // Offset: 0x10 | Size: 0x4
	float CPULimitPercentage; // Offset: 0x14 | Size: 0x4
	bool EnableDiffractionOnReflections; // Offset: 0x18 | Size: 0x1
	bool EnableGeometricDiffractionAndTransmission; // Offset: 0x19 | Size: 0x1
	bool CalcEmitterVirtualPosition; // Offset: 0x1a | Size: 0x1
	bool UseObstruction; // Offset: 0x1b | Size: 0x1
	bool UseOcclusion; // Offset: 0x1c | Size: 0x1
	char pad_0x1D[0x3]; // Offset: 0x1d | Size: 0x3
};

// Object: ScriptStruct AkAudio.AkMainOutputSettings
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FAkMainOutputSettings {
	// Fields
	struct FString AudioDeviceShareset; // Offset: 0x0 | Size: 0x10
	uint32_t DeviceID; // Offset: 0x10 | Size: 0x4
	enum class EAkPanningRule PanningRule; // Offset: 0x14 | Size: 0x4
	enum class EAkChannelConfigType ChannelConfigType; // Offset: 0x18 | Size: 0x4
	uint32_t ChannelMask; // Offset: 0x1c | Size: 0x4
	uint32_t NumberOfChannels; // Offset: 0x20 | Size: 0x4
	char pad_0x24[0x4]; // Offset: 0x24 | Size: 0x4
};

// Object: ScriptStruct AkAudio.AkCommonInitializationSettingsWithSampleRate
// Inherited Bytes: 0x60 | Struct Size: 0x68
struct FAkCommonInitializationSettingsWithSampleRate : FAkCommonInitializationSettings {
	// Fields
	uint32_t SampleRate; // Offset: 0x60 | Size: 0x4
	char pad_0x64[0x4]; // Offset: 0x64 | Size: 0x4
};

// Object: ScriptStruct AkAudio.AkCommunicationSettings
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FAkCommunicationSettings {
	// Fields
	uint32_t PoolSize; // Offset: 0x0 | Size: 0x4
	uint16_t DiscoveryBroadcastPort; // Offset: 0x4 | Size: 0x2
	uint16_t CommandPort; // Offset: 0x6 | Size: 0x2
	uint16_t NotificationPort; // Offset: 0x8 | Size: 0x2
	char pad_0xA[0x6]; // Offset: 0xa | Size: 0x6
	struct FString NetworkName; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct AkAudio.AkCommunicationSettingsWithCommSelection
// Inherited Bytes: 0x20 | Struct Size: 0x28
struct FAkCommunicationSettingsWithCommSelection : FAkCommunicationSettings {
	// Fields
	enum class EAkCommSystem CommunicationSystem; // Offset: 0x20 | Size: 0x4
	char pad_0x24[0x4]; // Offset: 0x24 | Size: 0x4
};

// Object: ScriptStruct AkAudio.AkCommunicationSettingsWithSystemInitialization
// Inherited Bytes: 0x20 | Struct Size: 0x28
struct FAkCommunicationSettingsWithSystemInitialization : FAkCommunicationSettings {
	// Fields
	bool InitializeSystemComms; // Offset: 0x20 | Size: 0x1
	char pad_0x21[0x7]; // Offset: 0x21 | Size: 0x7
};

// Object: ScriptStruct AkAudio.AkBoolPropertyToControl
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FAkBoolPropertyToControl {
	// Fields
	struct FString ItemProperty; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct AkAudio.AkPropertyToControl
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FAkPropertyToControl {
	// Fields
	struct FString ItemProperty; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct AkAudio.AkPS4AdvancedInitializationSettings
// Inherited Bytes: 0x30 | Struct Size: 0x38
struct FAkPS4AdvancedInitializationSettings : FAkAdvancedInitializationSettingsWithMultiCoreRendering {
	// Fields
	uint32_t ACPBatchBufferSize; // Offset: 0x30 | Size: 0x4
	bool UseHardwareCodecLowLatencyMode; // Offset: 0x34 | Size: 0x1
	char pad_0x35[0x3]; // Offset: 0x35 | Size: 0x3
};

// Object: ScriptStruct AkAudio.AkReverbDescriptor
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FAkReverbDescriptor {
	// Fields
	char pad_0x0[0x28]; // Offset: 0x0 | Size: 0x28
};

// Object: ScriptStruct AkAudio.AkAcousticTextureParams
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FAkAcousticTextureParams {
	// Fields
	struct FVector4 AbsorptionValues; // Offset: 0x0 | Size: 0x10
	char pad_0x10[0x10]; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct AkAudio.AkGeometrySurfacePropertiesToMap
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FAkGeometrySurfacePropertiesToMap {
	// Fields
	struct TSoftObjectPtr<UAkAcousticTexture> AcousticTexture; // Offset: 0x0 | Size: 0x28
	float OcclusionValue; // Offset: 0x28 | Size: 0x4
	char pad_0x2C[0x4]; // Offset: 0x2c | Size: 0x4
};

// Object: ScriptStruct AkAudio.AkWwiseItemToControl
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FAkWwiseItemToControl {
	// Fields
	struct FAkWwiseObjectDetails ItemPicked; // Offset: 0x0 | Size: 0x30
	struct FString ItemPath; // Offset: 0x30 | Size: 0x10
};

// Object: ScriptStruct AkAudio.AkWwiseObjectDetails
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FAkWwiseObjectDetails {
	// Fields
	struct FString ItemName; // Offset: 0x0 | Size: 0x10
	struct FString ItemPath; // Offset: 0x10 | Size: 0x10
	struct FString ItemID; // Offset: 0x20 | Size: 0x10
};

// Object: ScriptStruct AkAudio.AkSurfaceProperties
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FAkSurfaceProperties {
	// Fields
	char pad_0x0[0x40]; // Offset: 0x0 | Size: 0x40
};

// Object: ScriptStruct AkAudio.AkEdgeInfo
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FAkEdgeInfo {
	// Fields
	char pad_0x0[0x28]; // Offset: 0x0 | Size: 0x28
};

// Object: ScriptStruct AkAudio.AkPoly
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FAkPoly {
	// Fields
	struct UAkAcousticTexture* Texture; // Offset: 0x0 | Size: 0x8
	float Occlusion; // Offset: 0x8 | Size: 0x4
	bool EnableSurface; // Offset: 0xc | Size: 0x1
	char pad_0xD[0x3]; // Offset: 0xd | Size: 0x3
	float SurfaceArea; // Offset: 0x10 | Size: 0x4
	char pad_0x14[0x4]; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct AkAudio.AkWaapiFieldNames
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FAkWaapiFieldNames {
	// Fields
	struct FString FieldName; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct AkAudio.AkWaapiUri
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FAkWaapiUri {
	// Fields
	struct FString Uri; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct AkAudio.AkWindowsAdvancedInitializationSettings
// Inherited Bytes: 0x30 | Struct Size: 0x34
struct FAkWindowsAdvancedInitializationSettings : FAkAdvancedInitializationSettingsWithMultiCoreRendering {
	// Fields
	bool UseHeadMountedDisplayAudioDevice; // Offset: 0x2d | Size: 0x1
	uint32_t MaxSystemAudioObjects; // Offset: 0x30 | Size: 0x4
};

// Object: ScriptStruct AkAudio.AkXboxOneApuHeapInitializationSettings
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FAkXboxOneApuHeapInitializationSettings {
	// Fields
	uint32_t CachedSize; // Offset: 0x0 | Size: 0x4
	uint32_t NonCachedSize; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct AkAudio.AkXboxOneAdvancedInitializationSettings
// Inherited Bytes: 0x30 | Struct Size: 0x34
struct FAkXboxOneAdvancedInitializationSettings : FAkAdvancedInitializationSettingsWithMultiCoreRendering {
	// Fields
	uint16_t MaximumNumberOfXMAVoices; // Offset: 0x2e | Size: 0x2
	bool UseHardwareCodecLowLatencyMode; // Offset: 0x30 | Size: 0x1
	char pad_0x33[0x1]; // Offset: 0x33 | Size: 0x1
};

// Object: ScriptStruct AkAudio.BankHandler
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FBankHandler {
	// Fields
	struct FString BankName; // Offset: 0x0 | Size: 0x10
	enum class EBankLoadStatus LoadStatus; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x3]; // Offset: 0x11 | Size: 0x3
	int32_t LoadCounter; // Offset: 0x14 | Size: 0x4
	int32_t CounterPendingIncrement; // Offset: 0x18 | Size: 0x4
	struct FDelegate LoadCallback; // Offset: 0x1c | Size: 0x10
	struct FDelegate UnloadCallback; // Offset: 0x2c | Size: 0x10
	char pad_0x3C[0x4]; // Offset: 0x3c | Size: 0x4
};

// Object: ScriptStruct AkAudio.EventCooldownData
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FEventCooldownData {
	// Fields
	struct TMap<struct FString, float> Data; // Offset: 0x0 | Size: 0x50
};

// Object: ScriptStruct AkAudio.CachedGameSyncData
// Inherited Bytes: 0x0 | Struct Size: 0xa0
struct FCachedGameSyncData {
	// Fields
	struct TMap<struct FString, float> RTPCData; // Offset: 0x0 | Size: 0x50
	struct TMap<struct FString, struct FString> SwitchData; // Offset: 0x50 | Size: 0x50
};

// Object: ScriptStruct AkAudio.AkAudioEventTrackKey
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FAkAudioEventTrackKey {
	// Fields
	float Time; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct UAkAudioEvent* AkAudioEvent; // Offset: 0x8 | Size: 0x8
	struct FString EventName; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct AkAudio.MovieSceneAkAudioEventTemplate
// Inherited Bytes: 0x18 | Struct Size: 0x20
struct FMovieSceneAkAudioEventTemplate : FMovieSceneEvalTemplate {
	// Fields
	struct UMovieSceneAkAudioEventSection* Section; // Offset: 0x18 | Size: 0x8
};

// Object: ScriptStruct AkAudio.MovieSceneAkAudioRTPCTemplate
// Inherited Bytes: 0x18 | Struct Size: 0x20
struct FMovieSceneAkAudioRTPCTemplate : FMovieSceneEvalTemplate {
	// Fields
	struct UMovieSceneAkAudioRTPCSection* Section; // Offset: 0x18 | Size: 0x8
};

// Object: ScriptStruct AkAudio.MovieSceneFloatChannelSerializationHelper
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FMovieSceneFloatChannelSerializationHelper {
	// Fields
	enum class ERichCurveExtrapolation PreInfinityExtrap; // Offset: 0x0 | Size: 0x1
	enum class ERichCurveExtrapolation PostInfinityExtrap; // Offset: 0x1 | Size: 0x1
	char pad_0x2[0x6]; // Offset: 0x2 | Size: 0x6
	struct TArray<int32_t> Times; // Offset: 0x8 | Size: 0x10
	struct TArray<struct FMovieSceneFloatValueSerializationHelper> Values; // Offset: 0x18 | Size: 0x10
	float DefaultValue; // Offset: 0x28 | Size: 0x4
	bool bHasDefaultValue; // Offset: 0x2c | Size: 0x1
	char pad_0x2D[0x3]; // Offset: 0x2d | Size: 0x3
};

// Object: ScriptStruct AkAudio.MovieSceneFloatValueSerializationHelper
// Inherited Bytes: 0x0 | Struct Size: 0x1c
struct FMovieSceneFloatValueSerializationHelper {
	// Fields
	float Value; // Offset: 0x0 | Size: 0x4
	enum class ERichCurveInterpMode InterpMode; // Offset: 0x4 | Size: 0x1
	enum class ERichCurveTangentMode TangentMode; // Offset: 0x5 | Size: 0x1
	char pad_0x6[0x2]; // Offset: 0x6 | Size: 0x2
	struct FMovieSceneTangentDataSerializationHelper Tangent; // Offset: 0x8 | Size: 0x14
};

// Object: ScriptStruct AkAudio.MovieSceneTangentDataSerializationHelper
// Inherited Bytes: 0x0 | Struct Size: 0x14
struct FMovieSceneTangentDataSerializationHelper {
	// Fields
	float ArriveTangent; // Offset: 0x0 | Size: 0x4
	float LeaveTangent; // Offset: 0x4 | Size: 0x4
	enum class ERichCurveTangentWeightMode TangentWeightMode; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x3]; // Offset: 0x9 | Size: 0x3
	float ArriveTangentWeight; // Offset: 0xc | Size: 0x4
	float LeaveTangentWeight; // Offset: 0x10 | Size: 0x4
};

// Object: ScriptStruct AkAudio.WwiseDataRow
// Inherited Bytes: 0x8 | Struct Size: 0x50
struct FWwiseDataRow : FTableRowBase {
	// Fields
	struct FString SoundbankName; // Offset: 0x8 | Size: 0x10
	struct TSoftObjectPtr<UAkAudioEvent> RealAkEvent; // Offset: 0x18 | Size: 0x28
	struct FGuid EventGuid; // Offset: 0x40 | Size: 0x10
};

