#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class AndroidPermission.AndroidPermissionCallbackProxy
// Inherited Bytes: 0x28 | Struct Size: 0x48
struct UAndroidPermissionCallbackProxy : UObject {
	// Fields
	struct FMulticastInlineDelegate OnPermissionsGrantedDynamicDelegate; // Offset: 0x28 | Size: 0x10
	char pad_0x38[0x10]; // Offset: 0x38 | Size: 0x10
};

// Object: Class AndroidPermission.AndroidPermissionFunctionLibrary
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UAndroidPermissionFunctionLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object: Function AndroidPermission.AndroidPermissionFunctionLibrary.CheckPermission
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1016668a4
	// Return & Params: [ Num(2) Size(0x11) ]
	bool CheckPermission(struct FString Permission);

	// Object: Function AndroidPermission.AndroidPermissionFunctionLibrary.AcquirePermissions
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1016667d8
	// Return & Params: [ Num(2) Size(0x18) ]
	struct UAndroidPermissionCallbackProxy* AcquirePermissions(struct TArray<struct FString>& Permissions);
};

