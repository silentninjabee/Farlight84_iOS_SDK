#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct AnimGraphRuntime.AnimSequencerInstanceProxy
// Inherited Bytes: 0x6e0 | Struct Size: 0x930
struct FAnimSequencerInstanceProxy : FAnimInstanceProxy {
	// Fields
	char pad_0x6E0[0x250]; // Offset: 0x6e0 | Size: 0x250
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_SkeletalControlBase
// Inherited Bytes: 0x10 | Struct Size: 0xc8
struct FAnimNode_SkeletalControlBase : FAnimNode_Base {
	// Fields
	struct FComponentSpacePoseLink ComponentPose; // Offset: 0x10 | Size: 0x10
	int32_t LODThreshold; // Offset: 0x20 | Size: 0x4
	float ActualAlpha; // Offset: 0x24 | Size: 0x4
	enum class EAnimAlphaInputType AlphaInputType; // Offset: 0x28 | Size: 0x1
	bool bAlphaBoolEnabled; // Offset: 0x29 | Size: 0x1
	char pad_0x2A[0x2]; // Offset: 0x2a | Size: 0x2
	float Alpha; // Offset: 0x2c | Size: 0x4
	struct FInputScaleBias AlphaScaleBias; // Offset: 0x30 | Size: 0x8
	struct FInputAlphaBoolBlend AlphaBoolBlend; // Offset: 0x38 | Size: 0x48
	struct FName AlphaCurveName; // Offset: 0x80 | Size: 0x8
	struct FInputScaleBiasClamp AlphaScaleBiasClamp; // Offset: 0x88 | Size: 0x30
	char pad_0xB8[0x10]; // Offset: 0xb8 | Size: 0x10
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_BlendSpacePlayer
// Inherited Bytes: 0x30 | Struct Size: 0xe0
struct FAnimNode_BlendSpacePlayer : FAnimNode_AssetPlayerBase {
	// Fields
	float X; // Offset: 0x30 | Size: 0x4
	float Y; // Offset: 0x34 | Size: 0x4
	float Z; // Offset: 0x38 | Size: 0x4
	float PlayRate; // Offset: 0x3c | Size: 0x4
	bool bLoop; // Offset: 0x40 | Size: 0x1
	bool bResetPlayTimeWhenBlendSpaceChanges; // Offset: 0x41 | Size: 0x1
	char pad_0x42[0x2]; // Offset: 0x42 | Size: 0x2
	float StartPosition; // Offset: 0x44 | Size: 0x4
	struct UBlendSpaceBase* BlendSpace; // Offset: 0x48 | Size: 0x8
	char pad_0x50[0x88]; // Offset: 0x50 | Size: 0x88
	struct UBlendSpaceBase* PreviousBlendSpace; // Offset: 0xd8 | Size: 0x8
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_AimOffsetLookAt
// Inherited Bytes: 0xe0 | Struct Size: 0x1b0
struct FAnimNode_AimOffsetLookAt : FAnimNode_BlendSpacePlayer {
	// Fields
	char pad_0xE0[0x60]; // Offset: 0xe0 | Size: 0x60
	struct FPoseLink BasePose; // Offset: 0x140 | Size: 0x10
	int32_t LODThreshold; // Offset: 0x150 | Size: 0x4
	struct FName SourceSocketName; // Offset: 0x154 | Size: 0x8
	struct FName PivotSocketName; // Offset: 0x15c | Size: 0x8
	struct FVector LookAtLocation; // Offset: 0x164 | Size: 0xc
	struct FVector SocketAxis; // Offset: 0x170 | Size: 0xc
	float Alpha; // Offset: 0x17c | Size: 0x4
	char pad_0x180[0x30]; // Offset: 0x180 | Size: 0x30
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_AnimDynamics
// Inherited Bytes: 0xc8 | Struct Size: 0x450
struct FAnimNode_AnimDynamics : FAnimNode_SkeletalControlBase {
	// Fields
	float LinearDampingOverride; // Offset: 0xc8 | Size: 0x4
	float AngularDampingOverride; // Offset: 0xcc | Size: 0x4
	char pad_0xD0[0x60]; // Offset: 0xd0 | Size: 0x60
	struct FBoneReference RelativeSpaceBone; // Offset: 0x130 | Size: 0x10
	struct FBoneReference BoundBone; // Offset: 0x140 | Size: 0x10
	struct FBoneReference ChainEnd; // Offset: 0x150 | Size: 0x10
	struct FVector BoxExtents; // Offset: 0x160 | Size: 0xc
	struct FVector LocalJointOffset; // Offset: 0x16c | Size: 0xc
	float GravityScale; // Offset: 0x178 | Size: 0x4
	struct FVector GravityOverride; // Offset: 0x17c | Size: 0xc
	float LinearSpringConstant; // Offset: 0x188 | Size: 0x4
	float AngularSpringConstant; // Offset: 0x18c | Size: 0x4
	float WindScale; // Offset: 0x190 | Size: 0x4
	struct FVector ComponentLinearAccScale; // Offset: 0x194 | Size: 0xc
	struct FVector ComponentLinearVelScale; // Offset: 0x1a0 | Size: 0xc
	struct FVector ComponentAppliedLinearAccClamp; // Offset: 0x1ac | Size: 0xc
	float AngularBiasOverride; // Offset: 0x1b8 | Size: 0x4
	int32_t NumSolverIterationsPreUpdate; // Offset: 0x1bc | Size: 0x4
	int32_t NumSolverIterationsPostUpdate; // Offset: 0x1c0 | Size: 0x4
	struct FAnimPhysConstraintSetup ConstraintSetup; // Offset: 0x1c4 | Size: 0x48
	char pad_0x20C[0x4]; // Offset: 0x20c | Size: 0x4
	struct TArray<struct FAnimPhysSphericalLimit> SphericalLimits; // Offset: 0x210 | Size: 0x10
	float SphereCollisionRadius; // Offset: 0x220 | Size: 0x4
	struct FVector ExternalForce; // Offset: 0x224 | Size: 0xc
	struct TArray<struct FAnimPhysPlanarLimit> PlanarLimits; // Offset: 0x230 | Size: 0x10
	enum class AnimPhysCollisionType CollisionType; // Offset: 0x240 | Size: 0x1
	enum class AnimPhysSimSpaceType SimulationSpace; // Offset: 0x241 | Size: 0x1
	char pad_0x242[0x2]; // Offset: 0x242 | Size: 0x2
	bool bForceResetTeleportType; // Offset: 0x244 | Size: 0x1
	char bUseSphericalLimits : 1; // Offset: 0x245 | Size: 0x1
	char bUsePlanarLimit : 1; // Offset: 0x245 | Size: 0x1
	char bDoUpdate : 1; // Offset: 0x245 | Size: 0x1
	char bDoEval : 1; // Offset: 0x245 | Size: 0x1
	char bOverrideLinearDamping : 1; // Offset: 0x245 | Size: 0x1
	char bOverrideAngularBias : 1; // Offset: 0x245 | Size: 0x1
	char bOverrideAngularDamping : 1; // Offset: 0x245 | Size: 0x1
	char bEnableWind : 1; // Offset: 0x245 | Size: 0x1
	char pad_0x246_0 : 1; // Offset: 0x246 | Size: 0x1
	char bUseGravityOverride : 1; // Offset: 0x246 | Size: 0x1
	char bLinearSpring : 1; // Offset: 0x246 | Size: 0x1
	char bAngularSpring : 1; // Offset: 0x246 | Size: 0x1
	char bChain : 1; // Offset: 0x246 | Size: 0x1
	char pad_0x246_5 : 3; // Offset: 0x246 | Size: 0x1
	char pad_0x247[0x9]; // Offset: 0x247 | Size: 0x9
	struct FRotationRetargetingInfo RetargetingSettings; // Offset: 0x250 | Size: 0x130
	char pad_0x380[0xd0]; // Offset: 0x380 | Size: 0xd0
};

// Object: ScriptStruct AnimGraphRuntime.RotationRetargetingInfo
// Inherited Bytes: 0x0 | Struct Size: 0x130
struct FRotationRetargetingInfo {
	// Fields
	bool bEnabled; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0xf]; // Offset: 0x1 | Size: 0xf
	struct FTransform Source; // Offset: 0x10 | Size: 0x30
	struct FTransform Target; // Offset: 0x40 | Size: 0x30
	enum class ERotationComponent RotationComponent; // Offset: 0x70 | Size: 0x1
	char pad_0x71[0x3]; // Offset: 0x71 | Size: 0x3
	struct FVector TwistAxis; // Offset: 0x74 | Size: 0xc
	bool bUseAbsoluteAngle; // Offset: 0x80 | Size: 0x1
	char pad_0x81[0x3]; // Offset: 0x81 | Size: 0x3
	float SourceMinimum; // Offset: 0x84 | Size: 0x4
	float SourceMaximum; // Offset: 0x88 | Size: 0x4
	float TargetMinimum; // Offset: 0x8c | Size: 0x4
	float TargetMaximum; // Offset: 0x90 | Size: 0x4
	enum class EEasingFuncType EasingType; // Offset: 0x94 | Size: 0x1
	char pad_0x95[0x3]; // Offset: 0x95 | Size: 0x3
	struct FRuntimeFloatCurve CustomCurve; // Offset: 0x98 | Size: 0x88
	bool bFlipEasing; // Offset: 0x120 | Size: 0x1
	char pad_0x121[0x3]; // Offset: 0x121 | Size: 0x3
	float EasingWeight; // Offset: 0x124 | Size: 0x4
	bool bClamp; // Offset: 0x128 | Size: 0x1
	char pad_0x129[0x7]; // Offset: 0x129 | Size: 0x7
};

// Object: ScriptStruct AnimGraphRuntime.AnimPhysPlanarLimit
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FAnimPhysPlanarLimit {
	// Fields
	struct FBoneReference DrivingBone; // Offset: 0x0 | Size: 0x10
	struct FTransform PlaneTransform; // Offset: 0x10 | Size: 0x30
};

// Object: ScriptStruct AnimGraphRuntime.AnimPhysSphericalLimit
// Inherited Bytes: 0x0 | Struct Size: 0x24
struct FAnimPhysSphericalLimit {
	// Fields
	struct FBoneReference DrivingBone; // Offset: 0x0 | Size: 0x10
	struct FVector SphereLocalOffset; // Offset: 0x10 | Size: 0xc
	float LimitRadius; // Offset: 0x1c | Size: 0x4
	enum class ESphericalLimitType LimitType; // Offset: 0x20 | Size: 0x1
	char pad_0x21[0x3]; // Offset: 0x21 | Size: 0x3
};

// Object: ScriptStruct AnimGraphRuntime.AnimPhysConstraintSetup
// Inherited Bytes: 0x0 | Struct Size: 0x48
struct FAnimPhysConstraintSetup {
	// Fields
	enum class AnimPhysLinearConstraintType LinearXLimitType; // Offset: 0x0 | Size: 0x1
	enum class AnimPhysLinearConstraintType LinearYLimitType; // Offset: 0x1 | Size: 0x1
	enum class AnimPhysLinearConstraintType LinearZLimitType; // Offset: 0x2 | Size: 0x1
	char pad_0x3[0x1]; // Offset: 0x3 | Size: 0x1
	struct FVector LinearAxesMin; // Offset: 0x4 | Size: 0xc
	struct FVector LinearAxesMax; // Offset: 0x10 | Size: 0xc
	enum class AnimPhysAngularConstraintType AngularConstraintType; // Offset: 0x1c | Size: 0x1
	enum class AnimPhysTwistAxis TwistAxis; // Offset: 0x1d | Size: 0x1
	enum class AnimPhysTwistAxis AngularTargetAxis; // Offset: 0x1e | Size: 0x1
	char pad_0x1F[0x1]; // Offset: 0x1f | Size: 0x1
	float ConeAngle; // Offset: 0x20 | Size: 0x4
	struct FVector AngularLimitsMin; // Offset: 0x24 | Size: 0xc
	struct FVector AngularLimitsMax; // Offset: 0x30 | Size: 0xc
	struct FVector AngularTarget; // Offset: 0x3c | Size: 0xc
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_ApplyAdditive
// Inherited Bytes: 0x10 | Struct Size: 0xc8
struct FAnimNode_ApplyAdditive : FAnimNode_Base {
	// Fields
	struct FPoseLink Base; // Offset: 0x10 | Size: 0x10
	struct FPoseLink Additive; // Offset: 0x20 | Size: 0x10
	float Alpha; // Offset: 0x30 | Size: 0x4
	struct FInputScaleBias AlphaScaleBias; // Offset: 0x34 | Size: 0x8
	int32_t LODThreshold; // Offset: 0x3c | Size: 0x4
	struct FInputAlphaBoolBlend AlphaBoolBlend; // Offset: 0x40 | Size: 0x48
	struct FName AlphaCurveName; // Offset: 0x88 | Size: 0x8
	struct FInputScaleBiasClamp AlphaScaleBiasClamp; // Offset: 0x90 | Size: 0x30
	char pad_0xC0[0x4]; // Offset: 0xc0 | Size: 0x4
	enum class EAnimAlphaInputType AlphaInputType; // Offset: 0xc4 | Size: 0x1
	bool bAlphaBoolEnabled; // Offset: 0xc5 | Size: 0x1
	char pad_0xC6[0x2]; // Offset: 0xc6 | Size: 0x2
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_ApplyLimits
// Inherited Bytes: 0xc8 | Struct Size: 0xe8
struct FAnimNode_ApplyLimits : FAnimNode_SkeletalControlBase {
	// Fields
	struct TArray<struct FAngularRangeLimit> AngularRangeLimits; // Offset: 0xc8 | Size: 0x10
	struct TArray<struct FVector> AngularOffsets; // Offset: 0xd8 | Size: 0x10
};

// Object: ScriptStruct AnimGraphRuntime.AngularRangeLimit
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FAngularRangeLimit {
	// Fields
	struct FVector LimitMin; // Offset: 0x0 | Size: 0xc
	struct FVector LimitMax; // Offset: 0xc | Size: 0xc
	struct FBoneReference Bone; // Offset: 0x18 | Size: 0x10
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_BlendBoneByChannel
// Inherited Bytes: 0x10 | Struct Size: 0x68
struct FAnimNode_BlendBoneByChannel : FAnimNode_Base {
	// Fields
	struct FPoseLink A; // Offset: 0x10 | Size: 0x10
	struct FPoseLink B; // Offset: 0x20 | Size: 0x10
	struct TArray<struct FBlendBoneByChannelEntry> BoneDefinitions; // Offset: 0x30 | Size: 0x10
	char pad_0x40[0x10]; // Offset: 0x40 | Size: 0x10
	float Alpha; // Offset: 0x50 | Size: 0x4
	char pad_0x54[0x4]; // Offset: 0x54 | Size: 0x4
	struct FInputScaleBias AlphaScaleBias; // Offset: 0x58 | Size: 0x8
	enum class EBoneControlSpace TransformsSpace; // Offset: 0x60 | Size: 0x1
	char pad_0x61[0x7]; // Offset: 0x61 | Size: 0x7
};

// Object: ScriptStruct AnimGraphRuntime.BlendBoneByChannelEntry
// Inherited Bytes: 0x0 | Struct Size: 0x24
struct FBlendBoneByChannelEntry {
	// Fields
	struct FBoneReference SourceBone; // Offset: 0x0 | Size: 0x10
	struct FBoneReference TargetBone; // Offset: 0x10 | Size: 0x10
	bool bBlendTranslation; // Offset: 0x20 | Size: 0x1
	bool bBlendRotation; // Offset: 0x21 | Size: 0x1
	bool bBlendScale; // Offset: 0x22 | Size: 0x1
	char pad_0x23[0x1]; // Offset: 0x23 | Size: 0x1
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_BlendListBase
// Inherited Bytes: 0x10 | Struct Size: 0xa0
struct FAnimNode_BlendListBase : FAnimNode_Base {
	// Fields
	struct TArray<struct FPoseLink> BlendPose; // Offset: 0x10 | Size: 0x10
	struct TArray<float> BlendTime; // Offset: 0x20 | Size: 0x10
	enum class EBlendListTransitionType TransitionType; // Offset: 0x30 | Size: 0x1
	enum class EAlphaBlendOption BlendType; // Offset: 0x31 | Size: 0x1
	bool bResetChildOnActivation; // Offset: 0x32 | Size: 0x1
	char pad_0x33[0x5]; // Offset: 0x33 | Size: 0x5
	struct UCurveFloat* CustomBlendCurve; // Offset: 0x38 | Size: 0x8
	struct UBlendProfile* BlendProfile; // Offset: 0x40 | Size: 0x8
	int32_t LODThreshold; // Offset: 0x48 | Size: 0x4
	char pad_0x4C[0x54]; // Offset: 0x4c | Size: 0x54
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_BlendListByBool
// Inherited Bytes: 0xa0 | Struct Size: 0xa8
struct FAnimNode_BlendListByBool : FAnimNode_BlendListBase {
	// Fields
	bool bActiveValue; // Offset: 0xa0 | Size: 0x1
	char pad_0xA1[0x7]; // Offset: 0xa1 | Size: 0x7
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_BlendListByEnum
// Inherited Bytes: 0xa0 | Struct Size: 0xb8
struct FAnimNode_BlendListByEnum : FAnimNode_BlendListBase {
	// Fields
	struct TArray<int32_t> EnumToPoseIndex; // Offset: 0xa0 | Size: 0x10
	char ActiveEnumValue; // Offset: 0xb0 | Size: 0x1
	char pad_0xB1[0x7]; // Offset: 0xb1 | Size: 0x7
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_BlendListByInt
// Inherited Bytes: 0xa0 | Struct Size: 0xa8
struct FAnimNode_BlendListByInt : FAnimNode_BlendListBase {
	// Fields
	int32_t ActiveChildIndex; // Offset: 0xa0 | Size: 0x4
	char pad_0xA4[0x4]; // Offset: 0xa4 | Size: 0x4
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_BlendSpaceEvaluator
// Inherited Bytes: 0xe0 | Struct Size: 0xe8
struct FAnimNode_BlendSpaceEvaluator : FAnimNode_BlendSpacePlayer {
	// Fields
	float NormalizedTime; // Offset: 0xe0 | Size: 0x4
	char pad_0xE4[0x4]; // Offset: 0xe4 | Size: 0x4
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_BoneDrivenController
// Inherited Bytes: 0xc8 | Struct Size: 0x118
struct FAnimNode_BoneDrivenController : FAnimNode_SkeletalControlBase {
	// Fields
	struct FBoneReference SourceBone; // Offset: 0xc8 | Size: 0x10
	struct UCurveFloat* DrivingCurve; // Offset: 0xd8 | Size: 0x8
	float Multiplier; // Offset: 0xe0 | Size: 0x4
	float RangeMin; // Offset: 0xe4 | Size: 0x4
	float RangeMax; // Offset: 0xe8 | Size: 0x4
	float RemappedMin; // Offset: 0xec | Size: 0x4
	float RemappedMax; // Offset: 0xf0 | Size: 0x4
	struct FName ParameterName; // Offset: 0xf4 | Size: 0x8
	struct FBoneReference TargetBone; // Offset: 0xfc | Size: 0x10
	enum class EDrivenDestinationMode DestinationMode; // Offset: 0x10c | Size: 0x1
	enum class EDrivenBoneModificationMode ModificationMode; // Offset: 0x10d | Size: 0x1
	enum class EComponentType SourceComponent; // Offset: 0x10e | Size: 0x1
	char bUseRange : 1; // Offset: 0x10f | Size: 0x1
	char bAffectTargetTranslationX : 1; // Offset: 0x10f | Size: 0x1
	char bAffectTargetTranslationY : 1; // Offset: 0x10f | Size: 0x1
	char bAffectTargetTranslationZ : 1; // Offset: 0x10f | Size: 0x1
	char bAffectTargetRotationX : 1; // Offset: 0x10f | Size: 0x1
	char bAffectTargetRotationY : 1; // Offset: 0x10f | Size: 0x1
	char bAffectTargetRotationZ : 1; // Offset: 0x10f | Size: 0x1
	char bAffectTargetScaleX : 1; // Offset: 0x10f | Size: 0x1
	char bAffectTargetScaleY : 1; // Offset: 0x110 | Size: 0x1
	char bAffectTargetScaleZ : 1; // Offset: 0x110 | Size: 0x1
	char pad_0x110_2 : 6; // Offset: 0x110 | Size: 0x1
	char pad_0x111[0x7]; // Offset: 0x111 | Size: 0x7
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_CCDIK
// Inherited Bytes: 0xc8 | Struct Size: 0x180
struct FAnimNode_CCDIK : FAnimNode_SkeletalControlBase {
	// Fields
	struct FVector EffectorLocation; // Offset: 0xc8 | Size: 0xc
	enum class EBoneControlSpace EffectorLocationSpace; // Offset: 0xd4 | Size: 0x1
	char pad_0xD5[0xb]; // Offset: 0xd5 | Size: 0xb
	struct FBoneSocketTarget EffectorTarget; // Offset: 0xe0 | Size: 0x60
	struct FBoneReference TipBone; // Offset: 0x140 | Size: 0x10
	struct FBoneReference RootBone; // Offset: 0x150 | Size: 0x10
	float Precision; // Offset: 0x160 | Size: 0x4
	int32_t MaxIterations; // Offset: 0x164 | Size: 0x4
	bool bStartFromTail; // Offset: 0x168 | Size: 0x1
	bool bEnableRotationLimit; // Offset: 0x169 | Size: 0x1
	char pad_0x16A[0x6]; // Offset: 0x16a | Size: 0x6
	struct TArray<float> RotationLimitPerJoints; // Offset: 0x170 | Size: 0x10
};

// Object: ScriptStruct AnimGraphRuntime.BoneSocketTarget
// Inherited Bytes: 0x0 | Struct Size: 0x60
struct FBoneSocketTarget {
	// Fields
	bool bUseSocket; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	struct FBoneReference BoneReference; // Offset: 0x4 | Size: 0x10
	char pad_0x14[0xc]; // Offset: 0x14 | Size: 0xc
	struct FSocketReference SocketReference; // Offset: 0x20 | Size: 0x40
};

// Object: ScriptStruct AnimGraphRuntime.SocketReference
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FSocketReference {
	// Fields
	char pad_0x0[0x30]; // Offset: 0x0 | Size: 0x30
	struct FName SocketName; // Offset: 0x30 | Size: 0x8
	char pad_0x38[0x8]; // Offset: 0x38 | Size: 0x8
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_Constraint
// Inherited Bytes: 0xc8 | Struct Size: 0x108
struct FAnimNode_Constraint : FAnimNode_SkeletalControlBase {
	// Fields
	struct FBoneReference BoneToModify; // Offset: 0xc8 | Size: 0x10
	struct TArray<struct FConstraint> ConstraintSetup; // Offset: 0xd8 | Size: 0x10
	struct TArray<float> ConstraintWeights; // Offset: 0xe8 | Size: 0x10
	char pad_0xF8[0x10]; // Offset: 0xf8 | Size: 0x10
};

// Object: ScriptStruct AnimGraphRuntime.Constraint
// Inherited Bytes: 0x0 | Struct Size: 0x1c
struct FConstraint {
	// Fields
	struct FBoneReference TargetBone; // Offset: 0x0 | Size: 0x10
	enum class EConstraintOffsetOption OffsetOption; // Offset: 0x10 | Size: 0x1
	enum class ETransformConstraintType TransformType; // Offset: 0x11 | Size: 0x1
	struct FFilterOptionPerAxis PerAxis; // Offset: 0x12 | Size: 0x3
	char pad_0x15[0x7]; // Offset: 0x15 | Size: 0x7
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_CopyBone
// Inherited Bytes: 0xc8 | Struct Size: 0xf0
struct FAnimNode_CopyBone : FAnimNode_SkeletalControlBase {
	// Fields
	struct FBoneReference SourceBone; // Offset: 0xc8 | Size: 0x10
	struct FBoneReference TargetBone; // Offset: 0xd8 | Size: 0x10
	bool bCopyTranslation; // Offset: 0xe8 | Size: 0x1
	bool bCopyRotation; // Offset: 0xe9 | Size: 0x1
	bool bCopyScale; // Offset: 0xea | Size: 0x1
	enum class EBoneControlSpace ControlSpace; // Offset: 0xeb | Size: 0x1
	char pad_0xEC[0x4]; // Offset: 0xec | Size: 0x4
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_CopyBoneDelta
// Inherited Bytes: 0xc8 | Struct Size: 0xf8
struct FAnimNode_CopyBoneDelta : FAnimNode_SkeletalControlBase {
	// Fields
	struct FBoneReference SourceBone; // Offset: 0xc8 | Size: 0x10
	struct FBoneReference TargetBone; // Offset: 0xd8 | Size: 0x10
	bool bCopyTranslation; // Offset: 0xe8 | Size: 0x1
	bool bCopyRotation; // Offset: 0xe9 | Size: 0x1
	bool bCopyScale; // Offset: 0xea | Size: 0x1
	enum class CopyBoneDeltaMode CopyMode; // Offset: 0xeb | Size: 0x1
	float TranslationMultiplier; // Offset: 0xec | Size: 0x4
	float RotationMultiplier; // Offset: 0xf0 | Size: 0x4
	float ScaleMultiplier; // Offset: 0xf4 | Size: 0x4
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_CopyPoseFromMesh
// Inherited Bytes: 0x10 | Struct Size: 0x140
struct FAnimNode_CopyPoseFromMesh : FAnimNode_Base {
	// Fields
	struct TWeakObjectPtr<struct USkeletalMeshComponent> SourceMeshComponent; // Offset: 0x10 | Size: 0x8
	bool bUseAttachedParent; // Offset: 0x18 | Size: 0x1
	bool bCopyCurves; // Offset: 0x19 | Size: 0x1
	char pad_0x1A[0x126]; // Offset: 0x1a | Size: 0x126
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_CurveSource
// Inherited Bytes: 0x10 | Struct Size: 0x40
struct FAnimNode_CurveSource : FAnimNode_Base {
	// Fields
	struct FPoseLink SourcePose; // Offset: 0x10 | Size: 0x10
	struct FName SourceBinding; // Offset: 0x20 | Size: 0x8
	float Alpha; // Offset: 0x28 | Size: 0x4
	char pad_0x2C[0x4]; // Offset: 0x2c | Size: 0x4
	struct TScriptInterface<ICurveSourceInterface> CurveSource; // Offset: 0x30 | Size: 0x10
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_Fabrik
// Inherited Bytes: 0xc8 | Struct Size: 0x190
struct FAnimNode_Fabrik : FAnimNode_SkeletalControlBase {
	// Fields
	char pad_0xC8[0x8]; // Offset: 0xc8 | Size: 0x8
	struct FTransform EffectorTransform; // Offset: 0xd0 | Size: 0x30
	struct FBoneSocketTarget EffectorTarget; // Offset: 0x100 | Size: 0x60
	struct FBoneReference TipBone; // Offset: 0x160 | Size: 0x10
	struct FBoneReference RootBone; // Offset: 0x170 | Size: 0x10
	float Precision; // Offset: 0x180 | Size: 0x4
	int32_t MaxIterations; // Offset: 0x184 | Size: 0x4
	enum class EBoneControlSpace EffectorTransformSpace; // Offset: 0x188 | Size: 0x1
	enum class EBoneRotationSource EffectorRotationSource; // Offset: 0x189 | Size: 0x1
	char pad_0x18A[0x6]; // Offset: 0x18a | Size: 0x6
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_HandIKRetargeting
// Inherited Bytes: 0xc8 | Struct Size: 0x120
struct FAnimNode_HandIKRetargeting : FAnimNode_SkeletalControlBase {
	// Fields
	struct FBoneReference RightHandFK; // Offset: 0xc8 | Size: 0x10
	struct FBoneReference LeftHandFK; // Offset: 0xd8 | Size: 0x10
	struct FBoneReference RightHandIK; // Offset: 0xe8 | Size: 0x10
	struct FBoneReference LeftHandIK; // Offset: 0xf8 | Size: 0x10
	struct TArray<struct FBoneReference> IKBonesToMove; // Offset: 0x108 | Size: 0x10
	float HandFKWeight; // Offset: 0x118 | Size: 0x4
	char pad_0x11C[0x4]; // Offset: 0x11c | Size: 0x4
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_LayeredBoneBlend
// Inherited Bytes: 0x10 | Struct Size: 0xc0
struct FAnimNode_LayeredBoneBlend : FAnimNode_Base {
	// Fields
	struct FPoseLink BasePose; // Offset: 0x10 | Size: 0x10
	struct TArray<struct FPoseLink> BlendPoses; // Offset: 0x20 | Size: 0x10
	struct TArray<struct FInputBlendPose> LayerSetup; // Offset: 0x30 | Size: 0x10
	struct TArray<float> BlendWeights; // Offset: 0x40 | Size: 0x10
	bool bMeshSpaceRotationBlend; // Offset: 0x50 | Size: 0x1
	bool bMeshSpaceScaleBlend; // Offset: 0x51 | Size: 0x1
	enum class ECurveBlendOption CurveBlendOption; // Offset: 0x52 | Size: 0x1
	bool bBlendRootMotionBasedOnRootBone; // Offset: 0x53 | Size: 0x1
	char pad_0x54[0x4]; // Offset: 0x54 | Size: 0x4
	int32_t LODThreshold; // Offset: 0x58 | Size: 0x4
	char pad_0x5C[0x4]; // Offset: 0x5c | Size: 0x4
	struct TArray<struct FPerBoneBlendWeight> PerBoneBlendWeights; // Offset: 0x60 | Size: 0x10
	struct FGuid SkeletonGuid; // Offset: 0x70 | Size: 0x10
	struct FGuid VirtualBoneGuid; // Offset: 0x80 | Size: 0x10
	char pad_0x90[0x30]; // Offset: 0x90 | Size: 0x30
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_LegIK
// Inherited Bytes: 0xc8 | Struct Size: 0xf8
struct FAnimNode_LegIK : FAnimNode_SkeletalControlBase {
	// Fields
	float ReachPrecision; // Offset: 0xc8 | Size: 0x4
	int32_t MaxIterations; // Offset: 0xcc | Size: 0x4
	struct TArray<struct FAnimLegIKDefinition> LegsDefinition; // Offset: 0xd0 | Size: 0x10
	char pad_0xE0[0x18]; // Offset: 0xe0 | Size: 0x18
};

// Object: ScriptStruct AnimGraphRuntime.AnimLegIKDefinition
// Inherited Bytes: 0x0 | Struct Size: 0x2c
struct FAnimLegIKDefinition {
	// Fields
	struct FBoneReference IKFootBone; // Offset: 0x0 | Size: 0x10
	struct FBoneReference FKFootBone; // Offset: 0x10 | Size: 0x10
	int32_t NumBonesInLimb; // Offset: 0x20 | Size: 0x4
	float MinRotationAngle; // Offset: 0x24 | Size: 0x4
	enum class EAxis FootBoneForwardAxis; // Offset: 0x28 | Size: 0x1
	enum class EAxis HingeRotationAxis; // Offset: 0x29 | Size: 0x1
	bool bEnableRotationLimit; // Offset: 0x2a | Size: 0x1
	bool bEnableKneeTwistCorrection; // Offset: 0x2b | Size: 0x1
};

// Object: ScriptStruct AnimGraphRuntime.AnimLegIKData
// Inherited Bytes: 0x0 | Struct Size: 0xa0
struct FAnimLegIKData {
	// Fields
	char pad_0x0[0xa0]; // Offset: 0x0 | Size: 0xa0
};

// Object: ScriptStruct AnimGraphRuntime.IKChain
// Inherited Bytes: 0x0 | Struct Size: 0x38
struct FIKChain {
	// Fields
	char pad_0x0[0x38]; // Offset: 0x0 | Size: 0x38
};

// Object: ScriptStruct AnimGraphRuntime.IKChainLink
// Inherited Bytes: 0x0 | Struct Size: 0x3c
struct FIKChainLink {
	// Fields
	char pad_0x0[0x3c]; // Offset: 0x0 | Size: 0x3c
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_LookAt
// Inherited Bytes: 0xc8 | Struct Size: 0x1b0
struct FAnimNode_LookAt : FAnimNode_SkeletalControlBase {
	// Fields
	struct FBoneReference BoneToModify; // Offset: 0xc8 | Size: 0x10
	char pad_0xD8[0x8]; // Offset: 0xd8 | Size: 0x8
	struct FBoneSocketTarget LookAtTarget; // Offset: 0xe0 | Size: 0x60
	struct FVector LookAtLocation; // Offset: 0x140 | Size: 0xc
	struct FAxis LookAt_Axis; // Offset: 0x14c | Size: 0x10
	bool bUseLookUpAxis; // Offset: 0x15c | Size: 0x1
	enum class EInterpolationBlend InterpolationType; // Offset: 0x15d | Size: 0x1
	char pad_0x15E[0x2]; // Offset: 0x15e | Size: 0x2
	struct FAxis LookUp_Axis; // Offset: 0x160 | Size: 0x10
	float LookAtClamp; // Offset: 0x170 | Size: 0x4
	float InterpolationTime; // Offset: 0x174 | Size: 0x4
	float InterpolationTriggerThreashold; // Offset: 0x178 | Size: 0x4
	char pad_0x17C[0x34]; // Offset: 0x17c | Size: 0x34
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_MakeDynamicAdditive
// Inherited Bytes: 0x10 | Struct Size: 0x38
struct FAnimNode_MakeDynamicAdditive : FAnimNode_Base {
	// Fields
	struct FPoseLink Base; // Offset: 0x10 | Size: 0x10
	struct FPoseLink Additive; // Offset: 0x20 | Size: 0x10
	bool bMeshSpaceAdditive; // Offset: 0x30 | Size: 0x1
	char pad_0x31[0x7]; // Offset: 0x31 | Size: 0x7
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_ModifyBone
// Inherited Bytes: 0xc8 | Struct Size: 0x108
struct FAnimNode_ModifyBone : FAnimNode_SkeletalControlBase {
	// Fields
	struct FBoneReference BoneToModify; // Offset: 0xc8 | Size: 0x10
	struct FVector Translation; // Offset: 0xd8 | Size: 0xc
	struct FRotator Rotation; // Offset: 0xe4 | Size: 0xc
	struct FVector Scale; // Offset: 0xf0 | Size: 0xc
	enum class EBoneModificationMode TranslationMode; // Offset: 0xfc | Size: 0x1
	enum class EBoneModificationMode RotationMode; // Offset: 0xfd | Size: 0x1
	enum class EBoneModificationMode ScaleMode; // Offset: 0xfe | Size: 0x1
	enum class EBoneControlSpace TranslationSpace; // Offset: 0xff | Size: 0x1
	enum class EBoneControlSpace RotationSpace; // Offset: 0x100 | Size: 0x1
	enum class EBoneControlSpace ScaleSpace; // Offset: 0x101 | Size: 0x1
	char pad_0x102[0x6]; // Offset: 0x102 | Size: 0x6
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_ModifyCurve
// Inherited Bytes: 0x10 | Struct Size: 0x58
struct FAnimNode_ModifyCurve : FAnimNode_Base {
	// Fields
	struct FPoseLink SourcePose; // Offset: 0x10 | Size: 0x10
	struct TArray<float> CurveValues; // Offset: 0x20 | Size: 0x10
	struct TArray<struct FName> CurveNames; // Offset: 0x30 | Size: 0x10
	char pad_0x40[0x10]; // Offset: 0x40 | Size: 0x10
	float Alpha; // Offset: 0x50 | Size: 0x4
	enum class EModifyCurveApplyMode ApplyMode; // Offset: 0x54 | Size: 0x1
	char pad_0x55[0x3]; // Offset: 0x55 | Size: 0x3
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_MultiWayBlend
// Inherited Bytes: 0x10 | Struct Size: 0x50
struct FAnimNode_MultiWayBlend : FAnimNode_Base {
	// Fields
	struct TArray<struct FPoseLink> Poses; // Offset: 0x10 | Size: 0x10
	struct TArray<float> DesiredAlphas; // Offset: 0x20 | Size: 0x10
	char pad_0x30[0x10]; // Offset: 0x30 | Size: 0x10
	struct FInputScaleBias AlphaScaleBias; // Offset: 0x40 | Size: 0x8
	bool bAdditiveNode; // Offset: 0x48 | Size: 0x1
	bool bNormalizeAlpha; // Offset: 0x49 | Size: 0x1
	char pad_0x4A[0x6]; // Offset: 0x4a | Size: 0x6
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_ObserveBone
// Inherited Bytes: 0xc8 | Struct Size: 0x100
struct FAnimNode_ObserveBone : FAnimNode_SkeletalControlBase {
	// Fields
	struct FBoneReference BoneToObserve; // Offset: 0xc8 | Size: 0x10
	enum class EBoneControlSpace DisplaySpace; // Offset: 0xd8 | Size: 0x1
	bool bRelativeToRefPose; // Offset: 0xd9 | Size: 0x1
	char pad_0xDA[0x2]; // Offset: 0xda | Size: 0x2
	struct FVector Translation; // Offset: 0xdc | Size: 0xc
	struct FRotator Rotation; // Offset: 0xe8 | Size: 0xc
	struct FVector Scale; // Offset: 0xf4 | Size: 0xc
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_PoseHandler
// Inherited Bytes: 0x30 | Struct Size: 0x78
struct FAnimNode_PoseHandler : FAnimNode_AssetPlayerBase {
	// Fields
	struct UPoseAsset* PoseAsset; // Offset: 0x30 | Size: 0x8
	char pad_0x38[0x40]; // Offset: 0x38 | Size: 0x40
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_PoseBlendNode
// Inherited Bytes: 0x78 | Struct Size: 0x98
struct FAnimNode_PoseBlendNode : FAnimNode_PoseHandler {
	// Fields
	struct FPoseLink SourcePose; // Offset: 0x78 | Size: 0x10
	enum class EAlphaBlendOption BlendOption; // Offset: 0x88 | Size: 0x1
	char pad_0x89[0x7]; // Offset: 0x89 | Size: 0x7
	struct UCurveFloat* CustomCurve; // Offset: 0x90 | Size: 0x8
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_PoseByName
// Inherited Bytes: 0x78 | Struct Size: 0x90
struct FAnimNode_PoseByName : FAnimNode_PoseHandler {
	// Fields
	struct FName PoseName; // Offset: 0x78 | Size: 0x8
	float PoseWeight; // Offset: 0x80 | Size: 0x4
	char pad_0x84[0xc]; // Offset: 0x84 | Size: 0xc
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_PoseDriver
// Inherited Bytes: 0x78 | Struct Size: 0x128
struct FAnimNode_PoseDriver : FAnimNode_PoseHandler {
	// Fields
	struct FPoseLink SourcePose; // Offset: 0x78 | Size: 0x10
	struct TArray<struct FBoneReference> SourceBones; // Offset: 0x88 | Size: 0x10
	struct TArray<struct FBoneReference> OnlyDriveBones; // Offset: 0x98 | Size: 0x10
	struct TArray<struct FPoseDriverTarget> PoseTargets; // Offset: 0xa8 | Size: 0x10
	char pad_0xB8[0x30]; // Offset: 0xb8 | Size: 0x30
	struct FBoneReference EvalSpaceBone; // Offset: 0xe8 | Size: 0x10
	struct FRBFParams RBFParams; // Offset: 0xf8 | Size: 0x2c
	enum class EPoseDriverSource DriveSource; // Offset: 0x124 | Size: 0x1
	enum class EPoseDriverOutput DriveOutput; // Offset: 0x125 | Size: 0x1
	char bOnlyDriveSelectedBones : 1; // Offset: 0x126 | Size: 0x1
	char pad_0x126_1 : 7; // Offset: 0x126 | Size: 0x1
	char pad_0x127[0x1]; // Offset: 0x127 | Size: 0x1
};

// Object: ScriptStruct AnimGraphRuntime.RBFParams
// Inherited Bytes: 0x0 | Struct Size: 0x2c
struct FRBFParams {
	// Fields
	int32_t TargetDimensions; // Offset: 0x0 | Size: 0x4
	enum class ERBFSolverType SolverType; // Offset: 0x4 | Size: 0x1
	char pad_0x5[0x3]; // Offset: 0x5 | Size: 0x3
	float Radius; // Offset: 0x8 | Size: 0x4
	enum class ERBFFunctionType Function; // Offset: 0xc | Size: 0x1
	enum class ERBFDistanceMethod DistanceMethod; // Offset: 0xd | Size: 0x1
	enum class EBoneAxis TwistAxis; // Offset: 0xe | Size: 0x1
	char pad_0xF[0x1]; // Offset: 0xf | Size: 0x1
	float WeightThreshold; // Offset: 0x10 | Size: 0x4
	enum class ERBFNormalizeMethod NormalizeMethod; // Offset: 0x14 | Size: 0x1
	char pad_0x15[0x3]; // Offset: 0x15 | Size: 0x3
	struct FVector MedianReference; // Offset: 0x18 | Size: 0xc
	float MedianMin; // Offset: 0x24 | Size: 0x4
	float MedianMax; // Offset: 0x28 | Size: 0x4
};

// Object: ScriptStruct AnimGraphRuntime.PoseDriverTarget
// Inherited Bytes: 0x0 | Struct Size: 0xc0
struct FPoseDriverTarget {
	// Fields
	struct TArray<struct FPoseDriverTransform> BoneTransforms; // Offset: 0x0 | Size: 0x10
	struct FRotator TargetRotation; // Offset: 0x10 | Size: 0xc
	float TargetScale; // Offset: 0x1c | Size: 0x4
	enum class ERBFDistanceMethod DistanceMethod; // Offset: 0x20 | Size: 0x1
	enum class ERBFFunctionType FunctionType; // Offset: 0x21 | Size: 0x1
	bool bApplyCustomCurve; // Offset: 0x22 | Size: 0x1
	char pad_0x23[0x5]; // Offset: 0x23 | Size: 0x5
	struct FRichCurve CustomCurve; // Offset: 0x28 | Size: 0x80
	struct FName DrivenName; // Offset: 0xa8 | Size: 0x8
	char pad_0xB0[0x8]; // Offset: 0xb0 | Size: 0x8
	bool bIsHidden; // Offset: 0xb8 | Size: 0x1
	char pad_0xB9[0x7]; // Offset: 0xb9 | Size: 0x7
};

// Object: ScriptStruct AnimGraphRuntime.PoseDriverTransform
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FPoseDriverTransform {
	// Fields
	struct FVector TargetTranslation; // Offset: 0x0 | Size: 0xc
	struct FRotator TargetRotation; // Offset: 0xc | Size: 0xc
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_PoseSnapshot
// Inherited Bytes: 0x10 | Struct Size: 0x90
struct FAnimNode_PoseSnapshot : FAnimNode_Base {
	// Fields
	struct FName SnapshotName; // Offset: 0x10 | Size: 0x8
	struct FPoseSnapshot Snapshot; // Offset: 0x18 | Size: 0x38
	enum class ESnapshotSourceMode Mode; // Offset: 0x50 | Size: 0x1
	char pad_0x51[0x3f]; // Offset: 0x51 | Size: 0x3f
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_RandomPlayer
// Inherited Bytes: 0x10 | Struct Size: 0x78
struct FAnimNode_RandomPlayer : FAnimNode_Base {
	// Fields
	struct TArray<struct FRandomPlayerSequenceEntry> Entries; // Offset: 0x10 | Size: 0x10
	char pad_0x20[0x50]; // Offset: 0x20 | Size: 0x50
	bool bShuffleMode; // Offset: 0x70 | Size: 0x1
	char pad_0x71[0x7]; // Offset: 0x71 | Size: 0x7
};

// Object: ScriptStruct AnimGraphRuntime.RandomPlayerSequenceEntry
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FRandomPlayerSequenceEntry {
	// Fields
	struct UAnimSequence* Sequence; // Offset: 0x0 | Size: 0x8
	float ChanceToPlay; // Offset: 0x8 | Size: 0x4
	int32_t MinLoopCount; // Offset: 0xc | Size: 0x4
	int32_t MaxLoopCount; // Offset: 0x10 | Size: 0x4
	float MinPlayRate; // Offset: 0x14 | Size: 0x4
	float MaxPlayRate; // Offset: 0x18 | Size: 0x4
	char pad_0x1C[0x4]; // Offset: 0x1c | Size: 0x4
	struct FAlphaBlend BlendIn; // Offset: 0x20 | Size: 0x30
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_MeshSpaceRefPose
// Inherited Bytes: 0x10 | Struct Size: 0x10
struct FAnimNode_MeshSpaceRefPose : FAnimNode_Base {
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_RefPose
// Inherited Bytes: 0x10 | Struct Size: 0x18
struct FAnimNode_RefPose : FAnimNode_Base {
	// Fields
	enum class ERefPoseType RefPoseType; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x7]; // Offset: 0x11 | Size: 0x7
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_ResetRoot
// Inherited Bytes: 0xc8 | Struct Size: 0xd8
struct FAnimNode_ResetRoot : FAnimNode_SkeletalControlBase {
	// Fields
	char pad_0xC8[0x10]; // Offset: 0xc8 | Size: 0x10
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_RigidBody
// Inherited Bytes: 0xc8 | Struct Size: 0x590
struct FAnimNode_RigidBody : FAnimNode_SkeletalControlBase {
	// Fields
	struct UPhysicsAsset* OverridePhysicsAsset; // Offset: 0xc8 | Size: 0x8
	char pad_0xD0[0x98]; // Offset: 0xd0 | Size: 0x98
	struct FVector OverrideWorldGravity; // Offset: 0x168 | Size: 0xc
	struct FVector ExternalForce; // Offset: 0x174 | Size: 0xc
	struct FVector ComponentLinearAccScale; // Offset: 0x180 | Size: 0xc
	struct FVector ComponentLinearVelScale; // Offset: 0x18c | Size: 0xc
	struct FVector ComponentAppliedLinearAccClamp; // Offset: 0x198 | Size: 0xc
	float CachedBoundsScale; // Offset: 0x1a4 | Size: 0x4
	struct FBoneReference BaseBoneRef; // Offset: 0x1a8 | Size: 0x10
	enum class ECollisionChannel OverlapChannel; // Offset: 0x1b8 | Size: 0x1
	enum class ESimulationSpace SimulationSpace; // Offset: 0x1b9 | Size: 0x1
	bool bForceDisableCollisionBetweenConstraintBodies; // Offset: 0x1ba | Size: 0x1
	char pad_0x1BB[0x1]; // Offset: 0x1bb | Size: 0x1
	char bEnableWorldGeometry : 1; // Offset: 0x1bc | Size: 0x1
	char bOverrideWorldGravity : 1; // Offset: 0x1bc | Size: 0x1
	char bTransferBoneVelocities : 1; // Offset: 0x1bc | Size: 0x1
	char bFreezeIncomingPoseOnStart : 1; // Offset: 0x1bc | Size: 0x1
	char bClampLinearTranslationLimitToRefPose : 1; // Offset: 0x1bc | Size: 0x1
	char pad_0x1BC_5 : 3; // Offset: 0x1bc | Size: 0x1
	char pad_0x1BD[0x3]; // Offset: 0x1bd | Size: 0x3
	struct FSolverIterations OverrideSolverIterations; // Offset: 0x1c0 | Size: 0x18
	char pad_0x1D8[0x3b8]; // Offset: 0x1d8 | Size: 0x3b8
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_RigidBody_Chaos
// Inherited Bytes: 0xc8 | Struct Size: 0x580
struct FAnimNode_RigidBody_Chaos : FAnimNode_SkeletalControlBase {
	// Fields
	struct UPhysicsAsset* OverridePhysicsAsset; // Offset: 0xc8 | Size: 0x8
	struct FVector OverrideWorldGravity; // Offset: 0xd0 | Size: 0xc
	struct FVector ExternalForce; // Offset: 0xdc | Size: 0xc
	struct FVector ComponentLinearAccScale; // Offset: 0xe8 | Size: 0xc
	struct FVector ComponentLinearVelScale; // Offset: 0xf4 | Size: 0xc
	struct FVector ComponentAppliedLinearAccClamp; // Offset: 0x100 | Size: 0xc
	float CachedBoundsScale; // Offset: 0x10c | Size: 0x4
	struct FBoneReference BaseBoneRef; // Offset: 0x110 | Size: 0x10
	enum class ECollisionChannel OverlapChannel; // Offset: 0x120 | Size: 0x1
	enum class ESimulationSpace SimulationSpace; // Offset: 0x121 | Size: 0x1
	bool bForceDisableCollisionBetweenConstraintBodies; // Offset: 0x122 | Size: 0x1
	char bEnableWorldGeometry : 1; // Offset: 0x123 | Size: 0x1
	char bOverrideWorldGravity : 1; // Offset: 0x123 | Size: 0x1
	char bTransferBoneVelocities : 1; // Offset: 0x123 | Size: 0x1
	char bFreezeIncomingPoseOnStart : 1; // Offset: 0x123 | Size: 0x1
	char bClampLinearTranslationLimitToRefPose : 1; // Offset: 0x123 | Size: 0x1
	char pad_0x123_5 : 3; // Offset: 0x123 | Size: 0x1
	struct FSolverIterations OverrideSolverIterations; // Offset: 0x124 | Size: 0x18
	char pad_0x13C[0x444]; // Offset: 0x13c | Size: 0x444
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_RotateRootBone
// Inherited Bytes: 0x10 | Struct Size: 0xa0
struct FAnimNode_RotateRootBone : FAnimNode_Base {
	// Fields
	struct FPoseLink BasePose; // Offset: 0x10 | Size: 0x10
	float Pitch; // Offset: 0x20 | Size: 0x4
	float Yaw; // Offset: 0x24 | Size: 0x4
	struct FInputScaleBiasClamp PitchScaleBiasClamp; // Offset: 0x28 | Size: 0x30
	struct FInputScaleBiasClamp YawScaleBiasClamp; // Offset: 0x58 | Size: 0x30
	struct FRotator MeshToComponent; // Offset: 0x88 | Size: 0xc
	char pad_0x94[0xc]; // Offset: 0x94 | Size: 0xc
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_RotationMultiplier
// Inherited Bytes: 0xc8 | Struct Size: 0xf0
struct FAnimNode_RotationMultiplier : FAnimNode_SkeletalControlBase {
	// Fields
	struct FBoneReference TargetBone; // Offset: 0xc8 | Size: 0x10
	struct FBoneReference SourceBone; // Offset: 0xd8 | Size: 0x10
	float Multiplier; // Offset: 0xe8 | Size: 0x4
	enum class EBoneAxis RotationAxisToRefer; // Offset: 0xec | Size: 0x1
	bool bIsAdditive; // Offset: 0xed | Size: 0x1
	char pad_0xEE[0x2]; // Offset: 0xee | Size: 0x2
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_RotationOffsetBlendSpace
// Inherited Bytes: 0xe0 | Struct Size: 0x188
struct FAnimNode_RotationOffsetBlendSpace : FAnimNode_BlendSpacePlayer {
	// Fields
	struct FPoseLink BasePose; // Offset: 0xe0 | Size: 0x10
	int32_t LODThreshold; // Offset: 0xf0 | Size: 0x4
	float Alpha; // Offset: 0xf4 | Size: 0x4
	struct FInputScaleBias AlphaScaleBias; // Offset: 0xf8 | Size: 0x8
	struct FInputAlphaBoolBlend AlphaBoolBlend; // Offset: 0x100 | Size: 0x48
	struct FName AlphaCurveName; // Offset: 0x148 | Size: 0x8
	struct FInputScaleBiasClamp AlphaScaleBiasClamp; // Offset: 0x150 | Size: 0x30
	char pad_0x180[0x4]; // Offset: 0x180 | Size: 0x4
	enum class EAnimAlphaInputType AlphaInputType; // Offset: 0x184 | Size: 0x1
	bool bAlphaBoolEnabled; // Offset: 0x185 | Size: 0x1
	char pad_0x186[0x2]; // Offset: 0x186 | Size: 0x2
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_ScaleChainLength
// Inherited Bytes: 0x10 | Struct Size: 0x78
struct FAnimNode_ScaleChainLength : FAnimNode_Base {
	// Fields
	struct FPoseLink InputPose; // Offset: 0x10 | Size: 0x10
	float DefaultChainLength; // Offset: 0x20 | Size: 0x4
	struct FBoneReference ChainStartBone; // Offset: 0x24 | Size: 0x10
	struct FBoneReference ChainEndBone; // Offset: 0x34 | Size: 0x10
	struct FVector TargetLocation; // Offset: 0x44 | Size: 0xc
	float Alpha; // Offset: 0x50 | Size: 0x4
	char pad_0x54[0x4]; // Offset: 0x54 | Size: 0x4
	struct FInputScaleBias AlphaScaleBias; // Offset: 0x58 | Size: 0x8
	enum class EScaleChainInitialLength ChainInitialLength; // Offset: 0x60 | Size: 0x1
	char pad_0x61[0x17]; // Offset: 0x61 | Size: 0x17
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_SequenceEvaluator
// Inherited Bytes: 0x30 | Struct Size: 0x48
struct FAnimNode_SequenceEvaluator : FAnimNode_AssetPlayerBase {
	// Fields
	struct UAnimSequenceBase* Sequence; // Offset: 0x30 | Size: 0x8
	float ExplicitTime; // Offset: 0x38 | Size: 0x4
	bool bShouldLoop; // Offset: 0x3c | Size: 0x1
	bool bTeleportToExplicitTime; // Offset: 0x3d | Size: 0x1
	enum class ESequenceEvalReinit ReinitializationBehavior; // Offset: 0x3e | Size: 0x1
	char pad_0x3F[0x1]; // Offset: 0x3f | Size: 0x1
	float StartPosition; // Offset: 0x40 | Size: 0x4
	char pad_0x44[0x4]; // Offset: 0x44 | Size: 0x4
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_Slot
// Inherited Bytes: 0x10 | Struct Size: 0x48
struct FAnimNode_Slot : FAnimNode_Base {
	// Fields
	struct FPoseLink Source; // Offset: 0x10 | Size: 0x10
	struct FName SlotName; // Offset: 0x20 | Size: 0x8
	bool bAlwaysUpdateSourcePose; // Offset: 0x28 | Size: 0x1
	char pad_0x29[0x1f]; // Offset: 0x29 | Size: 0x1f
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_SplineIK
// Inherited Bytes: 0xc8 | Struct Size: 0x260
struct FAnimNode_SplineIK : FAnimNode_SkeletalControlBase {
	// Fields
	struct FBoneReference StartBone; // Offset: 0xc8 | Size: 0x10
	struct FBoneReference EndBone; // Offset: 0xd8 | Size: 0x10
	enum class ESplineBoneAxis BoneAxis; // Offset: 0xe8 | Size: 0x1
	bool bAutoCalculateSpline; // Offset: 0xe9 | Size: 0x1
	char pad_0xEA[0x2]; // Offset: 0xea | Size: 0x2
	int32_t PointCount; // Offset: 0xec | Size: 0x4
	struct TArray<struct FTransform> ControlPoints; // Offset: 0xf0 | Size: 0x10
	float Roll; // Offset: 0x100 | Size: 0x4
	float TwistStart; // Offset: 0x104 | Size: 0x4
	float TwistEnd; // Offset: 0x108 | Size: 0x4
	char pad_0x10C[0x4]; // Offset: 0x10c | Size: 0x4
	struct FAlphaBlend TwistBlend; // Offset: 0x110 | Size: 0x30
	float Stretch; // Offset: 0x140 | Size: 0x4
	float Offset; // Offset: 0x144 | Size: 0x4
	char pad_0x148[0x118]; // Offset: 0x148 | Size: 0x118
};

// Object: ScriptStruct AnimGraphRuntime.SplineIKCachedBoneData
// Inherited Bytes: 0x0 | Struct Size: 0x14
struct FSplineIKCachedBoneData {
	// Fields
	struct FBoneReference Bone; // Offset: 0x0 | Size: 0x10
	int32_t RefSkeletonIndex; // Offset: 0x10 | Size: 0x4
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_SpringBone
// Inherited Bytes: 0xc8 | Struct Size: 0x128
struct FAnimNode_SpringBone : FAnimNode_SkeletalControlBase {
	// Fields
	struct FBoneReference SpringBone; // Offset: 0xc8 | Size: 0x10
	float MaxDisplacement; // Offset: 0xd8 | Size: 0x4
	float SpringStiffness; // Offset: 0xdc | Size: 0x4
	float SpringDamping; // Offset: 0xe0 | Size: 0x4
	float ErrorResetThresh; // Offset: 0xe4 | Size: 0x4
	char pad_0xE8[0x3c]; // Offset: 0xe8 | Size: 0x3c
	char bLimitDisplacement : 1; // Offset: 0x124 | Size: 0x1
	char bTranslateX : 1; // Offset: 0x124 | Size: 0x1
	char bTranslateY : 1; // Offset: 0x124 | Size: 0x1
	char bTranslateZ : 1; // Offset: 0x124 | Size: 0x1
	char bRotateX : 1; // Offset: 0x124 | Size: 0x1
	char bRotateY : 1; // Offset: 0x124 | Size: 0x1
	char bRotateZ : 1; // Offset: 0x124 | Size: 0x1
	char pad_0x124_7 : 1; // Offset: 0x124 | Size: 0x1
	char pad_0x125[0x3]; // Offset: 0x125 | Size: 0x3
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_StateResult
// Inherited Bytes: 0x30 | Struct Size: 0x30
struct FAnimNode_StateResult : FAnimNode_Root {
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_Trail
// Inherited Bytes: 0xc8 | Struct Size: 0x260
struct FAnimNode_Trail : FAnimNode_SkeletalControlBase {
	// Fields
	char pad_0xC8[0x38]; // Offset: 0xc8 | Size: 0x38
	struct FBoneReference TrailBone; // Offset: 0x100 | Size: 0x10
	int32_t ChainLength; // Offset: 0x110 | Size: 0x4
	enum class EAxis ChainBoneAxis; // Offset: 0x114 | Size: 0x1
	char bInvertChainBoneAxis : 1; // Offset: 0x115 | Size: 0x1
	char bLimitStretch : 1; // Offset: 0x115 | Size: 0x1
	char bLimitRotation : 1; // Offset: 0x115 | Size: 0x1
	char bUsePlanarLimit : 1; // Offset: 0x115 | Size: 0x1
	char bActorSpaceFakeVel : 1; // Offset: 0x115 | Size: 0x1
	char bReorientParentToChild : 1; // Offset: 0x115 | Size: 0x1
	char pad_0x115_6 : 2; // Offset: 0x115 | Size: 0x1
	char pad_0x116[0x2]; // Offset: 0x116 | Size: 0x2
	float MaxDeltaTime; // Offset: 0x118 | Size: 0x4
	float RelaxationSpeedScale; // Offset: 0x11c | Size: 0x4
	struct FRuntimeFloatCurve TrailRelaxationSpeed; // Offset: 0x120 | Size: 0x88
	struct FInputScaleBiasClamp RelaxationSpeedScaleInputProcessor; // Offset: 0x1a8 | Size: 0x30
	struct TArray<struct FRotationLimit> RotationLimits; // Offset: 0x1d8 | Size: 0x10
	struct TArray<struct FVector> RotationOffsets; // Offset: 0x1e8 | Size: 0x10
	struct TArray<struct FAnimPhysPlanarLimit> PlanarLimits; // Offset: 0x1f8 | Size: 0x10
	float StretchLimit; // Offset: 0x208 | Size: 0x4
	struct FVector FakeVelocity; // Offset: 0x20c | Size: 0xc
	struct FBoneReference BaseJoint; // Offset: 0x218 | Size: 0x10
	float LastBoneRotationAnimAlphaBlend; // Offset: 0x228 | Size: 0x4
	char pad_0x22C[0x34]; // Offset: 0x22c | Size: 0x34
};

// Object: ScriptStruct AnimGraphRuntime.RotationLimit
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FRotationLimit {
	// Fields
	struct FVector LimitMin; // Offset: 0x0 | Size: 0xc
	struct FVector LimitMax; // Offset: 0xc | Size: 0xc
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_TwistCorrectiveNode
// Inherited Bytes: 0xc8 | Struct Size: 0x138
struct FAnimNode_TwistCorrectiveNode : FAnimNode_SkeletalControlBase {
	// Fields
	struct FReferenceBoneFrame BaseFrame; // Offset: 0xc8 | Size: 0x20
	struct FReferenceBoneFrame TwistFrame; // Offset: 0xe8 | Size: 0x20
	struct FAxis TwistPlaneNormalAxis; // Offset: 0x108 | Size: 0x10
	float RangeMax; // Offset: 0x118 | Size: 0x4
	float RemappedMin; // Offset: 0x11c | Size: 0x4
	float RemappedMax; // Offset: 0x120 | Size: 0x4
	struct FAnimCurveParam Curve; // Offset: 0x124 | Size: 0xc
	char pad_0x130[0x8]; // Offset: 0x130 | Size: 0x8
};

// Object: ScriptStruct AnimGraphRuntime.ReferenceBoneFrame
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FReferenceBoneFrame {
	// Fields
	struct FBoneReference Bone; // Offset: 0x0 | Size: 0x10
	struct FAxis Axis; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_TwoBoneIK
// Inherited Bytes: 0xc8 | Struct Size: 0x1e0
struct FAnimNode_TwoBoneIK : FAnimNode_SkeletalControlBase {
	// Fields
	struct FBoneReference IKBone; // Offset: 0xc8 | Size: 0x10
	float StartStretchRatio; // Offset: 0xd8 | Size: 0x4
	float MaxStretchScale; // Offset: 0xdc | Size: 0x4
	struct FVector EffectorLocation; // Offset: 0xe0 | Size: 0xc
	char pad_0xEC[0x4]; // Offset: 0xec | Size: 0x4
	struct FBoneSocketTarget EffectorTarget; // Offset: 0xf0 | Size: 0x60
	struct FVector JointTargetLocation; // Offset: 0x150 | Size: 0xc
	char pad_0x15C[0x4]; // Offset: 0x15c | Size: 0x4
	struct FBoneSocketTarget JointTarget; // Offset: 0x160 | Size: 0x60
	struct FAxis TwistAxis; // Offset: 0x1c0 | Size: 0x10
	enum class EBoneControlSpace EffectorLocationSpace; // Offset: 0x1d0 | Size: 0x1
	enum class EBoneControlSpace JointTargetLocationSpace; // Offset: 0x1d1 | Size: 0x1
	char bAllowStretching : 1; // Offset: 0x1d2 | Size: 0x1
	char bTakeRotationFromEffectorSpace : 1; // Offset: 0x1d2 | Size: 0x1
	char bMaintainEffectorRelRot : 1; // Offset: 0x1d2 | Size: 0x1
	char bAllowTwist : 1; // Offset: 0x1d2 | Size: 0x1
	char pad_0x1D2_4 : 4; // Offset: 0x1d2 | Size: 0x1
	char pad_0x1D3[0xd]; // Offset: 0x1d3 | Size: 0xd
};

// Object: ScriptStruct AnimGraphRuntime.AnimNode_TwoWayBlend
// Inherited Bytes: 0x10 | Struct Size: 0xc8
struct FAnimNode_TwoWayBlend : FAnimNode_Base {
	// Fields
	struct FPoseLink A; // Offset: 0x10 | Size: 0x10
	struct FPoseLink B; // Offset: 0x20 | Size: 0x10
	enum class EAnimAlphaInputType AlphaInputType; // Offset: 0x30 | Size: 0x1
	char bAlphaBoolEnabled : 1; // Offset: 0x31 | Size: 0x1
	char pad_0x31_1 : 2; // Offset: 0x31 | Size: 0x1
	char bResetChildOnActivation : 1; // Offset: 0x31 | Size: 0x1
	char pad_0x31_4 : 4; // Offset: 0x31 | Size: 0x1
	char pad_0x32[0x2]; // Offset: 0x32 | Size: 0x2
	float Alpha; // Offset: 0x34 | Size: 0x4
	struct FInputScaleBias AlphaScaleBias; // Offset: 0x38 | Size: 0x8
	struct FInputAlphaBoolBlend AlphaBoolBlend; // Offset: 0x40 | Size: 0x48
	struct FName AlphaCurveName; // Offset: 0x88 | Size: 0x8
	struct FInputScaleBiasClamp AlphaScaleBiasClamp; // Offset: 0x90 | Size: 0x30
	int32_t LODThreshold; // Offset: 0xc0 | Size: 0x4
	char pad_0xC4[0x4]; // Offset: 0xc4 | Size: 0x4
};

// Object: ScriptStruct AnimGraphRuntime.PositionHistory
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FPositionHistory {
	// Fields
	struct TArray<struct FVector> Positions; // Offset: 0x0 | Size: 0x10
	float Range; // Offset: 0x10 | Size: 0x4
	char pad_0x14[0x1c]; // Offset: 0x14 | Size: 0x1c
};

// Object: ScriptStruct AnimGraphRuntime.RBFEntry
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FRBFEntry {
	// Fields
	struct TArray<float> Values; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct AnimGraphRuntime.RBFTarget
// Inherited Bytes: 0x10 | Struct Size: 0xa0
struct FRBFTarget : FRBFEntry {
	// Fields
	float ScaleFactor; // Offset: 0x10 | Size: 0x4
	bool bApplyCustomCurve; // Offset: 0x14 | Size: 0x1
	char pad_0x15[0x3]; // Offset: 0x15 | Size: 0x3
	struct FRichCurve CustomCurve; // Offset: 0x18 | Size: 0x80
	enum class ERBFDistanceMethod DistanceMethod; // Offset: 0x98 | Size: 0x1
	enum class ERBFFunctionType FunctionType; // Offset: 0x99 | Size: 0x1
	char pad_0x9A[0x6]; // Offset: 0x9a | Size: 0x6
};

