#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class AnimationCore.AnimationDataSourceRegistry
// Inherited Bytes: 0x28 | Struct Size: 0x78
struct UAnimationDataSourceRegistry : UObject {
	// Fields
	struct TMap<struct FName, struct TWeakObjectPtr<struct UObject>> DataSources; // Offset: 0x28 | Size: 0x50
};

