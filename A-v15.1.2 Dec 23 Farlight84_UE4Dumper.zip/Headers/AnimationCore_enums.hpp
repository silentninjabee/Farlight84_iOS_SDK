#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Enum AnimationCore.ETransformConstraintType
enum class ETransformConstraintType : uint8_t {
	Translation = 0,
	Rotation = 1,
	Scale = 2,
	Parent = 3,
	ETransformConstraintType_MAX = 4
};

// Object: Enum AnimationCore.EConstraintType
enum class EConstraintType : uint8_t {
	Transform = 0,
	Aim = 1,
	MAX = 2
};

