#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct AnimationCore.NodeHierarchyWithUserData
// Inherited Bytes: 0x0 | Struct Size: 0x78
struct FNodeHierarchyWithUserData {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
	struct FNodeHierarchyData Hierarchy; // Offset: 0x8 | Size: 0x70
};

// Object: ScriptStruct AnimationCore.NodeHierarchyData
// Inherited Bytes: 0x0 | Struct Size: 0x70
struct FNodeHierarchyData {
	// Fields
	struct TArray<struct FNodeObject> Nodes; // Offset: 0x0 | Size: 0x10
	struct TArray<struct FTransform> Transforms; // Offset: 0x10 | Size: 0x10
	struct TMap<struct FName, int32_t> NodeNameToIndexMapping; // Offset: 0x20 | Size: 0x50
};

// Object: ScriptStruct AnimationCore.NodeObject
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FNodeObject {
	// Fields
	struct FName Name; // Offset: 0x0 | Size: 0x8
	struct FName ParentName; // Offset: 0x8 | Size: 0x8
};

// Object: ScriptStruct AnimationCore.TransformConstraint
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FTransformConstraint {
	// Fields
	struct FConstraintDescription Operator; // Offset: 0x0 | Size: 0xd
	char pad_0xD[0x3]; // Offset: 0xd | Size: 0x3
	struct FName SourceNode; // Offset: 0x10 | Size: 0x8
	struct FName TargetNode; // Offset: 0x18 | Size: 0x8
	float Weight; // Offset: 0x20 | Size: 0x4
	bool bMaintainOffset; // Offset: 0x24 | Size: 0x1
	char pad_0x25[0x3]; // Offset: 0x25 | Size: 0x3
};

// Object: ScriptStruct AnimationCore.ConstraintDescription
// Inherited Bytes: 0x0 | Struct Size: 0xd
struct FConstraintDescription {
	// Fields
	bool bTranslation; // Offset: 0x0 | Size: 0x1
	bool bRotation; // Offset: 0x1 | Size: 0x1
	bool bScale; // Offset: 0x2 | Size: 0x1
	bool bParent; // Offset: 0x3 | Size: 0x1
	struct FFilterOptionPerAxis TranslationAxes; // Offset: 0x4 | Size: 0x3
	struct FFilterOptionPerAxis RotationAxes; // Offset: 0x7 | Size: 0x3
	struct FFilterOptionPerAxis ScaleAxes; // Offset: 0xa | Size: 0x3
};

// Object: ScriptStruct AnimationCore.FilterOptionPerAxis
// Inherited Bytes: 0x0 | Struct Size: 0x3
struct FFilterOptionPerAxis {
	// Fields
	bool bX; // Offset: 0x0 | Size: 0x1
	bool bY; // Offset: 0x1 | Size: 0x1
	bool bZ; // Offset: 0x2 | Size: 0x1
};

// Object: ScriptStruct AnimationCore.ConstraintOffset
// Inherited Bytes: 0x0 | Struct Size: 0x60
struct FConstraintOffset {
	// Fields
	struct FVector Translation; // Offset: 0x0 | Size: 0xc
	char pad_0xC[0x4]; // Offset: 0xc | Size: 0x4
	struct FQuat Rotation; // Offset: 0x10 | Size: 0x10
	struct FVector Scale; // Offset: 0x20 | Size: 0xc
	char pad_0x2C[0x4]; // Offset: 0x2c | Size: 0x4
	struct FTransform Parent; // Offset: 0x30 | Size: 0x30
};

// Object: ScriptStruct AnimationCore.TransformFilter
// Inherited Bytes: 0x0 | Struct Size: 0x9
struct FTransformFilter {
	// Fields
	struct FFilterOptionPerAxis TranslationFilter; // Offset: 0x0 | Size: 0x3
	struct FFilterOptionPerAxis RotationFilter; // Offset: 0x3 | Size: 0x3
	struct FFilterOptionPerAxis ScaleFilter; // Offset: 0x6 | Size: 0x3
};

// Object: ScriptStruct AnimationCore.CCDIKChainLink
// Inherited Bytes: 0x0 | Struct Size: 0x80
struct FCCDIKChainLink {
	// Fields
	char pad_0x0[0x80]; // Offset: 0x0 | Size: 0x80
};

// Object: ScriptStruct AnimationCore.EulerTransform
// Inherited Bytes: 0x0 | Struct Size: 0x24
struct FEulerTransform {
	// Fields
	struct FVector Location; // Offset: 0x0 | Size: 0xc
	struct FRotator Rotation; // Offset: 0xc | Size: 0xc
	struct FVector Scale; // Offset: 0x18 | Size: 0xc
};

// Object: ScriptStruct AnimationCore.FABRIKChainLink
// Inherited Bytes: 0x0 | Struct Size: 0x38
struct FFABRIKChainLink {
	// Fields
	char pad_0x0[0x38]; // Offset: 0x0 | Size: 0x38
};

// Object: ScriptStruct AnimationCore.ConstraintData
// Inherited Bytes: 0x0 | Struct Size: 0x80
struct FConstraintData {
	// Fields
	struct FConstraintDescriptor Constraint; // Offset: 0x0 | Size: 0x10
	float Weight; // Offset: 0x10 | Size: 0x4
	bool bMaintainOffset; // Offset: 0x14 | Size: 0x1
	char pad_0x15[0xb]; // Offset: 0x15 | Size: 0xb
	struct FTransform Offset; // Offset: 0x20 | Size: 0x30
	struct FTransform CurrentTransform; // Offset: 0x50 | Size: 0x30
};

// Object: ScriptStruct AnimationCore.ConstraintDescriptor
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FConstraintDescriptor {
	// Fields
	enum class EConstraintType Type; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0xf]; // Offset: 0x1 | Size: 0xf
};

// Object: ScriptStruct AnimationCore.Axis
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FAxis {
	// Fields
	struct FVector Axis; // Offset: 0x0 | Size: 0xc
	bool bInLocalSpace; // Offset: 0xc | Size: 0x1
	char pad_0xD[0x3]; // Offset: 0xd | Size: 0x3
};

// Object: ScriptStruct AnimationCore.ConstraintDescriptionEx
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FConstraintDescriptionEx {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
	struct FFilterOptionPerAxis AxesFilterOption; // Offset: 0x8 | Size: 0x3
	char pad_0xB[0x5]; // Offset: 0xb | Size: 0x5
};

// Object: ScriptStruct AnimationCore.AimConstraintDescription
// Inherited Bytes: 0x10 | Struct Size: 0x40
struct FAimConstraintDescription : FConstraintDescriptionEx {
	// Fields
	struct FAxis LookAt_Axis; // Offset: 0xc | Size: 0x10
	struct FAxis LookUp_Axis; // Offset: 0x1c | Size: 0x10
	bool bUseLookUp; // Offset: 0x2c | Size: 0x1
	struct FVector LookUpTarget; // Offset: 0x30 | Size: 0xc
	char pad_0x3D[0x3]; // Offset: 0x3d | Size: 0x3
};

// Object: ScriptStruct AnimationCore.TransformConstraintDescription
// Inherited Bytes: 0x10 | Struct Size: 0x10
struct FTransformConstraintDescription : FConstraintDescriptionEx {
	// Fields
	enum class ETransformConstraintType TransformType; // Offset: 0xb | Size: 0x1
};

// Object: ScriptStruct AnimationCore.NodeChain
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FNodeChain {
	// Fields
	struct TArray<struct FName> Nodes; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct AnimationCore.TransformNoScale
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FTransformNoScale {
	// Fields
	struct FVector Location; // Offset: 0x0 | Size: 0xc
	char pad_0xC[0x4]; // Offset: 0xc | Size: 0x4
	struct FQuat Rotation; // Offset: 0x10 | Size: 0x10
};

