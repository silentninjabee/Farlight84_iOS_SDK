#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class AnimationSharing.AnimSharingStateInstance
// Inherited Bytes: 0x270 | Struct Size: 0x290
struct UAnimSharingStateInstance : UAnimInstance {
	// Fields
	struct UAnimSequence* AnimationToPlay; // Offset: 0x268 | Size: 0x8
	float PermutationTimeOffset; // Offset: 0x270 | Size: 0x4
	float PlayRate; // Offset: 0x274 | Size: 0x4
	bool bStateBool; // Offset: 0x278 | Size: 0x1
	struct UAnimSharingInstance* Instance; // Offset: 0x280 | Size: 0x8
	char pad_0x289[0x7]; // Offset: 0x289 | Size: 0x7

	// Functions

	// Object: Function AnimationSharing.AnimSharingStateInstance.GetInstancedActors
	// Flags: [Final|Native|Protected|HasOutParms|BlueprintCallable]
	// Offset: 0x1023ea0e8
	// Return & Params: [ Num(1) Size(0x10) ]
	void GetInstancedActors(struct TArray<struct AActor*>& Actors);
};

// Object: Class AnimationSharing.AnimSharingTransitionInstance
// Inherited Bytes: 0x270 | Struct Size: 0x280
struct UAnimSharingTransitionInstance : UAnimInstance {
	// Fields
	struct TWeakObjectPtr<struct USkeletalMeshComponent> FromComponent; // Offset: 0x268 | Size: 0x8
	struct TWeakObjectPtr<struct USkeletalMeshComponent> ToComponent; // Offset: 0x270 | Size: 0x8
	float BlendTime; // Offset: 0x278 | Size: 0x4
	bool bBlendBool; // Offset: 0x27c | Size: 0x1
};

// Object: Class AnimationSharing.AnimSharingAdditiveInstance
// Inherited Bytes: 0x270 | Struct Size: 0x280
struct UAnimSharingAdditiveInstance : UAnimInstance {
	// Fields
	struct TWeakObjectPtr<struct USkeletalMeshComponent> BaseComponent; // Offset: 0x268 | Size: 0x8
	struct TWeakObjectPtr<struct UAnimSequence> AdditiveAnimation; // Offset: 0x270 | Size: 0x8
	float Alpha; // Offset: 0x278 | Size: 0x4
	bool bStateBool; // Offset: 0x27c | Size: 0x1
};

// Object: Class AnimationSharing.AnimSharingInstance
// Inherited Bytes: 0x28 | Struct Size: 0x138
struct UAnimSharingInstance : UObject {
	// Fields
	struct TArray<struct AActor*> RegisteredActors; // Offset: 0x28 | Size: 0x10
	char pad_0x38[0x70]; // Offset: 0x38 | Size: 0x70
	struct UAnimationSharingStateProcessor* StateProcessor; // Offset: 0xa8 | Size: 0x8
	char pad_0xB0[0x38]; // Offset: 0xb0 | Size: 0x38
	struct TArray<struct UAnimSequence*> UsedAnimationSequences; // Offset: 0xe8 | Size: 0x10
	char pad_0xF8[0x10]; // Offset: 0xf8 | Size: 0x10
	struct UEnum* StateEnum; // Offset: 0x108 | Size: 0x8
	struct AActor* SharingActor; // Offset: 0x110 | Size: 0x8
	char pad_0x118[0x20]; // Offset: 0x118 | Size: 0x20
};

// Object: Class AnimationSharing.AnimationSharingManager
// Inherited Bytes: 0x28 | Struct Size: 0x88
struct UAnimationSharingManager : UObject {
	// Fields
	struct TArray<struct USkeleton*> Skeletons; // Offset: 0x28 | Size: 0x10
	struct TArray<struct UAnimSharingInstance*> PerSkeletonData; // Offset: 0x38 | Size: 0x10
	char pad_0x48[0x40]; // Offset: 0x48 | Size: 0x40

	// Functions

	// Object: Function AnimationSharing.AnimationSharingManager.RegisterActorWithSkeletonBP
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1023eaf48
	// Return & Params: [ Num(2) Size(0x10) ]
	void RegisterActorWithSkeletonBP(struct AActor* InActor, struct USkeleton* SharingSkeleton);

	// Object: Function AnimationSharing.AnimationSharingManager.GetAnimationSharingManager
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1023eb0d8
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UAnimationSharingManager* GetAnimationSharingManager(struct UObject* WorldContextObject);

	// Object: Function AnimationSharing.AnimationSharingManager.CreateAnimationSharingManager
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1023eb010
	// Return & Params: [ Num(3) Size(0x11) ]
	bool CreateAnimationSharingManager(struct UObject* WorldContextObject, struct UAnimationSharingSetup* Setup);

	// Object: Function AnimationSharing.AnimationSharingManager.AnimationSharingEnabled
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1023eaf14
	// Return & Params: [ Num(1) Size(0x1) ]
	bool AnimationSharingEnabled();
};

// Object: Class AnimationSharing.AnimationSharingSetup
// Inherited Bytes: 0x28 | Struct Size: 0x48
struct UAnimationSharingSetup : UObject {
	// Fields
	struct TArray<struct FPerSkeletonAnimationSharingSetup> SkeletonSetups; // Offset: 0x28 | Size: 0x10
	struct FAnimationSharingScalability ScalabilitySettings; // Offset: 0x38 | Size: 0x10
};

// Object: Class AnimationSharing.AnimationSharingStateProcessor
// Inherited Bytes: 0x28 | Struct Size: 0x50
struct UAnimationSharingStateProcessor : UObject {
	// Fields
	struct TSoftObjectPtr<UEnum> AnimationStateEnum; // Offset: 0x28 | Size: 0x28

	// Functions

	// Object: Function AnimationSharing.AnimationSharingStateProcessor.ProcessActorState
	// Flags: [Native|Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x1023ebc70
	// Return & Params: [ Num(5) Size(0x13) ]
	void ProcessActorState(int32_t& OutState, struct AActor* InActor, char CurrentState, char OnDemandState, bool& bShouldProcess);

	// Object: Function AnimationSharing.AnimationSharingStateProcessor.GetAnimationStateEnum
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x1023ebc34
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UEnum* GetAnimationStateEnum();
};

