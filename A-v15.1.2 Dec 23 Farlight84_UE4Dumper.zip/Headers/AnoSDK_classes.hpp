#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class AnoSDK.AnoSDK
// Inherited Bytes: 0x28 | Struct Size: 0x88
struct UAnoSDK : UObject {
	// Fields
	struct FMulticastInlineDelegate OnAnoRecvAntiData; // Offset: 0x28 | Size: 0x10
	char pad_0x38[0x8]; // Offset: 0x38 | Size: 0x8
	struct FMulticastInlineDelegate OnAnoSentDataToSvr; // Offset: 0x40 | Size: 0x10
	char pad_0x50[0x8]; // Offset: 0x50 | Size: 0x8
	struct FMulticastInlineDelegate OnAnoSentCoreData; // Offset: 0x58 | Size: 0x10
	char pad_0x68[0x8]; // Offset: 0x68 | Size: 0x8
	struct FMulticastInlineDelegate OnAnoSentCoreTimeData; // Offset: 0x70 | Size: 0x10
	char pad_0x80[0x8]; // Offset: 0x80 | Size: 0x8

	// Functions

	// Object: DelegateFunction AnoSDK.AnoSDK.OnAnoSentAntiData__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a48564
	// Return & Params: [ Num(1) Size(0x18) ]
	void OnAnoSentAntiData__DelegateSignature(struct FAnoSDKAntiData AntiData);

	// Object: DelegateFunction AnoSDK.AnoSDK.OnAnoRecvAntiData__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a48564
	// Return & Params: [ Num(2) Size(0x18) ]
	void OnAnoRecvAntiData__DelegateSignature(int32_t Type, struct FString AntiData);

	// Object: Function AnoSDK.AnoSDK.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10236a8e4
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UAnoSDK* GetInstance();

	// Object: Function AnoSDK.AnoSDK.DestoryInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10236a8d0
	// Return & Params: [ Num(0) Size(0x0) ]
	void DestoryInstance();

	// Object: Function AnoSDK.AnoSDK.AnoUESDKSetUserInfo
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10236a318
	// Return & Params: [ Num(2) Size(0x18) ]
	void AnoUESDKSetUserInfo(enum class ETssSDKEntryId EntryId, struct FString OpenId);

	// Object: Function AnoSDK.AnoSDK.AnoUESDKSetCSChannelDomain
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10236a690
	// Return & Params: [ Num(1) Size(0x10) ]
	void AnoUESDKSetCSChannelDomain(struct FString DomainName);

	// Object: Function AnoSDK.AnoSDK.AnoUESDKSetChannelIP
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10236a714
	// Return & Params: [ Num(1) Size(0x10) ]
	void AnoUESDKSetChannelIP(struct FString IP);

	// Object: Function AnoSDK.AnoSDK.AnoUESDKSendSDKCoreData
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10236a244
	// Return & Params: [ Num(0) Size(0x0) ]
	void AnoUESDKSendSDKCoreData();

	// Object: Function AnoSDK.AnoSDK.AnoUESDKSendDataToSvr
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10236a258
	// Return & Params: [ Num(0) Size(0x0) ]
	void AnoUESDKSendDataToSvr();

	// Object: Function AnoSDK.AnoSDK.AnoUESDKSendCoreTimeData
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10236a230
	// Return & Params: [ Num(0) Size(0x0) ]
	void AnoUESDKSendCoreTimeData();

	// Object: Function AnoSDK.AnoSDK.AnoUESDKReportThreadShutDown
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10236a1f4
	// Return & Params: [ Num(0) Size(0x0) ]
	void AnoUESDKReportThreadShutDown();

	// Object: Function AnoSDK.AnoSDK.AnoUESDKReportThreadInit
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10236a208
	// Return & Params: [ Num(0) Size(0x0) ]
	void AnoUESDKReportThreadInit();

	// Object: Function AnoSDK.AnoSDK.AnoUESDKRegistInfoListener
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10236a21c
	// Return & Params: [ Num(0) Size(0x0) ]
	void AnoUESDKRegistInfoListener();

	// Object: Function AnoSDK.AnoSDK.AnoUESDKOnResume
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10236a304
	// Return & Params: [ Num(0) Size(0x0) ]
	void AnoUESDKOnResume();

	// Object: Function AnoSDK.AnoSDK.AnoUESDKOnRecvSignature
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10236a520
	// Return & Params: [ Num(4) Size(0x28) ]
	void AnoUESDKOnRecvSignature(struct FString Name, struct FString Buf, int32_t Len, int32_t Crc);

	// Object: Function AnoSDK.AnoSDK.AnoUESDKOnRecvData
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10236a26c
	// Return & Params: [ Num(1) Size(0x10) ]
	void AnoUESDKOnRecvData(struct FString Data);

	// Object: Function AnoSDK.AnoSDK.AnoUESDKOnPause
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10236a2f0
	// Return & Params: [ Num(0) Size(0x0) ]
	void AnoUESDKOnPause();

	// Object: Function AnoSDK.AnoSDK.AnoUESDKIoctl
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10236a798
	// Return & Params: [ Num(2) Size(0x18) ]
	void AnoUESDKIoctl(int32_t Request, struct FString Cmd);

	// Object: Function AnoSDK.AnoSDK.AnoUESDKInit
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10236a450
	// Return & Params: [ Num(2) Size(0x18) ]
	void AnoUESDKInit(int32_t GameID, struct FString Appkey);
};

// Object: Class AnoSDK.AnoSDKSettings
// Inherited Bytes: 0x38 | Struct Size: 0x40
struct UAnoSDKSettings : UDeveloperSettings {
	// Fields
	bool bEnableAnoSDK; // Offset: 0x38 | Size: 0x1
	char pad_0x39[0x7]; // Offset: 0x39 | Size: 0x7
};

