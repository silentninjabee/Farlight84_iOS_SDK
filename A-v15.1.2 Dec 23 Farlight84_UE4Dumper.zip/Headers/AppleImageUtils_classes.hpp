#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class AppleImageUtils.AppleImageUtilsBaseAsyncTaskBlueprintProxy
// Inherited Bytes: 0x28 | Struct Size: 0x90
struct UAppleImageUtilsBaseAsyncTaskBlueprintProxy : UObject {
	// Fields
	char pad_0x28[0x10]; // Offset: 0x28 | Size: 0x10
	struct FMulticastInlineDelegate OnSuccess; // Offset: 0x38 | Size: 0x10
	struct FMulticastInlineDelegate OnFailure; // Offset: 0x48 | Size: 0x10
	char pad_0x58[0x10]; // Offset: 0x58 | Size: 0x10
	struct FAppleImageUtilsImageConversionResult ConversionResult; // Offset: 0x68 | Size: 0x20
	char pad_0x88[0x8]; // Offset: 0x88 | Size: 0x8

	// Functions

	// Object: Function AppleImageUtils.AppleImageUtilsBaseAsyncTaskBlueprintProxy.CreateProxyObjectForConvertToTIFF
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102539a50
	// Return & Params: [ Num(6) Size(0x20) ]
	struct UAppleImageUtilsBaseAsyncTaskBlueprintProxy* CreateProxyObjectForConvertToTIFF(struct UTexture* SourceImage, bool bWantColor, bool bUseGpu, float Scale, enum class ETextureRotationDirection Rotate);

	// Object: Function AppleImageUtils.AppleImageUtilsBaseAsyncTaskBlueprintProxy.CreateProxyObjectForConvertToPNG
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102539880
	// Return & Params: [ Num(6) Size(0x20) ]
	struct UAppleImageUtilsBaseAsyncTaskBlueprintProxy* CreateProxyObjectForConvertToPNG(struct UTexture* SourceImage, bool bWantColor, bool bUseGpu, float Scale, enum class ETextureRotationDirection Rotate);

	// Object: Function AppleImageUtils.AppleImageUtilsBaseAsyncTaskBlueprintProxy.CreateProxyObjectForConvertToJPEG
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102539e3c
	// Return & Params: [ Num(7) Size(0x20) ]
	struct UAppleImageUtilsBaseAsyncTaskBlueprintProxy* CreateProxyObjectForConvertToJPEG(struct UTexture* SourceImage, int32_t Quality, bool bWantColor, bool bUseGpu, float Scale, enum class ETextureRotationDirection Rotate);

	// Object: Function AppleImageUtils.AppleImageUtilsBaseAsyncTaskBlueprintProxy.CreateProxyObjectForConvertToHEIF
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102539c20
	// Return & Params: [ Num(7) Size(0x20) ]
	struct UAppleImageUtilsBaseAsyncTaskBlueprintProxy* CreateProxyObjectForConvertToHEIF(struct UTexture* SourceImage, int32_t Quality, bool bWantColor, bool bUseGpu, float Scale, enum class ETextureRotationDirection Rotate);
};

// Object: Class AppleImageUtils.AppleImageInterface
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UAppleImageInterface : UInterface {
};

