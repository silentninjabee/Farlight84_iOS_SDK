#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class AssetRegistry.AssetRegistryImpl
// Inherited Bytes: 0x28 | Struct Size: 0x778
struct UAssetRegistryImpl : UObject {
	// Fields
	char pad_0x28[0x750]; // Offset: 0x28 | Size: 0x750
};

// Object: Class AssetRegistry.AssetRegistryHelpers
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UAssetRegistryHelpers : UObject {
	// Functions

	// Object: Function AssetRegistry.AssetRegistryHelpers.ToSoftObjectPath
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x104b46fcc
	// Return & Params: [ Num(2) Size(0x68) ]
	struct FSoftObjectPath ToSoftObjectPath(struct FAssetData& InAssetData);

	// Object: Function AssetRegistry.AssetRegistryHelpers.SetFilterTagsAndValues
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x104b46748
	// Return & Params: [ Num(3) Size(0x1e0) ]
	struct FARFilter SetFilterTagsAndValues(struct FARFilter& InFilter, struct TArray<struct FTagAndValue>& InTagsAndValues);

	// Object: Function AssetRegistry.AssetRegistryHelpers.IsValid
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x104b47434
	// Return & Params: [ Num(2) Size(0x51) ]
	bool IsValid(struct FAssetData& InAssetData);

	// Object: Function AssetRegistry.AssetRegistryHelpers.IsUAsset
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x104b47338
	// Return & Params: [ Num(2) Size(0x51) ]
	bool IsUAsset(struct FAssetData& InAssetData);

	// Object: Function AssetRegistry.AssetRegistryHelpers.IsRedirector
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x104b4723c
	// Return & Params: [ Num(2) Size(0x51) ]
	bool IsRedirector(struct FAssetData& InAssetData);

	// Object: Function AssetRegistry.AssetRegistryHelpers.IsAssetLoaded
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x104b46cd8
	// Return & Params: [ Num(2) Size(0x51) ]
	bool IsAssetLoaded(struct FAssetData& InAssetData);

	// Object: Function AssetRegistry.AssetRegistryHelpers.GetTagValue
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x104b469f4
	// Return & Params: [ Num(4) Size(0x69) ]
	bool GetTagValue(struct FAssetData& InAssetData, struct FName& InTagName, struct FString& OutTagValue);

	// Object: Function AssetRegistry.AssetRegistryHelpers.GetFullName
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x104b47108
	// Return & Params: [ Num(2) Size(0x60) ]
	struct FString GetFullName(struct FAssetData& InAssetData);

	// Object: Function AssetRegistry.AssetRegistryHelpers.GetExportTextName
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x104b46ba4
	// Return & Params: [ Num(2) Size(0x60) ]
	struct FString GetExportTextName(struct FAssetData& InAssetData);

	// Object: Function AssetRegistry.AssetRegistryHelpers.GetClass
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x104b46ed0
	// Return & Params: [ Num(2) Size(0x58) ]
	struct UObject* GetClass(struct FAssetData& InAssetData);

	// Object: Function AssetRegistry.AssetRegistryHelpers.GetAssetRegistry
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x104b47734
	// Return & Params: [ Num(1) Size(0x10) ]
	struct TScriptInterface<IAssetRegistry> GetAssetRegistry();

	// Object: Function AssetRegistry.AssetRegistryHelpers.GetAsset
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x104b46dd4
	// Return & Params: [ Num(2) Size(0x58) ]
	struct UObject* GetAsset(struct FAssetData& InAssetData);

	// Object: Function AssetRegistry.AssetRegistryHelpers.CreateAssetData
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x104b47530
	// Return & Params: [ Num(3) Size(0x60) ]
	struct FAssetData CreateAssetData(struct UObject* InAsset, bool bAllowBlueprintClass);
};

// Object: Class AssetRegistry.AssetRegistry
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UAssetRegistry : UInterface {
	// Functions

	// Object: Function AssetRegistry.AssetRegistry.UseFilterToExcludeAssets
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|Const]
	// Offset: 0x104b4833c
	// Return & Params: [ Num(2) Size(0xf8) ]
	void UseFilterToExcludeAssets(struct TArray<struct FAssetData>& AssetDataList, struct FARFilter& Filter);

	// Object: Function AssetRegistry.AssetRegistry.SearchAllAssets
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104b4805c
	// Return & Params: [ Num(1) Size(0x1) ]
	void SearchAllAssets(bool bSynchronousSearch);

	// Object: Function AssetRegistry.AssetRegistry.ScanPathsSynchronous
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104b48214
	// Return & Params: [ Num(2) Size(0x11) ]
	void ScanPathsSynchronous(struct TArray<struct FString>& InPaths, bool bForceRescan);

	// Object: Function AssetRegistry.AssetRegistry.ScanModifiedAssetFiles
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104b47ef4
	// Return & Params: [ Num(1) Size(0x10) ]
	void ScanModifiedAssetFiles(struct TArray<struct FString>& InFilePaths);

	// Object: Function AssetRegistry.AssetRegistry.ScanFilesSynchronous
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104b480ec
	// Return & Params: [ Num(2) Size(0x11) ]
	void ScanFilesSynchronous(struct TArray<struct FString>& InFilePaths, bool bForceRescan);

	// Object: Function AssetRegistry.AssetRegistry.RunAssetsThroughFilter
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|Const]
	// Offset: 0x104b48518
	// Return & Params: [ Num(2) Size(0xf8) ]
	void RunAssetsThroughFilter(struct TArray<struct FAssetData>& AssetDataList, struct FARFilter& Filter);

	// Object: Function AssetRegistry.AssetRegistry.PrioritizeSearchPath
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104b47fc8
	// Return & Params: [ Num(1) Size(0x10) ]
	void PrioritizeSearchPath(struct FString PathToPrioritize);

	// Object: Function AssetRegistry.AssetRegistry.K2_GetReferencers
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|Const]
	// Offset: 0x104b48948
	// Return & Params: [ Num(4) Size(0x21) ]
	bool K2_GetReferencers(struct FName PackageName, struct FAssetRegistryDependencyOptions& ReferenceOptions, struct TArray<struct FName>& OutReferencers);

	// Object: Function AssetRegistry.AssetRegistry.K2_GetDependencies
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|Const]
	// Offset: 0x104b48aa4
	// Return & Params: [ Num(4) Size(0x21) ]
	bool K2_GetDependencies(struct FName PackageName, struct FAssetRegistryDependencyOptions& DependencyOptions, struct TArray<struct FName>& OutDependencies);

	// Object: Function AssetRegistry.AssetRegistry.IsLoadingAssets
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104b47eb8
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsLoadingAssets();

	// Object: Function AssetRegistry.AssetRegistry.HasAssets
	// Flags: [Native|Public|BlueprintCallable|Const]
	// Offset: 0x104b4975c
	// Return & Params: [ Num(3) Size(0xa) ]
	bool HasAssets(struct FName PackagePath, bool bRecursive);

	// Object: Function AssetRegistry.AssetRegistry.GetSubPaths
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|Const]
	// Offset: 0x104b486f4
	// Return & Params: [ Num(3) Size(0x21) ]
	void GetSubPaths(struct FString InBasePath, struct TArray<struct FString>& OutPathList, bool bInRecurse);

	// Object: Function AssetRegistry.AssetRegistry.GetAssetsByPath
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|Const]
	// Offset: 0x104b49354
	// Return & Params: [ Num(5) Size(0x1b) ]
	bool GetAssetsByPath(struct FName PackagePath, struct TArray<struct FAssetData>& OutAssetData, bool bRecursive, bool bIncludeOnlyOnDiskAssets);

	// Object: Function AssetRegistry.AssetRegistry.GetAssetsByPackageName
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|Const]
	// Offset: 0x104b49588
	// Return & Params: [ Num(4) Size(0x1a) ]
	bool GetAssetsByPackageName(struct FName PackageName, struct TArray<struct FAssetData>& OutAssetData, bool bIncludeOnlyOnDiskAssets);

	// Object: Function AssetRegistry.AssetRegistry.GetAssetsByClass
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|Const]
	// Offset: 0x104b49180
	// Return & Params: [ Num(4) Size(0x1a) ]
	bool GetAssetsByClass(struct FName ClassName, struct TArray<struct FAssetData>& OutAssetData, bool bSearchSubClasses);

	// Object: Function AssetRegistry.AssetRegistry.GetAssets
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|Const]
	// Offset: 0x104b48f9c
	// Return & Params: [ Num(3) Size(0xf9) ]
	bool GetAssets(struct FARFilter& Filter, struct TArray<struct FAssetData>& OutAssetData);

	// Object: Function AssetRegistry.AssetRegistry.GetAssetByObjectPath
	// Flags: [Native|Public|BlueprintCallable|Const]
	// Offset: 0x104b48d88
	// Return & Params: [ Num(3) Size(0x60) ]
	struct FAssetData GetAssetByObjectPath(struct FName ObjectPath, bool bIncludeOnlyOnDiskAssets);

	// Object: Function AssetRegistry.AssetRegistry.GetAllCachedPaths
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|Const]
	// Offset: 0x104b48874
	// Return & Params: [ Num(1) Size(0x10) ]
	void GetAllCachedPaths(struct TArray<struct FString>& OutPathList);

	// Object: Function AssetRegistry.AssetRegistry.GetAllAssets
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|Const]
	// Offset: 0x104b48c00
	// Return & Params: [ Num(3) Size(0x12) ]
	bool GetAllAssets(struct TArray<struct FAssetData>& OutAssetData, bool bIncludeOnlyOnDiskAssets);
};

