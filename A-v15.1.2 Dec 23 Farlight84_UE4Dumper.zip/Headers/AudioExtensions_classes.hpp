#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class AudioExtensions.SoundfieldEncodingSettingsBase
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct USoundfieldEncodingSettingsBase : UObject {
};

// Object: Class AudioExtensions.AudioEndpointSettingsBase
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UAudioEndpointSettingsBase : UObject {
};

// Object: Class AudioExtensions.SpatializationPluginSourceSettingsBase
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct USpatializationPluginSourceSettingsBase : UObject {
};

// Object: Class AudioExtensions.OcclusionPluginSourceSettingsBase
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UOcclusionPluginSourceSettingsBase : UObject {
};

// Object: Class AudioExtensions.SoundModulationPluginSourceSettingsBase
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct USoundModulationPluginSourceSettingsBase : UObject {
};

// Object: Class AudioExtensions.ReverbPluginSourceSettingsBase
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UReverbPluginSourceSettingsBase : UObject {
};

// Object: Class AudioExtensions.SoundfieldEndpointSettingsBase
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct USoundfieldEndpointSettingsBase : UObject {
};

// Object: Class AudioExtensions.SoundfieldEffectSettingsBase
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct USoundfieldEffectSettingsBase : UObject {
};

// Object: Class AudioExtensions.SoundfieldEffectBase
// Inherited Bytes: 0x28 | Struct Size: 0x30
struct USoundfieldEffectBase : UObject {
	// Fields
	struct USoundfieldEffectSettingsBase* Settings; // Offset: 0x28 | Size: 0x8
};

