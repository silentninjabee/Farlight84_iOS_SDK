#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct AugmentedReality.ARSharedWorldReplicationState
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FARSharedWorldReplicationState {
	// Fields
	int32_t PreviewImageOffset; // Offset: 0x0 | Size: 0x4
	int32_t ARWorldOffset; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct AugmentedReality.ARTraceResult
// Inherited Bytes: 0x0 | Struct Size: 0x60
struct FARTraceResult {
	// Fields
	float DistanceFromCamera; // Offset: 0x0 | Size: 0x4
	enum class EARLineTraceChannels TraceChannel; // Offset: 0x4 | Size: 0x1
	char pad_0x5[0xb]; // Offset: 0x5 | Size: 0xb
	struct FTransform LocalToTrackingTransform; // Offset: 0x10 | Size: 0x30
	struct UARTrackedGeometry* TrackedGeometry; // Offset: 0x40 | Size: 0x8
	char pad_0x48[0x18]; // Offset: 0x48 | Size: 0x18
};

// Object: ScriptStruct AugmentedReality.ARPose3D
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FARPose3D {
	// Fields
	struct FARSkeletonDefinition SkeletonDefinition; // Offset: 0x0 | Size: 0x28
	struct TArray<struct FTransform> JointTransforms; // Offset: 0x28 | Size: 0x10
	struct TArray<bool> IsJointTracked; // Offset: 0x38 | Size: 0x10
	enum class EARJointTransformSpace JointTransformSpace; // Offset: 0x48 | Size: 0x1
	char pad_0x49[0x7]; // Offset: 0x49 | Size: 0x7
};

// Object: ScriptStruct AugmentedReality.ARSkeletonDefinition
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FARSkeletonDefinition {
	// Fields
	int32_t NumJoints; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct TArray<struct FName> JointNames; // Offset: 0x8 | Size: 0x10
	struct TArray<int32_t> ParentIndices; // Offset: 0x18 | Size: 0x10
};

// Object: ScriptStruct AugmentedReality.ARPose2D
// Inherited Bytes: 0x0 | Struct Size: 0x48
struct FARPose2D {
	// Fields
	struct FARSkeletonDefinition SkeletonDefinition; // Offset: 0x0 | Size: 0x28
	struct TArray<struct FVector2D> JointLocations; // Offset: 0x28 | Size: 0x10
	struct TArray<bool> IsJointTracked; // Offset: 0x38 | Size: 0x10
};

// Object: ScriptStruct AugmentedReality.ARVideoFormat
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FARVideoFormat {
	// Fields
	int32_t Fps; // Offset: 0x0 | Size: 0x4
	int32_t Width; // Offset: 0x4 | Size: 0x4
	int32_t Height; // Offset: 0x8 | Size: 0x4
};

// Object: ScriptStruct AugmentedReality.ARSessionStatus
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FARSessionStatus {
	// Fields
	struct FString AdditionalInfo; // Offset: 0x0 | Size: 0x10
	enum class EARSessionStatus status; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x7]; // Offset: 0x11 | Size: 0x7
};

