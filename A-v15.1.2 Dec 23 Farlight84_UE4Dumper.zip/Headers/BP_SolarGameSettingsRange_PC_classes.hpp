#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_SolarGameSettingsRange_PC.BP_SolarGameSettingsRange_PC_C
// Inherited Bytes: 0x180 | Struct Size: 0x180
struct UBP_SolarGameSettingsRange_PC_C : USolarGameSettingsRange {
};

