#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct BlockoutToolsPlugin.BlockoutMaterialPreset
// Inherited Bytes: 0x8 | Struct Size: 0x38
struct FBlockoutMaterialPreset : FTableRowBase {
	// Fields
	bool bUseGrid; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x3]; // Offset: 0x9 | Size: 0x3
	float GridSize; // Offset: 0xc | Size: 0x4
	float CheckerLuminance; // Offset: 0x10 | Size: 0x4
	struct FLinearColor Color; // Offset: 0x14 | Size: 0x10
	bool bUseTopColor; // Offset: 0x24 | Size: 0x1
	char pad_0x25[0x3]; // Offset: 0x25 | Size: 0x3
	struct FLinearColor TopColor; // Offset: 0x28 | Size: 0x10
};

