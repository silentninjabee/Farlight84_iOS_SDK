#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class CableComponent.CableActor
// Inherited Bytes: 0x228 | Struct Size: 0x230
struct ACableActor : AActor {
	// Fields
	struct UCableComponent* CableComponent; // Offset: 0x228 | Size: 0x8
};

// Object: Class CableComponent.CableComponent
// Inherited Bytes: 0x5e0 | Struct Size: 0x670
struct UCableComponent : UMeshComponent {
	// Fields
	bool bAttachStart; // Offset: 0x5d9 | Size: 0x1
	bool bAttachEnd; // Offset: 0x5da | Size: 0x1
	struct FComponentReference AttachEndTo; // Offset: 0x5e0 | Size: 0x28
	struct FName AttachEndToSocketName; // Offset: 0x608 | Size: 0x8
	struct FVector EndLocation; // Offset: 0x610 | Size: 0xc
	float CableLength; // Offset: 0x61c | Size: 0x4
	int32_t NumSegments; // Offset: 0x620 | Size: 0x4
	float SubstepTime; // Offset: 0x624 | Size: 0x4
	int32_t SolverIterations; // Offset: 0x628 | Size: 0x4
	bool bEnableStiffness; // Offset: 0x62c | Size: 0x1
	bool bEnableCollision; // Offset: 0x62d | Size: 0x1
	float CollisionFriction; // Offset: 0x630 | Size: 0x4
	struct FVector CableForce; // Offset: 0x634 | Size: 0xc
	float CableGravityScale; // Offset: 0x640 | Size: 0x4
	float CableWidth; // Offset: 0x644 | Size: 0x4
	int32_t NumSides; // Offset: 0x648 | Size: 0x4
	float TileMaterial; // Offset: 0x64c | Size: 0x4
	char pad_0x650[0x20]; // Offset: 0x650 | Size: 0x20

	// Functions

	// Object: Function CableComponent.CableComponent.SetAttachEndToComponent
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102544614
	// Return & Params: [ Num(2) Size(0x10) ]
	void SetAttachEndToComponent(struct USceneComponent* Component, struct FName SocketName);

	// Object: Function CableComponent.CableComponent.SetAttachEndTo
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102544500
	// Return & Params: [ Num(3) Size(0x18) ]
	void SetAttachEndTo(struct AActor* Actor, struct FName ComponentProperty, struct FName SocketName);

	// Object: Function CableComponent.CableComponent.GetCableParticleLocations
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102544400
	// Return & Params: [ Num(1) Size(0x10) ]
	void GetCableParticleLocations(struct TArray<struct FVector>& Locations);

	// Object: Function CableComponent.CableComponent.GetAttachedComponent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102544498
	// Return & Params: [ Num(1) Size(0x8) ]
	struct USceneComponent* GetAttachedComponent();

	// Object: Function CableComponent.CableComponent.GetAttachedActor
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1025444cc
	// Return & Params: [ Num(1) Size(0x8) ]
	struct AActor* GetAttachedActor();
};

