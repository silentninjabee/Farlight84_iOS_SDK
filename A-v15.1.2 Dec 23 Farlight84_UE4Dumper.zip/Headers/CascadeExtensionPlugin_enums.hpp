#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Enum CascadeExtensionPlugin.EDistanceWeight
enum class EDistanceWeight : uint8_t {
	LINEAR = 0,
	INVERSE_LINEAR = 1,
	QUADRATIC = 2,
	INVERSE_QUAD = 3,
	W_Max = 4,
	EDistanceWeight_MAX = 5
};

// Object: Enum CascadeExtensionPlugin.ESpaceAxis
enum class ESpaceAxis : uint8_t {
	X = 0,
	Y = 1,
	Z = 2,
	Ax_Max = 3,
	ESpaceAxis_MAX = 4
};

