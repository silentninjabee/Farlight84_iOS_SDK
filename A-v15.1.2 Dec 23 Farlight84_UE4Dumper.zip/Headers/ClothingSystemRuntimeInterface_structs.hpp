#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct ClothingSystemRuntimeInterface.ClothCollisionData
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FClothCollisionData {
	// Fields
	struct TArray<struct FClothCollisionPrim_Sphere> Spheres; // Offset: 0x0 | Size: 0x10
	struct TArray<struct FClothCollisionPrim_SphereConnection> SphereConnections; // Offset: 0x10 | Size: 0x10
	struct TArray<struct FClothCollisionPrim_Convex> Convexes; // Offset: 0x20 | Size: 0x10
	struct TArray<struct FClothCollisionPrim_Box> Boxes; // Offset: 0x30 | Size: 0x10
};

// Object: ScriptStruct ClothingSystemRuntimeInterface.ClothCollisionPrim_Box
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FClothCollisionPrim_Box {
	// Fields
	struct FVector LocalPosition; // Offset: 0x0 | Size: 0xc
	char pad_0xC[0x4]; // Offset: 0xc | Size: 0x4
	struct FQuat LocalRotation; // Offset: 0x10 | Size: 0x10
	struct FVector HalfExtents; // Offset: 0x20 | Size: 0xc
	int32_t BoneIndex; // Offset: 0x2c | Size: 0x4
};

// Object: ScriptStruct ClothingSystemRuntimeInterface.ClothCollisionPrim_Convex
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FClothCollisionPrim_Convex {
	// Fields
	struct TArray<struct FPlane> Planes; // Offset: 0x0 | Size: 0x10
	struct TArray<struct FVector> SurfacePoints; // Offset: 0x10 | Size: 0x10
	int32_t BoneIndex; // Offset: 0x20 | Size: 0x4
	char pad_0x24[0x4]; // Offset: 0x24 | Size: 0x4
};

// Object: ScriptStruct ClothingSystemRuntimeInterface.ClothCollisionPrim_SphereConnection
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FClothCollisionPrim_SphereConnection {
	// Fields
	int32_t SphereIndices[0x2]; // Offset: 0x0 | Size: 0x8
};

// Object: ScriptStruct ClothingSystemRuntimeInterface.ClothCollisionPrim_Sphere
// Inherited Bytes: 0x0 | Struct Size: 0x14
struct FClothCollisionPrim_Sphere {
	// Fields
	int32_t BoneIndex; // Offset: 0x0 | Size: 0x4
	float Radius; // Offset: 0x4 | Size: 0x4
	struct FVector LocalPosition; // Offset: 0x8 | Size: 0xc
};

// Object: ScriptStruct ClothingSystemRuntimeInterface.ClothVertBoneData
// Inherited Bytes: 0x0 | Struct Size: 0x4c
struct FClothVertBoneData {
	// Fields
	int32_t NumInfluences; // Offset: 0x0 | Size: 0x4
	uint16_t BoneIndices[0xc]; // Offset: 0x4 | Size: 0x18
	float BoneWeights[0xc]; // Offset: 0x1c | Size: 0x30
};

