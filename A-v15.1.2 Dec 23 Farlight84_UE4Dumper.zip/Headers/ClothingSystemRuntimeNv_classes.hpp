#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class ClothingSystemRuntimeNv.ClothConfigNv
// Inherited Bytes: 0x28 | Struct Size: 0x140
struct UClothConfigNv : UClothConfigCommon {
	// Fields
	enum class EClothingWindMethodNv ClothingWindMethod; // Offset: 0x28 | Size: 0x1
	char pad_0x29[0x3]; // Offset: 0x29 | Size: 0x3
	struct FClothConstraintSetupNv VerticalConstraint; // Offset: 0x2c | Size: 0x10
	struct FClothConstraintSetupNv HorizontalConstraint; // Offset: 0x3c | Size: 0x10
	struct FClothConstraintSetupNv BendConstraint; // Offset: 0x4c | Size: 0x10
	struct FClothConstraintSetupNv ShearConstraint; // Offset: 0x5c | Size: 0x10
	float SelfCollisionRadius; // Offset: 0x6c | Size: 0x4
	float SelfCollisionStiffness; // Offset: 0x70 | Size: 0x4
	float SelfCollisionCullScale; // Offset: 0x74 | Size: 0x4
	struct FVector Damping; // Offset: 0x78 | Size: 0xc
	float Friction; // Offset: 0x84 | Size: 0x4
	float WindDragCoefficient; // Offset: 0x88 | Size: 0x4
	float WindLiftCoefficient; // Offset: 0x8c | Size: 0x4
	struct FVector LinearDrag; // Offset: 0x90 | Size: 0xc
	struct FVector AngularDrag; // Offset: 0x9c | Size: 0xc
	struct FVector LinearInertiaScale; // Offset: 0xa8 | Size: 0xc
	struct FVector AngularInertiaScale; // Offset: 0xb4 | Size: 0xc
	struct FVector CentrifugalInertiaScale; // Offset: 0xc0 | Size: 0xc
	float SolverFrequency; // Offset: 0xcc | Size: 0x4
	float StiffnessFrequency; // Offset: 0xd0 | Size: 0x4
	float GravityScale; // Offset: 0xd4 | Size: 0x4
	struct FVector GravityOverride; // Offset: 0xd8 | Size: 0xc
	bool bUseGravityOverride; // Offset: 0xe4 | Size: 0x1
	char pad_0xE5[0x3]; // Offset: 0xe5 | Size: 0x3
	float TetherStiffness; // Offset: 0xe8 | Size: 0x4
	float TetherLimit; // Offset: 0xec | Size: 0x4
	float CollisionThickness; // Offset: 0xf0 | Size: 0x4
	float AnimDriveSpringStiffness; // Offset: 0xf4 | Size: 0x4
	float AnimDriveDamperStiffness; // Offset: 0xf8 | Size: 0x4
	enum class EClothingWindMethod_Legacy WindMethod; // Offset: 0xfc | Size: 0x1
	char pad_0xFD[0x3]; // Offset: 0xfd | Size: 0x3
	struct FClothConstraintSetup_Legacy VerticalConstraintConfig; // Offset: 0x100 | Size: 0x10
	struct FClothConstraintSetup_Legacy HorizontalConstraintConfig; // Offset: 0x110 | Size: 0x10
	struct FClothConstraintSetup_Legacy BendConstraintConfig; // Offset: 0x120 | Size: 0x10
	struct FClothConstraintSetup_Legacy ShearConstraintConfig; // Offset: 0x130 | Size: 0x10
};

// Object: Class ClothingSystemRuntimeNv.ClothingSimulationFactoryNv
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UClothingSimulationFactoryNv : UClothingSimulationFactory {
};

// Object: Class ClothingSystemRuntimeNv.ClothingSimulationInteractorNv
// Inherited Bytes: 0x30 | Struct Size: 0x40
struct UClothingSimulationInteractorNv : UClothingSimulationInteractor {
	// Fields
	char pad_0x30[0x10]; // Offset: 0x30 | Size: 0x10

	// Functions

	// Object: Function ClothingSystemRuntimeNv.ClothingSimulationInteractorNv.SetAnimDriveDamperStiffness
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105850628
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetAnimDriveDamperStiffness(float InStiffness);
};

// Object: Class ClothingSystemRuntimeNv.ClothPhysicalMeshDataNv_Legacy
// Inherited Bytes: 0xe0 | Struct Size: 0x120
struct UClothPhysicalMeshDataNv_Legacy : UClothPhysicalMeshDataBase_Legacy {
	// Fields
	struct TArray<float> MaxDistances; // Offset: 0xe0 | Size: 0x10
	struct TArray<float> BackstopDistances; // Offset: 0xf0 | Size: 0x10
	struct TArray<float> BackstopRadiuses; // Offset: 0x100 | Size: 0x10
	struct TArray<float> AnimDriveMultipliers; // Offset: 0x110 | Size: 0x10
};

