#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class CommonUI.AnalogSlider
// Inherited Bytes: 0x760 | Struct Size: 0x780
struct UAnalogSlider : USlider {
	// Fields
	struct FMulticastInlineDelegate OnAnalogCapture; // Offset: 0x760 | Size: 0x10
	char pad_0x770[0x10]; // Offset: 0x770 | Size: 0x10
};

// Object: Class CommonUI.CommonActionHandlerInterface
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UCommonActionHandlerInterface : UInterface {
};

// Object: Class CommonUI.CommonActionWidget
// Inherited Bytes: 0x138 | Struct Size: 0x470
struct UCommonActionWidget : UWidget {
	// Fields
	struct FMulticastInlineDelegate OnInputMethodChanged; // Offset: 0x138 | Size: 0x10
	char pad_0x148[0x8]; // Offset: 0x148 | Size: 0x8
	struct FSlateBrush ProgressMaterialBrush; // Offset: 0x150 | Size: 0xe0
	struct FName ProgressMaterialParam; // Offset: 0x230 | Size: 0x8
	char pad_0x238[0x8]; // Offset: 0x238 | Size: 0x8
	struct FSlateBrush IconRimBrush; // Offset: 0x240 | Size: 0xe0
	struct TArray<struct FDataTableRowHandle> InputActions; // Offset: 0x320 | Size: 0x10
	char pad_0x330[0x8]; // Offset: 0x330 | Size: 0x8
	struct UMaterialInstanceDynamic* ProgressDynamicMaterial; // Offset: 0x338 | Size: 0x8
	char pad_0x340[0x130]; // Offset: 0x340 | Size: 0x130

	// Functions

	// Object: Function CommonUI.CommonActionWidget.SetInputActions
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101706128
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetInputActions(struct TArray<struct FDataTableRowHandle> NewInputActions);

	// Object: Function CommonUI.CommonActionWidget.SetInputAction
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101706218
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetInputAction(struct FDataTableRowHandle InputActionRow);

	// Object: Function CommonUI.CommonActionWidget.SetIconRimBrush
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101705cec
	// Return & Params: [ Num(1) Size(0xe0) ]
	void SetIconRimBrush(struct FSlateBrush InIconRimBrush);

	// Object: DelegateFunction CommonUI.CommonActionWidget.OnInputMethodChanged__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a48564
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnInputMethodChanged__DelegateSignature(bool bUsingGamepad);

	// Object: Function CommonUI.CommonActionWidget.IsHeldAction
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x101705cb8
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsHeldAction();

	// Object: Function CommonUI.CommonActionWidget.GetIcon
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x101706340
	// Return & Params: [ Num(1) Size(0xe0) ]
	struct FSlateBrush GetIcon();

	// Object: Function CommonUI.CommonActionWidget.GetDisplayText
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x101706298
	// Return & Params: [ Num(1) Size(0x18) ]
	struct FText GetDisplayText();
};

// Object: Class CommonUI.CommonUserWidget
// Inherited Bytes: 0x260 | Struct Size: 0x288
struct UCommonUserWidget : UUserWidget {
	// Fields
	bool bConsumePointerInput; // Offset: 0x260 | Size: 0x1
	char pad_0x261[0x27]; // Offset: 0x261 | Size: 0x27

	// Functions

	// Object: Function CommonUI.CommonUserWidget.SetConsumePointerInput
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10171b94c
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetConsumePointerInput(bool bInConsumePointerInput);
};

// Object: Class CommonUI.CommonActivatableWidget
// Inherited Bytes: 0x288 | Struct Size: 0x320
struct UCommonActivatableWidget : UCommonUserWidget {
	// Fields
	bool bAutoActivate; // Offset: 0x288 | Size: 0x1
	bool bIsBackHandler; // Offset: 0x289 | Size: 0x1
	bool bSupportsActivationFocus; // Offset: 0x28a | Size: 0x1
	bool bIsModal; // Offset: 0x28b | Size: 0x1
	bool bAutoRestoreFocus; // Offset: 0x28c | Size: 0x1
	bool bSetVisibilityOnActivated; // Offset: 0x28d | Size: 0x1
	enum class ESlateVisibility ActivatedVisibility; // Offset: 0x28e | Size: 0x1
	bool bSetVisibilityOnDeactivated; // Offset: 0x28f | Size: 0x1
	enum class ESlateVisibility DeactivatedVisibility; // Offset: 0x290 | Size: 0x1
	char pad_0x291[0x7]; // Offset: 0x291 | Size: 0x7
	struct FMulticastInlineDelegate BP_OnWidgetActivated; // Offset: 0x298 | Size: 0x10
	struct FMulticastInlineDelegate BP_OnWidgetDeactivated; // Offset: 0x2a8 | Size: 0x10
	bool bIsActive; // Offset: 0x2b8 | Size: 0x1
	char pad_0x2B9[0x67]; // Offset: 0x2b9 | Size: 0x67

	// Functions

	// Object: Function CommonUI.CommonActivatableWidget.IsActivated
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x101706968
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsActivated();

	// Object: Function CommonUI.CommonActivatableWidget.DeactivateWidget
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101706940
	// Return & Params: [ Num(0) Size(0x0) ]
	void DeactivateWidget();

	// Object: Function CommonUI.CommonActivatableWidget.BP_OnHandleBackAction
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103a48564
	// Return & Params: [ Num(1) Size(0x1) ]
	bool BP_OnHandleBackAction();

	// Object: Function CommonUI.CommonActivatableWidget.BP_OnDeactivated
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103a48564
	// Return & Params: [ Num(0) Size(0x0) ]
	void BP_OnDeactivated();

	// Object: Function CommonUI.CommonActivatableWidget.BP_OnActivated
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103a48564
	// Return & Params: [ Num(0) Size(0x0) ]
	void BP_OnActivated();

	// Object: Function CommonUI.CommonActivatableWidget.BP_GetDesiredFocusTarget
	// Flags: [Event|Protected|BlueprintEvent|Const]
	// Offset: 0x103a48564
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UWidget* BP_GetDesiredFocusTarget();

	// Object: Function CommonUI.CommonActivatableWidget.ActivateWidget
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101706954
	// Return & Params: [ Num(0) Size(0x0) ]
	void ActivateWidget();
};

// Object: Class CommonUI.CommonActivatableWidgetContainerBase
// Inherited Bytes: 0x138 | Struct Size: 0x238
struct UCommonActivatableWidgetContainerBase : UWidget {
	// Fields
	enum class ECommonSwitcherTransition TransitionType; // Offset: 0x138 | Size: 0x1
	enum class ETransitionCurve TransitionCurveType; // Offset: 0x139 | Size: 0x1
	char pad_0x13A[0x2]; // Offset: 0x13a | Size: 0x2
	float TransitionDuration; // Offset: 0x13c | Size: 0x4
	struct TArray<struct UCommonActivatableWidget*> WidgetList; // Offset: 0x140 | Size: 0x10
	struct UCommonActivatableWidget* DisplayedWidget; // Offset: 0x150 | Size: 0x8
	struct FUserWidgetPool GeneratedWidgetsPool; // Offset: 0x158 | Size: 0x80
	char pad_0x1D8[0x60]; // Offset: 0x1d8 | Size: 0x60

	// Functions

	// Object: Function CommonUI.CommonActivatableWidgetContainerBase.RemoveWidget
	// Flags: [Final|Native|Private|BlueprintCallable]
	// Offset: 0x10170711c
	// Return & Params: [ Num(1) Size(0x8) ]
	void RemoveWidget(struct UCommonActivatableWidget* WidgetToRemove);

	// Object: Function CommonUI.CommonActivatableWidgetContainerBase.GetActiveWidget
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x101707240
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UCommonActivatableWidget* GetActiveWidget();

	// Object: Function CommonUI.CommonActivatableWidgetContainerBase.ClearWidgets
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10170722c
	// Return & Params: [ Num(0) Size(0x0) ]
	void ClearWidgets();

	// Object: Function CommonUI.CommonActivatableWidgetContainerBase.BP_AddWidget
	// Flags: [Final|Native|Private|BlueprintCallable]
	// Offset: 0x10170719c
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UCommonActivatableWidget* BP_AddWidget(struct UCommonActivatableWidget* ActivatableWidgetClass);
};

// Object: Class CommonUI.CommonActivatableWidgetStack
// Inherited Bytes: 0x238 | Struct Size: 0x248
struct UCommonActivatableWidgetStack : UCommonActivatableWidgetContainerBase {
	// Fields
	struct UCommonActivatableWidget* RootContentWidgetClass; // Offset: 0x238 | Size: 0x8
	struct UCommonActivatableWidget* RootContentWidget; // Offset: 0x240 | Size: 0x8
};

// Object: Class CommonUI.CommonActivatableWidgetQueue
// Inherited Bytes: 0x238 | Struct Size: 0x238
struct UCommonActivatableWidgetQueue : UCommonActivatableWidgetContainerBase {
};

// Object: Class CommonUI.CommonAnimatedSwitcher
// Inherited Bytes: 0x160 | Struct Size: 0x1b8
struct UCommonAnimatedSwitcher : UWidgetSwitcher {
	// Fields
	char pad_0x160[0x18]; // Offset: 0x160 | Size: 0x18
	enum class ECommonSwitcherTransition TransitionType; // Offset: 0x178 | Size: 0x1
	enum class ETransitionCurve TransitionCurveType; // Offset: 0x179 | Size: 0x1
	char pad_0x17A[0x2]; // Offset: 0x17a | Size: 0x2
	float TransitionDuration; // Offset: 0x17c | Size: 0x4
	char pad_0x180[0x38]; // Offset: 0x180 | Size: 0x38

	// Functions

	// Object: Function CommonUI.CommonAnimatedSwitcher.SetDisableTransitionAnimation
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101707a4c
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetDisableTransitionAnimation(bool bDisableAnimation);

	// Object: Function CommonUI.CommonAnimatedSwitcher.HasWidgets
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x101707ad4
	// Return & Params: [ Num(1) Size(0x1) ]
	bool HasWidgets();

	// Object: Function CommonUI.CommonAnimatedSwitcher.ActivatePreviousWidget
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101707b08
	// Return & Params: [ Num(1) Size(0x1) ]
	void ActivatePreviousWidget(bool bCanWrap);

	// Object: Function CommonUI.CommonAnimatedSwitcher.ActivateNextWidget
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101707b90
	// Return & Params: [ Num(1) Size(0x1) ]
	void ActivateNextWidget(bool bCanWrap);
};

// Object: Class CommonUI.CommonActivatableWidgetSwitcher
// Inherited Bytes: 0x1b8 | Struct Size: 0x1b8
struct UCommonActivatableWidgetSwitcher : UCommonAnimatedSwitcher {
};

// Object: Class CommonUI.CommonBorderStyle
// Inherited Bytes: 0x28 | Struct Size: 0x110
struct UCommonBorderStyle : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
	struct FSlateBrush Background; // Offset: 0x30 | Size: 0xe0

	// Functions

	// Object: Function CommonUI.CommonBorderStyle.GetBackgroundBrush
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x101707f04
	// Return & Params: [ Num(1) Size(0xe0) ]
	void GetBackgroundBrush(struct FSlateBrush& Brush);
};

// Object: Class CommonUI.CommonBorder
// Inherited Bytes: 0x2f0 | Struct Size: 0x310
struct UCommonBorder : UBorder {
	// Fields
	struct UCommonBorderStyle* Style; // Offset: 0x2f0 | Size: 0x8
	bool bReducePaddingBySafezone; // Offset: 0x2f8 | Size: 0x1
	char pad_0x2F9[0x3]; // Offset: 0x2f9 | Size: 0x3
	struct FMargin MinimumPadding; // Offset: 0x2fc | Size: 0x10
	char pad_0x30C[0x4]; // Offset: 0x30c | Size: 0x4

	// Functions

	// Object: Function CommonUI.CommonBorder.SetStyle
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1017084e8
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetStyle(struct UCommonBorderStyle* InStyle);
};

// Object: Class CommonUI.CommonBoundActionBar
// Inherited Bytes: 0x1f8 | Struct Size: 0x208
struct UCommonBoundActionBar : UDynamicEntryBoxBase {
	// Fields
	struct UCommonBoundActionButton* ActionButtonClass; // Offset: 0x1f8 | Size: 0x8
	bool bDisplayOwningPlayerActionsOnly; // Offset: 0x200 | Size: 0x1
	char pad_0x201[0x7]; // Offset: 0x201 | Size: 0x7

	// Functions

	// Object: Function CommonUI.CommonBoundActionBar.SetDisplayOwningPlayerActionsOnly
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1017087a0
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetDisplayOwningPlayerActionsOnly(bool bShouldOnlyDisplayOwningPlayerActions);
};

// Object: Class CommonUI.CommonButtonBase
// Inherited Bytes: 0x288 | Struct Size: 0xfe0
struct UCommonButtonBase : UCommonUserWidget {
	// Fields
	int32_t MinWidth; // Offset: 0x288 | Size: 0x4
	int32_t MinHeight; // Offset: 0x28c | Size: 0x4
	struct UCommonButtonStyle* Style; // Offset: 0x290 | Size: 0x8
	bool bHideInputAction; // Offset: 0x298 | Size: 0x1
	char pad_0x299[0x7]; // Offset: 0x299 | Size: 0x7
	struct FSlateSound PressedSlateSoundOverride; // Offset: 0x2a0 | Size: 0x18
	struct FSlateSound HoveredSlateSoundOverride; // Offset: 0x2b8 | Size: 0x18
	char bApplyAlphaOnDisable : 1; // Offset: 0x2d0 | Size: 0x1
	char bSelectable : 1; // Offset: 0x2d0 | Size: 0x1
	char bShouldSelectUponReceivingFocus : 1; // Offset: 0x2d0 | Size: 0x1
	char bInteractableWhenSelected : 1; // Offset: 0x2d0 | Size: 0x1
	char bToggleable : 1; // Offset: 0x2d0 | Size: 0x1
	char bDisplayInputActionWhenNotInteractable : 1; // Offset: 0x2d0 | Size: 0x1
	char bHideInputActionWithKeyboard : 1; // Offset: 0x2d0 | Size: 0x1
	char bShouldUseFallbackDefaultInputAction : 1; // Offset: 0x2d0 | Size: 0x1
	char pad_0x2D1[0x1]; // Offset: 0x2d1 | Size: 0x1
	enum class EButtonClickMethod ClickMethod; // Offset: 0x2d2 | Size: 0x1
	enum class EButtonTouchMethod TouchMethod; // Offset: 0x2d3 | Size: 0x1
	enum class EButtonPressMethod PressMethod; // Offset: 0x2d4 | Size: 0x1
	char pad_0x2D5[0x3]; // Offset: 0x2d5 | Size: 0x3
	int32_t InputPriority; // Offset: 0x2d8 | Size: 0x4
	char pad_0x2DC[0x4]; // Offset: 0x2dc | Size: 0x4
	struct FDataTableRowHandle TriggeringInputAction; // Offset: 0x2e0 | Size: 0x10
	char pad_0x2F0[0x10]; // Offset: 0x2f0 | Size: 0x10
	struct FMulticastInlineDelegate OnSelectedChangedBase; // Offset: 0x300 | Size: 0x10
	struct FMulticastInlineDelegate OnButtonBaseClicked; // Offset: 0x310 | Size: 0x10
	struct FMulticastInlineDelegate OnButtonBaseDoubleClicked; // Offset: 0x320 | Size: 0x10
	struct FMulticastInlineDelegate OnButtonBaseHovered; // Offset: 0x330 | Size: 0x10
	struct FMulticastInlineDelegate OnButtonBaseUnhovered; // Offset: 0x340 | Size: 0x10
	char pad_0x350[0x4]; // Offset: 0x350 | Size: 0x4
	bool bIsPersistentBinding; // Offset: 0x354 | Size: 0x1
	enum class ECommonInputMode InputModeOverride; // Offset: 0x355 | Size: 0x1
	char pad_0x356[0x32]; // Offset: 0x356 | Size: 0x32
	struct UMaterialInstanceDynamic* SingleMaterialStyleMID; // Offset: 0x388 | Size: 0x8
	struct FButtonStyle NormalStyle; // Offset: 0x390 | Size: 0x3e0
	struct FButtonStyle SelectedStyle; // Offset: 0x770 | Size: 0x3e0
	struct FButtonStyle DisabledStyle; // Offset: 0xb50 | Size: 0x3e0
	char bStopDoubleClickPropagation : 1; // Offset: 0xf30 | Size: 0x1
	char pad_0xF30_1 : 7; // Offset: 0xf30 | Size: 0x1
	char pad_0xF31[0x9f]; // Offset: 0xf31 | Size: 0x9f
	struct UCommonActionWidget* InputActionWidget; // Offset: 0xfd0 | Size: 0x8
	char pad_0xFD8[0x8]; // Offset: 0xfd8 | Size: 0x8

	// Functions

	// Object: Function CommonUI.CommonButtonBase.StopDoubleClickPropagation
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x10170b1f4
	// Return & Params: [ Num(0) Size(0x0) ]
	void StopDoubleClickPropagation();

	// Object: Function CommonUI.CommonButtonBase.SetTriggeringInputAction
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10170b8c0
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetTriggeringInputAction(struct FDataTableRowHandle& InputActionRow);

	// Object: Function CommonUI.CommonButtonBase.SetTriggeredInputAction
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10170b94c
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetTriggeredInputAction(struct FDataTableRowHandle& InputActionRow);

	// Object: Function CommonUI.CommonButtonBase.SetTouchMethod
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10170c160
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetTouchMethod(enum class EButtonTouchMethod InTouchMethod);

	// Object: Function CommonUI.CommonButtonBase.SetStyle
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10170bc54
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetStyle(struct UCommonButtonStyle* InStyle);

	// Object: Function CommonUI.CommonButtonBase.SetShouldUseFallbackDefaultInputAction
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10170bec0
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetShouldUseFallbackDefaultInputAction(bool bInShouldUseFallbackDefaultInputAction);

	// Object: Function CommonUI.CommonButtonBase.SetShouldSelectUponReceivingFocus
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10170bd08
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetShouldSelectUponReceivingFocus(bool bInShouldSelectUponReceivingFocus);

	// Object: Function CommonUI.CommonButtonBase.SetSelectedInternal
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x10170b0b4
	// Return & Params: [ Num(3) Size(0x3) ]
	void SetSelectedInternal(bool bInSelected, bool bAllowSound, bool bBroadCast);

	// Object: Function CommonUI.CommonButtonBase.SetPressMethod
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10170c0e0
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetPressMethod(enum class EButtonPressMethod InPressMethod);

	// Object: Function CommonUI.CommonButtonBase.SetPressedSoundOverride
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10170b3fc
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetPressedSoundOverride(struct USoundBase* Sound);

	// Object: Function CommonUI.CommonButtonBase.SetMinDimensions
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10170b9d8
	// Return & Params: [ Num(2) Size(0x8) ]
	void SetMinDimensions(int32_t InMinWidth, int32_t InMinHeight);

	// Object: Function CommonUI.CommonButtonBase.SetIsToggleable
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10170bf48
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetIsToggleable(bool bInIsToggleable);

	// Object: Function CommonUI.CommonButtonBase.SetIsSelected
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10170bdd8
	// Return & Params: [ Num(2) Size(0x2) ]
	void SetIsSelected(bool InSelected, bool bGiveClickFeedback);

	// Object: Function CommonUI.CommonButtonBase.SetIsSelectable
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10170c058
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetIsSelectable(bool bInIsSelectable);

	// Object: Function CommonUI.CommonButtonBase.SetIsInteractionEnabled
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10170c2c8
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetIsInteractionEnabled(bool bInIsInteractionEnabled);

	// Object: Function CommonUI.CommonButtonBase.SetIsInteractableWhenSelected
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10170bfd0
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetIsInteractableWhenSelected(bool bInInteractableWhenSelected);

	// Object: Function CommonUI.CommonButtonBase.SetIsFocusable
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10170b79c
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetIsFocusable(bool bInIsFocusable);

	// Object: Function CommonUI.CommonButtonBase.SetInputActionProgressMaterial
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10170b47c
	// Return & Params: [ Num(2) Size(0xe8) ]
	void SetInputActionProgressMaterial(struct FSlateBrush& InProgressMaterialBrush, struct FName& InProgressMaterialParam);

	// Object: Function CommonUI.CommonButtonBase.SetHoveredSoundOverride
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10170b37c
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetHoveredSoundOverride(struct USoundBase* Sound);

	// Object: Function CommonUI.CommonButtonBase.SetClickMethod
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10170c1e0
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetClickMethod(enum class EButtonClickMethod InClickMethod);

	// Object: Function CommonUI.CommonButtonBase.OnTriggeredInputActionChanged
	// Flags: [Event|Protected|HasOutParms|BlueprintEvent]
	// Offset: 0x103a48564
	// Return & Params: [ Num(1) Size(0x10) ]
	void OnTriggeredInputActionChanged(struct FDataTableRowHandle& NewTriggeredAction);

	// Object: Function CommonUI.CommonButtonBase.OnInputMethodChanged
	// Flags: [Native|Protected]
	// Offset: 0x10170b2f4
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnInputMethodChanged(enum class ECommonInputType CurrentInputType);

	// Object: Function CommonUI.CommonButtonBase.OnCurrentTextStyleChanged
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103a48564
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnCurrentTextStyleChanged();

	// Object: Function CommonUI.CommonButtonBase.OnActionProgress
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103a48564
	// Return & Params: [ Num(1) Size(0x4) ]
	void OnActionProgress(float HeldPercent);

	// Object: Function CommonUI.CommonButtonBase.OnActionComplete
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103a48564
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnActionComplete();

	// Object: Function CommonUI.CommonButtonBase.NativeOnActionProgress
	// Flags: [Native|Protected]
	// Offset: 0x10170b02c
	// Return & Params: [ Num(1) Size(0x4) ]
	void NativeOnActionProgress(float HeldPercent);

	// Object: Function CommonUI.CommonButtonBase.NativeOnActionComplete
	// Flags: [Native|Protected]
	// Offset: 0x10170b010
	// Return & Params: [ Num(0) Size(0x0) ]
	void NativeOnActionComplete();

	// Object: Function CommonUI.CommonButtonBase.IsPressed
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10170c260
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsPressed();

	// Object: Function CommonUI.CommonButtonBase.IsInteractionEnabled
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10170c294
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsInteractionEnabled();

	// Object: Function CommonUI.CommonButtonBase.HandleTriggeringActionCommited
	// Flags: [Native|Protected|HasOutParms]
	// Offset: 0x10170b260
	// Return & Params: [ Num(1) Size(0x1) ]
	void HandleTriggeringActionCommited(bool& bPassThrough);

	// Object: Function CommonUI.CommonButtonBase.HandleFocusReceived
	// Flags: [Native|Protected]
	// Offset: 0x10170b230
	// Return & Params: [ Num(0) Size(0x0) ]
	void HandleFocusReceived();

	// Object: Function CommonUI.CommonButtonBase.HandleButtonReleased
	// Flags: [Final|Native|Protected]
	// Offset: 0x10170b208
	// Return & Params: [ Num(0) Size(0x0) ]
	void HandleButtonReleased();

	// Object: Function CommonUI.CommonButtonBase.HandleButtonPressed
	// Flags: [Final|Native|Protected]
	// Offset: 0x10170b21c
	// Return & Params: [ Num(0) Size(0x0) ]
	void HandleButtonPressed();

	// Object: Function CommonUI.CommonButtonBase.HandleButtonClicked
	// Flags: [Final|Native|Protected]
	// Offset: 0x10170b24c
	// Return & Params: [ Num(0) Size(0x0) ]
	void HandleButtonClicked();

	// Object: Function CommonUI.CommonButtonBase.GetStyle
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10170bc20
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UCommonButtonStyle* GetStyle();

	// Object: Function CommonUI.CommonButtonBase.GetSingleMaterialStyleMID
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10170b734
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UMaterialInstanceDynamic* GetSingleMaterialStyleMID();

	// Object: Function CommonUI.CommonButtonBase.GetShouldSelectUponReceivingFocus
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10170bcd4
	// Return & Params: [ Num(1) Size(0x1) ]
	bool GetShouldSelectUponReceivingFocus();

	// Object: Function CommonUI.CommonButtonBase.GetSelected
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10170bda4
	// Return & Params: [ Num(1) Size(0x1) ]
	bool GetSelected();

	// Object: Function CommonUI.CommonButtonBase.GetIsFocusable
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10170b768
	// Return & Params: [ Num(1) Size(0x1) ]
	bool GetIsFocusable();

	// Object: Function CommonUI.CommonButtonBase.GetInputAction
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10170b824
	// Return & Params: [ Num(2) Size(0x11) ]
	bool GetInputAction(struct FDataTableRowHandle& InputActionRow);

	// Object: Function CommonUI.CommonButtonBase.GetCurrentTextStyleClass
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10170baa0
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UCommonTextStyle* GetCurrentTextStyleClass();

	// Object: Function CommonUI.CommonButtonBase.GetCurrentTextStyle
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10170bad4
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UCommonTextStyle* GetCurrentTextStyle();

	// Object: Function CommonUI.CommonButtonBase.GetCurrentCustomPadding
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10170bb08
	// Return & Params: [ Num(1) Size(0x10) ]
	void GetCurrentCustomPadding(struct FMargin& OutCustomPadding);

	// Object: Function CommonUI.CommonButtonBase.GetCurrentButtonPadding
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10170bb94
	// Return & Params: [ Num(1) Size(0x10) ]
	void GetCurrentButtonPadding(struct FMargin& OutButtonPadding);

	// Object: Function CommonUI.CommonButtonBase.DisableButtonWithReason
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10170c350
	// Return & Params: [ Num(1) Size(0x18) ]
	void DisableButtonWithReason(struct FText& DisabledReason);

	// Object: Function CommonUI.CommonButtonBase.ClearSelection
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10170bd90
	// Return & Params: [ Num(0) Size(0x0) ]
	void ClearSelection();

	// Object: Function CommonUI.CommonButtonBase.BP_OnUnhovered
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103a48564
	// Return & Params: [ Num(0) Size(0x0) ]
	void BP_OnUnhovered();

	// Object: Function CommonUI.CommonButtonBase.BP_OnSelected
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103a48564
	// Return & Params: [ Num(0) Size(0x0) ]
	void BP_OnSelected();

	// Object: Function CommonUI.CommonButtonBase.BP_OnHovered
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103a48564
	// Return & Params: [ Num(0) Size(0x0) ]
	void BP_OnHovered();

	// Object: Function CommonUI.CommonButtonBase.BP_OnEnabled
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103a48564
	// Return & Params: [ Num(0) Size(0x0) ]
	void BP_OnEnabled();

	// Object: Function CommonUI.CommonButtonBase.BP_OnDoubleClicked
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103a48564
	// Return & Params: [ Num(0) Size(0x0) ]
	void BP_OnDoubleClicked();

	// Object: Function CommonUI.CommonButtonBase.BP_OnDisabled
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103a48564
	// Return & Params: [ Num(0) Size(0x0) ]
	void BP_OnDisabled();

	// Object: Function CommonUI.CommonButtonBase.BP_OnDeselected
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103a48564
	// Return & Params: [ Num(0) Size(0x0) ]
	void BP_OnDeselected();

	// Object: Function CommonUI.CommonButtonBase.BP_OnClicked
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103a48564
	// Return & Params: [ Num(0) Size(0x0) ]
	void BP_OnClicked();
};

// Object: Class CommonUI.CommonBoundActionButton
// Inherited Bytes: 0xfe0 | Struct Size: 0xff0
struct UCommonBoundActionButton : UCommonButtonBase {
	// Fields
	struct UCommonTextBlock* Text_ActionName; // Offset: 0xfd8 | Size: 0x8
	char pad_0xFE8[0x8]; // Offset: 0xfe8 | Size: 0x8

	// Functions

	// Object: Function CommonUI.CommonBoundActionButton.OnUpdateInputAction
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103a48564
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnUpdateInputAction();
};

// Object: Class CommonUI.CommonButtonStyle
// Inherited Bytes: 0x28 | Struct Size: 0x830
struct UCommonButtonStyle : UObject {
	// Fields
	bool bSingleMaterial; // Offset: 0x28 | Size: 0x1
	char pad_0x29[0x7]; // Offset: 0x29 | Size: 0x7
	struct FSlateBrush SingleMaterialBrush; // Offset: 0x30 | Size: 0xe0
	struct FSlateBrush NormalBase; // Offset: 0x110 | Size: 0xe0
	struct FSlateBrush NormalHovered; // Offset: 0x1f0 | Size: 0xe0
	struct FSlateBrush NormalPressed; // Offset: 0x2d0 | Size: 0xe0
	struct FSlateBrush SelectedBase; // Offset: 0x3b0 | Size: 0xe0
	struct FSlateBrush SelectedHovered; // Offset: 0x490 | Size: 0xe0
	struct FSlateBrush SelectedPressed; // Offset: 0x570 | Size: 0xe0
	struct FSlateBrush Disabled; // Offset: 0x650 | Size: 0xe0
	struct FMargin ButtonPadding; // Offset: 0x730 | Size: 0x10
	struct FMargin CustomPadding; // Offset: 0x740 | Size: 0x10
	int32_t MinWidth; // Offset: 0x750 | Size: 0x4
	int32_t MinHeight; // Offset: 0x754 | Size: 0x4
	struct UCommonTextStyle* NormalTextStyle; // Offset: 0x758 | Size: 0x8
	struct UCommonTextStyle* NormalHoveredTextStyle; // Offset: 0x760 | Size: 0x8
	struct UCommonTextStyle* SelectedTextStyle; // Offset: 0x768 | Size: 0x8
	struct UCommonTextStyle* SelectedHoveredTextStyle; // Offset: 0x770 | Size: 0x8
	struct UCommonTextStyle* DisabledTextStyle; // Offset: 0x778 | Size: 0x8
	struct FSlateSound PressedSlateSound; // Offset: 0x780 | Size: 0x18
	struct FCommonButtonStyleOptionalSlateSound SelectedPressedSlateSound; // Offset: 0x798 | Size: 0x20
	struct FCommonButtonStyleOptionalSlateSound DisabledPressedSlateSound; // Offset: 0x7b8 | Size: 0x20
	struct FSlateSound HoveredSlateSound; // Offset: 0x7d8 | Size: 0x18
	struct FCommonButtonStyleOptionalSlateSound SelectedHoveredSlateSound; // Offset: 0x7f0 | Size: 0x20
	struct FCommonButtonStyleOptionalSlateSound DisabledHoveredSlateSound; // Offset: 0x810 | Size: 0x20

	// Functions

	// Object: Function CommonUI.CommonButtonStyle.GetSelectedTextStyle
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1017091a8
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UCommonTextStyle* GetSelectedTextStyle();

	// Object: Function CommonUI.CommonButtonStyle.GetSelectedPressedBrush
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1017095bc
	// Return & Params: [ Num(1) Size(0xe0) ]
	void GetSelectedPressedBrush(struct FSlateBrush& Brush);

	// Object: Function CommonUI.CommonButtonStyle.GetSelectedHoveredTextStyle
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x101709174
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UCommonTextStyle* GetSelectedHoveredTextStyle();

	// Object: Function CommonUI.CommonButtonStyle.GetSelectedHoveredBrush
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10170981c
	// Return & Params: [ Num(1) Size(0xe0) ]
	void GetSelectedHoveredBrush(struct FSlateBrush& Brush);

	// Object: Function CommonUI.CommonButtonStyle.GetSelectedBaseBrush
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x101709a7c
	// Return & Params: [ Num(1) Size(0xe0) ]
	void GetSelectedBaseBrush(struct FSlateBrush& Brush);

	// Object: Function CommonUI.CommonButtonStyle.GetNormalTextStyle
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x101709210
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UCommonTextStyle* GetNormalTextStyle();

	// Object: Function CommonUI.CommonButtonStyle.GetNormalPressedBrush
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x101709cdc
	// Return & Params: [ Num(1) Size(0xe0) ]
	void GetNormalPressedBrush(struct FSlateBrush& Brush);

	// Object: Function CommonUI.CommonButtonStyle.GetNormalHoveredTextStyle
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1017091dc
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UCommonTextStyle* GetNormalHoveredTextStyle();

	// Object: Function CommonUI.CommonButtonStyle.GetNormalHoveredBrush
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x101709f3c
	// Return & Params: [ Num(1) Size(0xe0) ]
	void GetNormalHoveredBrush(struct FSlateBrush& Brush);

	// Object: Function CommonUI.CommonButtonStyle.GetNormalBaseBrush
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10170a19c
	// Return & Params: [ Num(1) Size(0xe0) ]
	void GetNormalBaseBrush(struct FSlateBrush& Brush);

	// Object: Function CommonUI.CommonButtonStyle.GetMaterialBrush
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10170a3fc
	// Return & Params: [ Num(1) Size(0xe0) ]
	void GetMaterialBrush(struct FSlateBrush& Brush);

	// Object: Function CommonUI.CommonButtonStyle.GetDisabledTextStyle
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x101709140
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UCommonTextStyle* GetDisabledTextStyle();

	// Object: Function CommonUI.CommonButtonStyle.GetDisabledBrush
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10170935c
	// Return & Params: [ Num(1) Size(0xe0) ]
	void GetDisabledBrush(struct FSlateBrush& Brush);

	// Object: Function CommonUI.CommonButtonStyle.GetCustomPadding
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x101709244
	// Return & Params: [ Num(1) Size(0x10) ]
	void GetCustomPadding(struct FMargin& OutCustomPadding);

	// Object: Function CommonUI.CommonButtonStyle.GetButtonPadding
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1017092d0
	// Return & Params: [ Num(1) Size(0x10) ]
	void GetButtonPadding(struct FMargin& OutButtonPadding);
};

// Object: Class CommonUI.CommonButtonInternalBase
// Inherited Bytes: 0x5d0 | Struct Size: 0x630
struct UCommonButtonInternalBase : UButton {
	// Fields
	char pad_0x5D0[0x8]; // Offset: 0x5d0 | Size: 0x8
	struct FMulticastInlineDelegate OnDoubleClicked; // Offset: 0x5d8 | Size: 0x10
	char pad_0x5E8[0x10]; // Offset: 0x5e8 | Size: 0x10
	int32_t MinWidth; // Offset: 0x5f8 | Size: 0x4
	int32_t MinHeight; // Offset: 0x5fc | Size: 0x4
	bool bButtonEnabled; // Offset: 0x600 | Size: 0x1
	bool bInteractionEnabled; // Offset: 0x601 | Size: 0x1
	char pad_0x602[0x2e]; // Offset: 0x602 | Size: 0x2e
};

// Object: Class CommonUI.CommonWidgetGroupBase
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UCommonWidgetGroupBase : UObject {
	// Functions

	// Object: Function CommonUI.CommonWidgetGroupBase.RemoveWidget
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10171d69c
	// Return & Params: [ Num(1) Size(0x8) ]
	void RemoveWidget(struct UWidget* InWidget);

	// Object: Function CommonUI.CommonWidgetGroupBase.RemoveAll
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10171d688
	// Return & Params: [ Num(0) Size(0x0) ]
	void RemoveAll();

	// Object: Function CommonUI.CommonWidgetGroupBase.AddWidget
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10171d71c
	// Return & Params: [ Num(1) Size(0x8) ]
	void AddWidget(struct UWidget* InWidget);
};

// Object: Class CommonUI.CommonButtonGroupBase
// Inherited Bytes: 0x28 | Struct Size: 0x110
struct UCommonButtonGroupBase : UCommonWidgetGroupBase {
	// Fields
	struct FMulticastInlineDelegate OnSelectedButtonBaseChanged; // Offset: 0x28 | Size: 0x10
	char pad_0x38[0x18]; // Offset: 0x38 | Size: 0x18
	struct FMulticastInlineDelegate OnHoveredButtonBaseChanged; // Offset: 0x50 | Size: 0x10
	char pad_0x60[0x18]; // Offset: 0x60 | Size: 0x18
	struct FMulticastInlineDelegate OnButtonBaseClicked; // Offset: 0x78 | Size: 0x10
	char pad_0x88[0x18]; // Offset: 0x88 | Size: 0x18
	struct FMulticastInlineDelegate OnButtonBaseDoubleClicked; // Offset: 0xa0 | Size: 0x10
	char pad_0xB0[0x18]; // Offset: 0xb0 | Size: 0x18
	struct FMulticastInlineDelegate OnSelectionCleared; // Offset: 0xc8 | Size: 0x10
	char pad_0xD8[0x18]; // Offset: 0xd8 | Size: 0x18
	bool bSelectionRequired; // Offset: 0xf0 | Size: 0x1
	char pad_0xF1[0x1f]; // Offset: 0xf1 | Size: 0x1f

	// Functions

	// Object: Function CommonUI.CommonButtonGroupBase.SetSelectionRequired
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1017106e8
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetSelectionRequired(bool bRequireSelection);

	// Object: Function CommonUI.CommonButtonGroupBase.SelectPreviousButton
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1017105c4
	// Return & Params: [ Num(1) Size(0x1) ]
	void SelectPreviousButton(bool bAllowWrap);

	// Object: Function CommonUI.CommonButtonGroupBase.SelectNextButton
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10171064c
	// Return & Params: [ Num(1) Size(0x1) ]
	void SelectNextButton(bool bAllowWrap);

	// Object: Function CommonUI.CommonButtonGroupBase.SelectButtonAtIndex
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101710544
	// Return & Params: [ Num(1) Size(0x4) ]
	void SelectButtonAtIndex(int32_t ButtonIndex);

	// Object: Function CommonUI.CommonButtonGroupBase.OnSelectionStateChangedBase
	// Flags: [Native|Protected]
	// Offset: 0x101710244
	// Return & Params: [ Num(2) Size(0x9) ]
	void OnSelectionStateChangedBase(struct UCommonButtonBase* BaseButton, bool bIsSelected);

	// Object: Function CommonUI.CommonButtonGroupBase.OnHandleButtonBaseDoubleClicked
	// Flags: [Native|Protected]
	// Offset: 0x101710134
	// Return & Params: [ Num(1) Size(0x8) ]
	void OnHandleButtonBaseDoubleClicked(struct UCommonButtonBase* BaseButton);

	// Object: Function CommonUI.CommonButtonGroupBase.OnHandleButtonBaseClicked
	// Flags: [Native|Protected]
	// Offset: 0x1017101bc
	// Return & Params: [ Num(1) Size(0x8) ]
	void OnHandleButtonBaseClicked(struct UCommonButtonBase* BaseButton);

	// Object: Function CommonUI.CommonButtonGroupBase.OnButtonBaseUnhovered
	// Flags: [Native|Protected]
	// Offset: 0x101710024
	// Return & Params: [ Num(1) Size(0x8) ]
	void OnButtonBaseUnhovered(struct UCommonButtonBase* BaseButton);

	// Object: Function CommonUI.CommonButtonGroupBase.OnButtonBaseHovered
	// Flags: [Native|Protected]
	// Offset: 0x1017100ac
	// Return & Params: [ Num(1) Size(0x8) ]
	void OnButtonBaseHovered(struct UCommonButtonBase* BaseButton);

	// Object: Function CommonUI.CommonButtonGroupBase.HasAnyButtons
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x101710354
	// Return & Params: [ Num(1) Size(0x1) ]
	bool HasAnyButtons();

	// Object: Function CommonUI.CommonButtonGroupBase.GetSelectedButtonIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x101710510
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetSelectedButtonIndex();

	// Object: Function CommonUI.CommonButtonGroupBase.GetSelectedButtonBase
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x101710388
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UCommonButtonBase* GetSelectedButtonBase();

	// Object: Function CommonUI.CommonButtonGroupBase.GetHoveredButtonIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1017104dc
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetHoveredButtonIndex();

	// Object: Function CommonUI.CommonButtonGroupBase.GetButtonCount
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x101710320
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetButtonCount();

	// Object: Function CommonUI.CommonButtonGroupBase.GetButtonBaseAtIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1017103bc
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UCommonButtonBase* GetButtonBaseAtIndex(int32_t Index);

	// Object: Function CommonUI.CommonButtonGroupBase.FindButtonIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10171044c
	// Return & Params: [ Num(2) Size(0xc) ]
	int32_t FindButtonIndex(struct UCommonButtonBase* ButtonToFind);

	// Object: Function CommonUI.CommonButtonGroupBase.DeselectAll
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1017106d4
	// Return & Params: [ Num(0) Size(0x0) ]
	void DeselectAll();
};

// Object: Class CommonUI.CommonCustomNavigation
// Inherited Bytes: 0x2f0 | Struct Size: 0x300
struct UCommonCustomNavigation : UBorder {
	// Fields
	struct FDelegate OnNavigationEvent; // Offset: 0x2f0 | Size: 0x10
};

// Object: Class CommonUI.CommonTextBlock
// Inherited Bytes: 0x420 | Struct Size: 0x450
struct UCommonTextBlock : UTextBlock {
	// Fields
	struct UCommonTextStyle* Style; // Offset: 0x420 | Size: 0x8
	struct UCommonTextScrollStyle* ScrollStyle; // Offset: 0x428 | Size: 0x8
	bool bDisplayAllCaps; // Offset: 0x430 | Size: 0x1
	bool bAutoCollapseWithEmptyText; // Offset: 0x431 | Size: 0x1
	char pad_0x432[0x2]; // Offset: 0x432 | Size: 0x2
	float MobileFontSizeMultiplier; // Offset: 0x434 | Size: 0x4
	char pad_0x438[0x18]; // Offset: 0x438 | Size: 0x18

	// Functions

	// Object: Function CommonUI.CommonTextBlock.SetWrapTextWidth
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1017198cc
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetWrapTextWidth(int32_t InWrapTextAt);

	// Object: Function CommonUI.CommonTextBlock.SetTextCase
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101719844
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetTextCase(bool bUseAllCaps);

	// Object: Function CommonUI.CommonTextBlock.SetStyle
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1017197c4
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetStyle(struct UCommonTextStyle* InStyle);

	// Object: Function CommonUI.CommonTextBlock.ResetScrollState
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1017197b0
	// Return & Params: [ Num(0) Size(0x0) ]
	void ResetScrollState();
};

// Object: Class CommonUI.CommonDateTimeTextBlock
// Inherited Bytes: 0x450 | Struct Size: 0x490
struct UCommonDateTimeTextBlock : UCommonTextBlock {
	// Fields
	char pad_0x450[0x40]; // Offset: 0x450 | Size: 0x40

	// Functions

	// Object: Function CommonUI.CommonDateTimeTextBlock.SetTimespanValue
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x10171131c
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetTimespanValue(struct FTimespan InTimespan);

	// Object: Function CommonUI.CommonDateTimeTextBlock.SetDateTimeValue
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x101711398
	// Return & Params: [ Num(3) Size(0x10) ]
	void SetDateTimeValue(struct FDateTime InDateTime, bool bShowAsCountdown, float InRefreshDelay);

	// Object: Function CommonUI.CommonDateTimeTextBlock.SetCountDownCompletionText
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1017111c0
	// Return & Params: [ Num(1) Size(0x18) ]
	void SetCountDownCompletionText(struct FText InCompletionText);

	// Object: Function CommonUI.CommonDateTimeTextBlock.GetDateTime
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10171118c
	// Return & Params: [ Num(1) Size(0x8) ]
	struct FDateTime GetDateTime();
};

// Object: Class CommonUI.CommonGameViewportClient
// Inherited Bytes: 0x328 | Struct Size: 0x368
struct UCommonGameViewportClient : UGameViewportClient {
	// Fields
	char pad_0x328[0x40]; // Offset: 0x328 | Size: 0x40
};

// Object: Class CommonUI.CommonHierarchicalScrollBox
// Inherited Bytes: 0xd40 | Struct Size: 0xd40
struct UCommonHierarchicalScrollBox : UScrollBox {
};

// Object: Class CommonUI.CommonLazyImage
// Inherited Bytes: 0x2a0 | Struct Size: 0x3c0
struct UCommonLazyImage : UImage {
	// Fields
	struct FSlateBrush LoadingBackgroundBrush; // Offset: 0x2a0 | Size: 0xe0
	struct FName MaterialTextureParamName; // Offset: 0x380 | Size: 0x8
	struct FMulticastInlineDelegate BP_OnLoadingStateChanged; // Offset: 0x388 | Size: 0x10
	char pad_0x398[0x28]; // Offset: 0x398 | Size: 0x28

	// Functions

	// Object: Function CommonUI.CommonLazyImage.SetMaterialTextureParamName
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101711b68
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetMaterialTextureParamName(struct FName TextureParamName);

	// Object: Function CommonUI.CommonLazyImage.SetBrushFromLazyTexture
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101711dc0
	// Return & Params: [ Num(2) Size(0x29) ]
	void SetBrushFromLazyTexture(struct TSoftObjectPtr<UTexture2D>& LazyTexture, bool bMatchSize);

	// Object: Function CommonUI.CommonLazyImage.SetBrushFromLazyMaterial
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101711d18
	// Return & Params: [ Num(1) Size(0x28) ]
	void SetBrushFromLazyMaterial(struct TSoftObjectPtr<UMaterialInterface>& LazyMaterial);

	// Object: Function CommonUI.CommonLazyImage.SetBrushFromLazyDisplayAsset
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101711c1c
	// Return & Params: [ Num(2) Size(0x29) ]
	void SetBrushFromLazyDisplayAsset(struct TSoftObjectPtr<UObject>& LazyObject, bool bMatchTextureSize);

	// Object: Function CommonUI.CommonLazyImage.IsLoading
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x101711be8
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsLoading();
};

// Object: Class CommonUI.CommonLazyWidget
// Inherited Bytes: 0x138 | Struct Size: 0x2a0
struct UCommonLazyWidget : UWidget {
	// Fields
	char pad_0x138[0x8]; // Offset: 0x138 | Size: 0x8
	struct FSlateBrush LoadingBackgroundBrush; // Offset: 0x140 | Size: 0xe0
	struct UUserWidget* Content; // Offset: 0x220 | Size: 0x8
	char pad_0x228[0x28]; // Offset: 0x228 | Size: 0x28
	struct FMulticastInlineDelegate BP_OnLoadingStateChanged; // Offset: 0x250 | Size: 0x10
	char pad_0x260[0x40]; // Offset: 0x260 | Size: 0x40

	// Functions

	// Object: Function CommonUI.CommonLazyWidget.SetLazyContent
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10171238c
	// Return & Params: [ Num(1) Size(0x28) ]
	void SetLazyContent(struct TSoftClassPtr<UObject> SoftWidget);

	// Object: Function CommonUI.CommonLazyWidget.IsLoading
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10171233c
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsLoading();

	// Object: Function CommonUI.CommonLazyWidget.GetContent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x101712370
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UUserWidget* GetContent();
};

// Object: Class CommonUI.CommonListView
// Inherited Bytes: 0xbf0 | Struct Size: 0xbf0
struct UCommonListView : UListView {
	// Functions

	// Object: Function CommonUI.CommonListView.SetEntrySpacing
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10171274c
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetEntrySpacing(float InEntrySpacing);
};

// Object: Class CommonUI.LoadGuardSlot
// Inherited Bytes: 0x38 | Struct Size: 0x60
struct ULoadGuardSlot : UPanelSlot {
	// Fields
	struct FMargin Padding; // Offset: 0x38 | Size: 0x10
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0x48 | Size: 0x1
	enum class EVerticalAlignment VerticalAlignment; // Offset: 0x49 | Size: 0x1
	char pad_0x4A[0x16]; // Offset: 0x4a | Size: 0x16

	// Functions

	// Object: Function CommonUI.LoadGuardSlot.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101712a94
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment);

	// Object: Function CommonUI.LoadGuardSlot.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101712b94
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetPadding(struct FMargin InPadding);

	// Object: Function CommonUI.LoadGuardSlot.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101712b14
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment);
};

// Object: Class CommonUI.CommonLoadGuard
// Inherited Bytes: 0x150 | Struct Size: 0x2c0
struct UCommonLoadGuard : UContentWidget {
	// Fields
	struct FSlateBrush LoadingBackgroundBrush; // Offset: 0x150 | Size: 0xe0
	enum class EHorizontalAlignment ThrobberAlignment; // Offset: 0x230 | Size: 0x1
	char pad_0x231[0x3]; // Offset: 0x231 | Size: 0x3
	struct FMargin ThrobberPadding; // Offset: 0x234 | Size: 0x10
	char pad_0x244[0x4]; // Offset: 0x244 | Size: 0x4
	struct FText LoadingText; // Offset: 0x248 | Size: 0x18
	struct UCommonTextStyle* TextStyle; // Offset: 0x260 | Size: 0x8
	struct FMulticastInlineDelegate BP_OnLoadingStateChanged; // Offset: 0x268 | Size: 0x10
	struct FSoftObjectPath SpinnerMaterialPath; // Offset: 0x278 | Size: 0x18
	char pad_0x290[0x30]; // Offset: 0x290 | Size: 0x30

	// Functions

	// Object: Function CommonUI.CommonLoadGuard.SetLoadingText
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1017131c0
	// Return & Params: [ Num(1) Size(0x18) ]
	void SetLoadingText(struct FText& InLoadingText);

	// Object: Function CommonUI.CommonLoadGuard.SetIsLoading
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101713138
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetIsLoading(bool bInIsLoading);

	// Object: DelegateFunction CommonUI.CommonLoadGuard.OnAssetLoaded__DelegateSignature
	// Flags: [Public|Delegate]
	// Offset: 0x103a48564
	// Return & Params: [ Num(1) Size(0x8) ]
	void OnAssetLoaded__DelegateSignature(struct UObject* Object);

	// Object: Function CommonUI.CommonLoadGuard.IsLoading
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x101713104
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsLoading();

	// Object: Function CommonUI.CommonLoadGuard.BP_GuardAndLoadAsset
	// Flags: [Final|Native|Private|HasOutParms|BlueprintCallable]
	// Offset: 0x101712fbc
	// Return & Params: [ Num(2) Size(0x38) ]
	void BP_GuardAndLoadAsset(struct TSoftObjectPtr<UObject>& InLazyAsset, struct FDelegate& OnAssetLoaded);
};

// Object: Class CommonUI.CommonNumericTextBlock
// Inherited Bytes: 0x450 | Struct Size: 0x4f0
struct UCommonNumericTextBlock : UCommonTextBlock {
	// Fields
	struct FMulticastInlineDelegate OnInterpolationStartedEvent; // Offset: 0x448 | Size: 0x10
	struct FMulticastInlineDelegate OnInterpolationUpdatedEvent; // Offset: 0x458 | Size: 0x10
	struct FMulticastInlineDelegate OnOutroEvent; // Offset: 0x468 | Size: 0x10
	struct FMulticastInlineDelegate OnInterpolationEndedEvent; // Offset: 0x478 | Size: 0x10
	float CurrentNumericValue; // Offset: 0x488 | Size: 0x4
	enum class ECommonNumericType NumericType; // Offset: 0x48c | Size: 0x1
	struct FCommonNumberFormattingOptions FormattingSpecification; // Offset: 0x490 | Size: 0x14
	float EaseOutInterpolationExponent; // Offset: 0x4a4 | Size: 0x4
	float InterpolationUpdateInterval; // Offset: 0x4a8 | Size: 0x4
	float PostInterpolationShrinkDuration; // Offset: 0x4ac | Size: 0x4
	bool PerformSizeInterpolation; // Offset: 0x4b0 | Size: 0x1
	bool IsPercentage; // Offset: 0x4b1 | Size: 0x1
	char pad_0x4B7[0x39]; // Offset: 0x4b7 | Size: 0x39

	// Functions

	// Object: Function CommonUI.CommonNumericTextBlock.SetNumericType
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101713958
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetNumericType(enum class ECommonNumericType InNumericType);

	// Object: Function CommonUI.CommonNumericTextBlock.SetCurrentValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101713b68
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetCurrentValue(float NewValue);

	// Object: DelegateFunction CommonUI.CommonNumericTextBlock.OnOutro__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a48564
	// Return & Params: [ Num(1) Size(0x8) ]
	void OnOutro__DelegateSignature(struct UCommonNumericTextBlock* NumericTextBlock);

	// Object: DelegateFunction CommonUI.CommonNumericTextBlock.OnInterpolationUpdated__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a48564
	// Return & Params: [ Num(3) Size(0x10) ]
	void OnInterpolationUpdated__DelegateSignature(struct UCommonNumericTextBlock* NumericTextBlock, float LastValue, float NewValue);

	// Object: DelegateFunction CommonUI.CommonNumericTextBlock.OnInterpolationStarted__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a48564
	// Return & Params: [ Num(1) Size(0x8) ]
	void OnInterpolationStarted__DelegateSignature(struct UCommonNumericTextBlock* NumericTextBlock);

	// Object: DelegateFunction CommonUI.CommonNumericTextBlock.OnInterpolationEnded__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a48564
	// Return & Params: [ Num(2) Size(0x9) ]
	void OnInterpolationEnded__DelegateSignature(struct UCommonNumericTextBlock* NumericTextBlock, bool HadCompleted);

	// Object: Function CommonUI.CommonNumericTextBlock.IsInterpolatingNumericValue
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1017139d8
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsInterpolatingNumericValue();

	// Object: Function CommonUI.CommonNumericTextBlock.InterpolateToValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101713a0c
	// Return & Params: [ Num(4) Size(0x10) ]
	void InterpolateToValue(float TargetValue, float MaximumInterpolationDuration, float MinimumChangeRate, float OutroOffset);

	// Object: Function CommonUI.CommonNumericTextBlock.GetTargetValue
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x101713be8
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetTargetValue();
};

// Object: Class CommonUI.CommonPoolableWidgetInterface
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UCommonPoolableWidgetInterface : UInterface {
	// Functions

	// Object: Function CommonUI.CommonPoolableWidgetInterface.OnReleaseToPool
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x101713f58
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnReleaseToPool();

	// Object: Function CommonUI.CommonPoolableWidgetInterface.OnAcquireFromPool
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x101713f74
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnAcquireFromPool();
};

// Object: Class CommonUI.CommonRichTextBlock
// Inherited Bytes: 0xaa0 | Struct Size: 0xae0
struct UCommonRichTextBlock : URichTextBlock {
	// Fields
	enum class ERichTextInlineIconDisplayMode InlineIconDisplayMode; // Offset: 0xaa0 | Size: 0x1
	bool bTintInlineIcon; // Offset: 0xaa1 | Size: 0x1
	char pad_0xAA2[0x6]; // Offset: 0xaa2 | Size: 0x6
	struct UCommonTextStyle* DefaultTextStyleOverrideClass; // Offset: 0xaa8 | Size: 0x8
	float MobileTextBlockScale; // Offset: 0xab0 | Size: 0x4
	char pad_0xAB4[0x4]; // Offset: 0xab4 | Size: 0x4
	struct UCommonTextScrollStyle* ScrollStyle; // Offset: 0xab8 | Size: 0x8
	bool bDisplayAllCaps; // Offset: 0xac0 | Size: 0x1
	char pad_0xAC1[0x1f]; // Offset: 0xac1 | Size: 0x1f
};

// Object: Class CommonUI.CommonRotator
// Inherited Bytes: 0xfe0 | Struct Size: 0x1030
struct UCommonRotator : UCommonButtonBase {
	// Fields
	char pad_0xFE0[0x8]; // Offset: 0xfe0 | Size: 0x8
	struct FMulticastInlineDelegate OnRotated; // Offset: 0xfe8 | Size: 0x10
	char pad_0xFF8[0x18]; // Offset: 0xff8 | Size: 0x18
	struct UCommonTextBlock* MyText; // Offset: 0x1010 | Size: 0x8
	char pad_0x1018[0x18]; // Offset: 0x1018 | Size: 0x18

	// Functions

	// Object: Function CommonUI.CommonRotator.ShiftTextRight
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101714490
	// Return & Params: [ Num(0) Size(0x0) ]
	void ShiftTextRight();

	// Object: Function CommonUI.CommonRotator.ShiftTextLeft
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1017144a4
	// Return & Params: [ Num(0) Size(0x0) ]
	void ShiftTextLeft();

	// Object: Function CommonUI.CommonRotator.SetSelectedItem
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1017144d4
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetSelectedItem(int32_t InValue);

	// Object: Function CommonUI.CommonRotator.PopulateTextLabels
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101714604
	// Return & Params: [ Num(1) Size(0x10) ]
	void PopulateTextLabels(struct TArray<struct FText> Labels);

	// Object: Function CommonUI.CommonRotator.GetSelectedText
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10171455c
	// Return & Params: [ Num(1) Size(0x18) ]
	struct FText GetSelectedText();

	// Object: Function CommonUI.CommonRotator.GetSelectedIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1017144b8
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetSelectedIndex();

	// Object: Function CommonUI.CommonRotator.BP_OnOptionsPopulated
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103a48564
	// Return & Params: [ Num(1) Size(0x4) ]
	void BP_OnOptionsPopulated(int32_t count);

	// Object: Function CommonUI.CommonRotator.BP_OnOptionSelected
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103a48564
	// Return & Params: [ Num(1) Size(0x4) ]
	void BP_OnOptionSelected(int32_t Index);
};

// Object: Class CommonUI.CommonTabListWidgetBase
// Inherited Bytes: 0x288 | Struct Size: 0x358
struct UCommonTabListWidgetBase : UCommonUserWidget {
	// Fields
	struct FMulticastInlineDelegate OnTabSelected; // Offset: 0x288 | Size: 0x10
	struct FMulticastInlineDelegate OnTabButtonCreation; // Offset: 0x298 | Size: 0x10
	struct FMulticastInlineDelegate OnTabButtonRemoval; // Offset: 0x2a8 | Size: 0x10
	struct FDataTableRowHandle NextTabInputActionData; // Offset: 0x2b8 | Size: 0x10
	struct FDataTableRowHandle PreviousTabInputActionData; // Offset: 0x2c8 | Size: 0x10
	bool bAutoListenForInput; // Offset: 0x2d8 | Size: 0x1
	char pad_0x2D9[0x3]; // Offset: 0x2d9 | Size: 0x3
	struct TWeakObjectPtr<struct UCommonAnimatedSwitcher> LinkedSwitcher; // Offset: 0x2dc | Size: 0x8
	char pad_0x2E4[0x4]; // Offset: 0x2e4 | Size: 0x4
	struct UCommonButtonGroupBase* TabButtonGroup; // Offset: 0x2e8 | Size: 0x8
	char pad_0x2F0[0x8]; // Offset: 0x2f0 | Size: 0x8
	struct TMap<struct FName, struct FCommonRegisteredTabInfo> RegisteredTabsByID; // Offset: 0x2f8 | Size: 0x50
	char pad_0x348[0x10]; // Offset: 0x348 | Size: 0x10

	// Functions

	// Object: Function CommonUI.CommonTabListWidgetBase.SetTabVisibility
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101715670
	// Return & Params: [ Num(2) Size(0x9) ]
	void SetTabVisibility(struct FName TabNameID, enum class ESlateVisibility NewVisibility);

	// Object: Function CommonUI.CommonTabListWidgetBase.SetTabInteractionEnabled
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1017154c8
	// Return & Params: [ Num(2) Size(0x9) ]
	void SetTabInteractionEnabled(struct FName TabNameID, bool bEnable);

	// Object: Function CommonUI.CommonTabListWidgetBase.SetTabEnabled
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10171559c
	// Return & Params: [ Num(2) Size(0x9) ]
	void SetTabEnabled(struct FName TabNameID, bool bEnable);

	// Object: Function CommonUI.CommonTabListWidgetBase.SetListeningForInput
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x101715300
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetListeningForInput(bool bShouldListen);

	// Object: Function CommonUI.CommonTabListWidgetBase.SetLinkedSwitcher
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x101715b14
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetLinkedSwitcher(struct UCommonAnimatedSwitcher* CommonSwitcher);

	// Object: Function CommonUI.CommonTabListWidgetBase.SelectTabByID
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101715800
	// Return & Params: [ Num(3) Size(0xa) ]
	bool SelectTabByID(struct FName TabNameID, bool bSuppressClickFeedback);

	// Object: Function CommonUI.CommonTabListWidgetBase.RemoveTab
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10171592c
	// Return & Params: [ Num(2) Size(0x9) ]
	bool RemoveTab(struct FName TabNameID);

	// Object: Function CommonUI.CommonTabListWidgetBase.RemoveAllTabs
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101715918
	// Return & Params: [ Num(0) Size(0x0) ]
	void RemoveAllTabs();

	// Object: Function CommonUI.CommonTabListWidgetBase.RegisterTab
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1017159bc
	// Return & Params: [ Num(4) Size(0x19) ]
	bool RegisterTab(struct FName TabNameID, struct UCommonButtonBase* ButtonWidgetType, struct UWidget* ContentWidget);

	// Object: DelegateFunction CommonUI.CommonTabListWidgetBase.OnTabSelected__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a48564
	// Return & Params: [ Num(1) Size(0x8) ]
	void OnTabSelected__DelegateSignature(struct FName TabId);

	// Object: DelegateFunction CommonUI.CommonTabListWidgetBase.OnTabButtonRemoval__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a48564
	// Return & Params: [ Num(2) Size(0x10) ]
	void OnTabButtonRemoval__DelegateSignature(struct FName TabId, struct UCommonButtonBase* TabButton);

	// Object: DelegateFunction CommonUI.CommonTabListWidgetBase.OnTabButtonCreation__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a48564
	// Return & Params: [ Num(2) Size(0x10) ]
	void OnTabButtonCreation__DelegateSignature(struct FName TabId, struct UCommonButtonBase* TabButton);

	// Object: Function CommonUI.CommonTabListWidgetBase.HandleTabRemoval
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x101715160
	// Return & Params: [ Num(2) Size(0x10) ]
	void HandleTabRemoval(struct FName TabNameID, struct UCommonButtonBase* TabButton);

	// Object: Function CommonUI.CommonTabListWidgetBase.HandleTabCreation
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x101715230
	// Return & Params: [ Num(2) Size(0x10) ]
	void HandleTabCreation(struct FName TabNameID, struct UCommonButtonBase* TabButton);

	// Object: Function CommonUI.CommonTabListWidgetBase.HandleTabButtonSelected
	// Flags: [Final|Native|Protected]
	// Offset: 0x101715004
	// Return & Params: [ Num(2) Size(0xc) ]
	void HandleTabButtonSelected(struct UCommonButtonBase* SelectedTabButton, int32_t ButtonIndex);

	// Object: Function CommonUI.CommonTabListWidgetBase.HandlePreviousTabInputAction
	// Flags: [Final|Native|Protected|HasOutParms]
	// Offset: 0x101714f78
	// Return & Params: [ Num(1) Size(0x1) ]
	void HandlePreviousTabInputAction(bool& bPassThrough);

	// Object: Function CommonUI.CommonTabListWidgetBase.HandlePreLinkedSwitcherChanged_BP
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103a48564
	// Return & Params: [ Num(0) Size(0x0) ]
	void HandlePreLinkedSwitcherChanged_BP();

	// Object: Function CommonUI.CommonTabListWidgetBase.HandlePostLinkedSwitcherChanged_BP
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103a48564
	// Return & Params: [ Num(0) Size(0x0) ]
	void HandlePostLinkedSwitcherChanged_BP();

	// Object: Function CommonUI.CommonTabListWidgetBase.HandleNextTabInputAction
	// Flags: [Final|Native|Protected|HasOutParms]
	// Offset: 0x101714eec
	// Return & Params: [ Num(1) Size(0x1) ]
	void HandleNextTabInputAction(bool& bPassThrough);

	// Object: Function CommonUI.CommonTabListWidgetBase.GetTabIdAtIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10171573c
	// Return & Params: [ Num(2) Size(0xc) ]
	struct FName GetTabIdAtIndex(int32_t Index);

	// Object: Function CommonUI.CommonTabListWidgetBase.GetTabCount
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1017158e4
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetTabCount();

	// Object: Function CommonUI.CommonTabListWidgetBase.GetTabButtonBaseByID
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x1017150d0
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UCommonButtonBase* GetTabButtonBaseByID(struct FName TabNameID);

	// Object: Function CommonUI.CommonTabListWidgetBase.GetSelectedTabId
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1017157cc
	// Return & Params: [ Num(1) Size(0x8) ]
	struct FName GetSelectedTabId();

	// Object: Function CommonUI.CommonTabListWidgetBase.GetLinkedSwitcher
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x101715ae0
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UCommonAnimatedSwitcher* GetLinkedSwitcher();

	// Object: Function CommonUI.CommonTabListWidgetBase.GetActiveTab
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x101715b9c
	// Return & Params: [ Num(1) Size(0x8) ]
	struct FName GetActiveTab();

	// Object: Function CommonUI.CommonTabListWidgetBase.DisableTabWithReason
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101715390
	// Return & Params: [ Num(2) Size(0x20) ]
	void DisableTabWithReason(struct FName TabNameID, struct FText& reason);
};

// Object: Class CommonUI.CommonTextStyle
// Inherited Bytes: 0x28 | Struct Size: 0x1c0
struct UCommonTextStyle : UObject {
	// Fields
	struct FSlateFontInfo Font; // Offset: 0x28 | Size: 0x60
	struct FLinearColor Color; // Offset: 0x88 | Size: 0x10
	bool bUsesDropShadow; // Offset: 0x98 | Size: 0x1
	char pad_0x99[0x3]; // Offset: 0x99 | Size: 0x3
	struct FVector2D ShadowOffset; // Offset: 0x9c | Size: 0x8
	struct FLinearColor ShadowColor; // Offset: 0xa4 | Size: 0x10
	struct FMargin Margin; // Offset: 0xb4 | Size: 0x10
	char pad_0xC4[0xc]; // Offset: 0xc4 | Size: 0xc
	struct FSlateBrush StrikeBrush; // Offset: 0xd0 | Size: 0xe0
	float LineHeightPercentage; // Offset: 0x1b0 | Size: 0x4
	char pad_0x1B4[0xc]; // Offset: 0x1b4 | Size: 0xc

	// Functions

	// Object: Function CommonUI.CommonTextStyle.GetStrikeBrush
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1017189c4
	// Return & Params: [ Num(1) Size(0xe0) ]
	void GetStrikeBrush(struct FSlateBrush& OutStrikeBrush);

	// Object: Function CommonUI.CommonTextStyle.GetShadowOffset
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x101718cac
	// Return & Params: [ Num(1) Size(0x8) ]
	void GetShadowOffset(struct FVector2D& OutShadowOffset);

	// Object: Function CommonUI.CommonTextStyle.GetShadowColor
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x101718c24
	// Return & Params: [ Num(1) Size(0x10) ]
	void GetShadowColor(struct FLinearColor& OutColor);

	// Object: Function CommonUI.CommonTextStyle.GetMargin
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x101718d68
	// Return & Params: [ Num(1) Size(0x10) ]
	void GetMargin(struct FMargin& OutMargin);

	// Object: Function CommonUI.CommonTextStyle.GetLineHeightPercentage
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x101718d34
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetLineHeightPercentage();

	// Object: Function CommonUI.CommonTextStyle.GetFont
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x101718e7c
	// Return & Params: [ Num(1) Size(0x60) ]
	void GetFont(struct FSlateFontInfo& OutFont);

	// Object: Function CommonUI.CommonTextStyle.GetColor
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x101718df4
	// Return & Params: [ Num(1) Size(0x10) ]
	void GetColor(struct FLinearColor& OutColor);
};

// Object: Class CommonUI.CommonTextScrollStyle
// Inherited Bytes: 0x28 | Struct Size: 0x40
struct UCommonTextScrollStyle : UObject {
	// Fields
	float Speed; // Offset: 0x28 | Size: 0x4
	float StartDelay; // Offset: 0x2c | Size: 0x4
	float EndDelay; // Offset: 0x30 | Size: 0x4
	float FadeInDelay; // Offset: 0x34 | Size: 0x4
	float FadeOutDelay; // Offset: 0x38 | Size: 0x4
	char pad_0x3C[0x4]; // Offset: 0x3c | Size: 0x4
};

// Object: Class CommonUI.CommonTileView
// Inherited Bytes: 0xc10 | Struct Size: 0xc10
struct UCommonTileView : UTileView {
};

// Object: Class CommonUI.CommonTreeView
// Inherited Bytes: 0xc50 | Struct Size: 0xc50
struct UCommonTreeView : UTreeView {
};

// Object: Class CommonUI.CommonUIActionRouterBase
// Inherited Bytes: 0x30 | Struct Size: 0x100
struct UCommonUIActionRouterBase : ULocalPlayerSubsystem {
	// Fields
	char pad_0x30[0xd0]; // Offset: 0x30 | Size: 0xd0
};

// Object: Class CommonUI.CommonUIEditorSettings
// Inherited Bytes: 0x28 | Struct Size: 0xa8
struct UCommonUIEditorSettings : UObject {
	// Fields
	struct TSoftClassPtr<UObject> TemplateTextStyle; // Offset: 0x28 | Size: 0x28
	struct TSoftClassPtr<UObject> TemplateButtonStyle; // Offset: 0x50 | Size: 0x28
	struct TSoftClassPtr<UObject> TemplateBorderStyle; // Offset: 0x78 | Size: 0x28
	char pad_0xA0[0x8]; // Offset: 0xa0 | Size: 0x8
};

// Object: Class CommonUI.CommonUIInputSettings
// Inherited Bytes: 0x28 | Struct Size: 0x78
struct UCommonUIInputSettings : UObject {
	// Fields
	bool bLinkCursorToGamepadFocus; // Offset: 0x28 | Size: 0x1
	char pad_0x29[0x3]; // Offset: 0x29 | Size: 0x3
	int32_t UIActionProcessingPriority; // Offset: 0x2c | Size: 0x4
	struct TArray<struct FUIInputAction> InputActions; // Offset: 0x30 | Size: 0x10
	struct TArray<struct FUIInputAction> ActionOverrides; // Offset: 0x40 | Size: 0x10
	struct FCommonAnalogCursorSettings AnalogCursorSettings; // Offset: 0x50 | Size: 0x28
};

// Object: Class CommonUI.CommonUILibrary
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UCommonUILibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object: Function CommonUI.CommonUILibrary.FindParentWidgetOfType
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10171a8a4
	// Return & Params: [ Num(3) Size(0x18) ]
	struct UWidget* FindParentWidgetOfType(struct UWidget* StartingWidget, struct UWidget* Type);
};

// Object: Class CommonUI.CommonUIRichTextData
// Inherited Bytes: 0x28 | Struct Size: 0x30
struct UCommonUIRichTextData : UObject {
	// Fields
	struct UDataTable* InlineIconSet; // Offset: 0x28 | Size: 0x8
};

// Object: Class CommonUI.CommonUISettings
// Inherited Bytes: 0x28 | Struct Size: 0x1b0
struct UCommonUISettings : UObject {
	// Fields
	bool bAutoLoadData; // Offset: 0x28 | Size: 0x1
	char pad_0x29[0x7]; // Offset: 0x29 | Size: 0x7
	struct TSoftObjectPtr<UObject> DefaultImageResourceObject; // Offset: 0x30 | Size: 0x28
	struct TSoftObjectPtr<UMaterialInterface> DefaultThrobberMaterial; // Offset: 0x58 | Size: 0x28
	struct TSoftClassPtr<UObject> DefaultRichTextDataClass; // Offset: 0x80 | Size: 0x28
	char pad_0xA8[0x8]; // Offset: 0xa8 | Size: 0x8
	struct UObject* DefaultImageResourceObjectInstance; // Offset: 0xb0 | Size: 0x8
	struct UMaterialInterface* DefaultThrobberMaterialInstance; // Offset: 0xb8 | Size: 0x8
	struct FSlateBrush DefaultThrobberBrush; // Offset: 0xc0 | Size: 0xe0
	struct UCommonUIRichTextData* RichTextDataInstance; // Offset: 0x1a0 | Size: 0x8
	char pad_0x1A8[0x8]; // Offset: 0x1a8 | Size: 0x8
};

// Object: Class CommonUI.CommonUISubsystemBase
// Inherited Bytes: 0x30 | Struct Size: 0x40
struct UCommonUISubsystemBase : UGameInstanceSubsystem {
	// Fields
	char pad_0x30[0x10]; // Offset: 0x30 | Size: 0x10

	// Functions

	// Object: Function CommonUI.CommonUISubsystemBase.GetInputActionButtonIcon
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10171b100
	// Return & Params: [ Num(4) Size(0x100) ]
	struct FSlateBrush GetInputActionButtonIcon(struct FDataTableRowHandle& InputActionRowHandle, enum class ECommonInputType InputType, struct FName& GamepadName);
};

// Object: Class CommonUI.CommonVideoPlayer
// Inherited Bytes: 0x138 | Struct Size: 0x2a0
struct UCommonVideoPlayer : UWidget {
	// Fields
	struct UMediaSource* Video; // Offset: 0x138 | Size: 0x8
	struct UMediaPlayer* MediaPlayer; // Offset: 0x140 | Size: 0x8
	struct UMediaTexture* MediaTexture; // Offset: 0x148 | Size: 0x8
	struct UMaterial* VideoMaterial; // Offset: 0x150 | Size: 0x8
	struct UMediaSoundComponent* SoundComponent; // Offset: 0x158 | Size: 0x8
	struct FSlateBrush VideoBrush; // Offset: 0x160 | Size: 0xe0
	char pad_0x240[0x60]; // Offset: 0x240 | Size: 0x60
};

// Object: Class CommonUI.CommonVisibilitySwitcher
// Inherited Bytes: 0x160 | Struct Size: 0x188
struct UCommonVisibilitySwitcher : UOverlay {
	// Fields
	enum class ESlateVisibility ShownVisibility; // Offset: 0x160 | Size: 0x1
	char pad_0x161[0x3]; // Offset: 0x161 | Size: 0x3
	int32_t ActiveWidgetIndex; // Offset: 0x164 | Size: 0x4
	bool bAutoActivateSlot; // Offset: 0x168 | Size: 0x1
	bool bActivateFirstSlotOnAdding; // Offset: 0x169 | Size: 0x1
	char pad_0x16A[0x1e]; // Offset: 0x16a | Size: 0x1e

	// Functions

	// Object: Function CommonUI.CommonVisibilitySwitcher.SetActiveWidgetIndex
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10171bf34
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetActiveWidgetIndex(int32_t Index);

	// Object: Function CommonUI.CommonVisibilitySwitcher.SetActiveWidget
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10171be64
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetActiveWidget(struct UWidget* Widget);

	// Object: Function CommonUI.CommonVisibilitySwitcher.IncrementActiveWidgetIndex
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10171bddc
	// Return & Params: [ Num(1) Size(0x1) ]
	void IncrementActiveWidgetIndex(bool bAllowWrapping);

	// Object: Function CommonUI.CommonVisibilitySwitcher.GetActiveWidgetIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10171bf18
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetActiveWidgetIndex();

	// Object: Function CommonUI.CommonVisibilitySwitcher.GetActiveWidget
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10171bee4
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UWidget* GetActiveWidget();

	// Object: Function CommonUI.CommonVisibilitySwitcher.DecrementActiveWidgetIndex
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10171bd54
	// Return & Params: [ Num(1) Size(0x1) ]
	void DecrementActiveWidgetIndex(bool bAllowWrapping);

	// Object: Function CommonUI.CommonVisibilitySwitcher.DeactivateVisibleSlot
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10171bd2c
	// Return & Params: [ Num(0) Size(0x0) ]
	void DeactivateVisibleSlot();

	// Object: Function CommonUI.CommonVisibilitySwitcher.ActivateVisibleSlot
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10171bd40
	// Return & Params: [ Num(0) Size(0x0) ]
	void ActivateVisibleSlot();
};

// Object: Class CommonUI.CommonVisibilitySwitcherSlot
// Inherited Bytes: 0x58 | Struct Size: 0x68
struct UCommonVisibilitySwitcherSlot : UOverlaySlot {
	// Fields
	char pad_0x58[0x10]; // Offset: 0x58 | Size: 0x10
};

// Object: Class CommonUI.CommonVisibilityWidgetBase
// Inherited Bytes: 0x310 | Struct Size: 0x370
struct UCommonVisibilityWidgetBase : UCommonBorder {
	// Fields
	struct TMap<struct FName, bool> VisibilityControls; // Offset: 0x310 | Size: 0x50
	bool bShowForGamepad; // Offset: 0x360 | Size: 0x1
	bool bShowForMouseAndKeyboard; // Offset: 0x361 | Size: 0x1
	bool bShowForTouch; // Offset: 0x362 | Size: 0x1
	enum class ESlateVisibility VisibleType; // Offset: 0x363 | Size: 0x1
	enum class ESlateVisibility HiddenType; // Offset: 0x364 | Size: 0x1
	char pad_0x365[0xb]; // Offset: 0x365 | Size: 0xb

	// Functions

	// Object: Function CommonUI.CommonVisibilityWidgetBase.GetRegisteredPlatforms
	// Flags: [Final|Native|Static|Protected]
	// Offset: 0x10171c640
	// Return & Params: [ Num(1) Size(0x10) ]
	struct TArray<struct FName> GetRegisteredPlatforms();
};

// Object: Class CommonUI.CommonVisualAttachment
// Inherited Bytes: 0x188 | Struct Size: 0x1a0
struct UCommonVisualAttachment : USizeBox {
	// Fields
	struct FVector2D ContentAnchor; // Offset: 0x184 | Size: 0x8
	char pad_0x190[0x10]; // Offset: 0x190 | Size: 0x10
};

// Object: Class CommonUI.CommonWidgetCarousel
// Inherited Bytes: 0x150 | Struct Size: 0x188
struct UCommonWidgetCarousel : UPanelWidget {
	// Fields
	int32_t ActiveWidgetIndex; // Offset: 0x14c | Size: 0x4
	struct FMulticastInlineDelegate OnCurrentPageIndexChanged; // Offset: 0x150 | Size: 0x10
	char pad_0x164[0x24]; // Offset: 0x164 | Size: 0x24

	// Functions

	// Object: Function CommonUI.CommonWidgetCarousel.SetActiveWidgetIndex
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x10171ccc4
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetActiveWidgetIndex(int32_t Index);

	// Object: Function CommonUI.CommonWidgetCarousel.SetActiveWidget
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x10171cc3c
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetActiveWidget(struct UWidget* Widget);

	// Object: Function CommonUI.CommonWidgetCarousel.PreviousPage
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10171caf0
	// Return & Params: [ Num(0) Size(0x0) ]
	void PreviousPage();

	// Object: Function CommonUI.CommonWidgetCarousel.NextPage
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10171cb04
	// Return & Params: [ Num(0) Size(0x0) ]
	void NextPage();

	// Object: Function CommonUI.CommonWidgetCarousel.GetWidgetAtIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10171cbac
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UWidget* GetWidgetAtIndex(int32_t Index);

	// Object: Function CommonUI.CommonWidgetCarousel.GetActiveWidgetIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10171cd4c
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetActiveWidgetIndex();

	// Object: Function CommonUI.CommonWidgetCarousel.EndAutoScrolling
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10171cb18
	// Return & Params: [ Num(0) Size(0x0) ]
	void EndAutoScrolling();

	// Object: Function CommonUI.CommonWidgetCarousel.BeginAutoScrolling
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10171cb2c
	// Return & Params: [ Num(1) Size(0x4) ]
	void BeginAutoScrolling(float ScrollInterval);
};

// Object: Class CommonUI.CommonWidgetCarouselNavBar
// Inherited Bytes: 0x138 | Struct Size: 0x180
struct UCommonWidgetCarouselNavBar : UWidget {
	// Fields
	struct UCommonButtonBase* ButtonWidgetType; // Offset: 0x138 | Size: 0x8
	struct FMargin ButtonPadding; // Offset: 0x140 | Size: 0x10
	char pad_0x150[0x10]; // Offset: 0x150 | Size: 0x10
	struct UCommonWidgetCarousel* LinkedCarousel; // Offset: 0x160 | Size: 0x8
	struct UCommonButtonGroupBase* ButtonGroup; // Offset: 0x168 | Size: 0x8
	struct TArray<struct UCommonButtonBase*> Buttons; // Offset: 0x170 | Size: 0x10

	// Functions

	// Object: Function CommonUI.CommonWidgetCarouselNavBar.SetLinkedCarousel
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10171d350
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetLinkedCarousel(struct UCommonWidgetCarousel* CommonCarousel);

	// Object: Function CommonUI.CommonWidgetCarouselNavBar.HandlePageChanged
	// Flags: [Final|Native|Protected]
	// Offset: 0x10171d284
	// Return & Params: [ Num(2) Size(0xc) ]
	void HandlePageChanged(struct UCommonWidgetCarousel* CommonCarousel, int32_t PageIndex);

	// Object: Function CommonUI.CommonWidgetCarouselNavBar.HandleButtonClicked
	// Flags: [Final|Native|Protected]
	// Offset: 0x10171d1b8
	// Return & Params: [ Num(2) Size(0xc) ]
	void HandleButtonClicked(struct UCommonButtonBase* AssociatedButton, int32_t ButtonIndex);
};

