#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct CoreUObject.JoinabilitySettings
// Inherited Bytes: 0x0 | Struct Size: 0x14
struct FJoinabilitySettings {
	// Fields
	struct FName SessionName; // Offset: 0x0 | Size: 0x8
	bool bPublicSearchable; // Offset: 0x8 | Size: 0x1
	bool bAllowInvites; // Offset: 0x9 | Size: 0x1
	bool bJoinViaPresence; // Offset: 0xa | Size: 0x1
	bool bJoinViaPresenceFriendsOnly; // Offset: 0xb | Size: 0x1
	int32_t MaxPlayers; // Offset: 0xc | Size: 0x4
	int32_t MaxPartySize; // Offset: 0x10 | Size: 0x4
};

// Object: ScriptStruct CoreUObject.UniqueNetIdWrapper
// Inherited Bytes: 0x0 | Struct Size: 0x1
struct FUniqueNetIdWrapper {
	// Fields
	char pad_0x0[0x1]; // Offset: 0x0 | Size: 0x1
};

// Object: ScriptStruct CoreUObject.Guid
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FGuid {
	// Fields
	int32_t A; // Offset: 0x0 | Size: 0x4
	int32_t B; // Offset: 0x4 | Size: 0x4
	int32_t C; // Offset: 0x8 | Size: 0x4
	int32_t D; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct CoreUObject.Vector
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FVector {
	// Fields
	float X; // Offset: 0x0 | Size: 0x4
	float Y; // Offset: 0x4 | Size: 0x4
	float Z; // Offset: 0x8 | Size: 0x4
};

// Object: ScriptStruct CoreUObject.Vector4
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FVector4 {
	// Fields
	float X; // Offset: 0x0 | Size: 0x4
	float Y; // Offset: 0x4 | Size: 0x4
	float Z; // Offset: 0x8 | Size: 0x4
	float W; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct CoreUObject.Vector2D
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FVector2D {
	// Fields
	float X; // Offset: 0x0 | Size: 0x4
	float Y; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct CoreUObject.TwoVectors
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FTwoVectors {
	// Fields
	struct FVector v1; // Offset: 0x0 | Size: 0xc
	struct FVector v2; // Offset: 0xc | Size: 0xc
};

// Object: ScriptStruct CoreUObject.Plane
// Inherited Bytes: 0xc | Struct Size: 0x10
struct FPlane : FVector {
	// Fields
	float W; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct CoreUObject.Rotator
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FRotator {
	// Fields
	float Pitch; // Offset: 0x0 | Size: 0x4
	float Yaw; // Offset: 0x4 | Size: 0x4
	float Roll; // Offset: 0x8 | Size: 0x4
};

// Object: ScriptStruct CoreUObject.Quat
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FQuat {
	// Fields
	float X; // Offset: 0x0 | Size: 0x4
	float Y; // Offset: 0x4 | Size: 0x4
	float Z; // Offset: 0x8 | Size: 0x4
	float W; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct CoreUObject.PackedNormal
// Inherited Bytes: 0x0 | Struct Size: 0x4
struct FPackedNormal {
	// Fields
	char X; // Offset: 0x0 | Size: 0x1
	char Y; // Offset: 0x1 | Size: 0x1
	char Z; // Offset: 0x2 | Size: 0x1
	char W; // Offset: 0x3 | Size: 0x1
};

// Object: ScriptStruct CoreUObject.PackedRGB10A2N
// Inherited Bytes: 0x0 | Struct Size: 0x4
struct FPackedRGB10A2N {
	// Fields
	int32_t Packed; // Offset: 0x0 | Size: 0x4
};

// Object: ScriptStruct CoreUObject.PackedRGBA16N
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FPackedRGBA16N {
	// Fields
	int32_t XY; // Offset: 0x0 | Size: 0x4
	int32_t ZW; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct CoreUObject.IntPoint
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FIntPoint {
	// Fields
	int32_t X; // Offset: 0x0 | Size: 0x4
	int32_t Y; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct CoreUObject.IntVector
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FIntVector {
	// Fields
	int32_t X; // Offset: 0x0 | Size: 0x4
	int32_t Y; // Offset: 0x4 | Size: 0x4
	int32_t Z; // Offset: 0x8 | Size: 0x4
};

// Object: ScriptStruct CoreUObject.Color
// Inherited Bytes: 0x0 | Struct Size: 0x4
struct FColor {
	// Fields
	char B; // Offset: 0x0 | Size: 0x1
	char G; // Offset: 0x1 | Size: 0x1
	char R; // Offset: 0x2 | Size: 0x1
	char A; // Offset: 0x3 | Size: 0x1
};

// Object: ScriptStruct CoreUObject.LinearColor
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FLinearColor {
	// Fields
	float R; // Offset: 0x0 | Size: 0x4
	float G; // Offset: 0x4 | Size: 0x4
	float B; // Offset: 0x8 | Size: 0x4
	float A; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct CoreUObject.Box
// Inherited Bytes: 0x0 | Struct Size: 0x1c
struct FBox {
	// Fields
	struct FVector Min; // Offset: 0x0 | Size: 0xc
	struct FVector Max; // Offset: 0xc | Size: 0xc
	char IsValid; // Offset: 0x18 | Size: 0x1
	char pad_0x19[0x3]; // Offset: 0x19 | Size: 0x3
};

// Object: ScriptStruct CoreUObject.Box2D
// Inherited Bytes: 0x0 | Struct Size: 0x14
struct FBox2D {
	// Fields
	struct FVector2D Min; // Offset: 0x0 | Size: 0x8
	struct FVector2D Max; // Offset: 0x8 | Size: 0x8
	char bIsValid; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x3]; // Offset: 0x11 | Size: 0x3
};

// Object: ScriptStruct CoreUObject.BoxSphereBounds
// Inherited Bytes: 0x0 | Struct Size: 0x1c
struct FBoxSphereBounds {
	// Fields
	struct FVector Origin; // Offset: 0x0 | Size: 0xc
	struct FVector BoxExtent; // Offset: 0xc | Size: 0xc
	float SphereRadius; // Offset: 0x18 | Size: 0x4
};

// Object: ScriptStruct CoreUObject.OrientedBox
// Inherited Bytes: 0x0 | Struct Size: 0x3c
struct FOrientedBox {
	// Fields
	struct FVector Center; // Offset: 0x0 | Size: 0xc
	struct FVector AxisX; // Offset: 0xc | Size: 0xc
	struct FVector AxisY; // Offset: 0x18 | Size: 0xc
	struct FVector AxisZ; // Offset: 0x24 | Size: 0xc
	float ExtentX; // Offset: 0x30 | Size: 0x4
	float ExtentY; // Offset: 0x34 | Size: 0x4
	float ExtentZ; // Offset: 0x38 | Size: 0x4
};

// Object: ScriptStruct CoreUObject.Matrix
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FMatrix {
	// Fields
	struct FPlane XPlane; // Offset: 0x0 | Size: 0x10
	struct FPlane YPlane; // Offset: 0x10 | Size: 0x10
	struct FPlane ZPlane; // Offset: 0x20 | Size: 0x10
	struct FPlane WPlane; // Offset: 0x30 | Size: 0x10
};

// Object: ScriptStruct CoreUObject.InterpCurvePointFloat
// Inherited Bytes: 0x0 | Struct Size: 0x14
struct FInterpCurvePointFloat {
	// Fields
	float InVal; // Offset: 0x0 | Size: 0x4
	float OutVal; // Offset: 0x4 | Size: 0x4
	float ArriveTangent; // Offset: 0x8 | Size: 0x4
	float LeaveTangent; // Offset: 0xc | Size: 0x4
	enum class EInterpCurveMode InterpMode; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x3]; // Offset: 0x11 | Size: 0x3
};

// Object: ScriptStruct CoreUObject.InterpCurveFloat
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FInterpCurveFloat {
	// Fields
	struct TArray<struct FInterpCurvePointFloat> Points; // Offset: 0x0 | Size: 0x10
	bool bIsLooped; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x3]; // Offset: 0x11 | Size: 0x3
	float LoopKeyOffset; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct CoreUObject.InterpCurvePointVector2D
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FInterpCurvePointVector2D {
	// Fields
	float InVal; // Offset: 0x0 | Size: 0x4
	struct FVector2D OutVal; // Offset: 0x4 | Size: 0x8
	struct FVector2D ArriveTangent; // Offset: 0xc | Size: 0x8
	struct FVector2D LeaveTangent; // Offset: 0x14 | Size: 0x8
	enum class EInterpCurveMode InterpMode; // Offset: 0x1c | Size: 0x1
	char pad_0x1D[0x3]; // Offset: 0x1d | Size: 0x3
};

// Object: ScriptStruct CoreUObject.InterpCurveVector2D
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FInterpCurveVector2D {
	// Fields
	struct TArray<struct FInterpCurvePointVector2D> Points; // Offset: 0x0 | Size: 0x10
	bool bIsLooped; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x3]; // Offset: 0x11 | Size: 0x3
	float LoopKeyOffset; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct CoreUObject.InterpCurvePointVector
// Inherited Bytes: 0x0 | Struct Size: 0x2c
struct FInterpCurvePointVector {
	// Fields
	float InVal; // Offset: 0x0 | Size: 0x4
	struct FVector OutVal; // Offset: 0x4 | Size: 0xc
	struct FVector ArriveTangent; // Offset: 0x10 | Size: 0xc
	struct FVector LeaveTangent; // Offset: 0x1c | Size: 0xc
	enum class EInterpCurveMode InterpMode; // Offset: 0x28 | Size: 0x1
	char pad_0x29[0x3]; // Offset: 0x29 | Size: 0x3
};

// Object: ScriptStruct CoreUObject.InterpCurveVector
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FInterpCurveVector {
	// Fields
	struct TArray<struct FInterpCurvePointVector> Points; // Offset: 0x0 | Size: 0x10
	bool bIsLooped; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x3]; // Offset: 0x11 | Size: 0x3
	float LoopKeyOffset; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct CoreUObject.InterpCurvePointQuat
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FInterpCurvePointQuat {
	// Fields
	float InVal; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0xc]; // Offset: 0x4 | Size: 0xc
	struct FQuat OutVal; // Offset: 0x10 | Size: 0x10
	struct FQuat ArriveTangent; // Offset: 0x20 | Size: 0x10
	struct FQuat LeaveTangent; // Offset: 0x30 | Size: 0x10
	enum class EInterpCurveMode InterpMode; // Offset: 0x40 | Size: 0x1
	char pad_0x41[0xf]; // Offset: 0x41 | Size: 0xf
};

// Object: ScriptStruct CoreUObject.InterpCurveQuat
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FInterpCurveQuat {
	// Fields
	struct TArray<struct FInterpCurvePointQuat> Points; // Offset: 0x0 | Size: 0x10
	bool bIsLooped; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x3]; // Offset: 0x11 | Size: 0x3
	float LoopKeyOffset; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct CoreUObject.InterpCurvePointTwoVectors
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FInterpCurvePointTwoVectors {
	// Fields
	float InVal; // Offset: 0x0 | Size: 0x4
	struct FTwoVectors OutVal; // Offset: 0x4 | Size: 0x18
	struct FTwoVectors ArriveTangent; // Offset: 0x1c | Size: 0x18
	struct FTwoVectors LeaveTangent; // Offset: 0x34 | Size: 0x18
	enum class EInterpCurveMode InterpMode; // Offset: 0x4c | Size: 0x1
	char pad_0x4D[0x3]; // Offset: 0x4d | Size: 0x3
};

// Object: ScriptStruct CoreUObject.InterpCurveTwoVectors
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FInterpCurveTwoVectors {
	// Fields
	struct TArray<struct FInterpCurvePointTwoVectors> Points; // Offset: 0x0 | Size: 0x10
	bool bIsLooped; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x3]; // Offset: 0x11 | Size: 0x3
	float LoopKeyOffset; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct CoreUObject.InterpCurvePointLinearColor
// Inherited Bytes: 0x0 | Struct Size: 0x38
struct FInterpCurvePointLinearColor {
	// Fields
	float InVal; // Offset: 0x0 | Size: 0x4
	struct FLinearColor OutVal; // Offset: 0x4 | Size: 0x10
	struct FLinearColor ArriveTangent; // Offset: 0x14 | Size: 0x10
	struct FLinearColor LeaveTangent; // Offset: 0x24 | Size: 0x10
	enum class EInterpCurveMode InterpMode; // Offset: 0x34 | Size: 0x1
	char pad_0x35[0x3]; // Offset: 0x35 | Size: 0x3
};

// Object: ScriptStruct CoreUObject.InterpCurveLinearColor
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FInterpCurveLinearColor {
	// Fields
	struct TArray<struct FInterpCurvePointLinearColor> Points; // Offset: 0x0 | Size: 0x10
	bool bIsLooped; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x3]; // Offset: 0x11 | Size: 0x3
	float LoopKeyOffset; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct CoreUObject.Transform
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FTransform {
	// Fields
	struct FQuat Rotation; // Offset: 0x0 | Size: 0x10
	struct FVector Translation; // Offset: 0x10 | Size: 0xc
	struct FVector Scale3D; // Offset: 0x1c | Size: 0xc
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
};

// Object: ScriptStruct CoreUObject.RandomStream
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FRandomStream {
	// Fields
	int32_t InitialSeed; // Offset: 0x0 | Size: 0x4
	int32_t Seed; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct CoreUObject.DateTime
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FDateTime {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
};

// Object: ScriptStruct CoreUObject.FrameNumber
// Inherited Bytes: 0x0 | Struct Size: 0x4
struct FFrameNumber {
	// Fields
	int32_t Value; // Offset: 0x0 | Size: 0x4
};

// Object: ScriptStruct CoreUObject.FrameRate
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FFrameRate {
	// Fields
	int32_t Numerator; // Offset: 0x0 | Size: 0x4
	int32_t Denominator; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct CoreUObject.FrameTime
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FFrameTime {
	// Fields
	struct FFrameNumber FrameNumber; // Offset: 0x0 | Size: 0x4
	float SubFrame; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct CoreUObject.QualifiedFrameTime
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FQualifiedFrameTime {
	// Fields
	struct FFrameTime Time; // Offset: 0x0 | Size: 0x8
	struct FFrameRate Rate; // Offset: 0x8 | Size: 0x8
};

// Object: ScriptStruct CoreUObject.Timecode
// Inherited Bytes: 0x0 | Struct Size: 0x14
struct FTimecode {
	// Fields
	int32_t Hours; // Offset: 0x0 | Size: 0x4
	int32_t Minutes; // Offset: 0x4 | Size: 0x4
	int32_t Seconds; // Offset: 0x8 | Size: 0x4
	int32_t Frames; // Offset: 0xc | Size: 0x4
	bool bDropFrameFormat; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x3]; // Offset: 0x11 | Size: 0x3
};

// Object: ScriptStruct CoreUObject.Timespan
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FTimespan {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
};

// Object: ScriptStruct CoreUObject.SoftObjectPath
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FSoftObjectPath {
	// Fields
	struct FName AssetPathName; // Offset: 0x0 | Size: 0x8
	struct FString SubPathString; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct CoreUObject.SoftClassPath
// Inherited Bytes: 0x18 | Struct Size: 0x18
struct FSoftClassPath : FSoftObjectPath {
};

// Object: ScriptStruct CoreUObject.PrimaryAssetType
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FPrimaryAssetType {
	// Fields
	struct FName Name; // Offset: 0x0 | Size: 0x8
};

// Object: ScriptStruct CoreUObject.PrimaryAssetId
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FPrimaryAssetId {
	// Fields
	struct FPrimaryAssetType PrimaryAssetType; // Offset: 0x0 | Size: 0x8
	struct FName PrimaryAssetName; // Offset: 0x8 | Size: 0x8
};

// Object: ScriptStruct CoreUObject.FallbackStruct
// Inherited Bytes: 0x0 | Struct Size: 0x1
struct FFallbackStruct {
	// Fields
	char pad_0x0[0x1]; // Offset: 0x0 | Size: 0x1
};

// Object: ScriptStruct CoreUObject.FloatRangeBound
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FFloatRangeBound {
	// Fields
	enum class ERangeBoundTypes Type; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	float Value; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct CoreUObject.FloatRange
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FFloatRange {
	// Fields
	struct FFloatRangeBound LowerBound; // Offset: 0x0 | Size: 0x8
	struct FFloatRangeBound UpperBound; // Offset: 0x8 | Size: 0x8
};

// Object: ScriptStruct CoreUObject.Int32RangeBound
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FInt32RangeBound {
	// Fields
	enum class ERangeBoundTypes Type; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	int32_t Value; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct CoreUObject.Int32Range
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FInt32Range {
	// Fields
	struct FInt32RangeBound LowerBound; // Offset: 0x0 | Size: 0x8
	struct FInt32RangeBound UpperBound; // Offset: 0x8 | Size: 0x8
};

// Object: ScriptStruct CoreUObject.FloatInterval
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FFloatInterval {
	// Fields
	float Min; // Offset: 0x0 | Size: 0x4
	float Max; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct CoreUObject.Int32Interval
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FInt32Interval {
	// Fields
	int32_t Min; // Offset: 0x0 | Size: 0x4
	int32_t Max; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct CoreUObject.PolyglotTextData
// Inherited Bytes: 0x0 | Struct Size: 0xb8
struct FPolyglotTextData {
	// Fields
	enum class ELocalizedTextSourceCategory Category; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x7]; // Offset: 0x1 | Size: 0x7
	struct FString NativeCulture; // Offset: 0x8 | Size: 0x10
	struct FString Namespace; // Offset: 0x18 | Size: 0x10
	struct FString Key; // Offset: 0x28 | Size: 0x10
	struct FString NativeString; // Offset: 0x38 | Size: 0x10
	struct TMap<struct FString, struct FString> LocalizedStrings; // Offset: 0x48 | Size: 0x50
	bool bIsMinimalPatch; // Offset: 0x98 | Size: 0x1
	char pad_0x99[0x7]; // Offset: 0x99 | Size: 0x7
	struct FText CachedText; // Offset: 0xa0 | Size: 0x18
};

// Object: ScriptStruct CoreUObject.AutomationEvent
// Inherited Bytes: 0x0 | Struct Size: 0x38
struct FAutomationEvent {
	// Fields
	enum class EAutomationEventType Type; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x7]; // Offset: 0x1 | Size: 0x7
	struct FString Message; // Offset: 0x8 | Size: 0x10
	struct FString Context; // Offset: 0x18 | Size: 0x10
	struct FGuid Artifact; // Offset: 0x28 | Size: 0x10
};

// Object: ScriptStruct CoreUObject.AutomationExecutionEntry
// Inherited Bytes: 0x0 | Struct Size: 0x58
struct FAutomationExecutionEntry {
	// Fields
	struct FAutomationEvent Event; // Offset: 0x0 | Size: 0x38
	struct FString Filename; // Offset: 0x38 | Size: 0x10
	int32_t LineNumber; // Offset: 0x48 | Size: 0x4
	char pad_0x4C[0x4]; // Offset: 0x4c | Size: 0x4
	struct FDateTime Timestamp; // Offset: 0x50 | Size: 0x8
};

