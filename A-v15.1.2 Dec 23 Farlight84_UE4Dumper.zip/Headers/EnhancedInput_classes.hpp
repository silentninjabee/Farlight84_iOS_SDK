#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class EnhancedInput.EnhancedInputActionDelegateBinding
// Inherited Bytes: 0x28 | Struct Size: 0x38
struct UEnhancedInputActionDelegateBinding : UInputDelegateBinding {
	// Fields
	struct TArray<struct FBlueprintEnhancedInputActionBinding> InputActionDelegateBindings; // Offset: 0x28 | Size: 0x10
};

// Object: Class EnhancedInput.EnhancedInputActionValueBinding
// Inherited Bytes: 0x28 | Struct Size: 0x38
struct UEnhancedInputActionValueBinding : UInputDelegateBinding {
	// Fields
	struct TArray<struct FBlueprintEnhancedInputActionBinding> InputActionValueBindings; // Offset: 0x28 | Size: 0x10
};

// Object: Class EnhancedInput.EnhancedInputComponent
// Inherited Bytes: 0x138 | Struct Size: 0x168
struct UEnhancedInputComponent : UInputComponent {
	// Fields
	char pad_0x138[0x30]; // Offset: 0x138 | Size: 0x30

	// Functions

	// Object: Function EnhancedInput.EnhancedInputComponent.GetBoundActionValue
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x101818194
	// Return & Params: [ Num(2) Size(0x18) ]
	struct FInputActionValue GetBoundActionValue(struct UInputAction* Action);
};

// Object: Class EnhancedInput.EnhancedInputLibrary
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UEnhancedInputLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object: Function EnhancedInput.EnhancedInputLibrary.RequestRebuildControlMappingsUsingContext
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101818b84
	// Return & Params: [ Num(2) Size(0x9) ]
	void RequestRebuildControlMappingsUsingContext(struct UInputMappingContext* Context, bool bForceImmediately);

	// Object: Function EnhancedInput.EnhancedInputLibrary.MakeInputActionValue
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x101818858
	// Return & Params: [ Num(5) Size(0x2c) ]
	struct FInputActionValue MakeInputActionValue(float X, float Y, float Z, struct FInputActionValue& MatchValueType);

	// Object: Function EnhancedInput.EnhancedInputLibrary.GetBoundActionValue
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x101818784
	// Return & Params: [ Num(3) Size(0x20) ]
	struct FInputActionValue GetBoundActionValue(struct AActor* Actor, struct UInputAction* Action);

	// Object: Function EnhancedInput.EnhancedInputLibrary.Conv_InputActionValueToBool
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1018186ec
	// Return & Params: [ Num(2) Size(0x11) ]
	bool Conv_InputActionValueToBool(struct FInputActionValue InValue);

	// Object: Function EnhancedInput.EnhancedInputLibrary.Conv_InputActionValueToAxis3D
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x10181851c
	// Return & Params: [ Num(2) Size(0x1c) ]
	struct FVector Conv_InputActionValueToAxis3D(struct FInputActionValue ActionValue);

	// Object: Function EnhancedInput.EnhancedInputLibrary.Conv_InputActionValueToAxis2D
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x1018185b8
	// Return & Params: [ Num(2) Size(0x18) ]
	struct FVector2D Conv_InputActionValueToAxis2D(struct FInputActionValue InValue);

	// Object: Function EnhancedInput.EnhancedInputLibrary.Conv_InputActionValueToAxis1D
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x101818654
	// Return & Params: [ Num(2) Size(0x14) ]
	float Conv_InputActionValueToAxis1D(struct FInputActionValue InValue);

	// Object: Function EnhancedInput.EnhancedInputLibrary.BreakInputActionValue
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x1018189dc
	// Return & Params: [ Num(4) Size(0x1c) ]
	void BreakInputActionValue(struct FInputActionValue InActionValue, float& X, float& Y, float& Z);
};

// Object: Class EnhancedInput.EnhancedInputSubsystemInterface
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UEnhancedInputSubsystemInterface : UInterface {
	// Functions

	// Object: Function EnhancedInput.EnhancedInputSubsystemInterface.RequestRebuildControlMappings
	// Flags: [BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x101819a84
	// Return & Params: [ Num(1) Size(0x1) ]
	void RequestRebuildControlMappings(bool bForceImmediately);

	// Object: Function EnhancedInput.EnhancedInputSubsystemInterface.RemoveMappingContext
	// Flags: [BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x101819b14
	// Return & Params: [ Num(1) Size(0x8) ]
	void RemoveMappingContext(struct UInputMappingContext* MappingContext);

	// Object: Function EnhancedInput.EnhancedInputSubsystemInterface.QueryMapKeyInContextSet
	// Flags: [BlueprintCosmetic|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1018194b8
	// Return & Params: [ Num(7) Size(0x4a) ]
	enum class EMappingQueryResult QueryMapKeyInContextSet(struct TArray<struct UInputMappingContext*>& PrioritizedActiveContexts, struct UInputMappingContext* InputContext, struct UInputAction* Action, struct FKey Key, struct TArray<struct FMappingQueryIssue>& OutIssues, enum class EMappingQueryIssue BlockingIssues);

	// Object: Function EnhancedInput.EnhancedInputSubsystemInterface.QueryMapKeyInActiveContextSet
	// Flags: [BlueprintCosmetic|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1018197d0
	// Return & Params: [ Num(6) Size(0x3a) ]
	enum class EMappingQueryResult QueryMapKeyInActiveContextSet(struct UInputMappingContext* InputContext, struct UInputAction* Action, struct FKey Key, struct TArray<struct FMappingQueryIssue>& OutIssues, enum class EMappingQueryIssue BlockingIssues);

	// Object: Function EnhancedInput.EnhancedInputSubsystemInterface.QueryKeysMappedToAction
	// Flags: [BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x101819234
	// Return & Params: [ Num(2) Size(0x18) ]
	struct TArray<struct FKey> QueryKeysMappedToAction(struct UInputAction* Action);

	// Object: Function EnhancedInput.EnhancedInputSubsystemInterface.HasMappingContext
	// Flags: [BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x101819420
	// Return & Params: [ Num(2) Size(0x9) ]
	bool HasMappingContext(struct UInputMappingContext* MappingContext);

	// Object: Function EnhancedInput.EnhancedInputSubsystemInterface.ClearAllMappings
	// Flags: [BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x101819c70
	// Return & Params: [ Num(0) Size(0x0) ]
	void ClearAllMappings();

	// Object: Function EnhancedInput.EnhancedInputSubsystemInterface.AddMappingContext
	// Flags: [BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x101819b9c
	// Return & Params: [ Num(2) Size(0xc) ]
	void AddMappingContext(struct UInputMappingContext* MappingContext, int32_t Priority);
};

// Object: Class EnhancedInput.EnhancedInputLocalPlayerSubsystem
// Inherited Bytes: 0x30 | Struct Size: 0xe0
struct UEnhancedInputLocalPlayerSubsystem : ULocalPlayerSubsystem {
	// Fields
	char pad_0x30[0xb0]; // Offset: 0x30 | Size: 0xb0
};

// Object: Class EnhancedInput.EnhancedInputEngineSubsystem
// Inherited Bytes: 0x30 | Struct Size: 0xe8
struct UEnhancedInputEngineSubsystem : UEngineSubsystem {
	// Fields
	char pad_0x30[0xb0]; // Offset: 0x30 | Size: 0xb0
	struct UEnhancedPlayerInput* PlayerInput; // Offset: 0xe0 | Size: 0x8
};

// Object: Class EnhancedInput.EnhancedPlayerInput
// Inherited Bytes: 0x3a8 | Struct Size: 0x600
struct UEnhancedPlayerInput : UPlayerInput {
	// Fields
	struct TMap<struct UInputMappingContext*, int32_t> AppliedInputContexts; // Offset: 0x3a8 | Size: 0x50
	struct TArray<struct FEnhancedActionKeyMapping> EnhancedActionMappings; // Offset: 0x3f8 | Size: 0x10
	char pad_0x408[0x50]; // Offset: 0x408 | Size: 0x50
	struct TMap<struct UInputAction*, struct FInputActionInstance> ActionInstanceData; // Offset: 0x458 | Size: 0x50
	char pad_0x4A8[0x158]; // Offset: 0x4a8 | Size: 0x158
};

// Object: Class EnhancedInput.InputAction
// Inherited Bytes: 0x30 | Struct Size: 0x58
struct UInputAction : UDataAsset {
	// Fields
	bool bConsumeInput; // Offset: 0x30 | Size: 0x1
	bool bTriggerWhenPaused; // Offset: 0x31 | Size: 0x1
	bool bReserveAllMappings; // Offset: 0x32 | Size: 0x1
	enum class EInputActionValueType ValueType; // Offset: 0x33 | Size: 0x1
	char pad_0x34[0x4]; // Offset: 0x34 | Size: 0x4
	struct TArray<struct UInputTrigger*> Triggers; // Offset: 0x38 | Size: 0x10
	struct TArray<struct UInputModifier*> Modifiers; // Offset: 0x48 | Size: 0x10
};

// Object: Class EnhancedInput.InputDebugKeyDelegateBinding
// Inherited Bytes: 0x28 | Struct Size: 0x38
struct UInputDebugKeyDelegateBinding : UInputDelegateBinding {
	// Fields
	struct TArray<struct FBlueprintInputDebugKeyDelegateBinding> InputDebugKeyDelegateBindings; // Offset: 0x28 | Size: 0x10
};

// Object: Class EnhancedInput.InputMappingContext
// Inherited Bytes: 0x30 | Struct Size: 0x58
struct UInputMappingContext : UDataAsset {
	// Fields
	struct TArray<struct FEnhancedActionKeyMapping> Mappings; // Offset: 0x30 | Size: 0x10
	struct FText ContextDescription; // Offset: 0x40 | Size: 0x18

	// Functions

	// Object: Function EnhancedInput.InputMappingContext.UnmapKey
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10181b30c
	// Return & Params: [ Num(2) Size(0x20) ]
	void UnmapKey(struct UInputAction* Action, struct FKey Key);

	// Object: Function EnhancedInput.InputMappingContext.UnmapAll
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10181b278
	// Return & Params: [ Num(0) Size(0x0) ]
	void UnmapAll();

	// Object: Function EnhancedInput.InputMappingContext.UnmapAction
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10181b28c
	// Return & Params: [ Num(1) Size(0x8) ]
	void UnmapAction(struct UInputAction* Action);

	// Object: Function EnhancedInput.InputMappingContext.MapKey
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10181b4b8
	// Return & Params: [ Num(3) Size(0x68) ]
	struct FEnhancedActionKeyMapping MapKey(struct UInputAction* Action, struct FKey ToKey);
};

// Object: Class EnhancedInput.InputModifier
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UInputModifier : UObject {
	// Functions

	// Object: Function EnhancedInput.InputModifier.ModifyRaw
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const]
	// Offset: 0x10181c1a8
	// Return & Params: [ Num(4) Size(0x2c) ]
	struct FInputActionValue ModifyRaw(struct UEnhancedPlayerInput* PlayerInput, struct FInputActionValue CurrentValue, float DeltaTime);

	// Object: Function EnhancedInput.InputModifier.GetVisualizationColor
	// Flags: [Native|Event|Public|HasDefaults|BlueprintEvent|Const]
	// Offset: 0x10181c060
	// Return & Params: [ Num(3) Size(0x30) ]
	struct FLinearColor GetVisualizationColor(struct FInputActionValue SampleValue, struct FInputActionValue FinalValue);

	// Object: Function EnhancedInput.InputModifier.GetExecutionPhase
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x10181c16c
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class EModifierExecutionPhase GetExecutionPhase();
};

// Object: Class EnhancedInput.InputModifierDeadZone
// Inherited Bytes: 0x28 | Struct Size: 0x38
struct UInputModifierDeadZone : UInputModifier {
	// Fields
	float LowerThreshold; // Offset: 0x28 | Size: 0x4
	float UpperThreshold; // Offset: 0x2c | Size: 0x4
	enum class EDeadZoneType Type; // Offset: 0x30 | Size: 0x1
	char pad_0x31[0x7]; // Offset: 0x31 | Size: 0x7
};

// Object: Class EnhancedInput.InputModifierScalar
// Inherited Bytes: 0x28 | Struct Size: 0x38
struct UInputModifierScalar : UInputModifier {
	// Fields
	struct FVector Scalar; // Offset: 0x28 | Size: 0xc
	char pad_0x34[0x4]; // Offset: 0x34 | Size: 0x4
};

// Object: Class EnhancedInput.InputModifierNegate
// Inherited Bytes: 0x28 | Struct Size: 0x30
struct UInputModifierNegate : UInputModifier {
	// Fields
	bool bX; // Offset: 0x28 | Size: 0x1
	bool bY; // Offset: 0x29 | Size: 0x1
	bool bZ; // Offset: 0x2a | Size: 0x1
	char pad_0x2B[0x5]; // Offset: 0x2b | Size: 0x5
};

// Object: Class EnhancedInput.InputModifierSmooth
// Inherited Bytes: 0x28 | Struct Size: 0x48
struct UInputModifierSmooth : UInputModifier {
	// Fields
	char pad_0x28[0x20]; // Offset: 0x28 | Size: 0x20
};

// Object: Class EnhancedInput.InputModifierResponseCurveExponential
// Inherited Bytes: 0x28 | Struct Size: 0x38
struct UInputModifierResponseCurveExponential : UInputModifier {
	// Fields
	struct FVector CurveExponent; // Offset: 0x28 | Size: 0xc
	char pad_0x34[0x4]; // Offset: 0x34 | Size: 0x4
};

// Object: Class EnhancedInput.InputModifierResponseCurveUser
// Inherited Bytes: 0x28 | Struct Size: 0x40
struct UInputModifierResponseCurveUser : UInputModifier {
	// Fields
	struct UCurveFloat* ResponseX; // Offset: 0x28 | Size: 0x8
	struct UCurveFloat* ResponseY; // Offset: 0x30 | Size: 0x8
	struct UCurveFloat* ResponseZ; // Offset: 0x38 | Size: 0x8
};

// Object: Class EnhancedInput.InputModifierFOVScaling
// Inherited Bytes: 0x28 | Struct Size: 0x30
struct UInputModifierFOVScaling : UInputModifier {
	// Fields
	float FOVScale; // Offset: 0x28 | Size: 0x4
	enum class EFOVScalingType FOVScalingType; // Offset: 0x2c | Size: 0x1
	char pad_0x2D[0x3]; // Offset: 0x2d | Size: 0x3
};

// Object: Class EnhancedInput.InputModifierToWorldSpace
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UInputModifierToWorldSpace : UInputModifier {
};

// Object: Class EnhancedInput.InputModifierSwizzleAxis
// Inherited Bytes: 0x28 | Struct Size: 0x30
struct UInputModifierSwizzleAxis : UInputModifier {
	// Fields
	enum class EInputAxisSwizzle Order; // Offset: 0x28 | Size: 0x1
	char pad_0x29[0x7]; // Offset: 0x29 | Size: 0x7
};

// Object: Class EnhancedInput.InputModifierCollection
// Inherited Bytes: 0x28 | Struct Size: 0x40
struct UInputModifierCollection : UInputModifier {
	// Fields
	struct TArray<struct UInputModifier*> Modifiers; // Offset: 0x28 | Size: 0x10
	bool bPermitValueTypeModification; // Offset: 0x38 | Size: 0x1
	char pad_0x39[0x7]; // Offset: 0x39 | Size: 0x7
};

// Object: Class EnhancedInput.InputTrigger
// Inherited Bytes: 0x28 | Struct Size: 0x40
struct UInputTrigger : UObject {
	// Fields
	float ActuationThreshold; // Offset: 0x28 | Size: 0x4
	struct FInputActionValue LastValue; // Offset: 0x2c | Size: 0x10
	char pad_0x3C[0x4]; // Offset: 0x3c | Size: 0x4

	// Functions

	// Object: Function EnhancedInput.InputTrigger.UpdateState
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10181d9c0
	// Return & Params: [ Num(4) Size(0x1d) ]
	enum class ETriggerState UpdateState(struct UEnhancedPlayerInput* PlayerInput, struct FInputActionValue ModifiedValue, float DeltaTime);

	// Object: Function EnhancedInput.InputTrigger.IsActuated
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10181db38
	// Return & Params: [ Num(2) Size(0x11) ]
	bool IsActuated(struct FInputActionValue& ForValue);

	// Object: Function EnhancedInput.InputTrigger.GetTriggerType
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const]
	// Offset: 0x10181dafc
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class ETriggerTypeEx GetTriggerType();
};

// Object: Class EnhancedInput.InputTriggerTimedBase
// Inherited Bytes: 0x40 | Struct Size: 0x48
struct UInputTriggerTimedBase : UInputTrigger {
	// Fields
	float HeldDuration; // Offset: 0x3c | Size: 0x4
	bool bAffectedByTimeDilation; // Offset: 0x40 | Size: 0x1
	char pad_0x45[0x3]; // Offset: 0x45 | Size: 0x3
};

// Object: Class EnhancedInput.InputTriggerDown
// Inherited Bytes: 0x40 | Struct Size: 0x40
struct UInputTriggerDown : UInputTrigger {
};

// Object: Class EnhancedInput.InputTriggerPressed
// Inherited Bytes: 0x40 | Struct Size: 0x40
struct UInputTriggerPressed : UInputTrigger {
};

// Object: Class EnhancedInput.InputTriggerReleased
// Inherited Bytes: 0x40 | Struct Size: 0x40
struct UInputTriggerReleased : UInputTrigger {
};

// Object: Class EnhancedInput.InputTriggerHold
// Inherited Bytes: 0x48 | Struct Size: 0x50
struct UInputTriggerHold : UInputTriggerTimedBase {
	// Fields
	float HoldTimeThreshold; // Offset: 0x44 | Size: 0x4
	bool bIsOneShot; // Offset: 0x48 | Size: 0x1
	char pad_0x4D[0x3]; // Offset: 0x4d | Size: 0x3
};

// Object: Class EnhancedInput.InputTriggerHoldAndRelease
// Inherited Bytes: 0x48 | Struct Size: 0x48
struct UInputTriggerHoldAndRelease : UInputTriggerTimedBase {
	// Fields
	float HoldTimeThreshold; // Offset: 0x44 | Size: 0x4
};

// Object: Class EnhancedInput.InputTriggerTap
// Inherited Bytes: 0x48 | Struct Size: 0x48
struct UInputTriggerTap : UInputTriggerTimedBase {
	// Fields
	float TapReleaseTimeThreshold; // Offset: 0x44 | Size: 0x4
};

// Object: Class EnhancedInput.InputTriggerPulse
// Inherited Bytes: 0x48 | Struct Size: 0x58
struct UInputTriggerPulse : UInputTriggerTimedBase {
	// Fields
	bool bTriggerOnStart; // Offset: 0x48 | Size: 0x1
	char pad_0x49[0x3]; // Offset: 0x49 | Size: 0x3
	float Interval; // Offset: 0x4c | Size: 0x4
	int32_t TriggerLimit; // Offset: 0x50 | Size: 0x4
	char pad_0x54[0x4]; // Offset: 0x54 | Size: 0x4
};

// Object: Class EnhancedInput.InputTriggerChordAction
// Inherited Bytes: 0x40 | Struct Size: 0x48
struct UInputTriggerChordAction : UInputTrigger {
	// Fields
	struct UInputAction* ChordAction; // Offset: 0x40 | Size: 0x8
};

// Object: Class EnhancedInput.InputTriggerChordBlocker
// Inherited Bytes: 0x48 | Struct Size: 0x48
struct UInputTriggerChordBlocker : UInputTriggerChordAction {
};

