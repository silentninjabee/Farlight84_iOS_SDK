#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct EnhancedInput.InputActionValue
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FInputActionValue {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct EnhancedInput.EnhancedActionKeyMapping
// Inherited Bytes: 0x0 | Struct Size: 0x48
struct FEnhancedActionKeyMapping {
	// Fields
	struct UInputAction* Action; // Offset: 0x0 | Size: 0x8
	struct FKey Key; // Offset: 0x8 | Size: 0x18
	char bShouldBeIgnored : 1; // Offset: 0x20 | Size: 0x1
	char pad_0x20_1 : 7; // Offset: 0x20 | Size: 0x1
	char pad_0x21[0x7]; // Offset: 0x21 | Size: 0x7
	struct TArray<struct UInputTrigger*> Triggers; // Offset: 0x28 | Size: 0x10
	struct TArray<struct UInputModifier*> Modifiers; // Offset: 0x38 | Size: 0x10
};

// Object: ScriptStruct EnhancedInput.BlueprintEnhancedInputActionBinding
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FBlueprintEnhancedInputActionBinding {
	// Fields
	struct UInputAction* InputAction; // Offset: 0x0 | Size: 0x8
	enum class ETriggerEvent TriggerEvent; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x3]; // Offset: 0x9 | Size: 0x3
	struct FName FunctionNameToBind; // Offset: 0xc | Size: 0x8
	char pad_0x14[0x4]; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct EnhancedInput.InputActionInstance
// Inherited Bytes: 0x0 | Struct Size: 0x70
struct FInputActionInstance {
	// Fields
	struct UInputAction* SourceAction; // Offset: 0x0 | Size: 0x8
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct TArray<struct UInputTrigger*> Triggers; // Offset: 0x10 | Size: 0x10
	struct TArray<struct UInputModifier*> Modifiers; // Offset: 0x20 | Size: 0x10
	struct TArray<struct UInputModifier*> PerInputModifiers; // Offset: 0x30 | Size: 0x10
	struct TArray<struct UInputModifier*> FinalValueModifiers; // Offset: 0x40 | Size: 0x10
	char pad_0x50[0x10]; // Offset: 0x50 | Size: 0x10
	float ElapsedProcessedTime; // Offset: 0x60 | Size: 0x4
	float ElapsedTriggeredTime; // Offset: 0x64 | Size: 0x4
	enum class ETriggerEvent TriggerEvent; // Offset: 0x68 | Size: 0x1
	char pad_0x69[0x7]; // Offset: 0x69 | Size: 0x7
};

// Object: ScriptStruct EnhancedInput.BlueprintInputDebugKeyDelegateBinding
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FBlueprintInputDebugKeyDelegateBinding {
	// Fields
	struct FInputChord InputChord; // Offset: 0x0 | Size: 0x20
	enum class EInputEvent InputKeyEvent; // Offset: 0x20 | Size: 0x1
	char pad_0x21[0x3]; // Offset: 0x21 | Size: 0x3
	struct FName FunctionNameToBind; // Offset: 0x24 | Size: 0x8
	bool bExecuteWhenPaused; // Offset: 0x2c | Size: 0x1
	char pad_0x2D[0x3]; // Offset: 0x2d | Size: 0x3
};

// Object: ScriptStruct EnhancedInput.MappingQueryIssue
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FMappingQueryIssue {
	// Fields
	enum class EMappingQueryIssue Issue; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x7]; // Offset: 0x1 | Size: 0x7
	struct UInputMappingContext* BlockingContext; // Offset: 0x8 | Size: 0x8
	struct UInputAction* BlockingAction; // Offset: 0x10 | Size: 0x8
};

