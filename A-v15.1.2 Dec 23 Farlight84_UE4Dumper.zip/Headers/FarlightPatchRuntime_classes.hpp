#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class FarlightPatchRuntime.PakHelper
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UPakHelper : UObject {
	// Functions

	// Object: Function FarlightPatchRuntime.PakHelper.ReloadRedirectSettingsFromIni
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102391ed8
	// Return & Params: [ Num(1) Size(0x10) ]
	void ReloadRedirectSettingsFromIni(struct FString IniPath);

	// Object: Function FarlightPatchRuntime.PakHelper.ReloadIniFile
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102391f98
	// Return & Params: [ Num(3) Size(0x21) ]
	bool ReloadIniFile(struct FString StrippedConfigFileName, struct FString FilePath);

	// Object: Function FarlightPatchRuntime.PakHelper.ReloadGameUserSettings
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102391f5c
	// Return & Params: [ Num(0) Size(0x0) ]
	void ReloadGameUserSettings();

	// Object: Function FarlightPatchRuntime.PakHelper.ReloadDeviceProfiles
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102391f70
	// Return & Params: [ Num(0) Size(0x0) ]
	void ReloadDeviceProfiles();

	// Object: Function FarlightPatchRuntime.PakHelper.ReloadCVarSettingsFromIni
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102391f84
	// Return & Params: [ Num(0) Size(0x0) ]
	void ReloadCVarSettingsFromIni();

	// Object: Function FarlightPatchRuntime.PakHelper.OpenShaderPatchLibrary
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10239207c
	// Return & Params: [ Num(3) Size(0x21) ]
	void OpenShaderPatchLibrary(struct FString ShaderPatchLibraryName, struct FString LibraryDir, bool& bShaderPatchLibUnique);

	// Object: Function FarlightPatchRuntime.PakHelper.MountPak
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102392230
	// Return & Params: [ Num(3) Size(0x15) ]
	bool MountPak(struct FString InPakFilename, int32_t PakOrder);

	// Object: Function FarlightPatchRuntime.PakHelper.GetStrippedConfigFileName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102391e14
	// Return & Params: [ Num(2) Size(0x20) ]
	struct FString GetStrippedConfigFileName(struct FString IniName);

	// Object: Function FarlightPatchRuntime.PakHelper.GetProjectName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1023921b0
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetProjectName();

	// Object: Function FarlightPatchRuntime.PakHelper.CreatePakWriter
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102392308
	// Return & Params: [ Num(3) Size(0x28) ]
	struct UPakWriter* CreatePakWriter(struct FString InFilename, struct FString InMountPoint);

	// Object: Function FarlightPatchRuntime.PakHelper.CreatePakReader
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1023923ec
	// Return & Params: [ Num(3) Size(0x20) ]
	struct UPakReader* CreatePakReader(struct FString InFilename, bool bLoadIndex);
};

// Object: Class FarlightPatchRuntime.PakReader
// Inherited Bytes: 0x28 | Struct Size: 0x50
struct UPakReader : UObject {
	// Fields
	char pad_0x28[0x28]; // Offset: 0x28 | Size: 0x28

	// Functions

	// Object: Function FarlightPatchRuntime.PakReader.GetTotalSize
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102392c60
	// Return & Params: [ Num(1) Size(0x8) ]
	int64_t GetTotalSize();

	// Object: Function FarlightPatchRuntime.PakReader.GetPakIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102392c7c
	// Return & Params: [ Num(1) Size(0x10) ]
	struct TArray<struct FPakEntryInfo> GetPakIndex();

	// Object: Function FarlightPatchRuntime.PakReader.Close
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102392da0
	// Return & Params: [ Num(0) Size(0x0) ]
	void Close();
};

// Object: Class FarlightPatchRuntime.PakWriter
// Inherited Bytes: 0x28 | Struct Size: 0xc0
struct UPakWriter : UObject {
	// Fields
	char pad_0x28[0x98]; // Offset: 0x28 | Size: 0x98
};

