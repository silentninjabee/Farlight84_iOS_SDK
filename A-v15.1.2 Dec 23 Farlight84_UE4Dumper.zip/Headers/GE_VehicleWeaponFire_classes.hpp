#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass GE_VehicleWeaponFire.GE_VehicleWeaponFire_C
// Inherited Bytes: 0x848 | Struct Size: 0x848
struct UGE_VehicleWeaponFire_C : UGameplayEffect {
};

