#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class GameplayTags.BlueprintGameplayTagLibrary
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UBlueprintGameplayTagLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object: Function GameplayTags.BlueprintGameplayTagLibrary.RemoveGameplayTag
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104b5e978
	// Return & Params: [ Num(3) Size(0x29) ]
	bool RemoveGameplayTag(struct FGameplayTagContainer& TagContainer, struct FGameplayTag Tag);

	// Object: Function GameplayTags.BlueprintGameplayTagLibrary.NotEqual_TagTag
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x104b5de90
	// Return & Params: [ Num(3) Size(0x19) ]
	bool NotEqual_TagTag(struct FGameplayTag A, struct FString B);

	// Object: Function GameplayTags.BlueprintGameplayTagLibrary.NotEqual_TagContainerTagContainer
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x104b5dd08
	// Return & Params: [ Num(3) Size(0x31) ]
	bool NotEqual_TagContainerTagContainer(struct FGameplayTagContainer A, struct FString B);

	// Object: Function GameplayTags.BlueprintGameplayTagLibrary.NotEqual_GameplayTagContainer
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x104b5e634
	// Return & Params: [ Num(3) Size(0x41) ]
	bool NotEqual_GameplayTagContainer(struct FGameplayTagContainer& A, struct FGameplayTagContainer& B);

	// Object: Function GameplayTags.BlueprintGameplayTagLibrary.NotEqual_GameplayTag
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x104b5f53c
	// Return & Params: [ Num(3) Size(0x11) ]
	bool NotEqual_GameplayTag(struct FGameplayTag A, struct FGameplayTag B);

	// Object: Function GameplayTags.BlueprintGameplayTagLibrary.MatchesTag
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x104b5f818
	// Return & Params: [ Num(4) Size(0x12) ]
	bool MatchesTag(struct FGameplayTag TagOne, struct FGameplayTag TagTwo, bool bExactMatch);

	// Object: Function GameplayTags.BlueprintGameplayTagLibrary.MatchesAnyTags
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x104b5f6cc
	// Return & Params: [ Num(4) Size(0x2a) ]
	bool MatchesAnyTags(struct FGameplayTag TagOne, struct FGameplayTagContainer& OtherContainer, bool bExactMatch);

	// Object: Function GameplayTags.BlueprintGameplayTagLibrary.MakeLiteralGameplayTagContainer
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x104b5e548
	// Return & Params: [ Num(2) Size(0x40) ]
	struct FGameplayTagContainer MakeLiteralGameplayTagContainer(struct FGameplayTagContainer Value);

	// Object: Function GameplayTags.BlueprintGameplayTagLibrary.MakeLiteralGameplayTag
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x104b5f3b0
	// Return & Params: [ Num(2) Size(0x10) ]
	struct FGameplayTag MakeLiteralGameplayTag(struct FGameplayTag Value);

	// Object: Function GameplayTags.BlueprintGameplayTagLibrary.MakeGameplayTagQuery
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x104b5e1b8
	// Return & Params: [ Num(2) Size(0x90) ]
	struct FGameplayTagQuery MakeGameplayTagQuery(struct FGameplayTagQuery TagQuery);

	// Object: Function GameplayTags.BlueprintGameplayTagLibrary.MakeGameplayTagContainerFromTag
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x104b5e3e8
	// Return & Params: [ Num(2) Size(0x28) ]
	struct FGameplayTagContainer MakeGameplayTagContainerFromTag(struct FGameplayTag SingleTag);

	// Object: Function GameplayTags.BlueprintGameplayTagLibrary.MakeGameplayTagContainerFromArray
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x104b5e48c
	// Return & Params: [ Num(2) Size(0x30) ]
	struct FGameplayTagContainer MakeGameplayTagContainerFromArray(struct TArray<struct FGameplayTag>& GameplayTags);

	// Object: Function GameplayTags.BlueprintGameplayTagLibrary.IsTagQueryEmpty
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x104b5ee30
	// Return & Params: [ Num(2) Size(0x49) ]
	bool IsTagQueryEmpty(struct FGameplayTagQuery& TagQuery);

	// Object: Function GameplayTags.BlueprintGameplayTagLibrary.IsGameplayTagValid
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x104b5f4bc
	// Return & Params: [ Num(2) Size(0x9) ]
	bool IsGameplayTagValid(struct FGameplayTag GameplayTag);

	// Object: Function GameplayTags.BlueprintGameplayTagLibrary.HasTag
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x104b5f1c0
	// Return & Params: [ Num(4) Size(0x2a) ]
	bool HasTag(struct FGameplayTagContainer& TagContainer, struct FGameplayTag Tag, bool bExactMatch);

	// Object: Function GameplayTags.BlueprintGameplayTagLibrary.HasAnyTags
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x104b5f058
	// Return & Params: [ Num(4) Size(0x42) ]
	bool HasAnyTags(struct FGameplayTagContainer& TagContainer, struct FGameplayTagContainer& OtherContainer, bool bExactMatch);

	// Object: Function GameplayTags.BlueprintGameplayTagLibrary.HasAllTags
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x104b5eef0
	// Return & Params: [ Num(4) Size(0x42) ]
	bool HasAllTags(struct FGameplayTagContainer& TagContainer, struct FGameplayTagContainer& OtherContainer, bool bExactMatch);

	// Object: Function GameplayTags.BlueprintGameplayTagLibrary.HasAllMatchingGameplayTags
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x104b5e0b0
	// Return & Params: [ Num(3) Size(0x31) ]
	bool HasAllMatchingGameplayTags(struct TScriptInterface<IGameplayTagAssetInterface> TagContainerInterface, struct FGameplayTagContainer& OtherContainer);

	// Object: Function GameplayTags.BlueprintGameplayTagLibrary.GetTagName
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x104b5f430
	// Return & Params: [ Num(2) Size(0x10) ]
	struct FName GetTagName(struct FGameplayTag& GameplayTag);

	// Object: Function GameplayTags.BlueprintGameplayTagLibrary.GetNumGameplayTagsInContainer
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x104b5f308
	// Return & Params: [ Num(2) Size(0x24) ]
	int32_t GetNumGameplayTagsInContainer(struct FGameplayTagContainer& TagContainer);

	// Object: Function GameplayTags.BlueprintGameplayTagLibrary.GetDebugStringFromGameplayTagContainer
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x104b5dc28
	// Return & Params: [ Num(2) Size(0x30) ]
	struct FString GetDebugStringFromGameplayTagContainer(struct FGameplayTagContainer& TagContainer);

	// Object: Function GameplayTags.BlueprintGameplayTagLibrary.GetDebugStringFromGameplayTag
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x104b5db64
	// Return & Params: [ Num(2) Size(0x18) ]
	struct FString GetDebugStringFromGameplayTag(struct FGameplayTag GameplayTag);

	// Object: Function GameplayTags.BlueprintGameplayTagLibrary.GetAllActorsOfClassMatchingTagQuery
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104b5eb50
	// Return & Params: [ Num(4) Size(0x68) ]
	void GetAllActorsOfClassMatchingTagQuery(struct UObject* WorldContextObject, struct AActor* ActorClass, struct FGameplayTagQuery& GameplayTagQuery, struct TArray<struct AActor*>& OutActors);

	// Object: Function GameplayTags.BlueprintGameplayTagLibrary.EqualEqual_GameplayTagContainer
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x104b5e750
	// Return & Params: [ Num(3) Size(0x41) ]
	bool EqualEqual_GameplayTagContainer(struct FGameplayTagContainer& A, struct FGameplayTagContainer& B);

	// Object: Function GameplayTags.BlueprintGameplayTagLibrary.EqualEqual_GameplayTag
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x104b5f604
	// Return & Params: [ Num(3) Size(0x11) ]
	bool EqualEqual_GameplayTag(struct FGameplayTag A, struct FGameplayTag B);

	// Object: Function GameplayTags.BlueprintGameplayTagLibrary.DoesTagAssetInterfaceHaveTag
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x104b5dfd4
	// Return & Params: [ Num(3) Size(0x19) ]
	bool DoesTagAssetInterfaceHaveTag(struct TScriptInterface<IGameplayTagAssetInterface> TagContainerInterface, struct FGameplayTag Tag);

	// Object: Function GameplayTags.BlueprintGameplayTagLibrary.DoesContainerMatchTagQuery
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x104b5ecfc
	// Return & Params: [ Num(3) Size(0x69) ]
	bool DoesContainerMatchTagQuery(struct FGameplayTagContainer& TagContainer, struct FGameplayTagQuery& TagQuery);

	// Object: Function GameplayTags.BlueprintGameplayTagLibrary.BreakGameplayTagContainer
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x104b5e2ec
	// Return & Params: [ Num(2) Size(0x30) ]
	void BreakGameplayTagContainer(struct FGameplayTagContainer& GameplayTagContainer, struct TArray<struct FGameplayTag>& GameplayTags);

	// Object: Function GameplayTags.BlueprintGameplayTagLibrary.AppendGameplayTagContainers
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104b5e86c
	// Return & Params: [ Num(2) Size(0x40) ]
	void AppendGameplayTagContainers(struct FGameplayTagContainer& InOutTagContainer, struct FGameplayTagContainer& InTagContainer);

	// Object: Function GameplayTags.BlueprintGameplayTagLibrary.AddGameplayTag
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104b5ea6c
	// Return & Params: [ Num(2) Size(0x28) ]
	void AddGameplayTag(struct FGameplayTagContainer& TagContainer, struct FGameplayTag Tag);
};

// Object: Class GameplayTags.GameplayTagAssetInterface
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UGameplayTagAssetInterface : UInterface {
	// Functions

	// Object: Function GameplayTags.GameplayTagAssetInterface.HasMatchingGameplayTag
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104b60868
	// Return & Params: [ Num(2) Size(0x9) ]
	bool HasMatchingGameplayTag(struct FGameplayTag TagToCheck);

	// Object: Function GameplayTags.GameplayTagAssetInterface.HasAnyMatchingGameplayTags
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104b606e8
	// Return & Params: [ Num(2) Size(0x21) ]
	bool HasAnyMatchingGameplayTags(struct FGameplayTagContainer& TagContainer);

	// Object: Function GameplayTags.GameplayTagAssetInterface.HasAllMatchingGameplayTags
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104b607a8
	// Return & Params: [ Num(2) Size(0x21) ]
	bool HasAllMatchingGameplayTags(struct FGameplayTagContainer& TagContainer);

	// Object: Function GameplayTags.GameplayTagAssetInterface.GetOwnedGameplayTags
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104b60900
	// Return & Params: [ Num(1) Size(0x20) ]
	void GetOwnedGameplayTags(struct FGameplayTagContainer& TagContainer);
};

// Object: Class GameplayTags.EditableGameplayTagQuery
// Inherited Bytes: 0x28 | Struct Size: 0x98
struct UEditableGameplayTagQuery : UObject {
	// Fields
	struct FString UserDescription; // Offset: 0x28 | Size: 0x10
	char pad_0x38[0x10]; // Offset: 0x38 | Size: 0x10
	struct UEditableGameplayTagQueryExpression* RootExpression; // Offset: 0x48 | Size: 0x8
	struct FGameplayTagQuery TagQueryExportText_Helper; // Offset: 0x50 | Size: 0x48
};

// Object: Class GameplayTags.EditableGameplayTagQueryExpression
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UEditableGameplayTagQueryExpression : UObject {
};

// Object: Class GameplayTags.EditableGameplayTagQueryExpression_AnyTagsMatch
// Inherited Bytes: 0x28 | Struct Size: 0x48
struct UEditableGameplayTagQueryExpression_AnyTagsMatch : UEditableGameplayTagQueryExpression {
	// Fields
	struct FGameplayTagContainer Tags; // Offset: 0x28 | Size: 0x20
};

// Object: Class GameplayTags.EditableGameplayTagQueryExpression_AllTagsMatch
// Inherited Bytes: 0x28 | Struct Size: 0x48
struct UEditableGameplayTagQueryExpression_AllTagsMatch : UEditableGameplayTagQueryExpression {
	// Fields
	struct FGameplayTagContainer Tags; // Offset: 0x28 | Size: 0x20
};

// Object: Class GameplayTags.EditableGameplayTagQueryExpression_NoTagsMatch
// Inherited Bytes: 0x28 | Struct Size: 0x48
struct UEditableGameplayTagQueryExpression_NoTagsMatch : UEditableGameplayTagQueryExpression {
	// Fields
	struct FGameplayTagContainer Tags; // Offset: 0x28 | Size: 0x20
};

// Object: Class GameplayTags.EditableGameplayTagQueryExpression_AnyExprMatch
// Inherited Bytes: 0x28 | Struct Size: 0x38
struct UEditableGameplayTagQueryExpression_AnyExprMatch : UEditableGameplayTagQueryExpression {
	// Fields
	struct TArray<struct UEditableGameplayTagQueryExpression*> Expressions; // Offset: 0x28 | Size: 0x10
};

// Object: Class GameplayTags.EditableGameplayTagQueryExpression_AllExprMatch
// Inherited Bytes: 0x28 | Struct Size: 0x38
struct UEditableGameplayTagQueryExpression_AllExprMatch : UEditableGameplayTagQueryExpression {
	// Fields
	struct TArray<struct UEditableGameplayTagQueryExpression*> Expressions; // Offset: 0x28 | Size: 0x10
};

// Object: Class GameplayTags.EditableGameplayTagQueryExpression_NoExprMatch
// Inherited Bytes: 0x28 | Struct Size: 0x38
struct UEditableGameplayTagQueryExpression_NoExprMatch : UEditableGameplayTagQueryExpression {
	// Fields
	struct TArray<struct UEditableGameplayTagQueryExpression*> Expressions; // Offset: 0x28 | Size: 0x10
};

// Object: Class GameplayTags.GameplayTagsManager
// Inherited Bytes: 0x28 | Struct Size: 0x210
struct UGameplayTagsManager : UObject {
	// Fields
	char pad_0x28[0x98]; // Offset: 0x28 | Size: 0x98
	struct TArray<struct FGameplayTagSource> TagSources; // Offset: 0xc0 | Size: 0x10
	char pad_0xD0[0xe0]; // Offset: 0xd0 | Size: 0xe0
	struct TArray<struct UDataTable*> GameplayTagTables; // Offset: 0x1b0 | Size: 0x10
	char pad_0x1C0[0x50]; // Offset: 0x1c0 | Size: 0x50
};

// Object: Class GameplayTags.GameplayTagsList
// Inherited Bytes: 0x28 | Struct Size: 0x48
struct UGameplayTagsList : UObject {
	// Fields
	struct FString ConfigFileName; // Offset: 0x28 | Size: 0x10
	struct TArray<struct FGameplayTagTableRow> GameplayTagList; // Offset: 0x38 | Size: 0x10
};

// Object: Class GameplayTags.RestrictedGameplayTagsList
// Inherited Bytes: 0x28 | Struct Size: 0x48
struct URestrictedGameplayTagsList : UObject {
	// Fields
	struct FString ConfigFileName; // Offset: 0x28 | Size: 0x10
	struct TArray<struct FRestrictedGameplayTagTableRow> RestrictedGameplayTagList; // Offset: 0x38 | Size: 0x10
};

// Object: Class GameplayTags.GameplayTagsSettings
// Inherited Bytes: 0x48 | Struct Size: 0xb8
struct UGameplayTagsSettings : UGameplayTagsList {
	// Fields
	bool ImportTagsFromConfig; // Offset: 0x48 | Size: 0x1
	bool WarnOnInvalidTags; // Offset: 0x49 | Size: 0x1
	bool FastReplication; // Offset: 0x4a | Size: 0x1
	char pad_0x4B[0x5]; // Offset: 0x4b | Size: 0x5
	struct FString InvalidTagCharacters; // Offset: 0x50 | Size: 0x10
	struct TArray<struct FGameplayTagCategoryRemap> CategoryRemapping; // Offset: 0x60 | Size: 0x10
	struct TArray<struct FSoftObjectPath> GameplayTagTableList; // Offset: 0x70 | Size: 0x10
	struct TArray<struct FGameplayTagRedirect> GameplayTagRedirects; // Offset: 0x80 | Size: 0x10
	struct TArray<struct FName> CommonlyReplicatedTags; // Offset: 0x90 | Size: 0x10
	int32_t NumBitsForContainerSize; // Offset: 0xa0 | Size: 0x4
	int32_t NetIndexFirstBitSegment; // Offset: 0xa4 | Size: 0x4
	struct TArray<struct FRestrictedConfigInfo> RestrictedConfigFiles; // Offset: 0xa8 | Size: 0x10
};

// Object: Class GameplayTags.GameplayTagsDeveloperSettings
// Inherited Bytes: 0x28 | Struct Size: 0x38
struct UGameplayTagsDeveloperSettings : UObject {
	// Fields
	struct FString DeveloperConfigName; // Offset: 0x28 | Size: 0x10
};

