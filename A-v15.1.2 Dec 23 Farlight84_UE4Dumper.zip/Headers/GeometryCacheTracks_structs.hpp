#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct GeometryCacheTracks.MovieSceneGeometryCacheParams
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FMovieSceneGeometryCacheParams {
	// Fields
	struct UGeometryCache* GeometryCacheAsset; // Offset: 0x0 | Size: 0x8
	struct FFrameNumber FirstLoopStartFrameOffset; // Offset: 0x8 | Size: 0x4
	struct FFrameNumber StartFrameOffset; // Offset: 0xc | Size: 0x4
	struct FFrameNumber EndFrameOffset; // Offset: 0x10 | Size: 0x4
	float PlayRate; // Offset: 0x14 | Size: 0x4
	char bReverse : 1; // Offset: 0x18 | Size: 0x1
	char pad_0x18_1 : 7; // Offset: 0x18 | Size: 0x1
	char pad_0x19[0x3]; // Offset: 0x19 | Size: 0x3
	float StartOffset; // Offset: 0x1c | Size: 0x4
	float EndOffset; // Offset: 0x20 | Size: 0x4
	char pad_0x24[0x4]; // Offset: 0x24 | Size: 0x4
	struct FSoftObjectPath GeometryCache; // Offset: 0x28 | Size: 0x18
};

// Object: ScriptStruct GeometryCacheTracks.MovieSceneGeometryCacheSectionTemplate
// Inherited Bytes: 0x18 | Struct Size: 0x60
struct FMovieSceneGeometryCacheSectionTemplate : FMovieSceneEvalTemplate {
	// Fields
	struct FMovieSceneGeometryCacheSectionTemplateParameters Params; // Offset: 0x18 | Size: 0x48
};

// Object: ScriptStruct GeometryCacheTracks.MovieSceneGeometryCacheSectionTemplateParameters
// Inherited Bytes: 0x40 | Struct Size: 0x48
struct FMovieSceneGeometryCacheSectionTemplateParameters : FMovieSceneGeometryCacheParams {
	// Fields
	struct FFrameNumber SectionStartTime; // Offset: 0x40 | Size: 0x4
	struct FFrameNumber SectionEndTime; // Offset: 0x44 | Size: 0x4
};

