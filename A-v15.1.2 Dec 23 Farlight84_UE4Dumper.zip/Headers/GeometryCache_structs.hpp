#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct GeometryCache.TrackRenderData
// Inherited Bytes: 0x0 | Struct Size: 0x70
struct FTrackRenderData {
	// Fields
	char pad_0x0[0x70]; // Offset: 0x0 | Size: 0x70
};

// Object: ScriptStruct GeometryCache.GeometryCacheMeshData
// Inherited Bytes: 0x0 | Struct Size: 0xa8
struct FGeometryCacheMeshData {
	// Fields
	char pad_0x0[0xa8]; // Offset: 0x0 | Size: 0xa8
};

// Object: ScriptStruct GeometryCache.GeometryCacheVertexInfo
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FGeometryCacheVertexInfo {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
};

// Object: ScriptStruct GeometryCache.GeometryCacheMeshBatchInfo
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FGeometryCacheMeshBatchInfo {
	// Fields
	char pad_0x0[0xc]; // Offset: 0x0 | Size: 0xc
};

