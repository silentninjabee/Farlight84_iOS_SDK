#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct GeometryCollectionCore.RecordedTransformTrack
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FRecordedTransformTrack {
	// Fields
	struct TArray<struct FRecordedFrame> Records; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct GeometryCollectionCore.RecordedFrame
// Inherited Bytes: 0x0 | Struct Size: 0xb8
struct FRecordedFrame {
	// Fields
	struct TArray<struct FTransform> Transforms; // Offset: 0x0 | Size: 0x10
	struct TArray<int32_t> TransformIndices; // Offset: 0x10 | Size: 0x10
	struct TArray<int32_t> PreviousTransformIndices; // Offset: 0x20 | Size: 0x10
	struct TArray<bool> DisabledFlags; // Offset: 0x30 | Size: 0x10
	struct TArray<struct FSolverCollisionData> Collisions; // Offset: 0x40 | Size: 0x10
	struct TArray<struct FSolverBreakingData> Breakings; // Offset: 0x50 | Size: 0x10
	struct TSet<struct FSolverTrailingData> Trailings; // Offset: 0x60 | Size: 0x50
	float Timestamp; // Offset: 0xb0 | Size: 0x4
	char pad_0xB4[0x4]; // Offset: 0xb4 | Size: 0x4
};

// Object: ScriptStruct GeometryCollectionCore.SolverTrailingData
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FSolverTrailingData {
	// Fields
	struct FVector Location; // Offset: 0x0 | Size: 0xc
	struct FVector Velocity; // Offset: 0xc | Size: 0xc
	struct FVector AngularVelocity; // Offset: 0x18 | Size: 0xc
	float Mass; // Offset: 0x24 | Size: 0x4
	int32_t ParticleIndex; // Offset: 0x28 | Size: 0x4
	int32_t ParticleIndexMesh; // Offset: 0x2c | Size: 0x4
};

// Object: ScriptStruct GeometryCollectionCore.SolverBreakingData
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FSolverBreakingData {
	// Fields
	struct FVector Location; // Offset: 0x0 | Size: 0xc
	struct FVector Velocity; // Offset: 0xc | Size: 0xc
	struct FVector AngularVelocity; // Offset: 0x18 | Size: 0xc
	float Mass; // Offset: 0x24 | Size: 0x4
	int32_t ParticleIndex; // Offset: 0x28 | Size: 0x4
	int32_t ParticleIndexMesh; // Offset: 0x2c | Size: 0x4
};

// Object: ScriptStruct GeometryCollectionCore.SolverCollisionData
// Inherited Bytes: 0x0 | Struct Size: 0x6c
struct FSolverCollisionData {
	// Fields
	struct FVector Location; // Offset: 0x0 | Size: 0xc
	struct FVector AccumulatedImpulse; // Offset: 0xc | Size: 0xc
	struct FVector Normal; // Offset: 0x18 | Size: 0xc
	struct FVector Velocity1; // Offset: 0x24 | Size: 0xc
	struct FVector Velocity2; // Offset: 0x30 | Size: 0xc
	struct FVector AngularVelocity1; // Offset: 0x3c | Size: 0xc
	struct FVector AngularVelocity2; // Offset: 0x48 | Size: 0xc
	float Mass1; // Offset: 0x54 | Size: 0x4
	float Mass2; // Offset: 0x58 | Size: 0x4
	int32_t ParticleIndex; // Offset: 0x5c | Size: 0x4
	int32_t LevelsetIndex; // Offset: 0x60 | Size: 0x4
	int32_t ParticleIndexMesh; // Offset: 0x64 | Size: 0x4
	int32_t LevelsetIndexMesh; // Offset: 0x68 | Size: 0x4
};

