#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct GeometryCollectionTracks.MovieSceneGeometryCollectionParams
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FMovieSceneGeometryCollectionParams {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
	struct FSoftObjectPath GeometryCollectionCache; // Offset: 0x8 | Size: 0x18
	struct FFrameNumber StartFrameOffset; // Offset: 0x20 | Size: 0x4
	struct FFrameNumber EndFrameOffset; // Offset: 0x24 | Size: 0x4
	float PlayRate; // Offset: 0x28 | Size: 0x4
	char pad_0x2C[0x4]; // Offset: 0x2c | Size: 0x4
};

// Object: ScriptStruct GeometryCollectionTracks.MovieSceneGeometryCollectionSectionTemplate
// Inherited Bytes: 0x18 | Struct Size: 0x50
struct FMovieSceneGeometryCollectionSectionTemplate : FMovieSceneEvalTemplate {
	// Fields
	struct FMovieSceneGeometryCollectionSectionTemplateParameters Params; // Offset: 0x18 | Size: 0x38
};

// Object: ScriptStruct GeometryCollectionTracks.MovieSceneGeometryCollectionSectionTemplateParameters
// Inherited Bytes: 0x30 | Struct Size: 0x38
struct FMovieSceneGeometryCollectionSectionTemplateParameters : FMovieSceneGeometryCollectionParams {
	// Fields
	struct FFrameNumber SectionStartTime; // Offset: 0x2c | Size: 0x4
	struct FFrameNumber SectionEndTime; // Offset: 0x30 | Size: 0x4
};

