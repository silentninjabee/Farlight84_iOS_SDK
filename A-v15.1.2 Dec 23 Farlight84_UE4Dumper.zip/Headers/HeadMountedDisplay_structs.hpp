#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct HeadMountedDisplay.XRDeviceId
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FXRDeviceId {
	// Fields
	struct FName SystemName; // Offset: 0x0 | Size: 0x8
	int32_t DeviceID; // Offset: 0x8 | Size: 0x4
};

