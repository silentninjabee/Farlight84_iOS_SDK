#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class IOSDeviceProfileSelector.IOSDeviceProfileMatchingRules
// Inherited Bytes: 0x28 | Struct Size: 0x38
struct UIOSDeviceProfileMatchingRules : UObject {
	// Fields
	struct TArray<struct FIOSProfileMatch> MatchProfile; // Offset: 0x28 | Size: 0x10
};

