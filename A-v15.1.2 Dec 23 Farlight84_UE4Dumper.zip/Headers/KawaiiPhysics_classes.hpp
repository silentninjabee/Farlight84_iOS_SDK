#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class KawaiiPhysics.KawaiiPhysicsLimitsDataAsset
// Inherited Bytes: 0x30 | Struct Size: 0x60
struct UKawaiiPhysicsLimitsDataAsset : UDataAsset {
	// Fields
	struct TArray<struct FSphericalLimit> SphericalLimits; // Offset: 0x30 | Size: 0x10
	struct TArray<struct FCapsuleLimit> CapsuleLimits; // Offset: 0x40 | Size: 0x10
	struct TArray<struct FPlanarLimit> PlanarLimits; // Offset: 0x50 | Size: 0x10
};

