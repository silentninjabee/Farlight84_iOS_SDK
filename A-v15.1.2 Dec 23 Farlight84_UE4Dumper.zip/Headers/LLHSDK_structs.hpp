#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct LLHSDK.LLHSDKLoginUser
// Inherited Bytes: 0x0 | Struct Size: 0x48
struct FLLHSDKLoginUser {
	// Fields
	bool bValid; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x7]; // Offset: 0x1 | Size: 0x7
	struct FString AppUid; // Offset: 0x8 | Size: 0x10
	struct FString AppToken; // Offset: 0x18 | Size: 0x10
	enum class ELLHSDKLoginType LoginType; // Offset: 0x28 | Size: 0x1
	char pad_0x29[0x7]; // Offset: 0x29 | Size: 0x7
	struct FString Name; // Offset: 0x30 | Size: 0x10
	bool bIsGuest; // Offset: 0x40 | Size: 0x1
	bool bIsSafe; // Offset: 0x41 | Size: 0x1
	char pad_0x42[0x2]; // Offset: 0x42 | Size: 0x2
	int32_t LimitDeviceCount; // Offset: 0x44 | Size: 0x4
};

// Object: ScriptStruct LLHSDK.LLHSDKLoginUserInfo
// Inherited Bytes: 0x0 | Struct Size: 0x140
struct FLLHSDKLoginUserInfo {
	// Fields
	bool bValid; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x7]; // Offset: 0x1 | Size: 0x7
	struct FString Phone; // Offset: 0x8 | Size: 0x10
	struct FString Email; // Offset: 0x18 | Size: 0x10
	struct FString UserRegion; // Offset: 0x28 | Size: 0x10
	struct FString IP; // Offset: 0x38 | Size: 0x10
	int32_t RestPoint; // Offset: 0x48 | Size: 0x4
	bool bDomesticHasBindAnyOne; // Offset: 0x4c | Size: 0x1
	bool bIsNewReg; // Offset: 0x4d | Size: 0x1
	bool bIsIdentified; // Offset: 0x4e | Size: 0x1
	bool bIsAbusePrevented; // Offset: 0x4f | Size: 0x1
	struct TSet<enum class ELLHSDKLoginType> BoundLoginTypes; // Offset: 0x50 | Size: 0x50
	struct TMap<enum class ELLHSDKLoginType, struct FLLHSDKLoginUserInfoMap> BoundInfoMap; // Offset: 0xa0 | Size: 0x50
	struct FLLHSDKLoginUserInfoMap UserExtra; // Offset: 0xf0 | Size: 0x50
};

// Object: ScriptStruct LLHSDK.LLHSDKLoginUserInfoMap
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FLLHSDKLoginUserInfoMap {
	// Fields
	struct TMap<struct FString, struct FString> Info; // Offset: 0x0 | Size: 0x50
};

// Object: ScriptStruct LLHSDK.SDKSocialUserInfo
// Inherited Bytes: 0x0 | Struct Size: 0x38
struct FSDKSocialUserInfo {
	// Fields
	struct FString Avatar; // Offset: 0x0 | Size: 0x10
	struct FString Name; // Offset: 0x10 | Size: 0x10
	struct FString Email; // Offset: 0x20 | Size: 0x10
	int32_t BindType; // Offset: 0x30 | Size: 0x4
	char pad_0x34[0x4]; // Offset: 0x34 | Size: 0x4
};

// Object: ScriptStruct LLHSDK.LLHSDKGenericSkuItemsDetailList
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FLLHSDKGenericSkuItemsDetailList {
	// Fields
	struct TArray<struct FLLHSDKGoogleSkuItemDetail> Items; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct LLHSDK.LLHSDKGoogleSkuItemDetail
// Inherited Bytes: 0x0 | Struct Size: 0x70
struct FLLHSDKGoogleSkuItemDetail {
	// Fields
	enum class ELLHSDKPayGenericSkuItemType ItemType; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x7]; // Offset: 0x1 | Size: 0x7
	struct FString Title; // Offset: 0x8 | Size: 0x10
	struct FString Desc; // Offset: 0x18 | Size: 0x10
	struct FString Price; // Offset: 0x28 | Size: 0x10
	struct FString Sku; // Offset: 0x38 | Size: 0x10
	struct FString Currency; // Offset: 0x48 | Size: 0x10
	int32_t PriceAmountMicros; // Offset: 0x58 | Size: 0x4
	char pad_0x5C[0x4]; // Offset: 0x5c | Size: 0x4
	struct FString SdkConvertSymbol; // Offset: 0x60 | Size: 0x10
};

// Object: ScriptStruct LLHSDK.LLHSDKCustomerServiceExtra
// Inherited Bytes: 0x0 | Struct Size: 0x60
struct FLLHSDKCustomerServiceExtra {
	// Fields
	struct TArray<struct FString> Tags; // Offset: 0x0 | Size: 0x10
	struct TMap<struct FString, struct FString> CustomParams; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct LLHSDK.LLHSDKLocaleInfo
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FLLHSDKLocaleInfo {
	// Fields
	struct FString Language; // Offset: 0x0 | Size: 0x10
	struct FString Region; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct LLHSDK.LLHSDKGenericSkuSubItemsDetailList
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FLLHSDKGenericSkuSubItemsDetailList {
	// Fields
	struct TArray<struct FLLHSDKGoogleSkuSubItemDetail> Items; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct LLHSDK.LLHSDKGoogleSkuSubItemDetail
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FLLHSDKGoogleSkuSubItemDetail {
	// Fields
	enum class ELLHSDKPayGenericSkuItemType ItemType; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x7]; // Offset: 0x1 | Size: 0x7
	struct FString Title; // Offset: 0x8 | Size: 0x10
	struct FString Desc; // Offset: 0x18 | Size: 0x10
	struct FString Sku; // Offset: 0x28 | Size: 0x10
	int32_t SubGoodsSize; // Offset: 0x38 | Size: 0x4
	char pad_0x3C[0x4]; // Offset: 0x3c | Size: 0x4
	struct TArray<struct FLLHSDKGoogleSkuSubGood> SubGoods; // Offset: 0x40 | Size: 0x10
};

// Object: ScriptStruct LLHSDK.LLHSDKGoogleSkuSubGood
// Inherited Bytes: 0x0 | Struct Size: 0x38
struct FLLHSDKGoogleSkuSubGood {
	// Fields
	struct FString OfferToken; // Offset: 0x0 | Size: 0x10
	int32_t CombineSize; // Offset: 0x10 | Size: 0x4
	char pad_0x14[0x4]; // Offset: 0x14 | Size: 0x4
	struct TArray<struct FLLHSDKGoogleSubCombineItem> CombineItems; // Offset: 0x18 | Size: 0x10
	struct TArray<struct FString> OfferTags; // Offset: 0x28 | Size: 0x10
};

// Object: ScriptStruct LLHSDK.LLHSDKGoogleSubCombineItem
// Inherited Bytes: 0x0 | Struct Size: 0x70
struct FLLHSDKGoogleSubCombineItem {
	// Fields
	int32_t Index; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct FString ProductID; // Offset: 0x8 | Size: 0x10
	struct FString CombineItemName1; // Offset: 0x18 | Size: 0x10
	struct FString CombineItemName2; // Offset: 0x28 | Size: 0x10
	struct FString Price; // Offset: 0x38 | Size: 0x10
	struct FString Currency; // Offset: 0x48 | Size: 0x10
	int32_t PriceAmountMicros; // Offset: 0x58 | Size: 0x4
	char pad_0x5C[0x4]; // Offset: 0x5c | Size: 0x4
	struct FString SdkConvertSymbol; // Offset: 0x60 | Size: 0x10
};

