#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class Landscape.ControlPointMeshActor
// Inherited Bytes: 0x228 | Struct Size: 0x230
struct AControlPointMeshActor : AActor {
	// Fields
	struct UControlPointMeshComponent* ControlPointMeshComponent; // Offset: 0x228 | Size: 0x8
};

// Object: Class Landscape.ControlPointMeshComponent
// Inherited Bytes: 0x660 | Struct Size: 0x660
struct UControlPointMeshComponent : UStaticMeshComponent {
	// Fields
	float VirtualTextureMainPassMaxDrawDistance; // Offset: 0x65c | Size: 0x4
};

// Object: Class Landscape.LandscapeProxy
// Inherited Bytes: 0x228 | Struct Size: 0x560
struct ALandscapeProxy : AActor {
	// Fields
	struct ULandscapeSplinesComponent* SplineComponent; // Offset: 0x228 | Size: 0x8
	struct FGuid LandscapeGuid; // Offset: 0x230 | Size: 0x10
	struct FIntPoint LandscapeSectionOffset; // Offset: 0x240 | Size: 0x8
	int32_t MaxLODLevel; // Offset: 0x248 | Size: 0x4
	float LODDistanceFactor; // Offset: 0x24c | Size: 0x4
	enum class ELandscapeLODFalloff LODFalloff; // Offset: 0x250 | Size: 0x1
	char pad_0x251[0x3]; // Offset: 0x251 | Size: 0x3
	float ComponentScreenSizeToUseSubSections; // Offset: 0x254 | Size: 0x4
	float LOD0ScreenSize; // Offset: 0x258 | Size: 0x4
	float LOD0DistributionSetting; // Offset: 0x25c | Size: 0x4
	float LODDistributionSetting; // Offset: 0x260 | Size: 0x4
	float TessellationComponentScreenSize; // Offset: 0x264 | Size: 0x4
	bool UseTessellationComponentScreenSizeFalloff; // Offset: 0x268 | Size: 0x1
	char pad_0x269[0x3]; // Offset: 0x269 | Size: 0x3
	float TessellationComponentScreenSizeFalloff; // Offset: 0x26c | Size: 0x4
	int32_t OccluderGeometryLOD; // Offset: 0x270 | Size: 0x4
	int32_t StaticLightingLOD; // Offset: 0x274 | Size: 0x4
	struct UPhysicalMaterial* DefaultPhysMaterial; // Offset: 0x278 | Size: 0x8
	float StreamingDistanceMultiplier; // Offset: 0x280 | Size: 0x4
	char pad_0x284[0x4]; // Offset: 0x284 | Size: 0x4
	struct UMaterialInterface* LandscapeMaterial; // Offset: 0x288 | Size: 0x8
	char pad_0x290[0x20]; // Offset: 0x290 | Size: 0x20
	struct UMaterialInterface* LandscapeHoleMaterial; // Offset: 0x2b0 | Size: 0x8
	struct TArray<struct FLandscapeProxyMaterialOverride> LandscapeMaterialsOverride; // Offset: 0x2b8 | Size: 0x10
	bool bMeshHoles; // Offset: 0x2c8 | Size: 0x1
	char MeshHolesMaxLod; // Offset: 0x2c9 | Size: 0x1
	char pad_0x2CA[0x6]; // Offset: 0x2ca | Size: 0x6
	struct TArray<struct URuntimeVirtualTexture*> RuntimeVirtualTextures; // Offset: 0x2d0 | Size: 0x10
	int32_t VirtualTextureNumLods; // Offset: 0x2e0 | Size: 0x4
	int32_t VirtualTextureLodBias; // Offset: 0x2e4 | Size: 0x4
	enum class ERuntimeVirtualTextureMainPassType VirtualTextureRenderPassType; // Offset: 0x2e8 | Size: 0x1
	char pad_0x2E9[0x3]; // Offset: 0x2e9 | Size: 0x3
	float NegativeZBoundsExtension; // Offset: 0x2ec | Size: 0x4
	float PositiveZBoundsExtension; // Offset: 0x2f0 | Size: 0x4
	char pad_0x2F4[0x4]; // Offset: 0x2f4 | Size: 0x4
	struct TArray<struct ULandscapeComponent*> LandscapeComponents; // Offset: 0x2f8 | Size: 0x10
	struct TArray<struct ULandscapeHeightfieldCollisionComponent*> CollisionComponents; // Offset: 0x308 | Size: 0x10
	struct TArray<struct UHierarchicalInstancedStaticMeshComponent*> FoliageComponents; // Offset: 0x318 | Size: 0x10
	char pad_0x328[0x64]; // Offset: 0x328 | Size: 0x64
	bool bHasLandscapeGrass; // Offset: 0x38c | Size: 0x1
	char pad_0x38D[0x3]; // Offset: 0x38d | Size: 0x3
	float StaticLightingResolution; // Offset: 0x390 | Size: 0x4
	char bCastStaticShadow : 1; // Offset: 0x394 | Size: 0x1
	char bCastShadowAsTwoSided : 1; // Offset: 0x394 | Size: 0x1
	char bCastFarShadow : 1; // Offset: 0x394 | Size: 0x1
	char bAffectDistanceFieldLighting : 1; // Offset: 0x394 | Size: 0x1
	char pad_0x394_4 : 4; // Offset: 0x394 | Size: 0x1
	struct FLightingChannels LightingChannels; // Offset: 0x395 | Size: 0x1
	char bUseMaterialPositionOffsetInStaticLighting : 1; // Offset: 0x396 | Size: 0x1
	char bRenderCustomDepth : 1; // Offset: 0x396 | Size: 0x1
	char pad_0x396_2 : 6; // Offset: 0x396 | Size: 0x1
	char pad_0x397[0x1]; // Offset: 0x397 | Size: 0x1
	int32_t CustomDepthStencilValue; // Offset: 0x398 | Size: 0x4
	float LDMaxDrawDistance; // Offset: 0x39c | Size: 0x4
	struct FLightmassPrimitiveSettings LightmassSettings; // Offset: 0x3a0 | Size: 0x18
	int32_t CollisionMipLevel; // Offset: 0x3b8 | Size: 0x4
	int32_t SimpleCollisionMipLevel; // Offset: 0x3bc | Size: 0x4
	float CollisionThickness; // Offset: 0x3c0 | Size: 0x4
	char pad_0x3C4[0x4]; // Offset: 0x3c4 | Size: 0x4
	struct FBodyInstance BodyInstance; // Offset: 0x3c8 | Size: 0x130
	char bGenerateOverlapEvents : 1; // Offset: 0x4f8 | Size: 0x1
	char bBakeMaterialPositionOffsetIntoCollision : 1; // Offset: 0x4f8 | Size: 0x1
	char pad_0x4F8_2 : 6; // Offset: 0x4f8 | Size: 0x1
	char pad_0x4F9[0x3]; // Offset: 0x4f9 | Size: 0x3
	int32_t ComponentSizeQuads; // Offset: 0x4fc | Size: 0x4
	int32_t SubsectionSizeQuads; // Offset: 0x500 | Size: 0x4
	int32_t NumSubsections; // Offset: 0x504 | Size: 0x4
	char bUsedForNavigation : 1; // Offset: 0x508 | Size: 0x1
	char bFillCollisionUnderLandscapeForNavmesh : 1; // Offset: 0x508 | Size: 0x1
	char pad_0x508_2 : 6; // Offset: 0x508 | Size: 0x1
	bool bUseDynamicMaterialInstance; // Offset: 0x509 | Size: 0x1
	enum class ENavDataGatheringMode NavigationGeometryGatheringMode; // Offset: 0x50a | Size: 0x1
	bool bUseLandscapeForCullingInvisibleHLODVertices; // Offset: 0x50b | Size: 0x1
	bool bHasLayersContent; // Offset: 0x50c | Size: 0x1
	char pad_0x50D[0x3]; // Offset: 0x50d | Size: 0x3
	struct TMap<struct UTexture2D*, struct ULandscapeWeightmapUsage*> WeightmapUsageMap; // Offset: 0x510 | Size: 0x50

	// Functions

	// Object: Function Landscape.LandscapeProxy.SetLandscapeMaterialVectorParameterValue
	// Flags: [Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x1047aeef8
	// Return & Params: [ Num(2) Size(0x18) ]
	void SetLandscapeMaterialVectorParameterValue(struct FName ParameterName, struct FLinearColor Value);

	// Object: Function Landscape.LandscapeProxy.SetLandscapeMaterialTextureParameterValue
	// Flags: [Final|RequiredAPI|Native|Public|BlueprintCallable]
	// Offset: 0x1047aefc0
	// Return & Params: [ Num(2) Size(0x10) ]
	void SetLandscapeMaterialTextureParameterValue(struct FName ParameterName, struct UTexture* Value);

	// Object: Function Landscape.LandscapeProxy.SetLandscapeMaterialScalarParameterValue
	// Flags: [Final|RequiredAPI|Native|Public|BlueprintCallable]
	// Offset: 0x1047aee2c
	// Return & Params: [ Num(2) Size(0xc) ]
	void SetLandscapeMaterialScalarParameterValue(struct FName ParameterName, float Value);

	// Object: Function Landscape.LandscapeProxy.EditorSetLandscapeMaterial
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1047af418
	// Return & Params: [ Num(1) Size(0x8) ]
	void EditorSetLandscapeMaterial(struct UMaterialInterface* NewLandscapeMaterial);

	// Object: Function Landscape.LandscapeProxy.EditorApplySpline
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1047af088
	// Return & Params: [ Num(11) Size(0x30) ]
	void EditorApplySpline(struct USplineComponent* InSplineComponent, float StartWidth, float EndWidth, float StartSideFalloff, float EndSideFalloff, float StartRoll, float EndRoll, int32_t NumSubdivisions, bool bRaiseHeights, bool bLowerHeights, struct ULandscapeLayerInfoObject* PaintLayer);

	// Object: Function Landscape.LandscapeProxy.ChangeUseTessellationComponentScreenSizeFalloff
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1047af520
	// Return & Params: [ Num(1) Size(0x1) ]
	void ChangeUseTessellationComponentScreenSizeFalloff(bool InComponentScreenSizeToUseSubSections);

	// Object: Function Landscape.LandscapeProxy.ChangeTessellationComponentScreenSizeFalloff
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1047af498
	// Return & Params: [ Num(1) Size(0x4) ]
	void ChangeTessellationComponentScreenSizeFalloff(float InUseTessellationComponentScreenSizeFalloff);

	// Object: Function Landscape.LandscapeProxy.ChangeTessellationComponentScreenSize
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1047af638
	// Return & Params: [ Num(1) Size(0x4) ]
	void ChangeTessellationComponentScreenSize(float InTessellationComponentScreenSize);

	// Object: Function Landscape.LandscapeProxy.ChangeLODDistanceFactor
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1047af6c0
	// Return & Params: [ Num(1) Size(0x4) ]
	void ChangeLODDistanceFactor(float InLODDistanceFactor);

	// Object: Function Landscape.LandscapeProxy.ChangeComponentScreenSizeToUseSubSections
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1047af5b0
	// Return & Params: [ Num(1) Size(0x4) ]
	void ChangeComponentScreenSizeToUseSubSections(float InComponentScreenSizeToUseSubSections);
};

// Object: Class Landscape.Landscape
// Inherited Bytes: 0x560 | Struct Size: 0x560
struct ALandscape : ALandscapeProxy {
};

// Object: Class Landscape.LandscapeBlueprintBrushBase
// Inherited Bytes: 0x228 | Struct Size: 0x228
struct ALandscapeBlueprintBrushBase : AActor {
	// Functions

	// Object: Function Landscape.LandscapeBlueprintBrushBase.RequestLandscapeUpdate
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1047a8570
	// Return & Params: [ Num(0) Size(0x0) ]
	void RequestLandscapeUpdate();

	// Object: Function Landscape.LandscapeBlueprintBrushBase.Render
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x103a48564
	// Return & Params: [ Num(4) Size(0x20) ]
	struct UTextureRenderTarget2D* Render(bool InIsHeightmap, struct UTextureRenderTarget2D* InCombinedResult, struct FName& InWeightmapLayerName);

	// Object: Function Landscape.LandscapeBlueprintBrushBase.Initialize
	// Flags: [Event|Public|HasOutParms|HasDefaults|BlueprintEvent]
	// Offset: 0x103a48564
	// Return & Params: [ Num(3) Size(0x40) ]
	void Initialize(struct FTransform& InLandscapeTransform, struct FIntPoint& InLandscapeSize, struct FIntPoint& InLandscapeRenderTargetSize);

	// Object: Function Landscape.LandscapeBlueprintBrushBase.GetBlueprintRenderDependencies
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x103a48564
	// Return & Params: [ Num(1) Size(0x10) ]
	void GetBlueprintRenderDependencies(struct TArray<struct UTexture2D*>& OutStreamableAssets);
};

// Object: Class Landscape.LandscapeComponent
// Inherited Bytes: 0x5b0 | Struct Size: 0x7a0
struct ULandscapeComponent : UPrimitiveComponent {
	// Fields
	int32_t SectionBaseX; // Offset: 0x5a8 | Size: 0x4
	int32_t SectionBaseY; // Offset: 0x5ac | Size: 0x4
	int32_t ComponentSizeQuads; // Offset: 0x5b0 | Size: 0x4
	int32_t SubsectionSizeQuads; // Offset: 0x5b4 | Size: 0x4
	int32_t NumSubsections; // Offset: 0x5b8 | Size: 0x4
	struct UMaterialInterface* OverrideMaterial; // Offset: 0x5c0 | Size: 0x8
	struct UMaterialInterface* OverrideHoleMaterial; // Offset: 0x5c8 | Size: 0x8
	struct TArray<struct FLandscapeComponentMaterialOverride> OverrideMaterials; // Offset: 0x5d0 | Size: 0x10
	struct TArray<struct UMaterialInstanceConstant*> MaterialInstances; // Offset: 0x5e0 | Size: 0x10
	struct TArray<struct UMaterialInstanceDynamic*> MaterialInstancesDynamic; // Offset: 0x5f0 | Size: 0x10
	struct TArray<int8_t> LODIndexToMaterialIndex; // Offset: 0x600 | Size: 0x10
	struct TArray<int8_t> MaterialIndexToDisabledTessellationMaterial; // Offset: 0x610 | Size: 0x10
	struct UTexture2D* XYOffsetmapTexture; // Offset: 0x620 | Size: 0x8
	char pad_0x62C[0x4]; // Offset: 0x62c | Size: 0x4
	struct FVector4 WeightmapScaleBias; // Offset: 0x630 | Size: 0x10
	float WeightmapSubsectionOffset; // Offset: 0x640 | Size: 0x4
	char pad_0x644[0xc]; // Offset: 0x644 | Size: 0xc
	struct FVector4 HeightmapScaleBias; // Offset: 0x650 | Size: 0x10
	struct FBox CachedLocalBox; // Offset: 0x660 | Size: 0x1c
	LazyObjectProperty CollisionComponent; // Offset: 0x67c | Size: 0x1c
	struct UTexture2D* HeightmapTexture; // Offset: 0x698 | Size: 0x8
	struct TArray<struct FWeightmapLayerAllocationInfo> WeightmapLayerAllocations; // Offset: 0x6a0 | Size: 0x10
	struct TArray<struct UTexture2D*> WeightmapTextures; // Offset: 0x6b0 | Size: 0x10
	struct FGuid MapBuildDataId; // Offset: 0x6c0 | Size: 0x10
	struct TArray<struct FGuid> IrrelevantLights; // Offset: 0x6d0 | Size: 0x10
	int32_t CollisionMipLevel; // Offset: 0x6e0 | Size: 0x4
	int32_t SimpleCollisionMipLevel; // Offset: 0x6e4 | Size: 0x4
	float NegativeZBoundsExtension; // Offset: 0x6e8 | Size: 0x4
	float PositiveZBoundsExtension; // Offset: 0x6ec | Size: 0x4
	float StaticLightingResolution; // Offset: 0x6f0 | Size: 0x4
	int32_t ForcedLOD; // Offset: 0x6f4 | Size: 0x4
	int32_t LODBias; // Offset: 0x6f8 | Size: 0x4
	struct FGuid StateId; // Offset: 0x6fc | Size: 0x10
	struct FGuid BakedTextureMaterialGuid; // Offset: 0x70c | Size: 0x10
	char pad_0x71C[0x4]; // Offset: 0x71c | Size: 0x4
	struct UTexture2D* GIBakedBaseColorTexture; // Offset: 0x720 | Size: 0x8
	char MobileBlendableLayerMask; // Offset: 0x728 | Size: 0x1
	char pad_0x729[0x7]; // Offset: 0x729 | Size: 0x7
	struct UMaterialInterface* MobileMaterialInterface; // Offset: 0x730 | Size: 0x8
	struct TArray<struct UMaterialInterface*> MobileMaterialInterfaces; // Offset: 0x738 | Size: 0x10
	struct TArray<struct UTexture2D*> MobileWeightmapTextures; // Offset: 0x748 | Size: 0x10
	char pad_0x758[0x48]; // Offset: 0x758 | Size: 0x48

	// Functions

	// Object: Function Landscape.LandscapeComponent.GetMaterialInstanceDynamic
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1047a90f4
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UMaterialInstanceDynamic* GetMaterialInstanceDynamic(int32_t InIndex);

	// Object: Function Landscape.LandscapeComponent.EditorGetPaintLayerWeightByNameAtLocation
	// Flags: [Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1047a8f24
	// Return & Params: [ Num(3) Size(0x18) ]
	float EditorGetPaintLayerWeightByNameAtLocation(struct FVector& InLocation, struct FName InPaintLayerName);

	// Object: Function Landscape.LandscapeComponent.EditorGetPaintLayerWeightAtLocation
	// Flags: [Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1047a900c
	// Return & Params: [ Num(3) Size(0x1c) ]
	float EditorGetPaintLayerWeightAtLocation(struct FVector& InLocation, struct ULandscapeLayerInfoObject* PaintLayer);
};

// Object: Class Landscape.LandscapeGizmoActor
// Inherited Bytes: 0x228 | Struct Size: 0x228
struct ALandscapeGizmoActor : AActor {
};

// Object: Class Landscape.LandscapeGizmoActiveActor
// Inherited Bytes: 0x228 | Struct Size: 0x278
struct ALandscapeGizmoActiveActor : ALandscapeGizmoActor {
	// Fields
	char pad_0x228[0x50]; // Offset: 0x228 | Size: 0x50
};

// Object: Class Landscape.LandscapeGizmoRenderComponent
// Inherited Bytes: 0x5b0 | Struct Size: 0x5b0
struct ULandscapeGizmoRenderComponent : UPrimitiveComponent {
};

// Object: Class Landscape.LandscapeGrassType
// Inherited Bytes: 0x28 | Struct Size: 0x60
struct ULandscapeGrassType : UObject {
	// Fields
	struct TArray<struct FGrassVariety> GrassVarieties; // Offset: 0x28 | Size: 0x10
	char bEnableDensityScaling : 1; // Offset: 0x38 | Size: 0x1
	char pad_0x38_1 : 7; // Offset: 0x38 | Size: 0x1
	char pad_0x39[0x7]; // Offset: 0x39 | Size: 0x7
	struct UStaticMesh* GrassMesh; // Offset: 0x40 | Size: 0x8
	float GrassDensity; // Offset: 0x48 | Size: 0x4
	float PlacementJitter; // Offset: 0x4c | Size: 0x4
	int32_t StartCullDistance; // Offset: 0x50 | Size: 0x4
	int32_t EndCullDistance; // Offset: 0x54 | Size: 0x4
	bool RandomRotation; // Offset: 0x58 | Size: 0x1
	bool AlignToSurface; // Offset: 0x59 | Size: 0x1
	char pad_0x5A[0x6]; // Offset: 0x5a | Size: 0x6
};

// Object: Class Landscape.LandscapeHeightfieldCollisionComponent
// Inherited Bytes: 0x5b0 | Struct Size: 0x690
struct ULandscapeHeightfieldCollisionComponent : UPrimitiveComponent {
	// Fields
	struct TArray<struct ULandscapeLayerInfoObject*> ComponentLayerInfos; // Offset: 0x5a8 | Size: 0x10
	int32_t SectionBaseX; // Offset: 0x5b8 | Size: 0x4
	int32_t SectionBaseY; // Offset: 0x5bc | Size: 0x4
	int32_t CollisionSizeQuads; // Offset: 0x5c0 | Size: 0x4
	float CollisionScale; // Offset: 0x5c4 | Size: 0x4
	int32_t SimpleCollisionSizeQuads; // Offset: 0x5c8 | Size: 0x4
	struct TArray<char> CollisionQuadFlags; // Offset: 0x5d0 | Size: 0x10
	struct FGuid HeightfieldGuid; // Offset: 0x5e0 | Size: 0x10
	struct FBox CachedLocalBox; // Offset: 0x5f0 | Size: 0x1c
	LazyObjectProperty RenderComponent; // Offset: 0x60c | Size: 0x1c
	char pad_0x62C[0xc]; // Offset: 0x62c | Size: 0xc
	struct TArray<struct UPhysicalMaterial*> CookedPhysicalMaterials; // Offset: 0x638 | Size: 0x10
	char pad_0x648[0x48]; // Offset: 0x648 | Size: 0x48

	// Functions

	// Object: Function Landscape.LandscapeHeightfieldCollisionComponent.GetRenderComponent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1047aa06c
	// Return & Params: [ Num(1) Size(0x8) ]
	struct ULandscapeComponent* GetRenderComponent();
};

// Object: Class Landscape.LandscapeInfo
// Inherited Bytes: 0x28 | Struct Size: 0x210
struct ULandscapeInfo : UObject {
	// Fields
	LazyObjectProperty LandscapeActor; // Offset: 0x28 | Size: 0x1c
	struct FGuid LandscapeGuid; // Offset: 0x44 | Size: 0x10
	int32_t ComponentSizeQuads; // Offset: 0x54 | Size: 0x4
	int32_t SubsectionSizeQuads; // Offset: 0x58 | Size: 0x4
	int32_t ComponentNumSubsections; // Offset: 0x5c | Size: 0x4
	struct FVector DrawScale; // Offset: 0x60 | Size: 0xc
	char pad_0x6C[0xa4]; // Offset: 0x6c | Size: 0xa4
	struct TArray<struct ALandscapeStreamingProxy*> Proxies; // Offset: 0x110 | Size: 0x10
	char pad_0x120[0xf0]; // Offset: 0x120 | Size: 0xf0
};

// Object: Class Landscape.LandscapeInfoMap
// Inherited Bytes: 0x28 | Struct Size: 0x80
struct ULandscapeInfoMap : UObject {
	// Fields
	char pad_0x28[0x58]; // Offset: 0x28 | Size: 0x58
};

// Object: Class Landscape.LandscapeLayerInfoObject
// Inherited Bytes: 0x28 | Struct Size: 0x50
struct ULandscapeLayerInfoObject : UObject {
	// Fields
	struct FName LayerName; // Offset: 0x28 | Size: 0x8
	struct UPhysicalMaterial* PhysMaterial; // Offset: 0x30 | Size: 0x8
	float Hardness; // Offset: 0x38 | Size: 0x4
	struct FLinearColor LayerUsageDebugColor; // Offset: 0x3c | Size: 0x10
	char pad_0x4C[0x4]; // Offset: 0x4c | Size: 0x4
};

// Object: Class Landscape.LandscapeMaterialInstanceConstant
// Inherited Bytes: 0x410 | Struct Size: 0x428
struct ULandscapeMaterialInstanceConstant : UMaterialInstanceConstant {
	// Fields
	struct TArray<struct FLandscapeMaterialTextureStreamingInfo> TextureStreamingInfo; // Offset: 0x410 | Size: 0x10
	char bIsLayerThumbnail : 1; // Offset: 0x420 | Size: 0x1
	char bDisableTessellation : 1; // Offset: 0x420 | Size: 0x1
	char bMobile : 1; // Offset: 0x420 | Size: 0x1
	char bEditorToolUsage : 1; // Offset: 0x420 | Size: 0x1
	char pad_0x420_4 : 4; // Offset: 0x420 | Size: 0x1
	char pad_0x421[0x7]; // Offset: 0x421 | Size: 0x7
};

// Object: Class Landscape.LandscapeMeshCollisionComponent
// Inherited Bytes: 0x690 | Struct Size: 0x6a0
struct ULandscapeMeshCollisionComponent : ULandscapeHeightfieldCollisionComponent {
	// Fields
	struct FGuid MeshGuid; // Offset: 0x688 | Size: 0x10
};

// Object: Class Landscape.LandscapeMeshProxyActor
// Inherited Bytes: 0x228 | Struct Size: 0x230
struct ALandscapeMeshProxyActor : AActor {
	// Fields
	struct ULandscapeMeshProxyComponent* LandscapeMeshProxyComponent; // Offset: 0x228 | Size: 0x8
};

// Object: Class Landscape.LandscapeMeshProxyComponent
// Inherited Bytes: 0x660 | Struct Size: 0x690
struct ULandscapeMeshProxyComponent : UStaticMeshComponent {
	// Fields
	struct FGuid LandscapeGuid; // Offset: 0x65c | Size: 0x10
	struct TArray<struct FIntPoint> ProxyComponentBases; // Offset: 0x670 | Size: 0x10
	int8_t ProxyLOD; // Offset: 0x680 | Size: 0x1
	char pad_0x681[0xf]; // Offset: 0x681 | Size: 0xf
};

// Object: Class Landscape.LandscapeSettings
// Inherited Bytes: 0x38 | Struct Size: 0x50
struct ULandscapeSettings : UDeveloperSettings {
	// Fields
	int32_t MaxNumberOfLayers; // Offset: 0x38 | Size: 0x4
	bool bForceFourLayers; // Offset: 0x3c | Size: 0x1
	bool bPrintLayerInfos; // Offset: 0x3d | Size: 0x1
	char pad_0x3E[0x2]; // Offset: 0x3e | Size: 0x2
	struct TArray<struct FLandscapeSplineSegmentSurfaceName> LandscapeSplineSegmentSurfaces; // Offset: 0x40 | Size: 0x10
};

// Object: Class Landscape.LandscapeSplinesComponent
// Inherited Bytes: 0x5b0 | Struct Size: 0x5e0
struct ULandscapeSplinesComponent : UPrimitiveComponent {
	// Fields
	struct TArray<struct ULandscapeSplineControlPoint*> ControlPoints; // Offset: 0x5a8 | Size: 0x10
	struct TArray<struct ULandscapeSplineSegment*> Segments; // Offset: 0x5b8 | Size: 0x10
	struct TArray<struct UMeshComponent*> CookedForeignMeshComponents; // Offset: 0x5c8 | Size: 0x10

	// Functions

	// Object: Function Landscape.LandscapeSplinesComponent.GetSplineMeshComponents
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1047b25b0
	// Return & Params: [ Num(1) Size(0x10) ]
	struct TArray<struct USplineMeshComponent*> GetSplineMeshComponents();
};

// Object: Class Landscape.LandscapeSplineControlPoint
// Inherited Bytes: 0x28 | Struct Size: 0xa8
struct ULandscapeSplineControlPoint : UObject {
	// Fields
	struct FVector Location; // Offset: 0x28 | Size: 0xc
	struct FRotator Rotation; // Offset: 0x34 | Size: 0xc
	float Width; // Offset: 0x40 | Size: 0x4
	float LayerWidthRatio; // Offset: 0x44 | Size: 0x4
	float SideFalloff; // Offset: 0x48 | Size: 0x4
	float LeftSideFalloffFactor; // Offset: 0x4c | Size: 0x4
	float RightSideFalloffFactor; // Offset: 0x50 | Size: 0x4
	float LeftSideLayerFalloffFactor; // Offset: 0x54 | Size: 0x4
	float RightSideLayerFalloffFactor; // Offset: 0x58 | Size: 0x4
	float EndFalloff; // Offset: 0x5c | Size: 0x4
	struct TArray<struct FLandscapeSplineConnection> ConnectedSegments; // Offset: 0x60 | Size: 0x10
	struct TArray<struct FLandscapeSplineInterpPoint> Points; // Offset: 0x70 | Size: 0x10
	struct FBox Bounds; // Offset: 0x80 | Size: 0x1c
	char pad_0x9C[0x4]; // Offset: 0x9c | Size: 0x4
	struct UControlPointMeshComponent* LocalMeshComponent; // Offset: 0xa0 | Size: 0x8
};

// Object: Class Landscape.LandscapeSplineSegment
// Inherited Bytes: 0x28 | Struct Size: 0xb8
struct ULandscapeSplineSegment : UObject {
	// Fields
	struct FLandscapeSplineSegmentConnection Connections[0x2]; // Offset: 0x28 | Size: 0x30
	enum class ELandscapeSplineSegmentSurface SurfaceType; // Offset: 0x58 | Size: 0x1
	char bBranchTrunk : 1; // Offset: 0x59 | Size: 0x1
	char pad_0x59_1 : 7; // Offset: 0x59 | Size: 0x1
	char pad_0x5A[0x6]; // Offset: 0x5a | Size: 0x6
	struct FInterpCurveVector SplineInfo; // Offset: 0x60 | Size: 0x18
	struct TArray<struct FLandscapeSplineInterpPoint> Points; // Offset: 0x78 | Size: 0x10
	struct FBox Bounds; // Offset: 0x88 | Size: 0x1c
	char pad_0xA4[0x4]; // Offset: 0xa4 | Size: 0x4
	struct TArray<struct USplineMeshComponent*> LocalMeshComponents; // Offset: 0xa8 | Size: 0x10
};

// Object: Class Landscape.LandscapeStreamingProxy
// Inherited Bytes: 0x560 | Struct Size: 0x580
struct ALandscapeStreamingProxy : ALandscapeProxy {
	// Fields
	LazyObjectProperty LandscapeActor; // Offset: 0x560 | Size: 0x1c
	char pad_0x57C[0x4]; // Offset: 0x57c | Size: 0x4
};

// Object: Class Landscape.LandscapeSubsystem
// Inherited Bytes: 0x30 | Struct Size: 0x98
struct ULandscapeSubsystem : UWorldSubsystem {
	// Fields
	char pad_0x30[0x68]; // Offset: 0x30 | Size: 0x68
};

// Object: Class Landscape.LandscapeWeightmapUsage
// Inherited Bytes: 0x28 | Struct Size: 0x58
struct ULandscapeWeightmapUsage : UObject {
	// Fields
	struct ULandscapeComponent* ChannelUsage[0x4]; // Offset: 0x28 | Size: 0x20
	struct FGuid LayerGuid; // Offset: 0x48 | Size: 0x10
};

// Object: Class Landscape.MaterialExpressionLandscapeGrassOutput
// Inherited Bytes: 0x40 | Struct Size: 0x50
struct UMaterialExpressionLandscapeGrassOutput : UMaterialExpressionCustomOutput {
	// Fields
	struct TArray<struct FGrassInput> GrassTypes; // Offset: 0x40 | Size: 0x10
};

// Object: Class Landscape.MaterialExpressionLandscapeLayerBlend
// Inherited Bytes: 0x40 | Struct Size: 0x60
struct UMaterialExpressionLandscapeLayerBlend : UMaterialExpression {
	// Fields
	struct TArray<struct FLayerBlendInput> Layers; // Offset: 0x40 | Size: 0x10
	struct FGuid ExpressionGUID; // Offset: 0x50 | Size: 0x10
};

// Object: Class Landscape.MaterialExpressionLandscapeLayerCoords
// Inherited Bytes: 0x40 | Struct Size: 0x50
struct UMaterialExpressionLandscapeLayerCoords : UMaterialExpression {
	// Fields
	enum class ETerrainCoordMappingType MappingType; // Offset: 0x39 | Size: 0x1
	enum class ELandscapeCustomizedCoordType CustomUVType; // Offset: 0x3a | Size: 0x1
	float MappingScale; // Offset: 0x3c | Size: 0x4
	float MappingRotation; // Offset: 0x40 | Size: 0x4
	float MappingPanU; // Offset: 0x44 | Size: 0x4
	float MappingPanV; // Offset: 0x48 | Size: 0x4
};

// Object: Class Landscape.MaterialExpressionLandscapeLayerSample
// Inherited Bytes: 0x40 | Struct Size: 0x58
struct UMaterialExpressionLandscapeLayerSample : UMaterialExpression {
	// Fields
	struct FName ParameterName; // Offset: 0x3c | Size: 0x8
	float PreviewWeight; // Offset: 0x44 | Size: 0x4
	struct FGuid ExpressionGUID; // Offset: 0x48 | Size: 0x10
};

// Object: Class Landscape.MaterialExpressionLandscapeLayerSwitch
// Inherited Bytes: 0x40 | Struct Size: 0x80
struct UMaterialExpressionLandscapeLayerSwitch : UMaterialExpression {
	// Fields
	struct FExpressionInput LayerUsed; // Offset: 0x3c | Size: 0xc
	char pad_0x4C[0x4]; // Offset: 0x4c | Size: 0x4
	struct FExpressionInput LayerNotUsed; // Offset: 0x50 | Size: 0xc
	char pad_0x5C[0x8]; // Offset: 0x5c | Size: 0x8
	struct FName ParameterName; // Offset: 0x64 | Size: 0x8
	char PreviewUsed : 1; // Offset: 0x6c | Size: 0x1
	char pad_0x6C_1 : 7; // Offset: 0x6c | Size: 0x1
	char pad_0x6D[0x3]; // Offset: 0x6d | Size: 0x3
	struct FGuid ExpressionGUID; // Offset: 0x70 | Size: 0x10
};

// Object: Class Landscape.MaterialExpressionLandscapeLayerWeight
// Inherited Bytes: 0x40 | Struct Size: 0x90
struct UMaterialExpressionLandscapeLayerWeight : UMaterialExpression {
	// Fields
	struct FExpressionInput Base; // Offset: 0x3c | Size: 0xc
	char pad_0x4C[0x4]; // Offset: 0x4c | Size: 0x4
	struct FExpressionInput Layer; // Offset: 0x50 | Size: 0xc
	char pad_0x5C[0x8]; // Offset: 0x5c | Size: 0x8
	struct FName ParameterName; // Offset: 0x64 | Size: 0x8
	float PreviewWeight; // Offset: 0x6c | Size: 0x4
	struct FVector ConstBase; // Offset: 0x70 | Size: 0xc
	struct FGuid ExpressionGUID; // Offset: 0x7c | Size: 0x10
	char pad_0x8C[0x4]; // Offset: 0x8c | Size: 0x4
};

// Object: Class Landscape.MaterialExpressionLandscapeVisibilityMask
// Inherited Bytes: 0x40 | Struct Size: 0x50
struct UMaterialExpressionLandscapeVisibilityMask : UMaterialExpression {
	// Fields
	struct FGuid ExpressionGUID; // Offset: 0x3c | Size: 0x10
};

