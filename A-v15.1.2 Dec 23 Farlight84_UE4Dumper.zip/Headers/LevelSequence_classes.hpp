#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class LevelSequence.LevelSequence
// Inherited Bytes: 0x348 | Struct Size: 0x498
struct ULevelSequence : UMovieSceneSequence {
	// Fields
	struct UMovieScene* MovieScene; // Offset: 0x348 | Size: 0x8
	struct FLevelSequenceObjectReferenceMap ObjectReferences; // Offset: 0x350 | Size: 0x50
	struct FLevelSequenceBindingReferences BindingReferences; // Offset: 0x3a0 | Size: 0xa0
	struct TMap<struct FString, struct FLevelSequenceObject> PossessedObjects; // Offset: 0x440 | Size: 0x50
	struct UObject* DirectorClass; // Offset: 0x490 | Size: 0x8

	// Functions

	// Object: Function LevelSequence.LevelSequence.RemoveMetaDataByClass
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c46f34
	// Return & Params: [ Num(1) Size(0x8) ]
	void RemoveMetaDataByClass(struct UObject* InClass);

	// Object: Function LevelSequence.LevelSequence.FindOrAddMetaDataByClass
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c4701c
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UObject* FindOrAddMetaDataByClass(struct UObject* InClass);

	// Object: Function LevelSequence.LevelSequence.FindMetaDataByClass
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c47094
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UObject* FindMetaDataByClass(struct UObject* InClass);

	// Object: Function LevelSequence.LevelSequence.CopyMetaData
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c46fa4
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UObject* CopyMetaData(struct UObject* InMetaData);
};

// Object: Class LevelSequence.LevelSequenceActor
// Inherited Bytes: 0x228 | Struct Size: 0x2b8
struct ALevelSequenceActor : AActor {
	// Fields
	char pad_0x228[0x10]; // Offset: 0x228 | Size: 0x10
	struct FMovieSceneSequencePlaybackSettings PlaybackSettings; // Offset: 0x238 | Size: 0x14
	char pad_0x24C[0x4]; // Offset: 0x24c | Size: 0x4
	struct ULevelSequencePlayer* SequencePlayer; // Offset: 0x250 | Size: 0x8
	struct FSoftObjectPath LevelSequence; // Offset: 0x258 | Size: 0x18
	struct TArray<struct AActor*> AdditionalEventReceivers; // Offset: 0x270 | Size: 0x10
	struct FLevelSequenceCameraSettings CameraSettings; // Offset: 0x280 | Size: 0x2
	char pad_0x282[0x6]; // Offset: 0x282 | Size: 0x6
	struct ULevelSequenceBurnInOptions* BurnInOptions; // Offset: 0x288 | Size: 0x8
	struct UMovieSceneBindingOverrides* BindingOverrides; // Offset: 0x290 | Size: 0x8
	char bAutoPlay : 1; // Offset: 0x298 | Size: 0x1
	char bOverrideInstanceData : 1; // Offset: 0x298 | Size: 0x1
	char bReplicatePlayback : 1; // Offset: 0x298 | Size: 0x1
	char pad_0x298_3 : 5; // Offset: 0x298 | Size: 0x1
	char pad_0x299[0x7]; // Offset: 0x299 | Size: 0x7
	struct UObject* DefaultInstanceData; // Offset: 0x2a0 | Size: 0x8
	struct ULevelSequenceBurnIn* BurnInInstance; // Offset: 0x2a8 | Size: 0x8
	bool bShowBurnin; // Offset: 0x2b0 | Size: 0x1
	char pad_0x2B1[0x7]; // Offset: 0x2b1 | Size: 0x7

	// Functions

	// Object: Function LevelSequence.LevelSequenceActor.ShowBurnin
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c487ac
	// Return & Params: [ Num(0) Size(0x0) ]
	void ShowBurnin();

	// Object: Function LevelSequence.LevelSequenceActor.SetSequence
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c489c4
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetSequence(struct ULevelSequence* InSequence);

	// Object: Function LevelSequence.LevelSequenceActor.SetReplicatePlayback
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c48808
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetReplicatePlayback(bool ReplicatePlayback);

	// Object: Function LevelSequence.LevelSequenceActor.SetEventReceivers
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c48890
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetEventReceivers(struct TArray<struct AActor*> AdditionalReceivers);

	// Object: Function LevelSequence.LevelSequenceActor.SetBindingByTag
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104c48518
	// Return & Params: [ Num(3) Size(0x19) ]
	void SetBindingByTag(struct FName BindingTag, struct TArray<struct AActor*>& Actors, bool bAllowBindingsFromAsset);

	// Object: Function LevelSequence.LevelSequenceActor.SetBinding
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104c48650
	// Return & Params: [ Num(3) Size(0x29) ]
	void SetBinding(struct FMovieSceneObjectBindingID Binding, struct TArray<struct AActor*>& Actors, bool bAllowBindingsFromAsset);

	// Object: Function LevelSequence.LevelSequenceActor.ResetBindings
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c48048
	// Return & Params: [ Num(0) Size(0x0) ]
	void ResetBindings();

	// Object: Function LevelSequence.LevelSequenceActor.ResetBinding
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c4805c
	// Return & Params: [ Num(1) Size(0x18) ]
	void ResetBinding(struct FMovieSceneObjectBindingID Binding);

	// Object: Function LevelSequence.LevelSequenceActor.RemoveBindingByTag
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c48100
	// Return & Params: [ Num(2) Size(0x10) ]
	void RemoveBindingByTag(struct FName Tag, struct AActor* Actor);

	// Object: Function LevelSequence.LevelSequenceActor.RemoveBinding
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c481c8
	// Return & Params: [ Num(2) Size(0x20) ]
	void RemoveBinding(struct FMovieSceneObjectBindingID Binding, struct AActor* Actor);

	// Object: DelegateFunction LevelSequence.LevelSequenceActor.OnLevelSequenceLoaded__DelegateSignature
	// Flags: [Public|Delegate]
	// Offset: 0x103a48564
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnLevelSequenceLoaded__DelegateSignature();

	// Object: Function LevelSequence.LevelSequenceActor.LoadSequence
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c48a44
	// Return & Params: [ Num(1) Size(0x8) ]
	struct ULevelSequence* LoadSequence();

	// Object: Function LevelSequence.LevelSequenceActor.HideBurnin
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c487c0
	// Return & Params: [ Num(0) Size(0x0) ]
	void HideBurnin();

	// Object: Function LevelSequence.LevelSequenceActor.GetSequencePlayer
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c487d4
	// Return & Params: [ Num(1) Size(0x8) ]
	struct ULevelSequencePlayer* GetSequencePlayer();

	// Object: Function LevelSequence.LevelSequenceActor.GetSequence
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c48a78
	// Return & Params: [ Num(1) Size(0x8) ]
	struct ULevelSequence* GetSequence();

	// Object: Function LevelSequence.LevelSequenceActor.FindNamedBindings
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c47ebc
	// Return & Params: [ Num(2) Size(0x18) ]
	struct TArray<struct FMovieSceneObjectBindingID> FindNamedBindings(struct FName Tag);

	// Object: Function LevelSequence.LevelSequenceActor.FindNamedBinding
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c47fa0
	// Return & Params: [ Num(2) Size(0x20) ]
	struct FMovieSceneObjectBindingID FindNamedBinding(struct FName Tag);

	// Object: Function LevelSequence.LevelSequenceActor.AddBindingByTag
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c482b8
	// Return & Params: [ Num(3) Size(0x11) ]
	void AddBindingByTag(struct FName BindingTag, struct AActor* Actor, bool bAllowBindingsFromAsset);

	// Object: Function LevelSequence.LevelSequenceActor.AddBinding
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c483d4
	// Return & Params: [ Num(3) Size(0x21) ]
	void AddBinding(struct FMovieSceneObjectBindingID Binding, struct AActor* Actor, bool bAllowBindingsFromAsset);
};

// Object: Class LevelSequence.DefaultLevelSequenceInstanceData
// Inherited Bytes: 0x28 | Struct Size: 0x70
struct UDefaultLevelSequenceInstanceData : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
	struct AActor* TransformOriginActor; // Offset: 0x30 | Size: 0x8
	char pad_0x38[0x8]; // Offset: 0x38 | Size: 0x8
	struct FTransform TransformOrigin; // Offset: 0x40 | Size: 0x30
};

// Object: Class LevelSequence.LevelSequenceMetaData
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct ULevelSequenceMetaData : UInterface {
};

// Object: Class LevelSequence.LevelSequenceBurnInInitSettings
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct ULevelSequenceBurnInInitSettings : UObject {
};

// Object: Class LevelSequence.LevelSequenceBurnInOptions
// Inherited Bytes: 0x28 | Struct Size: 0x50
struct ULevelSequenceBurnInOptions : UObject {
	// Fields
	bool bUseBurnIn; // Offset: 0x28 | Size: 0x1
	char pad_0x29[0x7]; // Offset: 0x29 | Size: 0x7
	struct FSoftClassPath BurnInClass; // Offset: 0x30 | Size: 0x18
	struct ULevelSequenceBurnInInitSettings* Settings; // Offset: 0x48 | Size: 0x8

	// Functions

	// Object: Function LevelSequence.LevelSequenceBurnInOptions.SetBurnIn
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x104c47a30
	// Return & Params: [ Num(1) Size(0x18) ]
	void SetBurnIn(struct FSoftClassPath InBurnInClass);
};

// Object: Class LevelSequence.LevelSequenceBurnIn
// Inherited Bytes: 0x260 | Struct Size: 0x320
struct ULevelSequenceBurnIn : UUserWidget {
	// Fields
	struct FLevelSequencePlayerSnapshot FrameInformation; // Offset: 0x260 | Size: 0xb8
	struct ALevelSequenceActor* LevelSequenceActor; // Offset: 0x318 | Size: 0x8

	// Functions

	// Object: Function LevelSequence.LevelSequenceBurnIn.SetSettings
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x103a48564
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetSettings(struct UObject* InSettings);

	// Object: Function LevelSequence.LevelSequenceBurnIn.GetSettingsClass
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x104c49780
	// Return & Params: [ Num(1) Size(0x8) ]
	struct ULevelSequenceBurnInInitSettings* GetSettingsClass();
};

// Object: Class LevelSequence.LevelSequenceDirector
// Inherited Bytes: 0x28 | Struct Size: 0x30
struct ULevelSequenceDirector : UObject {
	// Fields
	struct ULevelSequencePlayer* Player; // Offset: 0x28 | Size: 0x8

	// Functions

	// Object: Function LevelSequence.LevelSequenceDirector.OnCreated
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x103a48564
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnCreated();
};

// Object: Class LevelSequence.LegacyLevelSequenceDirectorBlueprint
// Inherited Bytes: 0xa0 | Struct Size: 0xa0
struct ULegacyLevelSequenceDirectorBlueprint : UBlueprint {
};

// Object: Class LevelSequence.LevelSequencePlayer
// Inherited Bytes: 0x888 | Struct Size: 0x9a0
struct ULevelSequencePlayer : UMovieSceneSequencePlayer {
	// Fields
	struct FMulticastInlineDelegate OnCameraCut; // Offset: 0x888 | Size: 0x10
	char pad_0x898[0x108]; // Offset: 0x898 | Size: 0x108

	// Functions

	// Object: Function LevelSequence.LevelSequencePlayer.GetActiveCameraComponent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c4a4b8
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UCameraComponent* GetActiveCameraComponent();

	// Object: Function LevelSequence.LevelSequencePlayer.CreateLevelSequencePlayer
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104c4a4f0
	// Return & Params: [ Num(5) Size(0x38) ]
	struct ULevelSequencePlayer* CreateLevelSequencePlayer(struct UObject* WorldContextObject, struct ULevelSequence* LevelSequence, struct FMovieSceneSequencePlaybackSettings Settings, struct ALevelSequenceActor*& OutActor);
};

// Object: Class LevelSequence.LevelSequenceMediaController
// Inherited Bytes: 0x228 | Struct Size: 0x250
struct ALevelSequenceMediaController : AActor {
	// Fields
	char pad_0x228[0x8]; // Offset: 0x228 | Size: 0x8
	struct ALevelSequenceActor* Sequence; // Offset: 0x230 | Size: 0x8
	struct UMediaComponent* MediaComponent; // Offset: 0x238 | Size: 0x8
	float ServerStartTimeSeconds; // Offset: 0x240 | Size: 0x4
	char pad_0x244[0xc]; // Offset: 0x244 | Size: 0xc

	// Functions

	// Object: Function LevelSequence.LevelSequenceMediaController.SynchronizeToServer
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c4a9b0
	// Return & Params: [ Num(1) Size(0x4) ]
	void SynchronizeToServer(float DesyncThresholdSeconds);

	// Object: Function LevelSequence.LevelSequenceMediaController.Play
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c4aa68
	// Return & Params: [ Num(0) Size(0x0) ]
	void Play();

	// Object: Function LevelSequence.LevelSequenceMediaController.OnRep_ServerStartTimeSeconds
	// Flags: [Final|Native|Private]
	// Offset: 0x104c4a99c
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnRep_ServerStartTimeSeconds();

	// Object: Function LevelSequence.LevelSequenceMediaController.GetSequence
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c4aa30
	// Return & Params: [ Num(1) Size(0x8) ]
	struct ALevelSequenceActor* GetSequence();

	// Object: Function LevelSequence.LevelSequenceMediaController.GetMediaComponent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c4aa4c
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UMediaComponent* GetMediaComponent();
};

