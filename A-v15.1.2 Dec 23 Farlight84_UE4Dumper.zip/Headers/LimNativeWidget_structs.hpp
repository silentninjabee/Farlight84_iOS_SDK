#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct LimNativeWidget.ChatGMEDataResult
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FChatGMEDataResult {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
	bool bSuccess; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x7]; // Offset: 0x9 | Size: 0x7
	struct FString ErrorInfo; // Offset: 0x10 | Size: 0x10
	int32_t ErrorCode; // Offset: 0x20 | Size: 0x4
	char pad_0x24[0x4]; // Offset: 0x24 | Size: 0x4
};

// Object: ScriptStruct LimNativeWidget.ChatGMEDataDeviceInfo
// Inherited Bytes: 0x28 | Struct Size: 0x50
struct FChatGMEDataDeviceInfo : FChatGMEDataResult {
	// Fields
	struct FString DeviceID; // Offset: 0x28 | Size: 0x10
	struct FString DeviceName; // Offset: 0x38 | Size: 0x10
	bool bNewDevice; // Offset: 0x48 | Size: 0x1
	bool bUsedDevice; // Offset: 0x49 | Size: 0x1
	char pad_0x4A[0x6]; // Offset: 0x4a | Size: 0x6
};

// Object: ScriptStruct LimNativeWidget.ChatGMEDataRoomQuality
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FChatGMEDataRoomQuality {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
	int32_t Weight; // Offset: 0x8 | Size: 0x4
	float Loss; // Offset: 0xc | Size: 0x4
	int32_t Delay; // Offset: 0x10 | Size: 0x4
	char pad_0x14[0x4]; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct LimNativeWidget.ChatGMEDataChangeRoomType
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct FChatGMEDataChangeRoomType : FChatGMEDataResult {
	// Fields
	enum class EChatGMERoomTypeSubEvent NewRoomType; // Offset: 0x24 | Size: 0x1
};

// Object: ScriptStruct LimNativeWidget.ChatGMEDataFileInfo
// Inherited Bytes: 0x28 | Struct Size: 0x58
struct FChatGMEDataFileInfo : FChatGMEDataResult {
	// Fields
	struct FString FileID; // Offset: 0x28 | Size: 0x10
	struct FString FilePath; // Offset: 0x38 | Size: 0x10
	struct FString Text; // Offset: 0x48 | Size: 0x10
};

// Object: ScriptStruct LimNativeWidget.ChatGMEDataNumberOfAudioStreamsUpdate
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FChatGMEDataNumberOfAudioStreamsUpdate {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
	int32_t AudioStreamsNum; // Offset: 0x8 | Size: 0x4
	char pad_0xC[0x4]; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct LimNativeWidget.ChatGMEDataNumberOfUserUpdate
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FChatGMEDataNumberOfUserUpdate {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
	int32_t AllUserNum; // Offset: 0x8 | Size: 0x4
	int32_t AccUserNum; // Offset: 0xc | Size: 0x4
	int32_t ProxyUserNum; // Offset: 0x10 | Size: 0x4
	char pad_0x14[0x4]; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct LimNativeWidget.ChatGMEDataRecordCompleted
// Inherited Bytes: 0x28 | Struct Size: 0x48
struct FChatGMEDataRecordCompleted : FChatGMEDataResult {
	// Fields
	struct FString FilePath; // Offset: 0x28 | Size: 0x10
	struct FString Duration; // Offset: 0x38 | Size: 0x10
};

// Object: ScriptStruct LimNativeWidget.ChatGMEDataRoomOperator
// Inherited Bytes: 0x28 | Struct Size: 0x50
struct FChatGMEDataRoomOperator : FChatGMEDataResult {
	// Fields
	struct FString SenderId; // Offset: 0x28 | Size: 0x10
	struct FString ReceiverId; // Offset: 0x38 | Size: 0x10
	enum class EChatGMERoomManagementOp OperateType; // Offset: 0x48 | Size: 0x1
	bool bOpenCmd; // Offset: 0x49 | Size: 0x1
	char pad_0x4A[0x6]; // Offset: 0x4a | Size: 0x6
};

// Object: ScriptStruct LimNativeWidget.ChatGMEDataUserUpdate
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FChatGMEDataUserUpdate {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
	enum class EChatGMEEventIDUserUpdate EventId; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x7]; // Offset: 0x9 | Size: 0x7
	struct TArray<struct FString> UserList; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct LimNativeWidget.ChatGMEDataUserVolumes
// Inherited Bytes: 0x0 | Struct Size: 0x58
struct FChatGMEDataUserVolumes {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
	struct TMap<struct FString, float> Volumes; // Offset: 0x8 | Size: 0x50
};

// Object: ScriptStruct LimNativeWidget.ChatListConvData
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FChatListConvData {
	// Fields
	struct FString ConvID; // Offset: 0x0 | Size: 0x10
	enum class ELimNativeConvType ConvType; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x7]; // Offset: 0x11 | Size: 0x7
};

// Object: ScriptStruct LimNativeWidget.ChatListUserData
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FChatListUserData {
	// Fields
	struct FString Uid; // Offset: 0x0 | Size: 0x10
	struct FString NickName; // Offset: 0x10 | Size: 0x10
	struct FString AvatarUrl; // Offset: 0x20 | Size: 0x10
	struct FString AvatarFrameUrl; // Offset: 0x30 | Size: 0x10
	enum class ELimNativeUserSexType Sex; // Offset: 0x40 | Size: 0x1
	char pad_0x41[0x3]; // Offset: 0x41 | Size: 0x3
	int32_t VipLevel; // Offset: 0x44 | Size: 0x4
	bool IsShowVip; // Offset: 0x48 | Size: 0x1
	enum class ELimNativeFriendStateType OnlineState; // Offset: 0x49 | Size: 0x1
	char pad_0x4A[0x6]; // Offset: 0x4a | Size: 0x6
};

// Object: ScriptStruct LimNativeWidget.NewChatListMessageData
// Inherited Bytes: 0x0 | Struct Size: 0x178
struct FNewChatListMessageData {
	// Fields
	struct FString SendId; // Offset: 0x0 | Size: 0x10
	struct FString MsgId; // Offset: 0x10 | Size: 0x10
	enum class ELimNativeMsgState MsgState; // Offset: 0x20 | Size: 0x1
	char pad_0x21[0x7]; // Offset: 0x21 | Size: 0x7
	struct FString MsgContent; // Offset: 0x28 | Size: 0x10
	struct FString UUID; // Offset: 0x38 | Size: 0x10
	struct FString URL; // Offset: 0x48 | Size: 0x10
	struct FString Size; // Offset: 0x58 | Size: 0x10
	int32_t Duration; // Offset: 0x68 | Size: 0x4
	char pad_0x6C[0x4]; // Offset: 0x6c | Size: 0x4
	struct FString Ext; // Offset: 0x70 | Size: 0x10
	enum class ELimNativeMsgContentType MsgType; // Offset: 0x80 | Size: 0x1
	char pad_0x81[0x7]; // Offset: 0x81 | Size: 0x7
	struct FString ConvID; // Offset: 0x88 | Size: 0x10
	enum class ELimNativeConvType ConvType; // Offset: 0x98 | Size: 0x1
	char pad_0x99[0x7]; // Offset: 0x99 | Size: 0x7
	struct FString Timestamp; // Offset: 0xa0 | Size: 0x10
	struct FLimNativeIMChatMessage MsgData; // Offset: 0xb0 | Size: 0x70
	struct FLimNativeIMChatMessageBase MsgBase; // Offset: 0x120 | Size: 0x58
};

// Object: ScriptStruct LimNativeWidget.ChatListMessageData
// Inherited Bytes: 0x0 | Struct Size: 0x98
struct FChatListMessageData {
	// Fields
	struct FString SendId; // Offset: 0x0 | Size: 0x10
	struct FString MsgId; // Offset: 0x10 | Size: 0x10
	enum class ELimNativeMsgState MsgState; // Offset: 0x20 | Size: 0x1
	char pad_0x21[0x7]; // Offset: 0x21 | Size: 0x7
	struct FLimNativeIMChatMessage MsgData; // Offset: 0x28 | Size: 0x70
};

// Object: ScriptStruct LimNativeWidget.NertcUserUpdateData
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FNertcUserUpdateData {
	// Fields
	struct TArray<struct FString> UserList; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct LimNativeWidget.ChatLogicMessageData
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FChatLogicMessageData {
	// Fields
	int32_t Type; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct FLimNativeDataObjectBase BizObj; // Offset: 0x8 | Size: 0x8
};

