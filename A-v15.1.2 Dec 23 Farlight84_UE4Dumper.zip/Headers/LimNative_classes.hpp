#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class LimNative.LimNative
// Inherited Bytes: 0x28 | Struct Size: 0x3f0
struct ULimNative : UObject {
	// Fields
	bool ShowLog; // Offset: 0x28 | Size: 0x1
	char pad_0x29[0x7]; // Offset: 0x29 | Size: 0x7
	struct FMulticastInlineDelegate OnLog; // Offset: 0x30 | Size: 0x10
	struct FMulticastInlineDelegate OnEvent; // Offset: 0x40 | Size: 0x10
	struct FMulticastInlineDelegate OnGetLanguage; // Offset: 0x50 | Size: 0x10
	struct FMulticastInlineDelegate OnSetLanguage; // Offset: 0x60 | Size: 0x10
	struct FMulticastInlineDelegate OnSetAllConfig; // Offset: 0x70 | Size: 0x10
	struct FMulticastInlineDelegate OnSetReportConfig; // Offset: 0x80 | Size: 0x10
	struct FMulticastInlineDelegate OnSetParkConfig; // Offset: 0x90 | Size: 0x10
	struct FMulticastInlineDelegate OnGetResDir; // Offset: 0xa0 | Size: 0x10
	struct FMulticastInlineDelegate OnSetResDir; // Offset: 0xb0 | Size: 0x10
	struct FMulticastInlineDelegate OnLogin; // Offset: 0xc0 | Size: 0x10
	struct FMulticastInlineDelegate OnLoginV2; // Offset: 0xd0 | Size: 0x10
	struct FMulticastInlineDelegate OnLogout; // Offset: 0xe0 | Size: 0x10
	struct FMulticastInlineDelegate OnCreateGroup; // Offset: 0xf0 | Size: 0x10
	struct FMulticastInlineDelegate OnJoinGroup; // Offset: 0x100 | Size: 0x10
	struct FMulticastInlineDelegate OnQuitGroup; // Offset: 0x110 | Size: 0x10
	struct FMulticastInlineDelegate OnDestoryGroup; // Offset: 0x120 | Size: 0x10
	struct FMulticastInlineDelegate OnGetGroup; // Offset: 0x130 | Size: 0x10
	struct FMulticastInlineDelegate OnGetGroups; // Offset: 0x140 | Size: 0x10
	struct FMulticastInlineDelegate OnGetAttr; // Offset: 0x150 | Size: 0x10
	struct FMulticastInlineDelegate OnGetAllGroupAttr; // Offset: 0x160 | Size: 0x10
	struct FMulticastInlineDelegate OnSetGroupAttr; // Offset: 0x170 | Size: 0x10
	struct FMulticastInlineDelegate OnGetGroupMembers; // Offset: 0x180 | Size: 0x10
	struct FMulticastInlineDelegate OnAddGroupMember; // Offset: 0x190 | Size: 0x10
	struct FMulticastInlineDelegate OnRemoveGroupMember; // Offset: 0x1a0 | Size: 0x10
	struct FMulticastInlineDelegate OnGetGroupMember; // Offset: 0x1b0 | Size: 0x10
	struct FMulticastInlineDelegate OnSetConvRead; // Offset: 0x1c0 | Size: 0x10
	struct FMulticastInlineDelegate OnSendMsg; // Offset: 0x1d0 | Size: 0x10
	struct FMulticastInlineDelegate OnRevokeMsg; // Offset: 0x1e0 | Size: 0x10
	struct FMulticastInlineDelegate OnGetBeforeMsg; // Offset: 0x1f0 | Size: 0x10
	struct FMulticastInlineDelegate OnGetAfterMsg; // Offset: 0x200 | Size: 0x10
	struct FMulticastInlineDelegate OnGetMsgsById; // Offset: 0x210 | Size: 0x10
	struct FMulticastInlineDelegate OnGetCommonMsgs; // Offset: 0x220 | Size: 0x10
	struct FMulticastInlineDelegate OnSetMsgState; // Offset: 0x230 | Size: 0x10
	struct FMulticastInlineDelegate OnConvHandle; // Offset: 0x240 | Size: 0x10
	struct FMulticastInlineDelegate OnConvsGet; // Offset: 0x250 | Size: 0x10
	struct FMulticastInlineDelegate OnGetFriends; // Offset: 0x260 | Size: 0x10
	struct FMulticastInlineDelegate OnRemoveFriend; // Offset: 0x270 | Size: 0x10
	struct FMulticastInlineDelegate OnCreateFriendRequest; // Offset: 0x280 | Size: 0x10
	struct FMulticastInlineDelegate OnGetFriendRequests; // Offset: 0x290 | Size: 0x10
	struct FMulticastInlineDelegate OnAcceptFriendRequest; // Offset: 0x2a0 | Size: 0x10
	struct FMulticastInlineDelegate OnRefuseFriendRequest; // Offset: 0x2b0 | Size: 0x10
	struct FMulticastInlineDelegate OnCancelFriendRequest; // Offset: 0x2c0 | Size: 0x10
	struct FMulticastInlineDelegate OnGetBlockees; // Offset: 0x2d0 | Size: 0x10
	struct FMulticastInlineDelegate OnAddToBlockee; // Offset: 0x2e0 | Size: 0x10
	struct FMulticastInlineDelegate OnRemoveFromBlockee; // Offset: 0x2f0 | Size: 0x10
	struct FMulticastInlineDelegate OnGetUser; // Offset: 0x300 | Size: 0x10
	struct FMulticastInlineDelegate OnGetUsers; // Offset: 0x310 | Size: 0x10
	struct FMulticastInlineDelegate OnGetUsersState; // Offset: 0x320 | Size: 0x10
	struct FMulticastInlineDelegate OnReportMsg; // Offset: 0x330 | Size: 0x10
	struct FMulticastInlineDelegate OnTranslateText; // Offset: 0x340 | Size: 0x10
	struct FMulticastInlineDelegate OnCheckImage; // Offset: 0x350 | Size: 0x10
	struct FMulticastInlineDelegate OnGetOssToken; // Offset: 0x360 | Size: 0x10
	struct FMulticastInlineDelegate OnGetGMEToken; // Offset: 0x370 | Size: 0x10
	struct FMulticastInlineDelegate OnMsgReceived; // Offset: 0x380 | Size: 0x10
	struct FMulticastInlineDelegate OnMsgLogicReceived; // Offset: 0x390 | Size: 0x10
	struct FMulticastInlineDelegate OnMsgRevoked; // Offset: 0x3a0 | Size: 0x10
	struct FMulticastInlineDelegate OnGetMiscConfigInfo; // Offset: 0x3b0 | Size: 0x10
	struct FMulticastInlineDelegate OnGetConvChatLevelConfig; // Offset: 0x3c0 | Size: 0x10
	struct FMulticastInlineDelegate OnGetConnState; // Offset: 0x3d0 | Size: 0x10
	struct FMulticastInlineDelegate OnNetState; // Offset: 0x3e0 | Size: 0x10

	// Functions

	// Object: Function LimNative.LimNative.TranslateText
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1015057e0
	// Return & Params: [ Num(4) Size(0x38) ]
	void TranslateText(struct FLimNativeLowLevelWrapper& InCtx, struct FString InText, enum class ELimNativeSupportedLanguage InLang, struct FString ExtraInfo);

	// Object: Function LimNative.LimNative.SetResDir
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10150c0b0
	// Return & Params: [ Num(2) Size(0x20) ]
	void SetResDir(struct FLimNativeLowLevelWrapper& InCtx, struct FString InResDir);

	// Object: Function LimNative.LimNative.SetMsgState
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1015077e4
	// Return & Params: [ Num(2) Size(0x50) ]
	void SetMsgState(struct FLimNativeLowLevelWrapper& InCtx, struct FLimNativeSetMsgState& SetMsgParams);

	// Object: Function LimNative.LimNative.SetLogHandler
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10150c5e4
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetLogHandler(struct FLimNativeLowLevelWrapper& InCtx);

	// Object: Function LimNative.LimNative.SetLanguage
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10150c3e8
	// Return & Params: [ Num(2) Size(0x11) ]
	void SetLanguage(struct FLimNativeLowLevelWrapper& InCtx, enum class ELimNativeSupportedLanguage InLanguage);

	// Object: Function LimNative.LimNative.SetGroupAttr
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10150aa2c
	// Return & Params: [ Num(4) Size(0x40) ]
	void SetGroupAttr(struct FLimNativeLowLevelWrapper& InCtx, struct FString groupid, struct FString Key, struct FString Value);

	// Object: Function LimNative.LimNative.SetEventHandler
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10150c508
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetEventHandler(struct FLimNativeLowLevelWrapper& InCtx);

	// Object: Function LimNative.LimNative.SetConvRead
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10150b7e4
	// Return & Params: [ Num(5) Size(0x48) ]
	void SetConvRead(struct FLimNativeLowLevelWrapper& InCtx, struct FString ConvID, enum class ELimNativeConvType ConvType, struct FString InMsgID, struct FString Extra);

	// Object: Function LimNative.LimNative.SetAllConfig
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10150c1dc
	// Return & Params: [ Num(2) Size(0x88) ]
	void SetAllConfig(struct FLimNativeLowLevelWrapper& InCtx, struct FLimNativeInitConfig InConfig);

	// Object: Function LimNative.LimNative.SendVoiceMsg
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1015094a0
	// Return & Params: [ Num(7) Size(0xe8) ]
	void SendVoiceMsg(struct FLimNativeLowLevelWrapper& InCtx, struct FLimNativeIMVoiceMessage& VoiceMsg, struct FString ConvID, enum class ELimNativeConvType ConvType, struct FString Nonce, struct FString Timestamp, struct FString Extra);

	// Object: Function LimNative.LimNative.SendTextWithAtMsg
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101509e70
	// Return & Params: [ Num(7) Size(0xc0) ]
	void SendTextWithAtMsg(struct FLimNativeLowLevelWrapper& InCtx, struct FLimNativeIMTextWithAtMessage& TextWithAtMsg, struct FString ConvID, enum class ELimNativeConvType ConvType, struct FString Nonce, struct FString Timestamp, struct FString Extra);

	// Object: Function LimNative.LimNative.SendTextMsg
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10150a1dc
	// Return & Params: [ Num(7) Size(0xc0) ]
	void SendTextMsg(struct FLimNativeLowLevelWrapper& InCtx, struct FLimNativeIMTextMessage& TextMsg, struct FString ConvID, enum class ELimNativeConvType ConvType, struct FString Nonce, struct FString Timestamp, struct FString Extra);

	// Object: Function LimNative.LimNative.SendShareMsg
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101509180
	// Return & Params: [ Num(7) Size(0x118) ]
	void SendShareMsg(struct FLimNativeLowLevelWrapper& InCtx, struct FLimNativeIMShareMessage& ShareMsg, struct FString ConvID, enum class ELimNativeConvType ConvType, struct FString Nonce, struct FString Timestamp, struct FString Extra);

	// Object: Function LimNative.LimNative.SendImageMsg
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10150982c
	// Return & Params: [ Num(7) Size(0xf8) ]
	void SendImageMsg(struct FLimNativeLowLevelWrapper& InCtx, struct FLimNativeIMImageMessage& ImageMsg, struct FString ConvID, enum class ELimNativeConvType ConvType, struct FString Nonce, struct FString Timestamp, struct FString Extra);

	// Object: Function LimNative.LimNative.SendEmotionMsg
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101509b50
	// Return & Params: [ Num(7) Size(0x108) ]
	void SendEmotionMsg(struct FLimNativeLowLevelWrapper& InCtx, struct FLimNativeIMEmotionMessage& EmotionMsg, struct FString ConvID, enum class ELimNativeConvType ConvType, struct FString Nonce, struct FString Timestamp, struct FString Extra);

	// Object: Function LimNative.LimNative.RevokeVoiceMsg
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1015082a0
	// Return & Params: [ Num(6) Size(0xd8) ]
	void RevokeVoiceMsg(struct FLimNativeLowLevelWrapper& InCtx, struct FLimNativeIMVoiceMessage& VoiceMsg, struct FString ConvID, enum class ELimNativeConvType ConvType, struct FString Nonce, struct FString Timestamp);

	// Object: Function LimNative.LimNative.RevokeTextWithAtMsg
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101508b68
	// Return & Params: [ Num(6) Size(0xb0) ]
	void RevokeTextWithAtMsg(struct FLimNativeLowLevelWrapper& InCtx, struct FLimNativeIMTextWithAtMessage& TextWithAtMsg, struct FString ConvID, enum class ELimNativeConvType ConvType, struct FString Nonce, struct FString Timestamp);

	// Object: Function LimNative.LimNative.RevokeTextMsg
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101508e74
	// Return & Params: [ Num(6) Size(0xb0) ]
	void RevokeTextMsg(struct FLimNativeLowLevelWrapper& InCtx, struct FLimNativeIMTextMessage& TextMsg, struct FString ConvID, enum class ELimNativeConvType ConvType, struct FString Nonce, struct FString Timestamp);

	// Object: Function LimNative.LimNative.RevokeShareMsg
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101507fd8
	// Return & Params: [ Num(6) Size(0x108) ]
	void RevokeShareMsg(struct FLimNativeLowLevelWrapper& InCtx, struct FLimNativeIMShareMessage& ShareMsg, struct FString ConvID, enum class ELimNativeConvType ConvType, struct FString Nonce, struct FString Timestamp);

	// Object: Function LimNative.LimNative.RevokeImageMsg
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1015085d4
	// Return & Params: [ Num(6) Size(0xe8) ]
	void RevokeImageMsg(struct FLimNativeLowLevelWrapper& InCtx, struct FLimNativeIMImageMessage& ImageMsg, struct FString ConvID, enum class ELimNativeConvType ConvType, struct FString Nonce, struct FString Timestamp);

	// Object: Function LimNative.LimNative.RevokeEmotionMsg
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1015088a0
	// Return & Params: [ Num(6) Size(0xf8) ]
	void RevokeEmotionMsg(struct FLimNativeLowLevelWrapper& InCtx, struct FLimNativeIMEmotionMessage& EmotionMsg, struct FString ConvID, enum class ELimNativeConvType ConvType, struct FString Nonce, struct FString Timestamp);

	// Object: Function LimNative.LimNative.ReportMsg
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1015059b0
	// Return & Params: [ Num(3) Size(0x30) ]
	void ReportMsg(struct FLimNativeLowLevelWrapper& InCtx, struct FString InType, struct FString InMsg);

	// Object: Function LimNative.LimNative.RemoveGroupMember
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10150a548
	// Return & Params: [ Num(3) Size(0x30) ]
	void RemoveGroupMember(struct FLimNativeLowLevelWrapper& InCtx, struct FString groupid, struct FString memberid);

	// Object: Function LimNative.LimNative.RemoveFromBlockee
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1015063c8
	// Return & Params: [ Num(2) Size(0x20) ]
	void RemoveFromBlockee(struct FLimNativeLowLevelWrapper& InCtx, struct FString InUserId);

	// Object: Function LimNative.LimNative.RemoveFriend
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101507028
	// Return & Params: [ Num(3) Size(0x30) ]
	void RemoveFriend(struct FLimNativeLowLevelWrapper& InCtx, struct FString InUserId, struct FString InExtra);

	// Object: Function LimNative.LimNative.RefuseFriendRequest
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1015069cc
	// Return & Params: [ Num(3) Size(0x30) ]
	void RefuseFriendRequest(struct FLimNativeLowLevelWrapper& InCtx, struct FString InRequestID, struct FString InExtra);

	// Object: Function LimNative.LimNative.QuitGroup
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10150b294
	// Return & Params: [ Num(2) Size(0x20) ]
	void QuitGroup(struct FLimNativeLowLevelWrapper& InCtx, struct FString groupid);

	// Object: Function LimNative.LimNative.PostInitLIM
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10150c8a4
	// Return & Params: [ Num(3) Size(0x130) ]
	void PostInitLIM(struct FLimNativeLowLevelWrapper& ctx, struct FLimNativeReportConfig ReportConfig, struct FLimNativeParkConfig ParkConfig);

	// Object: Function LimNative.LimNative.MsgsGetCommon
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10150794c
	// Return & Params: [ Num(1) Size(0x10) ]
	void MsgsGetCommon(struct FLimNativeLowLevelWrapper& InCtx);

	// Object: Function LimNative.LimNative.Logout
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10150ba0c
	// Return & Params: [ Num(1) Size(0x10) ]
	void Logout(struct FLimNativeLowLevelWrapper& InCtx);

	// Object: Function LimNative.LimNative.LoginV2
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10150bae8
	// Return & Params: [ Num(3) Size(0x30) ]
	void LoginV2(struct FLimNativeLowLevelWrapper& InCtx, struct FString InEnvId, struct FString InRoleID);

	// Object: Function LimNative.LimNative.Login
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10150bc6c
	// Return & Params: [ Num(6) Size(0x60) ]
	void Login(struct FLimNativeLowLevelWrapper& InCtx, struct FString InAppId, struct FString InAppUserID, struct FString InToken, struct FString InRoleID, struct FString InExtra);

	// Object: DelegateFunction LimNative.LimNative.LIMOnTranslateTextDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103a48564
	// Return & Params: [ Num(2) Size(0x98) ]
	void LIMOnTranslateTextDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeTextTranslateCallBack& RetData);

	// Object: DelegateFunction LimNative.LimNative.LIMOnSetResDirDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103a48564
	// Return & Params: [ Num(2) Size(0x28) ]
	void LIMOnSetResDirDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeResDirConfig& RetData);

	// Object: DelegateFunction LimNative.LimNative.LIMOnSetReportConfigDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103a48564
	// Return & Params: [ Num(2) Size(0xd8) ]
	void LIMOnSetReportConfigDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeReportConfig& RetData);

	// Object: DelegateFunction LimNative.LimNative.LIMOnSetParkConfigDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103a48564
	// Return & Params: [ Num(2) Size(0x68) ]
	void LIMOnSetParkConfigDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeParkConfig& RetData);

	// Object: DelegateFunction LimNative.LimNative.LIMOnSetMsgStateDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103a48564
	// Return & Params: [ Num(2) Size(0x40) ]
	void LIMOnSetMsgStateDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnSetMsgStateCallBack& RetData);

	// Object: DelegateFunction LimNative.LimNative.LIMOnSetLanguageDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103a48564
	// Return & Params: [ Num(2) Size(0x20) ]
	void LIMOnSetLanguageDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeLanguageConfig& RetData);

	// Object: DelegateFunction LimNative.LimNative.LIMOnSetGroupAttrDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103a48564
	// Return & Params: [ Num(2) Size(0x40) ]
	void LIMOnSetGroupAttrDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnGroupAttrSetCallBack& RetData);

	// Object: DelegateFunction LimNative.LimNative.LIMOnSetConvReadDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103a48564
	// Return & Params: [ Num(2) Size(0x40) ]
	void LIMOnSetConvReadDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnSetConvReadCallBack& RetData);

	// Object: DelegateFunction LimNative.LimNative.LIMOnSetAllConfigDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103a48564
	// Return & Params: [ Num(2) Size(0x88) ]
	void LIMOnSetAllConfigDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeInitConfig& RetData);

	// Object: DelegateFunction LimNative.LimNative.LIMOnSendMsgDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103a48564
	// Return & Params: [ Num(2) Size(0xd0) ]
	void LIMOnSendMsgDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnSendMsgCallBack& RetData);

	// Object: DelegateFunction LimNative.LimNative.LIMOnRevokeMsgDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103a48564
	// Return & Params: [ Num(2) Size(0x40) ]
	void LIMOnRevokeMsgDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnRevokeMsgCallBack& RetData);

	// Object: DelegateFunction LimNative.LimNative.LIMOnReportMsgDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103a48564
	// Return & Params: [ Num(2) Size(0x40) ]
	void LIMOnReportMsgDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeDataCallBackBase& RetData);

	// Object: DelegateFunction LimNative.LimNative.LIMOnRemoveGroupMemberDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103a48564
	// Return & Params: [ Num(2) Size(0xa8) ]
	void LIMOnRemoveGroupMemberDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnGroupMemberRemoveCallBack& RetData);

	// Object: DelegateFunction LimNative.LimNative.LIMOnRemoveFromBlockeeDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103a48564
	// Return & Params: [ Num(2) Size(0x68) ]
	void LIMOnRemoveFromBlockeeDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeFriendCommonCallBack& RetData);

	// Object: DelegateFunction LimNative.LimNative.LIMOnRemoveFriendDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103a48564
	// Return & Params: [ Num(2) Size(0x68) ]
	void LIMOnRemoveFriendDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeFriendCommonCallBack& RetData);

	// Object: DelegateFunction LimNative.LimNative.LIMOnRefuseFriendRequestDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103a48564
	// Return & Params: [ Num(2) Size(0x68) ]
	void LIMOnRefuseFriendRequestDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeFriendCommonCallBack& RetData);

	// Object: DelegateFunction LimNative.LimNative.LIMOnQuitGroupDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103a48564
	// Return & Params: [ Num(2) Size(0x60) ]
	void LIMOnQuitGroupDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnGroupQuitCallBack& RetData);

	// Object: DelegateFunction LimNative.LimNative.LIMOnNetConnectStateDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103a48564
	// Return & Params: [ Num(2) Size(0x14) ]
	void LIMOnNetConnectStateDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, int32_t EventCode);

	// Object: DelegateFunction LimNative.LimNative.LIMOnMsgRevokedDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103a48564
	// Return & Params: [ Num(2) Size(0x70) ]
	void LIMOnMsgRevokedDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnMsgRevokedEventCallBack& RetData);

	// Object: DelegateFunction LimNative.LimNative.LIMOnMsgReceivedDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103a48564
	// Return & Params: [ Num(2) Size(0x50) ]
	void LIMOnMsgReceivedDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnMsgReceivedEventCallBack& RetData);

	// Object: DelegateFunction LimNative.LimNative.LIMOnMsgLogicReceivedDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103a48564
	// Return & Params: [ Num(2) Size(0x48) ]
	void LIMOnMsgLogicReceivedDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnMsgLogicReceivedEventCallBack& RetData);

	// Object: DelegateFunction LimNative.LimNative.LIMOnLogoutDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103a48564
	// Return & Params: [ Num(2) Size(0x40) ]
	void LIMOnLogoutDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnLogoutCallBack& RetData);

	// Object: DelegateFunction LimNative.LimNative.LIMOnLoginDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103a48564
	// Return & Params: [ Num(2) Size(0x40) ]
	void LIMOnLoginDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnLoginCallBack& RetData);

	// Object: DelegateFunction LimNative.LimNative.LIMOnJoinGroupDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103a48564
	// Return & Params: [ Num(2) Size(0x40) ]
	void LIMOnJoinGroupDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnGroupJoinCallBack& RetData);

	// Object: DelegateFunction LimNative.LimNative.LIMOnGetUsersStateDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103a48564
	// Return & Params: [ Num(2) Size(0xb8) ]
	void LIMOnGetUsersStateDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnGetUsersStateCallBack& RetData);

	// Object: DelegateFunction LimNative.LimNative.LIMOnGetUsersDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103a48564
	// Return & Params: [ Num(2) Size(0x78) ]
	void LIMOnGetUsersDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnGetUsersCallBack& RetData);

	// Object: DelegateFunction LimNative.LimNative.LIMOnGetUserDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103a48564
	// Return & Params: [ Num(2) Size(0x178) ]
	void LIMOnGetUserDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnGetUserCallBack& RetData);

	// Object: DelegateFunction LimNative.LimNative.LIMOnGetOssTokenDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103a48564
	// Return & Params: [ Num(2) Size(0xe0) ]
	void LIMOnGetOssTokenDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeGetOssTokenCallBack& RetData);

	// Object: DelegateFunction LimNative.LimNative.LIMOnGetMsgsDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103a48564
	// Return & Params: [ Num(2) Size(0x58) ]
	void LIMOnGetMsgsDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnGetMsgsCallBack& RetData);

	// Object: DelegateFunction LimNative.LimNative.LIMOnGetMiscConfigInfoDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103a48564
	// Return & Params: [ Num(2) Size(0x80) ]
	void LIMOnGetMiscConfigInfoDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeGetMiscConfigInfoCallBack& RetData);

	// Object: DelegateFunction LimNative.LimNative.LIMOnGetGroupsDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103a48564
	// Return & Params: [ Num(2) Size(0x60) ]
	void LIMOnGetGroupsDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnGroupsGetCallBack& RetData);

	// Object: DelegateFunction LimNative.LimNative.LIMOnGetGroupMembersDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103a48564
	// Return & Params: [ Num(2) Size(0xa8) ]
	void LIMOnGetGroupMembersDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnGroupMembersGetCallBack& RetData);

	// Object: DelegateFunction LimNative.LimNative.LIMOnGetGroupMemberDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103a48564
	// Return & Params: [ Num(2) Size(0x40) ]
	void LIMOnGetGroupMemberDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnGroupMemberGetCallBack& RetData);

	// Object: DelegateFunction LimNative.LimNative.LIMOnGetGroupDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103a48564
	// Return & Params: [ Num(2) Size(0xa8) ]
	void LIMOnGetGroupDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnGroupGetCallBack& RetData);

	// Object: DelegateFunction LimNative.LimNative.LIMOnGetGroupAttrDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103a48564
	// Return & Params: [ Num(2) Size(0x40) ]
	void LIMOnGetGroupAttrDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnGroupAttrGetCallBack& RetData);

	// Object: DelegateFunction LimNative.LimNative.LIMOnGetGMETokenDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103a48564
	// Return & Params: [ Num(2) Size(0x78) ]
	void LIMOnGetGMETokenDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeGetGMETokenCallBack& RetData);

	// Object: DelegateFunction LimNative.LimNative.LIMOnGetFriendsDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103a48564
	// Return & Params: [ Num(2) Size(0x78) ]
	void LIMOnGetFriendsDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnGetFriendCallBack& RetData);

	// Object: DelegateFunction LimNative.LimNative.LIMOnGetFriendRequestsDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103a48564
	// Return & Params: [ Num(2) Size(0x88) ]
	void LIMOnGetFriendRequestsDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnGetFriendRequestCallBack& RetData);

	// Object: DelegateFunction LimNative.LimNative.LIMOnGetConvChatLevelConfigDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103a48564
	// Return & Params: [ Num(2) Size(0x50) ]
	void LIMOnGetConvChatLevelConfigDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnGetConvChatLevelConfigCallBack& RetData);

	// Object: DelegateFunction LimNative.LimNative.LIMOnGetConnStateDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103a48564
	// Return & Params: [ Num(2) Size(0x50) ]
	void LIMOnGetConnStateDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeGetConnStateCallBack& RetData);

	// Object: DelegateFunction LimNative.LimNative.LIMOnGetConfigDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103a48564
	// Return & Params: [ Num(2) Size(0x60) ]
	void LIMOnGetConfigDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnGetConfigCallBack& RetData);

	// Object: DelegateFunction LimNative.LimNative.LIMOnGetCommonMsgsDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103a48564
	// Return & Params: [ Num(2) Size(0x78) ]
	void LIMOnGetCommonMsgsDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnGetCommonMsgsCallBack& RetData);

	// Object: DelegateFunction LimNative.LimNative.LIMOnGetBlockeesDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103a48564
	// Return & Params: [ Num(2) Size(0x78) ]
	void LIMOnGetBlockeesDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnGetBlockeesCallBack& RetData);

	// Object: DelegateFunction LimNative.LimNative.LIMOnGetAllGroupAttrDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103a48564
	// Return & Params: [ Num(2) Size(0x40) ]
	void LIMOnGetAllGroupAttrDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnGroupAttrGetAllCallBack& RetData);

	// Object: DelegateFunction LimNative.LimNative.LIMOnDestoryGroupDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103a48564
	// Return & Params: [ Num(2) Size(0x40) ]
	void LIMOnDestoryGroupDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnGroupDestoryCallBack& RetData);

	// Object: DelegateFunction LimNative.LimNative.LIMOnCreateGroupDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103a48564
	// Return & Params: [ Num(2) Size(0xa8) ]
	void LIMOnCreateGroupDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnCreateGroupCallBack& RetData);

	// Object: DelegateFunction LimNative.LimNative.LIMOnCreateFriendRequestDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103a48564
	// Return & Params: [ Num(2) Size(0x78) ]
	void LIMOnCreateFriendRequestDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnCreateFriendRequestCallBack& RetData);

	// Object: DelegateFunction LimNative.LimNative.LIMOnConvsGetDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103a48564
	// Return & Params: [ Num(2) Size(0x58) ]
	void LIMOnConvsGetDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnConvsGetCallBack& RetData);

	// Object: DelegateFunction LimNative.LimNative.LIMOnConvHandleynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103a48564
	// Return & Params: [ Num(2) Size(0x78) ]
	void LIMOnConvHandleynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnConvHandleCallBack& RetData);

	// Object: DelegateFunction LimNative.LimNative.LIMOnCheckImageDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103a48564
	// Return & Params: [ Num(2) Size(0x40) ]
	void LIMOnCheckImageDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeDataCallBackBase& RetData);

	// Object: DelegateFunction LimNative.LimNative.LIMOnCancelFriendRequestDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103a48564
	// Return & Params: [ Num(2) Size(0x68) ]
	void LIMOnCancelFriendRequestDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeFriendCommonCallBack& RetData);

	// Object: DelegateFunction LimNative.LimNative.LIMOnAddToBlockeeDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103a48564
	// Return & Params: [ Num(2) Size(0x68) ]
	void LIMOnAddToBlockeeDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeFriendCommonCallBack& RetData);

	// Object: DelegateFunction LimNative.LimNative.LIMOnAddGroupMemberDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103a48564
	// Return & Params: [ Num(2) Size(0xa8) ]
	void LIMOnAddGroupMemberDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnGroupMemberAddCallBack& RetData);

	// Object: DelegateFunction LimNative.LimNative.LIMOnAcceptFriendRequestDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103a48564
	// Return & Params: [ Num(2) Size(0x68) ]
	void LIMOnAcceptFriendRequestDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeFriendCommonCallBack& RetData);

	// Object: DelegateFunction LimNative.LimNative.LIMLogDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103a48564
	// Return & Params: [ Num(2) Size(0x20) ]
	void LIMLogDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FString InData);

	// Object: DelegateFunction LimNative.LimNative.LIMEventDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103a48564
	// Return & Params: [ Num(2) Size(0x20) ]
	void LIMEventDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FString InData);

	// Object: Function LimNative.LimNative.JoinGroup
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10150b3c0
	// Return & Params: [ Num(2) Size(0x20) ]
	void JoinGroup(struct FLimNativeLowLevelWrapper& InCtx, struct FString groupid);

	// Object: Function LimNative.LimNative.InitLIM
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10150cb1c
	// Return & Params: [ Num(3) Size(0x98) ]
	struct FLimNativeLowLevelWrapper InitLIM(struct FString InServerEnvID, struct FLimNativeInitConfig InConfig);

	// Object: Function LimNative.LimNative.GetUsersState
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101505fa4
	// Return & Params: [ Num(2) Size(0x20) ]
	void GetUsersState(struct FLimNativeLowLevelWrapper& InCtx, struct TArray<struct FString>& InUserIDs);

	// Object: Function LimNative.LimNative.GetUsers
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101506110
	// Return & Params: [ Num(2) Size(0x28) ]
	void GetUsers(struct FLimNativeLowLevelWrapper& InCtx, struct FUidList& InUserIDs);

	// Object: Function LimNative.LimNative.GetUser
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10150629c
	// Return & Params: [ Num(2) Size(0x20) ]
	void GetUser(struct FLimNativeLowLevelWrapper& InCtx, struct FString InUserId);

	// Object: Function LimNative.LimNative.GetResDir
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10150bef8
	// Return & Params: [ Num(1) Size(0x10) ]
	void GetResDir(struct FLimNativeLowLevelWrapper& InCtx);

	// Object: Function LimNative.LimNative.GetOssToken
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101505ec8
	// Return & Params: [ Num(1) Size(0x10) ]
	void GetOssToken(struct FLimNativeLowLevelWrapper& InCtx);

	// Object: Function LimNative.LimNative.GetMiscConfigInfo
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101505dec
	// Return & Params: [ Num(1) Size(0x10) ]
	void GetMiscConfigInfo(struct FLimNativeLowLevelWrapper& InCtx);

	// Object: Function LimNative.LimNative.GetMessagesByID
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101507bec
	// Return & Params: [ Num(5) Size(0x48) ]
	void GetMessagesByID(struct FLimNativeLowLevelWrapper& InCtx, struct FString InConvID, enum class ELimNativeConvType InConvType, struct FString InFromMsgID, struct FString InToMsgID);

	// Object: Function LimNative.LimNative.GetLIMVersion
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10150c6c0
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetLIMVersion();

	// Object: Function LimNative.LimNative.GetLimNativeInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10150cdc0
	// Return & Params: [ Num(1) Size(0x8) ]
	struct ULimNative* GetLimNativeInstance();

	// Object: Function LimNative.LimNative.GetLanguage
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10150bfd4
	// Return & Params: [ Num(1) Size(0x10) ]
	void GetLanguage(struct FLimNativeLowLevelWrapper& InCtx);

	// Object: Function LimNative.LimNative.GetGroups
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10150aeb8
	// Return & Params: [ Num(3) Size(0x30) ]
	void GetGroups(struct FLimNativeLowLevelWrapper& InCtx, struct FString Tag, struct FString Size);

	// Object: Function LimNative.LimNative.GetGroupMembers
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10150a850
	// Return & Params: [ Num(4) Size(0x40) ]
	void GetGroupMembers(struct FLimNativeLowLevelWrapper& InCtx, struct FString groupid, struct FString Tag, struct FString Size);

	// Object: Function LimNative.LimNative.GetGroupAttr
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10150ad34
	// Return & Params: [ Num(3) Size(0x30) ]
	void GetGroupAttr(struct FLimNativeLowLevelWrapper& InCtx, struct FString groupid, struct FString Key);

	// Object: Function LimNative.LimNative.GetGroupAllAttr
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10150ac08
	// Return & Params: [ Num(2) Size(0x20) ]
	void GetGroupAllAttr(struct FLimNativeLowLevelWrapper& InCtx, struct FString groupid);

	// Object: Function LimNative.LimNative.GetGroup
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10150b03c
	// Return & Params: [ Num(2) Size(0x20) ]
	void GetGroup(struct FLimNativeLowLevelWrapper& InCtx, struct FString groupid);

	// Object: Function LimNative.LimNative.GetGMEToken
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101505b34
	// Return & Params: [ Num(4) Size(0x40) ]
	void GetGMEToken(struct FLimNativeLowLevelWrapper& InCtx, struct FString InAppId, struct FString InUserId, struct FString InRoomId);

	// Object: Function LimNative.LimNative.GetFriendsV2
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1015071ac
	// Return & Params: [ Num(2) Size(0x11) ]
	void GetFriendsV2(struct FLimNativeLowLevelWrapper& InCtx, bool InNeedPresence);

	// Object: Function LimNative.LimNative.GetFriends
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1015072d4
	// Return & Params: [ Num(4) Size(0x38) ]
	void GetFriends(struct FLimNativeLowLevelWrapper& InCtx, int32_t InTag, struct FString InSize, struct FString InExtra);

	// Object: Function LimNative.LimNative.GetFriendRequests
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101506cd4
	// Return & Params: [ Num(4) Size(0x38) ]
	void GetFriendRequests(struct FLimNativeLowLevelWrapper& InCtx, int32_t InTag, struct FString InSize, struct FString InExtra);

	// Object: Function LimNative.LimNative.GetConvChatLevelConfig
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10150b708
	// Return & Params: [ Num(1) Size(0x10) ]
	void GetConvChatLevelConfig(struct FLimNativeLowLevelWrapper& InCtx);

	// Object: Function LimNative.LimNative.GetConnState
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101505d10
	// Return & Params: [ Num(1) Size(0x10) ]
	void GetConnState(struct FLimNativeLowLevelWrapper& InCtx);

	// Object: Function LimNative.LimNative.GetBlockees
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101506620
	// Return & Params: [ Num(4) Size(0x38) ]
	void GetBlockees(struct FLimNativeLowLevelWrapper& InCtx, int32_t InTag, struct FString InSize, struct FString InExtra);

	// Object: Function LimNative.LimNative.GetBeforeMessages
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101507e14
	// Return & Params: [ Num(4) Size(0x28) ]
	void GetBeforeMessages(struct FLimNativeLowLevelWrapper& InCtx, struct FString ConvID, enum class ELimNativeConvType ConvType, int32_t MsgId);

	// Object: Function LimNative.LimNative.GetAfterMessages
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101507a28
	// Return & Params: [ Num(4) Size(0x28) ]
	void GetAfterMessages(struct FLimNativeLowLevelWrapper& InCtx, struct FString ConvID, enum class ELimNativeConvType ConvType, int32_t MsgId);

	// Object: Function LimNative.LimNative.DestoryLimNativeInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10150cdac
	// Return & Params: [ Num(0) Size(0x0) ]
	void DestoryLimNativeInstance();

	// Object: Function LimNative.LimNative.DestoryGroup
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10150b168
	// Return & Params: [ Num(2) Size(0x20) ]
	void DestoryGroup(struct FLimNativeLowLevelWrapper& InCtx, struct FString groupid);

	// Object: Function LimNative.LimNative.CreateLIM
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10150c740
	// Return & Params: [ Num(2) Size(0x20) ]
	struct FLimNativeLowLevelWrapper CreateLIM(struct FString InServerEnvID);

	// Object: Function LimNative.LimNative.CreateGroup
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10150b4ec
	// Return & Params: [ Num(4) Size(0x40) ]
	void CreateGroup(struct FLimNativeLowLevelWrapper& InCtx, struct FString Name, struct TArray<struct FString>& members, struct FString Extra);

	// Object: Function LimNative.LimNative.CreateFriendRequest
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101506ea4
	// Return & Params: [ Num(3) Size(0x30) ]
	void CreateFriendRequest(struct FLimNativeLowLevelWrapper& InCtx, struct FString InUserId, struct FString InExtra);

	// Object: Function LimNative.LimNative.ConversationsGet
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1015074f4
	// Return & Params: [ Num(3) Size(0x28) ]
	void ConversationsGet(struct FLimNativeLowLevelWrapper& InCtx, int32_t Size, struct FString Extra);

	// Object: Function LimNative.LimNative.ConversationSetSticky
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1015074cc
	// Return & Params: [ Num(0) Size(0x0) ]
	void ConversationSetSticky();

	// Object: Function LimNative.LimNative.ConversationSetRead
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1015074e0
	// Return & Params: [ Num(0) Size(0x0) ]
	void ConversationSetRead();

	// Object: Function LimNative.LimNative.ConversationSetMute
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1015074b8
	// Return & Params: [ Num(0) Size(0x0) ]
	void ConversationSetMute();

	// Object: Function LimNative.LimNative.ConversationSetHide
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1015074a4
	// Return & Params: [ Num(0) Size(0x0) ]
	void ConversationSetHide();

	// Object: Function LimNative.LimNative.ConversationDiscard
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10150766c
	// Return & Params: [ Num(3) Size(0x21) ]
	void ConversationDiscard(struct FLimNativeLowLevelWrapper& InCtx, struct FString ConvID, enum class ELimNativeConvType ConvType);

	// Object: Function LimNative.LimNative.CheckImage
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1015056b4
	// Return & Params: [ Num(2) Size(0x20) ]
	void CheckImage(struct FLimNativeLowLevelWrapper& InCtx, struct FString InUrl);

	// Object: Function LimNative.LimNative.CancelFriendRequest
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1015067f0
	// Return & Params: [ Num(4) Size(0x40) ]
	void CancelFriendRequest(struct FLimNativeLowLevelWrapper& InCtx, struct FString InUserId, struct FString InRequestID, struct FString InExtra);

	// Object: Function LimNative.LimNative.AddToBlockee
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1015064f4
	// Return & Params: [ Num(2) Size(0x20) ]
	void AddToBlockee(struct FLimNativeLowLevelWrapper& InCtx, struct FString InUserId);

	// Object: Function LimNative.LimNative.AddGroupMember
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10150a6cc
	// Return & Params: [ Num(3) Size(0x30) ]
	void AddGroupMember(struct FLimNativeLowLevelWrapper& InCtx, struct FString groupid, struct FString memberid);

	// Object: Function LimNative.LimNative.AcceptFriendRequest
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101506b50
	// Return & Params: [ Num(3) Size(0x30) ]
	void AcceptFriendRequest(struct FLimNativeLowLevelWrapper& InCtx, struct FString InRequestID, struct FString InExtra);
};

// Object: Class LimNative.LimNativeChatMsgReader
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct ULimNativeChatMsgReader : UObject {
	// Functions

	// Object: Function LimNative.LimNativeChatMsgReader.GetVoiceMessage
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10151569c
	// Return & Params: [ Num(3) Size(0x150) ]
	struct FLimNativeIMVoiceMessage GetVoiceMessage(struct FLimNativeIMChatMessage& MsgStructWrapper, struct FLimNativeIMChatMessageInfo& MsgInfo);

	// Object: Function LimNative.LimNativeChatMsgReader.GetTextMessage
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101516094
	// Return & Params: [ Num(3) Size(0x128) ]
	struct FLimNativeIMTextMessage GetTextMessage(struct FLimNativeIMChatMessage& MsgStructWrapper, struct FLimNativeIMChatMessageInfo& MsgInfo);

	// Object: Function LimNative.LimNativeChatMsgReader.GetShareMessage
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101515360
	// Return & Params: [ Num(3) Size(0x180) ]
	struct FLimNativeIMShareMessage GetShareMessage(struct FLimNativeIMChatMessage& MsgStructWrapper, struct FLimNativeIMChatMessageInfo& MsgInfo);

	// Object: Function LimNative.LimNativeChatMsgReader.GetNotificationMessage
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101515014
	// Return & Params: [ Num(3) Size(0x128) ]
	struct FLimNativeIMNotificationMessage GetNotificationMessage(struct FLimNativeIMChatMessage& MsgStructWrapper, struct FLimNativeIMChatMessageInfo& MsgInfo);

	// Object: Function LimNative.LimNativeChatMsgReader.GetImageMessage
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101515a58
	// Return & Params: [ Num(3) Size(0x160) ]
	struct FLimNativeIMImageMessage GetImageMessage(struct FLimNativeIMChatMessage& MsgStructWrapper, struct FLimNativeIMChatMessageInfo& MsgInfo);

	// Object: Function LimNative.LimNativeChatMsgReader.GetEmotionMessage
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101515d64
	// Return & Params: [ Num(3) Size(0x170) ]
	struct FLimNativeIMEmotionMessage GetEmotionMessage(struct FLimNativeIMChatMessage& MsgStructWrapper, struct FLimNativeIMChatMessageInfo& MsgInfo);
};

// Object: Class LimNative.LimNativeHelper
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct ULimNativeHelper : UObject {
	// Functions

	// Object: Function LimNative.LimNativeHelper.NameStringToEnumValue
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10152bbbc
	// Return & Params: [ Num(3) Size(0x24) ]
	int32_t NameStringToEnumValue(struct FString Enum, struct FString EnumName);

	// Object: Function LimNative.LimNativeHelper.GetUE4LogFilePath
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10152c040
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetUE4LogFilePath();

	// Object: Function LimNative.LimNativeHelper.GetSavedPath
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10152c0c0
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetSavedPath();

	// Object: Function LimNative.LimNativeHelper.GetProjectPath
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10152bfc0
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetProjectPath();

	// Object: Function LimNative.LimNativeHelper.GetProjectContentPath
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10152bf40
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetProjectContentPath();

	// Object: Function LimNative.LimNativeHelper.GetGamePersistentDownloadDir
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10152bec0
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetGamePersistentDownloadDir();

	// Object: Function LimNative.LimNativeHelper.GetFileText
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10152b7e8
	// Return & Params: [ Num(2) Size(0x20) ]
	struct FString GetFileText(struct FString Path);

	// Object: Function LimNative.LimNativeHelper.GetFileBinary
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10152b724
	// Return & Params: [ Num(2) Size(0x20) ]
	struct TArray<char> GetFileBinary(struct FString Path);

	// Object: Function LimNative.LimNativeHelper.EnumToStringArray
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10152ba34
	// Return & Params: [ Num(3) Size(0x28) ]
	struct TArray<struct FString> EnumToStringArray(struct FString Enum, bool bExcludeHidden);

	// Object: Function LimNative.LimNativeHelper.EnumToString
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10152bdb0
	// Return & Params: [ Num(3) Size(0x28) ]
	struct FString EnumToString(struct FString Enum, int32_t EnumValue);

	// Object: Function LimNative.LimNativeHelper.EnumToNameStringArray
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10152b8ac
	// Return & Params: [ Num(3) Size(0x28) ]
	struct TArray<struct FString> EnumToNameStringArray(struct FString Enum, bool bExcludeHidden);

	// Object: Function LimNative.LimNativeHelper.EnumToNameString
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10152bca0
	// Return & Params: [ Num(3) Size(0x28) ]
	struct FString EnumToNameString(struct FString Enum, int32_t EnumValue);
};

// Object: Class LimNative.LimNativeLowLevel
// Inherited Bytes: 0x28 | Struct Size: 0x418
struct ULimNativeLowLevel : UObject {
	// Fields
	struct FMulticastInlineDelegate OnEvent; // Offset: 0x28 | Size: 0x10
	struct FMulticastInlineDelegate OnLog; // Offset: 0x38 | Size: 0x10
	struct FMulticastInlineDelegate OnCall; // Offset: 0x48 | Size: 0x10
	struct FMulticastInlineDelegate OnSetConfig; // Offset: 0x58 | Size: 0x10
	struct FMulticastInlineDelegate OnSetAllConfigs; // Offset: 0x68 | Size: 0x10
	struct FMulticastInlineDelegate OnGetConfig; // Offset: 0x78 | Size: 0x10
	struct FMulticastInlineDelegate OnGetAllConfigs; // Offset: 0x88 | Size: 0x10
	struct FMulticastInlineDelegate OnLogin; // Offset: 0x98 | Size: 0x10
	struct FMulticastInlineDelegate OnLoginV2; // Offset: 0xa8 | Size: 0x10
	struct FMulticastInlineDelegate OnLogout; // Offset: 0xb8 | Size: 0x10
	struct FMulticastInlineDelegate OnSendMsg; // Offset: 0xc8 | Size: 0x10
	struct FMulticastInlineDelegate OnRevokeMsg; // Offset: 0xd8 | Size: 0x10
	struct FMulticastInlineDelegate OnGetMsgs; // Offset: 0xe8 | Size: 0x10
	struct FMulticastInlineDelegate OnGetMsgsV2; // Offset: 0xf8 | Size: 0x10
	struct FMulticastInlineDelegate OnSetMsgRead; // Offset: 0x108 | Size: 0x10
	struct FMulticastInlineDelegate OnSetMsgState; // Offset: 0x118 | Size: 0x10
	struct FMulticastInlineDelegate OnCreateConv; // Offset: 0x128 | Size: 0x10
	struct FMulticastInlineDelegate OnDestroyConv; // Offset: 0x138 | Size: 0x10
	struct FMulticastInlineDelegate OnClearConv; // Offset: 0x148 | Size: 0x10
	struct FMulticastInlineDelegate OnGetConvs; // Offset: 0x158 | Size: 0x10
	struct FMulticastInlineDelegate OnGetConv; // Offset: 0x168 | Size: 0x10
	struct FMulticastInlineDelegate OnSetConvRead; // Offset: 0x178 | Size: 0x10
	struct FMulticastInlineDelegate OnSetConvSticky; // Offset: 0x188 | Size: 0x10
	struct FMulticastInlineDelegate OnSetConvMute; // Offset: 0x198 | Size: 0x10
	struct FMulticastInlineDelegate OnGetConvAttr; // Offset: 0x1a8 | Size: 0x10
	struct FMulticastInlineDelegate OnGetConvAllAttrs; // Offset: 0x1b8 | Size: 0x10
	struct FMulticastInlineDelegate OnSetConvAttr; // Offset: 0x1c8 | Size: 0x10
	struct FMulticastInlineDelegate OnCreateGroup; // Offset: 0x1d8 | Size: 0x10
	struct FMulticastInlineDelegate OnJoinGroup; // Offset: 0x1e8 | Size: 0x10
	struct FMulticastInlineDelegate OnQuitGroup; // Offset: 0x1f8 | Size: 0x10
	struct FMulticastInlineDelegate OnDestroyGroup; // Offset: 0x208 | Size: 0x10
	struct FMulticastInlineDelegate OnGetGroup; // Offset: 0x218 | Size: 0x10
	struct FMulticastInlineDelegate OnSetGroup; // Offset: 0x228 | Size: 0x10
	struct FMulticastInlineDelegate OnGetGroups; // Offset: 0x238 | Size: 0x10
	struct FMulticastInlineDelegate OnGetGroupAttr; // Offset: 0x248 | Size: 0x10
	struct FMulticastInlineDelegate OnGetGroupAllAttrs; // Offset: 0x258 | Size: 0x10
	struct FMulticastInlineDelegate OnSetGroupAttr; // Offset: 0x268 | Size: 0x10
	struct FMulticastInlineDelegate OnGetGroupMembers; // Offset: 0x278 | Size: 0x10
	struct FMulticastInlineDelegate OnGetGroupMember; // Offset: 0x288 | Size: 0x10
	struct FMulticastInlineDelegate OnAddGroupMember; // Offset: 0x298 | Size: 0x10
	struct FMulticastInlineDelegate OnRemoveGroupMember; // Offset: 0x2a8 | Size: 0x10
	struct FMulticastInlineDelegate OnGetFriends; // Offset: 0x2b8 | Size: 0x10
	struct FMulticastInlineDelegate OnRemoveFriend; // Offset: 0x2c8 | Size: 0x10
	struct FMulticastInlineDelegate OnGetFriendRequests; // Offset: 0x2d8 | Size: 0x10
	struct FMulticastInlineDelegate OnCreateFriendRequest; // Offset: 0x2e8 | Size: 0x10
	struct FMulticastInlineDelegate OnAcceptFriendRequest; // Offset: 0x2f8 | Size: 0x10
	struct FMulticastInlineDelegate OnRefuseFriendRequest; // Offset: 0x308 | Size: 0x10
	struct FMulticastInlineDelegate OnCancelFriendRequest; // Offset: 0x318 | Size: 0x10
	struct FMulticastInlineDelegate OnGetBlockees; // Offset: 0x328 | Size: 0x10
	struct FMulticastInlineDelegate OnAddToBlockee; // Offset: 0x338 | Size: 0x10
	struct FMulticastInlineDelegate OnRemoveFromBlockee; // Offset: 0x348 | Size: 0x10
	struct FMulticastInlineDelegate OnBlockeeExists; // Offset: 0x358 | Size: 0x10
	struct FMulticastInlineDelegate OnGetUser; // Offset: 0x368 | Size: 0x10
	struct FMulticastInlineDelegate OnGetUsers; // Offset: 0x378 | Size: 0x10
	struct FMulticastInlineDelegate OnGetUsersState; // Offset: 0x388 | Size: 0x10
	struct FMulticastInlineDelegate OnGetOssToken; // Offset: 0x398 | Size: 0x10
	struct FMulticastInlineDelegate OnGetGMEToken; // Offset: 0x3a8 | Size: 0x10
	struct FMulticastInlineDelegate OnReportMsg; // Offset: 0x3b8 | Size: 0x10
	struct FMulticastInlineDelegate OnTranslateText; // Offset: 0x3c8 | Size: 0x10
	struct FMulticastInlineDelegate OnCheckImage; // Offset: 0x3d8 | Size: 0x10
	struct FMulticastInlineDelegate OnGetMiscConfigInfo; // Offset: 0x3e8 | Size: 0x10
	struct FMulticastInlineDelegate OnGetConvChatLevelConfig; // Offset: 0x3f8 | Size: 0x10
	struct FMulticastInlineDelegate OnGetConnState; // Offset: 0x408 | Size: 0x10

	// Functions

	// Object: Function LimNative.LimNativeLowLevel.TranslateText
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10152cc90
	// Return & Params: [ Num(4) Size(0x38) ]
	void TranslateText(struct FLimNativeLowLevelWrapper& InCtx, struct FString InText, enum class ELimNativeSupportedLanguage InLang, struct FString ExtraInfo);

	// Object: Function LimNative.LimNativeLowLevel.SetMsgState
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101530ffc
	// Return & Params: [ Num(2) Size(0x20) ]
	void SetMsgState(struct FLimNativeLowLevelWrapper& InCtx, struct FString InMsgParams);

	// Object: Function LimNative.LimNativeLowLevel.SetMsgRead
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101531128
	// Return & Params: [ Num(5) Size(0x48) ]
	void SetMsgRead(struct FLimNativeLowLevelWrapper& InCtx, struct FString InConvID, enum class ELimNativeConvType InConvType, struct FString InMsgID, struct FString InExtra);

	// Object: Function LimNative.LimNativeLowLevel.SetLogHandler
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10153241c
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetLogHandler(struct FLimNativeLowLevelWrapper& InCtx);

	// Object: Function LimNative.LimNativeLowLevel.SetGroupAttr
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10152ed5c
	// Return & Params: [ Num(4) Size(0x40) ]
	void SetGroupAttr(struct FLimNativeLowLevelWrapper& InCtx, struct FString InGroupID, struct FString InKey, struct FString InValue);

	// Object: Function LimNative.LimNativeLowLevel.SetGroup
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10152f3a8
	// Return & Params: [ Num(4) Size(0x40) ]
	void SetGroup(struct FLimNativeLowLevelWrapper& InCtx, struct FString InGroupID, struct FString InGroupName, struct FString InExtra);

	// Object: Function LimNative.LimNativeLowLevel.SetEventHandler
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1015324f8
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetEventHandler(struct FLimNativeLowLevelWrapper& InCtx);

	// Object: Function LimNative.LimNativeLowLevel.SetConvSticky
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101530458
	// Return & Params: [ Num(4) Size(0x22) ]
	void SetConvSticky(struct FLimNativeLowLevelWrapper& InCtx, struct FString InConvID, enum class ELimNativeConvType InConvType, bool bSticky);

	// Object: Function LimNative.LimNativeLowLevel.SetConvRead
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101530624
	// Return & Params: [ Num(5) Size(0x48) ]
	void SetConvRead(struct FLimNativeLowLevelWrapper& InCtx, struct FString InConvID, enum class ELimNativeConvType InConvType, struct FString InMsgID, struct FString InExtra);

	// Object: Function LimNative.LimNativeLowLevel.SetConvMute
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10153028c
	// Return & Params: [ Num(4) Size(0x22) ]
	void SetConvMute(struct FLimNativeLowLevelWrapper& InCtx, struct FString InConvID, enum class ELimNativeConvType InConvType, bool bMute);

	// Object: Function LimNative.LimNativeLowLevel.SetConvAttr
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10152fd1c
	// Return & Params: [ Num(5) Size(0x48) ]
	void SetConvAttr(struct FLimNativeLowLevelWrapper& InCtx, struct FString InConvID, enum class ELimNativeConvType InConvType, struct FString InKey, struct FString InValue);

	// Object: Function LimNative.LimNativeLowLevel.SetAllConfigs
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1015321c4
	// Return & Params: [ Num(2) Size(0x20) ]
	void SetAllConfigs(struct FLimNativeLowLevelWrapper& InCtx, struct FString InJsonString);

	// Object: Function LimNative.LimNativeLowLevel.SendMsg
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101531918
	// Return & Params: [ Num(2) Size(0x20) ]
	void SendMsg(struct FLimNativeLowLevelWrapper& InCtx, struct FString InMsg);

	// Object: Function LimNative.LimNativeLowLevel.RevokeMsg
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1015317ec
	// Return & Params: [ Num(2) Size(0x20) ]
	void RevokeMsg(struct FLimNativeLowLevelWrapper& InCtx, struct FString InMsg);

	// Object: Function LimNative.LimNativeLowLevel.Resume
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101531a44
	// Return & Params: [ Num(1) Size(0x10) ]
	void Resume(struct FLimNativeLowLevelWrapper& InCtx);

	// Object: Function LimNative.LimNativeLowLevel.ReportMsg
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10152ce60
	// Return & Params: [ Num(2) Size(0x20) ]
	void ReportMsg(struct FLimNativeLowLevelWrapper& InCtx, struct FString InMsg);

	// Object: Function LimNative.LimNativeLowLevel.RemoveGroupMember
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10152e6b8
	// Return & Params: [ Num(3) Size(0x30) ]
	void RemoveGroupMember(struct FLimNativeLowLevelWrapper& InCtx, struct FString InGroupID, struct FString InMemberID);

	// Object: Function LimNative.LimNativeLowLevel.RemoveFromBlockee
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10152d734
	// Return & Params: [ Num(2) Size(0x20) ]
	void RemoveFromBlockee(struct FLimNativeLowLevelWrapper& InCtx, struct FString InUserId);

	// Object: Function LimNative.LimNativeLowLevel.RemoveFriend
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10152e374
	// Return & Params: [ Num(3) Size(0x30) ]
	void RemoveFriend(struct FLimNativeLowLevelWrapper& InCtx, struct FString InUserId, struct FString InExtra);

	// Object: Function LimNative.LimNativeLowLevel.RefuseFriendRequest
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10152dd28
	// Return & Params: [ Num(3) Size(0x30) ]
	void RefuseFriendRequest(struct FLimNativeLowLevelWrapper& InCtx, struct FString InRequestID, struct FString InExtra);

	// Object: Function LimNative.LimNativeLowLevel.QuitGroup
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10152f7dc
	// Return & Params: [ Num(2) Size(0x20) ]
	void QuitGroup(struct FLimNativeLowLevelWrapper& InCtx, struct FString InGroupID);

	// Object: Function LimNative.LimNativeLowLevel.Pause
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101531b20
	// Return & Params: [ Num(1) Size(0x10) ]
	void Pause(struct FLimNativeLowLevelWrapper& InCtx);

	// Object: Function LimNative.LimNativeLowLevel.Logout
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101531bfc
	// Return & Params: [ Num(1) Size(0x10) ]
	void Logout(struct FLimNativeLowLevelWrapper& InCtx);

	// Object: Function LimNative.LimNativeLowLevel.LoginV2
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101531cd8
	// Return & Params: [ Num(3) Size(0x30) ]
	void LoginV2(struct FLimNativeLowLevelWrapper& InCtx, struct FString InEnv, struct FString InRoleID);

	// Object: Function LimNative.LimNativeLowLevel.Login
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101531e5c
	// Return & Params: [ Num(6) Size(0x60) ]
	void Login(struct FLimNativeLowLevelWrapper& InCtx, struct FString InAppId, struct FString InAppUserID, struct FString InToken, struct FString InRoleID, struct FString InExtra);

	// Object: DelegateFunction LimNative.LimNativeLowLevel.LIMResultDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103a48564
	// Return & Params: [ Num(2) Size(0x20) ]
	void LIMResultDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FString InData);

	// Object: DelegateFunction LimNative.LimNativeLowLevel.LIMLogDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103a48564
	// Return & Params: [ Num(2) Size(0x20) ]
	void LIMLogDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FString InData);

	// Object: DelegateFunction LimNative.LimNativeLowLevel.LIMEventDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103a48564
	// Return & Params: [ Num(2) Size(0x20) ]
	void LIMEventDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FString InData);

	// Object: Function LimNative.LimNativeLowLevel.JoinGroup
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10152f908
	// Return & Params: [ Num(2) Size(0x20) ]
	void JoinGroup(struct FLimNativeLowLevelWrapper& InCtx, struct FString InGroupID);

	// Object: Function LimNative.LimNativeLowLevel.GetUsersState
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10152d244
	// Return & Params: [ Num(2) Size(0x20) ]
	void GetUsersState(struct FLimNativeLowLevelWrapper& InCtx, struct TArray<struct FString>& InUserIDs);

	// Object: Function LimNative.LimNativeLowLevel.GetUsers
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10152d3b0
	// Return & Params: [ Num(2) Size(0x20) ]
	void GetUsers(struct FLimNativeLowLevelWrapper& InCtx, struct FString InUserIDs);

	// Object: Function LimNative.LimNativeLowLevel.GetUser
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10152d4dc
	// Return & Params: [ Num(2) Size(0x20) ]
	void GetUser(struct FLimNativeLowLevelWrapper& InCtx, struct FString InUserId);

	// Object: Function LimNative.LimNativeLowLevel.GetOssToken
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10152d168
	// Return & Params: [ Num(1) Size(0x10) ]
	void GetOssToken(struct FLimNativeLowLevelWrapper& InCtx);

	// Object: Function LimNative.LimNativeLowLevel.GetMsgsV2
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101531350
	// Return & Params: [ Num(5) Size(0x48) ]
	void GetMsgsV2(struct FLimNativeLowLevelWrapper& InCtx, struct FString InConvID, enum class ELimNativeConvType InConvType, struct FString InFromMsgID, struct FString InToMsgID);

	// Object: Function LimNative.LimNativeLowLevel.GetMsgs
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101531578
	// Return & Params: [ Num(6) Size(0x48) ]
	void GetMsgs(struct FLimNativeLowLevelWrapper& InCtx, struct FString InConvID, enum class ELimNativeConvType InConvType, enum class ELimNativeMsgDirType InDir, struct FString InMsgID, struct FString InExtra);

	// Object: Function LimNative.LimNativeLowLevel.GetMiscConfigInfo
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10152ca88
	// Return & Params: [ Num(1) Size(0x10) ]
	void GetMiscConfigInfo(struct FLimNativeLowLevelWrapper& InCtx);

	// Object: Function LimNative.LimNativeLowLevel.GetLIMVersion
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1015325d4
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetLIMVersion();

	// Object: Function LimNative.LimNativeLowLevel.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1015327cc
	// Return & Params: [ Num(1) Size(0x8) ]
	struct ULimNativeLowLevel* GetInstance();

	// Object: Function LimNative.LimNativeLowLevel.GetGroups
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10152f1e8
	// Return & Params: [ Num(4) Size(0x28) ]
	void GetGroups(struct FLimNativeLowLevelWrapper& InCtx, int32_t InTag, int32_t InSize, struct FString InExtra);

	// Object: Function LimNative.LimNativeLowLevel.GetGroupMembers
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10152eb44
	// Return & Params: [ Num(5) Size(0x38) ]
	void GetGroupMembers(struct FLimNativeLowLevelWrapper& InCtx, struct FString InGroupID, int32_t InTag, int32_t InSize, struct FString InExtra);

	// Object: Function LimNative.LimNativeLowLevel.GetGroupMember
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10152e9c0
	// Return & Params: [ Num(3) Size(0x30) ]
	void GetGroupMember(struct FLimNativeLowLevelWrapper& InCtx, struct FString InGroupID, struct FString InMemberID);

	// Object: Function LimNative.LimNativeLowLevel.GetGroupAttr
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10152f064
	// Return & Params: [ Num(3) Size(0x30) ]
	void GetGroupAttr(struct FLimNativeLowLevelWrapper& InCtx, struct FString InGroupID, struct FString InKey);

	// Object: Function LimNative.LimNativeLowLevel.GetGroupAllAttrs
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10152ef38
	// Return & Params: [ Num(2) Size(0x20) ]
	void GetGroupAllAttrs(struct FLimNativeLowLevelWrapper& InCtx, struct FString InGroupID);

	// Object: Function LimNative.LimNativeLowLevel.GetGroup
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10152f584
	// Return & Params: [ Num(2) Size(0x20) ]
	void GetGroup(struct FLimNativeLowLevelWrapper& InCtx, struct FString InGroupID);

	// Object: Function LimNative.LimNativeLowLevel.GetGMEToken
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10152cf8c
	// Return & Params: [ Num(4) Size(0x40) ]
	void GetGMEToken(struct FLimNativeLowLevelWrapper& InCtx, struct FString InAppId, struct FString InUserId, struct FString InRoomId);

	// Object: Function LimNative.LimNativeLowLevel.GetFriends
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10152e4f8
	// Return & Params: [ Num(4) Size(0x28) ]
	void GetFriends(struct FLimNativeLowLevelWrapper& InCtx, int32_t InTag, int32_t InSize, struct FString InExtra);

	// Object: Function LimNative.LimNativeLowLevel.GetFriendRequests
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10152e1b4
	// Return & Params: [ Num(4) Size(0x28) ]
	void GetFriendRequests(struct FLimNativeLowLevelWrapper& InCtx, int32_t InTag, int32_t InSize, struct FString InExtra);

	// Object: Function LimNative.LimNativeLowLevel.GetConvs
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1015309c4
	// Return & Params: [ Num(3) Size(0x28) ]
	void GetConvs(struct FLimNativeLowLevelWrapper& InCtx, int32_t InSize, struct FString InExtra);

	// Object: Function LimNative.LimNativeLowLevel.GetConvChatLevelConfig
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10152c8d0
	// Return & Params: [ Num(1) Size(0x10) ]
	void GetConvChatLevelConfig(struct FLimNativeLowLevelWrapper& InCtx);

	// Object: Function LimNative.LimNativeLowLevel.GetConvAttr
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1015300bc
	// Return & Params: [ Num(4) Size(0x38) ]
	void GetConvAttr(struct FLimNativeLowLevelWrapper& InCtx, struct FString InConvID, enum class ELimNativeConvType InConvType, struct FString InKey);

	// Object: Function LimNative.LimNativeLowLevel.GetConvAllAttrs
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10152ff44
	// Return & Params: [ Num(3) Size(0x21) ]
	void GetConvAllAttrs(struct FLimNativeLowLevelWrapper& InCtx, struct FString InConvID, enum class ELimNativeConvType InConvType);

	// Object: Function LimNative.LimNativeLowLevel.GetConv
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10153084c
	// Return & Params: [ Num(3) Size(0x21) ]
	void GetConv(struct FLimNativeLowLevelWrapper& InCtx, struct FString InConvID, enum class ELimNativeConvType InConvType);

	// Object: Function LimNative.LimNativeLowLevel.GetConnState
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10152c9ac
	// Return & Params: [ Num(1) Size(0x10) ]
	void GetConnState(struct FLimNativeLowLevelWrapper& InCtx);

	// Object: Function LimNative.LimNativeLowLevel.GetBlockees
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10152d98c
	// Return & Params: [ Num(4) Size(0x28) ]
	void GetBlockees(struct FLimNativeLowLevelWrapper& InCtx, int32_t InTag, int32_t InSize, struct FString InExtra);

	// Object: Function LimNative.LimNativeLowLevel.GetAllConfigs
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1015320e8
	// Return & Params: [ Num(1) Size(0x10) ]
	void GetAllConfigs(struct FLimNativeLowLevelWrapper& InCtx);

	// Object: Function LimNative.LimNativeLowLevel.DestroyGroup
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10152f6b0
	// Return & Params: [ Num(2) Size(0x20) ]
	void DestroyGroup(struct FLimNativeLowLevelWrapper& InCtx, struct FString InGroupID);

	// Object: Function LimNative.LimNativeLowLevel.DestroyConv
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101530cb4
	// Return & Params: [ Num(3) Size(0x21) ]
	void DestroyConv(struct FLimNativeLowLevelWrapper& InCtx, struct FString InConvID, enum class ELimNativeConvType InConvType);

	// Object: Function LimNative.LimNativeLowLevel.DestoryInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1015327b8
	// Return & Params: [ Num(0) Size(0x0) ]
	void DestoryInstance();

	// Object: Function LimNative.LimNativeLowLevel.CreateLIM
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101532654
	// Return & Params: [ Num(2) Size(0x20) ]
	struct FLimNativeLowLevelWrapper CreateLIM(struct FString InServerEnvID);

	// Object: Function LimNative.LimNativeLowLevel.CreateGroup
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10152fa34
	// Return & Params: [ Num(4) Size(0x40) ]
	void CreateGroup(struct FLimNativeLowLevelWrapper& InCtx, struct TArray<struct FString> InMembers, struct FString InGroupName, struct FString InExtra);

	// Object: Function LimNative.LimNativeLowLevel.CreateFriendRequest
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10152e030
	// Return & Params: [ Num(3) Size(0x30) ]
	void CreateFriendRequest(struct FLimNativeLowLevelWrapper& InCtx, struct FString InUserId, struct FString InExtra);

	// Object: Function LimNative.LimNativeLowLevel.CreateConv
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101530e2c
	// Return & Params: [ Num(4) Size(0x38) ]
	void CreateConv(struct FLimNativeLowLevelWrapper& InCtx, struct FString InConvID, enum class ELimNativeConvType InConvType, struct FString InExtra);

	// Object: Function LimNative.LimNativeLowLevel.ClearConv
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101530b3c
	// Return & Params: [ Num(3) Size(0x21) ]
	void ClearConv(struct FLimNativeLowLevelWrapper& InCtx, struct FString InConvID, enum class ELimNativeConvType InConvType);

	// Object: Function LimNative.LimNativeLowLevel.CheckImage
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10152cb64
	// Return & Params: [ Num(2) Size(0x20) ]
	void CheckImage(struct FLimNativeLowLevelWrapper& InCtx, struct FString InUrl);

	// Object: Function LimNative.LimNativeLowLevel.CancelFriendRequest
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10152db4c
	// Return & Params: [ Num(4) Size(0x40) ]
	void CancelFriendRequest(struct FLimNativeLowLevelWrapper& InCtx, struct FString InUserId, struct FString InRequestID, struct FString InExtra);

	// Object: Function LimNative.LimNativeLowLevel.Call
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1015322f0
	// Return & Params: [ Num(2) Size(0x20) ]
	void Call(struct FLimNativeLowLevelWrapper& InCtx, struct FString InJsonString);

	// Object: Function LimNative.LimNativeLowLevel.BlockeeExists
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10152d608
	// Return & Params: [ Num(2) Size(0x20) ]
	void BlockeeExists(struct FLimNativeLowLevelWrapper& InCtx, struct FString InUserId);

	// Object: Function LimNative.LimNativeLowLevel.AddToBlockee
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10152d860
	// Return & Params: [ Num(2) Size(0x20) ]
	void AddToBlockee(struct FLimNativeLowLevelWrapper& InCtx, struct FString InUserId);

	// Object: Function LimNative.LimNativeLowLevel.AddGroupMember
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10152e83c
	// Return & Params: [ Num(3) Size(0x30) ]
	void AddGroupMember(struct FLimNativeLowLevelWrapper& InCtx, struct FString InGroupID, struct FString InMemberID);

	// Object: Function LimNative.LimNativeLowLevel.AcceptFriendRequest
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10152deac
	// Return & Params: [ Num(3) Size(0x30) ]
	void AcceptFriendRequest(struct FLimNativeLowLevelWrapper& InCtx, struct FString InRequestID, struct FString InExtra);
};

