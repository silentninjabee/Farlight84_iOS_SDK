#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class MediaCompositing.MovieSceneMediaPlayerPropertySection
// Inherited Bytes: 0xd8 | Struct Size: 0xe8
struct UMovieSceneMediaPlayerPropertySection : UMovieSceneSection {
	// Fields
	struct UMediaSource* MediaSource; // Offset: 0xd8 | Size: 0x8
	bool bLoop; // Offset: 0xe0 | Size: 0x1
	char pad_0xE1[0x7]; // Offset: 0xe1 | Size: 0x7
};

// Object: Class MediaCompositing.MovieSceneMediaPlayerPropertyTrack
// Inherited Bytes: 0x88 | Struct Size: 0x88
struct UMovieSceneMediaPlayerPropertyTrack : UMovieScenePropertyTrack {
};

// Object: Class MediaCompositing.MovieSceneMediaSection
// Inherited Bytes: 0xd8 | Struct Size: 0x108
struct UMovieSceneMediaSection : UMovieSceneSection {
	// Fields
	struct UMediaSource* MediaSource; // Offset: 0xd8 | Size: 0x8
	bool bLooping; // Offset: 0xe0 | Size: 0x1
	char pad_0xE1[0x3]; // Offset: 0xe1 | Size: 0x3
	struct FFrameNumber StartFrameOffset; // Offset: 0xe4 | Size: 0x4
	struct UMediaTexture* MediaTexture; // Offset: 0xe8 | Size: 0x8
	struct UMediaSoundComponent* MediaSoundComponent; // Offset: 0xf0 | Size: 0x8
	bool bUseExternalMediaPlayer; // Offset: 0xf8 | Size: 0x1
	char pad_0xF9[0x7]; // Offset: 0xf9 | Size: 0x7
	struct UMediaPlayer* ExternalMediaPlayer; // Offset: 0x100 | Size: 0x8
};

// Object: Class MediaCompositing.MovieSceneMediaTrack
// Inherited Bytes: 0x58 | Struct Size: 0x68
struct UMovieSceneMediaTrack : UMovieSceneNameableTrack {
	// Fields
	struct TArray<struct UMovieSceneSection*> MediaSections; // Offset: 0x58 | Size: 0x10
};

