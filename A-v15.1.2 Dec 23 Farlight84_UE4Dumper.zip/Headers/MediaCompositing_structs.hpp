#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct MediaCompositing.MovieSceneMediaPlayerPropertySectionTemplate
// Inherited Bytes: 0x40 | Struct Size: 0x50
struct FMovieSceneMediaPlayerPropertySectionTemplate : FMovieScenePropertySectionTemplate {
	// Fields
	struct UMediaSource* MediaSource; // Offset: 0x40 | Size: 0x8
	struct FFrameNumber SectionStartFrame; // Offset: 0x48 | Size: 0x4
	bool bLoop; // Offset: 0x4c | Size: 0x1
	char pad_0x4D[0x3]; // Offset: 0x4d | Size: 0x3
};

// Object: ScriptStruct MediaCompositing.MovieSceneMediaSectionTemplate
// Inherited Bytes: 0x18 | Struct Size: 0x48
struct FMovieSceneMediaSectionTemplate : FMovieSceneEvalTemplate {
	// Fields
	struct FMovieSceneMediaSectionParams Params; // Offset: 0x18 | Size: 0x30
};

// Object: ScriptStruct MediaCompositing.MovieSceneMediaSectionParams
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FMovieSceneMediaSectionParams {
	// Fields
	struct UMediaSoundComponent* MediaSoundComponent; // Offset: 0x0 | Size: 0x8
	struct UMediaSource* MediaSource; // Offset: 0x8 | Size: 0x8
	struct UMediaTexture* MediaTexture; // Offset: 0x10 | Size: 0x8
	struct UMediaPlayer* MediaPlayer; // Offset: 0x18 | Size: 0x8
	struct FFrameNumber SectionStartFrame; // Offset: 0x20 | Size: 0x4
	struct FFrameNumber SectionEndFrame; // Offset: 0x24 | Size: 0x4
	bool bLooping; // Offset: 0x28 | Size: 0x1
	char pad_0x29[0x3]; // Offset: 0x29 | Size: 0x3
	struct FFrameNumber StartFrameOffset; // Offset: 0x2c | Size: 0x4
};

