#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class MeshWidget.MeshWidgetUWidget
// Inherited Bytes: 0x138 | Struct Size: 0x148
struct UMeshWidgetUWidget : UWidget {
	// Fields
	char pad_0x138[0x10]; // Offset: 0x138 | Size: 0x10
};

// Object: Class MeshWidget.ParticleWidget
// Inherited Bytes: 0x148 | Struct Size: 0x188
struct UParticleWidget : UMeshWidgetUWidget {
	// Fields
	struct USlateVectorArtData* TrailMeshAsset; // Offset: 0x148 | Size: 0x8
	int32_t MaxParticleCount; // Offset: 0x150 | Size: 0x4
	char pad_0x154[0x34]; // Offset: 0x154 | Size: 0x34
};

// Object: Class MeshWidget.MeshRectangleWidget
// Inherited Bytes: 0x148 | Struct Size: 0x170
struct UMeshRectangleWidget : UMeshWidgetUWidget {
	// Fields
	struct UMaterialInterface* BaseMaterial; // Offset: 0x148 | Size: 0x8
	int32_t NumFloat4PerInstance; // Offset: 0x150 | Size: 0x4
	char pad_0x154[0x1c]; // Offset: 0x154 | Size: 0x1c

	// Functions

	// Object: Function MeshWidget.MeshRectangleWidget.SetInstanceNum
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10236fe68
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetInstanceNum(int32_t NewNum);

	// Object: Function MeshWidget.MeshRectangleWidget.ModifyInstanceNum
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10236fde8
	// Return & Params: [ Num(1) Size(0x4) ]
	void ModifyInstanceNum(int32_t dNum);

	// Object: Function MeshWidget.MeshRectangleWidget.InitUnitTestProvider
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10236fee8
	// Return & Params: [ Num(0) Size(0x0) ]
	void InitUnitTestProvider();
};

// Object: Class MeshWidget.TextMeshWidget
// Inherited Bytes: 0x148 | Struct Size: 0x178
struct UTextMeshWidget : UMeshWidgetUWidget {
	// Fields
	struct UMaterialInterface* BaseMaterial; // Offset: 0x148 | Size: 0x8
	char pad_0x150[0x28]; // Offset: 0x150 | Size: 0x28
};

// Object: Class MeshWidget.ProgressBarMeshWidget
// Inherited Bytes: 0x148 | Struct Size: 0x178
struct UProgressBarMeshWidget : UMeshWidgetUWidget {
	// Fields
	struct UMaterialInterface* BaseMaterial; // Offset: 0x148 | Size: 0x8
	char pad_0x150[0x28]; // Offset: 0x150 | Size: 0x28
};

