#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class MovieSceneTracks.MovieSceneSpawnTrack
// Inherited Bytes: 0x58 | Struct Size: 0x78
struct UMovieSceneSpawnTrack : UMovieSceneTrack {
	// Fields
	struct TArray<struct UMovieSceneSection*> Sections; // Offset: 0x58 | Size: 0x10
	struct FGuid ObjectGuid; // Offset: 0x68 | Size: 0x10
};

// Object: Class MovieSceneTracks.MovieSceneParameterSection
// Inherited Bytes: 0xd8 | Struct Size: 0x138
struct UMovieSceneParameterSection : UMovieSceneSection {
	// Fields
	struct TArray<struct FBoolParameterNameAndCurve> BoolParameterNamesAndCurves; // Offset: 0xd8 | Size: 0x10
	struct TArray<struct FScalarParameterNameAndCurve> ScalarParameterNamesAndCurves; // Offset: 0xe8 | Size: 0x10
	struct TArray<struct FVector2DParameterNameAndCurves> Vector2DParameterNamesAndCurves; // Offset: 0xf8 | Size: 0x10
	struct TArray<struct FVectorParameterNameAndCurves> VectorParameterNamesAndCurves; // Offset: 0x108 | Size: 0x10
	struct TArray<struct FColorParameterNameAndCurves> ColorParameterNamesAndCurves; // Offset: 0x118 | Size: 0x10
	struct TArray<struct FTransformParameterNameAndCurves> TransformParameterNamesAndCurves; // Offset: 0x128 | Size: 0x10
};

// Object: Class MovieSceneTracks.MovieScenePropertyTrack
// Inherited Bytes: 0x58 | Struct Size: 0x88
struct UMovieScenePropertyTrack : UMovieSceneNameableTrack {
	// Fields
	struct UMovieSceneSection* SectionToKey; // Offset: 0x58 | Size: 0x8
	struct FName PropertyName; // Offset: 0x60 | Size: 0x8
	struct FString PropertyPath; // Offset: 0x68 | Size: 0x10
	struct TArray<struct UMovieSceneSection*> Sections; // Offset: 0x78 | Size: 0x10
};

// Object: Class MovieSceneTracks.SceneComponentTransformStandIn
// Inherited Bytes: 0x28 | Struct Size: 0x60
struct USceneComponentTransformStandIn : UObject {
	// Fields
	char pad_0x28[0x38]; // Offset: 0x28 | Size: 0x38
};

// Object: Class MovieSceneTracks.MovieSceneTransformOrigin
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UMovieSceneTransformOrigin : UInterface {
	// Functions

	// Object: Function MovieSceneTracks.MovieSceneTransformOrigin.BP_GetTransformOrigin
	// Flags: [Event|Protected|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const]
	// Offset: 0x103a48564
	// Return & Params: [ Num(1) Size(0x30) ]
	struct FTransform BP_GetTransformOrigin();
};

// Object: Class MovieSceneTracks.MovieScene3DConstraintSection
// Inherited Bytes: 0xd8 | Struct Size: 0x100
struct UMovieScene3DConstraintSection : UMovieSceneSection {
	// Fields
	struct FGuid ConstraintId; // Offset: 0xd8 | Size: 0x10
	struct FMovieSceneObjectBindingID ConstraintBindingID; // Offset: 0xe8 | Size: 0x18

	// Functions

	// Object: Function MovieSceneTracks.MovieScene3DConstraintSection.SetConstraintBindingID
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x104917828
	// Return & Params: [ Num(1) Size(0x18) ]
	void SetConstraintBindingID(struct FMovieSceneObjectBindingID& InConstraintBindingID);

	// Object: Function MovieSceneTracks.MovieScene3DConstraintSection.GetConstraintBindingID
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1049178fc
	// Return & Params: [ Num(1) Size(0x18) ]
	struct FMovieSceneObjectBindingID GetConstraintBindingID();
};

// Object: Class MovieSceneTracks.MovieScene3DAttachSection
// Inherited Bytes: 0x100 | Struct Size: 0x118
struct UMovieScene3DAttachSection : UMovieScene3DConstraintSection {
	// Fields
	struct FName AttachSocketName; // Offset: 0x100 | Size: 0x8
	struct FName AttachComponentName; // Offset: 0x108 | Size: 0x8
	enum class EAttachmentRule AttachmentLocationRule; // Offset: 0x110 | Size: 0x1
	enum class EAttachmentRule AttachmentRotationRule; // Offset: 0x111 | Size: 0x1
	enum class EAttachmentRule AttachmentScaleRule; // Offset: 0x112 | Size: 0x1
	enum class EDetachmentRule DetachmentLocationRule; // Offset: 0x113 | Size: 0x1
	enum class EDetachmentRule DetachmentRotationRule; // Offset: 0x114 | Size: 0x1
	enum class EDetachmentRule DetachmentScaleRule; // Offset: 0x115 | Size: 0x1
	char pad_0x116[0x2]; // Offset: 0x116 | Size: 0x2
};

// Object: Class MovieSceneTracks.MovieScene3DConstraintTrack
// Inherited Bytes: 0x58 | Struct Size: 0x68
struct UMovieScene3DConstraintTrack : UMovieSceneTrack {
	// Fields
	struct TArray<struct UMovieSceneSection*> ConstraintSections; // Offset: 0x58 | Size: 0x10
};

// Object: Class MovieSceneTracks.MovieScene3DAttachTrack
// Inherited Bytes: 0x68 | Struct Size: 0x68
struct UMovieScene3DAttachTrack : UMovieScene3DConstraintTrack {
};

// Object: Class MovieSceneTracks.MovieScene3DPathSection
// Inherited Bytes: 0x100 | Struct Size: 0x1a8
struct UMovieScene3DPathSection : UMovieScene3DConstraintSection {
	// Fields
	struct FMovieSceneFloatChannel TimingCurve; // Offset: 0x100 | Size: 0xa0
	enum class MovieScene3DPathSection_Axis FrontAxisEnum; // Offset: 0x1a0 | Size: 0x1
	enum class MovieScene3DPathSection_Axis UpAxisEnum; // Offset: 0x1a1 | Size: 0x1
	char bFollow : 1; // Offset: 0x1a2 | Size: 0x1
	char bReverse : 1; // Offset: 0x1a2 | Size: 0x1
	char bForceUpright : 1; // Offset: 0x1a2 | Size: 0x1
	char pad_0x1A2_3 : 5; // Offset: 0x1a2 | Size: 0x1
	char pad_0x1A3[0x5]; // Offset: 0x1a3 | Size: 0x5
};

// Object: Class MovieSceneTracks.MovieScene3DPathTrack
// Inherited Bytes: 0x68 | Struct Size: 0x68
struct UMovieScene3DPathTrack : UMovieScene3DConstraintTrack {
};

// Object: Class MovieSceneTracks.MovieScene3DTransformSection
// Inherited Bytes: 0xd8 | Struct Size: 0x728
struct UMovieScene3DTransformSection : UMovieSceneSection {
	// Fields
	struct FMovieSceneTransformMask TransformMask; // Offset: 0xd8 | Size: 0x4
	char pad_0xDC[0x4]; // Offset: 0xdc | Size: 0x4
	struct FMovieSceneFloatChannel Translation[0x3]; // Offset: 0xe0 | Size: 0x1e0
	struct FMovieSceneFloatChannel Rotation[0x3]; // Offset: 0x2c0 | Size: 0x1e0
	struct FMovieSceneFloatChannel Scale[0x3]; // Offset: 0x4a0 | Size: 0x1e0
	struct FMovieSceneFloatChannel ManualWeight; // Offset: 0x680 | Size: 0xa0
	char pad_0x720[0x4]; // Offset: 0x720 | Size: 0x4
	bool bUseQuaternionInterpolation; // Offset: 0x724 | Size: 0x1
	char pad_0x725[0x3]; // Offset: 0x725 | Size: 0x3
};

// Object: Class MovieSceneTracks.MovieScene3DTransformTrack
// Inherited Bytes: 0x88 | Struct Size: 0x88
struct UMovieScene3DTransformTrack : UMovieScenePropertyTrack {
};

// Object: Class MovieSceneTracks.MovieSceneActorReferenceSection
// Inherited Bytes: 0xd8 | Struct Size: 0x218
struct UMovieSceneActorReferenceSection : UMovieSceneSection {
	// Fields
	struct FMovieSceneActorReferenceData ActorReferenceData; // Offset: 0xd8 | Size: 0xb0
	struct FIntegralCurve ActorGuidIndexCurve; // Offset: 0x188 | Size: 0x80
	struct TArray<struct FString> ActorGuidStrings; // Offset: 0x208 | Size: 0x10
};

// Object: Class MovieSceneTracks.MovieSceneActorReferenceTrack
// Inherited Bytes: 0x88 | Struct Size: 0x88
struct UMovieSceneActorReferenceTrack : UMovieScenePropertyTrack {
};

// Object: Class MovieSceneTracks.MovieSceneAudioSection
// Inherited Bytes: 0xd8 | Struct Size: 0x328
struct UMovieSceneAudioSection : UMovieSceneSection {
	// Fields
	struct USoundBase* Sound; // Offset: 0xd8 | Size: 0x8
	struct FFrameNumber StartFrameOffset; // Offset: 0xe0 | Size: 0x4
	float StartOffset; // Offset: 0xe4 | Size: 0x4
	float AudioStartTime; // Offset: 0xe8 | Size: 0x4
	float AudioDilationFactor; // Offset: 0xec | Size: 0x4
	float AudioVolume; // Offset: 0xf0 | Size: 0x4
	char pad_0xF4[0x4]; // Offset: 0xf4 | Size: 0x4
	struct FMovieSceneFloatChannel SoundVolume; // Offset: 0xf8 | Size: 0xa0
	struct FMovieSceneFloatChannel PitchMultiplier; // Offset: 0x198 | Size: 0xa0
	struct FMovieSceneActorReferenceData AttachActorData; // Offset: 0x238 | Size: 0xb0
	bool bSuppressSubtitles; // Offset: 0x2e8 | Size: 0x1
	bool bOverrideAttenuation; // Offset: 0x2e9 | Size: 0x1
	char pad_0x2EA[0x6]; // Offset: 0x2ea | Size: 0x6
	struct USoundAttenuation* AttenuationSettings; // Offset: 0x2f0 | Size: 0x8
	struct FDelegate OnQueueSubtitles; // Offset: 0x2f8 | Size: 0x10
	struct FMulticastInlineDelegate OnAudioFinished; // Offset: 0x308 | Size: 0x10
	struct FMulticastInlineDelegate OnAudioPlaybackPercent; // Offset: 0x318 | Size: 0x10

	// Functions

	// Object: Function MovieSceneTracks.MovieSceneAudioSection.SetStartOffset
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x104919020
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetStartOffset(struct FFrameNumber InStartOffset);

	// Object: Function MovieSceneTracks.MovieSceneAudioSection.SetSound
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1049190b8
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetSound(struct USoundBase* InSound);

	// Object: Function MovieSceneTracks.MovieSceneAudioSection.GetStartOffset
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104919004
	// Return & Params: [ Num(1) Size(0x4) ]
	struct FFrameNumber GetStartOffset();

	// Object: Function MovieSceneTracks.MovieSceneAudioSection.GetSound
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10491909c
	// Return & Params: [ Num(1) Size(0x8) ]
	struct USoundBase* GetSound();
};

// Object: Class MovieSceneTracks.MovieSceneAudioTrack
// Inherited Bytes: 0x58 | Struct Size: 0x68
struct UMovieSceneAudioTrack : UMovieSceneNameableTrack {
	// Fields
	struct TArray<struct UMovieSceneSection*> AudioSections; // Offset: 0x58 | Size: 0x10
};

// Object: Class MovieSceneTracks.MovieSceneBoolSection
// Inherited Bytes: 0xd8 | Struct Size: 0x170
struct UMovieSceneBoolSection : UMovieSceneSection {
	// Fields
	bool DefaultValue; // Offset: 0xd8 | Size: 0x1
	char pad_0xD9[0x7]; // Offset: 0xd9 | Size: 0x7
	struct FMovieSceneBoolChannel BoolCurve; // Offset: 0xe0 | Size: 0x90
};

// Object: Class MovieSceneTracks.MovieSceneBoolTrack
// Inherited Bytes: 0x88 | Struct Size: 0x88
struct UMovieSceneBoolTrack : UMovieScenePropertyTrack {
};

// Object: Class MovieSceneTracks.MovieSceneByteSection
// Inherited Bytes: 0xd8 | Struct Size: 0x170
struct UMovieSceneByteSection : UMovieSceneSection {
	// Fields
	struct FMovieSceneByteChannel ByteCurve; // Offset: 0xd8 | Size: 0x98
};

// Object: Class MovieSceneTracks.MovieSceneByteTrack
// Inherited Bytes: 0x88 | Struct Size: 0x90
struct UMovieSceneByteTrack : UMovieScenePropertyTrack {
	// Fields
	struct UEnum* Enum; // Offset: 0x88 | Size: 0x8
};

// Object: Class MovieSceneTracks.MovieSceneCameraAnimSection
// Inherited Bytes: 0xd8 | Struct Size: 0x118
struct UMovieSceneCameraAnimSection : UMovieSceneSection {
	// Fields
	struct FMovieSceneCameraAnimSectionData AnimData; // Offset: 0xd8 | Size: 0x20
	struct UCameraAnim* CameraAnim; // Offset: 0xf8 | Size: 0x8
	float PlayRate; // Offset: 0x100 | Size: 0x4
	float PlayScale; // Offset: 0x104 | Size: 0x4
	float BlendInTime; // Offset: 0x108 | Size: 0x4
	float BlendOutTime; // Offset: 0x10c | Size: 0x4
	bool bLooping; // Offset: 0x110 | Size: 0x1
	char pad_0x111[0x7]; // Offset: 0x111 | Size: 0x7
};

// Object: Class MovieSceneTracks.MovieSceneCameraAnimTrack
// Inherited Bytes: 0x58 | Struct Size: 0x68
struct UMovieSceneCameraAnimTrack : UMovieSceneNameableTrack {
	// Fields
	struct TArray<struct UMovieSceneSection*> CameraAnimSections; // Offset: 0x58 | Size: 0x10
};

// Object: Class MovieSceneTracks.MovieSceneCameraCutSection
// Inherited Bytes: 0xd8 | Struct Size: 0x100
struct UMovieSceneCameraCutSection : UMovieSceneSection {
	// Fields
	struct FGuid CameraGuid; // Offset: 0xd8 | Size: 0x10
	struct FMovieSceneObjectBindingID CameraBindingID; // Offset: 0xe8 | Size: 0x18

	// Functions

	// Object: Function MovieSceneTracks.MovieSceneCameraCutSection.SetCameraBindingID
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10491a544
	// Return & Params: [ Num(1) Size(0x18) ]
	void SetCameraBindingID(struct FMovieSceneObjectBindingID& InCameraBindingID);

	// Object: Function MovieSceneTracks.MovieSceneCameraCutSection.GetCameraBindingID
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10491a618
	// Return & Params: [ Num(1) Size(0x18) ]
	struct FMovieSceneObjectBindingID GetCameraBindingID();
};

// Object: Class MovieSceneTracks.MovieSceneCameraCutTrack
// Inherited Bytes: 0x58 | Struct Size: 0x68
struct UMovieSceneCameraCutTrack : UMovieSceneNameableTrack {
	// Fields
	bool bCanBlend; // Offset: 0x56 | Size: 0x1
	struct TArray<struct UMovieSceneSection*> Sections; // Offset: 0x58 | Size: 0x10
};

// Object: Class MovieSceneTracks.MovieSceneCameraShakeSection
// Inherited Bytes: 0xd8 | Struct Size: 0x118
struct UMovieSceneCameraShakeSection : UMovieSceneSection {
	// Fields
	struct FMovieSceneCameraShakeSectionData ShakeData; // Offset: 0xd8 | Size: 0x20
	struct UCameraShake* ShakeClass; // Offset: 0xf8 | Size: 0x8
	float PlayScale; // Offset: 0x100 | Size: 0x4
	enum class ECameraAnimPlaySpace PlaySpace; // Offset: 0x104 | Size: 0x1
	char pad_0x105[0x3]; // Offset: 0x105 | Size: 0x3
	struct FRotator UserDefinedPlaySpace; // Offset: 0x108 | Size: 0xc
	char pad_0x114[0x4]; // Offset: 0x114 | Size: 0x4
};

// Object: Class MovieSceneTracks.MovieSceneCameraShakeTrack
// Inherited Bytes: 0x58 | Struct Size: 0x68
struct UMovieSceneCameraShakeTrack : UMovieSceneNameableTrack {
	// Fields
	struct TArray<struct UMovieSceneSection*> CameraShakeSections; // Offset: 0x58 | Size: 0x10
};

// Object: Class MovieSceneTracks.MovieSceneCinematicShotSection
// Inherited Bytes: 0x150 | Struct Size: 0x178
struct UMovieSceneCinematicShotSection : UMovieSceneSubSection {
	// Fields
	struct FString ShotDisplayName; // Offset: 0x150 | Size: 0x10
	struct FText DisplayName; // Offset: 0x160 | Size: 0x18

	// Functions

	// Object: Function MovieSceneTracks.MovieSceneCinematicShotSection.SetShotDisplayName
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104920714
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetShotDisplayName(struct FString InShotDisplayName);

	// Object: Function MovieSceneTracks.MovieSceneCinematicShotSection.GetShotDisplayName
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104920800
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetShotDisplayName();
};

// Object: Class MovieSceneTracks.MovieSceneCinematicShotTrack
// Inherited Bytes: 0x68 | Struct Size: 0x68
struct UMovieSceneCinematicShotTrack : UMovieSceneSubTrack {
};

// Object: Class MovieSceneTracks.MovieSceneColorSection
// Inherited Bytes: 0xd8 | Struct Size: 0x358
struct UMovieSceneColorSection : UMovieSceneSection {
	// Fields
	struct FMovieSceneFloatChannel RedCurve; // Offset: 0xd8 | Size: 0xa0
	struct FMovieSceneFloatChannel GreenCurve; // Offset: 0x178 | Size: 0xa0
	struct FMovieSceneFloatChannel BlueCurve; // Offset: 0x218 | Size: 0xa0
	struct FMovieSceneFloatChannel AlphaCurve; // Offset: 0x2b8 | Size: 0xa0
};

// Object: Class MovieSceneTracks.MovieSceneColorTrack
// Inherited Bytes: 0x88 | Struct Size: 0x90
struct UMovieSceneColorTrack : UMovieScenePropertyTrack {
	// Fields
	bool bIsSlateColor; // Offset: 0x88 | Size: 0x1
	char pad_0x89[0x7]; // Offset: 0x89 | Size: 0x7
};

// Object: Class MovieSceneTracks.MovieSceneEnumSection
// Inherited Bytes: 0xd8 | Struct Size: 0x170
struct UMovieSceneEnumSection : UMovieSceneSection {
	// Fields
	struct FMovieSceneByteChannel EnumCurve; // Offset: 0xd8 | Size: 0x98
};

// Object: Class MovieSceneTracks.MovieSceneEnumTrack
// Inherited Bytes: 0x88 | Struct Size: 0x90
struct UMovieSceneEnumTrack : UMovieScenePropertyTrack {
	// Fields
	struct UEnum* Enum; // Offset: 0x88 | Size: 0x8
};

// Object: Class MovieSceneTracks.MovieSceneEulerTransformTrack
// Inherited Bytes: 0x88 | Struct Size: 0x88
struct UMovieSceneEulerTransformTrack : UMovieScenePropertyTrack {
};

// Object: Class MovieSceneTracks.MovieSceneEventSectionBase
// Inherited Bytes: 0xd8 | Struct Size: 0xd8
struct UMovieSceneEventSectionBase : UMovieSceneSection {
};

// Object: Class MovieSceneTracks.MovieSceneEventRepeaterSection
// Inherited Bytes: 0xd8 | Struct Size: 0x100
struct UMovieSceneEventRepeaterSection : UMovieSceneEventSectionBase {
	// Fields
	struct FMovieSceneEvent Event; // Offset: 0xd8 | Size: 0x28
};

// Object: Class MovieSceneTracks.MovieSceneEventSection
// Inherited Bytes: 0xd8 | Struct Size: 0x1d8
struct UMovieSceneEventSection : UMovieSceneSection {
	// Fields
	struct FNameCurve Events; // Offset: 0xd8 | Size: 0x78
	struct FMovieSceneEventSectionData EventData; // Offset: 0x150 | Size: 0x88
};

// Object: Class MovieSceneTracks.MovieSceneEventTrack
// Inherited Bytes: 0x58 | Struct Size: 0x78
struct UMovieSceneEventTrack : UMovieSceneNameableTrack {
	// Fields
	char bFireEventsWhenForwards : 1; // Offset: 0x56 | Size: 0x1
	char bFireEventsWhenBackwards : 1; // Offset: 0x56 | Size: 0x1
	enum class EFireEventsAtPosition EventPosition; // Offset: 0x57 | Size: 0x1
	struct TArray<struct FMovieSceneObjectBindingID> EventReceivers; // Offset: 0x58 | Size: 0x10
	struct TArray<struct UMovieSceneSection*> Sections; // Offset: 0x68 | Size: 0x10
};

// Object: Class MovieSceneTracks.MovieSceneEventTriggerSection
// Inherited Bytes: 0xd8 | Struct Size: 0x160
struct UMovieSceneEventTriggerSection : UMovieSceneEventSectionBase {
	// Fields
	struct FMovieSceneEventChannel EventChannel; // Offset: 0xd8 | Size: 0x88
};

// Object: Class MovieSceneTracks.MovieSceneFloatSection
// Inherited Bytes: 0xd8 | Struct Size: 0x178
struct UMovieSceneFloatSection : UMovieSceneSection {
	// Fields
	struct FMovieSceneFloatChannel FloatCurve; // Offset: 0xd8 | Size: 0xa0
};

// Object: Class MovieSceneTracks.MovieSceneFadeSection
// Inherited Bytes: 0x178 | Struct Size: 0x190
struct UMovieSceneFadeSection : UMovieSceneFloatSection {
	// Fields
	struct FLinearColor FadeColor; // Offset: 0x178 | Size: 0x10
	char bFadeAudio : 1; // Offset: 0x188 | Size: 0x1
	char pad_0x188_1 : 7; // Offset: 0x188 | Size: 0x1
	char pad_0x189[0x7]; // Offset: 0x189 | Size: 0x7
};

// Object: Class MovieSceneTracks.MovieSceneFloatTrack
// Inherited Bytes: 0x88 | Struct Size: 0x88
struct UMovieSceneFloatTrack : UMovieScenePropertyTrack {
};

// Object: Class MovieSceneTracks.MovieSceneFadeTrack
// Inherited Bytes: 0x88 | Struct Size: 0x88
struct UMovieSceneFadeTrack : UMovieSceneFloatTrack {
};

// Object: Class MovieSceneTracks.MovieSceneIntegerSection
// Inherited Bytes: 0xd8 | Struct Size: 0x168
struct UMovieSceneIntegerSection : UMovieSceneSection {
	// Fields
	struct FMovieSceneIntegerChannel IntegerCurve; // Offset: 0xd8 | Size: 0x90
};

// Object: Class MovieSceneTracks.MovieSceneIntegerTrack
// Inherited Bytes: 0x88 | Struct Size: 0x88
struct UMovieSceneIntegerTrack : UMovieScenePropertyTrack {
};

// Object: Class MovieSceneTracks.MovieSceneLevelVisibilitySection
// Inherited Bytes: 0xd8 | Struct Size: 0xf0
struct UMovieSceneLevelVisibilitySection : UMovieSceneSection {
	// Fields
	enum class ELevelVisibility Visibility; // Offset: 0xd8 | Size: 0x1
	char pad_0xD9[0x7]; // Offset: 0xd9 | Size: 0x7
	struct TArray<struct FName> LevelNames; // Offset: 0xe0 | Size: 0x10

	// Functions

	// Object: Function MovieSceneTracks.MovieSceneLevelVisibilitySection.SetVisibility
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10492353c
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetVisibility(enum class ELevelVisibility InVisibility);

	// Object: Function MovieSceneTracks.MovieSceneLevelVisibilitySection.SetLevelNames
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1049233c0
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetLevelNames(struct TArray<struct FName>& InLevelNames);

	// Object: Function MovieSceneTracks.MovieSceneLevelVisibilitySection.GetVisibility
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1049235bc
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class ELevelVisibility GetVisibility();

	// Object: Function MovieSceneTracks.MovieSceneLevelVisibilitySection.GetLevelNames
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1049234b8
	// Return & Params: [ Num(1) Size(0x10) ]
	struct TArray<struct FName> GetLevelNames();
};

// Object: Class MovieSceneTracks.MovieSceneLevelVisibilityTrack
// Inherited Bytes: 0x58 | Struct Size: 0x68
struct UMovieSceneLevelVisibilityTrack : UMovieSceneNameableTrack {
	// Fields
	struct TArray<struct UMovieSceneSection*> Sections; // Offset: 0x58 | Size: 0x10
};

// Object: Class MovieSceneTracks.MovieSceneMaterialTrack
// Inherited Bytes: 0x58 | Struct Size: 0x68
struct UMovieSceneMaterialTrack : UMovieSceneNameableTrack {
	// Fields
	struct TArray<struct UMovieSceneSection*> Sections; // Offset: 0x58 | Size: 0x10
};

// Object: Class MovieSceneTracks.MovieSceneMaterialParameterCollectionTrack
// Inherited Bytes: 0x68 | Struct Size: 0x70
struct UMovieSceneMaterialParameterCollectionTrack : UMovieSceneMaterialTrack {
	// Fields
	struct UMaterialParameterCollection* MPC; // Offset: 0x68 | Size: 0x8
};

// Object: Class MovieSceneTracks.MovieSceneComponentMaterialTrack
// Inherited Bytes: 0x68 | Struct Size: 0x70
struct UMovieSceneComponentMaterialTrack : UMovieSceneMaterialTrack {
	// Fields
	int32_t MaterialIndex; // Offset: 0x68 | Size: 0x4
	char pad_0x6C[0x4]; // Offset: 0x6c | Size: 0x4
};

// Object: Class MovieSceneTracks.MovieSceneObjectPropertySection
// Inherited Bytes: 0xd8 | Struct Size: 0x198
struct UMovieSceneObjectPropertySection : UMovieSceneSection {
	// Fields
	struct FMovieSceneObjectPathChannel ObjectChannel; // Offset: 0xd8 | Size: 0xc0
};

// Object: Class MovieSceneTracks.MovieSceneObjectPropertyTrack
// Inherited Bytes: 0x88 | Struct Size: 0x90
struct UMovieSceneObjectPropertyTrack : UMovieScenePropertyTrack {
	// Fields
	struct UObject* PropertyClass; // Offset: 0x88 | Size: 0x8
};

// Object: Class MovieSceneTracks.MovieSceneParticleParameterTrack
// Inherited Bytes: 0x58 | Struct Size: 0x68
struct UMovieSceneParticleParameterTrack : UMovieSceneNameableTrack {
	// Fields
	struct TArray<struct UMovieSceneSection*> Sections; // Offset: 0x58 | Size: 0x10
};

// Object: Class MovieSceneTracks.MovieSceneParticleSection
// Inherited Bytes: 0xd8 | Struct Size: 0x170
struct UMovieSceneParticleSection : UMovieSceneSection {
	// Fields
	struct FMovieSceneParticleChannel ParticleKeys; // Offset: 0xd8 | Size: 0x98
};

// Object: Class MovieSceneTracks.MovieSceneParticleTrack
// Inherited Bytes: 0x58 | Struct Size: 0x68
struct UMovieSceneParticleTrack : UMovieSceneNameableTrack {
	// Fields
	struct TArray<struct UMovieSceneSection*> ParticleSections; // Offset: 0x58 | Size: 0x10
};

// Object: Class MovieSceneTracks.MovieScenePrimitiveMaterialSection
// Inherited Bytes: 0xd8 | Struct Size: 0x198
struct UMovieScenePrimitiveMaterialSection : UMovieSceneSection {
	// Fields
	struct FMovieSceneObjectPathChannel MaterialChannel; // Offset: 0xd8 | Size: 0xc0
};

// Object: Class MovieSceneTracks.MovieScenePrimitiveMaterialTrack
// Inherited Bytes: 0x88 | Struct Size: 0x90
struct UMovieScenePrimitiveMaterialTrack : UMovieScenePropertyTrack {
	// Fields
	int32_t MaterialIndex; // Offset: 0x88 | Size: 0x4
	char pad_0x8C[0x4]; // Offset: 0x8c | Size: 0x4
};

// Object: Class MovieSceneTracks.MovieSceneSkeletalAnimationSection
// Inherited Bytes: 0xd8 | Struct Size: 0x1d8
struct UMovieSceneSkeletalAnimationSection : UMovieSceneSection {
	// Fields
	struct FMovieSceneSkeletalAnimationParams Params; // Offset: 0xd8 | Size: 0xd8
	struct UAnimSequence* AnimSequence; // Offset: 0x1b0 | Size: 0x8
	struct UAnimSequenceBase* Animation; // Offset: 0x1b8 | Size: 0x8
	float StartOffset; // Offset: 0x1c0 | Size: 0x4
	float EndOffset; // Offset: 0x1c4 | Size: 0x4
	float PlayRate; // Offset: 0x1c8 | Size: 0x4
	char bReverse : 1; // Offset: 0x1cc | Size: 0x1
	char pad_0x1CC_1 : 7; // Offset: 0x1cc | Size: 0x1
	char pad_0x1CD[0x3]; // Offset: 0x1cd | Size: 0x3
	struct FName SlotName; // Offset: 0x1d0 | Size: 0x8
};

// Object: Class MovieSceneTracks.MovieSceneSkeletalAnimationTrack
// Inherited Bytes: 0x58 | Struct Size: 0x70
struct UMovieSceneSkeletalAnimationTrack : UMovieSceneNameableTrack {
	// Fields
	struct TArray<struct UMovieSceneSection*> AnimationSections; // Offset: 0x58 | Size: 0x10
	bool bUseLegacySectionIndexBlend; // Offset: 0x68 | Size: 0x1
	char pad_0x69[0x7]; // Offset: 0x69 | Size: 0x7
};

// Object: Class MovieSceneTracks.MovieSceneSlomoSection
// Inherited Bytes: 0x178 | Struct Size: 0x178
struct UMovieSceneSlomoSection : UMovieSceneFloatSection {
};

// Object: Class MovieSceneTracks.MovieSceneSlomoTrack
// Inherited Bytes: 0x88 | Struct Size: 0x88
struct UMovieSceneSlomoTrack : UMovieSceneFloatTrack {
};

// Object: Class MovieSceneTracks.MovieSceneSpawnSection
// Inherited Bytes: 0x170 | Struct Size: 0x170
struct UMovieSceneSpawnSection : UMovieSceneBoolSection {
};

// Object: Class MovieSceneTracks.MovieSceneStringSection
// Inherited Bytes: 0xd8 | Struct Size: 0x178
struct UMovieSceneStringSection : UMovieSceneSection {
	// Fields
	struct FMovieSceneStringChannel StringCurve; // Offset: 0xd8 | Size: 0xa0
};

// Object: Class MovieSceneTracks.MovieSceneStringTrack
// Inherited Bytes: 0x88 | Struct Size: 0x88
struct UMovieSceneStringTrack : UMovieScenePropertyTrack {
};

// Object: Class MovieSceneTracks.MovieSceneTransformTrack
// Inherited Bytes: 0x88 | Struct Size: 0x88
struct UMovieSceneTransformTrack : UMovieScenePropertyTrack {
};

// Object: Class MovieSceneTracks.MovieSceneVectorSection
// Inherited Bytes: 0xd8 | Struct Size: 0x360
struct UMovieSceneVectorSection : UMovieSceneSection {
	// Fields
	struct FMovieSceneFloatChannel Curves[0x4]; // Offset: 0xd8 | Size: 0x280
	int32_t ChannelsUsed; // Offset: 0x358 | Size: 0x4
	char pad_0x35C[0x4]; // Offset: 0x35c | Size: 0x4
};

// Object: Class MovieSceneTracks.MovieSceneVectorTrack
// Inherited Bytes: 0x88 | Struct Size: 0x90
struct UMovieSceneVectorTrack : UMovieScenePropertyTrack {
	// Fields
	int32_t NumChannelsUsed; // Offset: 0x88 | Size: 0x4
	char pad_0x8C[0x4]; // Offset: 0x8c | Size: 0x4
};

// Object: Class MovieSceneTracks.MovieSceneVisibilityTrack
// Inherited Bytes: 0x88 | Struct Size: 0x88
struct UMovieSceneVisibilityTrack : UMovieSceneBoolTrack {
};

