#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class OnlineSubsystemUtils.AchievementBlueprintLibrary
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UAchievementBlueprintLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object: Function OnlineSubsystemUtils.AchievementBlueprintLibrary.GetCachedAchievementProgress
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102520b3c
	// Return & Params: [ Num(5) Size(0x20) ]
	void GetCachedAchievementProgress(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct FName AchievementID, bool& bFoundID, float& Progress);

	// Object: Function OnlineSubsystemUtils.AchievementBlueprintLibrary.GetCachedAchievementDescription
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102520774
	// Return & Params: [ Num(8) Size(0x69) ]
	void GetCachedAchievementDescription(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct FName AchievementID, bool& bFoundID, struct FText& Title, struct FText& LockedDescription, struct FText& UnlockedDescription, bool& bHidden);
};

// Object: Class OnlineSubsystemUtils.AchievementQueryCallbackProxy
// Inherited Bytes: 0x30 | Struct Size: 0x68
struct UAchievementQueryCallbackProxy : UOnlineBlueprintCallProxyBase {
	// Fields
	struct FMulticastInlineDelegate OnSuccess; // Offset: 0x30 | Size: 0x10
	struct FMulticastInlineDelegate OnFailure; // Offset: 0x40 | Size: 0x10
	char pad_0x50[0x18]; // Offset: 0x50 | Size: 0x18

	// Functions

	// Object: Function OnlineSubsystemUtils.AchievementQueryCallbackProxy.CacheAchievements
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102521054
	// Return & Params: [ Num(3) Size(0x18) ]
	struct UAchievementQueryCallbackProxy* CacheAchievements(struct UObject* WorldContextObject, struct APlayerController* PlayerController);

	// Object: Function OnlineSubsystemUtils.AchievementQueryCallbackProxy.CacheAchievementDescriptions
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102520f8c
	// Return & Params: [ Num(3) Size(0x18) ]
	struct UAchievementQueryCallbackProxy* CacheAchievementDescriptions(struct UObject* WorldContextObject, struct APlayerController* PlayerController);
};

// Object: Class OnlineSubsystemUtils.AchievementWriteCallbackProxy
// Inherited Bytes: 0x30 | Struct Size: 0x80
struct UAchievementWriteCallbackProxy : UOnlineBlueprintCallProxyBase {
	// Fields
	struct FMulticastInlineDelegate OnSuccess; // Offset: 0x30 | Size: 0x10
	struct FMulticastInlineDelegate OnFailure; // Offset: 0x40 | Size: 0x10
	char pad_0x50[0x30]; // Offset: 0x50 | Size: 0x30

	// Functions

	// Object: Function OnlineSubsystemUtils.AchievementWriteCallbackProxy.WriteAchievementProgress
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102521550
	// Return & Params: [ Num(6) Size(0x28) ]
	struct UAchievementWriteCallbackProxy* WriteAchievementProgress(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct FName AchievementName, float Progress, int32_t UserTag);
};

// Object: Class OnlineSubsystemUtils.ConnectionCallbackProxy
// Inherited Bytes: 0x30 | Struct Size: 0x78
struct UConnectionCallbackProxy : UOnlineBlueprintCallProxyBase {
	// Fields
	struct FMulticastInlineDelegate OnSuccess; // Offset: 0x30 | Size: 0x10
	struct FMulticastInlineDelegate OnFailure; // Offset: 0x40 | Size: 0x10
	char pad_0x50[0x28]; // Offset: 0x50 | Size: 0x28

	// Functions

	// Object: Function OnlineSubsystemUtils.ConnectionCallbackProxy.ConnectToService
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102521ae0
	// Return & Params: [ Num(3) Size(0x18) ]
	struct UConnectionCallbackProxy* ConnectToService(struct UObject* WorldContextObject, struct APlayerController* PlayerController);
};

// Object: Class OnlineSubsystemUtils.CreateSessionCallbackProxy
// Inherited Bytes: 0x30 | Struct Size: 0x98
struct UCreateSessionCallbackProxy : UOnlineBlueprintCallProxyBase {
	// Fields
	struct FMulticastInlineDelegate OnSuccess; // Offset: 0x30 | Size: 0x10
	struct FMulticastInlineDelegate OnFailure; // Offset: 0x40 | Size: 0x10
	char pad_0x50[0x48]; // Offset: 0x50 | Size: 0x48

	// Functions

	// Object: Function OnlineSubsystemUtils.CreateSessionCallbackProxy.CreateSession
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102521f40
	// Return & Params: [ Num(5) Size(0x20) ]
	struct UCreateSessionCallbackProxy* CreateSession(struct UObject* WorldContextObject, struct APlayerController* PlayerController, int32_t PublicConnections, bool bUseLAN);
};

// Object: Class OnlineSubsystemUtils.DestroySessionCallbackProxy
// Inherited Bytes: 0x30 | Struct Size: 0x78
struct UDestroySessionCallbackProxy : UOnlineBlueprintCallProxyBase {
	// Fields
	struct FMulticastInlineDelegate OnSuccess; // Offset: 0x30 | Size: 0x10
	struct FMulticastInlineDelegate OnFailure; // Offset: 0x40 | Size: 0x10
	char pad_0x50[0x28]; // Offset: 0x50 | Size: 0x28

	// Functions

	// Object: Function OnlineSubsystemUtils.DestroySessionCallbackProxy.DestroySession
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102522448
	// Return & Params: [ Num(3) Size(0x18) ]
	struct UDestroySessionCallbackProxy* DestroySession(struct UObject* WorldContextObject, struct APlayerController* PlayerController);
};

// Object: Class OnlineSubsystemUtils.EndMatchCallbackProxy
// Inherited Bytes: 0x30 | Struct Size: 0x80
struct UEndMatchCallbackProxy : UOnlineBlueprintCallProxyBase {
	// Fields
	struct FMulticastInlineDelegate OnSuccess; // Offset: 0x30 | Size: 0x10
	struct FMulticastInlineDelegate OnFailure; // Offset: 0x40 | Size: 0x10
	char pad_0x50[0x30]; // Offset: 0x50 | Size: 0x30

	// Functions

	// Object: Function OnlineSubsystemUtils.EndMatchCallbackProxy.EndMatch
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1025228a8
	// Return & Params: [ Num(7) Size(0x40) ]
	struct UEndMatchCallbackProxy* EndMatch(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct TScriptInterface<ITurnBasedMatchInterface> MatchActor, struct FString MatchID, enum class EMPMatchOutcome LocalPlayerOutcome, enum class EMPMatchOutcome OtherPlayersOutcome);
};

// Object: Class OnlineSubsystemUtils.EndTurnCallbackProxy
// Inherited Bytes: 0x30 | Struct Size: 0x78
struct UEndTurnCallbackProxy : UOnlineBlueprintCallProxyBase {
	// Fields
	struct FMulticastInlineDelegate OnSuccess; // Offset: 0x30 | Size: 0x10
	struct FMulticastInlineDelegate OnFailure; // Offset: 0x40 | Size: 0x10
	char pad_0x50[0x28]; // Offset: 0x50 | Size: 0x28

	// Functions

	// Object: Function OnlineSubsystemUtils.EndTurnCallbackProxy.EndTurn
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102522eb4
	// Return & Params: [ Num(5) Size(0x38) ]
	struct UEndTurnCallbackProxy* EndTurn(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct FString MatchID, struct TScriptInterface<ITurnBasedMatchInterface> TurnBasedMatchInterface);
};

// Object: Class OnlineSubsystemUtils.FindSessionsCallbackProxy
// Inherited Bytes: 0x30 | Struct Size: 0x90
struct UFindSessionsCallbackProxy : UOnlineBlueprintCallProxyBase {
	// Fields
	struct FMulticastInlineDelegate OnSuccess; // Offset: 0x30 | Size: 0x10
	struct FMulticastInlineDelegate OnFailure; // Offset: 0x40 | Size: 0x10
	char pad_0x50[0x40]; // Offset: 0x50 | Size: 0x40

	// Functions

	// Object: Function OnlineSubsystemUtils.FindSessionsCallbackProxy.GetServerName
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x102523900
	// Return & Params: [ Num(2) Size(0x118) ]
	struct FString GetServerName(struct FBlueprintSessionResult& Result);

	// Object: Function OnlineSubsystemUtils.FindSessionsCallbackProxy.GetPingInMs
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x102523b0c
	// Return & Params: [ Num(2) Size(0x10c) ]
	int32_t GetPingInMs(struct FBlueprintSessionResult& Result);

	// Object: Function OnlineSubsystemUtils.FindSessionsCallbackProxy.GetMaxPlayers
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x102523550
	// Return & Params: [ Num(2) Size(0x10c) ]
	int32_t GetMaxPlayers(struct FBlueprintSessionResult& Result);

	// Object: Function OnlineSubsystemUtils.FindSessionsCallbackProxy.GetCurrentPlayers
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x102523728
	// Return & Params: [ Num(2) Size(0x10c) ]
	int32_t GetCurrentPlayers(struct FBlueprintSessionResult& Result);

	// Object: Function OnlineSubsystemUtils.FindSessionsCallbackProxy.FindSessions
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102523ce4
	// Return & Params: [ Num(5) Size(0x20) ]
	struct UFindSessionsCallbackProxy* FindSessions(struct UObject* WorldContextObject, struct APlayerController* PlayerController, int32_t MaxResults, bool bUseLAN);
};

// Object: Class OnlineSubsystemUtils.FindTurnBasedMatchCallbackProxy
// Inherited Bytes: 0x30 | Struct Size: 0x88
struct UFindTurnBasedMatchCallbackProxy : UOnlineBlueprintCallProxyBase {
	// Fields
	struct FMulticastInlineDelegate OnSuccess; // Offset: 0x30 | Size: 0x10
	struct FMulticastInlineDelegate OnFailure; // Offset: 0x40 | Size: 0x10
	char pad_0x50[0x38]; // Offset: 0x50 | Size: 0x38

	// Functions

	// Object: Function OnlineSubsystemUtils.FindTurnBasedMatchCallbackProxy.FindTurnBasedMatch
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102524368
	// Return & Params: [ Num(8) Size(0x38) ]
	struct UFindTurnBasedMatchCallbackProxy* FindTurnBasedMatch(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct TScriptInterface<ITurnBasedMatchInterface> MatchActor, int32_t MinPlayers, int32_t MaxPlayers, int32_t PlayerGroup, bool ShowExistingMatches);
};

// Object: Class OnlineSubsystemUtils.InAppPurchaseCallbackProxy
// Inherited Bytes: 0x28 | Struct Size: 0x80
struct UInAppPurchaseCallbackProxy : UObject {
	// Fields
	struct FMulticastInlineDelegate OnSuccess; // Offset: 0x28 | Size: 0x10
	struct FMulticastInlineDelegate OnFailure; // Offset: 0x38 | Size: 0x10
	char pad_0x48[0x38]; // Offset: 0x48 | Size: 0x38

	// Functions

	// Object: Function OnlineSubsystemUtils.InAppPurchaseCallbackProxy.CreateProxyObjectForInAppPurchase
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102524a84
	// Return & Params: [ Num(3) Size(0x28) ]
	struct UInAppPurchaseCallbackProxy* CreateProxyObjectForInAppPurchase(struct APlayerController* PlayerController, struct FInAppPurchaseProductRequest& ProductRequest);
};

// Object: Class OnlineSubsystemUtils.InAppPurchaseCallbackProxy2
// Inherited Bytes: 0x28 | Struct Size: 0xa8
struct UInAppPurchaseCallbackProxy2 : UObject {
	// Fields
	struct FMulticastInlineDelegate OnSuccess; // Offset: 0x28 | Size: 0x10
	struct FMulticastInlineDelegate OnFailure; // Offset: 0x38 | Size: 0x10
	char pad_0x48[0x60]; // Offset: 0x48 | Size: 0x60

	// Functions

	// Object: Function OnlineSubsystemUtils.InAppPurchaseCallbackProxy2.CreateProxyObjectForInAppPurchaseUnprocessedPurchases
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1025252dc
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UInAppPurchaseCallbackProxy2* CreateProxyObjectForInAppPurchaseUnprocessedPurchases(struct APlayerController* PlayerController);

	// Object: Function OnlineSubsystemUtils.InAppPurchaseCallbackProxy2.CreateProxyObjectForInAppPurchaseQueryOwned
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10252525c
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UInAppPurchaseCallbackProxy2* CreateProxyObjectForInAppPurchaseQueryOwned(struct APlayerController* PlayerController);

	// Object: Function OnlineSubsystemUtils.InAppPurchaseCallbackProxy2.CreateProxyObjectForInAppPurchase
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10252535c
	// Return & Params: [ Num(3) Size(0x28) ]
	struct UInAppPurchaseCallbackProxy2* CreateProxyObjectForInAppPurchase(struct APlayerController* PlayerController, struct FInAppPurchaseProductRequest2& ProductRequest);
};

// Object: Class OnlineSubsystemUtils.InAppPurchaseQueryCallbackProxy
// Inherited Bytes: 0x28 | Struct Size: 0x90
struct UInAppPurchaseQueryCallbackProxy : UObject {
	// Fields
	struct FMulticastInlineDelegate OnSuccess; // Offset: 0x28 | Size: 0x10
	struct FMulticastInlineDelegate OnFailure; // Offset: 0x38 | Size: 0x10
	char pad_0x48[0x48]; // Offset: 0x48 | Size: 0x48

	// Functions

	// Object: Function OnlineSubsystemUtils.InAppPurchaseQueryCallbackProxy.CreateProxyObjectForInAppPurchaseQuery
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10252589c
	// Return & Params: [ Num(3) Size(0x20) ]
	struct UInAppPurchaseQueryCallbackProxy* CreateProxyObjectForInAppPurchaseQuery(struct APlayerController* PlayerController, struct TArray<struct FString>& ProductIdentifiers);
};

// Object: Class OnlineSubsystemUtils.InAppPurchaseQueryCallbackProxy2
// Inherited Bytes: 0x28 | Struct Size: 0x68
struct UInAppPurchaseQueryCallbackProxy2 : UObject {
	// Fields
	struct FMulticastInlineDelegate OnSuccess; // Offset: 0x28 | Size: 0x10
	struct FMulticastInlineDelegate OnFailure; // Offset: 0x38 | Size: 0x10
	char pad_0x48[0x20]; // Offset: 0x48 | Size: 0x20

	// Functions

	// Object: Function OnlineSubsystemUtils.InAppPurchaseQueryCallbackProxy2.CreateProxyObjectForInAppPurchaseQuery
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102525eec
	// Return & Params: [ Num(3) Size(0x20) ]
	struct UInAppPurchaseQueryCallbackProxy2* CreateProxyObjectForInAppPurchaseQuery(struct APlayerController* PlayerController, struct TArray<struct FString>& ProductIdentifiers);
};

// Object: Class OnlineSubsystemUtils.InAppPurchaseRestoreCallbackProxy
// Inherited Bytes: 0x28 | Struct Size: 0x90
struct UInAppPurchaseRestoreCallbackProxy : UObject {
	// Fields
	struct FMulticastInlineDelegate OnSuccess; // Offset: 0x28 | Size: 0x10
	struct FMulticastInlineDelegate OnFailure; // Offset: 0x38 | Size: 0x10
	char pad_0x48[0x48]; // Offset: 0x48 | Size: 0x48

	// Functions

	// Object: Function OnlineSubsystemUtils.InAppPurchaseRestoreCallbackProxy.CreateProxyObjectForInAppPurchaseRestore
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1025263c8
	// Return & Params: [ Num(3) Size(0x20) ]
	struct UInAppPurchaseRestoreCallbackProxy* CreateProxyObjectForInAppPurchaseRestore(struct TArray<struct FInAppPurchaseProductRequest>& ConsumableProductFlags, struct APlayerController* PlayerController);
};

// Object: Class OnlineSubsystemUtils.InAppPurchaseRestoreCallbackProxy2
// Inherited Bytes: 0x28 | Struct Size: 0xa8
struct UInAppPurchaseRestoreCallbackProxy2 : UObject {
	// Fields
	struct FMulticastInlineDelegate OnSuccess; // Offset: 0x28 | Size: 0x10
	struct FMulticastInlineDelegate OnFailure; // Offset: 0x38 | Size: 0x10
	char pad_0x48[0x60]; // Offset: 0x48 | Size: 0x60

	// Functions

	// Object: Function OnlineSubsystemUtils.InAppPurchaseRestoreCallbackProxy2.CreateProxyObjectForInAppPurchaseRestore
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10252697c
	// Return & Params: [ Num(3) Size(0x20) ]
	struct UInAppPurchaseRestoreCallbackProxy2* CreateProxyObjectForInAppPurchaseRestore(struct TArray<struct FInAppPurchaseProductRequest2>& ConsumableProductFlags, struct APlayerController* PlayerController);
};

// Object: Class OnlineSubsystemUtils.IpConnection
// Inherited Bytes: 0x1b10 | Struct Size: 0x1bc8
struct UIpConnection : UNetConnection {
	// Fields
	char pad_0x1B10[0x68]; // Offset: 0x1b10 | Size: 0x68
	float SocketErrorDisconnectDelay; // Offset: 0x1b78 | Size: 0x4
	char pad_0x1B7C[0x4c]; // Offset: 0x1b7c | Size: 0x4c
};

// Object: Class OnlineSubsystemUtils.IpNetDriver
// Inherited Bytes: 0x758 | Struct Size: 0x7c8
struct UIpNetDriver : UNetDriver {
	// Fields
	char LogPortUnreach : 1; // Offset: 0x756 | Size: 0x1
	char AllowPlayerPortUnreach : 1; // Offset: 0x756 | Size: 0x1
	uint32_t MaxPortCountToTry; // Offset: 0x758 | Size: 0x4
	char pad_0x75C_2 : 6; // Offset: 0x75c | Size: 0x1
	char pad_0x75D[0xf]; // Offset: 0x75d | Size: 0xf
	uint32_t ServerDesiredSocketReceiveBufferBytes; // Offset: 0x76c | Size: 0x4
	uint32_t ServerDesiredSocketSendBufferBytes; // Offset: 0x770 | Size: 0x4
	uint32_t ClientDesiredSocketReceiveBufferBytes; // Offset: 0x774 | Size: 0x4
	uint32_t ClientDesiredSocketSendBufferBytes; // Offset: 0x778 | Size: 0x4
	char pad_0x77C[0x4]; // Offset: 0x77c | Size: 0x4
	double MaxSecondsInReceive; // Offset: 0x780 | Size: 0x8
	int32_t NbPacketsBetweenReceiveTimeTest; // Offset: 0x788 | Size: 0x4
	float ResolutionConnectionTimeout; // Offset: 0x78c | Size: 0x4
	char pad_0x790[0x38]; // Offset: 0x790 | Size: 0x38
};

// Object: Class OnlineSubsystemUtils.JoinSessionCallbackProxy
// Inherited Bytes: 0x30 | Struct Size: 0x180
struct UJoinSessionCallbackProxy : UOnlineBlueprintCallProxyBase {
	// Fields
	struct FMulticastInlineDelegate OnSuccess; // Offset: 0x30 | Size: 0x10
	struct FMulticastInlineDelegate OnFailure; // Offset: 0x40 | Size: 0x10
	char pad_0x50[0x130]; // Offset: 0x50 | Size: 0x130

	// Functions

	// Object: Function OnlineSubsystemUtils.JoinSessionCallbackProxy.JoinSession
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10252a58c
	// Return & Params: [ Num(4) Size(0x120) ]
	struct UJoinSessionCallbackProxy* JoinSession(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct FBlueprintSessionResult& SearchResult);
};

// Object: Class OnlineSubsystemUtils.LeaderboardBlueprintLibrary
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct ULeaderboardBlueprintLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object: Function OnlineSubsystemUtils.LeaderboardBlueprintLibrary.WriteLeaderboardInteger
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10252ab84
	// Return & Params: [ Num(4) Size(0x15) ]
	bool WriteLeaderboardInteger(struct APlayerController* PlayerController, struct FName StatName, int32_t StatValue);
};

// Object: Class OnlineSubsystemUtils.LeaderboardFlushCallbackProxy
// Inherited Bytes: 0x28 | Struct Size: 0x68
struct ULeaderboardFlushCallbackProxy : UObject {
	// Fields
	struct FMulticastInlineDelegate OnSuccess; // Offset: 0x28 | Size: 0x10
	struct FMulticastInlineDelegate OnFailure; // Offset: 0x38 | Size: 0x10
	char pad_0x48[0x20]; // Offset: 0x48 | Size: 0x20

	// Functions

	// Object: Function OnlineSubsystemUtils.LeaderboardFlushCallbackProxy.CreateProxyObjectForFlush
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10252af10
	// Return & Params: [ Num(3) Size(0x18) ]
	struct ULeaderboardFlushCallbackProxy* CreateProxyObjectForFlush(struct APlayerController* PlayerController, struct FName SessionName);
};

// Object: Class OnlineSubsystemUtils.LeaderboardQueryCallbackProxy
// Inherited Bytes: 0x28 | Struct Size: 0x98
struct ULeaderboardQueryCallbackProxy : UObject {
	// Fields
	struct FMulticastInlineDelegate OnSuccess; // Offset: 0x28 | Size: 0x10
	struct FMulticastInlineDelegate OnFailure; // Offset: 0x38 | Size: 0x10
	char pad_0x48[0x50]; // Offset: 0x48 | Size: 0x50

	// Functions

	// Object: Function OnlineSubsystemUtils.LeaderboardQueryCallbackProxy.CreateProxyObjectForIntQuery
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10252b39c
	// Return & Params: [ Num(3) Size(0x18) ]
	struct ULeaderboardQueryCallbackProxy* CreateProxyObjectForIntQuery(struct APlayerController* PlayerController, struct FName StatName);
};

// Object: Class OnlineSubsystemUtils.LogoutCallbackProxy
// Inherited Bytes: 0x30 | Struct Size: 0x68
struct ULogoutCallbackProxy : UBlueprintAsyncActionBase {
	// Fields
	struct FMulticastInlineDelegate OnSuccess; // Offset: 0x30 | Size: 0x10
	struct FMulticastInlineDelegate OnFailure; // Offset: 0x40 | Size: 0x10
	char pad_0x50[0x18]; // Offset: 0x50 | Size: 0x18

	// Functions

	// Object: Function OnlineSubsystemUtils.LogoutCallbackProxy.Logout
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10252b828
	// Return & Params: [ Num(3) Size(0x18) ]
	struct ULogoutCallbackProxy* Logout(struct UObject* WorldContextObject, struct APlayerController* PlayerController);
};

// Object: Class OnlineSubsystemUtils.OnlineBeacon
// Inherited Bytes: 0x228 | Struct Size: 0x258
struct AOnlineBeacon : AActor {
	// Fields
	char pad_0x228[0x8]; // Offset: 0x228 | Size: 0x8
	float BeaconConnectionInitialTimeout; // Offset: 0x230 | Size: 0x4
	float BeaconConnectionTimeout; // Offset: 0x234 | Size: 0x4
	struct UNetDriver* NetDriver; // Offset: 0x238 | Size: 0x8
	char pad_0x240[0x18]; // Offset: 0x240 | Size: 0x18
};

// Object: Class OnlineSubsystemUtils.OnlineBeaconClient
// Inherited Bytes: 0x258 | Struct Size: 0x2b8
struct AOnlineBeaconClient : AOnlineBeacon {
	// Fields
	struct AOnlineBeaconHostObject* BeaconOwner; // Offset: 0x258 | Size: 0x8
	struct UNetConnection* BeaconConnection; // Offset: 0x260 | Size: 0x8
	enum class EBeaconConnectionState ConnectionState; // Offset: 0x268 | Size: 0x1
	char pad_0x269[0x4f]; // Offset: 0x269 | Size: 0x4f

	// Functions

	// Object: Function OnlineSubsystemUtils.OnlineBeaconClient.ClientOnConnected
	// Flags: [Final|Net|NetReliableNative|Event|Private|NetClient]
	// Offset: 0x10252be68
	// Return & Params: [ Num(0) Size(0x0) ]
	void ClientOnConnected();
};

// Object: Class OnlineSubsystemUtils.OnlineBeaconHost
// Inherited Bytes: 0x258 | Struct Size: 0x310
struct AOnlineBeaconHost : AOnlineBeacon {
	// Fields
	int32_t ListenPort; // Offset: 0x258 | Size: 0x4
	char pad_0x25C[0x4]; // Offset: 0x25c | Size: 0x4
	struct TArray<struct AOnlineBeaconClient*> ClientActors; // Offset: 0x260 | Size: 0x10
	char pad_0x270[0xa0]; // Offset: 0x270 | Size: 0xa0
};

// Object: Class OnlineSubsystemUtils.OnlineBeaconHostObject
// Inherited Bytes: 0x228 | Struct Size: 0x250
struct AOnlineBeaconHostObject : AActor {
	// Fields
	struct FString BeaconTypeName; // Offset: 0x228 | Size: 0x10
	struct AOnlineBeaconClient* ClientBeaconActorClass; // Offset: 0x238 | Size: 0x8
	struct TArray<struct AOnlineBeaconClient*> ClientActors; // Offset: 0x240 | Size: 0x10
};

// Object: Class OnlineSubsystemUtils.OnlineEngineInterfaceImpl
// Inherited Bytes: 0x28 | Struct Size: 0x128
struct UOnlineEngineInterfaceImpl : UOnlineEngineInterface {
	// Fields
	struct FName VoiceSubsystemNameOverride; // Offset: 0x28 | Size: 0x8
	char pad_0x30[0xf8]; // Offset: 0x30 | Size: 0xf8
};

// Object: Class OnlineSubsystemUtils.OnlinePIESettings
// Inherited Bytes: 0x38 | Struct Size: 0x50
struct UOnlinePIESettings : UDeveloperSettings {
	// Fields
	bool bOnlinePIEEnabled; // Offset: 0x38 | Size: 0x1
	char pad_0x39[0x7]; // Offset: 0x39 | Size: 0x7
	struct TArray<struct FPIELoginSettingsInternal> Logins; // Offset: 0x40 | Size: 0x10
};

// Object: Class OnlineSubsystemUtils.OnlineSessionClient
// Inherited Bytes: 0x28 | Struct Size: 0x1e0
struct UOnlineSessionClient : UOnlineSession {
	// Fields
	char pad_0x28[0x1b0]; // Offset: 0x28 | Size: 0x1b0
	bool bIsFromInvite; // Offset: 0x1d8 | Size: 0x1
	bool bHandlingDisconnect; // Offset: 0x1d9 | Size: 0x1
	char pad_0x1DA[0x6]; // Offset: 0x1da | Size: 0x6
};

// Object: Class OnlineSubsystemUtils.PartyBeaconClient
// Inherited Bytes: 0x2b8 | Struct Size: 0x378
struct APartyBeaconClient : AOnlineBeaconClient {
	// Fields
	char pad_0x2B8[0x30]; // Offset: 0x2b8 | Size: 0x30
	struct FString DestSessionId; // Offset: 0x2e8 | Size: 0x10
	struct FPartyReservation PendingReservation; // Offset: 0x2f8 | Size: 0x50
	enum class EClientRequestType RequestType; // Offset: 0x348 | Size: 0x1
	bool bPendingReservationSent; // Offset: 0x349 | Size: 0x1
	bool bCancelReservation; // Offset: 0x34a | Size: 0x1
	char pad_0x34B[0x2d]; // Offset: 0x34b | Size: 0x2d

	// Functions

	// Object: Function OnlineSubsystemUtils.PartyBeaconClient.ServerUpdateReservationRequest
	// Flags: [Net|NetReliableNative|Event|Protected|NetServer|NetValidate]
	// Offset: 0x10252d080
	// Return & Params: [ Num(2) Size(0x60) ]
	void ServerUpdateReservationRequest(struct FString SessionId, struct FPartyReservation ReservationUpdate);

	// Object: Function OnlineSubsystemUtils.PartyBeaconClient.ServerReservationRequest
	// Flags: [Net|NetReliableNative|Event|Protected|NetServer|NetValidate]
	// Offset: 0x10252d230
	// Return & Params: [ Num(2) Size(0x60) ]
	void ServerReservationRequest(struct FString SessionId, struct FPartyReservation Reservation);

	// Object: Function OnlineSubsystemUtils.PartyBeaconClient.ServerRemoveMemberFromReservationRequest
	// Flags: [Net|NetReliableNative|Event|Protected|NetServer|NetValidate]
	// Offset: 0x10252ced0
	// Return & Params: [ Num(2) Size(0x60) ]
	void ServerRemoveMemberFromReservationRequest(struct FString SessionId, struct FPartyReservation ReservationUpdate);

	// Object: Function OnlineSubsystemUtils.PartyBeaconClient.ServerCancelReservationRequest
	// Flags: [Net|NetReliableNative|Event|Protected|NetServer|NetValidate]
	// Offset: 0x10252cd88
	// Return & Params: [ Num(1) Size(0x28) ]
	void ServerCancelReservationRequest(struct FUniqueNetIdRepl PartyLeader);

	// Object: Function OnlineSubsystemUtils.PartyBeaconClient.ClientSendReservationUpdates
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	// Offset: 0x10252d3fc
	// Return & Params: [ Num(1) Size(0x4) ]
	void ClientSendReservationUpdates(int32_t NumRemainingReservations);

	// Object: Function OnlineSubsystemUtils.PartyBeaconClient.ClientSendReservationFull
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	// Offset: 0x10252d3e0
	// Return & Params: [ Num(0) Size(0x0) ]
	void ClientSendReservationFull();

	// Object: Function OnlineSubsystemUtils.PartyBeaconClient.ClientReservationResponse
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	// Offset: 0x10252d50c
	// Return & Params: [ Num(1) Size(0x1) ]
	void ClientReservationResponse(enum class EPartyReservationResult ReservationResponse);

	// Object: Function OnlineSubsystemUtils.PartyBeaconClient.ClientCancelReservationResponse
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	// Offset: 0x10252d484
	// Return & Params: [ Num(1) Size(0x1) ]
	void ClientCancelReservationResponse(enum class EPartyReservationResult ReservationResponse);
};

// Object: Class OnlineSubsystemUtils.PartyBeaconHost
// Inherited Bytes: 0x250 | Struct Size: 0x2c8
struct APartyBeaconHost : AOnlineBeaconHostObject {
	// Fields
	struct UPartyBeaconState* State; // Offset: 0x250 | Size: 0x8
	char pad_0x258[0x60]; // Offset: 0x258 | Size: 0x60
	bool bLogoutOnSessionTimeout; // Offset: 0x2b8 | Size: 0x1
	char pad_0x2B9[0x3]; // Offset: 0x2b9 | Size: 0x3
	float SessionTimeoutSecs; // Offset: 0x2bc | Size: 0x4
	float TravelSessionTimeoutSecs; // Offset: 0x2c0 | Size: 0x4
	char pad_0x2C4[0x4]; // Offset: 0x2c4 | Size: 0x4
};

// Object: Class OnlineSubsystemUtils.PartyBeaconState
// Inherited Bytes: 0x28 | Struct Size: 0x78
struct UPartyBeaconState : UObject {
	// Fields
	struct FName SessionName; // Offset: 0x28 | Size: 0x8
	int32_t NumConsumedReservations; // Offset: 0x30 | Size: 0x4
	int32_t MaxReservations; // Offset: 0x34 | Size: 0x4
	int32_t NumTeams; // Offset: 0x38 | Size: 0x4
	int32_t NumPlayersPerTeam; // Offset: 0x3c | Size: 0x4
	struct FName TeamAssignmentMethod; // Offset: 0x40 | Size: 0x8
	int32_t ReservedHostTeamNum; // Offset: 0x48 | Size: 0x4
	int32_t ForceTeamNum; // Offset: 0x4c | Size: 0x4
	bool bRestrictCrossConsole; // Offset: 0x50 | Size: 0x1
	bool bEnableRemovalRequests; // Offset: 0x51 | Size: 0x1
	char pad_0x52[0x6]; // Offset: 0x52 | Size: 0x6
	struct TArray<struct FPartyReservation> Reservations; // Offset: 0x58 | Size: 0x10
	char pad_0x68[0x10]; // Offset: 0x68 | Size: 0x10
};

// Object: Class OnlineSubsystemUtils.QuitMatchCallbackProxy
// Inherited Bytes: 0x30 | Struct Size: 0x78
struct UQuitMatchCallbackProxy : UOnlineBlueprintCallProxyBase {
	// Fields
	struct FMulticastInlineDelegate OnSuccess; // Offset: 0x30 | Size: 0x10
	struct FMulticastInlineDelegate OnFailure; // Offset: 0x40 | Size: 0x10
	char pad_0x50[0x28]; // Offset: 0x50 | Size: 0x28

	// Functions

	// Object: Function OnlineSubsystemUtils.QuitMatchCallbackProxy.QuitMatch
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10252ea9c
	// Return & Params: [ Num(6) Size(0x30) ]
	struct UQuitMatchCallbackProxy* QuitMatch(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct FString MatchID, enum class EMPMatchOutcome Outcome, int32_t TurnTimeoutInSeconds);
};

// Object: Class OnlineSubsystemUtils.ShowLoginUICallbackProxy
// Inherited Bytes: 0x30 | Struct Size: 0x60
struct UShowLoginUICallbackProxy : UBlueprintAsyncActionBase {
	// Fields
	struct FMulticastInlineDelegate OnSuccess; // Offset: 0x30 | Size: 0x10
	struct FMulticastInlineDelegate OnFailure; // Offset: 0x40 | Size: 0x10
	char pad_0x50[0x10]; // Offset: 0x50 | Size: 0x10

	// Functions

	// Object: Function OnlineSubsystemUtils.ShowLoginUICallbackProxy.ShowExternalLoginUI
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10252f04c
	// Return & Params: [ Num(3) Size(0x18) ]
	struct UShowLoginUICallbackProxy* ShowExternalLoginUI(struct UObject* WorldContextObject, struct APlayerController* InPlayerController);
};

// Object: Class OnlineSubsystemUtils.SpectatorBeaconClient
// Inherited Bytes: 0x2b8 | Struct Size: 0x3a0
struct ASpectatorBeaconClient : AOnlineBeaconClient {
	// Fields
	char pad_0x2B8[0x30]; // Offset: 0x2b8 | Size: 0x30
	struct FString DestSessionId; // Offset: 0x2e8 | Size: 0x10
	struct FSpectatorReservation PendingReservation; // Offset: 0x2f8 | Size: 0x78
	enum class ESpectatorClientRequestType RequestType; // Offset: 0x370 | Size: 0x1
	bool bPendingReservationSent; // Offset: 0x371 | Size: 0x1
	bool bCancelReservation; // Offset: 0x372 | Size: 0x1
	char pad_0x373[0x2d]; // Offset: 0x373 | Size: 0x2d

	// Functions

	// Object: Function OnlineSubsystemUtils.SpectatorBeaconClient.ServerReservationRequest
	// Flags: [Net|NetReliableNative|Event|Protected|NetServer|NetValidate]
	// Offset: 0x10252f6b0
	// Return & Params: [ Num(2) Size(0x88) ]
	void ServerReservationRequest(struct FString SessionId, struct FSpectatorReservation Reservation);

	// Object: Function OnlineSubsystemUtils.SpectatorBeaconClient.ServerCancelReservationRequest
	// Flags: [Net|NetReliableNative|Event|Protected|NetServer|NetValidate]
	// Offset: 0x10252f568
	// Return & Params: [ Num(1) Size(0x28) ]
	void ServerCancelReservationRequest(struct FUniqueNetIdRepl Spectator);

	// Object: Function OnlineSubsystemUtils.SpectatorBeaconClient.ClientSendReservationUpdates
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	// Offset: 0x10252f900
	// Return & Params: [ Num(1) Size(0x4) ]
	void ClientSendReservationUpdates(int32_t NumRemainingReservations);

	// Object: Function OnlineSubsystemUtils.SpectatorBeaconClient.ClientSendReservationFull
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	// Offset: 0x10252f8e4
	// Return & Params: [ Num(0) Size(0x0) ]
	void ClientSendReservationFull();

	// Object: Function OnlineSubsystemUtils.SpectatorBeaconClient.ClientReservationResponse
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	// Offset: 0x10252fa10
	// Return & Params: [ Num(1) Size(0x1) ]
	void ClientReservationResponse(enum class ESpectatorReservationResult ReservationResponse);

	// Object: Function OnlineSubsystemUtils.SpectatorBeaconClient.ClientCancelReservationResponse
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	// Offset: 0x10252f988
	// Return & Params: [ Num(1) Size(0x1) ]
	void ClientCancelReservationResponse(enum class ESpectatorReservationResult ReservationResponse);
};

// Object: Class OnlineSubsystemUtils.SpectatorBeaconHost
// Inherited Bytes: 0x250 | Struct Size: 0x2c8
struct ASpectatorBeaconHost : AOnlineBeaconHostObject {
	// Fields
	struct USpectatorBeaconState* State; // Offset: 0x250 | Size: 0x8
	char pad_0x258[0x60]; // Offset: 0x258 | Size: 0x60
	bool bLogoutOnSessionTimeout; // Offset: 0x2b8 | Size: 0x1
	char pad_0x2B9[0x3]; // Offset: 0x2b9 | Size: 0x3
	float SessionTimeoutSecs; // Offset: 0x2bc | Size: 0x4
	float TravelSessionTimeoutSecs; // Offset: 0x2c0 | Size: 0x4
	char pad_0x2C4[0x4]; // Offset: 0x2c4 | Size: 0x4
};

// Object: Class OnlineSubsystemUtils.SpectatorBeaconState
// Inherited Bytes: 0x28 | Struct Size: 0x60
struct USpectatorBeaconState : UObject {
	// Fields
	struct FName SessionName; // Offset: 0x28 | Size: 0x8
	int32_t NumConsumedReservations; // Offset: 0x30 | Size: 0x4
	int32_t MaxReservations; // Offset: 0x34 | Size: 0x4
	bool bRestrictCrossConsole; // Offset: 0x38 | Size: 0x1
	char pad_0x39[0x7]; // Offset: 0x39 | Size: 0x7
	struct TArray<struct FSpectatorReservation> Reservations; // Offset: 0x40 | Size: 0x10
	char pad_0x50[0x10]; // Offset: 0x50 | Size: 0x10
};

// Object: Class OnlineSubsystemUtils.TestBeaconClient
// Inherited Bytes: 0x2b8 | Struct Size: 0x2b8
struct ATestBeaconClient : AOnlineBeaconClient {
	// Functions

	// Object: Function OnlineSubsystemUtils.TestBeaconClient.ServerPong
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	// Offset: 0x102530ad0
	// Return & Params: [ Num(0) Size(0x0) ]
	void ServerPong();

	// Object: Function OnlineSubsystemUtils.TestBeaconClient.ClientPing
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	// Offset: 0x102530b2c
	// Return & Params: [ Num(0) Size(0x0) ]
	void ClientPing();
};

// Object: Class OnlineSubsystemUtils.TestBeaconHost
// Inherited Bytes: 0x250 | Struct Size: 0x250
struct ATestBeaconHost : AOnlineBeaconHostObject {
};

// Object: Class OnlineSubsystemUtils.TurnBasedBlueprintLibrary
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UTurnBasedBlueprintLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object: Function OnlineSubsystemUtils.TurnBasedBlueprintLibrary.RegisterTurnBasedMatchInterfaceObject
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102534028
	// Return & Params: [ Num(3) Size(0x18) ]
	void RegisterTurnBasedMatchInterfaceObject(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct UObject* Object);

	// Object: Function OnlineSubsystemUtils.TurnBasedBlueprintLibrary.GetPlayerDisplayName
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102533df8
	// Return & Params: [ Num(5) Size(0x38) ]
	void GetPlayerDisplayName(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct FString MatchID, int32_t PlayerIndex, struct FString& PlayerDisplayName);

	// Object: Function OnlineSubsystemUtils.TurnBasedBlueprintLibrary.GetMyPlayerIndex
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102534134
	// Return & Params: [ Num(4) Size(0x24) ]
	void GetMyPlayerIndex(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct FString MatchID, int32_t& PlayerIndex);

	// Object: Function OnlineSubsystemUtils.TurnBasedBlueprintLibrary.GetIsMyTurn
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102534308
	// Return & Params: [ Num(4) Size(0x21) ]
	void GetIsMyTurn(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct FString MatchID, bool& bIsMyTurn);
};

// Object: Class OnlineSubsystemUtils.VoipListenerSynthComponent
// Inherited Bytes: 0x820 | Struct Size: 0x890
struct UVoipListenerSynthComponent : USynthComponent {
	// Fields
	char pad_0x820[0x70]; // Offset: 0x820 | Size: 0x70

	// Functions

	// Object: Function OnlineSubsystemUtils.VoipListenerSynthComponent.IsIdling
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1025347ec
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsIdling();
};

