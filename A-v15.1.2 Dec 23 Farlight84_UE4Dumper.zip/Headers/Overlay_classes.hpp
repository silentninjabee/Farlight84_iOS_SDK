#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class Overlay.Overlays
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UOverlays : UObject {
};

// Object: Class Overlay.BasicOverlays
// Inherited Bytes: 0x28 | Struct Size: 0x38
struct UBasicOverlays : UOverlays {
	// Fields
	struct TArray<struct FOverlayItem> Overlays; // Offset: 0x28 | Size: 0x10
};

// Object: Class Overlay.LocalizedOverlays
// Inherited Bytes: 0x28 | Struct Size: 0x80
struct ULocalizedOverlays : UOverlays {
	// Fields
	struct UBasicOverlays* DefaultOverlays; // Offset: 0x28 | Size: 0x8
	struct TMap<struct FString, struct UBasicOverlays*> LocaleToOverlaysMap; // Offset: 0x30 | Size: 0x50
};

