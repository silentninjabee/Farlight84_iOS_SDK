#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class PacketHandler.HandlerComponentFactory
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UHandlerComponentFactory : UObject {
};

// Object: Class PacketHandler.PacketHandlerProfileConfig
// Inherited Bytes: 0x28 | Struct Size: 0x38
struct UPacketHandlerProfileConfig : UObject {
	// Fields
	struct TArray<struct FString> Components; // Offset: 0x28 | Size: 0x10
};

