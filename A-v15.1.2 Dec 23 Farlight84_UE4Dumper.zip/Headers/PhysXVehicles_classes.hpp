#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class PhysXVehicles.WheeledVehicleMovementComponent
// Inherited Bytes: 0x138 | Struct Size: 0x288
struct UWheeledVehicleMovementComponent : UPawnMovementComponent {
	// Fields
	char pad_0x138[0x8]; // Offset: 0x138 | Size: 0x8
	char bDeprecatedSpringOffsetMode : 1; // Offset: 0x140 | Size: 0x1
	char bReverseAsBrake : 1; // Offset: 0x140 | Size: 0x1
	char bUseRVOAvoidance : 1; // Offset: 0x140 | Size: 0x1
	char bRawHandbrakeInput : 1; // Offset: 0x140 | Size: 0x1
	char bRawGearUpInput : 1; // Offset: 0x140 | Size: 0x1
	char bRawGearDownInput : 1; // Offset: 0x140 | Size: 0x1
	char bWasAvoidanceUpdated : 1; // Offset: 0x140 | Size: 0x1
	char pad_0x140_7 : 1; // Offset: 0x140 | Size: 0x1
	char pad_0x141[0x3]; // Offset: 0x141 | Size: 0x3
	float Mass; // Offset: 0x144 | Size: 0x4
	struct TArray<struct FWheelSetup> WheelSetups; // Offset: 0x148 | Size: 0x10
	float DragCoefficient; // Offset: 0x158 | Size: 0x4
	float ChassisWidth; // Offset: 0x15c | Size: 0x4
	float ChassisHeight; // Offset: 0x160 | Size: 0x4
	float DragArea; // Offset: 0x164 | Size: 0x4
	float EstimatedMaxEngineSpeed; // Offset: 0x168 | Size: 0x4
	float MaxEngineRPM; // Offset: 0x16c | Size: 0x4
	float DebugDragMagnitude; // Offset: 0x170 | Size: 0x4
	struct FVector InertiaTensorScale; // Offset: 0x174 | Size: 0xc
	float MinNormalizedTireLoad; // Offset: 0x180 | Size: 0x4
	float MinNormalizedTireLoadFiltered; // Offset: 0x184 | Size: 0x4
	float MaxNormalizedTireLoad; // Offset: 0x188 | Size: 0x4
	float MaxNormalizedTireLoadFiltered; // Offset: 0x18c | Size: 0x4
	float ThresholdLongitudinalSpeed; // Offset: 0x190 | Size: 0x4
	int32_t LowForwardSpeedSubStepCount; // Offset: 0x194 | Size: 0x4
	int32_t HighForwardSpeedSubStepCount; // Offset: 0x198 | Size: 0x4
	char pad_0x19C[0x4]; // Offset: 0x19c | Size: 0x4
	struct TArray<struct UVehicleWheel*> Wheels; // Offset: 0x1a0 | Size: 0x10
	char pad_0x1B0[0x18]; // Offset: 0x1b0 | Size: 0x18
	float RVOAvoidanceRadius; // Offset: 0x1c8 | Size: 0x4
	float RVOAvoidanceHeight; // Offset: 0x1cc | Size: 0x4
	float AvoidanceConsiderationRadius; // Offset: 0x1d0 | Size: 0x4
	float RVOSteeringStep; // Offset: 0x1d4 | Size: 0x4
	float RVOThrottleStep; // Offset: 0x1d8 | Size: 0x4
	int32_t AvoidanceUID; // Offset: 0x1dc | Size: 0x4
	struct FNavAvoidanceMask AvoidanceGroup; // Offset: 0x1e0 | Size: 0x4
	struct FNavAvoidanceMask GroupsToAvoid; // Offset: 0x1e4 | Size: 0x4
	struct FNavAvoidanceMask GroupsToIgnore; // Offset: 0x1e8 | Size: 0x4
	float AvoidanceWeight; // Offset: 0x1ec | Size: 0x4
	struct FVector PendingLaunchVelocity; // Offset: 0x1f0 | Size: 0xc
	struct FReplicatedVehicleState ReplicatedState; // Offset: 0x1fc | Size: 0x14
	char pad_0x210[0x4]; // Offset: 0x210 | Size: 0x4
	float RawSteeringInput; // Offset: 0x214 | Size: 0x4
	float RawThrottleInput; // Offset: 0x218 | Size: 0x4
	float RawBrakeInput; // Offset: 0x21c | Size: 0x4
	float SteeringInput; // Offset: 0x220 | Size: 0x4
	float ThrottleInput; // Offset: 0x224 | Size: 0x4
	float BrakeInput; // Offset: 0x228 | Size: 0x4
	float HandbrakeInput; // Offset: 0x22c | Size: 0x4
	float IdleBrakeInput; // Offset: 0x230 | Size: 0x4
	float StopThreshold; // Offset: 0x234 | Size: 0x4
	float WrongDirectionThreshold; // Offset: 0x238 | Size: 0x4
	struct FVehicleInputRate ThrottleInputRate; // Offset: 0x23c | Size: 0x8
	struct FVehicleInputRate BrakeInputRate; // Offset: 0x244 | Size: 0x8
	struct FVehicleInputRate HandbrakeInputRate; // Offset: 0x24c | Size: 0x8
	struct FVehicleInputRate SteeringInputRate; // Offset: 0x254 | Size: 0x8
	char pad_0x25C[0x24]; // Offset: 0x25c | Size: 0x24
	struct AController* OverrideController; // Offset: 0x280 | Size: 0x8

	// Functions

	// Object: Function PhysXVehicles.WheeledVehicleMovementComponent.SetUseAutoGears
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105ac5c70
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetUseAutoGears(bool bUseAuto);

	// Object: Function PhysXVehicles.WheeledVehicleMovementComponent.SetThrottleInput
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105ac6060
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetThrottleInput(float Throttle);

	// Object: Function PhysXVehicles.WheeledVehicleMovementComponent.SetTargetGear
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105ac5cf8
	// Return & Params: [ Num(2) Size(0x5) ]
	void SetTargetGear(int32_t GearNum, bool bImmediate);

	// Object: Function PhysXVehicles.WheeledVehicleMovementComponent.SetSteeringInput
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105ac5f60
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetSteeringInput(float Steering);

	// Object: Function PhysXVehicles.WheeledVehicleMovementComponent.SetHandbrakeInput
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105ac5ed8
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetHandbrakeInput(bool bNewHandbrake);

	// Object: Function PhysXVehicles.WheeledVehicleMovementComponent.SetGroupsToIgnoreMask
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105ac5820
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetGroupsToIgnoreMask(struct FNavAvoidanceMask& GroupMask);

	// Object: Function PhysXVehicles.WheeledVehicleMovementComponent.SetGroupsToIgnore
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105ac58a8
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetGroupsToIgnore(int32_t GroupFlags);

	// Object: Function PhysXVehicles.WheeledVehicleMovementComponent.SetGroupsToAvoidMask
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105ac5928
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetGroupsToAvoidMask(struct FNavAvoidanceMask& GroupMask);

	// Object: Function PhysXVehicles.WheeledVehicleMovementComponent.SetGroupsToAvoid
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105ac59b0
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetGroupsToAvoid(int32_t GroupFlags);

	// Object: Function PhysXVehicles.WheeledVehicleMovementComponent.SetGearUp
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105ac5e50
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetGearUp(bool bNewGearUp);

	// Object: Function PhysXVehicles.WheeledVehicleMovementComponent.SetGearDown
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105ac5dc8
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetGearDown(bool bNewGearDown);

	// Object: Function PhysXVehicles.WheeledVehicleMovementComponent.SetBrakeInput
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105ac5fe0
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetBrakeInput(float Brake);

	// Object: Function PhysXVehicles.WheeledVehicleMovementComponent.SetAvoidanceGroupMask
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105ac5a30
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetAvoidanceGroupMask(struct FNavAvoidanceMask& GroupMask);

	// Object: Function PhysXVehicles.WheeledVehicleMovementComponent.SetAvoidanceGroup
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105ac5ab8
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetAvoidanceGroup(int32_t GroupFlags);

	// Object: Function PhysXVehicles.WheeledVehicleMovementComponent.SetAvoidanceEnabled
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105ac5798
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetAvoidanceEnabled(bool bEnable);

	// Object: Function PhysXVehicles.WheeledVehicleMovementComponent.ServerUpdateState
	// Flags: [Net|NetReliableNative|Event|Protected|NetServer|NetValidate]
	// Offset: 0x105ac55a4
	// Return & Params: [ Num(5) Size(0x14) ]
	void ServerUpdateState(float InSteeringInput, float InThrottleInput, float InBrakeInput, float InHandbrakeInput, int32_t CurrentGear);

	// Object: Function PhysXVehicles.WheeledVehicleMovementComponent.GetUseAutoGears
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105ac5b38
	// Return & Params: [ Num(1) Size(0x1) ]
	bool GetUseAutoGears();

	// Object: Function PhysXVehicles.WheeledVehicleMovementComponent.GetTargetGear
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105ac5b6c
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetTargetGear();

	// Object: Function PhysXVehicles.WheeledVehicleMovementComponent.GetForwardSpeed
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105ac5c3c
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetForwardSpeed();

	// Object: Function PhysXVehicles.WheeledVehicleMovementComponent.GetEngineRotationSpeed
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105ac5c08
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetEngineRotationSpeed();

	// Object: Function PhysXVehicles.WheeledVehicleMovementComponent.GetEngineMaxRotationSpeed
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105ac5bd4
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetEngineMaxRotationSpeed();

	// Object: Function PhysXVehicles.WheeledVehicleMovementComponent.GetCurrentGear
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105ac5ba0
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetCurrentGear();
};

// Object: Class PhysXVehicles.SimpleWheeledVehicleMovementComponent
// Inherited Bytes: 0x288 | Struct Size: 0x288
struct USimpleWheeledVehicleMovementComponent : UWheeledVehicleMovementComponent {
	// Functions

	// Object: Function PhysXVehicles.SimpleWheeledVehicleMovementComponent.SetSteerAngle
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105ac3b34
	// Return & Params: [ Num(2) Size(0x8) ]
	void SetSteerAngle(float SteerAngle, int32_t WheelIndex);

	// Object: Function PhysXVehicles.SimpleWheeledVehicleMovementComponent.SetDriveTorque
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105ac3c00
	// Return & Params: [ Num(2) Size(0x8) ]
	void SetDriveTorque(float DriveTorque, int32_t WheelIndex);

	// Object: Function PhysXVehicles.SimpleWheeledVehicleMovementComponent.SetBrakeTorque
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105ac3ccc
	// Return & Params: [ Num(2) Size(0x8) ]
	void SetBrakeTorque(float BrakeTorque, int32_t WheelIndex);
};

// Object: Class PhysXVehicles.TireConfig
// Inherited Bytes: 0x30 | Struct Size: 0x50
struct UTireConfig : UDataAsset {
	// Fields
	float FrictionScale; // Offset: 0x30 | Size: 0x4
	char pad_0x34[0x4]; // Offset: 0x34 | Size: 0x4
	struct TArray<struct FTireConfigMaterialFriction> TireFrictionScales; // Offset: 0x38 | Size: 0x10
	char pad_0x48[0x8]; // Offset: 0x48 | Size: 0x8
};

// Object: Class PhysXVehicles.VehicleAnimInstance
// Inherited Bytes: 0x270 | Struct Size: 0x980
struct UVehicleAnimInstance : UAnimInstance {
	// Fields
	char pad_0x270[0x700]; // Offset: 0x270 | Size: 0x700
	struct UWheeledVehicleMovementComponent* WheeledVehicleMovementComponent; // Offset: 0x970 | Size: 0x8
	char pad_0x978[0x8]; // Offset: 0x978 | Size: 0x8

	// Functions

	// Object: Function PhysXVehicles.VehicleAnimInstance.GetVehicle
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105ac4618
	// Return & Params: [ Num(1) Size(0x8) ]
	struct AWheeledVehicle* GetVehicle();
};

// Object: Class PhysXVehicles.VehicleWheel
// Inherited Bytes: 0x28 | Struct Size: 0xf0
struct UVehicleWheel : UObject {
	// Fields
	struct UStaticMesh* CollisionMesh; // Offset: 0x28 | Size: 0x8
	bool bDontCreateShape; // Offset: 0x30 | Size: 0x1
	bool bAutoAdjustCollisionSize; // Offset: 0x31 | Size: 0x1
	char pad_0x32[0x2]; // Offset: 0x32 | Size: 0x2
	struct FVector Offset; // Offset: 0x34 | Size: 0xc
	float ShapeRadius; // Offset: 0x40 | Size: 0x4
	float ShapeWidth; // Offset: 0x44 | Size: 0x4
	float Mass; // Offset: 0x48 | Size: 0x4
	float DampingRate; // Offset: 0x4c | Size: 0x4
	float SteerAngle; // Offset: 0x50 | Size: 0x4
	bool bAffectedByHandbrake; // Offset: 0x54 | Size: 0x1
	char pad_0x55[0x3]; // Offset: 0x55 | Size: 0x3
	struct UTireType* TireType; // Offset: 0x58 | Size: 0x8
	struct UTireConfig* TireConfig; // Offset: 0x60 | Size: 0x8
	float LatStiffMaxLoad; // Offset: 0x68 | Size: 0x4
	float LatStiffValue; // Offset: 0x6c | Size: 0x4
	float LongStiffValue; // Offset: 0x70 | Size: 0x4
	float SuspensionForceOffset; // Offset: 0x74 | Size: 0x4
	float SuspensionMaxRaise; // Offset: 0x78 | Size: 0x4
	float SuspensionMaxDrop; // Offset: 0x7c | Size: 0x4
	float SuspensionNaturalFrequency; // Offset: 0x80 | Size: 0x4
	float SuspensionDampingRatio; // Offset: 0x84 | Size: 0x4
	enum class EWheelSweepType SweepType; // Offset: 0x88 | Size: 0x1
	char pad_0x89[0x3]; // Offset: 0x89 | Size: 0x3
	float MaxBrakeTorque; // Offset: 0x8c | Size: 0x4
	float MaxHandBrakeTorque; // Offset: 0x90 | Size: 0x4
	char pad_0x94[0x4]; // Offset: 0x94 | Size: 0x4
	struct UWheeledVehicleMovementComponent* VehicleSim; // Offset: 0x98 | Size: 0x8
	int32_t WheelIndex; // Offset: 0xa0 | Size: 0x4
	float DebugLongSlip; // Offset: 0xa4 | Size: 0x4
	float DebugLatSlip; // Offset: 0xa8 | Size: 0x4
	float DebugNormalizedTireLoad; // Offset: 0xac | Size: 0x4
	char pad_0xB0[0x4]; // Offset: 0xb0 | Size: 0x4
	float DebugWheelTorque; // Offset: 0xb4 | Size: 0x4
	float DebugLongForce; // Offset: 0xb8 | Size: 0x4
	float DebugLatForce; // Offset: 0xbc | Size: 0x4
	struct FVector Location; // Offset: 0xc0 | Size: 0xc
	struct FVector OldLocation; // Offset: 0xcc | Size: 0xc
	struct FVector Velocity; // Offset: 0xd8 | Size: 0xc
	char pad_0xE4[0xc]; // Offset: 0xe4 | Size: 0xc

	// Functions

	// Object: Function PhysXVehicles.VehicleWheel.IsInAir
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105ac4b70
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsInAir();

	// Object: Function PhysXVehicles.VehicleWheel.GetSuspensionOffset
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105ac4ba4
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetSuspensionOffset();

	// Object: Function PhysXVehicles.VehicleWheel.GetSteerAngle
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105ac4c0c
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetSteerAngle();

	// Object: Function PhysXVehicles.VehicleWheel.GetRotationAngle
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105ac4bd8
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetRotationAngle();
};

// Object: Class PhysXVehicles.WheeledVehicle
// Inherited Bytes: 0x288 | Struct Size: 0x298
struct AWheeledVehicle : APawn {
	// Fields
	struct USkeletalMeshComponent* Mesh; // Offset: 0x288 | Size: 0x8
	struct UWheeledVehicleMovementComponent* VehicleMovement; // Offset: 0x290 | Size: 0x8
};

// Object: Class PhysXVehicles.WheeledVehicleMovementComponent4W
// Inherited Bytes: 0x288 | Struct Size: 0x400
struct UWheeledVehicleMovementComponent4W : UWheeledVehicleMovementComponent {
	// Fields
	struct FVehicleEngineData EngineSetup; // Offset: 0x288 | Size: 0xa0
	struct FVehicleDifferential4WData DifferentialSetup; // Offset: 0x328 | Size: 0x1c
	float AckermannAccuracy; // Offset: 0x344 | Size: 0x4
	struct FVehicleTransmissionData TransmissionSetup; // Offset: 0x348 | Size: 0x30
	struct FRuntimeFloatCurve SteeringCurve; // Offset: 0x378 | Size: 0x88
};

