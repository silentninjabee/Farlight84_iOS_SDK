#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class RichtapToolsLib.RichtapClip
// Inherited Bytes: 0x28 | Struct Size: 0x50
struct URichtapClip : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
	struct FString ClipData; // Offset: 0x30 | Size: 0x10
	char pad_0x40[0x10]; // Offset: 0x40 | Size: 0x10
};

