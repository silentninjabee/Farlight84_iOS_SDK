#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class Slate.ButtonWidgetStyle
// Inherited Bytes: 0x30 | Struct Size: 0x410
struct UButtonWidgetStyle : USlateWidgetStyleContainerBase {
	// Fields
	struct FButtonStyle ButtonStyle; // Offset: 0x30 | Size: 0x3e0
};

// Object: Class Slate.CheckBoxWidgetStyle
// Inherited Bytes: 0x30 | Struct Size: 0x8d0
struct UCheckBoxWidgetStyle : USlateWidgetStyleContainerBase {
	// Fields
	struct FCheckBoxStyle CheckBoxStyle; // Offset: 0x30 | Size: 0x8a0
};

// Object: Class Slate.ComboBoxWidgetStyle
// Inherited Bytes: 0x30 | Struct Size: 0x650
struct UComboBoxWidgetStyle : USlateWidgetStyleContainerBase {
	// Fields
	struct FComboBoxStyle ComboBoxStyle; // Offset: 0x30 | Size: 0x620
};

// Object: Class Slate.ComboButtonWidgetStyle
// Inherited Bytes: 0x30 | Struct Size: 0x610
struct UComboButtonWidgetStyle : USlateWidgetStyleContainerBase {
	// Fields
	struct FComboButtonStyle ComboButtonStyle; // Offset: 0x30 | Size: 0x5e0
};

// Object: Class Slate.EditableTextBoxWidgetStyle
// Inherited Bytes: 0x30 | Struct Size: 0xcc0
struct UEditableTextBoxWidgetStyle : USlateWidgetStyleContainerBase {
	// Fields
	struct FEditableTextBoxStyle EditableTextBoxStyle; // Offset: 0x30 | Size: 0xc90
};

// Object: Class Slate.EditableTextWidgetStyle
// Inherited Bytes: 0x30 | Struct Size: 0x360
struct UEditableTextWidgetStyle : USlateWidgetStyleContainerBase {
	// Fields
	struct FEditableTextStyle EditableTextStyle; // Offset: 0x30 | Size: 0x330
};

// Object: Class Slate.ProgressWidgetStyle
// Inherited Bytes: 0x30 | Struct Size: 0x2e0
struct UProgressWidgetStyle : USlateWidgetStyleContainerBase {
	// Fields
	struct FProgressBarStyle ProgressBarStyle; // Offset: 0x30 | Size: 0x2b0
};

// Object: Class Slate.ScrollBarWidgetStyle
// Inherited Bytes: 0x30 | Struct Size: 0x820
struct UScrollBarWidgetStyle : USlateWidgetStyleContainerBase {
	// Fields
	struct FScrollBarStyle ScrollBarStyle; // Offset: 0x30 | Size: 0x7f0
};

// Object: Class Slate.ScrollBoxWidgetStyle
// Inherited Bytes: 0x30 | Struct Size: 0x3c0
struct UScrollBoxWidgetStyle : USlateWidgetStyleContainerBase {
	// Fields
	struct FScrollBoxStyle ScrollBoxStyle; // Offset: 0x30 | Size: 0x390
};

// Object: Class Slate.SlateSettings
// Inherited Bytes: 0x28 | Struct Size: 0x30
struct USlateSettings : UObject {
	// Fields
	bool bExplicitCanvasChildZOrder; // Offset: 0x28 | Size: 0x1
	char pad_0x29[0x7]; // Offset: 0x29 | Size: 0x7
};

// Object: Class Slate.SpinBoxWidgetStyle
// Inherited Bytes: 0x30 | Struct Size: 0x4e0
struct USpinBoxWidgetStyle : USlateWidgetStyleContainerBase {
	// Fields
	struct FSpinBoxStyle SpinBoxStyle; // Offset: 0x30 | Size: 0x4b0
};

// Object: Class Slate.TextBlockWidgetStyle
// Inherited Bytes: 0x30 | Struct Size: 0x490
struct UTextBlockWidgetStyle : USlateWidgetStyleContainerBase {
	// Fields
	struct FTextBlockStyle TextBlockStyle; // Offset: 0x30 | Size: 0x460
};

// Object: Class Slate.ToolMenuBase
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UToolMenuBase : UObject {
};

