#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass SolarGameInstance.SolarGameInstance_C
// Inherited Bytes: 0xa78 | Struct Size: 0xa90
struct USolarGameInstance_C : USolarGameInstanceBase {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0xa78 | Size: 0x8
	struct FMulticastInlineDelegate OnBroadcastModeChanged; // Offset: 0xa80 | Size: 0x10

	// Functions

	// Object: DelegateFunction SolarGameInstance.SolarGameInstance_C.OnWifiStateChanged_0E1F56DF534E703DECEC99AD8A936086
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015bb124
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnWifiStateChanged_0E1F56DF534E703DECEC99AD8A936086(bool bEnabled);

	// Object: Function SolarGameInstance.SolarGameInstance_C.ReportLoadingInfoToBI
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x1015d02c4
	// Return & Params: [ Num(3) Size(0x15) ]
	void ReportLoadingInfoToBI(struct TArray<struct FString>& LoadingInfo, float LoadingTime, bool bIsFinished);

	// Object: Function SolarGameInstance.SolarGameInstance_C.LuaGetBroadcastPlayerNameCopy
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103a48564
	// Return & Params: [ Num(2) Size(0x20) ]
	void LuaGetBroadcastPlayerNameCopy(struct FString SolarPlayerID, struct FString& BroadcastPlayerName);

	// Object: Function SolarGameInstance.SolarGameInstance_C.ExecuteChangeAudioModeLuaCall
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x1015d02c4
	// Return & Params: [ Num(1) Size(0x1) ]
	void ExecuteChangeAudioModeLuaCall(bool bTurnOn);

	// Object: Function SolarGameInstance.SolarGameInstance_C.ShutDownLimSdk
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x1015d02c4
	// Return & Params: [ Num(0) Size(0x0) ]
	void ShutDownLimSdk();

	// Object: Function SolarGameInstance.SolarGameInstance_C.HandleNetworkError
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x1015d02c4
	// Return & Params: [ Num(2) Size(0x2) ]
	void HandleNetworkError(enum class ENetworkFailure FailureType, bool bIsServer);

	// Object: Function SolarGameInstance.SolarGameInstance_C.SolarGM_AddWeaponExpLua
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x1015d02c4
	// Return & Params: [ Num(2) Size(0x8) ]
	void SolarGM_AddWeaponExpLua(int32_t weaponid, int32_t count);

	// Object: Function SolarGameInstance.SolarGameInstance_C.RegisterNetworkManager
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x1015d02c4
	// Return & Params: [ Num(0) Size(0x0) ]
	void RegisterNetworkManager();

	// Object: Function SolarGameInstance.SolarGameInstance_C.ReceiveShutdown
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x1015d02c4
	// Return & Params: [ Num(0) Size(0x0) ]
	void ReceiveShutdown();

	// Object: Function SolarGameInstance.SolarGameInstance_C.LuaInitGameFrameWork
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x1015d02c4
	// Return & Params: [ Num(0) Size(0x0) ]
	void LuaInitGameFrameWork();

	// Object: Function SolarGameInstance.SolarGameInstance_C.InitLuaClasses
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x1015d02c4
	// Return & Params: [ Num(0) Size(0x0) ]
	void InitLuaClasses();

	// Object: Function SolarGameInstance.SolarGameInstance_C.SolarGM_TransmitGMLua
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x1015d02c4
	// Return & Params: [ Num(2) Size(0x20) ]
	void SolarGM_TransmitGMLua(struct FString playerName, struct TArray<struct FString>& GmArray);

	// Object: Function SolarGameInstance.SolarGameInstance_C.ShutdownAnoSDK
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x1015d02c4
	// Return & Params: [ Num(0) Size(0x0) ]
	void ShutdownAnoSDK();

	// Object: Function SolarGameInstance.SolarGameInstance_C.ShutDownPCSDK
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x1015d02c4
	// Return & Params: [ Num(0) Size(0x0) ]
	void ShutDownPCSDK();

	// Object: Function SolarGameInstance.SolarGameInstance_C.ExecuteBackKeyLuaCall
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x1015d02c4
	// Return & Params: [ Num(0) Size(0x0) ]
	void ExecuteBackKeyLuaCall();

	// Object: Function SolarGameInstance.SolarGameInstance_C.AsyncDownLoadConfigFile
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x1015d02c4
	// Return & Params: [ Num(2) Size(0x18) ]
	void AsyncDownLoadConfigFile(int64_t TaskID, struct FString URL);

	// Object: Function SolarGameInstance.SolarGameInstance_C.OnScopeChanged
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x1015d02c4
	// Return & Params: [ Num(2) Size(0x2) ]
	void OnScopeChanged(enum class EScope InLastScope, enum class EScope InCurScope);

	// Object: Function SolarGameInstance.SolarGameInstance_C.LuaGetBroadcastHeroNameCopy
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103a48564
	// Return & Params: [ Num(2) Size(0x20) ]
	void LuaGetBroadcastHeroNameCopy(struct FString SolarPlayerID, struct FString& BroadcastPlayerName);

	// Object: Function SolarGameInstance.SolarGameInstance_C.GoHomeLuaCall
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x1015d02c4
	// Return & Params: [ Num(0) Size(0x0) ]
	void GoHomeLuaCall();

	// Object: Function SolarGameInstance.SolarGameInstance_C.SolarGM_LobbyLua
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x1015d02c4
	// Return & Params: [ Num(2) Size(0x20) ]
	void SolarGM_LobbyLua(struct FString CmdName, struct TArray<struct FString>& Params);

	// Object: Function SolarGameInstance.SolarGameInstance_C.CheckSavedDirFiles
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x1015d02c4
	// Return & Params: [ Num(1) Size(0x10) ]
	void CheckSavedDirFiles(struct TArray<struct FString>& Files);

	// Object: Function SolarGameInstance.SolarGameInstance_C.LuaStartGameFrameWork
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x1015d02c4
	// Return & Params: [ Num(0) Size(0x0) ]
	void LuaStartGameFrameWork();

	// Object: Function SolarGameInstance.SolarGameInstance_C.SolarGM_AddItemLua
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x1015d02c4
	// Return & Params: [ Num(2) Size(0x8) ]
	void SolarGM_AddItemLua(int32_t ItemID, int32_t count);

	// Object: Function SolarGameInstance.SolarGameInstance_C.OnDisconnect
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x1015d02c4
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnDisconnect();

	// Object: Function SolarGameInstance.SolarGameInstance_C.LuaOnBroadcastModeChanged
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103a48564
	// Return & Params: [ Num(0) Size(0x0) ]
	void LuaOnBroadcastModeChanged();

	// Object: Function SolarGameInstance.SolarGameInstance_C.LuaGetBroadcastPlayerName
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x1015d02c4
	// Return & Params: [ Num(2) Size(0x20) ]
	void LuaGetBroadcastPlayerName(struct FString SolarPlayerID, struct FString& BroadcastPlayerName);

	// Object: Function SolarGameInstance.SolarGameInstance_C.LuaGetBroadcastHeroName
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x1015d02c4
	// Return & Params: [ Num(2) Size(0x20) ]
	void LuaGetBroadcastHeroName(struct FString SolarPlayerID, struct FString& BroadcastPlayerName);

	// Object: Function SolarGameInstance.SolarGameInstance_C.SolarGM_TestCrashWithBP
	// Flags: [Exec|Event|Public|BlueprintEvent]
	// Offset: 0x103a48564
	// Return & Params: [ Num(0) Size(0x0) ]
	void SolarGM_TestCrashWithBP();

	// Object: Function SolarGameInstance.SolarGameInstance_C.SolarGM_TestEnsureMsgWithBP
	// Flags: [Exec|Event|Public|BlueprintEvent]
	// Offset: 0x103a48564
	// Return & Params: [ Num(0) Size(0x0) ]
	void SolarGM_TestEnsureMsgWithBP();

	// Object: Function SolarGameInstance.SolarGameInstance_C.ExecuteUbergraph_SolarGameInstance
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103a48564
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_SolarGameInstance(int32_t EntryPoint);

	// Object: Function SolarGameInstance.SolarGameInstance_C.OnBroadcastModeChanged__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103a48564
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnBroadcastModeChanged__DelegateSignature();
};

