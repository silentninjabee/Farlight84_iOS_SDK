#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class SolarlandResUpdate.SolarlandResUpdater
// Inherited Bytes: 0x28 | Struct Size: 0xe0
struct USolarlandResUpdater : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
	struct FDelegate OnPatchPrompt; // Offset: 0x30 | Size: 0x10
	struct FDelegate OnPatchComplete; // Offset: 0x40 | Size: 0x10
	struct FDelegate OnPatchFailed; // Offset: 0x50 | Size: 0x10
	struct FDelegate OnCDNDownloadFailed; // Offset: 0x60 | Size: 0x10
	struct FDelegate OnPatchProgress; // Offset: 0x70 | Size: 0x10
	struct FDelegate OnServerClose; // Offset: 0x80 | Size: 0x10
	struct FDelegate OnBackdoorComplete; // Offset: 0x90 | Size: 0x10
	struct FDelegate OnBackdoorFaild; // Offset: 0xa0 | Size: 0x10
	struct FDelegate OnBackdoorProgress; // Offset: 0xb0 | Size: 0x10
	struct FDelegate OnAnnouncementGet; // Offset: 0xc0 | Size: 0x10
	struct FDelegate OnAnnouncementGetFail; // Offset: 0xd0 | Size: 0x10
};

// Object: Class SolarlandResUpdate.DownloadFileTask
// Inherited Bytes: 0x28 | Struct Size: 0xc8
struct UDownloadFileTask : UObject {
	// Fields
	struct FMulticastInlineDelegate OnDownloadComplete; // Offset: 0x28 | Size: 0x10
	struct FMulticastInlineDelegate OnDownloadProgress; // Offset: 0x38 | Size: 0x10
	struct FMulticastInlineDelegate OnDownloadFailed; // Offset: 0x48 | Size: 0x10
	char pad_0x58[0x70]; // Offset: 0x58 | Size: 0x70

	// Functions

	// Object: Function SolarlandResUpdate.DownloadFileTask.StartDownload
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1036b2a0c
	// Return & Params: [ Num(0) Size(0x0) ]
	void StartDownload();

	// Object: Function SolarlandResUpdate.DownloadFileTask.SetSaveToFile
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1036b2900
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetSaveToFile(bool InSet);

	// Object: Function SolarlandResUpdate.DownloadFileTask.SetForceRedownload
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1036b2984
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetForceRedownload(bool inForceRedownload);

	// Object: Function SolarlandResUpdate.DownloadFileTask.GetUrl
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1036b2880
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetUrl();

	// Object: Function SolarlandResUpdate.DownloadFileTask.CreateNoFile
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1036b2a20
	// Return & Params: [ Num(3) Size(0x20) ]
	struct UDownloadFileTask* CreateNoFile(struct FString URL, bool bByChunk);

	// Object: Function SolarlandResUpdate.DownloadFileTask.Create
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1036b2b00
	// Return & Params: [ Num(6) Size(0x40) ]
	struct UDownloadFileTask* Create(struct FString URL, struct FString FileDirectory, struct FString Filename, bool bByChunk, bool bForceWrite);
};

