#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct Solarland.ScreenshotConfig
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FScreenshotConfig {
	// Fields
	bool EnableOnCurrentReportGameCheating; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	int32_t MaxCountInRound; // Offset: 0x4 | Size: 0x4
	struct FString ScreenshotMoment; // Offset: 0x8 | Size: 0x10
	int32_t ScreenshotInterval; // Offset: 0x18 | Size: 0x4
	int32_t ScreenshotWidth; // Offset: 0x1c | Size: 0x4
	int32_t ScreenshotQuality; // Offset: 0x20 | Size: 0x4
	char pad_0x24[0x4]; // Offset: 0x24 | Size: 0x4
	struct FString ImageSaveType; // Offset: 0x28 | Size: 0x10
	struct FString ScreenshotMode; // Offset: 0x38 | Size: 0x10
	int32_t ImageMaxSize; // Offset: 0x48 | Size: 0x4
	char pad_0x4C[0x4]; // Offset: 0x4c | Size: 0x4
};

// Object: ScriptStruct Solarland.AntiCheatSetting
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FAntiCheatSetting {
	// Fields
	int64_t ID; // Offset: 0x0 | Size: 0x8
	int64_t ValueType; // Offset: 0x8 | Size: 0x8
	double ValueStart; // Offset: 0x10 | Size: 0x8
	double ValueEnd; // Offset: 0x18 | Size: 0x8
	int64_t Tolerance; // Offset: 0x20 | Size: 0x8
	int64_t ProbeInterval; // Offset: 0x28 | Size: 0x8
	struct FString VariableName; // Offset: 0x30 | Size: 0x10
};

// Object: ScriptStruct Solarland.RegistedActorContainer
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FRegistedActorContainer {
	// Fields
	char pad_0x0[0x50]; // Offset: 0x0 | Size: 0x50
};

// Object: ScriptStruct Solarland.LiveWatchOnlyMsg
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FLiveWatchOnlyMsg {
	// Fields
	struct FString BattleID; // Offset: 0x0 | Size: 0x10
	struct FString FromPlayerID; // Offset: 0x10 | Size: 0x10
	struct FString ToPlayerID; // Offset: 0x20 | Size: 0x10
	struct FString Content; // Offset: 0x30 | Size: 0x10
};

// Object: ScriptStruct Solarland.GameStartConditionList
// Inherited Bytes: 0x0 | Struct Size: 0x58
struct FGameStartConditionList {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
	struct FGameplayTagContainer ServerStartConditionList; // Offset: 0x8 | Size: 0x20
	struct FGameplayTagContainer ClientStartConditionList; // Offset: 0x28 | Size: 0x20
	struct AGameStateBase* Owner; // Offset: 0x48 | Size: 0x8
	char pad_0x50[0x8]; // Offset: 0x50 | Size: 0x8
};

// Object: ScriptStruct Solarland.PrePooledBundle
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FPrePooledBundle {
	// Fields
	struct FName ClassPath; // Offset: 0x0 | Size: 0x8
	int32_t Number; // Offset: 0x8 | Size: 0x4
	bool bNeedOnClient; // Offset: 0xc | Size: 0x1
	bool bNeedOnServer; // Offset: 0xd | Size: 0x1
	char pad_0xE[0x2]; // Offset: 0xe | Size: 0x2
};

// Object: ScriptStruct Solarland.CustomRoomData
// Inherited Bytes: 0x0 | Struct Size: 0xd8
struct FCustomRoomData {
	// Fields
	struct FString Name; // Offset: 0x0 | Size: 0x10
	int64_t MinPlayerLimit; // Offset: 0x10 | Size: 0x8
	int64_t MaxPlayerLimit; // Offset: 0x18 | Size: 0x8
	struct FString OwnerID; // Offset: 0x20 | Size: 0x10
	struct FString Passwd; // Offset: 0x30 | Size: 0x10
	int32_t LevelLimit; // Offset: 0x40 | Size: 0x4
	char pad_0x44[0x4]; // Offset: 0x44 | Size: 0x4
	int64_t ShowID; // Offset: 0x48 | Size: 0x8
	int64_t MaxOBPlayerLimit; // Offset: 0x50 | Size: 0x8
	bool bIsEnabledSwapPos; // Offset: 0x58 | Size: 0x1
	bool bIsEnabledInvite; // Offset: 0x59 | Size: 0x1
	bool bIsEnableTeamJoin; // Offset: 0x5a | Size: 0x1
	enum class ESCRoomType RoomType; // Offset: 0x5b | Size: 0x1
	struct FTournamentData TournamentData; // Offset: 0x5c | Size: 0x10
	int32_t RewardPoolID; // Offset: 0x6c | Size: 0x4
	int32_t RewardPoolPrizeType; // Offset: 0x70 | Size: 0x4
	char pad_0x74[0x4]; // Offset: 0x74 | Size: 0x4
	struct FCustomServerData CustomServerData; // Offset: 0x78 | Size: 0x58
	int32_t KeepMatchTime; // Offset: 0xd0 | Size: 0x4
	char pad_0xD4[0x4]; // Offset: 0xd4 | Size: 0x4
};

// Object: ScriptStruct Solarland.CustomServerData
// Inherited Bytes: 0x0 | Struct Size: 0x58
struct FCustomServerData {
	// Fields
	struct FString ID; // Offset: 0x0 | Size: 0x10
	int32_t ConfigID; // Offset: 0x10 | Size: 0x4
	char pad_0x14[0x4]; // Offset: 0x14 | Size: 0x4
	struct TArray<int32_t> WeaponBlacklist; // Offset: 0x18 | Size: 0x10
	struct TArray<int32_t> WeaponTypeBlacklist; // Offset: 0x28 | Size: 0x10
	struct TArray<int32_t> VehicleTypeBlacklist; // Offset: 0x38 | Size: 0x10
	struct TArray<int32_t> VehicleClassBlacklist; // Offset: 0x48 | Size: 0x10
};

// Object: ScriptStruct Solarland.TournamentData
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FTournamentData {
	// Fields
	int32_t StartTime; // Offset: 0x0 | Size: 0x4
	int32_t DelayTime; // Offset: 0x4 | Size: 0x4
	int32_t Turn; // Offset: 0x8 | Size: 0x4
	enum class ESCTournamentType TournamentType; // Offset: 0xc | Size: 0x1
	char pad_0xD[0x3]; // Offset: 0xd | Size: 0x3
};

// Object: ScriptStruct Solarland.KnockoutParams
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FKnockoutParams {
	// Fields
	float KnockoutKillPoint; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct TArray<float> KnockoutRankPoints; // Offset: 0x8 | Size: 0x10
	float KnockoutDamagePoint; // Offset: 0x18 | Size: 0x4
	float KnockoutDamageTakenPoint; // Offset: 0x1c | Size: 0x4
	float ScalarParam; // Offset: 0x20 | Size: 0x4
	char pad_0x24[0x4]; // Offset: 0x24 | Size: 0x4
};

// Object: ScriptStruct Solarland.SCMRankData
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FSCMRankData {
	// Fields
	struct FString HostID; // Offset: 0x0 | Size: 0x10
	int32_t Rank; // Offset: 0x10 | Size: 0x4
	float Value; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct Solarland.SCMRankInfo
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FSCMRankInfo {
	// Fields
	struct FString RankName; // Offset: 0x0 | Size: 0x10
	enum class ESCMDataRankType RankType; // Offset: 0x10 | Size: 0x1
	enum class ESCMHostType HostType; // Offset: 0x11 | Size: 0x1
	char pad_0x12[0x6]; // Offset: 0x12 | Size: 0x6
};

// Object: ScriptStruct Solarland.StartRecordingParams
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FStartRecordingParams {
	// Fields
	bool bWithLevelStreamingFixes; // Offset: 0x0 | Size: 0x1
	bool bEnableCheckpoint; // Offset: 0x1 | Size: 0x1
	char pad_0x2[0x2]; // Offset: 0x2 | Size: 0x2
	uint32_t RecordHz; // Offset: 0x4 | Size: 0x4
	float CheckpointInterval; // Offset: 0x8 | Size: 0x4
	float ChunkInterval; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct Solarland.HighlightReportData
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FHighlightReportData {
	// Fields
	int32_t Source; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct FString BattleID; // Offset: 0x8 | Size: 0x10
	struct FString MapID; // Offset: 0x18 | Size: 0x10
	int32_t MatchRanking; // Offset: 0x28 | Size: 0x4
	int32_t Rank; // Offset: 0x2c | Size: 0x4
	int32_t KillNum; // Offset: 0x30 | Size: 0x4
	char pad_0x34[0x4]; // Offset: 0x34 | Size: 0x4
	struct FString HighestRating; // Offset: 0x38 | Size: 0x10
	bool bIsInterrupt; // Offset: 0x48 | Size: 0x1
	char pad_0x49[0x7]; // Offset: 0x49 | Size: 0x7
};

// Object: ScriptStruct Solarland.AddMultiplePassMaterialChangeParams
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FAddMultiplePassMaterialChangeParams {
	// Fields
	struct FGameplayTag PriorityTag; // Offset: 0x0 | Size: 0x8
	enum class EMaterialChangeConflictResolveStrategy ResolveStrategy; // Offset: 0x8 | Size: 0x1
	enum class EMultiplePassMaterialChangeCompatibilityMode CompatibilityMode; // Offset: 0x9 | Size: 0x1
	char pad_0xA[0x6]; // Offset: 0xa | Size: 0x6
	struct FGameplayTagContainer SpecifiedPriorityTags; // Offset: 0x10 | Size: 0x20
	char bNeedMultiplePass : 1; // Offset: 0x30 | Size: 0x1
	char bForceFrontFaceCull : 1; // Offset: 0x30 | Size: 0x1
	char bIgnoreTranslucentSection : 1; // Offset: 0x30 | Size: 0x1
	char bIgnoreMaskedSection : 1; // Offset: 0x30 | Size: 0x1
	char bTreatAsBackgroundForOcclusion : 1; // Offset: 0x30 | Size: 0x1
	char bUseAsOccluder : 1; // Offset: 0x30 | Size: 0x1
	char bIgnoreOcclusionCull : 1; // Offset: 0x30 | Size: 0x1
	char bRenderMainPassStencil : 1; // Offset: 0x30 | Size: 0x1
	char bSetTranslucencySortPriorityOnly : 1; // Offset: 0x31 | Size: 0x1
	char bRenderCustomDepth : 1; // Offset: 0x31 | Size: 0x1
	char pad_0x31_2 : 6; // Offset: 0x31 | Size: 0x1
	char pad_0x32[0x2]; // Offset: 0x32 | Size: 0x2
	int32_t MainPassDepthStencilValue; // Offset: 0x34 | Size: 0x4
	int32_t TranslucencySortPriority; // Offset: 0x38 | Size: 0x4
	int32_t CustomDepthStencilValue; // Offset: 0x3c | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarClientAdjustPositionInfo
// Inherited Bytes: 0x0 | Struct Size: 0x38
struct FSolarClientAdjustPositionInfo {
	// Fields
	char pad_0x0[0x20]; // Offset: 0x0 | Size: 0x20
	struct UPrimitiveComponent* NewBase; // Offset: 0x20 | Size: 0x8
	char pad_0x28[0x10]; // Offset: 0x28 | Size: 0x10
};

// Object: ScriptStruct Solarland.CustomJumpParams
// Inherited Bytes: 0x0 | Struct Size: 0x98
struct FCustomJumpParams {
	// Fields
	float JumpHeight; // Offset: 0x0 | Size: 0x4
	float JumpTime; // Offset: 0x4 | Size: 0x4
	float JumpDelay; // Offset: 0x8 | Size: 0x4
	bool bEnableLateralSpeedAdjust; // Offset: 0xc | Size: 0x1
	char pad_0xD[0x3]; // Offset: 0xd | Size: 0x3
	struct FRuntimeFloatCurve LateralSpeedAdjustCurve; // Offset: 0x10 | Size: 0x88
};

// Object: ScriptStruct Solarland.SolarItemData
// Inherited Bytes: 0xc | Struct Size: 0xb8
struct FSolarItemData : FFastArraySerializerItem {
	// Fields
	int32_t ItemID; // Offset: 0xc | Size: 0x4
	int64_t ThisID; // Offset: 0x10 | Size: 0x8
	struct FString Name; // Offset: 0x18 | Size: 0x10
	struct FString Icon; // Offset: 0x28 | Size: 0x10
	struct FString Info; // Offset: 0x38 | Size: 0x10
	int32_t count; // Offset: 0x48 | Size: 0x4
	enum class EItemType ItemType; // Offset: 0x4c | Size: 0x4
	int32_t Quality; // Offset: 0x50 | Size: 0x4
	int32_t MaxPile; // Offset: 0x54 | Size: 0x4
	bool IfReplace; // Offset: 0x58 | Size: 0x1
	char pad_0x59[0x7]; // Offset: 0x59 | Size: 0x7
	struct FString AbilityBP; // Offset: 0x60 | Size: 0x10
	struct FString ItemBP; // Offset: 0x70 | Size: 0x10
	int32_t DropTime; // Offset: 0x80 | Size: 0x4
	int32_t UnPickupTime; // Offset: 0x84 | Size: 0x4
	bool IsRecommend; // Offset: 0x88 | Size: 0x1
	bool bDirty; // Offset: 0x89 | Size: 0x1
	bool IsPickupLock; // Offset: 0x8a | Size: 0x1
	char pad_0x8B[0x5]; // Offset: 0x8b | Size: 0x5
	int64_t UserId; // Offset: 0x90 | Size: 0x8
	int32_t Level; // Offset: 0x98 | Size: 0x4
	int32_t Prize; // Offset: 0x9c | Size: 0x4
	float CurValue; // Offset: 0xa0 | Size: 0x4
	bool UseOnPickup; // Offset: 0xa4 | Size: 0x1
	enum class EItemAppearanceType AppearanceType; // Offset: 0xa5 | Size: 0x1
	bool bUpdateOverlap; // Offset: 0xa6 | Size: 0x1
	char pad_0xA7[0x1]; // Offset: 0xa7 | Size: 0x1
	int32_t SourceType; // Offset: 0xa8 | Size: 0x4
	char pad_0xAC[0xc]; // Offset: 0xac | Size: 0xc
};

// Object: ScriptStruct Solarland.VehicleSpectateInfo
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FVehicleSpectateInfo {
	// Fields
	struct TWeakObjectPtr<struct ASolarVehiclePawn> SpectateVehicle; // Offset: 0x0 | Size: 0x8
	struct TWeakObjectPtr<struct ASolarVehicleWeapon> SpectateVehicleWeapon; // Offset: 0x8 | Size: 0x8
	enum class EVehicleWeaponScopeType VehicleWeaponScopeType; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x3]; // Offset: 0x11 | Size: 0x3
	struct TWeakObjectPtr<struct ASolarPlayerWeapon> SpectatePlayerWeapon; // Offset: 0x14 | Size: 0x8
	int32_t ScopeId; // Offset: 0x1c | Size: 0x4
	struct TArray<int32_t> WeaponIDs; // Offset: 0x20 | Size: 0x10
};

// Object: ScriptStruct Solarland.InteractiveTaskConfig
// Inherited Bytes: 0x8 | Struct Size: 0x88
struct FInteractiveTaskConfig : FTableRowBase {
	// Fields
	int32_t TaskID; // Offset: 0x8 | Size: 0x4
	int32_t GiftID; // Offset: 0xc | Size: 0x4
	int32_t TaskName; // Offset: 0x10 | Size: 0x4
	char pad_0x14[0x4]; // Offset: 0x14 | Size: 0x4
	struct FString Describe; // Offset: 0x18 | Size: 0x10
	int32_t TaskUpgradeDescribe; // Offset: 0x28 | Size: 0x4
	char pad_0x2C[0x4]; // Offset: 0x2c | Size: 0x4
	struct FSoftObjectPath TaskIcon; // Offset: 0x30 | Size: 0x18
	enum class ESocialCurrencyType CurrencyType; // Offset: 0x48 | Size: 0x1
	char pad_0x49[0x3]; // Offset: 0x49 | Size: 0x3
	int32_t MaxTaskLevel; // Offset: 0x4c | Size: 0x4
	struct TArray<int32_t> TaskTarget; // Offset: 0x50 | Size: 0x10
	struct TArray<int32_t> UpgradePrice; // Offset: 0x60 | Size: 0x10
	struct TArray<int32_t> TaskReward; // Offset: 0x70 | Size: 0x10
	enum class EInteractiveTaskType TaskType; // Offset: 0x80 | Size: 0x1
	char pad_0x81[0x3]; // Offset: 0x81 | Size: 0x3
	int32_t Param; // Offset: 0x84 | Size: 0x4
};

// Object: ScriptStruct Solarland.SpectateConditions
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FSpectateConditions {
	// Fields
	bool bCanBeSpectate; // Offset: 0x0 | Size: 0x1
	bool bCanBeSpectateByHostilePlayer; // Offset: 0x1 | Size: 0x1
	bool bCanBeSpectateByFriendlyPlayer; // Offset: 0x2 | Size: 0x1
	bool bCanISpectateBot; // Offset: 0x3 | Size: 0x1
	bool bCanISpectateHostilePlayers; // Offset: 0x4 | Size: 0x1
	char pad_0x5[0x3]; // Offset: 0x5 | Size: 0x3
	float LookAtSelfDeathBoxCountDown; // Offset: 0x8 | Size: 0x4
	char pad_0xC[0x4]; // Offset: 0xc | Size: 0x4
	struct TArray<enum class EFindSpectateTargetType> FindSpectateTargetPolicy; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct Solarland.SpectateReportInfo
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FSpectateReportInfo {
	// Fields
	uint32_t RankLevelID; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct FString TargetUserID; // Offset: 0x8 | Size: 0x10
	char TargetType; // Offset: 0x18 | Size: 0x1
	char pad_0x19[0x3]; // Offset: 0x19 | Size: 0x3
	uint32_t SpectateElapsedTime; // Offset: 0x1c | Size: 0x4
	char Type; // Offset: 0x20 | Size: 0x1
	char pad_0x21[0x7]; // Offset: 0x21 | Size: 0x7
};

// Object: ScriptStruct Solarland.BattleUpgradeEffectParamData
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FBattleUpgradeEffectParamData {
	// Fields
	enum class ESolarTablesEnum_BattleUpgradeEffectType EffectType; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	int32_t ParameterSum; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct Solarland.RepCountdownData
// Inherited Bytes: 0x0 | Struct Size: 0x2c
struct FRepCountdownData {
	// Fields
	int32_t RepTimes; // Offset: 0x0 | Size: 0x4
	int32_t RepTextID; // Offset: 0x4 | Size: 0x4
	int32_t RepPassiveTextID; // Offset: 0x8 | Size: 0x4
	int32_t RepPassiveCharacterID; // Offset: 0xc | Size: 0x4
	float RepDuration; // Offset: 0x10 | Size: 0x4
	float RepRemaining; // Offset: 0x14 | Size: 0x4
	float RepAmount; // Offset: 0x18 | Size: 0x4
	float RepStartTime; // Offset: 0x1c | Size: 0x4
	float RepEndTime; // Offset: 0x20 | Size: 0x4
	int32_t RepCancel; // Offset: 0x24 | Size: 0x4
	float RemainingTime; // Offset: 0x28 | Size: 0x4
};

// Object: ScriptStruct Solarland.CharacterRoleAbilityInfo
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FCharacterRoleAbilityInfo {
	// Fields
	bool bHasAbility; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x1]; // Offset: 0x1 | Size: 0x1
	bool bIsCountingDown; // Offset: 0x2 | Size: 0x1
	char pad_0x3[0x1]; // Offset: 0x3 | Size: 0x1
	float StartCDTime; // Offset: 0x4 | Size: 0x4
	float TotalCDTime; // Offset: 0x8 | Size: 0x4
	int32_t State; // Offset: 0xc | Size: 0x4
	char pad_0x10[0x4]; // Offset: 0x10 | Size: 0x4
	bool bOngoing; // Offset: 0x14 | Size: 0x1
	char pad_0x15[0x3]; // Offset: 0x15 | Size: 0x3
};

// Object: ScriptStruct Solarland.ReplicateMaxPileData
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FReplicateMaxPileData {
	// Fields
	int32_t ItemID; // Offset: 0x0 | Size: 0x4
	int32_t MaxPile; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct Solarland.ReplicateItemData
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FReplicateItemData {
	// Fields
	int32_t ItemID; // Offset: 0x0 | Size: 0x4
	int32_t count; // Offset: 0x4 | Size: 0x4
	int32_t Slot; // Offset: 0x8 | Size: 0x4
};

// Object: ScriptStruct Solarland.InteractiveTaskStatus
// Inherited Bytes: 0x0 | Struct Size: 0x78
struct FInteractiveTaskStatus {
	// Fields
	int32_t TaskID; // Offset: 0x0 | Size: 0x4
	int32_t CurLevel; // Offset: 0x4 | Size: 0x4
	int32_t ProgressValue; // Offset: 0x8 | Size: 0x4
	int32_t TargetValue; // Offset: 0xc | Size: 0x4
	int32_t Param; // Offset: 0x10 | Size: 0x4
	bool bAvailableToNxtLevel; // Offset: 0x14 | Size: 0x1
	char pad_0x15[0x53]; // Offset: 0x15 | Size: 0x53
	struct TArray<struct FGiftSenderInfo> TaskGiftPlayerInfo; // Offset: 0x68 | Size: 0x10
};

// Object: ScriptStruct Solarland.GiftSenderInfo
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FGiftSenderInfo {
	// Fields
	int32_t Gold; // Offset: 0x0 | Size: 0x4
	int32_t Diamond; // Offset: 0x4 | Size: 0x4
	struct FString playerName; // Offset: 0x8 | Size: 0x10
	struct FString PlayerId; // Offset: 0x18 | Size: 0x10
};

// Object: ScriptStruct Solarland.MedalInfo
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FMedalInfo {
	// Fields
	int32_t MedalID; // Offset: 0x0 | Size: 0x4
	int32_t MedalType; // Offset: 0x4 | Size: 0x4
	int32_t MedalPos; // Offset: 0x8 | Size: 0x4
	int32_t MedalLv; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct Solarland.CharacterSkin
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FCharacterSkin {
	// Fields
	int32_t SkinId; // Offset: 0x0 | Size: 0x4
	int32_t SkinOwnerType; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct Solarland.ShieldInfo
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FShieldInfo {
	// Fields
	int32_t ShieldID; // Offset: 0x0 | Size: 0x4
	float CurValue; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct Solarland.WorldMarkData
// Inherited Bytes: 0xc | Struct Size: 0x78
struct FWorldMarkData : FFastArraySerializerItem {
	// Fields
	int32_t WorldMarkGUID; // Offset: 0xc | Size: 0x4
	struct FVector_NetQuantize WorldPos; // Offset: 0x10 | Size: 0xc
	char PosInTeam; // Offset: 0x1c | Size: 0x1
	char pad_0x1D[0x3]; // Offset: 0x1d | Size: 0x3
	struct FVector2D ScreenCoordinate; // Offset: 0x20 | Size: 0x8
	enum class EWorldMarkType Type; // Offset: 0x28 | Size: 0x1
	char pad_0x29[0x3]; // Offset: 0x29 | Size: 0x3
	int32_t ItemID; // Offset: 0x2c | Size: 0x4
	int64_t ItemInstanceId; // Offset: 0x30 | Size: 0x8
	int32_t NameLocID; // Offset: 0x38 | Size: 0x4
	char pad_0x3C[0x4]; // Offset: 0x3c | Size: 0x4
	struct FString IconImg; // Offset: 0x40 | Size: 0x10
	int32_t WeaponLevel; // Offset: 0x50 | Size: 0x4
	enum class EInteractableType InteractableType; // Offset: 0x54 | Size: 0x1
	char pad_0x55[0x3]; // Offset: 0x55 | Size: 0x3
	int32_t MarkVoiceEventName; // Offset: 0x58 | Size: 0x4
	int32_t OuterBoxThisID; // Offset: 0x5c | Size: 0x4
	float MarkTimeStamp; // Offset: 0x60 | Size: 0x4
	float LifeTime; // Offset: 0x64 | Size: 0x4
	float ExtraLiveTime; // Offset: 0x68 | Size: 0x4
	struct TWeakObjectPtr<struct AActor> AttachedActor; // Offset: 0x6c | Size: 0x8
	char pad_0x74[0x4]; // Offset: 0x74 | Size: 0x4
};

// Object: ScriptStruct Solarland.BattleCharacterData
// Inherited Bytes: 0x0 | Struct Size: 0x60
struct FBattleCharacterData {
	// Fields
	int32_t CharacterId; // Offset: 0x0 | Size: 0x4
	int32_t SkinId; // Offset: 0x4 | Size: 0x4
	int32_t CharacterLevel; // Offset: 0x8 | Size: 0x4
	int32_t TalentID; // Offset: 0xc | Size: 0x4
	int32_t UseTimes; // Offset: 0x10 | Size: 0x4
	int32_t CardPose; // Offset: 0x14 | Size: 0x4
	int32_t Cardbackground; // Offset: 0x18 | Size: 0x4
	int32_t CharacterExp; // Offset: 0x1c | Size: 0x4
	int32_t Title; // Offset: 0x20 | Size: 0x4
	char pad_0x24[0x4]; // Offset: 0x24 | Size: 0x4
	int64_t Expired; // Offset: 0x28 | Size: 0x8
	int32_t CombatScore; // Offset: 0x30 | Size: 0x4
	int32_t BagId; // Offset: 0x34 | Size: 0x4
	int32_t TailFlameId; // Offset: 0x38 | Size: 0x4
	int32_t CapsuleActorId; // Offset: 0x3c | Size: 0x4
	int32_t DeathBoxId; // Offset: 0x40 | Size: 0x4
	int32_t CharacterOwnerType; // Offset: 0x44 | Size: 0x4
	struct TArray<struct FEquipVoiceData> Voice; // Offset: 0x48 | Size: 0x10
	int32_t KillReport; // Offset: 0x58 | Size: 0x4
	char pad_0x5C[0x4]; // Offset: 0x5c | Size: 0x4
};

// Object: ScriptStruct Solarland.EquipVoiceData
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FEquipVoiceData {
	// Fields
	int32_t Type; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct TArray<int32_t> Ids; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarBattleWeaponData
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FSolarBattleWeaponData {
	// Fields
	int32_t weaponid; // Offset: 0x0 | Size: 0x4
	int32_t SkinId; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct Solarland.ExposeLocationMap
// Inherited Bytes: 0x0 | Struct Size: 0x58
struct FExposeLocationMap {
	// Fields
	struct TMap<struct ASolarPlayerState*, int32_t> InnerMap; // Offset: 0x0 | Size: 0x50
	struct ASolarPlayerState* Owner; // Offset: 0x50 | Size: 0x8
};

// Object: ScriptStruct Solarland.SettlementTempData
// Inherited Bytes: 0x0 | Struct Size: 0xd8
struct FSettlementTempData {
	// Fields
	int32_t TotalAccountExp; // Offset: 0x0 | Size: 0x4
	int32_t AccountLevel; // Offset: 0x4 | Size: 0x4
	char pad_0x8[0x50]; // Offset: 0x8 | Size: 0x50
	int32_t CurCharacterLevel; // Offset: 0x58 | Size: 0x4
	int32_t TotalCharacterExp; // Offset: 0x5c | Size: 0x4
	bool bCharExpFull; // Offset: 0x60 | Size: 0x1
	bool bHaveRankData; // Offset: 0x61 | Size: 0x1
	char pad_0x62[0x2]; // Offset: 0x62 | Size: 0x2
	int32_t RankBeforeScore; // Offset: 0x64 | Size: 0x4
	int32_t RankAfterScore; // Offset: 0x68 | Size: 0x4
	int32_t RankSurviveScore; // Offset: 0x6c | Size: 0x4
	int32_t RankBeforeSurviveScore; // Offset: 0x70 | Size: 0x4
	int32_t RankDefeatScore; // Offset: 0x74 | Size: 0x4
	int32_t RankBeforeDefeatScore; // Offset: 0x78 | Size: 0x4
	float RankDefeatRatio; // Offset: 0x7c | Size: 0x4
	int32_t RankLegend; // Offset: 0x80 | Size: 0x4
	char RankProtectType; // Offset: 0x84 | Size: 0x1
	bool IsRankFight; // Offset: 0x85 | Size: 0x1
	char pad_0x86[0x2]; // Offset: 0x86 | Size: 0x2
	int32_t WinninScoreID; // Offset: 0x88 | Size: 0x4
	int32_t BattlePassID; // Offset: 0x8c | Size: 0x4
	int32_t BattlePassAddExp; // Offset: 0x90 | Size: 0x4
	int32_t BattlePassExp; // Offset: 0x94 | Size: 0x4
	struct TArray<int32_t> BattlePassTaskID; // Offset: 0x98 | Size: 0x10
	struct TArray<int32_t> BattlePassTaskWeek; // Offset: 0xa8 | Size: 0x10
	struct TArray<int32_t> BattlePassTaskAdd; // Offset: 0xb8 | Size: 0x10
	struct TArray<int32_t> BattlePassTaskVal; // Offset: 0xc8 | Size: 0x10
};

// Object: ScriptStruct Solarland.KillEnemySnapshot
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FKillEnemySnapshot {
	// Fields
	char pad_0x0[0x18]; // Offset: 0x0 | Size: 0x18
};

// Object: ScriptStruct Solarland.EquippedEmotesData
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FEquippedEmotesData {
	// Fields
	struct TArray<int32_t> EmoteData; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Solarland.SettlementCrateReward
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FSettlementCrateReward {
	// Fields
	int64_t crateID; // Offset: 0x0 | Size: 0x8
	struct TArray<struct FSettlementReward> Items; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct Solarland.SettlementReward
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FSettlementReward {
	// Fields
	int32_t ItemID; // Offset: 0x0 | Size: 0x4
	int32_t Amount; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct Solarland.SettlementParam_ExtraRewardInfo
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FSettlementParam_ExtraRewardInfo {
	// Fields
	int32_t TextID; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct FString LocVariable; // Offset: 0x8 | Size: 0x10
	struct FString Content; // Offset: 0x18 | Size: 0x10
	struct FString ItemList; // Offset: 0x28 | Size: 0x10
	int32_t Order; // Offset: 0x38 | Size: 0x4
	char pad_0x3C[0x4]; // Offset: 0x3c | Size: 0x4
};

// Object: ScriptStruct Solarland.LastBattleInfo
// Inherited Bytes: 0x0 | Struct Size: 0x1c
struct FLastBattleInfo {
	// Fields
	float MvpScore; // Offset: 0x0 | Size: 0x4
	int32_t KillNum; // Offset: 0x4 | Size: 0x4
	int32_t HitDown; // Offset: 0x8 | Size: 0x4
	int32_t AssistNum; // Offset: 0xc | Size: 0x4
	int32_t RescueNum; // Offset: 0x10 | Size: 0x4
	int32_t AliveTime; // Offset: 0x14 | Size: 0x4
	int32_t CauseDamage; // Offset: 0x18 | Size: 0x4
};

// Object: ScriptStruct Solarland.ExpRankMedalData
// Inherited Bytes: 0x0 | Struct Size: 0x38
struct FExpRankMedalData {
	// Fields
	struct FString Area; // Offset: 0x0 | Size: 0x10
	struct FString Country; // Offset: 0x10 | Size: 0x10
	int32_t Rank; // Offset: 0x20 | Size: 0x4
	int32_t CharacterId; // Offset: 0x24 | Size: 0x4
	int32_t CharacterType; // Offset: 0x28 | Size: 0x4
	int32_t RankScore; // Offset: 0x2c | Size: 0x4
	int32_t RankType; // Offset: 0x30 | Size: 0x4
	int32_t AutoID; // Offset: 0x34 | Size: 0x4
};

// Object: ScriptStruct Solarland.InWaterActorInfo
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FInWaterActorInfo {
	// Fields
	bool bIsInWater; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	float WaterLineHeight; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct Solarland.SpawnedActorHandle
// Inherited Bytes: 0x0 | Struct Size: 0x4
struct FSpawnedActorHandle {
	// Fields
	uint32_t Handle; // Offset: 0x0 | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarPointDamageEvent
// Inherited Bytes: 0xa8 | Struct Size: 0x110
struct FSolarPointDamageEvent : FPointDamageEvent {
	// Fields
	bool bBreakShield; // Offset: 0xa8 | Size: 0x1
	bool bIgnoreShield; // Offset: 0xa9 | Size: 0x1
	char pad_0xAA[0x2]; // Offset: 0xaa | Size: 0x2
	float ActualShieldDamage; // Offset: 0xac | Size: 0x4
	bool bBreakArmor; // Offset: 0xb0 | Size: 0x1
	bool bIgnoreArmor; // Offset: 0xb1 | Size: 0x1
	char pad_0xB2[0x2]; // Offset: 0xb2 | Size: 0x2
	float ActualArmorDamage; // Offset: 0xb4 | Size: 0x4
	enum class ESolarAttributeType SolarAttributeType; // Offset: 0xb8 | Size: 0x1
	bool bPreFakeInvincible; // Offset: 0xb9 | Size: 0x1
	enum class EHealthChangeType HealthChangeType; // Offset: 0xba | Size: 0x1
	char pad_0xBB[0x5]; // Offset: 0xbb | Size: 0x5
	struct ASolarAbility* DamageAbility; // Offset: 0xc0 | Size: 0x8
	struct USolarAbilityEffect* DamageAbilityEffect; // Offset: 0xc8 | Size: 0x8
	enum class EDamageResultType ResultType; // Offset: 0xd0 | Size: 0x1
	bool bJustForShield; // Offset: 0xd1 | Size: 0x1
	bool bCanDamageTeamate; // Offset: 0xd2 | Size: 0x1
	char pad_0xD3[0x1]; // Offset: 0xd3 | Size: 0x1
	int32_t UseWeaponID; // Offset: 0xd4 | Size: 0x4
	enum class ESCMDamageType DamageType; // Offset: 0xd8 | Size: 0x1
	char pad_0xD9[0x3]; // Offset: 0xd9 | Size: 0x3
	struct TWeakObjectPtr<struct AActor> DamageCauser; // Offset: 0xdc | Size: 0x8
	char pad_0xE4[0xc]; // Offset: 0xe4 | Size: 0xc
	struct FString HitBoneName; // Offset: 0xf0 | Size: 0x10
	char bHitVehicleWeakPoint : 1; // Offset: 0x100 | Size: 0x1
	char bHitHumanoidTargetHead : 1; // Offset: 0x100 | Size: 0x1
	char pad_0x100_2 : 6; // Offset: 0x100 | Size: 0x1
	char pad_0x101[0xf]; // Offset: 0x101 | Size: 0xf
};

// Object: ScriptStruct Solarland.ReconnectionParams
// Inherited Bytes: 0x0 | Struct Size: 0x1
struct FReconnectionParams {
	// Fields
	bool bIsCrouched; // Offset: 0x0 | Size: 0x1
};

// Object: ScriptStruct Solarland.PlayerWeaponMsg
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FPlayerWeaponMsg {
	// Fields
	enum class EPlayerWeaponMsgType MsgType; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x7]; // Offset: 0x1 | Size: 0x7
	struct FString MsgDetail; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct Solarland.ScannedInfo_NetQuantize
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FScannedInfo_NetQuantize {
	// Fields
	uint32_t UniqueId; // Offset: 0x0 | Size: 0x4
	char TargetType; // Offset: 0x4 | Size: 0x1
	char pad_0x5[0x3]; // Offset: 0x5 | Size: 0x3
	uint32_t VehicleID; // Offset: 0x8 | Size: 0x4
	struct FVector_NetQuantize TargetLocation; // Offset: 0xc | Size: 0xc
};

// Object: ScriptStruct Solarland.RestoreAbilityInfo
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FRestoreAbilityInfo {
	// Fields
	struct FGameplayAbilitySpecHandle Handle; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct FPredictionKey ActivationPredictionKey; // Offset: 0x8 | Size: 0x18
};

// Object: ScriptStruct Solarland.BackpackStatisticsInfo
// Inherited Bytes: 0x0 | Struct Size: 0x1c
struct FBackpackStatisticsInfo {
	// Fields
	bool IsVertical; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	struct FVector PlayerStartLocation; // Offset: 0x4 | Size: 0xc
	struct FVector PlayerEndLocation; // Offset: 0x10 | Size: 0xc
};

// Object: ScriptStruct Solarland.SoundGroupPlayContext
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FSoundGroupPlayContext {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
};

// Object: ScriptStruct Solarland.SoundGroupPlayContextByCharacter
// Inherited Bytes: 0x8 | Struct Size: 0x20
struct FSoundGroupPlayContextByCharacter : FSoundGroupPlayContext {
	// Fields
	struct TWeakObjectPtr<struct ASolarCharacter> Self; // Offset: 0x8 | Size: 0x8
	struct TWeakObjectPtr<struct ASolarCharacter> Instigator; // Offset: 0x10 | Size: 0x8
	struct TWeakObjectPtr<struct ASolarCharacter> LocalCharacter; // Offset: 0x18 | Size: 0x8
};

// Object: ScriptStruct Solarland.HitTraceInfo
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FHitTraceInfo {
	// Fields
	struct TWeakObjectPtr<struct AActor> CausingActor; // Offset: 0x0 | Size: 0x8
	struct FVector_NetQuantizeNormal TraceDirection; // Offset: 0x8 | Size: 0xc
	struct FVector DamageCauserLocation; // Offset: 0x14 | Size: 0xc
	float Damage; // Offset: 0x20 | Size: 0x4
	enum class EWeaponType WeaponType; // Offset: 0x24 | Size: 0x1
	bool bIsVehicleHitTrace; // Offset: 0x25 | Size: 0x1
	bool IsBump; // Offset: 0x26 | Size: 0x1
	char pad_0x27[0x1]; // Offset: 0x27 | Size: 0x1
};

// Object: ScriptStruct Solarland.HitSoundReplicationData
// Inherited Bytes: 0x0 | Struct Size: 0x80
struct FHitSoundReplicationData {
	// Fields
	uint16_t HitCount; // Offset: 0x0 | Size: 0x2
	char DirtyDataMask; // Offset: 0x2 | Size: 0x1
	char pad_0x3[0x1]; // Offset: 0x3 | Size: 0x1
	struct FHitSoundData HitData_Default; // Offset: 0x4 | Size: 0x1c
	struct FHitSoundData HitData_Weapon; // Offset: 0x20 | Size: 0x1c
	struct FHitSoundData HitData_Melee; // Offset: 0x3c | Size: 0x1c
	struct FHitSoundData HitData_Skill; // Offset: 0x58 | Size: 0x1c
	char pad_0x74[0xc]; // Offset: 0x74 | Size: 0xc
};

// Object: ScriptStruct Solarland.HitSoundData
// Inherited Bytes: 0x0 | Struct Size: 0x1c
struct FHitSoundData {
	// Fields
	struct TWeakObjectPtr<struct AActor> Instigator; // Offset: 0x0 | Size: 0x8
	enum class EHitSoundSourceType SourceType; // Offset: 0x8 | Size: 0x1
	enum class EHitSoundTargetType TargetType; // Offset: 0x9 | Size: 0x1
	char pad_0xA[0x2]; // Offset: 0xa | Size: 0x2
	struct FName SubTableKey; // Offset: 0xc | Size: 0x8
	struct FName SubTableKey2; // Offset: 0x14 | Size: 0x8
};

// Object: ScriptStruct Solarland.OrnamentMontageInfo
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FOrnamentMontageInfo {
	// Fields
	struct UAnimMontage* ActiveMontage; // Offset: 0x0 | Size: 0x8
	struct FGameplayTag OrnamentTag; // Offset: 0x8 | Size: 0x8
	char bForcePlayBit : 1; // Offset: 0x10 | Size: 0x1
	char pad_0x10_1 : 7; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x7]; // Offset: 0x11 | Size: 0x7
};

// Object: ScriptStruct Solarland.ShieldSoundData
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FShieldSoundData {
	// Fields
	struct TMap<enum class EShieldSoundEventType, enum class ECharacterSoundOpt> SoundData; // Offset: 0x0 | Size: 0x50
};

// Object: ScriptStruct Solarland.SingleCruiseBaseParam
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FSingleCruiseBaseParam {
	// Fields
	char pad_0x0[0x20]; // Offset: 0x0 | Size: 0x20
};

// Object: ScriptStruct Solarland.VehicleEjectParams
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FVehicleEjectParams {
	// Fields
	float EjectTime; // Offset: 0x0 | Size: 0x4
	float EjectDistance; // Offset: 0x4 | Size: 0x4
	float EjectBreakableTime; // Offset: 0x8 | Size: 0x4
	float EjectCameraFadeOutTime; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct Solarland.BattleUpgradeEffectContainer
// Inherited Bytes: 0x108 | Struct Size: 0x120
struct FBattleUpgradeEffectContainer : FFastArraySerializer {
	// Fields
	struct TArray<struct FBattleUpgradeEffect> DataArray; // Offset: 0x108 | Size: 0x10
	struct ASolarCharacter* Owner; // Offset: 0x118 | Size: 0x8
};

// Object: ScriptStruct Solarland.BattleUpgradeEffect
// Inherited Bytes: 0xc | Struct Size: 0x28
struct FBattleUpgradeEffect : FFastArraySerializerItem {
	// Fields
	int32_t Level; // Offset: 0xc | Size: 0x4
	int32_t EffectID; // Offset: 0x10 | Size: 0x4
	char pad_0x14[0x4]; // Offset: 0x14 | Size: 0x4
	struct TArray<int32_t> EffectCandidate; // Offset: 0x18 | Size: 0x10
};

// Object: ScriptStruct Solarland.BoardedVehicleInfo
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FBoardedVehicleInfo {
	// Fields
	struct ASolarVehiclePawn* BoardedVehicle; // Offset: 0x0 | Size: 0x8
	int32_t BoardedSeatIndex; // Offset: 0x8 | Size: 0x4
	char pad_0xC[0x4]; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct Solarland.CriticalHitInfo
// Inherited Bytes: 0x0 | Struct Size: 0x68
struct FCriticalHitInfo {
	// Fields
	struct ASolarPlayerState* Instigator; // Offset: 0x0 | Size: 0x8
	float Damage; // Offset: 0x8 | Size: 0x4
	float DamageTime; // Offset: 0xc | Size: 0x4
	int32_t LastDamageWeaponID; // Offset: 0x10 | Size: 0x4
	char pad_0x14[0x54]; // Offset: 0x14 | Size: 0x54
};

// Object: ScriptStruct Solarland.RadarDataSpecContainer
// Inherited Bytes: 0x108 | Struct Size: 0x120
struct FRadarDataSpecContainer : FFastArraySerializer {
	// Fields
	struct TArray<struct FRadarDataSpec> Radars; // Offset: 0x108 | Size: 0x10
	struct USolarRadarComponent* Owner; // Offset: 0x118 | Size: 0x8
};

// Object: ScriptStruct Solarland.RadarDataSpec
// Inherited Bytes: 0xc | Struct Size: 0x28
struct FRadarDataSpec : FFastArraySerializerItem {
	// Fields
	struct FGameplayAbilitySpecHandle RadarHandle; // Offset: 0xc | Size: 0x4
	char RadarType; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x3]; // Offset: 0x11 | Size: 0x3
	struct FVector2D RadarRange; // Offset: 0x14 | Size: 0x8
	char pad_0x1C[0x4]; // Offset: 0x1c | Size: 0x4
	struct APawn* RadarSpawner; // Offset: 0x20 | Size: 0x8
};

// Object: ScriptStruct Solarland.CharacterOperationEvent
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FCharacterOperationEvent {
	// Fields
	enum class ECharacterOperation Name; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x7]; // Offset: 0x1 | Size: 0x7
	struct UObject* Target; // Offset: 0x8 | Size: 0x8
};

// Object: ScriptStruct Solarland.BackpackJetPrepelInfo
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FBackpackJetPrepelInfo {
	// Fields
	bool IsPropelling; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	int32_t PropellingCounter; // Offset: 0x4 | Size: 0x4
	enum class EFXJetType JetType; // Offset: 0x8 | Size: 0x1
	bool bCheckGround; // Offset: 0x9 | Size: 0x1
	char pad_0xA[0x2]; // Offset: 0xa | Size: 0x2
};

// Object: ScriptStruct Solarland.WeaponIgnoreScopeLists
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FWeaponIgnoreScopeLists {
	// Fields
	struct TArray<enum class EWeaponPartType> Weapon1IgnoreList; // Offset: 0x0 | Size: 0x10
	struct TArray<enum class EWeaponPartType> Weapon2IgnoreList; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct Solarland.CharacterTagListenerForOrnamentComp
// Inherited Bytes: 0x0 | Struct Size: 0x58
struct FCharacterTagListenerForOrnamentComp {
	// Fields
	struct TSet<struct FOrnamentCompAndVisibilityConfigPair> OrnamentCompPairs; // Offset: 0x0 | Size: 0x50
	char pad_0x50[0x8]; // Offset: 0x50 | Size: 0x8
};

// Object: ScriptStruct Solarland.OrnamentCompAndVisibilityConfigPair
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FOrnamentCompAndVisibilityConfigPair {
	// Fields
	struct TWeakObjectPtr<struct USceneComponent> OrnamentComp; // Offset: 0x0 | Size: 0x8
	struct UOrnamentComponentVisibilityConfig* VisibilityConfig; // Offset: 0x8 | Size: 0x8
};

// Object: ScriptStruct Solarland.CustomParamConfig
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FCustomParamConfig {
	// Fields
	int32_t DisplayName; // Offset: 0x0 | Size: 0x4
	int32_t Desc; // Offset: 0x4 | Size: 0x4
	enum class ECustomParamType ParamType; // Offset: 0x8 | Size: 0x1
	enum class ECustomParamValueType ValueType; // Offset: 0x9 | Size: 0x1
	char pad_0xA[0x2]; // Offset: 0xa | Size: 0x2
	int32_t DefaultIndex; // Offset: 0xc | Size: 0x4
	struct TArray<float> ValueRange; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct Solarland.UserSetting
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FUserSetting {
	// Fields
	int32_t Name; // Offset: 0x0 | Size: 0x4
	int32_t Category; // Offset: 0x4 | Size: 0x4
	enum class ECustomParamType ParamType; // Offset: 0x8 | Size: 0x1
	enum class ECustomParamValueType ValueType; // Offset: 0x9 | Size: 0x1
	char pad_0xA[0x2]; // Offset: 0xa | Size: 0x2
	int32_t Index; // Offset: 0xc | Size: 0x4
	struct TArray<float> ValueRange; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct Solarland.CategoryConfig
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FCategoryConfig {
	// Fields
	int32_t Category; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct TArray<struct FCustomParamConfig> Configs; // Offset: 0x8 | Size: 0x10
	struct TSoftClassPtr<UObject> StyleClass; // Offset: 0x18 | Size: 0x28
};

// Object: ScriptStruct Solarland.FixedAntiCheatData
// Inherited Bytes: 0x0 | Struct Size: 0x1c
struct FFixedAntiCheatData {
	// Fields
	int32_t FOV; // Offset: 0x0 | Size: 0x4
	enum class EAspectRatioAxisConstraint AxisConstraint; // Offset: 0x4 | Size: 0x1
	bool bAssistAim; // Offset: 0x5 | Size: 0x1
	char pad_0x6[0x2]; // Offset: 0x6 | Size: 0x2
	struct FVector HeadBoneScale; // Offset: 0x8 | Size: 0xc
	bool CurrWeaponRecoil; // Offset: 0x14 | Size: 0x1
	char pad_0x15[0x3]; // Offset: 0x15 | Size: 0x3
	float LatestTimeDiscrepancyError; // Offset: 0x18 | Size: 0x4
};

// Object: ScriptStruct Solarland.ReplayActivityHeatFragment
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FReplayActivityHeatFragment {
	// Fields
	int32_t FragmentId; // Offset: 0x0 | Size: 0x4
	enum class EPlayerActivityHeatType ActivityHeatType; // Offset: 0x4 | Size: 0x1
	char pad_0x5[0x3]; // Offset: 0x5 | Size: 0x3
	float TotalScore; // Offset: 0x8 | Size: 0x4
	float BeginTime; // Offset: 0xc | Size: 0x4
	float EndTime; // Offset: 0x10 | Size: 0x4
	char pad_0x14[0x4]; // Offset: 0x14 | Size: 0x4
	struct TArray<struct FReplayActivityKillDetail> ActivityKillDetails; // Offset: 0x18 | Size: 0x10
	int32_t KillNum; // Offset: 0x28 | Size: 0x4
	float ActivityHotTime; // Offset: 0x2c | Size: 0x4
};

// Object: ScriptStruct Solarland.ReplayActivityKillDetail
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FReplayActivityKillDetail {
	// Fields
	float KillTime; // Offset: 0x0 | Size: 0x4
	enum class EReplayActivityHeatKillUseType KillUseType; // Offset: 0x4 | Size: 0x1
	char pad_0x5[0x3]; // Offset: 0x5 | Size: 0x3
	int32_t KillToolID; // Offset: 0x8 | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarGameModeInfo
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FSolarGameModeInfo {
	// Fields
	int32_t GameModeId; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct FString MapName; // Offset: 0x8 | Size: 0x10
	int32_t NumMode; // Offset: 0x18 | Size: 0x4
	int32_t PlayerCount; // Offset: 0x1c | Size: 0x4
	int32_t TeamCount; // Offset: 0x20 | Size: 0x4
	char pad_0x24[0x4]; // Offset: 0x24 | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarPlayerReport
// Inherited Bytes: 0x0 | Struct Size: 0x498
struct FSolarPlayerReport {
	// Fields
	struct FString PlayerId; // Offset: 0x0 | Size: 0x10
	uint64_t UserId; // Offset: 0x10 | Size: 0x8
	struct FString NickName; // Offset: 0x18 | Size: 0x10
	int32_t CharacterId; // Offset: 0x28 | Size: 0x4
	int32_t SkinId; // Offset: 0x2c | Size: 0x4
	int32_t PlayerRank; // Offset: 0x30 | Size: 0x4
	int32_t Gender; // Offset: 0x34 | Size: 0x4
	int32_t AvatarID; // Offset: 0x38 | Size: 0x4
	char pad_0x3C[0x4]; // Offset: 0x3c | Size: 0x4
	struct FString AvatarUrl; // Offset: 0x40 | Size: 0x10
	int32_t AccountFlag; // Offset: 0x50 | Size: 0x4
	int32_t TeamRank; // Offset: 0x54 | Size: 0x4
	int32_t TeamID; // Offset: 0x58 | Size: 0x4
	int32_t PosInTeam; // Offset: 0x5c | Size: 0x4
	bool bHasHangUpBehavior; // Offset: 0x60 | Size: 0x1
	char pad_0x61[0x3]; // Offset: 0x61 | Size: 0x3
	int32_t KillNum; // Offset: 0x64 | Size: 0x4
	int32_t KillNumToRealPlayer; // Offset: 0x68 | Size: 0x4
	char pad_0x6C[0x4]; // Offset: 0x6c | Size: 0x4
	struct TArray<int32_t> VehicleKillNum_ID; // Offset: 0x70 | Size: 0x10
	struct TArray<int32_t> VehicleKillNum_Value; // Offset: 0x80 | Size: 0x10
	int32_t KillTeammate; // Offset: 0x90 | Size: 0x4
	int32_t KillInAirNum; // Offset: 0x94 | Size: 0x4
	int32_t KillDownInAirNum; // Offset: 0x98 | Size: 0x4
	int32_t WeaponSkillKillNum; // Offset: 0x9c | Size: 0x4
	int32_t P_KillStreak; // Offset: 0xa0 | Size: 0x4
	char pad_0xA4[0x4]; // Offset: 0xa4 | Size: 0x4
	struct TArray<int32_t> KillStreakHistory; // Offset: 0xa8 | Size: 0x10
	int32_t RevengeNum; // Offset: 0xb8 | Size: 0x4
	int32_t DeathNum; // Offset: 0xbc | Size: 0x4
	int32_t KillDownNum; // Offset: 0xc0 | Size: 0x4
	int32_t KillDownTeammate; // Offset: 0xc4 | Size: 0x4
	float AccurateDamage; // Offset: 0xc8 | Size: 0x4
	int32_t AccurateDameageTimes; // Offset: 0xcc | Size: 0x4
	int32_t AccurateKillTimes; // Offset: 0xd0 | Size: 0x4
	int32_t AccurateKillDownTimes; // Offset: 0xd4 | Size: 0x4
	float CauseDamage; // Offset: 0xd8 | Size: 0x4
	float CauseDamageToRealPlayer; // Offset: 0xdc | Size: 0x4
	float ReceivedDamage; // Offset: 0xe0 | Size: 0x4
	int32_t AssistNum; // Offset: 0xe4 | Size: 0x4
	float CollectEnergy; // Offset: 0xe8 | Size: 0x4
	int32_t BuyESElectricNum; // Offset: 0xec | Size: 0x4
	int32_t ResurrectionCapsule; // Offset: 0xf0 | Size: 0x4
	int32_t TeamFriendRevive; // Offset: 0xf4 | Size: 0x4
	float ReceivedHeal; // Offset: 0xf8 | Size: 0x4
	float HealSelf; // Offset: 0xfc | Size: 0x4
	float TeammateHeal; // Offset: 0x100 | Size: 0x4
	int32_t OpenAirBoxNum; // Offset: 0x104 | Size: 0x4
	float LifeTime; // Offset: 0x108 | Size: 0x4
	int32_t SaveCount; // Offset: 0x10c | Size: 0x4
	int32_t FlyCount; // Offset: 0x110 | Size: 0x4
	int32_t VehicleTime; // Offset: 0x114 | Size: 0x4
	int32_t CurCharacterLevel; // Offset: 0x118 | Size: 0x4
	int32_t TotalCharacterExp; // Offset: 0x11c | Size: 0x4
	bool bCharExpFull; // Offset: 0x120 | Size: 0x1
	char pad_0x121[0x7]; // Offset: 0x121 | Size: 0x7
	struct TArray<int32_t> CharacterExpReason; // Offset: 0x128 | Size: 0x10
	int32_t CharacterExp; // Offset: 0x138 | Size: 0x4
	int32_t AccountExp; // Offset: 0x13c | Size: 0x4
	int32_t TotalAccountExp; // Offset: 0x140 | Size: 0x4
	int32_t AccountLevel; // Offset: 0x144 | Size: 0x4
	bool bHaveRankData; // Offset: 0x148 | Size: 0x1
	char pad_0x149[0x3]; // Offset: 0x149 | Size: 0x3
	int32_t RankID; // Offset: 0x14c | Size: 0x4
	int32_t RankBeforeScore; // Offset: 0x150 | Size: 0x4
	int32_t RankSurviveScore; // Offset: 0x154 | Size: 0x4
	int32_t RankBeforeSurviveScore; // Offset: 0x158 | Size: 0x4
	int32_t RankDefeatScore; // Offset: 0x15c | Size: 0x4
	int32_t RankBeforeDefeatScore; // Offset: 0x160 | Size: 0x4
	float RankDefeatRatio; // Offset: 0x164 | Size: 0x4
	int32_t RankAfterScore; // Offset: 0x168 | Size: 0x4
	int32_t RankLegend; // Offset: 0x16c | Size: 0x4
	char RankProtectType; // Offset: 0x170 | Size: 0x1
	bool IsRankFight; // Offset: 0x171 | Size: 0x1
	char pad_0x172[0x2]; // Offset: 0x172 | Size: 0x2
	int32_t WinninScoreID; // Offset: 0x174 | Size: 0x4
	int32_t Zomborg; // Offset: 0x178 | Size: 0x4
	float MvpScore; // Offset: 0x17c | Size: 0x4
	float KDA; // Offset: 0x180 | Size: 0x4
	bool IsAce; // Offset: 0x184 | Size: 0x1
	bool IsVictory; // Offset: 0x185 | Size: 0x1
	bool IsValid; // Offset: 0x186 | Size: 0x1
	char pad_0x187[0x1]; // Offset: 0x187 | Size: 0x1
	struct TArray<int32_t> SettlementItems; // Offset: 0x188 | Size: 0x10
	struct TArray<struct FString> StringExtraRewards; // Offset: 0x198 | Size: 0x10
	struct TArray<int32_t> SendGiftGold; // Offset: 0x1a8 | Size: 0x10
	struct TArray<int32_t> SendGiftDiamond; // Offset: 0x1b8 | Size: 0x10
	struct TArray<struct FString> SendGiftPlayerName; // Offset: 0x1c8 | Size: 0x10
	struct TArray<struct FString> SendGiftPlayerID; // Offset: 0x1d8 | Size: 0x10
	struct TArray<int32_t> WeaponExpIds; // Offset: 0x1e8 | Size: 0x10
	struct TArray<int32_t> WeaponLevel; // Offset: 0x1f8 | Size: 0x10
	struct TArray<int32_t> CurWeaponExp; // Offset: 0x208 | Size: 0x10
	struct TArray<int32_t> WeaponExps; // Offset: 0x218 | Size: 0x10
	struct TArray<int32_t> WeaponKillNum_ID; // Offset: 0x228 | Size: 0x10
	struct TArray<float> WeaponKillNum_Value; // Offset: 0x238 | Size: 0x10
	struct TArray<int32_t> WeaponDamage_ID; // Offset: 0x248 | Size: 0x10
	struct TArray<float> WeaponDamage_Value; // Offset: 0x258 | Size: 0x10
	struct TArray<int32_t> VehicleDamage_ID; // Offset: 0x268 | Size: 0x10
	struct TArray<float> VehicleDamage_Value; // Offset: 0x278 | Size: 0x10
	struct TArray<int32_t> VehicleDistance_ID; // Offset: 0x288 | Size: 0x10
	struct TArray<int32_t> VehicleDistance_Value; // Offset: 0x298 | Size: 0x10
	int32_t GainCombatScore; // Offset: 0x2a8 | Size: 0x4
	int32_t GameModeSubID; // Offset: 0x2ac | Size: 0x4
	struct FString KillerPlayerId; // Offset: 0x2b0 | Size: 0x10
	uint64_t KillerUserId; // Offset: 0x2c0 | Size: 0x8
	struct FString KillerNickName; // Offset: 0x2c8 | Size: 0x10
	struct FString KillerOS; // Offset: 0x2d8 | Size: 0x10
	struct FString OS; // Offset: 0x2e8 | Size: 0x10
	struct TArray<int32_t> CharacterKillNumIDs; // Offset: 0x2f8 | Size: 0x10
	struct TArray<int32_t> CharacterKillNumValues; // Offset: 0x308 | Size: 0x10
	int32_t WarmType; // Offset: 0x318 | Size: 0x4
	char pad_0x31C[0x4]; // Offset: 0x31c | Size: 0x4
	struct TArray<int32_t> AchievementIDs; // Offset: 0x320 | Size: 0x10
	struct TArray<int32_t> AchievementValues; // Offset: 0x330 | Size: 0x10
	int32_t LikeValue; // Offset: 0x340 | Size: 0x4
	char pad_0x344[0x4]; // Offset: 0x344 | Size: 0x4
	struct TArray<int32_t> StrategyConditionIDs; // Offset: 0x348 | Size: 0x10
	int32_t SettlementDisplayStrategyID; // Offset: 0x358 | Size: 0x4
	int32_t LastUseVehicleID; // Offset: 0x35c | Size: 0x4
	struct TArray<struct FString> SavedTeammateIDArr; // Offset: 0x360 | Size: 0x10
	struct TArray<int32_t> SavedTeammateBonusArr; // Offset: 0x370 | Size: 0x10
	struct TArray<char> SettlementRewards; // Offset: 0x380 | Size: 0x10
	struct TArray<char> CrateRewardData; // Offset: 0x390 | Size: 0x10
	struct TArray<char> CollectionItems; // Offset: 0x3a0 | Size: 0x10
	struct FString ClanId; // Offset: 0x3b0 | Size: 0x10
	int32_t KnockoutPoints; // Offset: 0x3c0 | Size: 0x4
	bool bIsKnockoutPointsValid; // Offset: 0x3c4 | Size: 0x1
	char pad_0x3C5[0x3]; // Offset: 0x3c5 | Size: 0x3
	int32_t BattlePassAddExp; // Offset: 0x3c8 | Size: 0x4
	int32_t BattlePassExp; // Offset: 0x3cc | Size: 0x4
	int32_t BattlePassID; // Offset: 0x3d0 | Size: 0x4
	char pad_0x3D4[0x4]; // Offset: 0x3d4 | Size: 0x4
	struct TArray<int32_t> BattlePassTaskWeek; // Offset: 0x3d8 | Size: 0x10
	struct TArray<int32_t> BattlePassTaskID; // Offset: 0x3e8 | Size: 0x10
	struct TArray<int32_t> BattlePassTaskAdd; // Offset: 0x3f8 | Size: 0x10
	struct TArray<int32_t> BattlePassTaskVal; // Offset: 0x408 | Size: 0x10
	struct TArray<int32_t> UsedCharacterIDs; // Offset: 0x418 | Size: 0x10
	int32_t CardPose; // Offset: 0x428 | Size: 0x4
	int32_t Cardbackground; // Offset: 0x42c | Size: 0x4
	int32_t SameClanCnt; // Offset: 0x430 | Size: 0x4
	int32_t CombatScore; // Offset: 0x434 | Size: 0x4
	bool IsCheater; // Offset: 0x438 | Size: 0x1
	char pad_0x439[0x7]; // Offset: 0x439 | Size: 0x7
	struct TArray<char> SettlePunishTypes; // Offset: 0x440 | Size: 0x10
	int32_t MedicineUseCount; // Offset: 0x450 | Size: 0x4
	int32_t DriveHoverCarInWaterDistance; // Offset: 0x454 | Size: 0x4
	int32_t SwimDistance; // Offset: 0x458 | Size: 0x4
	int32_t DanceCount; // Offset: 0x45c | Size: 0x4
	int32_t PosionWalkDistance; // Offset: 0x460 | Size: 0x4
	int32_t ShieldExpGainCount; // Offset: 0x464 | Size: 0x4
	int32_t UpgradeShieldCount; // Offset: 0x468 | Size: 0x4
	int32_t UpgradeRedShieldCount; // Offset: 0x46c | Size: 0x4
	int32_t JumpBoardUseCount; // Offset: 0x470 | Size: 0x4
	int32_t TerminaterCount; // Offset: 0x474 | Size: 0x4
	int32_t CarSkillCount; // Offset: 0x478 | Size: 0x4
	int32_t UltimateSkillUseCount; // Offset: 0x47c | Size: 0x4
	int32_t TacticalSkillUseCount; // Offset: 0x480 | Size: 0x4
	char pad_0x484[0x4]; // Offset: 0x484 | Size: 0x4
	struct TArray<struct FString> ReCombatLimitPlayer; // Offset: 0x488 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarDamageText
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FSolarDamageText {
	// Fields
	bool bHitHead; // Offset: 0x0 | Size: 0x1
	bool bHitShield; // Offset: 0x1 | Size: 0x1
	bool bBrokenShield; // Offset: 0x2 | Size: 0x1
	char pad_0x3[0x1]; // Offset: 0x3 | Size: 0x1
	int32_t Damage; // Offset: 0x4 | Size: 0x4
	struct TWeakObjectPtr<struct AActor> Target; // Offset: 0x8 | Size: 0x8
	struct TWeakObjectPtr<struct AActor> Source; // Offset: 0x10 | Size: 0x8
	struct FVector HitLocation; // Offset: 0x18 | Size: 0xc
	uint32_t TargetUniqueID; // Offset: 0x24 | Size: 0x4
};

// Object: ScriptStruct Solarland.ScreenshotSetting
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FScreenshotSetting {
	// Fields
	bool EnableOnCurrentReportGameCheating; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	int32_t MaxCountInRound; // Offset: 0x4 | Size: 0x4
	struct TArray<bool> ScreenshotMoment; // Offset: 0x8 | Size: 0x10
	int32_t ScreenshotInterval; // Offset: 0x18 | Size: 0x4
	int32_t ScreenshotWidth; // Offset: 0x1c | Size: 0x4
	int32_t ScreenshotQuality; // Offset: 0x20 | Size: 0x4
	char pad_0x24[0x4]; // Offset: 0x24 | Size: 0x4
	struct FString ImageSaveType; // Offset: 0x28 | Size: 0x10
	enum class EShotModeFlag ScreenshotMode; // Offset: 0x38 | Size: 0x1
	char pad_0x39[0x3]; // Offset: 0x39 | Size: 0x3
	int32_t ImageMaxSize; // Offset: 0x3c | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarInputModeDataBase
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FSolarInputModeDataBase {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Solarland.LocTextParam
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FLocTextParam {
	// Fields
	struct FString ParamName; // Offset: 0x0 | Size: 0x10
	int32_t LocTextID; // Offset: 0x10 | Size: 0x4
	char pad_0x14[0x4]; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct Solarland.SShotImageInfo
// Inherited Bytes: 0x0 | Struct Size: 0x78
struct FSShotImageInfo {
	// Fields
	struct FString UserId; // Offset: 0x0 | Size: 0x10
	struct FString PlayerId; // Offset: 0x10 | Size: 0x10
	struct FString BattleID; // Offset: 0x20 | Size: 0x10
	int64_t ScreenshotTime; // Offset: 0x30 | Size: 0x8
	int32_t ImageSize; // Offset: 0x38 | Size: 0x4
	int32_t ImageWidth; // Offset: 0x3c | Size: 0x4
	int32_t ImageHeight; // Offset: 0x40 | Size: 0x4
	char pad_0x44[0x4]; // Offset: 0x44 | Size: 0x4
	struct FString ImageType; // Offset: 0x48 | Size: 0x10
	struct FString ImageBuffer; // Offset: 0x58 | Size: 0x10
	char pad_0x68[0x10]; // Offset: 0x68 | Size: 0x10
};

// Object: ScriptStruct Solarland.GameplayHitInfo
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FGameplayHitInfo {
	// Fields
	char pad_0x0[0x20]; // Offset: 0x0 | Size: 0x20
};

// Object: ScriptStruct Solarland.AbilityCooldownTimer
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FAbilityCooldownTimer {
	// Fields
	struct FGameplayTag AbilityCooldownTag; // Offset: 0x0 | Size: 0x8
	float AbilityAppliedTime; // Offset: 0x8 | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarIgnoreCollisionTypeData
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FSolarIgnoreCollisionTypeData {
	// Fields
	struct TArray<struct AActor*> Actors; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Solarland.NoticeData
// Inherited Bytes: 0x0 | Struct Size: 0xa0
struct FNoticeData {
	// Fields
	int32_t NoticeId; // Offset: 0x0 | Size: 0x4
	enum class ECustomNoticeType NoticeType; // Offset: 0x4 | Size: 0x1
	char pad_0x5[0x3]; // Offset: 0x5 | Size: 0x3
	float ConfigShowTime; // Offset: 0x8 | Size: 0x4
	float Duration; // Offset: 0xc | Size: 0x4
	struct FString NoticeText; // Offset: 0x10 | Size: 0x10
	enum class ECustomNoticeColor NoticeColor; // Offset: 0x20 | Size: 0x1
	char pad_0x21[0x7]; // Offset: 0x21 | Size: 0x7
	struct FString NoticeClassPath; // Offset: 0x28 | Size: 0x10
	struct FString NoticeIconPath; // Offset: 0x38 | Size: 0x10
	struct TWeakObjectPtr<struct UUINoticeBase> NoticeWidget; // Offset: 0x48 | Size: 0x8
	struct TMap<struct FString, struct FString> Param; // Offset: 0x50 | Size: 0x50
};

// Object: ScriptStruct Solarland.SCMReplicateHostData
// Inherited Bytes: 0x0 | Struct Size: 0x48
struct FSCMReplicateHostData {
	// Fields
	enum class ESCMHostType HostType; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x7]; // Offset: 0x1 | Size: 0x7
	struct FString HostID; // Offset: 0x8 | Size: 0x10
	struct TArray<struct FSCMRepData> RepDataArray; // Offset: 0x18 | Size: 0x10
	struct TArray<struct FSCMRepDataArray> RepArrDataArray; // Offset: 0x28 | Size: 0x10
	struct TArray<struct FSCMRepDataMap> RepMapDataArray; // Offset: 0x38 | Size: 0x10
};

// Object: ScriptStruct Solarland.SCMRepDataMap
// Inherited Bytes: 0x0 | Struct Size: 0x78
struct FSCMRepDataMap {
	// Fields
	struct FString Name; // Offset: 0x0 | Size: 0x10
	enum class ESCMDataType Type; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x7]; // Offset: 0x11 | Size: 0x7
	struct TArray<enum class ESCMDataChangeType> ChangeTypeArray; // Offset: 0x18 | Size: 0x10
	struct TArray<struct FString> KeyArray; // Offset: 0x28 | Size: 0x10
	struct TArray<int32_t> VInt; // Offset: 0x38 | Size: 0x10
	struct TArray<float> VFloat; // Offset: 0x48 | Size: 0x10
	struct TArray<struct FVector_NetQuantize100> VVector; // Offset: 0x58 | Size: 0x10
	struct TArray<struct FString> VString; // Offset: 0x68 | Size: 0x10
};

// Object: ScriptStruct Solarland.SCMRepDataArray
// Inherited Bytes: 0x0 | Struct Size: 0x78
struct FSCMRepDataArray {
	// Fields
	struct FString Name; // Offset: 0x0 | Size: 0x10
	enum class ESCMDataType Type; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x7]; // Offset: 0x11 | Size: 0x7
	struct TArray<enum class ESCMDataChangeType> ChangeTypeArray; // Offset: 0x18 | Size: 0x10
	struct TArray<uint32_t> ChangeIndexArray; // Offset: 0x28 | Size: 0x10
	struct TArray<int32_t> VInt; // Offset: 0x38 | Size: 0x10
	struct TArray<float> VFloat; // Offset: 0x48 | Size: 0x10
	struct TArray<struct FVector_NetQuantize100> VVector; // Offset: 0x58 | Size: 0x10
	struct TArray<struct FString> VString; // Offset: 0x68 | Size: 0x10
};

// Object: ScriptStruct Solarland.SCMRepData
// Inherited Bytes: 0x0 | Struct Size: 0x38
struct FSCMRepData {
	// Fields
	struct FString Name; // Offset: 0x0 | Size: 0x10
	enum class ESCMDataType Type; // Offset: 0x10 | Size: 0x1
	enum class ESCMDataChangeType DataChangeType; // Offset: 0x11 | Size: 0x1
	char pad_0x12[0x2]; // Offset: 0x12 | Size: 0x2
	int32_t VInt; // Offset: 0x14 | Size: 0x4
	float VFloat; // Offset: 0x18 | Size: 0x4
	struct FVector_NetQuantize100 VVector; // Offset: 0x1c | Size: 0xc
	struct FString VString; // Offset: 0x28 | Size: 0x10
};

// Object: ScriptStruct Solarland.BattlePassInfo
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FBattlePassInfo {
	// Fields
	struct TArray<struct FTaskBriefData> tasks; // Offset: 0x0 | Size: 0x10
	int64_t BattlePassID; // Offset: 0x10 | Size: 0x8
	int64_t currWeek; // Offset: 0x18 | Size: 0x8
	int64_t maxWeek; // Offset: 0x20 | Size: 0x8
};

// Object: ScriptStruct Solarland.TaskBriefData
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FTaskBriefData {
	// Fields
	int64_t TaskID; // Offset: 0x0 | Size: 0x8
	int64_t BaseValue; // Offset: 0x8 | Size: 0x8
	int64_t CurValue; // Offset: 0x10 | Size: 0x8
	char pad_0x18[0x8]; // Offset: 0x18 | Size: 0x8
	int64_t status; // Offset: 0x20 | Size: 0x8
	enum class ETaskPage page; // Offset: 0x28 | Size: 0x1
	char pad_0x29[0x7]; // Offset: 0x29 | Size: 0x7
	int64_t week; // Offset: 0x30 | Size: 0x8
	bool IsMarked; // Offset: 0x38 | Size: 0x1
	char pad_0x39[0x7]; // Offset: 0x39 | Size: 0x7
};

// Object: ScriptStruct Solarland.TaskUpdateInfo
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FTaskUpdateInfo {
	// Fields
	bool delAllTask; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x7]; // Offset: 0x1 | Size: 0x7
	struct TArray<int64_t> delIDs; // Offset: 0x8 | Size: 0x10
	struct FBattlePassInfo Task; // Offset: 0x18 | Size: 0x28
	struct FString PlayerId; // Offset: 0x40 | Size: 0x10
};

// Object: ScriptStruct Solarland.WeaponPartsData
// Inherited Bytes: 0x0 | Struct Size: 0x14
struct FWeaponPartsData {
	// Fields
	int32_t ScopeId; // Offset: 0x0 | Size: 0x4
	int32_t GripID; // Offset: 0x4 | Size: 0x4
	int32_t GunStockID; // Offset: 0x8 | Size: 0x4
	int32_t MuzzleID; // Offset: 0xc | Size: 0x4
	int32_t ClipID; // Offset: 0x10 | Size: 0x4
};

// Object: ScriptStruct Solarland.BattlegroundGlobalData
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FBattlegroundGlobalData {
	// Fields
	int32_t MaxBattleTime; // Offset: 0x0 | Size: 0x4
	char WaitingLandCountDownTime; // Offset: 0x4 | Size: 0x1
	char pad_0x5[0x3]; // Offset: 0x5 | Size: 0x3
	float BattlePrepareTime; // Offset: 0x8 | Size: 0x4
	float RebirthWaitTime; // Offset: 0xc | Size: 0x4
	float RebirthInvincibleTime; // Offset: 0x10 | Size: 0x4
	float DeployConfirmTime; // Offset: 0x14 | Size: 0x4
	int32_t BatttleEndLeaveTime; // Offset: 0x18 | Size: 0x4
	float VictoryScore; // Offset: 0x1c | Size: 0x4
	float BonusScorePerSec; // Offset: 0x20 | Size: 0x4
	char pad_0x24[0x4]; // Offset: 0x24 | Size: 0x4
	struct TArray<struct FPersonalScoreData> PersonalScoreArray; // Offset: 0x28 | Size: 0x10
	int32_t AiLevel; // Offset: 0x38 | Size: 0x4
	char pad_0x3C[0x4]; // Offset: 0x3c | Size: 0x4
};

// Object: ScriptStruct Solarland.PersonalScoreData
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FPersonalScoreData {
	// Fields
	enum class EPersonalScoreType ScoreType; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	int32_t Score; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct Solarland.BattlegroundScoreData
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FBattlegroundScoreData {
	// Fields
	enum class EFactionType Faction; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	float Score; // Offset: 0x4 | Size: 0x4
	enum class EMatchResult MatchResult; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x3]; // Offset: 0x9 | Size: 0x3
};

// Object: ScriptStruct Solarland.BattlegroundSubModeData
// Inherited Bytes: 0x0 | Struct Size: 0x1c
struct FBattlegroundSubModeData {
	// Fields
	int32_t SubModeID; // Offset: 0x0 | Size: 0x4
	int32_t MapID; // Offset: 0x4 | Size: 0x4
	struct FVector2D MapCenter; // Offset: 0x8 | Size: 0x8
	float MapFOV; // Offset: 0x10 | Size: 0x4
	struct FVector2D SafeAreaCenter; // Offset: 0x14 | Size: 0x8
};

// Object: ScriptStruct Solarland.BasicUserSettings
// Inherited Bytes: 0x0 | Struct Size: 0x11
struct FBasicUserSettings {
	// Fields
	bool bOpenUniversalMark; // Offset: 0x0 | Size: 0x1
	enum class EBasicSettingBool OpenOffScreen; // Offset: 0x1 | Size: 0x1
	bool bOpenQuickChat; // Offset: 0x2 | Size: 0x1
	bool bAutoOverturn; // Offset: 0x3 | Size: 0x1
	bool bPowerAnim; // Offset: 0x4 | Size: 0x1
	bool bOpenRecruitRecommend; // Offset: 0x5 | Size: 0x1
	enum class ESolarGyroscopeChooseType curGyroscpeChooseLevel; // Offset: 0x6 | Size: 0x1
	bool bHorizontalGyroscopeInvert; // Offset: 0x7 | Size: 0x1
	bool bVerticalGyroscopeInvert; // Offset: 0x8 | Size: 0x1
	enum class ESolarDamageTextDisplayModeType CurrentDamageTextDisplayMode; // Offset: 0x9 | Size: 0x1
	enum class EBasicSettingBool OpenHighlightMoment; // Offset: 0xa | Size: 0x1
	enum class EBasicSettingBool OpenOutline; // Offset: 0xb | Size: 0x1
	bool bShowInputKeyTips; // Offset: 0xc | Size: 0x1
	bool bEnableGamepadInput; // Offset: 0xd | Size: 0x1
	enum class EBasicSettingBool OpenScreenDamageEffect; // Offset: 0xe | Size: 0x1
	bool bOpenMiniMapRotate; // Offset: 0xf | Size: 0x1
	bool bOpenDirectionBlood3D; // Offset: 0x10 | Size: 0x1
};

// Object: ScriptStruct Solarland.CharacterVoiceUserSettings
// Inherited Bytes: 0x0 | Struct Size: 0x1
struct FCharacterVoiceUserSettings {
	// Fields
	enum class ESolarSupportLanguages CurVoiceLanguage; // Offset: 0x0 | Size: 0x1
};

// Object: ScriptStruct Solarland.ChatOperatorUserSettings
// Inherited Bytes: 0x0 | Struct Size: 0x2
struct FChatOperatorUserSettings {
	// Fields
	enum class ESolarChatOperatorType Speaker; // Offset: 0x0 | Size: 0x1
	enum class ESolarChatOperatorType Mic; // Offset: 0x1 | Size: 0x1
};

// Object: ScriptStruct Solarland.VehicleControlUserSettings
// Inherited Bytes: 0x0 | Struct Size: 0x5
struct FVehicleControlUserSettings {
	// Fields
	enum class EWheeledVehicleDriveUserType WheeledVehicleDriveType; // Offset: 0x0 | Size: 0x1
	bool bCanAdjustInAir; // Offset: 0x1 | Size: 0x1
	bool bCanAutoSteering; // Offset: 0x2 | Size: 0x1
	enum class EWheeledVehicleDriveUserType LastWheeledVehicleDriveType; // Offset: 0x3 | Size: 0x1
	bool bCanVehicleCameraShake; // Offset: 0x4 | Size: 0x1
};

// Object: ScriptStruct Solarland.GraphicsUserSettings
// Inherited Bytes: 0x0 | Struct Size: 0x60
struct FGraphicsUserSettings {
	// Fields
	enum class ESolarFrameRateLevel FpsLevel; // Offset: 0x0 | Size: 0x1
	enum class ESolarContentScaleFactorLevel ContentScaleFactorLevel; // Offset: 0x1 | Size: 0x1
	enum class ESolarColorTheme ColorThemeType; // Offset: 0x2 | Size: 0x1
	bool MSAAIsEnabled; // Offset: 0x3 | Size: 0x1
	struct FFloatValue AdaptationUIValue; // Offset: 0x4 | Size: 0x4
	bool EnableDynamicShadow; // Offset: 0x8 | Size: 0x1
	enum class ESolarGraphicsQualityLevel SelectQualityLevel; // Offset: 0x9 | Size: 0x1
	char pad_0xA[0x2]; // Offset: 0xa | Size: 0x2
	struct FFloatValue CustomizedCharacterCameraFOV; // Offset: 0xc | Size: 0x4
	int32_t SavedVersion; // Offset: 0x10 | Size: 0x4
	char pad_0x14[0x4c]; // Offset: 0x14 | Size: 0x4c
};

// Object: ScriptStruct Solarland.FloatValue
// Inherited Bytes: 0x0 | Struct Size: 0x4
struct FFloatValue {
	// Fields
	float Value; // Offset: 0x0 | Size: 0x4
};

// Object: ScriptStruct Solarland.LanguageUserSettings
// Inherited Bytes: 0x0 | Struct Size: 0x3
struct FLanguageUserSettings {
	// Fields
	enum class ESolarSupportLanguages CurLanguage; // Offset: 0x0 | Size: 0x1
	enum class ESolarSupportLanguages CurCharacterVoiceLanguage; // Offset: 0x1 | Size: 0x1
	bool HasLoadedChinese; // Offset: 0x2 | Size: 0x1
};

// Object: ScriptStruct Solarland.PersonalityUserSettings
// Inherited Bytes: 0x0 | Struct Size: 0x88
struct FPersonalityUserSettings {
	// Fields
	struct TArray<struct FColorPreset> TeammatePerspectiveColors; // Offset: 0x0 | Size: 0x10
	struct TArray<struct FColorPreset> OpponentPerspectiveColors; // Offset: 0x10 | Size: 0x10
	struct TArray<struct FParticlePreset> BloodMistColors; // Offset: 0x20 | Size: 0x10
	struct FColorValue TeammatePerspectiveColor; // Offset: 0x30 | Size: 0x10
	struct FColorValue OpponentPerspectiveColor; // Offset: 0x40 | Size: 0x10
	struct TSoftObjectPtr<UParticleSystem> BloodMistParticle; // Offset: 0x50 | Size: 0x28
	int32_t TeammateColor; // Offset: 0x78 | Size: 0x4
	int32_t OpponentColor; // Offset: 0x7c | Size: 0x4
	int32_t BloodMistColor; // Offset: 0x80 | Size: 0x4
	char pad_0x84[0x4]; // Offset: 0x84 | Size: 0x4
};

// Object: ScriptStruct Solarland.ColorValue
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FColorValue {
	// Fields
	struct FLinearColor Value; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Solarland.ParticlePreset
// Inherited Bytes: 0x0 | Struct Size: 0x48
struct FParticlePreset {
	// Fields
	int32_t ColorID; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct TSoftObjectPtr<UParticleSystem> Particle; // Offset: 0x8 | Size: 0x28
	struct FColorValue UIColor; // Offset: 0x30 | Size: 0x10
	int32_t ColorNameLocalText; // Offset: 0x40 | Size: 0x4
	bool bNotShowDomestic; // Offset: 0x44 | Size: 0x1
	bool bDefault; // Offset: 0x45 | Size: 0x1
	bool bDefaultDomestic; // Offset: 0x46 | Size: 0x1
	char pad_0x47[0x1]; // Offset: 0x47 | Size: 0x1
};

// Object: ScriptStruct Solarland.ColorPreset
// Inherited Bytes: 0x0 | Struct Size: 0x2c
struct FColorPreset {
	// Fields
	int32_t ColorID; // Offset: 0x0 | Size: 0x4
	struct FColorValue ModelColor; // Offset: 0x4 | Size: 0x10
	struct FColorValue UIColor; // Offset: 0x14 | Size: 0x10
	int32_t ColorNameLocalText; // Offset: 0x24 | Size: 0x4
	bool bNotShowDomestic; // Offset: 0x28 | Size: 0x1
	bool bDefault; // Offset: 0x29 | Size: 0x1
	bool bDefaultDomestic; // Offset: 0x2a | Size: 0x1
	char pad_0x2B[0x1]; // Offset: 0x2b | Size: 0x1
};

// Object: ScriptStruct Solarland.PickupUserSettings
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FPickupUserSettings {
	// Fields
	bool bAutoPickup; // Offset: 0x0 | Size: 0x1
	bool bStopAutoPickupWhenClose; // Offset: 0x1 | Size: 0x1
	bool bUseTileView; // Offset: 0x2 | Size: 0x1
	char pad_0x3[0x5]; // Offset: 0x3 | Size: 0x5
	struct TArray<struct FPickupItemData> PickupItemList; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct Solarland.PickupItemData
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FPickupItemData {
	// Fields
	int32_t ItemID; // Offset: 0x0 | Size: 0x4
	int32_t ItemNum; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct Solarland.SensitivityUserSettings
// Inherited Bytes: 0x0 | Struct Size: 0x94
struct FSensitivityUserSettings {
	// Fields
	enum class ESolarTouchAccMode Sensitivity_AccMode; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	struct FFloatValue Sensitivity_CurveScale; // Offset: 0x4 | Size: 0x4
	struct FFloatValue Sensitivity_Free; // Offset: 0x8 | Size: 0x4
	struct FFloatValue Sensitivity_SecondarySkills; // Offset: 0xc | Size: 0x4
	struct FFloatValue Sensitivity_SuperSkills; // Offset: 0x10 | Size: 0x4
	struct FCameraSensitivityData Sensitivity_NoShoot; // Offset: 0x14 | Size: 0x20
	struct FCameraSensitivityData Sensitivity_Shoot; // Offset: 0x34 | Size: 0x20
	struct FGyroscopeSensitivityData GyroscopeData; // Offset: 0x54 | Size: 0x20
	struct FFloatValue Sensitivity_VehicleDriver; // Offset: 0x74 | Size: 0x4
	struct FFloatValue Sensitivity_VehicleFire; // Offset: 0x78 | Size: 0x4
	struct FVehicleCameraSensitivityData Sensitivity_Vehicle_NoShoot; // Offset: 0x7c | Size: 0xc
	struct FVehicleCameraSensitivityData Sensitivity_Vehicle_Shoot; // Offset: 0x88 | Size: 0xc
};

// Object: ScriptStruct Solarland.VehicleCameraSensitivityData
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FVehicleCameraSensitivityData {
	// Fields
	struct FFloatValue Sensitivity_Lens_Two; // Offset: 0x0 | Size: 0x4
	struct FFloatValue Sensitivity_Lens_Four; // Offset: 0x4 | Size: 0x4
	struct FFloatValue Sensitivity_Lens_Eight; // Offset: 0x8 | Size: 0x4
};

// Object: ScriptStruct Solarland.GyroscopeSensitivityData
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FGyroscopeSensitivityData {
	// Fields
	struct FFloatValue GyroscopeSensitivity_Basic; // Offset: 0x0 | Size: 0x4
	struct FFloatValue GyroscopeSensitivity_Shoulder; // Offset: 0x4 | Size: 0x4
	struct FFloatValue GyroscopeSensitivity_RedPoint; // Offset: 0x8 | Size: 0x4
	struct FFloatValue GyroscopeSensitivity_Lens_Two; // Offset: 0xc | Size: 0x4
	struct FFloatValue GyroscopeSensitivity_Lens_Three; // Offset: 0x10 | Size: 0x4
	struct FFloatValue GyroscopeSensitivity_Lens_Four; // Offset: 0x14 | Size: 0x4
	struct FFloatValue GyroscopeSensitivity_Lens_Six; // Offset: 0x18 | Size: 0x4
	struct FFloatValue GyroscopeSensitivity_Lens_Eight; // Offset: 0x1c | Size: 0x4
};

// Object: ScriptStruct Solarland.CameraSensitivityData
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FCameraSensitivityData {
	// Fields
	struct FFloatValue Sensitivity_Basic; // Offset: 0x0 | Size: 0x4
	struct FFloatValue Sensitivity_Shoulder; // Offset: 0x4 | Size: 0x4
	struct FFloatValue Sensitivity_RedPoint; // Offset: 0x8 | Size: 0x4
	struct FFloatValue Sensitivity_Lens_Two; // Offset: 0xc | Size: 0x4
	struct FFloatValue Sensitivity_Lens_Three; // Offset: 0x10 | Size: 0x4
	struct FFloatValue Sensitivity_Lens_Four; // Offset: 0x14 | Size: 0x4
	struct FFloatValue Sensitivity_Lens_Six; // Offset: 0x18 | Size: 0x4
	struct FFloatValue Sensitivity_Lens_Eight; // Offset: 0x1c | Size: 0x4
};

// Object: ScriptStruct Solarland.ShakeUserSettings
// Inherited Bytes: 0x0 | Struct Size: 0x1
struct FShakeUserSettings {
	// Fields
	enum class ESolarShakeMainType ShakeMainStatus; // Offset: 0x0 | Size: 0x1
};

// Object: ScriptStruct Solarland.SoundUserSettings
// Inherited Bytes: 0x0 | Struct Size: 0x60
struct FSoundUserSettings {
	// Fields
	struct FConditionValue Sound_Global; // Offset: 0x0 | Size: 0x8
	struct FConditionValue Sound_Action; // Offset: 0x8 | Size: 0x8
	struct FConditionValue Sound_BackGround; // Offset: 0x10 | Size: 0x8
	struct FConditionValue Sound_Character; // Offset: 0x18 | Size: 0x8
	int32_t MicroPhoneVolume; // Offset: 0x20 | Size: 0x4
	int32_t LoudSpeakerVolume; // Offset: 0x24 | Size: 0x4
	enum class ESolarSoundQuality Sound_Quality; // Offset: 0x28 | Size: 0x1
	enum class ESolarAudioMode AudioMode; // Offset: 0x29 | Size: 0x1
	char pad_0x2A[0x2]; // Offset: 0x2a | Size: 0x2
	int32_t MicLevel; // Offset: 0x2c | Size: 0x4
	int32_t SpeakerLevel; // Offset: 0x30 | Size: 0x4
	int32_t ChooseMicIndex; // Offset: 0x34 | Size: 0x4
	int32_t ChooseSpeakerIndex; // Offset: 0x38 | Size: 0x4
	char pad_0x3C[0x4]; // Offset: 0x3c | Size: 0x4
	struct FString MicDeviceID; // Offset: 0x40 | Size: 0x10
	struct FString SpeakerDeviceID; // Offset: 0x50 | Size: 0x10
};

// Object: ScriptStruct Solarland.ConditionValue
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FConditionValue {
	// Fields
	bool bOpen; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	int32_t CurValue; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct Solarland.WeaponUserSettings
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FWeaponUserSettings {
	// Fields
	bool bAimAssist_Global; // Offset: 0x0 | Size: 0x1
	bool bAutoFire_Global; // Offset: 0x1 | Size: 0x1
	bool bVehicleWeaponAutoFire_Global; // Offset: 0x2 | Size: 0x1
	bool bEnableRecoilRecovery_Global; // Offset: 0x3 | Size: 0x1
	bool bAutoScope_Global; // Offset: 0x4 | Size: 0x1
	bool bAutoScope_SpecialButtonGlobal; // Offset: 0x5 | Size: 0x1
	bool bAutoScopeRifle_Global; // Offset: 0x6 | Size: 0x1
	bool bAutoScopeSubmachinegun_Global; // Offset: 0x7 | Size: 0x1
	bool bAutoScopeShotgunSingle_Global; // Offset: 0x8 | Size: 0x1
	bool bAutoScopeShotgunAuto_Global; // Offset: 0x9 | Size: 0x1
	bool bAutoScopeSniperSingle_Global; // Offset: 0xa | Size: 0x1
	bool bAutoScopeSniperAuto_Global; // Offset: 0xb | Size: 0x1
	bool bAutoScopeSpecial_Global; // Offset: 0xc | Size: 0x1
	bool bSniperSingleShootOnPressed_Global; // Offset: 0xd | Size: 0x1
	bool bShotgunSingleShootOnPressed_Global; // Offset: 0xe | Size: 0x1
	char pad_0xF[0x1]; // Offset: 0xf | Size: 0x1
	struct UCurveFloat* HitEffectDistanceToScaleCurve; // Offset: 0x10 | Size: 0x8
	enum class ESolarWeaponDoScopeMode DoScopeMode_Global; // Offset: 0x18 | Size: 0x1
	bool bOpenVehicleWeaponCrosshair; // Offset: 0x19 | Size: 0x1
	bool bVehicleAutoScope; // Offset: 0x1a | Size: 0x1
	bool bVehicleAutoScope_SpecialButton; // Offset: 0x1b | Size: 0x1
	bool bCanScopeButtonRotateView; // Offset: 0x1c | Size: 0x1
	bool bShowQuickChangeScopeButton; // Offset: 0x1d | Size: 0x1
	char pad_0x1E[0x2]; // Offset: 0x1e | Size: 0x2
};

// Object: ScriptStruct Solarland.GraphicsUserSettingsPC
// Inherited Bytes: 0x0 | Struct Size: 0xa8
struct FGraphicsUserSettingsPC {
	// Fields
	enum class ESolarResolution Resolution; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x7]; // Offset: 0x1 | Size: 0x7
	struct UDataTable* ResolutionDataTable; // Offset: 0x8 | Size: 0x8
	enum class ESolarMonitor Monitor; // Offset: 0x10 | Size: 0x1
	enum class ESolarFPS Fps; // Offset: 0x11 | Size: 0x1
	enum class ESolarGraphicsMode GraphicsMode; // Offset: 0x12 | Size: 0x1
	char pad_0x13[0x1]; // Offset: 0x13 | Size: 0x1
	struct FFloatValue Brightness; // Offset: 0x14 | Size: 0x4
	enum class ESolarGraphicQuality ROV; // Offset: 0x18 | Size: 0x1
	enum class ESolarNvdiaReflexLevel NvdiaReflex; // Offset: 0x19 | Size: 0x1
	enum class ESolarRayTracingLevel RayTracing; // Offset: 0x1a | Size: 0x1
	bool VSync; // Offset: 0x1b | Size: 0x1
	enum class ESolarMotionBlurLevel MotionBlur; // Offset: 0x1c | Size: 0x1
	enum class ESolarAntiAliasingLevel AntiAliasing; // Offset: 0x1d | Size: 0x1
	enum class ESolarAnisotropicFilterLevel AnisotropicFiltering; // Offset: 0x1e | Size: 0x1
	enum class ESolarGraphicQuality TextureQuality; // Offset: 0x1f | Size: 0x1
	enum class ESolarGraphicQuality TextureModel; // Offset: 0x20 | Size: 0x1
	enum class ESolarGraphicQuality DetailQuality; // Offset: 0x21 | Size: 0x1
	enum class ESolarGraphicQuality VisualEffects; // Offset: 0x22 | Size: 0x1
	char pad_0x23[0x1]; // Offset: 0x23 | Size: 0x1
	struct FFloatValue SunlightShadowRange; // Offset: 0x24 | Size: 0x4
	enum class ESolarSunlightShadowDetailLevel SunlightShadowDetails; // Offset: 0x28 | Size: 0x1
	char pad_0x29[0x7]; // Offset: 0x29 | Size: 0x7
	struct UDataTable* ShadowDetailLevelDataTable; // Offset: 0x30 | Size: 0x8
	enum class ESolarMaxCSMResolutionLevel MaxCSMResolutionLevel; // Offset: 0x38 | Size: 0x1
	enum class ESolarPointLightShadowDetailsLevel PointLightShadowDetails; // Offset: 0x39 | Size: 0x1
	enum class ESolarAmbientOcclusionQualityLevel AmbientOcclusionQuality; // Offset: 0x3a | Size: 0x1
	enum class ESolarSSGIQualityLevel SSGIQuality; // Offset: 0x3b | Size: 0x1
	enum class ESolarReflectionQualityLevel Reflection; // Offset: 0x3c | Size: 0x1
	bool VolumetricLighting; // Offset: 0x3d | Size: 0x1
	bool DynamicVolumetricShadows; // Offset: 0x3e | Size: 0x1
	enum class ESolarPostProcessingEffectsLevel PostProcessingEffects; // Offset: 0x3f | Size: 0x1
	enum class ESolarRenderingResolutionScaleLevel RenderingResolutionScale; // Offset: 0x40 | Size: 0x1
	enum class ESolarGraphicQuality GrassDensity; // Offset: 0x41 | Size: 0x1
	enum class ESolarColorBlindMode ColorBlindMode; // Offset: 0x42 | Size: 0x1
	char pad_0x43[0x1]; // Offset: 0x43 | Size: 0x1
	float ScreenPercentageScale; // Offset: 0x44 | Size: 0x4
	char pad_0x48[0x60]; // Offset: 0x48 | Size: 0x60
};

// Object: ScriptStruct Solarland.GamepadAdvancedSettings
// Inherited Bytes: 0x0 | Struct Size: 0x3c
struct FGamepadAdvancedSettings {
	// Fields
	struct FRangeData ScalerRange; // Offset: 0x0 | Size: 0x8
	struct FRangeData SpeedUpScalerRange; // Offset: 0x8 | Size: 0x8
	struct FRangeData SpeedUpDelayRange; // Offset: 0x10 | Size: 0x8
	struct FRangeData SpeedUpStartRange; // Offset: 0x18 | Size: 0x8
	struct FFloatValue ScalerX; // Offset: 0x20 | Size: 0x4
	struct FFloatValue ScalerY; // Offset: 0x24 | Size: 0x4
	struct FFloatValue SpeedUpScalerX; // Offset: 0x28 | Size: 0x4
	struct FFloatValue SpeedUpScalerY; // Offset: 0x2c | Size: 0x4
	struct FFloatValue SpeedUpDelayTime; // Offset: 0x30 | Size: 0x4
	struct FFloatValue SpeedUpStartTime; // Offset: 0x34 | Size: 0x4
	bool bEnableAdsSpeedUp; // Offset: 0x38 | Size: 0x1
	char pad_0x39[0x3]; // Offset: 0x39 | Size: 0x3
};

// Object: ScriptStruct Solarland.RangeData
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FRangeData {
	// Fields
	float MinValue; // Offset: 0x0 | Size: 0x4
	float MaxValue; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct Solarland.GamepadSettings
// Inherited Bytes: 0x0 | Struct Size: 0xe0
struct FGamepadSettings {
	// Fields
	struct TArray<struct FSolarAimModeWithLocalText> AimModeMap; // Offset: 0x0 | Size: 0x10
	struct TArray<struct FSolarSprintModeWithLocalText> SprintModeMap; // Offset: 0x10 | Size: 0x10
	struct TArray<struct FFloatWithLocalText> ViewSensitivityMap; // Offset: 0x20 | Size: 0x10
	struct TArray<struct FObjectWithLocalText> ResponseCurveMap; // Offset: 0x30 | Size: 0x10
	struct TArray<struct FFloatWithLocalText> LeftStickDeadzoneMap; // Offset: 0x40 | Size: 0x10
	struct TArray<struct FFloatWithLocalText> RightStickDeadzoneMap; // Offset: 0x50 | Size: 0x10
	struct TArray<struct FFloatWithLocalText> TriggerDeadzoneMap; // Offset: 0x60 | Size: 0x10
	struct TArray<struct FFloatWithLocalText> VibrationLevelMap; // Offset: 0x70 | Size: 0x10
	struct FRangeData CursorSpeedRange; // Offset: 0x80 | Size: 0x8
	struct TArray<struct FSolarWheelModeTypeWithLocalText> WheelModeTypeMap; // Offset: 0x88 | Size: 0x10
	int32_t AimModeID; // Offset: 0x98 | Size: 0x4
	int32_t SprintModeID; // Offset: 0x9c | Size: 0x4
	struct FConditionValue MainHorizontalSensitivity; // Offset: 0xa0 | Size: 0x8
	struct FConditionValue MainVerticalSensitivity; // Offset: 0xa8 | Size: 0x8
	int32_t RightStickSensitivityID; // Offset: 0xb0 | Size: 0x4
	int32_t RightStickResponseCurveID; // Offset: 0xb4 | Size: 0x4
	bool bInvertedLook; // Offset: 0xb8 | Size: 0x1
	char pad_0xB9[0x3]; // Offset: 0xb9 | Size: 0x3
	int32_t LeftStickDeadzoneID; // Offset: 0xbc | Size: 0x4
	int32_t RightStickDeadzoneID; // Offset: 0xc0 | Size: 0x4
	int32_t TriggerDeadzoneID; // Offset: 0xc4 | Size: 0x4
	struct FFloatValue CursorSpeed; // Offset: 0xc8 | Size: 0x4
	int32_t VibrationLevelID; // Offset: 0xcc | Size: 0x4
	bool bEnableAimAssist; // Offset: 0xd0 | Size: 0x1
	bool bEnableClassicWheeledVehicleControlMode; // Offset: 0xd1 | Size: 0x1
	char pad_0xD2[0x2]; // Offset: 0xd2 | Size: 0x2
	int32_t MedicWheelModeID; // Offset: 0xd4 | Size: 0x4
	int32_t EmojiWheelModeID; // Offset: 0xd8 | Size: 0x4
	char pad_0xDC[0x4]; // Offset: 0xdc | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarWheelModeTypeWithLocalText
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FSolarWheelModeTypeWithLocalText {
	// Fields
	int32_t LocalText; // Offset: 0x0 | Size: 0x4
	enum class ESolarWheelModeType WheelPadMode; // Offset: 0x4 | Size: 0x1
	char pad_0x5[0x3]; // Offset: 0x5 | Size: 0x3
};

// Object: ScriptStruct Solarland.FloatWithLocalText
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FFloatWithLocalText {
	// Fields
	int32_t LocalText; // Offset: 0x0 | Size: 0x4
	float Value; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct Solarland.ObjectWithLocalText
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FObjectWithLocalText {
	// Fields
	int32_t LocalText; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct FSoftObjectPath ObjectPath; // Offset: 0x8 | Size: 0x18
};

// Object: ScriptStruct Solarland.SolarSprintModeWithLocalText
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FSolarSprintModeWithLocalText {
	// Fields
	int32_t LocalText; // Offset: 0x0 | Size: 0x4
	enum class ESolarSprintModeType SprintMode; // Offset: 0x4 | Size: 0x1
	char pad_0x5[0x3]; // Offset: 0x5 | Size: 0x3
};

// Object: ScriptStruct Solarland.SolarAimModeWithLocalText
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FSolarAimModeWithLocalText {
	// Fields
	int32_t LocalText; // Offset: 0x0 | Size: 0x4
	enum class ESolarWeaponDoScopeMode AimMode; // Offset: 0x4 | Size: 0x1
	char pad_0x5[0x3]; // Offset: 0x5 | Size: 0x3
};

// Object: ScriptStruct Solarland.MouseAndKeyboardSettings
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FMouseAndKeyboardSettings {
	// Fields
	struct FFloatValue MainSensitivity; // Offset: 0x0 | Size: 0x4
	bool bMouseInvert; // Offset: 0x4 | Size: 0x1
	enum class ESolarWeaponDoScopeMode AimMode; // Offset: 0x5 | Size: 0x1
	enum class ESolarSprintModeType SprintMode; // Offset: 0x6 | Size: 0x1
	enum class ESolarWheelModeType MedicWheelMode; // Offset: 0x7 | Size: 0x1
	enum class ESolarWheelModeType EmojiWheelMode; // Offset: 0x8 | Size: 0x1
	enum class ESolarITemHUDStyle CurrentItemHUDStyle; // Offset: 0x9 | Size: 0x1
	char pad_0xA[0x2]; // Offset: 0xa | Size: 0x2
};

// Object: ScriptStruct Solarland.DownloadFileInfo
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FDownloadFileInfo {
	// Fields
	struct FString URL; // Offset: 0x0 | Size: 0x10
	struct FString Filename; // Offset: 0x10 | Size: 0x10
	struct FString HashStr; // Offset: 0x20 | Size: 0x10
};

// Object: ScriptStruct Solarland.LocalFileInfo
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FLocalFileInfo {
	// Fields
	struct FString Dir; // Offset: 0x0 | Size: 0x10
	struct FString Filename; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct Solarland.ScreenEffectGroup
// Inherited Bytes: 0x0 | Struct Size: 0x60
struct FScreenEffectGroup {
	// Fields
	struct TMap<int32_t, struct FScreenEffectInstance> InstantScreenEffects; // Offset: 0x0 | Size: 0x50
	struct TArray<struct FScreenEffectInstance> DurationScreenEffects; // Offset: 0x50 | Size: 0x10
};

// Object: ScriptStruct Solarland.ScreenEffectInstance
// Inherited Bytes: 0x0 | Struct Size: 0x98
struct FScreenEffectInstance {
	// Fields
	char pad_0x0[0x98]; // Offset: 0x0 | Size: 0x98
};

// Object: ScriptStruct Solarland.BuffEffectActorElemPool
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FBuffEffectActorElemPool {
	// Fields
	struct TArray<struct UBuffEffectActorElem*> PoolInstances; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Solarland.BuffParticleEffectInstance
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FBuffParticleEffectInstance {
	// Fields
	char pad_0x0[0x20]; // Offset: 0x0 | Size: 0x20
	struct TArray<struct UBuffEffectActorElem*> AttachElemList; // Offset: 0x20 | Size: 0x10
};

// Object: ScriptStruct Solarland.BuffParticleEffectGroup
// Inherited Bytes: 0x0 | Struct Size: 0xb0
struct FBuffParticleEffectGroup {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
	struct TMap<struct FName, struct FBuffEffectActorElemList> InstantActorListMap; // Offset: 0x8 | Size: 0x50
	char pad_0x58[0x8]; // Offset: 0x58 | Size: 0x8
	struct TMap<struct FName, struct FBuffEffectActorElemList> DurationActorListMap; // Offset: 0x60 | Size: 0x50
};

// Object: ScriptStruct Solarland.BuffEffectActorElemList
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FBuffEffectActorElemList {
	// Fields
	struct TArray<struct UBuffEffectActorElem*> ElemList; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Solarland.InputKeyMappingEntry
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FInputKeyMappingEntry {
	// Fields
	bool bValid; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x7]; // Offset: 0x1 | Size: 0x7
	struct FString ActionID; // Offset: 0x8 | Size: 0x10
	struct FString ActionName; // Offset: 0x18 | Size: 0x10
	enum class ESolarTablesEnum_InputActionType ActionType; // Offset: 0x28 | Size: 0x1
	char pad_0x29[0x3]; // Offset: 0x29 | Size: 0x3
	float Scale; // Offset: 0x2c | Size: 0x4
	struct TArray<struct FInputKeyMappingPair> KeyMappingPairList; // Offset: 0x30 | Size: 0x10
};

// Object: ScriptStruct Solarland.InputKeyMappingPair
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FInputKeyMappingPair {
	// Fields
	struct FString KeyStr1; // Offset: 0x0 | Size: 0x10
	struct FString KeyStr2; // Offset: 0x10 | Size: 0x10
	enum class ESolarTablesEnum_InputTriggerType TriggerType; // Offset: 0x20 | Size: 0x1
	char pad_0x21[0x7]; // Offset: 0x21 | Size: 0x7
};

// Object: ScriptStruct Solarland.InputDeviceProxy
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FInputDeviceProxy {
	// Fields
	enum class ECommonInputType InputType; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	struct FName GamepadType; // Offset: 0x4 | Size: 0x8
};

// Object: ScriptStruct Solarland.ItemCountsList
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FItemCountsList {
	// Fields
	struct TMap<enum class EPickupItemType, int32_t> Type2IntMap; // Offset: 0x0 | Size: 0x50
};

// Object: ScriptStruct Solarland.InteractionTriggerInfo
// Inherited Bytes: 0x0 | Struct Size: 0x38
struct FInteractionTriggerInfo {
	// Fields
	struct FGameplayTag GameplayTag; // Offset: 0x0 | Size: 0x8
	char pad_0x8[0x30]; // Offset: 0x8 | Size: 0x30
};

// Object: ScriptStruct Solarland.HUDNoticeParams
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FHUDNoticeParams {
	// Fields
	struct TMap<struct FString, struct FString> Params; // Offset: 0x0 | Size: 0x50
};

// Object: ScriptStruct Solarland.CountDownInfo
// Inherited Bytes: 0x0 | Struct Size: 0x48
struct FCountDownInfo {
	// Fields
	int32_t TextID; // Offset: 0x0 | Size: 0x4
	float Time; // Offset: 0x4 | Size: 0x4
	float RemainingTime; // Offset: 0x8 | Size: 0x4
	bool bShowBtn; // Offset: 0xc | Size: 0x1
	char pad_0xD[0x3]; // Offset: 0xd | Size: 0x3
	int32_t PassiveTextID; // Offset: 0x10 | Size: 0x4
	struct FGameplayTag GameplayTag; // Offset: 0x14 | Size: 0x8
	char pad_0x1C[0x24]; // Offset: 0x1c | Size: 0x24
	int32_t ContributorCharacterId; // Offset: 0x40 | Size: 0x4
	enum class ECountDownState State; // Offset: 0x44 | Size: 0x1
	char pad_0x45[0x3]; // Offset: 0x45 | Size: 0x3
};

// Object: ScriptStruct Solarland.KillInfo
// Inherited Bytes: 0x0 | Struct Size: 0x98
struct FKillInfo {
	// Fields
	struct FString KillerPlayerId; // Offset: 0x0 | Size: 0x10
	int32_t KillerSkinID; // Offset: 0x10 | Size: 0x4
	int32_t KillerTeamID; // Offset: 0x14 | Size: 0x4
	struct FString KillerName; // Offset: 0x18 | Size: 0x10
	int32_t KillerFlag; // Offset: 0x28 | Size: 0x4
	char pad_0x2C[0x4]; // Offset: 0x2c | Size: 0x4
	struct FString VictimPlayerID; // Offset: 0x30 | Size: 0x10
	int32_t VictimSkinID; // Offset: 0x40 | Size: 0x4
	int32_t VictimTeamID; // Offset: 0x44 | Size: 0x4
	struct FString VictimName; // Offset: 0x48 | Size: 0x10
	int32_t VictimFlag; // Offset: 0x58 | Size: 0x4
	char pad_0x5C[0x4]; // Offset: 0x5c | Size: 0x4
	struct FString KillIcon; // Offset: 0x60 | Size: 0x10
	struct FString KillLeaderID; // Offset: 0x70 | Size: 0x10
	enum class EKillParamsCompressInfo KillParamsCompressInfo; // Offset: 0x80 | Size: 0x2
	char pad_0x82[0x2]; // Offset: 0x82 | Size: 0x2
	int32_t KillNum; // Offset: 0x84 | Size: 0x4
	int32_t WeaponSkinID; // Offset: 0x88 | Size: 0x4
	char KillerVipType; // Offset: 0x8c | Size: 0x1
	char VictimVipType; // Offset: 0x8d | Size: 0x1
	enum class ECommonInputType KillerInputType; // Offset: 0x8e | Size: 0x1
	enum class ECommonInputType VictimInputType; // Offset: 0x8f | Size: 0x1
	bool bDown; // Offset: 0x90 | Size: 0x1
	bool bPlayComboKillSoundEffect; // Offset: 0x91 | Size: 0x1
	char pad_0x92[0x2]; // Offset: 0x92 | Size: 0x2
	int32_t KillReportID; // Offset: 0x94 | Size: 0x4
};

// Object: ScriptStruct Solarland.PlayAnimationParams
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FPlayAnimationParams {
	// Fields
	char pad_0x0[0x40]; // Offset: 0x0 | Size: 0x40
};

// Object: ScriptStruct Solarland.BattleUpgradeEffectCategoryColorSet
// Inherited Bytes: 0x0 | Struct Size: 0x60
struct FBattleUpgradeEffectCategoryColorSet {
	// Fields
	struct FLinearColor BannerCategoryTextColor; // Offset: 0x0 | Size: 0x10
	struct FLinearColor BannerIconColor; // Offset: 0x10 | Size: 0x10
	struct FLinearColor BannerBorderColor; // Offset: 0x20 | Size: 0x10
	struct FLinearColor BannerBackgroundColor; // Offset: 0x30 | Size: 0x10
	struct FLinearColor BadgeIconColor; // Offset: 0x40 | Size: 0x10
	struct FLinearColor BadgeBackgroundColor; // Offset: 0x50 | Size: 0x10
};

// Object: ScriptStruct Solarland.ElectricShopItem
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FElectricShopItem {
	// Fields
	int32_t ItemID; // Offset: 0x0 | Size: 0x4
	float Prize; // Offset: 0x4 | Size: 0x4
	int32_t Num; // Offset: 0x8 | Size: 0x4
	int32_t ProductID; // Offset: 0xc | Size: 0x4
	float CoolDown; // Offset: 0x10 | Size: 0x4
	int32_t Generation; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct Solarland.ActionWheelConfig
// Inherited Bytes: 0x8 | Struct Size: 0xe0
struct FActionWheelConfig : FTableRowBase {
	// Fields
	int32_t groupid; // Offset: 0x8 | Size: 0x4
	struct FWrappedLocalTextID Title; // Offset: 0xc | Size: 0x4
	int32_t StyleID; // Offset: 0x10 | Size: 0x4
	char pad_0x14[0x4]; // Offset: 0x14 | Size: 0x4
	struct FString WheelDes; // Offset: 0x18 | Size: 0x10
	float DisplayDelay; // Offset: 0x28 | Size: 0x4
	float DisplayDelay_Gamepad; // Offset: 0x2c | Size: 0x4
	float PointMoveSensitivity; // Offset: 0x30 | Size: 0x4
	float PointMoveSensitivity_Gamepad; // Offset: 0x34 | Size: 0x4
	struct FVector2D Offset; // Offset: 0x38 | Size: 0x8
	struct UActionWheelWidgetFunctionBase* WheelFunctionBP; // Offset: 0x40 | Size: 0x8
	struct FString InputActionName; // Offset: 0x48 | Size: 0x10
	enum class EActionWheelOperateType OperateType; // Offset: 0x58 | Size: 0x1
	char pad_0x59[0x3]; // Offset: 0x59 | Size: 0x3
	struct FActionWheelStyle ActionWheelStyle; // Offset: 0x5c | Size: 0x70
	char pad_0xCC[0x4]; // Offset: 0xcc | Size: 0x4
	struct TArray<struct FActionWheelCommand> ActionWheelCommands; // Offset: 0xd0 | Size: 0x10
};

// Object: ScriptStruct Solarland.ActionWheelCommand
// Inherited Bytes: 0x0 | Struct Size: 0x38
struct FActionWheelCommand {
	// Fields
	enum class EActionWheelCommandType CommandType; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x7]; // Offset: 0x1 | Size: 0x7
	struct FString ConfigKey; // Offset: 0x8 | Size: 0x10
	struct FWrappedLocalTextID DisplayName; // Offset: 0x18 | Size: 0x4
	char pad_0x1C[0x4]; // Offset: 0x1c | Size: 0x4
	struct FSoftObjectPath Icon; // Offset: 0x20 | Size: 0x18
};

// Object: ScriptStruct Solarland.WrappedLocalTextID
// Inherited Bytes: 0x0 | Struct Size: 0x4
struct FWrappedLocalTextID {
	// Fields
	int32_t LocalTextId; // Offset: 0x0 | Size: 0x4
};

// Object: ScriptStruct Solarland.ActionWheelStyle
// Inherited Bytes: 0x0 | Struct Size: 0x70
struct FActionWheelStyle {
	// Fields
	struct FLinearColor BlackgroundColor; // Offset: 0x0 | Size: 0x10
	struct FLinearColor InnerCircleColor; // Offset: 0x10 | Size: 0x10
	struct FLinearColor BlackgroundSelectedColor; // Offset: 0x20 | Size: 0x10
	struct FLinearColor InnerCircleSelectedColor; // Offset: 0x30 | Size: 0x10
	struct FLinearColor WheelGradientColor; // Offset: 0x40 | Size: 0x10
	struct FLinearColor WheelSelectedGradientColor; // Offset: 0x50 | Size: 0x10
	struct FVector2D IconSize; // Offset: 0x60 | Size: 0x8
	float IconOffset; // Offset: 0x68 | Size: 0x4
	float SelectedIconOffset; // Offset: 0x6c | Size: 0x4
};

// Object: ScriptStruct Solarland.ActorEffectControllerPool
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FActorEffectControllerPool {
	// Fields
	struct TArray<struct UActorEffectController*> ControllerInstances; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Solarland.ActorEffectPool
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FActorEffectPool {
	// Fields
	struct TArray<struct UActorEffect*> EffectInstances; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Solarland.MaterialFilter
// Inherited Bytes: 0x0 | Struct Size: 0x48
struct FMaterialFilter {
	// Fields
	bool bIgnoreChangeability; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x7]; // Offset: 0x1 | Size: 0x7
	struct TArray<struct UMeshComponent*> IncludingMeshes; // Offset: 0x8 | Size: 0x10
	struct TArray<int32_t> IncludingMaterialIndices; // Offset: 0x18 | Size: 0x10
	struct TArray<struct UMeshComponent*> ExcludingMeshes; // Offset: 0x28 | Size: 0x10
	struct TArray<int32_t> ExcludingMaterialIndices; // Offset: 0x38 | Size: 0x10
};

// Object: ScriptStruct Solarland.MaterialChangeHandle
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FMaterialChangeHandle {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
};

// Object: ScriptStruct Solarland.MultiplePassMaterialChange
// Inherited Bytes: 0x0 | Struct Size: 0x68
struct FMultiplePassMaterialChange {
	// Fields
	struct TSoftObjectPtr<UMaterialInterface> SourceMaterial; // Offset: 0x0 | Size: 0x28
	struct FAddMultiplePassMaterialChangeParams Params; // Offset: 0x28 | Size: 0x40
};

// Object: ScriptStruct Solarland.NormalMaterialChange
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FNormalMaterialChange {
	// Fields
	struct TSoftObjectPtr<UMaterialInterface> SourceMaterial; // Offset: 0x0 | Size: 0x28
	struct FAddMaterialChangeParams Params; // Offset: 0x28 | Size: 0x28
};

// Object: ScriptStruct Solarland.AddMaterialChangeParams
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FAddMaterialChangeParams {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
	struct FGameplayTag PriorityTag; // Offset: 0x8 | Size: 0x8
	enum class EMaterialChangeConflictResolveStrategy ResolveStrategy; // Offset: 0x10 | Size: 0x1
	enum class EMaterialChangeTextureOverrideMode TextureOverrideMode; // Offset: 0x11 | Size: 0x1
	char pad_0x12[0x6]; // Offset: 0x12 | Size: 0x6
	struct TArray<struct FName> TextureParameterNamesToOverride; // Offset: 0x18 | Size: 0x10
};

// Object: ScriptStruct Solarland.MaterialChangePriorityGroup
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FMaterialChangePriorityGroup {
	// Fields
	struct TArray<struct FGameplayTag> Tags; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Solarland.ForceChangeMaterialInfos
// Inherited Bytes: 0x0 | Struct Size: 0x70
struct FForceChangeMaterialInfos {
	// Fields
	struct FGameplayTagContainer MaterialPriorityTags; // Offset: 0x0 | Size: 0x20
	struct TSet<struct FSoftObjectPath> MaterialPaths; // Offset: 0x20 | Size: 0x50
};

// Object: ScriptStruct Solarland.MaterialParameterFilter
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FMaterialParameterFilter {
	// Fields
	struct TArray<struct FName> IncludingNames; // Offset: 0x0 | Size: 0x10
	struct TArray<struct FName> ExcludingNames; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct Solarland.ActorMaterialInfo
// Inherited Bytes: 0x0 | Struct Size: 0x170
struct FActorMaterialInfo {
	// Fields
	char pad_0x0[0x20]; // Offset: 0x0 | Size: 0x20
	struct TMap<struct FMaterialChangeHandle, struct UMaterialInterface*> SourceMaterials; // Offset: 0x20 | Size: 0x50
	struct TMap<struct FMaterialChangeHandle, struct FAddMaterialChangeParams> NormalParams; // Offset: 0x70 | Size: 0x50
	struct TMap<struct FMaterialChangeHandle, struct FAddMultiplePassMaterialChangeParams> MultiplePassParams; // Offset: 0xc0 | Size: 0x50
	struct TMap<struct FMaterialChangeHandle, struct FLimitedMeshContainer> LimitedMeshes; // Offset: 0x110 | Size: 0x50
	struct TArray<struct FMeshMaterialInfo> MeshMaterials; // Offset: 0x160 | Size: 0x10
};

// Object: ScriptStruct Solarland.MeshMaterialInfo
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FMeshMaterialInfo {
	// Fields
	char pad_0x0[0x18]; // Offset: 0x0 | Size: 0x18
	struct TArray<struct FMaterialChange> NormalMaterialChanges; // Offset: 0x18 | Size: 0x10
	char pad_0x28[0x18]; // Offset: 0x28 | Size: 0x18
	struct TArray<struct FMaterialChange> MultiplePassMaterialChanges; // Offset: 0x40 | Size: 0x10
};

// Object: ScriptStruct Solarland.MaterialChange
// Inherited Bytes: 0x0 | Struct Size: 0x38
struct FMaterialChange {
	// Fields
	char pad_0x0[0x28]; // Offset: 0x0 | Size: 0x28
	struct TArray<struct UMaterialInterface*> Materials; // Offset: 0x28 | Size: 0x10
};

// Object: ScriptStruct Solarland.LimitedMeshContainer
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FLimitedMeshContainer {
	// Fields
	struct TArray<struct UMeshComponent*> Meshes; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Solarland.ActorParticleEffectSpawnHandle
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FActorParticleEffectSpawnHandle {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
};

// Object: ScriptStruct Solarland.ActorParticleEffectSpawnInfo
// Inherited Bytes: 0x0 | Struct Size: 0x70
struct FActorParticleEffectSpawnInfo {
	// Fields
	struct TSoftObjectPtr<UParticleSystem> ParticleSystem; // Offset: 0x0 | Size: 0x28
	enum class EActorParticleEffectAttachOption AttachOption; // Offset: 0x28 | Size: 0x1
	char pad_0x29[0x3]; // Offset: 0x29 | Size: 0x3
	struct FName AttachPointName; // Offset: 0x2c | Size: 0x8
	enum class EAttachLocation LocationType; // Offset: 0x34 | Size: 0x1
	char pad_0x35[0x3]; // Offset: 0x35 | Size: 0x3
	struct FVector Location; // Offset: 0x38 | Size: 0xc
	struct FRotator Rotation; // Offset: 0x44 | Size: 0xc
	struct FVector Scale; // Offset: 0x50 | Size: 0xc
	bool bAutoActivate; // Offset: 0x5c | Size: 0x1
	bool bAutoDestroy; // Offset: 0x5d | Size: 0x1
	bool bEnablePooling; // Offset: 0x5e | Size: 0x1
	bool bAbsoluteRotation; // Offset: 0x5f | Size: 0x1
	struct TArray<struct FName> ComponentTags; // Offset: 0x60 | Size: 0x10
};

// Object: ScriptStruct Solarland.WrappedLevelToIdMap
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FWrappedLevelToIdMap {
	// Fields
	struct TMap<int32_t, int32_t> LevelToId; // Offset: 0x0 | Size: 0x50
};

// Object: ScriptStruct Solarland.AirDropAllOutcomeConfigArray
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FAirDropAllOutcomeConfigArray {
	// Fields
	struct TArray<struct FAirDropAllOutcomeConfig> OutcomesOverTime; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Solarland.AirDropAllOutcomeConfig
// Inherited Bytes: 0x0 | Struct Size: 0x68
struct FAirDropAllOutcomeConfig {
	// Fields
	float GameSeconds; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct FAirDropShieldOutcomeConfig ShieldOutcome; // Offset: 0x8 | Size: 0x18
	struct FAirDropWeaponPartOutcomeConfig WeaponPartOutcome; // Offset: 0x20 | Size: 0x20
	struct FAirDropSupplyOutcomeConfig SupplyOutcome; // Offset: 0x40 | Size: 0x18
	struct TArray<struct FWrappedIdCount> GeneralOutcome; // Offset: 0x58 | Size: 0x10
};

// Object: ScriptStruct Solarland.WrappedIdCount
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FWrappedIdCount {
	// Fields
	int32_t ID; // Offset: 0x0 | Size: 0x4
	int32_t count; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct Solarland.AirDropSupplyOutcomeConfig
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FAirDropSupplyOutcomeConfig {
	// Fields
	int32_t count; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct TArray<struct FWrappedIdCount> CompensationItems; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct Solarland.AirDropWeaponPartOutcomeConfig
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FAirDropWeaponPartOutcomeConfig {
	// Fields
	int32_t count; // Offset: 0x0 | Size: 0x4
	int32_t MinLevel; // Offset: 0x4 | Size: 0x4
	int32_t ScopeMinLevel; // Offset: 0x8 | Size: 0x4
	int32_t MaxLevel; // Offset: 0xc | Size: 0x4
	struct TArray<struct FWrappedIdCount> CompensationOutcomes; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct Solarland.AirDropShieldOutcomeConfig
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FAirDropShieldOutcomeConfig {
	// Fields
	int32_t MinLevel; // Offset: 0x0 | Size: 0x4
	int32_t MaxLevel; // Offset: 0x4 | Size: 0x4
	struct TArray<struct FWrappedIdCount> CompensationOutcomes; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct Solarland.AirDropSkillDatas
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FAirDropSkillDatas {
	// Fields
	struct TArray<struct FAirDropSkillData> OutcomeSetting; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Solarland.AirDropSkillData
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FAirDropSkillData {
	// Fields
	float GameSeconds; // Offset: 0x0 | Size: 0x4
	int32_t OutcomeID; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct Solarland.MapAirlineData
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FMapAirlineData {
	// Fields
	int32_t MapID; // Offset: 0x0 | Size: 0x4
	float Height; // Offset: 0x4 | Size: 0x4
	float Speed; // Offset: 0x8 | Size: 0x4
	char pad_0xC[0x4]; // Offset: 0xc | Size: 0x4
	struct TArray<struct FAirlineData> AirlineDataList; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct Solarland.AirlineData
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FAirlineData {
	// Fields
	float AirlineHeight; // Offset: 0x0 | Size: 0x4
	float AirlineSpeed; // Offset: 0x4 | Size: 0x4
	struct FVector2D StartPoint; // Offset: 0x8 | Size: 0x8
	struct FVector2D EndPoint; // Offset: 0x10 | Size: 0x8
	struct FVector2D RealStartPoint; // Offset: 0x18 | Size: 0x8
	struct FVector2D RealEndPoint; // Offset: 0x20 | Size: 0x8
};

// Object: ScriptStruct Solarland.FireChargeData
// Inherited Bytes: 0x0 | Struct Size: 0xc0
struct FFireChargeData {
	// Fields
	bool IfContinuousCharge; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	float ChargeTime; // Offset: 0x4 | Size: 0x4
	struct UCurveFloat* ChargeDamageRadiusCurve; // Offset: 0x8 | Size: 0x8
	struct UCurveFloat* ChargeDamageMagnificationCurve; // Offset: 0x10 | Size: 0x8
	bool IfPenetrable; // Offset: 0x18 | Size: 0x1
	char pad_0x19[0x7]; // Offset: 0x19 | Size: 0x7
	struct UAmmoConfig* OverrideAmmo; // Offset: 0x20 | Size: 0x8
	int32_t OverrideAmmoID; // Offset: 0x28 | Size: 0x4
	char pad_0x2C[0x4]; // Offset: 0x2c | Size: 0x4
	struct FString ChargeSoundName; // Offset: 0x30 | Size: 0x10
	struct FString ChargeSoundEnemyName; // Offset: 0x40 | Size: 0x10
	struct FString FireSoundName; // Offset: 0x50 | Size: 0x10
	struct FString FireSoundEnemyName; // Offset: 0x60 | Size: 0x10
	bool IfBurst; // Offset: 0x70 | Size: 0x1
	char pad_0x71[0x7]; // Offset: 0x71 | Size: 0x7
	struct UCurveFloat* BulletBurstCountCurve; // Offset: 0x78 | Size: 0x8
	bool IfCostToChargeScale; // Offset: 0x80 | Size: 0x1
	char pad_0x81[0x3]; // Offset: 0x81 | Size: 0x3
	int32_t FireCostFullShot; // Offset: 0x84 | Size: 0x4
	bool IfForceFullShotCost; // Offset: 0x88 | Size: 0x1
	bool bNeedPlayCameraShake; // Offset: 0x89 | Size: 0x1
	char pad_0x8A[0x6]; // Offset: 0x8a | Size: 0x6
	struct UCurveFloat* AmmoSpeedScaleCurve; // Offset: 0x90 | Size: 0x8
	struct UCurveFloat* AmmoEffectXScaleCurve; // Offset: 0x98 | Size: 0x8
	struct UCurveFloat* AmmoEffectYZScaleCurve; // Offset: 0xa0 | Size: 0x8
	struct UCurveFloat* OverloadCurve; // Offset: 0xa8 | Size: 0x8
	float ChargeAnimationRate; // Offset: 0xb0 | Size: 0x4
	char pad_0xB4[0x4]; // Offset: 0xb4 | Size: 0x4
	struct UCurveFloat* DeflectionAngleCurve; // Offset: 0xb8 | Size: 0x8
};

// Object: ScriptStruct Solarland.TracerBulletData
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FTracerBulletData {
	// Fields
	float DeflectionAnglePerSec; // Offset: 0x0 | Size: 0x4
	float MaximumDetectionAngle; // Offset: 0x4 | Size: 0x4
	float HomingRange; // Offset: 0x8 | Size: 0x4
	bool bTraceTargetOnly; // Offset: 0xc | Size: 0x1
	char pad_0xD[0x3]; // Offset: 0xd | Size: 0x3
	struct FString TracingTargetWarningSound; // Offset: 0x10 | Size: 0x10
	struct FString TracingTargetWarningRTPC; // Offset: 0x20 | Size: 0x10
	struct FString TracingAuthorPromptSound; // Offset: 0x30 | Size: 0x10
};

// Object: ScriptStruct Solarland.AmmonRecoilScope
// Inherited Bytes: 0x0 | Struct Size: 0xb8
struct FAmmonRecoilScope {
	// Fields
	bool EnableScopeVibration; // Offset: 0x0 | Size: 0x1
	bool EnableCrossHairVibration; // Offset: 0x1 | Size: 0x1
	bool EnableScopeRoll; // Offset: 0x2 | Size: 0x1
	char pad_0x3[0x1]; // Offset: 0x3 | Size: 0x1
	float ScopeVMaxDistanceOffSet; // Offset: 0x4 | Size: 0x4
	float ScopeVVibrationDuration; // Offset: 0x8 | Size: 0x4
	char pad_0xC[0x4]; // Offset: 0xc | Size: 0x4
	struct UCurveFloat* ScopeVSingleOffSetCurve; // Offset: 0x10 | Size: 0x8
	struct UCurveFloat* ScopeVContinuousOffSetCurve; // Offset: 0x18 | Size: 0x8
	float ScopeVContinuousFallingDuration; // Offset: 0x20 | Size: 0x4
	char pad_0x24[0x4]; // Offset: 0x24 | Size: 0x4
	struct UCurveFloat* ScopeVContinuousFallingCurve; // Offset: 0x28 | Size: 0x8
	int32_t ScopeVContinuousFallingPointIndex; // Offset: 0x30 | Size: 0x4
	float ScopeHMaxDistanceOffSet; // Offset: 0x34 | Size: 0x4
	float ScopeHVibrationDuration; // Offset: 0x38 | Size: 0x4
	char pad_0x3C[0x4]; // Offset: 0x3c | Size: 0x4
	struct UCurveFloat* ScopeHSingleOffSetCurve; // Offset: 0x40 | Size: 0x8
	struct UCurveFloat* ScopeHContinuousOffSetCurve; // Offset: 0x48 | Size: 0x8
	struct UCurveFloat* ScopeHOffSetProbabilityCurve; // Offset: 0x50 | Size: 0x8
	struct FAmmonRecoilCrossHair CrossHairScaleSettings; // Offset: 0x58 | Size: 0x24
	char pad_0x7C[0x4]; // Offset: 0x7c | Size: 0x4
	struct FAmmonRecoilScopeRoll ScopeRollSettings; // Offset: 0x80 | Size: 0x38
};

// Object: ScriptStruct Solarland.AmmonRecoilStruct
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FAmmonRecoilStruct {
	// Fields
	float CostTime; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct UCurveFloat* RecoilRangeCurve; // Offset: 0x8 | Size: 0x8
	int32_t APointCurveKeyIndex; // Offset: 0x10 | Size: 0x4
	float APointMin; // Offset: 0x14 | Size: 0x4
	float APointMax; // Offset: 0x18 | Size: 0x4
	int32_t BPointCurveKeyIndex; // Offset: 0x1c | Size: 0x4
	float BPointMin; // Offset: 0x20 | Size: 0x4
	float BPointMax; // Offset: 0x24 | Size: 0x4
};

// Object: ScriptStruct Solarland.AmmonRecoilScopeRoll
// Inherited Bytes: 0x28 | Struct Size: 0x38
struct FAmmonRecoilScopeRoll : FAmmonRecoilStruct {
	// Fields
	struct UCurveFloat* RollProbabilityCurve; // Offset: 0x28 | Size: 0x8
	struct UCurveFloat* ContinuousFireWeightCurve; // Offset: 0x30 | Size: 0x8
};

// Object: ScriptStruct Solarland.AmmonRecoilCrossHair
// Inherited Bytes: 0x0 | Struct Size: 0x24
struct FAmmonRecoilCrossHair {
	// Fields
	float VMaxDistanceOffSetScale; // Offset: 0x0 | Size: 0x4
	float VVibrationDurationScale; // Offset: 0x4 | Size: 0x4
	float VSingleOffSetScale; // Offset: 0x8 | Size: 0x4
	float VContinuousOffSetScale; // Offset: 0xc | Size: 0x4
	float HMaxDistanceOffSetScale; // Offset: 0x10 | Size: 0x4
	float HVibrationDurationScale; // Offset: 0x14 | Size: 0x4
	float HSingleOffSetScale; // Offset: 0x18 | Size: 0x4
	float HContinuousOffSetScale; // Offset: 0x1c | Size: 0x4
	float HOffSetProbabilityScale; // Offset: 0x20 | Size: 0x4
};

// Object: ScriptStruct Solarland.AmmonRecoilRollStruct
// Inherited Bytes: 0x28 | Struct Size: 0x40
struct FAmmonRecoilRollStruct : FAmmonRecoilStruct {
	// Fields
	struct UCurveFloat* RollProbabilityCurve; // Offset: 0x28 | Size: 0x8
	float ADSRollCOP; // Offset: 0x30 | Size: 0x4
	char pad_0x34[0x4]; // Offset: 0x34 | Size: 0x4
	struct UCurveFloat* ContinuousFireWeightCurve; // Offset: 0x38 | Size: 0x8
};

// Object: ScriptStruct Solarland.AmmonVerticalRecoilStruct
// Inherited Bytes: 0x28 | Struct Size: 0x30
struct FAmmonVerticalRecoilStruct : FAmmonRecoilStruct {
	// Fields
	struct UCurveFloat* ContinuousFireWeightCurve; // Offset: 0x28 | Size: 0x8
};

// Object: ScriptStruct Solarland.AmmonHorizontalRecoilStruct
// Inherited Bytes: 0x28 | Struct Size: 0x30
struct FAmmonHorizontalRecoilStruct : FAmmonRecoilStruct {
	// Fields
	struct UCurveVector* ContinuousFireInfoCurve; // Offset: 0x28 | Size: 0x8
};

// Object: ScriptStruct Solarland.FootEffect
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FFootEffect {
	// Fields
	enum class EFootEffectType Type; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x7]; // Offset: 0x1 | Size: 0x7
	struct UParticleSystem* PSTemplate; // Offset: 0x8 | Size: 0x8
	struct TSoftObjectPtr<UParticleSystem> PSTemplateSoft; // Offset: 0x10 | Size: 0x28
	struct FName SocketName; // Offset: 0x38 | Size: 0x8
};

// Object: ScriptStruct Solarland.AttachedMeshInfo
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FAttachedMeshInfo {
	// Fields
	struct UStaticMesh* MeshResource; // Offset: 0x0 | Size: 0x8
	struct FName SocketName; // Offset: 0x8 | Size: 0x8
	struct FTransform TransformOffset; // Offset: 0x10 | Size: 0x30
};

// Object: ScriptStruct Solarland.AttributeSubSetting
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FAttributeSubSetting {
	// Fields
	bool bUsingAttributeSub; // Offset: 0x0 | Size: 0x1
	enum class EAttributeSubBehavior Behavior; // Offset: 0x1 | Size: 0x1
	char pad_0x2[0x2]; // Offset: 0x2 | Size: 0x2
	int32_t AttributeSubID; // Offset: 0x4 | Size: 0x4
	float Value; // Offset: 0x8 | Size: 0x4
};

// Object: ScriptStruct Solarland.ControlPointData
// Inherited Bytes: 0x0 | Struct Size: 0x14
struct FControlPointData {
	// Fields
	float OccupiedAddScorePerSec; // Offset: 0x0 | Size: 0x4
	char MinProgress; // Offset: 0x4 | Size: 0x1
	char MaxProgress; // Offset: 0x5 | Size: 0x1
	char pad_0x6[0x2]; // Offset: 0x6 | Size: 0x2
	float OccupyingProgressPerSec; // Offset: 0x8 | Size: 0x4
	float ReOccupyingProgressPerSec; // Offset: 0xc | Size: 0x4
	float RegainTime; // Offset: 0x10 | Size: 0x4
};

// Object: ScriptStruct Solarland.BattlegroundMapElementData
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FBattlegroundMapElementData {
	// Fields
	int32_t SubModeID; // Offset: 0x0 | Size: 0x4
	enum class EBattlegroundMapElementType Type; // Offset: 0x4 | Size: 0x1
	enum class EFactionType DefaultOwnerFaction; // Offset: 0x5 | Size: 0x1
	enum class EDeploymentType DeploymentType; // Offset: 0x6 | Size: 0x1
	enum class EBattlegroundPlayerStartRegion PlayerStartRegion; // Offset: 0x7 | Size: 0x1
	float EnemyCheckDistance; // Offset: 0x8 | Size: 0x4
};

// Object: ScriptStruct Solarland.BattlegroundWeaponData
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FBattlegroundWeaponData {
	// Fields
	int32_t weaponid; // Offset: 0x0 | Size: 0x4
	struct FWeaponPartsData WeaponPartsData; // Offset: 0x4 | Size: 0x14
};

// Object: ScriptStruct Solarland.BattlePassLevelInfo
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FBattlePassLevelInfo {
	// Fields
	char pad_0x0[0x18]; // Offset: 0x0 | Size: 0x18
};

// Object: ScriptStruct Solarland.BattlePassLevelItem
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FBattlePassLevelItem {
	// Fields
	char pad_0x0[0xc]; // Offset: 0x0 | Size: 0xc
};

// Object: ScriptStruct Solarland.PromptElemInfo
// Inherited Bytes: 0x0 | Struct Size: 0x34
struct FPromptElemInfo {
	// Fields
	enum class EBattlePromptType Type; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	struct FVector2D ArrowPosition; // Offset: 0x4 | Size: 0x8
	struct FVector2D IconPosition; // Offset: 0xc | Size: 0x8
	int32_t ArrowColorFactor; // Offset: 0x14 | Size: 0x4
	int32_t ArrowLengthFactor; // Offset: 0x18 | Size: 0x4
	int32_t IconFactor; // Offset: 0x1c | Size: 0x4
	float TransparencyFactor; // Offset: 0x20 | Size: 0x4
	float Distance; // Offset: 0x24 | Size: 0x4
	int32_t Angle; // Offset: 0x28 | Size: 0x4
	bool bBlocked; // Offset: 0x2c | Size: 0x1
	char pad_0x2D[0x3]; // Offset: 0x2d | Size: 0x3
	int32_t UVIdx; // Offset: 0x30 | Size: 0x4
};

// Object: ScriptStruct Solarland.BattleRoyalTimeLineDTRow
// Inherited Bytes: 0x8 | Struct Size: 0x18
struct FBattleRoyalTimeLineDTRow : FTableRowBase {
	// Fields
	float StartTime; // Offset: 0x8 | Size: 0x4
	enum class EBattleRoyalTimeLineEnum OperationType; // Offset: 0xc | Size: 0x1
	char pad_0xD[0x3]; // Offset: 0xd | Size: 0x3
	int32_t Parameter; // Offset: 0x10 | Size: 0x4
	char pad_0x14[0x4]; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct Solarland.BattleUpgradeEffectCategoryConfig
// Inherited Bytes: 0x0 | Struct Size: 0x64
struct FBattleUpgradeEffectCategoryConfig {
	// Fields
	int32_t TitleLocalTextID; // Offset: 0x0 | Size: 0x4
	struct FBattleUpgradeEffectCategoryColorSet ColorSet; // Offset: 0x4 | Size: 0x60
};

// Object: ScriptStruct Solarland.BattleUpgradeEffectConfig
// Inherited Bytes: 0x8 | Struct Size: 0x90
struct FBattleUpgradeEffectConfig : FTableRowBase {
	// Fields
	enum class ESolarTablesEnum_BattleUpgradeEffectType Type; // Offset: 0x8 | Size: 0x1
	enum class EBattleUpgradeEffectCategory Category; // Offset: 0x9 | Size: 0x1
	char pad_0xA[0x6]; // Offset: 0xa | Size: 0x6
	struct TSoftClassPtr<UObject> EffectClass; // Offset: 0x10 | Size: 0x28
	struct TArray<struct FBattleUpgradeEffectConfigParam> Parameters; // Offset: 0x38 | Size: 0x10
	struct FWrappedLocalTextID DescriptionLocalText; // Offset: 0x48 | Size: 0x4
	char pad_0x4C[0x4]; // Offset: 0x4c | Size: 0x4
	struct TSoftObjectPtr<UTexture2D> Icon; // Offset: 0x50 | Size: 0x28
	struct FString ShortNumberDisplayFormat; // Offset: 0x78 | Size: 0x10
	struct FWrappedLocalTextID TitleLocalText; // Offset: 0x88 | Size: 0x4
	struct FWrappedLocalTextID IntroductionLocalText; // Offset: 0x8c | Size: 0x4
};

// Object: ScriptStruct Solarland.BattleUpgradeEffectConfigParam
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FBattleUpgradeEffectConfigParam {
	// Fields
	struct FGameplayTag GameplayTag; // Offset: 0x0 | Size: 0x8
	float Scale; // Offset: 0x8 | Size: 0x4
};

// Object: ScriptStruct Solarland.BlueCircleInfo
// Inherited Bytes: 0x0 | Struct Size: 0x14
struct FBlueCircleInfo {
	// Fields
	struct FVector CenterLocation; // Offset: 0x0 | Size: 0xc
	float Radius; // Offset: 0xc | Size: 0x4
	bool bHiddenInLevel; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x3]; // Offset: 0x11 | Size: 0x3
};

// Object: ScriptStruct Solarland.BombingZone
// Inherited Bytes: 0x0 | Struct Size: 0x60
struct FBombingZone {
	// Fields
	int32_t instanceID; // Offset: 0x0 | Size: 0x4
	int32_t ConfigID; // Offset: 0x4 | Size: 0x4
	float Radius; // Offset: 0x8 | Size: 0x4
	float Duration; // Offset: 0xc | Size: 0x4
	int32_t MinBomb; // Offset: 0x10 | Size: 0x4
	int32_t MaxBomb; // Offset: 0x14 | Size: 0x4
	struct FVector Location; // Offset: 0x18 | Size: 0xc
	struct FBombingZoneBomb Bomb; // Offset: 0x24 | Size: 0x1c
	enum class EBombingZoneState State; // Offset: 0x40 | Size: 0x1
	char pad_0x41[0x1f]; // Offset: 0x41 | Size: 0x1f
};

// Object: ScriptStruct Solarland.BombingZoneBomb
// Inherited Bytes: 0x0 | Struct Size: 0x1c
struct FBombingZoneBomb {
	// Fields
	float Radius; // Offset: 0x0 | Size: 0x4
	float MaxDamage; // Offset: 0x4 | Size: 0x4
	float MinDamage; // Offset: 0x8 | Size: 0x4
	float VehicleMaxDamage; // Offset: 0xc | Size: 0x4
	float VehicleMinDamage; // Offset: 0x10 | Size: 0x4
	float InVehicleDamageScale; // Offset: 0x14 | Size: 0x4
	float LandingTime; // Offset: 0x18 | Size: 0x4
};

// Object: ScriptStruct Solarland.ScreenEffectConfig
// Inherited Bytes: 0x8 | Struct Size: 0x78
struct FScreenEffectConfig : FTableRowBase {
	// Fields
	struct FString EffectType; // Offset: 0x8 | Size: 0x10
	struct FString EffectName; // Offset: 0x18 | Size: 0x10
	struct FString State; // Offset: 0x28 | Size: 0x10
	enum class EBuffEffectTagType TagType; // Offset: 0x38 | Size: 0x1
	bool bMatReplace; // Offset: 0x39 | Size: 0x1
	enum class EBuffEffectDurationType DurationType; // Offset: 0x3a | Size: 0x1
	char pad_0x3B[0x1]; // Offset: 0x3b | Size: 0x1
	float DurationTime; // Offset: 0x3c | Size: 0x4
	struct TSoftClassPtr<UObject> ScreenWidgetPath; // Offset: 0x40 | Size: 0x28
	enum class ESameScreenEffectHandleType SameEffectHandleType; // Offset: 0x68 | Size: 0x1
	char pad_0x69[0x3]; // Offset: 0x69 | Size: 0x3
	float MinIntervalForSameScreenEffect; // Offset: 0x6c | Size: 0x4
	float MinIntervalForSameScreenEffectLowLevelDevice; // Offset: 0x70 | Size: 0x4
	char pad_0x74[0x4]; // Offset: 0x74 | Size: 0x4
};

// Object: ScriptStruct Solarland.BuffEffectTableRow
// Inherited Bytes: 0x8 | Struct Size: 0x38
struct FBuffEffectTableRow : FTableRowBase {
	// Fields
	struct FName EffectType; // Offset: 0x8 | Size: 0x8
	struct FName EffectName; // Offset: 0x10 | Size: 0x8
	struct FName State; // Offset: 0x18 | Size: 0x8
	bool bMatReplace; // Offset: 0x20 | Size: 0x1
	enum class EBuffEffectDurationType DurationType; // Offset: 0x21 | Size: 0x1
	char pad_0x22[0x2]; // Offset: 0x22 | Size: 0x2
	float DurationTime; // Offset: 0x24 | Size: 0x4
	struct TArray<struct FBuffEffectActorParam> ActorEffectParams; // Offset: 0x28 | Size: 0x10
};

// Object: ScriptStruct Solarland.BuffEffectActorParam
// Inherited Bytes: 0x0 | Struct Size: 0xd8
struct FBuffEffectActorParam {
	// Fields
	struct TSoftObjectPtr<UParticleSystem> ActorParticlePath; // Offset: 0x0 | Size: 0x28
	struct FSolarSkinnedParticleSystem ActorSkinnedParticlePath; // Offset: 0x28 | Size: 0x70
	struct FName SocketName; // Offset: 0x98 | Size: 0x8
	struct FVector LocationOffset; // Offset: 0xa0 | Size: 0xc
	struct FRotator RotationOffset; // Offset: 0xac | Size: 0xc
	struct FVector Scale; // Offset: 0xb8 | Size: 0xc
	enum class EAttachLocation LocationType; // Offset: 0xc4 | Size: 0x1
	bool bAutoActivate; // Offset: 0xc5 | Size: 0x1
	bool Attached; // Offset: 0xc6 | Size: 0x1
	bool bAbsoluteRotation; // Offset: 0xc7 | Size: 0x1
	struct TArray<struct FName> ComponentTags; // Offset: 0xc8 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarSkinnedAsset
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FSolarSkinnedAsset {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
};

// Object: ScriptStruct Solarland.SolarSkinnedParticleSystem
// Inherited Bytes: 0x8 | Struct Size: 0x70
struct FSolarSkinnedParticleSystem : FSolarSkinnedAsset {
	// Fields
	struct FSoftObjectPath DefaultSkinnedParticle; // Offset: 0x8 | Size: 0x18
	struct TMap<int32_t, struct FSoftObjectPath> SkinnedParticles; // Offset: 0x20 | Size: 0x50
};

// Object: ScriptStruct Solarland.ScreenEffectWidgetCacheInfo
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FScreenEffectWidgetCacheInfo {
	// Fields
	struct USolarScreenEffectWidget* WidgetClass; // Offset: 0x0 | Size: 0x8
	struct TArray<struct USolarScreenEffectWidget*> WidgetInstances; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct Solarland.ActiveCameraShakeWithCurve
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FActiveCameraShakeWithCurve {
	// Fields
	struct UCameraShakeWithCurve* ShakeInstance; // Offset: 0x0 | Size: 0x8
	char pad_0x8[0x10]; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct Solarland.CameraShakeWithCurveTemplatePool
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FCameraShakeWithCurveTemplatePool {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
	struct TArray<struct UCameraShakeWithCurve*> PooledShakes; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct Solarland.CameraShakeWithCurvePool
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FCameraShakeWithCurvePool {
	// Fields
	struct TArray<struct UCameraShakeWithCurve*> PooledShakes; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Solarland.CruiseFormation
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FCruiseFormation {
	// Fields
	struct TArray<struct FVector> LocationList; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Solarland.EchelonFormation
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FEchelonFormation {
	// Fields
	struct TArray<struct FVector> LocationList; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Solarland.SettlePageParam
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FSettlePageParam {
	// Fields
	int32_t WeaponExpSettlmentNum; // Offset: 0x0 | Size: 0x4
	bool IsRankFight; // Offset: 0x4 | Size: 0x1
	char pad_0x5[0x3]; // Offset: 0x5 | Size: 0x3
};

// Object: ScriptStruct Solarland.DataManagerConfig
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FDataManagerConfig {
	// Fields
	struct UDataTable* GeneralDataTable; // Offset: 0x0 | Size: 0x8
	struct UDataTable* DataTable; // Offset: 0x8 | Size: 0x8
};

// Object: ScriptStruct Solarland.FinalsBGMData
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FFinalsBGMData {
	// Fields
	bool bEnableFinalsBGM; // Offset: 0x0 | Size: 0x1
	char FinalsBGMSafeAreaIndex; // Offset: 0x1 | Size: 0x1
	char FinalsBGMPlayTeamCount; // Offset: 0x2 | Size: 0x1
	char FinalsBGMStopTeamCount; // Offset: 0x3 | Size: 0x1
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct FString FinalsBGMName_Play; // Offset: 0x8 | Size: 0x10
	struct FString FinalsBGMName_Stop; // Offset: 0x18 | Size: 0x10
};

// Object: ScriptStruct Solarland.SCMMapConfig
// Inherited Bytes: 0x0 | Struct Size: 0x80
struct FSCMMapConfig {
	// Fields
	struct FString Desc; // Offset: 0x0 | Size: 0x10
	struct FSoftObjectPath LevelMap; // Offset: 0x10 | Size: 0x18
	int32_t MiniMapId; // Offset: 0x28 | Size: 0x4
	bool IsStreaming; // Offset: 0x2c | Size: 0x1
	char pad_0x2D[0x3]; // Offset: 0x2d | Size: 0x3
	struct TMap<struct FString, struct FSCMElementMapConfig> ElementGroups; // Offset: 0x30 | Size: 0x50
};

// Object: ScriptStruct Solarland.SCMElementMapConfig
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FSCMElementMapConfig {
	// Fields
	struct FSoftObjectPath ElementLevel; // Offset: 0x0 | Size: 0x18
	bool LoadWithLevel; // Offset: 0x18 | Size: 0x1
	enum class ELevelLoadType LoadType; // Offset: 0x19 | Size: 0x1
	char pad_0x1A[0x6]; // Offset: 0x1a | Size: 0x6
};

// Object: ScriptStruct Solarland.DoppelgangerBehaviorConfig
// Inherited Bytes: 0x0 | Struct Size: 0x70
struct FDoppelgangerBehaviorConfig {
	// Fields
	bool bNeedCopy; // Offset: 0x0 | Size: 0x1
	bool bCopyRotate; // Offset: 0x1 | Size: 0x1
	bool bCopyCrouch; // Offset: 0x2 | Size: 0x1
	bool bCopySprint; // Offset: 0x3 | Size: 0x1
	bool bCopyJump; // Offset: 0x4 | Size: 0x1
	bool bCopyJetFly; // Offset: 0x5 | Size: 0x1
	char pad_0x6[0x2]; // Offset: 0x6 | Size: 0x2
	float MoveDuration; // Offset: 0x8 | Size: 0x4
	struct FVector2D MoveDirection; // Offset: 0xc | Size: 0x8
	float FindTargetRange; // Offset: 0x14 | Size: 0x4
	bool bCanAutoShoot; // Offset: 0x18 | Size: 0x1
	char pad_0x19[0x7]; // Offset: 0x19 | Size: 0x7
	struct TMap<enum class EWeaponType, float> ShootRequestInterval; // Offset: 0x20 | Size: 0x50
};

// Object: ScriptStruct Solarland.ActiveDynamicEffectTriggerVolumeInfo
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FActiveDynamicEffectTriggerVolumeInfo {
	// Fields
	struct TArray<struct FActiveGameplayEffectHandle> AppliedEffectHandles; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Solarland.DynamicGameplayEffectSpec
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FDynamicGameplayEffectSpec {
	// Fields
	struct UGameplayEffect* EffectClass; // Offset: 0x0 | Size: 0x8
	float EffectLevel; // Offset: 0x8 | Size: 0x4
	bool bRemoveOnEnd; // Offset: 0xc | Size: 0x1
	char pad_0xD[0x3]; // Offset: 0xd | Size: 0x3
};

// Object: ScriptStruct Solarland.TacticalDodgeDirectionConfig
// Inherited Bytes: 0x0 | Struct Size: 0x78
struct FTacticalDodgeDirectionConfig {
	// Fields
	struct FSolarSkinnedMontage SkinnedMontage; // Offset: 0x0 | Size: 0x70
	enum class ECamShakeType CameraShake; // Offset: 0x70 | Size: 0x1
	char pad_0x71[0x7]; // Offset: 0x71 | Size: 0x7
};

// Object: ScriptStruct Solarland.SolarSkinnedMontage
// Inherited Bytes: 0x8 | Struct Size: 0x70
struct FSolarSkinnedMontage : FSolarSkinnedAsset {
	// Fields
	struct FSoftObjectPath DefaultSkinnedMontage; // Offset: 0x8 | Size: 0x18
	struct TMap<int32_t, struct FSoftObjectPath> SkinnedMontages; // Offset: 0x20 | Size: 0x50
};

// Object: ScriptStruct Solarland.TacticalDodgeParams
// Inherited Bytes: 0x8 | Struct Size: 0x10
struct FTacticalDodgeParams : FGameplayAbilityTargetData {
	// Fields
	int32_t MontageIndex; // Offset: 0x8 | Size: 0x4
	float FaceYaw; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct Solarland.DGMatUpdateParams
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FDGMatUpdateParams {
	// Fields
	struct FName MatParam; // Offset: 0x0 | Size: 0x8
	struct UCurveBase* MatCurve; // Offset: 0x8 | Size: 0x8
};

// Object: ScriptStruct Solarland.SolarExtraShieldEffect
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FSolarExtraShieldEffect {
	// Fields
	int32_t Level; // Offset: 0x0 | Size: 0x4
	struct FName TeammateEffectID; // Offset: 0x4 | Size: 0x8
	struct FName EnemyEffectID; // Offset: 0xc | Size: 0x8
	bool bOnRemoveStop; // Offset: 0x14 | Size: 0x1
	char pad_0x15[0x3]; // Offset: 0x15 | Size: 0x3
};

// Object: ScriptStruct Solarland.SolarCharacterBillboardIconGroupConfig
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FSolarCharacterBillboardIconGroupConfig {
	// Fields
	struct TArray<struct FSolarCharacterBillboardIconConfig> IconConfigs; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarCharacterBillboardIconConfig
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FSolarCharacterBillboardIconConfig {
	// Fields
	struct FGameplayTag IconTag; // Offset: 0x0 | Size: 0x8
	struct TSoftObjectPtr<UTexture2D> IconSoftPtr; // Offset: 0x8 | Size: 0x28
};

// Object: ScriptStruct Solarland.CharacterAssistAimTargetConfig
// Inherited Bytes: 0x0 | Struct Size: 0xd8
struct FCharacterAssistAimTargetConfig {
	// Fields
	struct FWeaponAssistAimTargetConfig Standing; // Offset: 0x0 | Size: 0x48
	struct FWeaponAssistAimTargetConfig Crouching; // Offset: 0x48 | Size: 0x48
	struct FWeaponAssistAimTargetConfig Crawling; // Offset: 0x90 | Size: 0x48
};

// Object: ScriptStruct Solarland.WeaponAssistAimTargetConfig
// Inherited Bytes: 0x0 | Struct Size: 0x48
struct FWeaponAssistAimTargetConfig {
	// Fields
	struct FVector2D BaseFollowTriggerExtent; // Offset: 0x0 | Size: 0x8
	struct FVector2D BaseFollowStopExtent; // Offset: 0x8 | Size: 0x8
	struct TArray<struct FBaseFollowExtentByTag> BaseFollowExtentByTags; // Offset: 0x10 | Size: 0x10
	struct FVector2D TargetVelocityFollowTriggerExtent; // Offset: 0x20 | Size: 0x8
	struct FVector2D LockAimingExtent; // Offset: 0x28 | Size: 0x8
	struct FVector2D GlobalSensitivityScaleTriggerExtent; // Offset: 0x30 | Size: 0x8
	char pad_0x38[0x10]; // Offset: 0x38 | Size: 0x10
};

// Object: ScriptStruct Solarland.BaseFollowExtentByTag
// Inherited Bytes: 0x0 | Struct Size: 0x60
struct FBaseFollowExtentByTag {
	// Fields
	struct FGameplayTagRequirements TagRequirements; // Offset: 0x0 | Size: 0x50
	struct FVector2D BaseFollowTriggerExtent; // Offset: 0x50 | Size: 0x8
	struct FVector2D BaseFollowStopExtent; // Offset: 0x58 | Size: 0x8
};

// Object: ScriptStruct Solarland.CharacterBodyScaleConfig
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FCharacterBodyScaleConfig {
	// Fields
	float CapsuleHeight; // Offset: 0x0 | Size: 0x4
	float MeshOriginHeight; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct Solarland.CueContent
// Inherited Bytes: 0x0 | Struct Size: 0xb8
struct FCueContent {
	// Fields
	enum class ECueContentPlayTiming PlayTiming; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	struct FName CustomEvent; // Offset: 0x4 | Size: 0x8
	char VisibleTargetFlag; // Offset: 0xc | Size: 0x1
	char pad_0xD[0x3]; // Offset: 0xd | Size: 0x3
	struct FGameplayTagRequirements PlayTagRequirements; // Offset: 0x10 | Size: 0x50
	struct TArray<struct FActorEffectContent> ActorEffectContents; // Offset: 0x60 | Size: 0x10
	struct TArray<struct FBuffEffectContent> BuffEffectContents; // Offset: 0x70 | Size: 0x10
	struct TArray<struct FSoundContent> SoundContents; // Offset: 0x80 | Size: 0x10
	struct TArray<struct FHeadIconContent> HeadIconContents; // Offset: 0x90 | Size: 0x10
	struct TArray<struct FParticleSystemContent> ParticleSystemContents; // Offset: 0xa0 | Size: 0x10
	char pad_0xB0[0x8]; // Offset: 0xb0 | Size: 0x8
};

// Object: ScriptStruct Solarland.ParticleSystemContent
// Inherited Bytes: 0x0 | Struct Size: 0x88
struct FParticleSystemContent {
	// Fields
	struct FActorParticleEffectSpawnInfo SpawnInfo; // Offset: 0x0 | Size: 0x70
	bool bStopOnEnd; // Offset: 0x70 | Size: 0x1
	char pad_0x71[0x17]; // Offset: 0x71 | Size: 0x17
};

// Object: ScriptStruct Solarland.HeadIconContent
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FHeadIconContent {
	// Fields
	struct FGameplayTag HeadIconTag; // Offset: 0x0 | Size: 0x8
};

// Object: ScriptStruct Solarland.SoundContent
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FSoundContent {
	// Fields
	struct FName SoundGroupName; // Offset: 0x0 | Size: 0x8
};

// Object: ScriptStruct Solarland.BuffEffectContent
// Inherited Bytes: 0x0 | Struct Size: 0x14
struct FBuffEffectContent {
	// Fields
	struct FName BuffEffectID; // Offset: 0x0 | Size: 0x8
	bool bStopOnEnd; // Offset: 0x8 | Size: 0x1
	enum class EBuffEffectType BuffEffectType; // Offset: 0x9 | Size: 0x1
	char pad_0xA[0xa]; // Offset: 0xa | Size: 0xa
};

// Object: ScriptStruct Solarland.ActorEffectContent
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FActorEffectContent {
	// Fields
	struct UActorEffect* ActorEffectClass; // Offset: 0x0 | Size: 0x8
	enum class EActorEffectAffectedActorType AffectedActorType; // Offset: 0x8 | Size: 0x1
	bool bHideFX; // Offset: 0x9 | Size: 0x1
	char pad_0xA[0x2]; // Offset: 0xa | Size: 0x2
	struct FGameplayTag VisibilityFlagTag; // Offset: 0xc | Size: 0x8
	char pad_0x14[0xc]; // Offset: 0x14 | Size: 0xc
};

// Object: ScriptStruct Solarland.CharacterSpecializedComponentInfos
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FCharacterSpecializedComponentInfos {
	// Fields
	struct TArray<struct FCharacterSpecializedComponentInfo> ComponentInfos; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Solarland.CharacterSpecializedComponentInfo
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FCharacterSpecializedComponentInfo {
	// Fields
	struct TArray<enum class ENetRole> ValidRoles; // Offset: 0x0 | Size: 0x10
	bool bEnableReplication; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x7]; // Offset: 0x11 | Size: 0x7
	struct TArray<struct UActorComponent*> ComponentClasses; // Offset: 0x18 | Size: 0x10
};

// Object: ScriptStruct Solarland.CharacterMontageMappingData
// Inherited Bytes: 0x8 | Struct Size: 0x48
struct FCharacterMontageMappingData : FTableRowBase {
	// Fields
	struct FGameplayTag MontageTag; // Offset: 0x8 | Size: 0x8
	struct UAnimMontage* MaleMontage; // Offset: 0x10 | Size: 0x8
	struct UAnimMontage* FemaleMontage; // Offset: 0x18 | Size: 0x8
	struct TArray<struct FMontageDataByCharacter> CharacterSpecificData; // Offset: 0x20 | Size: 0x10
	struct UDataTable* WeaponSpecificDataTable; // Offset: 0x30 | Size: 0x8
	char pad_0x38[0x10]; // Offset: 0x38 | Size: 0x10
};

// Object: ScriptStruct Solarland.MontageDataByCharacter
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FMontageDataByCharacter {
	// Fields
	int32_t CharacterId; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct UAnimMontage* Montage; // Offset: 0x8 | Size: 0x8
	struct TArray<struct FMontageDataByCharacterSkin> SkinSpecificData; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct Solarland.MontageDataByCharacterSkin
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FMontageDataByCharacterSkin {
	// Fields
	int32_t CharacterSkinID; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct UAnimMontage* Montage; // Offset: 0x8 | Size: 0x8
};

// Object: ScriptStruct Solarland.EmotionMontageMappingData
// Inherited Bytes: 0x48 | Struct Size: 0x50
struct FEmotionMontageMappingData : FCharacterMontageMappingData {
	// Fields
	bool bShowWeapon; // Offset: 0x48 | Size: 0x1
	char pad_0x49[0x3]; // Offset: 0x49 | Size: 0x3
	float CameraZOffset; // Offset: 0x4c | Size: 0x4
};

// Object: ScriptStruct Solarland.MontageDataByWeapon
// Inherited Bytes: 0x8 | Struct Size: 0x30
struct FMontageDataByWeapon : FTableRowBase {
	// Fields
	int32_t weaponid; // Offset: 0x8 | Size: 0x4
	char pad_0xC[0x4]; // Offset: 0xc | Size: 0x4
	struct UAnimMontage* MaleMontage; // Offset: 0x10 | Size: 0x8
	struct UAnimMontage* FemaleMontage; // Offset: 0x18 | Size: 0x8
	struct TArray<struct FMontageDataByWeaponSkin> SkinSpecificData; // Offset: 0x20 | Size: 0x10
};

// Object: ScriptStruct Solarland.MontageDataByWeaponSkin
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FMontageDataByWeaponSkin {
	// Fields
	int32_t WeaponSkinID; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct UAnimMontage* MaleMontage; // Offset: 0x8 | Size: 0x8
	struct UAnimMontage* FemaleMontage; // Offset: 0x10 | Size: 0x8
};

// Object: ScriptStruct Solarland.ChildActorOrnamentConfig
// Inherited Bytes: 0x0 | Struct Size: 0x80
struct FChildActorOrnamentConfig {
	// Fields
	struct FSoftClassPath OrnamentRes; // Offset: 0x0 | Size: 0x18
	struct FName OrnamentAttachSocket; // Offset: 0x18 | Size: 0x8
	struct FTransform OrnamentRelativeTransform; // Offset: 0x20 | Size: 0x30
	struct FSoftObjectPath OrnamentVisibilityConfig; // Offset: 0x50 | Size: 0x18
	struct TArray<struct FName> OrnamentComponentTags; // Offset: 0x68 | Size: 0x10
	char pad_0x78[0x8]; // Offset: 0x78 | Size: 0x8
};

// Object: ScriptStruct Solarland.SkeletalMeshOrnamentConfig
// Inherited Bytes: 0x0 | Struct Size: 0xa0
struct FSkeletalMeshOrnamentConfig {
	// Fields
	struct FSoftObjectPath OrnamentRes; // Offset: 0x0 | Size: 0x18
	struct FSoftClassPath OrnamentABPRes; // Offset: 0x18 | Size: 0x18
	struct FName OrnamentAttachSocket; // Offset: 0x30 | Size: 0x8
	char pad_0x38[0x8]; // Offset: 0x38 | Size: 0x8
	struct FTransform OrnamentRelativeTransform; // Offset: 0x40 | Size: 0x30
	struct FSoftObjectPath OrnamentVisibilityConfig; // Offset: 0x70 | Size: 0x18
	struct TArray<struct FName> OrnamentComponentTags; // Offset: 0x88 | Size: 0x10
	char pad_0x98[0x8]; // Offset: 0x98 | Size: 0x8
};

// Object: ScriptStruct Solarland.StaticMeshOrnamentConfig
// Inherited Bytes: 0x0 | Struct Size: 0x80
struct FStaticMeshOrnamentConfig {
	// Fields
	struct FSoftObjectPath OrnamentRes; // Offset: 0x0 | Size: 0x18
	struct FName OrnamentAttachSocket; // Offset: 0x18 | Size: 0x8
	struct FTransform OrnamentRelativeTransform; // Offset: 0x20 | Size: 0x30
	struct FSoftObjectPath OrnamentVisibilityConfig; // Offset: 0x50 | Size: 0x18
	struct TArray<struct FName> OrnamentComponentTags; // Offset: 0x68 | Size: 0x10
	char pad_0x78[0x8]; // Offset: 0x78 | Size: 0x8
};

// Object: ScriptStruct Solarland.SoundGroupMappingData
// Inherited Bytes: 0x8 | Struct Size: 0x58
struct FSoundGroupMappingData : FTableRowBase {
	// Fields
	struct TMap<int32_t, struct FSoundGroupDataByCharacter> CharacterSpecificData; // Offset: 0x8 | Size: 0x50
};

// Object: ScriptStruct Solarland.SoundGroupDataByCharacter
// Inherited Bytes: 0x0 | Struct Size: 0x58
struct FSoundGroupDataByCharacter {
	// Fields
	struct FName DestinationSoundGroup; // Offset: 0x0 | Size: 0x8
	struct TMap<int32_t, struct FName> SkinSpecificData; // Offset: 0x8 | Size: 0x50
};

// Object: ScriptStruct Solarland.ChooseWeaponItemData
// Inherited Bytes: 0x0 | Struct Size: 0x88
struct FChooseWeaponItemData {
	// Fields
	struct FName RowName; // Offset: 0x0 | Size: 0x8
	int32_t weaponid; // Offset: 0x8 | Size: 0x4
	int32_t WeaponTypeId; // Offset: 0xc | Size: 0x4
	int32_t WeaponSkinID; // Offset: 0x10 | Size: 0x4
	bool bCollected; // Offset: 0x14 | Size: 0x1
	char pad_0x15[0x3]; // Offset: 0x15 | Size: 0x3
	struct TArray<int32_t> AvailableScopes; // Offset: 0x18 | Size: 0x10
	int32_t DefaultScope; // Offset: 0x28 | Size: 0x4
	char pad_0x2C[0x4]; // Offset: 0x2c | Size: 0x4
	struct TSet<enum class EWeaponEquipSlot> SelectedSlots; // Offset: 0x30 | Size: 0x50
	int32_t SelectedScope; // Offset: 0x80 | Size: 0x4
	char pad_0x84[0x4]; // Offset: 0x84 | Size: 0x4
};

// Object: ScriptStruct Solarland.ChooseWeaponItemState
// Inherited Bytes: 0x0 | Struct Size: 0x4
struct FChooseWeaponItemState {
	// Fields
	bool bCollected; // Offset: 0x0 | Size: 0x1
	bool bSelected; // Offset: 0x1 | Size: 0x1
	bool bSelectedBySlot1; // Offset: 0x2 | Size: 0x1
	bool bSelectedBySlot2; // Offset: 0x3 | Size: 0x1
};

// Object: ScriptStruct Solarland.NodeContainerItem
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FNodeContainerItem {
	// Fields
	struct UCanvasPanel* RootContainerPanel; // Offset: 0x0 | Size: 0x8
	struct TArray<struct FNodeContainer> ContainerArray; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct Solarland.NodeContainer
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FNodeContainer {
	// Fields
	struct FNodeElement ThisNode; // Offset: 0x0 | Size: 0x10
	bool bRoot; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x7]; // Offset: 0x11 | Size: 0x7
	struct TArray<struct FNodeElement> ChildsNode; // Offset: 0x18 | Size: 0x10
};

// Object: ScriptStruct Solarland.NodeElement
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FNodeElement {
	// Fields
	struct UWidget* Widget; // Offset: 0x0 | Size: 0x8
	enum class ESlateVisibility Visible; // Offset: 0x8 | Size: 0x1
	bool bIsContainer; // Offset: 0x9 | Size: 0x1
	char pad_0xA[0x6]; // Offset: 0xa | Size: 0x6
};

// Object: ScriptStruct Solarland.StateMapItemStruct
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FStateMapItemStruct {
	// Fields
	struct TArray<struct FStateItemStruct> ChildWidgetConfigList; // Offset: 0x0 | Size: 0x10
	bool bLoadChildWidgetTool; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x7]; // Offset: 0x11 | Size: 0x7
};

// Object: ScriptStruct Solarland.StateItemStruct
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FStateItemStruct {
	// Fields
	struct UWidget* CrosshairChildWidget; // Offset: 0x0 | Size: 0x8
	enum class ESlateVisibility VisibilityType; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x7]; // Offset: 0x9 | Size: 0x7
};

// Object: ScriptStruct Solarland.UICrossHairSpreadStruct
// Inherited Bytes: 0x0 | Struct Size: 0x48
struct FUICrossHairSpreadStruct {
	// Fields
	struct UWidget* TargetWidget; // Offset: 0x0 | Size: 0x8
	enum class ESpreadType SpreadType; // Offset: 0x8 | Size: 0x1
	bool bPosition; // Offset: 0x9 | Size: 0x1
	char pad_0xA[0x2]; // Offset: 0xa | Size: 0x2
	float Angle; // Offset: 0xc | Size: 0x4
	bool Pos_UseCustomizeFunc; // Offset: 0x10 | Size: 0x1
	bool bScale; // Offset: 0x11 | Size: 0x1
	char pad_0x12[0x2]; // Offset: 0x12 | Size: 0x2
	struct FVector2D ScaleFactor; // Offset: 0x14 | Size: 0x8
	bool Scale_UseCustomizeFunc; // Offset: 0x1c | Size: 0x1
	bool bRenderAngle; // Offset: 0x1d | Size: 0x1
	char pad_0x1E[0x2]; // Offset: 0x1e | Size: 0x2
	float RenderAngleFactor; // Offset: 0x20 | Size: 0x4
	bool Angle_UseCustomizeFunc; // Offset: 0x24 | Size: 0x1
	char pad_0x25[0x3]; // Offset: 0x25 | Size: 0x3
	struct FVector2D OrginalVector; // Offset: 0x28 | Size: 0x8
	struct FVector2D OrginalScale; // Offset: 0x30 | Size: 0x8
	float OrginalAngle; // Offset: 0x38 | Size: 0x4
	struct FVector2D Dir; // Offset: 0x3c | Size: 0x8
	char pad_0x44[0x4]; // Offset: 0x44 | Size: 0x4
};

// Object: ScriptStruct Solarland.UICrossHairAimColorStruct
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FUICrossHairAimColorStruct {
	// Fields
	struct UImage* TargetImg; // Offset: 0x0 | Size: 0x8
	struct FLinearColor TargetColor; // Offset: 0x8 | Size: 0x10
	char pad_0x18[0x10]; // Offset: 0x18 | Size: 0x10
};

// Object: ScriptStruct Solarland.CrosshairLayout
// Inherited Bytes: 0x0 | Struct Size: 0x4
struct FCrosshairLayout {
	// Fields
	float InitSpread; // Offset: 0x0 | Size: 0x4
};

// Object: ScriptStruct Solarland.CrosshairSprite
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FCrosshairSprite {
	// Fields
	struct FSoftObjectPath Normal; // Offset: 0x0 | Size: 0x18
	struct FSoftObjectPath Energy; // Offset: 0x18 | Size: 0x18
};

// Object: ScriptStruct Solarland.NoticeColorData
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FNoticeColorData {
	// Fields
	struct FLinearColor TextBg; // Offset: 0x0 | Size: 0x10
	struct FLinearColor IconBg; // Offset: 0x10 | Size: 0x10
	struct FLinearColor Icon; // Offset: 0x20 | Size: 0x10
};

// Object: ScriptStruct Solarland.CustomNoticeImageRow
// Inherited Bytes: 0x8 | Struct Size: 0x20
struct FCustomNoticeImageRow : FTableRowBase {
	// Fields
	struct FString Remark; // Offset: 0x8 | Size: 0x10
	struct UTexture2D* NoticeIcon; // Offset: 0x18 | Size: 0x8
};

// Object: ScriptStruct Solarland.CustomNoticeRow
// Inherited Bytes: 0x8 | Struct Size: 0x40
struct FCustomNoticeRow : FTableRowBase {
	// Fields
	struct FString Remark; // Offset: 0x8 | Size: 0x10
	int32_t NoticeText; // Offset: 0x18 | Size: 0x4
	enum class ECustomNoticeType NoticeType; // Offset: 0x1c | Size: 0x1
	char pad_0x1D[0x3]; // Offset: 0x1d | Size: 0x3
	float NoticeTime; // Offset: 0x20 | Size: 0x4
	enum class ECustomNoticeColor NoticeColor; // Offset: 0x24 | Size: 0x1
	char pad_0x25[0x3]; // Offset: 0x25 | Size: 0x3
	struct UUINoticeBase* NoticeClass; // Offset: 0x28 | Size: 0x8
	struct FString NoticeIcon; // Offset: 0x30 | Size: 0x10
};

// Object: ScriptStruct Solarland.CustomNoticeID
// Inherited Bytes: 0x0 | Struct Size: 0x1
struct FCustomNoticeID {
	// Fields
	char pad_0x0[0x1]; // Offset: 0x0 | Size: 0x1
};

// Object: ScriptStruct Solarland.BoxChargingInfo
// Inherited Bytes: 0x0 | Struct Size: 0x1c
struct FBoxChargingInfo {
	// Fields
	char pad_0x0[0x1c]; // Offset: 0x0 | Size: 0x1c
};

// Object: ScriptStruct Solarland.TerminatorNotifyUIConfig
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FTerminatorNotifyUIConfig {
	// Fields
	int32_t LocalizationID; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x14]; // Offset: 0x4 | Size: 0x14
	struct UUINoticeBase* TerminatorNotifyUI; // Offset: 0x18 | Size: 0x8
	enum class ECustomNoticeType NoticeType; // Offset: 0x20 | Size: 0x1
	char pad_0x21[0x3]; // Offset: 0x21 | Size: 0x3
	float NoticeTime; // Offset: 0x24 | Size: 0x4
};

// Object: ScriptStruct Solarland.SkeletalMeshOverride
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FSkeletalMeshOverride {
	// Fields
	struct TSoftObjectPtr<USkeletalMesh> MeshOverride; // Offset: 0x0 | Size: 0x28
	struct TSoftObjectPtr<UMaterialInstance> MaterialOverride; // Offset: 0x28 | Size: 0x28
};

// Object: ScriptStruct Solarland.StaticMeshOverride
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FStaticMeshOverride {
	// Fields
	struct TSoftObjectPtr<UStaticMesh> MeshOverride; // Offset: 0x0 | Size: 0x28
	struct TSoftObjectPtr<UMaterialInstance> MaterialOverride; // Offset: 0x28 | Size: 0x28
};

// Object: ScriptStruct Solarland.DuckRollingCharacterHitConfig
// Inherited Bytes: 0x0 | Struct Size: 0xa0
struct FDuckRollingCharacterHitConfig {
	// Fields
	float MinSelfSpeed; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct USolarCharacterGameplayAbility* EnableCharacterHitAbility; // Offset: 0x8 | Size: 0x8
	struct UParticleSystem* SpeedEffect; // Offset: 0x10 | Size: 0x8
	char pad_0x18[0x8]; // Offset: 0x18 | Size: 0x8
	struct FTransform SpeedEffectRelativeTransform; // Offset: 0x20 | Size: 0x30
	float PushUpAngle; // Offset: 0x50 | Size: 0x4
	float UpBoundingRatio; // Offset: 0x54 | Size: 0x4
	struct FVector PushBoxExtent; // Offset: 0x58 | Size: 0xc
	char pad_0x64[0x4]; // Offset: 0x64 | Size: 0x4
	struct UCurveFloat* PushSpeedCurve; // Offset: 0x68 | Size: 0x8
	bool bTeleportTargetOnPush; // Offset: 0x70 | Size: 0x1
	char pad_0x71[0x3]; // Offset: 0x71 | Size: 0x3
	float MinRelativeSpeedForDamage; // Offset: 0x74 | Size: 0x4
	float MinIntervalForDamage; // Offset: 0x78 | Size: 0x4
	float BaseDamage; // Offset: 0x7c | Size: 0x4
	struct UCurveFloat* RelativeSpeedToDamageMultiplierCurve; // Offset: 0x80 | Size: 0x8
	struct UParticleSystem* HitEffect; // Offset: 0x88 | Size: 0x8
	struct FString HitSoundEvent; // Offset: 0x90 | Size: 0x10
};

// Object: ScriptStruct Solarland.EmojiBubbleConfig
// Inherited Bytes: 0x8 | Struct Size: 0x10
struct FEmojiBubbleConfig : FTableRowBase {
	// Fields
	struct USolarUserWidget* EmojiClassType; // Offset: 0x8 | Size: 0x8
};

// Object: ScriptStruct Solarland.BoxBurstItemConfig
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FBoxBurstItemConfig {
	// Fields
	struct UDataTable* ConfigTable; // Offset: 0x0 | Size: 0x8
};

// Object: ScriptStruct Solarland.BurstItemSplitConfig
// Inherited Bytes: 0x8 | Struct Size: 0x40
struct FBurstItemSplitConfig : FTableRowBase {
	// Fields
	int32_t ID; // Offset: 0x8 | Size: 0x4
	char pad_0xC[0x4]; // Offset: 0xc | Size: 0x4
	struct TArray<int32_t> Piles; // Offset: 0x10 | Size: 0x10
	struct TArray<float> ModelScale; // Offset: 0x20 | Size: 0x10
	int32_t MaxPileNum; // Offset: 0x30 | Size: 0x4
	struct FRotator Rotator; // Offset: 0x34 | Size: 0xc
};

// Object: ScriptStruct Solarland.ExpItemReduceRate
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FExpItemReduceRate {
	// Fields
	struct UDataTable* ConfigTable; // Offset: 0x0 | Size: 0x8
};

// Object: ScriptStruct Solarland.ExpItemReduceRateConfig
// Inherited Bytes: 0x8 | Struct Size: 0x10
struct FExpItemReduceRateConfig : FTableRowBase {
	// Fields
	int32_t DeathCount; // Offset: 0x8 | Size: 0x4
	float Rate; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct Solarland.ExpItemConfig
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FExpItemConfig {
	// Fields
	struct UDataTable* ConfigTable; // Offset: 0x0 | Size: 0x8
	struct UDataTable* KilledConfigTable; // Offset: 0x8 | Size: 0x8
};

// Object: ScriptStruct Solarland.ExpItemCountConfig
// Inherited Bytes: 0x8 | Struct Size: 0x18
struct FExpItemCountConfig : FTableRowBase {
	// Fields
	int32_t Lv; // Offset: 0x8 | Size: 0x4
	int32_t ExpItemCount; // Offset: 0xc | Size: 0x4
	int32_t ShieldMatMaxCount; // Offset: 0x10 | Size: 0x4
	char pad_0x14[0x4]; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct Solarland.FeedbackSingleData
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FFeedbackSingleData {
	// Fields
	struct UUserWidget* AnimationWidget; // Offset: 0x0 | Size: 0x8
	struct FName AnimationName; // Offset: 0x8 | Size: 0x8
	float AnimationPlaySpeed; // Offset: 0x10 | Size: 0x4
	float AnimationStartTime; // Offset: 0x14 | Size: 0x4
	float AnimationAgainStartTime; // Offset: 0x18 | Size: 0x4
	int32_t AnimationLoopNumber; // Offset: 0x1c | Size: 0x4
	struct FName AudioName; // Offset: 0x20 | Size: 0x8
	enum class EAnimationType AnimationType; // Offset: 0x28 | Size: 0x1
	char pad_0x29[0x7]; // Offset: 0x29 | Size: 0x7
};

// Object: ScriptStruct Solarland.SElementLevelStreaming
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FSElementLevelStreaming {
	// Fields
	bool LoadWithLevel; // Offset: 0x0 | Size: 0x1
	enum class ELevelLoadType LoadType; // Offset: 0x1 | Size: 0x1
	char pad_0x2[0x6]; // Offset: 0x2 | Size: 0x6
	struct ULevelStreamingDynamic* LevelStreamingDynamic; // Offset: 0x8 | Size: 0x8
};

// Object: ScriptStruct Solarland.LoadingScreenLevelData
// Inherited Bytes: 0x0 | Struct Size: 0x68
struct FLoadingScreenLevelData {
	// Fields
	struct FVector BackupLevelStreamingLocation; // Offset: 0x0 | Size: 0xc
	char pad_0xC[0x4]; // Offset: 0xc | Size: 0x4
	struct TSet<struct FSoftObjectPath> LockupLevels; // Offset: 0x10 | Size: 0x50
	float LockupLevelMaxSquaredXYDistance; // Offset: 0x60 | Size: 0x4
	char pad_0x64[0x4]; // Offset: 0x64 | Size: 0x4
};

// Object: ScriptStruct Solarland.WeaponVibrateDTRow
// Inherited Bytes: 0x8 | Struct Size: 0x80
struct FWeaponVibrateDTRow : FTableRowBase {
	// Fields
	struct FString WeaponDesc; // Offset: 0x8 | Size: 0x10
	struct TMap<enum class EWeaponVibrateType, struct FVibrateDevicePlayParams> WeaponVibrateMap; // Offset: 0x18 | Size: 0x50
	struct FChargeVibratePlayParams ChargeVibrateData; // Offset: 0x68 | Size: 0x18
};

// Object: ScriptStruct Solarland.ChargeVibratePlayParams
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FChargeVibratePlayParams {
	// Fields
	float ChargingIntervalTime; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct UCurveFloat* ChargingFactorCurve; // Offset: 0x8 | Size: 0x8
	struct UCurveFloat* FireFactorCurve; // Offset: 0x10 | Size: 0x8
};

// Object: ScriptStruct Solarland.VibrateDevicePlayParams
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FVibrateDevicePlayParams {
	// Fields
	struct TMap<enum class EVibrateDeviceType, struct FVibratePlayParams> DeviceMap; // Offset: 0x0 | Size: 0x50
};

// Object: ScriptStruct Solarland.VibratePlayParams
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FVibratePlayParams {
	// Fields
	struct FString ClipToPlay; // Offset: 0x0 | Size: 0x10
	int32_t Duration; // Offset: 0x10 | Size: 0x4
	int32_t Loop; // Offset: 0x14 | Size: 0x4
	int32_t Priority; // Offset: 0x18 | Size: 0x4
	int32_t Interval; // Offset: 0x1c | Size: 0x4
	int32_t Amplitude; // Offset: 0x20 | Size: 0x4
	char pad_0x24[0x4]; // Offset: 0x24 | Size: 0x4
};

// Object: ScriptStruct Solarland.VibrateIntensityPlayParams
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FVibrateIntensityPlayParams {
	// Fields
	struct TMap<enum class EGameplayVibrateIntensity, struct FVibrateDevicePlayParams> IntensityMap; // Offset: 0x0 | Size: 0x50
};

// Object: ScriptStruct Solarland.SCMRankListMulticast
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FSCMRankListMulticast {
	// Fields
	int32_t BeginRank; // Offset: 0x0 | Size: 0x4
	int32_t EndRank; // Offset: 0x4 | Size: 0x4
	struct FMulticastInlineDelegate RankListChangeMulticast; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct Solarland.SCMRankEventHandle
// Inherited Bytes: 0x0 | Struct Size: 0x1c
struct FSCMRankEventHandle {
	// Fields
	int32_t BeginRank; // Offset: 0x0 | Size: 0x4
	int32_t EndRank; // Offset: 0x4 | Size: 0x4
	struct FDelegate RankListChangeEvent; // Offset: 0x8 | Size: 0x10
	int32_t Index; // Offset: 0x18 | Size: 0x4
};

// Object: ScriptStruct Solarland.SCMHostData
// Inherited Bytes: 0x0 | Struct Size: 0x488
struct FSCMHostData {
	// Fields
	struct FHostChangeData DataChangeToGlobal; // Offset: 0x0 | Size: 0xf0
	struct FHostChangeData DataChangeToSide; // Offset: 0xf0 | Size: 0xf0
	struct FHostChangeData DataChangeToSelf; // Offset: 0x1e0 | Size: 0xf0
	struct TMap<struct FString, struct FSCMSaveData> DataMap; // Offset: 0x2d0 | Size: 0x50
	struct TMap<struct FString, struct FSCMArrayData> ArrayDataMap; // Offset: 0x320 | Size: 0x50
	struct TMap<struct FString, struct FSCMMapData> MapDataMap; // Offset: 0x370 | Size: 0x50
	char pad_0x3C0[0xa0]; // Offset: 0x3c0 | Size: 0xa0
	struct FMulticastInlineDelegate SCMDataChangeDelegate; // Offset: 0x460 | Size: 0x10
	struct FString Name; // Offset: 0x470 | Size: 0x10
	enum class ESCMHostType HostType; // Offset: 0x480 | Size: 0x1
	char pad_0x481[0x7]; // Offset: 0x481 | Size: 0x7
};

// Object: ScriptStruct Solarland.SCMSaveDataBase
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FSCMSaveDataBase {
	// Fields
	struct FString Name; // Offset: 0x0 | Size: 0x10
	enum class ESCMDataType Type; // Offset: 0x10 | Size: 0x1
	enum class ESCMDataReplicateType RepType; // Offset: 0x11 | Size: 0x1
	char pad_0x12[0x6]; // Offset: 0x12 | Size: 0x6
};

// Object: ScriptStruct Solarland.SCMMapData
// Inherited Bytes: 0x18 | Struct Size: 0x68
struct FSCMMapData : FSCMSaveDataBase {
	// Fields
	char pad_0x18[0x50]; // Offset: 0x18 | Size: 0x50
};

// Object: ScriptStruct Solarland.SCMArrayData
// Inherited Bytes: 0x18 | Struct Size: 0x28
struct FSCMArrayData : FSCMSaveDataBase {
	// Fields
	char pad_0x18[0x10]; // Offset: 0x18 | Size: 0x10
};

// Object: ScriptStruct Solarland.SCMSaveData
// Inherited Bytes: 0x18 | Struct Size: 0x20
struct FSCMSaveData : FSCMSaveDataBase {
	// Fields
	char pad_0x18[0x8]; // Offset: 0x18 | Size: 0x8
};

// Object: ScriptStruct Solarland.HostChangeData
// Inherited Bytes: 0x0 | Struct Size: 0xf0
struct FHostChangeData {
	// Fields
	struct TMap<struct FString, enum class ESCMDataChangeType> DataChangeMap; // Offset: 0x0 | Size: 0x50
	struct TMap<struct FString, struct FSCMChangeDataArray> ArrayChangeMap; // Offset: 0x50 | Size: 0x50
	struct TMap<struct FString, struct FSCMChangeDataMap> MapChangeMap; // Offset: 0xa0 | Size: 0x50
};

// Object: ScriptStruct Solarland.SCMChangeDataMap
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FSCMChangeDataMap {
	// Fields
	struct TArray<enum class ESCMDataChangeType> ChangeType; // Offset: 0x0 | Size: 0x10
	struct TArray<struct FString> ChangeKeyArray; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct Solarland.SCMChangeDataArray
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FSCMChangeDataArray {
	// Fields
	struct TArray<enum class ESCMDataChangeType> ChangeType; // Offset: 0x0 | Size: 0x10
	struct TArray<uint32_t> ChangeIndexArray; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct Solarland.SCMDataBoardRow
// Inherited Bytes: 0x8 | Struct Size: 0x88
struct FSCMDataBoardRow : FTableRowBase {
	// Fields
	enum class ESCMDataType Type; // Offset: 0x8 | Size: 0x1
	enum class ESCMDataSetType DataSetType; // Offset: 0x9 | Size: 0x1
	char pad_0xA[0x6]; // Offset: 0xa | Size: 0x6
	struct FString Default; // Offset: 0x10 | Size: 0x10
	struct TArray<struct FString> DefaultArray; // Offset: 0x20 | Size: 0x10
	struct TMap<struct FString, struct FString> DefaultMap; // Offset: 0x30 | Size: 0x50
	enum class ESCMHostType HostType; // Offset: 0x80 | Size: 0x1
	enum class ESCMDataReplicateType ReplicateType; // Offset: 0x81 | Size: 0x1
	enum class ESCMDataGatherType_Settle SettleGatherType; // Offset: 0x82 | Size: 0x1
	enum class ESCMDataRankType Rank; // Offset: 0x83 | Size: 0x1
	char pad_0x84[0x4]; // Offset: 0x84 | Size: 0x4
};

// Object: ScriptStruct Solarland.SCMGeneralDataBoardRow
// Inherited Bytes: 0x88 | Struct Size: 0x90
struct FSCMGeneralDataBoardRow : FSCMDataBoardRow {
	// Fields
	enum class EStatisticsType MapNameType; // Offset: 0x84 | Size: 0x1
	char pad_0x89[0x7]; // Offset: 0x89 | Size: 0x7
};

// Object: ScriptStruct Solarland.WeaponAttributeGameplayTags
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FWeaponAttributeGameplayTags {
	// Fields
	struct FGameplayTag Spread; // Offset: 0x0 | Size: 0x8
	struct FGameplayTag HorizontalRecoil; // Offset: 0x8 | Size: 0x8
	struct FGameplayTag VerticalRecoil; // Offset: 0x10 | Size: 0x8
};

// Object: ScriptStruct Solarland.AssitLockBoneWeight
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FAssitLockBoneWeight {
	// Fields
	struct FName BoneName; // Offset: 0x0 | Size: 0x8
	float BoneWeight; // Offset: 0x8 | Size: 0x4
};

// Object: ScriptStruct Solarland.GuidanceConditionTableRow
// Inherited Bytes: 0x8 | Struct Size: 0x30
struct FGuidanceConditionTableRow : FTableRowBase {
	// Fields
	char TriggerType; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x7]; // Offset: 0x9 | Size: 0x7
	struct TArray<struct FString> Parameters; // Offset: 0x10 | Size: 0x10
	struct FString Description; // Offset: 0x20 | Size: 0x10
};

// Object: ScriptStruct Solarland.GyroscopeDeviceModel
// Inherited Bytes: 0x8 | Struct Size: 0x18
struct FGyroscopeDeviceModel : FTableRowBase {
	// Fields
	struct FString NotHavingGyroscopeDeviceModelName; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct Solarland.GyroscopeSensitivity
// Inherited Bytes: 0x8 | Struct Size: 0x20
struct FGyroscopeSensitivity : FTableRowBase {
	// Fields
	struct FString Axle; // Offset: 0x8 | Size: 0x10
	float GyroscopeSensitivityArray; // Offset: 0x18 | Size: 0x4
	char pad_0x1C[0x4]; // Offset: 0x1c | Size: 0x4
};

// Object: ScriptStruct Solarland.GyroscopeDTRow
// Inherited Bytes: 0x8 | Struct Size: 0x10
struct FGyroscopeDTRow : FTableRowBase {
	// Fields
	int32_t ID; // Offset: 0x8 | Size: 0x4
	float GyroscopeFactor; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct Solarland.PlayerSelectInfo
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FPlayerSelectInfo {
	// Fields
	struct ASolarPlayerState* Player; // Offset: 0x0 | Size: 0x8
	int32_t PlayerPos; // Offset: 0x8 | Size: 0x4
	int32_t CharacterId; // Offset: 0xc | Size: 0x4
	int32_t SkinId; // Offset: 0x10 | Size: 0x4
	int32_t HeroExpLevel; // Offset: 0x14 | Size: 0x4
	bool HasConfirm; // Offset: 0x18 | Size: 0x1
	char pad_0x19[0x3]; // Offset: 0x19 | Size: 0x3
	float PlayerSelectTime; // Offset: 0x1c | Size: 0x4
	bool IsInHeroPickProcess; // Offset: 0x20 | Size: 0x1
	char pad_0x21[0x7]; // Offset: 0x21 | Size: 0x7
};

// Object: ScriptStruct Solarland.AIPickHeroInfo
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FAIPickHeroInfo {
	// Fields
	int32_t CharacterId; // Offset: 0x0 | Size: 0x4
	int32_t SkinId; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct Solarland.PlayerSelection
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FPlayerSelection {
	// Fields
	struct ASolarPlayerState* PlayerState; // Offset: 0x0 | Size: 0x8
	struct TWeakObjectPtr<struct UHeroPickCharacterData> SelectionData; // Offset: 0x8 | Size: 0x8
	int32_t CachedPos; // Offset: 0x10 | Size: 0x4
	char pad_0x14[0x4]; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct Solarland.AlertConfig
// Inherited Bytes: 0x0 | Struct Size: 0xd0
struct FAlertConfig {
	// Fields
	bool bShowDebug; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	float TickInterval; // Offset: 0x4 | Size: 0x4
	float HighAlertAngle; // Offset: 0x8 | Size: 0x4
	float HighAlertRadiusMin; // Offset: 0xc | Size: 0x4
	float HighAlertRadiusMax; // Offset: 0x10 | Size: 0x4
	struct FVector2D HighAlertBoxExtent; // Offset: 0x14 | Size: 0x8
	char pad_0x1C[0x4]; // Offset: 0x1c | Size: 0x4
	struct TMap<enum class EAlertDirection, float> AlertCD; // Offset: 0x20 | Size: 0x50
	float VoiceCD; // Offset: 0x70 | Size: 0x4
	int32_t VoiceID; // Offset: 0x74 | Size: 0x4
	float NoticeCD; // Offset: 0x78 | Size: 0x4
	char pad_0x7C[0x4]; // Offset: 0x7c | Size: 0x4
	struct TArray<struct FName> OcclusionCheckBones; // Offset: 0x80 | Size: 0x10
	struct FGameplayTagContainer SelfBlockTags; // Offset: 0x90 | Size: 0x20
	struct FGameplayTagContainer EnemyBlockTags; // Offset: 0xb0 | Size: 0x20
};

// Object: ScriptStruct Solarland.SoundGroupTableDataBase
// Inherited Bytes: 0x8 | Struct Size: 0x8
struct FSoundGroupTableDataBase : FTableRowBase {
};

// Object: ScriptStruct Solarland.SoundGroupHitSoundTableData
// Inherited Bytes: 0x8 | Struct Size: 0x18
struct FSoundGroupHitSoundTableData : FSoundGroupTableDataBase {
	// Fields
	struct FString SoundEvent; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct Solarland.SoundGroupHitSoundWwiseParams
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FSoundGroupHitSoundWwiseParams {
	// Fields
	struct FString SwitchGroup; // Offset: 0x0 | Size: 0x10
	struct FString SwitchState_IAttackOther; // Offset: 0x10 | Size: 0x10
	struct FString SwitchState_OtherAttackMe; // Offset: 0x20 | Size: 0x10
	struct FString SwitchState_Other; // Offset: 0x30 | Size: 0x10
};

// Object: ScriptStruct Solarland.HitSoundTableData
// Inherited Bytes: 0x8 | Struct Size: 0x68
struct FHitSoundTableData : FTableRowBase {
	// Fields
	struct UDataTable* SubTableData; // Offset: 0x8 | Size: 0x8
	struct FName Default; // Offset: 0x10 | Size: 0x8
	struct FName CharacterBody; // Offset: 0x18 | Size: 0x8
	struct FName CharacterHead; // Offset: 0x20 | Size: 0x8
	struct FName CharacterShieldBody; // Offset: 0x28 | Size: 0x8
	struct FName CharacterShieldHead; // Offset: 0x30 | Size: 0x8
	struct FName CharacterHitDown; // Offset: 0x38 | Size: 0x8
	struct FName CharacterKill; // Offset: 0x40 | Size: 0x8
	struct FName CharacterKill2; // Offset: 0x48 | Size: 0x8
	struct FName Vehicle; // Offset: 0x50 | Size: 0x8
	struct FName SummonItemSolid; // Offset: 0x58 | Size: 0x8
	struct FName SummonItemVirtual; // Offset: 0x60 | Size: 0x8
};

// Object: ScriptStruct Solarland.HitTraceMeshWidgetData
// Inherited Bytes: 0x0 | Struct Size: 0x3c
struct FHitTraceMeshWidgetData {
	// Fields
	char pad_0x0[0x4]; // Offset: 0x0 | Size: 0x4
	struct FHitTraceData HitTraceSourceData; // Offset: 0x4 | Size: 0x18
	struct FVector2D Position; // Offset: 0x1c | Size: 0x8
	float Scale; // Offset: 0x24 | Size: 0x4
	int32_t Angle; // Offset: 0x28 | Size: 0x4
	float Opacity; // Offset: 0x2c | Size: 0x4
	char IconIndex; // Offset: 0x30 | Size: 0x1
	char ColorIdx; // Offset: 0x31 | Size: 0x1
	char pad_0x32[0x2]; // Offset: 0x32 | Size: 0x2
	int32_t ArcLength; // Offset: 0x34 | Size: 0x4
	int32_t SniperLength; // Offset: 0x38 | Size: 0x4
};

// Object: ScriptStruct Solarland.HitTraceData
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FHitTraceData {
	// Fields
	enum class EHitTraceType Type; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	struct FVector TraceDirection; // Offset: 0x4 | Size: 0xc
	float Damage; // Offset: 0x10 | Size: 0x4
	float HitTime; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct Solarland.ServerMoveData
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FServerMoveData {
	// Fields
	float Timestamp; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	int64_t ServerTimeStamp; // Offset: 0x8 | Size: 0x8
	struct FVector Acceleration; // Offset: 0x10 | Size: 0xc
	struct FVector Velocity; // Offset: 0x1c | Size: 0xc
	struct FVector Loction; // Offset: 0x28 | Size: 0xc
	char CompressedMoveFlags; // Offset: 0x34 | Size: 0x1
	char RollByte; // Offset: 0x35 | Size: 0x1
	char pad_0x36[0x2]; // Offset: 0x36 | Size: 0x2
	uint32_t YawPitchInt; // Offset: 0x38 | Size: 0x4
	char MovementMode; // Offset: 0x3c | Size: 0x1
	char pad_0x3D[0x3]; // Offset: 0x3d | Size: 0x3
	uint32_t FullBodyAnimationState; // Offset: 0x40 | Size: 0x4
	uint32_t MontageAnimState; // Offset: 0x44 | Size: 0x4
	char JetPackFlag; // Offset: 0x48 | Size: 0x1
	bool bValid; // Offset: 0x49 | Size: 0x1
	char pad_0x4A[0x6]; // Offset: 0x4a | Size: 0x6
};

// Object: ScriptStruct Solarland.SolarAerialReconnaissanceConfig
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FSolarAerialReconnaissanceConfig {
	// Fields
	int32_t MarkMaximum; // Offset: 0x0 | Size: 0x4
	bool bMarkTeamMode; // Offset: 0x4 | Size: 0x1
	char pad_0x5[0x3]; // Offset: 0x5 | Size: 0x3
};

// Object: ScriptStruct Solarland.RichHlinkRow
// Inherited Bytes: 0x8 | Struct Size: 0x870
struct FRichHlinkRow : FTableRowBase {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FHyperlinkStyle HlinkStyle; // Offset: 0x10 | Size: 0x860
};

// Object: ScriptStruct Solarland.InGameLevelingConfig
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FInGameLevelingConfig {
	// Fields
	struct UDataTable* ExpTable; // Offset: 0x0 | Size: 0x8
};

// Object: ScriptStruct Solarland.InGameExpConifg
// Inherited Bytes: 0x8 | Struct Size: 0x10
struct FInGameExpConifg : FTableRowBase {
	// Fields
	int32_t Lv; // Offset: 0x8 | Size: 0x4
	int32_t Exp; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct Solarland.JobManagerConfig
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FJobManagerConfig {
	// Fields
	struct UDataTable* JobTable; // Offset: 0x0 | Size: 0x8
};

// Object: ScriptStruct Solarland.KeyMapDisplayRowInfo
// Inherited Bytes: 0x8 | Struct Size: 0x18
struct FKeyMapDisplayRowInfo : FTableRowBase {
	// Fields
	struct FString DisplayName; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct Solarland.KeyMappingJsonData
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FKeyMappingJsonData {
	// Fields
	struct TArray<struct FKeyMappingRowInfo> JsonData; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Solarland.KeyMappingRowInfo
// Inherited Bytes: 0x8 | Struct Size: 0x98
struct FKeyMappingRowInfo : FTableRowBase {
	// Fields
	struct FString Label; // Offset: 0x8 | Size: 0x10
	struct FString ActionDisplayName; // Offset: 0x18 | Size: 0x10
	struct FString ActionName; // Offset: 0x28 | Size: 0x10
	bool Continuity; // Offset: 0x38 | Size: 0x1
	char pad_0x39[0x3]; // Offset: 0x39 | Size: 0x3
	float Scale; // Offset: 0x3c | Size: 0x4
	struct FString RealAction; // Offset: 0x40 | Size: 0x10
	struct TArray<struct FString> FirstDefaultKeys; // Offset: 0x50 | Size: 0x10
	struct TArray<struct FString> SecondDefaultKeys; // Offset: 0x60 | Size: 0x10
	struct FString Description; // Offset: 0x70 | Size: 0x10
	struct TArray<struct FString> RelatedActions; // Offset: 0x80 | Size: 0x10
	bool Stationary; // Offset: 0x90 | Size: 0x1
	char pad_0x91[0x7]; // Offset: 0x91 | Size: 0x7
};

// Object: ScriptStruct Solarland.KillInfoMessage
// Inherited Bytes: 0x0 | Struct Size: 0x38
struct FKillInfoMessage {
	// Fields
	char pad_0x0[0x38]; // Offset: 0x0 | Size: 0x38
};

// Object: ScriptStruct Solarland.KillEffectExtraInfo
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FKillEffectExtraInfo {
	// Fields
	char pad_0x0[0xc]; // Offset: 0x0 | Size: 0xc
};

// Object: ScriptStruct Solarland.KillExtraInfo
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FKillExtraInfo {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Solarland.EShopDisplayData
// Inherited Bytes: 0x0 | Struct Size: 0x58
struct FEShopDisplayData {
	// Fields
	int32_t ItemID; // Offset: 0x0 | Size: 0x4
	float Price; // Offset: 0x4 | Size: 0x4
	float UndiscountedPrice; // Offset: 0x8 | Size: 0x4
	int32_t Num; // Offset: 0xc | Size: 0x4
	int32_t ProductID; // Offset: 0x10 | Size: 0x4
	float CoolDown; // Offset: 0x14 | Size: 0x4
	int32_t Generation; // Offset: 0x18 | Size: 0x4
	bool bIsRecommend; // Offset: 0x1c | Size: 0x1
	char pad_0x1D[0x3]; // Offset: 0x1d | Size: 0x3
	struct FString Name; // Offset: 0x20 | Size: 0x10
	struct FString Icon; // Offset: 0x30 | Size: 0x10
	struct FString Info; // Offset: 0x40 | Size: 0x10
	int32_t Quality; // Offset: 0x50 | Size: 0x4
	int32_t ItemType; // Offset: 0x54 | Size: 0x4
};

// Object: ScriptStruct Solarland.ULoadingDataEntry
// Inherited Bytes: 0x0 | Struct Size: 0xb8
struct FULoadingDataEntry {
	// Fields
	struct FSoftObjectPath LoadingBg; // Offset: 0x0 | Size: 0x18
	struct TArray<int32_t> TipIntArray; // Offset: 0x18 | Size: 0x10
	struct TArray<struct FWrappedLocalTextID> TipLocalTitleArray; // Offset: 0x28 | Size: 0x10
	struct TArray<struct FWrappedLocalTextID> TipLocalLeftArray; // Offset: 0x38 | Size: 0x10
	struct TArray<struct FWrappedLocalTextID> TipLocalMidArray; // Offset: 0x48 | Size: 0x10
	struct TArray<struct FWrappedLocalTextID> TipLocalRightArray; // Offset: 0x58 | Size: 0x10
	struct TArray<struct FString> TipArray; // Offset: 0x68 | Size: 0x10
	struct TArray<struct FString> TipTitleArray; // Offset: 0x78 | Size: 0x10
	struct TArray<struct FString> TipLeftArray; // Offset: 0x88 | Size: 0x10
	struct TArray<struct FString> TipMidArray; // Offset: 0x98 | Size: 0x10
	struct TArray<struct FString> TipRightArray; // Offset: 0xa8 | Size: 0x10
};

// Object: ScriptStruct Solarland.MassInvStateTransitionData
// Inherited Bytes: 0x0 | Struct Size: 0x90
struct FMassInvStateTransitionData {
	// Fields
	float TransitionTime; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct FRuntimeFloatCurve TransitionCurve; // Offset: 0x8 | Size: 0x88
};

// Object: ScriptStruct Solarland.MassInvStateMaterialParams
// Inherited Bytes: 0x0 | Struct Size: 0x78
struct FMassInvStateMaterialParams {
	// Fields
	struct FMassInvMaterialParams PrepareParams; // Offset: 0x0 | Size: 0x28
	struct FMassInvMaterialParams NormalParams; // Offset: 0x28 | Size: 0x28
	struct FMassInvMaterialParams SprintParams; // Offset: 0x50 | Size: 0x28
};

// Object: ScriptStruct Solarland.MassInvMaterialParams
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FMassInvMaterialParams {
	// Fields
	float PatternResolution; // Offset: 0x0 | Size: 0x4
	float Detail; // Offset: 0x4 | Size: 0x4
	float MaskBlend; // Offset: 0x8 | Size: 0x4
	float Opacity; // Offset: 0xc | Size: 0x4
	float StealthAdjust; // Offset: 0x10 | Size: 0x4
	float Tilling; // Offset: 0x14 | Size: 0x4
	struct FLinearColor BaseColor; // Offset: 0x18 | Size: 0x10
};

// Object: ScriptStruct Solarland.MatchResult
// Inherited Bytes: 0x0 | Struct Size: 0x80
struct FMatchResult {
	// Fields
	struct FString BattleID; // Offset: 0x0 | Size: 0x10
	struct FString BattleAddr; // Offset: 0x10 | Size: 0x10
	struct FString Token; // Offset: 0x20 | Size: 0x10
	int32_t ModeID; // Offset: 0x30 | Size: 0x4
	int32_t RuleID; // Offset: 0x34 | Size: 0x4
	struct FString SelfPlayerID; // Offset: 0x38 | Size: 0x10
	struct TArray<struct FMatchResult_Group> Groups; // Offset: 0x48 | Size: 0x10
	struct FString MapName; // Offset: 0x58 | Size: 0x10
	struct FSoftObjectPath MapPath; // Offset: 0x68 | Size: 0x18
};

// Object: ScriptStruct Solarland.MatchResult_Group
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FMatchResult_Group {
	// Fields
	int32_t groupid; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct TArray<struct FMatchResult_Player> Players; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct Solarland.MatchResult_Player
// Inherited Bytes: 0x0 | Struct Size: 0x58
struct FMatchResult_Player {
	// Fields
	struct FString PlayerId; // Offset: 0x0 | Size: 0x10
	struct FString playerName; // Offset: 0x10 | Size: 0x10
	int32_t AvatarID; // Offset: 0x20 | Size: 0x4
	int32_t fightCharacterID; // Offset: 0x24 | Size: 0x4
	int32_t fightCharacterSkinID; // Offset: 0x28 | Size: 0x4
	char pad_0x2C[0x4]; // Offset: 0x2c | Size: 0x4
	struct FSoftObjectPath SkinConfigPath; // Offset: 0x30 | Size: 0x18
	struct FString CharacterName; // Offset: 0x48 | Size: 0x10
};

// Object: ScriptStruct Solarland.MaterialVariableChange
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FMaterialVariableChange {
	// Fields
	struct FName Variable; // Offset: 0x0 | Size: 0x8
	float FromValue; // Offset: 0x8 | Size: 0x4
	float ToValue; // Offset: 0xc | Size: 0x4
	float BeginProgress; // Offset: 0x10 | Size: 0x4
	float EndProgress; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct Solarland.MapMarkElemArray
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FMapMarkElemArray {
	// Fields
	struct TArray<struct FMapMarkElem> MapMarkElems; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Solarland.MapMarkElem
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FMapMarkElem {
	// Fields
	struct UMapMarkBase* MapMark; // Offset: 0x0 | Size: 0x8
	bool bUsing; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x7]; // Offset: 0x9 | Size: 0x7
};

// Object: ScriptStruct Solarland.AirdropMeshWidgetData
// Inherited Bytes: 0x0 | Struct Size: 0x48
struct FAirdropMeshWidgetData {
	// Fields
	struct FConfigMiniMapMeshWidgetData IconData; // Offset: 0x0 | Size: 0x18
	struct FConfigMiniMapMeshWidgetData DiffuseData; // Offset: 0x18 | Size: 0x18
	struct FConfigMiniMapMeshWidgetData FlashData; // Offset: 0x30 | Size: 0x18
};

// Object: ScriptStruct Solarland.ConfigMiniMapMeshWidgetData
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FConfigMiniMapMeshWidgetData {
	// Fields
	float TimeSpeed; // Offset: 0x0 | Size: 0x4
	char IconTexId; // Offset: 0x4 | Size: 0x1
	char ColorOpacityIndex; // Offset: 0x5 | Size: 0x1
	char pad_0x6[0x2]; // Offset: 0x6 | Size: 0x2
	struct FVector2D OpacityCoeff; // Offset: 0x8 | Size: 0x8
	struct FVector2D ScaleAndRipplingCoeff; // Offset: 0x10 | Size: 0x8
};

// Object: ScriptStruct Solarland.MiniMapData
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FMiniMapData {
	// Fields
	bool bUseAsBigMap; // Offset: 0x0 | Size: 0x1
	bool bOverride; // Offset: 0x1 | Size: 0x1
	char pad_0x2[0x2]; // Offset: 0x2 | Size: 0x2
	float MinFOV; // Offset: 0x4 | Size: 0x4
	float MaxFOV; // Offset: 0x8 | Size: 0x4
	float CurrentFOV; // Offset: 0xc | Size: 0x4
	struct FVector2D MapSize; // Offset: 0x10 | Size: 0x8
};

// Object: ScriptStruct Solarland.MissileBulletConfig
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FMissileBulletConfig {
	// Fields
	struct FVector EjectDir; // Offset: 0x0 | Size: 0xc
	float EjectDelayTime; // Offset: 0xc | Size: 0x4
	struct TArray<int32_t> TrailSpreadIndexArray; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct Solarland.MissileBullet
// Inherited Bytes: 0x0 | Struct Size: 0x68
struct FMissileBullet {
	// Fields
	char pad_0x0[0x40]; // Offset: 0x0 | Size: 0x40
	struct UParticleSystemComponent* BulletEffect; // Offset: 0x40 | Size: 0x8
	struct UParticleSystemComponent* RibbonTrajectoryEffect; // Offset: 0x48 | Size: 0x8
	struct AMissileSwarmLauncher* Launcher; // Offset: 0x50 | Size: 0x8
	char pad_0x58[0x10]; // Offset: 0x58 | Size: 0x10
};

// Object: ScriptStruct Solarland.MissileBulletSpawnParameter
// Inherited Bytes: 0x0 | Struct Size: 0x48
struct FMissileBulletSpawnParameter {
	// Fields
	struct FFireUniqueID FireUniqueID; // Offset: 0x0 | Size: 0x4
	struct FVector EjectLoc; // Offset: 0x4 | Size: 0xc
	struct FVector EjectDir; // Offset: 0x10 | Size: 0xc
	struct FVector TargetLoc; // Offset: 0x1c | Size: 0xc
	float EjectTimeStamp; // Offset: 0x28 | Size: 0x4
	float EjectDelayTime; // Offset: 0x2c | Size: 0x4
	struct TArray<int32_t> TrailSpreadIndexArray; // Offset: 0x30 | Size: 0x10
	int32_t SwarmIndex; // Offset: 0x40 | Size: 0x4
	char pad_0x44[0x4]; // Offset: 0x44 | Size: 0x4
};

// Object: ScriptStruct Solarland.FireUniqueID
// Inherited Bytes: 0x0 | Struct Size: 0x4
struct FFireUniqueID {
	// Fields
	uint32_t Data; // Offset: 0x0 | Size: 0x4
};

// Object: ScriptStruct Solarland.DetailedTeamListViewInfo
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FDetailedTeamListViewInfo {
	// Fields
	int32_t TeamID; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct FString TeamName; // Offset: 0x8 | Size: 0x10
	int32_t Rank; // Offset: 0x18 | Size: 0x4
	int32_t Point; // Offset: 0x1c | Size: 0x4
	uint32_t PreliminaryRank; // Offset: 0x20 | Size: 0x4
	char pad_0x24[0x4]; // Offset: 0x24 | Size: 0x4
	struct TArray<struct FDetailedListViewInfo> PlayerDetailInfos; // Offset: 0x28 | Size: 0x10
	bool bIsTournament; // Offset: 0x38 | Size: 0x1
	char pad_0x39[0x7]; // Offset: 0x39 | Size: 0x7
};

// Object: ScriptStruct Solarland.DetailedListViewInfo
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FDetailedListViewInfo {
	// Fields
	bool bIsUsingStructInfo; // Offset: 0x0 | Size: 0x1
	bool bIsCheater; // Offset: 0x1 | Size: 0x1
	bool bIsMVP; // Offset: 0x2 | Size: 0x1
	char pad_0x3[0x5]; // Offset: 0x3 | Size: 0x5
	struct FString playerName; // Offset: 0x8 | Size: 0x10
	int32_t KillNum; // Offset: 0x18 | Size: 0x4
	int32_t AssistNum; // Offset: 0x1c | Size: 0x4
	float CauseDamage; // Offset: 0x20 | Size: 0x4
	float ReceivedDamage; // Offset: 0x24 | Size: 0x4
	float HealSelf; // Offset: 0x28 | Size: 0x4
	float ReceivedHeal; // Offset: 0x2c | Size: 0x4
	float LifeTime; // Offset: 0x30 | Size: 0x4
	float MvpScore; // Offset: 0x34 | Size: 0x4
	int32_t FlagID; // Offset: 0x38 | Size: 0x4
	enum class ECommonInputType InputType; // Offset: 0x3c | Size: 0x1
	char pad_0x3D[0x3]; // Offset: 0x3d | Size: 0x3
};

// Object: ScriptStruct Solarland.ConfigMeshData
// Inherited Bytes: 0x0 | Struct Size: 0x18c
struct FConfigMeshData {
	// Fields
	bool bTeamVisible; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	int32_t TeamID; // Offset: 0x4 | Size: 0x4
	struct FVector2D TenOffset; // Offset: 0x8 | Size: 0x8
	struct FVector2D OneOffset; // Offset: 0x10 | Size: 0x8
	struct FLinearColor MainColor; // Offset: 0x18 | Size: 0x10
	struct FLinearColor ViceColor; // Offset: 0x28 | Size: 0x10
	bool bShieldVisible; // Offset: 0x38 | Size: 0x1
	char pad_0x39[0x3]; // Offset: 0x39 | Size: 0x3
	struct FProgressMeshData Shield; // Offset: 0x3c | Size: 0x1c
	struct FProgressMeshData ShieldDamage; // Offset: 0x58 | Size: 0x1c
	struct FProgressMeshData ShieldBG; // Offset: 0x74 | Size: 0x1c
	bool bHPVisible; // Offset: 0x90 | Size: 0x1
	char pad_0x91[0x3]; // Offset: 0x91 | Size: 0x3
	struct FProgressMeshData HP; // Offset: 0x94 | Size: 0x1c
	struct FProgressMeshData HPDamage; // Offset: 0xb0 | Size: 0x1c
	struct FProgressMeshData HPBG; // Offset: 0xcc | Size: 0x1c
	struct FMidProgressData MidShield; // Offset: 0xe8 | Size: 0x3c
	struct FMidProgressData MidHP; // Offset: 0x124 | Size: 0x3c
	struct FProgressMeshData MidBG; // Offset: 0x160 | Size: 0x1c
	struct FVector2D ScreenOffset; // Offset: 0x17c | Size: 0x8
	char pad_0x184[0x8]; // Offset: 0x184 | Size: 0x8
};

// Object: ScriptStruct Solarland.ProgressMeshData
// Inherited Bytes: 0x0 | Struct Size: 0x1c
struct FProgressMeshData {
	// Fields
	float Progress; // Offset: 0x0 | Size: 0x4
	struct FLinearColor Color; // Offset: 0x4 | Size: 0x10
	struct FVector2D Offset; // Offset: 0x14 | Size: 0x8
};

// Object: ScriptStruct Solarland.MidProgressData
// Inherited Bytes: 0x0 | Struct Size: 0x3c
struct FMidProgressData {
	// Fields
	bool bVisible; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	struct FProgressMeshData Data; // Offset: 0x4 | Size: 0x1c
	struct FProgressMeshData BGData; // Offset: 0x20 | Size: 0x1c
};

// Object: ScriptStruct Solarland.ReplayPlayerOverviewData
// Inherited Bytes: 0x0 | Struct Size: 0x60
struct FReplayPlayerOverviewData {
	// Fields
	struct FString playerName; // Offset: 0x0 | Size: 0x10
	struct FString HeroName; // Offset: 0x10 | Size: 0x10
	struct TSoftObjectPtr<UTexture2D> SkinResourcePtr; // Offset: 0x20 | Size: 0x28
	int32_t PlayerNum; // Offset: 0x48 | Size: 0x4
	char pad_0x4C[0x4]; // Offset: 0x4c | Size: 0x4
	struct FString GameModeName; // Offset: 0x50 | Size: 0x10
};

// Object: ScriptStruct Solarland.TeamPlayerNavArray
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FTeamPlayerNavArray {
	// Fields
	struct TArray<struct UOBPlayerNavWidget*> NavArray; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Solarland.CupViewInfo
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FCupViewInfo {
	// Fields
	struct FString TournamentName; // Offset: 0x0 | Size: 0x10
	struct FString TournamentIcon; // Offset: 0x10 | Size: 0x10
	int32_t GameModeId; // Offset: 0x20 | Size: 0x4
	int32_t RuleID; // Offset: 0x24 | Size: 0x4
};

// Object: ScriptStruct Solarland.OpponentPerspectiveMaterialParamsConditional
// Inherited Bytes: 0x0 | Struct Size: 0x270
struct FOpponentPerspectiveMaterialParamsConditional {
	// Fields
	struct FGameplayTagRequirements OpponentTagRequirements; // Offset: 0x0 | Size: 0x50
	struct FOpponentPerspectiveMaterialParams MaterialParams; // Offset: 0x50 | Size: 0x220
};

// Object: ScriptStruct Solarland.OpponentPerspectiveMaterialParams
// Inherited Bytes: 0x0 | Struct Size: 0x220
struct FOpponentPerspectiveMaterialParams {
	// Fields
	struct FRuntimeFloatCurve OpacityCurve; // Offset: 0x0 | Size: 0x88
	struct FRuntimeFloatCurve OutlineSizeCurve; // Offset: 0x88 | Size: 0x88
	struct FRuntimeFloatCurve OpacityScaleByFOVCurve; // Offset: 0x110 | Size: 0x88
	struct FRuntimeFloatCurve OutlineSizeScaleByFOVCurve; // Offset: 0x198 | Size: 0x88
};

// Object: ScriptStruct Solarland.PassiveSkillLevelDescription
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FPassiveSkillLevelDescription {
	// Fields
	struct FWrappedLocalTextID InnerDescriptionLocalTextID; // Offset: 0x0 | Size: 0x4
	struct FWrappedLocalTextID ShortDescriptionLocalTextID; // Offset: 0x4 | Size: 0x4
	struct FSoftObjectPath InnerIconPath; // Offset: 0x8 | Size: 0x18
};

// Object: ScriptStruct Solarland.BackpackAnimInfo
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FBackpackAnimInfo {
	// Fields
	int32_t StartFrame; // Offset: 0x0 | Size: 0x4
	int32_t EndFrame; // Offset: 0x4 | Size: 0x4
	float Length; // Offset: 0x8 | Size: 0x4
};

// Object: ScriptStruct Solarland.SwitchEffectInfo
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FSwitchEffectInfo {
	// Fields
	struct UMeshComponent* MeshComp; // Offset: 0x0 | Size: 0x8
	struct TArray<struct UMaterialInstanceDynamic*> EffectMat; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct Solarland.RookieGuidanceTableRow
// Inherited Bytes: 0x8 | Struct Size: 0xc0
struct FRookieGuidanceTableRow : FTableRowBase {
	// Fields
	char groupid; // Offset: 0x8 | Size: 0x1
	char Tag; // Offset: 0x9 | Size: 0x1
	bool IfBindedWidget; // Offset: 0xa | Size: 0x1
	char pad_0xB[0x5]; // Offset: 0xb | Size: 0x5
	struct FString TriggerCondition; // Offset: 0x10 | Size: 0x10
	float TriggerDelayTime; // Offset: 0x20 | Size: 0x4
	char TriggerStage; // Offset: 0x24 | Size: 0x1
	char pad_0x25[0x3]; // Offset: 0x25 | Size: 0x3
	struct FString GuideBPName; // Offset: 0x28 | Size: 0x10
	struct FVector2D GuideBPLocation; // Offset: 0x38 | Size: 0x8
	int32_t GuideBPScale; // Offset: 0x40 | Size: 0x4
	char pad_0x44[0x4]; // Offset: 0x44 | Size: 0x4
	struct FString RelatedUI; // Offset: 0x48 | Size: 0x10
	struct FVector2D RelatedUILocation; // Offset: 0x58 | Size: 0x8
	int32_t RelatedUIScale; // Offset: 0x60 | Size: 0x4
	int32_t LocTextID; // Offset: 0x64 | Size: 0x4
	struct FVector2D LocTextLocation; // Offset: 0x68 | Size: 0x8
	float LocTextDuration; // Offset: 0x70 | Size: 0x4
	char pad_0x74[0x4]; // Offset: 0x74 | Size: 0x4
	struct FString EndCondition; // Offset: 0x78 | Size: 0x10
	float EndDelayTime; // Offset: 0x88 | Size: 0x4
	char pad_0x8C[0x4]; // Offset: 0x8c | Size: 0x4
	struct FString InterruptCondition; // Offset: 0x90 | Size: 0x10
	char SingleRoundTriggerMax; // Offset: 0xa0 | Size: 0x1
	char TotalTriggerMax; // Offset: 0xa1 | Size: 0x1
	char pad_0xA2[0x6]; // Offset: 0xa2 | Size: 0x6
	struct FString FinishCondition; // Offset: 0xa8 | Size: 0x10
	bool IfUpload; // Offset: 0xb8 | Size: 0x1
	bool IfMandatory; // Offset: 0xb9 | Size: 0x1
	char pad_0xBA[0x6]; // Offset: 0xba | Size: 0x6
};

// Object: ScriptStruct Solarland.BuildingData
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FBuildingData {
	// Fields
	struct FString BuildingLocation; // Offset: 0x0 | Size: 0x10
	struct FString BuildingIconName; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct Solarland.ChargingZone
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FChargingZone {
	// Fields
	float Level1; // Offset: 0x0 | Size: 0x4
	float Level2; // Offset: 0x4 | Size: 0x4
	float Level3; // Offset: 0x8 | Size: 0x4
	float Level4; // Offset: 0xc | Size: 0x4
	char pad_0x10[0x10]; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct Solarland.SCustomMode_PlayerReport
// Inherited Bytes: 0x498 | Struct Size: 0x4e8
struct FSCustomMode_PlayerReport : FSolarPlayerReport {
	// Fields
	struct TMap<int32_t, int32_t> RewardItems; // Offset: 0x498 | Size: 0x50
};

// Object: ScriptStruct Solarland.SeparatedPackageInfo
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FSeparatedPackageInfo {
	// Fields
	int32_t SeparetedPkgID; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct TArray<int32_t> ChunksInPkg; // Offset: 0x8 | Size: 0x10
	struct TArray<int32_t> DependentPkgID; // Offset: 0x18 | Size: 0x10
};

// Object: ScriptStruct Solarland.SettlementConfig
// Inherited Bytes: 0x8 | Struct Size: 0x80
struct FSettlementConfig : FTableRowBase {
	// Fields
	int32_t SettlementID; // Offset: 0x8 | Size: 0x4
	char pad_0xC[0x4]; // Offset: 0xc | Size: 0x4
	struct FSettlementStageConfig StageConfig; // Offset: 0x10 | Size: 0x40
	struct TSoftClassPtr<UObject> Formula; // Offset: 0x50 | Size: 0x28
	bool IsValidData; // Offset: 0x78 | Size: 0x1
	char pad_0x79[0x7]; // Offset: 0x79 | Size: 0x7
};

// Object: ScriptStruct Solarland.SettlementStageConfig
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FSettlementStageConfig {
	// Fields
	struct TSoftClassPtr<UObject> Page_Die; // Offset: 0x0 | Size: 0x28
	int32_t Page_SkipIndex; // Offset: 0x28 | Size: 0x4
	char pad_0x2C[0x4]; // Offset: 0x2c | Size: 0x4
	struct TArray<struct TSoftClassPtr<UObject>> SettlementStage; // Offset: 0x30 | Size: 0x10
};

// Object: ScriptStruct Solarland.SettlementParam_Zomborg
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FSettlementParam_Zomborg {
	// Fields
	struct ASolarPlayerState* PS; // Offset: 0x0 | Size: 0x8
	float LifeTime; // Offset: 0x8 | Size: 0x4
	int32_t PlayerRank; // Offset: 0xc | Size: 0x4
	float GoldPunishRate; // Offset: 0x10 | Size: 0x4
	char pad_0x14[0x4]; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct Solarland.SettlementParam_PageParam
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FSettlementParam_PageParam {
	// Fields
	bool IsMVP; // Offset: 0x0 | Size: 0x1
	bool IsAce; // Offset: 0x1 | Size: 0x1
	bool IsVictory; // Offset: 0x2 | Size: 0x1
	char pad_0x3[0x1]; // Offset: 0x3 | Size: 0x1
	int32_t WeaponExpSettlmentNum; // Offset: 0x4 | Size: 0x4
	bool IsRankFight; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x3]; // Offset: 0x9 | Size: 0x3
};

// Object: ScriptStruct Solarland.SettlementParam_KDA
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FSettlementParam_KDA {
	// Fields
	struct ASolarPlayerState* PS; // Offset: 0x0 | Size: 0x8
	int32_t KillNum; // Offset: 0x8 | Size: 0x4
	int32_t DeathNum; // Offset: 0xc | Size: 0x4
	int32_t AssitNum; // Offset: 0x10 | Size: 0x4
	char pad_0x14[0x4]; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct Solarland.SettlementParam_MVP
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FSettlementParam_MVP {
	// Fields
	struct ASolarPlayerState* PS; // Offset: 0x0 | Size: 0x8
	int32_t KillNum; // Offset: 0x8 | Size: 0x4
	int32_t DownNum; // Offset: 0xc | Size: 0x4
	int32_t AssitNum; // Offset: 0x10 | Size: 0x4
	int32_t SaveNum; // Offset: 0x14 | Size: 0x4
	float LifeTime; // Offset: 0x18 | Size: 0x4
	float DamageValue; // Offset: 0x1c | Size: 0x4
	int32_t Rank; // Offset: 0x20 | Size: 0x4
	char pad_0x24[0x4]; // Offset: 0x24 | Size: 0x4
};

// Object: ScriptStruct Solarland.SettlementParam_WeaponExp
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FSettlementParam_WeaponExp {
	// Fields
	struct ASolarPlayerState* PS; // Offset: 0x0 | Size: 0x8
	float UseTime; // Offset: 0x8 | Size: 0x4
	int32_t WeaponKillNum; // Offset: 0xc | Size: 0x4
	int32_t WeaponAssitNum; // Offset: 0x10 | Size: 0x4
	float ExpRatio; // Offset: 0x14 | Size: 0x4
	float EXPPunishRatio; // Offset: 0x18 | Size: 0x4
	char pad_0x1C[0x4]; // Offset: 0x1c | Size: 0x4
};

// Object: ScriptStruct Solarland.SettlementParam_CommonExp
// Inherited Bytes: 0x0 | Struct Size: 0x38
struct FSettlementParam_CommonExp {
	// Fields
	struct ASolarPlayerState* PS; // Offset: 0x0 | Size: 0x8
	int32_t KillNum; // Offset: 0x8 | Size: 0x4
	int32_t DownNum; // Offset: 0xc | Size: 0x4
	int32_t AssitNum; // Offset: 0x10 | Size: 0x4
	int32_t SaveNum; // Offset: 0x14 | Size: 0x4
	float LifeTime; // Offset: 0x18 | Size: 0x4
	float DamageValue; // Offset: 0x1c | Size: 0x4
	int32_t Rank; // Offset: 0x20 | Size: 0x4
	float EXPPunishRatio; // Offset: 0x24 | Size: 0x4
	float CoinPunishRatio; // Offset: 0x28 | Size: 0x4
	int32_t RankCorePunish; // Offset: 0x2c | Size: 0x4
	int32_t BaseExp; // Offset: 0x30 | Size: 0x4
	float ExpRatio; // Offset: 0x34 | Size: 0x4
};

// Object: ScriptStruct Solarland.ShootingTargetRing
// Inherited Bytes: 0x0 | Struct Size: 0x1c
struct FShootingTargetRing {
	// Fields
	float Radius; // Offset: 0x0 | Size: 0x4
	float Score; // Offset: 0x4 | Size: 0x4
	struct FLinearColor ColorHUD; // Offset: 0x8 | Size: 0x10
	struct FColor Color3D; // Offset: 0x18 | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarWeaponFireSocketData
// Inherited Bytes: 0x0 | Struct Size: 0x60
struct FSolarWeaponFireSocketData {
	// Fields
	struct TArray<struct FName> MultiBulletSocketNames; // Offset: 0x0 | Size: 0x10
	struct TArray<struct FName> MuzzleSocketNames; // Offset: 0x10 | Size: 0x10
	struct TArray<struct FName> AdsMuzzleSocketNames; // Offset: 0x20 | Size: 0x10
	struct TArray<struct FName> MuzzleBlockCheckSocketNames; // Offset: 0x30 | Size: 0x10
	struct TArray<struct FName> MultiCastShellSocketNames; // Offset: 0x40 | Size: 0x10
	struct TArray<struct FName> AdsMultiCastShellSocketNames; // Offset: 0x50 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarWeaponFireInputRespondConfig
// Inherited Bytes: 0x0 | Struct Size: 0xb
struct FSolarWeaponFireInputRespondConfig {
	// Fields
	char pad_0x0[0x1]; // Offset: 0x0 | Size: 0x1
	bool bAutoCloseScope; // Offset: 0x1 | Size: 0x1
	bool bShootAtPress; // Offset: 0x2 | Size: 0x1
	bool bShootAtPressAutoScope; // Offset: 0x3 | Size: 0x1
	bool bCanAutoShootWhilePress; // Offset: 0x4 | Size: 0x1
	bool bCanAutoShootWhilePressAutoScope; // Offset: 0x5 | Size: 0x1
	bool bCanShootWhileScoping; // Offset: 0x6 | Size: 0x1
	bool bCanShootWhileScopingAutoScope; // Offset: 0x7 | Size: 0x1
	bool bCanManuallyCanceled; // Offset: 0x8 | Size: 0x1
	bool bCanManuallyCanceledAutoScope; // Offset: 0x9 | Size: 0x1
	bool bOpenScopeWhileAutoFire; // Offset: 0xa | Size: 0x1
};

// Object: ScriptStruct Solarland.SolarWeaponCrosshairData
// Inherited Bytes: 0x0 | Struct Size: 0x38
struct FSolarWeaponCrosshairData {
	// Fields
	char HasReload; // Offset: 0x0 | Size: 0x1
	char HasForbid; // Offset: 0x1 | Size: 0x1
	char HasOverload; // Offset: 0x2 | Size: 0x1
	char HasChargeProgress; // Offset: 0x3 | Size: 0x1
	char HasFeedback; // Offset: 0x4 | Size: 0x1
	enum class EWeaponType WeaponType; // Offset: 0x5 | Size: 0x1
	bool bIsEnergyType; // Offset: 0x6 | Size: 0x1
	char pad_0x7[0x1]; // Offset: 0x7 | Size: 0x1
	struct UUserWidget* CrossHairWidget; // Offset: 0x8 | Size: 0x8
	struct UUserWidget* BulletContainerWidget; // Offset: 0x10 | Size: 0x8
	struct UUserWidget* WeaponRechamberWidget; // Offset: 0x18 | Size: 0x8
	struct FSolarNoAmmoAlertWidgetLayout AmmoAlertWidgetLayout; // Offset: 0x20 | Size: 0x18
};

// Object: ScriptStruct Solarland.SolarNoAmmoAlertWidgetLayout
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FSolarNoAmmoAlertWidgetLayout {
	// Fields
	bool bOverrideLayout; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	struct FVector2D Offset; // Offset: 0x4 | Size: 0x8
	float SpinAngle; // Offset: 0xc | Size: 0x4
	struct FVector2D Scale; // Offset: 0x10 | Size: 0x8
};

// Object: ScriptStruct Solarland.MoveSpeedReduceCurveConfig
// Inherited Bytes: 0x0 | Struct Size: 0xd8
struct FMoveSpeedReduceCurveConfig {
	// Fields
	struct FGameplayTagRequirements TagRequirements; // Offset: 0x0 | Size: 0x50
	struct FRuntimeFloatCurve MoveSpeedReduceCurveOnHoldingWeapon; // Offset: 0x50 | Size: 0x88
};

// Object: ScriptStruct Solarland.LaunchDeviceInfo
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FLaunchDeviceInfo {
	// Fields
	bool bIsUsing; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	struct FName LaunchPadLocSocketName; // Offset: 0x4 | Size: 0x8
	struct FName PrepareEffectLocSocketName; // Offset: 0xc | Size: 0x8
	char pad_0x14[0x4]; // Offset: 0x14 | Size: 0x4
	struct UParticleSystemComponent* AvailableDeviceEffect; // Offset: 0x18 | Size: 0x8
};

// Object: ScriptStruct Solarland.ReplicateEffectData
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FReplicateEffectData {
	// Fields
	struct FSoftObjectPath IconPath; // Offset: 0x0 | Size: 0x18
};

// Object: ScriptStruct Solarland.SolarAttributeModifier
// Inherited Bytes: 0x0 | Struct Size: 0xa0
struct FSolarAttributeModifier {
	// Fields
	enum class ESolarAttributeType SolarAttributeType; // Offset: 0x0 | Size: 0x1
	enum class ESolarAttributeDurationType AttributeDurationType; // Offset: 0x1 | Size: 0x1
	enum class ESolarAttributeValueSourceType AttributeDurationSourceType; // Offset: 0x2 | Size: 0x1
	char pad_0x3[0x1]; // Offset: 0x3 | Size: 0x1
	float AttributeModifyDuration; // Offset: 0x4 | Size: 0x4
	struct FString AttributeModifyDurationSourceKey; // Offset: 0x8 | Size: 0x10
	float AttributeModifyMinDistance; // Offset: 0x18 | Size: 0x4
	float AttributeModifyMaxDistance; // Offset: 0x1c | Size: 0x4
	struct UCurveFloat* AttributeDistanceScaleCurve; // Offset: 0x20 | Size: 0x8
	bool AttributeUseTargetValue; // Offset: 0x28 | Size: 0x1
	char pad_0x29[0x3]; // Offset: 0x29 | Size: 0x3
	float AttributeTargetValue; // Offset: 0x2c | Size: 0x4
	enum class ESolarAttributeValueSourceType AttributeChangeValueSourceType; // Offset: 0x30 | Size: 0x1
	char pad_0x31[0x3]; // Offset: 0x31 | Size: 0x3
	float AttributeChangeValue; // Offset: 0x34 | Size: 0x4
	float AttributeChangeValueForVehicle; // Offset: 0x38 | Size: 0x4
	char pad_0x3C[0x4]; // Offset: 0x3c | Size: 0x4
	struct FString AttributeChangeValueSourceKey; // Offset: 0x40 | Size: 0x10
	bool AttributeChangeValueIsMultiplier; // Offset: 0x50 | Size: 0x1
	char pad_0x51[0x7]; // Offset: 0x51 | Size: 0x7
	enum class ESolarAttributeValueSourceType AttributeChangeSpeedSourceType; // Offset: 0x58 | Size: 0x1
	char pad_0x59[0x7]; // Offset: 0x59 | Size: 0x7
	struct FString AttributeChangeSpeedSourceKey; // Offset: 0x60 | Size: 0x10
	float AttributeChangeSpeed; // Offset: 0x70 | Size: 0x4
	bool AttributeApplyChargingScale; // Offset: 0x74 | Size: 0x1
	char pad_0x75[0x3]; // Offset: 0x75 | Size: 0x3
	struct TArray<int32_t> AttributeExtraIntParam; // Offset: 0x78 | Size: 0x10
	struct TArray<float> AttributeExtraFloatParam; // Offset: 0x88 | Size: 0x10
	char pad_0x98[0x8]; // Offset: 0x98 | Size: 0x8
};

// Object: ScriptStruct Solarland.GameplayAbilityRepAnimMontageForMesh
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FGameplayAbilityRepAnimMontageForMesh {
	// Fields
	struct USkeletalMeshComponent* Mesh; // Offset: 0x0 | Size: 0x8
	struct FGameplayAbilityRepAnimMontage RepMontageInfo; // Offset: 0x8 | Size: 0x38
};

// Object: ScriptStruct Solarland.GameplayAbilityLocalAnimMontageForMesh
// Inherited Bytes: 0x0 | Struct Size: 0x38
struct FGameplayAbilityLocalAnimMontageForMesh {
	// Fields
	struct USkeletalMeshComponent* Mesh; // Offset: 0x0 | Size: 0x8
	struct FGameplayAbilityLocalAnimMontage LocalMontageInfo; // Offset: 0x8 | Size: 0x30
};

// Object: ScriptStruct Solarland.AchievementResult
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FAchievementResult {
	// Fields
	int32_t AchievementID; // Offset: 0x0 | Size: 0x4
	int32_t ProgressValue; // Offset: 0x4 | Size: 0x4
	bool IsUnlock; // Offset: 0x8 | Size: 0x1
	enum class EAchievementReportType AchievementReportType; // Offset: 0x9 | Size: 0x1
	char pad_0xA[0x2]; // Offset: 0xa | Size: 0x2
};

// Object: ScriptStruct Solarland.AchievementContext
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FAchievementContext {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
	struct FString TargetValueName; // Offset: 0x8 | Size: 0x10
	struct FString HandleFunctionName; // Offset: 0x18 | Size: 0x10
};

// Object: ScriptStruct Solarland.AchievementHandle
// Inherited Bytes: 0x8 | Struct Size: 0x40
struct FAchievementHandle : FTableRowBase {
	// Fields
	enum class EAchievementCondition ConditionType; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x7]; // Offset: 0x9 | Size: 0x7
	struct FString TargetValueName; // Offset: 0x10 | Size: 0x10
	struct FString HandleFunctionName; // Offset: 0x20 | Size: 0x10
	struct FString Desc; // Offset: 0x30 | Size: 0x10
};

// Object: ScriptStruct Solarland.WidgetOverrideParam
// Inherited Bytes: 0x0 | Struct Size: 0x140
struct FWidgetOverrideParam {
	// Fields
	enum class EWidgetOverrideParamType Type; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	struct FName ChildName; // Offset: 0x4 | Size: 0x8
	bool bEnableLocText; // Offset: 0xc | Size: 0x1
	char pad_0xD[0x3]; // Offset: 0xd | Size: 0x3
	struct FText Text; // Offset: 0x10 | Size: 0x18
	int32_t LocTextID; // Offset: 0x28 | Size: 0x4
	char pad_0x2C[0x4]; // Offset: 0x2c | Size: 0x4
	struct FSlateBrush Brush; // Offset: 0x30 | Size: 0xe0
	struct FString CustomParameter; // Offset: 0x110 | Size: 0x10
	struct FGameplayTag GameplayTag; // Offset: 0x120 | Size: 0x8
	struct TArray<struct FString> MetaData; // Offset: 0x128 | Size: 0x10
	char pad_0x138[0x8]; // Offset: 0x138 | Size: 0x8
};

// Object: ScriptStruct Solarland.AdvProgressChannelInfo
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FAdvProgressChannelInfo {
	// Fields
	enum class EProgressBoardChannelState State; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	float Percent; // Offset: 0x4 | Size: 0x4
	float TargetPercent; // Offset: 0x8 | Size: 0x4
	float Speed; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct Solarland.PlaygroundEffect
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FPlaygroundEffect {
	// Fields
	struct FSoftObjectPath ParticlePath; // Offset: 0x0 | Size: 0x18
	float SpawnDelay; // Offset: 0x18 | Size: 0x4
	char pad_0x1C[0x4]; // Offset: 0x1c | Size: 0x4
	struct UParticleSystemComponent* Handle; // Offset: 0x20 | Size: 0x8
};

// Object: ScriptStruct Solarland.AirdropParas
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FAirdropParas {
	// Fields
	struct ASolarTreasureBoxSpawner* SolarTreasureBoxSpawnerClass; // Offset: 0x0 | Size: 0x8
	int32_t OutcomeID; // Offset: 0x8 | Size: 0x4
	int32_t ChestID; // Offset: 0xc | Size: 0x4
	int32_t ChestSpawnID; // Offset: 0x10 | Size: 0x4
	struct FVector Scale; // Offset: 0x14 | Size: 0xc
};

// Object: ScriptStruct Solarland.RouteInfo
// Inherited Bytes: 0x0 | Struct Size: 0x34
struct FRouteInfo {
	// Fields
	struct FVector RouteStart; // Offset: 0x0 | Size: 0xc
	struct FVector RouteEnd; // Offset: 0xc | Size: 0xc
	float RouteLength; // Offset: 0x18 | Size: 0x4
	struct FVector RouteDirection; // Offset: 0x1c | Size: 0xc
	struct FVector AirdropLocation; // Offset: 0x28 | Size: 0xc
};

// Object: ScriptStruct Solarland.AirshipConfig
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FAirshipConfig {
	// Fields
	float MoveSpeed; // Offset: 0x0 | Size: 0x4
	float MoveSpeedAfterAirdrop; // Offset: 0x4 | Size: 0x4
	float RouteHeight; // Offset: 0x8 | Size: 0x4
	float RouteMinLength; // Offset: 0xc | Size: 0x4
	float StartDistToAirdropMinLength; // Offset: 0x10 | Size: 0x4
	float FurthestDistAfterAirdrop; // Offset: 0x14 | Size: 0x4
	float DecelerateDistance; // Offset: 0x18 | Size: 0x4
	float AccelerateDistance; // Offset: 0x1c | Size: 0x4
	float HoveringDurance; // Offset: 0x20 | Size: 0x4
	float BestDegreeRange; // Offset: 0x24 | Size: 0x4
	struct UCurveFloat* FogDensityCurve; // Offset: 0x28 | Size: 0x8
};

// Object: ScriptStruct Solarland.AIQueryTeammateEvent
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FAIQueryTeammateEvent {
	// Fields
	struct UAIPerceptionComponent* QueryingTeammate; // Offset: 0x0 | Size: 0x8
	struct UAIPerceptionComponent* TeammateBeingQueried; // Offset: 0x8 | Size: 0x8
	struct AActor* Target; // Offset: 0x10 | Size: 0x8
	char pad_0x18[0x18]; // Offset: 0x18 | Size: 0x18
};

// Object: ScriptStruct Solarland.RadarDetectConfig
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FRadarDetectConfig {
	// Fields
	struct AActor* DetectActorType; // Offset: 0x0 | Size: 0x8
	float DetectRadius; // Offset: 0x8 | Size: 0x4
	float LossRadius; // Offset: 0xc | Size: 0x4
	float ScanInterval; // Offset: 0x10 | Size: 0x4
	char pad_0x14[0x4]; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarAITagStateTransition
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FSolarAITagStateTransition {
	// Fields
	struct FGameplayTag FromStateTag; // Offset: 0x0 | Size: 0x8
	struct FGameplayTag ToStateTag; // Offset: 0x8 | Size: 0x8
	struct TArray<struct USolarAICondition*> TransConditions; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarAIValueCompare
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FSolarAIValueCompare {
	// Fields
	enum class ESolarAIValueCompareOp Operator; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	float ComparedValue; // Offset: 0x4 | Size: 0x4
	float EqualThreshold; // Offset: 0x8 | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarAudioDetail
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FSolarAudioDetail {
	// Fields
	struct FName BankName; // Offset: 0x0 | Size: 0x8
	struct FName BindScene; // Offset: 0x8 | Size: 0x8
	enum class ESolarAudioDetailLoadMode LoadStrategy; // Offset: 0x10 | Size: 0x1
	enum class ESolarAudioDetailUnloadMode UnloadStrategy; // Offset: 0x11 | Size: 0x1
	enum class ESolarAudioDetailCatalog ResCatalog; // Offset: 0x12 | Size: 0x1
	bool LoadInQueue; // Offset: 0x13 | Size: 0x1
	int32_t OwnerCharacterID; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarAkBankInfo
// Inherited Bytes: 0x0 | Struct Size: 0x58
struct FSolarAkBankInfo {
	// Fields
	char pad_0x0[0x58]; // Offset: 0x0 | Size: 0x58
};

// Object: ScriptStruct Solarland.AkEventLocation
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FAkEventLocation {
	// Fields
	char pad_0x0[0x40]; // Offset: 0x0 | Size: 0x40
};

// Object: ScriptStruct Solarland.AkEventData
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FAkEventData {
	// Fields
	char pad_0x0[0x18]; // Offset: 0x0 | Size: 0x18
};

// Object: ScriptStruct Solarland.AnimBlendPointInfo
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FAnimBlendPointInfo {
	// Fields
	struct FVector2D GridLocation; // Offset: 0x0 | Size: 0x8
	struct TArray<enum class EAnimBlendDirection> AnimBlendArray; // Offset: 0x8 | Size: 0x10
	char pad_0x18[0x18]; // Offset: 0x18 | Size: 0x18
};

// Object: ScriptStruct Solarland.JetPackPoseSpeedRange
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FJetPackPoseSpeedRange {
	// Fields
	float Min; // Offset: 0x0 | Size: 0x4
	float Max; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct Solarland.LeftHandGripConfig
// Inherited Bytes: 0x0 | Struct Size: 0x84
struct FLeftHandGripConfig {
	// Fields
	struct FRotator HandL; // Offset: 0x0 | Size: 0xc
	struct FRotator Thumbl01; // Offset: 0xc | Size: 0xc
	struct FRotator Thumbl02; // Offset: 0x18 | Size: 0xc
	struct FRotator Index01; // Offset: 0x24 | Size: 0xc
	struct FRotator Index02; // Offset: 0x30 | Size: 0xc
	struct FRotator Middle01; // Offset: 0x3c | Size: 0xc
	struct FRotator Middle02; // Offset: 0x48 | Size: 0xc
	struct FRotator Ring01; // Offset: 0x54 | Size: 0xc
	struct FRotator Ring02; // Offset: 0x60 | Size: 0xc
	struct FRotator Pinky01; // Offset: 0x6c | Size: 0xc
	struct FRotator Pinky02; // Offset: 0x78 | Size: 0xc
};

// Object: ScriptStruct Solarland.MeerkatConfig
// Inherited Bytes: 0x0 | Struct Size: 0x14
struct FMeerkatConfig {
	// Fields
	int32_t ID; // Offset: 0x0 | Size: 0x4
	float Min; // Offset: 0x4 | Size: 0x4
	float Max; // Offset: 0x8 | Size: 0x4
	int32_t Tolerance; // Offset: 0xc | Size: 0x4
	int32_t ProbeInterval; // Offset: 0x10 | Size: 0x4
};

// Object: ScriptStruct Solarland.PreloadBundle
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FPreloadBundle {
	// Fields
	struct FName FolderPath; // Offset: 0x0 | Size: 0x8
	struct FName ClassName; // Offset: 0x8 | Size: 0x8
};

// Object: ScriptStruct Solarland.SolarAttributeConfig
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FSolarAttributeConfig {
	// Fields
	float MinValue; // Offset: 0x0 | Size: 0x4
	float MaxValue; // Offset: 0x4 | Size: 0x4
	float BaseValue; // Offset: 0x8 | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarAttributeSubReplicateData
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FSolarAttributeSubReplicateData {
	// Fields
	int32_t AttributeID; // Offset: 0x0 | Size: 0x4
	float AttributeValue; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarAttributeSubModifierData
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FSolarAttributeSubModifierData {
	// Fields
	enum class EGameplayModOp ModifierOp; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	float Magnitude; // Offset: 0x4 | Size: 0x4
	bool bIsEnabled; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x3]; // Offset: 0x9 | Size: 0x3
	int32_t ModifierID; // Offset: 0xc | Size: 0x4
	struct FName ModifierName; // Offset: 0x10 | Size: 0x8
};

// Object: ScriptStruct Solarland.AutoNavLinkSetting
// Inherited Bytes: 0x0 | Struct Size: 0x3c
struct FAutoNavLinkSetting {
	// Fields
	float TraceLength; // Offset: 0x0 | Size: 0x4
	float MaxHeight; // Offset: 0x4 | Size: 0x4
	float MinDistSquard; // Offset: 0x8 | Size: 0x4
	float TestAgentHalfHeight; // Offset: 0xc | Size: 0x4
	float TestAgentRadius; // Offset: 0x10 | Size: 0x4
	float AgentPassSphereRadius; // Offset: 0x14 | Size: 0x4
	float MinPassWidth; // Offset: 0x18 | Size: 0x4
	float MaxStepHeight; // Offset: 0x1c | Size: 0x4
	struct FVector FinalSnapExtent; // Offset: 0x20 | Size: 0xc
	float ProjectNavigationError; // Offset: 0x2c | Size: 0x4
	float VaultDetectDistance; // Offset: 0x30 | Size: 0x4
	float VaultDetectDeltaDistance; // Offset: 0x34 | Size: 0x4
	float VerticalError; // Offset: 0x38 | Size: 0x4
};

// Object: ScriptStruct Solarland.BackpackTrailAssemblingParams
// Inherited Bytes: 0x8 | Struct Size: 0xa8
struct FBackpackTrailAssemblingParams : FTableRowBase {
	// Fields
	struct TSoftObjectPtr<UParticleSystem> TrailParticle; // Offset: 0x8 | Size: 0x28
	struct TSoftObjectPtr<UParticleSystem> WallRunTrailParticle; // Offset: 0x30 | Size: 0x28
	struct TSoftObjectPtr<UParticleSystem> OffgasParticle; // Offset: 0x58 | Size: 0x28
	struct TSoftObjectPtr<UParticleSystem> WallRunOffgasParticle; // Offset: 0x80 | Size: 0x28
};

// Object: ScriptStruct Solarland.BackpackFXDataDTRow
// Inherited Bytes: 0x8 | Struct Size: 0x58
struct FBackpackFXDataDTRow : FTableRowBase {
	// Fields
	struct TMap<struct FName, struct FSoftObjectPath> FXPathMap; // Offset: 0x8 | Size: 0x50
};

// Object: ScriptStruct Solarland.BotResponseSetting
// Inherited Bytes: 0x0 | Struct Size: 0x14
struct FBotResponseSetting {
	// Fields
	float PersonalCD; // Offset: 0x0 | Size: 0x4
	float TeamCD; // Offset: 0x4 | Size: 0x4
	float MinTimeDelay; // Offset: 0x8 | Size: 0x4
	float MaxTimeDelay; // Offset: 0xc | Size: 0x4
	float TriggeredProbability; // Offset: 0x10 | Size: 0x4
};

// Object: ScriptStruct Solarland.BotEmojiSetting
// Inherited Bytes: 0x0 | Struct Size: 0x88
struct FBotEmojiSetting {
	// Fields
	struct TMap<int32_t, float> EmojiPool; // Offset: 0x0 | Size: 0x50
	struct FGameplayTagContainer TagsRequested; // Offset: 0x50 | Size: 0x20
	float PersonalCD; // Offset: 0x70 | Size: 0x4
	float TeamCD; // Offset: 0x74 | Size: 0x4
	float MinTimeDelay; // Offset: 0x78 | Size: 0x4
	float MaxTimeDelay; // Offset: 0x7c | Size: 0x4
	float TriggeredProbability; // Offset: 0x80 | Size: 0x4
	char pad_0x84[0x4]; // Offset: 0x84 | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarBotTeamInfo
// Inherited Bytes: 0x0 | Struct Size: 0xd0
struct FSolarBotTeamInfo {
	// Fields
	bool bIsActive; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	int32_t TeamID; // Offset: 0x4 | Size: 0x4
	struct FVector TeamPosition; // Offset: 0x8 | Size: 0xc
	float SeparateDistance; // Offset: 0x14 | Size: 0x4
	float ReturnDistance; // Offset: 0x18 | Size: 0x4
	bool bPlayerNeedPraise; // Offset: 0x1c | Size: 0x1
	bool bHasInitByTeamConfig; // Offset: 0x1d | Size: 0x1
	char pad_0x1E[0x2]; // Offset: 0x1e | Size: 0x2
	struct TArray<struct FSolarBotMemberInfo> MemberInfos; // Offset: 0x20 | Size: 0x10
	struct TMap<enum class EBotInteractCondition, float> TeamEmojiTimeStamp; // Offset: 0x30 | Size: 0x50
	struct TMap<enum class EBotInteractCondition, float> TeamResponseTimeStamp; // Offset: 0x80 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarBotMemberInfo
// Inherited Bytes: 0x0 | Struct Size: 0xb0
struct FSolarBotMemberInfo {
	// Fields
	struct TWeakObjectPtr<struct ASolarBotAIController> BotController; // Offset: 0x0 | Size: 0x8
	enum class ESolarBotMemberState MemberState; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x7]; // Offset: 0x9 | Size: 0x7
	struct TMap<enum class EBotInteractCondition, float> MemberEmojiTimeStamp; // Offset: 0x10 | Size: 0x50
	struct TMap<enum class EBotInteractCondition, float> MemberResponseTimeStamp; // Offset: 0x60 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarFuncBotSpawnParam
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FSolarFuncBotSpawnParam {
	// Fields
	struct ASolarFuncBotController* CtrlSubClass; // Offset: 0x0 | Size: 0x8
	struct ASolarCharacter* CharacterSubClass; // Offset: 0x8 | Size: 0x8
	int32_t CharacterId; // Offset: 0x10 | Size: 0x4
	int32_t SkinId; // Offset: 0x14 | Size: 0x4
	struct USolarBotAIConfig* ConfigPreset; // Offset: 0x18 | Size: 0x8
	struct FTransform SpawnTrans; // Offset: 0x20 | Size: 0x30
};

// Object: ScriptStruct Solarland.BotFocusInfo
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FBotFocusInfo {
	// Fields
	char pad_0x0[0x18]; // Offset: 0x0 | Size: 0x18
};

// Object: ScriptStruct Solarland.FeedBotStrategyInfo
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FFeedBotStrategyInfo {
	// Fields
	struct FString PlayerId; // Offset: 0x0 | Size: 0x10
	float FeedPriority; // Offset: 0x10 | Size: 0x4
	float Difficulty; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct Solarland.PopTask
// Inherited Bytes: 0x0 | Struct Size: 0x60
struct FPopTask {
	// Fields
	struct TArray<struct ASolarPlayerState*> WarmBots; // Offset: 0x0 | Size: 0x10
	struct UEnvQuery* SeparateLocEQS; // Offset: 0x10 | Size: 0x8
	enum class EEnvQueryRunMode SeparateLocEQSRunMode; // Offset: 0x18 | Size: 0x1
	char pad_0x19[0x7]; // Offset: 0x19 | Size: 0x7
	struct FPopParameter PreSetting; // Offset: 0x20 | Size: 0x40
};

// Object: ScriptStruct Solarland.PopParameter
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FPopParameter {
	// Fields
	struct TArray<struct ASolarPlayerState*> WarmTargets; // Offset: 0x0 | Size: 0x10
	struct FVector PopLocation; // Offset: 0x10 | Size: 0xc
	char pad_0x1C[0x4]; // Offset: 0x1c | Size: 0x4
	struct TArray<struct FTraceRecord> TargetTraces; // Offset: 0x20 | Size: 0x10
	struct UEnvQuery* TeleportLocEQS; // Offset: 0x30 | Size: 0x8
	enum class EEnvQueryRunMode TeleportLocEQSRunMode; // Offset: 0x38 | Size: 0x1
	bool bPopVehicle; // Offset: 0x39 | Size: 0x1
	bool bForcePop; // Offset: 0x3a | Size: 0x1
	char pad_0x3B[0x5]; // Offset: 0x3b | Size: 0x5
};

// Object: ScriptStruct Solarland.TraceRecord
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FTraceRecord {
	// Fields
	struct TArray<struct FVector> TargetTrace; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarWeaponPartBonusDropSetting
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FSolarWeaponPartBonusDropSetting {
	// Fields
	struct TMap<enum class EWeaponPartType, float> PriorityMap; // Offset: 0x0 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarItemProgressionBaseline
// Inherited Bytes: 0x8 | Struct Size: 0xc0
struct FSolarItemProgressionBaseline : FTableRowBase {
	// Fields
	float KeyTime; // Offset: 0x8 | Size: 0x4
	char pad_0xC[0x4]; // Offset: 0xc | Size: 0x4
	struct TMap<enum class ESpecialItemID, struct FRangeInteger> ConsumeableItemCountSetting; // Offset: 0x10 | Size: 0x50
	struct FRangeInteger PlayerLevel; // Offset: 0x60 | Size: 0x8
	struct FRangeInteger ShieldLevel; // Offset: 0x68 | Size: 0x8
	struct TMap<int32_t, struct FRangeInteger> WeaponPartsLevel; // Offset: 0x70 | Size: 0x50
};

// Object: ScriptStruct Solarland.RangeInteger
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FRangeInteger {
	// Fields
	int32_t Min; // Offset: 0x0 | Size: 0x4
	int32_t Max; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarBotTimelineGameSetting
// Inherited Bytes: 0x8 | Struct Size: 0x88
struct FSolarBotTimelineGameSetting : FTableRowBase {
	// Fields
	enum class ESolarBotWarmSystemType WarmSystemType; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x3]; // Offset: 0x9 | Size: 0x3
	int32_t MaxiumTeam; // Offset: 0xc | Size: 0x4
	struct FString Comment; // Offset: 0x10 | Size: 0x10
	struct UDataTable* Action; // Offset: 0x20 | Size: 0x8
	struct UDataTable* Item; // Offset: 0x28 | Size: 0x8
	struct UDataTable* Downsize; // Offset: 0x30 | Size: 0x8
	struct TMap<struct UDataTable*, float> ItemProgressionWeightMap; // Offset: 0x38 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarBotTimelineDownsizingTrigger
// Inherited Bytes: 0x8 | Struct Size: 0x18
struct FSolarBotTimelineDownsizingTrigger : FTableRowBase {
	// Fields
	int32_t StartTime; // Offset: 0x8 | Size: 0x4
	int32_t EndTime; // Offset: 0xc | Size: 0x4
	int32_t Min; // Offset: 0x10 | Size: 0x4
	int32_t Max; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarBotTimelineUpdateItemTrigger
// Inherited Bytes: 0x8 | Struct Size: 0x100
struct FSolarBotTimelineUpdateItemTrigger : FTableRowBase {
	// Fields
	int32_t StartTime; // Offset: 0x8 | Size: 0x4
	char pad_0xC[0x4]; // Offset: 0xc | Size: 0x4
	struct FSolarBotTimelineAIItemSetting AIItemSetting; // Offset: 0x10 | Size: 0xf0
};

// Object: ScriptStruct Solarland.SolarBotTimelineAIItemSetting
// Inherited Bytes: 0x0 | Struct Size: 0xf0
struct FSolarBotTimelineAIItemSetting {
	// Fields
	struct TMap<enum class ESolarBotTimelineEquipmentSettingType, struct FSolarBotTimelineEquipmentArray> Equipment; // Offset: 0x0 | Size: 0x50
	struct TMap<int32_t, struct FIntPoint> Consumable; // Offset: 0x50 | Size: 0x50
	struct TMap<enum class ESolarBotTimelineWeaponPartType, struct FSolarBotTimelineEquipmentArray> WeaponPart; // Offset: 0xa0 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarBotTimelineEquipmentArray
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FSolarBotTimelineEquipmentArray {
	// Fields
	struct TMap<int32_t, int32_t> IDArray; // Offset: 0x0 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarBotTimelineTrigger
// Inherited Bytes: 0x8 | Struct Size: 0x50
struct FSolarBotTimelineTrigger : FTableRowBase {
	// Fields
	enum class ESolarBotTimelineTriggerType TriggerType; // Offset: 0x8 | Size: 0x1
	char instanceID; // Offset: 0x9 | Size: 0x1
	char pad_0xA[0x2]; // Offset: 0xa | Size: 0x2
	float AbsoluteTriggerTime; // Offset: 0xc | Size: 0x4
	float RelativeTriggerTime; // Offset: 0x10 | Size: 0x4
	int32_t MinNumSurvivalBots; // Offset: 0x14 | Size: 0x4
	float ForceStartTime; // Offset: 0x18 | Size: 0x4
	float ForceEndTime; // Offset: 0x1c | Size: 0x4
	struct FSolarBotTimelineFilter Filter; // Offset: 0x20 | Size: 0x10
	int32_t MaxNumRetry; // Offset: 0x30 | Size: 0x4
	float IntervalRetry; // Offset: 0x34 | Size: 0x4
	struct TArray<struct FSolarBotTimelineWave> Waves; // Offset: 0x38 | Size: 0x10
	char pad_0x48[0x8]; // Offset: 0x48 | Size: 0x8
};

// Object: ScriptStruct Solarland.SolarBotTimelineWave
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FSolarBotTimelineWave {
	// Fields
	struct TArray<struct FSolarBotTimelineAIGroupSetting> AIGroupSetting; // Offset: 0x0 | Size: 0x10
	enum class EPopLocationType PopLocationType; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x3]; // Offset: 0x11 | Size: 0x3
	int32_t Timeout; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarBotTimelineAIGroupSetting
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FSolarBotTimelineAIGroupSetting {
	// Fields
	struct TArray<struct FSolarBotAISetting> Group; // Offset: 0x0 | Size: 0x10
	bool bGetBestChoice; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x7]; // Offset: 0x11 | Size: 0x7
};

// Object: ScriptStruct Solarland.SolarBotAISetting
// Inherited Bytes: 0x0 | Struct Size: 0x170
struct FSolarBotAISetting {
	// Fields
	struct USolarBotAIConfig* BotConfigPreset; // Offset: 0x0 | Size: 0x8
	struct FSolarBotTimelineVehicleSetting VehicleInfo; // Offset: 0x8 | Size: 0x18
	int32_t CharacterId; // Offset: 0x20 | Size: 0x4
	int32_t SkinId; // Offset: 0x24 | Size: 0x4
	struct TMap<enum class ESolarBotTimelineAIDataSettingType, struct FIntPoint> AIDataSetting; // Offset: 0x28 | Size: 0x50
	struct FSolarBotTimelineAIItemSetting AIItemSetting; // Offset: 0x78 | Size: 0xf0
	bool bSetWarmTarget; // Offset: 0x168 | Size: 0x1
	char pad_0x169[0x7]; // Offset: 0x169 | Size: 0x7
};

// Object: ScriptStruct Solarland.SolarBotTimelineVehicleSetting
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FSolarBotTimelineVehicleSetting {
	// Fields
	bool bHasVehicle; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x7]; // Offset: 0x1 | Size: 0x7
	struct TArray<int32_t> VehicleIDs; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarBotTimelineFilter
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FSolarBotTimelineFilter {
	// Fields
	struct TArray<struct FSolarBotTimelineFilterGroup> FilterGroup; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarBotTimelineFilterGroup
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FSolarBotTimelineFilterGroup {
	// Fields
	struct TArray<struct FSolarBotTimelineFilterItem> FilterItem; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarBotTimelineFilterItem
// Inherited Bytes: 0x0 | Struct Size: 0x58
struct FSolarBotTimelineFilterItem {
	// Fields
	enum class ESolarBotTimelineFilterType Type; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x7]; // Offset: 0x1 | Size: 0x7
	struct TMap<enum class ESolarBotTimelineFilterParameterType, struct FString> Parameter; // Offset: 0x8 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarBotWavePopSetting
// Inherited Bytes: 0x0 | Struct Size: 0x2
struct FSolarBotWavePopSetting {
	// Fields
	enum class EPopLocationType PopLocationType; // Offset: 0x0 | Size: 0x1
	bool bUsingWarmTargetForward; // Offset: 0x1 | Size: 0x1
};

// Object: ScriptStruct Solarland.SolarBotTimelineTeleCenterSetting
// Inherited Bytes: 0x0 | Struct Size: 0x14
struct FSolarBotTimelineTeleCenterSetting {
	// Fields
	bool SetTeleCenter; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	struct FIntPoint TeleportRadius; // Offset: 0x4 | Size: 0x8
	struct FIntPoint TeleportAngle; // Offset: 0xc | Size: 0x8
};

// Object: ScriptStruct Solarland.SolarBotUseSniperPosConfig
// Inherited Bytes: 0x0 | Struct Size: 0x1c
struct FSolarBotUseSniperPosConfig {
	// Fields
	int32_t MinNumSpawnerHasSearched; // Offset: 0x0 | Size: 0x4
	float MinElapsedReachedZone; // Offset: 0x4 | Size: 0x4
	float MinEnemyDistance; // Offset: 0x8 | Size: 0x4
	int32_t MinNumBeHitAbandonPos; // Offset: 0xc | Size: 0x4
	int32_t MaxDurationOccupyPos; // Offset: 0x10 | Size: 0x4
	float MaxDurationReachedPos; // Offset: 0x14 | Size: 0x4
	float IntervalUseNextPos; // Offset: 0x18 | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarBotBattleConfig
// Inherited Bytes: 0x0 | Struct Size: 0x158
struct FSolarBotBattleConfig {
	// Fields
	struct FBotFireConfig DefaultFireConfig; // Offset: 0x0 | Size: 0x10
	struct FBotFireConfig FireConfigToBot; // Offset: 0x10 | Size: 0x10
	struct TMap<enum class EWeaponType, struct FBotFireConfig> WeaponFireConfigs; // Offset: 0x20 | Size: 0x50
	struct TMap<enum class EWeaponType, struct FBotFireConfig> WeaponFireConfigsToBot; // Offset: 0x70 | Size: 0x50
	struct FBotFireConfig VehicleFireConfig; // Offset: 0xc0 | Size: 0x10
	struct FBotFireConfig VehicleFireConfigToBot; // Offset: 0xd0 | Size: 0x10
	bool bPreventFatalDamageToPlayer; // Offset: 0xe0 | Size: 0x1
	char pad_0xE1[0x3]; // Offset: 0xe1 | Size: 0x3
	float DamageFactorToVehicle; // Offset: 0xe4 | Size: 0x4
	float DamageFactorToBotVehicle; // Offset: 0xe8 | Size: 0x4
	float DamageFactorToSummonItem; // Offset: 0xec | Size: 0x4
	float DamageFactorToBotSummonItem; // Offset: 0xf0 | Size: 0x4
	float BotAIAttackRange; // Offset: 0xf4 | Size: 0x4
	float BotAIAttackRangeUnArm; // Offset: 0xf8 | Size: 0x4
	bool bEnableShootSimulator; // Offset: 0xfc | Size: 0x1
	char pad_0xFD[0x3]; // Offset: 0xfd | Size: 0x3
	struct FSolarBotShootConfig DefaultShootConfig; // Offset: 0x100 | Size: 0x58
};

// Object: ScriptStruct Solarland.SolarBotShootConfig
// Inherited Bytes: 0x0 | Struct Size: 0x58
struct FSolarBotShootConfig {
	// Fields
	enum class EBotFirePolicy FirePolicy; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	float FollowInterpSpeed; // Offset: 0x4 | Size: 0x4
	float AntiHorizRecoilStrenghth; // Offset: 0x8 | Size: 0x4
	float AntiVertRecoilStrenghth; // Offset: 0xc | Size: 0x4
	float LockHeightOffset; // Offset: 0x10 | Size: 0x4
	float AimInterpSpeed; // Offset: 0x14 | Size: 0x4
	float MaxFollowDeltaAngle; // Offset: 0x18 | Size: 0x4
	float MaxPreciseMoveAngle; // Offset: 0x1c | Size: 0x4
	float RoughMoveMaxAngle; // Offset: 0x20 | Size: 0x4
	float FollowMoveSpeed; // Offset: 0x24 | Size: 0x4
	float PreciseMoveSpeed; // Offset: 0x28 | Size: 0x4
	float RoughMoveSpeed; // Offset: 0x2c | Size: 0x4
	float LockMoveSpeed; // Offset: 0x30 | Size: 0x4
	float PreciseMoveDeviationYaw; // Offset: 0x34 | Size: 0x4
	float PreciseMoveDeviationPitch; // Offset: 0x38 | Size: 0x4
	float RoughMoveDeviationYaw; // Offset: 0x3c | Size: 0x4
	float RoughMoveDeviationPitch; // Offset: 0x40 | Size: 0x4
	float LockMoveMaxDeltaYaw; // Offset: 0x44 | Size: 0x4
	float LockMoveMaxDeltaPitch; // Offset: 0x48 | Size: 0x4
	float RoughMoveReactionTime; // Offset: 0x4c | Size: 0x4
	float PreciseMoveReactionTime; // Offset: 0x50 | Size: 0x4
	float MaxFollowUnreachTime; // Offset: 0x54 | Size: 0x4
};

// Object: ScriptStruct Solarland.BotFireConfig
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FBotFireConfig {
	// Fields
	float ShootDisperse; // Offset: 0x0 | Size: 0x4
	float HitRate; // Offset: 0x4 | Size: 0x4
	float ActiveDamageRate; // Offset: 0x8 | Size: 0x4
	float ActiveDamageFactor; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarBotBattleConfigNew
// Inherited Bytes: 0x0 | Struct Size: 0xd8
struct FSolarBotBattleConfigNew {
	// Fields
	struct FBotFireConfig DefaultFireConfig; // Offset: 0x0 | Size: 0x10
	struct TArray<struct FBotSpecifiedFireConfig> SpecifiedFireConfigs; // Offset: 0x10 | Size: 0x10
	float DefaultFireLockRadius; // Offset: 0x20 | Size: 0x4
	char pad_0x24[0x4]; // Offset: 0x24 | Size: 0x4
	struct TMap<enum class EBotShotTargetType, struct FRangeFloat> ShotLockRadiusMap; // Offset: 0x28 | Size: 0x50
	bool bPreventFatalDamageToPlayer; // Offset: 0x78 | Size: 0x1
	bool bEnableShootSimulator; // Offset: 0x79 | Size: 0x1
	char pad_0x7A[0x2]; // Offset: 0x7a | Size: 0x2
	struct FSolarBotShootConfig DefaultShootConfig; // Offset: 0x7c | Size: 0x58
	char pad_0xD4[0x4]; // Offset: 0xd4 | Size: 0x4
};

// Object: ScriptStruct Solarland.RangeFloat
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FRangeFloat {
	// Fields
	float Min; // Offset: 0x0 | Size: 0x4
	float Max; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct Solarland.BotSpecifiedFireConfig
// Inherited Bytes: 0x0 | Struct Size: 0x14
struct FBotSpecifiedFireConfig {
	// Fields
	enum class EWeaponType UsedWeaponType; // Offset: 0x0 | Size: 0x1
	enum class EBotShotTargetCtlType TargetCtlType; // Offset: 0x1 | Size: 0x1
	enum class EBotShotTargetType TargetType; // Offset: 0x2 | Size: 0x1
	char pad_0x3[0x1]; // Offset: 0x3 | Size: 0x1
	struct FBotFireConfig FireConfig; // Offset: 0x4 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarBotLootSearchConfig
// Inherited Bytes: 0x0 | Struct Size: 0x44
struct FSolarBotLootSearchConfig {
	// Fields
	float HPRatioToUseMedicine; // Offset: 0x0 | Size: 0x4
	float ShieldRatioToRecharge; // Offset: 0x4 | Size: 0x4
	float MaxSearchRangeNearbyPlayer; // Offset: 0x8 | Size: 0x4
	float MinSearchRangeNearbyPlayer; // Offset: 0xc | Size: 0x4
	float RadiusTolerance; // Offset: 0x10 | Size: 0x4
	struct FVector2D NearbyEnemyOuterFactorRange; // Offset: 0x14 | Size: 0x8
	struct FVector2D NearbyEnemyInnerFactorRange; // Offset: 0x1c | Size: 0x8
	struct FVector2D NearbyEnemyCountRange; // Offset: 0x24 | Size: 0x8
	struct FVector2D NearbySpawnerOuterFactorRange; // Offset: 0x2c | Size: 0x8
	struct FVector2D NearbySpawnerInnerFactorRange; // Offset: 0x34 | Size: 0x8
	struct FVector2D NearbySpawnerCountRange; // Offset: 0x3c | Size: 0x8
};

// Object: ScriptStruct Solarland.SolarBotLootWeaponFeedConfig
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FSolarBotLootWeaponFeedConfig {
	// Fields
	float MaxNoWeaponTime; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct TArray<int32_t> FeedWeaponIDs; // Offset: 0x8 | Size: 0x10
	float CheckPlayerSightInterval; // Offset: 0x18 | Size: 0x4
	bool bStartFeedAfterSearchedAnySpawner; // Offset: 0x1c | Size: 0x1
	char pad_0x1D[0x3]; // Offset: 0x1d | Size: 0x3
};

// Object: ScriptStruct Solarland.SolarBotLootValuationConfig
// Inherited Bytes: 0x0 | Struct Size: 0x44
struct FSolarBotLootValuationConfig {
	// Fields
	float MoveCostFactor; // Offset: 0x0 | Size: 0x4
	float DistSelfToSpawnerFactor; // Offset: 0x4 | Size: 0x4
	float DistSpawnerOffsetFactor; // Offset: 0x8 | Size: 0x4
	float AvgDistSpawnerToTeammatesFactor; // Offset: 0xc | Size: 0x4
	float AssualtRifleBaseValue; // Offset: 0x10 | Size: 0x4
	float ShotgunBaseValue; // Offset: 0x14 | Size: 0x4
	float SubmachinegunBaseValue; // Offset: 0x18 | Size: 0x4
	float SniperBaseValue; // Offset: 0x1c | Size: 0x4
	float WeaponQualityValue; // Offset: 0x20 | Size: 0x4
	float AmmoBaseValue; // Offset: 0x24 | Size: 0x4
	float AmmoMatchFactor; // Offset: 0x28 | Size: 0x4
	float ShieldBaseValue; // Offset: 0x2c | Size: 0x4
	float ShieldQualityValue; // Offset: 0x30 | Size: 0x4
	float JetpackModuleBaseValue; // Offset: 0x34 | Size: 0x4
	float JetpackModuleQualityValue; // Offset: 0x38 | Size: 0x4
	float MedkitBaseValue; // Offset: 0x3c | Size: 0x4
	float MedkitHPRatioFactor; // Offset: 0x40 | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarBotThreatConfig
// Inherited Bytes: 0x0 | Struct Size: 0x70
struct FSolarBotThreatConfig {
	// Fields
	float ThreatUpdateInterval; // Offset: 0x0 | Size: 0x4
	float AttackTriggerThreshold; // Offset: 0x4 | Size: 0x4
	float CancelAttackTriggerThreshold; // Offset: 0x8 | Size: 0x4
	float SwitchTargetDifferenceValue; // Offset: 0xc | Size: 0x4
	float DistanceThreshold; // Offset: 0x10 | Size: 0x4
	float DistanceThresholdInSmoke; // Offset: 0x14 | Size: 0x4
	float SightLoseRange; // Offset: 0x18 | Size: 0x4
	float PeripheralVisionAngleDegrees; // Offset: 0x1c | Size: 0x4
	float SightIncreaseBase; // Offset: 0x20 | Size: 0x4
	float SightIncreaseDistanceFactor; // Offset: 0x24 | Size: 0x4
	float SightDecreaseBase; // Offset: 0x28 | Size: 0x4
	float SightDecreaseDistanceFactor; // Offset: 0x2c | Size: 0x4
	float SightDecreaseMax; // Offset: 0x30 | Size: 0x4
	float SightMaxValue; // Offset: 0x34 | Size: 0x4
	float HearingAddBase; // Offset: 0x38 | Size: 0x4
	float HearingAddDistanceFactor; // Offset: 0x3c | Size: 0x4
	float HearingDecreasePerTick; // Offset: 0x40 | Size: 0x4
	float HearingMaxValue; // Offset: 0x44 | Size: 0x4
	float HitSoundAlertRange; // Offset: 0x48 | Size: 0x4
	float BotThreatFactor; // Offset: 0x4c | Size: 0x4
	float PlayerThreatFactor; // Offset: 0x50 | Size: 0x4
	float DeathVergeFactor; // Offset: 0x54 | Size: 0x4
	float MassInvisibilityPrepareFactor; // Offset: 0x58 | Size: 0x4
	float MaxDistanceThreatFactor; // Offset: 0x5c | Size: 0x4
	float DistanceThreatFactorDecayRate; // Offset: 0x60 | Size: 0x4
	float AccompanyThreatMaxValue; // Offset: 0x64 | Size: 0x4
	float AccompanyThreatAddBase; // Offset: 0x68 | Size: 0x4
	float AccompanyDecreasePerTick; // Offset: 0x6c | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarBotSafeAreaConfig
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FSolarBotSafeAreaConfig {
	// Fields
	float EstimateAdjustFactor; // Offset: 0x0 | Size: 0x4
	float SafeAreaRadiusEx; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarBotSkyDivingConfig
// Inherited Bytes: 0x0 | Struct Size: 0x24
struct FSolarBotSkyDivingConfig {
	// Fields
	float DecisionAltitude; // Offset: 0x0 | Size: 0x4
	float RandomLandingRadius; // Offset: 0x4 | Size: 0x4
	float RandomDelayCancelFollow; // Offset: 0x8 | Size: 0x4
	float FollowAcceptDistance; // Offset: 0xc | Size: 0x4
	float AbandonCheckAltitude; // Offset: 0x10 | Size: 0x4
	float CheckEnemyRange; // Offset: 0x14 | Size: 0x4
	int32_t CheckEnemyCount; // Offset: 0x18 | Size: 0x4
	float OuterRandomLandingRadius; // Offset: 0x1c | Size: 0x4
	float InnerRandomLandingRadius; // Offset: 0x20 | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarBotGameTeamSetting
// Inherited Bytes: 0x8 | Struct Size: 0x68
struct FSolarBotGameTeamSetting : FTableRowBase {
	// Fields
	struct TMap<struct USolarBotTeamConfig*, float> TeamConfigWeightMap; // Offset: 0x8 | Size: 0x50
	struct TArray<struct USolarBotAIConfig*> CandidateBotConfigs; // Offset: 0x58 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarBotTeamBuildRule
// Inherited Bytes: 0x0 | Struct Size: 0x68
struct FSolarBotTeamBuildRule {
	// Fields
	struct FString Description; // Offset: 0x0 | Size: 0x10
	bool bIsHeroPickTypeRule; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x7]; // Offset: 0x11 | Size: 0x7
	struct TMap<struct FGameplayTag, float> TagWeights; // Offset: 0x18 | Size: 0x50
};

// Object: ScriptStruct Solarland.WarmBotDebugInfo
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FWarmBotDebugInfo {
	// Fields
	struct TArray<struct FActiveBotDebugInfo> PoppedBots; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Solarland.ActiveBotDebugInfo
// Inherited Bytes: 0x0 | Struct Size: 0x70
struct FActiveBotDebugInfo {
	// Fields
	struct FString BotName; // Offset: 0x0 | Size: 0x10
	bool bTeleSuccess; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x3]; // Offset: 0x11 | Size: 0x3
	int32_t BotCharacterID; // Offset: 0x14 | Size: 0x4
	int32_t BotTeamID; // Offset: 0x18 | Size: 0x4
	char pad_0x1C[0x4]; // Offset: 0x1c | Size: 0x4
	struct FString BotConfigName; // Offset: 0x20 | Size: 0x10
	struct FVector BotLocation; // Offset: 0x30 | Size: 0xc
	struct FVector WarmTargetLocation; // Offset: 0x3c | Size: 0xc
	float DistanceToWarmTarget; // Offset: 0x48 | Size: 0x4
	struct FVector BotLocationOnTeleport; // Offset: 0x4c | Size: 0xc
	struct FVector WarmTargetLocationOnTeleport; // Offset: 0x58 | Size: 0xc
	float DistanceToWarmTargetOnTeleport; // Offset: 0x64 | Size: 0x4
	bool bIsAlive; // Offset: 0x68 | Size: 0x1
	char pad_0x69[0x7]; // Offset: 0x69 | Size: 0x7
};

// Object: ScriptStruct Solarland.BotTeamDebugInfo
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FBotTeamDebugInfo {
	// Fields
	int32_t TeamID; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct TArray<struct FBotMemberDebugInfo> MemberDebugInfos; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct Solarland.BotMemberDebugInfo
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FBotMemberDebugInfo {
	// Fields
	struct FVector MemberLocation; // Offset: 0x0 | Size: 0xc
	char pad_0xC[0x4]; // Offset: 0xc | Size: 0x4
	struct FString IDStr; // Offset: 0x10 | Size: 0x10
	enum class ESolarBotMemberState MemberState; // Offset: 0x20 | Size: 0x1
	char pad_0x21[0x7]; // Offset: 0x21 | Size: 0x7
};

// Object: ScriptStruct Solarland.TimeItemsSetting
// Inherited Bytes: 0x0 | Struct Size: 0xf8
struct FTimeItemsSetting {
	// Fields
	float TriggerTime; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct FSolarBotTimelineAIItemSetting Items; // Offset: 0x8 | Size: 0xf0
};

// Object: ScriptStruct Solarland.WarmTargetState
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FWarmTargetState {
	// Fields
	float BoringValue; // Offset: 0x0 | Size: 0x4
	int32_t ServedTimes; // Offset: 0x4 | Size: 0x4
	bool bNeedWarmService; // Offset: 0x8 | Size: 0x1
	char KillPlayerNum; // Offset: 0x9 | Size: 0x1
	char KillBotNum; // Offset: 0xa | Size: 0x1
	char pad_0xB[0x1]; // Offset: 0xb | Size: 0x1
	float LastBattleTime; // Offset: 0xc | Size: 0x4
	int32_t CurTraceRecordIdx; // Offset: 0x10 | Size: 0x4
	char pad_0x14[0x4]; // Offset: 0x14 | Size: 0x4
	struct TArray<struct FVector> TraceRecords; // Offset: 0x18 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarTaskScoringItem
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FSolarTaskScoringItem {
	// Fields
	struct TMap<enum class ESolarTaskScoringItemType, float> ScoringItemMap; // Offset: 0x0 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarScoringItemStruct
// Inherited Bytes: 0x0 | Struct Size: 0x14
struct FSolarScoringItemStruct {
	// Fields
	struct TWeakObjectPtr<struct ASolarBotAIController> BotController; // Offset: 0x0 | Size: 0x8
	struct TWeakObjectPtr<struct AActor> RelativeActor; // Offset: 0x8 | Size: 0x8
	float Score; // Offset: 0x10 | Size: 0x4
};

// Object: ScriptStruct Solarland.ByteBuffer
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FByteBuffer {
	// Fields
	char pad_0x0[0x28]; // Offset: 0x0 | Size: 0x28
};

// Object: ScriptStruct Solarland.CameraShakeInfo
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FCameraShakeInfo {
	// Fields
	struct FCameraShakeDuration Duration; // Offset: 0x0 | Size: 0x8
	float BlendIn; // Offset: 0x8 | Size: 0x4
	float BlendOut; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct Solarland.CameraShakeDuration
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FCameraShakeDuration {
	// Fields
	float Duration; // Offset: 0x0 | Size: 0x4
	enum class ECameraShakeDurationType Type; // Offset: 0x4 | Size: 0x1
	char pad_0x5[0x3]; // Offset: 0x5 | Size: 0x3
};

// Object: ScriptStruct Solarland.CameraShakeStopParams
// Inherited Bytes: 0x0 | Struct Size: 0x1
struct FCameraShakeStopParams {
	// Fields
	bool bImmediately; // Offset: 0x0 | Size: 0x1
};

// Object: ScriptStruct Solarland.CameraShakeUpdateResult
// Inherited Bytes: 0x0 | Struct Size: 0x5f0
struct FCameraShakeUpdateResult {
	// Fields
	char pad_0x0[0x5f0]; // Offset: 0x0 | Size: 0x5f0
};

// Object: ScriptStruct Solarland.CameraShakeScrubParams
// Inherited Bytes: 0x0 | Struct Size: 0x660
struct FCameraShakeScrubParams {
	// Fields
	float AbsoluteTime; // Offset: 0x0 | Size: 0x4
	float ShakeScale; // Offset: 0x4 | Size: 0x4
	float DynamicScale; // Offset: 0x8 | Size: 0x4
	float BlendingWeight; // Offset: 0xc | Size: 0x4
	struct FMinimalViewInfo POV; // Offset: 0x10 | Size: 0x650
};

// Object: ScriptStruct Solarland.CameraShakeUpdateParams
// Inherited Bytes: 0x0 | Struct Size: 0x660
struct FCameraShakeUpdateParams {
	// Fields
	float DeltaTime; // Offset: 0x0 | Size: 0x4
	float ShakeScale; // Offset: 0x4 | Size: 0x4
	float DynamicScale; // Offset: 0x8 | Size: 0x4
	float BlendingWeight; // Offset: 0xc | Size: 0x4
	struct FMinimalViewInfo POV; // Offset: 0x10 | Size: 0x650
};

// Object: ScriptStruct Solarland.CameraShakeStartParams
// Inherited Bytes: 0x0 | Struct Size: 0x1
struct FCameraShakeStartParams {
	// Fields
	bool bIsRestarting; // Offset: 0x0 | Size: 0x1
};

// Object: ScriptStruct Solarland.TeamFormationUnit
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FTeamFormationUnit {
	// Fields
	struct TMap<char, struct FEchelonFormationUnit> TeamFormation; // Offset: 0x0 | Size: 0x50
};

// Object: ScriptStruct Solarland.EchelonFormationUnit
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FEchelonFormationUnit {
	// Fields
	struct TArray<struct FBoardingSpotInfo> EchelonFormation; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Solarland.BoardingSpotInfo
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FBoardingSpotInfo {
	// Fields
	struct FVector SpotLocation; // Offset: 0x0 | Size: 0xc
	char pad_0xC[0x4]; // Offset: 0xc | Size: 0x4
	struct ASolarPlayerState* BoardingPlayer; // Offset: 0x10 | Size: 0x8
	struct ASolarPlayerState* LeaderPlayer; // Offset: 0x18 | Size: 0x8
};

// Object: ScriptStruct Solarland.UsingAirlineData
// Inherited Bytes: 0x0 | Struct Size: 0x44
struct FUsingAirlineData {
	// Fields
	int32_t MapID; // Offset: 0x0 | Size: 0x4
	struct FVector StartPoint; // Offset: 0x4 | Size: 0xc
	struct FVector EndPoint; // Offset: 0x10 | Size: 0xc
	struct FVector2D Direction; // Offset: 0x1c | Size: 0x8
	float Speed; // Offset: 0x24 | Size: 0x4
	float Height; // Offset: 0x28 | Size: 0x4
	struct FVector CanParachutePoint; // Offset: 0x2c | Size: 0xc
	struct FVector ForceParachutePoint; // Offset: 0x38 | Size: 0xc
};

// Object: ScriptStruct Solarland.BoarderInfo
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FBoarderInfo {
	// Fields
	struct ASolarCharacter* Boarder; // Offset: 0x0 | Size: 0x8
	int32_t BoarderTeamID; // Offset: 0x8 | Size: 0x4
	int32_t BoarderTeamSize; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct Solarland.HotFixAntiCheatData
// Inherited Bytes: 0x0 | Struct Size: 0x4
struct FHotFixAntiCheatData {
	// Fields
	float BulletSpread; // Offset: 0x0 | Size: 0x4
};

// Object: ScriptStruct Solarland.SoundEventRow
// Inherited Bytes: 0x8 | Struct Size: 0x30
struct FSoundEventRow : FTableRowBase {
	// Fields
	enum class ECharacterSoundOpt SoundOpt; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x7]; // Offset: 0x9 | Size: 0x7
	struct FString SoundName; // Offset: 0x10 | Size: 0x10
	struct FString EventName; // Offset: 0x20 | Size: 0x10
};

// Object: ScriptStruct Solarland.CharacterSound
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FCharacterSound {
	// Fields
	struct FString SoundOptPlayer; // Offset: 0x0 | Size: 0x10
	struct FString SoundOptTeammate; // Offset: 0x10 | Size: 0x10
	struct FString SoundOptEnemy; // Offset: 0x20 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarCharacterBillboardIconRuntimeInfo
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FSolarCharacterBillboardIconRuntimeInfo {
	// Fields
	char pad_0x0[0x18]; // Offset: 0x0 | Size: 0x18
	struct UStaticMeshComponent* Component; // Offset: 0x18 | Size: 0x8
	char pad_0x20[0x8]; // Offset: 0x20 | Size: 0x8
};

// Object: ScriptStruct Solarland.CamEffectSettings
// Inherited Bytes: 0x0 | Struct Size: 0x38
struct FCamEffectSettings {
	// Fields
	float FadeIn; // Offset: 0x0 | Size: 0x4
	float FadeOut; // Offset: 0x4 | Size: 0x4
	float Duration; // Offset: 0x8 | Size: 0x4
	bool bEnableOffset; // Offset: 0xc | Size: 0x1
	char pad_0xD[0x3]; // Offset: 0xd | Size: 0x3
	struct UCurveVector* OffsetCurve; // Offset: 0x10 | Size: 0x8
	bool bEnableRotation; // Offset: 0x18 | Size: 0x1
	char pad_0x19[0x7]; // Offset: 0x19 | Size: 0x7
	struct UCurveVector* RotationCurve; // Offset: 0x20 | Size: 0x8
	bool bEnableFOV; // Offset: 0x28 | Size: 0x1
	char pad_0x29[0x7]; // Offset: 0x29 | Size: 0x7
	struct UCurveFloat* FOVCurve; // Offset: 0x30 | Size: 0x8
};

// Object: ScriptStruct Solarland.CameraSettings
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FCameraSettings {
	// Fields
	float DistanceToTarget; // Offset: 0x0 | Size: 0x4
	float CameraFOV; // Offset: 0x4 | Size: 0x4
	struct FVector TargetOffset; // Offset: 0x8 | Size: 0xc
	struct FVector CameraOffset; // Offset: 0x14 | Size: 0xc
};

// Object: ScriptStruct Solarland.SolarTacticalSkillDamageEvent
// Inherited Bytes: 0x110 | Struct Size: 0x110
struct FSolarTacticalSkillDamageEvent : FSolarPointDamageEvent {
};

// Object: ScriptStruct Solarland.SolarClassSkillDamageEvent
// Inherited Bytes: 0x110 | Struct Size: 0x110
struct FSolarClassSkillDamageEvent : FSolarPointDamageEvent {
};

// Object: ScriptStruct Solarland.WeaponAbilityDamageEvent
// Inherited Bytes: 0x110 | Struct Size: 0x110
struct FWeaponAbilityDamageEvent : FSolarPointDamageEvent {
};

// Object: ScriptStruct Solarland.VehicleAbilityDamageEvent
// Inherited Bytes: 0x110 | Struct Size: 0x130
struct FVehicleAbilityDamageEvent : FSolarPointDamageEvent {
	// Fields
	struct FString AbilityName; // Offset: 0x110 | Size: 0x10
	struct FString AbilityTextType; // Offset: 0x120 | Size: 0x10
};

// Object: ScriptStruct Solarland.SummonWeaponDamageEvent
// Inherited Bytes: 0x110 | Struct Size: 0x118
struct FSummonWeaponDamageEvent : FSolarPointDamageEvent {
	// Fields
	struct TWeakObjectPtr<struct ASolarCharacter> SourceWeaponHolder; // Offset: 0x10c | Size: 0x8
};

// Object: ScriptStruct Solarland.SolarWeaponDamageEvent
// Inherited Bytes: 0x110 | Struct Size: 0x120
struct FSolarWeaponDamageEvent : FSolarPointDamageEvent {
	// Fields
	int32_t weaponid; // Offset: 0x10c | Size: 0x4
	int32_t WeaponSkinID; // Offset: 0x110 | Size: 0x4
	int32_t WeaponLv; // Offset: 0x114 | Size: 0x4
	int32_t ItemID; // Offset: 0x118 | Size: 0x4
};

// Object: ScriptStruct Solarland.VehicleWeaponDamageEvent
// Inherited Bytes: 0x120 | Struct Size: 0x120
struct FVehicleWeaponDamageEvent : FSolarWeaponDamageEvent {
	// Fields
	int32_t VehicleID; // Offset: 0x11c | Size: 0x4
};

// Object: ScriptStruct Solarland.UnarmWeaponDamageEvent
// Inherited Bytes: 0x110 | Struct Size: 0x110
struct FUnarmWeaponDamageEvent : FSolarPointDamageEvent {
};

// Object: ScriptStruct Solarland.VhicleExplosionDamageEvent
// Inherited Bytes: 0x110 | Struct Size: 0x110
struct FVhicleExplosionDamageEvent : FSolarPointDamageEvent {
	// Fields
	int32_t VehicleID; // Offset: 0x10c | Size: 0x4
};

// Object: ScriptStruct Solarland.VehicleHitDamageEvent
// Inherited Bytes: 0x110 | Struct Size: 0x110
struct FVehicleHitDamageEvent : FSolarPointDamageEvent {
	// Fields
	int32_t VehicleID; // Offset: 0x10c | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarSystemDamage
// Inherited Bytes: 0x110 | Struct Size: 0x110
struct FSolarSystemDamage : FSolarPointDamageEvent {
};

// Object: ScriptStruct Solarland.GMCmdDamageEvent
// Inherited Bytes: 0x110 | Struct Size: 0x110
struct FGMCmdDamageEvent : FSolarSystemDamage {
};

// Object: ScriptStruct Solarland.DeathVergeInWaterDamageEvent
// Inherited Bytes: 0x110 | Struct Size: 0x110
struct FDeathVergeInWaterDamageEvent : FSolarSystemDamage {
};

// Object: ScriptStruct Solarland.HelplessDeathVergeDamageEvent
// Inherited Bytes: 0x110 | Struct Size: 0x110
struct FHelplessDeathVergeDamageEvent : FSolarSystemDamage {
};

// Object: ScriptStruct Solarland.DyingDamageEvent
// Inherited Bytes: 0x110 | Struct Size: 0x110
struct FDyingDamageEvent : FSolarSystemDamage {
};

// Object: ScriptStruct Solarland.SolarAirDropDamageEvent
// Inherited Bytes: 0x110 | Struct Size: 0x110
struct FSolarAirDropDamageEvent : FSolarSystemDamage {
};

// Object: ScriptStruct Solarland.SolarBombDamageEvent
// Inherited Bytes: 0x110 | Struct Size: 0x110
struct FSolarBombDamageEvent : FSolarSystemDamage {
};

// Object: ScriptStruct Solarland.SolarPoisonDamageEvent
// Inherited Bytes: 0x110 | Struct Size: 0x110
struct FSolarPoisonDamageEvent : FSolarSystemDamage {
};

// Object: ScriptStruct Solarland.SolarCharacterDeathEffectData
// Inherited Bytes: 0x0 | Struct Size: 0x70
struct FSolarCharacterDeathEffectData {
	// Fields
	struct FSoftObjectPath Path; // Offset: 0x0 | Size: 0x18
	struct FSoftObjectPath PathForOther; // Offset: 0x18 | Size: 0x18
	struct FTransform RelativeTransform; // Offset: 0x30 | Size: 0x30
	struct FName SocketName; // Offset: 0x60 | Size: 0x8
	bool bAttachToSocket; // Offset: 0x68 | Size: 0x1
	char pad_0x69[0x7]; // Offset: 0x69 | Size: 0x7
};

// Object: ScriptStruct Solarland.SolarGameplayEffectConfig
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FSolarGameplayEffectConfig {
	// Fields
	struct UGameplayEffect* GameplayEffectClass; // Offset: 0x0 | Size: 0x8
	bool bRemoveOnEnd; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x3]; // Offset: 0x9 | Size: 0x3
	int32_t Level; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct Solarland.SoundGroupClothSoundTableData
// Inherited Bytes: 0x8 | Struct Size: 0x18
struct FSoundGroupClothSoundTableData : FSoundGroupTableDataBase {
	// Fields
	struct FString SoundEvent; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct Solarland.SoundGroupStepSoundTableData
// Inherited Bytes: 0x8 | Struct Size: 0x18
struct FSoundGroupStepSoundTableData : FSoundGroupTableDataBase {
	// Fields
	struct FString SoundEvent; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct Solarland.TempUndesignedAttributeMap
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FTempUndesignedAttributeMap {
	// Fields
	struct TMap<struct FName, float> Value; // Offset: 0x0 | Size: 0x50
};

// Object: ScriptStruct Solarland.TeammateHUDPreset
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FTeammateHUDPreset {
	// Fields
	struct UUserWidget* TeammateHUDClass; // Offset: 0x0 | Size: 0x8
	bool bUseDesireSize; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x3]; // Offset: 0x9 | Size: 0x3
	struct FVector2D DrawSize; // Offset: 0xc | Size: 0x8
	int32_t ZOrder; // Offset: 0x14 | Size: 0x4
	float DisplayMaxDistance; // Offset: 0x18 | Size: 0x4
	char pad_0x1C[0x4]; // Offset: 0x1c | Size: 0x4
};

// Object: ScriptStruct Solarland.InjectorMeshPreset
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FInjectorMeshPreset {
	// Fields
	struct FSoftObjectPath InjectorMeshPath; // Offset: 0x0 | Size: 0x18
	char pad_0x18[0x8]; // Offset: 0x18 | Size: 0x8
	struct FTransform InjectorRelativeTrans; // Offset: 0x20 | Size: 0x30
};

// Object: ScriptStruct Solarland.VehicleRepairToolMeshPreset
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FVehicleRepairToolMeshPreset {
	// Fields
	struct FSoftObjectPath MeshPath; // Offset: 0x0 | Size: 0x18
	char pad_0x18[0x8]; // Offset: 0x18 | Size: 0x8
	struct FTransform RelativeTrans; // Offset: 0x20 | Size: 0x30
};

// Object: ScriptStruct Solarland.TreasureBoxOperatorMeshPreset
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FTreasureBoxOperatorMeshPreset {
	// Fields
	struct FGameplayTag StaticOrnamentMeshTag; // Offset: 0x0 | Size: 0x8
	struct FSoftObjectPath TreasureBoxOperatorMeshPath; // Offset: 0x8 | Size: 0x18
	struct FTransform TreasureBoxOperatorRelativeTrans; // Offset: 0x20 | Size: 0x30
};

// Object: ScriptStruct Solarland.OperatorMeshPreset
// Inherited Bytes: 0x0 | Struct Size: 0x120
struct FOperatorMeshPreset {
	// Fields
	struct TSoftObjectPtr<UParticleSystem> ShieldRepairFXResourceSoft; // Offset: 0x0 | Size: 0x28
	struct FVector ShieldRepairFXRelativeLocation; // Offset: 0x28 | Size: 0xc
	char pad_0x34[0x4]; // Offset: 0x34 | Size: 0x4
	struct TSoftObjectPtr<UParticleSystem> ShieldMultiRecoverFXResourceSoft; // Offset: 0x38 | Size: 0x28
	struct FVector ShieldMultiRecoverFXRelativeLocation; // Offset: 0x60 | Size: 0xc
	char pad_0x6C[0x4]; // Offset: 0x6c | Size: 0x4
	struct FSoftObjectPath ShieldOperatorMeshPath; // Offset: 0x70 | Size: 0x18
	struct FSoftObjectPath ShieldOperatorBigMeshPath; // Offset: 0x88 | Size: 0x18
	struct FTransform ShieldOperatorRelativeTrans; // Offset: 0xa0 | Size: 0x30
	struct FSoftObjectPath ShieldUpgradeOperatorMeshPath; // Offset: 0xd0 | Size: 0x18
	char pad_0xE8[0x8]; // Offset: 0xe8 | Size: 0x8
	struct FTransform ShieldUpgradeOperatorRelativeTrans; // Offset: 0xf0 | Size: 0x30
};

// Object: ScriptStruct Solarland.WaterEffectPreset
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FWaterEffectPreset {
	// Fields
	struct TSoftObjectPtr<UParticleSystem> EffectResource; // Offset: 0x0 | Size: 0x28
	struct FName DefaultTrackSocket; // Offset: 0x28 | Size: 0x8
	struct FName FTrackSocket; // Offset: 0x30 | Size: 0x8
	struct FName BTrackSocket; // Offset: 0x38 | Size: 0x8
	struct FName LTrackSocket; // Offset: 0x40 | Size: 0x8
	struct FName RTrackSocket; // Offset: 0x48 | Size: 0x8
};

// Object: ScriptStruct Solarland.SkydivingEffectPreset
// Inherited Bytes: 0x0 | Struct Size: 0x70
struct FSkydivingEffectPreset {
	// Fields
	struct TSoftObjectPtr<UParticleSystem> EffectResource; // Offset: 0x0 | Size: 0x28
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
	struct FTransform AttachmentOffset; // Offset: 0x30 | Size: 0x30
	struct FName AttachmentSocket; // Offset: 0x60 | Size: 0x8
	enum class ESkydiveEffectLifetime LifeTime; // Offset: 0x68 | Size: 0x1
	char pad_0x69[0x7]; // Offset: 0x69 | Size: 0x7
};

// Object: ScriptStruct Solarland.BagRequirementData
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FBagRequirementData {
	// Fields
	int32_t ItemID; // Offset: 0x0 | Size: 0x4
	int32_t count; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct Solarland.ReplicateBagGradeData
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FReplicateBagGradeData {
	// Fields
	int32_t BagGrade; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct TArray<struct FReplicateBagGridData> BagGridDataArray; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct Solarland.ReplicateBagGridData
// Inherited Bytes: 0x0 | Struct Size: 0xc8
struct FReplicateBagGridData {
	// Fields
	struct FSolarItemData ItemData; // Offset: 0x0 | Size: 0xb8
	enum class EBagGridType GridType; // Offset: 0xb8 | Size: 0x1
	char pad_0xB9[0x3]; // Offset: 0xb9 | Size: 0x3
	int32_t BagGrade; // Offset: 0xbc | Size: 0x4
	int32_t Index; // Offset: 0xc0 | Size: 0x4
	bool IsRequirementTag; // Offset: 0xc4 | Size: 0x1
	char pad_0xC5[0x3]; // Offset: 0xc5 | Size: 0x3
};

// Object: ScriptStruct Solarland.ShieldEffect
// Inherited Bytes: 0x0 | Struct Size: 0x38
struct FShieldEffect {
	// Fields
	struct TSoftObjectPtr<UParticleSystem> ShieldEffect; // Offset: 0x0 | Size: 0x28
	struct FVector EffectScale; // Offset: 0x28 | Size: 0xc
	char pad_0x34[0x4]; // Offset: 0x34 | Size: 0x4
};

// Object: ScriptStruct Solarland.CharacterHitInfo
// Inherited Bytes: 0x0 | Struct Size: 0xb4
struct FCharacterHitInfo {
	// Fields
	enum class ESolarHitType HitType; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	struct TWeakObjectPtr<struct AActor> Instigator; // Offset: 0x4 | Size: 0x8
	struct FHitResult HitResult; // Offset: 0xc | Size: 0x88
	struct FVector RelativeHitLocation; // Offset: 0x94 | Size: 0xc
	struct TWeakObjectPtr<struct ASolarWeapon> WeaponCauser; // Offset: 0xa0 | Size: 0x8
	int32_t CauserWeaponID; // Offset: 0xa8 | Size: 0x4
	int32_t CauserWeaponSkinID; // Offset: 0xac | Size: 0x4
	float Damage; // Offset: 0xb0 | Size: 0x4
};

// Object: ScriptStruct Solarland.SingleCruiseParamForReplicated
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FSingleCruiseParamForReplicated {
	// Fields
	struct ASolarCharacter* CurrentCharacter; // Offset: 0x0 | Size: 0x8
	struct FVector StartLocation; // Offset: 0x8 | Size: 0xc
	struct FVector EndLocation; // Offset: 0x14 | Size: 0xc
	float FlyDuringTime; // Offset: 0x20 | Size: 0x4
	float StartTime; // Offset: 0x24 | Size: 0x4
};

// Object: ScriptStruct Solarland.CharacterMovementSimulationOptions
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FCharacterMovementSimulationOptions {
	// Fields
	bool bEnabled; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	float NetworkMaxSmoothUpdateDistance; // Offset: 0x4 | Size: 0x4
	float NetworkNoSmoothUpdateDistance; // Offset: 0x8 | Size: 0x4
	float NetworkSimulatedSmoothLocationTime; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct Solarland.CharacterMovementNetworkOptions
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FCharacterMovementNetworkOptions {
	// Fields
	bool bEnabled; // Offset: 0x0 | Size: 0x1
	bool bServerAcceptClientAuthoritativePosition; // Offset: 0x1 | Size: 0x1
	bool bIgnoreClientMovementErrorChecksAndCorrection; // Offset: 0x2 | Size: 0x1
	char pad_0x3[0x1]; // Offset: 0x3 | Size: 0x1
	float MaxLocationDifferenceToTrustClientMove; // Offset: 0x4 | Size: 0x4
	enum class EClientMoveTrustType ClientMoveTrustType; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x3]; // Offset: 0x9 | Size: 0x3
};

// Object: ScriptStruct Solarland.SideDataParams
// Inherited Bytes: 0x8 | Struct Size: 0x20
struct FSideDataParams : FGameplayAbilityTargetData {
	// Fields
	struct FString SideName; // Offset: 0x8 | Size: 0x10
	char TeamID; // Offset: 0x18 | Size: 0x1
	char pad_0x19[0x7]; // Offset: 0x19 | Size: 0x7
};

// Object: ScriptStruct Solarland.CelebrateWinnerTargetData
// Inherited Bytes: 0x8 | Struct Size: 0x28
struct FCelebrateWinnerTargetData : FGameplayAbilityTargetData {
	// Fields
	struct UObject* FocusCharacter; // Offset: 0x8 | Size: 0x8
	float FocusRange; // Offset: 0x10 | Size: 0x4
	bool bValidReviveCenter; // Offset: 0x14 | Size: 0x1
	char pad_0x15[0x3]; // Offset: 0x15 | Size: 0x3
	struct FVector ReviveCenter; // Offset: 0x18 | Size: 0xc
	char pad_0x24[0x4]; // Offset: 0x24 | Size: 0x4
};

// Object: ScriptStruct Solarland.RadarSpawnParams
// Inherited Bytes: 0x8 | Struct Size: 0x18
struct FRadarSpawnParams : FGameplayAbilityTargetData {
	// Fields
	struct FVector SpawnLocation; // Offset: 0x8 | Size: 0xc
	char pad_0x14[0x4]; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct Solarland.VehicleHitchingParams
// Inherited Bytes: 0x8 | Struct Size: 0x10
struct FVehicleHitchingParams : FGameplayAbilityTargetData {
	// Fields
	int32_t VehicleTypeID; // Offset: 0x8 | Size: 0x4
	char pad_0xC[0x4]; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct Solarland.SingleCruiseData
// Inherited Bytes: 0x8 | Struct Size: 0x28
struct FSingleCruiseData : FGameplayAbilityTargetData {
	// Fields
	struct FVector StartLocation; // Offset: 0x8 | Size: 0xc
	struct FVector EndLocation; // Offset: 0x14 | Size: 0xc
	float During; // Offset: 0x20 | Size: 0x4
	char pad_0x24[0x4]; // Offset: 0x24 | Size: 0x4
};

// Object: ScriptStruct Solarland.ZiplineData
// Inherited Bytes: 0x8 | Struct Size: 0x18
struct FZiplineData : FGameplayAbilityTargetData {
	// Fields
	struct ASolarZiplineObj* ZiplineObj; // Offset: 0x8 | Size: 0x8
	enum class EZiplineSide BeginningSide; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x7]; // Offset: 0x11 | Size: 0x7
};

// Object: ScriptStruct Solarland.CustomJetFlyParams
// Inherited Bytes: 0x8 | Struct Size: 0x28
struct FCustomJetFlyParams : FGameplayAbilityTargetData {
	// Fields
	struct FVector_NetQuantizeNormal DashDirection; // Offset: 0x8 | Size: 0xc
	float DashTime; // Offset: 0x14 | Size: 0x4
	float DashDistance; // Offset: 0x18 | Size: 0x4
	float DashBreakableTime; // Offset: 0x1c | Size: 0x4
	float DashCameraFadeOutTime; // Offset: 0x20 | Size: 0x4
	char pad_0x24[0x4]; // Offset: 0x24 | Size: 0x4
};

// Object: ScriptStruct Solarland.DanceData
// Inherited Bytes: 0x8 | Struct Size: 0x10
struct FDanceData : FGameplayAbilityTargetData {
	// Fields
	int32_t DanceID; // Offset: 0x8 | Size: 0x4
	char pad_0xC[0x4]; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct Solarland.HitRecoverData
// Inherited Bytes: 0x8 | Struct Size: 0x28
struct FHitRecoverData : FGameplayAbilityTargetData {
	// Fields
	float StartTime; // Offset: 0x8 | Size: 0x4
	struct FVector StartLocation; // Offset: 0xc | Size: 0xc
	struct FVector Direction; // Offset: 0x18 | Size: 0xc
	enum class EHitRecoverType Type; // Offset: 0x24 | Size: 0x1
	char pad_0x25[0x3]; // Offset: 0x25 | Size: 0x3
};

// Object: ScriptStruct Solarland.GrapplingHookData
// Inherited Bytes: 0x8 | Struct Size: 0x18
struct FGrapplingHookData : FGameplayAbilityTargetData {
	// Fields
	char pad_0x8[0x10]; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct Solarland.WallRunJumpData
// Inherited Bytes: 0x8 | Struct Size: 0x28
struct FWallRunJumpData : FGameplayAbilityTargetData {
	// Fields
	struct FVector EndLocation; // Offset: 0x8 | Size: 0xc
	struct FRotator EndRotation; // Offset: 0x14 | Size: 0xc
	bool bWallRunFailed; // Offset: 0x20 | Size: 0x1
	char pad_0x21[0x7]; // Offset: 0x21 | Size: 0x7
};

// Object: ScriptStruct Solarland.VaultData
// Inherited Bytes: 0x8 | Struct Size: 0x40
struct FVaultData : FGameplayAbilityTargetData {
	// Fields
	struct FVector AnchorLocation; // Offset: 0x8 | Size: 0xc
	struct FRotator AnchorRotation; // Offset: 0x14 | Size: 0xc
	struct FVector LandLocation; // Offset: 0x20 | Size: 0xc
	enum class EVaultType VaultType; // Offset: 0x2c | Size: 0x1
	char pad_0x2D[0x3]; // Offset: 0x2d | Size: 0x3
	float CameraAngle; // Offset: 0x30 | Size: 0x4
	float CharacterAngle; // Offset: 0x34 | Size: 0x4
	bool bAuto; // Offset: 0x38 | Size: 0x1
	char pad_0x39[0x7]; // Offset: 0x39 | Size: 0x7
};

// Object: ScriptStruct Solarland.WallRunData
// Inherited Bytes: 0x40 | Struct Size: 0x40
struct FWallRunData : FVaultData {
};

// Object: ScriptStruct Solarland.VectorParams
// Inherited Bytes: 0x8 | Struct Size: 0x18
struct FVectorParams : FGameplayAbilityTargetData {
	// Fields
	struct FVector VectorParam; // Offset: 0x8 | Size: 0xc
	char pad_0x14[0x4]; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct Solarland.BlinkParams
// Inherited Bytes: 0x8 | Struct Size: 0x28
struct FBlinkParams : FGameplayAbilityTargetData {
	// Fields
	struct FVector ThrowLoc; // Offset: 0x8 | Size: 0xc
	struct FVector ThrowDir; // Offset: 0x14 | Size: 0xc
	float PredictTime; // Offset: 0x20 | Size: 0x4
	char pad_0x24[0x4]; // Offset: 0x24 | Size: 0x4
};

// Object: ScriptStruct Solarland.MissileSwarmParams
// Inherited Bytes: 0x8 | Struct Size: 0x20
struct FMissileSwarmParams : FGameplayAbilityTargetData {
	// Fields
	struct FVector AimStart; // Offset: 0x8 | Size: 0xc
	struct FRotator ViewRot; // Offset: 0x14 | Size: 0xc
};

// Object: ScriptStruct Solarland.SkywardDiveParams
// Inherited Bytes: 0x8 | Struct Size: 0x10
struct FSkywardDiveParams : FGameplayAbilityTargetData {
	// Fields
	struct TWeakObjectPtr<struct AActor> SkywardDiveLauncherActor; // Offset: 0x8 | Size: 0x8
};

// Object: ScriptStruct Solarland.LaunchParams
// Inherited Bytes: 0x8 | Struct Size: 0x20
struct FLaunchParams : FGameplayAbilityTargetData {
	// Fields
	struct FVector LaunchVelocity; // Offset: 0x8 | Size: 0xc
	bool bXYOverride; // Offset: 0x14 | Size: 0x1
	bool bZOverride; // Offset: 0x15 | Size: 0x1
	char pad_0x16[0x2]; // Offset: 0x16 | Size: 0x2
	struct AActor* JumpPadActor; // Offset: 0x18 | Size: 0x8
};

// Object: ScriptStruct Solarland.CrouchData
// Inherited Bytes: 0x8 | Struct Size: 0x10
struct FCrouchData : FGameplayAbilityTargetData {
	// Fields
	bool bCanCrouchOnFalling; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x7]; // Offset: 0x9 | Size: 0x7
};

// Object: ScriptStruct Solarland.MeleeAttackParams
// Inherited Bytes: 0x8 | Struct Size: 0x10
struct FMeleeAttackParams : FGameplayAbilityTargetData {
	// Fields
	int32_t MeleeIndex; // Offset: 0x8 | Size: 0x4
	bool bFullBody; // Offset: 0xc | Size: 0x1
	char pad_0xD[0x3]; // Offset: 0xd | Size: 0x3
};

// Object: ScriptStruct Solarland.BoltParams
// Inherited Bytes: 0x8 | Struct Size: 0x10
struct FBoltParams : FGameplayAbilityTargetData {
	// Fields
	int32_t FireMode; // Offset: 0x8 | Size: 0x4
	char pad_0xC[0x4]; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct Solarland.FireParams
// Inherited Bytes: 0x8 | Struct Size: 0x10
struct FFireParams : FGameplayAbilityTargetData {
	// Fields
	int32_t FireMode; // Offset: 0x8 | Size: 0x4
	char pad_0xC[0x4]; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct Solarland.EquipParams
// Inherited Bytes: 0x8 | Struct Size: 0x10
struct FEquipParams : FGameplayAbilityTargetData {
	// Fields
	int32_t WeaponSlot; // Offset: 0x8 | Size: 0x4
	float SwitchTime; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct Solarland.PickUpAbilityParams
// Inherited Bytes: 0x8 | Struct Size: 0x20
struct FPickUpAbilityParams : FGameplayAbilityTargetData {
	// Fields
	float HeightDifferenceToItem; // Offset: 0x8 | Size: 0x4
	char pad_0xC[0x4]; // Offset: 0xc | Size: 0x4
	struct FString SoundEventName; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct Solarland.ChunkAssignRule
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FChunkAssignRule {
	// Fields
	struct FString FullPath; // Offset: 0x0 | Size: 0x10
	int32_t ChunkID; // Offset: 0x10 | Size: 0x4
	char pad_0x14[0x4]; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct Solarland.SafeAreaInfoBase
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FSafeAreaInfoBase {
	// Fields
	struct FVector Location; // Offset: 0x0 | Size: 0xc
	float WaitTime; // Offset: 0xc | Size: 0x4
	float ShrinkTime; // Offset: 0x10 | Size: 0x4
	float DamageValue; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct Solarland.CircleSafeAreaInfo
// Inherited Bytes: 0x18 | Struct Size: 0x1c
struct FCircleSafeAreaInfo : FSafeAreaInfoBase {
	// Fields
	float Radius; // Offset: 0x18 | Size: 0x4
};

// Object: ScriptStruct Solarland.HeroClassConfig
// Inherited Bytes: 0x0 | Struct Size: 0x38
struct FHeroClassConfig {
	// Fields
	struct TSoftObjectPtr<UPassiveSkillDataAsset> SpecificPassiveSkill; // Offset: 0x0 | Size: 0x28
	float HPGridUnit; // Offset: 0x28 | Size: 0x4
	bool bEnableCombatRegeneration; // Offset: 0x2c | Size: 0x1
	char pad_0x2D[0x3]; // Offset: 0x2d | Size: 0x3
	int32_t RegenGrids; // Offset: 0x30 | Size: 0x4
	char pad_0x34[0x4]; // Offset: 0x34 | Size: 0x4
};

// Object: ScriptStruct Solarland.ClassInfo
// Inherited Bytes: 0x8 | Struct Size: 0x70
struct FClassInfo : FTableRowBase {
	// Fields
	enum class EClassType ClassType; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x3]; // Offset: 0x9 | Size: 0x3
	int32_t ClassName; // Offset: 0xc | Size: 0x4
	struct FSoftObjectPath ClassIcon; // Offset: 0x10 | Size: 0x18
	struct USkillConfig* SkillOne; // Offset: 0x28 | Size: 0x8
	struct USkillConfig* SkillTwo; // Offset: 0x30 | Size: 0x8
	struct TSoftObjectPtr<UPassiveSkillDataAsset> InitPassiveSkill; // Offset: 0x38 | Size: 0x28
	struct TArray<struct FClassLevelUpRewardConfig> LevelUpBonus; // Offset: 0x60 | Size: 0x10
};

// Object: ScriptStruct Solarland.ClassLevelUpRewardConfig
// Inherited Bytes: 0x0 | Struct Size: 0x38
struct FClassLevelUpRewardConfig {
	// Fields
	int32_t TargetLevel; // Offset: 0x0 | Size: 0x4
	enum class EClassLevelUpRewardType RewardType; // Offset: 0x4 | Size: 0x1
	char pad_0x5[0x3]; // Offset: 0x5 | Size: 0x3
	struct TSoftObjectPtr<UPassiveSkillDataAsset> TargetPassiveSkill; // Offset: 0x8 | Size: 0x28
	struct FClassLevelUpPropertyRewardConfig PropertyReward; // Offset: 0x30 | Size: 0x8
};

// Object: ScriptStruct Solarland.ClassLevelUpPropertyRewardConfig
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FClassLevelUpPropertyRewardConfig {
	// Fields
	enum class ESolarTablesEnum_BattleUpgradeEffectType EffectType; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	int32_t EffectValue; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarDamageTextData
// Inherited Bytes: 0x0 | Struct Size: 0x14
struct FSolarDamageTextData {
	// Fields
	struct TWeakObjectPtr<struct USolarTextBlock> Text; // Offset: 0x0 | Size: 0x8
	struct TWeakObjectPtr<struct UWidgetAnimation> Animation; // Offset: 0x8 | Size: 0x8
	bool bEnableDamageSpecialAnimation; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x3]; // Offset: 0x11 | Size: 0x3
};

// Object: ScriptStruct Solarland.SolarDamageTextIconData
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FSolarDamageTextIconData {
	// Fields
	struct TArray<struct UImage*> Icons; // Offset: 0x0 | Size: 0x10
	struct TWeakObjectPtr<struct UImage> Outline; // Offset: 0x10 | Size: 0x8
	struct TWeakObjectPtr<struct UCanvasPanel> Panel; // Offset: 0x18 | Size: 0x8
	struct TWeakObjectPtr<struct UWidgetAnimation> Animation; // Offset: 0x20 | Size: 0x8
};

// Object: ScriptStruct Solarland.SolarDamageTextOffsetData
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FSolarDamageTextOffsetData {
	// Fields
	float HitHeightOffset; // Offset: 0x0 | Size: 0x4
	struct FVector2D DisplayPositionOffset; // Offset: 0x4 | Size: 0x8
};

// Object: ScriptStruct Solarland.SolarDamageTextGroupData
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FSolarDamageTextGroupData {
	// Fields
	struct TArray<struct TWeakObjectPtr<struct USolarDamageTextSlotWidget>> FloatDamageTextSlotWidgets; // Offset: 0x0 | Size: 0x10
	struct TWeakObjectPtr<struct USolarDamageTextSlotWidget> StackDamageTextSlotWidget; // Offset: 0x10 | Size: 0x8
	int32_t HitCount; // Offset: 0x18 | Size: 0x4
	int32_t CurrentDisplayIndex; // Offset: 0x1c | Size: 0x4
	struct TWeakObjectPtr<struct USolarDamageTextSlotWidget> PendingDamageTextSlotWidget; // Offset: 0x20 | Size: 0x8
	int32_t DamageCount; // Offset: 0x28 | Size: 0x4
	bool bFirstDisplay; // Offset: 0x2c | Size: 0x1
	char ReferenceTimes; // Offset: 0x2d | Size: 0x1
	char pad_0x2E[0x2]; // Offset: 0x2e | Size: 0x2
};

// Object: ScriptStruct Solarland.SolarDamageTextSlotInfo
// Inherited Bytes: 0x0 | Struct Size: 0x118
struct FSolarDamageTextSlotInfo {
	// Fields
	int32_t Damage; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct FSolarDamageTextStyle DamageTextStyle; // Offset: 0x8 | Size: 0xa0
	enum class ESolarDamageTextType DamageTextType; // Offset: 0xa8 | Size: 0x1
	char pad_0xA9[0x7]; // Offset: 0xa9 | Size: 0x7
	struct FSolarDamageTextColor DamageTextColor; // Offset: 0xb0 | Size: 0x68
};

// Object: ScriptStruct Solarland.SolarDamageTextColor
// Inherited Bytes: 0x0 | Struct Size: 0x68
struct FSolarDamageTextColor {
	// Fields
	struct FSlateColor FontColor; // Offset: 0x0 | Size: 0x28
	struct FLinearColor ShadowColor; // Offset: 0x28 | Size: 0x10
	struct FLinearColor IconColor; // Offset: 0x38 | Size: 0x10
	struct FLinearColor OutlineColor; // Offset: 0x48 | Size: 0x10
	struct FLinearColor IconOutlineColor; // Offset: 0x58 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarDamageTextStyle
// Inherited Bytes: 0x0 | Struct Size: 0xa0
struct FSolarDamageTextStyle {
	// Fields
	struct FText DamageText; // Offset: 0x0 | Size: 0x18
	struct FSlateFontInfo Font; // Offset: 0x18 | Size: 0x60
	struct FVector2D ShadowOffset; // Offset: 0x78 | Size: 0x8
	struct FMargin Margin; // Offset: 0x80 | Size: 0x10
	struct TArray<struct FSolarDamageTextColor> Colors; // Offset: 0x90 | Size: 0x10
};

// Object: ScriptStruct Solarland.VehicleSeatWidgets
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FVehicleSeatWidgets {
	// Fields
	struct USolarCheckBox* CheckBox_Seat; // Offset: 0x0 | Size: 0x8
	struct USolarCheckBox* CheckBox_SeatExpand; // Offset: 0x8 | Size: 0x8
	struct UImage* Img_SwitchIcon; // Offset: 0x10 | Size: 0x8
};

// Object: ScriptStruct Solarland.VehicleWeaponFireWidgets
// Inherited Bytes: 0x0 | Struct Size: 0x38
struct FVehicleWeaponFireWidgets {
	// Fields
	struct USolarMovablePad* VehicleFirePad; // Offset: 0x0 | Size: 0x8
	struct UImage* VehicleFireIcon; // Offset: 0x8 | Size: 0x8
	struct USolarTextBlock* Txt_FireType; // Offset: 0x10 | Size: 0x8
	struct UProgressBar* VehicleFireCDProgress; // Offset: 0x18 | Size: 0x8
	struct USolarTextBlock* Txt_VehicleFireCD; // Offset: 0x20 | Size: 0x8
	struct USolarMovablePad* QuickAdsFirePad; // Offset: 0x28 | Size: 0x8
	struct UImage* QuickAdsFireIcon; // Offset: 0x30 | Size: 0x8
};

// Object: ScriptStruct Solarland.PoolRefreshInfo
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FPoolRefreshInfo {
	// Fields
	int32_t PoolGroupID; // Offset: 0x0 | Size: 0x4
	float PoolRefreshTime; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct Solarland.ElectricShopSection
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FElectricShopSection {
	// Fields
	struct TArray<struct FElectricShopItem> Items; // Offset: 0x0 | Size: 0x10
	float CoolDownDuration; // Offset: 0x10 | Size: 0x4
	char pad_0x14[0x4]; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct Solarland.ElectricShopCDRecord
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FElectricShopCDRecord {
	// Fields
	int32_t ProductID; // Offset: 0x0 | Size: 0x4
	float Duration; // Offset: 0x4 | Size: 0x4
	float EndWorldTime; // Offset: 0x8 | Size: 0x4
	char pad_0xC[0x4]; // Offset: 0xc | Size: 0x4
	struct FString BuyerID; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct Solarland.ElectricShopItemDemoRow
// Inherited Bytes: 0x8 | Struct Size: 0x30
struct FElectricShopItemDemoRow : FTableRowBase {
	// Fields
	struct TSoftClassPtr<UObject> ItemDemoBP; // Offset: 0x8 | Size: 0x28
};

// Object: ScriptStruct Solarland.ElectricShopMeshRow
// Inherited Bytes: 0x8 | Struct Size: 0x20
struct FElectricShopMeshRow : FTableRowBase {
	// Fields
	struct FSoftObjectPath Mesh; // Offset: 0x8 | Size: 0x18
};

// Object: ScriptStruct Solarland.MatUpdateParams
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FMatUpdateParams {
	// Fields
	struct FName MatParam; // Offset: 0x0 | Size: 0x8
	struct UCurveBase* MatCurve; // Offset: 0x8 | Size: 0x8
	struct UCurveBase* MatCurveEnemy; // Offset: 0x10 | Size: 0x8
	bool bCanComplete; // Offset: 0x18 | Size: 0x1
	char pad_0x19[0x7]; // Offset: 0x19 | Size: 0x7
};

// Object: ScriptStruct Solarland.CharacterSkydiveTrailData
// Inherited Bytes: 0x0 | Struct Size: 0x60
struct FCharacterSkydiveTrailData {
	// Fields
	char pad_0x0[0x60]; // Offset: 0x0 | Size: 0x60
};

// Object: ScriptStruct Solarland.PackedSkydiveTrailFrameInfoContainer
// Inherited Bytes: 0x108 | Struct Size: 0x120
struct FPackedSkydiveTrailFrameInfoContainer : FFastArraySerializer {
	// Fields
	struct TArray<struct FPackedSkydiveTrailFrameInfo> InfoArray; // Offset: 0x108 | Size: 0x10
	struct ASolarFlyTrail* Owner; // Offset: 0x118 | Size: 0x8
};

// Object: ScriptStruct Solarland.PackedSkydiveTrailFrameInfo
// Inherited Bytes: 0xc | Struct Size: 0x30
struct FPackedSkydiveTrailFrameInfo : FFastArraySerializerItem {
	// Fields
	float Timestamp; // Offset: 0xc | Size: 0x4
	struct TArray<struct FSkydiveTrailFrameInfo> FrameInfos; // Offset: 0x10 | Size: 0x10
	struct TArray<struct ASolarPlayerState*> FinishedPlayerStates; // Offset: 0x20 | Size: 0x10
};

// Object: ScriptStruct Solarland.SkydiveTrailFrameInfo
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FSkydiveTrailFrameInfo {
	// Fields
	struct ASolarPlayerState* OwnerPlayerState; // Offset: 0x0 | Size: 0x8
	struct FVector_NetQuantize Location; // Offset: 0x8 | Size: 0xc
	struct FVector_NetQuantize Velocity; // Offset: 0x14 | Size: 0xc
};

// Object: ScriptStruct Solarland.CharacterSkydiveTrailStaticInfoContainer
// Inherited Bytes: 0x108 | Struct Size: 0x120
struct FCharacterSkydiveTrailStaticInfoContainer : FFastArraySerializer {
	// Fields
	struct TArray<struct FCharacterSkydiveTrailStaticInfo> InfoArray; // Offset: 0x108 | Size: 0x10
	struct ASolarFlyTrail* Owner; // Offset: 0x118 | Size: 0x8
};

// Object: ScriptStruct Solarland.CharacterSkydiveTrailStaticInfo
// Inherited Bytes: 0xc | Struct Size: 0x38
struct FCharacterSkydiveTrailStaticInfo : FFastArraySerializerItem {
	// Fields
	char pad_0xC[0x4]; // Offset: 0xc | Size: 0x4
	struct FString CharacterId; // Offset: 0x10 | Size: 0x10
	struct ASolarPlayerState* PlayerState; // Offset: 0x20 | Size: 0x8
	struct FString TrailAssemblingId; // Offset: 0x28 | Size: 0x10
};

// Object: ScriptStruct Solarland.VehicleDetector
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FVehicleDetector {
	// Fields
	struct FRotator VehicleLocalRotator; // Offset: 0x0 | Size: 0xc
	struct FVector StartLocParameter; // Offset: 0xc | Size: 0xc
};

// Object: ScriptStruct Solarland.FuncCharacterBackpackInfo
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FFuncCharacterBackpackInfo {
	// Fields
	int32_t BagId; // Offset: 0x0 | Size: 0x4
	int32_t TailFlameId; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct Solarland.AntiCheatData
// Inherited Bytes: 0x0 | Struct Size: 0x70
struct FAntiCheatData {
	// Fields
	char pad_0x0[0x70]; // Offset: 0x0 | Size: 0x70
};

// Object: ScriptStruct Solarland.SolarGameMode_DropItemData
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FSolarGameMode_DropItemData {
	// Fields
	int32_t ID; // Offset: 0x0 | Size: 0x4
	int32_t count; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct Solarland.SCustomMode_GameModeSetting
// Inherited Bytes: 0x0 | Struct Size: 0x68
struct FSCustomMode_GameModeSetting {
	// Fields
	struct FSoftObjectPath PlayerControllerClass; // Offset: 0x0 | Size: 0x18
	struct FSoftObjectPath DefaultPawnClass; // Offset: 0x18 | Size: 0x18
	struct FSoftObjectPath PlayerStateClass; // Offset: 0x30 | Size: 0x18
	struct FSoftObjectPath HUDClass; // Offset: 0x48 | Size: 0x18
	int32_t SettlementStageConfigID; // Offset: 0x60 | Size: 0x4
	char pad_0x64[0x4]; // Offset: 0x64 | Size: 0x4
};

// Object: ScriptStruct Solarland.SGameMode_LevelConfig
// Inherited Bytes: 0x0 | Struct Size: 0x78
struct FSGameMode_LevelConfig {
	// Fields
	struct FString Name; // Offset: 0x0 | Size: 0x10
	struct FString Desc; // Offset: 0x10 | Size: 0x10
	struct FSoftObjectPath LevelMap; // Offset: 0x20 | Size: 0x18
	int32_t MiniMapId; // Offset: 0x38 | Size: 0x4
	bool IsStreaming; // Offset: 0x3c | Size: 0x1
	char pad_0x3D[0x3]; // Offset: 0x3d | Size: 0x3
	struct TArray<struct FSolarElementGroupPath> ElementGroups; // Offset: 0x40 | Size: 0x10
	struct TSoftClassPtr<UObject> LoadingUI; // Offset: 0x50 | Size: 0x28
};

// Object: ScriptStruct Solarland.SolarElementGroupPath
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FSolarElementGroupPath {
	// Fields
	struct FString Name; // Offset: 0x0 | Size: 0x10
	struct FSoftObjectPath ElementLevel; // Offset: 0x10 | Size: 0x18
	bool LoadWithLevel; // Offset: 0x28 | Size: 0x1
	bool bPersistentLevel; // Offset: 0x29 | Size: 0x1
	char pad_0x2A[0x6]; // Offset: 0x2a | Size: 0x6
};

// Object: ScriptStruct Solarland.GameMode_ElementStruct
// Inherited Bytes: 0x8 | Struct Size: 0x220
struct FGameMode_ElementStruct : FTableRowBase {
	// Fields
	struct FString ElementID; // Offset: 0x8 | Size: 0x10
	struct FString Description; // Offset: 0x18 | Size: 0x10
	struct FString Side; // Offset: 0x28 | Size: 0x10
	struct FString Job; // Offset: 0x38 | Size: 0x10
	struct TArray<struct FName> Tags; // Offset: 0x48 | Size: 0x10
	struct TMap<struct FString, bool> PropertiesBool; // Offset: 0x58 | Size: 0x50
	struct TMap<struct FString, int32_t> PropertiesInt; // Offset: 0xa8 | Size: 0x50
	struct TMap<struct FString, float> PropertiesFloat; // Offset: 0xf8 | Size: 0x50
	struct TMap<struct FString, struct FString> PropertiesString; // Offset: 0x148 | Size: 0x50
	struct FName ElementTypeName; // Offset: 0x198 | Size: 0x8
	struct FString BP_Path; // Offset: 0x1a0 | Size: 0x10
	struct FVector Location; // Offset: 0x1b0 | Size: 0xc
	char pad_0x1BC[0x4]; // Offset: 0x1bc | Size: 0x4
	struct FQuat Rotation; // Offset: 0x1c0 | Size: 0x10
	struct FVector Scale; // Offset: 0x1d0 | Size: 0xc
	enum class EElementStateType State; // Offset: 0x1dc | Size: 0x1
	enum class EElementVisibilityType Visibility; // Offset: 0x1dd | Size: 0x1
	char pad_0x1DE[0x2]; // Offset: 0x1de | Size: 0x2
	int32_t OutcomeID; // Offset: 0x1e0 | Size: 0x4
	struct FBox SpawnerBox; // Offset: 0x1e4 | Size: 0x1c
	bool bRefresh; // Offset: 0x200 | Size: 0x1
	char pad_0x201[0x3]; // Offset: 0x201 | Size: 0x3
	float RefreshTime; // Offset: 0x204 | Size: 0x4
	bool bUseSpawnerTransform; // Offset: 0x208 | Size: 0x1
	bool bToTheGround; // Offset: 0x209 | Size: 0x1
	char pad_0x20A[0x2]; // Offset: 0x20a | Size: 0x2
	int32_t SpawnID; // Offset: 0x20c | Size: 0x4
	int32_t Zone; // Offset: 0x210 | Size: 0x4
	enum class ESGameMode_ElementType Type; // Offset: 0x214 | Size: 0x1
	char pad_0x215[0xb]; // Offset: 0x215 | Size: 0xb
};

// Object: ScriptStruct Solarland.SolarElementGroup
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FSolarElementGroup {
	// Fields
	struct FString GroupKey; // Offset: 0x0 | Size: 0x10
	bool bIsDefault; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x7]; // Offset: 0x11 | Size: 0x7
	struct UDataTable* ElementTable; // Offset: 0x18 | Size: 0x8
};

// Object: ScriptStruct Solarland.StatDataValue
// Inherited Bytes: 0x0 | Struct Size: 0x98
struct FStatDataValue {
	// Fields
	float FloatValue; // Offset: 0x0 | Size: 0x4
	bool BoolValue; // Offset: 0x4 | Size: 0x1
	char pad_0x5[0x3]; // Offset: 0x5 | Size: 0x3
	struct FString StringValue; // Offset: 0x8 | Size: 0x10
	struct TMap<int32_t, float> IntfloatValue; // Offset: 0x18 | Size: 0x50
	struct TArray<int32_t> IntArrayValue; // Offset: 0x68 | Size: 0x10
	struct TArray<float> FloatArrayValue; // Offset: 0x78 | Size: 0x10
	struct FVector Vector; // Offset: 0x88 | Size: 0xc
	char pad_0x94[0x4]; // Offset: 0x94 | Size: 0x4
};

// Object: ScriptStruct Solarland.AbilityMeshMontage
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FAbilityMeshMontage {
	// Fields
	struct USkeletalMeshComponent* Mesh; // Offset: 0x0 | Size: 0x8
	struct UAnimMontage* Montage; // Offset: 0x8 | Size: 0x8
};

// Object: ScriptStruct Solarland.GraphicsSettingsRange
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FGraphicsSettingsRange {
	// Fields
	struct FRangeData AdaptationUIValue; // Offset: 0x0 | Size: 0x8
	struct FRangeData FOVRange; // Offset: 0x8 | Size: 0x8
	struct FRangeData BrightnessRange; // Offset: 0x10 | Size: 0x8
};

// Object: ScriptStruct Solarland.SensitivitySettingsRange
// Inherited Bytes: 0x0 | Struct Size: 0x120
struct FSensitivitySettingsRange {
	// Fields
	struct FRangeData Sensitivity_CurveScale; // Offset: 0x0 | Size: 0x8
	struct FRangeData Sensitivity_Free; // Offset: 0x8 | Size: 0x8
	struct FRangeData Sensitivity_SecondarySkills; // Offset: 0x10 | Size: 0x8
	struct FRangeData Sensitivity_SuperSkills; // Offset: 0x18 | Size: 0x8
	struct FCameraSensitivityRangeData Sensitivity_NoShoot; // Offset: 0x20 | Size: 0x40
	struct FCameraSensitivityRangeData Sensitivity_Shoot; // Offset: 0x60 | Size: 0x40
	struct FVehicleCameraSensitivityRangeData Sensitivity_Vehicle_NoShoot; // Offset: 0xa0 | Size: 0x18
	struct FVehicleCameraSensitivityRangeData Sensitivity_Vehicle_Shoot; // Offset: 0xb8 | Size: 0x18
	struct FRangeData Sensitivity_VehicleDriver; // Offset: 0xd0 | Size: 0x8
	struct FRangeData Sensitivity_VehicleFire; // Offset: 0xd8 | Size: 0x8
	struct FGyroscopeSensitivityRangeData Sensitivity_GyroscopeData; // Offset: 0xe0 | Size: 0x40
};

// Object: ScriptStruct Solarland.GyroscopeSensitivityRangeData
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FGyroscopeSensitivityRangeData {
	// Fields
	struct FRangeData GyroscopeSensitivity_Basic; // Offset: 0x0 | Size: 0x8
	struct FRangeData GyroscopeSensitivity_Shoulder; // Offset: 0x8 | Size: 0x8
	struct FRangeData GyroscopeSensitivity_RedPoint; // Offset: 0x10 | Size: 0x8
	struct FRangeData GyroscopeSensitivity_Lens_Two; // Offset: 0x18 | Size: 0x8
	struct FRangeData GyroscopeSensitivity_Lens_Three; // Offset: 0x20 | Size: 0x8
	struct FRangeData GyroscopeSensitivity_Lens_Four; // Offset: 0x28 | Size: 0x8
	struct FRangeData GyroscopeSensitivity_Lens_Six; // Offset: 0x30 | Size: 0x8
	struct FRangeData GyroscopeSensitivity_Lens_Eight; // Offset: 0x38 | Size: 0x8
};

// Object: ScriptStruct Solarland.VehicleCameraSensitivityRangeData
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FVehicleCameraSensitivityRangeData {
	// Fields
	struct FRangeData Sensitivity_Lens_Two; // Offset: 0x0 | Size: 0x8
	struct FRangeData Sensitivity_Lens_Four; // Offset: 0x8 | Size: 0x8
	struct FRangeData Sensitivity_Lens_Eight; // Offset: 0x10 | Size: 0x8
};

// Object: ScriptStruct Solarland.CameraSensitivityRangeData
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FCameraSensitivityRangeData {
	// Fields
	struct FRangeData Sensitivity_Basic; // Offset: 0x0 | Size: 0x8
	struct FRangeData Sensitivity_Shoulder; // Offset: 0x8 | Size: 0x8
	struct FRangeData Sensitivity_RedPoint; // Offset: 0x10 | Size: 0x8
	struct FRangeData Sensitivity_Lens_Two; // Offset: 0x18 | Size: 0x8
	struct FRangeData Sensitivity_Lens_Three; // Offset: 0x20 | Size: 0x8
	struct FRangeData Sensitivity_Lens_Four; // Offset: 0x28 | Size: 0x8
	struct FRangeData Sensitivity_Lens_Six; // Offset: 0x30 | Size: 0x8
	struct FRangeData Sensitivity_Lens_Eight; // Offset: 0x38 | Size: 0x8
};

// Object: ScriptStruct Solarland.SoundSettingsRange
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FSoundSettingsRange {
	// Fields
	struct FRangeData Sound_Global; // Offset: 0x0 | Size: 0x8
	struct FRangeData Sound_Action; // Offset: 0x8 | Size: 0x8
	struct FRangeData Sound_BackGround; // Offset: 0x10 | Size: 0x8
	struct FRangeData Sound_Character; // Offset: 0x18 | Size: 0x8
};

// Object: ScriptStruct Solarland.GamepadSettingsRange
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FGamepadSettingsRange {
	// Fields
	struct FRangeData MainHorizontalSensitivity; // Offset: 0x0 | Size: 0x8
	struct FRangeData MainVerticalSensitivity; // Offset: 0x8 | Size: 0x8
};

// Object: ScriptStruct Solarland.MouseAndKeyboardSettingsRange
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FMouseAndKeyboardSettingsRange {
	// Fields
	struct FRangeData MainSensitivity; // Offset: 0x0 | Size: 0x8
};

// Object: ScriptStruct Solarland.PlayerStatesInTeam
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FPlayerStatesInTeam {
	// Fields
	struct TArray<struct ASolarPlayerState*> PlayerStates; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarGameStatisticsLogHeadInfo
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FSolarGameStatisticsLogHeadInfo {
	// Fields
	int32_t BattleInstanceId; // Offset: 0x0 | Size: 0x4
	int32_t PIEInstance; // Offset: 0x4 | Size: 0x4
	struct FString BattleID; // Offset: 0x8 | Size: 0x10
	struct FString WorldName; // Offset: 0x18 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarGameStatisticsData
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FSolarGameStatisticsData {
	// Fields
	char pad_0x0[0x28]; // Offset: 0x0 | Size: 0x28
};

// Object: ScriptStruct Solarland.ShadowDetailLevelData
// Inherited Bytes: 0x8 | Struct Size: 0x18
struct FShadowDetailLevelData : FTableRowBase {
	// Fields
	enum class ESolarSunlightShadowDetailLevel SunlightShadowDetailLevelEnum; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x3]; // Offset: 0x9 | Size: 0x3
	int32_t ShadowQualityValue; // Offset: 0xc | Size: 0x4
	int32_t MaxCSMResolution; // Offset: 0x10 | Size: 0x4
	float ShadowDistanceScale; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct Solarland.ResolutionData
// Inherited Bytes: 0x8 | Struct Size: 0x18
struct FResolutionData : FTableRowBase {
	// Fields
	enum class ESolarResolution ResolutionEnum; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x3]; // Offset: 0x9 | Size: 0x3
	int32_t Width; // Offset: 0xc | Size: 0x4
	int32_t Height; // Offset: 0x10 | Size: 0x4
	char pad_0x14[0x4]; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct Solarland.SymmetricRangeFloat
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FSymmetricRangeFloat {
	// Fields
	struct FRangeFloat Range; // Offset: 0x0 | Size: 0x8
	bool bSymmetric; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x3]; // Offset: 0x9 | Size: 0x3
};

// Object: ScriptStruct Solarland.ColorGradingItem
// Inherited Bytes: 0x0 | Struct Size: 0x5d0
struct FColorGradingItem {
	// Fields
	enum class ESolarColorTheme ColorTheme; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0xf]; // Offset: 0x1 | Size: 0xf
	struct FPostProcessSettings PPSettings; // Offset: 0x10 | Size: 0x5c0
};

// Object: ScriptStruct Solarland.MaxQualityConfig
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FMaxQualityConfig {
	// Fields
	struct TMap<enum class ESolarGraphicsQualityLevel, enum class ESolarFrameRateLevel> CurQualityToMaxFrameRateLevel; // Offset: 0x0 | Size: 0x50
};

// Object: ScriptStruct Solarland.FrameRateLevelItem
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FFrameRateLevelItem {
	// Fields
	enum class ESolarFrameRateLevel FrameRateLevel; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	float FrameRateLobby; // Offset: 0x4 | Size: 0x4
	float FrameRateInGame; // Offset: 0x8 | Size: 0x4
	float FrameRatePC; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct Solarland.ContentScaleFactorLevelItem
// Inherited Bytes: 0x0 | Struct Size: 0x58
struct FContentScaleFactorLevelItem {
	// Fields
	enum class ESolarContentScaleFactorLevel ContentScaleFactorLevel; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x7]; // Offset: 0x1 | Size: 0x7
	struct TMap<enum class ESolarDeviceLevel, float> DeviceLevelContentScaleFactorMap; // Offset: 0x8 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarDamageInfo
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FSolarDamageInfo {
	// Fields
	struct AActor* TargetActor; // Offset: 0x0 | Size: 0x8
	struct AActor* SourceActor; // Offset: 0x8 | Size: 0x8
	struct AActor* DamageCauserActor; // Offset: 0x10 | Size: 0x8
	float OriginalDamage; // Offset: 0x18 | Size: 0x4
	float OriginalDamageForVehicle; // Offset: 0x1c | Size: 0x4
	char pad_0x20[0x4]; // Offset: 0x20 | Size: 0x4
	enum class ESCMDamageType DamageType; // Offset: 0x24 | Size: 0x1
	char pad_0x25[0x3]; // Offset: 0x25 | Size: 0x3
	float DamageRadial; // Offset: 0x28 | Size: 0x4
	char bRadialIgnoreCollision : 1; // Offset: 0x2c | Size: 0x1
	char bRadialIgnoreVehicle : 1; // Offset: 0x2c | Size: 0x1
	char bEnableSelfDamage : 1; // Offset: 0x2c | Size: 0x1
	char bCheckSourceToTargetCollision : 1; // Offset: 0x2c | Size: 0x1
	char bApplyToSource : 1; // Offset: 0x2c | Size: 0x1
	char bJustForShield : 1; // Offset: 0x2c | Size: 0x1
	char pad_0x2C_6 : 2; // Offset: 0x2c | Size: 0x1
	char pad_0x2D[0x3]; // Offset: 0x2d | Size: 0x3
	float ExplosionMinDistance; // Offset: 0x30 | Size: 0x4
	float ExplosionMaxDistance; // Offset: 0x34 | Size: 0x4
	struct UCurveFloat* ExplosionDistanceScaleCurve; // Offset: 0x38 | Size: 0x8
};

// Object: ScriptStruct Solarland.HomeShaderData
// Inherited Bytes: 0x0 | Struct Size: 0xa0
struct FHomeShaderData {
	// Fields
	char pad_0x0[0xa0]; // Offset: 0x0 | Size: 0xa0
};

// Object: ScriptStruct Solarland.HomeActorQueueData
// Inherited Bytes: 0x0 | Struct Size: 0x78
struct FHomeActorQueueData {
	// Fields
	enum class EHomeOperationType Type; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct FHomeActorServerData Data; // Offset: 0x8 | Size: 0x68
	enum class EHomeLoadingChangeType LoadingType; // Offset: 0x70 | Size: 0x4
	bool bOnConstruct; // Offset: 0x74 | Size: 0x1
	char pad_0x75[0x3]; // Offset: 0x75 | Size: 0x3
};

// Object: ScriptStruct Solarland.HomeActorServerData
// Inherited Bytes: 0x0 | Struct Size: 0x68
struct FHomeActorServerData {
	// Fields
	int32_t ItemID; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct FString ThisID; // Offset: 0x8 | Size: 0x10
	enum class EHomeActorOwner Owner; // Offset: 0x18 | Size: 0x4
	bool isPreview; // Offset: 0x1c | Size: 0x1
	bool isDelete; // Offset: 0x1d | Size: 0x1
	char pad_0x1E[0x2]; // Offset: 0x1e | Size: 0x2
	struct FVector CurLocation; // Offset: 0x20 | Size: 0xc
	struct FRotator CurRotation; // Offset: 0x2c | Size: 0xc
	struct TArray<struct FBuildMeshSlotData> FacesMatData; // Offset: 0x38 | Size: 0x10
	struct FString ParentObject; // Offset: 0x48 | Size: 0x10
	struct TArray<struct FString> ChildObjects; // Offset: 0x58 | Size: 0x10
};

// Object: ScriptStruct Solarland.BuildMeshSlotData
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FBuildMeshSlotData {
	// Fields
	struct FString SlotName; // Offset: 0x0 | Size: 0x10
	struct FString TexturesID; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct Solarland.HomeOriginalShader
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FHomeOriginalShader {
	// Fields
	char pad_0x0[0x28]; // Offset: 0x0 | Size: 0x28
};

// Object: ScriptStruct Solarland.HomeActorStaticData
// Inherited Bytes: 0x0 | Struct Size: 0x38
struct FHomeActorStaticData {
	// Fields
	int64_t ItemID; // Offset: 0x0 | Size: 0x8
	enum class EHomeActor_FirstType FirstType; // Offset: 0x8 | Size: 0x4
	enum class EHomeActor_SecondType SecondType; // Offset: 0xc | Size: 0x4
	bool IsBrace; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x7]; // Offset: 0x11 | Size: 0x7
	struct FString Icon; // Offset: 0x18 | Size: 0x10
	struct FString BpPath; // Offset: 0x28 | Size: 0x10
};

// Object: ScriptStruct Solarland.HomeBuildReqData
// Inherited Bytes: 0x0 | Struct Size: 0x48
struct FHomeBuildReqData {
	// Fields
	int32_t ItemID; // Offset: 0x0 | Size: 0x4
	struct FVector Location; // Offset: 0x4 | Size: 0xc
	struct FRotator Rotation; // Offset: 0x10 | Size: 0xc
	char pad_0x1C[0x4]; // Offset: 0x1c | Size: 0x4
	struct TArray<struct FBuildMeshSlotData> MatDataArr; // Offset: 0x20 | Size: 0x10
	struct FString ParentThisID; // Offset: 0x30 | Size: 0x10
	bool IsSelected; // Offset: 0x40 | Size: 0x1
	char pad_0x41[0x7]; // Offset: 0x41 | Size: 0x7
};

// Object: ScriptStruct Solarland.BaseSpaceData
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FBaseSpaceData {
	// Fields
	int32_t Layer; // Offset: 0x0 | Size: 0x4
	enum class EHomeActor_SecondType BaseSpaceType; // Offset: 0x4 | Size: 0x4
	bool IsOccupied; // Offset: 0x8 | Size: 0x1
	bool IsShow; // Offset: 0x9 | Size: 0x1
	char pad_0xA[0x2]; // Offset: 0xa | Size: 0x2
};

// Object: ScriptStruct Solarland.HomeCameraMoveData
// Inherited Bytes: 0x0 | Struct Size: 0xa0
struct FHomeCameraMoveData {
	// Fields
	char pad_0x0[0xa0]; // Offset: 0x0 | Size: 0xa0
};

// Object: ScriptStruct Solarland.CameraTransitionData
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FCameraTransitionData {
	// Fields
	char pad_0x0[0xc]; // Offset: 0x0 | Size: 0xc
};

// Object: ScriptStruct Solarland.HomeCameraModeData
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FHomeCameraModeData {
	// Fields
	char pad_0x0[0x40]; // Offset: 0x0 | Size: 0x40
};

// Object: ScriptStruct Solarland.CameraMovementParameters
// Inherited Bytes: 0x0 | Struct Size: 0x68
struct FCameraMovementParameters {
	// Fields
	float OneFingerMoveScale; // Offset: 0x0 | Size: 0x4
	float MouseMoveScale; // Offset: 0x4 | Size: 0x4
	float OneFingerZoomScale; // Offset: 0x8 | Size: 0x4
	float MouseZoomScale; // Offset: 0xc | Size: 0x4
	float DoubleFingerSpinScale; // Offset: 0x10 | Size: 0x4
	float DoubleFingerPitchScale; // Offset: 0x14 | Size: 0x4
	float MouseRotateScale; // Offset: 0x18 | Size: 0x4
	float LookAtLocationHeigh; // Offset: 0x1c | Size: 0x4
	float MinPitch; // Offset: 0x20 | Size: 0x4
	float MaxPitch; // Offset: 0x24 | Size: 0x4
	float PanoramicDefaultPitch; // Offset: 0x28 | Size: 0x4
	float homeCameraBoundary; // Offset: 0x2c | Size: 0x4
	struct UCurveFloat* DistanceCurve; // Offset: 0x30 | Size: 0x8
	float DefultTime; // Offset: 0x38 | Size: 0x4
	char pad_0x3C[0x4]; // Offset: 0x3c | Size: 0x4
	struct UCurveFloat* DistanceCurve_Orthographic; // Offset: 0x40 | Size: 0x8
	float DefaultTime_Orthographic; // Offset: 0x48 | Size: 0x4
	char pad_0x4C[0x4]; // Offset: 0x4c | Size: 0x4
	struct UCurveFloat* LayerTransitionCurve; // Offset: 0x50 | Size: 0x8
	struct UCurveFloat* CeilingTransitionCurve; // Offset: 0x58 | Size: 0x8
	struct UCurveFloat* PanoramicTransitionCurve; // Offset: 0x60 | Size: 0x8
};

// Object: ScriptStruct Solarland.HomeIcon
// Inherited Bytes: 0x8 | Struct Size: 0x38
struct FHomeIcon : FTableRowBase {
	// Fields
	struct FSoftObjectPath NormalIconPath; // Offset: 0x8 | Size: 0x18
	struct FSoftObjectPath SelectedIconPath; // Offset: 0x20 | Size: 0x18
};

// Object: ScriptStruct Solarland.BuildMeshData
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FBuildMeshData {
	// Fields
	int64_t ItemID; // Offset: 0x0 | Size: 0x8
	struct FSoftObjectPath MeshPath; // Offset: 0x8 | Size: 0x18
	struct TArray<struct FBuildMeshSlotData> DefaultMat; // Offset: 0x20 | Size: 0x10
};

// Object: ScriptStruct Solarland.HomeObject
// Inherited Bytes: 0x8 | Struct Size: 0xc0
struct FHomeObject : FTableRowBase {
	// Fields
	struct FString HomeObjectDesc; // Offset: 0x8 | Size: 0x10
	struct FSoftObjectPath BpPath; // Offset: 0x18 | Size: 0x18
	struct FSoftObjectPath PreviewBpPath; // Offset: 0x30 | Size: 0x18
	struct TArray<struct FBuildMeshSlotData> DefaultMat; // Offset: 0x48 | Size: 0x10
	bool IsFocusCenter; // Offset: 0x58 | Size: 0x1
	bool IsDrawable; // Offset: 0x59 | Size: 0x1
	bool IsRotate; // Offset: 0x5a | Size: 0x1
	bool IsBrace; // Offset: 0x5b | Size: 0x1
	bool IsRotateHandle; // Offset: 0x5c | Size: 0x1
	char pad_0x5D[0x3]; // Offset: 0x5d | Size: 0x3
	int32_t RotateAngleSingle; // Offset: 0x60 | Size: 0x4
	char pad_0x64[0x4]; // Offset: 0x64 | Size: 0x4
	struct FSoftObjectPath Build_SFPath; // Offset: 0x68 | Size: 0x18
	struct FSoftObjectPath Remove_SFXPath; // Offset: 0x80 | Size: 0x18
	float FRemove_SFXTime; // Offset: 0x98 | Size: 0x4
	char pad_0x9C[0x4]; // Offset: 0x9c | Size: 0x4
	struct FString FSBuild_Audio; // Offset: 0xa0 | Size: 0x10
	struct FString FSRemove_Audio; // Offset: 0xb0 | Size: 0x10
};

// Object: ScriptStruct Solarland.HomePic
// Inherited Bytes: 0x8 | Struct Size: 0x20
struct FHomePic : FTableRowBase {
	// Fields
	struct FSoftObjectPath PicPath; // Offset: 0x8 | Size: 0x18
};

// Object: ScriptStruct Solarland.HomeObjectTexture
// Inherited Bytes: 0x8 | Struct Size: 0x78
struct FHomeObjectTexture : FTableRowBase {
	// Fields
	struct FString TextureDesc; // Offset: 0x8 | Size: 0x10
	struct FSoftObjectPath BaseColorPath; // Offset: 0x18 | Size: 0x18
	struct FSoftObjectPath MetalPath; // Offset: 0x30 | Size: 0x18
	struct FSoftObjectPath LightmapPath; // Offset: 0x48 | Size: 0x18
	struct FSoftObjectPath NormalPath; // Offset: 0x60 | Size: 0x18
};

// Object: ScriptStruct Solarland.ThrusterState
// Inherited Bytes: 0x0 | Struct Size: 0xc8
struct FThrusterState {
	// Fields
	char pad_0x0[0x38]; // Offset: 0x0 | Size: 0x38
	struct FHitResult TouchGroundHit; // Offset: 0x38 | Size: 0x88
	char pad_0xC0[0x8]; // Offset: 0xc0 | Size: 0x8
};

// Object: ScriptStruct Solarland.ThrusterData
// Inherited Bytes: 0x0 | Struct Size: 0x3c
struct FThrusterData {
	// Fields
	float HoverHeightMultiplierInForward; // Offset: 0x0 | Size: 0x4
	float HoverHeightMultiplierInBackward; // Offset: 0x4 | Size: 0x4
	float HoverHeightMultiplierInLeft; // Offset: 0x8 | Size: 0x4
	float HoverHeightMultiplierInRight; // Offset: 0xc | Size: 0x4
	bool bRaiseDust; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x3]; // Offset: 0x11 | Size: 0x3
	float DustEffectScale; // Offset: 0x14 | Size: 0x4
	struct FVector DustEffectOffest; // Offset: 0x18 | Size: 0xc
	struct FName ThrusterSocket; // Offset: 0x24 | Size: 0x8
	struct FVector ThrusterOffsetIfNoValidSocket; // Offset: 0x2c | Size: 0xc
	float SweepRadius; // Offset: 0x38 | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarClientPerformance
// Inherited Bytes: 0x0 | Struct Size: 0x1
struct FSolarClientPerformance {
	// Fields
	char pad_0x0[0x1]; // Offset: 0x0 | Size: 0x1
};

// Object: ScriptStruct Solarland.CountDownInfoDeprecated
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FCountDownInfoDeprecated {
	// Fields
	int32_t TextID; // Offset: 0x0 | Size: 0x4
	float Time; // Offset: 0x4 | Size: 0x4
	bool bShowBtn; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x27]; // Offset: 0x9 | Size: 0x27
};

// Object: ScriptStruct Solarland.SolarInputActionEntry
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FSolarInputActionEntry {
	// Fields
	struct UInputAction* InputAction; // Offset: 0x0 | Size: 0x8
	char pad_0x8[0x10]; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct Solarland.InputHandler
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FInputHandler {
	// Fields
	char pad_0x0[0x20]; // Offset: 0x0 | Size: 0x20
};

// Object: ScriptStruct Solarland.TouchHandler
// Inherited Bytes: 0x20 | Struct Size: 0x180
struct FTouchHandler : FInputHandler {
	// Fields
	char pad_0x20[0x78]; // Offset: 0x20 | Size: 0x78
	struct UCurveFloat* HorizCurve; // Offset: 0x98 | Size: 0x8
	struct UCurveFloat* VertCurve; // Offset: 0xa0 | Size: 0x8
	char pad_0xA8[0x28]; // Offset: 0xa8 | Size: 0x28
	struct UCurveFloat* DistHorizCurve; // Offset: 0xd0 | Size: 0x8
	struct UCurveFloat* DistVertCurve; // Offset: 0xd8 | Size: 0x8
	char pad_0xE0[0xa0]; // Offset: 0xe0 | Size: 0xa0
};

// Object: ScriptStruct Solarland.SolarInputModeUIOnly
// Inherited Bytes: 0x10 | Struct Size: 0x30
struct FSolarInputModeUIOnly : FSolarInputModeDataBase {
	// Fields
	char pad_0x10[0x20]; // Offset: 0x10 | Size: 0x20
};

// Object: ScriptStruct Solarland.SolarInputModeGameAndUI
// Inherited Bytes: 0x10 | Struct Size: 0x30
struct FSolarInputModeGameAndUI : FSolarInputModeDataBase {
	// Fields
	char pad_0x10[0x20]; // Offset: 0x10 | Size: 0x20
};

// Object: ScriptStruct Solarland.SolarInputModeGameOnly
// Inherited Bytes: 0x10 | Struct Size: 0x20
struct FSolarInputModeGameOnly : FSolarInputModeDataBase {
	// Fields
	char pad_0x10[0x10]; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct Solarland.RadarStationCollection
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FRadarStationCollection {
	// Fields
	int32_t Zone; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct TArray<struct ASolarRadarStation*> AllRadarStations; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct Solarland.SyncBurstItemParam
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FSyncBurstItemParam {
	// Fields
	struct FVector_NetQuantize StartLoc; // Offset: 0x0 | Size: 0xc
	struct FVector_NetQuantize MediumLoc; // Offset: 0xc | Size: 0xc
	struct FVector_NetQuantize EndLoc; // Offset: 0x18 | Size: 0xc
	float BurstLocalHeight; // Offset: 0x24 | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarShieldItemShopDataArray
// Inherited Bytes: 0x108 | Struct Size: 0x130
struct FSolarShieldItemShopDataArray : FFastArraySerializer {
	// Fields
	struct TArray<struct FSolarShieldItemShopDataEntry> Elements; // Offset: 0x108 | Size: 0x10
	char pad_0x118[0x18]; // Offset: 0x118 | Size: 0x18
};

// Object: ScriptStruct Solarland.SolarShieldItemShopDataEntry
// Inherited Bytes: 0xc | Struct Size: 0x20
struct FSolarShieldItemShopDataEntry : FFastArraySerializerItem {
	// Fields
	struct FVector_NetQuantize Pos; // Offset: 0xc | Size: 0xc
	int32_t Uid; // Offset: 0x18 | Size: 0x4
	char InteractState; // Offset: 0x1c | Size: 0x1
	char pad_0x1D[0x3]; // Offset: 0x1d | Size: 0x3
};

// Object: ScriptStruct Solarland.SolarIntArray
// Inherited Bytes: 0x108 | Struct Size: 0x130
struct FSolarIntArray : FFastArraySerializer {
	// Fields
	struct TArray<struct FSolarIntEntry> Elements; // Offset: 0x108 | Size: 0x10
	char pad_0x118[0x18]; // Offset: 0x118 | Size: 0x18
};

// Object: ScriptStruct Solarland.SolarIntEntry
// Inherited Bytes: 0xc | Struct Size: 0x10
struct FSolarIntEntry : FFastArraySerializerItem {
	// Fields
	int32_t IntProperty; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct Solarland.ItemActorDTRow
// Inherited Bytes: 0x8 | Struct Size: 0xa0
struct FItemActorDTRow : FTableRowBase {
	// Fields
	struct FSoftObjectPath MeshPath; // Offset: 0x8 | Size: 0x18
	struct FSoftObjectPath FXPath; // Offset: 0x20 | Size: 0x18
	struct TArray<struct FSoftObjectPath> MaterialPath; // Offset: 0x38 | Size: 0x10
	struct TArray<struct FSoftObjectPath> OutLineMaterialPath; // Offset: 0x48 | Size: 0x10
	char pad_0x58[0x8]; // Offset: 0x58 | Size: 0x8
	struct FTransform Transform; // Offset: 0x60 | Size: 0x30
	float SpawnOffset; // Offset: 0x90 | Size: 0x4
	float NoneMeshFxOffset; // Offset: 0x94 | Size: 0x4
	char pad_0x98[0x8]; // Offset: 0x98 | Size: 0x8
};

// Object: ScriptStruct Solarland.ItemResReference
// Inherited Bytes: 0x8 | Struct Size: 0x48
struct FItemResReference : FTableRowBase {
	// Fields
	struct FString Description; // Offset: 0x8 | Size: 0x10
	struct FSoftObjectPath Icon; // Offset: 0x18 | Size: 0x18
	struct FSoftObjectPath AbilityBP; // Offset: 0x30 | Size: 0x18
};

// Object: ScriptStruct Solarland.DeathBoxItemData
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FDeathBoxItemData {
	// Fields
	int32_t ItemID; // Offset: 0x0 | Size: 0x4
	int32_t ItemNum; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct Solarland.LoadedItemInfo
// Inherited Bytes: 0x0 | Struct Size: 0xd0
struct FLoadedItemInfo {
	// Fields
	struct FSoftClassPath SClassPath; // Offset: 0x0 | Size: 0x18
	struct FSolarItemData ItemData; // Offset: 0x18 | Size: 0xb8
};

// Object: ScriptStruct Solarland.FinalDropDataCollection
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FFinalDropDataCollection {
	// Fields
	struct TArray<struct FSolarItemData> Datas; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Solarland.OutcomeDataCollection
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FOutcomeDataCollection {
	// Fields
	struct TArray<struct FOutcomeData> Datas; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Solarland.OutcomeData
// Inherited Bytes: 0x0 | Struct Size: 0x1a8
struct FOutcomeData {
	// Fields
	int32_t ID; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct TArray<int32_t> Contents; // Offset: 0x8 | Size: 0x10
	enum class ESpawnStage SpawnStage; // Offset: 0x18 | Size: 0x1
	enum class EOutcomeType OutcomeType; // Offset: 0x19 | Size: 0x1
	char pad_0x1A[0x6]; // Offset: 0x1a | Size: 0x6
	struct TMap<int32_t, int32_t> OutcomePools; // Offset: 0x20 | Size: 0x50
	struct TMap<int32_t, int32_t> OutcomeDynamicWeights; // Offset: 0x70 | Size: 0x50
	struct TMap<int32_t, int32_t> OutcomeSubWeights; // Offset: 0xc0 | Size: 0x50
	int32_t PoolTotalWeight; // Offset: 0x110 | Size: 0x4
	int32_t PoolOutcomeID; // Offset: 0x114 | Size: 0x4
	int32_t MaxTimes; // Offset: 0x118 | Size: 0x4
	int32_t MinTimes; // Offset: 0x11c | Size: 0x4
	int32_t SpawnerID; // Offset: 0x120 | Size: 0x4
	int32_t NetSetTimes; // Offset: 0x124 | Size: 0x4
	int32_t DropedTimes; // Offset: 0x128 | Size: 0x4
	char pad_0x12C[0x4]; // Offset: 0x12c | Size: 0x4
	struct TMap<int32_t, struct FOutcomeContentData> ContentDatas; // Offset: 0x130 | Size: 0x50
	bool IsValid; // Offset: 0x180 | Size: 0x1
	char pad_0x181[0x3]; // Offset: 0x181 | Size: 0x3
	int32_t GlobalDropTimes; // Offset: 0x184 | Size: 0x4
	struct TArray<struct FOutcomeTypeLimitData> LimitTypeDatas; // Offset: 0x188 | Size: 0x10
	struct TArray<struct FOutcomeIDLimitData> LimitIDDatas; // Offset: 0x198 | Size: 0x10
};

// Object: ScriptStruct Solarland.OutcomeIDLimitData
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FOutcomeIDLimitData {
	// Fields
	struct TArray<int32_t> LimitIDs; // Offset: 0x0 | Size: 0x10
	int32_t MinTimes; // Offset: 0x10 | Size: 0x4
	int32_t MaxTimes; // Offset: 0x14 | Size: 0x4
	int32_t CurrDropTimes; // Offset: 0x18 | Size: 0x4
	char pad_0x1C[0x4]; // Offset: 0x1c | Size: 0x4
};

// Object: ScriptStruct Solarland.OutcomeTypeLimitData
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FOutcomeTypeLimitData {
	// Fields
	enum class EItemType LimitType; // Offset: 0x0 | Size: 0x4
	int32_t MinTimes; // Offset: 0x4 | Size: 0x4
	int32_t MaxTimes; // Offset: 0x8 | Size: 0x4
	int32_t CurrDropTimes; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct Solarland.OutcomeContentData
// Inherited Bytes: 0x0 | Struct Size: 0x38
struct FOutcomeContentData {
	// Fields
	int32_t ID; // Offset: 0x0 | Size: 0x4
	int32_t ItemID; // Offset: 0x4 | Size: 0x4
	int32_t Weight; // Offset: 0x8 | Size: 0x4
	char pad_0xC[0x4]; // Offset: 0xc | Size: 0x4
	struct TArray<int32_t> RandomNums; // Offset: 0x10 | Size: 0x10
	int32_t MaxTimes; // Offset: 0x20 | Size: 0x4
	int32_t MinTimes; // Offset: 0x24 | Size: 0x4
	int32_t RelatedContentID; // Offset: 0x28 | Size: 0x4
	enum class EItemType ItemType; // Offset: 0x2c | Size: 0x4
	int32_t DropedTimes; // Offset: 0x30 | Size: 0x4
	bool IsValid; // Offset: 0x34 | Size: 0x1
	bool IsDeleted; // Offset: 0x35 | Size: 0x1
	char pad_0x36[0x2]; // Offset: 0x36 | Size: 0x2
};

// Object: ScriptStruct Solarland.SimpleDropItemDataCollection
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FSimpleDropItemDataCollection {
	// Fields
	struct TMap<int32_t, int32_t> Datas; // Offset: 0x0 | Size: 0x50
};

// Object: ScriptStruct Solarland.ItemBurstParam
// Inherited Bytes: 0x0 | Struct Size: 0x1c
struct FItemBurstParam {
	// Fields
	float BurstRadius; // Offset: 0x0 | Size: 0x4
	float BurstRadiusRandScale; // Offset: 0x4 | Size: 0x4
	float BurstLocalHeight; // Offset: 0x8 | Size: 0x4
	float BurstEulerAngle; // Offset: 0xc | Size: 0x4
	bool bBurstSplitItem; // Offset: 0x10 | Size: 0x1
	enum class EBurstMethod BurstMethod; // Offset: 0x11 | Size: 0x1
	char pad_0x12[0x2]; // Offset: 0x12 | Size: 0x2
	float RadSafeSlopeToBurstOn; // Offset: 0x14 | Size: 0x4
	float GoldenSpiralMinRadiusSquared; // Offset: 0x18 | Size: 0x4
};

// Object: ScriptStruct Solarland.GlobalOutcomeData
// Inherited Bytes: 0x0 | Struct Size: 0x80
struct FGlobalOutcomeData {
	// Fields
	int32_t ID; // Offset: 0x0 | Size: 0x4
	int32_t SingleMaxTimes; // Offset: 0x4 | Size: 0x4
	int32_t TotalMaxTimes; // Offset: 0x8 | Size: 0x4
	int32_t TotalMinTimes; // Offset: 0xc | Size: 0x4
	int32_t NetSetTimes; // Offset: 0x10 | Size: 0x4
	int32_t DropedTimes; // Offset: 0x14 | Size: 0x4
	struct TMap<int32_t, int32_t> ItemIDNumMap; // Offset: 0x18 | Size: 0x50
	struct TArray<int32_t> AffectedOutcomes; // Offset: 0x68 | Size: 0x10
	bool IsValid; // Offset: 0x78 | Size: 0x1
	char pad_0x79[0x7]; // Offset: 0x79 | Size: 0x7
};

// Object: ScriptStruct Solarland.SolarItemDataArray
// Inherited Bytes: 0x108 | Struct Size: 0x118
struct FSolarItemDataArray : FFastArraySerializer {
	// Fields
	struct TArray<struct FSolarItemData> ItemDatas; // Offset: 0x108 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarItemSpawnerArray
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FSolarItemSpawnerArray {
	// Fields
	struct TArray<struct ASolarItemSpawner*> ItemSpawnerArray; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarVehicleData
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FSolarVehicleData {
	// Fields
	int32_t VehicleID; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct FString VehicleBP; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct Solarland.ItemResourceTableRow
// Inherited Bytes: 0x8 | Struct Size: 0x50
struct FItemResourceTableRow : FTableRowBase {
	// Fields
	struct FSoftObjectPath Icon; // Offset: 0x8 | Size: 0x18
	struct FSoftObjectPath BigIcon; // Offset: 0x20 | Size: 0x18
	struct FSoftObjectPath PreviewIcon; // Offset: 0x38 | Size: 0x18
};

// Object: ScriptStruct Solarland.PakDownloadInfo
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FPakDownloadInfo {
	// Fields
	struct FString Filename; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Solarland.ServerInfo
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FServerInfo {
	// Fields
	struct TArray<struct FGateAddress> GateList; // Offset: 0x0 | Size: 0x10
	struct TArray<struct FString> CDNList; // Offset: 0x10 | Size: 0x10
	struct FString LatestBuildVersion; // Offset: 0x20 | Size: 0x10
	struct FString SourceBuildVersion; // Offset: 0x30 | Size: 0x10
	struct FString Name; // Offset: 0x40 | Size: 0x10
};

// Object: ScriptStruct Solarland.GateAddress
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FGateAddress {
	// Fields
	struct FString GateTCPAddr; // Offset: 0x0 | Size: 0x10
	struct FString GateUDPAddr; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarLandscapeListenerConfig
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FSolarLandscapeListenerConfig {
	// Fields
	bool bListenLandscape; // Offset: 0x0 | Size: 0x1
	enum class OnLSModifiedStrategy LSModifiedStrategy; // Offset: 0x1 | Size: 0x1
	bool bAdjustRotate; // Offset: 0x2 | Size: 0x1
	enum class OnLSDestroyStrategy LSDestroyStrategy; // Offset: 0x3 | Size: 0x1
	struct FVector FreeFallBoxExtent; // Offset: 0x4 | Size: 0xc
};

// Object: ScriptStruct Solarland.LayoutDataEntry
// Inherited Bytes: 0x0 | Struct Size: 0x60
struct FLayoutDataEntry {
	// Fields
	struct FName WidgetName; // Offset: 0x0 | Size: 0x8
	struct FLayoutDataElement MobileLayoutData; // Offset: 0x8 | Size: 0x2c
	struct FLayoutDataElement DesktopLayoutData; // Offset: 0x34 | Size: 0x2c
};

// Object: ScriptStruct Solarland.LayoutDataElement
// Inherited Bytes: 0x0 | Struct Size: 0x2c
struct FLayoutDataElement {
	// Fields
	struct FAnchorData LayoutData; // Offset: 0x0 | Size: 0x2c
};

// Object: ScriptStruct Solarland.LeggedVehiclePostPhysicsTickFunction
// Inherited Bytes: 0x28 | Struct Size: 0x30
struct FLeggedVehiclePostPhysicsTickFunction : FTickFunction {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
};

// Object: ScriptStruct Solarland.VehicleFootIKState
// Inherited Bytes: 0x0 | Struct Size: 0x1a0
struct FVehicleFootIKState {
	// Fields
	char pad_0x0[0x1a0]; // Offset: 0x0 | Size: 0x1a0
};

// Object: ScriptStruct Solarland.VehicleIKGroupData
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FVehicleIKGroupData {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
};

// Object: ScriptStruct Solarland.VehicleFootIKData
// Inherited Bytes: 0x0 | Struct Size: 0x64
struct FVehicleFootIKData {
	// Fields
	struct FName LegBoneName; // Offset: 0x0 | Size: 0x8
	struct FName FootBoneName; // Offset: 0x8 | Size: 0x8
	struct FName FootVirtualBoneName; // Offset: 0x10 | Size: 0x8
	struct FName FootVirtualBoneForGround; // Offset: 0x18 | Size: 0x8
	struct FName FootIKBoneName; // Offset: 0x20 | Size: 0x8
	float FootHorizontalOffsetAfterBroken; // Offset: 0x28 | Size: 0x4
	float FootVerticalOffsetAfterBroken; // Offset: 0x2c | Size: 0x4
	float FootUnderWaterOffset; // Offset: 0x30 | Size: 0x4
	float RaiseDustEffectScale; // Offset: 0x34 | Size: 0x4
	float BrokenFootMultiplier; // Offset: 0x38 | Size: 0x4
	struct FVector FootBoneOffset; // Offset: 0x3c | Size: 0xc
	struct FName ParentBone; // Offset: 0x48 | Size: 0x8
	int32_t GroupIndex; // Offset: 0x50 | Size: 0x4
	float StepDistanceMultiplier; // Offset: 0x54 | Size: 0x4
	float StepDistanceMultiplierForVelocity; // Offset: 0x58 | Size: 0x4
	float MinVelocityDegreeForStepDistance; // Offset: 0x5c | Size: 0x4
	float MaxVelocityDegreeForStepDistance; // Offset: 0x60 | Size: 0x4
};

// Object: ScriptStruct Solarland.VehicleLocomotionData
// Inherited Bytes: 0x0 | Struct Size: 0x1c
struct FVehicleLocomotionData {
	// Fields
	float Speed; // Offset: 0x0 | Size: 0x4
	float Acceleration; // Offset: 0x4 | Size: 0x4
	float Deceleration; // Offset: 0x8 | Size: 0x4
	float Friction; // Offset: 0xc | Size: 0x4
	float RotateFriction; // Offset: 0x10 | Size: 0x4
	float RotationSpeed; // Offset: 0x14 | Size: 0x4
	float MovementDegree; // Offset: 0x18 | Size: 0x4
};

// Object: ScriptStruct Solarland.PSAttachElem
// Inherited Bytes: 0x0 | Struct Size: 0x38
struct FPSAttachElem {
	// Fields
	struct FSoftObjectPath ParticleSystemPath; // Offset: 0x0 | Size: 0x18
	struct FName SocketName; // Offset: 0x18 | Size: 0x8
	struct FVector LocationOffset; // Offset: 0x20 | Size: 0xc
	struct FRotator RotationOffset; // Offset: 0x2c | Size: 0xc
};

// Object: ScriptStruct Solarland.CharacterTransformData
// Inherited Bytes: 0x0 | Struct Size: 0x24
struct FCharacterTransformData {
	// Fields
	struct FVector CharacterOffset; // Offset: 0x0 | Size: 0xc
	struct FRotator CharacterRot; // Offset: 0xc | Size: 0xc
	struct FVector CharacterScale; // Offset: 0x18 | Size: 0xc
};

// Object: ScriptStruct Solarland.LootZonePath
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FLootZonePath {
	// Fields
	struct ASolarLootZone* To; // Offset: 0x0 | Size: 0x8
	float MoveCost; // Offset: 0x8 | Size: 0x4
	char pad_0xC[0x4]; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct Solarland.ItemSpawnerGraphNode
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FItemSpawnerGraphNode {
	// Fields
	struct TArray<struct FItemSpawnerPath> Paths; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Solarland.ItemSpawnerPath
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FItemSpawnerPath {
	// Fields
	struct ASolarItemSpawner* To; // Offset: 0x0 | Size: 0x8
	float MoveCost; // Offset: 0x8 | Size: 0x4
	char pad_0xC[0x4]; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarMapElementProperty
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FSolarMapElementProperty {
	// Fields
	struct FString Name; // Offset: 0x0 | Size: 0x10
	enum class ESolarMapElementPropertyType Type; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x7]; // Offset: 0x11 | Size: 0x7
	struct FString Value; // Offset: 0x18 | Size: 0x10
};

// Object: ScriptStruct Solarland.BattlePromptData
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FBattlePromptData {
	// Fields
	char MaxLength; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x7]; // Offset: 0x1 | Size: 0x7
	struct TArray<struct FBattlePromptElem> BattlePromptElemArr; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct Solarland.BattlePromptElem
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FBattlePromptElem {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
	enum class EBattlePromptType RealType; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x3]; // Offset: 0x9 | Size: 0x3
	struct FVector CacheLoc; // Offset: 0xc | Size: 0xc
	float Distance; // Offset: 0x18 | Size: 0x4
	float StartTime; // Offset: 0x1c | Size: 0x4
	float DestroyTime; // Offset: 0x20 | Size: 0x4
	float ReplaceTime; // Offset: 0x24 | Size: 0x4
};

// Object: ScriptStruct Solarland.SkydivingMapDataElem
// Inherited Bytes: 0x0 | Struct Size: 0x34
struct FSkydivingMapDataElem {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
	struct FVector CacheLoc; // Offset: 0x8 | Size: 0xc
	struct FVector2D MapLoc; // Offset: 0x14 | Size: 0x8
	struct FRotator Rotate; // Offset: 0x1c | Size: 0xc
	struct FVector2D Position; // Offset: 0x28 | Size: 0x8
	float RotationOffset; // Offset: 0x30 | Size: 0x4
};

// Object: ScriptStruct Solarland.CircleData
// Inherited Bytes: 0x0 | Struct Size: 0x1c
struct FCircleData {
	// Fields
	struct FVector2D Center; // Offset: 0x0 | Size: 0x8
	float Radius; // Offset: 0x8 | Size: 0x4
	struct FLinearColor LineColor; // Offset: 0xc | Size: 0x10
};

// Object: ScriptStruct Solarland.DotLineData
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FDotLineData {
	// Fields
	struct AActor* StartActor; // Offset: 0x0 | Size: 0x8
	struct AActor* EndActor; // Offset: 0x8 | Size: 0x8
	struct FLinearColor DotLineColor; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct Solarland.MiniMapAirlineData
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FMiniMapAirlineData {
	// Fields
	enum class EMapAirlineType AirlineType; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	struct FVector2D StartPoint; // Offset: 0x4 | Size: 0x8
	struct FVector2D EndPoint; // Offset: 0xc | Size: 0x8
	struct FVector2D RealStartPoint; // Offset: 0x14 | Size: 0x8
	struct FVector2D RealEndPoint; // Offset: 0x1c | Size: 0x8
	struct FVector2D AirlineDir; // Offset: 0x24 | Size: 0x8
	float AirlineLength; // Offset: 0x2c | Size: 0x4
};

// Object: ScriptStruct Solarland.SafeAreaMapInfo
// Inherited Bytes: 0x0 | Struct Size: 0x38
struct FSafeAreaMapInfo {
	// Fields
	struct FVector CurrentLocation; // Offset: 0x0 | Size: 0xc
	float CurrentRadius; // Offset: 0xc | Size: 0x4
	struct FVector NextLocation; // Offset: 0x10 | Size: 0xc
	float NextRadius; // Offset: 0x1c | Size: 0x4
	float BeginShrinkTime; // Offset: 0x20 | Size: 0x4
	float TargetShrinkTime; // Offset: 0x24 | Size: 0x4
	float CurrentConfigRadius; // Offset: 0x28 | Size: 0x4
	struct FVector CurrentAreaBeginLocation; // Offset: 0x2c | Size: 0xc
};

// Object: ScriptStruct Solarland.VehicleData
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FVehicleData {
	// Fields
	float Speed1; // Offset: 0x0 | Size: 0x4
	float Fov1; // Offset: 0x4 | Size: 0x4
	float Speed2; // Offset: 0x8 | Size: 0x4
	float Fov2; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct Solarland.MapData
// Inherited Bytes: 0x0 | Struct Size: 0x3c
struct FMapData {
	// Fields
	struct FVector2D MapTopLeftCoord; // Offset: 0x0 | Size: 0x8
	struct FVector2D MapRightBottomCoord; // Offset: 0x8 | Size: 0x8
	struct FVector2D MapImageSize; // Offset: 0x10 | Size: 0x8
	int32_t MapImage; // Offset: 0x18 | Size: 0x4
	float AirlineZ; // Offset: 0x1c | Size: 0x4
	float HorizonLineZ; // Offset: 0x20 | Size: 0x4
	float TopZ; // Offset: 0x24 | Size: 0x4
	float BottomZ; // Offset: 0x28 | Size: 0x4
	float AverageZ; // Offset: 0x2c | Size: 0x4
	float InitFogZ; // Offset: 0x30 | Size: 0x4
	float TargetFogZ; // Offset: 0x34 | Size: 0x4
	float MapFOV; // Offset: 0x38 | Size: 0x4
};

// Object: ScriptStruct Solarland.MapDarkData
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FMapDarkData {
	// Fields
	int32_t SrcMapID; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct FString SrcImagePath; // Offset: 0x8 | Size: 0x10
	int32_t SizeX; // Offset: 0x18 | Size: 0x4
	int32_t SizeY; // Offset: 0x1c | Size: 0x4
	char pad_0x20[0x10]; // Offset: 0x20 | Size: 0x10
};

// Object: ScriptStruct Solarland.MapSelectPointCellData
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FMapSelectPointCellData {
	// Fields
	bool CellBeSelected; // Offset: 0x0 | Size: 0x1
	enum class EMapCellSelectionAccess SelectionAccess; // Offset: 0x1 | Size: 0x1
	char pad_0x2[0x2]; // Offset: 0x2 | Size: 0x2
	int32_t PlayerId; // Offset: 0x4 | Size: 0x4
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FString CellAddress; // Offset: 0x10 | Size: 0x10
	struct FString SolarPlayerID; // Offset: 0x20 | Size: 0x10
	char pad_0x30[0x20]; // Offset: 0x30 | Size: 0x20
};

// Object: ScriptStruct Solarland.MapSelectPointCellConfig
// Inherited Bytes: 0x0 | Struct Size: 0x14
struct FMapSelectPointCellConfig {
	// Fields
	int32_t X; // Offset: 0x0 | Size: 0x4
	int32_t Y; // Offset: 0x4 | Size: 0x4
	float Width; // Offset: 0x8 | Size: 0x4
	float Height; // Offset: 0xc | Size: 0x4
	float DistanceOfCell; // Offset: 0x10 | Size: 0x4
};

// Object: ScriptStruct Solarland.MapSelectPointCellAddress
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FMapSelectPointCellAddress {
	// Fields
	int32_t X; // Offset: 0x0 | Size: 0x4
	int32_t Y; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct Solarland.MetaAttributeUpdateEvent
// Inherited Bytes: 0x0 | Struct Size: 0x78
struct FMetaAttributeUpdateEvent {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
	int32_t TypeID; // Offset: 0x8 | Size: 0x4
	char pad_0xC[0x4]; // Offset: 0xc | Size: 0x4
	struct USolarAbilitySystemComponent* TargetASC; // Offset: 0x10 | Size: 0x8
	struct USolarMetaAttributeSet* MetaAttributeSet; // Offset: 0x18 | Size: 0x8
	struct FGameplayAttribute MetaAttribute; // Offset: 0x20 | Size: 0x38
	float MetaAttributeValue; // Offset: 0x58 | Size: 0x4
	char pad_0x5C[0x4]; // Offset: 0x5c | Size: 0x4
	struct TArray<struct FMetaAttributeProduceEffect> Effects; // Offset: 0x60 | Size: 0x10
	struct FMetaAttributeUpdateEvent_Character CharacterEventData; // Offset: 0x70 | Size: 0x3
	char pad_0x73[0x5]; // Offset: 0x73 | Size: 0x5
};

// Object: ScriptStruct Solarland.MetaAttributeUpdateEvent_Character
// Inherited Bytes: 0x0 | Struct Size: 0x3
struct FMetaAttributeUpdateEvent_Character {
	// Fields
	bool bHitHead; // Offset: 0x0 | Size: 0x1
	bool bBreakShield; // Offset: 0x1 | Size: 0x1
	bool bDead; // Offset: 0x2 | Size: 0x1
};

// Object: ScriptStruct Solarland.MetaAttributeProduceEffect
// Inherited Bytes: 0x0 | Struct Size: 0x48
struct FMetaAttributeProduceEffect {
	// Fields
	struct USolarAttributeSet* EffectAttributeSet; // Offset: 0x0 | Size: 0x8
	struct FGameplayAttribute EffectAttribute; // Offset: 0x8 | Size: 0x38
	float EffectValue; // Offset: 0x40 | Size: 0x4
	char pad_0x44[0x4]; // Offset: 0x44 | Size: 0x4
};

// Object: ScriptStruct Solarland.MobilePlatformSplinePoint
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FMobilePlatformSplinePoint {
	// Fields
	float DelayTime; // Offset: 0x0 | Size: 0x4
	float Speed; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct Solarland.SmartLinkInstance
// Inherited Bytes: 0x0 | Struct Size: 0x60
struct FSmartLinkInstance {
	// Fields
	enum class ENavLinkType LinkType; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	uint32_t NavLinkUserId; // Offset: 0x4 | Size: 0x4
	struct UNavArea* EnabledAreaClass; // Offset: 0x8 | Size: 0x8
	struct UNavArea* DisabledAreaClass; // Offset: 0x10 | Size: 0x8
	struct FNavAgentSelector SupportedAgents; // Offset: 0x18 | Size: 0x4
	struct FVector LinkRelativeStart; // Offset: 0x1c | Size: 0xc
	struct FVector LinkRelativeEnd; // Offset: 0x28 | Size: 0xc
	enum class ENavLinkDirection LinkDirection; // Offset: 0x34 | Size: 0x1
	char pad_0x35[0x3]; // Offset: 0x35 | Size: 0x3
	struct FVector VaultPoint; // Offset: 0x38 | Size: 0xc
	struct FVector VaultDirect; // Offset: 0x44 | Size: 0xc
	enum class EVaultType VaultAnimate; // Offset: 0x50 | Size: 0x1
	char pad_0x51[0x3]; // Offset: 0x51 | Size: 0x3
	struct FVector VaultLandPoint; // Offset: 0x54 | Size: 0xc
};

// Object: ScriptStruct Solarland.SolarNetMovementState
// Inherited Bytes: 0x0 | Struct Size: 0xa0
struct FSolarNetMovementState {
	// Fields
	char pad_0x0[0xa0]; // Offset: 0x0 | Size: 0xa0
};

// Object: ScriptStruct Solarland.ObjectArray
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FObjectArray {
	// Fields
	struct TArray<struct UObject*> ObjectArray; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Solarland.OBTeamInfo
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FOBTeamInfo {
	// Fields
	char pad_0x0[0x30]; // Offset: 0x0 | Size: 0x30
};

// Object: ScriptStruct Solarland.OBTeammateInfo
// Inherited Bytes: 0x0 | Struct Size: 0x48
struct FOBTeammateInfo {
	// Fields
	char pad_0x0[0x48]; // Offset: 0x0 | Size: 0x48
};

// Object: ScriptStruct Solarland.OperationUIElement
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FOperationUIElement {
	// Fields
	struct FString PanelName; // Offset: 0x0 | Size: 0x10
	struct FString PanelAliasName; // Offset: 0x10 | Size: 0x10
	float CurScale; // Offset: 0x20 | Size: 0x4
	float MinScale; // Offset: 0x24 | Size: 0x4
	float MaxScale; // Offset: 0x28 | Size: 0x4
	float CurOpacity; // Offset: 0x2c | Size: 0x4
	float MinOpacity; // Offset: 0x30 | Size: 0x4
	float MaxOpacity; // Offset: 0x34 | Size: 0x4
	bool bCanHide; // Offset: 0x38 | Size: 0x1
	bool bVisible; // Offset: 0x39 | Size: 0x1
	bool bLockAxisX; // Offset: 0x3a | Size: 0x1
	char pad_0x3B[0x1]; // Offset: 0x3b | Size: 0x1
	float minOffsetY; // Offset: 0x3c | Size: 0x4
	float maxOffsetY; // Offset: 0x40 | Size: 0x4
	bool bCannotChangeScale; // Offset: 0x44 | Size: 0x1
	bool bCannotChangeOpacity; // Offset: 0x45 | Size: 0x1
	bool bVisibleInVehicle; // Offset: 0x46 | Size: 0x1
	char pad_0x47[0x1]; // Offset: 0x47 | Size: 0x1
	struct FVector2D Translation; // Offset: 0x48 | Size: 0x8
};

// Object: ScriptStruct Solarland.PerceivableEAInfluenceConfig
// Inherited Bytes: 0x0 | Struct Size: 0x60
struct FPerceivableEAInfluenceConfig {
	// Fields
	struct TMap<enum class EPerceivableEffectAreaType, float> AreaTypeValueMap; // Offset: 0x0 | Size: 0x50
	float HostileAreaFactor; // Offset: 0x50 | Size: 0x4
	float NeutralAreaFactor; // Offset: 0x54 | Size: 0x4
	float FriendlyAreaFactor; // Offset: 0x58 | Size: 0x4
	char pad_0x5C[0x4]; // Offset: 0x5c | Size: 0x4
};

// Object: ScriptStruct Solarland.PerceivableEffectArea
// Inherited Bytes: 0x0 | Struct Size: 0x2c
struct FPerceivableEffectArea {
	// Fields
	enum class EPerceivableEffectAreaType AreaType; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	struct FVector EffectLocation; // Offset: 0x4 | Size: 0xc
	float EffectRadius; // Offset: 0x10 | Size: 0x4
	struct TWeakObjectPtr<struct AActor> EffectActor; // Offset: 0x14 | Size: 0x8
	struct TWeakObjectPtr<struct AActor> Instigator; // Offset: 0x1c | Size: 0x8
	char pad_0x24[0x8]; // Offset: 0x24 | Size: 0x8
};

// Object: ScriptStruct Solarland.PickupListViewItemData
// Inherited Bytes: 0x0 | Struct Size: 0xd0
struct FPickupListViewItemData {
	// Fields
	struct FSolarItemData ItemData; // Offset: 0x0 | Size: 0xb8
	int32_t Index; // Offset: 0xb8 | Size: 0x4
	char pad_0xBC[0x4]; // Offset: 0xbc | Size: 0x4
	struct AActor* PickActor; // Offset: 0xc0 | Size: 0x8
	enum class EItemType PickActroItemType; // Offset: 0xc8 | Size: 0x4
	char pad_0xCC[0x4]; // Offset: 0xcc | Size: 0x4
};

// Object: ScriptStruct Solarland.ActorArrayMap
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FActorArrayMap {
	// Fields
	struct TMap<int32_t, struct FActorArray> ActorArrayMap; // Offset: 0x0 | Size: 0x50
};

// Object: ScriptStruct Solarland.ActorArray
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FActorArray {
	// Fields
	struct TArray<struct AActor*> ActorArray; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Solarland.ChargingInfo
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FChargingInfo {
	// Fields
	struct TWeakObjectPtr<struct ASolarCharacter> Ch; // Offset: 0x0 | Size: 0x8
	float Time; // Offset: 0x8 | Size: 0x4
	float LastChargeTime; // Offset: 0xc | Size: 0x4
	bool bShowEffect; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x3]; // Offset: 0x11 | Size: 0x3
	float Quantity; // Offset: 0x14 | Size: 0x4
	float Frequency; // Offset: 0x18 | Size: 0x4
	enum class EPileHealingType PileHealingType; // Offset: 0x1c | Size: 0x1
	char pad_0x1D[0x3]; // Offset: 0x1d | Size: 0x3
	float TotalChargeEnergy; // Offset: 0x20 | Size: 0x4
	char pad_0x24[0x4]; // Offset: 0x24 | Size: 0x4
	struct USolarBackpackComponent* BackpackComponent; // Offset: 0x28 | Size: 0x8
};

// Object: ScriptStruct Solarland.ChargingPilePreset
// Inherited Bytes: 0x0 | Struct Size: 0x150
struct FChargingPilePreset {
	// Fields
	struct FSoftObjectPath NormalMeshPath; // Offset: 0x0 | Size: 0x18
	struct FSoftObjectPath BrokenMeshPath; // Offset: 0x18 | Size: 0x18
	struct FSoftObjectPath BrokenMatPath; // Offset: 0x30 | Size: 0x18
	struct FSoftObjectPath RangeRingPath; // Offset: 0x48 | Size: 0x18
	struct FSoftObjectPath RangeRingMatPath; // Offset: 0x60 | Size: 0x18
	struct FSoftObjectPath ChargeCirclePath; // Offset: 0x78 | Size: 0x18
	struct FSoftObjectPath ChargeCircleMatPath; // Offset: 0x90 | Size: 0x18
	struct FSoftObjectPath ChargeParticleEffectPath; // Offset: 0xa8 | Size: 0x18
	struct FSoftObjectPath OutlineMatPath; // Offset: 0xc0 | Size: 0x18
	char pad_0xD8[0x8]; // Offset: 0xd8 | Size: 0x8
	struct FTransform RangeRingTrans; // Offset: 0xe0 | Size: 0x30
	struct FTransform ChargeCircleTrans; // Offset: 0x110 | Size: 0x30
	struct FVector BeamStartPos; // Offset: 0x140 | Size: 0xc
	char pad_0x14C[0x4]; // Offset: 0x14c | Size: 0x4
};

// Object: ScriptStruct Solarland.PlayerActivityHeatRawData
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FPlayerActivityHeatRawData {
	// Fields
	enum class EPlayerActivityHeatType PlayerActivityHeatType; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	float HeatDataTimeStamp; // Offset: 0x4 | Size: 0x4
	float ActivityHeatTimeOffset; // Offset: 0x8 | Size: 0x4
	char pad_0xC[0x4]; // Offset: 0xc | Size: 0x4
	struct FPlayerActivityHeatKillDetail KillDetail; // Offset: 0x10 | Size: 0x40
};

// Object: ScriptStruct Solarland.PlayerActivityHeatKillDetail
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FPlayerActivityHeatKillDetail {
	// Fields
	float KillTime; // Offset: 0x0 | Size: 0x4
	struct FVector VictimPosition; // Offset: 0x4 | Size: 0xc
	struct FString KillerID; // Offset: 0x10 | Size: 0x10
	struct FString VictimID; // Offset: 0x20 | Size: 0x10
	bool IsAbilityKill; // Offset: 0x30 | Size: 0x1
	bool IsScopedKill; // Offset: 0x31 | Size: 0x1
	bool IsVehicleKill; // Offset: 0x32 | Size: 0x1
	bool IsHeadShot; // Offset: 0x33 | Size: 0x1
	bool IsAbilityActivated; // Offset: 0x34 | Size: 0x1
	char pad_0x35[0x3]; // Offset: 0x35 | Size: 0x3
	int32_t weaponid; // Offset: 0x38 | Size: 0x4
	char pad_0x3C[0x4]; // Offset: 0x3c | Size: 0x4
};

// Object: ScriptStruct Solarland.ScreenshotManager
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FScreenshotManager {
	// Fields
	char pad_0x0[0x50]; // Offset: 0x0 | Size: 0x50
};

// Object: ScriptStruct Solarland.BagItemInfo
// Inherited Bytes: 0x0 | Struct Size: 0xc0
struct FBagItemInfo {
	// Fields
	struct FSolarItemData ItemData; // Offset: 0x0 | Size: 0xb8
	int32_t Grade; // Offset: 0xb8 | Size: 0x4
	char pad_0xBC[0x4]; // Offset: 0xbc | Size: 0x4
};

// Object: ScriptStruct Solarland.RadarDelegateHandle
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FRadarDelegateHandle {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
};

// Object: ScriptStruct Solarland.ScannedVehicleDisplayRow
// Inherited Bytes: 0x8 | Struct Size: 0x40
struct FScannedVehicleDisplayRow : FTableRowBase {
	// Fields
	int32_t VehicleID; // Offset: 0x8 | Size: 0x4
	char pad_0xC[0x4]; // Offset: 0xc | Size: 0x4
	struct TSoftObjectPtr<UObject> Icon; // Offset: 0x10 | Size: 0x28
	struct FVector2D IconSize; // Offset: 0x38 | Size: 0x8
};

// Object: ScriptStruct Solarland.PerspectiveActorInfo
// Inherited Bytes: 0x0 | Struct Size: 0x2
struct FPerspectiveActorInfo {
	// Fields
	char pad_0x0[0x2]; // Offset: 0x0 | Size: 0x2
};

// Object: ScriptStruct Solarland.ScannedInfo
// Inherited Bytes: 0x0 | Struct Size: 0x1c
struct FScannedInfo {
	// Fields
	uint32_t UniqueId; // Offset: 0x0 | Size: 0x4
	enum class EActorRegisterType TargetType; // Offset: 0x4 | Size: 0x1
	char pad_0x5[0x3]; // Offset: 0x5 | Size: 0x3
	uint32_t VehicleID; // Offset: 0x8 | Size: 0x4
	struct FVector TargetLocation; // Offset: 0xc | Size: 0xc
	float TargetToward; // Offset: 0x18 | Size: 0x4
};

// Object: ScriptStruct Solarland.StreamingDistanceScaleParam
// Inherited Bytes: 0x8 | Struct Size: 0x18
struct FStreamingDistanceScaleParam : FTableRowBase {
	// Fields
	enum class ESolarGraphicsQualityLevel GraphicsQualityLevel; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x3]; // Offset: 0x9 | Size: 0x3
	float RelativeStreamingDistanceScaleParam; // Offset: 0xc | Size: 0x4
	float RelativeStreamingDistanceScaleParam_PC; // Offset: 0x10 | Size: 0x4
	char pad_0x14[0x4]; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct Solarland.NarrateEventInfoResult
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FNarrateEventInfoResult {
	// Fields
	float EventTime; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct FString NarrateText; // Offset: 0x8 | Size: 0x10
	struct FString AudioAssetPath; // Offset: 0x18 | Size: 0x10
};

// Object: ScriptStruct Solarland.AutoDirectorNodeInfo
// Inherited Bytes: 0x0 | Struct Size: 0x48
struct FAutoDirectorNodeInfo {
	// Fields
	char pad_0x0[0x48]; // Offset: 0x0 | Size: 0x48
};

// Object: ScriptStruct Solarland.AutoDirectorActivityEventScoresInfo
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FAutoDirectorActivityEventScoresInfo {
	// Fields
	float ScoreSum; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct TArray<float> PlayerScores; // Offset: 0x8 | Size: 0x10
	struct TArray<bool> PlayerMakeFollow; // Offset: 0x18 | Size: 0x10
};

// Object: ScriptStruct Solarland.SubGraphInfo
// Inherited Bytes: 0x0 | Struct Size: 0x60
struct FSubGraphInfo {
	// Fields
	char TeamIndex; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x7]; // Offset: 0x1 | Size: 0x7
	struct TSet<struct TWeakObjectPtr<struct ASolarPlayerState>> AllPlayerStates; // Offset: 0x8 | Size: 0x50
	float ScoreSum; // Offset: 0x58 | Size: 0x4
	char pad_0x5C[0x4]; // Offset: 0x5c | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarActorGroupOfReplayCamera
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FSolarActorGroupOfReplayCamera {
	// Fields
	char pad_0x0[0x18]; // Offset: 0x0 | Size: 0x18
};

// Object: ScriptStruct Solarland.ReplayFindSpectateTargetParams
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FReplayFindSpectateTargetParams {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x0 | Size: 0x10
	struct ASolarPlayerState* SuggestTarget; // Offset: 0x10 | Size: 0x8
};

// Object: ScriptStruct Solarland.PlayerHighlightOverview
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FPlayerHighlightOverview {
	// Fields
	int32_t KillNum; // Offset: 0x0 | Size: 0x4
	int32_t AssistNum; // Offset: 0x4 | Size: 0x4
	int32_t Damage; // Offset: 0x8 | Size: 0x4
	char pad_0xC[0x4]; // Offset: 0xc | Size: 0x4
	struct FString PlayerId; // Offset: 0x10 | Size: 0x10
	int32_t RemainPlayers; // Offset: 0x20 | Size: 0x4
	char pad_0x24[0x4]; // Offset: 0x24 | Size: 0x4
};

// Object: ScriptStruct Solarland.FilteredData
// Inherited Bytes: 0x0 | Struct Size: 0x110
struct FFilteredData {
	// Fields
	struct FARFilter Filter; // Offset: 0x0 | Size: 0xe8
	struct TArray<struct FAssetData> Results; // Offset: 0xe8 | Size: 0x10
	struct UObject* ObjectBaseClassType; // Offset: 0xf8 | Size: 0x8
	struct TArray<struct FSavedTagAndValueData> SavedTagAndValueData; // Offset: 0x100 | Size: 0x10
};

// Object: ScriptStruct Solarland.SavedTagAndValueData
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FSavedTagAndValueData {
	// Fields
	struct TMap<struct FName, struct FString> SavedTagsAndValue; // Offset: 0x0 | Size: 0x50
};

// Object: ScriptStruct Solarland.PatfaceShowTime
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FPatfaceShowTime {
	// Fields
	int32_t ID; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	int64_t CanShowTimeStamp; // Offset: 0x8 | Size: 0x8
};

// Object: ScriptStruct Solarland.NeverShowCheckWindow
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FNeverShowCheckWindow {
	// Fields
	int32_t ConfirmID; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct FDateTime Timestamp; // Offset: 0x8 | Size: 0x8
	enum class ENeverShowDuration Duration; // Offset: 0x10 | Size: 0x4
	char pad_0x14[0x4]; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarShieldCreatorEffect
// Inherited Bytes: 0x0 | Struct Size: 0x60
struct FSolarShieldCreatorEffect {
	// Fields
	struct FSoftObjectPath TeammatePath; // Offset: 0x0 | Size: 0x18
	struct FSoftObjectPath EnemyPath; // Offset: 0x18 | Size: 0x18
	struct FTransform RelativeTransform; // Offset: 0x30 | Size: 0x30
};

// Object: ScriptStruct Solarland.SkeletalMeshMergeParams
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FSkeletalMeshMergeParams {
	// Fields
	struct TArray<struct USkeletalMesh*> MeshesToMerge; // Offset: 0x0 | Size: 0x10
	int32_t StripTopLODS; // Offset: 0x10 | Size: 0x4
	char bNeedsCpuAccess : 1; // Offset: 0x14 | Size: 0x1
	char bSkeletonBefore : 1; // Offset: 0x14 | Size: 0x1
	char pad_0x14_2 : 6; // Offset: 0x14 | Size: 0x1
	char pad_0x15[0x3]; // Offset: 0x15 | Size: 0x3
	struct USkeleton* Skeleton; // Offset: 0x18 | Size: 0x8
};

// Object: ScriptStruct Solarland.SkeletalMeshMergeUVTransformMapping_BP
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FSkeletalMeshMergeUVTransformMapping_BP {
	// Fields
	struct TArray<struct FSkeletalMeshMergeUVTransforms_BP> UVTransformsPerMesh; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Solarland.SkeletalMeshMergeUVTransforms_BP
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FSkeletalMeshMergeUVTransforms_BP {
	// Fields
	struct TArray<struct FTransform> UVTransforms; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Solarland.SkeletalMeshMergeSectionMapping_BP
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FSkeletalMeshMergeSectionMapping_BP {
	// Fields
	struct TArray<int32_t> SectionIDs; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarSubClusterGrenadeData
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FSolarSubClusterGrenadeData {
	// Fields
	struct ASolarSkill_ClusterGrenade* SubClusterGrenadeClass; // Offset: 0x0 | Size: 0x8
	float DelaySpawnTime; // Offset: 0x8 | Size: 0x4
	float SpawnTimer; // Offset: 0xc | Size: 0x4
	bool bLaunchSpawnTimer; // Offset: 0x10 | Size: 0x1
	bool bSpawned; // Offset: 0x11 | Size: 0x1
	char pad_0x12[0x6]; // Offset: 0x12 | Size: 0x6
};

// Object: ScriptStruct Solarland.SolarEMPParticleInfo
// Inherited Bytes: 0x0 | Struct Size: 0x80
struct FSolarEMPParticleInfo {
	// Fields
	struct FSoftObjectPath ParticlePathForTeammate; // Offset: 0x0 | Size: 0x18
	struct FSoftObjectPath ParticlePathForEnemy; // Offset: 0x18 | Size: 0x18
	struct FTransform RelativeTransform; // Offset: 0x30 | Size: 0x30
	bool bAttachMode; // Offset: 0x60 | Size: 0x1
	char pad_0x61[0x3]; // Offset: 0x61 | Size: 0x3
	struct FName AttachSocketName; // Offset: 0x64 | Size: 0x8
	enum class EAttachLocation AttachLocationType; // Offset: 0x6c | Size: 0x1
	bool bAutoDestroy; // Offset: 0x6d | Size: 0x1
	char pad_0x6E[0x2]; // Offset: 0x6e | Size: 0x2
	float Duration; // Offset: 0x70 | Size: 0x4
	enum class EPSCPoolMethod PoolMode; // Offset: 0x74 | Size: 0x1
	char pad_0x75[0xb]; // Offset: 0x75 | Size: 0xb
};

// Object: ScriptStruct Solarland.SolarDamageShapeData
// Inherited Bytes: 0x0 | Struct Size: 0x90
struct FSolarDamageShapeData {
	// Fields
	enum class ESolarDamageShapeType ShapeType; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	struct FVector ShapeExtent; // Offset: 0x4 | Size: 0xc
	struct FTransform DamageRelativeTransform; // Offset: 0x10 | Size: 0x30
	struct FSolarEffectData EffectData; // Offset: 0x40 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarEffectData
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FSolarEffectData {
	// Fields
	struct FSoftObjectPath Path; // Offset: 0x0 | Size: 0x18
	char pad_0x18[0x8]; // Offset: 0x18 | Size: 0x8
	struct FTransform RelativeTransform; // Offset: 0x20 | Size: 0x30
};

// Object: ScriptStruct Solarland.SolarProjectileCustomBounceData
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FSolarProjectileCustomBounceData {
	// Fields
	float CanBounceAngle; // Offset: 0x0 | Size: 0x4
	int32_t MaxBounceCount; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarSkillProjectileData
// Inherited Bytes: 0x0 | Struct Size: 0xd0
struct FSolarSkillProjectileData {
	// Fields
	float PredictTime; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct TMap<enum class ESlateDetailMode, float> PredictSimFrequencyMap; // Offset: 0x8 | Size: 0x50
	float PredictRadius; // Offset: 0x58 | Size: 0x4
	float PredictSpeed; // Offset: 0x5c | Size: 0x4
	float PredictGravityZ; // Offset: 0x60 | Size: 0x4
	float GravityScale; // Offset: 0x64 | Size: 0x4
	float PredictAngle; // Offset: 0x68 | Size: 0x4
	struct FName StartSocketName; // Offset: 0x6c | Size: 0x8
	struct FVector StartSocketOffset; // Offset: 0x74 | Size: 0xc
	bool bDisplayHoldModel; // Offset: 0x80 | Size: 0x1
	char pad_0x81[0x3]; // Offset: 0x81 | Size: 0x3
	struct FName HoldSocketName; // Offset: 0x84 | Size: 0x8
	char pad_0x8C[0x4]; // Offset: 0x8c | Size: 0x4
	struct FTransform HoldModelTransform; // Offset: 0x90 | Size: 0x30
	int32_t count; // Offset: 0xc0 | Size: 0x4
	float HorizontalOffsetAngle; // Offset: 0xc4 | Size: 0x4
	char pad_0xC8[0x8]; // Offset: 0xc8 | Size: 0x8
};

// Object: ScriptStruct Solarland.SolarSurroundLightningConfig
// Inherited Bytes: 0x0 | Struct Size: 0x98
struct FSolarSurroundLightningConfig {
	// Fields
	struct FVector ParticleDefaultScale; // Offset: 0x0 | Size: 0xc
	char pad_0xC[0x4]; // Offset: 0xc | Size: 0x4
	struct FRuntimeFloatCurve ParticleScaleByDistanceCurve; // Offset: 0x10 | Size: 0x88
};

// Object: ScriptStruct Solarland.BuffDurationInfo
// Inherited Bytes: 0x0 | Struct Size: 0x60
struct FBuffDurationInfo {
	// Fields
	char pad_0x0[0x60]; // Offset: 0x0 | Size: 0x60
};

// Object: ScriptStruct Solarland.SolarSkinnedSkeletalMesh
// Inherited Bytes: 0x8 | Struct Size: 0x70
struct FSolarSkinnedSkeletalMesh : FSolarSkinnedAsset {
	// Fields
	struct FSoftObjectPath DefaultSkinnedSkeletalMesh; // Offset: 0x8 | Size: 0x18
	struct TMap<int32_t, struct FSoftObjectPath> SkinnedSkeletalMeshes; // Offset: 0x20 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarSkinnedStaticMesh
// Inherited Bytes: 0x8 | Struct Size: 0x70
struct FSolarSkinnedStaticMesh : FSolarSkinnedAsset {
	// Fields
	struct FSoftObjectPath DefaultSkinnedStaticMesh; // Offset: 0x8 | Size: 0x18
	struct TMap<int32_t, struct FSoftObjectPath> SkinnedStaticMeshes; // Offset: 0x20 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarSoftObjectReference
// Inherited Bytes: 0x8 | Struct Size: 0x20
struct FSolarSoftObjectReference : FTableRowBase {
	// Fields
	struct FSoftObjectPath ObjectReference; // Offset: 0x8 | Size: 0x18
};

// Object: ScriptStruct Solarland.SolarSummonPreview
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FSolarSummonPreview {
	// Fields
	struct UStreamableRenderAsset* Mesh; // Offset: 0x0 | Size: 0x8
	struct UMaterialInterface* ValidMaterial; // Offset: 0x8 | Size: 0x8
	struct UMaterialInterface* InvalidMaterial; // Offset: 0x10 | Size: 0x8
};

// Object: ScriptStruct Solarland.SolarSummonCondition
// Inherited Bytes: 0x0 | Struct Size: 0x80
struct FSolarSummonCondition {
	// Fields
	struct TArray<enum class EObjectTypeQuery> SurfaceCheckTypes; // Offset: 0x0 | Size: 0x10
	struct TArray<enum class EPhysicalSurface> ForbiddenSurfaces; // Offset: 0x10 | Size: 0x10
	struct TArray<struct AActor*> ForbiddenSurfaceClasses; // Offset: 0x20 | Size: 0x10
	bool bUseChannelTest; // Offset: 0x30 | Size: 0x1
	enum class ECollisionChannel TestCollisionChannel; // Offset: 0x31 | Size: 0x1
	char pad_0x32[0x6]; // Offset: 0x32 | Size: 0x6
	struct TArray<enum class EObjectTypeQuery> CollisionCheckTypes; // Offset: 0x38 | Size: 0x10
	struct TArray<struct AActor*> CollisionCheckIgnoreClasses; // Offset: 0x48 | Size: 0x10
	float MaxPlaceableAngle; // Offset: 0x58 | Size: 0x4
	bool bDisplayOverThanPlaceableAngle; // Offset: 0x5c | Size: 0x1
	char pad_0x5D[0x3]; // Offset: 0x5d | Size: 0x3
	struct FVector CheckSize; // Offset: 0x60 | Size: 0xc
	float CollisionToGroundDistance; // Offset: 0x6c | Size: 0x4
	bool bEnableSummonInRoom; // Offset: 0x70 | Size: 0x1
	char pad_0x71[0x3]; // Offset: 0x71 | Size: 0x3
	float RoomCheckHalfHeight; // Offset: 0x74 | Size: 0x4
	bool bKeepPreviewUpright; // Offset: 0x78 | Size: 0x1
	bool bIgnorePlacementCollision; // Offset: 0x79 | Size: 0x1
	char pad_0x7A[0x6]; // Offset: 0x7a | Size: 0x6
};

// Object: ScriptStruct Solarland.SolarSummonTimer
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FSolarSummonTimer {
	// Fields
	bool bEnable; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	float Timer; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct Solarland.InvisibleZoneParticleInfo
// Inherited Bytes: 0x0 | Struct Size: 0x70
struct FInvisibleZoneParticleInfo {
	// Fields
	struct FSoftObjectPath ParticlePathForTeammate; // Offset: 0x0 | Size: 0x18
	struct FSoftObjectPath ParticlePathForEnemy; // Offset: 0x18 | Size: 0x18
	struct FTransform RelativeTransform; // Offset: 0x30 | Size: 0x30
	bool bAttach; // Offset: 0x60 | Size: 0x1
	char pad_0x61[0xf]; // Offset: 0x61 | Size: 0xf
};

// Object: ScriptStruct Solarland.TowerParticleInfo
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FTowerParticleInfo {
	// Fields
	struct FSoftObjectPath ParticlePath; // Offset: 0x0 | Size: 0x18
	char pad_0x18[0x8]; // Offset: 0x18 | Size: 0x8
	struct FTransform RelativeTransform; // Offset: 0x20 | Size: 0x30
};

// Object: ScriptStruct Solarland.TowerPadEffect
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FTowerPadEffect {
	// Fields
	struct UParticleSystem* Particle; // Offset: 0x0 | Size: 0x8
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FTransform Transform; // Offset: 0x10 | Size: 0x30
	struct UParticleSystemComponent* Handle; // Offset: 0x40 | Size: 0x8
	char pad_0x48[0x8]; // Offset: 0x48 | Size: 0x8
};

// Object: ScriptStruct Solarland.SolarSyncMoveMessageParams
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FSolarSyncMoveMessageParams {
	// Fields
	float Value; // Offset: 0x0 | Size: 0x4
	struct FVector Location; // Offset: 0x4 | Size: 0xc
};

// Object: ScriptStruct Solarland.SolarLocaleInfo
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FSolarLocaleInfo {
	// Fields
	struct FString Language; // Offset: 0x0 | Size: 0x10
	struct FString Region; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarTablesDataBase
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FSolarTablesDataBase {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarTables_AccountFixedExp
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_AccountFixedExp : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_AccountFixedExp> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_AccountFixedExp
// Inherited Bytes: 0x10 | Struct Size: 0x18
struct FSolarTablesData_AccountFixedExp : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	int32_t Exp; // Offset: 0x10 | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarTables_AccountFlag
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_AccountFlag : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_AccountFlag> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_AccountFlag
// Inherited Bytes: 0x10 | Struct Size: 0x38
struct FSolarTablesData_AccountFlag : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	int32_t FlagType; // Offset: 0x10 | Size: 0x4
	struct FString FlagIcon; // Offset: 0x18 | Size: 0x10
	struct FString StateName; // Offset: 0x28 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarTables_Achievement
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_Achievement : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_Achievement> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_Achievement
// Inherited Bytes: 0x10 | Struct Size: 0x80
struct FSolarTablesData_Achievement : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	int32_t Order; // Offset: 0x10 | Size: 0x4
	struct FSolarTablesLocalText AchieveName; // Offset: 0x14 | Size: 0x4
	int32_t AchieveTab; // Offset: 0x18 | Size: 0x4
	int32_t AchieveType; // Offset: 0x1c | Size: 0x4
	int32_t AchieveScore; // Offset: 0x20 | Size: 0x4
	struct TArray<int32_t> AwardList; // Offset: 0x28 | Size: 0x10
	struct FString AchieveIcon; // Offset: 0x38 | Size: 0x10
	struct FString AchieveIconS; // Offset: 0x48 | Size: 0x10
	int32_t AchieveTask; // Offset: 0x58 | Size: 0x4
	char pad_0x5C[0x4]; // Offset: 0x5c | Size: 0x4
	struct TArray<int32_t> AchieveTV; // Offset: 0x60 | Size: 0x10
	int32_t AchieveTT; // Offset: 0x70 | Size: 0x4
	int32_t ReportType; // Offset: 0x74 | Size: 0x4
	struct FSolarTablesLocalText AchieveTC; // Offset: 0x78 | Size: 0x4
	char pad_0x7C[0x4]; // Offset: 0x7c | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarTablesLocalText
// Inherited Bytes: 0x0 | Struct Size: 0x4
struct FSolarTablesLocalText {
	// Fields
	int32_t ID; // Offset: 0x0 | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarTables_Airline
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_Airline : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_Airline> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_Airline
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTablesData_Airline : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	struct TArray<float> AirlineCoordinateA; // Offset: 0x10 | Size: 0x10
	struct TArray<float> RealPointA; // Offset: 0x20 | Size: 0x10
	struct TArray<float> AirlineCoordinateB; // Offset: 0x30 | Size: 0x10
	struct TArray<float> RealPointB; // Offset: 0x40 | Size: 0x10
	int32_t UseGameMode; // Offset: 0x50 | Size: 0x4
	int32_t MapID; // Offset: 0x54 | Size: 0x4
	float AirlineAltitude; // Offset: 0x58 | Size: 0x4
	float CapsuleSpeed; // Offset: 0x5c | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarTables_ArmorProperty
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_ArmorProperty : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_ArmorProperty> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_ArmorProperty
// Inherited Bytes: 0x10 | Struct Size: 0x90
struct FSolarTablesData_ArmorProperty : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	struct FSolarTablesLocalText Name; // Offset: 0x10 | Size: 0x4
	struct FString Icon; // Offset: 0x18 | Size: 0x10
	struct FSolarTablesLocalText Info; // Offset: 0x28 | Size: 0x4
	int32_t Quality; // Offset: 0x2c | Size: 0x4
	int32_t ItemType; // Offset: 0x30 | Size: 0x4
	bool IfReplace; // Offset: 0x34 | Size: 0x1
	char pad_0x35[0x3]; // Offset: 0x35 | Size: 0x3
	int32_t Pile; // Offset: 0x38 | Size: 0x4
	char pad_0x3C[0x4]; // Offset: 0x3c | Size: 0x4
	struct FString AbilityBP; // Offset: 0x40 | Size: 0x10
	struct FString ItemBP; // Offset: 0x50 | Size: 0x10
	struct FString AudioEventName; // Offset: 0x60 | Size: 0x10
	bool UseOnPickup; // Offset: 0x70 | Size: 0x1
	char pad_0x71[0x3]; // Offset: 0x71 | Size: 0x3
	float MaxValue; // Offset: 0x74 | Size: 0x4
	float RecoverySpeed; // Offset: 0x78 | Size: 0x4
	float EnergyCost; // Offset: 0x7c | Size: 0x4
	float MaterialCost; // Offset: 0x80 | Size: 0x4
	float MinMaterialCost; // Offset: 0x84 | Size: 0x4
	int32_t ArmorWorth; // Offset: 0x88 | Size: 0x4
	char pad_0x8C[0x4]; // Offset: 0x8c | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarTables_Armory
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_Armory : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_Armory> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_Armory
// Inherited Bytes: 0x10 | Struct Size: 0x80
struct FSolarTablesData_Armory : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	int32_t WeaponType; // Offset: 0x10 | Size: 0x4
	int32_t WeaponDescription; // Offset: 0x14 | Size: 0x4
	int32_t SkillName; // Offset: 0x18 | Size: 0x4
	int32_t SkillDescription; // Offset: 0x1c | Size: 0x4
	struct FString UrlName; // Offset: 0x20 | Size: 0x10
	struct FString WeaponMovie; // Offset: 0x30 | Size: 0x10
	struct FString WeaponConfig; // Offset: 0x40 | Size: 0x10
	int32_t WeaponUnlockLevel; // Offset: 0x50 | Size: 0x4
	int32_t WeaponDamage; // Offset: 0x54 | Size: 0x4
	int32_t WeaponRateOfFire; // Offset: 0x58 | Size: 0x4
	int32_t WeaponRecoil; // Offset: 0x5c | Size: 0x4
	int32_t WeaponSpread; // Offset: 0x60 | Size: 0x4
	int32_t WeaponRange; // Offset: 0x64 | Size: 0x4
	int32_t WeaponMobility; // Offset: 0x68 | Size: 0x4
	struct FString SilhouetteIcon; // Offset: 0x70 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarTables_AutoDirector
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_AutoDirector : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_AutoDirector> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_AutoDirector
// Inherited Bytes: 0x10 | Struct Size: 0x30
struct FSolarTablesData_AutoDirector : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	int32_t SpectateAreaRadius; // Offset: 0x10 | Size: 0x4
	int32_t CollectScoreWindow; // Offset: 0x14 | Size: 0x4
	float MinFocusTime; // Offset: 0x18 | Size: 0x4
	float MaxFocusTime; // Offset: 0x1c | Size: 0x4
	float NewCutThreshold; // Offset: 0x20 | Size: 0x4
	float PreFreeCameraTime; // Offset: 0x24 | Size: 0x4
	int32_t AutoDirectorMinEnableTime; // Offset: 0x28 | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarTables_AutoDirectorActivityScore
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_AutoDirectorActivityScore : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_AutoDirectorActivityScore> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_AutoDirectorActivityScore
// Inherited Bytes: 0x10 | Struct Size: 0x18
struct FSolarTablesData_AutoDirectorActivityScore : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	float Score; // Offset: 0x10 | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarTables_BackpackProperty
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_BackpackProperty : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_BackpackProperty> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_BackpackProperty
// Inherited Bytes: 0x10 | Struct Size: 0x80
struct FSolarTablesData_BackpackProperty : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	struct FSolarTablesLocalText Name; // Offset: 0x10 | Size: 0x4
	struct FString Icon; // Offset: 0x18 | Size: 0x10
	struct FSolarTablesLocalText Info; // Offset: 0x28 | Size: 0x4
	int32_t Quality; // Offset: 0x2c | Size: 0x4
	int32_t ItemClass; // Offset: 0x30 | Size: 0x4
	int32_t ItemType; // Offset: 0x34 | Size: 0x4
	bool ShowInStorage; // Offset: 0x38 | Size: 0x1
	bool IfUse; // Offset: 0x39 | Size: 0x1
	bool IfRecycle; // Offset: 0x3a | Size: 0x1
	enum class ESolarTablesEnum_StackType StackType; // Offset: 0x3b | Size: 0x1
	char pad_0x3C[0x4]; // Offset: 0x3c | Size: 0x4
	struct TArray<int32_t> JumpLink; // Offset: 0x40 | Size: 0x10
	struct FString BackpackMeshPath; // Offset: 0x50 | Size: 0x10
	struct FString PreviewBpPath; // Offset: 0x60 | Size: 0x10
	int32_t StartFrame; // Offset: 0x70 | Size: 0x4
	int32_t EndFrame; // Offset: 0x74 | Size: 0x4
	float Length; // Offset: 0x78 | Size: 0x4
	char pad_0x7C[0x4]; // Offset: 0x7c | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarTables_BackpackTrailProperty
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_BackpackTrailProperty : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_BackpackTrailProperty> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_BackpackTrailProperty
// Inherited Bytes: 0x10 | Struct Size: 0x70
struct FSolarTablesData_BackpackTrailProperty : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	struct FSolarTablesLocalText Name; // Offset: 0x10 | Size: 0x4
	struct FString Icon; // Offset: 0x18 | Size: 0x10
	struct FSolarTablesLocalText Info; // Offset: 0x28 | Size: 0x4
	int32_t Quality; // Offset: 0x2c | Size: 0x4
	int32_t ItemClass; // Offset: 0x30 | Size: 0x4
	int32_t ItemType; // Offset: 0x34 | Size: 0x4
	bool ShowInStorage; // Offset: 0x38 | Size: 0x1
	bool IfUse; // Offset: 0x39 | Size: 0x1
	bool IfRecycle; // Offset: 0x3a | Size: 0x1
	enum class ESolarTablesEnum_StackType StackType; // Offset: 0x3b | Size: 0x1
	char pad_0x3C[0x4]; // Offset: 0x3c | Size: 0x4
	struct TArray<int32_t> JumpLink; // Offset: 0x40 | Size: 0x10
	struct FString PreviewTrailPath; // Offset: 0x50 | Size: 0x10
	struct FString AssemblingId; // Offset: 0x60 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarTables_BattleEndRankSettlement
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_BattleEndRankSettlement : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_BattleEndRankSettlement> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_BattleEndRankSettlement
// Inherited Bytes: 0x10 | Struct Size: 0x28
struct FSolarTablesData_BattleEndRankSettlement : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	int32_t RuleID; // Offset: 0x10 | Size: 0x4
	int32_t RealPerson; // Offset: 0x14 | Size: 0x4
	struct TArray<int32_t> ItemDrop; // Offset: 0x18 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarTables_BattleRoyaleMode
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_BattleRoyaleMode : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_BattleRoyaleMode> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_BattleRoyaleMode
// Inherited Bytes: 0x10 | Struct Size: 0x48
struct FSolarTablesData_BattleRoyaleMode : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	struct TArray<int32_t> GlobalOutcomes; // Offset: 0x10 | Size: 0x10
	int32_t BattleMap; // Offset: 0x20 | Size: 0x4
	int32_t ReadyMap; // Offset: 0x24 | Size: 0x4
	float ReadyStateTime; // Offset: 0x28 | Size: 0x4
	int32_t StartTime; // Offset: 0x2c | Size: 0x4
	float EenTime; // Offset: 0x30 | Size: 0x4
	int32_t CharacterEXPCoefficient; // Offset: 0x34 | Size: 0x4
	struct TArray<struct FString> EventSets; // Offset: 0x38 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarTables_BattleUpgradeContent
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_BattleUpgradeContent : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_BattleUpgradeContent> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_BattleUpgradeContent
// Inherited Bytes: 0x10 | Struct Size: 0x38
struct FSolarTablesData_BattleUpgradeContent : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	struct TArray<int32_t> ModelID; // Offset: 0x10 | Size: 0x10
	int32_t Grade; // Offset: 0x20 | Size: 0x4
	struct TArray<int32_t> UpgradeContent; // Offset: 0x28 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarTables_BattleUpgradeEffect
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_BattleUpgradeEffect : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_BattleUpgradeEffect> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_BattleUpgradeEffect
// Inherited Bytes: 0x10 | Struct Size: 0x20
struct FSolarTablesData_BattleUpgradeEffect : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	enum class ESolarTablesEnum_BattleUpgradeEffectType Effect; // Offset: 0x10 | Size: 0x1
	int32_t EffectValue; // Offset: 0x14 | Size: 0x4
	int32_t StackingTimes; // Offset: 0x18 | Size: 0x4
	char pad_0x1D[0x3]; // Offset: 0x1d | Size: 0x3
};

// Object: ScriptStruct Solarland.SolarTables_BattleUpgradeEffectPool
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_BattleUpgradeEffectPool : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_BattleUpgradeEffectPool> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_BattleUpgradeEffectPool
// Inherited Bytes: 0x10 | Struct Size: 0x20
struct FSolarTablesData_BattleUpgradeEffectPool : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	struct TArray<int32_t> Pool; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarTables_Behavior
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_Behavior : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_Behavior> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_Behavior
// Inherited Bytes: 0x10 | Struct Size: 0x30
struct FSolarTablesData_Behavior : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	enum class ESolarTablesEnum_BehaviorType BehaviorType; // Offset: 0x10 | Size: 0x1
	int32_t CharacterGetExp; // Offset: 0x14 | Size: 0x4
	int32_t WeaponGetExp; // Offset: 0x18 | Size: 0x4
	int32_t WeaponExp_2; // Offset: 0x1c | Size: 0x4
	int32_t WeaponExp_3; // Offset: 0x20 | Size: 0x4
	int32_t WeaponExp_5; // Offset: 0x24 | Size: 0x4
	struct FSolarTablesLocalText CharaGetExpText; // Offset: 0x28 | Size: 0x4
	int32_t WeaponGetExpText; // Offset: 0x2c | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarTables_BpAward
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_BpAward : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_BpAward> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_BpAward
// Inherited Bytes: 0x10 | Struct Size: 0x48
struct FSolarTablesData_BpAward : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	int32_t BpID; // Offset: 0x10 | Size: 0x4
	int32_t Level; // Offset: 0x14 | Size: 0x4
	int32_t Exp; // Offset: 0x18 | Size: 0x4
	int32_t UpdateValue; // Offset: 0x1c | Size: 0x4
	struct TArray<int32_t> FreeAward; // Offset: 0x20 | Size: 0x10
	struct TArray<int32_t> PayAward; // Offset: 0x30 | Size: 0x10
	bool UnlockExtraTask; // Offset: 0x40 | Size: 0x1
	bool BuyLevel; // Offset: 0x41 | Size: 0x1
	bool LoopReward; // Offset: 0x42 | Size: 0x1
	char pad_0x47[0x1]; // Offset: 0x47 | Size: 0x1
};

// Object: ScriptStruct Solarland.SolarTables_CapsuleProperty
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_CapsuleProperty : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_CapsuleProperty> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_CapsuleProperty
// Inherited Bytes: 0x10 | Struct Size: 0x70
struct FSolarTablesData_CapsuleProperty : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	struct FSolarTablesLocalText Name; // Offset: 0x10 | Size: 0x4
	struct FString Icon; // Offset: 0x18 | Size: 0x10
	struct FSolarTablesLocalText Info; // Offset: 0x28 | Size: 0x4
	int32_t Quality; // Offset: 0x2c | Size: 0x4
	int32_t ItemClass; // Offset: 0x30 | Size: 0x4
	int32_t ItemType; // Offset: 0x34 | Size: 0x4
	bool ShowInStorage; // Offset: 0x38 | Size: 0x1
	bool IfUse; // Offset: 0x39 | Size: 0x1
	bool IfRecycle; // Offset: 0x3a | Size: 0x1
	enum class ESolarTablesEnum_StackType StackType; // Offset: 0x3b | Size: 0x1
	char pad_0x3C[0x4]; // Offset: 0x3c | Size: 0x4
	struct TArray<int32_t> JumpLink; // Offset: 0x40 | Size: 0x10
	struct FString CapsuleBPPath; // Offset: 0x50 | Size: 0x10
	struct FString PreviewBpPath; // Offset: 0x60 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarTables_CaseToggleAlphabet
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_CaseToggleAlphabet : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_CaseToggleAlphabet> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_CaseToggleAlphabet
// Inherited Bytes: 0x10 | Struct Size: 0x98
struct FSolarTablesData_CaseToggleAlphabet : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	bool IsLower; // Offset: 0x10 | Size: 0x1
	char pad_0x15[0x3]; // Offset: 0x15 | Size: 0x3
	struct FString de; // Offset: 0x18 | Size: 0x10
	struct FString fr; // Offset: 0x28 | Size: 0x10
	struct FString es; // Offset: 0x38 | Size: 0x10
	struct FString pt; // Offset: 0x48 | Size: 0x10
	struct FString it; // Offset: 0x58 | Size: 0x10
	struct FString pl; // Offset: 0x68 | Size: 0x10
	struct FString tr; // Offset: 0x78 | Size: 0x10
	struct FString ru; // Offset: 0x88 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarTables_CharacterAbility
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_CharacterAbility : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_CharacterAbility> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_CharacterAbility
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTablesData_CharacterAbility : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	int32_t CharacterId; // Offset: 0x10 | Size: 0x4
	struct FString DataAssetsPath; // Offset: 0x18 | Size: 0x10
	struct FSolarTablesLocalText Name; // Offset: 0x28 | Size: 0x4
	struct FSolarTablesLocalText Info; // Offset: 0x2c | Size: 0x4
	int32_t DataID; // Offset: 0x30 | Size: 0x4
	char pad_0x34[0x4]; // Offset: 0x34 | Size: 0x4
	struct FString AbilityBP; // Offset: 0x38 | Size: 0x10
	struct FString Icon; // Offset: 0x48 | Size: 0x10
	int32_t Data; // Offset: 0x58 | Size: 0x4
	bool IfActive; // Offset: 0x5c | Size: 0x1
	char pad_0x5D[0x3]; // Offset: 0x5d | Size: 0x3
};

// Object: ScriptStruct Solarland.SolarTables_CharacterPassiveAbility
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_CharacterPassiveAbility : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_CharacterPassiveAbility> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_CharacterPassiveAbility
// Inherited Bytes: 0x10 | Struct Size: 0x20
struct FSolarTablesData_CharacterPassiveAbility : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	struct FString DataAssetsPath; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarTables_CharacterVoiceover
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_CharacterVoiceover : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_CharacterVoiceover> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_CharacterVoiceover
// Inherited Bytes: 0x10 | Struct Size: 0x38
struct FSolarTablesData_CharacterVoiceover : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	int32_t QuickVoiceID; // Offset: 0x10 | Size: 0x4
	int32_t CharacterId; // Offset: 0x14 | Size: 0x4
	int32_t SkinId; // Offset: 0x18 | Size: 0x4
	struct FString AudioEventName; // Offset: 0x20 | Size: 0x10
	int32_t LocalizationID; // Offset: 0x30 | Size: 0x4
	char pad_0x34[0x4]; // Offset: 0x34 | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarTables_Chest
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_Chest : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_Chest> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_Chest
// Inherited Bytes: 0x10 | Struct Size: 0x88
struct FSolarTablesData_Chest : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	struct FSolarTablesLocalText Name; // Offset: 0x10 | Size: 0x4
	struct FString Icon; // Offset: 0x18 | Size: 0x10
	struct FSolarTablesLocalText Info; // Offset: 0x28 | Size: 0x4
	int32_t Quality; // Offset: 0x2c | Size: 0x4
	int32_t ItemType; // Offset: 0x30 | Size: 0x4
	bool IfReplace; // Offset: 0x34 | Size: 0x1
	char pad_0x35[0x3]; // Offset: 0x35 | Size: 0x3
	int32_t Pile; // Offset: 0x38 | Size: 0x4
	char pad_0x3C[0x4]; // Offset: 0x3c | Size: 0x4
	struct FString AbilityBP; // Offset: 0x40 | Size: 0x10
	struct FString ItemBP; // Offset: 0x50 | Size: 0x10
	struct FString AudioEventName; // Offset: 0x60 | Size: 0x10
	bool UseOnPickup; // Offset: 0x70 | Size: 0x1
	char pad_0x71[0x3]; // Offset: 0x71 | Size: 0x3
	int32_t openType; // Offset: 0x74 | Size: 0x4
	int32_t CostQuantity; // Offset: 0x78 | Size: 0x4
	int32_t CostType; // Offset: 0x7c | Size: 0x4
	int32_t OpenTime; // Offset: 0x80 | Size: 0x4
	int32_t Drop; // Offset: 0x84 | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarTables_ChestSpawn
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_ChestSpawn : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_ChestSpawn> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_ChestSpawn
// Inherited Bytes: 0x10 | Struct Size: 0x40
struct FSolarTablesData_ChestSpawn : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	enum class ESolarTablesEnum_ChestType ChestType; // Offset: 0x10 | Size: 0x1
	char pad_0x15[0x3]; // Offset: 0x15 | Size: 0x3
	struct TArray<int32_t> Chests; // Offset: 0x18 | Size: 0x10
	struct TArray<int32_t> Weight; // Offset: 0x28 | Size: 0x10
	int32_t SpawnCount; // Offset: 0x38 | Size: 0x4
	char pad_0x3C[0x4]; // Offset: 0x3c | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarTables_ChestSpawnGroup
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_ChestSpawnGroup : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_ChestSpawnGroup> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_ChestSpawnGroup
// Inherited Bytes: 0x10 | Struct Size: 0x20
struct FSolarTablesData_ChestSpawnGroup : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	struct TArray<int32_t> ChestGroup; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarTables_CircularCameras
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_CircularCameras : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_CircularCameras> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_CircularCameras
// Inherited Bytes: 0x10 | Struct Size: 0x30
struct FSolarTablesData_CircularCameras : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	int32_t MiniDistance; // Offset: 0x10 | Size: 0x4
	float BorderRatio; // Offset: 0x14 | Size: 0x4
	int32_t FOV; // Offset: 0x18 | Size: 0x4
	int32_t Pitch; // Offset: 0x1c | Size: 0x4
	int32_t InitAngleWithMainDir; // Offset: 0x20 | Size: 0x4
	float BlendAlpha; // Offset: 0x24 | Size: 0x4
	float AngularSpeed; // Offset: 0x28 | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarTables_ClanFlag
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_ClanFlag : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_ClanFlag> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_ClanFlag
// Inherited Bytes: 0x10 | Struct Size: 0x30
struct FSolarTablesData_ClanFlag : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	struct FString FlagIcon; // Offset: 0x10 | Size: 0x10
	struct FString WebIcon; // Offset: 0x20 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarTables_Collect
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_Collect : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_Collect> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_Collect
// Inherited Bytes: 0x10 | Struct Size: 0x80
struct FSolarTablesData_Collect : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	struct FSolarTablesLocalText Name; // Offset: 0x10 | Size: 0x4
	struct FString Icon; // Offset: 0x18 | Size: 0x10
	struct FSolarTablesLocalText Info; // Offset: 0x28 | Size: 0x4
	int32_t Quality; // Offset: 0x2c | Size: 0x4
	int32_t ItemType; // Offset: 0x30 | Size: 0x4
	bool IfReplace; // Offset: 0x34 | Size: 0x1
	char pad_0x35[0x3]; // Offset: 0x35 | Size: 0x3
	int32_t Pile; // Offset: 0x38 | Size: 0x4
	char pad_0x3C[0x4]; // Offset: 0x3c | Size: 0x4
	struct FString AbilityBP; // Offset: 0x40 | Size: 0x10
	struct FString ItemBP; // Offset: 0x50 | Size: 0x10
	struct FString AudioEventName; // Offset: 0x60 | Size: 0x10
	bool UseOnPickup; // Offset: 0x70 | Size: 0x1
	char pad_0x71[0x3]; // Offset: 0x71 | Size: 0x3
	int32_t lobbyCollectId; // Offset: 0x74 | Size: 0x4
	int32_t Level; // Offset: 0x78 | Size: 0x4
	int32_t EventId; // Offset: 0x7c | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarTables_Dance
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_Dance : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_Dance> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_Dance
// Inherited Bytes: 0x10 | Struct Size: 0x80
struct FSolarTablesData_Dance : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	struct FSolarTablesLocalText Name; // Offset: 0x10 | Size: 0x4
	struct FString Icon; // Offset: 0x18 | Size: 0x10
	struct FSolarTablesLocalText Info; // Offset: 0x28 | Size: 0x4
	int32_t Quality; // Offset: 0x2c | Size: 0x4
	int32_t ItemClass; // Offset: 0x30 | Size: 0x4
	int32_t ItemType; // Offset: 0x34 | Size: 0x4
	bool ShowInStorage; // Offset: 0x38 | Size: 0x1
	bool IfUse; // Offset: 0x39 | Size: 0x1
	bool IfRecycle; // Offset: 0x3a | Size: 0x1
	enum class ESolarTablesEnum_StackType StackType; // Offset: 0x3b | Size: 0x1
	char pad_0x3C[0x4]; // Offset: 0x3c | Size: 0x4
	struct TArray<int32_t> JumpLink; // Offset: 0x40 | Size: 0x10
	int32_t LoopTime; // Offset: 0x50 | Size: 0x4
	char pad_0x54[0x4]; // Offset: 0x54 | Size: 0x4
	struct FString BlueprintPath; // Offset: 0x58 | Size: 0x10
	int32_t ShopID; // Offset: 0x68 | Size: 0x4
	bool IfDefault; // Offset: 0x6c | Size: 0x1
	bool IfShow; // Offset: 0x6d | Size: 0x1
	char pad_0x6E[0x2]; // Offset: 0x6e | Size: 0x2
	struct FString BeginTime; // Offset: 0x70 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarTables_DayAndNight
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_DayAndNight : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_DayAndNight> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_DayAndNight
// Inherited Bytes: 0x10 | Struct Size: 0x20
struct FSolarTablesData_DayAndNight : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	int32_t TimeOfDays; // Offset: 0x10 | Size: 0x4
	int32_t ChangingSpeed; // Offset: 0x14 | Size: 0x4
	float ChargingRate; // Offset: 0x18 | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarTables_DsVariableRange
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_DsVariableRange : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_DsVariableRange> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_DsVariableRange
// Inherited Bytes: 0x10 | Struct Size: 0x38
struct FSolarTablesData_DsVariableRange : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	struct FString VariableName; // Offset: 0x10 | Size: 0x10
	float ValueStart; // Offset: 0x20 | Size: 0x4
	float ValueEnd; // Offset: 0x24 | Size: 0x4
	int32_t ValueType; // Offset: 0x28 | Size: 0x4
	int32_t Tolerance; // Offset: 0x2c | Size: 0x4
	int32_t ProbeInterval; // Offset: 0x30 | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarTables_Emote
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_Emote : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_Emote> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_Emote
// Inherited Bytes: 0x10 | Struct Size: 0xa8
struct FSolarTablesData_Emote : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	struct FSolarTablesLocalText Name; // Offset: 0x10 | Size: 0x4
	struct FString Icon; // Offset: 0x18 | Size: 0x10
	struct FSolarTablesLocalText Info; // Offset: 0x28 | Size: 0x4
	int32_t Quality; // Offset: 0x2c | Size: 0x4
	int32_t ItemClass; // Offset: 0x30 | Size: 0x4
	int32_t ItemType; // Offset: 0x34 | Size: 0x4
	bool ShowInStorage; // Offset: 0x38 | Size: 0x1
	bool IfUse; // Offset: 0x39 | Size: 0x1
	bool IfRecycle; // Offset: 0x3a | Size: 0x1
	enum class ESolarTablesEnum_StackType StackType; // Offset: 0x3b | Size: 0x1
	char pad_0x3C[0x4]; // Offset: 0x3c | Size: 0x4
	struct TArray<int32_t> JumpLink; // Offset: 0x40 | Size: 0x10
	int32_t EmoteType; // Offset: 0x50 | Size: 0x4
	char pad_0x54[0x4]; // Offset: 0x54 | Size: 0x4
	struct FString EmoteBlueprintPath; // Offset: 0x58 | Size: 0x10
	struct FString EmoteResourcePath; // Offset: 0x68 | Size: 0x10
	float EmoteDuration; // Offset: 0x78 | Size: 0x4
	char pad_0x7C[0x4]; // Offset: 0x7c | Size: 0x4
	struct FString EmoteAppearSound; // Offset: 0x80 | Size: 0x10
	struct FString EmoteSound; // Offset: 0x90 | Size: 0x10
	int32_t ShopID; // Offset: 0xa0 | Size: 0x4
	char pad_0xA4[0x4]; // Offset: 0xa4 | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarTables_EnergyProperty
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_EnergyProperty : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_EnergyProperty> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_EnergyProperty
// Inherited Bytes: 0x10 | Struct Size: 0x80
struct FSolarTablesData_EnergyProperty : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	struct FSolarTablesLocalText Name; // Offset: 0x10 | Size: 0x4
	struct FString Icon; // Offset: 0x18 | Size: 0x10
	struct FSolarTablesLocalText Info; // Offset: 0x28 | Size: 0x4
	int32_t Quality; // Offset: 0x2c | Size: 0x4
	int32_t ItemType; // Offset: 0x30 | Size: 0x4
	bool IfReplace; // Offset: 0x34 | Size: 0x1
	char pad_0x35[0x3]; // Offset: 0x35 | Size: 0x3
	int32_t Pile; // Offset: 0x38 | Size: 0x4
	char pad_0x3C[0x4]; // Offset: 0x3c | Size: 0x4
	struct FString AbilityBP; // Offset: 0x40 | Size: 0x10
	struct FString ItemBP; // Offset: 0x50 | Size: 0x10
	struct FString AudioEventName; // Offset: 0x60 | Size: 0x10
	bool UseOnPickup; // Offset: 0x70 | Size: 0x1
	char pad_0x71[0x3]; // Offset: 0x71 | Size: 0x3
	float AddedEnergyMax; // Offset: 0x74 | Size: 0x4
	int32_t EnergyModuleWorth; // Offset: 0x78 | Size: 0x4
	char pad_0x7C[0x4]; // Offset: 0x7c | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarTables_EscapeExp
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_EscapeExp : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_EscapeExp> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_EscapeExp
// Inherited Bytes: 0x10 | Struct Size: 0x38
struct FSolarTablesData_EscapeExp : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	enum class ESolarTablesEnum_BehaviorType BehaviorType; // Offset: 0x10 | Size: 0x1
	int32_t CharacterGetExp; // Offset: 0x14 | Size: 0x4
	int32_t WeaponGetExp; // Offset: 0x18 | Size: 0x4
	int32_t WeaponExp_2; // Offset: 0x1c | Size: 0x4
	int32_t WeaponExp_3; // Offset: 0x20 | Size: 0x4
	int32_t WeaponExp_5; // Offset: 0x24 | Size: 0x4
	struct FSolarTablesLocalText CharaGetExpText; // Offset: 0x28 | Size: 0x4
	int32_t WeaponGetExpText; // Offset: 0x2c | Size: 0x4
	int32_t ExpID; // Offset: 0x30 | Size: 0x4
	char pad_0x35[0x3]; // Offset: 0x35 | Size: 0x3
};

// Object: ScriptStruct Solarland.SolarTables_EShop
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_EShop : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_EShop> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_EShop
// Inherited Bytes: 0x10 | Struct Size: 0x38
struct FSolarTablesData_EShop : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	struct TArray<int32_t> PoolGroupID; // Offset: 0x10 | Size: 0x10
	bool IfMapShow; // Offset: 0x20 | Size: 0x1
	char pad_0x25[0x3]; // Offset: 0x25 | Size: 0x3
	struct TArray<int32_t> PoolRefreshTime; // Offset: 0x28 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarTables_EShopDemoModel
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_EShopDemoModel : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_EShopDemoModel> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_EShopDemoModel
// Inherited Bytes: 0x10 | Struct Size: 0x18
struct FSolarTablesData_EShopDemoModel : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	int32_t ModelID; // Offset: 0x10 | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarTables_EShopGoodsPool
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_EShopGoodsPool : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_EShopGoodsPool> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_EShopGoodsPool
// Inherited Bytes: 0x10 | Struct Size: 0x58
struct FSolarTablesData_EShopGoodsPool : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	struct TArray<int32_t> Equipments; // Offset: 0x10 | Size: 0x10
	struct TArray<int32_t> Prize; // Offset: 0x20 | Size: 0x10
	struct TArray<int32_t> Nums; // Offset: 0x30 | Size: 0x10
	struct TArray<int32_t> Weight; // Offset: 0x40 | Size: 0x10
	int32_t NumbersToDisplay; // Offset: 0x50 | Size: 0x4
	int32_t ColdDown; // Offset: 0x54 | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarTables_EShopGoodsPoolGroup
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_EShopGoodsPoolGroup : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_EShopGoodsPoolGroup> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_EShopGoodsPoolGroup
// Inherited Bytes: 0x10 | Struct Size: 0x20
struct FSolarTablesData_EShopGoodsPoolGroup : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	struct TArray<int32_t> PoolIDs; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarTables_EShopSpawn
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_EShopSpawn : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_EShopSpawn> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_EShopSpawn
// Inherited Bytes: 0x10 | Struct Size: 0x30
struct FSolarTablesData_EShopSpawn : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	struct TArray<int32_t> Eshops; // Offset: 0x10 | Size: 0x10
	struct TArray<int32_t> Weight; // Offset: 0x20 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarTables_ExtraEnergyProperty
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_ExtraEnergyProperty : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_ExtraEnergyProperty> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_ExtraEnergyProperty
// Inherited Bytes: 0x10 | Struct Size: 0xb8
struct FSolarTablesData_ExtraEnergyProperty : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	struct FSolarTablesLocalText Name; // Offset: 0x10 | Size: 0x4
	struct FString Icon; // Offset: 0x18 | Size: 0x10
	struct FSolarTablesLocalText Info; // Offset: 0x28 | Size: 0x4
	int32_t Quality; // Offset: 0x2c | Size: 0x4
	int32_t ItemType; // Offset: 0x30 | Size: 0x4
	bool IfReplace; // Offset: 0x34 | Size: 0x1
	char pad_0x35[0x3]; // Offset: 0x35 | Size: 0x3
	int32_t Pile; // Offset: 0x38 | Size: 0x4
	char pad_0x3C[0x4]; // Offset: 0x3c | Size: 0x4
	struct FString AbilityBP; // Offset: 0x40 | Size: 0x10
	struct FString ItemBP; // Offset: 0x50 | Size: 0x10
	struct FString AudioEventName; // Offset: 0x60 | Size: 0x10
	bool UseOnPickup; // Offset: 0x70 | Size: 0x1
	char pad_0x71[0x3]; // Offset: 0x71 | Size: 0x3
	int32_t QualityColor; // Offset: 0x74 | Size: 0x4
	float ExtraEnergyMax; // Offset: 0x78 | Size: 0x4
	float ExtraEnergyCharge; // Offset: 0x7c | Size: 0x4
	float ChargeCD; // Offset: 0x80 | Size: 0x4
	int32_t ExtraEnergyWorth; // Offset: 0x84 | Size: 0x4
	float RechargeFrequencyFromSky; // Offset: 0x88 | Size: 0x4
	float RechargeFrequencyFromDeathBox; // Offset: 0x8c | Size: 0x4
	float RechargeFrequencyFromPile; // Offset: 0x90 | Size: 0x4
	float RechargeQuantityFromSky; // Offset: 0x94 | Size: 0x4
	float RechargeQuantityFromDeathBox; // Offset: 0x98 | Size: 0x4
	float RechargeQuantityFromPile; // Offset: 0x9c | Size: 0x4
	struct FString Sketch; // Offset: 0xa0 | Size: 0x10
	int32_t SketchLevel; // Offset: 0xb0 | Size: 0x4
	char pad_0xB4[0x4]; // Offset: 0xb4 | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarTables_GameMap
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_GameMap : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_GameMap> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_GameMap
// Inherited Bytes: 0x10 | Struct Size: 0xc0
struct FSolarTablesData_GameMap : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	struct FSolarTablesLocalText Name; // Offset: 0x10 | Size: 0x4
	struct FString MapName; // Offset: 0x18 | Size: 0x10
	struct FString ResPath; // Offset: 0x28 | Size: 0x10
	int32_t MapImage; // Offset: 0x38 | Size: 0x4
	char pad_0x3C[0x4]; // Offset: 0x3c | Size: 0x4
	struct TArray<float> MapImageSize; // Offset: 0x40 | Size: 0x10
	struct TArray<float> MapTopLeftCoord; // Offset: 0x50 | Size: 0x10
	struct TArray<float> MapRightBottomCoord; // Offset: 0x60 | Size: 0x10
	struct TArray<int32_t> LocationIcon; // Offset: 0x70 | Size: 0x10
	struct TArray<struct FString> ItemSubLevels; // Offset: 0x80 | Size: 0x10
	float HorizonLineZ; // Offset: 0x90 | Size: 0x4
	float TopZ; // Offset: 0x94 | Size: 0x4
	float BottomZ; // Offset: 0x98 | Size: 0x4
	float AverageZ; // Offset: 0x9c | Size: 0x4
	float InitFogZ; // Offset: 0xa0 | Size: 0x4
	float TargetFogZ; // Offset: 0xa4 | Size: 0x4
	float MapFOV; // Offset: 0xa8 | Size: 0x4
	int32_t Speed1; // Offset: 0xac | Size: 0x4
	int32_t Speed2; // Offset: 0xb0 | Size: 0x4
	float MapFOV1; // Offset: 0xb4 | Size: 0x4
	float MapFOV2; // Offset: 0xb8 | Size: 0x4
	char pad_0xBC[0x4]; // Offset: 0xbc | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarTables_GameModeGroup
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_GameModeGroup : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_GameModeGroup> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_GameModeGroup
// Inherited Bytes: 0x10 | Struct Size: 0x80
struct FSolarTablesData_GameModeGroup : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	struct FSolarTablesLocalText ModeGroupName; // Offset: 0x10 | Size: 0x4
	int32_t SortId; // Offset: 0x14 | Size: 0x4
	struct TArray<int32_t> ModeID; // Offset: 0x18 | Size: 0x10
	struct FString GroupBg; // Offset: 0x28 | Size: 0x10
	struct FString Icon_s; // Offset: 0x38 | Size: 0x10
	struct FString Icon_mini; // Offset: 0x48 | Size: 0x10
	struct FString Icon_recruit; // Offset: 0x58 | Size: 0x10
	int32_t DefaultSelect; // Offset: 0x68 | Size: 0x4
	bool IfMultiple; // Offset: 0x6c | Size: 0x1
	struct FString GuideVideoUrl; // Offset: 0x70 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarTables_GameModeMain
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_GameModeMain : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_GameModeMain> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_GameModeMain
// Inherited Bytes: 0x10 | Struct Size: 0x168
struct FSolarTablesData_GameModeMain : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	int32_t groupid; // Offset: 0x10 | Size: 0x4
	bool Enabled; // Offset: 0x14 | Size: 0x1
	int32_t DefaultSelect; // Offset: 0x18 | Size: 0x4
	struct FSolarTablesLocalText Name; // Offset: 0x1c | Size: 0x4
	struct FSolarTablesLocalText Desc; // Offset: 0x20 | Size: 0x4
	struct FSolarTablesLocalText DetailDes; // Offset: 0x24 | Size: 0x4
	struct FString Icon; // Offset: 0x28 | Size: 0x10
	struct FString Icon_s; // Offset: 0x38 | Size: 0x10
	struct FString Icon_recruit; // Offset: 0x48 | Size: 0x10
	struct FString Icon_recruit_issue; // Offset: 0x58 | Size: 0x10
	struct FString Icon_mini; // Offset: 0x68 | Size: 0x10
	bool IfRecruitShow; // Offset: 0x78 | Size: 0x1
	char pad_0x7A[0x2]; // Offset: 0x7a | Size: 0x2
	int32_t ModeType; // Offset: 0x7c | Size: 0x4
	int32_t OutcomeSet; // Offset: 0x80 | Size: 0x4
	int32_t LifeTime; // Offset: 0x84 | Size: 0x4
	struct TArray<int32_t> AccessClient; // Offset: 0x88 | Size: 0x10
	struct TArray<int32_t> AccessServer; // Offset: 0x98 | Size: 0x10
	struct TArray<int32_t> AccessAccount; // Offset: 0xa8 | Size: 0x10
	struct TArray<int32_t> AccessActivity; // Offset: 0xb8 | Size: 0x10
	int32_t UnlockLvl; // Offset: 0xc8 | Size: 0x4
	char pad_0xCC[0x4]; // Offset: 0xcc | Size: 0x4
	struct TArray<int32_t> MatchRule; // Offset: 0xd0 | Size: 0x10
	int32_t DefaultMatchRule; // Offset: 0xe0 | Size: 0x4
	int32_t Backpack; // Offset: 0xe4 | Size: 0x4
	struct FString UIConfig; // Offset: 0xe8 | Size: 0x10
	struct FString ModeConfig; // Offset: 0xf8 | Size: 0x10
	struct FString Parameters; // Offset: 0x108 | Size: 0x10
	bool AIMatch; // Offset: 0x118 | Size: 0x1
	char pad_0x119[0x7]; // Offset: 0x119 | Size: 0x7
	struct FString SettlementBPPath; // Offset: 0x120 | Size: 0x10
	bool ReEnterBattle; // Offset: 0x130 | Size: 0x1
	bool IsAutoFillTeammate; // Offset: 0x131 | Size: 0x1
	char pad_0x132[0x6]; // Offset: 0x132 | Size: 0x6
	struct TArray<int32_t> CustomRoomNum; // Offset: 0x138 | Size: 0x10
	bool GetSupplyBox; // Offset: 0x148 | Size: 0x1
	char pad_0x149[0x3]; // Offset: 0x149 | Size: 0x3
	int32_t ChunkID; // Offset: 0x14c | Size: 0x4
	struct TArray<int32_t> ChunkIdList; // Offset: 0x150 | Size: 0x10
	enum class ESolarTablesEnum_ClassModeType ClassModeType; // Offset: 0x160 | Size: 0x1
	bool WarmUp; // Offset: 0x161 | Size: 0x1
	bool EnableCustomRoomReplay; // Offset: 0x162 | Size: 0x1
	bool EnableReplayAutoDirector; // Offset: 0x163 | Size: 0x1
	char pad_0x164[0x4]; // Offset: 0x164 | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarTables_GameTimeLine
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_GameTimeLine : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_GameTimeLine> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_GameTimeLine
// Inherited Bytes: 0x10 | Struct Size: 0x48
struct FSolarTablesData_GameTimeLine : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	struct TArray<int32_t> CheckEvent; // Offset: 0x10 | Size: 0x10
	int32_t GameMode; // Offset: 0x20 | Size: 0x4
	int32_t StartTime; // Offset: 0x24 | Size: 0x4
	int32_t DaylightChange; // Offset: 0x28 | Size: 0x4
	int32_t AirDrops; // Offset: 0x2c | Size: 0x4
	bool IfPoisonShrink; // Offset: 0x30 | Size: 0x1
	char pad_0x35[0x3]; // Offset: 0x35 | Size: 0x3
	struct TArray<int32_t> RedZone; // Offset: 0x38 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarTables_GetPoint
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_GetPoint : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_GetPoint> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_GetPoint
// Inherited Bytes: 0x10 | Struct Size: 0x20
struct FSolarTablesData_GetPoint : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	int32_t Point; // Offset: 0x10 | Size: 0x4
	int32_t TaskValue; // Offset: 0x14 | Size: 0x4
	struct FSolarTablesLocalText TaskText; // Offset: 0x18 | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarTables_GlobalOutcome
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_GlobalOutcome : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_GlobalOutcome> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_GlobalOutcome
// Inherited Bytes: 0x10 | Struct Size: 0x50
struct FSolarTablesData_GlobalOutcome : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	struct TArray<int32_t> ItemIDs; // Offset: 0x10 | Size: 0x10
	struct TArray<int32_t> ItemNums; // Offset: 0x20 | Size: 0x10
	int32_t SingleMaxTimes; // Offset: 0x30 | Size: 0x4
	int32_t TotalMaxTimes; // Offset: 0x34 | Size: 0x4
	int32_t TotalMinTimes; // Offset: 0x38 | Size: 0x4
	struct TArray<int32_t> AffectedOutcomes; // Offset: 0x40 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarTables_GlobalSensitivity
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_GlobalSensitivity : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_GlobalSensitivity> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_GlobalSensitivity
// Inherited Bytes: 0x10 | Struct Size: 0x98
struct FSolarTablesData_GlobalSensitivity : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	struct TArray<float> HoldWeaponSensitivity; // Offset: 0x10 | Size: 0x10
	struct TArray<float> FireWeaponSensitivity; // Offset: 0x20 | Size: 0x10
	float ShoulderShootSenSItivity; // Offset: 0x30 | Size: 0x4
	float ShoulderShootFireSenSItivity; // Offset: 0x34 | Size: 0x4
	struct TArray<float> SkillSensitivity; // Offset: 0x38 | Size: 0x10
	struct TArray<float> SightSensitivity; // Offset: 0x48 | Size: 0x10
	struct TArray<float> VehicleDriverSensitivity; // Offset: 0x58 | Size: 0x10
	struct TArray<float> VehicleFireSensitivity; // Offset: 0x68 | Size: 0x10
	struct TArray<float> SuperSkillSensitivity; // Offset: 0x78 | Size: 0x10
	struct TArray<float> TacticalSkillSensitivity; // Offset: 0x88 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarTables_GunProperty
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_GunProperty : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_GunProperty> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_GunProperty
// Inherited Bytes: 0x10 | Struct Size: 0xb0
struct FSolarTablesData_GunProperty : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	struct FSolarTablesLocalText Name; // Offset: 0x10 | Size: 0x4
	struct FString Icon; // Offset: 0x18 | Size: 0x10
	struct FSolarTablesLocalText Info; // Offset: 0x28 | Size: 0x4
	int32_t Quality; // Offset: 0x2c | Size: 0x4
	int32_t ItemType; // Offset: 0x30 | Size: 0x4
	bool IfReplace; // Offset: 0x34 | Size: 0x1
	char pad_0x35[0x3]; // Offset: 0x35 | Size: 0x3
	int32_t Pile; // Offset: 0x38 | Size: 0x4
	char pad_0x3C[0x4]; // Offset: 0x3c | Size: 0x4
	struct FString AbilityBP; // Offset: 0x40 | Size: 0x10
	struct FString ItemBP; // Offset: 0x50 | Size: 0x10
	struct FString AudioEventName; // Offset: 0x60 | Size: 0x10
	bool UseOnPickup; // Offset: 0x70 | Size: 0x1
	char pad_0x71[0x3]; // Offset: 0x71 | Size: 0x3
	int32_t weaponid; // Offset: 0x74 | Size: 0x4
	bool Disused; // Offset: 0x78 | Size: 0x1
	char pad_0x79[0x7]; // Offset: 0x79 | Size: 0x7
	struct FString BigIcon; // Offset: 0x80 | Size: 0x10
	int32_t WeaponLv; // Offset: 0x90 | Size: 0x4
	bool UseWeaponAccessory; // Offset: 0x94 | Size: 0x1
	char pad_0x95[0x3]; // Offset: 0x95 | Size: 0x3
	int32_t WeaponAccessory1; // Offset: 0x98 | Size: 0x4
	int32_t WeaponAccessory2; // Offset: 0x9c | Size: 0x4
	int32_t WeaponAccessory3; // Offset: 0xa0 | Size: 0x4
	int32_t WeaponAccessory4; // Offset: 0xa4 | Size: 0x4
	int32_t WeaponAccessory5; // Offset: 0xa8 | Size: 0x4
	char pad_0xAC[0x4]; // Offset: 0xac | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarTables_HeroPowerFormula
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_HeroPowerFormula : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_HeroPowerFormula> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_HeroPowerFormula
// Inherited Bytes: 0x10 | Struct Size: 0x28
struct FSolarTablesData_HeroPowerFormula : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	int32_t MatchRuleID; // Offset: 0x10 | Size: 0x4
	int32_t Battlerank; // Offset: 0x14 | Size: 0x4
	int32_t RankScore; // Offset: 0x18 | Size: 0x4
	float KillRealConfig; // Offset: 0x1c | Size: 0x4
	float KillAiConfig; // Offset: 0x20 | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarTables_HighlightRating
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_HighlightRating : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_HighlightRating> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_HighlightRating
// Inherited Bytes: 0x10 | Struct Size: 0x28
struct FSolarTablesData_HighlightRating : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	struct FString Name; // Offset: 0x10 | Size: 0x10
	float MinScore; // Offset: 0x20 | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarTables_HotSpot
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_HotSpot : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_HotSpot> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_HotSpot
// Inherited Bytes: 0x10 | Struct Size: 0x28
struct FSolarTablesData_HotSpot : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	struct FString UIResource; // Offset: 0x10 | Size: 0x10
	float JumpTime; // Offset: 0x20 | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarTables_InputAction
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_InputAction : FSolarTablesDataBase {
	// Fields
	struct TMap<struct FString, struct FSolarTablesData_InputAction> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_InputAction
// Inherited Bytes: 0x10 | Struct Size: 0x28
struct FSolarTablesData_InputAction : FSolarTablesDataBase {
	// Fields
	struct FString ID; // Offset: 0x10 | Size: 0x10
	bool bFlagBigMap; // Offset: 0x20 | Size: 0x1
	bool bFlagBackpack; // Offset: 0x21 | Size: 0x1
	bool bFlagChat; // Offset: 0x22 | Size: 0x1
	bool bFlagParachute; // Offset: 0x23 | Size: 0x1
	bool bFlagSpectate; // Offset: 0x24 | Size: 0x1
	bool bFlagTeamDeath; // Offset: 0x25 | Size: 0x1
	bool bFlagRelive; // Offset: 0x26 | Size: 0x1
	char pad_0x27[0x1]; // Offset: 0x27 | Size: 0x1
};

// Object: ScriptStruct Solarland.SolarTables_InputMapping
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_InputMapping : FSolarTablesDataBase {
	// Fields
	struct TMap<struct FString, struct FSolarTablesData_InputMapping> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_InputMapping
// Inherited Bytes: 0x10 | Struct Size: 0x98
struct FSolarTablesData_InputMapping : FSolarTablesDataBase {
	// Fields
	struct FString ID; // Offset: 0x10 | Size: 0x10
	struct FString ActionName; // Offset: 0x20 | Size: 0x10
	enum class ESolarTablesEnum_InputActionType ActionType; // Offset: 0x30 | Size: 0x1
	char pad_0x31[0x3]; // Offset: 0x31 | Size: 0x3
	float Scale; // Offset: 0x34 | Size: 0x4
	enum class ESolarTablesEnum_InputTriggerType TriggerType; // Offset: 0x38 | Size: 0x1
	char pad_0x39[0x7]; // Offset: 0x39 | Size: 0x7
	struct FString FirstDefaultKeys; // Offset: 0x40 | Size: 0x10
	struct FString SecondDefaultKeys; // Offset: 0x50 | Size: 0x10
	struct FString ThirdDefaultKeys; // Offset: 0x60 | Size: 0x10
	enum class ESolarTablesEnum_InputCtrlType CtrlType; // Offset: 0x70 | Size: 0x1
	enum class ESolarTablesEnum_InputContextType ContextType; // Offset: 0x71 | Size: 0x1
	enum class ESolarTablesEnum_InputRelatedType RelatedType; // Offset: 0x72 | Size: 0x1
	char pad_0x73[0x1]; // Offset: 0x73 | Size: 0x1
	struct FSolarTablesLocalText ActionDisplayName; // Offset: 0x74 | Size: 0x4
	struct FSolarTablesLocalText ActionTipsDesc; // Offset: 0x78 | Size: 0x4
	enum class ESolarTablesEnum_InputTabType TabType; // Offset: 0x7c | Size: 0x1
	char pad_0x7D[0x3]; // Offset: 0x7d | Size: 0x3
	int32_t GroupIndex; // Offset: 0x80 | Size: 0x4
	struct FSolarTablesLocalText GroupTitle; // Offset: 0x84 | Size: 0x4
	enum class ESolarTablesEnum_InputGroupType GroupType; // Offset: 0x88 | Size: 0x1
	char pad_0x89[0x3]; // Offset: 0x89 | Size: 0x3
	int32_t GroupPriority; // Offset: 0x8c | Size: 0x4
	bool AffectedByActionTipsSettings; // Offset: 0x90 | Size: 0x1
	char pad_0x91[0x7]; // Offset: 0x91 | Size: 0x7
};

// Object: ScriptStruct Solarland.SolarTables_Item
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_Item : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_Item> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_Item
// Inherited Bytes: 0x10 | Struct Size: 0x50
struct FSolarTablesData_Item : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	struct FSolarTablesLocalText Name; // Offset: 0x10 | Size: 0x4
	struct FString Icon; // Offset: 0x18 | Size: 0x10
	struct FSolarTablesLocalText Info; // Offset: 0x28 | Size: 0x4
	int32_t Quality; // Offset: 0x2c | Size: 0x4
	int32_t ItemClass; // Offset: 0x30 | Size: 0x4
	int32_t ItemType; // Offset: 0x34 | Size: 0x4
	bool ShowInStorage; // Offset: 0x38 | Size: 0x1
	bool IfUse; // Offset: 0x39 | Size: 0x1
	bool IfRecycle; // Offset: 0x3a | Size: 0x1
	enum class ESolarTablesEnum_StackType StackType; // Offset: 0x3b | Size: 0x1
	char pad_0x3C[0x4]; // Offset: 0x3c | Size: 0x4
	struct TArray<int32_t> JumpLink; // Offset: 0x40 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarTables_ItemBehavior
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_ItemBehavior : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_ItemBehavior> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_ItemBehavior
// Inherited Bytes: 0x10 | Struct Size: 0x78
struct FSolarTablesData_ItemBehavior : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	struct FSolarTablesLocalText Name; // Offset: 0x10 | Size: 0x4
	struct FString Icon; // Offset: 0x18 | Size: 0x10
	struct FSolarTablesLocalText Info; // Offset: 0x28 | Size: 0x4
	int32_t Quality; // Offset: 0x2c | Size: 0x4
	int32_t ItemType; // Offset: 0x30 | Size: 0x4
	bool IfReplace; // Offset: 0x34 | Size: 0x1
	char pad_0x35[0x3]; // Offset: 0x35 | Size: 0x3
	int32_t Pile; // Offset: 0x38 | Size: 0x4
	char pad_0x3C[0x4]; // Offset: 0x3c | Size: 0x4
	struct FString AbilityBP; // Offset: 0x40 | Size: 0x10
	struct FString ItemBP; // Offset: 0x50 | Size: 0x10
	struct FString AudioEventName; // Offset: 0x60 | Size: 0x10
	bool UseOnPickup; // Offset: 0x70 | Size: 0x1
	char pad_0x71[0x3]; // Offset: 0x71 | Size: 0x3
	int32_t BehaviorExpID; // Offset: 0x74 | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarTables_ItemCustomType
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_ItemCustomType : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_ItemCustomType> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_ItemCustomType
// Inherited Bytes: 0x10 | Struct Size: 0x20
struct FSolarTablesData_ItemCustomType : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	struct TArray<int32_t> ItemIDs; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarTables_ItemInBattle
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_ItemInBattle : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_ItemInBattle> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_ItemInBattle
// Inherited Bytes: 0x10 | Struct Size: 0x78
struct FSolarTablesData_ItemInBattle : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	struct FSolarTablesLocalText Name; // Offset: 0x10 | Size: 0x4
	struct FString Icon; // Offset: 0x18 | Size: 0x10
	struct FSolarTablesLocalText Info; // Offset: 0x28 | Size: 0x4
	int32_t Quality; // Offset: 0x2c | Size: 0x4
	int32_t ItemType; // Offset: 0x30 | Size: 0x4
	bool IfReplace; // Offset: 0x34 | Size: 0x1
	char pad_0x35[0x3]; // Offset: 0x35 | Size: 0x3
	int32_t Pile; // Offset: 0x38 | Size: 0x4
	char pad_0x3C[0x4]; // Offset: 0x3c | Size: 0x4
	struct FString AbilityBP; // Offset: 0x40 | Size: 0x10
	struct FString ItemBP; // Offset: 0x50 | Size: 0x10
	struct FString AudioEventName; // Offset: 0x60 | Size: 0x10
	bool UseOnPickup; // Offset: 0x70 | Size: 0x1
	char pad_0x71[0x7]; // Offset: 0x71 | Size: 0x7
};

// Object: ScriptStruct Solarland.SolarTables_ItemQuality
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_ItemQuality : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_ItemQuality> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_ItemQuality
// Inherited Bytes: 0x10 | Struct Size: 0xe0
struct FSolarTablesData_ItemQuality : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	struct TArray<float> Color; // Offset: 0x10 | Size: 0x10
	struct TArray<float> HUDColor; // Offset: 0x20 | Size: 0x10
	struct TArray<float> OutsideColor; // Offset: 0x30 | Size: 0x10
	struct TArray<float> InsideColor; // Offset: 0x40 | Size: 0x10
	struct TArray<float> HighQualityColor; // Offset: 0x50 | Size: 0x10
	struct TArray<float> LowQualityColor; // Offset: 0x60 | Size: 0x10
	struct TArray<float> HUDBGColor; // Offset: 0x70 | Size: 0x10
	struct TArray<float> HUDDecorateColor; // Offset: 0x80 | Size: 0x10
	struct FString Qualitypic; // Offset: 0x90 | Size: 0x10
	struct FString QualityColor; // Offset: 0xa0 | Size: 0x10
	struct FString Qualitystr; // Offset: 0xb0 | Size: 0x10
	struct FString QualityBG; // Offset: 0xc0 | Size: 0x10
	struct FString QualityBG2; // Offset: 0xd0 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarTables_ItemSound
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_ItemSound : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_ItemSound> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_ItemSound
// Inherited Bytes: 0x10 | Struct Size: 0x40
struct FSolarTablesData_ItemSound : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	struct FString PickupSound; // Offset: 0x10 | Size: 0x10
	struct FString EquippedSound; // Offset: 0x20 | Size: 0x10
	struct FString PassiveSound; // Offset: 0x30 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarTables_ItemWeaponParts
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_ItemWeaponParts : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_ItemWeaponParts> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_ItemWeaponParts
// Inherited Bytes: 0x10 | Struct Size: 0x90
struct FSolarTablesData_ItemWeaponParts : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	struct FSolarTablesLocalText Name; // Offset: 0x10 | Size: 0x4
	struct FString Icon; // Offset: 0x18 | Size: 0x10
	struct FSolarTablesLocalText Info; // Offset: 0x28 | Size: 0x4
	int32_t Quality; // Offset: 0x2c | Size: 0x4
	int32_t ItemType; // Offset: 0x30 | Size: 0x4
	bool IfReplace; // Offset: 0x34 | Size: 0x1
	char pad_0x35[0x3]; // Offset: 0x35 | Size: 0x3
	int32_t Pile; // Offset: 0x38 | Size: 0x4
	char pad_0x3C[0x4]; // Offset: 0x3c | Size: 0x4
	struct FString AbilityBP; // Offset: 0x40 | Size: 0x10
	struct FString ItemBP; // Offset: 0x50 | Size: 0x10
	struct FString AudioEventName; // Offset: 0x60 | Size: 0x10
	bool UseOnPickup; // Offset: 0x70 | Size: 0x1
	char pad_0x71[0x3]; // Offset: 0x71 | Size: 0x3
	int32_t PartsType; // Offset: 0x74 | Size: 0x4
	int32_t Level; // Offset: 0x78 | Size: 0x4
	char pad_0x7C[0x4]; // Offset: 0x7c | Size: 0x4
	struct FString PreviewIcon; // Offset: 0x80 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarTables_JetPackModuleProperty
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_JetPackModuleProperty : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_JetPackModuleProperty> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_JetPackModuleProperty
// Inherited Bytes: 0x10 | Struct Size: 0xb8
struct FSolarTablesData_JetPackModuleProperty : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	struct FSolarTablesLocalText Name; // Offset: 0x10 | Size: 0x4
	struct FString Icon; // Offset: 0x18 | Size: 0x10
	struct FSolarTablesLocalText Info; // Offset: 0x28 | Size: 0x4
	int32_t Quality; // Offset: 0x2c | Size: 0x4
	int32_t ItemType; // Offset: 0x30 | Size: 0x4
	bool IfReplace; // Offset: 0x34 | Size: 0x1
	char pad_0x35[0x3]; // Offset: 0x35 | Size: 0x3
	int32_t Pile; // Offset: 0x38 | Size: 0x4
	char pad_0x3C[0x4]; // Offset: 0x3c | Size: 0x4
	struct FString AbilityBP; // Offset: 0x40 | Size: 0x10
	struct FString ItemBP; // Offset: 0x50 | Size: 0x10
	struct FString AudioEventName; // Offset: 0x60 | Size: 0x10
	bool UseOnPickup; // Offset: 0x70 | Size: 0x1
	char pad_0x71[0x3]; // Offset: 0x71 | Size: 0x3
	int32_t VerticalDashSpeedTimes; // Offset: 0x74 | Size: 0x4
	int32_t HorizontalDashSpeedTimes; // Offset: 0x78 | Size: 0x4
	float VerticalDashSpeedScale; // Offset: 0x7c | Size: 0x4
	float HorizontalDashSpeedScale; // Offset: 0x80 | Size: 0x4
	float VerticalDashCoolDownScale; // Offset: 0x84 | Size: 0x4
	float HorizontalDashCoolDownScale; // Offset: 0x88 | Size: 0x4
	float VerticalDashEnergyScale; // Offset: 0x8c | Size: 0x4
	float HorizontalDashEnergyScale; // Offset: 0x90 | Size: 0x4
	float VerticalChargingScale; // Offset: 0x94 | Size: 0x4
	float HorizontalChargingScale; // Offset: 0x98 | Size: 0x4
	int32_t JetPackModuleWorth; // Offset: 0x9c | Size: 0x4
	struct FString Sketch; // Offset: 0xa0 | Size: 0x10
	int32_t SketchLevel; // Offset: 0xb0 | Size: 0x4
	char pad_0xB4[0x4]; // Offset: 0xb4 | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarTables_KillNotify
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_KillNotify : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_KillNotify> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_KillNotify
// Inherited Bytes: 0x10 | Struct Size: 0xd0
struct FSolarTablesData_KillNotify : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	struct FSolarTablesLocalText Name; // Offset: 0x10 | Size: 0x4
	struct FString Icon; // Offset: 0x18 | Size: 0x10
	struct FSolarTablesLocalText Info; // Offset: 0x28 | Size: 0x4
	int32_t Quality; // Offset: 0x2c | Size: 0x4
	int32_t ItemClass; // Offset: 0x30 | Size: 0x4
	int32_t ItemType; // Offset: 0x34 | Size: 0x4
	bool ShowInStorage; // Offset: 0x38 | Size: 0x1
	bool IfUse; // Offset: 0x39 | Size: 0x1
	bool IfRecycle; // Offset: 0x3a | Size: 0x1
	enum class ESolarTablesEnum_StackType StackType; // Offset: 0x3b | Size: 0x1
	char pad_0x3C[0x4]; // Offset: 0x3c | Size: 0x4
	struct TArray<int32_t> JumpLink; // Offset: 0x40 | Size: 0x10
	struct FString KillNotifyPath; // Offset: 0x50 | Size: 0x10
	struct FString KillNotifySpecialPath; // Offset: 0x60 | Size: 0x10
	struct FString KillNotifyBackGroundPath; // Offset: 0x70 | Size: 0x10
	struct FString KillNotifyBackground; // Offset: 0x80 | Size: 0x10
	struct FString TextColor; // Offset: 0x90 | Size: 0x10
	struct FString IconColor; // Offset: 0xa0 | Size: 0x10
	struct FString BackgroundColor; // Offset: 0xb0 | Size: 0x10
	struct FString Param; // Offset: 0xc0 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarTables_LanguageSwitcher
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_LanguageSwitcher : FSolarTablesDataBase {
	// Fields
	struct TMap<struct FString, struct FSolarTablesData_LanguageSwitcher> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_LanguageSwitcher
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTablesData_LanguageSwitcher : FSolarTablesDataBase {
	// Fields
	struct FString ID; // Offset: 0x10 | Size: 0x10
	struct FString ButtonText; // Offset: 0x20 | Size: 0x10
	bool IfOpened; // Offset: 0x30 | Size: 0x1
	char pad_0x31[0x3]; // Offset: 0x31 | Size: 0x3
	int32_t LanguageIndex; // Offset: 0x34 | Size: 0x4
	struct FString MarqueeDirection; // Offset: 0x38 | Size: 0x10
	struct FString TextAbbr; // Offset: 0x48 | Size: 0x10
	int32_t VoiceID; // Offset: 0x58 | Size: 0x4
	char pad_0x5C[0x4]; // Offset: 0x5c | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarTables_LobbyAutoDownload
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_LobbyAutoDownload : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_LobbyAutoDownload> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_LobbyAutoDownload
// Inherited Bytes: 0x10 | Struct Size: 0x20
struct FSolarTablesData_LobbyAutoDownload : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	int32_t ChunkID; // Offset: 0x10 | Size: 0x4
	int32_t ChunkName; // Offset: 0x14 | Size: 0x4
	bool IncludeMain; // Offset: 0x18 | Size: 0x1
	bool IncludeOptional; // Offset: 0x19 | Size: 0x1
	char pad_0x1E[0x2]; // Offset: 0x1e | Size: 0x2
};

// Object: ScriptStruct Solarland.SolarTables_Localization
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_Localization : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_Localization> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_Localization
// Inherited Bytes: 0x10 | Struct Size: 0x160
struct FSolarTablesData_Localization : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	struct FString zh_CN; // Offset: 0x10 | Size: 0x10
	struct FString en; // Offset: 0x20 | Size: 0x10
	struct FString pt; // Offset: 0x30 | Size: 0x10
	struct FString ind; // Offset: 0x40 | Size: 0x10
	struct FString zh_TW; // Offset: 0x50 | Size: 0x10
	struct FString ja; // Offset: 0x60 | Size: 0x10
	struct FString ko; // Offset: 0x70 | Size: 0x10
	struct FString fr; // Offset: 0x80 | Size: 0x10
	struct FString de; // Offset: 0x90 | Size: 0x10
	struct FString ru; // Offset: 0xa0 | Size: 0x10
	struct FString ar; // Offset: 0xb0 | Size: 0x10
	struct FString tr; // Offset: 0xc0 | Size: 0x10
	struct FString tl; // Offset: 0xd0 | Size: 0x10
	struct FString es; // Offset: 0xe0 | Size: 0x10
	struct FString hi; // Offset: 0xf0 | Size: 0x10
	struct FString vi; // Offset: 0x100 | Size: 0x10
	struct FString th; // Offset: 0x110 | Size: 0x10
	struct FString it; // Offset: 0x120 | Size: 0x10
	struct FString pl; // Offset: 0x130 | Size: 0x10
	struct FString po; // Offset: 0x140 | Size: 0x10
	struct FString Op; // Offset: 0x150 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarTables_Localization_BattleUI
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_Localization_BattleUI : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_Localization_BattleUI> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_Localization_BattleUI
// Inherited Bytes: 0x10 | Struct Size: 0x160
struct FSolarTablesData_Localization_BattleUI : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	struct FString zh_CN; // Offset: 0x10 | Size: 0x10
	struct FString en; // Offset: 0x20 | Size: 0x10
	struct FString pt; // Offset: 0x30 | Size: 0x10
	struct FString ind; // Offset: 0x40 | Size: 0x10
	struct FString zh_TW; // Offset: 0x50 | Size: 0x10
	struct FString ja; // Offset: 0x60 | Size: 0x10
	struct FString ko; // Offset: 0x70 | Size: 0x10
	struct FString fr; // Offset: 0x80 | Size: 0x10
	struct FString de; // Offset: 0x90 | Size: 0x10
	struct FString ru; // Offset: 0xa0 | Size: 0x10
	struct FString ar; // Offset: 0xb0 | Size: 0x10
	struct FString tr; // Offset: 0xc0 | Size: 0x10
	struct FString tl; // Offset: 0xd0 | Size: 0x10
	struct FString es; // Offset: 0xe0 | Size: 0x10
	struct FString hi; // Offset: 0xf0 | Size: 0x10
	struct FString vi; // Offset: 0x100 | Size: 0x10
	struct FString th; // Offset: 0x110 | Size: 0x10
	struct FString it; // Offset: 0x120 | Size: 0x10
	struct FString pl; // Offset: 0x130 | Size: 0x10
	struct FString po; // Offset: 0x140 | Size: 0x10
	struct FString Op; // Offset: 0x150 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarTables_Localization_EventSystem
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_Localization_EventSystem : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_Localization_EventSystem> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_Localization_EventSystem
// Inherited Bytes: 0x10 | Struct Size: 0x160
struct FSolarTablesData_Localization_EventSystem : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	struct FString zh_CN; // Offset: 0x10 | Size: 0x10
	struct FString en; // Offset: 0x20 | Size: 0x10
	struct FString pt; // Offset: 0x30 | Size: 0x10
	struct FString ind; // Offset: 0x40 | Size: 0x10
	struct FString zh_TW; // Offset: 0x50 | Size: 0x10
	struct FString ja; // Offset: 0x60 | Size: 0x10
	struct FString ko; // Offset: 0x70 | Size: 0x10
	struct FString fr; // Offset: 0x80 | Size: 0x10
	struct FString de; // Offset: 0x90 | Size: 0x10
	struct FString ru; // Offset: 0xa0 | Size: 0x10
	struct FString ar; // Offset: 0xb0 | Size: 0x10
	struct FString tr; // Offset: 0xc0 | Size: 0x10
	struct FString tl; // Offset: 0xd0 | Size: 0x10
	struct FString es; // Offset: 0xe0 | Size: 0x10
	struct FString hi; // Offset: 0xf0 | Size: 0x10
	struct FString vi; // Offset: 0x100 | Size: 0x10
	struct FString th; // Offset: 0x110 | Size: 0x10
	struct FString it; // Offset: 0x120 | Size: 0x10
	struct FString pl; // Offset: 0x130 | Size: 0x10
	struct FString po; // Offset: 0x140 | Size: 0x10
	struct FString Op; // Offset: 0x150 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarTables_Localization_General
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_Localization_General : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_Localization_General> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_Localization_General
// Inherited Bytes: 0x10 | Struct Size: 0x160
struct FSolarTablesData_Localization_General : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	struct FString zh_CN; // Offset: 0x10 | Size: 0x10
	struct FString en; // Offset: 0x20 | Size: 0x10
	struct FString pt; // Offset: 0x30 | Size: 0x10
	struct FString ind; // Offset: 0x40 | Size: 0x10
	struct FString zh_TW; // Offset: 0x50 | Size: 0x10
	struct FString ja; // Offset: 0x60 | Size: 0x10
	struct FString ko; // Offset: 0x70 | Size: 0x10
	struct FString fr; // Offset: 0x80 | Size: 0x10
	struct FString de; // Offset: 0x90 | Size: 0x10
	struct FString ru; // Offset: 0xa0 | Size: 0x10
	struct FString ar; // Offset: 0xb0 | Size: 0x10
	struct FString tr; // Offset: 0xc0 | Size: 0x10
	struct FString tl; // Offset: 0xd0 | Size: 0x10
	struct FString es; // Offset: 0xe0 | Size: 0x10
	struct FString hi; // Offset: 0xf0 | Size: 0x10
	struct FString vi; // Offset: 0x100 | Size: 0x10
	struct FString th; // Offset: 0x110 | Size: 0x10
	struct FString it; // Offset: 0x120 | Size: 0x10
	struct FString pl; // Offset: 0x130 | Size: 0x10
	struct FString po; // Offset: 0x140 | Size: 0x10
	struct FString Op; // Offset: 0x150 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarTables_Localization_Heroes
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_Localization_Heroes : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_Localization_Heroes> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_Localization_Heroes
// Inherited Bytes: 0x10 | Struct Size: 0x160
struct FSolarTablesData_Localization_Heroes : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	struct FString zh_CN; // Offset: 0x10 | Size: 0x10
	struct FString en; // Offset: 0x20 | Size: 0x10
	struct FString pt; // Offset: 0x30 | Size: 0x10
	struct FString ind; // Offset: 0x40 | Size: 0x10
	struct FString zh_TW; // Offset: 0x50 | Size: 0x10
	struct FString ja; // Offset: 0x60 | Size: 0x10
	struct FString ko; // Offset: 0x70 | Size: 0x10
	struct FString fr; // Offset: 0x80 | Size: 0x10
	struct FString de; // Offset: 0x90 | Size: 0x10
	struct FString ru; // Offset: 0xa0 | Size: 0x10
	struct FString ar; // Offset: 0xb0 | Size: 0x10
	struct FString tr; // Offset: 0xc0 | Size: 0x10
	struct FString tl; // Offset: 0xd0 | Size: 0x10
	struct FString es; // Offset: 0xe0 | Size: 0x10
	struct FString hi; // Offset: 0xf0 | Size: 0x10
	struct FString vi; // Offset: 0x100 | Size: 0x10
	struct FString th; // Offset: 0x110 | Size: 0x10
	struct FString it; // Offset: 0x120 | Size: 0x10
	struct FString pl; // Offset: 0x130 | Size: 0x10
	struct FString po; // Offset: 0x140 | Size: 0x10
	struct FString Op; // Offset: 0x150 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarTables_Localization_Item
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_Localization_Item : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_Localization_Item> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_Localization_Item
// Inherited Bytes: 0x10 | Struct Size: 0x160
struct FSolarTablesData_Localization_Item : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	struct FString zh_CN; // Offset: 0x10 | Size: 0x10
	struct FString en; // Offset: 0x20 | Size: 0x10
	struct FString pt; // Offset: 0x30 | Size: 0x10
	struct FString ind; // Offset: 0x40 | Size: 0x10
	struct FString zh_TW; // Offset: 0x50 | Size: 0x10
	struct FString ja; // Offset: 0x60 | Size: 0x10
	struct FString ko; // Offset: 0x70 | Size: 0x10
	struct FString fr; // Offset: 0x80 | Size: 0x10
	struct FString de; // Offset: 0x90 | Size: 0x10
	struct FString ru; // Offset: 0xa0 | Size: 0x10
	struct FString ar; // Offset: 0xb0 | Size: 0x10
	struct FString tr; // Offset: 0xc0 | Size: 0x10
	struct FString tl; // Offset: 0xd0 | Size: 0x10
	struct FString es; // Offset: 0xe0 | Size: 0x10
	struct FString hi; // Offset: 0xf0 | Size: 0x10
	struct FString vi; // Offset: 0x100 | Size: 0x10
	struct FString th; // Offset: 0x110 | Size: 0x10
	struct FString it; // Offset: 0x120 | Size: 0x10
	struct FString pl; // Offset: 0x130 | Size: 0x10
	struct FString po; // Offset: 0x140 | Size: 0x10
	struct FString Op; // Offset: 0x150 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarTables_Localization_Tournament
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_Localization_Tournament : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_Localization_Tournament> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_Localization_Tournament
// Inherited Bytes: 0x10 | Struct Size: 0x160
struct FSolarTablesData_Localization_Tournament : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	struct FString zh_CN; // Offset: 0x10 | Size: 0x10
	struct FString en; // Offset: 0x20 | Size: 0x10
	struct FString pt; // Offset: 0x30 | Size: 0x10
	struct FString ind; // Offset: 0x40 | Size: 0x10
	struct FString zh_TW; // Offset: 0x50 | Size: 0x10
	struct FString ja; // Offset: 0x60 | Size: 0x10
	struct FString ko; // Offset: 0x70 | Size: 0x10
	struct FString fr; // Offset: 0x80 | Size: 0x10
	struct FString de; // Offset: 0x90 | Size: 0x10
	struct FString ru; // Offset: 0xa0 | Size: 0x10
	struct FString ar; // Offset: 0xb0 | Size: 0x10
	struct FString tr; // Offset: 0xc0 | Size: 0x10
	struct FString tl; // Offset: 0xd0 | Size: 0x10
	struct FString es; // Offset: 0xe0 | Size: 0x10
	struct FString hi; // Offset: 0xf0 | Size: 0x10
	struct FString vi; // Offset: 0x100 | Size: 0x10
	struct FString th; // Offset: 0x110 | Size: 0x10
	struct FString it; // Offset: 0x120 | Size: 0x10
	struct FString pl; // Offset: 0x130 | Size: 0x10
	struct FString po; // Offset: 0x140 | Size: 0x10
	struct FString Op; // Offset: 0x150 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarTables_Localization_Uncategorized
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_Localization_Uncategorized : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_Localization_Uncategorized> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_Localization_Uncategorized
// Inherited Bytes: 0x10 | Struct Size: 0x160
struct FSolarTablesData_Localization_Uncategorized : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	struct FString zh_CN; // Offset: 0x10 | Size: 0x10
	struct FString en; // Offset: 0x20 | Size: 0x10
	struct FString pt; // Offset: 0x30 | Size: 0x10
	struct FString ind; // Offset: 0x40 | Size: 0x10
	struct FString zh_TW; // Offset: 0x50 | Size: 0x10
	struct FString ja; // Offset: 0x60 | Size: 0x10
	struct FString ko; // Offset: 0x70 | Size: 0x10
	struct FString fr; // Offset: 0x80 | Size: 0x10
	struct FString de; // Offset: 0x90 | Size: 0x10
	struct FString ru; // Offset: 0xa0 | Size: 0x10
	struct FString ar; // Offset: 0xb0 | Size: 0x10
	struct FString tr; // Offset: 0xc0 | Size: 0x10
	struct FString tl; // Offset: 0xd0 | Size: 0x10
	struct FString es; // Offset: 0xe0 | Size: 0x10
	struct FString hi; // Offset: 0xf0 | Size: 0x10
	struct FString vi; // Offset: 0x100 | Size: 0x10
	struct FString th; // Offset: 0x110 | Size: 0x10
	struct FString it; // Offset: 0x120 | Size: 0x10
	struct FString pl; // Offset: 0x130 | Size: 0x10
	struct FString po; // Offset: 0x140 | Size: 0x10
	struct FString Op; // Offset: 0x150 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarTables_LookAtCameras
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_LookAtCameras : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_LookAtCameras> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_LookAtCameras
// Inherited Bytes: 0x10 | Struct Size: 0x28
struct FSolarTablesData_LookAtCameras : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	int32_t MiniDistance; // Offset: 0x10 | Size: 0x4
	float BorderRatio; // Offset: 0x14 | Size: 0x4
	int32_t FOV; // Offset: 0x18 | Size: 0x4
	int32_t Pitch; // Offset: 0x1c | Size: 0x4
	int32_t InitAngleWithMainDir; // Offset: 0x20 | Size: 0x4
	float BlendAlpha; // Offset: 0x24 | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarTables_MapMarkIcon
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_MapMarkIcon : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_MapMarkIcon> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_MapMarkIcon
// Inherited Bytes: 0x10 | Struct Size: 0x30
struct FSolarTablesData_MapMarkIcon : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	struct FString AtlasPath; // Offset: 0x10 | Size: 0x10
	struct TArray<float> IconSize; // Offset: 0x20 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarTables_MatchRule
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_MatchRule : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_MatchRule> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_MatchRule
// Inherited Bytes: 0x10 | Struct Size: 0x70
struct FSolarTablesData_MatchRule : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	int32_t MatchType; // Offset: 0x10 | Size: 0x4
	int32_t MinPlayer; // Offset: 0x14 | Size: 0x4
	int32_t MaxPlayer; // Offset: 0x18 | Size: 0x4
	int32_t NumMode; // Offset: 0x1c | Size: 0x4
	int32_t StopMatchTime; // Offset: 0x20 | Size: 0x4
	struct TArray<int32_t> PlayerStructure; // Offset: 0x28 | Size: 0x10
	int32_t MinGroup; // Offset: 0x38 | Size: 0x4
	int32_t EloSettleType; // Offset: 0x3c | Size: 0x4
	int32_t RankSettleType; // Offset: 0x40 | Size: 0x4
	int32_t groupid; // Offset: 0x44 | Size: 0x4
	int32_t RankGroupNameID; // Offset: 0x48 | Size: 0x4
	bool MatchSameBattle; // Offset: 0x4c | Size: 0x1
	char pad_0x4D[0x3]; // Offset: 0x4d | Size: 0x3
	int32_t KeepMatchTimeID; // Offset: 0x50 | Size: 0x4
	int32_t OBNum; // Offset: 0x54 | Size: 0x4
	bool MaxPlayerStopMatch; // Offset: 0x58 | Size: 0x1
	char pad_0x59[0x3]; // Offset: 0x59 | Size: 0x3
	int32_t StatisticsType; // Offset: 0x5c | Size: 0x4
	int32_t HistoryModeType; // Offset: 0x60 | Size: 0x4
	bool HeroCombatAbility; // Offset: 0x64 | Size: 0x1
	char pad_0x65[0x3]; // Offset: 0x65 | Size: 0x3
	int32_t RestartMatchTime; // Offset: 0x68 | Size: 0x4
	char pad_0x6C[0x4]; // Offset: 0x6c | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarTables_MaterialProperty
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_MaterialProperty : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_MaterialProperty> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_MaterialProperty
// Inherited Bytes: 0x10 | Struct Size: 0x68
struct FSolarTablesData_MaterialProperty : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	struct FSolarTablesLocalText Name; // Offset: 0x10 | Size: 0x4
	struct FString Icon; // Offset: 0x18 | Size: 0x10
	struct FSolarTablesLocalText Info; // Offset: 0x28 | Size: 0x4
	int32_t Quality; // Offset: 0x2c | Size: 0x4
	int32_t ItemClass; // Offset: 0x30 | Size: 0x4
	int32_t ItemType; // Offset: 0x34 | Size: 0x4
	bool ShowInStorage; // Offset: 0x38 | Size: 0x1
	bool IfUse; // Offset: 0x39 | Size: 0x1
	bool IfRecycle; // Offset: 0x3a | Size: 0x1
	enum class ESolarTablesEnum_StackType StackType; // Offset: 0x3b | Size: 0x1
	char pad_0x3C[0x4]; // Offset: 0x3c | Size: 0x4
	struct TArray<int32_t> JumpLink; // Offset: 0x40 | Size: 0x10
	int32_t Prize; // Offset: 0x50 | Size: 0x4
	bool IfCollection; // Offset: 0x54 | Size: 0x1
	char pad_0x55[0x3]; // Offset: 0x55 | Size: 0x3
	int32_t Level; // Offset: 0x58 | Size: 0x4
	struct FSolarTablesLocalText CoverName; // Offset: 0x5c | Size: 0x4
	int32_t Substitution; // Offset: 0x60 | Size: 0x4
	char pad_0x64[0x4]; // Offset: 0x64 | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarTables_NameCardBackground
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_NameCardBackground : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_NameCardBackground> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_NameCardBackground
// Inherited Bytes: 0x10 | Struct Size: 0x48
struct FSolarTablesData_NameCardBackground : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	int32_t ItemID; // Offset: 0x10 | Size: 0x4
	struct FSolarTablesLocalText Name; // Offset: 0x14 | Size: 0x4
	int32_t ShopID; // Offset: 0x18 | Size: 0x4
	int32_t Exclusive; // Offset: 0x1c | Size: 0x4
	int32_t IsAIEquiped; // Offset: 0x20 | Size: 0x4
	struct FString BackgroundPath; // Offset: 0x28 | Size: 0x10
	struct FString BackgroundTexturePath; // Offset: 0x38 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarTables_NameCardPose
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_NameCardPose : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_NameCardPose> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_NameCardPose
// Inherited Bytes: 0x10 | Struct Size: 0x78
struct FSolarTablesData_NameCardPose : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	int32_t ItemID; // Offset: 0x10 | Size: 0x4
	struct FSolarTablesLocalText Name; // Offset: 0x14 | Size: 0x4
	int32_t ShopID; // Offset: 0x18 | Size: 0x4
	int32_t Exclusive; // Offset: 0x1c | Size: 0x4
	int32_t IsAIEquiped; // Offset: 0x20 | Size: 0x4
	struct FString PosePath; // Offset: 0x28 | Size: 0x10
	struct FString PosePath_M; // Offset: 0x38 | Size: 0x10
	struct FString PosePath_F; // Offset: 0x48 | Size: 0x10
	struct FString PosePath_MCP; // Offset: 0x58 | Size: 0x10
	struct FString PosePath_FFM; // Offset: 0x68 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarTables_ObGift
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_ObGift : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_ObGift> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_ObGift
// Inherited Bytes: 0x10 | Struct Size: 0x70
struct FSolarTablesData_ObGift : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	int32_t gift_type; // Offset: 0x10 | Size: 0x4
	struct FString item_name; // Offset: 0x18 | Size: 0x10
	struct FString item_back_res; // Offset: 0x28 | Size: 0x10
	struct FString item_text_res; // Offset: 0x38 | Size: 0x10
	int32_t gift_hot_num; // Offset: 0x48 | Size: 0x4
	int32_t currency_type; // Offset: 0x4c | Size: 0x4
	int32_t item_price; // Offset: 0x50 | Size: 0x4
	float item_back; // Offset: 0x54 | Size: 0x4
	int32_t item_show_time; // Offset: 0x58 | Size: 0x4
	int32_t item_id; // Offset: 0x5c | Size: 0x4
	int32_t small_time; // Offset: 0x60 | Size: 0x4
	int32_t interact_num; // Offset: 0x64 | Size: 0x4
	int32_t CD; // Offset: 0x68 | Size: 0x4
	char pad_0x6C[0x4]; // Offset: 0x6c | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarTables_OBSubtitle_Action2Feature
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_OBSubtitle_Action2Feature : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_OBSubtitle_Action2Feature> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_OBSubtitle_Action2Feature
// Inherited Bytes: 0x10 | Struct Size: 0x40
struct FSolarTablesData_OBSubtitle_Action2Feature : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	struct FString ActionName; // Offset: 0x10 | Size: 0x10
	int32_t Priority; // Offset: 0x20 | Size: 0x4
	int32_t DefualtEmotion; // Offset: 0x24 | Size: 0x4
	int32_t MaxSuccessiveCount; // Offset: 0x28 | Size: 0x4
	struct TArray<int32_t> FeatureList; // Offset: 0x30 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarTables_OBSubtitle_Emotion2Pattern
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_OBSubtitle_Emotion2Pattern : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_OBSubtitle_Emotion2Pattern> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_OBSubtitle_Emotion2Pattern
// Inherited Bytes: 0x10 | Struct Size: 0x28
struct FSolarTablesData_OBSubtitle_Emotion2Pattern : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	int32_t EmotionLevel; // Offset: 0x10 | Size: 0x4
	struct TArray<int32_t> PatternList; // Offset: 0x18 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarTables_OBSubtitle_Feature2Emotion
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_OBSubtitle_Feature2Emotion : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_OBSubtitle_Feature2Emotion> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_OBSubtitle_Feature2Emotion
// Inherited Bytes: 0x10 | Struct Size: 0x30
struct FSolarTablesData_OBSubtitle_Feature2Emotion : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	struct FString FeatureName; // Offset: 0x10 | Size: 0x10
	struct TArray<int32_t> EmotionList; // Offset: 0x20 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarTables_OBSubtitle_Pattern2Subtitle
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_OBSubtitle_Pattern2Subtitle : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_OBSubtitle_Pattern2Subtitle> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_OBSubtitle_Pattern2Subtitle
// Inherited Bytes: 0x10 | Struct Size: 0x30
struct FSolarTablesData_OBSubtitle_Pattern2Subtitle : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	struct TArray<struct FSolarTablesLocalText> SubTitleList; // Offset: 0x10 | Size: 0x10
	struct TArray<int32_t> ENLengthList; // Offset: 0x20 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarTables_Outcome
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_Outcome : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_Outcome> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_Outcome
// Inherited Bytes: 0x10 | Struct Size: 0x70
struct FSolarTablesData_Outcome : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	int32_t OutcomeType; // Offset: 0x10 | Size: 0x4
	int32_t MaxTimes; // Offset: 0x14 | Size: 0x4
	int32_t MinTimes; // Offset: 0x18 | Size: 0x4
	struct TArray<int32_t> Contents; // Offset: 0x20 | Size: 0x10
	struct TArray<int32_t> LimitId; // Offset: 0x30 | Size: 0x10
	struct TArray<int32_t> LimitIdMax; // Offset: 0x40 | Size: 0x10
	struct TArray<int32_t> LimitIdMin; // Offset: 0x50 | Size: 0x10
	struct FString Refresh; // Offset: 0x60 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarTables_OutcomeContent
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_OutcomeContent : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_OutcomeContent> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_OutcomeContent
// Inherited Bytes: 0x10 | Struct Size: 0x38
struct FSolarTablesData_OutcomeContent : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	int32_t ItemID; // Offset: 0x10 | Size: 0x4
	int32_t Weight; // Offset: 0x14 | Size: 0x4
	struct TArray<int32_t> RandomNum; // Offset: 0x18 | Size: 0x10
	int32_t MaxTimes; // Offset: 0x28 | Size: 0x4
	int32_t MinTimes; // Offset: 0x2c | Size: 0x4
	int32_t RelatedContentID; // Offset: 0x30 | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarTables_OutcomeSet
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_OutcomeSet : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_OutcomeSet> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_OutcomeSet
// Inherited Bytes: 0x10 | Struct Size: 0x30
struct FSolarTablesData_OutcomeSet : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	struct TArray<int32_t> OutcomeRef; // Offset: 0x10 | Size: 0x10
	struct TArray<int32_t> GlobalOutcome; // Offset: 0x20 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarTables_PickupPriorityItem
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_PickupPriorityItem : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_PickupPriorityItem> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_PickupPriorityItem
// Inherited Bytes: 0x10 | Struct Size: 0x18
struct FSolarTablesData_PickupPriorityItem : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	int32_t PriorityValue; // Offset: 0x10 | Size: 0x4
	int32_t MutiAutoPickup; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarTables_PickupPriorityWeaponPart
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_PickupPriorityWeaponPart : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_PickupPriorityWeaponPart> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_PickupPriorityWeaponPart
// Inherited Bytes: 0x10 | Struct Size: 0x18
struct FSolarTablesData_PickupPriorityWeaponPart : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	int32_t PriorityValue; // Offset: 0x10 | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarTables_PlayerOperationListLayout
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_PlayerOperationListLayout : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_PlayerOperationListLayout> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_PlayerOperationListLayout
// Inherited Bytes: 0x10 | Struct Size: 0x40
struct FSolarTablesData_PlayerOperationListLayout : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	struct FString UIName; // Offset: 0x10 | Size: 0x10
	int32_t Normal; // Offset: 0x20 | Size: 0x4
	int32_t Driver; // Offset: 0x24 | Size: 0x4
	int32_t Passgner; // Offset: 0x28 | Size: 0x4
	int32_t EquipVehicleWeapon; // Offset: 0x2c | Size: 0x4
	int32_t Cruising; // Offset: 0x30 | Size: 0x4
	int32_t Parachuting; // Offset: 0x34 | Size: 0x4
	int32_t Swimming; // Offset: 0x38 | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarTables_QuickChat
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_QuickChat : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_QuickChat> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_QuickChat
// Inherited Bytes: 0x10 | Struct Size: 0x158
struct FSolarTablesData_QuickChat : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	int32_t LocalizationID; // Offset: 0x10 | Size: 0x4
	struct FString zh_CN; // Offset: 0x18 | Size: 0x10
	struct FString en; // Offset: 0x28 | Size: 0x10
	struct FString pt; // Offset: 0x38 | Size: 0x10
	struct FString ind; // Offset: 0x48 | Size: 0x10
	struct FString fr; // Offset: 0x58 | Size: 0x10
	struct FString de; // Offset: 0x68 | Size: 0x10
	struct FString ru; // Offset: 0x78 | Size: 0x10
	struct FString ar; // Offset: 0x88 | Size: 0x10
	struct FString es; // Offset: 0x98 | Size: 0x10
	struct FString hi; // Offset: 0xa8 | Size: 0x10
	struct FString it; // Offset: 0xb8 | Size: 0x10
	struct FString ja; // Offset: 0xc8 | Size: 0x10
	struct FString ko; // Offset: 0xd8 | Size: 0x10
	struct FString ms; // Offset: 0xe8 | Size: 0x10
	struct FString pl; // Offset: 0xf8 | Size: 0x10
	struct FString th; // Offset: 0x108 | Size: 0x10
	struct FString tl; // Offset: 0x118 | Size: 0x10
	struct FString tr; // Offset: 0x128 | Size: 0x10
	struct FString vi; // Offset: 0x138 | Size: 0x10
	struct FString zh_TW; // Offset: 0x148 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarTables_QuickVoice
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_QuickVoice : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_QuickVoice> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_QuickVoice
// Inherited Bytes: 0x10 | Struct Size: 0x68
struct FSolarTablesData_QuickVoice : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	struct FString Icon; // Offset: 0x10 | Size: 0x10
	int32_t LocalizationID; // Offset: 0x20 | Size: 0x4
	struct FString AudioEventName; // Offset: 0x28 | Size: 0x10
	struct FString AudioEventNameFemale; // Offset: 0x38 | Size: 0x10
	int32_t IsMarkIcon; // Offset: 0x48 | Size: 0x4
	int32_t PassiveTriggeredCD; // Offset: 0x4c | Size: 0x4
	int32_t PassiveTriggeredProb; // Offset: 0x50 | Size: 0x4
	char pad_0x54[0x4]; // Offset: 0x54 | Size: 0x4
	struct FString ReplyMessageID; // Offset: 0x58 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarTables_RankLevel
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_RankLevel : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_RankLevel> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_RankLevel
// Inherited Bytes: 0x10 | Struct Size: 0x80
struct FSolarTablesData_RankLevel : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	int32_t RankID; // Offset: 0x10 | Size: 0x4
	struct FSolarTablesLocalText RankName; // Offset: 0x14 | Size: 0x4
	struct FSolarTablesLocalText Name; // Offset: 0x18 | Size: 0x4
	int32_t LevelID; // Offset: 0x1c | Size: 0x4
	int32_t RankStart; // Offset: 0x20 | Size: 0x4
	int32_t RankEnd; // Offset: 0x24 | Size: 0x4
	int32_t RankProtect; // Offset: 0x28 | Size: 0x4
	int32_t FrustrationValue; // Offset: 0x2c | Size: 0x4
	int32_t RankReduce; // Offset: 0x30 | Size: 0x4
	struct FString Icon; // Offset: 0x38 | Size: 0x10
	struct FString Icon_s; // Offset: 0x48 | Size: 0x10
	struct FString IconWord; // Offset: 0x58 | Size: 0x10
	struct FString IconWord_s; // Offset: 0x68 | Size: 0x10
	int32_t RandomLowerLimit; // Offset: 0x78 | Size: 0x4
	int32_t RandomUpLimit; // Offset: 0x7c | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarTables_RankMatch
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_RankMatch : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_RankMatch> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_RankMatch
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTablesData_RankMatch : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	int32_t MatchType; // Offset: 0x10 | Size: 0x4
	int32_t NumOfAI; // Offset: 0x14 | Size: 0x4
	int32_t AiLevel; // Offset: 0x18 | Size: 0x4
	struct FString AILevelConfig; // Offset: 0x20 | Size: 0x10
	int32_t AITeamPresetsID; // Offset: 0x30 | Size: 0x4
	bool EnableTeamManager; // Offset: 0x34 | Size: 0x1
	char pad_0x35[0x3]; // Offset: 0x35 | Size: 0x3
	struct TArray<int32_t> MLApplication; // Offset: 0x38 | Size: 0x10
	int32_t MLApply; // Offset: 0x48 | Size: 0x4
	int32_t MaxWait; // Offset: 0x4c | Size: 0x4
	int32_t StopMatchTime; // Offset: 0x50 | Size: 0x4
	bool HasAITeammate; // Offset: 0x54 | Size: 0x1
	bool AIAccompany; // Offset: 0x55 | Size: 0x1
	char pad_0x56[0x2]; // Offset: 0x56 | Size: 0x2
	int32_t AIAccompanyTimeline; // Offset: 0x58 | Size: 0x4
	int32_t MinPlayer; // Offset: 0x5c | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarTables_Rescue
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_Rescue : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_Rescue> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_Rescue
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTablesData_Rescue : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	float RescueMaxDistance; // Offset: 0x10 | Size: 0x4
	float FallenHp; // Offset: 0x14 | Size: 0x4
	float RescueRecoveryHp; // Offset: 0x18 | Size: 0x4
	int32_t RescueTime; // Offset: 0x1c | Size: 0x4
	struct TArray<float> FallenLossHp; // Offset: 0x20 | Size: 0x10
	struct TArray<float> FallenMoveLossHp; // Offset: 0x30 | Size: 0x10
	float FallenMoveSpeed; // Offset: 0x40 | Size: 0x4
	float RescueMoveSpeed; // Offset: 0x44 | Size: 0x4
	float InvincibleTime; // Offset: 0x48 | Size: 0x4
	float MaxRescueAngle; // Offset: 0x4c | Size: 0x4
	float RemindRescueCooldownTime; // Offset: 0x50 | Size: 0x4
	float RemindRescueSoundCD; // Offset: 0x54 | Size: 0x4
	int32_t RemindRescueSoundIndex; // Offset: 0x58 | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarTables_SecondMode
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_SecondMode : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_SecondMode> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_SecondMode
// Inherited Bytes: 0x10 | Struct Size: 0x20
struct FSolarTablesData_SecondMode : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	int32_t UpperLimit; // Offset: 0x10 | Size: 0x4
	float RestoreProgressPerSec; // Offset: 0x14 | Size: 0x4
	float RestoreProgressPerKill; // Offset: 0x18 | Size: 0x4
	float RestoreProgressPerDmg; // Offset: 0x1c | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarTables_ShieldProperty
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_ShieldProperty : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_ShieldProperty> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_ShieldProperty
// Inherited Bytes: 0x10 | Struct Size: 0xd8
struct FSolarTablesData_ShieldProperty : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	struct FSolarTablesLocalText Name; // Offset: 0x10 | Size: 0x4
	struct FString Icon; // Offset: 0x18 | Size: 0x10
	struct FSolarTablesLocalText Info; // Offset: 0x28 | Size: 0x4
	int32_t Quality; // Offset: 0x2c | Size: 0x4
	int32_t ItemType; // Offset: 0x30 | Size: 0x4
	bool IfReplace; // Offset: 0x34 | Size: 0x1
	char pad_0x35[0x3]; // Offset: 0x35 | Size: 0x3
	int32_t Pile; // Offset: 0x38 | Size: 0x4
	char pad_0x3C[0x4]; // Offset: 0x3c | Size: 0x4
	struct FString AbilityBP; // Offset: 0x40 | Size: 0x10
	struct FString ItemBP; // Offset: 0x50 | Size: 0x10
	struct FString AudioEventName; // Offset: 0x60 | Size: 0x10
	bool UseOnPickup; // Offset: 0x70 | Size: 0x1
	char pad_0x71[0x3]; // Offset: 0x71 | Size: 0x3
	float MaxValue; // Offset: 0x74 | Size: 0x4
	float RecoverySpeed; // Offset: 0x78 | Size: 0x4
	float EnergyCost; // Offset: 0x7c | Size: 0x4
	int32_t CoolDownTime; // Offset: 0x80 | Size: 0x4
	float RecoveryDuration; // Offset: 0x84 | Size: 0x4
	float RecoveryDurationB; // Offset: 0x88 | Size: 0x4
	float RecoveryAmount; // Offset: 0x8c | Size: 0x4
	float EnergyConsumption; // Offset: 0x90 | Size: 0x4
	int32_t ShieldWorth; // Offset: 0x94 | Size: 0x4
	struct FString Sketch; // Offset: 0x98 | Size: 0x10
	int32_t SketchLevel; // Offset: 0xa8 | Size: 0x4
	int32_t QualityColor; // Offset: 0xac | Size: 0x4
	int32_t AutoRecharge; // Offset: 0xb0 | Size: 0x4
	float LeaveCombatTime; // Offset: 0xb4 | Size: 0x4
	float AutoRechargeInterval; // Offset: 0xb8 | Size: 0x4
	float AutoRechargeValue; // Offset: 0xbc | Size: 0x4
	int32_t NextUpgradeCost; // Offset: 0xc0 | Size: 0x4
	int32_t NextUpgradeItemID; // Offset: 0xc4 | Size: 0x4
	int32_t UpgradeItemCost; // Offset: 0xc8 | Size: 0x4
	float UpgradeTimeCost; // Offset: 0xcc | Size: 0x4
	float ShieldRechargeDelayTime; // Offset: 0xd0 | Size: 0x4
	float ShieldRecoveryTime; // Offset: 0xd4 | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarTables_Skin
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_Skin : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_Skin> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_Skin
// Inherited Bytes: 0x10 | Struct Size: 0xe8
struct FSolarTablesData_Skin : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	int32_t CharaId; // Offset: 0x10 | Size: 0x4
	struct FSolarTablesLocalText Name; // Offset: 0x14 | Size: 0x4
	bool IfShow; // Offset: 0x18 | Size: 0x1
	char pad_0x1D[0x3]; // Offset: 0x1d | Size: 0x3
	struct FString BeginTime; // Offset: 0x20 | Size: 0x10
	int32_t ShopPropertyid; // Offset: 0x30 | Size: 0x4
	int32_t ItemID; // Offset: 0x34 | Size: 0x4
	struct FString MVPDataAssetPath; // Offset: 0x38 | Size: 0x10
	struct FString MVPSequencePath; // Offset: 0x48 | Size: 0x10
	int32_t SceneId; // Offset: 0x58 | Size: 0x4
	bool IsMVP; // Offset: 0x5c | Size: 0x1
	char pad_0x5D[0x3]; // Offset: 0x5d | Size: 0x3
	struct FString CharacterSkinResource; // Offset: 0x60 | Size: 0x10
	struct FString CharacterLobbySkinResource; // Offset: 0x70 | Size: 0x10
	struct FString ChunkDir; // Offset: 0x80 | Size: 0x10
	int32_t ChunkID; // Offset: 0x90 | Size: 0x4
	char pad_0x94[0x4]; // Offset: 0x94 | Size: 0x4
	struct FString CharacterLowSkinResource; // Offset: 0x98 | Size: 0x10
	struct TArray<int32_t> CharacterPrologue; // Offset: 0xa8 | Size: 0x10
	struct FString CharacterProtrait; // Offset: 0xb8 | Size: 0x10
	int32_t SkinSort; // Offset: 0xc8 | Size: 0x4
	int32_t MVPSettlementStartFrame; // Offset: 0xcc | Size: 0x4
	int32_t MVPSettlementEndFrame; // Offset: 0xd0 | Size: 0x4
	int32_t MVPAnchorPoint; // Offset: 0xd4 | Size: 0x4
	struct FString IdleShowSequencePath; // Offset: 0xd8 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarTables_Tables
// Inherited Bytes: 0x0 | Struct Size: 0x2e88
struct FSolarTables_Tables {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
	struct FSolarTables_AccountFixedExp AccountFixedExp; // Offset: 0x8 | Size: 0x60
	struct FSolarTables_AccountFlag AccountFlag; // Offset: 0x68 | Size: 0x60
	struct FSolarTables_Airline Airline; // Offset: 0xc8 | Size: 0x60
	struct FSolarTables_Armory Armory; // Offset: 0x128 | Size: 0x60
	struct FSolarTables_BattleUpgradeContent BattleUpgradeContent; // Offset: 0x188 | Size: 0x60
	struct FSolarTables_BattleUpgradeEffect BattleUpgradeEffect; // Offset: 0x1e8 | Size: 0x60
	struct FSolarTables_BattleUpgradeEffectPool BattleUpgradeEffectPool; // Offset: 0x248 | Size: 0x60
	struct FSolarTables_BattleEndRankSettlement BattleEndRankSettlement; // Offset: 0x2a8 | Size: 0x60
	struct FSolarTables_BpAward BpAward; // Offset: 0x308 | Size: 0x60
	struct FSolarTables_Behavior Behavior; // Offset: 0x368 | Size: 0x60
	struct FSolarTables_EscapeExp EscapeExp; // Offset: 0x3c8 | Size: 0x60
	struct FSolarTables_CaseToggleAlphabet CaseToggleAlphabet; // Offset: 0x428 | Size: 0x60
	struct FSolarTables_UnitCharacter UnitCharacter; // Offset: 0x488 | Size: 0x60
	struct FSolarTables_CharacterAbility CharacterAbility; // Offset: 0x4e8 | Size: 0x60
	struct FSolarTables_CharacterPassiveAbility CharacterPassiveAbility; // Offset: 0x548 | Size: 0x60
	struct FSolarTables_GetPoint GetPoint; // Offset: 0x5a8 | Size: 0x60
	struct FSolarTables_ChestSpawn ChestSpawn; // Offset: 0x608 | Size: 0x60
	struct FSolarTables_ChestSpawnGroup ChestSpawnGroup; // Offset: 0x668 | Size: 0x60
	struct FSolarTables_ClanFlag ClanFlag; // Offset: 0x6c8 | Size: 0x60
	struct FSolarTables_DayAndNight DayAndNight; // Offset: 0x728 | Size: 0x60
	struct FSolarTables_DsVariableRange DsVariableRange; // Offset: 0x788 | Size: 0x60
	struct FSolarTables_EShop EShop; // Offset: 0x7e8 | Size: 0x60
	struct FSolarTables_EShopDemoModel EShopDemoModel; // Offset: 0x848 | Size: 0x60
	struct FSolarTables_EShopGoodsPool EShopGoodsPool; // Offset: 0x8a8 | Size: 0x60
	struct FSolarTables_EShopGoodsPoolGroup EShopGoodsPoolGroup; // Offset: 0x908 | Size: 0x60
	struct FSolarTables_EShopSpawn EShopSpawn; // Offset: 0x968 | Size: 0x60
	struct FSolarTables_BattleRoyaleMode BattleRoyaleMode; // Offset: 0x9c8 | Size: 0x60
	struct FSolarTables_GameModeGroup GameModeGroup; // Offset: 0xa28 | Size: 0x60
	struct FSolarTables_GameModeMain GameModeMain; // Offset: 0xa88 | Size: 0x60
	struct FSolarTables_OutcomeSet OutcomeSet; // Offset: 0xae8 | Size: 0x60
	struct FSolarTables_GameTimeLine GameTimeLine; // Offset: 0xb48 | Size: 0x60
	struct FSolarTables_GlobalOutcome GlobalOutcome; // Offset: 0xba8 | Size: 0x60
	struct FSolarTables_GlobalSensitivity GlobalSensitivity; // Offset: 0xc08 | Size: 0x60
	struct FSolarTables_HeroPowerFormula HeroPowerFormula; // Offset: 0xc68 | Size: 0x60
	struct FSolarTables_InputAction InputAction; // Offset: 0xcc8 | Size: 0x60
	struct FSolarTables_InputMapping InputMapping; // Offset: 0xd28 | Size: 0x60
	struct FSolarTables_Item Item; // Offset: 0xd88 | Size: 0x60
	struct FSolarTables_BackpackProperty BackpackProperty; // Offset: 0xde8 | Size: 0x60
	struct FSolarTables_BackpackTrailProperty BackpackTrailProperty; // Offset: 0xe48 | Size: 0x60
	struct FSolarTables_CapsuleProperty CapsuleProperty; // Offset: 0xea8 | Size: 0x60
	struct FSolarTables_Dance Dance; // Offset: 0xf08 | Size: 0x60
	struct FSolarTables_Emote Emote; // Offset: 0xf68 | Size: 0x60
	struct FSolarTables_KillNotify KillNotify; // Offset: 0xfc8 | Size: 0x60
	struct FSolarTables_MaterialProperty MaterialProperty; // Offset: 0x1028 | Size: 0x60
	struct FSolarTables_VehicleSkinProperty VehicleSkinProperty; // Offset: 0x1088 | Size: 0x60
	struct FSolarTables_Voice Voice; // Offset: 0x10e8 | Size: 0x60
	struct FSolarTables_WeaponSkinProperty WeaponSkinProperty; // Offset: 0x1148 | Size: 0x60
	struct FSolarTables_ItemCustomType ItemCustomType; // Offset: 0x11a8 | Size: 0x60
	struct FSolarTables_ItemInBattle ItemInBattle; // Offset: 0x1208 | Size: 0x60
	struct FSolarTables_ArmorProperty ArmorProperty; // Offset: 0x1268 | Size: 0x60
	struct FSolarTables_Chest Chest; // Offset: 0x12c8 | Size: 0x60
	struct FSolarTables_Collect Collect; // Offset: 0x1328 | Size: 0x60
	struct FSolarTables_EnergyProperty EnergyProperty; // Offset: 0x1388 | Size: 0x60
	struct FSolarTables_ExtraEnergyProperty ExtraEnergyProperty; // Offset: 0x13e8 | Size: 0x60
	struct FSolarTables_GunProperty GunProperty; // Offset: 0x1448 | Size: 0x60
	struct FSolarTables_ItemBehavior ItemBehavior; // Offset: 0x14a8 | Size: 0x60
	struct FSolarTables_ItemWeaponParts ItemWeaponParts; // Offset: 0x1508 | Size: 0x60
	struct FSolarTables_JetPackModuleProperty JetPackModuleProperty; // Offset: 0x1568 | Size: 0x60
	struct FSolarTables_ShieldProperty ShieldProperty; // Offset: 0x15c8 | Size: 0x60
	struct FSolarTables_ItemQuality ItemQuality; // Offset: 0x1628 | Size: 0x60
	struct FSolarTables_ItemSound ItemSound; // Offset: 0x1688 | Size: 0x60
	struct FSolarTables_LobbyAutoDownload LobbyAutoDownload; // Offset: 0x16e8 | Size: 0x60
	struct FSolarTables_LanguageSwitcher LanguageSwitcher; // Offset: 0x1748 | Size: 0x60
	struct FSolarTables_Localization Localization; // Offset: 0x17a8 | Size: 0x60
	struct FSolarTables_Localization_BattleUI Localization_BattleUI; // Offset: 0x1808 | Size: 0x60
	struct FSolarTables_Localization_EventSystem Localization_EventSystem; // Offset: 0x1868 | Size: 0x60
	struct FSolarTables_Localization_General Localization_General; // Offset: 0x18c8 | Size: 0x60
	struct FSolarTables_Localization_Heroes Localization_Heroes; // Offset: 0x1928 | Size: 0x60
	struct FSolarTables_Localization_Item Localization_Item; // Offset: 0x1988 | Size: 0x60
	struct FSolarTables_Localization_Tournament Localization_Tournament; // Offset: 0x19e8 | Size: 0x60
	struct FSolarTables_Localization_Uncategorized Localization_Uncategorized; // Offset: 0x1a48 | Size: 0x60
	struct FSolarTables_GameMap GameMap; // Offset: 0x1aa8 | Size: 0x60
	struct FSolarTables_MapMarkIcon MapMarkIcon; // Offset: 0x1b08 | Size: 0x60
	struct FSolarTables_MatchRule MatchRule; // Offset: 0x1b68 | Size: 0x60
	struct FSolarTables_RankMatch RankMatch; // Offset: 0x1bc8 | Size: 0x60
	struct FSolarTables_NameCardBackground NameCardBackground; // Offset: 0x1c28 | Size: 0x60
	struct FSolarTables_NameCardPose NameCardPose; // Offset: 0x1c88 | Size: 0x60
	struct FSolarTables_ObGift ObGift; // Offset: 0x1ce8 | Size: 0x60
	struct FSolarTables_OBSubtitle_Action2Feature OBSubtitle_Action2Feature; // Offset: 0x1d48 | Size: 0x60
	struct FSolarTables_OBSubtitle_Feature2Emotion OBSubtitle_Feature2Emotion; // Offset: 0x1da8 | Size: 0x60
	struct FSolarTables_OBSubtitle_Emotion2Pattern OBSubtitle_Emotion2Pattern; // Offset: 0x1e08 | Size: 0x60
	struct FSolarTables_OBSubtitle_Pattern2Subtitle OBSubtitle_Pattern2Subtitle; // Offset: 0x1e68 | Size: 0x60
	struct FSolarTables_Outcome Outcome; // Offset: 0x1ec8 | Size: 0x60
	struct FSolarTables_OutcomeContent OutcomeContent; // Offset: 0x1f28 | Size: 0x60
	struct FSolarTables_PickupPriorityItem PickupPriorityItem; // Offset: 0x1f88 | Size: 0x60
	struct FSolarTables_PickupPriorityWeaponPart PickupPriorityWeaponPart; // Offset: 0x1fe8 | Size: 0x60
	struct FSolarTables_CharacterVoiceover CharacterVoiceover; // Offset: 0x2048 | Size: 0x60
	struct FSolarTables_QuickChat QuickChat; // Offset: 0x20a8 | Size: 0x60
	struct FSolarTables_QuickVoice QuickVoice; // Offset: 0x2108 | Size: 0x60
	struct FSolarTables_VODownload VODownload; // Offset: 0x2168 | Size: 0x60
	struct FSolarTables_RankLevel RankLevel; // Offset: 0x21c8 | Size: 0x60
	struct FSolarTables_AutoDirector AutoDirector; // Offset: 0x2228 | Size: 0x60
	struct FSolarTables_AutoDirectorActivityScore AutoDirectorActivityScore; // Offset: 0x2288 | Size: 0x60
	struct FSolarTables_CircularCameras CircularCameras; // Offset: 0x22e8 | Size: 0x60
	struct FSolarTables_HighlightRating HighlightRating; // Offset: 0x2348 | Size: 0x60
	struct FSolarTables_HotSpot HotSpot; // Offset: 0x23a8 | Size: 0x60
	struct FSolarTables_LookAtCameras LookAtCameras; // Offset: 0x2408 | Size: 0x60
	struct FSolarTables_Rescue Rescue; // Offset: 0x2468 | Size: 0x60
	struct FSolarTables_Skin Skin; // Offset: 0x24c8 | Size: 0x60
	struct FSolarTables_Achievement Achievement; // Offset: 0x2528 | Size: 0x60
	struct FSolarTables_TaskProgress TaskProgress; // Offset: 0x2588 | Size: 0x60
	struct FSolarTables_TaskSystem TaskSystem; // Offset: 0x25e8 | Size: 0x60
	struct FSolarTables_PlayerOperationListLayout PlayerOperationListLayout; // Offset: 0x2648 | Size: 0x60
	struct FSolarTables_Variables Variables; // Offset: 0x26a8 | Size: 0x60
	struct FSolarTables_Vehicle Vehicle; // Offset: 0x2708 | Size: 0x60
	struct FSolarTables_VehicleSkin VehicleSkin; // Offset: 0x2768 | Size: 0x60
	struct FSolarTables_VehicleType VehicleType; // Offset: 0x27c8 | Size: 0x60
	struct FSolarTables_VehicleSpawn VehicleSpawn; // Offset: 0x2828 | Size: 0x60
	struct FSolarTables_VehicleSpawnGroup VehicleSpawnGroup; // Offset: 0x2888 | Size: 0x60
	struct FSolarTables_WarmGame WarmGame; // Offset: 0x28e8 | Size: 0x60
	struct FSolarTables_WarmGameMode WarmGameMode; // Offset: 0x2948 | Size: 0x60
	struct FSolarTables_WeaponDamage WeaponDamage; // Offset: 0x29a8 | Size: 0x60
	struct FSolarTables_Weapon Weapon; // Offset: 0x2a08 | Size: 0x60
	struct FSolarTables_WeaponAmmo WeaponAmmo; // Offset: 0x2a68 | Size: 0x60
	struct FSolarTables_WeaponBattleUpgrade WeaponBattleUpgrade; // Offset: 0x2ac8 | Size: 0x60
	struct FSolarTables_WeaponDefault WeaponDefault; // Offset: 0x2b28 | Size: 0x60
	struct FSolarTables_WeaponKillTip WeaponKillTip; // Offset: 0x2b88 | Size: 0x60
	struct FSolarTables_WeaponParts WeaponParts; // Offset: 0x2be8 | Size: 0x60
	struct FSolarTables_WeaponPartsOp WeaponPartsOp; // Offset: 0x2c48 | Size: 0x60
	struct FSolarTables_WeaponQuality WeaponQuality; // Offset: 0x2ca8 | Size: 0x60
	struct FSolarTables_SecondMode SecondMode; // Offset: 0x2d08 | Size: 0x60
	struct FSolarTables_WeaponSkin WeaponSkin; // Offset: 0x2d68 | Size: 0x60
	struct FSolarTables_WeaponSound WeaponSound; // Offset: 0x2dc8 | Size: 0x60
	struct FSolarTables_WeaponStatu WeaponStatu; // Offset: 0x2e28 | Size: 0x60
};

// Object: ScriptStruct Solarland.SolarTables_WeaponStatu
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_WeaponStatu : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_WeaponStatu> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_WeaponStatu
// Inherited Bytes: 0x10 | Struct Size: 0x30
struct FSolarTablesData_WeaponStatu : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	float Stand; // Offset: 0x10 | Size: 0x4
	float CrouchDown; // Offset: 0x14 | Size: 0x4
	float Still; // Offset: 0x18 | Size: 0x4
	float Run; // Offset: 0x1c | Size: 0x4
	float Spint; // Offset: 0x20 | Size: 0x4
	float Jump; // Offset: 0x24 | Size: 0x4
	float Fly; // Offset: 0x28 | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarTables_WeaponSound
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_WeaponSound : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_WeaponSound> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_WeaponSound
// Inherited Bytes: 0x10 | Struct Size: 0x4f0
struct FSolarTablesData_WeaponSound : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	struct FString Play_Fire_Auto_1P; // Offset: 0x10 | Size: 0x10
	struct FString Play_Fire_Auto_3P; // Offset: 0x20 | Size: 0x10
	struct FString Play_Fire_Auto_3P_Enemy; // Offset: 0x30 | Size: 0x10
	struct FString Stop_Fire_Auto_1P; // Offset: 0x40 | Size: 0x10
	struct FString Stop_Fire_Auto_3P; // Offset: 0x50 | Size: 0x10
	struct FString Stop_Fire_Auto_3P_Enemy; // Offset: 0x60 | Size: 0x10
	struct FString Play_Fire_Sigle_1P; // Offset: 0x70 | Size: 0x10
	struct FString Play_Fire_Sigle_3P; // Offset: 0x80 | Size: 0x10
	struct FString Play_Fire_Sigle_3P_Enemy; // Offset: 0x90 | Size: 0x10
	struct FString Play_Fire_Burst_1P; // Offset: 0xa0 | Size: 0x10
	struct FString Play_Fire_Burst_3P; // Offset: 0xb0 | Size: 0x10
	struct FString Play_Fire_Burst_3P_Enemy; // Offset: 0xc0 | Size: 0x10
	struct FString Stop_Fire_Burst_1P; // Offset: 0xd0 | Size: 0x10
	struct FString Stop_Fire_Burst_3P; // Offset: 0xe0 | Size: 0x10
	struct FString Stop_Fire_Burst_3P_Enemy; // Offset: 0xf0 | Size: 0x10
	struct FString Play_FIRE_LAST_1P; // Offset: 0x100 | Size: 0x10
	struct FString Play_FIRE_LAST_3P; // Offset: 0x110 | Size: 0x10
	struct FString Play_FIRE_LAST_3P_Enemy; // Offset: 0x120 | Size: 0x10
	struct FString Remain_Gun_RTPC_NAME; // Offset: 0x130 | Size: 0x10
	struct FString Play_Skill_Cast_1P; // Offset: 0x140 | Size: 0x10
	struct FString Play_Skill_Cast_3P; // Offset: 0x150 | Size: 0x10
	struct FString Play_Skill_Cast_3P_Enemy; // Offset: 0x160 | Size: 0x10
	struct FString Play_Fire_Lay_Tl_1P; // Offset: 0x170 | Size: 0x10
	struct FString Play_Fire_Lay_Tl_3P; // Offset: 0x180 | Size: 0x10
	struct FString Play_Fire_Lay_Tl_3P_Enemy; // Offset: 0x190 | Size: 0x10
	struct FString Play_Land_Fly_Once_3P; // Offset: 0x1a0 | Size: 0x10
	struct FString Play_Land_Fly_Once_3P_Enemy; // Offset: 0x1b0 | Size: 0x10
	struct FString Play_Land_Fly_Loop_1P; // Offset: 0x1c0 | Size: 0x10
	struct FString Play_Land_Fly_Loop_3P; // Offset: 0x1d0 | Size: 0x10
	struct FString Play_Land_Fly_Loop_3P_Enemy; // Offset: 0x1e0 | Size: 0x10
	struct FString Stop_Land_Fly_Loop_1P; // Offset: 0x1f0 | Size: 0x10
	struct FString Stop_Land_Fly_Loop_3P; // Offset: 0x200 | Size: 0x10
	struct FString Stop_Land_Fly_Loop_3P_Enemy; // Offset: 0x210 | Size: 0x10
	struct FString Play_Land_Common_Hit_1P; // Offset: 0x220 | Size: 0x10
	struct FString Play_Land_Common_Hit_3P; // Offset: 0x230 | Size: 0x10
	struct FString Play_Land_Common_Hit_3P_Enemy; // Offset: 0x240 | Size: 0x10
	struct FString Play_Fire_Overload_1P; // Offset: 0x250 | Size: 0x10
	struct FString Play_Fire_Overload_3P; // Offset: 0x260 | Size: 0x10
	struct FString Play_Fire_Overload_3P_Enemy; // Offset: 0x270 | Size: 0x10
	struct FString Play_Reload_01_1P; // Offset: 0x280 | Size: 0x10
	struct FString Play_Reload_01_3P; // Offset: 0x290 | Size: 0x10
	struct FString Play_Reload_01_3P_Enemy; // Offset: 0x2a0 | Size: 0x10
	struct FString Play_Reload_02_1P; // Offset: 0x2b0 | Size: 0x10
	struct FString Play_Reload_02_3P; // Offset: 0x2c0 | Size: 0x10
	struct FString Play_Reload_02_3P_Enemy; // Offset: 0x2d0 | Size: 0x10
	struct FString Play_Reload_03_1P; // Offset: 0x2e0 | Size: 0x10
	struct FString Play_Reload_03_3P; // Offset: 0x2f0 | Size: 0x10
	struct FString Play_Reload_03_3P_Enemy; // Offset: 0x300 | Size: 0x10
	struct FString Play_Bolt_1P; // Offset: 0x310 | Size: 0x10
	struct FString Play_Bolt_3P; // Offset: 0x320 | Size: 0x10
	struct FString Play_Bolt_3P_Enemy; // Offset: 0x330 | Size: 0x10
	struct FString Play_Vehicle_Gun_On_3P; // Offset: 0x340 | Size: 0x10
	struct FString Play_Vehicle_Gun_On_3P_Enemy; // Offset: 0x350 | Size: 0x10
	struct FString Play_Vehicle_Gun_Loop_3P; // Offset: 0x360 | Size: 0x10
	struct FString Play_Vehicle_Gun_Loop_3P_Enemy; // Offset: 0x370 | Size: 0x10
	struct FString Play_Vehicle_Gun_Off_3P; // Offset: 0x380 | Size: 0x10
	struct FString Play_Vehicle_Gun_Off_3P_Enemy; // Offset: 0x390 | Size: 0x10
	struct FString Play_Fire_Auto_1P_Mute; // Offset: 0x3a0 | Size: 0x10
	struct FString Play_Fire_Auto_3P_Mute; // Offset: 0x3b0 | Size: 0x10
	struct FString Play_Fire_Auto_3P_Enemy_Mute; // Offset: 0x3c0 | Size: 0x10
	struct FString Stop_Fire_Auto_1P_Mute; // Offset: 0x3d0 | Size: 0x10
	struct FString Stop_Fire_Auto_3P_Mute; // Offset: 0x3e0 | Size: 0x10
	struct FString Stop_Fire_Auto_3P_Enemy_Mute; // Offset: 0x3f0 | Size: 0x10
	struct FString Play_Fire_Sigle_1P_Mute; // Offset: 0x400 | Size: 0x10
	struct FString Play_Fire_Sigle_3P_Mute; // Offset: 0x410 | Size: 0x10
	struct FString Play_Fire_Sigle_3P_Enemy_Mute; // Offset: 0x420 | Size: 0x10
	struct FString Play_Fire_Burst_1P_Mute; // Offset: 0x430 | Size: 0x10
	struct FString Play_Fire_Burst_3P_Mute; // Offset: 0x440 | Size: 0x10
	struct FString Play_Fire_Burst_3P_Enemy_Mute; // Offset: 0x450 | Size: 0x10
	struct FString Stop_Fire_Burst_1P_Mute; // Offset: 0x460 | Size: 0x10
	struct FString Stop_Fire_Burst_3P_Mute; // Offset: 0x470 | Size: 0x10
	struct FString Stop_Fire_Burst_3P_Enemy_Mute; // Offset: 0x480 | Size: 0x10
	struct FString Play_Fire_Lay_Tl_1P_Mute; // Offset: 0x490 | Size: 0x10
	struct FString Play_Fire_Lay_Tl_3P_Mute; // Offset: 0x4a0 | Size: 0x10
	struct FString Play_Fire_Lay_Tl_3P_Enemy_Mute; // Offset: 0x4b0 | Size: 0x10
	struct FString Play_Fire_Empty_1p; // Offset: 0x4c0 | Size: 0x10
	struct FString Play_Fire_Empty_3p; // Offset: 0x4d0 | Size: 0x10
	struct FString Play_Fire_Empty_3p_Enemy; // Offset: 0x4e0 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarTables_WeaponSkin
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_WeaponSkin : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_WeaponSkin> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_WeaponSkin
// Inherited Bytes: 0x10 | Struct Size: 0x80
struct FSolarTablesData_WeaponSkin : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	int32_t WeaponSkinType; // Offset: 0x10 | Size: 0x4
	struct FString WeaponSkillQuality; // Offset: 0x18 | Size: 0x10
	int32_t SortId; // Offset: 0x28 | Size: 0x4
	int32_t weaponid; // Offset: 0x2c | Size: 0x4
	struct FString WeaponSkinResource; // Offset: 0x30 | Size: 0x10
	int32_t WeaponSkinAquiredThru; // Offset: 0x40 | Size: 0x4
	int32_t JumpPage; // Offset: 0x44 | Size: 0x4
	struct FString KillBroadcast; // Offset: 0x48 | Size: 0x10
	int32_t ShopPropertyid; // Offset: 0x58 | Size: 0x4
	int32_t ItemID; // Offset: 0x5c | Size: 0x4
	bool DisplayInWeaponry; // Offset: 0x60 | Size: 0x1
	char pad_0x61[0x7]; // Offset: 0x61 | Size: 0x7
	struct FString ChunkDir; // Offset: 0x68 | Size: 0x10
	int32_t ChunkID; // Offset: 0x78 | Size: 0x4
	int32_t AIRandomWeight; // Offset: 0x7c | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarTables_WeaponQuality
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_WeaponQuality : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_WeaponQuality> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_WeaponQuality
// Inherited Bytes: 0x10 | Struct Size: 0x18
struct FSolarTablesData_WeaponQuality : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	int32_t Quality; // Offset: 0x10 | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarTables_WeaponPartsOp
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_WeaponPartsOp : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_WeaponPartsOp> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_WeaponPartsOp
// Inherited Bytes: 0x10 | Struct Size: 0x18
struct FSolarTablesData_WeaponPartsOp : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	int32_t EffectOperator; // Offset: 0x10 | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarTables_WeaponParts
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_WeaponParts : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_WeaponParts> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_WeaponParts
// Inherited Bytes: 0x10 | Struct Size: 0xf8
struct FSolarTablesData_WeaponParts : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	int32_t WeaponLevel; // Offset: 0x10 | Size: 0x4
	enum class ESolarTablesEnum_PartsType PartsType; // Offset: 0x14 | Size: 0x1
	struct TMap<struct FString, struct FString> AttributeSub; // Offset: 0x18 | Size: 0x50
	int32_t PartsQuality; // Offset: 0x68 | Size: 0x4
	char pad_0x6D[0x3]; // Offset: 0x6d | Size: 0x3
	struct FString PartsBPResource; // Offset: 0x70 | Size: 0x10
	struct FString PartsIcon; // Offset: 0x80 | Size: 0x10
	int32_t EffectCondition; // Offset: 0x90 | Size: 0x4
	char pad_0x94[0x4]; // Offset: 0x94 | Size: 0x4
	struct TArray<int32_t> PartsEffect; // Offset: 0x98 | Size: 0x10
	struct TArray<float> PartsValue; // Offset: 0xa8 | Size: 0x10
	struct TArray<int32_t> PartsWeaponID; // Offset: 0xb8 | Size: 0x10
	int32_t PartsName; // Offset: 0xc8 | Size: 0x4
	char pad_0xCC[0x4]; // Offset: 0xcc | Size: 0x4
	struct TArray<struct FString> PartsDesc; // Offset: 0xd0 | Size: 0x10
	int32_t WeaponPartDamage; // Offset: 0xe0 | Size: 0x4
	int32_t WeaponPartRateOfFire; // Offset: 0xe4 | Size: 0x4
	int32_t WeaponPartRecoil; // Offset: 0xe8 | Size: 0x4
	int32_t WeaponPartSpread; // Offset: 0xec | Size: 0x4
	int32_t WeaponPartRange; // Offset: 0xf0 | Size: 0x4
	int32_t WeaponPartMobility; // Offset: 0xf4 | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarTables_WeaponKillTip
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_WeaponKillTip : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_WeaponKillTip> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_WeaponKillTip
// Inherited Bytes: 0x10 | Struct Size: 0x30
struct FSolarTablesData_WeaponKillTip : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	int32_t KillTipType; // Offset: 0x10 | Size: 0x4
	int32_t KillTipValue; // Offset: 0x14 | Size: 0x4
	struct FString KillTipIcon; // Offset: 0x18 | Size: 0x10
	struct FSolarTablesLocalText KillTipname; // Offset: 0x28 | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarTables_WeaponDefault
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_WeaponDefault : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_WeaponDefault> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_WeaponDefault
// Inherited Bytes: 0x10 | Struct Size: 0x90
struct FSolarTablesData_WeaponDefault : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	enum class ESolarTablesEnum_AccessoryType AccessoryType1; // Offset: 0x10 | Size: 0x1
	char pad_0x15[0x3]; // Offset: 0x15 | Size: 0x3
	struct TArray<int32_t> SlotSubtype1; // Offset: 0x18 | Size: 0x10
	int32_t AccessoryID1; // Offset: 0x28 | Size: 0x4
	enum class ESolarTablesEnum_AccessoryType AccessoryType2; // Offset: 0x2c | Size: 0x1
	char pad_0x2D[0x3]; // Offset: 0x2d | Size: 0x3
	struct TArray<int32_t> SlotSubtype2; // Offset: 0x30 | Size: 0x10
	int32_t AccessoryID2; // Offset: 0x40 | Size: 0x4
	enum class ESolarTablesEnum_AccessoryType AccessoryType3; // Offset: 0x44 | Size: 0x1
	char pad_0x45[0x3]; // Offset: 0x45 | Size: 0x3
	struct TArray<int32_t> SlotSubtype3; // Offset: 0x48 | Size: 0x10
	int32_t AccessoryID3; // Offset: 0x58 | Size: 0x4
	enum class ESolarTablesEnum_AccessoryType AccessoryType4; // Offset: 0x5c | Size: 0x1
	char pad_0x5D[0x3]; // Offset: 0x5d | Size: 0x3
	struct TArray<int32_t> SlotSubtype4; // Offset: 0x60 | Size: 0x10
	int32_t AccessoryID4; // Offset: 0x70 | Size: 0x4
	enum class ESolarTablesEnum_AccessoryType AccessoryType5; // Offset: 0x74 | Size: 0x1
	char pad_0x75[0x3]; // Offset: 0x75 | Size: 0x3
	struct TArray<int32_t> SlotSubtype5; // Offset: 0x78 | Size: 0x10
	int32_t AccessoryID5; // Offset: 0x88 | Size: 0x4
	char pad_0x8C[0x4]; // Offset: 0x8c | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarTables_WeaponBattleUpgrade
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_WeaponBattleUpgrade : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_WeaponBattleUpgrade> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_WeaponBattleUpgrade
// Inherited Bytes: 0x10 | Struct Size: 0x20
struct FSolarTablesData_WeaponBattleUpgrade : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	int32_t Exp; // Offset: 0x10 | Size: 0x4
	int32_t Retrofit; // Offset: 0x14 | Size: 0x4
	int32_t UpgradeCost; // Offset: 0x18 | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarTables_WeaponAmmo
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_WeaponAmmo : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_WeaponAmmo> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_WeaponAmmo
// Inherited Bytes: 0x10 | Struct Size: 0x160
struct FSolarTablesData_WeaponAmmo : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	int32_t AmmoType; // Offset: 0x10 | Size: 0x4
	int32_t PropID; // Offset: 0x14 | Size: 0x4
	int32_t SoundID; // Offset: 0x18 | Size: 0x4
	bool IfTimedExplode; // Offset: 0x1c | Size: 0x1
	int32_t BounceTimes; // Offset: 0x20 | Size: 0x4
	float LifeTime; // Offset: 0x24 | Size: 0x4
	float BaseReloadTime; // Offset: 0x28 | Size: 0x4
	float ReloadBoltTime; // Offset: 0x2c | Size: 0x4
	enum class ESolarTablesEnum_FireMethodType FireMethodType; // Offset: 0x30 | Size: 0x1
	enum class ESolarTablesEnum_TrajectoryType TrajectoryType; // Offset: 0x31 | Size: 0x1
	char pad_0x33[0x1]; // Offset: 0x33 | Size: 0x1
	float CustomValue; // Offset: 0x34 | Size: 0x4
	enum class ESolarTablesEnum_TriggerType TriggerType; // Offset: 0x38 | Size: 0x1
	char pad_0x39[0x3]; // Offset: 0x39 | Size: 0x3
	float MaxRange; // Offset: 0x3c | Size: 0x4
	float EffRange; // Offset: 0x40 | Size: 0x4
	float ProjectileMaxGravity; // Offset: 0x44 | Size: 0x4
	float DamageMaxRange; // Offset: 0x48 | Size: 0x4
	float DamageEffRange; // Offset: 0x4c | Size: 0x4
	float Radius; // Offset: 0x50 | Size: 0x4
	float PostFireOverload; // Offset: 0x54 | Size: 0x4
	float InitSpeed; // Offset: 0x58 | Size: 0x4
	float FireStreakBreakTime; // Offset: 0x5c | Size: 0x4
	enum class ESolarTablesEnum_FireCostType FireCostType; // Offset: 0x60 | Size: 0x1
	char pad_0x61[0x3]; // Offset: 0x61 | Size: 0x3
	int32_t FireCostPerAttack; // Offset: 0x64 | Size: 0x4
	int32_t FireSpeedChangeTime; // Offset: 0x68 | Size: 0x4
	float FireSpeedChangeCOP; // Offset: 0x6c | Size: 0x4
	float FireIntervalRevertPreTime; // Offset: 0x70 | Size: 0x4
	float FireIntervalReavertSpeed; // Offset: 0x74 | Size: 0x4
	float FastestFireInterval; // Offset: 0x78 | Size: 0x4
	float SlowestFireInterval; // Offset: 0x7c | Size: 0x4
	float BaseFireInterval; // Offset: 0x80 | Size: 0x4
	float BoltActionTime; // Offset: 0x84 | Size: 0x4
	float BurstShootInterval; // Offset: 0x88 | Size: 0x4
	float BurstFireInterval; // Offset: 0x8c | Size: 0x4
	float StartBoltDuration; // Offset: 0x90 | Size: 0x4
	bool UsePrimaryModeAmmoCap; // Offset: 0x94 | Size: 0x1
	bool UseBag; // Offset: 0x95 | Size: 0x1
	char pad_0x96[0x2]; // Offset: 0x96 | Size: 0x2
	struct TArray<float> SkillCDDiscountArray; // Offset: 0x98 | Size: 0x10
	int32_t SkillType; // Offset: 0xa8 | Size: 0x4
	float VhADSSpreadCOP; // Offset: 0xac | Size: 0x4
	float ADSSpreadCOP; // Offset: 0xb0 | Size: 0x4
	float SpreadFirePreTime; // Offset: 0xb4 | Size: 0x4
	float SpreadPostFireSpeed; // Offset: 0xb8 | Size: 0x4
	float SpreadRestorePreTime; // Offset: 0xbc | Size: 0x4
	float SpreadRestoreSpeed; // Offset: 0xc0 | Size: 0x4
	float VRecoilCostTime; // Offset: 0xc4 | Size: 0x4
	int32_t VRecoilAPoint; // Offset: 0xc8 | Size: 0x4
	float VRecoilAPointMax; // Offset: 0xcc | Size: 0x4
	float VRecoilAPointMin; // Offset: 0xd0 | Size: 0x4
	int32_t VRecoilBPoint; // Offset: 0xd4 | Size: 0x4
	float VRecoilBPointMax; // Offset: 0xd8 | Size: 0x4
	float VRecoilBPointMin; // Offset: 0xdc | Size: 0x4
	float HRecoilCostTime; // Offset: 0xe0 | Size: 0x4
	int32_t HRecoilAPoint; // Offset: 0xe4 | Size: 0x4
	float HRecoilAPointMax; // Offset: 0xe8 | Size: 0x4
	float HRecoilAPointMin; // Offset: 0xec | Size: 0x4
	int32_t HRecoilBPoint; // Offset: 0xf0 | Size: 0x4
	float HRecoilBPointMax; // Offset: 0xf4 | Size: 0x4
	float HRecoilBPointMin; // Offset: 0xf8 | Size: 0x4
	int32_t RecoilCOP; // Offset: 0xfc | Size: 0x4
	float ADSRecoilCOP; // Offset: 0x100 | Size: 0x4
	float RollCostTime; // Offset: 0x104 | Size: 0x4
	int32_t RollAPoint; // Offset: 0x108 | Size: 0x4
	int32_t RollBPoint; // Offset: 0x10c | Size: 0x4
	float RollHightestPointMax; // Offset: 0x110 | Size: 0x4
	float RollHightestPointMin; // Offset: 0x114 | Size: 0x4
	float RollLowesttPointMax; // Offset: 0x118 | Size: 0x4
	float RollLowesttPointMin; // Offset: 0x11c | Size: 0x4
	float ADSRollCOP; // Offset: 0x120 | Size: 0x4
	float ScopeRollCostTime; // Offset: 0x124 | Size: 0x4
	int32_t ScopeRollAPoint; // Offset: 0x128 | Size: 0x4
	int32_t ScopeRollBPoint; // Offset: 0x12c | Size: 0x4
	float ScopeRollHightestPointMax; // Offset: 0x130 | Size: 0x4
	float ScopeRollHightestPointMin; // Offset: 0x134 | Size: 0x4
	float ScopeRollLowesttPointMax; // Offset: 0x138 | Size: 0x4
	float ScopeRollLowesttPointMin; // Offset: 0x13c | Size: 0x4
	float ScopeVMaxDistanceOffSet; // Offset: 0x140 | Size: 0x4
	float ScopeHMaxDistanceOffSet; // Offset: 0x144 | Size: 0x4
	float ScopeVVibrationDuration; // Offset: 0x148 | Size: 0x4
	float ScopeHVibrationDuration; // Offset: 0x14c | Size: 0x4
	float CrossHairVibrationScale; // Offset: 0x150 | Size: 0x4
	float ScopeVContinuousFallingDuration; // Offset: 0x154 | Size: 0x4
	int32_t ScopeVContinuousFallingPointIndex; // Offset: 0x158 | Size: 0x4
	char pad_0x15C[0x4]; // Offset: 0x15c | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarTables_Weapon
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_Weapon : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_Weapon> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_Weapon
// Inherited Bytes: 0x10 | Struct Size: 0x1e8
struct FSolarTablesData_Weapon : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	struct FSolarTablesLocalText Name; // Offset: 0x10 | Size: 0x4
	enum class ESolarTablesEnum_WeaponType WeaponType; // Offset: 0x14 | Size: 0x1
	int32_t WeaponBrand; // Offset: 0x18 | Size: 0x4
	bool SupportSecondaryAmmo; // Offset: 0x1c | Size: 0x1
	char pad_0x1E[0x2]; // Offset: 0x1e | Size: 0x2
	struct TArray<int32_t> AccessoryID; // Offset: 0x20 | Size: 0x10
	struct FString WeaponIcon; // Offset: 0x30 | Size: 0x10
	bool Single; // Offset: 0x40 | Size: 0x1
	bool Burst; // Offset: 0x41 | Size: 0x1
	bool Automatic; // Offset: 0x42 | Size: 0x1
	bool OneKeyScope; // Offset: 0x43 | Size: 0x1
	float HitHead; // Offset: 0x44 | Size: 0x4
	int32_t SecModeLimitTypeID; // Offset: 0x48 | Size: 0x4
	int32_t BurstMaxCount; // Offset: 0x4c | Size: 0x4
	struct FString WeaponDamage; // Offset: 0x50 | Size: 0x10
	float MaxSpread; // Offset: 0x60 | Size: 0x4
	float MinSpread; // Offset: 0x64 | Size: 0x4
	float HipFireBaseSpread; // Offset: 0x68 | Size: 0x4
	float VhADSBaseSpread; // Offset: 0x6c | Size: 0x4
	float ADSBaseSpread; // Offset: 0x70 | Size: 0x4
	float SpreadStatuSpeed; // Offset: 0x74 | Size: 0x4
	float SpreadStatuIncreaseID; // Offset: 0x78 | Size: 0x4
	float SpreadStatuReduceID; // Offset: 0x7c | Size: 0x4
	int32_t SpreadCOPID; // Offset: 0x80 | Size: 0x4
	int32_t PrimaryAmmo; // Offset: 0x84 | Size: 0x4
	int32_t PrimaryAmmoCap; // Offset: 0x88 | Size: 0x4
	int32_t SecondaryAmmo; // Offset: 0x8c | Size: 0x4
	int32_t SecondaryAmmoCap; // Offset: 0x90 | Size: 0x4
	bool CanOverload; // Offset: 0x94 | Size: 0x1
	char pad_0x95[0x3]; // Offset: 0x95 | Size: 0x3
	float OverloadMaxValue; // Offset: 0x98 | Size: 0x4
	float NormalOverloadCoolingRate; // Offset: 0x9c | Size: 0x4
	float OverloadCoolingPeriod; // Offset: 0xa0 | Size: 0x4
	float OverloadWarningRate; // Offset: 0xa4 | Size: 0x4
	bool CanAutoFire; // Offset: 0xa8 | Size: 0x1
	char pad_0xA9[0x3]; // Offset: 0xa9 | Size: 0x3
	float AutoFireDelayMs; // Offset: 0xac | Size: 0x4
	float AutoFireEndDelayMs; // Offset: 0xb0 | Size: 0x4
	bool CanAimAssist; // Offset: 0xb4 | Size: 0x1
	char pad_0xB5[0x3]; // Offset: 0xb5 | Size: 0x3
	struct TArray<float> HipSoftZone; // Offset: 0xb8 | Size: 0x10
	float HipAimAssistStepRatio; // Offset: 0xc8 | Size: 0x4
	float HipMinAssistStepRatio; // Offset: 0xcc | Size: 0x4
	float HipAimAssistStepSpeed; // Offset: 0xd0 | Size: 0x4
	char pad_0xD4[0x4]; // Offset: 0xd4 | Size: 0x4
	struct TArray<float> AdsSoftZone; // Offset: 0xd8 | Size: 0x10
	float AdsAimAssistStepRatio; // Offset: 0xe8 | Size: 0x4
	float AdsMinAssistStepRatio; // Offset: 0xec | Size: 0x4
	float AdsAimAssistStepSpeed; // Offset: 0xf0 | Size: 0x4
	bool CanOpenScopeAimAssist; // Offset: 0xf4 | Size: 0x1
	char pad_0xF5[0x3]; // Offset: 0xf5 | Size: 0x3
	float OpenScopeAimAssistStepRatio; // Offset: 0xf8 | Size: 0x4
	float OpenScopeMinAssistStepRatio; // Offset: 0xfc | Size: 0x4
	float OpenScopeAssistStepSpeed; // Offset: 0x100 | Size: 0x4
	float OnVehicleAssistStepRatio; // Offset: 0x104 | Size: 0x4
	float Weight; // Offset: 0x108 | Size: 0x4
	float HipFireSpeed; // Offset: 0x10c | Size: 0x4
	float ADSFireSpeed; // Offset: 0x110 | Size: 0x4
	char pad_0x114[0x4]; // Offset: 0x114 | Size: 0x4
	struct TArray<int32_t> DefaultParts; // Offset: 0x118 | Size: 0x10
	float ScopeOpenTime; // Offset: 0x128 | Size: 0x4
	float FovFactor; // Offset: 0x12c | Size: 0x4
	float WeaponSwitchTime; // Offset: 0x130 | Size: 0x4
	float WeaponUnequipTime; // Offset: 0x134 | Size: 0x4
	struct TArray<int32_t> PartSlots; // Offset: 0x138 | Size: 0x10
	struct TMap<struct FString, struct FString> EquipAttributeSub; // Offset: 0x148 | Size: 0x50
	struct TMap<struct FString, struct FString> HoldAttributeSub; // Offset: 0x198 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTables_WeaponDamage
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_WeaponDamage : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_WeaponDamage> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_WeaponDamage
// Inherited Bytes: 0x10 | Struct Size: 0x18
struct FSolarTablesData_WeaponDamage : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	float NpcDamageFactor; // Offset: 0x10 | Size: 0x4
	float BotDamageFactor; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarTables_WarmGameMode
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_WarmGameMode : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_WarmGameMode> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_WarmGameMode
// Inherited Bytes: 0x10 | Struct Size: 0x68
struct FSolarTablesData_WarmGameMode : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	int32_t UniqueId; // Offset: 0x10 | Size: 0x4
	int32_t CCUStart; // Offset: 0x14 | Size: 0x4
	int32_t CCUEnd; // Offset: 0x18 | Size: 0x4
	int32_t NumOfAI; // Offset: 0x1c | Size: 0x4
	int32_t AiLevel; // Offset: 0x20 | Size: 0x4
	struct FString AILevelConfig; // Offset: 0x28 | Size: 0x10
	int32_t AITeamPresetsID; // Offset: 0x38 | Size: 0x4
	bool EnableTeamManager; // Offset: 0x3c | Size: 0x1
	char pad_0x3D[0x3]; // Offset: 0x3d | Size: 0x3
	int32_t MinPlayer; // Offset: 0x40 | Size: 0x4
	int32_t MaxRealGroup; // Offset: 0x44 | Size: 0x4
	int32_t LeastRealPlayer; // Offset: 0x48 | Size: 0x4
	int32_t MaxWait; // Offset: 0x4c | Size: 0x4
	bool HasMonster; // Offset: 0x50 | Size: 0x1
	char pad_0x51[0x3]; // Offset: 0x51 | Size: 0x3
	int32_t ReadyStateTime; // Offset: 0x54 | Size: 0x4
	int32_t StopMatchTime; // Offset: 0x58 | Size: 0x4
	bool HasAITeammate; // Offset: 0x5c | Size: 0x1
	bool AIAccompany; // Offset: 0x5d | Size: 0x1
	char pad_0x5E[0x2]; // Offset: 0x5e | Size: 0x2
	int32_t AIAccompanyTimeline; // Offset: 0x60 | Size: 0x4
	char pad_0x64[0x4]; // Offset: 0x64 | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarTables_WarmGame
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_WarmGame : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_WarmGame> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_WarmGame
// Inherited Bytes: 0x10 | Struct Size: 0x78
struct FSolarTablesData_WarmGame : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	int32_t WarmType; // Offset: 0x10 | Size: 0x4
	int32_t MatchType; // Offset: 0x14 | Size: 0x4
	int32_t EloStart; // Offset: 0x18 | Size: 0x4
	int32_t EloEnd; // Offset: 0x1c | Size: 0x4
	int32_t NumStart; // Offset: 0x20 | Size: 0x4
	int32_t NumEnd; // Offset: 0x24 | Size: 0x4
	int32_t KillStart; // Offset: 0x28 | Size: 0x4
	int32_t KillEnd; // Offset: 0x2c | Size: 0x4
	struct FString WarmSubType; // Offset: 0x30 | Size: 0x10
	int32_t UniqueId; // Offset: 0x40 | Size: 0x4
	struct FString Abid; // Offset: 0x48 | Size: 0x10
	struct FString WarmGameFillCheckBox; // Offset: 0x58 | Size: 0x10
	struct FString WarmGameFillTeammate; // Offset: 0x68 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarTables_VehicleSpawnGroup
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_VehicleSpawnGroup : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_VehicleSpawnGroup> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_VehicleSpawnGroup
// Inherited Bytes: 0x10 | Struct Size: 0x90
struct FSolarTablesData_VehicleSpawnGroup : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	struct TArray<int32_t> VehicleIDs; // Offset: 0x10 | Size: 0x10
	struct TArray<int32_t> VehicleCounts; // Offset: 0x20 | Size: 0x10
	struct TArray<int32_t> VehicleSum; // Offset: 0x30 | Size: 0x10
	struct FString VehicleWeightSet; // Offset: 0x40 | Size: 0x10
	struct TArray<int32_t> AlternateId; // Offset: 0x50 | Size: 0x10
	struct FString AlternateType; // Offset: 0x60 | Size: 0x10
	struct FString AlternateTime; // Offset: 0x70 | Size: 0x10
	struct FString AlternateDate; // Offset: 0x80 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarTables_VehicleSpawn
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_VehicleSpawn : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_VehicleSpawn> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_VehicleSpawn
// Inherited Bytes: 0x10 | Struct Size: 0x30
struct FSolarTablesData_VehicleSpawn : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	struct TArray<int32_t> VehicleSet; // Offset: 0x10 | Size: 0x10
	struct TArray<int32_t> WeightSet; // Offset: 0x20 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarTables_VehicleType
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_VehicleType : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_VehicleType> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_VehicleType
// Inherited Bytes: 0x10 | Struct Size: 0xf0
struct FSolarTablesData_VehicleType : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	int32_t DefaultId; // Offset: 0x10 | Size: 0x4
	struct FSolarTablesLocalText Name; // Offset: 0x14 | Size: 0x4
	struct FString VehicleIcon; // Offset: 0x18 | Size: 0x10
	struct FString AudioEventName; // Offset: 0x28 | Size: 0x10
	int32_t VehicleClass; // Offset: 0x38 | Size: 0x4
	float LobbyDurability; // Offset: 0x3c | Size: 0x4
	float LobbySpeed; // Offset: 0x40 | Size: 0x4
	float LobbyFirepower; // Offset: 0x44 | Size: 0x4
	float LobbyControl; // Offset: 0x48 | Size: 0x4
	int32_t SeatNum; // Offset: 0x4c | Size: 0x4
	struct TArray<int32_t> Seat1WeaponID; // Offset: 0x50 | Size: 0x10
	struct TArray<int32_t> Seat2WeaponID; // Offset: 0x60 | Size: 0x10
	struct TArray<int32_t> Seat3WeaponID; // Offset: 0x70 | Size: 0x10
	struct TArray<int32_t> Seat4WeaponID; // Offset: 0x80 | Size: 0x10
	struct TArray<int32_t> Seat1SkillID; // Offset: 0x90 | Size: 0x10
	struct TArray<int32_t> Seat2SkillID; // Offset: 0xa0 | Size: 0x10
	struct TArray<int32_t> Seat3SkillID; // Offset: 0xb0 | Size: 0x10
	struct TArray<int32_t> Seat4SkillID; // Offset: 0xc0 | Size: 0x10
	struct FString VehicleLink; // Offset: 0xd0 | Size: 0x10
	struct FString SilhouetteIcon; // Offset: 0xe0 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarTables_VehicleSkin
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_VehicleSkin : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_VehicleSkin> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_VehicleSkin
// Inherited Bytes: 0x10 | Struct Size: 0x88
struct FSolarTablesData_VehicleSkin : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	int32_t VehicleTypeID; // Offset: 0x10 | Size: 0x4
	int32_t ItemID; // Offset: 0x14 | Size: 0x4
	struct FSolarTablesLocalText SkinName; // Offset: 0x18 | Size: 0x4
	bool IfShow; // Offset: 0x1c | Size: 0x1
	struct FString BeginTime; // Offset: 0x20 | Size: 0x10
	struct TArray<int32_t> JumpLink; // Offset: 0x30 | Size: 0x10
	struct FString VehicleSkinBPPath; // Offset: 0x40 | Size: 0x10
	struct FString VehiclePreviewBP; // Offset: 0x50 | Size: 0x10
	struct FString VehicleIcon; // Offset: 0x60 | Size: 0x10
	struct FString VehicleSound; // Offset: 0x70 | Size: 0x10
	int32_t AIRandomWeight; // Offset: 0x80 | Size: 0x4
	char pad_0x85[0x3]; // Offset: 0x85 | Size: 0x3
};

// Object: ScriptStruct Solarland.SolarTables_Vehicle
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_Vehicle : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_Vehicle> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_Vehicle
// Inherited Bytes: 0x10 | Struct Size: 0x30
struct FSolarTablesData_Vehicle : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	struct FSolarTablesLocalText Name; // Offset: 0x10 | Size: 0x4
	struct FString VehicleBP; // Offset: 0x18 | Size: 0x10
	int32_t groupid; // Offset: 0x28 | Size: 0x4
	int32_t VehicleTypeID; // Offset: 0x2c | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarTables_Variables
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_Variables : FSolarTablesDataBase {
	// Fields
	struct TMap<struct FString, struct FSolarTablesData_Variables> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_Variables
// Inherited Bytes: 0x10 | Struct Size: 0x30
struct FSolarTablesData_Variables : FSolarTablesDataBase {
	// Fields
	struct FString ID; // Offset: 0x10 | Size: 0x10
	struct FString Value; // Offset: 0x20 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarTables_TaskSystem
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_TaskSystem : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_TaskSystem> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_TaskSystem
// Inherited Bytes: 0x10 | Struct Size: 0xb8
struct FSolarTablesData_TaskSystem : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	int32_t taskDesc; // Offset: 0x10 | Size: 0x4
	int32_t Task; // Offset: 0x14 | Size: 0x4
	int32_t TaskType; // Offset: 0x18 | Size: 0x4
	struct FString cond1_sheet; // Offset: 0x20 | Size: 0x10
	int32_t cond1; // Offset: 0x30 | Size: 0x4
	char pad_0x34[0x4]; // Offset: 0x34 | Size: 0x4
	struct FString cond2_sheet; // Offset: 0x38 | Size: 0x10
	int32_t cond2; // Offset: 0x48 | Size: 0x4
	char pad_0x4C[0x4]; // Offset: 0x4c | Size: 0x4
	struct FString cond3_sheet; // Offset: 0x50 | Size: 0x10
	int32_t cond3; // Offset: 0x60 | Size: 0x4
	int32_t Target; // Offset: 0x64 | Size: 0x4
	struct TArray<int32_t> Item; // Offset: 0x68 | Size: 0x10
	int32_t MinLevel; // Offset: 0x78 | Size: 0x4
	char pad_0x7C[0x4]; // Offset: 0x7c | Size: 0x4
	struct TArray<int32_t> link; // Offset: 0x80 | Size: 0x10
	int32_t Weight; // Offset: 0x90 | Size: 0x4
	int32_t sort; // Offset: 0x94 | Size: 0x4
	bool Progress; // Offset: 0x98 | Size: 0x1
	bool isCircle; // Offset: 0x99 | Size: 0x1
	char pad_0x9A[0x2]; // Offset: 0x9a | Size: 0x2
	int32_t circleTimes; // Offset: 0x9c | Size: 0x4
	int32_t resetType; // Offset: 0xa0 | Size: 0x4
	char pad_0xA4[0x4]; // Offset: 0xa4 | Size: 0x4
	struct TArray<int32_t> taskTips; // Offset: 0xa8 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarTables_TaskProgress
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_TaskProgress : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_TaskProgress> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_TaskProgress
// Inherited Bytes: 0x10 | Struct Size: 0x18
struct FSolarTablesData_TaskProgress : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	int32_t isRefresh; // Offset: 0x10 | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarTables_VODownload
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_VODownload : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_VODownload> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_VODownload
// Inherited Bytes: 0x10 | Struct Size: 0x50
struct FSolarTablesData_VODownload : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	struct FString ChunkDir; // Offset: 0x10 | Size: 0x10
	int32_t ChunkID; // Offset: 0x20 | Size: 0x4
	struct FString ButtonText; // Offset: 0x28 | Size: 0x10
	int32_t LanguageIndex; // Offset: 0x38 | Size: 0x4
	int32_t IsDefaultChunk; // Offset: 0x3c | Size: 0x4
	struct FString WwiseLanguageCode; // Offset: 0x40 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarTables_WeaponSkinProperty
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_WeaponSkinProperty : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_WeaponSkinProperty> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_WeaponSkinProperty
// Inherited Bytes: 0x10 | Struct Size: 0x68
struct FSolarTablesData_WeaponSkinProperty : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	struct FSolarTablesLocalText Name; // Offset: 0x10 | Size: 0x4
	struct FString Icon; // Offset: 0x18 | Size: 0x10
	struct FSolarTablesLocalText Info; // Offset: 0x28 | Size: 0x4
	int32_t Quality; // Offset: 0x2c | Size: 0x4
	int32_t ItemClass; // Offset: 0x30 | Size: 0x4
	int32_t ItemType; // Offset: 0x34 | Size: 0x4
	bool ShowInStorage; // Offset: 0x38 | Size: 0x1
	bool IfUse; // Offset: 0x39 | Size: 0x1
	bool IfRecycle; // Offset: 0x3a | Size: 0x1
	enum class ESolarTablesEnum_StackType StackType; // Offset: 0x3b | Size: 0x1
	char pad_0x3C[0x4]; // Offset: 0x3c | Size: 0x4
	struct TArray<int32_t> JumpLink; // Offset: 0x40 | Size: 0x10
	int32_t WeaponSkinID; // Offset: 0x50 | Size: 0x4
	char pad_0x54[0x4]; // Offset: 0x54 | Size: 0x4
	struct FString WeaponIcon_M; // Offset: 0x58 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarTables_Voice
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_Voice : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_Voice> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_Voice
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTablesData_Voice : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	struct FSolarTablesLocalText Name; // Offset: 0x10 | Size: 0x4
	struct FString Icon; // Offset: 0x18 | Size: 0x10
	struct FSolarTablesLocalText Info; // Offset: 0x28 | Size: 0x4
	int32_t Quality; // Offset: 0x2c | Size: 0x4
	int32_t ItemClass; // Offset: 0x30 | Size: 0x4
	int32_t ItemType; // Offset: 0x34 | Size: 0x4
	bool ShowInStorage; // Offset: 0x38 | Size: 0x1
	bool IfUse; // Offset: 0x39 | Size: 0x1
	bool IfRecycle; // Offset: 0x3a | Size: 0x1
	enum class ESolarTablesEnum_StackType StackType; // Offset: 0x3b | Size: 0x1
	char pad_0x3C[0x4]; // Offset: 0x3c | Size: 0x4
	struct TArray<int32_t> JumpLink; // Offset: 0x40 | Size: 0x10
	int32_t Type; // Offset: 0x50 | Size: 0x4
	int32_t VoiceID; // Offset: 0x54 | Size: 0x4
	int32_t CharacterId; // Offset: 0x58 | Size: 0x4
	bool IfBotUse; // Offset: 0x5c | Size: 0x1
	bool IfDefault; // Offset: 0x5d | Size: 0x1
	bool IfDefaultEquip; // Offset: 0x5e | Size: 0x1
	char pad_0x5F[0x1]; // Offset: 0x5f | Size: 0x1
};

// Object: ScriptStruct Solarland.SolarTables_VehicleSkinProperty
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_VehicleSkinProperty : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_VehicleSkinProperty> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_VehicleSkinProperty
// Inherited Bytes: 0x10 | Struct Size: 0x78
struct FSolarTablesData_VehicleSkinProperty : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	struct FSolarTablesLocalText Name; // Offset: 0x10 | Size: 0x4
	struct FString Icon; // Offset: 0x18 | Size: 0x10
	struct FSolarTablesLocalText Info; // Offset: 0x28 | Size: 0x4
	int32_t Quality; // Offset: 0x2c | Size: 0x4
	int32_t ItemClass; // Offset: 0x30 | Size: 0x4
	int32_t ItemType; // Offset: 0x34 | Size: 0x4
	bool ShowInStorage; // Offset: 0x38 | Size: 0x1
	bool IfUse; // Offset: 0x39 | Size: 0x1
	bool IfRecycle; // Offset: 0x3a | Size: 0x1
	enum class ESolarTablesEnum_StackType StackType; // Offset: 0x3b | Size: 0x1
	char pad_0x3C[0x4]; // Offset: 0x3c | Size: 0x4
	struct TArray<int32_t> JumpLink; // Offset: 0x40 | Size: 0x10
	int32_t VehicleSkinId; // Offset: 0x50 | Size: 0x4
	int32_t VehicleSkinAquiredThre; // Offset: 0x54 | Size: 0x4
	int32_t JumpPage; // Offset: 0x58 | Size: 0x4
	char pad_0x5C[0x4]; // Offset: 0x5c | Size: 0x4
	struct FString KillBroadcast; // Offset: 0x60 | Size: 0x10
	bool DisplayInVehiclery; // Offset: 0x70 | Size: 0x1
	char pad_0x71[0x7]; // Offset: 0x71 | Size: 0x7
};

// Object: ScriptStruct Solarland.SolarTables_UnitCharacter
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FSolarTables_UnitCharacter : FSolarTablesDataBase {
	// Fields
	struct TMap<int32_t, struct FSolarTablesData_UnitCharacter> Data; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarTablesData_UnitCharacter
// Inherited Bytes: 0x10 | Struct Size: 0x178
struct FSolarTablesData_UnitCharacter : FSolarTablesDataBase {
	// Fields
	int32_t ID; // Offset: 0xc | Size: 0x4
	struct FSolarTablesLocalText Name; // Offset: 0x10 | Size: 0x4
	struct FSolarTablesLocalText name_extra; // Offset: 0x14 | Size: 0x4
	struct FSolarTablesLocalText Info; // Offset: 0x18 | Size: 0x4
	int32_t Gender; // Offset: 0x1c | Size: 0x4
	int32_t Body; // Offset: 0x20 | Size: 0x4
	enum class ESolarTablesEnum_CharacterType CharacterType; // Offset: 0x24 | Size: 0x1
	struct FString ClassTypeIcon; // Offset: 0x28 | Size: 0x10
	struct FSolarTablesLocalText ClassTypeInfo; // Offset: 0x38 | Size: 0x4
	bool defaultChara; // Offset: 0x3c | Size: 0x1
	char pad_0x3E[0x2]; // Offset: 0x3e | Size: 0x2
	int32_t defaultSkin; // Offset: 0x40 | Size: 0x4
	int32_t defaultPose; // Offset: 0x44 | Size: 0x4
	int32_t defaultBackground; // Offset: 0x48 | Size: 0x4
	bool usableChara; // Offset: 0x4c | Size: 0x1
	char pad_0x4D[0x3]; // Offset: 0x4d | Size: 0x3
	struct FString CharacterProtrait; // Offset: 0x50 | Size: 0x10
	struct FString UrlName; // Offset: 0x60 | Size: 0x10
	struct TMap<struct FString, struct FString> CharacterAttributesID; // Offset: 0x70 | Size: 0x50
	float MaxNormalHP; // Offset: 0xc0 | Size: 0x4
	int32_t defaultArmor; // Offset: 0xc4 | Size: 0x4
	int32_t defaultShield; // Offset: 0xc8 | Size: 0x4
	int32_t defaultJetPackModule; // Offset: 0xcc | Size: 0x4
	struct FString BasicItemMax; // Offset: 0xd0 | Size: 0x10
	float InitialSolarCharge; // Offset: 0xe0 | Size: 0x4
	float RechargeFrequencyFromSky; // Offset: 0xe4 | Size: 0x4
	float RechargeFrequencyFromDeathBox; // Offset: 0xe8 | Size: 0x4
	float RechargeFrequencyFromPile; // Offset: 0xec | Size: 0x4
	float RechargeQuantityFromSky; // Offset: 0xf0 | Size: 0x4
	float RechargeQuantityFromDeathBox; // Offset: 0xf4 | Size: 0x4
	float RechargeQuantityFromPile; // Offset: 0xf8 | Size: 0x4
	float InitialEnergyLimit; // Offset: 0xfc | Size: 0x4
	float InitialExtraEnergyLimit; // Offset: 0x100 | Size: 0x4
	float InitialExtraEnergyCharge; // Offset: 0x104 | Size: 0x4
	float InitialChargeCD; // Offset: 0x108 | Size: 0x4
	int32_t ExpID; // Offset: 0x10c | Size: 0x4
	float ExpBonus; // Offset: 0x110 | Size: 0x4
	int32_t CharaGiftID; // Offset: 0x114 | Size: 0x4
	struct FString CharacterIngameBP; // Offset: 0x118 | Size: 0x10
	struct FString AnimBPResPath; // Offset: 0x128 | Size: 0x10
	int32_t StandJogSpeed; // Offset: 0x138 | Size: 0x4
	int32_t StandRunSpeed; // Offset: 0x13c | Size: 0x4
	int32_t StandSprintSpeed; // Offset: 0x140 | Size: 0x4
	int32_t CrouchJogSpeed; // Offset: 0x144 | Size: 0x4
	int32_t CrouchRunSpeed; // Offset: 0x148 | Size: 0x4
	int32_t CrouchSprintSpeed; // Offset: 0x14c | Size: 0x4
	int32_t ItemID; // Offset: 0x150 | Size: 0x4
	float BackpackScale; // Offset: 0x154 | Size: 0x4
	int32_t CharacterSize; // Offset: 0x158 | Size: 0x4
	int32_t BotConfigID; // Offset: 0x15c | Size: 0x4
	int32_t CharacterSort; // Offset: 0x160 | Size: 0x4
	int32_t CharacterTag1; // Offset: 0x164 | Size: 0x4
	int32_t CharacterTag2; // Offset: 0x168 | Size: 0x4
	int32_t HeroPickSortOrder; // Offset: 0x16c | Size: 0x4
	int32_t HeroPickSortOrderB; // Offset: 0x170 | Size: 0x4
	char pad_0x174[0x4]; // Offset: 0x174 | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarTablesDeviceRes
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FSolarTablesDeviceRes {
	// Fields
	struct FString res; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarTablesRangeFloat
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FSolarTablesRangeFloat {
	// Fields
	float Left; // Offset: 0x0 | Size: 0x4
	float Right; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarTablesRangeInt
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FSolarTablesRangeInt {
	// Fields
	int32_t Left; // Offset: 0x0 | Size: 0x4
	int32_t Right; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct Solarland.TaskHandleFuncConfig
// Inherited Bytes: 0x8 | Struct Size: 0x40
struct FTaskHandleFuncConfig : FTableRowBase {
	// Fields
	int64_t TaskType; // Offset: 0x8 | Size: 0x8
	struct FString taskDesc; // Offset: 0x10 | Size: 0x10
	struct FString TargetValueName; // Offset: 0x20 | Size: 0x10
	struct FString FuncName; // Offset: 0x30 | Size: 0x10
};

// Object: ScriptStruct Solarland.TaskHandleFuncInfo
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FTaskHandleFuncInfo {
	// Fields
	int64_t TaskID; // Offset: 0x0 | Size: 0x8
	struct FString FuncName; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct Solarland.BattlePassTimeInfo
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FBattlePassTimeInfo {
	// Fields
	int64_t BattlePassID; // Offset: 0x0 | Size: 0x8
	int64_t currWeek; // Offset: 0x8 | Size: 0x8
	int64_t maxWeek; // Offset: 0x10 | Size: 0x8
};

// Object: ScriptStruct Solarland.SolarTeamAttributeSet
// Inherited Bytes: 0x0 | Struct Size: 0x78
struct FSolarTeamAttributeSet {
	// Fields
	struct FSolarTeamAttribute TeamTreatmentDurationReductionMultiple; // Offset: 0x0 | Size: 0x18
	struct FSolarTeamAttribute TeamShieldChargeDurationReductionMultiple; // Offset: 0x18 | Size: 0x18
	struct FSolarTeamAttribute TeamBigShieldChargeDurationReductionMultiple; // Offset: 0x30 | Size: 0x18
	struct FSolarTeamAttribute TeamItemDiscountMultiple; // Offset: 0x48 | Size: 0x18
	struct FSolarTeamAttribute TeamItemAdditionMultiple; // Offset: 0x60 | Size: 0x18
};

// Object: ScriptStruct Solarland.SolarTeamAttribute
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FSolarTeamAttribute {
	// Fields
	float Value; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct TArray<struct ASCMPlayerState*> Contributors; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct Solarland.TeamInfoRow
// Inherited Bytes: 0x8 | Struct Size: 0x28
struct FTeamInfoRow : FTableRowBase {
	// Fields
	struct FText TeamName; // Offset: 0x8 | Size: 0x18
	char MemberLimit; // Offset: 0x20 | Size: 0x1
	char MatchCount; // Offset: 0x21 | Size: 0x1
	char pad_0x22[0x6]; // Offset: 0x22 | Size: 0x6
};

// Object: ScriptStruct Solarland.SlateFontSizeForLang
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FSlateFontSizeForLang {
	// Fields
	bool bEnableFontForLang; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	int32_t DefaultFontSize; // Offset: 0x4 | Size: 0x4
	struct TArray<struct FSlateFontSizeLangData> FontForLangGroup; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct Solarland.SlateFontSizeLangData
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FSlateFontSizeLangData {
	// Fields
	enum class ESolarSupportLanguages SpecialLang; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	int32_t SpecialFontSize; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct Solarland.TitanWeaponSetting
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FTitanWeaponSetting {
	// Fields
	struct ASolarVehicleWeapon* TitanWeaponClass; // Offset: 0x0 | Size: 0x8
	struct FName TitanWeaponSocket; // Offset: 0x8 | Size: 0x8
	struct ASolarVehicleWeapon* TitanVehicleWeapon; // Offset: 0x10 | Size: 0x8
};

// Object: ScriptStruct Solarland.TransformerSetting
// Inherited Bytes: 0x0 | Struct Size: 0x98
struct FTransformerSetting {
	// Fields
	enum class EVehicleControlUIType ControlUIType; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x7]; // Offset: 0x1 | Size: 0x7
	struct USolarVehicleGameplayAbility* AbilityClass; // Offset: 0x8 | Size: 0x8
	struct ASolarVehicleWeapon* WeaponClass; // Offset: 0x10 | Size: 0x8
	struct ASolarVehicleWeapon* SkinWeaponClass; // Offset: 0x18 | Size: 0x8
	struct FName WeaponSocketName; // Offset: 0x20 | Size: 0x8
	struct UVehicleCameraDataAsset* CameraDataAsset; // Offset: 0x28 | Size: 0x8
	struct UVehicleCameraDataAsset* PassengerOutShootCamera; // Offset: 0x30 | Size: 0x8
	struct UVehicleCameraDataAsset* PassengerOutShootAimCamera; // Offset: 0x38 | Size: 0x8
	struct ASolarVehicleWeapon* VehicleWeapon; // Offset: 0x40 | Size: 0x8
	struct TMap<enum class EPhysicalSurface, struct TSoftObjectPtr<UParticleSystem>> RaiseDustEffects; // Offset: 0x48 | Size: 0x50
};

// Object: ScriptStruct Solarland.SpawonTreasureBoxIdAndWeight
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FSpawonTreasureBoxIdAndWeight {
	// Fields
	int32_t TreasureId; // Offset: 0x0 | Size: 0x4
	int32_t Weight; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct Solarland.TutorialTableRowBase
// Inherited Bytes: 0x8 | Struct Size: 0x10
struct FTutorialTableRowBase : FTableRowBase {
	// Fields
	int32_t ID; // Offset: 0x8 | Size: 0x4
	char pad_0xC[0x4]; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct Solarland.TutorialConditionTableRow
// Inherited Bytes: 0x10 | Struct Size: 0x30
struct FTutorialConditionTableRow : FTutorialTableRowBase {
	// Fields
	char TriggerType; // Offset: 0xc | Size: 0x1
	struct TArray<struct FString> Parameters; // Offset: 0x10 | Size: 0x10
	struct FString Description; // Offset: 0x20 | Size: 0x10
};

// Object: ScriptStruct Solarland.TutorialActionTableRow
// Inherited Bytes: 0x10 | Struct Size: 0x1d0
struct FTutorialActionTableRow : FTutorialTableRowBase {
	// Fields
	struct FString Desc; // Offset: 0x10 | Size: 0x10
	enum class ETutorialUIType UIType; // Offset: 0x20 | Size: 0x1
	char pad_0x21[0x7]; // Offset: 0x21 | Size: 0x7
	struct FTutorialTipAndEffectUI TutorialTipAndEffectUI; // Offset: 0x28 | Size: 0x70
	struct FTutorialSpecialUI TutorialSpecialUI; // Offset: 0x98 | Size: 0x18
	int32_t NoticeLocTextId; // Offset: 0xb0 | Size: 0x4
	char pad_0xB4[0x4]; // Offset: 0xb4 | Size: 0x4
	struct FTutorialSubtitle TutorialSubtitle; // Offset: 0xb8 | Size: 0x18
	bool bRepeatTip; // Offset: 0xd0 | Size: 0x1
	char pad_0xD1[0x7]; // Offset: 0xd1 | Size: 0x7
	struct FTutorialRepeatTip RepeatTip; // Offset: 0xd8 | Size: 0x18
	struct FTutorialBackgroundMusicTableRow TutorialBackgroundMusic; // Offset: 0xf0 | Size: 0x20
	struct FTutorialSoftCondition EndCondition; // Offset: 0x110 | Size: 0x28
	struct FTutorialSoftCondition InterruptCondition; // Offset: 0x138 | Size: 0x28
	float WaitTime; // Offset: 0x160 | Size: 0x4
	float MinExecuteTime; // Offset: 0x164 | Size: 0x4
	struct TArray<int32_t> OpenBehaviors; // Offset: 0x168 | Size: 0x10
	struct TArray<int32_t> CloseBehaviors; // Offset: 0x178 | Size: 0x10
	int32_t FixedTriggerAreaID; // Offset: 0x188 | Size: 0x4
	char pad_0x18C[0x4]; // Offset: 0x18c | Size: 0x4
	struct TArray<int32_t> BotAISpawnIDs; // Offset: 0x190 | Size: 0x10
	struct TArray<int32_t> BotAIDeathIDs; // Offset: 0x1a0 | Size: 0x10
	struct TArray<int32_t> BotAIOnVehicleSpawnIDs; // Offset: 0x1b0 | Size: 0x10
	struct TArray<int32_t> BotAIOnVehicleDeathIDs; // Offset: 0x1c0 | Size: 0x10
};

// Object: ScriptStruct Solarland.TutorialSoftCondition
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FTutorialSoftCondition {
	// Fields
	struct FString ConditionStr; // Offset: 0x0 | Size: 0x10
	struct FSoftObjectPath ConditionBP; // Offset: 0x10 | Size: 0x18
};

// Object: ScriptStruct Solarland.TutorialBackgroundMusicTableRow
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FTutorialBackgroundMusicTableRow {
	// Fields
	struct FString TutorialPlayMusicName; // Offset: 0x0 | Size: 0x10
	struct FString TutorialStopMusicName; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct Solarland.TutorialRepeatTip
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FTutorialRepeatTip {
	// Fields
	float StartTime; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct TArray<struct FTutorialSingleSubtitle> Subtitles; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct Solarland.TutorialSingleSubtitle
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FTutorialSingleSubtitle {
	// Fields
	struct FString LocalTextId; // Offset: 0x0 | Size: 0x10
	struct FString Voice; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct Solarland.TutorialSubtitle
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FTutorialSubtitle {
	// Fields
	struct TArray<struct FTutorialSingleSubtitle> Subtitles; // Offset: 0x0 | Size: 0x10
	float DelayTime; // Offset: 0x10 | Size: 0x4
	char pad_0x14[0x4]; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct Solarland.TutorialSpecialUI
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FTutorialSpecialUI {
	// Fields
	struct FSoftObjectPath TutorialSpecialUIBPPath; // Offset: 0x0 | Size: 0x18
};

// Object: ScriptStruct Solarland.TutorialTipAndEffectUI
// Inherited Bytes: 0x0 | Struct Size: 0x70
struct FTutorialTipAndEffectUI {
	// Fields
	struct FString LinkedComponent; // Offset: 0x0 | Size: 0x10
	struct FString LimitedListView; // Offset: 0x10 | Size: 0x10
	struct FSoftObjectPath TutorialExpressionBPPath; // Offset: 0x20 | Size: 0x18
	struct FSoftObjectPath TutorialEffectBPPath; // Offset: 0x38 | Size: 0x18
	struct FVector2D TutorialBPLocation; // Offset: 0x50 | Size: 0x8
	bool HorizontalDirection; // Offset: 0x58 | Size: 0x1
	char pad_0x59[0x3]; // Offset: 0x59 | Size: 0x3
	int32_t LocTextID; // Offset: 0x5c | Size: 0x4
	float LocTextDuration; // Offset: 0x60 | Size: 0x4
	float DelayShowUITime; // Offset: 0x64 | Size: 0x4
	float WaitUIShowTime; // Offset: 0x68 | Size: 0x4
	enum class ETutorialUIParent UIParent; // Offset: 0x6c | Size: 0x1
	bool OpenEffectSound; // Offset: 0x6d | Size: 0x1
	bool NeedMask; // Offset: 0x6e | Size: 0x1
	char pad_0x6F[0x1]; // Offset: 0x6f | Size: 0x1
};

// Object: ScriptStruct Solarland.TutorialTableRow
// Inherited Bytes: 0x10 | Struct Size: 0x98
struct FTutorialTableRow : FTutorialTableRowBase {
	// Fields
	struct FString Desc; // Offset: 0x10 | Size: 0x10
	enum class ETutorialType Type; // Offset: 0x20 | Size: 0x1
	enum class ETutorialStage TriggerStage; // Offset: 0x21 | Size: 0x1
	char pad_0x22[0x6]; // Offset: 0x22 | Size: 0x6
	struct FTutorialSoftCondition TriggerCondition; // Offset: 0x28 | Size: 0x28
	int32_t EndNum; // Offset: 0x50 | Size: 0x4
	char pad_0x54[0x4]; // Offset: 0x54 | Size: 0x4
	struct FTutorialSoftCondition ForeverClosedCondition; // Offset: 0x58 | Size: 0x28
	struct TArray<int32_t> ActionIDs; // Offset: 0x80 | Size: 0x10
	bool bUpload; // Offset: 0x90 | Size: 0x1
	bool bMandatory; // Offset: 0x91 | Size: 0x1
	bool bStartUpload; // Offset: 0x92 | Size: 0x1
	bool bWindows; // Offset: 0x93 | Size: 0x1
	bool biOS; // Offset: 0x94 | Size: 0x1
	bool bAndroid; // Offset: 0x95 | Size: 0x1
	char pad_0x96[0x2]; // Offset: 0x96 | Size: 0x2
};

// Object: ScriptStruct Solarland.TutorialLevelConfig
// Inherited Bytes: 0x0 | Struct Size: 0x38
struct FTutorialLevelConfig {
	// Fields
	struct TArray<struct FTutorialLevelConfigData> LevelConfigDatas; // Offset: 0x0 | Size: 0x10
	struct FSoftObjectPath MainMapPath; // Offset: 0x10 | Size: 0x18
	int32_t VeteranTutorialID; // Offset: 0x28 | Size: 0x4
	float RepeatOperationTime; // Offset: 0x2c | Size: 0x4
	float WaitToEndTime; // Offset: 0x30 | Size: 0x4
	char pad_0x34[0x4]; // Offset: 0x34 | Size: 0x4
};

// Object: ScriptStruct Solarland.TutorialLevelConfigData
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FTutorialLevelConfigData {
	// Fields
	struct FString LevelName; // Offset: 0x0 | Size: 0x10
	struct TArray<int32_t> TutorialIds; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct Solarland.TutorialLevelSaveData
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FTutorialLevelSaveData {
	// Fields
	struct FString LevelName; // Offset: 0x0 | Size: 0x10
	struct FString PlayerStartTag; // Offset: 0x10 | Size: 0x10
	bool bTutorialHasFinished; // Offset: 0x20 | Size: 0x1
	char pad_0x21[0x3]; // Offset: 0x21 | Size: 0x3
	int32_t TutorialID; // Offset: 0x24 | Size: 0x4
};

// Object: ScriptStruct Solarland.ConditionReturnInfo_NoParams
// Inherited Bytes: 0x0 | Struct Size: 0x1
struct FConditionReturnInfo_NoParams {
	// Fields
	char pad_0x0[0x1]; // Offset: 0x0 | Size: 0x1
};

// Object: ScriptStruct Solarland.ConditionReturnInfo
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FConditionReturnInfo {
	// Fields
	char pad_0x0[0x18]; // Offset: 0x0 | Size: 0x18
};

// Object: ScriptStruct Solarland.CacheConditionInfo
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FCacheConditionInfo {
	// Fields
	char pad_0x0[0x20]; // Offset: 0x0 | Size: 0x20
};

// Object: ScriptStruct Solarland.MatAppearingData
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FMatAppearingData {
	// Fields
	struct UCurveFloat* MatCurve; // Offset: 0x0 | Size: 0x8
	struct FName MatParam; // Offset: 0x8 | Size: 0x8
};

// Object: ScriptStruct Solarland.ObstacleInitialPosParams
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FObstacleInitialPosParams {
	// Fields
	float Scale; // Offset: 0x0 | Size: 0x4
	float Offset; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct Solarland.DetectorShapeParams
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FDetectorShapeParams {
	// Fields
	struct FVector Offset; // Offset: 0x0 | Size: 0xc
	struct FVector BoxExtent; // Offset: 0xc | Size: 0xc
};

// Object: ScriptStruct Solarland.ClusterBombBullet
// Inherited Bytes: 0x0 | Struct Size: 0x168
struct FClusterBombBullet {
	// Fields
	struct FSolarVirtualBulletHitParameter CacheHitParam; // Offset: 0x0 | Size: 0x78
	char pad_0x78[0x98]; // Offset: 0x78 | Size: 0x98
	struct UParticleSystemComponent* BulletEffectComponent; // Offset: 0x110 | Size: 0x8
	struct USolarAirPlaneMissileConfig* MissileDataAsset; // Offset: 0x118 | Size: 0x8
	struct USolarVirtualBulletAKComponent* BulletAkComponent; // Offset: 0x120 | Size: 0x8
	char pad_0x128[0x40]; // Offset: 0x128 | Size: 0x40
};

// Object: ScriptStruct Solarland.SolarVirtualBulletHitParameter
// Inherited Bytes: 0x0 | Struct Size: 0x78
struct FSolarVirtualBulletHitParameter {
	// Fields
	struct FFireUniqueID FireUniqueID; // Offset: 0x0 | Size: 0x4
	float FireTimeStamp; // Offset: 0x4 | Size: 0x4
	float HitTimeStamp; // Offset: 0x8 | Size: 0x4
	struct FVector_NetQuantize PlayerViewDir; // Offset: 0xc | Size: 0xc
	int8_t FireChargePhase; // Offset: 0x18 | Size: 0x1
	char pad_0x19[0x3]; // Offset: 0x19 | Size: 0x3
	float FireChargeTime; // Offset: 0x1c | Size: 0x4
	int32_t HitStartIndex; // Offset: 0x20 | Size: 0x4
	struct FVector_NetQuantize StartLoc; // Offset: 0x24 | Size: 0xc
	struct FVector_NetQuantize TargetLoc; // Offset: 0x30 | Size: 0xc
	char pad_0x3C[0x4]; // Offset: 0x3c | Size: 0x4
	struct UAmmoConfig* Ammo; // Offset: 0x40 | Size: 0x8
	struct TArray<struct FSolarWeaponHitAntiData> HitAntiDatas; // Offset: 0x48 | Size: 0x10
	struct TArray<struct FHitResult> Hits; // Offset: 0x58 | Size: 0x10
	struct TArray<struct AActor*> IgnoreHitedActors; // Offset: 0x68 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarWeaponHitAntiData
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FSolarWeaponHitAntiData {
	// Fields
	struct FVector_NetQuantize RelavantHitLocationWithCharacter; // Offset: 0x0 | Size: 0xc
	struct FVector_NetQuantize HitBoneScale; // Offset: 0xc | Size: 0xc
	char pad_0x18[0x8]; // Offset: 0x18 | Size: 0x8
	struct FQuat HitBoneRotation; // Offset: 0x20 | Size: 0x10
	struct FVector_NetQuantize HitLoc; // Offset: 0x30 | Size: 0xc
	char pad_0x3C[0x4]; // Offset: 0x3c | Size: 0x4
};

// Object: ScriptStruct Solarland.SpawnClusterBombParam
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FSpawnClusterBombParam {
	// Fields
	struct FFireUniqueID FireUniqueID; // Offset: 0x0 | Size: 0x4
	float FireTimeStamp; // Offset: 0x4 | Size: 0x4
	struct FVector_NetQuantize StartLoc; // Offset: 0x8 | Size: 0xc
	struct FVector_NetQuantizeNormal StartDir; // Offset: 0x14 | Size: 0xc
};

// Object: ScriptStruct Solarland.FlameHitData
// Inherited Bytes: 0x0 | Struct Size: 0x48
struct FFlameHitData {
	// Fields
	struct FFireUniqueID FireUniqueID; // Offset: 0x0 | Size: 0x4
	float FireTimeStamp; // Offset: 0x4 | Size: 0x4
	struct TArray<struct FVector_NetQuantize> FireStartLocations; // Offset: 0x8 | Size: 0x10
	struct TArray<struct FVector_NetQuantize> FireEndLocations; // Offset: 0x18 | Size: 0x10
	struct TArray<struct FHitResult> HitResultDatas; // Offset: 0x28 | Size: 0x10
	struct TArray<struct FSolarWeaponHitAntiData> HitAntiDatas; // Offset: 0x38 | Size: 0x10
};

// Object: ScriptStruct Solarland.VehicleEquipWeaponOverlapCapsule
// Inherited Bytes: 0x0 | Struct Size: 0x14
struct FVehicleEquipWeaponOverlapCapsule {
	// Fields
	struct FVector Postion; // Offset: 0x0 | Size: 0xc
	float HalfHeight; // Offset: 0xc | Size: 0x4
	float Radius; // Offset: 0x10 | Size: 0x4
};

// Object: ScriptStruct Solarland.VehicleEquipWeaponOverlapBox
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FVehicleEquipWeaponOverlapBox {
	// Fields
	struct FVector Postion; // Offset: 0x0 | Size: 0xc
	struct FVector TraceBox; // Offset: 0xc | Size: 0xc
};

// Object: ScriptStruct Solarland.CacheDecalComponent
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FCacheDecalComponent {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Solarland.CacheQueryActor
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FCacheQueryActor {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Solarland.VehicleHealthResource
// Inherited Bytes: 0x0 | Struct Size: 0x60
struct FVehicleHealthResource {
	// Fields
	struct TSoftObjectPtr<UTexture2D> BodyTexture2D; // Offset: 0x0 | Size: 0x28
	struct TSoftObjectPtr<UTexture2D> FillImageTexture2D; // Offset: 0x28 | Size: 0x28
	struct TArray<struct FWeakPointImgInfo> WeakPointImgInfos; // Offset: 0x50 | Size: 0x10
};

// Object: ScriptStruct Solarland.WeakPointImgInfo
// Inherited Bytes: 0x0 | Struct Size: 0x60
struct FWeakPointImgInfo {
	// Fields
	struct TSoftObjectPtr<UTexture2D> Texture2D; // Offset: 0x0 | Size: 0x28
	struct FAnchors Anchors; // Offset: 0x28 | Size: 0x10
	struct FVector2D Postion; // Offset: 0x38 | Size: 0x8
	struct FVector2D Size; // Offset: 0x40 | Size: 0x8
	struct FVector2D Alignment; // Offset: 0x48 | Size: 0x8
	bool bAutoSize; // Offset: 0x50 | Size: 0x1
	char pad_0x51[0x3]; // Offset: 0x51 | Size: 0x3
	float Angle; // Offset: 0x54 | Size: 0x4
	struct FVector2D Scale; // Offset: 0x58 | Size: 0x8
};

// Object: ScriptStruct Solarland.VehicleDamageLevelColor
// Inherited Bytes: 0x0 | Struct Size: 0x34
struct FVehicleDamageLevelColor {
	// Fields
	struct FLinearColor BackgroundColor; // Offset: 0x0 | Size: 0x10
	struct FLinearColor BackgroundLeftPartColor; // Offset: 0x10 | Size: 0x10
	struct FLinearColor OutlineColor; // Offset: 0x20 | Size: 0x10
	int32_t DamageBonus; // Offset: 0x30 | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarVehicleMaterialData
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FSolarVehicleMaterialData {
	// Fields
	int8_t MaterialIndex; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	struct FName ParamName; // Offset: 0x4 | Size: 0x8
	float OnValue; // Offset: 0xc | Size: 0x4
	float OffValue; // Offset: 0x10 | Size: 0x4
	float ActiveSpeed; // Offset: 0x14 | Size: 0x4
	struct UMaterialInstanceDynamic* MatInstanceDynamic; // Offset: 0x18 | Size: 0x8
	char pad_0x20[0x8]; // Offset: 0x20 | Size: 0x8
};

// Object: ScriptStruct Solarland.VehicleCollisionInfo
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FVehicleCollisionInfo {
	// Fields
	struct UPrimitiveComponent* CollidedPrimitive; // Offset: 0x0 | Size: 0x8
	struct FVector_NetQuantize SelfPreVelocity; // Offset: 0x8 | Size: 0xc
	struct FVector_NetQuantize SelfCurrentVelocity; // Offset: 0x14 | Size: 0xc
	struct FVector_NetQuantize OtherVehicleLinearVelocity; // Offset: 0x20 | Size: 0xc
	struct FVector_NetQuantize OtherVehicleAngularVelocity; // Offset: 0x2c | Size: 0xc
	struct FVector_NetQuantize OtherVehicleLocation; // Offset: 0x38 | Size: 0xc
	struct FVector_NetQuantizeNormal OtherVehicleRotation; // Offset: 0x44 | Size: 0xc
};

// Object: ScriptStruct Solarland.BasedMovement
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FBasedMovement {
	// Fields
	struct UPrimitiveComponent* MovementBase; // Offset: 0x0 | Size: 0x8
	struct FVector_NetQuantize100 Location; // Offset: 0x8 | Size: 0xc
	struct FRotator Rotation; // Offset: 0x14 | Size: 0xc
	bool bRelativeRotation; // Offset: 0x20 | Size: 0x1
	bool bServerHasVelocity; // Offset: 0x21 | Size: 0x1
	char pad_0x22[0x6]; // Offset: 0x22 | Size: 0x6
};

// Object: ScriptStruct Solarland.VehicleSeatSlot
// Inherited Bytes: 0x0 | Struct Size: 0xd8
struct FVehicleSeatSlot {
	// Fields
	struct FName SeatSocketName; // Offset: 0x0 | Size: 0x8
	struct FName SeatWeaponSocket; // Offset: 0x8 | Size: 0x8
	bool bDisplayBackpack; // Offset: 0x10 | Size: 0x1
	bool SeatStickOutEnable; // Offset: 0x11 | Size: 0x1
	char pad_0x12[0x6]; // Offset: 0x12 | Size: 0x6
	struct UVehicleCameraDataAsset* OutShootCameraData; // Offset: 0x18 | Size: 0x8
	struct UVehicleCameraDataAsset* OutShootAimCameraData; // Offset: 0x20 | Size: 0x8
	struct UCurveFloat* OutShootPitchLimitCurve; // Offset: 0x28 | Size: 0x8
	struct TArray<struct FVehicleSeatAbility> VechicleAbilities; // Offset: 0x30 | Size: 0x10
	struct ASolarVehicleWeapon* VehicleWeaponClass; // Offset: 0x40 | Size: 0x8
	struct ASolarVehicleWeapon* VehicleWeaponSkinClass; // Offset: 0x48 | Size: 0x8
	bool bAutoEquipWeapon; // Offset: 0x50 | Size: 0x1
	char pad_0x51[0x7]; // Offset: 0x51 | Size: 0x7
	struct TSoftObjectPtr<UTexture2D> SeatDisplayIcon; // Offset: 0x58 | Size: 0x28
	float DamageRatio; // Offset: 0x80 | Size: 0x4
	float PenetrationDamageRatio; // Offset: 0x84 | Size: 0x4
	struct FBoxSphereBounds PenetrationSphere; // Offset: 0x88 | Size: 0x1c
	struct FRotator EjectRotation; // Offset: 0xa4 | Size: 0xc
	bool bOverrideDefaultEjectParams; // Offset: 0xb0 | Size: 0x1
	char pad_0xB1[0x3]; // Offset: 0xb1 | Size: 0x3
	struct FVehicleEjectParams EjectParams; // Offset: 0xb4 | Size: 0x10
	struct TWeakObjectPtr<struct ASolarCharacter> SeatPassenger; // Offset: 0xc4 | Size: 0x8
	char pad_0xCC[0x4]; // Offset: 0xcc | Size: 0x4
	struct ASolarVehicleWeapon* SeatWeapon; // Offset: 0xd0 | Size: 0x8
};

// Object: ScriptStruct Solarland.VehicleSeatAbility
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FVehicleSeatAbility {
	// Fields
	struct USolarVehicleGameplayAbility* AbilityClass; // Offset: 0x0 | Size: 0x8
	struct FGameplayAbilitySpecHandle ServerOrDriverAbilityHandle; // Offset: 0x8 | Size: 0x4
	struct FGameplayAbilitySpecHandle SkinPreAbilityHandle; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct Solarland.VehicleVFXMesh
// Inherited Bytes: 0x0 | Struct Size: 0x80
struct FVehicleVFXMesh {
	// Fields
	struct TSoftObjectPtr<UStaticMesh> Mesh; // Offset: 0x0 | Size: 0x28
	struct TArray<struct UMaterialInterface*> OverrideMaterials; // Offset: 0x28 | Size: 0x10
	struct FName AttachedSocket; // Offset: 0x38 | Size: 0x8
	struct FTransform OffsetTransform; // Offset: 0x40 | Size: 0x30
	char pad_0x70[0x10]; // Offset: 0x70 | Size: 0x10
};

// Object: ScriptStruct Solarland.DamageStatusVehicleVFXs
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FDamageStatusVehicleVFXs {
	// Fields
	struct TArray<struct FVehicleVFX> VehicleVFXs; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Solarland.VehicleVFX
// Inherited Bytes: 0x0 | Struct Size: 0x90
struct FVehicleVFX {
	// Fields
	struct TSoftObjectPtr<UParticleSystem> Particle; // Offset: 0x0 | Size: 0x28
	struct FName AttachedSocket; // Offset: 0x28 | Size: 0x8
	struct FTransform OffsetTransform; // Offset: 0x30 | Size: 0x30
	struct UCurveFloat* ActivateCurve; // Offset: 0x60 | Size: 0x8
	struct FName ParameterName; // Offset: 0x68 | Size: 0x8
	char pad_0x70[0x20]; // Offset: 0x70 | Size: 0x20
};

// Object: ScriptStruct Solarland.SiegeVehicleOpenTraceData
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FSiegeVehicleOpenTraceData {
	// Fields
	struct FVector BoxPostion; // Offset: 0x0 | Size: 0xc
	struct FVector TraceBox; // Offset: 0xc | Size: 0xc
};

// Object: ScriptStruct Solarland.PIDController
// Inherited Bytes: 0x0 | Struct Size: 0x1c
struct FPIDController {
	// Fields
	float PCoeff; // Offset: 0x0 | Size: 0x4
	float ICoeff; // Offset: 0x4 | Size: 0x4
	float DCoeff; // Offset: 0x8 | Size: 0x4
	float Minimum; // Offset: 0xc | Size: 0x4
	float Maximum; // Offset: 0x10 | Size: 0x4
	char pad_0x14[0x8]; // Offset: 0x14 | Size: 0x8
};

// Object: ScriptStruct Solarland.CarPadSpeedData
// Inherited Bytes: 0x0 | Struct Size: 0x14
struct FCarPadSpeedData {
	// Fields
	char pad_0x0[0x14]; // Offset: 0x0 | Size: 0x14
};

// Object: ScriptStruct Solarland.SolarLavaZone
// Inherited Bytes: 0x0 | Struct Size: 0x70
struct FSolarLavaZone {
	// Fields
	char pad_0x0[0x20]; // Offset: 0x0 | Size: 0x20
	struct FZoneServerValidate ServerValidate; // Offset: 0x20 | Size: 0x40
	struct UParticleSystemComponent* LavaZoneParticleComponent; // Offset: 0x60 | Size: 0x8
	struct USolarVirtualBulletAKComponent* LavaZoneAkComponent; // Offset: 0x68 | Size: 0x8
};

// Object: ScriptStruct Solarland.ZoneServerValidate
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FZoneServerValidate {
	// Fields
	struct FFireUniqueID FireUniqueID; // Offset: 0x0 | Size: 0x4
	struct FVector_NetQuantize ServerSpawnLocation; // Offset: 0x4 | Size: 0xc
	struct FVector_NetQuantizeNormal ServerSpawnDirection; // Offset: 0x10 | Size: 0xc
	float ServerTimeStamp; // Offset: 0x1c | Size: 0x4
	struct ASolarCharacter* LavaZoneOwner; // Offset: 0x20 | Size: 0x8
	float OverlapInterval; // Offset: 0x28 | Size: 0x4
	char pad_0x2C[0x4]; // Offset: 0x2c | Size: 0x4
	struct TArray<struct AActor*> OverlappedActors; // Offset: 0x30 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarLavaBullet
// Inherited Bytes: 0x0 | Struct Size: 0xe8
struct FSolarLavaBullet {
	// Fields
	struct ASolarCharacter* CacheCharacter; // Offset: 0x0 | Size: 0x8
	struct FSolarVirtualBulletHitParameter CacheHitParam; // Offset: 0x8 | Size: 0x78
	char pad_0x80[0x50]; // Offset: 0x80 | Size: 0x50
	struct UParticleSystemComponent* BulletEffectComponent; // Offset: 0xd0 | Size: 0x8
	struct UParticleSystemComponent* TrajectoryEffectComponent; // Offset: 0xd8 | Size: 0x8
	struct USolarVirtualBulletAKComponent* BulletAkComponent; // Offset: 0xe0 | Size: 0x8
};

// Object: ScriptStruct Solarland.BoneIKPreset
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FBoneIKPreset {
	// Fields
	struct FVector LeftIKTarget; // Offset: 0x0 | Size: 0xc
	struct FVector RightIKTarget; // Offset: 0xc | Size: 0xc
	struct FVector2D ChangeIKThreshold; // Offset: 0x18 | Size: 0x8
};

// Object: ScriptStruct Solarland.SpawnedRocketData
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FSpawnedRocketData {
	// Fields
	struct FVector RocketSpawnLocation; // Offset: 0x0 | Size: 0xc
	float RocketSpawnDelayTime; // Offset: 0xc | Size: 0x4
	float AlertLineRemainTime; // Offset: 0x10 | Size: 0x4
	float SpawnedTime; // Offset: 0x14 | Size: 0x4
	bool bRocketSpawned; // Offset: 0x18 | Size: 0x1
	char pad_0x19[0x7]; // Offset: 0x19 | Size: 0x7
	struct UStaticMeshComponent* AlertLineBombingMesh; // Offset: 0x20 | Size: 0x8
};

// Object: ScriptStruct Solarland.BombingAreaAsset
// Inherited Bytes: 0x0 | Struct Size: 0x60
struct FBombingAreaAsset {
	// Fields
	struct TSoftObjectPtr<UStaticMesh> BombingAreaMeshClass; // Offset: 0x0 | Size: 0x28
	struct TSoftObjectPtr<UMaterialInterface> BombingDecalMaterialClass; // Offset: 0x28 | Size: 0x28
	struct UStaticMeshComponent* BombingAreaMeshComponent; // Offset: 0x50 | Size: 0x8
	struct UDecalComponent* BombingAreaDecalComponent; // Offset: 0x58 | Size: 0x8
};

// Object: ScriptStruct Solarland.BombingAreaData
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FBombingAreaData {
	// Fields
	int32_t AreaIndex; // Offset: 0x0 | Size: 0x4
	struct FVector_NetQuantize CenterLocation; // Offset: 0x4 | Size: 0xc
	enum class ERocketFireMode SpawnedFireMode; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x3]; // Offset: 0x11 | Size: 0x3
	float ServerStartedTime; // Offset: 0x14 | Size: 0x4
	char MaxRocketCounter; // Offset: 0x18 | Size: 0x1
	char SpawnedRocketCounter; // Offset: 0x19 | Size: 0x1
	char pad_0x1A[0x2]; // Offset: 0x1a | Size: 0x2
	struct FVector2D LastLandLocation2D; // Offset: 0x1c | Size: 0x8
	bool bTriggered; // Offset: 0x24 | Size: 0x1
	char pad_0x25[0x3]; // Offset: 0x25 | Size: 0x3
};

// Object: ScriptStruct Solarland.FireModeSetting
// Inherited Bytes: 0x0 | Struct Size: 0x38
struct FFireModeSetting {
	// Fields
	float AreaMeshScale; // Offset: 0x0 | Size: 0x4
	struct FVector BombingAreaDecalSize; // Offset: 0x4 | Size: 0xc
	float FirstRocketSpawnTimer; // Offset: 0x10 | Size: 0x4
	float RocketSpawnDelay; // Offset: 0x14 | Size: 0x4
	float AlertLineRemainTime; // Offset: 0x18 | Size: 0x4
	float RocketSpawnInterval; // Offset: 0x1c | Size: 0x4
	float BombingAreaDisplayDelay; // Offset: 0x20 | Size: 0x4
	int32_t LaunchRocketNum; // Offset: 0x24 | Size: 0x4
	float BombingAreaRadius; // Offset: 0x28 | Size: 0x4
	float MiniSpawnDistance; // Offset: 0x2c | Size: 0x4
	struct FVector2D AimDistanceRange; // Offset: 0x30 | Size: 0x8
};

// Object: ScriptStruct Solarland.VehicleSpawner
// Inherited Bytes: 0x0 | Struct Size: 0xd0
struct FVehicleSpawner {
	// Fields
	struct ASolarVehicleSpawnerSets* SolarVehicleSpawnerSets; // Offset: 0x0 | Size: 0x8
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FTransform VehicleSpawnerTransform; // Offset: 0x10 | Size: 0x30
	enum class EVehicleSpawnType VehicleSpawnType; // Offset: 0x40 | Size: 0x1
	char pad_0x41[0x3]; // Offset: 0x41 | Size: 0x3
	int32_t SpawnerID; // Offset: 0x44 | Size: 0x4
	bool bVehicleRefresh; // Offset: 0x48 | Size: 0x1
	char pad_0x49[0x7]; // Offset: 0x49 | Size: 0x7
	struct FVehicleSpawnRefreshInfo VehicleSpawnRefreshInfo; // Offset: 0x50 | Size: 0x48
	char pad_0x98[0x8]; // Offset: 0x98 | Size: 0x8
	struct ASolarVehicleSpawnEffect* VehicleSpawnEffect; // Offset: 0xa0 | Size: 0x8
	char pad_0xA8[0x28]; // Offset: 0xa8 | Size: 0x28
};

// Object: ScriptStruct Solarland.VehicleSpawnRefreshInfo
// Inherited Bytes: 0x0 | Struct Size: 0x48
struct FVehicleSpawnRefreshInfo {
	// Fields
	int32_t VehicleRefreshSecond; // Offset: 0x0 | Size: 0x4
	bool bVehicleRefreshRand; // Offset: 0x4 | Size: 0x1
	bool bVehicleRefreshWaitPreBroken; // Offset: 0x5 | Size: 0x1
	char pad_0x6[0x2]; // Offset: 0x6 | Size: 0x2
	int64_t VehicleRefreshCheckRoleDisSquared; // Offset: 0x8 | Size: 0x8
	struct FVector VehicleCheckBoxSize; // Offset: 0x10 | Size: 0xc
	char pad_0x1C[0x4]; // Offset: 0x1c | Size: 0x4
	struct TSoftClassPtr<UObject> VehicleSpawnEffectClass; // Offset: 0x20 | Size: 0x28
};

// Object: ScriptStruct Solarland.VehicleStateTransition
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FVehicleStateTransition {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
	struct ASolarVehiclePawn* Owner; // Offset: 0x8 | Size: 0x8
	struct USolarLeggedVehicleMovement* MovementComponent; // Offset: 0x10 | Size: 0x8
};

// Object: ScriptStruct Solarland.VehicleState
// Inherited Bytes: 0x0 | Struct Size: 0x78
struct FVehicleState {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
	struct USolarVehicleStateMachine* StateMachine; // Offset: 0x8 | Size: 0x8
	struct ASolarVehiclePawn* Owner; // Offset: 0x10 | Size: 0x8
	struct USolarLeggedVehicleMovement* MovementComponent; // Offset: 0x18 | Size: 0x8
	char pad_0x20[0x58]; // Offset: 0x20 | Size: 0x58
};

// Object: ScriptStruct Solarland.VehicleWeakPointSpec
// Inherited Bytes: 0x0 | Struct Size: 0x1f0
struct FVehicleWeakPointSpec {
	// Fields
	float CurrentHealth; // Offset: 0x0 | Size: 0x4
	bool bInRepairing; // Offset: 0x4 | Size: 0x1
	char pad_0x5[0x3]; // Offset: 0x5 | Size: 0x3
	struct USolarVehicleWeakPointComponent* WeakPointMeshComponent; // Offset: 0x8 | Size: 0x8
	struct ASolarVehiclePawn* VehiclePawn; // Offset: 0x10 | Size: 0x8
	char WeakPointID; // Offset: 0x18 | Size: 0x1
	char pad_0x19[0x7]; // Offset: 0x19 | Size: 0x7
	struct TArray<struct FName> WeakPointSockets; // Offset: 0x20 | Size: 0x10
	struct FVector WeakPointOffset; // Offset: 0x30 | Size: 0xc
	char pad_0x3C[0x4]; // Offset: 0x3c | Size: 0x4
	struct TSoftObjectPtr<UStaticMesh> WeakPointStaticMesh; // Offset: 0x40 | Size: 0x28
	char pad_0x68[0x8]; // Offset: 0x68 | Size: 0x8
	struct FTransform WeakPointRelativeTransform; // Offset: 0x70 | Size: 0x30
	float MaxWeakPointHealth; // Offset: 0xa0 | Size: 0x4
	float RepairDuration; // Offset: 0xa4 | Size: 0x4
	bool bRecoverBoneScaleAfterVFXFinished; // Offset: 0xa8 | Size: 0x1
	char pad_0xA9[0x7]; // Offset: 0xa9 | Size: 0x7
	struct FVehicleVFX BrokenWeakPointVFX; // Offset: 0xb0 | Size: 0x90
	struct FVehicleVFX RepairingWeakPointVFX; // Offset: 0x140 | Size: 0x90
	float FacingAngle; // Offset: 0x1d0 | Size: 0x4
	float DistFromCharacterToWeakPoint; // Offset: 0x1d4 | Size: 0x4
	char pad_0x1D8[0x18]; // Offset: 0x1d8 | Size: 0x18
};

// Object: ScriptStruct Solarland.BulletLandAreaData
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FBulletLandAreaData {
	// Fields
	struct UParticleSystemComponent* TargetParticleComponent; // Offset: 0x0 | Size: 0x8
	struct UDecalComponent* TargetDecalComponent; // Offset: 0x8 | Size: 0x8
	char pad_0x10[0x8]; // Offset: 0x10 | Size: 0x8
};

// Object: ScriptStruct Solarland.SolarVirtualBullet
// Inherited Bytes: 0x0 | Struct Size: 0x1a8
struct FSolarVirtualBullet {
	// Fields
	struct FFireUniqueID FireUniqueID; // Offset: 0x0 | Size: 0x4
	enum class EVirtualBulletType BulletType; // Offset: 0x4 | Size: 0x1
	char pad_0x5[0xb]; // Offset: 0x5 | Size: 0xb
	struct UParticleSystemComponent* BulletEffect; // Offset: 0x10 | Size: 0x8
	struct UParticleSystemComponent* TrajectoryEffect; // Offset: 0x18 | Size: 0x8
	struct UParticleSystemComponent* TrajectoryBeamEffect; // Offset: 0x20 | Size: 0x8
	struct USolarVirtualBulletAKComponent* AkComponent; // Offset: 0x28 | Size: 0x8
	char pad_0x30[0x140]; // Offset: 0x30 | Size: 0x140
	struct FVector_NetQuantize PlayerViewDir; // Offset: 0x170 | Size: 0xc
	struct FVector_NetQuantize PlayerViewLoc; // Offset: 0x17c | Size: 0xc
	char IsScopeOpen; // Offset: 0x188 | Size: 0x1
	char pad_0x189[0x1f]; // Offset: 0x189 | Size: 0x1f
};

// Object: ScriptStruct Solarland.SolarVirtualBulletSpawnParameter
// Inherited Bytes: 0x0 | Struct Size: 0xa8
struct FSolarVirtualBulletSpawnParameter {
	// Fields
	struct FFireUniqueID FireUniqueID; // Offset: 0x0 | Size: 0x4
	float FireTimeStamp; // Offset: 0x4 | Size: 0x4
	float PreElapsedTime; // Offset: 0x8 | Size: 0x4
	struct FVector PlayerViewDir; // Offset: 0xc | Size: 0xc
	struct FVector_NetQuantize PlayerViewLoc; // Offset: 0x18 | Size: 0xc
	char IsScopeOpen; // Offset: 0x24 | Size: 0x1
	int8_t FireChargePhase; // Offset: 0x25 | Size: 0x1
	char pad_0x26[0x2]; // Offset: 0x26 | Size: 0x2
	float FireChargeTime; // Offset: 0x28 | Size: 0x4
	struct FVector_NetQuantize StartLoc; // Offset: 0x2c | Size: 0xc
	struct FVector_NetQuantize TargetLoc; // Offset: 0x38 | Size: 0xc
	struct FVector_NetQuantizeNormal Dir; // Offset: 0x44 | Size: 0xc
	struct FVector_NetQuantize MuzzleFxLoc; // Offset: 0x50 | Size: 0xc
	float CurveOffsetAngle; // Offset: 0x5c | Size: 0x4
	struct FSolarVirtualBulletHomingTarget HomingTarget; // Offset: 0x60 | Size: 0x18
	struct UAmmoConfig* Ammo; // Offset: 0x78 | Size: 0x8
	struct FString AntiData; // Offset: 0x80 | Size: 0x10
	struct TWeakObjectPtr<struct AActor> Target; // Offset: 0x90 | Size: 0x8
	struct FVector_NetQuantize HitTargetRelativeLocation; // Offset: 0x98 | Size: 0xc
	char pad_0xA4[0x4]; // Offset: 0xa4 | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarVirtualBulletHomingTarget
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FSolarVirtualBulletHomingTarget {
	// Fields
	bool bSet; // Offset: 0x0 | Size: 0x1
	bool bLocalCharacterLock; // Offset: 0x1 | Size: 0x1
	char pad_0x2[0x2]; // Offset: 0x2 | Size: 0x2
	struct TWeakObjectPtr<struct AActor> HomingTargetActor; // Offset: 0x4 | Size: 0x8
	struct FVector CurrentLoc; // Offset: 0xc | Size: 0xc
};

// Object: ScriptStruct Solarland.SolarWeaponExpData
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FSolarWeaponExpData {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
};

// Object: ScriptStruct Solarland.CameraShakeData
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FCameraShakeData {
	// Fields
	struct UCameraShake* CameraShakeClass; // Offset: 0x0 | Size: 0x8
	struct UCurveFloat* CameraShakeScaleCurve; // Offset: 0x8 | Size: 0x8
	float ScaleMultiplier; // Offset: 0x10 | Size: 0x4
	float ScopeScaleMultiplier; // Offset: 0x14 | Size: 0x4
	char pad_0x18[0x8]; // Offset: 0x18 | Size: 0x8
};

// Object: ScriptStruct Solarland.PlaySoundParams
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FPlaySoundParams {
	// Fields
	bool HasSilencer; // Offset: 0x0 | Size: 0x1
	bool InSameTeam; // Offset: 0x1 | Size: 0x1
	bool IsInRoom; // Offset: 0x2 | Size: 0x1
	char pad_0x3[0x1]; // Offset: 0x3 | Size: 0x1
	int32_t SoundFireAutoCount; // Offset: 0x4 | Size: 0x4
	bool bTriggerSoundFireBurst; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x3]; // Offset: 0x9 | Size: 0x3
};

// Object: ScriptStruct Solarland.MultiHitResult
// Inherited Bytes: 0x88 | Struct Size: 0xa4
struct FMultiHitResult : FHitResult {
	// Fields
	char Num; // Offset: 0x88 | Size: 0x1
	char Seed; // Offset: 0x89 | Size: 0x1
	char Mode; // Offset: 0x8a | Size: 0x1
	char pad_0x8B[0x1]; // Offset: 0x8b | Size: 0x1
	struct FVector_NetQuantize Start; // Offset: 0x8c | Size: 0xc
	struct FVector_NetQuantize End; // Offset: 0x98 | Size: 0xc
};

// Object: ScriptStruct Solarland.ImpactDisplayInfo
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FImpactDisplayInfo {
	// Fields
	struct FVector Pos; // Offset: 0x0 | Size: 0xc
	float Scale; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct Solarland.FireMode
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FFireMode {
	// Fields
	char Index; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	float FireRateAccumulation; // Offset: 0x4 | Size: 0x4
	float FireRateAccumulationBurstInterval; // Offset: 0x8 | Size: 0x4
	char pad_0xC[0x14]; // Offset: 0xc | Size: 0x14
	struct UParticleSystemComponent* ChargingEffect; // Offset: 0x20 | Size: 0x8
};

// Object: ScriptStruct Solarland.SolarBlackHoleTestActorInfo
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FSolarBlackHoleTestActorInfo {
	// Fields
	char pad_0x0[0x18]; // Offset: 0x0 | Size: 0x18
};

// Object: ScriptStruct Solarland.SolarBlackHoleParticleData
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FSolarBlackHoleParticleData {
	// Fields
	char pad_0x0[0x18]; // Offset: 0x0 | Size: 0x18
};

// Object: ScriptStruct Solarland.SolarBlackHoleParticleInfo
// Inherited Bytes: 0x0 | Struct Size: 0x80
struct FSolarBlackHoleParticleInfo {
	// Fields
	struct FSoftObjectPath ParticlePathForTeammate; // Offset: 0x0 | Size: 0x18
	struct FSoftObjectPath ParticlePathForEnemy; // Offset: 0x18 | Size: 0x18
	struct FTransform RelativeTransform; // Offset: 0x30 | Size: 0x30
	bool bAttachMode; // Offset: 0x60 | Size: 0x1
	char pad_0x61[0x3]; // Offset: 0x61 | Size: 0x3
	struct FName AttachSocketName; // Offset: 0x64 | Size: 0x8
	enum class EAttachLocation AttachLocationType; // Offset: 0x6c | Size: 0x1
	bool bAutoDestroy; // Offset: 0x6d | Size: 0x1
	char pad_0x6E[0x2]; // Offset: 0x6e | Size: 0x2
	float Duration; // Offset: 0x70 | Size: 0x4
	enum class EPSCPoolMethod PoolMode; // Offset: 0x74 | Size: 0x1
	char pad_0x75[0xb]; // Offset: 0x75 | Size: 0xb
};

// Object: ScriptStruct Solarland.WeaponFireLaserElement
// Inherited Bytes: 0x0 | Struct Size: 0x48
struct FWeaponFireLaserElement {
	// Fields
	char pad_0x0[0x38]; // Offset: 0x0 | Size: 0x38
	struct UParticleSystemComponent* BeamEffect; // Offset: 0x38 | Size: 0x8
	char pad_0x40[0x8]; // Offset: 0x40 | Size: 0x8
};

// Object: ScriptStruct Solarland.BulletContainerColor
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FBulletContainerColor {
	// Fields
	struct FColor Normal; // Offset: 0x0 | Size: 0x4
	struct FColor Energy; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarBulletContainerLayout
// Inherited Bytes: 0x0 | Struct Size: 0x1c
struct FSolarBulletContainerLayout {
	// Fields
	struct FVector2D Offset; // Offset: 0x0 | Size: 0x8
	float SpinAngle; // Offset: 0x8 | Size: 0x4
	struct FVector2D Scale; // Offset: 0xc | Size: 0x8
	struct FVector2D OneBulletSize; // Offset: 0x14 | Size: 0x8
};

// Object: ScriptStruct Solarland.SolarBulletWidgetState
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FSolarBulletWidgetState {
	// Fields
	struct UWidget* BulletWidget; // Offset: 0x0 | Size: 0x8
	bool bReloadState; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x7]; // Offset: 0x9 | Size: 0x7
};

// Object: ScriptStruct Solarland.WeaponShotHitResult
// Inherited Bytes: 0x0 | Struct Size: 0x3c
struct FWeaponShotHitResult {
	// Fields
	struct TWeakObjectPtr<struct AActor> Actor; // Offset: 0x0 | Size: 0x8
	struct FVector_NetQuantize Location; // Offset: 0x8 | Size: 0xc
	struct FName BoneName; // Offset: 0x14 | Size: 0x8
	struct FVector_NetQuantizeNormal ImpactNormal; // Offset: 0x1c | Size: 0xc
	char bBlockingHit : 1; // Offset: 0x28 | Size: 0x1
	char pad_0x28_1 : 7; // Offset: 0x28 | Size: 0x1
	char pad_0x29[0x3]; // Offset: 0x29 | Size: 0x3
	struct TWeakObjectPtr<struct UPrimitiveComponent> Component; // Offset: 0x2c | Size: 0x8
	struct TWeakObjectPtr<struct UPhysicalMaterial> PhysMaterial; // Offset: 0x34 | Size: 0x8
};

// Object: ScriptStruct Solarland.SpawnProjParam
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FSpawnProjParam {
	// Fields
	struct FVector_NetQuantize Start; // Offset: 0x0 | Size: 0xc
	struct FVector Velocity; // Offset: 0xc | Size: 0xc
	char Mode; // Offset: 0x18 | Size: 0x1
	char CurRocketNum; // Offset: 0x19 | Size: 0x1
	char bTriggerAnim : 1; // Offset: 0x1a | Size: 0x1
	char pad_0x1A_1 : 7; // Offset: 0x1a | Size: 0x1
	char pad_0x1B[0x1]; // Offset: 0x1b | Size: 0x1
	float Scale; // Offset: 0x1c | Size: 0x4
	float SpeedScale; // Offset: 0x20 | Size: 0x4
	struct TWeakObjectPtr<struct AActor> Target; // Offset: 0x24 | Size: 0x8
	uint32_t SpawnID; // Offset: 0x2c | Size: 0x4
	float Timestamp; // Offset: 0x30 | Size: 0x4
	struct TWeakObjectPtr<struct ASolarPlayerController> InstigatorController; // Offset: 0x34 | Size: 0x8
	struct FVector_NetQuantize RelativeLocation; // Offset: 0x3c | Size: 0xc
	char pad_0x48[0x8]; // Offset: 0x48 | Size: 0x8
};

// Object: ScriptStruct Solarland.AmmoExtraAbilityStruct
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FAmmoExtraAbilityStruct {
	// Fields
	struct TArray<struct ASolarAbility*> PrimaryExtraAbilies; // Offset: 0x0 | Size: 0x10
	struct TArray<struct ASolarAbility*> SecondaryExtraAbilies; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct Solarland.OverrideBulletStruct
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FOverrideBulletStruct {
	// Fields
	struct ASolarBullet* PrimaryOverrideBulletClass; // Offset: 0x0 | Size: 0x8
	struct ASolarBullet* SecondaryOverrideBulletClass; // Offset: 0x8 | Size: 0x8
	struct ASolarBullet* PrimaryOverrideTraceBulletClass; // Offset: 0x10 | Size: 0x8
};

// Object: ScriptStruct Solarland.WeaponDebugFlag
// Inherited Bytes: 0x0 | Struct Size: 0x4
struct FWeaponDebugFlag {
	// Fields
	bool bIgnoreActivated; // Offset: 0x0 | Size: 0x1
	bool bExtraInfo; // Offset: 0x1 | Size: 0x1
	bool bMechanicalState; // Offset: 0x2 | Size: 0x1
	bool bShowShootDir; // Offset: 0x3 | Size: 0x1
};

// Object: ScriptStruct Solarland.LocationEffectParam
// Inherited Bytes: 0x0 | Struct Size: 0x1c
struct FLocationEffectParam {
	// Fields
	struct FRotator Rotation; // Offset: 0x0 | Size: 0xc
	struct FVector Scale; // Offset: 0xc | Size: 0xc
	bool bAutoDestroy; // Offset: 0x18 | Size: 0x1
	enum class EPSCPoolMethod PoolingMethod; // Offset: 0x19 | Size: 0x1
	bool bAutoActivateSystem; // Offset: 0x1a | Size: 0x1
	char pad_0x1B[0x1]; // Offset: 0x1b | Size: 0x1
};

// Object: ScriptStruct Solarland.AttachedEffectParam
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FAttachedEffectParam {
	// Fields
	struct FVector Location; // Offset: 0x0 | Size: 0xc
	struct FRotator Rotation; // Offset: 0xc | Size: 0xc
	struct FVector Scale; // Offset: 0x18 | Size: 0xc
	enum class EAttachLocation LocationType; // Offset: 0x24 | Size: 0x1
	bool bAutoDestroy; // Offset: 0x25 | Size: 0x1
	enum class EPSCPoolMethod PoolingMethod; // Offset: 0x26 | Size: 0x1
	bool bAutoActivate; // Offset: 0x27 | Size: 0x1
};

// Object: ScriptStruct Solarland.SpawnBulletParam
// Inherited Bytes: 0x0 | Struct Size: 0x34
struct FSpawnBulletParam {
	// Fields
	struct FVector Start; // Offset: 0x0 | Size: 0xc
	struct FVector Velocity; // Offset: 0xc | Size: 0xc
	float SpeedScale; // Offset: 0x18 | Size: 0x4
	int32_t Mode; // Offset: 0x1c | Size: 0x4
	bool TriggerAnim; // Offset: 0x20 | Size: 0x1
	char pad_0x21[0x3]; // Offset: 0x21 | Size: 0x3
	float Scale; // Offset: 0x24 | Size: 0x4
	int32_t LastClipAmmo; // Offset: 0x28 | Size: 0x4
	float LastFireTime; // Offset: 0x2c | Size: 0x4
	bool bStartBlocked; // Offset: 0x30 | Size: 0x1
	char pad_0x31[0x3]; // Offset: 0x31 | Size: 0x3
};

// Object: ScriptStruct Solarland.MutiBulletHitData
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FMutiBulletHitData {
	// Fields
	struct FFireUniqueID FireUniqueID; // Offset: 0x0 | Size: 0x4
	int8_t FireMode; // Offset: 0x4 | Size: 0x1
	int8_t IsScopeOpen; // Offset: 0x5 | Size: 0x1
	bool bValidHit; // Offset: 0x6 | Size: 0x1
	char pad_0x7[0x1]; // Offset: 0x7 | Size: 0x1
	struct FVector StartLocation; // Offset: 0x8 | Size: 0xc
	struct FVector WeaponLocation; // Offset: 0x14 | Size: 0xc
	float ServerTimeSeconds; // Offset: 0x20 | Size: 0x4
	float DamageScale; // Offset: 0x24 | Size: 0x4
	int32_t LastClipAmmo; // Offset: 0x28 | Size: 0x4
	float LastFireTime; // Offset: 0x2c | Size: 0x4
	struct TArray<struct FSolarWeaponHitAntiData> HitAntiDatas; // Offset: 0x30 | Size: 0x10
	struct TArray<struct FBulletHitDetailData> HitDetailDataArray; // Offset: 0x40 | Size: 0x10
};

// Object: ScriptStruct Solarland.BulletHitDetailData
// Inherited Bytes: 0x0 | Struct Size: 0x4c
struct FBulletHitDetailData {
	// Fields
	struct TWeakObjectPtr<struct APawn> SourcePawn; // Offset: 0x0 | Size: 0x8
	struct TWeakObjectPtr<struct AActor> HitActor; // Offset: 0x8 | Size: 0x8
	struct TWeakObjectPtr<struct UPrimitiveComponent> HitComponent; // Offset: 0x10 | Size: 0x8
	struct FVector HitActorLocation; // Offset: 0x18 | Size: 0xc
	struct FVector HitLocation; // Offset: 0x24 | Size: 0xc
	struct FVector HitNormal; // Offset: 0x30 | Size: 0xc
	struct FName HitBone; // Offset: 0x3c | Size: 0x8
	struct TWeakObjectPtr<struct UPhysicalMaterial> PhysMaterial; // Offset: 0x44 | Size: 0x8
};

// Object: ScriptStruct Solarland.BulletHitData
// Inherited Bytes: 0x0 | Struct Size: 0xc0
struct FBulletHitData {
	// Fields
	struct FFireUniqueID FireUniqueID; // Offset: 0x0 | Size: 0x4
	int8_t FireMode; // Offset: 0x4 | Size: 0x1
	bool bValidHit; // Offset: 0x5 | Size: 0x1
	char pad_0x6[0x2]; // Offset: 0x6 | Size: 0x2
	struct FVector StartLocation; // Offset: 0x8 | Size: 0xc
	struct FVector WeaponLocation; // Offset: 0x14 | Size: 0xc
	float ServerTimeSeconds; // Offset: 0x20 | Size: 0x4
	float DamageScale; // Offset: 0x24 | Size: 0x4
	int32_t LastClipAmmo; // Offset: 0x28 | Size: 0x4
	float LastFireTime; // Offset: 0x2c | Size: 0x4
	struct FSolarWeaponHitAntiData HitAntiData; // Offset: 0x30 | Size: 0x40
	struct FBulletHitDetailData HitDetailData; // Offset: 0x70 | Size: 0x4c
	char pad_0xBC[0x4]; // Offset: 0xbc | Size: 0x4
};

// Object: ScriptStruct Solarland.WeaponHitResponse
// Inherited Bytes: 0x0 | Struct Size: 0x1
struct FWeaponHitResponse {
	// Fields
	char bForceBlock : 1; // Offset: 0x0 | Size: 0x1
	char bForcePenetrate : 1; // Offset: 0x0 | Size: 0x1
	char bForceAimIgnore : 1; // Offset: 0x0 | Size: 0x1
	char bAffectHalo : 1; // Offset: 0x0 | Size: 0x1
	char bTakeDamage : 1; // Offset: 0x0 | Size: 0x1
	char bShowExplode : 1; // Offset: 0x0 | Size: 0x1
	char bShowDecal : 1; // Offset: 0x0 | Size: 0x1
	char bPlaySound : 1; // Offset: 0x0 | Size: 0x1
};

// Object: ScriptStruct Solarland.WeaponAnimationInfo
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FWeaponAnimationInfo {
	// Fields
	struct FSoftObjectPath AssetPath; // Offset: 0x0 | Size: 0x18
	float PlayRate; // Offset: 0x18 | Size: 0x4
	bool bUseAdaptivePlayRate; // Offset: 0x1c | Size: 0x1
	char pad_0x1D[0x3]; // Offset: 0x1d | Size: 0x3
	struct UAnimMontage* Animation; // Offset: 0x20 | Size: 0x8
	struct UAnimMontage* AnimOverride; // Offset: 0x28 | Size: 0x8
};

// Object: ScriptStruct Solarland.WeaponMergeMeshStruct
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FWeaponMergeMeshStruct {
	// Fields
	struct FGuid Guid; // Offset: 0x0 | Size: 0x10
	int32_t weaponid; // Offset: 0x10 | Size: 0x4
	int32_t SkinId; // Offset: 0x14 | Size: 0x4
	struct TArray<int32_t> Parts; // Offset: 0x18 | Size: 0x10
	struct USkeletalMesh* MergeMesh; // Offset: 0x28 | Size: 0x8
};

// Object: ScriptStruct Solarland.SolarWeaponPartDescRow
// Inherited Bytes: 0x8 | Struct Size: 0x18
struct FSolarWeaponPartDescRow : FTableRowBase {
	// Fields
	struct TArray<struct FSolarWeaponPartEffectDesc> DescriptionArray; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct Solarland.SolarWeaponPartEffectDesc
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FSolarWeaponPartEffectDesc {
	// Fields
	struct FString EffectValue; // Offset: 0x0 | Size: 0x10
	int32_t DescriptionLocalTextID; // Offset: 0x10 | Size: 0x4
	int32_t Priority; // Offset: 0x14 | Size: 0x4
	int32_t PartID; // Offset: 0x18 | Size: 0x4
	int32_t weaponid; // Offset: 0x1c | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarWeaponFPPConfig
// Inherited Bytes: 0x0 | Struct Size: 0x70
struct FSolarWeaponFPPConfig {
	// Fields
	struct FRangeFloat AspectRatioRange; // Offset: 0x0 | Size: 0x8
	struct FSolarWeaponFPPData FPPData; // Offset: 0x8 | Size: 0x68
};

// Object: ScriptStruct Solarland.SolarWeaponFPPData
// Inherited Bytes: 0x0 | Struct Size: 0x68
struct FSolarWeaponFPPData {
	// Fields
	struct TMap<enum class EWeaponScopeType, struct FSolarWeaponScopeFPPConfig> ScopeFPPConfigByScopeTypeMap; // Offset: 0x0 | Size: 0x50
	struct FSolarWeaponScopeFPPData DefaultFPPDataForScopeType; // Offset: 0x50 | Size: 0x18
};

// Object: ScriptStruct Solarland.SolarWeaponScopeFPPData
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FSolarWeaponScopeFPPData {
	// Fields
	struct FVector RelativeLocation; // Offset: 0x0 | Size: 0xc
	struct FRotator RelativeRotation; // Offset: 0xc | Size: 0xc
};

// Object: ScriptStruct Solarland.SolarWeaponScopeFPPConfig
// Inherited Bytes: 0x0 | Struct Size: 0x68
struct FSolarWeaponScopeFPPConfig {
	// Fields
	struct TMap<int32_t, struct FSolarWeaponScopeFPPData> ScopeFPPDataByWeaponSkinIDMap; // Offset: 0x0 | Size: 0x50
	struct FSolarWeaponScopeFPPData DefaultFPPDataForWeaponSkinID; // Offset: 0x50 | Size: 0x18
};

// Object: ScriptStruct Solarland.WheelData
// Inherited Bytes: 0x0 | Struct Size: 0x270
struct FWheelData {
	// Fields
	bool bIsPowered; // Offset: 0x0 | Size: 0x1
	bool bIsPoweredInDrift; // Offset: 0x1 | Size: 0x1
	char pad_0x2[0x2]; // Offset: 0x2 | Size: 0x2
	struct FName BoneName; // Offset: 0x4 | Size: 0x8
	struct FVector Offset; // Offset: 0xc | Size: 0xc
	struct FVector WheelForceOffset; // Offset: 0x18 | Size: 0xc
	float Radius; // Offset: 0x24 | Size: 0x4
	float RadiusAfterBroken; // Offset: 0x28 | Size: 0x4
	float Width; // Offset: 0x2c | Size: 0x4
	float MaxRaise; // Offset: 0x30 | Size: 0x4
	float MaxDrop; // Offset: 0x34 | Size: 0x4
	float SpringStiffness; // Offset: 0x38 | Size: 0x4
	float DamperStiffness; // Offset: 0x3c | Size: 0x4
	float LaterialFriction; // Offset: 0x40 | Size: 0x4
	float LaterialFrictionAfterBroken; // Offset: 0x44 | Size: 0x4
	float LaterialFrictionInDrift; // Offset: 0x48 | Size: 0x4
	float DriftingLaterialFrictionLerpSpeed; // Offset: 0x4c | Size: 0x4
	struct FRuntimeFloatCurve EndDriftFrictionCurve; // Offset: 0x50 | Size: 0x88
	char pad_0xD8[0x8]; // Offset: 0xd8 | Size: 0x8
	struct FVehicleVFX DriftDecal; // Offset: 0xe0 | Size: 0x90
	float RollingFriction; // Offset: 0x170 | Size: 0x4
	float BrakeDeceleration; // Offset: 0x174 | Size: 0x4
	float DustEffectScale; // Offset: 0x178 | Size: 0x4
	float DustEffectScaleAfterBroken; // Offset: 0x17c | Size: 0x4
	float DriftEffectScale; // Offset: 0x180 | Size: 0x4
	char pad_0x184[0xdc]; // Offset: 0x184 | Size: 0xdc
	struct UParticleSystemComponent* RaiseDustParticleComponent; // Offset: 0x260 | Size: 0x8
	struct UParticleSystemComponent* DriftParticleComponent; // Offset: 0x268 | Size: 0x8
};

// Object: ScriptStruct Solarland.GearSetting
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FGearSetting {
	// Fields
	float MinSpeed; // Offset: 0x0 | Size: 0x4
	float MaxSpeed; // Offset: 0x4 | Size: 0x4
	float StartRpm; // Offset: 0x8 | Size: 0x4
	float MaxRpm; // Offset: 0xc | Size: 0x4
	float RpmDescendSpeed; // Offset: 0x10 | Size: 0x4
	float MinDescendRPM; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct Solarland.GearData
// Inherited Bytes: 0x0 | Struct Size: 0x1c
struct FGearData {
	// Fields
	char pad_0x0[0x1c]; // Offset: 0x0 | Size: 0x1c
};

// Object: ScriptStruct Solarland.SolarVirtualInput
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FSolarVirtualInput {
	// Fields
	enum class EInputEventHandleType InputBindType; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x7]; // Offset: 0x1 | Size: 0x7
	struct FKey VirtualKey; // Offset: 0x8 | Size: 0x18
};

// Object: ScriptStruct Solarland.ZiplineObjData
// Inherited Bytes: 0x0 | Struct Size: 0x74
struct FZiplineObjData {
	// Fields
	struct FSidesOfZiplineData ASideData; // Offset: 0x0 | Size: 0x30
	struct FSidesOfZiplineData BSideData; // Offset: 0x30 | Size: 0x30
	enum class EZiplineType ZiplineType; // Offset: 0x60 | Size: 0x1
	char pad_0x61[0x3]; // Offset: 0x61 | Size: 0x3
	float CableCollisionScale; // Offset: 0x64 | Size: 0x4
	bool bLookAtTarget; // Offset: 0x68 | Size: 0x1
	char pad_0x69[0x3]; // Offset: 0x69 | Size: 0x3
	float SlidingVelocity; // Offset: 0x6c | Size: 0x4
	float CancelledVelocity; // Offset: 0x70 | Size: 0x4
};

// Object: ScriptStruct Solarland.SidesOfZiplineData
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FSidesOfZiplineData {
	// Fields
	struct FVector BeginningLocation; // Offset: 0x0 | Size: 0xc
	struct FVector ArrivingLocation; // Offset: 0xc | Size: 0xc
	struct FVector LandingLocation; // Offset: 0x18 | Size: 0xc
	float ArrivingVelocity; // Offset: 0x24 | Size: 0x4
	bool bLandingAfterArriving; // Offset: 0x28 | Size: 0x1
	char pad_0x29[0x3]; // Offset: 0x29 | Size: 0x3
	float LandingVelocity; // Offset: 0x2c | Size: 0x4
};

// Object: ScriptStruct Solarland.SoundPoolContainer
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FSoundPoolContainer {
	// Fields
	struct TArray<struct USoundPoolDataAsset*> SoundPoolDataAssets; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Solarland.SoundGroupContainer
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FSoundGroupContainer {
	// Fields
	struct TArray<struct USoundGroupDataAsset*> SoundGroupDataAssets; // Offset: 0x0 | Size: 0x10
	struct TArray<struct UDataTable*> SoundGroupDataTables; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct Solarland.SoundGroupByBattleAdvancedTableData
// Inherited Bytes: 0x8 | Struct Size: 0x98
struct FSoundGroupByBattleAdvancedTableData : FSoundGroupTableDataBase {
	// Fields
	struct FSoundGroupSoundEvent IAttackOtherEvent; // Offset: 0x8 | Size: 0x30
	struct FSoundGroupSoundEvent OtherAttackMeEvent; // Offset: 0x38 | Size: 0x30
	struct FSoundGroupSoundEvent OtherEvent; // Offset: 0x68 | Size: 0x30
};

// Object: ScriptStruct Solarland.SoundGroupSoundEvent
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FSoundGroupSoundEvent {
	// Fields
	struct FString SoundEvent; // Offset: 0x0 | Size: 0x10
	struct FSoundGroupWwiseParams WwiseParams; // Offset: 0x10 | Size: 0x20
};

// Object: ScriptStruct Solarland.SoundGroupWwiseParams
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FSoundGroupWwiseParams {
	// Fields
	struct TArray<struct FWwiseSwitchParam> SwitchParams; // Offset: 0x0 | Size: 0x10
	struct TArray<struct FWwiseRTPCParam> RTPCParams; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct Solarland.WwiseRTPCParam
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FWwiseRTPCParam {
	// Fields
	struct FString RTPC; // Offset: 0x0 | Size: 0x10
	float Value; // Offset: 0x10 | Size: 0x4
	char pad_0x14[0x4]; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct Solarland.WwiseSwitchParam
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FWwiseSwitchParam {
	// Fields
	struct FString SwitchGroup; // Offset: 0x0 | Size: 0x10
	struct FString SwitchState; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct Solarland.SoundGroupByTeammateAdvancedTableData
// Inherited Bytes: 0x8 | Struct Size: 0x98
struct FSoundGroupByTeammateAdvancedTableData : FSoundGroupTableDataBase {
	// Fields
	struct FSoundGroupSoundEvent SelfEvent; // Offset: 0x8 | Size: 0x30
	struct FSoundGroupSoundEvent TeammateEvent; // Offset: 0x38 | Size: 0x30
	struct FSoundGroupSoundEvent OtherEvent; // Offset: 0x68 | Size: 0x30
};

// Object: ScriptStruct Solarland.SoundGroupSimpleAdvancedTableData
// Inherited Bytes: 0x8 | Struct Size: 0x38
struct FSoundGroupSimpleAdvancedTableData : FSoundGroupTableDataBase {
	// Fields
	struct FSoundGroupSoundEvent SoundEvent; // Offset: 0x8 | Size: 0x30
};

// Object: ScriptStruct Solarland.SoundGroupShareParamsTableDataBase
// Inherited Bytes: 0x8 | Struct Size: 0x28
struct FSoundGroupShareParamsTableDataBase : FSoundGroupTableDataBase {
	// Fields
	struct FSoundGroupWwiseParams WwiseParams; // Offset: 0x8 | Size: 0x20
};

// Object: ScriptStruct Solarland.SoundGroupByBattleTableData
// Inherited Bytes: 0x28 | Struct Size: 0x58
struct FSoundGroupByBattleTableData : FSoundGroupShareParamsTableDataBase {
	// Fields
	struct FString IAttackOtherEvent; // Offset: 0x28 | Size: 0x10
	struct FString OtherAttackMeEvent; // Offset: 0x38 | Size: 0x10
	struct FString OtherEvent; // Offset: 0x48 | Size: 0x10
};

// Object: ScriptStruct Solarland.SoundGroupByTeammateTableData
// Inherited Bytes: 0x28 | Struct Size: 0x58
struct FSoundGroupByTeammateTableData : FSoundGroupShareParamsTableDataBase {
	// Fields
	struct FString SelfEvent; // Offset: 0x28 | Size: 0x10
	struct FString TeammateEvent; // Offset: 0x38 | Size: 0x10
	struct FString OtherEvent; // Offset: 0x48 | Size: 0x10
};

// Object: ScriptStruct Solarland.SoundGroupSimpleTableData
// Inherited Bytes: 0x28 | Struct Size: 0x38
struct FSoundGroupSimpleTableData : FSoundGroupShareParamsTableDataBase {
	// Fields
	struct FString SoundEvent; // Offset: 0x28 | Size: 0x10
};

// Object: ScriptStruct Solarland.SoundGroupPlayContextSimple
// Inherited Bytes: 0x8 | Struct Size: 0x10
struct FSoundGroupPlayContextSimple : FSoundGroupPlayContext {
	// Fields
	enum class ESoundGroupPlayContextEnum Context; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x7]; // Offset: 0x9 | Size: 0x7
};

// Object: ScriptStruct Solarland.SpatializeItem
// Inherited Bytes: 0xc | Struct Size: 0x18
struct FSpatializeItem : FFastArraySerializerItem {
	// Fields
	struct FVector Location; // Offset: 0xc | Size: 0xc
};

// Object: ScriptStruct Solarland.TrackArray
// Inherited Bytes: 0x108 | Struct Size: 0x130
struct FTrackArray : FFastArraySerializer {
	// Fields
	struct TArray<struct FTrackItem> Tracks; // Offset: 0x108 | Size: 0x10
	char pad_0x118[0x18]; // Offset: 0x118 | Size: 0x18
};

// Object: ScriptStruct Solarland.TrackItem
// Inherited Bytes: 0x18 | Struct Size: 0x40
struct FTrackItem : FSpatializeItem {
	// Fields
	float Time; // Offset: 0x18 | Size: 0x4
	char pad_0x1C[0x4]; // Offset: 0x1c | Size: 0x4
	struct FString PID; // Offset: 0x20 | Size: 0x10
	bool bValid; // Offset: 0x30 | Size: 0x1
	bool bProjected; // Offset: 0x31 | Size: 0x1
	char pad_0x32[0x2]; // Offset: 0x32 | Size: 0x2
	struct FVector FloorLocation; // Offset: 0x34 | Size: 0xc
};

// Object: ScriptStruct Solarland.SolarImageProgressInfo
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FSolarImageProgressInfo {
	// Fields
	enum class ESolarImageProgressType ProgressType; // Offset: 0x0 | Size: 0x1
	enum class ESolarImageProgressLineDirType LineProgressDir; // Offset: 0x1 | Size: 0x1
	enum class ESolarImageProgressQuaterCirclePrivotType QuaterProgressPrivot; // Offset: 0x2 | Size: 0x1
	enum class ESolarImageProgressHalfCirclePrivotType HalfProgressPrivot; // Offset: 0x3 | Size: 0x1
	float CircleProgressInitDegree; // Offset: 0x4 | Size: 0x4
	bool bInvertProgressDir; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x3]; // Offset: 0x9 | Size: 0x3
	float Progress; // Offset: 0xc | Size: 0x4
	struct UMaterial* Material; // Offset: 0x10 | Size: 0x8
	struct UMaterialInstanceDynamic* MaterialInstance; // Offset: 0x18 | Size: 0x8
};

// Object: ScriptStruct Solarland.PlayerBattleRequestInfo
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FPlayerBattleRequestInfo {
	// Fields
	struct FString NickName; // Offset: 0x0 | Size: 0x10
	int32_t AccountLevel; // Offset: 0x10 | Size: 0x4
	char pad_0x14[0x4]; // Offset: 0x14 | Size: 0x4
	struct FPlatformParams PlatformParams; // Offset: 0x18 | Size: 0x18
};

// Object: ScriptStruct Solarland.PlatformParams
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FPlatformParams {
	// Fields
	int64_t UserId; // Offset: 0x0 | Size: 0x8
	struct FString OpenId; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct Solarland.StartBattleRequestInfo
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FStartBattleRequestInfo {
	// Fields
	int32_t aiNum; // Offset: 0x0 | Size: 0x4
	int32_t AiLevel; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarSummonSoundData
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FSolarSummonSoundData {
	// Fields
	struct TArray<struct FString> SoundNames; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Solarland.SplineMeshDetails
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FSplineMeshDetails {
	// Fields
	struct UStaticMesh* Mesh; // Offset: 0x0 | Size: 0x8
	enum class ESplineMeshAxis ForwardAxis; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x7]; // Offset: 0x9 | Size: 0x7
	struct UMaterialInterface* FirstMaterial; // Offset: 0x10 | Size: 0x8
	struct UMaterialInterface* SecondMaterial; // Offset: 0x18 | Size: 0x8
	struct FVector2D StartScale; // Offset: 0x20 | Size: 0x8
	float StartRoll; // Offset: 0x28 | Size: 0x4
	struct FVector2D StartOffset; // Offset: 0x2c | Size: 0x8
	struct FVector2D EndScale; // Offset: 0x34 | Size: 0x8
	float EndRoll; // Offset: 0x3c | Size: 0x4
	struct FVector2D EndOffset; // Offset: 0x40 | Size: 0x8
	int32_t TranslucencySortPriority; // Offset: 0x48 | Size: 0x4
	char pad_0x4C[0x4]; // Offset: 0x4c | Size: 0x4
};

// Object: ScriptStruct Solarland.UITweenBaseStruct
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FUITweenBaseStruct {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
	bool IsValid; // Offset: 0x8 | Size: 0x1
	enum class ETweenInterpolationType InterpolationType; // Offset: 0x9 | Size: 0x1
	enum class EEasingFunc EaseType; // Offset: 0xa | Size: 0x1
	char pad_0xB[0x5]; // Offset: 0xb | Size: 0x5
	struct UCurveFloat* InterpolationCurve; // Offset: 0x10 | Size: 0x8
	struct UWidget* Widget; // Offset: 0x18 | Size: 0x8
};

// Object: ScriptStruct Solarland.TextColorTween
// Inherited Bytes: 0x20 | Struct Size: 0x48
struct FTextColorTween : FUITweenBaseStruct {
	// Fields
	struct FLinearColor Original; // Offset: 0x20 | Size: 0x10
	struct FLinearColor TargetColor; // Offset: 0x30 | Size: 0x10
	struct UTextBlock* TargetText; // Offset: 0x40 | Size: 0x8
};

// Object: ScriptStruct Solarland.ImageColorTween
// Inherited Bytes: 0x20 | Struct Size: 0x48
struct FImageColorTween : FUITweenBaseStruct {
	// Fields
	struct FLinearColor Original; // Offset: 0x20 | Size: 0x10
	struct FLinearColor TargetColor; // Offset: 0x30 | Size: 0x10
	struct UImage* Image; // Offset: 0x40 | Size: 0x8
};

// Object: ScriptStruct Solarland.UIRenderOpacityTween
// Inherited Bytes: 0x20 | Struct Size: 0x28
struct FUIRenderOpacityTween : FUITweenBaseStruct {
	// Fields
	float OriginalOpacity; // Offset: 0x20 | Size: 0x4
	float TargetOpacity; // Offset: 0x24 | Size: 0x4
};

// Object: ScriptStruct Solarland.UIPositionTween
// Inherited Bytes: 0x20 | Struct Size: 0x40
struct FUIPositionTween : FUITweenBaseStruct {
	// Fields
	struct FVector2D OriginalPosition; // Offset: 0x20 | Size: 0x8
	struct FVector2D TargetPosition; // Offset: 0x28 | Size: 0x8
	bool bHandleAsRelativeChange; // Offset: 0x30 | Size: 0x1
	char pad_0x31[0xf]; // Offset: 0x31 | Size: 0xf
};

// Object: ScriptStruct Solarland.UIScaleTween
// Inherited Bytes: 0x20 | Struct Size: 0x40
struct FUIScaleTween : FUITweenBaseStruct {
	// Fields
	struct FVector2D OriginalScale; // Offset: 0x20 | Size: 0x8
	struct FVector2D TargetScale; // Offset: 0x28 | Size: 0x8
	bool bHandleAsMultiplier; // Offset: 0x30 | Size: 0x1
	char pad_0x31[0xf]; // Offset: 0x31 | Size: 0xf
};

// Object: ScriptStruct Solarland.OBTeamColor
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FOBTeamColor {
	// Fields
	struct FString Desc; // Offset: 0x0 | Size: 0x10
	struct FLinearColor Main; // Offset: 0x10 | Size: 0x10
	struct FLinearColor Vice; // Offset: 0x20 | Size: 0x10
};

// Object: ScriptStruct Solarland.ItemQualityData
// Inherited Bytes: 0x0 | Struct Size: 0x88
struct FItemQualityData {
	// Fields
	struct FLinearColor BaseColor; // Offset: 0x0 | Size: 0x10
	struct FLinearColor HUDColor; // Offset: 0x10 | Size: 0x10
	struct FLinearColor HighQualityColor; // Offset: 0x20 | Size: 0x10
	struct FLinearColor LowQualityColor; // Offset: 0x30 | Size: 0x10
	struct FLinearColor HUDBGColor; // Offset: 0x40 | Size: 0x10
	struct FLinearColor HUDDecorateColor; // Offset: 0x50 | Size: 0x10
	struct FSoftObjectPath QualityIcon; // Offset: 0x60 | Size: 0x18
	struct FString QualityChar; // Offset: 0x78 | Size: 0x10
};

// Object: ScriptStruct Solarland.TeamMemberColor
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FTeamMemberColor {
	// Fields
	struct FLinearColor Main; // Offset: 0x0 | Size: 0x10
	struct FLinearColor Vice; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct Solarland.DestroyObjectStruct
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FDestroyObjectStruct {
	// Fields
	struct UUserWidget* RootWidget; // Offset: 0x0 | Size: 0x8
	struct FString FullPath; // Offset: 0x8 | Size: 0x10
	struct TArray<struct FDestroyObjectEntry> Objects; // Offset: 0x18 | Size: 0x10
};

// Object: ScriptStruct Solarland.DestroyObjectEntry
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FDestroyObjectEntry {
	// Fields
	struct UObject* Object; // Offset: 0x0 | Size: 0x8
	struct FString FullPath; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct Solarland.CustomWidget_TableRow
// Inherited Bytes: 0x8 | Struct Size: 0x98
struct FCustomWidget_TableRow : FTableRowBase {
	// Fields
	struct FSoftObjectPath TeammateState; // Offset: 0x8 | Size: 0x18
	struct FSoftObjectPath BattleScore; // Offset: 0x20 | Size: 0x18
	struct FSoftObjectPath SpectatorListPath; // Offset: 0x38 | Size: 0x18
	struct FSoftObjectPath SafeAreaProgress; // Offset: 0x50 | Size: 0x18
	struct FSoftObjectPath JobEffectListPath; // Offset: 0x68 | Size: 0x18
	struct FSoftObjectPath JobEffectSelectPanelPath; // Offset: 0x80 | Size: 0x18
};

// Object: ScriptStruct Solarland.KillTotalNoticeWidget
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FKillTotalNoticeWidget {
	// Fields
	struct TArray<struct UImage*> Img_KillTotals; // Offset: 0x0 | Size: 0x10
	struct USolarTextBlock* Txt_KillTotal; // Offset: 0x10 | Size: 0x8
};

// Object: ScriptStruct Solarland.UIPanelConfigEntry
// Inherited Bytes: 0x0 | Struct Size: 0x38
struct FUIPanelConfigEntry {
	// Fields
	struct FSoftClassPath MobileUIPath; // Offset: 0x0 | Size: 0x18
	struct FSoftClassPath DesktopUIPath; // Offset: 0x18 | Size: 0x18
	enum class EUIRoot UILayerRoot; // Offset: 0x30 | Size: 0x1
	bool bPrecache; // Offset: 0x31 | Size: 0x1
	char pad_0x32[0x6]; // Offset: 0x32 | Size: 0x6
};

// Object: ScriptStruct Solarland.InteractionButtonSpec
// Inherited Bytes: 0x0 | Struct Size: 0x4
struct FInteractionButtonSpec {
	// Fields
	int32_t Priority; // Offset: 0x0 | Size: 0x4
};

// Object: ScriptStruct Solarland.StarterUIInfo
// Inherited Bytes: 0x0 | Struct Size: 0x88
struct FStarterUIInfo {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x0 | Size: 0x10
	struct UUserWidget* UIClass; // Offset: 0x10 | Size: 0x8
	struct TSoftClassPtr<UObject> MobileUIClass; // Offset: 0x18 | Size: 0x28
	struct TSoftClassPtr<UObject> DesktopUIClass; // Offset: 0x40 | Size: 0x28
	bool bCreateForEachDisplay; // Offset: 0x68 | Size: 0x1
	char pad_0x69[0x3]; // Offset: 0x69 | Size: 0x3
	int32_t OrderFromTopOverride; // Offset: 0x6c | Size: 0x4
	bool bFullScreen; // Offset: 0x70 | Size: 0x1
	char pad_0x71[0x17]; // Offset: 0x71 | Size: 0x17
};

// Object: ScriptStruct Solarland.LruWidgetPool
// Inherited Bytes: 0x0 | Struct Size: 0x80
struct FLruWidgetPool {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
	struct TArray<struct UUserWidget*> ActiveWidgetStack; // Offset: 0x8 | Size: 0x10
	char pad_0x18[0x68]; // Offset: 0x18 | Size: 0x68
};

// Object: ScriptStruct Solarland.VehicleSkinWeakPoint
// Inherited Bytes: 0x0 | Struct Size: 0x70
struct FVehicleSkinWeakPoint {
	// Fields
	struct TSoftObjectPtr<UStaticMesh> WeakPointStaticMesh; // Offset: 0x0 | Size: 0x28
	bool bWeakPointOffset; // Offset: 0x28 | Size: 0x1
	char pad_0x29[0x3]; // Offset: 0x29 | Size: 0x3
	struct FVector WeakPointOffset; // Offset: 0x2c | Size: 0xc
	bool bWeakPointTransform; // Offset: 0x38 | Size: 0x1
	char pad_0x39[0x7]; // Offset: 0x39 | Size: 0x7
	struct FTransform WeakPointRelativeTransform; // Offset: 0x40 | Size: 0x30
};

// Object: ScriptStruct Solarland.VehicleSkinSeat
// Inherited Bytes: 0x0 | Struct Size: 0x58
struct FVehicleSkinSeat {
	// Fields
	struct TArray<struct USolarVehicleGameplayAbility*> VechicleSkinAbilities; // Offset: 0x0 | Size: 0x10
	struct ASolarVehicleWeapon* VehicleSkinWeapon; // Offset: 0x10 | Size: 0x8
	struct UVehicleCameraDataAsset* OutShootCameraData; // Offset: 0x18 | Size: 0x8
	struct UVehicleCameraDataAsset* OutShootAimCameraData; // Offset: 0x20 | Size: 0x8
	struct UCurveFloat* OutShootPitchLimitCurve; // Offset: 0x28 | Size: 0x8
	struct TSoftObjectPtr<UTexture2D> SeatDisplayIcon; // Offset: 0x30 | Size: 0x28
};

// Object: ScriptStruct Solarland.SolarVehicleSkinPreviewPageInfo
// Inherited Bytes: 0x0 | Struct Size: 0x2
struct FSolarVehicleSkinPreviewPageInfo {
	// Fields
	bool bMirror; // Offset: 0x0 | Size: 0x1
	bool bChangeAnim; // Offset: 0x1 | Size: 0x1
};

// Object: ScriptStruct Solarland.SolarVehicleSkinPreviewMeshInfo
// Inherited Bytes: 0x0 | Struct Size: 0xc0
struct FSolarVehicleSkinPreviewMeshInfo {
	// Fields
	struct USkeletalMesh* Mesh; // Offset: 0x0 | Size: 0x8
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FTransform Transform; // Offset: 0x10 | Size: 0x30
	struct UAnimationAsset* AnimToPlay; // Offset: 0x40 | Size: 0x8
	struct UAnimationAsset* PageAnimToPlay[0xa]; // Offset: 0x48 | Size: 0x50
	struct TArray<struct UMaterialInterface*> OverrideMaterials; // Offset: 0x98 | Size: 0x10
	struct FName SocketName; // Offset: 0xa8 | Size: 0x8
	struct TArray<float> CustomData; // Offset: 0xb0 | Size: 0x10
};

// Object: ScriptStruct Solarland.VehicleStateAir
// Inherited Bytes: 0x78 | Struct Size: 0x80
struct FVehicleStateAir : FVehicleState {
	// Fields
	char pad_0x78[0x8]; // Offset: 0x78 | Size: 0x8
};

// Object: ScriptStruct Solarland.VehicleAirToGround
// Inherited Bytes: 0x18 | Struct Size: 0x18
struct FVehicleAirToGround : FVehicleStateTransition {
};

// Object: ScriptStruct Solarland.VehicleStateGround
// Inherited Bytes: 0x78 | Struct Size: 0x90
struct FVehicleStateGround : FVehicleState {
	// Fields
	char pad_0x78[0x18]; // Offset: 0x78 | Size: 0x18
};

// Object: ScriptStruct Solarland.VehicleGroundToSliding
// Inherited Bytes: 0x18 | Struct Size: 0x18
struct FVehicleGroundToSliding : FVehicleStateTransition {
};

// Object: ScriptStruct Solarland.VehicleStateSliding
// Inherited Bytes: 0x78 | Struct Size: 0x78
struct FVehicleStateSliding : FVehicleState {
};

// Object: ScriptStruct Solarland.VehicleSlidingToGround
// Inherited Bytes: 0x18 | Struct Size: 0x18
struct FVehicleSlidingToGround : FVehicleStateTransition {
};

// Object: ScriptStruct Solarland.StealthMaterialParams
// Inherited Bytes: 0x0 | Struct Size: 0xa0
struct FStealthMaterialParams {
	// Fields
	struct TMap<struct FName, float> ScalarParams; // Offset: 0x0 | Size: 0x50
	struct TMap<struct FName, struct FLinearColor> VectorParams; // Offset: 0x50 | Size: 0x50
};

// Object: ScriptStruct Solarland.VehicleWeaponCrossHairInfo
// Inherited Bytes: 0x0 | Struct Size: 0x24
struct FVehicleWeaponCrossHairInfo {
	// Fields
	bool bShowCrossHair; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	struct FVector2D CrossHairPosition; // Offset: 0x4 | Size: 0x8
	float CrossHairOpacity; // Offset: 0xc | Size: 0x4
	bool bShowReticleDirection; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x3]; // Offset: 0x11 | Size: 0x3
	struct FVector2D ReticleDirectionPosition; // Offset: 0x14 | Size: 0x8
	float ReticleDirectionAngle; // Offset: 0x1c | Size: 0x4
	bool bCrossHairForbid; // Offset: 0x20 | Size: 0x1
	char pad_0x21[0x3]; // Offset: 0x21 | Size: 0x3
};

// Object: ScriptStruct Solarland.VertexAnimInfo
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FVertexAnimInfo {
	// Fields
	int32_t StartFrame; // Offset: 0x0 | Size: 0x4
	int32_t EndFrame; // Offset: 0x4 | Size: 0x4
	float Length; // Offset: 0x8 | Size: 0x4
	bool Loop; // Offset: 0xc | Size: 0x1
	char pad_0xD[0x3]; // Offset: 0xd | Size: 0x3
};

// Object: ScriptStruct Solarland.VibrateWeaponFactorDeviceMap
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FVibrateWeaponFactorDeviceMap {
	// Fields
	struct TMap<enum class EVibrateDeviceType, float> DeviceMap; // Offset: 0x0 | Size: 0x50
};

// Object: ScriptStruct Solarland.VibrateDataDTRow
// Inherited Bytes: 0x8 | Struct Size: 0x20
struct FVibrateDataDTRow : FTableRowBase {
	// Fields
	struct FSoftObjectPath ClipPath; // Offset: 0x8 | Size: 0x18
};

// Object: ScriptStruct Solarland.VisualSoundData
// Inherited Bytes: 0x0 | Struct Size: 0x58
struct FVisualSoundData {
	// Fields
	struct FVisualSoundTagData TagsCondition; // Offset: 0x0 | Size: 0x40
	enum class EVisualSoundDetectionRule DetectionRule; // Offset: 0x40 | Size: 0x1
	char pad_0x41[0x3]; // Offset: 0x41 | Size: 0x3
	float DetectionDis; // Offset: 0x44 | Size: 0x4
	float DetectionZ; // Offset: 0x48 | Size: 0x4
	float AliveTime; // Offset: 0x4c | Size: 0x4
	float CanBreakTime; // Offset: 0x50 | Size: 0x4
	char pad_0x54[0x4]; // Offset: 0x54 | Size: 0x4
};

// Object: ScriptStruct Solarland.VisualSoundTagData
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FVisualSoundTagData {
	// Fields
	struct FGameplayTagContainer RequiredTagsAny; // Offset: 0x0 | Size: 0x20
	struct FGameplayTagContainer BlockedTagsAny; // Offset: 0x20 | Size: 0x20
};

// Object: ScriptStruct Solarland.AnimMsgData
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FAnimMsgData {
	// Fields
	enum class EWeaponAnimState State; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	float Speed; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct Solarland.WeaponAssistAimByCharacterTag
// Inherited Bytes: 0x0 | Struct Size: 0x58
struct FWeaponAssistAimByCharacterTag {
	// Fields
	struct FGameplayTagRequirements TagRequirements; // Offset: 0x0 | Size: 0x50
	struct UWeaponAssistAimWeaponConfig* AssistAimConfig; // Offset: 0x50 | Size: 0x8
};

// Object: ScriptStruct Solarland.WeaponAssistAimWeaponConfigAll
// Inherited Bytes: 0x0 | Struct Size: 0x60
struct FWeaponAssistAimWeaponConfigAll {
	// Fields
	struct UWeaponAssistAimWeaponConfig* DefaultConfig; // Offset: 0x0 | Size: 0x8
	struct UWeaponAssistAimWeaponConfig* DefaultScopeConfig; // Offset: 0x8 | Size: 0x8
	struct TMap<enum class EWeaponScopeType, struct UWeaponAssistAimWeaponConfig*> ScopeConfigMap; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.BaseFollowSpeedByTag
// Inherited Bytes: 0x0 | Struct Size: 0xe8
struct FBaseFollowSpeedByTag {
	// Fields
	struct FGameplayTagRequirements TagRequirements; // Offset: 0x0 | Size: 0x50
	float SameTargetTriggerCooldown; // Offset: 0x50 | Size: 0x4
	float HorizontalSpeed; // Offset: 0x54 | Size: 0x4
	float VerticalSpeed; // Offset: 0x58 | Size: 0x4
	char pad_0x5C[0x4]; // Offset: 0x5c | Size: 0x4
	struct FRuntimeFloatCurve SpeedScaleByDistanceCurve; // Offset: 0x60 | Size: 0x88
};

// Object: ScriptStruct Solarland.PlayerWeaponSoundGroupMappingData
// Inherited Bytes: 0x8 | Struct Size: 0x100
struct FPlayerWeaponSoundGroupMappingData : FTableRowBase {
	// Fields
	struct TMap<int32_t, struct FName> SkinMapping; // Offset: 0x8 | Size: 0x50
	struct TMap<int32_t, struct FName> IDMapping; // Offset: 0x58 | Size: 0x50
	struct TMap<enum class EWeaponType, struct FName> TypeMapping; // Offset: 0xa8 | Size: 0x50
	struct FName Default; // Offset: 0xf8 | Size: 0x8
};

// Object: ScriptStruct Solarland.SolarWeaponAttachDataTableRow
// Inherited Bytes: 0x8 | Struct Size: 0x160
struct FSolarWeaponAttachDataTableRow : FTableRowBase {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FWeaponAttachData DefaultAttachData; // Offset: 0x10 | Size: 0x100
	struct TMap<int32_t, struct FWeaponAttachData> WeaponSkinSpecificData; // Offset: 0x110 | Size: 0x50
};

// Object: ScriptStruct Solarland.WeaponAttachData
// Inherited Bytes: 0x0 | Struct Size: 0x100
struct FWeaponAttachData {
	// Fields
	struct FWeaponAttachTransformData DefaultRelativeTransform; // Offset: 0x0 | Size: 0x60
	struct TMap<enum class ECharacterBodyScaleType, struct FWeaponAttachTransformData> TransformByBodyScale; // Offset: 0x60 | Size: 0x50
	struct TMap<int32_t, struct FWeaponAttachDataByCharacter> CharacterSpecificData; // Offset: 0xb0 | Size: 0x50
};

// Object: ScriptStruct Solarland.WeaponAttachDataByCharacter
// Inherited Bytes: 0x0 | Struct Size: 0xb0
struct FWeaponAttachDataByCharacter {
	// Fields
	struct FWeaponAttachTransformData DefaultRelativeTransform; // Offset: 0x0 | Size: 0x60
	struct TMap<int32_t, struct FWeaponAttachTransformData> SkinSpecificData; // Offset: 0x60 | Size: 0x50
};

// Object: ScriptStruct Solarland.WeaponAttachTransformData
// Inherited Bytes: 0x0 | Struct Size: 0x60
struct FWeaponAttachTransformData {
	// Fields
	struct FTransform RelativeTransformIdle; // Offset: 0x0 | Size: 0x30
	struct FTransform RelativeTransformCrouch; // Offset: 0x30 | Size: 0x30
};

// Object: ScriptStruct Solarland.SolarWeaponLODTableRow
// Inherited Bytes: 0x8 | Struct Size: 0x148
struct FSolarWeaponLODTableRow : FTableRowBase {
	// Fields
	struct TMap<enum class ESolarWeaponLODState, struct FSolarWeaponLODData> WeaponDefaultLODMap; // Offset: 0x8 | Size: 0x50
	struct TMap<enum class ESolarWeaponLODState, struct FSolarWeaponLODData> WeaponFocusedLODMap; // Offset: 0x58 | Size: 0x50
	struct TMap<enum class ESolarWeaponLODState, struct FSolarWeaponLODData> WeaponPartDefaultLODMap; // Offset: 0xa8 | Size: 0x50
	struct TMap<enum class ESolarWeaponLODState, struct FSolarWeaponLODData> WeaponPartFocusedLODMap; // Offset: 0xf8 | Size: 0x50
};

// Object: ScriptStruct Solarland.SolarWeaponLODData
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FSolarWeaponLODData {
	// Fields
	int32_t ForcedLOD; // Offset: 0x0 | Size: 0x4
	int32_t MinLOD; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct Solarland.SolarWeaponSkinTableRow
// Inherited Bytes: 0x8 | Struct Size: 0x20
struct FSolarWeaponSkinTableRow : FTableRowBase {
	// Fields
	struct FSoftObjectPath WeaponSkinDataPath; // Offset: 0x8 | Size: 0x18
};

// Object: ScriptStruct Solarland.WeaponScopeSensitivityRow
// Inherited Bytes: 0x8 | Struct Size: 0x48
struct FWeaponScopeSensitivityRow : FTableRowBase {
	// Fields
	struct FName TypeName; // Offset: 0x8 | Size: 0x8
	float FovValue; // Offset: 0x10 | Size: 0x4
	float HipToAdsTime; // Offset: 0x14 | Size: 0x4
	struct TSoftObjectPtr<UCurveFloat> FovChangeCurve; // Offset: 0x18 | Size: 0x28
	float HitEffectScale; // Offset: 0x40 | Size: 0x4
	char pad_0x44[0x4]; // Offset: 0x44 | Size: 0x4
};

// Object: ScriptStruct Solarland.WeaponAppearanceDTRow
// Inherited Bytes: 0x8 | Struct Size: 0x250
struct FWeaponAppearanceDTRow : FTableRowBase {
	// Fields
	struct FSoftObjectPath MeshPath; // Offset: 0x8 | Size: 0x18
	struct FSoftObjectPath MaterialPath; // Offset: 0x20 | Size: 0x18
	enum class EWeaponType WPType; // Offset: 0x38 | Size: 0x1
	char pad_0x39[0x3]; // Offset: 0x39 | Size: 0x3
	int32_t FireModeNameLocalizationID; // Offset: 0x3c | Size: 0x4
	struct FSlateBrush TriggerIcon; // Offset: 0x40 | Size: 0xe0
	int32_t UpgradeFireModeNameLocalizationID; // Offset: 0x120 | Size: 0x4
	char pad_0x124[0xc]; // Offset: 0x124 | Size: 0xc
	struct FSlateBrush UpgradeTriggerIcon; // Offset: 0x130 | Size: 0xe0
	float Radius; // Offset: 0x210 | Size: 0x4
	char pad_0x214[0xc]; // Offset: 0x214 | Size: 0xc
	struct FTransform SphereTransform; // Offset: 0x220 | Size: 0x30
};

// Object: ScriptStruct Solarland.WeaponDTRow
// Inherited Bytes: 0x8 | Struct Size: 0x50
struct FWeaponDTRow : FTableRowBase {
	// Fields
	struct FString WeaponDesc; // Offset: 0x8 | Size: 0x10
	struct FSoftClassPath FightWeaponBPPath; // Offset: 0x18 | Size: 0x18
	struct FSoftClassPath PreviewWeaponBPPath; // Offset: 0x30 | Size: 0x18
	struct USingleWeaponConfig* WeaponConfig; // Offset: 0x48 | Size: 0x8
};

// Object: ScriptStruct Solarland.WeaponFireTPPAnimUtility
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FWeaponFireTPPAnimUtility {
	// Fields
	char pad_0x0[0x40]; // Offset: 0x0 | Size: 0x40
};

// Object: ScriptStruct Solarland.WeaponFireFPPAnimUtility
// Inherited Bytes: 0x0 | Struct Size: 0xc8
struct FWeaponFireFPPAnimUtility {
	// Fields
	char pad_0x0[0xc8]; // Offset: 0x0 | Size: 0xc8
};

// Object: ScriptStruct Solarland.WeaponFireTPPAnimConfig
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FWeaponFireTPPAnimConfig {
	// Fields
	float SingleFirePulse; // Offset: 0x0 | Size: 0x4
	float SingleStiffnessCoefficient; // Offset: 0x4 | Size: 0x4
	float LoopFirePulse; // Offset: 0x8 | Size: 0x4
	float LoopStiffnessCoefficient; // Offset: 0xc | Size: 0x4
	float RecoverSpeed; // Offset: 0x10 | Size: 0x4
	float BlendSpaceScale; // Offset: 0x14 | Size: 0x4
	struct UBlendSpace* BlendSpace; // Offset: 0x18 | Size: 0x8
	char pad_0x20[0x8]; // Offset: 0x20 | Size: 0x8
};

// Object: ScriptStruct Solarland.WeaponFireFPPAnimConfig
// Inherited Bytes: 0x0 | Struct Size: 0x70
struct FWeaponFireFPPAnimConfig {
	// Fields
	float SingleFireStraightPulse; // Offset: 0x0 | Size: 0x4
	float SingleStiffnessCoefficient; // Offset: 0x4 | Size: 0x4
	float SingleFireBackwardOffset; // Offset: 0x8 | Size: 0x4
	float LoopFireStraightPulse; // Offset: 0xc | Size: 0x4
	float LoopStiffnessCoefficient; // Offset: 0x10 | Size: 0x4
	float LoopFireBackwardOffset; // Offset: 0x14 | Size: 0x4
	struct UCurveFloat* StraightStiffnessCurve; // Offset: 0x18 | Size: 0x8
	float StraightRecoverSpeed; // Offset: 0x20 | Size: 0x4
	struct FVector ShakePivotOffset; // Offset: 0x24 | Size: 0xc
	struct TArray<struct FVector2D> ShakeOffsets; // Offset: 0x30 | Size: 0x10
	struct TArray<struct FRotator> ShakeRotations; // Offset: 0x40 | Size: 0x10
	bool bNeedEndShake; // Offset: 0x50 | Size: 0x1
	char pad_0x51[0x7]; // Offset: 0x51 | Size: 0x7
	struct UCurveVector* EndShakeOffsetCurve; // Offset: 0x58 | Size: 0x8
	struct UCurveVector* EndShakeRotateCurve; // Offset: 0x60 | Size: 0x8
	char pad_0x68[0x8]; // Offset: 0x68 | Size: 0x8
};

// Object: ScriptStruct Solarland.WeaponMeshEffectData
// Inherited Bytes: 0x0 | Struct Size: 0x60
struct FWeaponMeshEffectData {
	// Fields
	struct FSoftObjectPath EffectPath; // Offset: 0x0 | Size: 0x18
	struct FName SocketName; // Offset: 0x18 | Size: 0x8
	struct FTransform RelativeTransform; // Offset: 0x20 | Size: 0x30
	struct UCurveVector* ScaleCurveForFOV; // Offset: 0x50 | Size: 0x8
	struct UCurveVector* LocationCurveForFOV; // Offset: 0x58 | Size: 0x8
};

// Object: ScriptStruct Solarland.WeaponBodyData
// Inherited Bytes: 0x0 | Struct Size: 0xb0
struct FWeaponBodyData {
	// Fields
	int32_t weaponid; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct FSoftObjectPath WeaponMesh; // Offset: 0x8 | Size: 0x18
	struct UWeaponAnimInstance* WeaponAnimBP; // Offset: 0x20 | Size: 0x8
	struct TMap<enum class ECharacterMontage, struct FSoftObjectPath> OverrideWeaponAnimSequenceMap; // Offset: 0x28 | Size: 0x50
	struct FSoftObjectPath LodpMesh; // Offset: 0x78 | Size: 0x18
	struct TArray<struct FSoftObjectPath> WeaponMaterials; // Offset: 0x90 | Size: 0x10
	struct TArray<struct FWeaponSkinExtraPS> SkinPSArray; // Offset: 0xa0 | Size: 0x10
};

// Object: ScriptStruct Solarland.WeaponSkinExtraPS
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FWeaponSkinExtraPS {
	// Fields
	bool bStimulatedShow; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	struct FName Socket; // Offset: 0x4 | Size: 0x8
	char pad_0xC[0x4]; // Offset: 0xc | Size: 0x4
	struct UParticleSystem* PS; // Offset: 0x10 | Size: 0x8
	struct FSoftObjectPath PSPath; // Offset: 0x18 | Size: 0x18
};

// Object: ScriptStruct Solarland.WeaponSkinPartData
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FWeaponSkinPartData {
	// Fields
	int32_t WeaponPartId; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct FString WeaponPartDesc; // Offset: 0x8 | Size: 0x10
	struct FSoftObjectPath PartDataAsset; // Offset: 0x18 | Size: 0x18
	struct TArray<struct FSoftObjectPath> WeaponMaterials; // Offset: 0x30 | Size: 0x10
};

// Object: ScriptStruct Solarland.WeaponMechanicalState
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FWeaponMechanicalState {
	// Fields
	enum class EWeaponMechanicalUniqueState UniqueState; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	enum class EWeaponMechanicalSideFlag SideFlags; // Offset: 0x4 | Size: 0x4
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct ASolarWeapon* Weapon; // Offset: 0x10 | Size: 0x8
	struct USingleWeaponConfig* Config; // Offset: 0x18 | Size: 0x8
	char pad_0x20[0x30]; // Offset: 0x20 | Size: 0x30
};

// Object: ScriptStruct Solarland.WeaponUpgradeNetData
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FWeaponUpgradeNetData {
	// Fields
	int32_t TotalScore; // Offset: 0x0 | Size: 0x4
	int32_t LevelScore; // Offset: 0x4 | Size: 0x4
	struct TArray<struct FUpgradeSlotStruct> UpgradeSlots; // Offset: 0x8 | Size: 0x10
	int32_t UpgradeCount; // Offset: 0x18 | Size: 0x4
	char pad_0x1C[0x4]; // Offset: 0x1c | Size: 0x4
};

// Object: ScriptStruct Solarland.UpgradeSlotStruct
// Inherited Bytes: 0x0 | Struct Size: 0x100
struct FUpgradeSlotStruct {
	// Fields
	int32_t SlotID; // Offset: 0x0 | Size: 0x4
	bool Unlock; // Offset: 0x4 | Size: 0x1
	enum class EWeaponUpgradeType AccessoryType; // Offset: 0x5 | Size: 0x1
	char pad_0x6[0x2]; // Offset: 0x6 | Size: 0x2
	int32_t AccessoryID; // Offset: 0x8 | Size: 0x4
	char pad_0xC[0x4]; // Offset: 0xc | Size: 0x4
	struct FSlateBrush IconOverride; // Offset: 0x10 | Size: 0xe0
	struct FLinearColor IconColorOverride; // Offset: 0xf0 | Size: 0x10
};

// Object: ScriptStruct Solarland.WeaponPartWeaponAttributeByWeaponType
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FWeaponPartWeaponAttributeByWeaponType {
	// Fields
	enum class EWeaponType WeaponType; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x7]; // Offset: 0x1 | Size: 0x7
	struct FWeaponAttributeModifierContainer AttributeModifiers; // Offset: 0x8 | Size: 0x10
	struct TArray<struct FWeaponPartWeaponAttributeByWeaponID> ModifiersByWeaponID; // Offset: 0x18 | Size: 0x10
};

// Object: ScriptStruct Solarland.WeaponPartWeaponAttributeByWeaponID
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FWeaponPartWeaponAttributeByWeaponID {
	// Fields
	int32_t weaponid; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct FWeaponAttributeModifierContainer AttributeModifiers; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct Solarland.WeaponAttributeModifierContainer
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FWeaponAttributeModifierContainer {
	// Fields
	struct TArray<struct FWeaponAttributeModifier> Modifiers; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Solarland.WeaponAttributeModifier
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FWeaponAttributeModifier {
	// Fields
	struct FGameplayTag AttributeTag; // Offset: 0x0 | Size: 0x8
	struct TArray<struct FWeaponAttributeParam> Modifiers; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct Solarland.WeaponAttributeParam
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FWeaponAttributeParam {
	// Fields
	enum class EWeaponAttributeParamType ParamType; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	float Value; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct Solarland.WeaponPartGripDataForCharacter
// Inherited Bytes: 0x0 | Struct Size: 0x138
struct FWeaponPartGripDataForCharacter {
	// Fields
	struct FVector LeftHandIkEffectLocation; // Offset: 0x0 | Size: 0xc
	struct FVector LeftHandIkJointLocation; // Offset: 0xc | Size: 0xc
	struct FVector LeftHandIkJointLocationForGunIdle; // Offset: 0x18 | Size: 0xc
	struct FVector LeftHandIkJointLocationForGunIdleWhenCrouch; // Offset: 0x24 | Size: 0xc
	struct FLeftHandGripConfig LeftHandGripRotationConfig; // Offset: 0x30 | Size: 0x84
	struct FLeftHandGripConfig LeftHandGripRotationConfigForGunIdle; // Offset: 0xb4 | Size: 0x84
};

// Object: ScriptStruct Solarland.SolarAmmoMeshData
// Inherited Bytes: 0x0 | Struct Size: 0x48
struct FSolarAmmoMeshData {
	// Fields
	int32_t MaterialIndex; // Offset: 0x0 | Size: 0x4
	struct FLinearColor DefaultColor; // Offset: 0x4 | Size: 0x10
	struct FLinearColor WarningColor; // Offset: 0x14 | Size: 0x10
	struct FLinearColor SeriousWarningColor; // Offset: 0x24 | Size: 0x10
	float WarningLine; // Offset: 0x34 | Size: 0x4
	float SeriousWarningLine; // Offset: 0x38 | Size: 0x4
	float SeriousWarningBlinkLine; // Offset: 0x3c | Size: 0x4
	float SeriousWarningBlinkStrength; // Offset: 0x40 | Size: 0x4
	float SeriousWarningBlinkFrequence; // Offset: 0x44 | Size: 0x4
};

// Object: ScriptStruct Solarland.PartScopeCorrect
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FPartScopeCorrect {
	// Fields
	struct FVector FPPLocation; // Offset: 0x0 | Size: 0xc
	struct FRotator FPPRotation; // Offset: 0xc | Size: 0xc
};

// Object: ScriptStruct Solarland.ValueCurveBySprayingTime
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FValueCurveBySprayingTime {
	// Fields
	struct UCurveVector* ValueCurve; // Offset: 0x0 | Size: 0x8
	float TimeScale; // Offset: 0x8 | Size: 0x4
	struct FVector ValueScale; // Offset: 0xc | Size: 0xc
};

// Object: ScriptStruct Solarland.FixedSectionInfo
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FFixedSectionInfo {
	// Fields
	int32_t SprayingCount; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct UWeaponRecoilValueGenerator* ValueGenerator; // Offset: 0x8 | Size: 0x8
};

// Object: ScriptStruct Solarland.WeaponRecoilRotatorGenerator
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FWeaponRecoilRotatorGenerator {
	// Fields
	struct UWeaponRecoilValueGenerator* PitchGenerator; // Offset: 0x0 | Size: 0x8
	struct UWeaponRecoilValueGenerator* YawGenerator; // Offset: 0x8 | Size: 0x8
	struct UWeaponRecoilValueGenerator* RollGenerator; // Offset: 0x10 | Size: 0x8
};

// Object: ScriptStruct Solarland.WeaponRecoilVectorGenerator
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FWeaponRecoilVectorGenerator {
	// Fields
	struct UWeaponRecoilValueGenerator* XGenerator; // Offset: 0x0 | Size: 0x8
	struct UWeaponRecoilValueGenerator* YGenerator; // Offset: 0x8 | Size: 0x8
	struct UWeaponRecoilValueGenerator* ZGenerator; // Offset: 0x10 | Size: 0x8
};

// Object: ScriptStruct Solarland.ScopeSliderData
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FScopeSliderData {
	// Fields
	struct FVector2D SliderPercentRange; // Offset: 0x0 | Size: 0x8
	float SliderAnimeTimer; // Offset: 0x8 | Size: 0x4
	enum class EVehicleWeaponScopeType ScopeMagnifier; // Offset: 0xc | Size: 0x1
	char pad_0xD[0x3]; // Offset: 0xd | Size: 0x3
	struct FText DisplayText; // Offset: 0x10 | Size: 0x18
};

// Object: ScriptStruct Solarland.CrossHairShootConfig
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FCrossHairShootConfig {
	// Fields
	float GunKickOffsetInheritRatio; // Offset: 0x0 | Size: 0x4
	float SkewOffsetInheritRatio; // Offset: 0x4 | Size: 0x4
	struct URecoverableRecoilPattern* CrossHairKickPattern; // Offset: 0x8 | Size: 0x8
};

// Object: ScriptStruct Solarland.WeaponSkewAdjustment
// Inherited Bytes: 0x0 | Struct Size: 0x90
struct FWeaponSkewAdjustment {
	// Fields
	enum class EWeaponSkewInputType InputType; // Offset: 0x0 | Size: 0x1
	enum class EWeaponSkewAdjustmentType AdjustmentType; // Offset: 0x1 | Size: 0x1
	char pad_0x2[0x6]; // Offset: 0x2 | Size: 0x6
	struct FRuntimeFloatCurve AdjustmentCurve; // Offset: 0x8 | Size: 0x88
};

// Object: ScriptStruct Solarland.GunKickScale
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FGunKickScale {
	// Fields
	float XOffsetScale; // Offset: 0x0 | Size: 0x4
	float YOffsetScale; // Offset: 0x4 | Size: 0x4
	float ZOffsetScale; // Offset: 0x8 | Size: 0x4
	float PitchScale; // Offset: 0xc | Size: 0x4
	float YawScale; // Offset: 0x10 | Size: 0x4
	float RollScale; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct Solarland.WeaponAttributeModifiersByTag
// Inherited Bytes: 0x10 | Struct Size: 0x60
struct FWeaponAttributeModifiersByTag : FWeaponAttributeModifierContainer {
	// Fields
	struct FGameplayTagRequirements TagRequirements; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct Solarland.SpreadScaleIncrease
// Inherited Bytes: 0x0 | Struct Size: 0x14
struct FSpreadScaleIncrease {
	// Fields
	int32_t SprayingCount; // Offset: 0x0 | Size: 0x4
	float MinSpreadScale; // Offset: 0x4 | Size: 0x4
	float MaxSpreadScale; // Offset: 0x8 | Size: 0x4
	struct FRangeFloat ScaleIncreaseRange; // Offset: 0xc | Size: 0x8
};

// Object: ScriptStruct Solarland.WeaponAction
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FWeaponAction {
	// Fields
	int32_t ActionCount; // Offset: 0x0 | Size: 0x4
	int32_t ActionParameter; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct Solarland.WeaponSystemInteract
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FWeaponSystemInteract {
	// Fields
	char pad_0x0[0x50]; // Offset: 0x0 | Size: 0x50
};

// Object: ScriptStruct Solarland.WeaponSysBolt
// Inherited Bytes: 0x0 | Struct Size: 0x14
struct FWeaponSysBolt {
	// Fields
	char pad_0x0[0x14]; // Offset: 0x0 | Size: 0x14
};

// Object: ScriptStruct Solarland.WeaponSysInput
// Inherited Bytes: 0x0 | Struct Size: 0x3
struct FWeaponSysInput {
	// Fields
	char pad_0x0[0x3]; // Offset: 0x0 | Size: 0x3
};

// Object: ScriptStruct Solarland.WeaponSysStateStruct
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FWeaponSysStateStruct {
	// Fields
	int32_t State; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x8]; // Offset: 0x4 | Size: 0x8
	bool bPost; // Offset: 0xc | Size: 0x1
	char pad_0xD[0x3]; // Offset: 0xd | Size: 0x3
};

// Object: ScriptStruct Solarland.WeaponSysPostStateStruct
// Inherited Bytes: 0x10 | Struct Size: 0x10
struct FWeaponSysPostStateStruct : FWeaponSysStateStruct {
};

// Object: ScriptStruct Solarland.WeaponRealAttachInfo
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FWeaponRealAttachInfo {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
};

// Object: ScriptStruct Solarland.WeaponUIStyleSheetRow
// Inherited Bytes: 0x8 | Struct Size: 0x10
struct FWeaponUIStyleSheetRow : FTableRowBase {
	// Fields
	bool bSameQualityPlus; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x3]; // Offset: 0x9 | Size: 0x3
	int32_t Quality; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct Solarland.WorldMarkDataDetails
// Inherited Bytes: 0x108 | Struct Size: 0x120
struct FWorldMarkDataDetails : FFastArraySerializer {
	// Fields
	char PlayerPosMax; // Offset: 0x101 | Size: 0x1
	struct TArray<struct FWorldMarkData> AllMarkDatas; // Offset: 0x108 | Size: 0x10
	struct USolarTeamInfoComponent* Owner; // Offset: 0x118 | Size: 0x8
};

