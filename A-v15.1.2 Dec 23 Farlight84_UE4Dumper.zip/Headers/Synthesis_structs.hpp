#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct Synthesis.ModularSynthPresetBankEntry
// Inherited Bytes: 0x0 | Struct Size: 0xe0
struct FModularSynthPresetBankEntry {
	// Fields
	struct FString PresetName; // Offset: 0x0 | Size: 0x10
	struct FModularSynthPreset Preset; // Offset: 0x10 | Size: 0xd0
};

// Object: ScriptStruct Synthesis.ModularSynthPreset
// Inherited Bytes: 0x8 | Struct Size: 0xd0
struct FModularSynthPreset : FTableRowBase {
	// Fields
	char bEnablePolyphony : 1; // Offset: 0x8 | Size: 0x1
	char pad_0x8_1 : 7; // Offset: 0x8 | Size: 0x1
	enum class ESynth1OscType Osc1Type; // Offset: 0x9 | Size: 0x1
	char pad_0xA[0x2]; // Offset: 0xa | Size: 0x2
	float Osc1Gain; // Offset: 0xc | Size: 0x4
	float Osc1Octave; // Offset: 0x10 | Size: 0x4
	float Osc1Semitones; // Offset: 0x14 | Size: 0x4
	float Osc1Cents; // Offset: 0x18 | Size: 0x4
	float Osc1PulseWidth; // Offset: 0x1c | Size: 0x4
	enum class ESynth1OscType Osc2Type; // Offset: 0x20 | Size: 0x1
	char pad_0x21[0x3]; // Offset: 0x21 | Size: 0x3
	float Osc2Gain; // Offset: 0x24 | Size: 0x4
	float Osc2Octave; // Offset: 0x28 | Size: 0x4
	float Osc2Semitones; // Offset: 0x2c | Size: 0x4
	float Osc2Cents; // Offset: 0x30 | Size: 0x4
	float Osc2PulseWidth; // Offset: 0x34 | Size: 0x4
	float Portamento; // Offset: 0x38 | Size: 0x4
	char bEnableUnison : 1; // Offset: 0x3c | Size: 0x1
	char bEnableOscillatorSync : 1; // Offset: 0x3c | Size: 0x1
	char pad_0x3C_2 : 6; // Offset: 0x3c | Size: 0x1
	char pad_0x3D[0x3]; // Offset: 0x3d | Size: 0x3
	float Spread; // Offset: 0x40 | Size: 0x4
	float Pan; // Offset: 0x44 | Size: 0x4
	float LFO1Frequency; // Offset: 0x48 | Size: 0x4
	float LFO1Gain; // Offset: 0x4c | Size: 0x4
	enum class ESynthLFOType LFO1Type; // Offset: 0x50 | Size: 0x1
	enum class ESynthLFOMode LFO1Mode; // Offset: 0x51 | Size: 0x1
	enum class ESynthLFOPatchType LFO1PatchType; // Offset: 0x52 | Size: 0x1
	char pad_0x53[0x1]; // Offset: 0x53 | Size: 0x1
	float LFO2Frequency; // Offset: 0x54 | Size: 0x4
	float LFO2Gain; // Offset: 0x58 | Size: 0x4
	enum class ESynthLFOType LFO2Type; // Offset: 0x5c | Size: 0x1
	enum class ESynthLFOMode LFO2Mode; // Offset: 0x5d | Size: 0x1
	enum class ESynthLFOPatchType LFO2PatchType; // Offset: 0x5e | Size: 0x1
	char pad_0x5F[0x1]; // Offset: 0x5f | Size: 0x1
	float GainDb; // Offset: 0x60 | Size: 0x4
	float AttackTime; // Offset: 0x64 | Size: 0x4
	float DecayTime; // Offset: 0x68 | Size: 0x4
	float SustainGain; // Offset: 0x6c | Size: 0x4
	float ReleaseTime; // Offset: 0x70 | Size: 0x4
	enum class ESynthModEnvPatch ModEnvPatchType; // Offset: 0x74 | Size: 0x1
	enum class ESynthModEnvBiasPatch ModEnvBiasPatchType; // Offset: 0x75 | Size: 0x1
	char bInvertModulationEnvelope : 1; // Offset: 0x76 | Size: 0x1
	char bInvertModulationEnvelopeBias : 1; // Offset: 0x76 | Size: 0x1
	char pad_0x76_2 : 6; // Offset: 0x76 | Size: 0x1
	char pad_0x77[0x1]; // Offset: 0x77 | Size: 0x1
	float ModulationEnvelopeDepth; // Offset: 0x78 | Size: 0x4
	float ModulationEnvelopeAttackTime; // Offset: 0x7c | Size: 0x4
	float ModulationEnvelopeDecayTime; // Offset: 0x80 | Size: 0x4
	float ModulationEnvelopeSustainGain; // Offset: 0x84 | Size: 0x4
	float ModulationEnvelopeReleaseTime; // Offset: 0x88 | Size: 0x4
	char bLegato : 1; // Offset: 0x8c | Size: 0x1
	char bRetrigger : 1; // Offset: 0x8c | Size: 0x1
	char pad_0x8C_2 : 6; // Offset: 0x8c | Size: 0x1
	char pad_0x8D[0x3]; // Offset: 0x8d | Size: 0x3
	float FilterFrequency; // Offset: 0x90 | Size: 0x4
	float FilterQ; // Offset: 0x94 | Size: 0x4
	enum class ESynthFilterType FilterType; // Offset: 0x98 | Size: 0x1
	enum class ESynthFilterAlgorithm FilterAlgorithm; // Offset: 0x99 | Size: 0x1
	char bStereoDelayEnabled : 1; // Offset: 0x9a | Size: 0x1
	char pad_0x9A_1 : 7; // Offset: 0x9a | Size: 0x1
	enum class ESynthStereoDelayMode StereoDelayMode; // Offset: 0x9b | Size: 0x1
	float StereoDelayTime; // Offset: 0x9c | Size: 0x4
	float StereoDelayFeedback; // Offset: 0xa0 | Size: 0x4
	float StereoDelayWetlevel; // Offset: 0xa4 | Size: 0x4
	float StereoDelayRatio; // Offset: 0xa8 | Size: 0x4
	char bChorusEnabled : 1; // Offset: 0xac | Size: 0x1
	char pad_0xAC_1 : 7; // Offset: 0xac | Size: 0x1
	char pad_0xAD[0x3]; // Offset: 0xad | Size: 0x3
	float ChorusDepth; // Offset: 0xb0 | Size: 0x4
	float ChorusFeedback; // Offset: 0xb4 | Size: 0x4
	float ChorusFrequency; // Offset: 0xb8 | Size: 0x4
	char pad_0xBC[0x4]; // Offset: 0xbc | Size: 0x4
	struct TArray<struct FEpicSynth1Patch> Patches; // Offset: 0xc0 | Size: 0x10
};

// Object: ScriptStruct Synthesis.EpicSynth1Patch
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FEpicSynth1Patch {
	// Fields
	enum class ESynth1PatchSource PatchSource; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x7]; // Offset: 0x1 | Size: 0x7
	struct TArray<struct FSynth1PatchCable> PatchCables; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct Synthesis.Synth1PatchCable
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FSynth1PatchCable {
	// Fields
	float Depth; // Offset: 0x0 | Size: 0x4
	enum class ESynth1PatchDestination Destination; // Offset: 0x4 | Size: 0x1
	char pad_0x5[0x3]; // Offset: 0x5 | Size: 0x3
};

// Object: ScriptStruct Synthesis.PatchId
// Inherited Bytes: 0x0 | Struct Size: 0x4
struct FPatchId {
	// Fields
	int32_t ID; // Offset: 0x0 | Size: 0x4
};

// Object: ScriptStruct Synthesis.SourceEffectBitCrusherSettings
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FSourceEffectBitCrusherSettings {
	// Fields
	float CrushedSampleRate; // Offset: 0x0 | Size: 0x4
	float CrushedBits; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct Synthesis.SourceEffectChorusSettings
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FSourceEffectChorusSettings {
	// Fields
	float Depth; // Offset: 0x0 | Size: 0x4
	float Frequency; // Offset: 0x4 | Size: 0x4
	float Feedback; // Offset: 0x8 | Size: 0x4
	float WetLevel; // Offset: 0xc | Size: 0x4
	float DryLevel; // Offset: 0x10 | Size: 0x4
	float Spread; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct Synthesis.SourceEffectDynamicsProcessorSettings
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FSourceEffectDynamicsProcessorSettings {
	// Fields
	enum class ESourceEffectDynamicsProcessorType DynamicsProcessorType; // Offset: 0x0 | Size: 0x1
	enum class ESourceEffectDynamicsPeakMode PeakMode; // Offset: 0x1 | Size: 0x1
	char pad_0x2[0x2]; // Offset: 0x2 | Size: 0x2
	float LookAheadMsec; // Offset: 0x4 | Size: 0x4
	float AttackTimeMsec; // Offset: 0x8 | Size: 0x4
	float ReleaseTimeMsec; // Offset: 0xc | Size: 0x4
	float ThresholdDb; // Offset: 0x10 | Size: 0x4
	float Ratio; // Offset: 0x14 | Size: 0x4
	float KneeBandwidthDb; // Offset: 0x18 | Size: 0x4
	float InputGainDb; // Offset: 0x1c | Size: 0x4
	float OutputGainDb; // Offset: 0x20 | Size: 0x4
	char bStereoLinked : 1; // Offset: 0x24 | Size: 0x1
	char bAnalogMode : 1; // Offset: 0x24 | Size: 0x1
	char pad_0x24_2 : 6; // Offset: 0x24 | Size: 0x1
	char pad_0x25[0x3]; // Offset: 0x25 | Size: 0x3
};

// Object: ScriptStruct Synthesis.SourceEffectEnvelopeFollowerSettings
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FSourceEffectEnvelopeFollowerSettings {
	// Fields
	float AttackTime; // Offset: 0x0 | Size: 0x4
	float ReleaseTime; // Offset: 0x4 | Size: 0x4
	enum class EEnvelopeFollowerPeakMode PeakMode; // Offset: 0x8 | Size: 0x1
	bool bIsAnalogMode; // Offset: 0x9 | Size: 0x1
	char pad_0xA[0x2]; // Offset: 0xa | Size: 0x2
};

// Object: ScriptStruct Synthesis.SourceEffectEQSettings
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FSourceEffectEQSettings {
	// Fields
	struct TArray<struct FSourceEffectEQBand> EQBands; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Synthesis.SourceEffectEQBand
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FSourceEffectEQBand {
	// Fields
	float Frequency; // Offset: 0x0 | Size: 0x4
	float Bandwidth; // Offset: 0x4 | Size: 0x4
	float GainDb; // Offset: 0x8 | Size: 0x4
	char bEnabled : 1; // Offset: 0xc | Size: 0x1
	char pad_0xC_1 : 7; // Offset: 0xc | Size: 0x1
	char pad_0xD[0x3]; // Offset: 0xd | Size: 0x3
};

// Object: ScriptStruct Synthesis.SourceEffectFilterSettings
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FSourceEffectFilterSettings {
	// Fields
	enum class ESourceEffectFilterCircuit FilterCircuit; // Offset: 0x0 | Size: 0x1
	enum class ESourceEffectFilterType FilterType; // Offset: 0x1 | Size: 0x1
	char pad_0x2[0x2]; // Offset: 0x2 | Size: 0x2
	float CutoffFrequency; // Offset: 0x4 | Size: 0x4
	float FilterQ; // Offset: 0x8 | Size: 0x4
};

// Object: ScriptStruct Synthesis.SourceEffectFoldbackDistortionSettings
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FSourceEffectFoldbackDistortionSettings {
	// Fields
	float InputGainDb; // Offset: 0x0 | Size: 0x4
	float ThresholdDb; // Offset: 0x4 | Size: 0x4
	float OutputGainDb; // Offset: 0x8 | Size: 0x4
};

// Object: ScriptStruct Synthesis.SourceEffectMidSideSpreaderSettings
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FSourceEffectMidSideSpreaderSettings {
	// Fields
	enum class EStereoChannelMode InputMode; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	float SpreadAmount; // Offset: 0x4 | Size: 0x4
	enum class EStereoChannelMode OutputMode; // Offset: 0x8 | Size: 0x1
	bool bEqualPower; // Offset: 0x9 | Size: 0x1
	char pad_0xA[0x2]; // Offset: 0xa | Size: 0x2
};

// Object: ScriptStruct Synthesis.SourceEffectPannerSettings
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FSourceEffectPannerSettings {
	// Fields
	float Spread; // Offset: 0x0 | Size: 0x4
	float Pan; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct Synthesis.SourceEffectPhaserSettings
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FSourceEffectPhaserSettings {
	// Fields
	float WetLevel; // Offset: 0x0 | Size: 0x4
	float Frequency; // Offset: 0x4 | Size: 0x4
	float Feedback; // Offset: 0x8 | Size: 0x4
	enum class EPhaserLFOType LFOType; // Offset: 0xc | Size: 0x1
	bool UseQuadraturePhase; // Offset: 0xd | Size: 0x1
	char pad_0xE[0x2]; // Offset: 0xe | Size: 0x2
};

// Object: ScriptStruct Synthesis.SourceEffectRingModulationSettings
// Inherited Bytes: 0x0 | Struct Size: 0x14
struct FSourceEffectRingModulationSettings {
	// Fields
	enum class ERingModulatorTypeSourceEffect ModulatorType; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	float Frequency; // Offset: 0x4 | Size: 0x4
	float Depth; // Offset: 0x8 | Size: 0x4
	float DryLevel; // Offset: 0xc | Size: 0x4
	float WetLevel; // Offset: 0x10 | Size: 0x4
};

// Object: ScriptStruct Synthesis.SourceEffectSimpleDelaySettings
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FSourceEffectSimpleDelaySettings {
	// Fields
	float SpeedOfSound; // Offset: 0x0 | Size: 0x4
	float DelayAmount; // Offset: 0x4 | Size: 0x4
	float DryAmount; // Offset: 0x8 | Size: 0x4
	float WetAmount; // Offset: 0xc | Size: 0x4
	float Feedback; // Offset: 0x10 | Size: 0x4
	char bDelayBasedOnDistance : 1; // Offset: 0x14 | Size: 0x1
	char pad_0x14_1 : 7; // Offset: 0x14 | Size: 0x1
	char pad_0x15[0x3]; // Offset: 0x15 | Size: 0x3
};

// Object: ScriptStruct Synthesis.SourceEffectStereoDelaySettings
// Inherited Bytes: 0x0 | Struct Size: 0x14
struct FSourceEffectStereoDelaySettings {
	// Fields
	enum class EStereoDelaySourceEffect DelayMode; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	float DelayTimeMsec; // Offset: 0x4 | Size: 0x4
	float Feedback; // Offset: 0x8 | Size: 0x4
	float DelayRatio; // Offset: 0xc | Size: 0x4
	float WetLevel; // Offset: 0x10 | Size: 0x4
};

// Object: ScriptStruct Synthesis.SourceEffectWaveShaperSettings
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FSourceEffectWaveShaperSettings {
	// Fields
	float Amount; // Offset: 0x0 | Size: 0x4
	float OutputGainDb; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct Synthesis.SubmixEffectConvolutionReverbSettings
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FSubmixEffectConvolutionReverbSettings {
	// Fields
	float NormalizationVolumeDb; // Offset: 0x0 | Size: 0x4
	float SurroundRearChannelBleedDb; // Offset: 0x4 | Size: 0x4
	bool bInvertRearChannelBleedPhase; // Offset: 0x8 | Size: 0x1
	bool bSurroundRearChannelFlip; // Offset: 0x9 | Size: 0x1
	char pad_0xA[0x2]; // Offset: 0xa | Size: 0x2
	float SurroundRearChannelBleedAmount; // Offset: 0xc | Size: 0x4
	struct UAudioImpulseResponse* ImpulseResponse; // Offset: 0x10 | Size: 0x8
	bool AllowHArdwareAcceleration; // Offset: 0x18 | Size: 0x1
	char pad_0x19[0x7]; // Offset: 0x19 | Size: 0x7
};

// Object: ScriptStruct Synthesis.SubmixEffectDelaySettings
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FSubmixEffectDelaySettings {
	// Fields
	float MaximumDelayLength; // Offset: 0x0 | Size: 0x4
	float InterpolationTime; // Offset: 0x4 | Size: 0x4
	float DelayLength; // Offset: 0x8 | Size: 0x4
};

// Object: ScriptStruct Synthesis.SubmixEffectFilterSettings
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FSubmixEffectFilterSettings {
	// Fields
	enum class ESubmixFilterType FilterType; // Offset: 0x0 | Size: 0x1
	enum class ESubmixFilterAlgorithm FilterAlgorithm; // Offset: 0x1 | Size: 0x1
	char pad_0x2[0x2]; // Offset: 0x2 | Size: 0x2
	float FilterFrequency; // Offset: 0x4 | Size: 0x4
	float FilterQ; // Offset: 0x8 | Size: 0x4
};

// Object: ScriptStruct Synthesis.SubmixEffectFlexiverbSettings
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FSubmixEffectFlexiverbSettings {
	// Fields
	float PreDelay; // Offset: 0x0 | Size: 0x4
	float DecayTime; // Offset: 0x4 | Size: 0x4
	float RoomDampening; // Offset: 0x8 | Size: 0x4
	int32_t Complexity; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct Synthesis.SubmixEffectTapDelaySettings
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FSubmixEffectTapDelaySettings {
	// Fields
	float MaximumDelayLength; // Offset: 0x0 | Size: 0x4
	float InterpolationTime; // Offset: 0x4 | Size: 0x4
	struct TArray<struct FTapDelayInfo> Taps; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct Synthesis.TapDelayInfo
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FTapDelayInfo {
	// Fields
	enum class ETapLineMode TapLineMode; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	float DelayLength; // Offset: 0x4 | Size: 0x4
	float Gain; // Offset: 0x8 | Size: 0x4
	int32_t OutputChannel; // Offset: 0xc | Size: 0x4
	float PanInDegrees; // Offset: 0x10 | Size: 0x4
	int32_t TapId; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct Synthesis.Synth2DSliderStyle
// Inherited Bytes: 0x8 | Struct Size: 0x480
struct FSynth2DSliderStyle : FSlateWidgetStyle {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FSlateBrush NormalThumbImage; // Offset: 0x10 | Size: 0xe0
	struct FSlateBrush DisabledThumbImage; // Offset: 0xf0 | Size: 0xe0
	struct FSlateBrush NormalBarImage; // Offset: 0x1d0 | Size: 0xe0
	struct FSlateBrush DisabledBarImage; // Offset: 0x2b0 | Size: 0xe0
	struct FSlateBrush BackgroundImage; // Offset: 0x390 | Size: 0xe0
	float BarThickness; // Offset: 0x470 | Size: 0x4
	char pad_0x474[0xc]; // Offset: 0x474 | Size: 0xc
};

// Object: ScriptStruct Synthesis.SynthKnobStyle
// Inherited Bytes: 0x8 | Struct Size: 0x3a0
struct FSynthKnobStyle : FSlateWidgetStyle {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FSlateBrush LargeKnob; // Offset: 0x10 | Size: 0xe0
	struct FSlateBrush LargeKnobOverlay; // Offset: 0xf0 | Size: 0xe0
	struct FSlateBrush MediumKnob; // Offset: 0x1d0 | Size: 0xe0
	struct FSlateBrush MediumKnobOverlay; // Offset: 0x2b0 | Size: 0xe0
	float MinValueAngle; // Offset: 0x390 | Size: 0x4
	float MaxValueAngle; // Offset: 0x394 | Size: 0x4
	enum class ESynthKnobSize KnobSize; // Offset: 0x398 | Size: 0x1
	char pad_0x399[0x7]; // Offset: 0x399 | Size: 0x7
};

// Object: ScriptStruct Synthesis.SynthSlateStyle
// Inherited Bytes: 0x8 | Struct Size: 0x10
struct FSynthSlateStyle : FSlateWidgetStyle {
	// Fields
	enum class ESynthSlateSizeType SizeType; // Offset: 0x8 | Size: 0x1
	enum class ESynthSlateColorStyle ColorStyle; // Offset: 0x9 | Size: 0x1
	char pad_0xA[0x6]; // Offset: 0xa | Size: 0x6
};

