#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class TemplateLoadingSystem.LoadingScreenSubsystem
// Inherited Bytes: 0x30 | Struct Size: 0x40
struct ULoadingScreenSubsystem : UGameInstanceSubsystem {
	// Fields
	struct ULoadingWidgetBase* LoadingWidget; // Offset: 0x30 | Size: 0x8
	char pad_0x38[0x8]; // Offset: 0x38 | Size: 0x8

	// Functions

	// Object: Function TemplateLoadingSystem.LoadingScreenSubsystem.StopLoadingScreen
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1012cd4d8
	// Return & Params: [ Num(0) Size(0x0) ]
	void StopLoadingScreen();

	// Object: Function TemplateLoadingSystem.LoadingScreenSubsystem.StartLoadingScreen
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1012cd4ec
	// Return & Params: [ Num(2) Size(0x10) ]
	struct ULoadingWidgetBase* StartLoadingScreen(struct ULoadingWidgetBase* InWidgetClass);

	// Object: Function TemplateLoadingSystem.LoadingScreenSubsystem.Get
	// Flags: [Final|Native|Static|Private]
	// Offset: 0x1012cd458
	// Return & Params: [ Num(2) Size(0x10) ]
	struct ULoadingScreenSubsystem* Get(struct UObject* WorldContextObject);
};

// Object: Class TemplateLoadingSystem.LoadingWidgetBase
// Inherited Bytes: 0x260 | Struct Size: 0x260
struct ULoadingWidgetBase : UUserWidget {
	// Functions

	// Object: Function TemplateLoadingSystem.LoadingWidgetBase.LoadingStarted
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x1012cdad8
	// Return & Params: [ Num(0) Size(0x0) ]
	void LoadingStarted();

	// Object: Function TemplateLoadingSystem.LoadingWidgetBase.LoadingFinished
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x1012cdabc
	// Return & Params: [ Num(0) Size(0x0) ]
	void LoadingFinished();
};

