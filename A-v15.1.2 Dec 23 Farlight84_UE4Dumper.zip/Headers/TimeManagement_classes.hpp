#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class TimeManagement.FixedFrameRateCustomTimeStep
// Inherited Bytes: 0x28 | Struct Size: 0x30
struct UFixedFrameRateCustomTimeStep : UEngineCustomTimeStep {
	// Fields
	struct FFrameRate FixedFrameRate; // Offset: 0x28 | Size: 0x8
};

// Object: Class TimeManagement.TimeManagementBlueprintLibrary
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UTimeManagementBlueprintLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object: Function TimeManagement.TimeManagementBlueprintLibrary.TransformTime
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x1047c81e4
	// Return & Params: [ Num(4) Size(0x20) ]
	struct FFrameTime TransformTime(struct FFrameTime& SourceTime, struct FFrameRate& SourceRate, struct FFrameRate& DestinationRate);

	// Object: Function TimeManagement.TimeManagementBlueprintLibrary.Subtract_FrameNumberInteger
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x1047c7d70
	// Return & Params: [ Num(3) Size(0xc) ]
	struct FFrameNumber Subtract_FrameNumberInteger(struct FFrameNumber A, int32_t B);

	// Object: Function TimeManagement.TimeManagementBlueprintLibrary.Subtract_FrameNumberFrameNumber
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x1047c7f00
	// Return & Params: [ Num(3) Size(0xc) ]
	struct FFrameNumber Subtract_FrameNumberFrameNumber(struct FFrameNumber A, struct FFrameNumber B);

	// Object: Function TimeManagement.TimeManagementBlueprintLibrary.SnapFrameTimeToRate
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x1047c8098
	// Return & Params: [ Num(4) Size(0x20) ]
	struct FFrameTime SnapFrameTimeToRate(struct FFrameTime& SourceTime, struct FFrameRate& SourceRate, struct FFrameRate& SnapToRate);

	// Object: Function TimeManagement.TimeManagementBlueprintLibrary.Multiply_SecondsFrameRate
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x1047c860c
	// Return & Params: [ Num(3) Size(0x14) ]
	struct FFrameTime Multiply_SecondsFrameRate(float TimeInSeconds, struct FFrameRate& FrameRate);

	// Object: Function TimeManagement.TimeManagementBlueprintLibrary.Multiply_FrameNumberInteger
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x1047c7ca8
	// Return & Params: [ Num(3) Size(0xc) ]
	struct FFrameNumber Multiply_FrameNumberInteger(struct FFrameNumber A, int32_t B);

	// Object: Function TimeManagement.TimeManagementBlueprintLibrary.IsValid_MultipleOf
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x1047c8330
	// Return & Params: [ Num(3) Size(0x11) ]
	bool IsValid_MultipleOf(struct FFrameRate& InFrameRate, struct FFrameRate& OtherFramerate);

	// Object: Function TimeManagement.TimeManagementBlueprintLibrary.IsValid_Framerate
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x1047c8430
	// Return & Params: [ Num(2) Size(0x9) ]
	bool IsValid_Framerate(struct FFrameRate& InFrameRate);

	// Object: Function TimeManagement.TimeManagementBlueprintLibrary.GetTimecodeFrameRate
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1047c7ad4
	// Return & Params: [ Num(1) Size(0x8) ]
	struct FFrameRate GetTimecodeFrameRate();

	// Object: Function TimeManagement.TimeManagementBlueprintLibrary.GetTimecode
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1047c7b08
	// Return & Params: [ Num(1) Size(0x14) ]
	struct FTimecode GetTimecode();

	// Object: Function TimeManagement.TimeManagementBlueprintLibrary.Divide_FrameNumberInteger
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x1047c7be0
	// Return & Params: [ Num(3) Size(0xc) ]
	struct FFrameNumber Divide_FrameNumberInteger(struct FFrameNumber A, int32_t B);

	// Object: Function TimeManagement.TimeManagementBlueprintLibrary.Conv_TimecodeToString
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x1047c84c4
	// Return & Params: [ Num(3) Size(0x28) ]
	struct FString Conv_TimecodeToString(struct FTimecode& InTimecode, bool bForceSignDisplay);

	// Object: Function TimeManagement.TimeManagementBlueprintLibrary.Conv_QualifiedFrameTimeToSeconds
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x1047c86f4
	// Return & Params: [ Num(2) Size(0x14) ]
	float Conv_QualifiedFrameTimeToSeconds(struct FQualifiedFrameTime& InFrameTime);

	// Object: Function TimeManagement.TimeManagementBlueprintLibrary.Conv_FrameRateToSeconds
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x1047c878c
	// Return & Params: [ Num(2) Size(0xc) ]
	float Conv_FrameRateToSeconds(struct FFrameRate& InFrameRate);

	// Object: Function TimeManagement.TimeManagementBlueprintLibrary.Conv_FrameNumberToInteger
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x1047c7b54
	// Return & Params: [ Num(2) Size(0x8) ]
	int32_t Conv_FrameNumberToInteger(struct FFrameNumber& InFrameNumber);

	// Object: Function TimeManagement.TimeManagementBlueprintLibrary.Add_FrameNumberInteger
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x1047c7e38
	// Return & Params: [ Num(3) Size(0xc) ]
	struct FFrameNumber Add_FrameNumberInteger(struct FFrameNumber A, int32_t B);

	// Object: Function TimeManagement.TimeManagementBlueprintLibrary.Add_FrameNumberFrameNumber
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x1047c7fcc
	// Return & Params: [ Num(3) Size(0xc) ]
	struct FFrameNumber Add_FrameNumberFrameNumber(struct FFrameNumber A, struct FFrameNumber B);
};

// Object: Class TimeManagement.TimeSynchronizationSource
// Inherited Bytes: 0x28 | Struct Size: 0x30
struct UTimeSynchronizationSource : UObject {
	// Fields
	bool bUseForSynchronization; // Offset: 0x28 | Size: 0x1
	char pad_0x29[0x3]; // Offset: 0x29 | Size: 0x3
	int32_t FrameOffset; // Offset: 0x2c | Size: 0x4
};

