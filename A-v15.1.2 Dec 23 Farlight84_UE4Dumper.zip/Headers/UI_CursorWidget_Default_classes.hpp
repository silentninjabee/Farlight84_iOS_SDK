#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_CursorWidget_Default.UI_CursorWidget_Default_C
// Inherited Bytes: 0x260 | Struct Size: 0x268
struct UUI_CursorWidget_Default_C : UUserWidget {
	// Fields
	struct UCanvasPanel* CursorCanvas; // Offset: 0x260 | Size: 0x8

	// Functions

	// Object: Function UI_CursorWidget_Default.UI_CursorWidget_Default_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x103a48564
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();
};

