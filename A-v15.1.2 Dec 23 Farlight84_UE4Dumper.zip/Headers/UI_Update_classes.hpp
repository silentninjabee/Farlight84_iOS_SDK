#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Update.UI_Update_C
// Inherited Bytes: 0x400 | Struct Size: 0x560
struct UUI_Update_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x400 | Size: 0x8
	struct UWidgetAnimation* Anim_Enter; // Offset: 0x408 | Size: 0x8
	struct UButton* Btn_AgeLimit; // Offset: 0x410 | Size: 0x8
	struct UButton* Btn_Fix; // Offset: 0x418 | Size: 0x8
	struct USolarButton* btn_link; // Offset: 0x420 | Size: 0x8
	struct USolarButton* btn_new; // Offset: 0x428 | Size: 0x8
	struct UButton* Btn_Notice; // Offset: 0x430 | Size: 0x8
	struct UCanvasPanel* CanvasPanel_2; // Offset: 0x438 | Size: 0x8
	struct UHorizontalBox* HorizontalBox_1; // Offset: 0x440 | Size: 0x8
	struct UHorizontalBox* HorizontalBox_2; // Offset: 0x448 | Size: 0x8
	struct UImage* icon_link; // Offset: 0x450 | Size: 0x8
	struct UImage* Image_173; // Offset: 0x458 | Size: 0x8
	struct UImage* Img_Bg_Update; // Offset: 0x460 | Size: 0x8
	struct UImage* img_light_link; // Offset: 0x468 | Size: 0x8
	struct UImage* Img_Logo; // Offset: 0x470 | Size: 0x8
	struct UImage* img_Mask; // Offset: 0x478 | Size: 0x8
	struct UCanvasPanel* Panel_Load; // Offset: 0x480 | Size: 0x8
	struct USizeBox* Panel_ServerList; // Offset: 0x488 | Size: 0x8
	struct UProgressBar* ProgressBar_Download; // Offset: 0x490 | Size: 0x8
	struct UButton* StartGame; // Offset: 0x498 | Size: 0x8
	struct USolarTextBlock* StartGameText; // Offset: 0x4a0 | Size: 0x8
	struct USolarTextBlock* text_link; // Offset: 0x4a8 | Size: 0x8
	struct USolarTextBlock* text_new; // Offset: 0x4b0 | Size: 0x8
	struct USolarTextBlock* text_or; // Offset: 0x4b8 | Size: 0x8
	struct UTileView* TileView_ServerList; // Offset: 0x4c0 | Size: 0x8
	struct USolarTextBlock* Txt_GameInfo_CN; // Offset: 0x4c8 | Size: 0x8
	struct UTextBlock* Txt_LatestBuildNumber; // Offset: 0x4d0 | Size: 0x8
	struct USolarTextBlock* Txt_Loading_2; // Offset: 0x4d8 | Size: 0x8
	struct UTextBlock* Txt_SourceBuildNumber; // Offset: 0x4e0 | Size: 0x8
	struct USolarTextBlock* Txt_Speed; // Offset: 0x4e8 | Size: 0x8
	struct USolarTextBlock* Txt_Tips_2; // Offset: 0x4f0 | Size: 0x8
	struct UUI_UpdateLoadingBase_C* UpdateLoadingBase; // Offset: 0x4f8 | Size: 0x8
	struct UWidgetSwitcher* wgs_start; // Offset: 0x500 | Size: 0x8
	struct UMediaPlayer* MediaPlayer; // Offset: 0x508 | Size: 0x8
	struct FSlateColor Color_hoverd; // Offset: 0x510 | Size: 0x28
	struct FSlateColor Color_default; // Offset: 0x538 | Size: 0x28

	// Functions

	// Object: DelegateFunction UI_Update.UI_Update_C.OnClicked_4D867F6ABC4A986C3D9497888A447E9E
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015bb124
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_4D867F6ABC4A986C3D9497888A447E9E();

	// Object: DelegateFunction UI_Update.UI_Update_C.OnClicked_C9052C8BD647E291244A54A17616AF41
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015bb124
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_C9052C8BD647E291244A54A17616AF41();

	// Object: DelegateFunction UI_Update.UI_Update_C.OnReleased_B328A7B4F345530F9FFCAB86DBA07202
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015bb124
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnReleased_B328A7B4F345530F9FFCAB86DBA07202();

	// Object: DelegateFunction UI_Update.UI_Update_C.OnAssetManagerPreloadCompleted_B6D87D520D40034988A056A541CA4581
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015bb124
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnAssetManagerPreloadCompleted_B6D87D520D40034988A056A541CA4581();

	// Object: DelegateFunction UI_Update.UI_Update_C.OnHandleLuaException_6693B1CDDD44D8A065C82BB57BB1BB28
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015bb124
	// Return & Params: [ Num(2) Size(0x20) ]
	void OnHandleLuaException_6693B1CDDD44D8A065C82BB57BB1BB28(struct FString ErrorMsg, struct FString StaceTrace);

	// Object: Function UI_Update.UI_Update_C.ConnectGateExecCopy
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103a48564
	// Return & Params: [ Num(0) Size(0x0) ]
	void ConnectGateExecCopy();

	// Object: Function UI_Update.UI_Update_C.OnSolarUIClosed
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x1015d02c4
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnSolarUIClosed();

	// Object: Function UI_Update.UI_Update_C.Destruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x1015d02c4
	// Return & Params: [ Num(0) Size(0x0) ]
	void Destruct();

	// Object: Function UI_Update.UI_Update_C.ReceiveTick
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x1015d02c4
	// Return & Params: [ Num(2) Size(0x3c) ]
	void ReceiveTick(struct FGeometry& MyGeometry, float InDeltaTime);

	// Object: Function UI_Update.UI_Update_C.OnSolarUIOpened
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x1015d02c4
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnSolarUIOpened();

	// Object: Function UI_Update.UI_Update_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x103a48564
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();

	// Object: Function UI_Update.UI_Update_C.OnVideoReady
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103a48564
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnVideoReady();

	// Object: Function UI_Update.UI_Update_C.InitMedia
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103a48564
	// Return & Params: [ Num(1) Size(0x1) ]
	void InitMedia(bool& Result);

	// Object: Function UI_Update.UI_Update_C.FinishLoadLobby
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103a48564
	// Return & Params: [ Num(1) Size(0x4) ]
	void FinishLoadLobby(int32_t Type);

	// Object: Function UI_Update.UI_Update_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103a48564
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_Update.UI_Update_C.Tick
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103a48564
	// Return & Params: [ Num(2) Size(0x3c) ]
	void Tick(struct FGeometry MyGeometry, float InDeltaTime);

	// Object: Function UI_Update.UI_Update_C.ReceiveShow
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103a48564
	// Return & Params: [ Num(0) Size(0x0) ]
	void ReceiveShow();

	// Object: Function UI_Update.UI_Update_C.ConnectGateExec
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x1015d02c4
	// Return & Params: [ Num(0) Size(0x0) ]
	void ConnectGateExec();

	// Object: Function UI_Update.UI_Update_C.ReceiveHide
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103a48564
	// Return & Params: [ Num(0) Size(0x0) ]
	void ReceiveHide();

	// Object: Function UI_Update.UI_Update_C.BndEvt__btn_link_K2Node_ComponentBoundEvent_0_OnButtonHoverEvent__DelegateSignature
	// Flags: [BlueprintEvent]
	// Offset: 0x103a48564
	// Return & Params: [ Num(0) Size(0x0) ]
	void BndEvt__btn_link_K2Node_ComponentBoundEvent_0_OnButtonHoverEvent__DelegateSignature();

	// Object: Function UI_Update.UI_Update_C.BndEvt__btn_link_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature
	// Flags: [BlueprintEvent]
	// Offset: 0x103a48564
	// Return & Params: [ Num(0) Size(0x0) ]
	void BndEvt__btn_link_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature();

	// Object: Function UI_Update.UI_Update_C.ExecuteUbergraph_UI_Update
	// Flags: [Final|UbergraphFunction|HasDefaults]
	// Offset: 0x103a48564
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_Update(int32_t EntryPoint);
};

