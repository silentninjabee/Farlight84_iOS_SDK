#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class UnLua.UnLuaInterface
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UUnLuaInterface : UInterface {
	// Functions

	// Object: Function UnLua.UnLuaInterface.GetModuleName
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x10165fe70
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();
};

// Object: Class UnLua.UnLuaManager
// Inherited Bytes: 0x28 | Struct Size: 0x5b8
struct UUnLuaManager : UObject {
	// Fields
	char pad_0x28[0x590]; // Offset: 0x28 | Size: 0x590

	// Functions

	// Object: Function UnLua.UnLuaManager.TriggerAnimNotify
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x103a48564
	// Return & Params: [ Num(0) Size(0x0) ]
	void TriggerAnimNotify();

	// Object: Function UnLua.UnLuaManager.OnLatentActionCompleted
	// Flags: [Final|Native|Public]
	// Offset: 0x1016602bc
	// Return & Params: [ Num(1) Size(0x4) ]
	void OnLatentActionCompleted(int32_t LinkID);

	// Object: Function UnLua.UnLuaManager.OnActorDestroyed
	// Flags: [Final|Native|Public]
	// Offset: 0x10166033c
	// Return & Params: [ Num(1) Size(0x8) ]
	void OnActorDestroyed(struct AActor* Actor);

	// Object: Function UnLua.UnLuaManager.InputVectorAxis
	// Flags: [Event|Public|HasOutParms|HasDefaults|BlueprintEvent]
	// Offset: 0x103a48564
	// Return & Params: [ Num(1) Size(0xc) ]
	void InputVectorAxis(struct FVector& AxisValue);

	// Object: Function UnLua.UnLuaManager.InputTouch
	// Flags: [Event|Public|HasOutParms|HasDefaults|BlueprintEvent]
	// Offset: 0x103a48564
	// Return & Params: [ Num(2) Size(0x10) ]
	void InputTouch(enum class ETouchIndex FingerIndex, struct FVector& Location);

	// Object: Function UnLua.UnLuaManager.InputGesture
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x103a48564
	// Return & Params: [ Num(1) Size(0x4) ]
	void InputGesture(float Value);

	// Object: Function UnLua.UnLuaManager.InputAxis
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x103a48564
	// Return & Params: [ Num(1) Size(0x4) ]
	void InputAxis(float AxisValue);

	// Object: Function UnLua.UnLuaManager.InputAction
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x103a48564
	// Return & Params: [ Num(1) Size(0x18) ]
	void InputAction(struct FKey Key);
};

// Object: Class UnLua.UnLuaPerformanceTestProxy
// Inherited Bytes: 0x228 | Struct Size: 0x288
struct AUnLuaPerformanceTestProxy : AActor {
	// Fields
	char pad_0x228[0x8]; // Offset: 0x228 | Size: 0x8
	int32_t MeshID; // Offset: 0x230 | Size: 0x4
	char pad_0x234[0x4]; // Offset: 0x234 | Size: 0x4
	struct FString MeshName; // Offset: 0x238 | Size: 0x10
	struct FVector COM; // Offset: 0x248 | Size: 0xc
	char pad_0x254[0x4]; // Offset: 0x254 | Size: 0x4
	struct TArray<int32_t> Indices; // Offset: 0x258 | Size: 0x10
	struct TArray<struct FVector> Positions; // Offset: 0x268 | Size: 0x10
	struct TArray<struct FVector> PredictedPositions; // Offset: 0x278 | Size: 0x10

	// Functions

	// Object: Function UnLua.UnLuaPerformanceTestProxy.UpdatePositions
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101660b80
	// Return & Params: [ Num(1) Size(0x10) ]
	void UpdatePositions(struct TArray<struct FVector>& NewPositions);

	// Object: Function UnLua.UnLuaPerformanceTestProxy.UpdateMeshName
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101660ecc
	// Return & Params: [ Num(2) Size(0x20) ]
	struct FString UpdateMeshName(struct FString NewName);

	// Object: Function UnLua.UnLuaPerformanceTestProxy.UpdateMeshID
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101660fa0
	// Return & Params: [ Num(2) Size(0x8) ]
	int32_t UpdateMeshID(int32_t NewID);

	// Object: Function UnLua.UnLuaPerformanceTestProxy.UpdateIndices
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101660cb0
	// Return & Params: [ Num(1) Size(0x10) ]
	void UpdateIndices(struct TArray<int32_t>& NewIndices);

	// Object: Function UnLua.UnLuaPerformanceTestProxy.Simulate
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101661128
	// Return & Params: [ Num(1) Size(0x4) ]
	void Simulate(float DeltaTime);

	// Object: Function UnLua.UnLuaPerformanceTestProxy.Raycast
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x101660de0
	// Return & Params: [ Num(3) Size(0x19) ]
	bool Raycast(struct FVector& Origin, struct FVector& Direction);

	// Object: Function UnLua.UnLuaPerformanceTestProxy.NOP
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1016611a8
	// Return & Params: [ Num(0) Size(0x0) ]
	void NOP();

	// Object: Function UnLua.UnLuaPerformanceTestProxy.GetPredictedPositions
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x101660af8
	// Return & Params: [ Num(1) Size(0x10) ]
	struct TArray<struct FVector> GetPredictedPositions();

	// Object: Function UnLua.UnLuaPerformanceTestProxy.GetPositions
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x101660c18
	// Return & Params: [ Num(1) Size(0x10) ]
	void GetPositions(struct TArray<struct FVector>& OutPositions);

	// Object: Function UnLua.UnLuaPerformanceTestProxy.GetMeshName
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x101661070
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetMeshName();

	// Object: Function UnLua.UnLuaPerformanceTestProxy.GetMeshInfo
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x101660890
	// Return & Params: [ Num(7) Size(0x59) ]
	bool GetMeshInfo(int32_t& OutMeshID, struct FString& OutMeshName, struct FVector& OutCOM, struct TArray<int32_t>& OutIndices, struct TArray<struct FVector>& OutPositions, struct TArray<struct FVector>& OutPredictedPositions);

	// Object: Function UnLua.UnLuaPerformanceTestProxy.GetMeshID
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1016610f4
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetMeshID();

	// Object: Function UnLua.UnLuaPerformanceTestProxy.GetIndices
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x101660d48
	// Return & Params: [ Num(1) Size(0x10) ]
	void GetIndices(struct TArray<int32_t>& OutIndices);

	// Object: Function UnLua.UnLuaPerformanceTestProxy.GetCOM
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x101661030
	// Return & Params: [ Num(1) Size(0xc) ]
	struct FVector GetCOM();
};

