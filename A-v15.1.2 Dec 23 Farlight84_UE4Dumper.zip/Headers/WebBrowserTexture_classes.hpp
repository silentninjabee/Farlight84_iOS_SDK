#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class WebBrowserTexture.WebBrowserTexture
// Inherited Bytes: 0xb8 | Struct Size: 0x100
struct UWebBrowserTexture : UTexture {
	// Fields
	char pad_0xB8[0x48]; // Offset: 0xb8 | Size: 0x48
};

