#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class WebBrowserWidget.WebBrowser
// Inherited Bytes: 0x138 | Struct Size: 0x1a0
struct UWebBrowser : UWidget {
	// Fields
	struct FMulticastInlineDelegate OnUrlChanged; // Offset: 0x138 | Size: 0x10
	struct FMulticastInlineDelegate OnBeforePopup; // Offset: 0x148 | Size: 0x10
	struct FMulticastInlineDelegate OnBeforeNavigation; // Offset: 0x158 | Size: 0x10
	struct TArray<struct FString> URLKeywordWithoutNavigation; // Offset: 0x168 | Size: 0x10
	struct FString InitialURL; // Offset: 0x178 | Size: 0x10
	bool bSupportsTransparency; // Offset: 0x188 | Size: 0x1
	char pad_0x189[0x17]; // Offset: 0x189 | Size: 0x17

	// Functions

	// Object: Function WebBrowserWidget.WebBrowser.StopLoad
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1017305c4
	// Return & Params: [ Num(0) Size(0x0) ]
	void StopLoad();

	// Object: Function WebBrowserWidget.WebBrowser.SetURLWithoutNavigation
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1017304f8
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetURLWithoutNavigation(struct TArray<struct FString>& URLs);

	// Object: Function WebBrowserWidget.WebBrowser.Reload
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1017305d8
	// Return & Params: [ Num(0) Size(0x0) ]
	void Reload();

	// Object: DelegateFunction WebBrowserWidget.WebBrowser.OnUrlChanged__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103a48564
	// Return & Params: [ Num(1) Size(0x18) ]
	void OnUrlChanged__DelegateSignature(struct FText& Text);

	// Object: DelegateFunction WebBrowserWidget.WebBrowser.OnBeforePopup__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a48564
	// Return & Params: [ Num(2) Size(0x20) ]
	void OnBeforePopup__DelegateSignature(struct FString URL, struct FString Frame);

	// Object: DelegateFunction WebBrowserWidget.WebBrowser.OnBeforeNavigation__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a48564
	// Return & Params: [ Num(1) Size(0x10) ]
	void OnBeforeNavigation__DelegateSignature(struct FString URL);

	// Object: Function WebBrowserWidget.WebBrowser.LoadURL
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101730a84
	// Return & Params: [ Num(1) Size(0x10) ]
	void LoadURL(struct FString NewURL);

	// Object: Function WebBrowserWidget.WebBrowser.LoadString
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1017308e0
	// Return & Params: [ Num(2) Size(0x20) ]
	void LoadString(struct FString Contents, struct FString DummyURL);

	// Object: Function WebBrowserWidget.WebBrowser.GetUrl
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10173072c
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetUrl();

	// Object: Function WebBrowserWidget.WebBrowser.GetTitleText
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1017307ac
	// Return & Params: [ Num(1) Size(0x18) ]
	struct FText GetTitleText();

	// Object: Function WebBrowserWidget.WebBrowser.ExecuteJavascript
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101730854
	// Return & Params: [ Num(1) Size(0x10) ]
	void ExecuteJavascript(struct FString ScriptText);

	// Object: Function WebBrowserWidget.WebBrowser.CloseSelf
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1017305ec
	// Return & Params: [ Num(0) Size(0x0) ]
	void CloseSelf();

	// Object: Function WebBrowserWidget.WebBrowser.BindUObject
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101730600
	// Return & Params: [ Num(3) Size(0x19) ]
	void BindUObject(struct FString Name, struct UObject* Object, bool bIsPermanent);
};

// Object: Class WebBrowserWidget.WebBrowserAssetManager
// Inherited Bytes: 0x28 | Struct Size: 0x78
struct UWebBrowserAssetManager : UObject {
	// Fields
	struct TSoftObjectPtr<UMaterial> DefaultMaterial; // Offset: 0x28 | Size: 0x28
	char pad_0x50[0x28]; // Offset: 0x50 | Size: 0x28
};

