#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct WebBrowser.WebJSCallbackBase
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FWebJSCallbackBase {
	// Fields
	char pad_0x0[0x20]; // Offset: 0x0 | Size: 0x20
};

// Object: ScriptStruct WebBrowser.WebJSResponse
// Inherited Bytes: 0x20 | Struct Size: 0x20
struct FWebJSResponse : FWebJSCallbackBase {
};

// Object: ScriptStruct WebBrowser.WebJSFunction
// Inherited Bytes: 0x20 | Struct Size: 0x20
struct FWebJSFunction : FWebJSCallbackBase {
};

