#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct WidgetCarousel.WidgetCarouselNavigationBarStyle
// Inherited Bytes: 0x8 | Struct Size: 0xc90
struct FWidgetCarouselNavigationBarStyle : FSlateWidgetStyle {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FSlateBrush HighlightBrush; // Offset: 0x10 | Size: 0xe0
	struct FButtonStyle LeftButtonStyle; // Offset: 0xf0 | Size: 0x3e0
	struct FButtonStyle CenterButtonStyle; // Offset: 0x4d0 | Size: 0x3e0
	struct FButtonStyle RightButtonStyle; // Offset: 0x8b0 | Size: 0x3e0
};

// Object: ScriptStruct WidgetCarousel.WidgetCarouselNavigationButtonStyle
// Inherited Bytes: 0x8 | Struct Size: 0x5b0
struct FWidgetCarouselNavigationButtonStyle : FSlateWidgetStyle {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FButtonStyle InnerButtonStyle; // Offset: 0x10 | Size: 0x3e0
	struct FSlateBrush NavigationButtonLeftImage; // Offset: 0x3f0 | Size: 0xe0
	struct FSlateBrush NavigationButtonRightImage; // Offset: 0x4d0 | Size: 0xe0
};

