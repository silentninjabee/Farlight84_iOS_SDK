#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass Ability_Rifle_B9A05_BaseDamage_3.Ability_Rifle_B9A05_BaseDamage_2_C
// Size: 0x310 // Inherited bytes: 0x310
struct AAbility_Rifle_B9A05_BaseDamage_2_C : ASolarAbility {
};

