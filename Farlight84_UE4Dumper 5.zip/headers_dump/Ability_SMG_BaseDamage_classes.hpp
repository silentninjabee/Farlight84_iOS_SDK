#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass Ability_SMG_BaseDamage.Ability_SMG_BaseDamage_C
// Size: 0x318 // Inherited bytes: 0x310
struct AAbility_SMG_BaseDamage_C : ASolarAbility {
	// Fields
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x310 // Size: 0x08
};

