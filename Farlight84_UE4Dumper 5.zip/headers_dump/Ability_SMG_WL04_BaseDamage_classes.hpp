#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass Ability_SMG_WL04_BaseDamage.Ability_SMG_WL04_BaseDamage_C
// Size: 0x310 // Inherited bytes: 0x310
struct AAbility_SMG_WL04_BaseDamage_C : ASolarAbility {
};

