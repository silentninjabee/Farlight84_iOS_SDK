#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass Ability_VH_Hover_Soroll02_AutoGun_BaseDamage.Ability_VH_Hover_Soroll02_AutoGun_BaseDamage_C
// Size: 0x310 // Inherited bytes: 0x310
struct AAbility_VH_Hover_Soroll02_AutoGun_BaseDamage_C : ASolarAbility {
};

