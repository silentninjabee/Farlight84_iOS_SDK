#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass Ability_VH_Leg_WL06_Shotgun_ExplosionDamage_man.Ability_VH_Leg_WL06_Shotgun_ExplosionDamage_man_C
// Size: 0x319 // Inherited bytes: 0x310
struct AAbility_VH_Leg_WL06_Shotgun_ExplosionDamage_man_C : ASolarAbility {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x310 // Size: 0x08
	bool HasExploded; // Offset: 0x318 // Size: 0x01

	// Functions

	// Object Name: Function Ability_VH_Leg_WL06_Shotgun_ExplosionDamage_man.Ability_VH_Leg_WL06_Shotgun_ExplosionDamage_man_C.ReceiveBeginPlay
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveBeginPlay(); // Offset: 0x1032a8510 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Ability_VH_Leg_WL06_Shotgun_ExplosionDamage_man.Ability_VH_Leg_WL06_Shotgun_ExplosionDamage_man_C.ReceiveTick
	// Flags: [Event|Public|BlueprintEvent]
	void ReceiveTick(float DeltaSeconds); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Ability_VH_Leg_WL06_Shotgun_ExplosionDamage_man.Ability_VH_Leg_WL06_Shotgun_ExplosionDamage_man_C.ExecuteUbergraph_Ability_VH_Leg_WL06_Shotgun_ExplosionDamage_man
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_Ability_VH_Leg_WL06_Shotgun_ExplosionDamage_man(int32_t EntryPoint); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x4)
};

