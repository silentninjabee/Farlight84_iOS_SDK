#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass AnimNotifyState_SolarLobbyAkEvent.AnimNotifyState_SolarLobbyAkEvent_C
// Size: 0x80 // Inherited bytes: 0x30
struct UAnimNotifyState_SolarLobbyAkEvent_C : UAnimNotifyState {
	// Fields
	bool Follow; // Offset: 0x30 // Size: 0x01
	char pad_0x31[0x7]; // Offset: 0x31 // Size: 0x07
	struct FString Attach Name; // Offset: 0x38 // Size: 0x10
	struct UAkAudioEvent* Begin Event; // Offset: 0x48 // Size: 0x08
	struct FString Begin Event Name; // Offset: 0x50 // Size: 0x10
	struct UAkAudioEvent* End Event; // Offset: 0x60 // Size: 0x08
	struct FString End Event Name; // Offset: 0x68 // Size: 0x10
	struct UAkComponent* NewVar_1; // Offset: 0x78 // Size: 0x08

	// Functions

	// Object Name: Function AnimNotifyState_SolarLobbyAkEvent.AnimNotifyState_SolarLobbyAkEvent_C.AK Event Fun
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|Const]
	void AK Event Fun(struct USkeletalMeshComponent* Skeletal Mesh Comp, struct UAkAudioEvent* Event, struct FString Event Name, bool isNotifyEnd, bool& Return Value); // Offset: 0x1032a8510 // Return & Params: Num(5) Size(0x22)

	// Object Name: Function AnimNotifyState_SolarLobbyAkEvent.AnimNotifyState_SolarLobbyAkEvent_C.Get Mesh AK Component
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	void Get Mesh AK Component(struct USkeletalMeshComponent* InSkeletalMeshComp, struct UAkComponent*& OutAkComp, bool& IsSuccess); // Offset: 0x1032a8510 // Return & Params: Num(3) Size(0x11)

	// Object Name: Function AnimNotifyState_SolarLobbyAkEvent.AnimNotifyState_SolarLobbyAkEvent_C.GetAkSwitch
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	void GetAkSwitch(struct USkeletalMeshComponent* InSkeletalMeshComp, bool& ShouldPlaySounds); // Offset: 0x1032a8510 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function AnimNotifyState_SolarLobbyAkEvent.AnimNotifyState_SolarLobbyAkEvent_C.Received_NotifyEnd
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	bool Received_NotifyEnd(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Offset: 0x1032a8510 // Return & Params: Num(3) Size(0x11)

	// Object Name: Function AnimNotifyState_SolarLobbyAkEvent.AnimNotifyState_SolarLobbyAkEvent_C.Received_NotifyBegin
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	bool Received_NotifyBegin(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation, float TotalDuration); // Offset: 0x1032a8510 // Return & Params: Num(4) Size(0x15)
};

