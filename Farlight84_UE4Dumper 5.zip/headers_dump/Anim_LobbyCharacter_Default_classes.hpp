#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: DynamicClass Anim_LobbyCharacter_Default.Anim_LobbyCharacter_Default_C
// Size: 0x6c0 // Inherited bytes: 0x270
struct UAnim_LobbyCharacter_Default_C : USolarLobbyAnimInstance {
	// Fields
	struct FAnimNode_Root AnimGraphNode_Root; // Offset: 0x270 // Size: 0x30
	struct FAnimNode_Slot AnimGraphNode_Slot; // Offset: 0x2a0 // Size: 0x48
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_2; // Offset: 0x2e8 // Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult; // Offset: 0x310 // Size: 0x28
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_3; // Offset: 0x338 // Size: 0x78
	struct FAnimNode_StateResult AnimGraphNode_StateResult_2; // Offset: 0x3b0 // Size: 0x30
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2; // Offset: 0x3e0 // Size: 0x78
	struct FAnimNode_StateResult AnimGraphNode_StateResult; // Offset: 0x458 // Size: 0x30
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine; // Offset: 0x488 // Size: 0xb0
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer; // Offset: 0x538 // Size: 0x78
	struct FAnimNode_TwoWayBlend AnimGraphNode_TwoWayBlend; // Offset: 0x5b0 // Size: 0xc8
	struct UAnimSequenceBase* IdleAnim; // Offset: 0x678 // Size: 0x08
	struct UAnimSequenceBase* CurIdleShow; // Offset: 0x680 // Size: 0x08
	struct TArray<struct UAnimSequenceBase*> IdleShowList; // Offset: 0x688 // Size: 0x10
	bool ShouldPlayShow; // Offset: 0x698 // Size: 0x01
	char pad_0x699[0x3]; // Offset: 0x699 // Size: 0x03
	float ShowCDTime; // Offset: 0x69c // Size: 0x04
	struct FTimerHandle IdleShowCD; // Offset: 0x6a0 // Size: 0x08
	int32_t MaxNum; // Offset: 0x6a8 // Size: 0x04
	bool CharacterCanBeLooked; // Offset: 0x6ac // Size: 0x01
	char pad_0x6AD[0x3]; // Offset: 0x6ad // Size: 0x03
	float K2Node_Event_DeltaTimeX; // Offset: 0x6b0 // Size: 0x04
	bool K2Node_Event_IsVisible; // Offset: 0x6b4 // Size: 0x01
	char pad_0x6B5[0xb]; // Offset: 0x6b5 // Size: 0x0b

	// Functions

	// Object Name: Function Anim_LobbyCharacter_Default.Anim_LobbyCharacter_Default_C.SetCharacterCanBeLooked
	// Flags: [Native|Event|Public]
	void SetCharacterCanBeLooked(bool bpp__IsVisible__pf); // Offset: 0x101bc8d18 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Anim_LobbyCharacter_Default.Anim_LobbyCharacter_Default_C.Rand Idle Show BP
	// Flags: [Native|Public|BlueprintCallable]
	void Rand Idle Show BP(); // Offset: 0x101bc8b5c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Anim_LobbyCharacter_Default.Anim_LobbyCharacter_Default_C.RandIdleShow
	// Flags: [Native|Event|Public]
	void RandIdleShow(); // Offset: 0x101bc8cfc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Anim_LobbyCharacter_Default.Anim_LobbyCharacter_Default_C.PlayIdleShow
	// Flags: [Native|Public|BlueprintCallable]
	void PlayIdleShow(); // Offset: 0x101bc8cc4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Anim_LobbyCharacter_Default.Anim_LobbyCharacter_Default_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_LobbyCharacter_Default_AnimGraphNode_TwoWayBlend_1324C6B947749553DBAB488CF6FFAA1D
	// Flags: [Native|Public]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_LobbyCharacter_Default_AnimGraphNode_TwoWayBlend_1324C6B947749553DBAB488CF6FFAA1D(); // Offset: 0x101bc8be8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Anim_LobbyCharacter_Default.Anim_LobbyCharacter_Default_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_LobbyCharacter_Default_AnimGraphNode_TransitionResult_EFF864F2415FFE7C85667C9B1A0CC213
	// Flags: [Native|Public]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_LobbyCharacter_Default_AnimGraphNode_TransitionResult_EFF864F2415FFE7C85667C9B1A0CC213(); // Offset: 0x101bc8c04 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Anim_LobbyCharacter_Default.Anim_LobbyCharacter_Default_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_LobbyCharacter_Default_AnimGraphNode_TransitionResult_91AB0B2E43FDD2622D11D4823EEDD73C
	// Flags: [Native|Public]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_LobbyCharacter_Default_AnimGraphNode_TransitionResult_91AB0B2E43FDD2622D11D4823EEDD73C(); // Offset: 0x101bc8b94 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Anim_LobbyCharacter_Default.Anim_LobbyCharacter_Default_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_LobbyCharacter_Default_AnimGraphNode_SequencePlayer_D129D66148A76FE8404F6BB53C41B2F5
	// Flags: [Native|Public]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_LobbyCharacter_Default_AnimGraphNode_SequencePlayer_D129D66148A76FE8404F6BB53C41B2F5(); // Offset: 0x101bc8b78 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Anim_LobbyCharacter_Default.Anim_LobbyCharacter_Default_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_LobbyCharacter_Default_AnimGraphNode_SequencePlayer_9F92E37E45D0DB25B7813584454F8BDC
	// Flags: [Native|Public]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_LobbyCharacter_Default_AnimGraphNode_SequencePlayer_9F92E37E45D0DB25B7813584454F8BDC(); // Offset: 0x101bc8bcc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Anim_LobbyCharacter_Default.Anim_LobbyCharacter_Default_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_LobbyCharacter_Default_AnimGraphNode_SequencePlayer_8F8046714AA0A8276EC35FB1CD0F037A
	// Flags: [Native|Public]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_LobbyCharacter_Default_AnimGraphNode_SequencePlayer_8F8046714AA0A8276EC35FB1CD0F037A(); // Offset: 0x101bc8bb0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Anim_LobbyCharacter_Default.Anim_LobbyCharacter_Default_C.BlueprintUpdateAnimation
	// Flags: [Native|Event|Public]
	void BlueprintUpdateAnimation(float bpp__DeltaTimeX__pf); // Offset: 0x101bc8c20 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Anim_LobbyCharacter_Default.Anim_LobbyCharacter_Default_C.AnimNotify_IdleShowStart
	// Flags: [Native|Public|BlueprintCallable]
	void AnimNotify_IdleShowStart(); // Offset: 0x101bc8ca8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Anim_LobbyCharacter_Default.Anim_LobbyCharacter_Default_C.AnimNotify_IdleShowFinish
	// Flags: [Native|Public|BlueprintCallable]
	void AnimNotify_IdleShowFinish(); // Offset: 0x101bc8da8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Anim_LobbyCharacter_Default.Anim_LobbyCharacter_Default_C.AnimNotify_IdleAnimStart
	// Flags: [Native|Public|BlueprintCallable]
	void AnimNotify_IdleAnimStart(); // Offset: 0x101bc8ce0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Anim_LobbyCharacter_Default.Anim_LobbyCharacter_Default_C.AnimGraph
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	void AnimGraph(struct FPoseLink& bpp__AnimGraph__pf); // Offset: 0x101bc8abc // Return & Params: Num(1) Size(0x10)
};

