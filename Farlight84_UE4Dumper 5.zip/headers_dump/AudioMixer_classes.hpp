#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class AudioMixer.SynthComponent
// Size: 0x820 // Inherited bytes: 0x350
struct USynthComponent : USceneComponent {
	// Fields
	char bAutoDestroy : 1; // Offset: 0x344 // Size: 0x01
	char bStopWhenOwnerDestroyed : 1; // Offset: 0x344 // Size: 0x01
	char bAllowSpatialization : 1; // Offset: 0x344 // Size: 0x01
	char bOverrideAttenuation : 1; // Offset: 0x344 // Size: 0x01
	char bOutputToBusOnly : 1; // Offset: 0x344 // Size: 0x01
	struct USoundAttenuation* AttenuationSettings; // Offset: 0x348 // Size: 0x08
	struct FSoundAttenuationSettings AttenuationOverrides; // Offset: 0x350 // Size: 0x3a0
	struct USoundConcurrency* ConcurrencySettings; // Offset: 0x6f0 // Size: 0x08
	struct TSet<struct USoundConcurrency*> ConcurrencySet; // Offset: 0x6f8 // Size: 0x50
	struct USoundClass* SoundClass; // Offset: 0x748 // Size: 0x08
	struct USoundEffectSourcePresetChain* SourceEffectChain; // Offset: 0x750 // Size: 0x08
	struct USoundSubmixBase* SoundSubmix; // Offset: 0x758 // Size: 0x08
	struct TArray<struct FSoundSubmixSendInfo> SoundSubmixSends; // Offset: 0x760 // Size: 0x10
	struct TArray<struct FSoundSourceBusSendInfo> BusSends; // Offset: 0x770 // Size: 0x10
	struct FSoundModulation Modulation; // Offset: 0x780 // Size: 0x10
	struct TArray<struct FSoundSourceBusSendInfo> PreEffectBusSends; // Offset: 0x790 // Size: 0x10
	char bIsUISound : 1; // Offset: 0x7a0 // Size: 0x01
	char bIsPreviewSound : 1; // Offset: 0x7a0 // Size: 0x01
	int32_t EnvelopeFollowerAttackTime; // Offset: 0x7a4 // Size: 0x04
	int32_t EnvelopeFollowerReleaseTime; // Offset: 0x7a8 // Size: 0x04
	struct FMulticastInlineDelegate OnAudioEnvelopeValue; // Offset: 0x7b0 // Size: 0x10
	char pad_0x7C0_7 : 1; // Offset: 0x7c0 // Size: 0x01
	char pad_0x7C1[0x1f]; // Offset: 0x7c1 // Size: 0x1f
	struct USynthSound* Synth; // Offset: 0x7e0 // Size: 0x08
	struct UAudioComponent* AudioComponent; // Offset: 0x7e8 // Size: 0x08
	char pad_0x7F0[0x30]; // Offset: 0x7f0 // Size: 0x30

	// Functions

	// Object Name: Function AudioMixer.SynthComponent.Stop
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Stop(); // Offset: 0x1043325b8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AudioMixer.SynthComponent.Start
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Start(); // Offset: 0x1043325cc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AudioMixer.SynthComponent.SetVolumeMultiplier
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetVolumeMultiplier(float VolumeMultiplier); // Offset: 0x104332504 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function AudioMixer.SynthComponent.SetSubmixSend
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSubmixSend(struct USoundSubmixBase* Submix, float SendLevel); // Offset: 0x104332438 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function AudioMixer.SynthComponent.IsPlaying
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsPlaying(); // Offset: 0x104332584 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class AudioMixer.AudioGenerator
// Size: 0xc0 // Inherited bytes: 0x28
struct UAudioGenerator : UObject {
	// Fields
	char pad_0x28[0x98]; // Offset: 0x28 // Size: 0x98
};

// Object Name: Class AudioMixer.AudioMixerBlueprintLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct UAudioMixerBlueprintLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function AudioMixer.AudioMixerBlueprintLibrary.TrimAudioCache
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	float TrimAudioCache(float InMegabytesToFree); // Offset: 0x10432e560 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function AudioMixer.AudioMixerBlueprintLibrary.StopRecordingOutput
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct USoundWave* StopRecordingOutput(struct UObject* WorldContextObject, enum class EAudioRecordingExportType ExportType, struct FString Name, struct FString Path, struct USoundSubmix* SubmixToRecord, struct USoundWave* ExistingSoundWaveToOverwrite); // Offset: 0x10432f2b8 // Return & Params: Num(7) Size(0x48)

	// Object Name: Function AudioMixer.AudioMixerBlueprintLibrary.StopAnalyzingOutput
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void StopAnalyzingOutput(struct UObject* WorldContextObject, struct USoundSubmix* SubmixToStopAnalyzing); // Offset: 0x10432ee88 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function AudioMixer.AudioMixerBlueprintLibrary.StartRecordingOutput
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void StartRecordingOutput(struct UObject* WorldContextObject, float ExpectedDuration, struct USoundSubmix* SubmixToRecord); // Offset: 0x10432f528 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function AudioMixer.AudioMixerBlueprintLibrary.StartAnalyzingOutput
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void StartAnalyzingOutput(struct UObject* WorldContextObject, struct USoundSubmix* SubmixToAnalyze, enum class EFFTSize FFTSize, enum class EFFTPeakInterpolationMethod InterpolationMethod, enum class EFFTWindowType WindowType, float HopSize); // Offset: 0x10432ef48 // Return & Params: Num(6) Size(0x18)

	// Object Name: Function AudioMixer.AudioMixerBlueprintLibrary.SetBypassSourceEffectChainEntry
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetBypassSourceEffectChainEntry(struct UObject* WorldContextObject, struct USoundEffectSourcePresetChain* PresetChain, int32_t EntryIndex, bool bBypassed); // Offset: 0x10432e814 // Return & Params: Num(4) Size(0x15)

	// Object Name: Function AudioMixer.AudioMixerBlueprintLibrary.ResumeRecordingOutput
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void ResumeRecordingOutput(struct UObject* WorldContextObject, struct USoundSubmix* SubmixToPause); // Offset: 0x10432f138 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function AudioMixer.AudioMixerBlueprintLibrary.ReplaceSoundEffectSubmix
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void ReplaceSoundEffectSubmix(struct UObject* WorldContextObject, struct USoundSubmix* InSoundSubmix, int32_t SubmixChainIndex, struct USoundEffectSubmixPreset* SubmixEffectPreset); // Offset: 0x10432f6f8 // Return & Params: Num(4) Size(0x20)

	// Object Name: Function AudioMixer.AudioMixerBlueprintLibrary.RemoveSubmixEffectPresetAtIndex
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void RemoveSubmixEffectPresetAtIndex(struct UObject* WorldContextObject, struct USoundSubmix* SoundSubmix, int32_t SubmixChainIndex); // Offset: 0x10432f850 // Return & Params: Num(3) Size(0x14)

	// Object Name: Function AudioMixer.AudioMixerBlueprintLibrary.RemoveSubmixEffectPreset
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void RemoveSubmixEffectPreset(struct UObject* WorldContextObject, struct USoundSubmix* SoundSubmix, struct USoundEffectSubmixPreset* SubmixEffectPreset); // Offset: 0x10432f95c // Return & Params: Num(3) Size(0x18)

	// Object Name: Function AudioMixer.AudioMixerBlueprintLibrary.RemoveSourceEffectFromPresetChain
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void RemoveSourceEffectFromPresetChain(struct UObject* WorldContextObject, struct USoundEffectSourcePresetChain* PresetChain, int32_t EntryIndex); // Offset: 0x10432e970 // Return & Params: Num(3) Size(0x14)

	// Object Name: Function AudioMixer.AudioMixerBlueprintLibrary.RemoveMasterSubmixEffect
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void RemoveMasterSubmixEffect(struct UObject* WorldContextObject, struct USoundEffectSubmixPreset* SubmixEffectPreset); // Offset: 0x10432fbf4 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function AudioMixer.AudioMixerBlueprintLibrary.PrimeSoundForPlayback
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void PrimeSoundForPlayback(struct USoundWave* SoundWave, struct FDelegate OnLoadCompletion); // Offset: 0x10432e658 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function AudioMixer.AudioMixerBlueprintLibrary.PrimeSoundCueForPlayback
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void PrimeSoundCueForPlayback(struct USoundCue* SoundCue); // Offset: 0x10432e5e0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function AudioMixer.AudioMixerBlueprintLibrary.PauseRecordingOutput
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void PauseRecordingOutput(struct UObject* WorldContextObject, struct USoundSubmix* SubmixToPause); // Offset: 0x10432f1f8 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function AudioMixer.AudioMixerBlueprintLibrary.GetPhaseForFrequencies
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetPhaseForFrequencies(struct UObject* WorldContextObject, struct TArray<float>& Frequencies, struct TArray<float>& Phases, struct USoundSubmix* SubmixToAnalyze); // Offset: 0x10432eb80 // Return & Params: Num(4) Size(0x30)

	// Object Name: Function AudioMixer.AudioMixerBlueprintLibrary.GetNumberOfEntriesInSourceEffectChain
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int32_t GetNumberOfEntriesInSourceEffectChain(struct UObject* WorldContextObject, struct USoundEffectSourcePresetChain* PresetChain); // Offset: 0x10432e74c // Return & Params: Num(3) Size(0x14)

	// Object Name: Function AudioMixer.AudioMixerBlueprintLibrary.GetMagnitudeForFrequencies
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetMagnitudeForFrequencies(struct UObject* WorldContextObject, struct TArray<float>& Frequencies, struct TArray<float>& Magnitudes, struct USoundSubmix* SubmixToAnalyze); // Offset: 0x10432ed04 // Return & Params: Num(4) Size(0x30)

	// Object Name: Function AudioMixer.AudioMixerBlueprintLibrary.ClearSubmixEffects
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void ClearSubmixEffects(struct UObject* WorldContextObject, struct USoundSubmix* SoundSubmix); // Offset: 0x10432f638 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function AudioMixer.AudioMixerBlueprintLibrary.ClearMasterSubmixEffects
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void ClearMasterSubmixEffects(struct UObject* WorldContextObject); // Offset: 0x10432fb7c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function AudioMixer.AudioMixerBlueprintLibrary.AddSubmixEffect
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int32_t AddSubmixEffect(struct UObject* WorldContextObject, struct USoundSubmix* SoundSubmix, struct USoundEffectSubmixPreset* SubmixEffectPreset); // Offset: 0x10432fa68 // Return & Params: Num(4) Size(0x1c)

	// Object Name: Function AudioMixer.AudioMixerBlueprintLibrary.AddSourceEffectToPresetChain
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void AddSourceEffectToPresetChain(struct UObject* WorldContextObject, struct USoundEffectSourcePresetChain* PresetChain, struct FSourceEffectChainEntry Entry); // Offset: 0x10432ea7c // Return & Params: Num(3) Size(0x20)

	// Object Name: Function AudioMixer.AudioMixerBlueprintLibrary.AddMasterSubmixEffect
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void AddMasterSubmixEffect(struct UObject* WorldContextObject, struct USoundEffectSubmixPreset* SubmixEffectPreset); // Offset: 0x10432fcb4 // Return & Params: Num(2) Size(0x10)
};

// Object Name: Class AudioMixer.SubmixEffectDynamicsProcessorPreset
// Size: 0x120 // Inherited bytes: 0x40
struct USubmixEffectDynamicsProcessorPreset : USoundEffectSubmixPreset {
	// Fields
	char pad_0x40[0x90]; // Offset: 0x40 // Size: 0x90
	struct FSubmixEffectDynamicsProcessorSettings Settings; // Offset: 0xd0 // Size: 0x50

	// Functions

	// Object Name: Function AudioMixer.SubmixEffectDynamicsProcessorPreset.SetSettings
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetSettings(struct FSubmixEffectDynamicsProcessorSettings& Settings); // Offset: 0x104330aa8 // Return & Params: Num(1) Size(0x50)

	// Object Name: Function AudioMixer.SubmixEffectDynamicsProcessorPreset.SetExternalSubmix
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetExternalSubmix(struct USoundSubmix* Submix); // Offset: 0x104330b90 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class AudioMixer.SubmixEffectSubmixEQPreset
// Size: 0xa0 // Inherited bytes: 0x40
struct USubmixEffectSubmixEQPreset : USoundEffectSubmixPreset {
	// Fields
	char pad_0x40[0x50]; // Offset: 0x40 // Size: 0x50
	struct FSubmixEffectSubmixEQSettings Settings; // Offset: 0x90 // Size: 0x10

	// Functions

	// Object Name: Function AudioMixer.SubmixEffectSubmixEQPreset.SetSettings
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetSettings(struct FSubmixEffectSubmixEQSettings& InSettings); // Offset: 0x1043311ac // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class AudioMixer.SubmixEffectReverbPreset
// Size: 0xe8 // Inherited bytes: 0x40
struct USubmixEffectReverbPreset : USoundEffectSubmixPreset {
	// Fields
	char pad_0x40[0x74]; // Offset: 0x40 // Size: 0x74
	struct FSubmixEffectReverbSettings Settings; // Offset: 0xb4 // Size: 0x34

	// Functions

	// Object Name: Function AudioMixer.SubmixEffectReverbPreset.SetSettingsWithReverbEffect
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSettingsWithReverbEffect(struct UReverbEffect* InReverbEffect, float WetLevel, float DryLevel); // Offset: 0x1043315e8 // Return & Params: Num(3) Size(0x10)

	// Object Name: Function AudioMixer.SubmixEffectReverbPreset.SetSettings
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetSettings(struct FSubmixEffectReverbSettings& InSettings); // Offset: 0x1043316fc // Return & Params: Num(1) Size(0x34)
};

// Object Name: Class AudioMixer.SubmixEffectReverbFastPreset
// Size: 0xf0 // Inherited bytes: 0x40
struct USubmixEffectReverbFastPreset : USoundEffectSubmixPreset {
	// Fields
	char pad_0x40[0x78]; // Offset: 0x40 // Size: 0x78
	struct FSubmixEffectReverbFastSettings Settings; // Offset: 0xb8 // Size: 0x38

	// Functions

	// Object Name: Function AudioMixer.SubmixEffectReverbFastPreset.SetSettingsWithReverbEffect
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSettingsWithReverbEffect(struct UReverbEffect* InReverbEffect, float WetLevel, float DryLevel); // Offset: 0x104331be4 // Return & Params: Num(3) Size(0x10)

	// Object Name: Function AudioMixer.SubmixEffectReverbFastPreset.SetSettings
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetSettings(struct FSubmixEffectReverbFastSettings& InSettings); // Offset: 0x104331cf8 // Return & Params: Num(1) Size(0x38)
};

// Object Name: Class AudioMixer.SynthSound
// Size: 0x390 // Inherited bytes: 0x370
struct USynthSound : USoundWaveProcedural {
	// Fields
	struct USynthComponent* OwningSynthComponent; // Offset: 0x370 // Size: 0x08
	char pad_0x378[0x18]; // Offset: 0x378 // Size: 0x18
};

