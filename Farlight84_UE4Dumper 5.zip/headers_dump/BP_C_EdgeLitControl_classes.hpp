#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_C_EdgeLitControl.BP_C_EdgeLitControl_C
// Size: 0x260 // Inherited bytes: 0x228
struct ABP_C_EdgeLitControl_C : AActor {
	// Fields
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x228 // Size: 0x08
	struct FLinearColor LightColor1; // Offset: 0x230 // Size: 0x10
	struct FLinearColor LightColor2; // Offset: 0x240 // Size: 0x10
	struct FLinearColor LightColor3; // Offset: 0x250 // Size: 0x10

	// Functions

	// Object Name: Function BP_C_EdgeLitControl.BP_C_EdgeLitControl_C.UserConstructionScript
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void UserConstructionScript(); // Offset: 0x1032a8510 // Return & Params: Num(0) Size(0x0)
};

