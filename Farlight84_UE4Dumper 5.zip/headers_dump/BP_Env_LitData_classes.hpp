#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_Env_LitData.BP_Env_LitData_C
// Size: 0x330 // Inherited bytes: 0x228
struct ABP_Env_LitData_C : AActor {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x228 // Size: 0x08
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x230 // Size: 0x08
	struct ASkyLight* SkyLight; // Offset: 0x238 // Size: 0x08
	struct ADirectionalLight* DirectionalLight; // Offset: 0x240 // Size: 0x08
	struct FStr_LightData LocalLightData; // Offset: 0x248 // Size: 0x70
	struct TMap<struct FString, struct FStr_LightData> LightDatas; // Offset: 0x2b8 // Size: 0x50
	struct ABP_C_EdgeLitControl_C* CharacterEdgeLitControl; // Offset: 0x308 // Size: 0x08
	struct ASkyLight* NewVar_1; // Offset: 0x310 // Size: 0x08
	bool bUseDefaultLight; // Offset: 0x318 // Size: 0x01
	char pad_0x319[0x7]; // Offset: 0x319 // Size: 0x07
	struct FString CurrentLightDataKey; // Offset: 0x320 // Size: 0x10

	// Functions

	// Object Name: Function BP_Env_LitData.BP_Env_LitData_C.Toggle Env Lighting
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void Toggle Env Lighting(bool bUseDefaultLight); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function BP_Env_LitData.BP_Env_LitData_C.SetEdgeLightSetting
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetEdgeLightSetting(struct FStr_EdgeLightSetting EdgeLightSetting); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x30)

	// Object Name: Function BP_Env_LitData.BP_Env_LitData_C.Add or Set Light Data Element
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void Add or Set Light Data Element(struct FString& Key); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function BP_Env_LitData.BP_Env_LitData_C.LoadSceneLightData
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void LoadSceneLightData(struct FString& Key); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function BP_Env_LitData.BP_Env_LitData_C.MakeLightData
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void MakeLightData(); // Offset: 0x1032a8510 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_Env_LitData.BP_Env_LitData_C.SaveLightData
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SaveLightData(); // Offset: 0x1032a8510 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_Env_LitData.BP_Env_LitData_C.LoadLightData
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void LoadLightData(); // Offset: 0x1032a8510 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_Env_LitData.BP_Env_LitData_C.SetDirectionalLightSetting
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void SetDirectionalLightSetting(struct ADirectionalLight* DirectionalLight, struct FStr_DirectionalLightSetting& Str_DirectionalLightSetting); // Offset: 0x1032a8510 // Return & Params: Num(2) Size(0x40)

	// Object Name: Function BP_Env_LitData.BP_Env_LitData_C.SetSkyLightSetting
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void SetSkyLightSetting(struct ASkyLight* SkyLight, struct FStr_SkyLightSetting& Str_SkyLightSetting); // Offset: 0x1032a8510 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function BP_Env_LitData.BP_Env_LitData_C.ReceiveBeginPlay
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveBeginPlay(); // Offset: 0x1032a8510 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_Env_LitData.BP_Env_LitData_C.ExecuteUbergraph_BP_Env_LitData
	// Flags: [Final|UbergraphFunction|HasDefaults]
	void ExecuteUbergraph_BP_Env_LitData(int32_t EntryPoint); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x4)
};

