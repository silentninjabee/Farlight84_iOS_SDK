#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_PBagsTrail_Common.BP_PBagsTrail_Common_C
// Size: 0x2c0 // Inherited bytes: 0x280
struct ABP_PBagsTrail_Common_C : ASolarBackpackSFX {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x280 // Size: 0x08
	struct UParticleSystemComponent* FX_PowerBag_WallRunLoop; // Offset: 0x288 // Size: 0x08
	struct UParticleSystemComponent* FX_PowerBag_Trail; // Offset: 0x290 // Size: 0x08
	struct UParticleSystemComponent* FX_PowerBag_DropSlowDown; // Offset: 0x298 // Size: 0x08
	struct UParticleSystemComponent* FX_PowerBag_SkyDivingLanding; // Offset: 0x2a0 // Size: 0x08
	struct USceneComponent* VFX; // Offset: 0x2a8 // Size: 0x08
	float TrailFade_Size_581709C845BD673DB0841C82710F99F1; // Offset: 0x2b0 // Size: 0x04
	enum class ETimelineDirection TrailFade__Direction_581709C845BD673DB0841C82710F99F1; // Offset: 0x2b4 // Size: 0x01
	char pad_0x2B5[0x3]; // Offset: 0x2b5 // Size: 0x03
	struct UTimelineComponent* TrailFade; // Offset: 0x2b8 // Size: 0x08

	// Functions

	// Object Name: Function BP_PBagsTrail_Common.BP_PBagsTrail_Common_C.OnWallRun
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void OnWallRun(); // Offset: 0x1032a8510 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_PBagsTrail_Common.BP_PBagsTrail_Common_C.BackpackSFXEnd
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void BackpackSFXEnd(); // Offset: 0x1032a8510 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_PBagsTrail_Common.BP_PBagsTrail_Common_C.BackpackSFXLaunch
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void BackpackSFXLaunch(bool GroundDetected, struct FVector& GroundLocation, struct FVector& GroundNormal); // Offset: 0x1032a8510 // Return & Params: Num(3) Size(0x1c)

	// Object Name: Function BP_PBagsTrail_Common.BP_PBagsTrail_Common_C.BackpackSFXBegin
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void BackpackSFXBegin(enum class EFXJetType InJetType, bool GroundDetected); // Offset: 0x1032a8510 // Return & Params: Num(2) Size(0x2)

	// Object Name: Function BP_PBagsTrail_Common.BP_PBagsTrail_Common_C.UpdateTrailParticle
	// Flags: [Protected|BlueprintCallable|BlueprintEvent]
	void UpdateTrailParticle(struct FBackpackTrailAssemblingParams SoftObjectRef); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0xa8)

	// Object Name: Function BP_PBagsTrail_Common.BP_PBagsTrail_Common_C.GetTrailEffectComponent
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	struct UParticleSystemComponent* GetTrailEffectComponent(); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function BP_PBagsTrail_Common.BP_PBagsTrail_Common_C.FX_FinishDeactive
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void FX_FinishDeactive(); // Offset: 0x1032a8510 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_PBagsTrail_Common.BP_PBagsTrail_Common_C.SkyDivingLanding
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SkyDivingLanding(); // Offset: 0x1032a8510 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_PBagsTrail_Common.BP_PBagsTrail_Common_C.DropSlowDown
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void DropSlowDown(); // Offset: 0x1032a8510 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_PBagsTrail_Common.BP_PBagsTrail_Common_C.Normal Jet Fly
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void Normal Jet Fly(); // Offset: 0x1032a8510 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_PBagsTrail_Common.BP_PBagsTrail_Common_C.FX_InitializeDeactive
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void FX_InitializeDeactive(); // Offset: 0x1032a8510 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_PBagsTrail_Common.BP_PBagsTrail_Common_C.TrailFade__FinishedFunc
	// Flags: [BlueprintEvent]
	void TrailFade__FinishedFunc(); // Offset: 0x1032a8510 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_PBagsTrail_Common.BP_PBagsTrail_Common_C.TrailFade__UpdateFunc
	// Flags: [BlueprintEvent]
	void TrailFade__UpdateFunc(); // Offset: 0x1032a8510 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_PBagsTrail_Common.BP_PBagsTrail_Common_C.OnBackpackTrailAssembling
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	void OnBackpackTrailAssembling(struct FBackpackTrailAssemblingParams& Params, enum class EBackpackPropellingMode PropellingMode); // Offset: 0x1032a8510 // Return & Params: Num(2) Size(0xa9)

	// Object Name: Function BP_PBagsTrail_Common.BP_PBagsTrail_Common_C.TryFadeOutTrail
	// Flags: [BlueprintCallable|BlueprintEvent]
	void TryFadeOutTrail(); // Offset: 0x1032a8510 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_PBagsTrail_Common.BP_PBagsTrail_Common_C.ExecuteUbergraph_BP_PBagsTrail_Common
	// Flags: [Final|UbergraphFunction|HasDefaults]
	void ExecuteUbergraph_BP_PBagsTrail_Common(int32_t EntryPoint); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x4)
};

