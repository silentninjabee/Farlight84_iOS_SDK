#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_QuickSummon_FootDown.BP_QuickSummon_FootDown_C
// Size: 0x30 // Inherited bytes: 0x28
struct UBP_QuickSummon_FootDown_C : USolarQuickSummonProxy {
	// Fields
	float UpHeight; // Offset: 0x28 // Size: 0x04
	float DownHeight; // Offset: 0x2c // Size: 0x04

	// Functions

	// Object Name: Function BP_QuickSummon_FootDown.BP_QuickSummon_FootDown_C.TryGetSummonHitResult
	// Flags: [Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	bool TryGetSummonHitResult(struct FHitResult& OutHitResult, struct AActor* InSummoner, struct USolarSummonDetectionConfig* InSummonConfig); // Offset: 0x1032a8510 // Return & Params: Num(4) Size(0x99)
};

