#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_SettlementStageMgr.BP_SettlementStageMgr_C
// Size: 0x50 // Inherited bytes: 0x50
struct UBP_SettlementStageMgr_C : USettlementStageManager {
};

