#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_SolarGraphicSettings.BP_SolarGraphicSettings_C
// Size: 0x2e8 // Inherited bytes: 0x2e8
struct UBP_SolarGraphicSettings_C : USolarGraphicSettings {
};

