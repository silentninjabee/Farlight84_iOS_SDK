#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_SolarLobbyCharacter.BP_SolarLobbyCharacter_C
// Size: 0x448 // Inherited bytes: 0x438
struct ABP_SolarLobbyCharacter_C : ASolarLobbyCharacter {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x438 // Size: 0x08
	struct UMediaSoundComponent* MediaSound; // Offset: 0x440 // Size: 0x08

	// Functions

	// Object Name: Function BP_SolarLobbyCharacter.BP_SolarLobbyCharacter_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	struct FString GetModuleName(); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function BP_SolarLobbyCharacter.BP_SolarLobbyCharacter_C.ReceiveBeginPlay
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveBeginPlay(); // Offset: 0x1032a8510 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_SolarLobbyCharacter.BP_SolarLobbyCharacter_C.ExecuteUbergraph_BP_SolarLobbyCharacter
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_BP_SolarLobbyCharacter(int32_t EntryPoint); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x4)
};

