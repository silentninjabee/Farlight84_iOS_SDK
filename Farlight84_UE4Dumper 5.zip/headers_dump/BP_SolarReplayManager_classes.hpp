#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_SolarReplayManager.BP_SolarReplayManager_C
// Size: 0x490 // Inherited bytes: 0x490
struct UBP_SolarReplayManager_C : USolarReplayManager {
};

