#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_WAT_RocketLauncher.BP_WAT_RocketLauncher_C
// Size: 0xf8 // Inherited bytes: 0xf8
struct UBP_WAT_RocketLauncher_C : USolarWeaponAT_FireRocket {
};

