#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Btn_Unlock_Anim_3.Btn_Unlock_Anim_2_C
// Size: 0x380 // Inherited bytes: 0x348
struct UBtn_Unlock_Anim_2_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x348 // Size: 0x08
	struct UWidgetAnimation* Anim_Unlock; // Offset: 0x350 // Size: 0x08
	struct UButton* Btn_Locked; // Offset: 0x358 // Size: 0x08
	struct FMulticastInlineDelegate OnAnimStarted; // Offset: 0x360 // Size: 0x10
	struct FMulticastInlineDelegate OnAnimEnded; // Offset: 0x370 // Size: 0x10

	// Functions

	// Object Name: Function Btn_Unlock_Anim_3.Btn_Unlock_Anim_2_C.OnAnimStart
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnAnimStart(); // Offset: 0x1032a8510 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Btn_Unlock_Anim_3.Btn_Unlock_Anim_2_C.OnAnimEnd
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnAnimEnd(); // Offset: 0x1032a8510 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Btn_Unlock_Anim_3.Btn_Unlock_Anim_2_C.ExecuteUbergraph_Btn_Unlock_Anim_3
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_Btn_Unlock_Anim_3(int32_t EntryPoint); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Btn_Unlock_Anim_3.Btn_Unlock_Anim_2_C.OnAnimEnded__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void OnAnimEnded__DelegateSignature(); // Offset: 0x1032a8510 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Btn_Unlock_Anim_3.Btn_Unlock_Anim_2_C.OnAnimStarted__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void OnAnimStarted__DelegateSignature(); // Offset: 0x1032a8510 // Return & Params: Num(0) Size(0x0)
};

