#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass ChaGABP_CancelSkill_EMP.ChaGABP_CancelSkill_EMP_C
// Size: 0x410 // Inherited bytes: 0x410
struct UChaGABP_CancelSkill_EMP_C : USolarGameplayAbility {
};

