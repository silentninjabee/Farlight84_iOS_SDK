#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct ChaosSolverEngine.ChaosPhysicsCollisionInfo
// Size: 0x70 // Inherited bytes: 0x00
struct FChaosPhysicsCollisionInfo {
	// Fields
	struct UPrimitiveComponent* Component; // Offset: 0x00 // Size: 0x08
	struct UPrimitiveComponent* OtherComponent; // Offset: 0x08 // Size: 0x08
	struct FVector Location; // Offset: 0x10 // Size: 0x0c
	struct FVector Normal; // Offset: 0x1c // Size: 0x0c
	struct FVector AccumulatedImpulse; // Offset: 0x28 // Size: 0x0c
	struct FVector Velocity; // Offset: 0x34 // Size: 0x0c
	struct FVector OtherVelocity; // Offset: 0x40 // Size: 0x0c
	struct FVector AngularVelocity; // Offset: 0x4c // Size: 0x0c
	struct FVector OtherAngularVelocity; // Offset: 0x58 // Size: 0x0c
	float Mass; // Offset: 0x64 // Size: 0x04
	float OtherMass; // Offset: 0x68 // Size: 0x04
	char pad_0x6C[0x4]; // Offset: 0x6c // Size: 0x04
};

// Object Name: ScriptStruct ChaosSolverEngine.ChaosBreakEvent
// Size: 0x30 // Inherited bytes: 0x00
struct FChaosBreakEvent {
	// Fields
	struct UPrimitiveComponent* Component; // Offset: 0x00 // Size: 0x08
	struct FVector Location; // Offset: 0x08 // Size: 0x0c
	struct FVector Velocity; // Offset: 0x14 // Size: 0x0c
	struct FVector AngularVelocity; // Offset: 0x20 // Size: 0x0c
	float Mass; // Offset: 0x2c // Size: 0x04
};

// Object Name: ScriptStruct ChaosSolverEngine.ChaosHandlerSet
// Size: 0x58 // Inherited bytes: 0x00
struct FChaosHandlerSet {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
	struct TSet<struct UObject*> ChaosHandlers; // Offset: 0x08 // Size: 0x50
};

// Object Name: ScriptStruct ChaosSolverEngine.BreakEventCallbackWrapper
// Size: 0x40 // Inherited bytes: 0x00
struct FBreakEventCallbackWrapper {
	// Fields
	char pad_0x0[0x40]; // Offset: 0x00 // Size: 0x40
};

// Object Name: ScriptStruct ChaosSolverEngine.ChaosDebugSubstepControl
// Size: 0x03 // Inherited bytes: 0x00
struct FChaosDebugSubstepControl {
	// Fields
	bool bPause; // Offset: 0x00 // Size: 0x01
	bool bSubstep; // Offset: 0x01 // Size: 0x01
	bool bStep; // Offset: 0x02 // Size: 0x01
};

