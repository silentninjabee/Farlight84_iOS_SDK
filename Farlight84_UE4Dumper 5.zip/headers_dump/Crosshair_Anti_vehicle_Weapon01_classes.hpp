#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Crosshair_Anti-vehicle_Weapon01.Crosshair_Anti-vehicle_Weapon01_C
// Size: 0x348 // Inherited bytes: 0x300
struct UCrosshair_Anti-vehicle_Weapon01_C : UCrossHairWidget {
	// Fields
	struct UImage* ForbidImg; // Offset: 0x300 // Size: 0x08
	struct UImage* Image_243; // Offset: 0x308 // Size: 0x08
	struct UImage* OverloadImg2; // Offset: 0x310 // Size: 0x08
	struct UWidgetTween_C* OverloadNormalPanel_Tween; // Offset: 0x318 // Size: 0x08
	struct UImage* OverloadProgressBar_BG_2; // Offset: 0x320 // Size: 0x08
	struct UImage* OverloadProgressBar_BG_3; // Offset: 0x328 // Size: 0x08
	struct UProgressBar* OverloadProgressBarNormal; // Offset: 0x330 // Size: 0x08
	struct UProgressBar* OverloadProgressBarWarn; // Offset: 0x338 // Size: 0x08
	struct UImage* SpreadImg_coredot; // Offset: 0x340 // Size: 0x08
};

