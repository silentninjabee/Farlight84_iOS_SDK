#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Crosshair_CarWeapon_Cannon_New.Crosshair_CarWeapon_Cannon_New_C
// Size: 0x4b0 // Inherited bytes: 0x488
struct UCrosshair_CarWeapon_Cannon_New_C : UVehicleWeaponCrossHairWidget {
	// Fields
	struct UWidgetAnimation* Anim_CD_Out; // Offset: 0x488 // Size: 0x08
	struct UWidgetAnimation* Anim_CD_Enter; // Offset: 0x490 // Size: 0x08
	struct UCanvasPanel* Canvas_Dynamic; // Offset: 0x498 // Size: 0x08
	struct UImage* ReticleDirection; // Offset: 0x4a0 // Size: 0x08
	struct UImage* SpreadImg_coredot; // Offset: 0x4a8 // Size: 0x08

	// Functions

	// Object Name: Function Crosshair_CarWeapon_Cannon_New.Crosshair_CarWeapon_Cannon_New_C.SetWidgetResources
	// Flags: [Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent]
	void SetWidgetResources(struct UCanvasPanel*& InSecondReticlePanel, struct UImage*& InReticleDirectionImage, struct UImage*& InRangedImage, struct USizeBox*& InAssistLockSizeBox, struct UCanvasPanel*& InChangeNewAssistLockPawnPanel, struct UCanvasPanel*& InEnterLockPawnPanel, struct UCanvasPanel*& InCanvas_Dynamic); // Offset: 0x1032a8510 // Return & Params: Num(7) Size(0x38)
};

