#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Crosshair_CarWeapon_Flame_New.Crosshair_CarWeapon_Flame_New_C
// Size: 0x4e9 // Inherited bytes: 0x488
struct UCrosshair_CarWeapon_Flame_New_C : UVehicleWeaponCrossHairWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x488 // Size: 0x08
	struct UWidgetAnimation* Overheat_Anim_Quit; // Offset: 0x490 // Size: 0x08
	struct UWidgetAnimation* Overheat_Anim_Enter; // Offset: 0x498 // Size: 0x08
	struct UCanvasPanel* Container_SecondReticle; // Offset: 0x4a0 // Size: 0x08
	struct UCanvasPanel* Coredot; // Offset: 0x4a8 // Size: 0x08
	struct UImage* img_normal; // Offset: 0x4b0 // Size: 0x08
	struct UImage* img_overload; // Offset: 0x4b8 // Size: 0x08
	struct UImage* Img_Overload_vx; // Offset: 0x4c0 // Size: 0x08
	struct UCanvasPanel* panel_overload; // Offset: 0x4c8 // Size: 0x08
	struct UImage* ReticleDirection; // Offset: 0x4d0 // Size: 0x08
	struct UImage* SpreadImg_coredot; // Offset: 0x4d8 // Size: 0x08
	struct UWidgetSwitcher* wgs_status; // Offset: 0x4e0 // Size: 0x08
	bool IsOverloading; // Offset: 0x4e8 // Size: 0x01

	// Functions

	// Object Name: Function Crosshair_CarWeapon_Flame_New.Crosshair_CarWeapon_Flame_New_C.OnOverloadChanged
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void OnOverloadChanged(bool InOverload); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Crosshair_CarWeapon_Flame_New.Crosshair_CarWeapon_Flame_New_C.SetWidgetResources
	// Flags: [Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent]
	void SetWidgetResources(struct UCanvasPanel*& InSecondReticlePanel, struct UImage*& InReticleDirectionImage, struct UImage*& InRangedImage, struct USizeBox*& InAssistLockSizeBox, struct UCanvasPanel*& InChangeNewAssistLockPawnPanel, struct UCanvasPanel*& InEnterLockPawnPanel, struct UCanvasPanel*& InCanvas_Dynamic); // Offset: 0x1032a8510 // Return & Params: Num(7) Size(0x38)

	// Object Name: Function Crosshair_CarWeapon_Flame_New.Crosshair_CarWeapon_Flame_New_C.OnOverloadStateChanged
	// Flags: [Event|Protected|BlueprintEvent]
	void OnOverloadStateChanged(bool bEnter); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Crosshair_CarWeapon_Flame_New.Crosshair_CarWeapon_Flame_New_C.OnAnimationFinished
	// Flags: [BlueprintCosmetic|Event|Protected|BlueprintEvent]
	void OnAnimationFinished(struct UWidgetAnimation* Animation); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Crosshair_CarWeapon_Flame_New.Crosshair_CarWeapon_Flame_New_C.OnCrosshairInNormalState
	// Flags: [Event|Protected|BlueprintEvent]
	void OnCrosshairInNormalState(); // Offset: 0x1032a8510 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Crosshair_CarWeapon_Flame_New.Crosshair_CarWeapon_Flame_New_C.ExecuteUbergraph_Crosshair_CarWeapon_Flame_New
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_Crosshair_CarWeapon_Flame_New(int32_t EntryPoint); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x4)
};

