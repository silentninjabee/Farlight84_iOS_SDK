#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Crosshair_CarWeapon_Gatling.Crosshair_CarWeapon_Gatling_C
// Size: 0x4b9 // Inherited bytes: 0x488
struct UCrosshair_CarWeapon_Gatling_C : UVehicleWeaponCrossHairWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x488 // Size: 0x08
	struct UCanvasPanel* Coredot; // Offset: 0x490 // Size: 0x08
	struct UCanvasPanel* SpreadCanvasPanel; // Offset: 0x498 // Size: 0x08
	struct UImage* SpreadImg_coredot; // Offset: 0x4a0 // Size: 0x08
	struct UImage* SpreadImg_Leftarrow_2; // Offset: 0x4a8 // Size: 0x08
	struct UImage* SpreadImg_Rightarrow_2; // Offset: 0x4b0 // Size: 0x08
	bool NewlyControlled; // Offset: 0x4b8 // Size: 0x01

	// Functions

	// Object Name: Function Crosshair_CarWeapon_Gatling.Crosshair_CarWeapon_Gatling_C.OnCrosshairInNormalState
	// Flags: [Event|Protected|BlueprintEvent]
	void OnCrosshairInNormalState(); // Offset: 0x1032a8510 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Crosshair_CarWeapon_Gatling.Crosshair_CarWeapon_Gatling_C.OnUpdateGatlingRoll
	// Flags: [Event|Protected|BlueprintEvent]
	void OnUpdateGatlingRoll(float DeltaTmie, float InRollSpeedInterp, bool bWantFire); // Offset: 0x1032a8510 // Return & Params: Num(3) Size(0x9)

	// Object Name: Function Crosshair_CarWeapon_Gatling.Crosshair_CarWeapon_Gatling_C.Tick
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Offset: 0x1032a8510 // Return & Params: Num(2) Size(0x3c)

	// Object Name: Function Crosshair_CarWeapon_Gatling.Crosshair_CarWeapon_Gatling_C.ExecuteUbergraph_Crosshair_CarWeapon_Gatling
	// Flags: [Final|UbergraphFunction|HasDefaults]
	void ExecuteUbergraph_Crosshair_CarWeapon_Gatling(int32_t EntryPoint); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x4)
};

