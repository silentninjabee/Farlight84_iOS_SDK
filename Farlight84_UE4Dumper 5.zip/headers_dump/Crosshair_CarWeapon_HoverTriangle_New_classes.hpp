#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Crosshair_CarWeapon_HoverTriangle_New.Crosshair_CarWeapon_HoverTriangle_New_C
// Size: 0x4cc // Inherited bytes: 0x488
struct UCrosshair_CarWeapon_HoverTriangle_New_C : UVehicleWeaponCrossHairWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x488 // Size: 0x08
	struct UWidgetAnimation* Anim_Overheat; // Offset: 0x490 // Size: 0x08
	struct UWidgetAnimation* Anim_Shoot; // Offset: 0x498 // Size: 0x08
	struct UCanvasPanel* Container_SecondReticle; // Offset: 0x4a0 // Size: 0x08
	struct UCanvasPanel* Coredot; // Offset: 0x4a8 // Size: 0x08
	struct UImage* ReticleDirection; // Offset: 0x4b0 // Size: 0x08
	struct UImage* SpreadImg_coredot; // Offset: 0x4b8 // Size: 0x08
	struct UImage* SpreadImg_coredot_2; // Offset: 0x4c0 // Size: 0x08
	int32_t FireCounter; // Offset: 0x4c8 // Size: 0x04

	// Functions

	// Object Name: Function Crosshair_CarWeapon_HoverTriangle_New.Crosshair_CarWeapon_HoverTriangle_New_C.GetOverloadWidget
	// Flags: [Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent]
	struct UUserWidget* GetOverloadWidget(); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Crosshair_CarWeapon_HoverTriangle_New.Crosshair_CarWeapon_HoverTriangle_New_C.GetAmmoWidget
	// Flags: [Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent]
	struct UUserWidget* GetAmmoWidget(); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Crosshair_CarWeapon_HoverTriangle_New.Crosshair_CarWeapon_HoverTriangle_New_C.GetReloadWidget
	// Flags: [Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent]
	struct UUserWidget* GetReloadWidget(); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Crosshair_CarWeapon_HoverTriangle_New.Crosshair_CarWeapon_HoverTriangle_New_C.SetWidgetResources
	// Flags: [Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent]
	void SetWidgetResources(struct UCanvasPanel*& InSecondReticlePanel, struct UImage*& InReticleDirectionImage, struct UImage*& InRangedImage, struct USizeBox*& InAssistLockSizeBox, struct UCanvasPanel*& InChangeNewAssistLockPawnPanel, struct UCanvasPanel*& InEnterLockPawnPanel, struct UCanvasPanel*& InCanvas_Dynamic); // Offset: 0x1032a8510 // Return & Params: Num(7) Size(0x38)

	// Object Name: Function Crosshair_CarWeapon_HoverTriangle_New.Crosshair_CarWeapon_HoverTriangle_New_C.OnWeaponFired
	// Flags: [Event|Protected|BlueprintEvent]
	void OnWeaponFired(); // Offset: 0x1032a8510 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Crosshair_CarWeapon_HoverTriangle_New.Crosshair_CarWeapon_HoverTriangle_New_C.OnOverloadStateChanged
	// Flags: [Event|Protected|BlueprintEvent]
	void OnOverloadStateChanged(bool bEnter); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Crosshair_CarWeapon_HoverTriangle_New.Crosshair_CarWeapon_HoverTriangle_New_C.ExecuteUbergraph_Crosshair_CarWeapon_HoverTriangle_New
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_Crosshair_CarWeapon_HoverTriangle_New(int32_t EntryPoint); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x4)
};

