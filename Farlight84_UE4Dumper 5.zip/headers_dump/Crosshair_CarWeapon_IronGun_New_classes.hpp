#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Crosshair_CarWeapon_IronGun_New.Crosshair_CarWeapon_IronGun_New_C
// Size: 0x545 // Inherited bytes: 0x488
struct UCrosshair_CarWeapon_IronGun_New_C : UVehicleWeaponCrossHairWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x488 // Size: 0x08
	struct UWidgetAnimation* Anim_1; // Offset: 0x490 // Size: 0x08
	struct UWidgetAnimation* Anim_5; // Offset: 0x498 // Size: 0x08
	struct UWidgetAnimation* Anim_4; // Offset: 0x4a0 // Size: 0x08
	struct UWidgetAnimation* Anim_3; // Offset: 0x4a8 // Size: 0x08
	struct UWidgetAnimation* Anim_2; // Offset: 0x4b0 // Size: 0x08
	struct UWidgetAnimation* Anim_Fullcharge; // Offset: 0x4b8 // Size: 0x08
	struct UProgressBar* bar_crosshair_2; // Offset: 0x4c0 // Size: 0x08
	struct UProgressBar* bar_crosshair_3; // Offset: 0x4c8 // Size: 0x08
	struct UProgressBar* bar_crosshair_4; // Offset: 0x4d0 // Size: 0x08
	struct UCanvasPanel* Container_SecondReticle; // Offset: 0x4d8 // Size: 0x08
	struct UCanvasPanel* Coredot; // Offset: 0x4e0 // Size: 0x08
	struct UImage* Img_Glow; // Offset: 0x4e8 // Size: 0x08
	struct USolarImage* img_round_l; // Offset: 0x4f0 // Size: 0x08
	struct USolarImage* img_round_r; // Offset: 0x4f8 // Size: 0x08
	struct USolarImage* img_round_t; // Offset: 0x500 // Size: 0x08
	struct UImageTween_C* ReloadImg_Tween; // Offset: 0x508 // Size: 0x08
	struct UImage* ReticleDirection; // Offset: 0x510 // Size: 0x08
	struct UImage* SpreadImg_coredot; // Offset: 0x518 // Size: 0x08
	struct UCanvasPanel* SpreadImg_coredot_2; // Offset: 0x520 // Size: 0x08
	struct UCanvasPanel* SpreadImg_coredot_3; // Offset: 0x528 // Size: 0x08
	struct UCanvasPanel* SpreadImg_coredot_4; // Offset: 0x530 // Size: 0x08
	int32_t LastChargeMode; // Offset: 0x538 // Size: 0x04
	bool bChargeFull; // Offset: 0x53c // Size: 0x01
	char pad_0x53D[0x3]; // Offset: 0x53d // Size: 0x03
	float MinlPercent; // Offset: 0x540 // Size: 0x04
	bool bLockedEnemy; // Offset: 0x544 // Size: 0x01

	// Functions

	// Object Name: Function Crosshair_CarWeapon_IronGun_New.Crosshair_CarWeapon_IronGun_New_C.ChangeProgressBarColor
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void ChangeProgressBarColor(struct UProgressBar* InProgressBar, struct FLinearColor InBackgroundColor, struct FLinearColor InFillImageColor); // Offset: 0x1032a8510 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function Crosshair_CarWeapon_IronGun_New.Crosshair_CarWeapon_IronGun_New_C.SetPrograssPrecent
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetPrograssPrecent(float Percent, int32_t Index, struct UProgressBar* InProgressBar); // Offset: 0x1032a8510 // Return & Params: Num(3) Size(0x10)

	// Object Name: Function Crosshair_CarWeapon_IronGun_New.Crosshair_CarWeapon_IronGun_New_C.GetChargeWidget
	// Flags: [Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent]
	struct UUserWidget* GetChargeWidget(); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Crosshair_CarWeapon_IronGun_New.Crosshair_CarWeapon_IronGun_New_C.SetWidgetResources
	// Flags: [Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent]
	void SetWidgetResources(struct UCanvasPanel*& InSecondReticlePanel, struct UImage*& InReticleDirectionImage, struct UImage*& InRangedImage, struct USizeBox*& InAssistLockSizeBox, struct UCanvasPanel*& InChangeNewAssistLockPawnPanel, struct UCanvasPanel*& InEnterLockPawnPanel, struct UCanvasPanel*& InCanvas_Dynamic); // Offset: 0x1032a8510 // Return & Params: Num(7) Size(0x38)

	// Object Name: Function Crosshair_CarWeapon_IronGun_New.Crosshair_CarWeapon_IronGun_New_C.OnUpdateChargeProgress
	// Flags: [Event|Protected|BlueprintEvent]
	void OnUpdateChargeProgress(bool InbCharging, int32_t InChargeMode, float InChargeProgress, int32_t InChargeBurstCount); // Offset: 0x1032a8510 // Return & Params: Num(4) Size(0x10)

	// Object Name: Function Crosshair_CarWeapon_IronGun_New.Crosshair_CarWeapon_IronGun_New_C.OnUpdateAimState
	// Flags: [Event|Protected|BlueprintEvent]
	void OnUpdateAimState(bool InbLockEnemy); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Crosshair_CarWeapon_IronGun_New.Crosshair_CarWeapon_IronGun_New_C.OnPlayWeaponSpecialFire
	// Flags: [Event|Protected|BlueprintEvent]
	void OnPlayWeaponSpecialFire(enum class ECrossHairSpecialFireState InState, float PlayRate); // Offset: 0x1032a8510 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Crosshair_CarWeapon_IronGun_New.Crosshair_CarWeapon_IronGun_New_C.OnCrosshairInNormalState
	// Flags: [Event|Protected|BlueprintEvent]
	void OnCrosshairInNormalState(); // Offset: 0x1032a8510 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Crosshair_CarWeapon_IronGun_New.Crosshair_CarWeapon_IronGun_New_C.ExecuteUbergraph_Crosshair_CarWeapon_IronGun_New
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_Crosshair_CarWeapon_IronGun_New(int32_t EntryPoint); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x4)
};

