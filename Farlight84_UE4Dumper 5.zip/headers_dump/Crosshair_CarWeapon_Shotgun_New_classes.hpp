#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Crosshair_CarWeapon_Shotgun_New.Crosshair_CarWeapon_Shotgun_New_C
// Size: 0x514 // Inherited bytes: 0x488
struct UCrosshair_CarWeapon_Shotgun_New_C : UVehicleWeaponCrossHairWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x488 // Size: 0x08
	struct UWidgetAnimation* Anim_Reload; // Offset: 0x490 // Size: 0x08
	struct UImage* bullet_l; // Offset: 0x498 // Size: 0x08
	struct UImage* bullet_r; // Offset: 0x4a0 // Size: 0x08
	struct UCanvasPanel* Container_SecondReticle; // Offset: 0x4a8 // Size: 0x08
	struct UCanvasPanel* Coredot; // Offset: 0x4b0 // Size: 0x08
	struct UCanvasPanel* panel_bottom; // Offset: 0x4b8 // Size: 0x08
	struct UCanvasPanel* Panel_Left; // Offset: 0x4c0 // Size: 0x08
	struct UCanvasPanel* Panel_Reload; // Offset: 0x4c8 // Size: 0x08
	struct UCanvasPanel* Panel_Right; // Offset: 0x4d0 // Size: 0x08
	struct UCanvasPanel* panel_top; // Offset: 0x4d8 // Size: 0x08
	struct UImage* ReticleDirection; // Offset: 0x4e0 // Size: 0x08
	struct UImage* SpreadImg_coredot; // Offset: 0x4e8 // Size: 0x08
	struct UImage* SpreadImg_coredot_l; // Offset: 0x4f0 // Size: 0x08
	struct UImage* SpreadImg_coredot_l_2; // Offset: 0x4f8 // Size: 0x08
	struct UImage* SpreadImg_coredot_r; // Offset: 0x500 // Size: 0x08
	struct UImage* SpreadImg_coredot_r_2; // Offset: 0x508 // Size: 0x08
	int32_t LastAmmoCount; // Offset: 0x510 // Size: 0x04

	// Functions

	// Object Name: Function Crosshair_CarWeapon_Shotgun_New.Crosshair_CarWeapon_Shotgun_New_C.ChangeAmmoCount
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void ChangeAmmoCount(int32_t ReloadCount, int32_t AmmoCount); // Offset: 0x1032a8510 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Crosshair_CarWeapon_Shotgun_New.Crosshair_CarWeapon_Shotgun_New_C.SetWidgetResources
	// Flags: [Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent]
	void SetWidgetResources(struct UCanvasPanel*& InSecondReticlePanel, struct UImage*& InReticleDirectionImage, struct UImage*& InRangedImage, struct USizeBox*& InAssistLockSizeBox, struct UCanvasPanel*& InChangeNewAssistLockPawnPanel, struct UCanvasPanel*& InEnterLockPawnPanel, struct UCanvasPanel*& InCanvas_Dynamic); // Offset: 0x1032a8510 // Return & Params: Num(7) Size(0x38)

	// Object Name: Function Crosshair_CarWeapon_Shotgun_New.Crosshair_CarWeapon_Shotgun_New_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Construct(); // Offset: 0x1032a8510 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Crosshair_CarWeapon_Shotgun_New.Crosshair_CarWeapon_Shotgun_New_C.OnAmmoChanged
	// Flags: [Event|Protected|BlueprintEvent]
	void OnAmmoChanged(int32_t InReservedAmmo, int32_t InMaxAmmo, bool InbFirst); // Offset: 0x1032a8510 // Return & Params: Num(3) Size(0x9)

	// Object Name: Function Crosshair_CarWeapon_Shotgun_New.Crosshair_CarWeapon_Shotgun_New_C.OnReloadStarted
	// Flags: [Event|Protected|BlueprintEvent]
	void OnReloadStarted(float InReloadTime, int32_t InReservedAmmo); // Offset: 0x1032a8510 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Crosshair_CarWeapon_Shotgun_New.Crosshair_CarWeapon_Shotgun_New_C.OnReloadFinished
	// Flags: [Event|Protected|BlueprintEvent]
	void OnReloadFinished(bool InbReloadSuccess, int32_t InReloadAmmo, int32_t InReservedAmmo, int32_t InMaxAmmo); // Offset: 0x1032a8510 // Return & Params: Num(4) Size(0x10)

	// Object Name: Function Crosshair_CarWeapon_Shotgun_New.Crosshair_CarWeapon_Shotgun_New_C.ExecuteUbergraph_Crosshair_CarWeapon_Shotgun_New
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_Crosshair_CarWeapon_Shotgun_New(int32_t EntryPoint); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x4)
};

