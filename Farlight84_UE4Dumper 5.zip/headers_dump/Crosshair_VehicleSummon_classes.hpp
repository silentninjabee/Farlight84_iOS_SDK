#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Crosshair_VehicleSummon.Crosshair_VehicleSummon_C
// Size: 0x328 // Inherited bytes: 0x300
struct UCrosshair_VehicleSummon_C : UCrossHairWidget {
	// Fields
	struct UImage* SpreadImg_coredot; // Offset: 0x300 // Size: 0x08
	struct UImage* SpreadImg_Downarrow; // Offset: 0x308 // Size: 0x08
	struct UImage* SpreadImg_Leftarrow; // Offset: 0x310 // Size: 0x08
	struct UImage* SpreadImg_Rightarrow; // Offset: 0x318 // Size: 0x08
	struct UImage* SpreadImg_uparrow; // Offset: 0x320 // Size: 0x08
};

