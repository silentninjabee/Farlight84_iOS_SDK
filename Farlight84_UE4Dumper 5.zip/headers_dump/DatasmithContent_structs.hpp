#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct DatasmithContent.DatasmithCameraLookatTrackingSettingsTemplate
// Size: 0x30 // Inherited bytes: 0x00
struct FDatasmithCameraLookatTrackingSettingsTemplate {
	// Fields
	char bEnableLookAtTracking : 1; // Offset: 0x00 // Size: 0x01
	char bAllowRoll : 1; // Offset: 0x00 // Size: 0x01
	char pad_0x0_2 : 6; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct TSoftObjectPtr<AActor> ActorToTrack; // Offset: 0x08 // Size: 0x28
};

// Object Name: ScriptStruct DatasmithContent.DatasmithPostProcessSettingsTemplate
// Size: 0x40 // Inherited bytes: 0x00
struct FDatasmithPostProcessSettingsTemplate {
	// Fields
	char bOverride_WhiteTemp : 1; // Offset: 0x00 // Size: 0x01
	char bOverride_ColorSaturation : 1; // Offset: 0x00 // Size: 0x01
	char bOverride_VignetteIntensity : 1; // Offset: 0x00 // Size: 0x01
	char bOverride_FilmWhitePoint : 1; // Offset: 0x00 // Size: 0x01
	char bOverride_AutoExposureMethod : 1; // Offset: 0x00 // Size: 0x01
	char bOverride_CameraISO : 1; // Offset: 0x00 // Size: 0x01
	char bOverride_CameraShutterSpeed : 1; // Offset: 0x00 // Size: 0x01
	char bOverride_DepthOfFieldFstop : 1; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float WhiteTemp; // Offset: 0x04 // Size: 0x04
	float VignetteIntensity; // Offset: 0x08 // Size: 0x04
	struct FLinearColor FilmWhitePoint; // Offset: 0x0c // Size: 0x10
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
	struct FVector4 ColorSaturation; // Offset: 0x20 // Size: 0x10
	enum class EAutoExposureMethod AutoExposureMethod; // Offset: 0x30 // Size: 0x01
	char pad_0x31[0x3]; // Offset: 0x31 // Size: 0x03
	float CameraISO; // Offset: 0x34 // Size: 0x04
	float CameraShutterSpeed; // Offset: 0x38 // Size: 0x04
	float DepthOfFieldFstop; // Offset: 0x3c // Size: 0x04
};

// Object Name: ScriptStruct DatasmithContent.DatasmithCameraFocusSettingsTemplate
// Size: 0x08 // Inherited bytes: 0x00
struct FDatasmithCameraFocusSettingsTemplate {
	// Fields
	enum class ECameraFocusMethod FocusMethod; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float ManualFocusDistance; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct DatasmithContent.DatasmithCameraLensSettingsTemplate
// Size: 0x04 // Inherited bytes: 0x00
struct FDatasmithCameraLensSettingsTemplate {
	// Fields
	float MaxFStop; // Offset: 0x00 // Size: 0x04
};

// Object Name: ScriptStruct DatasmithContent.DatasmithCameraFilmbackSettingsTemplate
// Size: 0x08 // Inherited bytes: 0x00
struct FDatasmithCameraFilmbackSettingsTemplate {
	// Fields
	float SensorWidth; // Offset: 0x00 // Size: 0x04
	float SensorHeight; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct DatasmithContent.DatasmithTessellationOptions
// Size: 0x10 // Inherited bytes: 0x00
struct FDatasmithTessellationOptions {
	// Fields
	float ChordTolerance; // Offset: 0x00 // Size: 0x04
	float MaxEdgeLength; // Offset: 0x04 // Size: 0x04
	float NormalTolerance; // Offset: 0x08 // Size: 0x04
	enum class EDatasmithCADStitchingTechnique StitchingTechnique; // Offset: 0x0c // Size: 0x01
	char pad_0xD[0x3]; // Offset: 0x0d // Size: 0x03
};

// Object Name: ScriptStruct DatasmithContent.DatasmithImportBaseOptions
// Size: 0x14 // Inherited bytes: 0x00
struct FDatasmithImportBaseOptions {
	// Fields
	enum class EDatasmithImportScene SceneHandling; // Offset: 0x00 // Size: 0x01
	bool bIncludeGeometry; // Offset: 0x01 // Size: 0x01
	bool bIncludeMaterial; // Offset: 0x02 // Size: 0x01
	bool bIncludeLight; // Offset: 0x03 // Size: 0x01
	bool bIncludeCamera; // Offset: 0x04 // Size: 0x01
	bool bIncludeAnimation; // Offset: 0x05 // Size: 0x01
	char pad_0x6[0x2]; // Offset: 0x06 // Size: 0x02
	struct FDatasmithAssetImportOptions AssetOptions; // Offset: 0x08 // Size: 0x08
	struct FDatasmithStaticMeshImportOptions StaticMeshOptions; // Offset: 0x10 // Size: 0x04
};

// Object Name: ScriptStruct DatasmithContent.DatasmithStaticMeshImportOptions
// Size: 0x04 // Inherited bytes: 0x00
struct FDatasmithStaticMeshImportOptions {
	// Fields
	enum class EDatasmithImportLightmapMin MinLightmapResolution; // Offset: 0x00 // Size: 0x01
	enum class EDatasmithImportLightmapMax MaxLightmapResolution; // Offset: 0x01 // Size: 0x01
	bool bGenerateLightmapUVs; // Offset: 0x02 // Size: 0x01
	bool bRemoveDegenerates; // Offset: 0x03 // Size: 0x01
};

// Object Name: ScriptStruct DatasmithContent.DatasmithAssetImportOptions
// Size: 0x08 // Inherited bytes: 0x00
struct FDatasmithAssetImportOptions {
	// Fields
	struct FName PackagePath; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct DatasmithContent.DatasmithReimportOptions
// Size: 0x02 // Inherited bytes: 0x00
struct FDatasmithReimportOptions {
	// Fields
	bool bUpdateActors; // Offset: 0x00 // Size: 0x01
	bool bRespawnDeletedActors; // Offset: 0x01 // Size: 0x01
};

// Object Name: ScriptStruct DatasmithContent.DatasmithStaticParameterSetTemplate
// Size: 0x50 // Inherited bytes: 0x00
struct FDatasmithStaticParameterSetTemplate {
	// Fields
	struct TMap<struct FName, bool> StaticSwitchParameters; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct DatasmithContent.DatasmithMeshSectionInfoMapTemplate
// Size: 0x50 // Inherited bytes: 0x00
struct FDatasmithMeshSectionInfoMapTemplate {
	// Fields
	struct TMap<uint32_t, struct FDatasmithMeshSectionInfoTemplate> Map; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct DatasmithContent.DatasmithMeshSectionInfoTemplate
// Size: 0x04 // Inherited bytes: 0x00
struct FDatasmithMeshSectionInfoTemplate {
	// Fields
	int32_t MaterialIndex; // Offset: 0x00 // Size: 0x04
};

// Object Name: ScriptStruct DatasmithContent.DatasmithStaticMaterialTemplate
// Size: 0x10 // Inherited bytes: 0x00
struct FDatasmithStaticMaterialTemplate {
	// Fields
	struct FName MaterialSlotName; // Offset: 0x00 // Size: 0x08
	struct UMaterialInterface* MaterialInterface; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct DatasmithContent.DatasmithMeshBuildSettingsTemplate
// Size: 0x10 // Inherited bytes: 0x00
struct FDatasmithMeshBuildSettingsTemplate {
	// Fields
	char bUseMikkTSpace : 1; // Offset: 0x00 // Size: 0x01
	char bRecomputeNormals : 1; // Offset: 0x00 // Size: 0x01
	char bRecomputeTangents : 1; // Offset: 0x00 // Size: 0x01
	char bRemoveDegenerates : 1; // Offset: 0x00 // Size: 0x01
	char bBuildAdjacencyBuffer : 1; // Offset: 0x00 // Size: 0x01
	char bUseHighPrecisionTangentBasis : 1; // Offset: 0x00 // Size: 0x01
	char bUseFullPrecisionUVs : 1; // Offset: 0x00 // Size: 0x01
	char bGenerateLightmapUVs : 1; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	int32_t MinLightmapResolution; // Offset: 0x04 // Size: 0x04
	int32_t SrcLightmapIndex; // Offset: 0x08 // Size: 0x04
	int32_t DstLightmapIndex; // Offset: 0x0c // Size: 0x04
};

