#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum E_Item_Quality.E_Item_Quality
enum class E_Item_Quality : uint8 {
	N = 0,
	R = 1,
	SR = 2,
	SSR = 3,
	SSR+ = 4,
	UR = 5,
	E Item MAX = 6
};

