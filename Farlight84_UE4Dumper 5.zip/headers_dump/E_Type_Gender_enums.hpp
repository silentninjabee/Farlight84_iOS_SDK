#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum E_Type_Gender.E_Type_Gender
enum class E_Type_Gender : uint8 {
	NewEnumerator5 = 0,
	NewEnumerator0 = 1,
	NewEnumerator1 = 2,
	None = 3,
	E Type MAX = 4
};

