#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum E_Type_PlayerName_Vip_Color.E_Type_PlayerName_Vip_Color
enum class E_Type_PlayerName_Vip_Color : uint8 {
	None = 0,
	Week = 1,
	Month = 2,
	Super = 3,
	E Type Player Name Vip MAX = 4
};

