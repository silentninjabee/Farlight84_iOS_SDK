#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum E_Type_RedHint.E_Type_RedHint
enum class E_Type_RedHint : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	E Type MAX = 2
};

