#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum EditableMesh.ETriangleTessellationMode
enum class ETriangleTessellationMode : uint8 {
	ThreeTriangles = 0,
	FourTriangles = 1,
	ETriangleTessellationMode_MAX = 2
};

// Object Name: Enum EditableMesh.EInsetPolygonsMode
enum class EInsetPolygonsMode : uint8 {
	All = 0,
	CenterPolygonOnly = 1,
	SidePolygonsOnly = 2,
	EInsetPolygonsMode_MAX = 3
};

// Object Name: Enum EditableMesh.EPolygonEdgeHardness
enum class EPolygonEdgeHardness : uint8 {
	NewEdgesSoft = 0,
	NewEdgesHard = 1,
	AllEdgesSoft = 2,
	AllEdgesHard = 3,
	EPolygonEdgeHardness_MAX = 4
};

// Object Name: Enum EditableMesh.EMeshElementAttributeType
enum class EMeshElementAttributeType : uint8 {
	None = 0,
	FVector4 = 1,
	FVector = 2,
	FVector2D = 3,
	Float = 4,
	Int = 5,
	Bool = 6,
	FName = 7,
	EMeshElementAttributeType_MAX = 8
};

// Object Name: Enum EditableMesh.EMeshTopologyChange
enum class EMeshTopologyChange : uint8 {
	NoTopologyChange = 0,
	TopologyChange = 1,
	EMeshTopologyChange_MAX = 2
};

// Object Name: Enum EditableMesh.EMeshModificationType
enum class EMeshModificationType : uint8 {
	FirstInterim = 0,
	Interim = 1,
	Final = 2,
	EMeshModificationType_MAX = 3
};

