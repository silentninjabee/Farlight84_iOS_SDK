#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass Effect_VH_Hover_Soroll03_TurretA1_BaseDamage.Effect_VH_Hover_Soroll03_TurretA1_BaseDamage_C
// Size: 0x198 // Inherited bytes: 0x198
struct UEffect_VH_Hover_Soroll03_TurretA1_BaseDamage_C : USolarAbilityEffect {
};

