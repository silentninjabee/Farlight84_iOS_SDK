#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass Effect_VH_Leg_WL06_Shotgun_ExplosionDamage_man.Effect_VH_Leg_WL06_Shotgun_ExplosionDamage_man_C
// Size: 0x198 // Inherited bytes: 0x198
struct UEffect_VH_Leg_WL06_Shotgun_ExplosionDamage_man_C : USolarAbilityEffect {
};

