#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass Environment_Lighting.Environment_Lighting_C
// Size: 0x248 // Inherited bytes: 0x230
struct AEnvironment_Lighting_C : ALevelScriptActor {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x230 // Size: 0x08
	struct ASkyLight* SkyLight_0_ExecuteUbergraph_Environment_Lighting_RefProperty; // Offset: 0x238 // Size: 0x08
	struct ABP_Env_LitData_C* BP_Env_LitData_2_ExecuteUbergraph_Environment_Lighting_RefProperty; // Offset: 0x240 // Size: 0x08

	// Functions

	// Object Name: Function Environment_Lighting.Environment_Lighting_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	struct FString GetModuleName(); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Environment_Lighting.Environment_Lighting_C.SetLight
	// Flags: [BlueprintCallable|BlueprintEvent]
	void SetLight(struct FString SceneName); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Environment_Lighting.Environment_Lighting_C.SetCardSkyLightData
	// Flags: [BlueprintCallable|BlueprintEvent]
	void SetCardSkyLightData(float Indensity); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Environment_Lighting.Environment_Lighting_C.ExecuteUbergraph_Environment_Lighting
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_Environment_Lighting(int32_t EntryPoint); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x4)
};

