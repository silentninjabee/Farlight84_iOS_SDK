#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Feedback.Feedback_C
// Size: 0x2d0 // Inherited bytes: 0x2a0
struct UFeedback_C : UFeedbackWidget {
	// Fields
	struct UCrosshair_AutoFire_Anim_C* AutoFire; // Offset: 0x2a0 // Size: 0x08
	struct UHUD_HeadHit_Player_C* HUD_HeadHit_Player; // Offset: 0x2a8 // Size: 0x08
	struct UHUD_Hit_Car_C* HUD_Hit_Car; // Offset: 0x2b0 // Size: 0x08
	struct UHUD_Hit_Car_Weakness_C* HUD_Hit_Car_Weakness; // Offset: 0x2b8 // Size: 0x08
	struct UHUD_Hit_Player_C* HUD_Hit_Player; // Offset: 0x2c0 // Size: 0x08
	struct UKill_Anim_C* Kill_Anim; // Offset: 0x2c8 // Size: 0x08
};

