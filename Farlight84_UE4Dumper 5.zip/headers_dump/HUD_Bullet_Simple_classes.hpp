#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass HUD_Bullet_Simple.HUD_Bullet_Simple_C
// Size: 0x291 // Inherited bytes: 0x268
struct UHUD_Bullet_Simple_C : UBP_HUD_BulletBase_C {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x268 // Size: 0x08
	struct UWidgetAnimation* Buttle_Light_Anim; // Offset: 0x270 // Size: 0x08
	struct UGaugeImage_C* AmmoGauge; // Offset: 0x278 // Size: 0x08
	struct UImage* AmmoGauge_BG; // Offset: 0x280 // Size: 0x08
	struct UHUD_Bullet_Simple_Light_C* HUD_Bullet_Simple_Light; // Offset: 0x288 // Size: 0x08
	enum class E_UI_Bullet_Type ; // Offset: 0x290 // Size: 0x01

	// Functions

	// Object Name: Function HUD_Bullet_Simple.HUD_Bullet_Simple_C.ReloadFinish
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void ReloadFinish(int32_t InReservedAmmo, int32_t InMaxAmmo); // Offset: 0x1032a8510 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function HUD_Bullet_Simple.HUD_Bullet_Simple_C.SetBulletLightEffect
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetBulletLightEffect(float InProgress); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function HUD_Bullet_Simple.HUD_Bullet_Simple_C.GetBulletGaugeWidget
	// Flags: [Protected|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void GetBulletGaugeWidget(struct UUserWidget*& OutBulletGaugeWidget); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function HUD_Bullet_Simple.HUD_Bullet_Simple_C.BP_OnEntryReleased
	// Flags: [Event|Protected|BlueprintEvent]
	void BP_OnEntryReleased(); // Offset: 0x1032a8510 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function HUD_Bullet_Simple.HUD_Bullet_Simple_C.BP_OnItemExpansionChanged
	// Flags: [Event|Protected|BlueprintEvent]
	void BP_OnItemExpansionChanged(bool bIsExpanded); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function HUD_Bullet_Simple.HUD_Bullet_Simple_C.BP_OnItemSelectionChanged
	// Flags: [Event|Protected|BlueprintEvent]
	void BP_OnItemSelectionChanged(bool bIsSelected); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function HUD_Bullet_Simple.HUD_Bullet_Simple_C.OnListItemObjectSet
	// Flags: [Event|Protected|BlueprintEvent]
	void OnListItemObjectSet(struct UObject* ListItemObject); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function HUD_Bullet_Simple.HUD_Bullet_Simple_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void PreConstruct(bool IsDesignTime); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function HUD_Bullet_Simple.HUD_Bullet_Simple_C.ExecuteUbergraph_HUD_Bullet_Simple
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_HUD_Bullet_Simple(int32_t EntryPoint); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x4)
};

