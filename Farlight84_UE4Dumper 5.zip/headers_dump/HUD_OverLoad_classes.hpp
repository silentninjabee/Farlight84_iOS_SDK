#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass HUD_OverLoad.HUD_Overload_C
// Size: 0x335 // Inherited bytes: 0x260
struct UHUD_Overload_C : UUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x260 // Size: 0x08
	struct UWidgetAnimation* Overheat_Anim; // Offset: 0x268 // Size: 0x08
	struct UImage* Img_Disable; // Offset: 0x270 // Size: 0x08
	struct UImage* Img_Disable_2; // Offset: 0x278 // Size: 0x08
	struct UImage* img_overload; // Offset: 0x280 // Size: 0x08
	struct UImage* img_overload_bg; // Offset: 0x288 // Size: 0x08
	struct UImage* img_overload_Glow; // Offset: 0x290 // Size: 0x08
	struct UCanvasPanel* OverloadWarning; // Offset: 0x298 // Size: 0x08
	struct FVector2D OverloadImgMaxSize; // Offset: 0x2a0 // Size: 0x08
	float AnimImgRatio; // Offset: 0x2a8 // Size: 0x04
	float OverloadProgress; // Offset: 0x2ac // Size: 0x04
	struct UUserWidget* ParentWidget; // Offset: 0x2b0 // Size: 0x08
	struct UCurveLinearColor* ColorCurve; // Offset: 0x2b8 // Size: 0x08
	struct FVector2D ShadowSize; // Offset: 0x2c0 // Size: 0x08
	float ImgMaxParmValue; // Offset: 0x2c8 // Size: 0x04
	float ImgParmOffset; // Offset: 0x2cc // Size: 0x04
	struct FLinearColor NewVar_1; // Offset: 0x2d0 // Size: 0x10
	struct TMap<struct UUserWidget*, struct FVector2D> CrosshairScaleMapping; // Offset: 0x2e0 // Size: 0x50
	float NewVar_2; // Offset: 0x330 // Size: 0x04
	bool AlwaysShowOverload; // Offset: 0x334 // Size: 0x01

	// Functions

	// Object Name: Function HUD_OverLoad.HUD_Overload_C.PlayOverloadAnima
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void PlayOverloadAnima(bool InOverload); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function HUD_OverLoad.HUD_Overload_C.SetCoolDownProgress
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetCoolDownProgress(); // Offset: 0x1032a8510 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function HUD_OverLoad.HUD_Overload_C.SetOverLoadImageSize
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetOverLoadImageSize(float InProgress); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function HUD_OverLoad.HUD_Overload_C.OnChangeReloadState
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void OnChangeReloadState(bool InbQuitState, bool bReloadSpeedup); // Offset: 0x1032a8510 // Return & Params: Num(2) Size(0x2)

	// Object Name: Function HUD_OverLoad.HUD_Overload_C.OnInsufficientAmmo
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void OnInsufficientAmmo(); // Offset: 0x1032a8510 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function HUD_OverLoad.HUD_Overload_C.OnReloadFinish
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void OnReloadFinish(bool InbReloadSuccess, int32_t InReloadAmmo, int32_t InReservedAmmo, int32_t InMaxAmmo, float InAmmoProgress); // Offset: 0x1032a8510 // Return & Params: Num(5) Size(0x14)

	// Object Name: Function HUD_OverLoad.HUD_Overload_C.OnUpdateAmmo
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void OnUpdateAmmo(int32_t InReservedAmmo, int32_t InMaxAmmo, float InAmmoProgress, bool InbFirst); // Offset: 0x1032a8510 // Return & Params: Num(4) Size(0xd)

	// Object Name: Function HUD_OverLoad.HUD_Overload_C.OnUpdateCharge
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void OnUpdateCharge(bool InbCharging, int32_t InChargeMode, float InChargeProgress); // Offset: 0x1032a8510 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function HUD_OverLoad.HUD_Overload_C.OnUpdateCoolDown
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void OnUpdateCoolDown(float InReloadProgress); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function HUD_OverLoad.HUD_Overload_C.OnUpdateReload
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void OnUpdateReload(float InReloadProgress, int32_t InReloadAmmo, int32_t InMaxAmmo); // Offset: 0x1032a8510 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function HUD_OverLoad.HUD_Overload_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void PreConstruct(bool IsDesignTime); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function HUD_OverLoad.HUD_Overload_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Construct(); // Offset: 0x1032a8510 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function HUD_OverLoad.HUD_Overload_C.OnUpdateOverload
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void OnUpdateOverload(float InOverloadProgress, float InOverloadWarningRate, bool InbOverloadState); // Offset: 0x1032a8510 // Return & Params: Num(3) Size(0x9)

	// Object Name: Function HUD_OverLoad.HUD_Overload_C.OnChangeOverloadState
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void OnChangeOverloadState(bool InbQuitState); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function HUD_OverLoad.HUD_Overload_C.OnActiveCrosshair
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void OnActiveCrosshair(struct UUserWidget* InActiveCrosshair); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function HUD_OverLoad.HUD_Overload_C.ExecuteUbergraph_HUD_Overload
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_HUD_Overload(int32_t EntryPoint); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x4)
};

