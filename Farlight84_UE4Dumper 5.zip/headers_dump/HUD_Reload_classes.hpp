#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass HUD_Reload.HUD_Reload_C
// Size: 0x299 // Inherited bytes: 0x268
struct UHUD_Reload_C : UBP_HUD_ReloadBase_C {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x268 // Size: 0x08
	struct UWidgetAnimation* Anim_Reload_Buff; // Offset: 0x270 // Size: 0x08
	struct UWidgetAnimation* Anim_Reload; // Offset: 0x278 // Size: 0x08
	struct UImage* Img_Bullet; // Offset: 0x280 // Size: 0x08
	struct UImage* Img_Reload; // Offset: 0x288 // Size: 0x08
	struct USolarTextBlock* Txt_QuickReload; // Offset: 0x290 // Size: 0x08
	enum class E_PassiveBuff Passive; // Offset: 0x298 // Size: 0x01

	// Functions

	// Object Name: Function HUD_Reload.HUD_Reload_C.SetSpeedUpBuff
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetSpeedUpBuff(bool bHaveBuff); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function HUD_Reload.HUD_Reload_C.SetPassive
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SetPassive(enum class E_PassiveBuff Passive); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function HUD_Reload.HUD_Reload_C.GetReloadAnimation
	// Flags: [Protected|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void GetReloadAnimation(struct UWidgetAnimation*& OutReloadAnimation); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function HUD_Reload.HUD_Reload_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void PreConstruct(bool IsDesignTime); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function HUD_Reload.HUD_Reload_C.ExecuteUbergraph_HUD_Reload
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_HUD_Reload(int32_t EntryPoint); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x4)
};

