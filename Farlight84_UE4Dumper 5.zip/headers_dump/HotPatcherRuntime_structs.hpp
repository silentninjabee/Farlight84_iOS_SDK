#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct HotPatcherRuntime.PakMountInfo
// Size: 0x18 // Inherited bytes: 0x00
struct FPakMountInfo {
	// Fields
	struct FString Pak; // Offset: 0x00 // Size: 0x10
	int32_t PakOrder; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct HotPatcherRuntime.AssetDependenciesDetail
// Size: 0x60 // Inherited bytes: 0x00
struct FAssetDependenciesDetail {
	// Fields
	struct FString ModuleCategory; // Offset: 0x00 // Size: 0x10
	struct TMap<struct FString, struct FAssetDetail> AssetDependencyDetails; // Offset: 0x10 // Size: 0x50
};

// Object Name: ScriptStruct HotPatcherRuntime.AssetDetail
// Size: 0x18 // Inherited bytes: 0x00
struct FAssetDetail {
	// Fields
	struct FName PackagePath; // Offset: 0x00 // Size: 0x08
	struct FName AssetType; // Offset: 0x08 // Size: 0x08
	struct FName Guid; // Offset: 0x10 // Size: 0x08
};

// Object Name: ScriptStruct HotPatcherRuntime.AssetDependenciesInfo
// Size: 0x50 // Inherited bytes: 0x00
struct FAssetDependenciesInfo {
	// Fields
	struct TMap<struct FString, struct FAssetDependenciesDetail> AssetsDependenciesMap; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct HotPatcherRuntime.BinariesPatchConfig
// Size: 0x50 // Inherited bytes: 0x00
struct FBinariesPatchConfig {
	// Fields
	enum class EBinariesPatchFeature BinariesPatchType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x17]; // Offset: 0x01 // Size: 0x17
	struct FPakEncryptSettings EncryptSettings; // Offset: 0x18 // Size: 0x18
	struct TArray<struct FPlatformBasePak> BaseVersionPaks; // Offset: 0x30 // Size: 0x10
	struct TArray<struct FMatchRule> MatchRules; // Offset: 0x40 // Size: 0x10
};

// Object Name: ScriptStruct HotPatcherRuntime.MatchRule
// Size: 0x28 // Inherited bytes: 0x00
struct FMatchRule {
	// Fields
	enum class EMatchRule Rule; // Offset: 0x00 // Size: 0x01
	enum class EMatchOperator Operator; // Offset: 0x01 // Size: 0x01
	char pad_0x2[0x2]; // Offset: 0x02 // Size: 0x02
	float Size; // Offset: 0x04 // Size: 0x04
	struct TArray<struct FString> Formaters; // Offset: 0x08 // Size: 0x10
	struct TArray<struct FString> AssetTypes; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct HotPatcherRuntime.PlatformBasePak
// Size: 0x18 // Inherited bytes: 0x00
struct FPlatformBasePak {
	// Fields
	enum class ETargetPlatform Platform; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct TArray<struct FFilePath> Paks; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct HotPatcherRuntime.PakEncryptSettings
// Size: 0x18 // Inherited bytes: 0x00
struct FPakEncryptSettings {
	// Fields
	bool bUseDefaultCryptoIni; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct FFilePath CryptoKeys; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct HotPatcherRuntime.ChunkAssetDescribe
// Size: 0x148 // Inherited bytes: 0x00
struct FChunkAssetDescribe {
	// Fields
	char pad_0x0[0x148]; // Offset: 0x00 // Size: 0x148
};

// Object Name: ScriptStruct HotPatcherRuntime.ChunkPakCommand
// Size: 0x40 // Inherited bytes: 0x00
struct FChunkPakCommand {
	// Fields
	char pad_0x0[0x40]; // Offset: 0x00 // Size: 0x40
};

// Object Name: ScriptStruct HotPatcherRuntime.ChunkInfo
// Size: 0x88 // Inherited bytes: 0x00
struct FChunkInfo {
	// Fields
	struct FString ChunkName; // Offset: 0x00 // Size: 0x10
	bool bMonolithic; // Offset: 0x10 // Size: 0x01
	enum class EMonolithicPathMode MonolithicPathMode; // Offset: 0x11 // Size: 0x01
	bool bStorageUnrealPakList; // Offset: 0x12 // Size: 0x01
	bool bStorageIoStorePakList; // Offset: 0x13 // Size: 0x01
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct TArray<struct FDirectoryPath> AssetIncludeFilters; // Offset: 0x18 // Size: 0x10
	struct TArray<struct FDirectoryPath> AssetIgnoreFilters; // Offset: 0x28 // Size: 0x10
	bool bAnalysisFilterDependencies; // Offset: 0x38 // Size: 0x01
	char pad_0x39[0x7]; // Offset: 0x39 // Size: 0x07
	struct TArray<enum class EAssetRegistryDependencyTypeEx> AssetRegistryDependencyTypes; // Offset: 0x40 // Size: 0x10
	struct TArray<struct FPatcherSpecifyAsset> IncludeSpecifyAssets; // Offset: 0x50 // Size: 0x10
	struct TArray<struct FPlatformExternAssets> AddExternAssetsToPlatform; // Offset: 0x60 // Size: 0x10
	struct FPakInternalInfo InternalFiles; // Offset: 0x70 // Size: 0x06
	char pad_0x76[0x12]; // Offset: 0x76 // Size: 0x12
};

// Object Name: ScriptStruct HotPatcherRuntime.PakInternalInfo
// Size: 0x06 // Inherited bytes: 0x00
struct FPakInternalInfo {
	// Fields
	char pad_0x0[0x3]; // Offset: 0x00 // Size: 0x03
	bool bIncludeEngineIni; // Offset: 0x03 // Size: 0x01
	bool bIncludePluginIni; // Offset: 0x04 // Size: 0x01
	bool bIncludeProjectIni; // Offset: 0x05 // Size: 0x01
};

// Object Name: ScriptStruct HotPatcherRuntime.PlatformExternAssets
// Size: 0x28 // Inherited bytes: 0x00
struct FPlatformExternAssets {
	// Fields
	enum class ETargetPlatform TargetPlatform; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct TArray<struct FExternFileInfo> AddExternFileToPak; // Offset: 0x08 // Size: 0x10
	struct TArray<struct FExternDirectoryInfo> AddExternDirectoryToPak; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct HotPatcherRuntime.ExternDirectoryInfo
// Size: 0x20 // Inherited bytes: 0x00
struct FExternDirectoryInfo {
	// Fields
	struct FDirectoryPath DirectoryPath; // Offset: 0x00 // Size: 0x10
	struct FString MountPoint; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct HotPatcherRuntime.ExternFileInfo
// Size: 0x38 // Inherited bytes: 0x00
struct FExternFileInfo {
	// Fields
	struct FFilePath FilePath; // Offset: 0x00 // Size: 0x10
	struct FString MountPath; // Offset: 0x10 // Size: 0x10
	struct FString FileHash; // Offset: 0x20 // Size: 0x10
	char pad_0x30[0x8]; // Offset: 0x30 // Size: 0x08
};

// Object Name: ScriptStruct HotPatcherRuntime.PatcherSpecifyAsset
// Size: 0x30 // Inherited bytes: 0x00
struct FPatcherSpecifyAsset {
	// Fields
	struct FSoftObjectPath Asset; // Offset: 0x00 // Size: 0x18
	bool bAnalysisAssetDependencies; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x7]; // Offset: 0x19 // Size: 0x07
	struct TArray<enum class EAssetRegistryDependencyTypeEx> AssetRegistryDependencyTypes; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct HotPatcherRuntime.PakFileProxy
// Size: 0x68 // Inherited bytes: 0x00
struct FPakFileProxy {
	// Fields
	struct FString ChunkStoreName; // Offset: 0x00 // Size: 0x10
	enum class ETargetPlatform Platform; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x7]; // Offset: 0x11 // Size: 0x07
	struct FString StorageDirectory; // Offset: 0x18 // Size: 0x10
	struct FString PakCommandSavePath; // Offset: 0x28 // Size: 0x10
	struct FString PakSavePath; // Offset: 0x38 // Size: 0x10
	struct TArray<struct FPakCommand> PakCommands; // Offset: 0x48 // Size: 0x10
	struct TArray<struct FString> IoStoreCommands; // Offset: 0x58 // Size: 0x10
};

// Object Name: ScriptStruct HotPatcherRuntime.PakCommand
// Size: 0x58 // Inherited bytes: 0x00
struct FPakCommand {
	// Fields
	struct FString ChunkName; // Offset: 0x00 // Size: 0x10
	struct FString MountPath; // Offset: 0x10 // Size: 0x10
	struct FString AssetPackage; // Offset: 0x20 // Size: 0x10
	struct TArray<struct FString> PakCommands; // Offset: 0x30 // Size: 0x10
	struct TArray<struct FString> IoStoreCommands; // Offset: 0x40 // Size: 0x10
	char pad_0x50[0x8]; // Offset: 0x50 // Size: 0x08
};

// Object Name: ScriptStruct HotPatcherRuntime.CookerConfig
// Size: 0x88 // Inherited bytes: 0x00
struct FCookerConfig {
	// Fields
	struct FString EngineBin; // Offset: 0x00 // Size: 0x10
	struct FString ProjectPath; // Offset: 0x10 // Size: 0x10
	struct FString EngineParams; // Offset: 0x20 // Size: 0x10
	struct TArray<struct FString> CookPlatforms; // Offset: 0x30 // Size: 0x10
	bool bCookAllMap; // Offset: 0x40 // Size: 0x01
	char pad_0x41[0x7]; // Offset: 0x41 // Size: 0x07
	struct TArray<struct FString> CookMaps; // Offset: 0x48 // Size: 0x10
	struct TArray<struct FString> CookFilter; // Offset: 0x58 // Size: 0x10
	struct TArray<struct FString> CookSettings; // Offset: 0x68 // Size: 0x10
	struct FString options; // Offset: 0x78 // Size: 0x10
};

// Object Name: ScriptStruct HotPatcherRuntime.PatcherEntitySettingBase
// Size: 0x08 // Inherited bytes: 0x00
struct FPatcherEntitySettingBase {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct HotPatcherRuntime.HotPatcherSettingBase
// Size: 0x38 // Inherited bytes: 0x08
struct FHotPatcherSettingBase : FPatcherEntitySettingBase {
	// Fields
	bool bStorageConfig; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x7]; // Offset: 0x09 // Size: 0x07
	struct FDirectoryPath SavePath; // Offset: 0x10 // Size: 0x10
	bool bStandaloneMode; // Offset: 0x20 // Size: 0x01
	char pad_0x21[0x7]; // Offset: 0x21 // Size: 0x07
	struct TArray<struct FString> AdditionalCommandletArgs; // Offset: 0x28 // Size: 0x10
};

// Object Name: ScriptStruct HotPatcherRuntime.ExportPatchSettings
// Size: 0x328 // Inherited bytes: 0x38
struct FExportPatchSettings : FHotPatcherSettingBase {
	// Fields
	bool bByBaseVersion; // Offset: 0x38 // Size: 0x01
	char pad_0x39[0x7]; // Offset: 0x39 // Size: 0x07
	struct FFilePath BaseVersion; // Offset: 0x40 // Size: 0x10
	struct FString VersionId; // Offset: 0x50 // Size: 0x10
	bool bBinariesPatch; // Offset: 0x60 // Size: 0x01
	char pad_0x61[0x7]; // Offset: 0x61 // Size: 0x07
	struct FBinariesPatchConfig BinariesPatchConfig; // Offset: 0x68 // Size: 0x50
	struct TArray<struct FDirectoryPath> AssetIncludeFilters; // Offset: 0xb8 // Size: 0x10
	struct TArray<struct FDirectoryPath> AssetIgnoreFilters; // Offset: 0xc8 // Size: 0x10
	bool bForceSkipContent; // Offset: 0xd8 // Size: 0x01
	char pad_0xD9[0x7]; // Offset: 0xd9 // Size: 0x07
	struct TArray<struct FDirectoryPath> ForceSkipContentRules; // Offset: 0xe0 // Size: 0x10
	struct TArray<struct FSoftObjectPath> ForceSkipAssets; // Offset: 0xf0 // Size: 0x10
	bool bIncludeHasRefAssetsOnly; // Offset: 0x100 // Size: 0x01
	bool bAnalysisFilterDependencies; // Offset: 0x101 // Size: 0x01
	bool bAnalysisDiffAssetDependenciesOnly; // Offset: 0x102 // Size: 0x01
	char pad_0x103[0x5]; // Offset: 0x103 // Size: 0x05
	struct TArray<enum class EAssetRegistryDependencyTypeEx> AssetRegistryDependencyTypes; // Offset: 0x108 // Size: 0x10
	struct TArray<struct FPatcherSpecifyAsset> IncludeSpecifyAssets; // Offset: 0x118 // Size: 0x10
	bool bRecursiveWidgetTree; // Offset: 0x128 // Size: 0x01
	bool bPackageTracker; // Offset: 0x129 // Size: 0x01
	char pad_0x12A[0x4]; // Offset: 0x12a // Size: 0x04
	bool bIncludeEngineIni; // Offset: 0x12e // Size: 0x01
	bool bIncludePluginIni; // Offset: 0x12f // Size: 0x01
	bool bIncludeProjectIni; // Offset: 0x130 // Size: 0x01
	bool bEnableExternFilesDiff; // Offset: 0x131 // Size: 0x01
	char pad_0x132[0x6]; // Offset: 0x132 // Size: 0x06
	struct TArray<struct FString> IgnoreDeletionModulesAsset; // Offset: 0x138 // Size: 0x10
	char pad_0x148[0x20]; // Offset: 0x148 // Size: 0x20
	struct TArray<struct FPlatformExternAssets> AddExternAssetsToPlatform; // Offset: 0x168 // Size: 0x10
	char pad_0x178[0x18]; // Offset: 0x178 // Size: 0x18
	bool bEnableChunk; // Offset: 0x190 // Size: 0x01
	bool bCreateDefaultChunk; // Offset: 0x191 // Size: 0x01
	char pad_0x192[0x6]; // Offset: 0x192 // Size: 0x06
	struct TArray<struct FChunkInfo> ChunkInfos; // Offset: 0x198 // Size: 0x10
	bool bCookPatchAssets; // Offset: 0x1a8 // Size: 0x01
	char pad_0x1A9[0x7]; // Offset: 0x1a9 // Size: 0x07
	struct FCookShaderOptions CookShaderOptions; // Offset: 0x1b0 // Size: 0x28
	struct FAssetRegistryOptions SerializeAssetRegistryOptions; // Offset: 0x1d8 // Size: 0x30
	struct FIoStoreSettings IoStoreSettings; // Offset: 0x208 // Size: 0x80
	struct FUnrealPakSettings UnrealPakSettings; // Offset: 0x288 // Size: 0x28
	struct TArray<struct FString> DefaultPakListOptions; // Offset: 0x2b0 // Size: 0x10
	struct TArray<struct FString> DefaultCommandletOptions; // Offset: 0x2c0 // Size: 0x10
	struct FPakEncryptSettings EncryptSettings; // Offset: 0x2d0 // Size: 0x18
	struct TArray<struct FReplaceText> ReplacePakListTexts; // Offset: 0x2e8 // Size: 0x10
	struct TArray<enum class ETargetPlatform> PakTargetPlatforms; // Offset: 0x2f8 // Size: 0x10
	bool bCustomPakNameRegular; // Offset: 0x308 // Size: 0x01
	char pad_0x309[0x7]; // Offset: 0x309 // Size: 0x07
	struct FString PakNameRegular; // Offset: 0x310 // Size: 0x10
	bool bStorageNewRelease; // Offset: 0x320 // Size: 0x01
	bool bStoragePakFileInfo; // Offset: 0x321 // Size: 0x01
	bool bIgnoreDeleatedAssetsInfo; // Offset: 0x322 // Size: 0x01
	bool bStorageDeletedAssetsToNewReleaseJson; // Offset: 0x323 // Size: 0x01
	bool bStorageDiffAnalysisResults; // Offset: 0x324 // Size: 0x01
	bool bBackupMetadata; // Offset: 0x325 // Size: 0x01
	char pad_0x326[0x1]; // Offset: 0x326 // Size: 0x01
	bool bEnableProfiling; // Offset: 0x327 // Size: 0x01
};

// Object Name: ScriptStruct HotPatcherRuntime.ReplaceText
// Size: 0x28 // Inherited bytes: 0x00
struct FReplaceText {
	// Fields
	struct FString From; // Offset: 0x00 // Size: 0x10
	struct FString To; // Offset: 0x10 // Size: 0x10
	enum class ESearchCaseMode SearchCase; // Offset: 0x20 // Size: 0x01
	char pad_0x21[0x7]; // Offset: 0x21 // Size: 0x07
};

// Object Name: ScriptStruct HotPatcherRuntime.UnrealPakSettings
// Size: 0x28 // Inherited bytes: 0x00
struct FUnrealPakSettings {
	// Fields
	struct TArray<struct FString> UnrealPakListOptions; // Offset: 0x00 // Size: 0x10
	struct TArray<struct FString> UnrealCommandletOptions; // Offset: 0x10 // Size: 0x10
	bool bStoragePakList; // Offset: 0x20 // Size: 0x01
	char pad_0x21[0x7]; // Offset: 0x21 // Size: 0x07
};

// Object Name: ScriptStruct HotPatcherRuntime.IoStoreSettings
// Size: 0x80 // Inherited bytes: 0x00
struct FIoStoreSettings {
	// Fields
	bool bIoStore; // Offset: 0x00 // Size: 0x01
	bool bAllowBulkDataInIoStore; // Offset: 0x01 // Size: 0x01
	char pad_0x2[0x6]; // Offset: 0x02 // Size: 0x06
	struct TArray<struct FString> IoStorePakListOptions; // Offset: 0x08 // Size: 0x10
	struct TArray<struct FString> IoStoreCommandletOptions; // Offset: 0x18 // Size: 0x10
	struct TMap<enum class ETargetPlatform, struct FIoStorePlatformContainers> PlatformContainers; // Offset: 0x28 // Size: 0x50
	bool bStoragePakList; // Offset: 0x78 // Size: 0x01
	bool bStorageBulkDataInfo; // Offset: 0x79 // Size: 0x01
	char pad_0x7A[0x6]; // Offset: 0x7a // Size: 0x06
};

// Object Name: ScriptStruct HotPatcherRuntime.IoStorePlatformContainers
// Size: 0x38 // Inherited bytes: 0x00
struct FIoStorePlatformContainers {
	// Fields
	struct FDirectoryPath BasePackageStagedRootDir; // Offset: 0x00 // Size: 0x10
	bool bGenerateDiffPatch; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x7]; // Offset: 0x11 // Size: 0x07
	struct FFilePath GlobalContainersOverride; // Offset: 0x18 // Size: 0x10
	struct FFilePath PatchSourceOverride; // Offset: 0x28 // Size: 0x10
};

// Object Name: ScriptStruct HotPatcherRuntime.AssetRegistryOptions
// Size: 0x30 // Inherited bytes: 0x00
struct FAssetRegistryOptions {
	// Fields
	bool bSerializeAssetRegistry; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct FString AssetRegistryMountPointRegular; // Offset: 0x08 // Size: 0x10
	enum class EAssetRegistryRule AssetRegistryRule; // Offset: 0x18 // Size: 0x01
	bool bCustomAssetRegistryName; // Offset: 0x19 // Size: 0x01
	char pad_0x1A[0x6]; // Offset: 0x1a // Size: 0x06
	struct FString AssetRegistryNameRegular; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct HotPatcherRuntime.CookShaderOptions
// Size: 0x28 // Inherited bytes: 0x00
struct FCookShaderOptions {
	// Fields
	bool bSharedShaderLibrary; // Offset: 0x00 // Size: 0x01
	bool bNativeShader; // Offset: 0x01 // Size: 0x01
	char pad_0x2[0x1]; // Offset: 0x02 // Size: 0x01
	enum class EShaderLibNameRule ShaderNameRule; // Offset: 0x03 // Size: 0x01
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString CustomShaderName; // Offset: 0x08 // Size: 0x10
	struct FString ShderLibMountPointRegular; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct HotPatcherRuntime.ExportReleaseSettings
// Size: 0x100 // Inherited bytes: 0x38
struct FExportReleaseSettings : FHotPatcherSettingBase {
	// Fields
	struct FString VersionId; // Offset: 0x38 // Size: 0x10
	bool ByPakList; // Offset: 0x48 // Size: 0x01
	char pad_0x49[0x7]; // Offset: 0x49 // Size: 0x07
	struct TArray<struct FPlatformPakListFiles> PlatformsPakListFiles; // Offset: 0x50 // Size: 0x10
	struct TArray<struct FDirectoryPath> AssetIncludeFilters; // Offset: 0x60 // Size: 0x10
	struct TArray<struct FDirectoryPath> AssetIgnoreFilters; // Offset: 0x70 // Size: 0x10
	bool bAnalysisFilterDependencies; // Offset: 0x80 // Size: 0x01
	char pad_0x81[0x7]; // Offset: 0x81 // Size: 0x07
	struct TArray<enum class EAssetRegistryDependencyTypeEx> AssetRegistryDependencyTypes; // Offset: 0x88 // Size: 0x10
	bool bIncludeHasRefAssetsOnly; // Offset: 0x98 // Size: 0x01
	char pad_0x99[0x7]; // Offset: 0x99 // Size: 0x07
	struct TArray<struct FPatcherSpecifyAsset> IncludeSpecifyAssets; // Offset: 0xa0 // Size: 0x10
	char pad_0xB0[0x20]; // Offset: 0xb0 // Size: 0x20
	struct TArray<struct FPlatformExternAssets> AddExternAssetsToPlatform; // Offset: 0xd0 // Size: 0x10
	bool bBackupMetadata; // Offset: 0xe0 // Size: 0x01
	bool bBackupProjectConfig; // Offset: 0xe1 // Size: 0x01
	char pad_0xE2[0x6]; // Offset: 0xe2 // Size: 0x06
	struct TArray<enum class ETargetPlatform> BackupMetadataPlatforms; // Offset: 0xe8 // Size: 0x10
	bool bNoShaderCompile; // Offset: 0xf8 // Size: 0x01
	char pad_0xF9[0x7]; // Offset: 0xf9 // Size: 0x07
};

// Object Name: ScriptStruct HotPatcherRuntime.PlatformPakListFiles
// Size: 0x38 // Inherited bytes: 0x00
struct FPlatformPakListFiles {
	// Fields
	enum class ETargetPlatform TargetPlatform; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct TArray<struct FFilePath> PakResponseFiles; // Offset: 0x08 // Size: 0x10
	struct TArray<struct FFilePath> PakFiles; // Offset: 0x18 // Size: 0x10
	struct FString AESKey; // Offset: 0x28 // Size: 0x10
};

// Object Name: ScriptStruct HotPatcherRuntime.HotPatcherAssetDependency
// Size: 0x38 // Inherited bytes: 0x00
struct FHotPatcherAssetDependency {
	// Fields
	struct FAssetDetail Asset; // Offset: 0x00 // Size: 0x18
	struct TArray<struct FAssetDetail> AssetReference; // Offset: 0x18 // Size: 0x10
	struct TArray<struct FAssetDetail> AssetDependency; // Offset: 0x28 // Size: 0x10
};

// Object Name: ScriptStruct HotPatcherRuntime.HotPatcherVersion
// Size: 0x118 // Inherited bytes: 0x00
struct FHotPatcherVersion {
	// Fields
	struct FString VersionId; // Offset: 0x00 // Size: 0x10
	struct FString BaseVersionId; // Offset: 0x10 // Size: 0x10
	struct FString Date; // Offset: 0x20 // Size: 0x10
	char pad_0x30[0x48]; // Offset: 0x30 // Size: 0x48
	struct FAssetDependenciesInfo AssetInfo; // Offset: 0x78 // Size: 0x50
	struct TMap<enum class ETargetPlatform, struct FPlatformExternAssets> PlatformAssets; // Offset: 0xc8 // Size: 0x50
};

// Object Name: ScriptStruct HotPatcherRuntime.PackageInfo
// Size: 0x20 // Inherited bytes: 0x00
struct FPackageInfo {
	// Fields
	struct FString AssetName; // Offset: 0x00 // Size: 0x10
	struct FString AssetGuid; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct HotPatcherRuntime.PakEncryptionKeys
// Size: 0x88 // Inherited bytes: 0x00
struct FPakEncryptionKeys {
	// Fields
	struct FEncryptionKeyEntry EncryptionKey; // Offset: 0x00 // Size: 0x30
	struct TArray<struct FEncryptionKeyEntry> SecondaryEncryptionKeys; // Offset: 0x30 // Size: 0x10
	bool bEnablePakIndexEncryption; // Offset: 0x40 // Size: 0x01
	bool bEnablePakIniEncryption; // Offset: 0x41 // Size: 0x01
	bool bEnablePakUAssetEncryption; // Offset: 0x42 // Size: 0x01
	bool bEnablePakFullAssetEncryption; // Offset: 0x43 // Size: 0x01
	bool bDataCryptoRequired; // Offset: 0x44 // Size: 0x01
	bool PakEncryptionRequired; // Offset: 0x45 // Size: 0x01
	bool PakSigningRequired; // Offset: 0x46 // Size: 0x01
	bool bEnablePakSigning; // Offset: 0x47 // Size: 0x01
	struct FSignKeyEntry SigningKey; // Offset: 0x48 // Size: 0x40
};

// Object Name: ScriptStruct HotPatcherRuntime.SignKeyEntry
// Size: 0x40 // Inherited bytes: 0x00
struct FSignKeyEntry {
	// Fields
	struct FSignKeyItem PublicKey; // Offset: 0x00 // Size: 0x20
	struct FSignKeyItem PrivateKey; // Offset: 0x20 // Size: 0x20
};

// Object Name: ScriptStruct HotPatcherRuntime.SignKeyItem
// Size: 0x20 // Inherited bytes: 0x00
struct FSignKeyItem {
	// Fields
	struct FString Exponent; // Offset: 0x00 // Size: 0x10
	struct FString Modulus; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct HotPatcherRuntime.EncryptionKeyEntry
// Size: 0x30 // Inherited bytes: 0x00
struct FEncryptionKeyEntry {
	// Fields
	struct FString Name; // Offset: 0x00 // Size: 0x10
	struct FString Guid; // Offset: 0x10 // Size: 0x10
	struct FString Key; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct HotPatcherRuntime.PakFilesMap
// Size: 0x50 // Inherited bytes: 0x00
struct FPakFilesMap {
	// Fields
	struct TMap<struct FString, struct FPakFileArray> PakFilesMap; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct HotPatcherRuntime.PakFileArray
// Size: 0x10 // Inherited bytes: 0x00
struct FPakFileArray {
	// Fields
	struct TArray<struct FPakFileInfo> PakFileInfos; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct HotPatcherRuntime.PakFileInfo
// Size: 0x28 // Inherited bytes: 0x00
struct FPakFileInfo {
	// Fields
	struct FString Filename; // Offset: 0x00 // Size: 0x10
	struct FString Hash; // Offset: 0x10 // Size: 0x10
	int32_t FileSize; // Offset: 0x20 // Size: 0x04
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
};

// Object Name: ScriptStruct HotPatcherRuntime.PakVersion
// Size: 0x40 // Inherited bytes: 0x00
struct FPakVersion {
	// Fields
	struct FString VersionId; // Offset: 0x00 // Size: 0x10
	struct FString BaseVersionId; // Offset: 0x10 // Size: 0x10
	struct FString Date; // Offset: 0x20 // Size: 0x10
	struct FString CheckCode; // Offset: 0x30 // Size: 0x10
};

// Object Name: ScriptStruct HotPatcherRuntime.PatchVersionAssetDiff
// Size: 0xf0 // Inherited bytes: 0x00
struct FPatchVersionAssetDiff {
	// Fields
	struct FAssetDependenciesInfo AddAssetDependInfo; // Offset: 0x00 // Size: 0x50
	struct FAssetDependenciesInfo ModifyAssetDependInfo; // Offset: 0x50 // Size: 0x50
	struct FAssetDependenciesInfo DeleteAssetDependInfo; // Offset: 0xa0 // Size: 0x50
};

// Object Name: ScriptStruct HotPatcherRuntime.PatchVersionDiff
// Size: 0x140 // Inherited bytes: 0x00
struct FPatchVersionDiff {
	// Fields
	struct FPatchVersionAssetDiff AssetDiffInfo; // Offset: 0x00 // Size: 0xf0
	struct TMap<enum class ETargetPlatform, struct FPatchVersionExternDiff> PlatformExternDiffInfo; // Offset: 0xf0 // Size: 0x50
};

// Object Name: ScriptStruct HotPatcherRuntime.PatchVersionExternDiff
// Size: 0x38 // Inherited bytes: 0x00
struct FPatchVersionExternDiff {
	// Fields
	enum class ETargetPlatform Platform; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct TArray<struct FExternFileInfo> AddExternalFiles; // Offset: 0x08 // Size: 0x10
	struct TArray<struct FExternFileInfo> ModifyExternalFiles; // Offset: 0x18 // Size: 0x10
	struct TArray<struct FExternFileInfo> DeleteExternalFiles; // Offset: 0x28 // Size: 0x10
};

// Object Name: ScriptStruct HotPatcherRuntime.PlatformExternFiles
// Size: 0x18 // Inherited bytes: 0x00
struct FPlatformExternFiles {
	// Fields
	enum class ETargetPlatform Platform; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct TArray<struct FExternFileInfo> ExternFiles; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct HotPatcherRuntime.HotPatcherContext
// Size: 0x58 // Inherited bytes: 0x00
struct FHotPatcherContext {
	// Fields
	char pad_0x0[0x40]; // Offset: 0x00 // Size: 0x40
	struct UScopedSlowTaskContext* UnrealPakSlowTask; // Offset: 0x40 // Size: 0x08
	char pad_0x48[0x10]; // Offset: 0x48 // Size: 0x10
};

// Object Name: ScriptStruct HotPatcherRuntime.HotPatcherReleaseContext
// Size: 0x170 // Inherited bytes: 0x58
struct FHotPatcherReleaseContext : FHotPatcherContext {
	// Fields
	struct FHotPatcherVersion NewReleaseVersion; // Offset: 0x58 // Size: 0x118
};

// Object Name: ScriptStruct HotPatcherRuntime.HotPatcherPatchContext
// Size: 0x5e0 // Inherited bytes: 0x58
struct FHotPatcherPatchContext : FHotPatcherContext {
	// Fields
	char pad_0x58[0x8]; // Offset: 0x58 // Size: 0x08
	struct FHotPatcherVersion BaseVersion; // Offset: 0x60 // Size: 0x118
	struct FHotPatcherVersion CurrentVersion; // Offset: 0x178 // Size: 0x118
	struct FPatchVersionDiff VersionDiff; // Offset: 0x290 // Size: 0x140
	struct FHotPatcherVersion NewReleaseVersion; // Offset: 0x3d0 // Size: 0x118
	struct FChunkInfo NewVersionChunk; // Offset: 0x4e8 // Size: 0x88
	struct TArray<struct FChunkInfo> PakChunks; // Offset: 0x570 // Size: 0x10
	struct TArray<struct FPakCommand> AdditionalFileToPak; // Offset: 0x580 // Size: 0x10
	char pad_0x590[0x50]; // Offset: 0x590 // Size: 0x50
};

