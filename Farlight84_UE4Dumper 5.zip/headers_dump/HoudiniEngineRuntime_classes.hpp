#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class HoudiniEngineRuntime.HoudiniAssetActor
// Size: 0x230 // Inherited bytes: 0x228
struct AHoudiniAssetActor : AActor {
	// Fields
	struct UHoudiniAssetComponent* HoudiniAssetComponent; // Offset: 0x228 // Size: 0x08
};

// Object Name: Class HoudiniEngineRuntime.HiddenHoudiniAssetActor
// Size: 0x230 // Inherited bytes: 0x230
struct AHiddenHoudiniAssetActor : AHoudiniAssetActor {
};

// Object Name: Class HoudiniEngineRuntime.HoudiniAsset
// Size: 0x50 // Inherited bytes: 0x28
struct UHoudiniAsset : UObject {
	// Fields
	struct FString AssetFileName; // Offset: 0x28 // Size: 0x10
	struct TArray<char> AssetBytes; // Offset: 0x38 // Size: 0x10
	uint32_t AssetBytesCount; // Offset: 0x48 // Size: 0x04
	bool bAssetLimitedCommercial; // Offset: 0x4c // Size: 0x01
	bool bAssetNonCommercial; // Offset: 0x4d // Size: 0x01
	bool bAssetExpanded; // Offset: 0x4e // Size: 0x01
	char pad_0x4F[0x1]; // Offset: 0x4f // Size: 0x01
};

// Object Name: Class HoudiniEngineRuntime.HoudiniAssetComponent
// Size: 0xb10 // Inherited bytes: 0x570
struct UHoudiniAssetComponent : UPrimitiveComponent {
	// Fields
	char pad_0x570[0x8]; // Offset: 0x570 // Size: 0x08
	struct FHoudiniInputLandscapeTransferParams LandscapeTransferParams; // Offset: 0x578 // Size: 0xc8
	struct TArray<struct FDirectoryPath> Directories; // Offset: 0x640 // Size: 0x10
	struct UHoudiniAsset* HoudiniAsset; // Offset: 0x650 // Size: 0x08
	bool bCookOnParameterChange; // Offset: 0x658 // Size: 0x01
	bool bUploadTransformsToHoudiniEngine; // Offset: 0x659 // Size: 0x01
	bool bCookOnTransformChange; // Offset: 0x65a // Size: 0x01
	bool bCookOnAssetInputCook; // Offset: 0x65b // Size: 0x01
	bool bOutputless; // Offset: 0x65c // Size: 0x01
	bool bOutputTemplateGeos; // Offset: 0x65d // Size: 0x01
	bool bUseOutputNodes; // Offset: 0x65e // Size: 0x01
	char pad_0x65F[0x1]; // Offset: 0x65f // Size: 0x01
	struct FDirectoryPath TemporaryCookFolder; // Offset: 0x660 // Size: 0x10
	struct FDirectoryPath BakeFolder; // Offset: 0x670 // Size: 0x10
	enum class EHoudiniStaticMeshMethod StaticMeshMethod; // Offset: 0x680 // Size: 0x01
	char pad_0x681[0x7]; // Offset: 0x681 // Size: 0x07
	struct FHoudiniStaticMeshGenerationProperties StaticMeshGenerationProperties; // Offset: 0x688 // Size: 0x180
	struct FMeshBuildSettings StaticMeshBuildSettings; // Offset: 0x808 // Size: 0x30
	bool bOverrideGlobalProxyStaticMeshSettings; // Offset: 0x838 // Size: 0x01
	bool bEnableProxyStaticMeshOverride; // Offset: 0x839 // Size: 0x01
	bool bEnableProxyStaticMeshRefinementByTimerOverride; // Offset: 0x83a // Size: 0x01
	char pad_0x83B[0x1]; // Offset: 0x83b // Size: 0x01
	float ProxyMeshAutoRefineTimeoutSecondsOverride; // Offset: 0x83c // Size: 0x04
	bool bEnableProxyStaticMeshRefinementOnPreSaveWorldOverride; // Offset: 0x840 // Size: 0x01
	bool bEnableProxyStaticMeshRefinementOnPreBeginPIEOverride; // Offset: 0x841 // Size: 0x01
	char pad_0x842[0x2]; // Offset: 0x842 // Size: 0x02
	int32_t AssetId; // Offset: 0x844 // Size: 0x04
	struct TArray<int32_t> NodeIdsToCook; // Offset: 0x848 // Size: 0x10
	struct TMap<int32_t, int32_t> OutputNodeCookCounts; // Offset: 0x858 // Size: 0x50
	struct TSet<struct UHoudiniAssetComponent*> DownstreamHoudiniAssets; // Offset: 0x8a8 // Size: 0x50
	struct FGuid ComponentGUID; // Offset: 0x8f8 // Size: 0x10
	struct FGuid HapiGUID; // Offset: 0x908 // Size: 0x10
	struct FString HapiAssetName; // Offset: 0x918 // Size: 0x10
	enum class EHoudiniAssetState AssetState; // Offset: 0x928 // Size: 0x01
	enum class EHoudiniAssetState DebugLastAssetState; // Offset: 0x929 // Size: 0x01
	enum class EHoudiniAssetStateResult AssetStateResult; // Offset: 0x92a // Size: 0x01
	char pad_0x92B[0x5]; // Offset: 0x92b // Size: 0x05
	struct FTransform LastComponentTransform; // Offset: 0x930 // Size: 0x30
	uint32_t SubAssetIndex; // Offset: 0x960 // Size: 0x04
	int32_t AssetCookCount; // Offset: 0x964 // Size: 0x04
	bool bHasBeenLoaded; // Offset: 0x968 // Size: 0x01
	bool bHasBeenDuplicated; // Offset: 0x969 // Size: 0x01
	bool bPendingDelete; // Offset: 0x96a // Size: 0x01
	bool bRecookRequested; // Offset: 0x96b // Size: 0x01
	bool bRebuildRequested; // Offset: 0x96c // Size: 0x01
	bool bEnableCooking; // Offset: 0x96d // Size: 0x01
	bool bForceNeedUpdate; // Offset: 0x96e // Size: 0x01
	bool bLastCookSuccess; // Offset: 0x96f // Size: 0x01
	bool bParameterDefinitionUpdateNeeded; // Offset: 0x970 // Size: 0x01
	bool bBlueprintStructureModified; // Offset: 0x971 // Size: 0x01
	bool bBlueprintModified; // Offset: 0x972 // Size: 0x01
	char pad_0x973[0x5]; // Offset: 0x973 // Size: 0x05
	struct TArray<struct UHoudiniParameter*> Parameters; // Offset: 0x978 // Size: 0x10
	struct TArray<struct UHoudiniInput*> Inputs; // Offset: 0x988 // Size: 0x10
	struct TArray<struct UHoudiniOutput*> Outputs; // Offset: 0x998 // Size: 0x10
	struct TArray<struct FHoudiniBakedOutput> BakedOutputs; // Offset: 0x9a8 // Size: 0x10
	struct TArray<struct TWeakObjectPtr<struct AActor>> UntrackedOutputs; // Offset: 0x9b8 // Size: 0x10
	struct TArray<struct UHoudiniHandleComponent*> HandleComponents; // Offset: 0x9c8 // Size: 0x10
	bool bHasComponentTransformChanged; // Offset: 0x9d8 // Size: 0x01
	bool bFullyLoaded; // Offset: 0x9d9 // Size: 0x01
	char pad_0x9DA[0x6]; // Offset: 0x9da // Size: 0x06
	struct UHoudiniPDGAssetLink* PDGAssetLink; // Offset: 0x9e0 // Size: 0x08
	struct FTimerHandle RefineMeshesTimer; // Offset: 0x9e8 // Size: 0x08
	char pad_0x9F0[0x18]; // Offset: 0x9f0 // Size: 0x18
	bool bNoProxyMeshNextCookRequested; // Offset: 0xa08 // Size: 0x01
	char pad_0xA09[0x7]; // Offset: 0xa09 // Size: 0x07
	struct TMap<struct UObject*, int32_t> InputPresets; // Offset: 0xa10 // Size: 0x50
	bool bBakeAfterNextCook; // Offset: 0xa60 // Size: 0x01
	char pad_0xA61[0x7f]; // Offset: 0xa61 // Size: 0x7f
	bool bCachedIsPreview; // Offset: 0xae0 // Size: 0x01
	char pad_0xAE1[0xf]; // Offset: 0xae1 // Size: 0x0f
	double LastTickTime; // Offset: 0xaf0 // Size: 0x08
	char pad_0xAF8[0x18]; // Offset: 0xaf8 // Size: 0x18
};

// Object Name: Class HoudiniEngineRuntime.HoudiniAssetBlueprintComponent
// Size: 0xc10 // Inherited bytes: 0xb10
struct UHoudiniAssetBlueprintComponent : UHoudiniAssetComponent {
	// Fields
	char pad_0xB10[0x48]; // Offset: 0xb10 // Size: 0x48
	bool FauxBPProperty; // Offset: 0xb58 // Size: 0x01
	bool bHoudiniAssetChanged; // Offset: 0xb59 // Size: 0x01
	bool bUpdatedFromTemplate; // Offset: 0xb5a // Size: 0x01
	bool bIsInBlueprintEditor; // Offset: 0xb5b // Size: 0x01
	bool bCanDeleteHoudiniNodes; // Offset: 0xb5c // Size: 0x01
	bool bHasRegisteredComponentTemplate; // Offset: 0xb5d // Size: 0x01
	char pad_0xB5E[0xa]; // Offset: 0xb5e // Size: 0x0a
	struct TMap<struct FHoudiniOutputObjectIdentifier, struct FGuid> CachedOutputNodes; // Offset: 0xb68 // Size: 0x50
	struct TMap<struct FGuid, struct FGuid> CachedInputNodes; // Offset: 0xbb8 // Size: 0x50
	char pad_0xC08[0x8]; // Offset: 0xc08 // Size: 0x08

	// Functions

	// Object Name: Function HoudiniEngineRuntime.HoudiniAssetBlueprintComponent.SetToggleValueAt
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetToggleValueAt(struct FString Name, bool Value, int32_t Index); // Offset: 0x1010eeff0 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function HoudiniEngineRuntime.HoudiniAssetBlueprintComponent.SetFloatParameter
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetFloatParameter(struct FString Name, float Value, int32_t Index); // Offset: 0x1010ef170 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function HoudiniEngineRuntime.HoudiniAssetBlueprintComponent.HasParameter
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool HasParameter(struct FString Name); // Offset: 0x1010ef2e4 // Return & Params: Num(2) Size(0x11)
};

// Object Name: Class HoudiniEngineRuntime.HoudiniAssetParameter
// Size: 0x80 // Inherited bytes: 0x28
struct UHoudiniAssetParameter : UObject {
	// Fields
	char pad_0x28[0x58]; // Offset: 0x28 // Size: 0x58
};

// Object Name: Class HoudiniEngineRuntime.HoudiniAssetParameterButton
// Size: 0x80 // Inherited bytes: 0x80
struct UHoudiniAssetParameterButton : UHoudiniAssetParameter {
};

// Object Name: Class HoudiniEngineRuntime.HoudiniAssetParameterChoice
// Size: 0xb8 // Inherited bytes: 0x80
struct UHoudiniAssetParameterChoice : UHoudiniAssetParameter {
	// Fields
	char pad_0x80[0x38]; // Offset: 0x80 // Size: 0x38
};

// Object Name: Class HoudiniEngineRuntime.HoudiniAssetParameterColor
// Size: 0x90 // Inherited bytes: 0x80
struct UHoudiniAssetParameterColor : UHoudiniAssetParameter {
	// Fields
	char pad_0x80[0x10]; // Offset: 0x80 // Size: 0x10
};

// Object Name: Class HoudiniEngineRuntime.HoudiniAssetParameterFile
// Size: 0xa8 // Inherited bytes: 0x80
struct UHoudiniAssetParameterFile : UHoudiniAssetParameter {
	// Fields
	char pad_0x80[0x28]; // Offset: 0x80 // Size: 0x28
};

// Object Name: Class HoudiniEngineRuntime.HoudiniAssetParameterFloat
// Size: 0xb8 // Inherited bytes: 0x80
struct UHoudiniAssetParameterFloat : UHoudiniAssetParameter {
	// Fields
	char pad_0x80[0x38]; // Offset: 0x80 // Size: 0x38
};

// Object Name: Class HoudiniEngineRuntime.HoudiniAssetParameterFolder
// Size: 0x80 // Inherited bytes: 0x80
struct UHoudiniAssetParameterFolder : UHoudiniAssetParameter {
};

// Object Name: Class HoudiniEngineRuntime.HoudiniAssetParameterFolderList
// Size: 0x80 // Inherited bytes: 0x80
struct UHoudiniAssetParameterFolderList : UHoudiniAssetParameter {
};

// Object Name: Class HoudiniEngineRuntime.HoudiniAssetParameterInt
// Size: 0xb0 // Inherited bytes: 0x80
struct UHoudiniAssetParameterInt : UHoudiniAssetParameter {
	// Fields
	char pad_0x80[0x30]; // Offset: 0x80 // Size: 0x30
};

// Object Name: Class HoudiniEngineRuntime.HoudiniAssetParameterLabel
// Size: 0x80 // Inherited bytes: 0x80
struct UHoudiniAssetParameterLabel : UHoudiniAssetParameter {
};

// Object Name: Class HoudiniEngineRuntime.HoudiniAssetParameterMultiparm
// Size: 0x88 // Inherited bytes: 0x80
struct UHoudiniAssetParameterMultiparm : UHoudiniAssetParameter {
	// Fields
	char pad_0x80[0x8]; // Offset: 0x80 // Size: 0x08
};

// Object Name: Class HoudiniEngineRuntime.HoudiniAssetParameterRamp
// Size: 0x98 // Inherited bytes: 0x80
struct UHoudiniAssetParameterRamp : UHoudiniAssetParameter {
	// Fields
	char pad_0x80[0x18]; // Offset: 0x80 // Size: 0x18
};

// Object Name: Class HoudiniEngineRuntime.HoudiniAssetParameterSeparator
// Size: 0x80 // Inherited bytes: 0x80
struct UHoudiniAssetParameterSeparator : UHoudiniAssetParameter {
};

// Object Name: Class HoudiniEngineRuntime.HoudiniAssetParameterString
// Size: 0x90 // Inherited bytes: 0x80
struct UHoudiniAssetParameterString : UHoudiniAssetParameter {
	// Fields
	char pad_0x80[0x10]; // Offset: 0x80 // Size: 0x10
};

// Object Name: Class HoudiniEngineRuntime.HoudiniAssetParameterToggle
// Size: 0x90 // Inherited bytes: 0x80
struct UHoudiniAssetParameterToggle : UHoudiniAssetParameter {
	// Fields
	char pad_0x80[0x10]; // Offset: 0x80 // Size: 0x10
};

// Object Name: Class HoudiniEngineRuntime.HoudiniAssetComponentMaterials_V1
// Size: 0xc8 // Inherited bytes: 0x28
struct UHoudiniAssetComponentMaterials_V1 : UObject {
	// Fields
	char pad_0x28[0xa0]; // Offset: 0x28 // Size: 0xa0
};

// Object Name: Class HoudiniEngineRuntime.HoudiniHandleComponent_V1
// Size: 0x3e0 // Inherited bytes: 0x350
struct UHoudiniHandleComponent_V1 : USceneComponent {
	// Fields
	char pad_0x350[0x90]; // Offset: 0x350 // Size: 0x90
};

// Object Name: Class HoudiniEngineRuntime.HoudiniSplineComponent_V1
// Size: 0x440 // Inherited bytes: 0x350
struct UHoudiniSplineComponent_V1 : USceneComponent {
	// Fields
	char pad_0x350[0xf0]; // Offset: 0x350 // Size: 0xf0
};

// Object Name: Class HoudiniEngineRuntime.HoudiniAssetInput
// Size: 0x1a0 // Inherited bytes: 0x80
struct UHoudiniAssetInput : UHoudiniAssetParameter {
	// Fields
	char pad_0x80[0x120]; // Offset: 0x80 // Size: 0x120
};

// Object Name: Class HoudiniEngineRuntime.HoudiniAssetInstanceInput
// Size: 0x160 // Inherited bytes: 0x80
struct UHoudiniAssetInstanceInput : UHoudiniAssetParameter {
	// Fields
	char pad_0x80[0xe0]; // Offset: 0x80 // Size: 0xe0
};

// Object Name: Class HoudiniEngineRuntime.HoudiniAssetInstanceInputField
// Size: 0x190 // Inherited bytes: 0x28
struct UHoudiniAssetInstanceInputField : UObject {
	// Fields
	char pad_0x28[0x168]; // Offset: 0x28 // Size: 0x168
};

// Object Name: Class HoudiniEngineRuntime.HoudiniAssetComponent_V1
// Size: 0xa60 // Inherited bytes: 0x570
struct UHoudiniAssetComponent_V1 : UPrimitiveComponent {
	// Fields
	char bGeneratedDoubleSidedGeometry : 1; // Offset: 0x570 // Size: 0x01
	char pad_0x570_1 : 7; // Offset: 0x570 // Size: 0x01
	char pad_0x571[0x7]; // Offset: 0x571 // Size: 0x07
	struct UPhysicalMaterial* GeneratedPhysMaterial; // Offset: 0x578 // Size: 0x08
	struct FBodyInstance DefaultBodyInstance; // Offset: 0x580 // Size: 0x130
	enum class ECollisionTraceFlag GeneratedCollisionTraceFlag; // Offset: 0x6b0 // Size: 0x01
	char pad_0x6B1[0x3]; // Offset: 0x6b1 // Size: 0x03
	int32_t GeneratedLightMapResolution; // Offset: 0x6b4 // Size: 0x04
	float GeneratedDistanceFieldResolutionScale; // Offset: 0x6b8 // Size: 0x04
	struct FWalkableSlopeOverride GeneratedWalkableSlopeOverride; // Offset: 0x6bc // Size: 0x10
	int32_t GeneratedLightMapCoordinateIndex; // Offset: 0x6cc // Size: 0x04
	char bGeneratedUseMaximumStreamingTexelRatio : 1; // Offset: 0x6d0 // Size: 0x01
	char pad_0x6D0_1 : 7; // Offset: 0x6d0 // Size: 0x01
	char pad_0x6D1[0x3]; // Offset: 0x6d1 // Size: 0x03
	float GeneratedStreamingDistanceMultiplier; // Offset: 0x6d4 // Size: 0x04
	struct UFoliageType_InstancedStaticMesh* GeneratedFoliageDefaultSettings; // Offset: 0x6d8 // Size: 0x08
	struct TArray<struct UAssetUserData*> GeneratedAssetUserData; // Offset: 0x6e0 // Size: 0x10
	struct FText BakeFolder; // Offset: 0x6f0 // Size: 0x18
	struct FText TempCookFolder; // Offset: 0x708 // Size: 0x18
	char pad_0x720[0x340]; // Offset: 0x720 // Size: 0x340
};

// Object Name: Class HoudiniEngineRuntime.HoudiniInstancedActorComponent_V1
// Size: 0x360 // Inherited bytes: 0x350
struct UHoudiniInstancedActorComponent_V1 : USceneComponent {
	// Fields
	char pad_0x350[0x10]; // Offset: 0x350 // Size: 0x10
};

// Object Name: Class HoudiniEngineRuntime.HoudiniMeshSplitInstancerComponent_V1
// Size: 0x370 // Inherited bytes: 0x350
struct UHoudiniMeshSplitInstancerComponent_V1 : USceneComponent {
	// Fields
	char pad_0x350[0x20]; // Offset: 0x350 // Size: 0x20
};

// Object Name: Class HoudiniEngineRuntime.HoudiniEngineCopyPropertiesInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UHoudiniEngineCopyPropertiesInterface : UInterface {
};

// Object Name: Class HoudiniEngineRuntime.HoudiniHandleParameter
// Size: 0x38 // Inherited bytes: 0x28
struct UHoudiniHandleParameter : UObject {
	// Fields
	struct UHoudiniParameter* AssetParameter; // Offset: 0x28 // Size: 0x08
	int32_t TupleIndex; // Offset: 0x30 // Size: 0x04
	char pad_0x34[0x4]; // Offset: 0x34 // Size: 0x04
};

// Object Name: Class HoudiniEngineRuntime.HoudiniHandleComponent
// Size: 0x380 // Inherited bytes: 0x350
struct UHoudiniHandleComponent : USceneComponent {
	// Fields
	struct TArray<struct UHoudiniHandleParameter*> XformParms; // Offset: 0x348 // Size: 0x10
	struct UHoudiniHandleParameter* RSTParm; // Offset: 0x358 // Size: 0x08
	struct UHoudiniHandleParameter* RotOrderParm; // Offset: 0x360 // Size: 0x08
	enum class EHoudiniHandleType HandleType; // Offset: 0x368 // Size: 0x01
	struct FString HandleName; // Offset: 0x370 // Size: 0x10
};

// Object Name: Class HoudiniEngineRuntime.HoudiniInput
// Size: 0x278 // Inherited bytes: 0x28
struct UHoudiniInput : UObject {
	// Fields
	struct FString Name; // Offset: 0x28 // Size: 0x10
	struct FString Label; // Offset: 0x38 // Size: 0x10
	enum class EHoudiniInputType Type; // Offset: 0x48 // Size: 0x01
	enum class EHoudiniInputType PreviousType; // Offset: 0x49 // Size: 0x01
	char pad_0x4A[0x2]; // Offset: 0x4a // Size: 0x02
	int32_t AssetNodeId; // Offset: 0x4c // Size: 0x04
	int32_t InputNodeId; // Offset: 0x50 // Size: 0x04
	int32_t InputIndex; // Offset: 0x54 // Size: 0x04
	int32_t ParmId; // Offset: 0x58 // Size: 0x04
	bool bIsObjectPathParameter; // Offset: 0x5c // Size: 0x01
	char pad_0x5D[0x3]; // Offset: 0x5d // Size: 0x03
	struct TArray<int32_t> CreatedDataNodeIds; // Offset: 0x60 // Size: 0x10
	bool bHasChanged; // Offset: 0x70 // Size: 0x01
	bool bNeedsToTriggerUpdate; // Offset: 0x71 // Size: 0x01
	char pad_0x72[0x2]; // Offset: 0x72 // Size: 0x02
	struct FBox CachedBounds; // Offset: 0x74 // Size: 0x1c
	struct FString Help; // Offset: 0x90 // Size: 0x10
	enum class EHoudiniXformType KeepWorldTransform; // Offset: 0xa0 // Size: 0x01
	bool bPackBeforeMerge; // Offset: 0xa1 // Size: 0x01
	bool bImportAsReference; // Offset: 0xa2 // Size: 0x01
	bool bImportAsReferenceRotScaleEnabled; // Offset: 0xa3 // Size: 0x01
	bool bImportAsReferenceBboxEnabled; // Offset: 0xa4 // Size: 0x01
	bool bImportAsReferenceMaterialEnabled; // Offset: 0xa5 // Size: 0x01
	bool bExportLODs; // Offset: 0xa6 // Size: 0x01
	bool bExportSockets; // Offset: 0xa7 // Size: 0x01
	bool bExportColliders; // Offset: 0xa8 // Size: 0x01
	bool bExportMaterialParameters; // Offset: 0xa9 // Size: 0x01
	bool bCookOnCurveChanged; // Offset: 0xaa // Size: 0x01
	char pad_0xAB[0x5]; // Offset: 0xab // Size: 0x05
	struct TArray<struct UHoudiniInputObject*> GeometryInputObjects; // Offset: 0xb0 // Size: 0x10
	bool bStaticMeshChanged; // Offset: 0xc0 // Size: 0x01
	char pad_0xC1[0x7]; // Offset: 0xc1 // Size: 0x07
	struct TArray<struct UHoudiniInputObject*> AssetInputObjects; // Offset: 0xc8 // Size: 0x10
	bool bInputAssetConnectedInHoudini; // Offset: 0xd8 // Size: 0x01
	char pad_0xD9[0x7]; // Offset: 0xd9 // Size: 0x07
	struct TArray<struct UHoudiniInputObject*> CurveInputObjects; // Offset: 0xe0 // Size: 0x10
	float DefaultCurveOffset; // Offset: 0xf0 // Size: 0x04
	bool bAddRotAndScaleAttributesOnCurves; // Offset: 0xf4 // Size: 0x01
	bool bUseLegacyInputCurves; // Offset: 0xf5 // Size: 0x01
	char pad_0xF6[0x2]; // Offset: 0xf6 // Size: 0x02
	struct TArray<struct UHoudiniInputObject*> LandscapeInputObjects; // Offset: 0xf8 // Size: 0x10
	bool bLandscapeHasExportTypeChanged; // Offset: 0x108 // Size: 0x01
	char pad_0x109[0x7]; // Offset: 0x109 // Size: 0x07
	struct TArray<struct UHoudiniInputObject*> LandscapeSplinesInputObjects; // Offset: 0x110 // Size: 0x10
	struct TArray<struct UHoudiniInputObject*> FoliageInputObjects; // Offset: 0x120 // Size: 0x10
	struct TArray<struct UHoudiniInputObject*> WorldSMCInputObjects; // Offset: 0x130 // Size: 0x10
	struct TArray<struct UHoudiniInputObject*> PointCloudInputObjects; // Offset: 0x140 // Size: 0x10
	struct TArray<struct UHoudiniInputObject*> WorldInputObjects; // Offset: 0x150 // Size: 0x10
	struct TArray<struct UHoudiniInputObject*> TextureInputObjects; // Offset: 0x160 // Size: 0x10
	struct TArray<struct AActor*> WorldInputBoundSelectorObjects; // Offset: 0x170 // Size: 0x10
	bool bIsWorldInputBoundSelector; // Offset: 0x180 // Size: 0x01
	bool bWorldInputBoundSelectorAutoUpdate; // Offset: 0x181 // Size: 0x01
	char pad_0x182[0x2]; // Offset: 0x182 // Size: 0x02
	float UnrealSplineResolution; // Offset: 0x184 // Size: 0x04
	struct TArray<struct UHoudiniInputObject*> SkeletalInputObjects; // Offset: 0x188 // Size: 0x10
	struct TArray<struct UHoudiniInputObject*> GeometryCollectionInputObjects; // Offset: 0x198 // Size: 0x10
	struct TSet<struct ULandscapeComponent*> LandscapeSelectedComponents; // Offset: 0x1a8 // Size: 0x50
	struct TSet<int32_t> InputNodesPendingDelete; // Offset: 0x1f8 // Size: 0x50
	struct TArray<struct UHoudiniInputHoudiniSplineComponent*> LastInsertedInputs; // Offset: 0x248 // Size: 0x10
	struct TArray<struct UHoudiniInputObject*> LastUndoDeletedInputs; // Offset: 0x258 // Size: 0x10
	bool bUpdateInputLandscape; // Offset: 0x268 // Size: 0x01
	enum class EHoudiniLandscapeExportType LandscapeExportType; // Offset: 0x269 // Size: 0x01
	bool bLandscapeExportSelectionOnly; // Offset: 0x26a // Size: 0x01
	bool bLandscapeAutoSelectComponent; // Offset: 0x26b // Size: 0x01
	bool bLandscapeExportMaterials; // Offset: 0x26c // Size: 0x01
	bool bLandscapeExportLighting; // Offset: 0x26d // Size: 0x01
	bool bLandscapeExportNormalizedUVs; // Offset: 0x26e // Size: 0x01
	bool bLandscapeExportTileUVs; // Offset: 0x26f // Size: 0x01
	bool bCanDeleteHoudiniNodes; // Offset: 0x270 // Size: 0x01
	bool bAutoSelectInputType; // Offset: 0x271 // Size: 0x01
	bool bEnableSMCWorldFilter; // Offset: 0x272 // Size: 0x01
	bool bIsIncludeStaticMesh; // Offset: 0x273 // Size: 0x01
	bool bNeedSendModelMaterial; // Offset: 0x274 // Size: 0x01
	bool bNeedSendDataTableModel; // Offset: 0x275 // Size: 0x01
	bool bNeedSendFoliageInstanceCustomData; // Offset: 0x276 // Size: 0x01
	char pad_0x277[0x1]; // Offset: 0x277 // Size: 0x01
};

// Object Name: Class HoudiniEngineRuntime.HoudiniInputObject
// Size: 0xf0 // Inherited bytes: 0x28
struct UHoudiniInputObject : UObject {
	// Fields
	struct TSoftObjectPtr<UObject> InputObject; // Offset: 0x28 // Size: 0x28
	struct FTransform Transform; // Offset: 0x50 // Size: 0x30
	enum class EHoudiniInputObjectType Type; // Offset: 0x80 // Size: 0x01
	char pad_0x81[0x3]; // Offset: 0x81 // Size: 0x03
	int32_t InputNodeId; // Offset: 0x84 // Size: 0x04
	int32_t InputObjectNodeId; // Offset: 0x88 // Size: 0x04
	struct FGuid Guid; // Offset: 0x8c // Size: 0x10
	char pad_0x9C[0x2c]; // Offset: 0x9c // Size: 0x2c
	bool bHasChanged; // Offset: 0xc8 // Size: 0x01
	bool bNeedsToTriggerUpdate; // Offset: 0xc9 // Size: 0x01
	bool bTransformChanged; // Offset: 0xca // Size: 0x01
	bool bImportAsReference; // Offset: 0xcb // Size: 0x01
	bool bImportAsReferenceRotScaleEnabled; // Offset: 0xcc // Size: 0x01
	bool bImportAsReferenceBboxEnabled; // Offset: 0xcd // Size: 0x01
	bool bImportAsReferenceMaterialEnabled; // Offset: 0xce // Size: 0x01
	char pad_0xCF[0x1]; // Offset: 0xcf // Size: 0x01
	struct TArray<struct FString> MaterialReferences; // Offset: 0xd0 // Size: 0x10
	bool bCanDeleteHoudiniNodes; // Offset: 0xe0 // Size: 0x01
	char pad_0xE1[0xf]; // Offset: 0xe1 // Size: 0x0f
};

// Object Name: Class HoudiniEngineRuntime.HoudiniInputStaticMesh
// Size: 0xf0 // Inherited bytes: 0xf0
struct UHoudiniInputStaticMesh : UHoudiniInputObject {
};

// Object Name: Class HoudiniEngineRuntime.HoudiniInputTexture
// Size: 0xf0 // Inherited bytes: 0xf0
struct UHoudiniInputTexture : UHoudiniInputObject {
};

// Object Name: Class HoudiniEngineRuntime.HoudiniInputSkeletalMesh
// Size: 0xf0 // Inherited bytes: 0xf0
struct UHoudiniInputSkeletalMesh : UHoudiniInputObject {
};

// Object Name: Class HoudiniEngineRuntime.HoudiniInputGeometryCollection
// Size: 0xf0 // Inherited bytes: 0xf0
struct UHoudiniInputGeometryCollection : UHoudiniInputObject {
};

// Object Name: Class HoudiniEngineRuntime.HoudiniInputSceneComponent
// Size: 0x120 // Inherited bytes: 0xf0
struct UHoudiniInputSceneComponent : UHoudiniInputObject {
	// Fields
	struct FTransform ActorTransform; // Offset: 0xf0 // Size: 0x30
};

// Object Name: Class HoudiniEngineRuntime.HoudiniInputMeshComponent
// Size: 0x150 // Inherited bytes: 0x120
struct UHoudiniInputMeshComponent : UHoudiniInputSceneComponent {
	// Fields
	struct TSoftObjectPtr<UStaticMesh> StaticMesh; // Offset: 0x120 // Size: 0x28
	char pad_0x148[0x8]; // Offset: 0x148 // Size: 0x08
};

// Object Name: Class HoudiniEngineRuntime.HoudiniInputInstancedMeshComponent
// Size: 0x160 // Inherited bytes: 0x150
struct UHoudiniInputInstancedMeshComponent : UHoudiniInputMeshComponent {
	// Fields
	struct TArray<struct FTransform> InstanceTransforms; // Offset: 0x148 // Size: 0x10
};

// Object Name: Class HoudiniEngineRuntime.HoudiniInputLandscapeSplineComponent
// Size: 0x140 // Inherited bytes: 0x120
struct UHoudiniInputLandscapeSplineComponent : UHoudiniInputSceneComponent {
	// Fields
	int32_t NumberOfSplineControlPoints; // Offset: 0x120 // Size: 0x04
	float SplineLength; // Offset: 0x124 // Size: 0x04
	float SplineResolution; // Offset: 0x128 // Size: 0x04
	bool SplineClosed; // Offset: 0x12c // Size: 0x01
	char pad_0x12D[0x3]; // Offset: 0x12d // Size: 0x03
	struct TArray<struct FTransform> SplineControlPoints; // Offset: 0x130 // Size: 0x10
};

// Object Name: Class HoudiniEngineRuntime.HoudiniInputSplineComponent
// Size: 0x140 // Inherited bytes: 0x120
struct UHoudiniInputSplineComponent : UHoudiniInputSceneComponent {
	// Fields
	int32_t NumberOfSplineControlPoints; // Offset: 0x120 // Size: 0x04
	float SplineLength; // Offset: 0x124 // Size: 0x04
	float SplineResolution; // Offset: 0x128 // Size: 0x04
	bool SplineClosed; // Offset: 0x12c // Size: 0x01
	char pad_0x12D[0x3]; // Offset: 0x12d // Size: 0x03
	struct TArray<struct FTransform> SplineControlPoints; // Offset: 0x130 // Size: 0x10
};

// Object Name: Class HoudiniEngineRuntime.HoudiniInputGeometryCollectionComponent
// Size: 0x120 // Inherited bytes: 0x120
struct UHoudiniInputGeometryCollectionComponent : UHoudiniInputSceneComponent {
};

// Object Name: Class HoudiniEngineRuntime.HoudiniInputSkeletalMeshComponent
// Size: 0x120 // Inherited bytes: 0x120
struct UHoudiniInputSkeletalMeshComponent : UHoudiniInputSceneComponent {
};

// Object Name: Class HoudiniEngineRuntime.HoudiniInputHoudiniSplineComponent
// Size: 0xf0 // Inherited bytes: 0xf0
struct UHoudiniInputHoudiniSplineComponent : UHoudiniInputObject {
	// Fields
	enum class EHoudiniCurveType CurveType; // Offset: 0xe1 // Size: 0x01
	enum class EHoudiniCurveMethod CurveMethod; // Offset: 0xe2 // Size: 0x01
	bool Reversed; // Offset: 0xe3 // Size: 0x01
	struct UHoudiniSplineComponent* CachedComponent; // Offset: 0xe8 // Size: 0x08
};

// Object Name: Class HoudiniEngineRuntime.HoudiniInputCameraComponent
// Size: 0x140 // Inherited bytes: 0x120
struct UHoudiniInputCameraComponent : UHoudiniInputSceneComponent {
	// Fields
	float FOV; // Offset: 0x120 // Size: 0x04
	float AspectRatio; // Offset: 0x124 // Size: 0x04
	bool bIsOrthographic; // Offset: 0x128 // Size: 0x01
	char pad_0x129[0x3]; // Offset: 0x129 // Size: 0x03
	float OrthoWidth; // Offset: 0x12c // Size: 0x04
	float OrthoNearClipPlane; // Offset: 0x130 // Size: 0x04
	float OrthoFarClipPlane; // Offset: 0x134 // Size: 0x04
	char pad_0x138[0x8]; // Offset: 0x138 // Size: 0x08
};

// Object Name: Class HoudiniEngineRuntime.HoudiniInputHoudiniAsset
// Size: 0xf0 // Inherited bytes: 0xf0
struct UHoudiniInputHoudiniAsset : UHoudiniInputObject {
	// Fields
	int32_t AssetOutputIndex; // Offset: 0xe4 // Size: 0x04
};

// Object Name: Class HoudiniEngineRuntime.HoudiniInputActor
// Size: 0x150 // Inherited bytes: 0xf0
struct UHoudiniInputActor : UHoudiniInputObject {
	// Fields
	struct TArray<struct UHoudiniInputSceneComponent*> ActorComponents; // Offset: 0xe8 // Size: 0x10
	struct TSet<struct TSoftObjectPtr<UObject>> ActorSceneComponents; // Offset: 0xf8 // Size: 0x50
	int32_t LastUpdateNumComponentsAdded; // Offset: 0x148 // Size: 0x04
	int32_t LastUpdateNumComponentsRemoved; // Offset: 0x14c // Size: 0x04
};

// Object Name: Class HoudiniEngineRuntime.HoudiniInputLandscape
// Size: 0x250 // Inherited bytes: 0x150
struct UHoudiniInputLandscape : UHoudiniInputActor {
	// Fields
	struct FTransform CachedInputLandscapeTraqnsform; // Offset: 0x150 // Size: 0x30
	int32_t CachedNumLandscapeComponents; // Offset: 0x180 // Size: 0x04
	char pad_0x184[0x4]; // Offset: 0x184 // Size: 0x04
	struct FHoudiniInputLandscapeTransferParams TransferParams; // Offset: 0x188 // Size: 0xc8
};

// Object Name: Class HoudiniEngineRuntime.HoudiniInputInstancedFoliage
// Size: 0xf0 // Inherited bytes: 0xf0
struct UHoudiniInputInstancedFoliage : UHoudiniInputObject {
};

// Object Name: Class HoudiniEngineRuntime.HoudiniInputBrush
// Size: 0x170 // Inherited bytes: 0x150
struct UHoudiniInputBrush : UHoudiniInputActor {
	// Fields
	struct TArray<struct FHoudiniBrushInfo> BrushesInfo; // Offset: 0x150 // Size: 0x10
	struct UModel* CombinedModel; // Offset: 0x160 // Size: 0x08
	bool bIgnoreInputObject; // Offset: 0x168 // Size: 0x01
	enum class EBrushType CachedInputBrushType; // Offset: 0x169 // Size: 0x01
	char pad_0x16A[0x6]; // Offset: 0x16a // Size: 0x06
};

// Object Name: Class HoudiniEngineRuntime.HoudiniInputDataTable
// Size: 0xf0 // Inherited bytes: 0xf0
struct UHoudiniInputDataTable : UHoudiniInputObject {
};

// Object Name: Class HoudiniEngineRuntime.HoudiniInputFoliageType_InstancedStaticMesh
// Size: 0xf0 // Inherited bytes: 0xf0
struct UHoudiniInputFoliageType_InstancedStaticMesh : UHoudiniInputStaticMesh {
};

// Object Name: Class HoudiniEngineRuntime.HoudiniInputBlueprint
// Size: 0x150 // Inherited bytes: 0xf0
struct UHoudiniInputBlueprint : UHoudiniInputObject {
	// Fields
	struct TArray<struct UHoudiniInputSceneComponent*> BPComponents; // Offset: 0xe8 // Size: 0x10
	struct TSet<struct TSoftObjectPtr<UObject>> BPSceneComponents; // Offset: 0xf8 // Size: 0x50
	int32_t LastUpdateNumComponentsAdded; // Offset: 0x148 // Size: 0x04
	int32_t LastUpdateNumComponentsRemoved; // Offset: 0x14c // Size: 0x04
};

// Object Name: Class HoudiniEngineRuntime.HoudiniInstancedActorComponent
// Size: 0x360 // Inherited bytes: 0x350
struct UHoudiniInstancedActorComponent : USceneComponent {
	// Fields
	struct UObject* InstancedObject; // Offset: 0x348 // Size: 0x08
	struct TArray<struct AActor*> InstancedActors; // Offset: 0x350 // Size: 0x10
};

// Object Name: Class HoudiniEngineRuntime.HoudiniMeshSplitInstancerComponent
// Size: 0x370 // Inherited bytes: 0x350
struct UHoudiniMeshSplitInstancerComponent : USceneComponent {
	// Fields
	struct TArray<struct UStaticMeshComponent*> Instances; // Offset: 0x348 // Size: 0x10
	struct TArray<struct UMaterialInterface*> OverrideMaterials; // Offset: 0x358 // Size: 0x10
	struct UStaticMesh* InstancedMesh; // Offset: 0x368 // Size: 0x08
};

// Object Name: Class HoudiniEngineRuntime.HoudiniLandscapePtr
// Size: 0x60 // Inherited bytes: 0x28
struct UHoudiniLandscapePtr : UObject {
	// Fields
	struct TSoftObjectPtr<ALandscapeProxy> LandscapeSoftPtr; // Offset: 0x28 // Size: 0x28
	enum class EHoudiniLandscapeOutputBakeType BakeType; // Offset: 0x50 // Size: 0x01
	char pad_0x51[0x3]; // Offset: 0x51 // Size: 0x03
	struct FName EditLayerName; // Offset: 0x54 // Size: 0x08
	char pad_0x5C[0x4]; // Offset: 0x5c // Size: 0x04
};

// Object Name: Class HoudiniEngineRuntime.HoudiniLandscapeEditLayer
// Size: 0x60 // Inherited bytes: 0x28
struct UHoudiniLandscapeEditLayer : UObject {
	// Fields
	struct TSoftObjectPtr<ALandscapeProxy> LandscapeSoftPtr; // Offset: 0x28 // Size: 0x28
	struct FString LayerName; // Offset: 0x50 // Size: 0x10
};

// Object Name: Class HoudiniEngineRuntime.HoudiniOutput
// Size: 0x1b0 // Inherited bytes: 0x28
struct UHoudiniOutput : UObject {
	// Fields
	enum class EHoudiniOutputType Type; // Offset: 0x28 // Size: 0x01
	char pad_0x29[0x7]; // Offset: 0x29 // Size: 0x07
	struct TArray<struct FHoudiniGeoPartObject> HoudiniGeoPartObjects; // Offset: 0x30 // Size: 0x10
	struct TMap<struct FHoudiniOutputObjectIdentifier, struct FHoudiniOutputObject> OutputObjects; // Offset: 0x40 // Size: 0x50
	struct TMap<struct FHoudiniOutputObjectIdentifier, struct FHoudiniInstancedOutput> InstancedOutputs; // Offset: 0x90 // Size: 0x50
	struct TMap<struct FString, struct UMaterialInterface*> AssignementMaterials; // Offset: 0xe0 // Size: 0x50
	struct TMap<struct FString, struct UMaterialInterface*> ReplacementMaterials; // Offset: 0x130 // Size: 0x50
	char pad_0x180[0x4]; // Offset: 0x180 // Size: 0x04
	bool bLandscapeWorldComposition; // Offset: 0x184 // Size: 0x01
	char pad_0x185[0x3]; // Offset: 0x185 // Size: 0x03
	struct TArray<struct AActor*> HoudiniCreatedSocketActors; // Offset: 0x188 // Size: 0x10
	struct TArray<struct AActor*> HoudiniAttachedSocketActors; // Offset: 0x198 // Size: 0x10
	bool bIsEditableNode; // Offset: 0x1a8 // Size: 0x01
	bool bHasEditableNodeBuilt; // Offset: 0x1a9 // Size: 0x01
	bool bIsUpdating; // Offset: 0x1aa // Size: 0x01
	bool bCanDeleteHoudiniNodes; // Offset: 0x1ab // Size: 0x01
	char pad_0x1AC[0x4]; // Offset: 0x1ac // Size: 0x04
};

// Object Name: Class HoudiniEngineRuntime.TOPNode
// Size: 0x420 // Inherited bytes: 0x28
struct UTOPNode : UObject {
	// Fields
	int32_t NodeId; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
	struct FString NodeName; // Offset: 0x30 // Size: 0x10
	struct FString NodePath; // Offset: 0x40 // Size: 0x10
	struct FString ParentName; // Offset: 0x50 // Size: 0x10
	struct UObject* WorkResultParent; // Offset: 0x60 // Size: 0x08
	struct TArray<struct FTOPWorkResult> WorkResult; // Offset: 0x68 // Size: 0x10
	bool bHidden; // Offset: 0x78 // Size: 0x01
	bool bAutoLoad; // Offset: 0x79 // Size: 0x01
	enum class EPDGNodeState NodeState; // Offset: 0x7a // Size: 0x01
	bool bCachedHaveNotLoadedWorkResults; // Offset: 0x7b // Size: 0x01
	bool bCachedHaveLoadedWorkResults; // Offset: 0x7c // Size: 0x01
	bool bHasChildNodes; // Offset: 0x7d // Size: 0x01
	char pad_0x7E[0x2]; // Offset: 0x7e // Size: 0x02
	struct TSet<struct FString> ClearedLandscapeLayers; // Offset: 0x80 // Size: 0x50
	char pad_0xD0[0x80]; // Offset: 0xd0 // Size: 0x80
	bool bShow; // Offset: 0x150 // Size: 0x01
	char pad_0x151[0x7]; // Offset: 0x151 // Size: 0x07
	struct TMap<struct FString, struct FHoudiniPDGWorkResultObjectBakedOutput> BakedWorkResultObjectOutputs; // Offset: 0x158 // Size: 0x50
	struct FWorkItemTally WorkItemTally; // Offset: 0x1a8 // Size: 0x238
	struct FAggregatedWorkItemTally AggregatedWorkItemTally; // Offset: 0x3e0 // Size: 0x28
	bool bHasReceivedCookCompleteEvent; // Offset: 0x408 // Size: 0x01
	char pad_0x409[0x7]; // Offset: 0x409 // Size: 0x07
	struct FOutputActorOwner OutputActorOwner; // Offset: 0x410 // Size: 0x10
};

// Object Name: Class HoudiniEngineRuntime.TOPNetwork
// Size: 0x98 // Inherited bytes: 0x28
struct UTOPNetwork : UObject {
	// Fields
	int32_t NodeId; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
	struct FString NodeName; // Offset: 0x30 // Size: 0x10
	struct FString NodePath; // Offset: 0x40 // Size: 0x10
	struct TArray<struct UTOPNode*> AllTOPNodes; // Offset: 0x50 // Size: 0x10
	int32_t SelectedTOPIndex; // Offset: 0x60 // Size: 0x04
	char pad_0x64[0x4]; // Offset: 0x64 // Size: 0x04
	struct FString ParentName; // Offset: 0x68 // Size: 0x10
	bool bShowResults; // Offset: 0x78 // Size: 0x01
	bool bAutoLoadResults; // Offset: 0x79 // Size: 0x01
	char pad_0x7A[0x1e]; // Offset: 0x7a // Size: 0x1e
};

// Object Name: Class HoudiniEngineRuntime.HoudiniPDGAssetLink
// Size: 0x130 // Inherited bytes: 0x28
struct UHoudiniPDGAssetLink : UObject {
	// Fields
	struct FString AssetName; // Offset: 0x28 // Size: 0x10
	struct FString AssetNodePath; // Offset: 0x38 // Size: 0x10
	int32_t AssetId; // Offset: 0x48 // Size: 0x04
	char pad_0x4C[0x4]; // Offset: 0x4c // Size: 0x04
	struct TArray<struct UTOPNetwork*> AllTOPNetworks; // Offset: 0x50 // Size: 0x10
	int32_t SelectedTOPNetworkIndex; // Offset: 0x60 // Size: 0x04
	enum class EPDGLinkState LinkState; // Offset: 0x64 // Size: 0x01
	bool bAutoCook; // Offset: 0x65 // Size: 0x01
	bool bUseTOPNodeFilter; // Offset: 0x66 // Size: 0x01
	bool bUseTOPOutputFilter; // Offset: 0x67 // Size: 0x01
	struct FString TOPNodeFilter; // Offset: 0x68 // Size: 0x10
	struct FString TOPOutputFilter; // Offset: 0x78 // Size: 0x10
	int32_t NumWorkItems; // Offset: 0x88 // Size: 0x04
	char pad_0x8C[0x4]; // Offset: 0x8c // Size: 0x04
	struct FAggregatedWorkItemTally WorkItemTally; // Offset: 0x90 // Size: 0x28
	struct FString OutputCachePath; // Offset: 0xb8 // Size: 0x10
	bool bNeedsUIRefresh; // Offset: 0xc8 // Size: 0x01
	char pad_0xC9[0x7]; // Offset: 0xc9 // Size: 0x07
	struct AActor* OutputParentActor; // Offset: 0xd0 // Size: 0x08
	struct FDirectoryPath BakeFolder; // Offset: 0xd8 // Size: 0x10
	char pad_0xE8[0x48]; // Offset: 0xe8 // Size: 0x48
};

// Object Name: Class HoudiniEngineRuntime.HoudiniParameter
// Size: 0x108 // Inherited bytes: 0x28
struct UHoudiniParameter : UObject {
	// Fields
	struct FString Name; // Offset: 0x28 // Size: 0x10
	struct FString Label; // Offset: 0x38 // Size: 0x10
	enum class EHoudiniParameterType ParmType; // Offset: 0x48 // Size: 0x01
	char pad_0x49[0x3]; // Offset: 0x49 // Size: 0x03
	uint32_t TupleSize; // Offset: 0x4c // Size: 0x04
	int32_t NodeId; // Offset: 0x50 // Size: 0x04
	int32_t ParmId; // Offset: 0x54 // Size: 0x04
	int32_t ParentParmId; // Offset: 0x58 // Size: 0x04
	int32_t ChildIndex; // Offset: 0x5c // Size: 0x04
	bool bIsVisible; // Offset: 0x60 // Size: 0x01
	bool bIsParentFolderVisible; // Offset: 0x61 // Size: 0x01
	bool bIsDisabled; // Offset: 0x62 // Size: 0x01
	bool bHasChanged; // Offset: 0x63 // Size: 0x01
	bool bNeedsToTriggerUpdate; // Offset: 0x64 // Size: 0x01
	bool bIsDefault; // Offset: 0x65 // Size: 0x01
	bool bIsSpare; // Offset: 0x66 // Size: 0x01
	bool bJoinNext; // Offset: 0x67 // Size: 0x01
	bool bIsChildOfMultiParm; // Offset: 0x68 // Size: 0x01
	bool bIsDirectChildOfMultiParm; // Offset: 0x69 // Size: 0x01
	bool bPendingRevertToDefault; // Offset: 0x6a // Size: 0x01
	char pad_0x6B[0x5]; // Offset: 0x6b // Size: 0x05
	struct TArray<int32_t> TuplePendingRevertToDefault; // Offset: 0x70 // Size: 0x10
	struct FString Help; // Offset: 0x80 // Size: 0x10
	uint32_t TagCount; // Offset: 0x90 // Size: 0x04
	int32_t ValueIndex; // Offset: 0x94 // Size: 0x04
	bool bHasExpression; // Offset: 0x98 // Size: 0x01
	bool bShowExpression; // Offset: 0x99 // Size: 0x01
	char pad_0x9A[0x6]; // Offset: 0x9a // Size: 0x06
	struct FString ParamExpression; // Offset: 0xa0 // Size: 0x10
	struct TMap<struct FString, struct FString> Tags; // Offset: 0xb0 // Size: 0x50
	bool bAutoUpdate; // Offset: 0x100 // Size: 0x01
	char pad_0x101[0x7]; // Offset: 0x101 // Size: 0x07
};

// Object Name: Class HoudiniEngineRuntime.HoudiniParameterButton
// Size: 0x108 // Inherited bytes: 0x108
struct UHoudiniParameterButton : UHoudiniParameter {
};

// Object Name: Class HoudiniEngineRuntime.HoudiniParameterButtonStrip
// Size: 0x128 // Inherited bytes: 0x108
struct UHoudiniParameterButtonStrip : UHoudiniParameter {
	// Fields
	int32_t count; // Offset: 0x104 // Size: 0x04
	struct TArray<struct FString> Labels; // Offset: 0x108 // Size: 0x10
	struct TArray<int32_t> Values; // Offset: 0x118 // Size: 0x10
};

// Object Name: Class HoudiniEngineRuntime.HoudiniParameterChoice
// Size: 0x178 // Inherited bytes: 0x108
struct UHoudiniParameterChoice : UHoudiniParameter {
	// Fields
	int32_t IntValue; // Offset: 0x104 // Size: 0x04
	int32_t DefaultIntValue; // Offset: 0x108 // Size: 0x04
	struct FString StringValue; // Offset: 0x110 // Size: 0x10
	struct FString DefaultStringValue; // Offset: 0x120 // Size: 0x10
	struct TArray<struct FString> StringChoiceValues; // Offset: 0x130 // Size: 0x10
	struct TArray<struct FString> StringChoiceLabels; // Offset: 0x140 // Size: 0x10
	char pad_0x150[0x10]; // Offset: 0x150 // Size: 0x10
	bool bIsChildOfRamp; // Offset: 0x160 // Size: 0x01
	char pad_0x161[0x7]; // Offset: 0x161 // Size: 0x07
	struct TArray<int32_t> IntValuesArray; // Offset: 0x168 // Size: 0x10
};

// Object Name: Class HoudiniEngineRuntime.HoudiniParameterColor
// Size: 0x128 // Inherited bytes: 0x108
struct UHoudiniParameterColor : UHoudiniParameter {
	// Fields
	struct FLinearColor Color; // Offset: 0x104 // Size: 0x10
	struct FLinearColor DefaultColor; // Offset: 0x114 // Size: 0x10
	bool bIsChildOfRamp; // Offset: 0x124 // Size: 0x01
};

// Object Name: Class HoudiniEngineRuntime.HoudiniParameterFile
// Size: 0x140 // Inherited bytes: 0x108
struct UHoudiniParameterFile : UHoudiniParameter {
	// Fields
	struct TArray<struct FString> Values; // Offset: 0x108 // Size: 0x10
	struct TArray<struct FString> DefaultValues; // Offset: 0x118 // Size: 0x10
	struct FString Filters; // Offset: 0x128 // Size: 0x10
	bool bIsReadOnly; // Offset: 0x138 // Size: 0x01
	char pad_0x139[0x7]; // Offset: 0x139 // Size: 0x07
};

// Object Name: Class HoudiniEngineRuntime.HoudiniParameterFloat
// Size: 0x158 // Inherited bytes: 0x108
struct UHoudiniParameterFloat : UHoudiniParameter {
	// Fields
	struct TArray<float> Values; // Offset: 0x108 // Size: 0x10
	struct TArray<float> DefaultValues; // Offset: 0x118 // Size: 0x10
	struct FString Unit; // Offset: 0x128 // Size: 0x10
	bool bNoSwap; // Offset: 0x138 // Size: 0x01
	bool bHasMin; // Offset: 0x139 // Size: 0x01
	bool bHasMax; // Offset: 0x13a // Size: 0x01
	bool bHasUIMin; // Offset: 0x13b // Size: 0x01
	bool bHasUIMax; // Offset: 0x13c // Size: 0x01
	bool bIsLogarithmic; // Offset: 0x13d // Size: 0x01
	char pad_0x13E[0x2]; // Offset: 0x13e // Size: 0x02
	float Min; // Offset: 0x140 // Size: 0x04
	float Max; // Offset: 0x144 // Size: 0x04
	float UIMin; // Offset: 0x148 // Size: 0x04
	float UIMax; // Offset: 0x14c // Size: 0x04
	bool bIsChildOfRamp; // Offset: 0x150 // Size: 0x01
	char pad_0x151[0x7]; // Offset: 0x151 // Size: 0x07
};

// Object Name: Class HoudiniEngineRuntime.HoudiniParameterFolder
// Size: 0x110 // Inherited bytes: 0x108
struct UHoudiniParameterFolder : UHoudiniParameter {
	// Fields
	enum class EHoudiniFolderParameterType FolderType; // Offset: 0x101 // Size: 0x01
	bool bExpanded; // Offset: 0x102 // Size: 0x01
	bool bChosen; // Offset: 0x103 // Size: 0x01
	int32_t ChildCounter; // Offset: 0x104 // Size: 0x04
	bool bIsContentShown; // Offset: 0x108 // Size: 0x01
};

// Object Name: Class HoudiniEngineRuntime.HoudiniParameterFolderList
// Size: 0x118 // Inherited bytes: 0x108
struct UHoudiniParameterFolderList : UHoudiniParameter {
	// Fields
	bool bIsTabMenu; // Offset: 0x101 // Size: 0x01
	bool bIsTabsShown; // Offset: 0x102 // Size: 0x01
	struct TArray<struct UHoudiniParameterFolder*> TabFolders; // Offset: 0x108 // Size: 0x10
};

// Object Name: Class HoudiniEngineRuntime.HoudiniParameterInt
// Size: 0x150 // Inherited bytes: 0x108
struct UHoudiniParameterInt : UHoudiniParameter {
	// Fields
	struct TArray<int32_t> Values; // Offset: 0x108 // Size: 0x10
	struct TArray<int32_t> DefaultValues; // Offset: 0x118 // Size: 0x10
	struct FString Unit; // Offset: 0x128 // Size: 0x10
	bool bHasMin; // Offset: 0x138 // Size: 0x01
	bool bHasMax; // Offset: 0x139 // Size: 0x01
	bool bHasUIMin; // Offset: 0x13a // Size: 0x01
	bool bHasUIMax; // Offset: 0x13b // Size: 0x01
	bool bIsLogarithmic; // Offset: 0x13c // Size: 0x01
	char pad_0x13D[0x3]; // Offset: 0x13d // Size: 0x03
	int32_t Min; // Offset: 0x140 // Size: 0x04
	int32_t Max; // Offset: 0x144 // Size: 0x04
	int32_t UIMin; // Offset: 0x148 // Size: 0x04
	int32_t UIMax; // Offset: 0x14c // Size: 0x04
};

// Object Name: Class HoudiniEngineRuntime.HoudiniParameterLabel
// Size: 0x118 // Inherited bytes: 0x108
struct UHoudiniParameterLabel : UHoudiniParameter {
	// Fields
	struct TArray<struct FString> LabelStrings; // Offset: 0x108 // Size: 0x10
};

// Object Name: Class HoudiniEngineRuntime.HoudiniParameterMultiParm
// Size: 0x148 // Inherited bytes: 0x108
struct UHoudiniParameterMultiParm : UHoudiniParameter {
	// Fields
	bool bIsShown; // Offset: 0x101 // Size: 0x01
	int32_t Value; // Offset: 0x104 // Size: 0x04
	struct FString TemplateName; // Offset: 0x108 // Size: 0x10
	int32_t MultiparmValue; // Offset: 0x118 // Size: 0x04
	uint32_t MultiParmInstanceNum; // Offset: 0x11c // Size: 0x04
	uint32_t MultiParmInstanceLength; // Offset: 0x120 // Size: 0x04
	uint32_t MultiParmInstanceCount; // Offset: 0x124 // Size: 0x04
	uint32_t InstanceStartOffset; // Offset: 0x128 // Size: 0x04
	struct TArray<enum class EHoudiniMultiParmModificationType> MultiParmInstanceLastModifyArray; // Offset: 0x130 // Size: 0x10
	int32_t DefaultInstanceCount; // Offset: 0x140 // Size: 0x04
	char pad_0x145[0x3]; // Offset: 0x145 // Size: 0x03
};

// Object Name: Class HoudiniEngineRuntime.HoudiniParameterOperatorPath
// Size: 0x110 // Inherited bytes: 0x108
struct UHoudiniParameterOperatorPath : UHoudiniParameter {
	// Fields
	struct TWeakObjectPtr<struct UHoudiniInput> HoudiniInput; // Offset: 0x104 // Size: 0x08
};

// Object Name: Class HoudiniEngineRuntime.HoudiniParameterRampModificationEvent
// Size: 0x50 // Inherited bytes: 0x28
struct UHoudiniParameterRampModificationEvent : UObject {
	// Fields
	bool bIsInsertEvent; // Offset: 0x28 // Size: 0x01
	bool bIsFloatRamp; // Offset: 0x29 // Size: 0x01
	char pad_0x2A[0x2]; // Offset: 0x2a // Size: 0x02
	int32_t DeleteInstanceIndex; // Offset: 0x2c // Size: 0x04
	float InsertPosition; // Offset: 0x30 // Size: 0x04
	float InsertFloat; // Offset: 0x34 // Size: 0x04
	struct FLinearColor InsertColor; // Offset: 0x38 // Size: 0x10
	enum class EHoudiniRampInterpolationType InsertInterpolation; // Offset: 0x48 // Size: 0x01
	char pad_0x49[0x7]; // Offset: 0x49 // Size: 0x07
};

// Object Name: Class HoudiniEngineRuntime.HoudiniParameterRampFloatPoint
// Size: 0x50 // Inherited bytes: 0x28
struct UHoudiniParameterRampFloatPoint : UObject {
	// Fields
	float Position; // Offset: 0x28 // Size: 0x04
	float Value; // Offset: 0x2c // Size: 0x04
	enum class EHoudiniRampInterpolationType Interpolation; // Offset: 0x30 // Size: 0x01
	char pad_0x31[0x3]; // Offset: 0x31 // Size: 0x03
	int32_t InstanceIndex; // Offset: 0x34 // Size: 0x04
	struct UHoudiniParameterFloat* PositionParentParm; // Offset: 0x38 // Size: 0x08
	struct UHoudiniParameterFloat* ValueParentParm; // Offset: 0x40 // Size: 0x08
	struct UHoudiniParameterChoice* InterpolationParentParm; // Offset: 0x48 // Size: 0x08
};

// Object Name: Class HoudiniEngineRuntime.HoudiniParameterRampColorPoint
// Size: 0x60 // Inherited bytes: 0x28
struct UHoudiniParameterRampColorPoint : UObject {
	// Fields
	float Position; // Offset: 0x28 // Size: 0x04
	struct FLinearColor Value; // Offset: 0x2c // Size: 0x10
	enum class EHoudiniRampInterpolationType Interpolation; // Offset: 0x3c // Size: 0x01
	char pad_0x3D[0x3]; // Offset: 0x3d // Size: 0x03
	int32_t InstanceIndex; // Offset: 0x40 // Size: 0x04
	char pad_0x44[0x4]; // Offset: 0x44 // Size: 0x04
	struct UHoudiniParameterFloat* PositionParentParm; // Offset: 0x48 // Size: 0x08
	struct UHoudiniParameterColor* ValueParentParm; // Offset: 0x50 // Size: 0x08
	struct UHoudiniParameterChoice* InterpolationParentParm; // Offset: 0x58 // Size: 0x08
};

// Object Name: Class HoudiniEngineRuntime.HoudiniParameterRampFloat
// Size: 0x1b0 // Inherited bytes: 0x148
struct UHoudiniParameterRampFloat : UHoudiniParameterMultiParm {
	// Fields
	struct TArray<struct UHoudiniParameterRampFloatPoint*> Points; // Offset: 0x148 // Size: 0x10
	struct TArray<struct UHoudiniParameterRampFloatPoint*> CachedPoints; // Offset: 0x158 // Size: 0x10
	struct TArray<float> DefaultPositions; // Offset: 0x168 // Size: 0x10
	struct TArray<float> DefaultValues; // Offset: 0x178 // Size: 0x10
	struct TArray<int32_t> DefaultChoices; // Offset: 0x188 // Size: 0x10
	int32_t NumDefaultPoints; // Offset: 0x198 // Size: 0x04
	bool bCaching; // Offset: 0x19c // Size: 0x01
	char pad_0x19D[0x3]; // Offset: 0x19d // Size: 0x03
	struct TArray<struct UHoudiniParameterRampModificationEvent*> ModificationEvents; // Offset: 0x1a0 // Size: 0x10
};

// Object Name: Class HoudiniEngineRuntime.HoudiniParameterRampColor
// Size: 0x1b8 // Inherited bytes: 0x148
struct UHoudiniParameterRampColor : UHoudiniParameterMultiParm {
	// Fields
	struct TArray<struct UHoudiniParameterRampColorPoint*> Points; // Offset: 0x148 // Size: 0x10
	bool bCaching; // Offset: 0x158 // Size: 0x01
	char pad_0x159[0x7]; // Offset: 0x159 // Size: 0x07
	struct TArray<struct UHoudiniParameterRampColorPoint*> CachedPoints; // Offset: 0x160 // Size: 0x10
	struct TArray<float> DefaultPositions; // Offset: 0x170 // Size: 0x10
	struct TArray<struct FLinearColor> DefaultValues; // Offset: 0x180 // Size: 0x10
	struct TArray<int32_t> DefaultChoices; // Offset: 0x190 // Size: 0x10
	int32_t NumDefaultPoints; // Offset: 0x1a0 // Size: 0x04
	char pad_0x1A4[0x4]; // Offset: 0x1a4 // Size: 0x04
	struct TArray<struct UHoudiniParameterRampModificationEvent*> ModificationEvents; // Offset: 0x1a8 // Size: 0x10
};

// Object Name: Class HoudiniEngineRuntime.HoudiniParameterSeparator
// Size: 0x108 // Inherited bytes: 0x108
struct UHoudiniParameterSeparator : UHoudiniParameter {
};

// Object Name: Class HoudiniEngineRuntime.HoudiniParameterString
// Size: 0x140 // Inherited bytes: 0x108
struct UHoudiniParameterString : UHoudiniParameter {
	// Fields
	struct TArray<struct FString> Values; // Offset: 0x108 // Size: 0x10
	struct TArray<struct FString> DefaultValues; // Offset: 0x118 // Size: 0x10
	struct TArray<struct UObject*> ChosenAssets; // Offset: 0x128 // Size: 0x10
	bool bIsAssetRef; // Offset: 0x138 // Size: 0x01
	char pad_0x139[0x7]; // Offset: 0x139 // Size: 0x07
};

// Object Name: Class HoudiniEngineRuntime.HoudiniParameterToggle
// Size: 0x128 // Inherited bytes: 0x108
struct UHoudiniParameterToggle : UHoudiniParameter {
	// Fields
	struct TArray<int32_t> Values; // Offset: 0x108 // Size: 0x10
	struct TArray<int32_t> DefaultValues; // Offset: 0x118 // Size: 0x10
};

// Object Name: Class HoudiniEngineRuntime.HoudiniRuntimeSettings
// Size: 0x2d0 // Inherited bytes: 0x28
struct UHoudiniRuntimeSettings : UObject {
	// Fields
	enum class EHoudiniRuntimeSettingsSessionType SessionType; // Offset: 0x28 // Size: 0x01
	char pad_0x29[0x7]; // Offset: 0x29 // Size: 0x07
	struct FString ServerHost; // Offset: 0x30 // Size: 0x10
	int32_t ServerPort; // Offset: 0x40 // Size: 0x04
	char pad_0x44[0x4]; // Offset: 0x44 // Size: 0x04
	struct FString ServerPipeName; // Offset: 0x48 // Size: 0x10
	bool bStartAutomaticServer; // Offset: 0x58 // Size: 0x01
	char pad_0x59[0x3]; // Offset: 0x59 // Size: 0x03
	float AutomaticServerTimeout; // Offset: 0x5c // Size: 0x04
	bool bSyncWithHoudiniCook; // Offset: 0x60 // Size: 0x01
	bool bCookUsingHoudiniTime; // Offset: 0x61 // Size: 0x01
	bool bSyncViewport; // Offset: 0x62 // Size: 0x01
	bool bSyncHoudiniViewport; // Offset: 0x63 // Size: 0x01
	bool bSyncUnrealViewport; // Offset: 0x64 // Size: 0x01
	bool bShowMultiAssetDialog; // Offset: 0x65 // Size: 0x01
	bool bPreferHdaMemoryCopyOverHdaSourceFile; // Offset: 0x66 // Size: 0x01
	bool bPauseCookingOnStart; // Offset: 0x67 // Size: 0x01
	bool bDisplaySlateCookingNotifications; // Offset: 0x68 // Size: 0x01
	char pad_0x69[0x7]; // Offset: 0x69 // Size: 0x07
	struct FString DefaultTemporaryCookFolder; // Offset: 0x70 // Size: 0x10
	struct FString DefaultBakeFolder; // Offset: 0x80 // Size: 0x10
	bool bEnableTheReferenceCountedInputSystem; // Offset: 0x90 // Size: 0x01
	bool MarshallingLandscapesUseDefaultUnrealScaling; // Offset: 0x91 // Size: 0x01
	bool MarshallingLandscapesUseFullResolution; // Offset: 0x92 // Size: 0x01
	bool MarshallingLandscapesForceMinMaxValues; // Offset: 0x93 // Size: 0x01
	float MarshallingLandscapesForcedMinValue; // Offset: 0x94 // Size: 0x04
	float MarshallingLandscapesForcedMaxValue; // Offset: 0x98 // Size: 0x04
	bool bAddRotAndScaleAttributesOnCurves; // Offset: 0x9c // Size: 0x01
	bool bUseLegacyInputCurves; // Offset: 0x9d // Size: 0x01
	char pad_0x9E[0x2]; // Offset: 0x9e // Size: 0x02
	float MarshallingSplineResolution; // Offset: 0xa0 // Size: 0x04
	bool bEnableProxyStaticMesh; // Offset: 0xa4 // Size: 0x01
	bool bShowDefaultMesh; // Offset: 0xa5 // Size: 0x01
	bool bEnableProxyStaticMeshRefinementByTimer; // Offset: 0xa6 // Size: 0x01
	char pad_0xA7[0x1]; // Offset: 0xa7 // Size: 0x01
	float ProxyMeshAutoRefineTimeoutSeconds; // Offset: 0xa8 // Size: 0x04
	bool bEnableProxyStaticMeshRefinementOnPreSaveWorld; // Offset: 0xac // Size: 0x01
	bool bEnableProxyStaticMeshRefinementOnPreBeginPIE; // Offset: 0xad // Size: 0x01
	char bDoubleSidedGeometry : 1; // Offset: 0xae // Size: 0x01
	char pad_0xAE_1 : 7; // Offset: 0xae // Size: 0x01
	char pad_0xAF[0x1]; // Offset: 0xaf // Size: 0x01
	struct UPhysicalMaterial* PhysMaterial; // Offset: 0xb0 // Size: 0x08
	struct FBodyInstance DefaultBodyInstance; // Offset: 0xb8 // Size: 0x130
	enum class ECollisionTraceFlag CollisionTraceFlag; // Offset: 0x1e8 // Size: 0x01
	char pad_0x1E9[0x3]; // Offset: 0x1e9 // Size: 0x03
	int32_t LightMapResolution; // Offset: 0x1ec // Size: 0x04
	float LpvBiasMultiplier; // Offset: 0x1f0 // Size: 0x04
	float GeneratedDistanceFieldResolutionScale; // Offset: 0x1f4 // Size: 0x04
	struct FWalkableSlopeOverride WalkableSlopeOverride; // Offset: 0x1f8 // Size: 0x10
	int32_t LightMapCoordinateIndex; // Offset: 0x208 // Size: 0x04
	char bUseMaximumStreamingTexelRatio : 1; // Offset: 0x20c // Size: 0x01
	char pad_0x20C_1 : 7; // Offset: 0x20c // Size: 0x01
	char pad_0x20D[0x3]; // Offset: 0x20d // Size: 0x03
	float StreamingDistanceMultiplier; // Offset: 0x210 // Size: 0x04
	char pad_0x214[0x4]; // Offset: 0x214 // Size: 0x04
	struct UFoliageType_InstancedStaticMesh* FoliageDefaultSettings; // Offset: 0x218 // Size: 0x08
	struct TArray<struct UAssetUserData*> AssetUserData; // Offset: 0x220 // Size: 0x10
	bool bUseFullPrecisionUVs; // Offset: 0x230 // Size: 0x01
	char pad_0x231[0x3]; // Offset: 0x231 // Size: 0x03
	int32_t SrcLightmapIndex; // Offset: 0x234 // Size: 0x04
	int32_t DstLightmapIndex; // Offset: 0x238 // Size: 0x04
	int32_t MinLightmapResolution; // Offset: 0x23c // Size: 0x04
	bool bRemoveDegenerates; // Offset: 0x240 // Size: 0x01
	enum class EHoudiniRuntimeSettingsRecomputeFlag GenerateLightmapUVsFlag; // Offset: 0x241 // Size: 0x01
	enum class EHoudiniRuntimeSettingsRecomputeFlag RecomputeNormalsFlag; // Offset: 0x242 // Size: 0x01
	enum class EHoudiniRuntimeSettingsRecomputeFlag RecomputeTangentsFlag; // Offset: 0x243 // Size: 0x01
	bool bUseMikkTSpace; // Offset: 0x244 // Size: 0x01
	bool bBuildAdjacencyBuffer; // Offset: 0x245 // Size: 0x01
	char bComputeWeightedNormals : 1; // Offset: 0x246 // Size: 0x01
	char bBuildReversedIndexBuffer : 1; // Offset: 0x246 // Size: 0x01
	char bUseHighPrecisionTangentBasis : 1; // Offset: 0x246 // Size: 0x01
	char pad_0x246_3 : 5; // Offset: 0x246 // Size: 0x01
	char pad_0x247[0x1]; // Offset: 0x247 // Size: 0x01
	float DistanceFieldResolutionScale; // Offset: 0x248 // Size: 0x04
	char bGenerateDistanceFieldAsIfTwoSided : 1; // Offset: 0x24c // Size: 0x01
	char bSupportFaceRemap : 1; // Offset: 0x24c // Size: 0x01
	char pad_0x24C_2 : 6; // Offset: 0x24c // Size: 0x01
	bool bPDGAsyncCommandletImportEnabled; // Offset: 0x24d // Size: 0x01
	bool bEnableBackwardCompatibility; // Offset: 0x24e // Size: 0x01
	bool bAutomaticLegacyHDARebuild; // Offset: 0x24f // Size: 0x01
	bool bUseCustomHoudiniLocation; // Offset: 0x250 // Size: 0x01
	char pad_0x251[0x7]; // Offset: 0x251 // Size: 0x07
	struct FDirectoryPath CustomHoudiniLocation; // Offset: 0x258 // Size: 0x10
	enum class EHoudiniExecutableType HoudiniExecutable; // Offset: 0x268 // Size: 0x01
	char pad_0x269[0x3]; // Offset: 0x269 // Size: 0x03
	int32_t CookingThreadStackSize; // Offset: 0x26c // Size: 0x04
	struct FString HoudiniEnvironmentFiles; // Offset: 0x270 // Size: 0x10
	struct FString SyncNetDiscPath; // Offset: 0x280 // Size: 0x10
	struct FString OtlSearchPath; // Offset: 0x290 // Size: 0x10
	struct FString DsoSearchPath; // Offset: 0x2a0 // Size: 0x10
	struct FString ImageDsoSearchPath; // Offset: 0x2b0 // Size: 0x10
	struct FString AudioDsoSearchPath; // Offset: 0x2c0 // Size: 0x10
};

// Object Name: Class HoudiniEngineRuntime.HoudiniSplineComponent
// Size: 0x5f0 // Inherited bytes: 0x350
struct UHoudiniSplineComponent : USceneComponent {
	// Fields
	struct TArray<struct FTransform> CurvePoints; // Offset: 0x350 // Size: 0x10
	struct TArray<struct FVector> DisplayPoints; // Offset: 0x360 // Size: 0x10
	struct TArray<int32_t> DisplayPointIndexDivider; // Offset: 0x370 // Size: 0x10
	struct FString HoudiniSplineName; // Offset: 0x380 // Size: 0x10
	bool bClosed; // Offset: 0x390 // Size: 0x01
	bool bReversed; // Offset: 0x391 // Size: 0x01
	char pad_0x392[0x2]; // Offset: 0x392 // Size: 0x02
	int32_t CurveOrder; // Offset: 0x394 // Size: 0x04
	bool bIsHoudiniSplineVisible; // Offset: 0x398 // Size: 0x01
	enum class EHoudiniCurveType CurveType; // Offset: 0x399 // Size: 0x01
	enum class EHoudiniCurveMethod CurveMethod; // Offset: 0x39a // Size: 0x01
	enum class EHoudiniCurveBreakpointParameterization CurveBreakpointParameterization; // Offset: 0x39b // Size: 0x01
	bool bIsOutputCurve; // Offset: 0x39c // Size: 0x01
	bool bCookOnCurveChanged; // Offset: 0x39d // Size: 0x01
	bool bIsLegacyInputCurve; // Offset: 0x39e // Size: 0x01
	char pad_0x39F[0x231]; // Offset: 0x39f // Size: 0x231
	bool bHasChanged; // Offset: 0x5d0 // Size: 0x01
	bool bNeedsToTriggerUpdate; // Offset: 0x5d1 // Size: 0x01
	bool bIsInputCurve; // Offset: 0x5d2 // Size: 0x01
	bool bIsEditableOutputCurve; // Offset: 0x5d3 // Size: 0x01
	int32_t NodeId; // Offset: 0x5d4 // Size: 0x04
	struct FString PartName; // Offset: 0x5d8 // Size: 0x10
	char pad_0x5E8[0x8]; // Offset: 0x5e8 // Size: 0x08
};

// Object Name: Class HoudiniEngineRuntime.HoudiniStaticMesh
// Size: 0xc8 // Inherited bytes: 0x28
struct UHoudiniStaticMesh : UObject {
	// Fields
	bool bHasNormals; // Offset: 0x28 // Size: 0x01
	bool bHasTangents; // Offset: 0x29 // Size: 0x01
	bool bHasColors; // Offset: 0x2a // Size: 0x01
	char pad_0x2B[0x1]; // Offset: 0x2b // Size: 0x01
	uint32_t NumUVLayers; // Offset: 0x2c // Size: 0x04
	bool bHasPerFaceMaterials; // Offset: 0x30 // Size: 0x01
	char pad_0x31[0x7]; // Offset: 0x31 // Size: 0x07
	struct TArray<struct FVector> VertexPositions; // Offset: 0x38 // Size: 0x10
	struct TArray<struct FIntVector> TriangleIndices; // Offset: 0x48 // Size: 0x10
	struct TArray<struct FColor> VertexInstanceColors; // Offset: 0x58 // Size: 0x10
	struct TArray<struct FVector> VertexInstanceNormals; // Offset: 0x68 // Size: 0x10
	struct TArray<struct FVector> VertexInstanceUTangents; // Offset: 0x78 // Size: 0x10
	struct TArray<struct FVector> VertexInstanceVTangents; // Offset: 0x88 // Size: 0x10
	struct TArray<struct FVector2D> VertexInstanceUVs; // Offset: 0x98 // Size: 0x10
	struct TArray<int32_t> MaterialIDsPerTriangle; // Offset: 0xa8 // Size: 0x10
	struct TArray<struct FStaticMaterial> StaticMaterials; // Offset: 0xb8 // Size: 0x10

	// Functions

	// Object Name: Function HoudiniEngineRuntime.HoudiniStaticMesh.SetVertexPosition
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults]
	void SetVertexPosition(uint32_t InVertexIndex, struct FVector& InPosition); // Offset: 0x1011107e4 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function HoudiniEngineRuntime.HoudiniStaticMesh.SetTriangleVertexVTangent
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults]
	void SetTriangleVertexVTangent(uint32_t InTriangleIndex, char InTriangleVertexIndex, struct FVector& InVTangent); // Offset: 0x1011103c0 // Return & Params: Num(3) Size(0x14)

	// Object Name: Function HoudiniEngineRuntime.HoudiniStaticMesh.SetTriangleVertexUV
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults]
	void SetTriangleVertexUV(uint32_t InTriangleIndex, char InTriangleVertexIndex, char InUVLayer, struct FVector2D& InUV); // Offset: 0x10111013c // Return & Params: Num(4) Size(0x10)

	// Object Name: Function HoudiniEngineRuntime.HoudiniStaticMesh.SetTriangleVertexUTangent
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults]
	void SetTriangleVertexUTangent(uint32_t InTriangleIndex, char InTriangleVertexIndex, struct FVector& InUTangent); // Offset: 0x1011104dc // Return & Params: Num(3) Size(0x14)

	// Object Name: Function HoudiniEngineRuntime.HoudiniStaticMesh.SetTriangleVertexNormal
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults]
	void SetTriangleVertexNormal(uint32_t InTriangleIndex, char InTriangleVertexIndex, struct FVector& InNormal); // Offset: 0x1011105f8 // Return & Params: Num(3) Size(0x14)

	// Object Name: Function HoudiniEngineRuntime.HoudiniStaticMesh.SetTriangleVertexIndices
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults]
	void SetTriangleVertexIndices(uint32_t InTriangleIndex, struct FIntVector& InTriangleVertexIndices); // Offset: 0x101110714 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function HoudiniEngineRuntime.HoudiniStaticMesh.SetTriangleVertexColor
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults]
	void SetTriangleVertexColor(uint32_t InTriangleIndex, char InTriangleVertexIndex, struct FColor& InColor); // Offset: 0x1011102a4 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function HoudiniEngineRuntime.HoudiniStaticMesh.SetTriangleMaterialID
	// Flags: [Final|Native|Public]
	void SetTriangleMaterialID(uint32_t InTriangleIndex, int32_t InMaterialID); // Offset: 0x101110074 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function HoudiniEngineRuntime.HoudiniStaticMesh.SetStaticMaterial
	// Flags: [Final|Native|Public|HasOutParms]
	void SetStaticMaterial(uint32_t InMaterialIndex, struct FStaticMaterial& InStaticMaterial); // Offset: 0x10110ff60 // Return & Params: Num(2) Size(0x38)

	// Object Name: Function HoudiniEngineRuntime.HoudiniStaticMesh.SetNumUVLayers
	// Flags: [Final|Native|Public]
	void SetNumUVLayers(uint32_t InNumUVLayers); // Offset: 0x1011109a8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function HoudiniEngineRuntime.HoudiniStaticMesh.SetNumStaticMaterials
	// Flags: [Final|Native|Public]
	void SetNumStaticMaterials(uint32_t InNumStaticMaterials); // Offset: 0x10111090c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function HoudiniEngineRuntime.HoudiniStaticMesh.SetHasTangents
	// Flags: [Final|Native|Public]
	void SetHasTangents(bool bInHasTangents); // Offset: 0x101110ae8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function HoudiniEngineRuntime.HoudiniStaticMesh.SetHasPerFaceMaterials
	// Flags: [Final|Native|Public]
	void SetHasPerFaceMaterials(bool bInHasPerFaceMaterials); // Offset: 0x101110c30 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function HoudiniEngineRuntime.HoudiniStaticMesh.SetHasNormals
	// Flags: [Final|Native|Public]
	void SetHasNormals(bool bInHasNormals); // Offset: 0x101110b8c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function HoudiniEngineRuntime.HoudiniStaticMesh.SetHasColors
	// Flags: [Final|Native|Public]
	void SetHasColors(bool bInHasColors); // Offset: 0x101110a44 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function HoudiniEngineRuntime.HoudiniStaticMesh.Optimize
	// Flags: [Final|Native|Public]
	void Optimize(); // Offset: 0x10110fd28 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function HoudiniEngineRuntime.HoudiniStaticMesh.IsValid
	// Flags: [Final|Native|Public|Const]
	bool IsValid(bool bInSkipVertexIndicesCheck); // Offset: 0x10110f668 // Return & Params: Num(2) Size(0x2)

	// Object Name: Function HoudiniEngineRuntime.HoudiniStaticMesh.Initialize
	// Flags: [Final|Native|Public]
	void Initialize(uint32_t InNumVertices, uint32_t InNumTriangles, uint32_t InNumUVLayers, uint32_t InInitialNumStaticMaterials, bool bInHasNormals, bool bInHasTangents, bool bInHasColors, bool bInHasPerFaceMaterials); // Offset: 0x101110cd4 // Return & Params: Num(8) Size(0x14)

	// Object Name: Function HoudiniEngineRuntime.HoudiniStaticMesh.HasTangents
	// Flags: [Final|Native|Public|Const]
	bool HasTangents(); // Offset: 0x101110b70 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function HoudiniEngineRuntime.HoudiniStaticMesh.HasPerFaceMaterials
	// Flags: [Final|Native|Public|Const]
	bool HasPerFaceMaterials(); // Offset: 0x101110cb8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function HoudiniEngineRuntime.HoudiniStaticMesh.HasNormals
	// Flags: [Final|Native|Public|Const]
	bool HasNormals(); // Offset: 0x101110c14 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function HoudiniEngineRuntime.HoudiniStaticMesh.HasColors
	// Flags: [Final|Native|Public|Const]
	bool HasColors(); // Offset: 0x101110acc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function HoudiniEngineRuntime.HoudiniStaticMesh.GetVertexPositions
	// Flags: [Final|Native|Public|Const]
	struct TArray<struct FVector> GetVertexPositions(); // Offset: 0x10110fc54 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function HoudiniEngineRuntime.HoudiniStaticMesh.GetVertexInstanceVTangents
	// Flags: [Final|Native|Public|Const]
	struct TArray<struct FVector> GetVertexInstanceVTangents(); // Offset: 0x10110f9b0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function HoudiniEngineRuntime.HoudiniStaticMesh.GetVertexInstanceUVs
	// Flags: [Final|Native|Public|Const]
	struct TArray<struct FVector2D> GetVertexInstanceUVs(); // Offset: 0x10110f92c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function HoudiniEngineRuntime.HoudiniStaticMesh.GetVertexInstanceUTangents
	// Flags: [Final|Native|Public|Const]
	struct TArray<struct FVector> GetVertexInstanceUTangents(); // Offset: 0x10110fa38 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function HoudiniEngineRuntime.HoudiniStaticMesh.GetVertexInstanceNormals
	// Flags: [Final|Native|Public|Const]
	struct TArray<struct FVector> GetVertexInstanceNormals(); // Offset: 0x10110fac0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function HoudiniEngineRuntime.HoudiniStaticMesh.GetVertexInstanceColors
	// Flags: [Final|Native|Public|Const]
	struct TArray<struct FColor> GetVertexInstanceColors(); // Offset: 0x10110fb48 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function HoudiniEngineRuntime.HoudiniStaticMesh.GetTriangleIndices
	// Flags: [Final|Native|Public|Const]
	struct TArray<struct FIntVector> GetTriangleIndices(); // Offset: 0x10110fbcc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function HoudiniEngineRuntime.HoudiniStaticMesh.GetStaticMaterials
	// Flags: [Final|Native|Public|Const]
	struct TArray<struct FStaticMaterial> GetStaticMaterials(); // Offset: 0x10110f820 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function HoudiniEngineRuntime.HoudiniStaticMesh.GetNumVertices
	// Flags: [Final|Native|Public|Const]
	uint32_t GetNumVertices(); // Offset: 0x1011108f0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function HoudiniEngineRuntime.HoudiniStaticMesh.GetNumVertexInstances
	// Flags: [Final|Native|Public|Const]
	uint32_t GetNumVertexInstances(); // Offset: 0x1011108b4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function HoudiniEngineRuntime.HoudiniStaticMesh.GetNumUVLayers
	// Flags: [Final|Native|Public|Const]
	uint32_t GetNumUVLayers(); // Offset: 0x101110a28 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function HoudiniEngineRuntime.HoudiniStaticMesh.GetNumTriangles
	// Flags: [Final|Native|Public|Const]
	uint32_t GetNumTriangles(); // Offset: 0x1011108d4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function HoudiniEngineRuntime.HoudiniStaticMesh.GetNumStaticMaterials
	// Flags: [Final|Native|Public|Const]
	uint32_t GetNumStaticMaterials(); // Offset: 0x10111098c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function HoudiniEngineRuntime.HoudiniStaticMesh.GetMaterialIndex
	// Flags: [Final|Native|Public|Const]
	int32_t GetMaterialIndex(struct FName InMaterialSlotName); // Offset: 0x10110f700 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function HoudiniEngineRuntime.HoudiniStaticMesh.GetMaterialIDsPerTriangle
	// Flags: [Final|Native|Public|Const]
	struct TArray<int32_t> GetMaterialIDsPerTriangle(); // Offset: 0x10110f8a8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function HoudiniEngineRuntime.HoudiniStaticMesh.GetMaterial
	// Flags: [Final|Native|Public]
	struct UMaterialInterface* GetMaterial(int32_t InMaterialIndex); // Offset: 0x10110f790 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function HoudiniEngineRuntime.HoudiniStaticMesh.CalculateTangents
	// Flags: [Final|Native|Public]
	void CalculateTangents(bool bInComputeWeightedNormals); // Offset: 0x10110fd3c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function HoudiniEngineRuntime.HoudiniStaticMesh.CalculateNormals
	// Flags: [Final|Native|Public]
	void CalculateNormals(bool bInComputeWeightedNormals); // Offset: 0x10110fdc4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function HoudiniEngineRuntime.HoudiniStaticMesh.CalcBounds
	// Flags: [Final|Native|Public|HasDefaults|Const]
	struct FBox CalcBounds(); // Offset: 0x10110fcdc // Return & Params: Num(1) Size(0x1c)

	// Object Name: Function HoudiniEngineRuntime.HoudiniStaticMesh.AddStaticMaterial
	// Flags: [Final|Native|Public|HasOutParms]
	uint32_t AddStaticMaterial(struct FStaticMaterial& InStaticMaterial); // Offset: 0x10110fe4c // Return & Params: Num(2) Size(0x34)
};

// Object Name: Class HoudiniEngineRuntime.HoudiniStaticMeshComponent
// Size: 0x5d0 // Inherited bytes: 0x5b0
struct UHoudiniStaticMeshComponent : UMeshComponent {
	// Fields
	struct UHoudiniStaticMesh* Mesh; // Offset: 0x5a8 // Size: 0x08
	struct FBox LocalBounds; // Offset: 0x5b0 // Size: 0x1c
	bool bHoudiniIconVisible; // Offset: 0x5cc // Size: 0x01

	// Functions

	// Object Name: Function HoudiniEngineRuntime.HoudiniStaticMeshComponent.SetMesh
	// Flags: [Final|Native|Public]
	void SetMesh(struct UHoudiniStaticMesh* InMesh); // Offset: 0x10111254c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function HoudiniEngineRuntime.HoudiniStaticMeshComponent.SetHoudiniIconVisible
	// Flags: [Final|Native|Public]
	void SetHoudiniIconVisible(bool bInHoudiniIconVisible); // Offset: 0x101112478 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function HoudiniEngineRuntime.HoudiniStaticMeshComponent.NotifyMeshUpdated
	// Flags: [Final|Native|Public]
	void NotifyMeshUpdated(); // Offset: 0x10111251c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function HoudiniEngineRuntime.HoudiniStaticMeshComponent.IsHoudiniIconVisible
	// Flags: [Final|Native|Public|Const]
	bool IsHoudiniIconVisible(); // Offset: 0x101112500 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function HoudiniEngineRuntime.HoudiniStaticMeshComponent.GetMesh
	// Flags: [Final|Native|Public]
	struct UHoudiniStaticMesh* GetMesh(); // Offset: 0x101112530 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class HoudiniEngineRuntime.HoudiniAssetStateEvents
// Size: 0x28 // Inherited bytes: 0x28
struct UHoudiniAssetStateEvents : UInterface {
};

