#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class ImageWriteQueue.ImageWriteBlueprintLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct UImageWriteBlueprintLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function ImageWriteQueue.ImageWriteBlueprintLibrary.ExportToDisk
	// Flags: [Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable]
	void ExportToDisk(struct UTexture* Texture, struct FString Filename, struct FImageWriteOptions& options); // Offset: 0x1037195d4 // Return & Params: Num(3) Size(0x80)
};

