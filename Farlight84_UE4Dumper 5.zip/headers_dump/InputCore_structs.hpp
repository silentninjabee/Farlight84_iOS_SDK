#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct InputCore.Key
// Size: 0x18 // Inherited bytes: 0x00
struct FKey {
	// Fields
	struct FName KeyName; // Offset: 0x00 // Size: 0x08
	char pad_0x8[0x10]; // Offset: 0x08 // Size: 0x10
};

