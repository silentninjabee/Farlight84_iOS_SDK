#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct InteractiveToolsFramework.BrushStampData
// Size: 0xa8 // Inherited bytes: 0x00
struct FBrushStampData {
	// Fields
	char pad_0x0[0xa8]; // Offset: 0x00 // Size: 0xa8
};

// Object Name: ScriptStruct InteractiveToolsFramework.BehaviorInfo
// Size: 0x20 // Inherited bytes: 0x00
struct FBehaviorInfo {
	// Fields
	struct UInputBehavior* Behavior; // Offset: 0x00 // Size: 0x08
	char pad_0x8[0x18]; // Offset: 0x08 // Size: 0x18
};

// Object Name: ScriptStruct InteractiveToolsFramework.InputRayHit
// Size: 0x28 // Inherited bytes: 0x00
struct FInputRayHit {
	// Fields
	char pad_0x0[0x28]; // Offset: 0x00 // Size: 0x28
};

// Object Name: ScriptStruct InteractiveToolsFramework.ActiveGizmo
// Size: 0x30 // Inherited bytes: 0x00
struct FActiveGizmo {
	// Fields
	char pad_0x0[0x30]; // Offset: 0x00 // Size: 0x30
};

// Object Name: ScriptStruct InteractiveToolsFramework.GizmoFloatParameterChange
// Size: 0x08 // Inherited bytes: 0x00
struct FGizmoFloatParameterChange {
	// Fields
	float InitialValue; // Offset: 0x00 // Size: 0x04
	float CurrentValue; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct InteractiveToolsFramework.GizmoVec2ParameterChange
// Size: 0x10 // Inherited bytes: 0x00
struct FGizmoVec2ParameterChange {
	// Fields
	struct FVector2D InitialValue; // Offset: 0x00 // Size: 0x08
	struct FVector2D CurrentValue; // Offset: 0x08 // Size: 0x08
};

