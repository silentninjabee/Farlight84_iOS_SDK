#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class Landscape.ControlPointMeshActor
// Size: 0x230 // Inherited bytes: 0x228
struct AControlPointMeshActor : AActor {
	// Fields
	struct UControlPointMeshComponent* ControlPointMeshComponent; // Offset: 0x228 // Size: 0x08
};

// Object Name: Class Landscape.ControlPointMeshComponent
// Size: 0x630 // Inherited bytes: 0x630
struct UControlPointMeshComponent : UStaticMeshComponent {
	// Fields
	float VirtualTextureMainPassMaxDrawDistance; // Offset: 0x624 // Size: 0x04
};

// Object Name: Class Landscape.LandscapeProxy
// Size: 0x560 // Inherited bytes: 0x228
struct ALandscapeProxy : AActor {
	// Fields
	struct ULandscapeSplinesComponent* SplineComponent; // Offset: 0x228 // Size: 0x08
	struct FGuid LandscapeGuid; // Offset: 0x230 // Size: 0x10
	struct FIntPoint LandscapeSectionOffset; // Offset: 0x240 // Size: 0x08
	int32_t MaxLODLevel; // Offset: 0x248 // Size: 0x04
	float LODDistanceFactor; // Offset: 0x24c // Size: 0x04
	enum class ELandscapeLODFalloff LODFalloff; // Offset: 0x250 // Size: 0x01
	char pad_0x251[0x3]; // Offset: 0x251 // Size: 0x03
	float ComponentScreenSizeToUseSubSections; // Offset: 0x254 // Size: 0x04
	float LOD0ScreenSize; // Offset: 0x258 // Size: 0x04
	float LOD0DistributionSetting; // Offset: 0x25c // Size: 0x04
	float LODDistributionSetting; // Offset: 0x260 // Size: 0x04
	float TessellationComponentScreenSize; // Offset: 0x264 // Size: 0x04
	bool UseTessellationComponentScreenSizeFalloff; // Offset: 0x268 // Size: 0x01
	char pad_0x269[0x3]; // Offset: 0x269 // Size: 0x03
	float TessellationComponentScreenSizeFalloff; // Offset: 0x26c // Size: 0x04
	int32_t OccluderGeometryLOD; // Offset: 0x270 // Size: 0x04
	int32_t StaticLightingLOD; // Offset: 0x274 // Size: 0x04
	struct UPhysicalMaterial* DefaultPhysMaterial; // Offset: 0x278 // Size: 0x08
	float StreamingDistanceMultiplier; // Offset: 0x280 // Size: 0x04
	char pad_0x284[0x4]; // Offset: 0x284 // Size: 0x04
	struct UMaterialInterface* LandscapeMaterial; // Offset: 0x288 // Size: 0x08
	char pad_0x290[0x20]; // Offset: 0x290 // Size: 0x20
	struct UMaterialInterface* LandscapeHoleMaterial; // Offset: 0x2b0 // Size: 0x08
	struct TArray<struct FLandscapeProxyMaterialOverride> LandscapeMaterialsOverride; // Offset: 0x2b8 // Size: 0x10
	bool bMeshHoles; // Offset: 0x2c8 // Size: 0x01
	char MeshHolesMaxLod; // Offset: 0x2c9 // Size: 0x01
	char pad_0x2CA[0x6]; // Offset: 0x2ca // Size: 0x06
	struct TArray<struct URuntimeVirtualTexture*> RuntimeVirtualTextures; // Offset: 0x2d0 // Size: 0x10
	int32_t VirtualTextureNumLods; // Offset: 0x2e0 // Size: 0x04
	int32_t VirtualTextureLodBias; // Offset: 0x2e4 // Size: 0x04
	enum class ERuntimeVirtualTextureMainPassType VirtualTextureRenderPassType; // Offset: 0x2e8 // Size: 0x01
	char pad_0x2E9[0x3]; // Offset: 0x2e9 // Size: 0x03
	float NegativeZBoundsExtension; // Offset: 0x2ec // Size: 0x04
	float PositiveZBoundsExtension; // Offset: 0x2f0 // Size: 0x04
	char pad_0x2F4[0x4]; // Offset: 0x2f4 // Size: 0x04
	struct TArray<struct ULandscapeComponent*> LandscapeComponents; // Offset: 0x2f8 // Size: 0x10
	struct TArray<struct ULandscapeHeightfieldCollisionComponent*> CollisionComponents; // Offset: 0x308 // Size: 0x10
	struct TArray<struct UHierarchicalInstancedStaticMeshComponent*> FoliageComponents; // Offset: 0x318 // Size: 0x10
	char pad_0x328[0x64]; // Offset: 0x328 // Size: 0x64
	bool bHasLandscapeGrass; // Offset: 0x38c // Size: 0x01
	char pad_0x38D[0x3]; // Offset: 0x38d // Size: 0x03
	float StaticLightingResolution; // Offset: 0x390 // Size: 0x04
	char bCastStaticShadow : 1; // Offset: 0x394 // Size: 0x01
	char bCastShadowAsTwoSided : 1; // Offset: 0x394 // Size: 0x01
	char bCastFarShadow : 1; // Offset: 0x394 // Size: 0x01
	char bAffectDistanceFieldLighting : 1; // Offset: 0x394 // Size: 0x01
	char pad_0x394_4 : 4; // Offset: 0x394 // Size: 0x01
	struct FLightingChannels LightingChannels; // Offset: 0x395 // Size: 0x01
	char bUseMaterialPositionOffsetInStaticLighting : 1; // Offset: 0x396 // Size: 0x01
	char bRenderCustomDepth : 1; // Offset: 0x396 // Size: 0x01
	char pad_0x396_2 : 6; // Offset: 0x396 // Size: 0x01
	char pad_0x397[0x1]; // Offset: 0x397 // Size: 0x01
	int32_t CustomDepthStencilValue; // Offset: 0x398 // Size: 0x04
	float LDMaxDrawDistance; // Offset: 0x39c // Size: 0x04
	struct FLightmassPrimitiveSettings LightmassSettings; // Offset: 0x3a0 // Size: 0x18
	int32_t CollisionMipLevel; // Offset: 0x3b8 // Size: 0x04
	int32_t SimpleCollisionMipLevel; // Offset: 0x3bc // Size: 0x04
	float CollisionThickness; // Offset: 0x3c0 // Size: 0x04
	char pad_0x3C4[0x4]; // Offset: 0x3c4 // Size: 0x04
	struct FBodyInstance BodyInstance; // Offset: 0x3c8 // Size: 0x130
	char bGenerateOverlapEvents : 1; // Offset: 0x4f8 // Size: 0x01
	char bBakeMaterialPositionOffsetIntoCollision : 1; // Offset: 0x4f8 // Size: 0x01
	char pad_0x4F8_2 : 6; // Offset: 0x4f8 // Size: 0x01
	char pad_0x4F9[0x3]; // Offset: 0x4f9 // Size: 0x03
	int32_t ComponentSizeQuads; // Offset: 0x4fc // Size: 0x04
	int32_t SubsectionSizeQuads; // Offset: 0x500 // Size: 0x04
	int32_t NumSubsections; // Offset: 0x504 // Size: 0x04
	char bUsedForNavigation : 1; // Offset: 0x508 // Size: 0x01
	char bFillCollisionUnderLandscapeForNavmesh : 1; // Offset: 0x508 // Size: 0x01
	char pad_0x508_2 : 6; // Offset: 0x508 // Size: 0x01
	bool bUseDynamicMaterialInstance; // Offset: 0x509 // Size: 0x01
	enum class ENavDataGatheringMode NavigationGeometryGatheringMode; // Offset: 0x50a // Size: 0x01
	bool bUseLandscapeForCullingInvisibleHLODVertices; // Offset: 0x50b // Size: 0x01
	bool bHasLayersContent; // Offset: 0x50c // Size: 0x01
	char pad_0x50D[0x3]; // Offset: 0x50d // Size: 0x03
	struct TMap<struct UTexture2D*, struct ULandscapeWeightmapUsage*> WeightmapUsageMap; // Offset: 0x510 // Size: 0x50

	// Functions

	// Object Name: Function Landscape.LandscapeProxy.SetLandscapeMaterialVectorParameterValue
	// Flags: [Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable]
	void SetLandscapeMaterialVectorParameterValue(struct FName ParameterName, struct FLinearColor Value); // Offset: 0x1040079b0 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Landscape.LandscapeProxy.SetLandscapeMaterialTextureParameterValue
	// Flags: [Final|RequiredAPI|Native|Public|BlueprintCallable]
	void SetLandscapeMaterialTextureParameterValue(struct FName ParameterName, struct UTexture* Value); // Offset: 0x104007a78 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Landscape.LandscapeProxy.SetLandscapeMaterialScalarParameterValue
	// Flags: [Final|RequiredAPI|Native|Public|BlueprintCallable]
	void SetLandscapeMaterialScalarParameterValue(struct FName ParameterName, float Value); // Offset: 0x1040078e4 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Landscape.LandscapeProxy.EditorSetLandscapeMaterial
	// Flags: [Final|Native|Public|BlueprintCallable]
	void EditorSetLandscapeMaterial(struct UMaterialInterface* NewLandscapeMaterial); // Offset: 0x104007ed0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Landscape.LandscapeProxy.EditorApplySpline
	// Flags: [Final|Native|Public|BlueprintCallable]
	void EditorApplySpline(struct USplineComponent* InSplineComponent, float StartWidth, float EndWidth, float StartSideFalloff, float EndSideFalloff, float StartRoll, float EndRoll, int32_t NumSubdivisions, bool bRaiseHeights, bool bLowerHeights, struct ULandscapeLayerInfoObject* PaintLayer); // Offset: 0x104007b40 // Return & Params: Num(11) Size(0x30)

	// Object Name: Function Landscape.LandscapeProxy.ChangeUseTessellationComponentScreenSizeFalloff
	// Flags: [Native|Public|BlueprintCallable]
	void ChangeUseTessellationComponentScreenSizeFalloff(bool InComponentScreenSizeToUseSubSections); // Offset: 0x104007fd8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Landscape.LandscapeProxy.ChangeTessellationComponentScreenSizeFalloff
	// Flags: [Native|Public|BlueprintCallable]
	void ChangeTessellationComponentScreenSizeFalloff(float InUseTessellationComponentScreenSizeFalloff); // Offset: 0x104007f50 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Landscape.LandscapeProxy.ChangeTessellationComponentScreenSize
	// Flags: [Native|Public|BlueprintCallable]
	void ChangeTessellationComponentScreenSize(float InTessellationComponentScreenSize); // Offset: 0x1040080f0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Landscape.LandscapeProxy.ChangeLODDistanceFactor
	// Flags: [Native|Public|BlueprintCallable]
	void ChangeLODDistanceFactor(float InLODDistanceFactor); // Offset: 0x104008178 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Landscape.LandscapeProxy.ChangeComponentScreenSizeToUseSubSections
	// Flags: [Native|Public|BlueprintCallable]
	void ChangeComponentScreenSizeToUseSubSections(float InComponentScreenSizeToUseSubSections); // Offset: 0x104008068 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class Landscape.Landscape
// Size: 0x560 // Inherited bytes: 0x560
struct ALandscape : ALandscapeProxy {
};

// Object Name: Class Landscape.LandscapeBlueprintBrushBase
// Size: 0x228 // Inherited bytes: 0x228
struct ALandscapeBlueprintBrushBase : AActor {
	// Functions

	// Object Name: Function Landscape.LandscapeBlueprintBrushBase.RequestLandscapeUpdate
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RequestLandscapeUpdate(); // Offset: 0x1040010e8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Landscape.LandscapeBlueprintBrushBase.Render
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	struct UTextureRenderTarget2D* Render(bool InIsHeightmap, struct UTextureRenderTarget2D* InCombinedResult, struct FName& InWeightmapLayerName); // Offset: 0x1032a8510 // Return & Params: Num(4) Size(0x20)

	// Object Name: Function Landscape.LandscapeBlueprintBrushBase.Initialize
	// Flags: [Event|Public|HasOutParms|HasDefaults|BlueprintEvent]
	void Initialize(struct FTransform& InLandscapeTransform, struct FIntPoint& InLandscapeSize, struct FIntPoint& InLandscapeRenderTargetSize); // Offset: 0x1032a8510 // Return & Params: Num(3) Size(0x40)

	// Object Name: Function Landscape.LandscapeBlueprintBrushBase.GetBlueprintRenderDependencies
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	void GetBlueprintRenderDependencies(struct TArray<struct UTexture2D*>& OutStreamableAssets); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class Landscape.LandscapeComponent
// Size: 0x760 // Inherited bytes: 0x570
struct ULandscapeComponent : UPrimitiveComponent {
	// Fields
	int32_t SectionBaseX; // Offset: 0x570 // Size: 0x04
	int32_t SectionBaseY; // Offset: 0x574 // Size: 0x04
	int32_t ComponentSizeQuads; // Offset: 0x578 // Size: 0x04
	int32_t SubsectionSizeQuads; // Offset: 0x57c // Size: 0x04
	int32_t NumSubsections; // Offset: 0x580 // Size: 0x04
	char pad_0x584[0x4]; // Offset: 0x584 // Size: 0x04
	struct UMaterialInterface* OverrideMaterial; // Offset: 0x588 // Size: 0x08
	struct UMaterialInterface* OverrideHoleMaterial; // Offset: 0x590 // Size: 0x08
	struct TArray<struct FLandscapeComponentMaterialOverride> OverrideMaterials; // Offset: 0x598 // Size: 0x10
	struct TArray<struct UMaterialInstanceConstant*> MaterialInstances; // Offset: 0x5a8 // Size: 0x10
	struct TArray<struct UMaterialInstanceDynamic*> MaterialInstancesDynamic; // Offset: 0x5b8 // Size: 0x10
	struct TArray<int8_t> LODIndexToMaterialIndex; // Offset: 0x5c8 // Size: 0x10
	struct TArray<int8_t> MaterialIndexToDisabledTessellationMaterial; // Offset: 0x5d8 // Size: 0x10
	struct UTexture2D* XYOffsetmapTexture; // Offset: 0x5e8 // Size: 0x08
	struct FVector4 WeightmapScaleBias; // Offset: 0x5f0 // Size: 0x10
	float WeightmapSubsectionOffset; // Offset: 0x600 // Size: 0x04
	char pad_0x604[0xc]; // Offset: 0x604 // Size: 0x0c
	struct FVector4 HeightmapScaleBias; // Offset: 0x610 // Size: 0x10
	struct FBox CachedLocalBox; // Offset: 0x620 // Size: 0x1c
	LazyObjectProperty CollisionComponent; // Offset: 0x63c // Size: 0x1c
	struct UTexture2D* HeightmapTexture; // Offset: 0x658 // Size: 0x08
	struct TArray<struct FWeightmapLayerAllocationInfo> WeightmapLayerAllocations; // Offset: 0x660 // Size: 0x10
	struct TArray<struct UTexture2D*> WeightmapTextures; // Offset: 0x670 // Size: 0x10
	struct FGuid MapBuildDataId; // Offset: 0x680 // Size: 0x10
	struct TArray<struct FGuid> IrrelevantLights; // Offset: 0x690 // Size: 0x10
	int32_t CollisionMipLevel; // Offset: 0x6a0 // Size: 0x04
	int32_t SimpleCollisionMipLevel; // Offset: 0x6a4 // Size: 0x04
	float NegativeZBoundsExtension; // Offset: 0x6a8 // Size: 0x04
	float PositiveZBoundsExtension; // Offset: 0x6ac // Size: 0x04
	float StaticLightingResolution; // Offset: 0x6b0 // Size: 0x04
	int32_t ForcedLOD; // Offset: 0x6b4 // Size: 0x04
	int32_t LODBias; // Offset: 0x6b8 // Size: 0x04
	struct FGuid StateId; // Offset: 0x6bc // Size: 0x10
	struct FGuid BakedTextureMaterialGuid; // Offset: 0x6cc // Size: 0x10
	char pad_0x6DC[0x4]; // Offset: 0x6dc // Size: 0x04
	struct UTexture2D* GIBakedBaseColorTexture; // Offset: 0x6e0 // Size: 0x08
	char MobileBlendableLayerMask; // Offset: 0x6e8 // Size: 0x01
	char pad_0x6E9[0x7]; // Offset: 0x6e9 // Size: 0x07
	struct UMaterialInterface* MobileMaterialInterface; // Offset: 0x6f0 // Size: 0x08
	struct TArray<struct UMaterialInterface*> MobileMaterialInterfaces; // Offset: 0x6f8 // Size: 0x10
	struct TArray<struct UTexture2D*> MobileWeightmapTextures; // Offset: 0x708 // Size: 0x10
	char pad_0x718[0x48]; // Offset: 0x718 // Size: 0x48

	// Functions

	// Object Name: Function Landscape.LandscapeComponent.GetMaterialInstanceDynamic
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UMaterialInstanceDynamic* GetMaterialInstanceDynamic(int32_t InIndex); // Offset: 0x104001c6c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function Landscape.LandscapeComponent.EditorGetPaintLayerWeightByNameAtLocation
	// Flags: [Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	float EditorGetPaintLayerWeightByNameAtLocation(struct FVector& InLocation, struct FName InPaintLayerName); // Offset: 0x104001a9c // Return & Params: Num(3) Size(0x18)

	// Object Name: Function Landscape.LandscapeComponent.EditorGetPaintLayerWeightAtLocation
	// Flags: [Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	float EditorGetPaintLayerWeightAtLocation(struct FVector& InLocation, struct ULandscapeLayerInfoObject* PaintLayer); // Offset: 0x104001b84 // Return & Params: Num(3) Size(0x1c)
};

// Object Name: Class Landscape.LandscapeGizmoActor
// Size: 0x228 // Inherited bytes: 0x228
struct ALandscapeGizmoActor : AActor {
};

// Object Name: Class Landscape.LandscapeGizmoActiveActor
// Size: 0x278 // Inherited bytes: 0x228
struct ALandscapeGizmoActiveActor : ALandscapeGizmoActor {
	// Fields
	char pad_0x228[0x50]; // Offset: 0x228 // Size: 0x50
};

// Object Name: Class Landscape.LandscapeGizmoRenderComponent
// Size: 0x570 // Inherited bytes: 0x570
struct ULandscapeGizmoRenderComponent : UPrimitiveComponent {
};

// Object Name: Class Landscape.LandscapeGrassType
// Size: 0x60 // Inherited bytes: 0x28
struct ULandscapeGrassType : UObject {
	// Fields
	struct TArray<struct FGrassVariety> GrassVarieties; // Offset: 0x28 // Size: 0x10
	char bEnableDensityScaling : 1; // Offset: 0x38 // Size: 0x01
	char pad_0x38_1 : 7; // Offset: 0x38 // Size: 0x01
	char pad_0x39[0x7]; // Offset: 0x39 // Size: 0x07
	struct UStaticMesh* GrassMesh; // Offset: 0x40 // Size: 0x08
	float GrassDensity; // Offset: 0x48 // Size: 0x04
	float PlacementJitter; // Offset: 0x4c // Size: 0x04
	int32_t StartCullDistance; // Offset: 0x50 // Size: 0x04
	int32_t EndCullDistance; // Offset: 0x54 // Size: 0x04
	bool RandomRotation; // Offset: 0x58 // Size: 0x01
	bool AlignToSurface; // Offset: 0x59 // Size: 0x01
	char pad_0x5A[0x6]; // Offset: 0x5a // Size: 0x06
};

// Object Name: Class Landscape.LandscapeHeightfieldCollisionComponent
// Size: 0x650 // Inherited bytes: 0x570
struct ULandscapeHeightfieldCollisionComponent : UPrimitiveComponent {
	// Fields
	struct TArray<struct ULandscapeLayerInfoObject*> ComponentLayerInfos; // Offset: 0x570 // Size: 0x10
	int32_t SectionBaseX; // Offset: 0x580 // Size: 0x04
	int32_t SectionBaseY; // Offset: 0x584 // Size: 0x04
	int32_t CollisionSizeQuads; // Offset: 0x588 // Size: 0x04
	float CollisionScale; // Offset: 0x58c // Size: 0x04
	int32_t SimpleCollisionSizeQuads; // Offset: 0x590 // Size: 0x04
	char pad_0x594[0x4]; // Offset: 0x594 // Size: 0x04
	struct TArray<char> CollisionQuadFlags; // Offset: 0x598 // Size: 0x10
	struct FGuid HeightfieldGuid; // Offset: 0x5a8 // Size: 0x10
	struct FBox CachedLocalBox; // Offset: 0x5b8 // Size: 0x1c
	LazyObjectProperty RenderComponent; // Offset: 0x5d4 // Size: 0x1c
	char pad_0x5F0[0x10]; // Offset: 0x5f0 // Size: 0x10
	struct TArray<struct UPhysicalMaterial*> CookedPhysicalMaterials; // Offset: 0x600 // Size: 0x10
	char pad_0x610[0x40]; // Offset: 0x610 // Size: 0x40

	// Functions

	// Object Name: Function Landscape.LandscapeHeightfieldCollisionComponent.GetRenderComponent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct ULandscapeComponent* GetRenderComponent(); // Offset: 0x104002be4 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class Landscape.LandscapeInfo
// Size: 0x210 // Inherited bytes: 0x28
struct ULandscapeInfo : UObject {
	// Fields
	LazyObjectProperty LandscapeActor; // Offset: 0x28 // Size: 0x1c
	struct FGuid LandscapeGuid; // Offset: 0x44 // Size: 0x10
	int32_t ComponentSizeQuads; // Offset: 0x54 // Size: 0x04
	int32_t SubsectionSizeQuads; // Offset: 0x58 // Size: 0x04
	int32_t ComponentNumSubsections; // Offset: 0x5c // Size: 0x04
	struct FVector DrawScale; // Offset: 0x60 // Size: 0x0c
	char pad_0x6C[0xa4]; // Offset: 0x6c // Size: 0xa4
	struct TArray<struct ALandscapeStreamingProxy*> Proxies; // Offset: 0x110 // Size: 0x10
	char pad_0x120[0xf0]; // Offset: 0x120 // Size: 0xf0
};

// Object Name: Class Landscape.LandscapeInfoMap
// Size: 0x80 // Inherited bytes: 0x28
struct ULandscapeInfoMap : UObject {
	// Fields
	char pad_0x28[0x58]; // Offset: 0x28 // Size: 0x58
};

// Object Name: Class Landscape.LandscapeLayerInfoObject
// Size: 0x50 // Inherited bytes: 0x28
struct ULandscapeLayerInfoObject : UObject {
	// Fields
	struct FName LayerName; // Offset: 0x28 // Size: 0x08
	struct UPhysicalMaterial* PhysMaterial; // Offset: 0x30 // Size: 0x08
	float Hardness; // Offset: 0x38 // Size: 0x04
	struct FLinearColor LayerUsageDebugColor; // Offset: 0x3c // Size: 0x10
	char pad_0x4C[0x4]; // Offset: 0x4c // Size: 0x04
};

// Object Name: Class Landscape.LandscapeMaterialInstanceConstant
// Size: 0x428 // Inherited bytes: 0x410
struct ULandscapeMaterialInstanceConstant : UMaterialInstanceConstant {
	// Fields
	struct TArray<struct FLandscapeMaterialTextureStreamingInfo> TextureStreamingInfo; // Offset: 0x410 // Size: 0x10
	char bIsLayerThumbnail : 1; // Offset: 0x420 // Size: 0x01
	char bDisableTessellation : 1; // Offset: 0x420 // Size: 0x01
	char bMobile : 1; // Offset: 0x420 // Size: 0x01
	char bEditorToolUsage : 1; // Offset: 0x420 // Size: 0x01
	char pad_0x420_4 : 4; // Offset: 0x420 // Size: 0x01
	char pad_0x421[0x7]; // Offset: 0x421 // Size: 0x07
};

// Object Name: Class Landscape.LandscapeMeshCollisionComponent
// Size: 0x670 // Inherited bytes: 0x650
struct ULandscapeMeshCollisionComponent : ULandscapeHeightfieldCollisionComponent {
	// Fields
	struct FGuid MeshGuid; // Offset: 0x650 // Size: 0x10
	char pad_0x660[0x10]; // Offset: 0x660 // Size: 0x10
};

// Object Name: Class Landscape.LandscapeMeshProxyActor
// Size: 0x230 // Inherited bytes: 0x228
struct ALandscapeMeshProxyActor : AActor {
	// Fields
	struct ULandscapeMeshProxyComponent* LandscapeMeshProxyComponent; // Offset: 0x228 // Size: 0x08
};

// Object Name: Class Landscape.LandscapeMeshProxyComponent
// Size: 0x650 // Inherited bytes: 0x630
struct ULandscapeMeshProxyComponent : UStaticMeshComponent {
	// Fields
	struct FGuid LandscapeGuid; // Offset: 0x624 // Size: 0x10
	struct TArray<struct FIntPoint> ProxyComponentBases; // Offset: 0x638 // Size: 0x10
	int8_t ProxyLOD; // Offset: 0x648 // Size: 0x01
};

// Object Name: Class Landscape.LandscapeSettings
// Size: 0x50 // Inherited bytes: 0x38
struct ULandscapeSettings : UDeveloperSettings {
	// Fields
	int32_t MaxNumberOfLayers; // Offset: 0x38 // Size: 0x04
	bool bForceFourLayers; // Offset: 0x3c // Size: 0x01
	char pad_0x3D[0x3]; // Offset: 0x3d // Size: 0x03
	struct TArray<struct FLandscapeSplineSegmentSurfaceName> LandscapeSplineSegmentSurfaces; // Offset: 0x40 // Size: 0x10
};

// Object Name: Class Landscape.LandscapeSplinesComponent
// Size: 0x5a0 // Inherited bytes: 0x570
struct ULandscapeSplinesComponent : UPrimitiveComponent {
	// Fields
	struct TArray<struct ULandscapeSplineControlPoint*> ControlPoints; // Offset: 0x570 // Size: 0x10
	struct TArray<struct ULandscapeSplineSegment*> Segments; // Offset: 0x580 // Size: 0x10
	struct TArray<struct UMeshComponent*> CookedForeignMeshComponents; // Offset: 0x590 // Size: 0x10

	// Functions

	// Object Name: Function Landscape.LandscapeSplinesComponent.GetSplineMeshComponents
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct TArray<struct USplineMeshComponent*> GetSplineMeshComponents(); // Offset: 0x10400b05c // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class Landscape.LandscapeSplineControlPoint
// Size: 0xa8 // Inherited bytes: 0x28
struct ULandscapeSplineControlPoint : UObject {
	// Fields
	struct FVector Location; // Offset: 0x28 // Size: 0x0c
	struct FRotator Rotation; // Offset: 0x34 // Size: 0x0c
	float Width; // Offset: 0x40 // Size: 0x04
	float LayerWidthRatio; // Offset: 0x44 // Size: 0x04
	float SideFalloff; // Offset: 0x48 // Size: 0x04
	float LeftSideFalloffFactor; // Offset: 0x4c // Size: 0x04
	float RightSideFalloffFactor; // Offset: 0x50 // Size: 0x04
	float LeftSideLayerFalloffFactor; // Offset: 0x54 // Size: 0x04
	float RightSideLayerFalloffFactor; // Offset: 0x58 // Size: 0x04
	float EndFalloff; // Offset: 0x5c // Size: 0x04
	struct TArray<struct FLandscapeSplineConnection> ConnectedSegments; // Offset: 0x60 // Size: 0x10
	struct TArray<struct FLandscapeSplineInterpPoint> Points; // Offset: 0x70 // Size: 0x10
	struct FBox Bounds; // Offset: 0x80 // Size: 0x1c
	char pad_0x9C[0x4]; // Offset: 0x9c // Size: 0x04
	struct UControlPointMeshComponent* LocalMeshComponent; // Offset: 0xa0 // Size: 0x08
};

// Object Name: Class Landscape.LandscapeSplineSegment
// Size: 0xb8 // Inherited bytes: 0x28
struct ULandscapeSplineSegment : UObject {
	// Fields
	struct FLandscapeSplineSegmentConnection Connections[0x2]; // Offset: 0x28 // Size: 0x30
	enum class ELandscapeSplineSegmentSurface SurfaceType; // Offset: 0x58 // Size: 0x01
	char bBranchTrunk : 1; // Offset: 0x59 // Size: 0x01
	char pad_0x59_1 : 7; // Offset: 0x59 // Size: 0x01
	char pad_0x5A[0x6]; // Offset: 0x5a // Size: 0x06
	struct FInterpCurveVector SplineInfo; // Offset: 0x60 // Size: 0x18
	struct TArray<struct FLandscapeSplineInterpPoint> Points; // Offset: 0x78 // Size: 0x10
	struct FBox Bounds; // Offset: 0x88 // Size: 0x1c
	char pad_0xA4[0x4]; // Offset: 0xa4 // Size: 0x04
	struct TArray<struct USplineMeshComponent*> LocalMeshComponents; // Offset: 0xa8 // Size: 0x10
};

// Object Name: Class Landscape.LandscapeStreamingProxy
// Size: 0x580 // Inherited bytes: 0x560
struct ALandscapeStreamingProxy : ALandscapeProxy {
	// Fields
	LazyObjectProperty LandscapeActor; // Offset: 0x560 // Size: 0x1c
	char pad_0x57C[0x4]; // Offset: 0x57c // Size: 0x04
};

// Object Name: Class Landscape.LandscapeSubsystem
// Size: 0x98 // Inherited bytes: 0x30
struct ULandscapeSubsystem : UWorldSubsystem {
	// Fields
	char pad_0x30[0x68]; // Offset: 0x30 // Size: 0x68
};

// Object Name: Class Landscape.LandscapeWeightmapUsage
// Size: 0x58 // Inherited bytes: 0x28
struct ULandscapeWeightmapUsage : UObject {
	// Fields
	struct ULandscapeComponent* ChannelUsage[0x4]; // Offset: 0x28 // Size: 0x20
	struct FGuid LayerGuid; // Offset: 0x48 // Size: 0x10
};

// Object Name: Class Landscape.MaterialExpressionLandscapeGrassOutput
// Size: 0x50 // Inherited bytes: 0x40
struct UMaterialExpressionLandscapeGrassOutput : UMaterialExpressionCustomOutput {
	// Fields
	struct TArray<struct FGrassInput> GrassTypes; // Offset: 0x40 // Size: 0x10
};

// Object Name: Class Landscape.MaterialExpressionLandscapeLayerBlend
// Size: 0x60 // Inherited bytes: 0x40
struct UMaterialExpressionLandscapeLayerBlend : UMaterialExpression {
	// Fields
	struct TArray<struct FLayerBlendInput> Layers; // Offset: 0x40 // Size: 0x10
	struct FGuid ExpressionGUID; // Offset: 0x50 // Size: 0x10
};

// Object Name: Class Landscape.MaterialExpressionLandscapeLayerCoords
// Size: 0x50 // Inherited bytes: 0x40
struct UMaterialExpressionLandscapeLayerCoords : UMaterialExpression {
	// Fields
	enum class ETerrainCoordMappingType MappingType; // Offset: 0x39 // Size: 0x01
	enum class ELandscapeCustomizedCoordType CustomUVType; // Offset: 0x3a // Size: 0x01
	float MappingScale; // Offset: 0x3c // Size: 0x04
	float MappingRotation; // Offset: 0x40 // Size: 0x04
	float MappingPanU; // Offset: 0x44 // Size: 0x04
	float MappingPanV; // Offset: 0x48 // Size: 0x04
};

// Object Name: Class Landscape.MaterialExpressionLandscapeLayerSample
// Size: 0x58 // Inherited bytes: 0x40
struct UMaterialExpressionLandscapeLayerSample : UMaterialExpression {
	// Fields
	struct FName ParameterName; // Offset: 0x3c // Size: 0x08
	float PreviewWeight; // Offset: 0x44 // Size: 0x04
	struct FGuid ExpressionGUID; // Offset: 0x48 // Size: 0x10
};

// Object Name: Class Landscape.MaterialExpressionLandscapeLayerSwitch
// Size: 0x80 // Inherited bytes: 0x40
struct UMaterialExpressionLandscapeLayerSwitch : UMaterialExpression {
	// Fields
	struct FExpressionInput LayerUsed; // Offset: 0x3c // Size: 0x0c
	char pad_0x4C[0x4]; // Offset: 0x4c // Size: 0x04
	struct FExpressionInput LayerNotUsed; // Offset: 0x50 // Size: 0x0c
	char pad_0x5C[0x8]; // Offset: 0x5c // Size: 0x08
	struct FName ParameterName; // Offset: 0x64 // Size: 0x08
	char PreviewUsed : 1; // Offset: 0x6c // Size: 0x01
	char pad_0x6C_1 : 7; // Offset: 0x6c // Size: 0x01
	char pad_0x6D[0x3]; // Offset: 0x6d // Size: 0x03
	struct FGuid ExpressionGUID; // Offset: 0x70 // Size: 0x10
};

// Object Name: Class Landscape.MaterialExpressionLandscapeLayerWeight
// Size: 0x90 // Inherited bytes: 0x40
struct UMaterialExpressionLandscapeLayerWeight : UMaterialExpression {
	// Fields
	struct FExpressionInput Base; // Offset: 0x3c // Size: 0x0c
	char pad_0x4C[0x4]; // Offset: 0x4c // Size: 0x04
	struct FExpressionInput Layer; // Offset: 0x50 // Size: 0x0c
	char pad_0x5C[0x8]; // Offset: 0x5c // Size: 0x08
	struct FName ParameterName; // Offset: 0x64 // Size: 0x08
	float PreviewWeight; // Offset: 0x6c // Size: 0x04
	struct FVector ConstBase; // Offset: 0x70 // Size: 0x0c
	struct FGuid ExpressionGUID; // Offset: 0x7c // Size: 0x10
	char pad_0x8C[0x4]; // Offset: 0x8c // Size: 0x04
};

// Object Name: Class Landscape.MaterialExpressionLandscapeVisibilityMask
// Size: 0x50 // Inherited bytes: 0x40
struct UMaterialExpressionLandscapeVisibilityMask : UMaterialExpression {
	// Fields
	struct FGuid ExpressionGUID; // Offset: 0x3c // Size: 0x10
};

