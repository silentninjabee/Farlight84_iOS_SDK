#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass Lobby_Script.Lobby_Script_C
// Size: 0x288 // Inherited bytes: 0x230
struct ALobby_Script_C : ALevelScriptActor {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x230 // Size: 0x08
	struct AActor* Loc_Hall; // Offset: 0x238 // Size: 0x08
	struct AActor* Loc_BattlePass; // Offset: 0x240 // Size: 0x08
	struct AActor* Loc_RankRace; // Offset: 0x248 // Size: 0x08
	struct AActor* Loc_RankList; // Offset: 0x250 // Size: 0x08
	struct AActor* Loc_Shop; // Offset: 0x258 // Size: 0x08
	struct AActor* Loc_Weapon; // Offset: 0x260 // Size: 0x08
	struct AActor* Loc_MVP; // Offset: 0x268 // Size: 0x08
	struct AActor* Loc_Character; // Offset: 0x270 // Size: 0x08
	struct TArray<struct AActor*> LocatorList; // Offset: 0x278 // Size: 0x10

	// Functions

	// Object Name: Function Lobby_Script.Lobby_Script_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	struct FString GetModuleName(); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Lobby_Script.Lobby_Script_C.ReceiveBeginPlay
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveBeginPlay(); // Offset: 0x10138549c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby_Script.Lobby_Script_C.ExecuteUbergraph_Lobby_Script
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_Lobby_Script(int32_t EntryPoint); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x4)
};

