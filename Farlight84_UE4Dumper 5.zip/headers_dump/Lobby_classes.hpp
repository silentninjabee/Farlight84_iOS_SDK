#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass Lobby.Lobby_C
// Size: 0x238 // Inherited bytes: 0x230
struct ALobby_C : ALevelScriptActor {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x230 // Size: 0x08

	// Functions

	// Object Name: Function Lobby.Lobby_C.ReceiveBeginPlay
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveBeginPlay(); // Offset: 0x1032a8510 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Lobby.Lobby_C.ExecuteUbergraph_Lobby
	// Flags: [Final|UbergraphFunction|HasDefaults]
	void ExecuteUbergraph_Lobby(int32_t EntryPoint); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x4)
};

