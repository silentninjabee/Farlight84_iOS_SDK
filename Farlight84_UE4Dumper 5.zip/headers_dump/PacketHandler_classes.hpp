#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class PacketHandler.HandlerComponentFactory
// Size: 0x28 // Inherited bytes: 0x28
struct UHandlerComponentFactory : UObject {
};

// Object Name: Class PacketHandler.PacketHandlerProfileConfig
// Size: 0x38 // Inherited bytes: 0x28
struct UPacketHandlerProfileConfig : UObject {
	// Fields
	struct TArray<struct FString> Components; // Offset: 0x28 // Size: 0x10
};

