#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass Projectile_BMphy08_Primary.Projectile_BMphy08_Primary_C
// Size: 0x518 // Inherited bytes: 0x508
struct AProjectile_BMphy08_Primary_C : ADefaultProjBullet_C {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x508 // Size: 0x08
	struct UStaticMeshComponent* Bullet; // Offset: 0x510 // Size: 0x08

	// Functions

	// Object Name: Function Projectile_BMphy08_Primary.Projectile_BMphy08_Primary_C.BndEvt__MovementComp_K2Node_ComponentBoundEvent_0_OnProjectileStopDelegate__DelegateSignature
	// Flags: [HasOutParms|BlueprintEvent]
	void BndEvt__MovementComp_K2Node_ComponentBoundEvent_0_OnProjectileStopDelegate__DelegateSignature(struct FHitResult& ImpactResult); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x88)

	// Object Name: Function Projectile_BMphy08_Primary.Projectile_BMphy08_Primary_C.ExecuteUbergraph_Projectile_BMphy08_Primary
	// Flags: [Final|UbergraphFunction|HasDefaults]
	void ExecuteUbergraph_Projectile_BMphy08_Primary(int32_t EntryPoint); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x4)
};

