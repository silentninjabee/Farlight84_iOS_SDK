#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass Projectile_SniperPrimary.Projectile_SniperPrimary_C
// Size: 0x508 // Inherited bytes: 0x508
struct AProjectile_SniperPrimary_C : ADefaultProjBullet_C {
};

