#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass Projectile_VH_Hover_Soroll02_AutoGun.Projectile_VH_Hover_Soroll02_AutoGun_C
// Size: 0x510 // Inherited bytes: 0x508
struct AProjectile_VH_Hover_Soroll02_AutoGun_C : ADefaultProjBullet_C {
	// Fields
	struct UParticleSystemComponent* Bullet; // Offset: 0x508 // Size: 0x08
};

