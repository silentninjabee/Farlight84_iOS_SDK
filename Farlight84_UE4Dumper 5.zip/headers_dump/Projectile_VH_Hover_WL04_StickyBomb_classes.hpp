#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass Projectile_VH_Hover_WL04_StickyBomb.Projectile_VH_Hover_WL04_StickyBomb_C
// Size: 0x518 // Inherited bytes: 0x508
struct AProjectile_VH_Hover_WL04_StickyBomb_C : ADefaultProjBullet_C {
	// Fields
	struct UParticleSystemComponent* FX_Hover_WL04_waring; // Offset: 0x508 // Size: 0x08
	struct UStaticMeshComponent* Bullet; // Offset: 0x510 // Size: 0x08
};

