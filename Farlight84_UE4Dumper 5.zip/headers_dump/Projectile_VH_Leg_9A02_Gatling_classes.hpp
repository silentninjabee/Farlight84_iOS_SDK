#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass Projectile_VH_Leg_9A02_Gatling.Projectile_VH_Leg_9A02_Gatling_C
// Size: 0x510 // Inherited bytes: 0x508
struct AProjectile_VH_Leg_9A02_Gatling_C : ADefaultProjBullet_C {
	// Fields
	struct UParticleSystemComponent* Bullet; // Offset: 0x508 // Size: 0x08
};

