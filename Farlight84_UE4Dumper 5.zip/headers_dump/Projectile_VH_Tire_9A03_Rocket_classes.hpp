#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass Projectile_VH_Tire_9A03_Rocket.Projectile_VH_Tire_9A03_Rocket_C
// Size: 0x510 // Inherited bytes: 0x508
struct AProjectile_VH_Tire_9A03_Rocket_C : ADefaultProjBullet_C {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x508 // Size: 0x08

	// Functions

	// Object Name: Function Projectile_VH_Tire_9A03_Rocket.Projectile_VH_Tire_9A03_Rocket_C.BndEvt__MovementComp_K2Node_ComponentBoundEvent_0_OnProjectileStopDelegate__DelegateSignature
	// Flags: [HasOutParms|BlueprintEvent]
	void BndEvt__MovementComp_K2Node_ComponentBoundEvent_0_OnProjectileStopDelegate__DelegateSignature(struct FHitResult& ImpactResult); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x88)

	// Object Name: Function Projectile_VH_Tire_9A03_Rocket.Projectile_VH_Tire_9A03_Rocket_C.ExecuteUbergraph_Projectile_VH_Tire_9A03_Rocket
	// Flags: [Final|UbergraphFunction|HasDefaults]
	void ExecuteUbergraph_Projectile_VH_Tire_9A03_Rocket(int32_t EntryPoint); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x4)
};

