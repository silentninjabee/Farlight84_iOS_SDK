#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: DynamicClass R_Weapon_WL02_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_WL02_Set00_LODP_Skeleton_AnimBlueprint_C
// Size: 0x380 // Inherited bytes: 0x2d0
struct UR_Weapon_WL02_Set00_LODP_Skeleton_AnimBlueprint_C : UWeaponAnimInstance {
	// Fields
	struct FAnimNode_Root AnimGraphNode_Root; // Offset: 0x2d0 // Size: 0x30
	struct FAnimNode_RefPose AnimGraphNode_LocalRefPose; // Offset: 0x300 // Size: 0x18
	struct FAnimNode_Slot AnimGraphNode_Slot; // Offset: 0x318 // Size: 0x48
	struct FAnimMsgData K2Node_MakeStruct_AnimMsgData; // Offset: 0x360 // Size: 0x08
	struct TArray<struct FAnimMsgData> K2Node_MakeArray_Array; // Offset: 0x368 // Size: 0x10
	char pad_0x378[0x8]; // Offset: 0x378 // Size: 0x08

	// Functions

	// Object Name: Function R_Weapon_WL02_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_WL02_Set00_LODP_Skeleton_AnimBlueprint_C.TestAPI
	// Flags: [Native|Public|BlueprintCallable]
	void TestAPI(); // Offset: 0x101c24f54 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function R_Weapon_WL02_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_WL02_Set00_LODP_Skeleton_AnimBlueprint_C.InterruptAnim
	// Flags: [Native|Public|BlueprintCallable]
	void InterruptAnim(); // Offset: 0x101c25018 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function R_Weapon_WL02_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_WL02_Set00_LODP_Skeleton_AnimBlueprint_C.AnimNotify_QuitReload
	// Flags: [Native|Public|BlueprintCallable]
	void AnimNotify_QuitReload(); // Offset: 0x101c24fc4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function R_Weapon_WL02_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_WL02_Set00_LODP_Skeleton_AnimBlueprint_C.AnimNotify_QuitIdle
	// Flags: [Native|Public|BlueprintCallable]
	void AnimNotify_QuitIdle(); // Offset: 0x101c24ffc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function R_Weapon_WL02_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_WL02_Set00_LODP_Skeleton_AnimBlueprint_C.AnimNotify_QuitFire
	// Flags: [Native|Public|BlueprintCallable]
	void AnimNotify_QuitFire(); // Offset: 0x101c24fa8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function R_Weapon_WL02_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_WL02_Set00_LODP_Skeleton_AnimBlueprint_C.AnimNotify_EnterReload
	// Flags: [Native|Public|BlueprintCallable]
	void AnimNotify_EnterReload(); // Offset: 0x101c24f8c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function R_Weapon_WL02_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_WL02_Set00_LODP_Skeleton_AnimBlueprint_C.AnimNotify_EnterIdle
	// Flags: [Native|Public|BlueprintCallable]
	void AnimNotify_EnterIdle(); // Offset: 0x101c24fe0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function R_Weapon_WL02_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_WL02_Set00_LODP_Skeleton_AnimBlueprint_C.AnimNotify_EnterFire
	// Flags: [Native|Public|BlueprintCallable]
	void AnimNotify_EnterFire(); // Offset: 0x101c24f70 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function R_Weapon_WL02_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_WL02_Set00_LODP_Skeleton_AnimBlueprint_C.AnimGraph
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	void AnimGraph(struct FPoseLink& bpp__AnimGraph__pf); // Offset: 0x101c24eb4 // Return & Params: Num(1) Size(0x10)
};

