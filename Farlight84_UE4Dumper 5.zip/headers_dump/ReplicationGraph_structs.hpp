#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct ReplicationGraph.ConnectionAlwaysRelevantNodePair
// Size: 0x10 // Inherited bytes: 0x00
struct FConnectionAlwaysRelevantNodePair {
	// Fields
	struct UNetConnection* NetConnection; // Offset: 0x00 // Size: 0x08
	struct UReplicationGraphNode_AlwaysRelevant_ForConnection* Node; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct ReplicationGraph.LastLocationGatherInfo
// Size: 0x20 // Inherited bytes: 0x00
struct FLastLocationGatherInfo {
	// Fields
	struct UNetConnection* Connection; // Offset: 0x00 // Size: 0x08
	struct FVector LastLocation; // Offset: 0x08 // Size: 0x0c
	struct FVector LastOutOfRangeLocationCheck; // Offset: 0x14 // Size: 0x0c
};

// Object Name: ScriptStruct ReplicationGraph.TearOffActorInfo
// Size: 0x18 // Inherited bytes: 0x00
struct FTearOffActorInfo {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
	struct AActor* Actor; // Offset: 0x08 // Size: 0x08
	char pad_0x10[0x8]; // Offset: 0x10 // Size: 0x08
};

// Object Name: ScriptStruct ReplicationGraph.ClassExtraReplicatedInfo
// Size: 0x50 // Inherited bytes: 0x00
struct FClassExtraReplicatedInfo {
	// Fields
	struct TMap<struct UObject*, int32_t> ClassActorsMaxReplicatedNum; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct ReplicationGraph.AlwaysRelevantActorInfo
// Size: 0x18 // Inherited bytes: 0x00
struct FAlwaysRelevantActorInfo {
	// Fields
	struct UNetConnection* Connection; // Offset: 0x00 // Size: 0x08
	struct AActor* LastViewer; // Offset: 0x08 // Size: 0x08
	struct AActor* LastViewTarget; // Offset: 0x10 // Size: 0x08
};

// Object Name: ScriptStruct ReplicationGraph.ClassReplicationInfo
// Size: 0x70 // Inherited bytes: 0x00
struct FClassReplicationInfo {
	// Fields
	float DistancePriorityScale; // Offset: 0x00 // Size: 0x04
	float StarvationPriorityScale; // Offset: 0x04 // Size: 0x04
	float AccumulatedNetPriorityBias; // Offset: 0x08 // Size: 0x04
	uint16_t ReplicationPeriodFrame; // Offset: 0x0c // Size: 0x02
	uint16_t FastPath_ReplicationPeriodFrame; // Offset: 0x0e // Size: 0x02
	uint16_t ActorChannelFrameTimeout; // Offset: 0x10 // Size: 0x02
	char pad_0x12[0x56]; // Offset: 0x12 // Size: 0x56
	float CullDistance; // Offset: 0x68 // Size: 0x04
	float CullDistanceSquared; // Offset: 0x6c // Size: 0x04
};

