#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct Slate.VirtualKeyboardOptions
// Size: 0x01 // Inherited bytes: 0x00
struct FVirtualKeyboardOptions {
	// Fields
	bool bEnableAutocorrect; // Offset: 0x00 // Size: 0x01
};

// Object Name: ScriptStruct Slate.InputChord
// Size: 0x20 // Inherited bytes: 0x00
struct FInputChord {
	// Fields
	struct FKey Key; // Offset: 0x00 // Size: 0x18
	char bShift : 1; // Offset: 0x18 // Size: 0x01
	char bCtrl : 1; // Offset: 0x18 // Size: 0x01
	char bAlt : 1; // Offset: 0x18 // Size: 0x01
	char bCmd : 1; // Offset: 0x18 // Size: 0x01
	char pad_0x18_4 : 4; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x7]; // Offset: 0x19 // Size: 0x07
};

// Object Name: ScriptStruct Slate.Anchors
// Size: 0x10 // Inherited bytes: 0x00
struct FAnchors {
	// Fields
	struct FVector2D Minimum; // Offset: 0x00 // Size: 0x08
	struct FVector2D Maximum; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct Slate.CustomizedToolMenu
// Size: 0x1e8 // Inherited bytes: 0x00
struct FCustomizedToolMenu {
	// Fields
	struct FName Name; // Offset: 0x00 // Size: 0x08
	struct TMap<struct FName, struct FCustomizedToolMenuEntry> Entries; // Offset: 0x08 // Size: 0x50
	struct TMap<struct FName, struct FCustomizedToolMenuSection> Sections; // Offset: 0x58 // Size: 0x50
	struct TMap<struct FName, struct FCustomizedToolMenuNameArray> EntryOrder; // Offset: 0xa8 // Size: 0x50
	struct TArray<struct FName> SectionOrder; // Offset: 0xf8 // Size: 0x10
	char pad_0x108[0xe0]; // Offset: 0x108 // Size: 0xe0
};

// Object Name: ScriptStruct Slate.CustomizedToolMenuNameArray
// Size: 0x10 // Inherited bytes: 0x00
struct FCustomizedToolMenuNameArray {
	// Fields
	struct TArray<struct FName> Names; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct Slate.CustomizedToolMenuSection
// Size: 0x04 // Inherited bytes: 0x00
struct FCustomizedToolMenuSection {
	// Fields
	enum class ECustomizedToolMenuVisibility Visibility; // Offset: 0x00 // Size: 0x04
};

// Object Name: ScriptStruct Slate.CustomizedToolMenuEntry
// Size: 0x04 // Inherited bytes: 0x00
struct FCustomizedToolMenuEntry {
	// Fields
	enum class ECustomizedToolMenuVisibility Visibility; // Offset: 0x00 // Size: 0x04
};

