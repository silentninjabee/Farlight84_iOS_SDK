#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct SolarFramework.SolarConfigEntry
// Size: 0x30 // Inherited bytes: 0x00
struct FSolarConfigEntry {
	// Fields
	struct TSoftClassPtr<UObject> ContainerPath; // Offset: 0x00 // Size: 0x28
	enum class EScope Scope; // Offset: 0x28 // Size: 0x01
	char pad_0x29[0x7]; // Offset: 0x29 // Size: 0x07
};

