#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct StaticMeshDescription.UVMapSettings
// Size: 0x38 // Inherited bytes: 0x00
struct FUVMapSettings {
	// Fields
	struct FVector Size; // Offset: 0x00 // Size: 0x0c
	struct FVector2D UVTile; // Offset: 0x0c // Size: 0x08
	struct FVector Position; // Offset: 0x14 // Size: 0x0c
	struct FRotator Rotation; // Offset: 0x20 // Size: 0x0c
	struct FVector Scale; // Offset: 0x2c // Size: 0x0c
};

