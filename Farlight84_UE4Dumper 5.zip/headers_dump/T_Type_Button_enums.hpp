#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum T_Type_Button.T_Type_Button
enum class T_Type_Button : uint8 {
	Join = 0,
	Join_Icon = 1,
	Joining = 2,
	Watch = 3,
	T Type MAX = 4
};

