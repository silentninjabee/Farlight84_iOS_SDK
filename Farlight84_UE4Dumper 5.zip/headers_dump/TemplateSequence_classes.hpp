#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class TemplateSequence.TemplateSequence
// Size: 0x3f0 // Inherited bytes: 0x348
struct UTemplateSequence : UMovieSceneSequence {
	// Fields
	struct UMovieScene* MovieScene; // Offset: 0x348 // Size: 0x08
	struct TSoftClassPtr<UObject> BoundActorClass; // Offset: 0x350 // Size: 0x28
	struct TSoftObjectPtr<AActor> BoundPreviewActor; // Offset: 0x378 // Size: 0x28
	struct TMap<struct FGuid, struct FName> BoundActorComponents; // Offset: 0x3a0 // Size: 0x50
};

// Object Name: Class TemplateSequence.CameraAnimationSequence
// Size: 0x3f0 // Inherited bytes: 0x3f0
struct UCameraAnimationSequence : UTemplateSequence {
};

// Object Name: Class TemplateSequence.TemplateSequenceActor
// Size: 0x278 // Inherited bytes: 0x228
struct ATemplateSequenceActor : AActor {
	// Fields
	char pad_0x228[0x8]; // Offset: 0x228 // Size: 0x08
	struct FMovieSceneSequencePlaybackSettings PlaybackSettings; // Offset: 0x230 // Size: 0x14
	char pad_0x244[0x4]; // Offset: 0x244 // Size: 0x04
	struct UTemplateSequencePlayer* SequencePlayer; // Offset: 0x248 // Size: 0x08
	struct FSoftObjectPath TemplateSequence; // Offset: 0x250 // Size: 0x18
	struct FTemplateSequenceBindingOverrideData BindingOverride; // Offset: 0x268 // Size: 0x0c
	char pad_0x274[0x4]; // Offset: 0x274 // Size: 0x04

	// Functions

	// Object Name: Function TemplateSequence.TemplateSequenceActor.SetSequence
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSequence(struct UTemplateSequence* InSequence); // Offset: 0x101eee4b0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function TemplateSequence.TemplateSequenceActor.SetBinding
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetBinding(struct AActor* Actor); // Offset: 0x101eee3fc // Return & Params: Num(1) Size(0x8)

	// Object Name: Function TemplateSequence.TemplateSequenceActor.LoadSequence
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UTemplateSequence* LoadSequence(); // Offset: 0x101eee530 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function TemplateSequence.TemplateSequenceActor.GetSequencePlayer
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UTemplateSequencePlayer* GetSequencePlayer(); // Offset: 0x101eee47c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function TemplateSequence.TemplateSequenceActor.GetSequence
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UTemplateSequence* GetSequence(); // Offset: 0x101eee564 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class TemplateSequence.TemplateSequencePlayer
// Size: 0x890 // Inherited bytes: 0x888
struct UTemplateSequencePlayer : UMovieSceneSequencePlayer {
	// Fields
	char pad_0x888[0x8]; // Offset: 0x888 // Size: 0x08

	// Functions

	// Object Name: Function TemplateSequence.TemplateSequencePlayer.CreateTemplateSequencePlayer
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct UTemplateSequencePlayer* CreateTemplateSequencePlayer(struct UObject* WorldContextObject, struct UTemplateSequence* TemplateSequence, struct FMovieSceneSequencePlaybackSettings Settings, struct ATemplateSequenceActor*& OutActor); // Offset: 0x101eeec78 // Return & Params: Num(5) Size(0x38)
};

// Object Name: Class TemplateSequence.TemplateSequenceSection
// Size: 0x150 // Inherited bytes: 0x150
struct UTemplateSequenceSection : UMovieSceneSubSection {
};

// Object Name: Class TemplateSequence.TemplateSequenceTrack
// Size: 0x68 // Inherited bytes: 0x68
struct UTemplateSequenceTrack : UMovieSceneSubTrack {
};

