#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_AvatarFrame_S09.UI_AvatarFrame_S09_C
// Size: 0x380 // Inherited bytes: 0x348
struct UUI_AvatarFrame_S09_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x348 // Size: 0x08
	struct UWidgetAnimation* Loop_Anim; // Offset: 0x350 // Size: 0x08
	struct UParticleSystemWidget* ParticleSystemWidget_46; // Offset: 0x358 // Size: 0x08
	struct FMulticastInlineDelegate On Clicked; // Offset: 0x360 // Size: 0x10
	struct FMulticastInlineDelegate On Released; // Offset: 0x370 // Size: 0x10

	// Functions

	// Object Name: Function UI_AvatarFrame_S09.UI_AvatarFrame_S09_C.GetModuleName
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	struct FString GetModuleName(); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UI_AvatarFrame_S09.UI_AvatarFrame_S09_C.SetAvatarIcon
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetAvatarIcon(int32_t InAvatarID); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UI_AvatarFrame_S09.UI_AvatarFrame_S09_C.SetEmptyState
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetEmptyState(bool IsEmpty); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_AvatarFrame_S09.UI_AvatarFrame_S09_C.SetPlayerGender
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetPlayerGender(enum class E_Type_Gender Gender); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_AvatarFrame_S09.UI_AvatarFrame_S09_C.SetSocialIcon
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetSocialIcon(enum class E_Type_Social Social); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_AvatarFrame_S09.UI_AvatarFrame_S09_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void PreConstruct(bool IsDesignTime); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_AvatarFrame_S09.UI_AvatarFrame_S09_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Construct(); // Offset: 0x1032a8510 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_AvatarFrame_S09.UI_AvatarFrame_S09_C.Update
	// Flags: [BlueprintCallable|BlueprintEvent]
	void Update(); // Offset: 0x1032a8510 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_AvatarFrame_S09.UI_AvatarFrame_S09_C.ExecuteUbergraph_UI_AvatarFrame_S09
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_UI_AvatarFrame_S09(int32_t EntryPoint); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UI_AvatarFrame_S09.UI_AvatarFrame_S09_C.On Released__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void On Released__DelegateSignature(); // Offset: 0x1032a8510 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_AvatarFrame_S09.UI_AvatarFrame_S09_C.On Clicked__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void On Clicked__DelegateSignature(); // Offset: 0x1032a8510 // Return & Params: Num(0) Size(0x0)
};

