#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_Chat_Wave.UI_Chat_Wave_C
// Size: 0x350 // Inherited bytes: 0x348
struct UUI_Chat_Wave_C : USolarUserWidget {
	// Fields
	struct UWidgetAnimation* Anim_Loop; // Offset: 0x348 // Size: 0x08
};

