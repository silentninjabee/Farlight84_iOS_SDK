#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_Component_Platform.UI_Component_Platform_C
// Size: 0x362 // Inherited bytes: 0x348
struct UUI_Component_Platform_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x348 // Size: 0x08
	struct UImage* Img_Icon; // Offset: 0x350 // Size: 0x08
	struct USizeBox* Size_Icon; // Offset: 0x358 // Size: 0x08
	enum class E_Platform E_Platform; // Offset: 0x360 // Size: 0x01
	bool UseIcon; // Offset: 0x361 // Size: 0x01

	// Functions

	// Object Name: Function UI_Component_Platform.UI_Component_Platform_C.SetBlendPlatform
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetBlendPlatform(bool UseIcon); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Component_Platform.UI_Component_Platform_C.SetSizeState
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetSizeState(enum class E_Platform Platform); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Component_Platform.UI_Component_Platform_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void PreConstruct(bool IsDesignTime); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Component_Platform.UI_Component_Platform_C.ExecuteUbergraph_UI_Component_Platform
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_UI_Component_Platform(int32_t EntryPoint); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x4)
};

