#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_Component_PlayerName.UI_Component_PlayerName_C
// Size: 0x688 // Inherited bytes: 0x348
struct UUI_Component_PlayerName_C : UUIComponentPlayerName {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x348 // Size: 0x08
	struct USolarTextBlock* Txt_PlayerName; // Offset: 0x350 // Size: 0x08
	struct FS_VIP_TxtInfo DefaultTxtInfo; // Offset: 0x358 // Size: 0x88
	enum class E_Type_PlayerName_Vip_Color VIP_State; // Offset: 0x3e0 // Size: 0x01
	char pad_0x3E1[0x7]; // Offset: 0x3e1 // Size: 0x07
	struct TMap<enum class E_Type_PlayerName_Vip_Color, struct FS_VIP_TxtInfo> VIP_TxtInfos; // Offset: 0x3e8 // Size: 0x50
	bool Cheater; // Offset: 0x438 // Size: 0x01
	char pad_0x439[0x7]; // Offset: 0x439 // Size: 0x07
	struct FS_VIP_TxtInfo CheatTxtInfo; // Offset: 0x440 // Size: 0x88
	bool Killed; // Offset: 0x4c8 // Size: 0x01
	char pad_0x4C9[0x7]; // Offset: 0x4c9 // Size: 0x07
	struct FS_VIP_TxtInfo KilledTxtInfo; // Offset: 0x4d0 // Size: 0x88
	bool bSpecialSelf; // Offset: 0x558 // Size: 0x01
	char pad_0x559[0x7]; // Offset: 0x559 // Size: 0x07
	struct FS_VIP_TxtInfo SpecialSelfTxtInfo; // Offset: 0x560 // Size: 0x88
	struct FS_VIP_TxtInfo CurTxtInfo; // Offset: 0x5e8 // Size: 0x88
	struct FText DefaultText; // Offset: 0x670 // Size: 0x18

	// Functions

	// Object Name: Function UI_Component_PlayerName.UI_Component_PlayerName_C.SetIsKilled
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetIsKilled(bool IsKilled); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Component_PlayerName.UI_Component_PlayerName_C.SetIsCheater
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetIsCheater(bool bCheater); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Component_PlayerName.UI_Component_PlayerName_C.SetVipStyle
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetVipStyle(enum class E_Type_PlayerName_Vip_Color VIP_Type); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Component_PlayerName.UI_Component_PlayerName_C.SetPlayerNameAndStyle
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetPlayerNameAndStyle(struct FString NickName, bool bCheat, enum class E_Type_PlayerName_Vip_Color VIP_Type, bool bKilled); // Offset: 0x1032a8510 // Return & Params: Num(4) Size(0x13)

	// Object Name: Function UI_Component_PlayerName.UI_Component_PlayerName_C.SetPlayerName
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SetPlayerName(struct FString NickName); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UI_Component_PlayerName.UI_Component_PlayerName_C.SetDefaultStyle
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetDefaultStyle(bool bSpecialSelf); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Component_PlayerName.UI_Component_PlayerName_C.SetNameStyle
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SetNameStyle(bool bCheater, enum class E_Type_PlayerName_Vip_Color VIP_State, bool bKilled); // Offset: 0x1032a8510 // Return & Params: Num(3) Size(0x3)

	// Object Name: Function UI_Component_PlayerName.UI_Component_PlayerName_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void PreConstruct(bool IsDesignTime); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Component_PlayerName.UI_Component_PlayerName_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Construct(); // Offset: 0x1032a8510 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Component_PlayerName.UI_Component_PlayerName_C.ReSize
	// Flags: [BlueprintCallable|BlueprintEvent]
	void ReSize(); // Offset: 0x1032a8510 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Component_PlayerName.UI_Component_PlayerName_C.UpdatePlayerNameAndStyle
	// Flags: [Event|Public|BlueprintEvent]
	void UpdatePlayerNameAndStyle(struct FString NickName, char VipType, bool bCheat, bool bKilled); // Offset: 0x1032a8510 // Return & Params: Num(4) Size(0x13)

	// Object Name: Function UI_Component_PlayerName.UI_Component_PlayerName_C.SetText
	// Flags: [Event|Public|BlueprintEvent]
	void SetText(struct FString Content); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UI_Component_PlayerName.UI_Component_PlayerName_C.SetTextColorAndOpacity
	// Flags: [Event|Public|BlueprintEvent]
	void SetTextColorAndOpacity(struct FSlateColor InColor); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x28)

	// Object Name: Function UI_Component_PlayerName.UI_Component_PlayerName_C.SetStyle
	// Flags: [Event|Public|BlueprintEvent]
	void SetStyle(char VipType, bool bCheat, bool bKilled); // Offset: 0x1032a8510 // Return & Params: Num(3) Size(0x3)

	// Object Name: Function UI_Component_PlayerName.UI_Component_PlayerName_C.SetDeath
	// Flags: [Event|Public|BlueprintEvent]
	void SetDeath(bool bDeath); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Component_PlayerName.UI_Component_PlayerName_C.SetVip
	// Flags: [Event|Public|BlueprintEvent]
	void SetVip(char VipType); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Component_PlayerName.UI_Component_PlayerName_C.SetCheater
	// Flags: [Event|Public|BlueprintEvent]
	void SetCheater(bool bCheat); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Component_PlayerName.UI_Component_PlayerName_C.ExecuteUbergraph_UI_Component_PlayerName
	// Flags: [Final|UbergraphFunction|HasDefaults]
	void ExecuteUbergraph_UI_Component_PlayerName(int32_t EntryPoint); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x4)
};

