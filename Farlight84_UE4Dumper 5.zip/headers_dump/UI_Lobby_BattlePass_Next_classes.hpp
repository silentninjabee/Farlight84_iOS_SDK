#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_Lobby_BattlePass_Next.UI_Lobby_BattlePass_Next_C
// Size: 0x40b // Inherited bytes: 0x348
struct UUI_Lobby_BattlePass_Next_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x348 // Size: 0x08
	struct UWidgetAnimation* Loop_Anim; // Offset: 0x350 // Size: 0x08
	struct UWidgetAnimation* Anim_Upgrade; // Offset: 0x358 // Size: 0x08
	struct UWidgetAnimation* Anim_Loop; // Offset: 0x360 // Size: 0x08
	struct UWidgetAnimation* Anim_Max_Upgrade; // Offset: 0x368 // Size: 0x08
	struct UButton* Btn_BattlePass; // Offset: 0x370 // Size: 0x08
	struct UImage* Img_Arrow_Glow; // Offset: 0x378 // Size: 0x08
	struct UImage* Img_Arrow_Glow_2; // Offset: 0x380 // Size: 0x08
	struct UImage* Img_Arrow_Glow_3; // Offset: 0x388 // Size: 0x08
	struct UImage* Img_BG_Light; // Offset: 0x390 // Size: 0x08
	struct UImage* Img_BPBG; // Offset: 0x398 // Size: 0x08
	struct UImage* img_Hero; // Offset: 0x3a0 // Size: 0x08
	struct UImage* img_Hero_2; // Offset: 0x3a8 // Size: 0x08
	struct UImage* img_Hero_3; // Offset: 0x3b0 // Size: 0x08
	struct UImage* Img_Icon; // Offset: 0x3b8 // Size: 0x08
	struct UImage* Img_Weapon; // Offset: 0x3c0 // Size: 0x08
	struct UProgressBar* Level_Progress; // Offset: 0x3c8 // Size: 0x08
	struct UCanvasPanel* Panel_BattlePass; // Offset: 0x3d0 // Size: 0x08
	struct UScaleBox* Scale_BattlePass; // Offset: 0x3d8 // Size: 0x08
	struct UScaleBox* ScaleBox_Type; // Offset: 0x3e0 // Size: 0x08
	struct USolarRedHint_General_C* SolarRedHint_General_2; // Offset: 0x3e8 // Size: 0x08
	struct USolarTextBlock* Txt_BattlePass; // Offset: 0x3f0 // Size: 0x08
	struct UTextBlock* Txt_Battlepass_Level; // Offset: 0x3f8 // Size: 0x08
	struct USolarTextBlock* Txt_Type; // Offset: 0x400 // Size: 0x08
	bool isMax; // Offset: 0x408 // Size: 0x01
	bool isUpdate; // Offset: 0x409 // Size: 0x01
	bool isClaim; // Offset: 0x40a // Size: 0x01

	// Functions

	// Object Name: Function UI_Lobby_BattlePass_Next.UI_Lobby_BattlePass_Next_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	struct FString GetModuleName(); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UI_Lobby_BattlePass_Next.UI_Lobby_BattlePass_Next_C.SetClaimable
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetClaimable(bool NewParam); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Lobby_BattlePass_Next.UI_Lobby_BattlePass_Next_C.SetUpdate
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SetUpdate(bool NewParam); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Lobby_BattlePass_Next.UI_Lobby_BattlePass_Next_C.SetLevel
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SetLevel(bool NewParam); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Lobby_BattlePass_Next.UI_Lobby_BattlePass_Next_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void PreConstruct(bool IsDesignTime); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Lobby_BattlePass_Next.UI_Lobby_BattlePass_Next_C.BattlePassStateChange_Event
	// Flags: [BlueprintCallable|BlueprintEvent]
	void BattlePassStateChange_Event(); // Offset: 0x1032a8510 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Lobby_BattlePass_Next.UI_Lobby_BattlePass_Next_C.BattlePassPlayUpgradeAnimation
	// Flags: [BlueprintCallable|BlueprintEvent]
	void BattlePassPlayUpgradeAnimation(); // Offset: 0x1032a8510 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Lobby_BattlePass_Next.UI_Lobby_BattlePass_Next_C.ExecuteUbergraph_UI_Lobby_BattlePass_Next
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_UI_Lobby_BattlePass_Next(int32_t EntryPoint); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x4)
};

