#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_Lobby_Bubble_Container.UI_Lobby_Bubble_Container_C
// Size: 0x368 // Inherited bytes: 0x348
struct UUI_Lobby_Bubble_Container_C : USolarUserWidget {
	// Fields
	struct UCanvasPanel* Adapter; // Offset: 0x348 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_Container; // Offset: 0x350 // Size: 0x08
	struct UUI_Lobby_RoomInvite_Popup_C* UI_Lobby_RoomInvite_Popup; // Offset: 0x358 // Size: 0x08
	struct UUI_Lobby_TeamInvite_Popup_C* UI_Lobby_TeamInvite_Popup; // Offset: 0x360 // Size: 0x08
};

