#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_Lobby_StartBtn.UI_Lobby_StartBtn_C
// Size: 0x51c // Inherited bytes: 0x348
struct UUI_Lobby_StartBtn_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x348 // Size: 0x08
	struct UWidgetAnimation* Anim_Tournament_Enter; // Offset: 0x350 // Size: 0x08
	struct UWidgetAnimation* Anim_Activity_Enter; // Offset: 0x358 // Size: 0x08
	struct UWidgetAnimation* Loop_Normal_Anim; // Offset: 0x360 // Size: 0x08
	struct UWidgetAnimation* Loading_Anim; // Offset: 0x368 // Size: 0x08
	struct UWidgetAnimation* Loop_Start_Anim; // Offset: 0x370 // Size: 0x08
	struct UButton* Btn_Activity_Point; // Offset: 0x378 // Size: 0x08
	struct UButton* Btn_Cancel; // Offset: 0x380 // Size: 0x08
	struct UButton* Btn_Clan_Join; // Offset: 0x388 // Size: 0x08
	struct UButton* Btn_Clan_Reward; // Offset: 0x390 // Size: 0x08
	struct UButton* Btn_GameMode; // Offset: 0x398 // Size: 0x08
	struct UButton* Btn_Start; // Offset: 0x3a0 // Size: 0x08
	struct UButton* Btn_Tournament_Reward; // Offset: 0x3a8 // Size: 0x08
	struct UUI_Component_NationalFlag_C* ClanFlag; // Offset: 0x3b0 // Size: 0x08
	struct UScaleBox* GameMode; // Offset: 0x3b8 // Size: 0x08
	struct UHorizontalBox* HorizontalBox_PC; // Offset: 0x3c0 // Size: 0x08
	struct UImage* Image_X; // Offset: 0x3c8 // Size: 0x08
	struct UImage* Img_Activity_BG; // Offset: 0x3d0 // Size: 0x08
	struct UImage* Img_Activity_BG_Light; // Offset: 0x3d8 // Size: 0x08
	struct UImage* Img_Activity_BG_Light_2; // Offset: 0x3e0 // Size: 0x08
	struct UImage* Img_Activity_BG_Light_3; // Offset: 0x3e8 // Size: 0x08
	struct UImage* Img_Activity_BG_Light_4; // Offset: 0x3f0 // Size: 0x08
	struct UImage* Img_Arrow; // Offset: 0x3f8 // Size: 0x08
	struct UImage* Img_Arrow_Light; // Offset: 0x400 // Size: 0x08
	struct UImage* Img_GameMode; // Offset: 0x408 // Size: 0x08
	struct UImage* Img_Loading; // Offset: 0x410 // Size: 0x08
	struct UImage* Img_Start_Bg; // Offset: 0x418 // Size: 0x08
	struct UImage* Img_Start_Normal_Light; // Offset: 0x420 // Size: 0x08
	struct UCanvasPanel* Panel_Activity_All; // Offset: 0x428 // Size: 0x08
	struct UCanvasPanel* Panel_Anim; // Offset: 0x430 // Size: 0x08
	struct UCanvasPanel* Panel_Battle; // Offset: 0x438 // Size: 0x08
	struct UCanvasPanel* Panel_Cancel; // Offset: 0x440 // Size: 0x08
	struct UCanvasPanel* Panel_Gamemode; // Offset: 0x448 // Size: 0x08
	struct UCanvasPanel* Panel_Matching; // Offset: 0x450 // Size: 0x08
	struct UCanvasPanel* panel_start; // Offset: 0x458 // Size: 0x08
	struct UCanvasPanel* Panel_Start_Anim; // Offset: 0x460 // Size: 0x08
	struct USolarRedHint_General_C* RedHint_More; // Offset: 0x468 // Size: 0x08
	struct USolarImage* SolarImage_ClanFlag; // Offset: 0x470 // Size: 0x08
	struct USolarRichTextBlock* SolarRichTextBlock_Team; // Offset: 0x478 // Size: 0x08
	struct UTextBlock* Text_MatchDuration; // Offset: 0x480 // Size: 0x08
	struct USolarTextBlock* Text_Matching; // Offset: 0x488 // Size: 0x08
	struct USolarTextBlock* Text_Start; // Offset: 0x490 // Size: 0x08
	struct UTickerWidget_C* TickerWidget_Join; // Offset: 0x498 // Size: 0x08
	struct UTickerWidget_C* TickerWidget_Reward; // Offset: 0x4a0 // Size: 0x08
	struct USolarRichTextBlock* Txt_Activity_Point; // Offset: 0x4a8 // Size: 0x08
	struct USolarTextBlock* TXT_GameMap; // Offset: 0x4b0 // Size: 0x08
	struct USolarTextBlock* Txt_Mode; // Offset: 0x4b8 // Size: 0x08
	struct UTextBlock* Txt_Team_Num; // Offset: 0x4c0 // Size: 0x08
	struct URichTextBlock* Txt_Tournament_Reward; // Offset: 0x4c8 // Size: 0x08
	struct UUI_Component_Platform_C* UI_Component_Platform; // Offset: 0x4d0 // Size: 0x08
	struct UWidgetSwitcher* WidgetSwitcher_Activity; // Offset: 0x4d8 // Size: 0x08
	bool Leader; // Offset: 0x4e0 // Size: 0x01
	bool Matching; // Offset: 0x4e1 // Size: 0x01
	bool Ready; // Offset: 0x4e2 // Size: 0x01
	bool Disable; // Offset: 0x4e3 // Size: 0x01
	bool PC; // Offset: 0x4e4 // Size: 0x01
	char pad_0x4E5[0x3]; // Offset: 0x4e5 // Size: 0x03
	struct FLinearColor StartBtnLinearColorWordSolid; // Offset: 0x4e8 // Size: 0x10
	struct FLinearColor StartBtnLinearColorTimeSolid; // Offset: 0x4f8 // Size: 0x10
	struct FLinearColor StartBtnLinearColorWordGreyout; // Offset: 0x508 // Size: 0x10
	float ActivityIntervalTime; // Offset: 0x518 // Size: 0x04

	// Functions

	// Object Name: Function UI_Lobby_StartBtn.UI_Lobby_StartBtn_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	struct FString GetModuleName(); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UI_Lobby_StartBtn.UI_Lobby_StartBtn_C.UpdatePlatformBlendState
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void UpdatePlatformBlendState(bool NewParam); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Lobby_StartBtn.UI_Lobby_StartBtn_C.UpdatePanelState
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void UpdatePanelState(bool Leader, bool Matching, bool Ready, bool Disable); // Offset: 0x1032a8510 // Return & Params: Num(4) Size(0x4)

	// Object Name: Function UI_Lobby_StartBtn.UI_Lobby_StartBtn_C.Update All Widgets
	// Flags: [BlueprintCallable|BlueprintEvent]
	void Update All Widgets(); // Offset: 0x1032a8510 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Lobby_StartBtn.UI_Lobby_StartBtn_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void PreConstruct(bool IsDesignTime); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Lobby_StartBtn.UI_Lobby_StartBtn_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Construct(); // Offset: 0x10138549c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Lobby_StartBtn.UI_Lobby_StartBtn_C.ExecuteUbergraph_UI_Lobby_StartBtn
	// Flags: [Final|UbergraphFunction|HasDefaults]
	void ExecuteUbergraph_UI_Lobby_StartBtn(int32_t EntryPoint); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x4)
};

