#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_Lobby_TeamInvite_MIni_Popup.UI_Lobby_TeamInvite_Mini_Popup_C
// Size: 0x498 // Inherited bytes: 0x348
struct UUI_Lobby_TeamInvite_Mini_Popup_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x348 // Size: 0x08
	struct UWidgetAnimation* Anim_Enter; // Offset: 0x350 // Size: 0x08
	struct USolarButton* Btn_Join_Common; // Offset: 0x358 // Size: 0x08
	struct UButton* Btn_Player; // Offset: 0x360 // Size: 0x08
	struct UButton* Btn_Player_3; // Offset: 0x368 // Size: 0x08
	struct UHorizontalBox* HorizentalBox_Spectator; // Offset: 0x370 // Size: 0x08
	struct UHorizontalBox* HorizontalBox_CreateRoom_Invitation; // Offset: 0x378 // Size: 0x08
	struct UHorizontalBox* HorizontalBox_Home_Invitation; // Offset: 0x380 // Size: 0x08
	struct UHorizontalBox* HorizontalBox_Player; // Offset: 0x388 // Size: 0x08
	struct UHorizontalBox* HorizontalBox_Skydiving_Invitation; // Offset: 0x390 // Size: 0x08
	struct UHorizontalBox* HorizontalBox_Skydiving_Transfer; // Offset: 0x398 // Size: 0x08
	struct UHorizontalBox* HorizontalBox_Team_Application; // Offset: 0x3a0 // Size: 0x08
	struct UHorizontalBox* HorizontalBox_Team_Invitation; // Offset: 0x3a8 // Size: 0x08
	struct UImage* Img_Btn_Join; // Offset: 0x3b0 // Size: 0x08
	struct UImage* Img_GameMode_Icon; // Offset: 0x3b8 // Size: 0x08
	struct UImage* Img_Join_Common_Light; // Offset: 0x3c0 // Size: 0x08
	struct UImage* Img_Team_Num; // Offset: 0x3c8 // Size: 0x08
	struct UImage* Img_Title_BG_2; // Offset: 0x3d0 // Size: 0x08
	struct UOverlay* Overlay_Avatar; // Offset: 0x3d8 // Size: 0x08
	struct UOverlay* Overlay_Avatar_3; // Offset: 0x3e0 // Size: 0x08
	struct UCanvasPanel* Panel_Info_CreateRoom_Invitation; // Offset: 0x3e8 // Size: 0x08
	struct UCanvasPanel* Panel_Info_Invitation; // Offset: 0x3f0 // Size: 0x08
	struct UCanvasPanel* Panel_Pop_Common; // Offset: 0x3f8 // Size: 0x08
	struct UProgressBar* ProgressBar_CountDown; // Offset: 0x400 // Size: 0x08
	struct UOverlay* SizeBox_Team_Num; // Offset: 0x408 // Size: 0x08
	struct UTickerWidget_C* Text_NickName; // Offset: 0x410 // Size: 0x08
	struct USolarTextBlock* Txt_Capacity; // Offset: 0x418 // Size: 0x08
	struct USolarTextBlock* Txt_GameMode; // Offset: 0x420 // Size: 0x08
	struct USolarTextBlock* Txt_Home; // Offset: 0x428 // Size: 0x08
	struct USolarTextBlock* Txt_Invitation; // Offset: 0x430 // Size: 0x08
	struct USolarTextBlock* Txt_Join_Common; // Offset: 0x438 // Size: 0x08
	struct UTextBlock* Txt_OBCurr; // Offset: 0x440 // Size: 0x08
	struct USolarTextBlock* Txt_OBTotal; // Offset: 0x448 // Size: 0x08
	struct UTextBlock* Txt_Player; // Offset: 0x450 // Size: 0x08
	struct USolarTextBlock* Txt_PlayerIn; // Offset: 0x458 // Size: 0x08
	struct USolarTextBlock* Txt_Room_Name; // Offset: 0x460 // Size: 0x08
	struct USolarTextBlock* Txt_Skydiving; // Offset: 0x468 // Size: 0x08
	struct USolarTextBlock* Txt_Skydiving_2; // Offset: 0x470 // Size: 0x08
	struct UUI_Component_Close_C* UI_Component_Close; // Offset: 0x478 // Size: 0x08
	struct UUI_Component_PlayerHead_C* UI_Component_PlayerHead_2; // Offset: 0x480 // Size: 0x08
	struct UUI_Component_PlayerHead_C* UI_Component_PlayerHead_3; // Offset: 0x488 // Size: 0x08
	enum class T_Type_Invitation Pop_Type; // Offset: 0x490 // Size: 0x01
	char pad_0x491[0x3]; // Offset: 0x491 // Size: 0x03
	int32_t Player; // Offset: 0x494 // Size: 0x04

	// Functions

	// Object Name: Function UI_Lobby_TeamInvite_MIni_Popup.UI_Lobby_TeamInvite_Mini_Popup_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	struct FString GetModuleName(); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UI_Lobby_TeamInvite_MIni_Popup.UI_Lobby_TeamInvite_Mini_Popup_C.SetPlayer
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SetPlayer(int32_t Num); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UI_Lobby_TeamInvite_MIni_Popup.UI_Lobby_TeamInvite_Mini_Popup_C.SetType
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetType(enum class T_Type_Invitation Pop_Type); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Lobby_TeamInvite_MIni_Popup.UI_Lobby_TeamInvite_Mini_Popup_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void PreConstruct(bool IsDesignTime); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Lobby_TeamInvite_MIni_Popup.UI_Lobby_TeamInvite_Mini_Popup_C.ExecuteUbergraph_UI_Lobby_TeamInvite_Mini_Popup
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_UI_Lobby_TeamInvite_Mini_Popup(int32_t EntryPoint); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x4)
};

