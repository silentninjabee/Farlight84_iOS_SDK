#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_Lobby_Video_Hunt.UI_Lobby_Video_Hunt_C
// Size: 0x360 // Inherited bytes: 0x348
struct UUI_Lobby_Video_Hunt_C : USolarUserWidget {
	// Fields
	struct UButton* Btn_Close; // Offset: 0x348 // Size: 0x08
	struct UImage* Img_VideoPlayer; // Offset: 0x350 // Size: 0x08
	struct UMediaPlayer* MediaPlayer; // Offset: 0x358 // Size: 0x08

	// Functions

	// Object Name: Function UI_Lobby_Video_Hunt.UI_Lobby_Video_Hunt_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	struct FString GetModuleName(); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x10)
};

