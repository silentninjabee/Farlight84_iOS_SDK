#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_Root.UI_Root_C
// Size: 0x3d1 // Inherited bytes: 0x348
struct UUI_Root_C : USolarUIRoot {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x348 // Size: 0x08
	struct UCanvasPanel* BattleNoticeRoot; // Offset: 0x350 // Size: 0x08
	struct UCanvasPanel* BattleRoot; // Offset: 0x358 // Size: 0x08
	struct UCanvasPanel* BattleRootGuide; // Offset: 0x360 // Size: 0x08
	struct UCanvasPanel* BattleRootOverlay; // Offset: 0x368 // Size: 0x08
	struct UCanvasPanel* CommonRoot; // Offset: 0x370 // Size: 0x08
	struct UCanvasPanel* ExternalToolsRoot; // Offset: 0x378 // Size: 0x08
	struct UCanvasPanel* Guide; // Offset: 0x380 // Size: 0x08
	struct UCanvasPanel* Loading; // Offset: 0x388 // Size: 0x08
	struct UCanvasPanel* Map; // Offset: 0x390 // Size: 0x08
	struct UCanvasPanel* MiddleRoot; // Offset: 0x398 // Size: 0x08
	struct UCanvasPanel* NoticeRoot; // Offset: 0x3a0 // Size: 0x08
	struct UCanvasPanel* PopRoot; // Offset: 0x3a8 // Size: 0x08
	struct UCanvasPanel* Reconnecting; // Offset: 0x3b0 // Size: 0x08
	struct UCanvasPanel* TipsRoot; // Offset: 0x3b8 // Size: 0x08
	struct UCanvasPanel* UnderBattleRoot; // Offset: 0x3c0 // Size: 0x08
	float AdapterOffsetLeft; // Offset: 0x3c8 // Size: 0x04
	float AdapterOffsetRight; // Offset: 0x3cc // Size: 0x04
	bool EnableAutoAdaptation; // Offset: 0x3d0 // Size: 0x01

	// Functions

	// Object Name: Function UI_Root.UI_Root_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	struct FString GetModuleName(); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UI_Root.UI_Root_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void PreConstruct(bool IsDesignTime); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Root.UI_Root_C.CustomEvent_1
	// Flags: [HasOutParms|BlueprintCallable|BlueprintEvent]
	void CustomEvent_1(struct UObject* Publisher, struct UObject* Payload, struct TArray<struct FString>& MetaData); // Offset: 0x1032a8510 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function UI_Root.UI_Root_C.ExecuteUbergraph_UI_Root
	// Flags: [Final|UbergraphFunction|HasDefaults]
	void ExecuteUbergraph_UI_Root(int32_t EntryPoint); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x4)
};

