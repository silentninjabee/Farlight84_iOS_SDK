#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_Target_Medal_Challenge_S.UI_Target_Medal_Challenge_S_C
// Size: 0x361 // Inherited bytes: 0x348
struct UUI_Target_Medal_Challenge_S_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x348 // Size: 0x08
	struct UButton* Btn_Medal; // Offset: 0x350 // Size: 0x08
	struct UImage* Img_Medal_Icon; // Offset: 0x358 // Size: 0x08
	bool IsLock; // Offset: 0x360 // Size: 0x01

	// Functions

	// Object Name: Function UI_Target_Medal_Challenge_S.UI_Target_Medal_Challenge_S_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	struct FString GetModuleName(); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UI_Target_Medal_Challenge_S.UI_Target_Medal_Challenge_S_C.SetStateIsLocked
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetStateIsLocked(bool IsLock); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Target_Medal_Challenge_S.UI_Target_Medal_Challenge_S_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void PreConstruct(bool IsDesignTime); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Target_Medal_Challenge_S.UI_Target_Medal_Challenge_S_C.ExecuteUbergraph_UI_Target_Medal_Challenge_S
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_UI_Target_Medal_Challenge_S(int32_t EntryPoint); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x4)
};

