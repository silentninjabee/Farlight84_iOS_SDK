#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_Vip_Cards.UI_Vip_Cards_C
// Size: 0x39c // Inherited bytes: 0x348
struct UUI_Vip_Cards_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x348 // Size: 0x08
	struct UWidgetAnimation* Anim_Loop; // Offset: 0x350 // Size: 0x08
	struct UButton* Btn_Card; // Offset: 0x358 // Size: 0x08
	struct UImage* Img_Card; // Offset: 0x360 // Size: 0x08
	struct UImage* Img_Star; // Offset: 0x368 // Size: 0x08
	struct UImage* MI_Glow; // Offset: 0x370 // Size: 0x08
	struct UImage* MI_Glow_2; // Offset: 0x378 // Size: 0x08
	struct UImage* MI_Wipes; // Offset: 0x380 // Size: 0x08
	struct USizeBox* Size_Item; // Offset: 0x388 // Size: 0x08
	int32_t Type_Card; // Offset: 0x390 // Size: 0x04
	int32_t Size_W; // Offset: 0x394 // Size: 0x04
	int32_t Size_H; // Offset: 0x398 // Size: 0x04

	// Functions

	// Object Name: Function UI_Vip_Cards.UI_Vip_Cards_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	struct FString GetModuleName(); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UI_Vip_Cards.UI_Vip_Cards_C.SetCardType
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetCardType(int32_t CardType); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UI_Vip_Cards.UI_Vip_Cards_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void PreConstruct(bool IsDesignTime); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Vip_Cards.UI_Vip_Cards_C.ExecuteUbergraph_UI_Vip_Cards
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_UI_Vip_Cards(int32_t EntryPoint); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x4)
};

