#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_Warehouse_DragPanel.UI_Warehouse_DragPanel_C
// Size: 0x348 // Inherited bytes: 0x348
struct UUI_Warehouse_DragPanel_C : USolarUserWidget {
	// Functions

	// Object Name: Function UI_Warehouse_DragPanel.UI_Warehouse_DragPanel_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	struct FString GetModuleName(); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x10)
};

