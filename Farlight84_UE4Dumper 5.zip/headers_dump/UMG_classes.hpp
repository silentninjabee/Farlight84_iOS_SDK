#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class UMG.Visual
// Size: 0x28 // Inherited bytes: 0x28
struct UVisual : UObject {
};

// Object Name: Class UMG.Widget
// Size: 0x138 // Inherited bytes: 0x28
struct UWidget : UVisual {
	// Fields
	struct UPanelSlot* Slot; // Offset: 0x28 // Size: 0x08
	struct FDelegate bIsEnabledDelegate; // Offset: 0x30 // Size: 0x10
	struct FText ToolTipText; // Offset: 0x40 // Size: 0x18
	struct FDelegate ToolTipTextDelegate; // Offset: 0x58 // Size: 0x10
	struct UWidget* ToolTipWidget; // Offset: 0x68 // Size: 0x08
	struct FDelegate ToolTipWidgetDelegate; // Offset: 0x70 // Size: 0x10
	struct FDelegate VisibilityDelegate; // Offset: 0x80 // Size: 0x10
	struct FWidgetTransform RenderTransform; // Offset: 0x90 // Size: 0x1c
	struct FVector2D RenderTransformPivot; // Offset: 0xac // Size: 0x08
	char bIsVariable : 1; // Offset: 0xb4 // Size: 0x01
	char bCreatedByConstructionScript : 1; // Offset: 0xb4 // Size: 0x01
	char bIsEnabled : 1; // Offset: 0xb4 // Size: 0x01
	char bOverride_Cursor : 1; // Offset: 0xb4 // Size: 0x01
	char pad_0xB4_4 : 4; // Offset: 0xb4 // Size: 0x01
	char pad_0xB5[0x3]; // Offset: 0xb5 // Size: 0x03
	struct USlateAccessibleWidgetData* AccessibleWidgetData; // Offset: 0xb8 // Size: 0x08
	char bIsVolatile : 1; // Offset: 0xc0 // Size: 0x01
	char pad_0xC0_1 : 7; // Offset: 0xc0 // Size: 0x01
	enum class EMouseCursor Cursor; // Offset: 0xc1 // Size: 0x01
	enum class EWidgetClipping Clipping; // Offset: 0xc2 // Size: 0x01
	enum class ESlateVisibility Visibility; // Offset: 0xc3 // Size: 0x01
	float RenderOpacity; // Offset: 0xc4 // Size: 0x04
	enum class ESlateDetailMode DetailMode; // Offset: 0xc8 // Size: 0x01
	bool bSelectedDetailModeOnly; // Offset: 0xc9 // Size: 0x01
	char pad_0xCA[0x2]; // Offset: 0xca // Size: 0x02
	int32_t WidthDivisor; // Offset: 0xcc // Size: 0x04
	int32_t HeightDivisor; // Offset: 0xd0 // Size: 0x04
	char pad_0xD4[0x4]; // Offset: 0xd4 // Size: 0x04
	struct UWidgetNavigation* Navigation; // Offset: 0xd8 // Size: 0x08
	enum class EFlowDirectionPreference FlowDirectionPreference; // Offset: 0xe0 // Size: 0x01
	char pad_0xE1[0x47]; // Offset: 0xe1 // Size: 0x47
	struct TArray<struct UPropertyBinding*> NativeBindings; // Offset: 0x128 // Size: 0x10

	// Functions

	// Object Name: Function UMG.Widget.SetWidthHeightDivisors
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetWidthHeightDivisors(int32_t InWidthDivisor, int32_t InHeightDivisor); // Offset: 0x1042ac30c // Return & Params: Num(2) Size(0x8)

	// Object Name: Function UMG.Widget.SetVisibility
	// Flags: [Native|Public|BlueprintCallable]
	void SetVisibility(enum class ESlateVisibility InVisibility); // Offset: 0x1042ac590 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Widget.SetUserFocus
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetUserFocus(struct APlayerController* PlayerController); // Offset: 0x1042abe24 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.Widget.SetToolTipText
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetToolTipText(struct FText& InToolTipText); // Offset: 0x1042ac794 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function UMG.Widget.SetToolTip
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetToolTip(struct UWidget* Widget); // Offset: 0x1042ac714 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.Widget.SetSelectedDetailModeOnly
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSelectedDetailModeOnly(bool InSelectedDetailModeOnly); // Offset: 0x1042ac3d4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Widget.SetRenderTranslation
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetRenderTranslation(struct FVector2D Translation); // Offset: 0x1042ac9bc // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.Widget.SetRenderTransformPivot
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetRenderTransformPivot(struct FVector2D Pivot); // Offset: 0x1042ac940 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.Widget.SetRenderTransformAngle
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetRenderTransformAngle(float Angle); // Offset: 0x1042aca6c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.Widget.SetRenderTransform
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetRenderTransform(struct FWidgetTransform InTransform); // Offset: 0x1042acbe4 // Return & Params: Num(1) Size(0x1c)

	// Object Name: Function UMG.Widget.SetRenderShear
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetRenderShear(struct FVector2D Shear); // Offset: 0x1042acaec // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.Widget.SetRenderScale
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetRenderScale(struct FVector2D Scale); // Offset: 0x1042acb68 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.Widget.SetRenderOpacity
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetRenderOpacity(float InOpacity); // Offset: 0x1042ac4dc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.Widget.SetNavigationRuleExplicit
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetNavigationRuleExplicit(enum class EUINavigation Direction, struct UWidget* InWidget); // Offset: 0x1042aba48 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UMG.Widget.SetNavigationRuleCustomBoundary
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetNavigationRuleCustomBoundary(enum class EUINavigation Direction, struct FDelegate InCustomDelegate); // Offset: 0x1042ab850 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function UMG.Widget.SetNavigationRuleCustom
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetNavigationRuleCustom(enum class EUINavigation Direction, struct FDelegate InCustomDelegate); // Offset: 0x1042ab94c // Return & Params: Num(2) Size(0x14)

	// Object Name: Function UMG.Widget.SetNavigationRuleBase
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetNavigationRuleBase(enum class EUINavigation Direction, enum class EUINavigationRule Rule); // Offset: 0x1042abb14 // Return & Params: Num(2) Size(0x2)

	// Object Name: Function UMG.Widget.SetNavigationRule
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetNavigationRule(enum class EUINavigation Direction, enum class EUINavigationRule Rule, struct FName WidgetToFocus); // Offset: 0x1042abbe0 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function UMG.Widget.SetKeyboardFocus
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetKeyboardFocus(); // Offset: 0x1042ac040 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.Widget.SetIsEnabled
	// Flags: [Native|Public|BlueprintCallable]
	void SetIsEnabled(bool bInIsEnabled); // Offset: 0x1042ac87c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Widget.SetFocus
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetFocus(); // Offset: 0x1042abea4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.Widget.SetDetailMode
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetDetailMode(enum class ESlateDetailMode InDetailMode); // Offset: 0x1042ac45c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Widget.SetCursor
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetCursor(enum class EMouseCursor InCursor); // Offset: 0x1042ac694 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Widget.SetClipping
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetClipping(enum class EWidgetClipping InClipping); // Offset: 0x1042ac258 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Widget.SetAllNavigationRules
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAllNavigationRules(enum class EUINavigationRule Rule, struct FName WidgetToFocus); // Offset: 0x1042abcf8 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function UMG.Widget.ResetCursor
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ResetCursor(); // Offset: 0x1042ac680 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.Widget.RemoveFromParent
	// Flags: [Native|Public|BlueprintCallable]
	void RemoveFromParent(); // Offset: 0x1042ab800 // Return & Params: Num(0) Size(0x0)

	// Object Name: DelegateFunction UMG.Widget.OnReply__DelegateSignature
	// Flags: [Public|Delegate]
	struct FEventReply OnReply__DelegateSignature(); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0xb8)

	// Object Name: DelegateFunction UMG.Widget.OnPointerEvent__DelegateSignature
	// Flags: [Public|Delegate|HasOutParms]
	struct FEventReply OnPointerEvent__DelegateSignature(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent); // Offset: 0x1032a8510 // Return & Params: Num(3) Size(0x160)

	// Object Name: Function UMG.Widget.IsVisible
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsVisible(); // Offset: 0x1042ac64c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Widget.IsHovered
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsHovered(); // Offset: 0x1042ac194 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Widget.InvalidateLayoutAndVolatility
	// Flags: [Final|Native|Public|BlueprintCallable]
	void InvalidateLayoutAndVolatility(); // Offset: 0x1042abdfc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.Widget.HasUserFocusedDescendants
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool HasUserFocusedDescendants(struct APlayerController* PlayerController); // Offset: 0x1042abeb8 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function UMG.Widget.HasUserFocus
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool HasUserFocus(struct APlayerController* PlayerController); // Offset: 0x1042abfb0 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function UMG.Widget.HasMouseCaptureByUser
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool HasMouseCaptureByUser(int32_t UserIndex, int32_t PointerIndex); // Offset: 0x1042ac054 // Return & Params: Num(3) Size(0x9)

	// Object Name: Function UMG.Widget.HasMouseCapture
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool HasMouseCapture(); // Offset: 0x1042ac12c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Widget.HasKeyboardFocus
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool HasKeyboardFocus(); // Offset: 0x1042ac160 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Widget.HasFocusedDescendants
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool HasFocusedDescendants(); // Offset: 0x1042abf48 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Widget.HasAnyUserFocus
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool HasAnyUserFocus(); // Offset: 0x1042abf7c // Return & Params: Num(1) Size(0x1)

	// Object Name: DelegateFunction UMG.Widget.GetWidget__DelegateSignature
	// Flags: [Public|Delegate]
	struct UWidget* GetWidget__DelegateSignature(); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.Widget.GetVisibility
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	enum class ESlateVisibility GetVisibility(); // Offset: 0x1042ac618 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Widget.GetTickSpaceGeometry
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FGeometry GetTickSpaceGeometry(); // Offset: 0x1042ab790 // Return & Params: Num(1) Size(0x38)

	// Object Name: DelegateFunction UMG.Widget.GetText__DelegateSignature
	// Flags: [Public|Delegate]
	struct FText GetText__DelegateSignature(); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x18)

	// Object Name: DelegateFunction UMG.Widget.GetSlateVisibility__DelegateSignature
	// Flags: [Public|Delegate]
	enum class ESlateVisibility GetSlateVisibility__DelegateSignature(); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x1)

	// Object Name: DelegateFunction UMG.Widget.GetSlateColor__DelegateSignature
	// Flags: [Public|Delegate]
	struct FSlateColor GetSlateColor__DelegateSignature(); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x28)

	// Object Name: DelegateFunction UMG.Widget.GetSlateBrush__DelegateSignature
	// Flags: [Public|Delegate]
	struct FSlateBrush GetSlateBrush__DelegateSignature(); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x98)

	// Object Name: Function UMG.Widget.GetRenderTransformAngle
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetRenderTransformAngle(); // Offset: 0x1042aca38 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.Widget.GetRenderOpacity
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetRenderOpacity(); // Offset: 0x1042ac55c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.Widget.GetParent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UPanelWidget* GetParent(); // Offset: 0x1042ab81c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.Widget.GetPaintSpaceGeometry
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FGeometry GetPaintSpaceGeometry(); // Offset: 0x1042ab758 // Return & Params: Num(1) Size(0x38)

	// Object Name: Function UMG.Widget.GetOwningPlayer
	// Flags: [BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct APlayerController* GetOwningPlayer(); // Offset: 0x1042ab6e8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.Widget.GetOwningLocalPlayer
	// Flags: [BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct ULocalPlayer* GetOwningLocalPlayer(); // Offset: 0x1042ab6ac // Return & Params: Num(1) Size(0x8)

	// Object Name: DelegateFunction UMG.Widget.GetMouseCursor__DelegateSignature
	// Flags: [Public|Delegate]
	enum class EMouseCursor GetMouseCursor__DelegateSignature(); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x1)

	// Object Name: DelegateFunction UMG.Widget.GetLinearColor__DelegateSignature
	// Flags: [Public|Delegate|HasDefaults]
	struct FLinearColor GetLinearColor__DelegateSignature(); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.Widget.GetIsEnabled
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool GetIsEnabled(); // Offset: 0x1042ac90c // Return & Params: Num(1) Size(0x1)

	// Object Name: DelegateFunction UMG.Widget.GetInt32__DelegateSignature
	// Flags: [Public|Delegate]
	int32_t GetInt32__DelegateSignature(); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.Widget.GetGameInstance
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UGameInstance* GetGameInstance(); // Offset: 0x1042ab724 // Return & Params: Num(1) Size(0x8)

	// Object Name: DelegateFunction UMG.Widget.GetFloat__DelegateSignature
	// Flags: [Public|Delegate]
	float GetFloat__DelegateSignature(); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.Widget.GetDesiredSize
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FVector2D GetDesiredSize(); // Offset: 0x1042abdc4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.Widget.GetClipping
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	enum class EWidgetClipping GetClipping(); // Offset: 0x1042ac2d8 // Return & Params: Num(1) Size(0x1)

	// Object Name: DelegateFunction UMG.Widget.GetCheckBoxState__DelegateSignature
	// Flags: [Public|Delegate]
	enum class ECheckBoxState GetCheckBoxState__DelegateSignature(); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Widget.GetCachedGeometry
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FGeometry GetCachedGeometry(); // Offset: 0x1042ab7c8 // Return & Params: Num(1) Size(0x38)

	// Object Name: DelegateFunction UMG.Widget.GetBool__DelegateSignature
	// Flags: [Public|Delegate]
	bool GetBool__DelegateSignature(); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x1)

	// Object Name: DelegateFunction UMG.Widget.GenerateWidgetForString__DelegateSignature
	// Flags: [Public|Delegate]
	struct UWidget* GenerateWidgetForString__DelegateSignature(struct FString Item); // Offset: 0x1032a8510 // Return & Params: Num(2) Size(0x18)

	// Object Name: DelegateFunction UMG.Widget.GenerateWidgetForObject__DelegateSignature
	// Flags: [Public|Delegate]
	struct UWidget* GenerateWidgetForObject__DelegateSignature(struct UObject* Item); // Offset: 0x1032a8510 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UMG.Widget.ForceVolatile
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ForceVolatile(bool bForce); // Offset: 0x1042ac1d0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Widget.ForceLayoutPrepass
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ForceLayoutPrepass(); // Offset: 0x1042abe10 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class UMG.UserWidget
// Size: 0x260 // Inherited bytes: 0x138
struct UUserWidget : UWidget {
	// Fields
	char pad_0x138[0x8]; // Offset: 0x138 // Size: 0x08
	struct FLinearColor ColorAndOpacity; // Offset: 0x140 // Size: 0x10
	struct FDelegate ColorAndOpacityDelegate; // Offset: 0x150 // Size: 0x10
	struct FSlateColor ForegroundColor; // Offset: 0x160 // Size: 0x28
	struct FDelegate ForegroundColorDelegate; // Offset: 0x188 // Size: 0x10
	struct FMargin Padding; // Offset: 0x198 // Size: 0x10
	struct TArray<struct UUMGSequencePlayer*> ActiveSequencePlayers; // Offset: 0x1a8 // Size: 0x10
	struct TArray<struct UUMGSequencePlayer*> StoppedSequencePlayers; // Offset: 0x1b8 // Size: 0x10
	struct TArray<struct FNamedSlotBinding> NamedSlotBindings; // Offset: 0x1c8 // Size: 0x10
	struct UWidgetTree* WidgetTree; // Offset: 0x1d8 // Size: 0x08
	int32_t Priority; // Offset: 0x1e0 // Size: 0x04
	char bSupportsKeyboardFocus : 1; // Offset: 0x1e4 // Size: 0x01
	char bIsFocusable : 1; // Offset: 0x1e4 // Size: 0x01
	char bStopAction : 1; // Offset: 0x1e4 // Size: 0x01
	char bHasScriptImplementedTick : 1; // Offset: 0x1e4 // Size: 0x01
	char bHasScriptImplementedPaint : 1; // Offset: 0x1e4 // Size: 0x01
	char pad_0x1E4_5 : 3; // Offset: 0x1e4 // Size: 0x01
	char pad_0x1E5[0xb]; // Offset: 0x1e5 // Size: 0x0b
	enum class EWidgetTickFrequency TickFrequency; // Offset: 0x1f0 // Size: 0x01
	char pad_0x1F1[0x7]; // Offset: 0x1f1 // Size: 0x07
	struct UInputComponent* InputComponent; // Offset: 0x1f8 // Size: 0x08
	struct TArray<struct FAnimationEventBinding> AnimationCallbacks; // Offset: 0x200 // Size: 0x10
	char pad_0x210[0x50]; // Offset: 0x210 // Size: 0x50

	// Functions

	// Object Name: Function UMG.UserWidget.UnregisterInputComponent
	// Flags: [Final|Native|Protected|BlueprintCallable]
	void UnregisterInputComponent(); // Offset: 0x1042a03d8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.UserWidget.UnbindFromAnimationStarted
	// Flags: [Final|Native|Public|BlueprintCallable]
	void UnbindFromAnimationStarted(struct UWidgetAnimation* Animation, struct FDelegate Delegate); // Offset: 0x1042a1bb0 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function UMG.UserWidget.UnbindFromAnimationFinished
	// Flags: [Final|Native|Public|BlueprintCallable]
	void UnbindFromAnimationFinished(struct UWidgetAnimation* Animation, struct FDelegate Delegate); // Offset: 0x1042a1938 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function UMG.UserWidget.UnbindAllFromAnimationStarted
	// Flags: [Final|Native|Public|BlueprintCallable]
	void UnbindAllFromAnimationStarted(struct UWidgetAnimation* Animation); // Offset: 0x1042a1b30 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.UserWidget.UnbindAllFromAnimationFinished
	// Flags: [Final|Native|Public|BlueprintCallable]
	void UnbindAllFromAnimationFinished(struct UWidgetAnimation* Animation); // Offset: 0x1042a18b8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.UserWidget.Tick
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Offset: 0x1032a8510 // Return & Params: Num(2) Size(0x3c)

	// Object Name: Function UMG.UserWidget.StopListeningForInputAction
	// Flags: [Final|Native|Protected|BlueprintCallable]
	void StopListeningForInputAction(struct FName ActionName, enum class EInputEvent EventType); // Offset: 0x1042a0414 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function UMG.UserWidget.StopListeningForAllInputActions
	// Flags: [Final|Native|Protected|BlueprintCallable]
	void StopListeningForAllInputActions(); // Offset: 0x1042a0400 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.UserWidget.StopAnimationsAndLatentActions
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StopAnimationsAndLatentActions(); // Offset: 0x1042a1da8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.UserWidget.StopAnimation
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StopAnimation(struct UWidgetAnimation* InAnimation); // Offset: 0x1042a0bc8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.UserWidget.StopAllAnimations
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StopAllAnimations(); // Offset: 0x1042a0bb4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.UserWidget.SetPositionInViewport
	// Flags: [Final|BlueprintCosmetic|Native|Public|HasDefaults|BlueprintCallable]
	void SetPositionInViewport(struct FVector2D Position, bool bRemoveDPIScale); // Offset: 0x1042a20e0 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function UMG.UserWidget.SetPlaybackSpeed
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void SetPlaybackSpeed(struct UWidgetAnimation* InAnimation, float PlaybackSpeed); // Offset: 0x1042a0838 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function UMG.UserWidget.SetPadding
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void SetPadding(struct FMargin InPadding); // Offset: 0x1042a1318 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.UserWidget.SetOwningPlayer
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void SetOwningPlayer(struct APlayerController* LocalPlayerController); // Offset: 0x1042a1e04 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.UserWidget.SetNumLoopsToPlay
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void SetNumLoopsToPlay(struct UWidgetAnimation* InAnimation, int32_t NumLoopsToPlay); // Offset: 0x1042a0904 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function UMG.UserWidget.SetInputActionPriority
	// Flags: [Final|Native|Protected|BlueprintCallable]
	void SetInputActionPriority(int32_t NewPriority); // Offset: 0x1042a02c8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.UserWidget.SetInputActionBlocking
	// Flags: [Final|Native|Protected|BlueprintCallable]
	void SetInputActionBlocking(bool bShouldBlock); // Offset: 0x1042a0240 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.UserWidget.SetForegroundColor
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void SetForegroundColor(struct FSlateColor InForegroundColor); // Offset: 0x1042a139c // Return & Params: Num(1) Size(0x28)

	// Object Name: Function UMG.UserWidget.SetDesiredSizeInViewport
	// Flags: [Final|BlueprintCosmetic|Native|Public|HasDefaults|BlueprintCallable]
	void SetDesiredSizeInViewport(struct FVector2D Size); // Offset: 0x1042a2064 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.UserWidget.SetColorAndOpacity
	// Flags: [Final|BlueprintCosmetic|Native|Public|HasDefaults|BlueprintCallable]
	void SetColorAndOpacity(struct FLinearColor InColorAndOpacity); // Offset: 0x1042a150c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.UserWidget.SetAnchorsInViewport
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void SetAnchorsInViewport(struct FAnchors Anchors); // Offset: 0x1042a1fe0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.UserWidget.SetAlignmentInViewport
	// Flags: [Final|BlueprintCosmetic|Native|Public|HasDefaults|BlueprintCallable]
	void SetAlignmentInViewport(struct FVector2D Alignment); // Offset: 0x1042a1f64 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.UserWidget.ReverseAnimation
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void ReverseAnimation(struct UWidgetAnimation* InAnimation); // Offset: 0x1042a07b8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.UserWidget.RemoveFromViewport
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void RemoveFromViewport(); // Offset: 0x1042a21b0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.UserWidget.RegisterInputComponent
	// Flags: [Final|Native|Protected|BlueprintCallable]
	void RegisterInputComponent(); // Offset: 0x1042a03ec // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.UserWidget.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void PreConstruct(bool IsDesignTime); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.UserWidget.PlaySound
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void PlaySound(struct USoundBase* SoundToPlay); // Offset: 0x1042a06a8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.UserWidget.PlayEnterAnim
	// Flags: [Event|Public|BlueprintEvent]
	void PlayEnterAnim(); // Offset: 0x1032a8510 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.UserWidget.PlayAnimationTimeRange
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	struct UUMGSequencePlayer* PlayAnimationTimeRange(struct UWidgetAnimation* InAnimation, float StartAtTime, float EndAtTime, int32_t NumLoopsToPlay, enum class EUMGSequencePlayMode PlayMode, float PlaybackSpeed, bool bRestoreState); // Offset: 0x1042a0ea8 // Return & Params: Num(8) Size(0x28)

	// Object Name: Function UMG.UserWidget.PlayAnimationReverse
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	struct UUMGSequencePlayer* PlayAnimationReverse(struct UWidgetAnimation* InAnimation, float PlaybackSpeed, bool bRestoreState); // Offset: 0x1042a0c48 // Return & Params: Num(4) Size(0x18)

	// Object Name: Function UMG.UserWidget.PlayAnimationForward
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	struct UUMGSequencePlayer* PlayAnimationForward(struct UWidgetAnimation* InAnimation, float PlaybackSpeed, bool bRestoreState); // Offset: 0x1042a0d78 // Return & Params: Num(4) Size(0x18)

	// Object Name: Function UMG.UserWidget.PlayAnimation
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	struct UUMGSequencePlayer* PlayAnimation(struct UWidgetAnimation* InAnimation, float StartAtTime, int32_t NumLoopsToPlay, enum class EUMGSequencePlayMode PlayMode, float PlaybackSpeed, bool bRestoreState); // Offset: 0x1042a1104 // Return & Params: Num(7) Size(0x28)

	// Object Name: Function UMG.UserWidget.PauseAnimation
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	float PauseAnimation(struct UWidgetAnimation* InAnimation); // Offset: 0x1042a0b24 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function UMG.UserWidget.OnTouchStarted
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	struct FEventReply OnTouchStarted(struct FGeometry MyGeometry, struct FPointerEvent& InTouchEvent); // Offset: 0x1032a8510 // Return & Params: Num(3) Size(0x160)

	// Object Name: Function UMG.UserWidget.OnTouchMoved
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	struct FEventReply OnTouchMoved(struct FGeometry MyGeometry, struct FPointerEvent& InTouchEvent); // Offset: 0x1032a8510 // Return & Params: Num(3) Size(0x160)

	// Object Name: Function UMG.UserWidget.OnTouchGesture
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	struct FEventReply OnTouchGesture(struct FGeometry MyGeometry, struct FPointerEvent& GestureEvent); // Offset: 0x1032a8510 // Return & Params: Num(3) Size(0x160)

	// Object Name: Function UMG.UserWidget.OnTouchForceChanged
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	struct FEventReply OnTouchForceChanged(struct FGeometry MyGeometry, struct FPointerEvent& InTouchEvent); // Offset: 0x1032a8510 // Return & Params: Num(3) Size(0x160)

	// Object Name: Function UMG.UserWidget.OnTouchEnded
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	struct FEventReply OnTouchEnded(struct FGeometry MyGeometry, struct FPointerEvent& InTouchEvent); // Offset: 0x1032a8510 // Return & Params: Num(3) Size(0x160)

	// Object Name: Function UMG.UserWidget.OnRemovedFromFocusPath
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void OnRemovedFromFocusPath(struct FFocusEvent InFocusEvent); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.UserWidget.OnPreviewMouseButtonDown
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	struct FEventReply OnPreviewMouseButtonDown(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent); // Offset: 0x1032a8510 // Return & Params: Num(3) Size(0x160)

	// Object Name: Function UMG.UserWidget.OnPreviewKeyDown
	// Flags: [Event|Public|BlueprintEvent]
	struct FEventReply OnPreviewKeyDown(struct FGeometry MyGeometry, struct FKeyEvent InKeyEvent); // Offset: 0x1032a8510 // Return & Params: Num(3) Size(0x128)

	// Object Name: Function UMG.UserWidget.OnPaint
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent|Const]
	void OnPaint(struct FPaintContext& Context); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x30)

	// Object Name: Function UMG.UserWidget.OnMouseWheel
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	struct FEventReply OnMouseWheel(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent); // Offset: 0x1032a8510 // Return & Params: Num(3) Size(0x160)

	// Object Name: Function UMG.UserWidget.OnMouseMove
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	struct FEventReply OnMouseMove(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent); // Offset: 0x1032a8510 // Return & Params: Num(3) Size(0x160)

	// Object Name: Function UMG.UserWidget.OnMouseLeave
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	void OnMouseLeave(struct FPointerEvent& MouseEvent); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x70)

	// Object Name: Function UMG.UserWidget.OnMouseEnter
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	void OnMouseEnter(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent); // Offset: 0x1032a8510 // Return & Params: Num(2) Size(0xa8)

	// Object Name: Function UMG.UserWidget.OnMouseCaptureLost
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void OnMouseCaptureLost(); // Offset: 0x1032a8510 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.UserWidget.OnMouseButtonUp
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	struct FEventReply OnMouseButtonUp(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent); // Offset: 0x1032a8510 // Return & Params: Num(3) Size(0x160)

	// Object Name: Function UMG.UserWidget.OnMouseButtonDown
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	struct FEventReply OnMouseButtonDown(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent); // Offset: 0x1032a8510 // Return & Params: Num(3) Size(0x160)

	// Object Name: Function UMG.UserWidget.OnMouseButtonDoubleClick
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	struct FEventReply OnMouseButtonDoubleClick(struct FGeometry InMyGeometry, struct FPointerEvent& InMouseEvent); // Offset: 0x1032a8510 // Return & Params: Num(3) Size(0x160)

	// Object Name: Function UMG.UserWidget.OnMotionDetected
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	struct FEventReply OnMotionDetected(struct FGeometry MyGeometry, struct FMotionEvent InMotionEvent); // Offset: 0x1032a8510 // Return & Params: Num(3) Size(0x138)

	// Object Name: Function UMG.UserWidget.OnKeyUp
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	struct FEventReply OnKeyUp(struct FGeometry MyGeometry, struct FKeyEvent InKeyEvent); // Offset: 0x1032a8510 // Return & Params: Num(3) Size(0x128)

	// Object Name: Function UMG.UserWidget.OnKeyDown
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	struct FEventReply OnKeyDown(struct FGeometry MyGeometry, struct FKeyEvent InKeyEvent); // Offset: 0x1032a8510 // Return & Params: Num(3) Size(0x128)

	// Object Name: Function UMG.UserWidget.OnKeyChar
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	struct FEventReply OnKeyChar(struct FGeometry MyGeometry, struct FCharacterEvent InCharacterEvent); // Offset: 0x1032a8510 // Return & Params: Num(3) Size(0x110)

	// Object Name: Function UMG.UserWidget.OnInitialized
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void OnInitialized(); // Offset: 0x1032a8510 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.UserWidget.OnFocusReceived
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	struct FEventReply OnFocusReceived(struct FGeometry MyGeometry, struct FFocusEvent InFocusEvent); // Offset: 0x1032a8510 // Return & Params: Num(3) Size(0xf8)

	// Object Name: Function UMG.UserWidget.OnFocusLost
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void OnFocusLost(struct FFocusEvent InFocusEvent); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.UserWidget.OnDrop
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	bool OnDrop(struct FGeometry MyGeometry, struct FPointerEvent PointerEvent, struct UDragDropOperation* Operation); // Offset: 0x1032a8510 // Return & Params: Num(4) Size(0xb1)

	// Object Name: Function UMG.UserWidget.OnDragOver
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	bool OnDragOver(struct FGeometry MyGeometry, struct FPointerEvent PointerEvent, struct UDragDropOperation* Operation); // Offset: 0x1032a8510 // Return & Params: Num(4) Size(0xb1)

	// Object Name: Function UMG.UserWidget.OnDragLeave
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void OnDragLeave(struct FPointerEvent PointerEvent, struct UDragDropOperation* Operation); // Offset: 0x1032a8510 // Return & Params: Num(2) Size(0x78)

	// Object Name: Function UMG.UserWidget.OnDragEnter
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void OnDragEnter(struct FGeometry MyGeometry, struct FPointerEvent PointerEvent, struct UDragDropOperation* Operation); // Offset: 0x1032a8510 // Return & Params: Num(3) Size(0xb0)

	// Object Name: Function UMG.UserWidget.OnDragDetected
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	void OnDragDetected(struct FGeometry MyGeometry, struct FPointerEvent& PointerEvent, struct UDragDropOperation*& Operation); // Offset: 0x1032a8510 // Return & Params: Num(3) Size(0xb0)

	// Object Name: Function UMG.UserWidget.OnDragCancelled
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	void OnDragCancelled(struct FPointerEvent& PointerEvent, struct UDragDropOperation* Operation); // Offset: 0x1032a8510 // Return & Params: Num(2) Size(0x78)

	// Object Name: Function UMG.UserWidget.OnAnimationStarted
	// Flags: [BlueprintCosmetic|Native|Event|Protected|BlueprintEvent]
	void OnAnimationStarted(struct UWidgetAnimation* Animation); // Offset: 0x1042a1614 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.UserWidget.OnAnimationFinished
	// Flags: [BlueprintCosmetic|Native|Event|Protected|BlueprintEvent]
	void OnAnimationFinished(struct UWidgetAnimation* Animation); // Offset: 0x1042a158c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.UserWidget.OnAnalogValueChanged
	// Flags: [Event|Public|BlueprintEvent]
	struct FEventReply OnAnalogValueChanged(struct FGeometry MyGeometry, struct FAnalogInputEvent InAnalogInputEvent); // Offset: 0x1032a8510 // Return & Params: Num(3) Size(0x130)

	// Object Name: Function UMG.UserWidget.OnAddedToFocusPath
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void OnAddedToFocusPath(struct FFocusEvent InFocusEvent); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.UserWidget.ListenForInputAction
	// Flags: [Final|Native|Protected|BlueprintCallable]
	void ListenForInputAction(struct FName ActionName, enum class EInputEvent EventType, bool bConsume, struct FDelegate Callback); // Offset: 0x1042a04e0 // Return & Params: Num(4) Size(0x1c)

	// Object Name: Function UMG.UserWidget.IsPlayingAnimation
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsPlayingAnimation(); // Offset: 0x1042a0684 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.UserWidget.IsListeningForInputAction
	// Flags: [Final|Native|Protected|BlueprintCallable|BlueprintPure|Const]
	bool IsListeningForInputAction(struct FName ActionName); // Offset: 0x1042a0348 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function UMG.UserWidget.IsInViewport
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsInViewport(); // Offset: 0x1042a1e84 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.UserWidget.IsInteractable
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent|Const]
	bool IsInteractable(); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.UserWidget.IsAnyAnimationPlaying
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsAnyAnimationPlaying(); // Offset: 0x1042a09d0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.UserWidget.IsAnimationPlayingForward
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	bool IsAnimationPlayingForward(struct UWidgetAnimation* InAnimation); // Offset: 0x1042a0728 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function UMG.UserWidget.IsAnimationPlaying
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsAnimationPlaying(struct UWidgetAnimation* InAnimation); // Offset: 0x1042a0a04 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function UMG.UserWidget.GetOwningPlayerPawn
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct APawn* GetOwningPlayerPawn(); // Offset: 0x1042a1dd0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.UserWidget.GetOwningHUD
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct AHUD* GetOwningHUD(); // Offset: 0x1042a020c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.UserWidget.GetIsVisible
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool GetIsVisible(); // Offset: 0x1042a1eb8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.UserWidget.GetAnimationCurrentTime
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetAnimationCurrentTime(struct UWidgetAnimation* InAnimation); // Offset: 0x1042a0a94 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function UMG.UserWidget.GetAnchorsInViewport
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FAnchors GetAnchorsInViewport(); // Offset: 0x1042a1f24 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.UserWidget.GetAlignmentInViewport
	// Flags: [Final|BlueprintCosmetic|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FVector2D GetAlignmentInViewport(); // Offset: 0x1042a1eec // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.UserWidget.DoPlayEnterAnim
	// Flags: [Final|Native|Public|BlueprintCallable]
	void DoPlayEnterAnim(bool InPlayFlag); // Offset: 0x1042a169c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.UserWidget.Destruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Destruct(); // Offset: 0x1032a8510 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.UserWidget.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Construct(); // Offset: 0x1032a8510 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.UserWidget.CancelLatentActions
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CancelLatentActions(); // Offset: 0x1042a1dbc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.UserWidget.BindToAnimationStarted
	// Flags: [Final|Native|Public|BlueprintCallable]
	void BindToAnimationStarted(struct UWidgetAnimation* Animation, struct FDelegate Delegate); // Offset: 0x1042a1cac // Return & Params: Num(2) Size(0x18)

	// Object Name: Function UMG.UserWidget.BindToAnimationFinished
	// Flags: [Final|Native|Public|BlueprintCallable]
	void BindToAnimationFinished(struct UWidgetAnimation* Animation, struct FDelegate Delegate); // Offset: 0x1042a1a34 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function UMG.UserWidget.BindToAnimationEvent
	// Flags: [Final|Native|Public|BlueprintCallable]
	void BindToAnimationEvent(struct UWidgetAnimation* Animation, struct FDelegate Delegate, enum class EWidgetAnimationEvent AnimationEvent, struct FName UserTag); // Offset: 0x1042a1724 // Return & Params: Num(4) Size(0x24)

	// Object Name: Function UMG.UserWidget.AddToViewport
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void AddToViewport(int32_t ZOrder); // Offset: 0x1042a2254 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.UserWidget.AddToPlayerScreen
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	bool AddToPlayerScreen(int32_t ZOrder); // Offset: 0x1042a21c4 // Return & Params: Num(2) Size(0x5)
};

// Object Name: Class UMG.Slider
// Size: 0x598 // Inherited bytes: 0x138
struct USlider : UWidget {
	// Fields
	float Value; // Offset: 0x138 // Size: 0x04
	struct FDelegate ValueDelegate; // Offset: 0x13c // Size: 0x10
	float MinValue; // Offset: 0x14c // Size: 0x04
	float MaxValue; // Offset: 0x150 // Size: 0x04
	char pad_0x154[0x4]; // Offset: 0x154 // Size: 0x04
	struct FSliderStyle WidgetStyle; // Offset: 0x158 // Size: 0x3a0
	enum class EOrientation Orientation; // Offset: 0x4f8 // Size: 0x01
	char pad_0x4F9[0x3]; // Offset: 0x4f9 // Size: 0x03
	struct FLinearColor SliderBarColor; // Offset: 0x4fc // Size: 0x10
	struct FLinearColor SliderHandleColor; // Offset: 0x50c // Size: 0x10
	struct FVector2D SliderHandleOffset; // Offset: 0x51c // Size: 0x08
	bool CommitTouchStartValue; // Offset: 0x524 // Size: 0x01
	bool IndentHandle; // Offset: 0x525 // Size: 0x01
	bool Locked; // Offset: 0x526 // Size: 0x01
	bool MouseUsesStep; // Offset: 0x527 // Size: 0x01
	bool RequiresControllerLock; // Offset: 0x528 // Size: 0x01
	char pad_0x529[0x3]; // Offset: 0x529 // Size: 0x03
	float StepSize; // Offset: 0x52c // Size: 0x04
	bool IsFocusable; // Offset: 0x530 // Size: 0x01
	char pad_0x531[0x7]; // Offset: 0x531 // Size: 0x07
	struct FMulticastInlineDelegate OnMouseCaptureBegin; // Offset: 0x538 // Size: 0x10
	struct FMulticastInlineDelegate OnMouseCaptureEnd; // Offset: 0x548 // Size: 0x10
	struct FMulticastInlineDelegate OnControllerCaptureBegin; // Offset: 0x558 // Size: 0x10
	struct FMulticastInlineDelegate OnControllerCaptureEnd; // Offset: 0x568 // Size: 0x10
	struct FMulticastInlineDelegate OnValueChanged; // Offset: 0x578 // Size: 0x10
	char pad_0x588[0x10]; // Offset: 0x588 // Size: 0x10

	// Functions

	// Object Name: Function UMG.Slider.SetValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetValue(float InValue); // Offset: 0x104298fc4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.Slider.SetStepSize
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetStepSize(float InValue); // Offset: 0x104298d34 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.Slider.SetSliderHandleOffset
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetSliderHandleOffset(struct FVector2D InValue); // Offset: 0x104298bb8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.Slider.SetSliderHandleColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetSliderHandleColor(struct FLinearColor InValue); // Offset: 0x104298c34 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.Slider.SetSliderBarColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetSliderBarColor(struct FLinearColor InValue); // Offset: 0x104298cb4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.Slider.SetNormalBarImage
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetNormalBarImage(struct FSlateBrush& InImage); // Offset: 0x1042987e4 // Return & Params: Num(1) Size(0x98)

	// Object Name: Function UMG.Slider.SetMinValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMinValue(float InValue); // Offset: 0x104298f44 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.Slider.SetMaxValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMaxValue(float InValue); // Offset: 0x104298ec4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.Slider.SetLocked
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetLocked(bool InValue); // Offset: 0x104298db4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Slider.SetIndentHandle
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetIndentHandle(bool InValue); // Offset: 0x104298e3c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Slider.SetHoveredBarImage
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetHoveredBarImage(struct FSlateBrush& InImage); // Offset: 0x104298488 // Return & Params: Num(1) Size(0x98)

	// Object Name: Function UMG.Slider.SetBarThickness
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetBarThickness(float InValue); // Offset: 0x104298b3c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.Slider.GetValue
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetValue(); // Offset: 0x104299078 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.Slider.GetNormalizedValue
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetNormalizedValue(); // Offset: 0x104299044 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class UMG.PanelWidget
// Size: 0x150 // Inherited bytes: 0x138
struct UPanelWidget : UWidget {
	// Fields
	struct TArray<struct UPanelSlot*> Slots; // Offset: 0x138 // Size: 0x10
	char pad_0x148[0x8]; // Offset: 0x148 // Size: 0x08

	// Functions

	// Object Name: Function UMG.PanelWidget.RemoveChildAt
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool RemoveChildAt(int32_t Index); // Offset: 0x10428a2c8 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function UMG.PanelWidget.RemoveChild
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool RemoveChild(struct UWidget* Content); // Offset: 0x10428a1a8 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function UMG.PanelWidget.HasChild
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool HasChild(struct UWidget* Content); // Offset: 0x10428a358 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function UMG.PanelWidget.HasAnyChildren
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool HasAnyChildren(); // Offset: 0x10428a174 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.PanelWidget.GetChildrenCount
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetChildrenCount(); // Offset: 0x10428a588 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.PanelWidget.GetChildIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetChildIndex(struct UWidget* Content); // Offset: 0x10428a3e8 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function UMG.PanelWidget.GetChildAt
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UWidget* GetChildAt(int32_t Index); // Offset: 0x10428a4f8 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UMG.PanelWidget.GetAllChildren
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct TArray<struct UWidget*> GetAllChildren(); // Offset: 0x10428a478 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.PanelWidget.ClearChildren
	// Flags: [Native|Public|BlueprintCallable]
	void ClearChildren(); // Offset: 0x10428a158 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.PanelWidget.AddChild
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UPanelSlot* AddChild(struct UWidget* Content); // Offset: 0x10428a238 // Return & Params: Num(2) Size(0x10)
};

// Object Name: Class UMG.WidgetSwitcher
// Size: 0x160 // Inherited bytes: 0x150
struct UWidgetSwitcher : UPanelWidget {
	// Fields
	int32_t ActiveWidgetIndex; // Offset: 0x14c // Size: 0x04
	char pad_0x154[0xc]; // Offset: 0x154 // Size: 0x0c

	// Functions

	// Object Name: Function UMG.WidgetSwitcher.SetActiveWidgetIndex
	// Flags: [Native|Public|BlueprintCallable]
	void SetActiveWidgetIndex(int32_t Index); // Offset: 0x1042bd2b4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.WidgetSwitcher.SetActiveWidget
	// Flags: [Native|Public|BlueprintCallable]
	void SetActiveWidget(struct UWidget* Widget); // Offset: 0x1042bd22c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.WidgetSwitcher.GetWidgetAtIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UWidget* GetWidgetAtIndex(int32_t Index); // Offset: 0x1042bd19c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UMG.WidgetSwitcher.GetNumWidgets
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetNumWidgets(); // Offset: 0x1042bd370 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.WidgetSwitcher.GetActiveWidgetIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetActiveWidgetIndex(); // Offset: 0x1042bd33c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.WidgetSwitcher.GetActiveWidget
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UWidget* GetActiveWidget(); // Offset: 0x1042bd168 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class UMG.ContentWidget
// Size: 0x150 // Inherited bytes: 0x150
struct UContentWidget : UPanelWidget {
	// Functions

	// Object Name: Function UMG.ContentWidget.SetContent
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UPanelSlot* SetContent(struct UWidget* Content); // Offset: 0x104278adc // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UMG.ContentWidget.GetContentSlot
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UPanelSlot* GetContentSlot(); // Offset: 0x104278b6c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.ContentWidget.GetContent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UWidget* GetContent(); // Offset: 0x104278aa8 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class UMG.Border
// Size: 0x2a8 // Inherited bytes: 0x150
struct UBorder : UContentWidget {
	// Fields
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0x149 // Size: 0x01
	enum class EVerticalAlignment VerticalAlignment; // Offset: 0x14a // Size: 0x01
	char bShowEffectWhenDisabled : 1; // Offset: 0x14b // Size: 0x01
	struct FLinearColor ContentColorAndOpacity; // Offset: 0x14c // Size: 0x10
	struct FDelegate ContentColorAndOpacityDelegate; // Offset: 0x15c // Size: 0x10
	struct FMargin Padding; // Offset: 0x16c // Size: 0x10
	struct FSlateBrush Background; // Offset: 0x180 // Size: 0x98
	struct FDelegate BackgroundDelegate; // Offset: 0x218 // Size: 0x10
	struct FLinearColor BrushColor; // Offset: 0x228 // Size: 0x10
	struct FDelegate BrushColorDelegate; // Offset: 0x238 // Size: 0x10
	struct FVector2D DesiredSizeScale; // Offset: 0x248 // Size: 0x08
	bool bFlipForRightToLeftFlowDirection; // Offset: 0x250 // Size: 0x01
	char pad_0x253_1 : 7; // Offset: 0x253 // Size: 0x01
	struct FDelegate OnMouseButtonDownEvent; // Offset: 0x254 // Size: 0x10
	struct FDelegate OnMouseButtonUpEvent; // Offset: 0x264 // Size: 0x10
	struct FDelegate OnMouseMoveEvent; // Offset: 0x274 // Size: 0x10
	struct FDelegate OnMouseDoubleClickEvent; // Offset: 0x284 // Size: 0x10
	char pad_0x294[0x14]; // Offset: 0x294 // Size: 0x14

	// Functions

	// Object Name: Function UMG.Border.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment); // Offset: 0x104271db4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Border.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPadding(struct FMargin InPadding); // Offset: 0x104271eb4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.Border.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment); // Offset: 0x104271e34 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Border.SetDesiredSizeScale
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetDesiredSizeScale(struct FVector2D InScale); // Offset: 0x104271950 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.Border.SetContentColorAndOpacity
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetContentColorAndOpacity(struct FLinearColor InContentColorAndOpacity); // Offset: 0x104271f38 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.Border.SetBrushFromTexture
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetBrushFromTexture(struct UTexture2D* Texture); // Offset: 0x104271a80 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.Border.SetBrushFromMaterial
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetBrushFromMaterial(struct UMaterialInterface* Material); // Offset: 0x104271a00 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.Border.SetBrushFromAsset
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetBrushFromAsset(struct USlateBrushAsset* Asset); // Offset: 0x104271b00 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.Border.SetBrushColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetBrushColor(struct FLinearColor InBrushColor); // Offset: 0x104271d34 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.Border.SetBrush
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetBrush(struct FSlateBrush& InBrush); // Offset: 0x104271b80 // Return & Params: Num(1) Size(0x98)

	// Object Name: Function UMG.Border.GetDynamicMaterial
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UMaterialInstanceDynamic* GetDynamicMaterial(); // Offset: 0x1042719cc // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class UMG.DynamicEntryBoxBase
// Size: 0x1f8 // Inherited bytes: 0x138
struct UDynamicEntryBoxBase : UWidget {
	// Fields
	enum class EDynamicBoxType EntryBoxType; // Offset: 0x138 // Size: 0x01
	char pad_0x139[0x3]; // Offset: 0x139 // Size: 0x03
	struct FVector2D EntrySpacing; // Offset: 0x13c // Size: 0x08
	char pad_0x144[0x4]; // Offset: 0x144 // Size: 0x04
	struct TArray<struct FVector2D> SpacingPattern; // Offset: 0x148 // Size: 0x10
	struct FSlateChildSize EntrySizeRule; // Offset: 0x158 // Size: 0x08
	enum class EHorizontalAlignment EntryHorizontalAlignment; // Offset: 0x160 // Size: 0x01
	enum class EVerticalAlignment EntryVerticalAlignment; // Offset: 0x161 // Size: 0x01
	char pad_0x162[0x2]; // Offset: 0x162 // Size: 0x02
	int32_t MaxElementSize; // Offset: 0x164 // Size: 0x04
	char pad_0x168[0x10]; // Offset: 0x168 // Size: 0x10
	struct FUserWidgetPool EntryWidgetPool; // Offset: 0x178 // Size: 0x80

	// Functions

	// Object Name: Function UMG.DynamicEntryBoxBase.SetEntrySpacing
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void SetEntrySpacing(struct FVector2D& InEntrySpacing); // Offset: 0x10427a024 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.DynamicEntryBoxBase.GetNumEntries
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetNumEntries(); // Offset: 0x10427a0ac // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.DynamicEntryBoxBase.GetAllEntries
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct TArray<struct UUserWidget*> GetAllEntries(); // Offset: 0x10427a0e0 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class UMG.Button
// Size: 0x498 // Inherited bytes: 0x150
struct UButton : UContentWidget {
	// Fields
	struct USlateWidgetStyleAsset* Style; // Offset: 0x150 // Size: 0x08
	struct FButtonStyle WidgetStyle; // Offset: 0x158 // Size: 0x2b8
	struct FLinearColor ColorAndOpacity; // Offset: 0x410 // Size: 0x10
	struct FLinearColor BackgroundColor; // Offset: 0x420 // Size: 0x10
	enum class EButtonClickMethod ClickMethod; // Offset: 0x430 // Size: 0x01
	enum class EButtonTouchMethod TouchMethod; // Offset: 0x431 // Size: 0x01
	enum class EButtonPressMethod PressMethod; // Offset: 0x432 // Size: 0x01
	bool IsFocusable; // Offset: 0x433 // Size: 0x01
	char pad_0x434[0x4]; // Offset: 0x434 // Size: 0x04
	struct FMulticastInlineDelegate OnClicked; // Offset: 0x438 // Size: 0x10
	struct FMulticastInlineDelegate OnPressed; // Offset: 0x448 // Size: 0x10
	struct FMulticastInlineDelegate OnReleased; // Offset: 0x458 // Size: 0x10
	struct FMulticastInlineDelegate OnHovered; // Offset: 0x468 // Size: 0x10
	struct FMulticastInlineDelegate OnUnhovered; // Offset: 0x478 // Size: 0x10
	char pad_0x488[0x10]; // Offset: 0x488 // Size: 0x10

	// Functions

	// Object Name: Function UMG.Button.SetTouchMethod
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetTouchMethod(enum class EButtonTouchMethod InTouchMethod); // Offset: 0x104273160 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Button.SetStyle
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetStyle(struct FButtonStyle& InStyle); // Offset: 0x104273394 // Return & Params: Num(1) Size(0x2b8)

	// Object Name: Function UMG.Button.SetPressMethod
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPressMethod(enum class EButtonPressMethod InPressMethod); // Offset: 0x1042730e0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Button.SetColorAndOpacity
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetColorAndOpacity(struct FLinearColor InColorAndOpacity); // Offset: 0x104273314 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.Button.SetClickMethod
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetClickMethod(enum class EButtonClickMethod InClickMethod); // Offset: 0x1042731e0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Button.SetBackgroundColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetBackgroundColor(struct FLinearColor InBackgroundColor); // Offset: 0x104273294 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.Button.IsPressed
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsPressed(); // Offset: 0x104273260 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.TextLayoutWidget
// Size: 0x160 // Inherited bytes: 0x138
struct UTextLayoutWidget : UWidget {
	// Fields
	struct FShapedTextOptions ShapedTextOptions; // Offset: 0x138 // Size: 0x03
	enum class ETextJustify Justification; // Offset: 0x13b // Size: 0x01
	enum class ETextWrappingPolicy WrappingPolicy; // Offset: 0x13c // Size: 0x01
	char AutoWrapText : 1; // Offset: 0x13d // Size: 0x01
	char pad_0x13D_1 : 7; // Offset: 0x13d // Size: 0x01
	char pad_0x13E[0x2]; // Offset: 0x13e // Size: 0x02
	float WrapTextAt; // Offset: 0x140 // Size: 0x04
	struct FMargin Margin; // Offset: 0x144 // Size: 0x10
	float LineHeightPercentage; // Offset: 0x154 // Size: 0x04
	char AlwaysKeepJustification : 1; // Offset: 0x158 // Size: 0x01
	char pad_0x158_1 : 7; // Offset: 0x158 // Size: 0x01
	char pad_0x159[0x7]; // Offset: 0x159 // Size: 0x07

	// Functions

	// Object Name: Function UMG.TextLayoutWidget.SetJustification
	// Flags: [Native|Public|BlueprintCallable]
	void SetJustification(enum class ETextJustify InJustification); // Offset: 0x10429c370 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.TextBlock
// Size: 0x2f8 // Inherited bytes: 0x160
struct UTextBlock : UTextLayoutWidget {
	// Fields
	struct FText Text; // Offset: 0x160 // Size: 0x18
	struct FDelegate TextDelegate; // Offset: 0x178 // Size: 0x10
	struct FSlateColor ColorAndOpacity; // Offset: 0x188 // Size: 0x28
	struct FDelegate ColorAndOpacityDelegate; // Offset: 0x1b0 // Size: 0x10
	struct FSlateFontInfo Font; // Offset: 0x1c0 // Size: 0x60
	struct FSlateBrush StrikeBrush; // Offset: 0x220 // Size: 0x98
	struct FVector2D ShadowOffset; // Offset: 0x2b8 // Size: 0x08
	struct FLinearColor ShadowColorAndOpacity; // Offset: 0x2c0 // Size: 0x10
	struct FDelegate ShadowColorAndOpacityDelegate; // Offset: 0x2d0 // Size: 0x10
	float MinDesiredWidth; // Offset: 0x2e0 // Size: 0x04
	bool bWrapWithInvalidationPanel; // Offset: 0x2e4 // Size: 0x01
	bool bAutoWrapText; // Offset: 0x2e5 // Size: 0x01
	enum class ETextTransformPolicy TextTransformPolicy; // Offset: 0x2e6 // Size: 0x01
	bool bSimpleTextMode; // Offset: 0x2e7 // Size: 0x01
	char pad_0x2E8[0x10]; // Offset: 0x2e8 // Size: 0x10

	// Functions

	// Object Name: Function UMG.TextBlock.SetTextTransformPolicy
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetTextTransformPolicy(enum class ETextTransformPolicy InTransformPolicy); // Offset: 0x10429b2ac // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.TextBlock.SetText
	// Flags: [Native|Public|BlueprintCallable]
	void SetText(struct FText InText); // Offset: 0x10429b038 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function UMG.TextBlock.SetStrikeBrush
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetStrikeBrush(struct FSlateBrush InStrikeBrush); // Offset: 0x10429b434 // Return & Params: Num(1) Size(0x98)

	// Object Name: Function UMG.TextBlock.SetShadowOffset
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetShadowOffset(struct FVector2D InShadowOffset); // Offset: 0x10429b8a4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.TextBlock.SetShadowColorAndOpacity
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetShadowColorAndOpacity(struct FLinearColor InShadowColorAndOpacity); // Offset: 0x10429b920 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.TextBlock.SetOpacity
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetOpacity(float InOpacity); // Offset: 0x10429b9a0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.TextBlock.SetMinDesiredWidth
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMinDesiredWidth(float InMinDesiredWidth); // Offset: 0x10429b3b4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.TextBlock.SetFont
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetFont(struct FSlateFontInfo InFontInfo); // Offset: 0x10429b728 // Return & Params: Num(1) Size(0x60)

	// Object Name: Function UMG.TextBlock.SetColorAndOpacity
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetColorAndOpacity(struct FSlateColor InColorAndOpacity); // Offset: 0x10429ba20 // Return & Params: Num(1) Size(0x28)

	// Object Name: Function UMG.TextBlock.SetAutoWrapText
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAutoWrapText(bool InAutoTextWrap); // Offset: 0x10429b32c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.TextBlock.GetText
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FText GetText(); // Offset: 0x10429b19c // Return & Params: Num(1) Size(0x18)

	// Object Name: Function UMG.TextBlock.GetDynamicOutlineMaterial
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UMaterialInstanceDynamic* GetDynamicOutlineMaterial(); // Offset: 0x10429b244 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.TextBlock.GetDynamicFontMaterial
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UMaterialInstanceDynamic* GetDynamicFontMaterial(); // Offset: 0x10429b278 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class UMG.ScrollBox
// Size: 0x980 // Inherited bytes: 0x150
struct UScrollBox : UPanelWidget {
	// Fields
	struct FScrollBoxStyle WidgetStyle; // Offset: 0x150 // Size: 0x268
	struct FScrollBarStyle WidgetBarStyle; // Offset: 0x3b8 // Size: 0x560
	struct USlateWidgetStyleAsset* Style; // Offset: 0x918 // Size: 0x08
	struct USlateWidgetStyleAsset* BarStyle; // Offset: 0x920 // Size: 0x08
	enum class EOrientation Orientation; // Offset: 0x928 // Size: 0x01
	enum class ESlateVisibility ScrollBarVisibility; // Offset: 0x929 // Size: 0x01
	enum class EConsumeMouseWheel ConsumeMouseWheel; // Offset: 0x92a // Size: 0x01
	char pad_0x92B[0x1]; // Offset: 0x92b // Size: 0x01
	struct FVector2D ScrollbarThickness; // Offset: 0x92c // Size: 0x08
	struct FMargin ScrollbarPadding; // Offset: 0x934 // Size: 0x10
	bool AlwaysShowScrollbar; // Offset: 0x944 // Size: 0x01
	bool AlwaysShowScrollbarTrack; // Offset: 0x945 // Size: 0x01
	bool AllowOverscroll; // Offset: 0x946 // Size: 0x01
	bool bAnimateWheelScrolling; // Offset: 0x947 // Size: 0x01
	enum class EDescendantScrollDestination NavigationDestination; // Offset: 0x948 // Size: 0x01
	char pad_0x949[0x3]; // Offset: 0x949 // Size: 0x03
	float NavigationScrollPadding; // Offset: 0x94c // Size: 0x04
	enum class EScrollWhenFocusChanges ScrollWhenFocusChanges; // Offset: 0x950 // Size: 0x01
	bool bAllowRightClickDragScrolling; // Offset: 0x951 // Size: 0x01
	char pad_0x952[0x2]; // Offset: 0x952 // Size: 0x02
	float WheelScrollMultiplier; // Offset: 0x954 // Size: 0x04
	struct FMulticastInlineDelegate OnUserScrolled; // Offset: 0x958 // Size: 0x10
	char pad_0x968[0x18]; // Offset: 0x968 // Size: 0x18

	// Functions

	// Object Name: Function UMG.ScrollBox.SetWheelScrollMultiplier
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetWheelScrollMultiplier(float NewWheelScrollMultiplier); // Offset: 0x104291cec // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.ScrollBox.SetScrollOffset
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetScrollOffset(float NewScrollOffset); // Offset: 0x104291c58 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.ScrollBox.SetScrollBarVisibility
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetScrollBarVisibility(enum class ESlateVisibility NewScrollBarVisibility); // Offset: 0x104292018 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.ScrollBox.SetScrollbarThickness
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void SetScrollbarThickness(struct FVector2D& NewScrollbarThickness); // Offset: 0x104291f90 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.ScrollBox.SetScrollbarPadding
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetScrollbarPadding(struct FMargin& NewScrollbarPadding); // Offset: 0x104291f04 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.ScrollBox.SetOrientation
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetOrientation(enum class EOrientation NewOrientation); // Offset: 0x104292098 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.ScrollBox.SetConsumeMouseWheel
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetConsumeMouseWheel(enum class EConsumeMouseWheel NewConsumeMouseWheel); // Offset: 0x104292118 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.ScrollBox.SetAnimateWheelScrolling
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAnimateWheelScrolling(bool bShouldAnimateWheelScrolling); // Offset: 0x104291d6c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.ScrollBox.SetAlwaysShowScrollbar
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAlwaysShowScrollbar(bool NewAlwaysShowScrollbar); // Offset: 0x104291e7c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.ScrollBox.SetAllowOverscroll
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAllowOverscroll(bool NewAllowOverscroll); // Offset: 0x104291df4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.ScrollBox.ScrollWidgetIntoView
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ScrollWidgetIntoView(struct UWidget* WidgetToFind, bool AnimateScroll, enum class EDescendantScrollDestination ScrollDestination, float Padding); // Offset: 0x104291a1c // Return & Params: Num(4) Size(0x10)

	// Object Name: Function UMG.ScrollBox.ScrollToStart
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ScrollToStart(); // Offset: 0x104291ba8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.ScrollBox.ScrollToEnd
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ScrollToEnd(); // Offset: 0x104291b94 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.ScrollBox.GetViewOffsetFraction
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetViewOffsetFraction(); // Offset: 0x104291bbc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.ScrollBox.GetScrollOffsetOfEnd
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetScrollOffsetOfEnd(); // Offset: 0x104291bf0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.ScrollBox.GetScrollOffset
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetScrollOffset(); // Offset: 0x104291c24 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.ScrollBox.EndInertialScrolling
	// Flags: [Final|Native|Public|BlueprintCallable]
	void EndInertialScrolling(); // Offset: 0x104291cd8 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class UMG.Image
// Size: 0x250 // Inherited bytes: 0x138
struct UImage : UWidget {
	// Fields
	struct FSlateBrush Brush; // Offset: 0x138 // Size: 0x98
	struct FDelegate BrushDelegate; // Offset: 0x1d0 // Size: 0x10
	struct FLinearColor ColorAndOpacity; // Offset: 0x1e0 // Size: 0x10
	struct FDelegate ColorAndOpacityDelegate; // Offset: 0x1f0 // Size: 0x10
	bool bFlipForRightToLeftFlowDirection; // Offset: 0x200 // Size: 0x01
	char pad_0x201[0x3]; // Offset: 0x201 // Size: 0x03
	struct FDelegate OnMouseButtonDownEvent; // Offset: 0x204 // Size: 0x10
	char pad_0x214[0x3c]; // Offset: 0x214 // Size: 0x3c

	// Functions

	// Object Name: Function UMG.Image.SetOpacity
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetOpacity(float InOpacity); // Offset: 0x10427fe78 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.Image.SetColorAndOpacity
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetColorAndOpacity(struct FLinearColor InColorAndOpacity); // Offset: 0x10427fef8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.Image.SetBrushTintColor
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetBrushTintColor(struct FSlateColor TintColor); // Offset: 0x10427fc8c // Return & Params: Num(1) Size(0x28)

	// Object Name: Function UMG.Image.SetBrushSize
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetBrushSize(struct FVector2D DesiredSize); // Offset: 0x10427fdfc // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.Image.SetBrushResourceObject
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetBrushResourceObject(struct UObject* ResourceObject); // Offset: 0x10427fc0c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.Image.SetBrushFromTextureDynamic
	// Flags: [Native|Public|BlueprintCallable]
	void SetBrushFromTextureDynamic(struct UTexture2DDynamic* Texture, bool bMatchSize); // Offset: 0x10427f724 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function UMG.Image.SetBrushFromTexture
	// Flags: [Native|Public|BlueprintCallable]
	void SetBrushFromTexture(struct UTexture2D* Texture, bool bMatchSize); // Offset: 0x10427f8ec // Return & Params: Num(2) Size(0x9)

	// Object Name: Function UMG.Image.SetBrushFromSoftTexture
	// Flags: [Native|Public|BlueprintCallable]
	void SetBrushFromSoftTexture(struct TSoftObjectPtr<UTexture2D> SoftTexture, bool bMatchSize); // Offset: 0x10427f544 // Return & Params: Num(2) Size(0x29)

	// Object Name: Function UMG.Image.SetBrushFromSoftMaterial
	// Flags: [Native|Public|BlueprintCallable]
	void SetBrushFromSoftMaterial(struct TSoftObjectPtr<UMaterialInterface> SoftMaterial); // Offset: 0x10427f440 // Return & Params: Num(1) Size(0x28)

	// Object Name: Function UMG.Image.SetBrushFromMaterial
	// Flags: [Native|Public|BlueprintCallable]
	void SetBrushFromMaterial(struct UMaterialInterface* Material); // Offset: 0x10427f69c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.Image.SetBrushFromAtlasInterface
	// Flags: [Native|Public|BlueprintCallable]
	void SetBrushFromAtlasInterface(struct TScriptInterface<ISlateTextureAtlasInterface> AtlasRegion, bool bMatchSize); // Offset: 0x10427f800 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function UMG.Image.SetBrushFromAsset
	// Flags: [Native|Public|BlueprintCallable]
	void SetBrushFromAsset(struct USlateBrushAsset* Asset); // Offset: 0x10427f9c8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.Image.SetBrush
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	void SetBrush(struct FSlateBrush& InBrush); // Offset: 0x10427fa50 // Return & Params: Num(1) Size(0x98)

	// Object Name: Function UMG.Image.GetDynamicMaterial
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UMaterialInstanceDynamic* GetDynamicMaterial(); // Offset: 0x10427f40c // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class UMG.ListViewBase
// Size: 0x7c8 // Inherited bytes: 0x138
struct UListViewBase : UWidget {
	// Fields
	struct UUserWidget* EntryWidgetClass; // Offset: 0x138 // Size: 0x08
	float WheelScrollMultiplier; // Offset: 0x140 // Size: 0x04
	bool bEnableScrollAnimation; // Offset: 0x144 // Size: 0x01
	bool bEnableFixedLineOffset; // Offset: 0x145 // Size: 0x01
	bool bClampScroll; // Offset: 0x146 // Size: 0x01
	bool bDisableScroll; // Offset: 0x147 // Size: 0x01
	float FixedLineScrollOffset; // Offset: 0x148 // Size: 0x04
	char pad_0x14C[0x4]; // Offset: 0x14c // Size: 0x04
	struct FMulticastInlineDelegate BP_OnEntryGenerated; // Offset: 0x150 // Size: 0x10
	struct FMulticastInlineDelegate BP_OnEntryReleased; // Offset: 0x160 // Size: 0x10
	struct FUserWidgetPool EntryWidgetPool; // Offset: 0x170 // Size: 0x80
	struct FScrollBarStyle WidgetBarStyle; // Offset: 0x1f0 // Size: 0x560
	enum class ESlateVisibility ScrollBarVisibility; // Offset: 0x750 // Size: 0x01
	char pad_0x751[0x3]; // Offset: 0x751 // Size: 0x03
	struct FVector2D ScrollbarThickness; // Offset: 0x754 // Size: 0x08
	struct FMargin ScrollbarPadding; // Offset: 0x75c // Size: 0x10
	bool AlwaysShowScrollbar; // Offset: 0x76c // Size: 0x01
	bool AlwaysShowScrollbarTrack; // Offset: 0x76d // Size: 0x01
	char pad_0x76E[0x5a]; // Offset: 0x76e // Size: 0x5a

	// Functions

	// Object Name: Function UMG.ListViewBase.SetWheelScrollMultiplier
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetWheelScrollMultiplier(float NewWheelScrollMultiplier); // Offset: 0x104284510 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.ListViewBase.SetScrollOffset
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetScrollOffset(float InScrollOffset); // Offset: 0x1042845c4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.ListViewBase.SetScrollBarVisibility
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetScrollBarVisibility(enum class ESlateVisibility InVisibility); // Offset: 0x104284490 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.ListViewBase.SetScrollbarThickness
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void SetScrollbarThickness(struct FVector2D& NewScrollbarThickness); // Offset: 0x1042842b0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.ListViewBase.SetScrollbarPadding
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetScrollbarPadding(struct FMargin& NewScrollbarPadding); // Offset: 0x104284224 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.ListViewBase.SetEnableScrollAnimation
	// Flags: [Final|Native|Protected|BlueprintCallable]
	void SetEnableScrollAnimation(bool bNewEnableScrollAnimation); // Offset: 0x104284338 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.ListViewBase.SetDisableScroll
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetDisableScroll(bool bInDisableScroll); // Offset: 0x104284408 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.ListViewBase.SetAlwaysShowScrollbar
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAlwaysShowScrollbar(bool NewAlwaysShowScrollbar); // Offset: 0x10428419c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.ListViewBase.ScrollToTop
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ScrollToTop(); // Offset: 0x104284658 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.ListViewBase.ScrollToBottom
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ScrollToBottom(); // Offset: 0x104284644 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.ListViewBase.RequestRefresh
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RequestRefresh(); // Offset: 0x1042843c0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.ListViewBase.RegenerateAllEntries
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RegenerateAllEntries(); // Offset: 0x10428466c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.ListViewBase.GetScrollOffset
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetScrollOffset(); // Offset: 0x104284590 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.ListViewBase.GetDisplayedEntryWidgets
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct TArray<struct UUserWidget*> GetDisplayedEntryWidgets(); // Offset: 0x104284680 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.ListViewBase.GetDisableScroll
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool GetDisableScroll(); // Offset: 0x1042843d4 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.ListView
// Size: 0x950 // Inherited bytes: 0x7c8
struct UListView : UListViewBase {
	// Fields
	char pad_0x7C8[0xc0]; // Offset: 0x7c8 // Size: 0xc0
	enum class EOrientation Orientation; // Offset: 0x888 // Size: 0x01
	enum class ESelectionMode SelectionMode; // Offset: 0x889 // Size: 0x01
	enum class EConsumeMouseWheel ConsumeMouseWheel; // Offset: 0x88a // Size: 0x01
	bool bClearSelectionOnClick; // Offset: 0x88b // Size: 0x01
	bool bIsFocusable; // Offset: 0x88c // Size: 0x01
	char pad_0x88D[0x3]; // Offset: 0x88d // Size: 0x03
	float EntrySpacing; // Offset: 0x890 // Size: 0x04
	bool bReturnFocusToSelection; // Offset: 0x894 // Size: 0x01
	char pad_0x895[0x3]; // Offset: 0x895 // Size: 0x03
	float ListItemStartPosOffset; // Offset: 0x898 // Size: 0x04
	char pad_0x89C[0x4]; // Offset: 0x89c // Size: 0x04
	struct TArray<struct UObject*> ListItems; // Offset: 0x8a0 // Size: 0x10
	char pad_0x8B0[0x10]; // Offset: 0x8b0 // Size: 0x10
	bool EnableDelayAdd; // Offset: 0x8c0 // Size: 0x01
	char pad_0x8C1[0x3]; // Offset: 0x8c1 // Size: 0x03
	float DelayAddInterval; // Offset: 0x8c4 // Size: 0x04
	int32_t NumInPanel; // Offset: 0x8c8 // Size: 0x04
	char pad_0x8CC[0x4]; // Offset: 0x8cc // Size: 0x04
	struct TArray<struct UObject*> DelayAddedListItems; // Offset: 0x8d0 // Size: 0x10
	bool DelayAddAnimFlag; // Offset: 0x8e0 // Size: 0x01
	char pad_0x8E1[0x7]; // Offset: 0x8e1 // Size: 0x07
	struct FMulticastInlineDelegate BP_OnEntryInitialized; // Offset: 0x8e8 // Size: 0x10
	struct FMulticastInlineDelegate BP_OnItemClicked; // Offset: 0x8f8 // Size: 0x10
	struct FMulticastInlineDelegate BP_OnItemDoubleClicked; // Offset: 0x908 // Size: 0x10
	struct FMulticastInlineDelegate BP_OnItemIsHoveredChanged; // Offset: 0x918 // Size: 0x10
	struct FMulticastInlineDelegate BP_OnItemSelectionChanged; // Offset: 0x928 // Size: 0x10
	struct FMulticastInlineDelegate BP_OnItemScrolledIntoView; // Offset: 0x938 // Size: 0x10
	char pad_0x948[0x8]; // Offset: 0x948 // Size: 0x08

	// Functions

	// Object Name: Function UMG.ListView.SetSelectionMode
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSelectionMode(enum class ESelectionMode SelectionMode); // Offset: 0x104283154 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.ListView.SetSelectedIndex
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSelectedIndex(int32_t Index); // Offset: 0x104283020 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.ListView.ScrollIndexIntoView
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ScrollIndexIntoView(int32_t Index); // Offset: 0x1042830a0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.ListView.RemoveItem
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RemoveItem(struct UObject* Item); // Offset: 0x10428333c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.ListView.NavigateToIndex
	// Flags: [Final|Native|Public|BlueprintCallable]
	void NavigateToIndex(int32_t Index); // Offset: 0x104282fa0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.ListView.IsRefreshPending
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsRefreshPending(); // Offset: 0x104283120 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.ListView.GetNumItems
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetNumItems(); // Offset: 0x104283278 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.ListView.GetListItems
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct TArray<struct UObject*> GetListItems(); // Offset: 0x1042834c0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.ListView.GetItemAt
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UObject* GetItemAt(int32_t Index); // Offset: 0x1042832ac // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UMG.ListView.GetIndexForItem
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetIndexForItem(struct UObject* Item); // Offset: 0x1042831e8 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function UMG.ListView.GetDelayAddedListItems
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct TArray<struct UObject*> GetDelayAddedListItems(); // Offset: 0x10428343c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.ListView.ClearListItems
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearListItems(); // Offset: 0x1042831d4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.ListView.BP_SetSelectedItem
	// Flags: [Final|Native|Private|BlueprintCallable]
	void BP_SetSelectedItem(struct UObject* Item); // Offset: 0x104282f20 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.ListView.BP_SetListItems
	// Flags: [Final|Native|Private|HasOutParms|BlueprintCallable]
	void BP_SetListItems(struct TArray<struct UObject*>& InListItems); // Offset: 0x104282b20 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.ListView.BP_SetItemSelection
	// Flags: [Final|Native|Private|BlueprintCallable]
	void BP_SetItemSelection(struct UObject* Item, bool bSelected); // Offset: 0x104282e4c // Return & Params: Num(2) Size(0x9)

	// Object Name: Function UMG.ListView.BP_SetDelayAddListItems
	// Flags: [Final|Native|Private|HasOutParms|BlueprintCallable]
	void BP_SetDelayAddListItems(struct TArray<struct UObject*>& InListItems); // Offset: 0x104282a54 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.ListView.BP_ScrollItemIntoView
	// Flags: [Final|Native|Private|BlueprintCallable]
	void BP_ScrollItemIntoView(struct UObject* Item); // Offset: 0x104282bcc // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.ListView.BP_NavigateToItem
	// Flags: [Final|Native|Private|BlueprintCallable]
	void BP_NavigateToItem(struct UObject* Item); // Offset: 0x104282c4c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.ListView.BP_IsItemVisible
	// Flags: [Final|Native|Private|BlueprintCallable|BlueprintPure|Const]
	bool BP_IsItemVisible(struct UObject* Item); // Offset: 0x104282ccc // Return & Params: Num(2) Size(0x9)

	// Object Name: Function UMG.ListView.BP_GetSelectedItems
	// Flags: [Final|Native|Private|HasOutParms|BlueprintCallable|Const]
	bool BP_GetSelectedItems(struct TArray<struct UObject*>& Items); // Offset: 0x104282d5c // Return & Params: Num(2) Size(0x11)

	// Object Name: Function UMG.ListView.BP_GetSelectedItem
	// Flags: [Final|Native|Private|BlueprintCallable|BlueprintPure|Const]
	struct UObject* BP_GetSelectedItem(); // Offset: 0x104282aec // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.ListView.BP_GetNumItemsSelected
	// Flags: [Final|Native|Private|BlueprintCallable|BlueprintPure|Const]
	int32_t BP_GetNumItemsSelected(); // Offset: 0x104282e04 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.ListView.BP_DoDelayAddTick
	// Flags: [Final|Native|Private|BlueprintCallable]
	void BP_DoDelayAddTick(float DeltaTime); // Offset: 0x1042829d4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.ListView.BP_ClearSelection
	// Flags: [Final|Native|Private|BlueprintCallable]
	void BP_ClearSelection(); // Offset: 0x104282e38 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.ListView.BP_CancelScrollIntoView
	// Flags: [Final|Native|Private|BlueprintCallable]
	void BP_CancelScrollIntoView(); // Offset: 0x104282bb8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.ListView.AddItem
	// Flags: [Final|Native|Public|BlueprintCallable]
	void AddItem(struct UObject* Item); // Offset: 0x1042833bc // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class UMG.PanelSlot
// Size: 0x38 // Inherited bytes: 0x28
struct UPanelSlot : UVisual {
	// Fields
	struct UPanelWidget* Parent; // Offset: 0x28 // Size: 0x08
	struct UWidget* Content; // Offset: 0x30 // Size: 0x08
};

// Object Name: Class UMG.RichTextBlock
// Size: 0x720 // Inherited bytes: 0x160
struct URichTextBlock : UTextLayoutWidget {
	// Fields
	struct FText Text; // Offset: 0x160 // Size: 0x18
	struct UDataTable* TextStyleSet; // Offset: 0x178 // Size: 0x08
	struct TArray<struct URichTextBlockDecorator*> DecoratorClasses; // Offset: 0x180 // Size: 0x10
	bool bOverrideDefaultStyle; // Offset: 0x190 // Size: 0x01
	char pad_0x191[0x7]; // Offset: 0x191 // Size: 0x07
	struct FTextBlockStyle DefaultTextStyleOverride; // Offset: 0x198 // Size: 0x2a8
	float MinDesiredWidth; // Offset: 0x440 // Size: 0x04
	enum class ETextTransformPolicy TextTransformPolicy; // Offset: 0x444 // Size: 0x01
	char pad_0x445[0x3]; // Offset: 0x445 // Size: 0x03
	struct FTextBlockStyle DefaultTextStyle; // Offset: 0x448 // Size: 0x2a8
	struct TArray<struct URichTextBlockDecorator*> InstanceDecorators; // Offset: 0x6f0 // Size: 0x10
	char pad_0x700[0x20]; // Offset: 0x700 // Size: 0x20

	// Functions

	// Object Name: Function UMG.RichTextBlock.SetTextTransformPolicy
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetTextTransformPolicy(enum class ETextTransformPolicy InTransformPolicy); // Offset: 0x10428f138 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.RichTextBlock.SetTextStyleSet
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetTextStyleSet(struct UDataTable* NewTextStyleSet); // Offset: 0x10428ee6c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.RichTextBlock.SetText
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	void SetText(struct FText& InText); // Offset: 0x10428eeec // Return & Params: Num(1) Size(0x18)

	// Object Name: Function UMG.RichTextBlock.SetMinDesiredWidth
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMinDesiredWidth(float InMinDesiredWidth); // Offset: 0x10428f240 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.RichTextBlock.SetDefaultTextStyle
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetDefaultTextStyle(struct FTextBlockStyle& InDefaultTextStyle); // Offset: 0x10428f098 // Return & Params: Num(1) Size(0x2a8)

	// Object Name: Function UMG.RichTextBlock.SetDefaultStrikeBrush
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetDefaultStrikeBrush(struct FSlateBrush& InStrikeBrush); // Offset: 0x10428f2c0 // Return & Params: Num(1) Size(0x98)

	// Object Name: Function UMG.RichTextBlock.SetDefaultShadowOffset
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetDefaultShadowOffset(struct FVector2D InShadowOffset); // Offset: 0x10428f5f0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.RichTextBlock.SetDefaultShadowColorAndOpacity
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetDefaultShadowColorAndOpacity(struct FLinearColor InShadowColorAndOpacity); // Offset: 0x10428f66c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.RichTextBlock.SetDefaultFont
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetDefaultFont(struct FSlateFontInfo InFontInfo); // Offset: 0x10428f474 // Return & Params: Num(1) Size(0x60)

	// Object Name: Function UMG.RichTextBlock.SetDefaultColorAndOpacity
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetDefaultColorAndOpacity(struct FSlateColor InColorAndOpacity); // Offset: 0x10428f6ec // Return & Params: Num(1) Size(0x28)

	// Object Name: Function UMG.RichTextBlock.SetAutoWrapText
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAutoWrapText(bool InAutoTextWrap); // Offset: 0x10428f1b8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.RichTextBlock.GetText
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FText GetText(); // Offset: 0x10428efdc // Return & Params: Num(1) Size(0x18)

	// Object Name: Function UMG.RichTextBlock.GetDecoratorByClass
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct URichTextBlockDecorator* GetDecoratorByClass(struct URichTextBlockDecorator* DecoratorClass); // Offset: 0x10428eddc // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UMG.RichTextBlock.ClearAllDefaultStyleOverrides
	// Flags: [Final|Native|Public]
	void ClearAllDefaultStyleOverrides(); // Offset: 0x10428f084 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class UMG.TileView
// Size: 0x968 // Inherited bytes: 0x950
struct UTileView : UListView {
	// Fields
	float EntryHeight; // Offset: 0x94c // Size: 0x04
	float EntryWidth; // Offset: 0x950 // Size: 0x04
	enum class EListItemAlignment TileAlignment; // Offset: 0x954 // Size: 0x01
	bool bWrapHorizontalNavigation; // Offset: 0x955 // Size: 0x01
	char pad_0x95A[0xe]; // Offset: 0x95a // Size: 0x0e

	// Functions

	// Object Name: Function UMG.TileView.SetEntryWidth
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetEntryWidth(float NewWidth); // Offset: 0x10429e2d8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.TileView.SetEntryHeight
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetEntryHeight(float NewHeight); // Offset: 0x10429e358 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class UMG.TreeView
// Size: 0x9a8 // Inherited bytes: 0x950
struct UTreeView : UListView {
	// Fields
	char pad_0x950[0x10]; // Offset: 0x950 // Size: 0x10
	struct FDelegate BP_OnGetItemChildren; // Offset: 0x960 // Size: 0x10
	struct FMulticastInlineDelegate BP_OnItemExpansionChanged; // Offset: 0x970 // Size: 0x10
	char pad_0x980[0x28]; // Offset: 0x980 // Size: 0x28

	// Functions

	// Object Name: Function UMG.TreeView.SetItemExpansion
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetItemExpansion(struct UObject* Item, bool bExpandItem); // Offset: 0x10429e824 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function UMG.TreeView.ExpandAll
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ExpandAll(); // Offset: 0x10429e810 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.TreeView.CollapseAll
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CollapseAll(); // Offset: 0x10429e7fc // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class UMG.Overlay
// Size: 0x160 // Inherited bytes: 0x150
struct UOverlay : UPanelWidget {
	// Fields
	char pad_0x150[0x10]; // Offset: 0x150 // Size: 0x10

	// Functions

	// Object Name: Function UMG.Overlay.AddChildToOverlay
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UOverlaySlot* AddChildToOverlay(struct UWidget* Content); // Offset: 0x104289608 // Return & Params: Num(2) Size(0x10)
};

// Object Name: Class UMG.OverlaySlot
// Size: 0x58 // Inherited bytes: 0x38
struct UOverlaySlot : UPanelSlot {
	// Fields
	char pad_0x38[0x8]; // Offset: 0x38 // Size: 0x08
	struct FMargin Padding; // Offset: 0x40 // Size: 0x10
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0x50 // Size: 0x01
	enum class EVerticalAlignment VerticalAlignment; // Offset: 0x51 // Size: 0x01
	char pad_0x52[0x6]; // Offset: 0x52 // Size: 0x06

	// Functions

	// Object Name: Function UMG.OverlaySlot.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment); // Offset: 0x104289a7c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.OverlaySlot.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPadding(struct FMargin InPadding); // Offset: 0x104289b7c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.OverlaySlot.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment); // Offset: 0x104289afc // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.SizeBox
// Size: 0x188 // Inherited bytes: 0x150
struct USizeBox : UContentWidget {
	// Fields
	char pad_0x150[0x10]; // Offset: 0x150 // Size: 0x10
	float WidthOverride; // Offset: 0x160 // Size: 0x04
	float HeightOverride; // Offset: 0x164 // Size: 0x04
	float MinDesiredWidth; // Offset: 0x168 // Size: 0x04
	float MinDesiredHeight; // Offset: 0x16c // Size: 0x04
	float MaxDesiredWidth; // Offset: 0x170 // Size: 0x04
	float MaxDesiredHeight; // Offset: 0x174 // Size: 0x04
	float MinAspectRatio; // Offset: 0x178 // Size: 0x04
	float MaxAspectRatio; // Offset: 0x17c // Size: 0x04
	char bOverride_WidthOverride : 1; // Offset: 0x180 // Size: 0x01
	char bOverride_HeightOverride : 1; // Offset: 0x180 // Size: 0x01
	char bOverride_MinDesiredWidth : 1; // Offset: 0x180 // Size: 0x01
	char bOverride_MinDesiredHeight : 1; // Offset: 0x180 // Size: 0x01
	char bOverride_MaxDesiredWidth : 1; // Offset: 0x180 // Size: 0x01
	char bOverride_MaxDesiredHeight : 1; // Offset: 0x180 // Size: 0x01
	char bOverride_MinAspectRatio : 1; // Offset: 0x180 // Size: 0x01
	char bOverride_MaxAspectRatio : 1; // Offset: 0x180 // Size: 0x01
	char pad_0x181[0x7]; // Offset: 0x181 // Size: 0x07

	// Functions

	// Object Name: Function UMG.SizeBox.SetWidthOverride
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetWidthOverride(float InWidthOverride); // Offset: 0x104293374 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.SizeBox.SetMinDesiredWidth
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMinDesiredWidth(float InMinDesiredWidth); // Offset: 0x10429324c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.SizeBox.SetMinDesiredHeight
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMinDesiredHeight(float InMinDesiredHeight); // Offset: 0x1042931b8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.SizeBox.SetMinAspectRatio
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMinAspectRatio(float InMinAspectRatio); // Offset: 0x104292ffc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.SizeBox.SetMaxDesiredWidth
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMaxDesiredWidth(float InMaxDesiredWidth); // Offset: 0x104293124 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.SizeBox.SetMaxDesiredHeight
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMaxDesiredHeight(float InMaxDesiredHeight); // Offset: 0x104293090 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.SizeBox.SetMaxAspectRatio
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMaxAspectRatio(float InMaxAspectRatio); // Offset: 0x104292f7c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.SizeBox.SetHeightOverride
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetHeightOverride(float InHeightOverride); // Offset: 0x1042932e0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.SizeBox.ClearWidthOverride
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearWidthOverride(); // Offset: 0x104293360 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.SizeBox.ClearMinDesiredWidth
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearMinDesiredWidth(); // Offset: 0x104293238 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.SizeBox.ClearMinDesiredHeight
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearMinDesiredHeight(); // Offset: 0x1042931a4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.SizeBox.ClearMinAspectRatio
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearMinAspectRatio(); // Offset: 0x104292f68 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.SizeBox.ClearMaxDesiredWidth
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearMaxDesiredWidth(); // Offset: 0x104293110 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.SizeBox.ClearMaxDesiredHeight
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearMaxDesiredHeight(); // Offset: 0x10429307c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.SizeBox.ClearMaxAspectRatio
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearMaxAspectRatio(); // Offset: 0x104292f54 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.SizeBox.ClearHeightOverride
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearHeightOverride(); // Offset: 0x1042932cc // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class UMG.NamedSlot
// Size: 0x160 // Inherited bytes: 0x150
struct UNamedSlot : UContentWidget {
	// Fields
	char pad_0x150[0x10]; // Offset: 0x150 // Size: 0x10
};

// Object Name: Class UMG.CanvasPanel
// Size: 0x160 // Inherited bytes: 0x150
struct UCanvasPanel : UPanelWidget {
	// Fields
	int32_t ReservedLayerSpace; // Offset: 0x14c // Size: 0x04
	char pad_0x154[0xc]; // Offset: 0x154 // Size: 0x0c

	// Functions

	// Object Name: Function UMG.CanvasPanel.AddChildToCanvas
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UCanvasPanelSlot* AddChildToCanvas(struct UWidget* Content); // Offset: 0x104273de8 // Return & Params: Num(2) Size(0x10)
};

// Object Name: Class UMG.RichTextBlockDecorator
// Size: 0x28 // Inherited bytes: 0x28
struct URichTextBlockDecorator : UObject {
};

// Object Name: Class UMG.CheckBox
// Size: 0x828 // Inherited bytes: 0x150
struct UCheckBox : UContentWidget {
	// Fields
	enum class ECheckBoxState CheckedState; // Offset: 0x149 // Size: 0x01
	struct FDelegate CheckedStateDelegate; // Offset: 0x14c // Size: 0x10
	struct FCheckBoxStyle WidgetStyle; // Offset: 0x160 // Size: 0x610
	struct USlateWidgetStyleAsset* Style; // Offset: 0x770 // Size: 0x08
	struct USlateBrushAsset* UncheckedImage; // Offset: 0x778 // Size: 0x08
	struct USlateBrushAsset* UncheckedHoveredImage; // Offset: 0x780 // Size: 0x08
	struct USlateBrushAsset* UncheckedPressedImage; // Offset: 0x788 // Size: 0x08
	struct USlateBrushAsset* CheckedImage; // Offset: 0x790 // Size: 0x08
	struct USlateBrushAsset* CheckedHoveredImage; // Offset: 0x798 // Size: 0x08
	struct USlateBrushAsset* CheckedPressedImage; // Offset: 0x7a0 // Size: 0x08
	struct USlateBrushAsset* UndeterminedImage; // Offset: 0x7a8 // Size: 0x08
	struct USlateBrushAsset* UndeterminedHoveredImage; // Offset: 0x7b0 // Size: 0x08
	struct USlateBrushAsset* UndeterminedPressedImage; // Offset: 0x7b8 // Size: 0x08
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0x7c0 // Size: 0x01
	char pad_0x7C2[0x2]; // Offset: 0x7c2 // Size: 0x02
	struct FMargin Padding; // Offset: 0x7c4 // Size: 0x10
	char pad_0x7D4[0x4]; // Offset: 0x7d4 // Size: 0x04
	struct FSlateColor BorderBackgroundColor; // Offset: 0x7d8 // Size: 0x28
	enum class EButtonClickMethod ClickMethod; // Offset: 0x800 // Size: 0x01
	enum class EButtonTouchMethod TouchMethod; // Offset: 0x801 // Size: 0x01
	enum class EButtonPressMethod PressMethod; // Offset: 0x802 // Size: 0x01
	bool IsFocusable; // Offset: 0x803 // Size: 0x01
	char pad_0x804[0x4]; // Offset: 0x804 // Size: 0x04
	struct FMulticastInlineDelegate OnCheckStateChanged; // Offset: 0x808 // Size: 0x10
	char pad_0x818[0x10]; // Offset: 0x818 // Size: 0x10

	// Functions

	// Object Name: Function UMG.CheckBox.SetTouchMethod
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetTouchMethod(enum class EButtonTouchMethod InTouchMethod); // Offset: 0x1042752c0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.CheckBox.SetPressMethod
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPressMethod(enum class EButtonPressMethod InPressMethod); // Offset: 0x104275240 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.CheckBox.SetIsChecked
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetIsChecked(bool InIsChecked); // Offset: 0x104275440 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.CheckBox.SetClickMethod
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetClickMethod(enum class EButtonClickMethod InClickMethod); // Offset: 0x104275340 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.CheckBox.SetCheckedState
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetCheckedState(enum class ECheckBoxState InCheckedState); // Offset: 0x1042753c0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.CheckBox.IsPressed
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsPressed(); // Offset: 0x104275530 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.CheckBox.IsChecked
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsChecked(); // Offset: 0x1042754fc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.CheckBox.GetCheckedState
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	enum class ECheckBoxState GetCheckedState(); // Offset: 0x1042754c8 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.DragDropOperation
// Size: 0x88 // Inherited bytes: 0x28
struct UDragDropOperation : UObject {
	// Fields
	struct FString Tag; // Offset: 0x28 // Size: 0x10
	struct UObject* Payload; // Offset: 0x38 // Size: 0x08
	struct UWidget* DefaultDragVisual; // Offset: 0x40 // Size: 0x08
	enum class EDragPivot Pivot; // Offset: 0x48 // Size: 0x01
	char pad_0x49[0x3]; // Offset: 0x49 // Size: 0x03
	struct FVector2D Offset; // Offset: 0x4c // Size: 0x08
	char pad_0x54[0x4]; // Offset: 0x54 // Size: 0x04
	struct FMulticastInlineDelegate OnDrop; // Offset: 0x58 // Size: 0x10
	struct FMulticastInlineDelegate OnDragCancelled; // Offset: 0x68 // Size: 0x10
	struct FMulticastInlineDelegate OnDragged; // Offset: 0x78 // Size: 0x10

	// Functions

	// Object Name: Function UMG.DragDropOperation.Drop
	// Flags: [Native|Event|Public|HasOutParms|BlueprintEvent]
	void Drop(struct FPointerEvent& PointerEvent); // Offset: 0x10427934c // Return & Params: Num(1) Size(0x70)

	// Object Name: Function UMG.DragDropOperation.Dragged
	// Flags: [Native|Event|Public|HasOutParms|BlueprintEvent]
	void Dragged(struct FPointerEvent& PointerEvent); // Offset: 0x1042790bc // Return & Params: Num(1) Size(0x70)

	// Object Name: Function UMG.DragDropOperation.DragCancelled
	// Flags: [Native|Event|Public|HasOutParms|BlueprintEvent]
	void DragCancelled(struct FPointerEvent& PointerEvent); // Offset: 0x104279204 // Return & Params: Num(1) Size(0x70)
};

// Object Name: Class UMG.WidgetComponent
// Size: 0x6c0 // Inherited bytes: 0x5b0
struct UWidgetComponent : UMeshComponent {
	// Fields
	enum class EWidgetSpace Space; // Offset: 0x5a1 // Size: 0x01
	enum class EWidgetTimingPolicy TimingPolicy; // Offset: 0x5a2 // Size: 0x01
	struct UUserWidget* WidgetClass; // Offset: 0x5a8 // Size: 0x08
	struct FIntPoint DrawSize; // Offset: 0x5b0 // Size: 0x08
	bool bManuallyRedraw; // Offset: 0x5b8 // Size: 0x01
	bool bRedrawRequested; // Offset: 0x5b9 // Size: 0x01
	float RedrawTime; // Offset: 0x5bc // Size: 0x04
	struct FIntPoint CurrentDrawSize; // Offset: 0x5c8 // Size: 0x08
	bool bDrawAtDesiredSize; // Offset: 0x5d0 // Size: 0x01
	char pad_0x5D1[0x3]; // Offset: 0x5d1 // Size: 0x03
	struct FVector2D Pivot; // Offset: 0x5d4 // Size: 0x08
	bool bReceiveHardwareInput; // Offset: 0x5dc // Size: 0x01
	bool bWindowFocusable; // Offset: 0x5dd // Size: 0x01
	enum class EWindowVisibility WindowVisibility; // Offset: 0x5de // Size: 0x01
	bool bApplyGammaCorrection; // Offset: 0x5df // Size: 0x01
	struct ULocalPlayer* OwnerPlayer; // Offset: 0x5e0 // Size: 0x08
	struct FLinearColor BackgroundColor; // Offset: 0x5e8 // Size: 0x10
	struct FLinearColor TintColorAndOpacity; // Offset: 0x5f8 // Size: 0x10
	float OpacityFromTexture; // Offset: 0x608 // Size: 0x04
	enum class EWidgetBlendMode BlendMode; // Offset: 0x60c // Size: 0x01
	bool bIsTwoSided; // Offset: 0x60d // Size: 0x01
	bool TickWhenOffscreen; // Offset: 0x60e // Size: 0x01
	char pad_0x60F[0x1]; // Offset: 0x60f // Size: 0x01
	struct UUserWidget* Widget; // Offset: 0x610 // Size: 0x08
	char pad_0x618[0x20]; // Offset: 0x618 // Size: 0x20
	struct UBodySetup* BodySetup; // Offset: 0x638 // Size: 0x08
	struct UMaterialInterface* TranslucentMaterial; // Offset: 0x640 // Size: 0x08
	struct UMaterialInterface* TranslucentMaterial_OneSided; // Offset: 0x648 // Size: 0x08
	struct UMaterialInterface* OpaqueMaterial; // Offset: 0x650 // Size: 0x08
	struct UMaterialInterface* OpaqueMaterial_OneSided; // Offset: 0x658 // Size: 0x08
	struct UMaterialInterface* MaskedMaterial; // Offset: 0x660 // Size: 0x08
	struct UMaterialInterface* MaskedMaterial_OneSided; // Offset: 0x668 // Size: 0x08
	struct UTextureRenderTarget2D* RenderTarget; // Offset: 0x670 // Size: 0x08
	struct UMaterialInstanceDynamic* MaterialInstance; // Offset: 0x678 // Size: 0x08
	bool bAddedToScreen; // Offset: 0x680 // Size: 0x01
	bool bEditTimeUsable; // Offset: 0x681 // Size: 0x01
	char pad_0x682[0x2]; // Offset: 0x682 // Size: 0x02
	struct FName SharedLayerName; // Offset: 0x684 // Size: 0x08
	int32_t LayerZOrder; // Offset: 0x68c // Size: 0x04
	enum class EWidgetGeometryMode GeometryMode; // Offset: 0x690 // Size: 0x01
	char pad_0x691[0x3]; // Offset: 0x691 // Size: 0x03
	float CylinderArcAngle; // Offset: 0x694 // Size: 0x04
	char pad_0x698[0x28]; // Offset: 0x698 // Size: 0x28

	// Functions

	// Object Name: Function UMG.WidgetComponent.SetWindowVisibility
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetWindowVisibility(enum class EWindowVisibility InVisibility); // Offset: 0x1042b7210 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.WidgetComponent.SetWindowFocusable
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetWindowFocusable(bool bInWindowFocusable); // Offset: 0x1042b72ac // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.WidgetComponent.SetWidgetSpace
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetWidgetSpace(enum class EWidgetSpace NewSpace); // Offset: 0x1042b7480 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.WidgetComponent.SetWidget
	// Flags: [Native|Public|BlueprintCallable]
	void SetWidget(struct UUserWidget* Widget); // Offset: 0x1042b7ba0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.WidgetComponent.SetTwoSided
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetTwoSided(bool bWantTwoSided); // Offset: 0x1042b789c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.WidgetComponent.SetTintColorAndOpacity
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetTintColorAndOpacity(struct FLinearColor NewTintColorAndOpacity); // Offset: 0x1042b76fc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.WidgetComponent.SetTickWhenOffscreen
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetTickWhenOffscreen(bool bWantTickWhenOffscreen); // Offset: 0x1042b77fc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.WidgetComponent.SetRedrawTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetRedrawTime(float InRedrawTime); // Offset: 0x1042b7518 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.WidgetComponent.SetPivot
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void SetPivot(struct FVector2D& InPivot); // Offset: 0x1042b7650 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.WidgetComponent.SetOwnerPlayer
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetOwnerPlayer(struct ULocalPlayer* LocalPlayer); // Offset: 0x1042b7b20 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.WidgetComponent.SetManuallyRedraw
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetManuallyRedraw(bool bUseManualRedraw); // Offset: 0x1042b7a7c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.WidgetComponent.SetGeometryMode
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetGeometryMode(enum class EWidgetGeometryMode InGeometryMode); // Offset: 0x1042b73e8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.WidgetComponent.SetDrawSize
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetDrawSize(struct FVector2D Size); // Offset: 0x1042b795c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.WidgetComponent.SetDrawAtDesiredSize
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetDrawAtDesiredSize(bool bInDrawAtDesiredSize); // Offset: 0x1042b75b0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.WidgetComponent.SetCylinderArcAngle
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetCylinderArcAngle(float InCylinderArcAngle); // Offset: 0x1042b7350 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.WidgetComponent.SetBackgroundColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetBackgroundColor(struct FLinearColor NewBackgroundColor); // Offset: 0x1042b777c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.WidgetComponent.RequestRedraw
	// Flags: [Native|Public|BlueprintCallable]
	void RequestRedraw(); // Offset: 0x1042b7940 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.WidgetComponent.GetWindowVisiblility
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	enum class EWindowVisibility GetWindowVisiblility(); // Offset: 0x1042b7290 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.WidgetComponent.GetWindowFocusable
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool GetWindowFocusable(); // Offset: 0x1042b7334 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.WidgetComponent.GetWidgetSpace
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	enum class EWidgetSpace GetWidgetSpace(); // Offset: 0x1042b74fc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.WidgetComponent.GetUserWidgetObject
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UUserWidget* GetUserWidgetObject(); // Offset: 0x1042b7c90 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.WidgetComponent.GetTwoSided
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool GetTwoSided(); // Offset: 0x1042b7924 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.WidgetComponent.GetTickWhenOffscreen
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool GetTickWhenOffscreen(); // Offset: 0x1042b7880 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.WidgetComponent.GetRenderTarget
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UTextureRenderTarget2D* GetRenderTarget(); // Offset: 0x1042b7c5c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.WidgetComponent.GetRedrawTime
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetRedrawTime(); // Offset: 0x1042b7594 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.WidgetComponent.GetPivot
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FVector2D GetPivot(); // Offset: 0x1042b76dc // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.WidgetComponent.GetOwnerPlayer
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct ULocalPlayer* GetOwnerPlayer(); // Offset: 0x1042b7a48 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.WidgetComponent.GetMaterialInstance
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UMaterialInstanceDynamic* GetMaterialInstance(); // Offset: 0x1042b7c28 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.WidgetComponent.GetManuallyRedraw
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool GetManuallyRedraw(); // Offset: 0x1042b7b04 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.WidgetComponent.GetGeometryMode
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	enum class EWidgetGeometryMode GetGeometryMode(); // Offset: 0x1042b7464 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.WidgetComponent.GetDrawSize
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FVector2D GetDrawSize(); // Offset: 0x1042b7a10 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.WidgetComponent.GetDrawAtDesiredSize
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool GetDrawAtDesiredSize(); // Offset: 0x1042b7634 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.WidgetComponent.GetCylinderArcAngle
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetCylinderArcAngle(); // Offset: 0x1042b73cc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.WidgetComponent.GetCurrentDrawSize
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FVector2D GetCurrentDrawSize(); // Offset: 0x1042b79d8 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class UMG.AsyncTaskDownloadImage
// Size: 0x50 // Inherited bytes: 0x30
struct UAsyncTaskDownloadImage : UBlueprintAsyncActionBase {
	// Fields
	struct FMulticastInlineDelegate OnSuccess; // Offset: 0x30 // Size: 0x10
	struct FMulticastInlineDelegate OnFail; // Offset: 0x40 // Size: 0x10

	// Functions

	// Object Name: Function UMG.AsyncTaskDownloadImage.DownloadImage
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UAsyncTaskDownloadImage* DownloadImage(struct FString URL); // Offset: 0x1042702cc // Return & Params: Num(2) Size(0x18)
};

// Object Name: Class UMG.BackgroundBlur
// Size: 0x220 // Inherited bytes: 0x150
struct UBackgroundBlur : UContentWidget {
	// Fields
	struct FMargin Padding; // Offset: 0x14c // Size: 0x10
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0x15c // Size: 0x01
	enum class EVerticalAlignment VerticalAlignment; // Offset: 0x15d // Size: 0x01
	bool bBlurOnce; // Offset: 0x15e // Size: 0x01
	bool bBlurState; // Offset: 0x15f // Size: 0x01
	bool bApplyAlphaToBlur; // Offset: 0x160 // Size: 0x01
	float BlurStrength; // Offset: 0x164 // Size: 0x04
	bool bOverrideAutoRadiusCalculation; // Offset: 0x168 // Size: 0x01
	char pad_0x16A[0x2]; // Offset: 0x16a // Size: 0x02
	int32_t BlurRadius; // Offset: 0x16c // Size: 0x04
	struct FSlateBrush LowQualityFallbackBrush; // Offset: 0x170 // Size: 0x98
	char pad_0x208[0x18]; // Offset: 0x208 // Size: 0x18

	// Functions

	// Object Name: Function UMG.BackgroundBlur.StopOnFirstBlur
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StopOnFirstBlur(); // Offset: 0x104270754 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.BackgroundBlur.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment); // Offset: 0x104270b94 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.BackgroundBlur.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPadding(struct FMargin InPadding); // Offset: 0x104270c94 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.BackgroundBlur.SetLowQualityFallbackBrush
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetLowQualityFallbackBrush(struct FSlateBrush& InBrush); // Offset: 0x104270850 // Return & Params: Num(1) Size(0x98)

	// Object Name: Function UMG.BackgroundBlur.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment); // Offset: 0x104270c14 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.BackgroundBlur.SetBlurStrength
	// Flags: [Native|Public|BlueprintCallable]
	void SetBlurStrength(float InStrength); // Offset: 0x104270a04 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.BackgroundBlur.SetBlurState
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetBlurState(bool BlurState, bool RefreshCount); // Offset: 0x104270768 // Return & Params: Num(2) Size(0x2)

	// Object Name: Function UMG.BackgroundBlur.SetBlurRadius
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetBlurRadius(int32_t InBlurRadius); // Offset: 0x104270a8c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.BackgroundBlur.SetApplyAlphaToBlur
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetApplyAlphaToBlur(bool bInApplyAlphaToBlur); // Offset: 0x104270b0c // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.BackgroundBlurSlot
// Size: 0x60 // Inherited bytes: 0x38
struct UBackgroundBlurSlot : UPanelSlot {
	// Fields
	struct FMargin Padding; // Offset: 0x38 // Size: 0x10
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0x48 // Size: 0x01
	enum class EVerticalAlignment VerticalAlignment; // Offset: 0x49 // Size: 0x01
	char pad_0x4A[0x16]; // Offset: 0x4a // Size: 0x16

	// Functions

	// Object Name: Function UMG.BackgroundBlurSlot.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment); // Offset: 0x1042711f8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.BackgroundBlurSlot.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPadding(struct FMargin InPadding); // Offset: 0x1042712f8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.BackgroundBlurSlot.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment); // Offset: 0x104271278 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.PropertyBinding
// Size: 0x60 // Inherited bytes: 0x28
struct UPropertyBinding : UObject {
	// Fields
	struct TWeakObjectPtr<struct UObject> SourceObject; // Offset: 0x28 // Size: 0x08
	struct FDynamicPropertyPath SourcePath; // Offset: 0x30 // Size: 0x28
	struct FName DestinationProperty; // Offset: 0x58 // Size: 0x08
};

// Object Name: Class UMG.BoolBinding
// Size: 0x60 // Inherited bytes: 0x60
struct UBoolBinding : UPropertyBinding {
	// Functions

	// Object Name: Function UMG.BoolBinding.GetValue
	// Flags: [Final|Native|Public|Const]
	bool GetValue(); // Offset: 0x1042716f0 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.BorderSlot
// Size: 0x60 // Inherited bytes: 0x38
struct UBorderSlot : UPanelSlot {
	// Fields
	struct FMargin Padding; // Offset: 0x38 // Size: 0x10
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0x48 // Size: 0x01
	enum class EVerticalAlignment VerticalAlignment; // Offset: 0x49 // Size: 0x01
	char pad_0x4A[0x16]; // Offset: 0x4a // Size: 0x16

	// Functions

	// Object Name: Function UMG.BorderSlot.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment); // Offset: 0x1042725a8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.BorderSlot.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPadding(struct FMargin InPadding); // Offset: 0x1042726a8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.BorderSlot.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment); // Offset: 0x104272628 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.BrushBinding
// Size: 0x68 // Inherited bytes: 0x60
struct UBrushBinding : UPropertyBinding {
	// Fields
	char pad_0x60[0x8]; // Offset: 0x60 // Size: 0x08

	// Functions

	// Object Name: Function UMG.BrushBinding.GetValue
	// Flags: [Final|Native|Public|Const]
	struct FSlateBrush GetValue(); // Offset: 0x104272b5c // Return & Params: Num(1) Size(0x98)
};

// Object Name: Class UMG.ButtonSlot
// Size: 0x60 // Inherited bytes: 0x38
struct UButtonSlot : UPanelSlot {
	// Fields
	struct FMargin Padding; // Offset: 0x38 // Size: 0x10
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0x48 // Size: 0x01
	enum class EVerticalAlignment VerticalAlignment; // Offset: 0x49 // Size: 0x01
	char pad_0x4A[0x16]; // Offset: 0x4a // Size: 0x16

	// Functions

	// Object Name: Function UMG.ButtonSlot.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment); // Offset: 0x1042738f0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.ButtonSlot.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPadding(struct FMargin InPadding); // Offset: 0x1042739f0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.ButtonSlot.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment); // Offset: 0x104273970 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.CanvasPanelSlot
// Size: 0x78 // Inherited bytes: 0x38
struct UCanvasPanelSlot : UPanelSlot {
	// Fields
	struct FAnchorData LayoutData; // Offset: 0x38 // Size: 0x2c
	bool bAutoSize; // Offset: 0x64 // Size: 0x01
	char pad_0x65[0x3]; // Offset: 0x65 // Size: 0x03
	int32_t ZOrder; // Offset: 0x68 // Size: 0x04
	char pad_0x6C[0xc]; // Offset: 0x6c // Size: 0x0c

	// Functions

	// Object Name: Function UMG.CanvasPanelSlot.SetZOrder
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetZOrder(int32_t InZOrder); // Offset: 0x104274420 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.CanvasPanelSlot.SetSize
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetSize(struct FVector2D InSize); // Offset: 0x1042747d0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.CanvasPanelSlot.SetPosition
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetPosition(struct FVector2D InPosition); // Offset: 0x104274884 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.CanvasPanelSlot.SetOffsets
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetOffsets(struct FMargin InOffset); // Offset: 0x104274714 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.CanvasPanelSlot.SetMinimum
	// Flags: [Final|Native|Public|HasDefaults]
	void SetMinimum(struct FVector2D InMinimumAnchors); // Offset: 0x104274370 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.CanvasPanelSlot.SetMaximum
	// Flags: [Final|Native|Public|HasDefaults]
	void SetMaximum(struct FVector2D InMaximumAnchors); // Offset: 0x1042742f4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.CanvasPanelSlot.SetLayout
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetLayout(struct FAnchorData& InLayoutData); // Offset: 0x10427494c // Return & Params: Num(1) Size(0x2c)

	// Object Name: Function UMG.CanvasPanelSlot.SetAutoSize
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAutoSize(bool InbAutoSize); // Offset: 0x1042744d4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.CanvasPanelSlot.SetAnchors
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAnchors(struct FAnchors InAnchors); // Offset: 0x104274650 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.CanvasPanelSlot.SetAlignment
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetAlignment(struct FVector2D InAlignment); // Offset: 0x104274594 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.CanvasPanelSlot.GetZOrder
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetZOrder(); // Offset: 0x1042743ec // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.CanvasPanelSlot.GetSize
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FVector2D GetSize(); // Offset: 0x104274798 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.CanvasPanelSlot.GetPosition
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FVector2D GetPosition(); // Offset: 0x10427484c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.CanvasPanelSlot.GetOffsets
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FMargin GetOffsets(); // Offset: 0x1042746d4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.CanvasPanelSlot.GetLayout
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FAnchorData GetLayout(); // Offset: 0x104274900 // Return & Params: Num(1) Size(0x2c)

	// Object Name: Function UMG.CanvasPanelSlot.GetAutoSize
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool GetAutoSize(); // Offset: 0x1042744a0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.CanvasPanelSlot.GetAnchors
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FAnchors GetAnchors(); // Offset: 0x104274610 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.CanvasPanelSlot.GetAlignment
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FVector2D GetAlignment(); // Offset: 0x10427455c // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class UMG.CheckedStateBinding
// Size: 0x68 // Inherited bytes: 0x60
struct UCheckedStateBinding : UPropertyBinding {
	// Fields
	char pad_0x60[0x8]; // Offset: 0x60 // Size: 0x08

	// Functions

	// Object Name: Function UMG.CheckedStateBinding.GetValue
	// Flags: [Final|Native|Public|Const]
	enum class ECheckBoxState GetValue(); // Offset: 0x104275a84 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.CircularThrobber
// Size: 0x200 // Inherited bytes: 0x138
struct UCircularThrobber : UWidget {
	// Fields
	int32_t NumberOfPieces; // Offset: 0x138 // Size: 0x04
	float Period; // Offset: 0x13c // Size: 0x04
	float Radius; // Offset: 0x140 // Size: 0x04
	char pad_0x144[0x4]; // Offset: 0x144 // Size: 0x04
	struct USlateBrushAsset* PieceImage; // Offset: 0x148 // Size: 0x08
	struct FSlateBrush Image; // Offset: 0x150 // Size: 0x98
	bool bEnableRadius; // Offset: 0x1e8 // Size: 0x01
	char pad_0x1E9[0x17]; // Offset: 0x1e9 // Size: 0x17

	// Functions

	// Object Name: Function UMG.CircularThrobber.SetRadius
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetRadius(float InRadius); // Offset: 0x104275cd4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.CircularThrobber.SetPeriod
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPeriod(float InPeriod); // Offset: 0x104275d54 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.CircularThrobber.SetNumberOfPieces
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetNumberOfPieces(int32_t InNumberOfPieces); // Offset: 0x104275dd4 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class UMG.ColorBinding
// Size: 0x68 // Inherited bytes: 0x60
struct UColorBinding : UPropertyBinding {
	// Fields
	char pad_0x60[0x8]; // Offset: 0x60 // Size: 0x08

	// Functions

	// Object Name: Function UMG.ColorBinding.GetSlateValue
	// Flags: [Final|Native|Public|Const]
	struct FSlateColor GetSlateValue(); // Offset: 0x104277a04 // Return & Params: Num(1) Size(0x28)

	// Object Name: Function UMG.ColorBinding.GetLinearValue
	// Flags: [Final|Native|Public|HasDefaults|Const]
	struct FLinearColor GetLinearValue(); // Offset: 0x1042779c4 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class UMG.ComboBox
// Size: 0x170 // Inherited bytes: 0x138
struct UComboBox : UWidget {
	// Fields
	struct TArray<struct UObject*> Items; // Offset: 0x138 // Size: 0x10
	struct FDelegate OnGenerateWidgetEvent; // Offset: 0x148 // Size: 0x10
	bool bIsFocusable; // Offset: 0x158 // Size: 0x01
	char pad_0x159[0x17]; // Offset: 0x159 // Size: 0x17
};

// Object Name: Class UMG.ComboBoxString
// Size: 0xf78 // Inherited bytes: 0x138
struct UComboBoxString : UWidget {
	// Fields
	struct TArray<struct FString> DefaultOptions; // Offset: 0x138 // Size: 0x10
	struct FString SelectedOption; // Offset: 0x148 // Size: 0x10
	struct FComboBoxStyle WidgetStyle; // Offset: 0x158 // Size: 0x450
	struct FTableRowStyle ItemStyle; // Offset: 0x5a8 // Size: 0x8a8
	struct FMargin ContentPadding; // Offset: 0xe50 // Size: 0x10
	float MaxListHeight; // Offset: 0xe60 // Size: 0x04
	bool HasDownArrow; // Offset: 0xe64 // Size: 0x01
	bool EnableGamepadNavigationMode; // Offset: 0xe65 // Size: 0x01
	char pad_0xE66[0x2]; // Offset: 0xe66 // Size: 0x02
	struct FSlateFontInfo Font; // Offset: 0xe68 // Size: 0x60
	struct FSlateColor ForegroundColor; // Offset: 0xec8 // Size: 0x28
	bool bIsFocusable; // Offset: 0xef0 // Size: 0x01
	char pad_0xEF1[0x3]; // Offset: 0xef1 // Size: 0x03
	struct FDelegate OnGenerateWidgetEvent; // Offset: 0xef4 // Size: 0x10
	char pad_0xF04[0x4]; // Offset: 0xf04 // Size: 0x04
	struct FMulticastInlineDelegate OnSelectionChanged; // Offset: 0xf08 // Size: 0x10
	struct FMulticastInlineDelegate OnOpening; // Offset: 0xf18 // Size: 0x10
	char pad_0xF28[0x50]; // Offset: 0xf28 // Size: 0x50

	// Functions

	// Object Name: Function UMG.ComboBoxString.SetSelectedOption
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSelectedOption(struct FString Option); // Offset: 0x104278134 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.ComboBoxString.SetSelectedIndex
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSelectedIndex(int32_t Index); // Offset: 0x1042780b4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.ComboBoxString.RemoveOption
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool RemoveOption(struct FString Option); // Offset: 0x1042783d4 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function UMG.ComboBoxString.RefreshOptions
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RefreshOptions(); // Offset: 0x104278224 // Return & Params: Num(0) Size(0x0)

	// Object Name: DelegateFunction UMG.ComboBoxString.OnSelectionChangedEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnSelectionChangedEvent__DelegateSignature(struct FString SelectedItem, enum class ESelectInfo SelectionType); // Offset: 0x1032a8510 // Return & Params: Num(2) Size(0x11)

	// Object Name: DelegateFunction UMG.ComboBoxString.OnOpeningEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnOpeningEvent__DelegateSignature(); // Offset: 0x1032a8510 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.ComboBoxString.IsOpen
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsOpen(); // Offset: 0x104277f98 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.ComboBoxString.GetSelectedOption
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FString GetSelectedOption(); // Offset: 0x104278034 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.ComboBoxString.GetSelectedIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetSelectedIndex(); // Offset: 0x104278000 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.ComboBoxString.GetOptionCount
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetOptionCount(); // Offset: 0x104277fcc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.ComboBoxString.GetOptionAtIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FString GetOptionAtIndex(int32_t Index); // Offset: 0x104278260 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function UMG.ComboBoxString.FindOptionIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t FindOptionIndex(struct FString Option); // Offset: 0x104278338 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function UMG.ComboBoxString.ClearSelection
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearSelection(); // Offset: 0x104278238 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.ComboBoxString.ClearOptions
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearOptions(); // Offset: 0x10427824c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.ComboBoxString.AddOption
	// Flags: [Final|Native|Public|BlueprintCallable]
	void AddOption(struct FString Option); // Offset: 0x104278470 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class UMG.DynamicEntryBox
// Size: 0x200 // Inherited bytes: 0x1f8
struct UDynamicEntryBox : UDynamicEntryBoxBase {
	// Fields
	struct UUserWidget* EntryWidgetClass; // Offset: 0x1f8 // Size: 0x08

	// Functions

	// Object Name: Function UMG.DynamicEntryBox.Reset
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Reset(bool bDeleteWidgets); // Offset: 0x104279b80 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.DynamicEntryBox.RemoveEntry
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RemoveEntry(struct UUserWidget* EntryWidget); // Offset: 0x104279b00 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.DynamicEntryBox.BP_CreateEntryOfClass
	// Flags: [Final|Native|Private|BlueprintCallable]
	struct UUserWidget* BP_CreateEntryOfClass(struct UUserWidget* EntryClass); // Offset: 0x104279a3c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UMG.DynamicEntryBox.BP_CreateEntry
	// Flags: [Final|Native|Private|BlueprintCallable]
	struct UUserWidget* BP_CreateEntry(); // Offset: 0x104279acc // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class UMG.EditableText
// Size: 0x4d0 // Inherited bytes: 0x138
struct UEditableText : UWidget {
	// Fields
	struct FText Text; // Offset: 0x138 // Size: 0x18
	struct FDelegate TextDelegate; // Offset: 0x150 // Size: 0x10
	struct FText HintText; // Offset: 0x160 // Size: 0x18
	struct FDelegate HintTextDelegate; // Offset: 0x178 // Size: 0x10
	struct FEditableTextStyle WidgetStyle; // Offset: 0x188 // Size: 0x258
	struct USlateWidgetStyleAsset* Style; // Offset: 0x3e0 // Size: 0x08
	struct USlateBrushAsset* BackgroundImageSelected; // Offset: 0x3e8 // Size: 0x08
	struct USlateBrushAsset* BackgroundImageComposing; // Offset: 0x3f0 // Size: 0x08
	struct USlateBrushAsset* CaretImage; // Offset: 0x3f8 // Size: 0x08
	struct FSlateFontInfo Font; // Offset: 0x400 // Size: 0x60
	struct FSlateColor ColorAndOpacity; // Offset: 0x460 // Size: 0x28
	bool IsReadOnly; // Offset: 0x488 // Size: 0x01
	bool IsPassword; // Offset: 0x489 // Size: 0x01
	char pad_0x48A[0x2]; // Offset: 0x48a // Size: 0x02
	float MinimumDesiredWidth; // Offset: 0x48c // Size: 0x04
	bool IsCaretMovedWhenGainFocus; // Offset: 0x490 // Size: 0x01
	bool SelectAllTextWhenFocused; // Offset: 0x491 // Size: 0x01
	bool RevertTextOnEscape; // Offset: 0x492 // Size: 0x01
	bool ClearKeyboardFocusOnCommit; // Offset: 0x493 // Size: 0x01
	bool SelectAllTextOnCommit; // Offset: 0x494 // Size: 0x01
	bool AllowContextMenu; // Offset: 0x495 // Size: 0x01
	enum class EVirtualKeyboardType KeyboardType; // Offset: 0x496 // Size: 0x01
	struct FVirtualKeyboardOptions VirtualKeyboardOptions; // Offset: 0x497 // Size: 0x01
	enum class EVirtualKeyboardTrigger VirtualKeyboardTrigger; // Offset: 0x498 // Size: 0x01
	enum class EVirtualKeyboardDismissAction VirtualKeyboardDismissAction; // Offset: 0x499 // Size: 0x01
	enum class ETextJustify Justification; // Offset: 0x49a // Size: 0x01
	struct FShapedTextOptions ShapedTextOptions; // Offset: 0x49b // Size: 0x03
	char pad_0x49E[0x2]; // Offset: 0x49e // Size: 0x02
	struct FMulticastInlineDelegate OnTextChanged; // Offset: 0x4a0 // Size: 0x10
	struct FMulticastInlineDelegate OnTextCommitted; // Offset: 0x4b0 // Size: 0x10
	char pad_0x4C0[0x10]; // Offset: 0x4c0 // Size: 0x10

	// Functions

	// Object Name: Function UMG.EditableText.SetText
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetText(struct FText InText); // Offset: 0x10427a880 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function UMG.EditableText.SetJustification
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetJustification(enum class ETextJustify InJustification); // Offset: 0x10427a594 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.EditableText.SetIsReadOnly
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetIsReadOnly(bool InbIsReadyOnly); // Offset: 0x10427a614 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.EditableText.SetIsPassword
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetIsPassword(bool InbIsPassword); // Offset: 0x10427a7f8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.EditableText.SetHintText
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetHintText(struct FText InHintText); // Offset: 0x10427a69c // Return & Params: Num(1) Size(0x18)

	// Object Name: DelegateFunction UMG.EditableText.OnEditableTextCommittedEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void OnEditableTextCommittedEvent__DelegateSignature(struct FText& Text, enum class ETextCommit CommitMethod); // Offset: 0x1032a8510 // Return & Params: Num(2) Size(0x19)

	// Object Name: DelegateFunction UMG.EditableText.OnEditableTextChangedEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void OnEditableTextChangedEvent__DelegateSignature(struct FText& Text); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function UMG.EditableText.GetText
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FText GetText(); // Offset: 0x10427a9dc // Return & Params: Num(1) Size(0x18)
};

// Object Name: Class UMG.EditableTextBox
// Size: 0xb48 // Inherited bytes: 0x138
struct UEditableTextBox : UWidget {
	// Fields
	struct FText Text; // Offset: 0x138 // Size: 0x18
	struct FDelegate TextDelegate; // Offset: 0x150 // Size: 0x10
	struct FEditableTextBoxStyle WidgetStyle; // Offset: 0x160 // Size: 0x8d0
	struct USlateWidgetStyleAsset* Style; // Offset: 0xa30 // Size: 0x08
	struct FText HintText; // Offset: 0xa38 // Size: 0x18
	struct FDelegate HintTextDelegate; // Offset: 0xa50 // Size: 0x10
	struct FSlateFontInfo Font; // Offset: 0xa60 // Size: 0x60
	struct FLinearColor ForegroundColor; // Offset: 0xac0 // Size: 0x10
	struct FLinearColor BackgroundColor; // Offset: 0xad0 // Size: 0x10
	struct FLinearColor ReadOnlyForegroundColor; // Offset: 0xae0 // Size: 0x10
	bool IsReadOnly; // Offset: 0xaf0 // Size: 0x01
	bool IsPassword; // Offset: 0xaf1 // Size: 0x01
	char pad_0xAF2[0x2]; // Offset: 0xaf2 // Size: 0x02
	float MinimumDesiredWidth; // Offset: 0xaf4 // Size: 0x04
	struct FMargin Padding; // Offset: 0xaf8 // Size: 0x10
	bool IsCaretMovedWhenGainFocus; // Offset: 0xb08 // Size: 0x01
	bool SelectAllTextWhenFocused; // Offset: 0xb09 // Size: 0x01
	bool RevertTextOnEscape; // Offset: 0xb0a // Size: 0x01
	bool ClearKeyboardFocusOnCommit; // Offset: 0xb0b // Size: 0x01
	bool SelectAllTextOnCommit; // Offset: 0xb0c // Size: 0x01
	bool AllowContextMenu; // Offset: 0xb0d // Size: 0x01
	enum class EVirtualKeyboardType KeyboardType; // Offset: 0xb0e // Size: 0x01
	struct FVirtualKeyboardOptions VirtualKeyboardOptions; // Offset: 0xb0f // Size: 0x01
	enum class EVirtualKeyboardTrigger VirtualKeyboardTrigger; // Offset: 0xb10 // Size: 0x01
	enum class EVirtualKeyboardDismissAction VirtualKeyboardDismissAction; // Offset: 0xb11 // Size: 0x01
	enum class ETextJustify Justification; // Offset: 0xb12 // Size: 0x01
	struct FShapedTextOptions ShapedTextOptions; // Offset: 0xb13 // Size: 0x03
	char pad_0xB16[0x2]; // Offset: 0xb16 // Size: 0x02
	struct FMulticastInlineDelegate OnTextChanged; // Offset: 0xb18 // Size: 0x10
	struct FMulticastInlineDelegate OnTextCommitted; // Offset: 0xb28 // Size: 0x10
	char pad_0xB38[0x10]; // Offset: 0xb38 // Size: 0x10

	// Functions

	// Object Name: Function UMG.EditableTextBox.SetText
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetText(struct FText InText); // Offset: 0x10427b3c0 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function UMG.EditableTextBox.SetJustification
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetJustification(enum class ETextJustify InJustification); // Offset: 0x10427af30 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.EditableTextBox.SetIsReadOnly
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetIsReadOnly(bool bReadOnly); // Offset: 0x10427b080 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.EditableTextBox.SetIsPassword
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetIsPassword(bool bIsPassword); // Offset: 0x10427aff8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.EditableTextBox.SetHintText
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetHintText(struct FText InText); // Offset: 0x10427b264 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function UMG.EditableTextBox.SetError
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetError(struct FText InError); // Offset: 0x10427b108 // Return & Params: Num(1) Size(0x18)

	// Object Name: DelegateFunction UMG.EditableTextBox.OnEditableTextBoxCommittedEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void OnEditableTextBoxCommittedEvent__DelegateSignature(struct FText& Text, enum class ETextCommit CommitMethod); // Offset: 0x1032a8510 // Return & Params: Num(2) Size(0x19)

	// Object Name: DelegateFunction UMG.EditableTextBox.OnEditableTextBoxChangedEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void OnEditableTextBoxChangedEvent__DelegateSignature(struct FText& Text); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function UMG.EditableTextBox.HasError
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool HasError(); // Offset: 0x10427afb0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.EditableTextBox.GetText
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FText GetText(); // Offset: 0x10427b51c // Return & Params: Num(1) Size(0x18)

	// Object Name: Function UMG.EditableTextBox.ClearError
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearError(); // Offset: 0x10427afe4 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class UMG.ExpandableArea
// Size: 0x398 // Inherited bytes: 0x138
struct UExpandableArea : UWidget {
	// Fields
	char pad_0x138[0x8]; // Offset: 0x138 // Size: 0x08
	struct FExpandableAreaStyle Style; // Offset: 0x140 // Size: 0x140
	struct FSlateBrush BorderBrush; // Offset: 0x280 // Size: 0x98
	struct FSlateColor BorderColor; // Offset: 0x318 // Size: 0x28
	bool bIsExpanded; // Offset: 0x340 // Size: 0x01
	char pad_0x341[0x3]; // Offset: 0x341 // Size: 0x03
	float MaxHeight; // Offset: 0x344 // Size: 0x04
	struct FMargin HeaderPadding; // Offset: 0x348 // Size: 0x10
	struct FMargin AreaPadding; // Offset: 0x358 // Size: 0x10
	struct FMulticastInlineDelegate OnExpansionChanged; // Offset: 0x368 // Size: 0x10
	struct UWidget* HeaderContent; // Offset: 0x378 // Size: 0x08
	struct UWidget* BodyContent; // Offset: 0x380 // Size: 0x08
	char pad_0x388[0x10]; // Offset: 0x388 // Size: 0x10

	// Functions

	// Object Name: Function UMG.ExpandableArea.SetIsExpanded_Animated
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetIsExpanded_Animated(bool IsExpanded); // Offset: 0x10427bb90 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.ExpandableArea.SetIsExpanded
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetIsExpanded(bool IsExpanded); // Offset: 0x10427bc18 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.ExpandableArea.GetIsExpanded
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool GetIsExpanded(); // Offset: 0x10427bca0 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.FloatBinding
// Size: 0x60 // Inherited bytes: 0x60
struct UFloatBinding : UPropertyBinding {
	// Functions

	// Object Name: Function UMG.FloatBinding.GetValue
	// Flags: [Final|Native|Public|Const]
	float GetValue(); // Offset: 0x10427bfbc // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class UMG.GridPanel
// Size: 0x180 // Inherited bytes: 0x150
struct UGridPanel : UPanelWidget {
	// Fields
	struct TArray<float> ColumnFill; // Offset: 0x150 // Size: 0x10
	struct TArray<float> RowFill; // Offset: 0x160 // Size: 0x10
	char pad_0x170[0x10]; // Offset: 0x170 // Size: 0x10

	// Functions

	// Object Name: Function UMG.GridPanel.SetRowFill
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetRowFill(int32_t ColumnIndex, float Coefficient); // Offset: 0x10427c20c // Return & Params: Num(2) Size(0x8)

	// Object Name: Function UMG.GridPanel.SetColumnFill
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetColumnFill(int32_t ColumnIndex, float Coefficient); // Offset: 0x10427c2d8 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function UMG.GridPanel.AddChildToGrid
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UGridSlot* AddChildToGrid(struct UWidget* Content, int32_t InRow, int32_t InColumn); // Offset: 0x10427c3a4 // Return & Params: Num(4) Size(0x18)
};

// Object Name: Class UMG.GridSlot
// Size: 0x70 // Inherited bytes: 0x38
struct UGridSlot : UPanelSlot {
	// Fields
	struct FMargin Padding; // Offset: 0x38 // Size: 0x10
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0x48 // Size: 0x01
	enum class EVerticalAlignment VerticalAlignment; // Offset: 0x49 // Size: 0x01
	char pad_0x4A[0x2]; // Offset: 0x4a // Size: 0x02
	int32_t Row; // Offset: 0x4c // Size: 0x04
	int32_t RowSpan; // Offset: 0x50 // Size: 0x04
	int32_t Column; // Offset: 0x54 // Size: 0x04
	int32_t ColumnSpan; // Offset: 0x58 // Size: 0x04
	int32_t Layer; // Offset: 0x5c // Size: 0x04
	struct FVector2D Nudge; // Offset: 0x60 // Size: 0x08
	char pad_0x68[0x8]; // Offset: 0x68 // Size: 0x08

	// Functions

	// Object Name: Function UMG.GridSlot.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment); // Offset: 0x10427df9c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.GridSlot.SetRowSpan
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetRowSpan(int32_t InRowSpan); // Offset: 0x10427e298 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.GridSlot.SetRow
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetRow(int32_t InRow); // Offset: 0x10427e318 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.GridSlot.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPadding(struct FMargin InPadding); // Offset: 0x10427e398 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.GridSlot.SetNudge
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetNudge(struct FVector2D InNudge); // Offset: 0x10427e09c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.GridSlot.SetLayer
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetLayer(int32_t InLayer); // Offset: 0x10427e118 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.GridSlot.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment); // Offset: 0x10427e01c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.GridSlot.SetColumnSpan
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetColumnSpan(int32_t InColumnSpan); // Offset: 0x10427e198 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.GridSlot.SetColumn
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetColumn(int32_t InColumn); // Offset: 0x10427e218 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class UMG.HorizontalBox
// Size: 0x160 // Inherited bytes: 0x150
struct UHorizontalBox : UPanelWidget {
	// Fields
	char pad_0x150[0x10]; // Offset: 0x150 // Size: 0x10

	// Functions

	// Object Name: Function UMG.HorizontalBox.AddChildToHorizontalBox
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UHorizontalBoxSlot* AddChildToHorizontalBox(struct UWidget* Content); // Offset: 0x10427ea14 // Return & Params: Num(2) Size(0x10)
};

// Object Name: Class UMG.HorizontalBoxSlot
// Size: 0x60 // Inherited bytes: 0x38
struct UHorizontalBoxSlot : UPanelSlot {
	// Fields
	char pad_0x38[0x8]; // Offset: 0x38 // Size: 0x08
	struct FMargin Padding; // Offset: 0x40 // Size: 0x10
	struct FSlateChildSize Size; // Offset: 0x50 // Size: 0x08
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0x58 // Size: 0x01
	enum class EVerticalAlignment VerticalAlignment; // Offset: 0x59 // Size: 0x01
	char pad_0x5A[0x6]; // Offset: 0x5a // Size: 0x06

	// Functions

	// Object Name: Function UMG.HorizontalBoxSlot.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment); // Offset: 0x10427ee3c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.HorizontalBoxSlot.SetSize
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSize(struct FSlateChildSize InSize); // Offset: 0x10427ef3c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.HorizontalBoxSlot.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPadding(struct FMargin InPadding); // Offset: 0x10427efc8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.HorizontalBoxSlot.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment); // Offset: 0x10427eebc // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.InputKeySelector
// Size: 0x7b0 // Inherited bytes: 0x138
struct UInputKeySelector : UWidget {
	// Fields
	struct FButtonStyle WidgetStyle; // Offset: 0x138 // Size: 0x2b8
	struct FTextBlockStyle TextStyle; // Offset: 0x3f0 // Size: 0x2a8
	struct FInputChord SelectedKey; // Offset: 0x698 // Size: 0x20
	struct FSlateFontInfo Font; // Offset: 0x6b8 // Size: 0x60
	struct FMargin Margin; // Offset: 0x718 // Size: 0x10
	struct FLinearColor ColorAndOpacity; // Offset: 0x728 // Size: 0x10
	struct FText KeySelectionText; // Offset: 0x738 // Size: 0x18
	struct FText NoKeySpecifiedText; // Offset: 0x750 // Size: 0x18
	bool bAllowModifierKeys; // Offset: 0x768 // Size: 0x01
	bool bAllowGamepadKeys; // Offset: 0x769 // Size: 0x01
	char pad_0x76A[0x6]; // Offset: 0x76a // Size: 0x06
	struct TArray<struct FKey> EscapeKeys; // Offset: 0x770 // Size: 0x10
	struct FMulticastInlineDelegate OnKeySelected; // Offset: 0x780 // Size: 0x10
	struct FMulticastInlineDelegate OnIsSelectingKeyChanged; // Offset: 0x790 // Size: 0x10
	char pad_0x7A0[0x10]; // Offset: 0x7a0 // Size: 0x10

	// Functions

	// Object Name: Function UMG.InputKeySelector.SetTextBlockVisibility
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetTextBlockVisibility(enum class ESlateVisibility InVisibility); // Offset: 0x104280870 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.InputKeySelector.SetSelectedKey
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetSelectedKey(struct FInputChord& InSelectedKey); // Offset: 0x104280cec // Return & Params: Num(1) Size(0x20)

	// Object Name: Function UMG.InputKeySelector.SetNoKeySpecifiedText
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetNoKeySpecifiedText(struct FText InNoKeySpecifiedText); // Offset: 0x104280a34 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function UMG.InputKeySelector.SetKeySelectionText
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetKeySelectionText(struct FText InKeySelectionText); // Offset: 0x104280b90 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function UMG.InputKeySelector.SetEscapeKeys
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetEscapeKeys(struct TArray<struct FKey>& InKeys); // Offset: 0x104280750 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.InputKeySelector.SetAllowModifierKeys
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAllowModifierKeys(bool bInAllowModifierKeys); // Offset: 0x1042809ac // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.InputKeySelector.SetAllowGamepadKeys
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAllowGamepadKeys(bool bInAllowGamepadKeys); // Offset: 0x104280924 // Return & Params: Num(1) Size(0x1)

	// Object Name: DelegateFunction UMG.InputKeySelector.OnKeySelected__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnKeySelected__DelegateSignature(struct FInputChord SelectedKey); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x20)

	// Object Name: DelegateFunction UMG.InputKeySelector.OnIsSelectingKeyChanged__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnIsSelectingKeyChanged__DelegateSignature(); // Offset: 0x1032a8510 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.InputKeySelector.GetIsSelectingKey
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool GetIsSelectingKey(); // Offset: 0x1042808f0 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.Int32Binding
// Size: 0x60 // Inherited bytes: 0x60
struct UInt32Binding : UPropertyBinding {
	// Functions

	// Object Name: Function UMG.Int32Binding.GetValue
	// Flags: [Final|Native|Public|Const]
	int32_t GetValue(); // Offset: 0x104281238 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class UMG.InvalidationBox
// Size: 0x160 // Inherited bytes: 0x150
struct UInvalidationBox : UContentWidget {
	// Fields
	bool bCanCache; // Offset: 0x149 // Size: 0x01
	bool CacheRelativeTransforms; // Offset: 0x14a // Size: 0x01
	char pad_0x152[0xe]; // Offset: 0x152 // Size: 0x0e

	// Functions

	// Object Name: Function UMG.InvalidationBox.SetCanCache
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetCanCache(bool CanCache); // Offset: 0x104281488 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.InvalidationBox.InvalidateCache
	// Flags: [Final|Native|Public|BlueprintCallable]
	void InvalidateCache(); // Offset: 0x104281544 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.InvalidationBox.GetCanCache
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool GetCanCache(); // Offset: 0x104281510 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.UserListEntry
// Size: 0x28 // Inherited bytes: 0x28
struct UUserListEntry : UInterface {
	// Functions

	// Object Name: Function UMG.UserListEntry.BP_OnItemSelectionChanged
	// Flags: [Event|Protected|BlueprintEvent]
	void BP_OnItemSelectionChanged(bool bIsSelected); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.UserListEntry.BP_OnItemExpansionChanged
	// Flags: [Event|Protected|BlueprintEvent]
	void BP_OnItemExpansionChanged(bool bIsExpanded); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.UserListEntry.BP_OnEntryReleased
	// Flags: [Event|Protected|BlueprintEvent]
	void BP_OnEntryReleased(); // Offset: 0x1032a8510 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class UMG.UserListEntryLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct UUserListEntryLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function UMG.UserListEntryLibrary.IsListItemSelected
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	bool IsListItemSelected(struct TScriptInterface<IUserListEntry> UserListEntry); // Offset: 0x104281df4 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function UMG.UserListEntryLibrary.IsListItemExpanded
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	bool IsListItemExpanded(struct TScriptInterface<IUserListEntry> UserListEntry); // Offset: 0x104281d64 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function UMG.UserListEntryLibrary.GetOwningListView
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct UListViewBase* GetOwningListView(struct TScriptInterface<IUserListEntry> UserListEntry); // Offset: 0x104281cd4 // Return & Params: Num(2) Size(0x18)
};

// Object Name: Class UMG.UserObjectListEntry
// Size: 0x28 // Inherited bytes: 0x28
struct UUserObjectListEntry : UUserListEntry {
	// Functions

	// Object Name: Function UMG.UserObjectListEntry.OnListItemObjectSet
	// Flags: [Event|Protected|BlueprintEvent]
	void OnListItemObjectSet(struct UObject* ListItemObject); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class UMG.UserObjectListEntryLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct UUserObjectListEntryLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function UMG.UserObjectListEntryLibrary.GetListItemObject
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct UObject* GetListItemObject(struct TScriptInterface<IUserObjectListEntry> UserObjectListEntry); // Offset: 0x104282574 // Return & Params: Num(2) Size(0x18)
};

// Object Name: Class UMG.ListViewDesignerPreviewItem
// Size: 0x28 // Inherited bytes: 0x28
struct UListViewDesignerPreviewItem : UObject {
};

// Object Name: Class UMG.MenuAnchor
// Size: 0x190 // Inherited bytes: 0x150
struct UMenuAnchor : UContentWidget {
	// Fields
	struct UUserWidget* MenuClass; // Offset: 0x150 // Size: 0x08
	struct FDelegate OnGetMenuContentEvent; // Offset: 0x158 // Size: 0x10
	enum class EMenuPlacement Placement; // Offset: 0x168 // Size: 0x01
	bool bFitInWindow; // Offset: 0x169 // Size: 0x01
	bool ShouldDeferPaintingAfterWindowContent; // Offset: 0x16a // Size: 0x01
	bool UseApplicationMenuStack; // Offset: 0x16b // Size: 0x01
	char pad_0x16C[0x4]; // Offset: 0x16c // Size: 0x04
	struct FMulticastInlineDelegate OnMenuOpenChanged; // Offset: 0x170 // Size: 0x10
	char pad_0x180[0x10]; // Offset: 0x180 // Size: 0x10

	// Functions

	// Object Name: Function UMG.MenuAnchor.ToggleOpen
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ToggleOpen(bool bFocusOnOpen); // Offset: 0x1042867e8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.MenuAnchor.ShouldOpenDueToClick
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool ShouldOpenDueToClick(); // Offset: 0x1042866e4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.MenuAnchor.SetPlacement
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPlacement(enum class EMenuPlacement InPlacement); // Offset: 0x1042868f8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.MenuAnchor.Open
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Open(bool bFocusMenu); // Offset: 0x104286760 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.MenuAnchor.IsOpen
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsOpen(); // Offset: 0x104286718 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.MenuAnchor.HasOpenSubMenus
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool HasOpenSubMenus(); // Offset: 0x104286678 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.MenuAnchor.GetMenuPosition
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FVector2D GetMenuPosition(); // Offset: 0x1042866ac // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.MenuAnchor.FitInWindow
	// Flags: [Final|Native|Public|BlueprintCallable]
	void FitInWindow(bool bFit); // Offset: 0x104286870 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.MenuAnchor.Close
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Close(); // Offset: 0x10428674c // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class UMG.MouseCursorBinding
// Size: 0x60 // Inherited bytes: 0x60
struct UMouseCursorBinding : UPropertyBinding {
	// Functions

	// Object Name: Function UMG.MouseCursorBinding.GetValue
	// Flags: [Final|Native|Public|Const]
	enum class EMouseCursor GetValue(); // Offset: 0x104286e64 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.MovieScene2DTransformSection
// Size: 0x548 // Inherited bytes: 0xd8
struct UMovieScene2DTransformSection : UMovieSceneSection {
	// Fields
	struct FMovieScene2DTransformMask TransformMask; // Offset: 0xd8 // Size: 0x04
	char pad_0xDC[0x4]; // Offset: 0xdc // Size: 0x04
	struct FMovieSceneFloatChannel Translation[0x2]; // Offset: 0xe0 // Size: 0x140
	struct FMovieSceneFloatChannel Rotation; // Offset: 0x220 // Size: 0xa0
	struct FMovieSceneFloatChannel Scale[0x2]; // Offset: 0x2c0 // Size: 0x140
	struct FMovieSceneFloatChannel Shear[0x2]; // Offset: 0x400 // Size: 0x140
	char pad_0x540[0x8]; // Offset: 0x540 // Size: 0x08
};

// Object Name: Class UMG.MovieScene2DTransformTrack
// Size: 0x88 // Inherited bytes: 0x88
struct UMovieScene2DTransformTrack : UMovieScenePropertyTrack {
};

// Object Name: Class UMG.MovieSceneMarginSection
// Size: 0x358 // Inherited bytes: 0xd8
struct UMovieSceneMarginSection : UMovieSceneSection {
	// Fields
	struct FMovieSceneFloatChannel TopCurve; // Offset: 0xd8 // Size: 0xa0
	struct FMovieSceneFloatChannel LeftCurve; // Offset: 0x178 // Size: 0xa0
	struct FMovieSceneFloatChannel RightCurve; // Offset: 0x218 // Size: 0xa0
	struct FMovieSceneFloatChannel BottomCurve; // Offset: 0x2b8 // Size: 0xa0
};

// Object Name: Class UMG.MovieSceneMarginTrack
// Size: 0x88 // Inherited bytes: 0x88
struct UMovieSceneMarginTrack : UMovieScenePropertyTrack {
};

// Object Name: Class UMG.MovieSceneWidgetMaterialTrack
// Size: 0x80 // Inherited bytes: 0x68
struct UMovieSceneWidgetMaterialTrack : UMovieSceneMaterialTrack {
	// Fields
	struct TArray<struct FName> BrushPropertyNamePath; // Offset: 0x68 // Size: 0x10
	struct FName TrackName; // Offset: 0x78 // Size: 0x08
};

// Object Name: Class UMG.MultiLineEditableText
// Size: 0x4e8 // Inherited bytes: 0x160
struct UMultiLineEditableText : UTextLayoutWidget {
	// Fields
	struct FText Text; // Offset: 0x160 // Size: 0x18
	struct FText HintText; // Offset: 0x178 // Size: 0x18
	struct FDelegate HintTextDelegate; // Offset: 0x190 // Size: 0x10
	struct FTextBlockStyle WidgetStyle; // Offset: 0x1a0 // Size: 0x2a8
	bool bIsReadOnly; // Offset: 0x448 // Size: 0x01
	char pad_0x449[0x7]; // Offset: 0x449 // Size: 0x07
	struct FSlateFontInfo Font; // Offset: 0x450 // Size: 0x60
	bool SelectAllTextWhenFocused; // Offset: 0x4b0 // Size: 0x01
	bool ClearTextSelectionOnFocusLoss; // Offset: 0x4b1 // Size: 0x01
	bool RevertTextOnEscape; // Offset: 0x4b2 // Size: 0x01
	bool ClearKeyboardFocusOnCommit; // Offset: 0x4b3 // Size: 0x01
	bool AllowContextMenu; // Offset: 0x4b4 // Size: 0x01
	struct FVirtualKeyboardOptions VirtualKeyboardOptions; // Offset: 0x4b5 // Size: 0x01
	enum class EVirtualKeyboardDismissAction VirtualKeyboardDismissAction; // Offset: 0x4b6 // Size: 0x01
	char pad_0x4B7[0x1]; // Offset: 0x4b7 // Size: 0x01
	struct FMulticastInlineDelegate OnTextChanged; // Offset: 0x4b8 // Size: 0x10
	struct FMulticastInlineDelegate OnTextCommitted; // Offset: 0x4c8 // Size: 0x10
	char pad_0x4D8[0x10]; // Offset: 0x4d8 // Size: 0x10

	// Functions

	// Object Name: Function UMG.MultiLineEditableText.SetWidgetStyle
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetWidgetStyle(struct FTextBlockStyle& InWidgetStyle); // Offset: 0x104287c64 // Return & Params: Num(1) Size(0x2a8)

	// Object Name: Function UMG.MultiLineEditableText.SetText
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetText(struct FText InText); // Offset: 0x104287f90 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function UMG.MultiLineEditableText.SetIsReadOnly
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetIsReadOnly(bool bReadOnly); // Offset: 0x104287d04 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.MultiLineEditableText.SetHintText
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetHintText(struct FText InHintText); // Offset: 0x104287d8c // Return & Params: Num(1) Size(0x18)

	// Object Name: DelegateFunction UMG.MultiLineEditableText.OnMultiLineEditableTextCommittedEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void OnMultiLineEditableTextCommittedEvent__DelegateSignature(struct FText& Text, enum class ETextCommit CommitMethod); // Offset: 0x1032a8510 // Return & Params: Num(2) Size(0x19)

	// Object Name: DelegateFunction UMG.MultiLineEditableText.OnMultiLineEditableTextChangedEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void OnMultiLineEditableTextChangedEvent__DelegateSignature(struct FText& Text); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function UMG.MultiLineEditableText.GetText
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FText GetText(); // Offset: 0x1042880ec // Return & Params: Num(1) Size(0x18)

	// Object Name: Function UMG.MultiLineEditableText.GetHintText
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FText GetHintText(); // Offset: 0x104287ee8 // Return & Params: Num(1) Size(0x18)
};

// Object Name: Class UMG.MultiLineEditableTextBox
// Size: 0xde8 // Inherited bytes: 0x160
struct UMultiLineEditableTextBox : UTextLayoutWidget {
	// Fields
	struct FText Text; // Offset: 0x160 // Size: 0x18
	struct FText HintText; // Offset: 0x178 // Size: 0x18
	struct FDelegate HintTextDelegate; // Offset: 0x190 // Size: 0x10
	struct FEditableTextBoxStyle WidgetStyle; // Offset: 0x1a0 // Size: 0x8d0
	struct FTextBlockStyle TextStyle; // Offset: 0xa70 // Size: 0x2a8
	bool bIsReadOnly; // Offset: 0xd18 // Size: 0x01
	bool AllowContextMenu; // Offset: 0xd19 // Size: 0x01
	struct FVirtualKeyboardOptions VirtualKeyboardOptions; // Offset: 0xd1a // Size: 0x01
	enum class EVirtualKeyboardDismissAction VirtualKeyboardDismissAction; // Offset: 0xd1b // Size: 0x01
	char pad_0xD1C[0x4]; // Offset: 0xd1c // Size: 0x04
	struct USlateWidgetStyleAsset* Style; // Offset: 0xd20 // Size: 0x08
	struct FSlateFontInfo Font; // Offset: 0xd28 // Size: 0x60
	struct FLinearColor ForegroundColor; // Offset: 0xd88 // Size: 0x10
	struct FLinearColor BackgroundColor; // Offset: 0xd98 // Size: 0x10
	struct FLinearColor ReadOnlyForegroundColor; // Offset: 0xda8 // Size: 0x10
	struct FMulticastInlineDelegate OnTextChanged; // Offset: 0xdb8 // Size: 0x10
	struct FMulticastInlineDelegate OnTextCommitted; // Offset: 0xdc8 // Size: 0x10
	char pad_0xDD8[0x10]; // Offset: 0xdd8 // Size: 0x10

	// Functions

	// Object Name: Function UMG.MultiLineEditableTextBox.SetTextStyle
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetTextStyle(struct FTextBlockStyle& InTextStyle); // Offset: 0x10428861c // Return & Params: Num(1) Size(0x2a8)

	// Object Name: Function UMG.MultiLineEditableTextBox.SetText
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetText(struct FText InText); // Offset: 0x104288aa4 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function UMG.MultiLineEditableTextBox.SetIsReadOnly
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetIsReadOnly(bool bReadOnly); // Offset: 0x1042886bc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.MultiLineEditableTextBox.SetHintText
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetHintText(struct FText InHintText); // Offset: 0x1042888a0 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function UMG.MultiLineEditableTextBox.SetError
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetError(struct FText InError); // Offset: 0x104288744 // Return & Params: Num(1) Size(0x18)

	// Object Name: DelegateFunction UMG.MultiLineEditableTextBox.OnMultiLineEditableTextBoxCommittedEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void OnMultiLineEditableTextBoxCommittedEvent__DelegateSignature(struct FText& Text, enum class ETextCommit CommitMethod); // Offset: 0x1032a8510 // Return & Params: Num(2) Size(0x19)

	// Object Name: DelegateFunction UMG.MultiLineEditableTextBox.OnMultiLineEditableTextBoxChangedEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void OnMultiLineEditableTextBoxChangedEvent__DelegateSignature(struct FText& Text); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function UMG.MultiLineEditableTextBox.GetText
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FText GetText(); // Offset: 0x104288c00 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function UMG.MultiLineEditableTextBox.GetHintText
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FText GetHintText(); // Offset: 0x1042889fc // Return & Params: Num(1) Size(0x18)
};

// Object Name: Class UMG.NamedSlotInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UNamedSlotInterface : UInterface {
};

// Object Name: Class UMG.NativeWidgetHost
// Size: 0x148 // Inherited bytes: 0x138
struct UNativeWidgetHost : UWidget {
	// Fields
	char pad_0x138[0x10]; // Offset: 0x138 // Size: 0x10
};

// Object Name: Class UMG.ProgressBar
// Size: 0x378 // Inherited bytes: 0x138
struct UProgressBar : UWidget {
	// Fields
	struct FProgressBarStyle WidgetStyle; // Offset: 0x138 // Size: 0x1d0
	struct USlateWidgetStyleAsset* Style; // Offset: 0x308 // Size: 0x08
	struct USlateBrushAsset* BackgroundImage; // Offset: 0x310 // Size: 0x08
	struct USlateBrushAsset* FillImage; // Offset: 0x318 // Size: 0x08
	struct USlateBrushAsset* MarqueeImage; // Offset: 0x320 // Size: 0x08
	float Percent; // Offset: 0x328 // Size: 0x04
	enum class EProgressBarFillType BarFillType; // Offset: 0x32c // Size: 0x01
	bool bIsMarquee; // Offset: 0x32d // Size: 0x01
	char pad_0x32E[0x2]; // Offset: 0x32e // Size: 0x02
	struct FVector2D BorderPadding; // Offset: 0x330 // Size: 0x08
	struct FDelegate PercentDelegate; // Offset: 0x338 // Size: 0x10
	struct FLinearColor FillColorAndOpacity; // Offset: 0x348 // Size: 0x10
	struct FDelegate FillColorAndOpacityDelegate; // Offset: 0x358 // Size: 0x10
	char pad_0x368[0x10]; // Offset: 0x368 // Size: 0x10

	// Functions

	// Object Name: Function UMG.ProgressBar.SetPercent
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPercent(float InPercent); // Offset: 0x10428ab7c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.ProgressBar.SetIsMarquee
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetIsMarquee(bool InbIsMarquee); // Offset: 0x10428aa74 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.ProgressBar.SetFillColorAndOpacity
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetFillColorAndOpacity(struct FLinearColor InColor); // Offset: 0x10428aafc // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class UMG.RetainerBox
// Size: 0x178 // Inherited bytes: 0x150
struct URetainerBox : UContentWidget {
	// Fields
	bool bRetainRender; // Offset: 0x149 // Size: 0x01
	bool RenderOnInvalidation; // Offset: 0x14a // Size: 0x01
	bool RenderOnPhase; // Offset: 0x14b // Size: 0x01
	int32_t Phase; // Offset: 0x14c // Size: 0x04
	int32_t PhaseCount; // Offset: 0x150 // Size: 0x04
	struct UMaterialInterface* EffectMaterial; // Offset: 0x158 // Size: 0x08
	struct FName TextureParameter; // Offset: 0x160 // Size: 0x08
	char pad_0x16B[0xd]; // Offset: 0x16b // Size: 0x0d

	// Functions

	// Object Name: Function UMG.RetainerBox.SetTextureParameter
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetTextureParameter(struct FName TextureParameter); // Offset: 0x10428b248 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.RetainerBox.SetRetainRendering
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetRetainRendering(bool bInRetainRendering); // Offset: 0x10428b1c0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.RetainerBox.SetRenderingPhase
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetRenderingPhase(int32_t RenderPhase, int32_t TotalPhases); // Offset: 0x10428b390 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function UMG.RetainerBox.SetEffectMaterial
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetEffectMaterial(struct UMaterialInterface* EffectMaterial); // Offset: 0x10428b2c8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.RetainerBox.RequestRender
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RequestRender(); // Offset: 0x10428b37c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.RetainerBox.GetEffectMaterial
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UMaterialInstanceDynamic* GetEffectMaterial(); // Offset: 0x10428b348 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class UMG.RichTextBlockImageDecorator
// Size: 0x30 // Inherited bytes: 0x28
struct URichTextBlockImageDecorator : URichTextBlockDecorator {
	// Fields
	struct UDataTable* ImageSet; // Offset: 0x28 // Size: 0x08
};

// Object Name: Class UMG.SafeZone
// Size: 0x160 // Inherited bytes: 0x150
struct USafeZone : UContentWidget {
	// Fields
	bool PadLeft; // Offset: 0x149 // Size: 0x01
	bool PadRight; // Offset: 0x14a // Size: 0x01
	bool PadTop; // Offset: 0x14b // Size: 0x01
	bool PadBottom; // Offset: 0x14c // Size: 0x01
	char pad_0x154[0xc]; // Offset: 0x154 // Size: 0x0c

	// Functions

	// Object Name: Function UMG.SafeZone.SetSidesToPad
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSidesToPad(bool InPadLeft, bool InPadRight, bool InPadTop, bool InPadBottom); // Offset: 0x1042902fc // Return & Params: Num(4) Size(0x4)
};

// Object Name: Class UMG.SafeZoneSlot
// Size: 0x60 // Inherited bytes: 0x38
struct USafeZoneSlot : UPanelSlot {
	// Fields
	bool bIsTitleSafe; // Offset: 0x38 // Size: 0x01
	char pad_0x39[0x3]; // Offset: 0x39 // Size: 0x03
	struct FMargin SafeAreaScale; // Offset: 0x3c // Size: 0x10
	enum class EHorizontalAlignment HAlign; // Offset: 0x4c // Size: 0x01
	enum class EVerticalAlignment VAlign; // Offset: 0x4d // Size: 0x01
	char pad_0x4E[0x2]; // Offset: 0x4e // Size: 0x02
	struct FMargin Padding; // Offset: 0x50 // Size: 0x10
};

// Object Name: Class UMG.ScaleBox
// Size: 0x168 // Inherited bytes: 0x150
struct UScaleBox : UContentWidget {
	// Fields
	enum class EStretch Stretch; // Offset: 0x149 // Size: 0x01
	enum class EStretchDirection StretchDirection; // Offset: 0x14a // Size: 0x01
	float UserSpecifiedScale; // Offset: 0x14c // Size: 0x04
	bool IgnoreInheritedScale; // Offset: 0x150 // Size: 0x01
	float IgnoreSlightScaleModificationPercent; // Offset: 0x154 // Size: 0x04
	char pad_0x15B[0xd]; // Offset: 0x15b // Size: 0x0d

	// Functions

	// Object Name: Function UMG.ScaleBox.SetUserSpecifiedScale
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetUserSpecifiedScale(float InUserSpecifiedScale); // Offset: 0x104290a40 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.ScaleBox.SetStretchDirection
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetStretchDirection(enum class EStretchDirection InStretchDirection); // Offset: 0x104290ac0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.ScaleBox.SetStretch
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetStretch(enum class EStretch InStretch); // Offset: 0x104290b40 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.ScaleBox.SetIgnoreInheritedScale
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetIgnoreInheritedScale(bool bInIgnoreInheritedScale); // Offset: 0x1042909b8 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.ScaleBoxSlot
// Size: 0x60 // Inherited bytes: 0x38
struct UScaleBoxSlot : UPanelSlot {
	// Fields
	struct FMargin Padding; // Offset: 0x38 // Size: 0x10
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0x48 // Size: 0x01
	enum class EVerticalAlignment VerticalAlignment; // Offset: 0x49 // Size: 0x01
	char pad_0x4A[0x16]; // Offset: 0x4a // Size: 0x16

	// Functions

	// Object Name: Function UMG.ScaleBoxSlot.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment); // Offset: 0x104291060 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.ScaleBoxSlot.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPadding(struct FMargin InPadding); // Offset: 0x104291160 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.ScaleBoxSlot.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment); // Offset: 0x1042910e0 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.ScrollBar
// Size: 0x6d0 // Inherited bytes: 0x138
struct UScrollBar : UWidget {
	// Fields
	struct FScrollBarStyle WidgetStyle; // Offset: 0x138 // Size: 0x560
	struct USlateWidgetStyleAsset* Style; // Offset: 0x698 // Size: 0x08
	bool bAlwaysShowScrollbar; // Offset: 0x6a0 // Size: 0x01
	bool bAlwaysShowScrollbarTrack; // Offset: 0x6a1 // Size: 0x01
	enum class EOrientation Orientation; // Offset: 0x6a2 // Size: 0x01
	char pad_0x6A3[0x1]; // Offset: 0x6a3 // Size: 0x01
	struct FVector2D Thickness; // Offset: 0x6a4 // Size: 0x08
	struct FMargin Padding; // Offset: 0x6ac // Size: 0x10
	char pad_0x6BC[0x14]; // Offset: 0x6bc // Size: 0x14

	// Functions

	// Object Name: Function UMG.ScrollBar.SetState
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetState(float InOffsetFraction, float InThumbSizeFraction); // Offset: 0x104291614 // Return & Params: Num(2) Size(0x8)
};

// Object Name: Class UMG.ScrollBoxSlot
// Size: 0x58 // Inherited bytes: 0x38
struct UScrollBoxSlot : UPanelSlot {
	// Fields
	struct FMargin Padding; // Offset: 0x38 // Size: 0x10
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0x48 // Size: 0x01
	enum class EVerticalAlignment VerticalAlignment; // Offset: 0x49 // Size: 0x01
	char pad_0x4A[0xe]; // Offset: 0x4a // Size: 0x0e

	// Functions

	// Object Name: Function UMG.ScrollBoxSlot.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment); // Offset: 0x1042929a0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.ScrollBoxSlot.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPadding(struct FMargin InPadding); // Offset: 0x104292aa0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.ScrollBoxSlot.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment); // Offset: 0x104292a20 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.SizeBoxSlot
// Size: 0x60 // Inherited bytes: 0x38
struct USizeBoxSlot : UPanelSlot {
	// Fields
	struct FMargin Padding; // Offset: 0x38 // Size: 0x10
	char pad_0x48[0x10]; // Offset: 0x48 // Size: 0x10
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0x58 // Size: 0x01
	enum class EVerticalAlignment VerticalAlignment; // Offset: 0x59 // Size: 0x01
	char pad_0x5A[0x6]; // Offset: 0x5a // Size: 0x06

	// Functions

	// Object Name: Function UMG.SizeBoxSlot.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment); // Offset: 0x104293bc4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.SizeBoxSlot.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPadding(struct FMargin InPadding); // Offset: 0x104293cc4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.SizeBoxSlot.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment); // Offset: 0x104293c44 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.SlateBlueprintLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct USlateBlueprintLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function UMG.SlateBlueprintLibrary.WidgetGlobalPostionToSubWidgetLocal
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults]
	void WidgetGlobalPostionToSubWidgetLocal(struct UObject* WorldContextObject, struct FGeometry& Geometry, struct FVector2D ScreenUIPosition, struct FVector2D& OutLocalUIPostion); // Offset: 0x104294178 // Return & Params: Num(4) Size(0x50)

	// Object Name: Function UMG.SlateBlueprintLibrary.TransformVectorLocalToAbsolute
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	struct FVector2D TransformVectorLocalToAbsolute(struct FGeometry& Geometry, struct FVector2D LocalVector); // Offset: 0x104294d6c // Return & Params: Num(3) Size(0x48)

	// Object Name: Function UMG.SlateBlueprintLibrary.TransformVectorAbsoluteToLocal
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	struct FVector2D TransformVectorAbsoluteToLocal(struct FGeometry& Geometry, struct FVector2D AbsoluteVector); // Offset: 0x104294e4c // Return & Params: Num(3) Size(0x48)

	// Object Name: Function UMG.SlateBlueprintLibrary.TransformScalarLocalToAbsolute
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	float TransformScalarLocalToAbsolute(struct FGeometry& Geometry, float LocalScalar); // Offset: 0x104294f2c // Return & Params: Num(3) Size(0x40)

	// Object Name: Function UMG.SlateBlueprintLibrary.TransformScalarAbsoluteToLocal
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	float TransformScalarAbsoluteToLocal(struct FGeometry& Geometry, float AbsoluteScalar); // Offset: 0x104295014 // Return & Params: Num(3) Size(0x40)

	// Object Name: Function UMG.SlateBlueprintLibrary.ScreenToWidgetLocal
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults]
	void ScreenToWidgetLocal(struct UObject* WorldContextObject, struct FGeometry& Geometry, struct FVector2D ScreenPosition, struct FVector2D& LocalCoordinate, bool bIncludeWindowPosition); // Offset: 0x104294558 // Return & Params: Num(5) Size(0x51)

	// Object Name: Function UMG.SlateBlueprintLibrary.ScreenToWidgetAbsolute
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults]
	void ScreenToWidgetAbsolute(struct UObject* WorldContextObject, struct FVector2D ScreenPosition, struct FVector2D& AbsoluteCoordinate, bool bIncludeWindowPosition); // Offset: 0x1042943f4 // Return & Params: Num(4) Size(0x19)

	// Object Name: Function UMG.SlateBlueprintLibrary.ScreenToViewport
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults]
	void ScreenToViewport(struct UObject* WorldContextObject, struct FVector2D ScreenPosition, struct FVector2D& ViewportPosition); // Offset: 0x1042942e8 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function UMG.SlateBlueprintLibrary.LocalToViewport
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	void LocalToViewport(struct UObject* WorldContextObject, struct FGeometry& Geometry, struct FVector2D LocalCoordinate, struct FVector2D& PixelPosition, struct FVector2D& ViewportPosition); // Offset: 0x104294888 // Return & Params: Num(5) Size(0x58)

	// Object Name: Function UMG.SlateBlueprintLibrary.LocalToAbsolute
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	struct FVector2D LocalToAbsolute(struct FGeometry& Geometry, struct FVector2D LocalCoordinate); // Offset: 0x1042952b8 // Return & Params: Num(3) Size(0x48)

	// Object Name: Function UMG.SlateBlueprintLibrary.IsUnderLocation
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	bool IsUnderLocation(struct FGeometry& Geometry, struct FVector2D& AbsoluteCoordinate); // Offset: 0x104295478 // Return & Params: Num(3) Size(0x41)

	// Object Name: Function UMG.SlateBlueprintLibrary.GetLocalTopLeft
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	struct FVector2D GetLocalTopLeft(struct FGeometry& Geometry); // Offset: 0x104295224 // Return & Params: Num(2) Size(0x40)

	// Object Name: Function UMG.SlateBlueprintLibrary.GetLocalSize
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	struct FVector2D GetLocalSize(struct FGeometry& Geometry); // Offset: 0x104295190 // Return & Params: Num(2) Size(0x40)

	// Object Name: Function UMG.SlateBlueprintLibrary.GetAbsoluteSize
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	struct FVector2D GetAbsoluteSize(struct FGeometry& Geometry); // Offset: 0x1042950fc // Return & Params: Num(2) Size(0x40)

	// Object Name: Function UMG.SlateBlueprintLibrary.EqualEqual_SlateBrush
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	bool EqualEqual_SlateBrush(struct FSlateBrush& A, struct FSlateBrush& B); // Offset: 0x104294a54 // Return & Params: Num(3) Size(0x131)

	// Object Name: Function UMG.SlateBlueprintLibrary.AbsoluteToViewport
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	void AbsoluteToViewport(struct UObject* WorldContextObject, struct FVector2D AbsoluteDesktopCoordinate, struct FVector2D& PixelPosition, struct FVector2D& ViewportPosition); // Offset: 0x104294728 // Return & Params: Num(4) Size(0x20)

	// Object Name: Function UMG.SlateBlueprintLibrary.AbsoluteToLocal
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	struct FVector2D AbsoluteToLocal(struct FGeometry& Geometry, struct FVector2D AbsoluteCoordinate); // Offset: 0x104295398 // Return & Params: Num(3) Size(0x48)
};

// Object Name: Class UMG.SlateVectorArtData
// Size: 0x60 // Inherited bytes: 0x28
struct USlateVectorArtData : UObject {
	// Fields
	struct TArray<struct FSlateMeshVertex> VertexData; // Offset: 0x28 // Size: 0x10
	struct TArray<uint32_t> IndexData; // Offset: 0x38 // Size: 0x10
	struct UMaterialInterface* Material; // Offset: 0x48 // Size: 0x08
	struct FVector2D ExtentMin; // Offset: 0x50 // Size: 0x08
	struct FVector2D ExtentMax; // Offset: 0x58 // Size: 0x08
};

// Object Name: Class UMG.SlateAccessibleWidgetData
// Size: 0x80 // Inherited bytes: 0x28
struct USlateAccessibleWidgetData : UObject {
	// Fields
	bool bCanChildrenBeAccessible; // Offset: 0x28 // Size: 0x01
	enum class ESlateAccessibleBehavior AccessibleBehavior; // Offset: 0x29 // Size: 0x01
	enum class ESlateAccessibleBehavior AccessibleSummaryBehavior; // Offset: 0x2a // Size: 0x01
	char pad_0x2B[0x5]; // Offset: 0x2b // Size: 0x05
	struct FText AccessibleText; // Offset: 0x30 // Size: 0x18
	struct FDelegate AccessibleTextDelegate; // Offset: 0x48 // Size: 0x10
	struct FText AccessibleSummaryText; // Offset: 0x58 // Size: 0x18
	struct FDelegate AccessibleSummaryTextDelegate; // Offset: 0x70 // Size: 0x10
};

// Object Name: Class UMG.Spacer
// Size: 0x150 // Inherited bytes: 0x138
struct USpacer : UWidget {
	// Fields
	struct FVector2D Size; // Offset: 0x138 // Size: 0x08
	char pad_0x140[0x10]; // Offset: 0x140 // Size: 0x10

	// Functions

	// Object Name: Function UMG.Spacer.SetSize
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetSize(struct FVector2D InSize); // Offset: 0x1042997c4 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class UMG.SpinBox
// Size: 0x5a8 // Inherited bytes: 0x138
struct USpinBox : UWidget {
	// Fields
	float Value; // Offset: 0x138 // Size: 0x04
	struct FDelegate ValueDelegate; // Offset: 0x13c // Size: 0x10
	char pad_0x14C[0x4]; // Offset: 0x14c // Size: 0x04
	struct FSpinBoxStyle WidgetStyle; // Offset: 0x150 // Size: 0x338
	struct USlateWidgetStyleAsset* Style; // Offset: 0x488 // Size: 0x08
	int32_t MinFractionalDigits; // Offset: 0x490 // Size: 0x04
	int32_t MaxFractionalDigits; // Offset: 0x494 // Size: 0x04
	bool bAlwaysUsesDeltaSnap; // Offset: 0x498 // Size: 0x01
	char pad_0x499[0x3]; // Offset: 0x499 // Size: 0x03
	float Delta; // Offset: 0x49c // Size: 0x04
	float SliderExponent; // Offset: 0x4a0 // Size: 0x04
	char pad_0x4A4[0x4]; // Offset: 0x4a4 // Size: 0x04
	struct FSlateFontInfo Font; // Offset: 0x4a8 // Size: 0x60
	enum class ETextJustify Justification; // Offset: 0x508 // Size: 0x01
	char pad_0x509[0x3]; // Offset: 0x509 // Size: 0x03
	float MinDesiredWidth; // Offset: 0x50c // Size: 0x04
	bool ClearKeyboardFocusOnCommit; // Offset: 0x510 // Size: 0x01
	bool SelectAllTextOnCommit; // Offset: 0x511 // Size: 0x01
	char pad_0x512[0x6]; // Offset: 0x512 // Size: 0x06
	struct FSlateColor ForegroundColor; // Offset: 0x518 // Size: 0x28
	struct FMulticastInlineDelegate OnValueChanged; // Offset: 0x540 // Size: 0x10
	struct FMulticastInlineDelegate OnValueCommitted; // Offset: 0x550 // Size: 0x10
	struct FMulticastInlineDelegate OnBeginSliderMovement; // Offset: 0x560 // Size: 0x10
	struct FMulticastInlineDelegate OnEndSliderMovement; // Offset: 0x570 // Size: 0x10
	char bOverride_MinValue : 1; // Offset: 0x580 // Size: 0x01
	char bOverride_MaxValue : 1; // Offset: 0x580 // Size: 0x01
	char bOverride_MinSliderValue : 1; // Offset: 0x580 // Size: 0x01
	char bOverride_MaxSliderValue : 1; // Offset: 0x580 // Size: 0x01
	char pad_0x580_4 : 4; // Offset: 0x580 // Size: 0x01
	char pad_0x581[0x3]; // Offset: 0x581 // Size: 0x03
	float MinValue; // Offset: 0x584 // Size: 0x04
	float MaxValue; // Offset: 0x588 // Size: 0x04
	float MinSliderValue; // Offset: 0x58c // Size: 0x04
	float MaxSliderValue; // Offset: 0x590 // Size: 0x04
	char pad_0x594[0x14]; // Offset: 0x594 // Size: 0x14

	// Functions

	// Object Name: Function UMG.SpinBox.SetValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetValue(float NewValue); // Offset: 0x10429a2f8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.SpinBox.SetMinValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMinValue(float NewValue); // Offset: 0x104299f6c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.SpinBox.SetMinSliderValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMinSliderValue(float NewValue); // Offset: 0x104299ddc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.SpinBox.SetMinFractionalDigits
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMinFractionalDigits(int32_t NewValue); // Offset: 0x10429a244 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.SpinBox.SetMaxValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMaxValue(float NewValue); // Offset: 0x104299ea4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.SpinBox.SetMaxSliderValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMaxSliderValue(float NewValue); // Offset: 0x104299d14 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.SpinBox.SetMaxFractionalDigits
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMaxFractionalDigits(int32_t NewValue); // Offset: 0x10429a190 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.SpinBox.SetForegroundColor
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetForegroundColor(struct FSlateColor InForegroundColor); // Offset: 0x104299b90 // Return & Params: Num(1) Size(0x28)

	// Object Name: Function UMG.SpinBox.SetDelta
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetDelta(float NewValue); // Offset: 0x10429a020 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.SpinBox.SetAlwaysUsesDeltaSnap
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAlwaysUsesDeltaSnap(bool bNewValue); // Offset: 0x10429a0d4 // Return & Params: Num(1) Size(0x1)

	// Object Name: DelegateFunction UMG.SpinBox.OnSpinBoxValueCommittedEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnSpinBoxValueCommittedEvent__DelegateSignature(float InValue, enum class ETextCommit CommitMethod); // Offset: 0x1032a8510 // Return & Params: Num(2) Size(0x5)

	// Object Name: DelegateFunction UMG.SpinBox.OnSpinBoxValueChangedEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnSpinBoxValueChangedEvent__DelegateSignature(float InValue); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x4)

	// Object Name: DelegateFunction UMG.SpinBox.OnSpinBoxBeginSliderMovement__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnSpinBoxBeginSliderMovement__DelegateSignature(); // Offset: 0x1032a8510 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.SpinBox.GetValue
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetValue(); // Offset: 0x10429a378 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.SpinBox.GetMinValue
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetMinValue(); // Offset: 0x104299fec // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.SpinBox.GetMinSliderValue
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetMinSliderValue(); // Offset: 0x104299e5c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.SpinBox.GetMinFractionalDigits
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetMinFractionalDigits(); // Offset: 0x10429a2c4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.SpinBox.GetMaxValue
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetMaxValue(); // Offset: 0x104299f24 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.SpinBox.GetMaxSliderValue
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetMaxSliderValue(); // Offset: 0x104299d94 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.SpinBox.GetMaxFractionalDigits
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetMaxFractionalDigits(); // Offset: 0x10429a210 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.SpinBox.GetDelta
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetDelta(); // Offset: 0x10429a0a0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.SpinBox.GetAlwaysUsesDeltaSnap
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool GetAlwaysUsesDeltaSnap(); // Offset: 0x10429a15c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.SpinBox.ClearMinValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearMinValue(); // Offset: 0x104299f58 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.SpinBox.ClearMinSliderValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearMinSliderValue(); // Offset: 0x104299dc8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.SpinBox.ClearMaxValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearMaxValue(); // Offset: 0x104299e90 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.SpinBox.ClearMaxSliderValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearMaxSliderValue(); // Offset: 0x104299d00 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class UMG.TextBinding
// Size: 0x68 // Inherited bytes: 0x60
struct UTextBinding : UPropertyBinding {
	// Fields
	char pad_0x60[0x8]; // Offset: 0x60 // Size: 0x08

	// Functions

	// Object Name: Function UMG.TextBinding.GetTextValue
	// Flags: [Final|Native|Public|Const]
	struct FText GetTextValue(); // Offset: 0x10429ad04 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function UMG.TextBinding.GetStringValue
	// Flags: [Final|Native|Public|Const]
	struct FString GetStringValue(); // Offset: 0x10429ac84 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class UMG.Throbber
// Size: 0x1f0 // Inherited bytes: 0x138
struct UThrobber : UWidget {
	// Fields
	int32_t NumberOfPieces; // Offset: 0x138 // Size: 0x04
	bool bAnimateHorizontally; // Offset: 0x13c // Size: 0x01
	bool bAnimateVertically; // Offset: 0x13d // Size: 0x01
	bool bAnimateOpacity; // Offset: 0x13e // Size: 0x01
	char pad_0x13F[0x1]; // Offset: 0x13f // Size: 0x01
	struct USlateBrushAsset* PieceImage; // Offset: 0x140 // Size: 0x08
	struct FSlateBrush Image; // Offset: 0x148 // Size: 0x98
	char pad_0x1E0[0x10]; // Offset: 0x1e0 // Size: 0x10

	// Functions

	// Object Name: Function UMG.Throbber.SetNumberOfPieces
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetNumberOfPieces(int32_t InNumberOfPieces); // Offset: 0x10429c78c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.Throbber.SetAnimateVertically
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAnimateVertically(bool bInAnimateVertically); // Offset: 0x10429c67c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Throbber.SetAnimateOpacity
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAnimateOpacity(bool bInAnimateOpacity); // Offset: 0x10429c5f4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.Throbber.SetAnimateHorizontally
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAnimateHorizontally(bool bInAnimateHorizontally); // Offset: 0x10429c704 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.UMGSequencePlayer
// Size: 0x7a8 // Inherited bytes: 0x28
struct UUMGSequencePlayer : UObject {
	// Fields
	char pad_0x28[0x3e0]; // Offset: 0x28 // Size: 0x3e0
	struct UWidgetAnimation* Animation; // Offset: 0x408 // Size: 0x08
	char pad_0x410[0x398]; // Offset: 0x410 // Size: 0x398

	// Functions

	// Object Name: Function UMG.UMGSequencePlayer.SetUserTag
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetUserTag(struct FName InUserTag); // Offset: 0x10429ec54 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.UMGSequencePlayer.GetUserTag
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FName GetUserTag(); // Offset: 0x10429ecd4 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class UMG.UniformGridPanel
// Size: 0x178 // Inherited bytes: 0x150
struct UUniformGridPanel : UPanelWidget {
	// Fields
	struct FMargin SlotPadding; // Offset: 0x14c // Size: 0x10
	float MinDesiredSlotWidth; // Offset: 0x15c // Size: 0x04
	float MinDesiredSlotHeight; // Offset: 0x160 // Size: 0x04
	char pad_0x168[0x10]; // Offset: 0x168 // Size: 0x10

	// Functions

	// Object Name: Function UMG.UniformGridPanel.SetSlotPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSlotPadding(struct FMargin InSlotPadding); // Offset: 0x10429f2ec // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.UniformGridPanel.SetMinDesiredSlotWidth
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMinDesiredSlotWidth(float InMinDesiredSlotWidth); // Offset: 0x10429f26c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.UniformGridPanel.SetMinDesiredSlotHeight
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMinDesiredSlotHeight(float InMinDesiredSlotHeight); // Offset: 0x10429f1ec // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.UniformGridPanel.AddChildToUniformGrid
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UUniformGridSlot* AddChildToUniformGrid(struct UWidget* Content, int32_t InRow, int32_t InColumn); // Offset: 0x10429f0c8 // Return & Params: Num(4) Size(0x18)
};

// Object Name: Class UMG.UniformGridSlot
// Size: 0x50 // Inherited bytes: 0x38
struct UUniformGridSlot : UPanelSlot {
	// Fields
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0x38 // Size: 0x01
	enum class EVerticalAlignment VerticalAlignment; // Offset: 0x39 // Size: 0x01
	char pad_0x3A[0x2]; // Offset: 0x3a // Size: 0x02
	int32_t Row; // Offset: 0x3c // Size: 0x04
	int32_t Column; // Offset: 0x40 // Size: 0x04
	char pad_0x44[0xc]; // Offset: 0x44 // Size: 0x0c

	// Functions

	// Object Name: Function UMG.UniformGridSlot.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment); // Offset: 0x10429f730 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.UniformGridSlot.SetRow
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetRow(int32_t InRow); // Offset: 0x10429f8b0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.UniformGridSlot.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment); // Offset: 0x10429f7b0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.UniformGridSlot.SetColumn
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetColumn(int32_t InColumn); // Offset: 0x10429f830 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class UMG.VerticalBox
// Size: 0x160 // Inherited bytes: 0x150
struct UVerticalBox : UPanelWidget {
	// Fields
	char pad_0x150[0x10]; // Offset: 0x150 // Size: 0x10

	// Functions

	// Object Name: Function UMG.VerticalBox.AddChildToVerticalBox
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UVerticalBoxSlot* AddChildToVerticalBox(struct UWidget* Content); // Offset: 0x1042a9d54 // Return & Params: Num(2) Size(0x10)
};

// Object Name: Class UMG.VerticalBoxSlot
// Size: 0x60 // Inherited bytes: 0x38
struct UVerticalBoxSlot : UPanelSlot {
	// Fields
	struct FSlateChildSize Size; // Offset: 0x38 // Size: 0x08
	struct FMargin Padding; // Offset: 0x40 // Size: 0x10
	char pad_0x50[0x8]; // Offset: 0x50 // Size: 0x08
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0x58 // Size: 0x01
	enum class EVerticalAlignment VerticalAlignment; // Offset: 0x59 // Size: 0x01
	char pad_0x5A[0x6]; // Offset: 0x5a // Size: 0x06

	// Functions

	// Object Name: Function UMG.VerticalBoxSlot.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment); // Offset: 0x1042aa23c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.VerticalBoxSlot.SetSize
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSize(struct FSlateChildSize InSize); // Offset: 0x1042aa33c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.VerticalBoxSlot.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPadding(struct FMargin InPadding); // Offset: 0x1042aa3c8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.VerticalBoxSlot.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment); // Offset: 0x1042aa2bc // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.Viewport
// Size: 0x178 // Inherited bytes: 0x150
struct UViewport : UContentWidget {
	// Fields
	struct FLinearColor BackgroundColor; // Offset: 0x14c // Size: 0x10
	char pad_0x160[0x18]; // Offset: 0x160 // Size: 0x18

	// Functions

	// Object Name: Function UMG.Viewport.Spawn
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct AActor* Spawn(struct AActor* ActorClass); // Offset: 0x1042aa80c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UMG.Viewport.SetViewRotation
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetViewRotation(struct FRotator Rotation); // Offset: 0x1042aa89c // Return & Params: Num(1) Size(0xc)

	// Object Name: Function UMG.Viewport.SetViewLocation
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetViewLocation(struct FVector Location); // Offset: 0x1042aa954 // Return & Params: Num(1) Size(0xc)

	// Object Name: Function UMG.Viewport.GetViewRotation
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FRotator GetViewRotation(); // Offset: 0x1042aa91c // Return & Params: Num(1) Size(0xc)

	// Object Name: Function UMG.Viewport.GetViewportWorld
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UWorld* GetViewportWorld(); // Offset: 0x1042aaa0c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.Viewport.GetViewLocation
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FVector GetViewLocation(); // Offset: 0x1042aa9d4 // Return & Params: Num(1) Size(0xc)
};

// Object Name: Class UMG.VisibilityBinding
// Size: 0x60 // Inherited bytes: 0x60
struct UVisibilityBinding : UPropertyBinding {
	// Functions

	// Object Name: Function UMG.VisibilityBinding.GetValue
	// Flags: [Final|Native|Public|Const]
	enum class ESlateVisibility GetValue(); // Offset: 0x1042aaddc // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.WidgetAnimation
// Size: 0x380 // Inherited bytes: 0x348
struct UWidgetAnimation : UMovieSceneSequence {
	// Fields
	struct UMovieScene* MovieScene; // Offset: 0x348 // Size: 0x08
	struct TArray<struct FWidgetAnimationBinding> AnimationBindings; // Offset: 0x350 // Size: 0x10
	bool bLegacyFinishOnStop; // Offset: 0x360 // Size: 0x01
	char pad_0x361[0x7]; // Offset: 0x361 // Size: 0x07
	struct FString DisplayLabel; // Offset: 0x368 // Size: 0x10
	enum class ESlateDetailMode DetailMode; // Offset: 0x378 // Size: 0x01
	char pad_0x379[0x7]; // Offset: 0x379 // Size: 0x07

	// Functions

	// Object Name: Function UMG.WidgetAnimation.UnbindFromAnimationStarted
	// Flags: [Final|Native|Public|BlueprintCallable]
	void UnbindFromAnimationStarted(struct UUserWidget* Widget, struct FDelegate Delegate); // Offset: 0x1042ae2f0 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function UMG.WidgetAnimation.UnbindFromAnimationFinished
	// Flags: [Final|Native|Public|BlueprintCallable]
	void UnbindFromAnimationFinished(struct UUserWidget* Widget, struct FDelegate Delegate); // Offset: 0x1042ae078 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function UMG.WidgetAnimation.UnbindAllFromAnimationStarted
	// Flags: [Final|Native|Public|BlueprintCallable]
	void UnbindAllFromAnimationStarted(struct UUserWidget* Widget); // Offset: 0x1042ae270 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.WidgetAnimation.UnbindAllFromAnimationFinished
	// Flags: [Final|Native|Public|BlueprintCallable]
	void UnbindAllFromAnimationFinished(struct UUserWidget* Widget); // Offset: 0x1042adff8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.WidgetAnimation.SetDetailMode
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetDetailMode(enum class ESlateDetailMode InDetailMode); // Offset: 0x1042adf70 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.WidgetAnimation.GetStartTime
	// Flags: [Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetStartTime(); // Offset: 0x1042ae51c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.WidgetAnimation.GetEndTime
	// Flags: [Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetEndTime(); // Offset: 0x1042ae4e8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.WidgetAnimation.BindToAnimationStarted
	// Flags: [Final|Native|Public|BlueprintCallable]
	void BindToAnimationStarted(struct UUserWidget* Widget, struct FDelegate Delegate); // Offset: 0x1042ae3ec // Return & Params: Num(2) Size(0x18)

	// Object Name: Function UMG.WidgetAnimation.BindToAnimationFinished
	// Flags: [Final|Native|Public|BlueprintCallable]
	void BindToAnimationFinished(struct UUserWidget* Widget, struct FDelegate Delegate); // Offset: 0x1042ae174 // Return & Params: Num(2) Size(0x18)
};

// Object Name: Class UMG.WidgetAnimationDelegateBinding
// Size: 0x38 // Inherited bytes: 0x28
struct UWidgetAnimationDelegateBinding : UDynamicBlueprintBinding {
	// Fields
	struct TArray<struct FBlueprintWidgetAnimationDelegateBinding> WidgetAnimationDelegateBindings; // Offset: 0x28 // Size: 0x10
};

// Object Name: Class UMG.WidgetAnimationPlayCallbackProxy
// Size: 0x48 // Inherited bytes: 0x28
struct UWidgetAnimationPlayCallbackProxy : UObject {
	// Fields
	struct FMulticastInlineDelegate Finished; // Offset: 0x28 // Size: 0x10
	char pad_0x38[0x10]; // Offset: 0x38 // Size: 0x10

	// Functions

	// Object Name: Function UMG.WidgetAnimationPlayCallbackProxy.CreatePlayAnimationTimeRangeProxyObject
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct UWidgetAnimationPlayCallbackProxy* CreatePlayAnimationTimeRangeProxyObject(struct UUMGSequencePlayer*& Result, struct UUserWidget* Widget, struct UWidgetAnimation* InAnimation, float StartAtTime, float EndAtTime, int32_t NumLoopsToPlay, enum class EUMGSequencePlayMode PlayMode, float PlaybackSpeed); // Offset: 0x1042afffc // Return & Params: Num(9) Size(0x38)

	// Object Name: Function UMG.WidgetAnimationPlayCallbackProxy.CreatePlayAnimationProxyObject
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct UWidgetAnimationPlayCallbackProxy* CreatePlayAnimationProxyObject(struct UUMGSequencePlayer*& Result, struct UUserWidget* Widget, struct UWidgetAnimation* InAnimation, float StartAtTime, int32_t NumLoopsToPlay, enum class EUMGSequencePlayMode PlayMode, float PlaybackSpeed); // Offset: 0x1042b02a0 // Return & Params: Num(8) Size(0x30)
};

// Object Name: Class UMG.WidgetBinding
// Size: 0x60 // Inherited bytes: 0x60
struct UWidgetBinding : UPropertyBinding {
	// Functions

	// Object Name: Function UMG.WidgetBinding.GetValue
	// Flags: [Final|Native|Public|Const]
	struct UWidget* GetValue(); // Offset: 0x1042b08c0 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class UMG.WidgetBlueprintGeneratedClass
// Size: 0x458 // Inherited bytes: 0x418
struct UWidgetBlueprintGeneratedClass : UBlueprintGeneratedClass {
	// Fields
	struct UWidgetTree* WidgetTree; // Offset: 0x418 // Size: 0x08
	char bClassRequiresNativeTick : 1; // Offset: 0x420 // Size: 0x01
	char pad_0x420_1 : 7; // Offset: 0x420 // Size: 0x01
	char pad_0x421[0x7]; // Offset: 0x421 // Size: 0x07
	struct TArray<struct FDelegateRuntimeBinding> Bindings; // Offset: 0x428 // Size: 0x10
	struct TArray<struct UWidgetAnimation*> Animations; // Offset: 0x438 // Size: 0x10
	struct TArray<struct FName> NamedSlots; // Offset: 0x448 // Size: 0x10
};

// Object Name: Class UMG.WidgetBlueprintLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct UWidgetBlueprintLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function UMG.WidgetBlueprintLibrary.UnlockMouse
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FEventReply UnlockMouse(struct FEventReply& Reply); // Offset: 0x1042b43ec // Return & Params: Num(2) Size(0x170)

	// Object Name: Function UMG.WidgetBlueprintLibrary.Unhandled
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FEventReply Unhandled(); // Offset: 0x1042b490c // Return & Params: Num(1) Size(0xb8)

	// Object Name: Function UMG.WidgetBlueprintLibrary.SetWindowTitleBarState
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetWindowTitleBarState(struct UWidget* TitleBarContent, enum class EWindowTitleBarMode Mode, bool bTitleBarDragEnabled, bool bWindowButtonsVisible, bool bTitleBarVisible); // Offset: 0x1042b105c // Return & Params: Num(5) Size(0xc)

	// Object Name: Function UMG.WidgetBlueprintLibrary.SetWindowTitleBarOnCloseClickedDelegate
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetWindowTitleBarOnCloseClickedDelegate(struct FDelegate Delegate); // Offset: 0x1042b0f94 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.WidgetBlueprintLibrary.SetWindowTitleBarCloseButtonActive
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetWindowTitleBarCloseButtonActive(bool bActive); // Offset: 0x1042b0f14 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.WidgetBlueprintLibrary.SetUserFocus
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FEventReply SetUserFocus(struct FEventReply& Reply, struct UWidget* FocusWidget, bool bInAllUsers); // Offset: 0x1042b4228 // Return & Params: Num(4) Size(0x180)

	// Object Name: Function UMG.WidgetBlueprintLibrary.SetMousePosition
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	struct FEventReply SetMousePosition(struct FEventReply& Reply, struct FVector2D NewMousePosition); // Offset: 0x1042b3c0c // Return & Params: Num(3) Size(0x178)

	// Object Name: Function UMG.WidgetBlueprintLibrary.SetInputMode_UIOnlyEx
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void SetInputMode_UIOnlyEx(struct APlayerController* PlayerController, struct UWidget* InWidgetToFocus, enum class EMouseLockMode InMouseLockMode); // Offset: 0x1042b56f0 // Return & Params: Num(3) Size(0x11)

	// Object Name: Function UMG.WidgetBlueprintLibrary.SetInputMode_UIOnly
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void SetInputMode_UIOnly(struct APlayerController* Target, struct UWidget* InWidgetToFocus, bool bLockMouseToViewport); // Offset: 0x1042b57fc // Return & Params: Num(3) Size(0x11)

	// Object Name: Function UMG.WidgetBlueprintLibrary.SetInputMode_GameOnly
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void SetInputMode_GameOnly(struct APlayerController* PlayerController); // Offset: 0x1042b53ac // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.WidgetBlueprintLibrary.SetInputMode_GameAndUIEx
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void SetInputMode_GameAndUIEx(struct APlayerController* PlayerController, struct UWidget* InWidgetToFocus, enum class EMouseLockMode InMouseLockMode, bool bHideCursorDuringCapture); // Offset: 0x1042b5424 // Return & Params: Num(4) Size(0x12)

	// Object Name: Function UMG.WidgetBlueprintLibrary.SetInputMode_GameAndUI
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void SetInputMode_GameAndUI(struct APlayerController* Target, struct UWidget* InWidgetToFocus, bool bLockMouseToViewport, bool bHideCursorDuringCapture); // Offset: 0x1042b5584 // Return & Params: Num(4) Size(0x12)

	// Object Name: Function UMG.WidgetBlueprintLibrary.SetHardwareCursor
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	bool SetHardwareCursor(struct UObject* WorldContextObject, enum class EMouseCursor CursorShape, struct FName CursorName, struct FVector2D HotSpot); // Offset: 0x1042b122c // Return & Params: Num(5) Size(0x1d)

	// Object Name: Function UMG.WidgetBlueprintLibrary.SetFocusToGameViewport
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void SetFocusToGameViewport(); // Offset: 0x1042b5398 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.WidgetBlueprintLibrary.SetColorVisionDeficiencyType
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void SetColorVisionDeficiencyType(enum class EColorVisionDeficiency Type, float Severity, bool CorrectDeficiency, bool ShowCorrectionWithDeficiency); // Offset: 0x1042b1388 // Return & Params: Num(4) Size(0xa)

	// Object Name: Function UMG.WidgetBlueprintLibrary.SetBrushResourceToTexture
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void SetBrushResourceToTexture(struct FSlateBrush& Brush, struct UTexture2D* Texture); // Offset: 0x1042b2544 // Return & Params: Num(2) Size(0xa0)

	// Object Name: Function UMG.WidgetBlueprintLibrary.SetBrushResourceToMaterial
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void SetBrushResourceToMaterial(struct FSlateBrush& Brush, struct UMaterialInterface* Material); // Offset: 0x1042b2354 // Return & Params: Num(2) Size(0xa0)

	// Object Name: Function UMG.WidgetBlueprintLibrary.RestorePreviousWindowTitleBarState
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void RestorePreviousWindowTitleBarState(); // Offset: 0x1042b1048 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.WidgetBlueprintLibrary.ReleaseMouseCapture
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FEventReply ReleaseMouseCapture(struct FEventReply& Reply); // Offset: 0x1042b467c // Return & Params: Num(2) Size(0x170)

	// Object Name: Function UMG.WidgetBlueprintLibrary.ReleaseJoystickCapture
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FEventReply ReleaseJoystickCapture(struct FEventReply& Reply, bool bInAllJoysticks); // Offset: 0x1042b3d74 // Return & Params: Num(3) Size(0x178)

	// Object Name: DelegateFunction UMG.WidgetBlueprintLibrary.OnGameWindowCloseButtonClickedDelegate__DelegateSignature
	// Flags: [Public|Delegate]
	void OnGameWindowCloseButtonClickedDelegate__DelegateSignature(); // Offset: 0x1032a8510 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.WidgetBlueprintLibrary.NoResourceBrush
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FSlateBrush NoResourceBrush(); // Offset: 0x1042b211c // Return & Params: Num(1) Size(0x98)

	// Object Name: Function UMG.WidgetBlueprintLibrary.MakeBrushFromTexture
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FSlateBrush MakeBrushFromTexture(struct UTexture2D* Texture, int32_t Width, int32_t Height); // Offset: 0x1042b2f60 // Return & Params: Num(4) Size(0xa8)

	// Object Name: Function UMG.WidgetBlueprintLibrary.MakeBrushFromMaterial
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FSlateBrush MakeBrushFromMaterial(struct UMaterialInterface* Material, int32_t Width, int32_t Height); // Offset: 0x1042b2c50 // Return & Params: Num(4) Size(0xa8)

	// Object Name: Function UMG.WidgetBlueprintLibrary.MakeBrushFromAsset
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FSlateBrush MakeBrushFromAsset(struct USlateBrushAsset* BrushAsset); // Offset: 0x1042b3270 // Return & Params: Num(2) Size(0xa0)

	// Object Name: Function UMG.WidgetBlueprintLibrary.LockMouse
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FEventReply LockMouse(struct FEventReply& Reply, struct UWidget* CapturingWidget); // Offset: 0x1042b450c // Return & Params: Num(3) Size(0x178)

	// Object Name: Function UMG.WidgetBlueprintLibrary.IsDragDropping
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable|BlueprintPure]
	bool IsDragDropping(); // Offset: 0x1042b3534 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.WidgetBlueprintLibrary.Handled
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FEventReply Handled(); // Offset: 0x1042b4988 // Return & Params: Num(1) Size(0xb8)

	// Object Name: Function UMG.WidgetBlueprintLibrary.GetSafeZonePadding
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void GetSafeZonePadding(struct UObject* WorldContextObject, struct FVector4& SafePadding, struct FVector2D& SafePaddingScale, struct FVector4& SpillOverPadding); // Offset: 0x1042b14f8 // Return & Params: Num(4) Size(0x40)

	// Object Name: Function UMG.WidgetBlueprintLibrary.GetKeyEventFromAnalogInputEvent
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FKeyEvent GetKeyEventFromAnalogInputEvent(struct FAnalogInputEvent& Event); // Offset: 0x1042b1938 // Return & Params: Num(2) Size(0x78)

	// Object Name: Function UMG.WidgetBlueprintLibrary.GetInputEventFromPointerEvent
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FInputEvent GetInputEventFromPointerEvent(struct FPointerEvent& Event); // Offset: 0x1042b173c // Return & Params: Num(2) Size(0x88)

	// Object Name: Function UMG.WidgetBlueprintLibrary.GetInputEventFromNavigationEvent
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FInputEvent GetInputEventFromNavigationEvent(struct FNavigationEvent& Event); // Offset: 0x1042b1688 // Return & Params: Num(2) Size(0x38)

	// Object Name: Function UMG.WidgetBlueprintLibrary.GetInputEventFromKeyEvent
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FInputEvent GetInputEventFromKeyEvent(struct FKeyEvent& Event); // Offset: 0x1042b1b4c // Return & Params: Num(2) Size(0x50)

	// Object Name: Function UMG.WidgetBlueprintLibrary.GetInputEventFromCharacterEvent
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FInputEvent GetInputEventFromCharacterEvent(struct FCharacterEvent& Event); // Offset: 0x1042b1884 // Return & Params: Num(2) Size(0x38)

	// Object Name: Function UMG.WidgetBlueprintLibrary.GetDynamicMaterial
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct UMaterialInstanceDynamic* GetDynamicMaterial(struct FSlateBrush& Brush); // Offset: 0x1042b1f68 // Return & Params: Num(2) Size(0xa0)

	// Object Name: Function UMG.WidgetBlueprintLibrary.GetDragDroppingContent
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct UDragDropOperation* GetDragDroppingContent(); // Offset: 0x1042b3500 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.WidgetBlueprintLibrary.GetBrushResourceAsTexture2D
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct UTexture2D* GetBrushResourceAsTexture2D(struct FSlateBrush& Brush); // Offset: 0x1042b28e8 // Return & Params: Num(2) Size(0xa0)

	// Object Name: Function UMG.WidgetBlueprintLibrary.GetBrushResourceAsMaterial
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct UMaterialInterface* GetBrushResourceAsMaterial(struct FSlateBrush& Brush); // Offset: 0x1042b2734 // Return & Params: Num(2) Size(0xa0)

	// Object Name: Function UMG.WidgetBlueprintLibrary.GetBrushResource
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct UObject* GetBrushResource(struct FSlateBrush& Brush); // Offset: 0x1042b2a9c // Return & Params: Num(2) Size(0xa0)

	// Object Name: Function UMG.WidgetBlueprintLibrary.GetAllWidgetsWithInterface
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetAllWidgetsWithInterface(struct UObject* WorldContextObject, struct TArray<struct UUserWidget*>& FoundWidgets, struct UInterface* Interface, bool TopLevelOnly); // Offset: 0x1042b1c6c // Return & Params: Num(4) Size(0x21)

	// Object Name: Function UMG.WidgetBlueprintLibrary.GetAllWidgetsOfClass
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetAllWidgetsOfClass(struct UObject* WorldContextObject, struct TArray<struct UUserWidget*>& FoundWidgets, struct UUserWidget* WidgetClass, bool TopLevelOnly); // Offset: 0x1042b1de0 // Return & Params: Num(4) Size(0x21)

	// Object Name: Function UMG.WidgetBlueprintLibrary.EndDragDrop
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FEventReply EndDragDrop(struct FEventReply& Reply); // Offset: 0x1042b3568 // Return & Params: Num(2) Size(0x170)

	// Object Name: Function UMG.WidgetBlueprintLibrary.DrawTextFormatted
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void DrawTextFormatted(struct FPaintContext& Context, struct FText& Text, struct FVector2D Position, struct UFont* Font, int32_t FontSize, struct FName FontTypeFace, struct FLinearColor Tint); // Offset: 0x1042b4a04 // Return & Params: Num(7) Size(0x74)

	// Object Name: Function UMG.WidgetBlueprintLibrary.DrawText
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void DrawText(struct FPaintContext& Context, struct FString inString, struct FVector2D Position, struct FLinearColor Tint); // Offset: 0x1042b4cac // Return & Params: Num(4) Size(0x58)

	// Object Name: Function UMG.WidgetBlueprintLibrary.DrawLines
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void DrawLines(struct FPaintContext& Context, struct TArray<struct FVector2D>& Points, struct FLinearColor Tint, bool bAntiAlias, float Thickness); // Offset: 0x1042b4e10 // Return & Params: Num(5) Size(0x58)

	// Object Name: Function UMG.WidgetBlueprintLibrary.DrawLine
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void DrawLine(struct FPaintContext& Context, struct FVector2D PositionA, struct FVector2D PositionB, struct FLinearColor Tint, bool bAntiAlias, float Thickness); // Offset: 0x1042b4fe4 // Return & Params: Num(6) Size(0x58)

	// Object Name: Function UMG.WidgetBlueprintLibrary.DrawBox
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void DrawBox(struct FPaintContext& Context, struct FVector2D Position, struct FVector2D Size, struct USlateBrushAsset* Brush, struct FLinearColor Tint); // Offset: 0x1042b51f0 // Return & Params: Num(5) Size(0x58)

	// Object Name: Function UMG.WidgetBlueprintLibrary.DismissAllMenus
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void DismissAllMenus(); // Offset: 0x1042b1f54 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UMG.WidgetBlueprintLibrary.DetectDragIfPressed
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct FEventReply DetectDragIfPressed(struct FPointerEvent& PointerEvent, struct UWidget* WidgetDetectingDrag, struct FKey DragKey); // Offset: 0x1042b3688 // Return & Params: Num(4) Size(0x148)

	// Object Name: Function UMG.WidgetBlueprintLibrary.DetectDrag
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FEventReply DetectDrag(struct FEventReply& Reply, struct UWidget* WidgetDetectingDrag, struct FKey DragKey); // Offset: 0x1042b3980 // Return & Params: Num(4) Size(0x190)

	// Object Name: Function UMG.WidgetBlueprintLibrary.CreateDragDropOperation
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UDragDropOperation* CreateDragDropOperation(struct UDragDropOperation* OperationClass); // Offset: 0x1042b5910 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UMG.WidgetBlueprintLibrary.Create
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	struct UUserWidget* Create(struct UObject* WorldContextObject, struct UUserWidget* WidgetType, struct APlayerController* OwningPlayer); // Offset: 0x1042b5990 // Return & Params: Num(4) Size(0x20)

	// Object Name: Function UMG.WidgetBlueprintLibrary.ClearUserFocus
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FEventReply ClearUserFocus(struct FEventReply& Reply, bool bInAllUsers); // Offset: 0x1042b3eec // Return & Params: Num(3) Size(0x178)

	// Object Name: Function UMG.WidgetBlueprintLibrary.CaptureMouse
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FEventReply CaptureMouse(struct FEventReply& Reply, struct UWidget* CapturingWidget); // Offset: 0x1042b479c // Return & Params: Num(3) Size(0x178)

	// Object Name: Function UMG.WidgetBlueprintLibrary.CaptureJoystick
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FEventReply CaptureJoystick(struct FEventReply& Reply, struct UWidget* CapturingWidget, bool bInAllJoysticks); // Offset: 0x1042b4064 // Return & Params: Num(4) Size(0x180)

	// Object Name: Function UMG.WidgetBlueprintLibrary.CancelDragDrop
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void CancelDragDrop(); // Offset: 0x1042b34ec // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class UMG.WidgetInteractionComponent
// Size: 0x540 // Inherited bytes: 0x350
struct UWidgetInteractionComponent : USceneComponent {
	// Fields
	struct FMulticastInlineDelegate OnHoveredWidgetChanged; // Offset: 0x348 // Size: 0x10
	char pad_0x360[0x8]; // Offset: 0x360 // Size: 0x08
	int32_t VirtualUserIndex; // Offset: 0x368 // Size: 0x04
	float PointerIndex; // Offset: 0x36c // Size: 0x04
	enum class ECollisionChannel TraceChannel; // Offset: 0x370 // Size: 0x01
	char pad_0x371[0x3]; // Offset: 0x371 // Size: 0x03
	float InteractionDistance; // Offset: 0x374 // Size: 0x04
	enum class EWidgetInteractionSource InteractionSource; // Offset: 0x378 // Size: 0x01
	bool bEnableHitTesting; // Offset: 0x379 // Size: 0x01
	bool bShowDebug; // Offset: 0x37a // Size: 0x01
	char pad_0x37B[0x1]; // Offset: 0x37b // Size: 0x01
	struct FLinearColor DebugColor; // Offset: 0x37c // Size: 0x10
	char pad_0x38C[0x7c]; // Offset: 0x38c // Size: 0x7c
	struct FHitResult CustomHitResult; // Offset: 0x408 // Size: 0x88
	struct FVector2D LocalHitLocation; // Offset: 0x490 // Size: 0x08
	struct FVector2D LastLocalHitLocation; // Offset: 0x498 // Size: 0x08
	struct UWidgetComponent* HoveredWidgetComponent; // Offset: 0x4a0 // Size: 0x08
	struct FHitResult LastHitResult; // Offset: 0x4a8 // Size: 0x88
	bool bIsHoveredWidgetInteractable; // Offset: 0x530 // Size: 0x01
	bool bIsHoveredWidgetFocusable; // Offset: 0x531 // Size: 0x01
	bool bIsHoveredWidgetHitTestVisible; // Offset: 0x532 // Size: 0x01
	char pad_0x533[0xd]; // Offset: 0x533 // Size: 0x0d

	// Functions

	// Object Name: Function UMG.WidgetInteractionComponent.SetFocus
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetFocus(struct UWidget* FocusWidget); // Offset: 0x1042ba478 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.WidgetInteractionComponent.SetCustomHitResult
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetCustomHitResult(struct FHitResult& HitResult); // Offset: 0x1042ba4f8 // Return & Params: Num(1) Size(0x88)

	// Object Name: Function UMG.WidgetInteractionComponent.SendKeyChar
	// Flags: [Native|Public|BlueprintCallable]
	bool SendKeyChar(struct FString Characters, bool bRepeat); // Offset: 0x1042ba790 // Return & Params: Num(3) Size(0x12)

	// Object Name: Function UMG.WidgetInteractionComponent.ScrollWheel
	// Flags: [Native|Public|BlueprintCallable]
	void ScrollWheel(float ScrollDelta); // Offset: 0x1042ba708 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.WidgetInteractionComponent.ReleasePointerKey
	// Flags: [Native|Public|BlueprintCallable]
	void ReleasePointerKey(struct FKey Key); // Offset: 0x1042bad88 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function UMG.WidgetInteractionComponent.ReleaseKey
	// Flags: [Native|Public|BlueprintCallable]
	bool ReleaseKey(struct FKey Key); // Offset: 0x1042baa4c // Return & Params: Num(2) Size(0x19)

	// Object Name: Function UMG.WidgetInteractionComponent.PressPointerKey
	// Flags: [Native|Public|BlueprintCallable]
	void PressPointerKey(struct FKey Key); // Offset: 0x1042baeec // Return & Params: Num(1) Size(0x18)

	// Object Name: Function UMG.WidgetInteractionComponent.PressKey
	// Flags: [Native|Public|BlueprintCallable]
	bool PressKey(struct FKey Key, bool bRepeat); // Offset: 0x1042babc0 // Return & Params: Num(3) Size(0x1a)

	// Object Name: Function UMG.WidgetInteractionComponent.PressAndReleaseKey
	// Flags: [Native|Public|BlueprintCallable]
	bool PressAndReleaseKey(struct FKey Key); // Offset: 0x1042ba8d8 // Return & Params: Num(2) Size(0x19)

	// Object Name: Function UMG.WidgetInteractionComponent.IsOverInteractableWidget
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsOverInteractableWidget(); // Offset: 0x1042ba6a0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.WidgetInteractionComponent.IsOverHitTestVisibleWidget
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsOverHitTestVisibleWidget(); // Offset: 0x1042ba638 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.WidgetInteractionComponent.IsOverFocusableWidget
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsOverFocusableWidget(); // Offset: 0x1042ba66c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.WidgetInteractionComponent.GetLastHitResult
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FHitResult GetLastHitResult(); // Offset: 0x1042ba5d8 // Return & Params: Num(1) Size(0x88)

	// Object Name: Function UMG.WidgetInteractionComponent.GetHoveredWidgetComponent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UWidgetComponent* GetHoveredWidgetComponent(); // Offset: 0x1042ba6d4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.WidgetInteractionComponent.Get2DHitLocation
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FVector2D Get2DHitLocation(); // Offset: 0x1042ba5a0 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class UMG.WidgetLayoutLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct UWidgetLayoutLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function UMG.WidgetLayoutLibrary.SlotAsWrapBoxSlot
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct UWrapBoxSlot* SlotAsWrapBoxSlot(struct UWidget* Widget); // Offset: 0x1042bb840 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UMG.WidgetLayoutLibrary.SlotAsWidgetSwitcherSlot
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct UWidgetSwitcherSlot* SlotAsWidgetSwitcherSlot(struct UWidget* Widget); // Offset: 0x1042bb7c0 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UMG.WidgetLayoutLibrary.SlotAsVerticalBoxSlot
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct UVerticalBoxSlot* SlotAsVerticalBoxSlot(struct UWidget* Widget); // Offset: 0x1042bbac0 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UMG.WidgetLayoutLibrary.SlotAsUniformGridSlot
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct UUniformGridSlot* SlotAsUniformGridSlot(struct UWidget* Widget); // Offset: 0x1042bbb40 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UMG.WidgetLayoutLibrary.SlotAsSizeBoxSlot
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct USizeBoxSlot* SlotAsSizeBoxSlot(struct UWidget* Widget); // Offset: 0x1042bb8c0 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UMG.WidgetLayoutLibrary.SlotAsScrollBoxSlot
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct UScrollBoxSlot* SlotAsScrollBoxSlot(struct UWidget* Widget); // Offset: 0x1042bba40 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UMG.WidgetLayoutLibrary.SlotAsScaleBoxSlot
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct UScaleBoxSlot* SlotAsScaleBoxSlot(struct UWidget* Widget); // Offset: 0x1042bb940 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UMG.WidgetLayoutLibrary.SlotAsSafeBoxSlot
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct USafeZoneSlot* SlotAsSafeBoxSlot(struct UWidget* Widget); // Offset: 0x1042bb9c0 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UMG.WidgetLayoutLibrary.SlotAsOverlaySlot
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct UOverlaySlot* SlotAsOverlaySlot(struct UWidget* Widget); // Offset: 0x1042bbbc0 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UMG.WidgetLayoutLibrary.SlotAsHorizontalBoxSlot
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct UHorizontalBoxSlot* SlotAsHorizontalBoxSlot(struct UWidget* Widget); // Offset: 0x1042bbc40 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UMG.WidgetLayoutLibrary.SlotAsGridSlot
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct UGridSlot* SlotAsGridSlot(struct UWidget* Widget); // Offset: 0x1042bbcc0 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UMG.WidgetLayoutLibrary.SlotAsCanvasSlot
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct UCanvasPanelSlot* SlotAsCanvasSlot(struct UWidget* Widget); // Offset: 0x1042bbd40 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UMG.WidgetLayoutLibrary.SlotAsBorderSlot
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct UBorderSlot* SlotAsBorderSlot(struct UWidget* Widget); // Offset: 0x1042bbdc0 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UMG.WidgetLayoutLibrary.RemoveAllWidgets
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void RemoveAllWidgets(struct UObject* WorldContextObject); // Offset: 0x1042bb748 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.WidgetLayoutLibrary.ProjectWorldLocationToWidgetPosition
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	bool ProjectWorldLocationToWidgetPosition(struct APlayerController* PlayerController, struct FVector WorldLocation, struct FVector2D& ScreenPosition, bool bPlayerViewportRelative); // Offset: 0x1042bc254 // Return & Params: Num(5) Size(0x1e)

	// Object Name: Function UMG.WidgetLayoutLibrary.GetViewportWidgetGeometry
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FGeometry GetViewportWidgetGeometry(struct UObject* WorldContextObject); // Offset: 0x1042bc0c4 // Return & Params: Num(2) Size(0x40)

	// Object Name: Function UMG.WidgetLayoutLibrary.GetViewportSize
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	struct FVector2D GetViewportSize(struct UObject* WorldContextObject); // Offset: 0x1042bc150 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UMG.WidgetLayoutLibrary.GetViewportScale
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable|BlueprintPure]
	float GetViewportScale(struct UObject* WorldContextObject); // Offset: 0x1042bc1d4 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function UMG.WidgetLayoutLibrary.GetPlayerScreenWidgetGeometry
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FGeometry GetPlayerScreenWidgetGeometry(struct APlayerController* PlayerController); // Offset: 0x1042bc038 // Return & Params: Num(2) Size(0x40)

	// Object Name: Function UMG.WidgetLayoutLibrary.GetMousePositionScaledByDPI
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	bool GetMousePositionScaledByDPI(struct APlayerController* Player, float& LocationX, float& LocationY); // Offset: 0x1042bbe40 // Return & Params: Num(4) Size(0x11)

	// Object Name: Function UMG.WidgetLayoutLibrary.GetMousePositionOnViewport
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	struct FVector2D GetMousePositionOnViewport(struct UObject* WorldContextObject); // Offset: 0x1042bbf7c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UMG.WidgetLayoutLibrary.GetMousePositionOnPlatform
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	struct FVector2D GetMousePositionOnPlatform(); // Offset: 0x1042bc000 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class UMG.WidgetNavigation
// Size: 0x100 // Inherited bytes: 0x28
struct UWidgetNavigation : UObject {
	// Fields
	struct FWidgetNavigationData Up; // Offset: 0x28 // Size: 0x24
	struct FWidgetNavigationData Down; // Offset: 0x4c // Size: 0x24
	struct FWidgetNavigationData Left; // Offset: 0x70 // Size: 0x24
	struct FWidgetNavigationData Right; // Offset: 0x94 // Size: 0x24
	struct FWidgetNavigationData Next; // Offset: 0xb8 // Size: 0x24
	struct FWidgetNavigationData Previous; // Offset: 0xdc // Size: 0x24
};

// Object Name: Class UMG.WidgetSwitcherSlot
// Size: 0x58 // Inherited bytes: 0x38
struct UWidgetSwitcherSlot : UPanelSlot {
	// Fields
	char pad_0x38[0x8]; // Offset: 0x38 // Size: 0x08
	struct FMargin Padding; // Offset: 0x40 // Size: 0x10
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0x50 // Size: 0x01
	enum class EVerticalAlignment VerticalAlignment; // Offset: 0x51 // Size: 0x01
	char pad_0x52[0x6]; // Offset: 0x52 // Size: 0x06

	// Functions

	// Object Name: Function UMG.WidgetSwitcherSlot.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment); // Offset: 0x1042bd7fc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.WidgetSwitcherSlot.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPadding(struct FMargin InPadding); // Offset: 0x1042bd8fc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.WidgetSwitcherSlot.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment); // Offset: 0x1042bd87c // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.WidgetTree
// Size: 0x30 // Inherited bytes: 0x28
struct UWidgetTree : UObject {
	// Fields
	struct UWidget* RootWidget; // Offset: 0x28 // Size: 0x08
};

// Object Name: Class UMG.WindowTitleBarArea
// Size: 0x168 // Inherited bytes: 0x150
struct UWindowTitleBarArea : UContentWidget {
	// Fields
	bool bWindowButtonsEnabled; // Offset: 0x149 // Size: 0x01
	bool bDoubleClickTogglesFullscreen; // Offset: 0x14a // Size: 0x01
	char pad_0x152[0x16]; // Offset: 0x152 // Size: 0x16

	// Functions

	// Object Name: Function UMG.WindowTitleBarArea.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment); // Offset: 0x1042be04c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.WindowTitleBarArea.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPadding(struct FMargin InPadding); // Offset: 0x1042be14c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.WindowTitleBarArea.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment); // Offset: 0x1042be0cc // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.WindowTitleBarAreaSlot
// Size: 0x60 // Inherited bytes: 0x38
struct UWindowTitleBarAreaSlot : UPanelSlot {
	// Fields
	struct FMargin Padding; // Offset: 0x38 // Size: 0x10
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0x48 // Size: 0x01
	enum class EVerticalAlignment VerticalAlignment; // Offset: 0x49 // Size: 0x01
	char pad_0x4A[0x16]; // Offset: 0x4a // Size: 0x16

	// Functions

	// Object Name: Function UMG.WindowTitleBarAreaSlot.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment); // Offset: 0x1042be4a0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.WindowTitleBarAreaSlot.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPadding(struct FMargin InPadding); // Offset: 0x1042be5a0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.WindowTitleBarAreaSlot.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment); // Offset: 0x1042be520 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class UMG.WrapBox
// Size: 0x170 // Inherited bytes: 0x150
struct UWrapBox : UPanelWidget {
	// Fields
	struct FVector2D InnerSlotPadding; // Offset: 0x14c // Size: 0x08
	float WrapWidth; // Offset: 0x154 // Size: 0x04
	bool bExplicitWrapWidth; // Offset: 0x158 // Size: 0x01
	char pad_0x15D[0x13]; // Offset: 0x15d // Size: 0x13

	// Functions

	// Object Name: Function UMG.WrapBox.SetInnerSlotPadding
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetInnerSlotPadding(struct FVector2D InPadding); // Offset: 0x1042bea28 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UMG.WrapBox.AddChildToWrapBox
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UWrapBoxSlot* AddChildToWrapBox(struct UWidget* Content); // Offset: 0x1042be998 // Return & Params: Num(2) Size(0x10)
};

// Object Name: Class UMG.WrapBoxSlot
// Size: 0x60 // Inherited bytes: 0x38
struct UWrapBoxSlot : UPanelSlot {
	// Fields
	struct FMargin Padding; // Offset: 0x38 // Size: 0x10
	bool bFillEmptySpace; // Offset: 0x48 // Size: 0x01
	char pad_0x49[0x3]; // Offset: 0x49 // Size: 0x03
	float FillSpanWhenLessThan; // Offset: 0x4c // Size: 0x04
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0x50 // Size: 0x01
	enum class EVerticalAlignment VerticalAlignment; // Offset: 0x51 // Size: 0x01
	char pad_0x52[0xe]; // Offset: 0x52 // Size: 0x0e

	// Functions

	// Object Name: Function UMG.WrapBoxSlot.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment); // Offset: 0x1042bed1c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.WrapBoxSlot.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPadding(struct FMargin InPadding); // Offset: 0x1042bef24 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UMG.WrapBoxSlot.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment); // Offset: 0x1042bed9c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UMG.WrapBoxSlot.SetFillSpanWhenLessThan
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetFillSpanWhenLessThan(float InFillSpanWhenLessThan); // Offset: 0x1042bee1c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UMG.WrapBoxSlot.SetFillEmptySpace
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetFillEmptySpace(bool InbFillEmptySpace); // Offset: 0x1042bee9c // Return & Params: Num(1) Size(0x1)
};

