#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass WAT_9A08.WAT_9A08_C
// Size: 0xf0 // Inherited bytes: 0xf0
struct UWAT_9A08_C : USolarWeaponAT_FireBurst {
};

