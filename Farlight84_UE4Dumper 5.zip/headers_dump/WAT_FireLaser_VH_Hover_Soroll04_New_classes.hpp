#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass WAT_FireLaser_VH_Hover_Soroll04_New.WAT_FireLaser_VH_Hover_Soroll04_New_C
// Size: 0x238 // Inherited bytes: 0x230
struct UWAT_FireLaser_VH_Hover_Soroll04_New_C : USolarWeaponAT_FireLaser {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x230 // Size: 0x08

	// Functions

	// Object Name: Function WAT_FireLaser_VH_Hover_Soroll04_New.WAT_FireLaser_VH_Hover_Soroll04_New_C.K2_ActivateRealFire
	// Flags: [Event|Public|BlueprintEvent]
	void K2_ActivateRealFire(); // Offset: 0x1032a8510 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function WAT_FireLaser_VH_Hover_Soroll04_New.WAT_FireLaser_VH_Hover_Soroll04_New_C.ExecuteUbergraph_WAT_FireLaser_VH_Hover_Soroll04_New
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_WAT_FireLaser_VH_Hover_Soroll04_New(int32_t EntryPoint); // Offset: 0x1032a8510 // Return & Params: Num(1) Size(0x4)
};

