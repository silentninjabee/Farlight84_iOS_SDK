#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass AEBP_InSmokeBase.AEBP_InSmokeBase_C
// Inherited Bytes: 0x1c8 | Struct Size: 0x1c8
struct UAEBP_InSmokeBase_C : UMultiplePassMaterialEffect {
};

