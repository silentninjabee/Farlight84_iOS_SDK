#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass AEBP_ThunderFlash_Holding_MaterialEffect_Ghost.AEBP_ThunderFlash_Holding_MaterialEffect_Ghost_C
// Inherited Bytes: 0x160 | Struct Size: 0x160
struct UAEBP_ThunderFlash_Holding_MaterialEffect_Ghost_C : UMaterialEffectBase {
};

