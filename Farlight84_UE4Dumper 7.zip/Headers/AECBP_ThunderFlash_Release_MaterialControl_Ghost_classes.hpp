#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass AECBP_ThunderFlash_Release_MaterialControl_Ghost.AECBP_ThunderFlash_Release_MaterialControl_Ghost_C
// Inherited Bytes: 0x40 | Struct Size: 0x40
struct UAECBP_ThunderFlash_Release_MaterialControl_Ghost_C : UCharacterMeshMaterialEffectController {
};

