#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class AIModule.BTNode
// Inherited Bytes: 0x28 | Struct Size: 0x58
struct UBTNode : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
	struct FString NodeName; // Offset: 0x30 | Size: 0x10
	struct UBehaviorTree* TreeAsset; // Offset: 0x40 | Size: 0x8
	struct UBTCompositeNode* ParentNode; // Offset: 0x48 | Size: 0x8
	char pad_0x50[0x8]; // Offset: 0x50 | Size: 0x8
};

// Object: Class AIModule.BTAuxiliaryNode
// Inherited Bytes: 0x58 | Struct Size: 0x58
struct UBTAuxiliaryNode : UBTNode {
};

// Object: Class AIModule.BTDecorator
// Inherited Bytes: 0x58 | Struct Size: 0x60
struct UBTDecorator : UBTAuxiliaryNode {
	// Fields
	char pad_0x58_0 : 7; // Offset: 0x58 | Size: 0x1
	char bInverseCondition : 1; // Offset: 0x58 | Size: 0x1
	enum class EBTFlowAbortMode FlowAbortMode; // Offset: 0x59 | Size: 0x1
	char pad_0x5A[0x6]; // Offset: 0x5a | Size: 0x6
};

// Object: Class AIModule.BTDecorator_BlackboardBase
// Inherited Bytes: 0x60 | Struct Size: 0x88
struct UBTDecorator_BlackboardBase : UBTDecorator {
	// Fields
	struct FBlackboardKeySelector BlackboardKey; // Offset: 0x60 | Size: 0x28
};

// Object: Class AIModule.BTDecorator_Blackboard
// Inherited Bytes: 0x88 | Struct Size: 0xb8
struct UBTDecorator_Blackboard : UBTDecorator_BlackboardBase {
	// Fields
	int32_t IntValue; // Offset: 0x88 | Size: 0x4
	float FloatValue; // Offset: 0x8c | Size: 0x4
	struct FString StringValue; // Offset: 0x90 | Size: 0x10
	struct FString CachedDescription; // Offset: 0xa0 | Size: 0x10
	char OperationType; // Offset: 0xb0 | Size: 0x1
	enum class EBTBlackboardRestart NotifyObserver; // Offset: 0xb1 | Size: 0x1
	char pad_0xB2[0x6]; // Offset: 0xb2 | Size: 0x6
};

// Object: Class AIModule.BTDecorator_TimeLimit
// Inherited Bytes: 0x60 | Struct Size: 0x60
struct UBTDecorator_TimeLimit : UBTDecorator {
	// Fields
	float timeLimit; // Offset: 0x5c | Size: 0x4
};

// Object: Class AIModule.AIController
// Inherited Bytes: 0x2b8 | Struct Size: 0x348
struct AAIController : AController {
	// Fields
	char pad_0x2B8[0x38]; // Offset: 0x2b8 | Size: 0x38
	char bStartAILogicOnPossess : 1; // Offset: 0x2f0 | Size: 0x1
	char bStopAILogicOnUnposses : 1; // Offset: 0x2f0 | Size: 0x1
	char bLOSflag : 1; // Offset: 0x2f0 | Size: 0x1
	char bSkipExtraLOSChecks : 1; // Offset: 0x2f0 | Size: 0x1
	char bAllowStrafe : 1; // Offset: 0x2f0 | Size: 0x1
	char bWantsPlayerState : 1; // Offset: 0x2f0 | Size: 0x1
	char bSetControlRotationFromPawnOrientation : 1; // Offset: 0x2f0 | Size: 0x1
	char pad_0x2F0_7 : 1; // Offset: 0x2f0 | Size: 0x1
	char pad_0x2F1[0x7]; // Offset: 0x2f1 | Size: 0x7
	struct UPathFollowingComponent* PathFollowingComponent; // Offset: 0x2f8 | Size: 0x8
	struct UBrainComponent* BrainComponent; // Offset: 0x300 | Size: 0x8
	struct UAIPerceptionComponent* PerceptionComponent; // Offset: 0x308 | Size: 0x8
	struct UPawnActionsComponent* ActionsComp; // Offset: 0x310 | Size: 0x8
	struct UBlackboardComponent* Blackboard; // Offset: 0x318 | Size: 0x8
	struct UGameplayTasksComponent* CachedGameplayTasksComponent; // Offset: 0x320 | Size: 0x8
	struct UNavigationQueryFilter* DefaultNavigationFilterClass; // Offset: 0x328 | Size: 0x8
	struct FMulticastInlineDelegate ReceiveMoveCompleted; // Offset: 0x330 | Size: 0x10
	char pad_0x340[0x8]; // Offset: 0x340 | Size: 0x8

	// Functions

	// Object: Function AIModule.AIController.UseBlackboard
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105cd273c
	// Return & Params: [ Num(3) Size(0x11) ]
	bool UseBlackboard(struct UBlackboardData* BlackboardAsset, struct UBlackboardComponent*& BlackboardComponent);

	// Object: Function AIModule.AIController.UnclaimTaskResource
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105cd263c
	// Return & Params: [ Num(1) Size(0x8) ]
	void UnclaimTaskResource(struct UGameplayTaskResource* ResourceClass);

	// Object: Function AIModule.AIController.SetPathFollowingComponent
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105cd2294
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetPathFollowingComponent(struct UPathFollowingComponent* NewPFComponent);

	// Object: Function AIModule.AIController.SetMoveBlockDetection
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105cd28bc
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetMoveBlockDetection(bool bEnable);

	// Object: Function AIModule.AIController.RunBehaviorTree
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x105cd2824
	// Return & Params: [ Num(2) Size(0x9) ]
	bool RunBehaviorTree(struct UBehaviorTree* BTAsset);

	// Object: Function AIModule.AIController.OnUsingBlackBoard
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(2) Size(0x10) ]
	void OnUsingBlackBoard(struct UBlackboardComponent* BlackboardComp, struct UBlackboardData* BlackboardAsset);

	// Object: Function AIModule.AIController.OnGameplayTaskResourcesClaimed
	// Flags: [Native|Public]
	// Offset: 0x105cd234c
	// Return & Params: [ Num(2) Size(0x4) ]
	void OnGameplayTaskResourcesClaimed(struct FGameplayResourceSet NewlyClaimed, struct FGameplayResourceSet FreshlyReleased);

	// Object: Function AIModule.AIController.MoveToLocation
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x105cd29e4
	// Return & Params: [ Num(9) Size(0x22) ]
	enum class EPathFollowingRequestResult MoveToLocation(struct FVector& Dest, float AcceptanceRadius, bool bStopOnOverlap, bool bUsePathfinding, bool bProjectDestinationToNavigation, bool bCanStrafe, struct UNavigationQueryFilter* FilterClass, bool bAllowPartialPath);

	// Object: Function AIModule.AIController.MoveToActor
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105cd2cdc
	// Return & Params: [ Num(8) Size(0x1a) ]
	enum class EPathFollowingRequestResult MoveToActor(struct AActor* Goal, float AcceptanceRadius, bool bStopOnOverlap, bool bUsePathfinding, bool bCanStrafe, struct UNavigationQueryFilter* FilterClass, bool bAllowPartialPath);

	// Object: Function AIModule.AIController.K2_SetFocus
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105cd2468
	// Return & Params: [ Num(1) Size(0x8) ]
	void K2_SetFocus(struct AActor* NewFocus);

	// Object: Function AIModule.AIController.K2_SetFocalPoint
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x105cd24e8
	// Return & Params: [ Num(1) Size(0xc) ]
	void K2_SetFocalPoint(struct FVector FP);

	// Object: Function AIModule.AIController.K2_ClearFocus
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105cd2420
	// Return & Params: [ Num(0) Size(0x0) ]
	void K2_ClearFocus();

	// Object: Function AIModule.AIController.HasPartialPath
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105cd297c
	// Return & Params: [ Num(1) Size(0x1) ]
	bool HasPartialPath();

	// Object: Function AIModule.AIController.GetPathFollowingComponent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105cd2330
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UPathFollowingComponent* GetPathFollowingComponent();

	// Object: Function AIModule.AIController.GetMoveStatus
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105cd29b0
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class EPathFollowingStatus GetMoveStatus();

	// Object: Function AIModule.AIController.GetImmediateMoveDestination
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105cd2944
	// Return & Params: [ Num(1) Size(0xc) ]
	struct FVector GetImmediateMoveDestination();

	// Object: Function AIModule.AIController.GetFocusActor
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105cd2434
	// Return & Params: [ Num(1) Size(0x8) ]
	struct AActor* GetFocusActor();

	// Object: Function AIModule.AIController.GetFocalPointOnActor
	// Flags: [Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105cd2568
	// Return & Params: [ Num(2) Size(0x14) ]
	struct FVector GetFocalPointOnActor(struct AActor* Actor);

	// Object: Function AIModule.AIController.GetFocalPoint
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105cd2604
	// Return & Params: [ Num(1) Size(0xc) ]
	struct FVector GetFocalPoint();

	// Object: Function AIModule.AIController.GetAIPerceptionComponent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x105cd2314
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UAIPerceptionComponent* GetAIPerceptionComponent();

	// Object: Function AIModule.AIController.ClaimTaskResource
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105cd26bc
	// Return & Params: [ Num(1) Size(0x8) ]
	void ClaimTaskResource(struct UGameplayTaskResource* ResourceClass);
};

// Object: Class AIModule.AISense
// Inherited Bytes: 0x28 | Struct Size: 0x78
struct UAISense : UObject {
	// Fields
	float DefaultExpirationAge; // Offset: 0x28 | Size: 0x4
	enum class EAISenseNotifyType NotifyType; // Offset: 0x2c | Size: 0x1
	char bWantsNewPawnNotification : 1; // Offset: 0x2d | Size: 0x1
	char bAutoRegisterAllPawnsAsSources : 1; // Offset: 0x2d | Size: 0x1
	char pad_0x2D_2 : 6; // Offset: 0x2d | Size: 0x1
	char pad_0x2E[0x2]; // Offset: 0x2e | Size: 0x2
	struct UAIPerceptionSystem* PerceptionSystemInstance; // Offset: 0x30 | Size: 0x8
	char pad_0x38[0x40]; // Offset: 0x38 | Size: 0x40
};

// Object: Class AIModule.AISenseConfig
// Inherited Bytes: 0x28 | Struct Size: 0x48
struct UAISenseConfig : UObject {
	// Fields
	struct FColor DebugColor; // Offset: 0x28 | Size: 0x4
	float MaxAge; // Offset: 0x2c | Size: 0x4
	char bStartsEnabled : 1; // Offset: 0x30 | Size: 0x1
	char pad_0x30_1 : 7; // Offset: 0x30 | Size: 0x1
	char pad_0x31[0x17]; // Offset: 0x31 | Size: 0x17
};

// Object: Class AIModule.BTCompositeNode
// Inherited Bytes: 0x58 | Struct Size: 0x90
struct UBTCompositeNode : UBTNode {
	// Fields
	struct TArray<struct FBTCompositeChild> Children; // Offset: 0x58 | Size: 0x10
	struct TArray<struct UBTService*> Services; // Offset: 0x68 | Size: 0x10
	char pad_0x78[0x10]; // Offset: 0x78 | Size: 0x10
	char bApplyDecoratorScope : 1; // Offset: 0x88 | Size: 0x1
	char pad_0x88_1 : 7; // Offset: 0x88 | Size: 0x1
	char pad_0x89[0x7]; // Offset: 0x89 | Size: 0x7
};

// Object: Class AIModule.BTService
// Inherited Bytes: 0x58 | Struct Size: 0x68
struct UBTService : UBTAuxiliaryNode {
	// Fields
	float Interval; // Offset: 0x58 | Size: 0x4
	float RandomDeviation; // Offset: 0x5c | Size: 0x4
	char bCallTickOnSearchStart : 1; // Offset: 0x60 | Size: 0x1
	char bRestartTimerOnEachActivation : 1; // Offset: 0x60 | Size: 0x1
	char pad_0x60_2 : 6; // Offset: 0x60 | Size: 0x1
	char pad_0x61[0x7]; // Offset: 0x61 | Size: 0x7
};

// Object: Class AIModule.BTService_BlackboardBase
// Inherited Bytes: 0x68 | Struct Size: 0x90
struct UBTService_BlackboardBase : UBTService {
	// Fields
	struct FBlackboardKeySelector BlackboardKey; // Offset: 0x68 | Size: 0x28
};

// Object: Class AIModule.BTService_BlueprintBase
// Inherited Bytes: 0x68 | Struct Size: 0x90
struct UBTService_BlueprintBase : UBTService {
	// Fields
	struct AAIController* AIOwner; // Offset: 0x68 | Size: 0x8
	struct AActor* ActorOwner; // Offset: 0x70 | Size: 0x8
	char pad_0x78[0x10]; // Offset: 0x78 | Size: 0x10
	char bShowPropertyDetails : 1; // Offset: 0x88 | Size: 0x1
	char bShowEventDetails : 1; // Offset: 0x88 | Size: 0x1
	char pad_0x88_2 : 6; // Offset: 0x88 | Size: 0x1
	char pad_0x89[0x7]; // Offset: 0x89 | Size: 0x7

	// Functions

	// Object: Function AIModule.BTService_BlueprintBase.ReceiveTickAI
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(3) Size(0x14) ]
	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds);

	// Object: Function AIModule.BTService_BlueprintBase.ReceiveTick
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(2) Size(0xc) ]
	void ReceiveTick(struct AActor* OwnerActor, float DeltaSeconds);

	// Object: Function AIModule.BTService_BlueprintBase.ReceiveSearchStartAI
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(2) Size(0x10) ]
	void ReceiveSearchStartAI(struct AAIController* OwnerController, struct APawn* ControlledPawn);

	// Object: Function AIModule.BTService_BlueprintBase.ReceiveSearchStart
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x8) ]
	void ReceiveSearchStart(struct AActor* OwnerActor);

	// Object: Function AIModule.BTService_BlueprintBase.ReceiveDeactivationAI
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(2) Size(0x10) ]
	void ReceiveDeactivationAI(struct AAIController* OwnerController, struct APawn* ControlledPawn);

	// Object: Function AIModule.BTService_BlueprintBase.ReceiveDeactivation
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x8) ]
	void ReceiveDeactivation(struct AActor* OwnerActor);

	// Object: Function AIModule.BTService_BlueprintBase.ReceiveActivationAI
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(2) Size(0x10) ]
	void ReceiveActivationAI(struct AAIController* OwnerController, struct APawn* ControlledPawn);

	// Object: Function AIModule.BTService_BlueprintBase.ReceiveActivation
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x8) ]
	void ReceiveActivation(struct AActor* OwnerActor);

	// Object: Function AIModule.BTService_BlueprintBase.IsServiceActive
	// Flags: [Final|Native|Protected|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105cf02c0
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsServiceActive();
};

// Object: Class AIModule.BTTaskNode
// Inherited Bytes: 0x58 | Struct Size: 0x70
struct UBTTaskNode : UBTNode {
	// Fields
	struct TArray<struct UBTService*> Services; // Offset: 0x58 | Size: 0x10
	char bIgnoreRestartSelf : 1; // Offset: 0x68 | Size: 0x1
	char pad_0x68_1 : 7; // Offset: 0x68 | Size: 0x1
	char pad_0x69[0x7]; // Offset: 0x69 | Size: 0x7
};

// Object: Class AIModule.BTTask_BlackboardBase
// Inherited Bytes: 0x70 | Struct Size: 0x98
struct UBTTask_BlackboardBase : UBTTaskNode {
	// Fields
	struct FBlackboardKeySelector BlackboardKey; // Offset: 0x70 | Size: 0x28
};

// Object: Class AIModule.BTTask_MoveTo
// Inherited Bytes: 0x98 | Struct Size: 0xb0
struct UBTTask_MoveTo : UBTTask_BlackboardBase {
	// Fields
	float AcceptableRadius; // Offset: 0x98 | Size: 0x4
	char pad_0x9C[0x4]; // Offset: 0x9c | Size: 0x4
	struct UNavigationQueryFilter* FilterClass; // Offset: 0xa0 | Size: 0x8
	float ObservedBlackboardValueTolerance; // Offset: 0xa8 | Size: 0x4
	char bObserveBlackboardValue : 1; // Offset: 0xac | Size: 0x1
	char bAllowStrafe : 1; // Offset: 0xac | Size: 0x1
	char bAllowPartialPath : 1; // Offset: 0xac | Size: 0x1
	char bTrackMovingGoal : 1; // Offset: 0xac | Size: 0x1
	char bProjectGoalLocation : 1; // Offset: 0xac | Size: 0x1
	char bReachTestIncludesAgentRadius : 1; // Offset: 0xac | Size: 0x1
	char bReachTestIncludesGoalRadius : 1; // Offset: 0xac | Size: 0x1
	char bStopOnOverlap : 1; // Offset: 0xac | Size: 0x1
	char bStopOnOverlapNeedsUpdate : 1; // Offset: 0xad | Size: 0x1
	char pad_0xAD_1 : 7; // Offset: 0xad | Size: 0x1
	char pad_0xAE[0x2]; // Offset: 0xae | Size: 0x2
};

// Object: Class AIModule.BTTask_RunBehaviorDynamic
// Inherited Bytes: 0x70 | Struct Size: 0x88
struct UBTTask_RunBehaviorDynamic : UBTTaskNode {
	// Fields
	struct FGameplayTag InjectionTag; // Offset: 0x6c | Size: 0x8
	struct UBehaviorTree* DefaultBehaviorAsset; // Offset: 0x78 | Size: 0x8
	struct UBehaviorTree* BehaviorAsset; // Offset: 0x80 | Size: 0x8
};

// Object: Class AIModule.EnvQueryContext
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UEnvQueryContext : UObject {
};

// Object: Class AIModule.EnvQueryNode
// Inherited Bytes: 0x28 | Struct Size: 0x30
struct UEnvQueryNode : UObject {
	// Fields
	int32_t VerNum; // Offset: 0x28 | Size: 0x4
	char pad_0x2C[0x4]; // Offset: 0x2c | Size: 0x4
};

// Object: Class AIModule.EnvQueryTest
// Inherited Bytes: 0x30 | Struct Size: 0x1f8
struct UEnvQueryTest : UEnvQueryNode {
	// Fields
	int32_t TestOrder; // Offset: 0x2c | Size: 0x4
	enum class EEnvTestPurpose TestPurpose; // Offset: 0x30 | Size: 0x1
	char pad_0x35[0x3]; // Offset: 0x35 | Size: 0x3
	struct FString TestComment; // Offset: 0x38 | Size: 0x10
	enum class EEnvTestFilterOperator MultipleContextFilterOp; // Offset: 0x48 | Size: 0x1
	enum class EEnvTestScoreOperator MultipleContextScoreOp; // Offset: 0x49 | Size: 0x1
	enum class EEnvTestFilterType FilterType; // Offset: 0x4a | Size: 0x1
	char pad_0x4B[0x5]; // Offset: 0x4b | Size: 0x5
	struct FAIDataProviderBoolValue BoolValue; // Offset: 0x50 | Size: 0x38
	struct FAIDataProviderFloatValue FloatValueMin; // Offset: 0x88 | Size: 0x38
	struct FAIDataProviderFloatValue FloatValueMax; // Offset: 0xc0 | Size: 0x38
	char pad_0xF8[0x1]; // Offset: 0xf8 | Size: 0x1
	enum class EEnvTestScoreEquation ScoringEquation; // Offset: 0xf9 | Size: 0x1
	enum class EEnvQueryTestClamping ClampMinType; // Offset: 0xfa | Size: 0x1
	enum class EEnvQueryTestClamping ClampMaxType; // Offset: 0xfb | Size: 0x1
	enum class EEQSNormalizationType NormalizationType; // Offset: 0xfc | Size: 0x1
	char pad_0xFD[0x3]; // Offset: 0xfd | Size: 0x3
	struct FAIDataProviderFloatValue ScoreClampMin; // Offset: 0x100 | Size: 0x38
	struct FAIDataProviderFloatValue ScoreClampMax; // Offset: 0x138 | Size: 0x38
	struct FAIDataProviderFloatValue ScoringFactor; // Offset: 0x170 | Size: 0x38
	struct FAIDataProviderFloatValue ReferenceValue; // Offset: 0x1a8 | Size: 0x38
	bool bDefineReferenceValue; // Offset: 0x1e0 | Size: 0x1
	char pad_0x1E1[0xf]; // Offset: 0x1e1 | Size: 0xf
	char bWorkOnFloatValues : 1; // Offset: 0x1f0 | Size: 0x1
	char pad_0x1F0_1 : 7; // Offset: 0x1f0 | Size: 0x1
	char pad_0x1F1[0x7]; // Offset: 0x1f1 | Size: 0x7
};

// Object: Class AIModule.EnvQueryTest_Pathfinding
// Inherited Bytes: 0x1f8 | Struct Size: 0x278
struct UEnvQueryTest_Pathfinding : UEnvQueryTest {
	// Fields
	enum class EEnvTestPathfinding TestMode; // Offset: 0x1f1 | Size: 0x1
	struct UEnvQueryContext* Context; // Offset: 0x1f8 | Size: 0x8
	struct FAIDataProviderBoolValue PathFromContext; // Offset: 0x200 | Size: 0x38
	struct FAIDataProviderBoolValue SkipUnreachable; // Offset: 0x238 | Size: 0x38
	struct UNavigationQueryFilter* FilterClass; // Offset: 0x270 | Size: 0x8
};

// Object: Class AIModule.EnvQueryTest_Trace
// Inherited Bytes: 0x1f8 | Struct Size: 0x2d8
struct UEnvQueryTest_Trace : UEnvQueryTest {
	// Fields
	struct FEnvTraceData TraceData; // Offset: 0x1f8 | Size: 0x30
	struct FAIDataProviderBoolValue TraceFromContext; // Offset: 0x228 | Size: 0x38
	struct FAIDataProviderFloatValue ItemHeightOffset; // Offset: 0x260 | Size: 0x38
	struct FAIDataProviderFloatValue ContextHeightOffset; // Offset: 0x298 | Size: 0x38
	struct UEnvQueryContext* Context; // Offset: 0x2d0 | Size: 0x8
};

// Object: Class AIModule.PathFollowingComponent
// Inherited Bytes: 0xb0 | Struct Size: 0x260
struct UPathFollowingComponent : UActorComponent {
	// Fields
	char pad_0xB0[0x38]; // Offset: 0xb0 | Size: 0x38
	struct UNavMovementComponent* MovementComp; // Offset: 0xe8 | Size: 0x8
	char pad_0xF0[0x10]; // Offset: 0xf0 | Size: 0x10
	struct ANavigationData* MyNavData; // Offset: 0x100 | Size: 0x8
	char pad_0x108[0x158]; // Offset: 0x108 | Size: 0x158

	// Functions

	// Object: Function AIModule.PathFollowingComponent.OnNavDataRegistered
	// Flags: [Final|Native|Protected]
	// Offset: 0x105d055e0
	// Return & Params: [ Num(1) Size(0x8) ]
	void OnNavDataRegistered(struct ANavigationData* NavData);

	// Object: Function AIModule.PathFollowingComponent.OnActorBump
	// Flags: [Native|Public|HasOutParms|HasDefaults]
	// Offset: 0x105d056cc
	// Return & Params: [ Num(4) Size(0xa4) ]
	void OnActorBump(struct AActor* SelfActor, struct AActor* OtherActor, struct FVector NormalImpulse, struct FHitResult& Hit);

	// Object: Function AIModule.PathFollowingComponent.GetPathDestination
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105d05660
	// Return & Params: [ Num(1) Size(0xc) ]
	struct FVector GetPathDestination();

	// Object: Function AIModule.PathFollowingComponent.GetPathActionType
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105d05698
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class EPathFollowingAction GetPathActionType();
};

// Object: Class AIModule.CrowdFollowingComponent
// Inherited Bytes: 0x260 | Struct Size: 0x2a0
struct UCrowdFollowingComponent : UPathFollowingComponent {
	// Fields
	char pad_0x260[0x8]; // Offset: 0x260 | Size: 0x8
	struct UCharacterMovementComponent* CharacterMovement; // Offset: 0x268 | Size: 0x8
	struct FVector CrowdAgentMoveDirection; // Offset: 0x270 | Size: 0xc
	char pad_0x27C[0x24]; // Offset: 0x27c | Size: 0x24

	// Functions

	// Object: Function AIModule.CrowdFollowingComponent.SuspendCrowdSteering
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x105cf5378
	// Return & Params: [ Num(1) Size(0x1) ]
	void SuspendCrowdSteering(bool bSuspend);
};

// Object: Class AIModule.NavLinkProxy
// Inherited Bytes: 0x228 | Struct Size: 0x278
struct ANavLinkProxy : AActor {
	// Fields
	char pad_0x228[0x10]; // Offset: 0x228 | Size: 0x10
	struct TArray<struct FNavigationLink> PointLinks; // Offset: 0x238 | Size: 0x10
	struct TArray<struct FNavigationSegmentLink> SegmentLinks; // Offset: 0x248 | Size: 0x10
	struct UNavLinkCustomComponent* SmartLinkComp; // Offset: 0x258 | Size: 0x8
	bool bSmartLinkIsRelevant; // Offset: 0x260 | Size: 0x1
	char pad_0x261[0x7]; // Offset: 0x261 | Size: 0x7
	struct FMulticastInlineDelegate OnSmartLinkReached; // Offset: 0x268 | Size: 0x10

	// Functions

	// Object: Function AIModule.NavLinkProxy.SetSmartLinkEnabled
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d03d78
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetSmartLinkEnabled(bool bEnabled);

	// Object: Function AIModule.NavLinkProxy.ResumePathFollowing
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d03e34
	// Return & Params: [ Num(1) Size(0x8) ]
	void ResumePathFollowing(struct AActor* Agent);

	// Object: Function AIModule.NavLinkProxy.ReceiveSmartLinkReached
	// Flags: [Event|Public|HasOutParms|HasDefaults|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(2) Size(0x14) ]
	void ReceiveSmartLinkReached(struct AActor* Agent, struct FVector& Destination);

	// Object: Function AIModule.NavLinkProxy.IsSmartLinkEnabled
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105d03e00
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsSmartLinkEnabled();

	// Object: Function AIModule.NavLinkProxy.HasMovingAgents
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105d03d44
	// Return & Params: [ Num(1) Size(0x1) ]
	bool HasMovingAgents();
};

// Object: Class AIModule.AIPerceptionComponent
// Inherited Bytes: 0xb0 | Struct Size: 0x180
struct UAIPerceptionComponent : UActorComponent {
	// Fields
	struct TArray<struct UAISenseConfig*> SensesConfig; // Offset: 0xb0 | Size: 0x10
	struct UAISense* DominantSense; // Offset: 0xc0 | Size: 0x8
	char pad_0xC8[0x10]; // Offset: 0xc8 | Size: 0x10
	struct AAIController* AIOwner; // Offset: 0xd8 | Size: 0x8
	char pad_0xE0[0x80]; // Offset: 0xe0 | Size: 0x80
	struct FMulticastInlineDelegate OnPerceptionUpdated; // Offset: 0x160 | Size: 0x10
	struct FMulticastInlineDelegate OnTargetPerceptionUpdated; // Offset: 0x170 | Size: 0x10

	// Functions

	// Object: Function AIModule.AIPerceptionComponent.SetSenseEnabled
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105cd48f4
	// Return & Params: [ Num(2) Size(0x9) ]
	void SetSenseEnabled(struct UAISense* SenseClass, bool bEnable);

	// Object: Function AIModule.AIPerceptionComponent.RequestStimuliListenerUpdate
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105cd4e24
	// Return & Params: [ Num(0) Size(0x0) ]
	void RequestStimuliListenerUpdate();

	// Object: Function AIModule.AIPerceptionComponent.OnOwnerEndPlay
	// Flags: [Final|Native|Public]
	// Offset: 0x105cd4e38
	// Return & Params: [ Num(2) Size(0x9) ]
	void OnOwnerEndPlay(struct AActor* Actor, enum class EEndPlayReason EndPlayReason);

	// Object: Function AIModule.AIPerceptionComponent.GetPerceivedHostileActors
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105cd4d78
	// Return & Params: [ Num(1) Size(0x10) ]
	void GetPerceivedHostileActors(struct TArray<struct AActor*>& OutActors);

	// Object: Function AIModule.AIPerceptionComponent.GetPerceivedActors
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105cd4acc
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetPerceivedActors(struct UAISense* SenseToUse, struct TArray<struct AActor*>& OutActors);

	// Object: Function AIModule.AIPerceptionComponent.GetKnownPerceivedActors
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105cd4bb0
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetKnownPerceivedActors(struct UAISense* SenseToUse, struct TArray<struct AActor*>& OutActors);

	// Object: Function AIModule.AIPerceptionComponent.GetCurrentlyPerceivedActors
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105cd4c94
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetCurrentlyPerceivedActors(struct UAISense* SenseToUse, struct TArray<struct AActor*>& OutActors);

	// Object: Function AIModule.AIPerceptionComponent.GetActorsPerception
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105cd49c8
	// Return & Params: [ Num(3) Size(0x29) ]
	bool GetActorsPerception(struct AActor* Actor, struct FActorPerceptionBlueprintInfo& Info);

	// Object: Function AIModule.AIPerceptionComponent.ForgetAll
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105cd4e10
	// Return & Params: [ Num(0) Size(0x0) ]
	void ForgetAll();
};

// Object: Class AIModule.AIAsyncTaskBlueprintProxy
// Inherited Bytes: 0x28 | Struct Size: 0x68
struct UAIAsyncTaskBlueprintProxy : UObject {
	// Fields
	struct FMulticastInlineDelegate OnSuccess; // Offset: 0x28 | Size: 0x10
	struct FMulticastInlineDelegate OnFail; // Offset: 0x38 | Size: 0x10
	char pad_0x48[0x20]; // Offset: 0x48 | Size: 0x20

	// Functions

	// Object: Function AIModule.AIAsyncTaskBlueprintProxy.OnMoveCompleted
	// Flags: [Final|Native|Public]
	// Offset: 0x105cd0a98
	// Return & Params: [ Num(2) Size(0x5) ]
	void OnMoveCompleted(struct FAIRequestID RequestID, enum class EPathFollowingResult MovementResult);
};

// Object: Class AIModule.AIBlueprintHelperLibrary
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UAIBlueprintHelperLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object: Function AIModule.AIBlueprintHelperLibrary.UnlockAIResourcesWithAnimation
	// Flags: [Final|BlueprintAuthorityOnly|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105cd1268
	// Return & Params: [ Num(3) Size(0xa) ]
	void UnlockAIResourcesWithAnimation(struct UAnimInstance* AnimInstance, bool bUnlockMovement, bool UnlockAILogic);

	// Object: Function AIModule.AIBlueprintHelperLibrary.SpawnAIFromClass
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x105cd15b0
	// Return & Params: [ Num(8) Size(0x48) ]
	struct APawn* SpawnAIFromClass(struct UObject* WorldContextObject, struct APawn* PawnClass, struct UBehaviorTree* BehaviorTree, struct FVector Location, struct FRotator Rotation, bool bNoCollisionFail, struct AActor* Owner);

	// Object: Function AIModule.AIBlueprintHelperLibrary.SimpleMoveToLocation
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x105cd0ee0
	// Return & Params: [ Num(2) Size(0x14) ]
	void SimpleMoveToLocation(struct AController* Controller, struct FVector& Goal);

	// Object: Function AIModule.AIBlueprintHelperLibrary.SimpleMoveToActor
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105cd0fa8
	// Return & Params: [ Num(2) Size(0x10) ]
	void SimpleMoveToActor(struct AController* Controller, struct AActor* Goal);

	// Object: Function AIModule.AIBlueprintHelperLibrary.SendAIMessage
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105cd1800
	// Return & Params: [ Num(4) Size(0x19) ]
	void SendAIMessage(struct APawn* Target, struct FName Message, struct UObject* MessageSource, bool bSuccess);

	// Object: Function AIModule.AIBlueprintHelperLibrary.LockAIResourcesWithAnimation
	// Flags: [Final|BlueprintAuthorityOnly|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105cd138c
	// Return & Params: [ Num(3) Size(0xa) ]
	void LockAIResourcesWithAnimation(struct UAnimInstance* AnimInstance, bool bLockMovement, bool LockAILogic);

	// Object: Function AIModule.AIBlueprintHelperLibrary.IsValidAIRotation
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x105cd10e8
	// Return & Params: [ Num(2) Size(0xd) ]
	bool IsValidAIRotation(struct FRotator Rotation);

	// Object: Function AIModule.AIBlueprintHelperLibrary.IsValidAILocation
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x105cd11e8
	// Return & Params: [ Num(2) Size(0xd) ]
	bool IsValidAILocation(struct FVector Location);

	// Object: Function AIModule.AIBlueprintHelperLibrary.IsValidAIDirection
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x105cd1168
	// Return & Params: [ Num(2) Size(0xd) ]
	bool IsValidAIDirection(struct FVector DirectionVector);

	// Object: Function AIModule.AIBlueprintHelperLibrary.GetCurrentPath
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x105cd1068
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UNavigationPath* GetCurrentPath(struct AController* Controller);

	// Object: Function AIModule.AIBlueprintHelperLibrary.GetBlackboard
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x105cd14b0
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UBlackboardComponent* GetBlackboard(struct AActor* Target);

	// Object: Function AIModule.AIBlueprintHelperLibrary.GetAIController
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x105cd1530
	// Return & Params: [ Num(2) Size(0x10) ]
	struct AAIController* GetAIController(struct AActor* ControlledActor);

	// Object: Function AIModule.AIBlueprintHelperLibrary.CreateMoveToProxyObject
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x105cd1960
	// Return & Params: [ Num(7) Size(0x38) ]
	struct UAIAsyncTaskBlueprintProxy* CreateMoveToProxyObject(struct UObject* WorldContextObject, struct APawn* Pawn, struct FVector Destination, struct AActor* TargetActor, float AcceptanceRadius, bool bStopOnOverlap);
};

// Object: Class AIModule.AIDataProvider
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UAIDataProvider : UObject {
};

// Object: Class AIModule.AIDataProvider_QueryParams
// Inherited Bytes: 0x28 | Struct Size: 0x40
struct UAIDataProvider_QueryParams : UAIDataProvider {
	// Fields
	struct FName ParamName; // Offset: 0x28 | Size: 0x8
	float FloatValue; // Offset: 0x30 | Size: 0x4
	int32_t IntValue; // Offset: 0x34 | Size: 0x4
	bool BoolValue; // Offset: 0x38 | Size: 0x1
	char pad_0x39[0x7]; // Offset: 0x39 | Size: 0x7
};

// Object: Class AIModule.AIDataProvider_Random
// Inherited Bytes: 0x40 | Struct Size: 0x48
struct UAIDataProvider_Random : UAIDataProvider_QueryParams {
	// Fields
	float Min; // Offset: 0x3c | Size: 0x4
	float Max; // Offset: 0x40 | Size: 0x4
	char bInteger : 1; // Offset: 0x44 | Size: 0x1
};

// Object: Class AIModule.AIHotSpotManager
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UAIHotSpotManager : UObject {
};

// Object: Class AIModule.AIPerceptionListenerInterface
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UAIPerceptionListenerInterface : UInterface {
};

// Object: Class AIModule.AIPerceptionStimuliSourceComponent
// Inherited Bytes: 0xb0 | Struct Size: 0xc8
struct UAIPerceptionStimuliSourceComponent : UActorComponent {
	// Fields
	char bAutoRegisterAsSource : 1; // Offset: 0xb0 | Size: 0x1
	char pad_0xB0_1 : 7; // Offset: 0xb0 | Size: 0x1
	char pad_0xB1[0x7]; // Offset: 0xb1 | Size: 0x7
	struct TArray<struct UAISense*> RegisterAsSourceForSenses; // Offset: 0xb8 | Size: 0x10

	// Functions

	// Object: Function AIModule.AIPerceptionStimuliSourceComponent.UnregisterFromSense
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105cd5588
	// Return & Params: [ Num(1) Size(0x8) ]
	void UnregisterFromSense(struct UAISense* SenseClass);

	// Object: Function AIModule.AIPerceptionStimuliSourceComponent.UnregisterFromPerceptionSystem
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105cd5608
	// Return & Params: [ Num(0) Size(0x0) ]
	void UnregisterFromPerceptionSystem();

	// Object: Function AIModule.AIPerceptionStimuliSourceComponent.RegisterWithPerceptionSystem
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105cd569c
	// Return & Params: [ Num(0) Size(0x0) ]
	void RegisterWithPerceptionSystem();

	// Object: Function AIModule.AIPerceptionStimuliSourceComponent.RegisterForSense
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105cd561c
	// Return & Params: [ Num(1) Size(0x8) ]
	void RegisterForSense(struct UAISense* SenseClass);
};

// Object: Class AIModule.AISubsystem
// Inherited Bytes: 0x28 | Struct Size: 0x40
struct UAISubsystem : UObject {
	// Fields
	char pad_0x28[0x10]; // Offset: 0x28 | Size: 0x10
	struct UAISystem* AISystem; // Offset: 0x38 | Size: 0x8
};

// Object: Class AIModule.AIPerceptionSystem
// Inherited Bytes: 0x40 | Struct Size: 0x140
struct UAIPerceptionSystem : UAISubsystem {
	// Fields
	char pad_0x40[0x50]; // Offset: 0x40 | Size: 0x50
	struct TArray<struct UAISense*> Senses; // Offset: 0x90 | Size: 0x10
	float PerceptionAgingRate; // Offset: 0xa0 | Size: 0x4
	char pad_0xA4[0x9c]; // Offset: 0xa4 | Size: 0x9c

	// Functions

	// Object: Function AIModule.AIPerceptionSystem.ReportPerceptionEvent
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105cd5df0
	// Return & Params: [ Num(2) Size(0x10) ]
	void ReportPerceptionEvent(struct UObject* WorldContextObject, struct UAISenseEvent* PerceptionEvent);

	// Object: Function AIModule.AIPerceptionSystem.ReportEvent
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105cd5eb0
	// Return & Params: [ Num(1) Size(0x8) ]
	void ReportEvent(struct UAISenseEvent* PerceptionEvent);

	// Object: Function AIModule.AIPerceptionSystem.RegisterPerceptionStimuliSource
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105cd5cdc
	// Return & Params: [ Num(4) Size(0x19) ]
	bool RegisterPerceptionStimuliSource(struct UObject* WorldContextObject, struct UAISense* Sense, struct AActor* Target);

	// Object: Function AIModule.AIPerceptionSystem.OnPerceptionStimuliSourceEndPlay
	// Flags: [Final|Native|Protected]
	// Offset: 0x105cd5a8c
	// Return & Params: [ Num(2) Size(0x9) ]
	void OnPerceptionStimuliSourceEndPlay(struct AActor* Actor, enum class EEndPlayReason EndPlayReason);

	// Object: Function AIModule.AIPerceptionSystem.GetSenseClassForStimulus
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105cd5b58
	// Return & Params: [ Num(3) Size(0x50) ]
	struct UAISense* GetSenseClassForStimulus(struct UObject* WorldContextObject, struct FAIStimulus& Stimulus);
};

// Object: Class AIModule.AIResourceInterface
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UAIResourceInterface : UInterface {
};

// Object: Class AIModule.AIResource_Movement
// Inherited Bytes: 0x30 | Struct Size: 0x30
struct UAIResource_Movement : UGameplayTaskResource {
};

// Object: Class AIModule.AIResource_Logic
// Inherited Bytes: 0x30 | Struct Size: 0x30
struct UAIResource_Logic : UGameplayTaskResource {
};

// Object: Class AIModule.AISense_Blueprint
// Inherited Bytes: 0x78 | Struct Size: 0xa0
struct UAISense_Blueprint : UAISense {
	// Fields
	struct UUserDefinedStruct* ListenerDataType; // Offset: 0x78 | Size: 0x8
	struct TArray<struct UAIPerceptionComponent*> ListenerContainer; // Offset: 0x80 | Size: 0x10
	struct TArray<struct UAISenseEvent*> UnprocessedEvents; // Offset: 0x90 | Size: 0x10

	// Functions

	// Object: Function AIModule.AISense_Blueprint.OnUpdate
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(2) Size(0x14) ]
	float OnUpdate(struct TArray<struct UAISenseEvent*>& EventsToProcess);

	// Object: Function AIModule.AISense_Blueprint.OnListenerUpdated
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(2) Size(0x10) ]
	void OnListenerUpdated(struct AActor* ActorListener, struct UAIPerceptionComponent* PerceptionComponent);

	// Object: Function AIModule.AISense_Blueprint.OnListenerUnregistered
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(2) Size(0x10) ]
	void OnListenerUnregistered(struct AActor* ActorListener, struct UAIPerceptionComponent* PerceptionComponent);

	// Object: Function AIModule.AISense_Blueprint.OnListenerRegistered
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(2) Size(0x10) ]
	void OnListenerRegistered(struct AActor* ActorListener, struct UAIPerceptionComponent* PerceptionComponent);

	// Object: Function AIModule.AISense_Blueprint.K2_OnNewPawn
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x8) ]
	void K2_OnNewPawn(struct APawn* NewPawn);

	// Object: Function AIModule.AISense_Blueprint.GetAllListenerComponents
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105cd91cc
	// Return & Params: [ Num(1) Size(0x10) ]
	void GetAllListenerComponents(struct TArray<struct UAIPerceptionComponent*>& ListenerComponents);

	// Object: Function AIModule.AISense_Blueprint.GetAllListenerActors
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105cd9264
	// Return & Params: [ Num(1) Size(0x10) ]
	void GetAllListenerActors(struct TArray<struct AActor*>& ListenerActors);
};

// Object: Class AIModule.AISense_Damage
// Inherited Bytes: 0x78 | Struct Size: 0x88
struct UAISense_Damage : UAISense {
	// Fields
	struct TArray<struct FAIDamageEvent> RegisteredEvents; // Offset: 0x78 | Size: 0x10

	// Functions

	// Object: Function AIModule.AISense_Damage.ReportDamageEvent
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x105cd9be0
	// Return & Params: [ Num(6) Size(0x34) ]
	void ReportDamageEvent(struct UObject* WorldContextObject, struct AActor* DamagedActor, struct AActor* Instigator, float DamageAmount, struct FVector EventLocation, struct FVector HitLocation);
};

// Object: Class AIModule.AISense_Hearing
// Inherited Bytes: 0x78 | Struct Size: 0xe0
struct UAISense_Hearing : UAISense {
	// Fields
	struct TArray<struct FAINoiseEvent> NoiseEvents; // Offset: 0x78 | Size: 0x10
	float SpeedOfSoundSq; // Offset: 0x88 | Size: 0x4
	char pad_0x8C[0x54]; // Offset: 0x8c | Size: 0x54

	// Functions

	// Object: Function AIModule.AISense_Hearing.ReportNoiseEvent
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x105cda244
	// Return & Params: [ Num(6) Size(0x2c) ]
	void ReportNoiseEvent(struct UObject* WorldContextObject, struct FVector NoiseLocation, float Loudness, struct AActor* Instigator, float MaxRange, struct FName Tag);
};

// Object: Class AIModule.AISense_Prediction
// Inherited Bytes: 0x78 | Struct Size: 0x88
struct UAISense_Prediction : UAISense {
	// Fields
	struct TArray<struct FAIPredictionEvent> RegisteredEvents; // Offset: 0x78 | Size: 0x10

	// Functions

	// Object: Function AIModule.AISense_Prediction.RequestPawnPredictionEvent
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105cda8b4
	// Return & Params: [ Num(3) Size(0x14) ]
	void RequestPawnPredictionEvent(struct APawn* Requestor, struct AActor* PredictedActor, float PredictionTime);

	// Object: Function AIModule.AISense_Prediction.RequestControllerPredictionEvent
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105cda9c0
	// Return & Params: [ Num(3) Size(0x14) ]
	void RequestControllerPredictionEvent(struct AAIController* Requestor, struct AActor* PredictedActor, float PredictionTime);
};

// Object: Class AIModule.AISense_Sight
// Inherited Bytes: 0x78 | Struct Size: 0x168
struct UAISense_Sight : UAISense {
	// Fields
	char pad_0x78[0xc8]; // Offset: 0x78 | Size: 0xc8
	int32_t MaxTracesPerTick; // Offset: 0x140 | Size: 0x4
	int32_t MinQueriesPerTimeSliceCheck; // Offset: 0x144 | Size: 0x4
	double MaxTimeSlicePerTick; // Offset: 0x148 | Size: 0x8
	float HighImportanceQueryDistanceThreshold; // Offset: 0x150 | Size: 0x4
	char pad_0x154[0x4]; // Offset: 0x154 | Size: 0x4
	float MaxQueryImportance; // Offset: 0x158 | Size: 0x4
	float SightLimitQueryImportance; // Offset: 0x15c | Size: 0x4
	char pad_0x160[0x8]; // Offset: 0x160 | Size: 0x8
};

// Object: Class AIModule.AISense_Team
// Inherited Bytes: 0x78 | Struct Size: 0x88
struct UAISense_Team : UAISense {
	// Fields
	struct TArray<struct FAITeamStimulusEvent> RegisteredEvents; // Offset: 0x78 | Size: 0x10
};

// Object: Class AIModule.AISense_Touch
// Inherited Bytes: 0x78 | Struct Size: 0x88
struct UAISense_Touch : UAISense {
	// Fields
	struct TArray<struct FAITouchEvent> RegisteredEvents; // Offset: 0x78 | Size: 0x10
};

// Object: Class AIModule.AISenseBlueprintListener
// Inherited Bytes: 0x108 | Struct Size: 0x108
struct UAISenseBlueprintListener : UUserDefinedStruct {
};

// Object: Class AIModule.AISenseConfig_Blueprint
// Inherited Bytes: 0x48 | Struct Size: 0x50
struct UAISenseConfig_Blueprint : UAISenseConfig {
	// Fields
	struct UAISense_Blueprint* Implementation; // Offset: 0x48 | Size: 0x8
};

// Object: Class AIModule.AISenseConfig_Damage
// Inherited Bytes: 0x48 | Struct Size: 0x50
struct UAISenseConfig_Damage : UAISenseConfig {
	// Fields
	struct UAISense_Damage* Implementation; // Offset: 0x48 | Size: 0x8
};

// Object: Class AIModule.AISenseConfig_Hearing
// Inherited Bytes: 0x48 | Struct Size: 0x60
struct UAISenseConfig_Hearing : UAISenseConfig {
	// Fields
	struct UAISense_Hearing* Implementation; // Offset: 0x48 | Size: 0x8
	float HearingRange; // Offset: 0x50 | Size: 0x4
	float LoSHearingRange; // Offset: 0x54 | Size: 0x4
	char bUseLoSHearing : 1; // Offset: 0x58 | Size: 0x1
	char pad_0x58_1 : 7; // Offset: 0x58 | Size: 0x1
	char pad_0x59[0x3]; // Offset: 0x59 | Size: 0x3
	struct FAISenseAffiliationFilter DetectionByAffiliation; // Offset: 0x5c | Size: 0x4
};

// Object: Class AIModule.AISenseConfig_Prediction
// Inherited Bytes: 0x48 | Struct Size: 0x48
struct UAISenseConfig_Prediction : UAISenseConfig {
};

// Object: Class AIModule.AISenseConfig_Sight
// Inherited Bytes: 0x48 | Struct Size: 0x68
struct UAISenseConfig_Sight : UAISenseConfig {
	// Fields
	struct UAISense_Sight* Implementation; // Offset: 0x48 | Size: 0x8
	float SightRadius; // Offset: 0x50 | Size: 0x4
	float LoseSightRadius; // Offset: 0x54 | Size: 0x4
	float PeripheralVisionAngleDegrees; // Offset: 0x58 | Size: 0x4
	struct FAISenseAffiliationFilter DetectionByAffiliation; // Offset: 0x5c | Size: 0x4
	float AutoSuccessRangeFromLastSeenLocation; // Offset: 0x60 | Size: 0x4
	char pad_0x64[0x4]; // Offset: 0x64 | Size: 0x4
};

// Object: Class AIModule.AISenseConfig_Team
// Inherited Bytes: 0x48 | Struct Size: 0x48
struct UAISenseConfig_Team : UAISenseConfig {
};

// Object: Class AIModule.AISenseConfig_Touch
// Inherited Bytes: 0x48 | Struct Size: 0x48
struct UAISenseConfig_Touch : UAISenseConfig {
};

// Object: Class AIModule.AISenseEvent
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UAISenseEvent : UObject {
};

// Object: Class AIModule.AISenseEvent_Damage
// Inherited Bytes: 0x28 | Struct Size: 0x58
struct UAISenseEvent_Damage : UAISenseEvent {
	// Fields
	struct FAIDamageEvent Event; // Offset: 0x28 | Size: 0x30
};

// Object: Class AIModule.AISenseEvent_Hearing
// Inherited Bytes: 0x28 | Struct Size: 0x58
struct UAISenseEvent_Hearing : UAISenseEvent {
	// Fields
	struct FAINoiseEvent Event; // Offset: 0x28 | Size: 0x30
};

// Object: Class AIModule.AISightTargetInterface
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UAISightTargetInterface : UInterface {
};

// Object: Class AIModule.AISystem
// Inherited Bytes: 0x58 | Struct Size: 0x130
struct UAISystem : UAISystemBase {
	// Fields
	struct FSoftClassPath PerceptionSystemClassName; // Offset: 0x58 | Size: 0x18
	struct FSoftClassPath HotSpotManagerClassName; // Offset: 0x70 | Size: 0x18
	float AcceptanceRadius; // Offset: 0x88 | Size: 0x4
	float PathfollowingRegularPathPointAcceptanceRadius; // Offset: 0x8c | Size: 0x4
	float PathfollowingNavLinkAcceptanceRadius; // Offset: 0x90 | Size: 0x4
	bool bFinishMoveOnGoalOverlap; // Offset: 0x94 | Size: 0x1
	bool bAcceptPartialPaths; // Offset: 0x95 | Size: 0x1
	bool bAllowStrafing; // Offset: 0x96 | Size: 0x1
	bool bEnableBTAITasks; // Offset: 0x97 | Size: 0x1
	bool bAllowControllersAsEQSQuerier; // Offset: 0x98 | Size: 0x1
	bool bEnableDebuggerPlugin; // Offset: 0x99 | Size: 0x1
	bool bForgetStaleActors; // Offset: 0x9a | Size: 0x1
	enum class ECollisionChannel DefaultSightCollisionChannel; // Offset: 0x9b | Size: 0x1
	char pad_0x9C[0x4]; // Offset: 0x9c | Size: 0x4
	struct UBehaviorTreeManager* BehaviorTreeManager; // Offset: 0xa0 | Size: 0x8
	struct UEnvQueryManager* EnvironmentQueryManager; // Offset: 0xa8 | Size: 0x8
	struct UAIPerceptionSystem* PerceptionSystem; // Offset: 0xb0 | Size: 0x8
	struct TArray<struct UAIAsyncTaskBlueprintProxy*> AllProxyObjects; // Offset: 0xb8 | Size: 0x10
	struct UAIHotSpotManager* HotSpotManager; // Offset: 0xc8 | Size: 0x8
	struct UNavLocalGridManager* NavLocalGrids; // Offset: 0xd0 | Size: 0x8
	char pad_0xD8[0x58]; // Offset: 0xd8 | Size: 0x58

	// Functions

	// Object: Function AIModule.AISystem.AILoggingVerbose
	// Flags: [Exec|Native|Public]
	// Offset: 0x105cdcd24
	// Return & Params: [ Num(0) Size(0x0) ]
	void AILoggingVerbose();

	// Object: Function AIModule.AISystem.AIIgnorePlayers
	// Flags: [Exec|Native|Public]
	// Offset: 0x105cdcd40
	// Return & Params: [ Num(0) Size(0x0) ]
	void AIIgnorePlayers();
};

// Object: Class AIModule.AITask
// Inherited Bytes: 0x60 | Struct Size: 0x68
struct UAITask : UGameplayTask {
	// Fields
	struct AAIController* OwnerController; // Offset: 0x60 | Size: 0x8
};

// Object: Class AIModule.AITask_LockLogic
// Inherited Bytes: 0x68 | Struct Size: 0x68
struct UAITask_LockLogic : UAITask {
};

// Object: Class AIModule.AITask_MoveTo
// Inherited Bytes: 0x68 | Struct Size: 0x108
struct UAITask_MoveTo : UAITask {
	// Fields
	struct FMulticastInlineDelegate OnRequestFailed; // Offset: 0x68 | Size: 0x10
	struct FMulticastInlineDelegate OnMoveFinished; // Offset: 0x78 | Size: 0x10
	struct FAIMoveRequest MoveRequest; // Offset: 0x88 | Size: 0x40
	char pad_0xC8[0x40]; // Offset: 0xc8 | Size: 0x40

	// Functions

	// Object: Function AIModule.AITask_MoveTo.AIMoveTo
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x105cdd4d4
	// Return & Params: [ Num(11) Size(0x38) ]
	struct UAITask_MoveTo* AIMoveTo(struct AAIController* Controller, struct FVector GoalLocation, struct AActor* GoalActor, float AcceptanceRadius, enum class EAIOptionFlag StopOnOverlap, enum class EAIOptionFlag AcceptPartialPath, bool bUsePathfinding, bool bLockAILogic, bool bUseContinuosGoalTracking, enum class EAIOptionFlag ProjectGoalOnNavigation);
};

// Object: Class AIModule.AITask_RunEQS
// Inherited Bytes: 0x68 | Struct Size: 0xe0
struct UAITask_RunEQS : UAITask {
	// Fields
	char pad_0x68[0x78]; // Offset: 0x68 | Size: 0x78

	// Functions

	// Object: Function AIModule.AITask_RunEQS.RunEQS
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105cddc94
	// Return & Params: [ Num(3) Size(0x18) ]
	struct UAITask_RunEQS* RunEQS(struct AAIController* Controller, struct UEnvQuery* QueryTemplate);
};

// Object: Class AIModule.BehaviorTree
// Inherited Bytes: 0x28 | Struct Size: 0x68
struct UBehaviorTree : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
	struct UBTCompositeNode* RootNode; // Offset: 0x30 | Size: 0x8
	struct UBlackboardData* BlackboardAsset; // Offset: 0x38 | Size: 0x8
	struct TArray<struct UBTDecorator*> RootDecorators; // Offset: 0x40 | Size: 0x10
	struct TArray<struct FBTDecoratorLogic> RootDecoratorOps; // Offset: 0x50 | Size: 0x10
	char pad_0x60[0x8]; // Offset: 0x60 | Size: 0x8
};

// Object: Class AIModule.BrainComponent
// Inherited Bytes: 0xb0 | Struct Size: 0x110
struct UBrainComponent : UActorComponent {
	// Fields
	char pad_0xB0[0x8]; // Offset: 0xb0 | Size: 0x8
	struct UBlackboardComponent* BlackboardComp; // Offset: 0xb8 | Size: 0x8
	struct AAIController* AIOwner; // Offset: 0xc0 | Size: 0x8
	char pad_0xC8[0x48]; // Offset: 0xc8 | Size: 0x48

	// Functions

	// Object: Function AIModule.BrainComponent.StopLogic
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x105ce7630
	// Return & Params: [ Num(1) Size(0x10) ]
	void StopLogic(struct FString Reason);

	// Object: Function AIModule.BrainComponent.StartLogic
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x105ce76e0
	// Return & Params: [ Num(0) Size(0x0) ]
	void StartLogic();

	// Object: Function AIModule.BrainComponent.RestartLogic
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x105ce76c4
	// Return & Params: [ Num(0) Size(0x0) ]
	void RestartLogic();

	// Object: Function AIModule.BrainComponent.IsRunning
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105ce75f4
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsRunning();

	// Object: Function AIModule.BrainComponent.IsPaused
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105ce75b8
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsPaused();
};

// Object: Class AIModule.BehaviorTreeComponent
// Inherited Bytes: 0x110 | Struct Size: 0x2a0
struct UBehaviorTreeComponent : UBrainComponent {
	// Fields
	char pad_0x110[0x20]; // Offset: 0x110 | Size: 0x20
	struct TArray<struct UBTNode*> NodeInstances; // Offset: 0x130 | Size: 0x10
	char pad_0x140[0x148]; // Offset: 0x140 | Size: 0x148
	struct UBehaviorTree* DefaultBehaviorTreeAsset; // Offset: 0x288 | Size: 0x8
	char pad_0x290[0x10]; // Offset: 0x290 | Size: 0x10

	// Functions

	// Object: Function AIModule.BehaviorTreeComponent.SetDynamicSubtree
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x105cdea3c
	// Return & Params: [ Num(2) Size(0x10) ]
	void SetDynamicSubtree(struct FGameplayTag InjectTag, struct UBehaviorTree* BehaviorAsset);

	// Object: Function AIModule.BehaviorTreeComponent.GetTagCooldownEndTime
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105cdec2c
	// Return & Params: [ Num(2) Size(0xc) ]
	float GetTagCooldownEndTime(struct FGameplayTag CooldownTag);

	// Object: Function AIModule.BehaviorTreeComponent.AddCooldownTagDuration
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105cdeb0c
	// Return & Params: [ Num(3) Size(0xd) ]
	void AddCooldownTagDuration(struct FGameplayTag CooldownTag, float CoolDownDuration, bool bAddToExistingDuration);
};

// Object: Class AIModule.BehaviorTreeManager
// Inherited Bytes: 0x28 | Struct Size: 0x50
struct UBehaviorTreeManager : UObject {
	// Fields
	int32_t MaxDebuggerSteps; // Offset: 0x28 | Size: 0x4
	char pad_0x2C[0x4]; // Offset: 0x2c | Size: 0x4
	struct TArray<struct FBehaviorTreeTemplateInfo> LoadedTemplates; // Offset: 0x30 | Size: 0x10
	struct TArray<struct UBehaviorTreeComponent*> ActiveComponents; // Offset: 0x40 | Size: 0x10
};

// Object: Class AIModule.BehaviorTreeTypes
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UBehaviorTreeTypes : UObject {
};

// Object: Class AIModule.BlackboardAssetProvider
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UBlackboardAssetProvider : UInterface {
	// Functions

	// Object: Function AIModule.BlackboardAssetProvider.GetBlackboardAsset
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105ce395c
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UBlackboardData* GetBlackboardAsset();
};

// Object: Class AIModule.BlackboardComponent
// Inherited Bytes: 0xb0 | Struct Size: 0x1b0
struct UBlackboardComponent : UActorComponent {
	// Fields
	struct UBrainComponent* BrainComp; // Offset: 0xb0 | Size: 0x8
	struct UBlackboardData* DefaultBlackboardAsset; // Offset: 0xb8 | Size: 0x8
	struct UBlackboardData* BlackboardAsset; // Offset: 0xc0 | Size: 0x8
	char pad_0xC8[0x20]; // Offset: 0xc8 | Size: 0x20
	struct TArray<struct UBlackboardKeyType*> KeyInstances; // Offset: 0xe8 | Size: 0x10
	char pad_0xF8[0xb8]; // Offset: 0xf8 | Size: 0xb8

	// Functions

	// Object: Function AIModule.BlackboardComponent.SetValueAsVector
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x105ce4124
	// Return & Params: [ Num(2) Size(0x14) ]
	void SetValueAsVector(struct FName& KeyName, struct FVector VectorValue);

	// Object: Function AIModule.BlackboardComponent.SetValueAsString
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105ce42e8
	// Return & Params: [ Num(2) Size(0x18) ]
	void SetValueAsString(struct FName& KeyName, struct FString StringValue);

	// Object: Function AIModule.BlackboardComponent.SetValueAsRotator
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x105ce4044
	// Return & Params: [ Num(2) Size(0x14) ]
	void SetValueAsRotator(struct FName& KeyName, struct FRotator VectorValue);

	// Object: Function AIModule.BlackboardComponent.SetValueAsObject
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105ce48a8
	// Return & Params: [ Num(2) Size(0x10) ]
	void SetValueAsObject(struct FName& KeyName, struct UObject* ObjectValue);

	// Object: Function AIModule.BlackboardComponent.SetValueAsName
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105ce4204
	// Return & Params: [ Num(2) Size(0x10) ]
	void SetValueAsName(struct FName& KeyName, struct FName NameValue);

	// Object: Function AIModule.BlackboardComponent.SetValueAsInt
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105ce45fc
	// Return & Params: [ Num(2) Size(0xc) ]
	void SetValueAsInt(struct FName& KeyName, int32_t IntValue);

	// Object: Function AIModule.BlackboardComponent.SetValueAsFloat
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105ce4518
	// Return & Params: [ Num(2) Size(0xc) ]
	void SetValueAsFloat(struct FName& KeyName, float FloatValue);

	// Object: Function AIModule.BlackboardComponent.SetValueAsEnum
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105ce46e0
	// Return & Params: [ Num(2) Size(0x9) ]
	void SetValueAsEnum(struct FName& KeyName, char EnumValue);

	// Object: Function AIModule.BlackboardComponent.SetValueAsClass
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105ce47c4
	// Return & Params: [ Num(2) Size(0x10) ]
	void SetValueAsClass(struct FName& KeyName, struct UObject* ClassValue);

	// Object: Function AIModule.BlackboardComponent.SetValueAsBool
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105ce442c
	// Return & Params: [ Num(2) Size(0x9) ]
	void SetValueAsBool(struct FName& KeyName, bool BoolValue);

	// Object: Function AIModule.BlackboardComponent.IsVectorValueSet
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105ce3fa8
	// Return & Params: [ Num(2) Size(0x9) ]
	bool IsVectorValueSet(struct FName& KeyName);

	// Object: Function AIModule.BlackboardComponent.GetValueAsVector
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105ce4a30
	// Return & Params: [ Num(2) Size(0x14) ]
	struct FVector GetValueAsVector(struct FName& KeyName);

	// Object: Function AIModule.BlackboardComponent.GetValueAsString
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105ce4b70
	// Return & Params: [ Num(2) Size(0x18) ]
	struct FString GetValueAsString(struct FName& KeyName);

	// Object: Function AIModule.BlackboardComponent.GetValueAsRotator
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105ce498c
	// Return & Params: [ Num(2) Size(0x14) ]
	struct FRotator GetValueAsRotator(struct FName& KeyName);

	// Object: Function AIModule.BlackboardComponent.GetValueAsObject
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105ce4f60
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UObject* GetValueAsObject(struct FName& KeyName);

	// Object: Function AIModule.BlackboardComponent.GetValueAsName
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105ce4ad4
	// Return & Params: [ Num(2) Size(0x10) ]
	struct FName GetValueAsName(struct FName& KeyName);

	// Object: Function AIModule.BlackboardComponent.GetValueAsInt
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105ce4d8c
	// Return & Params: [ Num(2) Size(0xc) ]
	int32_t GetValueAsInt(struct FName& KeyName);

	// Object: Function AIModule.BlackboardComponent.GetValueAsFloat
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105ce4cf0
	// Return & Params: [ Num(2) Size(0xc) ]
	float GetValueAsFloat(struct FName& KeyName);

	// Object: Function AIModule.BlackboardComponent.GetValueAsEnum
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105ce4e28
	// Return & Params: [ Num(2) Size(0x9) ]
	char GetValueAsEnum(struct FName& KeyName);

	// Object: Function AIModule.BlackboardComponent.GetValueAsClass
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105ce4ec4
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UObject* GetValueAsClass(struct FName& KeyName);

	// Object: Function AIModule.BlackboardComponent.GetValueAsBool
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105ce4c54
	// Return & Params: [ Num(2) Size(0x9) ]
	bool GetValueAsBool(struct FName& KeyName);

	// Object: Function AIModule.BlackboardComponent.GetRotationFromEntry
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105ce3dc8
	// Return & Params: [ Num(3) Size(0x15) ]
	bool GetRotationFromEntry(struct FName& KeyName, struct FRotator& ResultRotation);

	// Object: Function AIModule.BlackboardComponent.GetLocationFromEntry
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105ce3eb8
	// Return & Params: [ Num(3) Size(0x15) ]
	bool GetLocationFromEntry(struct FName& KeyName, struct FVector& ResultLocation);

	// Object: Function AIModule.BlackboardComponent.ClearValue
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105ce3d3c
	// Return & Params: [ Num(1) Size(0x8) ]
	void ClearValue(struct FName& KeyName);
};

// Object: Class AIModule.BlackboardData
// Inherited Bytes: 0x30 | Struct Size: 0x50
struct UBlackboardData : UDataAsset {
	// Fields
	struct UBlackboardData* Parent; // Offset: 0x30 | Size: 0x8
	struct TArray<struct FBlackboardEntry> Keys; // Offset: 0x38 | Size: 0x10
	char bHasSynchronizedKeys : 1; // Offset: 0x48 | Size: 0x1
	char pad_0x48_1 : 7; // Offset: 0x48 | Size: 0x1
	char pad_0x49[0x7]; // Offset: 0x49 | Size: 0x7
};

// Object: Class AIModule.BlackboardKeyType
// Inherited Bytes: 0x28 | Struct Size: 0x30
struct UBlackboardKeyType : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
};

// Object: Class AIModule.BlackboardKeyType_Bool
// Inherited Bytes: 0x30 | Struct Size: 0x30
struct UBlackboardKeyType_Bool : UBlackboardKeyType {
};

// Object: Class AIModule.BlackboardKeyType_Class
// Inherited Bytes: 0x30 | Struct Size: 0x38
struct UBlackboardKeyType_Class : UBlackboardKeyType {
	// Fields
	struct UObject* BaseClass; // Offset: 0x30 | Size: 0x8
};

// Object: Class AIModule.BlackboardKeyType_Enum
// Inherited Bytes: 0x30 | Struct Size: 0x50
struct UBlackboardKeyType_Enum : UBlackboardKeyType {
	// Fields
	struct UEnum* EnumType; // Offset: 0x30 | Size: 0x8
	struct FString EnumName; // Offset: 0x38 | Size: 0x10
	char bIsEnumNameValid : 1; // Offset: 0x48 | Size: 0x1
	char pad_0x48_1 : 7; // Offset: 0x48 | Size: 0x1
	char pad_0x49[0x7]; // Offset: 0x49 | Size: 0x7
};

// Object: Class AIModule.BlackboardKeyType_Float
// Inherited Bytes: 0x30 | Struct Size: 0x30
struct UBlackboardKeyType_Float : UBlackboardKeyType {
};

// Object: Class AIModule.BlackboardKeyType_Int
// Inherited Bytes: 0x30 | Struct Size: 0x30
struct UBlackboardKeyType_Int : UBlackboardKeyType {
};

// Object: Class AIModule.BlackboardKeyType_Name
// Inherited Bytes: 0x30 | Struct Size: 0x30
struct UBlackboardKeyType_Name : UBlackboardKeyType {
};

// Object: Class AIModule.BlackboardKeyType_NativeEnum
// Inherited Bytes: 0x30 | Struct Size: 0x48
struct UBlackboardKeyType_NativeEnum : UBlackboardKeyType {
	// Fields
	struct FString EnumName; // Offset: 0x30 | Size: 0x10
	struct UEnum* EnumType; // Offset: 0x40 | Size: 0x8
};

// Object: Class AIModule.BlackboardKeyType_Object
// Inherited Bytes: 0x30 | Struct Size: 0x38
struct UBlackboardKeyType_Object : UBlackboardKeyType {
	// Fields
	struct UObject* BaseClass; // Offset: 0x30 | Size: 0x8
};

// Object: Class AIModule.BlackboardKeyType_Rotator
// Inherited Bytes: 0x30 | Struct Size: 0x30
struct UBlackboardKeyType_Rotator : UBlackboardKeyType {
};

// Object: Class AIModule.BlackboardKeyType_String
// Inherited Bytes: 0x30 | Struct Size: 0x40
struct UBlackboardKeyType_String : UBlackboardKeyType {
	// Fields
	struct FString StringValue; // Offset: 0x30 | Size: 0x10
};

// Object: Class AIModule.BlackboardKeyType_Vector
// Inherited Bytes: 0x30 | Struct Size: 0x30
struct UBlackboardKeyType_Vector : UBlackboardKeyType {
};

// Object: Class AIModule.BTComposite_Selector
// Inherited Bytes: 0x90 | Struct Size: 0x90
struct UBTComposite_Selector : UBTCompositeNode {
};

// Object: Class AIModule.BTComposite_Sequence
// Inherited Bytes: 0x90 | Struct Size: 0x90
struct UBTComposite_Sequence : UBTCompositeNode {
};

// Object: Class AIModule.BTComposite_SimpleParallel
// Inherited Bytes: 0x90 | Struct Size: 0x90
struct UBTComposite_SimpleParallel : UBTCompositeNode {
	// Fields
	enum class EBTParallelMode FinishMode; // Offset: 0x8c | Size: 0x1
};

// Object: Class AIModule.BTDecorator_BlueprintBase
// Inherited Bytes: 0x60 | Struct Size: 0x98
struct UBTDecorator_BlueprintBase : UBTDecorator {
	// Fields
	struct AAIController* AIOwner; // Offset: 0x60 | Size: 0x8
	struct AActor* ActorOwner; // Offset: 0x68 | Size: 0x8
	struct TArray<struct FName> ObservedKeyNames; // Offset: 0x70 | Size: 0x10
	char pad_0x80[0x10]; // Offset: 0x80 | Size: 0x10
	char bShowPropertyDetails : 1; // Offset: 0x90 | Size: 0x1
	char bCheckConditionOnlyBlackBoardChanges : 1; // Offset: 0x90 | Size: 0x1
	char bIsObservingBB : 1; // Offset: 0x90 | Size: 0x1
	char pad_0x90_3 : 5; // Offset: 0x90 | Size: 0x1
	char pad_0x91[0x7]; // Offset: 0x91 | Size: 0x7

	// Functions

	// Object: Function AIModule.BTDecorator_BlueprintBase.ReceiveTickAI
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(3) Size(0x14) ]
	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds);

	// Object: Function AIModule.BTDecorator_BlueprintBase.ReceiveTick
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(2) Size(0xc) ]
	void ReceiveTick(struct AActor* OwnerActor, float DeltaSeconds);

	// Object: Function AIModule.BTDecorator_BlueprintBase.ReceiveObserverDeactivatedAI
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(2) Size(0x10) ]
	void ReceiveObserverDeactivatedAI(struct AAIController* OwnerController, struct APawn* ControlledPawn);

	// Object: Function AIModule.BTDecorator_BlueprintBase.ReceiveObserverDeactivated
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x8) ]
	void ReceiveObserverDeactivated(struct AActor* OwnerActor);

	// Object: Function AIModule.BTDecorator_BlueprintBase.ReceiveObserverActivatedAI
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(2) Size(0x10) ]
	void ReceiveObserverActivatedAI(struct AAIController* OwnerController, struct APawn* ControlledPawn);

	// Object: Function AIModule.BTDecorator_BlueprintBase.ReceiveObserverActivated
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x8) ]
	void ReceiveObserverActivated(struct AActor* OwnerActor);

	// Object: Function AIModule.BTDecorator_BlueprintBase.ReceiveExecutionStartAI
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(2) Size(0x10) ]
	void ReceiveExecutionStartAI(struct AAIController* OwnerController, struct APawn* ControlledPawn);

	// Object: Function AIModule.BTDecorator_BlueprintBase.ReceiveExecutionStart
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x8) ]
	void ReceiveExecutionStart(struct AActor* OwnerActor);

	// Object: Function AIModule.BTDecorator_BlueprintBase.ReceiveExecutionFinishAI
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(3) Size(0x11) ]
	void ReceiveExecutionFinishAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, enum class EBTNodeResult NodeResult);

	// Object: Function AIModule.BTDecorator_BlueprintBase.ReceiveExecutionFinish
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(2) Size(0x9) ]
	void ReceiveExecutionFinish(struct AActor* OwnerActor, enum class EBTNodeResult NodeResult);

	// Object: Function AIModule.BTDecorator_BlueprintBase.PerformConditionCheckAI
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(3) Size(0x11) ]
	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn);

	// Object: Function AIModule.BTDecorator_BlueprintBase.PerformConditionCheck
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(2) Size(0x9) ]
	bool PerformConditionCheck(struct AActor* OwnerActor);

	// Object: Function AIModule.BTDecorator_BlueprintBase.IsDecoratorObserverActive
	// Flags: [Final|Native|Protected|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105ce893c
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsDecoratorObserverActive();

	// Object: Function AIModule.BTDecorator_BlueprintBase.IsDecoratorExecutionActive
	// Flags: [Final|Native|Protected|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105ce8970
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsDecoratorExecutionActive();
};

// Object: Class AIModule.BTDecorator_CheckGameplayTagsOnActor
// Inherited Bytes: 0x60 | Struct Size: 0xc0
struct UBTDecorator_CheckGameplayTagsOnActor : UBTDecorator {
	// Fields
	struct FBlackboardKeySelector ActorToCheck; // Offset: 0x60 | Size: 0x28
	enum class EGameplayContainerMatchType TagsToMatch; // Offset: 0x88 | Size: 0x1
	char pad_0x89[0x7]; // Offset: 0x89 | Size: 0x7
	struct FGameplayTagContainer GameplayTags; // Offset: 0x90 | Size: 0x20
	struct FString CachedDescription; // Offset: 0xb0 | Size: 0x10
};

// Object: Class AIModule.BTDecorator_CompareBBEntries
// Inherited Bytes: 0x60 | Struct Size: 0xb0
struct UBTDecorator_CompareBBEntries : UBTDecorator {
	// Fields
	enum class EBlackBoardEntryComparison Operator; // Offset: 0x5a | Size: 0x1
	struct FBlackboardKeySelector BlackboardKeyA; // Offset: 0x60 | Size: 0x28
	struct FBlackboardKeySelector BlackboardKeyB; // Offset: 0x88 | Size: 0x28
};

// Object: Class AIModule.BTDecorator_ConditionalLoop
// Inherited Bytes: 0xb8 | Struct Size: 0xb8
struct UBTDecorator_ConditionalLoop : UBTDecorator_Blackboard {
};

// Object: Class AIModule.BTDecorator_ConeCheck
// Inherited Bytes: 0x60 | Struct Size: 0xe0
struct UBTDecorator_ConeCheck : UBTDecorator {
	// Fields
	float ConeHalfAngle; // Offset: 0x5c | Size: 0x4
	struct FBlackboardKeySelector ConeOrigin; // Offset: 0x60 | Size: 0x28
	struct FBlackboardKeySelector ConeDirection; // Offset: 0x88 | Size: 0x28
	struct FBlackboardKeySelector Observed; // Offset: 0xb0 | Size: 0x28
	char pad_0xDC[0x4]; // Offset: 0xdc | Size: 0x4
};

// Object: Class AIModule.BTDecorator_Cooldown
// Inherited Bytes: 0x60 | Struct Size: 0x60
struct UBTDecorator_Cooldown : UBTDecorator {
	// Fields
	float CoolDownTime; // Offset: 0x5c | Size: 0x4
};

// Object: Class AIModule.BTDecorator_DoesPathExist
// Inherited Bytes: 0x60 | Struct Size: 0xc0
struct UBTDecorator_DoesPathExist : UBTDecorator {
	// Fields
	struct FBlackboardKeySelector BlackboardKeyA; // Offset: 0x60 | Size: 0x28
	struct FBlackboardKeySelector BlackboardKeyB; // Offset: 0x88 | Size: 0x28
	char bUseSelf : 1; // Offset: 0xb0 | Size: 0x1
	char pad_0xB0_1 : 7; // Offset: 0xb0 | Size: 0x1
	enum class EPathExistanceQueryType PathQueryType; // Offset: 0xb1 | Size: 0x1
	char pad_0xB2[0x6]; // Offset: 0xb2 | Size: 0x6
	struct UNavigationQueryFilter* FilterClass; // Offset: 0xb8 | Size: 0x8
};

// Object: Class AIModule.BTDecorator_ForceSuccess
// Inherited Bytes: 0x60 | Struct Size: 0x60
struct UBTDecorator_ForceSuccess : UBTDecorator {
};

// Object: Class AIModule.BTDecorator_IsAtLocation
// Inherited Bytes: 0x88 | Struct Size: 0xd0
struct UBTDecorator_IsAtLocation : UBTDecorator_BlackboardBase {
	// Fields
	float AcceptableRadius; // Offset: 0x88 | Size: 0x4
	char pad_0x8C[0x4]; // Offset: 0x8c | Size: 0x4
	struct FAIDataProviderFloatValue ParametrizedAcceptableRadius; // Offset: 0x90 | Size: 0x38
	enum class FAIDistanceType GeometricDistanceType; // Offset: 0xc8 | Size: 0x1
	char bUseParametrizedRadius : 1; // Offset: 0xc9 | Size: 0x1
	char bUseNavAgentGoalLocation : 1; // Offset: 0xc9 | Size: 0x1
	char bPathFindingBasedTest : 1; // Offset: 0xc9 | Size: 0x1
	char pad_0xC9_3 : 5; // Offset: 0xc9 | Size: 0x1
	char pad_0xCA[0x6]; // Offset: 0xca | Size: 0x6
};

// Object: Class AIModule.BTDecorator_IsBBEntryOfClass
// Inherited Bytes: 0x88 | Struct Size: 0x90
struct UBTDecorator_IsBBEntryOfClass : UBTDecorator_BlackboardBase {
	// Fields
	struct UObject* TestClass; // Offset: 0x88 | Size: 0x8
};

// Object: Class AIModule.BTDecorator_KeepInCone
// Inherited Bytes: 0x60 | Struct Size: 0xb8
struct UBTDecorator_KeepInCone : UBTDecorator {
	// Fields
	float ConeHalfAngle; // Offset: 0x5c | Size: 0x4
	struct FBlackboardKeySelector ConeOrigin; // Offset: 0x60 | Size: 0x28
	struct FBlackboardKeySelector Observed; // Offset: 0x88 | Size: 0x28
	char bUseSelfAsOrigin : 1; // Offset: 0xb0 | Size: 0x1
	char bUseSelfAsObserved : 1; // Offset: 0xb0 | Size: 0x1
	char pad_0xB4_2 : 6; // Offset: 0xb4 | Size: 0x1
	char pad_0xB5[0x3]; // Offset: 0xb5 | Size: 0x3
};

// Object: Class AIModule.BTDecorator_Loop
// Inherited Bytes: 0x60 | Struct Size: 0x68
struct UBTDecorator_Loop : UBTDecorator {
	// Fields
	int32_t NumLoops; // Offset: 0x5c | Size: 0x4
	bool bInfiniteLoop; // Offset: 0x60 | Size: 0x1
	float InfiniteLoopTimeoutTime; // Offset: 0x64 | Size: 0x4
};

// Object: Class AIModule.BTDecorator_ReachedMoveGoal
// Inherited Bytes: 0x60 | Struct Size: 0x60
struct UBTDecorator_ReachedMoveGoal : UBTDecorator {
};

// Object: Class AIModule.BTDecorator_SetTagCooldown
// Inherited Bytes: 0x60 | Struct Size: 0x70
struct UBTDecorator_SetTagCooldown : UBTDecorator {
	// Fields
	struct FGameplayTag CooldownTag; // Offset: 0x5c | Size: 0x8
	float CoolDownDuration; // Offset: 0x64 | Size: 0x4
	bool bAddToExistingDuration; // Offset: 0x68 | Size: 0x1
	char pad_0x6D[0x3]; // Offset: 0x6d | Size: 0x3
};

// Object: Class AIModule.BTDecorator_TagCooldown
// Inherited Bytes: 0x60 | Struct Size: 0x70
struct UBTDecorator_TagCooldown : UBTDecorator {
	// Fields
	struct FGameplayTag CooldownTag; // Offset: 0x5c | Size: 0x8
	float CoolDownDuration; // Offset: 0x64 | Size: 0x4
	bool bAddToExistingDuration; // Offset: 0x68 | Size: 0x1
	bool bActivatesCooldown; // Offset: 0x69 | Size: 0x1
	char pad_0x6E[0x2]; // Offset: 0x6e | Size: 0x2
};

// Object: Class AIModule.BTFunctionLibrary
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UBTFunctionLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object: Function AIModule.BTFunctionLibrary.StopUsingExternalEvent
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105ced9fc
	// Return & Params: [ Num(1) Size(0x8) ]
	void StopUsingExternalEvent(struct UBTNode* NodeOwner);

	// Object: Function AIModule.BTFunctionLibrary.StartUsingExternalEvent
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105ceda74
	// Return & Params: [ Num(2) Size(0x10) ]
	void StartUsingExternalEvent(struct UBTNode* NodeOwner, struct AActor* OwningActor);

	// Object: Function AIModule.BTFunctionLibrary.SetBlackboardValueAsVector
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x105cede0c
	// Return & Params: [ Num(3) Size(0x3c) ]
	void SetBlackboardValueAsVector(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key, struct FVector Value);

	// Object: Function AIModule.BTFunctionLibrary.SetBlackboardValueAsString
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105cee04c
	// Return & Params: [ Num(3) Size(0x40) ]
	void SetBlackboardValueAsString(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key, struct FString Value);

	// Object: Function AIModule.BTFunctionLibrary.SetBlackboardValueAsRotator
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x105cedc10
	// Return & Params: [ Num(3) Size(0x3c) ]
	void SetBlackboardValueAsRotator(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key, struct FRotator Value);

	// Object: Function AIModule.BTFunctionLibrary.SetBlackboardValueAsObject
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105cee78c
	// Return & Params: [ Num(3) Size(0x38) ]
	void SetBlackboardValueAsObject(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key, struct UObject* Value);

	// Object: Function AIModule.BTFunctionLibrary.SetBlackboardValueAsName
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105cedf2c
	// Return & Params: [ Num(3) Size(0x38) ]
	void SetBlackboardValueAsName(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key, struct FName Value);

	// Object: Function AIModule.BTFunctionLibrary.SetBlackboardValueAsInt
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105cee42c
	// Return & Params: [ Num(3) Size(0x34) ]
	void SetBlackboardValueAsInt(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key, int32_t Value);

	// Object: Function AIModule.BTFunctionLibrary.SetBlackboardValueAsFloat
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105cee30c
	// Return & Params: [ Num(3) Size(0x34) ]
	void SetBlackboardValueAsFloat(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key, float Value);

	// Object: Function AIModule.BTFunctionLibrary.SetBlackboardValueAsEnum
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105cee54c
	// Return & Params: [ Num(3) Size(0x31) ]
	void SetBlackboardValueAsEnum(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key, char Value);

	// Object: Function AIModule.BTFunctionLibrary.SetBlackboardValueAsClass
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105cee66c
	// Return & Params: [ Num(3) Size(0x38) ]
	void SetBlackboardValueAsClass(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key, struct UObject* Value);

	// Object: Function AIModule.BTFunctionLibrary.SetBlackboardValueAsBool
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105cee1e4
	// Return & Params: [ Num(3) Size(0x31) ]
	void SetBlackboardValueAsBool(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key, bool Value);

	// Object: Function AIModule.BTFunctionLibrary.GetOwnersBlackboard
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x105cef338
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UBlackboardComponent* GetOwnersBlackboard(struct UBTNode* NodeOwner);

	// Object: Function AIModule.BTFunctionLibrary.GetOwnerComponent
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x105cef2b8
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UBehaviorTreeComponent* GetOwnerComponent(struct UBTNode* NodeOwner);

	// Object: Function AIModule.BTFunctionLibrary.GetBlackboardValueAsVector
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x105cee994
	// Return & Params: [ Num(3) Size(0x3c) ]
	struct FVector GetBlackboardValueAsVector(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key);

	// Object: Function AIModule.BTFunctionLibrary.GetBlackboardValueAsString
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x105ceeb60
	// Return & Params: [ Num(3) Size(0x40) ]
	struct FString GetBlackboardValueAsString(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key);

	// Object: Function AIModule.BTFunctionLibrary.GetBlackboardValueAsRotator
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x105cee8ac
	// Return & Params: [ Num(3) Size(0x3c) ]
	struct FRotator GetBlackboardValueAsRotator(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key);

	// Object: Function AIModule.BTFunctionLibrary.GetBlackboardValueAsObject
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x105cef1d4
	// Return & Params: [ Num(3) Size(0x38) ]
	struct UObject* GetBlackboardValueAsObject(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key);

	// Object: Function AIModule.BTFunctionLibrary.GetBlackboardValueAsName
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x105ceea7c
	// Return & Params: [ Num(3) Size(0x38) ]
	struct FName GetBlackboardValueAsName(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key);

	// Object: Function AIModule.BTFunctionLibrary.GetBlackboardValueAsInt
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x105ceee44
	// Return & Params: [ Num(3) Size(0x34) ]
	int32_t GetBlackboardValueAsInt(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key);

	// Object: Function AIModule.BTFunctionLibrary.GetBlackboardValueAsFloat
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x105ceed60
	// Return & Params: [ Num(3) Size(0x34) ]
	float GetBlackboardValueAsFloat(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key);

	// Object: Function AIModule.BTFunctionLibrary.GetBlackboardValueAsEnum
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x105ceef28
	// Return & Params: [ Num(3) Size(0x31) ]
	char GetBlackboardValueAsEnum(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key);

	// Object: Function AIModule.BTFunctionLibrary.GetBlackboardValueAsClass
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x105cef00c
	// Return & Params: [ Num(3) Size(0x38) ]
	struct UObject* GetBlackboardValueAsClass(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key);

	// Object: Function AIModule.BTFunctionLibrary.GetBlackboardValueAsBool
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x105ceec7c
	// Return & Params: [ Num(3) Size(0x31) ]
	bool GetBlackboardValueAsBool(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key);

	// Object: Function AIModule.BTFunctionLibrary.GetBlackboardValueAsActor
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x105cef0f0
	// Return & Params: [ Num(3) Size(0x38) ]
	struct AActor* GetBlackboardValueAsActor(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key);

	// Object: Function AIModule.BTFunctionLibrary.ClearBlackboardValueAsVector
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105cedd30
	// Return & Params: [ Num(2) Size(0x30) ]
	void ClearBlackboardValueAsVector(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key);

	// Object: Function AIModule.BTFunctionLibrary.ClearBlackboardValue
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105cedb34
	// Return & Params: [ Num(2) Size(0x30) ]
	void ClearBlackboardValue(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key);
};

// Object: Class AIModule.BTService_DefaultFocus
// Inherited Bytes: 0x90 | Struct Size: 0x98
struct UBTService_DefaultFocus : UBTService_BlackboardBase {
	// Fields
	char FocusPriority; // Offset: 0x90 | Size: 0x1
	char pad_0x91[0x7]; // Offset: 0x91 | Size: 0x7
};

// Object: Class AIModule.BTService_RunEQS
// Inherited Bytes: 0x90 | Struct Size: 0xe8
struct UBTService_RunEQS : UBTService_BlackboardBase {
	// Fields
	struct FEQSParametrizedQueryExecutionRequest EQSRequest; // Offset: 0x90 | Size: 0x48
	char pad_0xD8[0x10]; // Offset: 0xd8 | Size: 0x10
};

// Object: Class AIModule.BTTask_BlueprintBase
// Inherited Bytes: 0x70 | Struct Size: 0xa8
struct UBTTask_BlueprintBase : UBTTaskNode {
	// Fields
	struct AAIController* AIOwner; // Offset: 0x70 | Size: 0x8
	struct AActor* ActorOwner; // Offset: 0x78 | Size: 0x8
	struct FIntervalCountdown TickInterval; // Offset: 0x80 | Size: 0x8
	char pad_0x88[0x18]; // Offset: 0x88 | Size: 0x18
	char bShowPropertyDetails : 1; // Offset: 0xa0 | Size: 0x1
	char pad_0xA0_1 : 7; // Offset: 0xa0 | Size: 0x1
	char pad_0xA1[0x7]; // Offset: 0xa1 | Size: 0x7

	// Functions

	// Object: Function AIModule.BTTask_BlueprintBase.SetFinishOnMessageWithId
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x105cf0ddc
	// Return & Params: [ Num(2) Size(0xc) ]
	void SetFinishOnMessageWithId(struct FName MessageName, int32_t RequestID);

	// Object: Function AIModule.BTTask_BlueprintBase.SetFinishOnMessage
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x105cf0ea8
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetFinishOnMessage(struct FName MessageName);

	// Object: Function AIModule.BTTask_BlueprintBase.ReceiveTickAI
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(3) Size(0x14) ]
	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds);

	// Object: Function AIModule.BTTask_BlueprintBase.ReceiveTick
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(2) Size(0xc) ]
	void ReceiveTick(struct AActor* OwnerActor, float DeltaSeconds);

	// Object: Function AIModule.BTTask_BlueprintBase.ReceiveExecuteAI
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(2) Size(0x10) ]
	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn);

	// Object: Function AIModule.BTTask_BlueprintBase.ReceiveExecute
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x8) ]
	void ReceiveExecute(struct AActor* OwnerActor);

	// Object: Function AIModule.BTTask_BlueprintBase.ReceiveAbortAI
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(2) Size(0x10) ]
	void ReceiveAbortAI(struct AAIController* OwnerController, struct APawn* ControlledPawn);

	// Object: Function AIModule.BTTask_BlueprintBase.ReceiveAbort
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x8) ]
	void ReceiveAbort(struct AActor* OwnerActor);

	// Object: Function AIModule.BTTask_BlueprintBase.IsTaskExecuting
	// Flags: [Final|Native|Protected|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105cf0da8
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsTaskExecuting();

	// Object: Function AIModule.BTTask_BlueprintBase.IsTaskAborting
	// Flags: [Final|Native|Protected|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105cf0d74
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsTaskAborting();

	// Object: Function AIModule.BTTask_BlueprintBase.FinishExecute
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x105cf0f3c
	// Return & Params: [ Num(1) Size(0x1) ]
	void FinishExecute(bool bSuccess);

	// Object: Function AIModule.BTTask_BlueprintBase.FinishAbort
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x105cf0f28
	// Return & Params: [ Num(0) Size(0x0) ]
	void FinishAbort();
};

// Object: Class AIModule.BTTask_FinishWithResult
// Inherited Bytes: 0x70 | Struct Size: 0x70
struct UBTTask_FinishWithResult : UBTTaskNode {
	// Fields
	enum class EBTNodeResult Result; // Offset: 0x69 | Size: 0x1
};

// Object: Class AIModule.BTTask_GameplayTaskBase
// Inherited Bytes: 0x70 | Struct Size: 0x70
struct UBTTask_GameplayTaskBase : UBTTaskNode {
	// Fields
	char bWaitForGameplayTask : 1; // Offset: 0x69 | Size: 0x1
};

// Object: Class AIModule.BTTask_MakeNoise
// Inherited Bytes: 0x70 | Struct Size: 0x70
struct UBTTask_MakeNoise : UBTTaskNode {
	// Fields
	float Loudnes; // Offset: 0x6c | Size: 0x4
};

// Object: Class AIModule.BTTask_MoveDirectlyToward
// Inherited Bytes: 0xb0 | Struct Size: 0xb0
struct UBTTask_MoveDirectlyToward : UBTTask_MoveTo {
	// Fields
	char bDisablePathUpdateOnGoalLocationChange : 1; // Offset: 0xae | Size: 0x1
	char bProjectVectorGoalToNavigation : 1; // Offset: 0xae | Size: 0x1
	char bUpdatedDeprecatedProperties : 1; // Offset: 0xae | Size: 0x1
};

// Object: Class AIModule.BTTask_PawnActionBase
// Inherited Bytes: 0x70 | Struct Size: 0x70
struct UBTTask_PawnActionBase : UBTTaskNode {
};

// Object: Class AIModule.BTTask_PlayAnimation
// Inherited Bytes: 0x70 | Struct Size: 0xb0
struct UBTTask_PlayAnimation : UBTTaskNode {
	// Fields
	struct UAnimationAsset* AnimationToPlay; // Offset: 0x70 | Size: 0x8
	char bLooping : 1; // Offset: 0x78 | Size: 0x1
	char bNonBlocking : 1; // Offset: 0x78 | Size: 0x1
	char pad_0x78_2 : 6; // Offset: 0x78 | Size: 0x1
	char pad_0x79[0x7]; // Offset: 0x79 | Size: 0x7
	struct UBehaviorTreeComponent* MyOwnerComp; // Offset: 0x80 | Size: 0x8
	struct USkeletalMeshComponent* CachedSkelMesh; // Offset: 0x88 | Size: 0x8
	char pad_0x90[0x20]; // Offset: 0x90 | Size: 0x20
};

// Object: Class AIModule.BTTask_PlaySound
// Inherited Bytes: 0x70 | Struct Size: 0x78
struct UBTTask_PlaySound : UBTTaskNode {
	// Fields
	struct USoundCue* SoundToPlay; // Offset: 0x70 | Size: 0x8
};

// Object: Class AIModule.BTTask_PushPawnAction
// Inherited Bytes: 0x70 | Struct Size: 0x78
struct UBTTask_PushPawnAction : UBTTask_PawnActionBase {
	// Fields
	struct UPawnAction* Action; // Offset: 0x70 | Size: 0x8
};

// Object: Class AIModule.BTTask_RotateToFaceBBEntry
// Inherited Bytes: 0x98 | Struct Size: 0xa0
struct UBTTask_RotateToFaceBBEntry : UBTTask_BlackboardBase {
	// Fields
	float Precision; // Offset: 0x98 | Size: 0x4
	char pad_0x9C[0x4]; // Offset: 0x9c | Size: 0x4
};

// Object: Class AIModule.BTTask_RunBehavior
// Inherited Bytes: 0x70 | Struct Size: 0x78
struct UBTTask_RunBehavior : UBTTaskNode {
	// Fields
	struct UBehaviorTree* BehaviorAsset; // Offset: 0x70 | Size: 0x8
};

// Object: Class AIModule.BTTask_RunEQSQuery
// Inherited Bytes: 0x98 | Struct Size: 0x150
struct UBTTask_RunEQSQuery : UBTTask_BlackboardBase {
	// Fields
	struct UEnvQuery* QueryTemplate; // Offset: 0x98 | Size: 0x8
	struct TArray<struct FEnvNamedValue> QueryParams; // Offset: 0xa0 | Size: 0x10
	struct TArray<struct FAIDynamicParam> QueryConfig; // Offset: 0xb0 | Size: 0x10
	enum class EEnvQueryRunMode RunMode; // Offset: 0xc0 | Size: 0x1
	char pad_0xC1[0x7]; // Offset: 0xc1 | Size: 0x7
	struct FBlackboardKeySelector EQSQueryBlackboardKey; // Offset: 0xc8 | Size: 0x28
	bool bUseBBKey; // Offset: 0xf0 | Size: 0x1
	char pad_0xF1[0x7]; // Offset: 0xf1 | Size: 0x7
	struct FEQSParametrizedQueryExecutionRequest EQSRequest; // Offset: 0xf8 | Size: 0x48
	char pad_0x140[0x10]; // Offset: 0x140 | Size: 0x10
};

// Object: Class AIModule.BTTask_SetTagCooldown
// Inherited Bytes: 0x70 | Struct Size: 0x80
struct UBTTask_SetTagCooldown : UBTTaskNode {
	// Fields
	struct FGameplayTag CooldownTag; // Offset: 0x6c | Size: 0x8
	bool bAddToExistingDuration; // Offset: 0x74 | Size: 0x1
	float CoolDownDuration; // Offset: 0x78 | Size: 0x4
	char pad_0x7D[0x3]; // Offset: 0x7d | Size: 0x3
};

// Object: Class AIModule.BTTask_Wait
// Inherited Bytes: 0x70 | Struct Size: 0x78
struct UBTTask_Wait : UBTTaskNode {
	// Fields
	float WaitTime; // Offset: 0x6c | Size: 0x4
	float RandomDeviation; // Offset: 0x70 | Size: 0x4
};

// Object: Class AIModule.BTTask_WaitBlackboardTime
// Inherited Bytes: 0x78 | Struct Size: 0xa0
struct UBTTask_WaitBlackboardTime : UBTTask_Wait {
	// Fields
	struct FBlackboardKeySelector BlackboardKey; // Offset: 0x78 | Size: 0x28
};

// Object: Class AIModule.CrowdAgentInterface
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UCrowdAgentInterface : UInterface {
};

// Object: Class AIModule.CrowdManager
// Inherited Bytes: 0x28 | Struct Size: 0xf0
struct UCrowdManager : UCrowdManagerBase {
	// Fields
	struct ANavigationData* MyNavData; // Offset: 0x28 | Size: 0x8
	struct TArray<struct FCrowdAvoidanceConfig> AvoidanceConfig; // Offset: 0x30 | Size: 0x10
	struct TArray<struct FCrowdAvoidanceSamplingPattern> SamplingPatterns; // Offset: 0x40 | Size: 0x10
	int32_t MaxAgents; // Offset: 0x50 | Size: 0x4
	float MaxAgentRadius; // Offset: 0x54 | Size: 0x4
	int32_t MaxAvoidedAgents; // Offset: 0x58 | Size: 0x4
	int32_t MaxAvoidedWalls; // Offset: 0x5c | Size: 0x4
	float NavmeshCheckInterval; // Offset: 0x60 | Size: 0x4
	float PathOptimizationInterval; // Offset: 0x64 | Size: 0x4
	float SeparationDirClamp; // Offset: 0x68 | Size: 0x4
	float PathOffsetRadiusMultiplier; // Offset: 0x6c | Size: 0x4
	char pad_0x70_0 : 4; // Offset: 0x70 | Size: 0x1
	char bResolveCollisions : 1; // Offset: 0x70 | Size: 0x1
	char pad_0x70_5 : 3; // Offset: 0x70 | Size: 0x1
	char pad_0x71[0x7f]; // Offset: 0x71 | Size: 0x7f
};

// Object: Class AIModule.DetourCrowdAIController
// Inherited Bytes: 0x348 | Struct Size: 0x348
struct ADetourCrowdAIController : AAIController {
};

// Object: Class AIModule.EnvQuery
// Inherited Bytes: 0x30 | Struct Size: 0x48
struct UEnvQuery : UDataAsset {
	// Fields
	struct FName QueryName; // Offset: 0x30 | Size: 0x8
	struct TArray<struct UEnvQueryOption*> options; // Offset: 0x38 | Size: 0x10
};

// Object: Class AIModule.EnvQueryContext_BlueprintBase
// Inherited Bytes: 0x28 | Struct Size: 0x30
struct UEnvQueryContext_BlueprintBase : UEnvQueryContext {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8

	// Functions

	// Object: Function AIModule.EnvQueryContext_BlueprintBase.ProvideSingleLocation
	// Flags: [Event|Public|HasOutParms|HasDefaults|BlueprintEvent|Const]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(3) Size(0x1c) ]
	void ProvideSingleLocation(struct UObject* QuerierObject, struct AActor* QuerierActor, struct FVector& ResultingLocation);

	// Object: Function AIModule.EnvQueryContext_BlueprintBase.ProvideSingleActor
	// Flags: [Event|Public|HasOutParms|BlueprintEvent|Const]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(3) Size(0x18) ]
	void ProvideSingleActor(struct UObject* QuerierObject, struct AActor* QuerierActor, struct AActor*& ResultingActor);

	// Object: Function AIModule.EnvQueryContext_BlueprintBase.ProvideLocationsSet
	// Flags: [Event|Public|HasOutParms|BlueprintEvent|Const]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(3) Size(0x20) ]
	void ProvideLocationsSet(struct UObject* QuerierObject, struct AActor* QuerierActor, struct TArray<struct FVector>& ResultingLocationSet);

	// Object: Function AIModule.EnvQueryContext_BlueprintBase.ProvideActorsSet
	// Flags: [Event|Public|HasOutParms|BlueprintEvent|Const]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(3) Size(0x20) ]
	void ProvideActorsSet(struct UObject* QuerierObject, struct AActor* QuerierActor, struct TArray<struct AActor*>& ResultingActorsSet);
};

// Object: Class AIModule.EnvQueryContext_Item
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UEnvQueryContext_Item : UEnvQueryContext {
};

// Object: Class AIModule.EnvQueryContext_Querier
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UEnvQueryContext_Querier : UEnvQueryContext {
};

// Object: Class AIModule.EnvQueryDebugHelpers
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UEnvQueryDebugHelpers : UObject {
};

// Object: Class AIModule.EnvQueryGenerator
// Inherited Bytes: 0x30 | Struct Size: 0x50
struct UEnvQueryGenerator : UEnvQueryNode {
	// Fields
	struct FString OptionName; // Offset: 0x30 | Size: 0x10
	struct UEnvQueryItemType* ItemType; // Offset: 0x40 | Size: 0x8
	char bAutoSortTests : 1; // Offset: 0x48 | Size: 0x1
	char pad_0x48_1 : 7; // Offset: 0x48 | Size: 0x1
	char pad_0x49[0x7]; // Offset: 0x49 | Size: 0x7
};

// Object: Class AIModule.EnvQueryGenerator_ActorsOfClass
// Inherited Bytes: 0x50 | Struct Size: 0xd0
struct UEnvQueryGenerator_ActorsOfClass : UEnvQueryGenerator {
	// Fields
	struct AActor* SearchedActorClass; // Offset: 0x50 | Size: 0x8
	struct FAIDataProviderBoolValue GenerateOnlyActorsInRadius; // Offset: 0x58 | Size: 0x38
	struct FAIDataProviderFloatValue SearchRadius; // Offset: 0x90 | Size: 0x38
	struct UEnvQueryContext* SearchCenter; // Offset: 0xc8 | Size: 0x8
};

// Object: Class AIModule.EnvQueryGenerator_BlueprintBase
// Inherited Bytes: 0x50 | Struct Size: 0x80
struct UEnvQueryGenerator_BlueprintBase : UEnvQueryGenerator {
	// Fields
	struct FText GeneratorsActionDescription; // Offset: 0x50 | Size: 0x18
	struct UEnvQueryContext* Context; // Offset: 0x68 | Size: 0x8
	struct UEnvQueryItemType* GeneratedItemType; // Offset: 0x70 | Size: 0x8
	char pad_0x78[0x8]; // Offset: 0x78 | Size: 0x8

	// Functions

	// Object: Function AIModule.EnvQueryGenerator_BlueprintBase.GetQuerier
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105cf6cfc
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UObject* GetQuerier();

	// Object: Function AIModule.EnvQueryGenerator_BlueprintBase.DoItemGeneration
	// Flags: [Event|Public|HasOutParms|BlueprintEvent|Const]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x10) ]
	void DoItemGeneration(struct TArray<struct FVector>& ContextLocations);

	// Object: Function AIModule.EnvQueryGenerator_BlueprintBase.AddGeneratedVector
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|Const]
	// Offset: 0x105cf6db0
	// Return & Params: [ Num(1) Size(0xc) ]
	void AddGeneratedVector(struct FVector GeneratedVector);

	// Object: Function AIModule.EnvQueryGenerator_BlueprintBase.AddGeneratedActor
	// Flags: [Final|Native|Public|BlueprintCallable|Const]
	// Offset: 0x105cf6d30
	// Return & Params: [ Num(1) Size(0x8) ]
	void AddGeneratedActor(struct AActor* GeneratedActor);
};

// Object: Class AIModule.EnvQueryGenerator_Composite
// Inherited Bytes: 0x50 | Struct Size: 0x70
struct UEnvQueryGenerator_Composite : UEnvQueryGenerator {
	// Fields
	struct TArray<struct UEnvQueryGenerator*> Generators; // Offset: 0x50 | Size: 0x10
	char bAllowDifferentItemTypes : 1; // Offset: 0x60 | Size: 0x1
	char bHasMatchingItemType : 1; // Offset: 0x60 | Size: 0x1
	char pad_0x60_2 : 6; // Offset: 0x60 | Size: 0x1
	char pad_0x61[0x7]; // Offset: 0x61 | Size: 0x7
	struct UEnvQueryItemType* ForcedItemType; // Offset: 0x68 | Size: 0x8
};

// Object: Class AIModule.EnvQueryGenerator_ProjectedPoints
// Inherited Bytes: 0x50 | Struct Size: 0x80
struct UEnvQueryGenerator_ProjectedPoints : UEnvQueryGenerator {
	// Fields
	struct FEnvTraceData ProjectionData; // Offset: 0x50 | Size: 0x30
};

// Object: Class AIModule.EnvQueryGenerator_Cone
// Inherited Bytes: 0x80 | Struct Size: 0x170
struct UEnvQueryGenerator_Cone : UEnvQueryGenerator_ProjectedPoints {
	// Fields
	struct FAIDataProviderFloatValue AlignedPointsDistance; // Offset: 0x80 | Size: 0x38
	struct FAIDataProviderFloatValue ConeDegrees; // Offset: 0xb8 | Size: 0x38
	struct FAIDataProviderFloatValue AngleStep; // Offset: 0xf0 | Size: 0x38
	struct FAIDataProviderFloatValue Range; // Offset: 0x128 | Size: 0x38
	struct UEnvQueryContext* CenterActor; // Offset: 0x160 | Size: 0x8
	char bIncludeContextLocation : 1; // Offset: 0x168 | Size: 0x1
	char pad_0x168_1 : 7; // Offset: 0x168 | Size: 0x1
	char pad_0x169[0x7]; // Offset: 0x169 | Size: 0x7
};

// Object: Class AIModule.EnvQueryGenerator_CurrentLocation
// Inherited Bytes: 0x50 | Struct Size: 0x58
struct UEnvQueryGenerator_CurrentLocation : UEnvQueryGenerator {
	// Fields
	struct UEnvQueryContext* QueryContext; // Offset: 0x50 | Size: 0x8
};

// Object: Class AIModule.EnvQueryGenerator_Donut
// Inherited Bytes: 0x80 | Struct Size: 0x1d0
struct UEnvQueryGenerator_Donut : UEnvQueryGenerator_ProjectedPoints {
	// Fields
	struct FAIDataProviderFloatValue InnerRadius; // Offset: 0x80 | Size: 0x38
	struct FAIDataProviderFloatValue OuterRadius; // Offset: 0xb8 | Size: 0x38
	struct FAIDataProviderIntValue NumberOfRings; // Offset: 0xf0 | Size: 0x38
	struct FAIDataProviderIntValue PointsPerRing; // Offset: 0x128 | Size: 0x38
	struct FEnvDirection ArcDirection; // Offset: 0x160 | Size: 0x20
	struct FAIDataProviderFloatValue ArcAngle; // Offset: 0x180 | Size: 0x38
	bool bUseSpiralPattern; // Offset: 0x1b8 | Size: 0x1
	char pad_0x1B9[0x7]; // Offset: 0x1b9 | Size: 0x7
	struct UEnvQueryContext* Center; // Offset: 0x1c0 | Size: 0x8
	char bDefineArc : 1; // Offset: 0x1c8 | Size: 0x1
	char pad_0x1C8_1 : 7; // Offset: 0x1c8 | Size: 0x1
	char pad_0x1C9[0x7]; // Offset: 0x1c9 | Size: 0x7
};

// Object: Class AIModule.EnvQueryGenerator_OnCircle
// Inherited Bytes: 0x80 | Struct Size: 0x210
struct UEnvQueryGenerator_OnCircle : UEnvQueryGenerator_ProjectedPoints {
	// Fields
	struct FAIDataProviderFloatValue CircleRadius; // Offset: 0x80 | Size: 0x38
	struct FAIDataProviderFloatValue SpaceBetween; // Offset: 0xb8 | Size: 0x38
	struct FAIDataProviderIntValue NumberOfPoints; // Offset: 0xf0 | Size: 0x38
	enum class EPointOnCircleSpacingMethod PointOnCircleSpacingMethod; // Offset: 0x128 | Size: 0x1
	char pad_0x129[0x7]; // Offset: 0x129 | Size: 0x7
	struct FEnvDirection ArcDirection; // Offset: 0x130 | Size: 0x20
	struct FAIDataProviderFloatValue ArcAngle; // Offset: 0x150 | Size: 0x38
	float AngleRadians; // Offset: 0x188 | Size: 0x4
	char pad_0x18C[0x4]; // Offset: 0x18c | Size: 0x4
	struct UEnvQueryContext* CircleCenter; // Offset: 0x190 | Size: 0x8
	bool bIgnoreAnyContextActorsWhenGeneratingCircle; // Offset: 0x198 | Size: 0x1
	char pad_0x199[0x7]; // Offset: 0x199 | Size: 0x7
	struct FAIDataProviderFloatValue CircleCenterZOffset; // Offset: 0x1a0 | Size: 0x38
	struct FEnvTraceData TraceData; // Offset: 0x1d8 | Size: 0x30
	char bDefineArc : 1; // Offset: 0x208 | Size: 0x1
	char pad_0x208_1 : 7; // Offset: 0x208 | Size: 0x1
	char pad_0x209[0x7]; // Offset: 0x209 | Size: 0x7
};

// Object: Class AIModule.EnvQueryGenerator_SimpleGrid
// Inherited Bytes: 0x80 | Struct Size: 0xf8
struct UEnvQueryGenerator_SimpleGrid : UEnvQueryGenerator_ProjectedPoints {
	// Fields
	struct FAIDataProviderFloatValue GridSize; // Offset: 0x80 | Size: 0x38
	struct FAIDataProviderFloatValue SpaceBetween; // Offset: 0xb8 | Size: 0x38
	struct UEnvQueryContext* GenerateAround; // Offset: 0xf0 | Size: 0x8
};

// Object: Class AIModule.EnvQueryGenerator_PathingGrid
// Inherited Bytes: 0xf8 | Struct Size: 0x170
struct UEnvQueryGenerator_PathingGrid : UEnvQueryGenerator_SimpleGrid {
	// Fields
	struct FAIDataProviderBoolValue PathToItem; // Offset: 0xf8 | Size: 0x38
	struct UNavigationQueryFilter* NavigationFilter; // Offset: 0x130 | Size: 0x8
	struct FAIDataProviderFloatValue ScanRangeMultiplier; // Offset: 0x138 | Size: 0x38
};

// Object: Class AIModule.EnvQueryInstanceBlueprintWrapper
// Inherited Bytes: 0x28 | Struct Size: 0x78
struct UEnvQueryInstanceBlueprintWrapper : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
	int32_t QueryID; // Offset: 0x30 | Size: 0x4
	char pad_0x34[0x24]; // Offset: 0x34 | Size: 0x24
	struct UEnvQueryItemType* ItemType; // Offset: 0x58 | Size: 0x8
	int32_t OptionIndex; // Offset: 0x60 | Size: 0x4
	char pad_0x64[0x4]; // Offset: 0x64 | Size: 0x4
	struct FMulticastInlineDelegate OnQueryFinishedEvent; // Offset: 0x68 | Size: 0x10

	// Functions

	// Object: Function AIModule.EnvQueryInstanceBlueprintWrapper.SetNamedParam
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105cfb3cc
	// Return & Params: [ Num(2) Size(0xc) ]
	void SetNamedParam(struct FName ParamName, float Value);

	// Object: Function AIModule.EnvQueryInstanceBlueprintWrapper.GetResultsAsLocations
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105cfb498
	// Return & Params: [ Num(1) Size(0x10) ]
	struct TArray<struct FVector> GetResultsAsLocations();

	// Object: Function AIModule.EnvQueryInstanceBlueprintWrapper.GetResultsAsActors
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105cfb518
	// Return & Params: [ Num(1) Size(0x10) ]
	struct TArray<struct AActor*> GetResultsAsActors();

	// Object: Function AIModule.EnvQueryInstanceBlueprintWrapper.GetQueryResultsAsLocations
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|Const]
	// Offset: 0x105cfb598
	// Return & Params: [ Num(2) Size(0x11) ]
	bool GetQueryResultsAsLocations(struct TArray<struct FVector>& ResultLocations);

	// Object: Function AIModule.EnvQueryInstanceBlueprintWrapper.GetQueryResultsAsActors
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|Const]
	// Offset: 0x105cfb640
	// Return & Params: [ Num(2) Size(0x11) ]
	bool GetQueryResultsAsActors(struct TArray<struct AActor*>& ResultActors);

	// Object: Function AIModule.EnvQueryInstanceBlueprintWrapper.GetItemScore
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105cfb6e8
	// Return & Params: [ Num(2) Size(0x8) ]
	float GetItemScore(int32_t ItemIndex);

	// Object: DelegateFunction AIModule.EnvQueryInstanceBlueprintWrapper.EQSQueryDoneSignature__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(2) Size(0x9) ]
	void EQSQueryDoneSignature__DelegateSignature(struct UEnvQueryInstanceBlueprintWrapper* QueryInstance, enum class EEnvQueryStatus QueryStatus);
};

// Object: Class AIModule.EnvQueryItemType
// Inherited Bytes: 0x28 | Struct Size: 0x30
struct UEnvQueryItemType : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
};

// Object: Class AIModule.EnvQueryItemType_VectorBase
// Inherited Bytes: 0x30 | Struct Size: 0x30
struct UEnvQueryItemType_VectorBase : UEnvQueryItemType {
};

// Object: Class AIModule.EnvQueryItemType_ActorBase
// Inherited Bytes: 0x30 | Struct Size: 0x30
struct UEnvQueryItemType_ActorBase : UEnvQueryItemType_VectorBase {
};

// Object: Class AIModule.EnvQueryItemType_Actor
// Inherited Bytes: 0x30 | Struct Size: 0x30
struct UEnvQueryItemType_Actor : UEnvQueryItemType_ActorBase {
};

// Object: Class AIModule.EnvQueryItemType_Direction
// Inherited Bytes: 0x30 | Struct Size: 0x30
struct UEnvQueryItemType_Direction : UEnvQueryItemType_VectorBase {
};

// Object: Class AIModule.EnvQueryItemType_Point
// Inherited Bytes: 0x30 | Struct Size: 0x30
struct UEnvQueryItemType_Point : UEnvQueryItemType_VectorBase {
};

// Object: Class AIModule.EnvQueryManager
// Inherited Bytes: 0x40 | Struct Size: 0x148
struct UEnvQueryManager : UAISubsystem {
	// Fields
	char pad_0x40[0x70]; // Offset: 0x40 | Size: 0x70
	struct TArray<struct FEnvQueryInstanceCache> InstanceCache; // Offset: 0xb0 | Size: 0x10
	struct TArray<struct UEnvQueryContext*> LocalContexts; // Offset: 0xc0 | Size: 0x10
	struct TArray<struct UEnvQueryInstanceBlueprintWrapper*> GCShieldedWrappers; // Offset: 0xd0 | Size: 0x10
	char pad_0xE0[0x54]; // Offset: 0xe0 | Size: 0x54
	float MaxAllowedTestingTime; // Offset: 0x134 | Size: 0x4
	bool bTestQueriesUsingBreadth; // Offset: 0x138 | Size: 0x1
	char pad_0x139[0x3]; // Offset: 0x139 | Size: 0x3
	int32_t QueryCountWarningThreshold; // Offset: 0x13c | Size: 0x4
	double QueryCountWarningInterval; // Offset: 0x140 | Size: 0x8

	// Functions

	// Object: Function AIModule.EnvQueryManager.RunEQSQuery
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105cfca1c
	// Return & Params: [ Num(6) Size(0x30) ]
	struct UEnvQueryInstanceBlueprintWrapper* RunEQSQuery(struct UObject* WorldContextObject, struct UEnvQuery* QueryTemplate, struct UObject* Querier, enum class EEnvQueryRunMode RunMode, struct UEnvQueryInstanceBlueprintWrapper* WrapperClass);
};

// Object: Class AIModule.EnvQueryOption
// Inherited Bytes: 0x28 | Struct Size: 0x40
struct UEnvQueryOption : UObject {
	// Fields
	struct UEnvQueryGenerator* Generator; // Offset: 0x28 | Size: 0x8
	struct TArray<struct UEnvQueryTest*> Tests; // Offset: 0x30 | Size: 0x10
};

// Object: Class AIModule.EnvQueryTest_Distance
// Inherited Bytes: 0x1f8 | Struct Size: 0x200
struct UEnvQueryTest_Distance : UEnvQueryTest {
	// Fields
	enum class EEnvTestDistance TestMode; // Offset: 0x1f1 | Size: 0x1
	struct UEnvQueryContext* DistanceTo; // Offset: 0x1f8 | Size: 0x8
};

// Object: Class AIModule.EnvQueryTest_Dot
// Inherited Bytes: 0x1f8 | Struct Size: 0x240
struct UEnvQueryTest_Dot : UEnvQueryTest {
	// Fields
	struct FEnvDirection LineA; // Offset: 0x1f8 | Size: 0x20
	struct FEnvDirection LineB; // Offset: 0x218 | Size: 0x20
	enum class EEnvTestDot TestMode; // Offset: 0x238 | Size: 0x1
	bool bAbsoluteValue; // Offset: 0x239 | Size: 0x1
	char pad_0x23A[0x6]; // Offset: 0x23a | Size: 0x6
};

// Object: Class AIModule.EnvQueryTest_GameplayTags
// Inherited Bytes: 0x1f8 | Struct Size: 0x268
struct UEnvQueryTest_GameplayTags : UEnvQueryTest {
	// Fields
	struct FGameplayTagQuery TagQueryToMatch; // Offset: 0x1f8 | Size: 0x48
	bool bUpdatedToUseQuery; // Offset: 0x240 | Size: 0x1
	enum class EGameplayContainerMatchType TagsToMatch; // Offset: 0x241 | Size: 0x1
	char pad_0x242[0x6]; // Offset: 0x242 | Size: 0x6
	struct FGameplayTagContainer GameplayTags; // Offset: 0x248 | Size: 0x20
};

// Object: Class AIModule.EnvQueryTest_Overlap
// Inherited Bytes: 0x1f8 | Struct Size: 0x210
struct UEnvQueryTest_Overlap : UEnvQueryTest {
	// Fields
	struct FEnvOverlapData OverlapData; // Offset: 0x1f4 | Size: 0x1c
};

// Object: Class AIModule.EnvQueryTest_PathfindingBatch
// Inherited Bytes: 0x278 | Struct Size: 0x2b0
struct UEnvQueryTest_PathfindingBatch : UEnvQueryTest_Pathfinding {
	// Fields
	struct FAIDataProviderFloatValue ScanRangeMultiplier; // Offset: 0x278 | Size: 0x38
};

// Object: Class AIModule.EnvQueryTest_Project
// Inherited Bytes: 0x1f8 | Struct Size: 0x228
struct UEnvQueryTest_Project : UEnvQueryTest {
	// Fields
	struct FEnvTraceData ProjectionData; // Offset: 0x1f8 | Size: 0x30
};

// Object: Class AIModule.EnvQueryTest_Random
// Inherited Bytes: 0x1f8 | Struct Size: 0x1f8
struct UEnvQueryTest_Random : UEnvQueryTest {
};

// Object: Class AIModule.EnvQueryTest_Volume
// Inherited Bytes: 0x1f8 | Struct Size: 0x210
struct UEnvQueryTest_Volume : UEnvQueryTest {
	// Fields
	struct UEnvQueryContext* VolumeContext; // Offset: 0x1f8 | Size: 0x8
	struct AVolume* VolumeClass; // Offset: 0x200 | Size: 0x8
	char bDoComplexVolumeTest : 1; // Offset: 0x208 | Size: 0x1
	char pad_0x208_1 : 7; // Offset: 0x208 | Size: 0x1
	char pad_0x209[0x7]; // Offset: 0x209 | Size: 0x7
};

// Object: Class AIModule.EnvQueryTypes
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UEnvQueryTypes : UObject {
};

// Object: Class AIModule.EQSQueryResultSourceInterface
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UEQSQueryResultSourceInterface : UInterface {
};

// Object: Class AIModule.EQSRenderingComponent
// Inherited Bytes: 0x5b0 | Struct Size: 0x5e0
struct UEQSRenderingComponent : UPrimitiveComponent {
	// Fields
	char pad_0x5B0[0x30]; // Offset: 0x5b0 | Size: 0x30
};

// Object: Class AIModule.EQSTestingPawn
// Inherited Bytes: 0x4d0 | Struct Size: 0x560
struct AEQSTestingPawn : ACharacter {
	// Fields
	struct UEnvQuery* QueryTemplate; // Offset: 0x4d0 | Size: 0x8
	struct TArray<struct FEnvNamedValue> QueryParams; // Offset: 0x4d8 | Size: 0x10
	struct TArray<struct FAIDynamicParam> QueryConfig; // Offset: 0x4e8 | Size: 0x10
	float TimeLimitPerStep; // Offset: 0x4f8 | Size: 0x4
	int32_t StepToDebugDraw; // Offset: 0x4fc | Size: 0x4
	enum class EEnvQueryHightlightMode HighlightMode; // Offset: 0x500 | Size: 0x1
	char bDrawLabels : 1; // Offset: 0x501 | Size: 0x1
	char bDrawFailedItems : 1; // Offset: 0x501 | Size: 0x1
	char bReRunQueryOnlyOnFinishedMove : 1; // Offset: 0x501 | Size: 0x1
	char bShouldBeVisibleInGame : 1; // Offset: 0x501 | Size: 0x1
	char bTickDuringGame : 1; // Offset: 0x501 | Size: 0x1
	char pad_0x501_5 : 3; // Offset: 0x501 | Size: 0x1
	enum class EEnvQueryRunMode QueryingMode; // Offset: 0x502 | Size: 0x1
	char pad_0x503[0x5]; // Offset: 0x503 | Size: 0x5
	struct FNavAgentProperties NavAgentProperties; // Offset: 0x508 | Size: 0x30
	char pad_0x538[0x28]; // Offset: 0x538 | Size: 0x28
};

// Object: Class AIModule.GenericTeamAgentInterface
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UGenericTeamAgentInterface : UInterface {
};

// Object: Class AIModule.GridPathAIController
// Inherited Bytes: 0x348 | Struct Size: 0x348
struct AGridPathAIController : AAIController {
};

// Object: Class AIModule.GridPathFollowingComponent
// Inherited Bytes: 0x260 | Struct Size: 0x290
struct UGridPathFollowingComponent : UPathFollowingComponent {
	// Fields
	struct UNavLocalGridManager* GridManager; // Offset: 0x260 | Size: 0x8
	char pad_0x268[0x28]; // Offset: 0x268 | Size: 0x28
};

// Object: Class AIModule.NavFilter_AIControllerDefault
// Inherited Bytes: 0x48 | Struct Size: 0x48
struct UNavFilter_AIControllerDefault : UNavigationQueryFilter {
};

// Object: Class AIModule.NavLocalGridManager
// Inherited Bytes: 0x28 | Struct Size: 0x58
struct UNavLocalGridManager : UObject {
	// Fields
	char pad_0x28[0x30]; // Offset: 0x28 | Size: 0x30

	// Functions

	// Object: Function AIModule.NavLocalGridManager.SetLocalNavigationGridDensity
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105d04d74
	// Return & Params: [ Num(3) Size(0xd) ]
	bool SetLocalNavigationGridDensity(struct UObject* WorldContextObject, float CellSize);

	// Object: Function AIModule.NavLocalGridManager.RemoveLocalNavigationGrid
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105d04414
	// Return & Params: [ Num(3) Size(0xd) ]
	void RemoveLocalNavigationGrid(struct UObject* WorldContextObject, int32_t GridId, bool bRebuildGrids);

	// Object: Function AIModule.NavLocalGridManager.FindLocalNavigationGridPath
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x105d04294
	// Return & Params: [ Num(5) Size(0x31) ]
	bool FindLocalNavigationGridPath(struct UObject* WorldContextObject, struct FVector& Start, struct FVector& End, struct TArray<struct FVector>& PathPoints);

	// Object: Function AIModule.NavLocalGridManager.AddLocalNavigationGridForPoints
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105d049dc
	// Return & Params: [ Num(6) Size(0x28) ]
	int32_t AddLocalNavigationGridForPoints(struct UObject* WorldContextObject, struct TArray<struct FVector>& Locations, int32_t Radius2D, float Height, bool bRebuildGrids);

	// Object: Function AIModule.NavLocalGridManager.AddLocalNavigationGridForPoint
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x105d04bac
	// Return & Params: [ Num(6) Size(0x24) ]
	int32_t AddLocalNavigationGridForPoint(struct UObject* WorldContextObject, struct FVector& Location, int32_t Radius2D, float Height, bool bRebuildGrids);

	// Object: Function AIModule.NavLocalGridManager.AddLocalNavigationGridForCapsule
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x105d04528
	// Return & Params: [ Num(8) Size(0x2c) ]
	int32_t AddLocalNavigationGridForCapsule(struct UObject* WorldContextObject, struct FVector& Location, float CapsuleRadius, float CapsuleHalfHeight, int32_t Radius2D, float Height, bool bRebuildGrids);

	// Object: Function AIModule.NavLocalGridManager.AddLocalNavigationGridForBox
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x105d04784
	// Return & Params: [ Num(8) Size(0x3c) ]
	int32_t AddLocalNavigationGridForBox(struct UObject* WorldContextObject, struct FVector& Location, struct FVector Extent, struct FRotator Rotation, int32_t Radius2D, float Height, bool bRebuildGrids);
};

// Object: Class AIModule.PathFollowingManager
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UPathFollowingManager : UObject {
};

// Object: Class AIModule.PawnAction
// Inherited Bytes: 0x28 | Struct Size: 0x98
struct UPawnAction : UObject {
	// Fields
	struct UPawnAction* ChildAction; // Offset: 0x28 | Size: 0x8
	struct UPawnAction* ParentAction; // Offset: 0x30 | Size: 0x8
	struct UPawnActionsComponent* OwnerComponent; // Offset: 0x38 | Size: 0x8
	struct UObject* Instigator; // Offset: 0x40 | Size: 0x8
	struct UBrainComponent* BrainComp; // Offset: 0x48 | Size: 0x8
	char pad_0x50[0x30]; // Offset: 0x50 | Size: 0x30
	char bAllowNewSameClassInstance : 1; // Offset: 0x80 | Size: 0x1
	char bReplaceActiveSameClassInstance : 1; // Offset: 0x80 | Size: 0x1
	char bShouldPauseMovement : 1; // Offset: 0x80 | Size: 0x1
	char bAlwaysNotifyOnFinished : 1; // Offset: 0x80 | Size: 0x1
	char pad_0x80_4 : 4; // Offset: 0x80 | Size: 0x1
	char pad_0x81[0x17]; // Offset: 0x81 | Size: 0x17

	// Functions

	// Object: Function AIModule.PawnAction.GetActionPriority
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x105d05f6c
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class EAIRequestPriority GetActionPriority();

	// Object: Function AIModule.PawnAction.Finish
	// Flags: [Native|Protected|BlueprintCallable]
	// Offset: 0x105d05e1c
	// Return & Params: [ Num(1) Size(0x1) ]
	void Finish(enum class EPawnActionResult WithResult);

	// Object: Function AIModule.PawnAction.CreateActionInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105d05ea4
	// Return & Params: [ Num(3) Size(0x18) ]
	struct UPawnAction* CreateActionInstance(struct UObject* WorldContextObject, struct UPawnAction* ActionClass);
};

// Object: Class AIModule.PawnAction_BlueprintBase
// Inherited Bytes: 0x98 | Struct Size: 0x98
struct UPawnAction_BlueprintBase : UPawnAction {
	// Functions

	// Object: Function AIModule.PawnAction_BlueprintBase.ActionTick
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(2) Size(0xc) ]
	void ActionTick(struct APawn* ControlledPawn, float DeltaSeconds);

	// Object: Function AIModule.PawnAction_BlueprintBase.ActionStart
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x8) ]
	void ActionStart(struct APawn* ControlledPawn);

	// Object: Function AIModule.PawnAction_BlueprintBase.ActionResume
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x8) ]
	void ActionResume(struct APawn* ControlledPawn);

	// Object: Function AIModule.PawnAction_BlueprintBase.ActionPause
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x8) ]
	void ActionPause(struct APawn* ControlledPawn);

	// Object: Function AIModule.PawnAction_BlueprintBase.ActionFinished
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(2) Size(0x9) ]
	void ActionFinished(struct APawn* ControlledPawn, enum class EPawnActionResult WithResult);
};

// Object: Class AIModule.PawnAction_Move
// Inherited Bytes: 0x98 | Struct Size: 0xe8
struct UPawnAction_Move : UPawnAction {
	// Fields
	struct AActor* GoalActor; // Offset: 0x98 | Size: 0x8
	struct FVector GoalLocation; // Offset: 0xa0 | Size: 0xc
	float AcceptableRadius; // Offset: 0xac | Size: 0x4
	struct UNavigationQueryFilter* FilterClass; // Offset: 0xb0 | Size: 0x8
	char bAllowStrafe : 1; // Offset: 0xb8 | Size: 0x1
	char bFinishOnOverlap : 1; // Offset: 0xb8 | Size: 0x1
	char bUsePathfinding : 1; // Offset: 0xb8 | Size: 0x1
	char bAllowPartialPath : 1; // Offset: 0xb8 | Size: 0x1
	char bProjectGoalToNavigation : 1; // Offset: 0xb8 | Size: 0x1
	char bUpdatePathToGoal : 1; // Offset: 0xb8 | Size: 0x1
	char bAbortChildActionOnPathChange : 1; // Offset: 0xb8 | Size: 0x1
	char pad_0xB8_7 : 1; // Offset: 0xb8 | Size: 0x1
	char pad_0xB9[0x2f]; // Offset: 0xb9 | Size: 0x2f
};

// Object: Class AIModule.PawnAction_Repeat
// Inherited Bytes: 0x98 | Struct Size: 0xb8
struct UPawnAction_Repeat : UPawnAction {
	// Fields
	struct UPawnAction* ActionToRepeat; // Offset: 0x98 | Size: 0x8
	struct UPawnAction* RecentActionCopy; // Offset: 0xa0 | Size: 0x8
	enum class EPawnActionFailHandling ChildFailureHandlingMode; // Offset: 0xa8 | Size: 0x1
	char pad_0xA9[0xf]; // Offset: 0xa9 | Size: 0xf
};

// Object: Class AIModule.PawnAction_Sequence
// Inherited Bytes: 0x98 | Struct Size: 0xc0
struct UPawnAction_Sequence : UPawnAction {
	// Fields
	struct TArray<struct UPawnAction*> ActionSequence; // Offset: 0x98 | Size: 0x10
	enum class EPawnActionFailHandling ChildFailureHandlingMode; // Offset: 0xa8 | Size: 0x1
	char pad_0xA9[0x7]; // Offset: 0xa9 | Size: 0x7
	struct UPawnAction* RecentActionCopy; // Offset: 0xb0 | Size: 0x8
	char pad_0xB8[0x8]; // Offset: 0xb8 | Size: 0x8
};

// Object: Class AIModule.PawnAction_Wait
// Inherited Bytes: 0x98 | Struct Size: 0xa8
struct UPawnAction_Wait : UPawnAction {
	// Fields
	float TimeToWait; // Offset: 0x94 | Size: 0x4
	char pad_0x9C[0xc]; // Offset: 0x9c | Size: 0xc
};

// Object: Class AIModule.PawnActionsComponent
// Inherited Bytes: 0xb0 | Struct Size: 0xe8
struct UPawnActionsComponent : UActorComponent {
	// Fields
	struct APawn* ControlledPawn; // Offset: 0xb0 | Size: 0x8
	struct TArray<struct FPawnActionStack> ActionStacks; // Offset: 0xb8 | Size: 0x10
	struct TArray<struct FPawnActionEvent> ActionEvents; // Offset: 0xc8 | Size: 0x10
	struct UPawnAction* CurrentAction; // Offset: 0xd8 | Size: 0x8
	char pad_0xE0[0x8]; // Offset: 0xe0 | Size: 0x8

	// Functions

	// Object: Function AIModule.PawnActionsComponent.K2_PushAction
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d071e4
	// Return & Params: [ Num(4) Size(0x19) ]
	bool K2_PushAction(struct UPawnAction* NewAction, enum class EAIRequestPriority Priority, struct UObject* Instigator);

	// Object: Function AIModule.PawnActionsComponent.K2_PerformAction
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105d0730c
	// Return & Params: [ Num(4) Size(0x12) ]
	bool K2_PerformAction(struct APawn* Pawn, struct UPawnAction* Action, enum class EAIRequestPriority Priority);

	// Object: Function AIModule.PawnActionsComponent.K2_ForceAbortAction
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d070c4
	// Return & Params: [ Num(2) Size(0x9) ]
	enum class EPawnActionAbortState K2_ForceAbortAction(struct UPawnAction* ActionToAbort);

	// Object: Function AIModule.PawnActionsComponent.K2_AbortAction
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105d07154
	// Return & Params: [ Num(2) Size(0x9) ]
	enum class EPawnActionAbortState K2_AbortAction(struct UPawnAction* ActionToAbort);
};

// Object: Class AIModule.PawnSensingComponent
// Inherited Bytes: 0xb0 | Struct Size: 0xf8
struct UPawnSensingComponent : UActorComponent {
	// Fields
	float HearingThreshold; // Offset: 0xb0 | Size: 0x4
	float LOSHearingThreshold; // Offset: 0xb4 | Size: 0x4
	float SightRadius; // Offset: 0xb8 | Size: 0x4
	float SensingInterval; // Offset: 0xbc | Size: 0x4
	float HearingMaxSoundAge; // Offset: 0xc0 | Size: 0x4
	char bEnableSensingUpdates : 1; // Offset: 0xc4 | Size: 0x1
	char bOnlySensePlayers : 1; // Offset: 0xc4 | Size: 0x1
	char bSeePawns : 1; // Offset: 0xc4 | Size: 0x1
	char bHearNoises : 1; // Offset: 0xc4 | Size: 0x1
	char pad_0xC4_4 : 4; // Offset: 0xc4 | Size: 0x1
	char pad_0xC5[0xb]; // Offset: 0xc5 | Size: 0xb
	struct FMulticastInlineDelegate OnSeePawn; // Offset: 0xd0 | Size: 0x10
	struct FMulticastInlineDelegate OnHearNoise; // Offset: 0xe0 | Size: 0x10
	float PeripheralVisionAngle; // Offset: 0xf0 | Size: 0x4
	float PeripheralVisionCosine; // Offset: 0xf4 | Size: 0x4

	// Functions

	// Object: Function AIModule.PawnSensingComponent.SetSensingUpdatesEnabled
	// Flags: [BlueprintAuthorityOnly|Native|Public|BlueprintCallable]
	// Offset: 0x105d079a8
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetSensingUpdatesEnabled(bool bEnabled);

	// Object: Function AIModule.PawnSensingComponent.SetSensingInterval
	// Flags: [BlueprintAuthorityOnly|Native|Public|BlueprintCallable]
	// Offset: 0x105d07a38
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetSensingInterval(float NewSensingInterval);

	// Object: Function AIModule.PawnSensingComponent.SetPeripheralVisionAngle
	// Flags: [BlueprintAuthorityOnly|Native|Public|BlueprintCallable]
	// Offset: 0x105d07920
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetPeripheralVisionAngle(float NewPeripheralVisionAngle);

	// Object: DelegateFunction AIModule.PawnSensingComponent.SeePawnDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x8) ]
	void SeePawnDelegate__DelegateSignature(struct APawn* Pawn);

	// Object: DelegateFunction AIModule.PawnSensingComponent.HearNoiseDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms|HasDefaults]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(3) Size(0x18) ]
	void HearNoiseDelegate__DelegateSignature(struct APawn* Instigator, struct FVector& Location, float Volume);

	// Object: Function AIModule.PawnSensingComponent.GetPeripheralVisionCosine
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105d078e8
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetPeripheralVisionCosine();

	// Object: Function AIModule.PawnSensingComponent.GetPeripheralVisionAngle
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105d07904
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetPeripheralVisionAngle();
};

// Object: Class AIModule.VisualLoggerExtension
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UVisualLoggerExtension : UObject {
};

