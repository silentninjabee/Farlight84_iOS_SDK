#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass Ability_VH_Hover_Soroll03_TurretA1_BaseDamage.Ability_VH_Hover_Soroll03_TurretA1_BaseDamage_C
// Inherited Bytes: 0x310 | Struct Size: 0x310
struct AAbility_VH_Hover_Soroll03_TurretA1_BaseDamage_C : ASolarAbility {
};

