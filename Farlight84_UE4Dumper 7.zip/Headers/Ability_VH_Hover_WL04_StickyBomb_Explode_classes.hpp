#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass Ability_VH_Hover_WL04_StickyBomb_Explode.Ability_VH_Hover_WL04_StickyBomb_Explode_C
// Inherited Bytes: 0x310 | Struct Size: 0x318
struct AAbility_VH_Hover_WL04_StickyBomb_Explode_C : ASolarAbility {
	// Fields
	struct UParticleSystemComponent* FX_Hover_WL04_Hit; // Offset: 0x310 | Size: 0x8
};

