#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass Ability_VH_Tire_Mphy01_TurretB1_Rocket_ExplosionDamage_man.Ability_VH_Tire_Mphy01_TurretB1_Rocket_ExplosionDamage_man_C
// Inherited Bytes: 0x310 | Struct Size: 0x319
struct AAbility_VH_Tire_Mphy01_TurretB1_Rocket_ExplosionDamage_man_C : ASolarAbility {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x310 | Size: 0x8
	bool HasExploded; // Offset: 0x318 | Size: 0x1

	// Functions

	// Object: Function Ability_VH_Tire_Mphy01_TurretB1_Rocket_ExplosionDamage_man.Ability_VH_Tire_Mphy01_TurretB1_Rocket_ExplosionDamage_man_C.ReceiveBeginPlay
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(0) Size(0x0) ]
	void ReceiveBeginPlay();

	// Object: Function Ability_VH_Tire_Mphy01_TurretB1_Rocket_ExplosionDamage_man.Ability_VH_Tire_Mphy01_TurretB1_Rocket_ExplosionDamage_man_C.ReceiveTick
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x4) ]
	void ReceiveTick(float DeltaSeconds);

	// Object: Function Ability_VH_Tire_Mphy01_TurretB1_Rocket_ExplosionDamage_man.Ability_VH_Tire_Mphy01_TurretB1_Rocket_ExplosionDamage_man_C.ExecuteUbergraph_Ability_VH_Tire_Mphy01_TurretB1_Rocket_ExplosionDamage_man
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_Ability_VH_Tire_Mphy01_TurretB1_Rocket_ExplosionDamage_man(int32_t EntryPoint);
};

