#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass Ability_VehicleWeapon_ShapedGun.Ability_VehicleWeapon_ShapedGun_C
// Inherited Bytes: 0x310 | Struct Size: 0x310
struct AAbility_VehicleWeapon_ShapedGun_C : ASolarAbility {
};

