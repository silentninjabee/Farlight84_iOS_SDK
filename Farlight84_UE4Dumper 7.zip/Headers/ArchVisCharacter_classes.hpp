#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class ArchVisCharacter.ArchVisCharacter
// Inherited Bytes: 0x4d0 | Struct Size: 0x530
struct AArchVisCharacter : ACharacter {
	// Fields
	struct FString LookUpAxisName; // Offset: 0x4c8 | Size: 0x10
	struct FString LookUpAtRateAxisName; // Offset: 0x4d8 | Size: 0x10
	struct FString TurnAxisName; // Offset: 0x4e8 | Size: 0x10
	struct FString TurnAtRateAxisName; // Offset: 0x4f8 | Size: 0x10
	struct FString MoveForwardAxisName; // Offset: 0x508 | Size: 0x10
	struct FString MoveRightAxisName; // Offset: 0x518 | Size: 0x10
	float MouseSensitivityScale_Pitch; // Offset: 0x528 | Size: 0x4
	float MouseSensitivityScale_Yaw; // Offset: 0x52c | Size: 0x4
};

// Object: Class ArchVisCharacter.ArchVisCharMovementComponent
// Inherited Bytes: 0x620 | Struct Size: 0x670
struct UArchVisCharMovementComponent : UCharacterMovementComponent {
	// Fields
	struct FRotator RotationalAcceleration; // Offset: 0x618 | Size: 0xc
	struct FRotator RotationalDeceleration; // Offset: 0x624 | Size: 0xc
	struct FRotator MaxRotationalVelocity; // Offset: 0x630 | Size: 0xc
	float MinPitch; // Offset: 0x63c | Size: 0x4
	float MaxPitch; // Offset: 0x640 | Size: 0x4
	float WalkingFriction; // Offset: 0x644 | Size: 0x4
	float WalkingSpeed; // Offset: 0x648 | Size: 0x4
	float WalkingAcceleration; // Offset: 0x64c | Size: 0x4
	char pad_0x658[0x18]; // Offset: 0x658 | Size: 0x18
};

