#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class AudioMixer.SynthComponent
// Inherited Bytes: 0x350 | Struct Size: 0x820
struct USynthComponent : USceneComponent {
	// Fields
	char bAutoDestroy : 1; // Offset: 0x344 | Size: 0x1
	char bStopWhenOwnerDestroyed : 1; // Offset: 0x344 | Size: 0x1
	char bAllowSpatialization : 1; // Offset: 0x344 | Size: 0x1
	char bOverrideAttenuation : 1; // Offset: 0x344 | Size: 0x1
	char bOutputToBusOnly : 1; // Offset: 0x344 | Size: 0x1
	struct USoundAttenuation* AttenuationSettings; // Offset: 0x348 | Size: 0x8
	struct FSoundAttenuationSettings AttenuationOverrides; // Offset: 0x350 | Size: 0x3a0
	struct USoundConcurrency* ConcurrencySettings; // Offset: 0x6f0 | Size: 0x8
	struct TSet<struct USoundConcurrency*> ConcurrencySet; // Offset: 0x6f8 | Size: 0x50
	struct USoundClass* SoundClass; // Offset: 0x748 | Size: 0x8
	struct USoundEffectSourcePresetChain* SourceEffectChain; // Offset: 0x750 | Size: 0x8
	struct USoundSubmixBase* SoundSubmix; // Offset: 0x758 | Size: 0x8
	struct TArray<struct FSoundSubmixSendInfo> SoundSubmixSends; // Offset: 0x760 | Size: 0x10
	struct TArray<struct FSoundSourceBusSendInfo> BusSends; // Offset: 0x770 | Size: 0x10
	struct FSoundModulation Modulation; // Offset: 0x780 | Size: 0x10
	struct TArray<struct FSoundSourceBusSendInfo> PreEffectBusSends; // Offset: 0x790 | Size: 0x10
	char bIsUISound : 1; // Offset: 0x7a0 | Size: 0x1
	char bIsPreviewSound : 1; // Offset: 0x7a0 | Size: 0x1
	int32_t EnvelopeFollowerAttackTime; // Offset: 0x7a4 | Size: 0x4
	int32_t EnvelopeFollowerReleaseTime; // Offset: 0x7a8 | Size: 0x4
	struct FMulticastInlineDelegate OnAudioEnvelopeValue; // Offset: 0x7b0 | Size: 0x10
	char pad_0x7C0_7 : 1; // Offset: 0x7c0 | Size: 0x1
	char pad_0x7C1[0x1f]; // Offset: 0x7c1 | Size: 0x1f
	struct USynthSound* Synth; // Offset: 0x7e0 | Size: 0x8
	struct UAudioComponent* AudioComponent; // Offset: 0x7e8 | Size: 0x8
	char pad_0x7F0[0x30]; // Offset: 0x7f0 | Size: 0x30

	// Functions

	// Object: Function AudioMixer.SynthComponent.Stop
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104d5a4f4
	// Return & Params: [ Num(0) Size(0x0) ]
	void Stop();

	// Object: Function AudioMixer.SynthComponent.Start
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104d5a508
	// Return & Params: [ Num(0) Size(0x0) ]
	void Start();

	// Object: Function AudioMixer.SynthComponent.SetVolumeMultiplier
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104d5a440
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetVolumeMultiplier(float VolumeMultiplier);

	// Object: Function AudioMixer.SynthComponent.SetSubmixSend
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104d5a374
	// Return & Params: [ Num(2) Size(0xc) ]
	void SetSubmixSend(struct USoundSubmixBase* Submix, float SendLevel);

	// Object: Function AudioMixer.SynthComponent.IsPlaying
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104d5a4c0
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsPlaying();
};

// Object: Class AudioMixer.AudioGenerator
// Inherited Bytes: 0x28 | Struct Size: 0xc0
struct UAudioGenerator : UObject {
	// Fields
	char pad_0x28[0x98]; // Offset: 0x28 | Size: 0x98
};

// Object: Class AudioMixer.AudioMixerBlueprintLibrary
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UAudioMixerBlueprintLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object: Function AudioMixer.AudioMixerBlueprintLibrary.TrimAudioCache
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104d5649c
	// Return & Params: [ Num(2) Size(0x8) ]
	float TrimAudioCache(float InMegabytesToFree);

	// Object: Function AudioMixer.AudioMixerBlueprintLibrary.StopRecordingOutput
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104d571f4
	// Return & Params: [ Num(7) Size(0x48) ]
	struct USoundWave* StopRecordingOutput(struct UObject* WorldContextObject, enum class EAudioRecordingExportType ExportType, struct FString Name, struct FString Path, struct USoundSubmix* SubmixToRecord, struct USoundWave* ExistingSoundWaveToOverwrite);

	// Object: Function AudioMixer.AudioMixerBlueprintLibrary.StopAnalyzingOutput
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104d56dc4
	// Return & Params: [ Num(2) Size(0x10) ]
	void StopAnalyzingOutput(struct UObject* WorldContextObject, struct USoundSubmix* SubmixToStopAnalyzing);

	// Object: Function AudioMixer.AudioMixerBlueprintLibrary.StartRecordingOutput
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104d57464
	// Return & Params: [ Num(3) Size(0x18) ]
	void StartRecordingOutput(struct UObject* WorldContextObject, float ExpectedDuration, struct USoundSubmix* SubmixToRecord);

	// Object: Function AudioMixer.AudioMixerBlueprintLibrary.StartAnalyzingOutput
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104d56e84
	// Return & Params: [ Num(6) Size(0x18) ]
	void StartAnalyzingOutput(struct UObject* WorldContextObject, struct USoundSubmix* SubmixToAnalyze, enum class EFFTSize FFTSize, enum class EFFTPeakInterpolationMethod InterpolationMethod, enum class EFFTWindowType WindowType, float HopSize);

	// Object: Function AudioMixer.AudioMixerBlueprintLibrary.SetBypassSourceEffectChainEntry
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104d56750
	// Return & Params: [ Num(4) Size(0x15) ]
	void SetBypassSourceEffectChainEntry(struct UObject* WorldContextObject, struct USoundEffectSourcePresetChain* PresetChain, int32_t EntryIndex, bool bBypassed);

	// Object: Function AudioMixer.AudioMixerBlueprintLibrary.ResumeRecordingOutput
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104d57074
	// Return & Params: [ Num(2) Size(0x10) ]
	void ResumeRecordingOutput(struct UObject* WorldContextObject, struct USoundSubmix* SubmixToPause);

	// Object: Function AudioMixer.AudioMixerBlueprintLibrary.ReplaceSoundEffectSubmix
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104d57634
	// Return & Params: [ Num(4) Size(0x20) ]
	void ReplaceSoundEffectSubmix(struct UObject* WorldContextObject, struct USoundSubmix* InSoundSubmix, int32_t SubmixChainIndex, struct USoundEffectSubmixPreset* SubmixEffectPreset);

	// Object: Function AudioMixer.AudioMixerBlueprintLibrary.RemoveSubmixEffectPresetAtIndex
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104d5778c
	// Return & Params: [ Num(3) Size(0x14) ]
	void RemoveSubmixEffectPresetAtIndex(struct UObject* WorldContextObject, struct USoundSubmix* SoundSubmix, int32_t SubmixChainIndex);

	// Object: Function AudioMixer.AudioMixerBlueprintLibrary.RemoveSubmixEffectPreset
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104d57898
	// Return & Params: [ Num(3) Size(0x18) ]
	void RemoveSubmixEffectPreset(struct UObject* WorldContextObject, struct USoundSubmix* SoundSubmix, struct USoundEffectSubmixPreset* SubmixEffectPreset);

	// Object: Function AudioMixer.AudioMixerBlueprintLibrary.RemoveSourceEffectFromPresetChain
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104d568ac
	// Return & Params: [ Num(3) Size(0x14) ]
	void RemoveSourceEffectFromPresetChain(struct UObject* WorldContextObject, struct USoundEffectSourcePresetChain* PresetChain, int32_t EntryIndex);

	// Object: Function AudioMixer.AudioMixerBlueprintLibrary.RemoveMasterSubmixEffect
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104d57b30
	// Return & Params: [ Num(2) Size(0x10) ]
	void RemoveMasterSubmixEffect(struct UObject* WorldContextObject, struct USoundEffectSubmixPreset* SubmixEffectPreset);

	// Object: Function AudioMixer.AudioMixerBlueprintLibrary.PrimeSoundForPlayback
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104d56594
	// Return & Params: [ Num(2) Size(0x18) ]
	void PrimeSoundForPlayback(struct USoundWave* SoundWave, struct FDelegate OnLoadCompletion);

	// Object: Function AudioMixer.AudioMixerBlueprintLibrary.PrimeSoundCueForPlayback
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104d5651c
	// Return & Params: [ Num(1) Size(0x8) ]
	void PrimeSoundCueForPlayback(struct USoundCue* SoundCue);

	// Object: Function AudioMixer.AudioMixerBlueprintLibrary.PauseRecordingOutput
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104d57134
	// Return & Params: [ Num(2) Size(0x10) ]
	void PauseRecordingOutput(struct UObject* WorldContextObject, struct USoundSubmix* SubmixToPause);

	// Object: Function AudioMixer.AudioMixerBlueprintLibrary.GetPhaseForFrequencies
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104d56abc
	// Return & Params: [ Num(4) Size(0x30) ]
	void GetPhaseForFrequencies(struct UObject* WorldContextObject, struct TArray<float>& Frequencies, struct TArray<float>& Phases, struct USoundSubmix* SubmixToAnalyze);

	// Object: Function AudioMixer.AudioMixerBlueprintLibrary.GetNumberOfEntriesInSourceEffectChain
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104d56688
	// Return & Params: [ Num(3) Size(0x14) ]
	int32_t GetNumberOfEntriesInSourceEffectChain(struct UObject* WorldContextObject, struct USoundEffectSourcePresetChain* PresetChain);

	// Object: Function AudioMixer.AudioMixerBlueprintLibrary.GetMagnitudeForFrequencies
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104d56c40
	// Return & Params: [ Num(4) Size(0x30) ]
	void GetMagnitudeForFrequencies(struct UObject* WorldContextObject, struct TArray<float>& Frequencies, struct TArray<float>& Magnitudes, struct USoundSubmix* SubmixToAnalyze);

	// Object: Function AudioMixer.AudioMixerBlueprintLibrary.ClearSubmixEffects
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104d57574
	// Return & Params: [ Num(2) Size(0x10) ]
	void ClearSubmixEffects(struct UObject* WorldContextObject, struct USoundSubmix* SoundSubmix);

	// Object: Function AudioMixer.AudioMixerBlueprintLibrary.ClearMasterSubmixEffects
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104d57ab8
	// Return & Params: [ Num(1) Size(0x8) ]
	void ClearMasterSubmixEffects(struct UObject* WorldContextObject);

	// Object: Function AudioMixer.AudioMixerBlueprintLibrary.AddSubmixEffect
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104d579a4
	// Return & Params: [ Num(4) Size(0x1c) ]
	int32_t AddSubmixEffect(struct UObject* WorldContextObject, struct USoundSubmix* SoundSubmix, struct USoundEffectSubmixPreset* SubmixEffectPreset);

	// Object: Function AudioMixer.AudioMixerBlueprintLibrary.AddSourceEffectToPresetChain
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104d569b8
	// Return & Params: [ Num(3) Size(0x20) ]
	void AddSourceEffectToPresetChain(struct UObject* WorldContextObject, struct USoundEffectSourcePresetChain* PresetChain, struct FSourceEffectChainEntry Entry);

	// Object: Function AudioMixer.AudioMixerBlueprintLibrary.AddMasterSubmixEffect
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104d57bf0
	// Return & Params: [ Num(2) Size(0x10) ]
	void AddMasterSubmixEffect(struct UObject* WorldContextObject, struct USoundEffectSubmixPreset* SubmixEffectPreset);
};

// Object: Class AudioMixer.SubmixEffectDynamicsProcessorPreset
// Inherited Bytes: 0x40 | Struct Size: 0x120
struct USubmixEffectDynamicsProcessorPreset : USoundEffectSubmixPreset {
	// Fields
	char pad_0x40[0x90]; // Offset: 0x40 | Size: 0x90
	struct FSubmixEffectDynamicsProcessorSettings Settings; // Offset: 0xd0 | Size: 0x50

	// Functions

	// Object: Function AudioMixer.SubmixEffectDynamicsProcessorPreset.SetSettings
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104d589e4
	// Return & Params: [ Num(1) Size(0x50) ]
	void SetSettings(struct FSubmixEffectDynamicsProcessorSettings& Settings);

	// Object: Function AudioMixer.SubmixEffectDynamicsProcessorPreset.SetExternalSubmix
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104d58acc
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetExternalSubmix(struct USoundSubmix* Submix);
};

// Object: Class AudioMixer.SubmixEffectSubmixEQPreset
// Inherited Bytes: 0x40 | Struct Size: 0xa0
struct USubmixEffectSubmixEQPreset : USoundEffectSubmixPreset {
	// Fields
	char pad_0x40[0x50]; // Offset: 0x40 | Size: 0x50
	struct FSubmixEffectSubmixEQSettings Settings; // Offset: 0x90 | Size: 0x10

	// Functions

	// Object: Function AudioMixer.SubmixEffectSubmixEQPreset.SetSettings
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104d590e8
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetSettings(struct FSubmixEffectSubmixEQSettings& InSettings);
};

// Object: Class AudioMixer.SubmixEffectReverbPreset
// Inherited Bytes: 0x40 | Struct Size: 0xe8
struct USubmixEffectReverbPreset : USoundEffectSubmixPreset {
	// Fields
	char pad_0x40[0x74]; // Offset: 0x40 | Size: 0x74
	struct FSubmixEffectReverbSettings Settings; // Offset: 0xb4 | Size: 0x34

	// Functions

	// Object: Function AudioMixer.SubmixEffectReverbPreset.SetSettingsWithReverbEffect
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104d59524
	// Return & Params: [ Num(3) Size(0x10) ]
	void SetSettingsWithReverbEffect(struct UReverbEffect* InReverbEffect, float WetLevel, float DryLevel);

	// Object: Function AudioMixer.SubmixEffectReverbPreset.SetSettings
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104d59638
	// Return & Params: [ Num(1) Size(0x34) ]
	void SetSettings(struct FSubmixEffectReverbSettings& InSettings);
};

// Object: Class AudioMixer.SubmixEffectReverbFastPreset
// Inherited Bytes: 0x40 | Struct Size: 0xf0
struct USubmixEffectReverbFastPreset : USoundEffectSubmixPreset {
	// Fields
	char pad_0x40[0x78]; // Offset: 0x40 | Size: 0x78
	struct FSubmixEffectReverbFastSettings Settings; // Offset: 0xb8 | Size: 0x38

	// Functions

	// Object: Function AudioMixer.SubmixEffectReverbFastPreset.SetSettingsWithReverbEffect
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104d59b20
	// Return & Params: [ Num(3) Size(0x10) ]
	void SetSettingsWithReverbEffect(struct UReverbEffect* InReverbEffect, float WetLevel, float DryLevel);

	// Object: Function AudioMixer.SubmixEffectReverbFastPreset.SetSettings
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104d59c34
	// Return & Params: [ Num(1) Size(0x38) ]
	void SetSettings(struct FSubmixEffectReverbFastSettings& InSettings);
};

// Object: Class AudioMixer.SynthSound
// Inherited Bytes: 0x370 | Struct Size: 0x390
struct USynthSound : USoundWaveProcedural {
	// Fields
	struct USynthComponent* OwningSynthComponent; // Offset: 0x370 | Size: 0x8
	char pad_0x378[0x18]; // Offset: 0x378 | Size: 0x18
};

