#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct AudioPlatformConfiguration.PlatformRuntimeAudioCompressionOverrides
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FPlatformRuntimeAudioCompressionOverrides {
	// Fields
	bool bOverrideCompressionTimes; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	float DurationThreshold; // Offset: 0x4 | Size: 0x4
	int32_t MaxNumRandomBranches; // Offset: 0x8 | Size: 0x4
	int32_t SoundCueQualityIndex; // Offset: 0xc | Size: 0x4
};

