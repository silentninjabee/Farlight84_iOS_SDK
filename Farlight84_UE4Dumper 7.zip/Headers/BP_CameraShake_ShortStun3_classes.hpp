#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_CameraShake_ShortStun3.BP_CameraShake_ShortStun3_C
// Inherited Bytes: 0x180 | Struct Size: 0x180
struct UBP_CameraShake_ShortStun3_C : USolarCameraShake {
};

