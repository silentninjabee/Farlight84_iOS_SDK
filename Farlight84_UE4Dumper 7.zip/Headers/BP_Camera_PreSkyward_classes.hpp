#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_Camera_PreSkyward.BP_Camera_PreSkyward_C
// Inherited Bytes: 0x160 | Struct Size: 0x160
struct UBP_Camera_PreSkyward_C : UCameraShake {
};

