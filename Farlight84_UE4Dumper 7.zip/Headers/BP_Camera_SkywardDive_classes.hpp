#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_Camera_SkywardDive.BP_Camera_SkywardDive_C
// Inherited Bytes: 0x160 | Struct Size: 0x160
struct UBP_Camera_SkywardDive_C : UCameraShake {
};

