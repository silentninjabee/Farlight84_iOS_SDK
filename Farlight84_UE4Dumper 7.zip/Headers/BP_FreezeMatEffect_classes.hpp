#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_FreezeMatEffect.BP_FreezeMatEffect_C
// Inherited Bytes: 0x1c0 | Struct Size: 0x1c0
struct UBP_FreezeMatEffect_C : UMaterialSimpleEffect {
};

