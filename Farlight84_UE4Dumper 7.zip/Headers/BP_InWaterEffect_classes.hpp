#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_InWaterEffect.BP_InWaterEffect_C
// Inherited Bytes: 0x1c8 | Struct Size: 0x1c8
struct UBP_InWaterEffect_C : UMultiplePassMaterialEffect {
};

