#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_InvisibleByZoneEffect_Enemy.BP_InvisibleByZoneEffect_Enemy_C
// Inherited Bytes: 0x1d0 | Struct Size: 0x1d0
struct UBP_InvisibleByZoneEffect_Enemy_C : UMaterialVariableEffect {
};

