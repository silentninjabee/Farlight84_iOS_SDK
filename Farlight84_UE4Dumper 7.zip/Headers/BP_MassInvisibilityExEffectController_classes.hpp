#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_MassInvisibilityExEffectController.BP_MassInvisibilityExEffectController_C
// Inherited Bytes: 0x40 | Struct Size: 0x40
struct UBP_MassInvisibilityExEffectController_C : UTimedEffectController {
};

