#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_Mphy02_CameraAnim_Shot.BP_Mphy02_CameraAnim_Shot_C
// Inherited Bytes: 0x160 | Struct Size: 0x160
struct UBP_Mphy02_CameraAnim_Shot_C : UCameraShake {
};

