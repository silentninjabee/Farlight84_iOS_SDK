#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_Mphy03_RotationAnim.BP_Mphy03_RotationAnim_C
// Inherited Bytes: 0x160 | Struct Size: 0x160
struct UBP_Mphy03_RotationAnim_C : UCameraShake {
};

