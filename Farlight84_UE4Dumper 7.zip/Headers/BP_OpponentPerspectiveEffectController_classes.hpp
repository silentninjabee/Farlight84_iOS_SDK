#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_OpponentPerspectiveEffectController.BP_OpponentPerspectiveEffectController_C
// Inherited Bytes: 0x270 | Struct Size: 0x270
struct UBP_OpponentPerspectiveEffectController_C : UOpponentPerspectiveEffectController {
};

