#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_OpponentPerspectiveEffect.BP_OpponentPerspectiveEffect_C
// Inherited Bytes: 0x1c8 | Struct Size: 0x1c8
struct UBP_OpponentPerspectiveEffect_C : UMultiplePassMaterialEffect {
};

