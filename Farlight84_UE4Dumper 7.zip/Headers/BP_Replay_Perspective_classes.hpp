#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_Replay_Perspective.BP_Replay_Perspective_C
// Inherited Bytes: 0x1a8 | Struct Size: 0x1a8
struct UBP_Replay_Perspective_C : USolarReplayPerspectiveEffect {
};

