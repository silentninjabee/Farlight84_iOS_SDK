#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_SolarGameSettingsRange.BP_SolarGameSettingsRange_C
// Inherited Bytes: 0x1a8 | Struct Size: 0x1a8
struct UBP_SolarGameSettingsRange_C : USolarGameSettingsRange {
};

