#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_SolarGraphicSettings.BP_SolarGraphicSettings_C
// Inherited Bytes: 0x240 | Struct Size: 0x240
struct UBP_SolarGraphicSettings_C : USolarGraphicSettings {
};

