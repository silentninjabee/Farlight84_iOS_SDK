#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_SolarRuntimeAssetsCollection.BP_SolarRuntimeAssetsCollection_C
// Inherited Bytes: 0x38 | Struct Size: 0x38
struct UBP_SolarRuntimeAssetsCollection_C : USolarRuntimeAssetsCollection {
};

