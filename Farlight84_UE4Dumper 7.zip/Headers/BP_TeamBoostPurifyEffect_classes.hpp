#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_TeamBoostPurifyEffect.BP_TeamBoostPurifyEffect_C
// Inherited Bytes: 0x1d0 | Struct Size: 0x1d0
struct UBP_TeamBoostPurifyEffect_C : UMaterialVariableEffect {
};

