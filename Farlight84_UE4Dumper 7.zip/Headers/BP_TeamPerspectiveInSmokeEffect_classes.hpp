#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_TeamPerspectiveInSmokeEffect.BP_TeamPerspectiveInSmokeEffect_C
// Inherited Bytes: 0x1c8 | Struct Size: 0x1c8
struct UBP_TeamPerspectiveInSmokeEffect_C : UMultiplePassMaterialEffect {
};

