#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_Weapon_EMP_Throw.BP_Weapon_EMP_Throw_C
// Inherited Bytes: 0x6a0 | Struct Size: 0x6a0
struct ABP_Weapon_EMP_Throw_C : ASolarSkill_EMP {
};

