#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass B_DuckRollingMeshComponent.B_DuckRollingMeshComponent_C
// Inherited Bytes: 0xd10 | Struct Size: 0xd34
struct UB_DuckRollingMeshComponent_C : UDuckRollingMeshComponent {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0xd10 | Size: 0x8
	struct TArray<struct UAnimMontage*> JumpPoseMontages; // Offset: 0xd18 | Size: 0x10
	struct FRotator BoneRotation; // Offset: 0xd28 | Size: 0xc

	// Functions

	// Object: Function B_DuckRollingMeshComponent.B_DuckRollingMeshComponent_C.UpdateWorldRotation
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0xc) ]
	void UpdateWorldRotation(struct FRotator& WorldRotation);

	// Object: Function B_DuckRollingMeshComponent.B_DuckRollingMeshComponent_C.ExecuteUbergraph_B_DuckRollingMeshComponent
	// Flags: [Final|UbergraphFunction|HasDefaults]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_B_DuckRollingMeshComponent(int32_t EntryPoint);
};

