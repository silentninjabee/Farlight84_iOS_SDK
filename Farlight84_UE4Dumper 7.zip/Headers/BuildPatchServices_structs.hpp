#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct BuildPatchServices.FileManifestData
// Inherited Bytes: 0x0 | Struct Size: 0x68
struct FFileManifestData {
	// Fields
	struct FString Filename; // Offset: 0x0 | Size: 0x10
	struct FSHAHashData FileHash; // Offset: 0x10 | Size: 0x14
	char pad_0x24[0x4]; // Offset: 0x24 | Size: 0x4
	struct TArray<struct FChunkPartData> FileChunkParts; // Offset: 0x28 | Size: 0x10
	struct TArray<struct FString> InstallTags; // Offset: 0x38 | Size: 0x10
	bool bIsUnixExecutable; // Offset: 0x48 | Size: 0x1
	char pad_0x49[0x7]; // Offset: 0x49 | Size: 0x7
	struct FString SymlinkTarget; // Offset: 0x50 | Size: 0x10
	bool bIsReadOnly; // Offset: 0x60 | Size: 0x1
	bool bIsCompressed; // Offset: 0x61 | Size: 0x1
	char pad_0x62[0x6]; // Offset: 0x62 | Size: 0x6
};

// Object: ScriptStruct BuildPatchServices.ChunkPartData
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FChunkPartData {
	// Fields
	struct FGuid Guid; // Offset: 0x0 | Size: 0x10
	uint32_t Offset; // Offset: 0x10 | Size: 0x4
	uint32_t Size; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct BuildPatchServices.SHAHashData
// Inherited Bytes: 0x0 | Struct Size: 0x14
struct FSHAHashData {
	// Fields
	char Hash[0x14]; // Offset: 0x0 | Size: 0x14
};

// Object: ScriptStruct BuildPatchServices.ChunkInfoData
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FChunkInfoData {
	// Fields
	struct FGuid Guid; // Offset: 0x0 | Size: 0x10
	uint64_t Hash; // Offset: 0x10 | Size: 0x8
	struct FSHAHashData ShaHash; // Offset: 0x18 | Size: 0x14
	char pad_0x2C[0x4]; // Offset: 0x2c | Size: 0x4
	int64_t FileSize; // Offset: 0x30 | Size: 0x8
	char GroupNumber; // Offset: 0x38 | Size: 0x1
	char pad_0x39[0x7]; // Offset: 0x39 | Size: 0x7
};

// Object: ScriptStruct BuildPatchServices.CustomFieldData
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FCustomFieldData {
	// Fields
	struct FString Key; // Offset: 0x0 | Size: 0x10
	struct FString Value; // Offset: 0x10 | Size: 0x10
};

