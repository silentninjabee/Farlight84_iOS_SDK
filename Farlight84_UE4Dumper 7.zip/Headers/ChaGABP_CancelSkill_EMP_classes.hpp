#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGABP_CancelSkill_EMP.ChaGABP_CancelSkill_EMP_C
// Inherited Bytes: 0x410 | Struct Size: 0x410
struct UChaGABP_CancelSkill_EMP_C : USolarGameplayAbility {
};

