#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGABP_Fire.ChaGABP_Fire_C
// Inherited Bytes: 0x468 | Struct Size: 0x468
struct UChaGABP_Fire_C : UChaGA_Fire {
};

