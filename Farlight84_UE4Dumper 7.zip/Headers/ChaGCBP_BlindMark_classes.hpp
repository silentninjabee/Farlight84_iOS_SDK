#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGCBP_BlindMark.ChaGCBP_BlindMark_C
// Inherited Bytes: 0x3e0 | Struct Size: 0x3e8
struct AChaGCBP_BlindMark_C : AChaGC_BlindMark {
	// Fields
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x3e0 | Size: 0x8
};

