#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGCBP_DGExposeEnemy.ChaGCBP_DGExposeEnemy_C
// Inherited Bytes: 0x398 | Struct Size: 0x3a0
struct AChaGCBP_DGExposeEnemy_C : AChaGC_DoppelgangerExposeEnemy {
	// Fields
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x398 | Size: 0x8
};

