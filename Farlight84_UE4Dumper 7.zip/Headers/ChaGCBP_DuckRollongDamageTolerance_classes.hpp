#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGCBP_DuckRollongDamageTolerance.ChaGCBP_DuckRollongDamageTolerance_C
// Inherited Bytes: 0x298 | Struct Size: 0x2b8
struct AChaGCBP_DuckRollongDamageTolerance_C : AGameplayCueNotify_Actor {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x298 | Size: 0x8
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x2a0 | Size: 0x8
	struct UChaGA_DuckRolling* AbilityInstance; // Offset: 0x2a8 | Size: 0x8
	struct UUI_HeroSkill_DuckHitCancel_C* CrosshairInstance; // Offset: 0x2b0 | Size: 0x8

	// Functions

	// Object: Function ChaGCBP_DuckRollongDamageTolerance.ChaGCBP_DuckRollongDamageTolerance_C.GetSolarWeaponCrosshairData
	// Flags: [Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x38) ]
	struct FSolarWeaponCrosshairData GetSolarWeaponCrosshairData();

	// Object: Function ChaGCBP_DuckRollongDamageTolerance.ChaGCBP_DuckRollongDamageTolerance_C.OnRemove
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(3) Size(0xc9) ]
	bool OnRemove(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters);

	// Object: Function ChaGCBP_DuckRollongDamageTolerance.ChaGCBP_DuckRollongDamageTolerance_C.WhileActive
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(3) Size(0xc9) ]
	bool WhileActive(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters);

	// Object: Function ChaGCBP_DuckRollongDamageTolerance.ChaGCBP_DuckRollongDamageTolerance_C.ReceiveTick
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x4) ]
	void ReceiveTick(float DeltaSeconds);

	// Object: Function ChaGCBP_DuckRollongDamageTolerance.ChaGCBP_DuckRollongDamageTolerance_C.ExecuteUbergraph_ChaGCBP_DuckRollongDamageTolerance
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_ChaGCBP_DuckRollongDamageTolerance(int32_t EntryPoint);
};

