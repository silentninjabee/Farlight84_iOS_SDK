#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGCBP_DunkLanding.ChaGCBP_DunkLanding_C
// Inherited Bytes: 0x50 | Struct Size: 0x5c
struct UChaGCBP_DunkLanding_C : UGameplayCueNotify_Static {
	// Fields
	struct FRotator RotOffset; // Offset: 0x50 | Size: 0xc

	// Functions

	// Object: Function ChaGCBP_DunkLanding.ChaGCBP_DunkLanding_C.OnActive
	// Flags: [Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(3) Size(0xc9) ]
	bool OnActive(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters);
};

