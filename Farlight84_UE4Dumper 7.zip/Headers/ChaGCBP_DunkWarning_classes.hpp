#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGCBP_DunkWarning.ChaGCBP_DunkWarning_C
// Inherited Bytes: 0x390 | Struct Size: 0x3a4
struct AChaGCBP_DunkWarning_C : AChaGC_WarningArea {
	// Fields
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x390 | Size: 0x8
	struct FVector NewVar_1; // Offset: 0x398 | Size: 0xc
};

