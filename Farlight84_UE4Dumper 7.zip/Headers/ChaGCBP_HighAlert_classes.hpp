#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGCBP_HighAlert.ChaGCBP_HighAlert_C
// Inherited Bytes: 0x3d0 | Struct Size: 0x3e0
struct AChaGCBP_HighAlert_C : AChaGC_HighAlert {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x3d0 | Size: 0x8
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x3d8 | Size: 0x8

	// Functions

	// Object: Function ChaGCBP_HighAlert.ChaGCBP_HighAlert_C.ReceiveAlertEvent
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x1) ]
	void ReceiveAlertEvent(enum class EAlertDirection InDirection);

	// Object: Function ChaGCBP_HighAlert.ChaGCBP_HighAlert_C.ExecuteUbergraph_ChaGCBP_HighAlert
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_ChaGCBP_HighAlert(int32_t EntryPoint);
};

