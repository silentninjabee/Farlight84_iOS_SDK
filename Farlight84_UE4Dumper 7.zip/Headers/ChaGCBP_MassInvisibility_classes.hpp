#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGCBP_MassInvisibility.ChaGCBP_MassInvisibility_C
// Inherited Bytes: 0x438 | Struct Size: 0x440
struct AChaGCBP_MassInvisibility_C : AChaGC_MassInvisibility {
	// Fields
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x438 | Size: 0x8
};

