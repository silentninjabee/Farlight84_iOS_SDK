#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGCBP_SkydiveFly.ChaGCBP_SkydiveFly_C
// Inherited Bytes: 0x3c8 | Struct Size: 0x3f1
struct AChaGCBP_SkydiveFly_C : AChaGC_SkydiveFly {
	// Fields
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x3c8 | Size: 0x8
	struct UParticleSystemComponent* Particle; // Offset: 0x3d0 | Size: 0x8
	struct UParticleSystem* EnemyParticleAsset; // Offset: 0x3d8 | Size: 0x8
	struct UParticleSystem* FriendParticleAsset; // Offset: 0x3e0 | Size: 0x8
	struct UParticleSystem* DefenderParticleAsset; // Offset: 0x3e8 | Size: 0x8
	bool ShowParticleInLowLevelGraphicsQuality; // Offset: 0x3f0 | Size: 0x1

	// Functions

	// Object: Function ChaGCBP_SkydiveFly.ChaGCBP_SkydiveFly_C.ShowEncircleParticle
	// Flags: [Event|Protected|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(2) Size(0x2) ]
	void ShowEncircleParticle(bool bIsLocalTeam, bool bIsDefender);

	// Object: Function ChaGCBP_SkydiveFly.ChaGCBP_SkydiveFly_C.OnRemoveInternal
	// Flags: [Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(3) Size(0xc9) ]
	bool OnRemoveInternal(struct ASolarCharacter* NullableCharacter, struct FGameplayCueParameters& Parameters);

	// Object: Function ChaGCBP_SkydiveFly.ChaGCBP_SkydiveFly_C.WhileActiveInternal
	// Flags: [Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(3) Size(0xc9) ]
	bool WhileActiveInternal(struct ASolarCharacter* Character, struct FGameplayCueParameters& Parameters);
};

