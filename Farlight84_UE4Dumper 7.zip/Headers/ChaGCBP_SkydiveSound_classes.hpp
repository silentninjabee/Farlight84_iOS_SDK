#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGCBP_SkydiveSound.ChaGCBP_SkydiveSound_C
// Inherited Bytes: 0x2b8 | Struct Size: 0x2c0
struct AChaGCBP_SkydiveSound_C : AChaGC_SkydiveSound {
	// Fields
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x2b8 | Size: 0x8
};

