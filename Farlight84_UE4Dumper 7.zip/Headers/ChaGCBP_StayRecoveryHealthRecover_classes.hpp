#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGCBP_StayRecoveryHealthRecover.ChaGCBP_StayRecoveryHealthRecover_C
// Inherited Bytes: 0x370 | Struct Size: 0x378
struct AChaGCBP_StayRecoveryHealthRecover_C : AChaGC_CharacterActorCueBase {
	// Fields
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x370 | Size: 0x8
};

