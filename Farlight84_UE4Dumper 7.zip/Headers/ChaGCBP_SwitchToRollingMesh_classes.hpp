#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGCBP_SwitchToRollingMesh.ChaGCBP_SwitchToRollingMesh_C
// Inherited Bytes: 0x370 | Struct Size: 0x400
struct AChaGCBP_SwitchToRollingMesh_C : AChaGC_SwitchToDuckRollingMesh {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x370 | Size: 0x8
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x378 | Size: 0x8
	float Timeline_0_FxFade_8BBDA8D746ED656413E1B4B6DF587EEF; // Offset: 0x380 | Size: 0x4
	enum class ETimelineDirection Timeline_0__Direction_8BBDA8D746ED656413E1B4B6DF587EEF; // Offset: 0x384 | Size: 0x1
	char pad_0x385[0x3]; // Offset: 0x385 | Size: 0x3
	struct UTimelineComponent* Timeline_1; // Offset: 0x388 | Size: 0x8
	struct UParticleSystem* SmokeParticleAsset; // Offset: 0x390 | Size: 0x8
	char pad_0x398[0x8]; // Offset: 0x398 | Size: 0x8
	struct FTransform SmokeParticleRelativeTransform; // Offset: 0x3a0 | Size: 0x30
	struct UB_DuckRollingMeshComponent_C* MeshComponent; // Offset: 0x3d0 | Size: 0x8
	struct UParticleSystemComponent*  ParticleComponent; // Offset: 0x3d8 | Size: 0x8
	struct UCurveFloat* SpeedToSmokeRatCurve; // Offset: 0x3e0 | Size: 0x8
	struct UCurveFloat* SpeedToFxRatCurve; // Offset: 0x3e8 | Size: 0x8
	bool IsPlayingRolingLoop; // Offset: 0x3f0 | Size: 0x1
	bool IsPlayingAirLoop; // Offset: 0x3f1 | Size: 0x1
	char pad_0x3F2[0x6]; // Offset: 0x3f2 | Size: 0x6
	struct ASolarCharacter* SolarCharacter; // Offset: 0x3f8 | Size: 0x8

	// Functions

	// Object: Function ChaGCBP_SwitchToRollingMesh.ChaGCBP_SwitchToRollingMesh_C.TryStopAirLoop
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(0) Size(0x0) ]
	void TryStopAirLoop();

	// Object: Function ChaGCBP_SwitchToRollingMesh.ChaGCBP_SwitchToRollingMesh_C.TryStopRollingLoop
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(0) Size(0x0) ]
	void TryStopRollingLoop();

	// Object: Function ChaGCBP_SwitchToRollingMesh.ChaGCBP_SwitchToRollingMesh_C.TryStartAirLoop
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(0) Size(0x0) ]
	void TryStartAirLoop();

	// Object: Function ChaGCBP_SwitchToRollingMesh.ChaGCBP_SwitchToRollingMesh_C.TryStartRollingLoop
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(0) Size(0x0) ]
	void TryStartRollingLoop();

	// Object: Function ChaGCBP_SwitchToRollingMesh.ChaGCBP_SwitchToRollingMesh_C.StopLoopSound
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(0) Size(0x0) ]
	void StopLoopSound();

	// Object: Function ChaGCBP_SwitchToRollingMesh.ChaGCBP_SwitchToRollingMesh_C.UpdateRollingSound
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(0) Size(0x0) ]
	void UpdateRollingSound();

	// Object: Function ChaGCBP_SwitchToRollingMesh.ChaGCBP_SwitchToRollingMesh_C.UpdateParticleParamsBySpeed
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x4) ]
	void UpdateParticleParamsBySpeed(float Speed);

	// Object: Function ChaGCBP_SwitchToRollingMesh.ChaGCBP_SwitchToRollingMesh_C.OnRemoveInternal
	// Flags: [Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(3) Size(0xc9) ]
	bool OnRemoveInternal(struct ASolarCharacter* NullableCharacter, struct FGameplayCueParameters& Parameters);

	// Object: Function ChaGCBP_SwitchToRollingMesh.ChaGCBP_SwitchToRollingMesh_C.WhileActiveInternal
	// Flags: [Event|Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(3) Size(0xc9) ]
	bool WhileActiveInternal(struct ASolarCharacter* Character, struct FGameplayCueParameters& Parameters);

	// Object: Function ChaGCBP_SwitchToRollingMesh.ChaGCBP_SwitchToRollingMesh_C.OnActiveInternal
	// Flags: [Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(3) Size(0xc9) ]
	bool OnActiveInternal(struct ASolarCharacter* Character, struct FGameplayCueParameters& Parameters);

	// Object: Function ChaGCBP_SwitchToRollingMesh.ChaGCBP_SwitchToRollingMesh_C.Timeline_0__FinishedFunc
	// Flags: [BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(0) Size(0x0) ]
	void Timeline_0__FinishedFunc();

	// Object: Function ChaGCBP_SwitchToRollingMesh.ChaGCBP_SwitchToRollingMesh_C.Timeline_0__UpdateFunc
	// Flags: [BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(0) Size(0x0) ]
	void Timeline_0__UpdateFunc();

	// Object: Function ChaGCBP_SwitchToRollingMesh.ChaGCBP_SwitchToRollingMesh_C.ReceiveTick
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x4) ]
	void ReceiveTick(float DeltaSeconds);

	// Object: Function ChaGCBP_SwitchToRollingMesh.ChaGCBP_SwitchToRollingMesh_C.ReceiveEndPlay
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x1) ]
	void ReceiveEndPlay(enum class EEndPlayReason EndPlayReason);

	// Object: Function ChaGCBP_SwitchToRollingMesh.ChaGCBP_SwitchToRollingMesh_C.FadeIn
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(0) Size(0x0) ]
	void FadeIn();

	// Object: Function ChaGCBP_SwitchToRollingMesh.ChaGCBP_SwitchToRollingMesh_C.FadeOut
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(0) Size(0x0) ]
	void FadeOut();

	// Object: Function ChaGCBP_SwitchToRollingMesh.ChaGCBP_SwitchToRollingMesh_C.ExecuteUbergraph_ChaGCBP_SwitchToRollingMesh
	// Flags: [Final|UbergraphFunction|HasDefaults]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_ChaGCBP_SwitchToRollingMesh(int32_t EntryPoint);
};

