#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGCBP_TeamEDBigCast.ChaGCBP_TeamEDBigCast_C
// Inherited Bytes: 0x378 | Struct Size: 0x380
struct AChaGCBP_TeamEDBigCast_C : AChaGC_SuperSkillActorCueBase {
	// Fields
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x378 | Size: 0x8
};

