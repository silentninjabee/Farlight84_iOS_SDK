#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGCBP_TeamEDTeammate.ChaGCBP_TeamEDTeammate_C
// Inherited Bytes: 0x378 | Struct Size: 0x380
struct AChaGCBP_TeamEDTeammate_C : AChaGC_SuperSkillActorCueBase {
	// Fields
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x378 | Size: 0x8
};

