#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGEBP_HoldingSkill_Tactical_2.ChaGEBP_HoldingSkill_Tactical_1_C
// Inherited Bytes: 0x848 | Struct Size: 0x848
struct UChaGEBP_HoldingSkill_Tactical_1_C : UGameplayEffect {
};

