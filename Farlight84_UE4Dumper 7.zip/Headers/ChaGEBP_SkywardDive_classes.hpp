#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGEBP_SkywardDive.ChaGEBP_SkywardDive_C
// Inherited Bytes: 0x848 | Struct Size: 0x848
struct UChaGEBP_SkywardDive_C : UGameplayEffect {
};

