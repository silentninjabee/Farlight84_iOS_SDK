#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct CommonInput.CommonInputPlatformBaseData
// Inherited Bytes: 0x0 | Struct Size: 0x48
struct FCommonInputPlatformBaseData {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
	bool bSupported; // Offset: 0x8 | Size: 0x1
	enum class ECommonInputType DefaultInputType; // Offset: 0x9 | Size: 0x1
	bool bSupportsMouseAndKeyboard; // Offset: 0xa | Size: 0x1
	bool bSupportsGamepad; // Offset: 0xb | Size: 0x1
	struct FName DefaultGamepadName; // Offset: 0xc | Size: 0x8
	bool bCanChangeGamepadType; // Offset: 0x14 | Size: 0x1
	bool bSupportsTouch; // Offset: 0x15 | Size: 0x1
	char pad_0x16[0x2]; // Offset: 0x16 | Size: 0x2
	struct TArray<struct TSoftClassPtr<UObject>> ControllerData; // Offset: 0x18 | Size: 0x10
	struct TArray<struct UCommonInputBaseControllerData*> ControllerDataClasses; // Offset: 0x28 | Size: 0x10
	struct TArray<struct FCommonInputControllerSimpleData> ControllerSimpleData; // Offset: 0x38 | Size: 0x10
};

// Object: ScriptStruct CommonInput.CommonInputControllerSimpleData
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FCommonInputControllerSimpleData {
	// Fields
	struct FName GamepadName; // Offset: 0x0 | Size: 0x8
	struct TArray<struct FInputDeviceIdentifierPair> GamepadHardwareIdMapping; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct CommonInput.InputDeviceIdentifierPair
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FInputDeviceIdentifierPair {
	// Fields
	struct FName InputDeviceName; // Offset: 0x0 | Size: 0x8
	struct FString HardwareDeviceIdentifier; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct CommonInput.CommonInputKeySetBrushConfiguration
// Inherited Bytes: 0x0 | Struct Size: 0xf0
struct FCommonInputKeySetBrushConfiguration {
	// Fields
	struct TArray<struct FKey> Keys; // Offset: 0x0 | Size: 0x10
	struct FSlateBrush KeyBrush; // Offset: 0x10 | Size: 0xe0
};

// Object: ScriptStruct CommonInput.CommonInputKeyBrushConfiguration
// Inherited Bytes: 0x0 | Struct Size: 0x100
struct FCommonInputKeyBrushConfiguration {
	// Fields
	struct FKey Key; // Offset: 0x0 | Size: 0x18
	char pad_0x18[0x8]; // Offset: 0x18 | Size: 0x8
	struct FSlateBrush KeyBrush; // Offset: 0x20 | Size: 0xe0
};

