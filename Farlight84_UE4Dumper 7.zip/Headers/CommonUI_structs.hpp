#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct CommonUI.CommonNumberFormattingOptions
// Inherited Bytes: 0x0 | Struct Size: 0x14
struct FCommonNumberFormattingOptions {
	// Fields
	enum class ERoundingMode RoundingMode; // Offset: 0x0 | Size: 0x1
	bool UseGrouping; // Offset: 0x1 | Size: 0x1
	char pad_0x2[0x2]; // Offset: 0x2 | Size: 0x2
	int32_t MinimumIntegralDigits; // Offset: 0x4 | Size: 0x4
	int32_t MaximumIntegralDigits; // Offset: 0x8 | Size: 0x4
	int32_t MinimumFractionalDigits; // Offset: 0xc | Size: 0x4
	int32_t MaximumFractionalDigits; // Offset: 0x10 | Size: 0x4
};

// Object: ScriptStruct CommonUI.CommonRegisteredTabInfo
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FCommonRegisteredTabInfo {
	// Fields
	int32_t TabIndex; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct UCommonButtonBase* TabButton; // Offset: 0x8 | Size: 0x8
	struct UWidget* ContentInstance; // Offset: 0x10 | Size: 0x8
};

// Object: ScriptStruct CommonUI.CommonInputActionHandlerData
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FCommonInputActionHandlerData {
	// Fields
	struct FDataTableRowHandle InputActionRow; // Offset: 0x0 | Size: 0x10
	enum class EInputActionState State; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0xf]; // Offset: 0x11 | Size: 0xf
};

// Object: ScriptStruct CommonUI.CommonButtonStyleOptionalSlateSound
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FCommonButtonStyleOptionalSlateSound {
	// Fields
	bool bHasSound; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x7]; // Offset: 0x1 | Size: 0x7
	struct FSlateSound Sound; // Offset: 0x8 | Size: 0x18
};

// Object: ScriptStruct CommonUI.CommonAnalogCursorSettings
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FCommonAnalogCursorSettings {
	// Fields
	int32_t PreprocessorPriority; // Offset: 0x0 | Size: 0x4
	bool bEnableCursorAcceleration; // Offset: 0x4 | Size: 0x1
	char pad_0x5[0x3]; // Offset: 0x5 | Size: 0x3
	float CursorAcceleration; // Offset: 0x8 | Size: 0x4
	float CursorMaxSpeed; // Offset: 0xc | Size: 0x4
	float CursorDeadZone; // Offset: 0x10 | Size: 0x4
	float CursorRadius; // Offset: 0x14 | Size: 0x4
	float HoverSlowdownFactor; // Offset: 0x18 | Size: 0x4
	float ScrollDeadZone; // Offset: 0x1c | Size: 0x4
	float ScrollUpdatePeriod; // Offset: 0x20 | Size: 0x4
	float ScrollMultiplier; // Offset: 0x24 | Size: 0x4
};

// Object: ScriptStruct CommonUI.UIInputAction
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FUIInputAction {
	// Fields
	struct FUIActionTag ActionTag; // Offset: 0x0 | Size: 0x8
	struct FText DefaultDisplayName; // Offset: 0x8 | Size: 0x18
	struct TArray<struct FUIActionKeyMapping> KeyMappings; // Offset: 0x20 | Size: 0x10
};

// Object: ScriptStruct CommonUI.UIActionKeyMapping
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FUIActionKeyMapping {
	// Fields
	struct FKey Key; // Offset: 0x0 | Size: 0x18
	float HoldTime; // Offset: 0x18 | Size: 0x4
	char pad_0x1C[0x4]; // Offset: 0x1c | Size: 0x4
};

// Object: ScriptStruct CommonUI.UITag
// Inherited Bytes: 0x8 | Struct Size: 0x8
struct FUITag : FGameplayTag {
};

// Object: ScriptStruct CommonUI.UIActionTag
// Inherited Bytes: 0x8 | Struct Size: 0x8
struct FUIActionTag : FUITag {
};

// Object: ScriptStruct CommonUI.RichTextIconData
// Inherited Bytes: 0x8 | Struct Size: 0x50
struct FRichTextIconData : FTableRowBase {
	// Fields
	struct FText DisplayName; // Offset: 0x8 | Size: 0x18
	struct TSoftObjectPtr<UObject> ResourceObject; // Offset: 0x20 | Size: 0x28
	struct FVector2D ImageSize; // Offset: 0x48 | Size: 0x8
};

// Object: ScriptStruct CommonUI.CommonInputActionDataBase
// Inherited Bytes: 0x8 | Struct Size: 0x390
struct FCommonInputActionDataBase : FTableRowBase {
	// Fields
	struct FText DisplayName; // Offset: 0x8 | Size: 0x18
	struct FText HoldDisplayName; // Offset: 0x20 | Size: 0x18
	char pad_0x38[0x8]; // Offset: 0x38 | Size: 0x8
	struct FCommonInputTypeInfo KeyboardInputTypeInfo; // Offset: 0x40 | Size: 0x100
	struct FCommonInputTypeInfo DefaultGamepadInputTypeInfo; // Offset: 0x140 | Size: 0x100
	struct TMap<struct FName, struct FCommonInputTypeInfo> GamepadInputOverrides; // Offset: 0x240 | Size: 0x50
	struct FCommonInputTypeInfo TouchInputTypeInfo; // Offset: 0x290 | Size: 0x100
};

// Object: ScriptStruct CommonUI.CommonInputTypeInfo
// Inherited Bytes: 0x0 | Struct Size: 0x100
struct FCommonInputTypeInfo {
	// Fields
	struct FKey Key; // Offset: 0x0 | Size: 0x18
	enum class EInputActionState OverrrideState; // Offset: 0x18 | Size: 0x1
	bool bActionRequiresHold; // Offset: 0x19 | Size: 0x1
	char pad_0x1A[0x2]; // Offset: 0x1a | Size: 0x2
	float HoldTime; // Offset: 0x1c | Size: 0x4
	struct FSlateBrush OverrideBrush; // Offset: 0x20 | Size: 0xe0
};

