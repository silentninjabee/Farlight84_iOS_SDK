#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class CoreUObject.Object
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct UObject {
	// Fields
	char pad_0x0[0x28]; // Offset: 0x0 | Size: 0x28

	// Functions

	// Object: Function CoreUObject.Object.ExecuteUbergraph
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph(int32_t EntryPoint);
};

// Object: Class CoreUObject.Interface
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UInterface : UObject {
};

// Object: Class CoreUObject.Field
// Inherited Bytes: 0x28 | Struct Size: 0x30
struct UField : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
};

// Object: Class CoreUObject.Struct
// Inherited Bytes: 0x30 | Struct Size: 0xb0
struct UStruct : UField {
	// Fields
	char pad_0x30[0x80]; // Offset: 0x30 | Size: 0x80
};

// Object: Class CoreUObject.Package
// Inherited Bytes: 0x28 | Struct Size: 0x98
struct UPackage : UObject {
	// Fields
	char pad_0x28[0x70]; // Offset: 0x28 | Size: 0x70
};

// Object: Class CoreUObject.Class
// Inherited Bytes: 0xb0 | Struct Size: 0x308
struct UClass : UStruct {
	// Fields
	char pad_0xB0[0x258]; // Offset: 0xb0 | Size: 0x258
};

// Object: Class CoreUObject.GCObjectReferencer
// Inherited Bytes: 0x28 | Struct Size: 0x88
struct UGCObjectReferencer : UObject {
	// Fields
	char pad_0x28[0x60]; // Offset: 0x28 | Size: 0x60
};

// Object: Class CoreUObject.TextBuffer
// Inherited Bytes: 0x28 | Struct Size: 0x50
struct UTextBuffer : UObject {
	// Fields
	char pad_0x28[0x28]; // Offset: 0x28 | Size: 0x28
};

// Object: Class CoreUObject.ScriptStruct
// Inherited Bytes: 0xb0 | Struct Size: 0xc0
struct UScriptStruct : UStruct {
	// Fields
	char pad_0xB0[0x10]; // Offset: 0xb0 | Size: 0x10
};

// Object: Class CoreUObject.Function
// Inherited Bytes: 0xb0 | Struct Size: 0xe0
struct UFunction : UStruct {
	// Fields
	char pad_0xB0[0x30]; // Offset: 0xb0 | Size: 0x30
};

// Object: Class CoreUObject.DelegateFunction
// Inherited Bytes: 0xe0 | Struct Size: 0xe0
struct UDelegateFunction : UFunction {
};

// Object: Class CoreUObject.SparseDelegateFunction
// Inherited Bytes: 0xe0 | Struct Size: 0xf0
struct USparseDelegateFunction : UDelegateFunction {
	// Fields
	char pad_0xE0[0x10]; // Offset: 0xe0 | Size: 0x10
};

// Object: Class CoreUObject.DynamicClass
// Inherited Bytes: 0x308 | Struct Size: 0x388
struct UDynamicClass : UClass {
	// Fields
	char pad_0x308[0x80]; // Offset: 0x308 | Size: 0x80
};

// Object: Class CoreUObject.PackageMap
// Inherited Bytes: 0x28 | Struct Size: 0xe0
struct UPackageMap : UObject {
	// Fields
	char pad_0x28[0xb8]; // Offset: 0x28 | Size: 0xb8
};

// Object: Class CoreUObject.Enum
// Inherited Bytes: 0x30 | Struct Size: 0x60
struct UEnum : UField {
	// Fields
	char pad_0x30[0x30]; // Offset: 0x30 | Size: 0x30
};

// Object: Class CoreUObject.LinkerPlaceholderClass
// Inherited Bytes: 0x308 | Struct Size: 0x4c0
struct ULinkerPlaceholderClass : UClass {
	// Fields
	char pad_0x308[0x1b8]; // Offset: 0x308 | Size: 0x1b8
};

// Object: Class CoreUObject.LinkerPlaceholderExportObject
// Inherited Bytes: 0x28 | Struct Size: 0xf0
struct ULinkerPlaceholderExportObject : UObject {
	// Fields
	char pad_0x28[0xc8]; // Offset: 0x28 | Size: 0xc8
};

// Object: Class CoreUObject.LinkerPlaceholderFunction
// Inherited Bytes: 0xe0 | Struct Size: 0x298
struct ULinkerPlaceholderFunction : UFunction {
	// Fields
	char pad_0xE0[0x1b8]; // Offset: 0xe0 | Size: 0x1b8
};

// Object: Class CoreUObject.MetaData
// Inherited Bytes: 0x28 | Struct Size: 0xc8
struct UMetaData : UObject {
	// Fields
	char pad_0x28[0xa0]; // Offset: 0x28 | Size: 0xa0
};

// Object: Class CoreUObject.ObjectRedirector
// Inherited Bytes: 0x28 | Struct Size: 0x30
struct UObjectRedirector : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
};

// Object: Class CoreUObject.Property
// Inherited Bytes: 0x30 | Struct Size: 0x70
struct UProperty : UField {
	// Fields
	char pad_0x30[0x40]; // Offset: 0x30 | Size: 0x40
};

// Object: Class CoreUObject.EnumProperty
// Inherited Bytes: 0x70 | Struct Size: 0x80
struct UEnumProperty : UProperty {
	// Fields
	char pad_0x70[0x10]; // Offset: 0x70 | Size: 0x10
};

// Object: Class CoreUObject.ArrayProperty
// Inherited Bytes: 0x70 | Struct Size: 0x78
struct UArrayProperty : UProperty {
	// Fields
	char pad_0x70[0x8]; // Offset: 0x70 | Size: 0x8
};

// Object: Class CoreUObject.ObjectPropertyBase
// Inherited Bytes: 0x70 | Struct Size: 0x78
struct UObjectPropertyBase : UProperty {
	// Fields
	char pad_0x70[0x8]; // Offset: 0x70 | Size: 0x8
};

// Object: Class CoreUObject.BoolProperty
// Inherited Bytes: 0x70 | Struct Size: 0x78
struct UBoolProperty : UProperty {
	// Fields
	char pad_0x70[0x8]; // Offset: 0x70 | Size: 0x8
};

// Object: Class CoreUObject.NumericProperty
// Inherited Bytes: 0x70 | Struct Size: 0x70
struct UNumericProperty : UProperty {
};

// Object: Class CoreUObject.ByteProperty
// Inherited Bytes: 0x70 | Struct Size: 0x78
struct UByteProperty : UNumericProperty {
	// Fields
	char pad_0x70[0x8]; // Offset: 0x70 | Size: 0x8
};

// Object: Class CoreUObject.ObjectProperty
// Inherited Bytes: 0x78 | Struct Size: 0x78
struct UObjectProperty : UObjectPropertyBase {
};

// Object: Class CoreUObject.ClassProperty
// Inherited Bytes: 0x78 | Struct Size: 0x80
struct UClassProperty : UObjectProperty {
	// Fields
	char pad_0x78[0x8]; // Offset: 0x78 | Size: 0x8
};

// Object: Class CoreUObject.DelegateProperty
// Inherited Bytes: 0x70 | Struct Size: 0x78
struct UDelegateProperty : UProperty {
	// Fields
	char pad_0x70[0x8]; // Offset: 0x70 | Size: 0x8
};

// Object: Class CoreUObject.DoubleProperty
// Inherited Bytes: 0x70 | Struct Size: 0x70
struct UDoubleProperty : UNumericProperty {
};

// Object: Class CoreUObject.FloatProperty
// Inherited Bytes: 0x70 | Struct Size: 0x70
struct UFloatProperty : UNumericProperty {
};

// Object: Class CoreUObject.IntProperty
// Inherited Bytes: 0x70 | Struct Size: 0x70
struct UIntProperty : UNumericProperty {
};

// Object: Class CoreUObject.Int8Property
// Inherited Bytes: 0x70 | Struct Size: 0x70
struct UInt8Property : UNumericProperty {
};

// Object: Class CoreUObject.Int16Property
// Inherited Bytes: 0x70 | Struct Size: 0x70
struct UInt16Property : UNumericProperty {
};

// Object: Class CoreUObject.Int64Property
// Inherited Bytes: 0x70 | Struct Size: 0x70
struct UInt64Property : UNumericProperty {
};

// Object: Class CoreUObject.InterfaceProperty
// Inherited Bytes: 0x70 | Struct Size: 0x78
struct UInterfaceProperty : UProperty {
	// Fields
	char pad_0x70[0x8]; // Offset: 0x70 | Size: 0x8
};

// Object: Class CoreUObject.LazyObjectProperty
// Inherited Bytes: 0x78 | Struct Size: 0x78
struct ULazyObjectProperty : UObjectPropertyBase {
};

// Object: Class CoreUObject.MapProperty
// Inherited Bytes: 0x70 | Struct Size: 0x98
struct UMapProperty : UProperty {
	// Fields
	char pad_0x70[0x28]; // Offset: 0x70 | Size: 0x28
};

// Object: Class CoreUObject.MulticastDelegateProperty
// Inherited Bytes: 0x70 | Struct Size: 0x78
struct UMulticastDelegateProperty : UProperty {
	// Fields
	char pad_0x70[0x8]; // Offset: 0x70 | Size: 0x8
};

// Object: Class CoreUObject.MulticastInlineDelegateProperty
// Inherited Bytes: 0x78 | Struct Size: 0x78
struct UMulticastInlineDelegateProperty : UMulticastDelegateProperty {
};

// Object: Class CoreUObject.MulticastSparseDelegateProperty
// Inherited Bytes: 0x78 | Struct Size: 0x78
struct UMulticastSparseDelegateProperty : UMulticastDelegateProperty {
};

// Object: Class CoreUObject.NameProperty
// Inherited Bytes: 0x70 | Struct Size: 0x70
struct UNameProperty : UProperty {
};

// Object: Class CoreUObject.SetProperty
// Inherited Bytes: 0x70 | Struct Size: 0x90
struct USetProperty : UProperty {
	// Fields
	char pad_0x70[0x20]; // Offset: 0x70 | Size: 0x20
};

// Object: Class CoreUObject.SoftObjectProperty
// Inherited Bytes: 0x78 | Struct Size: 0x78
struct USoftObjectProperty : UObjectPropertyBase {
};

// Object: Class CoreUObject.SoftClassProperty
// Inherited Bytes: 0x78 | Struct Size: 0x80
struct USoftClassProperty : USoftObjectProperty {
	// Fields
	char pad_0x78[0x8]; // Offset: 0x78 | Size: 0x8
};

// Object: Class CoreUObject.StrProperty
// Inherited Bytes: 0x70 | Struct Size: 0x70
struct UStrProperty : UProperty {
};

// Object: Class CoreUObject.StructProperty
// Inherited Bytes: 0x70 | Struct Size: 0x78
struct UStructProperty : UProperty {
	// Fields
	char pad_0x70[0x8]; // Offset: 0x70 | Size: 0x8
};

// Object: Class CoreUObject.UInt16Property
// Inherited Bytes: 0x70 | Struct Size: 0x70
struct UUInt16Property : UNumericProperty {
};

// Object: Class CoreUObject.UInt32Property
// Inherited Bytes: 0x70 | Struct Size: 0x70
struct UUInt32Property : UNumericProperty {
};

// Object: Class CoreUObject.UInt64Property
// Inherited Bytes: 0x70 | Struct Size: 0x70
struct UUInt64Property : UNumericProperty {
};

// Object: Class CoreUObject.WeakObjectProperty
// Inherited Bytes: 0x78 | Struct Size: 0x78
struct UWeakObjectProperty : UObjectPropertyBase {
};

// Object: Class CoreUObject.TextProperty
// Inherited Bytes: 0x70 | Struct Size: 0x70
struct UTextProperty : UProperty {
};

// Object: Class CoreUObject.PropertyWrapper
// Inherited Bytes: 0x28 | Struct Size: 0x30
struct UPropertyWrapper : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
};

// Object: Class CoreUObject.MulticastDelegatePropertyWrapper
// Inherited Bytes: 0x30 | Struct Size: 0x30
struct UMulticastDelegatePropertyWrapper : UPropertyWrapper {
};

// Object: Class CoreUObject.MulticastInlineDelegatePropertyWrapper
// Inherited Bytes: 0x30 | Struct Size: 0x30
struct UMulticastInlineDelegatePropertyWrapper : UMulticastDelegatePropertyWrapper {
};

