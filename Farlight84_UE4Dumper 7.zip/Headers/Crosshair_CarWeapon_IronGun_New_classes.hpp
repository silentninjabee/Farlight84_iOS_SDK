#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass Crosshair_CarWeapon_IronGun_New.Crosshair_CarWeapon_IronGun_New_C
// Inherited Bytes: 0x6e8 | Struct Size: 0x7b8
struct UCrosshair_CarWeapon_IronGun_New_C : UVehicleWeaponCrossHairWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x6e8 | Size: 0x8
	struct UWidgetAnimation* Anim_Enter; // Offset: 0x6f0 | Size: 0x8
	struct UWidgetAnimation* Anim_1; // Offset: 0x6f8 | Size: 0x8
	struct UWidgetAnimation* Anim_5; // Offset: 0x700 | Size: 0x8
	struct UWidgetAnimation* Anim_4; // Offset: 0x708 | Size: 0x8
	struct UWidgetAnimation* Anim_3; // Offset: 0x710 | Size: 0x8
	struct UWidgetAnimation* Anim_2; // Offset: 0x718 | Size: 0x8
	struct UWidgetAnimation* Anim_Fullcharge; // Offset: 0x720 | Size: 0x8
	struct UProgressBar* bar_crosshair_2; // Offset: 0x728 | Size: 0x8
	struct UProgressBar* bar_crosshair_3; // Offset: 0x730 | Size: 0x8
	struct UProgressBar* bar_crosshair_4; // Offset: 0x738 | Size: 0x8
	struct UCanvasPanel* Container_SecondReticle; // Offset: 0x740 | Size: 0x8
	struct UCanvasPanel* Coredot; // Offset: 0x748 | Size: 0x8
	struct UImage* Img_Glow; // Offset: 0x750 | Size: 0x8
	struct USolarImage* img_round_l; // Offset: 0x758 | Size: 0x8
	struct USolarImage* img_round_r; // Offset: 0x760 | Size: 0x8
	struct USolarImage* img_round_t; // Offset: 0x768 | Size: 0x8
	struct UImageTween_C* ReloadImg_Tween; // Offset: 0x770 | Size: 0x8
	struct UImage* ReticleDirection; // Offset: 0x778 | Size: 0x8
	struct UImage* SpreadImg_coredot; // Offset: 0x780 | Size: 0x8
	struct UCanvasPanel* SpreadImg_coredot_2; // Offset: 0x788 | Size: 0x8
	struct UCanvasPanel* SpreadImg_coredot_3; // Offset: 0x790 | Size: 0x8
	struct UCanvasPanel* SpreadImg_coredot_4; // Offset: 0x798 | Size: 0x8
	int32_t LastChargeMode; // Offset: 0x7a0 | Size: 0x4
	bool bChargeFull; // Offset: 0x7a4 | Size: 0x1
	char pad_0x7A5[0x3]; // Offset: 0x7a5 | Size: 0x3
	float MinlPercent; // Offset: 0x7a8 | Size: 0x4
	bool bLockedEnemy; // Offset: 0x7ac | Size: 0x1
	char pad_0x7AD[0x3]; // Offset: 0x7ad | Size: 0x3
	struct UWidgetAnimation* LastAttackAnim; // Offset: 0x7b0 | Size: 0x8

	// Functions

	// Object: Function Crosshair_CarWeapon_IronGun_New.Crosshair_CarWeapon_IronGun_New_C.ChangeProgressBarColor
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(3) Size(0x28) ]
	void ChangeProgressBarColor(struct UProgressBar* InProgressBar, struct FLinearColor InBackgroundColor, struct FLinearColor InFillImageColor);

	// Object: Function Crosshair_CarWeapon_IronGun_New.Crosshair_CarWeapon_IronGun_New_C.SetPrograssPrecent
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(3) Size(0x10) ]
	void SetPrograssPrecent(float Percent, int32_t Index, struct UProgressBar* InProgressBar);

	// Object: Function Crosshair_CarWeapon_IronGun_New.Crosshair_CarWeapon_IronGun_New_C.GetChargeWidget
	// Flags: [Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UUserWidget* GetChargeWidget();

	// Object: Function Crosshair_CarWeapon_IronGun_New.Crosshair_CarWeapon_IronGun_New_C.SetWidgetResources
	// Flags: [Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(7) Size(0x38) ]
	void SetWidgetResources(struct UCanvasPanel*& InSecondReticlePanel, struct UImage*& InReticleDirectionImage, struct UImage*& InRangedImage, struct USizeBox*& InAssistLockSizeBox, struct UCanvasPanel*& InChangeNewAssistLockPawnPanel, struct UCanvasPanel*& InEnterLockPawnPanel, struct UCanvasPanel*& InCanvas_Dynamic);

	// Object: Function Crosshair_CarWeapon_IronGun_New.Crosshair_CarWeapon_IronGun_New_C.OnUpdateChargeProgress
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(4) Size(0x10) ]
	void OnUpdateChargeProgress(bool InbCharging, int32_t InChargeMode, float InChargeProgress, int32_t InChargeBurstCount);

	// Object: Function Crosshair_CarWeapon_IronGun_New.Crosshair_CarWeapon_IronGun_New_C.OnUpdateAimState
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnUpdateAimState(bool InbLockEnemy);

	// Object: Function Crosshair_CarWeapon_IronGun_New.Crosshair_CarWeapon_IronGun_New_C.OnPlayWeaponSpecialFire
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(2) Size(0x8) ]
	void OnPlayWeaponSpecialFire(enum class ECrossHairSpecialFireState InState, float PlayRate);

	// Object: Function Crosshair_CarWeapon_IronGun_New.Crosshair_CarWeapon_IronGun_New_C.OnCrosshairInNormalState
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnCrosshairInNormalState();

	// Object: Function Crosshair_CarWeapon_IronGun_New.Crosshair_CarWeapon_IronGun_New_C.OnShowVehicleWeaponCrossHair
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnShowVehicleWeaponCrossHair();

	// Object: Function Crosshair_CarWeapon_IronGun_New.Crosshair_CarWeapon_IronGun_New_C.ExecuteUbergraph_Crosshair_CarWeapon_IronGun_New
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_Crosshair_CarWeapon_IronGun_New(int32_t EntryPoint);
};

