#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass Crosshair_CarWeapon_Shotgun_New.Crosshair_CarWeapon_Shotgun_New_C
// Inherited Bytes: 0x6e8 | Struct Size: 0x774
struct UCrosshair_CarWeapon_Shotgun_New_C : UVehicleWeaponCrossHairWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x6e8 | Size: 0x8
	struct UWidgetAnimation* Anim_Reload; // Offset: 0x6f0 | Size: 0x8
	struct UImage* bullet_l; // Offset: 0x6f8 | Size: 0x8
	struct UImage* bullet_r; // Offset: 0x700 | Size: 0x8
	struct UCanvasPanel* Container_SecondReticle; // Offset: 0x708 | Size: 0x8
	struct UCanvasPanel* Coredot; // Offset: 0x710 | Size: 0x8
	struct UCanvasPanel* panel_bottom; // Offset: 0x718 | Size: 0x8
	struct UCanvasPanel* Panel_Left; // Offset: 0x720 | Size: 0x8
	struct UCanvasPanel* Panel_Reload; // Offset: 0x728 | Size: 0x8
	struct UCanvasPanel* Panel_Right; // Offset: 0x730 | Size: 0x8
	struct UCanvasPanel* panel_top; // Offset: 0x738 | Size: 0x8
	struct UImage* ReticleDirection; // Offset: 0x740 | Size: 0x8
	struct UImage* SpreadImg_coredot; // Offset: 0x748 | Size: 0x8
	struct UImage* SpreadImg_coredot_l; // Offset: 0x750 | Size: 0x8
	struct UImage* SpreadImg_coredot_l_2; // Offset: 0x758 | Size: 0x8
	struct UImage* SpreadImg_coredot_r; // Offset: 0x760 | Size: 0x8
	struct UImage* SpreadImg_coredot_r_2; // Offset: 0x768 | Size: 0x8
	int32_t LastAmmoCount; // Offset: 0x770 | Size: 0x4

	// Functions

	// Object: Function Crosshair_CarWeapon_Shotgun_New.Crosshair_CarWeapon_Shotgun_New_C.ChangeAmmoCount
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(2) Size(0x8) ]
	void ChangeAmmoCount(int32_t ReloadCount, int32_t AmmoCount);

	// Object: Function Crosshair_CarWeapon_Shotgun_New.Crosshair_CarWeapon_Shotgun_New_C.SetWidgetResources
	// Flags: [Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(7) Size(0x38) ]
	void SetWidgetResources(struct UCanvasPanel*& InSecondReticlePanel, struct UImage*& InReticleDirectionImage, struct UImage*& InRangedImage, struct USizeBox*& InAssistLockSizeBox, struct UCanvasPanel*& InChangeNewAssistLockPawnPanel, struct UCanvasPanel*& InEnterLockPawnPanel, struct UCanvasPanel*& InCanvas_Dynamic);

	// Object: Function Crosshair_CarWeapon_Shotgun_New.Crosshair_CarWeapon_Shotgun_New_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(0) Size(0x0) ]
	void Construct();

	// Object: Function Crosshair_CarWeapon_Shotgun_New.Crosshair_CarWeapon_Shotgun_New_C.OnAmmoChanged
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(3) Size(0x9) ]
	void OnAmmoChanged(int32_t InReservedAmmo, int32_t InMaxAmmo, bool InbFirst);

	// Object: Function Crosshair_CarWeapon_Shotgun_New.Crosshair_CarWeapon_Shotgun_New_C.OnReloadStarted
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(2) Size(0x8) ]
	void OnReloadStarted(float InReloadTime, int32_t InReservedAmmo);

	// Object: Function Crosshair_CarWeapon_Shotgun_New.Crosshair_CarWeapon_Shotgun_New_C.OnReloadFinished
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(4) Size(0x10) ]
	void OnReloadFinished(bool InbReloadSuccess, int32_t InReloadAmmo, int32_t InReservedAmmo, int32_t InMaxAmmo);

	// Object: Function Crosshair_CarWeapon_Shotgun_New.Crosshair_CarWeapon_Shotgun_New_C.ExecuteUbergraph_Crosshair_CarWeapon_Shotgun_New
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_Crosshair_CarWeapon_Shotgun_New(int32_t EntryPoint);
};

