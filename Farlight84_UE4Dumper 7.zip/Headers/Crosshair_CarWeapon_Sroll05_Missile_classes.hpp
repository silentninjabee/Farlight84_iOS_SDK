#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass Crosshair_CarWeapon_Sroll05_Missile.Crosshair_CarWeapon_Sroll05_Missile_C
// Inherited Bytes: 0x6e8 | Struct Size: 0x7c9
struct UCrosshair_CarWeapon_Sroll05_Missile_C : UVehicleWeaponCrossHairWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x6e8 | Size: 0x8
	struct UProgressBar* Bullet; // Offset: 0x6f0 | Size: 0x8
	struct UProgressBar* Bullet_2; // Offset: 0x6f8 | Size: 0x8
	struct UCanvasPanel* Container_SecondReticle; // Offset: 0x700 | Size: 0x8
	struct UCanvasPanel* Coredot; // Offset: 0x708 | Size: 0x8
	struct UCanvasPanel* Panel_Clip; // Offset: 0x710 | Size: 0x8
	struct UImage* SpreadImg_coredot; // Offset: 0x718 | Size: 0x8
	struct UCanvasPanel* SpreadImg_coredot_2; // Offset: 0x720 | Size: 0x8
	struct UCanvasPanel* SpreadImg_coredot_3; // Offset: 0x728 | Size: 0x8
	struct UCanvasPanel* SpreadImg_coredot_4; // Offset: 0x730 | Size: 0x8
	struct UCanvasPanel* SpreadImg_coredot_5; // Offset: 0x738 | Size: 0x8
	struct UCanvasPanel* SpreadImg_coredot_6; // Offset: 0x740 | Size: 0x8
	struct UCanvasPanel* SpreadImg_coredot_7; // Offset: 0x748 | Size: 0x8
	struct UCanvasPanel* SpreadImg_coredot_8; // Offset: 0x750 | Size: 0x8
	struct UCanvasPanel* SpreadImg_coredot_9; // Offset: 0x758 | Size: 0x8
	struct UCanvasPanel* SpreadImg_coredot_10; // Offset: 0x760 | Size: 0x8
	struct UCanvasPanel* SpreadImg_coredot_11; // Offset: 0x768 | Size: 0x8
	struct UCanvasPanel* SpreadImg_coredot_12; // Offset: 0x770 | Size: 0x8
	struct UCanvasPanel* SpreadImg_coredot_13; // Offset: 0x778 | Size: 0x8
	struct UCanvasPanel* SpreadImg_coredot_14; // Offset: 0x780 | Size: 0x8
	struct UCanvasPanel* SpreadImg_coredot_15; // Offset: 0x788 | Size: 0x8
	struct UCanvasPanel* SpreadImg_coredot_16; // Offset: 0x790 | Size: 0x8
	struct UCanvasPanel* SpreadImg_coredot_17; // Offset: 0x798 | Size: 0x8
	struct UCanvasPanel* SpreadImg_coredot_18; // Offset: 0x7a0 | Size: 0x8
	struct UCanvasPanel* SpreadImg_coredot_19; // Offset: 0x7a8 | Size: 0x8
	struct UCanvasPanel* SpreadImg_coredot_20; // Offset: 0x7b0 | Size: 0x8
	struct UCanvasPanel* SpreadImg_coredot_21; // Offset: 0x7b8 | Size: 0x8
	float PitchRotScale; // Offset: 0x7c0 | Size: 0x4
	int32_t LastAmmoCount; // Offset: 0x7c4 | Size: 0x4
	bool bShowClip; // Offset: 0x7c8 | Size: 0x1

	// Functions

	// Object: Function Crosshair_CarWeapon_Sroll05_Missile.Crosshair_CarWeapon_Sroll05_Missile_C.ChangeAmmoCount
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x4) ]
	void ChangeAmmoCount(int32_t AmmoCount);

	// Object: Function Crosshair_CarWeapon_Sroll05_Missile.Crosshair_CarWeapon_Sroll05_Missile_C.OnAmmoChanged
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(3) Size(0x9) ]
	void OnAmmoChanged(int32_t InReservedAmmo, int32_t InMaxAmmo, bool InbFirst);

	// Object: Function Crosshair_CarWeapon_Sroll05_Missile.Crosshair_CarWeapon_Sroll05_Missile_C.OnUpdateVehicleRotationPitch
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x4) ]
	void OnUpdateVehicleRotationPitch(float InPitch);

	// Object: Function Crosshair_CarWeapon_Sroll05_Missile.Crosshair_CarWeapon_Sroll05_Missile_C.OnReloadFinished
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(4) Size(0x10) ]
	void OnReloadFinished(bool InbReloadSuccess, int32_t InReloadAmmo, int32_t InReservedAmmo, int32_t InMaxAmmo);

	// Object: Function Crosshair_CarWeapon_Sroll05_Missile.Crosshair_CarWeapon_Sroll05_Missile_C.OnUpdateReloadProgress
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(3) Size(0xc) ]
	void OnUpdateReloadProgress(float InReloadProgress, int32_t InReservedAmmo, int32_t InMaxAmmo);

	// Object: Function Crosshair_CarWeapon_Sroll05_Missile.Crosshair_CarWeapon_Sroll05_Missile_C.ExecuteUbergraph_Crosshair_CarWeapon_Sroll05_Missile
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_Crosshair_CarWeapon_Sroll05_Missile(int32_t EntryPoint);
};

