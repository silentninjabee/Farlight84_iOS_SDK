#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass Crosshair_CarWeapon_Trans_MachineGun.Crosshair_CarWeapon_Trans_MachineGun_C
// Inherited Bytes: 0x6e8 | Struct Size: 0x788
struct UCrosshair_CarWeapon_Trans_MachineGun_C : UVehicleWeaponCrossHairWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x6e8 | Size: 0x8
	struct UWidgetAnimation* Anim_transform; // Offset: 0x6f0 | Size: 0x8
	struct UCanvasPanel* Container_SecondReticle; // Offset: 0x6f8 | Size: 0x8
	struct UCanvasPanel* Coredot; // Offset: 0x700 | Size: 0x8
	struct UImage* downarrow; // Offset: 0x708 | Size: 0x8
	struct UImage* img_flame; // Offset: 0x710 | Size: 0x8
	struct UImage* img_lb; // Offset: 0x718 | Size: 0x8
	struct UImage* img_lt; // Offset: 0x720 | Size: 0x8
	struct UImage* img_rb; // Offset: 0x728 | Size: 0x8
	struct UImage* img_rt; // Offset: 0x730 | Size: 0x8
	struct UImage* leftarrow; // Offset: 0x738 | Size: 0x8
	struct UCanvasPanel* panel_trans; // Offset: 0x740 | Size: 0x8
	struct UImage* ReticleDirection; // Offset: 0x748 | Size: 0x8
	struct UImage* rightarrow; // Offset: 0x750 | Size: 0x8
	struct UImage* SpreadImg_coredot; // Offset: 0x758 | Size: 0x8
	struct UImage* SpreadImg_Downarrow_2; // Offset: 0x760 | Size: 0x8
	struct UImage* SpreadImg_Leftarrow_2; // Offset: 0x768 | Size: 0x8
	struct UImage* SpreadImg_Rightarrow_2; // Offset: 0x770 | Size: 0x8
	struct UImage* SpreadImg_uparrow_2; // Offset: 0x778 | Size: 0x8
	struct UImage* uparrow; // Offset: 0x780 | Size: 0x8

	// Functions

	// Object: Function Crosshair_CarWeapon_Trans_MachineGun.Crosshair_CarWeapon_Trans_MachineGun_C.SetWidgetResources
	// Flags: [Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(7) Size(0x38) ]
	void SetWidgetResources(struct UCanvasPanel*& InSecondReticlePanel, struct UImage*& InReticleDirectionImage, struct UImage*& InRangedImage, struct USizeBox*& InAssistLockSizeBox, struct UCanvasPanel*& InChangeNewAssistLockPawnPanel, struct UCanvasPanel*& InEnterLockPawnPanel, struct UCanvasPanel*& InCanvas_Dynamic);

	// Object: Function Crosshair_CarWeapon_Trans_MachineGun.Crosshair_CarWeapon_Trans_MachineGun_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(0) Size(0x0) ]
	void Construct();

	// Object: Function Crosshair_CarWeapon_Trans_MachineGun.Crosshair_CarWeapon_Trans_MachineGun_C.OnTransformerWeaponChanged
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnTransformerWeaponChanged(enum class ETransformerType InType);

	// Object: Function Crosshair_CarWeapon_Trans_MachineGun.Crosshair_CarWeapon_Trans_MachineGun_C.ExecuteUbergraph_Crosshair_CarWeapon_Trans_MachineGun
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_Crosshair_CarWeapon_Trans_MachineGun(int32_t EntryPoint);
};

