#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass Crosshair_Shotgun.Crosshair_Shotgun_C
// Inherited Bytes: 0x560 | Struct Size: 0x575
struct UCrosshair_Shotgun_C : UCrossHairWidget {
	// Fields
	struct UImage* SpreadImg_Leftarrow; // Offset: 0x560 | Size: 0x8
	struct UImage* SpreadImg_Rightarrow; // Offset: 0x568 | Size: 0x8
	int32_t ; // Offset: 0x570 | Size: 0x4
	enum class E_UI_Bullet_Type ; // Offset: 0x574 | Size: 0x1

	// Functions

	// Object: Function Crosshair_Shotgun.Crosshair_Shotgun_C.GetAmmoWidget
	// Flags: [Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UUserWidget* GetAmmoWidget();

	// Object: Function Crosshair_Shotgun.Crosshair_Shotgun_C.GetReloadWidget
	// Flags: [Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UUserWidget* GetReloadWidget();
};

