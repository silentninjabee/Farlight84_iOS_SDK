#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class CustomMeshComponent.CustomMeshComponent
// Inherited Bytes: 0x5e0 | Struct Size: 0x5f0
struct UCustomMeshComponent : UMeshComponent {
	// Fields
	char pad_0x5E0[0x10]; // Offset: 0x5e0 | Size: 0x10

	// Functions

	// Object: Function CustomMeshComponent.CustomMeshComponent.SetCustomMeshTriangles
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1022653ec
	// Return & Params: [ Num(2) Size(0x11) ]
	bool SetCustomMeshTriangles(struct TArray<struct FCustomMeshTriangle>& Triangles);

	// Object: Function CustomMeshComponent.CustomMeshComponent.ClearCustomMeshTriangles
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102265340
	// Return & Params: [ Num(0) Size(0x0) ]
	void ClearCustomMeshTriangles();

	// Object: Function CustomMeshComponent.CustomMeshComponent.AddCustomMeshTriangles
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102265354
	// Return & Params: [ Num(1) Size(0x10) ]
	void AddCustomMeshTriangles(struct TArray<struct FCustomMeshTriangle>& Triangles);
};

