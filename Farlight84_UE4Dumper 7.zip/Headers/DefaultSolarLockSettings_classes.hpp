#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass DefaultSolarLockSettings.DefaultSolarLockSettings_C
// Inherited Bytes: 0x78 | Struct Size: 0x78
struct UDefaultSolarLockSettings_C : USolarLockSettings {
};

