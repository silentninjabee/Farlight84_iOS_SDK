#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: UserDefinedEnum E_BigMapSlot.E_BigMapSlot
enum class E_BigMapSlot : uint8_t {
	NewEnumerator0 = 0,
	E_MAX = 1
};

