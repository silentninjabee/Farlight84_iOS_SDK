#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: UserDefinedEnum E_Update_LoginNotice.E_Update_LoginNotice
enum class E_Update_LoginNotice : uint8_t {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	E_Update_MAX = 2
};

