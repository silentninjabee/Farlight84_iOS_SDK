#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass Effect_VH_Hover_Soroll05_weapon_ExplosionDamage_Secondary.Effect_VH_Hover_Soroll05_weapon_ExplosionDamage_Secondary_C
// Inherited Bytes: 0x198 | Struct Size: 0x198
struct UEffect_VH_Hover_Soroll05_weapon_ExplosionDamage_Secondary_C : USolarAbilityEffect {
};

