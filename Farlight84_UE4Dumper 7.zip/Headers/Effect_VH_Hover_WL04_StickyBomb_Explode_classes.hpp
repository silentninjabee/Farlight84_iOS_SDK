#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass Effect_VH_Hover_WL04_StickyBomb_Explode.Effect_VH_Hover_WL04_StickyBomb_Explode_C
// Inherited Bytes: 0x198 | Struct Size: 0x198
struct UEffect_VH_Hover_WL04_StickyBomb_Explode_C : USolarAbilityEffect {
};

