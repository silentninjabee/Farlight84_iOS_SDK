#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass Effect_VH_Leg_9A02_Gatling_BaseDamage.Effect_VH_Leg_9A02_Gatling_BaseDamage_C
// Inherited Bytes: 0x198 | Struct Size: 0x198
struct UEffect_VH_Leg_9A02_Gatling_BaseDamage_C : USolarAbilityEffect {
};

