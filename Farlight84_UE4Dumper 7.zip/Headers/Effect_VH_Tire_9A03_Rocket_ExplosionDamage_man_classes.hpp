#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass Effect_VH_Tire_9A03_Rocket_ExplosionDamage_man.Effect_VH_Tire_9A03_Rocket_ExplosionDamage_man_C
// Inherited Bytes: 0x198 | Struct Size: 0x198
struct UEffect_VH_Tire_9A03_Rocket_ExplosionDamage_man_C : USolarAbilityEffect {
};

