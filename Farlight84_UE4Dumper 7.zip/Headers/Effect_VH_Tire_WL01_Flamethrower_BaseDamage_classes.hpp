#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass Effect_VH_Tire_WL01_Flamethrower_BaseDamage.Effect_VH_Tire_WL01_Flamethrower_BaseDamage_C
// Inherited Bytes: 0x198 | Struct Size: 0x198
struct UEffect_VH_Tire_WL01_Flamethrower_BaseDamage_C : USolarAbilityEffect {
};

