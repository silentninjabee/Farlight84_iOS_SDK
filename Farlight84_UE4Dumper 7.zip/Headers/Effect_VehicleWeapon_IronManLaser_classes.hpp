#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass Effect_VehicleWeapon_IronManLaser.Effect_VehicleWeapon_IronManLaser_C
// Inherited Bytes: 0x198 | Struct Size: 0x198
struct UEffect_VehicleWeapon_IronManLaser_C : USolarAbilityEffect {
};

