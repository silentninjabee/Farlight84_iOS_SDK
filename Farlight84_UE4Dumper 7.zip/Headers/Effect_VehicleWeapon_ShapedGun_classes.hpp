#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass Effect_VehicleWeapon_ShapedGun.Effect_VehicleWeapon_ShapedGun_C
// Inherited Bytes: 0x198 | Struct Size: 0x198
struct UEffect_VehicleWeapon_ShapedGun_C : USolarAbilityEffect {
};

