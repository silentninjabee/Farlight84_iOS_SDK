#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct EyeTracker.EyeTrackerStereoGazeData
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FEyeTrackerStereoGazeData {
	// Fields
	struct FVector LeftEyeOrigin; // Offset: 0x0 | Size: 0xc
	struct FVector LeftEyeDirection; // Offset: 0xc | Size: 0xc
	struct FVector RightEyeOrigin; // Offset: 0x18 | Size: 0xc
	struct FVector RightEyeDirection; // Offset: 0x24 | Size: 0xc
	struct FVector FixationPoint; // Offset: 0x30 | Size: 0xc
	float ConfidenceValue; // Offset: 0x3c | Size: 0x4
};

// Object: ScriptStruct EyeTracker.EyeTrackerGazeData
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FEyeTrackerGazeData {
	// Fields
	struct FVector GazeOrigin; // Offset: 0x0 | Size: 0xc
	struct FVector GazeDirection; // Offset: 0xc | Size: 0xc
	struct FVector FixationPoint; // Offset: 0x18 | Size: 0xc
	float ConfidenceValue; // Offset: 0x24 | Size: 0x4
};

