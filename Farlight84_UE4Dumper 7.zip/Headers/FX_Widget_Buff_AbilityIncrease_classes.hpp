#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass FX_Widget_Buff_AbilityIncrease.FX_Widget_Buff_AbilityIncrease_C
// Inherited Bytes: 0x498 | Struct Size: 0x4c4
struct UFX_Widget_Buff_AbilityIncrease_C : UBP_SolarScreenEffectWidget_C {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x498 | Size: 0x8
	struct UWidgetAnimation* Buff_AbilityIncrease; // Offset: 0x4a0 | Size: 0x8
	struct UImage* Left; // Offset: 0x4a8 | Size: 0x8
	struct UImage* Right; // Offset: 0x4b0 | Size: 0x8
	struct UImage* Up; // Offset: 0x4b8 | Size: 0x8
	float Duartion; // Offset: 0x4c0 | Size: 0x4

	// Functions

	// Object: Function FX_Widget_Buff_AbilityIncrease.FX_Widget_Buff_AbilityIncrease_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(0) Size(0x0) ]
	void Construct();

	// Object: Function FX_Widget_Buff_AbilityIncrease.FX_Widget_Buff_AbilityIncrease_C.ExecuteUbergraph_FX_Widget_Buff_AbilityIncrease
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_FX_Widget_Buff_AbilityIncrease(int32_t EntryPoint);
};

