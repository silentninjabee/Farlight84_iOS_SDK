#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class FacialAnimation.AudioCurveSourceComponent
// Inherited Bytes: 0x930 | Struct Size: 0x970
struct UAudioCurveSourceComponent : UAudioComponent {
	// Fields
	struct FName CurveSourceBindingName; // Offset: 0x930 | Size: 0x8
	float CurveSyncOffset; // Offset: 0x938 | Size: 0x4
	char pad_0x93C[0x34]; // Offset: 0x93c | Size: 0x34
};

