#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class FieldSystemEngine.FieldSystemActor
// Inherited Bytes: 0x228 | Struct Size: 0x230
struct AFieldSystemActor : AActor {
	// Fields
	struct UFieldSystemComponent* FieldSystemComponent; // Offset: 0x228 | Size: 0x8
};

// Object: Class FieldSystemEngine.FieldSystem
// Inherited Bytes: 0x28 | Struct Size: 0x38
struct UFieldSystem : UObject {
	// Fields
	char pad_0x28[0x10]; // Offset: 0x28 | Size: 0x10
};

// Object: Class FieldSystemEngine.FieldSystemComponent
// Inherited Bytes: 0x5b0 | Struct Size: 0x5f0
struct UFieldSystemComponent : UPrimitiveComponent {
	// Fields
	struct UFieldSystem* FieldSystem; // Offset: 0x5a8 | Size: 0x8
	char pad_0x5B8[0x8]; // Offset: 0x5b8 | Size: 0x8
	struct TArray<struct TSoftObjectPtr<AChaosSolverActor>> SupportedSolvers; // Offset: 0x5c0 | Size: 0x10
	char pad_0x5D0[0x20]; // Offset: 0x5d0 | Size: 0x20

	// Functions

	// Object: Function FieldSystemEngine.FieldSystemComponent.ResetFieldSystem
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105ade064
	// Return & Params: [ Num(0) Size(0x0) ]
	void ResetFieldSystem();

	// Object: Function FieldSystemEngine.FieldSystemComponent.ApplyUniformVectorFalloffForce
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x105ade3a8
	// Return & Params: [ Num(5) Size(0x24) ]
	void ApplyUniformVectorFalloffForce(bool Enabled, struct FVector Position, struct FVector Direction, float Radius, float Magnitude);

	// Object: Function FieldSystemEngine.FieldSystemComponent.ApplyStrainField
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x105ade1ec
	// Return & Params: [ Num(5) Size(0x1c) ]
	void ApplyStrainField(bool Enabled, struct FVector Position, float Radius, float Magnitude, int32_t Iterations);

	// Object: Function FieldSystemEngine.FieldSystemComponent.ApplyStayDynamicField
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x105ade7f8
	// Return & Params: [ Num(3) Size(0x14) ]
	void ApplyStayDynamicField(bool Enabled, struct FVector Position, float Radius);

	// Object: Function FieldSystemEngine.FieldSystemComponent.ApplyRadialVectorFalloffForce
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x105ade560
	// Return & Params: [ Num(4) Size(0x18) ]
	void ApplyRadialVectorFalloffForce(bool Enabled, struct FVector Position, float Radius, float Magnitude);

	// Object: Function FieldSystemEngine.FieldSystemComponent.ApplyRadialForce
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x105ade6d0
	// Return & Params: [ Num(3) Size(0x14) ]
	void ApplyRadialForce(bool Enabled, struct FVector Position, float Magnitude);

	// Object: Function FieldSystemEngine.FieldSystemComponent.ApplyPhysicsField
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105ade078
	// Return & Params: [ Num(4) Size(0x18) ]
	void ApplyPhysicsField(bool Enabled, enum class EFieldPhysicsType Target, struct UFieldSystemMetaData* MetaData, struct UFieldNodeBase* Field);

	// Object: Function FieldSystemEngine.FieldSystemComponent.ApplyLinearForce
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x105ade920
	// Return & Params: [ Num(3) Size(0x14) ]
	void ApplyLinearForce(bool Enabled, struct FVector Direction, float Magnitude);

	// Object: Function FieldSystemEngine.FieldSystemComponent.AddFieldCommand
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105addef0
	// Return & Params: [ Num(4) Size(0x18) ]
	void AddFieldCommand(bool Enabled, enum class EFieldPhysicsType Target, struct UFieldSystemMetaData* MetaData, struct UFieldNodeBase* Field);
};

// Object: Class FieldSystemEngine.FieldSystemMetaData
// Inherited Bytes: 0xb0 | Struct Size: 0xb0
struct UFieldSystemMetaData : UActorComponent {
};

// Object: Class FieldSystemEngine.FieldSystemMetaDataIteration
// Inherited Bytes: 0xb0 | Struct Size: 0xb8
struct UFieldSystemMetaDataIteration : UFieldSystemMetaData {
	// Fields
	int32_t Iterations; // Offset: 0xb0 | Size: 0x4
	char pad_0xB4[0x4]; // Offset: 0xb4 | Size: 0x4

	// Functions

	// Object: Function FieldSystemEngine.FieldSystemMetaDataIteration.SetMetaDataIteration
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x105adf2b8
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UFieldSystemMetaDataIteration* SetMetaDataIteration(int32_t Iterations);
};

// Object: Class FieldSystemEngine.FieldSystemMetaDataProcessingResolution
// Inherited Bytes: 0xb0 | Struct Size: 0xb8
struct UFieldSystemMetaDataProcessingResolution : UFieldSystemMetaData {
	// Fields
	enum class EFieldResolutionType ResolutionType; // Offset: 0xb0 | Size: 0x1
	char pad_0xB1[0x7]; // Offset: 0xb1 | Size: 0x7

	// Functions

	// Object: Function FieldSystemEngine.FieldSystemMetaDataProcessingResolution.SetMetaDataaProcessingResolutionType
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x105adf658
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UFieldSystemMetaDataProcessingResolution* SetMetaDataaProcessingResolutionType(enum class EFieldResolutionType ResolutionType);
};

// Object: Class FieldSystemEngine.FieldNodeBase
// Inherited Bytes: 0xb0 | Struct Size: 0xb0
struct UFieldNodeBase : UActorComponent {
};

// Object: Class FieldSystemEngine.FieldNodeInt
// Inherited Bytes: 0xb0 | Struct Size: 0xb0
struct UFieldNodeInt : UFieldNodeBase {
};

// Object: Class FieldSystemEngine.FieldNodeFloat
// Inherited Bytes: 0xb0 | Struct Size: 0xb0
struct UFieldNodeFloat : UFieldNodeBase {
};

// Object: Class FieldSystemEngine.FieldNodeVector
// Inherited Bytes: 0xb0 | Struct Size: 0xb0
struct UFieldNodeVector : UFieldNodeBase {
};

// Object: Class FieldSystemEngine.UniformInteger
// Inherited Bytes: 0xb0 | Struct Size: 0xb8
struct UUniformInteger : UFieldNodeInt {
	// Fields
	int32_t Magnitude; // Offset: 0xb0 | Size: 0x4
	char pad_0xB4[0x4]; // Offset: 0xb4 | Size: 0x4

	// Functions

	// Object: Function FieldSystemEngine.UniformInteger.SetUniformInteger
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x105ae0098
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UUniformInteger* SetUniformInteger(int32_t Magnitude);
};

// Object: Class FieldSystemEngine.RadialIntMask
// Inherited Bytes: 0xb0 | Struct Size: 0xd0
struct URadialIntMask : UFieldNodeInt {
	// Fields
	float Radius; // Offset: 0xb0 | Size: 0x4
	struct FVector Position; // Offset: 0xb4 | Size: 0xc
	int32_t InteriorValue; // Offset: 0xc0 | Size: 0x4
	int32_t ExteriorValue; // Offset: 0xc4 | Size: 0x4
	enum class ESetMaskConditionType SetMaskCondition; // Offset: 0xc8 | Size: 0x1
	char pad_0xC9[0x7]; // Offset: 0xc9 | Size: 0x7

	// Functions

	// Object: Function FieldSystemEngine.RadialIntMask.SetRadialIntMask
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x105ae044c
	// Return & Params: [ Num(6) Size(0x28) ]
	struct URadialIntMask* SetRadialIntMask(float Radius, struct FVector Position, int32_t InteriorValue, int32_t ExteriorValue, enum class ESetMaskConditionType SetMaskConditionIn);
};

// Object: Class FieldSystemEngine.UniformScalar
// Inherited Bytes: 0xb0 | Struct Size: 0xb8
struct UUniformScalar : UFieldNodeFloat {
	// Fields
	float Magnitude; // Offset: 0xb0 | Size: 0x4
	char pad_0xB4[0x4]; // Offset: 0xb4 | Size: 0x4

	// Functions

	// Object: Function FieldSystemEngine.UniformScalar.SetUniformScalar
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x105ae0934
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UUniformScalar* SetUniformScalar(float Magnitude);
};

// Object: Class FieldSystemEngine.RadialFalloff
// Inherited Bytes: 0xb0 | Struct Size: 0xd8
struct URadialFalloff : UFieldNodeFloat {
	// Fields
	float Magnitude; // Offset: 0xb0 | Size: 0x4
	float MinRange; // Offset: 0xb4 | Size: 0x4
	float MaxRange; // Offset: 0xb8 | Size: 0x4
	float Default; // Offset: 0xbc | Size: 0x4
	float Radius; // Offset: 0xc0 | Size: 0x4
	struct FVector Position; // Offset: 0xc4 | Size: 0xc
	enum class EFieldFalloffType Falloff; // Offset: 0xd0 | Size: 0x1
	char pad_0xD1[0x7]; // Offset: 0xd1 | Size: 0x7

	// Functions

	// Object: Function FieldSystemEngine.RadialFalloff.SetRadialFalloff
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x105ae0cec
	// Return & Params: [ Num(8) Size(0x30) ]
	struct URadialFalloff* SetRadialFalloff(float Magnitude, float MinRange, float MaxRange, float Default, float Radius, struct FVector Position, enum class EFieldFalloffType Falloff);
};

// Object: Class FieldSystemEngine.PlaneFalloff
// Inherited Bytes: 0xb0 | Struct Size: 0xe0
struct UPlaneFalloff : UFieldNodeFloat {
	// Fields
	float Magnitude; // Offset: 0xb0 | Size: 0x4
	float MinRange; // Offset: 0xb4 | Size: 0x4
	float MaxRange; // Offset: 0xb8 | Size: 0x4
	float Default; // Offset: 0xbc | Size: 0x4
	float Distance; // Offset: 0xc0 | Size: 0x4
	struct FVector Position; // Offset: 0xc4 | Size: 0xc
	struct FVector Normal; // Offset: 0xd0 | Size: 0xc
	enum class EFieldFalloffType Falloff; // Offset: 0xdc | Size: 0x1
	char pad_0xDD[0x3]; // Offset: 0xdd | Size: 0x3

	// Functions

	// Object: Function FieldSystemEngine.PlaneFalloff.SetPlaneFalloff
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x105ae1280
	// Return & Params: [ Num(9) Size(0x38) ]
	struct UPlaneFalloff* SetPlaneFalloff(float Magnitude, float MinRange, float MaxRange, float Default, float Distance, struct FVector Position, struct FVector Normal, enum class EFieldFalloffType Falloff);
};

// Object: Class FieldSystemEngine.BoxFalloff
// Inherited Bytes: 0xb0 | Struct Size: 0x100
struct UBoxFalloff : UFieldNodeFloat {
	// Fields
	float Magnitude; // Offset: 0xb0 | Size: 0x4
	float MinRange; // Offset: 0xb4 | Size: 0x4
	float MaxRange; // Offset: 0xb8 | Size: 0x4
	float Default; // Offset: 0xbc | Size: 0x4
	struct FTransform Transform; // Offset: 0xc0 | Size: 0x30
	enum class EFieldFalloffType Falloff; // Offset: 0xf0 | Size: 0x1
	char pad_0xF1[0xf]; // Offset: 0xf1 | Size: 0xf

	// Functions

	// Object: Function FieldSystemEngine.BoxFalloff.SetBoxFalloff
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x105ae186c
	// Return & Params: [ Num(7) Size(0x50) ]
	struct UBoxFalloff* SetBoxFalloff(float Magnitude, float MinRange, float MaxRange, float Default, struct FTransform Transform, enum class EFieldFalloffType Falloff);
};

// Object: Class FieldSystemEngine.NoiseField
// Inherited Bytes: 0xb0 | Struct Size: 0xf0
struct UNoiseField : UFieldNodeFloat {
	// Fields
	float MinRange; // Offset: 0xb0 | Size: 0x4
	float MaxRange; // Offset: 0xb4 | Size: 0x4
	char pad_0xB8[0x8]; // Offset: 0xb8 | Size: 0x8
	struct FTransform Transform; // Offset: 0xc0 | Size: 0x30

	// Functions

	// Object: Function FieldSystemEngine.NoiseField.SetNoiseField
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x105ae1e10
	// Return & Params: [ Num(4) Size(0x48) ]
	struct UNoiseField* SetNoiseField(float MinRange, float MaxRange, struct FTransform Transform);
};

// Object: Class FieldSystemEngine.UniformVector
// Inherited Bytes: 0xb0 | Struct Size: 0xc0
struct UUniformVector : UFieldNodeVector {
	// Fields
	float Magnitude; // Offset: 0xb0 | Size: 0x4
	struct FVector Direction; // Offset: 0xb4 | Size: 0xc

	// Functions

	// Object: Function FieldSystemEngine.UniformVector.SetUniformVector
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x105ae22e4
	// Return & Params: [ Num(3) Size(0x18) ]
	struct UUniformVector* SetUniformVector(float Magnitude, struct FVector Direction);
};

// Object: Class FieldSystemEngine.RadialVector
// Inherited Bytes: 0xb0 | Struct Size: 0xc0
struct URadialVector : UFieldNodeVector {
	// Fields
	float Magnitude; // Offset: 0xb0 | Size: 0x4
	struct FVector Position; // Offset: 0xb4 | Size: 0xc

	// Functions

	// Object: Function FieldSystemEngine.RadialVector.SetRadialVector
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x105ae26e4
	// Return & Params: [ Num(3) Size(0x18) ]
	struct URadialVector* SetRadialVector(float Magnitude, struct FVector Position);
};

// Object: Class FieldSystemEngine.RandomVector
// Inherited Bytes: 0xb0 | Struct Size: 0xb8
struct URandomVector : UFieldNodeVector {
	// Fields
	float Magnitude; // Offset: 0xb0 | Size: 0x4
	char pad_0xB4[0x4]; // Offset: 0xb4 | Size: 0x4

	// Functions

	// Object: Function FieldSystemEngine.RandomVector.SetRandomVector
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x105ae2ae4
	// Return & Params: [ Num(2) Size(0x10) ]
	struct URandomVector* SetRandomVector(float Magnitude);
};

// Object: Class FieldSystemEngine.OperatorField
// Inherited Bytes: 0xb0 | Struct Size: 0xd0
struct UOperatorField : UFieldNodeBase {
	// Fields
	float Magnitude; // Offset: 0xb0 | Size: 0x4
	char pad_0xB4[0x4]; // Offset: 0xb4 | Size: 0x4
	struct UFieldNodeBase* RightField; // Offset: 0xb8 | Size: 0x8
	struct UFieldNodeBase* LeftField; // Offset: 0xc0 | Size: 0x8
	enum class EFieldOperationType Operation; // Offset: 0xc8 | Size: 0x1
	char pad_0xC9[0x7]; // Offset: 0xc9 | Size: 0x7

	// Functions

	// Object: Function FieldSystemEngine.OperatorField.SetOperatorField
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x105ae2e9c
	// Return & Params: [ Num(5) Size(0x28) ]
	struct UOperatorField* SetOperatorField(float Magnitude, struct UFieldNodeBase* RightField, struct UFieldNodeBase* LeftField, enum class EFieldOperationType Operation);
};

// Object: Class FieldSystemEngine.ToIntegerField
// Inherited Bytes: 0xb0 | Struct Size: 0xb8
struct UToIntegerField : UFieldNodeInt {
	// Fields
	struct UFieldNodeFloat* FloatField; // Offset: 0xb0 | Size: 0x8

	// Functions

	// Object: Function FieldSystemEngine.ToIntegerField.SetToIntegerField
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x105ae333c
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UToIntegerField* SetToIntegerField(struct UFieldNodeFloat* FloatField);
};

// Object: Class FieldSystemEngine.ToFloatField
// Inherited Bytes: 0xb0 | Struct Size: 0xb8
struct UToFloatField : UFieldNodeFloat {
	// Fields
	struct UFieldNodeInt* IntField; // Offset: 0xb0 | Size: 0x8

	// Functions

	// Object: Function FieldSystemEngine.ToFloatField.SetToFloatField
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x105ae36f0
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UToFloatField* SetToFloatField(struct UFieldNodeInt* IntegerField);
};

// Object: Class FieldSystemEngine.CullingField
// Inherited Bytes: 0xb0 | Struct Size: 0xc8
struct UCullingField : UFieldNodeBase {
	// Fields
	struct UFieldNodeBase* Culling; // Offset: 0xb0 | Size: 0x8
	struct UFieldNodeBase* Field; // Offset: 0xb8 | Size: 0x8
	enum class EFieldCullingOperationType Operation; // Offset: 0xc0 | Size: 0x1
	char pad_0xC1[0x7]; // Offset: 0xc1 | Size: 0x7

	// Functions

	// Object: Function FieldSystemEngine.CullingField.SetCullingField
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x105ae3aa4
	// Return & Params: [ Num(4) Size(0x20) ]
	struct UCullingField* SetCullingField(struct UFieldNodeBase* Culling, struct UFieldNodeBase* Field, enum class EFieldCullingOperationType Operation);
};

// Object: Class FieldSystemEngine.ReturnResultsTerminal
// Inherited Bytes: 0xb0 | Struct Size: 0xb0
struct UReturnResultsTerminal : UFieldNodeBase {
	// Functions

	// Object: Function FieldSystemEngine.ReturnResultsTerminal.SetReturnResultsTerminal
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x105ae3ef0
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UReturnResultsTerminal* SetReturnResultsTerminal();
};

