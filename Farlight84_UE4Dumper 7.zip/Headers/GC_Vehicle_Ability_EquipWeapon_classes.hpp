#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass GC_Vehicle_Ability_EquipWeapon.GC_Vehicle_Ability_EquipWeapon_C
// Inherited Bytes: 0x50 | Struct Size: 0x50
struct UGC_Vehicle_Ability_EquipWeapon_C : USolarVehicleGC_EquipWeapon {
};

