#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass GC_Vehicle_Ability_HoverJump.GC_Vehicle_Ability_HoverJump_C
// Inherited Bytes: 0x60 | Struct Size: 0x60
struct UGC_Vehicle_Ability_HoverJump_C : USolarVehicleGC_HoverJump {
};

