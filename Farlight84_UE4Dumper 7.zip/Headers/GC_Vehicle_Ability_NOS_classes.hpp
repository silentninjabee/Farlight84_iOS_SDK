#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass GC_Vehicle_Ability_NOS.GC_Vehicle_Ability_NOS_C
// Inherited Bytes: 0x2a0 | Struct Size: 0x2a8
struct AGC_Vehicle_Ability_NOS_C : ASolarVehicleNosGCNotify_Actor {
	// Fields
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x2a0 | Size: 0x8
};

