#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass GC_Vehicle_Ability_SelfHealing.GC_Vehicle_Ability_SelfHealing_C
// Inherited Bytes: 0xa8 | Struct Size: 0xa8
struct UGC_Vehicle_Ability_SelfHealing_C : USelfHealingCueNotify_Static {
};

