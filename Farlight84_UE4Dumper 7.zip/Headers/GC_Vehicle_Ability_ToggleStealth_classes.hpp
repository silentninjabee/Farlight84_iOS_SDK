#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass GC_Vehicle_Ability_ToggleStealth.GC_Vehicle_Ability_ToggleStealth_C
// Inherited Bytes: 0x550 | Struct Size: 0x558
struct AGC_Vehicle_Ability_ToggleStealth_C : AVehicleStealthGCNotify_Actor {
	// Fields
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x550 | Size: 0x8
};

