#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass GC_Vehicle_Ability_WholeShield.GC_Vehicle_Ability_WholeShield_C
// Inherited Bytes: 0x578 | Struct Size: 0x580
struct AGC_Vehicle_Ability_WholeShield_C : AVehicleWholeShieldGCNotify_Actor {
	// Fields
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x578 | Size: 0x8
};

