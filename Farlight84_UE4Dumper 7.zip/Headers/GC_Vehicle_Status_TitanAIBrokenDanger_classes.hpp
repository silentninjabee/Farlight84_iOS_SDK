#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass GC_Vehicle_Status_TitanAIBrokenDanger.GC_Vehicle_Status_TitanAIBrokenDanger_C
// Inherited Bytes: 0x50 | Struct Size: 0x50
struct UGC_Vehicle_Status_TitanAIBrokenDanger_C : UGameplayCueNotify_Static {
	// Functions

	// Object: Function GC_Vehicle_Status_TitanAIBrokenDanger.GC_Vehicle_Status_TitanAIBrokenDanger_C.WhileActive
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(3) Size(0xc9) ]
	bool WhileActive(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters);

	// Object: Function GC_Vehicle_Status_TitanAIBrokenDanger.GC_Vehicle_Status_TitanAIBrokenDanger_C.OnRemove
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(3) Size(0xc9) ]
	bool OnRemove(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters);

	// Object: Function GC_Vehicle_Status_TitanAIBrokenDanger.GC_Vehicle_Status_TitanAIBrokenDanger_C.OnActive
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(3) Size(0xc9) ]
	bool OnActive(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters);
};

