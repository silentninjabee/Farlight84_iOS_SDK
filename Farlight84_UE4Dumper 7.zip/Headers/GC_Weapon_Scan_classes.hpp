#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass GC_Weapon_Scan.GC_Weapon_Scan_C
// Inherited Bytes: 0x298 | Struct Size: 0x2a8
struct AGC_Weapon_Scan_C : AGameplayCueNotify_Actor {
	// Fields
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x298 | Size: 0x8
	float Duration; // Offset: 0x2a0 | Size: 0x4
	float ScanRadius; // Offset: 0x2a4 | Size: 0x4

	// Functions

	// Object: Function GC_Weapon_Scan.GC_Weapon_Scan_C.PlaySound
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(2) Size(0x14) ]
	void PlaySound(struct ASolarCharacter* CueOwner, struct FVector CueLocation);

	// Object: Function GC_Weapon_Scan.GC_Weapon_Scan_C.OnActive
	// Flags: [Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(3) Size(0xc9) ]
	bool OnActive(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters);
};

