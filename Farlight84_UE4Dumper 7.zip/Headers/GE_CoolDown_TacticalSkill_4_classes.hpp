#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass GE_CoolDown_TacticalSkill_4.GE_CoolDown_TacticalSkill_3_C
// Inherited Bytes: 0x848 | Struct Size: 0x848
struct UGE_CoolDown_TacticalSkill_3_C : UGameplayEffect {
};

