#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass GE_Cost_Super.GE_Cost_Super_C
// Inherited Bytes: 0x848 | Struct Size: 0x848
struct UGE_Cost_Super_C : UGameplayEffect {
};

