#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass GE_Cost_Tactical1.GE_Cost_Tactical1_C
// Inherited Bytes: 0x848 | Struct Size: 0x848
struct UGE_Cost_Tactical1_C : UGameplayEffect {
};

