#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class GameplayTasks.GameplayTasksComponent
// Inherited Bytes: 0xb0 | Struct Size: 0x120
struct UGameplayTasksComponent : UActorComponent {
	// Fields
	char pad_0xB0[0xc]; // Offset: 0xb0 | Size: 0xc
	char pad_0xBC_0 : 1; // Offset: 0xbc | Size: 0x1
	char bIsNetDirty : 1; // Offset: 0xbc | Size: 0x1
	char pad_0xBC_2 : 6; // Offset: 0xbc | Size: 0x1
	char pad_0xBD[0x3]; // Offset: 0xbd | Size: 0x3
	struct TArray<struct UGameplayTask*> SimulatedTasks; // Offset: 0xc0 | Size: 0x10
	struct TArray<struct UGameplayTask*> TaskPriorityQueue; // Offset: 0xd0 | Size: 0x10
	char pad_0xE0[0x10]; // Offset: 0xe0 | Size: 0x10
	struct TArray<struct UGameplayTask*> TickingTasks; // Offset: 0xf0 | Size: 0x10
	struct TArray<struct UGameplayTask*> KnownTasks; // Offset: 0x100 | Size: 0x10
	struct FMulticastInlineDelegate OnClaimedResourcesChange; // Offset: 0x110 | Size: 0x10

	// Functions

	// Object: Function GameplayTasks.GameplayTasksComponent.OnRep_SimulatedTasks
	// Flags: [Final|Native|Public]
	// Offset: 0x105ac0a50
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnRep_SimulatedTasks();

	// Object: Function GameplayTasks.GameplayTasksComponent.K2_RunGameplayTask
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105ac07c0
	// Return & Params: [ Num(6) Size(0x41) ]
	enum class EGameplayTaskRunResult K2_RunGameplayTask(struct TScriptInterface<IGameplayTaskOwnerInterface> TaskOwner, struct UGameplayTask* Task, char Priority, struct TArray<struct UGameplayTaskResource*> AdditionalRequiredResources, struct TArray<struct UGameplayTaskResource*> AdditionalClaimedResources);
};

// Object: Class GameplayTasks.GameplayTask
// Inherited Bytes: 0x28 | Struct Size: 0x60
struct UGameplayTask : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
	struct FName InstanceName; // Offset: 0x30 | Size: 0x8
	char pad_0x38[0x2]; // Offset: 0x38 | Size: 0x2
	enum class ETaskResourceOverlapPolicy ResourceOverlapPolicy; // Offset: 0x3a | Size: 0x1
	char pad_0x3B[0x1d]; // Offset: 0x3b | Size: 0x1d
	struct UGameplayTask* ChildTask; // Offset: 0x58 | Size: 0x8

	// Functions

	// Object: Function GameplayTasks.GameplayTask.ReadyForActivation
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105abe91c
	// Return & Params: [ Num(0) Size(0x0) ]
	void ReadyForActivation();

	// Object: DelegateFunction GameplayTasks.GameplayTask.GenericGameplayTaskDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(0) Size(0x0) ]
	void GenericGameplayTaskDelegate__DelegateSignature();

	// Object: Function GameplayTasks.GameplayTask.EndTask
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105abe908
	// Return & Params: [ Num(0) Size(0x0) ]
	void EndTask();
};

// Object: Class GameplayTasks.GameplayTask_ClaimResource
// Inherited Bytes: 0x60 | Struct Size: 0x60
struct UGameplayTask_ClaimResource : UGameplayTask {
	// Functions

	// Object: Function GameplayTasks.GameplayTask_ClaimResource.ClaimResources
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105abecc0
	// Return & Params: [ Num(5) Size(0x38) ]
	struct UGameplayTask_ClaimResource* ClaimResources(struct TScriptInterface<IGameplayTaskOwnerInterface> InTaskOwner, struct TArray<struct UGameplayTaskResource*> ResourceClasses, char Priority, struct FName TaskInstanceName);

	// Object: Function GameplayTasks.GameplayTask_ClaimResource.ClaimResource
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105abee90
	// Return & Params: [ Num(5) Size(0x30) ]
	struct UGameplayTask_ClaimResource* ClaimResource(struct TScriptInterface<IGameplayTaskOwnerInterface> InTaskOwner, struct UGameplayTaskResource* ResourceClass, char Priority, struct FName TaskInstanceName);
};

// Object: Class GameplayTasks.GameplayTask_SpawnActor
// Inherited Bytes: 0x60 | Struct Size: 0xa0
struct UGameplayTask_SpawnActor : UGameplayTask {
	// Fields
	struct FMulticastInlineDelegate Success; // Offset: 0x60 | Size: 0x10
	struct FMulticastInlineDelegate DidNotSpawn; // Offset: 0x70 | Size: 0x10
	char pad_0x80[0x18]; // Offset: 0x80 | Size: 0x18
	struct AActor* ClassToSpawn; // Offset: 0x98 | Size: 0x8

	// Functions

	// Object: Function GameplayTasks.GameplayTask_SpawnActor.SpawnActor
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x105abf6bc
	// Return & Params: [ Num(6) Size(0x40) ]
	struct UGameplayTask_SpawnActor* SpawnActor(struct TScriptInterface<IGameplayTaskOwnerInterface> TaskOwner, struct FVector SpawnLocation, struct FRotator SpawnRotation, struct AActor* Class, bool bSpawnOnlyOnAuthority);

	// Object: Function GameplayTasks.GameplayTask_SpawnActor.FinishSpawningActor
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x105abf4fc
	// Return & Params: [ Num(2) Size(0x10) ]
	void FinishSpawningActor(struct UObject* WorldContextObject, struct AActor* SpawnedActor);

	// Object: Function GameplayTasks.GameplayTask_SpawnActor.BeginSpawningActor
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105abf5cc
	// Return & Params: [ Num(3) Size(0x11) ]
	bool BeginSpawningActor(struct UObject* WorldContextObject, struct AActor*& SpawnedActor);
};

// Object: Class GameplayTasks.GameplayTask_TimeLimitedExecution
// Inherited Bytes: 0x60 | Struct Size: 0x90
struct UGameplayTask_TimeLimitedExecution : UGameplayTask {
	// Fields
	struct FMulticastInlineDelegate OnFinished; // Offset: 0x60 | Size: 0x10
	struct FMulticastInlineDelegate OnTimeExpired; // Offset: 0x70 | Size: 0x10
	char pad_0x80[0x10]; // Offset: 0x80 | Size: 0x10
};

// Object: Class GameplayTasks.GameplayTask_WaitDelay
// Inherited Bytes: 0x60 | Struct Size: 0x78
struct UGameplayTask_WaitDelay : UGameplayTask {
	// Fields
	struct FMulticastInlineDelegate OnFinish; // Offset: 0x60 | Size: 0x10
	char pad_0x70[0x8]; // Offset: 0x70 | Size: 0x8

	// Functions

	// Object: Function GameplayTasks.GameplayTask_WaitDelay.TaskWaitDelay
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105abff10
	// Return & Params: [ Num(4) Size(0x20) ]
	struct UGameplayTask_WaitDelay* TaskWaitDelay(struct TScriptInterface<IGameplayTaskOwnerInterface> TaskOwner, float Time, char Priority);

	// Object: DelegateFunction GameplayTasks.GameplayTask_WaitDelay.TaskDelayDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(0) Size(0x0) ]
	void TaskDelayDelegate__DelegateSignature();
};

// Object: Class GameplayTasks.GameplayTaskOwnerInterface
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UGameplayTaskOwnerInterface : UInterface {
};

// Object: Class GameplayTasks.GameplayTaskResource
// Inherited Bytes: 0x28 | Struct Size: 0x30
struct UGameplayTaskResource : UObject {
	// Fields
	int32_t ManualResourceID; // Offset: 0x28 | Size: 0x4
	int8_t AutoResourceID; // Offset: 0x2c | Size: 0x1
	char bManuallySetID : 1; // Offset: 0x2d | Size: 0x1
	char pad_0x2D_1 : 7; // Offset: 0x2d | Size: 0x1
	char pad_0x2E[0x2]; // Offset: 0x2e | Size: 0x2
};

