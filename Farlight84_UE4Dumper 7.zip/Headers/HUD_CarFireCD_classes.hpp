#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass HUD_CarFireCD.HUD_CarFireCD_C
// Inherited Bytes: 0x4a8 | Struct Size: 0x4a8
struct UHUD_CarFireCD_C : USolarWeaponRechamberWidget {
};

