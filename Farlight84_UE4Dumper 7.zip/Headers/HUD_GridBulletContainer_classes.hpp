#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass HUD_GridBulletContainer.HUD_GridBulletContainer_C
// Inherited Bytes: 0x580 | Struct Size: 0x878
struct UHUD_GridBulletContainer_C : UGridBulletContainer {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x580 | Size: 0x8
	struct UImage* bg_BulletEmpty; // Offset: 0x588 | Size: 0x8
	struct UImage* bg_BulletEmptyShine; // Offset: 0x590 | Size: 0x8
	struct UImage* bg_BulletGrid; // Offset: 0x598 | Size: 0x8
	struct UImage* Img_LightAll; // Offset: 0x5a0 | Size: 0x8
	int32_t CurrentBulletForDebug; // Offset: 0x5a8 | Size: 0x4
	int32_t MaxBulletForDebug; // Offset: 0x5ac | Size: 0x4
	struct FProgressBarStyle NewVar_1; // Offset: 0x5b0 | Size: 0x2b0
	bool IsMaxAmmoChanged; // Offset: 0x860 | Size: 0x1
	char pad_0x861[0x7]; // Offset: 0x861 | Size: 0x7
	struct TArray<struct UWidget*> DivisorWidgetArray; // Offset: 0x868 | Size: 0x10

	// Functions

	// Object: Function HUD_GridBulletContainer.HUD_GridBulletContainer_C.ReceiveUpdateMaxAmmoEvent
	// Flags: [Event|Protected|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x4) ]
	void ReceiveUpdateMaxAmmoEvent(int32_t InMaxAmmo);

	// Object: Function HUD_GridBulletContainer.HUD_GridBulletContainer_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(0) Size(0x0) ]
	void Construct();

	// Object: Function HUD_GridBulletContainer.HUD_GridBulletContainer_C.ExecuteUbergraph_HUD_GridBulletContainer
	// Flags: [Final|UbergraphFunction|HasDefaults]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_HUD_GridBulletContainer(int32_t EntryPoint);
};

