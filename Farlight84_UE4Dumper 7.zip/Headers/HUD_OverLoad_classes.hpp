#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass HUD_OverLoad.HUD_Overload_C
// Inherited Bytes: 0x260 | Struct Size: 0x335
struct UHUD_Overload_C : UUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x260 | Size: 0x8
	struct UWidgetAnimation* Overheat_Anim; // Offset: 0x268 | Size: 0x8
	struct UImage* Img_Disable; // Offset: 0x270 | Size: 0x8
	struct UImage* Img_Disable_2; // Offset: 0x278 | Size: 0x8
	struct UImage* img_overload; // Offset: 0x280 | Size: 0x8
	struct UImage* img_overload_bg; // Offset: 0x288 | Size: 0x8
	struct UImage* img_overload_Glow; // Offset: 0x290 | Size: 0x8
	struct UCanvasPanel* OverloadWarning; // Offset: 0x298 | Size: 0x8
	struct FVector2D OverloadImgMaxSize; // Offset: 0x2a0 | Size: 0x8
	float AnimImgRatio; // Offset: 0x2a8 | Size: 0x4
	float OverloadProgress; // Offset: 0x2ac | Size: 0x4
	struct UUserWidget* ParentWidget; // Offset: 0x2b0 | Size: 0x8
	struct UCurveLinearColor* ColorCurve; // Offset: 0x2b8 | Size: 0x8
	struct FVector2D ShadowSize; // Offset: 0x2c0 | Size: 0x8
	float ImgMaxParmValue; // Offset: 0x2c8 | Size: 0x4
	float ImgParmOffset; // Offset: 0x2cc | Size: 0x4
	struct FLinearColor NewVar_1; // Offset: 0x2d0 | Size: 0x10
	struct TMap<struct UUserWidget*, struct FVector2D> CrosshairScaleMapping; // Offset: 0x2e0 | Size: 0x50
	float NewVar_2; // Offset: 0x330 | Size: 0x4
	bool AlwaysShowOverload; // Offset: 0x334 | Size: 0x1

	// Functions

	// Object: Function HUD_OverLoad.HUD_Overload_C.PlayOverloadAnima
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x1) ]
	void PlayOverloadAnima(bool InOverload);

	// Object: Function HUD_OverLoad.HUD_Overload_C.SetCoolDownProgress
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(0) Size(0x0) ]
	void SetCoolDownProgress();

	// Object: Function HUD_OverLoad.HUD_Overload_C.SetOverLoadImageSize
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetOverLoadImageSize(float InProgress);

	// Object: Function HUD_OverLoad.HUD_Overload_C.OnChangeReloadState
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(2) Size(0x2) ]
	void OnChangeReloadState(bool InbQuitState, bool bReloadSpeedup);

	// Object: Function HUD_OverLoad.HUD_Overload_C.OnInsufficientAmmo
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnInsufficientAmmo();

	// Object: Function HUD_OverLoad.HUD_Overload_C.OnReloadFinish
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(5) Size(0x14) ]
	void OnReloadFinish(bool InbReloadSuccess, int32_t InReloadAmmo, int32_t InReservedAmmo, int32_t InMaxAmmo, float InAmmoProgress);

	// Object: Function HUD_OverLoad.HUD_Overload_C.OnUpdateAmmo
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(4) Size(0xd) ]
	void OnUpdateAmmo(int32_t InReservedAmmo, int32_t InMaxAmmo, float InAmmoProgress, bool InbFirst);

	// Object: Function HUD_OverLoad.HUD_Overload_C.OnUpdateCharge
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(3) Size(0xc) ]
	void OnUpdateCharge(bool InbCharging, int32_t InChargeMode, float InChargeProgress);

	// Object: Function HUD_OverLoad.HUD_Overload_C.OnUpdateCoolDown
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x4) ]
	void OnUpdateCoolDown(float InReloadProgress);

	// Object: Function HUD_OverLoad.HUD_Overload_C.OnUpdateReload
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(3) Size(0xc) ]
	void OnUpdateReload(float InReloadProgress, int32_t InReloadAmmo, int32_t InMaxAmmo);

	// Object: Function HUD_OverLoad.HUD_Overload_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function HUD_OverLoad.HUD_Overload_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(0) Size(0x0) ]
	void Construct();

	// Object: Function HUD_OverLoad.HUD_Overload_C.OnUpdateOverload
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(3) Size(0x9) ]
	void OnUpdateOverload(float InOverloadProgress, float InOverloadWarningRate, bool InbOverloadState);

	// Object: Function HUD_OverLoad.HUD_Overload_C.OnChangeOverloadState
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnChangeOverloadState(bool InbQuitState);

	// Object: Function HUD_OverLoad.HUD_Overload_C.OnActiveCrosshair
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x8) ]
	void OnActiveCrosshair(struct UUserWidget* InActiveCrosshair);

	// Object: Function HUD_OverLoad.HUD_Overload_C.ExecuteUbergraph_HUD_Overload
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_HUD_Overload(int32_t EntryPoint);
};

