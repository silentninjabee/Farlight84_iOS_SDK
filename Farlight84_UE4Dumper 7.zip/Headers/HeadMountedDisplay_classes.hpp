#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class HeadMountedDisplay.HeadMountedDisplayFunctionLibrary
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UHeadMountedDisplayFunctionLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.UpdateExternalTrackingHMDPosition
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x104426218
	// Return & Params: [ Num(1) Size(0x30) ]
	void UpdateExternalTrackingHMDPosition(struct FTransform& ExternalTrackingTransform);

	// Object: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.SetWorldToMetersScale
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1044265b0
	// Return & Params: [ Num(2) Size(0xc) ]
	void SetWorldToMetersScale(struct UObject* WorldContext, float NewScale);

	// Object: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.SetTrackingOrigin
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1044264b8
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetTrackingOrigin(enum class EHMDTrackingOrigin Origin);

	// Object: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.SetSpectatorScreenTexture
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104426014
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetSpectatorScreenTexture(struct UTexture* InTexture);

	// Object: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.SetSpectatorScreenModeTexturePlusEyeLayout
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x104425dc8
	// Return & Params: [ Num(7) Size(0x23) ]
	void SetSpectatorScreenModeTexturePlusEyeLayout(struct FVector2D EyeRectMin, struct FVector2D EyeRectMax, struct FVector2D TextureRectMin, struct FVector2D TextureRectMax, bool bDrawEyeFirst, bool bClearBlack, bool bUseAlpha);

	// Object: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.SetSpectatorScreenMode
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10442608c
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetSpectatorScreenMode(enum class ESpectatorScreenMode Mode);

	// Object: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.SetClippingPlanes
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1044266dc
	// Return & Params: [ Num(2) Size(0x8) ]
	void SetClippingPlanes(float Near, float Far);

	// Object: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.ResetOrientationAndPosition
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10442679c
	// Return & Params: [ Num(2) Size(0x5) ]
	void ResetOrientationAndPosition(float Yaw, enum class EOrientPositionSelector options);

	// Object: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.IsSpectatorScreenModeControllable
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x104426104
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsSpectatorScreenModeControllable();

	// Object: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.IsInLowPersistenceMode
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1044268d0
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsInLowPersistenceMode();

	// Object: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.IsHeadMountedDisplayEnabled
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x104427238
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsHeadMountedDisplayEnabled();

	// Object: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.IsHeadMountedDisplayConnected
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x104427204
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsHeadMountedDisplayConnected();

	// Object: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.IsDeviceTracking
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1044257e8
	// Return & Params: [ Num(2) Size(0xd) ]
	bool IsDeviceTracking(struct FXRDeviceId& XRDeviceId);

	// Object: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.HasValidTrackingPosition
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x10442700c
	// Return & Params: [ Num(1) Size(0x1) ]
	bool HasValidTrackingPosition();

	// Object: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.GetWorldToMetersScale
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x104426530
	// Return & Params: [ Num(2) Size(0xc) ]
	float GetWorldToMetersScale(struct UObject* WorldContext);

	// Object: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.GetVRFocusState
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x104426138
	// Return & Params: [ Num(2) Size(0x2) ]
	void GetVRFocusState(bool& bUseFocus, bool& bHasFocus);

	// Object: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.GetTrackingToWorldTransform
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x1044263c8
	// Return & Params: [ Num(2) Size(0x40) ]
	struct FTransform GetTrackingToWorldTransform(struct UObject* WorldContext);

	// Object: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.GetTrackingSensorParameters
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x104426ba0
	// Return & Params: [ Num(11) Size(0x3c) ]
	void GetTrackingSensorParameters(struct FVector& Origin, struct FRotator& Rotation, float& LeftFOV, float& RightFOV, float& TopFOV, float& BottomFOV, float& Distance, float& NearPlane, float& FarPlane, bool& IsActive, int32_t Index);

	// Object: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.GetTrackingOrigin
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x104426484
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class EHMDTrackingOrigin GetTrackingOrigin();

	// Object: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.GetScreenPercentage
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1044266a8
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetScreenPercentage();

	// Object: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.GetPositionalTrackingCameraParameters
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x1044268e8
	// Return & Params: [ Num(7) Size(0x2c) ]
	void GetPositionalTrackingCameraParameters(struct FVector& CameraOrigin, struct FRotator& CameraRotation, float& HFOV, float& VFOV, float& CameraDistance, float& NearPlane, float& FarPlane);

	// Object: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.GetPixelDensity
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x104426674
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetPixelDensity();

	// Object: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.GetOrientationAndPosition
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x104427040
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetOrientationAndPosition(struct FRotator& DeviceRotation, struct FVector& DevicePosition);

	// Object: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.GetNumOfTrackingSensors
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x104426fd8
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetNumOfTrackingSensors();

	// Object: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.GetHMDWornState
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x104427114
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class EHMDWornState GetHMDWornState();

	// Object: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.GetHMDDeviceName
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x104427148
	// Return & Params: [ Num(1) Size(0x8) ]
	struct FName GetHMDDeviceName();

	// Object: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.GetDeviceWorldPose
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x104425878
	// Return & Params: [ Num(6) Size(0x34) ]
	void GetDeviceWorldPose(struct UObject* WorldContext, struct FXRDeviceId& XRDeviceId, bool& bIsTracked, struct FRotator& Orientation, bool& bHasPositionalTracking, struct FVector& Position);

	// Object: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.GetDevicePose
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x104425ac0
	// Return & Params: [ Num(5) Size(0x2c) ]
	void GetDevicePose(struct FXRDeviceId& XRDeviceId, bool& bIsTracked, struct FRotator& Orientation, bool& bHasPositionalTracking, struct FVector& Position);

	// Object: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.EnumerateTrackedDevices
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104425cb8
	// Return & Params: [ Num(3) Size(0x20) ]
	struct TArray<struct FXRDeviceId> EnumerateTrackedDevices(struct FName SystemId, enum class EXRTrackedDeviceType DeviceType);

	// Object: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.EnableLowPersistenceMode
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104426860
	// Return & Params: [ Num(1) Size(0x1) ]
	void EnableLowPersistenceMode(bool bEnable);

	// Object: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.EnableHMD
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10442717c
	// Return & Params: [ Num(2) Size(0x2) ]
	bool EnableHMD(bool bEnable);

	// Object: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.CalibrateExternalTrackingToHMD
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1044262f0
	// Return & Params: [ Num(1) Size(0x30) ]
	void CalibrateExternalTrackingToHMD(struct FTransform& ExternalTrackingTransform);
};

// Object: Class HeadMountedDisplay.MotionControllerComponent
// Inherited Bytes: 0x5b0 | Struct Size: 0x660
struct UMotionControllerComponent : UPrimitiveComponent {
	// Fields
	int32_t PlayerIndex; // Offset: 0x5a8 | Size: 0x4
	enum class EControllerHand Hand; // Offset: 0x5ac | Size: 0x1
	struct FName MotionSource; // Offset: 0x5b0 | Size: 0x8
	char bDisableLowLatencyUpdate : 1; // Offset: 0x5b8 | Size: 0x1
	enum class ETrackingStatus CurrentTrackingStatus; // Offset: 0x5b9 | Size: 0x1
	bool bDisplayDeviceModel; // Offset: 0x5ba | Size: 0x1
	struct FName DisplayModelSource; // Offset: 0x5bc | Size: 0x8
	char pad_0x5C7_1 : 7; // Offset: 0x5c7 | Size: 0x1
	struct UStaticMesh* CustomDisplayMesh; // Offset: 0x5c8 | Size: 0x8
	struct TArray<struct UMaterialInterface*> DisplayMeshMaterialOverrides; // Offset: 0x5d0 | Size: 0x10
	char pad_0x5E0[0x60]; // Offset: 0x5e0 | Size: 0x60
	struct UPrimitiveComponent* DisplayComponent; // Offset: 0x640 | Size: 0x8
	char pad_0x648[0x18]; // Offset: 0x648 | Size: 0x18

	// Functions

	// Object: Function HeadMountedDisplay.MotionControllerComponent.SetTrackingSource
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1044287f0
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetTrackingSource(enum class EControllerHand NewSource);

	// Object: Function HeadMountedDisplay.MotionControllerComponent.SetTrackingMotionSource
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10442873c
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetTrackingMotionSource(struct FName NewSource);

	// Object: Function HeadMountedDisplay.MotionControllerComponent.SetShowDeviceModel
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104428970
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetShowDeviceModel(bool bShowControllerModel);

	// Object: Function HeadMountedDisplay.MotionControllerComponent.SetDisplayModelSource
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1044288f0
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetDisplayModelSource(struct FName NewDisplayModelSource);

	// Object: Function HeadMountedDisplay.MotionControllerComponent.SetCustomDisplayMesh
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104428870
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetCustomDisplayMesh(struct UStaticMesh* NewDisplayMesh);

	// Object: Function HeadMountedDisplay.MotionControllerComponent.SetAssociatedPlayerIndex
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1044286bc
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetAssociatedPlayerIndex(int32_t NewPlayer);

	// Object: Function HeadMountedDisplay.MotionControllerComponent.OnMotionControllerUpdated
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnMotionControllerUpdated();

	// Object: Function HeadMountedDisplay.MotionControllerComponent.IsTracked
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1044289f8
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsTracked();

	// Object: Function HeadMountedDisplay.MotionControllerComponent.GetTrackingSource
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1044287bc
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class EControllerHand GetTrackingSource();

	// Object: Function HeadMountedDisplay.MotionControllerComponent.GetParameterValue
	// Flags: [Final|Native|Protected|HasOutParms|BlueprintCallable]
	// Offset: 0x1044285d4
	// Return & Params: [ Num(3) Size(0x10) ]
	float GetParameterValue(struct FName InName, bool& bValueFound);

	// Object: Function HeadMountedDisplay.MotionControllerComponent.GetHandJointPosition
	// Flags: [Final|Native|Protected|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1044284e4
	// Return & Params: [ Num(3) Size(0x14) ]
	struct FVector GetHandJointPosition(int32_t jointIndex, bool& bValueFound);
};

// Object: Class HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UMotionTrackedDeviceFunctionLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object: Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.SetIsControllerMotionTrackingEnabledByDefault
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10442992c
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetIsControllerMotionTrackingEnabledByDefault(bool Enable);

	// Object: Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.IsMotionTrackingEnabledForSource
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x10442972c
	// Return & Params: [ Num(3) Size(0xd) ]
	bool IsMotionTrackingEnabledForSource(int32_t PlayerIndex, struct FName SourceName);

	// Object: Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.IsMotionTrackingEnabledForDevice
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1044297f8
	// Return & Params: [ Num(3) Size(0x6) ]
	bool IsMotionTrackingEnabledForDevice(int32_t PlayerIndex, enum class EControllerHand Hand);

	// Object: Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.IsMotionTrackingEnabledForComponent
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1044296ac
	// Return & Params: [ Num(2) Size(0x9) ]
	bool IsMotionTrackingEnabledForComponent(struct UMotionControllerComponent* MotionControllerComponent);

	// Object: Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.IsMotionTrackedDeviceCountManagementNecessary
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1044299ac
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsMotionTrackedDeviceCountManagementNecessary();

	// Object: Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.IsMotionSourceTracking
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104429088
	// Return & Params: [ Num(3) Size(0xd) ]
	bool IsMotionSourceTracking(int32_t PlayerIndex, struct FName SourceName);

	// Object: Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.GetMotionTrackingEnabledControllerCount
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1044298c4
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetMotionTrackingEnabledControllerCount();

	// Object: Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.GetMaximumMotionTrackedControllerCount
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1044298f8
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetMaximumMotionTrackedControllerCount();

	// Object: Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.GetActiveTrackingSystemName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104429154
	// Return & Params: [ Num(1) Size(0x8) ]
	struct FName GetActiveTrackingSystemName();

	// Object: Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.EnumerateMotionSources
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104429188
	// Return & Params: [ Num(1) Size(0x10) ]
	struct TArray<struct FName> EnumerateMotionSources();

	// Object: Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.EnableMotionTrackingOfSource
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104429514
	// Return & Params: [ Num(3) Size(0xd) ]
	bool EnableMotionTrackingOfSource(int32_t PlayerIndex, struct FName SourceName);

	// Object: Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.EnableMotionTrackingOfDevice
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1044295e0
	// Return & Params: [ Num(3) Size(0x6) ]
	bool EnableMotionTrackingOfDevice(int32_t PlayerIndex, enum class EControllerHand Hand);

	// Object: Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.EnableMotionTrackingForComponent
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104429494
	// Return & Params: [ Num(2) Size(0x9) ]
	bool EnableMotionTrackingForComponent(struct UMotionControllerComponent* MotionControllerComponent);

	// Object: Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.DisableMotionTrackingOfSource
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10442930c
	// Return & Params: [ Num(2) Size(0xc) ]
	void DisableMotionTrackingOfSource(int32_t PlayerIndex, struct FName SourceName);

	// Object: Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.DisableMotionTrackingOfDevice
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1044293d0
	// Return & Params: [ Num(2) Size(0x5) ]
	void DisableMotionTrackingOfDevice(int32_t PlayerIndex, enum class EControllerHand Hand);

	// Object: Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.DisableMotionTrackingOfControllersForPlayer
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104429208
	// Return & Params: [ Num(1) Size(0x4) ]
	void DisableMotionTrackingOfControllersForPlayer(int32_t PlayerIndex);

	// Object: Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.DisableMotionTrackingOfAllControllers
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104429280
	// Return & Params: [ Num(0) Size(0x0) ]
	void DisableMotionTrackingOfAllControllers();

	// Object: Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.DisableMotionTrackingForComponent
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104429294
	// Return & Params: [ Num(1) Size(0x8) ]
	void DisableMotionTrackingForComponent(struct UMotionControllerComponent* MotionControllerComponent);
};

// Object: Class HeadMountedDisplay.VRNotificationsComponent
// Inherited Bytes: 0xb0 | Struct Size: 0x140
struct UVRNotificationsComponent : UActorComponent {
	// Fields
	struct FMulticastInlineDelegate HMDTrackingInitializingAndNeedsHMDToBeTrackedDelegate; // Offset: 0xb0 | Size: 0x10
	struct FMulticastInlineDelegate HMDTrackingInitializedDelegate; // Offset: 0xc0 | Size: 0x10
	struct FMulticastInlineDelegate HMDRecenteredDelegate; // Offset: 0xd0 | Size: 0x10
	struct FMulticastInlineDelegate HMDLostDelegate; // Offset: 0xe0 | Size: 0x10
	struct FMulticastInlineDelegate HMDReconnectedDelegate; // Offset: 0xf0 | Size: 0x10
	struct FMulticastInlineDelegate HMDConnectCanceledDelegate; // Offset: 0x100 | Size: 0x10
	struct FMulticastInlineDelegate HMDPutOnHeadDelegate; // Offset: 0x110 | Size: 0x10
	struct FMulticastInlineDelegate HMDRemovedFromHeadDelegate; // Offset: 0x120 | Size: 0x10
	struct FMulticastInlineDelegate VRControllerRecenteredDelegate; // Offset: 0x130 | Size: 0x10
};

// Object: Class HeadMountedDisplay.XRAssetFunctionLibrary
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UXRAssetFunctionLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object: Function HeadMountedDisplay.XRAssetFunctionLibrary.AddNamedDeviceVisualizationComponentBlocking
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10442a29c
	// Return & Params: [ Num(7) Size(0x68) ]
	struct UPrimitiveComponent* AddNamedDeviceVisualizationComponentBlocking(struct AActor* Target, struct FName SystemName, struct FName DeviceName, bool bManualAttachment, struct FTransform& RelativeTransform, struct FXRDeviceId& XRDeviceId);

	// Object: Function HeadMountedDisplay.XRAssetFunctionLibrary.AddDeviceVisualizationComponentBlocking
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10442a510
	// Return & Params: [ Num(5) Size(0x58) ]
	struct UPrimitiveComponent* AddDeviceVisualizationComponentBlocking(struct AActor* Target, struct FXRDeviceId& XRDeviceId, bool bManualAttachment, struct FTransform& RelativeTransform);
};

// Object: Class HeadMountedDisplay.AsyncTask_LoadXRDeviceVisComponent
// Inherited Bytes: 0x30 | Struct Size: 0x60
struct UAsyncTask_LoadXRDeviceVisComponent : UBlueprintAsyncActionBase {
	// Fields
	struct FMulticastInlineDelegate OnModelLoaded; // Offset: 0x30 | Size: 0x10
	struct FMulticastInlineDelegate OnLoadFailure; // Offset: 0x40 | Size: 0x10
	char pad_0x50[0x8]; // Offset: 0x50 | Size: 0x8
	struct UPrimitiveComponent* SpawnedComponent; // Offset: 0x58 | Size: 0x8

	// Functions

	// Object: Function HeadMountedDisplay.AsyncTask_LoadXRDeviceVisComponent.AddNamedDeviceVisualizationComponentAsync
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10442abb8
	// Return & Params: [ Num(8) Size(0x70) ]
	struct UAsyncTask_LoadXRDeviceVisComponent* AddNamedDeviceVisualizationComponentAsync(struct AActor* Target, struct FName SystemName, struct FName DeviceName, bool bManualAttachment, struct FTransform& RelativeTransform, struct FXRDeviceId& XRDeviceId, struct UPrimitiveComponent*& NewComponent);

	// Object: Function HeadMountedDisplay.AsyncTask_LoadXRDeviceVisComponent.AddDeviceVisualizationComponentAsync
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10442a974
	// Return & Params: [ Num(6) Size(0x60) ]
	struct UAsyncTask_LoadXRDeviceVisComponent* AddDeviceVisualizationComponentAsync(struct AActor* Target, struct FXRDeviceId& XRDeviceId, bool bManualAttachment, struct FTransform& RelativeTransform, struct UPrimitiveComponent*& NewComponent);
};

// Object: Class HeadMountedDisplay.XRLoadingScreenFunctionLibrary
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UXRLoadingScreenFunctionLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object: Function HeadMountedDisplay.XRLoadingScreenFunctionLibrary.ShowLoadingScreen
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10442b2a0
	// Return & Params: [ Num(0) Size(0x0) ]
	void ShowLoadingScreen();

	// Object: Function HeadMountedDisplay.XRLoadingScreenFunctionLibrary.SetLoadingScreen
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x10442b4b8
	// Return & Params: [ Num(5) Size(0x1e) ]
	void SetLoadingScreen(struct UTexture* Texture, struct FVector2D Scale, struct FVector Offset, bool bShowLoadingMovie, bool bShowOnSet);

	// Object: Function HeadMountedDisplay.XRLoadingScreenFunctionLibrary.HideLoadingScreen
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10442b28c
	// Return & Params: [ Num(0) Size(0x0) ]
	void HideLoadingScreen();

	// Object: Function HeadMountedDisplay.XRLoadingScreenFunctionLibrary.ClearLoadingScreenSplashes
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10442b4a4
	// Return & Params: [ Num(0) Size(0x0) ]
	void ClearLoadingScreenSplashes();

	// Object: Function HeadMountedDisplay.XRLoadingScreenFunctionLibrary.AddLoadingScreenSplash
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x10442b2b4
	// Return & Params: [ Num(6) Size(0x35) ]
	void AddLoadingScreenSplash(struct UTexture* Texture, struct FVector Translation, struct FRotator Rotation, struct FVector2D Size, struct FRotator DeltaRotation, bool bClearBeforeAdd);
};

