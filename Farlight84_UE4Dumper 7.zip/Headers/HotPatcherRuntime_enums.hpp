#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Enum HotPatcherRuntime.ETargetPlatform
enum class ETargetPlatform : uint8_t {
	None = 0,
	AllPlatforms = 1,
	ETargetPlatform_MAX = 2
};

// Object: Enum HotPatcherRuntime.EMatchOperator
enum class EMatchOperator : uint8_t {
	None = 0,
	GREAT_THAN = 1,
	LESS_THAN = 2,
	EQUAL = 3,
	EMatchOperator_MAX = 4
};

// Object: Enum HotPatcherRuntime.EMatchRule
enum class EMatchRule : uint8_t {
	None = 0,
	MATCH = 1,
	IGNORE = 2,
	EMatchRule_MAX = 3
};

// Object: Enum HotPatcherRuntime.EMonolithicPathMode
enum class EMonolithicPathMode : uint8_t {
	MountPath = 0,
	PackagePath = 1,
	EMonolithicPathMode_MAX = 2
};

// Object: Enum HotPatcherRuntime.EAssetRegistryRule
enum class EAssetRegistryRule : uint8_t {
	PATCH = 0,
	PER_CHUNK = 1,
	CUSTOM = 2,
	EAssetRegistryRule_MAX = 3
};

// Object: Enum HotPatcherRuntime.EShaderLibNameRule
enum class EShaderLibNameRule : uint8_t {
	VERSION_ID = 0,
	PROJECT_NAME = 1,
	CUSTOM = 2,
	EShaderLibNameRule_MAX = 3
};

// Object: Enum HotPatcherRuntime.EAssetRegistryDependencyTypeEx
enum class EAssetRegistryDependencyTypeEx : uint8_t {
	None = 0,
	Soft = 1,
	Hard = 2,
	SearchableName = 4,
	SoftManage = 8,
	HardManage = 16,
	Packages = 3,
	Manage = 24,
	All = 31,
	EAssetRegistryDependencyTypeEx_MAX = 32
};

// Object: Enum HotPatcherRuntime.EPSOSaveMode
enum class EPSOSaveMode : uint8_t {
	Incremental = 0,
	BoundPSOsOnly = 1,
	SortedBoundPSOs = 2,
	EPSOSaveMode_MAX = 3
};

// Object: Enum HotPatcherRuntime.ESearchCaseMode
enum class ESearchCaseMode : uint8_t {
	CaseSensitive = 0,
	IgnoreCase = 1,
	ESearchCaseMode_MAX = 2
};

