#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class ImageWriteQueue.ImageWriteBlueprintLibrary
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UImageWriteBlueprintLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object: Function ImageWriteQueue.ImageWriteBlueprintLibrary.ExportToDisk
	// Flags: [Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104175998
	// Return & Params: [ Num(3) Size(0x80) ]
	void ExportToDisk(struct UTexture* Texture, struct FString Filename, struct FImageWriteOptions& options);
};

