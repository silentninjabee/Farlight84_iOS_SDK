#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class ImgMedia.ImgMediaSource
// Inherited Bytes: 0x88 | Struct Size: 0xb0
struct UImgMediaSource : UBaseMediaSource {
	// Fields
	struct FFrameRate FrameRateOverride; // Offset: 0x88 | Size: 0x8
	struct FString ProxyOverride; // Offset: 0x90 | Size: 0x10
	struct FDirectoryPath SequencePath; // Offset: 0xa0 | Size: 0x10

	// Functions

	// Object: Function ImgMedia.ImgMediaSource.SetSequencePath
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102148098
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetSequencePath(struct FString Path);

	// Object: Function ImgMedia.ImgMediaSource.GetSequencePath
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102148124
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetSequencePath();

	// Object: Function ImgMedia.ImgMediaSource.GetProxies
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102148204
	// Return & Params: [ Num(1) Size(0x10) ]
	void GetProxies(struct TArray<struct FString>& OutProxies);
};

