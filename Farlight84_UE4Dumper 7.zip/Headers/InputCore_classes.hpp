#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class InputCore.InputCoreTypes
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UInputCoreTypes : UObject {
};

