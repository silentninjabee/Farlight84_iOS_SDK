#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct KawaiiPhysics.AnimNode_KawaiiPhysics
// Inherited Bytes: 0xc8 | Struct Size: 0x2f0
struct FAnimNode_KawaiiPhysics : FAnimNode_SkeletalControlBase {
	// Fields
	struct FBoneReference RootBone; // Offset: 0xc8 | Size: 0x10
	struct TArray<struct FBoneReference> ExcludeBones; // Offset: 0xd8 | Size: 0x10
	int32_t TargetFramerate; // Offset: 0xe8 | Size: 0x4
	bool OverrideTargetFramerate; // Offset: 0xec | Size: 0x1
	char pad_0xED[0x3]; // Offset: 0xed | Size: 0x3
	float MinCalculateDeltaTime; // Offset: 0xf0 | Size: 0x4
	bool OverrideMinCalculateDeltaTime; // Offset: 0xf4 | Size: 0x1
	bool bUseCalculatedTransform; // Offset: 0xf5 | Size: 0x1
	bool bUseIndependentPhysicsSetting; // Offset: 0xf6 | Size: 0x1
	char pad_0xF7[0x1]; // Offset: 0xf7 | Size: 0x1
	struct TMap<struct FName, struct FKawaiiBonePhysicsSettings> BoneIndependentPhysicsSettings; // Offset: 0xf8 | Size: 0x50
	struct FKawaiiPhysicsSettings PhysicsSettings; // Offset: 0x148 | Size: 0x18
	struct UCurveFloat* DampingCurve; // Offset: 0x160 | Size: 0x8
	struct UCurveFloat* WorldDampingLocationCurve; // Offset: 0x168 | Size: 0x8
	struct UCurveFloat* WorldDampingRotationCurve; // Offset: 0x170 | Size: 0x8
	struct UCurveFloat* StiffnessCurve; // Offset: 0x178 | Size: 0x8
	struct UCurveFloat* RadiusCurve; // Offset: 0x180 | Size: 0x8
	struct UCurveFloat* LimitAngleCurve; // Offset: 0x188 | Size: 0x8
	bool bUpdatePhysicsSettingsInGame; // Offset: 0x190 | Size: 0x1
	char pad_0x191[0x3]; // Offset: 0x191 | Size: 0x3
	float DummyBoneLength; // Offset: 0x194 | Size: 0x4
	enum class EBoneForwardAxis BoneForwardAxis; // Offset: 0x198 | Size: 0x1
	enum class EPlanarConstraint PlanarConstraint; // Offset: 0x199 | Size: 0x1
	char pad_0x19A[0x6]; // Offset: 0x19a | Size: 0x6
	struct TArray<struct FSphericalLimit> SphericalLimits; // Offset: 0x1a0 | Size: 0x10
	struct TArray<struct FCapsuleLimit> CapsuleLimits; // Offset: 0x1b0 | Size: 0x10
	struct TArray<struct FPlanarLimit> PlanarLimits; // Offset: 0x1c0 | Size: 0x10
	struct UKawaiiPhysicsLimitsDataAsset* LimitsDataAsset; // Offset: 0x1d0 | Size: 0x8
	struct TArray<struct FSphericalLimit> SphericalLimitsData; // Offset: 0x1d8 | Size: 0x10
	struct TArray<struct FCapsuleLimit> CapsuleLimitsData; // Offset: 0x1e8 | Size: 0x10
	struct TArray<struct FPlanarLimit> PlanarLimitsData; // Offset: 0x1f8 | Size: 0x10
	float TeleportDistanceThreshold; // Offset: 0x208 | Size: 0x4
	float TeleportRotationThreshold; // Offset: 0x20c | Size: 0x4
	struct FVector Gravity; // Offset: 0x210 | Size: 0xc
	bool bEnableWind; // Offset: 0x21c | Size: 0x1
	char pad_0x21D[0x3]; // Offset: 0x21d | Size: 0x3
	float WindScale; // Offset: 0x220 | Size: 0x4
	char pad_0x224[0x4]; // Offset: 0x224 | Size: 0x4
	struct TArray<struct FKawaiiPhysicsModifyBone> ModifyBones; // Offset: 0x228 | Size: 0x10
	float TotalBoneLength; // Offset: 0x238 | Size: 0x4
	char pad_0x23C[0x4]; // Offset: 0x23c | Size: 0x4
	struct FTransform PreSkelCompTransform; // Offset: 0x240 | Size: 0x30
	bool bInitPhysicsSettings; // Offset: 0x270 | Size: 0x1
	char pad_0x271[0x7f]; // Offset: 0x271 | Size: 0x7f
};

// Object: ScriptStruct KawaiiPhysics.KawaiiPhysicsModifyBone
// Inherited Bytes: 0x0 | Struct Size: 0xf0
struct FKawaiiPhysicsModifyBone {
	// Fields
	struct FBoneReference BoneRef; // Offset: 0x0 | Size: 0x10
	int32_t ParentIndex; // Offset: 0x10 | Size: 0x4
	char pad_0x14[0x4]; // Offset: 0x14 | Size: 0x4
	struct TArray<int32_t> ChildIndexs; // Offset: 0x18 | Size: 0x10
	struct FKawaiiPhysicsSettings PhysicsSettings; // Offset: 0x28 | Size: 0x18
	struct FVector Location; // Offset: 0x40 | Size: 0xc
	struct FVector PrevLocation; // Offset: 0x4c | Size: 0xc
	char pad_0x58[0x8]; // Offset: 0x58 | Size: 0x8
	struct FQuat PrevRotation; // Offset: 0x60 | Size: 0x10
	struct FVector PoseLocation; // Offset: 0x70 | Size: 0xc
	char pad_0x7C[0x4]; // Offset: 0x7c | Size: 0x4
	struct FQuat PoseRotation; // Offset: 0x80 | Size: 0x10
	struct FVector OriginPoseLocation; // Offset: 0x90 | Size: 0xc
	char pad_0x9C[0x4]; // Offset: 0x9c | Size: 0x4
	struct FQuat OriginPoseRotation; // Offset: 0xa0 | Size: 0x10
	struct FVector PoseScale; // Offset: 0xb0 | Size: 0xc
	float LengthFromRoot; // Offset: 0xbc | Size: 0x4
	bool bDummy; // Offset: 0xc0 | Size: 0x1
	char pad_0xC1[0x2f]; // Offset: 0xc1 | Size: 0x2f
};

// Object: ScriptStruct KawaiiPhysics.KawaiiPhysicsSettings
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FKawaiiPhysicsSettings {
	// Fields
	float Damping; // Offset: 0x0 | Size: 0x4
	float WorldDampingLocation; // Offset: 0x4 | Size: 0x4
	float WorldDampingRotation; // Offset: 0x8 | Size: 0x4
	float Stiffness; // Offset: 0xc | Size: 0x4
	float Radius; // Offset: 0x10 | Size: 0x4
	float LimitAngle; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct KawaiiPhysics.CollisionLimitBase
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FCollisionLimitBase {
	// Fields
	struct FBoneReference DrivingBone; // Offset: 0x0 | Size: 0x10
	struct FVector OffsetLocation; // Offset: 0x10 | Size: 0xc
	struct FRotator OffsetRotation; // Offset: 0x1c | Size: 0xc
	struct FVector Location; // Offset: 0x28 | Size: 0xc
	char pad_0x34[0xc]; // Offset: 0x34 | Size: 0xc
	struct FQuat Rotation; // Offset: 0x40 | Size: 0x10
};

// Object: ScriptStruct KawaiiPhysics.PlanarLimit
// Inherited Bytes: 0x50 | Struct Size: 0x60
struct FPlanarLimit : FCollisionLimitBase {
	// Fields
	struct FPlane Plane; // Offset: 0x50 | Size: 0x10
};

// Object: ScriptStruct KawaiiPhysics.CapsuleLimit
// Inherited Bytes: 0x50 | Struct Size: 0x60
struct FCapsuleLimit : FCollisionLimitBase {
	// Fields
	float Radius; // Offset: 0x50 | Size: 0x4
	float Length; // Offset: 0x54 | Size: 0x4
	char pad_0x58[0x8]; // Offset: 0x58 | Size: 0x8
};

// Object: ScriptStruct KawaiiPhysics.SphericalLimit
// Inherited Bytes: 0x50 | Struct Size: 0x60
struct FSphericalLimit : FCollisionLimitBase {
	// Fields
	float Radius; // Offset: 0x50 | Size: 0x4
	enum class ESphericalLimitType LimitType; // Offset: 0x54 | Size: 0x1
	char pad_0x55[0xb]; // Offset: 0x55 | Size: 0xb
};

// Object: ScriptStruct KawaiiPhysics.KawaiiBonePhysicsSettings
// Inherited Bytes: 0x0 | Struct Size: 0x1c
struct FKawaiiBonePhysicsSettings {
	// Fields
	struct FKawaiiPhysicsSettings PhysicsSetting; // Offset: 0x0 | Size: 0x18
	bool OverridePhysicsSetting; // Offset: 0x18 | Size: 0x1
	char pad_0x19[0x3]; // Offset: 0x19 | Size: 0x3
};

// Object: ScriptStruct KawaiiPhysics.CollisionLimitDataBase
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FCollisionLimitDataBase {
	// Fields
	struct FName DrivingBoneName; // Offset: 0x0 | Size: 0x8
	struct FVector OffsetLocation; // Offset: 0x8 | Size: 0xc
	struct FRotator OffsetRotation; // Offset: 0x14 | Size: 0xc
	struct FVector Location; // Offset: 0x20 | Size: 0xc
	char pad_0x2C[0x4]; // Offset: 0x2c | Size: 0x4
	struct FQuat Rotation; // Offset: 0x30 | Size: 0x10
	struct FGuid Guid; // Offset: 0x40 | Size: 0x10
};

// Object: ScriptStruct KawaiiPhysics.PlanarLimitData
// Inherited Bytes: 0x50 | Struct Size: 0x60
struct FPlanarLimitData : FCollisionLimitDataBase {
	// Fields
	struct FPlane Plane; // Offset: 0x50 | Size: 0x10
};

// Object: ScriptStruct KawaiiPhysics.CapsuleLimitData
// Inherited Bytes: 0x50 | Struct Size: 0x60
struct FCapsuleLimitData : FCollisionLimitDataBase {
	// Fields
	float Radius; // Offset: 0x50 | Size: 0x4
	float Length; // Offset: 0x54 | Size: 0x4
	char pad_0x58[0x8]; // Offset: 0x58 | Size: 0x8
};

// Object: ScriptStruct KawaiiPhysics.SphericalLimitData
// Inherited Bytes: 0x50 | Struct Size: 0x60
struct FSphericalLimitData : FCollisionLimitDataBase {
	// Fields
	float Radius; // Offset: 0x50 | Size: 0x4
	enum class ESphericalLimitType LimitType; // Offset: 0x54 | Size: 0x1
	char pad_0x55[0xb]; // Offset: 0x55 | Size: 0xb
};

