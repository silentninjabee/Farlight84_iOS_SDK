#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Enum Landmass.EBrushFalloffMode
enum class EBrushFalloffMode : uint8_t {
	Angle = 0,
	Width = 1,
	EBrushFalloffMode_MAX = 2
};

// Object: Enum Landmass.EBrushBlendType
enum class EBrushBlendType : uint8_t {
	AlphaBlend = 0,
	Min = 1,
	Max = 2,
	Additive = 3
};

