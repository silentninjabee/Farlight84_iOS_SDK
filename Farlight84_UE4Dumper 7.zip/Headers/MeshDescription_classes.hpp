#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class MeshDescription.MeshDescription
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UMeshDescription : UObject {
};

// Object: Class MeshDescription.MeshDescriptionBase
// Inherited Bytes: 0x28 | Struct Size: 0x390
struct UMeshDescriptionBase : UObject {
	// Fields
	char pad_0x28[0x368]; // Offset: 0x28 | Size: 0x368

	// Functions

	// Object: Function MeshDescription.MeshDescriptionBase.SetVertexPosition
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x104e03c40
	// Return & Params: [ Num(2) Size(0x10) ]
	void SetVertexPosition(struct FVertexID VertexID, struct FVector& Position);

	// Object: Function MeshDescription.MeshDescriptionBase.SetPolygonVertexInstance
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104e01f8c
	// Return & Params: [ Num(3) Size(0xc) ]
	void SetPolygonVertexInstance(struct FPolygonID PolygonID, int32_t PerimeterIndex, struct FVertexInstanceID VertexInstanceID);

	// Object: Function MeshDescription.MeshDescriptionBase.SetPolygonPolygonGroup
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104e01ea4
	// Return & Params: [ Num(2) Size(0x8) ]
	void SetPolygonPolygonGroup(struct FPolygonID PolygonID, struct FPolygonGroupID PolygonGroupID);

	// Object: Function MeshDescription.MeshDescriptionBase.ReversePolygonFacing
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104e01e18
	// Return & Params: [ Num(1) Size(0x4) ]
	void ReversePolygonFacing(struct FPolygonID PolygonID);

	// Object: Function MeshDescription.MeshDescriptionBase.ReserveNewVertices
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104e05e20
	// Return & Params: [ Num(1) Size(0x4) ]
	void ReserveNewVertices(int32_t NumberOfNewVertices);

	// Object: Function MeshDescription.MeshDescriptionBase.ReserveNewVertexInstances
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104e05bb8
	// Return & Params: [ Num(1) Size(0x4) ]
	void ReserveNewVertexInstances(int32_t NumberOfNewVertexInstances);

	// Object: Function MeshDescription.MeshDescriptionBase.ReserveNewTriangles
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104e053f0
	// Return & Params: [ Num(1) Size(0x4) ]
	void ReserveNewTriangles(int32_t NumberOfNewTriangles);

	// Object: Function MeshDescription.MeshDescriptionBase.ReserveNewPolygons
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104e04e20
	// Return & Params: [ Num(1) Size(0x4) ]
	void ReserveNewPolygons(int32_t NumberOfNewPolygons);

	// Object: Function MeshDescription.MeshDescriptionBase.ReserveNewPolygonGroups
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104e04850
	// Return & Params: [ Num(1) Size(0x4) ]
	void ReserveNewPolygonGroups(int32_t NumberOfNewPolygonGroups);

	// Object: Function MeshDescription.MeshDescriptionBase.ReserveNewEdges
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104e05828
	// Return & Params: [ Num(1) Size(0x4) ]
	void ReserveNewEdges(int32_t NumberOfNewEdges);

	// Object: Function MeshDescription.MeshDescriptionBase.IsVertexValid
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104e05c38
	// Return & Params: [ Num(2) Size(0x5) ]
	bool IsVertexValid(struct FVertexID VertexID);

	// Object: Function MeshDescription.MeshDescriptionBase.IsVertexOrphaned
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104e045cc
	// Return & Params: [ Num(2) Size(0x5) ]
	bool IsVertexOrphaned(struct FVertexID VertexID);

	// Object: Function MeshDescription.MeshDescriptionBase.IsVertexInstanceValid
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104e058a8
	// Return & Params: [ Num(2) Size(0x5) ]
	bool IsVertexInstanceValid(struct FVertexInstanceID VertexInstanceID);

	// Object: Function MeshDescription.MeshDescriptionBase.IsTriangleValid
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104e04ea0
	// Return & Params: [ Num(2) Size(0x5) ]
	bool IsTriangleValid(struct FTriangleID TriangleID);

	// Object: Function MeshDescription.MeshDescriptionBase.IsTrianglePartOfNgon
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104e02f50
	// Return & Params: [ Num(2) Size(0x5) ]
	bool IsTrianglePartOfNgon(struct FTriangleID TriangleID);

	// Object: Function MeshDescription.MeshDescriptionBase.IsPolygonValid
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104e048d0
	// Return & Params: [ Num(2) Size(0x5) ]
	bool IsPolygonValid(struct FPolygonID PolygonID);

	// Object: Function MeshDescription.MeshDescriptionBase.IsPolygonGroupValid
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104e04668
	// Return & Params: [ Num(2) Size(0x5) ]
	bool IsPolygonGroupValid(struct FPolygonGroupID PolygonGroupID);

	// Object: Function MeshDescription.MeshDescriptionBase.IsEmpty
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104e05ea0
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsEmpty();

	// Object: Function MeshDescription.MeshDescriptionBase.IsEdgeValid
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104e05470
	// Return & Params: [ Num(2) Size(0x5) ]
	bool IsEdgeValid(struct FEdgeID EdgeID);

	// Object: Function MeshDescription.MeshDescriptionBase.IsEdgeInternalToPolygon
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104e03610
	// Return & Params: [ Num(3) Size(0x9) ]
	bool IsEdgeInternalToPolygon(struct FEdgeID EdgeID, struct FPolygonID PolygonID);

	// Object: Function MeshDescription.MeshDescriptionBase.IsEdgeInternal
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104e03700
	// Return & Params: [ Num(2) Size(0x5) ]
	bool IsEdgeInternal(struct FEdgeID EdgeID);

	// Object: Function MeshDescription.MeshDescriptionBase.GetVertexVertexInstances
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104e04260
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetVertexVertexInstances(struct FVertexID VertexID, struct TArray<struct FVertexInstanceID>& OutVertexInstanceIDs);

	// Object: Function MeshDescription.MeshDescriptionBase.GetVertexPosition
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104e03d1c
	// Return & Params: [ Num(2) Size(0x10) ]
	struct FVector GetVertexPosition(struct FVertexID VertexID);

	// Object: Function MeshDescription.MeshDescriptionBase.GetVertexPairEdge
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104e044dc
	// Return & Params: [ Num(3) Size(0xc) ]
	struct FEdgeID GetVertexPairEdge(struct FVertexID VertexID0, struct FVertexID VertexID1);

	// Object: Function MeshDescription.MeshDescriptionBase.GetVertexInstanceVertex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104e03ba4
	// Return & Params: [ Num(2) Size(0x8) ]
	struct FVertexID GetVertexInstanceVertex(struct FVertexInstanceID VertexInstanceID);

	// Object: Function MeshDescription.MeshDescriptionBase.GetVertexInstancePairEdge
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104e03ab4
	// Return & Params: [ Num(3) Size(0xc) ]
	struct FEdgeID GetVertexInstancePairEdge(struct FVertexInstanceID VertexInstanceID0, struct FVertexInstanceID VertexInstanceID1);

	// Object: Function MeshDescription.MeshDescriptionBase.GetVertexInstanceForTriangleVertex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104e029bc
	// Return & Params: [ Num(3) Size(0xc) ]
	struct FVertexInstanceID GetVertexInstanceForTriangleVertex(struct FTriangleID TriangleID, struct FVertexID VertexID);

	// Object: Function MeshDescription.MeshDescriptionBase.GetVertexInstanceForPolygonVertex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104e020bc
	// Return & Params: [ Num(3) Size(0xc) ]
	struct FVertexInstanceID GetVertexInstanceForPolygonVertex(struct FPolygonID PolygonID, struct FVertexID VertexID);

	// Object: Function MeshDescription.MeshDescriptionBase.GetVertexInstanceConnectedTriangles
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104e039c4
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetVertexInstanceConnectedTriangles(struct FVertexInstanceID VertexInstanceID, struct TArray<struct FTriangleID>& OutConnectedTriangleIDs);

	// Object: Function MeshDescription.MeshDescriptionBase.GetVertexInstanceConnectedPolygons
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104e03838
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetVertexInstanceConnectedPolygons(struct FVertexInstanceID VertexInstanceID, struct TArray<struct FPolygonID>& OutConnectedPolygonIDs);

	// Object: Function MeshDescription.MeshDescriptionBase.GetVertexConnectedTriangles
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104e040d4
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetVertexConnectedTriangles(struct FVertexID VertexID, struct TArray<struct FTriangleID>& OutConnectedTriangleIDs);

	// Object: Function MeshDescription.MeshDescriptionBase.GetVertexConnectedPolygons
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104e03f48
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetVertexConnectedPolygons(struct FVertexID VertexID, struct TArray<struct FPolygonID>& OutConnectedPolygonIDs);

	// Object: Function MeshDescription.MeshDescriptionBase.GetVertexConnectedEdges
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104e043ec
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetVertexConnectedEdges(struct FVertexID VertexID, struct TArray<struct FEdgeID>& OutEdgeIDs);

	// Object: Function MeshDescription.MeshDescriptionBase.GetVertexAdjacentVertices
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104e03dbc
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetVertexAdjacentVertices(struct FVertexID VertexID, struct TArray<struct FVertexID>& OutAdjacentVertexIDs);

	// Object: Function MeshDescription.MeshDescriptionBase.GetTriangleVertices
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104e02c8c
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetTriangleVertices(struct FTriangleID TriangleID, struct TArray<struct FVertexID>& OutVertexIDs);

	// Object: Function MeshDescription.MeshDescriptionBase.GetTriangleVertexInstances
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104e02e60
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetTriangleVertexInstances(struct FTriangleID TriangleID, struct TArray<struct FVertexInstanceID>& OutVertexInstanceIDs);

	// Object: Function MeshDescription.MeshDescriptionBase.GetTriangleVertexInstance
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104e02d7c
	// Return & Params: [ Num(3) Size(0xc) ]
	struct FVertexInstanceID GetTriangleVertexInstance(struct FTriangleID TriangleID, int32_t Index);

	// Object: Function MeshDescription.MeshDescriptionBase.GetTrianglePolygonGroup
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104e02fec
	// Return & Params: [ Num(2) Size(0x8) ]
	struct FPolygonGroupID GetTrianglePolygonGroup(struct FTriangleID TriangleID);

	// Object: Function MeshDescription.MeshDescriptionBase.GetTrianglePolygon
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104e03088
	// Return & Params: [ Num(2) Size(0x8) ]
	struct FPolygonID GetTrianglePolygon(struct FTriangleID TriangleID);

	// Object: Function MeshDescription.MeshDescriptionBase.GetTriangleEdges
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104e02b9c
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetTriangleEdges(struct FTriangleID TriangleID, struct TArray<struct FEdgeID>& OutEdgeIDs);

	// Object: Function MeshDescription.MeshDescriptionBase.GetTriangleAdjacentTriangles
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104e02aac
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetTriangleAdjacentTriangles(struct FTriangleID TriangleID, struct TArray<struct FTriangleID>& OutTriangleIDs);

	// Object: Function MeshDescription.MeshDescriptionBase.GetPolygonVertices
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104e025b4
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetPolygonVertices(struct FPolygonID PolygonID, struct TArray<struct FVertexID>& OutVertexIDs);

	// Object: Function MeshDescription.MeshDescriptionBase.GetPolygonVertexInstances
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104e02740
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetPolygonVertexInstances(struct FPolygonID PolygonID, struct TArray<struct FVertexInstanceID>& OutVertexInstanceIDs);

	// Object: Function MeshDescription.MeshDescriptionBase.GetPolygonTriangles
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104e028cc
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetPolygonTriangles(struct FPolygonID PolygonID, struct TArray<struct FTriangleID>& OutTriangleIDs);

	// Object: Function MeshDescription.MeshDescriptionBase.GetPolygonPolygonGroup
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104e021ac
	// Return & Params: [ Num(2) Size(0x8) ]
	struct FPolygonGroupID GetPolygonPolygonGroup(struct FPolygonID PolygonID);

	// Object: Function MeshDescription.MeshDescriptionBase.GetPolygonPerimeterEdges
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104e024c4
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetPolygonPerimeterEdges(struct FPolygonID PolygonID, struct TArray<struct FEdgeID>& OutEdgeIDs);

	// Object: Function MeshDescription.MeshDescriptionBase.GetPolygonInternalEdges
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104e023d4
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetPolygonInternalEdges(struct FPolygonID PolygonID, struct TArray<struct FEdgeID>& OutEdgeIDs);

	// Object: Function MeshDescription.MeshDescriptionBase.GetPolygonGroupPolygons
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104e01c9c
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetPolygonGroupPolygons(struct FPolygonGroupID PolygonGroupID, struct TArray<struct FPolygonID>& OutPolygonIDs);

	// Object: Function MeshDescription.MeshDescriptionBase.GetPolygonAdjacentPolygons
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104e02248
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetPolygonAdjacentPolygons(struct FPolygonID PolygonID, struct TArray<struct FPolygonID>& OutPolygonIDs);

	// Object: Function MeshDescription.MeshDescriptionBase.GetNumVertexVertexInstances
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104e041c4
	// Return & Params: [ Num(2) Size(0x8) ]
	int32_t GetNumVertexVertexInstances(struct FVertexID VertexID);

	// Object: Function MeshDescription.MeshDescriptionBase.GetNumVertexInstanceConnectedTriangles
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104e03928
	// Return & Params: [ Num(2) Size(0x8) ]
	int32_t GetNumVertexInstanceConnectedTriangles(struct FVertexInstanceID VertexInstanceID);

	// Object: Function MeshDescription.MeshDescriptionBase.GetNumVertexInstanceConnectedPolygons
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104e0379c
	// Return & Params: [ Num(2) Size(0x8) ]
	int32_t GetNumVertexInstanceConnectedPolygons(struct FVertexInstanceID VertexInstanceID);

	// Object: Function MeshDescription.MeshDescriptionBase.GetNumVertexConnectedTriangles
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104e04038
	// Return & Params: [ Num(2) Size(0x8) ]
	int32_t GetNumVertexConnectedTriangles(struct FVertexID VertexID);

	// Object: Function MeshDescription.MeshDescriptionBase.GetNumVertexConnectedPolygons
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104e03eac
	// Return & Params: [ Num(2) Size(0x8) ]
	int32_t GetNumVertexConnectedPolygons(struct FVertexID VertexID);

	// Object: Function MeshDescription.MeshDescriptionBase.GetNumVertexConnectedEdges
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104e04350
	// Return & Params: [ Num(2) Size(0x8) ]
	int32_t GetNumVertexConnectedEdges(struct FVertexID VertexID);

	// Object: Function MeshDescription.MeshDescriptionBase.GetNumPolygonVertices
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104e026a4
	// Return & Params: [ Num(2) Size(0x8) ]
	int32_t GetNumPolygonVertices(struct FPolygonID PolygonID);

	// Object: Function MeshDescription.MeshDescriptionBase.GetNumPolygonTriangles
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104e02830
	// Return & Params: [ Num(2) Size(0x8) ]
	int32_t GetNumPolygonTriangles(struct FPolygonID PolygonID);

	// Object: Function MeshDescription.MeshDescriptionBase.GetNumPolygonInternalEdges
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104e02338
	// Return & Params: [ Num(2) Size(0x8) ]
	int32_t GetNumPolygonInternalEdges(struct FPolygonID PolygonID);

	// Object: Function MeshDescription.MeshDescriptionBase.GetNumPolygonGroupPolygons
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104e01c00
	// Return & Params: [ Num(2) Size(0x8) ]
	int32_t GetNumPolygonGroupPolygons(struct FPolygonGroupID PolygonGroupID);

	// Object: Function MeshDescription.MeshDescriptionBase.GetNumEdgeConnectedTriangles
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104e03484
	// Return & Params: [ Num(2) Size(0x8) ]
	int32_t GetNumEdgeConnectedTriangles(struct FEdgeID EdgeID);

	// Object: Function MeshDescription.MeshDescriptionBase.GetNumEdgeConnectedPolygons
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104e032f8
	// Return & Params: [ Num(2) Size(0x8) ]
	int32_t GetNumEdgeConnectedPolygons(struct FEdgeID EdgeID);

	// Object: Function MeshDescription.MeshDescriptionBase.GetEdgeVertices
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104e03124
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetEdgeVertices(struct FEdgeID EdgeID, struct TArray<struct FVertexID>& OutVertexIDs);

	// Object: Function MeshDescription.MeshDescriptionBase.GetEdgeVertex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104e03214
	// Return & Params: [ Num(3) Size(0xc) ]
	struct FVertexID GetEdgeVertex(struct FEdgeID EdgeID, int32_t VertexNumber);

	// Object: Function MeshDescription.MeshDescriptionBase.GetEdgeConnectedTriangles
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104e03520
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetEdgeConnectedTriangles(struct FEdgeID EdgeID, struct TArray<struct FTriangleID>& OutConnectedTriangleIDs);

	// Object: Function MeshDescription.MeshDescriptionBase.GetEdgeConnectedPolygons
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104e03394
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetEdgeConnectedPolygons(struct FEdgeID EdgeID, struct TArray<struct FPolygonID>& OutConnectedPolygonIDs);

	// Object: Function MeshDescription.MeshDescriptionBase.Empty
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104e05ed4
	// Return & Params: [ Num(0) Size(0x0) ]
	void Empty();

	// Object: Function MeshDescription.MeshDescriptionBase.DeleteVertexInstance
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104e05944
	// Return & Params: [ Num(2) Size(0x18) ]
	void DeleteVertexInstance(struct FVertexInstanceID VertexInstanceID, struct TArray<struct FVertexID>& OrphanedVertices);

	// Object: Function MeshDescription.MeshDescriptionBase.DeleteVertex
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104e05cd4
	// Return & Params: [ Num(1) Size(0x4) ]
	void DeleteVertex(struct FVertexID VertexID);

	// Object: Function MeshDescription.MeshDescriptionBase.DeleteTriangle
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104e04f3c
	// Return & Params: [ Num(4) Size(0x38) ]
	void DeleteTriangle(struct FTriangleID TriangleID, struct TArray<struct FEdgeID>& OrphanedEdges, struct TArray<struct FVertexInstanceID>& OrphanedVertexInstances, struct TArray<struct FPolygonGroupID>& OrphanedPolygonGroupsPtr);

	// Object: Function MeshDescription.MeshDescriptionBase.DeletePolygonGroup
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104e04704
	// Return & Params: [ Num(1) Size(0x4) ]
	void DeletePolygonGroup(struct FPolygonGroupID PolygonGroupID);

	// Object: Function MeshDescription.MeshDescriptionBase.DeletePolygon
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104e0496c
	// Return & Params: [ Num(4) Size(0x38) ]
	void DeletePolygon(struct FPolygonID PolygonID, struct TArray<struct FEdgeID>& OrphanedEdges, struct TArray<struct FVertexInstanceID>& OrphanedVertexInstances, struct TArray<struct FPolygonGroupID>& OrphanedPolygonGroups);

	// Object: Function MeshDescription.MeshDescriptionBase.DeleteEdge
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104e0550c
	// Return & Params: [ Num(2) Size(0x18) ]
	void DeleteEdge(struct FEdgeID EdgeID, struct TArray<struct FVertexID>& OrphanedVertices);

	// Object: Function MeshDescription.MeshDescriptionBase.CreateVertexWithID
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104e05d60
	// Return & Params: [ Num(1) Size(0x4) ]
	void CreateVertexWithID(struct FVertexID VertexID);

	// Object: Function MeshDescription.MeshDescriptionBase.CreateVertexInstanceWithID
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104e05a34
	// Return & Params: [ Num(2) Size(0x8) ]
	void CreateVertexInstanceWithID(struct FVertexInstanceID VertexInstanceID, struct FVertexID VertexID);

	// Object: Function MeshDescription.MeshDescriptionBase.CreateVertexInstance
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104e05b1c
	// Return & Params: [ Num(2) Size(0x8) ]
	struct FVertexInstanceID CreateVertexInstance(struct FVertexID VertexID);

	// Object: Function MeshDescription.MeshDescriptionBase.CreateVertex
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104e05dec
	// Return & Params: [ Num(1) Size(0x4) ]
	struct FVertexID CreateVertex();

	// Object: Function MeshDescription.MeshDescriptionBase.CreateTriangleWithID
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104e050ec
	// Return & Params: [ Num(4) Size(0x28) ]
	void CreateTriangleWithID(struct FTriangleID TriangleID, struct FPolygonGroupID PolygonGroupID, struct TArray<struct FVertexInstanceID>& VertexInstanceIDs, struct TArray<struct FEdgeID>& NewEdgeIDs);

	// Object: Function MeshDescription.MeshDescriptionBase.CreateTriangle
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104e05294
	// Return & Params: [ Num(4) Size(0x2c) ]
	struct FTriangleID CreateTriangle(struct FPolygonGroupID PolygonGroupID, struct TArray<struct FVertexInstanceID>& VertexInstanceIDs, struct TArray<struct FEdgeID>& NewEdgeIDs);

	// Object: Function MeshDescription.MeshDescriptionBase.CreatePolygonWithID
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104e04b1c
	// Return & Params: [ Num(4) Size(0x28) ]
	void CreatePolygonWithID(struct FPolygonID PolygonID, struct FPolygonGroupID PolygonGroupID, struct TArray<struct FVertexInstanceID>& VertexInstanceIDs, struct TArray<struct FEdgeID>& NewEdgeIDs);

	// Object: Function MeshDescription.MeshDescriptionBase.CreatePolygonGroupWithID
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104e04790
	// Return & Params: [ Num(1) Size(0x4) ]
	void CreatePolygonGroupWithID(struct FPolygonGroupID PolygonGroupID);

	// Object: Function MeshDescription.MeshDescriptionBase.CreatePolygonGroup
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104e0481c
	// Return & Params: [ Num(1) Size(0x4) ]
	struct FPolygonGroupID CreatePolygonGroup();

	// Object: Function MeshDescription.MeshDescriptionBase.CreatePolygon
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104e04cc4
	// Return & Params: [ Num(4) Size(0x2c) ]
	struct FPolygonID CreatePolygon(struct FPolygonGroupID PolygonGroupID, struct TArray<struct FVertexInstanceID>& VertexInstanceIDs, struct TArray<struct FEdgeID>& NewEdgeIDs);

	// Object: Function MeshDescription.MeshDescriptionBase.CreateEdgeWithID
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104e055fc
	// Return & Params: [ Num(3) Size(0xc) ]
	void CreateEdgeWithID(struct FEdgeID EdgeID, struct FVertexID VertexID0, struct FVertexID VertexID1);

	// Object: Function MeshDescription.MeshDescriptionBase.CreateEdge
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104e05738
	// Return & Params: [ Num(3) Size(0xc) ]
	struct FEdgeID CreateEdge(struct FVertexID VertexID0, struct FVertexID VertexID1);

	// Object: Function MeshDescription.MeshDescriptionBase.ComputePolygonTriangulation
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104e01d8c
	// Return & Params: [ Num(1) Size(0x4) ]
	void ComputePolygonTriangulation(struct FPolygonID PolygonID);
};

