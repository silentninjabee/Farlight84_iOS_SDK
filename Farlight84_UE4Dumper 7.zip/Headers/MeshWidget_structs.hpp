#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct MeshWidget.UIMeshInstanceData
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FUIMeshInstanceData {
	// Fields
	struct FVector4 InstanceData1; // Offset: 0x0 | Size: 0x10
	struct FVector4 InstanceData2; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct MeshWidget.MeshVertex
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FMeshVertex {
	// Fields
	struct FVector Position; // Offset: 0x0 | Size: 0xc
	struct FColor Color; // Offset: 0xc | Size: 0x4
	struct FVector2D UV0; // Offset: 0x10 | Size: 0x8
	struct FVector2D UV1; // Offset: 0x18 | Size: 0x8
};

// Object: ScriptStruct MeshWidget.UIMeshCameraInfo
// Inherited Bytes: 0x0 | Struct Size: 0x1c
struct FUIMeshCameraInfo {
	// Fields
	enum class EUIMeshTransform TransformType; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	float HalfFov; // Offset: 0x4 | Size: 0x4
	float NearClip; // Offset: 0x8 | Size: 0x4
	struct FVector CameraRotate; // Offset: 0xc | Size: 0xc
	bool bDirty; // Offset: 0x18 | Size: 0x1
	char pad_0x19[0x3]; // Offset: 0x19 | Size: 0x3
};

// Object: ScriptStruct MeshWidget.UIMeshTransformInfo
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FUIMeshTransformInfo {
	// Fields
	struct FVector MeshScale; // Offset: 0x0 | Size: 0xc
	struct FVector MeshTranslate; // Offset: 0xc | Size: 0xc
	struct FVector MeshRotate; // Offset: 0x18 | Size: 0xc
	bool bDirty; // Offset: 0x24 | Size: 0x1
	char pad_0x25[0x3]; // Offset: 0x25 | Size: 0x3
};

