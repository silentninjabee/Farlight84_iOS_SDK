#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct MotionWarping.MotionWarpingWindowData
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FMotionWarpingWindowData {
	// Fields
	struct UAnimNotifyState_MotionWarping* AnimNotify; // Offset: 0x0 | Size: 0x8
	float StartTime; // Offset: 0x8 | Size: 0x4
	float EndTime; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct MotionWarping.MotionWarpingTarget
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FMotionWarpingTarget {
	// Fields
	struct FTransform Transform; // Offset: 0x0 | Size: 0x30
	struct TWeakObjectPtr<struct USceneComponent> Component; // Offset: 0x30 | Size: 0x8
	struct FName BoneName; // Offset: 0x38 | Size: 0x8
	bool bFollowComponent; // Offset: 0x40 | Size: 0x1
	char pad_0x41[0xf]; // Offset: 0x41 | Size: 0xf
};

// Object: ScriptStruct MotionWarping.MotionDeltaTrackContainer
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FMotionDeltaTrackContainer {
	// Fields
	struct TArray<struct FMotionDeltaTrack> Tracks; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct MotionWarping.MotionDeltaTrack
// Inherited Bytes: 0x0 | Struct Size: 0x48
struct FMotionDeltaTrack {
	// Fields
	struct TArray<struct FTransform> BoneTransformTrack; // Offset: 0x0 | Size: 0x10
	struct TArray<struct FVector> DeltaTranslationTrack; // Offset: 0x10 | Size: 0x10
	struct TArray<struct FRotator> DeltaRotationTrack; // Offset: 0x20 | Size: 0x10
	struct FVector TotalTranslation; // Offset: 0x30 | Size: 0xc
	struct FRotator TotalRotation; // Offset: 0x3c | Size: 0xc
};

