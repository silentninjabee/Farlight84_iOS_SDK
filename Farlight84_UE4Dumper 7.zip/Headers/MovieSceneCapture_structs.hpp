#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct MovieSceneCapture.CompositionGraphCapturePasses
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FCompositionGraphCapturePasses {
	// Fields
	struct TArray<struct FString> Value; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct MovieSceneCapture.FrameMetrics
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FFrameMetrics {
	// Fields
	float TotalElapsedTime; // Offset: 0x0 | Size: 0x4
	float FrameDelta; // Offset: 0x4 | Size: 0x4
	int32_t FrameNumber; // Offset: 0x8 | Size: 0x4
	int32_t NumDroppedFrames; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct MovieSceneCapture.MovieSceneCaptureSettings
// Inherited Bytes: 0x0 | Struct Size: 0x70
struct FMovieSceneCaptureSettings {
	// Fields
	struct FDirectoryPath OutputDirectory; // Offset: 0x0 | Size: 0x10
	struct AGameModeBase* GameModeOverride; // Offset: 0x10 | Size: 0x8
	struct FString OutputFormat; // Offset: 0x18 | Size: 0x10
	bool bOverwriteExisting; // Offset: 0x28 | Size: 0x1
	bool bUseRelativeFrameNumbers; // Offset: 0x29 | Size: 0x1
	char pad_0x2A[0x2]; // Offset: 0x2a | Size: 0x2
	int32_t HandleFrames; // Offset: 0x2c | Size: 0x4
	struct FString MovieExtension; // Offset: 0x30 | Size: 0x10
	char ZeroPadFrameNumbers; // Offset: 0x40 | Size: 0x1
	char pad_0x41[0x3]; // Offset: 0x41 | Size: 0x3
	struct FFrameRate FrameRate; // Offset: 0x44 | Size: 0x8
	bool bUseCustomFrameRate; // Offset: 0x4c | Size: 0x1
	char pad_0x4D[0x3]; // Offset: 0x4d | Size: 0x3
	struct FFrameRate CustomFrameRate; // Offset: 0x50 | Size: 0x8
	struct FCaptureResolution Resolution; // Offset: 0x58 | Size: 0x8
	bool bEnableTextureStreaming; // Offset: 0x60 | Size: 0x1
	bool bCinematicEngineScalability; // Offset: 0x61 | Size: 0x1
	bool bCinematicMode; // Offset: 0x62 | Size: 0x1
	bool bAllowMovement; // Offset: 0x63 | Size: 0x1
	bool bAllowTurning; // Offset: 0x64 | Size: 0x1
	bool bShowPlayer; // Offset: 0x65 | Size: 0x1
	bool bShowHUD; // Offset: 0x66 | Size: 0x1
	bool bUsePathTracer; // Offset: 0x67 | Size: 0x1
	int32_t PathTracerSamplePerPixel; // Offset: 0x68 | Size: 0x4
	char pad_0x6C[0x4]; // Offset: 0x6c | Size: 0x4
};

// Object: ScriptStruct MovieSceneCapture.CaptureResolution
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FCaptureResolution {
	// Fields
	int32_t ResX; // Offset: 0x0 | Size: 0x4
	int32_t ResY; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct MovieSceneCapture.CapturedPixels
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FCapturedPixels {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct MovieSceneCapture.CapturedPixelsID
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FCapturedPixelsID {
	// Fields
	struct TMap<struct FName, struct FName> Identifiers; // Offset: 0x0 | Size: 0x50
};

