#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct Overlay.OverlayItem
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FOverlayItem {
	// Fields
	struct FTimespan StartTime; // Offset: 0x0 | Size: 0x8
	struct FTimespan EndTime; // Offset: 0x8 | Size: 0x8
	struct FString Text; // Offset: 0x10 | Size: 0x10
	struct FVector2D Position; // Offset: 0x20 | Size: 0x8
};

