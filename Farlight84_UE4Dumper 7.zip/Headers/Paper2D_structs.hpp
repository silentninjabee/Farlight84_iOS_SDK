#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct Paper2D.IntMargin
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FIntMargin {
	// Fields
	int32_t Left; // Offset: 0x0 | Size: 0x4
	int32_t Top; // Offset: 0x4 | Size: 0x4
	int32_t Right; // Offset: 0x8 | Size: 0x4
	int32_t Bottom; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct Paper2D.PaperFlipbookKeyFrame
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FPaperFlipbookKeyFrame {
	// Fields
	struct UPaperSprite* Sprite; // Offset: 0x0 | Size: 0x8
	int32_t FrameRun; // Offset: 0x8 | Size: 0x4
	char pad_0xC[0x4]; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct Paper2D.SpriteInstanceData
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FSpriteInstanceData {
	// Fields
	struct FMatrix Transform; // Offset: 0x0 | Size: 0x40
	struct UPaperSprite* SourceSprite; // Offset: 0x40 | Size: 0x8
	struct FColor VertexColor; // Offset: 0x48 | Size: 0x4
	int32_t MaterialIndex; // Offset: 0x4c | Size: 0x4
};

// Object: ScriptStruct Paper2D.PaperSpriteSocket
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FPaperSpriteSocket {
	// Fields
	struct FTransform LocalTransform; // Offset: 0x0 | Size: 0x30
	struct FName SocketName; // Offset: 0x30 | Size: 0x8
	char pad_0x38[0x8]; // Offset: 0x38 | Size: 0x8
};

// Object: ScriptStruct Paper2D.PaperSpriteAtlasSlot
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FPaperSpriteAtlasSlot {
	// Fields
	struct TSoftObjectPtr<UPaperSprite> SpriteRef; // Offset: 0x0 | Size: 0x28
	int32_t AtlasIndex; // Offset: 0x28 | Size: 0x4
	int32_t X; // Offset: 0x2c | Size: 0x4
	int32_t Y; // Offset: 0x30 | Size: 0x4
	int32_t Width; // Offset: 0x34 | Size: 0x4
	int32_t Height; // Offset: 0x38 | Size: 0x4
	char pad_0x3C[0x4]; // Offset: 0x3c | Size: 0x4
};

// Object: ScriptStruct Paper2D.PaperTerrainMaterialRule
// Inherited Bytes: 0x0 | Struct Size: 0x38
struct FPaperTerrainMaterialRule {
	// Fields
	struct UPaperSprite* StartCap; // Offset: 0x0 | Size: 0x8
	struct TArray<struct UPaperSprite*> Body; // Offset: 0x8 | Size: 0x10
	struct UPaperSprite* EndCap; // Offset: 0x18 | Size: 0x8
	float MinimumAngle; // Offset: 0x20 | Size: 0x4
	float MaximumAngle; // Offset: 0x24 | Size: 0x4
	bool bEnableCollision; // Offset: 0x28 | Size: 0x1
	char pad_0x29[0x3]; // Offset: 0x29 | Size: 0x3
	float CollisionOffset; // Offset: 0x2c | Size: 0x4
	int32_t DrawOrder; // Offset: 0x30 | Size: 0x4
	char pad_0x34[0x4]; // Offset: 0x34 | Size: 0x4
};

// Object: ScriptStruct Paper2D.PaperTileInfo
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FPaperTileInfo {
	// Fields
	struct UPaperTileSet* TileSet; // Offset: 0x0 | Size: 0x8
	int32_t PackedTileIndex; // Offset: 0x8 | Size: 0x4
	char pad_0xC[0x4]; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct Paper2D.PaperTileSetTerrain
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FPaperTileSetTerrain {
	// Fields
	struct FString TerrainName; // Offset: 0x0 | Size: 0x10
	int32_t CenterTileIndex; // Offset: 0x10 | Size: 0x4
	char pad_0x14[0x4]; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct Paper2D.PaperTileMetadata
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FPaperTileMetadata {
	// Fields
	struct FName UserDataName; // Offset: 0x0 | Size: 0x8
	struct FSpriteGeometryCollection CollisionData; // Offset: 0x8 | Size: 0x30
	char TerrainMembership[0x4]; // Offset: 0x38 | Size: 0x4
	char pad_0x3C[0x4]; // Offset: 0x3c | Size: 0x4
};

// Object: ScriptStruct Paper2D.SpriteGeometryCollection
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FSpriteGeometryCollection {
	// Fields
	struct TArray<struct FSpriteGeometryShape> Shapes; // Offset: 0x0 | Size: 0x10
	enum class ESpritePolygonMode GeometryType; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x3]; // Offset: 0x11 | Size: 0x3
	int32_t PixelsPerSubdivisionX; // Offset: 0x14 | Size: 0x4
	int32_t PixelsPerSubdivisionY; // Offset: 0x18 | Size: 0x4
	bool bAvoidVertexMerging; // Offset: 0x1c | Size: 0x1
	char pad_0x1D[0x3]; // Offset: 0x1d | Size: 0x3
	float AlphaThreshold; // Offset: 0x20 | Size: 0x4
	float DetailAmount; // Offset: 0x24 | Size: 0x4
	float SimplifyEpsilon; // Offset: 0x28 | Size: 0x4
	char pad_0x2C[0x4]; // Offset: 0x2c | Size: 0x4
};

// Object: ScriptStruct Paper2D.SpriteGeometryShape
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FSpriteGeometryShape {
	// Fields
	enum class ESpriteShapeType ShapeType; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x7]; // Offset: 0x1 | Size: 0x7
	struct TArray<struct FVector2D> Vertices; // Offset: 0x8 | Size: 0x10
	struct FVector2D BoxSize; // Offset: 0x18 | Size: 0x8
	struct FVector2D BoxPosition; // Offset: 0x20 | Size: 0x8
	float Rotation; // Offset: 0x28 | Size: 0x4
	bool bNegativeWinding; // Offset: 0x2c | Size: 0x1
	char pad_0x2D[0x3]; // Offset: 0x2d | Size: 0x3
};

// Object: ScriptStruct Paper2D.SpriteDrawCallRecord
// Inherited Bytes: 0x0 | Struct Size: 0xd0
struct FSpriteDrawCallRecord {
	// Fields
	struct FVector Destination; // Offset: 0x0 | Size: 0xc
	char pad_0xC[0x4]; // Offset: 0xc | Size: 0x4
	struct UTexture* BaseTexture; // Offset: 0x10 | Size: 0x8
	char pad_0x18[0x30]; // Offset: 0x18 | Size: 0x30
	struct FColor Color; // Offset: 0x48 | Size: 0x4
	char pad_0x4C[0x84]; // Offset: 0x4c | Size: 0x84
};

// Object: ScriptStruct Paper2D.SpriteAssetInitParameters
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FSpriteAssetInitParameters {
	// Fields
	char pad_0x0[0x40]; // Offset: 0x0 | Size: 0x40
};

