#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class ProtectBase.ProtectBaseComponent
// Inherited Bytes: 0x28 | Struct Size: 0x50
struct UProtectBaseComponent : UObject {
	// Fields
	char pad_0x28[0x28]; // Offset: 0x28 | Size: 0x28

	// Functions

	// Object: Function ProtectBase.ProtectBaseComponent.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x101836e04
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UProtectBaseComponent* GetInstance();
};

// Object: Class ProtectBase.ProtectBaseManager
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UProtectBaseManager : UObject {
};

// Object: Class ProtectBase.SecDSComponent
// Inherited Bytes: 0x28 | Struct Size: 0xa0
struct USecDSComponent : UObject {
	// Fields
	char pad_0x28[0x78]; // Offset: 0x28 | Size: 0x78

	// Functions

	// Object: Function ProtectBase.SecDSComponent.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x10183742c
	// Return & Params: [ Num(1) Size(0x8) ]
	struct USecDSComponent* GetInstance();
};

