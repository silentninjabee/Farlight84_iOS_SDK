#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: DynamicClass R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_C
// Inherited Bytes: 0x300 | Struct Size: 0xa40
struct UR_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_C : UWeaponAnimInstance {
	// Fields
	struct FAnimNode_Root AnimGraphNode_Root; // Offset: 0x300 | Size: 0x30
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_19; // Offset: 0x330 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_18; // Offset: 0x358 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_17; // Offset: 0x380 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_16; // Offset: 0x3a8 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_15; // Offset: 0x3d0 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_14; // Offset: 0x3f8 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_13; // Offset: 0x420 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_12; // Offset: 0x448 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_11; // Offset: 0x470 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_10; // Offset: 0x498 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_9; // Offset: 0x4c0 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_8; // Offset: 0x4e8 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_7; // Offset: 0x510 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_6; // Offset: 0x538 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_5; // Offset: 0x560 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_4; // Offset: 0x588 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_3; // Offset: 0x5b0 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_2; // Offset: 0x5d8 | Size: 0x28
	struct FAnimNode_StateResult AnimGraphNode_StateResult_9; // Offset: 0x600 | Size: 0x30
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_3; // Offset: 0x630 | Size: 0x88
	struct FAnimNode_StateResult AnimGraphNode_StateResult_8; // Offset: 0x6b8 | Size: 0x30
	struct FAnimNode_StateResult AnimGraphNode_StateResult_7; // Offset: 0x6e8 | Size: 0x30
	struct FAnimNode_StateResult AnimGraphNode_StateResult_6; // Offset: 0x718 | Size: 0x30
	struct FAnimNode_StateResult AnimGraphNode_StateResult_5; // Offset: 0x748 | Size: 0x30
	struct FAnimNode_StateResult AnimGraphNode_StateResult_4; // Offset: 0x778 | Size: 0x30
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2; // Offset: 0x7a8 | Size: 0x88
	struct FAnimNode_StateResult AnimGraphNode_StateResult_3; // Offset: 0x830 | Size: 0x30
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer; // Offset: 0x860 | Size: 0x88
	struct FAnimNode_StateResult AnimGraphNode_StateResult_2; // Offset: 0x8e8 | Size: 0x30
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult; // Offset: 0x918 | Size: 0x28
	struct FAnimNode_StateResult AnimGraphNode_StateResult; // Offset: 0x940 | Size: 0x30
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine; // Offset: 0x970 | Size: 0xb0
	struct FAnimMsgData K2Node_MakeStruct_AnimMsgData; // Offset: 0xa20 | Size: 0x8
	struct TArray<struct FAnimMsgData> K2Node_MakeArray_Array; // Offset: 0xa28 | Size: 0x10
	char pad_0xA38[0x8]; // Offset: 0xa38 | Size: 0x8

	// Functions

	// Object: Function R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_C.TestAPI
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x101e52864
	// Return & Params: [ Num(0) Size(0x0) ]
	void TestAPI();

	// Object: Function R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_C.InterruptAnim
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x101e5290c
	// Return & Params: [ Num(0) Size(0x0) ]
	void InterruptAnim();

	// Object: Function R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_F9B9D1D1429B89723237BCB24B54862E
	// Flags: [Native|Public]
	// Offset: 0x101e52618
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_F9B9D1D1429B89723237BCB24B54862E();

	// Object: Function R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_E81BBECC4F2539FBCC25DFBE34448455
	// Flags: [Native|Public]
	// Offset: 0x101e52848
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_E81BBECC4F2539FBCC25DFBE34448455();

	// Object: Function R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_E790E6FA43FF01001DC00EBAE7DEA73A
	// Flags: [Native|Public]
	// Offset: 0x101e527a0
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_E790E6FA43FF01001DC00EBAE7DEA73A();

	// Object: Function R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_DC9EA4E74865E73956415D9AF6AF0FFB
	// Flags: [Native|Public]
	// Offset: 0x101e527d8
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_DC9EA4E74865E73956415D9AF6AF0FFB();

	// Object: Function R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_C56C131748626A9573F10282DB5E5052
	// Flags: [Native|Public]
	// Offset: 0x101e5282c
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_C56C131748626A9573F10282DB5E5052();

	// Object: Function R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_A975C81F48BDBB724FEA16A32DFE52AD
	// Flags: [Native|Public]
	// Offset: 0x101e52688
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_A975C81F48BDBB724FEA16A32DFE52AD();

	// Object: Function R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_A83B21F44232771E157063B19FE49DAE
	// Flags: [Native|Public]
	// Offset: 0x101e52730
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_A83B21F44232771E157063B19FE49DAE();

	// Object: Function R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_A5A85ECA4384FEB312E5EC9FAEEBC8EF
	// Flags: [Native|Public]
	// Offset: 0x101e52784
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_A5A85ECA4384FEB312E5EC9FAEEBC8EF();

	// Object: Function R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_A22C0EEB41705474E28772B94C0CC5EB
	// Flags: [Native|Public]
	// Offset: 0x101e52714
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_A22C0EEB41705474E28772B94C0CC5EB();

	// Object: Function R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_907282E34D2CAA9D3A150695E8520162
	// Flags: [Native|Public]
	// Offset: 0x101e526c0
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_907282E34D2CAA9D3A150695E8520162();

	// Object: Function R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_4E1475084D2538539DC6B7B5FE4829E3
	// Flags: [Native|Public]
	// Offset: 0x101e5266c
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_4E1475084D2538539DC6B7B5FE4829E3();

	// Object: Function R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_306B18E0410A5BCBF024F5BE0FAB5E62
	// Flags: [Native|Public]
	// Offset: 0x101e5289c
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_306B18E0410A5BCBF024F5BE0FAB5E62();

	// Object: Function R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_25994E49470CDA5E127ECA9658B84C2C
	// Flags: [Native|Public]
	// Offset: 0x101e52650
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_25994E49470CDA5E127ECA9658B84C2C();

	// Object: Function R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_241F2F034EA4B16FD25A7FA8376C1262
	// Flags: [Native|Public]
	// Offset: 0x101e52768
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_241F2F034EA4B16FD25A7FA8376C1262();

	// Object: Function R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_13E18D2B4DDE406CA9E094A97AAB8CB2
	// Flags: [Native|Public]
	// Offset: 0x101e526dc
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_13E18D2B4DDE406CA9E094A97AAB8CB2();

	// Object: Function R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_125A882A42DD03542B5F35AA4CA5C649
	// Flags: [Native|Public]
	// Offset: 0x101e5274c
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_125A882A42DD03542B5F35AA4CA5C649();

	// Object: Function R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_0D0306C84CEAEC5B427587847A0781A8
	// Flags: [Native|Public]
	// Offset: 0x101e526f8
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_0D0306C84CEAEC5B427587847A0781A8();

	// Object: Function R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_0AA3044A40FAC11D469367A4DF67F175
	// Flags: [Native|Public]
	// Offset: 0x101e526a4
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_0AA3044A40FAC11D469367A4DF67F175();

	// Object: Function R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_00A6E5CC469B38D9B7CBF9B11D9E2044
	// Flags: [Native|Public]
	// Offset: 0x101e52634
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_00A6E5CC469B38D9B7CBF9B11D9E2044();

	// Object: Function R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_SequencePlayer_F51C3A6B44503A03F1755DBDE8B8461F
	// Flags: [Native|Public]
	// Offset: 0x101e527f4
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_SequencePlayer_F51C3A6B44503A03F1755DBDE8B8461F();

	// Object: Function R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_SequencePlayer_D259476E46AC7C2E329C7A9BFA6A26D1
	// Flags: [Native|Public]
	// Offset: 0x101e527bc
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_SequencePlayer_D259476E46AC7C2E329C7A9BFA6A26D1();

	// Object: Function R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_SequencePlayer_5AE0E49E4A554133EEF277A411847096
	// Flags: [Native|Public]
	// Offset: 0x101e52810
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_SequencePlayer_5AE0E49E4A554133EEF277A411847096();

	// Object: Function R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_C.AnimNotify_QuitIdle
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x101e528f0
	// Return & Params: [ Num(0) Size(0x0) ]
	void AnimNotify_QuitIdle();

	// Object: Function R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_C.AnimNotify_QuitFire
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x101e528b8
	// Return & Params: [ Num(0) Size(0x0) ]
	void AnimNotify_QuitFire();

	// Object: Function R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_C.AnimNotify_EnterIdle
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x101e528d4
	// Return & Params: [ Num(0) Size(0x0) ]
	void AnimNotify_EnterIdle();

	// Object: Function R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_C.AnimNotify_EnterFire
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x101e52880
	// Return & Params: [ Num(0) Size(0x0) ]
	void AnimNotify_EnterFire();

	// Object: Function R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_9A02_Set00_LODP_Skeleton_AnimBlueprint_C.AnimGraph
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101e52578
	// Return & Params: [ Num(1) Size(0x10) ]
	void AnimGraph(struct FPoseLink& bpp__AnimGraph__pf);
};

