#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: DynamicClass R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_C
// Inherited Bytes: 0x300 | Struct Size: 0xa40
struct UR_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_C : UWeaponAnimInstance {
	// Fields
	struct FAnimNode_Root AnimGraphNode_Root; // Offset: 0x300 | Size: 0x30
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_19; // Offset: 0x330 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_18; // Offset: 0x358 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_17; // Offset: 0x380 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_16; // Offset: 0x3a8 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_15; // Offset: 0x3d0 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_14; // Offset: 0x3f8 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_13; // Offset: 0x420 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_12; // Offset: 0x448 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_11; // Offset: 0x470 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_10; // Offset: 0x498 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_9; // Offset: 0x4c0 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_8; // Offset: 0x4e8 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_7; // Offset: 0x510 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_6; // Offset: 0x538 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_5; // Offset: 0x560 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_4; // Offset: 0x588 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_3; // Offset: 0x5b0 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_2; // Offset: 0x5d8 | Size: 0x28
	struct FAnimNode_StateResult AnimGraphNode_StateResult_9; // Offset: 0x600 | Size: 0x30
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_3; // Offset: 0x630 | Size: 0x88
	struct FAnimNode_StateResult AnimGraphNode_StateResult_8; // Offset: 0x6b8 | Size: 0x30
	struct FAnimNode_StateResult AnimGraphNode_StateResult_7; // Offset: 0x6e8 | Size: 0x30
	struct FAnimNode_StateResult AnimGraphNode_StateResult_6; // Offset: 0x718 | Size: 0x30
	struct FAnimNode_StateResult AnimGraphNode_StateResult_5; // Offset: 0x748 | Size: 0x30
	struct FAnimNode_StateResult AnimGraphNode_StateResult_4; // Offset: 0x778 | Size: 0x30
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2; // Offset: 0x7a8 | Size: 0x88
	struct FAnimNode_StateResult AnimGraphNode_StateResult_3; // Offset: 0x830 | Size: 0x30
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer; // Offset: 0x860 | Size: 0x88
	struct FAnimNode_StateResult AnimGraphNode_StateResult_2; // Offset: 0x8e8 | Size: 0x30
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult; // Offset: 0x918 | Size: 0x28
	struct FAnimNode_StateResult AnimGraphNode_StateResult; // Offset: 0x940 | Size: 0x30
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine; // Offset: 0x970 | Size: 0xb0
	struct FAnimMsgData K2Node_MakeStruct_AnimMsgData; // Offset: 0xa20 | Size: 0x8
	struct TArray<struct FAnimMsgData> K2Node_MakeArray_Array; // Offset: 0xa28 | Size: 0x10
	char pad_0xA38[0x8]; // Offset: 0xa38 | Size: 0x8

	// Functions

	// Object: Function R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_C.TestAPI
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x101e61778
	// Return & Params: [ Num(0) Size(0x0) ]
	void TestAPI();

	// Object: Function R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_C.InterruptAnim
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x101e61820
	// Return & Params: [ Num(0) Size(0x0) ]
	void InterruptAnim();

	// Object: Function R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_FD3912374DA1042122EF4BA346AED47D
	// Flags: [Native|Public]
	// Offset: 0x101e6167c
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_FD3912374DA1042122EF4BA346AED47D();

	// Object: Function R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_F3E1CE4F4F52BDDF2C7C4392679371E6
	// Flags: [Native|Public]
	// Offset: 0x101e616b4
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_F3E1CE4F4F52BDDF2C7C4392679371E6();

	// Object: Function R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_D5845B9E400B3D008BEF698B783B92A9
	// Flags: [Native|Public]
	// Offset: 0x101e61660
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_D5845B9E400B3D008BEF698B783B92A9();

	// Object: Function R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_D26EF958487058FA7FC43FAD41F4DEF7
	// Flags: [Native|Public]
	// Offset: 0x101e6160c
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_D26EF958487058FA7FC43FAD41F4DEF7();

	// Object: Function R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_C56C131748626A9573F10282DB5E5052
	// Flags: [Native|Public]
	// Offset: 0x101e61740
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_C56C131748626A9573F10282DB5E5052();

	// Object: Function R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_9F7EE7DF4EADB7412001EA80EB6DF9EE
	// Flags: [Native|Public]
	// Offset: 0x101e61580
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_9F7EE7DF4EADB7412001EA80EB6DF9EE();

	// Object: Function R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_90C49DEF49A94759B5DF8D8AB0247252
	// Flags: [Native|Public]
	// Offset: 0x101e61644
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_90C49DEF49A94759B5DF8D8AB0247252();

	// Object: Function R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_7BF9F6B543647F4000354585CCDD9D8C
	// Flags: [Native|Public]
	// Offset: 0x101e616ec
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_7BF9F6B543647F4000354585CCDD9D8C();

	// Object: Function R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_69DC14EC4A779FA924FD3BAD514C71CA
	// Flags: [Native|Public]
	// Offset: 0x101e6175c
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_69DC14EC4A779FA924FD3BAD514C71CA();

	// Object: Function R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_520B94684B85FF9018373286CEF79B9D
	// Flags: [Native|Public]
	// Offset: 0x101e615f0
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_520B94684B85FF9018373286CEF79B9D();

	// Object: Function R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_512995A9441B7ABA6A1354A124B4947D
	// Flags: [Native|Public]
	// Offset: 0x101e61628
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_512995A9441B7ABA6A1354A124B4947D();

	// Object: Function R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_48E7AFC2428503DF315D6DA5F2F053F5
	// Flags: [Native|Public]
	// Offset: 0x101e61564
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_48E7AFC2428503DF315D6DA5F2F053F5();

	// Object: Function R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_3FDD26624535716666823A85B4A0EA6B
	// Flags: [Native|Public]
	// Offset: 0x101e615d4
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_3FDD26624535716666823A85B4A0EA6B();

	// Object: Function R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_37CC4BD349701B7B6B2903932ADDE28C
	// Flags: [Native|Public]
	// Offset: 0x101e61698
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_37CC4BD349701B7B6B2903932ADDE28C();

	// Object: Function R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_2DD7E36F4A2BD62B1A8519B45B2FBE75
	// Flags: [Native|Public]
	// Offset: 0x101e6152c
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_2DD7E36F4A2BD62B1A8519B45B2FBE75();

	// Object: Function R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_2AFD33E54E0DB5EA1233039AC1CBEAAE
	// Flags: [Native|Public]
	// Offset: 0x101e6159c
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_2AFD33E54E0DB5EA1233039AC1CBEAAE();

	// Object: Function R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_272B77AE42671779C55883858592D62C
	// Flags: [Native|Public]
	// Offset: 0x101e615b8
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_272B77AE42671779C55883858592D62C();

	// Object: Function R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_075E1FBF4BB9C39350964A81FBF296DE
	// Flags: [Native|Public]
	// Offset: 0x101e617b0
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_075E1FBF4BB9C39350964A81FBF296DE();

	// Object: Function R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_0584AE8244C44B37DF07C28ADC078A60
	// Flags: [Native|Public]
	// Offset: 0x101e61548
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_0584AE8244C44B37DF07C28ADC078A60();

	// Object: Function R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_SequencePlayer_31A4CD864812F3929F156E9AEE73754C
	// Flags: [Native|Public]
	// Offset: 0x101e61724
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_SequencePlayer_31A4CD864812F3929F156E9AEE73754C();

	// Object: Function R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_SequencePlayer_306EF0F349340C3816672B840E67EAF3
	// Flags: [Native|Public]
	// Offset: 0x101e616d0
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_SequencePlayer_306EF0F349340C3816672B840E67EAF3();

	// Object: Function R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_SequencePlayer_296D1E13442BD0646F8BEE8C73C07614
	// Flags: [Native|Public]
	// Offset: 0x101e61708
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_SequencePlayer_296D1E13442BD0646F8BEE8C73C07614();

	// Object: Function R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_C.AnimNotify_QuitIdle
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x101e61804
	// Return & Params: [ Num(0) Size(0x0) ]
	void AnimNotify_QuitIdle();

	// Object: Function R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_C.AnimNotify_QuitFire
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x101e617cc
	// Return & Params: [ Num(0) Size(0x0) ]
	void AnimNotify_QuitFire();

	// Object: Function R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_C.AnimNotify_EnterIdle
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x101e617e8
	// Return & Params: [ Num(0) Size(0x0) ]
	void AnimNotify_EnterIdle();

	// Object: Function R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_C.AnimNotify_EnterFire
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x101e61794
	// Return & Params: [ Num(0) Size(0x0) ]
	void AnimNotify_EnterFire();

	// Object: Function R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_WL03_Set00_LODP_Skeleton_AnimBlueprint_C.AnimGraph
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101e6148c
	// Return & Params: [ Num(1) Size(0x10) ]
	void AnimGraph(struct FPoseLink& bpp__AnimGraph__pf);
};

