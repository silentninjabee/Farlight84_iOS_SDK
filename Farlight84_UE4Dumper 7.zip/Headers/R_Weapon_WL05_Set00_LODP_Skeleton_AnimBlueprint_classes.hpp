#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: DynamicClass R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_C
// Inherited Bytes: 0x300 | Struct Size: 0xa40
struct UR_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_C : UWeaponAnimInstance {
	// Fields
	struct FAnimNode_Root AnimGraphNode_Root; // Offset: 0x300 | Size: 0x30
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_19; // Offset: 0x330 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_18; // Offset: 0x358 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_17; // Offset: 0x380 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_16; // Offset: 0x3a8 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_15; // Offset: 0x3d0 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_14; // Offset: 0x3f8 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_13; // Offset: 0x420 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_12; // Offset: 0x448 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_11; // Offset: 0x470 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_10; // Offset: 0x498 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_9; // Offset: 0x4c0 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_8; // Offset: 0x4e8 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_7; // Offset: 0x510 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_6; // Offset: 0x538 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_5; // Offset: 0x560 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_4; // Offset: 0x588 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_3; // Offset: 0x5b0 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_2; // Offset: 0x5d8 | Size: 0x28
	struct FAnimNode_StateResult AnimGraphNode_StateResult_9; // Offset: 0x600 | Size: 0x30
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_3; // Offset: 0x630 | Size: 0x88
	struct FAnimNode_StateResult AnimGraphNode_StateResult_8; // Offset: 0x6b8 | Size: 0x30
	struct FAnimNode_StateResult AnimGraphNode_StateResult_7; // Offset: 0x6e8 | Size: 0x30
	struct FAnimNode_StateResult AnimGraphNode_StateResult_6; // Offset: 0x718 | Size: 0x30
	struct FAnimNode_StateResult AnimGraphNode_StateResult_5; // Offset: 0x748 | Size: 0x30
	struct FAnimNode_StateResult AnimGraphNode_StateResult_4; // Offset: 0x778 | Size: 0x30
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2; // Offset: 0x7a8 | Size: 0x88
	struct FAnimNode_StateResult AnimGraphNode_StateResult_3; // Offset: 0x830 | Size: 0x30
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer; // Offset: 0x860 | Size: 0x88
	struct FAnimNode_StateResult AnimGraphNode_StateResult_2; // Offset: 0x8e8 | Size: 0x30
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult; // Offset: 0x918 | Size: 0x28
	struct FAnimNode_StateResult AnimGraphNode_StateResult; // Offset: 0x940 | Size: 0x30
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine; // Offset: 0x970 | Size: 0xb0
	struct FAnimMsgData K2Node_MakeStruct_AnimMsgData; // Offset: 0xa20 | Size: 0x8
	struct TArray<struct FAnimMsgData> K2Node_MakeArray_Array; // Offset: 0xa28 | Size: 0x10
	char pad_0xA38[0x8]; // Offset: 0xa38 | Size: 0x8

	// Functions

	// Object: Function R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_C.TestAPI
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x101e63d24
	// Return & Params: [ Num(0) Size(0x0) ]
	void TestAPI();

	// Object: Function R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_C.InterruptAnim
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x101e63dcc
	// Return & Params: [ Num(0) Size(0x0) ]
	void InterruptAnim();

	// Object: Function R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_F864A8404805F7EACEFC909E832043EE
	// Flags: [Native|Public]
	// Offset: 0x101e63af4
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_F864A8404805F7EACEFC909E832043EE();

	// Object: Function R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_EF1003244660F4F16818ACB549FE30A2
	// Flags: [Native|Public]
	// Offset: 0x101e63c98
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_EF1003244660F4F16818ACB549FE30A2();

	// Object: Function R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_C9FED2714733C7A7136C3B853D25E8AF
	// Flags: [Native|Public]
	// Offset: 0x101e63b9c
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_C9FED2714733C7A7136C3B853D25E8AF();

	// Object: Function R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_C75E784B46BBB88DCA0310ACB0D26B5C
	// Flags: [Native|Public]
	// Offset: 0x101e63d5c
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_C75E784B46BBB88DCA0310ACB0D26B5C();

	// Object: Function R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_C56C131748626A9573F10282DB5E5052
	// Flags: [Native|Public]
	// Offset: 0x101e63cec
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_C56C131748626A9573F10282DB5E5052();

	// Object: Function R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_B0F67D2C42C3309858AB33AC10288A84
	// Flags: [Native|Public]
	// Offset: 0x101e63c60
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_B0F67D2C42C3309858AB33AC10288A84();

	// Object: Function R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_A9D4CFA64B088023BC866EB7258D24DB
	// Flags: [Native|Public]
	// Offset: 0x101e63bf0
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_A9D4CFA64B088023BC866EB7258D24DB();

	// Object: Function R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_A09B0CDA42727AF610670C94DE73F3FB
	// Flags: [Native|Public]
	// Offset: 0x101e63b2c
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_A09B0CDA42727AF610670C94DE73F3FB();

	// Object: Function R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_6DD2D4034F92A9BD828C65B8BFBA2293
	// Flags: [Native|Public]
	// Offset: 0x101e63c28
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_6DD2D4034F92A9BD828C65B8BFBA2293();

	// Object: Function R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_648093B0430A4941FAABC299AD2FE963
	// Flags: [Native|Public]
	// Offset: 0x101e63c0c
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_648093B0430A4941FAABC299AD2FE963();

	// Object: Function R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_52925DBD4E136234F3ECC881874BD63D
	// Flags: [Native|Public]
	// Offset: 0x101e63d08
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_52925DBD4E136234F3ECC881874BD63D();

	// Object: Function R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_5253111046BC8B08009AD3A86A2A6A92
	// Flags: [Native|Public]
	// Offset: 0x101e63b80
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_5253111046BC8B08009AD3A86A2A6A92();

	// Object: Function R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_4891E8A74C85C9FAA5F481BF49F3C328
	// Flags: [Native|Public]
	// Offset: 0x101e63c44
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_4891E8A74C85C9FAA5F481BF49F3C328();

	// Object: Function R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_3F59DA0B453648FCA8849BB4F06C4CAD
	// Flags: [Native|Public]
	// Offset: 0x101e63b10
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_3F59DA0B453648FCA8849BB4F06C4CAD();

	// Object: Function R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_3648865447AFE466BAF6F1AA55855DBA
	// Flags: [Native|Public]
	// Offset: 0x101e63b48
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_3648865447AFE466BAF6F1AA55855DBA();

	// Object: Function R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_2B2B494947D256B2462E0C8D47029D4D
	// Flags: [Native|Public]
	// Offset: 0x101e63ad8
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_2B2B494947D256B2462E0C8D47029D4D();

	// Object: Function R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_1A41016A4CC12032E6B0F3B5B6DDF69A
	// Flags: [Native|Public]
	// Offset: 0x101e63bd4
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_1A41016A4CC12032E6B0F3B5B6DDF69A();

	// Object: Function R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_1210DDEB4E4988C12C9E2E8BBF476289
	// Flags: [Native|Public]
	// Offset: 0x101e63bb8
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_1210DDEB4E4988C12C9E2E8BBF476289();

	// Object: Function R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_06660E20471885C3FDEA209298977A13
	// Flags: [Native|Public]
	// Offset: 0x101e63b64
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_06660E20471885C3FDEA209298977A13();

	// Object: Function R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_SequencePlayer_B900DE27498B8EBDD9C81293F7BB1ED6
	// Flags: [Native|Public]
	// Offset: 0x101e63cb4
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_SequencePlayer_B900DE27498B8EBDD9C81293F7BB1ED6();

	// Object: Function R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_SequencePlayer_AEDD1FCA452DB89BD307AAA8B18B310C
	// Flags: [Native|Public]
	// Offset: 0x101e63c7c
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_SequencePlayer_AEDD1FCA452DB89BD307AAA8B18B310C();

	// Object: Function R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_SequencePlayer_611D453D494879EE90A0FE84805C41A1
	// Flags: [Native|Public]
	// Offset: 0x101e63cd0
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_SequencePlayer_611D453D494879EE90A0FE84805C41A1();

	// Object: Function R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_C.AnimNotify_QuitIdle
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x101e63db0
	// Return & Params: [ Num(0) Size(0x0) ]
	void AnimNotify_QuitIdle();

	// Object: Function R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_C.AnimNotify_QuitFire
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x101e63d78
	// Return & Params: [ Num(0) Size(0x0) ]
	void AnimNotify_QuitFire();

	// Object: Function R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_C.AnimNotify_EnterIdle
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x101e63d94
	// Return & Params: [ Num(0) Size(0x0) ]
	void AnimNotify_EnterIdle();

	// Object: Function R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_C.AnimNotify_EnterFire
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x101e63d40
	// Return & Params: [ Num(0) Size(0x0) ]
	void AnimNotify_EnterFire();

	// Object: Function R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_WL05_Set00_LODP_Skeleton_AnimBlueprint_C.AnimGraph
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101e63a38
	// Return & Params: [ Num(1) Size(0x10) ]
	void AnimGraph(struct FPoseLink& bpp__AnimGraph__pf);
};

