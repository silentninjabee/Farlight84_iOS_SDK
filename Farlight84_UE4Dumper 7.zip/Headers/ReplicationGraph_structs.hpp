#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct ReplicationGraph.ConnectionAlwaysRelevantNodePair
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FConnectionAlwaysRelevantNodePair {
	// Fields
	struct UNetConnection* NetConnection; // Offset: 0x0 | Size: 0x8
	struct UReplicationGraphNode_AlwaysRelevant_ForConnection* Node; // Offset: 0x8 | Size: 0x8
};

// Object: ScriptStruct ReplicationGraph.LastLocationGatherInfo
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FLastLocationGatherInfo {
	// Fields
	struct UNetConnection* Connection; // Offset: 0x0 | Size: 0x8
	struct FVector LastLocation; // Offset: 0x8 | Size: 0xc
	struct FVector LastOutOfRangeLocationCheck; // Offset: 0x14 | Size: 0xc
};

// Object: ScriptStruct ReplicationGraph.TearOffActorInfo
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FTearOffActorInfo {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
	struct AActor* Actor; // Offset: 0x8 | Size: 0x8
	char pad_0x10[0x8]; // Offset: 0x10 | Size: 0x8
};

// Object: ScriptStruct ReplicationGraph.ClassExtraReplicatedInfo
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FClassExtraReplicatedInfo {
	// Fields
	struct TMap<struct UObject*, int32_t> ClassActorsMaxReplicatedNum; // Offset: 0x0 | Size: 0x50
};

// Object: ScriptStruct ReplicationGraph.AlwaysRelevantActorInfo
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FAlwaysRelevantActorInfo {
	// Fields
	struct UNetConnection* Connection; // Offset: 0x0 | Size: 0x8
	struct AActor* LastViewer; // Offset: 0x8 | Size: 0x8
	struct AActor* LastViewTarget; // Offset: 0x10 | Size: 0x8
};

// Object: ScriptStruct ReplicationGraph.ClassReplicationInfo
// Inherited Bytes: 0x0 | Struct Size: 0x70
struct FClassReplicationInfo {
	// Fields
	float DistancePriorityScale; // Offset: 0x0 | Size: 0x4
	float StarvationPriorityScale; // Offset: 0x4 | Size: 0x4
	float AccumulatedNetPriorityBias; // Offset: 0x8 | Size: 0x4
	uint16_t ReplicationPeriodFrame; // Offset: 0xc | Size: 0x2
	uint16_t FastPath_ReplicationPeriodFrame; // Offset: 0xe | Size: 0x2
	uint16_t ActorChannelFrameTimeout; // Offset: 0x10 | Size: 0x2
	char pad_0x12[0x56]; // Offset: 0x12 | Size: 0x56
	float CullDistance; // Offset: 0x68 | Size: 0x4
	float CullDistanceSquared; // Offset: 0x6c | Size: 0x4
};

