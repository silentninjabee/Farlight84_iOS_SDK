#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class SignificanceManager.SignificanceManager
// Inherited Bytes: 0x28 | Struct Size: 0x138
struct USignificanceManager : UObject {
	// Fields
	char pad_0x28[0xf8]; // Offset: 0x28 | Size: 0xf8
	struct FSoftClassPath SignificanceManagerClassName; // Offset: 0x120 | Size: 0x18
};

