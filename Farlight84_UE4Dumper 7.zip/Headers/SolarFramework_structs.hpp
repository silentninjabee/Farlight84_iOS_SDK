#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct SolarFramework.SolarConfigEntry
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FSolarConfigEntry {
	// Fields
	struct TSoftClassPtr<UObject> ContainerPath; // Offset: 0x0 | Size: 0x28
	enum class EScope Scope; // Offset: 0x28 | Size: 0x1
	char pad_0x29[0x7]; // Offset: 0x29 | Size: 0x7
};

