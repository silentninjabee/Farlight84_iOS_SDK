#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass SolarGameInstance.SolarGameInstance_C
// Inherited Bytes: 0xa38 | Struct Size: 0xa50
struct USolarGameInstance_C : USolarGameInstanceBase {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0xa38 | Size: 0x8
	struct FMulticastInlineDelegate OnBroadcastModeChanged; // Offset: 0xa40 | Size: 0x10

	// Functions

	// Object: DelegateFunction SolarGameInstance.SolarGameInstance_C.OnIOSLLHPayFinished_A4DE515C5F4437FE5DD189BAC802CF8D
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015c6968
	// Return & Params: [ Num(6) Size(0x31) ]
	void OnIOSLLHPayFinished_A4DE515C5F4437FE5DD189BAC802CF8D(bool bSuccess, int32_t ErrorCode, struct FString ErrorMsg, int32_t PayValue, struct FString ProductID, enum class ELLHSDKPayType PayType);

	// Object: DelegateFunction SolarGameInstance.SolarGameInstance_C.OnIOSQuerySkus_FF22269C664170263386FB9B97B03558
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x1015c6968
	// Return & Params: [ Num(2) Size(0x20) ]
	void OnIOSQuerySkus_FF22269C664170263386FB9B97B03558(struct FLLHSDKGenericSkuItemsDetailList ItemsDetailList, struct TArray<struct FString>& InvalidProductIDs);

	// Object: DelegateFunction SolarGameInstance.SolarGameInstance_C.OnInternalBrowserOpen_713DF7D75F4E2F3489A25B9C515F81EF
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015c6968
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnInternalBrowserOpen_713DF7D75F4E2F3489A25B9C515F81EF();

	// Object: DelegateFunction SolarGameInstance.SolarGameInstance_C.OnBrowserClosed_D4CA2AFF57459644FE1DD891266EC641
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015c6968
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnBrowserClosed_D4CA2AFF57459644FE1DD891266EC641();

	// Object: DelegateFunction SolarGameInstance.SolarGameInstance_C.OnReceiveNotification_3B1BCA2F5342D37ADD86D3A028D6FC6C
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015c6968
	// Return & Params: [ Num(1) Size(0x4) ]
	void OnReceiveNotification_3B1BCA2F5342D37ADD86D3A028D6FC6C(int32_t NotificationType);

	// Object: DelegateFunction SolarGameInstance.SolarGameInstance_C.OnWifiStateChanged_2EA0D58D61464A6D5AC1E284B76F6BFF
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015c6968
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnWifiStateChanged_2EA0D58D61464A6D5AC1E284B76F6BFF(bool bEnabled);

	// Object: Function SolarGameInstance.SolarGameInstance_C.OnOtherNetworkFailureDisconnect
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x1015dc5d4
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnOtherNetworkFailureDisconnect();

	// Object: Function SolarGameInstance.SolarGameInstance_C.LuaGetBroadcastPlayerNameCopy
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(2) Size(0x20) ]
	void LuaGetBroadcastPlayerNameCopy(struct FString SolarPlayerID, struct FString& BroadcastPlayerName);

	// Object: Function SolarGameInstance.SolarGameInstance_C.HandleNetworkError
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x1015dc5d4
	// Return & Params: [ Num(2) Size(0x2) ]
	void HandleNetworkError(enum class ENetworkFailure FailureType, bool bIsServer);

	// Object: Function SolarGameInstance.SolarGameInstance_C.SolarGM_AddWeaponExpLua
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x1015dc5d4
	// Return & Params: [ Num(2) Size(0x8) ]
	void SolarGM_AddWeaponExpLua(int32_t weaponid, int32_t count);

	// Object: Function SolarGameInstance.SolarGameInstance_C.ShutdownAnoSDK
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x1015dc5d4
	// Return & Params: [ Num(0) Size(0x0) ]
	void ShutdownAnoSDK();

	// Object: Function SolarGameInstance.SolarGameInstance_C.SolarGM_AddItemLua
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x1015dc5d4
	// Return & Params: [ Num(2) Size(0x8) ]
	void SolarGM_AddItemLua(int32_t ItemID, int32_t count);

	// Object: Function SolarGameInstance.SolarGameInstance_C.ShutDownRTCSdk
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x1015dc5d4
	// Return & Params: [ Num(0) Size(0x0) ]
	void ShutDownRTCSdk();

	// Object: Function SolarGameInstance.SolarGameInstance_C.ReceiveShutdown
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x1015dc5d4
	// Return & Params: [ Num(0) Size(0x0) ]
	void ReceiveShutdown();

	// Object: Function SolarGameInstance.SolarGameInstance_C.InitLuaClasses
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x1015dc5d4
	// Return & Params: [ Num(0) Size(0x0) ]
	void InitLuaClasses();

	// Object: Function SolarGameInstance.SolarGameInstance_C.CheckSavedDirFiles
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x1015dc5d4
	// Return & Params: [ Num(1) Size(0x10) ]
	void CheckSavedDirFiles(struct TArray<struct FString>& Files);

	// Object: Function SolarGameInstance.SolarGameInstance_C.LuaStartGameFrameWork
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x1015dc5d4
	// Return & Params: [ Num(0) Size(0x0) ]
	void LuaStartGameFrameWork();

	// Object: Function SolarGameInstance.SolarGameInstance_C.OnDisconnect
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x1015dc5d4
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnDisconnect();

	// Object: Function SolarGameInstance.SolarGameInstance_C.LuaGetBroadcastHeroNameCopy
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(2) Size(0x20) ]
	void LuaGetBroadcastHeroNameCopy(struct FString SolarPlayerID, struct FString& BroadcastPlayerName);

	// Object: Function SolarGameInstance.SolarGameInstance_C.SolarGM_LobbyLua
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x1015dc5d4
	// Return & Params: [ Num(2) Size(0x20) ]
	void SolarGM_LobbyLua(struct FString CmdName, struct TArray<struct FString>& Params);

	// Object: Function SolarGameInstance.SolarGameInstance_C.LuaInitGameFrameWork
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x1015dc5d4
	// Return & Params: [ Num(0) Size(0x0) ]
	void LuaInitGameFrameWork();

	// Object: Function SolarGameInstance.SolarGameInstance_C.ExecuteChangeAudioModeLuaCall
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x1015dc5d4
	// Return & Params: [ Num(1) Size(0x1) ]
	void ExecuteChangeAudioModeLuaCall(bool bTurnOn);

	// Object: Function SolarGameInstance.SolarGameInstance_C.RegisterNetworkManager
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x1015dc5d4
	// Return & Params: [ Num(0) Size(0x0) ]
	void RegisterNetworkManager();

	// Object: Function SolarGameInstance.SolarGameInstance_C.ExecuteBackKeyLuaCall
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x1015dc5d4
	// Return & Params: [ Num(0) Size(0x0) ]
	void ExecuteBackKeyLuaCall();

	// Object: Function SolarGameInstance.SolarGameInstance_C.SolarGM_TransmitGMLua
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x1015dc5d4
	// Return & Params: [ Num(2) Size(0x20) ]
	void SolarGM_TransmitGMLua(struct FString playerName, struct TArray<struct FString>& GmArray);

	// Object: Function SolarGameInstance.SolarGameInstance_C.ShutDownPCSDK
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x1015dc5d4
	// Return & Params: [ Num(0) Size(0x0) ]
	void ShutDownPCSDK();

	// Object: Function SolarGameInstance.SolarGameInstance_C.ReportLoadingInfoToBI
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x1015dc5d4
	// Return & Params: [ Num(3) Size(0x15) ]
	void ReportLoadingInfoToBI(struct TArray<struct FString>& LoadingInfo, float LoadingTime, bool bIsFinished);

	// Object: Function SolarGameInstance.SolarGameInstance_C.AsyncDownLoadConfigFile
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x1015dc5d4
	// Return & Params: [ Num(2) Size(0x18) ]
	void AsyncDownLoadConfigFile(int64_t TaskID, struct FString URL);

	// Object: Function SolarGameInstance.SolarGameInstance_C.ShutDownLimSdk
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x1015dc5d4
	// Return & Params: [ Num(0) Size(0x0) ]
	void ShutDownLimSdk();

	// Object: Function SolarGameInstance.SolarGameInstance_C.OnScopeChanged
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x1015dc5d4
	// Return & Params: [ Num(2) Size(0x2) ]
	void OnScopeChanged(enum class EScope InLastScope, enum class EScope InCurScope);

	// Object: Function SolarGameInstance.SolarGameInstance_C.LuaOnBroadcastModeChanged
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(0) Size(0x0) ]
	void LuaOnBroadcastModeChanged();

	// Object: Function SolarGameInstance.SolarGameInstance_C.LuaGetBroadcastPlayerName
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x1015dc5d4
	// Return & Params: [ Num(2) Size(0x20) ]
	void LuaGetBroadcastPlayerName(struct FString SolarPlayerID, struct FString& BroadcastPlayerName);

	// Object: Function SolarGameInstance.SolarGameInstance_C.LuaGetBroadcastHeroName
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x1015dc5d4
	// Return & Params: [ Num(2) Size(0x20) ]
	void LuaGetBroadcastHeroName(struct FString SolarPlayerID, struct FString& BroadcastPlayerName);

	// Object: Function SolarGameInstance.SolarGameInstance_C.SolarGM_TestCrashWithBP
	// Flags: [Exec|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(0) Size(0x0) ]
	void SolarGM_TestCrashWithBP();

	// Object: Function SolarGameInstance.SolarGameInstance_C.SolarGM_TestEnsureMsgWithBP
	// Flags: [Exec|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(0) Size(0x0) ]
	void SolarGM_TestEnsureMsgWithBP();

	// Object: Function SolarGameInstance.SolarGameInstance_C.ExecuteUbergraph_SolarGameInstance
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_SolarGameInstance(int32_t EntryPoint);

	// Object: Function SolarGameInstance.SolarGameInstance_C.OnBroadcastModeChanged__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnBroadcastModeChanged__DelegateSignature();
};

