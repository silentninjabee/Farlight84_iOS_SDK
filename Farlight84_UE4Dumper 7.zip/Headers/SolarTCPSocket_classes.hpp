#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class SolarTCPSocket.SolarTCPSocketClient
// Inherited Bytes: 0x228 | Struct Size: 0x2b8
struct ASolarTCPSocketClient : AActor {
	// Fields
	int32_t SendBufferSize; // Offset: 0x228 | Size: 0x4
	int32_t ReceiveBufferSize; // Offset: 0x22c | Size: 0x4
	float TimeBetweenTicks; // Offset: 0x230 | Size: 0x4
	char pad_0x234[0x84]; // Offset: 0x234 | Size: 0x84

	// Functions

	// Object: Function SolarTCPSocket.SolarTCPSocketClient.SendData
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10205c570
	// Return & Params: [ Num(3) Size(0x19) ]
	bool SendData(int32_t ConnectionId, struct TArray<char> Data);

	// Object: Function SolarTCPSocket.SolarTCPSocketClient.Disconnect
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10205c6ac
	// Return & Params: [ Num(1) Size(0x4) ]
	void Disconnect(int32_t ConnectionId);

	// Object: Function SolarTCPSocket.SolarTCPSocketClient.Connect
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10205c72c
	// Return & Params: [ Num(6) Size(0x48) ]
	void Connect(struct FString IP, int32_t Port, struct FDelegate& OnConnected, struct FDelegate& OnDisconnected, struct FDelegate& OnMessageReceived, int32_t& ConnectionId);
};

