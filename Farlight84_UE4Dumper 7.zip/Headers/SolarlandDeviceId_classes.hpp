#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class SolarlandDeviceId.SolarlandDeviceInfoSettings
// Inherited Bytes: 0x38 | Struct Size: 0x48
struct USolarlandDeviceInfoSettings : UDeveloperSettings {
	// Fields
	struct FString UserName; // Offset: 0x38 | Size: 0x10

	// Functions

	// Object: Function SolarlandDeviceId.SolarlandDeviceInfoSettings.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x103974fe0
	// Return & Params: [ Num(1) Size(0x8) ]
	struct USolarlandDeviceInfoSettings* GetInstance();
};

