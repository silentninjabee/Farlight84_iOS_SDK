#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct StaticMeshDescription.UVMapSettings
// Inherited Bytes: 0x0 | Struct Size: 0x38
struct FUVMapSettings {
	// Fields
	struct FVector Size; // Offset: 0x0 | Size: 0xc
	struct FVector2D UVTile; // Offset: 0xc | Size: 0x8
	struct FVector Position; // Offset: 0x14 | Size: 0xc
	struct FRotator Rotation; // Offset: 0x20 | Size: 0xc
	struct FVector Scale; // Offset: 0x2c | Size: 0xc
};

