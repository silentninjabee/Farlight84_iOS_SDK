#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class Synthesis.ModularSynthPresetBank
// Inherited Bytes: 0x28 | Struct Size: 0x38
struct UModularSynthPresetBank : UObject {
	// Fields
	struct TArray<struct FModularSynthPresetBankEntry> Presets; // Offset: 0x28 | Size: 0x10
};

// Object: Class Synthesis.ModularSynthLibrary
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UModularSynthLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object: Function Synthesis.ModularSynthLibrary.AddModularSynthPresetToBankAsset
	// Flags: [Final|Native|Static|Private|HasOutParms|BlueprintCallable]
	// Offset: 0x1022a77ec
	// Return & Params: [ Num(3) Size(0xe8) ]
	void AddModularSynthPresetToBankAsset(struct UModularSynthPresetBank* InBank, struct FModularSynthPreset& Preset, struct FString PresetName);
};

// Object: Class Synthesis.ModularSynthComponent
// Inherited Bytes: 0x820 | Struct Size: 0xea0
struct UModularSynthComponent : USynthComponent {
	// Fields
	int32_t VoiceCount; // Offset: 0x820 | Size: 0x4
	char pad_0x824[0x67c]; // Offset: 0x824 | Size: 0x67c

	// Functions

	// Object: Function Synthesis.ModularSynthComponent.SetSynthPreset
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1022a7ebc
	// Return & Params: [ Num(1) Size(0xd0) ]
	void SetSynthPreset(struct FModularSynthPreset& SynthPreset);

	// Object: Function Synthesis.ModularSynthComponent.SetSustainGain
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a8e94
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetSustainGain(float SustainGain);

	// Object: Function Synthesis.ModularSynthComponent.SetStereoDelayWetlevel
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a82ec
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetStereoDelayWetlevel(float DelayWetlevel);

	// Object: Function Synthesis.ModularSynthComponent.SetStereoDelayTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a83ec
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetStereoDelayTime(float DelayTimeMsec);

	// Object: Function Synthesis.ModularSynthComponent.SetStereoDelayRatio
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a826c
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetStereoDelayRatio(float DelayRatio);

	// Object: Function Synthesis.ModularSynthComponent.SetStereoDelayMode
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a846c
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetStereoDelayMode(enum class ESynthStereoDelayMode StereoDelayMode);

	// Object: Function Synthesis.ModularSynthComponent.SetStereoDelayIsEnabled
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a84ec
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetStereoDelayIsEnabled(bool StereoDelayEnabled);

	// Object: Function Synthesis.ModularSynthComponent.SetStereoDelayFeedback
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a836c
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetStereoDelayFeedback(float DelayFeedback);

	// Object: Function Synthesis.ModularSynthComponent.SetSpread
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a9628
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetSpread(float Spread);

	// Object: Function Synthesis.ModularSynthComponent.SetReleaseTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a8e14
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetReleaseTime(float ReleaseTimeMsec);

	// Object: Function Synthesis.ModularSynthComponent.SetPortamento
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a9904
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetPortamento(float Portamento);

	// Object: Function Synthesis.ModularSynthComponent.SetPitchBend
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a9984
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetPitchBend(float PitchBend);

	// Object: Function Synthesis.ModularSynthComponent.SetPan
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a96a8
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetPan(float Pan);

	// Object: Function Synthesis.ModularSynthComponent.SetOscType
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a9c68
	// Return & Params: [ Num(2) Size(0x5) ]
	void SetOscType(int32_t OscIndex, enum class ESynth1OscType OscType);

	// Object: Function Synthesis.ModularSynthComponent.SetOscSync
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a9728
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetOscSync(bool bIsSynced);

	// Object: Function Synthesis.ModularSynthComponent.SetOscSemitones
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a9ad0
	// Return & Params: [ Num(2) Size(0x8) ]
	void SetOscSemitones(int32_t OscIndex, float Semitones);

	// Object: Function Synthesis.ModularSynthComponent.SetOscPulsewidth
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a9838
	// Return & Params: [ Num(2) Size(0x8) ]
	void SetOscPulsewidth(int32_t OscIndex, float Pulsewidth);

	// Object: Function Synthesis.ModularSynthComponent.SetOscOctave
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a9b9c
	// Return & Params: [ Num(2) Size(0x8) ]
	void SetOscOctave(int32_t OscIndex, float Octave);

	// Object: Function Synthesis.ModularSynthComponent.SetOscGainMod
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a9e00
	// Return & Params: [ Num(2) Size(0x8) ]
	void SetOscGainMod(int32_t OscIndex, float OscGainMod);

	// Object: Function Synthesis.ModularSynthComponent.SetOscGain
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a9ecc
	// Return & Params: [ Num(2) Size(0x8) ]
	void SetOscGain(int32_t OscIndex, float OscGain);

	// Object: Function Synthesis.ModularSynthComponent.SetOscFrequencyMod
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a9d34
	// Return & Params: [ Num(2) Size(0x8) ]
	void SetOscFrequencyMod(int32_t OscIndex, float OscFreqMod);

	// Object: Function Synthesis.ModularSynthComponent.SetOscCents
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a9a04
	// Return & Params: [ Num(2) Size(0x8) ]
	void SetOscCents(int32_t OscIndex, float Cents);

	// Object: Function Synthesis.ModularSynthComponent.SetModEnvSustainGain
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a8a04
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetModEnvSustainGain(float SustainGain);

	// Object: Function Synthesis.ModularSynthComponent.SetModEnvReleaseTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a8984
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetModEnvReleaseTime(float Release);

	// Object: Function Synthesis.ModularSynthComponent.SetModEnvPatch
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a8d94
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetModEnvPatch(enum class ESynthModEnvPatch InPatchType);

	// Object: Function Synthesis.ModularSynthComponent.SetModEnvInvert
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a8c8c
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetModEnvInvert(bool bInvert);

	// Object: Function Synthesis.ModularSynthComponent.SetModEnvDepth
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a8b84
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetModEnvDepth(float Depth);

	// Object: Function Synthesis.ModularSynthComponent.SetModEnvDecayTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a8a84
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetModEnvDecayTime(float DecayTimeMsec);

	// Object: Function Synthesis.ModularSynthComponent.SetModEnvBiasPatch
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a8d14
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetModEnvBiasPatch(enum class ESynthModEnvBiasPatch InPatchType);

	// Object: Function Synthesis.ModularSynthComponent.SetModEnvBiasInvert
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a8c04
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetModEnvBiasInvert(bool bInvert);

	// Object: Function Synthesis.ModularSynthComponent.SetModEnvAttackTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a8b04
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetModEnvAttackTime(float AttackTimeMsec);

	// Object: Function Synthesis.ModularSynthComponent.SetLFOType
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a922c
	// Return & Params: [ Num(2) Size(0x5) ]
	void SetLFOType(int32_t LFOIndex, enum class ESynthLFOType LFOType);

	// Object: Function Synthesis.ModularSynthComponent.SetLFOPatch
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a9094
	// Return & Params: [ Num(2) Size(0x5) ]
	void SetLFOPatch(int32_t LFOIndex, enum class ESynthLFOPatchType LFOPatchType);

	// Object: Function Synthesis.ModularSynthComponent.SetLFOMode
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a9160
	// Return & Params: [ Num(2) Size(0x5) ]
	void SetLFOMode(int32_t LFOIndex, enum class ESynthLFOMode LFOMode);

	// Object: Function Synthesis.ModularSynthComponent.SetLFOGainMod
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a92f8
	// Return & Params: [ Num(2) Size(0x8) ]
	void SetLFOGainMod(int32_t LFOIndex, float GainMod);

	// Object: Function Synthesis.ModularSynthComponent.SetLFOGain
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a93c4
	// Return & Params: [ Num(2) Size(0x8) ]
	void SetLFOGain(int32_t LFOIndex, float Gain);

	// Object: Function Synthesis.ModularSynthComponent.SetLFOFrequencyMod
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a9490
	// Return & Params: [ Num(2) Size(0x8) ]
	void SetLFOFrequencyMod(int32_t LFOIndex, float FrequencyModHz);

	// Object: Function Synthesis.ModularSynthComponent.SetLFOFrequency
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a955c
	// Return & Params: [ Num(2) Size(0x8) ]
	void SetLFOFrequency(int32_t LFOIndex, float FrequencyHz);

	// Object: Function Synthesis.ModularSynthComponent.SetGainDb
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a9014
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetGainDb(float GainDb);

	// Object: Function Synthesis.ModularSynthComponent.SetFilterType
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a85f4
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetFilterType(enum class ESynthFilterType FilterType);

	// Object: Function Synthesis.ModularSynthComponent.SetFilterQMod
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a8674
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetFilterQMod(float FilterQ);

	// Object: Function Synthesis.ModularSynthComponent.SetFilterQ
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a86f4
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetFilterQ(float FilterQ);

	// Object: Function Synthesis.ModularSynthComponent.SetFilterFrequencyMod
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a8774
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetFilterFrequencyMod(float FilterFrequencyHz);

	// Object: Function Synthesis.ModularSynthComponent.SetFilterFrequency
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a87f4
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetFilterFrequency(float FilterFrequencyHz);

	// Object: Function Synthesis.ModularSynthComponent.SetFilterAlgorithm
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a8574
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetFilterAlgorithm(enum class ESynthFilterAlgorithm FilterAlgorithm);

	// Object: Function Synthesis.ModularSynthComponent.SetEnableUnison
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a97b0
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetEnableUnison(bool EnableUnison);

	// Object: Function Synthesis.ModularSynthComponent.SetEnableRetrigger
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a8874
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetEnableRetrigger(bool RetriggerEnabled);

	// Object: Function Synthesis.ModularSynthComponent.SetEnablePolyphony
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a9f98
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetEnablePolyphony(bool bEnablePolyphony);

	// Object: Function Synthesis.ModularSynthComponent.SetEnablePatch
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a7c98
	// Return & Params: [ Num(3) Size(0x6) ]
	bool SetEnablePatch(struct FPatchId PatchId, bool bIsEnabled);

	// Object: Function Synthesis.ModularSynthComponent.SetEnableLegato
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a88fc
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetEnableLegato(bool LegatoEnabled);

	// Object: Function Synthesis.ModularSynthComponent.SetDecayTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a8f14
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetDecayTime(float DecayTimeMsec);

	// Object: Function Synthesis.ModularSynthComponent.SetChorusFrequency
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a8064
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetChorusFrequency(float Frequency);

	// Object: Function Synthesis.ModularSynthComponent.SetChorusFeedback
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a80e4
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetChorusFeedback(float Feedback);

	// Object: Function Synthesis.ModularSynthComponent.SetChorusEnabled
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a81e4
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetChorusEnabled(bool EnableChorus);

	// Object: Function Synthesis.ModularSynthComponent.SetChorusDepth
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a8164
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetChorusDepth(float Depth);

	// Object: Function Synthesis.ModularSynthComponent.SetAttackTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022a8f94
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetAttackTime(float AttackTimeMsec);

	// Object: Function Synthesis.ModularSynthComponent.NoteOn
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022aa154
	// Return & Params: [ Num(3) Size(0xc) ]
	void NoteOn(float Note, int32_t Velocity, float Duration);

	// Object: Function Synthesis.ModularSynthComponent.NoteOff
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022aa020
	// Return & Params: [ Num(3) Size(0x6) ]
	void NoteOff(float Note, bool bAllNotesOff, bool bKillAllNotes);

	// Object: Function Synthesis.ModularSynthComponent.CreatePatch
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1022a7d7c
	// Return & Params: [ Num(4) Size(0x20) ]
	struct FPatchId CreatePatch(enum class ESynth1PatchSource PatchSource, struct TArray<struct FSynth1PatchCable>& PatchCables, bool bEnableByDefault);
};

// Object: Class Synthesis.SourceEffectBitCrusherPreset
// Inherited Bytes: 0x40 | Struct Size: 0x90
struct USourceEffectBitCrusherPreset : USoundEffectSourcePreset {
	// Fields
	char pad_0x40[0x48]; // Offset: 0x40 | Size: 0x48
	struct FSourceEffectBitCrusherSettings Settings; // Offset: 0x88 | Size: 0x8

	// Functions

	// Object: Function Synthesis.SourceEffectBitCrusherPreset.SetSettings
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1022ad4cc
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetSettings(struct FSourceEffectBitCrusherSettings& InSettings);
};

// Object: Class Synthesis.SourceEffectChorusPreset
// Inherited Bytes: 0x40 | Struct Size: 0xb0
struct USourceEffectChorusPreset : USoundEffectSourcePreset {
	// Fields
	char pad_0x40[0x58]; // Offset: 0x40 | Size: 0x58
	struct FSourceEffectChorusSettings Settings; // Offset: 0x98 | Size: 0x18

	// Functions

	// Object: Function Synthesis.SourceEffectChorusPreset.SetSettings
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1022ad8ec
	// Return & Params: [ Num(1) Size(0x18) ]
	void SetSettings(struct FSourceEffectChorusSettings& InSettings);
};

// Object: Class Synthesis.SourceEffectDynamicsProcessorPreset
// Inherited Bytes: 0x40 | Struct Size: 0xd0
struct USourceEffectDynamicsProcessorPreset : USoundEffectSourcePreset {
	// Fields
	char pad_0x40[0x68]; // Offset: 0x40 | Size: 0x68
	struct FSourceEffectDynamicsProcessorSettings Settings; // Offset: 0xa8 | Size: 0x28

	// Functions

	// Object: Function Synthesis.SourceEffectDynamicsProcessorPreset.SetSettings
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1022ade80
	// Return & Params: [ Num(1) Size(0x28) ]
	void SetSettings(struct FSourceEffectDynamicsProcessorSettings& InSettings);
};

// Object: Class Synthesis.EnvelopeFollowerListener
// Inherited Bytes: 0xb0 | Struct Size: 0xd0
struct UEnvelopeFollowerListener : UActorComponent {
	// Fields
	struct FMulticastInlineDelegate OnEnvelopeFollowerUpdate; // Offset: 0xb0 | Size: 0x10
	char pad_0xC0[0x10]; // Offset: 0xc0 | Size: 0x10
};

// Object: Class Synthesis.SourceEffectEnvelopeFollowerPreset
// Inherited Bytes: 0x40 | Struct Size: 0x98
struct USourceEffectEnvelopeFollowerPreset : USoundEffectSourcePreset {
	// Fields
	char pad_0x40[0x4c]; // Offset: 0x40 | Size: 0x4c
	struct FSourceEffectEnvelopeFollowerSettings Settings; // Offset: 0x8c | Size: 0xc

	// Functions

	// Object: Function Synthesis.SourceEffectEnvelopeFollowerPreset.UnregisterEnvelopeFollowerListener
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022ae600
	// Return & Params: [ Num(1) Size(0x8) ]
	void UnregisterEnvelopeFollowerListener(struct UEnvelopeFollowerListener* EnvelopeFollowerListener);

	// Object: Function Synthesis.SourceEffectEnvelopeFollowerPreset.SetSettings
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1022ae700
	// Return & Params: [ Num(1) Size(0xc) ]
	void SetSettings(struct FSourceEffectEnvelopeFollowerSettings& InSettings);

	// Object: Function Synthesis.SourceEffectEnvelopeFollowerPreset.RegisterEnvelopeFollowerListener
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022ae680
	// Return & Params: [ Num(1) Size(0x8) ]
	void RegisterEnvelopeFollowerListener(struct UEnvelopeFollowerListener* EnvelopeFollowerListener);
};

// Object: Class Synthesis.SourceEffectEQPreset
// Inherited Bytes: 0x40 | Struct Size: 0xa0
struct USourceEffectEQPreset : USoundEffectSourcePreset {
	// Fields
	char pad_0x40[0x50]; // Offset: 0x40 | Size: 0x50
	struct FSourceEffectEQSettings Settings; // Offset: 0x90 | Size: 0x10

	// Functions

	// Object: Function Synthesis.SourceEffectEQPreset.SetSettings
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1022aecb4
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetSettings(struct FSourceEffectEQSettings& InSettings);
};

// Object: Class Synthesis.SourceEffectFilterPreset
// Inherited Bytes: 0x40 | Struct Size: 0x98
struct USourceEffectFilterPreset : USoundEffectSourcePreset {
	// Fields
	char pad_0x40[0x4c]; // Offset: 0x40 | Size: 0x4c
	struct FSourceEffectFilterSettings Settings; // Offset: 0x8c | Size: 0xc

	// Functions

	// Object: Function Synthesis.SourceEffectFilterPreset.SetSettings
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1022af208
	// Return & Params: [ Num(1) Size(0xc) ]
	void SetSettings(struct FSourceEffectFilterSettings& InSettings);
};

// Object: Class Synthesis.SourceEffectFoldbackDistortionPreset
// Inherited Bytes: 0x40 | Struct Size: 0x98
struct USourceEffectFoldbackDistortionPreset : USoundEffectSourcePreset {
	// Fields
	char pad_0x40[0x4c]; // Offset: 0x40 | Size: 0x4c
	struct FSourceEffectFoldbackDistortionSettings Settings; // Offset: 0x8c | Size: 0xc

	// Functions

	// Object: Function Synthesis.SourceEffectFoldbackDistortionPreset.SetSettings
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1022af63c
	// Return & Params: [ Num(1) Size(0xc) ]
	void SetSettings(struct FSourceEffectFoldbackDistortionSettings& InSettings);
};

// Object: Class Synthesis.SourceEffectMidSideSpreaderPreset
// Inherited Bytes: 0x40 | Struct Size: 0x98
struct USourceEffectMidSideSpreaderPreset : USoundEffectSourcePreset {
	// Fields
	char pad_0x40[0x4c]; // Offset: 0x40 | Size: 0x4c
	struct FSourceEffectMidSideSpreaderSettings Settings; // Offset: 0x8c | Size: 0xc

	// Functions

	// Object: Function Synthesis.SourceEffectMidSideSpreaderPreset.SetSettings
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1022afb14
	// Return & Params: [ Num(1) Size(0xc) ]
	void SetSettings(struct FSourceEffectMidSideSpreaderSettings& InSettings);
};

// Object: Class Synthesis.SourceEffectPannerPreset
// Inherited Bytes: 0x40 | Struct Size: 0x90
struct USourceEffectPannerPreset : USoundEffectSourcePreset {
	// Fields
	char pad_0x40[0x48]; // Offset: 0x40 | Size: 0x48
	struct FSourceEffectPannerSettings Settings; // Offset: 0x88 | Size: 0x8

	// Functions

	// Object: Function Synthesis.SourceEffectPannerPreset.SetSettings
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1022aff4c
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetSettings(struct FSourceEffectPannerSettings& InSettings);
};

// Object: Class Synthesis.SourceEffectPhaserPreset
// Inherited Bytes: 0x40 | Struct Size: 0xa0
struct USourceEffectPhaserPreset : USoundEffectSourcePreset {
	// Fields
	char pad_0x40[0x50]; // Offset: 0x40 | Size: 0x50
	struct FSourceEffectPhaserSettings Settings; // Offset: 0x90 | Size: 0x10

	// Functions

	// Object: Function Synthesis.SourceEffectPhaserPreset.SetSettings
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1022b0410
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetSettings(struct FSourceEffectPhaserSettings& InSettings);
};

// Object: Class Synthesis.SourceEffectRingModulationPreset
// Inherited Bytes: 0x40 | Struct Size: 0xa8
struct USourceEffectRingModulationPreset : USoundEffectSourcePreset {
	// Fields
	char pad_0x40[0x54]; // Offset: 0x40 | Size: 0x54
	struct FSourceEffectRingModulationSettings Settings; // Offset: 0x94 | Size: 0x14

	// Functions

	// Object: Function Synthesis.SourceEffectRingModulationPreset.SetSettings
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1022b08f4
	// Return & Params: [ Num(1) Size(0x14) ]
	void SetSettings(struct FSourceEffectRingModulationSettings& InSettings);
};

// Object: Class Synthesis.SourceEffectSimpleDelayPreset
// Inherited Bytes: 0x40 | Struct Size: 0xb0
struct USourceEffectSimpleDelayPreset : USoundEffectSourcePreset {
	// Fields
	char pad_0x40[0x58]; // Offset: 0x40 | Size: 0x58
	struct FSourceEffectSimpleDelaySettings Settings; // Offset: 0x98 | Size: 0x18

	// Functions

	// Object: Function Synthesis.SourceEffectSimpleDelayPreset.SetSettings
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1022b0d30
	// Return & Params: [ Num(1) Size(0x18) ]
	void SetSettings(struct FSourceEffectSimpleDelaySettings& InSettings);
};

// Object: Class Synthesis.SourceEffectStereoDelayPreset
// Inherited Bytes: 0x40 | Struct Size: 0xa8
struct USourceEffectStereoDelayPreset : USoundEffectSourcePreset {
	// Fields
	char pad_0x40[0x54]; // Offset: 0x40 | Size: 0x54
	struct FSourceEffectStereoDelaySettings Settings; // Offset: 0x94 | Size: 0x14

	// Functions

	// Object: Function Synthesis.SourceEffectStereoDelayPreset.SetSettings
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1022b1218
	// Return & Params: [ Num(1) Size(0x14) ]
	void SetSettings(struct FSourceEffectStereoDelaySettings& InSettings);
};

// Object: Class Synthesis.SourceEffectWaveShaperPreset
// Inherited Bytes: 0x40 | Struct Size: 0x90
struct USourceEffectWaveShaperPreset : USoundEffectSourcePreset {
	// Fields
	char pad_0x40[0x48]; // Offset: 0x40 | Size: 0x48
	struct FSourceEffectWaveShaperSettings Settings; // Offset: 0x88 | Size: 0x8

	// Functions

	// Object: Function Synthesis.SourceEffectWaveShaperPreset.SetSettings
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1022b164c
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetSettings(struct FSourceEffectWaveShaperSettings& InSettings);
};

// Object: Class Synthesis.AudioImpulseResponse
// Inherited Bytes: 0x28 | Struct Size: 0x58
struct UAudioImpulseResponse : UObject {
	// Fields
	struct TArray<float> ImpulseResponse; // Offset: 0x28 | Size: 0x10
	int32_t NumChannels; // Offset: 0x38 | Size: 0x4
	int32_t SampleRate; // Offset: 0x3c | Size: 0x4
	float NormalizationVolumeDb; // Offset: 0x40 | Size: 0x4
	char pad_0x44[0x4]; // Offset: 0x44 | Size: 0x4
	struct TArray<float> IRData; // Offset: 0x48 | Size: 0x10
};

// Object: Class Synthesis.SubmixEffectConvolutionReverbPreset
// Inherited Bytes: 0x40 | Struct Size: 0xd0
struct USubmixEffectConvolutionReverbPreset : USoundEffectSubmixPreset {
	// Fields
	struct FSubmixEffectConvolutionReverbSettings Settings; // Offset: 0x40 | Size: 0x20
	struct UAudioImpulseResponse* ImpulseResponse; // Offset: 0x60 | Size: 0x8
	enum class ESubmixEffectConvolutionReverbBlockSize BlockSize; // Offset: 0x68 | Size: 0x1
	bool bEnableHardwareAcceleration; // Offset: 0x69 | Size: 0x1
	char pad_0x6A[0x66]; // Offset: 0x6a | Size: 0x66

	// Functions

	// Object: Function Synthesis.SubmixEffectConvolutionReverbPreset.SetSettings
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1022b1d70
	// Return & Params: [ Num(1) Size(0x20) ]
	void SetSettings(struct FSubmixEffectConvolutionReverbSettings& InSettings);

	// Object: Function Synthesis.SubmixEffectConvolutionReverbPreset.SetImpulseResponse
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022b1cf0
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetImpulseResponse(struct UAudioImpulseResponse* InImpulseResponse);
};

// Object: Class Synthesis.SubmixEffectDelayPreset
// Inherited Bytes: 0x40 | Struct Size: 0xa8
struct USubmixEffectDelayPreset : USoundEffectSubmixPreset {
	// Fields
	char pad_0x40[0x4c]; // Offset: 0x40 | Size: 0x4c
	struct FSubmixEffectDelaySettings Settings; // Offset: 0x8c | Size: 0xc
	struct FSubmixEffectDelaySettings DynamicSettings; // Offset: 0x98 | Size: 0xc
	char pad_0xA4[0x4]; // Offset: 0xa4 | Size: 0x4

	// Functions

	// Object: Function Synthesis.SubmixEffectDelayPreset.SetSettings
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1022b917c
	// Return & Params: [ Num(1) Size(0xc) ]
	void SetSettings(struct FSubmixEffectDelaySettings& InSettings);

	// Object: Function Synthesis.SubmixEffectDelayPreset.SetInterpolationTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022b90e0
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetInterpolationTime(float Time);

	// Object: Function Synthesis.SubmixEffectDelayPreset.SetDelay
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022b9060
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetDelay(float Length);

	// Object: Function Synthesis.SubmixEffectDelayPreset.GetMaxDelayInMilliseconds
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022b9160
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetMaxDelayInMilliseconds();
};

// Object: Class Synthesis.SubmixEffectFilterPreset
// Inherited Bytes: 0x40 | Struct Size: 0x98
struct USubmixEffectFilterPreset : USoundEffectSubmixPreset {
	// Fields
	char pad_0x40[0x4c]; // Offset: 0x40 | Size: 0x4c
	struct FSubmixEffectFilterSettings Settings; // Offset: 0x8c | Size: 0xc

	// Functions

	// Object: Function Synthesis.SubmixEffectFilterPreset.SetSettings
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1022b9b8c
	// Return & Params: [ Num(1) Size(0xc) ]
	void SetSettings(struct FSubmixEffectFilterSettings& InSettings);

	// Object: Function Synthesis.SubmixEffectFilterPreset.SetFilterType
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022b9b0c
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetFilterType(enum class ESubmixFilterType InType);

	// Object: Function Synthesis.SubmixEffectFilterPreset.SetFilterQMod
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022b988c
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetFilterQMod(float InQ);

	// Object: Function Synthesis.SubmixEffectFilterPreset.SetFilterQ
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022b990c
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetFilterQ(float InQ);

	// Object: Function Synthesis.SubmixEffectFilterPreset.SetFilterCutoffFrequencyMod
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022b998c
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetFilterCutoffFrequencyMod(float InFrequency);

	// Object: Function Synthesis.SubmixEffectFilterPreset.SetFilterCutoffFrequency
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022b9a0c
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetFilterCutoffFrequency(float InFrequency);

	// Object: Function Synthesis.SubmixEffectFilterPreset.SetFilterAlgorithm
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022b9a8c
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetFilterAlgorithm(enum class ESubmixFilterAlgorithm InAlgorithm);
};

// Object: Class Synthesis.SubmixEffectFlexiverbPreset
// Inherited Bytes: 0x40 | Struct Size: 0xa0
struct USubmixEffectFlexiverbPreset : USoundEffectSubmixPreset {
	// Fields
	char pad_0x40[0x50]; // Offset: 0x40 | Size: 0x50
	struct FSubmixEffectFlexiverbSettings Settings; // Offset: 0x90 | Size: 0x10

	// Functions

	// Object: Function Synthesis.SubmixEffectFlexiverbPreset.SetSettings
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1022ba180
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetSettings(struct FSubmixEffectFlexiverbSettings& InSettings);
};

// Object: Class Synthesis.SubmixEffectTapDelayPreset
// Inherited Bytes: 0x40 | Struct Size: 0xc8
struct USubmixEffectTapDelayPreset : USoundEffectSubmixPreset {
	// Fields
	char pad_0x40[0x58]; // Offset: 0x40 | Size: 0x58
	struct FSubmixEffectTapDelaySettings Settings; // Offset: 0x98 | Size: 0x18
	char pad_0xB0[0x18]; // Offset: 0xb0 | Size: 0x18

	// Functions

	// Object: Function Synthesis.SubmixEffectTapDelayPreset.SetTap
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1022ba944
	// Return & Params: [ Num(2) Size(0x1c) ]
	void SetTap(int32_t TapId, struct FTapDelayInfo& TapInfo);

	// Object: Function Synthesis.SubmixEffectTapDelayPreset.SetSettings
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1022bab30
	// Return & Params: [ Num(1) Size(0x18) ]
	void SetSettings(struct FSubmixEffectTapDelaySettings& InSettings);

	// Object: Function Synthesis.SubmixEffectTapDelayPreset.SetInterpolationTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022ba730
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetInterpolationTime(float Time);

	// Object: Function Synthesis.SubmixEffectTapDelayPreset.RemoveTap
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022baa24
	// Return & Params: [ Num(1) Size(0x4) ]
	void RemoveTap(int32_t TapId);

	// Object: Function Synthesis.SubmixEffectTapDelayPreset.GetTapIds
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1022ba7cc
	// Return & Params: [ Num(1) Size(0x10) ]
	void GetTapIds(struct TArray<int32_t>& TapIds);

	// Object: Function Synthesis.SubmixEffectTapDelayPreset.GetTap
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1022ba864
	// Return & Params: [ Num(2) Size(0x1c) ]
	void GetTap(int32_t TapId, struct FTapDelayInfo& TapInfo);

	// Object: Function Synthesis.SubmixEffectTapDelayPreset.GetMaxDelayInMilliseconds
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022ba7b0
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetMaxDelayInMilliseconds();

	// Object: Function Synthesis.SubmixEffectTapDelayPreset.AddTap
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1022baaa4
	// Return & Params: [ Num(1) Size(0x4) ]
	void AddTap(int32_t& TapId);
};

// Object: Class Synthesis.Synth2DSlider
// Inherited Bytes: 0x138 | Struct Size: 0x670
struct USynth2DSlider : UWidget {
	// Fields
	float ValueX; // Offset: 0x138 | Size: 0x4
	float ValueY; // Offset: 0x13c | Size: 0x4
	struct FDelegate ValueXDelegate; // Offset: 0x140 | Size: 0x10
	struct FDelegate ValueYDelegate; // Offset: 0x150 | Size: 0x10
	struct FSynth2DSliderStyle WidgetStyle; // Offset: 0x160 | Size: 0x480
	struct FLinearColor SliderHandleColor; // Offset: 0x5e0 | Size: 0x10
	bool IndentHandle; // Offset: 0x5f0 | Size: 0x1
	bool Locked; // Offset: 0x5f1 | Size: 0x1
	char pad_0x5F2[0x2]; // Offset: 0x5f2 | Size: 0x2
	float StepSize; // Offset: 0x5f4 | Size: 0x4
	bool IsFocusable; // Offset: 0x5f8 | Size: 0x1
	char pad_0x5F9[0x7]; // Offset: 0x5f9 | Size: 0x7
	struct FMulticastInlineDelegate OnMouseCaptureBegin; // Offset: 0x600 | Size: 0x10
	struct FMulticastInlineDelegate OnMouseCaptureEnd; // Offset: 0x610 | Size: 0x10
	struct FMulticastInlineDelegate OnControllerCaptureBegin; // Offset: 0x620 | Size: 0x10
	struct FMulticastInlineDelegate OnControllerCaptureEnd; // Offset: 0x630 | Size: 0x10
	struct FMulticastInlineDelegate OnValueChangedX; // Offset: 0x640 | Size: 0x10
	struct FMulticastInlineDelegate OnValueChangedY; // Offset: 0x650 | Size: 0x10
	char pad_0x660[0x10]; // Offset: 0x660 | Size: 0x10

	// Functions

	// Object: Function Synthesis.Synth2DSlider.SetValue
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x1022bb4f8
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetValue(struct FVector2D InValue);

	// Object: Function Synthesis.Synth2DSlider.SetStepSize
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022bb368
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetStepSize(float InValue);

	// Object: Function Synthesis.Synth2DSlider.SetSliderHandleColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x1022bb2e8
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetSliderHandleColor(struct FLinearColor InValue);

	// Object: Function Synthesis.Synth2DSlider.SetLocked
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022bb3e8
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetLocked(bool InValue);

	// Object: Function Synthesis.Synth2DSlider.SetIndentHandle
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022bb470
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetIndentHandle(bool InValue);

	// Object: Function Synthesis.Synth2DSlider.GetValue
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022bb574
	// Return & Params: [ Num(1) Size(0x8) ]
	struct FVector2D GetValue();
};

// Object: Class Synthesis.GranularSynth
// Inherited Bytes: 0x820 | Struct Size: 0xbe0
struct UGranularSynth : USynthComponent {
	// Fields
	struct USoundWave* GranulatedSoundWave; // Offset: 0x820 | Size: 0x8
	char pad_0x828[0x3b8]; // Offset: 0x828 | Size: 0x3b8

	// Functions

	// Object: Function Synthesis.GranularSynth.SetSustainGain
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022bc548
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetSustainGain(float SustainGain);

	// Object: Function Synthesis.GranularSynth.SetSoundWave
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022bc6c8
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetSoundWave(struct USoundWave* InSoundWave);

	// Object: Function Synthesis.GranularSynth.SetScrubMode
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022bbd10
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetScrubMode(bool bScrubMode);

	// Object: Function Synthesis.GranularSynth.SetReleaseTimeMsec
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022bc4c8
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetReleaseTimeMsec(float ReleaseTimeMsec);

	// Object: Function Synthesis.GranularSynth.SetPlayheadTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022bbbfc
	// Return & Params: [ Num(3) Size(0x9) ]
	void SetPlayheadTime(float InPositionSec, float LerpTimeSec, enum class EGranularSynthSeekType SeekType);

	// Object: Function Synthesis.GranularSynth.SetPlaybackSpeed
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022bc0dc
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetPlaybackSpeed(float InPlayheadRate);

	// Object: Function Synthesis.GranularSynth.SetGrainVolume
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x1022bbf54
	// Return & Params: [ Num(2) Size(0xc) ]
	void SetGrainVolume(float BaseVolume, struct FVector2D VolumeRange);

	// Object: Function Synthesis.GranularSynth.SetGrainsPerSecond
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022bc25c
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetGrainsPerSecond(float InGrainsPerSecond);

	// Object: Function Synthesis.GranularSynth.SetGrainProbability
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022bc1dc
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetGrainProbability(float InGrainProbability);

	// Object: Function Synthesis.GranularSynth.SetGrainPitch
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x1022bc018
	// Return & Params: [ Num(2) Size(0xc) ]
	void SetGrainPitch(float BasePitch, struct FVector2D PitchRange);

	// Object: Function Synthesis.GranularSynth.SetGrainPan
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x1022bbe90
	// Return & Params: [ Num(2) Size(0xc) ]
	void SetGrainPan(float BasePan, struct FVector2D PanRange);

	// Object: Function Synthesis.GranularSynth.SetGrainEnvelopeType
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022bc15c
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetGrainEnvelopeType(enum class EGranularSynthEnvelopeType EnvelopeType);

	// Object: Function Synthesis.GranularSynth.SetGrainDuration
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x1022bbdcc
	// Return & Params: [ Num(2) Size(0xc) ]
	void SetGrainDuration(float BaseDurationMsec, struct FVector2D DurationRange);

	// Object: Function Synthesis.GranularSynth.SetDecayTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022bc5c8
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetDecayTime(float DecayTimeMsec);

	// Object: Function Synthesis.GranularSynth.SetAttackTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022bc648
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetAttackTime(float AttackTimeMsec);

	// Object: Function Synthesis.GranularSynth.NoteOn
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022bc3b0
	// Return & Params: [ Num(3) Size(0xc) ]
	void NoteOn(float Note, int32_t Velocity, float Duration);

	// Object: Function Synthesis.GranularSynth.NoteOff
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022bc2dc
	// Return & Params: [ Num(2) Size(0x5) ]
	void NoteOff(float Note, bool bKill);

	// Object: Function Synthesis.GranularSynth.IsLoaded
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022bbb94
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsLoaded();

	// Object: Function Synthesis.GranularSynth.GetSampleDuration
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022bbd98
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetSampleDuration();

	// Object: Function Synthesis.GranularSynth.GetCurrentPlayheadTime
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022bbbc8
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetCurrentPlayheadTime();
};

// Object: Class Synthesis.MonoWaveTableSynthPreset
// Inherited Bytes: 0x28 | Struct Size: 0x170
struct UMonoWaveTableSynthPreset : UObject {
	// Fields
	struct FString PresetName; // Offset: 0x28 | Size: 0x10
	char bLockKeyframesToGridBool : 1; // Offset: 0x38 | Size: 0x1
	char pad_0x38_1 : 7; // Offset: 0x38 | Size: 0x1
	char pad_0x39[0x3]; // Offset: 0x39 | Size: 0x3
	int32_t LockKeyframesToGrid; // Offset: 0x3c | Size: 0x4
	int32_t WaveTableResolution; // Offset: 0x40 | Size: 0x4
	char pad_0x44[0x4]; // Offset: 0x44 | Size: 0x4
	struct TArray<struct FRuntimeFloatCurve> WaveTable; // Offset: 0x48 | Size: 0x10
	char bNormalizeWaveTables : 1; // Offset: 0x58 | Size: 0x1
	char pad_0x58_1 : 7; // Offset: 0x58 | Size: 0x1
	char pad_0x59[0x117]; // Offset: 0x59 | Size: 0x117
};

// Object: Class Synthesis.SynthComponentMonoWaveTable
// Inherited Bytes: 0x820 | Struct Size: 0xf40
struct USynthComponentMonoWaveTable : USynthComponent {
	// Fields
	struct FMulticastInlineDelegate OnTableAltered; // Offset: 0x820 | Size: 0x10
	struct FMulticastInlineDelegate OnNumTablesChanged; // Offset: 0x830 | Size: 0x10
	struct UMonoWaveTableSynthPreset* CurrentPreset; // Offset: 0x840 | Size: 0x8
	char pad_0x848[0x6f8]; // Offset: 0x848 | Size: 0x6f8

	// Functions

	// Object: Function Synthesis.SynthComponentMonoWaveTable.SetWaveTablePosition
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022be610
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetWaveTablePosition(float InPosition);

	// Object: Function Synthesis.SynthComponentMonoWaveTable.SetSustainPedalState
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022be810
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetSustainPedalState(bool InSustainPedalState);

	// Object: Function Synthesis.SynthComponentMonoWaveTable.SetPosLfoType
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022be3fc
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetPosLfoType(enum class ESynthLFOType InLfoType);

	// Object: Function Synthesis.SynthComponentMonoWaveTable.SetPosLfoFrequency
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022be4fc
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetPosLfoFrequency(float InLfoFrequency);

	// Object: Function Synthesis.SynthComponentMonoWaveTable.SetPosLfoDepth
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022be47c
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetPosLfoDepth(float InLfoDepth);

	// Object: Function Synthesis.SynthComponentMonoWaveTable.SetPositionEnvelopeSustainGain
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022bd95c
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetPositionEnvelopeSustainGain(float InSustainGain);

	// Object: Function Synthesis.SynthComponentMonoWaveTable.SetPositionEnvelopeReleaseTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022bd8dc
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetPositionEnvelopeReleaseTime(float InReleaseTimeMsec);

	// Object: Function Synthesis.SynthComponentMonoWaveTable.SetPositionEnvelopeInvert
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022bd854
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetPositionEnvelopeInvert(bool bInInvert);

	// Object: Function Synthesis.SynthComponentMonoWaveTable.SetPositionEnvelopeDepth
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022bd74c
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetPositionEnvelopeDepth(float InDepth);

	// Object: Function Synthesis.SynthComponentMonoWaveTable.SetPositionEnvelopeDecayTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022bd9dc
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetPositionEnvelopeDecayTime(float InDecayTimeMsec);

	// Object: Function Synthesis.SynthComponentMonoWaveTable.SetPositionEnvelopeBiasInvert
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022bd7cc
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetPositionEnvelopeBiasInvert(bool bInBiasInvert);

	// Object: Function Synthesis.SynthComponentMonoWaveTable.SetPositionEnvelopeBiasDepth
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022bd6cc
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetPositionEnvelopeBiasDepth(float InDepth);

	// Object: Function Synthesis.SynthComponentMonoWaveTable.SetPositionEnvelopeAttackTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022bda5c
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetPositionEnvelopeAttackTime(float InAttackTimeMsec);

	// Object: Function Synthesis.SynthComponentMonoWaveTable.SetLowPassFilterResonance
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022be2fc
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetLowPassFilterResonance(float InNewQ);

	// Object: Function Synthesis.SynthComponentMonoWaveTable.SetLowPassFilterFrequency
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022be37c
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetLowPassFilterFrequency(float InNewFrequency);

	// Object: Function Synthesis.SynthComponentMonoWaveTable.SetFrequencyWithMidiNote
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022be690
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetFrequencyWithMidiNote(float InMidiNote);

	// Object: Function Synthesis.SynthComponentMonoWaveTable.SetFrequencyPitchBend
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022be710
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetFrequencyPitchBend(float FrequencyOffsetCents);

	// Object: Function Synthesis.SynthComponentMonoWaveTable.SetFrequency
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022be790
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetFrequency(float FrequencyHz);

	// Object: Function Synthesis.SynthComponentMonoWaveTable.SetFilterEnvelopeSustainGain
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022bdd6c
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetFilterEnvelopeSustainGain(float InSustainGain);

	// Object: Function Synthesis.SynthComponentMonoWaveTable.SetFilterEnvelopeReleaseTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022bdcec
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetFilterEnvelopeReleaseTime(float InReleaseTimeMsec);

	// Object: Function Synthesis.SynthComponentMonoWaveTable.SetFilterEnvelopenDecayTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022bddec
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetFilterEnvelopenDecayTime(float InDecayTimeMsec);

	// Object: Function Synthesis.SynthComponentMonoWaveTable.SetFilterEnvelopeInvert
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022bdc64
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetFilterEnvelopeInvert(bool bInInvert);

	// Object: Function Synthesis.SynthComponentMonoWaveTable.SetFilterEnvelopeDepth
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022bdb5c
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetFilterEnvelopeDepth(float InDepth);

	// Object: Function Synthesis.SynthComponentMonoWaveTable.SetFilterEnvelopeBiasInvert
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022bdbdc
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetFilterEnvelopeBiasInvert(bool bInBiasInvert);

	// Object: Function Synthesis.SynthComponentMonoWaveTable.SetFilterEnvelopeBiasDepth
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022bdadc
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetFilterEnvelopeBiasDepth(float InDepth);

	// Object: Function Synthesis.SynthComponentMonoWaveTable.SetFilterEnvelopeAttackTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022bde6c
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetFilterEnvelopeAttackTime(float InAttackTimeMsec);

	// Object: Function Synthesis.SynthComponentMonoWaveTable.SetCurveValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022bd574
	// Return & Params: [ Num(4) Size(0xd) ]
	bool SetCurveValue(int32_t TableIndex, int32_t KeyframeIndex, float NewValue);

	// Object: Function Synthesis.SynthComponentMonoWaveTable.SetCurveTangent
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022bd3bc
	// Return & Params: [ Num(3) Size(0x9) ]
	bool SetCurveTangent(int32_t TableIndex, float InNewTangent);

	// Object: Function Synthesis.SynthComponentMonoWaveTable.SetCurveInterpolationType
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022bd498
	// Return & Params: [ Num(3) Size(0x9) ]
	bool SetCurveInterpolationType(enum class CurveInterpolationType InterpolationType, int32_t TableIndex);

	// Object: Function Synthesis.SynthComponentMonoWaveTable.SetAmpEnvelopeSustainGain
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022be17c
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetAmpEnvelopeSustainGain(float InSustainGain);

	// Object: Function Synthesis.SynthComponentMonoWaveTable.SetAmpEnvelopeReleaseTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022be0fc
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetAmpEnvelopeReleaseTime(float InReleaseTimeMsec);

	// Object: Function Synthesis.SynthComponentMonoWaveTable.SetAmpEnvelopeInvert
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022be074
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetAmpEnvelopeInvert(bool bInInvert);

	// Object: Function Synthesis.SynthComponentMonoWaveTable.SetAmpEnvelopeDepth
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022bdf6c
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetAmpEnvelopeDepth(float InDepth);

	// Object: Function Synthesis.SynthComponentMonoWaveTable.SetAmpEnvelopeDecayTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022be1fc
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetAmpEnvelopeDecayTime(float InDecayTimeMsec);

	// Object: Function Synthesis.SynthComponentMonoWaveTable.SetAmpEnvelopeBiasInvert
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022bdfec
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetAmpEnvelopeBiasInvert(bool bInBiasInvert);

	// Object: Function Synthesis.SynthComponentMonoWaveTable.SetAmpEnvelopeBiasDepth
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022bdeec
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetAmpEnvelopeBiasDepth(float InDepth);

	// Object: Function Synthesis.SynthComponentMonoWaveTable.SetAmpEnvelopeAttackTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022be27c
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetAmpEnvelopeAttackTime(float InAttackTimeMsec);

	// Object: Function Synthesis.SynthComponentMonoWaveTable.RefreshWaveTable
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022be590
	// Return & Params: [ Num(1) Size(0x4) ]
	void RefreshWaveTable(int32_t Index);

	// Object: Function Synthesis.SynthComponentMonoWaveTable.RefreshAllWaveTables
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022be57c
	// Return & Params: [ Num(0) Size(0x0) ]
	void RefreshAllWaveTables();

	// Object: Function Synthesis.SynthComponentMonoWaveTable.NoteOn
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022be918
	// Return & Params: [ Num(2) Size(0x8) ]
	void NoteOn(float InMidiNote, float InVelocity);

	// Object: Function Synthesis.SynthComponentMonoWaveTable.NoteOff
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022be898
	// Return & Params: [ Num(1) Size(0x4) ]
	void NoteOff(float InMidiNote);

	// Object: Function Synthesis.SynthComponentMonoWaveTable.GetNumTableEntries
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022be9e0
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetNumTableEntries();

	// Object: Function Synthesis.SynthComponentMonoWaveTable.GetMaxTableIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022bd698
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetMaxTableIndex();

	// Object: Function Synthesis.SynthComponentMonoWaveTable.GetKeyFrameValuesForTable
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022bd254
	// Return & Params: [ Num(2) Size(0x18) ]
	struct TArray<float> GetKeyFrameValuesForTable(float TableIndex);

	// Object: Function Synthesis.SynthComponentMonoWaveTable.GetCurveTangent
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022bd32c
	// Return & Params: [ Num(2) Size(0x8) ]
	float GetCurveTangent(int32_t TableIndex);
};

// Object: Class Synthesis.SynthSamplePlayer
// Inherited Bytes: 0x820 | Struct Size: 0x950
struct USynthSamplePlayer : USynthComponent {
	// Fields
	struct USoundWave* SoundWave; // Offset: 0x820 | Size: 0x8
	struct FMulticastInlineDelegate OnSampleLoaded; // Offset: 0x828 | Size: 0x10
	struct FMulticastInlineDelegate OnSamplePlaybackProgress; // Offset: 0x838 | Size: 0x10
	char pad_0x848[0x108]; // Offset: 0x848 | Size: 0x108

	// Functions

	// Object: Function Synthesis.SynthSamplePlayer.SetSoundWave
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022c1f6c
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetSoundWave(struct USoundWave* InSoundWave);

	// Object: Function Synthesis.SynthSamplePlayer.SetScrubTimeWidth
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022c1c7c
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetScrubTimeWidth(float InScrubTimeWidthSec);

	// Object: Function Synthesis.SynthSamplePlayer.SetScrubMode
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022c1cfc
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetScrubMode(bool bScrubMode);

	// Object: Function Synthesis.SynthSamplePlayer.SetPitch
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022c1ea4
	// Return & Params: [ Num(2) Size(0x8) ]
	void SetPitch(float InPitch, float TimeSec);

	// Object: Function Synthesis.SynthSamplePlayer.SeekToTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022c1d84
	// Return & Params: [ Num(3) Size(0x6) ]
	void SeekToTime(float TimeSec, enum class ESamplePlayerSeekType SeekType, bool bWrap);

	// Object: Function Synthesis.SynthSamplePlayer.IsLoaded
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022c1bac
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsLoaded();

	// Object: Function Synthesis.SynthSamplePlayer.GetSampleDuration
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022c1c48
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetSampleDuration();

	// Object: Function Synthesis.SynthSamplePlayer.GetCurrentPlaybackProgressTime
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022c1c14
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetCurrentPlaybackProgressTime();

	// Object: Function Synthesis.SynthSamplePlayer.GetCurrentPlaybackProgressPercent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022c1be0
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetCurrentPlaybackProgressPercent();
};

// Object: Class Synthesis.SynthKnob
// Inherited Bytes: 0x138 | Struct Size: 0x5a0
struct USynthKnob : UWidget {
	// Fields
	float Value; // Offset: 0x138 | Size: 0x4
	float StepSize; // Offset: 0x13c | Size: 0x4
	float MouseSpeed; // Offset: 0x140 | Size: 0x4
	float MouseFineTuneSpeed; // Offset: 0x144 | Size: 0x4
	char ShowTooltipInfo : 1; // Offset: 0x148 | Size: 0x1
	char pad_0x148_1 : 7; // Offset: 0x148 | Size: 0x1
	char pad_0x149[0x7]; // Offset: 0x149 | Size: 0x7
	struct FText ParameterName; // Offset: 0x150 | Size: 0x18
	struct FText ParameterUnits; // Offset: 0x168 | Size: 0x18
	struct FDelegate ValueDelegate; // Offset: 0x180 | Size: 0x10
	struct FSynthKnobStyle WidgetStyle; // Offset: 0x190 | Size: 0x3a0
	bool Locked; // Offset: 0x530 | Size: 0x1
	bool IsFocusable; // Offset: 0x531 | Size: 0x1
	char pad_0x532[0x6]; // Offset: 0x532 | Size: 0x6
	struct FMulticastInlineDelegate OnMouseCaptureBegin; // Offset: 0x538 | Size: 0x10
	struct FMulticastInlineDelegate OnMouseCaptureEnd; // Offset: 0x548 | Size: 0x10
	struct FMulticastInlineDelegate OnControllerCaptureBegin; // Offset: 0x558 | Size: 0x10
	struct FMulticastInlineDelegate OnControllerCaptureEnd; // Offset: 0x568 | Size: 0x10
	struct FMulticastInlineDelegate OnValueChanged; // Offset: 0x578 | Size: 0x10
	char pad_0x588[0x18]; // Offset: 0x588 | Size: 0x18

	// Functions

	// Object: Function Synthesis.SynthKnob.SetValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022c271c
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetValue(float InValue);

	// Object: Function Synthesis.SynthKnob.SetStepSize
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022c2614
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetStepSize(float InValue);

	// Object: Function Synthesis.SynthKnob.SetLocked
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022c2694
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetLocked(bool InValue);

	// Object: Function Synthesis.SynthKnob.GetValue
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022c279c
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetValue();
};

