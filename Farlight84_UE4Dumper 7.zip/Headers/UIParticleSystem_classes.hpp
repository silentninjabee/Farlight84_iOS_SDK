#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class UIParticleSystem.ParticleSystemWidget
// Inherited Bytes: 0x138 | Struct Size: 0x168
struct UParticleSystemWidget : UWidget {
	// Fields
	struct UParticleSystem* ParticleSystemTemplate; // Offset: 0x138 | Size: 0x8
	bool bReactivate; // Offset: 0x140 | Size: 0x1
	bool bActiveSysWhenInit; // Offset: 0x141 | Size: 0x1
	char pad_0x142[0x6]; // Offset: 0x142 | Size: 0x6
	struct UParticleSystemComponent* WorldParticleComponent; // Offset: 0x148 | Size: 0x8
	struct AActor* WorldParticleActor; // Offset: 0x150 | Size: 0x8
	char pad_0x158[0x10]; // Offset: 0x158 | Size: 0x10

	// Functions

	// Object: Function UIParticleSystem.ParticleSystemWidget.SetReactivate
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1012aec60
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetReactivate(bool bActivateAndReset);

	// Object: Function UIParticleSystem.ParticleSystemWidget.ActivateParticles
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1012aece8
	// Return & Params: [ Num(2) Size(0x2) ]
	void ActivateParticles(bool bActive, bool bReset);
};

// Object: Class UIParticleSystem.UIParticleComponent
// Inherited Bytes: 0x820 | Struct Size: 0x820
struct UUIParticleComponent : UParticleSystemComponent {
};

// Object: Class UIParticleSystem.UIParticleActor
// Inherited Bytes: 0x228 | Struct Size: 0x228
struct AUIParticleActor : AActor {
};

