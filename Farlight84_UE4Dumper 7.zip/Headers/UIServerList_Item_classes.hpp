#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UIServerList_Item.UIServerList_Item_C
// Inherited Bytes: 0x490 | Struct Size: 0x4b0
struct UUIServerList_Item_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x490 | Size: 0x8
	struct UButton* Btn_Selected; // Offset: 0x498 | Size: 0x8
	struct UImage* Img_Selected; // Offset: 0x4a0 | Size: 0x8
	struct USolarTextBlock* Txt_ServerName; // Offset: 0x4a8 | Size: 0x8

	// Functions

	// Object: Function UIServerList_Item.UIServerList_Item_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();

	// Object: Function UIServerList_Item.UIServerList_Item_C.BP_OnEntryReleased
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(0) Size(0x0) ]
	void BP_OnEntryReleased();

	// Object: Function UIServerList_Item.UIServerList_Item_C.BP_OnItemExpansionChanged
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x1) ]
	void BP_OnItemExpansionChanged(bool bIsExpanded);

	// Object: Function UIServerList_Item.UIServerList_Item_C.BP_OnItemSelectionChanged
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x1) ]
	void BP_OnItemSelectionChanged(bool bIsSelected);

	// Object: Function UIServerList_Item.UIServerList_Item_C.OnListItemObjectSet
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x8) ]
	void OnListItemObjectSet(struct UObject* ListItemObject);

	// Object: Function UIServerList_Item.UIServerList_Item_C.ExecuteUbergraph_UIServerList_Item
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UIServerList_Item(int32_t EntryPoint);
};

