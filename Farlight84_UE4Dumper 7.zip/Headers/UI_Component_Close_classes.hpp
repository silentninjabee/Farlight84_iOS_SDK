#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Component_Close.UI_Component_Close_C
// Inherited Bytes: 0x490 | Struct Size: 0x4dc
struct UUI_Component_Close_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x490 | Size: 0x8
	struct USolarButton* Btn_Close; // Offset: 0x498 | Size: 0x8
	struct UImage* Img_Close_Nml; // Offset: 0x4a0 | Size: 0x8
	struct FMulticastInlineDelegate OnClicked; // Offset: 0x4a8 | Size: 0x10
	bool Black; // Offset: 0x4b8 | Size: 0x1
	char pad_0x4B9[0x7]; // Offset: 0x4b9 | Size: 0x7
	struct FMulticastInlineDelegate OnPressed; // Offset: 0x4c0 | Size: 0x10
	bool White; // Offset: 0x4d0 | Size: 0x1
	char pad_0x4D1[0x3]; // Offset: 0x4d1 | Size: 0x3
	struct FVector2D Icon_Size; // Offset: 0x4d4 | Size: 0x8

	// Functions

	// Object: Function UI_Component_Close.UI_Component_Close_C.ConstructCopy
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(0) Size(0x0) ]
	void ConstructCopy();

	// Object: Function UI_Component_Close.UI_Component_Close_C.Destruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x1015dc5d4
	// Return & Params: [ Num(0) Size(0x0) ]
	void Destruct();

	// Object: Function UI_Component_Close.UI_Component_Close_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();

	// Object: Function UI_Component_Close.UI_Component_Close_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_Component_Close.UI_Component_Close_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x1015dc5d4
	// Return & Params: [ Num(0) Size(0x0) ]
	void Construct();

	// Object: Function UI_Component_Close.UI_Component_Close_C.BndEvt__Btn_Close_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature
	// Flags: [BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(0) Size(0x0) ]
	void BndEvt__Btn_Close_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature();

	// Object: Function UI_Component_Close.UI_Component_Close_C.BndEvt__Btn_Close_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature
	// Flags: [BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(0) Size(0x0) ]
	void BndEvt__Btn_Close_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature();

	// Object: Function UI_Component_Close.UI_Component_Close_C.BndEvt__Btn_Close_K2Node_ComponentBoundEvent_2_OnButtonHoverEvent__DelegateSignature
	// Flags: [BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(0) Size(0x0) ]
	void BndEvt__Btn_Close_K2Node_ComponentBoundEvent_2_OnButtonHoverEvent__DelegateSignature();

	// Object: Function UI_Component_Close.UI_Component_Close_C.BndEvt__Btn_Close_K2Node_ComponentBoundEvent_3_OnButtonPressedEvent__DelegateSignature
	// Flags: [BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(0) Size(0x0) ]
	void BndEvt__Btn_Close_K2Node_ComponentBoundEvent_3_OnButtonPressedEvent__DelegateSignature();

	// Object: Function UI_Component_Close.UI_Component_Close_C.ExecuteUbergraph_UI_Component_Close
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_Component_Close(int32_t EntryPoint);

	// Object: Function UI_Component_Close.UI_Component_Close_C.OnPressed__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnPressed__DelegateSignature();

	// Object: Function UI_Component_Close.UI_Component_Close_C.OnClicked__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked__DelegateSignature();
};

