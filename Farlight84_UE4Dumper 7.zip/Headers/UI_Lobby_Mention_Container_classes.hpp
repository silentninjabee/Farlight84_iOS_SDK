#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Lobby_Mention_Container.UI_Lobby_Mention_Container_C
// Inherited Bytes: 0x490 | Struct Size: 0x498
struct UUI_Lobby_Mention_Container_C : USolarUserWidget {
	// Fields
	struct UCanvasPanel* CanvasPanel_Container; // Offset: 0x490 | Size: 0x8

	// Functions

	// Object: Function UI_Lobby_Mention_Container.UI_Lobby_Mention_Container_C.OnSolarUIOpened
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x1015dc5d4
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnSolarUIOpened();

	// Object: Function UI_Lobby_Mention_Container.UI_Lobby_Mention_Container_C.OnSolarUIClosed
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x1015dc5d4
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnSolarUIClosed();

	// Object: Function UI_Lobby_Mention_Container.UI_Lobby_Mention_Container_C.OnInitialized
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x1015dc5d4
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnInitialized();

	// Object: Function UI_Lobby_Mention_Container.UI_Lobby_Mention_Container_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();
};

