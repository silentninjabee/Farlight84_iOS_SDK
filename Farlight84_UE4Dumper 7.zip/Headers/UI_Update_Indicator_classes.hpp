#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Update_Indicator.UI_Update_Indicator_C
// Inherited Bytes: 0x490 | Struct Size: 0x4b1
struct UUI_Update_Indicator_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x490 | Size: 0x8
	struct UWidgetAnimation* Anim_Enter; // Offset: 0x498 | Size: 0x8
	struct UImage* Img; // Offset: 0x4a0 | Size: 0x8
	struct UImage* Img_2; // Offset: 0x4a8 | Size: 0x8
	bool SelectType; // Offset: 0x4b0 | Size: 0x1

	// Functions

	// Object: Function UI_Update_Indicator.UI_Update_Indicator_C.BP_OnItemSelectionChangedCopy
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x1) ]
	void BP_OnItemSelectionChangedCopy(bool bIsSelected);

	// Object: Function UI_Update_Indicator.UI_Update_Indicator_C.ConstructCopy
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(0) Size(0x0) ]
	void ConstructCopy();

	// Object: Function UI_Update_Indicator.UI_Update_Indicator_C.OnListItemObjectSetCopy
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x8) ]
	void OnListItemObjectSetCopy(struct UObject* ListItemObject);

	// Object: Function UI_Update_Indicator.UI_Update_Indicator_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();

	// Object: Function UI_Update_Indicator.UI_Update_Indicator_C.BP_OnEntryReleased
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(0) Size(0x0) ]
	void BP_OnEntryReleased();

	// Object: Function UI_Update_Indicator.UI_Update_Indicator_C.BP_OnItemExpansionChanged
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x1) ]
	void BP_OnItemExpansionChanged(bool bIsExpanded);

	// Object: Function UI_Update_Indicator.UI_Update_Indicator_C.BP_OnItemSelectionChanged
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x1015dc5d4
	// Return & Params: [ Num(1) Size(0x1) ]
	void BP_OnItemSelectionChanged(bool bIsSelected);

	// Object: Function UI_Update_Indicator.UI_Update_Indicator_C.OnListItemObjectSet
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x1015dc5d4
	// Return & Params: [ Num(1) Size(0x8) ]
	void OnListItemObjectSet(struct UObject* ListItemObject);

	// Object: Function UI_Update_Indicator.UI_Update_Indicator_C.ChangeShowPanelView
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(0) Size(0x0) ]
	void ChangeShowPanelView();

	// Object: Function UI_Update_Indicator.UI_Update_Indicator_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x1015dc5d4
	// Return & Params: [ Num(0) Size(0x0) ]
	void Construct();

	// Object: Function UI_Update_Indicator.UI_Update_Indicator_C.ExecuteUbergraph_UI_Update_Indicator
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_Update_Indicator(int32_t EntryPoint);
};

