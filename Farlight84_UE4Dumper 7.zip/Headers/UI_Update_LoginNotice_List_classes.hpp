#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Update_LoginNotice_List.UI_Update_LoginNotice_List_C
// Inherited Bytes: 0x490 | Struct Size: 0x4c9
struct UUI_Update_LoginNotice_List_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x490 | Size: 0x8
	struct UWidgetAnimation* Anim_Page_Enter; // Offset: 0x498 | Size: 0x8
	struct UWidgetAnimation* Anim_Page_Exit; // Offset: 0x4a0 | Size: 0x8
	struct USolarImageURL* Img_Banner; // Offset: 0x4a8 | Size: 0x8
	struct UCanvasPanel* Panel_Banner; // Offset: 0x4b0 | Size: 0x8
	struct UScrollBox* ScrollBox_NoticeContent; // Offset: 0x4b8 | Size: 0x8
	struct USolarRichTextBlock* Txt_NoticeContent; // Offset: 0x4c0 | Size: 0x8
	enum class E_Update_LoginNotice Notice; // Offset: 0x4c8 | Size: 0x1

	// Functions

	// Object: Function UI_Update_LoginNotice_List.UI_Update_LoginNotice_List_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x1015dc5d4
	// Return & Params: [ Num(0) Size(0x0) ]
	void Construct();

	// Object: Function UI_Update_LoginNotice_List.UI_Update_LoginNotice_List_C.Destruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x1015dc5d4
	// Return & Params: [ Num(0) Size(0x0) ]
	void Destruct();

	// Object: Function UI_Update_LoginNotice_List.UI_Update_LoginNotice_List_C.OnListItemObjectSetCopy
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x8) ]
	void OnListItemObjectSetCopy(struct UObject* ListItemObject);

	// Object: Function UI_Update_LoginNotice_List.UI_Update_LoginNotice_List_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();

	// Object: Function UI_Update_LoginNotice_List.UI_Update_LoginNotice_List_C.SetNotice
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetNotice(enum class E_Update_LoginNotice Notice);

	// Object: Function UI_Update_LoginNotice_List.UI_Update_LoginNotice_List_C.BP_OnEntryReleased
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(0) Size(0x0) ]
	void BP_OnEntryReleased();

	// Object: Function UI_Update_LoginNotice_List.UI_Update_LoginNotice_List_C.BP_OnItemExpansionChanged
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x1) ]
	void BP_OnItemExpansionChanged(bool bIsExpanded);

	// Object: Function UI_Update_LoginNotice_List.UI_Update_LoginNotice_List_C.BP_OnItemSelectionChanged
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x1) ]
	void BP_OnItemSelectionChanged(bool bIsSelected);

	// Object: Function UI_Update_LoginNotice_List.UI_Update_LoginNotice_List_C.OnListItemObjectSet
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x1015dc5d4
	// Return & Params: [ Num(1) Size(0x8) ]
	void OnListItemObjectSet(struct UObject* ListItemObject);

	// Object: Function UI_Update_LoginNotice_List.UI_Update_LoginNotice_List_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_Update_LoginNotice_List.UI_Update_LoginNotice_List_C.BP_SetNoticeUI
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(0) Size(0x0) ]
	void BP_SetNoticeUI();

	// Object: Function UI_Update_LoginNotice_List.UI_Update_LoginNotice_List_C.ExecuteUbergraph_UI_Update_LoginNotice_List
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_Update_LoginNotice_List(int32_t EntryPoint);
};

