#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Update_LoginNotice.UI_Update_LoginNotice_C
// Inherited Bytes: 0x490 | Struct Size: 0x510
struct UUI_Update_LoginNotice_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x490 | Size: 0x8
	struct UWidgetAnimation* Anim_RightBtn_Press; // Offset: 0x498 | Size: 0x8
	struct UWidgetAnimation* Anim_LeftBtn_Press; // Offset: 0x4a0 | Size: 0x8
	struct UBackgroundBlur* BlurBG; // Offset: 0x4a8 | Size: 0x8
	struct USolarButton* Btn_ArrowLeft; // Offset: 0x4b0 | Size: 0x8
	struct USolarButton* Btn_ArrowRight; // Offset: 0x4b8 | Size: 0x8
	struct UUI_Component_Close_C* Btn_Close; // Offset: 0x4c0 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* DragPanel; // Offset: 0x4c8 | Size: 0x8
	struct USolarImageURL* Img_Banner; // Offset: 0x4d0 | Size: 0x8
	struct UImage* Img_Line; // Offset: 0x4d8 | Size: 0x8
	struct UImage* Img_Logo; // Offset: 0x4e0 | Size: 0x8
	struct USolarListView* List_Indicator; // Offset: 0x4e8 | Size: 0x8
	struct USolarListView* List_Notice; // Offset: 0x4f0 | Size: 0x8
	struct UCanvasPanel* Panel_Light; // Offset: 0x4f8 | Size: 0x8
	struct USizeBox* SizeBox_Notice; // Offset: 0x500 | Size: 0x8
	struct USolarTextBlock* Txt_NoticeTitle; // Offset: 0x508 | Size: 0x8

	// Functions

	// Object: Function UI_Update_LoginNotice.UI_Update_LoginNotice_C.OnSolarUIClosed
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x1015dc5d4
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnSolarUIClosed();

	// Object: Function UI_Update_LoginNotice.UI_Update_LoginNotice_C.OnSolarUIOpened
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x1015dc5d4
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnSolarUIOpened();

	// Object: Function UI_Update_LoginNotice.UI_Update_LoginNotice_C.OnMouseButtonDown
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x1015dc5d4
	// Return & Params: [ Num(3) Size(0x160) ]
	struct FEventReply OnMouseButtonDown(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent);

	// Object: Function UI_Update_LoginNotice.UI_Update_LoginNotice_C.OnMouseButtonUp
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x1015dc5d4
	// Return & Params: [ Num(3) Size(0x160) ]
	struct FEventReply OnMouseButtonUp(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent);

	// Object: Function UI_Update_LoginNotice.UI_Update_LoginNotice_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();

	// Object: Function UI_Update_LoginNotice.UI_Update_LoginNotice_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_Update_LoginNotice.UI_Update_LoginNotice_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(0) Size(0x0) ]
	void Construct();

	// Object: Function UI_Update_LoginNotice.UI_Update_LoginNotice_C.ReceiveShow
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(0) Size(0x0) ]
	void ReceiveShow();

	// Object: Function UI_Update_LoginNotice.UI_Update_LoginNotice_C.ReceiveHide
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(0) Size(0x0) ]
	void ReceiveHide();

	// Object: Function UI_Update_LoginNotice.UI_Update_LoginNotice_C.CustomEvent_1
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(0) Size(0x0) ]
	void CustomEvent_1();

	// Object: Function UI_Update_LoginNotice.UI_Update_LoginNotice_C.ExecuteUbergraph_UI_Update_LoginNotice
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_Update_LoginNotice(int32_t EntryPoint);
};

