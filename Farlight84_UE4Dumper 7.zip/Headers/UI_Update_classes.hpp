#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Update.UI_Update_C
// Inherited Bytes: 0x490 | Struct Size: 0x638
struct UUI_Update_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x490 | Size: 0x8
	struct UWidgetAnimation* Anim_Enter; // Offset: 0x498 | Size: 0x8
	struct UButton* Btn_AgeLimit; // Offset: 0x4a0 | Size: 0x8
	struct UButton* Btn_Fix; // Offset: 0x4a8 | Size: 0x8
	struct USolarButton* btn_link; // Offset: 0x4b0 | Size: 0x8
	struct USolarButton* btn_new; // Offset: 0x4b8 | Size: 0x8
	struct UButton* Btn_Notice; // Offset: 0x4c0 | Size: 0x8
	struct UCanvasPanel* CanvasPanel_2; // Offset: 0x4c8 | Size: 0x8
	struct UHorizontalBox* HorizontalBox; // Offset: 0x4d0 | Size: 0x8
	struct UHorizontalBox* HorizontalBox_1; // Offset: 0x4d8 | Size: 0x8
	struct UHorizontalBox* HorizontalBox_2; // Offset: 0x4e0 | Size: 0x8
	struct UHorizontalBox* HorizontalBox_Dot_1; // Offset: 0x4e8 | Size: 0x8
	struct UHorizontalBox* HorizontalBox_Dot_2; // Offset: 0x4f0 | Size: 0x8
	struct UImage* icon_link; // Offset: 0x4f8 | Size: 0x8
	struct UImage* Image_173; // Offset: 0x500 | Size: 0x8
	struct UImage* Img_Bg_Update; // Offset: 0x508 | Size: 0x8
	struct UImage* img_light_link; // Offset: 0x510 | Size: 0x8
	struct UImage* Img_Logo; // Offset: 0x518 | Size: 0x8
	struct UImage* Img_Mask; // Offset: 0x520 | Size: 0x8
	struct UCanvasPanel* Panel_Load; // Offset: 0x528 | Size: 0x8
	struct UProgressBar* ProgressBar_Download; // Offset: 0x530 | Size: 0x8
	struct UButton* StartGame; // Offset: 0x538 | Size: 0x8
	struct USolarTextBlock* StartGameText; // Offset: 0x540 | Size: 0x8
	struct USolarTextBlock* text_link; // Offset: 0x548 | Size: 0x8
	struct USolarTextBlock* text_new; // Offset: 0x550 | Size: 0x8
	struct USolarTextBlock* text_or; // Offset: 0x558 | Size: 0x8
	struct UTileView* TileView_ServerList; // Offset: 0x560 | Size: 0x8
	struct USolarTextBlock* Txt_Dot_2; // Offset: 0x568 | Size: 0x8
	struct USolarTextBlock* Txt_Dot_3; // Offset: 0x570 | Size: 0x8
	struct USolarTextBlock* Txt_Dot_4; // Offset: 0x578 | Size: 0x8
	struct USolarTextBlock* Txt_Dot_01; // Offset: 0x580 | Size: 0x8
	struct USolarTextBlock* Txt_Dot_02; // Offset: 0x588 | Size: 0x8
	struct USolarTextBlock* Txt_Dot_03; // Offset: 0x590 | Size: 0x8
	struct USolarTextBlock* Txt_GameInfo_CN; // Offset: 0x598 | Size: 0x8
	struct UTextBlock* Txt_LatestBuildNumber; // Offset: 0x5a0 | Size: 0x8
	struct USolarTextBlock* Txt_Loading_2; // Offset: 0x5a8 | Size: 0x8
	struct USolarTextBlock* Txt_PlayerName; // Offset: 0x5b0 | Size: 0x8
	struct UTextBlock* Txt_SourceBuildNumber; // Offset: 0x5b8 | Size: 0x8
	struct USolarTextBlock* Txt_Speed; // Offset: 0x5c0 | Size: 0x8
	struct USolarTextBlock* Txt_Tips_2; // Offset: 0x5c8 | Size: 0x8
	struct UUI_UpdateLoadingBase_C* UpdateLoadingBase; // Offset: 0x5d0 | Size: 0x8
	struct UWidgetSwitcher* wgs_start; // Offset: 0x5d8 | Size: 0x8
	struct UMediaPlayer* MediaPlayer; // Offset: 0x5e0 | Size: 0x8
	struct FSlateColor Color_hoverd; // Offset: 0x5e8 | Size: 0x28
	struct FSlateColor Color_default; // Offset: 0x610 | Size: 0x28

	// Functions

	// Object: DelegateFunction UI_Update.UI_Update_C.OnBackdoorFaild_CC6D04AEAB403863BB8FD98A3C8CF498
	// Flags: [Public|Delegate]
	// Offset: 0x1015c6968
	// Return & Params: [ Num(2) Size(0x8) ]
	void OnBackdoorFaild_CC6D04AEAB403863BB8FD98A3C8CF498(enum class EDownloadTaskError ErrorReason, int32_t ReturnCode);

	// Object: DelegateFunction UI_Update.UI_Update_C.OnBackdoorComplete_4A63CF0DB8457AEEDE6FF19ADBE7798A
	// Flags: [Public|Delegate]
	// Offset: 0x1015c6968
	// Return & Params: [ Num(1) Size(0x10) ]
	void OnBackdoorComplete_4A63CF0DB8457AEEDE6FF19ADBE7798A(struct FString BackdoorString);

	// Object: DelegateFunction UI_Update.UI_Update_C.OnCDNDownloadFailed_8F11B96E9C48447324C64CA8F9FA6B76
	// Flags: [Public|Delegate]
	// Offset: 0x1015c6968
	// Return & Params: [ Num(4) Size(0x30) ]
	void OnCDNDownloadFailed_8F11B96E9C48447324C64CA8F9FA6B76(int32_t ErrorStep, struct FString ErrorReason, int32_t ReturnCode, struct FString URL);

	// Object: DelegateFunction UI_Update.UI_Update_C.OnPatchFailed_5C021B32E745D3FB21121A9A02E38CDC
	// Flags: [Public|Delegate]
	// Offset: 0x1015c6968
	// Return & Params: [ Num(3) Size(0x18) ]
	void OnPatchFailed_5C021B32E745D3FB21121A9A02E38CDC(int32_t ErrorReason, int32_t ReturnCode, struct FString URL);

	// Object: DelegateFunction UI_Update.UI_Update_C.OnPatchComplete_10470A81A44619A7EFBEC2B798FBA62F
	// Flags: [Public|Delegate]
	// Offset: 0x1015c6968
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnPatchComplete_10470A81A44619A7EFBEC2B798FBA62F();

	// Object: DelegateFunction UI_Update.UI_Update_C.OnPatchPrompt_08BB2D0BA44C429613E2479A678BBF5D
	// Flags: [Public|Delegate]
	// Offset: 0x1015c6968
	// Return & Params: [ Num(2) Size(0x8) ]
	void OnPatchPrompt_08BB2D0BA44C429613E2479A678BBF5D(uint32_t DownloadSize, int32_t FileNum);

	// Object: DelegateFunction UI_Update.UI_Update_C.OnLoginFailed_76D52ED2BF48830EF7246393C9F8D5FC
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015c6968
	// Return & Params: [ Num(2) Size(0x8) ]
	void OnLoginFailed_76D52ED2BF48830EF7246393C9F8D5FC(enum class ELLHSDKLoginType LoginType, int32_t ErrorCode);

	// Object: DelegateFunction UI_Update.UI_Update_C.OnClicked_9FEB81DA1145858F9FA8439ACDAF1077
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015c6968
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_9FEB81DA1145858F9FA8439ACDAF1077();

	// Object: DelegateFunction UI_Update.UI_Update_C.OnClicked_A341A1642543B9CE59A8609D4ED760F9
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015c6968
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_A341A1642543B9CE59A8609D4ED760F9();

	// Object: DelegateFunction UI_Update.UI_Update_C.OnReleased_DE8EC51B064CE382C025E4964F37375D
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015c6968
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnReleased_DE8EC51B064CE382C025E4964F37375D();

	// Object: DelegateFunction UI_Update.UI_Update_C.OnAssetManagerPreloadCompleted_5D141D3FC04662DE3FF5CA81251BFBD4
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015c6968
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnAssetManagerPreloadCompleted_5D141D3FC04662DE3FF5CA81251BFBD4();

	// Object: DelegateFunction UI_Update.UI_Update_C.OnHandleLuaException_754B54836A473417F7A12888A7EC5CE1
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015c6968
	// Return & Params: [ Num(2) Size(0x20) ]
	void OnHandleLuaException_754B54836A473417F7A12888A7EC5CE1(struct FString ErrorMsg, struct FString StaceTrace);

	// Object: Function UI_Update.UI_Update_C.ConnectGateExecCopy
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(0) Size(0x0) ]
	void ConnectGateExecCopy();

	// Object: Function UI_Update.UI_Update_C.ReceiveTick
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x1015dc5d4
	// Return & Params: [ Num(2) Size(0x3c) ]
	void ReceiveTick(struct FGeometry& MyGeometry, float InDeltaTime);

	// Object: Function UI_Update.UI_Update_C.OnSolarUIClosed
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x1015dc5d4
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnSolarUIClosed();

	// Object: Function UI_Update.UI_Update_C.Destruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x1015dc5d4
	// Return & Params: [ Num(0) Size(0x0) ]
	void Destruct();

	// Object: Function UI_Update.UI_Update_C.OnSolarUIOpened
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x1015dc5d4
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnSolarUIOpened();

	// Object: Function UI_Update.UI_Update_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();

	// Object: Function UI_Update.UI_Update_C.RefreshLoadingPointsAr
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x4) ]
	void RefreshLoadingPointsAr(int32_t Index);

	// Object: Function UI_Update.UI_Update_C.RefreshLoadingPoints
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x4) ]
	void RefreshLoadingPoints(int32_t Index);

	// Object: Function UI_Update.UI_Update_C.OnVideoReady
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnVideoReady();

	// Object: Function UI_Update.UI_Update_C.InitMedia
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x1) ]
	void InitMedia(bool& Result);

	// Object: Function UI_Update.UI_Update_C.FinishLoadLobby
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x4) ]
	void FinishLoadLobby(int32_t Type);

	// Object: Function UI_Update.UI_Update_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_Update.UI_Update_C.Tick
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(2) Size(0x3c) ]
	void Tick(struct FGeometry MyGeometry, float InDeltaTime);

	// Object: Function UI_Update.UI_Update_C.ReceiveShow
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(0) Size(0x0) ]
	void ReceiveShow();

	// Object: Function UI_Update.UI_Update_C.ConnectGateExec
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x1015dc5d4
	// Return & Params: [ Num(0) Size(0x0) ]
	void ConnectGateExec();

	// Object: Function UI_Update.UI_Update_C.ReceiveHide
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(0) Size(0x0) ]
	void ReceiveHide();

	// Object: Function UI_Update.UI_Update_C.BndEvt__btn_link_K2Node_ComponentBoundEvent_0_OnButtonHoverEvent__DelegateSignature
	// Flags: [BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(0) Size(0x0) ]
	void BndEvt__btn_link_K2Node_ComponentBoundEvent_0_OnButtonHoverEvent__DelegateSignature();

	// Object: Function UI_Update.UI_Update_C.BndEvt__btn_link_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature
	// Flags: [BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(0) Size(0x0) ]
	void BndEvt__btn_link_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature();

	// Object: Function UI_Update.UI_Update_C.ExecuteUbergraph_UI_Update
	// Flags: [Final|UbergraphFunction|HasDefaults]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_Update(int32_t EntryPoint);
};

