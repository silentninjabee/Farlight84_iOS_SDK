#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Warehouse_DragPanel.UI_Warehouse_DragPanel_C
// Inherited Bytes: 0x490 | Struct Size: 0x490
struct UUI_Warehouse_DragPanel_C : USolarUserWidget {
	// Functions

	// Object: Function UI_Warehouse_DragPanel.UI_Warehouse_DragPanel_C.OnMouseButtonUp
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x1015dc5d4
	// Return & Params: [ Num(3) Size(0x160) ]
	struct FEventReply OnMouseButtonUp(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent);

	// Object: Function UI_Warehouse_DragPanel.UI_Warehouse_DragPanel_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x1015dc5d4
	// Return & Params: [ Num(0) Size(0x0) ]
	void Construct();

	// Object: Function UI_Warehouse_DragPanel.UI_Warehouse_DragPanel_C.OnMouseMove
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x1015dc5d4
	// Return & Params: [ Num(3) Size(0x160) ]
	struct FEventReply OnMouseMove(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent);

	// Object: Function UI_Warehouse_DragPanel.UI_Warehouse_DragPanel_C.OnMouseButtonDown
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x1015dc5d4
	// Return & Params: [ Num(3) Size(0x160) ]
	struct FEventReply OnMouseButtonDown(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent);

	// Object: Function UI_Warehouse_DragPanel.UI_Warehouse_DragPanel_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();
};

