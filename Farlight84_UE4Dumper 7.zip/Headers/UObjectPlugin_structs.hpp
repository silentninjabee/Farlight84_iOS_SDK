#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct UObjectPlugin.MyPluginStruct
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FMyPluginStruct {
	// Fields
	struct FString TestString; // Offset: 0x0 | Size: 0x10
};

