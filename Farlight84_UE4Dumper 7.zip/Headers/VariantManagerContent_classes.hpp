#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class VariantManagerContent.LevelVariantSets
// Inherited Bytes: 0x28 | Struct Size: 0x90
struct ULevelVariantSets : UObject {
	// Fields
	struct UObject* DirectorClass; // Offset: 0x28 | Size: 0x8
	struct TArray<struct UVariantSet*> VariantSets; // Offset: 0x30 | Size: 0x10
	char pad_0x40[0x50]; // Offset: 0x40 | Size: 0x50

	// Functions

	// Object: Function VariantManagerContent.LevelVariantSets.GetVariantSetByName
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x10141bdbc
	// Return & Params: [ Num(2) Size(0x18) ]
	struct UVariantSet* GetVariantSetByName(struct FString VariantSetName);

	// Object: Function VariantManagerContent.LevelVariantSets.GetVariantSet
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x10141beb8
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UVariantSet* GetVariantSet(int32_t VariantSetIndex);

	// Object: Function VariantManagerContent.LevelVariantSets.GetNumVariantSets
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x10141bf48
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetNumVariantSets();
};

// Object: Class VariantManagerContent.LevelVariantSetsActor
// Inherited Bytes: 0x228 | Struct Size: 0x240
struct ALevelVariantSetsActor : AActor {
	// Fields
	struct FSoftObjectPath LevelVariantSets; // Offset: 0x228 | Size: 0x18

	// Functions

	// Object: Function VariantManagerContent.LevelVariantSetsActor.SwitchOnVariantByName
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10141c524
	// Return & Params: [ Num(3) Size(0x21) ]
	bool SwitchOnVariantByName(struct FString VariantSetName, struct FString VariantName);

	// Object: Function VariantManagerContent.LevelVariantSetsActor.SwitchOnVariantByIndex
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10141c44c
	// Return & Params: [ Num(3) Size(0x9) ]
	bool SwitchOnVariantByIndex(int32_t VariantSetIndex, int32_t VariantIndex);

	// Object: Function VariantManagerContent.LevelVariantSetsActor.SetLevelVariantSets
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10141c6b8
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetLevelVariantSets(struct ULevelVariantSets* InVariantSets);

	// Object: Function VariantManagerContent.LevelVariantSetsActor.GetLevelVariantSets
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10141c738
	// Return & Params: [ Num(2) Size(0x10) ]
	struct ULevelVariantSets* GetLevelVariantSets(bool bLoad);
};

// Object: Class VariantManagerContent.LevelVariantSetsFunctionDirector
// Inherited Bytes: 0x28 | Struct Size: 0x40
struct ULevelVariantSetsFunctionDirector : UObject {
	// Fields
	char pad_0x28[0x18]; // Offset: 0x28 | Size: 0x18
};

// Object: Class VariantManagerContent.PropertyValue
// Inherited Bytes: 0x28 | Struct Size: 0x1b8
struct UPropertyValue : UObject {
	// Fields
	char pad_0x28[0x60]; // Offset: 0x28 | Size: 0x60
	struct TArray<struct TFieldPath<FProperty>> Properties; // Offset: 0x88 | Size: 0x10
	struct TArray<int32_t> PropertyIndices; // Offset: 0x98 | Size: 0x10
	struct TArray<struct FCapturedPropSegment> CapturedPropSegments; // Offset: 0xa8 | Size: 0x10
	struct FString FullDisplayString; // Offset: 0xb8 | Size: 0x10
	struct FName PropertySetterName; // Offset: 0xc8 | Size: 0x8
	struct TMap<struct FString, struct FString> PropertySetterParameterDefaults; // Offset: 0xd0 | Size: 0x50
	bool bHasRecordedData; // Offset: 0x120 | Size: 0x1
	char pad_0x121[0x7]; // Offset: 0x121 | Size: 0x7
	struct UObject* LeafPropertyClass; // Offset: 0x128 | Size: 0x8
	char pad_0x130[0x8]; // Offset: 0x130 | Size: 0x8
	struct TArray<char> ValueBytes; // Offset: 0x138 | Size: 0x10
	enum class EPropertyValueCategory PropCategory; // Offset: 0x148 | Size: 0x1
	char pad_0x149[0x6f]; // Offset: 0x149 | Size: 0x6f

	// Functions

	// Object: Function VariantManagerContent.PropertyValue.HasRecordedData
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10141cebc
	// Return & Params: [ Num(1) Size(0x1) ]
	bool HasRecordedData();

	// Object: Function VariantManagerContent.PropertyValue.GetPropertyTooltip
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10141cf74
	// Return & Params: [ Num(1) Size(0x18) ]
	struct FText GetPropertyTooltip();

	// Object: Function VariantManagerContent.PropertyValue.GetFullDisplayString
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10141cef0
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetFullDisplayString();
};

// Object: Class VariantManagerContent.PropertyValueTransform
// Inherited Bytes: 0x1b8 | Struct Size: 0x1b8
struct UPropertyValueTransform : UPropertyValue {
};

// Object: Class VariantManagerContent.PropertyValueVisibility
// Inherited Bytes: 0x1b8 | Struct Size: 0x1b8
struct UPropertyValueVisibility : UPropertyValue {
};

// Object: Class VariantManagerContent.PropertyValueColor
// Inherited Bytes: 0x1b8 | Struct Size: 0x1b8
struct UPropertyValueColor : UPropertyValue {
};

// Object: Class VariantManagerContent.PropertyValueMaterial
// Inherited Bytes: 0x1b8 | Struct Size: 0x1b8
struct UPropertyValueMaterial : UPropertyValue {
};

// Object: Class VariantManagerContent.PropertyValueOption
// Inherited Bytes: 0x1b8 | Struct Size: 0x1b8
struct UPropertyValueOption : UPropertyValue {
};

// Object: Class VariantManagerContent.PropertyValueSoftObject
// Inherited Bytes: 0x1b8 | Struct Size: 0x1b8
struct UPropertyValueSoftObject : UPropertyValue {
};

// Object: Class VariantManagerContent.SwitchActor
// Inherited Bytes: 0x228 | Struct Size: 0x250
struct ASwitchActor : AActor {
	// Fields
	char pad_0x228[0x18]; // Offset: 0x228 | Size: 0x18
	struct USceneComponent* SceneComponent; // Offset: 0x240 | Size: 0x8
	int32_t LastSelectedOption; // Offset: 0x248 | Size: 0x4
	char pad_0x24C[0x4]; // Offset: 0x24c | Size: 0x4

	// Functions

	// Object: Function VariantManagerContent.SwitchActor.SelectOption
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10141da74
	// Return & Params: [ Num(1) Size(0x4) ]
	void SelectOption(int32_t OptionIndex);

	// Object: Function VariantManagerContent.SwitchActor.GetSelectedOption
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10141daf4
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetSelectedOption();

	// Object: Function VariantManagerContent.SwitchActor.GetOptions
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10141db28
	// Return & Params: [ Num(1) Size(0x10) ]
	struct TArray<struct AActor*> GetOptions();
};

// Object: Class VariantManagerContent.Variant
// Inherited Bytes: 0x28 | Struct Size: 0x70
struct UVariant : UObject {
	// Fields
	struct FText DisplayText; // Offset: 0x28 | Size: 0x18
	char pad_0x40[0x18]; // Offset: 0x40 | Size: 0x18
	struct TArray<struct UVariantObjectBinding*> ObjectBindings; // Offset: 0x58 | Size: 0x10
	struct UTexture2D* Thumbnail; // Offset: 0x68 | Size: 0x8

	// Functions

	// Object: Function VariantManagerContent.Variant.SwitchOn
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10141df90
	// Return & Params: [ Num(0) Size(0x0) ]
	void SwitchOn();

	// Object: Function VariantManagerContent.Variant.SetDisplayText
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10141e110
	// Return & Params: [ Num(1) Size(0x18) ]
	void SetDisplayText(struct FText& NewDisplayText);

	// Object: Function VariantManagerContent.Variant.IsActive
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10141df5c
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsActive();

	// Object: Function VariantManagerContent.Variant.GetThumbnail
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10141df28
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UTexture2D* GetThumbnail();

	// Object: Function VariantManagerContent.Variant.GetNumActors
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x10141e034
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetNumActors();

	// Object: Function VariantManagerContent.Variant.GetDisplayText
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10141e068
	// Return & Params: [ Num(1) Size(0x18) ]
	struct FText GetDisplayText();

	// Object: Function VariantManagerContent.Variant.GetActor
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x10141dfa4
	// Return & Params: [ Num(2) Size(0x10) ]
	struct AActor* GetActor(int32_t ActorIndex);
};

// Object: Class VariantManagerContent.VariantObjectBinding
// Inherited Bytes: 0x28 | Struct Size: 0x90
struct UVariantObjectBinding : UObject {
	// Fields
	struct FString CachedActorLabel; // Offset: 0x28 | Size: 0x10
	struct FSoftObjectPath ObjectPtr; // Offset: 0x38 | Size: 0x18
	LazyObjectProperty LazyObjectPtr; // Offset: 0x50 | Size: 0x1c
	char pad_0x6C[0x4]; // Offset: 0x6c | Size: 0x4
	struct TArray<struct UPropertyValue*> CapturedProperties; // Offset: 0x70 | Size: 0x10
	struct TArray<struct FFunctionCaller> FunctionCallers; // Offset: 0x80 | Size: 0x10
};

// Object: Class VariantManagerContent.VariantSet
// Inherited Bytes: 0x28 | Struct Size: 0x70
struct UVariantSet : UObject {
	// Fields
	struct FText DisplayText; // Offset: 0x28 | Size: 0x18
	char pad_0x40[0x18]; // Offset: 0x40 | Size: 0x18
	bool bExpanded; // Offset: 0x58 | Size: 0x1
	char pad_0x59[0x7]; // Offset: 0x59 | Size: 0x7
	struct TArray<struct UVariant*> Variants; // Offset: 0x60 | Size: 0x10

	// Functions

	// Object: Function VariantManagerContent.VariantSet.SetDisplayText
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10141ec44
	// Return & Params: [ Num(1) Size(0x18) ]
	void SetDisplayText(struct FText& NewDisplayText);

	// Object: Function VariantManagerContent.VariantSet.GetVariantByName
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x10141e9dc
	// Return & Params: [ Num(2) Size(0x18) ]
	struct UVariant* GetVariantByName(struct FString VariantName);

	// Object: Function VariantManagerContent.VariantSet.GetVariant
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x10141ead8
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UVariant* GetVariant(int32_t VariantIndex);

	// Object: Function VariantManagerContent.VariantSet.GetNumVariants
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x10141eb68
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetNumVariants();

	// Object: Function VariantManagerContent.VariantSet.GetDisplayText
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10141eb9c
	// Return & Params: [ Num(1) Size(0x18) ]
	struct FText GetDisplayText();
};

