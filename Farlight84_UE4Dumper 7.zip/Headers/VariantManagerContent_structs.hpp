#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct VariantManagerContent.FunctionCaller
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FFunctionCaller {
	// Fields
	struct FName FunctionName; // Offset: 0x0 | Size: 0x8
};

// Object: ScriptStruct VariantManagerContent.CapturedPropSegment
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FCapturedPropSegment {
	// Fields
	struct FString PropertyName; // Offset: 0x0 | Size: 0x10
	int32_t PropertyIndex; // Offset: 0x10 | Size: 0x4
	char pad_0x14[0x4]; // Offset: 0x14 | Size: 0x4
	struct FString ComponentName; // Offset: 0x18 | Size: 0x10
};

