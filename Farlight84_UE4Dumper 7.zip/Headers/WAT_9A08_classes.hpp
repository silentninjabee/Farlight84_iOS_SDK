#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass WAT_9A08.WAT_9A08_C
// Inherited Bytes: 0xe8 | Struct Size: 0xe8
struct UWAT_9A08_C : USolarWeaponAT_FireBurst {
};

