#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass WAT_FireLaser_VH_Hover_Soroll04_New.WAT_FireLaser_VH_Hover_Soroll04_New_C
// Inherited Bytes: 0x230 | Struct Size: 0x238
struct UWAT_FireLaser_VH_Hover_Soroll04_New_C : USolarWeaponAT_FireLaser {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x230 | Size: 0x8

	// Functions

	// Object: Function WAT_FireLaser_VH_Hover_Soroll04_New.WAT_FireLaser_VH_Hover_Soroll04_New_C.K2_ActivateRealFire
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(0) Size(0x0) ]
	void K2_ActivateRealFire();

	// Object: Function WAT_FireLaser_VH_Hover_Soroll04_New.WAT_FireLaser_VH_Hover_Soroll04_New_C.ExecuteUbergraph_WAT_FireLaser_VH_Hover_Soroll04_New
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103cd7c5c
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_WAT_FireLaser_VH_Hover_Soroll04_New(int32_t EntryPoint);
};

