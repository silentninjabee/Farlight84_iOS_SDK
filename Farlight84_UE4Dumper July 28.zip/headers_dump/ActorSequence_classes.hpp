#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class ActorSequence.ActorSequence
// Size: 0x370 // Inherited bytes: 0x348
struct UActorSequence : UMovieSceneSequence {
	// Fields
	struct UMovieScene* MovieScene; // Offset: 0x348 // Size: 0x08
	struct FActorSequenceObjectReferenceMap ObjectReferences; // Offset: 0x350 // Size: 0x20
};

// Object Name: Class ActorSequence.ActorSequenceComponent
// Size: 0xd8 // Inherited bytes: 0xb0
struct UActorSequenceComponent : UActorComponent {
	// Fields
	struct FMovieSceneSequencePlaybackSettings PlaybackSettings; // Offset: 0xb0 // Size: 0x14
	char pad_0xC4[0x4]; // Offset: 0xc4 // Size: 0x04
	struct UActorSequence* Sequence; // Offset: 0xc8 // Size: 0x08
	struct UActorSequencePlayer* SequencePlayer; // Offset: 0xd0 // Size: 0x08
};

// Object Name: Class ActorSequence.ActorSequencePlayer
// Size: 0x888 // Inherited bytes: 0x888
struct UActorSequencePlayer : UMovieSceneSequencePlayer {
};

