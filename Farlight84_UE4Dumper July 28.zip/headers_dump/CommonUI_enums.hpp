#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum CommonUI.ECommonNumericType
enum class ECommonNumericType : uint8 {
	Number = 0,
	Percentage = 1,
	Seconds = 2,
	Distance = 3,
	ECommonNumericType_MAX = 4
};

// Object Name: Enum CommonUI.ECommonInputMode
enum class ECommonInputMode : uint8 {
	Menu = 0,
	Game = 1,
	All = 2,
	MAX = 3
};

// Object Name: Enum CommonUI.ERichTextInlineIconDisplayMode
enum class ERichTextInlineIconDisplayMode : uint8 {
	IconOnly = 0,
	TextOnly = 1,
	IconAndText = 2,
	MAX = 3
};

// Object Name: Enum CommonUI.EInputActionState
enum class EInputActionState : uint8 {
	Enabled = 0,
	Disabled = 1,
	Hidden = 2,
	HiddenAndDisabled = 3,
	EInputActionState_MAX = 4
};

// Object Name: Enum CommonUI.ETransitionCurve
enum class ETransitionCurve : uint8 {
	Linear = 0,
	QuadIn = 1,
	QuadOut = 2,
	QuadInOut = 3,
	CubicIn = 4,
	CubicOut = 5,
	CubicInOut = 6,
	ETransitionCurve_MAX = 7
};

// Object Name: Enum CommonUI.ECommonSwitcherTransition
enum class ECommonSwitcherTransition : uint8 {
	FadeOnly = 0,
	Horizontal = 1,
	Vertical = 2,
	Zoom = 3,
	ECommonSwitcherTransition_MAX = 4
};

