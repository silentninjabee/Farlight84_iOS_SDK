#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class EnhancedInput.EnhancedInputActionDelegateBinding
// Size: 0x38 // Inherited bytes: 0x28
struct UEnhancedInputActionDelegateBinding : UInputDelegateBinding {
	// Fields
	struct TArray<struct FBlueprintEnhancedInputActionBinding> InputActionDelegateBindings; // Offset: 0x28 // Size: 0x10
};

// Object Name: Class EnhancedInput.EnhancedInputActionValueBinding
// Size: 0x38 // Inherited bytes: 0x28
struct UEnhancedInputActionValueBinding : UInputDelegateBinding {
	// Fields
	struct TArray<struct FBlueprintEnhancedInputActionBinding> InputActionValueBindings; // Offset: 0x28 // Size: 0x10
};

// Object Name: Class EnhancedInput.EnhancedInputComponent
// Size: 0x168 // Inherited bytes: 0x138
struct UEnhancedInputComponent : UInputComponent {
	// Fields
	char pad_0x138[0x30]; // Offset: 0x138 // Size: 0x30

	// Functions

	// Object Name: Function EnhancedInput.EnhancedInputComponent.GetBoundActionValue
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FInputActionValue GetBoundActionValue(struct UInputAction* Action); // Offset: 0x1015cd16c // Return & Params: Num(2) Size(0x18)
};

// Object Name: Class EnhancedInput.EnhancedInputLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct UEnhancedInputLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function EnhancedInput.EnhancedInputLibrary.RequestRebuildControlMappingsUsingContext
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void RequestRebuildControlMappingsUsingContext(struct UInputMappingContext* Context, bool bForceImmediately); // Offset: 0x1015cdb5c // Return & Params: Num(2) Size(0x9)

	// Object Name: Function EnhancedInput.EnhancedInputLibrary.MakeInputActionValue
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FInputActionValue MakeInputActionValue(float X, float Y, float Z, struct FInputActionValue& MatchValueType); // Offset: 0x1015cd830 // Return & Params: Num(5) Size(0x2c)

	// Object Name: Function EnhancedInput.EnhancedInputLibrary.GetBoundActionValue
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FInputActionValue GetBoundActionValue(struct AActor* Actor, struct UInputAction* Action); // Offset: 0x1015cd75c // Return & Params: Num(3) Size(0x20)

	// Object Name: Function EnhancedInput.EnhancedInputLibrary.Conv_InputActionValueToBool
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	bool Conv_InputActionValueToBool(struct FInputActionValue InValue); // Offset: 0x1015cd6c4 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function EnhancedInput.EnhancedInputLibrary.Conv_InputActionValueToAxis3D
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	struct FVector Conv_InputActionValueToAxis3D(struct FInputActionValue ActionValue); // Offset: 0x1015cd4f4 // Return & Params: Num(2) Size(0x1c)

	// Object Name: Function EnhancedInput.EnhancedInputLibrary.Conv_InputActionValueToAxis2D
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	struct FVector2D Conv_InputActionValueToAxis2D(struct FInputActionValue InValue); // Offset: 0x1015cd590 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function EnhancedInput.EnhancedInputLibrary.Conv_InputActionValueToAxis1D
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	float Conv_InputActionValueToAxis1D(struct FInputActionValue InValue); // Offset: 0x1015cd62c // Return & Params: Num(2) Size(0x14)

	// Object Name: Function EnhancedInput.EnhancedInputLibrary.BreakInputActionValue
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	void BreakInputActionValue(struct FInputActionValue InActionValue, float& X, float& Y, float& Z); // Offset: 0x1015cd9b4 // Return & Params: Num(4) Size(0x1c)
};

// Object Name: Class EnhancedInput.EnhancedInputSubsystemInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UEnhancedInputSubsystemInterface : UInterface {
	// Functions

	// Object Name: Function EnhancedInput.EnhancedInputSubsystemInterface.RequestRebuildControlMappings
	// Flags: [BlueprintCosmetic|Native|Public|BlueprintCallable]
	void RequestRebuildControlMappings(bool bForceImmediately); // Offset: 0x1015cea5c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function EnhancedInput.EnhancedInputSubsystemInterface.RemoveMappingContext
	// Flags: [BlueprintCosmetic|Native|Public|BlueprintCallable]
	void RemoveMappingContext(struct UInputMappingContext* MappingContext); // Offset: 0x1015ceaec // Return & Params: Num(1) Size(0x8)

	// Object Name: Function EnhancedInput.EnhancedInputSubsystemInterface.QueryMapKeyInContextSet
	// Flags: [BlueprintCosmetic|Native|Public|HasOutParms|BlueprintCallable]
	enum class EMappingQueryResult QueryMapKeyInContextSet(struct TArray<struct UInputMappingContext*>& PrioritizedActiveContexts, struct UInputMappingContext* InputContext, struct UInputAction* Action, struct FKey Key, struct TArray<struct FMappingQueryIssue>& OutIssues, enum class EMappingQueryIssue BlockingIssues); // Offset: 0x1015ce490 // Return & Params: Num(7) Size(0x4a)

	// Object Name: Function EnhancedInput.EnhancedInputSubsystemInterface.QueryMapKeyInActiveContextSet
	// Flags: [BlueprintCosmetic|Native|Public|HasOutParms|BlueprintCallable]
	enum class EMappingQueryResult QueryMapKeyInActiveContextSet(struct UInputMappingContext* InputContext, struct UInputAction* Action, struct FKey Key, struct TArray<struct FMappingQueryIssue>& OutIssues, enum class EMappingQueryIssue BlockingIssues); // Offset: 0x1015ce7a8 // Return & Params: Num(6) Size(0x3a)

	// Object Name: Function EnhancedInput.EnhancedInputSubsystemInterface.QueryKeysMappedToAction
	// Flags: [BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct TArray<struct FKey> QueryKeysMappedToAction(struct UInputAction* Action); // Offset: 0x1015ce20c // Return & Params: Num(2) Size(0x18)

	// Object Name: Function EnhancedInput.EnhancedInputSubsystemInterface.HasMappingContext
	// Flags: [BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool HasMappingContext(struct UInputMappingContext* MappingContext); // Offset: 0x1015ce3f8 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function EnhancedInput.EnhancedInputSubsystemInterface.ClearAllMappings
	// Flags: [BlueprintCosmetic|Native|Public|BlueprintCallable]
	void ClearAllMappings(); // Offset: 0x1015cec48 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function EnhancedInput.EnhancedInputSubsystemInterface.AddMappingContext
	// Flags: [BlueprintCosmetic|Native|Public|BlueprintCallable]
	void AddMappingContext(struct UInputMappingContext* MappingContext, int32_t Priority); // Offset: 0x1015ceb74 // Return & Params: Num(2) Size(0xc)
};

// Object Name: Class EnhancedInput.EnhancedInputLocalPlayerSubsystem
// Size: 0xe0 // Inherited bytes: 0x30
struct UEnhancedInputLocalPlayerSubsystem : ULocalPlayerSubsystem {
	// Fields
	char pad_0x30[0xb0]; // Offset: 0x30 // Size: 0xb0
};

// Object Name: Class EnhancedInput.EnhancedInputEngineSubsystem
// Size: 0xe8 // Inherited bytes: 0x30
struct UEnhancedInputEngineSubsystem : UEngineSubsystem {
	// Fields
	char pad_0x30[0xb0]; // Offset: 0x30 // Size: 0xb0
	struct UEnhancedPlayerInput* PlayerInput; // Offset: 0xe0 // Size: 0x08
};

// Object Name: Class EnhancedInput.EnhancedPlayerInput
// Size: 0x600 // Inherited bytes: 0x3a8
struct UEnhancedPlayerInput : UPlayerInput {
	// Fields
	struct TMap<struct UInputMappingContext*, int32_t> AppliedInputContexts; // Offset: 0x3a8 // Size: 0x50
	struct TArray<struct FEnhancedActionKeyMapping> EnhancedActionMappings; // Offset: 0x3f8 // Size: 0x10
	char pad_0x408[0x50]; // Offset: 0x408 // Size: 0x50
	struct TMap<struct UInputAction*, struct FInputActionInstance> ActionInstanceData; // Offset: 0x458 // Size: 0x50
	char pad_0x4A8[0x158]; // Offset: 0x4a8 // Size: 0x158
};

// Object Name: Class EnhancedInput.InputAction
// Size: 0x58 // Inherited bytes: 0x30
struct UInputAction : UDataAsset {
	// Fields
	bool bConsumeInput; // Offset: 0x30 // Size: 0x01
	bool bTriggerWhenPaused; // Offset: 0x31 // Size: 0x01
	bool bReserveAllMappings; // Offset: 0x32 // Size: 0x01
	enum class EInputActionValueType ValueType; // Offset: 0x33 // Size: 0x01
	char pad_0x34[0x4]; // Offset: 0x34 // Size: 0x04
	struct TArray<struct UInputTrigger*> Triggers; // Offset: 0x38 // Size: 0x10
	struct TArray<struct UInputModifier*> Modifiers; // Offset: 0x48 // Size: 0x10
};

// Object Name: Class EnhancedInput.InputDebugKeyDelegateBinding
// Size: 0x38 // Inherited bytes: 0x28
struct UInputDebugKeyDelegateBinding : UInputDelegateBinding {
	// Fields
	struct TArray<struct FBlueprintInputDebugKeyDelegateBinding> InputDebugKeyDelegateBindings; // Offset: 0x28 // Size: 0x10
};

// Object Name: Class EnhancedInput.InputMappingContext
// Size: 0x58 // Inherited bytes: 0x30
struct UInputMappingContext : UDataAsset {
	// Fields
	struct TArray<struct FEnhancedActionKeyMapping> Mappings; // Offset: 0x30 // Size: 0x10
	struct FText ContextDescription; // Offset: 0x40 // Size: 0x18

	// Functions

	// Object Name: Function EnhancedInput.InputMappingContext.UnmapKey
	// Flags: [Final|Native|Public|BlueprintCallable]
	void UnmapKey(struct UInputAction* Action, struct FKey Key); // Offset: 0x1015d02e0 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function EnhancedInput.InputMappingContext.UnmapAll
	// Flags: [Final|Native|Public|BlueprintCallable]
	void UnmapAll(); // Offset: 0x1015d024c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function EnhancedInput.InputMappingContext.UnmapAction
	// Flags: [Final|Native|Public|BlueprintCallable]
	void UnmapAction(struct UInputAction* Action); // Offset: 0x1015d0260 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function EnhancedInput.InputMappingContext.MapKey
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FEnhancedActionKeyMapping MapKey(struct UInputAction* Action, struct FKey ToKey); // Offset: 0x1015d048c // Return & Params: Num(3) Size(0x68)
};

// Object Name: Class EnhancedInput.InputModifier
// Size: 0x28 // Inherited bytes: 0x28
struct UInputModifier : UObject {
	// Functions

	// Object Name: Function EnhancedInput.InputModifier.ModifyRaw
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const]
	struct FInputActionValue ModifyRaw(struct UEnhancedPlayerInput* PlayerInput, struct FInputActionValue CurrentValue, float DeltaTime); // Offset: 0x1015d117c // Return & Params: Num(4) Size(0x2c)

	// Object Name: Function EnhancedInput.InputModifier.GetVisualizationColor
	// Flags: [Native|Event|Public|HasDefaults|BlueprintEvent|Const]
	struct FLinearColor GetVisualizationColor(struct FInputActionValue SampleValue, struct FInputActionValue FinalValue); // Offset: 0x1015d1034 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function EnhancedInput.InputModifier.GetExecutionPhase
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	enum class EModifierExecutionPhase GetExecutionPhase(); // Offset: 0x1015d1140 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class EnhancedInput.InputModifierDeadZone
// Size: 0x38 // Inherited bytes: 0x28
struct UInputModifierDeadZone : UInputModifier {
	// Fields
	float LowerThreshold; // Offset: 0x28 // Size: 0x04
	float UpperThreshold; // Offset: 0x2c // Size: 0x04
	enum class EDeadZoneType Type; // Offset: 0x30 // Size: 0x01
	char pad_0x31[0x7]; // Offset: 0x31 // Size: 0x07
};

// Object Name: Class EnhancedInput.InputModifierScalar
// Size: 0x38 // Inherited bytes: 0x28
struct UInputModifierScalar : UInputModifier {
	// Fields
	struct FVector Scalar; // Offset: 0x28 // Size: 0x0c
	char pad_0x34[0x4]; // Offset: 0x34 // Size: 0x04
};

// Object Name: Class EnhancedInput.InputModifierNegate
// Size: 0x30 // Inherited bytes: 0x28
struct UInputModifierNegate : UInputModifier {
	// Fields
	bool bX; // Offset: 0x28 // Size: 0x01
	bool bY; // Offset: 0x29 // Size: 0x01
	bool bZ; // Offset: 0x2a // Size: 0x01
	char pad_0x2B[0x5]; // Offset: 0x2b // Size: 0x05
};

// Object Name: Class EnhancedInput.InputModifierSmooth
// Size: 0x48 // Inherited bytes: 0x28
struct UInputModifierSmooth : UInputModifier {
	// Fields
	char pad_0x28[0x20]; // Offset: 0x28 // Size: 0x20
};

// Object Name: Class EnhancedInput.InputModifierResponseCurveExponential
// Size: 0x38 // Inherited bytes: 0x28
struct UInputModifierResponseCurveExponential : UInputModifier {
	// Fields
	struct FVector CurveExponent; // Offset: 0x28 // Size: 0x0c
	char pad_0x34[0x4]; // Offset: 0x34 // Size: 0x04
};

// Object Name: Class EnhancedInput.InputModifierResponseCurveUser
// Size: 0x40 // Inherited bytes: 0x28
struct UInputModifierResponseCurveUser : UInputModifier {
	// Fields
	struct UCurveFloat* ResponseX; // Offset: 0x28 // Size: 0x08
	struct UCurveFloat* ResponseY; // Offset: 0x30 // Size: 0x08
	struct UCurveFloat* ResponseZ; // Offset: 0x38 // Size: 0x08
};

// Object Name: Class EnhancedInput.InputModifierFOVScaling
// Size: 0x30 // Inherited bytes: 0x28
struct UInputModifierFOVScaling : UInputModifier {
	// Fields
	float FOVScale; // Offset: 0x28 // Size: 0x04
	enum class EFOVScalingType FOVScalingType; // Offset: 0x2c // Size: 0x01
	char pad_0x2D[0x3]; // Offset: 0x2d // Size: 0x03
};

// Object Name: Class EnhancedInput.InputModifierToWorldSpace
// Size: 0x28 // Inherited bytes: 0x28
struct UInputModifierToWorldSpace : UInputModifier {
};

// Object Name: Class EnhancedInput.InputModifierSwizzleAxis
// Size: 0x30 // Inherited bytes: 0x28
struct UInputModifierSwizzleAxis : UInputModifier {
	// Fields
	enum class EInputAxisSwizzle Order; // Offset: 0x28 // Size: 0x01
	char pad_0x29[0x7]; // Offset: 0x29 // Size: 0x07
};

// Object Name: Class EnhancedInput.InputModifierCollection
// Size: 0x40 // Inherited bytes: 0x28
struct UInputModifierCollection : UInputModifier {
	// Fields
	struct TArray<struct UInputModifier*> Modifiers; // Offset: 0x28 // Size: 0x10
	bool bPermitValueTypeModification; // Offset: 0x38 // Size: 0x01
	char pad_0x39[0x7]; // Offset: 0x39 // Size: 0x07
};

// Object Name: Class EnhancedInput.InputTrigger
// Size: 0x40 // Inherited bytes: 0x28
struct UInputTrigger : UObject {
	// Fields
	float ActuationThreshold; // Offset: 0x28 // Size: 0x04
	struct FInputActionValue LastValue; // Offset: 0x2c // Size: 0x10
	char pad_0x3C[0x4]; // Offset: 0x3c // Size: 0x04

	// Functions

	// Object Name: Function EnhancedInput.InputTrigger.UpdateState
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	enum class ETriggerState UpdateState(struct UEnhancedPlayerInput* PlayerInput, struct FInputActionValue ModifiedValue, float DeltaTime); // Offset: 0x1015d2994 // Return & Params: Num(4) Size(0x1d)

	// Object Name: Function EnhancedInput.InputTrigger.IsActuated
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	bool IsActuated(struct FInputActionValue& ForValue); // Offset: 0x1015d2b0c // Return & Params: Num(2) Size(0x11)

	// Object Name: Function EnhancedInput.InputTrigger.GetTriggerType
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const]
	enum class ETriggerTypeEx GetTriggerType(); // Offset: 0x1015d2ad0 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class EnhancedInput.InputTriggerTimedBase
// Size: 0x48 // Inherited bytes: 0x40
struct UInputTriggerTimedBase : UInputTrigger {
	// Fields
	float HeldDuration; // Offset: 0x3c // Size: 0x04
	bool bAffectedByTimeDilation; // Offset: 0x40 // Size: 0x01
	char pad_0x45[0x3]; // Offset: 0x45 // Size: 0x03
};

// Object Name: Class EnhancedInput.InputTriggerDown
// Size: 0x40 // Inherited bytes: 0x40
struct UInputTriggerDown : UInputTrigger {
};

// Object Name: Class EnhancedInput.InputTriggerPressed
// Size: 0x40 // Inherited bytes: 0x40
struct UInputTriggerPressed : UInputTrigger {
};

// Object Name: Class EnhancedInput.InputTriggerReleased
// Size: 0x40 // Inherited bytes: 0x40
struct UInputTriggerReleased : UInputTrigger {
};

// Object Name: Class EnhancedInput.InputTriggerHold
// Size: 0x50 // Inherited bytes: 0x48
struct UInputTriggerHold : UInputTriggerTimedBase {
	// Fields
	float HoldTimeThreshold; // Offset: 0x44 // Size: 0x04
	bool bIsOneShot; // Offset: 0x48 // Size: 0x01
	char pad_0x4D[0x3]; // Offset: 0x4d // Size: 0x03
};

// Object Name: Class EnhancedInput.InputTriggerHoldAndRelease
// Size: 0x48 // Inherited bytes: 0x48
struct UInputTriggerHoldAndRelease : UInputTriggerTimedBase {
	// Fields
	float HoldTimeThreshold; // Offset: 0x44 // Size: 0x04
};

// Object Name: Class EnhancedInput.InputTriggerTap
// Size: 0x48 // Inherited bytes: 0x48
struct UInputTriggerTap : UInputTriggerTimedBase {
	// Fields
	float TapReleaseTimeThreshold; // Offset: 0x44 // Size: 0x04
};

// Object Name: Class EnhancedInput.InputTriggerPulse
// Size: 0x58 // Inherited bytes: 0x48
struct UInputTriggerPulse : UInputTriggerTimedBase {
	// Fields
	bool bTriggerOnStart; // Offset: 0x48 // Size: 0x01
	char pad_0x49[0x3]; // Offset: 0x49 // Size: 0x03
	float Interval; // Offset: 0x4c // Size: 0x04
	int32_t TriggerLimit; // Offset: 0x50 // Size: 0x04
	char pad_0x54[0x4]; // Offset: 0x54 // Size: 0x04
};

// Object Name: Class EnhancedInput.InputTriggerChordAction
// Size: 0x48 // Inherited bytes: 0x40
struct UInputTriggerChordAction : UInputTrigger {
	// Fields
	struct UInputAction* ChordAction; // Offset: 0x40 // Size: 0x08
};

// Object Name: Class EnhancedInput.InputTriggerChordBlocker
// Size: 0x48 // Inherited bytes: 0x48
struct UInputTriggerChordBlocker : UInputTriggerChordAction {
};

