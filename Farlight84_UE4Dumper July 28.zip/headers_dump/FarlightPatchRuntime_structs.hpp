#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct FarlightPatchRuntime.PakEntryInfo
// Size: 0x40 // Inherited bytes: 0x00
struct FPakEntryInfo {
	// Fields
	struct FString Filename; // Offset: 0x00 // Size: 0x10
	struct FString MountPoint; // Offset: 0x10 // Size: 0x10
	int64_t Size; // Offset: 0x20 // Size: 0x08
	int64_t Offset; // Offset: 0x28 // Size: 0x08
	struct FString Hash; // Offset: 0x30 // Size: 0x10
};

