#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct GeometryCollectionCore.RecordedTransformTrack
// Size: 0x10 // Inherited bytes: 0x00
struct FRecordedTransformTrack {
	// Fields
	struct TArray<struct FRecordedFrame> Records; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct GeometryCollectionCore.RecordedFrame
// Size: 0xb8 // Inherited bytes: 0x00
struct FRecordedFrame {
	// Fields
	struct TArray<struct FTransform> Transforms; // Offset: 0x00 // Size: 0x10
	struct TArray<int32_t> TransformIndices; // Offset: 0x10 // Size: 0x10
	struct TArray<int32_t> PreviousTransformIndices; // Offset: 0x20 // Size: 0x10
	struct TArray<bool> DisabledFlags; // Offset: 0x30 // Size: 0x10
	struct TArray<struct FSolverCollisionData> Collisions; // Offset: 0x40 // Size: 0x10
	struct TArray<struct FSolverBreakingData> Breakings; // Offset: 0x50 // Size: 0x10
	struct TSet<struct FSolverTrailingData> Trailings; // Offset: 0x60 // Size: 0x50
	float Timestamp; // Offset: 0xb0 // Size: 0x04
	char pad_0xB4[0x4]; // Offset: 0xb4 // Size: 0x04
};

// Object Name: ScriptStruct GeometryCollectionCore.SolverTrailingData
// Size: 0x30 // Inherited bytes: 0x00
struct FSolverTrailingData {
	// Fields
	struct FVector Location; // Offset: 0x00 // Size: 0x0c
	struct FVector Velocity; // Offset: 0x0c // Size: 0x0c
	struct FVector AngularVelocity; // Offset: 0x18 // Size: 0x0c
	float Mass; // Offset: 0x24 // Size: 0x04
	int32_t ParticleIndex; // Offset: 0x28 // Size: 0x04
	int32_t ParticleIndexMesh; // Offset: 0x2c // Size: 0x04
};

// Object Name: ScriptStruct GeometryCollectionCore.SolverBreakingData
// Size: 0x30 // Inherited bytes: 0x00
struct FSolverBreakingData {
	// Fields
	struct FVector Location; // Offset: 0x00 // Size: 0x0c
	struct FVector Velocity; // Offset: 0x0c // Size: 0x0c
	struct FVector AngularVelocity; // Offset: 0x18 // Size: 0x0c
	float Mass; // Offset: 0x24 // Size: 0x04
	int32_t ParticleIndex; // Offset: 0x28 // Size: 0x04
	int32_t ParticleIndexMesh; // Offset: 0x2c // Size: 0x04
};

// Object Name: ScriptStruct GeometryCollectionCore.SolverCollisionData
// Size: 0x6c // Inherited bytes: 0x00
struct FSolverCollisionData {
	// Fields
	struct FVector Location; // Offset: 0x00 // Size: 0x0c
	struct FVector AccumulatedImpulse; // Offset: 0x0c // Size: 0x0c
	struct FVector Normal; // Offset: 0x18 // Size: 0x0c
	struct FVector Velocity1; // Offset: 0x24 // Size: 0x0c
	struct FVector Velocity2; // Offset: 0x30 // Size: 0x0c
	struct FVector AngularVelocity1; // Offset: 0x3c // Size: 0x0c
	struct FVector AngularVelocity2; // Offset: 0x48 // Size: 0x0c
	float Mass1; // Offset: 0x54 // Size: 0x04
	float Mass2; // Offset: 0x58 // Size: 0x04
	int32_t ParticleIndex; // Offset: 0x5c // Size: 0x04
	int32_t LevelsetIndex; // Offset: 0x60 // Size: 0x04
	int32_t ParticleIndexMesh; // Offset: 0x64 // Size: 0x04
	int32_t LevelsetIndexMesh; // Offset: 0x68 // Size: 0x04
};

