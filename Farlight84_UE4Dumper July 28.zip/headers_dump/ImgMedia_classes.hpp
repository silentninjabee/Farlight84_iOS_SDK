#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class ImgMedia.ImgMediaSource
// Size: 0xb0 // Inherited bytes: 0x88
struct UImgMediaSource : UBaseMediaSource {
	// Fields
	struct FFrameRate FrameRateOverride; // Offset: 0x88 // Size: 0x08
	struct FString ProxyOverride; // Offset: 0x90 // Size: 0x10
	struct FDirectoryPath SequencePath; // Offset: 0xa0 // Size: 0x10

	// Functions

	// Object Name: Function ImgMedia.ImgMediaSource.SetSequencePath
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSequencePath(struct FString Path); // Offset: 0x101ebd0f0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function ImgMedia.ImgMediaSource.GetSequencePath
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FString GetSequencePath(); // Offset: 0x101ebd17c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function ImgMedia.ImgMediaSource.GetProxies
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetProxies(struct TArray<struct FString>& OutProxies); // Offset: 0x101ebd25c // Return & Params: Num(1) Size(0x10)
};

