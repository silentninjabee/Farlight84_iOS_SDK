#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class InteractiveToolsFramework.InputBehavior
// Size: 0x30 // Inherited bytes: 0x28
struct UInputBehavior : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08
};

// Object Name: Class InteractiveToolsFramework.AnyButtonInputBehavior
// Size: 0x70 // Inherited bytes: 0x30
struct UAnyButtonInputBehavior : UInputBehavior {
	// Fields
	char pad_0x30[0x40]; // Offset: 0x30 // Size: 0x40
};

// Object Name: Class InteractiveToolsFramework.InteractiveGizmoBuilder
// Size: 0x28 // Inherited bytes: 0x28
struct UInteractiveGizmoBuilder : UObject {
};

// Object Name: Class InteractiveToolsFramework.AxisAngleGizmoBuilder
// Size: 0x28 // Inherited bytes: 0x28
struct UAxisAngleGizmoBuilder : UInteractiveGizmoBuilder {
};

// Object Name: Class InteractiveToolsFramework.InteractiveGizmo
// Size: 0x38 // Inherited bytes: 0x28
struct UInteractiveGizmo : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08
	struct UInputBehaviorSet* InputBehaviors; // Offset: 0x30 // Size: 0x08
};

// Object Name: Class InteractiveToolsFramework.AxisAngleGizmo
// Size: 0xf0 // Inherited bytes: 0x38
struct UAxisAngleGizmo : UInteractiveGizmo {
	// Fields
	char pad_0x38[0x10]; // Offset: 0x38 // Size: 0x10
	struct TScriptInterface<IGizmoAxisSource> AxisSource; // Offset: 0x48 // Size: 0x10
	struct TScriptInterface<IGizmoFloatParameterSource> AngleSource; // Offset: 0x58 // Size: 0x10
	struct TScriptInterface<IGizmoClickTarget> HitTarget; // Offset: 0x68 // Size: 0x10
	struct TScriptInterface<IGizmoStateTarget> StateTarget; // Offset: 0x78 // Size: 0x10
	bool bInInteraction; // Offset: 0x88 // Size: 0x01
	char pad_0x89[0x3]; // Offset: 0x89 // Size: 0x03
	struct FVector RotationOrigin; // Offset: 0x8c // Size: 0x0c
	struct FVector RotationAxis; // Offset: 0x98 // Size: 0x0c
	struct FVector RotationPlaneX; // Offset: 0xa4 // Size: 0x0c
	struct FVector RotationPlaneY; // Offset: 0xb0 // Size: 0x0c
	struct FVector InteractionStartPoint; // Offset: 0xbc // Size: 0x0c
	struct FVector InteractionCurPoint; // Offset: 0xc8 // Size: 0x0c
	float InteractionStartAngle; // Offset: 0xd4 // Size: 0x04
	float InteractionCurAngle; // Offset: 0xd8 // Size: 0x04
	char pad_0xDC[0x14]; // Offset: 0xdc // Size: 0x14
};

// Object Name: Class InteractiveToolsFramework.AxisPositionGizmoBuilder
// Size: 0x28 // Inherited bytes: 0x28
struct UAxisPositionGizmoBuilder : UInteractiveGizmoBuilder {
};

// Object Name: Class InteractiveToolsFramework.AxisPositionGizmo
// Size: 0xd8 // Inherited bytes: 0x38
struct UAxisPositionGizmo : UInteractiveGizmo {
	// Fields
	char pad_0x38[0x10]; // Offset: 0x38 // Size: 0x10
	struct TScriptInterface<IGizmoAxisSource> AxisSource; // Offset: 0x48 // Size: 0x10
	struct TScriptInterface<IGizmoFloatParameterSource> ParameterSource; // Offset: 0x58 // Size: 0x10
	struct TScriptInterface<IGizmoClickTarget> HitTarget; // Offset: 0x68 // Size: 0x10
	struct TScriptInterface<IGizmoStateTarget> StateTarget; // Offset: 0x78 // Size: 0x10
	bool bEnableSignedAxis; // Offset: 0x88 // Size: 0x01
	bool bInInteraction; // Offset: 0x89 // Size: 0x01
	char pad_0x8A[0x2]; // Offset: 0x8a // Size: 0x02
	struct FVector InteractionOrigin; // Offset: 0x8c // Size: 0x0c
	struct FVector InteractionAxis; // Offset: 0x98 // Size: 0x0c
	struct FVector InteractionStartPoint; // Offset: 0xa4 // Size: 0x0c
	struct FVector InteractionCurPoint; // Offset: 0xb0 // Size: 0x0c
	float InteractionStartParameter; // Offset: 0xbc // Size: 0x04
	float InteractionCurParameter; // Offset: 0xc0 // Size: 0x04
	float ParameterSign; // Offset: 0xc4 // Size: 0x04
	char pad_0xC8[0x10]; // Offset: 0xc8 // Size: 0x10
};

// Object Name: Class InteractiveToolsFramework.GizmoConstantAxisSource
// Size: 0x48 // Inherited bytes: 0x28
struct UGizmoConstantAxisSource : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08
	struct FVector Origin; // Offset: 0x30 // Size: 0x0c
	struct FVector Direction; // Offset: 0x3c // Size: 0x0c
};

// Object Name: Class InteractiveToolsFramework.GizmoConstantFrameAxisSource
// Size: 0x60 // Inherited bytes: 0x28
struct UGizmoConstantFrameAxisSource : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08
	struct FVector Origin; // Offset: 0x30 // Size: 0x0c
	struct FVector Direction; // Offset: 0x3c // Size: 0x0c
	struct FVector TangentX; // Offset: 0x48 // Size: 0x0c
	struct FVector TangentY; // Offset: 0x54 // Size: 0x0c
};

// Object Name: Class InteractiveToolsFramework.GizmoWorldAxisSource
// Size: 0x40 // Inherited bytes: 0x28
struct UGizmoWorldAxisSource : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08
	struct FVector Origin; // Offset: 0x30 // Size: 0x0c
	int32_t AxisIndex; // Offset: 0x3c // Size: 0x04
};

// Object Name: Class InteractiveToolsFramework.GizmoComponentAxisSource
// Size: 0x40 // Inherited bytes: 0x28
struct UGizmoComponentAxisSource : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08
	struct USceneComponent* Component; // Offset: 0x30 // Size: 0x08
	int32_t AxisIndex; // Offset: 0x38 // Size: 0x04
	bool bLocalAxes; // Offset: 0x3c // Size: 0x01
	char pad_0x3D[0x3]; // Offset: 0x3d // Size: 0x03
};

// Object Name: Class InteractiveToolsFramework.InteractiveToolPropertySet
// Size: 0x50 // Inherited bytes: 0x28
struct UInteractiveToolPropertySet : UObject {
	// Fields
	char pad_0x28[0x18]; // Offset: 0x28 // Size: 0x18
	struct UObject* CachedProperties; // Offset: 0x40 // Size: 0x08
	bool bIsPropertySetEnabled; // Offset: 0x48 // Size: 0x01
	char pad_0x49[0x7]; // Offset: 0x49 // Size: 0x07
};

// Object Name: Class InteractiveToolsFramework.BrushBaseProperties
// Size: 0x68 // Inherited bytes: 0x50
struct UBrushBaseProperties : UInteractiveToolPropertySet {
	// Fields
	float BrushSize; // Offset: 0x4c // Size: 0x04
	bool bSpecifyRadius; // Offset: 0x50 // Size: 0x01
	float BrushRadius; // Offset: 0x54 // Size: 0x04
	float BrushStrength; // Offset: 0x58 // Size: 0x04
	float BrushFalloffAmount; // Offset: 0x5c // Size: 0x04
	bool bShowStrength; // Offset: 0x60 // Size: 0x01
	bool bShowFalloff; // Offset: 0x61 // Size: 0x01
	char pad_0x63[0x5]; // Offset: 0x63 // Size: 0x05
};

// Object Name: Class InteractiveToolsFramework.InteractiveTool
// Size: 0x80 // Inherited bytes: 0x28
struct UInteractiveTool : UObject {
	// Fields
	char pad_0x28[0x20]; // Offset: 0x28 // Size: 0x20
	struct UInputBehaviorSet* InputBehaviors; // Offset: 0x48 // Size: 0x08
	struct TArray<struct UObject*> ToolPropertyObjects; // Offset: 0x50 // Size: 0x10
	char pad_0x60[0x20]; // Offset: 0x60 // Size: 0x20
};

// Object Name: Class InteractiveToolsFramework.SingleSelectionTool
// Size: 0x88 // Inherited bytes: 0x80
struct USingleSelectionTool : UInteractiveTool {
	// Fields
	char pad_0x80[0x8]; // Offset: 0x80 // Size: 0x08
};

// Object Name: Class InteractiveToolsFramework.MeshSurfacePointTool
// Size: 0xc0 // Inherited bytes: 0x88
struct UMeshSurfacePointTool : USingleSelectionTool {
	// Fields
	char pad_0x88[0x38]; // Offset: 0x88 // Size: 0x38
};

// Object Name: Class InteractiveToolsFramework.BaseBrushTool
// Size: 0x1b8 // Inherited bytes: 0xc0
struct UBaseBrushTool : UMeshSurfacePointTool {
	// Fields
	struct UBrushBaseProperties* BrushProperties; // Offset: 0xc0 // Size: 0x08
	bool bInBrushStroke; // Offset: 0xc8 // Size: 0x01
	char pad_0xC9[0x3]; // Offset: 0xc9 // Size: 0x03
	struct FBrushStampData LastBrushStamp; // Offset: 0xcc // Size: 0xa8
	char pad_0x174[0x14]; // Offset: 0x174 // Size: 0x14
	struct TSoftClassPtr<UObject> PropertyClass; // Offset: 0x188 // Size: 0x28
	struct UBrushStampIndicator* BrushStampIndicator; // Offset: 0x1b0 // Size: 0x08
};

// Object Name: Class InteractiveToolsFramework.BrushStampIndicatorBuilder
// Size: 0x28 // Inherited bytes: 0x28
struct UBrushStampIndicatorBuilder : UInteractiveGizmoBuilder {
};

// Object Name: Class InteractiveToolsFramework.BrushStampIndicator
// Size: 0xb0 // Inherited bytes: 0x38
struct UBrushStampIndicator : UInteractiveGizmo {
	// Fields
	float BrushRadius; // Offset: 0x38 // Size: 0x04
	float BrushFalloff; // Offset: 0x3c // Size: 0x04
	struct FVector BrushPosition; // Offset: 0x40 // Size: 0x0c
	struct FVector BrushNormal; // Offset: 0x4c // Size: 0x0c
	bool bDrawIndicatorLines; // Offset: 0x58 // Size: 0x01
	bool bDrawRadiusCircle; // Offset: 0x59 // Size: 0x01
	bool bDrawFalloffCircle; // Offset: 0x5a // Size: 0x01
	char pad_0x5B[0x1]; // Offset: 0x5b // Size: 0x01
	int32_t SampleStepCount; // Offset: 0x5c // Size: 0x04
	struct FLinearColor LineColor; // Offset: 0x60 // Size: 0x10
	float LineThickness; // Offset: 0x70 // Size: 0x04
	bool bDepthTested; // Offset: 0x74 // Size: 0x01
	bool bDrawSecondaryLines; // Offset: 0x75 // Size: 0x01
	char pad_0x76[0x2]; // Offset: 0x76 // Size: 0x02
	float SecondaryLineThickness; // Offset: 0x78 // Size: 0x04
	struct FLinearColor SecondaryLineColor; // Offset: 0x7c // Size: 0x10
	char pad_0x8C[0x4]; // Offset: 0x8c // Size: 0x04
	struct UPrimitiveComponent* AttachedComponent; // Offset: 0x90 // Size: 0x08
	char pad_0x98[0x18]; // Offset: 0x98 // Size: 0x18
};

// Object Name: Class InteractiveToolsFramework.ClickDragInputBehavior
// Size: 0x130 // Inherited bytes: 0x70
struct UClickDragInputBehavior : UAnyButtonInputBehavior {
	// Fields
	char pad_0x70[0xa0]; // Offset: 0x70 // Size: 0xa0
	bool bUpdateModifiersDuringDrag; // Offset: 0x110 // Size: 0x01
	char pad_0x111[0x1f]; // Offset: 0x111 // Size: 0x1f
};

// Object Name: Class InteractiveToolsFramework.LocalClickDragInputBehavior
// Size: 0x270 // Inherited bytes: 0x130
struct ULocalClickDragInputBehavior : UClickDragInputBehavior {
	// Fields
	char pad_0x130[0x140]; // Offset: 0x130 // Size: 0x140
};

// Object Name: Class InteractiveToolsFramework.InteractiveToolBuilder
// Size: 0x28 // Inherited bytes: 0x28
struct UInteractiveToolBuilder : UObject {
};

// Object Name: Class InteractiveToolsFramework.ClickDragToolBuilder
// Size: 0x28 // Inherited bytes: 0x28
struct UClickDragToolBuilder : UInteractiveToolBuilder {
};

// Object Name: Class InteractiveToolsFramework.ClickDragTool
// Size: 0x88 // Inherited bytes: 0x80
struct UClickDragTool : UInteractiveTool {
	// Fields
	char pad_0x80[0x8]; // Offset: 0x80 // Size: 0x08
};

// Object Name: Class InteractiveToolsFramework.InternalToolFrameworkActor
// Size: 0x228 // Inherited bytes: 0x228
struct AInternalToolFrameworkActor : AActor {
};

// Object Name: Class InteractiveToolsFramework.GizmoActor
// Size: 0x228 // Inherited bytes: 0x228
struct AGizmoActor : AInternalToolFrameworkActor {
};

// Object Name: Class InteractiveToolsFramework.GizmoBaseComponent
// Size: 0x590 // Inherited bytes: 0x570
struct UGizmoBaseComponent : UPrimitiveComponent {
	// Fields
	struct FLinearColor Color; // Offset: 0x570 // Size: 0x10
	float HoverSizeMultiplier; // Offset: 0x580 // Size: 0x04
	float PixelHitDistanceThreshold; // Offset: 0x584 // Size: 0x04
	char pad_0x588[0x8]; // Offset: 0x588 // Size: 0x08

	// Functions

	// Object Name: Function InteractiveToolsFramework.GizmoBaseComponent.UpdateWorldLocalState
	// Flags: [Final|Native|Public]
	void UpdateWorldLocalState(bool bWorldIn); // Offset: 0x105132874 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function InteractiveToolsFramework.GizmoBaseComponent.UpdateHoverState
	// Flags: [Final|Native|Public]
	void UpdateHoverState(bool bHoveringIn); // Offset: 0x105132904 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class InteractiveToolsFramework.GizmoArrowComponent
// Size: 0x5b0 // Inherited bytes: 0x590
struct UGizmoArrowComponent : UGizmoBaseComponent {
	// Fields
	struct FVector Direction; // Offset: 0x590 // Size: 0x0c
	float Gap; // Offset: 0x59c // Size: 0x04
	float Length; // Offset: 0x5a0 // Size: 0x04
	float Thickness; // Offset: 0x5a4 // Size: 0x04
	char pad_0x5A8[0x8]; // Offset: 0x5a8 // Size: 0x08
};

// Object Name: Class InteractiveToolsFramework.GizmoBoxComponent
// Size: 0x5d0 // Inherited bytes: 0x590
struct UGizmoBoxComponent : UGizmoBaseComponent {
	// Fields
	struct FVector Origin; // Offset: 0x590 // Size: 0x0c
	char pad_0x59C[0x4]; // Offset: 0x59c // Size: 0x04
	struct FQuat Rotation; // Offset: 0x5a0 // Size: 0x10
	struct FVector Dimensions; // Offset: 0x5b0 // Size: 0x0c
	float LineThickness; // Offset: 0x5bc // Size: 0x04
	bool bRemoveHiddenLines; // Offset: 0x5c0 // Size: 0x01
	bool bEnableAxisFlip; // Offset: 0x5c1 // Size: 0x01
	char pad_0x5C2[0xe]; // Offset: 0x5c2 // Size: 0x0e
};

// Object Name: Class InteractiveToolsFramework.GizmoCircleComponent
// Size: 0x5b0 // Inherited bytes: 0x590
struct UGizmoCircleComponent : UGizmoBaseComponent {
	// Fields
	struct FVector Normal; // Offset: 0x590 // Size: 0x0c
	float Radius; // Offset: 0x59c // Size: 0x04
	float Thickness; // Offset: 0x5a0 // Size: 0x04
	int32_t NumSides; // Offset: 0x5a4 // Size: 0x04
	bool bViewAligned; // Offset: 0x5a8 // Size: 0x01
	bool bOnlyAllowFrontFacingHits; // Offset: 0x5a9 // Size: 0x01
	char pad_0x5AA[0x6]; // Offset: 0x5aa // Size: 0x06
};

// Object Name: Class InteractiveToolsFramework.GizmoTransformSource
// Size: 0x28 // Inherited bytes: 0x28
struct UGizmoTransformSource : UInterface {
	// Functions

	// Object Name: Function InteractiveToolsFramework.GizmoTransformSource.SetTransform
	// Flags: [Native|Public|HasOutParms|HasDefaults]
	void SetTransform(struct FTransform& NewTransform); // Offset: 0x1051331a0 // Return & Params: Num(1) Size(0x30)

	// Object Name: Function InteractiveToolsFramework.GizmoTransformSource.GetTransform
	// Flags: [Native|Public|HasDefaults|Const]
	struct FTransform GetTransform(); // Offset: 0x105133288 // Return & Params: Num(1) Size(0x30)
};

// Object Name: Class InteractiveToolsFramework.GizmoAxisSource
// Size: 0x28 // Inherited bytes: 0x28
struct UGizmoAxisSource : UInterface {
	// Functions

	// Object Name: Function InteractiveToolsFramework.GizmoAxisSource.HasTangentVectors
	// Flags: [Native|Public|Const]
	bool HasTangentVectors(); // Offset: 0x105133804 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function InteractiveToolsFramework.GizmoAxisSource.GetTangentVectors
	// Flags: [Native|Public|HasOutParms|HasDefaults|Const]
	void GetTangentVectors(struct FVector& TangentXOut, struct FVector& TangentYOut); // Offset: 0x105133718 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function InteractiveToolsFramework.GizmoAxisSource.GetOrigin
	// Flags: [Native|Public|HasDefaults|Const]
	struct FVector GetOrigin(); // Offset: 0x105133880 // Return & Params: Num(1) Size(0xc)

	// Object Name: Function InteractiveToolsFramework.GizmoAxisSource.GetDirection
	// Flags: [Native|Public|HasDefaults|Const]
	struct FVector GetDirection(); // Offset: 0x105133840 // Return & Params: Num(1) Size(0xc)
};

// Object Name: Class InteractiveToolsFramework.GizmoClickTarget
// Size: 0x28 // Inherited bytes: 0x28
struct UGizmoClickTarget : UInterface {
	// Functions

	// Object Name: Function InteractiveToolsFramework.GizmoClickTarget.UpdateHoverState
	// Flags: [Native|Public|Const]
	void UpdateHoverState(bool bHovering); // Offset: 0x105133cb4 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class InteractiveToolsFramework.GizmoStateTarget
// Size: 0x28 // Inherited bytes: 0x28
struct UGizmoStateTarget : UInterface {
	// Functions

	// Object Name: Function InteractiveToolsFramework.GizmoStateTarget.EndUpdate
	// Flags: [Native|Public]
	void EndUpdate(); // Offset: 0x105134054 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function InteractiveToolsFramework.GizmoStateTarget.BeginUpdate
	// Flags: [Native|Public]
	void BeginUpdate(); // Offset: 0x105134070 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class InteractiveToolsFramework.GizmoFloatParameterSource
// Size: 0x28 // Inherited bytes: 0x28
struct UGizmoFloatParameterSource : UInterface {
	// Functions

	// Object Name: Function InteractiveToolsFramework.GizmoFloatParameterSource.SetParameter
	// Flags: [Native|Public]
	void SetParameter(float NewValue); // Offset: 0x1051343f8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function InteractiveToolsFramework.GizmoFloatParameterSource.GetParameter
	// Flags: [Native|Public|Const]
	float GetParameter(); // Offset: 0x10513449c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function InteractiveToolsFramework.GizmoFloatParameterSource.EndModify
	// Flags: [Native|Public]
	void EndModify(); // Offset: 0x1051343dc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function InteractiveToolsFramework.GizmoFloatParameterSource.BeginModify
	// Flags: [Native|Public]
	void BeginModify(); // Offset: 0x105134480 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class InteractiveToolsFramework.GizmoVec2ParameterSource
// Size: 0x28 // Inherited bytes: 0x28
struct UGizmoVec2ParameterSource : UInterface {
	// Functions

	// Object Name: Function InteractiveToolsFramework.GizmoVec2ParameterSource.SetParameter
	// Flags: [Native|Public|HasOutParms|HasDefaults]
	void SetParameter(struct FVector2D& NewValue); // Offset: 0x1051348dc // Return & Params: Num(1) Size(0x8)

	// Object Name: Function InteractiveToolsFramework.GizmoVec2ParameterSource.GetParameter
	// Flags: [Native|Public|HasDefaults|Const]
	struct FVector2D GetParameter(); // Offset: 0x105134988 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function InteractiveToolsFramework.GizmoVec2ParameterSource.EndModify
	// Flags: [Native|Public]
	void EndModify(); // Offset: 0x1051348c0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function InteractiveToolsFramework.GizmoVec2ParameterSource.BeginModify
	// Flags: [Native|Public]
	void BeginModify(); // Offset: 0x10513496c // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class InteractiveToolsFramework.GizmoLineHandleComponent
// Size: 0x5c0 // Inherited bytes: 0x590
struct UGizmoLineHandleComponent : UGizmoBaseComponent {
	// Fields
	struct FVector Normal; // Offset: 0x590 // Size: 0x0c
	float HandleSize; // Offset: 0x59c // Size: 0x04
	float Thickness; // Offset: 0x5a0 // Size: 0x04
	struct FVector Direction; // Offset: 0x5a4 // Size: 0x0c
	float Length; // Offset: 0x5b0 // Size: 0x04
	bool bImageScale; // Offset: 0x5b4 // Size: 0x01
	char pad_0x5B5[0xb]; // Offset: 0x5b5 // Size: 0x0b
};

// Object Name: Class InteractiveToolsFramework.GizmoRectangleComponent
// Size: 0x5c0 // Inherited bytes: 0x590
struct UGizmoRectangleComponent : UGizmoBaseComponent {
	// Fields
	struct FVector DirectionX; // Offset: 0x590 // Size: 0x0c
	struct FVector DirectionY; // Offset: 0x59c // Size: 0x0c
	float OffsetX; // Offset: 0x5a8 // Size: 0x04
	float OffsetY; // Offset: 0x5ac // Size: 0x04
	float LengthX; // Offset: 0x5b0 // Size: 0x04
	float LengthY; // Offset: 0x5b4 // Size: 0x04
	float Thickness; // Offset: 0x5b8 // Size: 0x04
	char SegmentFlags; // Offset: 0x5bc // Size: 0x01
	char pad_0x5BD[0x3]; // Offset: 0x5bd // Size: 0x03
};

// Object Name: Class InteractiveToolsFramework.GizmoLambdaHitTarget
// Size: 0xb0 // Inherited bytes: 0x28
struct UGizmoLambdaHitTarget : UObject {
	// Fields
	char pad_0x28[0x88]; // Offset: 0x28 // Size: 0x88
};

// Object Name: Class InteractiveToolsFramework.GizmoComponentHitTarget
// Size: 0x80 // Inherited bytes: 0x28
struct UGizmoComponentHitTarget : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08
	struct UPrimitiveComponent* Component; // Offset: 0x30 // Size: 0x08
	char pad_0x38[0x48]; // Offset: 0x38 // Size: 0x48
};

// Object Name: Class InteractiveToolsFramework.InputBehaviorSet
// Size: 0x38 // Inherited bytes: 0x28
struct UInputBehaviorSet : UObject {
	// Fields
	struct TArray<struct FBehaviorInfo> Behaviors; // Offset: 0x28 // Size: 0x10
};

// Object Name: Class InteractiveToolsFramework.InputBehaviorSource
// Size: 0x28 // Inherited bytes: 0x28
struct UInputBehaviorSource : UInterface {
};

// Object Name: Class InteractiveToolsFramework.InputRouter
// Size: 0xb0 // Inherited bytes: 0x28
struct UInputRouter : UObject {
	// Fields
	bool bAutoInvalidateOnHover; // Offset: 0x28 // Size: 0x01
	bool bAutoInvalidateOnCapture; // Offset: 0x29 // Size: 0x01
	char pad_0x2A[0xe]; // Offset: 0x2a // Size: 0x0e
	struct UInputBehaviorSet* ActiveInputBehaviors; // Offset: 0x38 // Size: 0x08
	char pad_0x40[0x70]; // Offset: 0x40 // Size: 0x70
};

// Object Name: Class InteractiveToolsFramework.InteractionMechanic
// Size: 0x30 // Inherited bytes: 0x28
struct UInteractionMechanic : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08
};

// Object Name: Class InteractiveToolsFramework.InteractiveGizmoManager
// Size: 0xb8 // Inherited bytes: 0x28
struct UInteractiveGizmoManager : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08
	struct TArray<struct FActiveGizmo> ActiveGizmos; // Offset: 0x30 // Size: 0x10
	char pad_0x40[0x18]; // Offset: 0x40 // Size: 0x18
	struct TMap<struct FString, struct UInteractiveGizmoBuilder*> GizmoBuilders; // Offset: 0x58 // Size: 0x50
	char pad_0xA8[0x10]; // Offset: 0xa8 // Size: 0x10
};

// Object Name: Class InteractiveToolsFramework.ToolContextTransactionProvider
// Size: 0x28 // Inherited bytes: 0x28
struct UToolContextTransactionProvider : UInterface {
};

// Object Name: Class InteractiveToolsFramework.InteractiveToolManager
// Size: 0x138 // Inherited bytes: 0x28
struct UInteractiveToolManager : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08
	struct UInteractiveTool* ActiveLeftTool; // Offset: 0x30 // Size: 0x08
	struct UInteractiveTool* ActiveRightTool; // Offset: 0x38 // Size: 0x08
	char pad_0x40[0x50]; // Offset: 0x40 // Size: 0x50
	struct TMap<struct FString, struct UInteractiveToolBuilder*> ToolBuilders; // Offset: 0x90 // Size: 0x50
	char pad_0xE0[0x58]; // Offset: 0xe0 // Size: 0x58
};

// Object Name: Class InteractiveToolsFramework.ToolFrameworkComponent
// Size: 0x28 // Inherited bytes: 0x28
struct UToolFrameworkComponent : UInterface {
};

// Object Name: Class InteractiveToolsFramework.InteractiveToolsContext
// Size: 0x98 // Inherited bytes: 0x28
struct UInteractiveToolsContext : UObject {
	// Fields
	char pad_0x28[0x30]; // Offset: 0x28 // Size: 0x30
	struct UInputRouter* InputRouter; // Offset: 0x58 // Size: 0x08
	struct UInteractiveToolManager* ToolManager; // Offset: 0x60 // Size: 0x08
	struct UInteractiveGizmoManager* GizmoManager; // Offset: 0x68 // Size: 0x08
	struct TSoftClassPtr<UObject> ToolManagerClass; // Offset: 0x70 // Size: 0x28
};

// Object Name: Class InteractiveToolsFramework.IntervalGizmoActor
// Size: 0x240 // Inherited bytes: 0x228
struct AIntervalGizmoActor : AGizmoActor {
	// Fields
	struct UGizmoLineHandleComponent* UpIntervalComponent; // Offset: 0x228 // Size: 0x08
	struct UGizmoLineHandleComponent* DownIntervalComponent; // Offset: 0x230 // Size: 0x08
	struct UGizmoLineHandleComponent* ForwardIntervalComponent; // Offset: 0x238 // Size: 0x08
};

// Object Name: Class InteractiveToolsFramework.IntervalGizmoBuilder
// Size: 0xc0 // Inherited bytes: 0x28
struct UIntervalGizmoBuilder : UInteractiveGizmoBuilder {
	// Fields
	char pad_0x28[0x98]; // Offset: 0x28 // Size: 0x98
};

// Object Name: Class InteractiveToolsFramework.IntervalGizmo
// Size: 0x130 // Inherited bytes: 0x38
struct UIntervalGizmo : UInteractiveGizmo {
	// Fields
	struct UGizmoTransformChangeStateTarget* StateTarget; // Offset: 0x38 // Size: 0x08
	char pad_0x40[0x10]; // Offset: 0x40 // Size: 0x10
	struct UTransformProxy* TransformProxy; // Offset: 0x50 // Size: 0x08
	struct TArray<struct UPrimitiveComponent*> ActiveComponents; // Offset: 0x58 // Size: 0x10
	struct TArray<struct UInteractiveGizmo*> ActiveGizmos; // Offset: 0x68 // Size: 0x10
	char pad_0x78[0x18]; // Offset: 0x78 // Size: 0x18
	struct UGizmoComponentAxisSource* AxisYSource; // Offset: 0x90 // Size: 0x08
	struct UGizmoComponentAxisSource* AxisZSource; // Offset: 0x98 // Size: 0x08
	char pad_0xA0[0x90]; // Offset: 0xa0 // Size: 0x90
};

// Object Name: Class InteractiveToolsFramework.GizmoBaseFloatParameterSource
// Size: 0x48 // Inherited bytes: 0x28
struct UGizmoBaseFloatParameterSource : UObject {
	// Fields
	char pad_0x28[0x20]; // Offset: 0x28 // Size: 0x20
};

// Object Name: Class InteractiveToolsFramework.GizmoAxisIntervalParameterSource
// Size: 0x60 // Inherited bytes: 0x48
struct UGizmoAxisIntervalParameterSource : UGizmoBaseFloatParameterSource {
	// Fields
	struct TScriptInterface<IGizmoFloatParameterSource> FloatParameterSource; // Offset: 0x48 // Size: 0x10
	float MinParameter; // Offset: 0x58 // Size: 0x04
	float MaxParameter; // Offset: 0x5c // Size: 0x04
};

// Object Name: Class InteractiveToolsFramework.KeyAsModifierInputBehavior
// Size: 0x110 // Inherited bytes: 0x30
struct UKeyAsModifierInputBehavior : UInputBehavior {
	// Fields
	char pad_0x30[0xe0]; // Offset: 0x30 // Size: 0xe0
};

// Object Name: Class InteractiveToolsFramework.MeshSurfacePointToolBuilder
// Size: 0x30 // Inherited bytes: 0x28
struct UMeshSurfacePointToolBuilder : UInteractiveToolBuilder {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08
};

// Object Name: Class InteractiveToolsFramework.MouseHoverBehavior
// Size: 0x98 // Inherited bytes: 0x30
struct UMouseHoverBehavior : UInputBehavior {
	// Fields
	char pad_0x30[0x68]; // Offset: 0x30 // Size: 0x68
};

// Object Name: Class InteractiveToolsFramework.MultiClickSequenceInputBehavior
// Size: 0x120 // Inherited bytes: 0x70
struct UMultiClickSequenceInputBehavior : UAnyButtonInputBehavior {
	// Fields
	char pad_0x70[0xb0]; // Offset: 0x70 // Size: 0xb0
};

// Object Name: Class InteractiveToolsFramework.MultiSelectionTool
// Size: 0x90 // Inherited bytes: 0x80
struct UMultiSelectionTool : UInteractiveTool {
	// Fields
	char pad_0x80[0x10]; // Offset: 0x80 // Size: 0x10
};

// Object Name: Class InteractiveToolsFramework.GizmoLocalFloatParameterSource
// Size: 0x58 // Inherited bytes: 0x48
struct UGizmoLocalFloatParameterSource : UGizmoBaseFloatParameterSource {
	// Fields
	float Value; // Offset: 0x48 // Size: 0x04
	struct FGizmoFloatParameterChange LastChange; // Offset: 0x4c // Size: 0x08
	char pad_0x54[0x4]; // Offset: 0x54 // Size: 0x04
};

// Object Name: Class InteractiveToolsFramework.GizmoBaseVec2ParameterSource
// Size: 0x48 // Inherited bytes: 0x28
struct UGizmoBaseVec2ParameterSource : UObject {
	// Fields
	char pad_0x28[0x20]; // Offset: 0x28 // Size: 0x20
};

// Object Name: Class InteractiveToolsFramework.GizmoLocalVec2ParameterSource
// Size: 0x60 // Inherited bytes: 0x48
struct UGizmoLocalVec2ParameterSource : UGizmoBaseVec2ParameterSource {
	// Fields
	struct FVector2D Value; // Offset: 0x48 // Size: 0x08
	struct FGizmoVec2ParameterChange LastChange; // Offset: 0x50 // Size: 0x10
};

// Object Name: Class InteractiveToolsFramework.GizmoAxisTranslationParameterSource
// Size: 0x110 // Inherited bytes: 0x48
struct UGizmoAxisTranslationParameterSource : UGizmoBaseFloatParameterSource {
	// Fields
	char pad_0x48[0x48]; // Offset: 0x48 // Size: 0x48
	struct TScriptInterface<IGizmoAxisSource> AxisSource; // Offset: 0x90 // Size: 0x10
	struct TScriptInterface<IGizmoTransformSource> TransformSource; // Offset: 0xa0 // Size: 0x10
	float Parameter; // Offset: 0xb0 // Size: 0x04
	struct FGizmoFloatParameterChange LastChange; // Offset: 0xb4 // Size: 0x08
	struct FVector CurTranslationAxis; // Offset: 0xbc // Size: 0x0c
	struct FVector CurTranslationOrigin; // Offset: 0xc8 // Size: 0x0c
	char pad_0xD4[0xc]; // Offset: 0xd4 // Size: 0x0c
	struct FTransform InitialTransform; // Offset: 0xe0 // Size: 0x30
};

// Object Name: Class InteractiveToolsFramework.GizmoPlaneTranslationParameterSource
// Size: 0x130 // Inherited bytes: 0x48
struct UGizmoPlaneTranslationParameterSource : UGizmoBaseVec2ParameterSource {
	// Fields
	char pad_0x48[0x48]; // Offset: 0x48 // Size: 0x48
	struct TScriptInterface<IGizmoAxisSource> AxisSource; // Offset: 0x90 // Size: 0x10
	struct TScriptInterface<IGizmoTransformSource> TransformSource; // Offset: 0xa0 // Size: 0x10
	struct FVector2D Parameter; // Offset: 0xb0 // Size: 0x08
	struct FGizmoVec2ParameterChange LastChange; // Offset: 0xb8 // Size: 0x10
	struct FVector CurTranslationOrigin; // Offset: 0xc8 // Size: 0x0c
	struct FVector CurTranslationNormal; // Offset: 0xd4 // Size: 0x0c
	struct FVector CurTranslationAxisX; // Offset: 0xe0 // Size: 0x0c
	struct FVector CurTranslationAxisY; // Offset: 0xec // Size: 0x0c
	char pad_0xF8[0x8]; // Offset: 0xf8 // Size: 0x08
	struct FTransform InitialTransform; // Offset: 0x100 // Size: 0x30
};

// Object Name: Class InteractiveToolsFramework.GizmoAxisRotationParameterSource
// Size: 0xc0 // Inherited bytes: 0x48
struct UGizmoAxisRotationParameterSource : UGizmoBaseFloatParameterSource {
	// Fields
	struct TScriptInterface<IGizmoAxisSource> AxisSource; // Offset: 0x48 // Size: 0x10
	struct TScriptInterface<IGizmoTransformSource> TransformSource; // Offset: 0x58 // Size: 0x10
	float Angle; // Offset: 0x68 // Size: 0x04
	struct FGizmoFloatParameterChange LastChange; // Offset: 0x6c // Size: 0x08
	struct FVector CurRotationAxis; // Offset: 0x74 // Size: 0x0c
	struct FVector CurRotationOrigin; // Offset: 0x80 // Size: 0x0c
	char pad_0x8C[0x4]; // Offset: 0x8c // Size: 0x04
	struct FTransform InitialTransform; // Offset: 0x90 // Size: 0x30
};

// Object Name: Class InteractiveToolsFramework.GizmoUniformScaleParameterSource
// Size: 0xf0 // Inherited bytes: 0x48
struct UGizmoUniformScaleParameterSource : UGizmoBaseVec2ParameterSource {
	// Fields
	struct TScriptInterface<IGizmoAxisSource> AxisSource; // Offset: 0x48 // Size: 0x10
	struct TScriptInterface<IGizmoTransformSource> TransformSource; // Offset: 0x58 // Size: 0x10
	float ScaleMultiplier; // Offset: 0x68 // Size: 0x04
	struct FVector2D Parameter; // Offset: 0x6c // Size: 0x08
	struct FGizmoVec2ParameterChange LastChange; // Offset: 0x74 // Size: 0x10
	struct FVector CurScaleOrigin; // Offset: 0x84 // Size: 0x0c
	struct FVector CurScaleNormal; // Offset: 0x90 // Size: 0x0c
	struct FVector CurScaleAxisX; // Offset: 0x9c // Size: 0x0c
	struct FVector CurScaleAxisY; // Offset: 0xa8 // Size: 0x0c
	char pad_0xB4[0xc]; // Offset: 0xb4 // Size: 0x0c
	struct FTransform InitialTransform; // Offset: 0xc0 // Size: 0x30
};

// Object Name: Class InteractiveToolsFramework.GizmoAxisScaleParameterSource
// Size: 0xc0 // Inherited bytes: 0x48
struct UGizmoAxisScaleParameterSource : UGizmoBaseFloatParameterSource {
	// Fields
	struct TScriptInterface<IGizmoAxisSource> AxisSource; // Offset: 0x48 // Size: 0x10
	struct TScriptInterface<IGizmoTransformSource> TransformSource; // Offset: 0x58 // Size: 0x10
	float ScaleMultiplier; // Offset: 0x68 // Size: 0x04
	float Parameter; // Offset: 0x6c // Size: 0x04
	struct FGizmoFloatParameterChange LastChange; // Offset: 0x70 // Size: 0x08
	struct FVector CurScaleAxis; // Offset: 0x78 // Size: 0x0c
	struct FVector CurScaleOrigin; // Offset: 0x84 // Size: 0x0c
	struct FTransform InitialTransform; // Offset: 0x90 // Size: 0x30
};

// Object Name: Class InteractiveToolsFramework.GizmoPlaneScaleParameterSource
// Size: 0x130 // Inherited bytes: 0x48
struct UGizmoPlaneScaleParameterSource : UGizmoBaseVec2ParameterSource {
	// Fields
	char pad_0x48[0x48]; // Offset: 0x48 // Size: 0x48
	struct TScriptInterface<IGizmoAxisSource> AxisSource; // Offset: 0x90 // Size: 0x10
	struct TScriptInterface<IGizmoTransformSource> TransformSource; // Offset: 0xa0 // Size: 0x10
	float ScaleMultiplier; // Offset: 0xb0 // Size: 0x04
	struct FVector2D Parameter; // Offset: 0xb4 // Size: 0x08
	struct FGizmoVec2ParameterChange LastChange; // Offset: 0xbc // Size: 0x10
	struct FVector CurScaleOrigin; // Offset: 0xcc // Size: 0x0c
	struct FVector CurScaleNormal; // Offset: 0xd8 // Size: 0x0c
	struct FVector CurScaleAxisX; // Offset: 0xe4 // Size: 0x0c
	struct FVector CurScaleAxisY; // Offset: 0xf0 // Size: 0x0c
	char pad_0xFC[0x4]; // Offset: 0xfc // Size: 0x04
	struct FTransform InitialTransform; // Offset: 0x100 // Size: 0x30
};

// Object Name: Class InteractiveToolsFramework.PlanePositionGizmoBuilder
// Size: 0x28 // Inherited bytes: 0x28
struct UPlanePositionGizmoBuilder : UInteractiveGizmoBuilder {
};

// Object Name: Class InteractiveToolsFramework.PlanePositionGizmo
// Size: 0x100 // Inherited bytes: 0x38
struct UPlanePositionGizmo : UInteractiveGizmo {
	// Fields
	char pad_0x38[0x10]; // Offset: 0x38 // Size: 0x10
	struct TScriptInterface<IGizmoAxisSource> AxisSource; // Offset: 0x48 // Size: 0x10
	struct TScriptInterface<IGizmoVec2ParameterSource> ParameterSource; // Offset: 0x58 // Size: 0x10
	struct TScriptInterface<IGizmoClickTarget> HitTarget; // Offset: 0x68 // Size: 0x10
	struct TScriptInterface<IGizmoStateTarget> StateTarget; // Offset: 0x78 // Size: 0x10
	bool bEnableSignedAxis; // Offset: 0x88 // Size: 0x01
	bool bFlipX; // Offset: 0x89 // Size: 0x01
	bool bFlipY; // Offset: 0x8a // Size: 0x01
	bool bInInteraction; // Offset: 0x8b // Size: 0x01
	struct FVector InteractionOrigin; // Offset: 0x8c // Size: 0x0c
	struct FVector InteractionNormal; // Offset: 0x98 // Size: 0x0c
	struct FVector InteractionAxisX; // Offset: 0xa4 // Size: 0x0c
	struct FVector InteractionAxisY; // Offset: 0xb0 // Size: 0x0c
	struct FVector InteractionStartPoint; // Offset: 0xbc // Size: 0x0c
	struct FVector InteractionCurPoint; // Offset: 0xc8 // Size: 0x0c
	struct FVector2D InteractionStartParameter; // Offset: 0xd4 // Size: 0x08
	struct FVector2D InteractionCurParameter; // Offset: 0xdc // Size: 0x08
	struct FVector2D ParameterSigns; // Offset: 0xe4 // Size: 0x08
	char pad_0xEC[0x14]; // Offset: 0xec // Size: 0x14
};

// Object Name: Class InteractiveToolsFramework.SelectionSet
// Size: 0x40 // Inherited bytes: 0x28
struct USelectionSet : UObject {
	// Fields
	char pad_0x28[0x18]; // Offset: 0x28 // Size: 0x18
};

// Object Name: Class InteractiveToolsFramework.MeshSelectionSet
// Size: 0x80 // Inherited bytes: 0x40
struct UMeshSelectionSet : USelectionSet {
	// Fields
	struct TArray<int32_t> Vertices; // Offset: 0x40 // Size: 0x10
	struct TArray<int32_t> Edges; // Offset: 0x50 // Size: 0x10
	struct TArray<int32_t> Faces; // Offset: 0x60 // Size: 0x10
	struct TArray<int32_t> Groups; // Offset: 0x70 // Size: 0x10
};

// Object Name: Class InteractiveToolsFramework.SingleClickInputBehavior
// Size: 0x120 // Inherited bytes: 0x70
struct USingleClickInputBehavior : UAnyButtonInputBehavior {
	// Fields
	char pad_0x70[0x40]; // Offset: 0x70 // Size: 0x40
	bool HitTestOnRelease; // Offset: 0xb0 // Size: 0x01
	char pad_0xB1[0x6f]; // Offset: 0xb1 // Size: 0x6f
};

// Object Name: Class InteractiveToolsFramework.SingleClickToolBuilder
// Size: 0x28 // Inherited bytes: 0x28
struct USingleClickToolBuilder : UInteractiveToolBuilder {
};

// Object Name: Class InteractiveToolsFramework.SingleClickTool
// Size: 0x88 // Inherited bytes: 0x80
struct USingleClickTool : UInteractiveTool {
	// Fields
	char pad_0x80[0x8]; // Offset: 0x80 // Size: 0x08
};

// Object Name: Class InteractiveToolsFramework.GizmoNilStateTarget
// Size: 0x30 // Inherited bytes: 0x28
struct UGizmoNilStateTarget : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08
};

// Object Name: Class InteractiveToolsFramework.GizmoLambdaStateTarget
// Size: 0xb0 // Inherited bytes: 0x28
struct UGizmoLambdaStateTarget : UObject {
	// Fields
	char pad_0x28[0x88]; // Offset: 0x28 // Size: 0x88
};

// Object Name: Class InteractiveToolsFramework.GizmoObjectModifyStateTarget
// Size: 0x58 // Inherited bytes: 0x28
struct UGizmoObjectModifyStateTarget : UObject {
	// Fields
	char pad_0x28[0x30]; // Offset: 0x28 // Size: 0x30
};

// Object Name: Class InteractiveToolsFramework.GizmoTransformChangeStateTarget
// Size: 0xe0 // Inherited bytes: 0x28
struct UGizmoTransformChangeStateTarget : UObject {
	// Fields
	char pad_0x28[0x28]; // Offset: 0x28 // Size: 0x28
	struct TScriptInterface<IToolContextTransactionProvider> TransactionManager; // Offset: 0x50 // Size: 0x10
	char pad_0x60[0x80]; // Offset: 0x60 // Size: 0x80
};

// Object Name: Class InteractiveToolsFramework.TransformGizmoActor
// Size: 0x2a8 // Inherited bytes: 0x228
struct ATransformGizmoActor : AGizmoActor {
	// Fields
	struct UPrimitiveComponent* TranslateX; // Offset: 0x228 // Size: 0x08
	struct UPrimitiveComponent* TranslateY; // Offset: 0x230 // Size: 0x08
	struct UPrimitiveComponent* TranslateZ; // Offset: 0x238 // Size: 0x08
	struct UPrimitiveComponent* TranslateYZ; // Offset: 0x240 // Size: 0x08
	struct UPrimitiveComponent* TranslateXZ; // Offset: 0x248 // Size: 0x08
	struct UPrimitiveComponent* TranslateXY; // Offset: 0x250 // Size: 0x08
	struct UPrimitiveComponent* RotateX; // Offset: 0x258 // Size: 0x08
	struct UPrimitiveComponent* RotateY; // Offset: 0x260 // Size: 0x08
	struct UPrimitiveComponent* RotateZ; // Offset: 0x268 // Size: 0x08
	struct UPrimitiveComponent* UniformScale; // Offset: 0x270 // Size: 0x08
	struct UPrimitiveComponent* AxisScaleX; // Offset: 0x278 // Size: 0x08
	struct UPrimitiveComponent* AxisScaleY; // Offset: 0x280 // Size: 0x08
	struct UPrimitiveComponent* AxisScaleZ; // Offset: 0x288 // Size: 0x08
	struct UPrimitiveComponent* PlaneScaleYZ; // Offset: 0x290 // Size: 0x08
	struct UPrimitiveComponent* PlaneScaleXZ; // Offset: 0x298 // Size: 0x08
	struct UPrimitiveComponent* PlaneScaleXY; // Offset: 0x2a0 // Size: 0x08
};

// Object Name: Class InteractiveToolsFramework.TransformGizmoBuilder
// Size: 0xc0 // Inherited bytes: 0x28
struct UTransformGizmoBuilder : UInteractiveGizmoBuilder {
	// Fields
	char pad_0x28[0x98]; // Offset: 0x28 // Size: 0x98
};

// Object Name: Class InteractiveToolsFramework.TransformGizmo
// Size: 0x180 // Inherited bytes: 0x38
struct UTransformGizmo : UInteractiveGizmo {
	// Fields
	char pad_0x38[0x8]; // Offset: 0x38 // Size: 0x08
	struct UTransformProxy* ActiveTarget; // Offset: 0x40 // Size: 0x08
	bool bSnapToWorldGrid; // Offset: 0x48 // Size: 0x01
	bool bUseContextCoordinateSystem; // Offset: 0x49 // Size: 0x01
	char pad_0x4A[0x2]; // Offset: 0x4a // Size: 0x02
	enum class EToolContextCoordinateSystem CurrentCoordinateSystem; // Offset: 0x4c // Size: 0x04
	char pad_0x50[0x90]; // Offset: 0x50 // Size: 0x90
	struct TArray<struct UPrimitiveComponent*> ActiveComponents; // Offset: 0xe0 // Size: 0x10
	struct TArray<struct UPrimitiveComponent*> NonuniformScaleComponents; // Offset: 0xf0 // Size: 0x10
	struct TArray<struct UInteractiveGizmo*> ActiveGizmos; // Offset: 0x100 // Size: 0x10
	char pad_0x110[0x10]; // Offset: 0x110 // Size: 0x10
	struct UGizmoConstantFrameAxisSource* CameraAxisSource; // Offset: 0x120 // Size: 0x08
	struct UGizmoComponentAxisSource* AxisXSource; // Offset: 0x128 // Size: 0x08
	struct UGizmoComponentAxisSource* AxisYSource; // Offset: 0x130 // Size: 0x08
	struct UGizmoComponentAxisSource* AxisZSource; // Offset: 0x138 // Size: 0x08
	struct UGizmoComponentAxisSource* UnitAxisXSource; // Offset: 0x140 // Size: 0x08
	struct UGizmoComponentAxisSource* UnitAxisYSource; // Offset: 0x148 // Size: 0x08
	struct UGizmoComponentAxisSource* UnitAxisZSource; // Offset: 0x150 // Size: 0x08
	struct UGizmoTransformChangeStateTarget* StateTarget; // Offset: 0x158 // Size: 0x08
	struct UGizmoScaledTransformSource* ScaledTransformSource; // Offset: 0x160 // Size: 0x08
	char pad_0x168[0x18]; // Offset: 0x168 // Size: 0x18
};

// Object Name: Class InteractiveToolsFramework.TransformProxy
// Size: 0xf0 // Inherited bytes: 0x28
struct UTransformProxy : UObject {
	// Fields
	char pad_0x28[0x48]; // Offset: 0x28 // Size: 0x48
	bool bRotatePerObject; // Offset: 0x70 // Size: 0x01
	bool bSetPivotMode; // Offset: 0x71 // Size: 0x01
	char pad_0x72[0x1e]; // Offset: 0x72 // Size: 0x1e
	struct FTransform SharedTransform; // Offset: 0x90 // Size: 0x30
	struct FTransform InitialSharedTransform; // Offset: 0xc0 // Size: 0x30
};

// Object Name: Class InteractiveToolsFramework.GizmoBaseTransformSource
// Size: 0x48 // Inherited bytes: 0x28
struct UGizmoBaseTransformSource : UObject {
	// Fields
	char pad_0x28[0x20]; // Offset: 0x28 // Size: 0x20
};

// Object Name: Class InteractiveToolsFramework.GizmoComponentWorldTransformSource
// Size: 0x58 // Inherited bytes: 0x48
struct UGizmoComponentWorldTransformSource : UGizmoBaseTransformSource {
	// Fields
	struct USceneComponent* Component; // Offset: 0x48 // Size: 0x08
	bool bModifyComponentOnTransform; // Offset: 0x50 // Size: 0x01
	char pad_0x51[0x7]; // Offset: 0x51 // Size: 0x07
};

// Object Name: Class InteractiveToolsFramework.GizmoScaledTransformSource
// Size: 0xe0 // Inherited bytes: 0x48
struct UGizmoScaledTransformSource : UGizmoBaseTransformSource {
	// Fields
	struct TScriptInterface<IGizmoTransformSource> ChildTransformSource; // Offset: 0x48 // Size: 0x10
	char pad_0x58[0x88]; // Offset: 0x58 // Size: 0x88
};

// Object Name: Class InteractiveToolsFramework.GizmoTransformProxyTransformSource
// Size: 0x50 // Inherited bytes: 0x48
struct UGizmoTransformProxyTransformSource : UGizmoBaseTransformSource {
	// Fields
	struct UTransformProxy* Proxy; // Offset: 0x48 // Size: 0x08
};

