#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum LLHSDK.ELLHSDKNetworkType
enum class ELLHSDKNetworkType : uint8 {
	Unknown = 0,
	NotConnected = 1,
	Type_WiFi = 2,
	Type_Unknown_Cell = 3,
	Type_2G = 4,
	Type_3G = 5,
	Type_4G = 6,
	Type_5G = 7,
	ELLHSDKNetworkType_MAX = 8
};

// Object Name: Enum LLHSDK.ELLHSDKLoginType
enum class ELLHSDKLoginType : uint8 {
	TYPE_NONE = 0,
	TYPE_QUICK_LOGIN = 1,
	TYPE_LILITH_LOGIN = 2,
	TYPE_MOBILE_LOGIN = 2,
	TYPE_FACEBOOK_LOGIN = 3,
	TYPE_GAME_CENTER_LOGIN = 4,
	TYPE_GOOGLE_PLUS_OR_GAMES_LOGIN = 5,
	TYPE_WECHAT_LOGIN = 6,
	TYPE_QQ_LOGIN = 7,
	TYPE_AUTO_LOGIN = 8,
	TYPE_VK_LOGIN = 9,
	TYPE_GOOGLE_LOGIN = 10,
	TYPE_LINE_LOGIN = 11,
	TYPE_TWITTER_LOGIN = 12,
	TYPE_APPLE_LOGIN = 13,
	TYPE_WEIBO_LOGIN = 14,
	TYPE_PGS_LOGIN = 15,
	TYPE_TIKTOK_LOGIN = 16,
	TYPE_STEAM_LOGIN = 17,
	TYPE_MAX = 18
};

// Object Name: Enum LLHSDK.ELLHSDKScreenOrientation
enum class ELLHSDKScreenOrientation : uint8 {
	Portrait = 0,
	ReversePortrait = 1,
	SensorPortrait = 2,
	Landscape = 3,
	ReverseLandscape = 4,
	SensorLandscape = 5,
	Sensor = 6,
	FullSensor = 7,
	ELLHSDKScreenOrientation_MAX = 8
};

// Object Name: Enum LLHSDK.ELLHSDKPayType
enum class ELLHSDKPayType : uint8 {
	None = 0,
	Apple = 1,
	Google = 2,
	Ali = 3,
	Wechat = 4,
	Union = 5,
	PlayPhone = 6,
	MyCard = 7,
	Payssion = 8,
	HuaweiAbroad = 9,
	Paypal = 10,
	Voucher = 11,
	Samsung = 12,
	ELLHSDKPayType_MAX = 13
};

// Object Name: Enum LLHSDK.ELLHSDKPayGenericSkuItemType
enum class ELLHSDKPayGenericSkuItemType : uint8 {
	Normal = 0,
	Subscription = 1,
	ELLHSDKPayGenericSkuItemType_MAX = 2
};

// Object Name: Enum LLHSDK.ELLHSDKCustomerServiceRateAction
enum class ELLHSDKCustomerServiceRateAction : uint8 {
	Success = 0,
	FeedBack = 1,
	Close = 2,
	Fail = 3,
	ELLHSDKCustomerServiceRateAction_MAX = 4
};

// Object Name: Enum LLHSDK.ELLHSDKSupportedLanguage
enum class ELLHSDKSupportedLanguage : uint8 {
	DefaultLanguage = 0,
	Arabic = 1,
	English = 2,
	French = 3,
	German = 4,
	Indonesian = 5,
	Italian = 6,
	Japanese = 7,
	Korean = 8,
	Malay = 9,
	Polish = 10,
	Portuguese = 11,
	Russian = 12,
	Spanish = 13,
	Thai = 14,
	Turkish = 15,
	Vietnamese = 16,
	Hindi = 17,
	SimplifiedChinese = 18,
	TraditionalChinese = 19,
	ELLHSDKSupportedLanguage_MAX = 20
};

// Object Name: Enum LLHSDK.ELLHSDKReportCurrencyType
enum class ELLHSDKReportCurrencyType : uint8 {
	USA_Dollar = 0,
	China_Yuan = 1,
	Taiwan_Dollar = 2,
	ELLHSDKReportCurrencyType_MAX = 3
};

// Object Name: Enum LLHSDK.ELLHSDKLoginUIStyle
enum class ELLHSDKLoginUIStyle : uint8 {
	NormalStyle = 0,
	SoulHunterStyle = 1,
	GameCenterStyle = 2,
	DomesticStyle = 3,
	GameCenterDomesticStyle = 4,
	ELLHSDKLoginUIStyle_MAX = 5
};

// Object Name: Enum LLHSDK.ELLHSDKGravity
enum class ELLHSDKGravity : uint8 {
	NO_GRAVITY = 0,
	LeftTop = 1,
	LeftCenter = 2,
	LeftBottom = 3,
	MidTop = 4,
	MidBottom = 5,
	RightTop = 6,
	RightCenter = 7,
	RightBottom = 8,
	ELLHSDKGravity_MAX = 9
};

