#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class LimNativeWidget.AudioPermissionHelperProxy
// Size: 0x48 // Inherited bytes: 0x28
struct UAudioPermissionHelperProxy : UObject {
	// Fields
	char pad_0x28[0x20]; // Offset: 0x28 // Size: 0x20

	// Functions

	// Object Name: Function LimNativeWidget.AudioPermissionHelperProxy.OnAndroidPermissionResult
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void OnAndroidPermissionResult(struct TArray<struct FString>& Permissions, struct TArray<bool>& Results); // Offset: 0x101224d9c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function LimNativeWidget.AudioPermissionHelperProxy.CheckIOSAudioPermission
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	enum class EIOSAudioPermissionState CheckIOSAudioPermission(); // Offset: 0x101224ef4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LimNativeWidget.AudioPermissionHelperProxy.CheckAndroidAudioPermission
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool CheckAndroidAudioPermission(); // Offset: 0x101224f28 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LimNativeWidget.AudioPermissionHelperProxy.AcquireIOSAudioPermission
	// Flags: [Final|Native|Public|BlueprintCallable]
	void AcquireIOSAudioPermission(); // Offset: 0x101224ecc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LimNativeWidget.AudioPermissionHelperProxy.AcquireAndroidAudioPermission
	// Flags: [Final|Native|Public|BlueprintCallable]
	void AcquireAndroidAudioPermission(); // Offset: 0x101224ee0 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class LimNativeWidget.ChatGMEManager
// Size: 0x798 // Inherited bytes: 0x28
struct UChatGMEManager : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08
	struct FLimNativeLowLevelWrapper ctx; // Offset: 0x30 // Size: 0x10
	struct FMulticastInlineDelegate OnEnterRoom; // Offset: 0x40 // Size: 0x10
	char pad_0x50[0x18]; // Offset: 0x50 // Size: 0x18
	struct FMulticastInlineDelegate OnExitRoom; // Offset: 0x68 // Size: 0x10
	char pad_0x78[0x18]; // Offset: 0x78 // Size: 0x18
	struct FMulticastInlineDelegate OnRoomDisconnect; // Offset: 0x90 // Size: 0x10
	char pad_0xA0[0x18]; // Offset: 0xa0 // Size: 0x18
	struct FMulticastInlineDelegate OnUserUpdate; // Offset: 0xb8 // Size: 0x10
	char pad_0xC8[0x18]; // Offset: 0xc8 // Size: 0x18
	struct FMulticastInlineDelegate OnNumberOfUsersUpdate; // Offset: 0xe0 // Size: 0x10
	char pad_0xF0[0x18]; // Offset: 0xf0 // Size: 0x18
	struct FMulticastInlineDelegate OnNumberOfAudioStreamsUpdate; // Offset: 0x108 // Size: 0x10
	char pad_0x118[0x18]; // Offset: 0x118 // Size: 0x18
	struct FMulticastInlineDelegate OnReconnectStart; // Offset: 0x130 // Size: 0x10
	char pad_0x140[0x18]; // Offset: 0x140 // Size: 0x18
	struct FMulticastInlineDelegate OnReconnectSuccess; // Offset: 0x158 // Size: 0x10
	char pad_0x168[0x18]; // Offset: 0x168 // Size: 0x18
	struct FMulticastInlineDelegate OnSwitchRoom; // Offset: 0x180 // Size: 0x10
	char pad_0x190[0x18]; // Offset: 0x190 // Size: 0x18
	struct FMulticastInlineDelegate OnChangeRoomType; // Offset: 0x1a8 // Size: 0x10
	char pad_0x1B8[0x18]; // Offset: 0x1b8 // Size: 0x18
	struct FMulticastInlineDelegate OnAudioDataEmpty; // Offset: 0x1d0 // Size: 0x10
	char pad_0x1E0[0x18]; // Offset: 0x1e0 // Size: 0x18
	struct FMulticastInlineDelegate OnRoomSharingStart; // Offset: 0x1f8 // Size: 0x10
	char pad_0x208[0x18]; // Offset: 0x208 // Size: 0x18
	struct FMulticastInlineDelegate OnRoomSharingStop; // Offset: 0x220 // Size: 0x10
	char pad_0x230[0x18]; // Offset: 0x230 // Size: 0x18
	struct FMulticastInlineDelegate OnRecordCompleted; // Offset: 0x248 // Size: 0x10
	char pad_0x258[0x18]; // Offset: 0x258 // Size: 0x18
	struct FMulticastInlineDelegate OnRecordPreviewCompleted; // Offset: 0x270 // Size: 0x10
	char pad_0x280[0x18]; // Offset: 0x280 // Size: 0x18
	struct FMulticastInlineDelegate OnRecordMixCompleted; // Offset: 0x298 // Size: 0x10
	char pad_0x2A8[0x18]; // Offset: 0x2a8 // Size: 0x18
	struct FMulticastInlineDelegate OnAudioRouteUpdate; // Offset: 0x2c0 // Size: 0x10
	char pad_0x2D0[0x18]; // Offset: 0x2d0 // Size: 0x18
	struct FMulticastInlineDelegate OnSpeakerDefaultDeviceChanged; // Offset: 0x2e8 // Size: 0x10
	char pad_0x2F8[0x18]; // Offset: 0x2f8 // Size: 0x18
	struct FMulticastInlineDelegate OnSpeakerNewDevice; // Offset: 0x310 // Size: 0x10
	char pad_0x320[0x18]; // Offset: 0x320 // Size: 0x18
	struct FMulticastInlineDelegate OnSpeakerLostDevice; // Offset: 0x338 // Size: 0x10
	char pad_0x348[0x18]; // Offset: 0x348 // Size: 0x18
	struct FMulticastInlineDelegate OnMicNewDevice; // Offset: 0x360 // Size: 0x10
	char pad_0x370[0x18]; // Offset: 0x370 // Size: 0x18
	struct FMulticastInlineDelegate OnMicLostDevice; // Offset: 0x388 // Size: 0x10
	char pad_0x398[0x18]; // Offset: 0x398 // Size: 0x18
	struct FMulticastInlineDelegate OnMicDefaultDeviceChanged; // Offset: 0x3b0 // Size: 0x10
	char pad_0x3C0[0x18]; // Offset: 0x3c0 // Size: 0x18
	struct FMulticastInlineDelegate OnAudioRouteChanged; // Offset: 0x3d8 // Size: 0x10
	char pad_0x3E8[0x18]; // Offset: 0x3e8 // Size: 0x18
	struct FMulticastInlineDelegate OnUserVolumes; // Offset: 0x400 // Size: 0x10
	char pad_0x410[0x18]; // Offset: 0x410 // Size: 0x18
	struct FMulticastInlineDelegate OnChangeRoomQuality; // Offset: 0x428 // Size: 0x10
	char pad_0x438[0x18]; // Offset: 0x438 // Size: 0x18
	struct FMulticastInlineDelegate OnAccompanyFinish; // Offset: 0x450 // Size: 0x10
	char pad_0x460[0x18]; // Offset: 0x460 // Size: 0x18
	struct FMulticastInlineDelegate OnServerAudioRouteEvent; // Offset: 0x478 // Size: 0x10
	char pad_0x488[0x18]; // Offset: 0x488 // Size: 0x18
	struct FMulticastInlineDelegate OnCustomDataUpdate; // Offset: 0x4a0 // Size: 0x10
	char pad_0x4B0[0x18]; // Offset: 0x4b0 // Size: 0x18
	struct FMulticastInlineDelegate OnRealtimeASR; // Offset: 0x4c8 // Size: 0x10
	char pad_0x4D8[0x18]; // Offset: 0x4d8 // Size: 0x18
	struct FMulticastInlineDelegate OnChorusEvent; // Offset: 0x4f0 // Size: 0x10
	char pad_0x500[0x18]; // Offset: 0x500 // Size: 0x18
	struct FMulticastInlineDelegate OnChangeTeamId; // Offset: 0x518 // Size: 0x10
	char pad_0x528[0x18]; // Offset: 0x528 // Size: 0x18
	struct FMulticastInlineDelegate OnAudioReady; // Offset: 0x540 // Size: 0x10
	char pad_0x550[0x18]; // Offset: 0x550 // Size: 0x18
	struct FMulticastInlineDelegate OnHardwareTestRecordFinish; // Offset: 0x568 // Size: 0x10
	char pad_0x578[0x18]; // Offset: 0x578 // Size: 0x18
	struct FMulticastInlineDelegate OnHardwareTestPreviewFinish; // Offset: 0x590 // Size: 0x10
	char pad_0x5A0[0x18]; // Offset: 0x5a0 // Size: 0x18
	struct FMulticastInlineDelegate OnPTTRecordComplete; // Offset: 0x5b8 // Size: 0x10
	char pad_0x5C8[0x18]; // Offset: 0x5c8 // Size: 0x18
	struct FMulticastInlineDelegate OnPTTUploadComplete; // Offset: 0x5e0 // Size: 0x10
	char pad_0x5F0[0x18]; // Offset: 0x5f0 // Size: 0x18
	struct FMulticastInlineDelegate OnPTTDownloadComplete; // Offset: 0x608 // Size: 0x10
	char pad_0x618[0x18]; // Offset: 0x618 // Size: 0x18
	struct FMulticastInlineDelegate OnPTTPlayComplete; // Offset: 0x630 // Size: 0x10
	char pad_0x640[0x18]; // Offset: 0x640 // Size: 0x18
	struct FMulticastInlineDelegate OnPTTSpeech2TextComplete; // Offset: 0x658 // Size: 0x10
	char pad_0x668[0x18]; // Offset: 0x668 // Size: 0x18
	struct FMulticastInlineDelegate OnPTTStreamingRecognitionComplete; // Offset: 0x680 // Size: 0x10
	char pad_0x690[0x18]; // Offset: 0x690 // Size: 0x18
	struct FMulticastInlineDelegate OnPTTStreamingRecognitionIsRunning; // Offset: 0x6a8 // Size: 0x10
	char pad_0x6B8[0x18]; // Offset: 0x6b8 // Size: 0x18
	struct FMulticastInlineDelegate OnRoomManagementOperator; // Offset: 0x6d0 // Size: 0x10
	char pad_0x6E0[0x18]; // Offset: 0x6e0 // Size: 0x18
	struct FMulticastInlineDelegate OnPermissionResult; // Offset: 0x6f8 // Size: 0x10
	char pad_0x708[0x90]; // Offset: 0x708 // Size: 0x90

	// Functions

	// Object Name: Function LimNativeWidget.ChatGMEManager.UpdateSelfPosition
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void UpdateSelfPosition(struct FVector InSelfPosition); // Offset: 0x101226a40 // Return & Params: Num(1) Size(0xc)

	// Object Name: Function LimNativeWidget.ChatGMEManager.UpdateAudioRecvRange
	// Flags: [Final|Native|Public|BlueprintCallable]
	void UpdateAudioRecvRange(int32_t InRange); // Offset: 0x101226ac0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LimNativeWidget.ChatGMEManager.UnRegisterLuaEvent
	// Flags: [Event|Public|BlueprintEvent]
	void UnRegisterLuaEvent(); // Offset: 0x1032a8bf4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LimNativeWidget.ChatGMEManager.Uninit
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Uninit(); // Offset: 0x101227b6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LimNativeWidget.ChatGMEManager.SwitchRoom
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool SwitchRoom(struct FString InRoomId); // Offset: 0x1012279e8 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function LimNativeWidget.ChatGMEManager.SetRangeAudioTeamID
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetRangeAudioTeamID(int32_t InTeamId); // Offset: 0x101227900 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LimNativeWidget.ChatGMEManager.SetRangeAudioMode
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetRangeAudioMode(enum class EChatGMERangeAudioMode InAudioMode); // Offset: 0x101227880 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LimNativeWidget.ChatGMEManager.SetAudioSendAndRecvRules
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAudioSendAndRecvRules(enum class EChatGMEAudioRouteSendType SendType, struct TArray<struct FString> SendOpenIDList, enum class EChatGMEAudioRouteRecvType RecvType, struct TArray<struct FString> RecvOpenIDList); // Offset: 0x101226f08 // Return & Params: Num(4) Size(0x30)

	// Object Name: Function LimNativeWidget.ChatGMEManager.SelectSpeak
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SelectSpeak(struct FString InDeviceID); // Offset: 0x101226b40 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LimNativeWidget.ChatGMEManager.SelectMic
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SelectMic(struct FString InDeviceID); // Offset: 0x101226bcc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LimNativeWidget.ChatGMEManager.PreInit
	// Flags: [Final|Native|Public|BlueprintCallable]
	void PreInit(); // Offset: 0x101227eb0 // Return & Params: Num(0) Size(0x0)

	// Object Name: DelegateFunction LimNativeWidget.ChatGMEManager.OnUserVolumesDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnUserVolumesDelegate__DelegateSignature(struct FChatGMEDataUserVolumes InData); // Offset: 0x1032a8bf4 // Return & Params: Num(1) Size(0x58)

	// Object Name: DelegateFunction LimNativeWidget.ChatGMEManager.OnUserUpdateDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnUserUpdateDelegate__DelegateSignature(struct FChatGMEDataUserUpdate InData); // Offset: 0x1032a8bf4 // Return & Params: Num(1) Size(0x20)

	// Object Name: DelegateFunction LimNativeWidget.ChatGMEManager.OnRoomManagementOperatorDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnRoomManagementOperatorDelegate__DelegateSignature(struct FChatGMEDataRoomOperator InData); // Offset: 0x1032a8bf4 // Return & Params: Num(1) Size(0x50)

	// Object Name: DelegateFunction LimNativeWidget.ChatGMEManager.OnResultDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnResultDelegate__DelegateSignature(struct FChatGMEDataResult Result); // Offset: 0x1032a8bf4 // Return & Params: Num(1) Size(0x28)

	// Object Name: DelegateFunction LimNativeWidget.ChatGMEManager.OnRecordCompletedDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnRecordCompletedDelegate__DelegateSignature(struct FChatGMEDataRecordCompleted InData); // Offset: 0x1032a8bf4 // Return & Params: Num(1) Size(0x48)

	// Object Name: DelegateFunction LimNativeWidget.ChatGMEManager.OnNumberOfUsersUpdateDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnNumberOfUsersUpdateDelegate__DelegateSignature(struct FChatGMEDataNumberOfUserUpdate InData); // Offset: 0x1032a8bf4 // Return & Params: Num(1) Size(0x18)

	// Object Name: DelegateFunction LimNativeWidget.ChatGMEManager.OnNumberOfAudioStreamsUpdateDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnNumberOfAudioStreamsUpdateDelegate__DelegateSignature(struct FChatGMEDataNumberOfAudioStreamsUpdate InData); // Offset: 0x1032a8bf4 // Return & Params: Num(1) Size(0x10)

	// Object Name: DelegateFunction LimNativeWidget.ChatGMEManager.OnNotifyFileInfoDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnNotifyFileInfoDelegate__DelegateSignature(struct FChatGMEDataFileInfo InData); // Offset: 0x1032a8bf4 // Return & Params: Num(1) Size(0x58)

	// Object Name: DelegateFunction LimNativeWidget.ChatGMEManager.OnNotifyDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnNotifyDelegate__DelegateSignature(struct FString InData); // Offset: 0x1032a8bf4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LimNativeWidget.ChatGMEManager.OnGetAuthBuffer
	// Flags: [Final|Native|Protected|HasOutParms]
	void OnGetAuthBuffer(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeGetGMETokenCallBack& RetData); // Offset: 0x101226218 // Return & Params: Num(2) Size(0x78)

	// Object Name: DelegateFunction LimNativeWidget.ChatGMEManager.OnDeviceChangedDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnDeviceChangedDelegate__DelegateSignature(struct FChatGMEDataDeviceInfo InData); // Offset: 0x1032a8bf4 // Return & Params: Num(1) Size(0x50)

	// Object Name: DelegateFunction LimNativeWidget.ChatGMEManager.OnChangeRoomTypeDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnChangeRoomTypeDelegate__DelegateSignature(struct FChatGMEDataChangeRoomType InData); // Offset: 0x1032a8bf4 // Return & Params: Num(1) Size(0x28)

	// Object Name: DelegateFunction LimNativeWidget.ChatGMEManager.OnChangeRoomQualityDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnChangeRoomQualityDelegate__DelegateSignature(struct FChatGMEDataRoomQuality InData); // Offset: 0x1032a8bf4 // Return & Params: Num(1) Size(0x18)

	// Object Name: DelegateFunction LimNativeWidget.ChatGMEManager.OnAndroidPermissionResult__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnAndroidPermissionResult__DelegateSignature(bool bSuccess); // Offset: 0x1032a8bf4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LimNativeWidget.ChatGMEManager.MediaMute
	// Flags: [Final|Native|Public|BlueprintCallable]
	void MediaMute(struct FString InUserId, bool InMute); // Offset: 0x1012272b0 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function LimNativeWidget.ChatGMEManager.IsRoomEntered
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsRoomEntered(); // Offset: 0x101227980 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LimNativeWidget.ChatGMEManager.IsAudioSendEnabled
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsAudioSendEnabled(); // Offset: 0x10122742c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LimNativeWidget.ChatGMEManager.IsAudioRecvEnabled
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsAudioRecvEnabled(); // Offset: 0x1012273f8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LimNativeWidget.ChatGMEManager.IsAudioPlayDeviceEnabled
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsAudioPlayDeviceEnabled(); // Offset: 0x101227570 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LimNativeWidget.ChatGMEManager.IsAudioCaptureDeviceEnabled
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsAudioCaptureDeviceEnabled(); // Offset: 0x1012275a4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LimNativeWidget.ChatGMEManager.InnerEnableMic
	// Flags: [Final|Native|Public|BlueprintCallable]
	void InnerEnableMic(bool InEnable); // Offset: 0x1012276e8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LimNativeWidget.ChatGMEManager.InitGME
	// Flags: [Final|Native|Public|BlueprintCallable]
	void InitGME(struct FString InEnvId, struct FString InGMEUserID); // Offset: 0x101227b80 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function LimNativeWidget.ChatGMEManager.Init
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Init(struct FString InUserId, struct FString InAppId, struct FString InEnvId); // Offset: 0x101227d24 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function LimNativeWidget.ChatGMEManager.GetSpeakerState
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool GetSpeakerState(); // Offset: 0x1012273c4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LimNativeWidget.ChatGMEManager.GetSpeakerList
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct TArray<struct FChatGMEDataDeviceInfo> GetSpeakerList(); // Offset: 0x101226c58 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LimNativeWidget.ChatGMEManager.GetRecordingLocalFilePath
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetRecordingLocalFilePath(); // Offset: 0x1012269c0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LimNativeWidget.ChatGMEManager.GetMicState
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool GetMicState(); // Offset: 0x101227390 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LimNativeWidget.ChatGMEManager.GetMicList
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct TArray<struct FChatGMEDataDeviceInfo> GetMicList(); // Offset: 0x101226db0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LimNativeWidget.ChatGMEManager.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UChatGMEManager* GetInstance(); // Offset: 0x101227ed8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function LimNativeWidget.ChatGMEManager.GameUploadRecordedFile
	// Flags: [Final|Native|Public|BlueprintCallable]
	void GameUploadRecordedFile(struct FString FilePath); // Offset: 0x101226858 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LimNativeWidget.ChatGMEManager.GameStopRecording
	// Flags: [Final|Native|Public|BlueprintCallable]
	void GameStopRecording(); // Offset: 0x101226920 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LimNativeWidget.ChatGMEManager.GameStopPlayFile
	// Flags: [Final|Native|Public|BlueprintCallable]
	void GameStopPlayFile(); // Offset: 0x1012266d4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LimNativeWidget.ChatGMEManager.GameStartRecording
	// Flags: [Final|Native|Public|BlueprintCallable]
	void GameStartRecording(struct FString FilePath); // Offset: 0x101226934 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LimNativeWidget.ChatGMEManager.GameSetSpeakerVolume
	// Flags: [Final|Native|Public|BlueprintCallable]
	int32_t GameSetSpeakerVolume(int32_t Volume); // Offset: 0x10122647c // Return & Params: Num(2) Size(0x8)

	// Object Name: Function LimNativeWidget.ChatGMEManager.GameSetMicVolume
	// Flags: [Final|Native|Public|BlueprintCallable]
	int32_t GameSetMicVolume(int32_t MicVolume); // Offset: 0x101226574 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function LimNativeWidget.ChatGMEManager.GameResumeRecording
	// Flags: [Final|Native|Public|BlueprintCallable]
	void GameResumeRecording(); // Offset: 0x1012268e4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LimNativeWidget.ChatGMEManager.GamePlayRecordedFile
	// Flags: [Final|Native|Public|BlueprintCallable]
	void GamePlayRecordedFile(struct FString FilePath); // Offset: 0x1012266e8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LimNativeWidget.ChatGMEManager.GamePauseRecording
	// Flags: [Final|Native|Public|BlueprintCallable]
	void GamePauseRecording(); // Offset: 0x1012268f8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LimNativeWidget.ChatGMEManager.GameGetVoiceFileDuration
	// Flags: [Final|Native|Public|BlueprintCallable]
	int32_t GameGetVoiceFileDuration(struct FString FilePath); // Offset: 0x101226638 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function LimNativeWidget.ChatGMEManager.GameGetSpeakerVolume
	// Flags: [Final|Native|Public|BlueprintCallable]
	int32_t GameGetSpeakerVolume(); // Offset: 0x101226448 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LimNativeWidget.ChatGMEManager.GameGetSpeakerLevel
	// Flags: [Final|Native|Public|BlueprintCallable]
	int32_t GameGetSpeakerLevel(); // Offset: 0x10122650c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LimNativeWidget.ChatGMEManager.GameGetMicVolume
	// Flags: [Final|Native|Public|BlueprintCallable]
	int32_t GameGetMicVolume(); // Offset: 0x101226540 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LimNativeWidget.ChatGMEManager.GameGetMicLevel
	// Flags: [Final|Native|Public|BlueprintCallable]
	int32_t GameGetMicLevel(); // Offset: 0x101226604 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LimNativeWidget.ChatGMEManager.GameDownloadRecordedFile
	// Flags: [Final|Native|Public|BlueprintCallable]
	void GameDownloadRecordedFile(struct FString FileID, struct FString FilePath); // Offset: 0x101226774 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function LimNativeWidget.ChatGMEManager.GameCancleRecording
	// Flags: [Final|Native|Public|BlueprintCallable]
	void GameCancleRecording(); // Offset: 0x10122690c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LimNativeWidget.ChatGMEManager.ExitRoom
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool ExitRoom(); // Offset: 0x1012279b4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LimNativeWidget.ChatGMEManager.EnterRoom
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool EnterRoom(struct FString InRoomId, enum class EChatGMERoomType InRoomType); // Offset: 0x101227a84 // Return & Params: Num(3) Size(0x12)

	// Object Name: Function LimNativeWidget.ChatGMEManager.EnableSpeaker
	// Flags: [Final|Native|Public|BlueprintCallable]
	void EnableSpeaker(bool InEnable); // Offset: 0x1012277f8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LimNativeWidget.ChatGMEManager.EnableMic
	// Flags: [Final|Native|Public|BlueprintCallable]
	void EnableMic(bool InEnable); // Offset: 0x101227770 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LimNativeWidget.ChatGMEManager.EnableAudioSend
	// Flags: [Final|Native|Public|BlueprintCallable]
	void EnableAudioSend(bool bEnable); // Offset: 0x1012274e8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LimNativeWidget.ChatGMEManager.EnableAudioRecv
	// Flags: [Final|Native|Public|BlueprintCallable]
	void EnableAudioRecv(bool bEnable); // Offset: 0x101227460 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LimNativeWidget.ChatGMEManager.EnableAudioPlayDevice
	// Flags: [Final|Native|Public|BlueprintCallable]
	void EnableAudioPlayDevice(bool InEnable); // Offset: 0x1012275d8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LimNativeWidget.ChatGMEManager.EnableAudioCaptureDevice
	// Flags: [Final|Native|Public|BlueprintCallable]
	void EnableAudioCaptureDevice(bool InEnable); // Offset: 0x101227660 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LimNativeWidget.ChatGMEManager.DestroyInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void DestroyInstance(); // Offset: 0x101227ec4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LimNativeWidget.ChatGMEManager.DeleteCacheFiles
	// Flags: [Final|Native|Public|BlueprintCallable]
	void DeleteCacheFiles(); // Offset: 0x101226434 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LimNativeWidget.ChatGMEManager.CheckPlatformMicPermission
	// Flags: [Final|Native|Public|BlueprintCallable]
	int32_t CheckPlatformMicPermission(); // Offset: 0x101226400 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class LimNativeWidget.ChatListEmojiEntryData
// Size: 0xd0 // Inherited bytes: 0x28
struct UChatListEmojiEntryData : UObject {
	// Fields
	struct FString Tag; // Offset: 0x28 // Size: 0x10
	struct FSlateBrush Image; // Offset: 0x38 // Size: 0x98
};

// Object Name: Class LimNativeWidget.ChatListEntryDataBase
// Size: 0x98 // Inherited bytes: 0x28
struct UChatListEntryDataBase : UObject {
	// Fields
	enum class ELimNativeMsgContentType MessageType; // Offset: 0x28 // Size: 0x01
	char pad_0x29[0x7]; // Offset: 0x29 // Size: 0x07
	struct FDateTime Timestamp; // Offset: 0x30 // Size: 0x08
	struct FString SenderId; // Offset: 0x38 // Size: 0x10
	struct FString SenderName; // Offset: 0x48 // Size: 0x10
	struct FString SenderAvatarUrl; // Offset: 0x58 // Size: 0x10
	enum class ELimNativeMsgState MsgState; // Offset: 0x68 // Size: 0x01
	char pad_0x69[0x7]; // Offset: 0x69 // Size: 0x07
	struct FString ConvID; // Offset: 0x70 // Size: 0x10
	enum class ELimNativeConvType ConvType; // Offset: 0x80 // Size: 0x01
	char pad_0x81[0x7]; // Offset: 0x81 // Size: 0x07
	struct FString MsgId; // Offset: 0x88 // Size: 0x10
};

// Object Name: Class LimNativeWidget.ChatListEntryDataText
// Size: 0xa8 // Inherited bytes: 0x98
struct UChatListEntryDataText : UChatListEntryDataBase {
	// Fields
	struct FString Message; // Offset: 0x98 // Size: 0x10
};

// Object Name: Class LimNativeWidget.ChatListEntryDataSystem
// Size: 0xa8 // Inherited bytes: 0x98
struct UChatListEntryDataSystem : UChatListEntryDataBase {
	// Fields
	struct FString Message; // Offset: 0x98 // Size: 0x10
};

// Object Name: Class LimNativeWidget.ChatListEntryDataVoice
// Size: 0xd0 // Inherited bytes: 0x98
struct UChatListEntryDataVoice : UChatListEntryDataBase {
	// Fields
	struct FString UUID; // Offset: 0x98 // Size: 0x10
	struct FString URL; // Offset: 0xa8 // Size: 0x10
	struct FString Size; // Offset: 0xb8 // Size: 0x10
	int32_t Duration; // Offset: 0xc8 // Size: 0x04
	char pad_0xCC[0x4]; // Offset: 0xcc // Size: 0x04
};

// Object Name: Class LimNativeWidget.ChatListEntryDataImage
// Size: 0xe0 // Inherited bytes: 0x98
struct UChatListEntryDataImage : UChatListEntryDataBase {
	// Fields
	struct FString UUID; // Offset: 0x98 // Size: 0x10
	struct FString Fmt; // Offset: 0xa8 // Size: 0x10
	struct FString URL; // Offset: 0xb8 // Size: 0x10
	int32_t Width; // Offset: 0xc8 // Size: 0x04
	int32_t Height; // Offset: 0xcc // Size: 0x04
	struct FString Size; // Offset: 0xd0 // Size: 0x10
};

// Object Name: Class LimNativeWidget.ChatListEntryDataCustomEmotion
// Size: 0xf0 // Inherited bytes: 0x98
struct UChatListEntryDataCustomEmotion : UChatListEntryDataBase {
	// Fields
	struct FString PackName; // Offset: 0x98 // Size: 0x10
	enum class ELimNativePackType PackType; // Offset: 0xa8 // Size: 0x01
	char pad_0xA9[0x7]; // Offset: 0xa9 // Size: 0x07
	struct FString EmotionName; // Offset: 0xb0 // Size: 0x10
	struct FString EmotionId; // Offset: 0xc0 // Size: 0x10
	struct FString EmotionUrl; // Offset: 0xd0 // Size: 0x10
	struct FString Desc; // Offset: 0xe0 // Size: 0x10
};

// Object Name: Class LimNativeWidget.ChatListEntryDataShaderedGameCard
// Size: 0x100 // Inherited bytes: 0x98
struct UChatListEntryDataShaderedGameCard : UChatListEntryDataBase {
	// Fields
	int32_t Type; // Offset: 0x98 // Size: 0x04
	char pad_0x9C[0x4]; // Offset: 0x9c // Size: 0x04
	struct FString Text; // Offset: 0xa0 // Size: 0x10
	struct FString Title; // Offset: 0xb0 // Size: 0x10
	struct FString Detail; // Offset: 0xc0 // Size: 0x10
	struct FString Img; // Offset: 0xd0 // Size: 0x10
	struct FString URL; // Offset: 0xe0 // Size: 0x10
	struct FString Extra; // Offset: 0xf0 // Size: 0x10
};

// Object Name: Class LimNativeWidget.ChatListUserEntryData
// Size: 0x78 // Inherited bytes: 0x28
struct UChatListUserEntryData : UObject {
	// Fields
	struct FString Uid; // Offset: 0x28 // Size: 0x10
	struct FString NickName; // Offset: 0x38 // Size: 0x10
	struct FString AvatarUrl; // Offset: 0x48 // Size: 0x10
	struct FString AvatarFrameUrl; // Offset: 0x58 // Size: 0x10
	enum class ELimNativeUserSexType Sex; // Offset: 0x68 // Size: 0x01
	char pad_0x69[0x3]; // Offset: 0x69 // Size: 0x03
	int32_t VipLevel; // Offset: 0x6c // Size: 0x04
	bool IsShowVip; // Offset: 0x70 // Size: 0x01
	enum class ELimNativeFriendStateType OnlineState; // Offset: 0x71 // Size: 0x01
	char pad_0x72[0x2]; // Offset: 0x72 // Size: 0x02
	int32_t UnreadCount; // Offset: 0x74 // Size: 0x04
};

// Object Name: Class LimNativeWidget.LimChatManager
// Size: 0x320 // Inherited bytes: 0x28
struct ULimChatManager : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08
	struct ULimNative* LimNativeInstance; // Offset: 0x30 // Size: 0x08
	struct FLimNativeLowLevelWrapper ctx; // Offset: 0x38 // Size: 0x10
	struct FString CurrentLanguage; // Offset: 0x48 // Size: 0x10
	struct FMulticastInlineDelegate OnLoginCallBackHandle; // Offset: 0x58 // Size: 0x10
	struct FMulticastInlineDelegate OnConvsGetCallBackHandle; // Offset: 0x68 // Size: 0x10
	struct FMulticastInlineDelegate OnNewGetMessageHandle; // Offset: 0x78 // Size: 0x10
	struct FMulticastInlineDelegate OnMessageReceivedHandle; // Offset: 0x88 // Size: 0x10
	struct FMulticastInlineDelegate OnNewMessageReceivedHandle; // Offset: 0x98 // Size: 0x10
	struct FMulticastInlineDelegate OnMessageSendCallBackHandle; // Offset: 0xa8 // Size: 0x10
	struct FMulticastInlineDelegate OnNewMessageSendCallBackHandle; // Offset: 0xb8 // Size: 0x10
	struct FMulticastInlineDelegate OnReceiveLogicMsgHandle; // Offset: 0xc8 // Size: 0x10
	struct FMulticastInlineDelegate OnConvDiscardHandle; // Offset: 0xd8 // Size: 0x10
	struct FMulticastInlineDelegate OnConfigInfoHandle; // Offset: 0xe8 // Size: 0x10
	struct FMulticastInlineDelegate OnGetConnStatHandle; // Offset: 0xf8 // Size: 0x10
	struct FMulticastInlineDelegate OnNetStatHandle; // Offset: 0x108 // Size: 0x10
	struct FMulticastInlineDelegate OnGetConfigChatLevelHandle; // Offset: 0x118 // Size: 0x10
	struct FMulticastInlineDelegate OnTextTranslateDynamicDelegate; // Offset: 0x128 // Size: 0x10
	struct FString SelfRoleID; // Offset: 0x138 // Size: 0x10
	struct FChatListConvData CurrentConvData; // Offset: 0x148 // Size: 0x18
	struct TArray<struct FLimNativeConversationData> ConvListFullData; // Offset: 0x160 // Size: 0x10
	struct TArray<struct FNewChatListMessageData> ChatMsgDataList; // Offset: 0x170 // Size: 0x10
	struct TArray<struct FLimNativeConvChatLevelConfigData> ChatLevelDataList; // Offset: 0x180 // Size: 0x10
	struct TMap<struct FChatListConvData, struct FString> MsgIDMap; // Offset: 0x190 // Size: 0x50
	struct TArray<struct FChatListUserData> PeerDataList; // Offset: 0x1e0 // Size: 0x10
	struct TArray<struct FChatListUserData> FriendDataList; // Offset: 0x1f0 // Size: 0x10
	struct TMap<struct FChatListConvData, struct FString> BaseMsgIDMap; // Offset: 0x200 // Size: 0x50
	struct TMap<struct FChatListConvData, int32_t> UnreadMsgMap; // Offset: 0x250 // Size: 0x50
	struct FMulticastInlineDelegate OnGetFriendsCallBackHandle; // Offset: 0x2a0 // Size: 0x10
	struct FMulticastInlineDelegate OnGetUserHandle; // Offset: 0x2b0 // Size: 0x10
	struct FMulticastInlineDelegate OnGetUserListHandle; // Offset: 0x2c0 // Size: 0x10
	struct FMulticastInlineDelegate OnGetUserListStateHandle; // Offset: 0x2d0 // Size: 0x10
	struct FMulticastInlineDelegate OnRedHintUpdateHandle; // Offset: 0x2e0 // Size: 0x10
	struct FMulticastInlineDelegate OnInputBoxChangeHandle; // Offset: 0x2f0 // Size: 0x10
	char pad_0x300[0x20]; // Offset: 0x300 // Size: 0x20

	// Functions

	// Object Name: Function LimNativeWidget.LimChatManager.UnRegisterLuaEvent
	// Flags: [Event|Public|BlueprintEvent]
	void UnRegisterLuaEvent(); // Offset: 0x1032a8bf4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LimNativeWidget.LimChatManager.UnInitChatManager
	// Flags: [Final|Native|Public|BlueprintCallable]
	void UnInitChatManager(); // Offset: 0x101231084 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LimNativeWidget.LimChatManager.TranslateText
	// Flags: [Final|Native|Public]
	void TranslateText(struct FString Text, struct FString Lang, struct FString ExtraInfo); // Offset: 0x10122ffbc // Return & Params: Num(3) Size(0x30)

	// Object Name: Function LimNativeWidget.LimChatManager.SwitchConvTo
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SwitchConvTo(struct FChatListConvData& InConvData, bool RefreshConvList); // Offset: 0x10122fd30 // Return & Params: Num(2) Size(0x19)

	// Object Name: Function LimNativeWidget.LimChatManager.SetCtxLanguage
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetCtxLanguage(struct FString Lang); // Offset: 0x101230e90 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LimNativeWidget.LimChatManager.SetConvRead
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetConvRead(struct FChatListConvData& ConvData); // Offset: 0x101230280 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function LimNativeWidget.LimChatManager.SetConvMsgRead
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetConvMsgRead(struct FString ConvID, enum class ELimNativeConvType ConvType, struct FString MsgId, struct FString Extra); // Offset: 0x1012300f8 // Return & Params: Num(4) Size(0x38)

	// Object Name: Function LimNativeWidget.LimChatManager.SendVoiceMessageToConv
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SendVoiceMessageToConv(struct FString ConvID, enum class ELimNativeConvType ConvType, struct FString FileID, struct FString Extra); // Offset: 0x10123031c // Return & Params: Num(4) Size(0x38)

	// Object Name: Function LimNativeWidget.LimChatManager.SendTextMessageToConv
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SendTextMessageToConv(struct FString ConvID, enum class ELimNativeConvType ConvType, struct FString Message, struct FString Extra); // Offset: 0x1012304f4 // Return & Params: Num(4) Size(0x38)

	// Object Name: Function LimNativeWidget.LimChatManager.SendTextMessage
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SendTextMessage(struct FString Message, struct FString Extra); // Offset: 0x1012306cc // Return & Params: Num(2) Size(0x20)

	// Object Name: Function LimNativeWidget.LimChatManager.PostInitChatManager
	// Flags: [Final|Native|Public|BlueprintCallable]
	void PostInitChatManager(struct FLimNativeReportConfig ReportConfig, struct FLimNativeParkConfig ParkConfig); // Offset: 0x101231098 // Return & Params: Num(2) Size(0x120)

	// Object Name: Function LimNativeWidget.LimChatManager.OpenChatUI
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UUserWidget* OpenChatUI(struct UObject* WorldContextObject, struct FString ChatWidgetPath, int32_t ZOrder); // Offset: 0x10122fe20 // Return & Params: Num(4) Size(0x28)

	// Object Name: DelegateFunction LimNativeWidget.LimChatManager.OnTextTranslateDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnTextTranslateDynamicDelegate__DelegateSignature(bool TranslateRes, struct FString TranslatedText, struct FString Translator, struct FString ExtraInfo); // Offset: 0x1032a8bf4 // Return & Params: Num(4) Size(0x38)

	// Object Name: DelegateFunction LimNativeWidget.LimChatManager.OnSendMessageCallBackDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void OnSendMessageCallBackDynamicDelegate__DelegateSignature(struct FChatListMessageData& MsgCallBack); // Offset: 0x1032a8bf4 // Return & Params: Num(1) Size(0x98)

	// Object Name: DelegateFunction LimNativeWidget.LimChatManager.OnRedHintUpdateDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnRedHintUpdateDynamicDelegate__DelegateSignature(); // Offset: 0x1032a8bf4 // Return & Params: Num(0) Size(0x0)

	// Object Name: DelegateFunction LimNativeWidget.LimChatManager.OnReceiveMessageDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void OnReceiveMessageDynamicDelegate__DelegateSignature(struct FChatListMessageData& Msg); // Offset: 0x1032a8bf4 // Return & Params: Num(1) Size(0x98)

	// Object Name: DelegateFunction LimNativeWidget.LimChatManager.OnReceiveLogicMessageDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void OnReceiveLogicMessageDynamicDelegate__DelegateSignature(int32_t MsgType, struct FLimNativeDataBizFullObj& NativeMsg); // Offset: 0x1032a8bf4 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function LimNativeWidget.LimChatManager.OnOpenChatUI
	// Flags: [Final|Native|Public|BlueprintCallable]
	void OnOpenChatUI(); // Offset: 0x10122ffa8 // Return & Params: Num(0) Size(0x0)

	// Object Name: DelegateFunction LimNativeWidget.LimChatManager.OnNewSendMessageCallBackDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void OnNewSendMessageCallBackDynamicDelegate__DelegateSignature(struct FNewChatListMessageData& MsgCallBack, struct FString RetData, int32_t Code); // Offset: 0x1032a8bf4 // Return & Params: Num(3) Size(0x18c)

	// Object Name: DelegateFunction LimNativeWidget.LimChatManager.OnNewReceiveMessageDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void OnNewReceiveMessageDynamicDelegate__DelegateSignature(struct FNewChatListMessageData& Msg); // Offset: 0x1032a8bf4 // Return & Params: Num(1) Size(0x178)

	// Object Name: Function LimNativeWidget.LimChatManager.OnMiscConfigInfoHandle
	// Flags: [Final|Native|Protected|HasOutParms]
	void OnMiscConfigInfoHandle(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeGetMiscConfigInfoCallBack& RetData); // Offset: 0x10122e6e4 // Return & Params: Num(2) Size(0x80)

	// Object Name: Function LimNativeWidget.LimChatManager.OnMessageSend
	// Flags: [Final|Native|Protected|HasOutParms]
	void OnMessageSend(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnSendMsgCallBack& RetData); // Offset: 0x10122efc0 // Return & Params: Num(2) Size(0xd0)

	// Object Name: Function LimNativeWidget.LimChatManager.OnMessageReceived
	// Flags: [Final|Native|Protected|HasOutParms]
	void OnMessageReceived(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnMsgReceivedEventCallBack& RetData); // Offset: 0x10122f174 // Return & Params: Num(2) Size(0x50)

	// Object Name: DelegateFunction LimNativeWidget.LimChatManager.OnLoginDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnLoginDynamicDelegate__DelegateSignature(bool LoginRes, int32_t Code, struct FString RetData); // Offset: 0x1032a8bf4 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function LimNativeWidget.LimChatManager.OnLogin
	// Flags: [Final|Native|Protected|HasOutParms]
	void OnLogin(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnLoginCallBack& RetData); // Offset: 0x10122ee04 // Return & Params: Num(2) Size(0x40)

	// Object Name: Function LimNativeWidget.LimChatManager.OnLogicMsgReceived
	// Flags: [Final|Native|Protected|HasOutParms]
	void OnLogicMsgReceived(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnMsgLogicReceivedEventCallBack& RetData); // Offset: 0x10122ea98 // Return & Params: Num(2) Size(0x48)

	// Object Name: Function LimNativeWidget.LimChatManager.OnLog
	// Flags: [Final|Native|Protected|HasOutParms]
	void OnLog(struct FLimNativeLowLevelWrapper& InWrapper, struct FString Data); // Offset: 0x10122f6c0 // Return & Params: Num(2) Size(0x20)

	// Object Name: DelegateFunction LimNativeWidget.LimChatManager.OnInputBoxStateChangeDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnInputBoxStateChangeDelegate__DelegateSignature(bool bUp, int32_t Left, int32_t Top, int32_t Right, int32_t Bottom); // Offset: 0x1032a8bf4 // Return & Params: Num(5) Size(0x14)

	// Object Name: DelegateFunction LimNativeWidget.LimChatManager.OnGetUsersStateCallBackDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnGetUsersStateCallBackDynamicDelegate__DelegateSignature(); // Offset: 0x1032a8bf4 // Return & Params: Num(0) Size(0x0)

	// Object Name: DelegateFunction LimNativeWidget.LimChatManager.OnGetUsersCallBackDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void OnGetUsersCallBackDynamicDelegate__DelegateSignature(struct TArray<struct FChatListUserData>& UserDataList); // Offset: 0x1032a8bf4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LimNativeWidget.LimChatManager.OnGetUserListState
	// Flags: [Final|Native|Protected|HasOutParms]
	void OnGetUserListState(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnGetUsersStateCallBack& RetData); // Offset: 0x10122d864 // Return & Params: Num(2) Size(0xb8)

	// Object Name: Function LimNativeWidget.LimChatManager.OnGetUserListInfo
	// Flags: [Final|Native|Protected|HasOutParms]
	void OnGetUserListInfo(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnGetUsersCallBack& RetData); // Offset: 0x10122da00 // Return & Params: Num(2) Size(0x78)

	// Object Name: Function LimNativeWidget.LimChatManager.OnGetUserInfo
	// Flags: [Final|Native|Protected|HasOutParms]
	void OnGetUserInfo(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnGetUserCallBack& RetData); // Offset: 0x10122dc04 // Return & Params: Num(2) Size(0x178)

	// Object Name: DelegateFunction LimNativeWidget.LimChatManager.OnGetUserCallBackDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void OnGetUserCallBackDynamicDelegate__DelegateSignature(struct FChatListUserData& UserData); // Offset: 0x1032a8bf4 // Return & Params: Num(1) Size(0x50)

	// Object Name: Function LimNativeWidget.LimChatManager.OnGetTextTranslateHandle
	// Flags: [Final|Native|Protected|HasOutParms]
	void OnGetTextTranslateHandle(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeTextTranslateCallBack& RetData); // Offset: 0x10122e024 // Return & Params: Num(2) Size(0x98)

	// Object Name: Function LimNativeWidget.LimChatManager.OnGetNetStatHandle
	// Flags: [Final|Native|Protected|HasOutParms]
	void OnGetNetStatHandle(struct FLimNativeLowLevelWrapper& InWrapper, int32_t RetData); // Offset: 0x10122e42c // Return & Params: Num(2) Size(0x14)

	// Object Name: DelegateFunction LimNativeWidget.LimChatManager.OnGetNetStatDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnGetNetStatDynamicDelegate__DelegateSignature(int32_t val); // Offset: 0x1032a8bf4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LimNativeWidget.LimChatManager.OnGetMessageInRange
	// Flags: [Final|Native|Protected|HasOutParms]
	void OnGetMessageInRange(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnGetMsgsCallBack& RetData); // Offset: 0x10122f340 // Return & Params: Num(2) Size(0x58)

	// Object Name: DelegateFunction LimNativeWidget.LimChatManager.OnGetMessageDataDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnGetMessageDataDynamicDelegate__DelegateSignature(int32_t Code, struct FString ConvID, enum class ELimNativeConvType ConvType); // Offset: 0x1032a8bf4 // Return & Params: Num(3) Size(0x19)

	// Object Name: DelegateFunction LimNativeWidget.LimChatManager.OnGetFriendsCallBackDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void OnGetFriendsCallBackDynamicDelegate__DelegateSignature(struct TArray<struct FChatListUserData>& FriendList); // Offset: 0x1032a8bf4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LimNativeWidget.LimChatManager.OnGetFriends
	// Flags: [Final|Native|Protected|HasOutParms]
	void OnGetFriends(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnGetFriendCallBack& RetData); // Offset: 0x10122de20 // Return & Params: Num(2) Size(0x78)

	// Object Name: Function LimNativeWidget.LimChatManager.OnGetConnStateHandle
	// Flags: [Final|Native|Protected|HasOutParms]
	void OnGetConnStateHandle(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeGetConnStateCallBack& RetData); // Offset: 0x10122e55c // Return & Params: Num(2) Size(0x50)

	// Object Name: DelegateFunction LimNativeWidget.LimChatManager.OnGetConnStatDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnGetConnStatDynamicDelegate__DelegateSignature(bool Result, int32_t val); // Offset: 0x1032a8bf4 // Return & Params: Num(2) Size(0x8)

	// Object Name: DelegateFunction LimNativeWidget.LimChatManager.OnConvsGetDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnConvsGetDynamicDelegate__DelegateSignature(bool GetConvRes); // Offset: 0x1032a8bf4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LimNativeWidget.LimChatManager.OnConvRead
	// Flags: [Final|Native|Protected|HasOutParms]
	void OnConvRead(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnSetConvReadCallBack& RetData); // Offset: 0x10122ec48 // Return & Params: Num(2) Size(0x40)

	// Object Name: Function LimNativeWidget.LimChatManager.OnConvListGet
	// Flags: [Final|Native|Protected|HasOutParms]
	void OnConvListGet(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnConvsGetCallBack& RetData); // Offset: 0x10122f4f4 // Return & Params: Num(2) Size(0x58)

	// Object Name: DelegateFunction LimNativeWidget.LimChatManager.OnConvHandleDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void OnConvHandleDynamicDelegate__DelegateSignature(bool Result, struct FLimNativeConvHandleCallBackData& Data); // Offset: 0x1032a8bf4 // Return & Params: Num(2) Size(0x40)

	// Object Name: Function LimNativeWidget.LimChatManager.OnConvHandle
	// Flags: [Final|Native|Protected|HasOutParms]
	void OnConvHandle(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnConvHandleCallBack& RetData); // Offset: 0x10122e8c0 // Return & Params: Num(2) Size(0x78)

	// Object Name: Function LimNativeWidget.LimChatManager.OnConvChatLevelConfig
	// Flags: [Final|Native|Protected|HasOutParms]
	void OnConvChatLevelConfig(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnGetConvChatLevelConfigCallBack& RetData); // Offset: 0x10122e228 // Return & Params: Num(2) Size(0x50)

	// Object Name: DelegateFunction LimNativeWidget.LimChatManager.OnConfigInfoHandleDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnConfigInfoHandleDynamicDelegate__DelegateSignature(bool Result, int32_t val); // Offset: 0x1032a8bf4 // Return & Params: Num(2) Size(0x8)

	// Object Name: DelegateFunction LimNativeWidget.LimChatManager.OnConfigGetChatLevlDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnConfigGetChatLevlDynamicDelegate__DelegateSignature(bool Result); // Offset: 0x1032a8bf4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LimNativeWidget.LimChatManager.Logout
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Logout(); // Offset: 0x101230c90 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LimNativeWidget.LimChatManager.Login
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Login(struct FString InAppId, struct FString InAppUserID, struct FString InToken, struct FString InRoleID, struct FString InExtra); // Offset: 0x101230ca4 // Return & Params: Num(5) Size(0x50)

	// Object Name: Function LimNativeWidget.LimChatManager.InitChatManager
	// Flags: [Final|Native|Public|BlueprintCallable]
	void InitChatManager(struct FLimNativeInitConfig InitConfig, struct FString InEnvId, struct FString InGMEUserID); // Offset: 0x101231270 // Return & Params: Num(3) Size(0x80)

	// Object Name: Function LimNativeWidget.LimChatManager.GetUserListState
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void GetUserListState(struct TArray<struct FString>& InUserIDList); // Offset: 0x1012307b0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LimNativeWidget.LimChatManager.GetUserListInfo
	// Flags: [Final|Native|Public|BlueprintCallable]
	void GetUserListInfo(struct TArray<struct FString> InUserIDList); // Offset: 0x10123087c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LimNativeWidget.LimChatManager.GetUserInfo
	// Flags: [Final|Native|Public|BlueprintCallable]
	void GetUserInfo(struct FString InUserId); // Offset: 0x101230a2c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LimNativeWidget.LimChatManager.GetMiscConfigInfo
	// Flags: [Final|Native|Public|BlueprintCallable]
	void GetMiscConfigInfo(); // Offset: 0x101230c68 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LimNativeWidget.LimChatManager.GetMessageInRange
	// Flags: [Final|Native|Public]
	void GetMessageInRange(struct FString ConvID, enum class ELimNativeConvType ConvType, struct FString FromMsgId, struct FString ToMsgId); // Offset: 0x101230acc // Return & Params: Num(4) Size(0x38)

	// Object Name: Function LimNativeWidget.LimChatManager.GetMessage
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	void GetMessage(struct FChatListConvData& TargetConv); // Offset: 0x10122fbe0 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function LimNativeWidget.LimChatManager.GetLimSlssvr
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetLimSlssvr(); // Offset: 0x101230f50 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LimNativeWidget.LimChatManager.GetLimSDKRegion
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetLimSDKRegion(); // Offset: 0x101231004 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LimNativeWidget.LimChatManager.GetLimGameID
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int32_t GetLimGameID(); // Offset: 0x101230fd0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LimNativeWidget.LimChatManager.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct ULimChatManager* GetInstance(); // Offset: 0x101231644 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function LimNativeWidget.LimChatManager.GetFriendList
	// Flags: [Final|Native|Public|BlueprintCallable]
	void GetFriendList(); // Offset: 0x101230ab8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LimNativeWidget.LimChatManager.GetFarlightDomain
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int32_t GetFarlightDomain(); // Offset: 0x101230f1c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LimNativeWidget.LimChatManager.GetConvMessage
	// Flags: [Final|Native|Public|BlueprintCallable]
	void GetConvMessage(struct FString ConvID, enum class ELimNativeConvType ConvType, struct FString FromMsgId, struct FString ToMsgId); // Offset: 0x10122f950 // Return & Params: Num(4) Size(0x38)

	// Object Name: Function LimNativeWidget.LimChatManager.GetConvList
	// Flags: [Final|Native|Public|BlueprintCallable]
	void GetConvList(); // Offset: 0x101230c7c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LimNativeWidget.LimChatManager.GetConvChatLevelConfig
	// Flags: [Final|Native|Public|BlueprintCallable]
	void GetConvChatLevelConfig(); // Offset: 0x10122f7fc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LimNativeWidget.LimChatManager.GetConnState
	// Flags: [Final|Native|Public|BlueprintCallable]
	void GetConnState(); // Offset: 0x101230c54 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LimNativeWidget.LimChatManager.DiscardConv
	// Flags: [Final|Native|Public|BlueprintCallable]
	void DiscardConv(struct FString ConvID, enum class ELimNativeConvType ConvType); // Offset: 0x10122f810 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function LimNativeWidget.LimChatManager.DestroyInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void DestroyInstance(); // Offset: 0x101231630 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LimNativeWidget.LimChatManager.CheckTargetIsContainIn
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	bool CheckTargetIsContainIn(struct FChatListConvData& InConvData); // Offset: 0x10122fc84 // Return & Params: Num(2) Size(0x19)
};

// Object Name: Class LimNativeWidget.LimNativeWidgetSettings
// Size: 0x188 // Inherited bytes: 0x38
struct ULimNativeWidgetSettings : UDeveloperSettings {
	// Fields
	struct FString rDownloadPath; // Offset: 0x38 // Size: 0x10
	int32_t FileIOThreadIntervalMs; // Offset: 0x48 // Size: 0x04
	float CachedDiskFileExpiredDuration; // Offset: 0x4c // Size: 0x04
	float CachedResponseExpiredDuration; // Offset: 0x50 // Size: 0x04
	int32_t CachedResponseMaxCount; // Offset: 0x54 // Size: 0x04
	struct FSoftObjectPath LocalizationTable; // Offset: 0x58 // Size: 0x18
	struct FString EnvId; // Offset: 0x70 // Size: 0x10
	struct FString GME_AppId; // Offset: 0x80 // Size: 0x10
	struct FString GME_PrivateKey; // Offset: 0x90 // Size: 0x10
	struct FString GME_Test_AppId; // Offset: 0xa0 // Size: 0x10
	struct FString GME_Test_PrivateKey; // Offset: 0xb0 // Size: 0x10
	bool bTestGmeEnv; // Offset: 0xc0 // Size: 0x01
	char pad_0xC1[0x3]; // Offset: 0xc1 // Size: 0x03
	float GME_EventTick; // Offset: 0xc4 // Size: 0x04
	int32_t MaxRecordingTime; // Offset: 0xc8 // Size: 0x04
	bool bShowLimSdkLog; // Offset: 0xcc // Size: 0x01
	char pad_0xCD[0x3]; // Offset: 0xcd // Size: 0x03
	struct FString Lim_SDKRegion; // Offset: 0xd0 // Size: 0x10
	int32_t Lim_GameID; // Offset: 0xe0 // Size: 0x04
	char pad_0xE4[0x4]; // Offset: 0xe4 // Size: 0x04
	struct FString Lim_Slssvr; // Offset: 0xe8 // Size: 0x10
	int32_t Use_Farlight_Domain; // Offset: 0xf8 // Size: 0x04
	char pad_0xFC[0x4]; // Offset: 0xfc // Size: 0x04
	struct FString Nertc_AppKey; // Offset: 0x100 // Size: 0x10
	struct FString Nertc_AppToken; // Offset: 0x110 // Size: 0x10
	struct FString Nertc_Test_AppKey; // Offset: 0x120 // Size: 0x10
	struct FString Nertc_Test_AppToken; // Offset: 0x130 // Size: 0x10
	struct FString Agora_AppKey; // Offset: 0x140 // Size: 0x10
	struct FString Agora_AppToken; // Offset: 0x150 // Size: 0x10
	struct FString Agora_Test_AppKey; // Offset: 0x160 // Size: 0x10
	struct FString Agora_Test_AppToken; // Offset: 0x170 // Size: 0x10
	bool bEnvOversea; // Offset: 0x180 // Size: 0x01
	char pad_0x181[0x7]; // Offset: 0x181 // Size: 0x07

	// Functions

	// Object Name: Function LimNativeWidget.LimNativeWidgetSettings.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct ULimNativeWidgetSettings* GetInstance(); // Offset: 0x101235014 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class LimNativeWidget.NertcManager
// Size: 0xe0 // Inherited bytes: 0x28
struct UNertcManager : UObject {
	// Fields
	char pad_0x28[0x10]; // Offset: 0x28 // Size: 0x10
	struct FMulticastInlineDelegate OnPermissionResult; // Offset: 0x38 // Size: 0x10
	struct FMulticastInlineDelegate OnEnterRoom; // Offset: 0x48 // Size: 0x10
	struct FMulticastInlineDelegate OnExitRoom; // Offset: 0x58 // Size: 0x10
	struct FMulticastInlineDelegate OnConnectionChanged; // Offset: 0x68 // Size: 0x10
	struct FMulticastInlineDelegate OnNertcUserInfoUpdate; // Offset: 0x78 // Size: 0x10
	struct FMulticastInlineDelegate OnNertcLocalInfoUpdate; // Offset: 0x88 // Size: 0x10
	struct FMulticastInlineDelegate OnUserRoomStateChange; // Offset: 0x98 // Size: 0x10
	struct FMulticastInlineDelegate OnAudioStateChanged; // Offset: 0xa8 // Size: 0x10
	struct TArray<int32_t> MuteUIDList; // Offset: 0xb8 // Size: 0x10
	char pad_0xC8[0x18]; // Offset: 0xc8 // Size: 0x18

	// Functions

	// Object Name: Function LimNativeWidget.NertcManager.UpdateSelfPosition
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void UpdateSelfPosition(struct FVector& InSelfPosition, struct FRotator& InSelfRotator); // Offset: 0x101236200 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function LimNativeWidget.NertcManager.UpdateAudioRecvRange
	// Flags: [Final|Native|Public|BlueprintCallable]
	void UpdateAudioRecvRange(int32_t InRange); // Offset: 0x1012362e4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LimNativeWidget.NertcManager.UnRegisterLuaEvent
	// Flags: [Event|Public|BlueprintEvent]
	void UnRegisterLuaEvent(); // Offset: 0x1032a8bf4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LimNativeWidget.NertcManager.Uninit
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Uninit(); // Offset: 0x1012369e0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LimNativeWidget.NertcManager.SwitchRoom
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SwitchRoom(struct FString RoomID, struct FString AppToken, int32_t Uid, int32_t TeamID, int32_t AudioDistance); // Offset: 0x1012365a8 // Return & Params: Num(5) Size(0x2c)

	// Object Name: Function LimNativeWidget.NertcManager.SetSubscribeAudioOnlyBy
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetSubscribeAudioOnlyBy(struct TArray<int32_t>& OpenIDList); // Offset: 0x101235d4c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LimNativeWidget.NertcManager.SetSubscribeAudioBlocklist
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetSubscribeAudioBlocklist(struct TArray<int32_t>& OpenIDList); // Offset: 0x101235e7c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LimNativeWidget.NertcManager.SetSubscribeAudioAllowlist
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetSubscribeAudioAllowlist(struct TArray<int32_t>& OpenIDList); // Offset: 0x101235de4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LimNativeWidget.NertcManager.SetRangeAudioTeamID
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetRangeAudioTeamID(int32_t TeamID); // Offset: 0x10123646c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LimNativeWidget.NertcManager.SetRangeAudioMode
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetRangeAudioMode(enum class EChatGMERangeAudioMode InAudioMode); // Offset: 0x1012363ec // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LimNativeWidget.NertcManager.SetClientRole
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetClientRole(bool bBroadCast); // Offset: 0x101236520 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LimNativeWidget.NertcManager.SetAudioSessionRestriction
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAudioSessionRestriction(); // Offset: 0x101235588 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LimNativeWidget.NertcManager.SetAudioSendAndRecvRules
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetAudioSendAndRecvRules(enum class EChatGMEAudioRouteSendType InSendType, struct TArray<int32_t>& InSendOpenIDList, enum class EChatGMEAudioRouteRecvType InRecvType, struct TArray<int32_t>& InRecvOpenIDList); // Offset: 0x101235f14 // Return & Params: Num(4) Size(0x30)

	// Object Name: Function LimNativeWidget.NertcManager.SelectSpeak
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SelectSpeak(struct FString InDeviceID); // Offset: 0x1012356cc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LimNativeWidget.NertcManager.SelectMic
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SelectMic(struct FString InDeviceID); // Offset: 0x101235758 // Return & Params: Num(1) Size(0x10)

	// Object Name: DelegateFunction LimNativeWidget.NertcManager.OnUserRoomStateChange__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnUserRoomStateChange__DelegateSignature(bool EnterRoom, int32_t Uid); // Offset: 0x1032a8bf4 // Return & Params: Num(2) Size(0x8)

	// Object Name: DelegateFunction LimNativeWidget.NertcManager.OnUserInfoUpdateDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnUserInfoUpdateDelegate__DelegateSignature(struct FNertcUserUpdateData UserData); // Offset: 0x1032a8bf4 // Return & Params: Num(1) Size(0x10)

	// Object Name: DelegateFunction LimNativeWidget.NertcManager.OnNertcConnectionChange__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnNertcConnectionChange__DelegateSignature(int32_t State, int32_t reason); // Offset: 0x1032a8bf4 // Return & Params: Num(2) Size(0x8)

	// Object Name: DelegateFunction LimNativeWidget.NertcManager.OnLocalUserVolumeChanged__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnLocalUserVolumeChanged__DelegateSignature(int32_t Volume, bool bVad); // Offset: 0x1032a8bf4 // Return & Params: Num(2) Size(0x5)

	// Object Name: DelegateFunction LimNativeWidget.NertcManager.OnExitRoomDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnExitRoomDelegate__DelegateSignature(int32_t Result, int64_t reason); // Offset: 0x1032a8bf4 // Return & Params: Num(2) Size(0x10)

	// Object Name: DelegateFunction LimNativeWidget.NertcManager.OnEnterRoomDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnEnterRoomDelegate__DelegateSignature(int64_t RoomID, int32_t Uid, int32_t Result, int64_t Elapsed); // Offset: 0x1032a8bf4 // Return & Params: Num(4) Size(0x18)

	// Object Name: DelegateFunction LimNativeWidget.NertcManager.OnAudioDeviceStateChanged__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnAudioDeviceStateChanged__DelegateSignature(bool bChanged); // Offset: 0x1032a8bf4 // Return & Params: Num(1) Size(0x1)

	// Object Name: DelegateFunction LimNativeWidget.NertcManager.OnAndroidPermissionResult__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnAndroidPermissionResult__DelegateSignature(bool bSuccess); // Offset: 0x1032a8bf4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LimNativeWidget.NertcManager.MuteLocalStream
	// Flags: [Final|Native|Public|BlueprintCallable]
	void MuteLocalStream(bool bMute); // Offset: 0x1012360a8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LimNativeWidget.NertcManager.MediaMute
	// Flags: [Final|Native|Public|BlueprintCallable]
	void MediaMute(int32_t Uid, bool bMute); // Offset: 0x101236130 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function LimNativeWidget.NertcManager.IsRoomEntered
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsRoomEntered(); // Offset: 0x1012364ec // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LimNativeWidget.NertcManager.InnerEnterRoom
	// Flags: [Final|Native|Public|BlueprintCallable]
	void InnerEnterRoom(struct FString RoomID, struct FString AppToken, int32_t Uid); // Offset: 0x101236780 // Return & Params: Num(3) Size(0x24)

	// Object Name: Function LimNativeWidget.NertcManager.InnerEnableMic
	// Flags: [Final|Native|Public|BlueprintCallable]
	void InnerEnableMic(bool InEnable); // Offset: 0x101235bb4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LimNativeWidget.NertcManager.Init
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Init(struct FString Appkey); // Offset: 0x1012369f4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LimNativeWidget.NertcManager.GetSpeakerList
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct TArray<struct FChatGMEDataDeviceInfo> GetSpeakerList(); // Offset: 0x1012357e4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LimNativeWidget.NertcManager.GetMicList
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct TArray<struct FChatGMEDataDeviceInfo> GetMicList(); // Offset: 0x10123593c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LimNativeWidget.NertcManager.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UNertcManager* GetInstance(); // Offset: 0x101236a94 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function LimNativeWidget.NertcManager.GameSetSpeakerVolume
	// Flags: [Final|Native|Public|BlueprintCallable]
	int32_t GameSetSpeakerVolume(int32_t Volume); // Offset: 0x101235a94 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function LimNativeWidget.NertcManager.GameSetMicVolume
	// Flags: [Final|Native|Public|BlueprintCallable]
	int32_t GameSetMicVolume(int32_t MicVolume); // Offset: 0x101235b24 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function LimNativeWidget.NertcManager.ExitRoom
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ExitRoom(); // Offset: 0x10123676c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LimNativeWidget.NertcManager.EnterRoom
	// Flags: [Final|Native|Public|BlueprintCallable]
	void EnterRoom(struct FString RoomID, struct FString AppToken, int32_t Uid); // Offset: 0x1012368b0 // Return & Params: Num(3) Size(0x24)

	// Object Name: Function LimNativeWidget.NertcManager.EnableSpeaker
	// Flags: [Final|Native|Public|BlueprintCallable]
	void EnableSpeaker(bool InEnable); // Offset: 0x101235cc4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LimNativeWidget.NertcManager.EnableRangeVoice
	// Flags: [Final|Native|Public|BlueprintCallable]
	void EnableRangeVoice(bool bEnbale); // Offset: 0x101236364 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LimNativeWidget.NertcManager.EnableMic
	// Flags: [Final|Native|Public|BlueprintCallable]
	void EnableMic(bool InEnable); // Offset: 0x101235c3c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LimNativeWidget.NertcManager.EnabelAudioIndication
	// Flags: [Final|Native|Public|BlueprintCallable]
	void EnabelAudioIndication(bool InEnable, int32_t millions, bool bEnbaleLocal); // Offset: 0x10123559c // Return & Params: Num(3) Size(0x9)

	// Object Name: Function LimNativeWidget.NertcManager.DestroyInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void DestroyInstance(); // Offset: 0x101236a80 // Return & Params: Num(0) Size(0x0)
};

