#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class MRMesh.MeshReconstructorBase
// Size: 0x28 // Inherited bytes: 0x28
struct UMeshReconstructorBase : UObject {
	// Functions

	// Object Name: Function MRMesh.MeshReconstructorBase.StopReconstruction
	// Flags: [Native|Public|BlueprintCallable]
	void StopReconstruction(); // Offset: 0x103998cb8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function MRMesh.MeshReconstructorBase.StartReconstruction
	// Flags: [Native|Public|BlueprintCallable]
	void StartReconstruction(); // Offset: 0x103998cd4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function MRMesh.MeshReconstructorBase.PauseReconstruction
	// Flags: [Native|Public|BlueprintCallable]
	void PauseReconstruction(); // Offset: 0x103998c9c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function MRMesh.MeshReconstructorBase.IsReconstructionStarted
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsReconstructionStarted(); // Offset: 0x103998c60 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function MRMesh.MeshReconstructorBase.IsReconstructionPaused
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsReconstructionPaused(); // Offset: 0x103998c24 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function MRMesh.MeshReconstructorBase.DisconnectMRMesh
	// Flags: [Native|Public]
	void DisconnectMRMesh(); // Offset: 0x103998b80 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function MRMesh.MeshReconstructorBase.ConnectMRMesh
	// Flags: [Native|Public]
	void ConnectMRMesh(struct UMRMeshComponent* Mesh); // Offset: 0x103998b9c // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class MRMesh.MockDataMeshTrackerComponent
// Size: 0x3c0 // Inherited bytes: 0x350
struct UMockDataMeshTrackerComponent : USceneComponent {
	// Fields
	struct FMulticastInlineDelegate OnMeshTrackerUpdated; // Offset: 0x348 // Size: 0x10
	bool ScanWorld; // Offset: 0x358 // Size: 0x01
	bool RequestNormals; // Offset: 0x359 // Size: 0x01
	bool RequestVertexConfidence; // Offset: 0x35a // Size: 0x01
	enum class EMeshTrackerVertexColorMode VertexColorMode; // Offset: 0x35b // Size: 0x01
	struct TArray<struct FColor> BlockVertexColors; // Offset: 0x360 // Size: 0x10
	struct FLinearColor VertexColorFromConfidenceZero; // Offset: 0x370 // Size: 0x10
	struct FLinearColor VertexColorFromConfidenceOne; // Offset: 0x380 // Size: 0x10
	float UpdateInterval; // Offset: 0x390 // Size: 0x04
	struct UMRMeshComponent* MRMesh; // Offset: 0x398 // Size: 0x08
	char pad_0x3A0[0x20]; // Offset: 0x3a0 // Size: 0x20

	// Functions

	// Object Name: DelegateFunction MRMesh.MockDataMeshTrackerComponent.OnMockDataMeshTrackerUpdated__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void OnMockDataMeshTrackerUpdated__DelegateSignature(int32_t Index, struct TArray<struct FVector>& Vertices, struct TArray<int32_t>& Triangles, struct TArray<struct FVector>& Normals, struct TArray<float>& Confidence); // Offset: 0x1032a8bf4 // Return & Params: Num(5) Size(0x48)

	// Object Name: Function MRMesh.MockDataMeshTrackerComponent.DisconnectMRMesh
	// Flags: [Final|Native|Public|BlueprintCallable]
	void DisconnectMRMesh(struct UMRMeshComponent* InMRMeshPtr); // Offset: 0x103999314 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function MRMesh.MockDataMeshTrackerComponent.ConnectMRMesh
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ConnectMRMesh(struct UMRMeshComponent* InMRMeshPtr); // Offset: 0x103999394 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class MRMesh.MRMeshComponent
// Size: 0x5f0 // Inherited bytes: 0x570
struct UMRMeshComponent : UPrimitiveComponent {
	// Fields
	char pad_0x570[0x8]; // Offset: 0x570 // Size: 0x08
	struct UMaterialInterface* Material; // Offset: 0x578 // Size: 0x08
	bool bCreateMeshProxySections; // Offset: 0x580 // Size: 0x01
	bool bUpdateNavMeshOnMeshUpdate; // Offset: 0x581 // Size: 0x01
	bool bNeverCreateCollisionMesh; // Offset: 0x582 // Size: 0x01
	char pad_0x583[0x5]; // Offset: 0x583 // Size: 0x05
	struct UBodySetup* CachedBodySetup; // Offset: 0x588 // Size: 0x08
	struct TArray<struct UBodySetup*> BodySetups; // Offset: 0x590 // Size: 0x10
	struct UMaterialInterface* WireframeMaterial; // Offset: 0x5a0 // Size: 0x08
	char pad_0x5A8[0x48]; // Offset: 0x5a8 // Size: 0x48

	// Functions

	// Object Name: Function MRMesh.MRMeshComponent.IsConnected
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsConnected(); // Offset: 0x103999690 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function MRMesh.MRMeshComponent.ForceNavMeshUpdate
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ForceNavMeshUpdate(); // Offset: 0x10399967c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function MRMesh.MRMeshComponent.Clear
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Clear(); // Offset: 0x103999660 // Return & Params: Num(0) Size(0x0)
};

