#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class MaterialShaderQualitySettings.MaterialShaderQualitySettings
// Size: 0x78 // Inherited bytes: 0x28
struct UMaterialShaderQualitySettings : UObject {
	// Fields
	struct TMap<struct FName, struct UShaderPlatformQualitySettings*> ForwardSettingMap; // Offset: 0x28 // Size: 0x50
};

// Object Name: Class MaterialShaderQualitySettings.ShaderPlatformQualitySettings
// Size: 0x58 // Inherited bytes: 0x28
struct UShaderPlatformQualitySettings : UObject {
	// Fields
	struct FMaterialQualityOverrides QualityOverrides[0x3]; // Offset: 0x28 // Size: 0x1b
	char pad_0x43[0x15]; // Offset: 0x43 // Size: 0x15
};

