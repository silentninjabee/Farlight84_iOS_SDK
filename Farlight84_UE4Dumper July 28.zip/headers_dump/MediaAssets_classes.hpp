#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class MediaAssets.MediaSource
// Size: 0x80 // Inherited bytes: 0x28
struct UMediaSource : UObject {
	// Fields
	char pad_0x28[0x58]; // Offset: 0x28 // Size: 0x58

	// Functions

	// Object Name: Function MediaAssets.MediaSource.Validate
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool Validate(); // Offset: 0x104491230 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function MediaAssets.MediaSource.SetMediaOptionString
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetMediaOptionString(struct FName& Key, struct FString Value); // Offset: 0x104490e98 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function MediaAssets.MediaSource.SetMediaOptionInt64
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetMediaOptionInt64(struct FName& Key, int64_t Value); // Offset: 0x104490f7c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function MediaAssets.MediaSource.SetMediaOptionFloat
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetMediaOptionFloat(struct FName& Key, float Value); // Offset: 0x104491060 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function MediaAssets.MediaSource.SetMediaOptionBool
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetMediaOptionBool(struct FName& Key, bool Value); // Offset: 0x104491144 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function MediaAssets.MediaSource.GetUrl
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FString GetUrl(); // Offset: 0x10449126c // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class MediaAssets.BaseMediaSource
// Size: 0x88 // Inherited bytes: 0x80
struct UBaseMediaSource : UMediaSource {
	// Fields
	struct FName playerName; // Offset: 0x80 // Size: 0x08
};

// Object Name: Class MediaAssets.FileMediaSource
// Size: 0xb0 // Inherited bytes: 0x88
struct UFileMediaSource : UBaseMediaSource {
	// Fields
	struct FString FilePath; // Offset: 0x88 // Size: 0x10
	bool PrecacheFile; // Offset: 0x98 // Size: 0x01
	char pad_0x99[0x17]; // Offset: 0x99 // Size: 0x17

	// Functions

	// Object Name: Function MediaAssets.FileMediaSource.SetFilePath
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetFilePath(struct FString Path); // Offset: 0x104489b50 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class MediaAssets.MediaBlueprintFunctionLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct UMediaBlueprintFunctionLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function MediaAssets.MediaBlueprintFunctionLibrary.EnumerateWebcamCaptureDevices
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void EnumerateWebcamCaptureDevices(struct TArray<struct FMediaCaptureDevice>& OutDevices, int32_t Filter); // Offset: 0x10448a324 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function MediaAssets.MediaBlueprintFunctionLibrary.EnumerateVideoCaptureDevices
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void EnumerateVideoCaptureDevices(struct TArray<struct FMediaCaptureDevice>& OutDevices, int32_t Filter); // Offset: 0x10448a48c // Return & Params: Num(2) Size(0x14)

	// Object Name: Function MediaAssets.MediaBlueprintFunctionLibrary.EnumerateAudioCaptureDevices
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void EnumerateAudioCaptureDevices(struct TArray<struct FMediaCaptureDevice>& OutDevices, int32_t Filter); // Offset: 0x10448a5f4 // Return & Params: Num(2) Size(0x14)
};

// Object Name: Class MediaAssets.MediaComponent
// Size: 0xc0 // Inherited bytes: 0xb0
struct UMediaComponent : UActorComponent {
	// Fields
	struct UMediaTexture* MediaTexture; // Offset: 0xb0 // Size: 0x08
	struct UMediaPlayer* MediaPlayer; // Offset: 0xb8 // Size: 0x08

	// Functions

	// Object Name: Function MediaAssets.MediaComponent.GetMediaTexture
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UMediaTexture* GetMediaTexture(); // Offset: 0x10448aa30 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function MediaAssets.MediaComponent.GetMediaPlayer
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UMediaPlayer* GetMediaPlayer(); // Offset: 0x10448aa64 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class MediaAssets.MediaPlayer
// Size: 0x138 // Inherited bytes: 0x28
struct UMediaPlayer : UObject {
	// Fields
	struct FMulticastInlineDelegate OnEndReached; // Offset: 0x28 // Size: 0x10
	struct FMulticastInlineDelegate OnMediaClosed; // Offset: 0x38 // Size: 0x10
	struct FMulticastInlineDelegate OnMediaOpened; // Offset: 0x48 // Size: 0x10
	struct FMulticastInlineDelegate OnMediaOpenFailed; // Offset: 0x58 // Size: 0x10
	struct FMulticastInlineDelegate OnPlaybackResumed; // Offset: 0x68 // Size: 0x10
	struct FMulticastInlineDelegate OnPlaybackSuspended; // Offset: 0x78 // Size: 0x10
	struct FMulticastInlineDelegate OnSeekCompleted; // Offset: 0x88 // Size: 0x10
	struct FMulticastInlineDelegate OnTracksChanged; // Offset: 0x98 // Size: 0x10
	struct FTimespan CacheAhead; // Offset: 0xa8 // Size: 0x08
	struct FTimespan CacheBehind; // Offset: 0xb0 // Size: 0x08
	struct FTimespan CacheBehindGame; // Offset: 0xb8 // Size: 0x08
	bool NativeAudioOut; // Offset: 0xc0 // Size: 0x01
	bool PlayOnOpen; // Offset: 0xc1 // Size: 0x01
	char Shuffle : 1; // Offset: 0xc2 // Size: 0x01
	char Loop : 1; // Offset: 0xc2 // Size: 0x01
	char pad_0xC2_2 : 6; // Offset: 0xc2 // Size: 0x01
	char pad_0xC3[0x5]; // Offset: 0xc3 // Size: 0x05
	struct UMediaPlaylist* Playlist; // Offset: 0xc8 // Size: 0x08
	int32_t PlaylistIndex; // Offset: 0xd0 // Size: 0x04
	char pad_0xD4[0x4]; // Offset: 0xd4 // Size: 0x04
	struct FTimespan TimeDelay; // Offset: 0xd8 // Size: 0x08
	float HorizontalFieldOfView; // Offset: 0xe0 // Size: 0x04
	float VerticalFieldOfView; // Offset: 0xe4 // Size: 0x04
	struct FRotator ViewRotation; // Offset: 0xe8 // Size: 0x0c
	char pad_0xF4[0x2c]; // Offset: 0xf4 // Size: 0x2c
	struct FGuid PlayerGuid; // Offset: 0x120 // Size: 0x10
	char pad_0x130[0x8]; // Offset: 0x130 // Size: 0x08

	// Functions

	// Object Name: Function MediaAssets.MediaPlayer.SupportsSeeking
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool SupportsSeeking(); // Offset: 0x10448b0b8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function MediaAssets.MediaPlayer.SupportsScrubbing
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool SupportsScrubbing(); // Offset: 0x10448b0ec // Return & Params: Num(1) Size(0x1)

	// Object Name: Function MediaAssets.MediaPlayer.SupportsRate
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool SupportsRate(float Rate, bool Unthinned); // Offset: 0x10448b120 // Return & Params: Num(3) Size(0x6)

	// Object Name: Function MediaAssets.MediaPlayer.SetViewRotation
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	bool SetViewRotation(struct FRotator& Rotation, bool Absolute); // Offset: 0x10448b280 // Return & Params: Num(3) Size(0xe)

	// Object Name: Function MediaAssets.MediaPlayer.SetViewField
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool SetViewField(float Horizontal, float Vertical, bool Absolute); // Offset: 0x10448b370 // Return & Params: Num(4) Size(0xa)

	// Object Name: Function MediaAssets.MediaPlayer.SetVideoTrackFrameRate
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool SetVideoTrackFrameRate(int32_t TrackIndex, int32_t FormatIndex, float FrameRate); // Offset: 0x10448b49c // Return & Params: Num(4) Size(0xd)

	// Object Name: Function MediaAssets.MediaPlayer.SetTrackFormat
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool SetTrackFormat(enum class EMediaPlayerTrack TrackType, int32_t TrackIndex, int32_t FormatIndex); // Offset: 0x10448b5c0 // Return & Params: Num(4) Size(0xd)

	// Object Name: Function MediaAssets.MediaPlayer.SetTimeDelay
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetTimeDelay(struct FTimespan TimeDelay); // Offset: 0x10448b204 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function MediaAssets.MediaPlayer.SetRate
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool SetRate(float Rate); // Offset: 0x10448b774 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function MediaAssets.MediaPlayer.SetNativeVolume
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool SetNativeVolume(float Volume); // Offset: 0x10448b6e4 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function MediaAssets.MediaPlayer.SetMediaOptions
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMediaOptions(struct UMediaSource* options); // Offset: 0x10448b804 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function MediaAssets.MediaPlayer.SetLooping
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool SetLooping(bool Looping); // Offset: 0x10448b884 // Return & Params: Num(2) Size(0x2)

	// Object Name: Function MediaAssets.MediaPlayer.SetDesiredPlayerName
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetDesiredPlayerName(struct FName playerName); // Offset: 0x10448b91c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function MediaAssets.MediaPlayer.SetBlockOnTime
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void SetBlockOnTime(struct FTimespan& Time); // Offset: 0x10448b99c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function MediaAssets.MediaPlayer.SelectTrack
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool SelectTrack(enum class EMediaPlayerTrack TrackType, int32_t TrackIndex); // Offset: 0x10448ba24 // Return & Params: Num(3) Size(0x9)

	// Object Name: Function MediaAssets.MediaPlayer.Seek
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	bool Seek(struct FTimespan& Time); // Offset: 0x10448bb00 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function MediaAssets.MediaPlayer.Rewind
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool Rewind(); // Offset: 0x10448bb98 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function MediaAssets.MediaPlayer.Reopen
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool Reopen(); // Offset: 0x10448bbcc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function MediaAssets.MediaPlayer.Previous
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool Previous(); // Offset: 0x10448bc00 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function MediaAssets.MediaPlayer.PlayAndSeek
	// Flags: [Final|Native|Public|BlueprintCallable]
	void PlayAndSeek(); // Offset: 0x10448bc34 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function MediaAssets.MediaPlayer.Play
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool Play(); // Offset: 0x10448bc48 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function MediaAssets.MediaPlayer.Pause
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool Pause(); // Offset: 0x10448bc7c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function MediaAssets.MediaPlayer.OpenUrl
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool OpenUrl(struct FString URL); // Offset: 0x10448bcb0 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function MediaAssets.MediaPlayer.OpenSourceWithOptions
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	bool OpenSourceWithOptions(struct UMediaSource* MediaSource, struct FMediaPlayerOptions& options); // Offset: 0x10448bf4c // Return & Params: Num(3) Size(0x39)

	// Object Name: Function MediaAssets.MediaPlayer.OpenSourceLatent
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void OpenSourceLatent(struct UObject* WorldContextObject, struct FLatentActionInfo LatentInfo, struct UMediaSource* MediaSource, struct FMediaPlayerOptions& options, bool& bSuccess); // Offset: 0x10448bd4c // Return & Params: Num(5) Size(0x59)

	// Object Name: Function MediaAssets.MediaPlayer.OpenSource
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool OpenSource(struct UMediaSource* MediaSource); // Offset: 0x10448c044 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function MediaAssets.MediaPlayer.OpenPlaylistIndex
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool OpenPlaylistIndex(struct UMediaPlaylist* InPlaylist, int32_t Index); // Offset: 0x10448c0d4 // Return & Params: Num(3) Size(0xd)

	// Object Name: Function MediaAssets.MediaPlayer.OpenPlaylist
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool OpenPlaylist(struct UMediaPlaylist* InPlaylist); // Offset: 0x10448c1b0 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function MediaAssets.MediaPlayer.OpenFile
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool OpenFile(struct FString FilePath); // Offset: 0x10448c244 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function MediaAssets.MediaPlayer.Next
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool Next(); // Offset: 0x10448c2e0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function MediaAssets.MediaPlayer.IsReady
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsReady(); // Offset: 0x10448c314 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function MediaAssets.MediaPlayer.IsPreparing
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsPreparing(); // Offset: 0x10448c37c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function MediaAssets.MediaPlayer.IsPlaying
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsPlaying(); // Offset: 0x10448c3b0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function MediaAssets.MediaPlayer.IsPaused
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsPaused(); // Offset: 0x10448c3e4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function MediaAssets.MediaPlayer.IsLooping
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsLooping(); // Offset: 0x10448c418 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function MediaAssets.MediaPlayer.IsConnecting
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsConnecting(); // Offset: 0x10448c44c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function MediaAssets.MediaPlayer.IsClosed
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsClosed(); // Offset: 0x10448c348 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function MediaAssets.MediaPlayer.IsBuffering
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsBuffering(); // Offset: 0x10448c480 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function MediaAssets.MediaPlayer.HasError
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool HasError(); // Offset: 0x10448c4b4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function MediaAssets.MediaPlayer.GetViewRotation
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FRotator GetViewRotation(); // Offset: 0x10448c51c // Return & Params: Num(1) Size(0xc)

	// Object Name: Function MediaAssets.MediaPlayer.GetVideoTrackType
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FString GetVideoTrackType(int32_t TrackIndex, int32_t FormatIndex); // Offset: 0x10448c554 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function MediaAssets.MediaPlayer.GetVideoTrackFrameRates
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FFloatRange GetVideoTrackFrameRates(int32_t TrackIndex, int32_t FormatIndex); // Offset: 0x10448c674 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function MediaAssets.MediaPlayer.GetVideoTrackFrameRate
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetVideoTrackFrameRate(int32_t TrackIndex, int32_t FormatIndex); // Offset: 0x10448c74c // Return & Params: Num(3) Size(0xc)

	// Object Name: Function MediaAssets.MediaPlayer.GetVideoTrackDimensions
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FIntPoint GetVideoTrackDimensions(int32_t TrackIndex, int32_t FormatIndex); // Offset: 0x10448c824 // Return & Params: Num(3) Size(0x10)

	// Object Name: Function MediaAssets.MediaPlayer.GetVideoTrackAspectRatio
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetVideoTrackAspectRatio(int32_t TrackIndex, int32_t FormatIndex); // Offset: 0x10448c8fc // Return & Params: Num(3) Size(0xc)

	// Object Name: Function MediaAssets.MediaPlayer.GetVerticalFieldOfView
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetVerticalFieldOfView(); // Offset: 0x10448c9d4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MediaAssets.MediaPlayer.GetUrl
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FString GetUrl(); // Offset: 0x10448ca08 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function MediaAssets.MediaPlayer.GetTrackLanguage
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FString GetTrackLanguage(enum class EMediaPlayerTrack TrackType, int32_t TrackIndex); // Offset: 0x10448ca8c // Return & Params: Num(3) Size(0x18)

	// Object Name: Function MediaAssets.MediaPlayer.GetTrackFormat
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetTrackFormat(enum class EMediaPlayerTrack TrackType, int32_t TrackIndex); // Offset: 0x10448cbb0 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function MediaAssets.MediaPlayer.GetTrackDisplayName
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FText GetTrackDisplayName(enum class EMediaPlayerTrack TrackType, int32_t TrackIndex); // Offset: 0x10448cc8c // Return & Params: Num(3) Size(0x20)

	// Object Name: Function MediaAssets.MediaPlayer.GetTimeDelay
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FTimespan GetTimeDelay(); // Offset: 0x10448c4e8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function MediaAssets.MediaPlayer.GetTime
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FTimespan GetTime(); // Offset: 0x10448ce3c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function MediaAssets.MediaPlayer.GetSupportedRates
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetSupportedRates(struct TArray<struct FFloatRange>& OutRates, bool Unthinned); // Offset: 0x10448ce70 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function MediaAssets.MediaPlayer.GetSelectedTrack
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetSelectedTrack(enum class EMediaPlayerTrack TrackType); // Offset: 0x10448cf5c // Return & Params: Num(2) Size(0x8)

	// Object Name: Function MediaAssets.MediaPlayer.GetRate
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetRate(); // Offset: 0x10448cfec // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MediaAssets.MediaPlayer.GetPlaylistIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetPlaylistIndex(); // Offset: 0x10448d020 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MediaAssets.MediaPlayer.GetPlaylist
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UMediaPlaylist* GetPlaylist(); // Offset: 0x10448d03c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function MediaAssets.MediaPlayer.GetPlayerName
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FName GetPlayerName(); // Offset: 0x10448d058 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function MediaAssets.MediaPlayer.GetNumTracks
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetNumTracks(enum class EMediaPlayerTrack TrackType); // Offset: 0x10448d168 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function MediaAssets.MediaPlayer.GetNumTrackFormats
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetNumTrackFormats(enum class EMediaPlayerTrack TrackType, int32_t TrackIndex); // Offset: 0x10448d08c // Return & Params: Num(3) Size(0xc)

	// Object Name: Function MediaAssets.MediaPlayer.GetMediaName
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FText GetMediaName(); // Offset: 0x10448d1f8 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function MediaAssets.MediaPlayer.GetLastVideoSampleProcessedTime
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FTimespan GetLastVideoSampleProcessedTime(); // Offset: 0x10448cdd4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function MediaAssets.MediaPlayer.GetLastAudioSampleProcessedTime
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FTimespan GetLastAudioSampleProcessedTime(); // Offset: 0x10448ce08 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function MediaAssets.MediaPlayer.GetHorizontalFieldOfView
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetHorizontalFieldOfView(); // Offset: 0x10448d2a8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MediaAssets.MediaPlayer.GetDuration
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FTimespan GetDuration(); // Offset: 0x10448d2dc // Return & Params: Num(1) Size(0x8)

	// Object Name: Function MediaAssets.MediaPlayer.GetDesiredPlayerName
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FName GetDesiredPlayerName(); // Offset: 0x10448d310 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function MediaAssets.MediaPlayer.GetAudioTrackType
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FString GetAudioTrackType(int32_t TrackIndex, int32_t FormatIndex); // Offset: 0x10448d344 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function MediaAssets.MediaPlayer.GetAudioTrackSampleRate
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetAudioTrackSampleRate(int32_t TrackIndex, int32_t FormatIndex); // Offset: 0x10448d464 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function MediaAssets.MediaPlayer.GetAudioTrackChannels
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetAudioTrackChannels(int32_t TrackIndex, int32_t FormatIndex); // Offset: 0x10448d53c // Return & Params: Num(3) Size(0xc)

	// Object Name: Function MediaAssets.MediaPlayer.Close
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Close(); // Offset: 0x10448d614 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function MediaAssets.MediaPlayer.CanPlayUrl
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool CanPlayUrl(struct FString URL); // Offset: 0x10448d628 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function MediaAssets.MediaPlayer.CanPlaySource
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool CanPlaySource(struct UMediaSource* MediaSource); // Offset: 0x10448d6c4 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function MediaAssets.MediaPlayer.CanPause
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool CanPause(); // Offset: 0x10448d754 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class MediaAssets.MediaPlaylist
// Size: 0x38 // Inherited bytes: 0x28
struct UMediaPlaylist : UObject {
	// Fields
	struct TArray<struct UMediaSource*> Items; // Offset: 0x28 // Size: 0x10

	// Functions

	// Object Name: Function MediaAssets.MediaPlaylist.Replace
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool Replace(int32_t Index, struct UMediaSource* Replacement); // Offset: 0x10448f348 // Return & Params: Num(3) Size(0x11)

	// Object Name: Function MediaAssets.MediaPlaylist.RemoveAt
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool RemoveAt(int32_t Index); // Offset: 0x10448f424 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function MediaAssets.MediaPlaylist.Remove
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool Remove(struct UMediaSource* MediaSource); // Offset: 0x10448f4b4 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function MediaAssets.MediaPlaylist.Num
	// Flags: [Final|Native|Public|BlueprintCallable]
	int32_t Num(); // Offset: 0x10448f544 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MediaAssets.MediaPlaylist.Insert
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Insert(struct UMediaSource* MediaSource, int32_t Index); // Offset: 0x10448f560 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function MediaAssets.MediaPlaylist.GetRandom
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	struct UMediaSource* GetRandom(int32_t& OutIndex); // Offset: 0x10448f62c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function MediaAssets.MediaPlaylist.GetPrevious
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	struct UMediaSource* GetPrevious(int32_t& InOutIndex); // Offset: 0x10448f6c8 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function MediaAssets.MediaPlaylist.GetNext
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	struct UMediaSource* GetNext(int32_t& InOutIndex); // Offset: 0x10448f764 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function MediaAssets.MediaPlaylist.Get
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UMediaSource* Get(int32_t Index); // Offset: 0x10448f800 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function MediaAssets.MediaPlaylist.AddUrl
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool AddUrl(struct FString URL); // Offset: 0x10448f890 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function MediaAssets.MediaPlaylist.AddFile
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool AddFile(struct FString FilePath); // Offset: 0x10448f92c // Return & Params: Num(2) Size(0x11)

	// Object Name: Function MediaAssets.MediaPlaylist.Add
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool Add(struct UMediaSource* MediaSource); // Offset: 0x10448f9c8 // Return & Params: Num(2) Size(0x9)
};

// Object Name: Class MediaAssets.MediaSoundComponent
// Size: 0xa70 // Inherited bytes: 0x820
struct UMediaSoundComponent : USynthComponent {
	// Fields
	enum class EMediaSoundChannels Channels; // Offset: 0x820 // Size: 0x04
	bool DynamicRateAdjustment; // Offset: 0x824 // Size: 0x01
	char pad_0x825[0x3]; // Offset: 0x825 // Size: 0x03
	float RateAdjustmentFactor; // Offset: 0x828 // Size: 0x04
	struct FFloatRange RateAdjustmentRange; // Offset: 0x82c // Size: 0x10
	char pad_0x83C[0x4]; // Offset: 0x83c // Size: 0x04
	struct UMediaPlayer* MediaPlayer; // Offset: 0x840 // Size: 0x08
	char pad_0x848[0x228]; // Offset: 0x848 // Size: 0x228

	// Functions

	// Object Name: Function MediaAssets.MediaSoundComponent.SetSpectralAnalysisSettings
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSpectralAnalysisSettings(struct TArray<float> InFrequenciesToAnalyze, enum class EMediaSoundComponentFFTSize InFFTSize); // Offset: 0x10449053c // Return & Params: Num(2) Size(0x11)

	// Object Name: Function MediaAssets.MediaSoundComponent.SetMediaPlayer
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMediaPlayer(struct UMediaPlayer* NewMediaPlayer); // Offset: 0x104490704 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function MediaAssets.MediaSoundComponent.SetEnvelopeFollowingsettings
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetEnvelopeFollowingsettings(int32_t AttackTimeMsec, int32_t ReleaseTimeMsec); // Offset: 0x10449036c // Return & Params: Num(2) Size(0x8)

	// Object Name: Function MediaAssets.MediaSoundComponent.SetEnableSpectralAnalysis
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetEnableSpectralAnalysis(bool bInSpectralAnalysisEnabled); // Offset: 0x10449067c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function MediaAssets.MediaSoundComponent.SetEnableEnvelopeFollowing
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetEnableEnvelopeFollowing(bool bInEnvelopeFollowing); // Offset: 0x104490434 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function MediaAssets.MediaSoundComponent.GetSpectralData
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct TArray<struct FMediaSoundComponentSpectralData> GetSpectralData(); // Offset: 0x1044904bc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function MediaAssets.MediaSoundComponent.GetMediaPlayer
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UMediaPlayer* GetMediaPlayer(); // Offset: 0x104490784 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function MediaAssets.MediaSoundComponent.GetEnvelopeValue
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetEnvelopeValue(); // Offset: 0x104490338 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MediaAssets.MediaSoundComponent.BP_GetAttenuationSettingsToApply
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	bool BP_GetAttenuationSettingsToApply(struct FSoundAttenuationSettings& OutAttenuationSettings); // Offset: 0x1044907b8 // Return & Params: Num(2) Size(0x3a1)
};

// Object Name: Class MediaAssets.MediaTexture
// Size: 0x1a0 // Inherited bytes: 0xb8
struct UMediaTexture : UTexture {
	// Fields
	enum class TextureAddress AddressX; // Offset: 0xb8 // Size: 0x01
	enum class TextureAddress AddressY; // Offset: 0xb9 // Size: 0x01
	bool AutoClear; // Offset: 0xba // Size: 0x01
	char pad_0xBB[0x1]; // Offset: 0xbb // Size: 0x01
	struct FLinearColor ClearColor; // Offset: 0xbc // Size: 0x10
	bool EnableGenMips; // Offset: 0xcc // Size: 0x01
	char NumMips; // Offset: 0xcd // Size: 0x01
	char pad_0xCE[0x2]; // Offset: 0xce // Size: 0x02
	struct UMediaPlayer* MediaPlayer; // Offset: 0xd0 // Size: 0x08
	char pad_0xD8[0xc8]; // Offset: 0xd8 // Size: 0xc8

	// Functions

	// Object Name: Function MediaAssets.MediaTexture.SetMediaPlayer
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMediaPlayer(struct UMediaPlayer* NewMediaPlayer); // Offset: 0x104491698 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function MediaAssets.MediaTexture.GetWidth
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetWidth(); // Offset: 0x104491718 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MediaAssets.MediaTexture.GetMediaPlayer
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UMediaPlayer* GetMediaPlayer(); // Offset: 0x10449174c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function MediaAssets.MediaTexture.GetHeight
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetHeight(); // Offset: 0x104491780 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MediaAssets.MediaTexture.GetAspectRatio
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetAspectRatio(); // Offset: 0x1044917b4 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class MediaAssets.PlatformMediaSource
// Size: 0x88 // Inherited bytes: 0x80
struct UPlatformMediaSource : UMediaSource {
	// Fields
	struct UMediaSource* MediaSource; // Offset: 0x80 // Size: 0x08
};

// Object Name: Class MediaAssets.StreamMediaSource
// Size: 0x98 // Inherited bytes: 0x88
struct UStreamMediaSource : UBaseMediaSource {
	// Fields
	struct FString StreamUrl; // Offset: 0x88 // Size: 0x10
};

// Object Name: Class MediaAssets.TimeSynchronizableMediaSource
// Size: 0x98 // Inherited bytes: 0x88
struct UTimeSynchronizableMediaSource : UBaseMediaSource {
	// Fields
	bool bUseTimeSynchronization; // Offset: 0x88 // Size: 0x01
	char pad_0x89[0x3]; // Offset: 0x89 // Size: 0x03
	int32_t FrameDelay; // Offset: 0x8c // Size: 0x04
	double TimeDelay; // Offset: 0x90 // Size: 0x08
};

