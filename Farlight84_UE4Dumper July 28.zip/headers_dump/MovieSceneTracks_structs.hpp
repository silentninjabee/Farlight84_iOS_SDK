#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct MovieSceneTracks.MovieSceneSpawnSectionTemplate
// Size: 0xa8 // Inherited bytes: 0x18
struct FMovieSceneSpawnSectionTemplate : FMovieSceneEvalTemplate {
	// Fields
	struct FMovieSceneBoolChannel Curve; // Offset: 0x18 // Size: 0x90
};

// Object Name: ScriptStruct MovieSceneTracks.MovieSceneParameterSectionTemplate
// Size: 0x78 // Inherited bytes: 0x18
struct FMovieSceneParameterSectionTemplate : FMovieSceneEvalTemplate {
	// Fields
	struct TArray<struct FScalarParameterNameAndCurve> Scalars; // Offset: 0x18 // Size: 0x10
	struct TArray<struct FBoolParameterNameAndCurve> Bools; // Offset: 0x28 // Size: 0x10
	struct TArray<struct FVector2DParameterNameAndCurves> Vector2Ds; // Offset: 0x38 // Size: 0x10
	struct TArray<struct FVectorParameterNameAndCurves> Vectors; // Offset: 0x48 // Size: 0x10
	struct TArray<struct FColorParameterNameAndCurves> Colors; // Offset: 0x58 // Size: 0x10
	struct TArray<struct FTransformParameterNameAndCurves> Transforms; // Offset: 0x68 // Size: 0x10
};

// Object Name: ScriptStruct MovieSceneTracks.TransformParameterNameAndCurves
// Size: 0x5a8 // Inherited bytes: 0x00
struct FTransformParameterNameAndCurves {
	// Fields
	struct FName ParameterName; // Offset: 0x00 // Size: 0x08
	struct FMovieSceneFloatChannel Translation[0x3]; // Offset: 0x08 // Size: 0x1e0
	struct FMovieSceneFloatChannel Rotation[0x3]; // Offset: 0x1e8 // Size: 0x1e0
	struct FMovieSceneFloatChannel Scale[0x3]; // Offset: 0x3c8 // Size: 0x1e0
};

// Object Name: ScriptStruct MovieSceneTracks.ColorParameterNameAndCurves
// Size: 0x288 // Inherited bytes: 0x00
struct FColorParameterNameAndCurves {
	// Fields
	struct FName ParameterName; // Offset: 0x00 // Size: 0x08
	struct FMovieSceneFloatChannel RedCurve; // Offset: 0x08 // Size: 0xa0
	struct FMovieSceneFloatChannel GreenCurve; // Offset: 0xa8 // Size: 0xa0
	struct FMovieSceneFloatChannel BlueCurve; // Offset: 0x148 // Size: 0xa0
	struct FMovieSceneFloatChannel AlphaCurve; // Offset: 0x1e8 // Size: 0xa0
};

// Object Name: ScriptStruct MovieSceneTracks.VectorParameterNameAndCurves
// Size: 0x1e8 // Inherited bytes: 0x00
struct FVectorParameterNameAndCurves {
	// Fields
	struct FName ParameterName; // Offset: 0x00 // Size: 0x08
	struct FMovieSceneFloatChannel XCurve; // Offset: 0x08 // Size: 0xa0
	struct FMovieSceneFloatChannel YCurve; // Offset: 0xa8 // Size: 0xa0
	struct FMovieSceneFloatChannel ZCurve; // Offset: 0x148 // Size: 0xa0
};

// Object Name: ScriptStruct MovieSceneTracks.Vector2DParameterNameAndCurves
// Size: 0x148 // Inherited bytes: 0x00
struct FVector2DParameterNameAndCurves {
	// Fields
	struct FName ParameterName; // Offset: 0x00 // Size: 0x08
	struct FMovieSceneFloatChannel XCurve; // Offset: 0x08 // Size: 0xa0
	struct FMovieSceneFloatChannel YCurve; // Offset: 0xa8 // Size: 0xa0
};

// Object Name: ScriptStruct MovieSceneTracks.BoolParameterNameAndCurve
// Size: 0x98 // Inherited bytes: 0x00
struct FBoolParameterNameAndCurve {
	// Fields
	struct FName ParameterName; // Offset: 0x00 // Size: 0x08
	struct FMovieSceneBoolChannel ParameterCurve; // Offset: 0x08 // Size: 0x90
};

// Object Name: ScriptStruct MovieSceneTracks.ScalarParameterNameAndCurve
// Size: 0xa8 // Inherited bytes: 0x00
struct FScalarParameterNameAndCurve {
	// Fields
	struct FName ParameterName; // Offset: 0x00 // Size: 0x08
	struct FMovieSceneFloatChannel ParameterCurve; // Offset: 0x08 // Size: 0xa0
};

// Object Name: ScriptStruct MovieSceneTracks.MovieScene3DAttachSectionTemplate
// Size: 0x48 // Inherited bytes: 0x18
struct FMovieScene3DAttachSectionTemplate : FMovieSceneEvalTemplate {
	// Fields
	struct FMovieSceneObjectBindingID AttachBindingID; // Offset: 0x14 // Size: 0x18
	struct FName AttachSocketName; // Offset: 0x2c // Size: 0x08
	struct FName AttachComponentName; // Offset: 0x34 // Size: 0x08
	enum class EAttachmentRule AttachmentLocationRule; // Offset: 0x3c // Size: 0x01
	enum class EAttachmentRule AttachmentRotationRule; // Offset: 0x3d // Size: 0x01
	enum class EAttachmentRule AttachmentScaleRule; // Offset: 0x3e // Size: 0x01
	enum class EDetachmentRule DetachmentLocationRule; // Offset: 0x3f // Size: 0x01
	enum class EDetachmentRule DetachmentRotationRule; // Offset: 0x40 // Size: 0x01
	enum class EDetachmentRule DetachmentScaleRule; // Offset: 0x41 // Size: 0x01
	char pad_0x46[0x2]; // Offset: 0x46 // Size: 0x02
};

// Object Name: ScriptStruct MovieSceneTracks.MovieScene3DPathSectionTemplate
// Size: 0xd8 // Inherited bytes: 0x18
struct FMovieScene3DPathSectionTemplate : FMovieSceneEvalTemplate {
	// Fields
	struct FMovieSceneObjectBindingID PathBindingID; // Offset: 0x14 // Size: 0x18
	struct FMovieSceneFloatChannel TimingCurve; // Offset: 0x30 // Size: 0xa0
	enum class MovieScene3DPathSection_Axis FrontAxisEnum; // Offset: 0xd0 // Size: 0x01
	enum class MovieScene3DPathSection_Axis UpAxisEnum; // Offset: 0xd1 // Size: 0x01
	char bFollow : 1; // Offset: 0xd2 // Size: 0x01
	char bReverse : 1; // Offset: 0xd2 // Size: 0x01
	char bForceUpright : 1; // Offset: 0xd2 // Size: 0x01
	char pad_0xD2_3 : 5; // Offset: 0xd2 // Size: 0x01
	char pad_0xD3[0x5]; // Offset: 0xd3 // Size: 0x05
};

// Object Name: ScriptStruct MovieSceneTracks.MovieSceneTransformMask
// Size: 0x04 // Inherited bytes: 0x00
struct FMovieSceneTransformMask {
	// Fields
	uint32_t Mask; // Offset: 0x00 // Size: 0x04
};

// Object Name: ScriptStruct MovieSceneTracks.MovieScene3DTransformKeyStruct
// Size: 0x48 // Inherited bytes: 0x08
struct FMovieScene3DTransformKeyStruct : FMovieSceneKeyStruct {
	// Fields
	struct FVector Location; // Offset: 0x08 // Size: 0x0c
	struct FRotator Rotation; // Offset: 0x14 // Size: 0x0c
	struct FVector Scale; // Offset: 0x20 // Size: 0x0c
	struct FFrameNumber Time; // Offset: 0x2c // Size: 0x04
	char pad_0x30[0x18]; // Offset: 0x30 // Size: 0x18
};

// Object Name: ScriptStruct MovieSceneTracks.MovieScene3DScaleKeyStruct
// Size: 0x30 // Inherited bytes: 0x08
struct FMovieScene3DScaleKeyStruct : FMovieSceneKeyStruct {
	// Fields
	struct FVector Scale; // Offset: 0x08 // Size: 0x0c
	struct FFrameNumber Time; // Offset: 0x14 // Size: 0x04
	char pad_0x18[0x18]; // Offset: 0x18 // Size: 0x18
};

// Object Name: ScriptStruct MovieSceneTracks.MovieScene3DRotationKeyStruct
// Size: 0x30 // Inherited bytes: 0x08
struct FMovieScene3DRotationKeyStruct : FMovieSceneKeyStruct {
	// Fields
	struct FRotator Rotation; // Offset: 0x08 // Size: 0x0c
	struct FFrameNumber Time; // Offset: 0x14 // Size: 0x04
	char pad_0x18[0x18]; // Offset: 0x18 // Size: 0x18
};

// Object Name: ScriptStruct MovieSceneTracks.MovieScene3DLocationKeyStruct
// Size: 0x30 // Inherited bytes: 0x08
struct FMovieScene3DLocationKeyStruct : FMovieSceneKeyStruct {
	// Fields
	struct FVector Location; // Offset: 0x08 // Size: 0x0c
	struct FFrameNumber Time; // Offset: 0x14 // Size: 0x04
	char pad_0x18[0x18]; // Offset: 0x18 // Size: 0x18
};

// Object Name: ScriptStruct MovieSceneTracks.MovieSceneComponentTransformSectionTemplate
// Size: 0x668 // Inherited bytes: 0x18
struct FMovieSceneComponentTransformSectionTemplate : FMovieSceneEvalTemplate {
	// Fields
	struct FMovieScene3DTransformTemplateData TemplateData; // Offset: 0x18 // Size: 0x650
};

// Object Name: ScriptStruct MovieSceneTracks.MovieScene3DTransformTemplateData
// Size: 0x650 // Inherited bytes: 0x00
struct FMovieScene3DTransformTemplateData {
	// Fields
	struct FMovieSceneFloatChannel TranslationCurve[0x3]; // Offset: 0x00 // Size: 0x1e0
	struct FMovieSceneFloatChannel RotationCurve[0x3]; // Offset: 0x1e0 // Size: 0x1e0
	struct FMovieSceneFloatChannel ScaleCurve[0x3]; // Offset: 0x3c0 // Size: 0x1e0
	struct FMovieSceneFloatChannel ManualWeight; // Offset: 0x5a0 // Size: 0xa0
	enum class EMovieSceneBlendType BlendType; // Offset: 0x640 // Size: 0x01
	char pad_0x641[0x3]; // Offset: 0x641 // Size: 0x03
	struct FMovieSceneTransformMask Mask; // Offset: 0x644 // Size: 0x04
	bool bUseQuaternionInterpolation; // Offset: 0x648 // Size: 0x01
	char pad_0x649[0x7]; // Offset: 0x649 // Size: 0x07
};

// Object Name: ScriptStruct MovieSceneTracks.MovieSceneActorReferenceData
// Size: 0xb0 // Inherited bytes: 0x08
struct FMovieSceneActorReferenceData : FMovieSceneChannel {
	// Fields
	struct TArray<struct FFrameNumber> KeyTimes; // Offset: 0x08 // Size: 0x10
	char pad_0x18[0x28]; // Offset: 0x18 // Size: 0x28
	struct TArray<struct FMovieSceneActorReferenceKey> KeyValues; // Offset: 0x40 // Size: 0x10
	char pad_0x50[0x60]; // Offset: 0x50 // Size: 0x60
};

// Object Name: ScriptStruct MovieSceneTracks.MovieSceneActorReferenceKey
// Size: 0x28 // Inherited bytes: 0x00
struct FMovieSceneActorReferenceKey {
	// Fields
	struct FMovieSceneObjectBindingID Object; // Offset: 0x00 // Size: 0x18
	struct FName ComponentName; // Offset: 0x18 // Size: 0x08
	struct FName SocketName; // Offset: 0x20 // Size: 0x08
};

// Object Name: ScriptStruct MovieSceneTracks.MovieSceneActorReferenceSectionTemplate
// Size: 0xf0 // Inherited bytes: 0x18
struct FMovieSceneActorReferenceSectionTemplate : FMovieSceneEvalTemplate {
	// Fields
	struct FMovieScenePropertySectionData PropertyData; // Offset: 0x18 // Size: 0x28
	struct FMovieSceneActorReferenceData ActorReferenceData; // Offset: 0x40 // Size: 0xb0
};

// Object Name: ScriptStruct MovieSceneTracks.MovieSceneAudioSectionTemplate
// Size: 0x20 // Inherited bytes: 0x18
struct FMovieSceneAudioSectionTemplate : FMovieSceneEvalTemplate {
	// Fields
	struct UMovieSceneAudioSection* AudioSection; // Offset: 0x18 // Size: 0x08
};

// Object Name: ScriptStruct MovieSceneTracks.MovieSceneCameraAnimSectionData
// Size: 0x20 // Inherited bytes: 0x00
struct FMovieSceneCameraAnimSectionData {
	// Fields
	struct UCameraAnim* CameraAnim; // Offset: 0x00 // Size: 0x08
	float PlayRate; // Offset: 0x08 // Size: 0x04
	float PlayScale; // Offset: 0x0c // Size: 0x04
	float BlendInTime; // Offset: 0x10 // Size: 0x04
	float BlendOutTime; // Offset: 0x14 // Size: 0x04
	bool bLooping; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x7]; // Offset: 0x19 // Size: 0x07
};

// Object Name: ScriptStruct MovieSceneTracks.MovieSceneAdditiveCameraAnimationTemplate
// Size: 0x18 // Inherited bytes: 0x18
struct FMovieSceneAdditiveCameraAnimationTemplate : FMovieSceneEvalTemplate {
};

// Object Name: ScriptStruct MovieSceneTracks.MovieSceneCameraShakeSectionTemplate
// Size: 0x40 // Inherited bytes: 0x18
struct FMovieSceneCameraShakeSectionTemplate : FMovieSceneAdditiveCameraAnimationTemplate {
	// Fields
	struct FMovieSceneCameraShakeSectionData SourceData; // Offset: 0x18 // Size: 0x20
	struct FFrameNumber SectionStartTime; // Offset: 0x38 // Size: 0x04
	char pad_0x3C[0x4]; // Offset: 0x3c // Size: 0x04
};

// Object Name: ScriptStruct MovieSceneTracks.MovieSceneCameraShakeSectionData
// Size: 0x20 // Inherited bytes: 0x00
struct FMovieSceneCameraShakeSectionData {
	// Fields
	struct UCameraShake* ShakeClass; // Offset: 0x00 // Size: 0x08
	float PlayScale; // Offset: 0x08 // Size: 0x04
	enum class ECameraAnimPlaySpace PlaySpace; // Offset: 0x0c // Size: 0x01
	char pad_0xD[0x3]; // Offset: 0x0d // Size: 0x03
	struct FRotator UserDefinedPlaySpace; // Offset: 0x10 // Size: 0x0c
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct MovieSceneTracks.MovieSceneCameraAnimSectionTemplate
// Size: 0x40 // Inherited bytes: 0x18
struct FMovieSceneCameraAnimSectionTemplate : FMovieSceneAdditiveCameraAnimationTemplate {
	// Fields
	struct FMovieSceneCameraAnimSectionData SourceData; // Offset: 0x18 // Size: 0x20
	struct FFrameNumber SectionStartTime; // Offset: 0x38 // Size: 0x04
	char pad_0x3C[0x4]; // Offset: 0x3c // Size: 0x04
};

// Object Name: ScriptStruct MovieSceneTracks.MovieSceneCameraCutSectionTemplate
// Size: 0x70 // Inherited bytes: 0x18
struct FMovieSceneCameraCutSectionTemplate : FMovieSceneEvalTemplate {
	// Fields
	struct FMovieSceneObjectBindingID CameraBindingID; // Offset: 0x14 // Size: 0x18
	struct FTransform CutTransform; // Offset: 0x30 // Size: 0x30
	bool bHasCutTransform; // Offset: 0x60 // Size: 0x01
	bool bIsFinalSection; // Offset: 0x61 // Size: 0x01
	char pad_0x62[0xe]; // Offset: 0x62 // Size: 0x0e
};

// Object Name: ScriptStruct MovieSceneTracks.MovieSceneColorKeyStruct
// Size: 0x38 // Inherited bytes: 0x08
struct FMovieSceneColorKeyStruct : FMovieSceneKeyStruct {
	// Fields
	struct FLinearColor Color; // Offset: 0x08 // Size: 0x10
	struct FFrameNumber Time; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x1c]; // Offset: 0x1c // Size: 0x1c
};

// Object Name: ScriptStruct MovieSceneTracks.MovieSceneColorSectionTemplate
// Size: 0x2c8 // Inherited bytes: 0x40
struct FMovieSceneColorSectionTemplate : FMovieScenePropertySectionTemplate {
	// Fields
	struct FMovieSceneFloatChannel Curves[0x4]; // Offset: 0x40 // Size: 0x280
	enum class EMovieSceneBlendType BlendType; // Offset: 0x2c0 // Size: 0x01
	char pad_0x2C1[0x7]; // Offset: 0x2c1 // Size: 0x07
};

// Object Name: ScriptStruct MovieSceneTracks.MovieSceneEvent
// Size: 0x28 // Inherited bytes: 0x00
struct FMovieSceneEvent {
	// Fields
	struct FMovieSceneEventPtrs Ptrs; // Offset: 0x00 // Size: 0x28
};

// Object Name: ScriptStruct MovieSceneTracks.MovieSceneEventPtrs
// Size: 0x28 // Inherited bytes: 0x00
struct FMovieSceneEventPtrs {
	// Fields
	struct UFunction* Function; // Offset: 0x00 // Size: 0x08
	struct TFieldPath<FProperty> BoundObjectProperty; // Offset: 0x08 // Size: 0x20
};

// Object Name: ScriptStruct MovieSceneTracks.MovieSceneEventPayloadVariable
// Size: 0x10 // Inherited bytes: 0x00
struct FMovieSceneEventPayloadVariable {
	// Fields
	struct FString Value; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct MovieSceneTracks.MovieSceneEventChannel
// Size: 0x88 // Inherited bytes: 0x08
struct FMovieSceneEventChannel : FMovieSceneChannel {
	// Fields
	struct TArray<struct FFrameNumber> KeyTimes; // Offset: 0x08 // Size: 0x10
	struct TArray<struct FMovieSceneEvent> KeyValues; // Offset: 0x18 // Size: 0x10
	char pad_0x28[0x60]; // Offset: 0x28 // Size: 0x60
};

// Object Name: ScriptStruct MovieSceneTracks.MovieSceneEventSectionData
// Size: 0x88 // Inherited bytes: 0x08
struct FMovieSceneEventSectionData : FMovieSceneChannel {
	// Fields
	struct TArray<struct FFrameNumber> Times; // Offset: 0x08 // Size: 0x10
	struct TArray<struct FEventPayload> KeyValues; // Offset: 0x18 // Size: 0x10
	char pad_0x28[0x60]; // Offset: 0x28 // Size: 0x60
};

// Object Name: ScriptStruct MovieSceneTracks.EventPayload
// Size: 0x30 // Inherited bytes: 0x00
struct FEventPayload {
	// Fields
	struct FName EventName; // Offset: 0x00 // Size: 0x08
	struct FMovieSceneEventParameters Parameters; // Offset: 0x08 // Size: 0x28
};

// Object Name: ScriptStruct MovieSceneTracks.MovieSceneEventParameters
// Size: 0x28 // Inherited bytes: 0x00
struct FMovieSceneEventParameters {
	// Fields
	char pad_0x0[0x28]; // Offset: 0x00 // Size: 0x28
};

// Object Name: ScriptStruct MovieSceneTracks.MovieSceneEventTemplateBase
// Size: 0x30 // Inherited bytes: 0x18
struct FMovieSceneEventTemplateBase : FMovieSceneEvalTemplate {
	// Fields
	struct TArray<struct FMovieSceneObjectBindingID> EventReceivers; // Offset: 0x18 // Size: 0x10
	char bFireEventsWhenForwards : 1; // Offset: 0x28 // Size: 0x01
	char bFireEventsWhenBackwards : 1; // Offset: 0x28 // Size: 0x01
	char pad_0x28_2 : 6; // Offset: 0x28 // Size: 0x01
	char pad_0x29[0x7]; // Offset: 0x29 // Size: 0x07
};

// Object Name: ScriptStruct MovieSceneTracks.MovieSceneEventRepeaterTemplate
// Size: 0x58 // Inherited bytes: 0x30
struct FMovieSceneEventRepeaterTemplate : FMovieSceneEventTemplateBase {
	// Fields
	struct FMovieSceneEventPtrs EventToTrigger; // Offset: 0x30 // Size: 0x28
};

// Object Name: ScriptStruct MovieSceneTracks.MovieSceneEventTriggerTemplate
// Size: 0x50 // Inherited bytes: 0x30
struct FMovieSceneEventTriggerTemplate : FMovieSceneEventTemplateBase {
	// Fields
	struct TArray<struct FFrameNumber> EventTimes; // Offset: 0x30 // Size: 0x10
	struct TArray<struct FMovieSceneEventPtrs> Events; // Offset: 0x40 // Size: 0x10
};

// Object Name: ScriptStruct MovieSceneTracks.MovieSceneEventSectionTemplate
// Size: 0xb8 // Inherited bytes: 0x30
struct FMovieSceneEventSectionTemplate : FMovieSceneEventTemplateBase {
	// Fields
	struct FMovieSceneEventSectionData EventData; // Offset: 0x30 // Size: 0x88
};

// Object Name: ScriptStruct MovieSceneTracks.MovieSceneFadeSectionTemplate
// Size: 0xd0 // Inherited bytes: 0x18
struct FMovieSceneFadeSectionTemplate : FMovieSceneEvalTemplate {
	// Fields
	struct FMovieSceneFloatChannel FadeCurve; // Offset: 0x18 // Size: 0xa0
	struct FLinearColor FadeColor; // Offset: 0xb8 // Size: 0x10
	char bFadeAudio : 1; // Offset: 0xc8 // Size: 0x01
	char pad_0xC8_1 : 7; // Offset: 0xc8 // Size: 0x01
	char pad_0xC9[0x7]; // Offset: 0xc9 // Size: 0x07
};

// Object Name: ScriptStruct MovieSceneTracks.MovieSceneLevelVisibilitySectionTemplate
// Size: 0x28 // Inherited bytes: 0x18
struct FMovieSceneLevelVisibilitySectionTemplate : FMovieSceneEvalTemplate {
	// Fields
	enum class ELevelVisibility Visibility; // Offset: 0x14 // Size: 0x01
	struct TArray<struct FName> LevelNames; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct MovieSceneTracks.MovieSceneMaterialParameterCollectionTemplate
// Size: 0x80 // Inherited bytes: 0x78
struct FMovieSceneMaterialParameterCollectionTemplate : FMovieSceneParameterSectionTemplate {
	// Fields
	struct UMaterialParameterCollection* MPC; // Offset: 0x78 // Size: 0x08
};

// Object Name: ScriptStruct MovieSceneTracks.MovieSceneObjectPropertyTemplate
// Size: 0x100 // Inherited bytes: 0x40
struct FMovieSceneObjectPropertyTemplate : FMovieScenePropertySectionTemplate {
	// Fields
	struct FMovieSceneObjectPathChannel ObjectChannel; // Offset: 0x40 // Size: 0xc0
};

// Object Name: ScriptStruct MovieSceneTracks.MovieSceneComponentMaterialSectionTemplate
// Size: 0x80 // Inherited bytes: 0x78
struct FMovieSceneComponentMaterialSectionTemplate : FMovieSceneParameterSectionTemplate {
	// Fields
	int32_t MaterialIndex; // Offset: 0x78 // Size: 0x04
	char pad_0x7C[0x4]; // Offset: 0x7c // Size: 0x04
};

// Object Name: ScriptStruct MovieSceneTracks.MovieSceneParticleParameterSectionTemplate
// Size: 0x78 // Inherited bytes: 0x78
struct FMovieSceneParticleParameterSectionTemplate : FMovieSceneParameterSectionTemplate {
};

// Object Name: ScriptStruct MovieSceneTracks.MovieSceneParticleChannel
// Size: 0x98 // Inherited bytes: 0x98
struct FMovieSceneParticleChannel : FMovieSceneByteChannel {
};

// Object Name: ScriptStruct MovieSceneTracks.MovieSceneParticleSectionTemplate
// Size: 0xb0 // Inherited bytes: 0x18
struct FMovieSceneParticleSectionTemplate : FMovieSceneEvalTemplate {
	// Fields
	struct FMovieSceneParticleChannel ParticleKeys; // Offset: 0x18 // Size: 0x98
};

// Object Name: ScriptStruct MovieSceneTracks.MovieScenePrimitiveMaterialTemplate
// Size: 0xd8 // Inherited bytes: 0x18
struct FMovieScenePrimitiveMaterialTemplate : FMovieSceneEvalTemplate {
	// Fields
	int32_t MaterialIndex; // Offset: 0x14 // Size: 0x04
	struct FMovieSceneObjectPathChannel MaterialChannel; // Offset: 0x18 // Size: 0xc0
};

// Object Name: ScriptStruct MovieSceneTracks.MovieSceneEulerTransformPropertySectionTemplate
// Size: 0x690 // Inherited bytes: 0x40
struct FMovieSceneEulerTransformPropertySectionTemplate : FMovieScenePropertySectionTemplate {
	// Fields
	struct FMovieScene3DTransformTemplateData TemplateData; // Offset: 0x40 // Size: 0x650
};

// Object Name: ScriptStruct MovieSceneTracks.MovieSceneTransformPropertySectionTemplate
// Size: 0x690 // Inherited bytes: 0x40
struct FMovieSceneTransformPropertySectionTemplate : FMovieScenePropertySectionTemplate {
	// Fields
	struct FMovieScene3DTransformTemplateData TemplateData; // Offset: 0x40 // Size: 0x650
};

// Object Name: ScriptStruct MovieSceneTracks.MovieSceneVectorPropertySectionTemplate
// Size: 0x2c8 // Inherited bytes: 0x40
struct FMovieSceneVectorPropertySectionTemplate : FMovieScenePropertySectionTemplate {
	// Fields
	struct FMovieSceneFloatChannel ComponentCurves[0x4]; // Offset: 0x40 // Size: 0x280
	int32_t NumChannelsUsed; // Offset: 0x2c0 // Size: 0x04
	enum class EMovieSceneBlendType BlendType; // Offset: 0x2c4 // Size: 0x01
	char pad_0x2C5[0x3]; // Offset: 0x2c5 // Size: 0x03
};

// Object Name: ScriptStruct MovieSceneTracks.MovieSceneStringPropertySectionTemplate
// Size: 0xe0 // Inherited bytes: 0x40
struct FMovieSceneStringPropertySectionTemplate : FMovieScenePropertySectionTemplate {
	// Fields
	struct FMovieSceneStringChannel StringCurve; // Offset: 0x40 // Size: 0xa0
};

// Object Name: ScriptStruct MovieSceneTracks.MovieSceneStringChannel
// Size: 0xa0 // Inherited bytes: 0x08
struct FMovieSceneStringChannel : FMovieSceneChannel {
	// Fields
	struct TArray<struct FFrameNumber> Times; // Offset: 0x08 // Size: 0x10
	struct TArray<struct FString> Values; // Offset: 0x18 // Size: 0x10
	struct FString DefaultValue; // Offset: 0x28 // Size: 0x10
	bool bHasDefaultValue; // Offset: 0x38 // Size: 0x01
	char pad_0x39[0x67]; // Offset: 0x39 // Size: 0x67
};

// Object Name: ScriptStruct MovieSceneTracks.MovieSceneIntegerPropertySectionTemplate
// Size: 0xd8 // Inherited bytes: 0x40
struct FMovieSceneIntegerPropertySectionTemplate : FMovieScenePropertySectionTemplate {
	// Fields
	struct FMovieSceneIntegerChannel IntegerCurve; // Offset: 0x40 // Size: 0x90
	enum class EMovieSceneBlendType BlendType; // Offset: 0xd0 // Size: 0x01
	char pad_0xD1[0x7]; // Offset: 0xd1 // Size: 0x07
};

// Object Name: ScriptStruct MovieSceneTracks.MovieSceneEnumPropertySectionTemplate
// Size: 0xd8 // Inherited bytes: 0x40
struct FMovieSceneEnumPropertySectionTemplate : FMovieScenePropertySectionTemplate {
	// Fields
	struct FMovieSceneByteChannel EnumCurve; // Offset: 0x40 // Size: 0x98
};

// Object Name: ScriptStruct MovieSceneTracks.MovieSceneBytePropertySectionTemplate
// Size: 0xd8 // Inherited bytes: 0x40
struct FMovieSceneBytePropertySectionTemplate : FMovieScenePropertySectionTemplate {
	// Fields
	struct FMovieSceneByteChannel ByteCurve; // Offset: 0x40 // Size: 0x98
};

// Object Name: ScriptStruct MovieSceneTracks.MovieSceneFloatPropertySectionTemplate
// Size: 0xe8 // Inherited bytes: 0x40
struct FMovieSceneFloatPropertySectionTemplate : FMovieScenePropertySectionTemplate {
	// Fields
	struct FMovieSceneFloatChannel FloatFunction; // Offset: 0x40 // Size: 0xa0
	enum class EMovieSceneBlendType BlendType; // Offset: 0xe0 // Size: 0x01
	char pad_0xE1[0x7]; // Offset: 0xe1 // Size: 0x07
};

// Object Name: ScriptStruct MovieSceneTracks.MovieSceneBoolPropertySectionTemplate
// Size: 0xd0 // Inherited bytes: 0x40
struct FMovieSceneBoolPropertySectionTemplate : FMovieScenePropertySectionTemplate {
	// Fields
	struct FMovieSceneBoolChannel BoolCurve; // Offset: 0x40 // Size: 0x90
};

// Object Name: ScriptStruct MovieSceneTracks.MovieSceneSkeletalAnimationParams
// Size: 0xd8 // Inherited bytes: 0x00
struct FMovieSceneSkeletalAnimationParams {
	// Fields
	struct UAnimSequenceBase* Animation; // Offset: 0x00 // Size: 0x08
	struct FFrameNumber FirstLoopStartFrameOffset; // Offset: 0x08 // Size: 0x04
	struct FFrameNumber StartFrameOffset; // Offset: 0x0c // Size: 0x04
	struct FFrameNumber EndFrameOffset; // Offset: 0x10 // Size: 0x04
	float PlayRate; // Offset: 0x14 // Size: 0x04
	char bReverse : 1; // Offset: 0x18 // Size: 0x01
	char pad_0x18_1 : 7; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x3]; // Offset: 0x19 // Size: 0x03
	struct FName SlotName; // Offset: 0x1c // Size: 0x08
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
	struct FMovieSceneFloatChannel Weight; // Offset: 0x28 // Size: 0xa0
	bool bSkipAnimNotifiers; // Offset: 0xc8 // Size: 0x01
	bool bForceCustomMode; // Offset: 0xc9 // Size: 0x01
	char pad_0xCA[0x2]; // Offset: 0xca // Size: 0x02
	float StartOffset; // Offset: 0xcc // Size: 0x04
	float EndOffset; // Offset: 0xd0 // Size: 0x04
	char pad_0xD4[0x4]; // Offset: 0xd4 // Size: 0x04
};

// Object Name: ScriptStruct MovieSceneTracks.MovieSceneSkeletalAnimationSectionTemplate
// Size: 0xf8 // Inherited bytes: 0x18
struct FMovieSceneSkeletalAnimationSectionTemplate : FMovieSceneEvalTemplate {
	// Fields
	struct FMovieSceneSkeletalAnimationSectionTemplateParameters Params; // Offset: 0x18 // Size: 0xe0
};

// Object Name: ScriptStruct MovieSceneTracks.MovieSceneSkeletalAnimationSectionTemplateParameters
// Size: 0xe0 // Inherited bytes: 0xd8
struct FMovieSceneSkeletalAnimationSectionTemplateParameters : FMovieSceneSkeletalAnimationParams {
	// Fields
	struct FFrameNumber SectionStartTime; // Offset: 0xd4 // Size: 0x04
	struct FFrameNumber SectionEndTime; // Offset: 0xd8 // Size: 0x04
};

// Object Name: ScriptStruct MovieSceneTracks.MovieSceneSlomoSectionTemplate
// Size: 0xb8 // Inherited bytes: 0x18
struct FMovieSceneSlomoSectionTemplate : FMovieSceneEvalTemplate {
	// Fields
	struct FMovieSceneFloatChannel SlomoCurve; // Offset: 0x18 // Size: 0xa0
};

// Object Name: ScriptStruct MovieSceneTracks.MovieSceneVectorKeyStructBase
// Size: 0x28 // Inherited bytes: 0x08
struct FMovieSceneVectorKeyStructBase : FMovieSceneKeyStruct {
	// Fields
	struct FFrameNumber Time; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x1c]; // Offset: 0x0c // Size: 0x1c
};

// Object Name: ScriptStruct MovieSceneTracks.MovieSceneVector4KeyStruct
// Size: 0x40 // Inherited bytes: 0x28
struct FMovieSceneVector4KeyStruct : FMovieSceneVectorKeyStructBase {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08
	struct FVector4 Vector; // Offset: 0x30 // Size: 0x10
};

// Object Name: ScriptStruct MovieSceneTracks.MovieSceneVectorKeyStruct
// Size: 0x38 // Inherited bytes: 0x28
struct FMovieSceneVectorKeyStruct : FMovieSceneVectorKeyStructBase {
	// Fields
	struct FVector Vector; // Offset: 0x28 // Size: 0x0c
	char pad_0x34[0x4]; // Offset: 0x34 // Size: 0x04
};

// Object Name: ScriptStruct MovieSceneTracks.MovieSceneVector2DKeyStruct
// Size: 0x30 // Inherited bytes: 0x28
struct FMovieSceneVector2DKeyStruct : FMovieSceneVectorKeyStructBase {
	// Fields
	struct FVector2D Vector; // Offset: 0x28 // Size: 0x08
};

// Object Name: ScriptStruct MovieSceneTracks.MovieSceneVisibilitySectionTemplate
// Size: 0xd0 // Inherited bytes: 0xd0
struct FMovieSceneVisibilitySectionTemplate : FMovieSceneBoolPropertySectionTemplate {
};

