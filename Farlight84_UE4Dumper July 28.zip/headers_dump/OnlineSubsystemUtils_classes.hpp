#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class OnlineSubsystemUtils.AchievementBlueprintLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct UAchievementBlueprintLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function OnlineSubsystemUtils.AchievementBlueprintLibrary.GetCachedAchievementProgress
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetCachedAchievementProgress(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct FName AchievementID, bool& bFoundID, float& Progress); // Offset: 0x101fb4590 // Return & Params: Num(5) Size(0x20)

	// Object Name: Function OnlineSubsystemUtils.AchievementBlueprintLibrary.GetCachedAchievementDescription
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetCachedAchievementDescription(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct FName AchievementID, bool& bFoundID, struct FText& Title, struct FText& LockedDescription, struct FText& UnlockedDescription, bool& bHidden); // Offset: 0x101fb41c8 // Return & Params: Num(8) Size(0x69)
};

// Object Name: Class OnlineSubsystemUtils.AchievementQueryCallbackProxy
// Size: 0x68 // Inherited bytes: 0x30
struct UAchievementQueryCallbackProxy : UOnlineBlueprintCallProxyBase {
	// Fields
	struct FMulticastInlineDelegate OnSuccess; // Offset: 0x30 // Size: 0x10
	struct FMulticastInlineDelegate OnFailure; // Offset: 0x40 // Size: 0x10
	char pad_0x50[0x18]; // Offset: 0x50 // Size: 0x18

	// Functions

	// Object Name: Function OnlineSubsystemUtils.AchievementQueryCallbackProxy.CacheAchievements
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UAchievementQueryCallbackProxy* CacheAchievements(struct UObject* WorldContextObject, struct APlayerController* PlayerController); // Offset: 0x101fb4aa8 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function OnlineSubsystemUtils.AchievementQueryCallbackProxy.CacheAchievementDescriptions
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UAchievementQueryCallbackProxy* CacheAchievementDescriptions(struct UObject* WorldContextObject, struct APlayerController* PlayerController); // Offset: 0x101fb49e0 // Return & Params: Num(3) Size(0x18)
};

// Object Name: Class OnlineSubsystemUtils.AchievementWriteCallbackProxy
// Size: 0x80 // Inherited bytes: 0x30
struct UAchievementWriteCallbackProxy : UOnlineBlueprintCallProxyBase {
	// Fields
	struct FMulticastInlineDelegate OnSuccess; // Offset: 0x30 // Size: 0x10
	struct FMulticastInlineDelegate OnFailure; // Offset: 0x40 // Size: 0x10
	char pad_0x50[0x30]; // Offset: 0x50 // Size: 0x30

	// Functions

	// Object Name: Function OnlineSubsystemUtils.AchievementWriteCallbackProxy.WriteAchievementProgress
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UAchievementWriteCallbackProxy* WriteAchievementProgress(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct FName AchievementName, float Progress, int32_t UserTag); // Offset: 0x101fb4fa4 // Return & Params: Num(6) Size(0x28)
};

// Object Name: Class OnlineSubsystemUtils.ConnectionCallbackProxy
// Size: 0x78 // Inherited bytes: 0x30
struct UConnectionCallbackProxy : UOnlineBlueprintCallProxyBase {
	// Fields
	struct FMulticastInlineDelegate OnSuccess; // Offset: 0x30 // Size: 0x10
	struct FMulticastInlineDelegate OnFailure; // Offset: 0x40 // Size: 0x10
	char pad_0x50[0x28]; // Offset: 0x50 // Size: 0x28

	// Functions

	// Object Name: Function OnlineSubsystemUtils.ConnectionCallbackProxy.ConnectToService
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UConnectionCallbackProxy* ConnectToService(struct UObject* WorldContextObject, struct APlayerController* PlayerController); // Offset: 0x101fb5534 // Return & Params: Num(3) Size(0x18)
};

// Object Name: Class OnlineSubsystemUtils.CreateSessionCallbackProxy
// Size: 0x98 // Inherited bytes: 0x30
struct UCreateSessionCallbackProxy : UOnlineBlueprintCallProxyBase {
	// Fields
	struct FMulticastInlineDelegate OnSuccess; // Offset: 0x30 // Size: 0x10
	struct FMulticastInlineDelegate OnFailure; // Offset: 0x40 // Size: 0x10
	char pad_0x50[0x48]; // Offset: 0x50 // Size: 0x48

	// Functions

	// Object Name: Function OnlineSubsystemUtils.CreateSessionCallbackProxy.CreateSession
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UCreateSessionCallbackProxy* CreateSession(struct UObject* WorldContextObject, struct APlayerController* PlayerController, int32_t PublicConnections, bool bUseLAN); // Offset: 0x101fb5994 // Return & Params: Num(5) Size(0x20)
};

// Object Name: Class OnlineSubsystemUtils.DestroySessionCallbackProxy
// Size: 0x78 // Inherited bytes: 0x30
struct UDestroySessionCallbackProxy : UOnlineBlueprintCallProxyBase {
	// Fields
	struct FMulticastInlineDelegate OnSuccess; // Offset: 0x30 // Size: 0x10
	struct FMulticastInlineDelegate OnFailure; // Offset: 0x40 // Size: 0x10
	char pad_0x50[0x28]; // Offset: 0x50 // Size: 0x28

	// Functions

	// Object Name: Function OnlineSubsystemUtils.DestroySessionCallbackProxy.DestroySession
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UDestroySessionCallbackProxy* DestroySession(struct UObject* WorldContextObject, struct APlayerController* PlayerController); // Offset: 0x101fb5e9c // Return & Params: Num(3) Size(0x18)
};

// Object Name: Class OnlineSubsystemUtils.EndMatchCallbackProxy
// Size: 0x80 // Inherited bytes: 0x30
struct UEndMatchCallbackProxy : UOnlineBlueprintCallProxyBase {
	// Fields
	struct FMulticastInlineDelegate OnSuccess; // Offset: 0x30 // Size: 0x10
	struct FMulticastInlineDelegate OnFailure; // Offset: 0x40 // Size: 0x10
	char pad_0x50[0x30]; // Offset: 0x50 // Size: 0x30

	// Functions

	// Object Name: Function OnlineSubsystemUtils.EndMatchCallbackProxy.EndMatch
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UEndMatchCallbackProxy* EndMatch(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct TScriptInterface<ITurnBasedMatchInterface> MatchActor, struct FString MatchID, enum class EMPMatchOutcome LocalPlayerOutcome, enum class EMPMatchOutcome OtherPlayersOutcome); // Offset: 0x101fb62fc // Return & Params: Num(7) Size(0x40)
};

// Object Name: Class OnlineSubsystemUtils.EndTurnCallbackProxy
// Size: 0x78 // Inherited bytes: 0x30
struct UEndTurnCallbackProxy : UOnlineBlueprintCallProxyBase {
	// Fields
	struct FMulticastInlineDelegate OnSuccess; // Offset: 0x30 // Size: 0x10
	struct FMulticastInlineDelegate OnFailure; // Offset: 0x40 // Size: 0x10
	char pad_0x50[0x28]; // Offset: 0x50 // Size: 0x28

	// Functions

	// Object Name: Function OnlineSubsystemUtils.EndTurnCallbackProxy.EndTurn
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UEndTurnCallbackProxy* EndTurn(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct FString MatchID, struct TScriptInterface<ITurnBasedMatchInterface> TurnBasedMatchInterface); // Offset: 0x101fb6908 // Return & Params: Num(5) Size(0x38)
};

// Object Name: Class OnlineSubsystemUtils.FindSessionsCallbackProxy
// Size: 0x90 // Inherited bytes: 0x30
struct UFindSessionsCallbackProxy : UOnlineBlueprintCallProxyBase {
	// Fields
	struct FMulticastInlineDelegate OnSuccess; // Offset: 0x30 // Size: 0x10
	struct FMulticastInlineDelegate OnFailure; // Offset: 0x40 // Size: 0x10
	char pad_0x50[0x40]; // Offset: 0x50 // Size: 0x40

	// Functions

	// Object Name: Function OnlineSubsystemUtils.FindSessionsCallbackProxy.GetServerName
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FString GetServerName(struct FBlueprintSessionResult& Result); // Offset: 0x101fb7354 // Return & Params: Num(2) Size(0x118)

	// Object Name: Function OnlineSubsystemUtils.FindSessionsCallbackProxy.GetPingInMs
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	int32_t GetPingInMs(struct FBlueprintSessionResult& Result); // Offset: 0x101fb7560 // Return & Params: Num(2) Size(0x10c)

	// Object Name: Function OnlineSubsystemUtils.FindSessionsCallbackProxy.GetMaxPlayers
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	int32_t GetMaxPlayers(struct FBlueprintSessionResult& Result); // Offset: 0x101fb6fa4 // Return & Params: Num(2) Size(0x10c)

	// Object Name: Function OnlineSubsystemUtils.FindSessionsCallbackProxy.GetCurrentPlayers
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	int32_t GetCurrentPlayers(struct FBlueprintSessionResult& Result); // Offset: 0x101fb717c // Return & Params: Num(2) Size(0x10c)

	// Object Name: Function OnlineSubsystemUtils.FindSessionsCallbackProxy.FindSessions
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UFindSessionsCallbackProxy* FindSessions(struct UObject* WorldContextObject, struct APlayerController* PlayerController, int32_t MaxResults, bool bUseLAN); // Offset: 0x101fb7738 // Return & Params: Num(5) Size(0x20)
};

// Object Name: Class OnlineSubsystemUtils.FindTurnBasedMatchCallbackProxy
// Size: 0x88 // Inherited bytes: 0x30
struct UFindTurnBasedMatchCallbackProxy : UOnlineBlueprintCallProxyBase {
	// Fields
	struct FMulticastInlineDelegate OnSuccess; // Offset: 0x30 // Size: 0x10
	struct FMulticastInlineDelegate OnFailure; // Offset: 0x40 // Size: 0x10
	char pad_0x50[0x38]; // Offset: 0x50 // Size: 0x38

	// Functions

	// Object Name: Function OnlineSubsystemUtils.FindTurnBasedMatchCallbackProxy.FindTurnBasedMatch
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UFindTurnBasedMatchCallbackProxy* FindTurnBasedMatch(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct TScriptInterface<ITurnBasedMatchInterface> MatchActor, int32_t MinPlayers, int32_t MaxPlayers, int32_t PlayerGroup, bool ShowExistingMatches); // Offset: 0x101fb7dbc // Return & Params: Num(8) Size(0x38)
};

// Object Name: Class OnlineSubsystemUtils.InAppPurchaseCallbackProxy
// Size: 0x80 // Inherited bytes: 0x28
struct UInAppPurchaseCallbackProxy : UObject {
	// Fields
	struct FMulticastInlineDelegate OnSuccess; // Offset: 0x28 // Size: 0x10
	struct FMulticastInlineDelegate OnFailure; // Offset: 0x38 // Size: 0x10
	char pad_0x48[0x38]; // Offset: 0x48 // Size: 0x38

	// Functions

	// Object Name: Function OnlineSubsystemUtils.InAppPurchaseCallbackProxy.CreateProxyObjectForInAppPurchase
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct UInAppPurchaseCallbackProxy* CreateProxyObjectForInAppPurchase(struct APlayerController* PlayerController, struct FInAppPurchaseProductRequest& ProductRequest); // Offset: 0x101fb84d8 // Return & Params: Num(3) Size(0x28)
};

// Object Name: Class OnlineSubsystemUtils.InAppPurchaseCallbackProxy2
// Size: 0xa8 // Inherited bytes: 0x28
struct UInAppPurchaseCallbackProxy2 : UObject {
	// Fields
	struct FMulticastInlineDelegate OnSuccess; // Offset: 0x28 // Size: 0x10
	struct FMulticastInlineDelegate OnFailure; // Offset: 0x38 // Size: 0x10
	char pad_0x48[0x60]; // Offset: 0x48 // Size: 0x60

	// Functions

	// Object Name: Function OnlineSubsystemUtils.InAppPurchaseCallbackProxy2.CreateProxyObjectForInAppPurchaseUnprocessedPurchases
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UInAppPurchaseCallbackProxy2* CreateProxyObjectForInAppPurchaseUnprocessedPurchases(struct APlayerController* PlayerController); // Offset: 0x101fb8d30 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function OnlineSubsystemUtils.InAppPurchaseCallbackProxy2.CreateProxyObjectForInAppPurchaseQueryOwned
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UInAppPurchaseCallbackProxy2* CreateProxyObjectForInAppPurchaseQueryOwned(struct APlayerController* PlayerController); // Offset: 0x101fb8cb0 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function OnlineSubsystemUtils.InAppPurchaseCallbackProxy2.CreateProxyObjectForInAppPurchase
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct UInAppPurchaseCallbackProxy2* CreateProxyObjectForInAppPurchase(struct APlayerController* PlayerController, struct FInAppPurchaseProductRequest2& ProductRequest); // Offset: 0x101fb8db0 // Return & Params: Num(3) Size(0x28)
};

// Object Name: Class OnlineSubsystemUtils.InAppPurchaseQueryCallbackProxy
// Size: 0x90 // Inherited bytes: 0x28
struct UInAppPurchaseQueryCallbackProxy : UObject {
	// Fields
	struct FMulticastInlineDelegate OnSuccess; // Offset: 0x28 // Size: 0x10
	struct FMulticastInlineDelegate OnFailure; // Offset: 0x38 // Size: 0x10
	char pad_0x48[0x48]; // Offset: 0x48 // Size: 0x48

	// Functions

	// Object Name: Function OnlineSubsystemUtils.InAppPurchaseQueryCallbackProxy.CreateProxyObjectForInAppPurchaseQuery
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct UInAppPurchaseQueryCallbackProxy* CreateProxyObjectForInAppPurchaseQuery(struct APlayerController* PlayerController, struct TArray<struct FString>& ProductIdentifiers); // Offset: 0x101fb92f0 // Return & Params: Num(3) Size(0x20)
};

// Object Name: Class OnlineSubsystemUtils.InAppPurchaseQueryCallbackProxy2
// Size: 0x68 // Inherited bytes: 0x28
struct UInAppPurchaseQueryCallbackProxy2 : UObject {
	// Fields
	struct FMulticastInlineDelegate OnSuccess; // Offset: 0x28 // Size: 0x10
	struct FMulticastInlineDelegate OnFailure; // Offset: 0x38 // Size: 0x10
	char pad_0x48[0x20]; // Offset: 0x48 // Size: 0x20

	// Functions

	// Object Name: Function OnlineSubsystemUtils.InAppPurchaseQueryCallbackProxy2.CreateProxyObjectForInAppPurchaseQuery
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct UInAppPurchaseQueryCallbackProxy2* CreateProxyObjectForInAppPurchaseQuery(struct APlayerController* PlayerController, struct TArray<struct FString>& ProductIdentifiers); // Offset: 0x101fb9940 // Return & Params: Num(3) Size(0x20)
};

// Object Name: Class OnlineSubsystemUtils.InAppPurchaseRestoreCallbackProxy
// Size: 0x90 // Inherited bytes: 0x28
struct UInAppPurchaseRestoreCallbackProxy : UObject {
	// Fields
	struct FMulticastInlineDelegate OnSuccess; // Offset: 0x28 // Size: 0x10
	struct FMulticastInlineDelegate OnFailure; // Offset: 0x38 // Size: 0x10
	char pad_0x48[0x48]; // Offset: 0x48 // Size: 0x48

	// Functions

	// Object Name: Function OnlineSubsystemUtils.InAppPurchaseRestoreCallbackProxy.CreateProxyObjectForInAppPurchaseRestore
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct UInAppPurchaseRestoreCallbackProxy* CreateProxyObjectForInAppPurchaseRestore(struct TArray<struct FInAppPurchaseProductRequest>& ConsumableProductFlags, struct APlayerController* PlayerController); // Offset: 0x101fb9e1c // Return & Params: Num(3) Size(0x20)
};

// Object Name: Class OnlineSubsystemUtils.InAppPurchaseRestoreCallbackProxy2
// Size: 0xa8 // Inherited bytes: 0x28
struct UInAppPurchaseRestoreCallbackProxy2 : UObject {
	// Fields
	struct FMulticastInlineDelegate OnSuccess; // Offset: 0x28 // Size: 0x10
	struct FMulticastInlineDelegate OnFailure; // Offset: 0x38 // Size: 0x10
	char pad_0x48[0x60]; // Offset: 0x48 // Size: 0x60

	// Functions

	// Object Name: Function OnlineSubsystemUtils.InAppPurchaseRestoreCallbackProxy2.CreateProxyObjectForInAppPurchaseRestore
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct UInAppPurchaseRestoreCallbackProxy2* CreateProxyObjectForInAppPurchaseRestore(struct TArray<struct FInAppPurchaseProductRequest2>& ConsumableProductFlags, struct APlayerController* PlayerController); // Offset: 0x101fba3d0 // Return & Params: Num(3) Size(0x20)
};

// Object Name: Class OnlineSubsystemUtils.IpConnection
// Size: 0x1bc0 // Inherited bytes: 0x1b08
struct UIpConnection : UNetConnection {
	// Fields
	char pad_0x1B08[0x68]; // Offset: 0x1b08 // Size: 0x68
	float SocketErrorDisconnectDelay; // Offset: 0x1b70 // Size: 0x04
	char pad_0x1B74[0x4c]; // Offset: 0x1b74 // Size: 0x4c
};

// Object Name: Class OnlineSubsystemUtils.IpNetDriver
// Size: 0x7c8 // Inherited bytes: 0x758
struct UIpNetDriver : UNetDriver {
	// Fields
	char LogPortUnreach : 1; // Offset: 0x755 // Size: 0x01
	char AllowPlayerPortUnreach : 1; // Offset: 0x755 // Size: 0x01
	uint32_t MaxPortCountToTry; // Offset: 0x758 // Size: 0x04
	char pad_0x75C_2 : 6; // Offset: 0x75c // Size: 0x01
	char pad_0x75D[0xf]; // Offset: 0x75d // Size: 0x0f
	uint32_t ServerDesiredSocketReceiveBufferBytes; // Offset: 0x76c // Size: 0x04
	uint32_t ServerDesiredSocketSendBufferBytes; // Offset: 0x770 // Size: 0x04
	uint32_t ClientDesiredSocketReceiveBufferBytes; // Offset: 0x774 // Size: 0x04
	uint32_t ClientDesiredSocketSendBufferBytes; // Offset: 0x778 // Size: 0x04
	char pad_0x77C[0x4]; // Offset: 0x77c // Size: 0x04
	double MaxSecondsInReceive; // Offset: 0x780 // Size: 0x08
	int32_t NbPacketsBetweenReceiveTimeTest; // Offset: 0x788 // Size: 0x04
	float ResolutionConnectionTimeout; // Offset: 0x78c // Size: 0x04
	char pad_0x790[0x38]; // Offset: 0x790 // Size: 0x38
};

// Object Name: Class OnlineSubsystemUtils.JoinSessionCallbackProxy
// Size: 0x180 // Inherited bytes: 0x30
struct UJoinSessionCallbackProxy : UOnlineBlueprintCallProxyBase {
	// Fields
	struct FMulticastInlineDelegate OnSuccess; // Offset: 0x30 // Size: 0x10
	struct FMulticastInlineDelegate OnFailure; // Offset: 0x40 // Size: 0x10
	char pad_0x50[0x130]; // Offset: 0x50 // Size: 0x130

	// Functions

	// Object Name: Function OnlineSubsystemUtils.JoinSessionCallbackProxy.JoinSession
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct UJoinSessionCallbackProxy* JoinSession(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct FBlueprintSessionResult& SearchResult); // Offset: 0x101fbdfe0 // Return & Params: Num(4) Size(0x120)
};

// Object Name: Class OnlineSubsystemUtils.LeaderboardBlueprintLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct ULeaderboardBlueprintLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function OnlineSubsystemUtils.LeaderboardBlueprintLibrary.WriteLeaderboardInteger
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool WriteLeaderboardInteger(struct APlayerController* PlayerController, struct FName StatName, int32_t StatValue); // Offset: 0x101fbe5d8 // Return & Params: Num(4) Size(0x15)
};

// Object Name: Class OnlineSubsystemUtils.LeaderboardFlushCallbackProxy
// Size: 0x68 // Inherited bytes: 0x28
struct ULeaderboardFlushCallbackProxy : UObject {
	// Fields
	struct FMulticastInlineDelegate OnSuccess; // Offset: 0x28 // Size: 0x10
	struct FMulticastInlineDelegate OnFailure; // Offset: 0x38 // Size: 0x10
	char pad_0x48[0x20]; // Offset: 0x48 // Size: 0x20

	// Functions

	// Object Name: Function OnlineSubsystemUtils.LeaderboardFlushCallbackProxy.CreateProxyObjectForFlush
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct ULeaderboardFlushCallbackProxy* CreateProxyObjectForFlush(struct APlayerController* PlayerController, struct FName SessionName); // Offset: 0x101fbe964 // Return & Params: Num(3) Size(0x18)
};

// Object Name: Class OnlineSubsystemUtils.LeaderboardQueryCallbackProxy
// Size: 0x98 // Inherited bytes: 0x28
struct ULeaderboardQueryCallbackProxy : UObject {
	// Fields
	struct FMulticastInlineDelegate OnSuccess; // Offset: 0x28 // Size: 0x10
	struct FMulticastInlineDelegate OnFailure; // Offset: 0x38 // Size: 0x10
	char pad_0x48[0x50]; // Offset: 0x48 // Size: 0x50

	// Functions

	// Object Name: Function OnlineSubsystemUtils.LeaderboardQueryCallbackProxy.CreateProxyObjectForIntQuery
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct ULeaderboardQueryCallbackProxy* CreateProxyObjectForIntQuery(struct APlayerController* PlayerController, struct FName StatName); // Offset: 0x101fbedf0 // Return & Params: Num(3) Size(0x18)
};

// Object Name: Class OnlineSubsystemUtils.LogoutCallbackProxy
// Size: 0x68 // Inherited bytes: 0x30
struct ULogoutCallbackProxy : UBlueprintAsyncActionBase {
	// Fields
	struct FMulticastInlineDelegate OnSuccess; // Offset: 0x30 // Size: 0x10
	struct FMulticastInlineDelegate OnFailure; // Offset: 0x40 // Size: 0x10
	char pad_0x50[0x18]; // Offset: 0x50 // Size: 0x18

	// Functions

	// Object Name: Function OnlineSubsystemUtils.LogoutCallbackProxy.Logout
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct ULogoutCallbackProxy* Logout(struct UObject* WorldContextObject, struct APlayerController* PlayerController); // Offset: 0x101fbf27c // Return & Params: Num(3) Size(0x18)
};

// Object Name: Class OnlineSubsystemUtils.OnlineBeacon
// Size: 0x258 // Inherited bytes: 0x228
struct AOnlineBeacon : AActor {
	// Fields
	char pad_0x228[0x8]; // Offset: 0x228 // Size: 0x08
	float BeaconConnectionInitialTimeout; // Offset: 0x230 // Size: 0x04
	float BeaconConnectionTimeout; // Offset: 0x234 // Size: 0x04
	struct UNetDriver* NetDriver; // Offset: 0x238 // Size: 0x08
	char pad_0x240[0x18]; // Offset: 0x240 // Size: 0x18
};

// Object Name: Class OnlineSubsystemUtils.OnlineBeaconClient
// Size: 0x2b8 // Inherited bytes: 0x258
struct AOnlineBeaconClient : AOnlineBeacon {
	// Fields
	struct AOnlineBeaconHostObject* BeaconOwner; // Offset: 0x258 // Size: 0x08
	struct UNetConnection* BeaconConnection; // Offset: 0x260 // Size: 0x08
	enum class EBeaconConnectionState ConnectionState; // Offset: 0x268 // Size: 0x01
	char pad_0x269[0x4f]; // Offset: 0x269 // Size: 0x4f

	// Functions

	// Object Name: Function OnlineSubsystemUtils.OnlineBeaconClient.ClientOnConnected
	// Flags: [Final|Net|NetReliableNative|Event|Private|NetClient]
	void ClientOnConnected(); // Offset: 0x101fbf8bc // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class OnlineSubsystemUtils.OnlineBeaconHost
// Size: 0x310 // Inherited bytes: 0x258
struct AOnlineBeaconHost : AOnlineBeacon {
	// Fields
	int32_t ListenPort; // Offset: 0x258 // Size: 0x04
	char pad_0x25C[0x4]; // Offset: 0x25c // Size: 0x04
	struct TArray<struct AOnlineBeaconClient*> ClientActors; // Offset: 0x260 // Size: 0x10
	char pad_0x270[0xa0]; // Offset: 0x270 // Size: 0xa0
};

// Object Name: Class OnlineSubsystemUtils.OnlineBeaconHostObject
// Size: 0x250 // Inherited bytes: 0x228
struct AOnlineBeaconHostObject : AActor {
	// Fields
	struct FString BeaconTypeName; // Offset: 0x228 // Size: 0x10
	struct AOnlineBeaconClient* ClientBeaconActorClass; // Offset: 0x238 // Size: 0x08
	struct TArray<struct AOnlineBeaconClient*> ClientActors; // Offset: 0x240 // Size: 0x10
};

// Object Name: Class OnlineSubsystemUtils.OnlineEngineInterfaceImpl
// Size: 0x128 // Inherited bytes: 0x28
struct UOnlineEngineInterfaceImpl : UOnlineEngineInterface {
	// Fields
	struct FName VoiceSubsystemNameOverride; // Offset: 0x28 // Size: 0x08
	char pad_0x30[0xf8]; // Offset: 0x30 // Size: 0xf8
};

// Object Name: Class OnlineSubsystemUtils.OnlinePIESettings
// Size: 0x50 // Inherited bytes: 0x38
struct UOnlinePIESettings : UDeveloperSettings {
	// Fields
	bool bOnlinePIEEnabled; // Offset: 0x38 // Size: 0x01
	char pad_0x39[0x7]; // Offset: 0x39 // Size: 0x07
	struct TArray<struct FPIELoginSettingsInternal> Logins; // Offset: 0x40 // Size: 0x10
};

// Object Name: Class OnlineSubsystemUtils.OnlineSessionClient
// Size: 0x1e0 // Inherited bytes: 0x28
struct UOnlineSessionClient : UOnlineSession {
	// Fields
	char pad_0x28[0x1b0]; // Offset: 0x28 // Size: 0x1b0
	bool bIsFromInvite; // Offset: 0x1d8 // Size: 0x01
	bool bHandlingDisconnect; // Offset: 0x1d9 // Size: 0x01
	char pad_0x1DA[0x6]; // Offset: 0x1da // Size: 0x06
};

// Object Name: Class OnlineSubsystemUtils.PartyBeaconClient
// Size: 0x378 // Inherited bytes: 0x2b8
struct APartyBeaconClient : AOnlineBeaconClient {
	// Fields
	char pad_0x2B8[0x30]; // Offset: 0x2b8 // Size: 0x30
	struct FString DestSessionId; // Offset: 0x2e8 // Size: 0x10
	struct FPartyReservation PendingReservation; // Offset: 0x2f8 // Size: 0x50
	enum class EClientRequestType RequestType; // Offset: 0x348 // Size: 0x01
	bool bPendingReservationSent; // Offset: 0x349 // Size: 0x01
	bool bCancelReservation; // Offset: 0x34a // Size: 0x01
	char pad_0x34B[0x2d]; // Offset: 0x34b // Size: 0x2d

	// Functions

	// Object Name: Function OnlineSubsystemUtils.PartyBeaconClient.ServerUpdateReservationRequest
	// Flags: [Net|NetReliableNative|Event|Protected|NetServer|NetValidate]
	void ServerUpdateReservationRequest(struct FString SessionId, struct FPartyReservation ReservationUpdate); // Offset: 0x101fc0ad4 // Return & Params: Num(2) Size(0x60)

	// Object Name: Function OnlineSubsystemUtils.PartyBeaconClient.ServerReservationRequest
	// Flags: [Net|NetReliableNative|Event|Protected|NetServer|NetValidate]
	void ServerReservationRequest(struct FString SessionId, struct FPartyReservation Reservation); // Offset: 0x101fc0c84 // Return & Params: Num(2) Size(0x60)

	// Object Name: Function OnlineSubsystemUtils.PartyBeaconClient.ServerRemoveMemberFromReservationRequest
	// Flags: [Net|NetReliableNative|Event|Protected|NetServer|NetValidate]
	void ServerRemoveMemberFromReservationRequest(struct FString SessionId, struct FPartyReservation ReservationUpdate); // Offset: 0x101fc0924 // Return & Params: Num(2) Size(0x60)

	// Object Name: Function OnlineSubsystemUtils.PartyBeaconClient.ServerCancelReservationRequest
	// Flags: [Net|NetReliableNative|Event|Protected|NetServer|NetValidate]
	void ServerCancelReservationRequest(struct FUniqueNetIdRepl PartyLeader); // Offset: 0x101fc07dc // Return & Params: Num(1) Size(0x28)

	// Object Name: Function OnlineSubsystemUtils.PartyBeaconClient.ClientSendReservationUpdates
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	void ClientSendReservationUpdates(int32_t NumRemainingReservations); // Offset: 0x101fc0e50 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function OnlineSubsystemUtils.PartyBeaconClient.ClientSendReservationFull
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	void ClientSendReservationFull(); // Offset: 0x101fc0e34 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function OnlineSubsystemUtils.PartyBeaconClient.ClientReservationResponse
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	void ClientReservationResponse(enum class EPartyReservationResult ReservationResponse); // Offset: 0x101fc0f60 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function OnlineSubsystemUtils.PartyBeaconClient.ClientCancelReservationResponse
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	void ClientCancelReservationResponse(enum class EPartyReservationResult ReservationResponse); // Offset: 0x101fc0ed8 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class OnlineSubsystemUtils.PartyBeaconHost
// Size: 0x2c8 // Inherited bytes: 0x250
struct APartyBeaconHost : AOnlineBeaconHostObject {
	// Fields
	struct UPartyBeaconState* State; // Offset: 0x250 // Size: 0x08
	char pad_0x258[0x60]; // Offset: 0x258 // Size: 0x60
	bool bLogoutOnSessionTimeout; // Offset: 0x2b8 // Size: 0x01
	char pad_0x2B9[0x3]; // Offset: 0x2b9 // Size: 0x03
	float SessionTimeoutSecs; // Offset: 0x2bc // Size: 0x04
	float TravelSessionTimeoutSecs; // Offset: 0x2c0 // Size: 0x04
	char pad_0x2C4[0x4]; // Offset: 0x2c4 // Size: 0x04
};

// Object Name: Class OnlineSubsystemUtils.PartyBeaconState
// Size: 0x78 // Inherited bytes: 0x28
struct UPartyBeaconState : UObject {
	// Fields
	struct FName SessionName; // Offset: 0x28 // Size: 0x08
	int32_t NumConsumedReservations; // Offset: 0x30 // Size: 0x04
	int32_t MaxReservations; // Offset: 0x34 // Size: 0x04
	int32_t NumTeams; // Offset: 0x38 // Size: 0x04
	int32_t NumPlayersPerTeam; // Offset: 0x3c // Size: 0x04
	struct FName TeamAssignmentMethod; // Offset: 0x40 // Size: 0x08
	int32_t ReservedHostTeamNum; // Offset: 0x48 // Size: 0x04
	int32_t ForceTeamNum; // Offset: 0x4c // Size: 0x04
	bool bRestrictCrossConsole; // Offset: 0x50 // Size: 0x01
	bool bEnableRemovalRequests; // Offset: 0x51 // Size: 0x01
	char pad_0x52[0x6]; // Offset: 0x52 // Size: 0x06
	struct TArray<struct FPartyReservation> Reservations; // Offset: 0x58 // Size: 0x10
	char pad_0x68[0x10]; // Offset: 0x68 // Size: 0x10
};

// Object Name: Class OnlineSubsystemUtils.QuitMatchCallbackProxy
// Size: 0x78 // Inherited bytes: 0x30
struct UQuitMatchCallbackProxy : UOnlineBlueprintCallProxyBase {
	// Fields
	struct FMulticastInlineDelegate OnSuccess; // Offset: 0x30 // Size: 0x10
	struct FMulticastInlineDelegate OnFailure; // Offset: 0x40 // Size: 0x10
	char pad_0x50[0x28]; // Offset: 0x50 // Size: 0x28

	// Functions

	// Object Name: Function OnlineSubsystemUtils.QuitMatchCallbackProxy.QuitMatch
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UQuitMatchCallbackProxy* QuitMatch(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct FString MatchID, enum class EMPMatchOutcome Outcome, int32_t TurnTimeoutInSeconds); // Offset: 0x101fc24f0 // Return & Params: Num(6) Size(0x30)
};

// Object Name: Class OnlineSubsystemUtils.ShowLoginUICallbackProxy
// Size: 0x60 // Inherited bytes: 0x30
struct UShowLoginUICallbackProxy : UBlueprintAsyncActionBase {
	// Fields
	struct FMulticastInlineDelegate OnSuccess; // Offset: 0x30 // Size: 0x10
	struct FMulticastInlineDelegate OnFailure; // Offset: 0x40 // Size: 0x10
	char pad_0x50[0x10]; // Offset: 0x50 // Size: 0x10

	// Functions

	// Object Name: Function OnlineSubsystemUtils.ShowLoginUICallbackProxy.ShowExternalLoginUI
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UShowLoginUICallbackProxy* ShowExternalLoginUI(struct UObject* WorldContextObject, struct APlayerController* InPlayerController); // Offset: 0x101fc2aa0 // Return & Params: Num(3) Size(0x18)
};

// Object Name: Class OnlineSubsystemUtils.SpectatorBeaconClient
// Size: 0x3a0 // Inherited bytes: 0x2b8
struct ASpectatorBeaconClient : AOnlineBeaconClient {
	// Fields
	char pad_0x2B8[0x30]; // Offset: 0x2b8 // Size: 0x30
	struct FString DestSessionId; // Offset: 0x2e8 // Size: 0x10
	struct FSpectatorReservation PendingReservation; // Offset: 0x2f8 // Size: 0x78
	enum class ESpectatorClientRequestType RequestType; // Offset: 0x370 // Size: 0x01
	bool bPendingReservationSent; // Offset: 0x371 // Size: 0x01
	bool bCancelReservation; // Offset: 0x372 // Size: 0x01
	char pad_0x373[0x2d]; // Offset: 0x373 // Size: 0x2d

	// Functions

	// Object Name: Function OnlineSubsystemUtils.SpectatorBeaconClient.ServerReservationRequest
	// Flags: [Net|NetReliableNative|Event|Protected|NetServer|NetValidate]
	void ServerReservationRequest(struct FString SessionId, struct FSpectatorReservation Reservation); // Offset: 0x101fc3104 // Return & Params: Num(2) Size(0x88)

	// Object Name: Function OnlineSubsystemUtils.SpectatorBeaconClient.ServerCancelReservationRequest
	// Flags: [Net|NetReliableNative|Event|Protected|NetServer|NetValidate]
	void ServerCancelReservationRequest(struct FUniqueNetIdRepl Spectator); // Offset: 0x101fc2fbc // Return & Params: Num(1) Size(0x28)

	// Object Name: Function OnlineSubsystemUtils.SpectatorBeaconClient.ClientSendReservationUpdates
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	void ClientSendReservationUpdates(int32_t NumRemainingReservations); // Offset: 0x101fc3354 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function OnlineSubsystemUtils.SpectatorBeaconClient.ClientSendReservationFull
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	void ClientSendReservationFull(); // Offset: 0x101fc3338 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function OnlineSubsystemUtils.SpectatorBeaconClient.ClientReservationResponse
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	void ClientReservationResponse(enum class ESpectatorReservationResult ReservationResponse); // Offset: 0x101fc3464 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function OnlineSubsystemUtils.SpectatorBeaconClient.ClientCancelReservationResponse
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	void ClientCancelReservationResponse(enum class ESpectatorReservationResult ReservationResponse); // Offset: 0x101fc33dc // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class OnlineSubsystemUtils.SpectatorBeaconHost
// Size: 0x2c8 // Inherited bytes: 0x250
struct ASpectatorBeaconHost : AOnlineBeaconHostObject {
	// Fields
	struct USpectatorBeaconState* State; // Offset: 0x250 // Size: 0x08
	char pad_0x258[0x60]; // Offset: 0x258 // Size: 0x60
	bool bLogoutOnSessionTimeout; // Offset: 0x2b8 // Size: 0x01
	char pad_0x2B9[0x3]; // Offset: 0x2b9 // Size: 0x03
	float SessionTimeoutSecs; // Offset: 0x2bc // Size: 0x04
	float TravelSessionTimeoutSecs; // Offset: 0x2c0 // Size: 0x04
	char pad_0x2C4[0x4]; // Offset: 0x2c4 // Size: 0x04
};

// Object Name: Class OnlineSubsystemUtils.SpectatorBeaconState
// Size: 0x60 // Inherited bytes: 0x28
struct USpectatorBeaconState : UObject {
	// Fields
	struct FName SessionName; // Offset: 0x28 // Size: 0x08
	int32_t NumConsumedReservations; // Offset: 0x30 // Size: 0x04
	int32_t MaxReservations; // Offset: 0x34 // Size: 0x04
	bool bRestrictCrossConsole; // Offset: 0x38 // Size: 0x01
	char pad_0x39[0x7]; // Offset: 0x39 // Size: 0x07
	struct TArray<struct FSpectatorReservation> Reservations; // Offset: 0x40 // Size: 0x10
	char pad_0x50[0x10]; // Offset: 0x50 // Size: 0x10
};

// Object Name: Class OnlineSubsystemUtils.TestBeaconClient
// Size: 0x2b8 // Inherited bytes: 0x2b8
struct ATestBeaconClient : AOnlineBeaconClient {
	// Functions

	// Object Name: Function OnlineSubsystemUtils.TestBeaconClient.ServerPong
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	void ServerPong(); // Offset: 0x101fc4524 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function OnlineSubsystemUtils.TestBeaconClient.ClientPing
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	void ClientPing(); // Offset: 0x101fc4580 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class OnlineSubsystemUtils.TestBeaconHost
// Size: 0x250 // Inherited bytes: 0x250
struct ATestBeaconHost : AOnlineBeaconHostObject {
};

// Object Name: Class OnlineSubsystemUtils.TurnBasedBlueprintLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct UTurnBasedBlueprintLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function OnlineSubsystemUtils.TurnBasedBlueprintLibrary.RegisterTurnBasedMatchInterfaceObject
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void RegisterTurnBasedMatchInterfaceObject(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct UObject* Object); // Offset: 0x101fc7a7c // Return & Params: Num(3) Size(0x18)

	// Object Name: Function OnlineSubsystemUtils.TurnBasedBlueprintLibrary.GetPlayerDisplayName
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetPlayerDisplayName(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct FString MatchID, int32_t PlayerIndex, struct FString& PlayerDisplayName); // Offset: 0x101fc784c // Return & Params: Num(5) Size(0x38)

	// Object Name: Function OnlineSubsystemUtils.TurnBasedBlueprintLibrary.GetMyPlayerIndex
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetMyPlayerIndex(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct FString MatchID, int32_t& PlayerIndex); // Offset: 0x101fc7b88 // Return & Params: Num(4) Size(0x24)

	// Object Name: Function OnlineSubsystemUtils.TurnBasedBlueprintLibrary.GetIsMyTurn
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetIsMyTurn(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct FString MatchID, bool& bIsMyTurn); // Offset: 0x101fc7d5c // Return & Params: Num(4) Size(0x21)
};

// Object Name: Class OnlineSubsystemUtils.VoipListenerSynthComponent
// Size: 0x890 // Inherited bytes: 0x820
struct UVoipListenerSynthComponent : USynthComponent {
	// Fields
	char pad_0x820[0x70]; // Offset: 0x820 // Size: 0x70

	// Functions

	// Object Name: Function OnlineSubsystemUtils.VoipListenerSynthComponent.IsIdling
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool IsIdling(); // Offset: 0x101fc8240 // Return & Params: Num(1) Size(0x1)
};

