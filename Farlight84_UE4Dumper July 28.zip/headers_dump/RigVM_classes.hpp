#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class RigVM.RigVM
// Size: 0x240 // Inherited bytes: 0x28
struct URigVM : UObject {
	// Fields
	struct FRigVMMemoryContainer WorkMemory; // Offset: 0x28 // Size: 0xa0
	struct FRigVMMemoryContainer LiteralMemory; // Offset: 0xc8 // Size: 0xa0
	struct FRigVMByteCode ByteCode; // Offset: 0x168 // Size: 0x10
	struct FRigVMInstructionArray Instructions; // Offset: 0x178 // Size: 0x10
	struct TArray<struct FName> FunctionNames; // Offset: 0x188 // Size: 0x10
	char pad_0x198[0x10]; // Offset: 0x198 // Size: 0x10
	struct TArray<struct FRigVMParameter> Parameters; // Offset: 0x1a8 // Size: 0x10
	struct TMap<struct FName, int32_t> ParametersNameMap; // Offset: 0x1b8 // Size: 0x50
	char pad_0x208[0x38]; // Offset: 0x208 // Size: 0x38

	// Functions

	// Object Name: Function RigVM.RigVM.SetParameterValueVector2D
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void SetParameterValueVector2D(struct FName& InParameterName, struct FVector2D& InValue, int32_t InArrayIndex); // Offset: 0x10517d244 // Return & Params: Num(3) Size(0x14)

	// Object Name: Function RigVM.RigVM.SetParameterValueVector
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void SetParameterValueVector(struct FName& InParameterName, struct FVector& InValue, int32_t InArrayIndex); // Offset: 0x10517d054 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function RigVM.RigVM.SetParameterValueTransform
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void SetParameterValueTransform(struct FName& InParameterName, struct FTransform& InValue, int32_t InArrayIndex); // Offset: 0x10517cc2c // Return & Params: Num(3) Size(0x44)

	// Object Name: Function RigVM.RigVM.SetParameterValueString
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetParameterValueString(struct FName& InParameterName, struct FString InValue, int32_t InArrayIndex); // Offset: 0x10517d40c // Return & Params: Num(3) Size(0x1c)

	// Object Name: Function RigVM.RigVM.SetParameterValueQuat
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void SetParameterValueQuat(struct FName& InParameterName, struct FQuat& InValue, int32_t InArrayIndex); // Offset: 0x10517ce74 // Return & Params: Num(3) Size(0x24)

	// Object Name: Function RigVM.RigVM.SetParameterValueName
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetParameterValueName(struct FName& InParameterName, struct FName& InValue, int32_t InArrayIndex); // Offset: 0x10517d53c // Return & Params: Num(3) Size(0x14)

	// Object Name: Function RigVM.RigVM.SetParameterValueInt
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetParameterValueInt(struct FName& InParameterName, int32_t InValue, int32_t InArrayIndex); // Offset: 0x10517d708 // Return & Params: Num(3) Size(0x10)

	// Object Name: Function RigVM.RigVM.SetParameterValueFloat
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetParameterValueFloat(struct FName& InParameterName, float InValue, int32_t InArrayIndex); // Offset: 0x10517d8d0 // Return & Params: Num(3) Size(0x10)

	// Object Name: Function RigVM.RigVM.SetParameterValueBool
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetParameterValueBool(struct FName& InParameterName, bool InValue, int32_t InArrayIndex); // Offset: 0x10517da98 // Return & Params: Num(3) Size(0x10)

	// Object Name: Function RigVM.RigVM.GetRigVMFunctionName
	// Flags: [Final|Native|Public|Const]
	struct FString GetRigVMFunctionName(int32_t InFunctionIndex); // Offset: 0x10517ec04 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function RigVM.RigVM.GetParameterValueVector2D
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct FVector2D GetParameterValueVector2D(struct FName& InParameterName, int32_t InArrayIndex); // Offset: 0x10517e1c8 // Return & Params: Num(3) Size(0x14)

	// Object Name: Function RigVM.RigVM.GetParameterValueVector
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct FVector GetParameterValueVector(struct FName& InParameterName, int32_t InArrayIndex); // Offset: 0x10517e01c // Return & Params: Num(3) Size(0x18)

	// Object Name: Function RigVM.RigVM.GetParameterValueTransform
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct FTransform GetParameterValueTransform(struct FName& InParameterName, int32_t InArrayIndex); // Offset: 0x10517dc6c // Return & Params: Num(3) Size(0x40)

	// Object Name: Function RigVM.RigVM.GetParameterValueString
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	struct FString GetParameterValueString(struct FName& InParameterName, int32_t InArrayIndex); // Offset: 0x10517e360 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function RigVM.RigVM.GetParameterValueQuat
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct FQuat GetParameterValueQuat(struct FName& InParameterName, int32_t InArrayIndex); // Offset: 0x10517de84 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function RigVM.RigVM.GetParameterValueName
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	struct FName GetParameterValueName(struct FName& InParameterName, int32_t InArrayIndex); // Offset: 0x10517e49c // Return & Params: Num(3) Size(0x14)

	// Object Name: Function RigVM.RigVM.GetParameterValueInt
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	int32_t GetParameterValueInt(struct FName& InParameterName, int32_t InArrayIndex); // Offset: 0x10517e628 // Return & Params: Num(3) Size(0x10)

	// Object Name: Function RigVM.RigVM.GetParameterValueFloat
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	float GetParameterValueFloat(struct FName& InParameterName, int32_t InArrayIndex); // Offset: 0x10517e7b4 // Return & Params: Num(3) Size(0x10)

	// Object Name: Function RigVM.RigVM.GetParameterValueBool
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	bool GetParameterValueBool(struct FName& InParameterName, int32_t InArrayIndex); // Offset: 0x10517e940 // Return & Params: Num(3) Size(0xd)

	// Object Name: Function RigVM.RigVM.GetParameterArraySize
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	int32_t GetParameterArraySize(struct FName& InParameterName); // Offset: 0x10517ead4 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function RigVM.RigVM.Execute
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool Execute(); // Offset: 0x10517edc4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function RigVM.RigVM.AddRigVMFunction
	// Flags: [Final|Native|Public|HasOutParms]
	int32_t AddRigVMFunction(struct UScriptStruct* InRigVMStruct, struct FName& InMethodName); // Offset: 0x10517ecdc // Return & Params: Num(3) Size(0x14)
};

