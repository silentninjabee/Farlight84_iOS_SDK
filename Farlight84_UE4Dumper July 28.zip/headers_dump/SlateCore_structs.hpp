#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct SlateCore.Geometry
// Size: 0x38 // Inherited bytes: 0x00
struct FGeometry {
	// Fields
	char pad_0x0[0x38]; // Offset: 0x00 // Size: 0x38
};

// Object Name: ScriptStruct SlateCore.SlateBrush
// Size: 0x98 // Inherited bytes: 0x00
struct FSlateBrush {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
	struct FVector2D ImageSize; // Offset: 0x08 // Size: 0x08
	bool bLockRatio; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x3]; // Offset: 0x11 // Size: 0x03
	struct FVector2D LockedSize; // Offset: 0x14 // Size: 0x08
	struct FMargin Margin; // Offset: 0x1c // Size: 0x10
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
	struct FSlateColor TintColor; // Offset: 0x30 // Size: 0x28
	struct UObject* ResourceObject; // Offset: 0x58 // Size: 0x08
	struct FName ResourceName; // Offset: 0x60 // Size: 0x08
	struct FBox2D UVRegion; // Offset: 0x68 // Size: 0x14
	enum class ESlateBrushDrawType DrawAs; // Offset: 0x7c // Size: 0x01
	enum class ESlateBrushTileType Tiling; // Offset: 0x7d // Size: 0x01
	enum class ESlateBrushMirrorType Mirroring; // Offset: 0x7e // Size: 0x01
	enum class ESlateBrushImageType ImageType; // Offset: 0x7f // Size: 0x01
	char pad_0x80[0x10]; // Offset: 0x80 // Size: 0x10
	char bIsDynamicallyLoaded : 1; // Offset: 0x90 // Size: 0x01
	char bHasUObject : 1; // Offset: 0x90 // Size: 0x01
	char pad_0x90_2 : 6; // Offset: 0x90 // Size: 0x01
	char pad_0x91[0x7]; // Offset: 0x91 // Size: 0x07
};

// Object Name: ScriptStruct SlateCore.SlateColor
// Size: 0x28 // Inherited bytes: 0x00
struct FSlateColor {
	// Fields
	struct FLinearColor SpecifiedColor; // Offset: 0x00 // Size: 0x10
	enum class ESlateColorStylingMode ColorUseRule; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x17]; // Offset: 0x11 // Size: 0x17
};

// Object Name: ScriptStruct SlateCore.Margin
// Size: 0x10 // Inherited bytes: 0x00
struct FMargin {
	// Fields
	float Left; // Offset: 0x00 // Size: 0x04
	float Top; // Offset: 0x04 // Size: 0x04
	float Right; // Offset: 0x08 // Size: 0x04
	float Bottom; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct SlateCore.InputEvent
// Size: 0x18 // Inherited bytes: 0x00
struct FInputEvent {
	// Fields
	char pad_0x0[0x18]; // Offset: 0x00 // Size: 0x18
};

// Object Name: ScriptStruct SlateCore.PointerEvent
// Size: 0x70 // Inherited bytes: 0x18
struct FPointerEvent : FInputEvent {
	// Fields
	char pad_0x18[0x58]; // Offset: 0x18 // Size: 0x58
};

// Object Name: ScriptStruct SlateCore.CharacterEvent
// Size: 0x20 // Inherited bytes: 0x18
struct FCharacterEvent : FInputEvent {
	// Fields
	char pad_0x18[0x8]; // Offset: 0x18 // Size: 0x08
};

// Object Name: ScriptStruct SlateCore.KeyEvent
// Size: 0x38 // Inherited bytes: 0x18
struct FKeyEvent : FInputEvent {
	// Fields
	char pad_0x18[0x20]; // Offset: 0x18 // Size: 0x20
};

// Object Name: ScriptStruct SlateCore.NavigationEvent
// Size: 0x20 // Inherited bytes: 0x18
struct FNavigationEvent : FInputEvent {
	// Fields
	char pad_0x18[0x8]; // Offset: 0x18 // Size: 0x08
};

// Object Name: ScriptStruct SlateCore.AnalogInputEvent
// Size: 0x40 // Inherited bytes: 0x38
struct FAnalogInputEvent : FKeyEvent {
	// Fields
	char pad_0x38[0x8]; // Offset: 0x38 // Size: 0x08
};

// Object Name: ScriptStruct SlateCore.SlateFontInfo
// Size: 0x60 // Inherited bytes: 0x00
struct FSlateFontInfo {
	// Fields
	struct UObject* FontObject; // Offset: 0x00 // Size: 0x08
	struct UObject* FontMaterial; // Offset: 0x08 // Size: 0x08
	struct FFontOutlineSettings OutlineSettings; // Offset: 0x10 // Size: 0x28
	char pad_0x38[0x10]; // Offset: 0x38 // Size: 0x10
	struct FName TypefaceFontName; // Offset: 0x48 // Size: 0x08
	int32_t Size; // Offset: 0x50 // Size: 0x04
	int32_t LetterSpacing; // Offset: 0x54 // Size: 0x04
	char pad_0x58[0x8]; // Offset: 0x58 // Size: 0x08
};

// Object Name: ScriptStruct SlateCore.FontOutlineSettings
// Size: 0x28 // Inherited bytes: 0x00
struct FFontOutlineSettings {
	// Fields
	int32_t OutlineSize; // Offset: 0x00 // Size: 0x04
	int32_t OutlineBlur; // Offset: 0x04 // Size: 0x04
	bool bSeparateFillAlpha; // Offset: 0x08 // Size: 0x01
	bool bApplyOutlineToDropShadows; // Offset: 0x09 // Size: 0x01
	char pad_0xA[0x6]; // Offset: 0x0a // Size: 0x06
	struct UObject* OutlineMaterial; // Offset: 0x10 // Size: 0x08
	struct FLinearColor OutlineColor; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct SlateCore.SlateWidgetStyle
// Size: 0x08 // Inherited bytes: 0x00
struct FSlateWidgetStyle {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct SlateCore.TableRowStyle
// Size: 0x8a8 // Inherited bytes: 0x08
struct FTableRowStyle : FSlateWidgetStyle {
	// Fields
	struct FSlateBrush SelectorFocusedBrush; // Offset: 0x08 // Size: 0x98
	struct FSlateBrush ActiveHoveredBrush; // Offset: 0xa0 // Size: 0x98
	struct FSlateBrush ActiveBrush; // Offset: 0x138 // Size: 0x98
	struct FSlateBrush InactiveHoveredBrush; // Offset: 0x1d0 // Size: 0x98
	struct FSlateBrush InactiveBrush; // Offset: 0x268 // Size: 0x98
	struct FSlateBrush EvenRowBackgroundHoveredBrush; // Offset: 0x300 // Size: 0x98
	struct FSlateBrush EvenRowBackgroundBrush; // Offset: 0x398 // Size: 0x98
	struct FSlateBrush OddRowBackgroundHoveredBrush; // Offset: 0x430 // Size: 0x98
	struct FSlateBrush OddRowBackgroundBrush; // Offset: 0x4c8 // Size: 0x98
	struct FSlateColor TextColor; // Offset: 0x560 // Size: 0x28
	struct FSlateColor SelectedTextColor; // Offset: 0x588 // Size: 0x28
	struct FSlateBrush DropIndicator_Above; // Offset: 0x5b0 // Size: 0x98
	struct FSlateBrush DropIndicator_Onto; // Offset: 0x648 // Size: 0x98
	struct FSlateBrush DropIndicator_Below; // Offset: 0x6e0 // Size: 0x98
	struct FSlateBrush ActiveHighlightedBrush; // Offset: 0x778 // Size: 0x98
	struct FSlateBrush InactiveHighlightedBrush; // Offset: 0x810 // Size: 0x98
};

// Object Name: ScriptStruct SlateCore.ComboBoxStyle
// Size: 0x450 // Inherited bytes: 0x08
struct FComboBoxStyle : FSlateWidgetStyle {
	// Fields
	struct FComboButtonStyle ComboButtonStyle; // Offset: 0x08 // Size: 0x418
	struct FSlateSound PressedSlateSound; // Offset: 0x420 // Size: 0x18
	struct FSlateSound SelectionChangeSlateSound; // Offset: 0x438 // Size: 0x18
};

// Object Name: ScriptStruct SlateCore.SlateSound
// Size: 0x18 // Inherited bytes: 0x00
struct FSlateSound {
	// Fields
	struct UObject* ResourceObject; // Offset: 0x00 // Size: 0x08
	char pad_0x8[0x10]; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct SlateCore.ComboButtonStyle
// Size: 0x418 // Inherited bytes: 0x08
struct FComboButtonStyle : FSlateWidgetStyle {
	// Fields
	struct FButtonStyle ButtonStyle; // Offset: 0x08 // Size: 0x2b8
	struct FSlateBrush DownArrowImage; // Offset: 0x2c0 // Size: 0x98
	struct FVector2D ShadowOffset; // Offset: 0x358 // Size: 0x08
	struct FLinearColor ShadowColorAndOpacity; // Offset: 0x360 // Size: 0x10
	struct FSlateBrush MenuBorderBrush; // Offset: 0x370 // Size: 0x98
	struct FMargin MenuBorderPadding; // Offset: 0x408 // Size: 0x10
};

// Object Name: ScriptStruct SlateCore.ButtonStyle
// Size: 0x2b8 // Inherited bytes: 0x08
struct FButtonStyle : FSlateWidgetStyle {
	// Fields
	struct FSlateBrush Normal; // Offset: 0x08 // Size: 0x98
	struct FSlateBrush Hovered; // Offset: 0xa0 // Size: 0x98
	struct FSlateBrush Pressed; // Offset: 0x138 // Size: 0x98
	struct FSlateBrush Disabled; // Offset: 0x1d0 // Size: 0x98
	struct FMargin NormalPadding; // Offset: 0x268 // Size: 0x10
	struct FMargin PressedPadding; // Offset: 0x278 // Size: 0x10
	struct FSlateSound PressedSlateSound; // Offset: 0x288 // Size: 0x18
	struct FSlateSound HoveredSlateSound; // Offset: 0x2a0 // Size: 0x18
};

// Object Name: ScriptStruct SlateCore.EditableTextStyle
// Size: 0x258 // Inherited bytes: 0x08
struct FEditableTextStyle : FSlateWidgetStyle {
	// Fields
	struct FSlateFontInfo Font; // Offset: 0x08 // Size: 0x60
	struct FSlateColor ColorAndOpacity; // Offset: 0x68 // Size: 0x28
	struct FSlateBrush BackgroundImageSelected; // Offset: 0x90 // Size: 0x98
	struct FSlateBrush BackgroundImageComposing; // Offset: 0x128 // Size: 0x98
	struct FSlateBrush CaretImage; // Offset: 0x1c0 // Size: 0x98
};

// Object Name: ScriptStruct SlateCore.EditableTextBoxStyle
// Size: 0x8d0 // Inherited bytes: 0x08
struct FEditableTextBoxStyle : FSlateWidgetStyle {
	// Fields
	struct FSlateBrush BackgroundImageNormal; // Offset: 0x08 // Size: 0x98
	struct FSlateBrush BackgroundImageHovered; // Offset: 0xa0 // Size: 0x98
	struct FSlateBrush BackgroundImageFocused; // Offset: 0x138 // Size: 0x98
	struct FSlateBrush BackgroundImageReadOnly; // Offset: 0x1d0 // Size: 0x98
	struct FMargin Padding; // Offset: 0x268 // Size: 0x10
	struct FSlateFontInfo Font; // Offset: 0x278 // Size: 0x60
	struct FSlateColor ForegroundColor; // Offset: 0x2d8 // Size: 0x28
	struct FSlateColor BackgroundColor; // Offset: 0x300 // Size: 0x28
	struct FSlateColor ReadOnlyForegroundColor; // Offset: 0x328 // Size: 0x28
	struct FMargin HScrollBarPadding; // Offset: 0x350 // Size: 0x10
	struct FMargin VScrollBarPadding; // Offset: 0x360 // Size: 0x10
	struct FScrollBarStyle ScrollBarStyle; // Offset: 0x370 // Size: 0x560
};

// Object Name: ScriptStruct SlateCore.ScrollBarStyle
// Size: 0x560 // Inherited bytes: 0x08
struct FScrollBarStyle : FSlateWidgetStyle {
	// Fields
	struct FSlateBrush HorizontalBackgroundImage; // Offset: 0x08 // Size: 0x98
	struct FSlateBrush VerticalBackgroundImage; // Offset: 0xa0 // Size: 0x98
	struct FSlateBrush VerticalTopSlotImage; // Offset: 0x138 // Size: 0x98
	struct FSlateBrush HorizontalTopSlotImage; // Offset: 0x1d0 // Size: 0x98
	struct FSlateBrush VerticalBottomSlotImage; // Offset: 0x268 // Size: 0x98
	struct FSlateBrush HorizontalBottomSlotImage; // Offset: 0x300 // Size: 0x98
	struct FSlateBrush NormalThumbImage; // Offset: 0x398 // Size: 0x98
	struct FSlateBrush HoveredThumbImage; // Offset: 0x430 // Size: 0x98
	struct FSlateBrush DraggedThumbImage; // Offset: 0x4c8 // Size: 0x98
};

// Object Name: ScriptStruct SlateCore.TextBlockStyle
// Size: 0x2a8 // Inherited bytes: 0x08
struct FTextBlockStyle : FSlateWidgetStyle {
	// Fields
	struct FSlateFontInfo Font; // Offset: 0x08 // Size: 0x60
	struct FSlateColor ColorAndOpacity; // Offset: 0x68 // Size: 0x28
	struct FVector2D ShadowOffset; // Offset: 0x90 // Size: 0x08
	struct FLinearColor ShadowColorAndOpacity; // Offset: 0x98 // Size: 0x10
	struct FSlateColor SelectedBackgroundColor; // Offset: 0xa8 // Size: 0x28
	struct FLinearColor HighlightColor; // Offset: 0xd0 // Size: 0x10
	struct FSlateBrush HighlightShape; // Offset: 0xe0 // Size: 0x98
	struct FSlateBrush StrikeBrush; // Offset: 0x178 // Size: 0x98
	struct FSlateBrush UnderlineBrush; // Offset: 0x210 // Size: 0x98
};

// Object Name: ScriptStruct SlateCore.SpinBoxStyle
// Size: 0x338 // Inherited bytes: 0x08
struct FSpinBoxStyle : FSlateWidgetStyle {
	// Fields
	struct FSlateBrush BackgroundBrush; // Offset: 0x08 // Size: 0x98
	struct FSlateBrush HoveredBackgroundBrush; // Offset: 0xa0 // Size: 0x98
	struct FSlateBrush ActiveFillBrush; // Offset: 0x138 // Size: 0x98
	struct FSlateBrush InactiveFillBrush; // Offset: 0x1d0 // Size: 0x98
	struct FSlateBrush ArrowsImage; // Offset: 0x268 // Size: 0x98
	struct FSlateColor ForegroundColor; // Offset: 0x300 // Size: 0x28
	struct FMargin TextPadding; // Offset: 0x328 // Size: 0x10
};

// Object Name: ScriptStruct SlateCore.FocusEvent
// Size: 0x08 // Inherited bytes: 0x00
struct FFocusEvent {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct SlateCore.MotionEvent
// Size: 0x48 // Inherited bytes: 0x18
struct FMotionEvent : FInputEvent {
	// Fields
	char pad_0x18[0x30]; // Offset: 0x18 // Size: 0x30
};

// Object Name: ScriptStruct SlateCore.HyperlinkStyle
// Size: 0x578 // Inherited bytes: 0x08
struct FHyperlinkStyle : FSlateWidgetStyle {
	// Fields
	struct FButtonStyle UnderlineStyle; // Offset: 0x08 // Size: 0x2b8
	struct FTextBlockStyle TextStyle; // Offset: 0x2c0 // Size: 0x2a8
	struct FMargin Padding; // Offset: 0x568 // Size: 0x10
};

// Object Name: ScriptStruct SlateCore.CompositeFont
// Size: 0x38 // Inherited bytes: 0x00
struct FCompositeFont {
	// Fields
	struct FTypeface DefaultTypeface; // Offset: 0x00 // Size: 0x10
	struct FCompositeFallbackFont FallbackTypeface; // Offset: 0x10 // Size: 0x18
	struct TArray<struct FCompositeSubFont> SubTypefaces; // Offset: 0x28 // Size: 0x10
};

// Object Name: ScriptStruct SlateCore.CompositeFallbackFont
// Size: 0x18 // Inherited bytes: 0x00
struct FCompositeFallbackFont {
	// Fields
	struct FTypeface Typeface; // Offset: 0x00 // Size: 0x10
	float ScalingFactor; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct SlateCore.Typeface
// Size: 0x10 // Inherited bytes: 0x00
struct FTypeface {
	// Fields
	struct TArray<struct FTypefaceEntry> Fonts; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct SlateCore.TypefaceEntry
// Size: 0x28 // Inherited bytes: 0x00
struct FTypefaceEntry {
	// Fields
	struct FName Name; // Offset: 0x00 // Size: 0x08
	struct FFontData Font; // Offset: 0x08 // Size: 0x20
};

// Object Name: ScriptStruct SlateCore.FontData
// Size: 0x20 // Inherited bytes: 0x00
struct FFontData {
	// Fields
	struct FString FontFilename; // Offset: 0x00 // Size: 0x10
	enum class EFontHinting Hinting; // Offset: 0x10 // Size: 0x01
	enum class EFontLoadingPolicy LoadingPolicy; // Offset: 0x11 // Size: 0x01
	char pad_0x12[0x2]; // Offset: 0x12 // Size: 0x02
	int32_t SubFaceIndex; // Offset: 0x14 // Size: 0x04
	struct UObject* FontFaceAsset; // Offset: 0x18 // Size: 0x08
};

// Object Name: ScriptStruct SlateCore.CompositeSubFont
// Size: 0x38 // Inherited bytes: 0x18
struct FCompositeSubFont : FCompositeFallbackFont {
	// Fields
	struct TArray<struct FInt32Range> CharacterRanges; // Offset: 0x18 // Size: 0x10
	struct FString Cultures; // Offset: 0x28 // Size: 0x10
};

// Object Name: ScriptStruct SlateCore.CaptureLostEvent
// Size: 0x08 // Inherited bytes: 0x00
struct FCaptureLostEvent {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct SlateCore.WindowStyle
// Size: 0x1208 // Inherited bytes: 0x08
struct FWindowStyle : FSlateWidgetStyle {
	// Fields
	struct FButtonStyle MinimizeButtonStyle; // Offset: 0x08 // Size: 0x2b8
	struct FButtonStyle MaximizeButtonStyle; // Offset: 0x2c0 // Size: 0x2b8
	struct FButtonStyle RestoreButtonStyle; // Offset: 0x578 // Size: 0x2b8
	struct FButtonStyle CloseButtonStyle; // Offset: 0x830 // Size: 0x2b8
	struct FTextBlockStyle TitleTextStyle; // Offset: 0xae8 // Size: 0x2a8
	struct FSlateBrush ActiveTitleBrush; // Offset: 0xd90 // Size: 0x98
	struct FSlateBrush InactiveTitleBrush; // Offset: 0xe28 // Size: 0x98
	struct FSlateBrush FlashTitleBrush; // Offset: 0xec0 // Size: 0x98
	struct FSlateColor BackgroundColor; // Offset: 0xf58 // Size: 0x28
	struct FSlateBrush OutlineBrush; // Offset: 0xf80 // Size: 0x98
	struct FSlateColor OutlineColor; // Offset: 0x1018 // Size: 0x28
	struct FSlateBrush BorderBrush; // Offset: 0x1040 // Size: 0x98
	struct FSlateBrush BackgroundBrush; // Offset: 0x10d8 // Size: 0x98
	struct FSlateBrush ChildBackgroundBrush; // Offset: 0x1170 // Size: 0x98
};

// Object Name: ScriptStruct SlateCore.ScrollBorderStyle
// Size: 0x138 // Inherited bytes: 0x08
struct FScrollBorderStyle : FSlateWidgetStyle {
	// Fields
	struct FSlateBrush TopShadowBrush; // Offset: 0x08 // Size: 0x98
	struct FSlateBrush BottomShadowBrush; // Offset: 0xa0 // Size: 0x98
};

// Object Name: ScriptStruct SlateCore.ScrollBoxStyle
// Size: 0x268 // Inherited bytes: 0x08
struct FScrollBoxStyle : FSlateWidgetStyle {
	// Fields
	struct FSlateBrush TopShadowBrush; // Offset: 0x08 // Size: 0x98
	struct FSlateBrush BottomShadowBrush; // Offset: 0xa0 // Size: 0x98
	struct FSlateBrush LeftShadowBrush; // Offset: 0x138 // Size: 0x98
	struct FSlateBrush RightShadowBrush; // Offset: 0x1d0 // Size: 0x98
};

// Object Name: ScriptStruct SlateCore.DockTabStyle
// Size: 0x7c0 // Inherited bytes: 0x08
struct FDockTabStyle : FSlateWidgetStyle {
	// Fields
	struct FButtonStyle CloseButtonStyle; // Offset: 0x08 // Size: 0x2b8
	struct FSlateBrush NormalBrush; // Offset: 0x2c0 // Size: 0x98
	struct FSlateBrush ActiveBrush; // Offset: 0x358 // Size: 0x98
	struct FSlateBrush ColorOverlayTabBrush; // Offset: 0x3f0 // Size: 0x98
	struct FSlateBrush ColorOverlayIconBrush; // Offset: 0x488 // Size: 0x98
	struct FSlateBrush ForegroundBrush; // Offset: 0x520 // Size: 0x98
	struct FSlateBrush HoveredBrush; // Offset: 0x5b8 // Size: 0x98
	struct FSlateBrush ContentAreaBrush; // Offset: 0x650 // Size: 0x98
	struct FSlateBrush TabWellBrush; // Offset: 0x6e8 // Size: 0x98
	struct FMargin TabPadding; // Offset: 0x780 // Size: 0x10
	float OverlapWidth; // Offset: 0x790 // Size: 0x04
	char pad_0x794[0x4]; // Offset: 0x794 // Size: 0x04
	struct FSlateColor FlashColor; // Offset: 0x798 // Size: 0x28
};

// Object Name: ScriptStruct SlateCore.HeaderRowStyle
// Size: 0xcc0 // Inherited bytes: 0x08
struct FHeaderRowStyle : FSlateWidgetStyle {
	// Fields
	struct FTableColumnHeaderStyle ColumnStyle; // Offset: 0x08 // Size: 0x560
	struct FTableColumnHeaderStyle LastColumnStyle; // Offset: 0x568 // Size: 0x560
	struct FSplitterStyle ColumnSplitterStyle; // Offset: 0xac8 // Size: 0x138
	struct FSlateBrush BackgroundBrush; // Offset: 0xc00 // Size: 0x98
	struct FSlateColor ForegroundColor; // Offset: 0xc98 // Size: 0x28
};

// Object Name: ScriptStruct SlateCore.SplitterStyle
// Size: 0x138 // Inherited bytes: 0x08
struct FSplitterStyle : FSlateWidgetStyle {
	// Fields
	struct FSlateBrush HandleNormalBrush; // Offset: 0x08 // Size: 0x98
	struct FSlateBrush HandleHighlightBrush; // Offset: 0xa0 // Size: 0x98
};

// Object Name: ScriptStruct SlateCore.TableColumnHeaderStyle
// Size: 0x560 // Inherited bytes: 0x08
struct FTableColumnHeaderStyle : FSlateWidgetStyle {
	// Fields
	struct FSlateBrush SortPrimaryAscendingImage; // Offset: 0x08 // Size: 0x98
	struct FSlateBrush SortPrimaryDescendingImage; // Offset: 0xa0 // Size: 0x98
	struct FSlateBrush SortSecondaryAscendingImage; // Offset: 0x138 // Size: 0x98
	struct FSlateBrush SortSecondaryDescendingImage; // Offset: 0x1d0 // Size: 0x98
	struct FSlateBrush NormalBrush; // Offset: 0x268 // Size: 0x98
	struct FSlateBrush HoveredBrush; // Offset: 0x300 // Size: 0x98
	struct FSlateBrush MenuDropdownImage; // Offset: 0x398 // Size: 0x98
	struct FSlateBrush MenuDropdownNormalBorderBrush; // Offset: 0x430 // Size: 0x98
	struct FSlateBrush MenuDropdownHoveredBorderBrush; // Offset: 0x4c8 // Size: 0x98
};

// Object Name: ScriptStruct SlateCore.InlineTextImageStyle
// Size: 0xa8 // Inherited bytes: 0x08
struct FInlineTextImageStyle : FSlateWidgetStyle {
	// Fields
	struct FSlateBrush Image; // Offset: 0x08 // Size: 0x98
	int16_t Baseline; // Offset: 0xa0 // Size: 0x02
	char pad_0xA2[0x6]; // Offset: 0xa2 // Size: 0x06
};

// Object Name: ScriptStruct SlateCore.VolumeControlStyle
// Size: 0x6a0 // Inherited bytes: 0x08
struct FVolumeControlStyle : FSlateWidgetStyle {
	// Fields
	struct FSliderStyle SliderStyle; // Offset: 0x08 // Size: 0x3a0
	struct FSlateBrush HighVolumeImage; // Offset: 0x3a8 // Size: 0x98
	struct FSlateBrush MidVolumeImage; // Offset: 0x440 // Size: 0x98
	struct FSlateBrush LowVolumeImage; // Offset: 0x4d8 // Size: 0x98
	struct FSlateBrush NoVolumeImage; // Offset: 0x570 // Size: 0x98
	struct FSlateBrush MutedImage; // Offset: 0x608 // Size: 0x98
};

// Object Name: ScriptStruct SlateCore.SliderStyle
// Size: 0x3a0 // Inherited bytes: 0x08
struct FSliderStyle : FSlateWidgetStyle {
	// Fields
	struct FSlateBrush NormalBarImage; // Offset: 0x08 // Size: 0x98
	struct FSlateBrush HoveredBarImage; // Offset: 0xa0 // Size: 0x98
	struct FSlateBrush DisabledBarImage; // Offset: 0x138 // Size: 0x98
	struct FSlateBrush NormalThumbImage; // Offset: 0x1d0 // Size: 0x98
	struct FSlateBrush HoveredThumbImage; // Offset: 0x268 // Size: 0x98
	struct FSlateBrush DisabledThumbImage; // Offset: 0x300 // Size: 0x98
	float BarThickness; // Offset: 0x398 // Size: 0x04
	char pad_0x39C[0x4]; // Offset: 0x39c // Size: 0x04
};

// Object Name: ScriptStruct SlateCore.SearchBoxStyle
// Size: 0xbb0 // Inherited bytes: 0x08
struct FSearchBoxStyle : FSlateWidgetStyle {
	// Fields
	struct FEditableTextBoxStyle TextBoxStyle; // Offset: 0x08 // Size: 0x8d0
	struct FSlateFontInfo ActiveFontInfo; // Offset: 0x8d8 // Size: 0x60
	struct FSlateBrush UpArrowImage; // Offset: 0x938 // Size: 0x98
	struct FSlateBrush DownArrowImage; // Offset: 0x9d0 // Size: 0x98
	struct FSlateBrush GlassImage; // Offset: 0xa68 // Size: 0x98
	struct FSlateBrush ClearImage; // Offset: 0xb00 // Size: 0x98
	struct FMargin ImagePadding; // Offset: 0xb98 // Size: 0x10
	bool bLeftAlignButtons; // Offset: 0xba8 // Size: 0x01
	char pad_0xBA9[0x7]; // Offset: 0xba9 // Size: 0x07
};

// Object Name: ScriptStruct SlateCore.ExpandableAreaStyle
// Size: 0x140 // Inherited bytes: 0x08
struct FExpandableAreaStyle : FSlateWidgetStyle {
	// Fields
	struct FSlateBrush CollapsedImage; // Offset: 0x08 // Size: 0x98
	struct FSlateBrush ExpandedImage; // Offset: 0xa0 // Size: 0x98
	float RolloutAnimationSeconds; // Offset: 0x138 // Size: 0x04
	char pad_0x13C[0x4]; // Offset: 0x13c // Size: 0x04
};

// Object Name: ScriptStruct SlateCore.ProgressBarStyle
// Size: 0x1d0 // Inherited bytes: 0x08
struct FProgressBarStyle : FSlateWidgetStyle {
	// Fields
	struct FSlateBrush BackgroundImage; // Offset: 0x08 // Size: 0x98
	struct FSlateBrush FillImage; // Offset: 0xa0 // Size: 0x98
	struct FSlateBrush MarqueeImage; // Offset: 0x138 // Size: 0x98
};

// Object Name: ScriptStruct SlateCore.InlineEditableTextBlockStyle
// Size: 0xb80 // Inherited bytes: 0x08
struct FInlineEditableTextBlockStyle : FSlateWidgetStyle {
	// Fields
	struct FEditableTextBoxStyle EditableTextBoxStyle; // Offset: 0x08 // Size: 0x8d0
	struct FTextBlockStyle TextStyle; // Offset: 0x8d8 // Size: 0x2a8
};

// Object Name: ScriptStruct SlateCore.CheckBoxStyle
// Size: 0x610 // Inherited bytes: 0x08
struct FCheckBoxStyle : FSlateWidgetStyle {
	// Fields
	enum class ESlateCheckBoxType CheckBoxType; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x7]; // Offset: 0x09 // Size: 0x07
	struct FSlateBrush UncheckedImage; // Offset: 0x10 // Size: 0x98
	struct FSlateBrush UncheckedHoveredImage; // Offset: 0xa8 // Size: 0x98
	struct FSlateBrush UncheckedPressedImage; // Offset: 0x140 // Size: 0x98
	struct FSlateBrush CheckedImage; // Offset: 0x1d8 // Size: 0x98
	struct FSlateBrush CheckedHoveredImage; // Offset: 0x270 // Size: 0x98
	struct FSlateBrush CheckedPressedImage; // Offset: 0x308 // Size: 0x98
	struct FSlateBrush UndeterminedImage; // Offset: 0x3a0 // Size: 0x98
	struct FSlateBrush UndeterminedHoveredImage; // Offset: 0x438 // Size: 0x98
	struct FSlateBrush UndeterminedPressedImage; // Offset: 0x4d0 // Size: 0x98
	struct FMargin Padding; // Offset: 0x568 // Size: 0x10
	struct FSlateColor ForegroundColor; // Offset: 0x578 // Size: 0x28
	struct FSlateColor BorderBackgroundColor; // Offset: 0x5a0 // Size: 0x28
	struct FSlateSound CheckedSlateSound; // Offset: 0x5c8 // Size: 0x18
	struct FSlateSound UncheckedSlateSound; // Offset: 0x5e0 // Size: 0x18
	struct FSlateSound HoveredSlateSound; // Offset: 0x5f8 // Size: 0x18
};

