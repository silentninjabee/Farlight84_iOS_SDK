#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class SolarFramework.SolarContainer
// Size: 0x28 // Inherited bytes: 0x28
struct USolarContainer : UObject {
	// Functions

	// Object Name: Function SolarFramework.SolarContainer.ReceiveInitialize
	// Flags: [Event|Public|BlueprintEvent]
	void ReceiveInitialize(); // Offset: 0x1032a8bf4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SolarFramework.SolarContainer.ReceiveDeinitialize
	// Flags: [Event|Public|BlueprintEvent]
	void ReceiveDeinitialize(); // Offset: 0x1032a8bf4 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class SolarFramework.SolarAbstractManager
// Size: 0x28 // Inherited bytes: 0x28
struct USolarAbstractManager : USolarContainer {
};

// Object Name: Class SolarFramework.SolarAbstractModel
// Size: 0x28 // Inherited bytes: 0x28
struct USolarAbstractModel : USolarContainer {
};

// Object Name: Class SolarFramework.SolarArchitecture
// Size: 0x348 // Inherited bytes: 0x1a0
struct USolarArchitecture : UGameInstance {
	// Fields
	struct FMulticastInlineDelegate OnOnScopeChangeDelegate; // Offset: 0x1a0 // Size: 0x10
	char pad_0x1B0[0x198]; // Offset: 0x1b0 // Size: 0x198

	// Functions

	// Object Name: Function SolarFramework.SolarArchitecture.OnScopeChanged
	// Flags: [Event|Public|BlueprintEvent]
	void OnScopeChanged(enum class EScope InLastScope, enum class EScope InCurScope); // Offset: 0x1032a8bf4 // Return & Params: Num(2) Size(0x2)

	// Object Name: Function SolarFramework.SolarArchitecture.IsScopeSettlement
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsScopeSettlement(); // Offset: 0x102f17fd8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function SolarFramework.SolarArchitecture.IsScopeLogin
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsScopeLogin(); // Offset: 0x102f18044 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function SolarFramework.SolarArchitecture.IsScopeLobby
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsScopeLobby(); // Offset: 0x102f18020 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function SolarFramework.SolarArchitecture.IsScopeBattle
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsScopeBattle(); // Offset: 0x102f17ffc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function SolarFramework.SolarArchitecture.IsInScope
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsInScope(enum class EScope InScopeMask); // Offset: 0x102f18068 // Return & Params: Num(2) Size(0x2)

	// Object Name: Function SolarFramework.SolarArchitecture.GetModel
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	struct USolarAbstractModel* GetModel(struct USolarAbstractModel*& ModelClass); // Offset: 0x102f18114 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function SolarFramework.SolarArchitecture.GetManager
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	struct USolarAbstractManager* GetManager(struct USolarAbstractManager*& ManagerClass); // Offset: 0x102f181b0 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function SolarFramework.SolarArchitecture.GetCurScope
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	enum class EScope GetCurScope(); // Offset: 0x102f180f8 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class SolarFramework.SolarFrameworkSettings
// Size: 0x58 // Inherited bytes: 0x38
struct USolarFrameworkSettings : UDeveloperSettings {
	// Fields
	struct TArray<struct FSolarConfigEntry> ManagerConfigs; // Offset: 0x38 // Size: 0x10
	struct TArray<struct FSolarConfigEntry> ModelConfigs; // Offset: 0x48 // Size: 0x10
};

