#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass SolarGameInstance.SolarGameInstance_C
// Size: 0x9c0 // Inherited bytes: 0x9b8
struct USolarGameInstance_C : USolarGameInstanceBase {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x9b8 // Size: 0x08

	// Functions

	// Object Name: Function SolarGameInstance.SolarGameInstance_C.SolarGM_TestCrashWithBP
	// Flags: [Exec|Event|Public|BlueprintEvent]
	void SolarGM_TestCrashWithBP(); // Offset: 0x1032a8bf4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SolarGameInstance.SolarGameInstance_C.SolarGM_TestEnsureMsgWithBP
	// Flags: [Exec|Event|Public|BlueprintEvent]
	void SolarGM_TestEnsureMsgWithBP(); // Offset: 0x1032a8bf4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SolarGameInstance.SolarGameInstance_C.ExecuteUbergraph_SolarGameInstance
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_SolarGameInstance(int32_t EntryPoint); // Offset: 0x1032a8bf4 // Return & Params: Num(1) Size(0x4)
};

