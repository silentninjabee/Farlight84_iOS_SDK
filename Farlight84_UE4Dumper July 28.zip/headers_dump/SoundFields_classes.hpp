#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class SoundFields.AmbisonicsEncodingSettings
// Size: 0x30 // Inherited bytes: 0x28
struct UAmbisonicsEncodingSettings : USoundfieldEncodingSettingsBase {
	// Fields
	int32_t AmbisonicsOrder; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
};

