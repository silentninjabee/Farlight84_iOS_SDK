#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class UIParticleSystem.ParticleSystemWidget
// Size: 0x168 // Inherited bytes: 0x138
struct UParticleSystemWidget : UWidget {
	// Fields
	struct UParticleSystem* ParticleSystemTemplate; // Offset: 0x138 // Size: 0x08
	bool bReactivate; // Offset: 0x140 // Size: 0x01
	bool bActiveSysWhenInit; // Offset: 0x141 // Size: 0x01
	char pad_0x142[0x6]; // Offset: 0x142 // Size: 0x06
	struct UParticleSystemComponent* WorldParticleComponent; // Offset: 0x148 // Size: 0x08
	struct AActor* WorldParticleActor; // Offset: 0x150 // Size: 0x08
	char pad_0x158[0x10]; // Offset: 0x158 // Size: 0x10

	// Functions

	// Object Name: Function UIParticleSystem.ParticleSystemWidget.SetReactivate
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetReactivate(bool bActivateAndReset); // Offset: 0x10106a3c0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UIParticleSystem.ParticleSystemWidget.ActivateParticles
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ActivateParticles(bool bActive, bool bReset); // Offset: 0x10106a448 // Return & Params: Num(2) Size(0x2)
};

// Object Name: Class UIParticleSystem.UIParticleComponent
// Size: 0x7e0 // Inherited bytes: 0x7e0
struct UUIParticleComponent : UParticleSystemComponent {
};

// Object Name: Class UIParticleSystem.UIParticleActor
// Size: 0x228 // Inherited bytes: 0x228
struct AUIParticleActor : AActor {
};

