#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_UpdateLoadingBase.UI_UpdateLoadingBase_C
// Size: 0x4c0 // Inherited bytes: 0x4b0
struct UUI_UpdateLoadingBase_C : UUI_LoadingBase_C {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x4b0 // Size: 0x08
	struct UCanvasPanel* Panel_Load; // Offset: 0x4b8 // Size: 0x08

	// Functions

	// Object Name: Function UI_UpdateLoadingBase.UI_UpdateLoadingBase_C.SetPercentText
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetPercentText(struct FText NewParam); // Offset: 0x1032a8bf4 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function UI_UpdateLoadingBase.UI_UpdateLoadingBase_C.SetImgBgHidden
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetImgBgHidden(); // Offset: 0x1032a8bf4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_UpdateLoadingBase.UI_UpdateLoadingBase_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void PreConstruct(bool IsDesignTime); // Offset: 0x1032a8bf4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_UpdateLoadingBase.UI_UpdateLoadingBase_C.Tick
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Offset: 0x1032a8bf4 // Return & Params: Num(2) Size(0x3c)

	// Object Name: Function UI_UpdateLoadingBase.UI_UpdateLoadingBase_C.ExecuteUbergraph_UI_UpdateLoadingBase
	// Flags: [Final|UbergraphFunction|HasDefaults]
	void ExecuteUbergraph_UI_UpdateLoadingBase(int32_t EntryPoint); // Offset: 0x1032a8bf4 // Return & Params: Num(1) Size(0x4)
};

