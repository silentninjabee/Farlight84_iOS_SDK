#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct UObjectPlugin.MyPluginStruct
// Size: 0x10 // Inherited bytes: 0x00
struct FMyPluginStruct {
	// Fields
	struct FString TestString; // Offset: 0x00 // Size: 0x10
};

