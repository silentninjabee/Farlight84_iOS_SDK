#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct VariantManagerContent.FunctionCaller
// Size: 0x08 // Inherited bytes: 0x00
struct FFunctionCaller {
	// Fields
	struct FName FunctionName; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct VariantManagerContent.CapturedPropSegment
// Size: 0x28 // Inherited bytes: 0x00
struct FCapturedPropSegment {
	// Fields
	struct FString PropertyName; // Offset: 0x00 // Size: 0x10
	int32_t PropertyIndex; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct FString ComponentName; // Offset: 0x18 // Size: 0x10
};

