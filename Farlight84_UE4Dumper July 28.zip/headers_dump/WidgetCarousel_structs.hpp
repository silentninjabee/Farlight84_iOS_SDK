#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct WidgetCarousel.WidgetCarouselNavigationBarStyle
// Size: 0x8c8 // Inherited bytes: 0x08
struct FWidgetCarouselNavigationBarStyle : FSlateWidgetStyle {
	// Fields
	struct FSlateBrush HighlightBrush; // Offset: 0x08 // Size: 0x98
	struct FButtonStyle LeftButtonStyle; // Offset: 0xa0 // Size: 0x2b8
	struct FButtonStyle CenterButtonStyle; // Offset: 0x358 // Size: 0x2b8
	struct FButtonStyle RightButtonStyle; // Offset: 0x610 // Size: 0x2b8
};

// Object Name: ScriptStruct WidgetCarousel.WidgetCarouselNavigationButtonStyle
// Size: 0x3f0 // Inherited bytes: 0x08
struct FWidgetCarouselNavigationButtonStyle : FSlateWidgetStyle {
	// Fields
	struct FButtonStyle InnerButtonStyle; // Offset: 0x08 // Size: 0x2b8
	struct FSlateBrush NavigationButtonLeftImage; // Offset: 0x2c0 // Size: 0x98
	struct FSlateBrush NavigationButtonRightImage; // Offset: 0x358 // Size: 0x98
};

