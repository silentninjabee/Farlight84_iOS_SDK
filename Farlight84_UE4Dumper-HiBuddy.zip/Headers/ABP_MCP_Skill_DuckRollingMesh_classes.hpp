#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: DynamicClass ABP_MCP_Skill_DuckRollingMesh.ABP_MCP_Skill_DuckRollingMesh_C
// Inherited Bytes: 0x2b0 | Struct Size: 0x4a0
struct UABP_MCP_Skill_DuckRollingMesh_C : UAnimInstance {
	// Fields
	struct FAnimNode_Root AnimGraphNode_Root; // Offset: 0x2a8 | Size: 0x30
	struct FAnimNode_Slot AnimGraphNode_Slot; // Offset: 0x2d8 | Size: 0x48
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone; // Offset: 0x320 | Size: 0x108
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace; // Offset: 0x428 | Size: 0x20
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace; // Offset: 0x448 | Size: 0x20
	int32_t PoseIndex; // Offset: 0x468 | Size: 0x4
	struct FRotator BoneRotation; // Offset: 0x46c | Size: 0xc
	float RootOffsetZ; // Offset: 0x478 | Size: 0x4
	float K2Node_Event_DeltaTimeX; // Offset: 0x47c | Size: 0x4
	struct ASolarCharacter* K2Node_DynamicCast_AsSolar_Character; // Offset: 0x480 | Size: 0x8
	bool K2Node_DynamicCast_bSuccess; // Offset: 0x488 | Size: 0x1
	struct UDuckRollingMeshComponent* K2Node_DynamicCast_AsB_Duck_Rolling_Mesh_Component; // Offset: 0x490 | Size: 0x8
	bool K2Node_DynamicCast_bSuccess_2; // Offset: 0x498 | Size: 0x1
	char pad_0x49A[0x6]; // Offset: 0x49a | Size: 0x6

	// Functions

	// Object: Function ABP_MCP_Skill_DuckRollingMesh.ABP_MCP_Skill_DuckRollingMesh_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_MCP_Skill_DuckRollingMesh_AnimGraphNode_ModifyBone_91AEC0A84734F98DAFCF6A96BF96E989
	// Flags: [Native|Public]
	// Offset: 0x101594d64
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_MCP_Skill_DuckRollingMesh_AnimGraphNode_ModifyBone_91AEC0A84734F98DAFCF6A96BF96E989();

	// Object: Function ABP_MCP_Skill_DuckRollingMesh.ABP_MCP_Skill_DuckRollingMesh_C.BlueprintUpdateAnimation
	// Flags: [Native|Event|Public]
	// Offset: 0x101594d80
	// Return & Params: [ Num(1) Size(0x4) ]
	void BlueprintUpdateAnimation(float bpp__DeltaTimeX__pf);

	// Object: Function ABP_MCP_Skill_DuckRollingMesh.ABP_MCP_Skill_DuckRollingMesh_C.AnimGraph
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1034eea34
	// Return & Params: [ Num(1) Size(0x10) ]
	void AnimGraph(struct FPoseLink& bpp__AnimGraph__pf);
};

