#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass AEBP_DefaultMultiPassEffectParameters.AEBP_DefaultMultiPassEffectParameters_C
// Inherited Bytes: 0x1e8 | Struct Size: 0x1e8
struct UAEBP_DefaultMultiPassEffectParameters_C : UMultiplePassMaterialEffect {
};

