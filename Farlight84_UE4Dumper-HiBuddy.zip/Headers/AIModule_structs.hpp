#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct AIModule.AIRequestID
// Inherited Bytes: 0x0 | Struct Size: 0x4
struct FAIRequestID {
	// Fields
	uint32_t RequestID; // Offset: 0x0 | Size: 0x4
};

// Object: ScriptStruct AIModule.AIStimulus
// Inherited Bytes: 0x0 | Struct Size: 0x3c
struct FAIStimulus {
	// Fields
	float Age; // Offset: 0x0 | Size: 0x4
	float ExpirationAge; // Offset: 0x4 | Size: 0x4
	float Strength; // Offset: 0x8 | Size: 0x4
	struct FVector StimulusLocation; // Offset: 0xc | Size: 0xc
	struct FVector ReceiverLocation; // Offset: 0x18 | Size: 0xc
	struct FName Tag; // Offset: 0x24 | Size: 0x8
	char pad_0x2C[0xc]; // Offset: 0x2c | Size: 0xc
	char pad_0x38_0 : 1; // Offset: 0x38 | Size: 0x1
	char bSuccessfullySensed : 1; // Offset: 0x38 | Size: 0x1
	char pad_0x38_2 : 6; // Offset: 0x38 | Size: 0x1
	char pad_0x39[0x3]; // Offset: 0x39 | Size: 0x3
};

// Object: ScriptStruct AIModule.AIDataProviderValue
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FAIDataProviderValue {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x0 | Size: 0x10
	struct UAIDataProvider* DataBinding; // Offset: 0x10 | Size: 0x8
	struct FName DataField; // Offset: 0x18 | Size: 0x8
};

// Object: ScriptStruct AIModule.AIDataProviderTypedValue
// Inherited Bytes: 0x20 | Struct Size: 0x30
struct FAIDataProviderTypedValue : FAIDataProviderValue {
	// Fields
	struct UObject* PropertyType; // Offset: 0x20 | Size: 0x8
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
};

// Object: ScriptStruct AIModule.AIDataProviderBoolValue
// Inherited Bytes: 0x30 | Struct Size: 0x38
struct FAIDataProviderBoolValue : FAIDataProviderTypedValue {
	// Fields
	bool DefaultValue; // Offset: 0x30 | Size: 0x1
	char pad_0x31[0x7]; // Offset: 0x31 | Size: 0x7
};

// Object: ScriptStruct AIModule.AIDataProviderFloatValue
// Inherited Bytes: 0x30 | Struct Size: 0x38
struct FAIDataProviderFloatValue : FAIDataProviderTypedValue {
	// Fields
	float DefaultValue; // Offset: 0x30 | Size: 0x4
	char pad_0x34[0x4]; // Offset: 0x34 | Size: 0x4
};

// Object: ScriptStruct AIModule.AIDataProviderIntValue
// Inherited Bytes: 0x30 | Struct Size: 0x38
struct FAIDataProviderIntValue : FAIDataProviderTypedValue {
	// Fields
	int32_t DefaultValue; // Offset: 0x30 | Size: 0x4
	char pad_0x34[0x4]; // Offset: 0x34 | Size: 0x4
};

// Object: ScriptStruct AIModule.AIDataProviderStructValue
// Inherited Bytes: 0x20 | Struct Size: 0x30
struct FAIDataProviderStructValue : FAIDataProviderValue {
	// Fields
	char pad_0x20[0x10]; // Offset: 0x20 | Size: 0x10
};

// Object: ScriptStruct AIModule.ActorPerceptionBlueprintInfo
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FActorPerceptionBlueprintInfo {
	// Fields
	struct AActor* Target; // Offset: 0x0 | Size: 0x8
	struct TArray<struct FAIStimulus> LastSensedStimuli; // Offset: 0x8 | Size: 0x10
	char bIsHostile : 1; // Offset: 0x18 | Size: 0x1
	char pad_0x18_1 : 7; // Offset: 0x18 | Size: 0x1
	char pad_0x19[0x7]; // Offset: 0x19 | Size: 0x7
};

// Object: ScriptStruct AIModule.AISenseAffiliationFilter
// Inherited Bytes: 0x0 | Struct Size: 0x4
struct FAISenseAffiliationFilter {
	// Fields
	char bDetectEnemies : 1; // Offset: 0x0 | Size: 0x1
	char bDetectNeutrals : 1; // Offset: 0x0 | Size: 0x1
	char bDetectFriendlies : 1; // Offset: 0x0 | Size: 0x1
	char pad_0x0_3 : 5; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
};

// Object: ScriptStruct AIModule.AIDamageEvent
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FAIDamageEvent {
	// Fields
	float amount; // Offset: 0x0 | Size: 0x4
	struct FVector Location; // Offset: 0x4 | Size: 0xc
	struct FVector HitLocation; // Offset: 0x10 | Size: 0xc
	char pad_0x1C[0x4]; // Offset: 0x1c | Size: 0x4
	struct AActor* DamagedActor; // Offset: 0x20 | Size: 0x8
	struct AActor* Instigator; // Offset: 0x28 | Size: 0x8
};

// Object: ScriptStruct AIModule.AINoiseEvent
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FAINoiseEvent {
	// Fields
	char pad_0x0[0x4]; // Offset: 0x0 | Size: 0x4
	struct FVector NoiseLocation; // Offset: 0x4 | Size: 0xc
	float Loudness; // Offset: 0x10 | Size: 0x4
	float MaxRange; // Offset: 0x14 | Size: 0x4
	struct AActor* Instigator; // Offset: 0x18 | Size: 0x8
	struct FName Tag; // Offset: 0x20 | Size: 0x8
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
};

// Object: ScriptStruct AIModule.AIPredictionEvent
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FAIPredictionEvent {
	// Fields
	struct AActor* Requestor; // Offset: 0x0 | Size: 0x8
	struct AActor* PredictedActor; // Offset: 0x8 | Size: 0x8
	char pad_0x10[0x8]; // Offset: 0x10 | Size: 0x8
};

// Object: ScriptStruct AIModule.AISightEvent
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FAISightEvent {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
	struct AActor* SeenActor; // Offset: 0x8 | Size: 0x8
	struct AActor* Observer; // Offset: 0x10 | Size: 0x8
};

// Object: ScriptStruct AIModule.AITeamStimulusEvent
// Inherited Bytes: 0x0 | Struct Size: 0x38
struct FAITeamStimulusEvent {
	// Fields
	char pad_0x0[0x28]; // Offset: 0x0 | Size: 0x28
	struct AActor* Broadcaster; // Offset: 0x28 | Size: 0x8
	struct AActor* Enemy; // Offset: 0x30 | Size: 0x8
};

// Object: ScriptStruct AIModule.AITouchEvent
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FAITouchEvent {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x0 | Size: 0x10
	struct AActor* TouchReceiver; // Offset: 0x10 | Size: 0x8
	struct AActor* OtherActor; // Offset: 0x18 | Size: 0x8
};

// Object: ScriptStruct AIModule.IntervalCountdown
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FIntervalCountdown {
	// Fields
	float Interval; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct AIModule.AIMoveRequest
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FAIMoveRequest {
	// Fields
	struct AActor* GoalActor; // Offset: 0x0 | Size: 0x8
	char pad_0x8[0x38]; // Offset: 0x8 | Size: 0x38
};

// Object: ScriptStruct AIModule.BehaviorTreeTemplateInfo
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FBehaviorTreeTemplateInfo {
	// Fields
	struct UBehaviorTree* Asset; // Offset: 0x0 | Size: 0x8
	struct UBTCompositeNode* Template; // Offset: 0x8 | Size: 0x8
	char pad_0x10[0x8]; // Offset: 0x10 | Size: 0x8
};

// Object: ScriptStruct AIModule.BlackboardKeySelector
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FBlackboardKeySelector {
	// Fields
	struct TArray<struct UBlackboardKeyType*> AllowedTypes; // Offset: 0x0 | Size: 0x10
	struct FName SelectedKeyName; // Offset: 0x10 | Size: 0x8
	struct UBlackboardKeyType* SelectedKeyType; // Offset: 0x18 | Size: 0x8
	char SelectedKeyID; // Offset: 0x20 | Size: 0x1
	char bNoneIsAllowedValue : 1; // Offset: 0x21 | Size: 0x1
	char pad_0x21_1 : 7; // Offset: 0x21 | Size: 0x1
	char pad_0x22[0x6]; // Offset: 0x22 | Size: 0x6
};

// Object: ScriptStruct AIModule.BlackboardEntry
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FBlackboardEntry {
	// Fields
	struct FName EntryName; // Offset: 0x0 | Size: 0x8
	struct UBlackboardKeyType* KeyType; // Offset: 0x8 | Size: 0x8
	char bInstanceSynced : 1; // Offset: 0x10 | Size: 0x1
	char pad_0x10_1 : 7; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x7]; // Offset: 0x11 | Size: 0x7
};

// Object: ScriptStruct AIModule.BTCompositeChild
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FBTCompositeChild {
	// Fields
	struct UBTCompositeNode* ChildComposite; // Offset: 0x0 | Size: 0x8
	struct UBTTaskNode* ChildTask; // Offset: 0x8 | Size: 0x8
	struct TArray<struct UBTDecorator*> Decorators; // Offset: 0x10 | Size: 0x10
	struct TArray<struct FBTDecoratorLogic> DecoratorOps; // Offset: 0x20 | Size: 0x10
};

// Object: ScriptStruct AIModule.BTDecoratorLogic
// Inherited Bytes: 0x0 | Struct Size: 0x4
struct FBTDecoratorLogic {
	// Fields
	enum class EBTDecoratorLogic Operation; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x1]; // Offset: 0x1 | Size: 0x1
	uint16_t Number; // Offset: 0x2 | Size: 0x2
};

// Object: ScriptStruct AIModule.CrowdAvoidanceSamplingPattern
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FCrowdAvoidanceSamplingPattern {
	// Fields
	struct TArray<float> Angles; // Offset: 0x0 | Size: 0x10
	struct TArray<float> Radii; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct AIModule.CrowdAvoidanceConfig
// Inherited Bytes: 0x0 | Struct Size: 0x1c
struct FCrowdAvoidanceConfig {
	// Fields
	float VelocityBias; // Offset: 0x0 | Size: 0x4
	float DesiredVelocityWeight; // Offset: 0x4 | Size: 0x4
	float CurrentVelocityWeight; // Offset: 0x8 | Size: 0x4
	float SideBiasWeight; // Offset: 0xc | Size: 0x4
	float ImpactTimeWeight; // Offset: 0x10 | Size: 0x4
	float ImpactTimeRange; // Offset: 0x14 | Size: 0x4
	char CustomPatternIdx; // Offset: 0x18 | Size: 0x1
	char AdaptiveDivisions; // Offset: 0x19 | Size: 0x1
	char AdaptiveRings; // Offset: 0x1a | Size: 0x1
	char AdaptiveDepth; // Offset: 0x1b | Size: 0x1
};

// Object: ScriptStruct AIModule.EnvQueryInstanceCache
// Inherited Bytes: 0x0 | Struct Size: 0x178
struct FEnvQueryInstanceCache {
	// Fields
	struct UEnvQuery* Template; // Offset: 0x0 | Size: 0x8
	char pad_0x8[0x170]; // Offset: 0x8 | Size: 0x170
};

// Object: ScriptStruct AIModule.EnvQueryRequest
// Inherited Bytes: 0x0 | Struct Size: 0x68
struct FEnvQueryRequest {
	// Fields
	struct UEnvQuery* QueryTemplate; // Offset: 0x0 | Size: 0x8
	struct UObject* Owner; // Offset: 0x8 | Size: 0x8
	struct UWorld* World; // Offset: 0x10 | Size: 0x8
	char pad_0x18[0x50]; // Offset: 0x18 | Size: 0x50
};

// Object: ScriptStruct AIModule.EQSParametrizedQueryExecutionRequest
// Inherited Bytes: 0x0 | Struct Size: 0x48
struct FEQSParametrizedQueryExecutionRequest {
	// Fields
	struct UEnvQuery* QueryTemplate; // Offset: 0x0 | Size: 0x8
	struct TArray<struct FAIDynamicParam> QueryConfig; // Offset: 0x8 | Size: 0x10
	struct FBlackboardKeySelector EQSQueryBlackboardKey; // Offset: 0x18 | Size: 0x28
	enum class EEnvQueryRunMode RunMode; // Offset: 0x40 | Size: 0x1
	char bUseBBKeyForQueryTemplate : 1; // Offset: 0x41 | Size: 0x1
	char pad_0x41_1 : 7; // Offset: 0x41 | Size: 0x1
	char pad_0x42[0x6]; // Offset: 0x42 | Size: 0x6
};

// Object: ScriptStruct AIModule.AIDynamicParam
// Inherited Bytes: 0x0 | Struct Size: 0x38
struct FAIDynamicParam {
	// Fields
	struct FName ParamName; // Offset: 0x0 | Size: 0x8
	enum class EAIParamType ParamType; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x3]; // Offset: 0x9 | Size: 0x3
	float Value; // Offset: 0xc | Size: 0x4
	struct FBlackboardKeySelector BBKey; // Offset: 0x10 | Size: 0x28
};

// Object: ScriptStruct AIModule.EnvQueryResult
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FEnvQueryResult {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x0 | Size: 0x10
	struct UEnvQueryItemType* ItemType; // Offset: 0x10 | Size: 0x8
	char pad_0x18[0x14]; // Offset: 0x18 | Size: 0x14
	int32_t OptionIndex; // Offset: 0x2c | Size: 0x4
	int32_t QueryID; // Offset: 0x30 | Size: 0x4
	char pad_0x34[0xc]; // Offset: 0x34 | Size: 0xc
};

// Object: ScriptStruct AIModule.EnvOverlapData
// Inherited Bytes: 0x0 | Struct Size: 0x1c
struct FEnvOverlapData {
	// Fields
	float ExtentX; // Offset: 0x0 | Size: 0x4
	float ExtentY; // Offset: 0x4 | Size: 0x4
	float ExtentZ; // Offset: 0x8 | Size: 0x4
	struct FVector ShapeOffset; // Offset: 0xc | Size: 0xc
	enum class ECollisionChannel OverlapChannel; // Offset: 0x18 | Size: 0x1
	enum class EEnvOverlapShape OverlapShape; // Offset: 0x19 | Size: 0x1
	char bOnlyBlockingHits : 1; // Offset: 0x1a | Size: 0x1
	char bOverlapComplex : 1; // Offset: 0x1a | Size: 0x1
	char bSkipOverlapQuerier : 1; // Offset: 0x1a | Size: 0x1
	char pad_0x1A_3 : 5; // Offset: 0x1a | Size: 0x1
	char pad_0x1B[0x1]; // Offset: 0x1b | Size: 0x1
};

// Object: ScriptStruct AIModule.EnvTraceData
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FEnvTraceData {
	// Fields
	int32_t VersionNum; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct UNavigationQueryFilter* NavigationFilter; // Offset: 0x8 | Size: 0x8
	float ProjectDown; // Offset: 0x10 | Size: 0x4
	float ProjectUp; // Offset: 0x14 | Size: 0x4
	float ExtentX; // Offset: 0x18 | Size: 0x4
	float ExtentY; // Offset: 0x1c | Size: 0x4
	float ExtentZ; // Offset: 0x20 | Size: 0x4
	float PostProjectionVerticalOffset; // Offset: 0x24 | Size: 0x4
	enum class ETraceTypeQuery TraceChannel; // Offset: 0x28 | Size: 0x1
	enum class ECollisionChannel SerializedChannel; // Offset: 0x29 | Size: 0x1
	enum class EEnvTraceShape TraceShape; // Offset: 0x2a | Size: 0x1
	enum class EEnvQueryTrace TraceMode; // Offset: 0x2b | Size: 0x1
	char bTraceComplex : 1; // Offset: 0x2c | Size: 0x1
	char bOnlyBlockingHits : 1; // Offset: 0x2c | Size: 0x1
	char bCanTraceOnNavMesh : 1; // Offset: 0x2c | Size: 0x1
	char bCanTraceOnGeometry : 1; // Offset: 0x2c | Size: 0x1
	char bCanDisableTrace : 1; // Offset: 0x2c | Size: 0x1
	char bCanProjectDown : 1; // Offset: 0x2c | Size: 0x1
	char pad_0x2C_6 : 2; // Offset: 0x2c | Size: 0x1
	char pad_0x2D[0x3]; // Offset: 0x2d | Size: 0x3
};

// Object: ScriptStruct AIModule.EnvDirection
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FEnvDirection {
	// Fields
	struct UEnvQueryContext* LineFrom; // Offset: 0x0 | Size: 0x8
	struct UEnvQueryContext* LineTo; // Offset: 0x8 | Size: 0x8
	struct UEnvQueryContext* Rotation; // Offset: 0x10 | Size: 0x8
	enum class EEnvDirection DirMode; // Offset: 0x18 | Size: 0x1
	char pad_0x19[0x7]; // Offset: 0x19 | Size: 0x7
};

// Object: ScriptStruct AIModule.EnvNamedValue
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FEnvNamedValue {
	// Fields
	struct FName ParamName; // Offset: 0x0 | Size: 0x8
	enum class EAIParamType ParamType; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x3]; // Offset: 0x9 | Size: 0x3
	float Value; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct AIModule.GenericTeamId
// Inherited Bytes: 0x0 | Struct Size: 0x1
struct FGenericTeamId {
	// Fields
	char TeamID; // Offset: 0x0 | Size: 0x1
};

// Object: ScriptStruct AIModule.PawnActionStack
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FPawnActionStack {
	// Fields
	struct UPawnAction* TopAction; // Offset: 0x0 | Size: 0x8
};

// Object: ScriptStruct AIModule.PawnActionEvent
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FPawnActionEvent {
	// Fields
	struct UPawnAction* Action; // Offset: 0x0 | Size: 0x8
	char pad_0x8[0x10]; // Offset: 0x8 | Size: 0x10
};

