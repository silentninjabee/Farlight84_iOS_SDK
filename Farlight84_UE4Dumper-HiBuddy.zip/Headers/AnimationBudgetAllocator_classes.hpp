#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class AnimationBudgetAllocator.AnimationBudgetBlueprintLibrary
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UAnimationBudgetBlueprintLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object: Function AnimationBudgetAllocator.AnimationBudgetBlueprintLibrary.SetAnimationBudgetParameters
	// Flags: [Final|Native|Static|Private|HasOutParms|BlueprintCallable]
	// Offset: 0x102b2a388
	// Return & Params: [ Num(2) Size(0x5c) ]
	void SetAnimationBudgetParameters(struct UObject* WorldContextObject, struct FAnimationBudgetAllocatorParameters& InParameters);

	// Object: Function AnimationBudgetAllocator.AnimationBudgetBlueprintLibrary.EnableAnimationBudget
	// Flags: [Final|Native|Static|Private|BlueprintCallable]
	// Offset: 0x102b2a49c
	// Return & Params: [ Num(2) Size(0x9) ]
	void EnableAnimationBudget(struct UObject* WorldContextObject, bool bEnabled);
};

// Object: Class AnimationBudgetAllocator.SkeletalMeshComponentBudgeted
// Inherited Bytes: 0xd40 | Struct Size: 0xd70
struct USkeletalMeshComponentBudgeted : USkeletalMeshComponent {
	// Fields
	enum class ESkeletalMeshAnimDetailMode AnimDetailMode; // Offset: 0xd40 | Size: 0x1
	char pad_0xD41[0x27]; // Offset: 0xd41 | Size: 0x27
	char bAutoRegisterWithBudgetAllocator : 1; // Offset: 0xd68 | Size: 0x1
	char bAutoCalculateSignificance : 1; // Offset: 0xd68 | Size: 0x1
	char bShouldUseActorRenderedFlag : 1; // Offset: 0xd68 | Size: 0x1
	char pad_0xD68_3 : 5; // Offset: 0xd68 | Size: 0x1
	char pad_0xD69[0x7]; // Offset: 0xd69 | Size: 0x7

	// Functions

	// Object: Function AnimationBudgetAllocator.SkeletalMeshComponentBudgeted.SetAutoRegisterWithBudgetAllocator
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102b2a658
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetAutoRegisterWithBudgetAllocator(bool bInAutoRegisterWithBudgetAllocator);
};

