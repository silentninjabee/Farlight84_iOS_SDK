#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct AppleImageUtils.AppleImageUtilsImageConversionResult
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FAppleImageUtilsImageConversionResult {
	// Fields
	struct FString Error; // Offset: 0x0 | Size: 0x10
	struct TArray<char> ImageData; // Offset: 0x10 | Size: 0x10
};

