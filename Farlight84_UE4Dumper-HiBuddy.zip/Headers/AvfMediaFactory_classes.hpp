#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class AvfMediaFactory.AvfMediaSettings
// Inherited Bytes: 0x28 | Struct Size: 0x30
struct UAvfMediaSettings : UObject {
	// Fields
	bool NativeAudioOut; // Offset: 0x28 | Size: 0x1
	char pad_0x29[0x7]; // Offset: 0x29 | Size: 0x7
};

