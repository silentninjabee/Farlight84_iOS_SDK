#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BPC_Death_BattleRoyale.BPC_Death_BattleRoyale_C
// Inherited Bytes: 0x17c | Struct Size: 0x2b8
struct UBPC_Death_BattleRoyale_C : UBPC_Death_Framework_C {
	// Fields
	char pad_0x17C[0x4]; // Offset: 0x17c | Size: 0x4
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x180 | Size: 0x8
	struct ABP_ReviveItemManger_BattleRoyale_C* ReviveItemManger; // Offset: 0x188 | Size: 0x8
	struct ASCMPlayerState* Killer; // Offset: 0x190 | Size: 0x8
	struct ASCMPlayerState* Killed; // Offset: 0x198 | Size: 0x8
	struct FSolarPointDamageEvent DeathDamageEvent; // Offset: 0x1a0 | Size: 0x118

	// Functions

	// Object: Function BPC_Death_BattleRoyale.BPC_Death_BattleRoyale_C.Out Put Kill Log
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(1) Size(0x1) ]
	void Out Put Kill Log(bool InBool);

	// Object: Function BPC_Death_BattleRoyale.BPC_Death_BattleRoyale_C.TryRevivePlayerByCoin
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(2) Size(0x9) ]
	void TryRevivePlayerByCoin(struct ABP_PlayerState_BattleRoyale_C* Player, bool& Succeed);

	// Object: Function BPC_Death_BattleRoyale.BPC_Death_BattleRoyale_C.CanPlayerBattle
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x10213e738
	// Return & Params: [ Num(2) Size(0x9) ]
	bool CanPlayerBattle(struct ASCMPlayerState* Player);

	// Object: Function BPC_Death_BattleRoyale.BPC_Death_BattleRoyale_C.GetMainLogic
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x10213e738
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UBP_Logic_BattleRoyale_C* GetMainLogic();

	// Object: Function BPC_Death_BattleRoyale.BPC_Death_BattleRoyale_C.GetConiReviveManager
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x10213e738
	// Return & Params: [ Num(1) Size(0x8) ]
	void GetConiReviveManager(struct ABP_ReviveItemManger_BattleRoyale_C*& Output_Get);

	// Object: Function BPC_Death_BattleRoyale.BPC_Death_BattleRoyale_C.ReceivePlayerKill
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(5) Size(0x140) ]
	void ReceivePlayerKill(struct ASCMPlayerState* Killer, struct ASCMPlayerState* Killed, struct TArray<struct ASCMPlayerState*>& Assists, struct FSolarPointDamageEvent& InDamageEvent, struct AActor* InDamageCauser);

	// Object: Function BPC_Death_BattleRoyale.BPC_Death_BattleRoyale_C.ReceivePlayerDeathVerge
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(4) Size(0x130) ]
	void ReceivePlayerDeathVerge(struct ASCMPlayerState* InAttacker, struct ASCMPlayerState* InDeathVergePlayer, struct FSolarPointDamageEvent& InDamageEvent, struct AActor* InDamageCauser);

	// Object: Function BPC_Death_BattleRoyale.BPC_Death_BattleRoyale_C.ReceivePlayerResurrect
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(2) Size(0x10) ]
	void ReceivePlayerResurrect(struct ASolarCharacter* ResurrectCharacter, struct ASCMPlayerState* ResurrectPlayer);

	// Object: Function BPC_Death_BattleRoyale.BPC_Death_BattleRoyale_C.ReceiveBeginPlay
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(0) Size(0x0) ]
	void ReceiveBeginPlay();

	// Object: Function BPC_Death_BattleRoyale.BPC_Death_BattleRoyale_C.ExecuteUbergraph_BPC_Death_BattleRoyale
	// Flags: [Final|UbergraphFunction|HasDefaults]
	// Offset: 0x10213e738
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_BPC_Death_BattleRoyale(int32_t EntryPoint);
};

