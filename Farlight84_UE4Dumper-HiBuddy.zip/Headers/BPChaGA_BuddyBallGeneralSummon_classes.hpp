#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BPChaGA_BuddyBallGeneralSummon.BPChaGA_BuddyBallGeneralSummon_C
// Inherited Bytes: 0x5f0 | Struct Size: 0x5f0
struct UBPChaGA_BuddyBallGeneralSummon_C : UChaGA_BuddyGeneralSummon {
};

