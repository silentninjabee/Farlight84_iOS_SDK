#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_BattleRoylePoisonCircle.BP_BattleRoylePoisonCircle_C
// Inherited Bytes: 0x608 | Struct Size: 0x608
struct ABP_BattleRoylePoisonCircle_C : ABP_CustomPoisonCircle_Template_C {
};

