#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_BlueCircle.BP_BlueCircle_C
// Inherited Bytes: 0x280 | Struct Size: 0x298
struct ABP_BlueCircle_C : ASolarBlueCircle {
	// Fields
	struct UStaticMeshComponent* FX_Tag_Glow1; // Offset: 0x280 | Size: 0x8
	struct USceneComponent* Scene; // Offset: 0x288 | Size: 0x8
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x290 | Size: 0x8

	// Functions

	// Object: Function BP_BlueCircle.BP_BlueCircle_C.GetGlowMeshComponent
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UStaticMeshComponent* GetGlowMeshComponent();

	// Object: Function BP_BlueCircle.BP_BlueCircle_C.GetModuleName
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x10213e738
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();
};

