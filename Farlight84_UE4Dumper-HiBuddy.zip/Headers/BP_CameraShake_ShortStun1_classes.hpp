#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_CameraShake_ShortStun1.BP_CameraShake_ShortStun1_C
// Inherited Bytes: 0x190 | Struct Size: 0x190
struct UBP_CameraShake_ShortStun1_C : USolarCameraShake {
};

