#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_Controller_BattleRoyale.BP_Controller_BattleRoyale_C
// Inherited Bytes: 0x1254 | Struct Size: 0x1254
struct ABP_Controller_BattleRoyale_C : ABP_Controller_Framework_C {
};

