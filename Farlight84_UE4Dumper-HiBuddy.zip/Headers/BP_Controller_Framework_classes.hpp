#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_Controller_Framework.BP_Controller_Framework_C
// Inherited Bytes: 0x1208 | Struct Size: 0x1254
struct ABP_Controller_Framework_C : ASCMPlayerController {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x1208 | Size: 0x8
	struct FPoseSnapshot Snapshot; // Offset: 0x1210 | Size: 0x38
	float TempMaxDist; // Offset: 0x1248 | Size: 0x4
	int32_t TempMaxIndex; // Offset: 0x124c | Size: 0x4
	int32_t EnableAiPalRate; // Offset: 0x1250 | Size: 0x4

	// Functions

	// Object: Function BP_Controller_Framework.BP_Controller_Framework_C.MeerkatTriggerReport
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(1) Size(0x10) ]
	void MeerkatTriggerReport(struct FString Value);

	// Object: Function BP_Controller_Framework.BP_Controller_Framework_C.UpdateAiPalRate
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(1) Size(0x4) ]
	void UpdateAiPalRate(int32_t Rate);

	// Object: Function BP_Controller_Framework.BP_Controller_Framework_C.OnRep_EnableAiPalRate
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnRep_EnableAiPalRate();

	// Object: Function BP_Controller_Framework.BP_Controller_Framework_C.OnNotifyLockPlayer
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(1) Size(0x10) ]
	void OnNotifyLockPlayer(struct FString Name);

	// Object: Function BP_Controller_Framework.BP_Controller_Framework_C.RequestNotifyLockPlayer
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(1) Size(0x10) ]
	void RequestNotifyLockPlayer(struct FString Name);

	// Object: Function BP_Controller_Framework.BP_Controller_Framework_C.ClientNotifyLockPlayer
	// Flags: [Net|NetClient|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(1) Size(0x10) ]
	void ClientNotifyLockPlayer(struct FString Name);

	// Object: Function BP_Controller_Framework.BP_Controller_Framework_C.RpcClientRepAceStatusToServer
	// Flags: [Net|NetServer|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(1) Size(0x10) ]
	void RpcClientRepAceStatusToServer(struct FString Value);

	// Object: Function BP_Controller_Framework.BP_Controller_Framework_C.ExecuteUbergraph_BP_Controller_Framework
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x10213e738
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_BP_Controller_Framework(int32_t EntryPoint);
};

