#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_Express.BP_Express_C
// Inherited Bytes: 0x7d0 | Struct Size: 0x7e0
struct ABP_Express_C : ASolarSummonExpress {
	// Fields
	struct UParticleSystemComponent* ParticleSystem; // Offset: 0x7d0 | Size: 0x8
	struct UStaticMeshComponent* HPBillboard; // Offset: 0x7d8 | Size: 0x8
};

