#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_Formula_BattleRoyale.BP_Formula_BattleRoyale_C
// Inherited Bytes: 0x31c | Struct Size: 0x3c8
struct ABP_Formula_BattleRoyale_C : ABP_FormulaBase_C {
	// Fields
	int32_t WarmGameExp; // Offset: 0x31c | Size: 0x4
	struct TMap<struct ASolarPlayerState*, bool> WeaponExp; // Offset: 0x320 | Size: 0x50
	struct TSet<int32_t> WarmGameIdSet; // Offset: 0x370 | Size: 0x50
	struct ABP_DefenderManager_C* DefenderManager; // Offset: 0x3c0 | Size: 0x8

	// Functions

	// Object: Function BP_Formula_BattleRoyale.BP_Formula_BattleRoyale_C.GetSettlementRewards
	// Flags: [Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(2) Size(0x18) ]
	struct TArray<struct FSettlementReward> GetSettlementRewards(struct ASolarPlayerState* InPS);

	// Object: Function BP_Formula_BattleRoyale.BP_Formula_BattleRoyale_C.IsSettlementBagItem
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(2) Size(0x9) ]
	bool IsSettlementBagItem(struct ASolarPlayerState* InPS);

	// Object: Function BP_Formula_BattleRoyale.BP_Formula_BattleRoyale_C.GetDefenderManager
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x10213e738
	// Return & Params: [ Num(1) Size(0x8) ]
	void GetDefenderManager(struct ABP_DefenderManager_C*& Output_Get);

	// Object: Function BP_Formula_BattleRoyale.BP_Formula_BattleRoyale_C.MVPLifeTimeScore
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x10213e738
	// Return & Params: [ Num(2) Size(0x8) ]
	void MVPLifeTimeScore(float Life Time, float& LTMVPScore);

	// Object: Function BP_Formula_BattleRoyale.BP_Formula_BattleRoyale_C.GetStrategyGuideConditions
	// Flags: [Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetStrategyGuideConditions(struct ASolarPlayerState* InPS, struct TArray<int32_t>& OutResult);

	// Object: Function BP_Formula_BattleRoyale.BP_Formula_BattleRoyale_C.CalculateTeamRank
	// Flags: [Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(2) Size(0xc) ]
	int32_t CalculateTeamRank(struct ASolarPlayerState* InPS);

	// Object: Function BP_Formula_BattleRoyale.BP_Formula_BattleRoyale_C.CalculatePlayerRank
	// Flags: [Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(2) Size(0xc) ]
	int32_t CalculatePlayerRank(struct ASolarPlayerState* InPS);

	// Object: Function BP_Formula_BattleRoyale.BP_Formula_BattleRoyale_C.BattleStateDealFloat
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x10213e738
	// Return & Params: [ Num(2) Size(0x8) ]
	float BattleStateDealFloat(float Input);

	// Object: Function BP_Formula_BattleRoyale.BP_Formula_BattleRoyale_C.BattleStateDealInt
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x10213e738
	// Return & Params: [ Num(2) Size(0x8) ]
	int32_t BattleStateDealInt(int32_t Input);

	// Object: Function BP_Formula_BattleRoyale.BP_Formula_BattleRoyale_C.GetBattleState
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x10213e738
	// Return & Params: [ Num(1) Size(0x1) ]
	void GetBattleState(enum class E_BattleState_BattleRoyale& State);

	// Object: Function BP_Formula_BattleRoyale.BP_Formula_BattleRoyale_C.GetKDA
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(2) Size(0xc) ]
	float GetKDA(struct ASolarPlayerState* InPS);

	// Object: Function BP_Formula_BattleRoyale.BP_Formula_BattleRoyale_C.GetExtraRewards
	// Flags: [Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(2) Size(0x18) ]
	struct TArray<struct FSettlementParam_ExtraRewardInfo> GetExtraRewards(struct ASolarPlayerState* InPS);

	// Object: Function BP_Formula_BattleRoyale.BP_Formula_BattleRoyale_C.GetPlayerData
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(14) Size(0x30) ]
	void GetPlayerData(struct ASolarPlayerState* Player, int32_t& KillCount, int32_t& KillDown, int32_t& Assist, int32_t& SaveCount, float& LifeTime, float& CauseDamage, int32_t& Rank, int32_t& TeamRank, int32_t& DeathCount, bool& TeamAced, bool& IsMVP, bool& IsCustomRoomActive, enum class E_DefenderPlayerType& DefenderType);

	// Object: Function BP_Formula_BattleRoyale.BP_Formula_BattleRoyale_C.GetZomborg
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x10213e738
	// Return & Params: [ Num(2) Size(0xc) ]
	int32_t GetZomborg(struct ASolarPlayerState* InPS);

	// Object: Function BP_Formula_BattleRoyale.BP_Formula_BattleRoyale_C.GetCharacterExp
	// Flags: [Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(3) Size(0x20) ]
	void GetCharacterExp(struct ASolarPlayerState* InPS, int32_t& OutGetExp, struct TArray<int32_t>& OutReason);

	// Object: Function BP_Formula_BattleRoyale.BP_Formula_BattleRoyale_C.GetAccountExp
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x10213e738
	// Return & Params: [ Num(2) Size(0xc) ]
	int32_t GetAccountExp(struct ASolarPlayerState* InPS);

	// Object: Function BP_Formula_BattleRoyale.BP_Formula_BattleRoyale_C.GetShowPageIndexs
	// Flags: [Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(3) Size(0x20) ]
	void GetShowPageIndexs(struct ASolarPlayerState* InPS, struct FSettlePageParam& InParam, struct TArray<int32_t>& OutResult);
};

