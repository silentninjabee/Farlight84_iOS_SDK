#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_GE_DebuffImmunity.BP_GE_DebuffImmunity_C
// Inherited Bytes: 0x898 | Struct Size: 0x898
struct UBP_GE_DebuffImmunity_C : UGameplayEffect {
};

