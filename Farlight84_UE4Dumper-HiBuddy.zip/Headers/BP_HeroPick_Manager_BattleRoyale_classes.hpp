#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_HeroPick_Manager_BattleRoyale.BP_HeroPick_Manager_BattleRoyale_C
// Inherited Bytes: 0x358 | Struct Size: 0x358
struct ABP_HeroPick_Manager_BattleRoyale_C : AHeroPickManager_BattleRoyale {
};

