#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_InteractionDoor.BP_InteractionDoor_C
// Inherited Bytes: 0x6d0 | Struct Size: 0x6d0
struct ABP_InteractionDoor_C : ASolarInteractionDoor {
};

