#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_MapInfoComponent.BP_MapInfoComponent_C
// Inherited Bytes: 0x248 | Struct Size: 0x37c
struct UBP_MapInfoComponent_C : UCGMMapInfo {
	// Fields
	struct FAirlineData Airline; // Offset: 0x248 | Size: 0x28
	struct TArray<struct FVector> SafeAreaCenters; // Offset: 0x270 | Size: 0x10
	bool StaticAirline; // Offset: 0x280 | Size: 0x1
	bool StaticSafeArea; // Offset: 0x281 | Size: 0x1
	char pad_0x282[0x6]; // Offset: 0x282 | Size: 0x6
	struct UDataTable* DT_EventTimeline_BattleRoyale; // Offset: 0x288 | Size: 0x8
	bool UsePoisonCircleMarker; // Offset: 0x290 | Size: 0x1
	char pad_0x291[0x3]; // Offset: 0x291 | Size: 0x3
	struct FVector2D TempDir; // Offset: 0x294 | Size: 0x8
	bool UseFakePoint; // Offset: 0x29c | Size: 0x1
	char pad_0x29D[0x3]; // Offset: 0x29d | Size: 0x3
	struct TMap<int32_t, struct FVector2D> FakePointRangeArr; // Offset: 0x2a0 | Size: 0x50
	bool UseFakeBombPoint; // Offset: 0x2f0 | Size: 0x1
	char pad_0x2F1[0x7]; // Offset: 0x2f1 | Size: 0x7
	struct TMap<int32_t, struct FVector2D> FakeBombPointRangeArr; // Offset: 0x2f8 | Size: 0x50
	struct FVector PreCirclePoint; // Offset: 0x348 | Size: 0xc
	char pad_0x354[0x4]; // Offset: 0x354 | Size: 0x4
	struct TArray<float> CircleRadiusArr; // Offset: 0x358 | Size: 0x10
	int32_t StaticAirlineID; // Offset: 0x368 | Size: 0x4
	struct FInt32Range OverrideCenterIndex; // Offset: 0x36c | Size: 0x10

	// Functions

	// Object: Function BP_MapInfoComponent.BP_MapInfoComponent_C.Calculate Required Parameters
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(5) Size(0x20) ]
	void Calculate Required Parameters(struct TArray<float>& RadiusArr, int32_t Index, float& Radius, float& MaxOffset, float& GoToTheCentreRadius);

	// Object: Function BP_MapInfoComponent.BP_MapInfoComponent_C.Random Get Fake Bomb Point
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(3) Size(0x11) ]
	void Random Get Fake Bomb Point(int32_t& Key, struct FVector& Pos, bool& Success);

	// Object: Function BP_MapInfoComponent.BP_MapInfoComponent_C.SetFakeBombPointRangeArrr
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(1) Size(0x50) ]
	void SetFakeBombPointRangeArrr(struct TMap<int32_t, struct FVector2D> FakeBombPointRangeArr);

	// Object: Function BP_MapInfoComponent.BP_MapInfoComponent_C.SetFakePointRnageArr
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(1) Size(0x50) ]
	void SetFakePointRnageArr(struct TMap<int32_t, struct FVector2D> FakePointRnageArr);

	// Object: Function BP_MapInfoComponent.BP_MapInfoComponent_C.Get Safe Area Centers Len
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(1) Size(0x4) ]
	void Get Safe Area Centers Len(int32_t& Len);

	// Object: Function BP_MapInfoComponent.BP_MapInfoComponent_C.CalculateFakePoint
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(5) Size(0x24) ]
	void CalculateFakePoint(struct FVector Centre, float SmallRadiu, float LargeRadiu, int32_t Index, struct FVector& Pos);

	// Object: Function BP_MapInfoComponent.BP_MapInfoComponent_C.Join Next
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(5) Size(0x24) ]
	void Join Next(float Radius, float MaxOffset, int32_t LastIndex, struct TArray<struct FVector>& TargetArray, float GoToTheCentreRadius);

	// Object: Function BP_MapInfoComponent.BP_MapInfoComponent_C.Random Selection
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(5) Size(0x1a) ]
	void Random Selection(float TargetDisMax, float Radius, struct TArray<struct FVector>& TargetArray, bool NeedCheckBoundary, bool& Add);

	// Object: Function BP_MapInfoComponent.BP_MapInfoComponent_C.JudgeBoundary
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(3) Size(0x11) ]
	void JudgeBoundary(struct FVector Pos, float Radius, bool& DontInBoundary);

	// Object: Function BP_MapInfoComponent.BP_MapInfoComponent_C.Calculate Poison Circle Point Array
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(1) Size(0x10) ]
	void Calculate Poison Circle Point Array(struct TArray<float>& RadiusArr);

	// Object: Function BP_MapInfoComponent.BP_MapInfoComponent_C.Get Safe Area Center
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(2) Size(0x10) ]
	void Get Safe Area Center(int32_t Index, struct FVector& Pos);

	// Object: Function BP_MapInfoComponent.BP_MapInfoComponent_C.GetAirline
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x10213e738
	// Return & Params: [ Num(2) Size(0x2c) ]
	int32_t GetAirline(struct FAirlineData& Airline);

	// Object: Function BP_MapInfoComponent.BP_MapInfoComponent_C.SetStaticSafeArea
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(2) Size(0x20) ]
	void SetStaticSafeArea(struct TArray<struct FVector>& SafeAreaCenters, struct FInt32Range OverrideIndexRange);

	// Object: Function BP_MapInfoComponent.BP_MapInfoComponent_C.SetStaticAirline
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(2) Size(0x2c) ]
	void SetStaticAirline(struct FAirlineData Airline, int32_t StaticAirlineID);
};

