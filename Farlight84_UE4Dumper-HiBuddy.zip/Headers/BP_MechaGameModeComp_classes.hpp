#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_MechaGameModeComp.BP_MechaGameModeComp_C
// Inherited Bytes: 0x110 | Struct Size: 0x110
struct UBP_MechaGameModeComp_C : UMechaBossGameModeComp {
};

