#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_MorphMeshComponent.BP_MorphMeshComponent_C
// Inherited Bytes: 0xad0 | Struct Size: 0xad0
struct UBP_MorphMeshComponent_C : UMorphBuddyComponent {
};

