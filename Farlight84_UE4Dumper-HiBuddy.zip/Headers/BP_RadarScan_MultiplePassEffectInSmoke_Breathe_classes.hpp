#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_RadarScan_MultiplePassEffectInSmoke_Breathe.BP_RadarScan_MultiplePassEffectInSmoke_Breathe_C
// Inherited Bytes: 0x1e8 | Struct Size: 0x1e8
struct UBP_RadarScan_MultiplePassEffectInSmoke_Breathe_C : UMultiplePassMaterialEffect {
};

