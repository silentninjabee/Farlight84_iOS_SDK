#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_RadarScan_NormalEffect_Breathe.BP_RadarScan_NormalEffect_Breathe_C
// Inherited Bytes: 0x230 | Struct Size: 0x230
struct UBP_RadarScan_NormalEffect_Breathe_C : UMaterialSimpleEffect {
};

