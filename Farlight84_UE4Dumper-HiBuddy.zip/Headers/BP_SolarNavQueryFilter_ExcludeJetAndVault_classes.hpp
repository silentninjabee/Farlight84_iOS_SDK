#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_SolarNavQueryFilter_ExcludeJetAndVault.BP_SolarNavQueryFilter_ExcludeJetAndVault_C
// Inherited Bytes: 0x48 | Struct Size: 0x48
struct UBP_SolarNavQueryFilter_ExcludeJetAndVault_C : USolarNavQueryFilter {
};

