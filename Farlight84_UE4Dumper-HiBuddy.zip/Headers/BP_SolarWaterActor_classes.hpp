#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_SolarWaterActor.BP_SolarWaterActor_C
// Inherited Bytes: 0x718 | Struct Size: 0x720
struct ABP_SolarWaterActor_C : ASolarWaterActorNew {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x718 | Size: 0x8

	// Functions

	// Object: Function BP_SolarWaterActor.BP_SolarWaterActor_C.BndEvt__SurfaceMeshComponent_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature
	// Flags: [HasOutParms|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(6) Size(0xa8) ]
	void BndEvt__SurfaceMeshComponent_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult);

	// Object: Function BP_SolarWaterActor.BP_SolarWaterActor_C.BndEvt__SurfaceMeshComponent_K2Node_ComponentBoundEvent_1_ComponentEndOverlapSignature__DelegateSignature
	// Flags: [BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(4) Size(0x1c) ]
	void BndEvt__SurfaceMeshComponent_K2Node_ComponentBoundEvent_1_ComponentEndOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex);

	// Object: Function BP_SolarWaterActor.BP_SolarWaterActor_C.ExecuteUbergraph_BP_SolarWaterActor
	// Flags: [Final|UbergraphFunction|HasDefaults]
	// Offset: 0x10213e738
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_BP_SolarWaterActor(int32_t EntryPoint);
};

