#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_TP_Default_Base.BP_TP_Default_Base_C
// Inherited Bytes: 0x458 | Struct Size: 0x458
struct ABP_TP_Default_Base_C : ABP_CapsuleBase_InBattle_C {
};

