#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_WL03_DissolvedDeath.BP_WL03_DissolvedDeath_C
// Inherited Bytes: 0x240 | Struct Size: 0x240
struct UBP_WL03_DissolvedDeath_C : UMaterialVariableEffect {
};

