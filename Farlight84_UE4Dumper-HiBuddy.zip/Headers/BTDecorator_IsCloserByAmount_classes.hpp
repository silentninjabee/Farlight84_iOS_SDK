#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BTDecorator_IsCloserByAmount.BTDecorator_IsCloserByAmount_C
// Inherited Bytes: 0x98 | Struct Size: 0x114
struct UBTDecorator_IsCloserByAmount_C : UBTDecorator_BlueprintBase {
	// Fields
	struct FBlackboardKeySelector StartPoint; // Offset: 0x98 | Size: 0x28
	struct FBlackboardKeySelector EndPointA; // Offset: 0xc0 | Size: 0x28
	struct FBlackboardKeySelector EndPointB; // Offset: 0xe8 | Size: 0x28
	float CloserByAmount; // Offset: 0x110 | Size: 0x4

	// Functions

	// Object: Function BTDecorator_IsCloserByAmount.BTDecorator_IsCloserByAmount_C.GetActorLocation2D
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x10213e738
	// Return & Params: [ Num(2) Size(0x30) ]
	void GetActorLocation2D(struct FBlackboardKeySelector ActorKey, struct FVector2D& Location2D);

	// Object: Function BTDecorator_IsCloserByAmount.BTDecorator_IsCloserByAmount_C.IsActorValid
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x10213e738
	// Return & Params: [ Num(2) Size(0x29) ]
	void IsActorValid(struct FBlackboardKeySelector ActorKey, bool& IsValid);

	// Object: Function BTDecorator_IsCloserByAmount.BTDecorator_IsCloserByAmount_C.PerformConditionCheckAI
	// Flags: [Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(3) Size(0x11) ]
	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn);
};

