#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BTDecorators_ActorEqual.BTDecorators_ActorEqual_C
// Inherited Bytes: 0x98 | Struct Size: 0xe8
struct UBTDecorators_ActorEqual_C : UBTDecorator_BlueprintBase {
	// Fields
	struct FBlackboardKeySelector NewVar_2; // Offset: 0x98 | Size: 0x28
	struct FBlackboardKeySelector NewVar_1; // Offset: 0xc0 | Size: 0x28

	// Functions

	// Object: Function BTDecorators_ActorEqual.BTDecorators_ActorEqual_C.PerformConditionCheckAI
	// Flags: [Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(3) Size(0x11) ]
	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn);
};

