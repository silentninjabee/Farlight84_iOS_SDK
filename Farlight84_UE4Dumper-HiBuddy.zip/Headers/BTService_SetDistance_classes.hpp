#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BTService_SetDistance.BTService_SetDistance_C
// Inherited Bytes: 0x90 | Struct Size: 0x110
struct UBTService_SetDistance_C : UBTService_BlueprintBase {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x90 | Size: 0x8
	struct FBlackboardKeySelector Source; // Offset: 0x98 | Size: 0x28
	struct FBlackboardKeySelector Target; // Offset: 0xc0 | Size: 0x28
	struct FBlackboardKeySelector ResultDistanceFromSourceToTarget; // Offset: 0xe8 | Size: 0x28

	// Functions

	// Object: Function BTService_SetDistance.BTService_SetDistance_C.ReceiveTickAI
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(3) Size(0x14) ]
	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds);

	// Object: Function BTService_SetDistance.BTService_SetDistance_C.ExecuteUbergraph_BTService_SetDistance
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x10213e738
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_BTService_SetDistance(int32_t EntryPoint);
};

