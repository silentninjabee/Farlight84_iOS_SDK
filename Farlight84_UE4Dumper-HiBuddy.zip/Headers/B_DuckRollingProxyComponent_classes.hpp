#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass B_DuckRollingProxyComponent.B_DuckRollingProxyComponent_C
// Inherited Bytes: 0x260 | Struct Size: 0x260
struct UB_DuckRollingProxyComponent_C : UDuckRollingProxyComponent {
};

