#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BattlegroundControlPoint.BattlegroundControlPoint_C
// Inherited Bytes: 0x2a8 | Struct Size: 0x4f2
struct ABattlegroundControlPoint_C : ABattlegroundControlPoint {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x2a8 | Size: 0x8
	struct UStaticMeshComponent* FX_BG_HoldAreaEdge; // Offset: 0x2b0 | Size: 0x8
	struct UStaticMeshComponent* FX_BG_HoldAreaCube; // Offset: 0x2b8 | Size: 0x8
	struct UParticleSystemComponent* FX_BG_CenterSparks; // Offset: 0x2c0 | Size: 0x8
	struct UStaticMeshComponent* FX_BG_CenterGround; // Offset: 0x2c8 | Size: 0x8
	struct UStaticMeshComponent* FX_BG_CenterSignalLine; // Offset: 0x2d0 | Size: 0x8
	struct UStaticMeshComponent* FX_BG_CenterSignalGlow; // Offset: 0x2d8 | Size: 0x8
	struct UBoxComponent* Box; // Offset: 0x2e0 | Size: 0x8
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x2e8 | Size: 0x8
	struct UMaterialInstanceDynamic* CenterSignalGlowMI; // Offset: 0x2f0 | Size: 0x8
	struct UMaterialInstanceDynamic* CenterSignalLineMI; // Offset: 0x2f8 | Size: 0x8
	struct UMaterialInstanceDynamic* HoldAreaCubeMI; // Offset: 0x300 | Size: 0x8
	struct UMaterialInstanceDynamic* HoldAreaEdgeMI; // Offset: 0x308 | Size: 0x8
	struct TMap<enum class EControlPointStatus, struct FLinearColor> CenterSignalGlowColors; // Offset: 0x310 | Size: 0x50
	struct TMap<enum class EControlPointStatus, struct FLinearColor> CenterSignalLineColors; // Offset: 0x360 | Size: 0x50
	struct TMap<enum class EControlPointStatus, struct FLinearColor> HoldAreaCubeColors_Dark; // Offset: 0x3b0 | Size: 0x50
	struct TMap<enum class EControlPointStatus, struct FLinearColor> HoldAreaCubeColors_Bright; // Offset: 0x400 | Size: 0x50
	struct TMap<enum class EControlPointStatus, struct FLinearColor> HoldAreaEdgeColors_Dark; // Offset: 0x450 | Size: 0x50
	struct TMap<enum class EControlPointStatus, struct FLinearColor> HoldAreaEdgeColors_Bright; // Offset: 0x4a0 | Size: 0x50
	enum class EControlPointStatus CurOccupiedFactionStatus; // Offset: 0x4f0 | Size: 0x1
	bool bOccupying; // Offset: 0x4f1 | Size: 0x1

	// Functions

	// Object: Function BattlegroundControlPoint.BattlegroundControlPoint_C.GetOccupying
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x10213e738
	// Return & Params: [ Num(1) Size(0x1) ]
	void GetOccupying(bool& NewOccupying);

	// Object: Function BattlegroundControlPoint.BattlegroundControlPoint_C.GetStatus
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x10213e738
	// Return & Params: [ Num(2) Size(0x2) ]
	void GetStatus(enum class EFactionType InFaction, enum class EControlPointStatus& OutStatus);

	// Object: Function BattlegroundControlPoint.BattlegroundControlPoint_C.OnOccupiedChanged
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnOccupiedChanged();

	// Object: Function BattlegroundControlPoint.BattlegroundControlPoint_C.OnOccupyingChanged
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnOccupyingChanged();

	// Object: Function BattlegroundControlPoint.BattlegroundControlPoint_C.ReceiveBeginPlay
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(0) Size(0x0) ]
	void ReceiveBeginPlay();

	// Object: Function BattlegroundControlPoint.BattlegroundControlPoint_C.K2_OnOccupiedFactionChanged
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(0) Size(0x0) ]
	void K2_OnOccupiedFactionChanged();

	// Object: Function BattlegroundControlPoint.BattlegroundControlPoint_C.K2_OnCharactersInsideChanged
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(0) Size(0x0) ]
	void K2_OnCharactersInsideChanged();

	// Object: Function BattlegroundControlPoint.BattlegroundControlPoint_C.K2_OnProgressOwnerFactionChanged
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(0) Size(0x0) ]
	void K2_OnProgressOwnerFactionChanged();

	// Object: Function BattlegroundControlPoint.BattlegroundControlPoint_C.K2_OnProgressStatusChanged
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(0) Size(0x0) ]
	void K2_OnProgressStatusChanged();

	// Object: Function BattlegroundControlPoint.BattlegroundControlPoint_C.ExecuteUbergraph_BattlegroundControlPoint
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x10213e738
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_BattlegroundControlPoint(int32_t EntryPoint);
};

