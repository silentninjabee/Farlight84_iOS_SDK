#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass CFG_BattleRoyale.CFG_BattleRoyale_C
// Inherited Bytes: 0x720 | Struct Size: 0x954
struct UCFG_BattleRoyale_C : UCFG_Framework_C {
	// Fields
	int32_t ; // Offset: 0x720 | Size: 0x4
	int32_t ; // Offset: 0x724 | Size: 0x4
	int32_t ; // Offset: 0x728 | Size: 0x4
	char pad_0x72C[0x4]; // Offset: 0x72c | Size: 0x4
	struct TSoftObjectPtr<UBehaviorTree> ; // Offset: 0x730 | Size: 0x28
	struct TSoftObjectPtr<UBehaviorTree> ; // Offset: 0x758 | Size: 0x28
	struct TSoftObjectPtr<UBehaviorTree> ; // Offset: 0x780 | Size: 0x28
	int32_t ; // Offset: 0x7a8 | Size: 0x4
	char pad_0x7AC[0x4]; // Offset: 0x7ac | Size: 0x4
	struct UDataTable* ; // Offset: 0x7b0 | Size: 0x8
	int32_t ; // Offset: 0x7b8 | Size: 0x4
	char pad_0x7BC[0x4]; // Offset: 0x7bc | Size: 0x4
	struct TSoftClassPtr<UObject> AIController; // Offset: 0x7c0 | Size: 0x28
	bool ; // Offset: 0x7e8 | Size: 0x1
	char pad_0x7E9[0x3]; // Offset: 0x7e9 | Size: 0x3
	float ; // Offset: 0x7ec | Size: 0x4
	float ; // Offset: 0x7f0 | Size: 0x4
	int32_t ; // Offset: 0x7f4 | Size: 0x4
	int32_t ; // Offset: 0x7f8 | Size: 0x4
	int32_t ; // Offset: 0x7fc | Size: 0x4
	int32_t ; // Offset: 0x800 | Size: 0x4
	char pad_0x804[0x4]; // Offset: 0x804 | Size: 0x4
	struct UDataTable* ; // Offset: 0x808 | Size: 0x8
	int32_t ; // Offset: 0x810 | Size: 0x4
	struct FInt32Range ; // Offset: 0x814 | Size: 0x10
	struct FInt32Range ; // Offset: 0x824 | Size: 0x10
	float ; // Offset: 0x834 | Size: 0x4
	struct FS_SkillState ; // Offset: 0x838 | Size: 0x4
	struct FS_SkillState ; // Offset: 0x83c | Size: 0x4
	struct TMap<int32_t, int32_t> ; // Offset: 0x840 | Size: 0x50
	struct TMap<int32_t, int32_t> ; // Offset: 0x890 | Size: 0x50
	struct FS_SkillState ; // Offset: 0x8e0 | Size: 0x4
	struct FS_SkillState ; // Offset: 0x8e4 | Size: 0x4
	bool ; // Offset: 0x8e8 | Size: 0x1
	struct FS_SkillState ; // Offset: 0x8e9 | Size: 0x4
	char pad_0x8ED[0x3]; // Offset: 0x8ed | Size: 0x3
	int32_t TopVictoryTeamRank; // Offset: 0x8f0 | Size: 0x4
	int32_t MaxBattleCountDown; // Offset: 0x8f4 | Size: 0x4
	bool ; // Offset: 0x8f8 | Size: 0x1
	bool ; // Offset: 0x8f9 | Size: 0x1
	char pad_0x8FA[0x6]; // Offset: 0x8fa | Size: 0x6
	struct TMap<int32_t, struct FString> ; // Offset: 0x900 | Size: 0x50
	int32_t ; // Offset: 0x950 | Size: 0x4

	// Functions

	// Object: Function CFG_BattleRoyale.CFG_BattleRoyale_C.GetSkillStateByNameEnum
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x10213e738
	// Return & Params: [ Num(2) Size(0x5) ]
	void GetSkillStateByNameEnum(enum class ESkillStateNameEnum Enum, struct FS_SkillState& Out);
};

