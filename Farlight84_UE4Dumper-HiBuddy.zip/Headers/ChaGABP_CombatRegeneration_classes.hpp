#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGABP_CombatRegeneration.ChaGABP_CombatRegeneration_C
// Inherited Bytes: 0x560 | Struct Size: 0x560
struct UChaGABP_CombatRegeneration_C : UChaGA_CombatRegeneration {
};

