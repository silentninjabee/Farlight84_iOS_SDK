#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGABP_DeathVergeRecover.ChaGABP_DeathVergeRecover_C
// Inherited Bytes: 0x558 | Struct Size: 0x558
struct UChaGABP_DeathVergeRecover_C : UChaGA_RecoverAction {
};

