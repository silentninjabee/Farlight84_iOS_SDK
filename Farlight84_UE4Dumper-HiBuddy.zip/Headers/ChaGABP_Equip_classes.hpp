#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGABP_Equip.ChaGABP_Equip_C
// Inherited Bytes: 0x580 | Struct Size: 0x580
struct UChaGABP_Equip_C : UChaGA_Equip {
};

