#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGABP_HitRecoverPredict.ChaGABP_HitRecoverPredict_C
// Inherited Bytes: 0x590 | Struct Size: 0x590
struct UChaGABP_HitRecoverPredict_C : UChaGABP_HitRecover_C {
};

