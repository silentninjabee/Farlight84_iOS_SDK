#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGABP_InitializationFromGameMode.ChaGABP_InitializationFromGameMode_C
// Inherited Bytes: 0x540 | Struct Size: 0x540
struct UChaGABP_InitializationFromGameMode_C : UChaGA_InitializationFromGameMode {
};

