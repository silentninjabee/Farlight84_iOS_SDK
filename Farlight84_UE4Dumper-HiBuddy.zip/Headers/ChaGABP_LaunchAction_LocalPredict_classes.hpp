#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGABP_LaunchAction_LocalPredict.ChaGABP_LaunchAction_LocalPredict_C
// Inherited Bytes: 0x548 | Struct Size: 0x548
struct UChaGABP_LaunchAction_LocalPredict_C : UChaGA_LocalPredictLaunchAction {
};

