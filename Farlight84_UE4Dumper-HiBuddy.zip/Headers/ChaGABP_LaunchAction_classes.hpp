#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGABP_LaunchAction.ChaGABP_LaunchAction_C
// Inherited Bytes: 0x538 | Struct Size: 0x538
struct UChaGABP_LaunchAction_C : UChaGA_LaunchAction {
};

