#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGABP_Melee.ChaGABP_Melee_C
// Inherited Bytes: 0x608 | Struct Size: 0x608
struct UChaGABP_Melee_C : UChaGA_Melee {
};

