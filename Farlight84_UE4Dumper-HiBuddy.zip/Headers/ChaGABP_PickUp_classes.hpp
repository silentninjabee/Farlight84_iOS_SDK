#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGABP_PickUp.ChaGABP_PickUp_C
// Inherited Bytes: 0x588 | Struct Size: 0x588
struct UChaGABP_PickUp_C : UChaGA_PickUp {
};

