#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGABP_PokeBallProjectile.ChaGABP_PokeBallProjectile_C
// Inherited Bytes: 0x750 | Struct Size: 0x750
struct UChaGABP_PokeBallProjectile_C : USolarSkillGA_BuddyBall {
};

