#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGABP_Rebirth.ChaGABP_Rebirth_C
// Inherited Bytes: 0x538 | Struct Size: 0x538
struct UChaGABP_Rebirth_C : UChaGA_Rebirth {
};

