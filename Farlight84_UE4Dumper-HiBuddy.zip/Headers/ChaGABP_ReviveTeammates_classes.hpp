#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGABP_ReviveTeammates.ChaGABP_ReviveTeammates_C
// Inherited Bytes: 0x540 | Struct Size: 0x548
struct UChaGABP_ReviveTeammates_C : UChaGA_ReviveTeammates {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x540 | Size: 0x8

	// Functions

	// Object: Function ChaGABP_ReviveTeammates.ChaGABP_ReviveTeammates_C.OnAbilityExec
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnAbilityExec();

	// Object: Function ChaGABP_ReviveTeammates.ChaGABP_ReviveTeammates_C.K2_OnEndAbility
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(1) Size(0x1) ]
	void K2_OnEndAbility(bool bWasCancelled);

	// Object: Function ChaGABP_ReviveTeammates.ChaGABP_ReviveTeammates_C.ExecuteUbergraph_ChaGABP_ReviveTeammates
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x10213e738
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_ChaGABP_ReviveTeammates(int32_t EntryPoint);
};

