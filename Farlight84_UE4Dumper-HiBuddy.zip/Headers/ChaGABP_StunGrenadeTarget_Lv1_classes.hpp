#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGABP_StunGrenadeTarget_Lv1.ChaGABP_StunGrenadeTarget_Lv1_C
// Inherited Bytes: 0x5c0 | Struct Size: 0x5c0
struct UChaGABP_StunGrenadeTarget_Lv1_C : UChaGA_StunGrenadeTarget {
};

