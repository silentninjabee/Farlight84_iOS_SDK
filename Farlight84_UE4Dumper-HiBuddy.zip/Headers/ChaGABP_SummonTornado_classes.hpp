#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGABP_SummonTornado.ChaGABP_SummonTornado_C
// Inherited Bytes: 0x5d8 | Struct Size: 0x5d8
struct UChaGABP_SummonTornado_C : UPokeGA_SummonBase {
};

