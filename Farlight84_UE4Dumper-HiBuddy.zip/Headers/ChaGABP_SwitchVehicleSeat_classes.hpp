#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGABP_SwitchVehicleSeat.ChaGABP_SwitchVehicleSeat_C
// Inherited Bytes: 0x528 | Struct Size: 0x528
struct UChaGABP_SwitchVehicleSeat_C : UChaGA_SwitchVehicleSeat {
};

