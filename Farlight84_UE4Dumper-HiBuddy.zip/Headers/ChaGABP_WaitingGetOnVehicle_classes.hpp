#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGABP_WaitingGetOnVehicle.ChaGABP_WaitingGetOnVehicle_C
// Inherited Bytes: 0x528 | Struct Size: 0x528
struct UChaGABP_WaitingGetOnVehicle_C : UChaGA_WaitingGetOnVehicle {
};

