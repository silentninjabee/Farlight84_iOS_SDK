#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGA_ActivateExpSpring.ChaGA_ActivateExpSpring_C
// Inherited Bytes: 0x560 | Struct Size: 0x560
struct UChaGA_ActivateExpSpring_C : USolarExpSpringActivePointAbility {
};

