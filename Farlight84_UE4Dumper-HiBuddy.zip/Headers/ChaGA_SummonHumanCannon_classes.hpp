#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGA_SummonHumanCannon.ChaGA_SummonHumanCannon_C
// Inherited Bytes: 0x5d8 | Struct Size: 0x5d8
struct UChaGA_SummonHumanCannon_C : UPokeGA_SummonBase {
};

