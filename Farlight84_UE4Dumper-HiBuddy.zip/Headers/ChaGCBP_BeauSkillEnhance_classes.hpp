#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGCBP_BeauSkillEnhance.ChaGCBP_BeauSkillEnhance_C
// Inherited Bytes: 0x60 | Struct Size: 0x60
struct UChaGCBP_BeauSkillEnhance_C : UChaGC_CharacterStaticCueBase {
};

