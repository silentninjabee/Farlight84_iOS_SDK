#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGCBP_BlindMark_SlowDown.ChaGCBP_BlindMark_SlowDown_C
// Inherited Bytes: 0x428 | Struct Size: 0x430
struct AChaGCBP_BlindMark_SlowDown_C : AChaGC_BlindMarkSlowDown {
	// Fields
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x428 | Size: 0x8
};

