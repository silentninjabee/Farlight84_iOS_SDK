#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGCBP_BlindMark.ChaGCBP_BlindMark_C
// Inherited Bytes: 0x410 | Struct Size: 0x418
struct AChaGCBP_BlindMark_C : AChaGC_BlindMark {
	// Fields
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x410 | Size: 0x8
};

