#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGCBP_DunkWarning.ChaGCBP_DunkWarning_C
// Inherited Bytes: 0x328 | Struct Size: 0x33c
struct AChaGCBP_DunkWarning_C : AChaGC_WarningArea {
	// Fields
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x328 | Size: 0x8
	struct FVector NewVar_1; // Offset: 0x330 | Size: 0xc
};

