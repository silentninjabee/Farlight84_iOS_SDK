#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGCBP_ExpSpring_AddExp.ChaGCBP_ExpSpring_AddExp_C
// Inherited Bytes: 0x3a0 | Struct Size: 0x3a8
struct AChaGCBP_ExpSpring_AddExp_C : AChaGC_CharacterActorCueBase {
	// Fields
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x3a0 | Size: 0x8
};

