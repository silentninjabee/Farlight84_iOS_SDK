#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGCBP_InDragonRealmBuff.ChaGCBP_InDragonRealmBuff_C
// Inherited Bytes: 0x60 | Struct Size: 0x60
struct UChaGCBP_InDragonRealmBuff_C : UChaGC_CharacterStaticCueBase {
};

