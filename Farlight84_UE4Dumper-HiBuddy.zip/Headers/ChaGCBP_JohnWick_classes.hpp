#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGCBP_JohnWick.ChaGCBP_JohnWick_C
// Inherited Bytes: 0x3e8 | Struct Size: 0x3f0
struct AChaGCBP_JohnWick_C : AChaGC_JohnWick {
	// Fields
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x3e8 | Size: 0x8
};

