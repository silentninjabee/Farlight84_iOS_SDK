#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGCBP_MeleeAttack.ChaGCBP_MeleeAttack_C
// Inherited Bytes: 0x50 | Struct Size: 0x50
struct UChaGCBP_MeleeAttack_C : UGameplayCueNotify_Static {
	// Functions

	// Object: Function ChaGCBP_MeleeAttack.ChaGCBP_MeleeAttack_C.PlayAdditiveHitAnim
	// Flags: [Public|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x10213e738
	// Return & Params: [ Num(2) Size(0x14) ]
	void PlayAdditiveHitAnim(struct ASolarCharacter* InCharater, struct FVector InHitLocation);

	// Object: Function ChaGCBP_MeleeAttack.ChaGCBP_MeleeAttack_C.OnExecute
	// Flags: [Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const]
	// Offset: 0x10213e738
	// Return & Params: [ Num(3) Size(0xd9) ]
	bool OnExecute(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters);
};

