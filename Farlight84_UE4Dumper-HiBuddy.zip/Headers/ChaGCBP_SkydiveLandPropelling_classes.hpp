#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGCBP_SkydiveLandPropelling.ChaGCBP_SkydiveLandPropelling_C
// Inherited Bytes: 0x78 | Struct Size: 0x78
struct UChaGCBP_SkydiveLandPropelling_C : UChaGC_BackpackPropelling {
};

