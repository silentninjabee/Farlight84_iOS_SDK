#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGCBP_TornadoCandidate.ChaGCBP_TornadoCandidate_C
// Inherited Bytes: 0x70 | Struct Size: 0x70
struct UChaGCBP_TornadoCandidate_C : UChaGC_InTornado {
};

