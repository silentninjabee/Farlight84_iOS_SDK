#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGC_HoldStunGrenade.ChaGC_HoldStunGrenade_C
// Inherited Bytes: 0x60 | Struct Size: 0x60
struct UChaGC_HoldStunGrenade_C : UChaGC_CharacterStaticCueBase {
};

