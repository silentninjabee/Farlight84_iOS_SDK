#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGEBP_HasAnyFireInputEffect.ChaGEBP_HasAnyFireInputEffect_C
// Inherited Bytes: 0x898 | Struct Size: 0x898
struct UChaGEBP_HasAnyFireInputEffect_C : UGameplayEffect {
};

