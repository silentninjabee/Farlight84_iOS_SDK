#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGEBP_InhibitGetOnZipline.ChaGEBP_InhibitGetOnZipline_C
// Inherited Bytes: 0x898 | Struct Size: 0x898
struct UChaGEBP_InhibitGetOnZipline_C : UGameplayEffect {
};

