#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGEBP_SkydiveFalling.ChaGEBP_SkydiveFalling_C
// Inherited Bytes: 0x898 | Struct Size: 0x898
struct UChaGEBP_SkydiveFalling_C : UGameplayEffect {
};

