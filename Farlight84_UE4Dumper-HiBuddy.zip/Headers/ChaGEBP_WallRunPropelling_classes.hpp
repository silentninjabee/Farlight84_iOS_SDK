#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGEBP_WallRunPropelling.ChaGEBP_WallRunPropelling_C
// Inherited Bytes: 0x898 | Struct Size: 0x898
struct UChaGEBP_WallRunPropelling_C : UGameplayEffect {
};

