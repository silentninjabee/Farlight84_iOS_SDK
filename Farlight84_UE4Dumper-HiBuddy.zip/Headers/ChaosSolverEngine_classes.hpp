#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class ChaosSolverEngine.ChaosDebugDrawComponent
// Inherited Bytes: 0xc0 | Struct Size: 0xc8
struct UChaosDebugDrawComponent : UActorComponent {
	// Fields
	char pad_0xC0[0x8]; // Offset: 0xc0 | Size: 0x8
};

// Object: Class ChaosSolverEngine.ChaosEventListenerComponent
// Inherited Bytes: 0xc0 | Struct Size: 0xc8
struct UChaosEventListenerComponent : UActorComponent {
	// Fields
	char pad_0xC0[0x8]; // Offset: 0xc0 | Size: 0x8
};

// Object: Class ChaosSolverEngine.ChaosGameplayEventDispatcher
// Inherited Bytes: 0xc8 | Struct Size: 0x280
struct UChaosGameplayEventDispatcher : UChaosEventListenerComponent {
	// Fields
	char pad_0xC8[0x110]; // Offset: 0xc8 | Size: 0x110
	struct TMap<struct UPrimitiveComponent*, struct FChaosHandlerSet> CollisionEventRegistrations; // Offset: 0x1d8 | Size: 0x50
	struct TMap<struct UPrimitiveComponent*, struct FBreakEventCallbackWrapper> BreakEventRegistrations; // Offset: 0x228 | Size: 0x50
	char pad_0x278[0x8]; // Offset: 0x278 | Size: 0x8
};

// Object: Class ChaosSolverEngine.ChaosNotifyHandlerInterface
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UChaosNotifyHandlerInterface : UInterface {
};

// Object: Class ChaosSolverEngine.ChaosSolverEngineBlueprintLibrary
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UChaosSolverEngineBlueprintLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object: Function ChaosSolverEngine.ChaosSolverEngineBlueprintLibrary.ConvertPhysicsCollisionToHitResult
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x105c42358
	// Return & Params: [ Num(2) Size(0xf8) ]
	struct FHitResult ConvertPhysicsCollisionToHitResult(struct FChaosPhysicsCollisionInfo& PhysicsCollision);
};

// Object: Class ChaosSolverEngine.ChaosSolver
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UChaosSolver : UObject {
};

// Object: Class ChaosSolverEngine.ChaosSolverActor
// Inherited Bytes: 0x248 | Struct Size: 0x2d0
struct AChaosSolverActor : AActor {
	// Fields
	float TimeStepMultiplier; // Offset: 0x248 | Size: 0x4
	int32_t CollisionIterations; // Offset: 0x24c | Size: 0x4
	int32_t PushOutIterations; // Offset: 0x250 | Size: 0x4
	int32_t PushOutPairIterations; // Offset: 0x254 | Size: 0x4
	float ClusterConnectionFactor; // Offset: 0x258 | Size: 0x4
	enum class EClusterConnectionTypeEnum ClusterUnionConnectionType; // Offset: 0x25c | Size: 0x1
	bool DoGenerateCollisionData; // Offset: 0x25d | Size: 0x1
	char pad_0x25E[0x2]; // Offset: 0x25e | Size: 0x2
	struct FSolverCollisionFilterSettings CollisionFilterSettings; // Offset: 0x260 | Size: 0x10
	bool DoGenerateBreakingData; // Offset: 0x270 | Size: 0x1
	char pad_0x271[0x3]; // Offset: 0x271 | Size: 0x3
	struct FSolverBreakingFilterSettings BreakingFilterSettings; // Offset: 0x274 | Size: 0x10
	bool DoGenerateTrailingData; // Offset: 0x284 | Size: 0x1
	char pad_0x285[0x3]; // Offset: 0x285 | Size: 0x3
	struct FSolverTrailingFilterSettings TrailingFilterSettings; // Offset: 0x288 | Size: 0x10
	bool bHasFloor; // Offset: 0x298 | Size: 0x1
	char pad_0x299[0x3]; // Offset: 0x299 | Size: 0x3
	float FloorHeight; // Offset: 0x29c | Size: 0x4
	float MassScale; // Offset: 0x2a0 | Size: 0x4
	bool bGenerateContactGraph; // Offset: 0x2a4 | Size: 0x1
	struct FChaosDebugSubstepControl ChaosDebugSubstepControl; // Offset: 0x2a5 | Size: 0x3
	struct UBillboardComponent* SpriteComponent; // Offset: 0x2a8 | Size: 0x8
	char pad_0x2B0[0x18]; // Offset: 0x2b0 | Size: 0x18
	struct UChaosGameplayEventDispatcher* GameplayEventDispatcherComponent; // Offset: 0x2c8 | Size: 0x8

	// Functions

	// Object: Function ChaosSolverEngine.ChaosSolverActor.SetSolverActive
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x105c425e0
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetSolverActive(bool bActive);

	// Object: Function ChaosSolverEngine.ChaosSolverActor.SetAsCurrentWorldSolver
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105c42664
	// Return & Params: [ Num(0) Size(0x0) ]
	void SetAsCurrentWorldSolver();
};

// Object: Class ChaosSolverEngine.ChaosSolverSettings
// Inherited Bytes: 0x38 | Struct Size: 0x58
struct UChaosSolverSettings : UDeveloperSettings {
	// Fields
	char pad_0x38[0x8]; // Offset: 0x38 | Size: 0x8
	struct FSoftClassPath DefaultChaosSolverActorClass; // Offset: 0x40 | Size: 0x18
};

