#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct ChaosSolvers.SolverBreakingFilterSettings
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FSolverBreakingFilterSettings {
	// Fields
	bool FilterEnabled; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	float MinMass; // Offset: 0x4 | Size: 0x4
	float MinSpeed; // Offset: 0x8 | Size: 0x4
	float MinVolume; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct ChaosSolvers.SolverCollisionFilterSettings
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FSolverCollisionFilterSettings {
	// Fields
	bool FilterEnabled; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	float MinMass; // Offset: 0x4 | Size: 0x4
	float MinSpeed; // Offset: 0x8 | Size: 0x4
	float MinImpulse; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct ChaosSolvers.SolverTrailingFilterSettings
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FSolverTrailingFilterSettings {
	// Fields
	bool FilterEnabled; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	float MinMass; // Offset: 0x4 | Size: 0x4
	float MinSpeed; // Offset: 0x8 | Size: 0x4
	float MinVolume; // Offset: 0xc | Size: 0x4
};

