#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct ClothingSystemRuntimeCommon.ClothConfig_Legacy
// Inherited Bytes: 0x0 | Struct Size: 0xd4
struct FClothConfig_Legacy {
	// Fields
	enum class EClothingWindMethod_Legacy WindMethod; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	struct FClothConstraintSetup_Legacy VerticalConstraintConfig; // Offset: 0x4 | Size: 0x10
	struct FClothConstraintSetup_Legacy HorizontalConstraintConfig; // Offset: 0x14 | Size: 0x10
	struct FClothConstraintSetup_Legacy BendConstraintConfig; // Offset: 0x24 | Size: 0x10
	struct FClothConstraintSetup_Legacy ShearConstraintConfig; // Offset: 0x34 | Size: 0x10
	float SelfCollisionRadius; // Offset: 0x44 | Size: 0x4
	float SelfCollisionStiffness; // Offset: 0x48 | Size: 0x4
	float SelfCollisionCullScale; // Offset: 0x4c | Size: 0x4
	struct FVector Damping; // Offset: 0x50 | Size: 0xc
	float Friction; // Offset: 0x5c | Size: 0x4
	float WindDragCoefficient; // Offset: 0x60 | Size: 0x4
	float WindLiftCoefficient; // Offset: 0x64 | Size: 0x4
	struct FVector LinearDrag; // Offset: 0x68 | Size: 0xc
	struct FVector AngularDrag; // Offset: 0x74 | Size: 0xc
	struct FVector LinearInertiaScale; // Offset: 0x80 | Size: 0xc
	struct FVector AngularInertiaScale; // Offset: 0x8c | Size: 0xc
	struct FVector CentrifugalInertiaScale; // Offset: 0x98 | Size: 0xc
	float SolverFrequency; // Offset: 0xa4 | Size: 0x4
	float StiffnessFrequency; // Offset: 0xa8 | Size: 0x4
	float GravityScale; // Offset: 0xac | Size: 0x4
	struct FVector GravityOverride; // Offset: 0xb0 | Size: 0xc
	bool bUseGravityOverride; // Offset: 0xbc | Size: 0x1
	char pad_0xBD[0x3]; // Offset: 0xbd | Size: 0x3
	float TetherStiffness; // Offset: 0xc0 | Size: 0x4
	float TetherLimit; // Offset: 0xc4 | Size: 0x4
	float CollisionThickness; // Offset: 0xc8 | Size: 0x4
	float AnimDriveSpringStiffness; // Offset: 0xcc | Size: 0x4
	float AnimDriveDamperStiffness; // Offset: 0xd0 | Size: 0x4
};

// Object: ScriptStruct ClothingSystemRuntimeCommon.ClothConstraintSetup_Legacy
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FClothConstraintSetup_Legacy {
	// Fields
	float Stiffness; // Offset: 0x0 | Size: 0x4
	float StiffnessMultiplier; // Offset: 0x4 | Size: 0x4
	float StretchLimit; // Offset: 0x8 | Size: 0x4
	float CompressionLimit; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct ClothingSystemRuntimeCommon.ClothLODDataCommon
// Inherited Bytes: 0x0 | Struct Size: 0x158
struct FClothLODDataCommon {
	// Fields
	struct FClothPhysicalMeshData PhysicalMeshData; // Offset: 0x0 | Size: 0xf8
	struct FClothCollisionData CollisionData; // Offset: 0xf8 | Size: 0x40
	char pad_0x138[0x20]; // Offset: 0x138 | Size: 0x20
};

// Object: ScriptStruct ClothingSystemRuntimeCommon.ClothPhysicalMeshData
// Inherited Bytes: 0x0 | Struct Size: 0xf8
struct FClothPhysicalMeshData {
	// Fields
	struct TArray<struct FVector> Vertices; // Offset: 0x0 | Size: 0x10
	struct TArray<struct FVector> Normals; // Offset: 0x10 | Size: 0x10
	struct TArray<uint32_t> Indices; // Offset: 0x20 | Size: 0x10
	struct TMap<uint32_t, struct FPointWeightMap> WeightMaps; // Offset: 0x30 | Size: 0x50
	struct TArray<float> InverseMasses; // Offset: 0x80 | Size: 0x10
	struct TArray<struct FClothVertBoneData> BoneData; // Offset: 0x90 | Size: 0x10
	int32_t MaxBoneWeights; // Offset: 0xa0 | Size: 0x4
	int32_t NumFixedVerts; // Offset: 0xa4 | Size: 0x4
	struct TArray<uint32_t> SelfCollisionIndices; // Offset: 0xa8 | Size: 0x10
	struct TArray<float> MaxDistances; // Offset: 0xb8 | Size: 0x10
	struct TArray<float> BackstopDistances; // Offset: 0xc8 | Size: 0x10
	struct TArray<float> BackstopRadiuses; // Offset: 0xd8 | Size: 0x10
	struct TArray<float> AnimDriveMultipliers; // Offset: 0xe8 | Size: 0x10
};

// Object: ScriptStruct ClothingSystemRuntimeCommon.PointWeightMap
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FPointWeightMap {
	// Fields
	struct TArray<float> Values; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct ClothingSystemRuntimeCommon.ClothParameterMask_Legacy
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FClothParameterMask_Legacy {
	// Fields
	struct FName MaskName; // Offset: 0x0 | Size: 0x8
	enum class EWeightMapTargetCommon CurrentTarget; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x3]; // Offset: 0x9 | Size: 0x3
	float MaxValue; // Offset: 0xc | Size: 0x4
	float MinValue; // Offset: 0x10 | Size: 0x4
	char pad_0x14[0x4]; // Offset: 0x14 | Size: 0x4
	struct TArray<float> Values; // Offset: 0x18 | Size: 0x10
	bool bEnabled; // Offset: 0x28 | Size: 0x1
	char pad_0x29[0x7]; // Offset: 0x29 | Size: 0x7
};

