#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Enum CommonUI.ECommonNumericType
enum class ECommonNumericType : uint8_t {
	Number = 0,
	Percentage = 1,
	Seconds = 2,
	Distance = 3,
	ECommonNumericType_MAX = 4
};

// Object: Enum CommonUI.ECommonInputMode
enum class ECommonInputMode : uint8_t {
	Menu = 0,
	Game = 1,
	All = 2,
	MAX = 3
};

// Object: Enum CommonUI.ERichTextInlineIconDisplayMode
enum class ERichTextInlineIconDisplayMode : uint8_t {
	IconOnly = 0,
	TextOnly = 1,
	IconAndText = 2,
	MAX = 3
};

// Object: Enum CommonUI.EInputActionState
enum class EInputActionState : uint8_t {
	Enabled = 0,
	Disabled = 1,
	Hidden = 2,
	HiddenAndDisabled = 3,
	EInputActionState_MAX = 4
};

// Object: Enum CommonUI.ETransitionCurve
enum class ETransitionCurve : uint8_t {
	Linear = 0,
	QuadIn = 1,
	QuadOut = 2,
	QuadInOut = 3,
	CubicIn = 4,
	CubicOut = 5,
	CubicInOut = 6,
	ETransitionCurve_MAX = 7
};

// Object: Enum CommonUI.ECommonSwitcherTransition
enum class ECommonSwitcherTransition : uint8_t {
	FadeOnly = 0,
	Horizontal = 1,
	Vertical = 2,
	Zoom = 3,
	ECommonSwitcherTransition_MAX = 4
};

