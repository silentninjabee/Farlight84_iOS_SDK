#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct ControlRig.AnimationHierarchy
// Inherited Bytes: 0x78 | Struct Size: 0x88
struct FAnimationHierarchy : FNodeHierarchyWithUserData {
	// Fields
	struct TArray<struct FConstraintNodeData> UserData; // Offset: 0x78 | Size: 0x10
};

// Object: ScriptStruct ControlRig.ConstraintNodeData
// Inherited Bytes: 0x0 | Struct Size: 0xb0
struct FConstraintNodeData {
	// Fields
	struct FTransform RelativeParent; // Offset: 0x0 | Size: 0x30
	struct FConstraintOffset ConstraintOffset; // Offset: 0x30 | Size: 0x60
	struct FName LinkedNode; // Offset: 0x90 | Size: 0x8
	struct TArray<struct FTransformConstraint> Constraints; // Offset: 0x98 | Size: 0x10
	char pad_0xA8[0x8]; // Offset: 0xa8 | Size: 0x8
};

// Object: ScriptStruct ControlRig.AnimNode_ControlRigBase
// Inherited Bytes: 0x58 | Struct Size: 0x170
struct FAnimNode_ControlRigBase : FAnimNode_CustomProperty {
	// Fields
	struct FPoseLink Source; // Offset: 0x58 | Size: 0x10
	struct TMap<struct FName, uint16_t> ControlRigBoneMapping; // Offset: 0x68 | Size: 0x50
	struct TMap<struct FName, uint16_t> ControlRigCurveMapping; // Offset: 0xb8 | Size: 0x50
	struct TMap<struct FName, uint16_t> InputToCurveMappingUIDs; // Offset: 0x108 | Size: 0x50
	struct TWeakObjectPtr<struct UNodeMappingContainer> NodeMappingContainer; // Offset: 0x158 | Size: 0x8
	struct FControlRigIOSettings InputSettings; // Offset: 0x160 | Size: 0x2
	struct FControlRigIOSettings OutputSettings; // Offset: 0x162 | Size: 0x2
	bool bExecute; // Offset: 0x164 | Size: 0x1
	char pad_0x165[0xb]; // Offset: 0x165 | Size: 0xb
};

// Object: ScriptStruct ControlRig.ControlRigIOSettings
// Inherited Bytes: 0x0 | Struct Size: 0x2
struct FControlRigIOSettings {
	// Fields
	bool bUpdatePose; // Offset: 0x0 | Size: 0x1
	bool bUpdateCurves; // Offset: 0x1 | Size: 0x1
};

// Object: ScriptStruct ControlRig.AnimNode_ControlRig
// Inherited Bytes: 0x170 | Struct Size: 0x360
struct FAnimNode_ControlRig : FAnimNode_ControlRigBase {
	// Fields
	struct UControlRig* ControlRigClass; // Offset: 0x170 | Size: 0x8
	struct UControlRig* ControlRig; // Offset: 0x178 | Size: 0x8
	float Alpha; // Offset: 0x180 | Size: 0x4
	enum class EAnimAlphaInputType AlphaInputType; // Offset: 0x184 | Size: 0x1
	char bAlphaBoolEnabled : 1; // Offset: 0x185 | Size: 0x1
	char pad_0x185_1 : 7; // Offset: 0x185 | Size: 0x1
	char pad_0x186[0x2]; // Offset: 0x186 | Size: 0x2
	struct FInputScaleBias AlphaScaleBias; // Offset: 0x188 | Size: 0x8
	struct FInputAlphaBoolBlend AlphaBoolBlend; // Offset: 0x190 | Size: 0x48
	struct FName AlphaCurveName; // Offset: 0x1d8 | Size: 0x8
	struct FInputScaleBiasClamp AlphaScaleBiasClamp; // Offset: 0x1e0 | Size: 0x30
	struct TMap<struct FName, struct FName> InputMapping; // Offset: 0x210 | Size: 0x50
	struct TMap<struct FName, struct FName> OutputMapping; // Offset: 0x260 | Size: 0x50
	char pad_0x2B0[0xb0]; // Offset: 0x2b0 | Size: 0xb0
};

// Object: ScriptStruct ControlRig.AnimNode_ControlRig_ExternalSource
// Inherited Bytes: 0x170 | Struct Size: 0x178
struct FAnimNode_ControlRig_ExternalSource : FAnimNode_ControlRigBase {
	// Fields
	struct TWeakObjectPtr<struct UControlRig> ControlRig; // Offset: 0x16c | Size: 0x8
};

// Object: ScriptStruct ControlRig.ControlRigBindingTemplate
// Inherited Bytes: 0xa8 | Struct Size: 0xa8
struct FControlRigBindingTemplate : FMovieSceneSpawnSectionTemplate {
};

// Object: ScriptStruct ControlRig.ControlRigComponentInstanceData
// Inherited Bytes: 0x58 | Struct Size: 0x60
struct FControlRigComponentInstanceData : FActorComponentInstanceData {
	// Fields
	struct UControlRig* AnimControlRig; // Offset: 0x58 | Size: 0x8
};

// Object: ScriptStruct ControlRig.ControlRigExecuteContext
// Inherited Bytes: 0x10 | Struct Size: 0x18
struct FControlRigExecuteContext : FRigVMExecuteContext {
	// Fields
	char pad_0x10[0x8]; // Offset: 0x10 | Size: 0x8
};

// Object: ScriptStruct ControlRig.ControlRigDrawContainer
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FControlRigDrawContainer {
	// Fields
	struct TArray<struct FControlRigDrawInstruction> Instructions; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct ControlRig.ControlRigDrawInstruction
// Inherited Bytes: 0x0 | Struct Size: 0x70
struct FControlRigDrawInstruction {
	// Fields
	struct FName Name; // Offset: 0x0 | Size: 0x8
	enum class EControlRigDrawSettings PrimitiveType; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x7]; // Offset: 0x9 | Size: 0x7
	struct TArray<struct FVector> Positions; // Offset: 0x10 | Size: 0x10
	struct FLinearColor Color; // Offset: 0x20 | Size: 0x10
	float Thickness; // Offset: 0x30 | Size: 0x4
	char pad_0x34[0xc]; // Offset: 0x34 | Size: 0xc
	struct FTransform Transform; // Offset: 0x40 | Size: 0x30
};

// Object: ScriptStruct ControlRig.ControlRigDrawInterface
// Inherited Bytes: 0x10 | Struct Size: 0x18
struct FControlRigDrawInterface : FControlRigDrawContainer {
	// Fields
	char pad_0x10[0x8]; // Offset: 0x10 | Size: 0x8
};

// Object: ScriptStruct ControlRig.ControlRigGizmoDefinition
// Inherited Bytes: 0x0 | Struct Size: 0x60
struct FControlRigGizmoDefinition {
	// Fields
	struct FName GizmoName; // Offset: 0x0 | Size: 0x8
	struct TSoftObjectPtr<UStaticMesh> StaticMesh; // Offset: 0x8 | Size: 0x28
	struct FTransform Transform; // Offset: 0x30 | Size: 0x30
};

// Object: ScriptStruct ControlRig.ControlRigLayerInstanceProxy
// Inherited Bytes: 0x6f0 | Struct Size: 0x790
struct FControlRigLayerInstanceProxy : FAnimInstanceProxy {
	// Fields
	char pad_0x6F0[0xa0]; // Offset: 0x6f0 | Size: 0xa0
};

// Object: ScriptStruct ControlRig.AnimNode_ControlRigInputPose
// Inherited Bytes: 0x10 | Struct Size: 0x30
struct FAnimNode_ControlRigInputPose : FAnimNode_Base {
	// Fields
	struct FPoseLink InputPose; // Offset: 0x10 | Size: 0x10
	char pad_0x20[0x10]; // Offset: 0x20 | Size: 0x10
};

// Object: ScriptStruct ControlRig.CRFourPointBezier
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FCRFourPointBezier {
	// Fields
	struct FVector A; // Offset: 0x0 | Size: 0xc
	struct FVector B; // Offset: 0xc | Size: 0xc
	struct FVector C; // Offset: 0x18 | Size: 0xc
	struct FVector D; // Offset: 0x24 | Size: 0xc
};

// Object: ScriptStruct ControlRig.ControlRigSequenceObjectReferenceMap
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FControlRigSequenceObjectReferenceMap {
	// Fields
	struct TArray<struct FGuid> BindingIds; // Offset: 0x0 | Size: 0x10
	struct TArray<struct FControlRigSequenceObjectReferences> References; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct ControlRig.ControlRigSequenceObjectReferences
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FControlRigSequenceObjectReferences {
	// Fields
	struct TArray<struct FControlRigSequenceObjectReference> Array; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct ControlRig.ControlRigSequenceObjectReference
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FControlRigSequenceObjectReference {
	// Fields
	struct UControlRig* ControlRigClass; // Offset: 0x0 | Size: 0x8
};

// Object: ScriptStruct ControlRig.ControlRigSequencerAnimInstanceProxy
// Inherited Bytes: 0x940 | Struct Size: 0xc00
struct FControlRigSequencerAnimInstanceProxy : FAnimSequencerInstanceProxy {
	// Fields
	char pad_0x940[0x2c0]; // Offset: 0x940 | Size: 0x2c0
};

// Object: ScriptStruct ControlRig.CRSimContainer
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FCRSimContainer {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
	float TimeStep; // Offset: 0x8 | Size: 0x4
	float AccumulatedTime; // Offset: 0xc | Size: 0x4
	float TimeLeftForStep; // Offset: 0x10 | Size: 0x4
	char pad_0x14[0x4]; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct ControlRig.CRSimLinearSpring
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FCRSimLinearSpring {
	// Fields
	int32_t SubjectA; // Offset: 0x0 | Size: 0x4
	int32_t SubjectB; // Offset: 0x4 | Size: 0x4
	float Coefficient; // Offset: 0x8 | Size: 0x4
	float Equilibrium; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct ControlRig.CRSimPoint
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FCRSimPoint {
	// Fields
	float Mass; // Offset: 0x0 | Size: 0x4
	float Size; // Offset: 0x4 | Size: 0x4
	float LinearDamping; // Offset: 0x8 | Size: 0x4
	float InheritMotion; // Offset: 0xc | Size: 0x4
	struct FVector Position; // Offset: 0x10 | Size: 0xc
	struct FVector LinearVelocity; // Offset: 0x1c | Size: 0xc
};

// Object: ScriptStruct ControlRig.CRSimPointConstraint
// Inherited Bytes: 0x0 | Struct Size: 0x24
struct FCRSimPointConstraint {
	// Fields
	enum class ECRSimConstraintType Type; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	int32_t SubjectA; // Offset: 0x4 | Size: 0x4
	int32_t SubjectB; // Offset: 0x8 | Size: 0x4
	struct FVector DataA; // Offset: 0xc | Size: 0xc
	struct FVector DataB; // Offset: 0x18 | Size: 0xc
};

// Object: ScriptStruct ControlRig.CRSimPointContainer
// Inherited Bytes: 0x18 | Struct Size: 0x78
struct FCRSimPointContainer : FCRSimContainer {
	// Fields
	struct TArray<struct FCRSimPoint> Points; // Offset: 0x18 | Size: 0x10
	struct TArray<struct FCRSimLinearSpring> Springs; // Offset: 0x28 | Size: 0x10
	struct TArray<struct FCRSimPointForce> Forces; // Offset: 0x38 | Size: 0x10
	struct TArray<struct FCRSimSoftCollision> CollisionVolumes; // Offset: 0x48 | Size: 0x10
	struct TArray<struct FCRSimPointConstraint> Constraints; // Offset: 0x58 | Size: 0x10
	struct TArray<struct FCRSimPoint> PreviousStep; // Offset: 0x68 | Size: 0x10
};

// Object: ScriptStruct ControlRig.CRSimSoftCollision
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FCRSimSoftCollision {
	// Fields
	struct FTransform Transform; // Offset: 0x0 | Size: 0x30
	enum class ECRSimSoftCollisionType ShapeType; // Offset: 0x30 | Size: 0x1
	char pad_0x31[0x3]; // Offset: 0x31 | Size: 0x3
	float MinimumDistance; // Offset: 0x34 | Size: 0x4
	float MaximumDistance; // Offset: 0x38 | Size: 0x4
	enum class EControlRigAnimEasingType FalloffType; // Offset: 0x3c | Size: 0x1
	char pad_0x3D[0x3]; // Offset: 0x3d | Size: 0x3
	float Coefficient; // Offset: 0x40 | Size: 0x4
	bool bInverted; // Offset: 0x44 | Size: 0x1
	char pad_0x45[0xb]; // Offset: 0x45 | Size: 0xb
};

// Object: ScriptStruct ControlRig.CRSimPointForce
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FCRSimPointForce {
	// Fields
	enum class ECRSimPointForceType ForceType; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	struct FVector Vector; // Offset: 0x4 | Size: 0xc
	float Coefficient; // Offset: 0x10 | Size: 0x4
	bool bNormalize; // Offset: 0x14 | Size: 0x1
	char pad_0x15[0x3]; // Offset: 0x15 | Size: 0x3
};

// Object: ScriptStruct ControlRig.MovieSceneControlRigInstanceData
// Inherited Bytes: 0x8 | Struct Size: 0xd8
struct FMovieSceneControlRigInstanceData : FMovieSceneSequenceInstanceData {
	// Fields
	bool bAdditive; // Offset: 0x8 | Size: 0x1
	bool bApplyBoneFilter; // Offset: 0x9 | Size: 0x1
	char pad_0xA[0x6]; // Offset: 0xa | Size: 0x6
	struct FInputBlendPose BoneFilter; // Offset: 0x10 | Size: 0x10
	struct FMovieSceneFloatChannel Weight; // Offset: 0x20 | Size: 0xa0
	struct FMovieSceneEvaluationOperand Operand; // Offset: 0xc0 | Size: 0x14
	char pad_0xD4[0x4]; // Offset: 0xd4 | Size: 0x4
};

// Object: ScriptStruct ControlRig.ChannelMapInfo
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FChannelMapInfo {
	// Fields
	int32_t ControlIndex; // Offset: 0x0 | Size: 0x4
	int32_t ChannelIndex; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct ControlRig.MovieSceneControlRigParameterTemplate
// Inherited Bytes: 0x78 | Struct Size: 0x78
struct FMovieSceneControlRigParameterTemplate : FMovieSceneParameterSectionTemplate {
};

// Object: ScriptStruct ControlRig.RigBoneHierarchy
// Inherited Bytes: 0x0 | Struct Size: 0x70
struct FRigBoneHierarchy {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
	struct TArray<struct FRigBone> Bones; // Offset: 0x8 | Size: 0x10
	struct TMap<struct FName, int32_t> NameToIndexMapping; // Offset: 0x18 | Size: 0x50
	char pad_0x68[0x8]; // Offset: 0x68 | Size: 0x8
};

// Object: ScriptStruct ControlRig.RigElement
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FRigElement {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
	struct FName Name; // Offset: 0x8 | Size: 0x8
	int32_t Index; // Offset: 0x10 | Size: 0x4
	char pad_0x14[0x4]; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigBone
// Inherited Bytes: 0x18 | Struct Size: 0xd0
struct FRigBone : FRigElement {
	// Fields
	struct FName ParentName; // Offset: 0x14 | Size: 0x8
	int32_t ParentIndex; // Offset: 0x1c | Size: 0x4
	struct FTransform InitialTransform; // Offset: 0x20 | Size: 0x30
	struct FTransform GlobalTransform; // Offset: 0x50 | Size: 0x30
	struct FTransform LocalTransform; // Offset: 0x80 | Size: 0x30
	struct TArray<int32_t> Dependents; // Offset: 0xb0 | Size: 0x10
	enum class ERigBoneType Type; // Offset: 0xc0 | Size: 0x1
	char pad_0xC5[0xb]; // Offset: 0xc5 | Size: 0xb
};

// Object: ScriptStruct ControlRig.RigControlHierarchy
// Inherited Bytes: 0x0 | Struct Size: 0x68
struct FRigControlHierarchy {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
	struct TArray<struct FRigControl> Controls; // Offset: 0x8 | Size: 0x10
	struct TMap<struct FName, int32_t> NameToIndexMapping; // Offset: 0x18 | Size: 0x50
};

// Object: ScriptStruct ControlRig.RigControl
// Inherited Bytes: 0x18 | Struct Size: 0x170
struct FRigControl : FRigElement {
	// Fields
	enum class ERigControlType ControlType; // Offset: 0x14 | Size: 0x1
	struct FName ParentName; // Offset: 0x18 | Size: 0x8
	int32_t ParentIndex; // Offset: 0x20 | Size: 0x4
	struct FName SpaceName; // Offset: 0x24 | Size: 0x8
	int32_t SpaceIndex; // Offset: 0x2c | Size: 0x4
	struct FRigControlValue InitialValue; // Offset: 0x30 | Size: 0x30
	struct FRigControlValue Value; // Offset: 0x60 | Size: 0x30
	enum class ERigControlAxis PrimaryAxis; // Offset: 0x90 | Size: 0x1
	bool bIsCurve; // Offset: 0x91 | Size: 0x1
	bool bAnimatable; // Offset: 0x92 | Size: 0x1
	bool bLimitTranslation; // Offset: 0x93 | Size: 0x1
	bool bLimitRotation; // Offset: 0x94 | Size: 0x1
	bool bLimitScale; // Offset: 0x95 | Size: 0x1
	bool bDrawLimits; // Offset: 0x96 | Size: 0x1
	char pad_0x98[0x8]; // Offset: 0x98 | Size: 0x8
	struct FRigControlValue MinimumValue; // Offset: 0xa0 | Size: 0x30
	struct FRigControlValue MaximumValue; // Offset: 0xd0 | Size: 0x30
	bool bGizmoEnabled; // Offset: 0x100 | Size: 0x1
	char pad_0x101[0x3]; // Offset: 0x101 | Size: 0x3
	struct FName GizmoName; // Offset: 0x104 | Size: 0x8
	char pad_0x10C[0x4]; // Offset: 0x10c | Size: 0x4
	struct FTransform GizmoTransform; // Offset: 0x110 | Size: 0x30
	struct FLinearColor GizmoColor; // Offset: 0x140 | Size: 0x10
	struct TArray<int32_t> Dependents; // Offset: 0x150 | Size: 0x10
	bool bIsTransientControl; // Offset: 0x160 | Size: 0x1
	char pad_0x161[0xf]; // Offset: 0x161 | Size: 0xf
};

// Object: ScriptStruct ControlRig.RigControlValue
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FRigControlValue {
	// Fields
	struct FTransform Storage; // Offset: 0x0 | Size: 0x30
};

// Object: ScriptStruct ControlRig.RigCurveContainer
// Inherited Bytes: 0x0 | Struct Size: 0x70
struct FRigCurveContainer {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
	struct TArray<struct FRigCurve> Curves; // Offset: 0x8 | Size: 0x10
	struct TMap<struct FName, int32_t> NameToIndexMapping; // Offset: 0x18 | Size: 0x50
	char pad_0x68[0x8]; // Offset: 0x68 | Size: 0x8
};

// Object: ScriptStruct ControlRig.RigCurve
// Inherited Bytes: 0x18 | Struct Size: 0x18
struct FRigCurve : FRigElement {
	// Fields
	float Value; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigHierarchyRef
// Inherited Bytes: 0x0 | Struct Size: 0x1
struct FRigHierarchyRef {
	// Fields
	char pad_0x0[0x1]; // Offset: 0x0 | Size: 0x1
};

// Object: ScriptStruct ControlRig.RigHierarchyContainer
// Inherited Bytes: 0x0 | Struct Size: 0x1b0
struct FRigHierarchyContainer {
	// Fields
	struct FRigBoneHierarchy BoneHierarchy; // Offset: 0x0 | Size: 0x70
	struct FRigSpaceHierarchy SpaceHierarchy; // Offset: 0x70 | Size: 0x68
	struct FRigControlHierarchy ControlHierarchy; // Offset: 0xd8 | Size: 0x68
	struct FRigCurveContainer CurveContainer; // Offset: 0x140 | Size: 0x70
};

// Object: ScriptStruct ControlRig.RigSpaceHierarchy
// Inherited Bytes: 0x0 | Struct Size: 0x68
struct FRigSpaceHierarchy {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
	struct TArray<struct FRigSpace> Spaces; // Offset: 0x8 | Size: 0x10
	struct TMap<struct FName, int32_t> NameToIndexMapping; // Offset: 0x18 | Size: 0x50
};

// Object: ScriptStruct ControlRig.RigSpace
// Inherited Bytes: 0x18 | Struct Size: 0x90
struct FRigSpace : FRigElement {
	// Fields
	enum class ERigSpaceType SpaceType; // Offset: 0x14 | Size: 0x1
	struct FName ParentName; // Offset: 0x18 | Size: 0x8
	int32_t ParentIndex; // Offset: 0x20 | Size: 0x4
	char pad_0x25[0xb]; // Offset: 0x25 | Size: 0xb
	struct FTransform InitialTransform; // Offset: 0x30 | Size: 0x30
	struct FTransform LocalTransform; // Offset: 0x60 | Size: 0x30
};

// Object: ScriptStruct ControlRig.RigHierarchyCopyPasteContent
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FRigHierarchyCopyPasteContent {
	// Fields
	struct TArray<enum class ERigElementType> Types; // Offset: 0x0 | Size: 0x10
	struct TArray<struct FString> Contents; // Offset: 0x10 | Size: 0x10
	struct TArray<struct FTransform> LocalTransforms; // Offset: 0x20 | Size: 0x10
	struct TArray<struct FTransform> GlobalTransforms; // Offset: 0x30 | Size: 0x10
};

// Object: ScriptStruct ControlRig.RigElementKey
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FRigElementKey {
	// Fields
	struct FName Name; // Offset: 0x0 | Size: 0x8
	enum class ERigElementType Type; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x3]; // Offset: 0x9 | Size: 0x3
};

// Object: ScriptStruct ControlRig.RigUnit
// Inherited Bytes: 0x8 | Struct Size: 0x8
struct FRigUnit : FRigVMStruct {
};

// Object: ScriptStruct ControlRig.RigUnitMutable
// Inherited Bytes: 0x8 | Struct Size: 0x20
struct FRigUnitMutable : FRigUnit {
	// Fields
	struct FControlRigExecuteContext ExecuteContext; // Offset: 0x8 | Size: 0x18
};

// Object: ScriptStruct ControlRig.RigUnit_SimBase
// Inherited Bytes: 0x8 | Struct Size: 0x8
struct FRigUnit_SimBase : FRigUnit {
};

// Object: ScriptStruct ControlRig.RigUnit_AccumulateVectorRange
// Inherited Bytes: 0x8 | Struct Size: 0x48
struct FRigUnit_AccumulateVectorRange : FRigUnit_SimBase {
	// Fields
	struct FVector Value; // Offset: 0x8 | Size: 0xc
	struct FVector Minimum; // Offset: 0x14 | Size: 0xc
	struct FVector Maximum; // Offset: 0x20 | Size: 0xc
	struct FVector AccumulatedMinimum; // Offset: 0x2c | Size: 0xc
	struct FVector AccumulatedMaximum; // Offset: 0x38 | Size: 0xc
	char pad_0x44[0x4]; // Offset: 0x44 | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_AccumulateFloatRange
// Inherited Bytes: 0x8 | Struct Size: 0x20
struct FRigUnit_AccumulateFloatRange : FRigUnit_SimBase {
	// Fields
	float Value; // Offset: 0x8 | Size: 0x4
	float Minimum; // Offset: 0xc | Size: 0x4
	float Maximum; // Offset: 0x10 | Size: 0x4
	float AccumulatedMinimum; // Offset: 0x14 | Size: 0x4
	float AccumulatedMaximum; // Offset: 0x18 | Size: 0x4
	char pad_0x1C[0x4]; // Offset: 0x1c | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_AccumulateTransformLerp
// Inherited Bytes: 0x8 | Struct Size: 0xe0
struct FRigUnit_AccumulateTransformLerp : FRigUnit_SimBase {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FTransform TargetValue; // Offset: 0x10 | Size: 0x30
	struct FTransform InitialValue; // Offset: 0x40 | Size: 0x30
	float Blend; // Offset: 0x70 | Size: 0x4
	bool bIntegrateDeltaTime; // Offset: 0x74 | Size: 0x1
	char pad_0x75[0xb]; // Offset: 0x75 | Size: 0xb
	struct FTransform Result; // Offset: 0x80 | Size: 0x30
	struct FTransform AccumulatedValue; // Offset: 0xb0 | Size: 0x30
};

// Object: ScriptStruct ControlRig.RigUnit_AccumulateQuatLerp
// Inherited Bytes: 0x8 | Struct Size: 0x60
struct FRigUnit_AccumulateQuatLerp : FRigUnit_SimBase {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FQuat TargetValue; // Offset: 0x10 | Size: 0x10
	struct FQuat InitialValue; // Offset: 0x20 | Size: 0x10
	float Blend; // Offset: 0x30 | Size: 0x4
	bool bIntegrateDeltaTime; // Offset: 0x34 | Size: 0x1
	char pad_0x35[0xb]; // Offset: 0x35 | Size: 0xb
	struct FQuat Result; // Offset: 0x40 | Size: 0x10
	struct FQuat AccumulatedValue; // Offset: 0x50 | Size: 0x10
};

// Object: ScriptStruct ControlRig.RigUnit_AccumulateVectorLerp
// Inherited Bytes: 0x8 | Struct Size: 0x40
struct FRigUnit_AccumulateVectorLerp : FRigUnit_SimBase {
	// Fields
	struct FVector TargetValue; // Offset: 0x8 | Size: 0xc
	struct FVector InitialValue; // Offset: 0x14 | Size: 0xc
	float Blend; // Offset: 0x20 | Size: 0x4
	bool bIntegrateDeltaTime; // Offset: 0x24 | Size: 0x1
	char pad_0x25[0x3]; // Offset: 0x25 | Size: 0x3
	struct FVector Result; // Offset: 0x28 | Size: 0xc
	struct FVector AccumulatedValue; // Offset: 0x34 | Size: 0xc
};

// Object: ScriptStruct ControlRig.RigUnit_AccumulateFloatLerp
// Inherited Bytes: 0x8 | Struct Size: 0x20
struct FRigUnit_AccumulateFloatLerp : FRigUnit_SimBase {
	// Fields
	float TargetValue; // Offset: 0x8 | Size: 0x4
	float InitialValue; // Offset: 0xc | Size: 0x4
	float Blend; // Offset: 0x10 | Size: 0x4
	bool bIntegrateDeltaTime; // Offset: 0x14 | Size: 0x1
	char pad_0x15[0x3]; // Offset: 0x15 | Size: 0x3
	float Result; // Offset: 0x18 | Size: 0x4
	float AccumulatedValue; // Offset: 0x1c | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_AccumulateTransformMul
// Inherited Bytes: 0x8 | Struct Size: 0xe0
struct FRigUnit_AccumulateTransformMul : FRigUnit_SimBase {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FTransform Multiplier; // Offset: 0x10 | Size: 0x30
	struct FTransform InitialValue; // Offset: 0x40 | Size: 0x30
	bool bFlipOrder; // Offset: 0x70 | Size: 0x1
	bool bIntegrateDeltaTime; // Offset: 0x71 | Size: 0x1
	char pad_0x72[0xe]; // Offset: 0x72 | Size: 0xe
	struct FTransform Result; // Offset: 0x80 | Size: 0x30
	struct FTransform AccumulatedValue; // Offset: 0xb0 | Size: 0x30
};

// Object: ScriptStruct ControlRig.RigUnit_AccumulateQuatMul
// Inherited Bytes: 0x8 | Struct Size: 0x60
struct FRigUnit_AccumulateQuatMul : FRigUnit_SimBase {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FQuat Multiplier; // Offset: 0x10 | Size: 0x10
	struct FQuat InitialValue; // Offset: 0x20 | Size: 0x10
	bool bFlipOrder; // Offset: 0x30 | Size: 0x1
	bool bIntegrateDeltaTime; // Offset: 0x31 | Size: 0x1
	char pad_0x32[0xe]; // Offset: 0x32 | Size: 0xe
	struct FQuat Result; // Offset: 0x40 | Size: 0x10
	struct FQuat AccumulatedValue; // Offset: 0x50 | Size: 0x10
};

// Object: ScriptStruct ControlRig.RigUnit_AccumulateVectorMul
// Inherited Bytes: 0x8 | Struct Size: 0x40
struct FRigUnit_AccumulateVectorMul : FRigUnit_SimBase {
	// Fields
	struct FVector Multiplier; // Offset: 0x8 | Size: 0xc
	struct FVector InitialValue; // Offset: 0x14 | Size: 0xc
	bool bIntegrateDeltaTime; // Offset: 0x20 | Size: 0x1
	char pad_0x21[0x3]; // Offset: 0x21 | Size: 0x3
	struct FVector Result; // Offset: 0x24 | Size: 0xc
	struct FVector AccumulatedValue; // Offset: 0x30 | Size: 0xc
	char pad_0x3C[0x4]; // Offset: 0x3c | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_AccumulateFloatMul
// Inherited Bytes: 0x8 | Struct Size: 0x20
struct FRigUnit_AccumulateFloatMul : FRigUnit_SimBase {
	// Fields
	float Multiplier; // Offset: 0x8 | Size: 0x4
	float InitialValue; // Offset: 0xc | Size: 0x4
	bool bIntegrateDeltaTime; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x3]; // Offset: 0x11 | Size: 0x3
	float Result; // Offset: 0x14 | Size: 0x4
	float AccumulatedValue; // Offset: 0x18 | Size: 0x4
	char pad_0x1C[0x4]; // Offset: 0x1c | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_AccumulateVectorAdd
// Inherited Bytes: 0x8 | Struct Size: 0x40
struct FRigUnit_AccumulateVectorAdd : FRigUnit_SimBase {
	// Fields
	struct FVector Increment; // Offset: 0x8 | Size: 0xc
	struct FVector InitialValue; // Offset: 0x14 | Size: 0xc
	bool bIntegrateDeltaTime; // Offset: 0x20 | Size: 0x1
	char pad_0x21[0x3]; // Offset: 0x21 | Size: 0x3
	struct FVector Result; // Offset: 0x24 | Size: 0xc
	struct FVector AccumulatedValue; // Offset: 0x30 | Size: 0xc
	char pad_0x3C[0x4]; // Offset: 0x3c | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_AccumulateFloatAdd
// Inherited Bytes: 0x8 | Struct Size: 0x20
struct FRigUnit_AccumulateFloatAdd : FRigUnit_SimBase {
	// Fields
	float Increment; // Offset: 0x8 | Size: 0x4
	float InitialValue; // Offset: 0xc | Size: 0x4
	bool bIntegrateDeltaTime; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x3]; // Offset: 0x11 | Size: 0x3
	float Result; // Offset: 0x14 | Size: 0x4
	float AccumulatedValue; // Offset: 0x18 | Size: 0x4
	char pad_0x1C[0x4]; // Offset: 0x1c | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_AddBoneTransform
// Inherited Bytes: 0x20 | Struct Size: 0x70
struct FRigUnit_AddBoneTransform : FRigUnitMutable {
	// Fields
	struct FName Bone; // Offset: 0x20 | Size: 0x8
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
	struct FTransform Transform; // Offset: 0x30 | Size: 0x30
	float Weight; // Offset: 0x60 | Size: 0x4
	bool bPostMultiply; // Offset: 0x64 | Size: 0x1
	bool bPropagateToChildren; // Offset: 0x65 | Size: 0x1
	char pad_0x66[0x2]; // Offset: 0x66 | Size: 0x2
	int32_t CachedBoneIndex; // Offset: 0x68 | Size: 0x4
	char pad_0x6C[0x4]; // Offset: 0x6c | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_HighlevelBaseMutable
// Inherited Bytes: 0x20 | Struct Size: 0x20
struct FRigUnit_HighlevelBaseMutable : FRigUnitMutable {
};

// Object: ScriptStruct ControlRig.RigUnit_AimBone
// Inherited Bytes: 0x20 | Struct Size: 0xe0
struct FRigUnit_AimBone : FRigUnit_HighlevelBaseMutable {
	// Fields
	struct FName Bone; // Offset: 0x20 | Size: 0x8
	struct FRigUnit_AimBone_Target Primary; // Offset: 0x28 | Size: 0x28
	struct FRigUnit_AimBone_Target Secondary; // Offset: 0x50 | Size: 0x28
	float Weight; // Offset: 0x78 | Size: 0x4
	bool bPropagateToChildren; // Offset: 0x7c | Size: 0x1
	char pad_0x7D[0x3]; // Offset: 0x7d | Size: 0x3
	struct FRigUnit_AimBone_DebugSettings DebugSettings; // Offset: 0x80 | Size: 0x40
	int32_t BoneIndex; // Offset: 0xc0 | Size: 0x4
	struct FName PrimaryCachedSpaceName; // Offset: 0xc4 | Size: 0x8
	int32_t PrimaryCachedSpaceIndex; // Offset: 0xcc | Size: 0x4
	struct FName SecondaryCachedSpaceName; // Offset: 0xd0 | Size: 0x8
	int32_t SecondaryCachedSpaceIndex; // Offset: 0xd8 | Size: 0x4
	char pad_0xDC[0x4]; // Offset: 0xdc | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_AimBone_DebugSettings
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FRigUnit_AimBone_DebugSettings {
	// Fields
	bool bEnabled; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	float Scale; // Offset: 0x4 | Size: 0x4
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FTransform WorldOffset; // Offset: 0x10 | Size: 0x30
};

// Object: ScriptStruct ControlRig.RigUnit_AimBone_Target
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FRigUnit_AimBone_Target {
	// Fields
	float Weight; // Offset: 0x0 | Size: 0x4
	struct FVector Axis; // Offset: 0x4 | Size: 0xc
	struct FVector Target; // Offset: 0x10 | Size: 0xc
	enum class EControlRigVectorKind Kind; // Offset: 0x1c | Size: 0x1
	char pad_0x1D[0x3]; // Offset: 0x1d | Size: 0x3
	struct FName Space; // Offset: 0x20 | Size: 0x8
};

// Object: ScriptStruct ControlRig.RigUnit_AimConstraint
// Inherited Bytes: 0x20 | Struct Size: 0x78
struct FRigUnit_AimConstraint : FRigUnitMutable {
	// Fields
	struct FName Joint; // Offset: 0x20 | Size: 0x8
	enum class EAimMode AimMode; // Offset: 0x28 | Size: 0x1
	enum class EAimMode UpMode; // Offset: 0x29 | Size: 0x1
	char pad_0x2A[0x2]; // Offset: 0x2a | Size: 0x2
	struct FVector AimVector; // Offset: 0x2c | Size: 0xc
	struct FVector UpVector; // Offset: 0x38 | Size: 0xc
	char pad_0x44[0x4]; // Offset: 0x44 | Size: 0x4
	struct TArray<struct FAimTarget> AimTargets; // Offset: 0x48 | Size: 0x10
	struct TArray<struct FAimTarget> UpTargets; // Offset: 0x58 | Size: 0x10
	char pad_0x68[0x10]; // Offset: 0x68 | Size: 0x10
};

// Object: ScriptStruct ControlRig.AimTarget
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FAimTarget {
	// Fields
	float Weight; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0xc]; // Offset: 0x4 | Size: 0xc
	struct FTransform Transform; // Offset: 0x10 | Size: 0x30
	struct FVector AlignVector; // Offset: 0x40 | Size: 0xc
	char pad_0x4C[0x4]; // Offset: 0x4c | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_AlphaInterpVector
// Inherited Bytes: 0x8 | Struct Size: 0x88
struct FRigUnit_AlphaInterpVector : FRigUnit_SimBase {
	// Fields
	struct FVector Value; // Offset: 0x8 | Size: 0xc
	float Scale; // Offset: 0x14 | Size: 0x4
	float Bias; // Offset: 0x18 | Size: 0x4
	bool bMapRange; // Offset: 0x1c | Size: 0x1
	char pad_0x1D[0x3]; // Offset: 0x1d | Size: 0x3
	struct FInputRange InRange; // Offset: 0x20 | Size: 0x8
	struct FInputRange OutRange; // Offset: 0x28 | Size: 0x8
	bool bClampResult; // Offset: 0x30 | Size: 0x1
	char pad_0x31[0x3]; // Offset: 0x31 | Size: 0x3
	float ClampMin; // Offset: 0x34 | Size: 0x4
	float ClampMax; // Offset: 0x38 | Size: 0x4
	bool bInterpResult; // Offset: 0x3c | Size: 0x1
	char pad_0x3D[0x3]; // Offset: 0x3d | Size: 0x3
	float InterpSpeedIncreasing; // Offset: 0x40 | Size: 0x4
	float InterpSpeedDecreasing; // Offset: 0x44 | Size: 0x4
	struct FVector Result; // Offset: 0x48 | Size: 0xc
	struct FInputScaleBiasClamp ScaleBiasClamp; // Offset: 0x54 | Size: 0x30
	char pad_0x84[0x4]; // Offset: 0x84 | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_AlphaInterp
// Inherited Bytes: 0x8 | Struct Size: 0x78
struct FRigUnit_AlphaInterp : FRigUnit_SimBase {
	// Fields
	float Value; // Offset: 0x8 | Size: 0x4
	float Scale; // Offset: 0xc | Size: 0x4
	float Bias; // Offset: 0x10 | Size: 0x4
	bool bMapRange; // Offset: 0x14 | Size: 0x1
	char pad_0x15[0x3]; // Offset: 0x15 | Size: 0x3
	struct FInputRange InRange; // Offset: 0x18 | Size: 0x8
	struct FInputRange OutRange; // Offset: 0x20 | Size: 0x8
	bool bClampResult; // Offset: 0x28 | Size: 0x1
	char pad_0x29[0x3]; // Offset: 0x29 | Size: 0x3
	float ClampMin; // Offset: 0x2c | Size: 0x4
	float ClampMax; // Offset: 0x30 | Size: 0x4
	bool bInterpResult; // Offset: 0x34 | Size: 0x1
	char pad_0x35[0x3]; // Offset: 0x35 | Size: 0x3
	float InterpSpeedIncreasing; // Offset: 0x38 | Size: 0x4
	float InterpSpeedDecreasing; // Offset: 0x3c | Size: 0x4
	float Result; // Offset: 0x40 | Size: 0x4
	struct FInputScaleBiasClamp ScaleBiasClamp; // Offset: 0x44 | Size: 0x30
	char pad_0x74[0x4]; // Offset: 0x74 | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_AnimBase
// Inherited Bytes: 0x8 | Struct Size: 0x8
struct FRigUnit_AnimBase : FRigUnit {
};

// Object: ScriptStruct ControlRig.RigUnit_AnimEasing
// Inherited Bytes: 0x8 | Struct Size: 0x28
struct FRigUnit_AnimEasing : FRigUnit_AnimBase {
	// Fields
	float Value; // Offset: 0x8 | Size: 0x4
	enum class EControlRigAnimEasingType Type; // Offset: 0xc | Size: 0x1
	char pad_0xD[0x3]; // Offset: 0xd | Size: 0x3
	float SourceMinimum; // Offset: 0x10 | Size: 0x4
	float SourceMaximum; // Offset: 0x14 | Size: 0x4
	float TargetMinimum; // Offset: 0x18 | Size: 0x4
	float TargetMaximum; // Offset: 0x1c | Size: 0x4
	float Result; // Offset: 0x20 | Size: 0x4
	char pad_0x24[0x4]; // Offset: 0x24 | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_AnimEasingType
// Inherited Bytes: 0x8 | Struct Size: 0x10
struct FRigUnit_AnimEasingType : FRigUnit_AnimBase {
	// Fields
	enum class EControlRigAnimEasingType Type; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x7]; // Offset: 0x9 | Size: 0x7
};

// Object: ScriptStruct ControlRig.RigUnit_AnimEvalRichCurve
// Inherited Bytes: 0x8 | Struct Size: 0xb0
struct FRigUnit_AnimEvalRichCurve : FRigUnit_AnimBase {
	// Fields
	float Value; // Offset: 0x8 | Size: 0x4
	char pad_0xC[0x4]; // Offset: 0xc | Size: 0x4
	struct FRuntimeFloatCurve Curve; // Offset: 0x10 | Size: 0x88
	float SourceMinimum; // Offset: 0x98 | Size: 0x4
	float SourceMaximum; // Offset: 0x9c | Size: 0x4
	float TargetMinimum; // Offset: 0xa0 | Size: 0x4
	float TargetMaximum; // Offset: 0xa4 | Size: 0x4
	float Result; // Offset: 0xa8 | Size: 0x4
	char pad_0xAC[0x4]; // Offset: 0xac | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_AnimRichCurve
// Inherited Bytes: 0x8 | Struct Size: 0x90
struct FRigUnit_AnimRichCurve : FRigUnit_AnimBase {
	// Fields
	struct FRuntimeFloatCurve Curve; // Offset: 0x8 | Size: 0x88
};

// Object: ScriptStruct ControlRig.RigUnit_ApplyFK
// Inherited Bytes: 0x20 | Struct Size: 0xb0
struct FRigUnit_ApplyFK : FRigUnitMutable {
	// Fields
	struct FName Joint; // Offset: 0x20 | Size: 0x8
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
	struct FTransform Transform; // Offset: 0x30 | Size: 0x30
	struct FTransformFilter Filter; // Offset: 0x60 | Size: 0x9
	enum class EApplyTransformMode ApplyTransformMode; // Offset: 0x69 | Size: 0x1
	enum class ETransformSpaceMode ApplyTransformSpace; // Offset: 0x6a | Size: 0x1
	char pad_0x6B[0x5]; // Offset: 0x6b | Size: 0x5
	struct FTransform BaseTransform; // Offset: 0x70 | Size: 0x30
	struct FName BaseJoint; // Offset: 0xa0 | Size: 0x8
	char pad_0xA8[0x8]; // Offset: 0xa8 | Size: 0x8
};

// Object: ScriptStruct ControlRig.RigUnit_BeginExecution
// Inherited Bytes: 0x8 | Struct Size: 0x20
struct FRigUnit_BeginExecution : FRigUnit {
	// Fields
	struct FControlRigExecuteContext ExecuteContext; // Offset: 0x8 | Size: 0x18
};

// Object: ScriptStruct ControlRig.RigUnit_BlendTransform
// Inherited Bytes: 0x8 | Struct Size: 0x80
struct FRigUnit_BlendTransform : FRigUnit {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FTransform Source; // Offset: 0x10 | Size: 0x30
	struct TArray<struct FBlendTarget> Targets; // Offset: 0x40 | Size: 0x10
	struct FTransform Result; // Offset: 0x50 | Size: 0x30
};

// Object: ScriptStruct ControlRig.BlendTarget
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FBlendTarget {
	// Fields
	struct FTransform Transform; // Offset: 0x0 | Size: 0x30
	float Weight; // Offset: 0x30 | Size: 0x4
	char pad_0x34[0xc]; // Offset: 0x34 | Size: 0xc
};

// Object: ScriptStruct ControlRig.RigUnit_BoneHarmonics
// Inherited Bytes: 0x20 | Struct Size: 0xa0
struct FRigUnit_BoneHarmonics : FRigUnit_HighlevelBaseMutable {
	// Fields
	struct TArray<struct FRigUnit_BoneHarmonics_BoneTarget> Bones; // Offset: 0x20 | Size: 0x10
	struct FVector WaveSpeed; // Offset: 0x30 | Size: 0xc
	struct FVector WaveFrequency; // Offset: 0x3c | Size: 0xc
	struct FVector WaveAmplitude; // Offset: 0x48 | Size: 0xc
	struct FVector WaveOffset; // Offset: 0x54 | Size: 0xc
	struct FVector WaveNoise; // Offset: 0x60 | Size: 0xc
	enum class EControlRigAnimEasingType WaveEase; // Offset: 0x6c | Size: 0x1
	char pad_0x6D[0x3]; // Offset: 0x6d | Size: 0x3
	float WaveMinimum; // Offset: 0x70 | Size: 0x4
	float WaveMaximum; // Offset: 0x74 | Size: 0x4
	enum class EControlRigRotationOrder RotationOrder; // Offset: 0x78 | Size: 0x1
	bool bPropagateToChildren; // Offset: 0x79 | Size: 0x1
	char pad_0x7A[0x6]; // Offset: 0x7a | Size: 0x6
	struct FRigUnit_BoneHarmonics_WorkData WorkData; // Offset: 0x80 | Size: 0x20
};

// Object: ScriptStruct ControlRig.RigUnit_BoneHarmonics_WorkData
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FRigUnit_BoneHarmonics_WorkData {
	// Fields
	struct TArray<int32_t> BoneIndices; // Offset: 0x0 | Size: 0x10
	struct FVector WaveTime; // Offset: 0x10 | Size: 0xc
	char pad_0x1C[0x4]; // Offset: 0x1c | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_BoneHarmonics_BoneTarget
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FRigUnit_BoneHarmonics_BoneTarget {
	// Fields
	struct FName Bone; // Offset: 0x0 | Size: 0x8
	float Ratio; // Offset: 0x8 | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_ControlName
// Inherited Bytes: 0x8 | Struct Size: 0x10
struct FRigUnit_ControlName : FRigUnit {
	// Fields
	struct FName Control; // Offset: 0x8 | Size: 0x8
};

// Object: ScriptStruct ControlRig.RigUnit_SpaceName
// Inherited Bytes: 0x8 | Struct Size: 0x10
struct FRigUnit_SpaceName : FRigUnit {
	// Fields
	struct FName Space; // Offset: 0x8 | Size: 0x8
};

// Object: ScriptStruct ControlRig.RigUnit_BoneName
// Inherited Bytes: 0x8 | Struct Size: 0x10
struct FRigUnit_BoneName : FRigUnit {
	// Fields
	struct FName Bone; // Offset: 0x8 | Size: 0x8
};

// Object: ScriptStruct ControlRig.RigUnit_CCDIK
// Inherited Bytes: 0x20 | Struct Size: 0xe0
struct FRigUnit_CCDIK : FRigUnit_HighlevelBaseMutable {
	// Fields
	struct FName StartBone; // Offset: 0x20 | Size: 0x8
	struct FName EffectorBone; // Offset: 0x28 | Size: 0x8
	struct FTransform EffectorTransform; // Offset: 0x30 | Size: 0x30
	float Precision; // Offset: 0x60 | Size: 0x4
	float Weight; // Offset: 0x64 | Size: 0x4
	int32_t MaxIterations; // Offset: 0x68 | Size: 0x4
	bool bStartFromTail; // Offset: 0x6c | Size: 0x1
	char pad_0x6D[0x3]; // Offset: 0x6d | Size: 0x3
	float BaseRotationLimit; // Offset: 0x70 | Size: 0x4
	char pad_0x74[0x4]; // Offset: 0x74 | Size: 0x4
	struct TArray<struct FRigUnit_CCDIK_RotationLimit> RotationLimits; // Offset: 0x78 | Size: 0x10
	bool bPropagateToChildren; // Offset: 0x88 | Size: 0x1
	char pad_0x89[0x7]; // Offset: 0x89 | Size: 0x7
	struct FRigUnit_CCDIK_WorkData WorkData; // Offset: 0x90 | Size: 0x48
	char pad_0xD8[0x8]; // Offset: 0xd8 | Size: 0x8
};

// Object: ScriptStruct ControlRig.RigUnit_CCDIK_WorkData
// Inherited Bytes: 0x0 | Struct Size: 0x48
struct FRigUnit_CCDIK_WorkData {
	// Fields
	struct TArray<struct FCCDIKChainLink> Chain; // Offset: 0x0 | Size: 0x10
	struct TArray<int32_t> BoneIndices; // Offset: 0x10 | Size: 0x10
	struct TArray<int32_t> RotationLimitIndex; // Offset: 0x20 | Size: 0x10
	struct TArray<float> RotationLimitsPerBone; // Offset: 0x30 | Size: 0x10
	int32_t EffectorIndex; // Offset: 0x40 | Size: 0x4
	char pad_0x44[0x4]; // Offset: 0x44 | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_CCDIK_RotationLimit
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FRigUnit_CCDIK_RotationLimit {
	// Fields
	struct FName Bone; // Offset: 0x0 | Size: 0x8
	float Limit; // Offset: 0x8 | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_ChainHarmonics
// Inherited Bytes: 0x20 | Struct Size: 0x230
struct FRigUnit_ChainHarmonics : FRigUnit_HighlevelBaseMutable {
	// Fields
	struct FName ChainRoot; // Offset: 0x20 | Size: 0x8
	struct FVector Speed; // Offset: 0x28 | Size: 0xc
	struct FRigUnit_ChainHarmonics_Reach Reach; // Offset: 0x34 | Size: 0x28
	struct FRigUnit_ChainHarmonics_Wave Wave; // Offset: 0x5c | Size: 0x40
	char pad_0x9C[0x4]; // Offset: 0x9c | Size: 0x4
	struct FRuntimeFloatCurve WaveCurve; // Offset: 0xa0 | Size: 0x88
	struct FRigUnit_ChainHarmonics_Pendulum Pendulum; // Offset: 0x128 | Size: 0x3c
	bool bDrawDebug; // Offset: 0x164 | Size: 0x1
	char pad_0x165[0xb]; // Offset: 0x165 | Size: 0xb
	struct FTransform DrawWorldOffset; // Offset: 0x170 | Size: 0x30
	struct FRigUnit_ChainHarmonics_WorkData WorkData; // Offset: 0x1a0 | Size: 0x90
};

// Object: ScriptStruct ControlRig.RigUnit_ChainHarmonics_WorkData
// Inherited Bytes: 0x0 | Struct Size: 0x90
struct FRigUnit_ChainHarmonics_WorkData {
	// Fields
	struct FVector Time; // Offset: 0x0 | Size: 0xc
	char pad_0xC[0x4]; // Offset: 0xc | Size: 0x4
	struct TArray<int32_t> Bones; // Offset: 0x10 | Size: 0x10
	struct TArray<float> Ratio; // Offset: 0x20 | Size: 0x10
	struct TArray<struct FVector> LocalTip; // Offset: 0x30 | Size: 0x10
	struct TArray<struct FVector> PendulumTip; // Offset: 0x40 | Size: 0x10
	struct TArray<struct FVector> PendulumPosition; // Offset: 0x50 | Size: 0x10
	struct TArray<struct FVector> PendulumVelocity; // Offset: 0x60 | Size: 0x10
	struct TArray<struct FVector> HierarchyLine; // Offset: 0x70 | Size: 0x10
	struct TArray<struct FVector> VelocityLines; // Offset: 0x80 | Size: 0x10
};

// Object: ScriptStruct ControlRig.RigUnit_ChainHarmonics_Pendulum
// Inherited Bytes: 0x0 | Struct Size: 0x3c
struct FRigUnit_ChainHarmonics_Pendulum {
	// Fields
	bool bEnabled; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	float PendulumStiffness; // Offset: 0x4 | Size: 0x4
	struct FVector PendulumGravity; // Offset: 0x8 | Size: 0xc
	float PendulumBlend; // Offset: 0x14 | Size: 0x4
	float PendulumDrag; // Offset: 0x18 | Size: 0x4
	float PendulumMinimum; // Offset: 0x1c | Size: 0x4
	float PendulumMaximum; // Offset: 0x20 | Size: 0x4
	enum class EControlRigAnimEasingType PendulumEase; // Offset: 0x24 | Size: 0x1
	char pad_0x25[0x3]; // Offset: 0x25 | Size: 0x3
	struct FVector UnwindAxis; // Offset: 0x28 | Size: 0xc
	float UnwindMinimum; // Offset: 0x34 | Size: 0x4
	float UnwindMaximum; // Offset: 0x38 | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_ChainHarmonics_Wave
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FRigUnit_ChainHarmonics_Wave {
	// Fields
	bool bEnabled; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	struct FVector WaveFrequency; // Offset: 0x4 | Size: 0xc
	struct FVector WaveAmplitude; // Offset: 0x10 | Size: 0xc
	struct FVector WaveOffset; // Offset: 0x1c | Size: 0xc
	struct FVector WaveNoise; // Offset: 0x28 | Size: 0xc
	float WaveMinimum; // Offset: 0x34 | Size: 0x4
	float WaveMaximum; // Offset: 0x38 | Size: 0x4
	enum class EControlRigAnimEasingType WaveEase; // Offset: 0x3c | Size: 0x1
	char pad_0x3D[0x3]; // Offset: 0x3d | Size: 0x3
};

// Object: ScriptStruct ControlRig.RigUnit_ChainHarmonics_Reach
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FRigUnit_ChainHarmonics_Reach {
	// Fields
	bool bEnabled; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	struct FVector ReachTarget; // Offset: 0x4 | Size: 0xc
	struct FVector ReachAxis; // Offset: 0x10 | Size: 0xc
	float ReachMinimum; // Offset: 0x1c | Size: 0x4
	float ReachMaximum; // Offset: 0x20 | Size: 0x4
	enum class EControlRigAnimEasingType ReachEase; // Offset: 0x24 | Size: 0x1
	char pad_0x25[0x3]; // Offset: 0x25 | Size: 0x3
};

// Object: ScriptStruct ControlRig.RigUnit_Control
// Inherited Bytes: 0x8 | Struct Size: 0xd0
struct FRigUnit_Control : FRigUnit {
	// Fields
	struct FEulerTransform Transform; // Offset: 0x8 | Size: 0x24
	char pad_0x2C[0x4]; // Offset: 0x2c | Size: 0x4
	struct FTransform Base; // Offset: 0x30 | Size: 0x30
	struct FTransform InitTransform; // Offset: 0x60 | Size: 0x30
	struct FTransform Result; // Offset: 0x90 | Size: 0x30
	struct FTransformFilter Filter; // Offset: 0xc0 | Size: 0x9
	char pad_0xC9[0x7]; // Offset: 0xc9 | Size: 0x7
};

// Object: ScriptStruct ControlRig.RigUnit_Control_StaticMesh
// Inherited Bytes: 0xd0 | Struct Size: 0x100
struct FRigUnit_Control_StaticMesh : FRigUnit_Control {
	// Fields
	struct FTransform MeshTransform; // Offset: 0xd0 | Size: 0x30
};

// Object: ScriptStruct ControlRig.RigUnit_ToSwingAndTwist
// Inherited Bytes: 0x8 | Struct Size: 0x50
struct FRigUnit_ToSwingAndTwist : FRigUnit {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FQuat Input; // Offset: 0x10 | Size: 0x10
	struct FVector TwistAxis; // Offset: 0x20 | Size: 0xc
	char pad_0x2C[0x4]; // Offset: 0x2c | Size: 0x4
	struct FQuat Swing; // Offset: 0x30 | Size: 0x10
	struct FQuat Twist; // Offset: 0x40 | Size: 0x10
};

// Object: ScriptStruct ControlRig.RigUnit_ConvertQuaternionToVector
// Inherited Bytes: 0x8 | Struct Size: 0x30
struct FRigUnit_ConvertQuaternionToVector : FRigUnit {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FQuat Input; // Offset: 0x10 | Size: 0x10
	struct FVector Result; // Offset: 0x20 | Size: 0xc
	char pad_0x2C[0x4]; // Offset: 0x2c | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_ConvertRotationToVector
// Inherited Bytes: 0x8 | Struct Size: 0x20
struct FRigUnit_ConvertRotationToVector : FRigUnit {
	// Fields
	struct FRotator Input; // Offset: 0x8 | Size: 0xc
	struct FVector Result; // Offset: 0x14 | Size: 0xc
};

// Object: ScriptStruct ControlRig.RigUnit_ConvertVectorToQuaternion
// Inherited Bytes: 0x8 | Struct Size: 0x30
struct FRigUnit_ConvertVectorToQuaternion : FRigUnit {
	// Fields
	struct FVector Input; // Offset: 0x8 | Size: 0xc
	char pad_0x14[0xc]; // Offset: 0x14 | Size: 0xc
	struct FQuat Result; // Offset: 0x20 | Size: 0x10
};

// Object: ScriptStruct ControlRig.RigUnit_ConvertVectorToRotation
// Inherited Bytes: 0x8 | Struct Size: 0x20
struct FRigUnit_ConvertVectorToRotation : FRigUnit {
	// Fields
	struct FVector Input; // Offset: 0x8 | Size: 0xc
	struct FRotator Result; // Offset: 0x14 | Size: 0xc
};

// Object: ScriptStruct ControlRig.RigUnit_ConvertQuaternion
// Inherited Bytes: 0x8 | Struct Size: 0x30
struct FRigUnit_ConvertQuaternion : FRigUnit {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FQuat Input; // Offset: 0x10 | Size: 0x10
	struct FRotator Result; // Offset: 0x20 | Size: 0xc
	char pad_0x2C[0x4]; // Offset: 0x2c | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_ConvertRotation
// Inherited Bytes: 0x8 | Struct Size: 0x30
struct FRigUnit_ConvertRotation : FRigUnit {
	// Fields
	struct FRotator Input; // Offset: 0x8 | Size: 0xc
	char pad_0x14[0xc]; // Offset: 0x14 | Size: 0xc
	struct FQuat Result; // Offset: 0x20 | Size: 0x10
};

// Object: ScriptStruct ControlRig.RigUnit_ConvertVectorRotation
// Inherited Bytes: 0x30 | Struct Size: 0x30
struct FRigUnit_ConvertVectorRotation : FRigUnit_ConvertRotation {
};

// Object: ScriptStruct ControlRig.RigUnit_ConvertEulerTransform
// Inherited Bytes: 0x8 | Struct Size: 0x60
struct FRigUnit_ConvertEulerTransform : FRigUnit {
	// Fields
	struct FEulerTransform Input; // Offset: 0x8 | Size: 0x24
	char pad_0x2C[0x4]; // Offset: 0x2c | Size: 0x4
	struct FTransform Result; // Offset: 0x30 | Size: 0x30
};

// Object: ScriptStruct ControlRig.RigUnit_ConvertTransform
// Inherited Bytes: 0x8 | Struct Size: 0x70
struct FRigUnit_ConvertTransform : FRigUnit {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FTransform Input; // Offset: 0x10 | Size: 0x30
	struct FEulerTransform Result; // Offset: 0x40 | Size: 0x24
	char pad_0x64[0xc]; // Offset: 0x64 | Size: 0xc
};

// Object: ScriptStruct ControlRig.RigUnit_DebugBaseMutable
// Inherited Bytes: 0x20 | Struct Size: 0x20
struct FRigUnit_DebugBaseMutable : FRigUnitMutable {
};

// Object: ScriptStruct ControlRig.RigUnit_DebugBase
// Inherited Bytes: 0x8 | Struct Size: 0x8
struct FRigUnit_DebugBase : FRigUnit {
};

// Object: ScriptStruct ControlRig.RigUnit_DebugBezier
// Inherited Bytes: 0x20 | Struct Size: 0xc0
struct FRigUnit_DebugBezier : FRigUnit_DebugBaseMutable {
	// Fields
	struct FCRFourPointBezier Bezier; // Offset: 0x20 | Size: 0x30
	float MinimumU; // Offset: 0x50 | Size: 0x4
	float MaximumU; // Offset: 0x54 | Size: 0x4
	struct FLinearColor Color; // Offset: 0x58 | Size: 0x10
	float Thickness; // Offset: 0x68 | Size: 0x4
	int32_t Detail; // Offset: 0x6c | Size: 0x4
	struct FName Space; // Offset: 0x70 | Size: 0x8
	char pad_0x78[0x8]; // Offset: 0x78 | Size: 0x8
	struct FTransform WorldOffset; // Offset: 0x80 | Size: 0x30
	bool bEnabled; // Offset: 0xb0 | Size: 0x1
	char pad_0xB1[0xf]; // Offset: 0xb1 | Size: 0xf
};

// Object: ScriptStruct ControlRig.RigUnit_DebugHierarchy
// Inherited Bytes: 0x20 | Struct Size: 0x80
struct FRigUnit_DebugHierarchy : FRigUnit_DebugBaseMutable {
	// Fields
	enum class EControlRigDrawHierarchyMode Mode; // Offset: 0x20 | Size: 0x1
	char pad_0x21[0x3]; // Offset: 0x21 | Size: 0x3
	float Scale; // Offset: 0x24 | Size: 0x4
	struct FLinearColor Color; // Offset: 0x28 | Size: 0x10
	float Thickness; // Offset: 0x38 | Size: 0x4
	char pad_0x3C[0x4]; // Offset: 0x3c | Size: 0x4
	struct FTransform WorldOffset; // Offset: 0x40 | Size: 0x30
	bool bEnabled; // Offset: 0x70 | Size: 0x1
	char pad_0x71[0xf]; // Offset: 0x71 | Size: 0xf
};

// Object: ScriptStruct ControlRig.RigUnit_DebugLine
// Inherited Bytes: 0x20 | Struct Size: 0xa0
struct FRigUnit_DebugLine : FRigUnit_DebugBaseMutable {
	// Fields
	struct FVector A; // Offset: 0x20 | Size: 0xc
	struct FVector B; // Offset: 0x2c | Size: 0xc
	struct FLinearColor Color; // Offset: 0x38 | Size: 0x10
	float Thickness; // Offset: 0x48 | Size: 0x4
	struct FName Space; // Offset: 0x4c | Size: 0x8
	char pad_0x54[0xc]; // Offset: 0x54 | Size: 0xc
	struct FTransform WorldOffset; // Offset: 0x60 | Size: 0x30
	bool bEnabled; // Offset: 0x90 | Size: 0x1
	char pad_0x91[0xf]; // Offset: 0x91 | Size: 0xf
};

// Object: ScriptStruct ControlRig.RigUnit_DebugLineStrip
// Inherited Bytes: 0x20 | Struct Size: 0x90
struct FRigUnit_DebugLineStrip : FRigUnit_DebugBaseMutable {
	// Fields
	struct TArray<struct FVector> Points; // Offset: 0x20 | Size: 0x10
	struct FLinearColor Color; // Offset: 0x30 | Size: 0x10
	float Thickness; // Offset: 0x40 | Size: 0x4
	struct FName Space; // Offset: 0x44 | Size: 0x8
	char pad_0x4C[0x4]; // Offset: 0x4c | Size: 0x4
	struct FTransform WorldOffset; // Offset: 0x50 | Size: 0x30
	bool bEnabled; // Offset: 0x80 | Size: 0x1
	char pad_0x81[0xf]; // Offset: 0x81 | Size: 0xf
};

// Object: ScriptStruct ControlRig.RigUnit_DebugPointMutable
// Inherited Bytes: 0x20 | Struct Size: 0x90
struct FRigUnit_DebugPointMutable : FRigUnit_DebugBaseMutable {
	// Fields
	struct FVector Vector; // Offset: 0x20 | Size: 0xc
	enum class ERigUnitDebugPointMode Mode; // Offset: 0x2c | Size: 0x1
	char pad_0x2D[0x3]; // Offset: 0x2d | Size: 0x3
	struct FLinearColor Color; // Offset: 0x30 | Size: 0x10
	float Scale; // Offset: 0x40 | Size: 0x4
	float Thickness; // Offset: 0x44 | Size: 0x4
	struct FName Space; // Offset: 0x48 | Size: 0x8
	struct FTransform WorldOffset; // Offset: 0x50 | Size: 0x30
	bool bEnabled; // Offset: 0x80 | Size: 0x1
	char pad_0x81[0xf]; // Offset: 0x81 | Size: 0xf
};

// Object: ScriptStruct ControlRig.RigUnit_DebugPoint
// Inherited Bytes: 0x8 | Struct Size: 0x80
struct FRigUnit_DebugPoint : FRigUnit_DebugBase {
	// Fields
	struct FVector Vector; // Offset: 0x8 | Size: 0xc
	enum class ERigUnitDebugPointMode Mode; // Offset: 0x14 | Size: 0x1
	char pad_0x15[0x3]; // Offset: 0x15 | Size: 0x3
	struct FLinearColor Color; // Offset: 0x18 | Size: 0x10
	float Scale; // Offset: 0x28 | Size: 0x4
	float Thickness; // Offset: 0x2c | Size: 0x4
	struct FName Space; // Offset: 0x30 | Size: 0x8
	char pad_0x38[0x8]; // Offset: 0x38 | Size: 0x8
	struct FTransform WorldOffset; // Offset: 0x40 | Size: 0x30
	bool bEnabled; // Offset: 0x70 | Size: 0x1
	char pad_0x71[0xf]; // Offset: 0x71 | Size: 0xf
};

// Object: ScriptStruct ControlRig.RigUnit_DebugArc
// Inherited Bytes: 0x20 | Struct Size: 0xc0
struct FRigUnit_DebugArc : FRigUnit_DebugBaseMutable {
	// Fields
	struct FTransform Transform; // Offset: 0x20 | Size: 0x30
	struct FLinearColor Color; // Offset: 0x50 | Size: 0x10
	float Radius; // Offset: 0x60 | Size: 0x4
	float MinimumDegrees; // Offset: 0x64 | Size: 0x4
	float MaximumDegrees; // Offset: 0x68 | Size: 0x4
	float Thickness; // Offset: 0x6c | Size: 0x4
	int32_t Detail; // Offset: 0x70 | Size: 0x4
	struct FName Space; // Offset: 0x74 | Size: 0x8
	char pad_0x7C[0x4]; // Offset: 0x7c | Size: 0x4
	struct FTransform WorldOffset; // Offset: 0x80 | Size: 0x30
	bool bEnabled; // Offset: 0xb0 | Size: 0x1
	char pad_0xB1[0xf]; // Offset: 0xb1 | Size: 0xf
};

// Object: ScriptStruct ControlRig.RigUnit_DebugRectangle
// Inherited Bytes: 0x20 | Struct Size: 0xb0
struct FRigUnit_DebugRectangle : FRigUnit_DebugBaseMutable {
	// Fields
	struct FTransform Transform; // Offset: 0x20 | Size: 0x30
	struct FLinearColor Color; // Offset: 0x50 | Size: 0x10
	float Scale; // Offset: 0x60 | Size: 0x4
	float Thickness; // Offset: 0x64 | Size: 0x4
	struct FName Space; // Offset: 0x68 | Size: 0x8
	struct FTransform WorldOffset; // Offset: 0x70 | Size: 0x30
	bool bEnabled; // Offset: 0xa0 | Size: 0x1
	char pad_0xA1[0xf]; // Offset: 0xa1 | Size: 0xf
};

// Object: ScriptStruct ControlRig.RigUnit_DebugTransformArrayMutable
// Inherited Bytes: 0x20 | Struct Size: 0xb0
struct FRigUnit_DebugTransformArrayMutable : FRigUnit_DebugBaseMutable {
	// Fields
	struct TArray<struct FTransform> Transforms; // Offset: 0x20 | Size: 0x10
	enum class ERigUnitDebugTransformMode Mode; // Offset: 0x30 | Size: 0x1
	char pad_0x31[0x3]; // Offset: 0x31 | Size: 0x3
	struct FLinearColor Color; // Offset: 0x34 | Size: 0x10
	float Thickness; // Offset: 0x44 | Size: 0x4
	float Scale; // Offset: 0x48 | Size: 0x4
	struct FName Space; // Offset: 0x4c | Size: 0x8
	char pad_0x54[0xc]; // Offset: 0x54 | Size: 0xc
	struct FTransform WorldOffset; // Offset: 0x60 | Size: 0x30
	bool bEnabled; // Offset: 0x90 | Size: 0x1
	char pad_0x91[0x7]; // Offset: 0x91 | Size: 0x7
	struct FRigUnit_DebugTransformArrayMutable_WorkData WorkData; // Offset: 0x98 | Size: 0x10
	char pad_0xA8[0x8]; // Offset: 0xa8 | Size: 0x8
};

// Object: ScriptStruct ControlRig.RigUnit_DebugTransformArrayMutable_WorkData
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FRigUnit_DebugTransformArrayMutable_WorkData {
	// Fields
	struct TArray<struct FTransform> DrawTransforms; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct ControlRig.RigUnit_DebugTransformMutable
// Inherited Bytes: 0x20 | Struct Size: 0xc0
struct FRigUnit_DebugTransformMutable : FRigUnit_DebugBaseMutable {
	// Fields
	struct FTransform Transform; // Offset: 0x20 | Size: 0x30
	enum class ERigUnitDebugTransformMode Mode; // Offset: 0x50 | Size: 0x1
	char pad_0x51[0x3]; // Offset: 0x51 | Size: 0x3
	struct FLinearColor Color; // Offset: 0x54 | Size: 0x10
	float Thickness; // Offset: 0x64 | Size: 0x4
	float Scale; // Offset: 0x68 | Size: 0x4
	struct FName Space; // Offset: 0x6c | Size: 0x8
	char pad_0x74[0xc]; // Offset: 0x74 | Size: 0xc
	struct FTransform WorldOffset; // Offset: 0x80 | Size: 0x30
	bool bEnabled; // Offset: 0xb0 | Size: 0x1
	char pad_0xB1[0xf]; // Offset: 0xb1 | Size: 0xf
};

// Object: ScriptStruct ControlRig.RigUnit_DebugTransform
// Inherited Bytes: 0x8 | Struct Size: 0xb0
struct FRigUnit_DebugTransform : FRigUnit_DebugBase {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FTransform Transform; // Offset: 0x10 | Size: 0x30
	enum class ERigUnitDebugTransformMode Mode; // Offset: 0x40 | Size: 0x1
	char pad_0x41[0x3]; // Offset: 0x41 | Size: 0x3
	struct FLinearColor Color; // Offset: 0x44 | Size: 0x10
	float Thickness; // Offset: 0x54 | Size: 0x4
	float Scale; // Offset: 0x58 | Size: 0x4
	struct FName Space; // Offset: 0x5c | Size: 0x8
	char pad_0x64[0xc]; // Offset: 0x64 | Size: 0xc
	struct FTransform WorldOffset; // Offset: 0x70 | Size: 0x30
	bool bEnabled; // Offset: 0xa0 | Size: 0x1
	char pad_0xA1[0xf]; // Offset: 0xa1 | Size: 0xf
};

// Object: ScriptStruct ControlRig.RigUnit_DeltaFromPreviousTransform
// Inherited Bytes: 0x8 | Struct Size: 0xd0
struct FRigUnit_DeltaFromPreviousTransform : FRigUnit_SimBase {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FTransform Value; // Offset: 0x10 | Size: 0x30
	struct FTransform Delta; // Offset: 0x40 | Size: 0x30
	struct FTransform PreviousValue; // Offset: 0x70 | Size: 0x30
	struct FTransform Cache; // Offset: 0xa0 | Size: 0x30
};

// Object: ScriptStruct ControlRig.RigUnit_DeltaFromPreviousQuat
// Inherited Bytes: 0x8 | Struct Size: 0x50
struct FRigUnit_DeltaFromPreviousQuat : FRigUnit_SimBase {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FQuat Value; // Offset: 0x10 | Size: 0x10
	struct FQuat Delta; // Offset: 0x20 | Size: 0x10
	struct FQuat PreviousValue; // Offset: 0x30 | Size: 0x10
	struct FQuat Cache; // Offset: 0x40 | Size: 0x10
};

// Object: ScriptStruct ControlRig.RigUnit_DeltaFromPreviousVector
// Inherited Bytes: 0x8 | Struct Size: 0x38
struct FRigUnit_DeltaFromPreviousVector : FRigUnit_SimBase {
	// Fields
	struct FVector Value; // Offset: 0x8 | Size: 0xc
	struct FVector Delta; // Offset: 0x14 | Size: 0xc
	struct FVector PreviousValue; // Offset: 0x20 | Size: 0xc
	struct FVector Cache; // Offset: 0x2c | Size: 0xc
};

// Object: ScriptStruct ControlRig.RigUnit_DeltaFromPreviousFloat
// Inherited Bytes: 0x8 | Struct Size: 0x18
struct FRigUnit_DeltaFromPreviousFloat : FRigUnit_SimBase {
	// Fields
	float Value; // Offset: 0x8 | Size: 0x4
	float Delta; // Offset: 0xc | Size: 0x4
	float PreviousValue; // Offset: 0x10 | Size: 0x4
	float Cache; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_DistributeRotation
// Inherited Bytes: 0x20 | Struct Size: 0x98
struct FRigUnit_DistributeRotation : FRigUnit_HighlevelBaseMutable {
	// Fields
	struct FName StartBone; // Offset: 0x20 | Size: 0x8
	struct FName EndBone; // Offset: 0x28 | Size: 0x8
	struct TArray<struct FRigUnit_DistributeRotation_Rotation> Rotations; // Offset: 0x30 | Size: 0x10
	enum class EControlRigAnimEasingType RotationEaseType; // Offset: 0x40 | Size: 0x1
	bool bPropagateToChildren; // Offset: 0x41 | Size: 0x1
	char pad_0x42[0x6]; // Offset: 0x42 | Size: 0x6
	struct FRigUnit_DistributeRotation_WorkData WorkData; // Offset: 0x48 | Size: 0x50
};

// Object: ScriptStruct ControlRig.RigUnit_DistributeRotation_WorkData
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FRigUnit_DistributeRotation_WorkData {
	// Fields
	struct TArray<int32_t> BoneIndices; // Offset: 0x0 | Size: 0x10
	struct TArray<int32_t> BoneRotationA; // Offset: 0x10 | Size: 0x10
	struct TArray<int32_t> BoneRotationB; // Offset: 0x20 | Size: 0x10
	struct TArray<float> BoneRotationT; // Offset: 0x30 | Size: 0x10
	struct TArray<struct FTransform> BoneLocalTransforms; // Offset: 0x40 | Size: 0x10
};

// Object: ScriptStruct ControlRig.RigUnit_DistributeRotation_Rotation
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FRigUnit_DistributeRotation_Rotation {
	// Fields
	struct FQuat Rotation; // Offset: 0x0 | Size: 0x10
	float Ratio; // Offset: 0x10 | Size: 0x4
	char pad_0x14[0xc]; // Offset: 0x14 | Size: 0xc
};

// Object: ScriptStruct ControlRig.RigUnit_DrawContainerSetTransform
// Inherited Bytes: 0x20 | Struct Size: 0x60
struct FRigUnit_DrawContainerSetTransform : FRigUnitMutable {
	// Fields
	struct FName InstructionName; // Offset: 0x20 | Size: 0x8
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
	struct FTransform Transform; // Offset: 0x30 | Size: 0x30
};

// Object: ScriptStruct ControlRig.RigUnit_DrawContainerSetThickness
// Inherited Bytes: 0x20 | Struct Size: 0x30
struct FRigUnit_DrawContainerSetThickness : FRigUnitMutable {
	// Fields
	struct FName InstructionName; // Offset: 0x20 | Size: 0x8
	float Thickness; // Offset: 0x28 | Size: 0x4
	char pad_0x2C[0x4]; // Offset: 0x2c | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_DrawContainerSetColor
// Inherited Bytes: 0x20 | Struct Size: 0x38
struct FRigUnit_DrawContainerSetColor : FRigUnitMutable {
	// Fields
	struct FName InstructionName; // Offset: 0x20 | Size: 0x8
	struct FLinearColor Color; // Offset: 0x28 | Size: 0x10
};

// Object: ScriptStruct ControlRig.RigUnit_DrawContainerGetInstruction
// Inherited Bytes: 0x8 | Struct Size: 0x50
struct FRigUnit_DrawContainerGetInstruction : FRigUnit {
	// Fields
	struct FName InstructionName; // Offset: 0x8 | Size: 0x8
	struct FLinearColor Color; // Offset: 0x10 | Size: 0x10
	struct FTransform Transform; // Offset: 0x20 | Size: 0x30
};

// Object: ScriptStruct ControlRig.RigUnit_FABRIK
// Inherited Bytes: 0x20 | Struct Size: 0xa0
struct FRigUnit_FABRIK : FRigUnit_HighlevelBaseMutable {
	// Fields
	struct FName StartBone; // Offset: 0x20 | Size: 0x8
	struct FName EffectorBone; // Offset: 0x28 | Size: 0x8
	struct FTransform EffectorTransform; // Offset: 0x30 | Size: 0x30
	float Precision; // Offset: 0x60 | Size: 0x4
	float Weight; // Offset: 0x64 | Size: 0x4
	bool bPropagateToChildren; // Offset: 0x68 | Size: 0x1
	char pad_0x69[0x3]; // Offset: 0x69 | Size: 0x3
	int32_t MaxIterations; // Offset: 0x6c | Size: 0x4
	struct FRigUnit_FABRIK_WorkData WorkData; // Offset: 0x70 | Size: 0x28
	char pad_0x98[0x8]; // Offset: 0x98 | Size: 0x8
};

// Object: ScriptStruct ControlRig.RigUnit_FABRIK_WorkData
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FRigUnit_FABRIK_WorkData {
	// Fields
	struct TArray<struct FFABRIKChainLink> Chain; // Offset: 0x0 | Size: 0x10
	struct TArray<int32_t> BoneIndices; // Offset: 0x10 | Size: 0x10
	int32_t EffectorIndex; // Offset: 0x20 | Size: 0x4
	char pad_0x24[0x4]; // Offset: 0x24 | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_FitChainToCurve
// Inherited Bytes: 0x20 | Struct Size: 0x1b0
struct FRigUnit_FitChainToCurve : FRigUnit_HighlevelBaseMutable {
	// Fields
	struct FName StartBone; // Offset: 0x20 | Size: 0x8
	struct FName EndBone; // Offset: 0x28 | Size: 0x8
	struct FCRFourPointBezier Bezier; // Offset: 0x30 | Size: 0x30
	enum class EControlRigCurveAlignment Alignment; // Offset: 0x60 | Size: 0x1
	char pad_0x61[0x3]; // Offset: 0x61 | Size: 0x3
	float Minimum; // Offset: 0x64 | Size: 0x4
	float Maximum; // Offset: 0x68 | Size: 0x4
	int32_t SamplingPrecision; // Offset: 0x6c | Size: 0x4
	struct FVector PrimaryAxis; // Offset: 0x70 | Size: 0xc
	struct FVector SecondaryAxis; // Offset: 0x7c | Size: 0xc
	struct FVector PoleVectorPosition; // Offset: 0x88 | Size: 0xc
	char pad_0x94[0x4]; // Offset: 0x94 | Size: 0x4
	struct TArray<struct FRigUnit_FitChainToCurve_Rotation> Rotations; // Offset: 0x98 | Size: 0x10
	enum class EControlRigAnimEasingType RotationEaseType; // Offset: 0xa8 | Size: 0x1
	bool bPropagateToChildren; // Offset: 0xa9 | Size: 0x1
	char pad_0xAA[0x6]; // Offset: 0xaa | Size: 0x6
	struct FRigUnit_FitChainToCurve_DebugSettings DebugSettings; // Offset: 0xb0 | Size: 0x60
	struct FRigUnit_FitChainToCurve_WorkData WorkData; // Offset: 0x110 | Size: 0x98
	char pad_0x1A8[0x8]; // Offset: 0x1a8 | Size: 0x8
};

// Object: ScriptStruct ControlRig.RigUnit_FitChainToCurve_WorkData
// Inherited Bytes: 0x0 | Struct Size: 0x98
struct FRigUnit_FitChainToCurve_WorkData {
	// Fields
	float ChainLength; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct TArray<struct FVector> BonePositions; // Offset: 0x8 | Size: 0x10
	struct TArray<float> BoneSegments; // Offset: 0x18 | Size: 0x10
	struct TArray<struct FVector> CurvePositions; // Offset: 0x28 | Size: 0x10
	struct TArray<float> CurveSegments; // Offset: 0x38 | Size: 0x10
	struct TArray<int32_t> BoneIndices; // Offset: 0x48 | Size: 0x10
	struct TArray<int32_t> BoneRotationA; // Offset: 0x58 | Size: 0x10
	struct TArray<int32_t> BoneRotationB; // Offset: 0x68 | Size: 0x10
	struct TArray<float> BoneRotationT; // Offset: 0x78 | Size: 0x10
	struct TArray<struct FTransform> BoneLocalTransforms; // Offset: 0x88 | Size: 0x10
};

// Object: ScriptStruct ControlRig.RigUnit_FitChainToCurve_DebugSettings
// Inherited Bytes: 0x0 | Struct Size: 0x60
struct FRigUnit_FitChainToCurve_DebugSettings {
	// Fields
	bool bEnabled; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	float Scale; // Offset: 0x4 | Size: 0x4
	struct FLinearColor CurveColor; // Offset: 0x8 | Size: 0x10
	struct FLinearColor SegmentsColor; // Offset: 0x18 | Size: 0x10
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
	struct FTransform WorldOffset; // Offset: 0x30 | Size: 0x30
};

// Object: ScriptStruct ControlRig.RigUnit_FitChainToCurve_Rotation
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FRigUnit_FitChainToCurve_Rotation {
	// Fields
	struct FQuat Rotation; // Offset: 0x0 | Size: 0x10
	float Ratio; // Offset: 0x10 | Size: 0x4
	char pad_0x14[0xc]; // Offset: 0x14 | Size: 0xc
};

// Object: ScriptStruct ControlRig.RigUnit_MapRange_Float
// Inherited Bytes: 0x8 | Struct Size: 0x20
struct FRigUnit_MapRange_Float : FRigUnit {
	// Fields
	float Value; // Offset: 0x8 | Size: 0x4
	float MinIn; // Offset: 0xc | Size: 0x4
	float MaxIn; // Offset: 0x10 | Size: 0x4
	float MinOut; // Offset: 0x14 | Size: 0x4
	float MaxOut; // Offset: 0x18 | Size: 0x4
	float Result; // Offset: 0x1c | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_Clamp_Float
// Inherited Bytes: 0x8 | Struct Size: 0x18
struct FRigUnit_Clamp_Float : FRigUnit {
	// Fields
	float Value; // Offset: 0x8 | Size: 0x4
	float Min; // Offset: 0xc | Size: 0x4
	float Max; // Offset: 0x10 | Size: 0x4
	float Result; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_BinaryFloatOp
// Inherited Bytes: 0x8 | Struct Size: 0x18
struct FRigUnit_BinaryFloatOp : FRigUnit {
	// Fields
	float Argument0; // Offset: 0x8 | Size: 0x4
	float Argument1; // Offset: 0xc | Size: 0x4
	float Result; // Offset: 0x10 | Size: 0x4
	char pad_0x14[0x4]; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_Divide_FloatFloat
// Inherited Bytes: 0x18 | Struct Size: 0x18
struct FRigUnit_Divide_FloatFloat : FRigUnit_BinaryFloatOp {
};

// Object: ScriptStruct ControlRig.RigUnit_Subtract_FloatFloat
// Inherited Bytes: 0x18 | Struct Size: 0x18
struct FRigUnit_Subtract_FloatFloat : FRigUnit_BinaryFloatOp {
};

// Object: ScriptStruct ControlRig.RigUnit_Add_FloatFloat
// Inherited Bytes: 0x18 | Struct Size: 0x18
struct FRigUnit_Add_FloatFloat : FRigUnit_BinaryFloatOp {
};

// Object: ScriptStruct ControlRig.RigUnit_Multiply_FloatFloat
// Inherited Bytes: 0x18 | Struct Size: 0x18
struct FRigUnit_Multiply_FloatFloat : FRigUnit_BinaryFloatOp {
};

// Object: ScriptStruct ControlRig.RigUnit_GetBoneTransform
// Inherited Bytes: 0x8 | Struct Size: 0x60
struct FRigUnit_GetBoneTransform : FRigUnit {
	// Fields
	struct FName Bone; // Offset: 0x8 | Size: 0x8
	enum class EBoneGetterSetterMode Space; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0xf]; // Offset: 0x11 | Size: 0xf
	struct FTransform Transform; // Offset: 0x20 | Size: 0x30
	int32_t CachedBoneIndex; // Offset: 0x50 | Size: 0x4
	char pad_0x54[0xc]; // Offset: 0x54 | Size: 0xc
};

// Object: ScriptStruct ControlRig.RigUnit_GetControlInitialTransform
// Inherited Bytes: 0x8 | Struct Size: 0x60
struct FRigUnit_GetControlInitialTransform : FRigUnit {
	// Fields
	struct FName Control; // Offset: 0x8 | Size: 0x8
	enum class EBoneGetterSetterMode Space; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0xf]; // Offset: 0x11 | Size: 0xf
	struct FTransform Transform; // Offset: 0x20 | Size: 0x30
	int32_t CachedControlIndex; // Offset: 0x50 | Size: 0x4
	char pad_0x54[0xc]; // Offset: 0x54 | Size: 0xc
};

// Object: ScriptStruct ControlRig.RigUnit_GetControlTransform
// Inherited Bytes: 0x8 | Struct Size: 0xc0
struct FRigUnit_GetControlTransform : FRigUnit {
	// Fields
	struct FName Control; // Offset: 0x8 | Size: 0x8
	enum class EBoneGetterSetterMode Space; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0xf]; // Offset: 0x11 | Size: 0xf
	struct FTransform Transform; // Offset: 0x20 | Size: 0x30
	struct FTransform Minimum; // Offset: 0x50 | Size: 0x30
	struct FTransform Maximum; // Offset: 0x80 | Size: 0x30
	int32_t CachedControlIndex; // Offset: 0xb0 | Size: 0x4
	char pad_0xB4[0xc]; // Offset: 0xb4 | Size: 0xc
};

// Object: ScriptStruct ControlRig.RigUnit_GetControlRotator
// Inherited Bytes: 0x8 | Struct Size: 0x40
struct FRigUnit_GetControlRotator : FRigUnit {
	// Fields
	struct FName Control; // Offset: 0x8 | Size: 0x8
	enum class EBoneGetterSetterMode Space; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x3]; // Offset: 0x11 | Size: 0x3
	struct FRotator Rotator; // Offset: 0x14 | Size: 0xc
	struct FRotator Minimum; // Offset: 0x20 | Size: 0xc
	struct FRotator Maximum; // Offset: 0x2c | Size: 0xc
	int32_t CachedControlIndex; // Offset: 0x38 | Size: 0x4
	char pad_0x3C[0x4]; // Offset: 0x3c | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_GetControlVector
// Inherited Bytes: 0x8 | Struct Size: 0x40
struct FRigUnit_GetControlVector : FRigUnit {
	// Fields
	struct FName Control; // Offset: 0x8 | Size: 0x8
	enum class EBoneGetterSetterMode Space; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x3]; // Offset: 0x11 | Size: 0x3
	struct FVector Vector; // Offset: 0x14 | Size: 0xc
	struct FVector Minimum; // Offset: 0x20 | Size: 0xc
	struct FVector Maximum; // Offset: 0x2c | Size: 0xc
	int32_t CachedControlIndex; // Offset: 0x38 | Size: 0x4
	char pad_0x3C[0x4]; // Offset: 0x3c | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_GetControlVector2D
// Inherited Bytes: 0x8 | Struct Size: 0x30
struct FRigUnit_GetControlVector2D : FRigUnit {
	// Fields
	struct FName Control; // Offset: 0x8 | Size: 0x8
	struct FVector2D Vector; // Offset: 0x10 | Size: 0x8
	struct FVector2D Minimum; // Offset: 0x18 | Size: 0x8
	struct FVector2D Maximum; // Offset: 0x20 | Size: 0x8
	int32_t CachedControlIndex; // Offset: 0x28 | Size: 0x4
	char pad_0x2C[0x4]; // Offset: 0x2c | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_GetControlFloat
// Inherited Bytes: 0x8 | Struct Size: 0x20
struct FRigUnit_GetControlFloat : FRigUnit {
	// Fields
	struct FName Control; // Offset: 0x8 | Size: 0x8
	float FloatValue; // Offset: 0x10 | Size: 0x4
	float Minimum; // Offset: 0x14 | Size: 0x4
	float Maximum; // Offset: 0x18 | Size: 0x4
	int32_t CachedControlIndex; // Offset: 0x1c | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_GetControlBool
// Inherited Bytes: 0x8 | Struct Size: 0x18
struct FRigUnit_GetControlBool : FRigUnit {
	// Fields
	struct FName Control; // Offset: 0x8 | Size: 0x8
	bool BoolValue; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x3]; // Offset: 0x11 | Size: 0x3
	int32_t CachedControlIndex; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_GetCurveValue
// Inherited Bytes: 0x8 | Struct Size: 0x18
struct FRigUnit_GetCurveValue : FRigUnit {
	// Fields
	struct FName Curve; // Offset: 0x8 | Size: 0x8
	float Value; // Offset: 0x10 | Size: 0x4
	int32_t CachedCurveIndex; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_GetDeltaTime
// Inherited Bytes: 0x8 | Struct Size: 0x10
struct FRigUnit_GetDeltaTime : FRigUnit_AnimBase {
	// Fields
	float Result; // Offset: 0x8 | Size: 0x4
	char pad_0xC[0x4]; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_GetInitialBoneTransform
// Inherited Bytes: 0x8 | Struct Size: 0x60
struct FRigUnit_GetInitialBoneTransform : FRigUnit {
	// Fields
	struct FName Bone; // Offset: 0x8 | Size: 0x8
	enum class EBoneGetterSetterMode Space; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0xf]; // Offset: 0x11 | Size: 0xf
	struct FTransform Transform; // Offset: 0x20 | Size: 0x30
	int32_t CachedBoneIndex; // Offset: 0x50 | Size: 0x4
	char pad_0x54[0xc]; // Offset: 0x54 | Size: 0xc
};

// Object: ScriptStruct ControlRig.RigUnit_GetJointTransform
// Inherited Bytes: 0x20 | Struct Size: 0xa0
struct FRigUnit_GetJointTransform : FRigUnitMutable {
	// Fields
	struct FName Joint; // Offset: 0x20 | Size: 0x8
	enum class ETransformGetterType Type; // Offset: 0x28 | Size: 0x1
	enum class ETransformSpaceMode TransformSpace; // Offset: 0x29 | Size: 0x1
	char pad_0x2A[0x6]; // Offset: 0x2a | Size: 0x6
	struct FTransform BaseTransform; // Offset: 0x30 | Size: 0x30
	struct FName BaseJoint; // Offset: 0x60 | Size: 0x8
	char pad_0x68[0x8]; // Offset: 0x68 | Size: 0x8
	struct FTransform Output; // Offset: 0x70 | Size: 0x30
};

// Object: ScriptStruct ControlRig.RigUnit_GetRelativeBoneTransform
// Inherited Bytes: 0x8 | Struct Size: 0x60
struct FRigUnit_GetRelativeBoneTransform : FRigUnit {
	// Fields
	struct FName Bone; // Offset: 0x8 | Size: 0x8
	struct FName Space; // Offset: 0x10 | Size: 0x8
	char pad_0x18[0x8]; // Offset: 0x18 | Size: 0x8
	struct FTransform Transform; // Offset: 0x20 | Size: 0x30
	int32_t CachedBoneIndex; // Offset: 0x50 | Size: 0x4
	int32_t CachedSpaceIndex; // Offset: 0x54 | Size: 0x4
	char pad_0x58[0x8]; // Offset: 0x58 | Size: 0x8
};

// Object: ScriptStruct ControlRig.RigUnit_GetSpaceTransform
// Inherited Bytes: 0x8 | Struct Size: 0x60
struct FRigUnit_GetSpaceTransform : FRigUnit {
	// Fields
	struct FName Space; // Offset: 0x8 | Size: 0x8
	enum class EBoneGetterSetterMode SpaceType; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0xf]; // Offset: 0x11 | Size: 0xf
	struct FTransform Transform; // Offset: 0x20 | Size: 0x30
	int32_t CachedSpaceIndex; // Offset: 0x50 | Size: 0x4
	char pad_0x54[0xc]; // Offset: 0x54 | Size: 0xc
};

// Object: ScriptStruct ControlRig.RigUnit_GetWorldTime
// Inherited Bytes: 0x8 | Struct Size: 0x28
struct FRigUnit_GetWorldTime : FRigUnit_AnimBase {
	// Fields
	float Year; // Offset: 0x8 | Size: 0x4
	float Month; // Offset: 0xc | Size: 0x4
	float Day; // Offset: 0x10 | Size: 0x4
	float WeekDay; // Offset: 0x14 | Size: 0x4
	float Hours; // Offset: 0x18 | Size: 0x4
	float Minutes; // Offset: 0x1c | Size: 0x4
	float Seconds; // Offset: 0x20 | Size: 0x4
	float OverallSeconds; // Offset: 0x24 | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_HighlevelBase
// Inherited Bytes: 0x8 | Struct Size: 0x8
struct FRigUnit_HighlevelBase : FRigUnit {
};

// Object: ScriptStruct ControlRig.RigUnit_KalmanTransform
// Inherited Bytes: 0x8 | Struct Size: 0xa0
struct FRigUnit_KalmanTransform : FRigUnit_SimBase {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FTransform Value; // Offset: 0x10 | Size: 0x30
	int32_t BufferSize; // Offset: 0x40 | Size: 0x4
	char pad_0x44[0xc]; // Offset: 0x44 | Size: 0xc
	struct FTransform Result; // Offset: 0x50 | Size: 0x30
	struct TArray<struct FTransform> Buffer; // Offset: 0x80 | Size: 0x10
	int32_t LastInsertIndex; // Offset: 0x90 | Size: 0x4
	char pad_0x94[0xc]; // Offset: 0x94 | Size: 0xc
};

// Object: ScriptStruct ControlRig.RigUnit_KalmanVector
// Inherited Bytes: 0x8 | Struct Size: 0x40
struct FRigUnit_KalmanVector : FRigUnit_SimBase {
	// Fields
	struct FVector Value; // Offset: 0x8 | Size: 0xc
	int32_t BufferSize; // Offset: 0x14 | Size: 0x4
	struct FVector Result; // Offset: 0x18 | Size: 0xc
	char pad_0x24[0x4]; // Offset: 0x24 | Size: 0x4
	struct TArray<struct FVector> Buffer; // Offset: 0x28 | Size: 0x10
	int32_t LastInsertIndex; // Offset: 0x38 | Size: 0x4
	char pad_0x3C[0x4]; // Offset: 0x3c | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_KalmanFloat
// Inherited Bytes: 0x8 | Struct Size: 0x30
struct FRigUnit_KalmanFloat : FRigUnit_SimBase {
	// Fields
	float Value; // Offset: 0x8 | Size: 0x4
	int32_t BufferSize; // Offset: 0xc | Size: 0x4
	float Result; // Offset: 0x10 | Size: 0x4
	char pad_0x14[0x4]; // Offset: 0x14 | Size: 0x4
	struct TArray<float> Buffer; // Offset: 0x18 | Size: 0x10
	int32_t LastInsertIndex; // Offset: 0x28 | Size: 0x4
	char pad_0x2C[0x4]; // Offset: 0x2c | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_MathBase
// Inherited Bytes: 0x8 | Struct Size: 0x8
struct FRigUnit_MathBase : FRigUnit {
};

// Object: ScriptStruct ControlRig.RigUnit_MathBoolBase
// Inherited Bytes: 0x8 | Struct Size: 0x8
struct FRigUnit_MathBoolBase : FRigUnit_MathBase {
};

// Object: ScriptStruct ControlRig.RigUnit_MathBoolNotEquals
// Inherited Bytes: 0x8 | Struct Size: 0x10
struct FRigUnit_MathBoolNotEquals : FRigUnit_MathBoolBase {
	// Fields
	bool A; // Offset: 0x8 | Size: 0x1
	bool B; // Offset: 0x9 | Size: 0x1
	bool Result; // Offset: 0xa | Size: 0x1
	char pad_0xB[0x5]; // Offset: 0xb | Size: 0x5
};

// Object: ScriptStruct ControlRig.RigUnit_MathBoolEquals
// Inherited Bytes: 0x8 | Struct Size: 0x10
struct FRigUnit_MathBoolEquals : FRigUnit_MathBoolBase {
	// Fields
	bool A; // Offset: 0x8 | Size: 0x1
	bool B; // Offset: 0x9 | Size: 0x1
	bool Result; // Offset: 0xa | Size: 0x1
	char pad_0xB[0x5]; // Offset: 0xb | Size: 0x5
};

// Object: ScriptStruct ControlRig.RigUnit_MathBoolBinaryOp
// Inherited Bytes: 0x8 | Struct Size: 0x10
struct FRigUnit_MathBoolBinaryOp : FRigUnit_MathBoolBase {
	// Fields
	bool A; // Offset: 0x8 | Size: 0x1
	bool B; // Offset: 0x9 | Size: 0x1
	bool Result; // Offset: 0xa | Size: 0x1
	char pad_0xB[0x5]; // Offset: 0xb | Size: 0x5
};

// Object: ScriptStruct ControlRig.RigUnit_MathBoolOr
// Inherited Bytes: 0x10 | Struct Size: 0x10
struct FRigUnit_MathBoolOr : FRigUnit_MathBoolBinaryOp {
};

// Object: ScriptStruct ControlRig.RigUnit_MathBoolNand
// Inherited Bytes: 0x10 | Struct Size: 0x10
struct FRigUnit_MathBoolNand : FRigUnit_MathBoolBinaryOp {
};

// Object: ScriptStruct ControlRig.RigUnit_MathBoolAnd
// Inherited Bytes: 0x10 | Struct Size: 0x10
struct FRigUnit_MathBoolAnd : FRigUnit_MathBoolBinaryOp {
};

// Object: ScriptStruct ControlRig.RigUnit_MathBoolUnaryOp
// Inherited Bytes: 0x8 | Struct Size: 0x10
struct FRigUnit_MathBoolUnaryOp : FRigUnit_MathBoolBase {
	// Fields
	bool Value; // Offset: 0x8 | Size: 0x1
	bool Result; // Offset: 0x9 | Size: 0x1
	char pad_0xA[0x6]; // Offset: 0xa | Size: 0x6
};

// Object: ScriptStruct ControlRig.RigUnit_MathBoolNot
// Inherited Bytes: 0x10 | Struct Size: 0x10
struct FRigUnit_MathBoolNot : FRigUnit_MathBoolUnaryOp {
};

// Object: ScriptStruct ControlRig.RigUnit_MathBoolConstant
// Inherited Bytes: 0x8 | Struct Size: 0x10
struct FRigUnit_MathBoolConstant : FRigUnit_MathBoolBase {
	// Fields
	bool Value; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x7]; // Offset: 0x9 | Size: 0x7
};

// Object: ScriptStruct ControlRig.RigUnit_MathBoolConstFalse
// Inherited Bytes: 0x10 | Struct Size: 0x10
struct FRigUnit_MathBoolConstFalse : FRigUnit_MathBoolConstant {
};

// Object: ScriptStruct ControlRig.RigUnit_MathBoolConstTrue
// Inherited Bytes: 0x10 | Struct Size: 0x10
struct FRigUnit_MathBoolConstTrue : FRigUnit_MathBoolConstant {
};

// Object: ScriptStruct ControlRig.RigUnit_MathColorBase
// Inherited Bytes: 0x8 | Struct Size: 0x8
struct FRigUnit_MathColorBase : FRigUnit_MathBase {
};

// Object: ScriptStruct ControlRig.RigUnit_MathColorLerp
// Inherited Bytes: 0x8 | Struct Size: 0x40
struct FRigUnit_MathColorLerp : FRigUnit_MathColorBase {
	// Fields
	struct FLinearColor A; // Offset: 0x8 | Size: 0x10
	struct FLinearColor B; // Offset: 0x18 | Size: 0x10
	float T; // Offset: 0x28 | Size: 0x4
	struct FLinearColor Result; // Offset: 0x2c | Size: 0x10
	char pad_0x3C[0x4]; // Offset: 0x3c | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_MathColorBinaryOp
// Inherited Bytes: 0x8 | Struct Size: 0x38
struct FRigUnit_MathColorBinaryOp : FRigUnit_MathColorBase {
	// Fields
	struct FLinearColor A; // Offset: 0x8 | Size: 0x10
	struct FLinearColor B; // Offset: 0x18 | Size: 0x10
	struct FLinearColor Result; // Offset: 0x28 | Size: 0x10
};

// Object: ScriptStruct ControlRig.RigUnit_MathColorMul
// Inherited Bytes: 0x38 | Struct Size: 0x38
struct FRigUnit_MathColorMul : FRigUnit_MathColorBinaryOp {
};

// Object: ScriptStruct ControlRig.RigUnit_MathColorSub
// Inherited Bytes: 0x38 | Struct Size: 0x38
struct FRigUnit_MathColorSub : FRigUnit_MathColorBinaryOp {
};

// Object: ScriptStruct ControlRig.RigUnit_MathColorAdd
// Inherited Bytes: 0x38 | Struct Size: 0x38
struct FRigUnit_MathColorAdd : FRigUnit_MathColorBinaryOp {
};

// Object: ScriptStruct ControlRig.RigUnit_MathColorFromFloat
// Inherited Bytes: 0x8 | Struct Size: 0x20
struct FRigUnit_MathColorFromFloat : FRigUnit_MathColorBase {
	// Fields
	float Value; // Offset: 0x8 | Size: 0x4
	struct FLinearColor Result; // Offset: 0xc | Size: 0x10
	char pad_0x1C[0x4]; // Offset: 0x1c | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_MathFloatBase
// Inherited Bytes: 0x8 | Struct Size: 0x8
struct FRigUnit_MathFloatBase : FRigUnit_MathBase {
};

// Object: ScriptStruct ControlRig.RigUnit_MathFloatLawOfCosine
// Inherited Bytes: 0x8 | Struct Size: 0x28
struct FRigUnit_MathFloatLawOfCosine : FRigUnit_MathFloatBase {
	// Fields
	float A; // Offset: 0x8 | Size: 0x4
	float B; // Offset: 0xc | Size: 0x4
	float C; // Offset: 0x10 | Size: 0x4
	float AlphaAngle; // Offset: 0x14 | Size: 0x4
	float BetaAngle; // Offset: 0x18 | Size: 0x4
	float GammaAngle; // Offset: 0x1c | Size: 0x4
	bool bValid; // Offset: 0x20 | Size: 0x1
	char pad_0x21[0x7]; // Offset: 0x21 | Size: 0x7
};

// Object: ScriptStruct ControlRig.RigUnit_MathFloatUnaryOp
// Inherited Bytes: 0x8 | Struct Size: 0x10
struct FRigUnit_MathFloatUnaryOp : FRigUnit_MathFloatBase {
	// Fields
	float Value; // Offset: 0x8 | Size: 0x4
	float Result; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_MathFloatAtan
// Inherited Bytes: 0x10 | Struct Size: 0x10
struct FRigUnit_MathFloatAtan : FRigUnit_MathFloatUnaryOp {
};

// Object: ScriptStruct ControlRig.RigUnit_MathFloatAcos
// Inherited Bytes: 0x10 | Struct Size: 0x10
struct FRigUnit_MathFloatAcos : FRigUnit_MathFloatUnaryOp {
};

// Object: ScriptStruct ControlRig.RigUnit_MathFloatAsin
// Inherited Bytes: 0x10 | Struct Size: 0x10
struct FRigUnit_MathFloatAsin : FRigUnit_MathFloatUnaryOp {
};

// Object: ScriptStruct ControlRig.RigUnit_MathFloatTan
// Inherited Bytes: 0x10 | Struct Size: 0x10
struct FRigUnit_MathFloatTan : FRigUnit_MathFloatUnaryOp {
};

// Object: ScriptStruct ControlRig.RigUnit_MathFloatCos
// Inherited Bytes: 0x10 | Struct Size: 0x10
struct FRigUnit_MathFloatCos : FRigUnit_MathFloatUnaryOp {
};

// Object: ScriptStruct ControlRig.RigUnit_MathFloatSin
// Inherited Bytes: 0x10 | Struct Size: 0x10
struct FRigUnit_MathFloatSin : FRigUnit_MathFloatUnaryOp {
};

// Object: ScriptStruct ControlRig.RigUnit_MathFloatRad
// Inherited Bytes: 0x10 | Struct Size: 0x10
struct FRigUnit_MathFloatRad : FRigUnit_MathFloatUnaryOp {
};

// Object: ScriptStruct ControlRig.RigUnit_MathFloatDeg
// Inherited Bytes: 0x10 | Struct Size: 0x10
struct FRigUnit_MathFloatDeg : FRigUnit_MathFloatUnaryOp {
};

// Object: ScriptStruct ControlRig.RigUnit_MathFloatSelectBool
// Inherited Bytes: 0x8 | Struct Size: 0x18
struct FRigUnit_MathFloatSelectBool : FRigUnit_MathFloatBase {
	// Fields
	bool Condition; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x3]; // Offset: 0x9 | Size: 0x3
	float IfTrue; // Offset: 0xc | Size: 0x4
	float IfFalse; // Offset: 0x10 | Size: 0x4
	float Result; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_MathFloatIsNearlyEqual
// Inherited Bytes: 0x8 | Struct Size: 0x18
struct FRigUnit_MathFloatIsNearlyEqual : FRigUnit_MathFloatBase {
	// Fields
	float A; // Offset: 0x8 | Size: 0x4
	float B; // Offset: 0xc | Size: 0x4
	float Tolerance; // Offset: 0x10 | Size: 0x4
	bool Result; // Offset: 0x14 | Size: 0x1
	char pad_0x15[0x3]; // Offset: 0x15 | Size: 0x3
};

// Object: ScriptStruct ControlRig.RigUnit_MathFloatIsNearlyZero
// Inherited Bytes: 0x8 | Struct Size: 0x18
struct FRigUnit_MathFloatIsNearlyZero : FRigUnit_MathFloatBase {
	// Fields
	float Value; // Offset: 0x8 | Size: 0x4
	float Tolerance; // Offset: 0xc | Size: 0x4
	bool Result; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x7]; // Offset: 0x11 | Size: 0x7
};

// Object: ScriptStruct ControlRig.RigUnit_MathFloatLessEqual
// Inherited Bytes: 0x8 | Struct Size: 0x18
struct FRigUnit_MathFloatLessEqual : FRigUnit_MathFloatBase {
	// Fields
	float A; // Offset: 0x8 | Size: 0x4
	float B; // Offset: 0xc | Size: 0x4
	bool Result; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x7]; // Offset: 0x11 | Size: 0x7
};

// Object: ScriptStruct ControlRig.RigUnit_MathFloatGreaterEqual
// Inherited Bytes: 0x8 | Struct Size: 0x18
struct FRigUnit_MathFloatGreaterEqual : FRigUnit_MathFloatBase {
	// Fields
	float A; // Offset: 0x8 | Size: 0x4
	float B; // Offset: 0xc | Size: 0x4
	bool Result; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x7]; // Offset: 0x11 | Size: 0x7
};

// Object: ScriptStruct ControlRig.RigUnit_MathFloatLess
// Inherited Bytes: 0x8 | Struct Size: 0x18
struct FRigUnit_MathFloatLess : FRigUnit_MathFloatBase {
	// Fields
	float A; // Offset: 0x8 | Size: 0x4
	float B; // Offset: 0xc | Size: 0x4
	bool Result; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x7]; // Offset: 0x11 | Size: 0x7
};

// Object: ScriptStruct ControlRig.RigUnit_MathFloatGreater
// Inherited Bytes: 0x8 | Struct Size: 0x18
struct FRigUnit_MathFloatGreater : FRigUnit_MathFloatBase {
	// Fields
	float A; // Offset: 0x8 | Size: 0x4
	float B; // Offset: 0xc | Size: 0x4
	bool Result; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x7]; // Offset: 0x11 | Size: 0x7
};

// Object: ScriptStruct ControlRig.RigUnit_MathFloatNotEquals
// Inherited Bytes: 0x8 | Struct Size: 0x18
struct FRigUnit_MathFloatNotEquals : FRigUnit_MathFloatBase {
	// Fields
	float A; // Offset: 0x8 | Size: 0x4
	float B; // Offset: 0xc | Size: 0x4
	bool Result; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x7]; // Offset: 0x11 | Size: 0x7
};

// Object: ScriptStruct ControlRig.RigUnit_MathFloatEquals
// Inherited Bytes: 0x8 | Struct Size: 0x18
struct FRigUnit_MathFloatEquals : FRigUnit_MathFloatBase {
	// Fields
	float A; // Offset: 0x8 | Size: 0x4
	float B; // Offset: 0xc | Size: 0x4
	bool Result; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x7]; // Offset: 0x11 | Size: 0x7
};

// Object: ScriptStruct ControlRig.RigUnit_MathFloatRemap
// Inherited Bytes: 0x8 | Struct Size: 0x28
struct FRigUnit_MathFloatRemap : FRigUnit_MathFloatBase {
	// Fields
	float Value; // Offset: 0x8 | Size: 0x4
	float SourceMinimum; // Offset: 0xc | Size: 0x4
	float SourceMaximum; // Offset: 0x10 | Size: 0x4
	float TargetMinimum; // Offset: 0x14 | Size: 0x4
	float TargetMaximum; // Offset: 0x18 | Size: 0x4
	bool bClamp; // Offset: 0x1c | Size: 0x1
	char pad_0x1D[0x3]; // Offset: 0x1d | Size: 0x3
	float Result; // Offset: 0x20 | Size: 0x4
	char pad_0x24[0x4]; // Offset: 0x24 | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_MathFloatLerp
// Inherited Bytes: 0x8 | Struct Size: 0x18
struct FRigUnit_MathFloatLerp : FRigUnit_MathFloatBase {
	// Fields
	float A; // Offset: 0x8 | Size: 0x4
	float B; // Offset: 0xc | Size: 0x4
	float T; // Offset: 0x10 | Size: 0x4
	float Result; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_MathFloatClamp
// Inherited Bytes: 0x8 | Struct Size: 0x18
struct FRigUnit_MathFloatClamp : FRigUnit_MathFloatBase {
	// Fields
	float Value; // Offset: 0x8 | Size: 0x4
	float Minimum; // Offset: 0xc | Size: 0x4
	float Maximum; // Offset: 0x10 | Size: 0x4
	float Result; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_MathFloatSign
// Inherited Bytes: 0x10 | Struct Size: 0x10
struct FRigUnit_MathFloatSign : FRigUnit_MathFloatUnaryOp {
};

// Object: ScriptStruct ControlRig.RigUnit_MathFloatRound
// Inherited Bytes: 0x10 | Struct Size: 0x10
struct FRigUnit_MathFloatRound : FRigUnit_MathFloatUnaryOp {
};

// Object: ScriptStruct ControlRig.RigUnit_MathFloatCeil
// Inherited Bytes: 0x10 | Struct Size: 0x10
struct FRigUnit_MathFloatCeil : FRigUnit_MathFloatUnaryOp {
};

// Object: ScriptStruct ControlRig.RigUnit_MathFloatFloor
// Inherited Bytes: 0x10 | Struct Size: 0x10
struct FRigUnit_MathFloatFloor : FRigUnit_MathFloatUnaryOp {
};

// Object: ScriptStruct ControlRig.RigUnit_MathFloatAbs
// Inherited Bytes: 0x10 | Struct Size: 0x10
struct FRigUnit_MathFloatAbs : FRigUnit_MathFloatUnaryOp {
};

// Object: ScriptStruct ControlRig.RigUnit_MathFloatNegate
// Inherited Bytes: 0x10 | Struct Size: 0x10
struct FRigUnit_MathFloatNegate : FRigUnit_MathFloatUnaryOp {
};

// Object: ScriptStruct ControlRig.RigUnit_MathFloatSqrt
// Inherited Bytes: 0x10 | Struct Size: 0x10
struct FRigUnit_MathFloatSqrt : FRigUnit_MathFloatUnaryOp {
};

// Object: ScriptStruct ControlRig.RigUnit_MathFloatBinaryOp
// Inherited Bytes: 0x8 | Struct Size: 0x18
struct FRigUnit_MathFloatBinaryOp : FRigUnit_MathFloatBase {
	// Fields
	float A; // Offset: 0x8 | Size: 0x4
	float B; // Offset: 0xc | Size: 0x4
	float Result; // Offset: 0x10 | Size: 0x4
	char pad_0x14[0x4]; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_MathFloatPow
// Inherited Bytes: 0x18 | Struct Size: 0x18
struct FRigUnit_MathFloatPow : FRigUnit_MathFloatBinaryOp {
};

// Object: ScriptStruct ControlRig.RigUnit_MathFloatMax
// Inherited Bytes: 0x18 | Struct Size: 0x18
struct FRigUnit_MathFloatMax : FRigUnit_MathFloatBinaryOp {
};

// Object: ScriptStruct ControlRig.RigUnit_MathFloatMin
// Inherited Bytes: 0x18 | Struct Size: 0x18
struct FRigUnit_MathFloatMin : FRigUnit_MathFloatBinaryOp {
};

// Object: ScriptStruct ControlRig.RigUnit_MathFloatMod
// Inherited Bytes: 0x18 | Struct Size: 0x18
struct FRigUnit_MathFloatMod : FRigUnit_MathFloatBinaryOp {
};

// Object: ScriptStruct ControlRig.RigUnit_MathFloatDiv
// Inherited Bytes: 0x18 | Struct Size: 0x18
struct FRigUnit_MathFloatDiv : FRigUnit_MathFloatBinaryOp {
};

// Object: ScriptStruct ControlRig.RigUnit_MathFloatMul
// Inherited Bytes: 0x18 | Struct Size: 0x18
struct FRigUnit_MathFloatMul : FRigUnit_MathFloatBinaryOp {
};

// Object: ScriptStruct ControlRig.RigUnit_MathFloatSub
// Inherited Bytes: 0x18 | Struct Size: 0x18
struct FRigUnit_MathFloatSub : FRigUnit_MathFloatBinaryOp {
};

// Object: ScriptStruct ControlRig.RigUnit_MathFloatAdd
// Inherited Bytes: 0x18 | Struct Size: 0x18
struct FRigUnit_MathFloatAdd : FRigUnit_MathFloatBinaryOp {
};

// Object: ScriptStruct ControlRig.RigUnit_MathFloatConstant
// Inherited Bytes: 0x8 | Struct Size: 0x10
struct FRigUnit_MathFloatConstant : FRigUnit_MathFloatBase {
	// Fields
	float Value; // Offset: 0x8 | Size: 0x4
	char pad_0xC[0x4]; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_MathFloatConstTwoPi
// Inherited Bytes: 0x10 | Struct Size: 0x10
struct FRigUnit_MathFloatConstTwoPi : FRigUnit_MathFloatConstant {
};

// Object: ScriptStruct ControlRig.RigUnit_MathFloatConstHalfPi
// Inherited Bytes: 0x10 | Struct Size: 0x10
struct FRigUnit_MathFloatConstHalfPi : FRigUnit_MathFloatConstant {
};

// Object: ScriptStruct ControlRig.RigUnit_MathFloatConstPi
// Inherited Bytes: 0x10 | Struct Size: 0x10
struct FRigUnit_MathFloatConstPi : FRigUnit_MathFloatConstant {
};

// Object: ScriptStruct ControlRig.RigUnit_MathQuaternionRotationOrder
// Inherited Bytes: 0x8 | Struct Size: 0x10
struct FRigUnit_MathQuaternionRotationOrder : FRigUnit_MathBase {
	// Fields
	enum class EControlRigRotationOrder RotationOrder; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x7]; // Offset: 0x9 | Size: 0x7
};

// Object: ScriptStruct ControlRig.RigUnit_MathQuaternionBase
// Inherited Bytes: 0x8 | Struct Size: 0x8
struct FRigUnit_MathQuaternionBase : FRigUnit_MathBase {
};

// Object: ScriptStruct ControlRig.RigUnit_MathQuaternionSwingTwist
// Inherited Bytes: 0x8 | Struct Size: 0x50
struct FRigUnit_MathQuaternionSwingTwist : FRigUnit_MathQuaternionBase {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FQuat Input; // Offset: 0x10 | Size: 0x10
	struct FVector TwistAxis; // Offset: 0x20 | Size: 0xc
	char pad_0x2C[0x4]; // Offset: 0x2c | Size: 0x4
	struct FQuat Swing; // Offset: 0x30 | Size: 0x10
	struct FQuat Twist; // Offset: 0x40 | Size: 0x10
};

// Object: ScriptStruct ControlRig.RigUnit_MathQuaternionGetAxis
// Inherited Bytes: 0x8 | Struct Size: 0x30
struct FRigUnit_MathQuaternionGetAxis : FRigUnit_MathQuaternionBase {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FQuat Quaternion; // Offset: 0x10 | Size: 0x10
	enum class EAxis Axis; // Offset: 0x20 | Size: 0x1
	char pad_0x21[0x3]; // Offset: 0x21 | Size: 0x3
	struct FVector Result; // Offset: 0x24 | Size: 0xc
};

// Object: ScriptStruct ControlRig.RigUnit_MathQuaternionRotateVector
// Inherited Bytes: 0x8 | Struct Size: 0x40
struct FRigUnit_MathQuaternionRotateVector : FRigUnit_MathQuaternionBase {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FQuat Quaternion; // Offset: 0x10 | Size: 0x10
	struct FVector Vector; // Offset: 0x20 | Size: 0xc
	struct FVector Result; // Offset: 0x2c | Size: 0xc
	char pad_0x38[0x8]; // Offset: 0x38 | Size: 0x8
};

// Object: ScriptStruct ControlRig.RigUnit_MathQuaternionUnaryOp
// Inherited Bytes: 0x8 | Struct Size: 0x30
struct FRigUnit_MathQuaternionUnaryOp : FRigUnit_MathQuaternionBase {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FQuat Value; // Offset: 0x10 | Size: 0x10
	struct FQuat Result; // Offset: 0x20 | Size: 0x10
};

// Object: ScriptStruct ControlRig.RigUnit_MathQuaternionUnit
// Inherited Bytes: 0x30 | Struct Size: 0x30
struct FRigUnit_MathQuaternionUnit : FRigUnit_MathQuaternionUnaryOp {
};

// Object: ScriptStruct ControlRig.RigUnit_MathQuaternionDot
// Inherited Bytes: 0x8 | Struct Size: 0x40
struct FRigUnit_MathQuaternionDot : FRigUnit_MathQuaternionBase {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FQuat A; // Offset: 0x10 | Size: 0x10
	struct FQuat B; // Offset: 0x20 | Size: 0x10
	float Result; // Offset: 0x30 | Size: 0x4
	char pad_0x34[0xc]; // Offset: 0x34 | Size: 0xc
};

// Object: ScriptStruct ControlRig.RigUnit_MathQuaternionSelectBool
// Inherited Bytes: 0x8 | Struct Size: 0x40
struct FRigUnit_MathQuaternionSelectBool : FRigUnit_MathQuaternionBase {
	// Fields
	bool Condition; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x7]; // Offset: 0x9 | Size: 0x7
	struct FQuat IfTrue; // Offset: 0x10 | Size: 0x10
	struct FQuat IfFalse; // Offset: 0x20 | Size: 0x10
	struct FQuat Result; // Offset: 0x30 | Size: 0x10
};

// Object: ScriptStruct ControlRig.RigUnit_MathQuaternionNotEquals
// Inherited Bytes: 0x8 | Struct Size: 0x40
struct FRigUnit_MathQuaternionNotEquals : FRigUnit_MathQuaternionBase {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FQuat A; // Offset: 0x10 | Size: 0x10
	struct FQuat B; // Offset: 0x20 | Size: 0x10
	bool Result; // Offset: 0x30 | Size: 0x1
	char pad_0x31[0xf]; // Offset: 0x31 | Size: 0xf
};

// Object: ScriptStruct ControlRig.RigUnit_MathQuaternionEquals
// Inherited Bytes: 0x8 | Struct Size: 0x40
struct FRigUnit_MathQuaternionEquals : FRigUnit_MathQuaternionBase {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FQuat A; // Offset: 0x10 | Size: 0x10
	struct FQuat B; // Offset: 0x20 | Size: 0x10
	bool Result; // Offset: 0x30 | Size: 0x1
	char pad_0x31[0xf]; // Offset: 0x31 | Size: 0xf
};

// Object: ScriptStruct ControlRig.RigUnit_MathQuaternionSlerp
// Inherited Bytes: 0x8 | Struct Size: 0x50
struct FRigUnit_MathQuaternionSlerp : FRigUnit_MathQuaternionBase {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FQuat A; // Offset: 0x10 | Size: 0x10
	struct FQuat B; // Offset: 0x20 | Size: 0x10
	float T; // Offset: 0x30 | Size: 0x4
	char pad_0x34[0xc]; // Offset: 0x34 | Size: 0xc
	struct FQuat Result; // Offset: 0x40 | Size: 0x10
};

// Object: ScriptStruct ControlRig.RigUnit_MathQuaternionInverse
// Inherited Bytes: 0x30 | Struct Size: 0x30
struct FRigUnit_MathQuaternionInverse : FRigUnit_MathQuaternionUnaryOp {
};

// Object: ScriptStruct ControlRig.RigUnit_MathQuaternionBinaryOp
// Inherited Bytes: 0x8 | Struct Size: 0x40
struct FRigUnit_MathQuaternionBinaryOp : FRigUnit_MathQuaternionBase {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FQuat A; // Offset: 0x10 | Size: 0x10
	struct FQuat B; // Offset: 0x20 | Size: 0x10
	struct FQuat Result; // Offset: 0x30 | Size: 0x10
};

// Object: ScriptStruct ControlRig.RigUnit_MathQuaternionMul
// Inherited Bytes: 0x40 | Struct Size: 0x40
struct FRigUnit_MathQuaternionMul : FRigUnit_MathQuaternionBinaryOp {
};

// Object: ScriptStruct ControlRig.RigUnit_MathQuaternionToRotator
// Inherited Bytes: 0x8 | Struct Size: 0x30
struct FRigUnit_MathQuaternionToRotator : FRigUnit_MathQuaternionBase {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FQuat Value; // Offset: 0x10 | Size: 0x10
	struct FRotator Result; // Offset: 0x20 | Size: 0xc
	char pad_0x2C[0x4]; // Offset: 0x2c | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_MathQuaternionToEuler
// Inherited Bytes: 0x8 | Struct Size: 0x30
struct FRigUnit_MathQuaternionToEuler : FRigUnit_MathQuaternionBase {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FQuat Value; // Offset: 0x10 | Size: 0x10
	enum class EControlRigRotationOrder RotationOrder; // Offset: 0x20 | Size: 0x1
	char pad_0x21[0x3]; // Offset: 0x21 | Size: 0x3
	struct FVector Result; // Offset: 0x24 | Size: 0xc
};

// Object: ScriptStruct ControlRig.RigUnit_MathQuaternionToAxisAndAngle
// Inherited Bytes: 0x8 | Struct Size: 0x30
struct FRigUnit_MathQuaternionToAxisAndAngle : FRigUnit_MathQuaternionBase {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FQuat Value; // Offset: 0x10 | Size: 0x10
	struct FVector Axis; // Offset: 0x20 | Size: 0xc
	float Angle; // Offset: 0x2c | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_MathQuaternionFromTwoVectors
// Inherited Bytes: 0x8 | Struct Size: 0x30
struct FRigUnit_MathQuaternionFromTwoVectors : FRigUnit_MathQuaternionBase {
	// Fields
	struct FVector A; // Offset: 0x8 | Size: 0xc
	struct FVector B; // Offset: 0x14 | Size: 0xc
	struct FQuat Result; // Offset: 0x20 | Size: 0x10
};

// Object: ScriptStruct ControlRig.RigUnit_MathQuaternionFromRotator
// Inherited Bytes: 0x8 | Struct Size: 0x30
struct FRigUnit_MathQuaternionFromRotator : FRigUnit_MathQuaternionBase {
	// Fields
	struct FRotator Rotator; // Offset: 0x8 | Size: 0xc
	char pad_0x14[0xc]; // Offset: 0x14 | Size: 0xc
	struct FQuat Result; // Offset: 0x20 | Size: 0x10
};

// Object: ScriptStruct ControlRig.RigUnit_MathQuaternionFromEuler
// Inherited Bytes: 0x8 | Struct Size: 0x30
struct FRigUnit_MathQuaternionFromEuler : FRigUnit_MathQuaternionBase {
	// Fields
	struct FVector Euler; // Offset: 0x8 | Size: 0xc
	enum class EControlRigRotationOrder RotationOrder; // Offset: 0x14 | Size: 0x1
	char pad_0x15[0xb]; // Offset: 0x15 | Size: 0xb
	struct FQuat Result; // Offset: 0x20 | Size: 0x10
};

// Object: ScriptStruct ControlRig.RigUnit_MathQuaternionFromAxisAndAngle
// Inherited Bytes: 0x8 | Struct Size: 0x30
struct FRigUnit_MathQuaternionFromAxisAndAngle : FRigUnit_MathQuaternionBase {
	// Fields
	struct FVector Axis; // Offset: 0x8 | Size: 0xc
	float Angle; // Offset: 0x14 | Size: 0x4
	char pad_0x18[0x8]; // Offset: 0x18 | Size: 0x8
	struct FQuat Result; // Offset: 0x20 | Size: 0x10
};

// Object: ScriptStruct ControlRig.RigUnit_MathTransformBase
// Inherited Bytes: 0x8 | Struct Size: 0x8
struct FRigUnit_MathTransformBase : FRigUnit_MathBase {
};

// Object: ScriptStruct ControlRig.RigUnit_MathTransformClampSpatially
// Inherited Bytes: 0x8 | Struct Size: 0xd0
struct FRigUnit_MathTransformClampSpatially : FRigUnit_MathTransformBase {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FTransform Value; // Offset: 0x10 | Size: 0x30
	enum class EAxis Axis; // Offset: 0x40 | Size: 0x1
	enum class EControlRigClampSpatialMode Type; // Offset: 0x41 | Size: 0x1
	char pad_0x42[0x2]; // Offset: 0x42 | Size: 0x2
	float Minimum; // Offset: 0x44 | Size: 0x4
	float Maximum; // Offset: 0x48 | Size: 0x4
	char pad_0x4C[0x4]; // Offset: 0x4c | Size: 0x4
	struct FTransform Space; // Offset: 0x50 | Size: 0x30
	bool bDrawDebug; // Offset: 0x80 | Size: 0x1
	char pad_0x81[0x3]; // Offset: 0x81 | Size: 0x3
	struct FLinearColor DebugColor; // Offset: 0x84 | Size: 0x10
	float DebugThickness; // Offset: 0x94 | Size: 0x4
	char pad_0x98[0x8]; // Offset: 0x98 | Size: 0x8
	struct FTransform Result; // Offset: 0xa0 | Size: 0x30
};

// Object: ScriptStruct ControlRig.RigUnit_MathTransformFromSRT
// Inherited Bytes: 0x8 | Struct Size: 0x90
struct FRigUnit_MathTransformFromSRT : FRigUnit_MathTransformBase {
	// Fields
	struct FVector Location; // Offset: 0x8 | Size: 0xc
	struct FVector Rotation; // Offset: 0x14 | Size: 0xc
	enum class EControlRigRotationOrder RotationOrder; // Offset: 0x20 | Size: 0x1
	char pad_0x21[0x3]; // Offset: 0x21 | Size: 0x3
	struct FVector Scale; // Offset: 0x24 | Size: 0xc
	struct FTransform Transform; // Offset: 0x30 | Size: 0x30
	struct FEulerTransform EulerTransform; // Offset: 0x60 | Size: 0x24
	char pad_0x84[0xc]; // Offset: 0x84 | Size: 0xc
};

// Object: ScriptStruct ControlRig.RigUnit_MathTransformTransformVector
// Inherited Bytes: 0x8 | Struct Size: 0x60
struct FRigUnit_MathTransformTransformVector : FRigUnit_MathTransformBase {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FTransform Transform; // Offset: 0x10 | Size: 0x30
	struct FVector Location; // Offset: 0x40 | Size: 0xc
	struct FVector Result; // Offset: 0x4c | Size: 0xc
	char pad_0x58[0x8]; // Offset: 0x58 | Size: 0x8
};

// Object: ScriptStruct ControlRig.RigUnit_MathTransformRotateVector
// Inherited Bytes: 0x8 | Struct Size: 0x60
struct FRigUnit_MathTransformRotateVector : FRigUnit_MathTransformBase {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FTransform Transform; // Offset: 0x10 | Size: 0x30
	struct FVector Direction; // Offset: 0x40 | Size: 0xc
	struct FVector Result; // Offset: 0x4c | Size: 0xc
	char pad_0x58[0x8]; // Offset: 0x58 | Size: 0x8
};

// Object: ScriptStruct ControlRig.RigUnit_MathTransformSelectBool
// Inherited Bytes: 0x8 | Struct Size: 0xa0
struct FRigUnit_MathTransformSelectBool : FRigUnit_MathTransformBase {
	// Fields
	bool Condition; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x7]; // Offset: 0x9 | Size: 0x7
	struct FTransform IfTrue; // Offset: 0x10 | Size: 0x30
	struct FTransform IfFalse; // Offset: 0x40 | Size: 0x30
	struct FTransform Result; // Offset: 0x70 | Size: 0x30
};

// Object: ScriptStruct ControlRig.RigUnit_MathTransformLerp
// Inherited Bytes: 0x8 | Struct Size: 0xb0
struct FRigUnit_MathTransformLerp : FRigUnit_MathTransformBase {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FTransform A; // Offset: 0x10 | Size: 0x30
	struct FTransform B; // Offset: 0x40 | Size: 0x30
	float T; // Offset: 0x70 | Size: 0x4
	char pad_0x74[0xc]; // Offset: 0x74 | Size: 0xc
	struct FTransform Result; // Offset: 0x80 | Size: 0x30
};

// Object: ScriptStruct ControlRig.RigUnit_MathTransformUnaryOp
// Inherited Bytes: 0x8 | Struct Size: 0x70
struct FRigUnit_MathTransformUnaryOp : FRigUnit_MathTransformBase {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FTransform Value; // Offset: 0x10 | Size: 0x30
	struct FTransform Result; // Offset: 0x40 | Size: 0x30
};

// Object: ScriptStruct ControlRig.RigUnit_MathTransformInverse
// Inherited Bytes: 0x70 | Struct Size: 0x70
struct FRigUnit_MathTransformInverse : FRigUnit_MathTransformUnaryOp {
};

// Object: ScriptStruct ControlRig.RigUnit_MathTransformMakeAbsolute
// Inherited Bytes: 0x8 | Struct Size: 0xa0
struct FRigUnit_MathTransformMakeAbsolute : FRigUnit_MathTransformBase {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FTransform Local; // Offset: 0x10 | Size: 0x30
	struct FTransform Parent; // Offset: 0x40 | Size: 0x30
	struct FTransform Global; // Offset: 0x70 | Size: 0x30
};

// Object: ScriptStruct ControlRig.RigUnit_MathTransformMakeRelative
// Inherited Bytes: 0x8 | Struct Size: 0xa0
struct FRigUnit_MathTransformMakeRelative : FRigUnit_MathTransformBase {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FTransform Global; // Offset: 0x10 | Size: 0x30
	struct FTransform Parent; // Offset: 0x40 | Size: 0x30
	struct FTransform Local; // Offset: 0x70 | Size: 0x30
};

// Object: ScriptStruct ControlRig.RigUnit_MathTransformBinaryOp
// Inherited Bytes: 0x8 | Struct Size: 0xa0
struct FRigUnit_MathTransformBinaryOp : FRigUnit_MathTransformBase {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FTransform A; // Offset: 0x10 | Size: 0x30
	struct FTransform B; // Offset: 0x40 | Size: 0x30
	struct FTransform Result; // Offset: 0x70 | Size: 0x30
};

// Object: ScriptStruct ControlRig.RigUnit_MathTransformMul
// Inherited Bytes: 0xa0 | Struct Size: 0xa0
struct FRigUnit_MathTransformMul : FRigUnit_MathTransformBinaryOp {
};

// Object: ScriptStruct ControlRig.RigUnit_MathTransformToEulerTransform
// Inherited Bytes: 0x8 | Struct Size: 0x70
struct FRigUnit_MathTransformToEulerTransform : FRigUnit_MathTransformBase {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FTransform Value; // Offset: 0x10 | Size: 0x30
	struct FEulerTransform Result; // Offset: 0x40 | Size: 0x24
	char pad_0x64[0xc]; // Offset: 0x64 | Size: 0xc
};

// Object: ScriptStruct ControlRig.RigUnit_MathTransformFromEulerTransform
// Inherited Bytes: 0x8 | Struct Size: 0x60
struct FRigUnit_MathTransformFromEulerTransform : FRigUnit_MathTransformBase {
	// Fields
	struct FEulerTransform EulerTransform; // Offset: 0x8 | Size: 0x24
	char pad_0x2C[0x4]; // Offset: 0x2c | Size: 0x4
	struct FTransform Result; // Offset: 0x30 | Size: 0x30
};

// Object: ScriptStruct ControlRig.RigUnit_MathVectorBase
// Inherited Bytes: 0x8 | Struct Size: 0x8
struct FRigUnit_MathVectorBase : FRigUnit_MathBase {
};

// Object: ScriptStruct ControlRig.RigUnit_MathVectorClampSpatially
// Inherited Bytes: 0x8 | Struct Size: 0x80
struct FRigUnit_MathVectorClampSpatially : FRigUnit_MathVectorBase {
	// Fields
	struct FVector Value; // Offset: 0x8 | Size: 0xc
	enum class EAxis Axis; // Offset: 0x14 | Size: 0x1
	enum class EControlRigClampSpatialMode Type; // Offset: 0x15 | Size: 0x1
	char pad_0x16[0x2]; // Offset: 0x16 | Size: 0x2
	float Minimum; // Offset: 0x18 | Size: 0x4
	float Maximum; // Offset: 0x1c | Size: 0x4
	struct FTransform Space; // Offset: 0x20 | Size: 0x30
	bool bDrawDebug; // Offset: 0x50 | Size: 0x1
	char pad_0x51[0x3]; // Offset: 0x51 | Size: 0x3
	struct FLinearColor DebugColor; // Offset: 0x54 | Size: 0x10
	float DebugThickness; // Offset: 0x64 | Size: 0x4
	struct FVector Result; // Offset: 0x68 | Size: 0xc
	char pad_0x74[0xc]; // Offset: 0x74 | Size: 0xc
};

// Object: ScriptStruct ControlRig.RigUnit_MathVectorMakeBezierFourPoint
// Inherited Bytes: 0x8 | Struct Size: 0x38
struct FRigUnit_MathVectorMakeBezierFourPoint : FRigUnit_MathVectorBase {
	// Fields
	struct FCRFourPointBezier Bezier; // Offset: 0x8 | Size: 0x30
};

// Object: ScriptStruct ControlRig.RigUnit_MathVectorBezierFourPoint
// Inherited Bytes: 0x8 | Struct Size: 0x58
struct FRigUnit_MathVectorBezierFourPoint : FRigUnit_MathVectorBase {
	// Fields
	struct FCRFourPointBezier Bezier; // Offset: 0x8 | Size: 0x30
	float T; // Offset: 0x38 | Size: 0x4
	struct FVector Result; // Offset: 0x3c | Size: 0xc
	struct FVector Tangent; // Offset: 0x48 | Size: 0xc
	char pad_0x54[0x4]; // Offset: 0x54 | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_MathVectorOrthogonal
// Inherited Bytes: 0x8 | Struct Size: 0x28
struct FRigUnit_MathVectorOrthogonal : FRigUnit_MathVectorBase {
	// Fields
	struct FVector A; // Offset: 0x8 | Size: 0xc
	struct FVector B; // Offset: 0x14 | Size: 0xc
	bool Result; // Offset: 0x20 | Size: 0x1
	char pad_0x21[0x7]; // Offset: 0x21 | Size: 0x7
};

// Object: ScriptStruct ControlRig.RigUnit_MathVectorParallel
// Inherited Bytes: 0x8 | Struct Size: 0x28
struct FRigUnit_MathVectorParallel : FRigUnit_MathVectorBase {
	// Fields
	struct FVector A; // Offset: 0x8 | Size: 0xc
	struct FVector B; // Offset: 0x14 | Size: 0xc
	bool Result; // Offset: 0x20 | Size: 0x1
	char pad_0x21[0x7]; // Offset: 0x21 | Size: 0x7
};

// Object: ScriptStruct ControlRig.RigUnit_MathVectorAngle
// Inherited Bytes: 0x8 | Struct Size: 0x28
struct FRigUnit_MathVectorAngle : FRigUnit_MathVectorBase {
	// Fields
	struct FVector A; // Offset: 0x8 | Size: 0xc
	struct FVector B; // Offset: 0x14 | Size: 0xc
	float Result; // Offset: 0x20 | Size: 0x4
	char pad_0x24[0x4]; // Offset: 0x24 | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_MathVectorMirror
// Inherited Bytes: 0x8 | Struct Size: 0x30
struct FRigUnit_MathVectorMirror : FRigUnit_MathVectorBase {
	// Fields
	struct FVector Value; // Offset: 0x8 | Size: 0xc
	struct FVector Normal; // Offset: 0x14 | Size: 0xc
	struct FVector Result; // Offset: 0x20 | Size: 0xc
	char pad_0x2C[0x4]; // Offset: 0x2c | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_MathVectorClampLength
// Inherited Bytes: 0x8 | Struct Size: 0x28
struct FRigUnit_MathVectorClampLength : FRigUnit_MathVectorBase {
	// Fields
	struct FVector Value; // Offset: 0x8 | Size: 0xc
	float MinimumLength; // Offset: 0x14 | Size: 0x4
	float MaximumLength; // Offset: 0x18 | Size: 0x4
	struct FVector Result; // Offset: 0x1c | Size: 0xc
};

// Object: ScriptStruct ControlRig.RigUnit_MathVectorSetLength
// Inherited Bytes: 0x8 | Struct Size: 0x28
struct FRigUnit_MathVectorSetLength : FRigUnit_MathVectorBase {
	// Fields
	struct FVector Value; // Offset: 0x8 | Size: 0xc
	float Length; // Offset: 0x14 | Size: 0x4
	struct FVector Result; // Offset: 0x18 | Size: 0xc
	char pad_0x24[0x4]; // Offset: 0x24 | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_MathVectorUnaryOp
// Inherited Bytes: 0x8 | Struct Size: 0x20
struct FRigUnit_MathVectorUnaryOp : FRigUnit_MathVectorBase {
	// Fields
	struct FVector Value; // Offset: 0x8 | Size: 0xc
	struct FVector Result; // Offset: 0x14 | Size: 0xc
};

// Object: ScriptStruct ControlRig.RigUnit_MathVectorUnit
// Inherited Bytes: 0x20 | Struct Size: 0x20
struct FRigUnit_MathVectorUnit : FRigUnit_MathVectorUnaryOp {
};

// Object: ScriptStruct ControlRig.RigUnit_MathVectorDot
// Inherited Bytes: 0x8 | Struct Size: 0x28
struct FRigUnit_MathVectorDot : FRigUnit_MathVectorBase {
	// Fields
	struct FVector A; // Offset: 0x8 | Size: 0xc
	struct FVector B; // Offset: 0x14 | Size: 0xc
	float Result; // Offset: 0x20 | Size: 0x4
	char pad_0x24[0x4]; // Offset: 0x24 | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_MathVectorBinaryOp
// Inherited Bytes: 0x8 | Struct Size: 0x30
struct FRigUnit_MathVectorBinaryOp : FRigUnit_MathVectorBase {
	// Fields
	struct FVector A; // Offset: 0x8 | Size: 0xc
	struct FVector B; // Offset: 0x14 | Size: 0xc
	struct FVector Result; // Offset: 0x20 | Size: 0xc
	char pad_0x2C[0x4]; // Offset: 0x2c | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_MathVectorCross
// Inherited Bytes: 0x30 | Struct Size: 0x30
struct FRigUnit_MathVectorCross : FRigUnit_MathVectorBinaryOp {
};

// Object: ScriptStruct ControlRig.RigUnit_MathVectorDistance
// Inherited Bytes: 0x8 | Struct Size: 0x28
struct FRigUnit_MathVectorDistance : FRigUnit_MathVectorBase {
	// Fields
	struct FVector A; // Offset: 0x8 | Size: 0xc
	struct FVector B; // Offset: 0x14 | Size: 0xc
	float Result; // Offset: 0x20 | Size: 0x4
	char pad_0x24[0x4]; // Offset: 0x24 | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_MathVectorLength
// Inherited Bytes: 0x8 | Struct Size: 0x18
struct FRigUnit_MathVectorLength : FRigUnit_MathVectorBase {
	// Fields
	struct FVector Value; // Offset: 0x8 | Size: 0xc
	float Result; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_MathVectorLengthSquared
// Inherited Bytes: 0x8 | Struct Size: 0x18
struct FRigUnit_MathVectorLengthSquared : FRigUnit_MathVectorBase {
	// Fields
	struct FVector Value; // Offset: 0x8 | Size: 0xc
	float Result; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_MathVectorRad
// Inherited Bytes: 0x20 | Struct Size: 0x20
struct FRigUnit_MathVectorRad : FRigUnit_MathVectorUnaryOp {
};

// Object: ScriptStruct ControlRig.RigUnit_MathVectorDeg
// Inherited Bytes: 0x20 | Struct Size: 0x20
struct FRigUnit_MathVectorDeg : FRigUnit_MathVectorUnaryOp {
};

// Object: ScriptStruct ControlRig.RigUnit_MathVectorSelectBool
// Inherited Bytes: 0x8 | Struct Size: 0x30
struct FRigUnit_MathVectorSelectBool : FRigUnit_MathVectorBase {
	// Fields
	bool Condition; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x3]; // Offset: 0x9 | Size: 0x3
	struct FVector IfTrue; // Offset: 0xc | Size: 0xc
	struct FVector IfFalse; // Offset: 0x18 | Size: 0xc
	struct FVector Result; // Offset: 0x24 | Size: 0xc
};

// Object: ScriptStruct ControlRig.RigUnit_MathVectorIsNearlyEqual
// Inherited Bytes: 0x8 | Struct Size: 0x28
struct FRigUnit_MathVectorIsNearlyEqual : FRigUnit_MathVectorBase {
	// Fields
	struct FVector A; // Offset: 0x8 | Size: 0xc
	struct FVector B; // Offset: 0x14 | Size: 0xc
	float Tolerance; // Offset: 0x20 | Size: 0x4
	bool Result; // Offset: 0x24 | Size: 0x1
	char pad_0x25[0x3]; // Offset: 0x25 | Size: 0x3
};

// Object: ScriptStruct ControlRig.RigUnit_MathVectorIsNearlyZero
// Inherited Bytes: 0x8 | Struct Size: 0x20
struct FRigUnit_MathVectorIsNearlyZero : FRigUnit_MathVectorBase {
	// Fields
	struct FVector Value; // Offset: 0x8 | Size: 0xc
	float Tolerance; // Offset: 0x14 | Size: 0x4
	bool Result; // Offset: 0x18 | Size: 0x1
	char pad_0x19[0x7]; // Offset: 0x19 | Size: 0x7
};

// Object: ScriptStruct ControlRig.RigUnit_MathVectorNotEquals
// Inherited Bytes: 0x8 | Struct Size: 0x28
struct FRigUnit_MathVectorNotEquals : FRigUnit_MathVectorBase {
	// Fields
	struct FVector A; // Offset: 0x8 | Size: 0xc
	struct FVector B; // Offset: 0x14 | Size: 0xc
	bool Result; // Offset: 0x20 | Size: 0x1
	char pad_0x21[0x7]; // Offset: 0x21 | Size: 0x7
};

// Object: ScriptStruct ControlRig.RigUnit_MathVectorEquals
// Inherited Bytes: 0x8 | Struct Size: 0x28
struct FRigUnit_MathVectorEquals : FRigUnit_MathVectorBase {
	// Fields
	struct FVector A; // Offset: 0x8 | Size: 0xc
	struct FVector B; // Offset: 0x14 | Size: 0xc
	bool Result; // Offset: 0x20 | Size: 0x1
	char pad_0x21[0x7]; // Offset: 0x21 | Size: 0x7
};

// Object: ScriptStruct ControlRig.RigUnit_MathVectorRemap
// Inherited Bytes: 0x8 | Struct Size: 0x58
struct FRigUnit_MathVectorRemap : FRigUnit_MathVectorBase {
	// Fields
	struct FVector Value; // Offset: 0x8 | Size: 0xc
	struct FVector SourceMinimum; // Offset: 0x14 | Size: 0xc
	struct FVector SourceMaximum; // Offset: 0x20 | Size: 0xc
	struct FVector TargetMinimum; // Offset: 0x2c | Size: 0xc
	struct FVector TargetMaximum; // Offset: 0x38 | Size: 0xc
	bool bClamp; // Offset: 0x44 | Size: 0x1
	char pad_0x45[0x3]; // Offset: 0x45 | Size: 0x3
	struct FVector Result; // Offset: 0x48 | Size: 0xc
	char pad_0x54[0x4]; // Offset: 0x54 | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_MathVectorLerp
// Inherited Bytes: 0x8 | Struct Size: 0x30
struct FRigUnit_MathVectorLerp : FRigUnit_MathVectorBase {
	// Fields
	struct FVector A; // Offset: 0x8 | Size: 0xc
	struct FVector B; // Offset: 0x14 | Size: 0xc
	float T; // Offset: 0x20 | Size: 0x4
	struct FVector Result; // Offset: 0x24 | Size: 0xc
};

// Object: ScriptStruct ControlRig.RigUnit_MathVectorClamp
// Inherited Bytes: 0x8 | Struct Size: 0x38
struct FRigUnit_MathVectorClamp : FRigUnit_MathVectorBase {
	// Fields
	struct FVector Value; // Offset: 0x8 | Size: 0xc
	struct FVector Minimum; // Offset: 0x14 | Size: 0xc
	struct FVector Maximum; // Offset: 0x20 | Size: 0xc
	struct FVector Result; // Offset: 0x2c | Size: 0xc
};

// Object: ScriptStruct ControlRig.RigUnit_MathVectorSign
// Inherited Bytes: 0x20 | Struct Size: 0x20
struct FRigUnit_MathVectorSign : FRigUnit_MathVectorUnaryOp {
};

// Object: ScriptStruct ControlRig.RigUnit_MathVectorRound
// Inherited Bytes: 0x20 | Struct Size: 0x20
struct FRigUnit_MathVectorRound : FRigUnit_MathVectorUnaryOp {
};

// Object: ScriptStruct ControlRig.RigUnit_MathVectorCeil
// Inherited Bytes: 0x20 | Struct Size: 0x20
struct FRigUnit_MathVectorCeil : FRigUnit_MathVectorUnaryOp {
};

// Object: ScriptStruct ControlRig.RigUnit_MathVectorFloor
// Inherited Bytes: 0x20 | Struct Size: 0x20
struct FRigUnit_MathVectorFloor : FRigUnit_MathVectorUnaryOp {
};

// Object: ScriptStruct ControlRig.RigUnit_MathVectorAbs
// Inherited Bytes: 0x20 | Struct Size: 0x20
struct FRigUnit_MathVectorAbs : FRigUnit_MathVectorUnaryOp {
};

// Object: ScriptStruct ControlRig.RigUnit_MathVectorNegate
// Inherited Bytes: 0x20 | Struct Size: 0x20
struct FRigUnit_MathVectorNegate : FRigUnit_MathVectorUnaryOp {
};

// Object: ScriptStruct ControlRig.RigUnit_MathVectorMax
// Inherited Bytes: 0x30 | Struct Size: 0x30
struct FRigUnit_MathVectorMax : FRigUnit_MathVectorBinaryOp {
};

// Object: ScriptStruct ControlRig.RigUnit_MathVectorMin
// Inherited Bytes: 0x30 | Struct Size: 0x30
struct FRigUnit_MathVectorMin : FRigUnit_MathVectorBinaryOp {
};

// Object: ScriptStruct ControlRig.RigUnit_MathVectorMod
// Inherited Bytes: 0x30 | Struct Size: 0x30
struct FRigUnit_MathVectorMod : FRigUnit_MathVectorBinaryOp {
};

// Object: ScriptStruct ControlRig.RigUnit_MathVectorDiv
// Inherited Bytes: 0x30 | Struct Size: 0x30
struct FRigUnit_MathVectorDiv : FRigUnit_MathVectorBinaryOp {
};

// Object: ScriptStruct ControlRig.RigUnit_MathVectorScale
// Inherited Bytes: 0x8 | Struct Size: 0x28
struct FRigUnit_MathVectorScale : FRigUnit_MathVectorBase {
	// Fields
	struct FVector Value; // Offset: 0x8 | Size: 0xc
	float Factor; // Offset: 0x14 | Size: 0x4
	struct FVector Result; // Offset: 0x18 | Size: 0xc
	char pad_0x24[0x4]; // Offset: 0x24 | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_MathVectorMul
// Inherited Bytes: 0x30 | Struct Size: 0x30
struct FRigUnit_MathVectorMul : FRigUnit_MathVectorBinaryOp {
};

// Object: ScriptStruct ControlRig.RigUnit_MathVectorSub
// Inherited Bytes: 0x30 | Struct Size: 0x30
struct FRigUnit_MathVectorSub : FRigUnit_MathVectorBinaryOp {
};

// Object: ScriptStruct ControlRig.RigUnit_MathVectorAdd
// Inherited Bytes: 0x30 | Struct Size: 0x30
struct FRigUnit_MathVectorAdd : FRigUnit_MathVectorBinaryOp {
};

// Object: ScriptStruct ControlRig.RigUnit_MathVectorFromFloat
// Inherited Bytes: 0x8 | Struct Size: 0x18
struct FRigUnit_MathVectorFromFloat : FRigUnit_MathVectorBase {
	// Fields
	float Value; // Offset: 0x8 | Size: 0x4
	struct FVector Result; // Offset: 0xc | Size: 0xc
};

// Object: ScriptStruct ControlRig.RigUnit_ModifyBoneTransforms
// Inherited Bytes: 0x20 | Struct Size: 0x50
struct FRigUnit_ModifyBoneTransforms : FRigUnit_HighlevelBaseMutable {
	// Fields
	struct TArray<struct FRigUnit_ModifyBoneTransforms_PerBone> BoneToModify; // Offset: 0x20 | Size: 0x10
	float Weight; // Offset: 0x30 | Size: 0x4
	float WeightMinimum; // Offset: 0x34 | Size: 0x4
	float WeightMaximum; // Offset: 0x38 | Size: 0x4
	enum class EControlRigModifyBoneMode Mode; // Offset: 0x3c | Size: 0x1
	char pad_0x3D[0x3]; // Offset: 0x3d | Size: 0x3
	struct FRigUnit_ModifyBoneTransforms_WorkData WorkData; // Offset: 0x40 | Size: 0x10
};

// Object: ScriptStruct ControlRig.RigUnit_ModifyBoneTransforms_WorkData
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FRigUnit_ModifyBoneTransforms_WorkData {
	// Fields
	struct TArray<int32_t> CachedBoneIndices; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct ControlRig.RigUnit_ModifyBoneTransforms_PerBone
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FRigUnit_ModifyBoneTransforms_PerBone {
	// Fields
	struct FName Bone; // Offset: 0x0 | Size: 0x8
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FTransform Transform; // Offset: 0x10 | Size: 0x30
};

// Object: ScriptStruct ControlRig.RigUnit_MultiFABRIK
// Inherited Bytes: 0x20 | Struct Size: 0xa8
struct FRigUnit_MultiFABRIK : FRigUnit_HighlevelBaseMutable {
	// Fields
	struct FName RootBone; // Offset: 0x20 | Size: 0x8
	struct TArray<struct FRigUnit_MultiFABRIK_EndEffector> Effectors; // Offset: 0x28 | Size: 0x10
	float Precision; // Offset: 0x38 | Size: 0x4
	bool bPropagateToChildren; // Offset: 0x3c | Size: 0x1
	char pad_0x3D[0x3]; // Offset: 0x3d | Size: 0x3
	int32_t MaxIterations; // Offset: 0x40 | Size: 0x4
	char pad_0x44[0x4]; // Offset: 0x44 | Size: 0x4
	struct FRigUnit_MultiFABRIK_WorkData WorkData; // Offset: 0x48 | Size: 0x60
};

// Object: ScriptStruct ControlRig.RigUnit_MultiFABRIK_WorkData
// Inherited Bytes: 0x0 | Struct Size: 0x60
struct FRigUnit_MultiFABRIK_WorkData {
	// Fields
	char pad_0x0[0x60]; // Offset: 0x0 | Size: 0x60
};

// Object: ScriptStruct ControlRig.RigUnit_MultiFABRIK_EndEffector
// Inherited Bytes: 0x0 | Struct Size: 0x14
struct FRigUnit_MultiFABRIK_EndEffector {
	// Fields
	struct FName Bone; // Offset: 0x0 | Size: 0x8
	struct FVector Location; // Offset: 0x8 | Size: 0xc
};

// Object: ScriptStruct ControlRig.RigUnit_NoiseVector
// Inherited Bytes: 0x8 | Struct Size: 0x50
struct FRigUnit_NoiseVector : FRigUnit_MathBase {
	// Fields
	struct FVector Position; // Offset: 0x8 | Size: 0xc
	struct FVector Speed; // Offset: 0x14 | Size: 0xc
	struct FVector Frequency; // Offset: 0x20 | Size: 0xc
	float Minimum; // Offset: 0x2c | Size: 0x4
	float Maximum; // Offset: 0x30 | Size: 0x4
	struct FVector Result; // Offset: 0x34 | Size: 0xc
	struct FVector Time; // Offset: 0x40 | Size: 0xc
	char pad_0x4C[0x4]; // Offset: 0x4c | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_NoiseFloat
// Inherited Bytes: 0x8 | Struct Size: 0x28
struct FRigUnit_NoiseFloat : FRigUnit_MathBase {
	// Fields
	float Value; // Offset: 0x8 | Size: 0x4
	float Speed; // Offset: 0xc | Size: 0x4
	float Frequency; // Offset: 0x10 | Size: 0x4
	float Minimum; // Offset: 0x14 | Size: 0x4
	float Maximum; // Offset: 0x18 | Size: 0x4
	float Result; // Offset: 0x1c | Size: 0x4
	float Time; // Offset: 0x20 | Size: 0x4
	char pad_0x24[0x4]; // Offset: 0x24 | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_SimBaseMutable
// Inherited Bytes: 0x20 | Struct Size: 0x20
struct FRigUnit_SimBaseMutable : FRigUnitMutable {
};

// Object: ScriptStruct ControlRig.RigUnit_PointSimulation
// Inherited Bytes: 0x20 | Struct Size: 0x1b0
struct FRigUnit_PointSimulation : FRigUnit_SimBaseMutable {
	// Fields
	struct TArray<struct FCRSimPoint> Points; // Offset: 0x20 | Size: 0x10
	struct TArray<struct FCRSimLinearSpring> Links; // Offset: 0x30 | Size: 0x10
	struct TArray<struct FCRSimPointForce> Forces; // Offset: 0x40 | Size: 0x10
	struct TArray<struct FCRSimSoftCollision> CollisionVolumes; // Offset: 0x50 | Size: 0x10
	float SimulatedStepsPerSecond; // Offset: 0x60 | Size: 0x4
	enum class ECRSimPointIntegrateType IntegratorType; // Offset: 0x64 | Size: 0x1
	char pad_0x65[0x3]; // Offset: 0x65 | Size: 0x3
	float VerletBlend; // Offset: 0x68 | Size: 0x4
	char pad_0x6C[0x4]; // Offset: 0x6c | Size: 0x4
	struct TArray<struct FRigUnit_PointSimulation_BoneTarget> BoneTargets; // Offset: 0x70 | Size: 0x10
	bool bLimitLocalPosition; // Offset: 0x80 | Size: 0x1
	bool bPropagateToChildren; // Offset: 0x81 | Size: 0x1
	char pad_0x82[0x2]; // Offset: 0x82 | Size: 0x2
	struct FVector PrimaryAimAxis; // Offset: 0x84 | Size: 0xc
	struct FVector SecondaryAimAxis; // Offset: 0x90 | Size: 0xc
	char pad_0x9C[0x4]; // Offset: 0x9c | Size: 0x4
	struct FRigUnit_PointSimulation_DebugSettings DebugSettings; // Offset: 0xa0 | Size: 0x50
	struct FCRFourPointBezier Bezier; // Offset: 0xf0 | Size: 0x30
	struct FRigUnit_PointSimulation_WorkData WorkData; // Offset: 0x120 | Size: 0x88
	char pad_0x1A8[0x8]; // Offset: 0x1a8 | Size: 0x8
};

// Object: ScriptStruct ControlRig.RigUnit_PointSimulation_WorkData
// Inherited Bytes: 0x0 | Struct Size: 0x88
struct FRigUnit_PointSimulation_WorkData {
	// Fields
	struct FCRSimPointContainer Simulation; // Offset: 0x0 | Size: 0x78
	struct TArray<int32_t> BoneIndices; // Offset: 0x78 | Size: 0x10
};

// Object: ScriptStruct ControlRig.RigUnit_PointSimulation_DebugSettings
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FRigUnit_PointSimulation_DebugSettings {
	// Fields
	bool bEnabled; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	float Scale; // Offset: 0x4 | Size: 0x4
	float CollisionScale; // Offset: 0x8 | Size: 0x4
	bool bDrawPointsAsSpheres; // Offset: 0xc | Size: 0x1
	char pad_0xD[0x3]; // Offset: 0xd | Size: 0x3
	struct FLinearColor Color; // Offset: 0x10 | Size: 0x10
	struct FTransform WorldOffset; // Offset: 0x20 | Size: 0x30
};

// Object: ScriptStruct ControlRig.RigUnit_PointSimulation_BoneTarget
// Inherited Bytes: 0x0 | Struct Size: 0x14
struct FRigUnit_PointSimulation_BoneTarget {
	// Fields
	struct FName Bone; // Offset: 0x0 | Size: 0x8
	int32_t TranslationPoint; // Offset: 0x8 | Size: 0x4
	int32_t PrimaryAimPoint; // Offset: 0xc | Size: 0x4
	int32_t SecondaryAimPoint; // Offset: 0x10 | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_EndProfilingTimer
// Inherited Bytes: 0x20 | Struct Size: 0x40
struct FRigUnit_EndProfilingTimer : FRigUnit_DebugBaseMutable {
	// Fields
	int32_t NumberOfMeasurements; // Offset: 0x20 | Size: 0x4
	char pad_0x24[0x4]; // Offset: 0x24 | Size: 0x4
	struct FString Prefix; // Offset: 0x28 | Size: 0x10
	float AccumulatedTime; // Offset: 0x38 | Size: 0x4
	int32_t MeasurementsLeft; // Offset: 0x3c | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_StartProfilingTimer
// Inherited Bytes: 0x20 | Struct Size: 0x20
struct FRigUnit_StartProfilingTimer : FRigUnit_DebugBaseMutable {
};

// Object: ScriptStruct ControlRig.RigUnit_QuaternionToAngle
// Inherited Bytes: 0x8 | Struct Size: 0x40
struct FRigUnit_QuaternionToAngle : FRigUnit {
	// Fields
	struct FVector Axis; // Offset: 0x8 | Size: 0xc
	char pad_0x14[0xc]; // Offset: 0x14 | Size: 0xc
	struct FQuat Argument; // Offset: 0x20 | Size: 0x10
	float Angle; // Offset: 0x30 | Size: 0x4
	char pad_0x34[0xc]; // Offset: 0x34 | Size: 0xc
};

// Object: ScriptStruct ControlRig.RigUnit_QuaternionFromAxisAndAngle
// Inherited Bytes: 0x8 | Struct Size: 0x30
struct FRigUnit_QuaternionFromAxisAndAngle : FRigUnit {
	// Fields
	struct FVector Axis; // Offset: 0x8 | Size: 0xc
	float Angle; // Offset: 0x14 | Size: 0x4
	char pad_0x18[0x8]; // Offset: 0x18 | Size: 0x8
	struct FQuat Result; // Offset: 0x20 | Size: 0x10
};

// Object: ScriptStruct ControlRig.RigUnit_QuaternionToAxisAndAngle
// Inherited Bytes: 0x8 | Struct Size: 0x30
struct FRigUnit_QuaternionToAxisAndAngle : FRigUnit {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FQuat Argument; // Offset: 0x10 | Size: 0x10
	struct FVector Axis; // Offset: 0x20 | Size: 0xc
	float Angle; // Offset: 0x2c | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_UnaryQuaternionOp
// Inherited Bytes: 0x8 | Struct Size: 0x30
struct FRigUnit_UnaryQuaternionOp : FRigUnit {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FQuat Argument; // Offset: 0x10 | Size: 0x10
	struct FQuat Result; // Offset: 0x20 | Size: 0x10
};

// Object: ScriptStruct ControlRig.RigUnit_InverseQuaterion
// Inherited Bytes: 0x30 | Struct Size: 0x30
struct FRigUnit_InverseQuaterion : FRigUnit_UnaryQuaternionOp {
};

// Object: ScriptStruct ControlRig.RigUnit_BinaryQuaternionOp
// Inherited Bytes: 0x8 | Struct Size: 0x40
struct FRigUnit_BinaryQuaternionOp : FRigUnit {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FQuat Argument0; // Offset: 0x10 | Size: 0x10
	struct FQuat Argument1; // Offset: 0x20 | Size: 0x10
	struct FQuat Result; // Offset: 0x30 | Size: 0x10
};

// Object: ScriptStruct ControlRig.RigUnit_MultiplyQuaternion
// Inherited Bytes: 0x40 | Struct Size: 0x40
struct FRigUnit_MultiplyQuaternion : FRigUnit_BinaryQuaternionOp {
};

// Object: ScriptStruct ControlRig.RigUnit_RandomVector
// Inherited Bytes: 0x8 | Struct Size: 0x38
struct FRigUnit_RandomVector : FRigUnit_MathBase {
	// Fields
	int32_t Seed; // Offset: 0x8 | Size: 0x4
	float Minimum; // Offset: 0xc | Size: 0x4
	float Maximum; // Offset: 0x10 | Size: 0x4
	float Duration; // Offset: 0x14 | Size: 0x4
	struct FVector Result; // Offset: 0x18 | Size: 0xc
	struct FVector LastResult; // Offset: 0x24 | Size: 0xc
	int32_t LastSeed; // Offset: 0x30 | Size: 0x4
	float TimeLeft; // Offset: 0x34 | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_RandomFloat
// Inherited Bytes: 0x8 | Struct Size: 0x28
struct FRigUnit_RandomFloat : FRigUnit_MathBase {
	// Fields
	int32_t Seed; // Offset: 0x8 | Size: 0x4
	float Minimum; // Offset: 0xc | Size: 0x4
	float Maximum; // Offset: 0x10 | Size: 0x4
	float Duration; // Offset: 0x14 | Size: 0x4
	float Result; // Offset: 0x18 | Size: 0x4
	float LastResult; // Offset: 0x1c | Size: 0x4
	int32_t LastSeed; // Offset: 0x20 | Size: 0x4
	float TimeLeft; // Offset: 0x24 | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_SetBoneRotation
// Inherited Bytes: 0x20 | Struct Size: 0x50
struct FRigUnit_SetBoneRotation : FRigUnitMutable {
	// Fields
	struct FName Bone; // Offset: 0x20 | Size: 0x8
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
	struct FQuat Rotation; // Offset: 0x30 | Size: 0x10
	enum class EBoneGetterSetterMode Space; // Offset: 0x40 | Size: 0x1
	char pad_0x41[0x3]; // Offset: 0x41 | Size: 0x3
	float Weight; // Offset: 0x44 | Size: 0x4
	bool bPropagateToChildren; // Offset: 0x48 | Size: 0x1
	char pad_0x49[0x3]; // Offset: 0x49 | Size: 0x3
	int32_t CachedBoneIndex; // Offset: 0x4c | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_SetBoneTransform
// Inherited Bytes: 0x20 | Struct Size: 0x70
struct FRigUnit_SetBoneTransform : FRigUnitMutable {
	// Fields
	struct FName Bone; // Offset: 0x20 | Size: 0x8
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
	struct FTransform Transform; // Offset: 0x30 | Size: 0x30
	enum class EBoneGetterSetterMode Space; // Offset: 0x60 | Size: 0x1
	char pad_0x61[0x3]; // Offset: 0x61 | Size: 0x3
	float Weight; // Offset: 0x64 | Size: 0x4
	bool bPropagateToChildren; // Offset: 0x68 | Size: 0x1
	char pad_0x69[0x3]; // Offset: 0x69 | Size: 0x3
	int32_t CachedBoneIndex; // Offset: 0x6c | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_SetBoneTranslation
// Inherited Bytes: 0x20 | Struct Size: 0x48
struct FRigUnit_SetBoneTranslation : FRigUnitMutable {
	// Fields
	struct FName Bone; // Offset: 0x20 | Size: 0x8
	struct FVector Translation; // Offset: 0x28 | Size: 0xc
	enum class EBoneGetterSetterMode Space; // Offset: 0x34 | Size: 0x1
	char pad_0x35[0x3]; // Offset: 0x35 | Size: 0x3
	float Weight; // Offset: 0x38 | Size: 0x4
	bool bPropagateToChildren; // Offset: 0x3c | Size: 0x1
	char pad_0x3D[0x3]; // Offset: 0x3d | Size: 0x3
	int32_t CachedBoneIndex; // Offset: 0x40 | Size: 0x4
	char pad_0x44[0x4]; // Offset: 0x44 | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_SetControlColor
// Inherited Bytes: 0x20 | Struct Size: 0x40
struct FRigUnit_SetControlColor : FRigUnitMutable {
	// Fields
	struct FName Control; // Offset: 0x20 | Size: 0x8
	struct FLinearColor Color; // Offset: 0x28 | Size: 0x10
	int32_t CachedControlIndex; // Offset: 0x38 | Size: 0x4
	char pad_0x3C[0x4]; // Offset: 0x3c | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_SetControlTransform
// Inherited Bytes: 0x20 | Struct Size: 0x70
struct FRigUnit_SetControlTransform : FRigUnitMutable {
	// Fields
	struct FName Control; // Offset: 0x20 | Size: 0x8
	float Weight; // Offset: 0x28 | Size: 0x4
	char pad_0x2C[0x4]; // Offset: 0x2c | Size: 0x4
	struct FTransform Transform; // Offset: 0x30 | Size: 0x30
	enum class EBoneGetterSetterMode Space; // Offset: 0x60 | Size: 0x1
	char pad_0x61[0x3]; // Offset: 0x61 | Size: 0x3
	int32_t CachedControlIndex; // Offset: 0x64 | Size: 0x4
	char pad_0x68[0x8]; // Offset: 0x68 | Size: 0x8
};

// Object: ScriptStruct ControlRig.RigUnit_SetControlRotator
// Inherited Bytes: 0x20 | Struct Size: 0x40
struct FRigUnit_SetControlRotator : FRigUnitMutable {
	// Fields
	struct FName Control; // Offset: 0x20 | Size: 0x8
	float Weight; // Offset: 0x28 | Size: 0x4
	struct FRotator Rotator; // Offset: 0x2c | Size: 0xc
	enum class EBoneGetterSetterMode Space; // Offset: 0x38 | Size: 0x1
	char pad_0x39[0x3]; // Offset: 0x39 | Size: 0x3
	int32_t CachedControlIndex; // Offset: 0x3c | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_SetControlVector
// Inherited Bytes: 0x20 | Struct Size: 0x40
struct FRigUnit_SetControlVector : FRigUnitMutable {
	// Fields
	struct FName Control; // Offset: 0x20 | Size: 0x8
	float Weight; // Offset: 0x28 | Size: 0x4
	struct FVector Vector; // Offset: 0x2c | Size: 0xc
	enum class EBoneGetterSetterMode Space; // Offset: 0x38 | Size: 0x1
	char pad_0x39[0x3]; // Offset: 0x39 | Size: 0x3
	int32_t CachedControlIndex; // Offset: 0x3c | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_SetControlVector2D
// Inherited Bytes: 0x20 | Struct Size: 0x38
struct FRigUnit_SetControlVector2D : FRigUnitMutable {
	// Fields
	struct FName Control; // Offset: 0x20 | Size: 0x8
	float Weight; // Offset: 0x28 | Size: 0x4
	struct FVector2D Vector; // Offset: 0x2c | Size: 0x8
	int32_t CachedControlIndex; // Offset: 0x34 | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_SetControlFloat
// Inherited Bytes: 0x20 | Struct Size: 0x38
struct FRigUnit_SetControlFloat : FRigUnitMutable {
	// Fields
	struct FName Control; // Offset: 0x20 | Size: 0x8
	float Weight; // Offset: 0x28 | Size: 0x4
	float FloatValue; // Offset: 0x2c | Size: 0x4
	int32_t CachedControlIndex; // Offset: 0x30 | Size: 0x4
	char pad_0x34[0x4]; // Offset: 0x34 | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_SetControlBool
// Inherited Bytes: 0x20 | Struct Size: 0x30
struct FRigUnit_SetControlBool : FRigUnitMutable {
	// Fields
	struct FName Control; // Offset: 0x20 | Size: 0x8
	bool BoolValue; // Offset: 0x28 | Size: 0x1
	char pad_0x29[0x3]; // Offset: 0x29 | Size: 0x3
	int32_t CachedControlIndex; // Offset: 0x2c | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_SetCurveValue
// Inherited Bytes: 0x20 | Struct Size: 0x30
struct FRigUnit_SetCurveValue : FRigUnitMutable {
	// Fields
	struct FName Curve; // Offset: 0x20 | Size: 0x8
	float Value; // Offset: 0x28 | Size: 0x4
	int32_t CachedCurveIndex; // Offset: 0x2c | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_SetRelativeBoneTransform
// Inherited Bytes: 0x20 | Struct Size: 0x70
struct FRigUnit_SetRelativeBoneTransform : FRigUnitMutable {
	// Fields
	struct FName Bone; // Offset: 0x20 | Size: 0x8
	struct FName Space; // Offset: 0x28 | Size: 0x8
	struct FTransform Transform; // Offset: 0x30 | Size: 0x30
	float Weight; // Offset: 0x60 | Size: 0x4
	bool bPropagateToChildren; // Offset: 0x64 | Size: 0x1
	char pad_0x65[0x3]; // Offset: 0x65 | Size: 0x3
	int32_t CachedBoneIndex; // Offset: 0x68 | Size: 0x4
	int32_t CachedSpaceIndex; // Offset: 0x6c | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_SetSpaceTransform
// Inherited Bytes: 0x20 | Struct Size: 0x70
struct FRigUnit_SetSpaceTransform : FRigUnitMutable {
	// Fields
	struct FName Space; // Offset: 0x20 | Size: 0x8
	float Weight; // Offset: 0x28 | Size: 0x4
	char pad_0x2C[0x4]; // Offset: 0x2c | Size: 0x4
	struct FTransform Transform; // Offset: 0x30 | Size: 0x30
	enum class EBoneGetterSetterMode SpaceType; // Offset: 0x60 | Size: 0x1
	char pad_0x61[0x3]; // Offset: 0x61 | Size: 0x3
	int32_t CachedSpaceIndex; // Offset: 0x64 | Size: 0x4
	char pad_0x68[0x8]; // Offset: 0x68 | Size: 0x8
};

// Object: ScriptStruct ControlRig.RigUnit_SlideChain
// Inherited Bytes: 0x20 | Struct Size: 0x80
struct FRigUnit_SlideChain : FRigUnit_HighlevelBaseMutable {
	// Fields
	struct FName StartBone; // Offset: 0x20 | Size: 0x8
	struct FName EndBone; // Offset: 0x28 | Size: 0x8
	float SlideAmount; // Offset: 0x30 | Size: 0x4
	bool bPropagateToChildren; // Offset: 0x34 | Size: 0x1
	char pad_0x35[0x3]; // Offset: 0x35 | Size: 0x3
	struct FRigUnit_SlideChain_WorkData WorkData; // Offset: 0x38 | Size: 0x48
};

// Object: ScriptStruct ControlRig.RigUnit_SlideChain_WorkData
// Inherited Bytes: 0x0 | Struct Size: 0x48
struct FRigUnit_SlideChain_WorkData {
	// Fields
	float ChainLength; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct TArray<float> BoneSegments; // Offset: 0x8 | Size: 0x10
	struct TArray<int32_t> BoneIndices; // Offset: 0x18 | Size: 0x10
	struct TArray<struct FTransform> Transforms; // Offset: 0x28 | Size: 0x10
	struct TArray<struct FTransform> BlendedTransforms; // Offset: 0x38 | Size: 0x10
};

// Object: ScriptStruct ControlRig.RigUnit_SpringIK
// Inherited Bytes: 0x20 | Struct Size: 0x180
struct FRigUnit_SpringIK : FRigUnit_HighlevelBaseMutable {
	// Fields
	struct FName StartBone; // Offset: 0x20 | Size: 0x8
	struct FName EndBone; // Offset: 0x28 | Size: 0x8
	float HierarchyStrength; // Offset: 0x30 | Size: 0x4
	float EffectorStrength; // Offset: 0x34 | Size: 0x4
	float EffectorRatio; // Offset: 0x38 | Size: 0x4
	float RootStrength; // Offset: 0x3c | Size: 0x4
	float RootRatio; // Offset: 0x40 | Size: 0x4
	float Damping; // Offset: 0x44 | Size: 0x4
	struct FVector PoleVector; // Offset: 0x48 | Size: 0xc
	bool bFlipPolePlane; // Offset: 0x54 | Size: 0x1
	enum class EControlRigVectorKind PoleVectorKind; // Offset: 0x55 | Size: 0x1
	char pad_0x56[0x2]; // Offset: 0x56 | Size: 0x2
	struct FName PoleVectorSpace; // Offset: 0x58 | Size: 0x8
	struct FVector PrimaryAxis; // Offset: 0x60 | Size: 0xc
	struct FVector SecondaryAxis; // Offset: 0x6c | Size: 0xc
	bool bLiveSimulation; // Offset: 0x78 | Size: 0x1
	char pad_0x79[0x3]; // Offset: 0x79 | Size: 0x3
	int32_t Iterations; // Offset: 0x7c | Size: 0x4
	bool bLimitLocalPosition; // Offset: 0x80 | Size: 0x1
	bool bPropagateToChildren; // Offset: 0x81 | Size: 0x1
	char pad_0x82[0xe]; // Offset: 0x82 | Size: 0xe
	struct FRigUnit_SpringIK_DebugSettings DebugSettings; // Offset: 0x90 | Size: 0x50
	struct FRigUnit_SpringIK_WorkData WorkData; // Offset: 0xe0 | Size: 0xa0
};

// Object: ScriptStruct ControlRig.RigUnit_SpringIK_WorkData
// Inherited Bytes: 0x0 | Struct Size: 0xa0
struct FRigUnit_SpringIK_WorkData {
	// Fields
	struct TArray<int32_t> BoneIndices; // Offset: 0x0 | Size: 0x10
	int32_t PoleVectorIndex; // Offset: 0x10 | Size: 0x4
	char pad_0x14[0x4]; // Offset: 0x14 | Size: 0x4
	struct TArray<struct FTransform> Transforms; // Offset: 0x18 | Size: 0x10
	struct FCRSimPointContainer Simulation; // Offset: 0x28 | Size: 0x78
};

// Object: ScriptStruct ControlRig.RigUnit_SpringIK_DebugSettings
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FRigUnit_SpringIK_DebugSettings {
	// Fields
	bool bEnabled; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	float Scale; // Offset: 0x4 | Size: 0x4
	struct FLinearColor Color; // Offset: 0x8 | Size: 0x10
	char pad_0x18[0x8]; // Offset: 0x18 | Size: 0x8
	struct FTransform WorldOffset; // Offset: 0x20 | Size: 0x30
};

// Object: ScriptStruct ControlRig.RigUnit_Timeline
// Inherited Bytes: 0x8 | Struct Size: 0x18
struct FRigUnit_Timeline : FRigUnit_SimBase {
	// Fields
	float Speed; // Offset: 0x8 | Size: 0x4
	float Time; // Offset: 0xc | Size: 0x4
	float AccumulatedValue; // Offset: 0x10 | Size: 0x4
	char pad_0x14[0x4]; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_TimeOffsetTransform
// Inherited Bytes: 0x8 | Struct Size: 0xb0
struct FRigUnit_TimeOffsetTransform : FRigUnit_SimBase {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FTransform Value; // Offset: 0x10 | Size: 0x30
	float SecondsAgo; // Offset: 0x40 | Size: 0x4
	int32_t BufferSize; // Offset: 0x44 | Size: 0x4
	float TimeRange; // Offset: 0x48 | Size: 0x4
	char pad_0x4C[0x4]; // Offset: 0x4c | Size: 0x4
	struct FTransform Result; // Offset: 0x50 | Size: 0x30
	struct TArray<struct FTransform> Buffer; // Offset: 0x80 | Size: 0x10
	struct TArray<float> DeltaTimes; // Offset: 0x90 | Size: 0x10
	int32_t LastInsertIndex; // Offset: 0xa0 | Size: 0x4
	int32_t UpperBound; // Offset: 0xa4 | Size: 0x4
	char pad_0xA8[0x8]; // Offset: 0xa8 | Size: 0x8
};

// Object: ScriptStruct ControlRig.RigUnit_TimeOffsetVector
// Inherited Bytes: 0x8 | Struct Size: 0x58
struct FRigUnit_TimeOffsetVector : FRigUnit_SimBase {
	// Fields
	struct FVector Value; // Offset: 0x8 | Size: 0xc
	float SecondsAgo; // Offset: 0x14 | Size: 0x4
	int32_t BufferSize; // Offset: 0x18 | Size: 0x4
	float TimeRange; // Offset: 0x1c | Size: 0x4
	struct FVector Result; // Offset: 0x20 | Size: 0xc
	char pad_0x2C[0x4]; // Offset: 0x2c | Size: 0x4
	struct TArray<struct FVector> Buffer; // Offset: 0x30 | Size: 0x10
	struct TArray<float> DeltaTimes; // Offset: 0x40 | Size: 0x10
	int32_t LastInsertIndex; // Offset: 0x50 | Size: 0x4
	int32_t UpperBound; // Offset: 0x54 | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_TimeOffsetFloat
// Inherited Bytes: 0x8 | Struct Size: 0x48
struct FRigUnit_TimeOffsetFloat : FRigUnit_SimBase {
	// Fields
	float Value; // Offset: 0x8 | Size: 0x4
	float SecondsAgo; // Offset: 0xc | Size: 0x4
	int32_t BufferSize; // Offset: 0x10 | Size: 0x4
	float TimeRange; // Offset: 0x14 | Size: 0x4
	float Result; // Offset: 0x18 | Size: 0x4
	char pad_0x1C[0x4]; // Offset: 0x1c | Size: 0x4
	struct TArray<float> Buffer; // Offset: 0x20 | Size: 0x10
	struct TArray<float> DeltaTimes; // Offset: 0x30 | Size: 0x10
	int32_t LastInsertIndex; // Offset: 0x40 | Size: 0x4
	int32_t UpperBound; // Offset: 0x44 | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_BinaryTransformOp
// Inherited Bytes: 0x8 | Struct Size: 0xa0
struct FRigUnit_BinaryTransformOp : FRigUnit {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FTransform Argument0; // Offset: 0x10 | Size: 0x30
	struct FTransform Argument1; // Offset: 0x40 | Size: 0x30
	struct FTransform Result; // Offset: 0x70 | Size: 0x30
};

// Object: ScriptStruct ControlRig.RigUnit_GetRelativeTransform
// Inherited Bytes: 0xa0 | Struct Size: 0xa0
struct FRigUnit_GetRelativeTransform : FRigUnit_BinaryTransformOp {
};

// Object: ScriptStruct ControlRig.RigUnit_MultiplyTransform
// Inherited Bytes: 0xa0 | Struct Size: 0xa0
struct FRigUnit_MultiplyTransform : FRigUnit_BinaryTransformOp {
};

// Object: ScriptStruct ControlRig.RigUnit_TransformConstraint
// Inherited Bytes: 0x20 | Struct Size: 0xe0
struct FRigUnit_TransformConstraint : FRigUnit_HighlevelBaseMutable {
	// Fields
	struct FName Bone; // Offset: 0x20 | Size: 0x8
	enum class ETransformSpaceMode BaseTransformSpace; // Offset: 0x28 | Size: 0x1
	char pad_0x29[0x7]; // Offset: 0x29 | Size: 0x7
	struct FTransform BaseTransform; // Offset: 0x30 | Size: 0x30
	struct FName BaseBone; // Offset: 0x60 | Size: 0x8
	struct TArray<struct FConstraintTarget> Targets; // Offset: 0x68 | Size: 0x10
	struct FRigUnit_TransformConstraint_WorkData WorkData; // Offset: 0x78 | Size: 0x60
	char pad_0xD8[0x8]; // Offset: 0xd8 | Size: 0x8
};

// Object: ScriptStruct ControlRig.RigUnit_TransformConstraint_WorkData
// Inherited Bytes: 0x0 | Struct Size: 0x60
struct FRigUnit_TransformConstraint_WorkData {
	// Fields
	struct TArray<struct FConstraintData> ConstraintData; // Offset: 0x0 | Size: 0x10
	struct TMap<int32_t, int32_t> ConstraintDataToTargets; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct ControlRig.ConstraintTarget
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FConstraintTarget {
	// Fields
	struct FTransform Transform; // Offset: 0x0 | Size: 0x30
	float Weight; // Offset: 0x30 | Size: 0x4
	bool bMaintainOffset; // Offset: 0x34 | Size: 0x1
	struct FTransformFilter Filter; // Offset: 0x35 | Size: 0x9
	char pad_0x3E[0x2]; // Offset: 0x3e | Size: 0x2
};

// Object: ScriptStruct ControlRig.RigUnit_TwoBoneIKFK
// Inherited Bytes: 0x20 | Struct Size: 0x1d0
struct FRigUnit_TwoBoneIKFK : FRigUnitMutable {
	// Fields
	struct FName StartJoint; // Offset: 0x20 | Size: 0x8
	struct FName EndJoint; // Offset: 0x28 | Size: 0x8
	struct FVector PoleTarget; // Offset: 0x30 | Size: 0xc
	float Spin; // Offset: 0x3c | Size: 0x4
	struct FTransform EndEffector; // Offset: 0x40 | Size: 0x30
	float IKBlend; // Offset: 0x70 | Size: 0x4
	char pad_0x74[0xc]; // Offset: 0x74 | Size: 0xc
	struct FTransform StartJointFKTransform; // Offset: 0x80 | Size: 0x30
	struct FTransform MidJointFKTransform; // Offset: 0xb0 | Size: 0x30
	struct FTransform EndJointFKTransform; // Offset: 0xe0 | Size: 0x30
	float PreviousFKIKBlend; // Offset: 0x110 | Size: 0x4
	char pad_0x114[0xc]; // Offset: 0x114 | Size: 0xc
	struct FTransform StartJointIKTransform; // Offset: 0x120 | Size: 0x30
	struct FTransform MidJointIKTransform; // Offset: 0x150 | Size: 0x30
	struct FTransform EndJointIKTransform; // Offset: 0x180 | Size: 0x30
	int32_t StartJointIndex; // Offset: 0x1b0 | Size: 0x4
	int32_t MidJointIndex; // Offset: 0x1b4 | Size: 0x4
	int32_t EndJointIndex; // Offset: 0x1b8 | Size: 0x4
	float UpperLimbLength; // Offset: 0x1bc | Size: 0x4
	float LowerLimbLength; // Offset: 0x1c0 | Size: 0x4
	char pad_0x1C4[0xc]; // Offset: 0x1c4 | Size: 0xc
};

// Object: ScriptStruct ControlRig.RigUnit_TwoBoneIKSimpleTransforms
// Inherited Bytes: 0x8 | Struct Size: 0xe0
struct FRigUnit_TwoBoneIKSimpleTransforms : FRigUnit_HighlevelBase {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FTransform Root; // Offset: 0x10 | Size: 0x30
	struct FVector PoleVector; // Offset: 0x40 | Size: 0xc
	char pad_0x4C[0x4]; // Offset: 0x4c | Size: 0x4
	struct FTransform Effector; // Offset: 0x50 | Size: 0x30
	struct FVector PrimaryAxis; // Offset: 0x80 | Size: 0xc
	struct FVector SecondaryAxis; // Offset: 0x8c | Size: 0xc
	float SecondaryAxisWeight; // Offset: 0x98 | Size: 0x4
	bool bEnableStretch; // Offset: 0x9c | Size: 0x1
	char pad_0x9D[0x3]; // Offset: 0x9d | Size: 0x3
	float StretchStartRatio; // Offset: 0xa0 | Size: 0x4
	float StretchMaximumRatio; // Offset: 0xa4 | Size: 0x4
	float BoneALength; // Offset: 0xa8 | Size: 0x4
	float BoneBLength; // Offset: 0xac | Size: 0x4
	struct FTransform Elbow; // Offset: 0xb0 | Size: 0x30
};

// Object: ScriptStruct ControlRig.RigUnit_TwoBoneIKSimpleVectors
// Inherited Bytes: 0x8 | Struct Size: 0x50
struct FRigUnit_TwoBoneIKSimpleVectors : FRigUnit_HighlevelBase {
	// Fields
	struct FVector Root; // Offset: 0x8 | Size: 0xc
	struct FVector PoleVector; // Offset: 0x14 | Size: 0xc
	struct FVector Effector; // Offset: 0x20 | Size: 0xc
	bool bEnableStretch; // Offset: 0x2c | Size: 0x1
	char pad_0x2D[0x3]; // Offset: 0x2d | Size: 0x3
	float StretchStartRatio; // Offset: 0x30 | Size: 0x4
	float StretchMaximumRatio; // Offset: 0x34 | Size: 0x4
	float BoneALength; // Offset: 0x38 | Size: 0x4
	float BoneBLength; // Offset: 0x3c | Size: 0x4
	struct FVector Elbow; // Offset: 0x40 | Size: 0xc
	char pad_0x4C[0x4]; // Offset: 0x4c | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_TwoBoneIKSimple
// Inherited Bytes: 0x20 | Struct Size: 0x110
struct FRigUnit_TwoBoneIKSimple : FRigUnit_HighlevelBaseMutable {
	// Fields
	struct FName BoneA; // Offset: 0x20 | Size: 0x8
	struct FName BoneB; // Offset: 0x28 | Size: 0x8
	struct FName EffectorBone; // Offset: 0x30 | Size: 0x8
	char pad_0x38[0x8]; // Offset: 0x38 | Size: 0x8
	struct FTransform Effector; // Offset: 0x40 | Size: 0x30
	struct FVector PrimaryAxis; // Offset: 0x70 | Size: 0xc
	struct FVector SecondaryAxis; // Offset: 0x7c | Size: 0xc
	float SecondaryAxisWeight; // Offset: 0x88 | Size: 0x4
	struct FVector PoleVector; // Offset: 0x8c | Size: 0xc
	enum class EControlRigVectorKind PoleVectorKind; // Offset: 0x98 | Size: 0x1
	char pad_0x99[0x3]; // Offset: 0x99 | Size: 0x3
	struct FName PoleVectorSpace; // Offset: 0x9c | Size: 0x8
	bool bEnableStretch; // Offset: 0xa4 | Size: 0x1
	char pad_0xA5[0x3]; // Offset: 0xa5 | Size: 0x3
	float StretchStartRatio; // Offset: 0xa8 | Size: 0x4
	float StretchMaximumRatio; // Offset: 0xac | Size: 0x4
	float Weight; // Offset: 0xb0 | Size: 0x4
	float BoneALength; // Offset: 0xb4 | Size: 0x4
	float BoneBLength; // Offset: 0xb8 | Size: 0x4
	bool bPropagateToChildren; // Offset: 0xbc | Size: 0x1
	char pad_0xBD[0x3]; // Offset: 0xbd | Size: 0x3
	struct FRigUnit_TwoBoneIKSimple_DebugSettings DebugSettings; // Offset: 0xc0 | Size: 0x40
	int32_t BoneAIndex; // Offset: 0x100 | Size: 0x4
	int32_t BoneBIndex; // Offset: 0x104 | Size: 0x4
	int32_t EffectorBoneIndex; // Offset: 0x108 | Size: 0x4
	int32_t PoleVectorSpaceIndex; // Offset: 0x10c | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_TwoBoneIKSimple_DebugSettings
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FRigUnit_TwoBoneIKSimple_DebugSettings {
	// Fields
	bool bEnabled; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	float Scale; // Offset: 0x4 | Size: 0x4
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FTransform WorldOffset; // Offset: 0x10 | Size: 0x30
};

// Object: ScriptStruct ControlRig.RigUnit_Distance_VectorVector
// Inherited Bytes: 0x8 | Struct Size: 0x28
struct FRigUnit_Distance_VectorVector : FRigUnit {
	// Fields
	struct FVector Argument0; // Offset: 0x8 | Size: 0xc
	struct FVector Argument1; // Offset: 0x14 | Size: 0xc
	float Result; // Offset: 0x20 | Size: 0x4
	char pad_0x24[0x4]; // Offset: 0x24 | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_BinaryVectorOp
// Inherited Bytes: 0x8 | Struct Size: 0x30
struct FRigUnit_BinaryVectorOp : FRigUnit {
	// Fields
	struct FVector Argument0; // Offset: 0x8 | Size: 0xc
	struct FVector Argument1; // Offset: 0x14 | Size: 0xc
	struct FVector Result; // Offset: 0x20 | Size: 0xc
	char pad_0x2C[0x4]; // Offset: 0x2c | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_Divide_VectorVector
// Inherited Bytes: 0x30 | Struct Size: 0x30
struct FRigUnit_Divide_VectorVector : FRigUnit_BinaryVectorOp {
};

// Object: ScriptStruct ControlRig.RigUnit_Subtract_VectorVector
// Inherited Bytes: 0x30 | Struct Size: 0x30
struct FRigUnit_Subtract_VectorVector : FRigUnit_BinaryVectorOp {
};

// Object: ScriptStruct ControlRig.RigUnit_Add_VectorVector
// Inherited Bytes: 0x30 | Struct Size: 0x30
struct FRigUnit_Add_VectorVector : FRigUnit_BinaryVectorOp {
};

// Object: ScriptStruct ControlRig.RigUnit_Multiply_VectorVector
// Inherited Bytes: 0x30 | Struct Size: 0x30
struct FRigUnit_Multiply_VectorVector : FRigUnit_BinaryVectorOp {
};

// Object: ScriptStruct ControlRig.RigUnit_VerletIntegrateVector
// Inherited Bytes: 0x8 | Struct Size: 0x70
struct FRigUnit_VerletIntegrateVector : FRigUnit_SimBase {
	// Fields
	struct FVector Target; // Offset: 0x8 | Size: 0xc
	float Strength; // Offset: 0x14 | Size: 0x4
	float Damp; // Offset: 0x18 | Size: 0x4
	float Blend; // Offset: 0x1c | Size: 0x4
	struct FVector Position; // Offset: 0x20 | Size: 0xc
	struct FVector Velocity; // Offset: 0x2c | Size: 0xc
	struct FVector Acceleration; // Offset: 0x38 | Size: 0xc
	struct FCRSimPoint Point; // Offset: 0x44 | Size: 0x28
	char pad_0x6C[0x4]; // Offset: 0x6c | Size: 0x4
};

// Object: ScriptStruct ControlRig.RigUnit_VisualDebugTransform
// Inherited Bytes: 0x8 | Struct Size: 0x60
struct FRigUnit_VisualDebugTransform : FRigUnit_DebugBase {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FTransform Value; // Offset: 0x10 | Size: 0x30
	bool bEnabled; // Offset: 0x40 | Size: 0x1
	char pad_0x41[0x3]; // Offset: 0x41 | Size: 0x3
	float Thickness; // Offset: 0x44 | Size: 0x4
	float Scale; // Offset: 0x48 | Size: 0x4
	struct FName BoneSpace; // Offset: 0x4c | Size: 0x8
	char pad_0x54[0xc]; // Offset: 0x54 | Size: 0xc
};

// Object: ScriptStruct ControlRig.RigUnit_VisualDebugQuat
// Inherited Bytes: 0x8 | Struct Size: 0x40
struct FRigUnit_VisualDebugQuat : FRigUnit_DebugBase {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FQuat Value; // Offset: 0x10 | Size: 0x10
	bool bEnabled; // Offset: 0x20 | Size: 0x1
	char pad_0x21[0x3]; // Offset: 0x21 | Size: 0x3
	float Thickness; // Offset: 0x24 | Size: 0x4
	float Scale; // Offset: 0x28 | Size: 0x4
	struct FName BoneSpace; // Offset: 0x2c | Size: 0x8
	char pad_0x34[0xc]; // Offset: 0x34 | Size: 0xc
};

// Object: ScriptStruct ControlRig.RigUnit_VisualDebugVector
// Inherited Bytes: 0x8 | Struct Size: 0x38
struct FRigUnit_VisualDebugVector : FRigUnit_DebugBase {
	// Fields
	struct FVector Value; // Offset: 0x8 | Size: 0xc
	bool bEnabled; // Offset: 0x14 | Size: 0x1
	enum class ERigUnitVisualDebugPointMode Mode; // Offset: 0x15 | Size: 0x1
	char pad_0x16[0x2]; // Offset: 0x16 | Size: 0x2
	struct FLinearColor Color; // Offset: 0x18 | Size: 0x10
	float Thickness; // Offset: 0x28 | Size: 0x4
	float Scale; // Offset: 0x2c | Size: 0x4
	struct FName BoneSpace; // Offset: 0x30 | Size: 0x8
};

// Object: ScriptStruct ControlRig.StructReference
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FStructReference {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
};

