#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct DatasmithContent.DatasmithCameraLookatTrackingSettingsTemplate
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FDatasmithCameraLookatTrackingSettingsTemplate {
	// Fields
	char bEnableLookAtTracking : 1; // Offset: 0x0 | Size: 0x1
	char bAllowRoll : 1; // Offset: 0x0 | Size: 0x1
	char pad_0x0_2 : 6; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x7]; // Offset: 0x1 | Size: 0x7
	struct TSoftObjectPtr<AActor> ActorToTrack; // Offset: 0x8 | Size: 0x28
};

// Object: ScriptStruct DatasmithContent.DatasmithPostProcessSettingsTemplate
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FDatasmithPostProcessSettingsTemplate {
	// Fields
	char bOverride_WhiteTemp : 1; // Offset: 0x0 | Size: 0x1
	char bOverride_ColorSaturation : 1; // Offset: 0x0 | Size: 0x1
	char bOverride_VignetteIntensity : 1; // Offset: 0x0 | Size: 0x1
	char bOverride_FilmWhitePoint : 1; // Offset: 0x0 | Size: 0x1
	char bOverride_AutoExposureMethod : 1; // Offset: 0x0 | Size: 0x1
	char bOverride_CameraISO : 1; // Offset: 0x0 | Size: 0x1
	char bOverride_CameraShutterSpeed : 1; // Offset: 0x0 | Size: 0x1
	char bOverride_DepthOfFieldFstop : 1; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	float WhiteTemp; // Offset: 0x4 | Size: 0x4
	float VignetteIntensity; // Offset: 0x8 | Size: 0x4
	struct FLinearColor FilmWhitePoint; // Offset: 0xc | Size: 0x10
	char pad_0x1C[0x4]; // Offset: 0x1c | Size: 0x4
	struct FVector4 ColorSaturation; // Offset: 0x20 | Size: 0x10
	enum class EAutoExposureMethod AutoExposureMethod; // Offset: 0x30 | Size: 0x1
	char pad_0x31[0x3]; // Offset: 0x31 | Size: 0x3
	float CameraISO; // Offset: 0x34 | Size: 0x4
	float CameraShutterSpeed; // Offset: 0x38 | Size: 0x4
	float DepthOfFieldFstop; // Offset: 0x3c | Size: 0x4
};

// Object: ScriptStruct DatasmithContent.DatasmithCameraFocusSettingsTemplate
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FDatasmithCameraFocusSettingsTemplate {
	// Fields
	enum class ECameraFocusMethod FocusMethod; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	float ManualFocusDistance; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct DatasmithContent.DatasmithCameraLensSettingsTemplate
// Inherited Bytes: 0x0 | Struct Size: 0x4
struct FDatasmithCameraLensSettingsTemplate {
	// Fields
	float MaxFStop; // Offset: 0x0 | Size: 0x4
};

// Object: ScriptStruct DatasmithContent.DatasmithCameraFilmbackSettingsTemplate
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FDatasmithCameraFilmbackSettingsTemplate {
	// Fields
	float SensorWidth; // Offset: 0x0 | Size: 0x4
	float SensorHeight; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct DatasmithContent.DatasmithTessellationOptions
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FDatasmithTessellationOptions {
	// Fields
	float ChordTolerance; // Offset: 0x0 | Size: 0x4
	float MaxEdgeLength; // Offset: 0x4 | Size: 0x4
	float NormalTolerance; // Offset: 0x8 | Size: 0x4
	enum class EDatasmithCADStitchingTechnique StitchingTechnique; // Offset: 0xc | Size: 0x1
	char pad_0xD[0x3]; // Offset: 0xd | Size: 0x3
};

// Object: ScriptStruct DatasmithContent.DatasmithImportBaseOptions
// Inherited Bytes: 0x0 | Struct Size: 0x14
struct FDatasmithImportBaseOptions {
	// Fields
	enum class EDatasmithImportScene SceneHandling; // Offset: 0x0 | Size: 0x1
	bool bIncludeGeometry; // Offset: 0x1 | Size: 0x1
	bool bIncludeMaterial; // Offset: 0x2 | Size: 0x1
	bool bIncludeLight; // Offset: 0x3 | Size: 0x1
	bool bIncludeCamera; // Offset: 0x4 | Size: 0x1
	bool bIncludeAnimation; // Offset: 0x5 | Size: 0x1
	char pad_0x6[0x2]; // Offset: 0x6 | Size: 0x2
	struct FDatasmithAssetImportOptions AssetOptions; // Offset: 0x8 | Size: 0x8
	struct FDatasmithStaticMeshImportOptions StaticMeshOptions; // Offset: 0x10 | Size: 0x4
};

// Object: ScriptStruct DatasmithContent.DatasmithStaticMeshImportOptions
// Inherited Bytes: 0x0 | Struct Size: 0x4
struct FDatasmithStaticMeshImportOptions {
	// Fields
	enum class EDatasmithImportLightmapMin MinLightmapResolution; // Offset: 0x0 | Size: 0x1
	enum class EDatasmithImportLightmapMax MaxLightmapResolution; // Offset: 0x1 | Size: 0x1
	bool bGenerateLightmapUVs; // Offset: 0x2 | Size: 0x1
	bool bRemoveDegenerates; // Offset: 0x3 | Size: 0x1
};

// Object: ScriptStruct DatasmithContent.DatasmithAssetImportOptions
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FDatasmithAssetImportOptions {
	// Fields
	struct FName PackagePath; // Offset: 0x0 | Size: 0x8
};

// Object: ScriptStruct DatasmithContent.DatasmithReimportOptions
// Inherited Bytes: 0x0 | Struct Size: 0x2
struct FDatasmithReimportOptions {
	// Fields
	bool bUpdateActors; // Offset: 0x0 | Size: 0x1
	bool bRespawnDeletedActors; // Offset: 0x1 | Size: 0x1
};

// Object: ScriptStruct DatasmithContent.DatasmithStaticParameterSetTemplate
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FDatasmithStaticParameterSetTemplate {
	// Fields
	struct TMap<struct FName, bool> StaticSwitchParameters; // Offset: 0x0 | Size: 0x50
};

// Object: ScriptStruct DatasmithContent.DatasmithMeshSectionInfoMapTemplate
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FDatasmithMeshSectionInfoMapTemplate {
	// Fields
	struct TMap<uint32_t, struct FDatasmithMeshSectionInfoTemplate> Map; // Offset: 0x0 | Size: 0x50
};

// Object: ScriptStruct DatasmithContent.DatasmithMeshSectionInfoTemplate
// Inherited Bytes: 0x0 | Struct Size: 0x4
struct FDatasmithMeshSectionInfoTemplate {
	// Fields
	int32_t MaterialIndex; // Offset: 0x0 | Size: 0x4
};

// Object: ScriptStruct DatasmithContent.DatasmithStaticMaterialTemplate
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FDatasmithStaticMaterialTemplate {
	// Fields
	struct FName MaterialSlotName; // Offset: 0x0 | Size: 0x8
	struct UMaterialInterface* MaterialInterface; // Offset: 0x8 | Size: 0x8
};

// Object: ScriptStruct DatasmithContent.DatasmithMeshBuildSettingsTemplate
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FDatasmithMeshBuildSettingsTemplate {
	// Fields
	char bUseMikkTSpace : 1; // Offset: 0x0 | Size: 0x1
	char bRecomputeNormals : 1; // Offset: 0x0 | Size: 0x1
	char bRecomputeTangents : 1; // Offset: 0x0 | Size: 0x1
	char bRemoveDegenerates : 1; // Offset: 0x0 | Size: 0x1
	char bBuildAdjacencyBuffer : 1; // Offset: 0x0 | Size: 0x1
	char bUseHighPrecisionTangentBasis : 1; // Offset: 0x0 | Size: 0x1
	char bUseFullPrecisionUVs : 1; // Offset: 0x0 | Size: 0x1
	char bGenerateLightmapUVs : 1; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	int32_t MinLightmapResolution; // Offset: 0x4 | Size: 0x4
	int32_t SrcLightmapIndex; // Offset: 0x8 | Size: 0x4
	int32_t DstLightmapIndex; // Offset: 0xc | Size: 0x4
};

