#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass DefaultSolarGameModeLockSettings.DefaultSolarGameModeLockSettings_C
// Inherited Bytes: 0x98 | Struct Size: 0x98
struct UDefaultSolarGameModeLockSettings_C : USolarGameModeLockSettings {
};

