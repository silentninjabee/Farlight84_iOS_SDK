#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class DownloaderTool.DownloaderHttpTask
// Inherited Bytes: 0x28 | Struct Size: 0x2b8
struct UDownloaderHttpTask : UObject {
	// Fields
	struct FMulticastInlineDelegate OnTaskProgress; // Offset: 0x28 | Size: 0x10
	struct FMulticastInlineDelegate OnTaskSuccess; // Offset: 0x38 | Size: 0x10
	struct FMulticastInlineDelegate OnTaskFailed; // Offset: 0x48 | Size: 0x10
	struct FMulticastInlineDelegate OnTaskCDNFailed; // Offset: 0x58 | Size: 0x10
	struct TWeakObjectPtr<struct UDownloaderManager> Manager; // Offset: 0x68 | Size: 0x8
	char pad_0x70[0x1e8]; // Offset: 0x70 | Size: 0x1e8
	struct FDownloaderResponse DownloadResponse; // Offset: 0x258 | Size: 0x60

	// Functions

	// Object: Function DownloaderTool.DownloaderHttpTask.SetWriteFilePath
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102f4fca4
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetWriteFilePath(struct FString InWriteFilePath);

	// Object: Function DownloaderTool.DownloaderHttpTask.OnWriteFileComplete
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x1011ffe78
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnWriteFileComplete(bool bWriteResult);

	// Object: Function DownloaderTool.DownloaderHttpTask.CreateAndProcessHttpRequest
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1011fff00
	// Return & Params: [ Num(0) Size(0x0) ]
	void CreateAndProcessHttpRequest();
};

// Object: Class DownloaderTool.DownloaderMainTask
// Inherited Bytes: 0x28 | Struct Size: 0x1a8
struct UDownloaderMainTask : UObject {
	// Fields
	struct FMulticastInlineDelegate OnMainTaskProgress; // Offset: 0x28 | Size: 0x10
	struct FMulticastInlineDelegate OnMainTaskSuccess; // Offset: 0x38 | Size: 0x10
	struct FMulticastInlineDelegate OnMainTaskFailed; // Offset: 0x48 | Size: 0x10
	struct FMulticastInlineDelegate OnTaskCDNFailed; // Offset: 0x58 | Size: 0x10
	struct TWeakObjectPtr<struct UDownloaderManager> Manager; // Offset: 0x68 | Size: 0x8
	struct TArray<struct FDownloaderResponse> AllUrlTasksResponses; // Offset: 0x70 | Size: 0x10
	struct TArray<struct UDownloaderSubTask*> PausingSubTasks; // Offset: 0x80 | Size: 0x10
	struct TMap<struct FName, struct UDownloaderUrlTask*> AllUrlTasksMap; // Offset: 0x90 | Size: 0x50
	struct TMap<struct FString, struct FDownloaderProgressInfo> AllUrlTasksProgressInfoMap; // Offset: 0xe0 | Size: 0x50
	char pad_0x130[0x78]; // Offset: 0x130 | Size: 0x78

	// Functions

	// Object: Function DownloaderTool.DownloaderMainTask.SetTaskReadyLaunch
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102f4fe5c
	// Return & Params: [ Num(0) Size(0x0) ]
	void SetTaskReadyLaunch();

	// Object: Function DownloaderTool.DownloaderMainTask.OnUrlTaskSuccess
	// Flags: [Final|Native|Protected|HasOutParms]
	// Offset: 0x1012002e4
	// Return & Params: [ Num(1) Size(0x60) ]
	void OnUrlTaskSuccess(struct FDownloaderResponse& InResponse);

	// Object: Function DownloaderTool.DownloaderMainTask.OnUrlTaskProgress
	// Flags: [Final|Native|Protected|HasOutParms]
	// Offset: 0x101200240
	// Return & Params: [ Num(1) Size(0x28) ]
	void OnUrlTaskProgress(struct FDownloaderProgressInfo& InProgressInfo);

	// Object: Function DownloaderTool.DownloaderMainTask.OnUrlTaskFailed
	// Flags: [Final|Native|Protected|HasOutParms]
	// Offset: 0x102f4fde4
	// Return & Params: [ Num(1) Size(0x18) ]
	void OnUrlTaskFailed(struct FDownloaderFailedInfo& InFailedInfo);

	// Object: Function DownloaderTool.DownloaderMainTask.OnUrlTaskCDNFailed
	// Flags: [Final|Native|Protected|HasOutParms]
	// Offset: 0x10120018c
	// Return & Params: [ Num(1) Size(0x30) ]
	void OnUrlTaskCDNFailed(struct FDownloaderCDNFailedInfo& InCDNFailedInfo);
};

// Object: Class DownloaderTool.DownloaderManagerLuaImpl
// Inherited Bytes: 0x28 | Struct Size: 0x30
struct UDownloaderManagerLuaImpl : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8

	// Functions

	// Object: Function DownloaderTool.DownloaderManagerLuaImpl.UnInitDownloaderMgrLuaInternal
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10113cfa4
	// Return & Params: [ Num(0) Size(0x0) ]
	void UnInitDownloaderMgrLuaInternal();

	// Object: Function DownloaderTool.DownloaderManagerLuaImpl.InitDownloaderMgrLuaInternal
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10113cfa4
	// Return & Params: [ Num(1) Size(0x1) ]
	bool InitDownloaderMgrLuaInternal();
};

// Object: Class DownloaderTool.DownloaderManager
// Inherited Bytes: 0x30 | Struct Size: 0x1d0
struct UDownloaderManager : UGameInstanceSubsystem {
	// Fields
	char pad_0x30[0x10]; // Offset: 0x30 | Size: 0x10
	struct UDownloaderManagerLuaImpl* LuaImpl; // Offset: 0x40 | Size: 0x8
	bool bIsDownloaderEnabled; // Offset: 0x48 | Size: 0x1
	bool bSystemSupportFileCache; // Offset: 0x49 | Size: 0x1
	char pad_0x4A[0x2]; // Offset: 0x4a | Size: 0x2
	int32_t CacheExpiredSeconds; // Offset: 0x4c | Size: 0x4
	int32_t CacheClearMaxSpacePercent; // Offset: 0x50 | Size: 0x4
	float TimeOutSeconds; // Offset: 0x54 | Size: 0x4
	float UrlTaskCallbackTimeOutSeconds; // Offset: 0x58 | Size: 0x4
	int32_t SubTaskChunkSize; // Offset: 0x5c | Size: 0x4
	int32_t CurDownloadingSubTaskNum; // Offset: 0x60 | Size: 0x4
	int32_t MaxDownloadingSubTaskNum; // Offset: 0x64 | Size: 0x4
	struct FString DefaultLaunchCacheDir; // Offset: 0x68 | Size: 0x10
	struct FString DefaultPictureCacheDir; // Offset: 0x78 | Size: 0x10
	struct TMap<struct FName, struct UDownloaderMainTask*> MainTasksMap; // Offset: 0x88 | Size: 0x50
	struct TMap<struct FString, struct UDownloaderHttpTask*> LightWeightHttpTasksMap; // Offset: 0xd8 | Size: 0x50
	struct TMap<struct FString, struct FString> UrlEncodedStrMap; // Offset: 0x128 | Size: 0x50
	struct TArray<struct UDownloaderSubTask*> SubTasksQueue; // Offset: 0x178 | Size: 0x10
	bool bInitLuaComplete; // Offset: 0x188 | Size: 0x1
	char pad_0x189[0x47]; // Offset: 0x189 | Size: 0x47

	// Functions

	// Object: Function DownloaderTool.DownloaderManager.TyrLaunchSubTasksQueue
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102f501bc
	// Return & Params: [ Num(0) Size(0x0) ]
	void TyrLaunchSubTasksQueue();

	// Object: Function DownloaderTool.DownloaderManager.StopMainTask
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102f501cc
	// Return & Params: [ Num(1) Size(0x8) ]
	void StopMainTask(struct FName& InMainTaskName);

	// Object: Function DownloaderTool.DownloaderManager.StopAllMainTasks
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102f5034c
	// Return & Params: [ Num(0) Size(0x0) ]
	void StopAllMainTasks();

	// Object: Function DownloaderTool.DownloaderManager.SetUrlTaskCallbackTimeOutSeconds
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102f50b68
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetUrlTaskCallbackTimeOutSeconds(float InTimeOutSeconds);

	// Object: Function DownloaderTool.DownloaderManager.SetTimeOutSeconds
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102f50bd8
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetTimeOutSeconds(float InTimeOutSeconds);

	// Object: Function DownloaderTool.DownloaderManager.SetSubTaskChunkSize
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102f50a18
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetSubTaskChunkSize(int32_t InSubTaskChunkSize);

	// Object: Function DownloaderTool.DownloaderManager.SetMaxDownloadingSubTaskNum
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102f509a8
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetMaxDownloadingSubTaskNum(int32_t InMaxDownloadingSubTaskNum);

	// Object: Function DownloaderTool.DownloaderManager.SetManagerEnable
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102f50c68
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetManagerEnable(bool bInEnable);

	// Object: Function DownloaderTool.DownloaderManager.SetCacheExpiredSeconds
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102f50af8
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetCacheExpiredSeconds(int32_t InCacheExpiredSeconds);

	// Object: Function DownloaderTool.DownloaderManager.SetCacheClearMaxSpacePercent
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102f50a88
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetCacheClearMaxSpacePercent(int32_t InCacheClearMaxSpacePercent);

	// Object: Function DownloaderTool.DownloaderManager.ResumeMainTask
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102f5028c
	// Return & Params: [ Num(1) Size(0x8) ]
	void ResumeMainTask(struct FName& InMainTaskName);

	// Object: Function DownloaderTool.DownloaderManager.ReadyMainTaskFinish
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102f502ec
	// Return & Params: [ Num(1) Size(0x8) ]
	void ReadyMainTaskFinish(struct FName& InMainTaskName);

	// Object: Function DownloaderTool.DownloaderManager.PushBatchSubTasksToQueue
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102f50118
	// Return & Params: [ Num(2) Size(0x11) ]
	void PushBatchSubTasksToQueue(struct TArray<struct UDownloaderSubTask*>& InSubTasks, bool bInCutQueue);

	// Object: Function DownloaderTool.DownloaderManager.PauseMainTask
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102f5022c
	// Return & Params: [ Num(1) Size(0x8) ]
	void PauseMainTask(struct FName& InMainTaskName);

	// Object: Function DownloaderTool.DownloaderManager.IsSystemSupportFileCache
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102f50c48
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsSystemSupportFileCache();

	// Object: Function DownloaderTool.DownloaderManager.IsManagerEnable
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102f50cd0
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsManagerEnable();

	// Object: Function DownloaderTool.DownloaderManager.IsMainTaskExist
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102f50880
	// Return & Params: [ Num(2) Size(0x9) ]
	bool IsMainTaskExist(struct FName& InMainTaskName);

	// Object: Function DownloaderTool.DownloaderManager.Init
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102f50e68
	// Return & Params: [ Num(0) Size(0x0) ]
	void Init();

	// Object: Function DownloaderTool.DownloaderManager.GetUrlTaskRecordFilePath
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102f50528
	// Return & Params: [ Num(2) Size(0xc8) ]
	struct FString GetUrlTaskRecordFilePath(struct FDownloaderTaskInfo& InTaskInfo);

	// Object: Function DownloaderTool.DownloaderManager.GetUrlTaskCallbackTimeOutSeconds
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102f50bb8
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetUrlTaskCallbackTimeOutSeconds();

	// Object: Function DownloaderTool.DownloaderManager.GetUrlTaskCacheDirPath
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102f505bc
	// Return & Params: [ Num(2) Size(0xc8) ]
	struct FString GetUrlTaskCacheDirPath(struct FDownloaderTaskInfo& InTaskInfo);

	// Object: Function DownloaderTool.DownloaderManager.GetUrlsCachedSize
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102f50650
	// Return & Params: [ Num(2) Size(0x14) ]
	int32_t GetUrlsCachedSize(struct TArray<struct FDownloaderTaskInfo>& InAllTaskInfos);

	// Object: Function DownloaderTool.DownloaderManager.GetUrlEncodedStr
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102f50494
	// Return & Params: [ Num(2) Size(0xc8) ]
	struct FString GetUrlEncodedStr(struct FDownloaderTaskInfo& InTaskInfo);

	// Object: Function DownloaderTool.DownloaderManager.GetTimeOutSeconds
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102f50c28
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetTimeOutSeconds();

	// Object: Function DownloaderTool.DownloaderManager.GetSubTaskChunkSize
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102f50a68
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetSubTaskChunkSize();

	// Object: Function DownloaderTool.DownloaderManager.GetMaxDownloadingSubTaskNum
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102f509f8
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetMaxDownloadingSubTaskNum();

	// Object: Function DownloaderTool.DownloaderManager.GetMainTaskStatus
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102f506d8
	// Return & Params: [ Num(2) Size(0x9) ]
	enum class EDownloaderStatus GetMainTaskStatus(struct FName& InMainTaskName);

	// Object: Function DownloaderTool.DownloaderManager.GetMainTasksMap
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102f50960
	// Return & Params: [ Num(1) Size(0x50) ]
	struct TMap<struct FName, struct UDownloaderMainTask*> GetMainTasksMap();

	// Object: Function DownloaderTool.DownloaderManager.GetMainTaskName
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102f508e0
	// Return & Params: [ Num(2) Size(0x18) ]
	struct FName GetMainTaskName(struct TArray<struct FDownloaderTaskInfo>& InAllTaskInfos);

	// Object: Function DownloaderTool.DownloaderManager.GetMainTaskByName
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102f507a0
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UDownloaderMainTask* GetMainTaskByName(struct FName& InMainTaskName);

	// Object: Function DownloaderTool.DownloaderManager.GetlightWeightHttpTaskByURL
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102f50738
	// Return & Params: [ Num(2) Size(0x18) ]
	struct UDownloaderHttpTask* GetlightWeightHttpTaskByURL(struct FString InNecessaryURL);

	// Object: Function DownloaderTool.DownloaderManager.GetDefaultPictureCacheDir
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102f5037c
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetDefaultPictureCacheDir();

	// Object: Function DownloaderTool.DownloaderManager.GetDefaultLaunchCacheDir
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102f50408
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetDefaultLaunchCacheDir();

	// Object: Function DownloaderTool.DownloaderManager.GetCacheExpiredSeconds
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102f50b48
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetCacheExpiredSeconds();

	// Object: Function DownloaderTool.DownloaderManager.GetCacheClearMaxSpacePercent
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102f50ad8
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetCacheClearMaxSpacePercent();

	// Object: Function DownloaderTool.DownloaderManager.Get
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102f50e78
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UDownloaderManager* Get(struct UObject* WorldContextObject);

	// Object: Function DownloaderTool.DownloaderManager.DeleteDefaultPictureCacheDir
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102f5035c
	// Return & Params: [ Num(1) Size(0x1) ]
	bool DeleteDefaultPictureCacheDir();

	// Object: Function DownloaderTool.DownloaderManager.DeleteDefaultLaunchCacheDir
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102f503e8
	// Return & Params: [ Num(1) Size(0x1) ]
	bool DeleteDefaultLaunchCacheDir();

	// Object: Function DownloaderTool.DownloaderManager.DeleteAllDefaultCacheDir
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102f50474
	// Return & Params: [ Num(1) Size(0x1) ]
	bool DeleteAllDefaultCacheDir();

	// Object: Function DownloaderTool.DownloaderManager.CurDownSubTasksNumSubOne
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102f50108
	// Return & Params: [ Num(0) Size(0x0) ]
	void CurDownSubTasksNumSubOne();

	// Object: Function DownloaderTool.DownloaderManager.CreateLightWeightTask
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1012006dc
	// Return & Params: [ Num(2) Size(0xc0) ]
	struct UDownloaderHttpTask* CreateLightWeightTask(struct FDownloaderTaskInfo& InTaskInfo);

	// Object: Function DownloaderTool.DownloaderManager.CreateJsonReqTask
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102f50cf0
	// Return & Params: [ Num(3) Size(0xd0) ]
	struct UDownloaderHttpTask* CreateJsonReqTask(struct FString InNecessaryURL, struct FDownloaderReqJson& InReqJson);

	// Object: Function DownloaderTool.DownloaderManager.CreateBigFilesDownloadTask
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102f50de0
	// Return & Params: [ Num(2) Size(0x18) ]
	struct UDownloaderMainTask* CreateBigFilesDownloadTask(struct TArray<struct FDownloaderTaskInfo>& InAllTaskInfos);

	// Object: Function DownloaderTool.DownloaderManager.ClearCompletedMainTask
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102f500e8
	// Return & Params: [ Num(0) Size(0x0) ]
	void ClearCompletedMainTask();

	// Object: Function DownloaderTool.DownloaderManager.ClearCompletedLightWeightHttpTask
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102f500d8
	// Return & Params: [ Num(0) Size(0x0) ]
	void ClearCompletedLightWeightHttpTask();

	// Object: Function DownloaderTool.DownloaderManager.ClearCache
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102f500f8
	// Return & Params: [ Num(0) Size(0x0) ]
	void ClearCache();

	// Object: Function DownloaderTool.DownloaderManager.Clear
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102f500c8
	// Return & Params: [ Num(0) Size(0x0) ]
	void Clear();

	// Object: Function DownloaderTool.DownloaderManager.CheckTaskInfosValid
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102f50800
	// Return & Params: [ Num(2) Size(0x11) ]
	bool CheckTaskInfosValid(struct TArray<struct FDownloaderTaskInfo>& InAllTaskInfos);
};

// Object: Class DownloaderTool.DownloaderSubTask
// Inherited Bytes: 0x28 | Struct Size: 0x180
struct UDownloaderSubTask : UObject {
	// Fields
	struct FDelegate OnSubTaskProgress; // Offset: 0x28 | Size: 0x10
	struct FDelegate OnSubTaskSuccess; // Offset: 0x38 | Size: 0x10
	struct FDelegate OnSubTaskFailed; // Offset: 0x48 | Size: 0x10
	struct FMulticastInlineDelegate OnTaskCDNFailed; // Offset: 0x58 | Size: 0x10
	struct TWeakObjectPtr<struct UDownloaderManager> Manager; // Offset: 0x68 | Size: 0x8
	struct UDownloaderHttpTask* RealHttpTask; // Offset: 0x70 | Size: 0x8
	char pad_0x78[0x108]; // Offset: 0x78 | Size: 0x108

	// Functions

	// Object: Function DownloaderTool.DownloaderSubTask.OnRealHttpTaskSuccess
	// Flags: [Final|Native|Protected|HasOutParms]
	// Offset: 0x101200a74
	// Return & Params: [ Num(1) Size(0x60) ]
	void OnRealHttpTaskSuccess(struct FDownloaderResponse& InResponse);

	// Object: Function DownloaderTool.DownloaderSubTask.OnRealHttpTaskProgress
	// Flags: [Final|Native|Protected]
	// Offset: 0x1012009b8
	// Return & Params: [ Num(2) Size(0x8) ]
	void OnRealHttpTaskProgress(int32_t InBytesSent, int32_t InBytesReceived);

	// Object: Function DownloaderTool.DownloaderSubTask.OnRealHttpTaskFailed
	// Flags: [Final|Native|Protected|HasOutParms]
	// Offset: 0x102f519c4
	// Return & Params: [ Num(2) Size(0x8) ]
	void OnRealHttpTaskFailed(enum class EDTFailedType& InFailedType, int32_t InErrorCode);

	// Object: Function DownloaderTool.DownloaderSubTask.OnRealHttpTaskCDNFailed
	// Flags: [Final|Native|Protected|HasOutParms]
	// Offset: 0x101200904
	// Return & Params: [ Num(1) Size(0x30) ]
	void OnRealHttpTaskCDNFailed(struct FDownloaderCDNFailedInfo& InCDNFailedInfo);
};

// Object: Class DownloaderTool.DownloaderUrlTask
// Inherited Bytes: 0x28 | Struct Size: 0x2b8
struct UDownloaderUrlTask : UObject {
	// Fields
	struct FDelegate OnUrlTaskProgress; // Offset: 0x28 | Size: 0x10
	struct FDelegate OnUrlTaskSuccess; // Offset: 0x38 | Size: 0x10
	struct FDelegate OnUrlTaskFailed; // Offset: 0x48 | Size: 0x10
	struct FMulticastInlineDelegate OnTaskCDNFailed; // Offset: 0x58 | Size: 0x10
	struct TWeakObjectPtr<struct UDownloaderManager> Manager; // Offset: 0x68 | Size: 0x8
	struct TMap<struct FName, struct UDownloaderSubTask*> AllSubTasksMap; // Offset: 0x70 | Size: 0x50
	char pad_0xC0[0x1f8]; // Offset: 0xc0 | Size: 0x1f8

	// Functions

	// Object: Function DownloaderTool.DownloaderUrlTask.OnSubTaskSuccess
	// Flags: [Final|Native|Protected|HasOutParms]
	// Offset: 0x101201058
	// Return & Params: [ Num(1) Size(0x60) ]
	void OnSubTaskSuccess(struct FDownloaderResponse& InResponse);

	// Object: Function DownloaderTool.DownloaderUrlTask.OnSubTaskProgress
	// Flags: [Final|Native|Protected]
	// Offset: 0x101200f9c
	// Return & Params: [ Num(2) Size(0x8) ]
	void OnSubTaskProgress(int32_t InCurBytesSent, int32_t InCurBytesReceived);

	// Object: Function DownloaderTool.DownloaderUrlTask.OnSubTaskFailed
	// Flags: [Final|Native|Protected|HasOutParms]
	// Offset: 0x102f52264
	// Return & Params: [ Num(2) Size(0x8) ]
	void OnSubTaskFailed(enum class EDTFailedType& InFailedType, int32_t InErrorCode);

	// Object: Function DownloaderTool.DownloaderUrlTask.OnSubTaskCDNFailed
	// Flags: [Final|Native|Protected|HasOutParms]
	// Offset: 0x101200ee8
	// Return & Params: [ Num(1) Size(0x30) ]
	void OnSubTaskCDNFailed(struct FDownloaderCDNFailedInfo& InCDNFailedInfo);

	// Object: Function DownloaderTool.DownloaderUrlTask.OnMergeFileComplete
	// Flags: [Final|Native|Protected]
	// Offset: 0x101200e60
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnMergeFileComplete(bool bMergeResult);

	// Object: Function DownloaderTool.DownloaderUrlTask.OnHashCheckFileComplete
	// Flags: [Final|Native|Protected]
	// Offset: 0x101200dd8
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnHashCheckFileComplete(bool bHashCheckResult);

	// Object: Function DownloaderTool.DownloaderUrlTask.OnCallbackTimeOutFailed
	// Flags: [Final|Native|Protected]
	// Offset: 0x102f52254
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnCallbackTimeOutFailed();
};

// Object: Class DownloaderTool.DownloaderUtils
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UDownloaderUtils : UObject {
	// Functions

	// Object: Function DownloaderTool.DownloaderUtils.TryUpdateUrlTaskRecordFile
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102f52b10
	// Return & Params: [ Num(3) Size(0x21) ]
	bool TryUpdateUrlTaskRecordFile(struct FString InUrlTaskRecordFilePath, struct FUrlTaskRecordInfo& InUrlTaskRecordInfo);

	// Object: Function DownloaderTool.DownloaderUtils.TrySaveResponseToCache
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102f529c4
	// Return & Params: [ Num(3) Size(0x71) ]
	bool TrySaveResponseToCache(struct FDownloaderResponse& InResponse, struct FString InCachePath);

	// Object: Function DownloaderTool.DownloaderUtils.TryGetUrlTaskRecordFromFile
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102f52a84
	// Return & Params: [ Num(3) Size(0x21) ]
	bool TryGetUrlTaskRecordFromFile(struct FString InUrlTaskRecordFilePath, struct FUrlTaskRecordInfo& OutUrlTaskRecordInfo);

	// Object: Function DownloaderTool.DownloaderUtils.TryGetResponseFromCache
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102f5286c
	// Return & Params: [ Num(4) Size(0x129) ]
	bool TryGetResponseFromCache(struct FDownloaderTaskInfo& InTaskInfo, struct FString InCachePath, struct FDownloaderResponse& OutResponse);

	// Object: Function DownloaderTool.DownloaderUtils.TryGetJsonStrFromDownloaderReqJson
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102f52d7c
	// Return & Params: [ Num(3) Size(0xc9) ]
	bool TryGetJsonStrFromDownloaderReqJson(struct FDownloaderReqJson& InReqJson, struct FString& OutReqStr);

	// Object: Function DownloaderTool.DownloaderUtils.TryDeleteOldFileAndCreateDir
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102f52804
	// Return & Params: [ Num(2) Size(0x11) ]
	bool TryDeleteOldFileAndCreateDir(struct FString InFileFullPath);

	// Object: Function DownloaderTool.DownloaderUtils.StringFileRawData
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102f52f04
	// Return & Params: [ Num(2) Size(0x70) ]
	struct FString StringFileRawData(struct FDownloaderResponse& InResponse);

	// Object: Function DownloaderTool.DownloaderUtils.HashStringWithSHA1
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102f53044
	// Return & Params: [ Num(2) Size(0x20) ]
	struct FString HashStringWithSHA1(struct FString inString);

	// Object: Function DownloaderTool.DownloaderUtils.GetVerbFromJsonRequestStr
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102f52d04
	// Return & Params: [ Num(2) Size(0x20) ]
	struct FString GetVerbFromJsonRequestStr(struct FString JsonRequestStr);

	// Object: Function DownloaderTool.DownloaderUtils.GetTaskInfoLogStr
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102f526ec
	// Return & Params: [ Num(2) Size(0xc8) ]
	struct FString GetTaskInfoLogStr(struct FDownloaderTaskInfo& InTaskInfo);

	// Object: Function DownloaderTool.DownloaderUtils.GetQueriesFromJsonRequestStr
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102f52c14
	// Return & Params: [ Num(2) Size(0x60) ]
	struct TMap<struct FString, struct FString> GetQueriesFromJsonRequestStr(struct FString JsonRequestStr);

	// Object: Function DownloaderTool.DownloaderUtils.GetHttpMethodTypeStr
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102f52768
	// Return & Params: [ Num(2) Size(0x18) ]
	struct FString GetHttpMethodTypeStr(enum class EDownloaderHttpMethod& InHttpMethod);

	// Object: Function DownloaderTool.DownloaderUtils.GetHeadersFromJsonRequestStr
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102f52c8c
	// Return & Params: [ Num(2) Size(0x60) ]
	struct TMap<struct FString, struct FString> GetHeadersFromJsonRequestStr(struct FString JsonRequestStr);

	// Object: Function DownloaderTool.DownloaderUtils.GetFailedTypeStr
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1012011b8
	// Return & Params: [ Num(2) Size(0x18) ]
	struct FString GetFailedTypeStr(enum class EDTFailedType& InFailedType);

	// Object: Function DownloaderTool.DownloaderUtils.GetBodyFromJsonRequestStr
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102f52b9c
	// Return & Params: [ Num(2) Size(0x20) ]
	struct FString GetBodyFromJsonRequestStr(struct FString JsonRequestStr);

	// Object: Function DownloaderTool.DownloaderUtils.GetAllTaskNameLogStr
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102f525b8
	// Return & Params: [ Num(5) Size(0x50) ]
	struct FString GetAllTaskNameLogStr(struct FString InMainTaskName, struct FString InUrlTaskName, struct FString InSubTaskName, struct FString InHttpTaskName);

	// Object: Function DownloaderTool.DownloaderUtils.ExtractFileNameAndExtensionFromFileFullName
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102f524b8
	// Return & Params: [ Num(3) Size(0x30) ]
	void ExtractFileNameAndExtensionFromFileFullName(struct FString InFileFullName, struct FString& OutFileName, struct FString& OutFileExtension);

	// Object: Function DownloaderTool.DownloaderUtils.execConvertRawDataToTexture
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102f52f98
	// Return & Params: [ Num(3) Size(0x20) ]
	struct UTexture2DDynamic* execConvertRawDataToTexture(struct TArray<char>& Data, int32_t DataLength);

	// Object: Function DownloaderTool.DownloaderUtils.DecodeFileRawData
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102f52e70
	// Return & Params: [ Num(2) Size(0x70) ]
	struct FString DecodeFileRawData(struct FDownloaderResponse& InResponse);
};

