#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class DynamicAtlas.DynamicAtlas
// Inherited Bytes: 0x28 | Struct Size: 0xd0
struct UDynamicAtlas : UObject {
	// Fields
	char pad_0x28[0xa8]; // Offset: 0x28 | Size: 0xa8

	// Functions

	// Object: Function DynamicAtlas.DynamicAtlas.OnCanvasRenderTargetUpdate
	// Flags: [Final|Native|Private]
	// Offset: 0x10121c390
	// Return & Params: [ Num(3) Size(0x10) ]
	void OnCanvasRenderTargetUpdate(struct UCanvas* InCanvas, int32_t InWidth, int32_t InHeight);
};

// Object: Class DynamicAtlas.DynamicAtlasLoader
// Inherited Bytes: 0x28 | Struct Size: 0x50
struct UDynamicAtlasLoader : UObject {
	// Fields
	char pad_0x28[0x28]; // Offset: 0x28 | Size: 0x28
};

// Object: Class DynamicAtlas.DynamicAtlasSettings
// Inherited Bytes: 0x38 | Struct Size: 0x78
struct UDynamicAtlasSettings : UDeveloperSettings {
	// Fields
	bool bEnableDynamicAtlas; // Offset: 0x38 | Size: 0x1
	bool bEnableRuntimeDynamicAtlas; // Offset: 0x39 | Size: 0x1
	bool bClearWhenRemove; // Offset: 0x3a | Size: 0x1
	char pad_0x3B[0x5]; // Offset: 0x3b | Size: 0x5
	struct TArray<struct TSoftObjectPtr<UCanvasRenderTarget2D>> DynamicAtlasSoftTemplateRenderTargets; // Offset: 0x40 | Size: 0x10
	struct TSoftObjectPtr<UTexture2D> DynamicAtlasSoftTemplateClear; // Offset: 0x50 | Size: 0x28
};

// Object: Class DynamicAtlas.DynamicAtlasSubsystem
// Inherited Bytes: 0x30 | Struct Size: 0x210
struct UDynamicAtlasSubsystem : UWorldSubsystem {
	// Fields
	struct TMap<enum class EDynamicAtlasGroup, struct UDynamicAtlas*> m_DynamicAtlas; // Offset: 0x30 | Size: 0x50
	struct TArray<struct UTexture2D*> AtlasTemplates; // Offset: 0x80 | Size: 0x10
	struct TArray<struct UCanvasRenderTarget2D*> AtlasTemplateRenderTargets; // Offset: 0x90 | Size: 0x10
	struct TMap<struct FString, struct UDynamicSprite*> DynamicSprites; // Offset: 0xa0 | Size: 0x50
	char pad_0xF0[0x50]; // Offset: 0xf0 | Size: 0x50
	struct TMap<int32_t, struct FString> HandleToPaths; // Offset: 0x140 | Size: 0x50
	struct TMap<struct UObject*, struct UDynamicAtlasLoader*> DynamicAtlasLoaders; // Offset: 0x190 | Size: 0x50
	char pad_0x1E0[0x30]; // Offset: 0x1e0 | Size: 0x30
};

// Object: Class DynamicAtlas.DynamicAtlasTestMain
// Inherited Bytes: 0x260 | Struct Size: 0x310
struct UDynamicAtlasTestMain : UUserWidget {
	// Fields
	struct UImage* Img_StaticTexture; // Offset: 0x260 | Size: 0x8
	struct UImage* Img_StaticTextureSame; // Offset: 0x268 | Size: 0x8
	struct UImage* Img_StaticSprite; // Offset: 0x270 | Size: 0x8
	struct UImage* Img_DynamicTexture; // Offset: 0x278 | Size: 0x8
	struct UImage* Img_DynamicSprite; // Offset: 0x280 | Size: 0x8
	struct UImage* Img_DynamicTextureBeyond; // Offset: 0x288 | Size: 0x8
	struct UImage* Img_DynamicTextureBig; // Offset: 0x290 | Size: 0x8
	struct UButton* BtnAdd; // Offset: 0x298 | Size: 0x8
	struct UButton* BtnRemove; // Offset: 0x2a0 | Size: 0x8
	struct FSoftObjectPath SoftTexturePath; // Offset: 0x2a8 | Size: 0x18
	struct FSoftObjectPath SoftSpritePath; // Offset: 0x2c0 | Size: 0x18
	struct TArray<struct FSoftObjectPath> SoftTexturePaths; // Offset: 0x2d8 | Size: 0x10
	struct TArray<struct UImage*> AddImageList; // Offset: 0x2e8 | Size: 0x10
	char pad_0x2F8[0x18]; // Offset: 0x2f8 | Size: 0x18

	// Functions

	// Object: Function DynamicAtlas.DynamicAtlasTestMain.OnBtnRemoveClicked
	// Flags: [Final|Native|Private]
	// Offset: 0x102f8d678
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnBtnRemoveClicked();

	// Object: Function DynamicAtlas.DynamicAtlasTestMain.OnBtnAddClicked
	// Flags: [Final|Native|Private]
	// Offset: 0x102f8d68c
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnBtnAddClicked();
};

// Object: Class DynamicAtlas.DynamicSprite
// Inherited Bytes: 0x28 | Struct Size: 0x48
struct UDynamicSprite : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
	struct UTexture* SourceTexture; // Offset: 0x30 | Size: 0x8
	struct FVector2D SourceUV; // Offset: 0x38 | Size: 0x8
	struct FVector2D SourceDimension; // Offset: 0x40 | Size: 0x8
};

