#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Enum E_CharacterAnimState.E_CharacterAnimState
enum class E_CharacterAnimState : uint8_t {
	Default = 0,
	SkillStart = 1,
	SkillQuit = 2,
	SkillFire = 3,
	E MAX = 4
};

