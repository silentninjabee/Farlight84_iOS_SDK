#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: UserDefinedEnum E_Item_Quality.E_Item_Quality
enum class E_Item_Quality : uint8_t {
	NewEnumerator6 = 0,
	NewEnumerator0 = 1,
	NewEnumerator1 = 2,
	NewEnumerator2 = 3,
	NewEnumerator3 = 4,
	NewEnumerator5 = 5,
	NewEnumerator4 = 6,
	E_Item_MAX = 7
};

