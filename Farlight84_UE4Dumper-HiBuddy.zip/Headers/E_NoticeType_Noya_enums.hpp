#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: UserDefinedEnum E_NoticeType_Noya.E_NoticeType_Noya
enum class E_NoticeType_Noya : uint8_t {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	E_NoticeType_MAX = 2
};

