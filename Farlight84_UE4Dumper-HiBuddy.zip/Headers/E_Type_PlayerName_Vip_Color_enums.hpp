#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: UserDefinedEnum E_Type_PlayerName_Vip_Color.E_Type_PlayerName_Vip_Color
enum class E_Type_PlayerName_Vip_Color : uint8_t {
	NewEnumerator4 = 0,
	NewEnumerator0 = 1,
	NewEnumerator1 = 2,
	NewEnumerator2 = 3,
	E_Type_PlayerName_Vip_MAX = 4
};

