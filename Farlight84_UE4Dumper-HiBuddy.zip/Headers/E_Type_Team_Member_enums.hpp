#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: UserDefinedEnum E_Type_Team_Member.E_Type_Team_Member
enum class E_Type_Team_Member : uint8_t {
	NewEnumerator0 = 0,
	NewEnumerator4 = 1,
	NewEnumerator1 = 2,
	NewEnumerator2 = 3,
	E_Type_Team_MAX = 4
};

