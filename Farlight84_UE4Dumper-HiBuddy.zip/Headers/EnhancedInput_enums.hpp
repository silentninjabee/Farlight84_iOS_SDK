#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Enum EnhancedInput.EInputActionValueType
enum class EInputActionValueType : uint8_t {
	Boolean = 0,
	Axis1D = 1,
	Axis2D = 2,
	Axis3D = 3,
	EInputActionValueType_MAX = 4
};

// Object: Enum EnhancedInput.EMappingQueryIssue
enum class EMappingQueryIssue : uint8_t {
	NoIssue = 0,
	ReservedByAction = 1,
	HidesExistingMapping = 2,
	HiddenByExistingMapping = 4,
	CollisionWithMappingInSameContext = 8,
	ForcesTypePromotion = 16,
	ForcesTypeDemotion = 32,
	EMappingQueryIssue_MAX = 33
};

// Object: Enum EnhancedInput.EMappingQueryResult
enum class EMappingQueryResult : uint8_t {
	Error_EnhancedInputNotEnabled = 0,
	Error_InputContextNotInActiveContexts = 1,
	Error_InvalidAction = 2,
	NotMappable = 3,
	MappingAvailable = 4,
	EMappingQueryResult_MAX = 5
};

// Object: Enum EnhancedInput.EInputAxisSwizzle
enum class EInputAxisSwizzle : uint8_t {
	YXZ = 0,
	ZYX = 1,
	XZY = 2,
	YZX = 3,
	ZXY = 4,
	EInputAxisSwizzle_MAX = 5
};

// Object: Enum EnhancedInput.EFOVScalingType
enum class EFOVScalingType : uint8_t {
	Standard = 0,
	UE4_BackCompat = 1,
	EFOVScalingType_MAX = 2
};

// Object: Enum EnhancedInput.EDeadZoneType
enum class EDeadZoneType : uint8_t {
	Axial = 0,
	Radial = 1,
	EDeadZoneType_MAX = 2
};

// Object: Enum EnhancedInput.EModifierExecutionPhase
enum class EModifierExecutionPhase : uint8_t {
	PerInput = 0,
	FinalValue = 1,
	NumPhases = 2,
	EModifierExecutionPhase_MAX = 3
};

// Object: Enum EnhancedInput.ETriggerTypeEx
enum class ETriggerTypeEx : uint8_t {
	Explicit = 0,
	Implicit = 1,
	Blocker = 2,
	ETriggerTypeEx_MAX = 3
};

// Object: Enum EnhancedInput.ETriggerEvent
enum class ETriggerEvent : uint8_t {
	None = 0,
	Started = 1,
	Ongoing = 2,
	Canceled = 3,
	Triggered = 4,
	Completed = 5,
	ETriggerEvent_MAX = 6
};

// Object: Enum EnhancedInput.ETriggerState
enum class ETriggerState : uint8_t {
	None = 0,
	Ongoing = 1,
	Triggered = 2,
	ETriggerState_MAX = 3
};

