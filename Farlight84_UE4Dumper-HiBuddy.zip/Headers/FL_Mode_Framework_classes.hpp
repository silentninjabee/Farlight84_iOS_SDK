#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass FL_Mode_Framework.FL_Mode_Framework_C
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UFL_Mode_Framework_C : UBlueprintFunctionLibrary {
	// Functions

	// Object: Function FL_Mode_Framework.FL_Mode_Framework_C.GetCapsuleList
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x10213e738
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetCapsuleList(struct UObject* __WorldContext, struct TArray<int32_t>& OutKeys);

	// Object: Function FL_Mode_Framework.FL_Mode_Framework_C.GetCapsuleData
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x10213e738
	// Return & Params: [ Num(3) Size(0x90) ]
	struct FSolarTablesData_CapsuleProperty GetCapsuleData(int32_t Key, struct UObject* __WorldContext);

	// Object: Function FL_Mode_Framework.FL_Mode_Framework_C.GetDeathBoxList
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x10213e738
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetDeathBoxList(struct UObject* __WorldContext, struct TArray<int32_t>& OutKeys);

	// Object: Function FL_Mode_Framework.FL_Mode_Framework_C.GetDeathBoxData
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x10213e738
	// Return & Params: [ Num(3) Size(0x88) ]
	struct FSolarTablesData_DeathBox GetDeathBoxData(int32_t Key, struct UObject* __WorldContext);

	// Object: Function FL_Mode_Framework.FL_Mode_Framework_C.GetDanceList
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x10213e738
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetDanceList(struct UObject* __WorldContext, struct TArray<int32_t>& OutKeys);

	// Object: Function FL_Mode_Framework.FL_Mode_Framework_C.GetDanceData
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x10213e738
	// Return & Params: [ Num(3) Size(0xa0) ]
	struct FSolarTablesData_Dance GetDanceData(int32_t Key, struct UObject* __WorldContext);

	// Object: Function FL_Mode_Framework.FL_Mode_Framework_C.GetEmojiList
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x10213e738
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetEmojiList(struct UObject* __WorldContext, struct TArray<int32_t>& OutKeys);

	// Object: Function FL_Mode_Framework.FL_Mode_Framework_C.GetEmojiData
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x10213e738
	// Return & Params: [ Num(3) Size(0xc8) ]
	struct FSolarTablesData_Emote GetEmojiData(int32_t Key, struct UObject* __WorldContext);

	// Object: Function FL_Mode_Framework.FL_Mode_Framework_C.SkillConfigToString
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x10213e738
	// Return & Params: [ Num(3) Size(0x20) ]
	struct FString SkillConfigToString(struct FS_SkillState& S_SkillState, struct UObject* __WorldContext);

	// Object: Function FL_Mode_Framework.FL_Mode_Framework_C.GetItemIconPath
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x10213e738
	// Return & Params: [ Num(4) Size(0x30) ]
	struct FString GetItemIconPath(int32_t Key, struct FString BasePath, struct UObject* __WorldContext);

	// Object: Function FL_Mode_Framework.FL_Mode_Framework_C.GetVehicleSkinList
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x10213e738
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetVehicleSkinList(struct UObject* __WorldContext, struct TArray<int32_t>& OutKeys);

	// Object: Function FL_Mode_Framework.FL_Mode_Framework_C.GetVehicleSkinData
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x10213e738
	// Return & Params: [ Num(3) Size(0x98) ]
	struct FSolarTablesData_VehicleSkin GetVehicleSkinData(int32_t Key, struct UObject* __WorldContext);

	// Object: Function FL_Mode_Framework.FL_Mode_Framework_C.GetVehicleTypeList
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x10213e738
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetVehicleTypeList(struct UObject* __WorldContext, struct TArray<int32_t>& OutKeys);

	// Object: Function FL_Mode_Framework.FL_Mode_Framework_C.GetVehicleTypeData
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x10213e738
	// Return & Params: [ Num(3) Size(0x118) ]
	struct FSolarTablesData_VehicleType GetVehicleTypeData(int32_t Key, struct UObject* __WorldContext);

	// Object: Function FL_Mode_Framework.FL_Mode_Framework_C.GetWeaponSkinList
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x10213e738
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetWeaponSkinList(struct UObject* __WorldContext, struct TArray<int32_t>& OutKeys);

	// Object: Function FL_Mode_Framework.FL_Mode_Framework_C.GetWeaponSkinData
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x10213e738
	// Return & Params: [ Num(3) Size(0xa0) ]
	struct FSolarTablesData_WeaponSkin GetWeaponSkinData(int32_t Key, struct UObject* __WorldContext);

	// Object: Function FL_Mode_Framework.FL_Mode_Framework_C.GetWeaponList
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x10213e738
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetWeaponList(struct UObject* __WorldContext, struct TArray<int32_t>& OutKeys);

	// Object: Function FL_Mode_Framework.FL_Mode_Framework_C.GetWeaponData
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x10213e738
	// Return & Params: [ Num(3) Size(0xf8) ]
	struct FSolarTablesData_GunProperty GetWeaponData(int32_t Key, struct UObject* __WorldContext);

	// Object: Function FL_Mode_Framework.FL_Mode_Framework_C.GetBroadcastPlayerName
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(3) Size(0x28) ]
	void GetBroadcastPlayerName(struct FString SolarPlayerId, struct UObject* __WorldContext, struct FString& BroadcastPlayerName);

	// Object: Function FL_Mode_Framework.FL_Mode_Framework_C.BindBroadcastModeChanged
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(2) Size(0x18) ]
	void BindBroadcastModeChanged(struct FDelegate& Event, struct UObject* __WorldContext);

	// Object: Function FL_Mode_Framework.FL_Mode_Framework_C.GetBroadcastHeroName
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(3) Size(0x28) ]
	void GetBroadcastHeroName(struct FString SolarPlayerId, struct UObject* __WorldContext, struct FString& BroadcastHeroName);

	// Object: Function FL_Mode_Framework.FL_Mode_Framework_C.IsTouchScreenLayout
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x10213e738
	// Return & Params: [ Num(2) Size(0x9) ]
	bool IsTouchScreenLayout(struct UObject* __WorldContext);

	// Object: Function FL_Mode_Framework.FL_Mode_Framework_C.GetPositionOfCircle
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x10213e738
	// Return & Params: [ Num(4) Size(0x18) ]
	void GetPositionOfCircle(float Radius, float Angle, struct UObject* __WorldContext, struct FVector2D& Position);

	// Object: Function FL_Mode_Framework.FL_Mode_Framework_C.[s]SetCharacterSkill
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(3) Size(0x18) ]
	void [s]SetCharacterSkill(struct ASolarCharacter* Character, struct FS_SkillState& SkillConfig, struct UObject* __WorldContext);

	// Object: Function FL_Mode_Framework.FL_Mode_Framework_C.[a]GetCharacterIDBySkinID
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x10213e738
	// Return & Params: [ Num(3) Size(0x14) ]
	void [a]GetCharacterIDBySkinID(int32_t SkinID, struct UObject* __WorldContext, int32_t& CharacterID);

	// Object: Function FL_Mode_Framework.FL_Mode_Framework_C.SetSkillState
	// Flags: [Static|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(4) Size(0x18) ]
	void SetSkillState(struct ASolarCharacter* Character, enum class ECharacterRoleAbilityIndex SkillType, enum class ERoleSkillOperation NewSate, struct UObject* __WorldContext);

	// Object: Function FL_Mode_Framework.FL_Mode_Framework_C.Set Skill State for Everybody
	// Flags: [Static|Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(3) Size(0x10) ]
	void Set Skill State for Everybody(enum class E_CharacterSkillType SkillType, enum class ERoleSkillOperation NewSate, struct UObject* __WorldContext);

	// Object: Function FL_Mode_Framework.FL_Mode_Framework_C.SetWeaponPartByPartID
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(4) Size(0x19) ]
	void SetWeaponPartByPartID(struct ASolarWeapon* TargetWeapon, int32_t PartID, struct UObject* __WorldContext, bool& Success);

	// Object: Function FL_Mode_Framework.FL_Mode_Framework_C.Distribute Experience to Side
	// Flags: [Static|Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(3) Size(0x10) ]
	void Distribute Experience to Side(int32_t InExp, enum class EExpBehaviorType InType, struct UObject* __WorldContext);

	// Object: Function FL_Mode_Framework.FL_Mode_Framework_C.GetRandomCharacter
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x10213e738
	// Return & Params: [ Num(2) Size(0xc) ]
	void GetRandomCharacter(struct UObject* __WorldContext, int32_t& Output);

	// Object: Function FL_Mode_Framework.FL_Mode_Framework_C.RandomIntInRange
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x10213e738
	// Return & Params: [ Num(3) Size(0x1c) ]
	int32_t RandomIntInRange(struct FInt32Range Range, struct UObject* __WorldContext);

	// Object: Function FL_Mode_Framework.FL_Mode_Framework_C.GetLocText
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x10213e738
	// Return & Params: [ Num(3) Size(0x20) ]
	struct FString GetLocText(struct FSolarTablesLocalText& InData, struct UObject* __WorldContext);

	// Object: Function FL_Mode_Framework.FL_Mode_Framework_C.GetTrailList
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x10213e738
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetTrailList(struct UObject* __WorldContext, struct TArray<int32_t>& OutKeys);

	// Object: Function FL_Mode_Framework.FL_Mode_Framework_C.GetTrailData
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x10213e738
	// Return & Params: [ Num(3) Size(0x90) ]
	struct FSolarTablesData_BackpackTrailProperty GetTrailData(int32_t Key, struct UObject* __WorldContext);

	// Object: Function FL_Mode_Framework.FL_Mode_Framework_C.GetBackpackList
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x10213e738
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetBackpackList(struct UObject* __WorldContext, struct TArray<int32_t>& OutKeys);

	// Object: Function FL_Mode_Framework.FL_Mode_Framework_C.GetBackpackData
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x10213e738
	// Return & Params: [ Num(3) Size(0xa0) ]
	struct FSolarTablesData_BackpackProperty GetBackpackData(int32_t Key, struct UObject* __WorldContext);

	// Object: Function FL_Mode_Framework.FL_Mode_Framework_C.GetCharacterList
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x10213e738
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetCharacterList(struct UObject* __WorldContext, struct TArray<int32_t>& OutKeys);

	// Object: Function FL_Mode_Framework.FL_Mode_Framework_C.GetCharacterData
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x10213e738
	// Return & Params: [ Num(3) Size(0x1b8) ]
	struct FSolarTablesData_UnitCharacter GetCharacterData(int32_t Key, struct UObject* __WorldContext);

	// Object: Function FL_Mode_Framework.FL_Mode_Framework_C.GetTextureByPath
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x10213e738
	// Return & Params: [ Num(3) Size(0x20) ]
	struct UObject* GetTextureByPath(struct FString Path, struct UObject* __WorldContext);

	// Object: Function FL_Mode_Framework.FL_Mode_Framework_C.GetCharacterSkinList
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x10213e738
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetCharacterSkinList(struct UObject* __WorldContext, struct TArray<int32_t>& OutKeys);

	// Object: Function FL_Mode_Framework.FL_Mode_Framework_C.GetCharacterSkinData
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x10213e738
	// Return & Params: [ Num(3) Size(0x128) ]
	struct FSolarTablesData_Skin GetCharacterSkinData(int32_t Key, struct UObject* __WorldContext);
};

