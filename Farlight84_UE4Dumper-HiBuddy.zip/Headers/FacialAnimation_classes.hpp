#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class FacialAnimation.AudioCurveSourceComponent
// Inherited Bytes: 0x960 | Struct Size: 0x9a0
struct UAudioCurveSourceComponent : UAudioComponent {
	// Fields
	struct FName CurveSourceBindingName; // Offset: 0x960 | Size: 0x8
	float CurveSyncOffset; // Offset: 0x968 | Size: 0x4
	char pad_0x96C[0x34]; // Offset: 0x96c | Size: 0x34
};

