#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class FairyGUI.DragDropManager
// Inherited Bytes: 0x28 | Struct Size: 0x48
struct UDragDropManager : UObject {
	// Fields
	struct UGLoader* Agent; // Offset: 0x28 | Size: 0x8
	char pad_0x30[0x18]; // Offset: 0x30 | Size: 0x18

	// Functions

	// Object: Function FairyGUI.DragDropManager.StartDrag
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1035c0cd8
	// Return & Params: [ Num(4) Size(0x30) ]
	void StartDrag(struct FString InIcon, struct FNVariant& InUserData, int32_t InUserIndex, int32_t InPointerIndex);

	// Object: Function FairyGUI.DragDropManager.IsDragging
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c0e34
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsDragging();

	// Object: Function FairyGUI.DragDropManager.GetAgent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c0e74
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UGLoader* GetAgent();

	// Object: Function FairyGUI.DragDropManager.Cancel
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c0cc8
	// Return & Params: [ Num(0) Size(0x0) ]
	void Cancel();
};

// Object: Class FairyGUI.EventContext
// Inherited Bytes: 0x28 | Struct Size: 0x78
struct UEventContext : UObject {
	// Fields
	char pad_0x28[0x50]; // Offset: 0x28 | Size: 0x50

	// Functions

	// Object: Function FairyGUI.EventContext.StopPropagation
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c1060
	// Return & Params: [ Num(0) Size(0x0) ]
	void StopPropagation();

	// Object: Function FairyGUI.EventContext.PreventDefault
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c1030
	// Return & Params: [ Num(0) Size(0x0) ]
	void PreventDefault();

	// Object: Function FairyGUI.EventContext.IsPropagationStopped
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c104c
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsPropagationStopped();

	// Object: Function FairyGUI.EventContext.IsDoubleClick
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c1094
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsDoubleClick();

	// Object: Function FairyGUI.EventContext.IsDefaultPrevented
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c101c
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsDefaultPrevented();

	// Object: Function FairyGUI.EventContext.GetWheelDelta
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c1280
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetWheelDelta();

	// Object: Function FairyGUI.EventContext.GetUserIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c1298
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetUserIndex();

	// Object: Function FairyGUI.EventContext.GetType
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c12d4
	// Return & Params: [ Num(1) Size(0x8) ]
	struct FName GetType();

	// Object: Function FairyGUI.EventContext.GetSender
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c1300
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UGObject* GetSender();

	// Object: Function FairyGUI.EventContext.GetPointerPosition
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c12c0
	// Return & Params: [ Num(1) Size(0x8) ]
	struct FVector2D GetPointerPosition();

	// Object: Function FairyGUI.EventContext.GetPointerIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c12ac
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetPointerIndex();

	// Object: Function FairyGUI.EventContext.GetPointerEvent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c1178
	// Return & Params: [ Num(1) Size(0x70) ]
	struct FPointerEvent GetPointerEvent();

	// Object: Function FairyGUI.EventContext.GetMouseButton
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c1190
	// Return & Params: [ Num(1) Size(0x18) ]
	struct FKey GetMouseButton();

	// Object: Function FairyGUI.EventContext.GetKeyEvent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c10cc
	// Return & Params: [ Num(1) Size(0x38) ]
	struct FKeyEvent GetKeyEvent();

	// Object: Function FairyGUI.EventContext.GetInitiator
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c12e8
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UGObject* GetInitiator();

	// Object: Function FairyGUI.EventContext.GetData
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c107c
	// Return & Params: [ Num(1) Size(0x18) ]
	struct FNVariant GetData();

	// Object: Function FairyGUI.EventContext.GetClickCount
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c10b4
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetClickCount();

	// Object: Function FairyGUI.EventContext.CaptureTouch
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c1000
	// Return & Params: [ Num(0) Size(0x0) ]
	void CaptureTouch();
};

// Object: Class FairyGUI.FairyApplication
// Inherited Bytes: 0x28 | Struct Size: 0xc0
struct UFairyApplication : UObject {
	// Fields
	struct UGRoot* UIRoot; // Offset: 0x28 | Size: 0x8
	struct UDragDropManager* DragDropManager; // Offset: 0x30 | Size: 0x8
	struct TArray<struct UEventContext*> EventContextPool; // Offset: 0x38 | Size: 0x10
	char pad_0x48[0x78]; // Offset: 0x48 | Size: 0x78

	// Functions

	// Object: Function FairyGUI.FairyApplication.SetSoundVolumeScale
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c1770
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetSoundVolumeScale(float InVolumeScale);

	// Object: Function FairyGUI.FairyApplication.SetSoundEnabled
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c17e4
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetSoundEnabled(bool InEnabled);

	// Object: Function FairyGUI.FairyApplication.PlaySound
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c1854
	// Return & Params: [ Num(2) Size(0x14) ]
	void PlaySound(struct FString URL, float VolumeScale);

	// Object: Function FairyGUI.FairyApplication.IsSoundEnabled
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c1840
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsSoundEnabled();

	// Object: Function FairyGUI.FairyApplication.GetUIRoot
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c1a9c
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UGRoot* GetUIRoot();

	// Object: Function FairyGUI.FairyApplication.GetTouchPosition
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x1035c19f8
	// Return & Params: [ Num(3) Size(0x10) ]
	struct FVector2D GetTouchPosition(int32_t InUserIndex, int32_t InPointerIndex);

	// Object: Function FairyGUI.FairyApplication.GetTouchCount
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c19d4
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetTouchCount();

	// Object: Function FairyGUI.FairyApplication.GetSoundVolumeScale
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c17cc
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetSoundVolumeScale();

	// Object: Function FairyGUI.FairyApplication.GetObjectUnderPoint
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1035c1978
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UGObject* GetObjectUnderPoint(struct FVector2D& ScreenspacePosition);

	// Object: Function FairyGUI.FairyApplication.GetDragDropManager
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c1a84
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UDragDropManager* GetDragDropManager();

	// Object: Function FairyGUI.FairyApplication.Get
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1035c1ac0
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UFairyApplication* Get(struct UObject* WorldContextObject);

	// Object: Function FairyGUI.FairyApplication.CancelClick
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c18f0
	// Return & Params: [ Num(2) Size(0x8) ]
	void CancelClick(int32_t InUserIndex, int32_t InPointerIndex);
};

// Object: Class FairyGUI.FairyBlueprintLibrary
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UFairyBlueprintLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object: Function FairyGUI.FairyBlueprintLibrary.TweenVector2
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1035c1f04
	// Return & Params: [ Num(8) Size(0x48) ]
	struct FTweenerHandle TweenVector2(struct FVector2D& StartValue, struct FVector2D& EndValue, enum class EEaseType EaseType, float Duration, int32_t Repeat, struct FDelegate& OnUpdate, struct FDelegate& OnComplete);

	// Object: Function FairyGUI.FairyBlueprintLibrary.TweenFloat
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1035c20ec
	// Return & Params: [ Num(8) Size(0x40) ]
	struct FTweenerHandle TweenFloat(float StartValue, float EndValue, enum class EEaseType EaseType, float Duration, int32_t Repeat, struct FDelegate& OnUpdate, struct FDelegate& OnComplete);

	// Object: Function FairyGUI.FairyBlueprintLibrary.SetVariantUObject
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1035c22b8
	// Return & Params: [ Num(3) Size(0x38) ]
	struct FNVariant SetVariantUObject(struct FNVariant& InVariant, struct UObject* InValue);

	// Object: Function FairyGUI.FairyBlueprintLibrary.SetVariantString
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1035c2444
	// Return & Params: [ Num(3) Size(0x40) ]
	struct FNVariant SetVariantString(struct FNVariant& InVariant, struct FString InValue);

	// Object: Function FairyGUI.FairyBlueprintLibrary.SetVariantInt
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1035c25f4
	// Return & Params: [ Num(3) Size(0x38) ]
	struct FNVariant SetVariantInt(struct FNVariant& InVariant, int32_t InValue);

	// Object: Function FairyGUI.FairyBlueprintLibrary.SetVariantFloat
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1035c2530
	// Return & Params: [ Num(3) Size(0x38) ]
	struct FNVariant SetVariantFloat(struct FNVariant& InVariant, float InValue);

	// Object: Function FairyGUI.FairyBlueprintLibrary.SetVariantColor
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1035c237c
	// Return & Params: [ Num(3) Size(0x38) ]
	struct FNVariant SetVariantColor(struct FNVariant& InVariant, struct FColor& InValue);

	// Object: Function FairyGUI.FairyBlueprintLibrary.SetVariantBool
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1035c26c8
	// Return & Params: [ Num(3) Size(0x38) ]
	struct FNVariant SetVariantBool(struct FNVariant& InVariant, bool bInValue);

	// Object: Function FairyGUI.FairyBlueprintLibrary.SetUIConfig
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1035c2b6c
	// Return & Params: [ Num(1) Size(0xc0) ]
	void SetUIConfig(struct FUIConfig& InConfig);

	// Object: Function FairyGUI.FairyBlueprintLibrary.SetPackageItemExtension
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1035c1df8
	// Return & Params: [ Num(2) Size(0x18) ]
	void SetPackageItemExtension(struct FString URL, struct UGComponent* ClassType);

	// Object: Function FairyGUI.FairyBlueprintLibrary.KillTween
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1035c1e78
	// Return & Params: [ Num(2) Size(0x9) ]
	void KillTween(struct FTweenerHandle& Handle, bool bSetComplete);

	// Object: Function FairyGUI.FairyBlueprintLibrary.GetVariantAsUObject
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x1035c279c
	// Return & Params: [ Num(3) Size(0x28) ]
	struct UObject* GetVariantAsUObject(struct FNVariant& InVariant, struct UObject* ClassType);

	// Object: Function FairyGUI.FairyBlueprintLibrary.GetVariantAsString
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x1035c28ec
	// Return & Params: [ Num(2) Size(0x28) ]
	struct FString GetVariantAsString(struct FNVariant& InVariant);

	// Object: Function FairyGUI.FairyBlueprintLibrary.GetVariantAsInt
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x1035c2a54
	// Return & Params: [ Num(2) Size(0x1c) ]
	int32_t GetVariantAsInt(struct FNVariant& InVariant);

	// Object: Function FairyGUI.FairyBlueprintLibrary.GetVariantAsFloat
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x1035c29c8
	// Return & Params: [ Num(2) Size(0x1c) ]
	float GetVariantAsFloat(struct FNVariant& InVariant);

	// Object: Function FairyGUI.FairyBlueprintLibrary.GetVariantAsColor
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x1035c2860
	// Return & Params: [ Num(2) Size(0x1c) ]
	struct FColor GetVariantAsColor(struct FNVariant& InVariant);

	// Object: Function FairyGUI.FairyBlueprintLibrary.GetVariantAsBool
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x1035c2ae0
	// Return & Params: [ Num(2) Size(0x19) ]
	bool GetVariantAsBool(struct FNVariant& InVariant);

	// Object: Function FairyGUI.FairyBlueprintLibrary.GetUIConfig
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1035c2be0
	// Return & Params: [ Num(1) Size(0xc0) ]
	struct FUIConfig GetUIConfig();
};

// Object: Class FairyGUI.GObject
// Inherited Bytes: 0x28 | Struct Size: 0x340
struct UGObject : UObject {
	// Fields
	struct FMulticastInlineDelegate OnClick; // Offset: 0x28 | Size: 0x10
	struct FMulticastInlineDelegate OnTouchBegin; // Offset: 0x38 | Size: 0x10
	struct FMulticastInlineDelegate OnTouchMove; // Offset: 0x48 | Size: 0x10
	struct FMulticastInlineDelegate OnTouchEnd; // Offset: 0x58 | Size: 0x10
	struct FMulticastInlineDelegate OnRollOver; // Offset: 0x68 | Size: 0x10
	struct FMulticastInlineDelegate OnRollOut; // Offset: 0x78 | Size: 0x10
	struct FMulticastInlineDelegate OnDragStart; // Offset: 0x88 | Size: 0x10
	struct FMulticastInlineDelegate OnDragMove; // Offset: 0x98 | Size: 0x10
	struct FMulticastInlineDelegate OnDragEnd; // Offset: 0xa8 | Size: 0x10
	struct FMulticastInlineDelegate OnGearStop; // Offset: 0xb8 | Size: 0x10
	struct FMulticastInlineDelegate OnAddedToStage; // Offset: 0xc8 | Size: 0x10
	struct FMulticastInlineDelegate OnRemovedFromStage; // Offset: 0xd8 | Size: 0x10
	struct FString ID; // Offset: 0xe8 | Size: 0x10
	struct FString Name; // Offset: 0xf8 | Size: 0x10
	struct FVector2D SourceSize; // Offset: 0x108 | Size: 0x8
	struct FVector2D InitSize; // Offset: 0x110 | Size: 0x8
	struct FVector2D MinSize; // Offset: 0x118 | Size: 0x8
	struct FVector2D MaxSize; // Offset: 0x120 | Size: 0x8
	struct FNVariant UserData; // Offset: 0x128 | Size: 0x18
	char pad_0x140[0x200]; // Offset: 0x140 | Size: 0x200

	// Functions

	// Object: Function FairyGUI.GObject.StopDrag
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035ccf20
	// Return & Params: [ Num(0) Size(0x0) ]
	void StopDrag();

	// Object: Function FairyGUI.GObject.StartDrag
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035ccf30
	// Return & Params: [ Num(2) Size(0x8) ]
	void StartDrag(int32_t UserIndex, int32_t PointerIndex);

	// Object: Function FairyGUI.GObject.SetYMin
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035cd944
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetYMin(float InYMin);

	// Object: Function FairyGUI.GObject.SetY
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035cda54
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetY(float InY);

	// Object: Function FairyGUI.GObject.SetXMin
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035cd9a0
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetXMin(float InXMin);

	// Object: Function FairyGUI.GObject.SetX
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035cdaa0
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetX(float InX);

	// Object: Function FairyGUI.GObject.SetWidth
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035cd8d8
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetWidth(float InWidth);

	// Object: Function FairyGUI.GObject.SetVisible
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035cd3b4
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetVisible(bool bInVisible);

	// Object: Function FairyGUI.GObject.SetTouchable
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035cd34c
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetTouchable(bool bInTouchable);

	// Object: Function FairyGUI.GObject.SetTooltips
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035cd07c
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetTooltips(struct FString InTooltips);

	// Object: Function FairyGUI.GObject.SetText
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1035cd1e0
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetText(struct FString InText);

	// Object: Function FairyGUI.GObject.SetSortingOrder
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035cd2fc
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetSortingOrder(int32_t InSortingOrder);

	// Object: Function FairyGUI.GObject.SetSkew
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1035cd50c
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetSkew(struct FVector2D& InSkew);

	// Object: Function FairyGUI.GObject.SetSize
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1035cd7d0
	// Return & Params: [ Num(2) Size(0x9) ]
	void SetSize(struct FVector2D& InSize, bool bIgnorePivot);

	// Object: Function FairyGUI.GObject.SetScaleY
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035cd5bc
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetScaleY(float InScaleY);

	// Object: Function FairyGUI.GObject.SetScaleX
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035cd628
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetScaleX(float InScaleX);

	// Object: Function FairyGUI.GObject.SetScale
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1035cd564
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetScale(struct FVector2D& InScale);

	// Object: Function FairyGUI.GObject.SetRotation
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035cd4c0
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetRotation(float InRotation);

	// Object: Function FairyGUI.GObject.SetPosition
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1035cd9fc
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetPosition(struct FVector2D& InPosition);

	// Object: Function FairyGUI.GObject.SetPivot
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1035cd6ac
	// Return & Params: [ Num(2) Size(0x9) ]
	void SetPivot(struct FVector2D& InPivot, bool bAsAnchor);

	// Object: Function FairyGUI.GObject.SetParentToRoot
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035cca78
	// Return & Params: [ Num(0) Size(0x0) ]
	void SetParentToRoot();

	// Object: Function FairyGUI.GObject.SetParent
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035cca88
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetParent(struct UGObject* InParent);

	// Object: Function FairyGUI.GObject.SetIcon
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1035cd12c
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetIcon(struct FString InIcon);

	// Object: Function FairyGUI.GObject.SetHeight
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035cd86c
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetHeight(float InHeight);

	// Object: Function FairyGUI.GObject.SetGroup
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035cd294
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetGroup(struct UGGroup* InGroup);

	// Object: Function FairyGUI.GObject.SetGrayed
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035cd414
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetGrayed(bool bInGrayed);

	// Object: Function FairyGUI.GObject.SetDraggable
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035cd01c
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetDraggable(bool bInDraggable);

	// Object: Function FairyGUI.GObject.SetDragBounds
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1035ccfa0
	// Return & Params: [ Num(1) Size(0x14) ]
	void SetDragBounds(struct FBox2D& InBounds);

	// Object: Function FairyGUI.GObject.SetAlpha
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035cd474
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetAlpha(float InAlpha);

	// Object: Function FairyGUI.GObject.RootToLocalRect
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1035ccd30
	// Return & Params: [ Num(2) Size(0x28) ]
	struct FBox2D RootToLocalRect(struct FBox2D& InRect);

	// Object: Function FairyGUI.GObject.RootToLocal
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1035ccd74
	// Return & Params: [ Num(2) Size(0x10) ]
	struct FVector2D RootToLocal(struct FVector2D& InPoint);

	// Object: Function FairyGUI.GObject.RemoveRelation
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035ccaf0
	// Return & Params: [ Num(2) Size(0x9) ]
	void RemoveRelation(struct UGObject* Obj, enum class ERelationType RelationType);

	// Object: Function FairyGUI.GObject.RemoveFromParent
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035cc9fc
	// Return & Params: [ Num(0) Size(0x0) ]
	void RemoveFromParent();

	// Object: Function FairyGUI.GObject.OnTouchMoveHandler
	// Flags: [Final|Native|Private]
	// Offset: 0x1035cc858
	// Return & Params: [ Num(1) Size(0x8) ]
	void OnTouchMoveHandler(struct UEventContext* Context);

	// Object: Function FairyGUI.GObject.OnTouchEndHandler
	// Flags: [Final|Native|Private]
	// Offset: 0x1035cc818
	// Return & Params: [ Num(1) Size(0x8) ]
	void OnTouchEndHandler(struct UEventContext* Context);

	// Object: Function FairyGUI.GObject.OnTouchBeginHandler
	// Flags: [Final|Native|Private]
	// Offset: 0x1035cc898
	// Return & Params: [ Num(1) Size(0x8) ]
	void OnTouchBeginHandler(struct UEventContext* Context);

	// Object: Function FairyGUI.GObject.OnStage
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035cca0c
	// Return & Params: [ Num(1) Size(0x1) ]
	bool OnStage();

	// Object: Function FairyGUI.GObject.OnRollOverHandler
	// Flags: [Final|Native|Private]
	// Offset: 0x1035cc918
	// Return & Params: [ Num(1) Size(0x8) ]
	void OnRollOverHandler(struct UEventContext* Context);

	// Object: Function FairyGUI.GObject.OnRollOutHandler
	// Flags: [Final|Native|Private]
	// Offset: 0x1035cc8d8
	// Return & Params: [ Num(1) Size(0x8) ]
	void OnRollOutHandler(struct UEventContext* Context);

	// Object: Function FairyGUI.GObject.MakeFullScreen
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035cd748
	// Return & Params: [ Num(1) Size(0x1) ]
	void MakeFullScreen(bool bRestraint);

	// Object: Function FairyGUI.GObject.LocalToRootRect
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1035ccc18
	// Return & Params: [ Num(2) Size(0x28) ]
	struct FBox2D LocalToRootRect(struct FBox2D& InRect);

	// Object: Function FairyGUI.GObject.LocalToRoot
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1035ccc5c
	// Return & Params: [ Num(2) Size(0x10) ]
	struct FVector2D LocalToRoot(struct FVector2D& InPoint);

	// Object: Function FairyGUI.GObject.LocalToGlobalRect
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1035ccca4
	// Return & Params: [ Num(2) Size(0x28) ]
	struct FBox2D LocalToGlobalRect(struct FBox2D& InRect);

	// Object: Function FairyGUI.GObject.LocalToGlobal
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1035ccce8
	// Return & Params: [ Num(2) Size(0x10) ]
	struct FVector2D LocalToGlobal(struct FVector2D& InPoint);

	// Object: Function FairyGUI.GObject.IsVisible
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035cd3f8
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsVisible();

	// Object: Function FairyGUI.GObject.IsTouchable
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035cd390
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsTouchable();

	// Object: Function FairyGUI.GObject.IsPivotAsAnchor
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035cd694
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsPivotAsAnchor();

	// Object: Function FairyGUI.GObject.IsGrayed
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035cd458
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsGrayed();

	// Object: Function FairyGUI.GObject.IsDraggable
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035cd060
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsDraggable();

	// Object: Function FairyGUI.GObject.GlobalToLocalRect
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1035ccdbc
	// Return & Params: [ Num(2) Size(0x28) ]
	struct FBox2D GlobalToLocalRect(struct FBox2D& InRect);

	// Object: Function FairyGUI.GObject.GlobalToLocal
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1035cce00
	// Return & Params: [ Num(2) Size(0x10) ]
	struct FVector2D GlobalToLocal(struct FVector2D& InPoint);

	// Object: Function FairyGUI.GObject.GetYMin
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035cd97c
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetYMin();

	// Object: Function FairyGUI.GObject.GetY
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035cda8c
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetY();

	// Object: Function FairyGUI.GObject.GetXMin
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035cd9d8
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetXMin();

	// Object: Function FairyGUI.GObject.GetX
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035cdad8
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetX();

	// Object: Function FairyGUI.GObject.GetWidth
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035cd930
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetWidth();

	// Object: Function FairyGUI.GObject.GetUIRoot
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035cca54
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UGRoot* GetUIRoot();

	// Object: Function FairyGUI.GObject.GetTreeNode
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035cc984
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UGTreeNode* GetTreeNode();

	// Object: Function FairyGUI.GObject.GetTooltips
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035cd0d8
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetTooltips();

	// Object: Function FairyGUI.GObject.GetText
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035cd240
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetText();

	// Object: Function FairyGUI.GObject.GetSortingOrder
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035cd334
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetSortingOrder();

	// Object: Function FairyGUI.GObject.GetSkew
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035cd550
	// Return & Params: [ Num(1) Size(0x8) ]
	struct FVector2D GetSkew();

	// Object: Function FairyGUI.GObject.GetSize
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035cd858
	// Return & Params: [ Num(1) Size(0x8) ]
	struct FVector2D GetSize();

	// Object: Function FairyGUI.GObject.GetScaleY
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035cd614
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetScaleY();

	// Object: Function FairyGUI.GObject.GetScaleX
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035cd680
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetScaleX();

	// Object: Function FairyGUI.GObject.GetScale
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035cd5a8
	// Return & Params: [ Num(1) Size(0x8) ]
	struct FVector2D GetScale();

	// Object: Function FairyGUI.GObject.GetRotation
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035cd4f8
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetRotation();

	// Object: Function FairyGUI.GObject.GetResourceURL
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035cced8
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetResourceURL();

	// Object: Function FairyGUI.GObject.GetResourceName
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035cce90
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetResourceName();

	// Object: Function FairyGUI.GObject.GetPosition
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035cda40
	// Return & Params: [ Num(1) Size(0x8) ]
	struct FVector2D GetPosition();

	// Object: Function FairyGUI.GObject.GetPivot
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035cd734
	// Return & Params: [ Num(1) Size(0x8) ]
	struct FVector2D GetPivot();

	// Object: Function FairyGUI.GObject.GetParent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035ccac8
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UGComponent* GetParent();

	// Object: Function FairyGUI.GObject.GetPackageName
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035cce48
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetPackageName();

	// Object: Function FairyGUI.GObject.GetIcon
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035cd18c
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetIcon();

	// Object: Function FairyGUI.GObject.GetHeight
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035cd8c4
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetHeight();

	// Object: Function FairyGUI.GObject.GetGroup
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035cd2d4
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UGGroup* GetGroup();

	// Object: Function FairyGUI.GObject.GetDraggingObject
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1035cc958
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UGObject* GetDraggingObject();

	// Object: Function FairyGUI.GObject.GetDragBounds
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035ccfe4
	// Return & Params: [ Num(1) Size(0x14) ]
	struct FBox2D GetDragBounds();

	// Object: Function FairyGUI.GObject.GetApp
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035cca30
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UFairyApplication* GetApp();

	// Object: Function FairyGUI.GObject.GetAlpha
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035cd4ac
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetAlpha();

	// Object: Function FairyGUI.GObject.Center
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035cd78c
	// Return & Params: [ Num(1) Size(0x1) ]
	void Center(bool bRestraint);

	// Object: Function FairyGUI.GObject.CastTo
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035cc998
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UGObject* CastTo(struct UGObject* ClassType);

	// Object: Function FairyGUI.GObject.AddRelation
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035ccb64
	// Return & Params: [ Num(3) Size(0xa) ]
	void AddRelation(struct UGObject* Obj, enum class ERelationType RelationType, bool bUsePercent);
};

// Object: Class FairyGUI.GComponent
// Inherited Bytes: 0x340 | Struct Size: 0x448
struct UGComponent : UGObject {
	// Fields
	struct FMulticastInlineDelegate OnDrop; // Offset: 0x340 | Size: 0x10
	struct FMulticastInlineDelegate OnScroll; // Offset: 0x350 | Size: 0x10
	struct FMulticastInlineDelegate OnScrollEnd; // Offset: 0x360 | Size: 0x10
	struct FMulticastInlineDelegate OnPullUpRelease; // Offset: 0x370 | Size: 0x10
	struct FMulticastInlineDelegate OnPullDownRelease; // Offset: 0x380 | Size: 0x10
	char pad_0x390[0x8]; // Offset: 0x390 | Size: 0x8
	struct TArray<struct UGObject*> Children; // Offset: 0x398 | Size: 0x10
	struct TArray<struct UGController*> Controllers; // Offset: 0x3a8 | Size: 0x10
	struct TArray<struct UTransition*> Transitions; // Offset: 0x3b8 | Size: 0x10
	struct UScrollPane* ScrollPane; // Offset: 0x3c8 | Size: 0x8
	char pad_0x3D0[0x78]; // Offset: 0x3d0 | Size: 0x78

	// Functions

	// Object: Function FairyGUI.GComponent.SwapChildrenAt
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c5f64
	// Return & Params: [ Num(2) Size(0x8) ]
	void SwapChildrenAt(int32_t Index1, int32_t Index2);

	// Object: Function FairyGUI.GComponent.SwapChildren
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c5fcc
	// Return & Params: [ Num(2) Size(0x10) ]
	void SwapChildren(struct UGObject* Child1, struct UGObject* Child2);

	// Object: Function FairyGUI.GComponent.SetViewWidth
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c5ae8
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetViewWidth(float InViewWidth);

	// Object: Function FairyGUI.GComponent.SetViewHeight
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c5a8c
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetViewHeight(float InViewHeight);

	// Object: Function FairyGUI.GComponent.SetOpaque
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c5c88
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetOpaque(bool bInOpaque);

	// Object: Function FairyGUI.GComponent.SetMargin
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1035c5c0c
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetMargin(struct FMargin& InMargin);

	// Object: Function FairyGUI.GComponent.SetChildrenRenderOrder
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c5ba8
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetChildrenRenderOrder(enum class EChildrenRenderOrder InChildrenRenderOrder);

	// Object: Function FairyGUI.GComponent.SetChildIndexBefore
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c6054
	// Return & Params: [ Num(3) Size(0x10) ]
	int32_t SetChildIndexBefore(struct UGObject* Child, int32_t Index);

	// Object: Function FairyGUI.GComponent.SetChildIndex
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c60c8
	// Return & Params: [ Num(2) Size(0xc) ]
	void SetChildIndex(struct UGObject* Child, int32_t Index);

	// Object: Function FairyGUI.GComponent.SetBoundsChangedFlag
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c5a7c
	// Return & Params: [ Num(0) Size(0x0) ]
	void SetBoundsChangedFlag();

	// Object: Function FairyGUI.GComponent.SetApexIndex
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c5b5c
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetApexIndex(int32_t InApedIndex);

	// Object: Function FairyGUI.GComponent.RemoveChildren
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c6428
	// Return & Params: [ Num(2) Size(0x8) ]
	void RemoveChildren(int32_t BeginIndex, int32_t EndIndex);

	// Object: Function FairyGUI.GComponent.RemoveChildAt
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1035c6490
	// Return & Params: [ Num(1) Size(0x4) ]
	void RemoveChildAt(int32_t Index);

	// Object: Function FairyGUI.GComponent.RemoveChild
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c64e4
	// Return & Params: [ Num(1) Size(0x8) ]
	void RemoveChild(struct UGObject* Child);

	// Object: Function FairyGUI.GComponent.OnClickChild
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1035c5978
	// Return & Params: [ Num(2) Size(0x20) ]
	void OnClickChild(struct FString ChildName, struct FDelegate& Delegate);

	// Object: Function FairyGUI.GComponent.NumChildren
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c5f40
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t NumChildren();

	// Object: Function FairyGUI.GComponent.K2_OnConstruct
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(0) Size(0x0) ]
	void K2_OnConstruct();

	// Object: Function FairyGUI.GComponent.IsOpaque
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c5ccc
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsOpaque();

	// Object: Function FairyGUI.GComponent.IsChildInView
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c5ea4
	// Return & Params: [ Num(2) Size(0x9) ]
	bool IsChildInView(struct UGObject* Child);

	// Object: Function FairyGUI.GComponent.IsAncestorOf
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c5f00
	// Return & Params: [ Num(2) Size(0x9) ]
	bool IsAncestorOf(struct UGObject* Obj);

	// Object: Function FairyGUI.GComponent.GetViewWidth
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c5b20
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetViewWidth();

	// Object: Function FairyGUI.GComponent.GetViewHeight
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c5ac4
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetViewHeight();

	// Object: Function FairyGUI.GComponent.GetTransitionAt
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c5cf0
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UTransition* GetTransitionAt(int32_t Index);

	// Object: Function FairyGUI.GComponent.GetTransition
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c5d54
	// Return & Params: [ Num(2) Size(0x18) ]
	struct UTransition* GetTransition(struct FString TransitionName);

	// Object: Function FairyGUI.GComponent.GetScrollPane
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c5b44
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UScrollPane* GetScrollPane();

	// Object: Function FairyGUI.GComponent.GetMargin
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c5c70
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FMargin GetMargin();

	// Object: Function FairyGUI.GComponent.GetFirstChildInView
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c5e80
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetFirstChildInView();

	// Object: Function FairyGUI.GComponent.GetControllerAt
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c5e1c
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UGController* GetControllerAt(int32_t Index);

	// Object: Function FairyGUI.GComponent.GetController
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c5db8
	// Return & Params: [ Num(2) Size(0x18) ]
	struct UGController* GetController(struct FString ControllerName);

	// Object: Function FairyGUI.GComponent.GetChildrenRenderOrder
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c5bf8
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class EChildrenRenderOrder GetChildrenRenderOrder();

	// Object: Function FairyGUI.GComponent.GetChildInGroup
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c61a0
	// Return & Params: [ Num(4) Size(0x28) ]
	struct UGObject* GetChildInGroup(struct UGGroup* Group, struct FString ChildName, struct UGObject* ClassType);

	// Object: Function FairyGUI.GComponent.GetChildIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c6160
	// Return & Params: [ Num(2) Size(0xc) ]
	int32_t GetChildIndex(struct UGObject* Child);

	// Object: Function FairyGUI.GComponent.GetChildByPath
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c627c
	// Return & Params: [ Num(3) Size(0x20) ]
	struct UGObject* GetChildByPath(struct FString Path, struct UGObject* ClassType);

	// Object: Function FairyGUI.GComponent.GetChildAt
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c637c
	// Return & Params: [ Num(3) Size(0x18) ]
	struct UGObject* GetChildAt(int32_t Index, struct UGObject* ClassType);

	// Object: Function FairyGUI.GComponent.GetChild
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c62fc
	// Return & Params: [ Num(3) Size(0x20) ]
	struct UGObject* GetChild(struct FString ChildName, struct UGObject* ClassType);

	// Object: Function FairyGUI.GComponent.GetApexIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c5b94
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetApexIndex();

	// Object: Function FairyGUI.GComponent.EnsureBoundsCorrect
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c5a6c
	// Return & Params: [ Num(0) Size(0x0) ]
	void EnsureBoundsCorrect();

	// Object: Function FairyGUI.GComponent.AddChildAt
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1035c6534
	// Return & Params: [ Num(3) Size(0x18) ]
	struct UGObject* AddChildAt(struct UGObject* Child, int32_t Index);

	// Object: Function FairyGUI.GComponent.AddChild
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c65b0
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UGObject* AddChild(struct UGObject* Child);
};

// Object: Class FairyGUI.GButton
// Inherited Bytes: 0x448 | Struct Size: 0x4f8
struct UGButton : UGComponent {
	// Fields
	struct FMulticastInlineDelegate OnChanged; // Offset: 0x448 | Size: 0x10
	bool bChangeStateOnClick; // Offset: 0x458 | Size: 0x1
	char pad_0x459[0x9f]; // Offset: 0x459 | Size: 0x9f

	// Functions

	// Object: Function FairyGUI.GButton.SetTitleFontSize
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c3e0c
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetTitleFontSize(int32_t InFontSize);

	// Object: Function FairyGUI.GButton.SetTitleColor
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1035c3e80
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetTitleColor(struct FColor& InColor);

	// Object: Function FairyGUI.GButton.SetTitle
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c4058
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetTitle(struct FString InTitle);

	// Object: Function FairyGUI.GButton.SetSelectedTitle
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c3fac
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetSelectedTitle(struct FString InTitle);

	// Object: Function FairyGUI.GButton.SetSelectedIcon
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c3f00
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetSelectedIcon(struct FString InIcon);

	// Object: Function FairyGUI.GButton.SetSelected
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c3d9c
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetSelected(bool bInSelected);

	// Object: Function FairyGUI.GButton.SetRelatedController
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c3d2c
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetRelatedController(struct UGController* InController);

	// Object: Function FairyGUI.GButton.IsSelected
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c3df8
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsSelected();

	// Object: Function FairyGUI.GButton.GetTitleFontSize
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c3e5c
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetTitleFontSize();

	// Object: Function FairyGUI.GButton.GetTitleColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c3edc
	// Return & Params: [ Num(1) Size(0x4) ]
	struct FColor GetTitleColor();

	// Object: Function FairyGUI.GButton.GetTitle
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c40b0
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetTitle();

	// Object: Function FairyGUI.GButton.GetSelectedTitle
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c4008
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetSelectedTitle();

	// Object: Function FairyGUI.GButton.GetSelectedIcon
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c3f5c
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetSelectedIcon();

	// Object: Function FairyGUI.GButton.GetRelatedController
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c3d88
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UGController* GetRelatedController();
};

// Object: Class FairyGUI.GComboBox
// Inherited Bytes: 0x448 | Struct Size: 0x4d0
struct UGComboBox : UGComponent {
	// Fields
	int32_t VisibleItemCount; // Offset: 0x448 | Size: 0x4
	enum class EPopupDirection PopupDirection; // Offset: 0x44c | Size: 0x1
	char pad_0x44D[0x3]; // Offset: 0x44d | Size: 0x3
	struct TArray<struct FString> Items; // Offset: 0x450 | Size: 0x10
	struct TArray<struct FString> Icons; // Offset: 0x460 | Size: 0x10
	struct TArray<struct FString> Values; // Offset: 0x470 | Size: 0x10
	struct FMulticastInlineDelegate OnChanged; // Offset: 0x480 | Size: 0x10
	struct UGComponent* DropdownObject; // Offset: 0x490 | Size: 0x8
	char pad_0x498[0x38]; // Offset: 0x498 | Size: 0x38

	// Functions

	// Object: Function FairyGUI.GComboBox.SetValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c4550
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetValue(struct FString InValue);

	// Object: Function FairyGUI.GComboBox.SetTitleFontSize
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c45f4
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetTitleFontSize(int32_t InFontSize);

	// Object: Function FairyGUI.GComboBox.SetTitleColor
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1035c4668
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetTitleColor(struct FColor& InColor);

	// Object: Function FairyGUI.GComboBox.SetTitle
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c46e8
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetTitle(struct FString InTitle);

	// Object: Function FairyGUI.GComboBox.SetSelectionController
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c447c
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetSelectionController(struct UGController* InController);

	// Object: Function FairyGUI.GComboBox.SetSelectedIndex
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c44ec
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetSelectedIndex(int32_t InIndex);

	// Object: Function FairyGUI.GComboBox.Refresh
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c4458
	// Return & Params: [ Num(0) Size(0x0) ]
	void Refresh();

	// Object: Function FairyGUI.GComboBox.GetValue
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c45ac
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetValue();

	// Object: Function FairyGUI.GComboBox.GetTitleFontSize
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c4644
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetTitleFontSize();

	// Object: Function FairyGUI.GComboBox.GetTitleColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c46c4
	// Return & Params: [ Num(1) Size(0x4) ]
	struct FColor GetTitleColor();

	// Object: Function FairyGUI.GComboBox.GetTitle
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c4740
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetTitle();

	// Object: Function FairyGUI.GComboBox.GetSelectionController
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c44d8
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UGController* GetSelectionController();

	// Object: Function FairyGUI.GComboBox.GetSelectedIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c453c
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetSelectedIndex();

	// Object: Function FairyGUI.GComboBox.GetDropdown
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c4468
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UGObject* GetDropdown();
};

// Object: Class FairyGUI.GController
// Inherited Bytes: 0x28 | Struct Size: 0x90
struct UGController : UObject {
	// Fields
	char pad_0x28[0x68]; // Offset: 0x28 | Size: 0x68

	// Functions

	// Object: Function FairyGUI.GController.SetSelectedPage
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c6ef4
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetSelectedPage(struct FString PageName);

	// Object: Function FairyGUI.GController.SetSelectedIndex
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c6fa8
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetSelectedIndex(int32_t Index);

	// Object: Function FairyGUI.GController.GetSelectedPage
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c6f60
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetSelectedPage();

	// Object: Function FairyGUI.GController.GetSelectedIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c6fe0
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetSelectedIndex();
};

// Object: Class FairyGUI.GGraph
// Inherited Bytes: 0x340 | Struct Size: 0x350
struct UGGraph : UGObject {
	// Fields
	char pad_0x340[0x10]; // Offset: 0x340 | Size: 0x10

	// Functions

	// Object: Function FairyGUI.GGraph.SetColor
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1035c7738
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetColor(struct FColor& InColor);

	// Object: Function FairyGUI.GGraph.IsEmpty
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c7108
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsEmpty();

	// Object: Function FairyGUI.GGraph.GetColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c778c
	// Return & Params: [ Num(1) Size(0x4) ]
	struct FColor GetColor();

	// Object: Function FairyGUI.GGraph.DrawRoundRect
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1035c7508
	// Return & Params: [ Num(7) Size(0x1c) ]
	void DrawRoundRect(float LineWidth, struct FColor& LineColor, struct FColor& FillColor, float TopLeftRadius, float TopRightRadius, float BottomLeftRadius, float BottomRightRadius);

	// Object: Function FairyGUI.GGraph.DrawRegularPolygon
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1035c713c
	// Return & Params: [ Num(6) Size(0x28) ]
	void DrawRegularPolygon(int32_t Sides, float LineWidth, struct FColor& LineColor, struct FColor& FillColor, float Rotation, struct TArray<float>& Distances);

	// Object: Function FairyGUI.GGraph.DrawRect
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1035c768c
	// Return & Params: [ Num(3) Size(0xc) ]
	void DrawRect(float LineWidth, struct FColor& LineColor, struct FColor& FillColor);

	// Object: Function FairyGUI.GGraph.DrawPolygon
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1035c72cc
	// Return & Params: [ Num(4) Size(0x20) ]
	void DrawPolygon(float LineWidth, struct FColor& LineColor, struct FColor& FillColor, struct TArray<struct FVector2D>& Points);

	// Object: Function FairyGUI.GGraph.DrawEllipse
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1035c73f0
	// Return & Params: [ Num(5) Size(0x14) ]
	void DrawEllipse(float LineWidth, struct FColor& LineColor, struct FColor& FillColor, float StartDegree, float EndDegree);

	// Object: Function FairyGUI.GGraph.Clear
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c712c
	// Return & Params: [ Num(0) Size(0x0) ]
	void Clear();
};

// Object: Class FairyGUI.GGroup
// Inherited Bytes: 0x340 | Struct Size: 0x370
struct UGGroup : UGObject {
	// Fields
	char pad_0x340[0x30]; // Offset: 0x340 | Size: 0x30

	// Functions

	// Object: Function FairyGUI.GGroup.SetMainGridMinSize
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c7a38
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetMainGridMinSize(int32_t InSize);

	// Object: Function FairyGUI.GGroup.SetMainGridIndex
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c7a84
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetMainGridIndex(int32_t InIndex);

	// Object: Function FairyGUI.GGroup.SetLineGap
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c7b80
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetLineGap(int32_t InLineGap);

	// Object: Function FairyGUI.GGroup.SetLayout
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c7c18
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetLayout(enum class EGroupLayoutType InLayout);

	// Object: Function FairyGUI.GGroup.SetExcludeInvisibles
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c7b28
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetExcludeInvisibles(bool bInFlag);

	// Object: Function FairyGUI.GGroup.SetColumnGap
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c7bcc
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetColumnGap(int32_t InColumnGap);

	// Object: Function FairyGUI.GGroup.SetBoundsChangedFlag
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c79f4
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetBoundsChangedFlag(bool bPositionChangedOnly);

	// Object: Function FairyGUI.GGroup.SetAutoSizeDisabled
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c7ad0
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetAutoSizeDisabled(bool bInFlag);

	// Object: Function FairyGUI.GGroup.IsExcludeInvisibles
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c7b6c
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsExcludeInvisibles();

	// Object: Function FairyGUI.GGroup.IsAutoSizeDisabled
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c7b14
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsAutoSizeDisabled();

	// Object: Function FairyGUI.GGroup.GetMainGridMinSize
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c7a70
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetMainGridMinSize();

	// Object: Function FairyGUI.GGroup.GetMainGridIndex
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c7abc
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetMainGridIndex();

	// Object: Function FairyGUI.GGroup.GetLineGap
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c7bb8
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetLineGap();

	// Object: Function FairyGUI.GGroup.GetLayout
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c7c68
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class EGroupLayoutType GetLayout();

	// Object: Function FairyGUI.GGroup.GetColumnGap
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c7c04
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetColumnGap();

	// Object: Function FairyGUI.GGroup.EnsureBoundsCorrect
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c79e4
	// Return & Params: [ Num(0) Size(0x0) ]
	void EnsureBoundsCorrect();
};

// Object: Class FairyGUI.GImage
// Inherited Bytes: 0x340 | Struct Size: 0x350
struct UGImage : UGObject {
	// Fields
	char pad_0x340[0x10]; // Offset: 0x340 | Size: 0x10

	// Functions

	// Object: Function FairyGUI.GImage.SetFlip
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c8250
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetFlip(enum class EFlipType InFlip);

	// Object: Function FairyGUI.GImage.SetFillOrigin
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c8108
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetFillOrigin(int32_t Origin);

	// Object: Function FairyGUI.GImage.SetFillMethod
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c8164
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetFillMethod(enum class EFillMethod Method);

	// Object: Function FairyGUI.GImage.SetFillClockwise
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c80a0
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetFillClockwise(bool bClockwise);

	// Object: Function FairyGUI.GImage.SetFillAmount
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c8044
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetFillAmount(float amount);

	// Object: Function FairyGUI.GImage.SetColor
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1035c81d8
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetColor(struct FColor& InColor);

	// Object: Function FairyGUI.GImage.IsFillClockwise
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c80e4
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsFillClockwise();

	// Object: Function FairyGUI.GImage.GetFlip
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c82a0
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class EFlipType GetFlip();

	// Object: Function FairyGUI.GImage.GetFillOrigin
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c8140
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetFillOrigin();

	// Object: Function FairyGUI.GImage.GetFillMethod
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c81b4
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class EFillMethod GetFillMethod();

	// Object: Function FairyGUI.GImage.GetFillAmount
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c807c
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetFillAmount();

	// Object: Function FairyGUI.GImage.GetColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c822c
	// Return & Params: [ Num(1) Size(0x4) ]
	struct FColor GetColor();
};

// Object: Class FairyGUI.GLabel
// Inherited Bytes: 0x448 | Struct Size: 0x458
struct UGLabel : UGComponent {
	// Fields
	char pad_0x448[0x10]; // Offset: 0x448 | Size: 0x10

	// Functions

	// Object: Function FairyGUI.GLabel.SetTitleFontSize
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c85a0
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetTitleFontSize(int32_t Value);

	// Object: Function FairyGUI.GLabel.SetTitleColor
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1035c85fc
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetTitleColor(struct FColor& InColor);

	// Object: Function FairyGUI.GLabel.SetTitle
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c8674
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetTitle(struct FString InTitle);

	// Object: Function FairyGUI.GLabel.GetTitleFontSize
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c85d8
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetTitleFontSize();

	// Object: Function FairyGUI.GLabel.GetTitleColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c8650
	// Return & Params: [ Num(1) Size(0x4) ]
	struct FColor GetTitleColor();

	// Object: Function FairyGUI.GLabel.GetTitle
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c86dc
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetTitle();
};

// Object: Class FairyGUI.GList
// Inherited Bytes: 0x448 | Struct Size: 0x500
struct UGList : UGComponent {
	// Fields
	struct FMulticastInlineDelegate OnClickItem; // Offset: 0x448 | Size: 0x10
	bool bScrollItemToViewOnClick; // Offset: 0x458 | Size: 0x1
	bool bFoldInvisibleItems; // Offset: 0x459 | Size: 0x1
	char pad_0x45A[0xa6]; // Offset: 0x45a | Size: 0xa6

	// Functions

	// Object: Function FairyGUI.GList.SetVirtualAndLoop
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c8e00
	// Return & Params: [ Num(0) Size(0x0) ]
	void SetVirtualAndLoop();

	// Object: Function FairyGUI.GList.SetVirtual
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c8e10
	// Return & Params: [ Num(0) Size(0x0) ]
	void SetVirtual();

	// Object: Function FairyGUI.GList.SetVerticalAlign
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c92fc
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetVerticalAlign(enum class EVerticalAlignType InVerticalAlign);

	// Object: Function FairyGUI.GList.SetSelectionMode
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c923c
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetSelectionMode(enum class EListSelectionMode InMode);

	// Object: Function FairyGUI.GList.SetSelectionController
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c8e20
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetSelectionController(struct UGController* InController);

	// Object: Function FairyGUI.GList.SetSelectedIndex
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c908c
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetSelectedIndex(int32_t Index);

	// Object: Function FairyGUI.GList.SetNumItems
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c8d80
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetNumItems(int32_t InNumItems);

	// Object: Function FairyGUI.GList.SetLineGap
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c93c4
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetLineGap(int32_t InLineGap);

	// Object: Function FairyGUI.GList.SetLineCount
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c94a8
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetLineCount(int32_t InLineCount);

	// Object: Function FairyGUI.GList.SetLayout
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c94f4
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetLayout(enum class EListLayoutType InLayout);

	// Object: Function FairyGUI.GList.SetItemRenderer
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1035c8ad0
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetItemRenderer(struct FDelegate& InItemRenderer);

	// Object: Function FairyGUI.GList.SetItemProvider
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1035c88f8
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetItemProvider(struct FDelegate& InItemProvider);

	// Object: Function FairyGUI.GList.SetDefaultItem
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c9558
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetDefaultItem(struct FString InDefaultItem);

	// Object: Function FairyGUI.GList.SetColumnGap
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c9410
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetColumnGap(int32_t InColumnGap);

	// Object: Function FairyGUI.GList.SetColumnCount
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c945c
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetColumnCount(int32_t InColumnCount);

	// Object: Function FairyGUI.GList.SetAutoResizeItem
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c92a4
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetAutoResizeItem(bool bFlag);

	// Object: Function FairyGUI.GList.SetAlign
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c9360
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetAlign(enum class EAlignType InAlign);

	// Object: Function FairyGUI.GList.SelectReverse
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c8fac
	// Return & Params: [ Num(0) Size(0x0) ]
	void SelectReverse();

	// Object: Function FairyGUI.GList.SelectAll
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c8fbc
	// Return & Params: [ Num(0) Size(0x0) ]
	void SelectAll();

	// Object: Function FairyGUI.GList.ScrollToView
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c8e88
	// Return & Params: [ Num(3) Size(0x6) ]
	void ScrollToView(int32_t Index, bool bAnimation, bool bSetFirst);

	// Object: Function FairyGUI.GList.ResizeToFit
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c8f44
	// Return & Params: [ Num(2) Size(0x8) ]
	void ResizeToFit(int32_t ItemCount, int32_t InMinSize);

	// Object: Function FairyGUI.GList.RemoveSelection
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c8fdc
	// Return & Params: [ Num(1) Size(0x4) ]
	void RemoveSelection(int32_t Index);

	// Object: Function FairyGUI.GList.RemoveChildToPoolAt
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c91a0
	// Return & Params: [ Num(1) Size(0x4) ]
	void RemoveChildToPoolAt(int32_t Index);

	// Object: Function FairyGUI.GList.RemoveChildToPool
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c9150
	// Return & Params: [ Num(1) Size(0x8) ]
	void RemoveChildToPool(struct UGObject* Child);

	// Object: Function FairyGUI.GList.RemoveChildrenToPool
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c90e8
	// Return & Params: [ Num(2) Size(0x8) ]
	void RemoveChildrenToPool(int32_t BeginIndex, int32_t EndIndex);

	// Object: Function FairyGUI.GList.RefreshVirtualList
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c8ddc
	// Return & Params: [ Num(0) Size(0x0) ]
	void RefreshVirtualList();

	// Object: Function FairyGUI.GList.OnClickItemHandler
	// Flags: [Final|Native|Private]
	// Offset: 0x1035c88a8
	// Return & Params: [ Num(1) Size(0x8) ]
	void OnClickItemHandler(struct UEventContext* Context);

	// Object: Function FairyGUI.GList.ItemIndexToChildIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c8cb8
	// Return & Params: [ Num(2) Size(0x8) ]
	int32_t ItemIndexToChildIndex(int32_t Index);

	// Object: Function FairyGUI.GList.IsVirtual
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c8dec
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsVirtual();

	// Object: Function FairyGUI.GList.GetVerticalAlign
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c934c
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class EVerticalAlignType GetVerticalAlign();

	// Object: Function FairyGUI.GList.GetSelectionMode
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c9290
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class EListSelectionMode GetSelectionMode();

	// Object: Function FairyGUI.GList.GetSelectionController
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c8e70
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UGController* GetSelectionController();

	// Object: Function FairyGUI.GList.GetSelectedIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c90c4
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetSelectedIndex();

	// Object: Function FairyGUI.GList.GetNumItems
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c8db8
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetNumItems();

	// Object: Function FairyGUI.GList.GetLineGap
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c93fc
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetLineGap();

	// Object: Function FairyGUI.GList.GetLineCount
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c94e0
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetLineCount();

	// Object: Function FairyGUI.GList.GetLayout
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c9544
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class EListLayoutType GetLayout();

	// Object: Function FairyGUI.GList.GetDefaultItem
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c95c4
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetDefaultItem();

	// Object: Function FairyGUI.GList.GetColumnGap
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c9448
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetColumnGap();

	// Object: Function FairyGUI.GList.GetColumnCount
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c9494
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetColumnCount();

	// Object: Function FairyGUI.GList.GetAutoResizeItem
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c92e8
	// Return & Params: [ Num(1) Size(0x1) ]
	bool GetAutoResizeItem();

	// Object: Function FairyGUI.GList.GetAlign
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c93b0
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class EAlignType GetAlign();

	// Object: Function FairyGUI.GList.ClearSelection
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c8fcc
	// Return & Params: [ Num(0) Size(0x0) ]
	void ClearSelection();

	// Object: Function FairyGUI.GList.ChildIndexToItemIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035c8d1c
	// Return & Params: [ Num(2) Size(0x8) ]
	int32_t ChildIndexToItemIndex(int32_t Index);

	// Object: Function FairyGUI.GList.AddSelection
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c9014
	// Return & Params: [ Num(2) Size(0x5) ]
	void AddSelection(int32_t Index, bool bScrollItToView);

	// Object: Function FairyGUI.GList.AddItemFromPool
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035c91d8
	// Return & Params: [ Num(2) Size(0x18) ]
	struct UGObject* AddItemFromPool(struct FString URL);
};

// Object: Class FairyGUI.GLoader
// Inherited Bytes: 0x340 | Struct Size: 0x3a0
struct UGLoader : UGObject {
	// Fields
	char pad_0x340[0x30]; // Offset: 0x340 | Size: 0x30
	struct UGObject* Content2; // Offset: 0x370 | Size: 0x8
	char pad_0x378[0x28]; // Offset: 0x378 | Size: 0x28

	// Functions

	// Object: Function FairyGUI.GLoader.SetVerticalAlign
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035cb674
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetVerticalAlign(enum class EVerticalAlignType InVerticalAlign);

	// Object: Function FairyGUI.GLoader.SetURL
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035cb73c
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetURL(struct FString InUrl);

	// Object: Function FairyGUI.GLoader.SetShrinkOnly
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035cb550
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetShrinkOnly(bool bInShrinkOnly);

	// Object: Function FairyGUI.GLoader.SetPlaying
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035cb278
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetPlaying(bool bInPlaying);

	// Object: Function FairyGUI.GLoader.SetFrame
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035cb21c
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetFrame(int32_t InFrame);

	// Object: Function FairyGUI.GLoader.SetFlip
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035cb4dc
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetFlip(enum class EFlipType InFlip);

	// Object: Function FairyGUI.GLoader.SetFillOrigin
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035cb3a4
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetFillOrigin(int32_t Origin);

	// Object: Function FairyGUI.GLoader.SetFillMethod
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035cb400
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetFillMethod(enum class EFillMethod Method);

	// Object: Function FairyGUI.GLoader.SetFillClockwise
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035cb33c
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetFillClockwise(bool bClockwise);

	// Object: Function FairyGUI.GLoader.SetFillAmount
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035cb2e0
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetFillAmount(float amount);

	// Object: Function FairyGUI.GLoader.SetFill
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035cb5b0
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetFill(enum class ELoaderFillType InFillType);

	// Object: Function FairyGUI.GLoader.SetColor
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1035cb474
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetColor(struct FColor& InColor);

	// Object: Function FairyGUI.GLoader.SetAutoSize
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035cb614
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetAutoSize(bool bInAutoSize);

	// Object: Function FairyGUI.GLoader.SetAlign
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035cb6d8
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetAlign(enum class EAlignType InAlign);

	// Object: Function FairyGUI.GLoader.IsShrinkOnly
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035cb594
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsShrinkOnly();

	// Object: Function FairyGUI.GLoader.IsPlaying
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035cb2bc
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsPlaying();

	// Object: Function FairyGUI.GLoader.IsFillClockwise
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035cb380
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsFillClockwise();

	// Object: Function FairyGUI.GLoader.GetVerticalAlign
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035cb6c4
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class EVerticalAlignType GetVerticalAlign();

	// Object: Function FairyGUI.GLoader.GetUrl
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035cb798
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetUrl();

	// Object: Function FairyGUI.GLoader.GetFrame
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035cb254
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetFrame();

	// Object: Function FairyGUI.GLoader.GetFlip
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035cb52c
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class EFlipType GetFlip();

	// Object: Function FairyGUI.GLoader.GetFillOrigin
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035cb3dc
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetFillOrigin();

	// Object: Function FairyGUI.GLoader.GetFillMethod
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035cb450
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class EFillMethod GetFillMethod();

	// Object: Function FairyGUI.GLoader.GetFillAmount
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035cb318
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetFillAmount();

	// Object: Function FairyGUI.GLoader.GetFill
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035cb600
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class ELoaderFillType GetFill();

	// Object: Function FairyGUI.GLoader.GetColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035cb4b8
	// Return & Params: [ Num(1) Size(0x4) ]
	struct FColor GetColor();

	// Object: Function FairyGUI.GLoader.GetAutoSize
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035cb658
	// Return & Params: [ Num(1) Size(0x1) ]
	bool GetAutoSize();

	// Object: Function FairyGUI.GLoader.GetAlign
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035cb728
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class EAlignType GetAlign();
};

// Object: Class FairyGUI.GLoader3D
// Inherited Bytes: 0x340 | Struct Size: 0x378
struct UGLoader3D : UGObject {
	// Fields
	char pad_0x340[0x38]; // Offset: 0x340 | Size: 0x38

	// Functions

	// Object: Function FairyGUI.GLoader3D.SetURL
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035cbec8
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetURL(struct FString InUrl);

	// Object: Function FairyGUI.GLoader3D.SetColor
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1035cbe60
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetColor(struct FColor& InColor);

	// Object: Function FairyGUI.GLoader3D.GetUrl
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035cbf24
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetUrl();

	// Object: Function FairyGUI.GLoader3D.GetColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035cbea4
	// Return & Params: [ Num(1) Size(0x4) ]
	struct FColor GetColor();
};

// Object: Class FairyGUI.GMovieClip
// Inherited Bytes: 0x340 | Struct Size: 0x350
struct UGMovieClip : UGObject {
	// Fields
	char pad_0x340[0x10]; // Offset: 0x340 | Size: 0x10

	// Functions

	// Object: Function FairyGUI.GMovieClip.SetTimeScale
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035cc41c
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetTimeScale(float InTimeScale);

	// Object: Function FairyGUI.GMovieClip.SetPlaySettings
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1035cc08c
	// Return & Params: [ Num(5) Size(0x20) ]
	void SetPlaySettings(struct FDelegate& InCompleteCallback, int32_t InStart, int32_t InEnd, int32_t InTimes, int32_t InEndAt);

	// Object: Function FairyGUI.GMovieClip.SetPlaying
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035cc4d4
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetPlaying(bool bInPlaying);

	// Object: Function FairyGUI.GMovieClip.SetFrame
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035cc478
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetFrame(int32_t InFrame);

	// Object: Function FairyGUI.GMovieClip.SetFlip
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035cc370
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetFlip(enum class EFlipType InFlip);

	// Object: Function FairyGUI.GMovieClip.SetColor
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1035cc308
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetColor(struct FColor& InColor);

	// Object: Function FairyGUI.GMovieClip.IsPlaying
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035cc518
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsPlaying();

	// Object: Function FairyGUI.GMovieClip.GetTimeScale
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035cc454
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetTimeScale();

	// Object: Function FairyGUI.GMovieClip.GetFrame
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035cc4b0
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetFrame();

	// Object: Function FairyGUI.GMovieClip.GetFlip
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035cc3c0
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class EFlipType GetFlip();

	// Object: Function FairyGUI.GMovieClip.GetColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035cc34c
	// Return & Params: [ Num(1) Size(0x4) ]
	struct FColor GetColor();

	// Object: Function FairyGUI.GMovieClip.Advance
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035cc3e4
	// Return & Params: [ Num(1) Size(0x4) ]
	void Advance(float Time);
};

// Object: Class FairyGUI.GProgressBar
// Inherited Bytes: 0x448 | Struct Size: 0x490
struct UGProgressBar : UGComponent {
	// Fields
	char pad_0x448[0x48]; // Offset: 0x448 | Size: 0x48

	// Functions

	// Object: Function FairyGUI.GProgressBar.TweenValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035cf754
	// Return & Params: [ Num(2) Size(0x8) ]
	void TweenValue(float InValue, float Duration);

	// Object: Function FairyGUI.GProgressBar.SetValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035cf7b8
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetValue(float InValue);

	// Object: Function FairyGUI.GProgressBar.SetTitleType
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035cf8b4
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetTitleType(enum class EProgressTitleType InType);

	// Object: Function FairyGUI.GProgressBar.SetMin
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035cf860
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetMin(float InMin);

	// Object: Function FairyGUI.GProgressBar.SetMax
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035cf80c
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetMax(float InMax);

	// Object: Function FairyGUI.GProgressBar.GetValue
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035cf7f8
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetValue();

	// Object: Function FairyGUI.GProgressBar.GetTitleType
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035cf904
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class EProgressTitleType GetTitleType();

	// Object: Function FairyGUI.GProgressBar.GetMin
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035cf8a0
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetMin();

	// Object: Function FairyGUI.GProgressBar.GetMax
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035cf84c
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetMax();
};

// Object: Class FairyGUI.GTextField
// Inherited Bytes: 0x340 | Struct Size: 0x3c0
struct UGTextField : UGObject {
	// Fields
	char pad_0x340[0x80]; // Offset: 0x340 | Size: 0x80

	// Functions

	// Object: Function FairyGUI.GTextField.SetVar
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d079c
	// Return & Params: [ Num(3) Size(0x28) ]
	struct UGTextField* SetVar(struct FString VarKey, struct FString VarValue);

	// Object: Function FairyGUI.GTextField.SetUBBEnabled
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1035d0a60
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetUBBEnabled(bool InEnabled);

	// Object: Function FairyGUI.GTextField.SetTextFormat
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1035d088c
	// Return & Params: [ Num(1) Size(0x40) ]
	void SetTextFormat(struct FNTextFormat& InTextFormat);

	// Object: Function FairyGUI.GTextField.SetSingleLine
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1035d096c
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetSingleLine(bool InSingleLine);

	// Object: Function FairyGUI.GTextField.SetAutoSize
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1035d09d4
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetAutoSize(enum class EAutoSizeType InAutoSize);

	// Object: Function FairyGUI.GTextField.IsUBBEnabled
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035d0aa4
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsUBBEnabled();

	// Object: Function FairyGUI.GTextField.IsSingleLine
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035d09b0
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsSingleLine();

	// Object: Function FairyGUI.GTextField.GetTextSize
	// Flags: [Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x1035d0858
	// Return & Params: [ Num(1) Size(0x8) ]
	struct FVector2D GetTextSize();

	// Object: Function FairyGUI.GTextField.GetTextFormat
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1035d08f0
	// Return & Params: [ Num(1) Size(0x40) ]
	struct FNTextFormat GetTextFormat();

	// Object: Function FairyGUI.GTextField.GetAutoSize
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035d0a3c
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class EAutoSizeType GetAutoSize();

	// Object: Function FairyGUI.GTextField.FlushVars
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d078c
	// Return & Params: [ Num(0) Size(0x0) ]
	void FlushVars();

	// Object: Function FairyGUI.GTextField.ApplyFormat
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d087c
	// Return & Params: [ Num(0) Size(0x0) ]
	void ApplyFormat();
};

// Object: Class FairyGUI.GRichTextField
// Inherited Bytes: 0x3c0 | Struct Size: 0x3d0
struct UGRichTextField : UGTextField {
	// Fields
	struct FMulticastInlineDelegate OnClickLink; // Offset: 0x3c0 | Size: 0x10
};

// Object: Class FairyGUI.GRoot
// Inherited Bytes: 0x448 | Struct Size: 0x490
struct UGRoot : UGComponent {
	// Fields
	struct UGGraph* ModalLayer; // Offset: 0x448 | Size: 0x8
	struct UGObject* ModalWaitPane; // Offset: 0x450 | Size: 0x8
	struct UGObject* TooltipWin; // Offset: 0x458 | Size: 0x8
	struct UGObject* DefaultTooltipWin; // Offset: 0x460 | Size: 0x8
	char pad_0x468[0x28]; // Offset: 0x468 | Size: 0x28

	// Functions

	// Object: Function FairyGUI.GRoot.TogglePopup
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035cfc98
	// Return & Params: [ Num(3) Size(0x11) ]
	void TogglePopup(struct UGObject* PopUp, struct UGObject* AtObject, enum class EPopupDirection Direction);

	// Object: Function FairyGUI.GRoot.ShowTooltipsWin
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035cfba8
	// Return & Params: [ Num(1) Size(0x8) ]
	void ShowTooltipsWin(struct UGObject* InTooltipWin);

	// Object: Function FairyGUI.GRoot.ShowTooltips
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035cfbe0
	// Return & Params: [ Num(1) Size(0x10) ]
	void ShowTooltips(struct FString Text);

	// Object: Function FairyGUI.GRoot.ShowPopup
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035cfd54
	// Return & Params: [ Num(3) Size(0x11) ]
	void ShowPopup(struct UGObject* PopUp, struct UGObject* AtObject, enum class EPopupDirection Direction);

	// Object: Function FairyGUI.GRoot.ShowModalWait
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035cfeac
	// Return & Params: [ Num(0) Size(0x0) ]
	void ShowModalWait();

	// Object: Function FairyGUI.GRoot.IsModalWaiting
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035cfe10
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsModalWaiting();

	// Object: Function FairyGUI.GRoot.HideTooltips
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035cfb98
	// Return & Params: [ Num(0) Size(0x0) ]
	void HideTooltips();

	// Object: Function FairyGUI.GRoot.HidePopup
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035cfc60
	// Return & Params: [ Num(1) Size(0x8) ]
	void HidePopup(struct UGObject* PopUp);

	// Object: Function FairyGUI.GRoot.HasModalWindow
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035cfe34
	// Return & Params: [ Num(1) Size(0x1) ]
	bool HasModalWindow();

	// Object: Function FairyGUI.GRoot.HasAnyPopup
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035cfc3c
	// Return & Params: [ Num(1) Size(0x1) ]
	bool HasAnyPopup();

	// Object: Function FairyGUI.GRoot.GetTopWindow
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035cfe58
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UGWindow* GetTopWindow();

	// Object: Function FairyGUI.GRoot.Get
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1035cfef4
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UGRoot* Get(struct UObject* WorldContextObject);

	// Object: Function FairyGUI.GRoot.CloseModalWait
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035cfe9c
	// Return & Params: [ Num(0) Size(0x0) ]
	void CloseModalWait();

	// Object: Function FairyGUI.GRoot.CloseAllWindows
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035cfe7c
	// Return & Params: [ Num(0) Size(0x0) ]
	void CloseAllWindows();

	// Object: Function FairyGUI.GRoot.CloseAllExceptModals
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035cfe8c
	// Return & Params: [ Num(0) Size(0x0) ]
	void CloseAllExceptModals();

	// Object: Function FairyGUI.GRoot.BringToFront
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035cfebc
	// Return & Params: [ Num(1) Size(0x8) ]
	void BringToFront(struct UGWindow* Window);
};

// Object: Class FairyGUI.GScrollBar
// Inherited Bytes: 0x448 | Struct Size: 0x490
struct UGScrollBar : UGComponent {
	// Fields
	char pad_0x448[0x48]; // Offset: 0x448 | Size: 0x48
};

// Object: Class FairyGUI.GSlider
// Inherited Bytes: 0x448 | Struct Size: 0x4b8
struct UGSlider : UGComponent {
	// Fields
	bool bChangeOnClick; // Offset: 0x448 | Size: 0x1
	bool bCanDrag; // Offset: 0x449 | Size: 0x1
	char pad_0x44A[0x6]; // Offset: 0x44a | Size: 0x6
	struct FMulticastInlineDelegate OnChanged; // Offset: 0x450 | Size: 0x10
	char pad_0x460[0x58]; // Offset: 0x460 | Size: 0x58

	// Functions

	// Object: Function FairyGUI.GSlider.SetWholeNumbers
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d0350
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetWholeNumbers(bool bWholeNumbers);

	// Object: Function FairyGUI.GSlider.SetValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d03b0
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetValue(float InValue);

	// Object: Function FairyGUI.GSlider.SetTitleType
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d04ac
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetTitleType(enum class EProgressTitleType InTitleType);

	// Object: Function FairyGUI.GSlider.SetMin
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d0458
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetMin(float InMin);

	// Object: Function FairyGUI.GSlider.SetMax
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d0404
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetMax(float InMax);

	// Object: Function FairyGUI.GSlider.GetWholeNumbers
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035d039c
	// Return & Params: [ Num(1) Size(0x1) ]
	bool GetWholeNumbers();

	// Object: Function FairyGUI.GSlider.GetValue
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035d03f0
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetValue();

	// Object: Function FairyGUI.GSlider.GetTitleType
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035d04fc
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class EProgressTitleType GetTitleType();

	// Object: Function FairyGUI.GSlider.GetMin
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035d0498
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetMin();

	// Object: Function FairyGUI.GSlider.GetMax
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035d0444
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetMax();
};

// Object: Class FairyGUI.GTextInput
// Inherited Bytes: 0x340 | Struct Size: 0x3b8
struct UGTextInput : UGObject {
	// Fields
	struct FMulticastInlineDelegate OnSubmit; // Offset: 0x340 | Size: 0x10
	char pad_0x350[0x68]; // Offset: 0x350 | Size: 0x68

	// Functions

	// Object: Function FairyGUI.GTextInput.SetTextFormat
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1035d0f30
	// Return & Params: [ Num(1) Size(0x40) ]
	void SetTextFormat(struct FNTextFormat& InTextFormat);

	// Object: Function FairyGUI.GTextInput.SetSingleLine
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d0ff4
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetSingleLine(bool InSingleLine);

	// Object: Function FairyGUI.GTextInput.SetRestrict
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d0d9c
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetRestrict(struct FString InRestrict);

	// Object: Function FairyGUI.GTextInput.SetPrompt
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d0ec4
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetPrompt(struct FString InPrompt);

	// Object: Function FairyGUI.GTextInput.SetPassword
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d0e78
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetPassword(bool bInPassword);

	// Object: Function FairyGUI.GTextInput.SetMaxLength
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d0df8
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetMaxLength(int32_t InMaxLength);

	// Object: Function FairyGUI.GTextInput.SetKeyboardType
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d0e38
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetKeyboardType(int32_t InKeyboardType);

	// Object: Function FairyGUI.GTextInput.IsSingleLine
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035d1040
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsSingleLine();

	// Object: Function FairyGUI.GTextInput.GetTextFormat
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1035d0f94
	// Return & Params: [ Num(1) Size(0x40) ]
	struct FNTextFormat GetTextFormat();

	// Object: Function FairyGUI.GTextInput.ApplyFormat
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d0f20
	// Return & Params: [ Num(0) Size(0x0) ]
	void ApplyFormat();
};

// Object: Class FairyGUI.GTree
// Inherited Bytes: 0x500 | Struct Size: 0x538
struct UGTree : UGList {
	// Fields
	int32_t Indent; // Offset: 0x500 | Size: 0x4
	int32_t ClickToExpand; // Offset: 0x504 | Size: 0x4
	struct UGTreeNode* RootNode; // Offset: 0x508 | Size: 0x8
	char pad_0x510[0x28]; // Offset: 0x510 | Size: 0x28

	// Functions

	// Object: Function FairyGUI.GTree.UnselectNode
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d1768
	// Return & Params: [ Num(1) Size(0x8) ]
	void UnselectNode(struct UGTreeNode* Node);

	// Object: Function FairyGUI.GTree.SetTreeNodeRenderer
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1035d1504
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetTreeNodeRenderer(struct FDelegate& InDelegate);

	// Object: Function FairyGUI.GTree.SetOnTreeNodeWillExpand
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1035d1310
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetOnTreeNodeWillExpand(struct FDelegate& InDelegate);

	// Object: Function FairyGUI.GTree.SelectNode
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d17a0
	// Return & Params: [ Num(2) Size(0x9) ]
	void SelectNode(struct UGTreeNode* Node, bool bScrollItToView);

	// Object: Function FairyGUI.GTree.OnCellTouchBegin
	// Flags: [Final|Native|Private]
	// Offset: 0x1035d12d8
	// Return & Params: [ Num(1) Size(0x8) ]
	void OnCellTouchBegin(struct UEventContext* Context);

	// Object: Function FairyGUI.GTree.GetSelectedNodes
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035d1818
	// Return & Params: [ Num(1) Size(0x10) ]
	void GetSelectedNodes(struct TArray<struct UGTreeNode*>& Result);

	// Object: Function FairyGUI.GTree.GetSelectedNode
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035d1888
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UGTreeNode* GetSelectedNode();

	// Object: Function FairyGUI.GTree.GetRootNode
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035d18ac
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UGTreeNode* GetRootNode();

	// Object: Function FairyGUI.GTree.ExpandAll
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d1730
	// Return & Params: [ Num(1) Size(0x8) ]
	void ExpandAll(struct UGTreeNode* Node);

	// Object: Function FairyGUI.GTree.CollapseAll
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d16f8
	// Return & Params: [ Num(1) Size(0x8) ]
	void CollapseAll(struct UGTreeNode* Node);
};

// Object: Class FairyGUI.GTreeNode
// Inherited Bytes: 0x28 | Struct Size: 0x80
struct UGTreeNode : UObject {
	// Fields
	struct FNVariant UserData; // Offset: 0x28 | Size: 0x18
	char pad_0x40[0x10]; // Offset: 0x40 | Size: 0x10
	struct UGComponent* Cell; // Offset: 0x50 | Size: 0x8
	struct TArray<struct UGTreeNode*> Children; // Offset: 0x58 | Size: 0x10
	char pad_0x68[0x18]; // Offset: 0x68 | Size: 0x18

	// Functions

	// Object: Function FairyGUI.GTreeNode.SwapChildrenAt
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d1b50
	// Return & Params: [ Num(2) Size(0x8) ]
	void SwapChildrenAt(int32_t Index1, int32_t Index2);

	// Object: Function FairyGUI.GTreeNode.SwapChildren
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d1bac
	// Return & Params: [ Num(2) Size(0x10) ]
	void SwapChildren(struct UGTreeNode* Child, struct UGTreeNode* Child2);

	// Object: Function FairyGUI.GTreeNode.SetText
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d2004
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetText(struct FString InText);

	// Object: Function FairyGUI.GTreeNode.SetParent
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d2160
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetParent(struct UGTreeNode* InParent);

	// Object: Function FairyGUI.GTreeNode.SetIcon
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d1f58
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetIcon(struct FString InIcon);

	// Object: Function FairyGUI.GTreeNode.SetExpaned
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d20c4
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetExpaned(bool bInExpanded);

	// Object: Function FairyGUI.GTreeNode.SetChildIndex
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d1c20
	// Return & Params: [ Num(2) Size(0xc) ]
	void SetChildIndex(struct UGTreeNode* Child, int32_t Index);

	// Object: Function FairyGUI.GTreeNode.RemoveChildren
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d1d98
	// Return & Params: [ Num(2) Size(0x8) ]
	void RemoveChildren(int32_t BeginIndex, int32_t EndIndex);

	// Object: Function FairyGUI.GTreeNode.RemoveChildAt
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d1df4
	// Return & Params: [ Num(1) Size(0x4) ]
	void RemoveChildAt(int32_t Index);

	// Object: Function FairyGUI.GTreeNode.RemoveChild
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d1e34
	// Return & Params: [ Num(1) Size(0x8) ]
	void RemoveChild(struct UGTreeNode* Child);

	// Object: Function FairyGUI.GTreeNode.NumChildren
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035d1b2c
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t NumChildren();

	// Object: Function FairyGUI.GTreeNode.IsFolder
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035d20b0
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsFolder();

	// Object: Function FairyGUI.GTreeNode.IsExpanded
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035d2110
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsExpanded();

	// Object: Function FairyGUI.GTreeNode.GetTree
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035d2138
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UGTree* GetTree();

	// Object: Function FairyGUI.GTreeNode.GetText
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035d2060
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetText();

	// Object: Function FairyGUI.GTreeNode.GetPrevSibling
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035d1d1c
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UGTreeNode* GetPrevSibling();

	// Object: Function FairyGUI.GTreeNode.GetParent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035d2198
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UGTreeNode* GetParent();

	// Object: Function FairyGUI.GTreeNode.GetNextSibling
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035d1cf8
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UGTreeNode* GetNextSibling();

	// Object: Function FairyGUI.GTreeNode.GetIcon
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035d1fb4
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetIcon();

	// Object: Function FairyGUI.GTreeNode.GetChildIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035d1ca4
	// Return & Params: [ Num(2) Size(0xc) ]
	int32_t GetChildIndex(struct UGTreeNode* Child);

	// Object: Function FairyGUI.GTreeNode.GetChildAt
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035d1d40
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UGTreeNode* GetChildAt(int32_t Index);

	// Object: Function FairyGUI.GTreeNode.GetCell
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035d2124
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UGComponent* GetCell();

	// Object: Function FairyGUI.GTreeNode.CreateNode
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1035d21c0
	// Return & Params: [ Num(3) Size(0x20) ]
	struct UGTreeNode* CreateNode(bool bIsFolder, struct FString ResourceURL);

	// Object: Function FairyGUI.GTreeNode.AddChildAt
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d1e6c
	// Return & Params: [ Num(3) Size(0x18) ]
	struct UGTreeNode* AddChildAt(struct UGTreeNode* Child, int32_t Index);

	// Object: Function FairyGUI.GTreeNode.AddChild
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d1f04
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UGTreeNode* AddChild(struct UGTreeNode* Child);
};

// Object: Class FairyGUI.GWindow
// Inherited Bytes: 0x448 | Struct Size: 0x4f0
struct UGWindow : UGComponent {
	// Fields
	bool bBringToFontOnClick; // Offset: 0x448 | Size: 0x1
	char pad_0x449[0x3]; // Offset: 0x449 | Size: 0x3
	struct FDelegate InitCallback; // Offset: 0x44c | Size: 0x10
	struct FDelegate ShownCallback; // Offset: 0x45c | Size: 0x10
	struct FDelegate HideCallback; // Offset: 0x46c | Size: 0x10
	struct FDelegate ShowingCallback; // Offset: 0x47c | Size: 0x10
	struct FDelegate HidingCallback; // Offset: 0x48c | Size: 0x10
	char pad_0x49C[0x4]; // Offset: 0x49c | Size: 0x4
	struct UGComponent* ContentPane; // Offset: 0x4a0 | Size: 0x8
	struct UGObject* ModalWaitPane; // Offset: 0x4a8 | Size: 0x8
	struct UGComponent* FrameObject; // Offset: 0x4b0 | Size: 0x8
	struct UGObject* CloseButton; // Offset: 0x4b8 | Size: 0x8
	struct UGObject* DragArea; // Offset: 0x4c0 | Size: 0x8
	struct UGObject* ContentArea; // Offset: 0x4c8 | Size: 0x8
	char pad_0x4D0[0x20]; // Offset: 0x4d0 | Size: 0x20

	// Functions

	// Object: Function FairyGUI.GWindow.ToggleStatus
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d2b54
	// Return & Params: [ Num(0) Size(0x0) ]
	void ToggleStatus();

	// Object: Function FairyGUI.GWindow.ShowModalWait
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d2a3c
	// Return & Params: [ Num(1) Size(0x4) ]
	void ShowModalWait(int32_t InRequestingCmd);

	// Object: Function FairyGUI.GWindow.Show
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d2b84
	// Return & Params: [ Num(0) Size(0x0) ]
	void Show();

	// Object: Function FairyGUI.GWindow.SetModal
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d2a7c
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetModal(bool bInModal);

	// Object: Function FairyGUI.GWindow.SetDragArea
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d28ec
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetDragArea(struct UGObject* Obj);

	// Object: Function FairyGUI.GWindow.SetContentPane
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d2998
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetContentPane(struct UGComponent* Obj);

	// Object: Function FairyGUI.GWindow.SetContentArea
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d289c
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetContentArea(struct UGObject* Obj);

	// Object: Function FairyGUI.GWindow.SetCloseButton
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d2938
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetCloseButton(struct UGObject* Obj);

	// Object: Function FairyGUI.GWindow.OnDragStartHandler
	// Flags: [Final|Native|Private]
	// Offset: 0x1035d2818
	// Return & Params: [ Num(1) Size(0x8) ]
	void OnDragStartHandler(struct UEventContext* Context);

	// Object: Function FairyGUI.GWindow.IsTop
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035d2af8
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsTop();

	// Object: Function FairyGUI.GWindow.IsShowing
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035d2b1c
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsShowing();

	// Object: Function FairyGUI.GWindow.IsModal
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035d2ae0
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsModal();

	// Object: Function FairyGUI.GWindow.HideImmediately
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d2b64
	// Return & Params: [ Num(0) Size(0x0) ]
	void HideImmediately();

	// Object: Function FairyGUI.GWindow.Hide
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d2b74
	// Return & Params: [ Num(0) Size(0x0) ]
	void Hide();

	// Object: Function FairyGUI.GWindow.GetModalWaitingPane
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035d2888
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UGObject* GetModalWaitingPane();

	// Object: Function FairyGUI.GWindow.GetFrame
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035d2984
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UGComponent* GetFrame();

	// Object: Function FairyGUI.GWindow.GetDragArea
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035d2924
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UGObject* GetDragArea();

	// Object: Function FairyGUI.GWindow.GetContentPane
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035d29d0
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UGComponent* GetContentPane();

	// Object: Function FairyGUI.GWindow.GetContentArea
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035d28d8
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UGObject* GetContentArea();

	// Object: Function FairyGUI.GWindow.GetCloseButton
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035d2970
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UGObject* GetCloseButton();

	// Object: Function FairyGUI.GWindow.CreateWidget
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1035d2b94
	// Return & Params: [ Num(4) Size(0x30) ]
	struct UGWindow* CreateWidget(struct FString PackageName, struct FString ResourceName, struct UObject* WorldContextObject);

	// Object: Function FairyGUI.GWindow.CloseModalWait
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d29e4
	// Return & Params: [ Num(2) Size(0x5) ]
	bool CloseModalWait(int32_t InRequestingCmd);

	// Object: Function FairyGUI.GWindow.CloseEventHandler
	// Flags: [Final|Native|Protected]
	// Offset: 0x1035d2850
	// Return & Params: [ Num(1) Size(0x8) ]
	void CloseEventHandler(struct UEventContext* Context);

	// Object: Function FairyGUI.GWindow.BringToFront
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d2b44
	// Return & Params: [ Num(0) Size(0x0) ]
	void BringToFront();
};

// Object: Class FairyGUI.NTexture
// Inherited Bytes: 0x28 | Struct Size: 0x78
struct UNTexture : UObject {
	// Fields
	struct UNTexture* Root; // Offset: 0x28 | Size: 0x8
	struct UTexture2D* NativeTexture; // Offset: 0x30 | Size: 0x8
	char pad_0x38[0x40]; // Offset: 0x38 | Size: 0x40
};

// Object: Class FairyGUI.PopupMenu
// Inherited Bytes: 0x28 | Struct Size: 0x38
struct UPopupMenu : UObject {
	// Fields
	struct UGComponent* ContentPane; // Offset: 0x28 | Size: 0x8
	char pad_0x30[0x8]; // Offset: 0x30 | Size: 0x8

	// Functions

	// Object: Function FairyGUI.PopupMenu.Show
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d47c8
	// Return & Params: [ Num(2) Size(0x9) ]
	void Show(struct UGObject* AtObject, enum class EPopupDirection Dir);

	// Object: Function FairyGUI.PopupMenu.SetItemVisible
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d4aec
	// Return & Params: [ Num(2) Size(0x11) ]
	void SetItemVisible(struct FString Name, bool bVisible);

	// Object: Function FairyGUI.PopupMenu.SetItemText
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d4b68
	// Return & Params: [ Num(2) Size(0x20) ]
	void SetItemText(struct FString Name, struct FString Caption);

	// Object: Function FairyGUI.PopupMenu.SetItemGrayed
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d4a70
	// Return & Params: [ Num(2) Size(0x11) ]
	void SetItemGrayed(struct FString Name, bool bGrayed);

	// Object: Function FairyGUI.PopupMenu.SetItemChecked
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d4978
	// Return & Params: [ Num(2) Size(0x11) ]
	void SetItemChecked(struct FString Name, bool bCheck);

	// Object: Function FairyGUI.PopupMenu.SetItemCheckable
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d49f4
	// Return & Params: [ Num(2) Size(0x11) ]
	void SetItemCheckable(struct FString Name, bool bCheckable);

	// Object: Function FairyGUI.PopupMenu.RemoveItem
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d48a8
	// Return & Params: [ Num(2) Size(0x11) ]
	bool RemoveItem(struct FString Name);

	// Object: Function FairyGUI.PopupMenu.IsItemChecked
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035d4910
	// Return & Params: [ Num(2) Size(0x11) ]
	bool IsItemChecked(struct FString Name);

	// Object: Function FairyGUI.PopupMenu.GetList
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035d484c
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UGList* GetList();

	// Object: Function FairyGUI.PopupMenu.GetItemName
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035d4c18
	// Return & Params: [ Num(2) Size(0x18) ]
	struct FString GetItemName(int32_t Index);

	// Object: Function FairyGUI.PopupMenu.GetItemCount
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035d4874
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetItemCount();

	// Object: Function FairyGUI.PopupMenu.GetContentPane
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035d4860
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UGComponent* GetContentPane();

	// Object: Function FairyGUI.PopupMenu.CreatePopupMenu
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1035d4e7c
	// Return & Params: [ Num(3) Size(0x20) ]
	struct UPopupMenu* CreatePopupMenu(struct FString ResourceURL, struct UObject* WorldContextObject);

	// Object: Function FairyGUI.PopupMenu.ClearItems
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d4898
	// Return & Params: [ Num(0) Size(0x0) ]
	void ClearItems();

	// Object: Function FairyGUI.PopupMenu.AddSeperator
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d4ca0
	// Return & Params: [ Num(0) Size(0x0) ]
	void AddSeperator();

	// Object: Function FairyGUI.PopupMenu.AddItemAt
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1035d4cb0
	// Return & Params: [ Num(4) Size(0x30) ]
	struct UGButton* AddItemAt(struct FString Caption, int32_t Index, struct FDelegate& Callback);

	// Object: Function FairyGUI.PopupMenu.AddItem
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1035d4db8
	// Return & Params: [ Num(3) Size(0x28) ]
	struct UGButton* AddItem(struct FString Caption, struct FDelegate& Callback);
};

// Object: Class FairyGUI.ScrollPane
// Inherited Bytes: 0x28 | Struct Size: 0x150
struct UScrollPane : UObject {
	// Fields
	char bBouncebackEffect : 1; // Offset: 0x28 | Size: 0x1
	char bTouchEffect : 1; // Offset: 0x28 | Size: 0x1
	char bInertiaDisabled : 1; // Offset: 0x28 | Size: 0x1
	char bMouseWheelEnabled : 1; // Offset: 0x28 | Size: 0x1
	char bSnapToItem : 1; // Offset: 0x28 | Size: 0x1
	char bPageMode : 1; // Offset: 0x28 | Size: 0x1
	char pad_0x28_6 : 2; // Offset: 0x28 | Size: 0x1
	char pad_0x29[0x3]; // Offset: 0x29 | Size: 0x3
	float DecelerationRate; // Offset: 0x2c | Size: 0x4
	float ScrollStep; // Offset: 0x30 | Size: 0x4
	char pad_0x34[0x4]; // Offset: 0x34 | Size: 0x4
	struct UGController* PageController; // Offset: 0x38 | Size: 0x8
	char pad_0x40[0x28]; // Offset: 0x40 | Size: 0x28
	struct UGScrollBar* HzScrollBar; // Offset: 0x68 | Size: 0x8
	struct UGScrollBar* VtScrollBar; // Offset: 0x70 | Size: 0x8
	struct UGComponent* Header; // Offset: 0x78 | Size: 0x8
	struct UGComponent* Footer; // Offset: 0x80 | Size: 0x8
	char pad_0x88[0xc8]; // Offset: 0x88 | Size: 0xc8

	// Functions

	// Object: Function FairyGUI.ScrollPane.SetPosY
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d59d0
	// Return & Params: [ Num(2) Size(0x5) ]
	void SetPosY(float Value, bool bAnimation);

	// Object: Function FairyGUI.ScrollPane.SetPosX
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d5a44
	// Return & Params: [ Num(2) Size(0x5) ]
	void SetPosX(float Value, bool bAnimation);

	// Object: Function FairyGUI.ScrollPane.SetPercY
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d58c8
	// Return & Params: [ Num(2) Size(0x5) ]
	void SetPercY(float Value, bool bAnimation);

	// Object: Function FairyGUI.ScrollPane.SetPercX
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d594c
	// Return & Params: [ Num(2) Size(0x5) ]
	void SetPercX(float Value, bool bAnimation);

	// Object: Function FairyGUI.ScrollPane.SetPageY
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d540c
	// Return & Params: [ Num(2) Size(0x5) ]
	void SetPageY(int32_t PageY, bool bAnimation);

	// Object: Function FairyGUI.ScrollPane.SetPageX
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d549c
	// Return & Params: [ Num(2) Size(0x5) ]
	void SetPageX(int32_t PageX, bool bAnimation);

	// Object: Function FairyGUI.ScrollPane.ScrollUp
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d5760
	// Return & Params: [ Num(2) Size(0x5) ]
	void ScrollUp(float Ratio, bool bAnimation);

	// Object: Function FairyGUI.ScrollPane.ScrollToView
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d5590
	// Return & Params: [ Num(3) Size(0xa) ]
	void ScrollToView(struct UGObject* Obj, bool bAnimation, bool bSetFirst);

	// Object: Function FairyGUI.ScrollPane.ScrollTop
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d56b4
	// Return & Params: [ Num(1) Size(0x1) ]
	void ScrollTop(bool bAnimation);

	// Object: Function FairyGUI.ScrollPane.ScrollRight
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d57c0
	// Return & Params: [ Num(2) Size(0x5) ]
	void ScrollRight(float Ratio, bool bAnimation);

	// Object: Function FairyGUI.ScrollPane.ScrollLeft
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d5820
	// Return & Params: [ Num(2) Size(0x5) ]
	void ScrollLeft(float Ratio, bool bAnimation);

	// Object: Function FairyGUI.ScrollPane.ScrollDown
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d5700
	// Return & Params: [ Num(2) Size(0x5) ]
	void ScrollDown(float Ratio, bool bAnimation);

	// Object: Function FairyGUI.ScrollPane.ScrollBottom
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d5668
	// Return & Params: [ Num(1) Size(0x1) ]
	void ScrollBottom(bool bAnimation);

	// Object: Function FairyGUI.ScrollPane.LockHeader
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d535c
	// Return & Params: [ Num(1) Size(0x4) ]
	void LockHeader(int32_t Size);

	// Object: Function FairyGUI.ScrollPane.LockFooter
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d531c
	// Return & Params: [ Num(1) Size(0x4) ]
	void LockFooter(int32_t Size);

	// Object: Function FairyGUI.ScrollPane.IsRightMost
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035d5880
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsRightMost();

	// Object: Function FairyGUI.ScrollPane.IsChildInView
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035d552c
	// Return & Params: [ Num(2) Size(0x9) ]
	bool IsChildInView(struct UGObject* Obj);

	// Object: Function FairyGUI.ScrollPane.IsBottomMost
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035d58a4
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsBottomMost();

	// Object: Function FairyGUI.ScrollPane.GetVtScrollBar
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035d5acc
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UGScrollBar* GetVtScrollBar();

	// Object: Function FairyGUI.ScrollPane.GetViewSize
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035d539c
	// Return & Params: [ Num(1) Size(0x8) ]
	struct FVector2D GetViewSize();

	// Object: Function FairyGUI.ScrollPane.GetScrollingPosY
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035d53c4
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetScrollingPosY();

	// Object: Function FairyGUI.ScrollPane.GetScrollingPosX
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035d53e8
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetScrollingPosX();

	// Object: Function FairyGUI.ScrollPane.GetPosY
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035d5a30
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetPosY();

	// Object: Function FairyGUI.ScrollPane.GetPosX
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035d5aa4
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetPosX();

	// Object: Function FairyGUI.ScrollPane.GetPercY
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035d5928
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetPercY();

	// Object: Function FairyGUI.ScrollPane.GetPercX
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035d59ac
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetPercX();

	// Object: Function FairyGUI.ScrollPane.GetPageY
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035d5478
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetPageY();

	// Object: Function FairyGUI.ScrollPane.GetPageX
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035d5508
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetPageX();

	// Object: Function FairyGUI.ScrollPane.GetHzScrollBar
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035d5ab8
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UGScrollBar* GetHzScrollBar();

	// Object: Function FairyGUI.ScrollPane.GetHeader
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035d5af4
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UGComponent* GetHeader();

	// Object: Function FairyGUI.ScrollPane.GetFooter
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035d5ae0
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UGComponent* GetFooter();

	// Object: Function FairyGUI.ScrollPane.GetContentSize
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035d53b0
	// Return & Params: [ Num(1) Size(0x8) ]
	struct FVector2D GetContentSize();

	// Object: Function FairyGUI.ScrollPane.CancelDragging
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d530c
	// Return & Params: [ Num(0) Size(0x0) ]
	void CancelDragging();
};

// Object: Class FairyGUI.Transition
// Inherited Bytes: 0x28 | Struct Size: 0xa8
struct UTransition : UObject {
	// Fields
	struct FString Name; // Offset: 0x28 | Size: 0x10
	char pad_0x38[0x70]; // Offset: 0x38 | Size: 0x70

	// Functions

	// Object: Function FairyGUI.Transition.Stop
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d68ac
	// Return & Params: [ Num(2) Size(0x2) ]
	void Stop(bool bSetToComplete, bool bProcessCallback);

	// Object: Function FairyGUI.Transition.SetValue
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1035d66c8
	// Return & Params: [ Num(2) Size(0x20) ]
	void SetValue(struct FString InLabel, struct TArray<struct FNVariant>& InValues);

	// Object: Function FairyGUI.Transition.SetTimeScale
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d6308
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetTimeScale(float InTimeScale);

	// Object: Function FairyGUI.Transition.SetTarget
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d6470
	// Return & Params: [ Num(2) Size(0x18) ]
	void SetTarget(struct FString InLabel, struct UGObject* InTarget);

	// Object: Function FairyGUI.Transition.SetPaused
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d67a4
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetPaused(bool bInPaused);

	// Object: Function FairyGUI.Transition.SetHook
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d6508
	// Return & Params: [ Num(2) Size(0x20) ]
	void SetHook(struct FString InLabel, struct FDelegate Callback);

	// Object: Function FairyGUI.Transition.SetDuration
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d63d8
	// Return & Params: [ Num(2) Size(0x14) ]
	void SetDuration(struct FString InLabel, float InDuration);

	// Object: Function FairyGUI.Transition.SetAutoPlay
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d67f0
	// Return & Params: [ Num(3) Size(0xc) ]
	void SetAutoPlay(bool bInAutoPlay, int32_t InTimes, float InDelay);

	// Object: Function FairyGUI.Transition.PlayReverse
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1035d6970
	// Return & Params: [ Num(3) Size(0x18) ]
	void PlayReverse(struct FDelegate& InCompleteCallback, int32_t InTimes, float InDelay);

	// Object: Function FairyGUI.Transition.Play
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1035d6b74
	// Return & Params: [ Num(5) Size(0x20) ]
	void Play(struct FDelegate& InCompleteCallback, int32_t InTimes, float InDelay, float InStartTime, float InEndTime);

	// Object: Function FairyGUI.Transition.GetTimeScale
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035d635c
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetTimeScale();

	// Object: Function FairyGUI.Transition.GetLabelTime
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035d6370
	// Return & Params: [ Num(2) Size(0x14) ]
	float GetLabelTime(struct FString InLabel);

	// Object: Function FairyGUI.Transition.ClearHooks
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d64f8
	// Return & Params: [ Num(0) Size(0x0) ]
	void ClearHooks();

	// Object: Function FairyGUI.Transition.ChangePlayTimes
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1035d6930
	// Return & Params: [ Num(1) Size(0x4) ]
	void ChangePlayTimes(int32_t InTimes);
};

// Object: Class FairyGUI.UIPackage
// Inherited Bytes: 0x28 | Struct Size: 0x1e8
struct UUIPackage : UObject {
	// Fields
	char pad_0x28[0x30]; // Offset: 0x28 | Size: 0x30
	struct UUIPackageAsset* Asset; // Offset: 0x58 | Size: 0x8
	char pad_0x60[0x188]; // Offset: 0x60 | Size: 0x188

	// Functions

	// Object: Function FairyGUI.UIPackage.SetVar
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1035d779c
	// Return & Params: [ Num(2) Size(0x20) ]
	void SetVar(struct FString VarKey, struct FString VarValue);

	// Object: Function FairyGUI.UIPackage.SetBranch
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1035d78cc
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetBranch(struct FString InBranch);

	// Object: Function FairyGUI.UIPackage.RemovePackage
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1035d76a4
	// Return & Params: [ Num(2) Size(0x18) ]
	void RemovePackage(struct FString IDOrName, struct UObject* WorldContextObject);

	// Object: Function FairyGUI.UIPackage.RemoveAllPackages
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1035d7694
	// Return & Params: [ Num(0) Size(0x0) ]
	void RemoveAllPackages();

	// Object: Function FairyGUI.UIPackage.RegisterFont
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1035d7388
	// Return & Params: [ Num(2) Size(0x18) ]
	void RegisterFont(struct FString FontFace, struct UObject* Font);

	// Object: Function FairyGUI.UIPackage.GetVar
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1035d7828
	// Return & Params: [ Num(2) Size(0x20) ]
	struct FString GetVar(struct FString VarKey);

	// Object: Function FairyGUI.UIPackage.GetPackageByName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1035d75c4
	// Return & Params: [ Num(2) Size(0x18) ]
	struct UUIPackage* GetPackageByName(struct FString PackageName);

	// Object: Function FairyGUI.UIPackage.GetPackageByID
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1035d762c
	// Return & Params: [ Num(2) Size(0x18) ]
	struct UUIPackage* GetPackageByID(struct FString PackageID);

	// Object: Function FairyGUI.UIPackage.GetName
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035d72d8
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetName();

	// Object: Function FairyGUI.UIPackage.GetID
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035d7330
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetID();

	// Object: Function FairyGUI.UIPackage.GetBranch
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1035d7930
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetBranch();

	// Object: Function FairyGUI.UIPackage.CreateObjectFromURL
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1035d7400
	// Return & Params: [ Num(4) Size(0x28) ]
	struct UGObject* CreateObjectFromURL(struct FString URL, struct UObject* WorldContextObject, struct UGObject* ClassType);

	// Object: Function FairyGUI.UIPackage.CreateObject
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1035d74bc
	// Return & Params: [ Num(5) Size(0x38) ]
	struct UGObject* CreateObject(struct FString PackageName, struct FString ResourceName, struct UObject* WorldContextObject, struct UGObject* ClassType);

	// Object: Function FairyGUI.UIPackage.AddPackage
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1035d771c
	// Return & Params: [ Num(3) Size(0x18) ]
	struct UUIPackage* AddPackage(struct UUIPackageAsset* InAsset, struct UObject* WorldContextObject);
};

// Object: Class FairyGUI.UIPackageStatic
// Inherited Bytes: 0x28 | Struct Size: 0x188
struct UUIPackageStatic : UObject {
	// Fields
	struct TArray<struct UUIPackage*> PackageList; // Offset: 0x28 | Size: 0x10
	char pad_0x38[0x100]; // Offset: 0x38 | Size: 0x100
	struct TMap<struct FString, struct UObject*> Fonts; // Offset: 0x138 | Size: 0x50
};

// Object: Class FairyGUI.UIPackageAsset
// Inherited Bytes: 0x28 | Struct Size: 0x38
struct UUIPackageAsset : UObject {
	// Fields
	struct TArray<char> Data; // Offset: 0x28 | Size: 0x10
};

