#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Enum FairyGUI.EEaseType
enum class EEaseType : uint8_t {
	Linear = 0,
	SineIn = 1,
	SineOut = 2,
	SineInOut = 3,
	QuadIn = 4,
	QuadOut = 5,
	QuadInOut = 6,
	CubicIn = 7,
	CubicOut = 8,
	CubicInOut = 9,
	QuartIn = 10,
	QuartOut = 11,
	QuartInOut = 12,
	QuintIn = 13,
	QuintOut = 14,
	QuintInOut = 15,
	ExpoIn = 16,
	ExpoOut = 17,
	ExpoInOut = 18,
	CircIn = 19,
	CircOut = 20,
	CircInOut = 21,
	ElasticIn = 22,
	ElasticOut = 23,
	ElasticInOut = 24,
	BackIn = 25,
	BackOut = 26,
	BackInOut = 27,
	BounceIn = 28,
	BounceOut = 29,
	BounceInOut = 30,
	Custom = 31,
	EEaseType_MAX = 32
};

// Object: Enum FairyGUI.ERelationType
enum class ERelationType : uint8_t {
	Left_Left = 0,
	Left_Center = 1,
	Left_Right = 2,
	Center_Center = 3,
	Right_Left = 4,
	Right_Center = 5,
	Right_Right = 6,
	Top_Top = 7,
	Top_Middle = 8,
	Top_Bottom = 9,
	Middle_Middle = 10,
	Bottom_Top = 11,
	Bottom_Middle = 12,
	Bottom_Bottom = 13,
	Width = 14,
	Height = 15,
	LeftExt_Left = 16,
	LeftExt_Right = 17,
	RightExt_Left = 18,
	RightExt_Right = 19,
	TopExt_Top = 20,
	TopExt_Bottom = 21,
	BottomExt_Top = 22,
	BottomExt_Bottom = 23,
	Size = 24,
	ERelationType_MAX = 25
};

// Object: Enum FairyGUI.EVerticalAlignType
enum class EVerticalAlignType : uint8_t {
	Top = 0,
	Middle = 1,
	Bottom = 2,
	EVerticalAlignType_MAX = 3
};

// Object: Enum FairyGUI.EAlignType
enum class EAlignType : uint8_t {
	Left = 0,
	Center = 1,
	Right = 2,
	EAlignType_MAX = 3
};

// Object: Enum FairyGUI.EObjectPropID
enum class EObjectPropID : uint8_t {
	Text = 0,
	Icon = 1,
	Color = 2,
	OutlineColor = 3,
	Playing = 4,
	Frame = 5,
	DeltaTime = 6,
	TimeScale = 7,
	FontSize = 8,
	Selected = 9,
	EObjectPropID_MAX = 10
};

// Object: Enum FairyGUI.EOrigin360
enum class EOrigin360 : uint8_t {
	Top = 0,
	Bottom = 1,
	Left = 2,
	Right = 3,
	EOrigin360_MAX = 4
};

// Object: Enum FairyGUI.EOrigin180
enum class EOrigin180 : uint8_t {
	Top = 0,
	Bottom = 1,
	Left = 2,
	Right = 3,
	EOrigin180_MAX = 4
};

// Object: Enum FairyGUI.EOrigin90
enum class EOrigin90 : uint8_t {
	TopLeft = 0,
	TopRight = 1,
	BottomLeft = 2,
	BottomRight = 3,
	EOrigin90_MAX = 4
};

// Object: Enum FairyGUI.EOriginVertical
enum class EOriginVertical : uint8_t {
	Top = 0,
	Bottom = 1,
	EOriginVertical_MAX = 2
};

// Object: Enum FairyGUI.EOriginHorizontal
enum class EOriginHorizontal : uint8_t {
	Left = 0,
	Right = 1,
	EOriginHorizontal_MAX = 2
};

// Object: Enum FairyGUI.EFillMethod
enum class EFillMethod : uint8_t {
	None = 0,
	Horizontal = 1,
	Vertical = 2,
	Radial90 = 3,
	Radial180 = 4,
	Radial360 = 5,
	EFillMethod_MAX = 6
};

// Object: Enum FairyGUI.ETransitionActionType
enum class ETransitionActionType : uint8_t {
	XY = 0,
	Size = 1,
	Scale = 2,
	Pivot = 3,
	Alpha = 4,
	Rotation = 5,
	Color = 6,
	Animation = 7,
	Visible = 8,
	Sound = 9,
	Transition = 10,
	Shake = 11,
	ColorFilter = 12,
	Skew = 13,
	Text = 14,
	Icon = 15,
	Unknown = 16,
	ETransitionActionType_MAX = 17
};

// Object: Enum FairyGUI.EFlipType
enum class EFlipType : uint8_t {
	None = 0,
	Horizontal = 1,
	Vertical = 2,
	Both = 3,
	EFlipType_MAX = 4
};

// Object: Enum FairyGUI.EAutoSizeType
enum class EAutoSizeType : uint8_t {
	None = 0,
	Both = 1,
	Height = 2,
	Shrink = 3,
	EAutoSizeType_MAX = 4
};

// Object: Enum FairyGUI.EPopupDirection
enum class EPopupDirection : uint8_t {
	Auto = 0,
	Up = 1,
	Down = 2,
	EPopupDirection_MAX = 3
};

// Object: Enum FairyGUI.EGroupLayoutType
enum class EGroupLayoutType : uint8_t {
	None = 0,
	Horizontal = 1,
	Vertical = 2,
	EGroupLayoutType_MAX = 3
};

// Object: Enum FairyGUI.EListSelectionMode
enum class EListSelectionMode : uint8_t {
	Single = 0,
	Multiple = 1,
	MultipleSingleclick = 2,
	None = 3,
	EListSelectionMode_MAX = 4
};

// Object: Enum FairyGUI.EListLayoutType
enum class EListLayoutType : uint8_t {
	SingleColumn = 0,
	SingleRow = 1,
	FlowHorizontal = 2,
	FlowVertical = 3,
	Pagination = 4,
	EListLayoutType_MAX = 5
};

// Object: Enum FairyGUI.EProgressTitleType
enum class EProgressTitleType : uint8_t {
	Percent = 0,
	ValueMax = 1,
	Value = 2,
	Max = 3
};

// Object: Enum FairyGUI.ELoaderFillType
enum class ELoaderFillType : uint8_t {
	None = 0,
	Scale = 1,
	ScaleMatchHeight = 2,
	ScaleMatchWidth = 3,
	ScaleFree = 4,
	ScaleNoBorder = 5,
	ELoaderFillType_MAX = 6
};

// Object: Enum FairyGUI.EScrollBarDisplayType
enum class EScrollBarDisplayType : uint8_t {
	Default = 0,
	Visible = 1,
	Auto = 2,
	Hidden = 3,
	EScrollBarDisplayType_MAX = 4
};

// Object: Enum FairyGUI.EScrollType
enum class EScrollType : uint8_t {
	Horizontal = 0,
	Vertical = 1,
	Both = 2,
	EScrollType_MAX = 3
};

// Object: Enum FairyGUI.EOverflowType
enum class EOverflowType : uint8_t {
	Visible = 0,
	Hidden = 1,
	Scroll = 2,
	EOverflowType_MAX = 3
};

// Object: Enum FairyGUI.EChildrenRenderOrder
enum class EChildrenRenderOrder : uint8_t {
	Ascent = 0,
	Descent = 1,
	Arch = 2,
	EChildrenRenderOrder_MAX = 3
};

// Object: Enum FairyGUI.EButtonMode
enum class EButtonMode : uint8_t {
	Common = 0,
	Check = 1,
	Radio = 2,
	EButtonMode_MAX = 3
};

// Object: Enum FairyGUI.EObjectType
enum class EObjectType : uint8_t {
	Image = 0,
	MovieClip = 1,
	Swf = 2,
	Graph = 3,
	Loader = 4,
	Group = 5,
	Text = 6,
	RichText = 7,
	InputText = 8,
	Component = 9,
	List = 10,
	Label = 11,
	Button = 12,
	ComboBox = 13,
	ProgressBar = 14,
	Slider = 15,
	ScrollBar = 16,
	Tree = 17,
	Loader3D = 18,
	EObjectType_MAX = 19
};

// Object: Enum FairyGUI.EPackageItemType
enum class EPackageItemType : uint8_t {
	Image = 0,
	MovieClip = 1,
	Sound = 2,
	Component = 3,
	Atlas = 4,
	Font = 5,
	Swf = 6,
	Misc = 7,
	Unknown = 8,
	Spine = 9,
	DragonBones = 10,
	EPackageItemType_MAX = 11
};

