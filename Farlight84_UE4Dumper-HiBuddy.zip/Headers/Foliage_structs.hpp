#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct Foliage.FoliageVertexColorChannelMask
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FFoliageVertexColorChannelMask {
	// Fields
	char UseMask : 1; // Offset: 0x0 | Size: 0x1
	char pad_0x0_1 : 7; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	float MaskThreshold; // Offset: 0x4 | Size: 0x4
	char InvertMask : 1; // Offset: 0x8 | Size: 0x1
	char pad_0x8_1 : 7; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x3]; // Offset: 0x9 | Size: 0x3
};

// Object: ScriptStruct Foliage.SelectInstanceInfo
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FSelectInstanceInfo {
	// Fields
	int32_t instanceID; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0xc]; // Offset: 0x4 | Size: 0xc
	struct FTransform Transform; // Offset: 0x10 | Size: 0x30
	struct TArray<float> CustomData; // Offset: 0x40 | Size: 0x10
};

// Object: ScriptStruct Foliage.FoliageTypeObject
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FFoliageTypeObject {
	// Fields
	struct UObject* FoliageTypeObject; // Offset: 0x0 | Size: 0x8
	struct UFoliageType* TypeInstance; // Offset: 0x8 | Size: 0x8
	bool bIsAsset; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x7]; // Offset: 0x11 | Size: 0x7
	struct UFoliageType_InstancedStaticMesh* Type; // Offset: 0x18 | Size: 0x8
};

// Object: ScriptStruct Foliage.ProceduralFoliageInstance
// Inherited Bytes: 0x0 | Struct Size: 0x60
struct FProceduralFoliageInstance {
	// Fields
	struct FVector Location; // Offset: 0x0 | Size: 0xc
	char pad_0xC[0x4]; // Offset: 0xc | Size: 0x4
	struct FQuat Rotation; // Offset: 0x10 | Size: 0x10
	struct FVector Normal; // Offset: 0x20 | Size: 0xc
	float Age; // Offset: 0x2c | Size: 0x4
	float Scale; // Offset: 0x30 | Size: 0x4
	char pad_0x34[0x4]; // Offset: 0x34 | Size: 0x4
	struct UFoliageType* Type; // Offset: 0x38 | Size: 0x8
	char pad_0x40[0x20]; // Offset: 0x40 | Size: 0x20
};

