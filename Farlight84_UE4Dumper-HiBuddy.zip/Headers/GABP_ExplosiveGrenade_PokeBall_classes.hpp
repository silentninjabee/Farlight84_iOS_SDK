#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass GABP_ExplosiveGrenade_PokeBall.GABP_ExplosiveGrenade_PokeBall_C
// Inherited Bytes: 0x750 | Struct Size: 0x751
struct UGABP_ExplosiveGrenade_PokeBall_C : UBuddyGA_Projectile {
	// Fields
	bool if cancel; // Offset: 0x750 | Size: 0x1
};

