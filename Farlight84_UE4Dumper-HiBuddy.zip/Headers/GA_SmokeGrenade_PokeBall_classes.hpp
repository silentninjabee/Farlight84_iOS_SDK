#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass GA_SmokeGrenade_PokeBall.GA_SmokeGrenade_PokeBall_C
// Inherited Bytes: 0x750 | Struct Size: 0x751
struct UGA_SmokeGrenade_PokeBall_C : USolarSkillGA_JumpSmoke {
	// Fields
	bool if cancel; // Offset: 0x750 | Size: 0x1
};

