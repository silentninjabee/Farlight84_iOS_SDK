#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass GC_Skill_DuckRolling.GC_Skill_DuckRolling_C
// Inherited Bytes: 0x50 | Struct Size: 0x50
struct UGC_Skill_DuckRolling_C : UGameplayCueNotify_Static {
	// Functions

	// Object: Function GC_Skill_DuckRolling.GC_Skill_DuckRolling_C.OnActive
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const]
	// Offset: 0x10213e738
	// Return & Params: [ Num(3) Size(0xd9) ]
	bool OnActive(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters);
};

