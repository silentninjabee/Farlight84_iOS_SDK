#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass GC_SurroundLightning.GC_SurroundLightning_C
// Inherited Bytes: 0x318 | Struct Size: 0x320
struct AGC_SurroundLightning_C : ASolarSkillGC_SurroundLightning {
	// Fields
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x318 | Size: 0x8
};

