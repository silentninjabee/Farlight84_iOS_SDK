#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass GC_UnlimitedAmmo.GC_UnlimitedAmmo_C
// Inherited Bytes: 0x2b8 | Struct Size: 0x2d8
struct AGC_UnlimitedAmmo_C : AGameplayCueNotify_Actor {
	// Fields
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x2b8 | Size: 0x8
	struct UParticleSystemComponent* CharacterVFX; // Offset: 0x2c0 | Size: 0x8
	struct UUserWidget* ScreenVFX; // Offset: 0x2c8 | Size: 0x8
	int32_t CharacterEffectHandle; // Offset: 0x2d0 | Size: 0x4
	int32_t ScreenEffectHandle; // Offset: 0x2d4 | Size: 0x4

	// Functions

	// Object: Function GC_UnlimitedAmmo.GC_UnlimitedAmmo_C.OnRemove
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(3) Size(0xd9) ]
	bool OnRemove(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters);

	// Object: Function GC_UnlimitedAmmo.GC_UnlimitedAmmo_C.OnActive
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(3) Size(0xd9) ]
	bool OnActive(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters);
};

