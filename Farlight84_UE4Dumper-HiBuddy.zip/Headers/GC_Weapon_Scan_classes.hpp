#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass GC_Weapon_Scan.GC_Weapon_Scan_C
// Inherited Bytes: 0x2b8 | Struct Size: 0x2c8
struct AGC_Weapon_Scan_C : AGameplayCueNotify_Actor {
	// Fields
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x2b8 | Size: 0x8
	float Duration; // Offset: 0x2c0 | Size: 0x4
	float ScanRadius; // Offset: 0x2c4 | Size: 0x4

	// Functions

	// Object: Function GC_Weapon_Scan.GC_Weapon_Scan_C.PlaySound
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(2) Size(0x14) ]
	void PlaySound(struct ASolarCharacter* CueOwner, struct FVector CueLocation);

	// Object: Function GC_Weapon_Scan.GC_Weapon_Scan_C.OnActive
	// Flags: [Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(3) Size(0xd9) ]
	bool OnActive(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters);
};

