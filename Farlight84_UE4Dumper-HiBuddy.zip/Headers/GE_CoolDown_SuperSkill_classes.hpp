#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass GE_CoolDown_SuperSkill.GE_CoolDown_SuperSkill_C
// Inherited Bytes: 0x898 | Struct Size: 0x898
struct UGE_CoolDown_SuperSkill_C : UGameplayEffect {
};

