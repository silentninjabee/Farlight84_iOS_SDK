#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class GeometryCollectionEngine.ChaosDestructionListener
// Inherited Bytes: 0x370 | Struct Size: 0x590
struct UChaosDestructionListener : USceneComponent {
	// Fields
	char bIsCollisionEventListeningEnabled : 1; // Offset: 0x364 | Size: 0x1
	char bIsBreakingEventListeningEnabled : 1; // Offset: 0x364 | Size: 0x1
	char bIsTrailingEventListeningEnabled : 1; // Offset: 0x364 | Size: 0x1
	struct FChaosCollisionEventRequestSettings CollisionEventRequestSettings; // Offset: 0x368 | Size: 0x18
	struct FChaosBreakingEventRequestSettings BreakingEventRequestSettings; // Offset: 0x380 | Size: 0x18
	struct FChaosTrailingEventRequestSettings TrailingEventRequestSettings; // Offset: 0x398 | Size: 0x18
	struct TSet<struct AChaosSolverActor*> ChaosSolverActors; // Offset: 0x3b0 | Size: 0x50
	struct TSet<struct AGeometryCollectionActor*> GeometryCollectionActors; // Offset: 0x400 | Size: 0x50
	struct FMulticastInlineDelegate OnCollisionEvents; // Offset: 0x450 | Size: 0x10
	struct FMulticastInlineDelegate OnBreakingEvents; // Offset: 0x460 | Size: 0x10
	struct FMulticastInlineDelegate OnTrailingEvents; // Offset: 0x470 | Size: 0x10
	char pad_0x488_3 : 5; // Offset: 0x488 | Size: 0x1
	char pad_0x489[0x107]; // Offset: 0x489 | Size: 0x107

	// Functions

	// Object: Function GeometryCollectionEngine.ChaosDestructionListener.SortTrailingEvents
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105c5dabc
	// Return & Params: [ Num(2) Size(0x11) ]
	void SortTrailingEvents(struct TArray<struct FChaosTrailingEventData>& TrailingEvents, enum class EChaosTrailingSortMethod SortMethod);

	// Object: Function GeometryCollectionEngine.ChaosDestructionListener.SortCollisionEvents
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105c5dbe4
	// Return & Params: [ Num(2) Size(0x11) ]
	void SortCollisionEvents(struct TArray<struct FChaosCollisionEventData>& CollisionEvents, enum class EChaosCollisionSortMethod SortMethod);

	// Object: Function GeometryCollectionEngine.ChaosDestructionListener.SortBreakingEvents
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105c5db50
	// Return & Params: [ Num(2) Size(0x11) ]
	void SortBreakingEvents(struct TArray<struct FChaosBreakingEventData>& BreakingEvents, enum class EChaosBreakingSortMethod SortMethod);

	// Object: Function GeometryCollectionEngine.ChaosDestructionListener.SetTrailingEventRequestSettings
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105c5ddc0
	// Return & Params: [ Num(1) Size(0x18) ]
	void SetTrailingEventRequestSettings(struct FChaosTrailingEventRequestSettings& InSettings);

	// Object: Function GeometryCollectionEngine.ChaosDestructionListener.SetTrailingEventEnabled
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105c5dcac
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetTrailingEventEnabled(bool bIsEnabled);

	// Object: Function GeometryCollectionEngine.ChaosDestructionListener.SetCollisionEventRequestSettings
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105c5de48
	// Return & Params: [ Num(1) Size(0x18) ]
	void SetCollisionEventRequestSettings(struct FChaosCollisionEventRequestSettings& InSettings);

	// Object: Function GeometryCollectionEngine.ChaosDestructionListener.SetCollisionEventEnabled
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105c5dd64
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetCollisionEventEnabled(bool bIsEnabled);

	// Object: Function GeometryCollectionEngine.ChaosDestructionListener.SetBreakingEventRequestSettings
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105c5de04
	// Return & Params: [ Num(1) Size(0x18) ]
	void SetBreakingEventRequestSettings(struct FChaosBreakingEventRequestSettings& InSettings);

	// Object: Function GeometryCollectionEngine.ChaosDestructionListener.SetBreakingEventEnabled
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105c5dd08
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetBreakingEventEnabled(bool bIsEnabled);

	// Object: Function GeometryCollectionEngine.ChaosDestructionListener.RemoveGeometryCollectionActor
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105c5de8c
	// Return & Params: [ Num(1) Size(0x8) ]
	void RemoveGeometryCollectionActor(struct AGeometryCollectionActor* GeometryCollectionActor);

	// Object: Function GeometryCollectionEngine.ChaosDestructionListener.RemoveChaosSolverActor
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105c5df0c
	// Return & Params: [ Num(1) Size(0x8) ]
	void RemoveChaosSolverActor(struct AChaosSolverActor* ChaosSolverActor);

	// Object: Function GeometryCollectionEngine.ChaosDestructionListener.IsEventListening
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105c5dc78
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsEventListening();

	// Object: Function GeometryCollectionEngine.ChaosDestructionListener.AddGeometryCollectionActor
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105c5decc
	// Return & Params: [ Num(1) Size(0x8) ]
	void AddGeometryCollectionActor(struct AGeometryCollectionActor* GeometryCollectionActor);

	// Object: Function GeometryCollectionEngine.ChaosDestructionListener.AddChaosSolverActor
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105c5df4c
	// Return & Params: [ Num(1) Size(0x8) ]
	void AddChaosSolverActor(struct AChaosSolverActor* ChaosSolverActor);
};

// Object: Class GeometryCollectionEngine.GeometryCollectionActor
// Inherited Bytes: 0x248 | Struct Size: 0x258
struct AGeometryCollectionActor : AActor {
	// Fields
	struct UGeometryCollectionComponent* GeometryCollectionComponent; // Offset: 0x248 | Size: 0x8
	struct UGeometryCollectionDebugDrawComponent* GeometryCollectionDebugDrawComponent; // Offset: 0x250 | Size: 0x8

	// Functions

	// Object: Function GeometryCollectionEngine.GeometryCollectionActor.RaycastSingle
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105c5e7d4
	// Return & Params: [ Num(4) Size(0xa1) ]
	bool RaycastSingle(struct FVector Start, struct FVector End, struct FHitResult& OutHit);
};

// Object: Class GeometryCollectionEngine.GeometryCollectionCache
// Inherited Bytes: 0x28 | Struct Size: 0x50
struct UGeometryCollectionCache : UObject {
	// Fields
	struct FRecordedTransformTrack RecordedData; // Offset: 0x28 | Size: 0x10
	struct UGeometryCollection* SupportedCollection; // Offset: 0x38 | Size: 0x8
	struct FGuid CompatibleCollectionState; // Offset: 0x40 | Size: 0x10
};

// Object: Class GeometryCollectionEngine.GeometryCollectionComponent
// Inherited Bytes: 0x6a0 | Struct Size: 0xae0
struct UGeometryCollectionComponent : UMeshComponent {
	// Fields
	struct AChaosSolverActor* ChaosSolverActor; // Offset: 0x6a0 | Size: 0x8
	char pad_0x6A8[0xe0]; // Offset: 0x6a8 | Size: 0xe0
	struct UGeometryCollection* RestCollection; // Offset: 0x788 | Size: 0x8
	struct TArray<struct AFieldSystemActor*> InitializationFields; // Offset: 0x790 | Size: 0x10
	bool Simulating; // Offset: 0x7a0 | Size: 0x1
	char pad_0x7A1[0x7]; // Offset: 0x7a1 | Size: 0x7
	enum class EObjectStateTypeEnum ObjectType; // Offset: 0x7a8 | Size: 0x1
	bool EnableClustering; // Offset: 0x7a9 | Size: 0x1
	char pad_0x7AA[0x2]; // Offset: 0x7aa | Size: 0x2
	int32_t ClusterGroupIndex; // Offset: 0x7ac | Size: 0x4
	int32_t MaxClusterLevel; // Offset: 0x7b0 | Size: 0x4
	char pad_0x7B4[0x4]; // Offset: 0x7b4 | Size: 0x4
	struct TArray<float> DamageThreshold; // Offset: 0x7b8 | Size: 0x10
	enum class EClusterConnectionTypeEnum ClusterConnectionType; // Offset: 0x7c8 | Size: 0x1
	char pad_0x7C9[0x3]; // Offset: 0x7c9 | Size: 0x3
	int32_t CollisionGroup; // Offset: 0x7cc | Size: 0x4
	float CollisionSampleFraction; // Offset: 0x7d0 | Size: 0x4
	float LinearEtherDrag; // Offset: 0x7d4 | Size: 0x4
	float AngularEtherDrag; // Offset: 0x7d8 | Size: 0x4
	char pad_0x7DC[0x4]; // Offset: 0x7dc | Size: 0x4
	struct UChaosPhysicalMaterial* PhysicalMaterial; // Offset: 0x7e0 | Size: 0x8
	enum class EInitialVelocityTypeEnum InitialVelocityType; // Offset: 0x7e8 | Size: 0x1
	char pad_0x7E9[0x3]; // Offset: 0x7e9 | Size: 0x3
	struct FVector InitialLinearVelocity; // Offset: 0x7ec | Size: 0xc
	struct FVector InitialAngularVelocity; // Offset: 0x7f8 | Size: 0xc
	char pad_0x804[0x4]; // Offset: 0x804 | Size: 0x4
	struct FGeomComponentCacheParameters CacheParameters; // Offset: 0x808 | Size: 0x50
	struct FMulticastInlineDelegate NotifyGeometryCollectionPhysicsStateChange; // Offset: 0x858 | Size: 0x10
	struct FMulticastInlineDelegate NotifyGeometryCollectionPhysicsLoadingStateChange; // Offset: 0x868 | Size: 0x10
	char pad_0x878[0x18]; // Offset: 0x878 | Size: 0x18
	struct FMulticastInlineDelegate OnChaosBreakEvent; // Offset: 0x890 | Size: 0x10
	float DesiredCacheTime; // Offset: 0x8a0 | Size: 0x4
	bool CachePlayback; // Offset: 0x8a4 | Size: 0x1
	char pad_0x8A5[0x3]; // Offset: 0x8a5 | Size: 0x3
	struct FMulticastInlineDelegate OnChaosPhysicsCollision; // Offset: 0x8a8 | Size: 0x10
	bool bNotifyBreaks; // Offset: 0x8b8 | Size: 0x1
	bool bNotifyCollisions; // Offset: 0x8b9 | Size: 0x1
	char pad_0x8BA[0x1fe]; // Offset: 0x8ba | Size: 0x1fe
	struct UBodySetup* DummyBodySetup; // Offset: 0xab8 | Size: 0x8
	char pad_0xAC0[0x20]; // Offset: 0xac0 | Size: 0x20

	// Functions

	// Object: Function GeometryCollectionEngine.GeometryCollectionComponent.SetNotifyBreaks
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105c5eacc
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetNotifyBreaks(bool bNewNotifyBreaks);

	// Object: Function GeometryCollectionEngine.GeometryCollectionComponent.ReceivePhysicsCollision
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(1) Size(0x70) ]
	void ReceivePhysicsCollision(struct FChaosPhysicsCollisionInfo& CollisionInfo);

	// Object: DelegateFunction GeometryCollectionEngine.GeometryCollectionComponent.NotifyGeometryCollectionPhysicsStateChange__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10213e738
	// Return & Params: [ Num(1) Size(0x8) ]
	void NotifyGeometryCollectionPhysicsStateChange__DelegateSignature(struct UGeometryCollectionComponent* FracturedComponent);

	// Object: DelegateFunction GeometryCollectionEngine.GeometryCollectionComponent.NotifyGeometryCollectionPhysicsLoadingStateChange__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10213e738
	// Return & Params: [ Num(1) Size(0x8) ]
	void NotifyGeometryCollectionPhysicsLoadingStateChange__DelegateSignature(struct UGeometryCollectionComponent* FracturedComponent);

	// Object: Function GeometryCollectionEngine.GeometryCollectionComponent.ApplyPhysicsField
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105c5eb28
	// Return & Params: [ Num(4) Size(0x18) ]
	void ApplyPhysicsField(bool Enabled, enum class EGeometryCollectionPhysicsTypeEnum Target, struct UFieldSystemMetaData* MetaData, struct UFieldNodeBase* Field);

	// Object: Function GeometryCollectionEngine.GeometryCollectionComponent.ApplyKinematicField
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x105c5ec1c
	// Return & Params: [ Num(2) Size(0x10) ]
	void ApplyKinematicField(float Radius, struct FVector Position);
};

// Object: Class GeometryCollectionEngine.GeometryCollectionDebugDrawActor
// Inherited Bytes: 0x248 | Struct Size: 0x330
struct AGeometryCollectionDebugDrawActor : AActor {
	// Fields
	struct FGeometryCollectionDebugDrawWarningMessage WarningMessage; // Offset: 0x248 | Size: 0x1
	char pad_0x249[0x7]; // Offset: 0x249 | Size: 0x7
	struct FGeometryCollectionDebugDrawActorSelectedRigidBody SelectedRigidBody; // Offset: 0x250 | Size: 0x18
	bool bDebugDrawWholeCollection; // Offset: 0x268 | Size: 0x1
	bool bDebugDrawHierarchy; // Offset: 0x269 | Size: 0x1
	bool bDebugDrawClustering; // Offset: 0x26a | Size: 0x1
	enum class EGeometryCollectionDebugDrawActorHideGeometry HideGeometry; // Offset: 0x26b | Size: 0x1
	bool bShowRigidBodyId; // Offset: 0x26c | Size: 0x1
	bool bShowRigidBodyCollision; // Offset: 0x26d | Size: 0x1
	bool bCollisionAtOrigin; // Offset: 0x26e | Size: 0x1
	bool bShowRigidBodyTransform; // Offset: 0x26f | Size: 0x1
	bool bShowRigidBodyInertia; // Offset: 0x270 | Size: 0x1
	bool bShowRigidBodyVelocity; // Offset: 0x271 | Size: 0x1
	bool bShowRigidBodyForce; // Offset: 0x272 | Size: 0x1
	bool bShowRigidBodyInfos; // Offset: 0x273 | Size: 0x1
	bool bShowTransformIndex; // Offset: 0x274 | Size: 0x1
	bool bShowTransform; // Offset: 0x275 | Size: 0x1
	bool bShowParent; // Offset: 0x276 | Size: 0x1
	bool bShowLevel; // Offset: 0x277 | Size: 0x1
	bool bShowConnectivityEdges; // Offset: 0x278 | Size: 0x1
	bool bShowGeometryIndex; // Offset: 0x279 | Size: 0x1
	bool bShowGeometryTransform; // Offset: 0x27a | Size: 0x1
	bool bShowBoundingBox; // Offset: 0x27b | Size: 0x1
	bool bShowFaces; // Offset: 0x27c | Size: 0x1
	bool bShowFaceIndices; // Offset: 0x27d | Size: 0x1
	bool bShowFaceNormals; // Offset: 0x27e | Size: 0x1
	bool bShowSingleFace; // Offset: 0x27f | Size: 0x1
	int32_t SingleFaceIndex; // Offset: 0x280 | Size: 0x4
	bool bShowVertices; // Offset: 0x284 | Size: 0x1
	bool bShowVertexIndices; // Offset: 0x285 | Size: 0x1
	bool bShowVertexNormals; // Offset: 0x286 | Size: 0x1
	bool bUseActiveVisualization; // Offset: 0x287 | Size: 0x1
	float PointThickness; // Offset: 0x288 | Size: 0x4
	float LineThickness; // Offset: 0x28c | Size: 0x4
	bool bTextShadow; // Offset: 0x290 | Size: 0x1
	char pad_0x291[0x3]; // Offset: 0x291 | Size: 0x3
	float TextScale; // Offset: 0x294 | Size: 0x4
	float NormalScale; // Offset: 0x298 | Size: 0x4
	float AxisScale; // Offset: 0x29c | Size: 0x4
	float ArrowScale; // Offset: 0x2a0 | Size: 0x4
	struct FColor RigidBodyIdColor; // Offset: 0x2a4 | Size: 0x4
	float RigidBodyTransformScale; // Offset: 0x2a8 | Size: 0x4
	struct FColor RigidBodyCollisionColor; // Offset: 0x2ac | Size: 0x4
	struct FColor RigidBodyInertiaColor; // Offset: 0x2b0 | Size: 0x4
	struct FColor RigidBodyVelocityColor; // Offset: 0x2b4 | Size: 0x4
	struct FColor RigidBodyForceColor; // Offset: 0x2b8 | Size: 0x4
	struct FColor RigidBodyInfoColor; // Offset: 0x2bc | Size: 0x4
	struct FColor TransformIndexColor; // Offset: 0x2c0 | Size: 0x4
	float TransformScale; // Offset: 0x2c4 | Size: 0x4
	struct FColor LevelColor; // Offset: 0x2c8 | Size: 0x4
	struct FColor ParentColor; // Offset: 0x2cc | Size: 0x4
	float ConnectivityEdgeThickness; // Offset: 0x2d0 | Size: 0x4
	struct FColor GeometryIndexColor; // Offset: 0x2d4 | Size: 0x4
	float GeometryTransformScale; // Offset: 0x2d8 | Size: 0x4
	struct FColor BoundingBoxColor; // Offset: 0x2dc | Size: 0x4
	struct FColor FaceColor; // Offset: 0x2e0 | Size: 0x4
	struct FColor FaceIndexColor; // Offset: 0x2e4 | Size: 0x4
	struct FColor FaceNormalColor; // Offset: 0x2e8 | Size: 0x4
	struct FColor SingleFaceColor; // Offset: 0x2ec | Size: 0x4
	struct FColor VertexColor; // Offset: 0x2f0 | Size: 0x4
	struct FColor VertexIndexColor; // Offset: 0x2f4 | Size: 0x4
	struct FColor VertexNormalColor; // Offset: 0x2f8 | Size: 0x4
	char pad_0x2FC[0x4]; // Offset: 0x2fc | Size: 0x4
	struct UBillboardComponent* SpriteComponent; // Offset: 0x300 | Size: 0x8
	char pad_0x308[0x28]; // Offset: 0x308 | Size: 0x28
};

// Object: Class GeometryCollectionEngine.GeometryCollectionDebugDrawComponent
// Inherited Bytes: 0xc0 | Struct Size: 0xd8
struct UGeometryCollectionDebugDrawComponent : UActorComponent {
	// Fields
	struct AGeometryCollectionDebugDrawActor* GeometryCollectionDebugDrawActor; // Offset: 0xc0 | Size: 0x8
	struct AGeometryCollectionRenderLevelSetActor* GeometryCollectionRenderLevelSetActor; // Offset: 0xc8 | Size: 0x8
	char pad_0xD0[0x8]; // Offset: 0xd0 | Size: 0x8
};

// Object: Class GeometryCollectionEngine.GeometryCollection
// Inherited Bytes: 0x28 | Struct Size: 0xd0
struct UGeometryCollection : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
	struct TArray<struct UMaterialInterface*> Materials; // Offset: 0x30 | Size: 0x10
	enum class ECollisionTypeEnum CollisionType; // Offset: 0x40 | Size: 0x1
	enum class EImplicitTypeEnum ImplicitType; // Offset: 0x41 | Size: 0x1
	char pad_0x42[0x2]; // Offset: 0x42 | Size: 0x2
	int32_t MinLevelSetResolution; // Offset: 0x44 | Size: 0x4
	int32_t MaxLevelSetResolution; // Offset: 0x48 | Size: 0x4
	int32_t MinClusterLevelSetResolution; // Offset: 0x4c | Size: 0x4
	int32_t MaxClusterLevelSetResolution; // Offset: 0x50 | Size: 0x4
	float CollisionObjectReductionPercentage; // Offset: 0x54 | Size: 0x4
	bool bMassAsDensity; // Offset: 0x58 | Size: 0x1
	char pad_0x59[0x3]; // Offset: 0x59 | Size: 0x3
	float Mass; // Offset: 0x5c | Size: 0x4
	float MinimumMassClamp; // Offset: 0x60 | Size: 0x4
	float CollisionParticlesFraction; // Offset: 0x64 | Size: 0x4
	int32_t MaximumCollisionParticles; // Offset: 0x68 | Size: 0x4
	char pad_0x6C[0x4]; // Offset: 0x6c | Size: 0x4
	struct TArray<struct FGeometryCollectionSizeSpecificData> SizeSpecificData; // Offset: 0x70 | Size: 0x10
	bool EnableRemovePiecesOnFracture; // Offset: 0x80 | Size: 0x1
	char pad_0x81[0x7]; // Offset: 0x81 | Size: 0x7
	struct TArray<struct UMaterialInterface*> RemoveOnFractureMaterials; // Offset: 0x88 | Size: 0x10
	struct FGuid PersistentGuid; // Offset: 0x98 | Size: 0x10
	struct FGuid StateGuid; // Offset: 0xa8 | Size: 0x10
	int32_t BoneSelectedMaterialIndex; // Offset: 0xb8 | Size: 0x4
	char pad_0xBC[0x14]; // Offset: 0xbc | Size: 0x14
};

// Object: Class GeometryCollectionEngine.GeometryCollectionRenderLevelSetActor
// Inherited Bytes: 0x248 | Struct Size: 0x2e0
struct AGeometryCollectionRenderLevelSetActor : AActor {
	// Fields
	struct UVolumeTexture* TargetVolumeTexture; // Offset: 0x248 | Size: 0x8
	struct UMaterial* RayMarchMaterial; // Offset: 0x250 | Size: 0x8
	float SurfaceTolerance; // Offset: 0x258 | Size: 0x4
	float Isovalue; // Offset: 0x25c | Size: 0x4
	bool Enabled; // Offset: 0x260 | Size: 0x1
	bool RenderVolumeBoundingBox; // Offset: 0x261 | Size: 0x1
	char pad_0x262[0x7e]; // Offset: 0x262 | Size: 0x7e
};

// Object: Class GeometryCollectionEngine.SkeletalMeshSimulationComponent
// Inherited Bytes: 0xc0 | Struct Size: 0x148
struct USkeletalMeshSimulationComponent : UActorComponent {
	// Fields
	char pad_0xC0[0x8]; // Offset: 0xc0 | Size: 0x8
	struct UChaosPhysicalMaterial* PhysicalMaterial; // Offset: 0xc8 | Size: 0x8
	struct AChaosSolverActor* ChaosSolverActor; // Offset: 0xd0 | Size: 0x8
	struct UPhysicsAsset* OverridePhysicsAsset; // Offset: 0xd8 | Size: 0x8
	bool bSimulating; // Offset: 0xe0 | Size: 0x1
	bool bNotifyCollisions; // Offset: 0xe1 | Size: 0x1
	enum class EObjectStateTypeEnum ObjectType; // Offset: 0xe2 | Size: 0x1
	char pad_0xE3[0x1]; // Offset: 0xe3 | Size: 0x1
	float Density; // Offset: 0xe4 | Size: 0x4
	float MinMass; // Offset: 0xe8 | Size: 0x4
	float MaxMass; // Offset: 0xec | Size: 0x4
	enum class ECollisionTypeEnum CollisionType; // Offset: 0xf0 | Size: 0x1
	char pad_0xF1[0x3]; // Offset: 0xf1 | Size: 0x3
	float ImplicitShapeParticlesPerUnitArea; // Offset: 0xf4 | Size: 0x4
	int32_t ImplicitShapeMinNumParticles; // Offset: 0xf8 | Size: 0x4
	int32_t ImplicitShapeMaxNumParticles; // Offset: 0xfc | Size: 0x4
	int32_t MinLevelSetResolution; // Offset: 0x100 | Size: 0x4
	int32_t MaxLevelSetResolution; // Offset: 0x104 | Size: 0x4
	int32_t CollisionGroup; // Offset: 0x108 | Size: 0x4
	enum class EInitialVelocityTypeEnum InitialVelocityType; // Offset: 0x10c | Size: 0x1
	char pad_0x10D[0x3]; // Offset: 0x10d | Size: 0x3
	struct FVector InitialLinearVelocity; // Offset: 0x110 | Size: 0xc
	struct FVector InitialAngularVelocity; // Offset: 0x11c | Size: 0xc
	struct FMulticastInlineDelegate OnChaosPhysicsCollision; // Offset: 0x128 | Size: 0x10
	char pad_0x138[0x10]; // Offset: 0x138 | Size: 0x10

	// Functions

	// Object: Function GeometryCollectionEngine.SkeletalMeshSimulationComponent.ReceivePhysicsCollision
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(1) Size(0x70) ]
	void ReceivePhysicsCollision(struct FChaosPhysicsCollisionInfo& CollisionInfo);
};

// Object: Class GeometryCollectionEngine.StaticMeshSimulationComponent
// Inherited Bytes: 0xc0 | Struct Size: 0x148
struct UStaticMeshSimulationComponent : UActorComponent {
	// Fields
	char pad_0xC0[0x8]; // Offset: 0xc0 | Size: 0x8
	bool Simulating; // Offset: 0xc8 | Size: 0x1
	bool bNotifyCollisions; // Offset: 0xc9 | Size: 0x1
	enum class EObjectStateTypeEnum ObjectType; // Offset: 0xca | Size: 0x1
	char pad_0xCB[0x1]; // Offset: 0xcb | Size: 0x1
	float Mass; // Offset: 0xcc | Size: 0x4
	enum class ECollisionTypeEnum CollisionType; // Offset: 0xd0 | Size: 0x1
	enum class EImplicitTypeEnum ImplicitType; // Offset: 0xd1 | Size: 0x1
	char pad_0xD2[0x2]; // Offset: 0xd2 | Size: 0x2
	int32_t MinLevelSetResolution; // Offset: 0xd4 | Size: 0x4
	int32_t MaxLevelSetResolution; // Offset: 0xd8 | Size: 0x4
	enum class EInitialVelocityTypeEnum InitialVelocityType; // Offset: 0xdc | Size: 0x1
	char pad_0xDD[0x3]; // Offset: 0xdd | Size: 0x3
	struct FVector InitialLinearVelocity; // Offset: 0xe0 | Size: 0xc
	struct FVector InitialAngularVelocity; // Offset: 0xec | Size: 0xc
	float DamageThreshold; // Offset: 0xf8 | Size: 0x4
	char pad_0xFC[0x4]; // Offset: 0xfc | Size: 0x4
	struct UChaosPhysicalMaterial* PhysicalMaterial; // Offset: 0x100 | Size: 0x8
	struct AChaosSolverActor* ChaosSolverActor; // Offset: 0x108 | Size: 0x8
	struct FMulticastInlineDelegate OnChaosPhysicsCollision; // Offset: 0x110 | Size: 0x10
	char pad_0x120[0x10]; // Offset: 0x120 | Size: 0x10
	struct TArray<struct UPrimitiveComponent*> SimulatedComponents; // Offset: 0x130 | Size: 0x10
	char pad_0x140[0x8]; // Offset: 0x140 | Size: 0x8

	// Functions

	// Object: Function GeometryCollectionEngine.StaticMeshSimulationComponent.ReceivePhysicsCollision
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(1) Size(0x70) ]
	void ReceivePhysicsCollision(struct FChaosPhysicsCollisionInfo& CollisionInfo);

	// Object: Function GeometryCollectionEngine.StaticMeshSimulationComponent.ForceRecreatePhysicsState
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105c5f518
	// Return & Params: [ Num(0) Size(0x0) ]
	void ForceRecreatePhysicsState();
};

