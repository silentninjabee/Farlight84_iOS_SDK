#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct GeometryCollectionEngine.GeomComponentCacheParameters
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FGeomComponentCacheParameters {
	// Fields
	enum class EGeometryCollectionCacheType CacheMode; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x7]; // Offset: 0x1 | Size: 0x7
	struct UGeometryCollectionCache* TargetCache; // Offset: 0x8 | Size: 0x8
	float ReverseCacheBeginTime; // Offset: 0x10 | Size: 0x4
	bool SaveCollisionData; // Offset: 0x14 | Size: 0x1
	bool DoGenerateCollisionData; // Offset: 0x15 | Size: 0x1
	char pad_0x16[0x2]; // Offset: 0x16 | Size: 0x2
	int32_t CollisionDataSizeMax; // Offset: 0x18 | Size: 0x4
	bool DoCollisionDataSpatialHash; // Offset: 0x1c | Size: 0x1
	char pad_0x1D[0x3]; // Offset: 0x1d | Size: 0x3
	float CollisionDataSpatialHashRadius; // Offset: 0x20 | Size: 0x4
	int32_t MaxCollisionPerCell; // Offset: 0x24 | Size: 0x4
	bool SaveBreakingData; // Offset: 0x28 | Size: 0x1
	bool DoGenerateBreakingData; // Offset: 0x29 | Size: 0x1
	char pad_0x2A[0x2]; // Offset: 0x2a | Size: 0x2
	int32_t BreakingDataSizeMax; // Offset: 0x2c | Size: 0x4
	bool DoBreakingDataSpatialHash; // Offset: 0x30 | Size: 0x1
	char pad_0x31[0x3]; // Offset: 0x31 | Size: 0x3
	float BreakingDataSpatialHashRadius; // Offset: 0x34 | Size: 0x4
	int32_t MaxBreakingPerCell; // Offset: 0x38 | Size: 0x4
	bool SaveTrailingData; // Offset: 0x3c | Size: 0x1
	bool DoGenerateTrailingData; // Offset: 0x3d | Size: 0x1
	char pad_0x3E[0x2]; // Offset: 0x3e | Size: 0x2
	int32_t TrailingDataSizeMax; // Offset: 0x40 | Size: 0x4
	float TrailingMinSpeedThreshold; // Offset: 0x44 | Size: 0x4
	float TrailingMinVolumeThreshold; // Offset: 0x48 | Size: 0x4
	char pad_0x4C[0x4]; // Offset: 0x4c | Size: 0x4
};

// Object: ScriptStruct GeometryCollectionEngine.ChaosCollisionEventData
// Inherited Bytes: 0x0 | Struct Size: 0x58
struct FChaosCollisionEventData {
	// Fields
	struct FVector Location; // Offset: 0x0 | Size: 0xc
	struct FVector Normal; // Offset: 0xc | Size: 0xc
	struct FVector Velocity1; // Offset: 0x18 | Size: 0xc
	struct FVector Velocity2; // Offset: 0x24 | Size: 0xc
	float Mass1; // Offset: 0x30 | Size: 0x4
	float Mass2; // Offset: 0x34 | Size: 0x4
	struct FVector Impulse; // Offset: 0x38 | Size: 0xc
	char pad_0x44[0x14]; // Offset: 0x44 | Size: 0x14
};

// Object: ScriptStruct GeometryCollectionEngine.ChaosBreakingEventData
// Inherited Bytes: 0x0 | Struct Size: 0x1c
struct FChaosBreakingEventData {
	// Fields
	struct FVector Location; // Offset: 0x0 | Size: 0xc
	struct FVector Velocity; // Offset: 0xc | Size: 0xc
	float Mass; // Offset: 0x18 | Size: 0x4
};

// Object: ScriptStruct GeometryCollectionEngine.ChaosTrailingEventData
// Inherited Bytes: 0x0 | Struct Size: 0x2c
struct FChaosTrailingEventData {
	// Fields
	struct FVector Location; // Offset: 0x0 | Size: 0xc
	struct FVector Velocity; // Offset: 0xc | Size: 0xc
	struct FVector AngularVelocity; // Offset: 0x18 | Size: 0xc
	float Mass; // Offset: 0x24 | Size: 0x4
	int32_t ParticleIndex; // Offset: 0x28 | Size: 0x4
};

// Object: ScriptStruct GeometryCollectionEngine.ChaosBreakingEventRequestSettings
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FChaosBreakingEventRequestSettings {
	// Fields
	int32_t MaxNumberOfResults; // Offset: 0x0 | Size: 0x4
	float MinRadius; // Offset: 0x4 | Size: 0x4
	float MinSpeed; // Offset: 0x8 | Size: 0x4
	float MinMass; // Offset: 0xc | Size: 0x4
	float MaxDistance; // Offset: 0x10 | Size: 0x4
	enum class EChaosBreakingSortMethod SortMethod; // Offset: 0x14 | Size: 0x1
	char pad_0x15[0x3]; // Offset: 0x15 | Size: 0x3
};

// Object: ScriptStruct GeometryCollectionEngine.ChaosCollisionEventRequestSettings
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FChaosCollisionEventRequestSettings {
	// Fields
	int32_t MaxNumberResults; // Offset: 0x0 | Size: 0x4
	float MinMass; // Offset: 0x4 | Size: 0x4
	float MinSpeed; // Offset: 0x8 | Size: 0x4
	float MinImpulse; // Offset: 0xc | Size: 0x4
	float MaxDistance; // Offset: 0x10 | Size: 0x4
	enum class EChaosCollisionSortMethod SortMethod; // Offset: 0x14 | Size: 0x1
	char pad_0x15[0x3]; // Offset: 0x15 | Size: 0x3
};

// Object: ScriptStruct GeometryCollectionEngine.ChaosTrailingEventRequestSettings
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FChaosTrailingEventRequestSettings {
	// Fields
	int32_t MaxNumberOfResults; // Offset: 0x0 | Size: 0x4
	float MinMass; // Offset: 0x4 | Size: 0x4
	float MinSpeed; // Offset: 0x8 | Size: 0x4
	float MinAngularSpeed; // Offset: 0xc | Size: 0x4
	float MaxDistance; // Offset: 0x10 | Size: 0x4
	enum class EChaosTrailingSortMethod SortMethod; // Offset: 0x14 | Size: 0x1
	char pad_0x15[0x3]; // Offset: 0x15 | Size: 0x3
};

// Object: ScriptStruct GeometryCollectionEngine.GeometryCollectionDebugDrawActorSelectedRigidBody
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FGeometryCollectionDebugDrawActorSelectedRigidBody {
	// Fields
	int32_t ID; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct AChaosSolverActor* Solver; // Offset: 0x8 | Size: 0x8
	struct AGeometryCollectionActor* GeometryCollection; // Offset: 0x10 | Size: 0x8
};

// Object: ScriptStruct GeometryCollectionEngine.GeometryCollectionDebugDrawWarningMessage
// Inherited Bytes: 0x0 | Struct Size: 0x1
struct FGeometryCollectionDebugDrawWarningMessage {
	// Fields
	char pad_0x0[0x1]; // Offset: 0x0 | Size: 0x1
};

// Object: ScriptStruct GeometryCollectionEngine.GeometryCollectionSizeSpecificData
// Inherited Bytes: 0x0 | Struct Size: 0x24
struct FGeometryCollectionSizeSpecificData {
	// Fields
	float MaxSize; // Offset: 0x0 | Size: 0x4
	enum class ECollisionTypeEnum CollisionType; // Offset: 0x4 | Size: 0x1
	enum class EImplicitTypeEnum ImplicitType; // Offset: 0x5 | Size: 0x1
	char pad_0x6[0x2]; // Offset: 0x6 | Size: 0x2
	int32_t MinLevelSetResolution; // Offset: 0x8 | Size: 0x4
	int32_t MaxLevelSetResolution; // Offset: 0xc | Size: 0x4
	int32_t MinClusterLevelSetResolution; // Offset: 0x10 | Size: 0x4
	int32_t MaxClusterLevelSetResolution; // Offset: 0x14 | Size: 0x4
	int32_t CollisionObjectReductionPercentage; // Offset: 0x18 | Size: 0x4
	float CollisionParticlesFraction; // Offset: 0x1c | Size: 0x4
	int32_t MaximumCollisionParticles; // Offset: 0x20 | Size: 0x4
};

