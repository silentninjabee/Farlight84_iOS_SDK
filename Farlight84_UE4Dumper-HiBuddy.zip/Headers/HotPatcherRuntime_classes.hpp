#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class HotPatcherRuntime.FlibAssetManageHelper
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UFlibAssetManageHelper : UBlueprintFunctionLibrary {
	// Functions

	// Object: Function HotPatcherRuntime.FlibAssetManageHelper.SaveStringToFile
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1035f50b8
	// Return & Params: [ Num(3) Size(0x21) ]
	bool SaveStringToFile(struct FString InFile, struct FString inString);

	// Object: Function HotPatcherRuntime.FlibAssetManageHelper.PackagePathToFilename
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1035f5b18
	// Return & Params: [ Num(2) Size(0x20) ]
	struct FString PackagePathToFilename(struct FString InPackagePath);

	// Object: Function HotPatcherRuntime.FlibAssetManageHelper.ModuleIsEnabled
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1035f4e44
	// Return & Params: [ Num(2) Size(0x11) ]
	bool ModuleIsEnabled(struct FString InModuleName);

	// Object: Function HotPatcherRuntime.FlibAssetManageHelper.LongPackageNameToPackagePath
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1035f5a24
	// Return & Params: [ Num(2) Size(0x20) ]
	struct FString LongPackageNameToPackagePath(struct FString InLongPackageName);

	// Object: Function HotPatcherRuntime.FlibAssetManageHelper.LoadFileToString
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1035f5038
	// Return & Params: [ Num(3) Size(0x21) ]
	bool LoadFileToString(struct FString InFile, struct FString& OutString);

	// Object: Function HotPatcherRuntime.FlibAssetManageHelper.GetSpecifyAssetDetail
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x1035f5638
	// Return & Params: [ Num(3) Size(0x29) ]
	bool GetSpecifyAssetDetail(struct FString InLongPackageName, struct FAssetDetail& OutAssetDetail);

	// Object: Function HotPatcherRuntime.FlibAssetManageHelper.GetRedirectorList
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x1035f56dc
	// Return & Params: [ Num(3) Size(0x21) ]
	bool GetRedirectorList(struct TArray<struct FString>& InFilterPackagePaths, struct TArray<struct FAssetDetail>& OutRedirector);

	// Object: Function HotPatcherRuntime.FlibAssetManageHelper.GetPluginModuleAbsDir
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1035f4d44
	// Return & Params: [ Num(3) Size(0x21) ]
	bool GetPluginModuleAbsDir(struct FString InPluginModuleName, struct FString& OutPath);

	// Object: Function HotPatcherRuntime.FlibAssetManageHelper.GetModuleNameByRelativePath
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1035f4ea4
	// Return & Params: [ Num(3) Size(0x21) ]
	bool GetModuleNameByRelativePath(struct FString InRelativePath, struct FString& OutModuleName);

	// Object: Function HotPatcherRuntime.FlibAssetManageHelper.GetEnableModuleAbsDir
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1035f4dc4
	// Return & Params: [ Num(3) Size(0x21) ]
	bool GetEnableModuleAbsDir(struct FString InModuleName, struct FString& OutPath);

	// Object: Function HotPatcherRuntime.FlibAssetManageHelper.GetAssetReferenceEx
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x1035f5768
	// Return & Params: [ Num(4) Size(0x39) ]
	bool GetAssetReferenceEx(struct FAssetDetail& InAsset, struct TArray<enum class EAssetRegistryDependencyTypeEx>& SearchAssetDepTypes, struct TArray<struct FAssetDetail>& OutRefAsset);

	// Object: Function HotPatcherRuntime.FlibAssetManageHelper.GetAssetPackageGUID
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1035f599c
	// Return & Params: [ Num(3) Size(0x19) ]
	bool GetAssetPackageGUID(struct FString InPackagePath, struct FName& OutGUID);

	// Object: Function HotPatcherRuntime.FlibAssetManageHelper.GetAllEnabledModuleName
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1035f4f24
	// Return & Params: [ Num(1) Size(0x50) ]
	void GetAllEnabledModuleName(struct TMap<struct FString, struct FString>& OutModules);

	// Object: Function HotPatcherRuntime.FlibAssetManageHelper.FindFilesRecursive
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1035f4c78
	// Return & Params: [ Num(4) Size(0x22) ]
	bool FindFilesRecursive(struct FString InStartDir, struct TArray<struct FString>& OutFileList, bool InRecursive);

	// Object: Function HotPatcherRuntime.FlibAssetManageHelper.FilterNoRefAssetsWithIgnoreFilter
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x1035f5404
	// Return & Params: [ Num(4) Size(0x40) ]
	void FilterNoRefAssetsWithIgnoreFilter(struct TArray<struct FAssetDetail>& InAssetsDetail, struct TArray<struct FString>& InIgnoreFilters, struct TArray<struct FAssetDetail>& OutHasRefAssetsDetail, struct TArray<struct FAssetDetail>& OutDontHasRefAssetsDetail);

	// Object: Function HotPatcherRuntime.FlibAssetManageHelper.FilterNoRefAssets
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x1035f5544
	// Return & Params: [ Num(3) Size(0x30) ]
	void FilterNoRefAssets(struct TArray<struct FAssetDetail>& InAssetsDetail, struct TArray<struct FAssetDetail>& OutHasRefAssetsDetail, struct TArray<struct FAssetDetail>& OutDontHasRefAssetsDetail);

	// Object: Function HotPatcherRuntime.FlibAssetManageHelper.FilenameToPackagePath
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1035f5a98
	// Return & Params: [ Num(3) Size(0x21) ]
	bool FilenameToPackagePath(struct FString InAbsPath, struct FString& OutPackagePath);

	// Object: Function HotPatcherRuntime.FlibAssetManageHelper.ExportCookPakCommandToFile
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1035f5134
	// Return & Params: [ Num(3) Size(0x21) ]
	bool ExportCookPakCommandToFile(struct TArray<struct FString>& InCommand, struct FString InFile);

	// Object: Function HotPatcherRuntime.FlibAssetManageHelper.ConvRelativeDirToAbsDir
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1035f4fb8
	// Return & Params: [ Num(3) Size(0x21) ]
	bool ConvRelativeDirToAbsDir(struct FString InRelativePath, struct FString& OutAbsPath);

	// Object: Function HotPatcherRuntime.FlibAssetManageHelper.ConvLongPackageNameToCookedPath
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1035f51c0
	// Return & Params: [ Num(6) Size(0x51) ]
	bool ConvLongPackageNameToCookedPath(struct FString InProjectAbsDir, struct FString InPlatformName, struct FString InLongPackageName, struct TArray<struct FString>& OutCookedAssetPath, struct TArray<struct FString>& OutCookedAssetRelativePath);

	// Object: Function HotPatcherRuntime.FlibAssetManageHelper.CombineAssetsDetailAsFAssetDepenInfo
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x1035f5320
	// Return & Params: [ Num(3) Size(0x61) ]
	bool CombineAssetsDetailAsFAssetDepenInfo(struct TArray<struct FAssetDetail>& InAssetsDetailList, struct FAssetDependenciesInfo& OutAssetInfo);

	// Object: Function HotPatcherRuntime.FlibAssetManageHelper.CombineAssetDependencies
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x1035f5860
	// Return & Params: [ Num(3) Size(0xf0) ]
	struct FAssetDependenciesInfo CombineAssetDependencies(struct FAssetDependenciesInfo& A, struct FAssetDependenciesInfo& B);
};

// Object: Class HotPatcherRuntime.FlibPakHelper
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UFlibPakHelper : UBlueprintFunctionLibrary {
	// Functions

	// Object: Function HotPatcherRuntime.FlibPakHelper.UnMountPak
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1035fcc38
	// Return & Params: [ Num(2) Size(0x11) ]
	bool UnMountPak(struct FString PakPath);

	// Object: Function HotPatcherRuntime.FlibPakHelper.ScanPlatformDirectory
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1035fc9e0
	// Return & Params: [ Num(6) Size(0x29) ]
	bool ScanPlatformDirectory(struct FString InRelativePath, bool bIncludeFile, bool bIncludeDir, bool bRecursively, struct TArray<struct FString>& OutResault);

	// Object: Function HotPatcherRuntime.FlibPakHelper.ScanExtenPakFiles
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1035fc860
	// Return & Params: [ Num(1) Size(0x10) ]
	struct TArray<struct FString> ScanExtenPakFiles();

	// Object: Function HotPatcherRuntime.FlibPakHelper.ScanExtenFilesInDirectory
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1035fc8b0
	// Return & Params: [ Num(5) Size(0x39) ]
	bool ScanExtenFilesInDirectory(struct FString InRelativePath, struct FString InExtenPostfix, bool InRecursively, struct TArray<struct FString>& OutFiles);

	// Object: Function HotPatcherRuntime.FlibPakHelper.ScanAllVersionDescribleFiles
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1035fc888
	// Return & Params: [ Num(1) Size(0x10) ]
	struct TArray<struct FString> ScanAllVersionDescribleFiles();

	// Object: Function HotPatcherRuntime.FlibPakHelper.ReloadShaderbytecode
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1035fc76c
	// Return & Params: [ Num(0) Size(0x0) ]
	void ReloadShaderbytecode();

	// Object: Function HotPatcherRuntime.FlibPakHelper.OpenPSO
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1035fc77c
	// Return & Params: [ Num(2) Size(0x11) ]
	bool OpenPSO(struct FString Name);

	// Object: Function HotPatcherRuntime.FlibPakHelper.MountPak
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1035fcc94
	// Return & Params: [ Num(4) Size(0x29) ]
	bool MountPak(struct FString PakPath, int32_t PakOrder, struct FString InMountPoint);

	// Object: Function HotPatcherRuntime.FlibPakHelper.LoadShaderbytecode
	// Flags: [Final|Exec|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1035fc6d4
	// Return & Params: [ Num(3) Size(0x21) ]
	bool LoadShaderbytecode(struct FString LibraryName, struct FString LibraryDir);

	// Object: Function HotPatcherRuntime.FlibPakHelper.LoadAssetRegistry
	// Flags: [Final|Exec|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1035fc5ec
	// Return & Params: [ Num(3) Size(0x21) ]
	bool LoadAssetRegistry(struct FString LibraryName, struct FString LibraryDir);

	// Object: Function HotPatcherRuntime.FlibPakHelper.GetPakOrderByPakPath
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1035fc7d8
	// Return & Params: [ Num(2) Size(0x14) ]
	int32_t GetPakOrderByPakPath(struct FString PakFile);

	// Object: Function HotPatcherRuntime.FlibPakHelper.GetAllMountedPaks
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1035fc838
	// Return & Params: [ Num(1) Size(0x10) ]
	struct TArray<struct FString> GetAllMountedPaks();

	// Object: Function HotPatcherRuntime.FlibPakHelper.ExecMountPak
	// Flags: [Final|Exec|Native|Static|Public]
	// Offset: 0x1035fcd74
	// Return & Params: [ Num(3) Size(0x28) ]
	void ExecMountPak(struct FString InPakPath, int32_t InPakOrder, struct FString InMountPoint);

	// Object: Function HotPatcherRuntime.FlibPakHelper.CreateFileByBytes
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1035fcb44
	// Return & Params: [ Num(4) Size(0x25) ]
	bool CreateFileByBytes(struct FString InFile, struct TArray<char>& InBytes, int32_t InWriteFlag);

	// Object: Function HotPatcherRuntime.FlibPakHelper.CloseShaderbytecode
	// Flags: [Final|Exec|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1035fc684
	// Return & Params: [ Num(1) Size(0x10) ]
	void CloseShaderbytecode(struct FString LibraryName);
};

// Object: Class HotPatcherRuntime.FlibPatchParserHelper
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UFlibPatchParserHelper : UBlueprintFunctionLibrary {
	// Functions

	// Object: Function HotPatcherRuntime.FlibPatchParserHelper.ReloadShaderbytecode
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1035fd390
	// Return & Params: [ Num(0) Size(0x0) ]
	void ReloadShaderbytecode();

	// Object: Function HotPatcherRuntime.FlibPatchParserHelper.LoadShaderbytecode
	// Flags: [Final|Exec|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1035fd2f8
	// Return & Params: [ Num(3) Size(0x21) ]
	bool LoadShaderbytecode(struct FString LibraryName, struct FString LibraryDir);

	// Object: Function HotPatcherRuntime.FlibPatchParserHelper.HashStringWithSHA1
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1035fd5a8
	// Return & Params: [ Num(2) Size(0x20) ]
	struct FString HashStringWithSHA1(struct FString inString);

	// Object: Function HotPatcherRuntime.FlibPatchParserHelper.GetProjectName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1035fdfec
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetProjectName();

	// Object: Function HotPatcherRuntime.FlibPatchParserHelper.GetProjectIniFiles
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1035fd468
	// Return & Params: [ Num(3) Size(0x30) ]
	struct TArray<struct FString> GetProjectIniFiles(struct FString InProjectDir, struct FString InPlatformName);

	// Object: Function HotPatcherRuntime.FlibPatchParserHelper.GetProjectFilePath
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1035fdfa4
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetProjectFilePath();

	// Object: Function HotPatcherRuntime.FlibPatchParserHelper.GetPakFileInfo
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1035fd998
	// Return & Params: [ Num(3) Size(0x39) ]
	bool GetPakFileInfo(struct FString InFile, struct FPakFileInfo& OutFileInfo);

	// Object: Function HotPatcherRuntime.FlibPatchParserHelper.GetIniConfigs
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1035fd508
	// Return & Params: [ Num(3) Size(0x30) ]
	struct TArray<struct FString> GetIniConfigs(struct FString InSearchDir, struct FString InPlatformName);

	// Object: Function HotPatcherRuntime.FlibPatchParserHelper.GetEngineConfigs
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1035fd404
	// Return & Params: [ Num(2) Size(0x20) ]
	struct TArray<struct FString> GetEngineConfigs(struct FString InPlatformName);

	// Object: Function HotPatcherRuntime.FlibPatchParserHelper.GetEnabledPluginConfigs
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1035fd3a0
	// Return & Params: [ Num(2) Size(0x20) ]
	struct TArray<struct FString> GetEnabledPluginConfigs(struct FString InPlatformName);

	// Object: Function HotPatcherRuntime.FlibPatchParserHelper.GetCookedShaderBytecodeFiles
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1035fd638
	// Return & Params: [ Num(7) Size(0x49) ]
	bool GetCookedShaderBytecodeFiles(struct FString InProjectAbsDir, struct FString InProjectName, struct FString InPlatformName, bool InGalobalBytecode, bool InProjectBytecode, struct TArray<struct FString>& OutFiles);

	// Object: Function HotPatcherRuntime.FlibPatchParserHelper.GetCookedGlobalShaderCacheFiles
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1035fd8f8
	// Return & Params: [ Num(3) Size(0x30) ]
	struct TArray<struct FString> GetCookedGlobalShaderCacheFiles(struct FString InProjectDir, struct FString InPlatformName);

	// Object: Function HotPatcherRuntime.FlibPatchParserHelper.GetCookedAssetRegistryFiles
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1035fd7d8
	// Return & Params: [ Num(5) Size(0x41) ]
	bool GetCookedAssetRegistryFiles(struct FString InProjectAbsDir, struct FString InProjectName, struct FString InPlatformName, struct FString& OutFiles);

	// Object: Function HotPatcherRuntime.FlibPatchParserHelper.GetAvailableMaps
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1035fe034
	// Return & Params: [ Num(5) Size(0x28) ]
	struct TArray<struct FString> GetAvailableMaps(struct FString GameName, bool IncludeEngineMaps, bool IncludePluginMaps, bool Sorted);

	// Object: Function HotPatcherRuntime.FlibPatchParserHelper.GetAllExFilesByPlatform
	// Flags: [Final|Native|Static|Public|HasOutParms]
	// Offset: 0x1035fda50
	// Return & Params: [ Num(3) Size(0x48) ]
	struct FPlatformExternFiles GetAllExFilesByPlatform(struct FPlatformExternAssets& InPlatformConf, bool InGeneratedHash);

	// Object: Function HotPatcherRuntime.FlibPatchParserHelper.DiffVersionAssets
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1035fdd48
	// Return & Params: [ Num(6) Size(0x191) ]
	bool DiffVersionAssets(struct FAssetDependenciesInfo& InNewVersion, struct FAssetDependenciesInfo& InBaseVersion, struct FAssetDependenciesInfo& OutAddAsset, struct FAssetDependenciesInfo& OutModifyAsset, struct FAssetDependenciesInfo& OutDeleteAsset);

	// Object: Function HotPatcherRuntime.FlibPatchParserHelper.DiffVersionAllPlatformExFiles
	// Flags: [Final|Native|Static|Public|HasOutParms]
	// Offset: 0x1035fdb7c
	// Return & Params: [ Num(4) Size(0x281) ]
	bool DiffVersionAllPlatformExFiles(struct FHotPatcherVersion& InBaseVersion, struct FHotPatcherVersion& InNewVersion, struct TMap<enum class ETargetPlatform, struct FPatchVersionExternDiff>& OutDiff);

	// Object: Function HotPatcherRuntime.FlibPatchParserHelper.CloseShaderbytecode
	// Flags: [Final|Exec|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1035fd2a8
	// Return & Params: [ Num(1) Size(0x10) ]
	void CloseShaderbytecode(struct FString LibraryName);
};

// Object: Class HotPatcherRuntime.FlibShaderPipelineCacheHelper
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UFlibShaderPipelineCacheHelper : UBlueprintFunctionLibrary {
	// Functions

	// Object: Function HotPatcherRuntime.FlibShaderPipelineCacheHelper.SavePipelineFileCache
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1035fe7b0
	// Return & Params: [ Num(2) Size(0x2) ]
	bool SavePipelineFileCache(enum class EPSOSaveMode Mode);

	// Object: Function HotPatcherRuntime.FlibShaderPipelineCacheHelper.LoadShaderPipelineCache
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1035fe868
	// Return & Params: [ Num(2) Size(0x11) ]
	bool LoadShaderPipelineCache(struct FString Name);

	// Object: Function HotPatcherRuntime.FlibShaderPipelineCacheHelper.IsEnabledUsePSO
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1035fe6cc
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsEnabledUsePSO();

	// Object: Function HotPatcherRuntime.FlibShaderPipelineCacheHelper.IsEnabledSaveBoundPSOLog
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1035fe684
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsEnabledSaveBoundPSOLog();

	// Object: Function HotPatcherRuntime.FlibShaderPipelineCacheHelper.IsEnabledLogPSO
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1035fe6a8
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsEnabledLogPSO();

	// Object: Function HotPatcherRuntime.FlibShaderPipelineCacheHelper.EnableShaderPipelineCache
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1035fe808
	// Return & Params: [ Num(2) Size(0x2) ]
	bool EnableShaderPipelineCache(bool bEnable);

	// Object: Function HotPatcherRuntime.FlibShaderPipelineCacheHelper.EnableSaveBoundPSOLog
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1035fe6f0
	// Return & Params: [ Num(2) Size(0x2) ]
	bool EnableSaveBoundPSOLog(bool bEnable);

	// Object: Function HotPatcherRuntime.FlibShaderPipelineCacheHelper.EnableLogPSO
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1035fe750
	// Return & Params: [ Num(2) Size(0x2) ]
	bool EnableLogPSO(bool bEnable);
};

// Object: Class HotPatcherRuntime.MountListener
// Inherited Bytes: 0x28 | Struct Size: 0x98
struct UMountListener : UObject {
	// Fields
	struct FMulticastInlineDelegate OnMountPakDelegate; // Offset: 0x28 | Size: 0x10
	struct FMulticastInlineDelegate OnUnMountPakDelegate; // Offset: 0x38 | Size: 0x10
	char pad_0x48[0x50]; // Offset: 0x48 | Size: 0x50

	// Functions

	// Object: Function HotPatcherRuntime.MountListener.Init
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x103604e04
	// Return & Params: [ Num(0) Size(0x0) ]
	void Init();
};

// Object: Class HotPatcherRuntime.ScopedSlowTaskContext
// Inherited Bytes: 0x28 | Struct Size: 0x30
struct UScopedSlowTaskContext : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
};

