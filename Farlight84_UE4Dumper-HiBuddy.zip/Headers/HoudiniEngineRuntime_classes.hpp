#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class HoudiniEngineRuntime.HoudiniAssetActor
// Inherited Bytes: 0x248 | Struct Size: 0x250
struct AHoudiniAssetActor : AActor {
	// Fields
	struct UHoudiniAssetComponent* HoudiniAssetComponent; // Offset: 0x248 | Size: 0x8
};

// Object: Class HoudiniEngineRuntime.HiddenHoudiniAssetActor
// Inherited Bytes: 0x250 | Struct Size: 0x250
struct AHiddenHoudiniAssetActor : AHoudiniAssetActor {
};

// Object: Class HoudiniEngineRuntime.HoudiniParameter
// Inherited Bytes: 0x28 | Struct Size: 0x108
struct UHoudiniParameter : UObject {
	// Fields
	struct FString Name; // Offset: 0x28 | Size: 0x10
	struct FString Label; // Offset: 0x38 | Size: 0x10
	enum class EHoudiniParameterType ParmType; // Offset: 0x48 | Size: 0x1
	char pad_0x49[0x3]; // Offset: 0x49 | Size: 0x3
	uint32_t TupleSize; // Offset: 0x4c | Size: 0x4
	int32_t NodeId; // Offset: 0x50 | Size: 0x4
	int32_t ParmId; // Offset: 0x54 | Size: 0x4
	int32_t ParentParmId; // Offset: 0x58 | Size: 0x4
	int32_t ChildIndex; // Offset: 0x5c | Size: 0x4
	bool bIsVisible; // Offset: 0x60 | Size: 0x1
	bool bIsParentFolderVisible; // Offset: 0x61 | Size: 0x1
	bool bIsDisabled; // Offset: 0x62 | Size: 0x1
	bool bHasChanged; // Offset: 0x63 | Size: 0x1
	bool bNeedsToTriggerUpdate; // Offset: 0x64 | Size: 0x1
	bool bIsDefault; // Offset: 0x65 | Size: 0x1
	bool bIsSpare; // Offset: 0x66 | Size: 0x1
	bool bJoinNext; // Offset: 0x67 | Size: 0x1
	bool bIsChildOfMultiParm; // Offset: 0x68 | Size: 0x1
	bool bIsDirectChildOfMultiParm; // Offset: 0x69 | Size: 0x1
	bool bPendingRevertToDefault; // Offset: 0x6a | Size: 0x1
	char pad_0x6B[0x5]; // Offset: 0x6b | Size: 0x5
	struct TArray<int32_t> TuplePendingRevertToDefault; // Offset: 0x70 | Size: 0x10
	struct FString Help; // Offset: 0x80 | Size: 0x10
	uint32_t TagCount; // Offset: 0x90 | Size: 0x4
	int32_t ValueIndex; // Offset: 0x94 | Size: 0x4
	bool bHasExpression; // Offset: 0x98 | Size: 0x1
	bool bShowExpression; // Offset: 0x99 | Size: 0x1
	char pad_0x9A[0x6]; // Offset: 0x9a | Size: 0x6
	struct FString ParamExpression; // Offset: 0xa0 | Size: 0x10
	struct TMap<struct FString, struct FString> Tags; // Offset: 0xb0 | Size: 0x50
	bool bAutoUpdate; // Offset: 0x100 | Size: 0x1
	char pad_0x101[0x7]; // Offset: 0x101 | Size: 0x7
};

// Object: Class HoudiniEngineRuntime.HoudiniParameterFloat
// Inherited Bytes: 0x108 | Struct Size: 0x158
struct UHoudiniParameterFloat : UHoudiniParameter {
	// Fields
	struct TArray<float> Values; // Offset: 0x108 | Size: 0x10
	struct TArray<float> DefaultValues; // Offset: 0x118 | Size: 0x10
	struct FString Unit; // Offset: 0x128 | Size: 0x10
	bool bNoSwap; // Offset: 0x138 | Size: 0x1
	bool bHasMin; // Offset: 0x139 | Size: 0x1
	bool bHasMax; // Offset: 0x13a | Size: 0x1
	bool bHasUIMin; // Offset: 0x13b | Size: 0x1
	bool bHasUIMax; // Offset: 0x13c | Size: 0x1
	bool bIsLogarithmic; // Offset: 0x13d | Size: 0x1
	char pad_0x13E[0x2]; // Offset: 0x13e | Size: 0x2
	float Min; // Offset: 0x140 | Size: 0x4
	float Max; // Offset: 0x144 | Size: 0x4
	float UIMin; // Offset: 0x148 | Size: 0x4
	float UIMax; // Offset: 0x14c | Size: 0x4
	bool bIsChildOfRamp; // Offset: 0x150 | Size: 0x1
	char pad_0x151[0x7]; // Offset: 0x151 | Size: 0x7
};

// Object: Class HoudiniEngineRuntime.HoudiniAssetStateEvents
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UHoudiniAssetStateEvents : UInterface {
};

// Object: Class HoudiniEngineRuntime.HoudiniParameterRampModificationEvent
// Inherited Bytes: 0x28 | Struct Size: 0x50
struct UHoudiniParameterRampModificationEvent : UObject {
	// Fields
	bool bIsInsertEvent; // Offset: 0x28 | Size: 0x1
	bool bIsFloatRamp; // Offset: 0x29 | Size: 0x1
	char pad_0x2A[0x2]; // Offset: 0x2a | Size: 0x2
	int32_t DeleteInstanceIndex; // Offset: 0x2c | Size: 0x4
	float InsertPosition; // Offset: 0x30 | Size: 0x4
	float InsertFloat; // Offset: 0x34 | Size: 0x4
	struct FLinearColor InsertColor; // Offset: 0x38 | Size: 0x10
	enum class EHoudiniRampInterpolationType InsertInterpolation; // Offset: 0x48 | Size: 0x1
	char pad_0x49[0x7]; // Offset: 0x49 | Size: 0x7
};

// Object: Class HoudiniEngineRuntime.HoudiniParameterRampFloatPoint
// Inherited Bytes: 0x28 | Struct Size: 0x50
struct UHoudiniParameterRampFloatPoint : UObject {
	// Fields
	float Position; // Offset: 0x28 | Size: 0x4
	float Value; // Offset: 0x2c | Size: 0x4
	enum class EHoudiniRampInterpolationType Interpolation; // Offset: 0x30 | Size: 0x1
	char pad_0x31[0x3]; // Offset: 0x31 | Size: 0x3
	int32_t InstanceIndex; // Offset: 0x34 | Size: 0x4
	struct UHoudiniParameterFloat* PositionParentParm; // Offset: 0x38 | Size: 0x8
	struct UHoudiniParameterFloat* ValueParentParm; // Offset: 0x40 | Size: 0x8
	struct UHoudiniParameterChoice* InterpolationParentParm; // Offset: 0x48 | Size: 0x8
};

// Object: Class HoudiniEngineRuntime.HoudiniParameterRampColorPoint
// Inherited Bytes: 0x28 | Struct Size: 0x60
struct UHoudiniParameterRampColorPoint : UObject {
	// Fields
	float Position; // Offset: 0x28 | Size: 0x4
	struct FLinearColor Value; // Offset: 0x2c | Size: 0x10
	enum class EHoudiniRampInterpolationType Interpolation; // Offset: 0x3c | Size: 0x1
	char pad_0x3D[0x3]; // Offset: 0x3d | Size: 0x3
	int32_t InstanceIndex; // Offset: 0x40 | Size: 0x4
	char pad_0x44[0x4]; // Offset: 0x44 | Size: 0x4
	struct UHoudiniParameterFloat* PositionParentParm; // Offset: 0x48 | Size: 0x8
	struct UHoudiniParameterColor* ValueParentParm; // Offset: 0x50 | Size: 0x8
	struct UHoudiniParameterChoice* InterpolationParentParm; // Offset: 0x58 | Size: 0x8
};

// Object: Class HoudiniEngineRuntime.HoudiniParameterMultiParm
// Inherited Bytes: 0x108 | Struct Size: 0x148
struct UHoudiniParameterMultiParm : UHoudiniParameter {
	// Fields
	bool bIsShown; // Offset: 0x101 | Size: 0x1
	int32_t Value; // Offset: 0x104 | Size: 0x4
	struct FString TemplateName; // Offset: 0x108 | Size: 0x10
	int32_t MultiparmValue; // Offset: 0x118 | Size: 0x4
	uint32_t MultiParmInstanceNum; // Offset: 0x11c | Size: 0x4
	uint32_t MultiParmInstanceLength; // Offset: 0x120 | Size: 0x4
	uint32_t MultiParmInstanceCount; // Offset: 0x124 | Size: 0x4
	uint32_t InstanceStartOffset; // Offset: 0x128 | Size: 0x4
	struct TArray<enum class EHoudiniMultiParmModificationType> MultiParmInstanceLastModifyArray; // Offset: 0x130 | Size: 0x10
	int32_t DefaultInstanceCount; // Offset: 0x140 | Size: 0x4
	char pad_0x145[0x3]; // Offset: 0x145 | Size: 0x3
};

// Object: Class HoudiniEngineRuntime.HoudiniParameterRampFloat
// Inherited Bytes: 0x148 | Struct Size: 0x1b0
struct UHoudiniParameterRampFloat : UHoudiniParameterMultiParm {
	// Fields
	struct TArray<struct UHoudiniParameterRampFloatPoint*> Points; // Offset: 0x148 | Size: 0x10
	struct TArray<struct UHoudiniParameterRampFloatPoint*> CachedPoints; // Offset: 0x158 | Size: 0x10
	struct TArray<float> DefaultPositions; // Offset: 0x168 | Size: 0x10
	struct TArray<float> DefaultValues; // Offset: 0x178 | Size: 0x10
	struct TArray<int32_t> DefaultChoices; // Offset: 0x188 | Size: 0x10
	int32_t NumDefaultPoints; // Offset: 0x198 | Size: 0x4
	bool bCaching; // Offset: 0x19c | Size: 0x1
	char pad_0x19D[0x3]; // Offset: 0x19d | Size: 0x3
	struct TArray<struct UHoudiniParameterRampModificationEvent*> ModificationEvents; // Offset: 0x1a0 | Size: 0x10
};

// Object: Class HoudiniEngineRuntime.HoudiniParameterRampColor
// Inherited Bytes: 0x148 | Struct Size: 0x1b8
struct UHoudiniParameterRampColor : UHoudiniParameterMultiParm {
	// Fields
	struct TArray<struct UHoudiniParameterRampColorPoint*> Points; // Offset: 0x148 | Size: 0x10
	bool bCaching; // Offset: 0x158 | Size: 0x1
	char pad_0x159[0x7]; // Offset: 0x159 | Size: 0x7
	struct TArray<struct UHoudiniParameterRampColorPoint*> CachedPoints; // Offset: 0x160 | Size: 0x10
	struct TArray<float> DefaultPositions; // Offset: 0x170 | Size: 0x10
	struct TArray<struct FLinearColor> DefaultValues; // Offset: 0x180 | Size: 0x10
	struct TArray<int32_t> DefaultChoices; // Offset: 0x190 | Size: 0x10
	int32_t NumDefaultPoints; // Offset: 0x1a0 | Size: 0x4
	char pad_0x1A4[0x4]; // Offset: 0x1a4 | Size: 0x4
	struct TArray<struct UHoudiniParameterRampModificationEvent*> ModificationEvents; // Offset: 0x1a8 | Size: 0x10
};

// Object: Class HoudiniEngineRuntime.HoudiniMeshSplitInstancerComponent
// Inherited Bytes: 0x370 | Struct Size: 0x390
struct UHoudiniMeshSplitInstancerComponent : USceneComponent {
	// Fields
	struct TArray<struct UStaticMeshComponent*> Instances; // Offset: 0x368 | Size: 0x10
	struct TArray<struct UMaterialInterface*> OverrideMaterials; // Offset: 0x378 | Size: 0x10
	struct UStaticMesh* InstancedMesh; // Offset: 0x388 | Size: 0x8
};

// Object: Class HoudiniEngineRuntime.HoudiniHandleParameter
// Inherited Bytes: 0x28 | Struct Size: 0x38
struct UHoudiniHandleParameter : UObject {
	// Fields
	struct UHoudiniParameter* AssetParameter; // Offset: 0x28 | Size: 0x8
	int32_t TupleIndex; // Offset: 0x30 | Size: 0x4
	char pad_0x34[0x4]; // Offset: 0x34 | Size: 0x4
};

// Object: Class HoudiniEngineRuntime.HoudiniHandleComponent
// Inherited Bytes: 0x370 | Struct Size: 0x3a0
struct UHoudiniHandleComponent : USceneComponent {
	// Fields
	struct TArray<struct UHoudiniHandleParameter*> XformParms; // Offset: 0x368 | Size: 0x10
	struct UHoudiniHandleParameter* RSTParm; // Offset: 0x378 | Size: 0x8
	struct UHoudiniHandleParameter* RotOrderParm; // Offset: 0x380 | Size: 0x8
	enum class EHoudiniHandleType HandleType; // Offset: 0x388 | Size: 0x1
	struct FString HandleName; // Offset: 0x390 | Size: 0x10
};

// Object: Class HoudiniEngineRuntime.HoudiniStaticMesh
// Inherited Bytes: 0x28 | Struct Size: 0xc8
struct UHoudiniStaticMesh : UObject {
	// Fields
	bool bHasNormals; // Offset: 0x28 | Size: 0x1
	bool bHasTangents; // Offset: 0x29 | Size: 0x1
	bool bHasColors; // Offset: 0x2a | Size: 0x1
	char pad_0x2B[0x1]; // Offset: 0x2b | Size: 0x1
	uint32_t NumUVLayers; // Offset: 0x2c | Size: 0x4
	bool bHasPerFaceMaterials; // Offset: 0x30 | Size: 0x1
	char pad_0x31[0x7]; // Offset: 0x31 | Size: 0x7
	struct TArray<struct FVector> VertexPositions; // Offset: 0x38 | Size: 0x10
	struct TArray<struct FIntVector> TriangleIndices; // Offset: 0x48 | Size: 0x10
	struct TArray<struct FColor> VertexInstanceColors; // Offset: 0x58 | Size: 0x10
	struct TArray<struct FVector> VertexInstanceNormals; // Offset: 0x68 | Size: 0x10
	struct TArray<struct FVector> VertexInstanceUTangents; // Offset: 0x78 | Size: 0x10
	struct TArray<struct FVector> VertexInstanceVTangents; // Offset: 0x88 | Size: 0x10
	struct TArray<struct FVector2D> VertexInstanceUVs; // Offset: 0x98 | Size: 0x10
	struct TArray<int32_t> MaterialIDsPerTriangle; // Offset: 0xa8 | Size: 0x10
	struct TArray<struct FStaticMaterial> StaticMaterials; // Offset: 0xb8 | Size: 0x10

	// Functions

	// Object: Function HoudiniEngineRuntime.HoudiniStaticMesh.SetVertexPosition
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults]
	// Offset: 0x102c2cf4c
	// Return & Params: [ Num(2) Size(0x10) ]
	void SetVertexPosition(uint32_t InVertexIndex, struct FVector& InPosition);

	// Object: Function HoudiniEngineRuntime.HoudiniStaticMesh.SetTriangleVertexVTangent
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults]
	// Offset: 0x102c2ccb0
	// Return & Params: [ Num(3) Size(0x14) ]
	void SetTriangleVertexVTangent(uint32_t InTriangleIndex, char InTriangleVertexIndex, struct FVector& InVTangent);

	// Object: Function HoudiniEngineRuntime.HoudiniStaticMesh.SetTriangleVertexUV
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults]
	// Offset: 0x102c2cb28
	// Return & Params: [ Num(4) Size(0x10) ]
	void SetTriangleVertexUV(uint32_t InTriangleIndex, char InTriangleVertexIndex, char InUVLayer, struct FVector2D& InUV);

	// Object: Function HoudiniEngineRuntime.HoudiniStaticMesh.SetTriangleVertexUTangent
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults]
	// Offset: 0x102c2cd68
	// Return & Params: [ Num(3) Size(0x14) ]
	void SetTriangleVertexUTangent(uint32_t InTriangleIndex, char InTriangleVertexIndex, struct FVector& InUTangent);

	// Object: Function HoudiniEngineRuntime.HoudiniStaticMesh.SetTriangleVertexNormal
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults]
	// Offset: 0x102c2ce20
	// Return & Params: [ Num(3) Size(0x14) ]
	void SetTriangleVertexNormal(uint32_t InTriangleIndex, char InTriangleVertexIndex, struct FVector& InNormal);

	// Object: Function HoudiniEngineRuntime.HoudiniStaticMesh.SetTriangleVertexIndices
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults]
	// Offset: 0x102c2ced8
	// Return & Params: [ Num(2) Size(0x10) ]
	void SetTriangleVertexIndices(uint32_t InTriangleIndex, struct FIntVector& InTriangleVertexIndices);

	// Object: Function HoudiniEngineRuntime.HoudiniStaticMesh.SetTriangleVertexColor
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults]
	// Offset: 0x102c2cc04
	// Return & Params: [ Num(3) Size(0xc) ]
	void SetTriangleVertexColor(uint32_t InTriangleIndex, char InTriangleVertexIndex, struct FColor& InColor);

	// Object: Function HoudiniEngineRuntime.HoudiniStaticMesh.SetTriangleMaterialID
	// Flags: [Final|Native|Public]
	// Offset: 0x102c2caa0
	// Return & Params: [ Num(2) Size(0x8) ]
	void SetTriangleMaterialID(uint32_t InTriangleIndex, int32_t InMaterialID);

	// Object: Function HoudiniEngineRuntime.HoudiniStaticMesh.SetStaticMaterial
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x102c2c9fc
	// Return & Params: [ Num(2) Size(0x38) ]
	void SetStaticMaterial(uint32_t InMaterialIndex, struct FStaticMaterial& InStaticMaterial);

	// Object: Function HoudiniEngineRuntime.HoudiniStaticMesh.SetNumUVLayers
	// Flags: [Final|Native|Public]
	// Offset: 0x102c2d05c
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetNumUVLayers(uint32_t InNumUVLayers);

	// Object: Function HoudiniEngineRuntime.HoudiniStaticMesh.SetNumStaticMaterials
	// Flags: [Final|Native|Public]
	// Offset: 0x102c2d008
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetNumStaticMaterials(uint32_t InNumStaticMaterials);

	// Object: Function HoudiniEngineRuntime.HoudiniStaticMesh.SetHasTangents
	// Flags: [Final|Native|Public]
	// Offset: 0x102c2d104
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetHasTangents(bool bInHasTangents);

	// Object: Function HoudiniEngineRuntime.HoudiniStaticMesh.SetHasPerFaceMaterials
	// Flags: [Final|Native|Public]
	// Offset: 0x102c2d1ac
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetHasPerFaceMaterials(bool bInHasPerFaceMaterials);

	// Object: Function HoudiniEngineRuntime.HoudiniStaticMesh.SetHasNormals
	// Flags: [Final|Native|Public]
	// Offset: 0x102c2d158
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetHasNormals(bool bInHasNormals);

	// Object: Function HoudiniEngineRuntime.HoudiniStaticMesh.SetHasColors
	// Flags: [Final|Native|Public]
	// Offset: 0x102c2d0b0
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetHasColors(bool bInHasColors);

	// Object: Function HoudiniEngineRuntime.HoudiniStaticMesh.Optimize
	// Flags: [Final|Native|Public]
	// Offset: 0x102c2c8a0
	// Return & Params: [ Num(0) Size(0x0) ]
	void Optimize();

	// Object: Function HoudiniEngineRuntime.HoudiniStaticMesh.IsValid
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x102c2c420
	// Return & Params: [ Num(2) Size(0x2) ]
	bool IsValid(bool bInSkipVertexIndicesCheck);

	// Object: Function HoudiniEngineRuntime.HoudiniStaticMesh.Initialize
	// Flags: [Final|Native|Public]
	// Offset: 0x102c2d200
	// Return & Params: [ Num(8) Size(0x14) ]
	void Initialize(uint32_t InNumVertices, uint32_t InNumTriangles, uint32_t InNumUVLayers, uint32_t InInitialNumStaticMaterials, bool bInHasNormals, bool bInHasTangents, bool bInHasColors, bool bInHasPerFaceMaterials);

	// Object: Function HoudiniEngineRuntime.HoudiniStaticMesh.HasTangents
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x102c2d144
	// Return & Params: [ Num(1) Size(0x1) ]
	bool HasTangents();

	// Object: Function HoudiniEngineRuntime.HoudiniStaticMesh.HasPerFaceMaterials
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x102c2d1ec
	// Return & Params: [ Num(1) Size(0x1) ]
	bool HasPerFaceMaterials();

	// Object: Function HoudiniEngineRuntime.HoudiniStaticMesh.HasNormals
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x102c2d198
	// Return & Params: [ Num(1) Size(0x1) ]
	bool HasNormals();

	// Object: Function HoudiniEngineRuntime.HoudiniStaticMesh.HasColors
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x102c2d0f0
	// Return & Params: [ Num(1) Size(0x1) ]
	bool HasColors();

	// Object: Function HoudiniEngineRuntime.HoudiniStaticMesh.GetVertexPositions
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x102c2c814
	// Return & Params: [ Num(1) Size(0x10) ]
	struct TArray<struct FVector> GetVertexPositions();

	// Object: Function HoudiniEngineRuntime.HoudiniStaticMesh.GetVertexInstanceVTangents
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x102c2c674
	// Return & Params: [ Num(1) Size(0x10) ]
	struct TArray<struct FVector> GetVertexInstanceVTangents();

	// Object: Function HoudiniEngineRuntime.HoudiniStaticMesh.GetVertexInstanceUVs
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x102c2c618
	// Return & Params: [ Num(1) Size(0x10) ]
	struct TArray<struct FVector2D> GetVertexInstanceUVs();

	// Object: Function HoudiniEngineRuntime.HoudiniStaticMesh.GetVertexInstanceUTangents
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x102c2c6c4
	// Return & Params: [ Num(1) Size(0x10) ]
	struct TArray<struct FVector> GetVertexInstanceUTangents();

	// Object: Function HoudiniEngineRuntime.HoudiniStaticMesh.GetVertexInstanceNormals
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x102c2c714
	// Return & Params: [ Num(1) Size(0x10) ]
	struct TArray<struct FVector> GetVertexInstanceNormals();

	// Object: Function HoudiniEngineRuntime.HoudiniStaticMesh.GetVertexInstanceColors
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x102c2c764
	// Return & Params: [ Num(1) Size(0x10) ]
	struct TArray<struct FColor> GetVertexInstanceColors();

	// Object: Function HoudiniEngineRuntime.HoudiniStaticMesh.GetTriangleIndices
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x102c2c7c0
	// Return & Params: [ Num(1) Size(0x10) ]
	struct TArray<struct FIntVector> GetTriangleIndices();

	// Object: Function HoudiniEngineRuntime.HoudiniStaticMesh.GetStaticMaterials
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x102c2c55c
	// Return & Params: [ Num(1) Size(0x10) ]
	struct TArray<struct FStaticMaterial> GetStaticMaterials();

	// Object: Function HoudiniEngineRuntime.HoudiniStaticMesh.GetNumVertices
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x102c2cff4
	// Return & Params: [ Num(1) Size(0x4) ]
	uint32_t GetNumVertices();

	// Object: Function HoudiniEngineRuntime.HoudiniStaticMesh.GetNumVertexInstances
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x102c2cfc0
	// Return & Params: [ Num(1) Size(0x4) ]
	uint32_t GetNumVertexInstances();

	// Object: Function HoudiniEngineRuntime.HoudiniStaticMesh.GetNumUVLayers
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x102c2d09c
	// Return & Params: [ Num(1) Size(0x4) ]
	uint32_t GetNumUVLayers();

	// Object: Function HoudiniEngineRuntime.HoudiniStaticMesh.GetNumTriangles
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x102c2cfdc
	// Return & Params: [ Num(1) Size(0x4) ]
	uint32_t GetNumTriangles();

	// Object: Function HoudiniEngineRuntime.HoudiniStaticMesh.GetNumStaticMaterials
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x102c2d048
	// Return & Params: [ Num(1) Size(0x4) ]
	uint32_t GetNumStaticMaterials();

	// Object: Function HoudiniEngineRuntime.HoudiniStaticMesh.GetMaterialIndex
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x102c2c484
	// Return & Params: [ Num(2) Size(0xc) ]
	int32_t GetMaterialIndex(struct FName InMaterialSlotName);

	// Object: Function HoudiniEngineRuntime.HoudiniStaticMesh.GetMaterialIDsPerTriangle
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x102c2c5bc
	// Return & Params: [ Num(1) Size(0x10) ]
	struct TArray<int32_t> GetMaterialIDsPerTriangle();

	// Object: Function HoudiniEngineRuntime.HoudiniStaticMesh.GetMaterial
	// Flags: [Final|Native|Public]
	// Offset: 0x102c2c500
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UMaterialInterface* GetMaterial(int32_t InMaterialIndex);

	// Object: Function HoudiniEngineRuntime.HoudiniStaticMesh.CalculateTangents
	// Flags: [Final|Native|Public]
	// Offset: 0x102c2c8b0
	// Return & Params: [ Num(1) Size(0x1) ]
	void CalculateTangents(bool bInComputeWeightedNormals);

	// Object: Function HoudiniEngineRuntime.HoudiniStaticMesh.CalculateNormals
	// Flags: [Final|Native|Public]
	// Offset: 0x102c2c8f0
	// Return & Params: [ Num(1) Size(0x1) ]
	void CalculateNormals(bool bInComputeWeightedNormals);

	// Object: Function HoudiniEngineRuntime.HoudiniStaticMesh.CalcBounds
	// Flags: [Final|Native|Public|HasDefaults|Const]
	// Offset: 0x102c2c864
	// Return & Params: [ Num(1) Size(0x1c) ]
	struct FBox CalcBounds();

	// Object: Function HoudiniEngineRuntime.HoudiniStaticMesh.AddStaticMaterial
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x102c2c930
	// Return & Params: [ Num(2) Size(0x34) ]
	uint32_t AddStaticMaterial(struct FStaticMaterial& InStaticMaterial);
};

// Object: Class HoudiniEngineRuntime.TOPNode
// Inherited Bytes: 0x28 | Struct Size: 0x420
struct UTOPNode : UObject {
	// Fields
	int32_t NodeId; // Offset: 0x28 | Size: 0x4
	char pad_0x2C[0x4]; // Offset: 0x2c | Size: 0x4
	struct FString NodeName; // Offset: 0x30 | Size: 0x10
	struct FString NodePath; // Offset: 0x40 | Size: 0x10
	struct FString ParentName; // Offset: 0x50 | Size: 0x10
	struct UObject* WorkResultParent; // Offset: 0x60 | Size: 0x8
	struct TArray<struct FTOPWorkResult> WorkResult; // Offset: 0x68 | Size: 0x10
	bool bHidden; // Offset: 0x78 | Size: 0x1
	bool bAutoLoad; // Offset: 0x79 | Size: 0x1
	enum class EPDGNodeState NodeState; // Offset: 0x7a | Size: 0x1
	bool bCachedHaveNotLoadedWorkResults; // Offset: 0x7b | Size: 0x1
	bool bCachedHaveLoadedWorkResults; // Offset: 0x7c | Size: 0x1
	bool bHasChildNodes; // Offset: 0x7d | Size: 0x1
	char pad_0x7E[0x2]; // Offset: 0x7e | Size: 0x2
	struct TSet<struct FString> ClearedLandscapeLayers; // Offset: 0x80 | Size: 0x50
	char pad_0xD0[0x80]; // Offset: 0xd0 | Size: 0x80
	bool bShow; // Offset: 0x150 | Size: 0x1
	char pad_0x151[0x7]; // Offset: 0x151 | Size: 0x7
	struct TMap<struct FString, struct FHoudiniPDGWorkResultObjectBakedOutput> BakedWorkResultObjectOutputs; // Offset: 0x158 | Size: 0x50
	struct FWorkItemTally WorkItemTally; // Offset: 0x1a8 | Size: 0x238
	struct FAggregatedWorkItemTally AggregatedWorkItemTally; // Offset: 0x3e0 | Size: 0x28
	bool bHasReceivedCookCompleteEvent; // Offset: 0x408 | Size: 0x1
	char pad_0x409[0x7]; // Offset: 0x409 | Size: 0x7
	struct FOutputActorOwner OutputActorOwner; // Offset: 0x410 | Size: 0x10
};

// Object: Class HoudiniEngineRuntime.TOPNetwork
// Inherited Bytes: 0x28 | Struct Size: 0x98
struct UTOPNetwork : UObject {
	// Fields
	int32_t NodeId; // Offset: 0x28 | Size: 0x4
	char pad_0x2C[0x4]; // Offset: 0x2c | Size: 0x4
	struct FString NodeName; // Offset: 0x30 | Size: 0x10
	struct FString NodePath; // Offset: 0x40 | Size: 0x10
	struct TArray<struct UTOPNode*> AllTOPNodes; // Offset: 0x50 | Size: 0x10
	int32_t SelectedTOPIndex; // Offset: 0x60 | Size: 0x4
	char pad_0x64[0x4]; // Offset: 0x64 | Size: 0x4
	struct FString ParentName; // Offset: 0x68 | Size: 0x10
	bool bShowResults; // Offset: 0x78 | Size: 0x1
	bool bAutoLoadResults; // Offset: 0x79 | Size: 0x1
	char pad_0x7A[0x1e]; // Offset: 0x7a | Size: 0x1e
};

// Object: Class HoudiniEngineRuntime.HoudiniPDGAssetLink
// Inherited Bytes: 0x28 | Struct Size: 0x130
struct UHoudiniPDGAssetLink : UObject {
	// Fields
	struct FString AssetName; // Offset: 0x28 | Size: 0x10
	struct FString AssetNodePath; // Offset: 0x38 | Size: 0x10
	int32_t AssetId; // Offset: 0x48 | Size: 0x4
	char pad_0x4C[0x4]; // Offset: 0x4c | Size: 0x4
	struct TArray<struct UTOPNetwork*> AllTOPNetworks; // Offset: 0x50 | Size: 0x10
	int32_t SelectedTOPNetworkIndex; // Offset: 0x60 | Size: 0x4
	enum class EPDGLinkState LinkState; // Offset: 0x64 | Size: 0x1
	bool bAutoCook; // Offset: 0x65 | Size: 0x1
	bool bUseTOPNodeFilter; // Offset: 0x66 | Size: 0x1
	bool bUseTOPOutputFilter; // Offset: 0x67 | Size: 0x1
	struct FString TOPNodeFilter; // Offset: 0x68 | Size: 0x10
	struct FString TOPOutputFilter; // Offset: 0x78 | Size: 0x10
	int32_t NumWorkItems; // Offset: 0x88 | Size: 0x4
	char pad_0x8C[0x4]; // Offset: 0x8c | Size: 0x4
	struct FAggregatedWorkItemTally WorkItemTally; // Offset: 0x90 | Size: 0x28
	struct FString OutputCachePath; // Offset: 0xb8 | Size: 0x10
	bool bNeedsUIRefresh; // Offset: 0xc8 | Size: 0x1
	char pad_0xC9[0x7]; // Offset: 0xc9 | Size: 0x7
	struct AActor* OutputParentActor; // Offset: 0xd0 | Size: 0x8
	struct FDirectoryPath BakeFolder; // Offset: 0xd8 | Size: 0x10
	char pad_0xE8[0x48]; // Offset: 0xe8 | Size: 0x48
};

// Object: Class HoudiniEngineRuntime.HoudiniAssetComponent
// Inherited Bytes: 0x5f0 | Struct Size: 0xb90
struct UHoudiniAssetComponent : UPrimitiveComponent {
	// Fields
	struct FHoudiniInputLandscapeTransferParams LandscapeTransferParams; // Offset: 0x5f0 | Size: 0xc8
	struct TArray<struct FDirectoryPath> Directories; // Offset: 0x6b8 | Size: 0x10
	struct UHoudiniAsset* HoudiniAsset; // Offset: 0x6c8 | Size: 0x8
	bool bCookOnParameterChange; // Offset: 0x6d0 | Size: 0x1
	bool bUploadTransformsToHoudiniEngine; // Offset: 0x6d1 | Size: 0x1
	bool bCookOnTransformChange; // Offset: 0x6d2 | Size: 0x1
	bool bCookOnAssetInputCook; // Offset: 0x6d3 | Size: 0x1
	bool bOutputless; // Offset: 0x6d4 | Size: 0x1
	bool bOutputTemplateGeos; // Offset: 0x6d5 | Size: 0x1
	bool bUseOutputNodes; // Offset: 0x6d6 | Size: 0x1
	char pad_0x6D7[0x1]; // Offset: 0x6d7 | Size: 0x1
	struct FDirectoryPath TemporaryCookFolder; // Offset: 0x6d8 | Size: 0x10
	struct FDirectoryPath BakeFolder; // Offset: 0x6e8 | Size: 0x10
	enum class EHoudiniStaticMeshMethod StaticMeshMethod; // Offset: 0x6f8 | Size: 0x1
	char pad_0x6F9[0x7]; // Offset: 0x6f9 | Size: 0x7
	struct FHoudiniStaticMeshGenerationProperties StaticMeshGenerationProperties; // Offset: 0x700 | Size: 0x180
	struct FMeshBuildSettings StaticMeshBuildSettings; // Offset: 0x880 | Size: 0x30
	bool bOverrideGlobalProxyStaticMeshSettings; // Offset: 0x8b0 | Size: 0x1
	bool bEnableProxyStaticMeshOverride; // Offset: 0x8b1 | Size: 0x1
	bool bEnableProxyStaticMeshRefinementByTimerOverride; // Offset: 0x8b2 | Size: 0x1
	char pad_0x8B3[0x1]; // Offset: 0x8b3 | Size: 0x1
	float ProxyMeshAutoRefineTimeoutSecondsOverride; // Offset: 0x8b4 | Size: 0x4
	bool bEnableProxyStaticMeshRefinementOnPreSaveWorldOverride; // Offset: 0x8b8 | Size: 0x1
	bool bEnableProxyStaticMeshRefinementOnPreBeginPIEOverride; // Offset: 0x8b9 | Size: 0x1
	char pad_0x8BA[0x2]; // Offset: 0x8ba | Size: 0x2
	int32_t AssetId; // Offset: 0x8bc | Size: 0x4
	struct TArray<int32_t> NodeIdsToCook; // Offset: 0x8c0 | Size: 0x10
	struct TMap<int32_t, int32_t> OutputNodeCookCounts; // Offset: 0x8d0 | Size: 0x50
	struct TSet<struct UHoudiniAssetComponent*> DownstreamHoudiniAssets; // Offset: 0x920 | Size: 0x50
	struct FGuid ComponentGUID; // Offset: 0x970 | Size: 0x10
	struct FGuid HapiGUID; // Offset: 0x980 | Size: 0x10
	struct FString HapiAssetName; // Offset: 0x990 | Size: 0x10
	enum class EHoudiniAssetState AssetState; // Offset: 0x9a0 | Size: 0x1
	enum class EHoudiniAssetState DebugLastAssetState; // Offset: 0x9a1 | Size: 0x1
	enum class EHoudiniAssetStateResult AssetStateResult; // Offset: 0x9a2 | Size: 0x1
	char pad_0x9A3[0xd]; // Offset: 0x9a3 | Size: 0xd
	struct FTransform LastComponentTransform; // Offset: 0x9b0 | Size: 0x30
	uint32_t SubAssetIndex; // Offset: 0x9e0 | Size: 0x4
	int32_t AssetCookCount; // Offset: 0x9e4 | Size: 0x4
	bool bHasBeenLoaded; // Offset: 0x9e8 | Size: 0x1
	bool bHasBeenDuplicated; // Offset: 0x9e9 | Size: 0x1
	bool bPendingDelete; // Offset: 0x9ea | Size: 0x1
	bool bRecookRequested; // Offset: 0x9eb | Size: 0x1
	bool bRebuildRequested; // Offset: 0x9ec | Size: 0x1
	bool bEnableCooking; // Offset: 0x9ed | Size: 0x1
	bool bForceNeedUpdate; // Offset: 0x9ee | Size: 0x1
	bool bLastCookSuccess; // Offset: 0x9ef | Size: 0x1
	bool bParameterDefinitionUpdateNeeded; // Offset: 0x9f0 | Size: 0x1
	bool bBlueprintStructureModified; // Offset: 0x9f1 | Size: 0x1
	bool bBlueprintModified; // Offset: 0x9f2 | Size: 0x1
	char pad_0x9F3[0x5]; // Offset: 0x9f3 | Size: 0x5
	struct TArray<struct UHoudiniParameter*> Parameters; // Offset: 0x9f8 | Size: 0x10
	struct TArray<struct UHoudiniInput*> Inputs; // Offset: 0xa08 | Size: 0x10
	struct TArray<struct UHoudiniOutput*> Outputs; // Offset: 0xa18 | Size: 0x10
	struct TArray<struct FHoudiniBakedOutput> BakedOutputs; // Offset: 0xa28 | Size: 0x10
	struct TArray<struct TWeakObjectPtr<struct AActor>> UntrackedOutputs; // Offset: 0xa38 | Size: 0x10
	struct TArray<struct UHoudiniHandleComponent*> HandleComponents; // Offset: 0xa48 | Size: 0x10
	bool bHasComponentTransformChanged; // Offset: 0xa58 | Size: 0x1
	bool bFullyLoaded; // Offset: 0xa59 | Size: 0x1
	char pad_0xA5A[0x6]; // Offset: 0xa5a | Size: 0x6
	struct UHoudiniPDGAssetLink* PDGAssetLink; // Offset: 0xa60 | Size: 0x8
	struct FTimerHandle RefineMeshesTimer; // Offset: 0xa68 | Size: 0x8
	char pad_0xA70[0x18]; // Offset: 0xa70 | Size: 0x18
	bool bNoProxyMeshNextCookRequested; // Offset: 0xa88 | Size: 0x1
	char pad_0xA89[0x7]; // Offset: 0xa89 | Size: 0x7
	struct TMap<struct UObject*, int32_t> InputPresets; // Offset: 0xa90 | Size: 0x50
	bool bBakeAfterNextCook; // Offset: 0xae0 | Size: 0x1
	char pad_0xAE1[0x7f]; // Offset: 0xae1 | Size: 0x7f
	bool bCachedIsPreview; // Offset: 0xb60 | Size: 0x1
	char pad_0xB61[0xf]; // Offset: 0xb61 | Size: 0xf
	double LastTickTime; // Offset: 0xb70 | Size: 0x8
	char pad_0xB78[0x18]; // Offset: 0xb78 | Size: 0x18
};

// Object: Class HoudiniEngineRuntime.HoudiniParameterFolderList
// Inherited Bytes: 0x108 | Struct Size: 0x118
struct UHoudiniParameterFolderList : UHoudiniParameter {
	// Fields
	bool bIsTabMenu; // Offset: 0x101 | Size: 0x1
	bool bIsTabsShown; // Offset: 0x102 | Size: 0x1
	struct TArray<struct UHoudiniParameterFolder*> TabFolders; // Offset: 0x108 | Size: 0x10
};

// Object: Class HoudiniEngineRuntime.HoudiniSplineComponent
// Inherited Bytes: 0x370 | Struct Size: 0x610
struct UHoudiniSplineComponent : USceneComponent {
	// Fields
	struct TArray<struct FTransform> CurvePoints; // Offset: 0x370 | Size: 0x10
	struct TArray<struct FVector> DisplayPoints; // Offset: 0x380 | Size: 0x10
	struct TArray<int32_t> DisplayPointIndexDivider; // Offset: 0x390 | Size: 0x10
	struct FString HoudiniSplineName; // Offset: 0x3a0 | Size: 0x10
	bool bClosed; // Offset: 0x3b0 | Size: 0x1
	bool bReversed; // Offset: 0x3b1 | Size: 0x1
	char pad_0x3B2[0x2]; // Offset: 0x3b2 | Size: 0x2
	int32_t CurveOrder; // Offset: 0x3b4 | Size: 0x4
	bool bIsHoudiniSplineVisible; // Offset: 0x3b8 | Size: 0x1
	enum class EHoudiniCurveType CurveType; // Offset: 0x3b9 | Size: 0x1
	enum class EHoudiniCurveMethod CurveMethod; // Offset: 0x3ba | Size: 0x1
	enum class EHoudiniCurveBreakpointParameterization CurveBreakpointParameterization; // Offset: 0x3bb | Size: 0x1
	bool bIsOutputCurve; // Offset: 0x3bc | Size: 0x1
	bool bCookOnCurveChanged; // Offset: 0x3bd | Size: 0x1
	bool bIsLegacyInputCurve; // Offset: 0x3be | Size: 0x1
	char pad_0x3BF[0x231]; // Offset: 0x3bf | Size: 0x231
	bool bHasChanged; // Offset: 0x5f0 | Size: 0x1
	bool bNeedsToTriggerUpdate; // Offset: 0x5f1 | Size: 0x1
	bool bIsInputCurve; // Offset: 0x5f2 | Size: 0x1
	bool bIsEditableOutputCurve; // Offset: 0x5f3 | Size: 0x1
	int32_t NodeId; // Offset: 0x5f4 | Size: 0x4
	struct FString PartName; // Offset: 0x5f8 | Size: 0x10
	char pad_0x608[0x8]; // Offset: 0x608 | Size: 0x8
};

// Object: Class HoudiniEngineRuntime.HoudiniParameterLabel
// Inherited Bytes: 0x108 | Struct Size: 0x118
struct UHoudiniParameterLabel : UHoudiniParameter {
	// Fields
	struct TArray<struct FString> LabelStrings; // Offset: 0x108 | Size: 0x10
};

// Object: Class HoudiniEngineRuntime.HoudiniParameterColor
// Inherited Bytes: 0x108 | Struct Size: 0x128
struct UHoudiniParameterColor : UHoudiniParameter {
	// Fields
	struct FLinearColor Color; // Offset: 0x104 | Size: 0x10
	struct FLinearColor DefaultColor; // Offset: 0x114 | Size: 0x10
	bool bIsChildOfRamp; // Offset: 0x124 | Size: 0x1
};

// Object: Class HoudiniEngineRuntime.HoudiniParameterFolder
// Inherited Bytes: 0x108 | Struct Size: 0x110
struct UHoudiniParameterFolder : UHoudiniParameter {
	// Fields
	enum class EHoudiniFolderParameterType FolderType; // Offset: 0x101 | Size: 0x1
	bool bExpanded; // Offset: 0x102 | Size: 0x1
	bool bChosen; // Offset: 0x103 | Size: 0x1
	int32_t ChildCounter; // Offset: 0x104 | Size: 0x4
	bool bIsContentShown; // Offset: 0x108 | Size: 0x1
};

// Object: Class HoudiniEngineRuntime.HoudiniParameterFile
// Inherited Bytes: 0x108 | Struct Size: 0x140
struct UHoudiniParameterFile : UHoudiniParameter {
	// Fields
	struct TArray<struct FString> Values; // Offset: 0x108 | Size: 0x10
	struct TArray<struct FString> DefaultValues; // Offset: 0x118 | Size: 0x10
	struct FString Filters; // Offset: 0x128 | Size: 0x10
	bool bIsReadOnly; // Offset: 0x138 | Size: 0x1
	char pad_0x139[0x7]; // Offset: 0x139 | Size: 0x7
};

// Object: Class HoudiniEngineRuntime.HoudiniEngineCopyPropertiesInterface
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UHoudiniEngineCopyPropertiesInterface : UInterface {
};

// Object: Class HoudiniEngineRuntime.HoudiniParameterChoice
// Inherited Bytes: 0x108 | Struct Size: 0x178
struct UHoudiniParameterChoice : UHoudiniParameter {
	// Fields
	int32_t IntValue; // Offset: 0x104 | Size: 0x4
	int32_t DefaultIntValue; // Offset: 0x108 | Size: 0x4
	struct FString StringValue; // Offset: 0x110 | Size: 0x10
	struct FString DefaultStringValue; // Offset: 0x120 | Size: 0x10
	struct TArray<struct FString> StringChoiceValues; // Offset: 0x130 | Size: 0x10
	struct TArray<struct FString> StringChoiceLabels; // Offset: 0x140 | Size: 0x10
	char pad_0x150[0x10]; // Offset: 0x150 | Size: 0x10
	bool bIsChildOfRamp; // Offset: 0x160 | Size: 0x1
	char pad_0x161[0x7]; // Offset: 0x161 | Size: 0x7
	struct TArray<int32_t> IntValuesArray; // Offset: 0x168 | Size: 0x10
};

// Object: Class HoudiniEngineRuntime.HoudiniLandscapePtr
// Inherited Bytes: 0x28 | Struct Size: 0x60
struct UHoudiniLandscapePtr : UObject {
	// Fields
	struct TSoftObjectPtr<ALandscapeProxy> LandscapeSoftPtr; // Offset: 0x28 | Size: 0x28
	enum class EHoudiniLandscapeOutputBakeType BakeType; // Offset: 0x50 | Size: 0x1
	char pad_0x51[0x3]; // Offset: 0x51 | Size: 0x3
	struct FName EditLayerName; // Offset: 0x54 | Size: 0x8
	char pad_0x5C[0x4]; // Offset: 0x5c | Size: 0x4
};

// Object: Class HoudiniEngineRuntime.HoudiniLandscapeEditLayer
// Inherited Bytes: 0x28 | Struct Size: 0x60
struct UHoudiniLandscapeEditLayer : UObject {
	// Fields
	struct TSoftObjectPtr<ALandscapeProxy> LandscapeSoftPtr; // Offset: 0x28 | Size: 0x28
	struct FString LayerName; // Offset: 0x50 | Size: 0x10
};

// Object: Class HoudiniEngineRuntime.HoudiniOutput
// Inherited Bytes: 0x28 | Struct Size: 0x1b0
struct UHoudiniOutput : UObject {
	// Fields
	enum class EHoudiniOutputType Type; // Offset: 0x28 | Size: 0x1
	char pad_0x29[0x7]; // Offset: 0x29 | Size: 0x7
	struct TArray<struct FHoudiniGeoPartObject> HoudiniGeoPartObjects; // Offset: 0x30 | Size: 0x10
	struct TMap<struct FHoudiniOutputObjectIdentifier, struct FHoudiniOutputObject> OutputObjects; // Offset: 0x40 | Size: 0x50
	struct TMap<struct FHoudiniOutputObjectIdentifier, struct FHoudiniInstancedOutput> InstancedOutputs; // Offset: 0x90 | Size: 0x50
	struct TMap<struct FString, struct UMaterialInterface*> AssignementMaterials; // Offset: 0xe0 | Size: 0x50
	struct TMap<struct FString, struct UMaterialInterface*> ReplacementMaterials; // Offset: 0x130 | Size: 0x50
	char pad_0x180[0x4]; // Offset: 0x180 | Size: 0x4
	bool bLandscapeWorldComposition; // Offset: 0x184 | Size: 0x1
	char pad_0x185[0x3]; // Offset: 0x185 | Size: 0x3
	struct TArray<struct AActor*> HoudiniCreatedSocketActors; // Offset: 0x188 | Size: 0x10
	struct TArray<struct AActor*> HoudiniAttachedSocketActors; // Offset: 0x198 | Size: 0x10
	bool bIsEditableNode; // Offset: 0x1a8 | Size: 0x1
	bool bHasEditableNodeBuilt; // Offset: 0x1a9 | Size: 0x1
	bool bIsUpdating; // Offset: 0x1aa | Size: 0x1
	bool bCanDeleteHoudiniNodes; // Offset: 0x1ab | Size: 0x1
	char pad_0x1AC[0x4]; // Offset: 0x1ac | Size: 0x4
};

// Object: Class HoudiniEngineRuntime.HoudiniAssetBlueprintComponent
// Inherited Bytes: 0xb90 | Struct Size: 0xc90
struct UHoudiniAssetBlueprintComponent : UHoudiniAssetComponent {
	// Fields
	char pad_0xB90[0x48]; // Offset: 0xb90 | Size: 0x48
	bool FauxBPProperty; // Offset: 0xbd8 | Size: 0x1
	bool bHoudiniAssetChanged; // Offset: 0xbd9 | Size: 0x1
	bool bUpdatedFromTemplate; // Offset: 0xbda | Size: 0x1
	bool bIsInBlueprintEditor; // Offset: 0xbdb | Size: 0x1
	bool bCanDeleteHoudiniNodes; // Offset: 0xbdc | Size: 0x1
	bool bHasRegisteredComponentTemplate; // Offset: 0xbdd | Size: 0x1
	char pad_0xBDE[0xa]; // Offset: 0xbde | Size: 0xa
	struct TMap<struct FHoudiniOutputObjectIdentifier, struct FGuid> CachedOutputNodes; // Offset: 0xbe8 | Size: 0x50
	struct TMap<struct FGuid, struct FGuid> CachedInputNodes; // Offset: 0xc38 | Size: 0x50
	char pad_0xC88[0x8]; // Offset: 0xc88 | Size: 0x8

	// Functions

	// Object: Function HoudiniEngineRuntime.HoudiniAssetBlueprintComponent.SetToggleValueAt
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102c35c50
	// Return & Params: [ Num(3) Size(0x18) ]
	void SetToggleValueAt(struct FString Name, bool Value, int32_t Index);

	// Object: Function HoudiniEngineRuntime.HoudiniAssetBlueprintComponent.SetFloatParameter
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102c35d20
	// Return & Params: [ Num(3) Size(0x18) ]
	void SetFloatParameter(struct FString Name, float Value, int32_t Index);

	// Object: Function HoudiniEngineRuntime.HoudiniAssetBlueprintComponent.HasParameter
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102c35de8
	// Return & Params: [ Num(2) Size(0x11) ]
	bool HasParameter(struct FString Name);
};

// Object: Class HoudiniEngineRuntime.HoudiniParameterString
// Inherited Bytes: 0x108 | Struct Size: 0x140
struct UHoudiniParameterString : UHoudiniParameter {
	// Fields
	struct TArray<struct FString> Values; // Offset: 0x108 | Size: 0x10
	struct TArray<struct FString> DefaultValues; // Offset: 0x118 | Size: 0x10
	struct TArray<struct UObject*> ChosenAssets; // Offset: 0x128 | Size: 0x10
	bool bIsAssetRef; // Offset: 0x138 | Size: 0x1
	char pad_0x139[0x7]; // Offset: 0x139 | Size: 0x7
};

// Object: Class HoudiniEngineRuntime.HoudiniParameterButtonStrip
// Inherited Bytes: 0x108 | Struct Size: 0x128
struct UHoudiniParameterButtonStrip : UHoudiniParameter {
	// Fields
	int32_t count; // Offset: 0x104 | Size: 0x4
	struct TArray<struct FString> Labels; // Offset: 0x108 | Size: 0x10
	struct TArray<int32_t> Values; // Offset: 0x118 | Size: 0x10
};

// Object: Class HoudiniEngineRuntime.HoudiniAsset
// Inherited Bytes: 0x28 | Struct Size: 0x50
struct UHoudiniAsset : UObject {
	// Fields
	struct FString AssetFileName; // Offset: 0x28 | Size: 0x10
	struct TArray<char> AssetBytes; // Offset: 0x38 | Size: 0x10
	uint32_t AssetBytesCount; // Offset: 0x48 | Size: 0x4
	bool bAssetLimitedCommercial; // Offset: 0x4c | Size: 0x1
	bool bAssetNonCommercial; // Offset: 0x4d | Size: 0x1
	bool bAssetExpanded; // Offset: 0x4e | Size: 0x1
	char pad_0x4F[0x1]; // Offset: 0x4f | Size: 0x1
};

// Object: Class HoudiniEngineRuntime.HoudiniStaticMeshComponent
// Inherited Bytes: 0x6a0 | Struct Size: 0x6c0
struct UHoudiniStaticMeshComponent : UMeshComponent {
	// Fields
	struct UHoudiniStaticMesh* Mesh; // Offset: 0x698 | Size: 0x8
	struct FBox LocalBounds; // Offset: 0x6a0 | Size: 0x1c
	bool bHoudiniIconVisible; // Offset: 0x6bc | Size: 0x1

	// Functions

	// Object: Function HoudiniEngineRuntime.HoudiniStaticMeshComponent.SetMesh
	// Flags: [Final|Native|Public]
	// Offset: 0x102c378e0
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetMesh(struct UHoudiniStaticMesh* InMesh);

	// Object: Function HoudiniEngineRuntime.HoudiniStaticMeshComponent.SetHoudiniIconVisible
	// Flags: [Final|Native|Public]
	// Offset: 0x102c37820
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetHoudiniIconVisible(bool bInHoudiniIconVisible);

	// Object: Function HoudiniEngineRuntime.HoudiniStaticMeshComponent.NotifyMeshUpdated
	// Flags: [Final|Native|Public]
	// Offset: 0x102c378b0
	// Return & Params: [ Num(0) Size(0x0) ]
	void NotifyMeshUpdated();

	// Object: Function HoudiniEngineRuntime.HoudiniStaticMeshComponent.IsHoudiniIconVisible
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x102c37894
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsHoudiniIconVisible();

	// Object: Function HoudiniEngineRuntime.HoudiniStaticMeshComponent.GetMesh
	// Flags: [Final|Native|Public]
	// Offset: 0x102c378c4
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UHoudiniStaticMesh* GetMesh();
};

// Object: Class HoudiniEngineRuntime.HoudiniParameterButton
// Inherited Bytes: 0x108 | Struct Size: 0x108
struct UHoudiniParameterButton : UHoudiniParameter {
};

// Object: Class HoudiniEngineRuntime.HoudiniParameterInt
// Inherited Bytes: 0x108 | Struct Size: 0x150
struct UHoudiniParameterInt : UHoudiniParameter {
	// Fields
	struct TArray<int32_t> Values; // Offset: 0x108 | Size: 0x10
	struct TArray<int32_t> DefaultValues; // Offset: 0x118 | Size: 0x10
	struct FString Unit; // Offset: 0x128 | Size: 0x10
	bool bHasMin; // Offset: 0x138 | Size: 0x1
	bool bHasMax; // Offset: 0x139 | Size: 0x1
	bool bHasUIMin; // Offset: 0x13a | Size: 0x1
	bool bHasUIMax; // Offset: 0x13b | Size: 0x1
	bool bIsLogarithmic; // Offset: 0x13c | Size: 0x1
	char pad_0x13D[0x3]; // Offset: 0x13d | Size: 0x3
	int32_t Min; // Offset: 0x140 | Size: 0x4
	int32_t Max; // Offset: 0x144 | Size: 0x4
	int32_t UIMin; // Offset: 0x148 | Size: 0x4
	int32_t UIMax; // Offset: 0x14c | Size: 0x4
};

// Object: Class HoudiniEngineRuntime.HoudiniAssetParameter
// Inherited Bytes: 0x28 | Struct Size: 0x80
struct UHoudiniAssetParameter : UObject {
	// Fields
	char pad_0x28[0x58]; // Offset: 0x28 | Size: 0x58
};

// Object: Class HoudiniEngineRuntime.HoudiniAssetParameterButton
// Inherited Bytes: 0x80 | Struct Size: 0x80
struct UHoudiniAssetParameterButton : UHoudiniAssetParameter {
};

// Object: Class HoudiniEngineRuntime.HoudiniAssetParameterChoice
// Inherited Bytes: 0x80 | Struct Size: 0xb8
struct UHoudiniAssetParameterChoice : UHoudiniAssetParameter {
	// Fields
	char pad_0x80[0x38]; // Offset: 0x80 | Size: 0x38
};

// Object: Class HoudiniEngineRuntime.HoudiniAssetParameterColor
// Inherited Bytes: 0x80 | Struct Size: 0x90
struct UHoudiniAssetParameterColor : UHoudiniAssetParameter {
	// Fields
	char pad_0x80[0x10]; // Offset: 0x80 | Size: 0x10
};

// Object: Class HoudiniEngineRuntime.HoudiniAssetParameterFile
// Inherited Bytes: 0x80 | Struct Size: 0xa8
struct UHoudiniAssetParameterFile : UHoudiniAssetParameter {
	// Fields
	char pad_0x80[0x28]; // Offset: 0x80 | Size: 0x28
};

// Object: Class HoudiniEngineRuntime.HoudiniAssetParameterFloat
// Inherited Bytes: 0x80 | Struct Size: 0xb8
struct UHoudiniAssetParameterFloat : UHoudiniAssetParameter {
	// Fields
	char pad_0x80[0x38]; // Offset: 0x80 | Size: 0x38
};

// Object: Class HoudiniEngineRuntime.HoudiniAssetParameterFolder
// Inherited Bytes: 0x80 | Struct Size: 0x80
struct UHoudiniAssetParameterFolder : UHoudiniAssetParameter {
};

// Object: Class HoudiniEngineRuntime.HoudiniAssetParameterFolderList
// Inherited Bytes: 0x80 | Struct Size: 0x80
struct UHoudiniAssetParameterFolderList : UHoudiniAssetParameter {
};

// Object: Class HoudiniEngineRuntime.HoudiniAssetParameterInt
// Inherited Bytes: 0x80 | Struct Size: 0xb0
struct UHoudiniAssetParameterInt : UHoudiniAssetParameter {
	// Fields
	char pad_0x80[0x30]; // Offset: 0x80 | Size: 0x30
};

// Object: Class HoudiniEngineRuntime.HoudiniAssetParameterLabel
// Inherited Bytes: 0x80 | Struct Size: 0x80
struct UHoudiniAssetParameterLabel : UHoudiniAssetParameter {
};

// Object: Class HoudiniEngineRuntime.HoudiniAssetParameterMultiparm
// Inherited Bytes: 0x80 | Struct Size: 0x88
struct UHoudiniAssetParameterMultiparm : UHoudiniAssetParameter {
	// Fields
	char pad_0x80[0x8]; // Offset: 0x80 | Size: 0x8
};

// Object: Class HoudiniEngineRuntime.HoudiniAssetParameterRamp
// Inherited Bytes: 0x80 | Struct Size: 0x98
struct UHoudiniAssetParameterRamp : UHoudiniAssetParameter {
	// Fields
	char pad_0x80[0x18]; // Offset: 0x80 | Size: 0x18
};

// Object: Class HoudiniEngineRuntime.HoudiniAssetParameterSeparator
// Inherited Bytes: 0x80 | Struct Size: 0x80
struct UHoudiniAssetParameterSeparator : UHoudiniAssetParameter {
};

// Object: Class HoudiniEngineRuntime.HoudiniAssetParameterString
// Inherited Bytes: 0x80 | Struct Size: 0x90
struct UHoudiniAssetParameterString : UHoudiniAssetParameter {
	// Fields
	char pad_0x80[0x10]; // Offset: 0x80 | Size: 0x10
};

// Object: Class HoudiniEngineRuntime.HoudiniAssetParameterToggle
// Inherited Bytes: 0x80 | Struct Size: 0x90
struct UHoudiniAssetParameterToggle : UHoudiniAssetParameter {
	// Fields
	char pad_0x80[0x10]; // Offset: 0x80 | Size: 0x10
};

// Object: Class HoudiniEngineRuntime.HoudiniAssetComponentMaterials_V1
// Inherited Bytes: 0x28 | Struct Size: 0xc8
struct UHoudiniAssetComponentMaterials_V1 : UObject {
	// Fields
	char pad_0x28[0xa0]; // Offset: 0x28 | Size: 0xa0
};

// Object: Class HoudiniEngineRuntime.HoudiniHandleComponent_V1
// Inherited Bytes: 0x370 | Struct Size: 0x400
struct UHoudiniHandleComponent_V1 : USceneComponent {
	// Fields
	char pad_0x370[0x90]; // Offset: 0x370 | Size: 0x90
};

// Object: Class HoudiniEngineRuntime.HoudiniSplineComponent_V1
// Inherited Bytes: 0x370 | Struct Size: 0x460
struct UHoudiniSplineComponent_V1 : USceneComponent {
	// Fields
	char pad_0x370[0xf0]; // Offset: 0x370 | Size: 0xf0
};

// Object: Class HoudiniEngineRuntime.HoudiniAssetInput
// Inherited Bytes: 0x80 | Struct Size: 0x1a0
struct UHoudiniAssetInput : UHoudiniAssetParameter {
	// Fields
	char pad_0x80[0x120]; // Offset: 0x80 | Size: 0x120
};

// Object: Class HoudiniEngineRuntime.HoudiniAssetInstanceInput
// Inherited Bytes: 0x80 | Struct Size: 0x160
struct UHoudiniAssetInstanceInput : UHoudiniAssetParameter {
	// Fields
	char pad_0x80[0xe0]; // Offset: 0x80 | Size: 0xe0
};

// Object: Class HoudiniEngineRuntime.HoudiniAssetInstanceInputField
// Inherited Bytes: 0x28 | Struct Size: 0x190
struct UHoudiniAssetInstanceInputField : UObject {
	// Fields
	char pad_0x28[0x168]; // Offset: 0x28 | Size: 0x168
};

// Object: Class HoudiniEngineRuntime.HoudiniAssetComponent_V1
// Inherited Bytes: 0x5f0 | Struct Size: 0xae0
struct UHoudiniAssetComponent_V1 : UPrimitiveComponent {
	// Fields
	char bGeneratedDoubleSidedGeometry : 1; // Offset: 0x5e8 | Size: 0x1
	struct UPhysicalMaterial* GeneratedPhysMaterial; // Offset: 0x5f0 | Size: 0x8
	struct FBodyInstance DefaultBodyInstance; // Offset: 0x5f8 | Size: 0x130
	enum class ECollisionTraceFlag GeneratedCollisionTraceFlag; // Offset: 0x728 | Size: 0x1
	char pad_0x729_1 : 7; // Offset: 0x729 | Size: 0x1
	char pad_0x72A[0x2]; // Offset: 0x72a | Size: 0x2
	int32_t GeneratedLightMapResolution; // Offset: 0x72c | Size: 0x4
	float GeneratedDistanceFieldResolutionScale; // Offset: 0x730 | Size: 0x4
	struct FWalkableSlopeOverride GeneratedWalkableSlopeOverride; // Offset: 0x734 | Size: 0x10
	int32_t GeneratedLightMapCoordinateIndex; // Offset: 0x744 | Size: 0x4
	char bGeneratedUseMaximumStreamingTexelRatio : 1; // Offset: 0x748 | Size: 0x1
	char pad_0x748_1 : 7; // Offset: 0x748 | Size: 0x1
	char pad_0x749[0x3]; // Offset: 0x749 | Size: 0x3
	float GeneratedStreamingDistanceMultiplier; // Offset: 0x74c | Size: 0x4
	struct UFoliageType_InstancedStaticMesh* GeneratedFoliageDefaultSettings; // Offset: 0x750 | Size: 0x8
	struct TArray<struct UAssetUserData*> GeneratedAssetUserData; // Offset: 0x758 | Size: 0x10
	struct FText BakeFolder; // Offset: 0x768 | Size: 0x18
	struct FText TempCookFolder; // Offset: 0x780 | Size: 0x18
	char pad_0x798[0x348]; // Offset: 0x798 | Size: 0x348
};

// Object: Class HoudiniEngineRuntime.HoudiniInstancedActorComponent_V1
// Inherited Bytes: 0x370 | Struct Size: 0x380
struct UHoudiniInstancedActorComponent_V1 : USceneComponent {
	// Fields
	char pad_0x370[0x10]; // Offset: 0x370 | Size: 0x10
};

// Object: Class HoudiniEngineRuntime.HoudiniMeshSplitInstancerComponent_V1
// Inherited Bytes: 0x370 | Struct Size: 0x390
struct UHoudiniMeshSplitInstancerComponent_V1 : USceneComponent {
	// Fields
	char pad_0x370[0x20]; // Offset: 0x370 | Size: 0x20
};

// Object: Class HoudiniEngineRuntime.HoudiniInput
// Inherited Bytes: 0x28 | Struct Size: 0x278
struct UHoudiniInput : UObject {
	// Fields
	struct FString Name; // Offset: 0x28 | Size: 0x10
	struct FString Label; // Offset: 0x38 | Size: 0x10
	enum class EHoudiniInputType Type; // Offset: 0x48 | Size: 0x1
	enum class EHoudiniInputType PreviousType; // Offset: 0x49 | Size: 0x1
	char pad_0x4A[0x2]; // Offset: 0x4a | Size: 0x2
	int32_t AssetNodeId; // Offset: 0x4c | Size: 0x4
	int32_t InputNodeId; // Offset: 0x50 | Size: 0x4
	int32_t InputIndex; // Offset: 0x54 | Size: 0x4
	int32_t ParmId; // Offset: 0x58 | Size: 0x4
	bool bIsObjectPathParameter; // Offset: 0x5c | Size: 0x1
	char pad_0x5D[0x3]; // Offset: 0x5d | Size: 0x3
	struct TArray<int32_t> CreatedDataNodeIds; // Offset: 0x60 | Size: 0x10
	bool bHasChanged; // Offset: 0x70 | Size: 0x1
	bool bNeedsToTriggerUpdate; // Offset: 0x71 | Size: 0x1
	char pad_0x72[0x2]; // Offset: 0x72 | Size: 0x2
	struct FBox CachedBounds; // Offset: 0x74 | Size: 0x1c
	struct FString Help; // Offset: 0x90 | Size: 0x10
	enum class EHoudiniXformType KeepWorldTransform; // Offset: 0xa0 | Size: 0x1
	bool bPackBeforeMerge; // Offset: 0xa1 | Size: 0x1
	bool bImportAsReference; // Offset: 0xa2 | Size: 0x1
	bool bImportAsReferenceRotScaleEnabled; // Offset: 0xa3 | Size: 0x1
	bool bImportAsReferenceBboxEnabled; // Offset: 0xa4 | Size: 0x1
	bool bImportAsReferenceMaterialEnabled; // Offset: 0xa5 | Size: 0x1
	bool bExportLODs; // Offset: 0xa6 | Size: 0x1
	bool bExportSockets; // Offset: 0xa7 | Size: 0x1
	bool bExportColliders; // Offset: 0xa8 | Size: 0x1
	bool bExportMaterialParameters; // Offset: 0xa9 | Size: 0x1
	bool bCookOnCurveChanged; // Offset: 0xaa | Size: 0x1
	char pad_0xAB[0x5]; // Offset: 0xab | Size: 0x5
	struct TArray<struct UHoudiniInputObject*> GeometryInputObjects; // Offset: 0xb0 | Size: 0x10
	bool bStaticMeshChanged; // Offset: 0xc0 | Size: 0x1
	char pad_0xC1[0x7]; // Offset: 0xc1 | Size: 0x7
	struct TArray<struct UHoudiniInputObject*> AssetInputObjects; // Offset: 0xc8 | Size: 0x10
	bool bInputAssetConnectedInHoudini; // Offset: 0xd8 | Size: 0x1
	char pad_0xD9[0x7]; // Offset: 0xd9 | Size: 0x7
	struct TArray<struct UHoudiniInputObject*> CurveInputObjects; // Offset: 0xe0 | Size: 0x10
	float DefaultCurveOffset; // Offset: 0xf0 | Size: 0x4
	bool bAddRotAndScaleAttributesOnCurves; // Offset: 0xf4 | Size: 0x1
	bool bUseLegacyInputCurves; // Offset: 0xf5 | Size: 0x1
	char pad_0xF6[0x2]; // Offset: 0xf6 | Size: 0x2
	struct TArray<struct UHoudiniInputObject*> LandscapeInputObjects; // Offset: 0xf8 | Size: 0x10
	bool bLandscapeHasExportTypeChanged; // Offset: 0x108 | Size: 0x1
	char pad_0x109[0x7]; // Offset: 0x109 | Size: 0x7
	struct TArray<struct UHoudiniInputObject*> LandscapeSplinesInputObjects; // Offset: 0x110 | Size: 0x10
	struct TArray<struct UHoudiniInputObject*> FoliageInputObjects; // Offset: 0x120 | Size: 0x10
	struct TArray<struct UHoudiniInputObject*> WorldSMCInputObjects; // Offset: 0x130 | Size: 0x10
	struct TArray<struct UHoudiniInputObject*> PointCloudInputObjects; // Offset: 0x140 | Size: 0x10
	struct TArray<struct UHoudiniInputObject*> WorldInputObjects; // Offset: 0x150 | Size: 0x10
	struct TArray<struct UHoudiniInputObject*> TextureInputObjects; // Offset: 0x160 | Size: 0x10
	struct TArray<struct AActor*> WorldInputBoundSelectorObjects; // Offset: 0x170 | Size: 0x10
	bool bIsWorldInputBoundSelector; // Offset: 0x180 | Size: 0x1
	bool bWorldInputBoundSelectorAutoUpdate; // Offset: 0x181 | Size: 0x1
	char pad_0x182[0x2]; // Offset: 0x182 | Size: 0x2
	float UnrealSplineResolution; // Offset: 0x184 | Size: 0x4
	struct TArray<struct UHoudiniInputObject*> SkeletalInputObjects; // Offset: 0x188 | Size: 0x10
	struct TArray<struct UHoudiniInputObject*> GeometryCollectionInputObjects; // Offset: 0x198 | Size: 0x10
	struct TSet<struct ULandscapeComponent*> LandscapeSelectedComponents; // Offset: 0x1a8 | Size: 0x50
	struct TSet<int32_t> InputNodesPendingDelete; // Offset: 0x1f8 | Size: 0x50
	struct TArray<struct UHoudiniInputHoudiniSplineComponent*> LastInsertedInputs; // Offset: 0x248 | Size: 0x10
	struct TArray<struct UHoudiniInputObject*> LastUndoDeletedInputs; // Offset: 0x258 | Size: 0x10
	bool bUpdateInputLandscape; // Offset: 0x268 | Size: 0x1
	enum class EHoudiniLandscapeExportType LandscapeExportType; // Offset: 0x269 | Size: 0x1
	bool bLandscapeExportSelectionOnly; // Offset: 0x26a | Size: 0x1
	bool bLandscapeAutoSelectComponent; // Offset: 0x26b | Size: 0x1
	bool bLandscapeExportMaterials; // Offset: 0x26c | Size: 0x1
	bool bLandscapeExportLighting; // Offset: 0x26d | Size: 0x1
	bool bLandscapeExportNormalizedUVs; // Offset: 0x26e | Size: 0x1
	bool bLandscapeExportTileUVs; // Offset: 0x26f | Size: 0x1
	bool bCanDeleteHoudiniNodes; // Offset: 0x270 | Size: 0x1
	bool bAutoSelectInputType; // Offset: 0x271 | Size: 0x1
	bool bEnableSMCWorldFilter; // Offset: 0x272 | Size: 0x1
	bool bIsIncludeStaticMesh; // Offset: 0x273 | Size: 0x1
	bool bNeedSendModelMaterial; // Offset: 0x274 | Size: 0x1
	bool bNeedSendDataTableModel; // Offset: 0x275 | Size: 0x1
	bool bNeedSendFoliageInstanceCustomData; // Offset: 0x276 | Size: 0x1
	char pad_0x277[0x1]; // Offset: 0x277 | Size: 0x1
};

// Object: Class HoudiniEngineRuntime.HoudiniParameterToggle
// Inherited Bytes: 0x108 | Struct Size: 0x128
struct UHoudiniParameterToggle : UHoudiniParameter {
	// Fields
	struct TArray<int32_t> Values; // Offset: 0x108 | Size: 0x10
	struct TArray<int32_t> DefaultValues; // Offset: 0x118 | Size: 0x10
};

// Object: Class HoudiniEngineRuntime.HoudiniRuntimeSettings
// Inherited Bytes: 0x28 | Struct Size: 0x2d0
struct UHoudiniRuntimeSettings : UObject {
	// Fields
	enum class EHoudiniRuntimeSettingsSessionType SessionType; // Offset: 0x28 | Size: 0x1
	char pad_0x29[0x7]; // Offset: 0x29 | Size: 0x7
	struct FString ServerHost; // Offset: 0x30 | Size: 0x10
	int32_t ServerPort; // Offset: 0x40 | Size: 0x4
	char pad_0x44[0x4]; // Offset: 0x44 | Size: 0x4
	struct FString ServerPipeName; // Offset: 0x48 | Size: 0x10
	bool bStartAutomaticServer; // Offset: 0x58 | Size: 0x1
	char pad_0x59[0x3]; // Offset: 0x59 | Size: 0x3
	float AutomaticServerTimeout; // Offset: 0x5c | Size: 0x4
	bool bSyncWithHoudiniCook; // Offset: 0x60 | Size: 0x1
	bool bCookUsingHoudiniTime; // Offset: 0x61 | Size: 0x1
	bool bSyncViewport; // Offset: 0x62 | Size: 0x1
	bool bSyncHoudiniViewport; // Offset: 0x63 | Size: 0x1
	bool bSyncUnrealViewport; // Offset: 0x64 | Size: 0x1
	bool bShowMultiAssetDialog; // Offset: 0x65 | Size: 0x1
	bool bPreferHdaMemoryCopyOverHdaSourceFile; // Offset: 0x66 | Size: 0x1
	bool bPauseCookingOnStart; // Offset: 0x67 | Size: 0x1
	bool bDisplaySlateCookingNotifications; // Offset: 0x68 | Size: 0x1
	char pad_0x69[0x7]; // Offset: 0x69 | Size: 0x7
	struct FString DefaultTemporaryCookFolder; // Offset: 0x70 | Size: 0x10
	struct FString DefaultBakeFolder; // Offset: 0x80 | Size: 0x10
	bool bEnableTheReferenceCountedInputSystem; // Offset: 0x90 | Size: 0x1
	bool MarshallingLandscapesUseDefaultUnrealScaling; // Offset: 0x91 | Size: 0x1
	bool MarshallingLandscapesUseFullResolution; // Offset: 0x92 | Size: 0x1
	bool MarshallingLandscapesForceMinMaxValues; // Offset: 0x93 | Size: 0x1
	float MarshallingLandscapesForcedMinValue; // Offset: 0x94 | Size: 0x4
	float MarshallingLandscapesForcedMaxValue; // Offset: 0x98 | Size: 0x4
	bool bAddRotAndScaleAttributesOnCurves; // Offset: 0x9c | Size: 0x1
	bool bUseLegacyInputCurves; // Offset: 0x9d | Size: 0x1
	char pad_0x9E[0x2]; // Offset: 0x9e | Size: 0x2
	float MarshallingSplineResolution; // Offset: 0xa0 | Size: 0x4
	bool bEnableProxyStaticMesh; // Offset: 0xa4 | Size: 0x1
	bool bShowDefaultMesh; // Offset: 0xa5 | Size: 0x1
	bool bEnableProxyStaticMeshRefinementByTimer; // Offset: 0xa6 | Size: 0x1
	char pad_0xA7[0x1]; // Offset: 0xa7 | Size: 0x1
	float ProxyMeshAutoRefineTimeoutSeconds; // Offset: 0xa8 | Size: 0x4
	bool bEnableProxyStaticMeshRefinementOnPreSaveWorld; // Offset: 0xac | Size: 0x1
	bool bEnableProxyStaticMeshRefinementOnPreBeginPIE; // Offset: 0xad | Size: 0x1
	char bDoubleSidedGeometry : 1; // Offset: 0xae | Size: 0x1
	char pad_0xAE_1 : 7; // Offset: 0xae | Size: 0x1
	char pad_0xAF[0x1]; // Offset: 0xaf | Size: 0x1
	struct UPhysicalMaterial* PhysMaterial; // Offset: 0xb0 | Size: 0x8
	struct FBodyInstance DefaultBodyInstance; // Offset: 0xb8 | Size: 0x130
	enum class ECollisionTraceFlag CollisionTraceFlag; // Offset: 0x1e8 | Size: 0x1
	char pad_0x1E9[0x3]; // Offset: 0x1e9 | Size: 0x3
	int32_t LightMapResolution; // Offset: 0x1ec | Size: 0x4
	float LpvBiasMultiplier; // Offset: 0x1f0 | Size: 0x4
	float GeneratedDistanceFieldResolutionScale; // Offset: 0x1f4 | Size: 0x4
	struct FWalkableSlopeOverride WalkableSlopeOverride; // Offset: 0x1f8 | Size: 0x10
	int32_t LightMapCoordinateIndex; // Offset: 0x208 | Size: 0x4
	char bUseMaximumStreamingTexelRatio : 1; // Offset: 0x20c | Size: 0x1
	char pad_0x20C_1 : 7; // Offset: 0x20c | Size: 0x1
	char pad_0x20D[0x3]; // Offset: 0x20d | Size: 0x3
	float StreamingDistanceMultiplier; // Offset: 0x210 | Size: 0x4
	char pad_0x214[0x4]; // Offset: 0x214 | Size: 0x4
	struct UFoliageType_InstancedStaticMesh* FoliageDefaultSettings; // Offset: 0x218 | Size: 0x8
	struct TArray<struct UAssetUserData*> AssetUserData; // Offset: 0x220 | Size: 0x10
	bool bUseFullPrecisionUVs; // Offset: 0x230 | Size: 0x1
	char pad_0x231[0x3]; // Offset: 0x231 | Size: 0x3
	int32_t SrcLightmapIndex; // Offset: 0x234 | Size: 0x4
	int32_t DstLightmapIndex; // Offset: 0x238 | Size: 0x4
	int32_t MinLightmapResolution; // Offset: 0x23c | Size: 0x4
	bool bRemoveDegenerates; // Offset: 0x240 | Size: 0x1
	enum class EHoudiniRuntimeSettingsRecomputeFlag GenerateLightmapUVsFlag; // Offset: 0x241 | Size: 0x1
	enum class EHoudiniRuntimeSettingsRecomputeFlag RecomputeNormalsFlag; // Offset: 0x242 | Size: 0x1
	enum class EHoudiniRuntimeSettingsRecomputeFlag RecomputeTangentsFlag; // Offset: 0x243 | Size: 0x1
	bool bUseMikkTSpace; // Offset: 0x244 | Size: 0x1
	bool bBuildAdjacencyBuffer; // Offset: 0x245 | Size: 0x1
	char bComputeWeightedNormals : 1; // Offset: 0x246 | Size: 0x1
	char bBuildReversedIndexBuffer : 1; // Offset: 0x246 | Size: 0x1
	char bUseHighPrecisionTangentBasis : 1; // Offset: 0x246 | Size: 0x1
	char pad_0x246_3 : 5; // Offset: 0x246 | Size: 0x1
	char pad_0x247[0x1]; // Offset: 0x247 | Size: 0x1
	float DistanceFieldResolutionScale; // Offset: 0x248 | Size: 0x4
	char bGenerateDistanceFieldAsIfTwoSided : 1; // Offset: 0x24c | Size: 0x1
	char bSupportFaceRemap : 1; // Offset: 0x24c | Size: 0x1
	char pad_0x24C_2 : 6; // Offset: 0x24c | Size: 0x1
	bool bPDGAsyncCommandletImportEnabled; // Offset: 0x24d | Size: 0x1
	bool bEnableBackwardCompatibility; // Offset: 0x24e | Size: 0x1
	bool bAutomaticLegacyHDARebuild; // Offset: 0x24f | Size: 0x1
	bool bUseCustomHoudiniLocation; // Offset: 0x250 | Size: 0x1
	char pad_0x251[0x7]; // Offset: 0x251 | Size: 0x7
	struct FDirectoryPath CustomHoudiniLocation; // Offset: 0x258 | Size: 0x10
	enum class EHoudiniExecutableType HoudiniExecutable; // Offset: 0x268 | Size: 0x1
	char pad_0x269[0x3]; // Offset: 0x269 | Size: 0x3
	int32_t CookingThreadStackSize; // Offset: 0x26c | Size: 0x4
	struct FString HoudiniEnvironmentFiles; // Offset: 0x270 | Size: 0x10
	struct FString SyncNetDiscPath; // Offset: 0x280 | Size: 0x10
	struct FString OtlSearchPath; // Offset: 0x290 | Size: 0x10
	struct FString DsoSearchPath; // Offset: 0x2a0 | Size: 0x10
	struct FString ImageDsoSearchPath; // Offset: 0x2b0 | Size: 0x10
	struct FString AudioDsoSearchPath; // Offset: 0x2c0 | Size: 0x10
};

// Object: Class HoudiniEngineRuntime.HoudiniParameterSeparator
// Inherited Bytes: 0x108 | Struct Size: 0x108
struct UHoudiniParameterSeparator : UHoudiniParameter {
};

// Object: Class HoudiniEngineRuntime.HoudiniInstancedActorComponent
// Inherited Bytes: 0x370 | Struct Size: 0x380
struct UHoudiniInstancedActorComponent : USceneComponent {
	// Fields
	struct UObject* InstancedObject; // Offset: 0x368 | Size: 0x8
	struct TArray<struct AActor*> InstancedActors; // Offset: 0x370 | Size: 0x10
};

// Object: Class HoudiniEngineRuntime.HoudiniParameterOperatorPath
// Inherited Bytes: 0x108 | Struct Size: 0x110
struct UHoudiniParameterOperatorPath : UHoudiniParameter {
	// Fields
	struct TWeakObjectPtr<struct UHoudiniInput> HoudiniInput; // Offset: 0x104 | Size: 0x8
};

// Object: Class HoudiniEngineRuntime.HoudiniInputObject
// Inherited Bytes: 0x28 | Struct Size: 0xf0
struct UHoudiniInputObject : UObject {
	// Fields
	struct TSoftObjectPtr<UObject> InputObject; // Offset: 0x28 | Size: 0x28
	struct FTransform Transform; // Offset: 0x50 | Size: 0x30
	enum class EHoudiniInputObjectType Type; // Offset: 0x80 | Size: 0x1
	char pad_0x81[0x3]; // Offset: 0x81 | Size: 0x3
	int32_t InputNodeId; // Offset: 0x84 | Size: 0x4
	int32_t InputObjectNodeId; // Offset: 0x88 | Size: 0x4
	struct FGuid Guid; // Offset: 0x8c | Size: 0x10
	char pad_0x9C[0x2c]; // Offset: 0x9c | Size: 0x2c
	bool bHasChanged; // Offset: 0xc8 | Size: 0x1
	bool bNeedsToTriggerUpdate; // Offset: 0xc9 | Size: 0x1
	bool bTransformChanged; // Offset: 0xca | Size: 0x1
	bool bImportAsReference; // Offset: 0xcb | Size: 0x1
	bool bImportAsReferenceRotScaleEnabled; // Offset: 0xcc | Size: 0x1
	bool bImportAsReferenceBboxEnabled; // Offset: 0xcd | Size: 0x1
	bool bImportAsReferenceMaterialEnabled; // Offset: 0xce | Size: 0x1
	char pad_0xCF[0x1]; // Offset: 0xcf | Size: 0x1
	struct TArray<struct FString> MaterialReferences; // Offset: 0xd0 | Size: 0x10
	bool bCanDeleteHoudiniNodes; // Offset: 0xe0 | Size: 0x1
	char pad_0xE1[0xf]; // Offset: 0xe1 | Size: 0xf
};

// Object: Class HoudiniEngineRuntime.HoudiniInputStaticMesh
// Inherited Bytes: 0xf0 | Struct Size: 0xf0
struct UHoudiniInputStaticMesh : UHoudiniInputObject {
};

// Object: Class HoudiniEngineRuntime.HoudiniInputTexture
// Inherited Bytes: 0xf0 | Struct Size: 0xf0
struct UHoudiniInputTexture : UHoudiniInputObject {
};

// Object: Class HoudiniEngineRuntime.HoudiniInputSkeletalMesh
// Inherited Bytes: 0xf0 | Struct Size: 0xf0
struct UHoudiniInputSkeletalMesh : UHoudiniInputObject {
};

// Object: Class HoudiniEngineRuntime.HoudiniInputGeometryCollection
// Inherited Bytes: 0xf0 | Struct Size: 0xf0
struct UHoudiniInputGeometryCollection : UHoudiniInputObject {
};

// Object: Class HoudiniEngineRuntime.HoudiniInputSceneComponent
// Inherited Bytes: 0xf0 | Struct Size: 0x120
struct UHoudiniInputSceneComponent : UHoudiniInputObject {
	// Fields
	struct FTransform ActorTransform; // Offset: 0xf0 | Size: 0x30
};

// Object: Class HoudiniEngineRuntime.HoudiniInputMeshComponent
// Inherited Bytes: 0x120 | Struct Size: 0x150
struct UHoudiniInputMeshComponent : UHoudiniInputSceneComponent {
	// Fields
	struct TSoftObjectPtr<UStaticMesh> StaticMesh; // Offset: 0x120 | Size: 0x28
	char pad_0x148[0x8]; // Offset: 0x148 | Size: 0x8
};

// Object: Class HoudiniEngineRuntime.HoudiniInputInstancedMeshComponent
// Inherited Bytes: 0x150 | Struct Size: 0x160
struct UHoudiniInputInstancedMeshComponent : UHoudiniInputMeshComponent {
	// Fields
	struct TArray<struct FTransform> InstanceTransforms; // Offset: 0x148 | Size: 0x10
};

// Object: Class HoudiniEngineRuntime.HoudiniInputLandscapeSplineComponent
// Inherited Bytes: 0x120 | Struct Size: 0x140
struct UHoudiniInputLandscapeSplineComponent : UHoudiniInputSceneComponent {
	// Fields
	int32_t NumberOfSplineControlPoints; // Offset: 0x120 | Size: 0x4
	float SplineLength; // Offset: 0x124 | Size: 0x4
	float SplineResolution; // Offset: 0x128 | Size: 0x4
	bool SplineClosed; // Offset: 0x12c | Size: 0x1
	char pad_0x12D[0x3]; // Offset: 0x12d | Size: 0x3
	struct TArray<struct FTransform> SplineControlPoints; // Offset: 0x130 | Size: 0x10
};

// Object: Class HoudiniEngineRuntime.HoudiniInputSplineComponent
// Inherited Bytes: 0x120 | Struct Size: 0x140
struct UHoudiniInputSplineComponent : UHoudiniInputSceneComponent {
	// Fields
	int32_t NumberOfSplineControlPoints; // Offset: 0x120 | Size: 0x4
	float SplineLength; // Offset: 0x124 | Size: 0x4
	float SplineResolution; // Offset: 0x128 | Size: 0x4
	bool SplineClosed; // Offset: 0x12c | Size: 0x1
	char pad_0x12D[0x3]; // Offset: 0x12d | Size: 0x3
	struct TArray<struct FTransform> SplineControlPoints; // Offset: 0x130 | Size: 0x10
};

// Object: Class HoudiniEngineRuntime.HoudiniInputGeometryCollectionComponent
// Inherited Bytes: 0x120 | Struct Size: 0x120
struct UHoudiniInputGeometryCollectionComponent : UHoudiniInputSceneComponent {
};

// Object: Class HoudiniEngineRuntime.HoudiniInputSkeletalMeshComponent
// Inherited Bytes: 0x120 | Struct Size: 0x120
struct UHoudiniInputSkeletalMeshComponent : UHoudiniInputSceneComponent {
};

// Object: Class HoudiniEngineRuntime.HoudiniInputHoudiniSplineComponent
// Inherited Bytes: 0xf0 | Struct Size: 0xf0
struct UHoudiniInputHoudiniSplineComponent : UHoudiniInputObject {
	// Fields
	enum class EHoudiniCurveType CurveType; // Offset: 0xe1 | Size: 0x1
	enum class EHoudiniCurveMethod CurveMethod; // Offset: 0xe2 | Size: 0x1
	bool Reversed; // Offset: 0xe3 | Size: 0x1
	struct UHoudiniSplineComponent* CachedComponent; // Offset: 0xe8 | Size: 0x8
};

// Object: Class HoudiniEngineRuntime.HoudiniInputCameraComponent
// Inherited Bytes: 0x120 | Struct Size: 0x140
struct UHoudiniInputCameraComponent : UHoudiniInputSceneComponent {
	// Fields
	float FOV; // Offset: 0x120 | Size: 0x4
	float AspectRatio; // Offset: 0x124 | Size: 0x4
	bool bIsOrthographic; // Offset: 0x128 | Size: 0x1
	char pad_0x129[0x3]; // Offset: 0x129 | Size: 0x3
	float OrthoWidth; // Offset: 0x12c | Size: 0x4
	float OrthoNearClipPlane; // Offset: 0x130 | Size: 0x4
	float OrthoFarClipPlane; // Offset: 0x134 | Size: 0x4
	char pad_0x138[0x8]; // Offset: 0x138 | Size: 0x8
};

// Object: Class HoudiniEngineRuntime.HoudiniInputHoudiniAsset
// Inherited Bytes: 0xf0 | Struct Size: 0xf0
struct UHoudiniInputHoudiniAsset : UHoudiniInputObject {
	// Fields
	int32_t AssetOutputIndex; // Offset: 0xe4 | Size: 0x4
};

// Object: Class HoudiniEngineRuntime.HoudiniInputActor
// Inherited Bytes: 0xf0 | Struct Size: 0x150
struct UHoudiniInputActor : UHoudiniInputObject {
	// Fields
	struct TArray<struct UHoudiniInputSceneComponent*> ActorComponents; // Offset: 0xe8 | Size: 0x10
	struct TSet<struct TSoftObjectPtr<UObject>> ActorSceneComponents; // Offset: 0xf8 | Size: 0x50
	int32_t LastUpdateNumComponentsAdded; // Offset: 0x148 | Size: 0x4
	int32_t LastUpdateNumComponentsRemoved; // Offset: 0x14c | Size: 0x4
};

// Object: Class HoudiniEngineRuntime.HoudiniInputLandscape
// Inherited Bytes: 0x150 | Struct Size: 0x250
struct UHoudiniInputLandscape : UHoudiniInputActor {
	// Fields
	struct FTransform CachedInputLandscapeTraqnsform; // Offset: 0x150 | Size: 0x30
	int32_t CachedNumLandscapeComponents; // Offset: 0x180 | Size: 0x4
	char pad_0x184[0x4]; // Offset: 0x184 | Size: 0x4
	struct FHoudiniInputLandscapeTransferParams TransferParams; // Offset: 0x188 | Size: 0xc8
};

// Object: Class HoudiniEngineRuntime.HoudiniInputInstancedFoliage
// Inherited Bytes: 0xf0 | Struct Size: 0xf0
struct UHoudiniInputInstancedFoliage : UHoudiniInputObject {
};

// Object: Class HoudiniEngineRuntime.HoudiniInputBrush
// Inherited Bytes: 0x150 | Struct Size: 0x170
struct UHoudiniInputBrush : UHoudiniInputActor {
	// Fields
	struct TArray<struct FHoudiniBrushInfo> BrushesInfo; // Offset: 0x150 | Size: 0x10
	struct UModel* CombinedModel; // Offset: 0x160 | Size: 0x8
	bool bIgnoreInputObject; // Offset: 0x168 | Size: 0x1
	enum class EBrushType CachedInputBrushType; // Offset: 0x169 | Size: 0x1
	char pad_0x16A[0x6]; // Offset: 0x16a | Size: 0x6
};

// Object: Class HoudiniEngineRuntime.HoudiniInputDataTable
// Inherited Bytes: 0xf0 | Struct Size: 0xf0
struct UHoudiniInputDataTable : UHoudiniInputObject {
};

// Object: Class HoudiniEngineRuntime.HoudiniInputFoliageType_InstancedStaticMesh
// Inherited Bytes: 0xf0 | Struct Size: 0xf0
struct UHoudiniInputFoliageType_InstancedStaticMesh : UHoudiniInputStaticMesh {
};

// Object: Class HoudiniEngineRuntime.HoudiniInputBlueprint
// Inherited Bytes: 0xf0 | Struct Size: 0x150
struct UHoudiniInputBlueprint : UHoudiniInputObject {
	// Fields
	struct TArray<struct UHoudiniInputSceneComponent*> BPComponents; // Offset: 0xe8 | Size: 0x10
	struct TSet<struct TSoftObjectPtr<UObject>> BPSceneComponents; // Offset: 0xf8 | Size: 0x50
	int32_t LastUpdateNumComponentsAdded; // Offset: 0x148 | Size: 0x4
	int32_t LastUpdateNumComponentsRemoved; // Offset: 0x14c | Size: 0x4
};

