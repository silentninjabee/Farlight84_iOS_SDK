#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct HoudiniEngineRuntime.HoudiniGenericAttribute
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FHoudiniGenericAttribute {
	// Fields
	struct FString AttributeName; // Offset: 0x0 | Size: 0x10
	enum class EAttribStorageType AttributeType; // Offset: 0x10 | Size: 0x1
	enum class EAttribOwner AttributeOwner; // Offset: 0x11 | Size: 0x1
	char pad_0x12[0x2]; // Offset: 0x12 | Size: 0x2
	int32_t AttributeCount; // Offset: 0x14 | Size: 0x4
	int32_t AttributeTupleSize; // Offset: 0x18 | Size: 0x4
	char pad_0x1C[0x4]; // Offset: 0x1c | Size: 0x4
	struct TArray<double> DoubleValues; // Offset: 0x20 | Size: 0x10
	struct TArray<int64_t> IntValues; // Offset: 0x30 | Size: 0x10
	struct TArray<struct FString> StringValues; // Offset: 0x40 | Size: 0x10
};

// Object: ScriptStruct HoudiniEngineRuntime.HoudiniGenericAttributeChangedProperty
// Inherited Bytes: 0x0 | Struct Size: 0x98
struct FHoudiniGenericAttributeChangedProperty {
	// Fields
	struct UObject* Object; // Offset: 0x0 | Size: 0x8
	char pad_0x8[0x90]; // Offset: 0x8 | Size: 0x90
};

// Object: ScriptStruct HoudiniEngineRuntime.HoudiniPDGWorkResultObjectBakedOutput
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FHoudiniPDGWorkResultObjectBakedOutput {
	// Fields
	struct TArray<struct FHoudiniBakedOutput> BakedOutputs; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct HoudiniEngineRuntime.HoudiniBakedOutput
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FHoudiniBakedOutput {
	// Fields
	struct TMap<struct FHoudiniBakedOutputObjectIdentifier, struct FHoudiniBakedOutputObject> BakedOutputObjects; // Offset: 0x0 | Size: 0x50
};

// Object: ScriptStruct HoudiniEngineRuntime.HoudiniBakedOutputObjectIdentifier
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FHoudiniBakedOutputObjectIdentifier {
	// Fields
	int32_t PartID; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct FString SplitIdentifier; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct HoudiniEngineRuntime.HoudiniBakedOutputObject
// Inherited Bytes: 0x0 | Struct Size: 0xb8
struct FHoudiniBakedOutputObject {
	// Fields
	struct FString Actor; // Offset: 0x0 | Size: 0x10
	struct FString Blueprint; // Offset: 0x10 | Size: 0x10
	struct FName ActorBakeName; // Offset: 0x20 | Size: 0x8
	struct FString BakedObject; // Offset: 0x28 | Size: 0x10
	struct FString BakedComponent; // Offset: 0x38 | Size: 0x10
	struct TArray<struct FString> InstancedActors; // Offset: 0x48 | Size: 0x10
	struct TArray<struct FString> InstancedComponents; // Offset: 0x58 | Size: 0x10
	struct TMap<struct FName, struct FString> LandscapeLayers; // Offset: 0x68 | Size: 0x50
};

// Object: ScriptStruct HoudiniEngineRuntime.WorkItemTallyBase
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FWorkItemTallyBase {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
};

// Object: ScriptStruct HoudiniEngineRuntime.AggregatedWorkItemTally
// Inherited Bytes: 0x8 | Struct Size: 0x28
struct FAggregatedWorkItemTally : FWorkItemTallyBase {
	// Fields
	int32_t TotalWorkItems; // Offset: 0x8 | Size: 0x4
	int32_t WaitingWorkItems; // Offset: 0xc | Size: 0x4
	int32_t ScheduledWorkItems; // Offset: 0x10 | Size: 0x4
	int32_t CookingWorkItems; // Offset: 0x14 | Size: 0x4
	int32_t CookedWorkItems; // Offset: 0x18 | Size: 0x4
	int32_t ErroredWorkItems; // Offset: 0x1c | Size: 0x4
	int32_t CookCancelledWorkItems; // Offset: 0x20 | Size: 0x4
	char pad_0x24[0x4]; // Offset: 0x24 | Size: 0x4
};

// Object: ScriptStruct HoudiniEngineRuntime.WorkItemTally
// Inherited Bytes: 0x8 | Struct Size: 0x238
struct FWorkItemTally : FWorkItemTallyBase {
	// Fields
	struct TSet<int32_t> AllWorkItems; // Offset: 0x8 | Size: 0x50
	struct TSet<int32_t> WaitingWorkItems; // Offset: 0x58 | Size: 0x50
	struct TSet<int32_t> ScheduledWorkItems; // Offset: 0xa8 | Size: 0x50
	struct TSet<int32_t> CookingWorkItems; // Offset: 0xf8 | Size: 0x50
	struct TSet<int32_t> CookedWorkItems; // Offset: 0x148 | Size: 0x50
	struct TSet<int32_t> ErroredWorkItems; // Offset: 0x198 | Size: 0x50
	struct TSet<int32_t> CookCancelledWorkItems; // Offset: 0x1e8 | Size: 0x50
};

// Object: ScriptStruct HoudiniEngineRuntime.TOPWorkResult
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FTOPWorkResult {
	// Fields
	int32_t WorkItemIndex; // Offset: 0x0 | Size: 0x4
	int32_t WorkItemID; // Offset: 0x4 | Size: 0x4
	struct TArray<struct FTOPWorkResultObject> ResultObjects; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct HoudiniEngineRuntime.TOPWorkResultObject
// Inherited Bytes: 0x0 | Struct Size: 0x58
struct FTOPWorkResultObject {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
	struct FString Name; // Offset: 0x8 | Size: 0x10
	struct FString FilePath; // Offset: 0x18 | Size: 0x10
	enum class EPDGWorkResultState State; // Offset: 0x28 | Size: 0x1
	char pad_0x29[0x3]; // Offset: 0x29 | Size: 0x3
	int32_t WorkItemResultInfoIndex; // Offset: 0x2c | Size: 0x4
	struct TArray<struct UHoudiniOutput*> ResultOutputs; // Offset: 0x30 | Size: 0x10
	bool bAutoBakedSinceLastLoad; // Offset: 0x40 | Size: 0x1
	char pad_0x41[0x7]; // Offset: 0x41 | Size: 0x7
	struct FOutputActorOwner OutputActorOwner; // Offset: 0x48 | Size: 0x10
};

// Object: ScriptStruct HoudiniEngineRuntime.OutputActorOwner
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FOutputActorOwner {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
	struct AActor* OutputActor; // Offset: 0x8 | Size: 0x8
};

// Object: ScriptStruct HoudiniEngineRuntime.HoudiniSplineComponentInstanceData
// Inherited Bytes: 0x58 | Struct Size: 0x88
struct FHoudiniSplineComponentInstanceData : FActorComponentInstanceData {
	// Fields
	struct TArray<struct FTransform> CurvePoints; // Offset: 0x58 | Size: 0x10
	struct TArray<struct FVector> DisplayPoints; // Offset: 0x68 | Size: 0x10
	struct TArray<int32_t> DisplayPointIndexDivider; // Offset: 0x78 | Size: 0x10
};

// Object: ScriptStruct HoudiniEngineRuntime.HoudiniOutputObject
// Inherited Bytes: 0x0 | Struct Size: 0xf8
struct FHoudiniOutputObject {
	// Fields
	struct UObject* OutputObject; // Offset: 0x0 | Size: 0x8
	struct UObject* OutputComponent; // Offset: 0x8 | Size: 0x8
	struct UObject* ProxyObject; // Offset: 0x10 | Size: 0x8
	struct UObject* ProxyComponent; // Offset: 0x18 | Size: 0x8
	bool bProxyIsCurrent; // Offset: 0x20 | Size: 0x1
	bool bIsImplicit; // Offset: 0x21 | Size: 0x1
	bool bIsGeometryCollectionPiece; // Offset: 0x22 | Size: 0x1
	char pad_0x23[0x5]; // Offset: 0x23 | Size: 0x5
	struct FString GeometryCollectionPieceName; // Offset: 0x28 | Size: 0x10
	struct FString BakeName; // Offset: 0x38 | Size: 0x10
	struct FHoudiniCurveOutputProperties CurveOutputProperty; // Offset: 0x48 | Size: 0xc
	char pad_0x54[0x4]; // Offset: 0x54 | Size: 0x4
	struct TMap<struct FString, struct FString> CachedAttributes; // Offset: 0x58 | Size: 0x50
	struct TMap<struct FString, struct FString> CachedTokens; // Offset: 0xa8 | Size: 0x50
};

// Object: ScriptStruct HoudiniEngineRuntime.HoudiniCurveOutputProperties
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FHoudiniCurveOutputProperties {
	// Fields
	enum class EHoudiniCurveOutputType CurveOutputType; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	int32_t NumPoints; // Offset: 0x4 | Size: 0x4
	bool bClosed; // Offset: 0x8 | Size: 0x1
	enum class EHoudiniCurveType CurveType; // Offset: 0x9 | Size: 0x1
	enum class EHoudiniCurveMethod CurveMethod; // Offset: 0xa | Size: 0x1
	char pad_0xB[0x1]; // Offset: 0xb | Size: 0x1
};

// Object: ScriptStruct HoudiniEngineRuntime.HoudiniInstancedOutput
// Inherited Bytes: 0x0 | Struct Size: 0x88
struct FHoudiniInstancedOutput {
	// Fields
	struct TSoftObjectPtr<UObject> OriginalObject; // Offset: 0x0 | Size: 0x28
	int32_t OriginalObjectIndex; // Offset: 0x28 | Size: 0x4
	char pad_0x2C[0x4]; // Offset: 0x2c | Size: 0x4
	struct TArray<struct FTransform> OriginalTransforms; // Offset: 0x30 | Size: 0x10
	struct TArray<struct TSoftObjectPtr<UObject>> VariationObjects; // Offset: 0x40 | Size: 0x10
	struct TArray<struct FTransform> VariationTransformOffsets; // Offset: 0x50 | Size: 0x10
	struct TArray<int32_t> TransformVariationIndices; // Offset: 0x60 | Size: 0x10
	struct TArray<int32_t> OriginalInstanceIndices; // Offset: 0x70 | Size: 0x10
	bool bChanged; // Offset: 0x80 | Size: 0x1
	bool bStale; // Offset: 0x81 | Size: 0x1
	char pad_0x82[0x6]; // Offset: 0x82 | Size: 0x6
};

// Object: ScriptStruct HoudiniEngineRuntime.HoudiniOutputObjectIdentifier
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FHoudiniOutputObjectIdentifier {
	// Fields
	int32_t ObjectId; // Offset: 0x0 | Size: 0x4
	int32_t GeoId; // Offset: 0x4 | Size: 0x4
	int32_t PartID; // Offset: 0x8 | Size: 0x4
	char pad_0xC[0x4]; // Offset: 0xc | Size: 0x4
	struct FString SplitIdentifier; // Offset: 0x10 | Size: 0x10
	struct FString PartName; // Offset: 0x20 | Size: 0x10
	int32_t PrimitiveIndex; // Offset: 0x30 | Size: 0x4
	int32_t PointIndex; // Offset: 0x34 | Size: 0x4
	char pad_0x38[0x8]; // Offset: 0x38 | Size: 0x8
};

// Object: ScriptStruct HoudiniEngineRuntime.HoudiniAssetBlueprintInstanceData
// Inherited Bytes: 0x58 | Struct Size: 0x110
struct FHoudiniAssetBlueprintInstanceData : FActorComponentInstanceData {
	// Fields
	struct UHoudiniAsset* HoudiniAsset; // Offset: 0x58 | Size: 0x8
	int32_t AssetId; // Offset: 0x60 | Size: 0x4
	enum class EHoudiniAssetState AssetState; // Offset: 0x64 | Size: 0x1
	char pad_0x65[0x3]; // Offset: 0x65 | Size: 0x3
	uint32_t SubAssetIndex; // Offset: 0x68 | Size: 0x4
	uint32_t AssetCookCount; // Offset: 0x6c | Size: 0x4
	bool bHasBeenLoaded; // Offset: 0x70 | Size: 0x1
	bool bHasBeenDuplicated; // Offset: 0x71 | Size: 0x1
	bool bPendingDelete; // Offset: 0x72 | Size: 0x1
	bool bRecookRequested; // Offset: 0x73 | Size: 0x1
	bool bRebuildRequested; // Offset: 0x74 | Size: 0x1
	bool bEnableCooking; // Offset: 0x75 | Size: 0x1
	bool bForceNeedUpdate; // Offset: 0x76 | Size: 0x1
	bool bLastCookSuccess; // Offset: 0x77 | Size: 0x1
	struct FGuid ComponentGUID; // Offset: 0x78 | Size: 0x10
	struct FGuid HapiGUID; // Offset: 0x88 | Size: 0x10
	bool bRegisteredComponentTemplate; // Offset: 0x98 | Size: 0x1
	char pad_0x99[0x7]; // Offset: 0x99 | Size: 0x7
	struct FString SourceName; // Offset: 0xa0 | Size: 0x10
	struct TMap<struct FHoudiniOutputObjectIdentifier, struct FHoudiniAssetBlueprintOutput> Outputs; // Offset: 0xb0 | Size: 0x50
	struct TArray<struct UHoudiniInput*> Inputs; // Offset: 0x100 | Size: 0x10
};

// Object: ScriptStruct HoudiniEngineRuntime.HoudiniAssetBlueprintOutput
// Inherited Bytes: 0x0 | Struct Size: 0x100
struct FHoudiniAssetBlueprintOutput {
	// Fields
	int32_t OutputIndex; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct FHoudiniOutputObject OutputObject; // Offset: 0x8 | Size: 0xf8
};

// Object: ScriptStruct HoudiniEngineRuntime.HoudiniGeoPartObject
// Inherited Bytes: 0x0 | Struct Size: 0x230
struct FHoudiniGeoPartObject {
	// Fields
	int32_t AssetId; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct FString AssetName; // Offset: 0x8 | Size: 0x10
	int32_t ObjectId; // Offset: 0x18 | Size: 0x4
	char pad_0x1C[0x4]; // Offset: 0x1c | Size: 0x4
	struct FString ObjectName; // Offset: 0x20 | Size: 0x10
	int32_t GeoId; // Offset: 0x30 | Size: 0x4
	int32_t PartID; // Offset: 0x34 | Size: 0x4
	struct FString PartName; // Offset: 0x38 | Size: 0x10
	bool bHasCustomPartName; // Offset: 0x48 | Size: 0x1
	char pad_0x49[0x7]; // Offset: 0x49 | Size: 0x7
	struct TArray<struct FString> SplitGroups; // Offset: 0x50 | Size: 0x10
	struct FTransform TransformMatrix; // Offset: 0x60 | Size: 0x30
	struct FString NodePath; // Offset: 0x90 | Size: 0x10
	enum class EHoudiniPartType Type; // Offset: 0xa0 | Size: 0x1
	enum class EHoudiniInstancerType InstancerType; // Offset: 0xa1 | Size: 0x1
	char pad_0xA2[0x6]; // Offset: 0xa2 | Size: 0x6
	struct FString VolumeName; // Offset: 0xa8 | Size: 0x10
	bool bHasEditLayers; // Offset: 0xb8 | Size: 0x1
	char pad_0xB9[0x7]; // Offset: 0xb9 | Size: 0x7
	struct FString VolumeLayerName; // Offset: 0xc0 | Size: 0x10
	int32_t VolumeTileIndex; // Offset: 0xd0 | Size: 0x4
	bool bIsVisible; // Offset: 0xd4 | Size: 0x1
	bool bIsEditable; // Offset: 0xd5 | Size: 0x1
	bool bIsTemplated; // Offset: 0xd6 | Size: 0x1
	bool bIsInstanced; // Offset: 0xd7 | Size: 0x1
	bool bHasGeoChanged; // Offset: 0xd8 | Size: 0x1
	bool bHasPartChanged; // Offset: 0xd9 | Size: 0x1
	bool bHasTransformChanged; // Offset: 0xda | Size: 0x1
	bool bHasMaterialsChanged; // Offset: 0xdb | Size: 0x1
	char pad_0xDC[0x144]; // Offset: 0xdc | Size: 0x144
	struct TArray<struct FHoudiniMeshSocket> AllMeshSockets; // Offset: 0x220 | Size: 0x10
};

// Object: ScriptStruct HoudiniEngineRuntime.HoudiniMeshSocket
// Inherited Bytes: 0x0 | Struct Size: 0x60
struct FHoudiniMeshSocket {
	// Fields
	char pad_0x0[0x60]; // Offset: 0x0 | Size: 0x60
};

// Object: ScriptStruct HoudiniEngineRuntime.HoudiniCurveInfo
// Inherited Bytes: 0x0 | Struct Size: 0x1c
struct FHoudiniCurveInfo {
	// Fields
	char pad_0x0[0x1c]; // Offset: 0x0 | Size: 0x1c
};

// Object: ScriptStruct HoudiniEngineRuntime.HoudiniVolumeInfo
// Inherited Bytes: 0x0 | Struct Size: 0x80
struct FHoudiniVolumeInfo {
	// Fields
	char pad_0x0[0x80]; // Offset: 0x0 | Size: 0x80
};

// Object: ScriptStruct HoudiniEngineRuntime.HoudiniPartInfo
// Inherited Bytes: 0x0 | Struct Size: 0x48
struct FHoudiniPartInfo {
	// Fields
	char pad_0x0[0x48]; // Offset: 0x0 | Size: 0x48
};

// Object: ScriptStruct HoudiniEngineRuntime.HoudiniGeoInfo
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FHoudiniGeoInfo {
	// Fields
	char pad_0x0[0x30]; // Offset: 0x0 | Size: 0x30
};

// Object: ScriptStruct HoudiniEngineRuntime.HoudiniObjectInfo
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FHoudiniObjectInfo {
	// Fields
	char pad_0x0[0x28]; // Offset: 0x0 | Size: 0x28
};

// Object: ScriptStruct HoudiniEngineRuntime.HoudiniStaticMeshGenerationProperties
// Inherited Bytes: 0x0 | Struct Size: 0x180
struct FHoudiniStaticMeshGenerationProperties {
	// Fields
	char bGeneratedDoubleSidedGeometry : 1; // Offset: 0x0 | Size: 0x1
	char pad_0x0_1 : 7; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x7]; // Offset: 0x1 | Size: 0x7
	struct UPhysicalMaterial* GeneratedPhysMaterial; // Offset: 0x8 | Size: 0x8
	struct FBodyInstance DefaultBodyInstance; // Offset: 0x10 | Size: 0x130
	enum class ECollisionTraceFlag GeneratedCollisionTraceFlag; // Offset: 0x140 | Size: 0x1
	char pad_0x141[0x3]; // Offset: 0x141 | Size: 0x3
	int32_t GeneratedLightMapResolution; // Offset: 0x144 | Size: 0x4
	struct FWalkableSlopeOverride GeneratedWalkableSlopeOverride; // Offset: 0x148 | Size: 0x10
	int32_t GeneratedLightMapCoordinateIndex; // Offset: 0x158 | Size: 0x4
	char bGeneratedUseMaximumStreamingTexelRatio : 1; // Offset: 0x15c | Size: 0x1
	char pad_0x15C_1 : 7; // Offset: 0x15c | Size: 0x1
	char pad_0x15D[0x3]; // Offset: 0x15d | Size: 0x3
	float GeneratedStreamingDistanceMultiplier; // Offset: 0x160 | Size: 0x4
	char pad_0x164[0x4]; // Offset: 0x164 | Size: 0x4
	struct UFoliageType_InstancedStaticMesh* GeneratedFoliageDefaultSettings; // Offset: 0x168 | Size: 0x8
	struct TArray<struct UAssetUserData*> GeneratedAssetUserData; // Offset: 0x170 | Size: 0x10
};

// Object: ScriptStruct HoudiniEngineRuntime.HoudiniBrushInfo
// Inherited Bytes: 0x0 | Struct Size: 0x70
struct FHoudiniBrushInfo {
	// Fields
	struct TWeakObjectPtr<struct ABrush> BrushActor; // Offset: 0x0 | Size: 0x8
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FTransform CachedTransform; // Offset: 0x10 | Size: 0x30
	struct FVector CachedOrigin; // Offset: 0x40 | Size: 0xc
	struct FVector CachedExtent; // Offset: 0x4c | Size: 0xc
	enum class EBrushType CachedBrushType; // Offset: 0x58 | Size: 0x1
	char pad_0x59[0x7]; // Offset: 0x59 | Size: 0x7
	uint64_t CachedSurfaceHash; // Offset: 0x60 | Size: 0x8
	char pad_0x68[0x8]; // Offset: 0x68 | Size: 0x8
};

// Object: ScriptStruct HoudiniEngineRuntime.HoudiniInputLandscapeTransferParams
// Inherited Bytes: 0x0 | Struct Size: 0xc8
struct FHoudiniInputLandscapeTransferParams {
	// Fields
	enum class ETransferHeightMode TransferHeightMode; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x7]; // Offset: 0x1 | Size: 0x7
	struct TSet<struct FName> HeightSpecifiedLayerNames; // Offset: 0x8 | Size: 0x50
	struct FName HeightUnderSpecifiedLayerName; // Offset: 0x58 | Size: 0x8
	enum class ETransferLayerMode TransferLayerMode; // Offset: 0x60 | Size: 0x1
	char pad_0x61[0x7]; // Offset: 0x61 | Size: 0x7
	struct TSet<struct FName> LayerSpecifiedLayerNames; // Offset: 0x68 | Size: 0x50
	struct FName LayerUnderSpecifiedLayerName; // Offset: 0xb8 | Size: 0x8
	bool bTransferWeightmap; // Offset: 0xc0 | Size: 0x1
	char pad_0xC1[0x7]; // Offset: 0xc1 | Size: 0x7
};

