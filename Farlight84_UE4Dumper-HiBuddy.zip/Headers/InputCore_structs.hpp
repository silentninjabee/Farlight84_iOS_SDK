#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct InputCore.Key
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FKey {
	// Fields
	struct FName KeyName; // Offset: 0x0 | Size: 0x8
	char pad_0x8[0x10]; // Offset: 0x8 | Size: 0x10
};

