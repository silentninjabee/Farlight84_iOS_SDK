#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct InteractiveToolsFramework.BrushStampData
// Inherited Bytes: 0x0 | Struct Size: 0xa8
struct FBrushStampData {
	// Fields
	char pad_0x0[0xa8]; // Offset: 0x0 | Size: 0xa8
};

// Object: ScriptStruct InteractiveToolsFramework.BehaviorInfo
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FBehaviorInfo {
	// Fields
	struct UInputBehavior* Behavior; // Offset: 0x0 | Size: 0x8
	char pad_0x8[0x18]; // Offset: 0x8 | Size: 0x18
};

// Object: ScriptStruct InteractiveToolsFramework.InputRayHit
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FInputRayHit {
	// Fields
	char pad_0x0[0x28]; // Offset: 0x0 | Size: 0x28
};

// Object: ScriptStruct InteractiveToolsFramework.ActiveGizmo
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FActiveGizmo {
	// Fields
	char pad_0x0[0x30]; // Offset: 0x0 | Size: 0x30
};

// Object: ScriptStruct InteractiveToolsFramework.GizmoFloatParameterChange
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FGizmoFloatParameterChange {
	// Fields
	float InitialValue; // Offset: 0x0 | Size: 0x4
	float CurrentValue; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct InteractiveToolsFramework.GizmoVec2ParameterChange
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FGizmoVec2ParameterChange {
	// Fields
	struct FVector2D InitialValue; // Offset: 0x0 | Size: 0x8
	struct FVector2D CurrentValue; // Offset: 0x8 | Size: 0x8
};

