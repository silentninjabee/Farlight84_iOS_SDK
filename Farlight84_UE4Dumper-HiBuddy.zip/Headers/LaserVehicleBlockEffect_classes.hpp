#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass LaserVehicleBlockEffect.LaserVehicleBlockEffect_C
// Inherited Bytes: 0x898 | Struct Size: 0x898
struct ULaserVehicleBlockEffect_C : UGameplayEffect {
};

