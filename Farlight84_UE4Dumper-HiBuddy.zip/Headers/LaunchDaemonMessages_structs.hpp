#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct LaunchDaemonMessages.IOSLaunchDaemonLaunchApp
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FIOSLaunchDaemonLaunchApp {
	// Fields
	struct FString AppId; // Offset: 0x0 | Size: 0x10
	struct FString Parameters; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct LaunchDaemonMessages.IOSLaunchDaemonPong
// Inherited Bytes: 0x0 | Struct Size: 0x48
struct FIOSLaunchDaemonPong {
	// Fields
	struct FString DeviceID; // Offset: 0x0 | Size: 0x10
	struct FString DeviceName; // Offset: 0x10 | Size: 0x10
	struct FString DeviceStatus; // Offset: 0x20 | Size: 0x10
	struct FString DeviceType; // Offset: 0x30 | Size: 0x10
	bool bCanPowerOff; // Offset: 0x40 | Size: 0x1
	bool bCanPowerOn; // Offset: 0x41 | Size: 0x1
	bool bCanReboot; // Offset: 0x42 | Size: 0x1
	char pad_0x43[0x5]; // Offset: 0x43 | Size: 0x5
};

// Object: ScriptStruct LaunchDaemonMessages.IOSLaunchDaemonPing
// Inherited Bytes: 0x0 | Struct Size: 0x1
struct FIOSLaunchDaemonPing {
	// Fields
	char pad_0x0[0x1]; // Offset: 0x0 | Size: 0x1
};

