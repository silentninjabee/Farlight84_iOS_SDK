#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct LevelSequence.LevelSequenceCameraSettings
// Inherited Bytes: 0x0 | Struct Size: 0x2
struct FLevelSequenceCameraSettings {
	// Fields
	bool bOverrideAspectRatioAxisConstraint; // Offset: 0x0 | Size: 0x1
	enum class EAspectRatioAxisConstraint AspectRatioAxisConstraint; // Offset: 0x1 | Size: 0x1
};

// Object: ScriptStruct LevelSequence.BoundActorProxy
// Inherited Bytes: 0x0 | Struct Size: 0x1
struct FBoundActorProxy {
	// Fields
	char pad_0x0[0x1]; // Offset: 0x0 | Size: 0x1
};

// Object: ScriptStruct LevelSequence.LevelSequenceBindingReferences
// Inherited Bytes: 0x0 | Struct Size: 0xa0
struct FLevelSequenceBindingReferences {
	// Fields
	struct TMap<struct FGuid, struct FLevelSequenceBindingReferenceArray> BindingIdToReferences; // Offset: 0x0 | Size: 0x50
	struct TSet<struct FGuid> AnimSequenceInstances; // Offset: 0x50 | Size: 0x50
};

// Object: ScriptStruct LevelSequence.LevelSequenceBindingReferenceArray
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FLevelSequenceBindingReferenceArray {
	// Fields
	struct TArray<struct FLevelSequenceBindingReference> References; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct LevelSequence.LevelSequenceBindingReference
// Inherited Bytes: 0x0 | Struct Size: 0x38
struct FLevelSequenceBindingReference {
	// Fields
	struct FString PackageName; // Offset: 0x0 | Size: 0x10
	struct FSoftObjectPath ExternalObjectPath; // Offset: 0x10 | Size: 0x18
	struct FString ObjectPath; // Offset: 0x28 | Size: 0x10
};

// Object: ScriptStruct LevelSequence.LevelSequenceObjectReferenceMap
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FLevelSequenceObjectReferenceMap {
	// Fields
	char pad_0x0[0x50]; // Offset: 0x0 | Size: 0x50
};

// Object: ScriptStruct LevelSequence.LevelSequenceLegacyObjectReference
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FLevelSequenceLegacyObjectReference {
	// Fields
	char pad_0x0[0x20]; // Offset: 0x0 | Size: 0x20
};

// Object: ScriptStruct LevelSequence.LevelSequenceObject
// Inherited Bytes: 0x0 | Struct Size: 0x38
struct FLevelSequenceObject {
	// Fields
	LazyObjectProperty ObjectOrOwner; // Offset: 0x0 | Size: 0x1c
	char pad_0x1C[0x4]; // Offset: 0x1c | Size: 0x4
	struct FString ComponentName; // Offset: 0x20 | Size: 0x10
	struct TWeakObjectPtr<struct UObject> CachedComponent; // Offset: 0x30 | Size: 0x8
};

// Object: ScriptStruct LevelSequence.LevelSequencePlayerSnapshot
// Inherited Bytes: 0x0 | Struct Size: 0xb8
struct FLevelSequencePlayerSnapshot {
	// Fields
	struct FString MasterName; // Offset: 0x0 | Size: 0x10
	struct FQualifiedFrameTime MasterTime; // Offset: 0x10 | Size: 0x10
	struct FQualifiedFrameTime SourceTime; // Offset: 0x20 | Size: 0x10
	struct FString CurrentShotName; // Offset: 0x30 | Size: 0x10
	struct FQualifiedFrameTime CurrentShotLocalTime; // Offset: 0x40 | Size: 0x10
	struct FQualifiedFrameTime CurrentShotSourceTime; // Offset: 0x50 | Size: 0x10
	struct FString SourceTimecode; // Offset: 0x60 | Size: 0x10
	struct TSoftObjectPtr<UCameraComponent> CameraComponent; // Offset: 0x70 | Size: 0x28
	struct FLevelSequenceSnapshotSettings Settings; // Offset: 0x98 | Size: 0xc
	char pad_0xA4[0x4]; // Offset: 0xa4 | Size: 0x4
	struct ULevelSequence* ActiveShot; // Offset: 0xa8 | Size: 0x8
	struct FMovieSceneSequenceID ShotID; // Offset: 0xb0 | Size: 0x4
	char pad_0xB4[0x4]; // Offset: 0xb4 | Size: 0x4
};

// Object: ScriptStruct LevelSequence.LevelSequenceSnapshotSettings
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FLevelSequenceSnapshotSettings {
	// Fields
	char ZeroPadAmount; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	struct FFrameRate FrameRate; // Offset: 0x4 | Size: 0x8
};

