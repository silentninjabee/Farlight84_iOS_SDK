#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class LightPropagationVolumeRuntime.LightPropagationVolumeBlendable
// Inherited Bytes: 0x28 | Struct Size: 0x78
struct ULightPropagationVolumeBlendable : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
	struct FLightPropagationVolumeSettings Settings; // Offset: 0x30 | Size: 0x40
	float BlendWeight; // Offset: 0x70 | Size: 0x4
	char pad_0x74[0x4]; // Offset: 0x74 | Size: 0x4
};

