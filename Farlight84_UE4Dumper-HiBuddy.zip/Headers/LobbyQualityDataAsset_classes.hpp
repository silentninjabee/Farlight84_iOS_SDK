#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass LobbyQualityDataAsset.LobbyQualityDataAsset_C
// Inherited Bytes: 0x38 | Struct Size: 0x88
struct ULobbyQualityDataAsset_C : USolarDataAsset {
	// Fields
	struct TMap<enum class E_Item_Quality, struct FLobbyQualityStructure> QualityConfig; // Offset: 0x38 | Size: 0x50
};

