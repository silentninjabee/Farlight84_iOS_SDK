#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass Lobby.Lobby_C
// Inherited Bytes: 0x250 | Struct Size: 0x258
struct ALobby_C : ALevelScriptActor {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x250 | Size: 0x8

	// Functions

	// Object: Function Lobby.Lobby_C.CloseVictoryUI
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(0) Size(0x0) ]
	void CloseVictoryUI();

	// Object: Function Lobby.Lobby_C.ReceiveBeginPlay
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(0) Size(0x0) ]
	void ReceiveBeginPlay();

	// Object: Function Lobby.Lobby_C.ExecuteUbergraph_Lobby
	// Flags: [Final|UbergraphFunction|HasDefaults]
	// Offset: 0x10213e738
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_Lobby(int32_t EntryPoint);
};

