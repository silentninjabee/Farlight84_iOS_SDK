#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class LocalizeText.LocalizeText
// Inherited Bytes: 0x160 | Struct Size: 0x850
struct ULocalizeText : UTextLayoutWidget {
	// Fields
	bool NotLocalize; // Offset: 0x159 | Size: 0x1
	bool CapitalOnly; // Offset: 0x15a | Size: 0x1
	struct FString LocalizeKey; // Offset: 0x160 | Size: 0x10
	struct FText Text; // Offset: 0x170 | Size: 0x18
	struct FDelegate TextDelegate; // Offset: 0x188 | Size: 0x10
	struct FSlateColor ColorAndOpacity; // Offset: 0x198 | Size: 0x28
	struct FDelegate ColorAndOpacityDelegate; // Offset: 0x1c0 | Size: 0x10
	struct FSlateFontInfo Font; // Offset: 0x1d0 | Size: 0x68
	char pad_0x23A[0x6]; // Offset: 0x23a | Size: 0x6
	struct FSlateBrush StrikeBrush; // Offset: 0x240 | Size: 0xf0
	struct FVector2D ShadowOffset; // Offset: 0x330 | Size: 0x8
	struct FLinearColor ShadowColorAndOpacity; // Offset: 0x338 | Size: 0x10
	struct FDelegate ShadowColorAndOpacityDelegate; // Offset: 0x348 | Size: 0x10
	float MinDesiredWidth; // Offset: 0x358 | Size: 0x4
	bool bWrapWithInvalidationPanel; // Offset: 0x35c | Size: 0x1
	char pad_0x35D[0x3]; // Offset: 0x35d | Size: 0x3
	int32_t LetterSpacing; // Offset: 0x360 | Size: 0x4
	char pad_0x364[0x4]; // Offset: 0x364 | Size: 0x4
	struct ULocalizeTransferAgent* Agent; // Offset: 0x368 | Size: 0x8
	struct FTextBlockStyle WidgetStyle; // Offset: 0x370 | Size: 0x4b0
	bool bSimpleTextMode; // Offset: 0x820 | Size: 0x1
	char pad_0x821[0x27]; // Offset: 0x821 | Size: 0x27
	enum class ETextScaleRule ScaleRule; // Offset: 0x848 | Size: 0x1
	enum class ETextVerticalAlign VerticalAlign; // Offset: 0x849 | Size: 0x1
	char pad_0x84A[0x6]; // Offset: 0x84a | Size: 0x6

	// Functions

	// Object: Function LocalizeText.LocalizeText.SetWrapTextAt
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x103611ab8
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetWrapTextAt(float InWrapTextAt);

	// Object: Function LocalizeText.LocalizeText.SetVerticalAlign
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x103611a18
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetVerticalAlign(enum class ETextVerticalAlign InScaleAlign);

	// Object: Function LocalizeText.LocalizeText.SetText
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x103611858
	// Return & Params: [ Num(1) Size(0x18) ]
	void SetText(struct FText InText);

	// Object: Function LocalizeText.LocalizeText.SetStrikeBrush
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x103611b78
	// Return & Params: [ Num(1) Size(0xf0) ]
	void SetStrikeBrush(struct FSlateBrush InStrikeBrush);

	// Object: Function LocalizeText.LocalizeText.SetShadowOffset
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x103611ec4
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetShadowOffset(struct FVector2D InShadowOffset);

	// Object: Function LocalizeText.LocalizeText.SetShadowColorAndOpacity
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x103611f14
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetShadowColorAndOpacity(struct FLinearColor InShadowColorAndOpacity);

	// Object: Function LocalizeText.LocalizeText.SetScaleRule
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x103611a68
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetScaleRule(enum class ETextScaleRule InScaleRule);

	// Object: Function LocalizeText.LocalizeText.SetOpacity
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x103611f68
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetOpacity(float InOpacity);

	// Object: Function LocalizeText.LocalizeText.SetMinDesiredWidth
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x103611b38
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetMinDesiredWidth(float InMinDesiredWidth);

	// Object: Function LocalizeText.LocalizeText.SetFont
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x103611db4
	// Return & Params: [ Num(1) Size(0x68) ]
	void SetFont(struct FSlateFontInfo InFontInfo);

	// Object: Function LocalizeText.LocalizeText.SetColorAndOpacity
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x103611fa8
	// Return & Params: [ Num(1) Size(0x28) ]
	void SetColorAndOpacity(struct FSlateColor InColorAndOpacity);

	// Object: Function LocalizeText.LocalizeText.SetCapitalOnly
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1036117c4
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetCapitalOnly(bool bCapitalOnly);

	// Object: Function LocalizeText.LocalizeText.SetAutoWrapText
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x103611af8
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetAutoWrapText(bool InAutoTextWrap);

	// Object: Function LocalizeText.LocalizeText.RefreshText
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1036119c0
	// Return & Params: [ Num(0) Size(0x0) ]
	void RefreshText();

	// Object: Function LocalizeText.LocalizeText.Refresh
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1036117b4
	// Return & Params: [ Num(0) Size(0x0) ]
	void Refresh();

	// Object: Function LocalizeText.LocalizeText.GetText
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x103611948
	// Return & Params: [ Num(1) Size(0x18) ]
	struct FText GetText();

	// Object: Function LocalizeText.LocalizeText.GetLocalizeKey
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x103611804
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetLocalizeKey();

	// Object: Function LocalizeText.LocalizeText.GetDynamicOutlineMaterial
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1036119d0
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UMaterialInstanceDynamic* GetDynamicOutlineMaterial();

	// Object: Function LocalizeText.LocalizeText.GetDynamicFontMaterial
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1036119f4
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UMaterialInstanceDynamic* GetDynamicFontMaterial();
};

// Object: Class LocalizeText.LocalizeTransferAgent
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct ULocalizeTransferAgent : UObject {
	// Functions

	// Object: Function LocalizeText.LocalizeTransferAgent.GetLocalizeText
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x103612540
	// Return & Params: [ Num(3) Size(0x30) ]
	struct FString GetLocalizeText(struct FString Language, struct FString Key);
};

