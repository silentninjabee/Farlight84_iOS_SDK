#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class LocationServicesBPLibrary.LocationServices
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct ULocationServices : UBlueprintFunctionLibrary {
	// Functions

	// Object: Function LocationServicesBPLibrary.LocationServices.StopLocationServices
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10375cdb4
	// Return & Params: [ Num(1) Size(0x1) ]
	bool StopLocationServices();

	// Object: Function LocationServicesBPLibrary.LocationServices.StartLocationServices
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10375cdd4
	// Return & Params: [ Num(1) Size(0x1) ]
	bool StartLocationServices();

	// Object: Function LocationServicesBPLibrary.LocationServices.IsLocationAccuracyAvailable
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10375cd14
	// Return & Params: [ Num(2) Size(0x2) ]
	bool IsLocationAccuracyAvailable(enum class ELocationAccuracy Accuracy);

	// Object: Function LocationServicesBPLibrary.LocationServices.InitLocationServices
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10375cdf4
	// Return & Params: [ Num(4) Size(0xd) ]
	bool InitLocationServices(enum class ELocationAccuracy Accuracy, float UpdateFrequency, float MinDistanceFilter);

	// Object: Function LocationServicesBPLibrary.LocationServices.GetLocationServicesImpl
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10375ccf0
	// Return & Params: [ Num(1) Size(0x8) ]
	struct ULocationServicesImpl* GetLocationServicesImpl();

	// Object: Function LocationServicesBPLibrary.LocationServices.GetLastKnownLocation
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10375cd78
	// Return & Params: [ Num(1) Size(0x18) ]
	struct FLocationServicesData GetLastKnownLocation();

	// Object: Function LocationServicesBPLibrary.LocationServices.AreLocationServicesEnabled
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10375cd58
	// Return & Params: [ Num(1) Size(0x1) ]
	bool AreLocationServicesEnabled();
};

// Object: Class LocationServicesBPLibrary.LocationServicesImpl
// Inherited Bytes: 0x28 | Struct Size: 0x38
struct ULocationServicesImpl : UObject {
	// Fields
	struct FMulticastInlineDelegate OnLocationChanged; // Offset: 0x28 | Size: 0x10
};

