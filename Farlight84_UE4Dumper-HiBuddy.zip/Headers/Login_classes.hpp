#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass Login.Login_C
// Inherited Bytes: 0x250 | Struct Size: 0x250
struct ALogin_C : ALevelScriptActor {
	// Functions

	// Object: Function Login.Login_C.ReceiveEndPlay
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10113cfa4
	// Return & Params: [ Num(1) Size(0x1) ]
	void ReceiveEndPlay(enum class EEndPlayReason EndPlayReason);

	// Object: Function Login.Login_C.ReceiveBeginPlay
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10113cfa4
	// Return & Params: [ Num(0) Size(0x0) ]
	void ReceiveBeginPlay();

	// Object: Function Login.Login_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x10213e738
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();
};

