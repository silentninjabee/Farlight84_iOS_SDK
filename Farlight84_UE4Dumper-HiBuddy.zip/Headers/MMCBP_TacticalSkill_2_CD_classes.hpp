#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass MMCBP_TacticalSkill_2_CD.MMCBP_TacticalSkill_2_CD_C
// Inherited Bytes: 0x40 | Struct Size: 0x40
struct UMMCBP_TacticalSkill_2_CD_C : UMMC_GenericCooldown {
};

