#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct MaterialShaderQualitySettings.MaterialQualityOverrides
// Inherited Bytes: 0x0 | Struct Size: 0x9
struct FMaterialQualityOverrides {
	// Fields
	bool bDiscardQualityDuringCook; // Offset: 0x0 | Size: 0x1
	bool bEnableOverride; // Offset: 0x1 | Size: 0x1
	bool bForceFullyRough; // Offset: 0x2 | Size: 0x1
	bool bForceNonMetal; // Offset: 0x3 | Size: 0x1
	bool bForceDisableLMDirectionality; // Offset: 0x4 | Size: 0x1
	bool bForceLQReflections; // Offset: 0x5 | Size: 0x1
	bool bForceDisablePreintegratedGF; // Offset: 0x6 | Size: 0x1
	bool bDisableMaterialNormalCalculation; // Offset: 0x7 | Size: 0x1
	enum class EMobileCSMQuality MobileCSMQuality; // Offset: 0x8 | Size: 0x1
};

