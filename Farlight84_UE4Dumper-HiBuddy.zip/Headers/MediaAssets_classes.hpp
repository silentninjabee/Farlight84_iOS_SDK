#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class MediaAssets.MediaSource
// Inherited Bytes: 0x28 | Struct Size: 0x80
struct UMediaSource : UObject {
	// Fields
	char pad_0x28[0x58]; // Offset: 0x28 | Size: 0x58

	// Functions

	// Object: Function MediaAssets.MediaSource.Validate
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10556dcf4
	// Return & Params: [ Num(1) Size(0x1) ]
	bool Validate();

	// Object: Function MediaAssets.MediaSource.SetMediaOptionString
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10556dab0
	// Return & Params: [ Num(2) Size(0x18) ]
	void SetMediaOptionString(struct FName& Key, struct FString Value);

	// Object: Function MediaAssets.MediaSource.SetMediaOptionInt64
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10556db40
	// Return & Params: [ Num(2) Size(0x10) ]
	void SetMediaOptionInt64(struct FName& Key, int64_t Value);

	// Object: Function MediaAssets.MediaSource.SetMediaOptionFloat
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10556dbd0
	// Return & Params: [ Num(2) Size(0xc) ]
	void SetMediaOptionFloat(struct FName& Key, float Value);

	// Object: Function MediaAssets.MediaSource.SetMediaOptionBool
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10556dc60
	// Return & Params: [ Num(2) Size(0x9) ]
	void SetMediaOptionBool(struct FName& Key, bool Value);

	// Object: Function MediaAssets.MediaSource.GetUrl
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10556dd2c
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetUrl();
};

// Object: Class MediaAssets.BaseMediaSource
// Inherited Bytes: 0x80 | Struct Size: 0x88
struct UBaseMediaSource : UMediaSource {
	// Fields
	struct FName playerName; // Offset: 0x80 | Size: 0x8
};

// Object: Class MediaAssets.FileMediaSource
// Inherited Bytes: 0x88 | Struct Size: 0xb0
struct UFileMediaSource : UBaseMediaSource {
	// Fields
	struct FString FilePath; // Offset: 0x88 | Size: 0x10
	bool PrecacheFile; // Offset: 0x98 | Size: 0x1
	char pad_0x99[0x17]; // Offset: 0x99 | Size: 0x17

	// Functions

	// Object: Function MediaAssets.FileMediaSource.SetFilePath
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105569d40
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetFilePath(struct FString Path);
};

// Object: Class MediaAssets.MediaBlueprintFunctionLibrary
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UMediaBlueprintFunctionLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object: Function MediaAssets.MediaBlueprintFunctionLibrary.EnumerateWebcamCaptureDevices
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10556a088
	// Return & Params: [ Num(2) Size(0x14) ]
	void EnumerateWebcamCaptureDevices(struct TArray<struct FMediaCaptureDevice>& OutDevices, int32_t Filter);

	// Object: Function MediaAssets.MediaBlueprintFunctionLibrary.EnumerateVideoCaptureDevices
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10556a0f4
	// Return & Params: [ Num(2) Size(0x14) ]
	void EnumerateVideoCaptureDevices(struct TArray<struct FMediaCaptureDevice>& OutDevices, int32_t Filter);

	// Object: Function MediaAssets.MediaBlueprintFunctionLibrary.EnumerateAudioCaptureDevices
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10556a160
	// Return & Params: [ Num(2) Size(0x14) ]
	void EnumerateAudioCaptureDevices(struct TArray<struct FMediaCaptureDevice>& OutDevices, int32_t Filter);
};

// Object: Class MediaAssets.MediaComponent
// Inherited Bytes: 0xc0 | Struct Size: 0xd0
struct UMediaComponent : UActorComponent {
	// Fields
	struct UMediaTexture* MediaTexture; // Offset: 0xc0 | Size: 0x8
	struct UMediaPlayer* MediaPlayer; // Offset: 0xc8 | Size: 0x8

	// Functions

	// Object: Function MediaAssets.MediaComponent.GetMediaTexture
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10556a2c8
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UMediaTexture* GetMediaTexture();

	// Object: Function MediaAssets.MediaComponent.GetMediaPlayer
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10556a2e8
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UMediaPlayer* GetMediaPlayer();
};

// Object: Class MediaAssets.MediaPlayer
// Inherited Bytes: 0x28 | Struct Size: 0x138
struct UMediaPlayer : UObject {
	// Fields
	struct FMulticastInlineDelegate OnEndReached; // Offset: 0x28 | Size: 0x10
	struct FMulticastInlineDelegate OnMediaClosed; // Offset: 0x38 | Size: 0x10
	struct FMulticastInlineDelegate OnMediaOpened; // Offset: 0x48 | Size: 0x10
	struct FMulticastInlineDelegate OnMediaOpenFailed; // Offset: 0x58 | Size: 0x10
	struct FMulticastInlineDelegate OnPlaybackResumed; // Offset: 0x68 | Size: 0x10
	struct FMulticastInlineDelegate OnPlaybackSuspended; // Offset: 0x78 | Size: 0x10
	struct FMulticastInlineDelegate OnSeekCompleted; // Offset: 0x88 | Size: 0x10
	struct FMulticastInlineDelegate OnTracksChanged; // Offset: 0x98 | Size: 0x10
	struct FTimespan CacheAhead; // Offset: 0xa8 | Size: 0x8
	struct FTimespan CacheBehind; // Offset: 0xb0 | Size: 0x8
	struct FTimespan CacheBehindGame; // Offset: 0xb8 | Size: 0x8
	bool NativeAudioOut; // Offset: 0xc0 | Size: 0x1
	bool PlayOnOpen; // Offset: 0xc1 | Size: 0x1
	char Shuffle : 1; // Offset: 0xc2 | Size: 0x1
	char Loop : 1; // Offset: 0xc2 | Size: 0x1
	char pad_0xC2_2 : 6; // Offset: 0xc2 | Size: 0x1
	char pad_0xC3[0x5]; // Offset: 0xc3 | Size: 0x5
	struct UMediaPlaylist* Playlist; // Offset: 0xc8 | Size: 0x8
	int32_t PlaylistIndex; // Offset: 0xd0 | Size: 0x4
	char pad_0xD4[0x4]; // Offset: 0xd4 | Size: 0x4
	struct FTimespan TimeDelay; // Offset: 0xd8 | Size: 0x8
	float HorizontalFieldOfView; // Offset: 0xe0 | Size: 0x4
	float VerticalFieldOfView; // Offset: 0xe4 | Size: 0x4
	struct FRotator ViewRotation; // Offset: 0xe8 | Size: 0xc
	char pad_0xF4[0x2c]; // Offset: 0xf4 | Size: 0x2c
	struct FGuid PlayerGuid; // Offset: 0x120 | Size: 0x10
	char pad_0x130[0x8]; // Offset: 0x130 | Size: 0x8

	// Functions

	// Object: Function MediaAssets.MediaPlayer.SupportsSeeking
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10556a408
	// Return & Params: [ Num(1) Size(0x1) ]
	bool SupportsSeeking();

	// Object: Function MediaAssets.MediaPlayer.SupportsScrubbing
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10556a428
	// Return & Params: [ Num(1) Size(0x1) ]
	bool SupportsScrubbing();

	// Object: Function MediaAssets.MediaPlayer.SupportsRate
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10556a448
	// Return & Params: [ Num(3) Size(0x6) ]
	bool SupportsRate(float Rate, bool Unthinned);

	// Object: Function MediaAssets.MediaPlayer.SetViewRotation
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10556a4fc
	// Return & Params: [ Num(3) Size(0xe) ]
	bool SetViewRotation(struct FRotator& Rotation, bool Absolute);

	// Object: Function MediaAssets.MediaPlayer.SetViewField
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10556a598
	// Return & Params: [ Num(4) Size(0xa) ]
	bool SetViewField(float Horizontal, float Vertical, bool Absolute);

	// Object: Function MediaAssets.MediaPlayer.SetVideoTrackFrameRate
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10556a644
	// Return & Params: [ Num(4) Size(0xd) ]
	bool SetVideoTrackFrameRate(int32_t TrackIndex, int32_t FormatIndex, float FrameRate);

	// Object: Function MediaAssets.MediaPlayer.SetTrackFormat
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10556a6f8
	// Return & Params: [ Num(4) Size(0xd) ]
	bool SetTrackFormat(enum class EMediaPlayerTrack TrackType, int32_t TrackIndex, int32_t FormatIndex);

	// Object: Function MediaAssets.MediaPlayer.SetTimeDelay
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x10556a4c0
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetTimeDelay(struct FTimespan TimeDelay);

	// Object: Function MediaAssets.MediaPlayer.SetRate
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10556a800
	// Return & Params: [ Num(2) Size(0x5) ]
	bool SetRate(float Rate);

	// Object: Function MediaAssets.MediaPlayer.SetNativeVolume
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10556a7b8
	// Return & Params: [ Num(2) Size(0x5) ]
	bool SetNativeVolume(float Volume);

	// Object: Function MediaAssets.MediaPlayer.SetMediaOptions
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10556a848
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetMediaOptions(struct UMediaSource* options);

	// Object: Function MediaAssets.MediaPlayer.SetLooping
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10556a880
	// Return & Params: [ Num(2) Size(0x2) ]
	bool SetLooping(bool Looping);

	// Object: Function MediaAssets.MediaPlayer.SetDesiredPlayerName
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10556a8e0
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetDesiredPlayerName(struct FName playerName);

	// Object: Function MediaAssets.MediaPlayer.SetBlockOnTime
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10556a924
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetBlockOnTime(struct FTimespan& Time);

	// Object: Function MediaAssets.MediaPlayer.SelectTrack
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10556a968
	// Return & Params: [ Num(3) Size(0x9) ]
	bool SelectTrack(enum class EMediaPlayerTrack TrackType, int32_t TrackIndex);

	// Object: Function MediaAssets.MediaPlayer.Seek
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10556a9e0
	// Return & Params: [ Num(2) Size(0x9) ]
	bool Seek(struct FTimespan& Time);

	// Object: Function MediaAssets.MediaPlayer.Rewind
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10556aa40
	// Return & Params: [ Num(1) Size(0x1) ]
	bool Rewind();

	// Object: Function MediaAssets.MediaPlayer.Reopen
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10556aa60
	// Return & Params: [ Num(1) Size(0x1) ]
	bool Reopen();

	// Object: Function MediaAssets.MediaPlayer.Previous
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10556aa80
	// Return & Params: [ Num(1) Size(0x1) ]
	bool Previous();

	// Object: Function MediaAssets.MediaPlayer.PlayAndSeek
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10556aaa0
	// Return & Params: [ Num(0) Size(0x0) ]
	void PlayAndSeek();

	// Object: Function MediaAssets.MediaPlayer.Play
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10556aab4
	// Return & Params: [ Num(1) Size(0x1) ]
	bool Play();

	// Object: Function MediaAssets.MediaPlayer.Pause
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10556aad4
	// Return & Params: [ Num(1) Size(0x1) ]
	bool Pause();

	// Object: Function MediaAssets.MediaPlayer.OpenUrl
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10556aaf4
	// Return & Params: [ Num(2) Size(0x11) ]
	bool OpenUrl(struct FString URL);

	// Object: Function MediaAssets.MediaPlayer.OpenSourceWithOptions
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10556acc0
	// Return & Params: [ Num(3) Size(0x39) ]
	bool OpenSourceWithOptions(struct UMediaSource* MediaSource, struct FMediaPlayerOptions& options);

	// Object: Function MediaAssets.MediaPlayer.OpenSourceLatent
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10556ab54
	// Return & Params: [ Num(5) Size(0x59) ]
	void OpenSourceLatent(struct UObject* WorldContextObject, struct FLatentActionInfo LatentInfo, struct UMediaSource* MediaSource, struct FMediaPlayerOptions& options, bool& bSuccess);

	// Object: Function MediaAssets.MediaPlayer.OpenSource
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1026360a8
	// Return & Params: [ Num(2) Size(0x9) ]
	bool OpenSource(struct UMediaSource* MediaSource);

	// Object: Function MediaAssets.MediaPlayer.OpenPlaylistIndex
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10556ad98
	// Return & Params: [ Num(3) Size(0xd) ]
	bool OpenPlaylistIndex(struct UMediaPlaylist* InPlaylist, int32_t Index);

	// Object: Function MediaAssets.MediaPlayer.OpenPlaylist
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10556ae28
	// Return & Params: [ Num(2) Size(0x9) ]
	bool OpenPlaylist(struct UMediaPlaylist* InPlaylist);

	// Object: Function MediaAssets.MediaPlayer.OpenFile
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10556ae74
	// Return & Params: [ Num(2) Size(0x11) ]
	bool OpenFile(struct FString FilePath);

	// Object: Function MediaAssets.MediaPlayer.Next
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10556aed4
	// Return & Params: [ Num(1) Size(0x1) ]
	bool Next();

	// Object: Function MediaAssets.MediaPlayer.IsReady
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10556aef4
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsReady();

	// Object: Function MediaAssets.MediaPlayer.IsPreparing
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10556af34
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsPreparing();

	// Object: Function MediaAssets.MediaPlayer.IsPlaying
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10556af54
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsPlaying();

	// Object: Function MediaAssets.MediaPlayer.IsPaused
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10556af74
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsPaused();

	// Object: Function MediaAssets.MediaPlayer.IsLooping
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10556af94
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsLooping();

	// Object: Function MediaAssets.MediaPlayer.IsConnecting
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10556afb4
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsConnecting();

	// Object: Function MediaAssets.MediaPlayer.IsClosed
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10556af14
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsClosed();

	// Object: Function MediaAssets.MediaPlayer.IsBuffering
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10556afd4
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsBuffering();

	// Object: Function MediaAssets.MediaPlayer.HasError
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10556aff4
	// Return & Params: [ Num(1) Size(0x1) ]
	bool HasError();

	// Object: Function MediaAssets.MediaPlayer.GetViewRotation
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10556b034
	// Return & Params: [ Num(1) Size(0xc) ]
	struct FRotator GetViewRotation();

	// Object: Function MediaAssets.MediaPlayer.GetVideoTrackType
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10556b058
	// Return & Params: [ Num(3) Size(0x18) ]
	struct FString GetVideoTrackType(int32_t TrackIndex, int32_t FormatIndex);

	// Object: Function MediaAssets.MediaPlayer.GetVideoTrackFrameRates
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10556b104
	// Return & Params: [ Num(3) Size(0x18) ]
	struct FFloatRange GetVideoTrackFrameRates(int32_t TrackIndex, int32_t FormatIndex);

	// Object: Function MediaAssets.MediaPlayer.GetVideoTrackFrameRate
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10556b16c
	// Return & Params: [ Num(3) Size(0xc) ]
	float GetVideoTrackFrameRate(int32_t TrackIndex, int32_t FormatIndex);

	// Object: Function MediaAssets.MediaPlayer.GetVideoTrackDimensions
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10556b1d4
	// Return & Params: [ Num(3) Size(0x10) ]
	struct FIntPoint GetVideoTrackDimensions(int32_t TrackIndex, int32_t FormatIndex);

	// Object: Function MediaAssets.MediaPlayer.GetVideoTrackAspectRatio
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10556b23c
	// Return & Params: [ Num(3) Size(0xc) ]
	float GetVideoTrackAspectRatio(int32_t TrackIndex, int32_t FormatIndex);

	// Object: Function MediaAssets.MediaPlayer.GetVerticalFieldOfView
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10556b2a4
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetVerticalFieldOfView();

	// Object: Function MediaAssets.MediaPlayer.GetUrl
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10556b2c4
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetUrl();

	// Object: Function MediaAssets.MediaPlayer.GetTrackLanguage
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10556b330
	// Return & Params: [ Num(3) Size(0x18) ]
	struct FString GetTrackLanguage(enum class EMediaPlayerTrack TrackType, int32_t TrackIndex);

	// Object: Function MediaAssets.MediaPlayer.GetTrackFormat
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10556b3e8
	// Return & Params: [ Num(3) Size(0xc) ]
	int32_t GetTrackFormat(enum class EMediaPlayerTrack TrackType, int32_t TrackIndex);

	// Object: Function MediaAssets.MediaPlayer.GetTrackDisplayName
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10556b460
	// Return & Params: [ Num(3) Size(0x20) ]
	struct FText GetTrackDisplayName(enum class EMediaPlayerTrack TrackType, int32_t TrackIndex);

	// Object: Function MediaAssets.MediaPlayer.GetTimeDelay
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10556b014
	// Return & Params: [ Num(1) Size(0x8) ]
	struct FTimespan GetTimeDelay();

	// Object: Function MediaAssets.MediaPlayer.GetTime
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10556b5a0
	// Return & Params: [ Num(1) Size(0x8) ]
	struct FTimespan GetTime();

	// Object: Function MediaAssets.MediaPlayer.GetSupportedRates
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10556b5c0
	// Return & Params: [ Num(2) Size(0x11) ]
	void GetSupportedRates(struct TArray<struct FFloatRange>& OutRates, bool Unthinned);

	// Object: Function MediaAssets.MediaPlayer.GetSelectedTrack
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10556b668
	// Return & Params: [ Num(2) Size(0x8) ]
	int32_t GetSelectedTrack(enum class EMediaPlayerTrack TrackType);

	// Object: Function MediaAssets.MediaPlayer.GetRate
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10556b6c0
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetRate();

	// Object: Function MediaAssets.MediaPlayer.GetPlaylistIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10556b6e0
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetPlaylistIndex();

	// Object: Function MediaAssets.MediaPlayer.GetPlaylist
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10556b6fc
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UMediaPlaylist* GetPlaylist();

	// Object: Function MediaAssets.MediaPlayer.GetPlayerName
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10556b718
	// Return & Params: [ Num(1) Size(0x8) ]
	struct FName GetPlayerName();

	// Object: Function MediaAssets.MediaPlayer.GetNumTracks
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10556b7b0
	// Return & Params: [ Num(2) Size(0x8) ]
	int32_t GetNumTracks(enum class EMediaPlayerTrack TrackType);

	// Object: Function MediaAssets.MediaPlayer.GetNumTrackFormats
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10556b738
	// Return & Params: [ Num(3) Size(0xc) ]
	int32_t GetNumTrackFormats(enum class EMediaPlayerTrack TrackType, int32_t TrackIndex);

	// Object: Function MediaAssets.MediaPlayer.GetMediaName
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10556b808
	// Return & Params: [ Num(1) Size(0x18) ]
	struct FText GetMediaName();

	// Object: Function MediaAssets.MediaPlayer.GetLastVideoSampleProcessedTime
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10556b560
	// Return & Params: [ Num(1) Size(0x8) ]
	struct FTimespan GetLastVideoSampleProcessedTime();

	// Object: Function MediaAssets.MediaPlayer.GetLastAudioSampleProcessedTime
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10556b580
	// Return & Params: [ Num(1) Size(0x8) ]
	struct FTimespan GetLastAudioSampleProcessedTime();

	// Object: Function MediaAssets.MediaPlayer.GetHorizontalFieldOfView
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10556b8a8
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetHorizontalFieldOfView();

	// Object: Function MediaAssets.MediaPlayer.GetDuration
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10556b8c8
	// Return & Params: [ Num(1) Size(0x8) ]
	struct FTimespan GetDuration();

	// Object: Function MediaAssets.MediaPlayer.GetDesiredPlayerName
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10556b8e8
	// Return & Params: [ Num(1) Size(0x8) ]
	struct FName GetDesiredPlayerName();

	// Object: Function MediaAssets.MediaPlayer.GetAudioTrackType
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10556b908
	// Return & Params: [ Num(3) Size(0x18) ]
	struct FString GetAudioTrackType(int32_t TrackIndex, int32_t FormatIndex);

	// Object: Function MediaAssets.MediaPlayer.GetAudioTrackSampleRate
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10556b9b4
	// Return & Params: [ Num(3) Size(0xc) ]
	int32_t GetAudioTrackSampleRate(int32_t TrackIndex, int32_t FormatIndex);

	// Object: Function MediaAssets.MediaPlayer.GetAudioTrackChannels
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10556ba1c
	// Return & Params: [ Num(3) Size(0xc) ]
	int32_t GetAudioTrackChannels(int32_t TrackIndex, int32_t FormatIndex);

	// Object: Function MediaAssets.MediaPlayer.Close
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10263612c
	// Return & Params: [ Num(0) Size(0x0) ]
	void Close();

	// Object: Function MediaAssets.MediaPlayer.CanPlayUrl
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10556ba84
	// Return & Params: [ Num(2) Size(0x11) ]
	bool CanPlayUrl(struct FString URL);

	// Object: Function MediaAssets.MediaPlayer.CanPlaySource
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10556bae4
	// Return & Params: [ Num(2) Size(0x9) ]
	bool CanPlaySource(struct UMediaSource* MediaSource);

	// Object: Function MediaAssets.MediaPlayer.CanPause
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10556bb2c
	// Return & Params: [ Num(1) Size(0x1) ]
	bool CanPause();
};

// Object: Class MediaAssets.MediaPlaylist
// Inherited Bytes: 0x28 | Struct Size: 0x38
struct UMediaPlaylist : UObject {
	// Fields
	struct TArray<struct UMediaSource*> Items; // Offset: 0x28 | Size: 0x10

	// Functions

	// Object: Function MediaAssets.MediaPlaylist.Replace
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10556cc80
	// Return & Params: [ Num(3) Size(0x11) ]
	bool Replace(int32_t Index, struct UMediaSource* Replacement);

	// Object: Function MediaAssets.MediaPlaylist.RemoveAt
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10556cd14
	// Return & Params: [ Num(2) Size(0x5) ]
	bool RemoveAt(int32_t Index);

	// Object: Function MediaAssets.MediaPlaylist.Remove
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10556cd5c
	// Return & Params: [ Num(2) Size(0x9) ]
	bool Remove(struct UMediaSource* MediaSource);

	// Object: Function MediaAssets.MediaPlaylist.Num
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10556cda4
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t Num();

	// Object: Function MediaAssets.MediaPlaylist.Insert
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10556cdc0
	// Return & Params: [ Num(2) Size(0xc) ]
	void Insert(struct UMediaSource* MediaSource, int32_t Index);

	// Object: Function MediaAssets.MediaPlaylist.GetRandom
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10556ce40
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UMediaSource* GetRandom(int32_t& OutIndex);

	// Object: Function MediaAssets.MediaPlaylist.GetPrevious
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10556ce9c
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UMediaSource* GetPrevious(int32_t& InOutIndex);

	// Object: Function MediaAssets.MediaPlaylist.GetNext
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10556cef8
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UMediaSource* GetNext(int32_t& InOutIndex);

	// Object: Function MediaAssets.MediaPlaylist.Get
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10556cf54
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UMediaSource* Get(int32_t Index);

	// Object: Function MediaAssets.MediaPlaylist.AddUrl
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10556cf9c
	// Return & Params: [ Num(2) Size(0x11) ]
	bool AddUrl(struct FString URL);

	// Object: Function MediaAssets.MediaPlaylist.AddFile
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10556cffc
	// Return & Params: [ Num(2) Size(0x11) ]
	bool AddFile(struct FString FilePath);

	// Object: Function MediaAssets.MediaPlaylist.Add
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10556d05c
	// Return & Params: [ Num(2) Size(0x9) ]
	bool Add(struct UMediaSource* MediaSource);
};

// Object: Class MediaAssets.MediaSoundComponent
// Inherited Bytes: 0x840 | Struct Size: 0xa90
struct UMediaSoundComponent : USynthComponent {
	// Fields
	enum class EMediaSoundChannels Channels; // Offset: 0x840 | Size: 0x4
	bool DynamicRateAdjustment; // Offset: 0x844 | Size: 0x1
	char pad_0x845[0x3]; // Offset: 0x845 | Size: 0x3
	float RateAdjustmentFactor; // Offset: 0x848 | Size: 0x4
	struct FFloatRange RateAdjustmentRange; // Offset: 0x84c | Size: 0x10
	char pad_0x85C[0x4]; // Offset: 0x85c | Size: 0x4
	struct UMediaPlayer* MediaPlayer; // Offset: 0x860 | Size: 0x8
	char pad_0x868[0x228]; // Offset: 0x868 | Size: 0x228

	// Functions

	// Object: Function MediaAssets.MediaSoundComponent.SetSpectralAnalysisSettings
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10556d63c
	// Return & Params: [ Num(2) Size(0x11) ]
	void SetSpectralAnalysisSettings(struct TArray<float> InFrequenciesToAnalyze, enum class EMediaSoundComponentFFTSize InFFTSize);

	// Object: Function MediaAssets.MediaSoundComponent.SetMediaPlayer
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10556d78c
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetMediaPlayer(struct UMediaPlayer* NewMediaPlayer);

	// Object: Function MediaAssets.MediaSoundComponent.SetEnvelopeFollowingsettings
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10556d510
	// Return & Params: [ Num(2) Size(0x8) ]
	void SetEnvelopeFollowingsettings(int32_t AttackTimeMsec, int32_t ReleaseTimeMsec);

	// Object: Function MediaAssets.MediaSoundComponent.SetEnableSpectralAnalysis
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10556d728
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetEnableSpectralAnalysis(bool bInSpectralAnalysisEnabled);

	// Object: Function MediaAssets.MediaSoundComponent.SetEnableEnvelopeFollowing
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10556d588
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetEnableEnvelopeFollowing(bool bInEnvelopeFollowing);

	// Object: Function MediaAssets.MediaSoundComponent.GetSpectralData
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10556d5ec
	// Return & Params: [ Num(1) Size(0x10) ]
	struct TArray<struct FMediaSoundComponentSpectralData> GetSpectralData();

	// Object: Function MediaAssets.MediaSoundComponent.GetMediaPlayer
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10556d7c4
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UMediaPlayer* GetMediaPlayer();

	// Object: Function MediaAssets.MediaSoundComponent.GetEnvelopeValue
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10556d4f0
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetEnvelopeValue();

	// Object: Function MediaAssets.MediaSoundComponent.BP_GetAttenuationSettingsToApply
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10556d7e4
	// Return & Params: [ Num(2) Size(0x3a1) ]
	bool BP_GetAttenuationSettingsToApply(struct FSoundAttenuationSettings& OutAttenuationSettings);
};

// Object: Class MediaAssets.MediaTexture
// Inherited Bytes: 0xb8 | Struct Size: 0x1a0
struct UMediaTexture : UTexture {
	// Fields
	enum class TextureAddress AddressX; // Offset: 0xb8 | Size: 0x1
	enum class TextureAddress AddressY; // Offset: 0xb9 | Size: 0x1
	bool AutoClear; // Offset: 0xba | Size: 0x1
	char pad_0xBB[0x1]; // Offset: 0xbb | Size: 0x1
	struct FLinearColor ClearColor; // Offset: 0xbc | Size: 0x10
	bool EnableGenMips; // Offset: 0xcc | Size: 0x1
	char NumMips; // Offset: 0xcd | Size: 0x1
	char pad_0xCE[0x2]; // Offset: 0xce | Size: 0x2
	struct UMediaPlayer* MediaPlayer; // Offset: 0xd0 | Size: 0x8
	char pad_0xD8[0xc8]; // Offset: 0xd8 | Size: 0xc8

	// Functions

	// Object: Function MediaAssets.MediaTexture.SetMediaPlayer
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10556df0c
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetMediaPlayer(struct UMediaPlayer* NewMediaPlayer);

	// Object: Function MediaAssets.MediaTexture.GetWidth
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10556df44
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetWidth();

	// Object: Function MediaAssets.MediaTexture.GetMediaPlayer
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10556df64
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UMediaPlayer* GetMediaPlayer();

	// Object: Function MediaAssets.MediaTexture.GetHeight
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10556df84
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetHeight();

	// Object: Function MediaAssets.MediaTexture.GetAspectRatio
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10556dfa4
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetAspectRatio();
};

// Object: Class MediaAssets.PlatformMediaSource
// Inherited Bytes: 0x80 | Struct Size: 0x88
struct UPlatformMediaSource : UMediaSource {
	// Fields
	struct UMediaSource* MediaSource; // Offset: 0x80 | Size: 0x8
};

// Object: Class MediaAssets.StreamMediaSource
// Inherited Bytes: 0x88 | Struct Size: 0x98
struct UStreamMediaSource : UBaseMediaSource {
	// Fields
	struct FString StreamUrl; // Offset: 0x88 | Size: 0x10
};

// Object: Class MediaAssets.TimeSynchronizableMediaSource
// Inherited Bytes: 0x88 | Struct Size: 0x98
struct UTimeSynchronizableMediaSource : UBaseMediaSource {
	// Fields
	bool bUseTimeSynchronization; // Offset: 0x88 | Size: 0x1
	char pad_0x89[0x3]; // Offset: 0x89 | Size: 0x3
	int32_t FrameDelay; // Offset: 0x8c | Size: 0x4
	double TimeDelay; // Offset: 0x90 | Size: 0x8
};

