#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass Module_Hall.Module_Hall_C
// Inherited Bytes: 0x250 | Struct Size: 0x260
struct AModule_Hall_C : ALevelScriptActor {
	// Fields
	struct AStaticMeshActor* SM_Module_HeroPick_Farlight_EdGraph_0_RefProperty; // Offset: 0x250 | Size: 0x8
	struct AStaticMeshActor* SM_Module_MC_Mesh_2_EdGraph_1_RefProperty; // Offset: 0x258 | Size: 0x8

	// Functions

	// Object: Function Module_Hall.Module_Hall_C.ReceiveBeginPlay
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10113cfa4
	// Return & Params: [ Num(0) Size(0x0) ]
	void ReceiveBeginPlay();

	// Object: Function Module_Hall.Module_Hall_C.ReceiveEndPlay
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10113cfa4
	// Return & Params: [ Num(1) Size(0x1) ]
	void ReceiveEndPlay(enum class EEndPlayReason EndPlayReason);

	// Object: Function Module_Hall.Module_Hall_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x10213e738
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();

	// Object: Function Module_Hall.Module_Hall_C.ResetMiFixedFOV
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(0) Size(0x0) ]
	void ResetMiFixedFOV();

	// Object: Function Module_Hall.Module_Hall_C.ShowLobbyBackgroundLogo
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(1) Size(0x1) ]
	void ShowLobbyBackgroundLogo(bool bShow);
};

