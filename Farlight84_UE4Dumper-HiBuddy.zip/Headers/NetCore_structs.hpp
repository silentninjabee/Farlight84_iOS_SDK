#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct NetCore.NetAnalyticsDataConfig
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FNetAnalyticsDataConfig {
	// Fields
	struct FName DataName; // Offset: 0x0 | Size: 0x8
	bool bEnabled; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x3]; // Offset: 0x9 | Size: 0x3
};

