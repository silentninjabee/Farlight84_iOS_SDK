#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass Panel_Interact_Progress.Panel_Interact_Progress_C
// Inherited Bytes: 0x5a8 | Struct Size: 0x6bc
struct UPanel_Interact_Progress_C : USolarProgressiveInteractButton {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x5a8 | Size: 0x8
	struct UWidgetAnimation* Enter_Anim; // Offset: 0x5b0 | Size: 0x8
	struct UWidgetAnimation* Select_Anim; // Offset: 0x5b8 | Size: 0x8
	struct USolarButton* Btn_Interact; // Offset: 0x5c0 | Size: 0x8
	struct UWidgetSwitcher* CancelableSwitcher; // Offset: 0x5c8 | Size: 0x8
	struct UHorizontalBox* HorizontalBox_CD_HelpNum; // Offset: 0x5d0 | Size: 0x8
	struct UHorizontalBox* HorizontalBox_HelpNum; // Offset: 0x5d8 | Size: 0x8
	struct UImage* Img_CD_HelpNum; // Offset: 0x5e0 | Size: 0x8
	struct UImage* Img_Disable; // Offset: 0x5e8 | Size: 0x8
	struct UImage* Img_Glow_Guide; // Offset: 0x5f0 | Size: 0x8
	struct UImage* Img_HelpNum; // Offset: 0x5f8 | Size: 0x8
	struct UImage* Img_Icon; // Offset: 0x600 | Size: 0x8
	struct UImage* img_Icon_Light; // Offset: 0x608 | Size: 0x8
	struct UImage* Img_Light; // Offset: 0x610 | Size: 0x8
	struct UImage* Img_Light_2; // Offset: 0x618 | Size: 0x8
	struct UImage* Img_Ring_Guide; // Offset: 0x620 | Size: 0x8
	struct UWidgetSwitcher* InteractableSwitcher; // Offset: 0x628 | Size: 0x8
	struct UCanvasPanel* Panel_CD; // Offset: 0x630 | Size: 0x8
	struct UCanvasPanel* Panel_Guide_VX; // Offset: 0x638 | Size: 0x8
	struct USolarAdapterWidget* Panel_Interact_KeyMapping; // Offset: 0x640 | Size: 0x8
	struct UCanvasPanel* Panel_Progress_CountDown; // Offset: 0x648 | Size: 0x8
	struct UCanvasPanel* Panel_ReduceCD; // Offset: 0x650 | Size: 0x8
	struct UUI_Button_ReduceCD_Clock_C* ReduceCD_Clock; // Offset: 0x658 | Size: 0x8
	struct UUI_Button_ReduceCD_Light_C* ReduceCD_Light; // Offset: 0x660 | Size: 0x8
	struct USolarTextBlock* Txt_Cancel; // Offset: 0x668 | Size: 0x8
	struct USolarTextBlock* Txt_CD_HelpNum; // Offset: 0x670 | Size: 0x8
	struct USolarTextBlock* Txt_Disable; // Offset: 0x678 | Size: 0x8
	struct USolarTextBlock* Txt_HelpNum; // Offset: 0x680 | Size: 0x8
	struct USolarTextBlock* Txt_Interact; // Offset: 0x688 | Size: 0x8
	struct USolarTextBlock* Txt_Interact_Desktop; // Offset: 0x690 | Size: 0x8
	struct UUI_Button_Selected_Anim_C* UI_Button_Selected_Anim; // Offset: 0x698 | Size: 0x8
	struct UUI_KeyPrompt_C* UI_KeyPrompt_Interact_M; // Offset: 0x6a0 | Size: 0x8
	struct UUI_Skill_CDRefresh_Anim_C* UI_Skill_CDRefresh_Anim; // Offset: 0x6a8 | Size: 0x8
	enum class ECountDownState State; // Offset: 0x6b0 | Size: 0x1
	enum class E_Interact_Type InteractType; // Offset: 0x6b1 | Size: 0x1
	bool ShowProgressBarPrevInteract; // Offset: 0x6b2 | Size: 0x1
	bool NonProgressText; // Offset: 0x6b3 | Size: 0x1
	bool HideNonCancellableTips; // Offset: 0x6b4 | Size: 0x1
	bool NeedGuideVX; // Offset: 0x6b5 | Size: 0x1
	char pad_0x6B6[0x2]; // Offset: 0x6b6 | Size: 0x2
	int32_t InteractNum; // Offset: 0x6b8 | Size: 0x4

	// Functions

	// Object: Function Panel_Interact_Progress.Panel_Interact_Progress_C.DoGetTagToInteractType
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(1) Size(0x50) ]
	void DoGetTagToInteractType(struct TMap<struct FGameplayTag, enum class E_Interact_Type>& NewParam);

	// Object: Function Panel_Interact_Progress.Panel_Interact_Progress_C.DoGetInteractType
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(1) Size(0x1) ]
	void DoGetInteractType(enum class E_Interact_Type& NewParam);

	// Object: Function Panel_Interact_Progress.Panel_Interact_Progress_C.Set Help Num Visible
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(0) Size(0x0) ]
	void Set Help Num Visible();

	// Object: Function Panel_Interact_Progress.Panel_Interact_Progress_C.BPGetConfigDataAsset
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(1) Size(0x8) ]
	void BPGetConfigDataAsset(struct UBP_GeneralInteractionListConfig_C*& DataAsset);

	// Object: Function Panel_Interact_Progress.Panel_Interact_Progress_C.UpdateGuideVXVisibility
	// Flags: [Protected|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(1) Size(0x1) ]
	void UpdateGuideVXVisibility(bool CanShow);

	// Object: Function Panel_Interact_Progress.Panel_Interact_Progress_C.ConditionalReplaceInteractType
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(3) Size(0x3) ]
	void ConditionalReplaceInteractType(bool IsBuffed, enum class E_Interact_Type OriginalType, enum class E_Interact_Type& ResultType);

	// Object: Function Panel_Interact_Progress.Panel_Interact_Progress_C.GetInteractConfig
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(2) Size(0x98) ]
	void GetInteractConfig(enum class E_Interact_Type InteractType, struct FBPS_InteractionButtonViewConfig& InteractConfig);

	// Object: Function Panel_Interact_Progress.Panel_Interact_Progress_C.RefreshToNonCancellableInteracting
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(0) Size(0x0) ]
	void RefreshToNonCancellableInteracting();

	// Object: Function Panel_Interact_Progress.Panel_Interact_Progress_C.RefreshToCancellableInteracting
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(0) Size(0x0) ]
	void RefreshToCancellableInteracting();

	// Object: Function Panel_Interact_Progress.Panel_Interact_Progress_C.RefreshToPreInteract
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(0) Size(0x0) ]
	void RefreshToPreInteract();

	// Object: Function Panel_Interact_Progress.Panel_Interact_Progress_C.PlayFadeInAnim
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(0) Size(0x0) ]
	void PlayFadeInAnim();

	// Object: Function Panel_Interact_Progress.Panel_Interact_Progress_C.HidePassiveBuff
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(0) Size(0x0) ]
	void HidePassiveBuff();

	// Object: Function Panel_Interact_Progress.Panel_Interact_Progress_C.ShowPassiveBuff
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(2) Size(0x8) ]
	void ShowPassiveBuff(int32_t CharacterID, int32_t LocalTextId);

	// Object: Function Panel_Interact_Progress.Panel_Interact_Progress_C.EnablePassiveBuffDisplay
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(2) Size(0x8) ]
	void EnablePassiveBuffDisplay(int32_t CharacterID, int32_t LocalTextId);

	// Object: Function Panel_Interact_Progress.Panel_Interact_Progress_C.SetProgressBarVisiblity
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetProgressBarVisiblity(bool bShow);

	// Object: Function Panel_Interact_Progress.Panel_Interact_Progress_C.SetInteractType
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetInteractType(enum class E_Interact_Type InteractType);

	// Object: Function Panel_Interact_Progress.Panel_Interact_Progress_C.UpdateStateView
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(1) Size(0x1) ]
	void UpdateStateView(enum class ECountDownState InState);

	// Object: Function Panel_Interact_Progress.Panel_Interact_Progress_C.OnLoaded_05FF62CE4143ABFEC942C68489E91470
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(1) Size(0x8) ]
	void OnLoaded_05FF62CE4143ABFEC942C68489E91470(struct UObject* Loaded);

	// Object: Function Panel_Interact_Progress.Panel_Interact_Progress_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function Panel_Interact_Progress.Panel_Interact_Progress_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(0) Size(0x0) ]
	void Construct();

	// Object: Function Panel_Interact_Progress.Panel_Interact_Progress_C.BP_UpdateStateView
	// Flags: [Event|Protected|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(1) Size(0x1) ]
	void BP_UpdateStateView(enum class ECountDownState InState);

	// Object: Function Panel_Interact_Progress.Panel_Interact_Progress_C.BndEvt__Btn_Interact_K2Node_ComponentBoundEvent_0_OnButtonPressedEvent__DelegateSignature
	// Flags: [BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(0) Size(0x0) ]
	void BndEvt__Btn_Interact_K2Node_ComponentBoundEvent_0_OnButtonPressedEvent__DelegateSignature();

	// Object: Function Panel_Interact_Progress.Panel_Interact_Progress_C.OnAnimationFinished
	// Flags: [BlueprintCosmetic|Event|Protected|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(1) Size(0x8) ]
	void OnAnimationFinished(struct UWidgetAnimation* Animation);

	// Object: Function Panel_Interact_Progress.Panel_Interact_Progress_C.OnAnimationStarted
	// Flags: [BlueprintCosmetic|Event|Protected|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(1) Size(0x8) ]
	void OnAnimationStarted(struct UWidgetAnimation* Animation);

	// Object: Function Panel_Interact_Progress.Panel_Interact_Progress_C.SetBurshIcon
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(1) Size(0x18) ]
	void SetBurshIcon(struct FSoftObjectPath BrushResoucePath);

	// Object: Function Panel_Interact_Progress.Panel_Interact_Progress_C.DoPlayFadeInAnim
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(0) Size(0x0) ]
	void DoPlayFadeInAnim();

	// Object: Function Panel_Interact_Progress.Panel_Interact_Progress_C.DoSetInteractType
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(1) Size(0x1) ]
	void DoSetInteractType(enum class E_Interact_Type InteractType);

	// Object: Function Panel_Interact_Progress.Panel_Interact_Progress_C.DoEnablePassiveBuffDisplay
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(2) Size(0x8) ]
	void DoEnablePassiveBuffDisplay(int32_t CharacterID, int32_t LocalTextId);

	// Object: Function Panel_Interact_Progress.Panel_Interact_Progress_C.UpdateInteractNum
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(1) Size(0x4) ]
	void UpdateInteractNum(int32_t InNum);

	// Object: Function Panel_Interact_Progress.Panel_Interact_Progress_C.ExecuteUbergraph_Panel_Interact_Progress
	// Flags: [Final|UbergraphFunction|HasDefaults]
	// Offset: 0x10213e738
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_Panel_Interact_Progress(int32_t EntryPoint);
};

