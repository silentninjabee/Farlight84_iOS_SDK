#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct PhysXVehicles.AnimNode_WheelHandler
// Inherited Bytes: 0xc8 | Struct Size: 0xe0
struct FAnimNode_WheelHandler : FAnimNode_SkeletalControlBase {
	// Fields
	char pad_0xC8[0x18]; // Offset: 0xc8 | Size: 0x18
};

// Object: ScriptStruct PhysXVehicles.TireConfigMaterialFriction
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FTireConfigMaterialFriction {
	// Fields
	struct UPhysicalMaterial* PhysicalMaterial; // Offset: 0x0 | Size: 0x8
	float FrictionScale; // Offset: 0x8 | Size: 0x4
	char pad_0xC[0x4]; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct PhysXVehicles.VehicleAnimInstanceProxy
// Inherited Bytes: 0x6f0 | Struct Size: 0x700
struct FVehicleAnimInstanceProxy : FAnimInstanceProxy {
	// Fields
	char pad_0x6F0[0x10]; // Offset: 0x6f0 | Size: 0x10
};

// Object: ScriptStruct PhysXVehicles.VehicleInputRate
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FVehicleInputRate {
	// Fields
	float RiseRate; // Offset: 0x0 | Size: 0x4
	float FallRate; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct PhysXVehicles.ReplicatedVehicleState
// Inherited Bytes: 0x0 | Struct Size: 0x14
struct FReplicatedVehicleState {
	// Fields
	float SteeringInput; // Offset: 0x0 | Size: 0x4
	float ThrottleInput; // Offset: 0x4 | Size: 0x4
	float BrakeInput; // Offset: 0x8 | Size: 0x4
	float HandbrakeInput; // Offset: 0xc | Size: 0x4
	int32_t CurrentGear; // Offset: 0x10 | Size: 0x4
};

// Object: ScriptStruct PhysXVehicles.WheelSetup
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FWheelSetup {
	// Fields
	struct UVehicleWheel* WheelClass; // Offset: 0x0 | Size: 0x8
	struct FName BoneName; // Offset: 0x8 | Size: 0x8
	struct FVector AdditionalOffset; // Offset: 0x10 | Size: 0xc
	bool bDisableSteering; // Offset: 0x1c | Size: 0x1
	char pad_0x1D[0x3]; // Offset: 0x1d | Size: 0x3
};

// Object: ScriptStruct PhysXVehicles.VehicleTransmissionData
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FVehicleTransmissionData {
	// Fields
	bool bUseGearAutoBox; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	float GearSwitchTime; // Offset: 0x4 | Size: 0x4
	float GearAutoBoxLatency; // Offset: 0x8 | Size: 0x4
	float FinalRatio; // Offset: 0xc | Size: 0x4
	struct TArray<struct FVehicleGearData> ForwardGears; // Offset: 0x10 | Size: 0x10
	float ReverseGearRatio; // Offset: 0x20 | Size: 0x4
	float NeutralGearUpRatio; // Offset: 0x24 | Size: 0x4
	float ClutchStrength; // Offset: 0x28 | Size: 0x4
	char pad_0x2C[0x4]; // Offset: 0x2c | Size: 0x4
};

// Object: ScriptStruct PhysXVehicles.VehicleGearData
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FVehicleGearData {
	// Fields
	float Ratio; // Offset: 0x0 | Size: 0x4
	float DownRatio; // Offset: 0x4 | Size: 0x4
	float UpRatio; // Offset: 0x8 | Size: 0x4
};

// Object: ScriptStruct PhysXVehicles.VehicleEngineData
// Inherited Bytes: 0x0 | Struct Size: 0xa0
struct FVehicleEngineData {
	// Fields
	struct FRuntimeFloatCurve TorqueCurve; // Offset: 0x0 | Size: 0x88
	float MaxRpm; // Offset: 0x88 | Size: 0x4
	float MOI; // Offset: 0x8c | Size: 0x4
	float DampingRateFullThrottle; // Offset: 0x90 | Size: 0x4
	float DampingRateZeroThrottleClutchEngaged; // Offset: 0x94 | Size: 0x4
	float DampingRateZeroThrottleClutchDisengaged; // Offset: 0x98 | Size: 0x4
	char pad_0x9C[0x4]; // Offset: 0x9c | Size: 0x4
};

// Object: ScriptStruct PhysXVehicles.VehicleDifferential4WData
// Inherited Bytes: 0x0 | Struct Size: 0x1c
struct FVehicleDifferential4WData {
	// Fields
	enum class EVehicleDifferential4W DifferentialType; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	float FrontRearSplit; // Offset: 0x4 | Size: 0x4
	float FrontLeftRightSplit; // Offset: 0x8 | Size: 0x4
	float RearLeftRightSplit; // Offset: 0xc | Size: 0x4
	float CentreBias; // Offset: 0x10 | Size: 0x4
	float FrontBias; // Offset: 0x14 | Size: 0x4
	float RearBias; // Offset: 0x18 | Size: 0x4
};

