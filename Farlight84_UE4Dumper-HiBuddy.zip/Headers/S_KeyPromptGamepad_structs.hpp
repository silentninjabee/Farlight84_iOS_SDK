#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: UserDefinedStruct S_KeyPromptGamepad.S_KeyPromptGamepad
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FS_KeyPromptGamepad {
	// Fields
	bool MemberVar_0_B90AE02F4CB9AD0D665AA28F9A2AC172; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	struct FVector2D Size_3_DB44F26A40DCD93A905A84B36D62DD91; // Offset: 0x4 | Size: 0x8
};

