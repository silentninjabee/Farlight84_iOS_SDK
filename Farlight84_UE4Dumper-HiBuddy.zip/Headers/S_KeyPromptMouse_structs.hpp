#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: UserDefinedStruct S_KeyPromptMouse.S_KeyPromptMouse
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FS_KeyPromptMouse {
	// Fields
	bool MemberVar_0_B90AE02F4CB9AD0D665AA28F9A2AC172; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	struct FVector2D Size_3_0432FC0844D2F92AEFC5CC80AB39D9CF; // Offset: 0x4 | Size: 0x8
};

