#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct Serialization.StructSerializerTestStruct
// Inherited Bytes: 0x0 | Struct Size: 0x450
struct FStructSerializerTestStruct {
	// Fields
	struct FStructSerializerNumericTestStruct Numerics; // Offset: 0x0 | Size: 0x30
	struct FStructSerializerBooleanTestStruct Booleans; // Offset: 0x30 | Size: 0x3
	char pad_0x33[0x5]; // Offset: 0x33 | Size: 0x5
	struct FStructSerializerObjectTestStruct Objects; // Offset: 0x38 | Size: 0xa0
	char pad_0xD8[0x8]; // Offset: 0xd8 | Size: 0x8
	struct FStructSerializerBuiltinTestStruct Builtins; // Offset: 0xe0 | Size: 0x90
	struct FStructSerializerArrayTestStruct Arrays; // Offset: 0x170 | Size: 0x60
	struct FStructSerializerMapTestStruct Maps; // Offset: 0x1d0 | Size: 0x140
	struct FStructSerializerSetTestStruct Sets; // Offset: 0x310 | Size: 0x140
};

// Object: ScriptStruct Serialization.StructSerializerSetTestStruct
// Inherited Bytes: 0x0 | Struct Size: 0x140
struct FStructSerializerSetTestStruct {
	// Fields
	struct TSet<struct FString> StrSet; // Offset: 0x0 | Size: 0x50
	struct TSet<int32_t> IntSet; // Offset: 0x50 | Size: 0x50
	struct TSet<struct FName> NameSet; // Offset: 0xa0 | Size: 0x50
	struct TSet<struct FStructSerializerBuiltinTestStruct> StructSet; // Offset: 0xf0 | Size: 0x50
};

// Object: ScriptStruct Serialization.StructSerializerBuiltinTestStruct
// Inherited Bytes: 0x0 | Struct Size: 0x90
struct FStructSerializerBuiltinTestStruct {
	// Fields
	struct FGuid Guid; // Offset: 0x0 | Size: 0x10
	struct FName Name; // Offset: 0x10 | Size: 0x8
	struct FString String; // Offset: 0x18 | Size: 0x10
	struct FText Text; // Offset: 0x28 | Size: 0x18
	struct FVector Vector; // Offset: 0x40 | Size: 0xc
	char pad_0x4C[0x4]; // Offset: 0x4c | Size: 0x4
	struct FVector4 Vector4; // Offset: 0x50 | Size: 0x10
	struct FRotator Rotator; // Offset: 0x60 | Size: 0xc
	char pad_0x6C[0x4]; // Offset: 0x6c | Size: 0x4
	struct FQuat Quat; // Offset: 0x70 | Size: 0x10
	struct FColor Color; // Offset: 0x80 | Size: 0x4
	char pad_0x84[0xc]; // Offset: 0x84 | Size: 0xc
};

// Object: ScriptStruct Serialization.StructSerializerMapTestStruct
// Inherited Bytes: 0x0 | Struct Size: 0x140
struct FStructSerializerMapTestStruct {
	// Fields
	struct TMap<int32_t, struct FString> IntToStr; // Offset: 0x0 | Size: 0x50
	struct TMap<struct FString, struct FString> StrToStr; // Offset: 0x50 | Size: 0x50
	struct TMap<struct FString, struct FVector> StrToVec; // Offset: 0xa0 | Size: 0x50
	struct TMap<struct FString, struct FStructSerializerBuiltinTestStruct> StrToStruct; // Offset: 0xf0 | Size: 0x50
};

// Object: ScriptStruct Serialization.StructSerializerArrayTestStruct
// Inherited Bytes: 0x0 | Struct Size: 0x60
struct FStructSerializerArrayTestStruct {
	// Fields
	struct TArray<int32_t> Int32Array; // Offset: 0x0 | Size: 0x10
	struct TArray<char> ByteArray; // Offset: 0x10 | Size: 0x10
	int32_t StaticSingleElement; // Offset: 0x20 | Size: 0x4
	int32_t StaticInt32Array[0x3]; // Offset: 0x24 | Size: 0xc
	float StaticFloatArray[0x3]; // Offset: 0x30 | Size: 0xc
	char pad_0x3C[0x4]; // Offset: 0x3c | Size: 0x4
	struct TArray<struct FVector> VectorArray; // Offset: 0x40 | Size: 0x10
	struct TArray<struct FStructSerializerBuiltinTestStruct> StructArray; // Offset: 0x50 | Size: 0x10
};

// Object: ScriptStruct Serialization.StructSerializerObjectTestStruct
// Inherited Bytes: 0x0 | Struct Size: 0xa0
struct FStructSerializerObjectTestStruct {
	// Fields
	struct UObject* Class; // Offset: 0x0 | Size: 0x8
	struct UMetaData* SubClass; // Offset: 0x8 | Size: 0x8
	struct TSoftClassPtr<UObject> SoftClass; // Offset: 0x10 | Size: 0x28
	struct UObject* Object; // Offset: 0x38 | Size: 0x8
	struct TWeakObjectPtr<struct UMetaData> WeakObject; // Offset: 0x40 | Size: 0x8
	struct TSoftObjectPtr<UMetaData> SoftObject; // Offset: 0x48 | Size: 0x28
	struct FSoftClassPath ClassPath; // Offset: 0x70 | Size: 0x18
	struct FSoftObjectPath ObjectPath; // Offset: 0x88 | Size: 0x18
};

// Object: ScriptStruct Serialization.StructSerializerBooleanTestStruct
// Inherited Bytes: 0x0 | Struct Size: 0x3
struct FStructSerializerBooleanTestStruct {
	// Fields
	bool BoolFalse; // Offset: 0x0 | Size: 0x1
	bool BoolTrue; // Offset: 0x1 | Size: 0x1
	char Bitfield0 : 1; // Offset: 0x2 | Size: 0x1
	char Bitfield1 : 1; // Offset: 0x2 | Size: 0x1
	char Bitfield2Set : 1; // Offset: 0x2 | Size: 0x1
	char Bitfield3 : 1; // Offset: 0x2 | Size: 0x1
	char Bitfield4Set : 1; // Offset: 0x2 | Size: 0x1
	char Bitfield5Set : 1; // Offset: 0x2 | Size: 0x1
	char Bitfield6 : 1; // Offset: 0x2 | Size: 0x1
	char Bitfield7Set : 1; // Offset: 0x2 | Size: 0x1
};

// Object: ScriptStruct Serialization.StructSerializerNumericTestStruct
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FStructSerializerNumericTestStruct {
	// Fields
	int8_t int8; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x1]; // Offset: 0x1 | Size: 0x1
	int16_t int16; // Offset: 0x2 | Size: 0x2
	int32_t int32; // Offset: 0x4 | Size: 0x4
	int64_t int64; // Offset: 0x8 | Size: 0x8
	char uint8; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x1]; // Offset: 0x11 | Size: 0x1
	uint16_t uint16; // Offset: 0x12 | Size: 0x2
	uint32_t uint32; // Offset: 0x14 | Size: 0x4
	uint64_t uint64; // Offset: 0x18 | Size: 0x8
	float float; // Offset: 0x20 | Size: 0x4
	char pad_0x24[0x4]; // Offset: 0x24 | Size: 0x4
	double Double; // Offset: 0x28 | Size: 0x8
};

// Object: ScriptStruct Serialization.StructSerializerByteArray
// Inherited Bytes: 0x0 | Struct Size: 0x38
struct FStructSerializerByteArray {
	// Fields
	int32_t Dummy1; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct TArray<char> ByteArray; // Offset: 0x8 | Size: 0x10
	int32_t Dummy2; // Offset: 0x18 | Size: 0x4
	char pad_0x1C[0x4]; // Offset: 0x1c | Size: 0x4
	struct TArray<int8_t> Int8Array; // Offset: 0x20 | Size: 0x10
	int32_t Dummy3; // Offset: 0x30 | Size: 0x4
	char pad_0x34[0x4]; // Offset: 0x34 | Size: 0x4
};

