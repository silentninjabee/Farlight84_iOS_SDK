#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass SolarGameInstance.SolarGameInstance_C
// Inherited Bytes: 0xad0 | Struct Size: 0xae8
struct USolarGameInstance_C : USolarGameInstanceBase {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0xad0 | Size: 0x8
	struct FMulticastInlineDelegate OnBroadcastModeChanged; // Offset: 0xad8 | Size: 0x10

	// Functions

	// Object: DelegateFunction SolarGameInstance.SolarGameInstance_C.OnIOSLLHPayFinished_49A33A5D7F4EF243E83A8996C6E3C8E9
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10112c8d8
	// Return & Params: [ Num(6) Size(0x31) ]
	void OnIOSLLHPayFinished_49A33A5D7F4EF243E83A8996C6E3C8E9(bool bSuccess, int32_t ErrorCode, struct FString ErrorMsg, int32_t PayValue, struct FString ProductID, enum class ELLHSDKPayType PayType);

	// Object: DelegateFunction SolarGameInstance.SolarGameInstance_C.OnIOSQuerySkus_375EDFCB214FC7C7DD3543AB1191615E
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x10112c8d8
	// Return & Params: [ Num(2) Size(0x20) ]
	void OnIOSQuerySkus_375EDFCB214FC7C7DD3543AB1191615E(struct FLLHSDKGenericSkuItemsDetailList ItemsDetailList, struct TArray<struct FString>& InvalidProductIDs);

	// Object: DelegateFunction SolarGameInstance.SolarGameInstance_C.OnInternalBrowserOpen_24C873FD10412E8AE1BFC8A47F4CE3EC
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10112c8d8
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnInternalBrowserOpen_24C873FD10412E8AE1BFC8A47F4CE3EC();

	// Object: DelegateFunction SolarGameInstance.SolarGameInstance_C.OnBrowserClosed_D56A549A6848F284A3AEEF9485AABB46
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10112c8d8
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnBrowserClosed_D56A549A6848F284A3AEEF9485AABB46();

	// Object: DelegateFunction SolarGameInstance.SolarGameInstance_C.OnReceiveNotification_21719CB5C944E6808C1437929198A4E3
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10112c8d8
	// Return & Params: [ Num(1) Size(0x4) ]
	void OnReceiveNotification_21719CB5C944E6808C1437929198A4E3(int32_t NotificationType);

	// Object: DelegateFunction SolarGameInstance.SolarGameInstance_C.OnWifiStateChanged_269DC381A14DCE77E4F32A9DA1079CB0
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10112c8d8
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnWifiStateChanged_269DC381A14DCE77E4F32A9DA1079CB0(bool bEnabled);

	// Object: DelegateFunction SolarGameInstance.SolarGameInstance_C.OnLIMPCAlilogAdd_6A1DE4675F4987A83E8796A879A22317
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10112c8d8
	// Return & Params: [ Num(1) Size(0x10) ]
	void OnLIMPCAlilogAdd_6A1DE4675F4987A83E8796A879A22317(struct FString Datas);

	// Object: DelegateFunction SolarGameInstance.SolarGameInstance_C.OnLSLSLogAdd_6F46B918994874E6A8AAA4BD2FD23B29
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10112c8d8
	// Return & Params: [ Num(1) Size(0x10) ]
	void OnLSLSLogAdd_6F46B918994874E6A8AAA4BD2FD23B29(struct FString Datas);

	// Object: DelegateFunction SolarGameInstance.SolarGameInstance_C.OnLimPCSDKCommonReportPoint_0C5183D51A41FDCE1DE2A8815879DA74
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10112c8d8
	// Return & Params: [ Num(1) Size(0x10) ]
	void OnLimPCSDKCommonReportPoint_0C5183D51A41FDCE1DE2A8815879DA74(struct FString Datas);

	// Object: DelegateFunction SolarGameInstance.SolarGameInstance_C.OnDAPLogAdd_54954B8A2243BB7C91D35EA03955EC80
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10112c8d8
	// Return & Params: [ Num(1) Size(0x10) ]
	void OnDAPLogAdd_54954B8A2243BB7C91D35EA03955EC80(struct FString Datas);

	// Object: Function SolarGameInstance.SolarGameInstance_C.SolarGM_TestCrashWithLua
	// Flags: [Exec|Event|Public|BlueprintEvent]
	// Offset: 0x10113cfa4
	// Return & Params: [ Num(0) Size(0x0) ]
	void SolarGM_TestCrashWithLua();

	// Object: Function SolarGameInstance.SolarGameInstance_C.LuaGetBroadcastHeroNameCopy
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(2) Size(0x20) ]
	void LuaGetBroadcastHeroNameCopy(struct FString SolarPlayerId, struct FString& BroadcastPlayerName);

	// Object: Function SolarGameInstance.SolarGameInstance_C.SelectHeroAndSkinForPSOGathring
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10113cfa4
	// Return & Params: [ Num(2) Size(0x8) ]
	void SelectHeroAndSkinForPSOGathring(int32_t CharacterID, int32_t SkinID);

	// Object: Function SolarGameInstance.SolarGameInstance_C.SolarGM_TransmitGMLua
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x10113cfa4
	// Return & Params: [ Num(2) Size(0x20) ]
	void SolarGM_TransmitGMLua(struct FString playerName, struct TArray<struct FString>& GmArray);

	// Object: Function SolarGameInstance.SolarGameInstance_C.SolarGM_LobbyLua
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x10113cfa4
	// Return & Params: [ Num(2) Size(0x20) ]
	void SolarGM_LobbyLua(struct FString CmdName, struct TArray<struct FString>& Params);

	// Object: Function SolarGameInstance.SolarGameInstance_C.SolarGM_TestEnsureMsgWithLua
	// Flags: [Exec|Event|Public|BlueprintEvent]
	// Offset: 0x10113cfa4
	// Return & Params: [ Num(0) Size(0x0) ]
	void SolarGM_TestEnsureMsgWithLua();

	// Object: Function SolarGameInstance.SolarGameInstance_C.HandleNetworkError
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10113cfa4
	// Return & Params: [ Num(2) Size(0x2) ]
	void HandleNetworkError(enum class ENetworkFailure FailureType, bool bIsServer);

	// Object: Function SolarGameInstance.SolarGameInstance_C.ExecuteChangeAudioModeLuaCall
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10113cfa4
	// Return & Params: [ Num(1) Size(0x1) ]
	void ExecuteChangeAudioModeLuaCall(bool bTurnOn);

	// Object: Function SolarGameInstance.SolarGameInstance_C.LuaStartGameFrameWork
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10113cfa4
	// Return & Params: [ Num(0) Size(0x0) ]
	void LuaStartGameFrameWork();

	// Object: Function SolarGameInstance.SolarGameInstance_C.RegisterNetworkManager
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10113cfa4
	// Return & Params: [ Num(0) Size(0x0) ]
	void RegisterNetworkManager();

	// Object: Function SolarGameInstance.SolarGameInstance_C.OnScopeChanged
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10113cfa4
	// Return & Params: [ Num(2) Size(0x2) ]
	void OnScopeChanged(enum class EScope InLastScope, enum class EScope InCurScope);

	// Object: Function SolarGameInstance.SolarGameInstance_C.LuaInitGameFrameWork
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10113cfa4
	// Return & Params: [ Num(0) Size(0x0) ]
	void LuaInitGameFrameWork();

	// Object: Function SolarGameInstance.SolarGameInstance_C.OnStageFlagChanged
	// Flags: [Event|Public|BlueprintEvent|Const]
	// Offset: 0x10113cfa4
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnStageFlagChanged(enum class ESolarStageFlags InCurStageFlag);

	// Object: Function SolarGameInstance.SolarGameInstance_C.ShutDownPCSDK
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10113cfa4
	// Return & Params: [ Num(0) Size(0x0) ]
	void ShutDownPCSDK();

	// Object: Function SolarGameInstance.SolarGameInstance_C.CheckSavedDirFiles
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x10113cfa4
	// Return & Params: [ Num(1) Size(0x10) ]
	void CheckSavedDirFiles(struct TArray<struct FString>& Files);

	// Object: Function SolarGameInstance.SolarGameInstance_C.OnDisconnect
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10113cfa4
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnDisconnect();

	// Object: Function SolarGameInstance.SolarGameInstance_C.ReceiveClientWasKicked
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10113cfa4
	// Return & Params: [ Num(1) Size(0x10) ]
	void ReceiveClientWasKicked(struct FString KickReason);

	// Object: Function SolarGameInstance.SolarGameInstance_C.InitLuaClasses
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10113cfa4
	// Return & Params: [ Num(0) Size(0x0) ]
	void InitLuaClasses();

	// Object: Function SolarGameInstance.SolarGameInstance_C.ReportLoadingInfoToBI
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x10113cfa4
	// Return & Params: [ Num(3) Size(0x15) ]
	void ReportLoadingInfoToBI(struct TArray<struct FString>& LoadingInfo, float LoadingTime, bool bIsFinished);

	// Object: Function SolarGameInstance.SolarGameInstance_C.SolarGM_QuickMatchLua
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10113cfa4
	// Return & Params: [ Num(2) Size(0x8) ]
	void SolarGM_QuickMatchLua(int32_t mapID, int32_t ruleID);

	// Object: Function SolarGameInstance.SolarGameInstance_C.ExecuteBackKeyLuaCall
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10113cfa4
	// Return & Params: [ Num(0) Size(0x0) ]
	void ExecuteBackKeyLuaCall();

	// Object: Function SolarGameInstance.SolarGameInstance_C.OnOtherNetworkFailureDisconnect
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10113cfa4
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnOtherNetworkFailureDisconnect();

	// Object: Function SolarGameInstance.SolarGameInstance_C.ShutDownLimSdk
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10113cfa4
	// Return & Params: [ Num(0) Size(0x0) ]
	void ShutDownLimSdk();

	// Object: Function SolarGameInstance.SolarGameInstance_C.SolarGM_AddItemLua
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10113cfa4
	// Return & Params: [ Num(2) Size(0x8) ]
	void SolarGM_AddItemLua(int32_t ItemID, int32_t count);

	// Object: Function SolarGameInstance.SolarGameInstance_C.SolarGM_AddWeaponExpLua
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10113cfa4
	// Return & Params: [ Num(2) Size(0x8) ]
	void SolarGM_AddWeaponExpLua(int32_t weaponid, int32_t count);

	// Object: Function SolarGameInstance.SolarGameInstance_C.ReceiveShutdown
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10113cfa4
	// Return & Params: [ Num(0) Size(0x0) ]
	void ReceiveShutdown();

	// Object: Function SolarGameInstance.SolarGameInstance_C.ShutDownRTCSdk
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10113cfa4
	// Return & Params: [ Num(0) Size(0x0) ]
	void ShutDownRTCSdk();

	// Object: Function SolarGameInstance.SolarGameInstance_C.AsyncDownLoadConfigFile
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10113cfa4
	// Return & Params: [ Num(2) Size(0x18) ]
	void AsyncDownLoadConfigFile(int64_t TaskID, struct FString URL);

	// Object: Function SolarGameInstance.SolarGameInstance_C.LuaGetBroadcastPlayerNameCopy
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(2) Size(0x20) ]
	void LuaGetBroadcastPlayerNameCopy(struct FString SolarPlayerId, struct FString& BroadcastPlayerName);

	// Object: Function SolarGameInstance.SolarGameInstance_C.LuaOnBroadcastModeChanged
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(0) Size(0x0) ]
	void LuaOnBroadcastModeChanged();

	// Object: Function SolarGameInstance.SolarGameInstance_C.LuaGetBroadcastPlayerName
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10113cfa4
	// Return & Params: [ Num(2) Size(0x20) ]
	void LuaGetBroadcastPlayerName(struct FString SolarPlayerId, struct FString& BroadcastPlayerName);

	// Object: Function SolarGameInstance.SolarGameInstance_C.LuaGetBroadcastHeroName
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10113cfa4
	// Return & Params: [ Num(2) Size(0x20) ]
	void LuaGetBroadcastHeroName(struct FString SolarPlayerId, struct FString& BroadcastPlayerName);

	// Object: Function SolarGameInstance.SolarGameInstance_C.SolarGM_TestCrashWithBP
	// Flags: [Exec|Event|Public|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(0) Size(0x0) ]
	void SolarGM_TestCrashWithBP();

	// Object: Function SolarGameInstance.SolarGameInstance_C.SolarGM_TestEnsureMsgWithBP
	// Flags: [Exec|Event|Public|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(0) Size(0x0) ]
	void SolarGM_TestEnsureMsgWithBP();

	// Object: Function SolarGameInstance.SolarGameInstance_C.ExecuteUbergraph_SolarGameInstance
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x10213e738
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_SolarGameInstance(int32_t EntryPoint);

	// Object: Function SolarGameInstance.SolarGameInstance_C.OnBroadcastModeChanged__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnBroadcastModeChanged__DelegateSignature();
};

