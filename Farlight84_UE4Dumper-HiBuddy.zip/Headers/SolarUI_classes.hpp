#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class SolarUI.SolarNavigationBase
// Inherited Bytes: 0x260 | Struct Size: 0x300
struct USolarNavigationBase : UUserWidget {
	// Fields
	struct TMap<struct FName, struct FSolarWidgetNavigationData> VisualNavigationData; // Offset: 0x260 | Size: 0x50
	struct TMap<struct FName, uint16_t> WidgetHashTable; // Offset: 0x2b0 | Size: 0x50
};

// Object: Class SolarUI.SolarUserWidgetBase
// Inherited Bytes: 0x300 | Struct Size: 0x338
struct USolarUserWidgetBase : USolarNavigationBase {
	// Fields
	bool bPreviewUseWidget; // Offset: 0x300 | Size: 0x1
	char pad_0x301[0x3]; // Offset: 0x301 | Size: 0x3
	struct TWeakObjectPtr<struct UWidgetAnimation> PlayingAnimation; // Offset: 0x304 | Size: 0x8
	char pad_0x30C[0x14]; // Offset: 0x30c | Size: 0x14
	struct TArray<struct FPlayAnimationParams> PendingPlayAnimations; // Offset: 0x320 | Size: 0x10
	char pad_0x330[0x8]; // Offset: 0x330 | Size: 0x8

	// Functions

	// Object: Function SolarUI.SolarUserWidgetBase.SetBlockInputForOneTick
	// Flags: [Final|Native|Public]
	// Offset: 0x10120e8d4
	// Return & Params: [ Num(0) Size(0x0) ]
	void SetBlockInputForOneTick();

	// Object: Function SolarUI.SolarUserWidgetBase.ReceivePlatformLayout
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(1) Size(0x1) ]
	void ReceivePlatformLayout(enum class USolarWidgetLayoutType InLayoutType);

	// Object: Function SolarUI.SolarUserWidgetBase.PlayAnimationByName
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x10120ea68
	// Return & Params: [ Num(6) Size(0x19) ]
	bool PlayAnimationByName(struct FName& AnimationName, float StartAtTime, int32_t NumLoopsToPlay, enum class EUMGSequencePlayMode PlayMode, float PlaybackSpeed);

	// Object: Function SolarUI.SolarUserWidgetBase.PlayAnimationByExclusively
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x10120e8e8
	// Return & Params: [ Num(6) Size(0x19) ]
	void PlayAnimationByExclusively(struct UWidgetAnimation* InAnimation, float StartAtTime, int32_t NumLoopsToPlay, enum class EUMGSequencePlayMode PlayMode, float PlaybackSpeed, bool bRestoreState);

	// Object: Function SolarUI.SolarUserWidgetBase.OnSynchronizeProperties
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnSynchronizeProperties();

	// Object: Function SolarUI.SolarUserWidgetBase.OnExclusivelyAnimationFinished
	// Flags: [Final|Native|Protected]
	// Offset: 0x10120e884
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnExclusivelyAnimationFinished();

	// Object: Function SolarUI.SolarUserWidgetBase.IsPlatformDesktop
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10120e898
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsPlatformDesktop();

	// Object: Function SolarUI.SolarUserWidgetBase.GetAnimationByName
	// Flags: [Final|Native|Public|HasOutParms|Const]
	// Offset: 0x10120ec04
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UWidgetAnimation* GetAnimationByName(struct FName& AnimationName);
};

// Object: Class SolarUI.SolarAdapterSlotInterface
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct USolarAdapterSlotInterface : UInterface {
	// Functions

	// Object: Function SolarUI.SolarAdapterSlotInterface.OnLoadAdapterSlotWidgetFinished
	// Flags: [Native|Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x102f7b600
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnLoadAdapterSlotWidgetFinished();

	// Object: Function SolarUI.SolarAdapterSlotInterface.OnChangeAdapterSlotWidgetParameters
	// Flags: [Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10120dbec
	// Return & Params: [ Num(1) Size(0x10) ]
	void OnChangeAdapterSlotWidgetParameters(struct TArray<struct FWidgetOverrideParam>& Params);

	// Object: Function SolarUI.SolarAdapterSlotInterface.OnChangeAdapterSlotWidgetGameplayTag
	// Flags: [Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x102f7b53c
	// Return & Params: [ Num(2) Size(0x18) ]
	void OnChangeAdapterSlotWidgetGameplayTag(struct FGameplayTag& InGameplayTag, struct TArray<struct FString>& MetaData);
};

// Object: Class SolarUI.SolarAdapterWidgetBase
// Inherited Bytes: 0x150 | Struct Size: 0x218
struct USolarAdapterWidgetBase : UContentWidget {
	// Fields
	enum class EWidgetLoadType WidgetLoadType; // Offset: 0x149 | Size: 0x1
	struct FSoftClassPath MobileWidgetPath; // Offset: 0x150 | Size: 0x18
	struct FSoftClassPath DesktopWidgetPath; // Offset: 0x168 | Size: 0x18
	enum class EUseDesktopWidgetType UseDesktopWidgetType; // Offset: 0x180 | Size: 0x1
	char pad_0x182[0x6]; // Offset: 0x182 | Size: 0x6
	struct TArray<struct FWidgetOverrideParam> OverrideParamList; // Offset: 0x188 | Size: 0x10
	struct TMap<struct FString, struct UUserWidget*> CacheWidgetMap; // Offset: 0x198 | Size: 0x50
	struct UUserWidget* AdapteeWidget; // Offset: 0x1e8 | Size: 0x8
	bool bNeedExecuteWidgetOpened; // Offset: 0x1f0 | Size: 0x1
	char pad_0x1F1[0x27]; // Offset: 0x1f1 | Size: 0x27

	// Functions

	// Object: Function SolarUI.SolarAdapterWidgetBase.SetUseDesktopWidgetType
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10120dfbc
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetUseDesktopWidgetType(enum class EUseDesktopWidgetType InType);

	// Object: Function SolarUI.SolarAdapterWidgetBase.SetNeedExecuteWidgetOpened
	// Flags: [Final|Native|Public]
	// Offset: 0x102f7b8f8
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetNeedExecuteWidgetOpened(bool bInNeedExecuteWidgetOpened);

	// Object: Function SolarUI.SolarAdapterWidgetBase.SetAdapterMargin
	// Flags: [Final|Native|Public]
	// Offset: 0x102f7b898
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetAdapterMargin(struct FMargin InMargin);

	// Object: Function SolarUI.SolarAdapterWidgetBase.RefreshUIByOverrideParams
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10120e030
	// Return & Params: [ Num(1) Size(0x10) ]
	void RefreshUIByOverrideParams(struct TArray<struct FWidgetOverrideParam>& WidgetOverrideParams);

	// Object: Function SolarUI.SolarAdapterWidgetBase.LoadUserWidgetResource
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10120e0ec
	// Return & Params: [ Num(0) Size(0x0) ]
	void LoadUserWidgetResource();

	// Object: Function SolarUI.SolarAdapterWidgetBase.IsNeedExecuteWidgetOpened
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x10120df88
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsNeedExecuteWidgetOpened();

	// Object: Function SolarUI.SolarAdapterWidgetBase.GetNeedAdapter
	// Flags: [Final|Native|Public|HasOutParms|Const]
	// Offset: 0x10120deec
	// Return & Params: [ Num(2) Size(0x11) ]
	bool GetNeedAdapter(struct FMargin& OutMargin);

	// Object: Function SolarUI.SolarAdapterWidgetBase.GetAdapteeWidget
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10120e0b8
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UUserWidget* GetAdapteeWidget();
};

// Object: Class SolarUI.SolarNavigableWidgetBase
// Inherited Bytes: 0x260 | Struct Size: 0x290
struct USolarNavigableWidgetBase : UUserWidget {
	// Fields
	struct FMulticastInlineDelegate BeginNavigateEvent; // Offset: 0x260 | Size: 0x10
	struct FMulticastInlineDelegate EndNavigateEvent; // Offset: 0x270 | Size: 0x10
	struct TArray<struct FKey> NavigationAcceptKeys; // Offset: 0x280 | Size: 0x10

	// Functions

	// Object: Function SolarUI.SolarNavigableWidgetBase.EndNavigate
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x102f7bff0
	// Return & Params: [ Num(0) Size(0x0) ]
	void EndNavigate();

	// Object: Function SolarUI.SolarNavigableWidgetBase.BeginNavigate
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x102f7c004
	// Return & Params: [ Num(0) Size(0x0) ]
	void BeginNavigate();

	// Object: Function SolarUI.SolarNavigableWidgetBase.AcceptNavigate
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x102f7bf7c
	// Return & Params: [ Num(1) Size(0xb8) ]
	struct FEventReply AcceptNavigate();
};

// Object: Class SolarUI.SolarNavigableButtonWidget
// Inherited Bytes: 0x290 | Struct Size: 0x3e0
struct USolarNavigableButtonWidget : USolarNavigableWidgetBase {
	// Fields
	struct FMulticastInlineDelegate OnClicked; // Offset: 0x290 | Size: 0x10
	struct FMulticastInlineDelegate OnPressed; // Offset: 0x2a0 | Size: 0x10
	struct FMulticastInlineDelegate OnReleased; // Offset: 0x2b0 | Size: 0x10
	struct FMulticastInlineDelegate OnHovered; // Offset: 0x2c0 | Size: 0x10
	struct FMulticastInlineDelegate OnUnhovered; // Offset: 0x2d0 | Size: 0x10
	struct UButton* Button; // Offset: 0x2e0 | Size: 0x8
	char pad_0x2E8[0x8]; // Offset: 0x2e8 | Size: 0x8
	struct FSlateBrush CachedNormalBrush; // Offset: 0x2f0 | Size: 0xf0

	// Functions

	// Object: Function SolarUI.SolarNavigableButtonWidget.OnUnhoveredEvent
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x102f7bb98
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnUnhoveredEvent();

	// Object: Function SolarUI.SolarNavigableButtonWidget.OnReleasedEvent
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x102f7bbe8
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnReleasedEvent();

	// Object: Function SolarUI.SolarNavigableButtonWidget.OnPressedEvent
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x102f7bc10
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnPressedEvent();

	// Object: Function SolarUI.SolarNavigableButtonWidget.OnHoveredEvent
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x102f7bbc0
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnHoveredEvent();

	// Object: Function SolarUI.SolarNavigableButtonWidget.OnClickedEvent
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x102f7bc38
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClickedEvent();

	// Object: Function SolarUI.SolarNavigableButtonWidget.HandleUnhoveredEvent
	// Flags: [Final|Native|Protected]
	// Offset: 0x102f7bb84
	// Return & Params: [ Num(0) Size(0x0) ]
	void HandleUnhoveredEvent();

	// Object: Function SolarUI.SolarNavigableButtonWidget.HandleReleasedEvent
	// Flags: [Final|Native|Protected]
	// Offset: 0x102f7bbd4
	// Return & Params: [ Num(0) Size(0x0) ]
	void HandleReleasedEvent();

	// Object: Function SolarUI.SolarNavigableButtonWidget.HandlePressedEvent
	// Flags: [Final|Native|Protected]
	// Offset: 0x102f7bbfc
	// Return & Params: [ Num(0) Size(0x0) ]
	void HandlePressedEvent();

	// Object: Function SolarUI.SolarNavigableButtonWidget.HandleHoveredEvent
	// Flags: [Final|Native|Protected]
	// Offset: 0x102f7bbac
	// Return & Params: [ Num(0) Size(0x0) ]
	void HandleHoveredEvent();

	// Object: Function SolarUI.SolarNavigableButtonWidget.HandleClickEvent
	// Flags: [Final|Native|Protected]
	// Offset: 0x102f7bc24
	// Return & Params: [ Num(0) Size(0x0) ]
	void HandleClickEvent();
};

// Object: Class SolarUI.SolarPanelSlotAdapter
// Inherited Bytes: 0x28 | Struct Size: 0x38
struct USolarPanelSlotAdapter : UObject {
	// Fields
	char pad_0x28[0x10]; // Offset: 0x28 | Size: 0x10
};

// Object: Class SolarUI.SolarButtonSlotAdapter
// Inherited Bytes: 0x38 | Struct Size: 0x50
struct USolarButtonSlotAdapter : USolarPanelSlotAdapter {
	// Fields
	char pad_0x38[0x18]; // Offset: 0x38 | Size: 0x18
};

// Object: Class SolarUI.SolarCanvasPanelSlotAdapter
// Inherited Bytes: 0x38 | Struct Size: 0x70
struct USolarCanvasPanelSlotAdapter : USolarPanelSlotAdapter {
	// Fields
	char pad_0x38[0x38]; // Offset: 0x38 | Size: 0x38
};

// Object: Class SolarUI.SolarGridSlotAdapter
// Inherited Bytes: 0x38 | Struct Size: 0x50
struct USolarGridSlotAdapter : USolarPanelSlotAdapter {
	// Fields
	char pad_0x38[0x18]; // Offset: 0x38 | Size: 0x18
};

// Object: Class SolarUI.SolarHorizontalBoxSlotAdapter
// Inherited Bytes: 0x38 | Struct Size: 0x50
struct USolarHorizontalBoxSlotAdapter : USolarPanelSlotAdapter {
	// Fields
	char pad_0x38[0x18]; // Offset: 0x38 | Size: 0x18
};

// Object: Class SolarUI.SolarOverlaySlotAdapter
// Inherited Bytes: 0x38 | Struct Size: 0x50
struct USolarOverlaySlotAdapter : USolarPanelSlotAdapter {
	// Fields
	char pad_0x38[0x18]; // Offset: 0x38 | Size: 0x18
};

// Object: Class SolarUI.SolarScaleBoxSlotAdapter
// Inherited Bytes: 0x38 | Struct Size: 0x50
struct USolarScaleBoxSlotAdapter : USolarPanelSlotAdapter {
	// Fields
	char pad_0x38[0x18]; // Offset: 0x38 | Size: 0x18
};

// Object: Class SolarUI.SolarScrollBoxSlotAdapter
// Inherited Bytes: 0x38 | Struct Size: 0x50
struct USolarScrollBoxSlotAdapter : USolarPanelSlotAdapter {
	// Fields
	char pad_0x38[0x18]; // Offset: 0x38 | Size: 0x18
};

// Object: Class SolarUI.SolarSizeBoxSlotAdapter
// Inherited Bytes: 0x38 | Struct Size: 0x50
struct USolarSizeBoxSlotAdapter : USolarPanelSlotAdapter {
	// Fields
	char pad_0x38[0x18]; // Offset: 0x38 | Size: 0x18
};

// Object: Class SolarUI.SolarUniformGridSlotAdapter
// Inherited Bytes: 0x38 | Struct Size: 0x48
struct USolarUniformGridSlotAdapter : USolarPanelSlotAdapter {
	// Fields
	char pad_0x38[0x10]; // Offset: 0x38 | Size: 0x10
};

// Object: Class SolarUI.SolarVerticalBoxSlotAdapter
// Inherited Bytes: 0x38 | Struct Size: 0x50
struct USolarVerticalBoxSlotAdapter : USolarPanelSlotAdapter {
	// Fields
	char pad_0x38[0x18]; // Offset: 0x38 | Size: 0x18
};

// Object: Class SolarUI.SolarWidgetSwitcherSlotAdapter
// Inherited Bytes: 0x38 | Struct Size: 0x50
struct USolarWidgetSwitcherSlotAdapter : USolarPanelSlotAdapter {
	// Fields
	char pad_0x38[0x18]; // Offset: 0x38 | Size: 0x18
};

// Object: Class SolarUI.SolarWrapBoxSlotAdapter
// Inherited Bytes: 0x38 | Struct Size: 0x58
struct USolarWrapBoxSlotAdapter : USolarPanelSlotAdapter {
	// Fields
	char pad_0x38[0x20]; // Offset: 0x38 | Size: 0x20
};

// Object: Class SolarUI.SolarUISettings
// Inherited Bytes: 0x38 | Struct Size: 0x58
struct USolarUISettings : UDeveloperSettings {
	// Fields
	struct TArray<struct FSolarUIMapWidgetAdapterEntry> WidgetAdapterMapList; // Offset: 0x38 | Size: 0x10
	struct TArray<struct FSolarUIMapPanelSlotAdapterEntry> PanelSlotAdapterMapList; // Offset: 0x48 | Size: 0x10
};

// Object: Class SolarUI.SolarWidgetAdapter
// Inherited Bytes: 0x28 | Struct Size: 0x78
struct USolarWidgetAdapter : UObject {
	// Fields
	char pad_0x28[0x18]; // Offset: 0x28 | Size: 0x18
	struct USolarPanelSlotAdapter* SlotAdapter; // Offset: 0x40 | Size: 0x8
	char pad_0x48[0x30]; // Offset: 0x48 | Size: 0x30
};

// Object: Class SolarUI.SolarImageAdapter
// Inherited Bytes: 0x78 | Struct Size: 0x180
struct USolarImageAdapter : USolarWidgetAdapter {
	// Fields
	char pad_0x78[0x108]; // Offset: 0x78 | Size: 0x108
};

// Object: Class SolarUI.SolarTextBlockAdapter
// Inherited Bytes: 0x78 | Struct Size: 0x108
struct USolarTextBlockAdapter : USolarWidgetAdapter {
	// Fields
	char pad_0x78[0x90]; // Offset: 0x78 | Size: 0x90
};

// Object: Class SolarUI.SolarButtonAdapter
// Inherited Bytes: 0x78 | Struct Size: 0xa0
struct USolarButtonAdapter : USolarWidgetAdapter {
	// Fields
	char pad_0x78[0x28]; // Offset: 0x78 | Size: 0x28
};

// Object: Class SolarUI.SolarSizeBoxAdapter
// Inherited Bytes: 0x78 | Struct Size: 0x90
struct USolarSizeBoxAdapter : USolarWidgetAdapter {
	// Fields
	char pad_0x78[0x18]; // Offset: 0x78 | Size: 0x18
};

// Object: Class SolarUI.SolarRichTextBlockAdapter
// Inherited Bytes: 0x78 | Struct Size: 0xe0
struct USolarRichTextBlockAdapter : USolarWidgetAdapter {
	// Fields
	char pad_0x78[0x68]; // Offset: 0x78 | Size: 0x68
};

// Object: Class SolarUI.SolarListViewAdapter
// Inherited Bytes: 0x78 | Struct Size: 0x78
struct USolarListViewAdapter : USolarWidgetAdapter {
};

// Object: Class SolarUI.SolarTileViewAdapter
// Inherited Bytes: 0x78 | Struct Size: 0x88
struct USolarTileViewAdapter : USolarWidgetAdapter {
	// Fields
	char pad_0x78[0x10]; // Offset: 0x78 | Size: 0x10
};

// Object: Class SolarUI.SolarWidgetContext
// Inherited Bytes: 0x28 | Struct Size: 0xc8
struct USolarWidgetContext : UObject {
	// Fields
	struct TMap<struct UObject*, struct USolarWidgetAdapter*> DefaultWidgetAdapterDict; // Offset: 0x28 | Size: 0x50
	struct TMap<struct UObject*, struct USolarPanelSlotAdapter*> DefaultPanelSlotAdapterDict; // Offset: 0x78 | Size: 0x50
};

// Object: Class SolarUI.SolarWidgetLayout
// Inherited Bytes: 0x28 | Struct Size: 0x40
struct USolarWidgetLayout : UObject {
	// Fields
	struct USolarWidgetContext* WidgetContext; // Offset: 0x28 | Size: 0x8
	struct TArray<struct USolarWidgetLayoutPlatform*> LayoutPlatforms; // Offset: 0x30 | Size: 0x10
};

// Object: Class SolarUI.SolarWidgetLayoutPlatform
// Inherited Bytes: 0x28 | Struct Size: 0xd8
struct USolarWidgetLayoutPlatform : UObject {
	// Fields
	enum class USolarWidgetLayoutType WidgetLayoutType; // Offset: 0x28 | Size: 0x1
	char pad_0x29[0xf]; // Offset: 0x29 | Size: 0xf
	struct TMap<struct FName, struct USolarWidgetAdapter*> WidgetAdapterDict; // Offset: 0x38 | Size: 0x50
	char pad_0x88[0x50]; // Offset: 0x88 | Size: 0x50
};

// Object: Class SolarUI.SolarWidgetLayoutTest
// Inherited Bytes: 0x338 | Struct Size: 0x338
struct USolarWidgetLayoutTest : USolarUserWidgetBase {
};

// Object: Class SolarUI.SolarWidgetLibrary
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct USolarWidgetLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object: Function SolarUI.SolarWidgetLibrary.NavigateTo
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10120f028
	// Return & Params: [ Num(1) Size(0x8) ]
	void NavigateTo(struct UWidget* WidgetToNavigate);
};

