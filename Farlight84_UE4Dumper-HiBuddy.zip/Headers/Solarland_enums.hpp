#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Enum Solarland.EBoolean
enum class EBoolean : uint8_t {
	BranchFalse = 0,
	BranchTrue = 1,
	EBoolean_MAX = 2
};

// Object: Enum Solarland.EActorRegisterType
enum class EActorRegisterType : uint8_t {
	EART_None = 0,
	EART_Character = 1,
	EART_Vehicle = 2,
	EART_Turret = 4,
	EART_TreasureBox = 8,
	EART_ChargingPile = 16,
	EART_Summon = 32,
	EART_HumanoidTarget = 64,
	EART_Water = 128,
	EART_MAX = 129
};

// Object: Enum Solarland.ESolarNetMode
enum class ESolarNetMode : uint8_t {
	NM_Standalone = 0,
	NM_DedicatedServer = 1,
	NM_ListenServer = 2,
	NM_Client = 3,
	NM_MAX = 4,
	NM_Unknown = 5
};

// Object: Enum Solarland.ESolarPlayStage
enum class ESolarPlayStage : uint8_t {
	None = 0,
	Login = 1,
	Lobby = 2,
	Battle = 3,
	Settlement = 4,
	PlaceHolder1 = 5,
	PlaceHolder2 = 6,
	PlaceHolder3 = 7,
	ESolarPlayStage_MAX = 8
};

// Object: Enum Solarland.ESolarStageFlags
enum class ESolarStageFlags : uint8_t {
	None = 0,
	Login = 1,
	Lobby = 2,
	Tutorial = 4,
	Battle = 8,
	Settlement = 16,
	All = 31,
	ESolarStageFlags_MAX = 32
};

// Object: Enum Solarland.ERoleSkillOperation
enum class ERoleSkillOperation : uint8_t {
	None = 0,
	ToNormal = 1,
	ClearCD = 2,
	ResetCD = 3,
	Forbid = 4,
	Unforbid = 5,
	Disable = 6,
	Enable = 7,
	ERoleSkillOperation_MAX = 8
};

// Object: Enum Solarland.ECustomParamType
enum class ECustomParamType : uint8_t {
	WeaponDamageScale = 0,
	SkillDamageScale = 1,
	HeadShootDamageScale = 2,
	VehicleDamageScale = 3,
	MoveSpeedScale = 4,
	ShieldScale = 5,
	HealthScale = 6,
	Resurgence = 7,
	GravityScale = 8,
	None = 9,
	ECustomParamType_MAX = 10
};

// Object: Enum Solarland.EBattleEndType
enum class EBattleEndType : uint8_t {
	None = 0,
	BattleOver = 1,
	PlayerNotEnough = 2,
	BeginTimeOut = 3,
	Abandoned = 4,
	EBattleEndType_MAX = 5
};

// Object: Enum Solarland.ESCTournamentType
enum class ESCTournamentType : uint8_t {
	None = 0,
	SingleRace = 1,
	PointRace = 2,
	KnockoutRace = 3,
	PointRaceV2 = 4,
	ESCTournamentType_MAX = 5
};

// Object: Enum Solarland.ESCRoomType
enum class ESCRoomType : uint8_t {
	None = 0,
	Normal = 1,
	Tournament = 2,
	CustomServer = 3,
	ESCRoomType_MAX = 4
};

// Object: Enum Solarland.ESCMInGameState
enum class ESCMInGameState : uint8_t {
	None = 0,
	InPrepare = 1,
	InBattle = 2,
	InBattleEnd = 3,
	ESCMInGameState_MAX = 4
};

// Object: Enum Solarland.ESCMHostType
enum class ESCMHostType : uint8_t {
	Global = 0,
	Side = 1,
	Player = 2,
	ESCMHostType_MAX = 3
};

// Object: Enum Solarland.ESCMDataRankType
enum class ESCMDataRankType : uint8_t {
	None = 0,
	Ascending = 1,
	AscendingReplace = 2,
	Descending = 3,
	DescendingReplace = 4,
	ESCMDataRankType_MAX = 5
};

// Object: Enum Solarland.ESCMDataChangeType
enum class ESCMDataChangeType : uint8_t {
	Add = 0,
	Change = 1,
	Delete = 2,
	DeleteAll = 3,
	ESCMDataChangeType_MAX = 4
};

// Object: Enum Solarland.EReplayCameraMode
enum class EReplayCameraMode : uint8_t {
	None = 0,
	ThirdPersonMode = 1,
	LockMode = 2,
	FreeMode = 3,
	LookAtMode = 4,
	CircularMode = 5,
	FreeLookAtMode = 6,
	CloseUpMode = 7,
	VictimMode = 8,
	FollowProjectileMode = 9,
	EReplayCameraMode_MAX = 10
};

// Object: Enum Solarland.EStatisticsType
enum class EStatisticsType : uint8_t {
	None = 0,
	KillNum = 1,
	P_KillStreak = 2,
	KillDownNum = 3,
	AssistNum = 4,
	KillPlayer = 5,
	DeathNum = 6,
	LifeTime = 7,
	HealSelf = 8,
	DeathPos = 9,
	SaveCount = 10,
	ReceivedHeal = 11,
	KillTeammate = 12,
	KillDownTeammate = 13,
	CarSkillCount = 14,
	P_BattleResult = 15,
	S_KillCount = 16,
	S_KillDownCount = 17,
	S_AssistCount = 18,
	S_DeathCount = 19,
	S_SaveCount = 20,
	S_UnBattleEndPlayerCount = 21,
	G_KillNum = 22,
	G_KillDown = 23,
	KillNumToPlayerID = 24,
	KillNumToRealPlayer = 25,
	KillStreakHistory = 26,
	CharacterKillNumWithID = 27,
	AssistKillAINum = 28,
	AssistKillPlayerNum = 29,
	AssistKillToPlayerID = 30,
	KillNpcNum = 31,
	KillMonster = 32,
	TotalWeaponKillNum = 33,
	WeaponAssistWithID = 34,
	WeaponKillNumWithID = 35,
	KillNumWithIDByVechile = 36,
	TotalVehicleKillNum = 37,
	RevengeNum = 38,
	AccurateKillTimes = 39,
	AccurateKillDownTimes = 40,
	WeaponSkillKillNum = 41,
	PunchKill = 42,
	AreaKillNum_Bubble = 43,
	KillSameCharacterCount = 44,
	DeathNumByPlayerID = 45,
	DyingCount = 46,
	DyingByNpc = 47,
	DyingByMonster = 48,
	DeathByVechile = 49,
	DeathByBombingArea = 50,
	CauseDamage = 51,
	CauseDamageToPlayerID = 52,
	CauseDamageToRealPlayer = 53,
	CauseDamageByHero = 54,
	WeaponDamageWithIDToPlayer = 55,
	WeaponDamageWithTypeToPlayer = 56,
	VechileDamageWithIDToPlayer = 57,
	TotalVehicleDamage = 58,
	ReceivedDamage = 59,
	ReceivedDamageByPlayerID = 60,
	DamageByAI = 61,
	DamageByMonster = 62,
	DamageToMonster = 63,
	DamageToNpc = 64,
	AccurateDamage = 65,
	AttackTimes = 66,
	HitTimes = 67,
	HitedTimes = 68,
	AccurateDameageTimes = 69,
	BeAccurateDameageTimes = 70,
	TeammateHeal = 71,
	ResurrectionCount = 72,
	VechileDistance = 73,
	TotalVechileDistance = 74,
	VehicleTime = 75,
	UseVehicleTypes = 76,
	LastUseVehicleID = 77,
	TakeTheCarOfEnemy = 78,
	DriveCarInAirTime = 79,
	DriveHoverCarInWaterDistance = 80,
	RepairVehicleCount = 81,
	WeaponID1 = 82,
	WeaponID2 = 83,
	WeaponLevel1 = 84,
	WeaponLevel2 = 85,
	UseWeaponSkillNum = 86,
	WeaponUseStartTimeWithID = 87,
	WeaponUseTimeWithID = 88,
	MaxGodWeaponNum = 89,
	CollectEnergy = 90,
	EscapeTimes = 91,
	CollectBoxNum = 92,
	CollectBoxNumWithHighQuality = 93,
	FlyCount = 94,
	ArmorUseCount = 95,
	ShieldRechargeCount = 96,
	EChestOpenNumForID = 97,
	LandingPos = 98,
	LandingTime = 99,
	DropoutEvent = 100,
	DropoutTime = 101,
	MedicineUseCount = 102,
	RadarUseCount = 103,
	OpenAirBoxNum = 104,
	KillInAirNum = 105,
	KillDownInAirNum = 106,
	ResurrectionNum = 107,
	ResurrectionCapsule = 108,
	TeamFriendRevive = 109,
	BuyESElectricNum = 110,
	CarFireCount = 111,
	HangTimeDuration = 112,
	SkydiveLandingDuration = 113,
	SwimDistance = 114,
	DanceCount = 115,
	PosionWalkDistance = 116,
	WalkDistance = 117,
	ShieldExpGainCount = 118,
	UpgradeShieldCount = 119,
	UpgradeRedShieldCount = 120,
	JumpBoardUseCount = 121,
	TerminaterCount = 122,
	ItemTypeCollectCount = 123,
	ZiplineUseCount = 124,
	LevelUpCount = 125,
	SlideShovelDistance = 126,
	UltimateSkillUseCount = 127,
	TacticalSkillUseCount = 128,
	TacticalSkill1UseCount = 129,
	TacticalSkill2UseCount = 130,
	UltimateSkillDamage = 131,
	TacticalSkillDamage = 132,
	TacticalSkill2Damage = 133,
	UltimateSkillTakenDamage = 134,
	TacticalSkillTakenDamage = 135,
	TacticalSkill2TakenDamage = 136,
	UltimateSkillKillNum = 137,
	TacticalSkillKillNum = 138,
	TacticalSkill2KillNum = 139,
	UltimateSkillDamageCount = 140,
	TacticalSkillDamageCount = 141,
	TacticalSkill2DamageCount = 142,
	UltimateSkillDamageAvgDistance = 143,
	TacticalSkillDamageAvgDistance = 144,
	TacticalSkill2DamageAvgDistance = 145,
	HasHighlight = 146,
	WeaponID3 = 147,
	BackpackItems = 148,
	CurrentWeaponID = 149,
	StrongholdVisitCount = 150,
	StrongholdKillCount = 151,
	StrongholdBoxCollectCount = 152,
	StrongholdDanceCount = 153,
	StrongholdWalkDistance = 154,
	StrongholdDamage = 155,
	StrongholdItemCollectCount = 156,
	GameplayEnterIsland = 157,
	CollectBuddyCount = 158,
	TesselationBuddyCount = 159,
	UseBuddyCount = 160,
	CauseDamageByBuddy = 161,
	MoveSafeAreaCount = 162,
	TotalCatchChillCount = 163,
	CatchChillMaxCountOneTime = 164,
	StayInBuddySmokeMaxSec = 165,
	MoveDeathBoxCount = 166,
	BuddyDeformMoveMaxDistance = 167,
	BuddyDeformTime = 168,
	BuddyEmissionselfCount = 169,
	BuddyWipeOutCount = 170,
	BuddyGetSuppliesCount = 171,
	BuddyGetItemCount = 172,
	BuddyScanEnemiesCount = 173,
	BuddyInWindSec = 174,
	BuddyPickUpCount = 175,
	MAX = 176
};

// Object: Enum Solarland.EPlayHighlightEntryType
enum class EPlayHighlightEntryType : uint8_t {
	Settlement = 0,
	HistoricalMatch = 1,
	TournamentList = 2,
	CustomRoomList = 3,
	EPlayHighlightEntryType_MAX = 4
};

// Object: Enum Solarland.EReplayState
enum class EReplayState : uint8_t {
	Idle = 0,
	Recording = 1,
	PlayingRequestAddress = 2,
	PlayingTryToStart = 3,
	PlayingStarted = 4,
	PlayingLoadLevelsStarted = 5,
	PlayingLevelLoaded = 6,
	PlayingStreamReadied = 7,
	PlayingFirstScrubing = 8,
	Playing = 9,
	PlayingAtEnd = 10,
	EReplayState_MAX = 11
};

// Object: Enum Solarland.EReplayType
enum class EReplayType : uint8_t {
	None = 0,
	CustomRoom = 1,
	Tournament = 2,
	LiveWatchOnly = 3,
	LocalHighlight = 4,
	LocalMonitor = 5,
	EReplayType_MAX = 6
};

// Object: Enum Solarland.EWalkMode
enum class EWalkMode : uint8_t {
	Idle = 0,
	Run = 1,
	Sprint = 2,
	CrouchIdle = 3,
	CrouchRun = 4,
	CrouchSprint = 5,
	Crawl = 6,
	SlideTackle = 7,
	EWalkMode_MAX = 8
};

// Object: Enum Solarland.EAirMoveMode
enum class EAirMoveMode : uint8_t {
	None = 0,
	Jump = 1,
	JetFly = 2,
	Cruise = 3,
	Skydive = 4,
	Launch = 5,
	Fall = 6,
	Fly = 7,
	WallRun = 8,
	SkywardFly = 9,
	ZipLine = 10,
	HumanCannon = 11,
	CatchOwl = 12,
	EAirMoveMode_MAX = 13
};

// Object: Enum Solarland.EClientMoveTrustType
enum class EClientMoveTrustType : uint8_t {
	TrustLocation = 0,
	TrustLocationAndMovementMode = 1,
	EClientMoveTrustType_MAX = 2
};

// Object: Enum Solarland.EItemModifyResult
enum class EItemModifyResult : uint8_t {
	Succeed = 0,
	Overflow = 1,
	Deficient = 2,
	IllegalParam = 3,
	Error = 4,
	EItemModifyResult_MAX = 5
};

// Object: Enum Solarland.EItemAppearanceType
enum class EItemAppearanceType : uint8_t {
	EApprenace_None = 0,
	EApprenace_Outline = 1,
	EApprenace_Float = 2,
	EApprenace_All = 3,
	EApprenace_MAX = 4
};

// Object: Enum Solarland.EItemType
enum class EItemType : int32_t {
	NONE = 0,
	SHIELD = 101,
	ARMOR = 102,
	BULLET = 103,
	CARIRIDGE_BAG = 104,
	ARMOR_MATERIAL = 105,
	ENERGY_MODULE = 106,
	EXTRA_ENERGY = 107,
	RADAR_OPERATOR = 108,
	BACKPACK_ENERGY = 109,
	BACKUP_ENERGY = 110,
	SHIELD_RECHARGER = 112,
	BACKPACK_ITEM = 113,
	WEAPON_PARTS = 114,
	JETPACK_MODULE_HORIZONTAL = 111,
	JETPACK_MODULE_VERTICAL = 115,
	REVIVE_ITEM = 116,
	SELF_RESCUE = 118,
	TREASUREBOX = 120,
	AIRDROPBOX = 121,
	DEATHBOX = 122,
	HOTSPRINTBOX = 123,
	TACTICALBOX = 124,
	NEUTRAL_CARD = 130,
	COLLECTION_ITEM = 131,
	DRAGONBALL = 132,
	TALENT_POINT = 133,
	HELMET = 140,
	ENHANCER_AMMO = 141,
	ENHANCER_MEDIC = 142,
	ENHANCER_SHIELD_RECHARGER = 143,
	ENHANCER_BACKPACK = 144,
	SHIELD_UPGRADE_MATERIAL = 148,
	EXP_ITEM = 149,
	WEAPON = 151,
	WEAPON_SKIN = 171,
	MISSIONSPAWN = 160,
	MISSIONCHEST = 161,
	MISSIONWORSHIP = 162,
	BACKPACK = 201,
	TAILFLAME = 202,
	CARDPOSE = 203,
	CARDBACKGROUND = 204,
	CAPSULE = 251,
	CHAR_SKIN_MIN = 301,
	CHAR_ANIMATION_MVP = 302,
	CHAR_SKIN_MAX = 350,
	CHARACTER = 351,
	EXPERIENCE = 401,
	GIFTBAG = 404,
	CHARACTER_TRIALCARD = 405,
	CHARACTERSKIN_TRIALCARD = 406,
	ACTIVENESS = 411,
	WEAPONSKIN_TRIALCARD = 412,
	GIFTBAG_ONBACKPACK = 414,
	BACKPACK_TRIALCARD = 415,
	TAILFLAME_TRIALCARD = 416,
	DIAMOND_VOUCHER = 417,
	LOTCOIN = 421,
	ZOMBORG = 422,
	WISHCOIN = 423,
	SURPRISECOIN = 424,
	TOKEN = 430,
	BUSINESSCARDFRAME = 432,
	AVATARFRAME = 434,
	CHARACTER_SHARD = 435,
	CHARACTER_SKIN_SHARD = 436,
	WEAPON_SKIN_SHARD = 437,
	BACKPACK_SHARD = 438,
	TAILFLAME_SHARD = 439,
	CAPSULE_SHARD = 440,
	VEHICLE_SKIN_SHARD = 441,
	ACCOUNT_AVATAR = 443,
	EMOTE = 444,
	SIGNIN_CARD = 447,
	RAFFLE_TICKET = 448,
	BUDDYBALL = 449,
	VEHICLE_SKIN = 701,
	SUPPLYBOX = 801,
	RANDOM_PACK = 901,
	DISPLAY_ITEM = 999,
	EItemType_MAX = 1000
};

// Object: Enum Solarland.EBagScopeSlotType
enum class EBagScopeSlotType : uint8_t {
	None = 0,
	Primary = 10,
	Second = 11,
	Bag = 12,
	BagSlot_1 = 13,
	BagSlot_2 = 14,
	BagSlot_3 = 15,
	BagSlot_4 = 16,
	BagSlot_5 = 17,
	BagSlot_6 = 18,
	PassiveSlot_1 = 19,
	PassiveSlot_2 = 20,
	PassiveSlot_3 = 21,
	ActiveSlot = 22,
	EBagScopeSlotType_MAX = 23
};

// Object: Enum Solarland.EWeaponSlotType
enum class EWeaponSlotType : int32_t {
	EWeaponSlotType_UnArm = -1,
	EWeaponSlotType_Primary = 0,
	EWeaponSlotType_Secondary = 1,
	EWeaponSlotType_Tertiary = 2,
	EWeaponSlotType_MAX = 3
};

// Object: Enum Solarland.EGmType
enum class EGmType : uint8_t {
	Fetch = 0,
	Discard = 1,
	ClearBackPack = 2,
	Use = 3,
	RemoveWeapon = 4,
	EGmType_MAX = 5
};

// Object: Enum Solarland.ESocialActionType
enum class ESocialActionType : uint8_t {
	None = 0,
	Like = 1,
	Unlike = 2,
	ESocialActionType_MAX = 3
};

// Object: Enum Solarland.EWeaponScopeType
enum class EWeaponScopeType : uint8_t {
	None = 0,
	ScopeX0 = 1,
	ScopeX1 = 2,
	ScopeX2 = 3,
	ScopeX3 = 4,
	ScopeX4 = 5,
	ScopeX6 = 6,
	ScopeX8 = 7,
	Count = 8,
	EWeaponScopeType_MAX = 9
};

// Object: Enum Solarland.EFindSpectateTargetType
enum class EFindSpectateTargetType : uint8_t {
	Teammate = 0,
	PlayerKiller = 1,
	AIKiller = 2,
	AllNonBot = 3,
	All = 4,
	EFindSpectateTargetType_MAX = 5
};

// Object: Enum Solarland.ESpectatePhase
enum class ESpectatePhase : uint8_t {
	NotSpectate = 0,
	LookAtSelfDeathBox = 1,
	SpectateTeammates = 2,
	BlockWhenAced = 3,
	SpectateAllPlayers = 4,
	ESpectatePhase_MAX = 5
};

// Object: Enum Solarland.EAssistLockState
enum class EAssistLockState : uint8_t {
	None = 0,
	PreEnterAssistLock = 1,
	EnterAssistLock = 2,
	HoldAssistLock = 3,
	LeaveAssistLock = 4,
	EAssistLockState_MAX = 5
};

// Object: Enum Solarland.ESolarTablesEnum_BattleUpgradeEffectType
enum class ESolarTablesEnum_BattleUpgradeEffectType : uint8_t {
	MaxHp = 0,
	BulletDamage = 1,
	CharacterSkillDamage = 2,
	VehicleWeaponDamage = 3,
	VehicleSkillDamage = 4,
	VehicleStrikeDamage = 5,
	CharacterPunchDamage = 6,
	CharacterUpgradeDamage = 7,
	SuperSkillCD = 8,
	Tactical_1_SkillCD = 9,
	Tactical_2_SkillCD = 10,
	Tactical_3_SkillCD = 11,
	_Count = 12,
	ESolarTablesEnum_MAX = 13
};

// Object: Enum Solarland.ESolarSummonDeathReason
enum class ESolarSummonDeathReason : uint8_t {
	SelfTimeDecay = 0,
	SelfLifeDecay = 1,
	OtherDestroy = 2,
	InValid = 3,
	None = 4,
	ESolarSummonDeathReason_MAX = 5
};

// Object: Enum Solarland.ESCMDamageType
enum class ESCMDamageType : uint8_t {
	Point = 0,
	Poison = 1,
	Bomb = 2,
	AirDrop = 3,
	Dying = 4,
	VehicleHit = 5,
	VehicleExplosion = 6,
	Weapon = 7,
	UnarmWeapon = 8,
	VehicleWeapon = 9,
	SummonWeapon = 10,
	VehicleAbility = 11,
	WeaponAbility = 12,
	HelplessDeathVerge = 13,
	DeathVergeInWater = 14,
	GMCmd = 15,
	BackToLobby = 16,
	AppEnterBackground = 17,
	LongTimeDisconnect = 18,
	ClassSkill = 19,
	TacticalSkill = 20,
	Outbound = 21,
	HumanCannonMoveHit = 22,
	HumanCannonMoveFallenSlam = 23,
	HumanCannonExplode = 24,
	ProjectileExplosiveGrenadeDamage = 25,
	ESCMDamageType_MAX = 26
};

// Object: Enum Solarland.EDamageResultType
enum class EDamageResultType : uint8_t {
	Normal = 0,
	Down = 1,
	Die = 2,
	EDamageResultType_MAX = 3
};

// Object: Enum Solarland.EHealthChangeType
enum class EHealthChangeType : uint8_t {
	Normal = 0,
	Self = 1,
	Ability = 2,
	Ability_Deadly = 3,
	Item = 4,
	Teammate = 5,
	Environment = 6,
	EHealthChangeType_MAX = 7
};

// Object: Enum Solarland.ETeamType
enum class ETeamType : uint8_t {
	PlayerTeam = 0,
	AITeam = 1,
	OnlyPlayerTeam = 2,
	EmptyTeam = 3,
	AnyTeam = 4,
	ETeamType_MAX = 5
};

// Object: Enum Solarland.EMatchResult
enum class EMatchResult : uint8_t {
	None = 0,
	Victory = 1,
	Fail = 2,
	Draw = 3,
	EMatchResult_MAX = 4
};

// Object: Enum Solarland.EPlayerStateRepType
enum class EPlayerStateRepType : uint8_t {
	Character = 0,
	Controller = 1,
	EPlayerStateRepType_MAX = 2
};

// Object: Enum Solarland.EPlayerChangedGoldResult
enum class EPlayerChangedGoldResult : uint8_t {
	None = 0,
	Success = 1,
	GoldIsNotEnough = 2,
	NetworkError = 3,
	EPlayerChangedGoldResult_MAX = 4
};

// Object: Enum Solarland.EPlayerChangedGoldType
enum class EPlayerChangedGoldType : uint8_t {
	None = 0,
	CostedGold = 1,
	ReceivedGold = 2,
	EPlayerChangedGoldType_MAX = 3
};

// Object: Enum Solarland.EExpBehaviorType
enum class EExpBehaviorType : uint8_t {
	None = 0,
	Kill = 1,
	Assist = 2,
	Damage = 3,
	Pickup = 4,
	Survival = 5,
	Spawner = 6,
	Device = 7,
	TreasureBox = 8,
	DeathBox = 9,
	Airdrop = 10,
	PureDrop = 11,
	ExpSpring = 12,
	DmgToCharacter = 13,
	DmgToVehicle = 14,
	DmgToSummon = 15,
	SlotMachine = 16,
	TacticalBox = 19,
	ShieldUpgrade = 20,
	TeamDestroy = 21,
	RevengeKilling = 22,
	WeakReward = 23,
	KillDown = 24,
	AssistingKillDown = 25,
	OpenHotSprintBox = 26,
	OpenAirdrop = 27,
	UseRespawnDevice = 28,
	ReviveTeammates = 29,
	ReviveReward = 30,
	HelpReward = 31,
	CollectBuddy = 32,
	EExpBehaviorType_MAX = 33
};

// Object: Enum Solarland.ECharacterStateInGame
enum class ECharacterStateInGame : uint8_t {
	None = 0,
	InVehicle = 1,
	Dying = 2,
	Dead = 4,
	MaxState = 7,
	ECharacterStateInGame_MAX = 8
};

// Object: Enum Solarland.EPlayerStateInGame
enum class EPlayerStateInGame : uint8_t {
	None = 0,
	AppHasDeactivated = 1,
	AppHasReactivated = 2,
	Talking = 4,
	MaxState = 7,
	EPlayerStateInGame_MAX = 8
};

// Object: Enum Solarland.EReplayActivityHeatKillUseType
enum class EReplayActivityHeatKillUseType : uint8_t {
	None = 0,
	Weapon = 1,
	Vehicle = 2,
	Skill = 3,
	Punch = 4,
	EReplayActivityHeatKillUseType_MAX = 5
};

// Object: Enum Solarland.EPlayerActivityHeatType
enum class EPlayerActivityHeatType : uint8_t {
	None = 0,
	Parachute = 1,
	ResurrectionParachute = 2,
	KillDown = 3,
	MultiKill = 4,
	BeKillDown = 5,
	Death = 6,
	Win = 7,
	Max = 8
};

// Object: Enum Solarland.EPassiveTriggeredVoice
enum class EPassiveTriggeredVoice : int32_t {
	NOVOICE = 0,
	Personality = 1,
	TakeIt = 1002,
	Alright = 1003,
	GotIt = 1004,
	MarkLocation = 1005,
	RemindTeammateRevive = 2006,
	NeedWeapons = 2009,
	NeedVehicle = 2010,
	Level1 = 2301,
	Level2 = 2303,
	Level3 = 2303,
	Level4 = 2304,
	Level5 = 2305,
	NeedMuzzle = 3001,
	NeedGrip = 3002,
	NeedMagazine = 3003,
	NeedStock = 3004,
	NeedScope = 3005,
	NeedShield = 3006,
	NeedBatteryPack = 3007,
	NeedHorizontalCooldown = 3008,
	NeedVerticalCooldown = 3009,
	NeedSMGAmmo = 3010,
	NeedShutGunAmmo = 3011,
	NeedRifleAmmo = 3012,
	NeedSniperAmmo = 3013,
	NeedBandage = 3014,
	NeedShieldRestorer = 3015,
	NeedSpecialWeapon = 3016,
	NeedRespawnPod = 3017,
	NeedBigShield = 3018,
	NeedEnhancerMedical = 3020,
	NeedEnhancerShield = 3021,
	NeedEnhancerAmmo = 3022,
	NeedMedKit = 3024,
	NeedHelmet = 3025,
	NeedBetterGear = 3026,
	NeedEnhancerBackpack = 3042,
	AirdropsDelivering = 4001,
	AirdropsDelivered = 4002,
	Remaining3EnemySuqads = 4003,
	Remaining2EnemySuqads = 4004,
	Remaining1EnemySuqads = 4005,
	SafeZoneRetract30s = 4006,
	ResurrectionPeriodEnded = 4007,
	WelcomeToFarlight84 = 4008,
	AirdropsArriveIn60 = 4009,
	AirdropsArriveIn45 = 4010,
	AirdropsArriveIn30 = 4011,
	CharAppear = 5000,
	UsingMedicine = 5001,
	AddingShield = 5002,
	Reloading = 5003,
	HelpingTeammate = 5004,
	HitEnemy = 5005,
	KillEnemy = 5006,
	DestroyOtherTeam = 5007,
	ReviveTeammate = 5008,
	TakeDamage = 5009,
	Defeated = 5010,
	GetKilled = 5011,
	TeammataDefeated = 5012,
	TooFarApart = 5013,
	Charging50 = 5014,
	ChargingFinish = 5015,
	BecomeKillLeader = 5016,
	BackInTheFight = 5017,
	ParachuteFollowMe = 5018,
	ParachuteStartJump = 5019,
	UsingBandage = 5001,
	UseSuperSkill = 5021,
	UseSuperSkillEnemy = 5024,
	UseTacticalSkill_2 = 5025,
	UseTacticalSkill_3 = 5026,
	NearbyEnemyLanding = 5027,
	OneMoreEnemyKilled = 5028,
	EnemyDown = 5029,
	OneMoreEnemyDown = 5030,
	EnemiesDown = 5031,
	BreakEnemyShield = 5032,
	AnotherSquadAttack = 5033,
	TeammateKilled = 5034,
	GlobalNewKillLeader = 4022,
	Teammate_Become_KillLeader = 5035,
	OtherTeam_Become_KillLeader = 5036,
	GlobalFirstBlood = 4014,
	TeamFirstBlood = 5037,
	OtherTeamFirstBlood = 5038,
	DefeatKillLeader = 5039,
	RemainHalfTeam = 5040,
	RemainThreeTeam = 5041,
	RemainTwoTeam = 5042,
	RemainOneTeam = 5043,
	AllInAreaOnWaitShrink = 5044,
	AllOutOfAreaOnWaitShrinkDis = 5045,
	AllOutOfAreaOnWaitShrink = 5046,
	OutOfAreaOnWaitShrink = 5047,
	AllOutOfAreaOnCountdown30Dis = 5048,
	AllOutOfAreaOnCountdown10Dis = 5065,
	AllOutOfAreaOnCountdown30 = 5049,
	AllOutOfAreaOnCountdown10 = 5066,
	AllInAreaOnShrinking = 5050,
	AllOutOfAreaOnShrinking = 5051,
	OutOfAreaOnShrinking = 5052,
	FinalAreaOnCountdown = 5053,
	FinalAreaOnShrinking = 5054,
	TeammateSpreadOut = 5055,
	BroadcastOnWaitShrink = 4015,
	BroadcastOnShrinking = 4016,
	BroadcastOnFinalShrinking = 4017,
	ExpSpringComingSoon = 5056,
	ExpSpringChestIsOpened = 5057,
	BroadcastExpSpringPreOpen = 4018,
	AirdropComingSoon = 5058,
	BroadcastAirdropComingSoon = 4019,
	AirdropRainComingSoon = 5059,
	BroadcastAirdropRainComingSoon = 4020,
	SuperAirdropComingSoon = 5060,
	BroadcastSuperAirdropComingSoon = 4021,
	PromiseToRescue = 1016,
	PromiseToRevive = 1014,
	PlayerUpgrade = 5067,
	SkillUpgradeNotice = 5068,
	SkillUpgradeApplied = 5069,
	EPassiveTriggeredVoice_MAX = 5070
};

// Object: Enum Solarland.ESolarTablesEnum_CharacterType
enum class ESolarTablesEnum_CharacterType : uint8_t {
	None = 0,
	Assault = 1,
	Defence = 2,
	Support = 3,
	Scout = 4,
	Control = 5,
	_Count = 6,
	ESolarTablesEnum_MAX = 7
};

// Object: Enum Solarland.EPlayerNetStateInGame
enum class EPlayerNetStateInGame : uint8_t {
	None = 0,
	Online = 1,
	Offline = 2,
	EPlayerNetStateInGame_MAX = 3
};

// Object: Enum Solarland.ETalentState
enum class ETalentState : uint8_t {
	Activating = 0,
	CoolingDown = 1,
	Unactivated = 2,
	Invalid = 3,
	ETalentState_MAX = 4
};

// Object: Enum Solarland.EInteractableType
enum class EInteractableType : uint8_t {
	FIRECIRCLE = 0,
	JUMPPAD = 1,
	VEHICLEPAD = 2,
	RADARSTATION = 3,
	ELECTRICSHOP = 4,
	CHARGINGPILE = 5,
	SHIELDUPGRADEITEM = 6,
	SHIELDCREATOR = 7,
	TACTICALTREASUREBOX = 8,
	RESPAWNDEVICE = 9,
	DRAGON_SUMMONING_ALTAR = 10,
	AIRDROPTREASUREBOX = 11,
	MAX = 12
};

// Object: Enum Solarland.EWorldMarkType
enum class EWorldMarkType : uint8_t {
	ITEM = 0,
	INVALID = 1,
	WARNING = 2,
	MINIMAP = 3,
	BIGMAP = 4,
	VEHICLE = 5,
	INTERACTABLEACTOR = 6,
	QUICKCHATWHEEL = 7,
	ATTACHED = 8,
	SUMMONACTOR = 9,
	LASTVEHICLE = 10,
	PERMANENTMARK = 11,
	OTHER = 12,
	BUDDY = 13,
	MAX = 14
};

// Object: Enum Solarland.EAppLifetimeState
enum class EAppLifetimeState : uint8_t {
	NONE = 0,
	NORMAL = 1,
	Background = 2,
	Deactive = 3,
	Terminated = 4,
	EAppLifetimeState_MAX = 5
};

// Object: Enum Solarland.ESkydivingState
enum class ESkydivingState : uint8_t {
	NotStarted = 0,
	PreStart = 1,
	InProgress = 2,
	Completed = 3,
	ESkydivingState_MAX = 4
};

// Object: Enum Solarland.ECruiseState
enum class ECruiseState : uint8_t {
	None = 0,
	Boarded = 1,
	CruisePendingStarted = 2,
	CruiseStarted = 3,
	ParachuteAllowed = 4,
	ParachutePendingStarted = 5,
	ParachuteStarted = 6,
	End = 7,
	Max = 8
};

// Object: Enum Solarland.ESCMPlayerOutPath
enum class ESCMPlayerOutPath : uint8_t {
	None = 0,
	OutFromSettingUI = 1,
	OutBySelf = 2,
	KickOutByServer = 3,
	OBSwitchScene = 4,
	Victory = 5,
	ESCMPlayerOutPath_MAX = 6
};

// Object: Enum Solarland.ESCMPlayerPunishType
enum class ESCMPlayerPunishType : uint8_t {
	None = 0,
	HangUp = 1,
	DropOut = 2,
	IsolationPool = 3,
	KillTeammate = 4,
	ESCMPlayerPunishType_MAX = 5
};

// Object: Enum Solarland.ESkydiveStage
enum class ESkydiveStage : uint8_t {
	None = 0,
	Flying = 1,
	Landing = 2,
	ESkydiveStage_MAX = 3
};

// Object: Enum Solarland.ESolarCharacterType
enum class ESolarCharacterType : uint8_t {
	ESolarCharacterType_None = 0,
	ESolarCharacterType_Player = 1,
	ESolarCharacterType_Bot = 2,
	ESolarCharacterType_Monster = 3,
	ESolarCharacterType_MAX = 4
};

// Object: Enum Solarland.ECharacterSoundOpt
enum class ECharacterSoundOpt : uint8_t {
	None = 0,
	Shield_Hit_1P = 1,
	Shield_Hit_3P = 2,
	Shield_Broken_1P = 3,
	Shield_Broken_3P = 4,
	Vehicle_Speedboard_1P = 5,
	Body_Hit_With_Bullet_Common_1P = 6,
	Body_Hit_By_Bullet_Common_1P = 7,
	Body_Hit_With_Punch_Common_1P = 8,
	Body_Hit_By_Punch_Common_1P = 9,
	Headshot_1P = 10,
	Headshot_Kill_UI = 11,
	Shot_Down_UI = 12,
	Shot_Down_1P = 13,
	Shot_Down_3P = 14,
	Shot_Down_3P_Enemy = 15,
	Death_UI = 16,
	Death_1P = 17,
	Death_3P = 18,
	Airborne_Fall_Start_1P = 19,
	Water_Fall_1P = 20,
	Water_Fall_3P = 21,
	Water_Fall_3P_Enemy = 22,
	Squat_1P = 23,
	Squat_3P = 24,
	Squat_3P_Enemy = 25,
	Stop_Climb_1P = 26,
	Stop_Climb_3P = 27,
	Stop_Climb_3P_Enemy = 28,
	Loop_Knapsack_Solar_Percent_1P = 29,
	Stop_Knapsack_Solar_Percent_1P = 30,
	Knapsack_Solar_Charging_Done_1P = 31,
	Knapsack_Solar_On_1P = 32,
	Knapsack_Solar_Off_1P = 33,
	Sniper_B01_Skill_On_1P = 34,
	Sniper_B01_Skill_Off_1P = 35,
	B9A04_Skill_Loop_1P = 36,
	B9A04_Skill_Loop_3P = 37,
	B9A04_Skill_Loop_3P_Enemy = 38,
	B9A04_Skill_Loop_End_1P = 39,
	B9A04_Skill_Loop_End_3P = 40,
	B9A04_Skill_Loop_End_3P_Enemy = 41,
	Knapsack_Landing_1P = 42,
	Knapsack_Landing_3P = 43,
	Knapsack_Landing_3P_Enemy = 44,
	Knapsack_Fly_Water_1P = 45,
	Knapsack_Fly_Water_3P = 46,
	Knapsack_Fly_Water_3P_Enemy = 47,
	Play_Shield_OneSet_1P = 48,
	Play_Shield_OneSet_3P = 49,
	Play_Shield_OneSet_3P_Enemy = 50,
	Play_Shield_Charging_1P = 51,
	Play_Shield_Multi_Charging_1P = 52,
	Play_Shield_Charging_3P = 53,
	Play_Shield_Charging_3P_Enemy = 54,
	Play_Shield_Charged_1P = 55,
	Play_Shield_Charged_3P = 56,
	Play_Shield_Charged_3P_Enemy = 57,
	Play_Shield_Charge_To_Max_1P = 58,
	Play_Shield_Charge_To_Max_3P = 59,
	Play_Shield_Charge_To_Max_3P_Enemy = 60,
	Play_Shield_Charge_Break_1P = 61,
	Play_Shield_Charge_Break_3P = 62,
	Play_Shield_Charge_Break_3P_Enemy = 63,
	Play_Hit_By_EMP_1P = 64,
	Play_Hit_By_EMP_3P = 65,
	Play_Hit_By_EMP_3P_Enemy = 66,
	Stop_Hit_By_EMP_1P = 67,
	Stop_Hit_By_EMP_3P = 68,
	Stop_Hit_By_EMP_3P_Enemy = 69,
	Play_Monster_Appear = 70,
	Play_Monster_Die = 71,
	Play_Heal_Wrap_1P = 72,
	Play_Heal_Wrap_3P = 73,
	Play_Heal_Wrap_3P_Enemy = 74,
	Stop_Heal_Wrap_1P = 75,
	Stop_Heal_Wrap_3P = 76,
	Stop_Heal_Wrap_3P_Enemy = 77,
	Play_Heal_Wrap_Cancel_1P = 78,
	Play_Heal_Wrap_Cancel_3P = 79,
	Play_Heal_Wrap_Cancel_3P_Enemy = 80,
	Play_Heal_Wrap_Complete_1P = 81,
	Play_Heal_Wrap_Complete_3P = 82,
	Play_Heal_Wrap_Complete_3P_Enemy = 83,
	Stop_Shield_Charging_1P = 84,
	Stop_Shield_Charging_3P = 85,
	Stop_Shield_Charging_3P_Enemy = 86,
	Mark_Select_Dial_UI = 87,
	Mark_Select_Pin_UI = 88,
	Mark_Select_Cancel_UI = 89,
	Mark_Select_Common_UI = 90,
	Mark_Danger_UI = 91,
	Play_Skill_Fast_Reload = 92,
	Play_char_skill_passive_targetlock = 93,
	Max = 94
};

// Object: Enum Solarland.EItemSource
enum class EItemSource : uint8_t {
	None = 0,
	Consumables = 1,
	GeneralSlot = 2,
	Weapon = 3,
	EItemSource_MAX = 4
};

// Object: Enum Solarland.EItemQualityType
enum class EItemQualityType : uint8_t {
	None = 0,
	White = 1,
	Green = 2,
	Blue = 3,
	Purple = 4,
	Orange = 5,
	Red = 6,
	EItemQualityType_MAX = 7
};

// Object: Enum Solarland.EShieldUpgradeInteractAckType
enum class EShieldUpgradeInteractAckType : uint8_t {
	Success = 0,
	ItemReachLimit = 1,
	AlreadyInteracted = 2,
	SuccessWithReconnect = 3,
	InteractedByTeammate = 4,
	EShieldUpgradeInteractAckType_MAX = 5
};

// Object: Enum Solarland.EShieldCancelRechargeReason
enum class EShieldCancelRechargeReason : uint8_t {
	None = 0,
	StopAutoRecharge = 1,
	EShieldCancelRechargeReason_MAX = 2
};

// Object: Enum Solarland.ECancelRespawnDeviceReason
enum class ECancelRespawnDeviceReason : uint8_t {
	OutOfRange = 0,
	CharacterDead = 1,
	AbilityIterupted = 2,
	NoNeedRevive = 3,
	IsInUse = 4,
	ECancelRespawnDeviceReason_MAX = 5
};

// Object: Enum Solarland.EWeaponShootPattern
enum class EWeaponShootPattern : uint8_t {
	Normal = 0,
	Single = 1,
	Burst = 2,
	Bolt = 3,
	EWeaponShootPattern_MAX = 4
};

// Object: Enum Solarland.ESolarHitType
enum class ESolarHitType : uint8_t {
	None = 0,
	Character_Hit = 1,
	Character_Kill = 2,
	Character_BreakArmor = 3,
	Character_BreakShield = 4,
	Character_PendingKill = 5,
	Character_Headshot = 6,
	Character_HitShield = 7,
	Character_HitArmor = 8,
	Character_HitDown = 9,
	Character_HeadshotKill = 10,
	Character_HeadshotDown = 11,
	Vehicle_Hit = 51,
	Vehicle_HitWeakness = 52,
	ESolarHitType_MAX = 53
};

// Object: Enum Solarland.EShieldRechargeState
enum class EShieldRechargeState : uint8_t {
	AutoRecharge = 0,
	ManualRecharge = 1,
	None = 2,
	EShieldRechargeState_MAX = 3
};

// Object: Enum Solarland.EItemChangeType
enum class EItemChangeType : uint8_t {
	Default = 0,
	PickUp = 1,
	Drop = 2,
	EItemChangeType_MAX = 3
};

// Object: Enum Solarland.ERiftReportType
enum class ERiftReportType : uint8_t {
	NormalVolume = 0,
	GuaranteeVolume = 1,
	ZLimit = 2,
	ERiftReportType_MAX = 3
};

// Object: Enum Solarland.ECustomJumpType
enum class ECustomJumpType : uint8_t {
	None = 0,
	Jump = 1,
	Launch = 2,
	ECustomJumpType_MAX = 3
};

// Object: Enum Solarland.EDriveState
enum class EDriveState : uint8_t {
	None = 0,
	Driver = 1,
	Passenger = 2,
	EDriveState_MAX = 3
};

// Object: Enum Solarland.ESpecAnimInstType
enum class ESpecAnimInstType : uint8_t {
	Base = 0,
	Vehicle = 1,
	OneHandThrow = 2,
	KeepFiring = 3,
	Gatling = 4,
	CardsThrow = 5,
	DuckRolling = 6,
	InvisibleZone = 7,
	GrapplingHook = 8,
	ArrowRain = 9,
	BurstDagger = 10,
	ThunderFlash = 11,
	SmokeDevil = 12,
	ChargeCannon = 13,
	TrapMine = 14,
	HotWheels = 15,
	SlitheringDragon = 16,
	SummonRex = 17,
	ShieldCreator = 18,
	GenericOneHandThrow = 19,
	NormalSummon = 20,
	HellStrike = 21,
	ESpecAnimInstType_MAX = 22
};

// Object: Enum Solarland.ERoleSkillStatus
enum class ERoleSkillStatus : uint8_t {
	None = 0,
	Normal = 1,
	Active = 2,
	InCost = 4,
	InCD = 8,
	Forbidden = 16,
	Disable = 32,
	ERoleSkillStatus_MAX = 33
};

// Object: Enum Solarland.EVelocityStatus
enum class EVelocityStatus : uint8_t {
	Any = 0,
	Stationary = 1,
	Moving = 2,
	EVelocityStatus_MAX = 3
};

// Object: Enum Solarland.EHitTraceType
enum class EHitTraceType : uint8_t {
	None = 0,
	Default = 1,
	Shield = 2,
	Vehicle = 3,
	NezhaHitShield = 4,
	EHitTraceType_MAX = 5
};

// Object: Enum Solarland.EHitSoundTargetType
enum class EHitSoundTargetType : uint8_t {
	Default = 0,
	CharacterBody = 1,
	CharacterHead = 2,
	CharacterShieldBody = 3,
	CharacterShieldHead = 4,
	CharacterHitDown = 5,
	CharacterKill = 6,
	CharacterKill2 = 7,
	Vehicle = 8,
	VehicleWeakPoint = 9,
	SummonItemSolid = 10,
	SummonItemVirtual = 11,
	SummonBuddy = 12,
	EHitSoundTargetType_MAX = 13
};

// Object: Enum Solarland.EHitSoundSourceType
enum class EHitSoundSourceType : uint8_t {
	Default = 0,
	Weapon = 1,
	Melee = 2,
	Skill = 3,
	VehicleWeapon = 4,
	VehicleSkill = 5,
	VehicleHit = 6,
	Poison = 7,
	AirDrop = 8,
	Bomb = 9,
	EHitSoundSourceType_MAX = 10
};

// Object: Enum Solarland.EShieldWidgetState
enum class EShieldWidgetState : uint8_t {
	None = 0,
	PreAdd = 1,
	DoAdd = 2,
	CancelAdd = 3,
	DoSub = 4,
	EShieldWidgetState_MAX = 5
};

// Object: Enum Solarland.EEnterBattleType
enum class EEnterBattleType : uint8_t {
	OnHit = 0,
	OnWeaponFire = 1,
	NotEnter = 2,
	EEnterBattleType_MAX = 3
};

// Object: Enum Solarland.EJetFlyType
enum class EJetFlyType : uint8_t {
	None = 0,
	VerticalJetFly = 1,
	HorizontalJetFly = 2,
	CustomJetFly = 3,
	TemporaryVerticalJetFly = 4,
	TemporaryHorizontalJetFly = 5,
	EJetFlyType_MAX = 6
};

// Object: Enum Solarland.EShieldState
enum class EShieldState : uint8_t {
	NONE = 0,
	SPAWN = 1,
	NORMAL = 2,
	RECHARGE = 3,
	BREAK = 4,
	PILE = 5,
	MAX = 6
};

// Object: Enum Solarland.ESingleCruiseState
enum class ESingleCruiseState : uint8_t {
	NONE = 0,
	Fly = 1,
	RequestParachute = 2,
	Parachute = 3,
	ESingleCruiseState_MAX = 4
};

// Object: Enum Solarland.ESolarTreatmentState
enum class ESolarTreatmentState : uint8_t {
	None = 0,
	Treating = 1,
	End = 2,
	ESolarTreatmentState_MAX = 3
};

// Object: Enum Solarland.EZiplineInteractState
enum class EZiplineInteractState : uint8_t {
	None = 0,
	CanGetOn = 1,
	CanGetOff = 2,
	EZiplineInteractState_MAX = 3
};

// Object: Enum Solarland.EShieldSoundType
enum class EShieldSoundType : uint8_t {
	StartRecharge = 0,
	Charging = 1,
	Charged = 2,
	ChargedToMax = 3,
	ChargeBreak = 4,
	ShieldHitted = 5,
	ShieldBroken = 6,
	StopRecharge = 7,
	MultiCharging = 8,
	EShieldSoundType_MAX = 9
};

// Object: Enum Solarland.ETreatmentSoundType
enum class ETreatmentSoundType : uint8_t {
	Healing = 0,
	Cancel = 1,
	StopHealing = 2,
	Completed = 3,
	ETreatmentSoundType_MAX = 4
};

// Object: Enum Solarland.EVMInteractFace
enum class EVMInteractFace : uint8_t {
	None = 0,
	Forward = 1,
	Backward = 2,
	Left = 3,
	Right = 4,
	EVMInteractFace_MAX = 5
};

// Object: Enum Solarland.EIdleTurnType
enum class EIdleTurnType : uint8_t {
	Turn_Idle = 0,
	Turn_Left = 1,
	Turn_Right = 2,
	Turn_MAX = 3
};

// Object: Enum Solarland.ETreasureBoxState
enum class ETreasureBoxState : uint8_t {
	None = 0,
	Close = 1,
	Open = 2,
	ETreasureBoxState_MAX = 3
};

// Object: Enum Solarland.EDoorOpenType
enum class EDoorOpenType : uint8_t {
	FButton = 0,
	HitLatch = 1,
	AutoOpen = 2,
	Combat = 3,
	EDoorOpenType_MAX = 4
};

// Object: Enum Solarland.EWallRunState
enum class EWallRunState : uint8_t {
	WallRunning = 0,
	Success = 1,
	Cancel = 2,
	EWallRunState_MAX = 3
};

// Object: Enum Solarland.EHumanCannonMoveState
enum class EHumanCannonMoveState : uint8_t {
	None = 0,
	Prep = 1,
	Ascending = 2,
	Descending = 3,
	Landing = 4,
	EHumanCannonMoveState_MAX = 5
};

// Object: Enum Solarland.EZiplineSide
enum class EZiplineSide : uint8_t {
	None = 0,
	Cable = 1,
	A = 2,
	B = 3,
	EZiplineSide_MAX = 4
};

// Object: Enum Solarland.EZiplineMoveState
enum class EZiplineMoveState : uint8_t {
	None = 0,
	PreStart = 1,
	OnZipline = 2,
	EZiplineMoveState_MAX = 3
};

// Object: Enum Solarland.ESkillAnimRightHandType
enum class ESkillAnimRightHandType : uint8_t {
	Default = 0,
	Card = 1,
	ESkillAnimRightHandType_MAX = 2
};

// Object: Enum Solarland.ESkillAnimType
enum class ESkillAnimType : uint8_t {
	None = 0,
	SkillWithoutAnim = 1,
	OneHandThrow = 2,
	DoubleHandsThrow = 3,
	KeepFiring = 4,
	Gatling = 5,
	CardsThrow = 6,
	DuckRolling = 7,
	InvisibleZone = 8,
	GrapplingHook = 9,
	ArrowRain = 10,
	BurstDagger = 11,
	ThunderFlash = 12,
	SmokeDevil = 13,
	ChargeCannon = 14,
	TrapMine = 15,
	HotWheels = 16,
	SummonRex = 17,
	ShieldCreator = 18,
	GenericOneHandThrow = 19,
	NormalSummon = 20,
	HellStrike = 21,
	ESkillAnimType_MAX = 22
};

// Object: Enum Solarland.EBGMInBattle
enum class EBGMInBattle : uint8_t {
	None = 0,
	Curise = 1,
	Skydiving = 2,
	Land = 3,
	End = 4,
	EBGMInBattle_MAX = 5
};

// Object: Enum Solarland.EJetFlyAnimType
enum class EJetFlyAnimType : uint8_t {
	Default = 0,
	HotWheelsNormalDash = 1,
	HotWheelsSuperDash = 2,
	EJetFlyAnimType_MAX = 3
};

// Object: Enum Solarland.EShieldSoundEventType
enum class EShieldSoundEventType : uint8_t {
	Type_1P = 0,
	Type_3P = 1,
	Type_3P_Enemy = 2,
	Type_MAX = 3
};

// Object: Enum Solarland.ERescueState
enum class ERescueState : uint8_t {
	EState_None = 0,
	EState_Dying = 1,
	EState_Rescuing = 2,
	EState_BeingRescue = 3,
	EState_MAX = 4
};

// Object: Enum Solarland.EFXJetType
enum class EFXJetType : uint8_t {
	JetDefault = 0,
	JetSingle = 1,
	JetLoop = 2,
	VerticalLaunch = 3,
	WallRun = 4,
	SlideTackle = 5,
	EFXJetType_MAX = 6
};

// Object: Enum Solarland.ECharacterBodyScaleType
enum class ECharacterBodyScaleType : uint8_t {
	None = 0,
	Woman = 1,
	Man = 2,
	DuckMan = 3,
	SmallWoman = 4,
	ECharacterBodyScaleType_MAX = 5
};

// Object: Enum Solarland.EPlayerResurrectType
enum class EPlayerResurrectType : uint8_t {
	NONE = 0,
	SelfResurrectionCoin = 1,
	RequestTeamResurrect = 2,
	RespawnDevice = 3,
	EPlayerResurrectType_MAX = 4
};

// Object: Enum Solarland.EResurrectType
enum class EResurrectType : uint8_t {
	DirectResurrect = 0,
	ResurrectCapsule = 1,
	Parachute = 2,
	EResurrectType_MAX = 3
};

// Object: Enum Solarland.EResurrectionState
enum class EResurrectionState : uint8_t {
	Alive = 0,
	WaitingTeammatesHelp = 1,
	TimeOut = 2,
	AllTeammatesDied = 3,
	LeaveBattle = 4,
	EResurrectionState_MAX = 5
};

// Object: Enum Solarland.EMapDarkDataType
enum class EMapDarkDataType : uint8_t {
	POISONCIRCLE = 0,
	VICTORYSTATUE = 1,
	EMapDarkDataType_MAX = 2
};

// Object: Enum Solarland.EMapAirlineType
enum class EMapAirlineType : uint8_t {
	Default = 0,
	Capsule = 1,
	Airdrop = 2,
	EMapAirlineType_MAX = 3
};

// Object: Enum Solarland.EDirection
enum class EDirection : uint8_t {
	TOP = 0,
	BOTTOM = 1,
	LEFT = 2,
	RIGHT = 3,
	EDirection_MAX = 4
};

// Object: Enum Solarland.ESolarInputMode
enum class ESolarInputMode : uint8_t {
	GameOnly = 0,
	GameAndUI = 1,
	UIOnly = 2,
	ESolarInputMode_MAX = 3
};

// Object: Enum Solarland.EShotMomentFlag
enum class EShotMomentFlag : uint8_t {
	shotting = 0,
	hit = 1,
	killed = 2,
	invalid = 3,
	EShotMomentFlag_MAX = 4
};

// Object: Enum Solarland.EShotModeFlag
enum class EShotModeFlag : uint8_t {
	orgin = 0,
	d3d = 1,
	dwm = 2,
	nvfbc = 3,
	rand = 4,
	EShotModeFlag_MAX = 5
};

// Object: Enum Solarland.ESoundSyncType
enum class ESoundSyncType : uint8_t {
	Invalid = 0,
	OnlySelf = 1,
	OnlyTeammate = 2,
	OnlyEnemy = 4,
	SelfAndTeammate = 3,
	SelfAndEnemy = 5,
	TeammateAndEnemy = 6,
	All = 7,
	ESoundSyncType_MAX = 8
};

// Object: Enum Solarland.ESoundCharacterRelationship
enum class ESoundCharacterRelationship : uint8_t {
	Invalid = 0,
	Self = 1,
	Teammate = 2,
	Enemy = 3,
	ESoundCharacterRelationship_MAX = 4
};

// Object: Enum Solarland.ERespawnDeviceState
enum class ERespawnDeviceState : uint8_t {
	Available = 0,
	InUse = 1,
	Unavailable = 2,
	ERespawnDeviceState_MAX = 3
};

// Object: Enum Solarland.EInputSwitchType
enum class EInputSwitchType : uint8_t {
	ActionBinding = 0,
	ActionRemove = 1,
	AxisBinding = 2,
	AxisRemove = 3,
	EInputSwitchType_MAX = 4
};

// Object: Enum Solarland.ESolarIgnoreCollisionType
enum class ESolarIgnoreCollisionType : uint8_t {
	EnergyShield = 0,
	SummonItemCore = 1,
	SummonItem = 2,
	Character = 3,
	Vehicle = 4,
	UAV = 5,
	Water = 6,
	C4 = 7,
	AIDog = 8,
	SmokeActor = 9,
	ESolarIgnoreCollisionType_MAX = 10
};

// Object: Enum Solarland.EWidgetStackAction
enum class EWidgetStackAction : uint8_t {
	Push = 0,
	Pop = 1,
	EWidgetStackAction_MAX = 2
};

// Object: Enum Solarland.EUIPanelName
enum class EUIPanelName : uint8_t {
	None = 0,
	SolarBattleControll = 1,
	UI_DeathView = 2,
	WorldMarkPanel = 3,
	WeaponCrosshairPanel = 4,
	SolarBattle_Backpack = 5,
	Separate_Discarded_MultiItem = 6,
	BigMapUMG = 7,
	HUD_CustomizedNotice = 8,
	UI_Settings = 9,
	UI_Setting_ExitPanel_Desktop = 10,
	UI_OB_Root = 11,
	UI_OB_GlobalControl = 12,
	UI_OB_BigMap = 13,
	UI_OB_Settlement = 14,
	UI_OB_Settlement_InputMask = 15,
	UI_OB_HeadInfo = 16,
	UI_OB_ShortKeyboard = 17,
	UI_OpeningShow = 18,
	UI_Eliminate = 19,
	UI_Skill_Scan = 20,
	UI_RoleSkillPanel = 21,
	UI_HeroPick = 22,
	UI_HeroPick_Solo = 23,
	UI_HeroPick_BattleGround = 24,
	JobEffectDetailPanel = 25,
	UI_BuffEffectScreenPanel = 26,
	UI_TestCustomPanel = 27,
	Solarland_DevDebugUI_Widget = 28,
	UI_Highlight_Overview = 29,
	UI_BattleGround_End = 30,
	UI_HUD_Teammate = 31,
	UI_HUD_Talent = 32,
	UI_HUD_HumanCannonState = 33,
	UI_HUD_BuddyInfo = 34,
	EUIPanelName_MAX = 35
};

// Object: Enum Solarland.EWidgetBackKeyType
enum class EWidgetBackKeyType : uint8_t {
	Invalid = 0,
	FromKey = 1,
	FromClose = 2,
	EWidgetBackKeyType_MAX = 3
};

// Object: Enum Solarland.EWidgetLayerLevel
enum class EWidgetLayerLevel : uint8_t {
	NormalWidget = 0,
	SameLevelCacheWidget = 1,
	SameLevelReplaceWidget = 2,
	CloseAllBackKeyWidget = 3,
	CloseAllBackKeyAndNormalWidget = 4,
	EWidgetLayerLevel_MAX = 5
};

// Object: Enum Solarland.EWidgetScope
enum class EWidgetScope : uint8_t {
	World = 0,
	Global = 1,
	EWidgetScope_MAX = 2
};

// Object: Enum Solarland.EUIUserWidgetFlags
enum class EUIUserWidgetFlags : uint8_t {
	None = 0,
	HideAllLtLayer = 1,
	EnableWidgetHide = 2,
	EUIUserWidgetFlags_MAX = 3
};

// Object: Enum Solarland.EInputCapture
enum class EInputCapture : uint8_t {
	EIC_None = 0,
	EIC_Start = 1,
	EIC_End = 2,
	EIC_Move = 4,
	EIC_Transient = 3,
	EIC_All = 7,
	EIC_MAX = 8
};

// Object: Enum Solarland.ECustomNoticeColor
enum class ECustomNoticeColor : uint8_t {
	None = 0,
	White = 1,
	Red = 2,
	Green = 3,
	Blue = 4,
	Yellow = 5,
	ECustomNoticeColor_MAX = 6
};

// Object: Enum Solarland.ECustomNoticeType
enum class ECustomNoticeType : uint8_t {
	SmallNotice = 0,
	MediumNotice = 1,
	BigNotice = 2,
	KillEffectNotice = 3,
	GlobalKillNotice = 4,
	LocalKillNotice = 5,
	TaskNotice = 6,
	ExpNotice = 7,
	ItemNotice = 8,
	CustomPosNotice = 9,
	ECustomNoticeType_MAX = 10
};

// Object: Enum Solarland.EJetFlyForbiddenType
enum class EJetFlyForbiddenType : uint8_t {
	Water = 0,
	Climb = 1,
	EJetFlyForbiddenType_MAX = 2
};

// Object: Enum Solarland.ESolarITemHUDStyle
enum class ESolarITemHUDStyle : uint8_t {
	Spread = 0,
	Wheel = 1,
	ESolarITemHUDStyle_MAX = 2
};

// Object: Enum Solarland.ECountDownState
enum class ECountDownState : uint8_t {
	CD_Normal = 0,
	CD_Buff = 1,
	CD_MAX = 2
};

// Object: Enum Solarland.EWorldMarkOperationBottomHalfStyle
enum class EWorldMarkOperationBottomHalfStyle : uint8_t {
	None = 0,
	OnlyShowRichText = 1,
	RichTextAndIcon = 2,
	RichTextAndExtraInfo = 3,
	EWorldMarkOperationBottomHalfStyle_MAX = 4
};

// Object: Enum Solarland.EWorldMarkOperationUpperHalfStyle
enum class EWorldMarkOperationUpperHalfStyle : uint8_t {
	None = 0,
	ShowInput = 1,
	ShowRichText = 2,
	EWorldMarkOperationUpperHalfStyle_MAX = 3
};

// Object: Enum Solarland.EInputButton
enum class EInputButton : uint8_t {
	EInputButton_None = 0,
	EInputButton_Jump = 1,
	EInputButton_RechargeShield = 2,
	EInputButton_BigRechargeShield = 3,
	EInputButton_Crouch = 4,
	EInputButton_JetVertical = 5,
	EInputButton_JetHorizontal = 6,
	EInputButton_Fire = 7,
	EInputButton_LeftFire = 8,
	EInputButton_AltFire = 9,
	EInputButton_QuickAds = 10,
	EInputButton_CancelAction = 11,
	EInputButton_FreeLook = 12,
	EInputButton_Interact = 13,
	EInputButton_InteractAlternative = 14,
	EInputButton_Reload = 15,
	EInputButton_TogglePrimaryWeapon = 16,
	EInputButton_ToggleSecondaryWeapon = 17,
	EInputButton_ToggleTertiaryWeapon = 18,
	EInputButton_TogglePrimaryWeapon_Checkbox = 19,
	EInputButton_ToggleSecondaryWeapon_Checkbox = 20,
	EInputButton_ToggleTertiaryWeapon_Checkbox = 21,
	EInputButton_ToggleGunsight = 22,
	EInputButton_Gunsight = 23,
	EInputButton_SprintFreeOnPC = 24,
	EInputButton_SprintFreeOnMobile = 25,
	EInputButton_SprintLock = 26,
	EInputButton_Equip1 = 27,
	EInputButton_Equip2 = 28,
	EInputButton_Map = 29,
	EInputButton_Eject = 30,
	EInputButton_OutVehicle = 31,
	EInputButton_Backpack = 32,
	EInputButton_UseMedicine = 33,
	EInputButton_UseRecommendItem = 34,
	EInputButton_Pickup = 35,
	EInputButton_TogglePickup = 36,
	EInputButton_SwitchFireMode = 37,
	EInputButton_SwitchToSeat1 = 38,
	EInputButton_SwitchToSeat2 = 39,
	EInputButton_SwitchToSeat3 = 40,
	EInputButton_SwitchToSeat4 = 41,
	EInputButton_VehicleAbility1 = 42,
	EInputButton_VehicleAbility2 = 43,
	EInputButton_RoleSkillSuper = 44,
	EInputButton_RoleSkillTactical = 45,
	EInputButton_ShieldUpgrade = 46,
	EInputButton_ShieldUpgradeCancel = 47,
	EInputButton_TogglePutAwayWeapon = 48,
	EInputButton_UseBandage = 49,
	EInputButton_Max = 50
};

// Object: Enum Solarland.EPickupItemType
enum class EPickupItemType : uint8_t {
	None = 0,
	Normal = 1,
	TreasureBox = 2,
	EPickupItemType_MAX = 3
};

// Object: Enum Solarland.EKillParamsCompressInfo
enum class EKillParamsCompressInfo : int32_t {
	Default = 0,
	bKillLeaderChange = 1,
	bKillLeaderShutDown = 2,
	bRevenge = 4,
	bShutDown = 8,
	bDown = 16,
	bClearTeam = 32,
	bKillDefender = 64,
	bKillerDead = 128,
	bHitHead = 256,
	bKillLeaderKill = 512,
	EKillParamsCompressInfo_MAX = 513
};

// Object: Enum Solarland.ESpectateReferToState
enum class ESpectateReferToState : uint8_t {
	Invalid = 0,
	Enter = 1,
	Change = 2,
	Exit = 3,
	ESpectateReferToState_MAX = 4
};

// Object: Enum Solarland.EVehicleInterationUIState
enum class EVehicleInterationUIState : uint8_t {
	None = 0,
	Repair = 1,
	Drive = 2,
	Passenger = 4,
	Backpacker = 8,
	EVehicleInterationUIState_MAX = 9
};

// Object: Enum Solarland.ETransformerType
enum class ETransformerType : uint8_t {
	Wheeled = 0,
	Legged = 1,
	Max = 2
};

// Object: Enum Solarland.EAIDogSignalState
enum class EAIDogSignalState : uint8_t {
	Signal_Normal = 0,
	Signal_Weak = 1,
	Signal_Lost = 2,
	Signal_MAX = 3
};

// Object: Enum Solarland.EAlertDirection
enum class EAlertDirection : uint8_t {
	Forward = 0,
	Backward = 1,
	Left = 2,
	Right = 3,
	EAlertDirection_MAX = 4
};

// Object: Enum Solarland.EWSCurWeaponUpdateType
enum class EWSCurWeaponUpdateType : uint8_t {
	Switch = 0,
	PartUpdate = 1,
	EWSCurWeaponUpdateType_MAX = 2
};

// Object: Enum Solarland.EVehicleClass
enum class EVehicleClass : uint8_t {
	All = 0,
	Wheeled = 1,
	Legged = 2,
	Hover = 3,
	EVehicleClass_MAX = 4
};

// Object: Enum Solarland.EWeaponUIType
enum class EWeaponUIType : uint8_t {
	All = 0,
	AssualtRifle = 1,
	Submachinegun = 2,
	Shotgun = 3,
	Sniper = 4,
	Others = 5,
	EWeaponUIType_MAX = 6
};

// Object: Enum Solarland.ECustomParamValueType
enum class ECustomParamValueType : uint8_t {
	None = 0,
	Bool = 1,
	Int = 2,
	Float = 3,
	Percent = 4,
	Enum_S = 5,
	Enum_M = 6,
	AvailableWeapons = 7,
	AvailableVehicles = 8,
	ECustomParamValueType_MAX = 9
};

// Object: Enum Solarland.ERemovedReasonType
enum class ERemovedReasonType : uint8_t {
	None = 0,
	TimeOut = 1,
	Abandoned = 2,
	OwnerKick = 3,
	NotEnough = 4,
	ServerKick = 5,
	ERemovedReasonType_MAX = 6
};

// Object: Enum Solarland.EUIRoot
enum class EUIRoot : uint8_t {
	None = 0,
	UnderBattleRoot = 1,
	BattleRoot = 2,
	BattleRootGuide = 3,
	MiddleRoot = 4,
	CommonRoot = 5,
	Map = 6,
	BattleNoticeRoot = 7,
	Guide = 8,
	PopRoot = 9,
	TipsRoot = 10,
	NoticeRoot = 11,
	Loading = 12,
	Reconnecting = 13,
	ExternalToolsRoot = 255,
	EUIRoot_MAX = 256
};

// Object: Enum Solarland.EDeathType
enum class EDeathType : uint8_t {
	Dying = 0,
	Death = 1,
	EDeathType_MAX = 2
};

// Object: Enum Solarland.ESCMPlayerOutType
enum class ESCMPlayerOutType : uint8_t {
	None = 0,
	SelfLogout = 1,
	BattleEnd = 2,
	SelfEnd = 3,
	OfflineEnd = 4,
	Cheating = 5,
	Abnormal = 6,
	Course = 7,
	ESCMPlayerOutType_MAX = 8
};

// Object: Enum Solarland.ESCMPlayerState
enum class ESCMPlayerState : uint8_t {
	None = 0,
	NotJoin = 2,
	InBattle = 4,
	Suspend = 8,
	BattleEnd = 16,
	LeaveBattle = 32,
	ESCMPlayerState_MAX = 33
};

// Object: Enum Solarland.ESCMDataType
enum class ESCMDataType : uint8_t {
	None = 0,
	Byte = 1,
	Int = 2,
	Float = 3,
	Bool = 4,
	FVector = 5,
	FString = 6,
	ESCMDataType_MAX = 7
};

// Object: Enum Solarland.ETaskPage
enum class ETaskPage : uint8_t {
	TPNone = 0,
	TPDaily = 1,
	TPGrow = 2,
	TPHomeDaily = 3,
	TPSeason = 4,
	TPPassDaily = 5,
	TPPassWelfare = 6,
	TPPassWeek = 7,
	TPMonthlyDaily = 8,
	TPMonthlyWeek = 9,
	TPHalMonth = 10,
	TPWeekChallenge = 11,
	TPShareCodeDaily = 12,
	TPShareCodePersonal = 13,
	TPShareCodeFriend = 14,
	TPCollectRedeem = 15,
	TPEventPassWeek = 20,
	ETaskPage_MAX = 21
};

// Object: Enum Solarland.ECharacterEjectState
enum class ECharacterEjectState : uint8_t {
	Eject = 0,
	Land = 1,
	ECharacterEjectState_MAX = 2
};

// Object: Enum Solarland.ECharacterHealthState
enum class ECharacterHealthState : uint8_t {
	Health = 0,
	Dying = 1,
	Death = 2,
	ECharacterHealthState_MAX = 3
};

// Object: Enum Solarland.ESCMPlayerGameRole
enum class ESCMPlayerGameRole : uint8_t {
	StandBy = 0,
	OBPlayer = 1,
	Player = 2,
	Spectator = 3,
	ESCMPlayerGameRole_MAX = 4
};

// Object: Enum Solarland.ESCMPlayerType
enum class ESCMPlayerType : uint8_t {
	None = 0,
	Player = 1,
	BotAI = 2,
	Monster = 3,
	ESCMPlayerType_MAX = 4
};

// Object: Enum Solarland.EPersonalScoreType
enum class EPersonalScoreType : uint8_t {
	None = 0,
	Kill = 1,
	Assist = 2,
	OccupyingPerSec = 3,
	Capture = 4,
	Release = 5,
	EPersonalScoreType_MAX = 6
};

// Object: Enum Solarland.EBattlegroundPlayerStatus
enum class EBattlegroundPlayerStatus : uint8_t {
	WaitForBattle = 0,
	Battle = 1,
	WaitForRebirth = 2,
	Deploying = 3,
	EBattlegroundPlayerStatus_MAX = 4
};

// Object: Enum Solarland.EDeploymentType
enum class EDeploymentType : uint8_t {
	None = 0,
	BlueHome = 1,
	RedHome = 2,
	A = 3,
	B = 4,
	C = 5,
	D = 6,
	EDeploymentType_MAX = 7
};

// Object: Enum Solarland.ESolarFrameRateLevel
enum class ESolarFrameRateLevel : uint8_t {
	ESFRL_NONE = 0,
	ESFRL_Low = 1,
	ESFRL_Mid = 2,
	ESFRL_High = 3,
	ESFRL_HighEnd = 4,
	ESFRL_EXTREME = 5,
	ESFRL_MAX = 6
};

// Object: Enum Solarland.ESolarColorTheme
enum class ESolarColorTheme : uint8_t {
	ESCT_Default = 0,
	ESCT_Bright = 1,
	ESCT_Soft = 2,
	ESCT_Cold = 3,
	ESCT_MAX = 4
};

// Object: Enum Solarland.ESolarGraphicsQualityLevel
enum class ESolarGraphicsQualityLevel : uint8_t {
	ESGQL_Invalid = 0,
	ESGQL_Level1 = 1,
	ESGQL_Level2 = 2,
	ESGQL_Level3 = 3,
	ESGQL_Level4 = 4,
	ESGQL_Level5 = 5,
	ESGQL_Level6 = 6,
	ESGQL_Level7 = 7,
	ESGQL_VALUE_MIN = 1,
	ESGQL_VALUE_MAX = 7,
	ESGQL_MAX = 8
};

// Object: Enum Solarland.ESolarVaultSensitivityMode
enum class ESolarVaultSensitivityMode : uint8_t {
	Low = 0,
	Medium = 1,
	High = 2,
	Custom = 3,
	ESolarVaultSensitivityMode_MAX = 4
};

// Object: Enum Solarland.EBasicSettingBool
enum class EBasicSettingBool : uint8_t {
	NotInit = 0,
	Off = 1,
	On = 2,
	EBasicSettingBool_MAX = 3
};

// Object: Enum Solarland.EShowInputTipsType
enum class EShowInputTipsType : uint8_t {
	HideAll = 0,
	ShowBtn = 1,
	ShowAll = 2,
	EShowInputTipsType_MAX = 3
};

// Object: Enum Solarland.ESolarEnhanceOutlineMode
enum class ESolarEnhanceOutlineMode : uint8_t {
	ExtraOutline = 0,
	InnerGlow = 1,
	OuterGlow = 2,
	ESolarEnhanceOutlineMode_MAX = 3
};

// Object: Enum Solarland.ESolarSkillTriggerMode
enum class ESolarSkillTriggerMode : uint8_t {
	OnRelease = 0,
	DoubleClick = 1,
	ESolarSkillTriggerMode_MAX = 2
};

// Object: Enum Solarland.ESolarDamageTextDisplayModeType
enum class ESolarDamageTextDisplayModeType : uint8_t {
	DamageTextDisplayMode_Off = 0,
	DamageTextDisplayMode_Stacked = 1,
	DamageTextDisplayMode_Floating = 2,
	DamageTextDisplayMode_Combined = 3,
	DamageTextDisplayMode_MAX = 4
};

// Object: Enum Solarland.ESolarGyroscopeChooseType
enum class ESolarGyroscopeChooseType : uint8_t {
	DefaultGyroscope = 0,
	ALWAYS = 1,
	FOCUS = 2,
	NEVER = 3,
	ESolarGyroscopeChooseType_MAX = 4
};

// Object: Enum Solarland.ESolarSupportLanguages
enum class ESolarSupportLanguages : uint8_t {
	DefaultLanguage = 0,
	SimplifiedChinese = 1,
	TraditionalChinese = 2,
	Arabic = 3,
	German = 4,
	English = 5,
	Spanish = 6,
	French = 7,
	Hindi = 8,
	Indonesian = 9,
	Italian = 10,
	Japanese = 11,
	Korean = 12,
	Malay = 13,
	Polish = 14,
	Portuguese = 15,
	Russian = 16,
	Thai = 17,
	Turkish = 18,
	Vietnamese = 19,
	Tagalog = 20,
	PO = 253,
	OP = 254,
	ESolarSupportLanguages_MAX = 255
};

// Object: Enum Solarland.ESolarChatOperatorType
enum class ESolarChatOperatorType : uint8_t {
	All = 0,
	Team = 1,
	Off = 2,
	ESolarChatOperatorType_MAX = 3
};

// Object: Enum Solarland.EWheeledVehicleDriveUserType
enum class EWheeledVehicleDriveUserType : uint8_t {
	DirectionalInput = 0,
	SteeringInput = 1,
	JoyStickInput = 2,
	EWheeledVehicleDriveUserType_MAX = 3
};

// Object: Enum Solarland.ECrosshairBulletVisibilityMode
enum class ECrosshairBulletVisibilityMode : uint8_t {
	Off = 0,
	OnlyHipFire = 1,
	Always = 2,
	ECrosshairBulletVisibilityMode_MAX = 3
};

// Object: Enum Solarland.ESolarSoundVisualMode
enum class ESolarSoundVisualMode : uint8_t {
	Close = 0,
	Tile = 1,
	Stretch = 2,
	Around = 3,
	ESolarSoundVisualMode_MAX = 4
};

// Object: Enum Solarland.ESolarBattleGroundChatOperatorType
enum class ESolarBattleGroundChatOperatorType : uint8_t {
	All = 0,
	BattleGround = 1,
	Team = 2,
	Off = 3,
	ESolarBattleGroundChatOperatorType_MAX = 4
};

// Object: Enum Solarland.EOpenScopeMode
enum class EOpenScopeMode : uint8_t {
	Immediate = 0,
	Complete = 1,
	Gradual = 2,
	EOpenScopeMode_MAX = 3
};

// Object: Enum Solarland.ESolarSensitiveLevel
enum class ESolarSensitiveLevel : uint8_t {
	Low = 0,
	Medium = 1,
	High = 2,
	Custom = 3,
	ESolarSensitiveLevel_MAX = 4
};

// Object: Enum Solarland.ESolarTouchAccMode
enum class ESolarTouchAccMode : uint8_t {
	Velocity = 0,
	Constant = 1,
	ESolarTouchAccMode_MAX = 2
};

// Object: Enum Solarland.ESolarShakeMainType
enum class ESolarShakeMainType : uint8_t {
	OFF = 0,
	LOW = 1,
	MEDIUM = 2,
	HIGH = 3,
	ESolarShakeMainType_MAX = 4
};

// Object: Enum Solarland.ESolarAudioMode
enum class ESolarAudioMode : uint8_t {
	PushToTalk = 0,
	FreeToTalk = 1,
	ESolarAudioMode_MAX = 2
};

// Object: Enum Solarland.ESolarSoundQuality
enum class ESolarSoundQuality : uint8_t {
	NotInit = 0,
	Low = 1,
	High = 2,
	Ultra = 3,
	ESolarSoundQuality_MAX = 4
};

// Object: Enum Solarland.ESolarWeaponBreakReloadMode
enum class ESolarWeaponBreakReloadMode : uint8_t {
	Disable = 0,
	FirePress = 1,
	ReloadPress = 2,
	Mixed = 3,
	ESolarWeaponBreakReloadMode_MAX = 4
};

// Object: Enum Solarland.ESolarWeaponDoScopeMode
enum class ESolarWeaponDoScopeMode : uint8_t {
	Click = 0,
	Press = 1,
	Mixed = 2,
	ESolarWeaponDoScopeMode_MAX = 3
};

// Object: Enum Solarland.EConfigVersion
enum class EConfigVersion : uint8_t {
	BeforeCustomVersionWasAdded = 0,
	FixedCanAutoSteering = 1,
	FixedDefaultFOV = 2,
	FixedUseIndependentKeyInExpandedMode = 3,
	FixedDamageTextDisplayMode = 4,
	FixedIndependentKeySettings = 5,
	VersionPlusOne = 6,
	LatestVersion = 5,
	EConfigVersion_MAX = 7
};

// Object: Enum Solarland.ESolarWheelModeType
enum class ESolarWheelModeType : uint8_t {
	Default = 0,
	Click = 1,
	Release = 2,
	ESolarWheelModeType_MAX = 3
};

// Object: Enum Solarland.ESolarSprintModeType
enum class ESolarSprintModeType : uint8_t {
	Default = 0,
	Pressing = 1,
	Toggle = 2,
	Auto = 3,
	ESolarSprintModeType_MAX = 4
};

// Object: Enum Solarland.ESolarDeviceLevel
enum class ESolarDeviceLevel : uint8_t {
	ESDL_Invalid = 0,
	ESDL_Level1 = 1,
	ESDL_Level2 = 2,
	ESDL_Level3 = 3,
	ESDL_Level4 = 4,
	ESDL_Level5 = 5,
	ESDL_Level6 = 6,
	ESDL_Level7 = 7,
	ESDL_VALUE_MIN = 1,
	ESDL_VALUE_MAX = 7,
	ESDL_MAX = 8
};

// Object: Enum Solarland.EFileDownloadError
enum class EFileDownloadError : uint8_t {
	None = 0,
	ConnectFailed = 1,
	RequestHeadFailed = 2,
	CreateFileFailed = 3,
	DownloadFailed = 4,
	WriteFailed = 5,
	DeleteOldFailed = 6,
	MoveFailed = 7,
	HashCheckFailed = 8,
	EFileDownloadError_MAX = 9
};

// Object: Enum Solarland.EDownloadFailedStep
enum class EDownloadFailedStep : uint8_t {
	DownloadServerListFailed = 0,
	DownloadPakListFailed = 1,
	DownloadPakFileFailed = 2,
	MountPakFileFailed = 3,
	EDownloadFailedStep_MAX = 4
};

// Object: Enum Solarland.EBuffEffectTagType
enum class EBuffEffectTagType : uint8_t {
	None = 0,
	TopHalfPart = 1,
	BottomHalfPart = 2,
	TwoSidePart = 3,
	BorderPart = 4,
	FullPart = 5,
	EBuffEffectTagType_MAX = 6
};

// Object: Enum Solarland.ESolarTablesEnum_InputTriggerType
enum class ESolarTablesEnum_InputTriggerType : uint8_t {
	InputTriggerPressed = 0,
	InputTriggerTap = 1,
	InputTriggerDoubleTap = 2,
	InputTriggerHold = 3,
	_Count = 4,
	ESolarTablesEnum_MAX = 5
};

// Object: Enum Solarland.ESolarTablesEnum_InputActionType
enum class ESolarTablesEnum_InputActionType : uint8_t {
	Action = 0,
	Axis = 1,
	_Count = 2,
	ESolarTablesEnum_MAX = 3
};

// Object: Enum Solarland.ESpecialItemID
enum class ESpecialItemID : int32_t {
	NONE = 0,
	CARIRIDGE_BAG = 1040101,
	BANDAGE = 1040102,
	REVIVE_ITEM = 1160501,
	RADAR_SCANNER = 1080101,
	SHIELD_RECHARGER = 1120100,
	SHIELD_BIG_RECHARGER = 1120101,
	AMMO_SMG = 1030101,
	AMMO_RIFLE = 1030102,
	AMMO_SNIPER = 1030103,
	AMMO_SHOTGUN = 1030104,
	SHIELD_UPGRADE_MATERIAL = 148023,
	EXP_ITEM = 149022,
	EXP_ITEM2 = 149023,
	EXP_ITEM3 = 149024,
	TACTICAL_BOX = 1240001,
	TACTICAL_BOX_HIGH = 1240002,
	TACTICAL_BOX3 = 1240003,
	TACTICAL_BOX4 = 1240004,
	TACTICAL_BOX5 = 1240005,
	ESpecialItemID_MAX = 1240006
};

// Object: Enum Solarland.EPlayerNamePanelScale
enum class EPlayerNamePanelScale : uint8_t {
	ExtraSmallSize = 0,
	SmallSize = 1,
	DefaultSize = 2,
	LargeSize = 3,
	ExtraLargeSize = 4,
	EPlayerNamePanelScale_MAX = 5
};

// Object: Enum Solarland.EBattleOBHUDType
enum class EBattleOBHUDType : uint8_t {
	None = 0,
	SpectatePlayer = 1,
	FreeView = 2,
	FreeLookAt = 3,
	Director = 4,
	EBattleOBHUDType_MAX = 5
};

// Object: Enum Solarland.EOBPlayerHeadInfoWidgetStyle
enum class EOBPlayerHeadInfoWidgetStyle : uint8_t {
	NearMode = 0,
	MiddleMode = 1,
	FarMode = 2,
	MAX = 3
};

// Object: Enum Solarland.ESolarSummonSoundType
enum class ESolarSummonSoundType : uint8_t {
	SummonSoundType_1P = 0,
	SummonSoundType_3P = 1,
	SummonSoundType_3P_Enemy = 2,
	SummonSoundType_MAX = 3
};

// Object: Enum Solarland.OnLSDestroyStrategy
enum class OnLSDestroyStrategy : uint8_t {
	Custom = 0,
	SelfDestroy = 1,
	FreeFall = 2,
	OnLSDestroyStrategy_MAX = 3
};

// Object: Enum Solarland.OnLSModifiedStrategy
enum class OnLSModifiedStrategy : uint8_t {
	Custom = 0,
	UpdateHeight = 1,
	OnLSModifiedStrategy_MAX = 2
};

// Object: Enum Solarland.EForceMovementSource
enum class EForceMovementSource : uint8_t {
	E_BlackHole = 0,
	E_WindField = 1,
	E_Max = 2
};

// Object: Enum Solarland.EMoveMode
enum class EMoveMode : uint8_t {
	E_Stop = 0,
	E_Direction = 1,
	E_TargetPos = 2,
	E_MAX = 3
};

// Object: Enum Solarland.ETipsStyleType
enum class ETipsStyleType : uint8_t {
	None = 0,
	NormalItem = 1,
	PokeBall = 2,
	ETipsStyleType_MAX = 3
};

// Object: Enum Solarland.ETipsInputPreset
enum class ETipsInputPreset : uint8_t {
	None = 0,
	PokeBallActive = 1,
	PokeBallPassive = 2,
	Consumable = 3,
	Pickup = 4,
	Equipment = 5,
	ETipsInputPreset_MAX = 6
};

// Object: Enum Solarland.EWeaponPartType
enum class EWeaponPartType : uint8_t {
	Muzzle = 0,
	Scope = 1,
	Clip = 2,
	Grip = 3,
	GunStock = 4,
	Core = 5,
	MAX = 6
};

// Object: Enum Solarland.EImageURLDownloadState
enum class EImageURLDownloadState : uint8_t {
	NotStarted = 0,
	Processing = 1,
	Success = 2,
	Failed = 3,
	EImageURLDownloadState_MAX = 4
};

// Object: Enum Solarland.ECustomGameModeTypeForUI
enum class ECustomGameModeTypeForUI : uint8_t {
	Type_Default = 0,
	Type_Sabotage = 1,
	Type_MAX = 2
};

// Object: Enum Solarland.EShopWeaponUpgradeState
enum class EShopWeaponUpgradeState : uint8_t {
	Upgrade_None = 0,
	Upgrade_Enable = 1,
	Upgrade_Max = 2,
	Upgrade_NotEnoughEnergy = 3
};

// Object: Enum Solarland.EActionWheelOperateType
enum class EActionWheelOperateType : uint8_t {
	NeedClick = 0,
	AutoCommand = 1,
	EActionWheelOperateType_MAX = 2
};

// Object: Enum Solarland.EActionWheelCommandType
enum class EActionWheelCommandType : uint8_t {
	None = 0,
	UseItem = 1,
	WorldMark = 2,
	UseSticker = 3,
	PlayAnimation = 4,
	PlaySound = 5,
	CollectBuddy = 6,
	UseBuddyBall = 7,
	Max = 8
};

// Object: Enum Solarland.EActivationType
enum class EActivationType : uint8_t {
	None = 0,
	PlayerWeaponFire = 1,
	PlayerWeaponHit = 2,
	PlayerWeaponDown = 3,
	PlayerWeaponKill = 4,
	DriveVehicle = 5,
	VehicleWeaponFire = 6,
	VehicleWeaponHit = 7,
	VehicleWeaponDown = 8,
	VehicleWeaponKill = 9,
	SummonWeaponHit = 10,
	SummonWeaponDown = 11,
	SummonWeaponKill = 12,
	UseTacticalAbility = 13,
	TacticalAbilityHit = 14,
	TacticalAbilityDown = 15,
	TacticalAbilityKill = 16,
	UseUltimateAbility = 17,
	UltimateAbilityHit = 18,
	UltimateAbilityDown = 19,
	UltimateAbilityKill = 20,
	PlayerMelee = 21,
	PlayerMeleeHit = 22,
	PlayerMeleeDown = 23,
	PlayerMeleeKill = 24,
	EActivationType_MAX = 25
};

// Object: Enum Solarland.EActivationDamageSourceType
enum class EActivationDamageSourceType : uint8_t {
	None = 0,
	Weapon = 1,
	Vehicle = 2,
	SummonWeapon = 3,
	TacticalAbility = 4,
	UltimateAbility = 5,
	Melee = 6,
	EActivationDamageSourceType_MAX = 7
};

// Object: Enum Solarland.EActorMaterialChangeRebuildReason
enum class EActorMaterialChangeRebuildReason : uint8_t {
	OriginalMeshChanged = 0,
	MeshAddedOrRemoved = 1,
	EActorMaterialChangeRebuildReason_MAX = 2
};

// Object: Enum Solarland.EMultiplePassMaterialChangeCompatibilityMode
enum class EMultiplePassMaterialChangeCompatibilityMode : uint8_t {
	Compatible = 0,
	Incompatible = 1,
	CompatibleWithSpecifiedPriorityTags = 2,
	IncompatibleWithSpecifiedPriorityTags = 3,
	EMultiplePassMaterialChangeCompatibilityMode_MAX = 4
};

// Object: Enum Solarland.EMaterialChangeTextureOverrideMode
enum class EMaterialChangeTextureOverrideMode : uint8_t {
	None = 0,
	OverrideAllTextures = 1,
	OverrideSpecifiedTextures = 2,
	EMaterialChangeTextureOverrideMode_MAX = 3
};

// Object: Enum Solarland.EMaterialChangeConflictResolveStrategy
enum class EMaterialChangeConflictResolveStrategy : uint8_t {
	KeepAll = 0,
	KeepNew = 1,
	KeepOld = 2,
	EMaterialChangeConflictResolveStrategy_MAX = 3
};

// Object: Enum Solarland.EMaterialParameterTypeFlags
enum class EMaterialParameterTypeFlags : uint8_t {
	None = 0,
	Scaler = 1,
	Vector = 2,
	Texture = 4,
	Font = 8,
	AllWithoutFont = 7,
	All = 15,
	EMaterialParameterTypeFlags_MAX = 16
};

// Object: Enum Solarland.EMaterialParameterType2
enum class EMaterialParameterType2 : uint8_t {
	Scaler = 0,
	Vector = 1,
	Texture = 2,
	Font = 3,
	EMaterialParameterType2_MAX = 4
};

// Object: Enum Solarland.EMaterialChangeType
enum class EMaterialChangeType : uint8_t {
	Normal = 0,
	MultiplePass = 1,
	EMaterialChangeType_MAX = 2
};

// Object: Enum Solarland.EActorParticleEffectAttachOption
enum class EActorParticleEffectAttachOption : uint8_t {
	None = 0,
	AttachToActor = 1,
	AttachToMesh = 2,
	WorldLocation = 3,
	EActorParticleEffectAttachOption_MAX = 4
};

// Object: Enum Solarland.EOperator
enum class EOperator : uint8_t {
	IDLE = 0,
	ADD = 1,
	MINUS = 2,
	CANCEL = 3,
	EOperator_MAX = 4
};

// Object: Enum Solarland.EAIDogState
enum class EAIDogState : uint8_t {
	NotSummoned = 0,
	BeDestroyed = 1,
	Normal = 2,
	SignalWeak = 3,
	SignalLost = 4,
	EAIDogState_MAX = 5
};

// Object: Enum Solarland.EAIDogSkillState
enum class EAIDogSkillState : uint8_t {
	Skill_Lvl1 = 0,
	Skill_Lvl2 = 1,
	Skill_Lvl1_Buff = 2,
	Skill_Lvl2_Buff = 3,
	Skill_MAX = 4
};

// Object: Enum Solarland.EAIDogCombatState
enum class EAIDogCombatState : uint8_t {
	Suppressed = 0,
	Fire = 1,
	GoAhead = 2,
	Standby = 3,
	EAIDogCombatState_MAX = 4
};

// Object: Enum Solarland.EBulletTraceTargetType
enum class EBulletTraceTargetType : uint8_t {
	None = 0,
	Character = 1,
	Vehicle = 4,
	SummonItem = 8,
	EBulletTraceTargetType_MAX = 9
};

// Object: Enum Solarland.EBounceType
enum class EBounceType : uint8_t {
	NONE = 0,
	ONCE = 1,
	STICK = 2,
	MAX = 3
};

// Object: Enum Solarland.ETriggerType
enum class ETriggerType : uint8_t {
	KEY_DOWN = 0,
	KEY_UP = 1,
	KEY_HOLD = 2,
	MAX = 3
};

// Object: Enum Solarland.EHoldActionType
enum class EHoldActionType : uint8_t {
	HT_Charge = 0,
	HT_Projectile = 1,
	HT_None = 2,
	HT_MAX = 3
};

// Object: Enum Solarland.ETrajectoryType
enum class ETrajectoryType : uint8_t {
	LINE = 0,
	LINE_GRAVITY = 1,
	CURVE = 2,
	CANISTER = 3,
	BEAM = 4,
	Rocket = 5,
	VirtualBullet = 6,
	MAX = 7
};

// Object: Enum Solarland.EWeaponSkillChargedState
enum class EWeaponSkillChargedState : uint8_t {
	PREPARE = 0,
	START = 1,
	COMPLETECHARGE = 2,
	EXECUTE = 3,
	EWeaponSkillChargedState_MAX = 4
};

// Object: Enum Solarland.EFireMethodType
enum class EFireMethodType : uint8_t {
	BULLET = 0,
	SKILL = 1,
	SUMMONBULLET = 2,
	MAX = 3
};

// Object: Enum Solarland.ECostFireType
enum class ECostFireType : uint8_t {
	DESCRETE = 0,
	CONTINUOUS = 1,
	MAX = 2
};

// Object: Enum Solarland.EShootingSoundOpt
enum class EShootingSoundOpt : uint8_t {
	EShootingSound_SINGLE_1P = 0,
	EShootingSound_SINGLE_3P = 1,
	EShootingSound_SINGLE_3P_ENEMY = 2,
	EShootingSound_AUTO_1P = 3,
	EShootingSound_AUTO_3P = 4,
	EShootingSound_AUTO_3P_ENEMY = 5,
	EShootingSound_BURST_1P = 6,
	EShootingSound_BURST_3P = 7,
	EShootingSound_BURST_3P_ENEMY = 8,
	EShootingSound_FIRE_LAST_1P = 9,
	EShootingSound_FIRE_LAST_3P = 10,
	EShootingSound_SKILL_CAST_1P = 11,
	EShootingSound_SKILL_CAST_3P = 12,
	EShootingSound_LAND_COMMON_HIT_3P = 13,
	EShootingSound_SKILL_FX_START_1P = 14,
	EShootingSound_SKILL_FX_START_3P = 15,
	EShootingSound_SHIELD_HIT_1P = 16,
	EShootingSound_SHIELD_HIT_3P = 17,
	EShootingSound_SHIELD_BROKEN_1P = 18,
	EShootingSound_SHIELD_BROKEN_3P = 19,
	EShootingSound_BODY_HIT_1P = 20,
	EShootingSound_BODY_HIT_3P = 21,
	EShootingSound_FIRE_OVERLOAD_1P = 22,
	EShootingSound_FIRE_OVERLOAD_3P = 23,
	EShootingSound_Fly_Loop = 24,
	EShootingSound_Fly_Once = 25,
	EShootingSound_Vehicle_Gun_On = 26,
	EShootingSound_Vehicle_Gun_Off = 27,
	EShootingSound_Smoke_Loop = 28,
	EShootingSound_B9A04Skill = 29,
	EShootingSound_Reload_1P_2 = 30,
	EShootingSound_Reload_3P_2 = 31,
	EShootingSound_Reload_1P_3 = 32,
	EShootingSound_Reload_3P_3 = 33,
	EShootingSound_Reload_1P_4 = 34,
	EShootingSound_Reload_3P_4 = 35,
	EShootingSound_Bolt_1P = 36,
	EShootingSound_Bolt_3P = 37,
	EShootingSound_MAX = 38
};

// Object: Enum Solarland.EShootingOpt
enum class EShootingOpt : uint8_t {
	EShootingOpt_SINGLE = 0,
	EShootingOpt_AUTO = 1,
	EShootingOpt_BURST = 2,
	EShootingOpt_MAX = 3
};

// Object: Enum Solarland.EFootEffectType
enum class EFootEffectType : uint8_t {
	Effect_None = 0,
	Effect_Water = 1,
	Effect_MAX = 2
};

// Object: Enum Solarland.EPlaySoundGroupWithCooldownRoleType
enum class EPlaySoundGroupWithCooldownRoleType : uint8_t {
	All = 0,
	LocalPlayerOnly = 1,
	LocalOrSpectatingPlayer = 2,
	EPlaySoundGroupWithCooldownRoleType_MAX = 3
};

// Object: Enum Solarland.EAnimNotifyParticleParam
enum class EAnimNotifyParticleParam : uint8_t {
	None = 0,
	Color = 1,
	CampColor = 2,
	Scalar = 3,
	EAnimNotifyParticleParam_MAX = 4
};

// Object: Enum Solarland.EMaterialOwnerMeshType
enum class EMaterialOwnerMeshType : uint8_t {
	CharacterMesh = 0,
	OrnamentMesh = 1,
	EMaterialOwnerMeshType_MAX = 2
};

// Object: Enum Solarland.EWeaponMontageType
enum class EWeaponMontageType : uint8_t {
	Reload = 0,
	Reload_1Hand = 1,
	Reload_Tactical = 2,
	Reload_Tactical_1Hand = 3,
	Bolt = 4,
	Bolt_1Hand = 5,
	FirstEquip = 6,
	FirstEquip_1Hand = 7,
	EWeaponMontageType_MAX = 8
};

// Object: Enum Solarland.EMyAnyType
enum class EMyAnyType : uint8_t {
	Int32 = 0,
	Float = 1,
	Vector = 2,
	None = 3,
	EMyAnyType_MAX = 4
};

// Object: Enum Solarland.EExpressState
enum class EExpressState : uint8_t {
	None = 0,
	Idle = 1,
	Transfer = 2,
	End = 3,
	EExpressState_MAX = 4
};

// Object: Enum Solarland.EAutoChessGameType
enum class EAutoChessGameType : uint8_t {
	WaitStart = 0,
	Prepare = 1,
	Fighting = 2,
	Settlement = 3,
	GameOver = 4,
	EAutoChessGameType_MAX = 5
};

// Object: Enum Solarland.EAutoChessPrototypeGameType
enum class EAutoChessPrototypeGameType : uint8_t {
	WaitStart = 0,
	Prepare = 1,
	Fighting = 2,
	Settlement = 3,
	GameOver = 4,
	EAutoChessPrototypeGameType_MAX = 5
};

// Object: Enum Solarland.EAutoPickupConfigEnum
enum class EAutoPickupConfigEnum : uint8_t {
	ItemID = 0,
	ItemType = 1,
	EAutoPickupConfigEnum_MAX = 2
};

// Object: Enum Solarland.EBabyBusMontageType
enum class EBabyBusMontageType : uint8_t {
	Spawn = 0,
	TakeTeammate = 1,
	DropTeammate = 2,
	Recycle = 3,
	EBabyBusMontageType_MAX = 4
};

// Object: Enum Solarland.EBackPackTransitionAnimState
enum class EBackPackTransitionAnimState : int32_t {
	TransitionAnimStateDefault = 0,
	SkyCharge2NoCharge_NoFly = 535,
	SkyCharge2NoEnergy_NoFly = 545,
	SkyCharge2NoCharge_Fly = 636,
	SkyCharge2NoEnergy_Fly = 646,
	SkyCharge2NoCharge_IntoFly = 536,
	SkyCharge2NoEnergy_IntoFly = 546,
	NoCharge2SkyCharge_NoFly = 3505,
	NoEnergy2SkyCharge_NoFly = 4505,
	NoCharge2SkyCharge_Fly = 3606,
	NoEnergy2SkyCharge_Fly = 4606,
	NoCharge2SkyCharge_OutFly = 3605,
	NoEnergy2SkyCharge_OutFly = 4605,
	PileCharge2NoCharge_NoFly = 1535,
	PileCharge2NoEnergy_NoFly = 1545,
	PileCharge2NoCharge_Fly = 1636,
	PileCharge2NoEnergy_Fly = 1646,
	PileCharge2NoCharge_IntoFly = 1536,
	PileCharge2NoEnergy_IntoFly = 1546,
	NoCharge2PileCharge_NoFly = 3515,
	NoEnergy2PileCharge_NoFly = 4515,
	NoCharge2PileCharge_Fly = 3616,
	NoEnergy2PileCharge_Fly = 4616,
	NoCharge2PileCharge_OutFly = 3615,
	NoEnergy2PileCharge_OutFly = 4615,
	BoxCharge2NoCharge_NoFly = 2535,
	BoxCharge2NoEnergy_NoFly = 2545,
	BoxCharge2NoCharge_Fly = 2636,
	BoxCharge2NoEnergy_Fly = 2646,
	BoxCharge2NoCharge_IntoFly = 2536,
	BoxCharge2NoEnergy_IntoFly = 2546,
	NoCharge2BoxCharge_NoFly = 3525,
	NoEnergy2BoxCharge_NoFly = 4525,
	NoCharge2BoxCharge_Fly = 3626,
	NoEnergy2BoxCharge_Fly = 4626,
	NoCharge2BoxCharge_OutFly = 3625,
	NoEnergy2BoxCharge_OutFly = 4625,
	NoCharge2NoEnergy_NoFly = 3545,
	NoCharge2NoEnergy_IntoFly = 3546,
	NoEnergy2NoCharge_NoFly = 4535,
	NoEnergy2NoCharge_OutFly = 4635,
	EBackPackTransitionAnimState_MAX = 4636
};

// Object: Enum Solarland.EBackPackFixedAnimState
enum class EBackPackFixedAnimState : uint8_t {
	FixedAnimStateDefault = 0,
	FixedSkyChargeNoFly = 5,
	FixedPileChargeNoFly = 15,
	FixedBoxChargeNoFly = 25,
	FixedNoChargeNoFly = 35,
	FixedNoEnergyNoFly = 45,
	FixedSkyChargeIsFly = 6,
	FixedPileChargeIsFly = 16,
	FixedBoxChargeIsFly = 26,
	FixedNoChargeIsFly = 36,
	FixedNoEnergyIsFly = 46,
	EBackPackFixedAnimState_MAX = 47
};

// Object: Enum Solarland.EBackPackAnimSubType
enum class EBackPackAnimSubType : uint8_t {
	SkyChargeNoFly = 1,
	PileChargeNoFly = 2,
	BoxChargeNoFly = 3,
	NoChargeNoFly = 4,
	NoEnergyNoFly = 5,
	SkyChargeIsFly = 6,
	PileChargeIsFly = 7,
	BoxChargeIsFly = 8,
	NoChargeIsFly = 9,
	NoEnergyIsFly = 10,
	Charge2NoCharge_NoFly = 50,
	Charge2NoEnergy_NoFly = 51,
	Charge2NoCharge_Fly = 52,
	Charge2NoEnergy_Fly = 53,
	Charge2NoCharge_IntoFly = 54,
	Charge2NoEnergy_IntoFly = 55,
	NoCharge2Charge_NoFly = 56,
	NoEnergy2Charge_NoFly = 57,
	NoCharge2Charge_Fly = 58,
	NoEnergy2Charge_Fly = 59,
	NoCharge2Charge_OutFly = 60,
	NoEnergy2Charge_OutFly = 61,
	NoCharge2NoEnergy_NoFly = 62,
	NoCharge2NoEnergy_IntoFly = 63,
	NoEnergy2NoCharge_NoFly = 64,
	NoEnergy2NoCharge_OutFly = 65,
	ETypeDefault = 0,
	EBackPackAnimSubType_MAX = 66
};

// Object: Enum Solarland.EBackPackAnimType
enum class EBackPackAnimType : uint8_t {
	SkyCharge = 0,
	PileCharge = 1,
	BoxCharge = 2,
	NoCharge = 3,
	NoEnergy = 4,
	NoFly = 5,
	IsFly = 6,
	EBackPackAnimType_MAX = 7
};

// Object: Enum Solarland.EBattleChatButtonState
enum class EBattleChatButtonState : uint8_t {
	Normal = 0,
	Pressed = 1,
	Clicked = 2,
	EBattleChatButtonState_MAX = 3
};

// Object: Enum Solarland.EProgressStatus
enum class EProgressStatus : uint8_t {
	Min = 0,
	Max = 1,
	NoChange = 2,
	Increase = 3,
	Decrease = 4
};

// Object: Enum Solarland.EControlPointStatus
enum class EControlPointStatus : uint8_t {
	None = 0,
	Neutral = 1,
	Owned = 2,
	Enemy = 3,
	EControlPointStatus_MAX = 4
};

// Object: Enum Solarland.EBattlegroundPlayerStartRegion
enum class EBattlegroundPlayerStartRegion : uint8_t {
	Default = 0,
	Inner = 1,
	Outer = 2,
	EBattlegroundPlayerStartRegion_MAX = 3
};

// Object: Enum Solarland.EBattlegroundMapElementType
enum class EBattlegroundMapElementType : uint8_t {
	None = 0,
	Home = 1,
	ControlPoint = 2,
	AirWall = 3,
	PlayerStart = 4,
	VehicleSpawner = 5,
	Custom = 6,
	EBattlegroundMapElementType_MAX = 7
};

// Object: Enum Solarland.EHPProgressBarBoardType
enum class EHPProgressBarBoardType : uint8_t {
	Normal = 0,
	Self = 1,
	Teammate = 2,
	EHPProgressBarBoardType_MAX = 3
};

// Object: Enum Solarland.EBattlePromptWidgetType
enum class EBattlePromptWidgetType : uint8_t {
	None = 0,
	DirArrow = 1,
	TypeDetail = 2,
	EBattlePromptWidgetType_MAX = 3
};

// Object: Enum Solarland.EBattleRoyalTimeLineEnum
enum class EBattleRoyalTimeLineEnum : uint8_t {
	None = 0,
	CreateBombingZone = 1,
	CreateAirdrop = 2,
	ModifyEnvironmentState = 3,
	EBattleRoyalTimeLineEnum_MAX = 4
};

// Object: Enum Solarland.EBattleUpgradeEffectCategory
enum class EBattleUpgradeEffectCategory : uint8_t {
	None = 0,
	Attack = 1,
	Defence = 2,
	Speed = 3,
	Bag = 4,
	Cooldown = 5,
	PlaceHolder1 = 6,
	PlaceHolder2 = 7,
	PlaceHolder3 = 8,
	PlaceHolder4 = 9,
	EBattleUpgradeEffectCategory_MAX = 10
};

// Object: Enum Solarland.EBombingZoneState
enum class EBombingZoneState : uint8_t {
	Waiting = 0,
	Firing = 1,
	Ending = 2,
	End = 3,
	EBombingZoneState_MAX = 4
};

// Object: Enum Solarland.EBotAttrOperator
enum class EBotAttrOperator : uint8_t {
	Equal = 0,
	Greater = 1,
	Less = 2,
	EBotAttrOperator_MAX = 3
};

// Object: Enum Solarland.EBotAttrValueType
enum class EBotAttrValueType : uint8_t {
	Current = 0,
	Max = 1,
	Percent = 2
};

// Object: Enum Solarland.EBotAttrType
enum class EBotAttrType : uint8_t {
	Health = 0,
	Shield = 1,
	Energy = 2,
	HealthAndShield = 3,
	HealthAndShieldLimit = 4,
	ClipAmmo = 5,
	EBotAttrType_MAX = 6
};

// Object: Enum Solarland.EBotCheckCondition
enum class EBotCheckCondition : uint8_t {
	AlwaysPass = 0,
	ReadyFight = 1,
	CanJetVertical = 2,
	CanJetHorizontal = 3,
	ReadyWeaponSkill = 4,
	IsIndependent = 5,
	NeedReloading = 6,
	EBotCheckCondition_MAX = 7
};

// Object: Enum Solarland.EBotCheckAIServer
enum class EBotCheckAIServer : uint8_t {
	AlwaysPass = 0,
	AIServerIsOnline = 1,
	EBotCheckAIServer_MAX = 2
};

// Object: Enum Solarland.EBotCheckDirector
enum class EBotCheckDirector : uint8_t {
	EndGameStage = 0,
	EBotCheckDirector_MAX = 1
};

// Object: Enum Solarland.EBotCheckNgaiMLAction
enum class EBotCheckNgaiMLAction : uint8_t {
	AlwaysPass = 0,
	DoOnceFire = 1,
	DoJump = 2,
	DoUseRoleSkillOne = 3,
	DoUseRoleSkillTwo = 4,
	DoUseRoleSkillThree = 5,
	DoContinueFire = 6,
	DoMoveTo = 7,
	DoUseMedicine = 8,
	DoUseShieldRecharger = 9,
	DoVehicleFire = 10,
	DoUseVehicleFirstSkill = 11,
	DoUseVehicleSecondSkill = 12,
	EBotCheckNgaiMLAction_MAX = 13
};

// Object: Enum Solarland.EBotCheckState
enum class EBotCheckState : uint8_t {
	None = 0,
	Falling = 1,
	Driving = 2,
	Passager = 3,
	Swiming = 4,
	Dying = 5,
	Dead = 6,
	WeaponReloading = 7,
	ShootAiming = 8,
	SiegeVehicleLocated = 9,
	BeingRescued = 10,
	Cruising = 11,
	Skydiving = 12,
	SkydivingInitially = 13,
	SkydivingAfterRebirth = 14,
	SkydivingByLauncher = 15,
	NewCome = 16,
	EBotCheckState_MAX = 17
};

// Object: Enum Solarland.EDistanceComparison
enum class EDistanceComparison : uint8_t {
	Equal = 0,
	Greater = 1,
	Less = 2,
	EDistanceComparison_MAX = 3
};

// Object: Enum Solarland.EBuddyAnimState
enum class EBuddyAnimState : uint8_t {
	IdleLoop = 0,
	IdleShow1 = 1,
	IdleShow2 = 2,
	IdleShow3 = 3,
	Max = 4
};

// Object: Enum Solarland.EBuddyBackpackState
enum class EBuddyBackpackState : uint8_t {
	Normal = 0,
	CoolDown = 1,
	MultiUseCoolDown = 2,
	Forbidden = 3,
	EBuddyBackpackState_MAX = 4
};

// Object: Enum Solarland.EBuddyConfigType
enum class EBuddyConfigType : uint8_t {
	Buddy = 0,
	GeneralSummon = 1,
	EBuddyConfigType_MAX = 2
};

// Object: Enum Solarland.ESameScreenEffectHandleType
enum class ESameScreenEffectHandleType : uint8_t {
	Ignore = 0,
	StopPrev = 1,
	ESameScreenEffectHandleType_MAX = 2
};

// Object: Enum Solarland.EBuffEffectDurationType
enum class EBuffEffectDurationType : uint8_t {
	Instant = 0,
	HasDuration = 1,
	EBuffEffectDurationType_MAX = 2
};

// Object: Enum Solarland.EC4ExplosiveAimType
enum class EC4ExplosiveAimType : uint8_t {
	SpecificDistanceParabola = 0,
	DynamicDistanceParabola = 1,
	EC4ExplosiveAimType_MAX = 2
};

// Object: Enum Solarland.EC4AttachTargetType
enum class EC4AttachTargetType : uint8_t {
	InHand = 0,
	InAir = 1,
	Normal = 2,
	SmallWoman = 3,
	Woman = 4,
	Man = 5,
	DuckMan = 6,
	EC4AttachTargetType_MAX = 7
};

// Object: Enum Solarland.EC4ProjectileLifeState
enum class EC4ProjectileLifeState : uint8_t {
	NewlySpawned = 0,
	Throwing = 1,
	Attaching = 2,
	Falling = 3,
	Explode = 4,
	Destroy = 5,
	Invalid = 6,
	EC4ProjectileLifeState_MAX = 7
};

// Object: Enum Solarland.ESettleUIDataGatherType
enum class ESettleUIDataGatherType : uint8_t {
	Personal = 0,
	Team = 1,
	All = 2,
	ESettleUIDataGatherType_MAX = 3
};

// Object: Enum Solarland.ELevelLoadType
enum class ELevelLoadType : uint8_t {
	ClientAntServer = 0,
	ClientOnly = 1,
	ServerOnly = 2,
	ELevelLoadType_MAX = 3
};

// Object: Enum Solarland.EAIDogCancelReason
enum class EAIDogCancelReason : uint8_t {
	E_SpawnFailed = 0,
	E_None = 1,
	E_MAX = 2
};

// Object: Enum Solarland.EAIDogGAAction
enum class EAIDogGAAction : uint8_t {
	E_Spawn = 0,
	E_Move = 1,
	E_EnterLongPress = 2,
	E_Recycle = 3,
	E_Reconnect = 4,
	E_MAX = 5
};

// Object: Enum Solarland.EAIDogSkillPhase
enum class EAIDogSkillPhase : uint8_t {
	E_PhaseSpawn = 0,
	E_PhaseControl = 1,
	E_MAX = 2
};

// Object: Enum Solarland.EC4ExplosiveSkillPhase
enum class EC4ExplosiveSkillPhase : uint8_t {
	E_PhaseThrow = 0,
	E_PhaseDetonate = 1,
	E_MAX = 2
};

// Object: Enum Solarland.EDoppelgangerActivePhase
enum class EDoppelgangerActivePhase : uint8_t {
	Summon = 0,
	Exchange = 1,
	EDoppelgangerActivePhase_MAX = 2
};

// Object: Enum Solarland.EDoppelgangerTargetDataType
enum class EDoppelgangerTargetDataType : uint8_t {
	ActivePhase = 0,
	SummonInfo = 1,
	EDoppelgangerTargetDataType_MAX = 2
};

// Object: Enum Solarland.EHellStrikeStage
enum class EHellStrikeStage : uint8_t {
	None = 0,
	FirstStage = 1,
	SecondStage = 2,
	EHellStrikeStage_MAX = 3
};

// Object: Enum Solarland.EHotWheelsPhase
enum class EHotWheelsPhase : uint8_t {
	E_PreActive = 0,
	E_Activated = 1,
	E_PostActive = 2,
	E_MAX = 3
};

// Object: Enum Solarland.EHotWheelsAction
enum class EHotWheelsAction : uint8_t {
	E_StartSkill = 0,
	E_EndSkill = 1,
	E_Reconnect = 2,
	E_Dash = 3,
	E_Reset = 4,
	E_MAX = 5
};

// Object: Enum Solarland.EGARestrictSnareAction
enum class EGARestrictSnareAction : uint8_t {
	Launch = 0,
	CallBack = 1,
	EGARestrictSnareAction_MAX = 2
};

// Object: Enum Solarland.EStealMessageType
enum class EStealMessageType : uint8_t {
	E_NoTarget = 0,
	E_StealFailed = 1,
	E_StealSuccess = 2,
	E_MAX = 3
};

// Object: Enum Solarland.EActionType
enum class EActionType : uint8_t {
	E_Call = 0,
	E_Recycle = 1,
	E_MAX = 2
};

// Object: Enum Solarland.ETransformationMeshType
enum class ETransformationMeshType : uint8_t {
	Small = 0,
	Middle = 1,
	Large = 2,
	ETransformationMeshType_MAX = 3
};

// Object: Enum Solarland.EVaultType
enum class EVaultType : uint8_t {
	None = 0,
	Step = 1,
	StepSprint = 2,
	Vault = 3,
	VaultSprint = 4,
	Climb = 5,
	ClimbSprint = 6,
	ClimbWallRun = 7,
	ClimbWater = 8,
	HighClimb = 9,
	HighClimbSprint = 10,
	WallRun = 11,
	WallRunFailed = 12,
	EVaultType_MAX = 13
};

// Object: Enum Solarland.EObstacleDetectorType
enum class EObstacleDetectorType : uint8_t {
	Knee = 0,
	Waist = 1,
	Chest = 2,
	Overhead = 3,
	Nullifier = 7,
	EObstacleDetectorType_MAX = 8
};

// Object: Enum Solarland.EMatActionOnRemoved
enum class EMatActionOnRemoved : uint8_t {
	None = 0,
	ResetToBeginValue = 1,
	ResetToEndValue = 2,
	EMatActionOnRemoved_MAX = 3
};

// Object: Enum Solarland.EMassInvisibilityRangeType
enum class EMassInvisibilityRangeType : uint8_t {
	Normal = 0,
	Closed = 1,
	Warning = 2,
	EMassInvisibilityRangeType_MAX = 3
};

// Object: Enum Solarland.EBuffEffectType
enum class EBuffEffectType : uint8_t {
	Both = 0,
	ScreenEffect = 1,
	ActorEffect = 2,
	EBuffEffectType_MAX = 3
};

// Object: Enum Solarland.EActorEffectAffectedActorType
enum class EActorEffectAffectedActorType : uint8_t {
	CharacterOnly = 0,
	All = 1,
	EActorEffectAffectedActorType_MAX = 2
};

// Object: Enum Solarland.ECueContentVisibleTargetFlag
enum class ECueContentVisibleTargetFlag : uint8_t {
	None = 0,
	Self = 1,
	Teammate = 2,
	Other = 4,
	Observer = 8,
	CueInstigator = 16,
	CueEffectCauser = 32,
	Anyone = 15,
	ECueContentVisibleTargetFlag_MAX = 33
};

// Object: Enum Solarland.ECueContentPlayTiming
enum class ECueContentPlayTiming : uint8_t {
	OnExecute = 0,
	OnActive = 1,
	WhileActive = 2,
	OnRemove = 3,
	OnCustomEvent = 4,
	ECueContentPlayTiming_MAX = 5
};

// Object: Enum Solarland.ECharacterIKOffsetType
enum class ECharacterIKOffsetType : uint8_t {
	ZIPLINE = 0,
	RELOAD = 1,
	ECharacterIKOffsetType_MAX = 2
};

// Object: Enum Solarland.ECharacterMeshMaterialParameterType
enum class ECharacterMeshMaterialParameterType : uint8_t {
	Scalar = 0,
	Vector = 1,
	ECharacterMeshMaterialParameterType_MAX = 2
};

// Object: Enum Solarland.ECharacterMeshMaterialChangeType
enum class ECharacterMeshMaterialChangeType : uint8_t {
	Set = 0,
	Curve = 1,
	ECharacterMeshMaterialChangeType_MAX = 2
};

// Object: Enum Solarland.EHitMontageBySpecialState
enum class EHitMontageBySpecialState : uint8_t {
	Normal = 0,
	HoldGun = 1,
	EHitMontageBySpecialState_MAX = 2
};

// Object: Enum Solarland.EUseType
enum class EUseType : uint8_t {
	NORMAL = 0,
	HANDSETTING = 101,
	EUseType_MAX = 102
};

// Object: Enum Solarland.EWeaponEquipSlot
enum class EWeaponEquipSlot : uint8_t {
	None = 0,
	First = 1,
	Second = 2,
	EWeaponEquipSlot_MAX = 3
};

// Object: Enum Solarland.ECrossHairState
enum class ECrossHairState : uint8_t {
	None = 0,
	Normal = 1,
	Reload = 2,
	Overload = 3,
	Forbid = 4,
	ECrossHairState_MAX = 5
};

// Object: Enum Solarland.ESpreadType
enum class ESpreadType : uint8_t {
	Absolute = 0,
	Relative = 1,
	ESpreadType_MAX = 2
};

// Object: Enum Solarland.ECrossHairSpecialFireState
enum class ECrossHairSpecialFireState : uint8_t {
	PrepareFire = 0,
	ActivateFire = 1,
	KeepFiring = 2,
	EndFire = 3,
	ECrossHairSpecialFireState_MAX = 4
};

// Object: Enum Solarland.ECurvedEffectControllerStopMode
enum class ECurvedEffectControllerStopMode : uint8_t {
	KeepCurrentProgress = 0,
	SetProgressToBegin = 1,
	SetProgressToEnd = 2,
	ECurvedEffectControllerStopMode_MAX = 3
};

// Object: Enum Solarland.ECutMaterialProgressType
enum class ECutMaterialProgressType : uint8_t {
	Spawning = 0,
	Destroying = 1,
	ECutMaterialProgressType_MAX = 2
};

// Object: Enum Solarland.ERevivePreviewAnimType
enum class ERevivePreviewAnimType : uint8_t {
	E_None = 0,
	E_GhostUp = 1,
	E_PrintDown = 2,
	E_FlashBody = 3,
	E_MAX = 4
};

// Object: Enum Solarland.EExpandWidgetState
enum class EExpandWidgetState : uint8_t {
	None = 0,
	Normal = 1,
	CanCancel = 2,
	ReCall = 3,
	EExpandWidgetState_MAX = 4
};

// Object: Enum Solarland.EInputActionType
enum class EInputActionType : uint8_t {
	RoleSkillOne = 0,
	RoleSkillTwo = 1,
	RoleSkillThree = 2,
	LongPressRoleSkillOne = 3,
	LongPressRoleSkillTwo = 4,
	LongPressRoleSkillThree = 5,
	Fire = 6,
	CancelAbility = 7,
	None = 8,
	EInputActionType_MAX = 9
};

// Object: Enum Solarland.ERoleSkillUIState
enum class ERoleSkillUIState : uint8_t {
	Forbid = 0,
	CDorCost_CanTrigger = 1,
	CDorCost_Disable = 2,
	Select = 3,
	Disable = 4,
	Default = 5,
	None = 6,
	ERoleSkillUIState_MAX = 7
};

// Object: Enum Solarland.ESignalState
enum class ESignalState : uint8_t {
	Signal_Normal = 0,
	Signal_Weak = 1,
	Signal_Lost = 2,
	None = 3,
	ESignalState_MAX = 4
};

// Object: Enum Solarland.EEmbroideredBallState
enum class EEmbroideredBallState : uint8_t {
	InHand = 0,
	Flying = 1,
	Jump = 2,
	Standby = 3,
	TraceTarget = 4,
	WaitingForExplode = 5,
	BrokenDueToDamage = 6,
	Exploded = 7,
	EEmbroideredBallState_MAX = 8
};

// Object: Enum Solarland.EUseOwnerType
enum class EUseOwnerType : uint8_t {
	Character = 0,
	Actor = 1,
	EUseOwnerType_MAX = 2
};

// Object: Enum Solarland.EUsePlayerType
enum class EUsePlayerType : uint8_t {
	Self = 0,
	Teammate = 1,
	Enemy = 2,
	EUsePlayerType_MAX = 3
};

// Object: Enum Solarland.EUseEmojiScene
enum class EUseEmojiScene : uint8_t {
	None = 0,
	Lobby = 1,
	Battle = 2,
	EUseEmojiScene_MAX = 3
};

// Object: Enum Solarland.EGameplayEventType
enum class EGameplayEventType : uint8_t {
	None = 0,
	Bombing = 1,
	AirDrop = 2,
	ReduceSafeArea = 3,
	AddExp = 4,
	Upgrade = 5,
	ExpSpring = 6,
	PVE = 7,
	SkyIsland = 8,
	ShieldShop = 9,
	RespawnDevice = 10,
	EGameplayEventType_MAX = 11
};

// Object: Enum Solarland.EAnimationStage
enum class EAnimationStage : uint8_t {
	None = 0,
	FlyToTeammate = 1,
	AppearByTeammate = 2,
	Transferring = 3,
	TransferSuccess = 4,
	TransferredReappearing = 5,
	Hit = 6,
	Death = 7,
	EAnimationStage_MAX = 8
};

// Object: Enum Solarland.EFactionType
enum class EFactionType : uint8_t {
	Neutral = 0,
	Blue = 1,
	Red = 2,
	EFactionType_MAX = 3
};

// Object: Enum Solarland.EAnimationType
enum class EAnimationType : uint8_t {
	Overload = 0,
	Overlay = 1,
	EAnimationType_MAX = 2
};

// Object: Enum Solarland.EFollowBuddyAnimState
enum class EFollowBuddyAnimState : uint8_t {
	None = 0,
	FollowStart = 1,
	FollowLoop = 2,
	FollowDisappear = 3,
	EFollowBuddyAnimState_MAX = 4
};

// Object: Enum Solarland.EWeaponInfiniteAmmoMode
enum class EWeaponInfiniteAmmoMode : uint8_t {
	Default = 0,
	InfiniteClip = 1,
	InfinitePkg = 2,
	InfiniteBoth = 3,
	EWeaponInfiniteAmmoMode_MAX = 4
};

// Object: Enum Solarland.EJetAltitudeLimitationMode
enum class EJetAltitudeLimitationMode : uint8_t {
	Default = 0,
	Home = 1,
	EJetAltitudeLimitationMode_MAX = 2
};

// Object: Enum Solarland.EWeaponVibrateFactor
enum class EWeaponVibrateFactor : uint8_t {
	Off = 0,
	Low = 10,
	Middle = 20,
	High = 30,
	EWeaponVibrateFactor_MAX = 31
};

// Object: Enum Solarland.EWeaponVibrateType
enum class EWeaponVibrateType : uint8_t {
	None = 0,
	Fire = 1,
	Reload_GetOld = 2,
	Reload_Restore = 3,
	Bolt = 4,
	Charge = 5,
	EWeaponVibrateType_MAX = 6
};

// Object: Enum Solarland.EGameplayVibrateIntensity
enum class EGameplayVibrateIntensity : uint8_t {
	Off = 0,
	Low = 10,
	Middle = 20,
	High = 30,
	EGameplayVibrateIntensity_MAX = 31
};

// Object: Enum Solarland.EGameplayVibrateCategory
enum class EGameplayVibrateCategory : uint8_t {
	None = 0,
	SelfBeingHit = 1,
	SelfJetpackFlying = 2,
	SelfContinuousDamaged = 3,
	TriggerCharacterDown = 4,
	TriggerCharacterDie = 5,
	ActionWheel = 6,
	Jump = 7,
	Land = 8,
	Crouch = 9,
	EGameplayVibrateCategory_MAX = 10
};

// Object: Enum Solarland.EVibrateAssetType
enum class EVibrateAssetType : uint8_t {
	None = 0,
	Richtap = 1,
	ForceFeedback = 2,
	EVibrateAssetType_MAX = 3
};

// Object: Enum Solarland.EVibrateDeviceType
enum class EVibrateDeviceType : uint8_t {
	Nonsupport = 0,
	Mobile = 1,
	Gamepad = 2,
	EVibrateDeviceType_MAX = 3
};

// Object: Enum Solarland.ESCMDataGatherType_Settle
enum class ESCMDataGatherType_Settle : uint8_t {
	None = 0,
	Self = 1,
	Side = 2,
	All = 3,
	ESCMDataGatherType_MAX = 4
};

// Object: Enum Solarland.ESCMDataReplicateType
enum class ESCMDataReplicateType : uint8_t {
	None = 0,
	RepOwner = 1,
	RepSide = 2,
	RepGlobal = 3,
	ESCMDataReplicateType_MAX = 4
};

// Object: Enum Solarland.ESCMRankCheckType
enum class ESCMRankCheckType : uint8_t {
	New = 0,
	Change = 1,
	Delete = 2,
	ESCMRankCheckType_MAX = 3
};

// Object: Enum Solarland.ESCMDataSetType
enum class ESCMDataSetType : uint8_t {
	None = 0,
	Array = 1,
	Map = 2,
	ESCMDataSetType_MAX = 3
};

// Object: Enum Solarland.EGaugeType
enum class EGaugeType : uint8_t {
	None = 0,
	Degree_361 = 1,
	Degree_181 = 2,
	Degree_91 = 3,
	DownUp = 4,
	LeftRight = 5,
	EGaugeType_MAX = 6
};

// Object: Enum Solarland.EAimOffsetAdjustType
enum class EAimOffsetAdjustType : uint8_t {
	None = 0,
	AdjustPitch = 1,
	AdjustYaw = 2,
	AdjustBoth = 3,
	EAimOffsetAdjustType_MAX = 4
};

// Object: Enum Solarland.EMobileAALevel
enum class EMobileAALevel : uint8_t {
	Off = 0,
	Low = 1,
	Medium = 2,
	High = 3,
	Invalid = 255,
	EMobileAALevel_MAX = 256
};

// Object: Enum Solarland.ESolarDecalLayerLevel
enum class ESolarDecalLayerLevel : uint8_t {
	Off = 0,
	Low = 1,
	Medium = 2,
	High = 3,
	Invalid = 255,
	ESolarDecalLayerLevel_MAX = 256
};

// Object: Enum Solarland.ESolarScreenPercentageLevel
enum class ESolarScreenPercentageLevel : uint8_t {
	Default = 0,
	Percent25 = 1,
	Percent50 = 2,
	Percent75 = 3,
	Percent100 = 4,
	VALUE_MIN = 2,
	VALUE_MAX = 4,
	Invalid = 255,
	ESolarScreenPercentageLevel_MAX = 256
};

// Object: Enum Solarland.ESolarSSRQualityLevel
enum class ESolarSSRQualityLevel : uint8_t {
	Off = 0,
	Low = 1,
	Medium = 2,
	High = 3,
	ExtraHigh = 4,
	Invalid = 255,
	ESolarSSRQualityLevel_MAX = 256
};

// Object: Enum Solarland.ESolarSSGIQualityLevel
enum class ESolarSSGIQualityLevel : uint8_t {
	Off = 0,
	Low = 1,
	Medium = 2,
	High = 3,
	ExtraHigh = 4,
	Invalid = 255,
	ESolarSSGIQualityLevel_MAX = 256
};

// Object: Enum Solarland.ESolarAmbientOcclusionQualityLevel
enum class ESolarAmbientOcclusionQualityLevel : uint8_t {
	Off = 0,
	Low = 1,
	Medium = 2,
	High = 3,
	Invalid = 255,
	ESolarAmbientOcclusionQualityLevel_MAX = 256
};

// Object: Enum Solarland.ESolarMaxCSMResolutionLevel
enum class ESolarMaxCSMResolutionLevel : uint8_t {
	Off = 0,
	Low = 1,
	Medium = 2,
	High = 3,
	Invalid = 255,
	ESolarMaxCSMResolutionLevel_MAX = 256
};

// Object: Enum Solarland.ESolarShadowQualityLevel
enum class ESolarShadowQualityLevel : uint8_t {
	Off = 0,
	Low = 1,
	Medium = 2,
	High = 3,
	Invalid = 255,
	ESolarShadowQualityLevel_MAX = 256
};

// Object: Enum Solarland.ESolarAnisotropicFilterLevel
enum class ESolarAnisotropicFilterLevel : uint8_t {
	Default = 0,
	Level1X = 1,
	Level2X = 2,
	Level4X = 3,
	Level8X = 4,
	Level16X = 5,
	Invalid = 255,
	ESolarAnisotropicFilterLevel_MAX = 256
};

// Object: Enum Solarland.ESolarFSRLevel
enum class ESolarFSRLevel : uint8_t {
	Off = 0,
	On = 1,
	Invalid = 255,
	ESolarFSRLevel_MAX = 256
};

// Object: Enum Solarland.ESolarAntiAliasingLevel
enum class ESolarAntiAliasingLevel : uint8_t {
	Off = 0,
	FXAA = 1,
	TAA = 2,
	MSAA = 3,
	Invalid = 255,
	ESolarAntiAliasingLevel_MAX = 256
};

// Object: Enum Solarland.ESolarMotionBlurLevel
enum class ESolarMotionBlurLevel : uint8_t {
	Off = 0,
	Low = 1,
	Medium = 2,
	High = 3,
	Ultra = 4,
	Invalid = 255,
	ESolarMotionBlurLevel_MAX = 256
};

// Object: Enum Solarland.ESolarMonitor
enum class ESolarMonitor : uint8_t {
	Default = 0,
	Monitor1 = 1,
	Monitor2 = 2,
	Monitor3 = 3,
	ESolarMonitor_MAX = 4
};

// Object: Enum Solarland.ESolarResolution
enum class ESolarResolution : uint8_t {
	Default = 0,
	Resolution1 = 1,
	Resolution2 = 2,
	Resolution3 = 3,
	Resolution4 = 4,
	Resolution5 = 5,
	ESolarResolution_MAX = 6
};

// Object: Enum Solarland.ECommercialInterfaceType
enum class ECommercialInterfaceType : uint8_t {
	None = 0,
	SelectHeroPick = 1,
	MyTeam = 2,
	Settlement = 3,
	ECommercialInterfaceType_MAX = 4
};

// Object: Enum Solarland.EGraphicQualitySelect
enum class EGraphicQualitySelect : uint8_t {
	Default = 0,
	Lobby = 1,
	InGame = 2,
	EGraphicQualitySelect_MAX = 3
};

// Object: Enum Solarland.ESolarDeviceType
enum class ESolarDeviceType : uint8_t {
	ESDT_Invalid = 0,
	ESDT_Windows = 1,
	ESDT_Android = 2,
	ESDT_IOS = 3,
	ESDT_Switch = 4,
	ESDT_Other = 5,
	ESDT_MAX = 6
};

// Object: Enum Solarland.ESolarFeatureLevel
enum class ESolarFeatureLevel : uint8_t {
	ESFL_Invalid = 0,
	ESFL_Deferred = 1,
	ESFL_MobileHDR = 2,
	ESFL_MobileLDR = 3,
	ESFL_MAX = 4
};

// Object: Enum Solarland.EHellStrikeOverlapAreaDamageCalculateType
enum class EHellStrikeOverlapAreaDamageCalculateType : uint8_t {
	Add = 0,
	BasedOnFirstEntry = 1,
	EHellStrikeOverlapAreaDamageCalculateType_MAX = 2
};

// Object: Enum Solarland.EClassLevelUpRewardType
enum class EClassLevelUpRewardType : uint8_t {
	BattleUpgradeEffect = 0,
	UpgradeSkill1 = 1,
	UpgradeSkill2 = 2,
	UpgradeSkill3 = 3,
	UpgradeSkill4 = 4,
	ClassCommonPassiveSkill = 5,
	ClassSpecificPassiveSkill = 6,
	Max = 7
};

// Object: Enum Solarland.EUIHeroPickListCellState
enum class EUIHeroPickListCellState : uint8_t {
	Show = 0,
	Lock = 1,
	Forbidden = 2,
	EUIHeroPickListCellState_MAX = 3
};

// Object: Enum Solarland.EHeroPickMode
enum class EHeroPickMode : uint8_t {
	BattleRoyale = 0,
	BattleGround = 1,
	Solo = 2,
	EHeroPickMode_MAX = 3
};

// Object: Enum Solarland.EUIHeroPickPlayerState
enum class EUIHeroPickPlayerState : uint8_t {
	Waiting = 0,
	Selecting = 1,
	Confirm = 2,
	Done = 3,
	EUIHeroPickPlayerState_MAX = 4
};

// Object: Enum Solarland.EHeroPickStage
enum class EHeroPickStage : uint8_t {
	Default = 0,
	WaitingToStartPick = 1,
	PlayerSelecting = 2,
	WaitingToEnd = 3,
	TeamShow = 4,
	End = 5,
	EHeroPickStage_MAX = 6
};

// Object: Enum Solarland.ESkillStateType
enum class ESkillStateType : uint8_t {
	Normal = 0,
	CD = 1,
	NoneSkill = 2,
	ESkillStateType_MAX = 3
};

// Object: Enum Solarland.ETeamMateUIMode
enum class ETeamMateUIMode : uint8_t {
	BattleRoyale = 0,
	DeathMatch = 1,
	ETeamMateUIMode_MAX = 2
};

// Object: Enum Solarland.EHUDPickupWidgetState
enum class EHUDPickupWidgetState : uint8_t {
	Pickup_Weapon = 0,
	Pickup_Normal = 1,
	Replace_Weapon = 2,
	Replace_Scope = 3,
	Replace_Shield = 4,
	CanNotPickup = 5,
	CanNotPickup_Scope = 6,
	EHUDPickupWidgetState_MAX = 7
};

// Object: Enum Solarland.EHUDPickupReplaceSlotState
enum class EHUDPickupReplaceSlotState : uint8_t {
	NormalWeapon = 0,
	FullPartWeapon = 1,
	NotWeapon = 2,
	EHUDPickupReplaceSlotState_MAX = 3
};

// Object: Enum Solarland.EKeyMappingStatus
enum class EKeyMappingStatus : uint8_t {
	EMPTY = 0,
	BASE = 1,
	OTHER = 2,
	OTHERANDBASE = 3,
	INVALID = 4,
	DONE = 5,
	EKeyMappingStatus_MAX = 6
};

// Object: Enum Solarland.EKillNoticeType
enum class EKillNoticeType : uint8_t {
	BeKillLeader = 0,
	ShutDownKillLeader = 1,
	Revenge = 2,
	ShutDown = 3,
	CumulativeKill = 4,
	Down = 5,
	ClearTeam = 6,
	KillDefender = 7,
	KillBoss = 8,
	SelfKillNotify = 9,
	KillLeaderChange = 10,
	KillLeaderShutDown = 11,
	GlobalKillNotify = 12,
	EKillNoticeType_MAX = 13
};

// Object: Enum Solarland.ELoadingDataType
enum class ELoadingDataType : uint8_t {
	None = 0,
	LoadingBR = 1,
	LoadingViceMode = 2,
	LoadingTuitionKeystroke = 3,
	LoadingTuitionHero = 4,
	LoadingTuitionGameplay = 5,
	Max = 6
};

// Object: Enum Solarland.ELoadingImageDataType
enum class ELoadingImageDataType : uint8_t {
	None = 0,
	OneImage = 1,
	TwoImages = 2,
	ThreeImages = 3,
	Max = 4
};

// Object: Enum Solarland.EMapObjectSpawnStyle
enum class EMapObjectSpawnStyle : uint8_t {
	Normal = 0,
	EMapObjectSpawnStyle_MAX = 1
};

// Object: Enum Solarland.EMapCellSelectionAccess
enum class EMapCellSelectionAccess : uint8_t {
	Can = 0,
	Cannot = 1,
	EMapCellSelectionAccess_MAX = 2
};

// Object: Enum Solarland.EMassInvState
enum class EMassInvState : uint8_t {
	Begin = 0,
	Prepare = 1,
	Normal = 2,
	Sprint = 3,
	End = 4,
	EMassInvState_MAX = 5
};

// Object: Enum Solarland.EMechaBossProcessState
enum class EMechaBossProcessState : uint8_t {
	None = 0,
	WaitingToSpawn = 1,
	Spawned = 2,
	Destroyed = 3,
	EMechaBossProcessState_MAX = 4
};

// Object: Enum Solarland.EMapState
enum class EMapState : uint8_t {
	Idle = 0,
	FOVScale = 1,
	EMapState_MAX = 2
};

// Object: Enum Solarland.EMinimapDetailKeyExpressType
enum class EMinimapDetailKeyExpressType : uint8_t {
	Normal = 0,
	MarkingMySelf = 1,
	ResponseOther = 2,
	CancelResponse = 3,
	EMinimapDetailKeyExpressType_MAX = 4
};

// Object: Enum Solarland.EMapFOVParamType
enum class EMapFOVParamType : uint8_t {
	VehicleSpeed = 0,
	PoisonCircle = 1,
	EMapFOVParamType_MAX = 2
};

// Object: Enum Solarland.EMapFOVState
enum class EMapFOVState : uint8_t {
	Default = 0,
	Fov1 = 1,
	Fov2 = 2,
	EMapFOVState_MAX = 3
};

// Object: Enum Solarland.EMissileSwarmDebugFlag
enum class EMissileSwarmDebugFlag : uint8_t {
	Aim = 0,
	Trail = 1,
	Trace = 2,
	Explode = 3,
	Mesh = 4,
	EMissileSwarmDebugFlag_MAX = 5
};

// Object: Enum Solarland.ENezhaBuddhaState
enum class ENezhaBuddhaState : uint8_t {
	Idle = 0,
	Prepare = 1,
	Active = 2,
	Loop = 3,
	NormalEnd = 4,
	ShieldBreakEnd = 5,
	ENezhaBuddhaState_MAX = 6
};

// Object: Enum Solarland.EMeshProgressType
enum class EMeshProgressType : uint8_t {
	Normal = 0,
	Damage = 1,
	Background = 2,
	EMeshProgressType_MAX = 3
};

// Object: Enum Solarland.EHighlightVideoState
enum class EHighlightVideoState : uint8_t {
	Hide = 0,
	NotGenerate = 1,
	Generating = 2,
	Ready = 3,
	EHighlightVideoState_MAX = 4
};

// Object: Enum Solarland.E_Type_OB_Scoreboard
enum class E_Type_OB_Scoreboard : uint8_t {
	OB_Settlement = 0,
	OB_InGame = 1,
	Lobby_League_Settlement = 2,
	Lobby_CreateRoom_Settlement = 3,
	E_Type_OB_MAX = 4
};

// Object: Enum Solarland.EOBPithyPlayerState
enum class EOBPithyPlayerState : uint8_t {
	Alive = 0,
	Dying = 1,
	Dead = 2,
	EOBPithyPlayerState_MAX = 3
};

// Object: Enum Solarland.EOBTeamListTab
enum class EOBTeamListTab : uint8_t {
	Pithy = 0,
	All = 1,
	Nearby = 2,
	EOBTeamListTab_MAX = 3
};

// Object: Enum Solarland.EPickupListEntryType
enum class EPickupListEntryType : uint8_t {
	PickupList = 0,
	PickupTileView = 1,
	BackpackItem = 2,
	BackpackWeapon = 3,
	BackpackPart = 4,
	EPickupListEntryType_MAX = 5
};

// Object: Enum Solarland.EPoisonControlBuddyAnimState
enum class EPoisonControlBuddyAnimState : uint8_t {
	None = 0,
	Appear = 1,
	ReadyLoop = 2,
	ReadyComplete = 3,
	SpellLoop = 4,
	FinishDisappear = 5,
	DeathDisappear = 6,
	EPoisonControlBuddyAnimState_MAX = 7
};

// Object: Enum Solarland.EBuddyState
enum class EBuddyState : uint8_t {
	CanCollect = 0,
	CollectCooldown = 1,
	Max = 2
};

// Object: Enum Solarland.EBuddyDetailType
enum class EBuddyDetailType : uint8_t {
	None = 0,
	TimeLord = 1,
	StormQueen = 2,
	BouncingSmoke = 3,
	Exposed = 4,
	Move = 5,
	Pretend = 6,
	Blabbermouth = 7,
	WindField = 8,
	Stealing = 9,
	Scan = 10,
	Max = 11
};

// Object: Enum Solarland.EPokeBallType
enum class EPokeBallType : uint8_t {
	None = 0,
	Vehicle = 1,
	TacticalBuilding = 2,
	Pokemon = 3,
	RarePokemon = 4,
	EPokeBallType_MAX = 5
};

// Object: Enum Solarland.ETeammateEffectTriggerType
enum class ETeammateEffectTriggerType : uint8_t {
	AfterSkillActivate = 0,
	AfterSelfEffectTrigger = 1,
	ETeammateEffectTriggerType_MAX = 2
};

// Object: Enum Solarland.EExplosiveGrenadeState
enum class EExplosiveGrenadeState : uint8_t {
	Flying = 0,
	Waiting = 1,
	Exploded = 2,
	BrokenDueToDamage = 3,
	EExplosiveGrenadeState_MAX = 4
};

// Object: Enum Solarland.ERestrictSnarePhase
enum class ERestrictSnarePhase : uint8_t {
	Idle = 0,
	Move = 1,
	Back = 2,
	Loop = 3,
	End = 4,
	ERestrictSnarePhase_MAX = 5
};

// Object: Enum Solarland.ERexDizzinessType
enum class ERexDizzinessType : uint8_t {
	Damage = 0,
	Stun = 1,
	ERexDizzinessType_MAX = 2
};

// Object: Enum Solarland.ERexMontageState
enum class ERexMontageState : uint8_t {
	None = 0,
	Combo1 = 1,
	Combo2 = 2,
	Combo3 = 3,
	FireBall = 4,
	Rage = 5,
	ERexMontageState_MAX = 6
};

// Object: Enum Solarland.ERexState
enum class ERexState : uint8_t {
	Idle = 0,
	InBattle = 1,
	PreTeleport = 2,
	Spawn = 3,
	Dizziness = 4,
	ERexState_MAX = 5
};

// Object: Enum Solarland.ERexBallState
enum class ERexBallState : uint8_t {
	None = 0,
	Spawn = 1,
	Loop = 2,
	PreEnd = 3,
	End = 4,
	ERexBallState_MAX = 5
};

// Object: Enum Solarland.ERexMoveType
enum class ERexMoveType : uint8_t {
	None = 0,
	MoveToOwner = 1,
	MoveToComboTarget = 2,
	MoveToFireBallLocation = 3,
	ERexMoveType_MAX = 4
};

// Object: Enum Solarland.EFireBallState
enum class EFireBallState : uint8_t {
	ReadyToLaunch = 0,
	Flying = 1,
	DamageZone = 2,
	EFireBallState_MAX = 3
};

// Object: Enum Solarland.ESCMMapElementVisibilityType
enum class ESCMMapElementVisibilityType : uint8_t {
	Visible = 0,
	Hidden = 1,
	ESCMMapElementVisibilityType_MAX = 2
};

// Object: Enum Solarland.ESCMMapElementStateType
enum class ESCMMapElementStateType : uint8_t {
	Normal = 0,
	Suspend = 1,
	ESCMMapElementStateType_MAX = 2
};

// Object: Enum Solarland.ESCMMapElementType
enum class ESCMMapElementType : uint8_t {
	PlayerStart = 0,
	ItemSpawner = 1,
	AirDrop = 2,
	ChargingPile = 3,
	JumpPad = 4,
	CarPad = 5,
	Vehicle = 6,
	Poison = 7,
	Custom = 8,
	ESCMMapElementType_MAX = 9
};

// Object: Enum Solarland.EPlayerPawnType
enum class EPlayerPawnType : uint8_t {
	NONE = 0,
	Character = 1,
	Vehicle = 2,
	Other = 3,
	EPlayerPawnType_MAX = 4
};

// Object: Enum Solarland.ESCMGameSceneType
enum class ESCMGameSceneType : uint8_t {
	None = 0,
	InBattle = 1,
	Settlement = 2,
	ESCMGameSceneType_MAX = 3
};

// Object: Enum Solarland.EDownloadState
enum class EDownloadState : uint8_t {
	None = 0,
	Downloading = 1,
	Successful = 2,
	Failed = 3,
	EDownloadState_MAX = 4
};

// Object: Enum Solarland.EShieldUpgradeItemShopOpenState
enum class EShieldUpgradeItemShopOpenState : uint8_t {
	Closed = 0,
	Opening = 1,
	Open = 2,
	Closing = 3,
	EShieldUpgradeItemShopOpenState_MAX = 4
};

// Object: Enum Solarland.EVulnerableBuffEffectType
enum class EVulnerableBuffEffectType : uint8_t {
	Individual = 0,
	Team = 1,
	EVulnerableBuffEffectType_MAX = 2
};

// Object: Enum Solarland.EDamageBuffType
enum class EDamageBuffType : uint8_t {
	Mitigation = 0,
	Vulnerable = 1,
	EDamageBuffType_MAX = 2
};

// Object: Enum Solarland.EHealthBuffType
enum class EHealthBuffType : uint8_t {
	HealingHealth = 0,
	DamageHealth = 1,
	HealingShield = 2,
	HealingShieldAndHealth = 3,
	EHealthBuffType_MAX = 4
};

// Object: Enum Solarland.ESkillBuffValueType
enum class ESkillBuffValueType : uint8_t {
	Static = 0,
	Curve = 1,
	None = 2,
	ESkillBuffValueType_MAX = 3
};

// Object: Enum Solarland.ERoleSkillEnhanceType
enum class ERoleSkillEnhanceType : uint8_t {
	None = 0,
	Tactical_2 = 1,
	Tactical_3 = 2,
	ERoleSkillEnhanceType_MAX = 3
};

// Object: Enum Solarland.ECharacterSkillGMIndex
enum class ECharacterSkillGMIndex : uint8_t {
	Super = 0,
	Tactical_2 = 1,
	Tactical_3 = 2,
	Tactical_4 = 3,
	Passive = 4,
	ResidentPassive = 5,
	ECharacterSkillGMIndex_MAX = 6
};

// Object: Enum Solarland.ERoleSkillActiveStatus
enum class ERoleSkillActiveStatus : uint8_t {
	NotActive = 0,
	Active_Default = 1,
	Active_Continuous = 2,
	Active_Holding = 3,
	ERoleSkillActiveStatus_MAX = 4
};

// Object: Enum Solarland.ECharacterRoleAbilityType
enum class ECharacterRoleAbilityType : uint8_t {
	Type_Super = 0,
	Type_Tactical = 1,
	Count = 2,
	ECharacterRoleAbilityType_MAX = 3
};

// Object: Enum Solarland.ECharacterRoleAbilityIndex
enum class ECharacterRoleAbilityIndex : uint8_t {
	Super = 0,
	Tactical_2 = 1,
	Tactical_3 = 2,
	Tactical_4 = 3,
	Count = 4,
	ECharacterRoleAbilityIndex_MAX = 5
};

// Object: Enum Solarland.ERoleAbilityVoiceTriggerTiming
enum class ERoleAbilityVoiceTriggerTiming : uint8_t {
	None = 0,
	Activate = 1,
	Commit = 2,
	Custom = 4,
	ERoleAbilityVoiceTriggerTiming_MAX = 5
};

// Object: Enum Solarland.EnemyStateInHellStrikeFirstStage
enum class EnemyStateInHellStrikeFirstStage : uint8_t {
	Normal = 0,
	WaitingLock = 1,
	Lock = 2,
	WaitingPerspectiveElimination = 3,
	EnemyStateInHellStrikeFirstStage_MAX = 4
};

// Object: Enum Solarland.EExplodedProjectileState
enum class EExplodedProjectileState : uint8_t {
	Idle = 0,
	Moving = 1,
	Exploded = 2,
	MaxDistance = 3,
	End = 4,
	EExplodedProjectileState_MAX = 5
};

// Object: Enum Solarland.EExpressMarkState
enum class EExpressMarkState : uint8_t {
	None = 0,
	Normal = 1,
	Holding = 2,
	Expressing = 3,
	BeyondTheDistance = 4,
	Interacting = 5,
	CoolDown = 6,
	EExpressMarkState_MAX = 7
};

// Object: Enum Solarland.EPreviewMeshAlignType
enum class EPreviewMeshAlignType : uint8_t {
	None = 0,
	UsingGroundUpAsForward = 1,
	EPreviewMeshAlignType_MAX = 2
};

// Object: Enum Solarland.ETreasuryDoorType
enum class ETreasuryDoorType : uint8_t {
	FrontDoor = 0,
	BackDoor = 1,
	ETreasuryDoorType_MAX = 2
};

// Object: Enum Solarland.ESlitheringDragonAnimationState
enum class ESlitheringDragonAnimationState : uint8_t {
	None = 0,
	Appear = 1,
	Exit = 2,
	ESlitheringDragonAnimationState_MAX = 3
};

// Object: Enum Solarland.EDevilSpeedUpState
enum class EDevilSpeedUpState : uint8_t {
	None = 0,
	DevilIn = 1,
	SmokeIn = 2,
	SmokeOut = 3,
	EDevilSpeedUpState_MAX = 4
};

// Object: Enum Solarland.EAchievementCondition
enum class EAchievementCondition : uint8_t {
	None = 0,
	AchTSubAchievement = 1,
	AchTMinuteKill = 2,
	AchTUseVehicle = 3,
	AchTHPKill = 4,
	AchTLimitWin = 5,
	AchTDyingWin = 6,
	AchTAssistWin = 7,
	AchTRescue = 8,
	AchTLevel = 9,
	AchTSkyKill = 10,
	AchTOnlyLiveWin = 11,
	AchTFirstKill = 12,
	AchTBlindSniper = 13,
	AchTFriendNum = 14,
	AchTOpenBoxNum = 15,
	AchTenemyVehicle = 16,
	AchTDie = 17,
	AchTMarsWin = 18,
	AchTFistKill = 19,
	AchTAirUmbrella = 20,
	AchTAirTrapeze = 21,
	AchTAirSpeed = 22,
	AchTBubbleKill = 23,
	AchTCharacterNum = 24,
	AchAdvancedWeapon = 25,
	AchTBombingDie = 26,
	AchTRevengeKill = 27,
	EAchievementCondition_MAX = 28
};

// Object: Enum Solarland.EAchievementReportType
enum class EAchievementReportType : uint8_t {
	None = 0,
	SingleBattlle = 1,
	MultiBattle = 2,
	NoBattle = 3,
	EAchievementReportType_MAX = 4
};

// Object: Enum Solarland.ESigninItemState
enum class ESigninItemState : uint8_t {
	Got = 0,
	UnGot = 1,
	No = 2,
	ESigninItemState_MAX = 3
};

// Object: Enum Solarland.EProgressEffectType
enum class EProgressEffectType : uint8_t {
	Instantly = 0,
	WholeGrid = 1,
	EProgressEffectType_MAX = 2
};

// Object: Enum Solarland.EProgressBoardChannelState
enum class EProgressBoardChannelState : uint8_t {
	None = 0,
	Add = 1,
	Minus = 2,
	HoldOn = 3,
	EProgressBoardChannelState_MAX = 4
};

// Object: Enum Solarland.ESolarCrowdAgentPriority
enum class ESolarCrowdAgentPriority : uint8_t {
	Low = 0,
	Medium = 1,
	High = 2,
	Top = 3,
	ESolarCrowdAgentPriority_MAX = 4
};

// Object: Enum Solarland.ESolarAIValueCompareOp
enum class ESolarAIValueCompareOp : uint8_t {
	Equal = 0,
	Greater = 1,
	Less = 2,
	ESolarAIValueCompareOp_MAX = 3
};

// Object: Enum Solarland.ELowMemBankLoadStrategy
enum class ELowMemBankLoadStrategy : uint8_t {
	SADM_Unchanged = 0,
	SADM_OnDemand = 1,
	SADM_NeverLoad = 2,
	SADM_MAX = 3
};

// Object: Enum Solarland.ESolarAudioDetailCatalog
enum class ESolarAudioDetailCatalog : uint8_t {
	SADC_Common = 0,
	SADC_Music = 1,
	SADC_UI = 2,
	SADC_Gun = 3,
	SADC_Vehicle = 4,
	SADC_Object = 5,
	SADC_Character = 6,
	SADC_Voice = 7,
	SADC_VoiceEx = 8,
	SADC_PokeBall = 9,
	SADC_SkyIsland = 10,
	SADC_MAX = 11
};

// Object: Enum Solarland.ESolarAudioDetailUnloadMode
enum class ESolarAudioDetailUnloadMode : uint8_t {
	SADU_Manual = 0,
	SADU_Timer = 1,
	SADU_SwitchLevel = 2,
	SADU_LeaveLobby = 3,
	SADU_LeaveTutorial = 4,
	SADU_LeaveWaiting = 5,
	SADU_LeaveGame = 6,
	SADU_LeaveGameState = 7,
	SADU_MAX = 8
};

// Object: Enum Solarland.ESolarAudioDetailLoadMode
enum class ESolarAudioDetailLoadMode : uint8_t {
	SADL_BeginPlay = 0,
	SADL_OnDemand = 1,
	SADL_Manual = 2,
	SADL_EnterBindScene = 3,
	SADL_EnterLobby = 4,
	SADL_EnterTutorial = 5,
	SADL_EnterWaiting = 6,
	SADL_EnterGame = 7,
	SADL_EnterGameState = 8,
	SADL_MAX = 9
};

// Object: Enum Solarland.EMontageCustomFlags
enum class EMontageCustomFlags : int32_t {
	None = 0,
	HasEndNotify = 1,
	Initialized = 2147483648,
	EMontageCustomFlags_MAX = 2147483649
};

// Object: Enum Solarland.ESolarCharacterLayeredMontageType
enum class ESolarCharacterLayeredMontageType : uint8_t {
	Weapon = 0,
	Skill = 1,
	ESolarCharacterLayeredMontageType_MAX = 2
};

// Object: Enum Solarland.EAnimBlendDirection
enum class EAnimBlendDirection : uint8_t {
	Idle = 0,
	Forward = 1,
	Back = 2,
	Right = 3,
	Left = 4,
	Max = 5
};

// Object: Enum Solarland.EInVehicleState
enum class EInVehicleState : uint8_t {
	None = 0,
	Driving = 1,
	Riding = 2,
	StickingOut = 3,
	EInVehicleState_MAX = 4
};

// Object: Enum Solarland.ECruiseAnimState
enum class ECruiseAnimState : uint8_t {
	None = 0,
	Looping = 1,
	Leaving = 2,
	End = 3,
	ECruiseAnimState_MAX = 4
};

// Object: Enum Solarland.ECharacterMontage
enum class ECharacterMontage : uint8_t {
	Invalid = 0,
	Bolt = 1,
	Equip = 2,
	PreFire = 3,
	Rechamber = 4,
	Fire1 = 5,
	Reload = 6,
	ReloadWithBolt = 7,
	SummonPreview = 8,
	SummonExecute = 9,
	Max = 10
};

// Object: Enum Solarland.EVehicleAnimationType
enum class EVehicleAnimationType : uint8_t {
	None = 0,
	Suv = 1,
	Sports = 2,
	MotorBike = 3,
	Hover = 4,
	Legged = 5,
	IronMan = 6,
	Backpacker = 7,
	BabyBus = 8,
	EVehicleAnimationType_MAX = 9
};

// Object: Enum Solarland.EDriveTurnType
enum class EDriveTurnType : uint8_t {
	EDriveTurnType_Idle = 0,
	EDriveTurnType_Left = 1,
	EDriveTurnType_Right = 2,
	EDriveTurnType_MAX = 3
};

// Object: Enum Solarland.EWeaponStatus
enum class EWeaponStatus : uint8_t {
	NoWeapon = 0,
	Peace = 1,
	Aiming = 2,
	EWeaponStatus_MAX = 3
};

// Object: Enum Solarland.EAnoAntiDataType
enum class EAnoAntiDataType : uint8_t {
	Unknown = 0,
	SecAntiDataFlow = 1,
	SecAttackFlow = 2,
	EAnoAntiDataType_MAX = 3
};

// Object: Enum Solarland.EMeerkatSubComponentType
enum class EMeerkatSubComponentType : uint8_t {
	MB = 0,
	Hp = 1,
	AE = 2,
	AR = 3,
	EMeerkatSubComponentType_MAX = 4
};

// Object: Enum Solarland.EMeerkatGameDispatchEvents
enum class EMeerkatGameDispatchEvents : uint8_t {
	ServerFire = 0,
	ServerHit = 1,
	ServerKill = 2,
	ServerKilled = 3,
	ClientFire = 4,
	ClientHit = 5,
	ClientKill = 6,
	ClientKilled = 7,
	ClientHitDown = 8,
	ClientBeHitDown = 9,
	ClientTick = 10,
	ServerTick = 11,
	ClientBeginPlay = 12,
	ServerBeginPlay = 13,
	ClientEndPlay = 14,
	ServerEndPlay = 15,
	EventMax = 16,
	EMeerkatGameDispatchEvents_MAX = 17
};

// Object: Enum Solarland.EItemLoadPriority
enum class EItemLoadPriority : int32_t {
	DEFAULT = 0,
	ITEM_MIN = 1,
	ITEM_MAX = 99,
	WEAPON_MIN = 100,
	WEAPON_MAX = 199,
	VEHICLE_MIN = 200,
	VEHICLE_MAX = 299,
	CHARACTER_MIN = 300,
	CHARACTER_MAX = 399,
	CLASS_PRIORITY = 4294967295,
	EItemLoadPriority_MAX = 4294967296
};

// Object: Enum Solarland.EAutoSaveType
enum class EAutoSaveType : uint8_t {
	Weapon = 0,
	ItemActor = 1,
	EAutoSaveType_MAX = 2
};

// Object: Enum Solarland.EBackpackPropellingMode
enum class EBackpackPropellingMode : uint8_t {
	Default = 0,
	Skydive = 1,
	EBackpackPropellingMode_MAX = 2
};

// Object: Enum Solarland.EMarkWidgetPriority
enum class EMarkWidgetPriority : uint8_t {
	Hide = 0,
	Lowest = 1,
	ItemBriefDetail = 2,
	Zipline = 3,
	WorldMarkOperation = 5,
	ItemDetail = 10,
	EMarkWidgetPriority_MAX = 11
};

// Object: Enum Solarland.ESolarBotMemberState
enum class ESolarBotMemberState : uint8_t {
	None = 0,
	Leader = 1,
	OnCall = 2,
	Separate = 3,
	Leaving = 4,
	Invalid = 5,
	ESolarBotMemberState_MAX = 6
};

// Object: Enum Solarland.EBotDebugType
enum class EBotDebugType : uint8_t {
	None = 0,
	BehaviorTree = 1,
	Blackboard = 2,
	FocusInfo = 3,
	FireInfo = 4,
	Config = 5,
	BackPack = 6,
	Perception = 7,
	PathFollow = 8,
	EBotDebugType_MAX = 9
};

// Object: Enum Solarland.EBotTeleportReason
enum class EBotTeleportReason : uint8_t {
	Unknown = 0,
	SolveBlock = 1,
	SolveOffMesh = 2,
	BTTask = 3,
	PreservePop = 4,
	EBotTeleportReason_MAX = 5
};

// Object: Enum Solarland.ESolarAITagStateTimeType
enum class ESolarAITagStateTimeType : uint8_t {
	DurationInCurrentState = 0,
	TimeSinceLastExitToState = 1,
	ESolarAITagStateTimeType_MAX = 2
};

// Object: Enum Solarland.EBotInteractCondition
enum class EBotInteractCondition : uint8_t {
	Invalid = 0,
	NeedToResponsePoison = 1,
	FoundEnemyActor = 2,
	TeammateKillEnemy = 3,
	WeAreTheChampion = 4,
	TeammateMarkTargetLocation = 5,
	TeammateMarkTargetDangerPoint = 6,
	TeammateMarkTargetItem = 7,
	TeammateMarkTargetFootstep = 8,
	TeammateMarkFollowHe = 9,
	TeammateMarkGetOnVehicle = 10,
	TeammateMarkNeedVehicle = 11,
	TeammateMarkNeedWeapon = 12,
	TeammateMarkNeedHelp = 13,
	TeammateMarkAttack = 14,
	TeammateMarkDefend = 15,
	MockEnemy = 16,
	MockDyingEnemy = 17,
	EnterDying = 18,
	BoringEnough = 19,
	EBotInteractCondition_MAX = 20
};

// Object: Enum Solarland.EBotFocusType
enum class EBotFocusType : uint8_t {
	FocusToNothing = 0,
	FocusToActor = 1,
	FocusToPoint = 2,
	FocusToDirection = 3,
	EBotFocusType_MAX = 4
};

// Object: Enum Solarland.ENgaiMLType
enum class ENgaiMLType : uint8_t {
	None = 0,
	OnlyImitationLearning = 1,
	OnlyReinforcementLearning = 2,
	Both = 3,
	ENgaiMLType_MAX = 4
};

// Object: Enum Solarland.EBotAIType
enum class EBotAIType : uint8_t {
	BehaviorTree = 0,
	ImitationLearning = 1,
	ReinforcementLearning = 2,
	MAX = 3
};

// Object: Enum Solarland.EPopLocationType
enum class EPopLocationType : uint8_t {
	Default = 0,
	ShowFight = 1,
	Guarantee = 2,
	EPopLocationType_MAX = 3
};

// Object: Enum Solarland.ESolarBotTimelineTriggerAction
enum class ESolarBotTimelineTriggerAction : uint8_t {
	None = 0,
	Add = 1,
	Remove = 2,
	Clear = 3,
	ESolarBotTimelineTriggerAction_MAX = 4
};

// Object: Enum Solarland.ESolarBotTimelineFilterParameterType
enum class ESolarBotTimelineFilterParameterType : uint8_t {
	None = 0,
	MoreThan = 1,
	LessThan = 2,
	Equal = 3,
	NotEqual = 4,
	Contain = 5,
	NotContain = 6,
	Radius = 7,
	Target = 8,
	ESolarBotTimelineFilterParameterType_MAX = 9
};

// Object: Enum Solarland.ESolarBotTimelineFilterType
enum class ESolarBotTimelineFilterType : uint8_t {
	None = 0,
	RankPoint = 1,
	Equipment = 2,
	Disengagement = 3,
	KillNum = 4,
	DamageNum = 5,
	ItemNum = 6,
	SkillCoolingDown = 7,
	SurroundingTeammate = 8,
	SurroundingEnemy = 9,
	ESolarBotTimelineFilterType_MAX = 10
};

// Object: Enum Solarland.ESolarBotTimelineAIDataSettingType
enum class ESolarBotTimelineAIDataSettingType : uint8_t {
	None = 0,
	Health = 1,
	Shield = 2,
	ESolarBotTimelineAIDataSettingType_MAX = 3
};

// Object: Enum Solarland.ESolarBotTimelineWeaponPartType
enum class ESolarBotTimelineWeaponPartType : uint8_t {
	None = 0,
	Muzzle = 1,
	Grip = 2,
	Clip = 3,
	Scope = 4,
	GunStock = 5,
	ESolarBotTimelineWeaponPartType_MAX = 6
};

// Object: Enum Solarland.ESolarBotTimelineEquipmentSettingType
enum class ESolarBotTimelineEquipmentSettingType : uint8_t {
	None = 0,
	PrimaryWeapon = 1,
	SecondaryWeapon = 2,
	Shield = 3,
	VerticalJet = 4,
	HorizontalJet = 5,
	SummonGun = 6,
	ESolarBotTimelineEquipmentSettingType_MAX = 7
};

// Object: Enum Solarland.ESolarBotTimelineTriggerType
enum class ESolarBotTimelineTriggerType : uint8_t {
	None = 0,
	Timeline = 1,
	Guarantee = 2,
	ESolarBotTimelineTriggerType_MAX = 3
};

// Object: Enum Solarland.ESolarBotWarmSystemType
enum class ESolarBotWarmSystemType : uint8_t {
	Regular = 0,
	Script = 1,
	Newcome = 2,
	Unknown = 3,
	ESolarBotWarmSystemType_MAX = 4
};

// Object: Enum Solarland.EBotShotTargetCtlType
enum class EBotShotTargetCtlType : uint8_t {
	Player = 0,
	Bot = 1,
	Any = 2,
	EBotShotTargetCtlType_MAX = 3
};

// Object: Enum Solarland.EBotShotTargetType
enum class EBotShotTargetType : uint8_t {
	Character = 0,
	Vehicle = 1,
	SummonItem = 2,
	Any = 3,
	EBotShotTargetType_MAX = 4
};

// Object: Enum Solarland.ESearchTargetType
enum class ESearchTargetType : uint8_t {
	Other = 0,
	TreasureBox = 1,
	DeathBox = 2,
	ItemSpawner = 3,
	ShieldUpgradeItemShop = 4,
	ESearchTargetType_MAX = 5
};

// Object: Enum Solarland.EPoisonEscapeStrategy
enum class EPoisonEscapeStrategy : uint8_t {
	Random = 0,
	MoveWhenPoisonClose = 1,
	MoveWhenCircleStartsShrinking = 2,
	MoveWhenNewCircleAppears = 3,
	EPoisonEscapeStrategy_MAX = 4
};

// Object: Enum Solarland.ELootStrategy
enum class ELootStrategy : uint8_t {
	None = 0,
	LootZoneStrategy = 1,
	SafeLocationStrategy = 2,
	ELootStrategy_MAX = 3
};

// Object: Enum Solarland.ERequestDirectorInfo
enum class ERequestDirectorInfo : uint8_t {
	None = 0,
	ParachutePoint = 1,
	LootPoint = 2,
	RetreatPoint = 3,
	SeekEnemy = 4,
	ERequestDirectorInfo_MAX = 5
};

// Object: Enum Solarland.EBotReviveMethod
enum class EBotReviveMethod : uint8_t {
	ByReviveItem = 0,
	DirectlyRebirth = 1,
	Preserve = 2,
	EBotReviveMethod_MAX = 3
};

// Object: Enum Solarland.EBotCountAdjustStrategy
enum class EBotCountAdjustStrategy : uint8_t {
	None = 0,
	BySafeAreaIndex = 1,
	EBotCountAdjustStrategy_MAX = 2
};

// Object: Enum Solarland.EParachuteAssignType
enum class EParachuteAssignType : uint8_t {
	None = 0,
	V1 = 1,
	V2 = 2,
	EParachuteAssignType_MAX = 3
};

// Object: Enum Solarland.ERequestResult
enum class ERequestResult : uint8_t {
	None = 0,
	Rejection = 1,
	Responded = 2,
	RequestFailed = 3,
	ERequestResult_MAX = 4
};

// Object: Enum Solarland.EBotOnVehicleFireType
enum class EBotOnVehicleFireType : uint8_t {
	EBotOnVehicleFireType_None = 0,
	EBotOnVehicleFireType_FireOn = 1,
	EBotOnVehicleFireType_FireOnDelayOff = 2,
	EBotOnVehicleFireType_MAX = 3
};

// Object: Enum Solarland.EBotOnVehicleStopType
enum class EBotOnVehicleStopType : uint8_t {
	EBotOnVehicleStopType_None = 0,
	EBotOnVehicleStopType_Delay = 1,
	EBotOnVehicleStopType_Stop = 2,
	EBotOnVehicleStopType_MAX = 3
};

// Object: Enum Solarland.EBotFirePolicy
enum class EBotFirePolicy : uint8_t {
	AlwaysFire = 0,
	FirstRoughMoveDone = 1,
	FirstPreciseMoveDone = 2,
	PreciseMoveOrGreater = 3,
	FollowMoveOrGreater = 4,
	OnlyWhenHitSimulatedTarget = 5,
	OnlyWhenHitLockedTarget = 6,
	EBotFirePolicy_MAX = 7
};

// Object: Enum Solarland.EBotStateDebugType
enum class EBotStateDebugType : uint8_t {
	Idle = 0,
	SearchSupplies = 1,
	InBattle = 2,
	MoveToWarmService = 3,
	EscapingPoison = 4,
	Dying = 5,
	Dead = 6,
	EBotStateDebugType_MAX = 7
};

// Object: Enum Solarland.EBotActionState
enum class EBotActionState : uint8_t {
	EBotActionState_Sprint = 0,
	EBotActionState_Crouch = 1,
	EBotActionState_MAX = 2
};

// Object: Enum Solarland.EBotBunkerType
enum class EBotBunkerType : uint8_t {
	Invalid = 0,
	FullSize = 1,
	HalfSize = 2,
	EBotBunkerType_MAX = 3
};

// Object: Enum Solarland.EBotTeamVehicleDrivePolicy
enum class EBotTeamVehicleDrivePolicy : uint8_t {
	DirectlyMove = 0,
	HoldAndWaitPassenger = 1,
	MoveAndTakePassenger = 2,
	EBotTeamVehicleDrivePolicy_MAX = 3
};

// Object: Enum Solarland.EPoisonResponseType
enum class EPoisonResponseType : uint8_t {
	NoResponse = 0,
	LowPriority = 1,
	HighPriority = 2,
	Immediately = 3,
	EPoisonResponseType_MAX = 4
};

// Object: Enum Solarland.ESolarTaskScoringItemType
enum class ESolarTaskScoringItemType : uint8_t {
	None = 0,
	CurrentHP = 1,
	IfSelfInBattle = 2,
	IfSelfInSafeArea = 3,
	IfSelfInPoisonCircle = 4,
	TimeToEnterSafeArea = 5,
	TimeToEnterPoisonCircleXPoisonDamage = 6,
	IfRelativeActorInSafeArea = 7,
	IfRelativeActorInPoisonCircle = 8,
	IfRescueTargetIsPlayer = 9,
	TimeToMovetoRescueTarget = 10,
	DistanceFromRescueTargetToSafeArea = 11,
	DistanceFromRescueTargetToPoisonCircleXPoisonDamage = 12,
	IfRescuingThisTarget = 13,
	IfRescuingOtherTarget = 14,
	TimePoisonToRescueTarget = 15,
	CurrentPoisonDamage = 16,
	ESolarTaskScoringItemType_MAX = 17
};

// Object: Enum Solarland.ESolarTeamTaskType
enum class ESolarTeamTaskType : uint8_t {
	RescueTeammate = 0,
	ESolarTeamTaskType_MAX = 1
};

// Object: Enum Solarland.EJetTaskFinishMode
enum class EJetTaskFinishMode : uint8_t {
	AfterResponded = 0,
	AfterDone = 1,
	EJetTaskFinishMode_MAX = 2
};

// Object: Enum Solarland.EJetPackMode
enum class EJetPackMode : uint8_t {
	Horizontal = 0,
	Vertical = 1,
	EJetPackMode_MAX = 2
};

// Object: Enum Solarland.EJumpTaskFinishMode
enum class EJumpTaskFinishMode : uint8_t {
	AfterResponded = 0,
	AfterApex = 1,
	AfterDone = 2,
	EJumpTaskFinishMode_MAX = 3
};

// Object: Enum Solarland.EBotShootTargetType
enum class EBotShootTargetType : uint8_t {
	Player = 0,
	Bot = 1,
	Vehicle = 2,
	Monster = 3,
	EBotShootTargetType_MAX = 4
};

// Object: Enum Solarland.ERoleAbilityTargetType
enum class ERoleAbilityTargetType : uint8_t {
	SingleTargetLocation = 0,
	SingleTargetActor = 1,
	MultipleTargets = 2,
	ERoleAbilityTargetType_MAX = 3
};

// Object: Enum Solarland.ECameraShakeDurationType
enum class ECameraShakeDurationType : uint8_t {
	Fixed = 0,
	Infinite = 1,
	Custom = 2,
	ECameraShakeDurationType_MAX = 3
};

// Object: Enum Solarland.ECameraShakeUpdateResultFlags
enum class ECameraShakeUpdateResultFlags : uint8_t {
	ApplyAsAbsolute = 1,
	SkipAutoScale = 2,
	SkipAutoPlaySpace = 4,
	Default = 0,
	ECameraShakeUpdateResultFlags_MAX = 5
};

// Object: Enum Solarland.ECameraShakePlaySpace
enum class ECameraShakePlaySpace : uint8_t {
	CameraLocal = 0,
	World = 1,
	UserDefined = 2,
	ECameraShakePlaySpace_MAX = 3
};

// Object: Enum Solarland.ECruiseStatePrivate
enum class ECruiseStatePrivate : uint8_t {
	None = 0,
	Start = 1,
	CanParachute = 2,
	ForceParachute = 3,
	End = 4,
	ECruiseStatePrivate_MAX = 5
};

// Object: Enum Solarland.ECatBodyStatus
enum class ECatBodyStatus : uint8_t {
	None = 0,
	FlyToHost = 1,
	Hover = 2,
	FlyToLand = 3,
	ECatBodyStatus_MAX = 4
};

// Object: Enum Solarland.EInteractionState
enum class EInteractionState : uint8_t {
	None = 0,
	Mark = 1,
	Interact = 2,
	EInteractionState_MAX = 3
};

// Object: Enum Solarland.EAntiCheatType
enum class EAntiCheatType : uint8_t {
	ShootingAtInvalidTime = 0,
	CheckLastShotWeapon = 1,
	ShootWhileNoAmmo = 2,
	ShootIntervalInvalid = 3,
	InvalidLaser = 4,
	ShootWhileOverload = 5,
	CheckRealShot = 6,
	VerifyHitInValid = 7,
	ReloadTooFast = 8,
	CanisterShotAbnormal = 9,
	EAntiCheatType_MAX = 10
};

// Object: Enum Solarland.ERoleAbilityCancelPhase
enum class ERoleAbilityCancelPhase : uint8_t {
	None = 0,
	Pressing = 1,
	Continuous = 2,
	All = 3,
	ERoleAbilityCancelPhase_MAX = 4
};

// Object: Enum Solarland.EMovementComponentEnableType
enum class EMovementComponentEnableType : uint8_t {
	Default = 0,
	Dying = 1,
	OnLevelStreaming = 2,
	OnLoadingScreen = 3,
	EMovementComponentEnableType_MAX = 4
};

// Object: Enum Solarland.EAntiCheatGameEvents
enum class EAntiCheatGameEvents : uint8_t {
	ServerFire = 0,
	ServerHit = 1,
	ServerKill = 2,
	ServerKilled = 3,
	ClientFire = 4,
	ClientHit = 5,
	ClientKill = 6,
	ClientKilled = 7,
	ClientHitDown = 8,
	ClientBeHitDown = 9,
	ClientTick = 10,
	ServerTick = 11,
	ClientBeginPlay = 12,
	ServerBeginPlay = 13,
	ClientEndPlay = 14,
	ServerEndPlay = 15,
	EventMax = 16,
	EAntiCheatGameEvents_MAX = 17
};

// Object: Enum Solarland.EClipAttachType
enum class EClipAttachType : uint8_t {
	Weapon = 0,
	CharacterLeftHand = 1,
	CharacterRightHand = 2,
	EClipAttachType_MAX = 3
};

// Object: Enum Solarland.EBattleTriggeredVoiceType
enum class EBattleTriggeredVoiceType : uint8_t {
	KillEnemy = 0,
	KillDown = 1,
	InCombatReloading = 2,
	EBattleTriggeredVoiceType_MAX = 3
};

// Object: Enum Solarland.EStopCamShakeFlags
enum class EStopCamShakeFlags : uint8_t {
	None = 0,
	All = 1,
	CacheOnly = 2,
	OnOpenScope = 4,
	EStopCamShakeFlags_MAX = 5
};

// Object: Enum Solarland.ECamShakeType
enum class ECamShakeType : uint8_t {
	Default = 0,
	JumpBegin = 1,
	JumpEndLight = 2,
	JumpEndHeavy = 3,
	FullBodyMeleeWithTarget = 4,
	FullBodyMeleeWithoutTarget = 5,
	TacticalDodgeForward = 6,
	TacticalDodgeBackward = 7,
	TacticalDodgeLeft = 8,
	TacticalDodgeRight = 9,
	GrapplingHook = 10,
	ECamShakeType_MAX = 11
};

// Object: Enum Solarland.EGunsightCameraSwitchMode
enum class EGunsightCameraSwitchMode : uint8_t {
	CloseScope = 0,
	CloseShoulderShot = 1,
	OpenShoulderShot = 2,
	OpenScope = 3,
	EGunsightCameraSwitchMode_MAX = 4
};

// Object: Enum Solarland.ESolarCameraSmoothType
enum class ESolarCameraSmoothType : uint8_t {
	Default = 0,
	Instant = 1,
	Constant = 2,
	EaseOut = 3,
	EaseInEaseOut = 4,
	FloatCurve = 5,
	ESolarCameraSmoothType_MAX = 6
};

// Object: Enum Solarland.ESolarAbilityStage
enum class ESolarAbilityStage : uint8_t {
	None = 0,
	Startup = 1,
	Action = 2,
	Recovery = 3,
	ESolarAbilityStage_MAX = 4
};

// Object: Enum Solarland.EReconnectionStatus
enum class EReconnectionStatus : uint8_t {
	None = 0,
	Reconnecting = 1,
	Reconnected = 2,
	EReconnectionStatus_MAX = 3
};

// Object: Enum Solarland.EAnimDirection
enum class EAnimDirection : uint8_t {
	AnimNone = 0,
	AnimForward = 1,
	AnimBackward = 2,
	AnimLeft = 3,
	AnimRight = 4,
	EAnimDirection_MAX = 5
};

// Object: Enum Solarland.ESkydiveEffectLifetime
enum class ESkydiveEffectLifetime : uint8_t {
	DuringFlying = 0,
	DuringLanding = 1,
	DuringWholeSkydiving = 2,
	ESkydiveEffectLifetime_MAX = 3
};

// Object: Enum Solarland.ERandomIdleAnimState
enum class ERandomIdleAnimState : uint8_t {
	None = 0,
	IdleWithoutWeapon = 1,
	IdleWithWeapon = 2,
	CrouchWithoutWeapon = 3,
	CrouchWithWeapon = 4,
	ERandomIdleAnimState_MAX = 5
};

// Object: Enum Solarland.EZiplineType
enum class EZiplineType : uint8_t {
	None = 0,
	Horizontal = 1,
	Vertical = 2,
	EZiplineType_MAX = 3
};

// Object: Enum Solarland.EUpdateWarmServiceEventType
enum class EUpdateWarmServiceEventType : uint8_t {
	None = 0,
	CharacterUpgrade = 1,
	WeaponUpgrade = 2,
	ShieldUpgrade = 3,
	SuperAbilityReady = 4,
	TacticalAbilityReady = 5,
	BattleStation = 6,
	EUpdateWarmServiceEventType_MAX = 7
};

// Object: Enum Solarland.EMassInVisibilityWarningType
enum class EMassInVisibilityWarningType : uint8_t {
	None = 0,
	Character = 1,
	Vehicle = 2,
	EMassInVisibilityWarningType_MAX = 3
};

// Object: Enum Solarland.EMeleeType
enum class EMeleeType : uint8_t {
	None = 0,
	Stand = 1,
	Sprint = 2,
	Air = 4,
	Crouch = 8,
	SlideTackle = 16,
	Special = 32,
	EMeleeType_MAX = 33
};

// Object: Enum Solarland.EHitRecoverType
enum class EHitRecoverType : uint8_t {
	None = 0,
	Normal = 1,
	DeathVerge = 2,
	DuckDunk = 4,
	C4Explosive = 8,
	CounterForce = 16,
	RexCombo = 32,
	HumanCannonFallenSlam = 64,
	EHitRecoverType_MAX = 65
};

// Object: Enum Solarland.EBResurrectionState
enum class EBResurrectionState : uint8_t {
	NoneState = 0,
	WaitForApply = 1,
	NotApply = 2,
	Resurrected = 3,
	WaitForResurrect = 4,
	GiveUp = 5,
	Timeout = 6,
	AllTeammatesDied = 7,
	EBResurrectionState_MAX = 8
};

// Object: Enum Solarland.EDroppedItemType
enum class EDroppedItemType : uint8_t {
	Weapons = 0,
	WeaponParts = 1,
	Consumables = 2,
	Equipments = 3,
	EDroppedItemType_MAX = 4
};

// Object: Enum Solarland.EEnergyState
enum class EEnergyState : uint8_t {
	NORMAL = 0,
	SKY = 1,
	PILE = 2,
	BOX = 4,
	E2M = 8,
	M2E = 16,
	EEnergyState_MAX = 17
};

// Object: Enum Solarland.EEnergyUsage
enum class EEnergyUsage : uint8_t {
	Box = 0,
	Weapon = 1,
	Ability = 2,
	Jet = 3,
	Pile = 4,
	Armor = 5,
	Shield = 6,
	Sky = 7,
	RadarStation = 8,
	ElectricShop = 9,
	DeathBox = 10,
	EEnergyUsage_MAX = 11
};

// Object: Enum Solarland.EShieldAutoRechargeStopReason
enum class EShieldAutoRechargeStopReason : uint8_t {
	SwitchShield = 0,
	OnWeaponFire = 1,
	OnHit = 2,
	Die = 3,
	ShieldFull = 4,
	ManualRecharge = 5,
	EShieldAutoRechargeStopReason_MAX = 6
};

// Object: Enum Solarland.ETransitionMontageInterruptType
enum class ETransitionMontageInterruptType : uint8_t {
	SpeedChange_ToIdle = 0,
	SpeedChange_ToRun = 1,
	SpeedChange_ToSprint = 2,
	DirectionChange = 3,
	ETransitionMontageInterruptType_MAX = 4
};

// Object: Enum Solarland.EHandsUsingState
enum class EHandsUsingState : uint8_t {
	Free = 0,
	OnlyLeft = 1,
	OnlyRight = 2,
	Both = 3,
	EHandsUsingState_MAX = 4
};

// Object: Enum Solarland.EAnimBaseMoveTransitionState
enum class EAnimBaseMoveTransitionState : uint8_t {
	None = 0,
	Stand = 1,
	Crouch = 2,
	SlideTackle = 3,
	Crawl = 4,
	Jump = 5,
	Fall = 6,
	Zipline = 7,
	JetFly = 8,
	WallRun = 9,
	SkywardFly = 10,
	Launch = 11,
	Cruise = 12,
	Skydive = 13,
	Swim = 14,
	InVehicle = 15,
	EAnimBaseMoveTransitionState_MAX = 16
};

// Object: Enum Solarland.EAnimBaseMoveState
enum class EAnimBaseMoveState : uint8_t {
	None = 0,
	BaseGround = 1,
	SlideTackle = 2,
	Crawl = 3,
	InAir = 4,
	InWater = 5,
	InVehicle = 6,
	EAnimBaseMoveState_MAX = 7
};

// Object: Enum Solarland.ECharacterInteractType
enum class ECharacterInteractType : uint8_t {
	None = 0,
	Item = 1,
	Interactable = 2,
	Zipline = 3,
	RevivableDeathBox = 4,
	RescueTeammate = 5,
	ECharacterInteractType_MAX = 6
};

// Object: Enum Solarland.EPoseMode
enum class EPoseMode : uint8_t {
	Stand = 0,
	Crouch = 1,
	Crawl = 2,
	FallingCrawl = 3,
	Skydive = 4,
	SlideTackle = 5,
	EPoseMode_MAX = 6
};

// Object: Enum Solarland.ESkillSpeedChangeType
enum class ESkillSpeedChangeType : uint8_t {
	SlowDown = 0,
	SpeedUp = 1,
	ESkillSpeedChangeType_MAX = 2
};

// Object: Enum Solarland.EHellStrikeGAAction
enum class EHellStrikeGAAction : uint8_t {
	E_EndAbility = 0,
	E_EnterSecondStage = 1,
	E_MAX = 2
};

// Object: Enum Solarland.EPickUpTargetType
enum class EPickUpTargetType : uint8_t {
	Invalid = 0,
	Item = 1,
	Weapon = 2,
	TreasureItem = 3,
	HomeItem = 4,
	BoxHomeItem = 5,
	EPickUpTargetType_MAX = 6
};

// Object: Enum Solarland.ESolarExpBehaviorType
enum class ESolarExpBehaviorType : uint8_t {
	SurvivalTime = 1,
	Kills = 2,
	Assists = 3,
	Selfhealing = 4,
	TeammateHealing = 5,
	Unpacking = 6,
	CollectElectricity = 7,
	PickExpPack = 8,
	EveryDamageDealt = 9,
	ESolarExpBehaviorType_MAX = 10
};

// Object: Enum Solarland.ESolarCheckButtonSelectType
enum class ESolarCheckButtonSelectType : uint8_t {
	None = 0,
	Next = 1,
	Prev = 2,
	ESolarCheckButtonSelectType_MAX = 3
};

// Object: Enum Solarland.EClassType
enum class EClassType : uint8_t {
	None = 0,
	Assault = 1,
	Defence = 2,
	Support = 3,
	Scout = 4,
	Control = 5,
	EClassType_MAX = 6
};

// Object: Enum Solarland.EConsoleEffectType
enum class EConsoleEffectType : uint8_t {
	Start = 0,
	Cancel = 1,
	Finished = 2,
	CooldownFinished = 3,
	EConsoleEffectType_MAX = 4
};

// Object: Enum Solarland.EConsoleDeviceState
enum class EConsoleDeviceState : uint8_t {
	Available = 0,
	InUse = 1,
	Cooldown = 2,
	Illegal = 3,
	EConsoleDeviceState_MAX = 4
};

// Object: Enum Solarland.ESolarDamageTextType
enum class ESolarDamageTextType : uint8_t {
	DamageTextType_None = 0,
	DamageTextType_Common = 1,
	DamageTextType_Headshot = 2,
	DamageTextType_HitShield = 3,
	DamageTextType_HeadshotWithShield = 4,
	DamageTextType_HitVehicle = 5,
	DamageTextType_HitVehicleWeak = 6,
	DamageTextType_BrokenShiled = 7,
	DamageTextType_BrokenShieldWithHeadShot = 8,
	DamageTextType_HitSummonItem = 9,
	DamageTextType_HitUnilateralEnergyShield = 10,
	DamageTextType_HitInteractionDoor = 11,
	DamageTextType_MAX = 12
};

// Object: Enum Solarland.EUIDragSourceType
enum class EUIDragSourceType : uint8_t {
	Default = 0,
	Weapon1 = 1,
	Weapon2 = 2,
	Weapon3 = 3,
	PickupList = 4,
	BackpackConsumable = 5,
	BackpackEquip = 6,
	BackpackWeaponPart = 7,
	DefaultPickupList = 8,
	BackpackPickupListItem = 9,
	BackpackPickupListWeapon = 10,
	BackpackPickupListWeaponPart = 11,
	EUIDragSourceType_MAX = 12
};

// Object: Enum Solarland.EShopStatisticType
enum class EShopStatisticType : uint8_t {
	OnActivated = 0,
	OnUpgradeWeapon = 1,
	OnPurchaseItem = 2,
	OnItemRefresh = 3,
	OnUpgradeShield = 4,
	EShopStatisticType_MAX = 5
};

// Object: Enum Solarland.EShopModelAnimType
enum class EShopModelAnimType : uint8_t {
	Idle = 0,
	Upgrade = 1,
	Purchase = 2,
	EShopModelAnimType_MAX = 3
};

// Object: Enum Solarland.ESpringRewardLimitType
enum class ESpringRewardLimitType : uint8_t {
	NoLimit = 0,
	ShieldLevel = 1,
	CharacterLevel = 2,
	GoldWeaponNum = 3,
	EmptyPartSlotNum = 4,
	ESpringRewardLimitType_MAX = 5
};

// Object: Enum Solarland.EExpSpringPointState
enum class EExpSpringPointState : uint8_t {
	PreOpen = 0,
	Opening = 1,
	Actived = 2,
	Closed = 3,
	EExpSpringPointState_MAX = 4
};

// Object: Enum Solarland.EExpSpringPointCloseResult
enum class EExpSpringPointCloseResult : uint8_t {
	NobodyActive = 0,
	NoActive = 1,
	Actived = 2,
	Force = 3,
	EExpSpringPointCloseResult_MAX = 4
};

// Object: Enum Solarland.ESolarExpSpringChestLevel
enum class ESolarExpSpringChestLevel : uint8_t {
	None = 0,
	Level1 = 1,
	Level2 = 2,
	Level3 = 3,
	ESolarExpSpringChestLevel_MAX = 4
};

// Object: Enum Solarland.EFocusLockType
enum class EFocusLockType : uint8_t {
	Enemy = 0,
	Teammate = 1,
	Custom = 2,
	EFocusLockType_MAX = 3
};

// Object: Enum Solarland.AIVehicleState
enum class AIVehicleState : uint8_t {
	AIVehicleState_Forward = 0,
	AIVehicleState_ReverseSolveBlock = 1,
	AIVehicleState_SolveBlockFoward = 2,
	AIVehicleState_ReverseToTarget = 3,
	AIVehicleState_MAX = 4
};

// Object: Enum Solarland.EAntiCheatReportType
enum class EAntiCheatReportType : uint8_t {
	Player = 0,
	Weapon = 1,
	Vehicle = 2,
	EAntiCheatReportType_MAX = 3
};

// Object: Enum Solarland.EActiveEffectDurationChangeProxy
enum class EActiveEffectDurationChangeProxy : uint8_t {
	MaintainCurrent = 0,
	MaintainRemain = 1,
	ScalingCurrent = 2,
	EActiveEffectDurationChangeProxy_MAX = 3
};

// Object: Enum Solarland.ESolarGAInputID
enum class ESolarGAInputID : uint8_t {
	None = 0,
	SkillOne = 1,
	SkillTwo = 2,
	SkillThree = 3,
	Jump = 4,
	Crouch = 5,
	Sprint = 6,
	JetVertical = 7,
	JetHorizontal = 8,
	Parachute = 9,
	SkydiveAccelerate = 10,
	Fire = 11,
	OutVehicle = 12,
	SkillTest = 13,
	HoldBreath = 14,
	SwitchShootMode = 15,
	ESolarGAInputID_MAX = 16
};

// Object: Enum Solarland.ELogChannel
enum class ELogChannel : uint8_t {
	General = 0,
	Mode = 1,
	Hunt = 2,
	BattleRoyal = 3,
	Weapon = 4,
	Character = 5,
	Vehicle = 6,
	Camera = 7,
	Animation = 8,
	Physics = 9,
	Inventory = 10,
	World = 11,
	ELogChannel_MAX = 12
};

// Object: Enum Solarland.ESolarGameUserSettingPart
enum class ESolarGameUserSettingPart : uint8_t {
	PickupSettings = 0,
	GraphicsSettings = 1,
	WeaponSettings = 2,
	LanguageSettings = 3,
	SoundSettings = 4,
	BasicSettings = 5,
	PersonalitySettings = 6,
	SensitivitySettings = 7,
	ShakeSettings = 8,
	DriverSettings = 9,
	ChatOperatorSettings = 10,
	CharacterVoiceSettings = 11,
	SensitivitySettingsKeyboard = 12,
	SensitivitySettingsGamepad = 13,
	KeyboardControlSettings = 14,
	GamepadSettings = 15,
	GamepadAdvancedSettings = 16,
	RtcBattleGroundSettings = 17,
	PickupSettingsPC = 18,
	VaultSettings = 19,
	All = 20,
	ESolarGameUserSettingPart_MAX = 21
};

// Object: Enum Solarland.ESolarColorBlindMode
enum class ESolarColorBlindMode : uint8_t {
	Default = 0,
	RedGreen = 1,
	RedBlue = 2,
	YellowGreen = 3,
	ESolarColorBlindMode_MAX = 4
};

// Object: Enum Solarland.ESolarPostProcessingEffectsLevel
enum class ESolarPostProcessingEffectsLevel : uint8_t {
	Default = 0,
	Low = 1,
	Medium = 2,
	High = 3,
	ExtraHigh = 4,
	ESolarPostProcessingEffectsLevel_MAX = 5
};

// Object: Enum Solarland.ESolarPointLightShadowDetailsLevel
enum class ESolarPointLightShadowDetailsLevel : uint8_t {
	Off = 0,
	Low = 1,
	Medium = 2,
	High = 3,
	VeryHigh = 4,
	ExtraHigh = 5,
	ESolarPointLightShadowDetailsLevel_MAX = 6
};

// Object: Enum Solarland.ESolarRayTracingLevel
enum class ESolarRayTracingLevel : uint8_t {
	Off = 0,
	HighPerformance = 1,
	HighQuality = 2,
	ESolarRayTracingLevel_MAX = 3
};

// Object: Enum Solarland.ESolarNvdiaReflexLevel
enum class ESolarNvdiaReflexLevel : uint8_t {
	Off = 0,
	On = 1,
	High = 2,
	ESolarNvdiaReflexLevel_MAX = 3
};

// Object: Enum Solarland.ESolarGraphicQuality
enum class ESolarGraphicQuality : uint8_t {
	Default = 0,
	Low = 1,
	Medium = 2,
	High = 3,
	ESolarGraphicQuality_MAX = 4
};

// Object: Enum Solarland.ESolarFPS
enum class ESolarFPS : uint8_t {
	Default = 0,
	FPS30 = 1,
	FPS60 = 2,
	FPS90 = 3,
	FPS120 = 4,
	FPS144 = 5,
	FPS240 = 6,
	FPS360 = 7,
	FPS500 = 8,
	SameWithMonitor = 9,
	ESolarFPS_MAX = 10
};

// Object: Enum Solarland.ESolarGraphicsMode
enum class ESolarGraphicsMode : uint8_t {
	Default = 0,
	HighPerformance = 1,
	HighQuality = 2,
	ESolarGraphicsMode_MAX = 3
};

// Object: Enum Solarland.ESolarAimModeType
enum class ESolarAimModeType : uint8_t {
	Default = 0,
	Change = 1,
	Press = 2,
	ESolarAimModeType_MAX = 3
};

// Object: Enum Solarland.ESolarContentScaleFactorLevel
enum class ESolarContentScaleFactorLevel : uint8_t {
	ESCSFL_NONE = 0,
	ESCSFL_Low = 1,
	ESCSFL_Mid = 2,
	ESCSFL_High = 3,
	ESCSFL_HighEnd = 4,
	ESCSFL_MAX = 5
};

// Object: Enum Solarland.EHoverCraftHitType
enum class EHoverCraftHitType : uint8_t {
	Default = 0,
	HoverCraftVehicle = 1,
	HoverVehicle = 2,
	LeggedVehicle = 3,
	WheeledVehicle = 4,
	EHoverCraftHitType_MAX = 5
};

// Object: Enum Solarland.EInputKeyMappingType
enum class EInputKeyMappingType : uint8_t {
	KeyAndMouse1 = 0,
	KeyAndMouse2 = 1,
	Gamepad = 2,
	Count = 3,
	EInputKeyMappingType_MAX = 4
};

// Object: Enum Solarland.EInputActionContextType
enum class EInputActionContextType : uint8_t {
	Pawn = 0,
	Controller = 1,
	LevelScriptActor = 2,
	UserWidget = 3,
	Count = 4,
	EInputActionContextType_MAX = 5
};

// Object: Enum Solarland.EInputActionFlags
enum class EInputActionFlags : uint8_t {
	None = 0,
	FlagBigMap = 1,
	FlagBackpack = 2,
	FlagChatWheel = 3,
	FlagParachute = 4,
	FlagSpectate = 5,
	FlagTeamDeath = 6,
	FlagRelive = 7,
	FlagBuddyWheel = 8,
	FlagBlockAll = 31,
	FlagMax = 32,
	EInputActionFlags_MAX = 33
};

// Object: Enum Solarland.ESolarInputContextType
enum class ESolarInputContextType : uint8_t {
	MouseAndKeyboard = 0,
	Gamepad = 1,
	Count = 2,
	ESolarInputContextType_MAX = 3
};

// Object: Enum Solarland.EInteractableActorType
enum class EInteractableActorType : uint8_t {
	None = 0,
	AirDropBox = 1,
	CarPad = 2,
	ConsoleDevice = 3,
	DragonSummoner = 4,
	BasicChest = 5,
	IntermediateChest = 6,
	AdvancedChest = 7,
	HotSpringChest = 8,
	BouncePad = 9,
	AdvancedBouncePad = 10,
	RespawnDevice = 11,
	ShieldUpgrade = 12,
	SkywardDive = 13,
	VendingMachine = 14,
	TacticalChest = 15,
	AdvancedTacticalChest = 16,
	ZipLine = 17,
	TreasureVaultDoor = 18,
	Door = 19,
	EInteractableActorType_MAX = 20
};

// Object: Enum Solarland.EShowWayType
enum class EShowWayType : uint8_t {
	Ground = 0,
	Airdrop = 1,
	EShowWayType_MAX = 2
};

// Object: Enum Solarland.EAirDropMovementState
enum class EAirDropMovementState : uint8_t {
	None = 0,
	Waiting = 1,
	FreeFalling = 2,
	UniformFalling = 3,
	DecelerateFalling = 4,
	Landing = 5,
	Landed = 6,
	Removed = 7,
	EAirDropMovementState_MAX = 8
};

// Object: Enum Solarland.EDoorEffectType
enum class EDoorEffectType : uint8_t {
	Block = 0,
	HitDoor = 1,
	Destroy = 2,
	OpenDoor = 3,
	HitLatch = 4,
	CloseDoor = 5,
	EDoorEffectType_MAX = 6
};

// Object: Enum Solarland.EInteractionDoorState
enum class EInteractionDoorState : uint8_t {
	Closed = 0,
	Rotating = 1,
	Opened = 2,
	Destroyed = 3,
	EInteractionDoorState_MAX = 4
};

// Object: Enum Solarland.ESolarInteractionType
enum class ESolarInteractionType : uint8_t {
	Invalid = 0,
	RescueTeammate = 1,
	ReviveTeammate = 2,
	OpenAirdrop = 3,
	ESolarInteractionType_MAX = 4
};

// Object: Enum Solarland.ESolarInteractionCommandType
enum class ESolarInteractionCommandType : uint8_t {
	InteractDoor = 0,
	Zipline = 1,
	FollowDance = 2,
	RoleAbility = 3,
	ExpDevice = 4,
	ESolarInteractionCommandType_MAX = 5
};

// Object: Enum Solarland.EPanelBackpackDisplayStyle
enum class EPanelBackpackDisplayStyle : uint8_t {
	Hidden = 0,
	Key_Tab = 1,
	Key_Interact = 2,
	EPanelBackpackDisplayStyle_MAX = 3
};

// Object: Enum Solarland.EInteractiveKeyState
enum class EInteractiveKeyState : uint8_t {
	None = 0,
	UnArm = 1,
	EquipGun = 2,
	InVehicle = 3,
	OpenScope = 4,
	Holding = 5,
	Swimming = 6,
	FollowFly = 7,
	SingleOrDirectFly = 8,
	Cruise = 9,
	SupperSkillUI = 10,
	LowHP = 11,
	DeathVerge = 12,
	Dead = 13,
	Max = 14
};

// Object: Enum Solarland.ESolarItemPrivilegeType
enum class ESolarItemPrivilegeType : uint8_t {
	NONE = 0,
	NETBAR = 1,
	ESolarItemPrivilegeType_MAX = 2
};

// Object: Enum Solarland.ESolarItemShowType
enum class ESolarItemShowType : uint8_t {
	NOTSHOW = 0,
	SHOW = 1,
	ESolarItemShowType_MAX = 2
};

// Object: Enum Solarland.ESolarRedHintType
enum class ESolarRedHintType : uint8_t {
	ZERO = 0,
	SHOW = 1,
	HIDE = 2,
	ESolarRedHintType_MAX = 3
};

// Object: Enum Solarland.ESolarItemOwnType
enum class ESolarItemOwnType : uint8_t {
	ZERO = 0,
	NOOWN = 1,
	OWN = 2,
	ESolarItemOwnType_MAX = 3
};

// Object: Enum Solarland.ESolarItemBuyType
enum class ESolarItemBuyType : uint8_t {
	ZERO = 0,
	NOBUY = 1,
	BUY = 2,
	CANTBUY = 3,
	ESolarItemBuyType_MAX = 4
};

// Object: Enum Solarland.ESolarItemUseType
enum class ESolarItemUseType : uint8_t {
	ZERO = 0,
	NOUSE = 1,
	USING = 2,
	ESolarItemUseType_MAX = 3
};

// Object: Enum Solarland.ESolarItemLimitType
enum class ESolarItemLimitType : uint8_t {
	ZERO = 0,
	NOLIMIT = 1,
	LIMITING = 2,
	ESolarItemLimitType_MAX = 3
};

// Object: Enum Solarland.ESolarItemMarkType
enum class ESolarItemMarkType : uint8_t {
	ZERO = 0,
	NOMARK = 1,
	MARKED = 2,
	ESolarItemMarkType_MAX = 3
};

// Object: Enum Solarland.ESolarItemDownloadType
enum class ESolarItemDownloadType : uint8_t {
	ZERO = 0,
	NOTDOWNLOAD = 1,
	DOWNLOADING = 2,
	DOWNLOADED = 3,
	PAUSING = 4,
	ESolarItemDownloadType_MAX = 5
};

// Object: Enum Solarland.ESolarItemLockType
enum class ESolarItemLockType : uint8_t {
	ZERO = 0,
	NOLOCK = 1,
	LOCKED = 2,
	TEMPUNLOCK = 3,
	ESolarItemLockType_MAX = 4
};

// Object: Enum Solarland.ESolarItemSelectType
enum class ESolarItemSelectType : uint8_t {
	ZERO = 0,
	NOTSELECT = 1,
	SELECTED = 2,
	ESolarItemSelectType_MAX = 3
};

// Object: Enum Solarland.ESolarItemQualityType
enum class ESolarItemQualityType : uint8_t {
	ZERO = 0,
	N = 1,
	R = 2,
	SR = 3,
	SSR = 4,
	SSRPLUS = 5,
	MR = 6,
	ESolarItemQualityType_MAX = 7
};

// Object: Enum Solarland.EBurstMethod
enum class EBurstMethod : uint8_t {
	ParabCurveFitting = 0,
	GoldenSpiral = 1,
	EBurstMethod_MAX = 2
};

// Object: Enum Solarland.EDroppingMethod
enum class EDroppingMethod : uint8_t {
	DIRECT_DROP = 0,
	LONG_PRESS_TO_DROP = 1,
	CANNOT_DROP = 2,
	EDroppingMethod_MAX = 3
};

// Object: Enum Solarland.EItemConfirmID
enum class EItemConfirmID : int32_t {
	DropExtraEnergyConfirmID = 110003,
	ReplaceExtraEnergyConfirmID = 110004,
	DropEnergyModuleConfirmID = 110007,
	ReplaceEnergyModuleConfirmID = 110008,
	EItemConfirmID_MAX = 110009
};

// Object: Enum Solarland.EItemLocalTextID
enum class EItemLocalTextID : uint8_t {
	LevelNumTextID = 40,
	EItemLocalTextID_MAX = 41
};

// Object: Enum Solarland.ESpawnStage
enum class ESpawnStage : uint8_t {
	STAGE_NONE = 0,
	STAGE_READY = 1,
	STAGE_BATTLE = 2,
	STAGE_ALL = 3,
	STAGE_MAX = 4
};

// Object: Enum Solarland.EOutcomeType
enum class EOutcomeType : uint8_t {
	None = 0,
	Single = 1,
	Pool = 2,
	DynamicPool = 3,
	EOutcomeType_MAX = 4
};

// Object: Enum Solarland.EItemSourceType
enum class EItemSourceType : uint8_t {
	None = 0,
	DeathBox = 1,
	Discard = 2,
	Spawner = 3,
	TacticalBox = 4,
	TacticalBoxHighLevel = 5,
	AirdropBox = 6,
	ExpSpring = 7,
	TreasureBox = 8,
	ExpDevice = 9,
	SlotMachine = 10,
	Max = 11
};

// Object: Enum Solarland.EItemDiscardState
enum class EItemDiscardState : uint8_t {
	EItemDiscardState_DEFAULT = 0,
	EItemDiscardState_DEATHBOX = 1,
	EItemDiscardState_MAX = 2
};

// Object: Enum Solarland.EItemState
enum class EItemState : uint8_t {
	EItemState_NONE = 0,
	EItemState_POSSESS = 1,
	EItemState_DISCARD = 2,
	EItemState_MAX = 3
};

// Object: Enum Solarland.ERandomPackAdjustType
enum class ERandomPackAdjustType : uint8_t {
	None = 0,
	SelfAdjust = 1,
	TeammateAdjust = 2,
	ERandomPackAdjustType_MAX = 3
};

// Object: Enum Solarland.ESpawnerDropType
enum class ESpawnerDropType : uint8_t {
	Outcome = 0,
	RandomPack = 1,
	ESpawnerDropType_MAX = 2
};

// Object: Enum Solarland.ETreasureBoxSpawnType
enum class ETreasureBoxSpawnType : uint8_t {
	SingleRandom = 0,
	Group = 1,
	ETreasureBoxSpawnType_MAX = 2
};

// Object: Enum Solarland.ESpawnerLevel
enum class ESpawnerLevel : uint8_t {
	LEVEL_1 = 0,
	LEVEL_2 = 1,
	LEVEL_3 = 2,
	LEVEL_4 = 3,
	LEVEL_5 = 4,
	LEVEL_6 = 5,
	LEVEL_7 = 6,
	LEVEL_MAX = 7
};

// Object: Enum Solarland.ESpawnerType
enum class ESpawnerType : uint8_t {
	NONE = 0,
	NORMAL = 1,
	TREASUREBOX = 2,
	AIRDROP = 3,
	VEHICLE = 4,
	TACTICALBOX = 5,
	MISSIONSPAWNER = 6,
	SLOTMACHINE = 7,
	ESpawnerType_MAX = 8
};

// Object: Enum Solarland.EWalkingDirection
enum class EWalkingDirection : uint8_t {
	None = 0,
	Forward = 1,
	Backward = 2,
	Left = 4,
	Right = 8,
	EWalkingDirection_MAX = 9
};

// Object: Enum Solarland.EVehicleShrinkCapsuleExtent
enum class EVehicleShrinkCapsuleExtent : uint8_t {
	SHRINK_None = 0,
	SHRINK_RadiusCustom = 1,
	SHRINK_HeightCustom = 2,
	SHRINK_AllCustom = 3,
	SHRINK_MAX = 4
};

// Object: Enum Solarland.EVehicleLocomotionState
enum class EVehicleLocomotionState : uint8_t {
	Walk = 0,
	Run = 1,
	Sprint = 2,
	Max = 3
};

// Object: Enum Solarland.ESolarBuildConfiguration
enum class ESolarBuildConfiguration : uint8_t {
	Unknown = 0,
	Debug = 1,
	Development = 2,
	Shipping = 3,
	Test = 4,
	ESolarBuildConfiguration_MAX = 5
};

// Object: Enum Solarland.EElementVisibilityType
enum class EElementVisibilityType : uint8_t {
	Visible = 0,
	Hidden = 1,
	EElementVisibilityType_MAX = 2
};

// Object: Enum Solarland.EElementStateType
enum class EElementStateType : uint8_t {
	Normal = 0,
	Suspend = 1,
	EElementStateType_MAX = 2
};

// Object: Enum Solarland.ESolarMapElementPropertyType
enum class ESolarMapElementPropertyType : uint8_t {
	String = 0,
	Float = 1,
	Int = 2,
	Bool = 3,
	ESolarMapElementPropertyType_MAX = 4
};

// Object: Enum Solarland.ESGameMode_ElementType
enum class ESGameMode_ElementType : uint8_t {
	PlayerStart = 0,
	ItemSpawner = 1,
	AirDrop = 2,
	ChargingPile = 3,
	JumpPad = 4,
	CarPad = 5,
	Vehicle = 6,
	Poison = 7,
	Custom = 8,
	ESGameMode_MAX = 9
};

// Object: Enum Solarland.EMapType
enum class EMapType : uint8_t {
	Default = 0,
	Map01 = 1,
	Map02 = 2,
	Map03 = 3,
	TDM01 = 4,
	TDM02 = 5,
	Solo = 6,
	TrainingCourse = 7,
	Tutorial = 8,
	EMapType_MAX = 9
};

// Object: Enum Solarland.EBattlePromptType
enum class EBattlePromptType : uint8_t {
	None = 0,
	Player = 1,
	Vehicle = 4,
	Move = 8,
	Fire = 16,
	HeavyWeapon = 32,
	Crouch = 64,
	Skydive = 128,
	PlayerStep = 9,
	VehicleMove = 12,
	PlayerCrouchMove = 73,
	PlayerSkydive = 137,
	PlayerFire = 17,
	VehicleFire = 20,
	PlayerHeavyFire = 49,
	VehicleHeavyFire = 52,
	EBattlePromptType_MAX = 138
};

// Object: Enum Solarland.EBuddyExposeDurationPolicy
enum class EBuddyExposeDurationPolicy : uint8_t {
	None = 0,
	HasDuration = 1,
	Infinite = 2,
	EBuddyExposeDurationPolicy_MAX = 3
};

// Object: Enum Solarland.EMeshWidgetOrderGroup
enum class EMeshWidgetOrderGroup : uint8_t {
	None = 0,
	WarningMarker = 1,
	MarkerBG = 2,
	ItemMarker = 3,
	NormalMarker = 4,
	Character = 5,
	Skill = 6,
	SkillBG = 7,
	Interact = 8,
	Selecting = 9,
	Max = 10
};

// Object: Enum Solarland.EMeshWidgetDisplayType
enum class EMeshWidgetDisplayType : uint8_t {
	Icon = 0,
	Flash = 1,
	Diffuse = 2,
	EMeshWidgetDisplayType_MAX = 3
};

// Object: Enum Solarland.EReviveMarkStatus
enum class EReviveMarkStatus : uint8_t {
	Normal = 0,
	Playing = 1,
	EReviveMarkStatus_MAX = 2
};

// Object: Enum Solarland.EAirdropMarkStatus
enum class EAirdropMarkStatus : uint8_t {
	Default = 0,
	Coming = 1,
	Available = 2,
	Opening = 3,
	Opened = 4,
	EAirdropMarkStatus_MAX = 5
};

// Object: Enum Solarland.EMarkerType
enum class EMarkerType : uint8_t {
	None = 0,
	AirDrop = 1,
	RedZone = 2,
	VehicleMark = 3,
	ShieldUpgradeShop = 4,
	ReviveTeammate = 5,
	BlueCircle = 6,
	ExpSpring = 7,
	EnemyFire = 8,
	AIDog = 9,
	SummonOwl = 10,
	Doppelganger = 11,
	SuperDoppelganger = 12,
	VehicleSpawn = 13,
	SummonActorCircle = 14,
	WorldMarkIcon = 15,
	HellStrikeCaster = 16,
	WorldMarkIconBG = 17,
	NeutralMonster = 18,
	RespawnDevice = 19,
	TacticalBox = 20,
	TrapMine = 21,
	EnemyScanned = 22,
	EMarkerType_MAX = 23
};

// Object: Enum Solarland.EMapObjectPointType
enum class EMapObjectPointType : uint8_t {
	None = 0,
	ShieldShop = 1,
	KongMingLantern = 2,
	TacticalBuilding = 3,
	SkywardDive = 4,
	RespawnDevice = 5,
	VendingMachine = 6,
	Buddy = 7,
	EMapObjectPointType_MAX = 8
};

// Object: Enum Solarland.EMissionEndType
enum class EMissionEndType : uint8_t {
	InProgress = 0,
	Completed = 1,
	Faild = 2,
	PlayerAllDead = 3,
	TimeOut = 4,
	MissTarget = 5,
	EMissionEndType_MAX = 6
};

// Object: Enum Solarland.EMissionSpawnType
enum class EMissionSpawnType : uint8_t {
	AcceptForAll = 0,
	AcceptForSelf = 1,
	EMissionSpawnType_MAX = 2
};

// Object: Enum Solarland.EMissionContent
enum class EMissionContent : uint8_t {
	Chest = 0,
	Worship = 1,
	MULTIPLE_TASK_MAX = 2,
	Pursuit = 3,
	TASK_MAX = 4,
	Escape = 5,
	None = 6,
	EMissionContent_MAX = 7
};

// Object: Enum Solarland.EMissionType
enum class EMissionType : uint8_t {
	NonHUD = 0,
	Explore = 1,
	Battle = 2,
	Survive = 3,
	EMissionType_MAX = 4
};

// Object: Enum Solarland.EMissionOwner
enum class EMissionOwner : uint8_t {
	Personal = 0,
	Teams = 1,
	None = 2,
	EMissionOwner_MAX = 3
};

// Object: Enum Solarland.EMonsterVisualNotice
enum class EMonsterVisualNotice : uint8_t {
	Suspicion = 0,
	Alarm = 1,
	EMonsterVisualNotice_MAX = 2
};

// Object: Enum Solarland.ESolarMonsterBehaviorState
enum class ESolarMonsterBehaviorState : uint8_t {
	None = 0,
	Patrol = 1,
	Alert = 2,
	Battle = 3,
	BackToBase = 4,
	ESolarMonsterBehaviorState_MAX = 5
};

// Object: Enum Solarland.ENavLinkType
enum class ENavLinkType : uint8_t {
	Jet = 0,
	Vault = 1,
	Zipline = 2,
	WallRun = 3,
	Door = 4,
	None = 5,
	ENavLinkType_MAX = 6
};

// Object: Enum Solarland.EOwnerType
enum class EOwnerType : uint8_t {
	None = 0,
	Vehicle = 1,
	TreasureBox = 2,
	EOwnerType_MAX = 3
};

// Object: Enum Solarland.EWeedType
enum class EWeedType : uint8_t {
	ValidMark = 0,
	InvalidMark = 1,
	AutoGenerateMark = 2,
	EWeedType_MAX = 3
};

// Object: Enum Solarland.ERestState
enum class ERestState : uint8_t {
	AT_REST = 0,
	JUST_STARTED_MOVING = 1,
	MOVING = 2,
	ERestState_MAX = 3
};

// Object: Enum Solarland.EExtrapolationMode
enum class EExtrapolationMode : uint8_t {
	UNLIMITED = 0,
	LIMITED = 1,
	NONE = 2,
	EExtrapolationMode_MAX = 3
};

// Object: Enum Solarland.ESyncMode
enum class ESyncMode : uint8_t {
	NONE = 0,
	X = 1,
	Y = 2,
	Z = 4,
	XY = 3,
	XZ = 5,
	YZ = 6,
	XYZ = 7,
	ESyncMode_MAX = 8
};

// Object: Enum Solarland.ENightComesState
enum class ENightComesState : uint8_t {
	None = 0,
	Begin = 1,
	Keep = 2,
	End = 3,
	ENightComesState_MAX = 4
};

// Object: Enum Solarland.EPerceivableEffectAreaTendency
enum class EPerceivableEffectAreaTendency : uint8_t {
	Hostile = 0,
	Neutral = 1,
	Friendly = 2,
	EPerceivableEffectAreaTendency_MAX = 3
};

// Object: Enum Solarland.EPerceivableEffectAreaType
enum class EPerceivableEffectAreaType : uint8_t {
	Unknow = 0,
	SmokeGrenade = 1,
	NightCome = 2,
	AutomaticTurret = 3,
	AIDog = 4,
	BlackHole = 5,
	Incendiary = 6,
	EnergyBubble = 7,
	SummonWall = 8,
	UAVShield = 9,
	UAVRescue = 10,
	HealPile = 11,
	Doppelganger = 12,
	EPerceivableEffectAreaType_MAX = 13
};

// Object: Enum Solarland.EPickupListItemType
enum class EPickupListItemType : uint8_t {
	None = 0,
	Single = 1,
	Merge = 2,
	Customize = 3,
	EPickupListItemType_MAX = 4
};

// Object: Enum Solarland.EPickupListChangeReason
enum class EPickupListChangeReason : uint8_t {
	Default = 0,
	Backpack = 1,
	Skill = 2,
	Weapon = 3,
	EPickupListChangeReason_MAX = 4
};

// Object: Enum Solarland.ESolarPileType
enum class ESolarPileType : uint8_t {
	ChargingPile = 0,
	HealPile = 1,
	ESolarPileType_MAX = 2
};

// Object: Enum Solarland.EChargingChannel
enum class EChargingChannel : uint8_t {
	MAIN = 0,
	EXTRA = 1,
	EChargingChannel_MAX = 2
};

// Object: Enum Solarland.EPileHealingType
enum class EPileHealingType : uint8_t {
	None = 0,
	Health = 1,
	Armor = 2,
	EPileHealingType_MAX = 3
};

// Object: Enum Solarland.EJankBoundType
enum class EJankBoundType : uint8_t {
	JANK_BOUND_TYPE_NONE = 0,
	JANK_BOUND_TYPE_GT = 1,
	JANK_BOUND_TYPE_RT = 2,
	JANK_BOUND_TYPE_RHI = 3,
	JANK_BOUND_TYPE_GPU = 4,
	JANK_BOUND_TYPE_MAX = 5
};

// Object: Enum Solarland.ELevelTickType
enum class ELevelTickType : uint8_t {
	LEVELTICK_TimeOnly = 0,
	LEVELTICK_ViewportsOnly = 1,
	LEVELTICK_All = 2,
	LEVELTICK_PauseTick = 3,
	LEVELTICK_MAX = 4
};

// Object: Enum Solarland.ESolarEigenvalueCollectorMode
enum class ESolarEigenvalueCollectorMode : uint8_t {
	NoRecord = 0,
	GlobalRecord = 1,
	TargetRecord = 2,
	ESolarEigenvalueCollectorMode_MAX = 3
};

// Object: Enum Solarland.EEVDamageType
enum class EEVDamageType : uint8_t {
	Unknown = 0,
	Weapon = 1,
	Skill = 2,
	Vehicle = 3,
	Punch = 4,
	EEVDamageType_MAX = 5
};

// Object: Enum Solarland.EInteractiveFlag
enum class EInteractiveFlag : uint8_t {
	None = 0,
	DanceLearder = 1,
	EInteractiveFlag_MAX = 2
};

// Object: Enum Solarland.ESolarPlayerSensitivitysType
enum class ESolarPlayerSensitivitysType : uint8_t {
	None = 0,
	HoldWeaponSensitivity = 1,
	WeaponShootSensitivity = 2,
	WeaponShoulderNoShotSensitivity = 3,
	WeaponShoulderShotSensitivity = 4,
	WeaponSkillSensitivity = 5,
	SightSensitivity = 6,
	ScopeSensitivity = 7,
	ScopeShootSensitivity = 8,
	VehicleDriverSensitivity = 9,
	VehicleFireSensitivity = 10,
	SuperSkillSensitivity = 11,
	TacticalSkillSensitivity = 12,
	ESolarPlayerSensitivitysType_MAX = 13
};

// Object: Enum Solarland.ECharacterOwnerType
enum class ECharacterOwnerType : uint8_t {
	CSITNone = 0,
	CSITOwn = 1,
	CSITExperience = 2,
	CSITLimit = 4,
	CSITPrivilege = 8,
	ECharacterOwnerType_MAX = 9
};

// Object: Enum Solarland.EPersonalRewardType
enum class EPersonalRewardType : uint8_t {
	OnlyOneSelf = 0,
	Team = 1,
	ScopeTeam = 2,
	EPersonalRewardType_MAX = 3
};

// Object: Enum Solarland.EGainEXPFromDmgType
enum class EGainEXPFromDmgType : uint8_t {
	None = 0,
	DmgToCharacter = 1,
	DmgToVehicle = 2,
	DmgToSummon = 3,
	EGainEXPFromDmgType_MAX = 4
};

// Object: Enum Solarland.EWeaponPartVisibilityChangeFlag
enum class EWeaponPartVisibilityChangeFlag : uint8_t {
	Default = 0,
	BySignificance = 1,
	ByHold = 2,
	ByOpenScope = 3,
	ByPartsVisibility = 4,
	EWeaponPartVisibilityChangeFlag_MAX = 5
};

// Object: Enum Solarland.EWeaponPartSlotMode
enum class EWeaponPartSlotMode : uint8_t {
	Empty = 0,
	Exist = 1,
	EWeaponPartSlotMode_MAX = 2
};

// Object: Enum Solarland.EWeaponAttributeParamType
enum class EWeaponAttributeParamType : uint8_t {
	Base = 0,
	BonusA = 1,
	BonusB = 2,
	EWeaponAttributeParamType_MAX = 3
};

// Object: Enum Solarland.EWeaponAdsAttributeType
enum class EWeaponAdsAttributeType : uint8_t {
	CrossHairKick = 0,
	SingleShotKickLocX = 1,
	SingleShotKickRotPitch = 2,
	SingleShotKickRotYaw = 3,
	CameraShake = 4,
	IdleBreath = 5,
	EWeaponAdsAttributeType_MAX = 6
};

// Object: Enum Solarland.EWeaponAttributeType
enum class EWeaponAttributeType : uint8_t {
	HoriRecoilFixed = 0,
	HoriRecoilRandom = 1,
	VertRecoilFixed = 2,
	VertRecoilRandom = 3,
	HoriSpreadBase = 4,
	HoriSpreadIncrement = 5,
	VertSpreadBase = 6,
	VertSpreadIncrement = 7,
	ExtraClipAmmo = 8,
	ReloadSpeed = 9,
	AdsEnterSpeed = 10,
	BaseDamageLevel = 11,
	EWeaponAttributeType_MAX = 12
};

// Object: Enum Solarland.EPlayerWeaponOperationType
enum class EPlayerWeaponOperationType : uint8_t {
	None = 0,
	Replace = 1,
	Drop = 2,
	Swap = 3,
	Equip = 4,
	StartUnequip = 5,
	FinishUnequip = 6,
	OpenScope = 7,
	CloseScope = 8,
	MarkScopeOpenDone = 9,
	EPlayerWeaponOperationType_MAX = 10
};

// Object: Enum Solarland.EEquipWeaponActionType
enum class EEquipWeaponActionType : uint8_t {
	Normal = 0,
	Quick = 1,
	PickUp = 2,
	EEquipWeaponActionType_MAX = 3
};

// Object: Enum Solarland.ESwitchWeaponAnimFlowType
enum class ESwitchWeaponAnimFlowType : uint8_t {
	None = 0,
	LargeToLarge = 18,
	LargeToSmall = 20,
	LargeToFist = 17,
	FistToLarge = 10,
	SmallToSmall = 36,
	SmallToLarge = 34,
	SmallToFist = 33,
	FistToSmall = 12,
	ESwitchWeaponAnimFlowType_MAX = 37
};

// Object: Enum Solarland.ESolarWeaponUnequipClassify
enum class ESolarWeaponUnequipClassify : uint8_t {
	Fist = 1,
	LargeToBackpack = 2,
	SmallToLeg = 4,
	ESolarWeaponUnequipClassify_MAX = 5
};

// Object: Enum Solarland.EPlayerWeaponEquipStatus
enum class EPlayerWeaponEquipStatus : uint8_t {
	None = 0,
	Holding = 1,
	PendingToHang = 2,
	Hanging = 3,
	EPlayerWeaponEquipStatus_MAX = 4
};

// Object: Enum Solarland.EPlayerWeaponType
enum class EPlayerWeaponType : uint8_t {
	AssualtRifle = 0,
	SubmachineGun = 1,
	Shotgun = 2,
	SniperRifle = 3,
	ShooterRifle = 4,
	HandGun = 5,
	LightMachineGun = 6,
	Other = 7,
	EPlayerWeaponType_MAX = 8
};

// Object: Enum Solarland.ESolarPreLoadingLobbyMatchConfigType
enum class ESolarPreLoadingLobbyMatchConfigType : uint8_t {
	NONE = 0,
	COMMON = 1,
	LEVEL = 2,
	GAMEMODE = 3,
	OTHER = 4,
	ESolarPreLoadingLobbyMatchConfigType_MAX = 5
};

// Object: Enum Solarland.EPreservedBotType
enum class EPreservedBotType : uint8_t {
	PendingInit = 0,
	OnCall = 1,
	WaitingForSend = 2,
	Killer = 3,
	WaitingToDie = 4,
	EPreservedBotType_MAX = 5
};

// Object: Enum Solarland.ESolarProjBulletCollisionType
enum class ESolarProjBulletCollisionType : uint8_t {
	Shape = 0,
	Box = 1,
	ESolarProjBulletCollisionType_MAX = 2
};

// Object: Enum Solarland.ESkillProjectileBounceType
enum class ESkillProjectileBounceType : uint8_t {
	Default = 0,
	AngleAndCount = 1,
	StopOnActor = 2,
	OnlyBounceOnActor = 3,
	ESkillProjectileBounceType_MAX = 4
};

// Object: Enum Solarland.EMapScanRadarNoticeType
enum class EMapScanRadarNoticeType : uint8_t {
	ScanFinish = 0,
	FoundNothing = 1,
	FoundEnemy = 2,
	BeFound = 3,
	FoundEnemyMobile = 4,
	BeFoundMobile = 5,
	EnemyLocationTip = 6,
	RadarLocationTip = 7,
	EnemyLocationTipMobile = 8,
	RadarLocationTipMobile = 9,
	Max = 10
};

// Object: Enum Solarland.ERadarShape
enum class ERadarShape : uint8_t {
	Sphere = 0,
	Box = 1,
	Sphere3D = 2,
	ERadarShape_MAX = 3
};

// Object: Enum Solarland.ERadarStationState
enum class ERadarStationState : uint8_t {
	Invalid = 0,
	CanInteract = 1,
	Interacting = 2,
	CoolDown = 3,
	ERadarStationState_MAX = 4
};

// Object: Enum Solarland.ERedHintPath
enum class ERedHintPath : uint8_t {
	None = 0,
	Root = 1,
	Social = 2,
	Arsenal = 3,
	Arsenal_Weapon = 4,
	Arsenal_Skin = 5,
	Arsenal_Part = 6,
	Shop = 7,
	Mail = 8,
	Capsulers = 9,
	Capsulers_Detail = 10,
	Capsulers_Story = 11,
	Capsulers_Skin = 12,
	Capsulers_LevelUp = 13,
	Capsulers_Pose = 14,
	Capsulers_PoseTab = 15,
	Capsulers_BG = 16,
	Capsulers_BGTab = 17,
	Capsulers_BGFrame = 18,
	Capsulers_BGFrameTab = 19,
	Capsulers_DeathBox = 20,
	Capsulers_DeathBoxTab = 21,
	Capsulers_Voice = 22,
	Capsulers_VoiceKillVoice = 23,
	Capsulers_VoiceTeamDie = 24,
	Capsulers_VoiceTopKill = 25,
	Capsulers_VoiceParachute = 26,
	Capsulers_VoiceBattleTab = 27,
	Capsulers_VoicePersonalityTab = 28,
	Capsulers_VoiceTab = 29,
	WareHouse = 30,
	Task = 31,
	Activity = 32,
	RankFight = 33,
	Achievement = 34,
	EditBusinessCard = 35,
	PlayerInfo = 36,
	GameMode = 37,
	Raffle = 38,
	Vehicle = 39,
	Vehicle_Skin = 40,
	Clan = 41,
	ClanPermission = 42,
	Collection = 43,
	Tournament = 44,
	VipCard = 45,
	ClanMember = 46,
	Max = 47,
	BattlePass = 48
};

// Object: Enum Solarland.ERedHintValueType
enum class ERedHintValueType : uint8_t {
	Single = 0,
	MultiValue = 1,
	ERedHintValueType_MAX = 2
};

// Object: Enum Solarland.ECharacterSkydivingState
enum class ECharacterSkydivingState : uint8_t {
	Invalid = 0,
	EveryBattle = 1,
	Flying = 2,
	Skydiving = 3,
	Landing = 4,
	ECharacterSkydivingState_MAX = 5
};

// Object: Enum Solarland.EReplayDamageSourceType
enum class EReplayDamageSourceType : uint8_t {
	None = 0,
	Weapon = 1,
	Vehicle = 2,
	Skill = 3,
	EReplayDamageSourceType_MAX = 4
};

// Object: Enum Solarland.EAutoDirectorActivityType
enum class EAutoDirectorActivityType : uint8_t {
	None = 0,
	PlayerWeaponHit = 1,
	PlayerWeaponDown = 2,
	PlayerWeaponKill = 3,
	PickupItem = 4,
	DriveVehicle = 5,
	VehicleWeaponHit = 6,
	VehicleWeaponDown = 7,
	VehicleWeaponKill = 8,
	BandagePlayer = 9,
	RevivePlayer = 10,
	UseTacticalAbility = 11,
	UseUltimateAbility = 12,
	AbilityDown = 13,
	AbilityKill = 14,
	StartSkydive = 15,
	EAutoDirectorActivityType_MAX = 16
};

// Object: Enum Solarland.EAutoDirectorCameraMode
enum class EAutoDirectorCameraMode : uint8_t {
	Free = 0,
	Follow = 1,
	EAutoDirectorCameraMode_MAX = 2
};

// Object: Enum Solarland.EReplayFindSpectateTargetApproach
enum class EReplayFindSpectateTargetApproach : uint8_t {
	None = 0,
	SuggestTarget = 1,
	LastTarget = 2,
	ClosestToCamera = 3,
	FirstInPlayerList = 4,
	EReplayFindSpectateTargetApproach_MAX = 5
};

// Object: Enum Solarland.EPlayerHighlightMarkType
enum class EPlayerHighlightMarkType : uint8_t {
	B = 0,
	A = 1,
	S = 2,
	Ex = 3,
	Max = 4
};

// Object: Enum Solarland.EHighlightFileType
enum class EHighlightFileType : uint8_t {
	Data = 0,
	Flag = 1,
	Keep = 2,
	Playing = 3,
	Writing = 4,
	EHighlightFileType_MAX = 5
};

// Object: Enum Solarland.EReplayPlayingFinishReason
enum class EReplayPlayingFinishReason : uint8_t {
	Normal = 0,
	GMForce = 1,
	StreamerDownloadChunkTimeout = 2,
	StreamerServiceUnavailable = 3,
	EReplayPlayingFinishReason_MAX = 4
};

// Object: Enum Solarland.EClassRepNodeMapping
enum class EClassRepNodeMapping : uint8_t {
	Missing = 0,
	NotRouted = 1,
	CustomRelevancy = 2,
	RelevantAllConnections = 3,
	RelevantAllConnections_Dormancy = 4,
	RelevantAllConnections_FastShared = 5,
	Spatialize_Static = 6,
	Spatialize_Dynamic = 7,
	Spatialize_Dormancy = 8,
	EClassRepNodeMapping_MAX = 9
};

// Object: Enum Solarland.ELightBeamType
enum class ELightBeamType : uint8_t {
	NoBeam = 0,
	AvailableBeam = 1,
	SelfBeam = 2,
	EnemyBeam = 3,
	ELightBeamType_MAX = 4
};

// Object: Enum Solarland.EIncreaseAndDecreaseTransitionMode
enum class EIncreaseAndDecreaseTransitionMode : uint8_t {
	Continuously = 0,
	BreakAndKeepLast = 1,
	EIncreaseAndDecreaseTransitionMode_MAX = 2
};

// Object: Enum Solarland.ESignalSystemSwitcher
enum class ESignalSystemSwitcher : uint8_t {
	Disable = 0,
	DomesticOnly = 1,
	ForeignOnly = 2,
	EnableBoth = 3,
	ESignalSystemSwitcher_MAX = 4
};

// Object: Enum Solarland.EDynamicPoisonState
enum class EDynamicPoisonState : uint8_t {
	None = 0,
	Warning = 1,
	Moving = 2,
	EDynamicPoisonState_MAX = 3
};

// Object: Enum Solarland.ESafeAreaNoticeType
enum class ESafeAreaNoticeType : uint8_t {
	ThirtySecondsWarning = 0,
	TenSecondsWarning = 1,
	ESafeAreaNoticeType_MAX = 2
};

// Object: Enum Solarland.EActorInSafeAreaStatus
enum class EActorInSafeAreaStatus : uint8_t {
	InSafeArea = 0,
	NotInSafeArea = 1,
	InTargetSafeArea = 2,
	EActorInSafeAreaStatus_MAX = 3
};

// Object: Enum Solarland.ESafeAreaStatus
enum class ESafeAreaStatus : uint8_t {
	None = 0,
	WaitingForStart = 1,
	WaitingForShrink = 2,
	Shrink = 4,
	ShrinkEnd = 8,
	Pause = 16,
	End = 32,
	Manual = 64,
	MovingToDynamicCenter = 128,
	NoEffect = 33,
	ESafeAreaStatus_MAX = 129
};

// Object: Enum Solarland.ENeverShowDuration
enum class ENeverShowDuration : uint8_t {
	Day = 0,
	Week = 1,
	Month = 2,
	Year = 3,
	Never = 4,
	None = 5,
	ENeverShowDuration_MAX = 6
};

// Object: Enum Solarland.ESettingSlotStyle
enum class ESettingSlotStyle : uint8_t {
	Default = 0,
	Toggle = 1,
	CheckBox = 2,
	Slider = 3,
	JumpBtn = 4,
	Title = 5,
	ESettingSlotStyle_MAX = 6
};

// Object: Enum Solarland.EShieldUpgradeItemShopState
enum class EShieldUpgradeItemShopState : uint8_t {
	None = 0,
	Upgrading = 1,
	Done = 2,
	EShieldUpgradeItemShopState_MAX = 3
};

// Object: Enum Solarland.EParticleOptimization
enum class EParticleOptimization : uint8_t {
	Origin = 0,
	LowPriorityOptimization = 1,
	MidPriorityOptimization = 2,
	HighPriorityOptimization = 3,
	UltraHighPriorityOptimization = 4,
	EParticleOptimization_MAX = 5
};

// Object: Enum Solarland.EMovablePadLimitationFlag
enum class EMovablePadLimitationFlag : uint8_t {
	None = 0,
	NoPress = 1,
	NoRelease = 2,
	NoMove = 4,
	NoPressAndRelease = 3,
	NoPressAndMove = 5,
	NoReleaseAndMove = 6,
	EMovablePadLimitationFlag_MAX = 7
};

// Object: Enum Solarland.ESolarEMPParticleType
enum class ESolarEMPParticleType : uint8_t {
	FadeIn = 0,
	FadeOut = 1,
	Loop = 2,
	ESolarEMPParticleType_MAX = 3
};

// Object: Enum Solarland.ESolarEMPForceFieldState
enum class ESolarEMPForceFieldState : uint8_t {
	None = 0,
	Ready = 1,
	Active = 2,
	End = 3,
	ESolarEMPForceFieldState_MAX = 4
};

// Object: Enum Solarland.EHookState
enum class EHookState : uint8_t {
	None = 0,
	Launching = 1,
	Hooked = 2,
	Retrieving = 3,
	EHookState_MAX = 4
};

// Object: Enum Solarland.EIncendiaryState
enum class EIncendiaryState : uint8_t {
	None = 0,
	Burning = 1,
	Destroyed = 2,
	EIncendiaryState_MAX = 3
};

// Object: Enum Solarland.EPenetrateGrenadeState
enum class EPenetrateGrenadeState : uint8_t {
	None = 0,
	Ready = 1,
	Damage = 2,
	Broken = 3,
	EPenetrateGrenadeState_MAX = 4
};

// Object: Enum Solarland.ETempShieldFXTriggerType
enum class ETempShieldFXTriggerType : uint8_t {
	None = 0,
	OnGiveTempShield = 1,
	OnRecoverCharacterShield = 2,
	ETempShieldFXTriggerType_MAX = 3
};

// Object: Enum Solarland.ETempShieldOverflowType
enum class ETempShieldOverflowType : uint8_t {
	ChargeTempShield = 0,
	ChargeShieldFirst = 1,
	ETempShieldOverflowType_MAX = 2
};

// Object: Enum Solarland.ESummonSkillType
enum class ESummonSkillType : uint8_t {
	E_QuickSummon = 0,
	E_PreviewSummon = 1,
	E_MAX = 2
};

// Object: Enum Solarland.ESolarSurroundLightningApplyType
enum class ESolarSurroundLightningApplyType : uint8_t {
	SurroundLightningApplyType_Character = 0,
	SurroundLightningApplyType_Vehicle = 1,
	SurroundLightningApplyType_Other = 2,
	SurroundLightningApplyType_MAX = 3
};

// Object: Enum Solarland.ESolarSkyIslandState
enum class ESolarSkyIslandState : uint8_t {
	PreOpen = 0,
	Open = 2,
	Close = 3,
	Destroy = 4,
	ESolarSkyIslandState_MAX = 5
};

// Object: Enum Solarland.ESlotMachineRewardQuality
enum class ESlotMachineRewardQuality : uint8_t {
	None = 0,
	Blue = 1,
	Purple = 2,
	Gold = 3,
	ESlotMachineRewardQuality_MAX = 4
};

// Object: Enum Solarland.ESlotMachineState
enum class ESlotMachineState : uint8_t {
	None = 0,
	Idle = 1,
	Tossing = 2,
	Drawing = 3,
	Resulting = 4,
	Bursting = 5,
	ESlotMachineState_MAX = 6
};

// Object: Enum Solarland.ESmokeGrenadeState
enum class ESmokeGrenadeState : uint8_t {
	Fly = 0,
	Smoke = 1,
	ESmokeGrenadeState_MAX = 2
};

// Object: Enum Solarland.ESmokeGrenadeSpawnType
enum class ESmokeGrenadeSpawnType : uint8_t {
	None = 0,
	Normal = 1,
	Devil = 2,
	ESmokeGrenadeSpawnType_MAX = 3
};

// Object: Enum Solarland.ESolarSmoothOption
enum class ESolarSmoothOption : uint8_t {
	Linear = 0,
	EaseInSine = 1,
	EaseOutSine = 2,
	EaseInOutSine = 3,
	EaseInQuad = 4,
	EaseOutQuad = 5,
	EaseInOutQuad = 6,
	EaseInCubic = 7,
	EaseOutCubic = 8,
	EaseInOutCubic = 9,
	EaseInQuart = 10,
	EaseOutQuart = 11,
	EaseInOutQuart = 12,
	EaseInQuint = 13,
	EaseOutQuint = 14,
	EaseInOutQuint = 15,
	EaseInExpo = 16,
	EaseOutExpo = 17,
	EaseInOutExpo = 18,
	Custom = 19,
	ESolarSmoothOption_MAX = 20
};

// Object: Enum Solarland.ESolarSpatialAudioRoomMaterial
enum class ESolarSpatialAudioRoomMaterial : uint8_t {
	Common = 10,
	Metal = 20,
	Tunnel = 30,
	ESolarSpatialAudioRoomMaterial_MAX = 31
};

// Object: Enum Solarland.ESolarSpatialAudioRoomSize
enum class ESolarSpatialAudioRoomSize : uint8_t {
	Room_Small = 10,
	Room_Medium = 20,
	Room_Large = 30,
	Room_UltraLarge = 40,
	Room_MAX = 41
};

// Object: Enum Solarland.ESpectatorMode
enum class ESpectatorMode : uint8_t {
	DeathWatch = 0,
	Replay = 1,
	ESpectatorMode_MAX = 2
};

// Object: Enum Solarland.EStrongholdType
enum class EStrongholdType : uint8_t {
	Default = 0,
	NormalPOI = 1,
	Skyland = 2,
	EStrongholdType_MAX = 3
};

// Object: Enum Solarland.EAIDogSoundGroup
enum class EAIDogSoundGroup : uint8_t {
	None = 0,
	SpawnSound = 1,
	DestroySound = 2,
	MoveMarkSound = 3,
	CommandAcceptSound = 4,
	CommandDeniedSound = 5,
	MoveBlockSound = 6,
	StartMoveLoopSound = 7,
	EndMoveLoopSound = 8,
	DestroyNoticeSound = 9,
	LevelUpSound = 10,
	UpgradedSound = 11,
	RecycleSound = 12,
	AlertSound = 13,
	ExitUpgradedSound = 14,
	EAIDogSoundGroup_MAX = 15
};

// Object: Enum Solarland.EAIDogTurretState
enum class EAIDogTurretState : uint8_t {
	Fire = 0,
	InReset = 1,
	Idle = 2,
	None = 3,
	EAIDogTurretState_MAX = 4
};

// Object: Enum Solarland.EAIDogDeadReason
enum class EAIDogDeadReason : uint8_t {
	HealthToZero = 0,
	Recycle = 1,
	AutoRecycle = 2,
	None = 3,
	EAIDogDeadReason_MAX = 4
};

// Object: Enum Solarland.EOrderMoveFeedback
enum class EOrderMoveFeedback : uint8_t {
	SummonerTooFar = 0,
	Failed = 1,
	AlreadyAtGoal = 2,
	NoPath = 3,
	DetourTooFar = 4,
	PartialPath = 5,
	FullPath = 6,
	Blocked = 7,
	Abort_Paralyzed = 8,
	Abort_BlackHole = 9,
	Affected_WindField = 10,
	ReachedGoal = 11,
	EOrderMoveFeedback_MAX = 12
};

// Object: Enum Solarland.ESummonFailedReason
enum class ESummonFailedReason : uint8_t {
	E_None = 0,
	E_RoomCheckFailed = 1,
	E_ForbiddenSurfacesFailed = 2,
	E_PhysMaterialFailed = 3,
	E_SurfaceActorClassFailed = 4,
	E_ChannelTestFailed = 5,
	E_WaterCheckFailed = 6,
	E_OverlapActorFailed = 7,
	E_PlaneEnoughFailed = 8,
	E_ValidateFailed = 9,
	E_ValidateStartLocationFailed = 10,
	E_ValidateTraceEndFailed = 11,
	E_ValidateTraceBlockFailed = 12,
	E_MAX = 13
};

// Object: Enum Solarland.ESolarSummonOwlMoveMode
enum class ESolarSummonOwlMoveMode : uint8_t {
	E_Stop = 0,
	E_ToPointPath = 1,
	E_CatchedMove = 2,
	E_TrackTarget = 3,
	E_MAX = 4
};

// Object: Enum Solarland.ETabControlListStyle
enum class ETabControlListStyle : uint8_t {
	None = 0,
	Text = 1,
	Icon = 2,
	ETabControlListStyle_MAX = 3
};

// Object: Enum Solarland.ETabControlListSlotType
enum class ETabControlListSlotType : uint8_t {
	Leaf = 0,
	Compound = 1,
	ETabControlListSlotType_MAX = 2
};

// Object: Enum Solarland.ESolarTablesEnum_CalculatingSign
enum class ESolarTablesEnum_CalculatingSign : uint8_t {
	Plus = 0,
	Multiplication = 1,
	Equal = 2,
	_Count = 3,
	ESolarTablesEnum_MAX = 4
};

// Object: Enum Solarland.ESolarTablesEnum_PartsType
enum class ESolarTablesEnum_PartsType : uint8_t {
	Muzzle = 0,
	Scope = 1,
	Clip = 2,
	Runes = 3,
	Grip = 4,
	GunStock = 5,
	Scope2x = 6,
	Scope4x = 7,
	Scope8x = 8,
	_Count = 9,
	ESolarTablesEnum_MAX = 10
};

// Object: Enum Solarland.ESolarTablesEnum_AccessoryType
enum class ESolarTablesEnum_AccessoryType : uint8_t {
	WeaponParts = 0,
	WeaponAmmo = 1,
	_Count = 2,
	ESolarTablesEnum_MAX = 3
};

// Object: Enum Solarland.ESolarTablesEnum_FireCostType
enum class ESolarTablesEnum_FireCostType : uint8_t {
	Descrete = 0,
	Continuous = 1,
	_Count = 2,
	ESolarTablesEnum_MAX = 3
};

// Object: Enum Solarland.ESolarTablesEnum_TriggerType
enum class ESolarTablesEnum_TriggerType : uint8_t {
	KeyDown = 0,
	KeyUp = 1,
	KeyHold = 2,
	_Count = 3,
	ESolarTablesEnum_MAX = 4
};

// Object: Enum Solarland.ESolarTablesEnum_TrajectoryType
enum class ESolarTablesEnum_TrajectoryType : uint8_t {
	Line = 0,
	LineGravity = 1,
	Curve = 2,
	Canister = 3,
	Beam = 4,
	Rocket = 5,
	VirtualBullet = 6,
	_Count = 7,
	ESolarTablesEnum_MAX = 8
};

// Object: Enum Solarland.ESolarTablesEnum_FireMethodType
enum class ESolarTablesEnum_FireMethodType : uint8_t {
	Bullet = 0,
	Skill = 1,
	SummonBullet = 2,
	_Count = 3,
	ESolarTablesEnum_MAX = 4
};

// Object: Enum Solarland.ESolarTablesEnum_WeaponType
enum class ESolarTablesEnum_WeaponType : uint8_t {
	AssualtRifle = 0,
	Submachinegun = 1,
	Shotgun = 2,
	Sniper = 3,
	Vehicle = 4,
	ItemWeapon = 5,
	SummonWeapon = 6,
	AntiVehicle = 7,
	_Count = 8,
	ESolarTablesEnum_MAX = 9
};

// Object: Enum Solarland.ESolarTablesEnum_TrigerType
enum class ESolarTablesEnum_TrigerType : uint8_t {
	GameTime = 0,
	AliveCount = 1,
	RealTime = 2,
	MatchRoundTime = 3,
	GameWorldTime = 4,
	_Count = 5,
	ESolarTablesEnum_MAX = 6
};

// Object: Enum Solarland.ESolarTablesEnum_CategoryType
enum class ESolarTablesEnum_CategoryType : uint8_t {
	CategoryType_None = 0,
	CategoryType_Reco = 1,
	CategoryType_Character = 2,
	CategoryType_CharacterSkin = 3,
	CategoryType_WeaponSkin = 4,
	CategoryType_Capsule = 5,
	CategoryType_Bag = 6,
	CategoryType_Tail = 7,
	CategoryType_Home = 8,
	CategoryType_Others = 9,
	_Count = 10,
	ESolarTablesEnum_MAX = 11
};

// Object: Enum Solarland.ESolarTablesEnum_ShareType
enum class ESolarTablesEnum_ShareType : uint8_t {
	ActionType_None = 0,
	ShareType_RankShare = 1,
	ShareType_BattlePassShare = 2,
	ShareType_AchieveItemShare = 3,
	ShareType_ScoreShare = 4,
	ShareType_LoginActivityShare = 5,
	ShareType_MedalShare = 6,
	ShareType_UserGrowthShare = 7,
	ShareType_FollowCommunity = 8,
	ShareType_PersonalHistory = 9,
	ShareType_IdolShare = 10,
	_Count = 11,
	ESolarTablesEnum_MAX = 12
};

// Object: Enum Solarland.ESolarTablesEnum_ReplayShortcutCategory
enum class ESolarTablesEnum_ReplayShortcutCategory : uint8_t {
	Camera = 0,
	UI = 1,
	Advance = 2,
	_Count = 3,
	ESolarTablesEnum_MAX = 4
};

// Object: Enum Solarland.ESolarTablesEnum_ReplayShortcutShowType
enum class ESolarTablesEnum_ReplayShortcutShowType : uint8_t {
	Never = 0,
	General = 1,
	ViewControl = 2,
	FreeView = 3,
	Spectate = 4,
	Lock = 5,
	FreeLookAt = 6,
	AutoDirector = 7,
	AutoComment = 8,
	_Count = 9,
	ESolarTablesEnum_MAX = 10
};

// Object: Enum Solarland.ESolarTablesEnum_HighlightCameraEffect
enum class ESolarTablesEnum_HighlightCameraEffect : uint8_t {
	None = 0,
	ThirdPerson = 1,
	CloseUp = 2,
	VictimPerspective = 3,
	FollowProjectile = 4,
	_Count = 5,
	ESolarTablesEnum_MAX = 6
};

// Object: Enum Solarland.ESolarTablesEnum_LobbyMatchEnterType
enum class ESolarTablesEnum_LobbyMatchEnterType : uint8_t {
	CanClick = 0,
	PartialClick = 1,
	ForbidClick = 2,
	_Count = 3,
	ESolarTablesEnum_MAX = 4
};

// Object: Enum Solarland.ESolarTablesEnum_StackType
enum class ESolarTablesEnum_StackType : uint8_t {
	StackByQTY = 0,
	StackByTime = 1,
	_Count = 2,
	ESolarTablesEnum_MAX = 3
};

// Object: Enum Solarland.ESolarTablesEnum_InputRelatedType
enum class ESolarTablesEnum_InputRelatedType : uint8_t {
	InputRelatedNone = 0,
	Input_F = 1,
	InputRelated2 = 2,
	InputRelated3 = 3,
	InputRelated4 = 4,
	InputRelated5 = 5,
	InputRelated6 = 6,
	InputRelated7 = 7,
	InputRelated8 = 8,
	InputRelated9 = 9,
	InputRelated10 = 10,
	Input_J = 11,
	Input_Shift = 12,
	Input_SKillZ = 13,
	Input_SKillQ = 14,
	Input_SKillE = 15,
	_Count = 16,
	ESolarTablesEnum_MAX = 17
};

// Object: Enum Solarland.ESolarTablesEnum_InputContextType
enum class ESolarTablesEnum_InputContextType : uint8_t {
	InputCommon = 0,
	InputPlayer = 1,
	InputVehicle = 2,
	InputOB = 3,
	InputPlayerSkill = 4,
	InputActionWheel = 5,
	_Count = 6,
	ESolarTablesEnum_MAX = 7
};

// Object: Enum Solarland.ESolarTablesEnum_InputTabType
enum class ESolarTablesEnum_InputTabType : uint8_t {
	InputTabPlayer = 0,
	InputTabVehicle = 1,
	InputTabOB = 2,
	InputTabMisc = 3,
	_Count = 4,
	ESolarTablesEnum_MAX = 5
};

// Object: Enum Solarland.ESolarTablesEnum_InputCtrlType
enum class ESolarTablesEnum_InputCtrlType : uint8_t {
	InputCtrlHide = 0,
	InputCtrlShow = 1,
	InputCtrlCustom = 2,
	InputCtrlCustomAndCom = 3,
	_Count = 4,
	ESolarTablesEnum_MAX = 5
};

// Object: Enum Solarland.ESolarTablesEnum_GamepadCtrlType
enum class ESolarTablesEnum_GamepadCtrlType : uint8_t {
	GamepadCtrlHide = 0,
	GamepadCtrlShowOnly = 1,
	GamepadCtrlCustom = 2,
	GamepadCtrlCustomAndCom = 3,
	_Count = 4,
	ESolarTablesEnum_MAX = 5
};

// Object: Enum Solarland.ESolarTablesEnum_InputGamepadType
enum class ESolarTablesEnum_InputGamepadType : uint8_t {
	InputGamepadOneKey = 0,
	InputGamepadComKey = 1,
	InputGamepadFreeComKey = 2,
	_Count = 3,
	ESolarTablesEnum_MAX = 4
};

// Object: Enum Solarland.ESolarTablesEnum_ClassModeType
enum class ESolarTablesEnum_ClassModeType : uint8_t {
	CLASS_MODE_NONE = 0,
	CLASS_MODE_V13_4 = 1,
	CLASS_MODE_UniqueSkill = 2,
	CLASS_MODE_RoleGrow = 3,
	CLASS_MODE_OFFLINE = 4,
	_Count = 5,
	ESolarTablesEnum_MAX = 6
};

// Object: Enum Solarland.ESolarTablesEnum_ExcuterType
enum class ESolarTablesEnum_ExcuterType : uint8_t {
	AirDrop = 0,
	GasCircle = 1,
	Bomb = 2,
	_Count = 3,
	ESolarTablesEnum_MAX = 4
};

// Object: Enum Solarland.ESolarTablesEnum_DisplayType
enum class ESolarTablesEnum_DisplayType : uint8_t {
	None = 0,
	Tips = 1,
	Window = 2,
	_Count = 3,
	ESolarTablesEnum_MAX = 4
};

// Object: Enum Solarland.ESolarTablesEnum_JumpType
enum class ESolarTablesEnum_JumpType : uint8_t {
	ActionType_None = 0,
	JumpType_Liveshow = 1,
	_Count = 2,
	ESolarTablesEnum_MAX = 3
};

// Object: Enum Solarland.ESolarTablesEnum_ChestType
enum class ESolarTablesEnum_ChestType : uint8_t {
	AirDrop = 0,
	ElecChest = 1,
	TacticalBox = 2,
	SlotMachine = 3,
	_Count = 4,
	ESolarTablesEnum_MAX = 5
};

// Object: Enum Solarland.ESolarTablesEnum_Duration
enum class ESolarTablesEnum_Duration : uint8_t {
	Day = 0,
	Week = 1,
	Month = 2,
	Year = 3,
	Never = 4,
	None = 5,
	_Count = 6,
	ESolarTablesEnum_MAX = 7
};

// Object: Enum Solarland.ESolarTablesEnum_CharacterLevelUpType
enum class ESolarTablesEnum_CharacterLevelUpType : uint8_t {
	Health = 0,
	Damage = 1,
	Movement = 2,
	FlyCooldown = 3,
	_Count = 4,
	ESolarTablesEnum_MAX = 5
};

// Object: Enum Solarland.ESolarTablesEnum_BehaviorType
enum class ESolarTablesEnum_BehaviorType : uint8_t {
	SurvivalTime = 0,
	Kills = 1,
	Assists = 2,
	Selfhealing = 3,
	TeammateHealing = 4,
	Unpacking = 5,
	CollectElectricity = 6,
	PickExpPack = 7,
	EveryDamageDealt = 8,
	NpcKills = 9,
	NpcAssists = 10,
	TacticalBox = 11,
	ShieldUpgradeShop = 12,
	TeamDestroy = 13,
	RevengeKilling = 14,
	WeakReward = 15,
	KillDown = 16,
	AssistingKillDown = 17,
	OpenAirDrop = 18,
	OpenHotSpringBox = 19,
	ReviveTeamates = 20,
	ReviveReward = 21,
	HelpReward = 22,
	CollectBuddy = 23,
	_Count = 24,
	ESolarTablesEnum_MAX = 25
};

// Object: Enum Solarland.ESolarTablesEnum_Enum_Behavior
enum class ESolarTablesEnum_Enum_Behavior : uint8_t {
	Behavior1 = 0,
	Behavior2 = 1,
	Behavior3 = 2,
	Behavior4 = 3,
	Behavior5 = 4,
	Behavior6 = 5,
	Behavior7 = 6,
	Behavior8 = 7,
	Behavior9 = 8,
	Behavior10 = 9,
	Behavior11 = 10,
	Behavior12 = 11,
	Behavior13 = 12,
	Behavior14 = 13,
	Behavior15 = 14,
	Behavior16 = 15,
	Behavior17 = 16,
	Behavior18 = 17,
	Behavior19 = 18,
	Behavior20 = 19,
	Behavior21 = 20,
	Behavior22 = 21,
	Behavior23 = 22,
	Behavior24 = 23,
	_Count = 24,
	ESolarTablesEnum_Enum_MAX = 25
};

// Object: Enum Solarland.ESolarTablesEnum_ActionType
enum class ESolarTablesEnum_ActionType : uint8_t {
	ActionType_None = 0,
	ActionType_OpenGift = 1,
	ActionType_Charge = 2,
	ActionType_Battle = 3,
	ActionType_Mail = 4,
	ActionType_ShopBuy = 5,
	ActionType_DailyTask = 6,
	ActionType_Activity = 7,
	ActionType_Guid = 8,
	ActionType_GM = 9,
	ActionType_BattleBag = 10,
	ActionType_ItemUse = 11,
	ActionType_Refund = 12,
	ActionType_BattleDouble = 13,
	ActionType_UnitProf = 14,
	ActionType_SanctuaryBuild = 15,
	ActionType_SanctuaryFacility = 16,
	ActionType_Weapon_Upgrade = 17,
	ActionType_Activereward = 18,
	ActionType_ComposeItem = 19,
	ActionType_LoginReward = 20,
	ActionType_NewUserLogin = 21,
	ActionType_HomeDailyTask = 22,
	ActionType_BattlePass = 23,
	ActionType_LevelReward = 24,
	ActionType_HomeUpgrade = 25,
	ActionType_BattlePassRepeat = 26,
	ActionType_TopUP = 27,
	ActionType_Achievement = 28,
	ActionType_LuckDraw = 29,
	ActionType_BattlePassShare = 30,
	ActionType_CDKey = 31,
	ActionType_HalfMonthLogin = 32,
	ActionType_MonthlyEvent = 33,
	ActionType_FriendEvent = 34,
	ActionType_WeekChanllenge = 35,
	ActionType_RoomCard = 36,
	ActionType_BindAccount = 37,
	ActionType_UserGrowthEvent = 38,
	ActionType_SendGift = 39,
	ActionType_SellItem = 40,
	ActionType_CollectRedeem = 41,
	ActionType_RandomPack = 42,
	ActionType_Clan = 43,
	ActionType_Bet = 44,
	ActionType_BetBonus = 45,
	ActionType_BetReturn = 46,
	ActionType_CarouselDraw = 47,
	ActionType_WeekFree = 48,
	ActionType_TutorialLevelReward = 49,
	ActionType_TournamentMiss = 50,
	ActionType_TournamentReward = 51,
	ActionType_RankingCard = 52,
	ActionType_BattleSupplyBox = 53,
	ActionType_BattlePassMission = 54,
	ActionType_SupplyBox = 55,
	ActionType_VipcardReceive = 56,
	ActionType_VipcardSign = 57,
	ActionType_Vipcard = 58,
	ActionType_Signcard = 59,
	ActionType_ChangeName = 60,
	ActionType_ServerCard = 61,
	ActionType_ExResourceDownload = 62,
	ActionType_CustomServer_Renewal = 63,
	ActionType_NewLuckDraw = 64,
	ActionType_SerialTask = 65,
	ActionType_Rank = 66,
	ActionType_NewBP = 67,
	ActionType_NewBPReward = 68,
	ActionType_PermanentReward = 69,
	ActionType_NewTaskRefresh = 70,
	ActionType_ExchangeShop = 71,
	ActionType_BuyGiftBox = 72,
	ActionType_WeeklyShop = 73,
	ActionType_StageReward = 74,
	ActionType_PermanentDraw = 75,
	ActionType_PermanentDrawExchange = 76,
	ActionType_DiamondsRebate = 77,
	ActionType_PassBallReward = 78,
	ActionType_BattlePassDiamonds = 79,
	_Count = 80,
	ESolarTablesEnum_MAX = 81
};

// Object: Enum Solarland.ETaskStatus
enum class ETaskStatus : uint8_t {
	Runing = 0,
	Completed = 1,
	ReceiveAward = 2,
	ETaskStatus_MAX = 3
};

// Object: Enum Solarland.ETitanAIState
enum class ETitanAIState : uint8_t {
	Idle = 0,
	GoBackHome = 1,
	ETitanAIState_MAX = 2
};

// Object: Enum Solarland.ETornadoState
enum class ETornadoState : uint8_t {
	None = 0,
	BuddyBegin = 1,
	BuddyAppear = 2,
	BuddyLoop = 3,
	BuddyDisappear = 4,
	TornadoEffecting = 5,
	TornadoEnd = 6,
	ETornadoState_MAX = 7
};

// Object: Enum Solarland.ECostType
enum class ECostType : uint8_t {
	NONE = 0,
	ELECTRONIC = 1,
	ECostType_MAX = 2
};

// Object: Enum Solarland.ETutorialMaskType
enum class ETutorialMaskType : uint8_t {
	Rectangle = 0,
	Circle = 1,
	ETutorialMaskType_MAX = 2
};

// Object: Enum Solarland.ETutorialGestureHandType
enum class ETutorialGestureHandType : uint8_t {
	Right = 0,
	Left = 1,
	ETutorialGestureHandType_MAX = 2
};

// Object: Enum Solarland.ETutorialGestureType
enum class ETutorialGestureType : uint8_t {
	None = 0,
	Click = 1,
	SlideUp = 2,
	SlideRight = 3,
	SlideLeft = 4,
	ETutorialGestureType_MAX = 5
};

// Object: Enum Solarland.ETutorialUIType
enum class ETutorialUIType : uint8_t {
	None = 0,
	Common = 1,
	Special = 2,
	PanelStyle1 = 3,
	ETutorialUIType_MAX = 4
};

// Object: Enum Solarland.ETutorialNodeType
enum class ETutorialNodeType : uint8_t {
	Single = 0,
	Parallel = 1,
	ETutorialNodeType_MAX = 2
};

// Object: Enum Solarland.ELevelRewardStatus
enum class ELevelRewardStatus : uint8_t {
	NotClaimed = 0,
	Claimed = 1,
	Disable = 2,
	ELevelRewardStatus_MAX = 3
};

// Object: Enum Solarland.EWidgetPlayAnimationFlag
enum class EWidgetPlayAnimationFlag : uint8_t {
	None = 0,
	Finish = 1,
	EWidgetPlayAnimationFlag_MAX = 2
};

// Object: Enum Solarland.EWidgetInteractionFlag
enum class EWidgetInteractionFlag : uint8_t {
	None = 0,
	Pressed = 1,
	Released = 2,
	Clicked = 3,
	EWidgetInteractionFlag_MAX = 4
};

// Object: Enum Solarland.ETutorialStage
enum class ETutorialStage : uint8_t {
	None = 0,
	Lobby = 1,
	BattleField = 2,
	TutorialLevel = 4,
	ETutorialStage_MAX = 5
};

// Object: Enum Solarland.ETutorialUIParent
enum class ETutorialUIParent : uint8_t {
	Parent = 0,
	UnderBattleRoot = 1,
	BattleRoot = 2,
	BattleRootGuide = 3,
	MiddleRoot = 4,
	CommonRoot = 5,
	Map = 6,
	BattleNoticeRoot = 7,
	Guide = 8,
	PopRoot = 9,
	TipsRoot = 10,
	NoticeRoot = 11,
	Loading = 12,
	Reconnecting = 13,
	ExternalToolsRoot = 255,
	ETutorialUIParent_MAX = 256
};

// Object: Enum Solarland.ETutorialConditionType
enum class ETutorialConditionType : uint8_t {
	None = 0,
	Trigger = 1,
	Interrupt = 2,
	Finish = 3,
	ForeverClose = 4,
	ETutorialConditionType_MAX = 5
};

// Object: Enum Solarland.ETutorialType
enum class ETutorialType : uint8_t {
	TEvent = 0,
	TTick = 1,
	ETutorialType_MAX = 2
};

// Object: Enum Solarland.ETutorialTriggerType
enum class ETutorialTriggerType : uint8_t {
	TickActivateTutorials = 0,
	AlreadyTriggeredMaxCount = 1,
	HasSpecifiedItem = 2,
	HasTakenDamage = 3,
	PlayerAcountLevel = 4,
	SprintingContinuously = 5,
	JumpBegin = 8,
	ShieldNotFull = 17,
	WidgetClicked = 19,
	CanUseSpecifiedVehicleAbility = 20,
	CanUseSpecifiedVehicleWeapon = 21,
	AirDropBoxLanded = 22,
	NearAirDropBox = 23,
	OpenBigMapUMG = 24,
	CanUseSpecifiedWeaponAbility = 25,
	CanOpenTreasureBox = 29,
	PlayerInTargetStage = 30,
	EquipSpecifiedWeapon = 34,
	FeatureUnlock = 35,
	ApproachTreasureBox = 36,
	BotAIDying = 38,
	RunningStep = 39,
	HasSpecifiedEquipmentByType = 40,
	TutorialLevelDone = 42,
	WeaponSlotHasSpecifiedItem = 45,
	HasUIPanelOpened = 48,
	SpecifiedPlayerProficiency = 53,
	PlayerUpgradeBattleLevel = 54,
	PlayerAbilityTagChanged = 55,
	ETutorialTriggerType_MAX = 56
};

// Object: Enum Solarland.EPlayerProficiency
enum class EPlayerProficiency : uint8_t {
	None = 0,
	Rookie = 1,
	FPS = 2,
	Veteran = 3,
	EPlayerProficiency_MAX = 4
};

// Object: Enum Solarland.EUAVRescueState
enum class EUAVRescueState : uint8_t {
	None = 0,
	Idle = 1,
	Heal = 2,
	Navigate = 3,
	Rescue = 4,
	EUAVRescueState_MAX = 5
};

// Object: Enum Solarland.EWidgetPassiveMode
enum class EWidgetPassiveMode : uint8_t {
	Normal = 0,
	Passive_Buff = 1,
	Passive_Debuff = 2,
	EWidgetPassiveMode_MAX = 3
};

// Object: Enum Solarland.EVehicleRotateAnimationType
enum class EVehicleRotateAnimationType : uint8_t {
	None = 0,
	Right_91 = 1,
	Right_181 = 2,
	Left_91 = 3,
	Left_181 = 4,
	Right = 5,
	Left = 6,
	EVehicleRotateAnimationType_MAX = 7
};

// Object: Enum Solarland.EIronManHandPart
enum class EIronManHandPart : uint8_t {
	LeftHand = 0,
	RightHand = 1,
	EIronManHandPart_MAX = 2
};

// Object: Enum Solarland.EIronManSoundEvent
enum class EIronManSoundEvent : uint8_t {
	LaserHit = 0,
	EIronManSoundEvent_MAX = 1
};

// Object: Enum Solarland.EPreloadVehicleUIType
enum class EPreloadVehicleUIType : uint8_t {
	None = 0,
	CrossHairUI = 1,
	VehicleSpecialUI = 2,
	EPreloadVehicleUIType_MAX = 3
};

// Object: Enum Solarland.EPlayerInputMask
enum class EPlayerInputMask : uint8_t {
	Invalidated = 0,
	VehicleBraking = 1,
	VehicleTrumpet = 2,
	VehicleAutoMove = 4,
	All = 7,
	EPlayerInputMask_MAX = 8
};

// Object: Enum Solarland.EHoverVehicleVFXType
enum class EHoverVehicleVFXType : uint8_t {
	Forward = 0,
	Backward = 1,
	Right = 2,
	Left = 3,
	Max = 4
};

// Object: Enum Solarland.EEnterWaterVFX
enum class EEnterWaterVFX : uint8_t {
	HorizontalLightEffect = 0,
	HorizontalHeavyEffect = 1,
	VerticalLightEffect = 2,
	VerticalHeavyEffect = 3,
	MAX = 4
};

// Object: Enum Solarland.ECorrectionReason
enum class ECorrectionReason : uint8_t {
	ClientTimeDiscrepancy = 0,
	InvalidSpeed = 1,
	TooShortDeltaTime = 2,
	WaitingForClientConfirm = 3,
	InvalidCollision = 4,
	FloatingInAir = 5,
	StandingOnUnwalkableVehicle = 6,
	ECorrectionReason_MAX = 7
};

// Object: Enum Solarland.EVehicleSpawnSourceType
enum class EVehicleSpawnSourceType : uint8_t {
	CommonSpawn = 0,
	VehicleSummonWeapon = 1,
	EVehicleSpawnSourceType_MAX = 2
};

// Object: Enum Solarland.EVehicleControlUIType
enum class EVehicleControlUIType : uint8_t {
	Vehicle = 0,
	Character = 1,
	None = 2,
	EVehicleControlUIType_MAX = 3
};

// Object: Enum Solarland.EVehicleRotateCondition
enum class EVehicleRotateCondition : uint8_t {
	None = 0,
	Forward = 1,
	Backward = 2,
	Right = 4,
	Left = 8,
	All = 15,
	EVehicleRotateCondition_MAX = 16
};

// Object: Enum Solarland.EVehicleOpenTips
enum class EVehicleOpenTips : uint8_t {
	FloorCanNotOpen = 0,
	SpeedCanNotOpen = 1,
	EVehicleOpenTips_MAX = 2
};

// Object: Enum Solarland.ESiegeVehicleAnimation
enum class ESiegeVehicleAnimation : uint8_t {
	CloseIdle = 0,
	OpenIdle = 1,
	Fire = 2,
	ESiegeVehicleAnimation_MAX = 3
};

// Object: Enum Solarland.EVehicleDamageStatus
enum class EVehicleDamageStatus : uint8_t {
	Normal = 0,
	Damaged = 1,
	SeriouslyDamaged = 2,
	BrokenDanger = 3,
	Broken = 4,
	MAX = 5
};

// Object: Enum Solarland.EVehicleAnimationState
enum class EVehicleAnimationState : uint8_t {
	None = 0,
	Jump = 1,
	Dash = 2,
	TakingOff = 3,
	Cruising = 4,
	PreJump = 5,
	Flying = 6,
	EVehicleAnimationState_MAX = 7
};

// Object: Enum Solarland.ERocketFireMode
enum class ERocketFireMode : uint8_t {
	NomalFire = 0,
	PrecisionFire = 1,
	Max = 2
};

// Object: Enum Solarland.EVehiclePageType
enum class EVehiclePageType : uint8_t {
	Lobby = 0,
	VehicleBag = 1,
	BattlePass = 2,
	LuckDraw = 3,
	GetReward = 4,
	GrowTask = 5,
	Shop = 6,
	CarouselDraw = 7,
	SupplyBoxDetail = 8,
	SupplyBoxRaffle = 9,
	Max = 10
};

// Object: Enum Solarland.EVehicleSpawnEffectType
enum class EVehicleSpawnEffectType : uint8_t {
	None = 0,
	RefreshingProgress = 1,
	PreVehicleSummon = 2,
	EVehicleSpawnEffectType_MAX = 3
};

// Object: Enum Solarland.EVehicleState
enum class EVehicleState : uint8_t {
	None = 0,
	Ground = 1,
	Air = 2,
	Sliding = 3,
	EVehicleState_MAX = 4
};

// Object: Enum Solarland.EWaterWallSpawnState
enum class EWaterWallSpawnState : uint8_t {
	E_NotSpawned = 0,
	E_Spawning = 1,
	E_Spawned = 2,
	E_WaitingDestroy = 3,
	E_MAX = 4
};

// Object: Enum Solarland.ESolarWeaponSpreadState
enum class ESolarWeaponSpreadState : uint8_t {
	Standby = 0,
	Approach = 1,
	Recover = 2,
	ESolarWeaponSpreadState_MAX = 3
};

// Object: Enum Solarland.ESolarBlackHoleParticle
enum class ESolarBlackHoleParticle : uint8_t {
	ForceField = 0,
	CoreFadeIn = 1,
	CoreFadeOut = 2,
	CoreLoop = 3,
	CoreHit = 4,
	Explode = 5,
	CharacterDebuff = 6,
	ESolarBlackHoleParticle_MAX = 7
};

// Object: Enum Solarland.ESolarBlackHoleState
enum class ESolarBlackHoleState : uint8_t {
	None = 0,
	Startup = 1,
	Ready = 2,
	Active = 3,
	End = 4,
	ESolarBlackHoleState_MAX = 5
};

// Object: Enum Solarland.EWeaponType
enum class EWeaponType : uint8_t {
	AssualtRifle = 0,
	Submachinegun = 1,
	Shotgun = 2,
	Sniper = 3,
	VehicleMounted = 4,
	ItemWeapon = 5,
	SummonWeapon = 6,
	AntiVehicle = 7,
	Unarm = 8,
	Unknown = 9,
	EWeaponType_MAX = 10
};

// Object: Enum Solarland.EWeaponOverloadState
enum class EWeaponOverloadState : uint8_t {
	NormalDecrease = 0,
	FireSuspend = 1,
	ForceOverload = 2,
	EWeaponOverloadState_MAX = 3
};

// Object: Enum Solarland.EPlayerWeaponTypeForFireInput
enum class EPlayerWeaponTypeForFireInput : uint8_t {
	AssaultRifle = 0,
	SubmachineGun = 1,
	ShotgunSingle = 2,
	ShotgunAuto = 3,
	SniperSingle = 4,
	SniperAuto = 5,
	ItemWeapon = 6,
	SpecialWeapon = 7,
	Max = 8
};

// Object: Enum Solarland.EFireDistType
enum class EFireDistType : uint8_t {
	Close = 0,
	Medium = 1,
	Long = 2,
	None = 3,
	EFireDistType_MAX = 4
};

// Object: Enum Solarland.EVirtualBulletType
enum class EVirtualBulletType : uint8_t {
	LinearBullet = 0,
	CurveBullet = 1,
	GravityBullet = 2,
	TracingBullet = 3,
	EVirtualBulletType_MAX = 4
};

// Object: Enum Solarland.ESolarPlayerWeaponTagType
enum class ESolarPlayerWeaponTagType : uint8_t {
	WeaponType = 0,
	WeaponDifficulty = 1,
	WeaponProperties = 2,
	Max = 3
};

// Object: Enum Solarland.EWeaponSpreadShape
enum class EWeaponSpreadShape : uint8_t {
	Ellipse = 0,
	Rectangle = 1,
	EWeaponSpreadShape_MAX = 2
};

// Object: Enum Solarland.EGearState
enum class EGearState : uint8_t {
	Reverse = 0,
	Neutral = 1,
	Forward = 2,
	EGearState_MAX = 3
};

// Object: Enum Solarland.EInputEventHandleType
enum class EInputEventHandleType : uint8_t {
	Unhandle = 0,
	SimulateKey = 1,
	BroadcastEvent = 2,
	SimulateTouch = 4,
	NoKeyOnly = 6,
	NoEventOnly = 5,
	NoTouchOnly = 3,
	HandleAll = 7,
	EInputEventHandleType_MAX = 8
};

// Object: Enum Solarland.ETouchMovePriority
enum class ETouchMovePriority : uint8_t {
	Invalid = 0,
	Lowest = 1,
	Lower = 2,
	Normal = 3,
	Higher = 4,
	Highest = 5,
	ETouchMovePriority_MAX = 6
};

// Object: Enum Solarland.EWindFieldSoundType
enum class EWindFieldSoundType : uint8_t {
	None = 0,
	SummonActivate = 1,
	SummonLoop = 2,
	SummonSuccess = 3,
	Death = 4,
	WindStart = 5,
	WindLoop = 6,
	WindEnd = 7,
	EWindFieldSoundType_MAX = 8
};

// Object: Enum Solarland.EWindFieldState
enum class EWindFieldState : uint8_t {
	None = 0,
	Delay = 1,
	Prepare = 2,
	Activated = 3,
	FadeOut = 4,
	Finished = 5,
	EWindFieldState_MAX = 6
};

// Object: Enum Solarland.ESoundPoolSimpleRule
enum class ESoundPoolSimpleRule : uint8_t {
	Random = 0,
	RandomNoRepeat = 1,
	Sequential = 2,
	ESoundPoolSimpleRule_MAX = 3
};

// Object: Enum Solarland.ESoundGroupContextLabel
enum class ESoundGroupContextLabel : uint8_t {
	None = 0,
	IsSelf = 1,
	IsTeammate = 2,
	IsAttackingOther = 4,
	IsAttackedByOther = 8,
	HasSilencer = 16,
	IsInRoom = 32,
	ESoundGroupContextLabel_MAX = 33
};

// Object: Enum Solarland.ESolarImageProgressHalfCirclePrivotType
enum class ESolarImageProgressHalfCirclePrivotType : uint8_t {
	MidLeft = 0,
	MidRight = 1,
	MidBottom = 2,
	MidTop = 4,
	ESolarImageProgressHalfCirclePrivotType_MAX = 5
};

// Object: Enum Solarland.ESolarImageProgressQuaterCirclePrivotType
enum class ESolarImageProgressQuaterCirclePrivotType : uint8_t {
	LeftBottom = 0,
	RightBottom = 1,
	LeftTop = 16,
	RightTop = 17,
	ESolarImageProgressQuaterCirclePrivotType_MAX = 18
};

// Object: Enum Solarland.ESolarImageProgressLineDirType
enum class ESolarImageProgressLineDirType : uint8_t {
	Horizantal = 0,
	Vertical = 1,
	ESolarImageProgressLineDirType_MAX = 2
};

// Object: Enum Solarland.ESolarImageProgressType
enum class ESolarImageProgressType : uint8_t {
	None = 0,
	Line = 1,
	QuarterCircle = 2,
	HalfCircle = 3,
	Circle = 4,
	ESolarImageProgressType_MAX = 5
};

// Object: Enum Solarland.ESolarImageFillType
enum class ESolarImageFillType : uint8_t {
	Normal = 0,
	Mirror = 1,
	Quarter = 2,
	ESolarImageFillType_MAX = 3
};

// Object: Enum Solarland.EStealPokemonState
enum class EStealPokemonState : uint8_t {
	InOwnerSight = 0,
	SendToStealTarget = 1,
	Steal = 2,
	EStealPokemonState_MAX = 3
};

// Object: Enum Solarland.ESummonItemTagChangedType
enum class ESummonItemTagChangedType : uint8_t {
	Add = 0,
	Remove = 1,
	Changed = 2,
	ESummonItemTagChangedType_MAX = 3
};

// Object: Enum Solarland.ESolarBarDisplayMode
enum class ESolarBarDisplayMode : uint8_t {
	E_Hidden = 0,
	E_AlwaysShow = 1,
	E_ShowIfTakeDamage = 2,
	E_MAX = 3
};

// Object: Enum Solarland.EUpgradeState
enum class EUpgradeState : uint8_t {
	Locked = 0,
	Upgradable = 1,
	Upgrading = 2,
	Upgraded = 3,
	EUpgradeState_MAX = 4
};

// Object: Enum Solarland.ERefreshCause
enum class ERefreshCause : uint8_t {
	ECause_None = 0,
	ECause_OutOrIntoScreen = 1,
	ECause_RescueStateChange = 2,
	ECause_MAX = 3
};

// Object: Enum Solarland.EThunderFlashPhase
enum class EThunderFlashPhase : uint8_t {
	None = 0,
	Idle = 1,
	Move = 2,
	Start = 3,
	Loop = 4,
	End = 5,
	Max = 6
};

// Object: Enum Solarland.ETrapGrenadeState
enum class ETrapGrenadeState : uint8_t {
	Flying = 0,
	Waiting = 1,
	Standby = 2,
	Jump = 3,
	DamageVolume = 4,
	BrokenDueToLifeTime = 5,
	BrokenDueToDamage = 6,
	BrokenDueToDamageVolumeLifeTime = 7,
	ETrapGrenadeState_MAX = 8
};

// Object: Enum Solarland.EHotSpringLifeState
enum class EHotSpringLifeState : uint8_t {
	None = 0,
	Normal = 1,
	Disappear = 2,
	Destoryed = 3,
	EHotSpringLifeState_MAX = 4
};

// Object: Enum Solarland.ECipherBoxOpenState
enum class ECipherBoxOpenState : uint8_t {
	Closed = 0,
	Opening = 1,
	Opened = 2,
	ECipherBoxOpenState_MAX = 3
};

// Object: Enum Solarland.ECipherBoxType
enum class ECipherBoxType : uint8_t {
	None = 0,
	AIRDROPBOX = 1,
	HOTSPRINTBOX = 2,
	ECipherBoxType_MAX = 3
};

// Object: Enum Solarland.ESplineMeshType
enum class ESplineMeshType : uint8_t {
	DEFAULT = 0,
	START = 1,
	END = 2,
	ESplineMeshType_MAX = 3
};

// Object: Enum Solarland.EHeroCellSelectedType
enum class EHeroCellSelectedType : uint8_t {
	Default = 0,
	Selecting = 1,
	DisableSelectd = 2,
	EHeroCellSelectedType_MAX = 3
};

// Object: Enum Solarland.EBackpackEquipState
enum class EBackpackEquipState : uint8_t {
	None = 0,
	CanAssembly = 1,
	NoAssembly = 2,
	EBackpackEquipState_MAX = 3
};

// Object: Enum Solarland.EUIGeneralItemSlotState
enum class EUIGeneralItemSlotState : uint8_t {
	Empty = 0,
	Occupied = 1,
	Disable = 2,
	EUIGeneralItemSlotState_MAX = 3
};

// Object: Enum Solarland.EUIPokeBallPassiveSlotState
enum class EUIPokeBallPassiveSlotState : uint8_t {
	Empty = 0,
	Occupied = 1,
	Disable = 2,
	EUIPokeBallPassiveSlotState_MAX = 3
};

// Object: Enum Solarland.EBackpackInfoPageType
enum class EBackpackInfoPageType : uint8_t {
	Backpack = 0,
	Talent = 1,
	Max = 2
};

// Object: Enum Solarland.ETweenInterpolationType
enum class ETweenInterpolationType : uint8_t {
	Easing = 0,
	Curve = 1,
	ETweenInterpolationType_MAX = 2
};

// Object: Enum Solarland.EDefenderTeamType
enum class EDefenderTeamType : uint8_t {
	None = 0,
	MyTeam = 1,
	DefenderTeam = 2,
	DazzlingTeam = 3,
	EDefenderTeamType_MAX = 4
};

// Object: Enum Solarland.EActionWheelImageType
enum class EActionWheelImageType : uint8_t {
	None = 0,
	Action = 1,
	Sticker = 2,
	EActionWheelImageType_MAX = 3
};

// Object: Enum Solarland.EPlayerWidgetState
enum class EPlayerWidgetState : uint8_t {
	NORMAL = 0,
	DRIVER = 1,
	PASSGNER = 2,
	EQUIPVEHICLEWEAPON = 3,
	CRUISING = 4,
	PATACHUTING = 5,
	SWIMMING = 6,
	INHUMANCANNON = 7,
	MAX = 8
};

// Object: Enum Solarland.ELocalNoticeType
enum class ELocalNoticeType : uint8_t {
	Revenge = 0,
	KillDown = 1,
	ClearTeam = 2,
	ShutDown = 3,
	KillDefender = 4,
	ELocalNoticeType_MAX = 5
};

// Object: Enum Solarland.EUIWidgetProxyName
enum class EUIWidgetProxyName : uint8_t {
	None = 0,
	UI_BuyResurrectionPanel = 1,
	OpenAirdrop = 2,
	ExpSpring = 3,
	RescueTeammate = 4,
	RespawnDevice = 5,
	ConsoleDevice = 6,
	GeneralTrigger_1 = 7,
	GeneralTrigger_2 = 8,
	GeneralTrigger_3 = 9,
	GeneralTrigger_4 = 10,
	EUIWidgetProxyName_MAX = 11
};

// Object: Enum Solarland.EInteractionButtonType
enum class EInteractionButtonType : uint8_t {
	NONE = 0,
	GENERAL = 1,
	REVIVAL = 2,
	RESCUE = 3,
	ZIPLINE = 4,
	VEHICLE = 5,
	EInteractionButtonType_MAX = 6
};

// Object: Enum Solarland.EUIWeaponPartState
enum class EUIWeaponPartState : uint8_t {
	NotEquip = 0,
	Equipped = 1,
	CantEquip = 2,
	EUIWeaponPartState_MAX = 3
};

// Object: Enum Solarland.EWidgetVisibilityFlags
enum class EWidgetVisibilityFlags : uint8_t {
	None = 0,
	ChatSwitch = 1,
	ChatMsgSending = 2,
	ConnectionState = 3,
	TalentState = 4,
	TalentValidation = 5,
	EWidgetVisibilityFlags_MAX = 6
};

// Object: Enum Solarland.EVehicleWeaponScopeType
enum class EVehicleWeaponScopeType : uint8_t {
	None = 0,
	Magnifier_X2 = 1,
	Magnifier_X4 = 2,
	Magnifier_X8 = 3,
	Max = 4
};

// Object: Enum Solarland.EVehicleSpawnAlternateType
enum class EVehicleSpawnAlternateType : uint8_t {
	Hour = 0,
	Day = 1,
	Week = 2,
	Month = 3,
	Season = 4,
	EVehicleSpawnAlternateType_MAX = 5
};

// Object: Enum Solarland.EVehicleSpawnType
enum class EVehicleSpawnType : uint8_t {
	SingleRandom = 0,
	Group = 1,
	GroupWithSingleRandom = 2,
	EVehicleSpawnType_MAX = 3
};

// Object: Enum Solarland.EStealthParamType
enum class EStealthParamType : uint8_t {
	None = 0,
	Type_1P = 1,
	Type_3P = 2,
	Type_3P_Enemy = 3,
	EStealthParamType_MAX = 4
};

// Object: Enum Solarland.EWholeShieldState
enum class EWholeShieldState : uint8_t {
	Begin = 0,
	InProgress = 1,
	End = 2,
	EWholeShieldState_MAX = 3
};

// Object: Enum Solarland.EVendingMachineRewardQuality
enum class EVendingMachineRewardQuality : uint8_t {
	None = 0,
	Blue = 1,
	Purple = 2,
	Gold = 3,
	EVendingMachineRewardQuality_MAX = 4
};

// Object: Enum Solarland.EVendingMachineState
enum class EVendingMachineState : uint8_t {
	None = 0,
	Idle = 1,
	Tossing = 2,
	Drawing = 3,
	Resulting = 4,
	Bursting = 5,
	EVendingMachineState_MAX = 6
};

// Object: Enum Solarland.EVisualSoundCalculatePoint
enum class EVisualSoundCalculatePoint : uint8_t {
	Camera = 0,
	Character = 1,
	EVisualSoundCalculatePoint_MAX = 2
};

// Object: Enum Solarland.EVisualSoundDetectionRule
enum class EVisualSoundDetectionRule : uint8_t {
	XYZ = 0,
	XY = 1,
	XY_FiniteZ = 2,
	EVisualSoundDetectionRule_MAX = 3
};

// Object: Enum Solarland.EShieldAcitveType
enum class EShieldAcitveType : uint8_t {
	Normal = 0,
	Slithering = 1,
	Max = 2
};

// Object: Enum Solarland.EShieldDestroyReason
enum class EShieldDestroyReason : uint8_t {
	FadeOut = 0,
	Broken = 1,
	Explode = 2,
	Max = 3
};

// Object: Enum Solarland.EWeaponAnimState
enum class EWeaponAnimState : uint8_t {
	Idle = 0,
	Fire = 1,
	AltFire = 2,
	Reload = 3,
	Overload = 4,
	OpenScope = 5,
	CloseScope = 6,
	Bolt = 7,
	Preview = 8,
	Summon = 9,
	EWeaponAnimState_MAX = 10
};

// Object: Enum Solarland.EWeaponTrajectoryType
enum class EWeaponTrajectoryType : uint8_t {
	VirtualBullet = 0,
	Canister = 1,
	EWeaponTrajectoryType_MAX = 2
};

// Object: Enum Solarland.EWeaponDamageDecayMode
enum class EWeaponDamageDecayMode : uint8_t {
	Instant = 0,
	Linear = 1,
	EWeaponDamageDecayMode_MAX = 2
};

// Object: Enum Solarland.ESolarWeaponLODState
enum class ESolarWeaponLODState : uint8_t {
	Hold = 0,
	OpenScope = 1,
	Discard = 2,
	AttachedOnBackpack = 3,
	ESolarWeaponLODState_MAX = 4
};

// Object: Enum Solarland.EWeaponSkinType
enum class EWeaponSkinType : uint8_t {
	Material = 0,
	Mesh = 1,
	EWeaponSkinType_MAX = 2
};

// Object: Enum Solarland.EWeaponMechanicalSideFlag
enum class EWeaponMechanicalSideFlag : int32_t {
	None = 0,
	OnGround = 2,
	Unequip = 4,
	OpenScope = 8,
	ForceFiring = 16,
	ChargedFire = 32,
	NeedBolt = 64,
	GatlingRolling = 128,
	DetectedWall = 256,
	NeedRechamber = 512,
	NoAmmoReserved = 1024,
	ReloadRecover = 2048,
	EWeaponMechanicalSideFlag_MAX = 2049
};

// Object: Enum Solarland.EWeaponMechanicalUniqueState
enum class EWeaponMechanicalUniqueState : uint8_t {
	None = 0,
	Idle = 1,
	PreFire = 2,
	RealFire = 3,
	Rechamber = 4,
	Reloading = 5,
	Bolting = 6,
	Charging = 7,
	Overloading = 8,
	KeyUPHolding = 9,
	EWeaponMechanicalUniqueState_MAX = 10
};

// Object: Enum Solarland.EWeaponRecoilPatternType
enum class EWeaponRecoilPatternType : uint8_t {
	Auto = 0,
	Burst = 1,
	EWeaponRecoilPatternType_MAX = 2
};

// Object: Enum Solarland.EFixedValueMode
enum class EFixedValueMode : uint8_t {
	Raw = 0,
	Increment = 1,
	EFixedValueMode_MAX = 2
};

// Object: Enum Solarland.EWeaponSpreadDistributionRule
enum class EWeaponSpreadDistributionRule : uint8_t {
	CentralLimitTheorem = 0,
	DistributionCurve = 1,
	Canister = 2,
	CanisterFixed = 3,
	EWeaponSpreadDistributionRule_MAX = 4
};

// Object: Enum Solarland.ESolarWeaponFireInputButtonState
enum class ESolarWeaponFireInputButtonState : uint8_t {
	FireWaiting = 0,
	FirePressed = 1,
	CancelWaiting = 2,
	CancelPressed = 3,
	Invalid = 4,
	ESolarWeaponFireInputButtonState_MAX = 5
};

// Object: Enum Solarland.ECheckFireResultType
enum class ECheckFireResultType : uint8_t {
	None = 0,
	Fire = 1,
	Reload = 2,
	OpenScope = 3,
	CloseScope = 4,
	Charge = 5,
	EndCharge = 6,
	ECheckFireResultType_MAX = 7
};

// Object: Enum Solarland.EOperateScopeStateReason
enum class EOperateScopeStateReason : uint8_t {
	None = 0,
	OpenScopeButton = 1,
	OpenQuickAds = 2,
	Open = 3,
	CloseScopeButton = 16,
	CloseReload = 32,
	CloseBolt = 64,
	Close = 112,
	ScopeButton = 17,
	AllFlag = 115,
	EOperateScopeStateReason_MAX = 116
};

// Object: Enum Solarland.EWeaponOperationExecutionReason
enum class EWeaponOperationExecutionReason : uint8_t {
	None = 0,
	NetOwner = 1,
	NetSync = 2,
	Local = 3,
	EWeaponOperationExecutionReason_MAX = 4
};

// Object: Enum Solarland.EWeaponStatusResetReason
enum class EWeaponStatusResetReason : uint8_t {
	None = 0,
	Initialized = 1,
	HasExpiredOperation = 2,
	BeSpectatedAsLocalPlayer = 3,
	EquipFailed = 4,
	EWeaponStatusResetReason_MAX = 5
};

// Object: Enum Solarland.EVehicleWeaponServerRecieveProto
enum class EVehicleWeaponServerRecieveProto : uint8_t {
	Reload = 0,
	StartReload = 1,
	EVehicleWeaponServerRecieveProto_MAX = 2
};

// Object: Enum Solarland.EWeaponSystemVehicleState
enum class EWeaponSystemVehicleState : uint8_t {
	PreCharging = 0,
	PreFire = 1,
	PreReload = 2,
	PreOpenScope = 3,
	PreCloseScope = 4,
	PreFireOverload = 5,
	EWeaponSystemVehicleState_MAX = 6
};

// Object: Enum Solarland.EWeaponSystemVehicleProto
enum class EWeaponSystemVehicleProto : uint8_t {
	EWeaponSystemVehicleProto_Equip = 0,
	EWeaponSystemVehicleProto_UnEquip = 1,
	EWeaponSystemVehicleProto_StartReload = 2,
	EWeaponSystemVehicleProto_MAX = 3
};

// Object: Enum Solarland.ECenterToTargetMarkState
enum class ECenterToTargetMarkState : uint8_t {
	E_Center = 0,
	E_MoveToTarget = 1,
	E_Target = 2,
	E_MAX = 3
};

// Object: Enum Solarland.EHeroSubItemDeviceState
enum class EHeroSubItemDeviceState : uint8_t {
	E_Normal = 0,
	E_Warning = 1,
	E_Trigger = 2,
	E_Hit = 3,
	E_Destroyed = 4,
	E_MAX = 5
};

// Object: Enum Solarland.EHeroSubItemType
enum class EHeroSubItemType : uint8_t {
	E_Owl = 0,
	E_AIDog = 1,
	E_Rex = 2,
	E_MAX = 3
};

// Object: Enum Solarland.EMarkButtonState
enum class EMarkButtonState : uint8_t {
	Normal = 0,
	Pressed = 1,
	Selecting = 2,
	Canceled = 3,
	Respond = 4,
	EMarkButtonState_MAX = 5
};

// Object: Enum Solarland.EMiniMapMarkOperationType
enum class EMiniMapMarkOperationType : uint8_t {
	None = 0,
	CreateMiniMapIcon = 1,
	SelectMiniMapIcon = 2,
	EMiniMapMarkOperationType_MAX = 3
};

// Object: Enum Solarland.EWorldMarkOperationType
enum class EWorldMarkOperationType : uint8_t {
	Mark = 0,
	CancelMark = 1,
	Response = 2,
	CancelResponse = 3,
	WasResponsedByOther = 4,
	NoOperation = 5,
	EWorldMarkOperationType_MAX = 6
};

