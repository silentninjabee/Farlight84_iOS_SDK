#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class SpinePlugin.SpineAtlasAsset
// Inherited Bytes: 0x30 | Struct Size: 0x60
struct USpineAtlasAsset : UPrimaryDataAsset {
	// Fields
	struct TArray<struct UTexture2D*> atlasPages; // Offset: 0x30 | Size: 0x10
	char pad_0x40[0x8]; // Offset: 0x40 | Size: 0x8
	struct FString RawData; // Offset: 0x48 | Size: 0x10
	struct FName atlasFileName; // Offset: 0x58 | Size: 0x8
};

// Object: Class SpinePlugin.SpineBoneDriverComponent
// Inherited Bytes: 0x370 | Struct Size: 0x390
struct USpineBoneDriverComponent : USceneComponent {
	// Fields
	struct AActor* Target; // Offset: 0x368 | Size: 0x8
	struct FString BoneName; // Offset: 0x370 | Size: 0x10
	bool UseComponentTransform; // Offset: 0x380 | Size: 0x1
	bool UsePosition; // Offset: 0x381 | Size: 0x1
	bool UseRotation; // Offset: 0x382 | Size: 0x1
	bool UseScale; // Offset: 0x383 | Size: 0x1
	char pad_0x38C[0x4]; // Offset: 0x38c | Size: 0x4

	// Functions

	// Object: Function SpinePlugin.SpineBoneDriverComponent.BeforeUpdateWorldTransform
	// Flags: [Final|Native|Protected]
	// Offset: 0x10364c78c
	// Return & Params: [ Num(1) Size(0x8) ]
	void BeforeUpdateWorldTransform(struct USpineSkeletonComponent* Skeleton);
};

// Object: Class SpinePlugin.SpineBoneFollowerComponent
// Inherited Bytes: 0x370 | Struct Size: 0x390
struct USpineBoneFollowerComponent : USceneComponent {
	// Fields
	struct AActor* Target; // Offset: 0x368 | Size: 0x8
	struct FString BoneName; // Offset: 0x370 | Size: 0x10
	bool UseComponentTransform; // Offset: 0x380 | Size: 0x1
	bool UsePosition; // Offset: 0x381 | Size: 0x1
	bool UseRotation; // Offset: 0x382 | Size: 0x1
	bool UseScale; // Offset: 0x383 | Size: 0x1
	char pad_0x38C[0x4]; // Offset: 0x38c | Size: 0x4
};

// Object: Class SpinePlugin.TrackEntry
// Inherited Bytes: 0x28 | Struct Size: 0x90
struct UTrackEntry : UObject {
	// Fields
	struct FMulticastInlineDelegate animationStart; // Offset: 0x28 | Size: 0x10
	struct FMulticastInlineDelegate AnimationInterrupt; // Offset: 0x38 | Size: 0x10
	struct FMulticastInlineDelegate AnimationEvent; // Offset: 0x48 | Size: 0x10
	struct FMulticastInlineDelegate AnimationComplete; // Offset: 0x58 | Size: 0x10
	struct FMulticastInlineDelegate animationEnd; // Offset: 0x68 | Size: 0x10
	struct FMulticastInlineDelegate AnimationDispose; // Offset: 0x78 | Size: 0x10
	char pad_0x88[0x8]; // Offset: 0x88 | Size: 0x8

	// Functions

	// Object: Function SpinePlugin.TrackEntry.SetTrackTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364ccf4
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetTrackTime(float trackTime);

	// Object: Function SpinePlugin.TrackEntry.SetTrackEnd
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364cc88
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetTrackEnd(float trackEnd);

	// Object: Function SpinePlugin.TrackEntry.SetTimeScale
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364cc1c
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetTimeScale(float TimeScale);

	// Object: Function SpinePlugin.TrackEntry.SetMixTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364cb44
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetMixTime(float mixTime);

	// Object: Function SpinePlugin.TrackEntry.SetMixDuration
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364cad8
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetMixDuration(float mixDuration);

	// Object: Function SpinePlugin.TrackEntry.SetLoop
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364d054
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetLoop(bool Loop);

	// Object: Function SpinePlugin.TrackEntry.SetEventThreshold
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364cfe8
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetEventThreshold(float eventThreshold);

	// Object: Function SpinePlugin.TrackEntry.SetDrawOrderThreshold
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364cf10
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetDrawOrderThreshold(float drawOrderThreshold);

	// Object: Function SpinePlugin.TrackEntry.SetDelay
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364cd60
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetDelay(float Delay);

	// Object: Function SpinePlugin.TrackEntry.SetAttachmentThreshold
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364cf7c
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetAttachmentThreshold(float attachmentThreshold);

	// Object: Function SpinePlugin.TrackEntry.SetAnimationStart
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364cea4
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetAnimationStart(float animationStart);

	// Object: Function SpinePlugin.TrackEntry.SetAnimationLast
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364cdcc
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetAnimationLast(float animationLast);

	// Object: Function SpinePlugin.TrackEntry.SetAnimationEnd
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364ce38
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetAnimationEnd(float animationEnd);

	// Object: Function SpinePlugin.TrackEntry.SetAlpha
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364cbb0
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetAlpha(float Alpha);

	// Object: Function SpinePlugin.TrackEntry.isValidAnimation
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364c968
	// Return & Params: [ Num(1) Size(0x1) ]
	bool isValidAnimation();

	// Object: Function SpinePlugin.TrackEntry.GetTrackTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364cd34
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetTrackTime();

	// Object: Function SpinePlugin.TrackEntry.GetTrackIndex
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364d0d0
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetTrackIndex();

	// Object: Function SpinePlugin.TrackEntry.GetTrackEnd
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364ccc8
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetTrackEnd();

	// Object: Function SpinePlugin.TrackEntry.GetTimeScale
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364cc5c
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetTimeScale();

	// Object: Function SpinePlugin.TrackEntry.GetMixTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364cb84
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetMixTime();

	// Object: Function SpinePlugin.TrackEntry.GetMixDuration
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364cb18
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetMixDuration();

	// Object: Function SpinePlugin.TrackEntry.GetLoop
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364d0ac
	// Return & Params: [ Num(1) Size(0x1) ]
	bool GetLoop();

	// Object: Function SpinePlugin.TrackEntry.GetEventThreshold
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364d028
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetEventThreshold();

	// Object: Function SpinePlugin.TrackEntry.GetDrawOrderThreshold
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364cf50
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetDrawOrderThreshold();

	// Object: Function SpinePlugin.TrackEntry.GetDelay
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364cda0
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetDelay();

	// Object: Function SpinePlugin.TrackEntry.GetAttachmentThreshold
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364cfbc
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetAttachmentThreshold();

	// Object: Function SpinePlugin.TrackEntry.GetAnimationStart
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364cee4
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetAnimationStart();

	// Object: Function SpinePlugin.TrackEntry.getAnimationName
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364c9b8
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString getAnimationName();

	// Object: Function SpinePlugin.TrackEntry.GetAnimationLast
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364ce0c
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetAnimationLast();

	// Object: Function SpinePlugin.TrackEntry.GetAnimationEnd
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364ce78
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetAnimationEnd();

	// Object: Function SpinePlugin.TrackEntry.getAnimationDuration
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364c988
	// Return & Params: [ Num(1) Size(0x4) ]
	float getAnimationDuration();

	// Object: Function SpinePlugin.TrackEntry.GetAlpha
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364cbf0
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetAlpha();
};

// Object: Class SpinePlugin.SpineSkeletonComponent
// Inherited Bytes: 0xc0 | Struct Size: 0x118
struct USpineSkeletonComponent : UActorComponent {
	// Fields
	struct USpineAtlasAsset* Atlas; // Offset: 0xc0 | Size: 0x8
	struct USpineSkeletonDataAsset* SkeletonData; // Offset: 0xc8 | Size: 0x8
	struct FMulticastInlineDelegate BeforeUpdateWorldTransform; // Offset: 0xd0 | Size: 0x10
	struct FMulticastInlineDelegate AfterUpdateWorldTransform; // Offset: 0xe0 | Size: 0x10
	char pad_0xF0[0x28]; // Offset: 0xf0 | Size: 0x28

	// Functions

	// Object: Function SpinePlugin.SpineSkeletonComponent.UpdateWorldTransform
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364e4e0
	// Return & Params: [ Num(0) Size(0x0) ]
	void UpdateWorldTransform();

	// Object: Function SpinePlugin.SpineSkeletonComponent.SetToSetupPose
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364e4d0
	// Return & Params: [ Num(0) Size(0x0) ]
	void SetToSetupPose();

	// Object: Function SpinePlugin.SpineSkeletonComponent.SetSlotsToSetupPose
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364e4b0
	// Return & Params: [ Num(0) Size(0x0) ]
	void SetSlotsToSetupPose();

	// Object: Function SpinePlugin.SpineSkeletonComponent.SetSlotColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x10364e17c
	// Return & Params: [ Num(2) Size(0x14) ]
	void SetSlotColor(struct FString SlotName, struct FColor Color);

	// Object: Function SpinePlugin.SpineSkeletonComponent.SetSkins
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10364e81c
	// Return & Params: [ Num(2) Size(0x11) ]
	bool SetSkins(struct TArray<struct FString>& SkinNames);

	// Object: Function SpinePlugin.SpineSkeletonComponent.SetSkin
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364e7a8
	// Return & Params: [ Num(2) Size(0x11) ]
	bool SetSkin(struct FString SkinName);

	// Object: Function SpinePlugin.SpineSkeletonComponent.SetScaleY
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364e41c
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetScaleY(float ScaleY);

	// Object: Function SpinePlugin.SpineSkeletonComponent.SetScaleX
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364e478
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetScaleX(float ScaleX);

	// Object: Function SpinePlugin.SpineSkeletonComponent.SetBoneWorldPosition
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10364e4f0
	// Return & Params: [ Num(2) Size(0x1c) ]
	void SetBoneWorldPosition(struct FString BoneName, struct FVector& Position);

	// Object: Function SpinePlugin.SpineSkeletonComponent.SetBonesToSetupPose
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364e4c0
	// Return & Params: [ Num(0) Size(0x0) ]
	void SetBonesToSetupPose();

	// Object: Function SpinePlugin.SpineSkeletonComponent.SetAttachment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364e640
	// Return & Params: [ Num(3) Size(0x21) ]
	bool SetAttachment(struct FString SlotName, struct FString attachmentName);

	// Object: Function SpinePlugin.SpineSkeletonComponent.HasSlot
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364e260
	// Return & Params: [ Num(2) Size(0x11) ]
	bool HasSlot(struct FString SlotName);

	// Object: Function SpinePlugin.SpineSkeletonComponent.HasSkin
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364e734
	// Return & Params: [ Num(2) Size(0x11) ]
	bool HasSkin(struct FString SkinName);

	// Object: Function SpinePlugin.SpineSkeletonComponent.HasBone
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364e32c
	// Return & Params: [ Num(2) Size(0x11) ]
	bool HasBone(struct FString BoneName);

	// Object: Function SpinePlugin.SpineSkeletonComponent.HasAnimation
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364e0b0
	// Return & Params: [ Num(2) Size(0x11) ]
	bool HasAnimation(struct FString AnimationName);

	// Object: Function SpinePlugin.SpineSkeletonComponent.GetSlots
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x10364e2d4
	// Return & Params: [ Num(1) Size(0x10) ]
	void GetSlots(struct TArray<struct FString>& Slots);

	// Object: Function SpinePlugin.SpineSkeletonComponent.GetSkins
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x10364e884
	// Return & Params: [ Num(1) Size(0x10) ]
	void GetSkins(struct TArray<struct FString>& Skins);

	// Object: Function SpinePlugin.SpineSkeletonComponent.GetScaleY
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364e3f8
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetScaleY();

	// Object: Function SpinePlugin.SpineSkeletonComponent.GetScaleX
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364e454
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetScaleX();

	// Object: Function SpinePlugin.SpineSkeletonComponent.GetBoneWorldTransform
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x10364e598
	// Return & Params: [ Num(2) Size(0x40) ]
	struct FTransform GetBoneWorldTransform(struct FString BoneName);

	// Object: Function SpinePlugin.SpineSkeletonComponent.GetBones
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x10364e3a0
	// Return & Params: [ Num(1) Size(0x10) ]
	void GetBones(struct TArray<struct FString>& Bones);

	// Object: Function SpinePlugin.SpineSkeletonComponent.GetAnimations
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x10364e124
	// Return & Params: [ Num(1) Size(0x10) ]
	void GetAnimations(struct TArray<struct FString>& Animations);

	// Object: Function SpinePlugin.SpineSkeletonComponent.getAnimationDuration
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364e038
	// Return & Params: [ Num(2) Size(0x14) ]
	float getAnimationDuration(struct FString AnimationName);
};

// Object: Class SpinePlugin.SpineSkeletonAnimationComponent
// Inherited Bytes: 0x118 | Struct Size: 0x218
struct USpineSkeletonAnimationComponent : USpineSkeletonComponent {
	// Fields
	struct FMulticastInlineDelegate animationStart; // Offset: 0x118 | Size: 0x10
	struct FMulticastInlineDelegate AnimationInterrupt; // Offset: 0x128 | Size: 0x10
	struct FMulticastInlineDelegate AnimationEvent; // Offset: 0x138 | Size: 0x10
	struct FMulticastInlineDelegate AnimationComplete; // Offset: 0x148 | Size: 0x10
	struct FMulticastInlineDelegate animationEnd; // Offset: 0x158 | Size: 0x10
	struct FMulticastInlineDelegate AnimationDispose; // Offset: 0x168 | Size: 0x10
	struct FString PreviewAnimation; // Offset: 0x178 | Size: 0x10
	struct FString PreviewSkin; // Offset: 0x188 | Size: 0x10
	char pad_0x198[0x8]; // Offset: 0x198 | Size: 0x8
	struct TSet<struct UTrackEntry*> trackEntries; // Offset: 0x1a0 | Size: 0x50
	bool bAutoPlaying; // Offset: 0x1f0 | Size: 0x1
	char pad_0x1F1[0x27]; // Offset: 0x1f1 | Size: 0x27

	// Functions

	// Object: Function SpinePlugin.SpineSkeletonAnimationComponent.SetTimeScale
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364dc90
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetTimeScale(float TimeScale);

	// Object: Function SpinePlugin.SpineSkeletonAnimationComponent.SetPlaybackTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364dcc8
	// Return & Params: [ Num(2) Size(0x5) ]
	void SetPlaybackTime(float InPlaybackTime, bool bCallDelegates);

	// Object: Function SpinePlugin.SpineSkeletonAnimationComponent.SetEmptyAnimation
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364d9cc
	// Return & Params: [ Num(3) Size(0x10) ]
	struct UTrackEntry* SetEmptyAnimation(int32_t TrackIndex, float mixDuration);

	// Object: Function SpinePlugin.SpineSkeletonAnimationComponent.SetAutoPlay
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364dd3c
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetAutoPlay(bool bInAutoPlays);

	// Object: Function SpinePlugin.SpineSkeletonAnimationComponent.SetAnimation
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364db70
	// Return & Params: [ Num(4) Size(0x28) ]
	struct UTrackEntry* SetAnimation(int32_t TrackIndex, struct FString AnimationName, bool Loop);

	// Object: Function SpinePlugin.SpineSkeletonAnimationComponent.GetTimeScale
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364dc6c
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetTimeScale();

	// Object: Function SpinePlugin.SpineSkeletonAnimationComponent.GetCurrent
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364d8b8
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UTrackEntry* GetCurrent(int32_t TrackIndex);

	// Object: Function SpinePlugin.SpineSkeletonAnimationComponent.ClearTracks
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364d8a8
	// Return & Params: [ Num(0) Size(0x0) ]
	void ClearTracks();

	// Object: Function SpinePlugin.SpineSkeletonAnimationComponent.ClearTrack
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364d870
	// Return & Params: [ Num(1) Size(0x4) ]
	void ClearTrack(int32_t TrackIndex);

	// Object: Function SpinePlugin.SpineSkeletonAnimationComponent.AddEmptyAnimation
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364d910
	// Return & Params: [ Num(4) Size(0x18) ]
	struct UTrackEntry* AddEmptyAnimation(int32_t TrackIndex, float mixDuration, float Delay);

	// Object: Function SpinePlugin.SpineSkeletonAnimationComponent.AddAnimation
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364da54
	// Return & Params: [ Num(5) Size(0x28) ]
	struct UTrackEntry* AddAnimation(int32_t TrackIndex, struct FString AnimationName, bool Loop, float Delay);
};

// Object: Class SpinePlugin.SpineSkeletonDataAsset
// Inherited Bytes: 0x28 | Struct Size: 0xf8
struct USpineSkeletonDataAsset : UObject {
	// Fields
	float DefaultMix; // Offset: 0x28 | Size: 0x4
	char pad_0x2C[0x4]; // Offset: 0x2c | Size: 0x4
	struct TArray<struct FSpineAnimationStateMixData> MixData; // Offset: 0x30 | Size: 0x10
	struct TArray<struct FString> Bones; // Offset: 0x40 | Size: 0x10
	struct TArray<struct FString> Slots; // Offset: 0x50 | Size: 0x10
	struct TArray<struct FString> Skins; // Offset: 0x60 | Size: 0x10
	struct TArray<struct FString> Animations; // Offset: 0x70 | Size: 0x10
	struct TArray<struct FString> Events; // Offset: 0x80 | Size: 0x10
	struct TArray<char> RawData; // Offset: 0x90 | Size: 0x10
	struct FName skeletonDataFileName; // Offset: 0xa0 | Size: 0x8
	char pad_0xA8[0x50]; // Offset: 0xa8 | Size: 0x50
};

// Object: Class SpinePlugin.SpineSkeletonRendererComponent
// Inherited Bytes: 0x700 | Struct Size: 0x9c0
struct USpineSkeletonRendererComponent : UProceduralMeshComponent {
	// Fields
	struct UMaterialInterface* NormalBlendMaterial; // Offset: 0x700 | Size: 0x8
	struct UMaterialInterface* AdditiveBlendMaterial; // Offset: 0x708 | Size: 0x8
	struct UMaterialInterface* MultiplyBlendMaterial; // Offset: 0x710 | Size: 0x8
	struct UMaterialInterface* ScreenBlendMaterial; // Offset: 0x718 | Size: 0x8
	struct TArray<struct UMaterialInstanceDynamic*> atlasNormalBlendMaterials; // Offset: 0x720 | Size: 0x10
	struct TArray<struct UMaterialInstanceDynamic*> atlasAdditiveBlendMaterials; // Offset: 0x730 | Size: 0x10
	struct TArray<struct UMaterialInstanceDynamic*> atlasMultiplyBlendMaterials; // Offset: 0x740 | Size: 0x10
	struct TArray<struct UMaterialInstanceDynamic*> atlasScreenBlendMaterials; // Offset: 0x750 | Size: 0x10
	float DepthOffset; // Offset: 0x760 | Size: 0x4
	struct FName TextureParameterName; // Offset: 0x764 | Size: 0x8
	struct FLinearColor Color; // Offset: 0x76c | Size: 0x10
	bool bCreateCollision; // Offset: 0x77c | Size: 0x1
	char pad_0x77D[0x1f3]; // Offset: 0x77d | Size: 0x1f3
	struct TArray<struct FVector> Vertices; // Offset: 0x970 | Size: 0x10
	struct TArray<int32_t> Indices; // Offset: 0x980 | Size: 0x10
	struct TArray<struct FVector> Normals; // Offset: 0x990 | Size: 0x10
	struct TArray<struct FVector2D> UVs; // Offset: 0x9a0 | Size: 0x10
	struct TArray<struct FColor> Colors; // Offset: 0x9b0 | Size: 0x10
};

// Object: Class SpinePlugin.SpineWidget
// Inherited Bytes: 0x138 | Struct Size: 0x720
struct USpineWidget : UWidget {
	// Fields
	struct FString InitialSkin; // Offset: 0x138 | Size: 0x10
	struct USpineAtlasAsset* Atlas; // Offset: 0x148 | Size: 0x8
	struct USpineSkeletonDataAsset* SkeletonData; // Offset: 0x150 | Size: 0x8
	struct UMaterialInterface* NormalBlendMaterial; // Offset: 0x158 | Size: 0x8
	struct UMaterialInterface* AdditiveBlendMaterial; // Offset: 0x160 | Size: 0x8
	struct UMaterialInterface* MultiplyBlendMaterial; // Offset: 0x168 | Size: 0x8
	struct UMaterialInterface* ScreenBlendMaterial; // Offset: 0x170 | Size: 0x8
	struct FName TextureParameterName; // Offset: 0x178 | Size: 0x8
	float DepthOffset; // Offset: 0x180 | Size: 0x4
	struct FLinearColor Color; // Offset: 0x184 | Size: 0x10
	char pad_0x194[0xc]; // Offset: 0x194 | Size: 0xc
	struct FSlateBrush Brush; // Offset: 0x1a0 | Size: 0xf0
	struct FMulticastInlineDelegate BeforeUpdateWorldTransform; // Offset: 0x290 | Size: 0x10
	struct FMulticastInlineDelegate AfterUpdateWorldTransform; // Offset: 0x2a0 | Size: 0x10
	struct FMulticastInlineDelegate animationStart; // Offset: 0x2b0 | Size: 0x10
	struct FMulticastInlineDelegate AnimationInterrupt; // Offset: 0x2c0 | Size: 0x10
	struct FMulticastInlineDelegate AnimationEvent; // Offset: 0x2d0 | Size: 0x10
	struct FMulticastInlineDelegate AnimationComplete; // Offset: 0x2e0 | Size: 0x10
	struct FMulticastInlineDelegate animationEnd; // Offset: 0x2f0 | Size: 0x10
	struct FMulticastInlineDelegate AnimationDispose; // Offset: 0x300 | Size: 0x10
	char pad_0x310[0x40]; // Offset: 0x310 | Size: 0x40
	struct TArray<struct UMaterialInstanceDynamic*> atlasNormalBlendMaterials; // Offset: 0x350 | Size: 0x10
	char pad_0x360[0x50]; // Offset: 0x360 | Size: 0x50
	struct TArray<struct UMaterialInstanceDynamic*> atlasAdditiveBlendMaterials; // Offset: 0x3b0 | Size: 0x10
	char pad_0x3C0[0x50]; // Offset: 0x3c0 | Size: 0x50
	struct TArray<struct UMaterialInstanceDynamic*> atlasMultiplyBlendMaterials; // Offset: 0x410 | Size: 0x10
	char pad_0x420[0x50]; // Offset: 0x420 | Size: 0x50
	struct TArray<struct UMaterialInstanceDynamic*> atlasScreenBlendMaterials; // Offset: 0x470 | Size: 0x10
	char pad_0x480[0x240]; // Offset: 0x480 | Size: 0x240
	struct TSet<struct UTrackEntry*> trackEntries; // Offset: 0x6c0 | Size: 0x50
	bool bAutoPlaying; // Offset: 0x710 | Size: 0x1
	char pad_0x711[0xf]; // Offset: 0x711 | Size: 0xf

	// Functions

	// Object: Function SpinePlugin.SpineWidget.UpdateWorldTransform
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364f978
	// Return & Params: [ Num(0) Size(0x0) ]
	void UpdateWorldTransform();

	// Object: Function SpinePlugin.SpineWidget.Tick
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364ef88
	// Return & Params: [ Num(2) Size(0x5) ]
	void Tick(float DeltaTime, bool CallDelegates);

	// Object: Function SpinePlugin.SpineWidget.SetToSetupPose
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364f968
	// Return & Params: [ Num(0) Size(0x0) ]
	void SetToSetupPose();

	// Object: Function SpinePlugin.SpineWidget.SetTimeScale
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364f41c
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetTimeScale(float TimeScale);

	// Object: Function SpinePlugin.SpineWidget.SetSlotsToSetupPose
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364f948
	// Return & Params: [ Num(0) Size(0x0) ]
	void SetSlotsToSetupPose();

	// Object: Function SpinePlugin.SpineWidget.SetSkins
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10364faf0
	// Return & Params: [ Num(2) Size(0x11) ]
	bool SetSkins(struct TArray<struct FString>& SkinNames);

	// Object: Function SpinePlugin.SpineWidget.SetSkin
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364fb58
	// Return & Params: [ Num(2) Size(0x11) ]
	bool SetSkin(struct FString SkinName);

	// Object: Function SpinePlugin.SpineWidget.SetScaleY
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364f8b4
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetScaleY(float ScaleY);

	// Object: Function SpinePlugin.SpineWidget.SetScaleX
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364f910
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetScaleX(float ScaleX);

	// Object: Function SpinePlugin.SpineWidget.SetPlaybackTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364f454
	// Return & Params: [ Num(2) Size(0x5) ]
	void SetPlaybackTime(float InPlaybackTime, bool bCallDelegates);

	// Object: Function SpinePlugin.SpineWidget.SetEmptyAnimation
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364f158
	// Return & Params: [ Num(3) Size(0x10) ]
	struct UTrackEntry* SetEmptyAnimation(int32_t TrackIndex, float mixDuration);

	// Object: Function SpinePlugin.SpineWidget.SetBonesToSetupPose
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364f958
	// Return & Params: [ Num(0) Size(0x0) ]
	void SetBonesToSetupPose();

	// Object: Function SpinePlugin.SpineWidget.SetAutoPlay
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364f4c8
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetAutoPlay(bool bInAutoPlays);

	// Object: Function SpinePlugin.SpineWidget.SetAttachment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364f988
	// Return & Params: [ Num(3) Size(0x21) ]
	bool SetAttachment(struct FString SlotName, struct FString attachmentName);

	// Object: Function SpinePlugin.SpineWidget.SetAnimation
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364f2fc
	// Return & Params: [ Num(4) Size(0x28) ]
	struct UTrackEntry* SetAnimation(int32_t TrackIndex, struct FString AnimationName, bool Loop);

	// Object: Function SpinePlugin.SpineWidget.HasSlot
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364f650
	// Return & Params: [ Num(2) Size(0x11) ]
	bool HasSlot(struct FString SlotName);

	// Object: Function SpinePlugin.SpineWidget.HasSkin
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364fa7c
	// Return & Params: [ Num(2) Size(0x11) ]
	bool HasSkin(struct FString SkinName);

	// Object: Function SpinePlugin.SpineWidget.HasBone
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364f7c4
	// Return & Params: [ Num(2) Size(0x11) ]
	bool HasBone(struct FString BoneName);

	// Object: Function SpinePlugin.SpineWidget.HasAnimation
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364f584
	// Return & Params: [ Num(2) Size(0x11) ]
	bool HasAnimation(struct FString AnimationName);

	// Object: Function SpinePlugin.SpineWidget.GetTimeScale
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364f3f8
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetTimeScale();

	// Object: Function SpinePlugin.SpineWidget.GetSlots
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x10364f6c4
	// Return & Params: [ Num(1) Size(0x10) ]
	void GetSlots(struct TArray<struct FString>& Slots);

	// Object: Function SpinePlugin.SpineWidget.GetSkins
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x10364fbcc
	// Return & Params: [ Num(1) Size(0x10) ]
	void GetSkins(struct TArray<struct FString>& Skins);

	// Object: Function SpinePlugin.SpineWidget.GetScaleY
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364f890
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetScaleY();

	// Object: Function SpinePlugin.SpineWidget.GetScaleX
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364f8ec
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetScaleX();

	// Object: Function SpinePlugin.SpineWidget.GetCurrent
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364f044
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UTrackEntry* GetCurrent(int32_t TrackIndex);

	// Object: Function SpinePlugin.SpineWidget.GetBoneTransform
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x10364f71c
	// Return & Params: [ Num(2) Size(0x40) ]
	struct FTransform GetBoneTransform(struct FString BoneName);

	// Object: Function SpinePlugin.SpineWidget.GetBones
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x10364f838
	// Return & Params: [ Num(1) Size(0x10) ]
	void GetBones(struct TArray<struct FString>& Bones);

	// Object: Function SpinePlugin.SpineWidget.GetAnimations
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x10364f5f8
	// Return & Params: [ Num(1) Size(0x10) ]
	void GetAnimations(struct TArray<struct FString>& Animations);

	// Object: Function SpinePlugin.SpineWidget.getAnimationDuration
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364f50c
	// Return & Params: [ Num(2) Size(0x14) ]
	float getAnimationDuration(struct FString AnimationName);

	// Object: Function SpinePlugin.SpineWidget.ClearTracks
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364f034
	// Return & Params: [ Num(0) Size(0x0) ]
	void ClearTracks();

	// Object: Function SpinePlugin.SpineWidget.ClearTrack
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364effc
	// Return & Params: [ Num(1) Size(0x4) ]
	void ClearTrack(int32_t TrackIndex);

	// Object: Function SpinePlugin.SpineWidget.AddEmptyAnimation
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364f09c
	// Return & Params: [ Num(4) Size(0x18) ]
	struct UTrackEntry* AddEmptyAnimation(int32_t TrackIndex, float mixDuration, float Delay);

	// Object: Function SpinePlugin.SpineWidget.AddAnimation
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10364f1e0
	// Return & Params: [ Num(5) Size(0x28) ]
	struct UTrackEntry* AddAnimation(int32_t TrackIndex, struct FString AnimationName, bool Loop, float Delay);
};

