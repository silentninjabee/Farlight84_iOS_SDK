#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Express_State.UI_Express_State_C
// Inherited Bytes: 0x510 | Struct Size: 0x550
struct UUI_Express_State_C : USkillExpressStateWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x510 | Size: 0x8
	struct UImage* Img_Disable; // Offset: 0x518 | Size: 0x8
	struct UImage* Img_Icon; // Offset: 0x520 | Size: 0x8
	struct UImage* Img_Progress_Bg; // Offset: 0x528 | Size: 0x8
	struct UUI_KeyPrompt_C* KeyBuddyBall; // Offset: 0x530 | Size: 0x8
	struct UCanvasPanel* Panel_Icon; // Offset: 0x538 | Size: 0x8
	struct UCanvasPanel* Panel_Info; // Offset: 0x540 | Size: 0x8
	struct USolarTextBlock* txt; // Offset: 0x548 | Size: 0x8

	// Functions

	// Object: Function UI_Express_State.UI_Express_State_C.SetExpressStateAndOutOfScreen
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(2) Size(0x2) ]
	void SetExpressStateAndOutOfScreen(enum class EExpressMarkState ExpressState, bool OutOfScreen);

	// Object: Function UI_Express_State.UI_Express_State_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_Express_State.UI_Express_State_C.OnExpressStateOrOutOfScreenChanged
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(2) Size(0x2) ]
	void OnExpressStateOrOutOfScreenChanged(enum class EExpressMarkState InExpressState, bool InIsOutOfScreen);

	// Object: Function UI_Express_State.UI_Express_State_C.ExecuteUbergraph_UI_Express_State
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x10213e738
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_Express_State(int32_t EntryPoint);
};

