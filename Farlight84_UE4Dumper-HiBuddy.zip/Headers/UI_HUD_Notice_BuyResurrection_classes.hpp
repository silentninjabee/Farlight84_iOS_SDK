#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_HUD_Notice_BuyResurrection.UI_HUD_Notice_BuyResurrection_C
// Inherited Bytes: 0x568 | Struct Size: 0x5c0
struct UUI_HUD_Notice_BuyResurrection_C : UUI_NoticeBase_C {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x568 | Size: 0x8
	struct UWidgetAnimation* ant_exit; // Offset: 0x570 | Size: 0x8
	struct UWidgetAnimation* Appear_Anim; // Offset: 0x578 | Size: 0x8
	struct UImage* Img_Txt_bg; // Offset: 0x580 | Size: 0x8
	struct UCanvasPanel* panel_Resurrection; // Offset: 0x588 | Size: 0x8
	struct URichTextBlock* Txt_Ballte_Notice_2; // Offset: 0x590 | Size: 0x8
	struct USolarTextBlock* Txt_Ballte_Notice_4; // Offset: 0x598 | Size: 0x8
	struct USolarTextBlock* Txt_Ballte_Notice_5; // Offset: 0x5a0 | Size: 0x8
	struct USolarTextBlock* Txt_Notice_2; // Offset: 0x5a8 | Size: 0x8
	struct URichTextBlock* Txt_Revive2; // Offset: 0x5b0 | Size: 0x8
	struct UUIMeshWidget* UIMesh_VX_Line_Loop; // Offset: 0x5b8 | Size: 0x8

	// Functions

	// Object: Function UI_HUD_Notice_BuyResurrection.UI_HUD_Notice_BuyResurrection_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(0) Size(0x0) ]
	void Construct();

	// Object: Function UI_HUD_Notice_BuyResurrection.UI_HUD_Notice_BuyResurrection_C.ShowNotice
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(2) Size(0x14) ]
	void ShowNotice(struct FString Text, float Duration);

	// Object: Function UI_HUD_Notice_BuyResurrection.UI_HUD_Notice_BuyResurrection_C.ExecuteUbergraph_UI_HUD_Notice_BuyResurrection
	// Flags: [Final|UbergraphFunction|HasDefaults]
	// Offset: 0x10213e738
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_HUD_Notice_BuyResurrection(int32_t EntryPoint);
};

