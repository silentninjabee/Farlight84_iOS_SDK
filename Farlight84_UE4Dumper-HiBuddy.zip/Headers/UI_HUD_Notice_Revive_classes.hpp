#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_HUD_Notice_Revive.UI_HUD_Notice_Revive_C
// Inherited Bytes: 0x4e0 | Struct Size: 0x514
struct UUI_HUD_Notice_Revive_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x4e0 | Size: 0x8
	struct UWidgetAnimation* Anim_Enter; // Offset: 0x4e8 | Size: 0x8
	struct USolarRichTextBlock* Txt_CD; // Offset: 0x4f0 | Size: 0x8
	int32_t ReviveWaitTime; // Offset: 0x4f8 | Size: 0x4
	char pad_0x4FC[0x4]; // Offset: 0x4fc | Size: 0x4
	struct ASCMPlayerState* Player; // Offset: 0x500 | Size: 0x8
	struct FTimerHandle HandleEnterAnimEnd; // Offset: 0x508 | Size: 0x8
	float FadeDuringTime; // Offset: 0x510 | Size: 0x4

	// Functions

	// Object: Function UI_HUD_Notice_Revive.UI_HUD_Notice_Revive_C.Visible and Invisible Protection
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(1) Size(0x1) ]
	void Visible and Invisible Protection(bool& Exec);

	// Object: Function UI_HUD_Notice_Revive.UI_HUD_Notice_Revive_C.ShowUI
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(2) Size(0x10) ]
	void ShowUI(int32_t Time, struct ASCMPlayerState* Player);

	// Object: Function UI_HUD_Notice_Revive.UI_HUD_Notice_Revive_C.AddInputFlag
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(0) Size(0x0) ]
	void AddInputFlag();

	// Object: Function UI_HUD_Notice_Revive.UI_HUD_Notice_Revive_C.RemoveInputFlag
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(0) Size(0x0) ]
	void RemoveInputFlag();

	// Object: Function UI_HUD_Notice_Revive.UI_HUD_Notice_Revive_C.TryClopseByPlayer
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(1) Size(0x8) ]
	void TryClopseByPlayer(struct ASCMPlayerState* OldPlayer);

	// Object: Function UI_HUD_Notice_Revive.UI_HUD_Notice_Revive_C.CloseUI
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(1) Size(0x1) ]
	void CloseUI(bool bWithoutDelay);

	// Object: Function UI_HUD_Notice_Revive.UI_HUD_Notice_Revive_C.EndEvent
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(0) Size(0x0) ]
	void EndEvent();

	// Object: Function UI_HUD_Notice_Revive.UI_HUD_Notice_Revive_C.BeginCountDown
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(0) Size(0x0) ]
	void BeginCountDown();

	// Object: Function UI_HUD_Notice_Revive.UI_HUD_Notice_Revive_C.UIEvent_Show
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(1) Size(0x4) ]
	void UIEvent_Show(int32_t ReviveWaitTime);

	// Object: Function UI_HUD_Notice_Revive.UI_HUD_Notice_Revive_C.ResurrectCountDown
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(2) Size(0x8) ]
	void ResurrectCountDown(int32_t InResurrectTime, int32_t InConfigResurrectTime);

	// Object: Function UI_HUD_Notice_Revive.UI_HUD_Notice_Revive_C.ExecuteUbergraph_UI_HUD_Notice_Revive
	// Flags: [Final|UbergraphFunction|HasDefaults]
	// Offset: 0x10213e738
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_HUD_Notice_Revive(int32_t EntryPoint);
};

