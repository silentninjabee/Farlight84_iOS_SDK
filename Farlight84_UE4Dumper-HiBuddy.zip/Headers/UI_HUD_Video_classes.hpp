#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_HUD_Video.UI_HUD_Video_C
// Inherited Bytes: 0x4e0 | Struct Size: 0x51c
struct UUI_HUD_Video_C : USkydivingVideoWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x4e0 | Size: 0x8
	struct UWidgetAnimation* Anim_Exit; // Offset: 0x4e8 | Size: 0x8
	struct UWidgetAnimation* Anim_Enter; // Offset: 0x4f0 | Size: 0x8
	struct UScaleBox* ScaleBox_Txt_3; // Offset: 0x4f8 | Size: 0x8
	struct USolarTextBlock* Txt_City; // Offset: 0x500 | Size: 0x8
	struct USolarTextBlock* Txt_Season; // Offset: 0x508 | Size: 0x8
	struct USolarTextBlock* Txt_Time; // Offset: 0x510 | Size: 0x8
	float WaitTime; // Offset: 0x518 | Size: 0x4

	// Functions

	// Object: Function UI_HUD_Video.UI_HUD_Video_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x10213e738
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();

	// Object: Function UI_HUD_Video.UI_HUD_Video_C.SetArabic
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(0) Size(0x0) ]
	void SetArabic();

	// Object: Function UI_HUD_Video.UI_HUD_Video_C.ShowBattleUIInLua
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(0) Size(0x0) ]
	void ShowBattleUIInLua();

	// Object: Function UI_HUD_Video.UI_HUD_Video_C.OnEnterAnimFinish
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnEnterAnimFinish();

	// Object: Function UI_HUD_Video.UI_HUD_Video_C.OnExitAnimFinish
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnExitAnimFinish();

	// Object: Function UI_HUD_Video.UI_HUD_Video_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(0) Size(0x0) ]
	void Construct();

	// Object: Function UI_HUD_Video.UI_HUD_Video_C.OnSolarUIClosed
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnSolarUIClosed();

	// Object: Function UI_HUD_Video.UI_HUD_Video_C.ShowHUDNotice
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(0) Size(0x0) ]
	void ShowHUDNotice();

	// Object: Function UI_HUD_Video.UI_HUD_Video_C.ExecuteUbergraph_UI_HUD_Video
	// Flags: [Final|UbergraphFunction|HasDefaults]
	// Offset: 0x10213e738
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_HUD_Video(int32_t EntryPoint);
};

