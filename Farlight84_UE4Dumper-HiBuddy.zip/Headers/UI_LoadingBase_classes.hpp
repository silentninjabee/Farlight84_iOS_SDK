#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_LoadingBase.UI_LoadingBase_C
// Inherited Bytes: 0x698 | Struct Size: 0x698
struct UUI_LoadingBase_C : ULoadingUIBase {
};

