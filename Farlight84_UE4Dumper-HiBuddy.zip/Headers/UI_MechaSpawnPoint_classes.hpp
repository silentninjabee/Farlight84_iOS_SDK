#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_MechaSpawnPoint.UI_MechaSpawnPoint_C
// Inherited Bytes: 0x520 | Struct Size: 0x528
struct UUI_MechaSpawnPoint_C : UMapMarkBase {
	// Fields
	struct UWidgetAnimation* Anim_Enter; // Offset: 0x520 | Size: 0x8
};

