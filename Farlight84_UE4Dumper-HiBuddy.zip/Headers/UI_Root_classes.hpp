#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Root.UI_Root_C
// Inherited Bytes: 0x4e0 | Struct Size: 0x569
struct UUI_Root_C : USolarUIRoot {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x4e0 | Size: 0x8
	struct UCanvasPanel* BattleNoticeRoot; // Offset: 0x4e8 | Size: 0x8
	struct UCanvasPanel* BattleRoot; // Offset: 0x4f0 | Size: 0x8
	struct UCanvasPanel* BattleRootGuide; // Offset: 0x4f8 | Size: 0x8
	struct UCanvasPanel* BattleRootOverlay; // Offset: 0x500 | Size: 0x8
	struct UCanvasPanel* CommonRoot; // Offset: 0x508 | Size: 0x8
	struct UCanvasPanel* ExternalToolsRoot; // Offset: 0x510 | Size: 0x8
	struct UCanvasPanel* Guide; // Offset: 0x518 | Size: 0x8
	struct UCanvasPanel* Loading; // Offset: 0x520 | Size: 0x8
	struct UCanvasPanel* Map; // Offset: 0x528 | Size: 0x8
	struct UCanvasPanel* MiddleRoot; // Offset: 0x530 | Size: 0x8
	struct UCanvasPanel* NoticeRoot; // Offset: 0x538 | Size: 0x8
	struct UCanvasPanel* PopRoot; // Offset: 0x540 | Size: 0x8
	struct UCanvasPanel* Reconnecting; // Offset: 0x548 | Size: 0x8
	struct UCanvasPanel* TipsRoot; // Offset: 0x550 | Size: 0x8
	struct UCanvasPanel* UnderBattleRoot; // Offset: 0x558 | Size: 0x8
	float AdapterOffsetLeft; // Offset: 0x560 | Size: 0x4
	float AdapterOffsetRight; // Offset: 0x564 | Size: 0x4
	bool EnableAutoAdaptation; // Offset: 0x568 | Size: 0x1

	// Functions

	// Object: Function UI_Root.UI_Root_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x10113cfa4
	// Return & Params: [ Num(0) Size(0x0) ]
	void Construct();

	// Object: Function UI_Root.UI_Root_C.OnInitialized
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x10113cfa4
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnInitialized();

	// Object: Function UI_Root.UI_Root_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x10213e738
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();

	// Object: Function UI_Root.UI_Root_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_Root.UI_Root_C.CustomEvent_1
	// Flags: [HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(3) Size(0x20) ]
	void CustomEvent_1(struct UObject* Publisher, struct UObject* Payload, struct TArray<struct FString>& MetaData);

	// Object: Function UI_Root.UI_Root_C.ExecuteUbergraph_UI_Root
	// Flags: [Final|UbergraphFunction|HasDefaults]
	// Offset: 0x10213e738
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_Root(int32_t EntryPoint);
};

