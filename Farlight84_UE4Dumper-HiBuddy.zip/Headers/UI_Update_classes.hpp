#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Update.UI_Update_C
// Inherited Bytes: 0x4e0 | Struct Size: 0x6a0
struct UUI_Update_C : UUpdateWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x4e0 | Size: 0x8
	struct UWidgetAnimation* Anim_Enter; // Offset: 0x4e8 | Size: 0x8
	struct UUI_Component_Btn_C* Btn_Account; // Offset: 0x4f0 | Size: 0x8
	struct UButton* Btn_AgeLimit; // Offset: 0x4f8 | Size: 0x8
	struct UUI_Component_Btn_C* Btn_Bind_ActivationCode; // Offset: 0x500 | Size: 0x8
	struct UUI_Component_Btn_C* Btn_Bind_PhoneNumber; // Offset: 0x508 | Size: 0x8
	struct UButton* Btn_Fix; // Offset: 0x510 | Size: 0x8
	struct UUI_Component_Btn_C* btn_link; // Offset: 0x518 | Size: 0x8
	struct USolarButton* btn_link1; // Offset: 0x520 | Size: 0x8
	struct UUI_Update_Server_Btn_C* Btn_National; // Offset: 0x528 | Size: 0x8
	struct UUI_Component_Btn_C* btn_new; // Offset: 0x530 | Size: 0x8
	struct USolarButton* btn_new1; // Offset: 0x538 | Size: 0x8
	struct UButton* Btn_Notice; // Offset: 0x540 | Size: 0x8
	struct UUI_Update_Server_Btn_C* Btn_OutSide; // Offset: 0x548 | Size: 0x8
	struct UUI_Update_Server_Btn_C* Btn_Server; // Offset: 0x550 | Size: 0x8
	struct UUI_Component_Btn_C* Btn_Vistor; // Offset: 0x558 | Size: 0x8
	struct UCanvasPanel* CanvasPanel_2; // Offset: 0x560 | Size: 0x8
	struct UCanvasPanel* CanvasPanel_Server; // Offset: 0x568 | Size: 0x8
	struct UHorizontalBox* HorizontalBox_1; // Offset: 0x570 | Size: 0x8
	struct UHorizontalBox* HorizontalBox_2; // Offset: 0x578 | Size: 0x8
	struct UImage* icon_link; // Offset: 0x580 | Size: 0x8
	struct UImage* Image_173; // Offset: 0x588 | Size: 0x8
	struct UImage* Img_Bg_Update; // Offset: 0x590 | Size: 0x8
	struct UImage* Img_Frame; // Offset: 0x598 | Size: 0x8
	struct UImage* Img_Frame_2; // Offset: 0x5a0 | Size: 0x8
	struct UImage* img_light_link; // Offset: 0x5a8 | Size: 0x8
	struct UImage* Img_Logo; // Offset: 0x5b0 | Size: 0x8
	struct UImage* Img_Mask; // Offset: 0x5b8 | Size: 0x8
	struct UUI_KeyPrompt_C* KeyBack; // Offset: 0x5c0 | Size: 0x8
	struct UCanvasPanel* Panel_Load; // Offset: 0x5c8 | Size: 0x8
	struct UCanvasPanel* Panel_Server; // Offset: 0x5d0 | Size: 0x8
	struct UProgressBar* ProgressBar_Download; // Offset: 0x5d8 | Size: 0x8
	struct UButton* StartGame; // Offset: 0x5e0 | Size: 0x8
	struct USolarTextBlock* StartGameText; // Offset: 0x5e8 | Size: 0x8
	struct USolarTextBlock* text_link; // Offset: 0x5f0 | Size: 0x8
	struct USolarTextBlock* text_new; // Offset: 0x5f8 | Size: 0x8
	struct UTileView* TileView_ServerList; // Offset: 0x600 | Size: 0x8
	struct USolarTextBlock* Txt_GameInfo_CN; // Offset: 0x608 | Size: 0x8
	struct UTextBlock* Txt_LatestBuildNumber; // Offset: 0x610 | Size: 0x8
	struct USolarTextBlock* Txt_Progress; // Offset: 0x618 | Size: 0x8
	struct UTextBlock* Txt_SourceBuildNumber; // Offset: 0x620 | Size: 0x8
	struct USolarTextBlock* Txt_Tips_2; // Offset: 0x628 | Size: 0x8
	struct UUI_Update_UID_C* UI_Update_UID; // Offset: 0x630 | Size: 0x8
	struct UUI_UpdateLoadingBase_C* UpdateLoadingBase; // Offset: 0x638 | Size: 0x8
	struct UWidgetSwitcher* wgs_start; // Offset: 0x640 | Size: 0x8
	struct UMediaPlayer* MediaPlayer; // Offset: 0x648 | Size: 0x8
	struct FSlateColor Color_hoverd; // Offset: 0x650 | Size: 0x28
	struct FSlateColor Color_default; // Offset: 0x678 | Size: 0x28

	// Functions

	// Object: DelegateFunction UI_Update.UI_Update_C.OnClicked_8715AC28F844C2EB61337285494263F0
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10112c8d8
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_8715AC28F844C2EB61337285494263F0();

	// Object: DelegateFunction UI_Update.UI_Update_C.OnLoginFailed_1D9E0B298C49E1415F73F2B6D3580221
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10112c8d8
	// Return & Params: [ Num(2) Size(0x8) ]
	void OnLoginFailed_1D9E0B298C49E1415F73F2B6D3580221(enum class ELLHSDKLoginType LoginType, int32_t ErrorCode);

	// Object: DelegateFunction UI_Update.UI_Update_C.OnInitFinish_5A644D72FF46925C4478B9B8D65B7653
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10112c8d8
	// Return & Params: [ Num(2) Size(0x8) ]
	void OnInitFinish_5A644D72FF46925C4478B9B8D65B7653(bool bSuccess, int32_t ErrorCode);

	// Object: DelegateFunction UI_Update.UI_Update_C.OnClicked_BDA7610A2949E13F3A0C05A9352ADC84
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10112c8d8
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_BDA7610A2949E13F3A0C05A9352ADC84();

	// Object: DelegateFunction UI_Update.UI_Update_C.OnClicked_6475CBB9344F06146A521C9D08BEEFBA
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10112c8d8
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_6475CBB9344F06146A521C9D08BEEFBA();

	// Object: DelegateFunction UI_Update.UI_Update_C.OnReleased_13B4E44CBA4F154705ECBDA7A9F54FFA
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10112c8d8
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnReleased_13B4E44CBA4F154705ECBDA7A9F54FFA();

	// Object: DelegateFunction UI_Update.UI_Update_C.OnAssetManagerPreloadCompleted_150C7B16F24730EA4532DF9AD1A14D78
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10112c8d8
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnAssetManagerPreloadCompleted_150C7B16F24730EA4532DF9AD1A14D78();

	// Object: DelegateFunction UI_Update.UI_Update_C.OnHandleLuaException_ABD49A5A6D40A1A1A2C299886E2D644F
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10112c8d8
	// Return & Params: [ Num(2) Size(0x20) ]
	void OnHandleLuaException_ABD49A5A6D40A1A1A2C299886E2D644F(struct FString ErrorMsg, struct FString StaceTrace);

	// Object: Function UI_Update.UI_Update_C.ReceiveTick
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x10113cfa4
	// Return & Params: [ Num(2) Size(0x3c) ]
	void ReceiveTick(struct FGeometry& MyGeometry, float InDeltaTime);

	// Object: Function UI_Update.UI_Update_C.RequestQuitGame
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x10113cfa4
	// Return & Params: [ Num(0) Size(0x0) ]
	void RequestQuitGame();

	// Object: Function UI_Update.UI_Update_C.OnSolarUIClosed
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x10113cfa4
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnSolarUIClosed();

	// Object: Function UI_Update.UI_Update_C.Destruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x10113cfa4
	// Return & Params: [ Num(0) Size(0x0) ]
	void Destruct();

	// Object: Function UI_Update.UI_Update_C.OnSolarUIOpened
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x10113cfa4
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnSolarUIOpened();

	// Object: Function UI_Update.UI_Update_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x10213e738
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();

	// Object: Function UI_Update.UI_Update_C.RefreshLoadingPointsAr
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(1) Size(0x4) ]
	void RefreshLoadingPointsAr(int32_t Index);

	// Object: Function UI_Update.UI_Update_C.RefreshLoadingPoints
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(1) Size(0x4) ]
	void RefreshLoadingPoints(int32_t Index);

	// Object: Function UI_Update.UI_Update_C.OnVideoReady
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnVideoReady();

	// Object: Function UI_Update.UI_Update_C.InitMedia
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(1) Size(0x1) ]
	void InitMedia(bool& Result);

	// Object: Function UI_Update.UI_Update_C.FinishLoadLobby
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(1) Size(0x4) ]
	void FinishLoadLobby(int32_t Type);

	// Object: Function UI_Update.UI_Update_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_Update.UI_Update_C.Tick
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(2) Size(0x3c) ]
	void Tick(struct FGeometry MyGeometry, float InDeltaTime);

	// Object: Function UI_Update.UI_Update_C.BndEvt__btn_link_K2Node_ComponentBoundEvent_0_OnButtonHoverEvent__DelegateSignature
	// Flags: [BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(0) Size(0x0) ]
	void BndEvt__btn_link_K2Node_ComponentBoundEvent_0_OnButtonHoverEvent__DelegateSignature();

	// Object: Function UI_Update.UI_Update_C.BndEvt__btn_link_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature
	// Flags: [BlueprintEvent]
	// Offset: 0x10213e738
	// Return & Params: [ Num(0) Size(0x0) ]
	void BndEvt__btn_link_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature();

	// Object: Function UI_Update.UI_Update_C.ExecuteUbergraph_UI_Update
	// Flags: [Final|UbergraphFunction|HasDefaults]
	// Offset: 0x10213e738
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_Update(int32_t EntryPoint);
};

