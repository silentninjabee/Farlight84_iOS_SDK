#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct UnLua.PropertyCollector
// Inherited Bytes: 0x0 | Struct Size: 0x1
struct FPropertyCollector {
	// Fields
	struct FTutorialTableRow None; // Offset: 0x0 | Size: 0xa8
	struct FInputKeyMappingEntry None; // Offset: 0x0 | Size: 0x40
};

// Object: ScriptStruct UnLua.InSightEvent
// Inherited Bytes: 0x0 | Struct Size: 0x1
struct FInSightEvent {
	// Fields
	char pad_0x0[0x1]; // Offset: 0x0 | Size: 0x1
};

