#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass WPNGEBP_SlowdownAmmo.WPNGEBP_SlowdownAmmo_C
// Inherited Bytes: 0x898 | Struct Size: 0x898
struct UWPNGEBP_SlowdownAmmo_C : UGameplayEffect {
};

