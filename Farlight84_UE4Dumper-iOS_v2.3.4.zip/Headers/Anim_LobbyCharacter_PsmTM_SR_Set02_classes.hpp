#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: DynamicClass Anim_LobbyCharacter_PsmTM_SR_Set02.Anim_LobbyCharacter_PsmTM_SR_Set02_C
// Inherited Bytes: 0xa50 | Struct Size: 0xa50
struct UAnim_LobbyCharacter_PsmTM_SR_Set02_C : UAnim_LobbyCharacter_Default_C {
};

