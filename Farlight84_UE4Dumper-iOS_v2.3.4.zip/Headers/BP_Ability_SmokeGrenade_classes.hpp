#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_Ability_SmokeGrenade.BP_Ability_SmokeGrenade_C
// Inherited Bytes: 0x3b0 | Struct Size: 0x3d8
struct ABP_Ability_SmokeGrenade_C : ASmokeGrenade {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x3b0 | Size: 0x8
	struct USphereComponent* Sphere; // Offset: 0x3b8 | Size: 0x8
	struct UAkComponent* AkAudioComponent; // Offset: 0x3c0 | Size: 0x8
	struct USolarGameplaySmokeComponent* Smoke; // Offset: 0x3c8 | Size: 0x8
	int32_t TranslucentSortPriority_1; // Offset: 0x3d0 | Size: 0x4
	float SmokeVFXLifeTime; // Offset: 0x3d4 | Size: 0x4

	// Functions

	// Object: Function BP_Ability_SmokeGrenade.BP_Ability_SmokeGrenade_C.ReceiveBeginPlay
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void ReceiveBeginPlay();

	// Object: Function BP_Ability_SmokeGrenade.BP_Ability_SmokeGrenade_C.ReceiveEndPlay
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x1) ]
	void ReceiveEndPlay(enum class EEndPlayReason EndPlayReason);

	// Object: Function BP_Ability_SmokeGrenade.BP_Ability_SmokeGrenade_C.ExecuteUbergraph_BP_Ability_SmokeGrenade
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_BP_Ability_SmokeGrenade(int32_t EntryPoint);
};

