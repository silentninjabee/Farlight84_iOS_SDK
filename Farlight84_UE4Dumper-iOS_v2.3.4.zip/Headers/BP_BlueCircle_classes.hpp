#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_BlueCircle.BP_BlueCircle_C
// Inherited Bytes: 0x268 | Struct Size: 0x288
struct ABP_BlueCircle_C : ASolarBlueCircle {
	// Fields
	struct UStaticMeshComponent* FX_Tag_Glow; // Offset: 0x268 | Size: 0x8
	struct UStaticMeshComponent* FX_Tag_Center; // Offset: 0x270 | Size: 0x8
	struct USceneComponent* Scene; // Offset: 0x278 | Size: 0x8
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x280 | Size: 0x8

	// Functions

	// Object: Function BP_BlueCircle.BP_BlueCircle_C.GetGlowStaticMeshComponent
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UStaticMeshComponent* GetGlowStaticMeshComponent();

	// Object: Function BP_BlueCircle.BP_BlueCircle_C.GetCenterStaticMeshComponent
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UStaticMeshComponent* GetCenterStaticMeshComponent();

	// Object: Function BP_BlueCircle.BP_BlueCircle_C.GetModuleName
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();
};

