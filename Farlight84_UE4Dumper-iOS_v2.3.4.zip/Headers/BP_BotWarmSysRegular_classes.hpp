#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_BotWarmSysRegular.BP_BotWarmSysRegular_C
// Inherited Bytes: 0x2a8 | Struct Size: 0x2a8
struct UBP_BotWarmSysRegular_C : USolarBotWarmSystemRegular {
	// Functions

	// Object: Function BP_BotWarmSysRegular.BP_BotWarmSysRegular_C.GetActivePlayerNumBP
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(3) Size(0xc) ]
	int32_t GetActivePlayerNumBP(int32_t PlayerNum, int32_t PlayerTeamNum);

	// Object: Function BP_BotWarmSysRegular.BP_BotWarmSysRegular_C.GetWarmScoreByEvent
	// Flags: [Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(3) Size(0x10) ]
	float GetWarmScoreByEvent(struct ASolarPlayerState* InPS, enum class EUpdateWarmServiceEventType InEventType);

	// Object: Function BP_BotWarmSysRegular.BP_BotWarmSysRegular_C.GetTargetTickValue
	// Flags: [Event|Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(3) Size(0x34) ]
	float GetTargetTickValue(struct ASolarPlayerState* InPS, struct FWarmTargetState& InState);
};

