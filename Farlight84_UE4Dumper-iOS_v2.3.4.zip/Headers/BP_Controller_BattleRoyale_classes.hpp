#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_Controller_BattleRoyale.BP_Controller_BattleRoyale_C
// Inherited Bytes: 0x111c | Struct Size: 0x111c
struct ABP_Controller_BattleRoyale_C : ABP_Controller_Framework_C {
};

