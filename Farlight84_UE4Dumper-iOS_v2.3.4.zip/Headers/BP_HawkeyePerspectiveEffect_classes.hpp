#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_HawkeyePerspectiveEffect.BP_HawkeyePerspectiveEffect_C
// Inherited Bytes: 0x1d8 | Struct Size: 0x1d8
struct UBP_HawkeyePerspectiveEffect_C : UMultiplePassMaterialVariableEffect {
};

