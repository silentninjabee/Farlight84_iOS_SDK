#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_HeroPickManager.BP_HeroPickManager_C
// Inherited Bytes: 0x310 | Struct Size: 0x338
struct ABP_HeroPickManager_C : AHeroPickManager {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x310 | Size: 0x8
	struct FMulticastInlineDelegate OnAllHeroPickEnd_1; // Offset: 0x318 | Size: 0x10
	struct FMulticastInlineDelegate OnSideHeroPickEnd; // Offset: 0x328 | Size: 0x10

	// Functions

	// Object: Function BP_HeroPickManager.BP_HeroPickManager_C.ReceiveAllHeroPickEnd
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void ReceiveAllHeroPickEnd();

	// Object: Function BP_HeroPickManager.BP_HeroPickManager_C.ReceiveTeamPickHeroEnd
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x10) ]
	void ReceiveTeamPickHeroEnd(struct FString TeamName);

	// Object: Function BP_HeroPickManager.BP_HeroPickManager_C.ExecuteUbergraph_BP_HeroPickManager
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_BP_HeroPickManager(int32_t EntryPoint);

	// Object: Function BP_HeroPickManager.BP_HeroPickManager_C.OnSideHeroPickEnd__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x10) ]
	void OnSideHeroPickEnd__DelegateSignature(struct FString Side);

	// Object: Function BP_HeroPickManager.BP_HeroPickManager_C.OnAllHeroPickEnd_0__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnAllHeroPickEnd_0__DelegateSignature();
};

