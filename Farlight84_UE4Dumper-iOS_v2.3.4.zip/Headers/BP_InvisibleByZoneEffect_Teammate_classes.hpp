#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_InvisibleByZoneEffect_Teammate.BP_InvisibleByZoneEffect_Teammate_C
// Inherited Bytes: 0x240 | Struct Size: 0x240
struct UBP_InvisibleByZoneEffect_Teammate_C : UMaterialVariableEffect {
};

