#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_LobbyGameState.BP_LobbyGameState_C
// Inherited Bytes: 0x330 | Struct Size: 0x338
struct ABP_LobbyGameState_C : ASolarGameStateBase {
	// Fields
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x330 | Size: 0x8
};

