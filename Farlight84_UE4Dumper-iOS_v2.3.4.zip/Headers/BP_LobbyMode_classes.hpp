#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_LobbyMode.BP_LobbyMode_C
// Inherited Bytes: 0x2d8 | Struct Size: 0x2e0
struct ABP_LobbyMode_C : AGameModeBase {
	// Fields
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x2d8 | Size: 0x8
};

