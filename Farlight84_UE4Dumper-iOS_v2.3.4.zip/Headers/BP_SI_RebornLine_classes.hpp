#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_SI_RebornLine.BP_SI_RebornLine_C
// Inherited Bytes: 0x238 | Struct Size: 0x258
struct ABP_SI_RebornLine_C : AActor {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x238 | Size: 0x8
	struct UStaticMeshComponent* FX_Tag; // Offset: 0x240 | Size: 0x8
	struct UStaticMeshComponent* FX_Tag_Glow; // Offset: 0x248 | Size: 0x8
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x250 | Size: 0x8

	// Functions

	// Object: Function BP_SI_RebornLine.BP_SI_RebornLine_C.ReceiveBeginPlay
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void ReceiveBeginPlay();

	// Object: Function BP_SI_RebornLine.BP_SI_RebornLine_C.Event_SetWaitingColor
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void Event_SetWaitingColor();

	// Object: Function BP_SI_RebornLine.BP_SI_RebornLine_C.Event_SetFinishColor
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void Event_SetFinishColor();

	// Object: Function BP_SI_RebornLine.BP_SI_RebornLine_C.ExecuteUbergraph_BP_SI_RebornLine
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_BP_SI_RebornLine(int32_t EntryPoint);
};

