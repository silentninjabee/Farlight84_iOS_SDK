#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_SI_Tacticalbox.BP_SI_Tacticalbox_C
// Inherited Bytes: 0x760 | Struct Size: 0x770
struct ABP_SI_Tacticalbox_C : ATacticalTreasureBox {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x760 | Size: 0x8
	struct UStaticMeshComponent* 3DIcon; // Offset: 0x768 | Size: 0x8

	// Functions

	// Object: Function BP_SI_Tacticalbox.BP_SI_Tacticalbox_C.PlayOpenAnimation
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void PlayOpenAnimation();

	// Object: Function BP_SI_Tacticalbox.BP_SI_Tacticalbox_C.Refresh3DUIVisible
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x1) ]
	void Refresh3DUIVisible(bool bVisible);

	// Object: Function BP_SI_Tacticalbox.BP_SI_Tacticalbox_C.ExecuteUbergraph_BP_SI_Tacticalbox
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_BP_SI_Tacticalbox(int32_t EntryPoint);
};

