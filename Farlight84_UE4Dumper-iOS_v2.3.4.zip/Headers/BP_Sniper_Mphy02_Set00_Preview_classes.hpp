#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_Sniper_Mphy02_Set00_Preview.BP_Sniper_Mphy02_Set00_Preview_C
// Inherited Bytes: 0x6c8 | Struct Size: 0x6c8
struct ABP_Sniper_Mphy02_Set00_Preview_C : ABP_Weaponry_Base_Preview_C {
};

