#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_TabItemObj.BP_TabItemObj_C
// Inherited Bytes: 0x28 | Struct Size: 0xb9
struct UBP_TabItemObj_C : UObject {
	// Fields
	struct FString QueryKey; // Offset: 0x28 | Size: 0x10
	enum class E_TabStyle Style; // Offset: 0x38 | Size: 0x1
	bool Selected; // Offset: 0x39 | Size: 0x1
	char pad_0x3A[0x6]; // Offset: 0x3a | Size: 0x6
	struct FMulticastInlineDelegate OnDataRevised; // Offset: 0x40 | Size: 0x10
	struct FS_TabItem TabData; // Offset: 0x50 | Size: 0x58
	struct FMulticastInlineDelegate OnHovered; // Offset: 0xa8 | Size: 0x10
	bool Hovered; // Offset: 0xb8 | Size: 0x1

	// Functions

	// Object: Function BP_TabItemObj.BP_TabItemObj_C.OnHovered__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnHovered__DelegateSignature(bool IsHovered);

	// Object: Function BP_TabItemObj.BP_TabItemObj_C.OnDataRevised__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnDataRevised__DelegateSignature();
};

