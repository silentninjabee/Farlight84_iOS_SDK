#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BTT_SetFollowDistance.BTT_SetFollowDistance_C
// Inherited Bytes: 0xa8 | Struct Size: 0x110
struct UBTT_SetFollowDistance_C : UBTTask_BlueprintBase {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0xa8 | Size: 0x8
	struct FBlackboardKeySelector Distance; // Offset: 0xb0 | Size: 0x28
	struct ASolarCharacter* SelfActor; // Offset: 0xd8 | Size: 0x8
	struct TArray<int32_t> Close; // Offset: 0xe0 | Size: 0x10
	struct TArray<int32_t> Middle; // Offset: 0xf0 | Size: 0x10
	struct TArray<int32_t> Far; // Offset: 0x100 | Size: 0x10

	// Functions

	// Object: Function BTT_SetFollowDistance.BTT_SetFollowDistance_C.ReceiveExecuteAI
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(2) Size(0x10) ]
	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn);

	// Object: Function BTT_SetFollowDistance.BTT_SetFollowDistance_C.ExecuteUbergraph_BTT_SetFollowDistance
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_BTT_SetFollowDistance(int32_t EntryPoint);
};

