#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass B_DuckRollingMeshComponent.B_DuckRollingMeshComponent_C
// Inherited Bytes: 0xdb0 | Struct Size: 0xdd4
struct UB_DuckRollingMeshComponent_C : UDuckRollingMeshComponent {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0xdb0 | Size: 0x8
	struct TArray<struct UAnimMontage*> JumpPoseMontages; // Offset: 0xdb8 | Size: 0x10
	struct FRotator BoneRotation; // Offset: 0xdc8 | Size: 0xc

	// Functions

	// Object: Function B_DuckRollingMeshComponent.B_DuckRollingMeshComponent_C.UpdateWorldRotation
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0xc) ]
	void UpdateWorldRotation(struct FRotator& WorldRotation);

	// Object: Function B_DuckRollingMeshComponent.B_DuckRollingMeshComponent_C.ExecuteUbergraph_B_DuckRollingMeshComponent
	// Flags: [Final|UbergraphFunction|HasDefaults]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_B_DuckRollingMeshComponent(int32_t EntryPoint);
};

