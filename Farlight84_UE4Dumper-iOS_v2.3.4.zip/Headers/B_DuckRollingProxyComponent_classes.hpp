#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass B_DuckRollingProxyComponent.B_DuckRollingProxyComponent_C
// Inherited Bytes: 0x250 | Struct Size: 0x250
struct UB_DuckRollingProxyComponent_C : UDuckRollingProxyComponent {
};

