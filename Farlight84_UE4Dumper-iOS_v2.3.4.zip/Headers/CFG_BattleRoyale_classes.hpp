#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass CFG_BattleRoyale.CFG_BattleRoyale_C
// Inherited Bytes: 0x6b8 | Struct Size: 0x8e8
struct UCFG_BattleRoyale_C : UCFG_Framework_C {
	// Fields
	int32_t ; // Offset: 0x6b8 | Size: 0x4
	int32_t ; // Offset: 0x6bc | Size: 0x4
	int32_t ; // Offset: 0x6c0 | Size: 0x4
	char pad_0x6C4[0x4]; // Offset: 0x6c4 | Size: 0x4
	struct TSoftObjectPtr<UBehaviorTree> ; // Offset: 0x6c8 | Size: 0x28
	struct TSoftObjectPtr<UBehaviorTree> ; // Offset: 0x6f0 | Size: 0x28
	struct TSoftObjectPtr<UBehaviorTree> ; // Offset: 0x718 | Size: 0x28
	int32_t ; // Offset: 0x740 | Size: 0x4
	char pad_0x744[0x4]; // Offset: 0x744 | Size: 0x4
	struct UDataTable* ; // Offset: 0x748 | Size: 0x8
	int32_t ; // Offset: 0x750 | Size: 0x4
	char pad_0x754[0x4]; // Offset: 0x754 | Size: 0x4
	struct TSoftClassPtr<UObject> AIController; // Offset: 0x758 | Size: 0x28
	bool ; // Offset: 0x780 | Size: 0x1
	char pad_0x781[0x3]; // Offset: 0x781 | Size: 0x3
	float ; // Offset: 0x784 | Size: 0x4
	float ; // Offset: 0x788 | Size: 0x4
	int32_t ; // Offset: 0x78c | Size: 0x4
	int32_t ; // Offset: 0x790 | Size: 0x4
	int32_t ; // Offset: 0x794 | Size: 0x4
	int32_t ; // Offset: 0x798 | Size: 0x4
	char pad_0x79C[0x4]; // Offset: 0x79c | Size: 0x4
	struct UDataTable* ; // Offset: 0x7a0 | Size: 0x8
	int32_t ; // Offset: 0x7a8 | Size: 0x4
	struct FInt32Range ; // Offset: 0x7ac | Size: 0x10
	struct FInt32Range ; // Offset: 0x7bc | Size: 0x10
	float ; // Offset: 0x7cc | Size: 0x4
	struct FS_SkillState ; // Offset: 0x7d0 | Size: 0x4
	struct FS_SkillState ; // Offset: 0x7d4 | Size: 0x4
	struct TMap<int32_t, int32_t> ; // Offset: 0x7d8 | Size: 0x50
	struct TMap<int32_t, int32_t> ; // Offset: 0x828 | Size: 0x50
	struct FS_SkillState ; // Offset: 0x878 | Size: 0x4
	struct FS_SkillState ; // Offset: 0x87c | Size: 0x4
	bool ; // Offset: 0x880 | Size: 0x1
	struct FS_SkillState ; // Offset: 0x881 | Size: 0x4
	char pad_0x885[0x3]; // Offset: 0x885 | Size: 0x3
	int32_t TopVictoryTeamRank; // Offset: 0x888 | Size: 0x4
	int32_t MaxBattleCountDown; // Offset: 0x88c | Size: 0x4
	bool ; // Offset: 0x890 | Size: 0x1
	bool ; // Offset: 0x891 | Size: 0x1
	char pad_0x892[0x6]; // Offset: 0x892 | Size: 0x6
	struct TMap<int32_t, struct FString> ; // Offset: 0x898 | Size: 0x50

	// Functions

	// Object: Function CFG_BattleRoyale.CFG_BattleRoyale_C.GetSkillStateByNameEnum
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(2) Size(0x5) ]
	void GetSkillStateByNameEnum(enum class ESkillStateNameEnum Enum, struct FS_SkillState& Out);
};

