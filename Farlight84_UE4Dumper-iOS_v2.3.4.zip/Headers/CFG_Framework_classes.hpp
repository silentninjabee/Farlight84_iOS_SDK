#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass CFG_Framework.CFG_Framework_C
// Inherited Bytes: 0x6b0 | Struct Size: 0x6b8
struct UCFG_Framework_C : UCGMGameplayConfig {
	// Fields
	struct UBP_ConfigSave_C* ModeConfig; // Offset: 0x6b0 | Size: 0x8

	// Functions

	// Object: Function CFG_Framework.CFG_Framework_C.GetSkillStateByNameEnum
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(2) Size(0x5) ]
	void GetSkillStateByNameEnum(enum class ESkillStateNameEnum Enum, struct FS_SkillState& Out);

	// Object: Function CFG_Framework.CFG_Framework_C.GetCustomRoomData
	// Flags: [Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0xe8) ]
	struct FCustomRoomData GetCustomRoomData();

	// Object: Function CFG_Framework.CFG_Framework_C.IsCustomRoomMode
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsCustomRoomMode();

	// Object: Function CFG_Framework.CFG_Framework_C.GetSavedConfig
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(2) Size(0x9) ]
	void GetSavedConfig(struct UBP_ConfigSave_C*& AsBP Config Save, bool& bSuccess);
};

