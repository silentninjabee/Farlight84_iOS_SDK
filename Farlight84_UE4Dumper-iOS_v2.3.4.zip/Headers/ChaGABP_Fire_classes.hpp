#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGABP_Fire.ChaGABP_Fire_C
// Inherited Bytes: 0x4d0 | Struct Size: 0x4d0
struct UChaGABP_Fire_C : UChaGA_Fire {
};

