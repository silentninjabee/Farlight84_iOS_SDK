#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGABP_Invincible.ChaGABP_Invincible_C
// Inherited Bytes: 0x4c0 | Struct Size: 0x4c0
struct UChaGABP_Invincible_C : UChaGA_Invincible {
};

