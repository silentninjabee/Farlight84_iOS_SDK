#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGABP_LaunchAirJetFly.ChaGABP_LaunchAirJetFly_C
// Inherited Bytes: 0x4d8 | Struct Size: 0x4d8
struct UChaGABP_LaunchAirJetFly_C : UChaGA_LaunchAirJetFly {
};

