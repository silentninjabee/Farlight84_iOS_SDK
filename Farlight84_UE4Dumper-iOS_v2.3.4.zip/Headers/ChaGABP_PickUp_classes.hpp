#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGABP_PickUp.ChaGABP_PickUp_C
// Inherited Bytes: 0x510 | Struct Size: 0x510
struct UChaGABP_PickUp_C : UChaGA_PickUp {
};

