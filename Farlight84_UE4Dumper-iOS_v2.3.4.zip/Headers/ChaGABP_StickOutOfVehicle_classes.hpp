#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGABP_StickOutOfVehicle.ChaGABP_StickOutOfVehicle_C
// Inherited Bytes: 0x4f0 | Struct Size: 0x4f0
struct UChaGABP_StickOutOfVehicle_C : UChaGA_StickOutOfVehicle {
};

