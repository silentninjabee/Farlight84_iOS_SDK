#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGABP_UpgradeShield.ChaGABP_UpgradeShield_C
// Inherited Bytes: 0x4e8 | Struct Size: 0x4e8
struct UChaGABP_UpgradeShield_C : UChaGA_UpgradeShield {
};

