#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGA_ActivateExpSpring.ChaGA_ActivateExpSpring_C
// Inherited Bytes: 0x4f8 | Struct Size: 0x4f8
struct UChaGA_ActivateExpSpring_C : USolarExpSpringActivePointAbility {
};

