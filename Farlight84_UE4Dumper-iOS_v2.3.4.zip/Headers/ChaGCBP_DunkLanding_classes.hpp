#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGCBP_DunkLanding.ChaGCBP_DunkLanding_C
// Inherited Bytes: 0x50 | Struct Size: 0x68
struct UChaGCBP_DunkLanding_C : UGameplayCueNotify_Static {
	// Fields
	struct FRotator RotOffset; // Offset: 0x50 | Size: 0xc
	char pad_0x5C[0x4]; // Offset: 0x5c | Size: 0x4
	struct UParticleSystem* ParticleEffect; // Offset: 0x60 | Size: 0x8

	// Functions

	// Object: Function ChaGCBP_DunkLanding.ChaGCBP_DunkLanding_C.OnActive
	// Flags: [Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(3) Size(0xd9) ]
	bool OnActive(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters);
};

