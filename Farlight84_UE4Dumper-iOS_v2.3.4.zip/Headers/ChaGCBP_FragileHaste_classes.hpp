#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGCBP_FragileHaste.ChaGCBP_FragileHaste_C
// Inherited Bytes: 0x390 | Struct Size: 0x398
struct AChaGCBP_FragileHaste_C : AChaGC_CharacterActorCueBase {
	// Fields
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x390 | Size: 0x8
};

