#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGCBP_MassInvisibilityRange.ChaGCBP_MassInvisibilityRange_C
// Inherited Bytes: 0x50 | Struct Size: 0x50
struct UChaGCBP_MassInvisibilityRange_C : UGameplayCueNotify_Static {
	// Functions

	// Object: Function ChaGCBP_MassInvisibilityRange.ChaGCBP_MassInvisibilityRange_C.OnExecute
	// Flags: [Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(3) Size(0xd9) ]
	bool OnExecute(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters);
};

