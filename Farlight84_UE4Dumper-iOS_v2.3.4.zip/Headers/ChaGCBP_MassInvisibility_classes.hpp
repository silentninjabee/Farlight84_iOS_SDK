#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGCBP_MassInvisibility.ChaGCBP_MassInvisibility_C
// Inherited Bytes: 0x5f0 | Struct Size: 0x5f8
struct AChaGCBP_MassInvisibility_C : AChaGC_MassInvisibility {
	// Fields
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x5f0 | Size: 0x8
};

