#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGCBP_RapidBoost.ChaGCBP_RapidBoost_C
// Inherited Bytes: 0x2c8 | Struct Size: 0x2f8
struct AChaGCBP_RapidBoost_C : ASolarSkillGC_RapidBoost {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x2c8 | Size: 0x8
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x2d0 | Size: 0x8
	struct FTimerHandle PlayEndSoundHandle; // Offset: 0x2d8 | Size: 0x8
	int32_t CachedScreenEffectHandle; // Offset: 0x2e0 | Size: 0x4
	char pad_0x2E4[0x4]; // Offset: 0x2e4 | Size: 0x4
	struct ASolarCharacter* CharacterOwner; // Offset: 0x2e8 | Size: 0x8
	int64_t OnActiveFrameCount; // Offset: 0x2f0 | Size: 0x8

	// Functions

	// Object: Function ChaGCBP_RapidBoost.ChaGCBP_RapidBoost_C.WhileActive_Impl
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void WhileActive_Impl();

	// Object: Function ChaGCBP_RapidBoost.ChaGCBP_RapidBoost_C.OnActive_Impl
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnActive_Impl();

	// Object: Function ChaGCBP_RapidBoost.ChaGCBP_RapidBoost_C.OnPlayEndSound
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnPlayEndSound();

	// Object: Function ChaGCBP_RapidBoost.ChaGCBP_RapidBoost_C.SpawnEmitter
	// Flags: [Private|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(6) Size(0x28) ]
	struct UParticleSystemComponent* SpawnEmitter(struct UParticleSystem* EmitterTemplate, struct USceneComponent* Mesh, struct FName BoneName, enum class EPSCPoolMethod PoolingMethod, bool bAbsoluteRotation);

	// Object: Function ChaGCBP_RapidBoost.ChaGCBP_RapidBoost_C.OnRemove
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(3) Size(0xd9) ]
	bool OnRemove(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters);

	// Object: Function ChaGCBP_RapidBoost.ChaGCBP_RapidBoost_C.K2_HandleGameplayCue
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(3) Size(0xe0) ]
	void K2_HandleGameplayCue(struct AActor* MyTarget, enum class EGameplayCueEvent EventType, struct FGameplayCueParameters& Parameters);

	// Object: Function ChaGCBP_RapidBoost.ChaGCBP_RapidBoost_C.ExecuteUbergraph_ChaGCBP_RapidBoost
	// Flags: [Final|UbergraphFunction|HasDefaults]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_ChaGCBP_RapidBoost(int32_t EntryPoint);
};

