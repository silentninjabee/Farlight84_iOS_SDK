#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGCBP_SectorScanning.ChaGCBP_SectorScanning_C
// Inherited Bytes: 0x398 | Struct Size: 0x3a0
struct AChaGCBP_SectorScanning_C : AChaGC_SuperSkillActorCueBase {
	// Fields
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x398 | Size: 0x8
};

