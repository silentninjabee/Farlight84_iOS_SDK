#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGCBP_SlideTackle.ChaGCBP_SlideTackle_C
// Inherited Bytes: 0x390 | Struct Size: 0x3b0
struct AChaGCBP_SlideTackle_C : AChaGC_CharacterActorCueBase {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x390 | Size: 0x8
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x398 | Size: 0x8
	bool IsPlayingSound; // Offset: 0x3a0 | Size: 0x1
	char pad_0x3A1[0x7]; // Offset: 0x3a1 | Size: 0x7
	struct ASolarCharacter* OwnerCharacter; // Offset: 0x3a8 | Size: 0x8

	// Functions

	// Object: Function ChaGCBP_SlideTackle.ChaGCBP_SlideTackle_C.OnRemoveInternal
	// Flags: [Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(3) Size(0xd9) ]
	bool OnRemoveInternal(struct ASolarCharacter* NullableCharacter, struct FGameplayCueParameters& Parameters);

	// Object: Function ChaGCBP_SlideTackle.ChaGCBP_SlideTackle_C.ShouldPlaySound
	// Flags: [Protected|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x1) ]
	void ShouldPlaySound(bool& Result);

	// Object: Function ChaGCBP_SlideTackle.ChaGCBP_SlideTackle_C.UpdateSound
	// Flags: [Protected|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x1) ]
	void UpdateSound(bool ForceStop);

	// Object: Function ChaGCBP_SlideTackle.ChaGCBP_SlideTackle_C.WhileActiveInternal
	// Flags: [Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(3) Size(0xd9) ]
	bool WhileActiveInternal(struct ASolarCharacter* Character, struct FGameplayCueParameters& Parameters);

	// Object: Function ChaGCBP_SlideTackle.ChaGCBP_SlideTackle_C.ReceiveTick
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x4) ]
	void ReceiveTick(float DeltaSeconds);

	// Object: Function ChaGCBP_SlideTackle.ChaGCBP_SlideTackle_C.ExecuteUbergraph_ChaGCBP_SlideTackle
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_ChaGCBP_SlideTackle(int32_t EntryPoint);
};

