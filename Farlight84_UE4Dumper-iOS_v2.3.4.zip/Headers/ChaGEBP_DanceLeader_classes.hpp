#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGEBP_DanceLeader.ChaGEBP_DanceLeader_C
// Inherited Bytes: 0x878 | Struct Size: 0x878
struct UChaGEBP_DanceLeader_C : UGameplayEffect {
};

