#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGEBP_Invincible.ChaGEBP_Invincible_C
// Inherited Bytes: 0x878 | Struct Size: 0x878
struct UChaGEBP_Invincible_C : UGameplayEffect {
};

