#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct ChaosSolverEngine.ChaosPhysicsCollisionInfo
// Inherited Bytes: 0x0 | Struct Size: 0x70
struct FChaosPhysicsCollisionInfo {
	// Fields
	struct UPrimitiveComponent* Component; // Offset: 0x0 | Size: 0x8
	struct UPrimitiveComponent* OtherComponent; // Offset: 0x8 | Size: 0x8
	struct FVector Location; // Offset: 0x10 | Size: 0xc
	struct FVector Normal; // Offset: 0x1c | Size: 0xc
	struct FVector AccumulatedImpulse; // Offset: 0x28 | Size: 0xc
	struct FVector Velocity; // Offset: 0x34 | Size: 0xc
	struct FVector OtherVelocity; // Offset: 0x40 | Size: 0xc
	struct FVector AngularVelocity; // Offset: 0x4c | Size: 0xc
	struct FVector OtherAngularVelocity; // Offset: 0x58 | Size: 0xc
	float Mass; // Offset: 0x64 | Size: 0x4
	float OtherMass; // Offset: 0x68 | Size: 0x4
	char pad_0x6C[0x4]; // Offset: 0x6c | Size: 0x4
};

// Object: ScriptStruct ChaosSolverEngine.ChaosBreakEvent
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FChaosBreakEvent {
	// Fields
	struct UPrimitiveComponent* Component; // Offset: 0x0 | Size: 0x8
	struct FVector Location; // Offset: 0x8 | Size: 0xc
	struct FVector Velocity; // Offset: 0x14 | Size: 0xc
	struct FVector AngularVelocity; // Offset: 0x20 | Size: 0xc
	float Mass; // Offset: 0x2c | Size: 0x4
};

// Object: ScriptStruct ChaosSolverEngine.ChaosHandlerSet
// Inherited Bytes: 0x0 | Struct Size: 0x58
struct FChaosHandlerSet {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
	struct TSet<struct UObject*> ChaosHandlers; // Offset: 0x8 | Size: 0x50
};

// Object: ScriptStruct ChaosSolverEngine.BreakEventCallbackWrapper
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FBreakEventCallbackWrapper {
	// Fields
	char pad_0x0[0x40]; // Offset: 0x0 | Size: 0x40
};

// Object: ScriptStruct ChaosSolverEngine.ChaosDebugSubstepControl
// Inherited Bytes: 0x0 | Struct Size: 0x3
struct FChaosDebugSubstepControl {
	// Fields
	bool bPause; // Offset: 0x0 | Size: 0x1
	bool bSubstep; // Offset: 0x1 | Size: 0x1
	bool bStep; // Offset: 0x2 | Size: 0x1
};

