#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass Crosshair_CarWeapon_Float.Crosshair_CarWeapon_Float_C
// Inherited Bytes: 0x748 | Struct Size: 0x80e
struct UCrosshair_CarWeapon_Float_C : UVehicleWeaponCrossHairWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x748 | Size: 0x8
	struct UWidgetAnimation* Normal_Anim; // Offset: 0x750 | Size: 0x8
	struct UWidgetAnimation* Aim_Anim; // Offset: 0x758 | Size: 0x8
	struct UWidgetAnimation* Overheat_Anim_Quit; // Offset: 0x760 | Size: 0x8
	struct UWidgetAnimation* Fullcharge_Anim; // Offset: 0x768 | Size: 0x8
	struct UWidgetAnimation* Overheat_Anim_Enter; // Offset: 0x770 | Size: 0x8
	struct UCanvasPanel* Container_SecondReticle; // Offset: 0x778 | Size: 0x8
	struct UCanvasPanel* Coredot; // Offset: 0x780 | Size: 0x8
	struct UImage* img_charge; // Offset: 0x788 | Size: 0x8
	struct UImage* Img_Circle; // Offset: 0x790 | Size: 0x8
	struct UImage* Img_Circle_2; // Offset: 0x798 | Size: 0x8
	struct UImage* Img_Glow; // Offset: 0x7a0 | Size: 0x8
	struct UImage* img_overload_cordot; // Offset: 0x7a8 | Size: 0x8
	struct UCanvasPanel* Panel_Aim; // Offset: 0x7b0 | Size: 0x8
	struct UCanvasPanel* panel_enlarge; // Offset: 0x7b8 | Size: 0x8
	struct UImage* ReticleDirection; // Offset: 0x7c0 | Size: 0x8
	struct UImage* SpreadImg_coredot; // Offset: 0x7c8 | Size: 0x8
	struct UImage* SpreadImg_coredot_3; // Offset: 0x7d0 | Size: 0x8
	struct UImage* SpreadImg_coredot_5; // Offset: 0x7d8 | Size: 0x8
	struct UWidgetSwitcher* wgs_enlarge; // Offset: 0x7e0 | Size: 0x8
	struct UWidgetSwitcher* wgs_overload; // Offset: 0x7e8 | Size: 0x8
	float ChargeProgress; // Offset: 0x7f0 | Size: 0x4
	bool IsChargingLast; // Offset: 0x7f4 | Size: 0x1
	char pad_0x7F5[0x3]; // Offset: 0x7f5 | Size: 0x3
	struct FVector2D OriChargeSize; // Offset: 0x7f8 | Size: 0x8
	bool IsCharging; // Offset: 0x800 | Size: 0x1
	char pad_0x801[0x3]; // Offset: 0x801 | Size: 0x3
	struct FVector2D TempSize; // Offset: 0x804 | Size: 0x8
	bool IsOverloading; // Offset: 0x80c | Size: 0x1
	bool bLockedEnemy; // Offset: 0x80d | Size: 0x1

	// Functions

	// Object: Function Crosshair_CarWeapon_Float.Crosshair_CarWeapon_Float_C.OnOverloadChanged
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnOverloadChanged(bool InOverload);

	// Object: Function Crosshair_CarWeapon_Float.Crosshair_CarWeapon_Float_C.Set Charge Panel Size
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void Set Charge Panel Size();

	// Object: Function Crosshair_CarWeapon_Float.Crosshair_CarWeapon_Float_C.SetChargeProgress
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void SetChargeProgress();

	// Object: Function Crosshair_CarWeapon_Float.Crosshair_CarWeapon_Float_C.SetWidgetResources
	// Flags: [Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(7) Size(0x38) ]
	void SetWidgetResources(struct UCanvasPanel*& InSecondReticlePanel, struct UImage*& InReticleDirectionImage, struct UImage*& InRangedImage, struct USizeBox*& InAssistLockSizeBox, struct UCanvasPanel*& InChangeNewAssistLockPawnPanel, struct UCanvasPanel*& InEnterLockPawnPanel, struct UCanvasPanel*& InCanvas_Dynamic);

	// Object: Function Crosshair_CarWeapon_Float.Crosshair_CarWeapon_Float_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void Construct();

	// Object: Function Crosshair_CarWeapon_Float.Crosshair_CarWeapon_Float_C.OnUpdateChargeProgress
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(4) Size(0x10) ]
	void OnUpdateChargeProgress(bool InbCharging, int32_t InChargeMode, float InChargeProgress, int32_t InChargeBurstCount);

	// Object: Function Crosshair_CarWeapon_Float.Crosshair_CarWeapon_Float_C.OnOverloadStateChanged
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnOverloadStateChanged(bool bEnter);

	// Object: Function Crosshair_CarWeapon_Float.Crosshair_CarWeapon_Float_C.OnCrosshairInNormalState
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnCrosshairInNormalState();

	// Object: Function Crosshair_CarWeapon_Float.Crosshair_CarWeapon_Float_C.OnAnimationFinished
	// Flags: [BlueprintCosmetic|Event|Protected|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x8) ]
	void OnAnimationFinished(struct UWidgetAnimation* Animation);

	// Object: Function Crosshair_CarWeapon_Float.Crosshair_CarWeapon_Float_C.OnUpdateAimState
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnUpdateAimState(bool InbLockEnemy);

	// Object: Function Crosshair_CarWeapon_Float.Crosshair_CarWeapon_Float_C.ExecuteUbergraph_Crosshair_CarWeapon_Float
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_Crosshair_CarWeapon_Float(int32_t EntryPoint);
};

