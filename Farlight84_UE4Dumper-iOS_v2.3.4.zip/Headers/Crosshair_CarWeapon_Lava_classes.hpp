#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass Crosshair_CarWeapon_Lava.Crosshair_CarWeapon_Lava_C
// Inherited Bytes: 0x748 | Struct Size: 0x750
struct UCrosshair_CarWeapon_Lava_C : UVehicleWeaponCrossHairWidget {
	// Fields
	struct UImage* SpreadImg_coredot; // Offset: 0x748 | Size: 0x8

	// Functions

	// Object: Function Crosshair_CarWeapon_Lava.Crosshair_CarWeapon_Lava_C.SetWidgetResources
	// Flags: [Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(7) Size(0x38) ]
	void SetWidgetResources(struct UCanvasPanel*& InSecondReticlePanel, struct UImage*& InReticleDirectionImage, struct UImage*& InRangedImage, struct USizeBox*& InAssistLockSizeBox, struct UCanvasPanel*& InChangeNewAssistLockPawnPanel, struct UCanvasPanel*& InEnterLockPawnPanel, struct UCanvasPanel*& InCanvas_Dynamic);
};

