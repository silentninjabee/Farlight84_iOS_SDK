#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct DTBPJson.DTStruct
// Inherited Bytes: 0x0 | Struct Size: 0x1
struct FDTStruct {
	// Fields
	char pad_0x0[0x1]; // Offset: 0x0 | Size: 0x1
};

