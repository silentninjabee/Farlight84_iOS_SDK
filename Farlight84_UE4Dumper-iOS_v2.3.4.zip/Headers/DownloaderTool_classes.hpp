#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class DownloaderTool.DownloaderHttpTask
// Inherited Bytes: 0x28 | Struct Size: 0x2a0
struct UDownloaderHttpTask : UObject {
	// Fields
	struct FMulticastInlineDelegate OnTaskProgress; // Offset: 0x28 | Size: 0x10
	struct FMulticastInlineDelegate OnTaskSuccess; // Offset: 0x38 | Size: 0x10
	struct FMulticastInlineDelegate OnTaskFailed; // Offset: 0x48 | Size: 0x10
	struct TWeakObjectPtr<struct UDownloaderManager> Manager; // Offset: 0x58 | Size: 0x8
	char pad_0x60[0x1e0]; // Offset: 0x60 | Size: 0x1e0
	struct FDownloaderResponse DownloadResponse; // Offset: 0x240 | Size: 0x60

	// Functions

	// Object: Function DownloaderTool.DownloaderHttpTask.SetWriteFilePath
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10170e724
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetWriteFilePath(struct FString InWriteFilePath);

	// Object: Function DownloaderTool.DownloaderHttpTask.OnWriteFileComplete
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x10170e69c
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnWriteFileComplete(bool bWriteResult);

	// Object: Function DownloaderTool.DownloaderHttpTask.CreateAndProcessHttpRequest
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10170e7b0
	// Return & Params: [ Num(0) Size(0x0) ]
	void CreateAndProcessHttpRequest();
};

// Object: Class DownloaderTool.DownloaderMainTask
// Inherited Bytes: 0x28 | Struct Size: 0x198
struct UDownloaderMainTask : UObject {
	// Fields
	struct FMulticastInlineDelegate OnMainTaskProgress; // Offset: 0x28 | Size: 0x10
	struct FMulticastInlineDelegate OnMainTaskSuccess; // Offset: 0x38 | Size: 0x10
	struct FMulticastInlineDelegate OnMainTaskFailed; // Offset: 0x48 | Size: 0x10
	struct TWeakObjectPtr<struct UDownloaderManager> Manager; // Offset: 0x58 | Size: 0x8
	struct TArray<struct FDownloaderResponse> AllUrlTasksResponses; // Offset: 0x60 | Size: 0x10
	struct TArray<struct UDownloaderSubTask*> PausingSubTasks; // Offset: 0x70 | Size: 0x10
	struct TMap<struct FName, struct UDownloaderUrlTask*> AllUrlTasksMap; // Offset: 0x80 | Size: 0x50
	struct TMap<struct FString, struct FDownloaderProgressInfo> AllUrlTasksProgressInfoMap; // Offset: 0xd0 | Size: 0x50
	char pad_0x120[0x78]; // Offset: 0x120 | Size: 0x78

	// Functions

	// Object: Function DownloaderTool.DownloaderMainTask.SetTaskReadyLaunch
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10170f028
	// Return & Params: [ Num(0) Size(0x0) ]
	void SetTaskReadyLaunch();

	// Object: Function DownloaderTool.DownloaderMainTask.OnUrlTaskSuccess
	// Flags: [Final|Native|Protected|HasOutParms]
	// Offset: 0x10170ef54
	// Return & Params: [ Num(1) Size(0x60) ]
	void OnUrlTaskSuccess(struct FDownloaderResponse& InResponse);

	// Object: Function DownloaderTool.DownloaderMainTask.OnUrlTaskProgress
	// Flags: [Final|Native|Protected|HasOutParms]
	// Offset: 0x10170ee18
	// Return & Params: [ Num(1) Size(0x28) ]
	void OnUrlTaskProgress(struct FDownloaderProgressInfo& InProgressInfo);

	// Object: Function DownloaderTool.DownloaderMainTask.OnUrlTaskFailed
	// Flags: [Final|Native|Protected|HasOutParms]
	// Offset: 0x10170eeb8
	// Return & Params: [ Num(1) Size(0x18) ]
	void OnUrlTaskFailed(struct FDownloaderFailedInfo& InFailedInfo);
};

// Object: Class DownloaderTool.DownloaderManagerLuaImpl
// Inherited Bytes: 0x28 | Struct Size: 0x30
struct UDownloaderManagerLuaImpl : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8

	// Functions

	// Object: Function DownloaderTool.DownloaderManagerLuaImpl.UnInitDownloaderMgrLuaInternal
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x101456f90
	// Return & Params: [ Num(0) Size(0x0) ]
	void UnInitDownloaderMgrLuaInternal();

	// Object: Function DownloaderTool.DownloaderManagerLuaImpl.ReportCdnDownloadFailedInternal
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x101456f90
	// Return & Params: [ Num(5) Size(0x30) ]
	void ReportCdnDownloadFailedInternal(struct FString InNecessaryURL, enum class EDTFailedType& InFailedType, int32_t InErrorCode, struct FString InCdnUrl, int64_t InCostTime);

	// Object: Function DownloaderTool.DownloaderManagerLuaImpl.InitDownloaderMgrLuaInternal
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x101456f90
	// Return & Params: [ Num(1) Size(0x1) ]
	bool InitDownloaderMgrLuaInternal();
};

// Object: Class DownloaderTool.DownloaderManager
// Inherited Bytes: 0x30 | Struct Size: 0x1b0
struct UDownloaderManager : UGameInstanceSubsystem {
	// Fields
	char pad_0x30[0x10]; // Offset: 0x30 | Size: 0x10
	struct UDownloaderManagerLuaImpl* LuaImpl; // Offset: 0x40 | Size: 0x8
	bool bIsDownloaderEnabled; // Offset: 0x48 | Size: 0x1
	bool bSystemSupportFileCache; // Offset: 0x49 | Size: 0x1
	char pad_0x4A[0x2]; // Offset: 0x4a | Size: 0x2
	int32_t CacheExpiredSeconds; // Offset: 0x4c | Size: 0x4
	int32_t CacheClearMaxSpacePercent; // Offset: 0x50 | Size: 0x4
	float TimeOutSeconds; // Offset: 0x54 | Size: 0x4
	float UrlTaskCallbackTimeOutSeconds; // Offset: 0x58 | Size: 0x4
	int32_t SubTaskChunkSize; // Offset: 0x5c | Size: 0x4
	int32_t CurDownloadingSubTaskNum; // Offset: 0x60 | Size: 0x4
	int32_t MaxDownloadingSubTaskNum; // Offset: 0x64 | Size: 0x4
	struct TMap<struct FName, struct UDownloaderMainTask*> MainTasksMap; // Offset: 0x68 | Size: 0x50
	struct TMap<struct FString, struct UDownloaderHttpTask*> LightWeightHttpTasksMap; // Offset: 0xb8 | Size: 0x50
	struct TMap<struct FString, struct FString> UrlEncodedStrMap; // Offset: 0x108 | Size: 0x50
	struct TArray<struct UDownloaderSubTask*> SubTasksQueue; // Offset: 0x158 | Size: 0x10
	bool bInitLuaComplete; // Offset: 0x168 | Size: 0x1
	char pad_0x169[0x47]; // Offset: 0x169 | Size: 0x47

	// Functions

	// Object: Function DownloaderTool.DownloaderManager.TyrLaunchSubTasksQueue
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10170fe60
	// Return & Params: [ Num(0) Size(0x0) ]
	void TyrLaunchSubTasksQueue();

	// Object: Function DownloaderTool.DownloaderManager.StopMainTask
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10170fe74
	// Return & Params: [ Num(1) Size(0x8) ]
	void StopMainTask(struct FName& InMainTaskName);

	// Object: Function DownloaderTool.DownloaderManager.SetUrlTaskCallbackTimeOutSeconds
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101710ca4
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetUrlTaskCallbackTimeOutSeconds(float InTimeOutSeconds);

	// Object: Function DownloaderTool.DownloaderManager.SetTimeOutSeconds
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101710d58
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetTimeOutSeconds(float InTimeOutSeconds);

	// Object: Function DownloaderTool.DownloaderManager.SetSubTaskChunkSize
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101710a88
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetSubTaskChunkSize(int32_t InSubTaskChunkSize);

	// Object: Function DownloaderTool.DownloaderManager.SetMaxDownloadingSubTaskNum
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1017109d4
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetMaxDownloadingSubTaskNum(int32_t InMaxDownloadingSubTaskNum);

	// Object: Function DownloaderTool.DownloaderManager.SetManagerEnable
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101710e40
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetManagerEnable(bool bInEnable);

	// Object: Function DownloaderTool.DownloaderManager.SetCacheExpiredSeconds
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101710bf0
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetCacheExpiredSeconds(int32_t InCacheExpiredSeconds);

	// Object: Function DownloaderTool.DownloaderManager.SetCacheClearMaxSpacePercent
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101710b3c
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetCacheClearMaxSpacePercent(int32_t InCacheClearMaxSpacePercent);

	// Object: Function DownloaderTool.DownloaderManager.ResumeMainTask
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10170ff8c
	// Return & Params: [ Num(1) Size(0x8) ]
	void ResumeMainTask(struct FName& InMainTaskName);

	// Object: Function DownloaderTool.DownloaderManager.ReadyMainTaskFinish
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101710018
	// Return & Params: [ Num(1) Size(0x8) ]
	void ReadyMainTaskFinish(struct FName& InMainTaskName);

	// Object: Function DownloaderTool.DownloaderManager.PushBatchSubTasksToQueue
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10170fd74
	// Return & Params: [ Num(2) Size(0x11) ]
	void PushBatchSubTasksToQueue(struct TArray<struct UDownloaderSubTask*>& InSubTasks, bool bInCutQueue);

	// Object: Function DownloaderTool.DownloaderManager.PauseMainTask
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10170ff00
	// Return & Params: [ Num(1) Size(0x8) ]
	void PauseMainTask(struct FName& InMainTaskName);

	// Object: Function DownloaderTool.DownloaderManager.IsSystemSupportFileCache
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101710e0c
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsSystemSupportFileCache();

	// Object: Function DownloaderTool.DownloaderManager.IsManagerEnable
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101710ec8
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsManagerEnable();

	// Object: Function DownloaderTool.DownloaderManager.IsMainTaskExist
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101710754
	// Return & Params: [ Num(2) Size(0x9) ]
	bool IsMainTaskExist(struct FName& InMainTaskName);

	// Object: Function DownloaderTool.DownloaderManager.Init
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1017111d0
	// Return & Params: [ Num(0) Size(0x0) ]
	void Init();

	// Object: Function DownloaderTool.DownloaderManager.GetUrlTaskRecordFilePath
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1017101c0
	// Return & Params: [ Num(2) Size(0xc8) ]
	struct FString GetUrlTaskRecordFilePath(struct FDownloaderTaskInfo& InTaskInfo);

	// Object: Function DownloaderTool.DownloaderManager.GetUrlTaskCallbackTimeOutSeconds
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101710d24
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetUrlTaskCallbackTimeOutSeconds();

	// Object: Function DownloaderTool.DownloaderManager.GetUrlTaskCacheDirPath
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1017102dc
	// Return & Params: [ Num(2) Size(0xc8) ]
	struct FString GetUrlTaskCacheDirPath(struct FDownloaderTaskInfo& InTaskInfo);

	// Object: Function DownloaderTool.DownloaderManager.GetUrlsCachedSize
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1017103f8
	// Return & Params: [ Num(2) Size(0x14) ]
	int32_t GetUrlsCachedSize(struct TArray<struct FDownloaderTaskInfo>& InAllTaskInfos);

	// Object: Function DownloaderTool.DownloaderManager.GetUrlEncodedStr
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1017100a4
	// Return & Params: [ Num(2) Size(0xc8) ]
	struct FString GetUrlEncodedStr(struct FDownloaderTaskInfo& InTaskInfo);

	// Object: Function DownloaderTool.DownloaderManager.GetTimeOutSeconds
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101710dd8
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetTimeOutSeconds();

	// Object: Function DownloaderTool.DownloaderManager.GetSubTaskChunkSize
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101710b08
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetSubTaskChunkSize();

	// Object: Function DownloaderTool.DownloaderManager.GetMaxDownloadingSubTaskNum
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101710a54
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetMaxDownloadingSubTaskNum();

	// Object: Function DownloaderTool.DownloaderManager.GetMainTaskStatus
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1017104bc
	// Return & Params: [ Num(2) Size(0x9) ]
	enum class EDownloaderStatus GetMainTaskStatus(struct FName& InMainTaskName);

	// Object: Function DownloaderTool.DownloaderManager.GetMainTasksMap
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1017108b4
	// Return & Params: [ Num(1) Size(0x50) ]
	struct TMap<struct FName, struct UDownloaderMainTask*> GetMainTasksMap();

	// Object: Function DownloaderTool.DownloaderManager.GetMainTaskName
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1017107f0
	// Return & Params: [ Num(2) Size(0x18) ]
	struct FName GetMainTaskName(struct TArray<struct FDownloaderTaskInfo>& InAllTaskInfos);

	// Object: Function DownloaderTool.DownloaderManager.GetMainTaskByName
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1017105f4
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UDownloaderMainTask* GetMainTaskByName(struct FName& InMainTaskName);

	// Object: Function DownloaderTool.DownloaderManager.GetlightWeightHttpTaskByURL
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101710558
	// Return & Params: [ Num(2) Size(0x18) ]
	struct UDownloaderHttpTask* GetlightWeightHttpTaskByURL(struct FString InNecessaryURL);

	// Object: Function DownloaderTool.DownloaderManager.GetCacheExpiredSeconds
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101710c70
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetCacheExpiredSeconds();

	// Object: Function DownloaderTool.DownloaderManager.GetCacheClearMaxSpacePercent
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101710bbc
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetCacheClearMaxSpacePercent();

	// Object: Function DownloaderTool.DownloaderManager.Get
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1017111e4
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UDownloaderManager* Get(struct UObject* WorldContextObject);

	// Object: Function DownloaderTool.DownloaderManager.CurDownSubTasksNumSubOne
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10170fd60
	// Return & Params: [ Num(0) Size(0x0) ]
	void CurDownSubTasksNumSubOne();

	// Object: Function DownloaderTool.DownloaderManager.CreateLightWeightTask
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101711028
	// Return & Params: [ Num(2) Size(0xc0) ]
	struct UDownloaderHttpTask* CreateLightWeightTask(struct FDownloaderTaskInfo& InTaskInfo);

	// Object: Function DownloaderTool.DownloaderManager.CreateJsonReqTask
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101710efc
	// Return & Params: [ Num(3) Size(0xd0) ]
	struct UDownloaderHttpTask* CreateJsonReqTask(struct FString InNecessaryURL, struct FDownloaderReqJson& InReqJson);

	// Object: Function DownloaderTool.DownloaderManager.CreateBigFilesDownloadTask
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10171110c
	// Return & Params: [ Num(2) Size(0x18) ]
	struct UDownloaderMainTask* CreateBigFilesDownloadTask(struct TArray<struct FDownloaderTaskInfo>& InAllTaskInfos);

	// Object: Function DownloaderTool.DownloaderManager.ClearCompletedMainTask
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10170fd38
	// Return & Params: [ Num(0) Size(0x0) ]
	void ClearCompletedMainTask();

	// Object: Function DownloaderTool.DownloaderManager.ClearCompletedLightWeightHttpTask
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10170fd24
	// Return & Params: [ Num(0) Size(0x0) ]
	void ClearCompletedLightWeightHttpTask();

	// Object: Function DownloaderTool.DownloaderManager.ClearCache
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10170fd4c
	// Return & Params: [ Num(0) Size(0x0) ]
	void ClearCache();

	// Object: Function DownloaderTool.DownloaderManager.Clear
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10170fd10
	// Return & Params: [ Num(0) Size(0x0) ]
	void Clear();

	// Object: Function DownloaderTool.DownloaderManager.CheckTaskInfosValid
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101710690
	// Return & Params: [ Num(2) Size(0x11) ]
	bool CheckTaskInfosValid(struct TArray<struct FDownloaderTaskInfo>& InAllTaskInfos);
};

// Object: Class DownloaderTool.DownloaderSubTask
// Inherited Bytes: 0x28 | Struct Size: 0x168
struct UDownloaderSubTask : UObject {
	// Fields
	struct FDelegate OnSubTaskProgress; // Offset: 0x28 | Size: 0x10
	struct FDelegate OnSubTaskSuccess; // Offset: 0x38 | Size: 0x10
	struct FDelegate OnSubTaskFailed; // Offset: 0x48 | Size: 0x10
	struct TWeakObjectPtr<struct UDownloaderManager> Manager; // Offset: 0x58 | Size: 0x8
	struct UDownloaderHttpTask* RealHttpTask; // Offset: 0x60 | Size: 0x8
	char pad_0x68[0x100]; // Offset: 0x68 | Size: 0x100

	// Functions

	// Object: Function DownloaderTool.DownloaderSubTask.OnRealHttpTaskSuccess
	// Flags: [Final|Native|Protected|HasOutParms]
	// Offset: 0x101712464
	// Return & Params: [ Num(1) Size(0x60) ]
	void OnRealHttpTaskSuccess(struct FDownloaderResponse& InResponse);

	// Object: Function DownloaderTool.DownloaderSubTask.OnRealHttpTaskProgress
	// Flags: [Final|Native|Protected]
	// Offset: 0x1017122b8
	// Return & Params: [ Num(2) Size(0x8) ]
	void OnRealHttpTaskProgress(int32_t InBytesSent, int32_t InBytesReceived);

	// Object: Function DownloaderTool.DownloaderSubTask.OnRealHttpTaskFailed
	// Flags: [Final|Native|Protected|HasOutParms]
	// Offset: 0x101712380
	// Return & Params: [ Num(2) Size(0x8) ]
	void OnRealHttpTaskFailed(enum class EDTFailedType& InFailedType, int32_t InErrorCode);
};

// Object: Class DownloaderTool.DownloaderUrlTask
// Inherited Bytes: 0x28 | Struct Size: 0x2a0
struct UDownloaderUrlTask : UObject {
	// Fields
	struct FDelegate OnUrlTaskProgress; // Offset: 0x28 | Size: 0x10
	struct FDelegate OnUrlTaskSuccess; // Offset: 0x38 | Size: 0x10
	struct FDelegate OnUrlTaskFailed; // Offset: 0x48 | Size: 0x10
	struct TWeakObjectPtr<struct UDownloaderManager> Manager; // Offset: 0x58 | Size: 0x8
	struct TMap<struct FName, struct UDownloaderSubTask*> AllSubTasksMap; // Offset: 0x60 | Size: 0x50
	char pad_0xB0[0x1f0]; // Offset: 0xb0 | Size: 0x1f0

	// Functions

	// Object: Function DownloaderTool.DownloaderUrlTask.OnSubTaskSuccess
	// Flags: [Final|Native|Protected|HasOutParms]
	// Offset: 0x1017134bc
	// Return & Params: [ Num(1) Size(0x60) ]
	void OnSubTaskSuccess(struct FDownloaderResponse& InResponse);

	// Object: Function DownloaderTool.DownloaderUrlTask.OnSubTaskProgress
	// Flags: [Final|Native|Protected]
	// Offset: 0x101713310
	// Return & Params: [ Num(2) Size(0x8) ]
	void OnSubTaskProgress(int32_t InCurBytesSent, int32_t InCurBytesReceived);

	// Object: Function DownloaderTool.DownloaderUrlTask.OnSubTaskFailed
	// Flags: [Final|Native|Protected|HasOutParms]
	// Offset: 0x1017133d8
	// Return & Params: [ Num(2) Size(0x8) ]
	void OnSubTaskFailed(enum class EDTFailedType& InFailedType, int32_t InErrorCode);

	// Object: Function DownloaderTool.DownloaderUrlTask.OnMergeFileComplete
	// Flags: [Final|Native|Protected]
	// Offset: 0x101713288
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnMergeFileComplete(bool bMergeResult);

	// Object: Function DownloaderTool.DownloaderUrlTask.OnHashCheckFileComplete
	// Flags: [Final|Native|Protected]
	// Offset: 0x101713200
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnHashCheckFileComplete(bool bHashCheckResult);

	// Object: Function DownloaderTool.DownloaderUrlTask.OnCallbackTimeOutFailed
	// Flags: [Final|Native|Protected]
	// Offset: 0x1017131ec
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnCallbackTimeOutFailed();
};

// Object: Class DownloaderTool.DownloaderUtils
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UDownloaderUtils : UObject {
	// Functions

	// Object: Function DownloaderTool.DownloaderUtils.TryUpdateUrlTaskRecordFile
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101714414
	// Return & Params: [ Num(3) Size(0x21) ]
	bool TryUpdateUrlTaskRecordFile(struct FString InUrlTaskRecordFilePath, struct FUrlTaskRecordInfo& InUrlTaskRecordInfo);

	// Object: Function DownloaderTool.DownloaderUtils.TrySaveResponseToCache
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101714204
	// Return & Params: [ Num(3) Size(0x71) ]
	bool TrySaveResponseToCache(struct FDownloaderResponse& InResponse, struct FString InCachePath);

	// Object: Function DownloaderTool.DownloaderUtils.TryGetUrlTaskRecordFromFile
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101714330
	// Return & Params: [ Num(3) Size(0x21) ]
	bool TryGetUrlTaskRecordFromFile(struct FString InUrlTaskRecordFilePath, struct FUrlTaskRecordInfo& OutUrlTaskRecordInfo);

	// Object: Function DownloaderTool.DownloaderUtils.TryGetResponseFromCache
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101714044
	// Return & Params: [ Num(4) Size(0x129) ]
	bool TryGetResponseFromCache(struct FDownloaderTaskInfo& InTaskInfo, struct FString InCachePath, struct FDownloaderResponse& OutResponse);

	// Object: Function DownloaderTool.DownloaderUtils.TryGetJsonStrFromDownloaderReqJson
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1017148b8
	// Return & Params: [ Num(3) Size(0xc9) ]
	bool TryGetJsonStrFromDownloaderReqJson(struct FDownloaderReqJson& InReqJson, struct FString& OutReqStr);

	// Object: Function DownloaderTool.DownloaderUtils.TryDeleteOldFileAndCreateDir
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101713fb8
	// Return & Params: [ Num(2) Size(0x11) ]
	bool TryDeleteOldFileAndCreateDir(struct FString InFileFullPath);

	// Object: Function DownloaderTool.DownloaderUtils.StringFileRawData
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101714af8
	// Return & Params: [ Num(2) Size(0x70) ]
	struct FString StringFileRawData(struct FDownloaderResponse& InResponse);

	// Object: Function DownloaderTool.DownloaderUtils.HashStringWithSHA1
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101714ce8
	// Return & Params: [ Num(2) Size(0x20) ]
	struct FString HashStringWithSHA1(struct FString inString);

	// Object: Function DownloaderTool.DownloaderUtils.GetVerbFromJsonRequestStr
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1017147f4
	// Return & Params: [ Num(2) Size(0x20) ]
	struct FString GetVerbFromJsonRequestStr(struct FString JsonRequestStr);

	// Object: Function DownloaderTool.DownloaderUtils.GetTaskInfoLogStr
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101713cf8
	// Return & Params: [ Num(2) Size(0xc8) ]
	struct FString GetTaskInfoLogStr(struct FDownloaderTaskInfo& InTaskInfo);

	// Object: Function DownloaderTool.DownloaderUtils.GetQueriesFromJsonRequestStr
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1017145bc
	// Return & Params: [ Num(2) Size(0x60) ]
	struct TMap<struct FString, struct FString> GetQueriesFromJsonRequestStr(struct FString JsonRequestStr);

	// Object: Function DownloaderTool.DownloaderUtils.GetHttpMethodTypeStr
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101713e18
	// Return & Params: [ Num(2) Size(0x18) ]
	struct FString GetHttpMethodTypeStr(enum class EDownloaderHttpMethod& InHttpMethod);

	// Object: Function DownloaderTool.DownloaderUtils.GetHeadersFromJsonRequestStr
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1017146d8
	// Return & Params: [ Num(2) Size(0x60) ]
	struct TMap<struct FString, struct FString> GetHeadersFromJsonRequestStr(struct FString JsonRequestStr);

	// Object: Function DownloaderTool.DownloaderUtils.GetFailedTypeStr
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101713ee8
	// Return & Params: [ Num(2) Size(0x18) ]
	struct FString GetFailedTypeStr(enum class EDTFailedType& InFailedType);

	// Object: Function DownloaderTool.DownloaderUtils.GetBodyFromJsonRequestStr
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1017144f8
	// Return & Params: [ Num(2) Size(0x20) ]
	struct FString GetBodyFromJsonRequestStr(struct FString JsonRequestStr);

	// Object: Function DownloaderTool.DownloaderUtils.GetAllTaskNameLogStr
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101713b2c
	// Return & Params: [ Num(5) Size(0x50) ]
	struct FString GetAllTaskNameLogStr(struct FString InMainTaskName, struct FString InUrlTaskName, struct FString InSubTaskName, struct FString InHttpTaskName);

	// Object: Function DownloaderTool.DownloaderUtils.ExtractFileNameAndExtensionFromFileFullName
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1017139e8
	// Return & Params: [ Num(3) Size(0x30) ]
	void ExtractFileNameAndExtensionFromFileFullName(struct FString InFileFullName, struct FString& OutFileName, struct FString& OutFileExtension);

	// Object: Function DownloaderTool.DownloaderUtils.execConvertRawDataToTexture
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101714c04
	// Return & Params: [ Num(3) Size(0x20) ]
	struct UTexture2DDynamic* execConvertRawDataToTexture(struct TArray<char>& Data, int32_t DataLength);

	// Object: Function DownloaderTool.DownloaderUtils.DecodeFileRawData
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1017149ec
	// Return & Params: [ Num(2) Size(0x70) ]
	struct FString DecodeFileRawData(struct FDownloaderResponse& InResponse);
};

