#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct DownloaderTool.DownloaderProgressInfo
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FDownloaderProgressInfo {
	// Fields
	struct FString NecessaryURL; // Offset: 0x0 | Size: 0x10
	int32_t BytesSent; // Offset: 0x10 | Size: 0x4
	int32_t BytesReceived; // Offset: 0x14 | Size: 0x4
	int32_t CacheWritedSize; // Offset: 0x18 | Size: 0x4
	int32_t MixedSize; // Offset: 0x1c | Size: 0x4
	int32_t TotalDownloadSize; // Offset: 0x20 | Size: 0x4
	char pad_0x24[0x4]; // Offset: 0x24 | Size: 0x4
};

// Object: ScriptStruct DownloaderTool.DownloaderResponse
// Inherited Bytes: 0x0 | Struct Size: 0x60
struct FDownloaderResponse {
	// Fields
	bool bWasSuccessful; // Offset: 0x0 | Size: 0x1
	bool bDownloadFromCache; // Offset: 0x1 | Size: 0x1
	char pad_0x2[0x6]; // Offset: 0x2 | Size: 0x6
	struct FString NecessaryURL; // Offset: 0x8 | Size: 0x10
	struct FString UsedCDNBaseURL; // Offset: 0x18 | Size: 0x10
	int32_t ErrorCode; // Offset: 0x28 | Size: 0x4
	char pad_0x2C[0x4]; // Offset: 0x2c | Size: 0x4
	struct TArray<char> RawData; // Offset: 0x30 | Size: 0x10
	struct FString RawFileSavePath; // Offset: 0x40 | Size: 0x10
	int32_t DataLength; // Offset: 0x50 | Size: 0x4
	int32_t ContentLength; // Offset: 0x54 | Size: 0x4
	int64_t Timestamp; // Offset: 0x58 | Size: 0x8
};

// Object: ScriptStruct DownloaderTool.DownloaderFailedInfo
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FDownloaderFailedInfo {
	// Fields
	struct FString NecessaryURL; // Offset: 0x0 | Size: 0x10
	int32_t ErrorCode; // Offset: 0x10 | Size: 0x4
	enum class EDTFailedType FailedType; // Offset: 0x14 | Size: 0x1
	char pad_0x15[0x3]; // Offset: 0x15 | Size: 0x3
};

// Object: ScriptStruct DownloaderTool.DownloaderTaskInfo
// Inherited Bytes: 0x0 | Struct Size: 0xb8
struct FDownloaderTaskInfo {
	// Fields
	struct FString NecessaryURL; // Offset: 0x0 | Size: 0x10
	struct TArray<struct FString> BaseCDNUrlList; // Offset: 0x10 | Size: 0x10
	struct FString JsonRequestStr; // Offset: 0x20 | Size: 0x10
	struct FString HashStr; // Offset: 0x30 | Size: 0x10
	int32_t MaxRetryTime; // Offset: 0x40 | Size: 0x4
	int32_t FileSize; // Offset: 0x44 | Size: 0x4
	bool bUsingResumeTrans; // Offset: 0x48 | Size: 0x1
	bool bClearSubTaskCache; // Offset: 0x49 | Size: 0x1
	bool bAsyncWrite; // Offset: 0x4a | Size: 0x1
	bool bAsyncMerge; // Offset: 0x4b | Size: 0x1
	bool bAsyncHashCheck; // Offset: 0x4c | Size: 0x1
	bool bUseBackgroundDownload; // Offset: 0x4d | Size: 0x1
	bool bForceRedownload; // Offset: 0x4e | Size: 0x1
	bool bForceWrite; // Offset: 0x4f | Size: 0x1
	bool bNeedHashCheck; // Offset: 0x50 | Size: 0x1
	bool bEnableTimeOutFailed; // Offset: 0x51 | Size: 0x1
	char pad_0x52[0x2]; // Offset: 0x52 | Size: 0x2
	float TimeOutSeconds; // Offset: 0x54 | Size: 0x4
	bool bCallBackWithRawData; // Offset: 0x58 | Size: 0x1
	bool bCutInLine; // Offset: 0x59 | Size: 0x1
	char pad_0x5A[0x6]; // Offset: 0x5a | Size: 0x6
	struct FString FileDirectory; // Offset: 0x60 | Size: 0x10
	struct FString FileFullName; // Offset: 0x70 | Size: 0x10
	bool bCompleted; // Offset: 0x80 | Size: 0x1
	bool bSuccessful; // Offset: 0x81 | Size: 0x1
	char pad_0x82[0x6]; // Offset: 0x82 | Size: 0x6
	int64_t StartTimeStamp; // Offset: 0x88 | Size: 0x8
	int64_t CompleteTimeStamp; // Offset: 0x90 | Size: 0x8
	struct FString Filename; // Offset: 0x98 | Size: 0x10
	struct FString FileExtension; // Offset: 0xa8 | Size: 0x10
};

// Object: ScriptStruct DownloaderTool.UrlTaskRecordInfo
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FUrlTaskRecordInfo {
	// Fields
	bool bUrlTaskSuccess; // Offset: 0x0 | Size: 0x1
	bool bHashCheckSuccess; // Offset: 0x1 | Size: 0x1
	char pad_0x2[0x2]; // Offset: 0x2 | Size: 0x2
	int32_t TotalDownloadSize; // Offset: 0x4 | Size: 0x4
	int32_t SubTaskChunkSize; // Offset: 0x8 | Size: 0x4
	int32_t CachedWritedSize; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct DownloaderTool.DownloaderReqJson
// Inherited Bytes: 0x0 | Struct Size: 0xb8
struct FDownloaderReqJson {
	// Fields
	enum class EDownloaderHttpMethod Verb; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x7]; // Offset: 0x1 | Size: 0x7
	struct TMap<struct FString, struct FString> Headers; // Offset: 0x8 | Size: 0x50
	struct TMap<struct FString, struct FString> Queries; // Offset: 0x58 | Size: 0x50
	struct FString Body; // Offset: 0xa8 | Size: 0x10
};

