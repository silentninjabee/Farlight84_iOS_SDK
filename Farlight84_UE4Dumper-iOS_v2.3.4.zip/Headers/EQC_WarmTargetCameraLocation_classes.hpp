#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass EQC_WarmTargetCameraLocation.EQC_WarmTargetCameraLocation_C
// Inherited Bytes: 0x30 | Struct Size: 0x30
struct UEQC_WarmTargetCameraLocation_C : UEnvQueryContext_BlueprintBase {
	// Functions

	// Object: Function EQC_WarmTargetCameraLocation.EQC_WarmTargetCameraLocation_C.ProvideSingleLocation
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(3) Size(0x1c) ]
	void ProvideSingleLocation(struct UObject* QuerierObject, struct AActor* QuerierActor, struct FVector& ResultingLocation);
};

