#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: UserDefinedEnum E_CountDownStyle.E_CountDownStyle
enum class E_CountDownStyle : uint8_t {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	E_MAX = 2
};

