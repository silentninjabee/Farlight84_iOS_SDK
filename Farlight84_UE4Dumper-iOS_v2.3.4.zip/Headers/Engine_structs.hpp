#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct Engine.DistributionLookupTable
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FDistributionLookupTable {
	// Fields
	float TimeScale; // Offset: 0x0 | Size: 0x4
	float TimeBias; // Offset: 0x4 | Size: 0x4
	struct TArray<float> Values; // Offset: 0x8 | Size: 0x10
	char Op; // Offset: 0x18 | Size: 0x1
	char EntryCount; // Offset: 0x19 | Size: 0x1
	char EntryStride; // Offset: 0x1a | Size: 0x1
	char SubEntryStride; // Offset: 0x1b | Size: 0x1
	char LockFlag; // Offset: 0x1c | Size: 0x1
	char pad_0x1D[0x3]; // Offset: 0x1d | Size: 0x3
};

// Object: ScriptStruct Engine.RawDistribution
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FRawDistribution {
	// Fields
	struct FDistributionLookupTable Table; // Offset: 0x0 | Size: 0x20
};

// Object: ScriptStruct Engine.FloatDistribution
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FFloatDistribution {
	// Fields
	struct FDistributionLookupTable Table; // Offset: 0x0 | Size: 0x20
};

// Object: ScriptStruct Engine.VectorDistribution
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FVectorDistribution {
	// Fields
	struct FDistributionLookupTable Table; // Offset: 0x0 | Size: 0x20
};

// Object: ScriptStruct Engine.Vector4Distribution
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FVector4Distribution {
	// Fields
	struct FDistributionLookupTable Table; // Offset: 0x0 | Size: 0x20
};

// Object: ScriptStruct Engine.FloatRK4SpringInterpolator
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FFloatRK4SpringInterpolator {
	// Fields
	float StiffnessConstant; // Offset: 0x0 | Size: 0x4
	float DampeningRatio; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct Engine.VectorRK4SpringInterpolator
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FVectorRK4SpringInterpolator {
	// Fields
	float StiffnessConstant; // Offset: 0x0 | Size: 0x4
	float DampeningRatio; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct Engine.FormatArgumentData
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FFormatArgumentData {
	// Fields
	struct FString ArgumentName; // Offset: 0x0 | Size: 0x10
	enum class EFormatArgumentType ArgumentValueType; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x7]; // Offset: 0x11 | Size: 0x7
	struct FText ArgumentValue; // Offset: 0x18 | Size: 0x18
	int32_t ArgumentValueInt; // Offset: 0x30 | Size: 0x4
	float ArgumentValueFloat; // Offset: 0x34 | Size: 0x4
	enum class ETextGender ArgumentValueGender; // Offset: 0x38 | Size: 0x1
	char pad_0x39[0x7]; // Offset: 0x39 | Size: 0x7
};

// Object: ScriptStruct Engine.ExpressionInput
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FExpressionInput {
	// Fields
	int32_t OutputIndex; // Offset: 0x0 | Size: 0x4
	struct FName ExpressionName; // Offset: 0x4 | Size: 0x8
};

// Object: ScriptStruct Engine.MaterialAttributesInput
// Inherited Bytes: 0xc | Struct Size: 0x10
struct FMaterialAttributesInput : FExpressionInput {
	// Fields
	int32_t PropertyConnectedBitmask; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct Engine.ExpressionOutput
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FExpressionOutput {
	// Fields
	struct FName OutputName; // Offset: 0x0 | Size: 0x8
};

// Object: ScriptStruct Engine.MaterialInput
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FMaterialInput {
	// Fields
	int32_t OutputIndex; // Offset: 0x0 | Size: 0x4
	struct FName ExpressionName; // Offset: 0x4 | Size: 0x8
};

// Object: ScriptStruct Engine.ColorMaterialInput
// Inherited Bytes: 0xc | Struct Size: 0xc
struct FColorMaterialInput : FMaterialInput {
};

// Object: ScriptStruct Engine.ScalarMaterialInput
// Inherited Bytes: 0xc | Struct Size: 0xc
struct FScalarMaterialInput : FMaterialInput {
};

// Object: ScriptStruct Engine.ShadingModelMaterialInput
// Inherited Bytes: 0xc | Struct Size: 0xc
struct FShadingModelMaterialInput : FMaterialInput {
};

// Object: ScriptStruct Engine.VectorMaterialInput
// Inherited Bytes: 0xc | Struct Size: 0xc
struct FVectorMaterialInput : FMaterialInput {
};

// Object: ScriptStruct Engine.Vector2MaterialInput
// Inherited Bytes: 0xc | Struct Size: 0xc
struct FVector2MaterialInput : FMaterialInput {
};

// Object: ScriptStruct Engine.HitResult
// Inherited Bytes: 0x0 | Struct Size: 0x88
struct FHitResult {
	// Fields
	char bBlockingHit : 1; // Offset: 0x0 | Size: 0x1
	char bStartPenetrating : 1; // Offset: 0x0 | Size: 0x1
	char pad_0x0_2 : 6; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	int32_t FaceIndex; // Offset: 0x4 | Size: 0x4
	float Time; // Offset: 0x8 | Size: 0x4
	float Distance; // Offset: 0xc | Size: 0x4
	struct FVector_NetQuantize Location; // Offset: 0x10 | Size: 0xc
	struct FVector_NetQuantize ImpactPoint; // Offset: 0x1c | Size: 0xc
	struct FVector_NetQuantizeNormal Normal; // Offset: 0x28 | Size: 0xc
	struct FVector_NetQuantizeNormal ImpactNormal; // Offset: 0x34 | Size: 0xc
	struct FVector_NetQuantize TraceStart; // Offset: 0x40 | Size: 0xc
	struct FVector_NetQuantize TraceEnd; // Offset: 0x4c | Size: 0xc
	float PenetrationDepth; // Offset: 0x58 | Size: 0x4
	int32_t Item; // Offset: 0x5c | Size: 0x4
	struct TWeakObjectPtr<struct UPhysicalMaterial> PhysMaterial; // Offset: 0x60 | Size: 0x8
	struct TWeakObjectPtr<struct AActor> Actor; // Offset: 0x68 | Size: 0x8
	struct TWeakObjectPtr<struct UPrimitiveComponent> Component; // Offset: 0x70 | Size: 0x8
	struct FName BoneName; // Offset: 0x78 | Size: 0x8
	struct FName MyBoneName; // Offset: 0x80 | Size: 0x8
};

// Object: ScriptStruct Engine.Vector_NetQuantize
// Inherited Bytes: 0xc | Struct Size: 0xc
struct FVector_NetQuantize : FVector {
};

// Object: ScriptStruct Engine.Vector_NetQuantizeNormal
// Inherited Bytes: 0xc | Struct Size: 0xc
struct FVector_NetQuantizeNormal : FVector {
};

// Object: ScriptStruct Engine.BranchingPointNotifyPayload
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FBranchingPointNotifyPayload {
	// Fields
	char pad_0x0[0x20]; // Offset: 0x0 | Size: 0x20
};

// Object: ScriptStruct Engine.SimpleMemberReference
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FSimpleMemberReference {
	// Fields
	struct UObject* MemberParent; // Offset: 0x0 | Size: 0x8
	struct FName MemberName; // Offset: 0x8 | Size: 0x8
	struct FGuid MemberGuid; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct Engine.TickFunction
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FTickFunction {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
	enum class ETickingGroup TickGroup; // Offset: 0x8 | Size: 0x1
	enum class ETickingGroup EndTickGroup; // Offset: 0x9 | Size: 0x1
	char bTickEvenWhenPaused : 1; // Offset: 0xa | Size: 0x1
	char bCanEverTick : 1; // Offset: 0xa | Size: 0x1
	char bStartWithTickEnabled : 1; // Offset: 0xa | Size: 0x1
	char bAllowTickOnDedicatedServer : 1; // Offset: 0xa | Size: 0x1
	char pad_0xA_4 : 4; // Offset: 0xa | Size: 0x1
	char pad_0xB[0x1]; // Offset: 0xb | Size: 0x1
	float TickInterval; // Offset: 0xc | Size: 0x4
	char pad_0x10[0x18]; // Offset: 0x10 | Size: 0x18
};

// Object: ScriptStruct Engine.ActorComponentTickFunction
// Inherited Bytes: 0x28 | Struct Size: 0x30
struct FActorComponentTickFunction : FTickFunction {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
};

// Object: ScriptStruct Engine.SubtitleCue
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FSubtitleCue {
	// Fields
	struct FText Text; // Offset: 0x0 | Size: 0x18
	float Time; // Offset: 0x18 | Size: 0x4
	char pad_0x1C[0x4]; // Offset: 0x1c | Size: 0x4
};

// Object: ScriptStruct Engine.InterpControlPoint
// Inherited Bytes: 0x0 | Struct Size: 0x1c
struct FInterpControlPoint {
	// Fields
	struct FVector PositionControlPoint; // Offset: 0x0 | Size: 0xc
	bool bPositionIsRelative; // Offset: 0xc | Size: 0x1
	char pad_0xD[0xf]; // Offset: 0xd | Size: 0xf
};

// Object: ScriptStruct Engine.PlatformInterfaceDelegateResult
// Inherited Bytes: 0x0 | Struct Size: 0x38
struct FPlatformInterfaceDelegateResult {
	// Fields
	bool bSuccessful; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x7]; // Offset: 0x1 | Size: 0x7
	struct FPlatformInterfaceData Data; // Offset: 0x8 | Size: 0x30
};

// Object: ScriptStruct Engine.PlatformInterfaceData
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FPlatformInterfaceData {
	// Fields
	struct FName DataName; // Offset: 0x0 | Size: 0x8
	enum class EPlatformInterfaceDataType Type; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x3]; // Offset: 0x9 | Size: 0x3
	int32_t IntValue; // Offset: 0xc | Size: 0x4
	float FloatValue; // Offset: 0x10 | Size: 0x4
	char pad_0x14[0x4]; // Offset: 0x14 | Size: 0x4
	struct FString StringValue; // Offset: 0x18 | Size: 0x10
	struct UObject* ObjectValue; // Offset: 0x28 | Size: 0x8
};

// Object: ScriptStruct Engine.DebugFloatHistory
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FDebugFloatHistory {
	// Fields
	struct TArray<float> Samples; // Offset: 0x0 | Size: 0x10
	float MaxSamples; // Offset: 0x10 | Size: 0x4
	float MinValue; // Offset: 0x14 | Size: 0x4
	float MaxValue; // Offset: 0x18 | Size: 0x4
	bool bAutoAdjustMinMax; // Offset: 0x1c | Size: 0x1
	char pad_0x1D[0x3]; // Offset: 0x1d | Size: 0x3
};

// Object: ScriptStruct Engine.LatentActionInfo
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FLatentActionInfo {
	// Fields
	int32_t Linkage; // Offset: 0x0 | Size: 0x4
	int32_t UUID; // Offset: 0x4 | Size: 0x4
	struct FName ExecutionFunction; // Offset: 0x8 | Size: 0x8
	struct UObject* CallbackTarget; // Offset: 0x10 | Size: 0x8
};

// Object: ScriptStruct Engine.TimerHandle
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FTimerHandle {
	// Fields
	uint64_t Handle; // Offset: 0x0 | Size: 0x8
};

// Object: ScriptStruct Engine.CollisionProfileName
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FCollisionProfileName {
	// Fields
	struct FName Name; // Offset: 0x0 | Size: 0x8
};

// Object: ScriptStruct Engine.GenericStruct
// Inherited Bytes: 0x0 | Struct Size: 0x4
struct FGenericStruct {
	// Fields
	int32_t Data; // Offset: 0x0 | Size: 0x4
};

// Object: ScriptStruct Engine.UserActivity
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FUserActivity {
	// Fields
	struct FString ActionName; // Offset: 0x0 | Size: 0x10
	char pad_0x10[0x8]; // Offset: 0x10 | Size: 0x8
};

// Object: ScriptStruct Engine.FastArraySerializerItem
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FFastArraySerializerItem {
	// Fields
	int32_t ReplicationID; // Offset: 0x0 | Size: 0x4
	int32_t ReplicationKey; // Offset: 0x4 | Size: 0x4
	int32_t MostRecentArrayReplicationKey; // Offset: 0x8 | Size: 0x4
};

// Object: ScriptStruct Engine.CurveTableRowHandle
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FCurveTableRowHandle {
	// Fields
	struct UCurveTable* CurveTable; // Offset: 0x0 | Size: 0x8
	struct FName RowName; // Offset: 0x8 | Size: 0x8
};

// Object: ScriptStruct Engine.Vector_NetQuantize10
// Inherited Bytes: 0xc | Struct Size: 0xc
struct FVector_NetQuantize10 : FVector {
};

// Object: ScriptStruct Engine.Vector_NetQuantize100
// Inherited Bytes: 0xc | Struct Size: 0xc
struct FVector_NetQuantize100 : FVector {
};

// Object: ScriptStruct Engine.FastArraySerializer
// Inherited Bytes: 0x0 | Struct Size: 0x108
struct FFastArraySerializer {
	// Fields
	char pad_0x0[0x54]; // Offset: 0x0 | Size: 0x54
	int32_t ArrayReplicationKey; // Offset: 0x54 | Size: 0x4
	char pad_0x58[0xa8]; // Offset: 0x58 | Size: 0xa8
	enum class EFastArraySerializerDeltaFlags DeltaFlags; // Offset: 0x100 | Size: 0x1
	char pad_0x101[0x7]; // Offset: 0x101 | Size: 0x7
};

// Object: ScriptStruct Engine.DataTableRowHandle
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FDataTableRowHandle {
	// Fields
	struct UDataTable* DataTable; // Offset: 0x0 | Size: 0x8
	struct FName RowName; // Offset: 0x8 | Size: 0x8
};

// Object: ScriptStruct Engine.RepAttachment
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FRepAttachment {
	// Fields
	struct AActor* AttachParent; // Offset: 0x0 | Size: 0x8
	struct FVector_NetQuantize100 LocationOffset; // Offset: 0x8 | Size: 0xc
	struct FVector_NetQuantize100 RelativeScale3D; // Offset: 0x14 | Size: 0xc
	struct FRotator RotationOffset; // Offset: 0x20 | Size: 0xc
	struct FName AttachSocket; // Offset: 0x2c | Size: 0x8
	char pad_0x34[0x4]; // Offset: 0x34 | Size: 0x4
	struct USceneComponent* AttachComponent; // Offset: 0x38 | Size: 0x8
};

// Object: ScriptStruct Engine.RepMovement
// Inherited Bytes: 0x0 | Struct Size: 0x38
struct FRepMovement {
	// Fields
	struct FVector LinearVelocity; // Offset: 0x0 | Size: 0xc
	struct FVector AngularVelocity; // Offset: 0xc | Size: 0xc
	struct FVector Location; // Offset: 0x18 | Size: 0xc
	struct FRotator Rotation; // Offset: 0x24 | Size: 0xc
	char pad_0x30[0x4]; // Offset: 0x30 | Size: 0x4
	char bSimulatedPhysicSleep : 1; // Offset: 0x34 | Size: 0x1
	char bRepPhysics : 1; // Offset: 0x34 | Size: 0x1
	char pad_0x34_2 : 6; // Offset: 0x34 | Size: 0x1
	enum class EVectorQuantization LocationQuantizationLevel; // Offset: 0x35 | Size: 0x1
	enum class EVectorQuantization VelocityQuantizationLevel; // Offset: 0x36 | Size: 0x1
	enum class ERotatorQuantization RotationQuantizationLevel; // Offset: 0x37 | Size: 0x1
};

// Object: ScriptStruct Engine.ActorTickFunction
// Inherited Bytes: 0x28 | Struct Size: 0x30
struct FActorTickFunction : FTickFunction {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
};

// Object: ScriptStruct Engine.MovementProperties
// Inherited Bytes: 0x0 | Struct Size: 0x1
struct FMovementProperties {
	// Fields
	char bCanCrouch : 1; // Offset: 0x0 | Size: 0x1
	char bCanJump : 1; // Offset: 0x0 | Size: 0x1
	char bCanWalk : 1; // Offset: 0x0 | Size: 0x1
	char bCanSwim : 1; // Offset: 0x0 | Size: 0x1
	char bCanFly : 1; // Offset: 0x0 | Size: 0x1
	char pad_0x0_5 : 3; // Offset: 0x0 | Size: 0x1
};

// Object: ScriptStruct Engine.NavAgentProperties
// Inherited Bytes: 0x1 | Struct Size: 0x30
struct FNavAgentProperties : FMovementProperties {
	// Fields
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	float AgentRadius; // Offset: 0x4 | Size: 0x4
	float AgentHeight; // Offset: 0x8 | Size: 0x4
	float AgentStepHeight; // Offset: 0xc | Size: 0x4
	float NavWalkingSearchHeightScale; // Offset: 0x10 | Size: 0x4
	char pad_0x14[0x4]; // Offset: 0x14 | Size: 0x4
	struct FSoftClassPath PreferredNavData; // Offset: 0x18 | Size: 0x18
};

// Object: ScriptStruct Engine.FindFloorResult
// Inherited Bytes: 0x0 | Struct Size: 0x94
struct FFindFloorResult {
	// Fields
	char bBlockingHit : 1; // Offset: 0x0 | Size: 0x1
	char bWalkableFloor : 1; // Offset: 0x0 | Size: 0x1
	char bLineTrace : 1; // Offset: 0x0 | Size: 0x1
	char pad_0x0_3 : 5; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	float FloorDist; // Offset: 0x4 | Size: 0x4
	float LineDist; // Offset: 0x8 | Size: 0x4
	struct FHitResult HitResult; // Offset: 0xc | Size: 0x88
};

// Object: ScriptStruct Engine.NavAvoidanceMask
// Inherited Bytes: 0x0 | Struct Size: 0x4
struct FNavAvoidanceMask {
	// Fields
	char bGroup0 : 1; // Offset: 0x0 | Size: 0x1
	char bGroup1 : 1; // Offset: 0x0 | Size: 0x1
	char bGroup2 : 1; // Offset: 0x0 | Size: 0x1
	char bGroup3 : 1; // Offset: 0x0 | Size: 0x1
	char bGroup4 : 1; // Offset: 0x0 | Size: 0x1
	char bGroup5 : 1; // Offset: 0x0 | Size: 0x1
	char bGroup6 : 1; // Offset: 0x0 | Size: 0x1
	char bGroup7 : 1; // Offset: 0x0 | Size: 0x1
	char bGroup8 : 1; // Offset: 0x1 | Size: 0x1
	char bGroup9 : 1; // Offset: 0x1 | Size: 0x1
	char bGroup10 : 1; // Offset: 0x1 | Size: 0x1
	char bGroup11 : 1; // Offset: 0x1 | Size: 0x1
	char bGroup12 : 1; // Offset: 0x1 | Size: 0x1
	char bGroup13 : 1; // Offset: 0x1 | Size: 0x1
	char bGroup14 : 1; // Offset: 0x1 | Size: 0x1
	char bGroup15 : 1; // Offset: 0x1 | Size: 0x1
	char bGroup16 : 1; // Offset: 0x2 | Size: 0x1
	char bGroup17 : 1; // Offset: 0x2 | Size: 0x1
	char bGroup18 : 1; // Offset: 0x2 | Size: 0x1
	char bGroup19 : 1; // Offset: 0x2 | Size: 0x1
	char bGroup20 : 1; // Offset: 0x2 | Size: 0x1
	char bGroup21 : 1; // Offset: 0x2 | Size: 0x1
	char bGroup22 : 1; // Offset: 0x2 | Size: 0x1
	char bGroup23 : 1; // Offset: 0x2 | Size: 0x1
	char bGroup24 : 1; // Offset: 0x3 | Size: 0x1
	char bGroup25 : 1; // Offset: 0x3 | Size: 0x1
	char bGroup26 : 1; // Offset: 0x3 | Size: 0x1
	char bGroup27 : 1; // Offset: 0x3 | Size: 0x1
	char bGroup28 : 1; // Offset: 0x3 | Size: 0x1
	char bGroup29 : 1; // Offset: 0x3 | Size: 0x1
	char bGroup30 : 1; // Offset: 0x3 | Size: 0x1
	char bGroup31 : 1; // Offset: 0x3 | Size: 0x1
};

// Object: ScriptStruct Engine.RootMotionMovementParams
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FRootMotionMovementParams {
	// Fields
	bool bHasRootMotion; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	float BlendWeight; // Offset: 0x4 | Size: 0x4
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FTransform RootMotionTransform; // Offset: 0x10 | Size: 0x30
};

// Object: ScriptStruct Engine.RootMotionSourceGroup
// Inherited Bytes: 0x0 | Struct Size: 0x38
struct FRootMotionSourceGroup {
	// Fields
	char pad_0x0[0x28]; // Offset: 0x0 | Size: 0x28
	char bHasAdditiveSources : 1; // Offset: 0x28 | Size: 0x1
	char bHasOverrideSources : 1; // Offset: 0x28 | Size: 0x1
	char bHasOverrideSourcesWithIgnoreZAccumulate : 1; // Offset: 0x28 | Size: 0x1
	char bIsAdditiveVelocityApplied : 1; // Offset: 0x28 | Size: 0x1
	char pad_0x28_4 : 4; // Offset: 0x28 | Size: 0x1
	struct FRootMotionSourceSettings LastAccumulatedSettings; // Offset: 0x29 | Size: 0x1
	char pad_0x2A[0x2]; // Offset: 0x2a | Size: 0x2
	struct FVector_NetQuantize10 LastPreAdditiveVelocity; // Offset: 0x2c | Size: 0xc
};

// Object: ScriptStruct Engine.RootMotionSourceSettings
// Inherited Bytes: 0x0 | Struct Size: 0x1
struct FRootMotionSourceSettings {
	// Fields
	char Flags; // Offset: 0x0 | Size: 0x1
};

// Object: ScriptStruct Engine.CharacterMovementComponentPostPhysicsTickFunction
// Inherited Bytes: 0x28 | Struct Size: 0x30
struct FCharacterMovementComponentPostPhysicsTickFunction : FTickFunction {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
};

// Object: ScriptStruct Engine.RuntimeFloatCurve
// Inherited Bytes: 0x0 | Struct Size: 0x88
struct FRuntimeFloatCurve {
	// Fields
	struct FRichCurve EditorCurveData; // Offset: 0x0 | Size: 0x80
	struct UCurveFloat* ExternalCurve; // Offset: 0x80 | Size: 0x8
};

// Object: ScriptStruct Engine.IndexedCurve
// Inherited Bytes: 0x0 | Struct Size: 0x68
struct FIndexedCurve {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
	struct FKeyHandleMap KeyHandlesToIndices; // Offset: 0x8 | Size: 0x60
};

// Object: ScriptStruct Engine.KeyHandleMap
// Inherited Bytes: 0x0 | Struct Size: 0x60
struct FKeyHandleMap {
	// Fields
	char pad_0x0[0x60]; // Offset: 0x0 | Size: 0x60
};

// Object: ScriptStruct Engine.RealCurve
// Inherited Bytes: 0x68 | Struct Size: 0x70
struct FRealCurve : FIndexedCurve {
	// Fields
	float DefaultValue; // Offset: 0x68 | Size: 0x4
	enum class ERichCurveExtrapolation PreInfinityExtrap; // Offset: 0x6c | Size: 0x1
	enum class ERichCurveExtrapolation PostInfinityExtrap; // Offset: 0x6d | Size: 0x1
	char pad_0x6E[0x2]; // Offset: 0x6e | Size: 0x2
};

// Object: ScriptStruct Engine.RichCurve
// Inherited Bytes: 0x70 | Struct Size: 0x80
struct FRichCurve : FRealCurve {
	// Fields
	struct TArray<struct FRichCurveKey> Keys; // Offset: 0x70 | Size: 0x10
};

// Object: ScriptStruct Engine.RichCurveKey
// Inherited Bytes: 0x0 | Struct Size: 0x1c
struct FRichCurveKey {
	// Fields
	enum class ERichCurveInterpMode InterpMode; // Offset: 0x0 | Size: 0x1
	enum class ERichCurveTangentMode TangentMode; // Offset: 0x1 | Size: 0x1
	enum class ERichCurveTangentWeightMode TangentWeightMode; // Offset: 0x2 | Size: 0x1
	char pad_0x3[0x1]; // Offset: 0x3 | Size: 0x1
	float Time; // Offset: 0x4 | Size: 0x4
	float Value; // Offset: 0x8 | Size: 0x4
	float ArriveTangent; // Offset: 0xc | Size: 0x4
	float ArriveTangentWeight; // Offset: 0x10 | Size: 0x4
	float LeaveTangent; // Offset: 0x14 | Size: 0x4
	float LeaveTangentWeight; // Offset: 0x18 | Size: 0x4
};

// Object: ScriptStruct Engine.UniqueNetIdRepl
// Inherited Bytes: 0x1 | Struct Size: 0x28
struct FUniqueNetIdRepl : FUniqueNetIdWrapper {
	// Fields
	char pad_0x1[0x17]; // Offset: 0x1 | Size: 0x17
	struct TArray<char> ReplicationBytes; // Offset: 0x18 | Size: 0x10
};

// Object: ScriptStruct Engine.RepRootMotionMontage
// Inherited Bytes: 0x0 | Struct Size: 0x98
struct FRepRootMotionMontage {
	// Fields
	bool bIsActive; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x7]; // Offset: 0x1 | Size: 0x7
	struct UAnimMontage* AnimMontage; // Offset: 0x8 | Size: 0x8
	float Position; // Offset: 0x10 | Size: 0x4
	struct FVector_NetQuantize100 Location; // Offset: 0x14 | Size: 0xc
	struct FRotator Rotation; // Offset: 0x20 | Size: 0xc
	char pad_0x2C[0x4]; // Offset: 0x2c | Size: 0x4
	struct UPrimitiveComponent* MovementBase; // Offset: 0x30 | Size: 0x8
	struct FName MovementBaseBoneName; // Offset: 0x38 | Size: 0x8
	bool bRelativePosition; // Offset: 0x40 | Size: 0x1
	bool bRelativeRotation; // Offset: 0x41 | Size: 0x1
	char pad_0x42[0x6]; // Offset: 0x42 | Size: 0x6
	struct FRootMotionSourceGroup AuthoritativeRootMotion; // Offset: 0x48 | Size: 0x38
	struct FVector_NetQuantize10 Acceleration; // Offset: 0x80 | Size: 0xc
	struct FVector_NetQuantize10 LinearVelocity; // Offset: 0x8c | Size: 0xc
};

// Object: ScriptStruct Engine.SimulatedRootMotionReplicatedMove
// Inherited Bytes: 0x0 | Struct Size: 0xa0
struct FSimulatedRootMotionReplicatedMove {
	// Fields
	float Time; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct FRepRootMotionMontage RootMotion; // Offset: 0x8 | Size: 0x98
};

// Object: ScriptStruct Engine.BasedMovementInfo
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FBasedMovementInfo {
	// Fields
	struct UPrimitiveComponent* MovementBase; // Offset: 0x0 | Size: 0x8
	struct FName BoneName; // Offset: 0x8 | Size: 0x8
	struct FVector_NetQuantize100 Location; // Offset: 0x10 | Size: 0xc
	struct FRotator Rotation; // Offset: 0x1c | Size: 0xc
	bool bServerHasBaseComponent; // Offset: 0x28 | Size: 0x1
	bool bRelativeRotation; // Offset: 0x29 | Size: 0x1
	bool bServerHasVelocity; // Offset: 0x2a | Size: 0x1
	char pad_0x2B[0x5]; // Offset: 0x2b | Size: 0x5
};

// Object: ScriptStruct Engine.DamageEvent
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FDamageEvent {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
	struct UDamageType* DamageTypeClass; // Offset: 0x8 | Size: 0x8
};

// Object: ScriptStruct Engine.PointDamageEvent
// Inherited Bytes: 0x10 | Struct Size: 0xa8
struct FPointDamageEvent : FDamageEvent {
	// Fields
	float Damage; // Offset: 0x10 | Size: 0x4
	struct FVector_NetQuantizeNormal ShotDirection; // Offset: 0x14 | Size: 0xc
	struct FHitResult HitInfo; // Offset: 0x20 | Size: 0x88
};

// Object: ScriptStruct Engine.Timeline
// Inherited Bytes: 0x0 | Struct Size: 0x98
struct FTimeline {
	// Fields
	enum class ETimelineLengthMode LengthMode; // Offset: 0x0 | Size: 0x1
	char bLooping : 1; // Offset: 0x1 | Size: 0x1
	char bReversePlayback : 1; // Offset: 0x1 | Size: 0x1
	char bPlaying : 1; // Offset: 0x1 | Size: 0x1
	char pad_0x1_3 : 5; // Offset: 0x1 | Size: 0x1
	char pad_0x2[0x2]; // Offset: 0x2 | Size: 0x2
	float Length; // Offset: 0x4 | Size: 0x4
	float PlayRate; // Offset: 0x8 | Size: 0x4
	float Position; // Offset: 0xc | Size: 0x4
	struct TArray<struct FTimelineEventEntry> Events; // Offset: 0x10 | Size: 0x10
	struct TArray<struct FTimelineVectorTrack> InterpVectors; // Offset: 0x20 | Size: 0x10
	struct TArray<struct FTimelineFloatTrack> InterpFloats; // Offset: 0x30 | Size: 0x10
	struct TArray<struct FTimelineLinearColorTrack> InterpLinearColors; // Offset: 0x40 | Size: 0x10
	struct FDelegate TimelinePostUpdateFunc; // Offset: 0x50 | Size: 0x10
	struct FDelegate TimelineFinishedFunc; // Offset: 0x60 | Size: 0x10
	struct TWeakObjectPtr<struct UObject> PropertySetObject; // Offset: 0x70 | Size: 0x8
	struct FName DirectionPropertyName; // Offset: 0x78 | Size: 0x8
	char pad_0x80[0x18]; // Offset: 0x80 | Size: 0x18
};

// Object: ScriptStruct Engine.TimelineLinearColorTrack
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FTimelineLinearColorTrack {
	// Fields
	struct UCurveLinearColor* LinearColorCurve; // Offset: 0x0 | Size: 0x8
	struct FDelegate InterpFunc; // Offset: 0x8 | Size: 0x10
	struct FName TrackName; // Offset: 0x18 | Size: 0x8
	struct FName LinearColorPropertyName; // Offset: 0x20 | Size: 0x8
	char pad_0x28[0x18]; // Offset: 0x28 | Size: 0x18
};

// Object: ScriptStruct Engine.TimelineFloatTrack
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FTimelineFloatTrack {
	// Fields
	struct UCurveFloat* FloatCurve; // Offset: 0x0 | Size: 0x8
	struct FDelegate InterpFunc; // Offset: 0x8 | Size: 0x10
	struct FName TrackName; // Offset: 0x18 | Size: 0x8
	struct FName FloatPropertyName; // Offset: 0x20 | Size: 0x8
	char pad_0x28[0x18]; // Offset: 0x28 | Size: 0x18
};

// Object: ScriptStruct Engine.TimelineVectorTrack
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FTimelineVectorTrack {
	// Fields
	struct UCurveVector* VectorCurve; // Offset: 0x0 | Size: 0x8
	struct FDelegate InterpFunc; // Offset: 0x8 | Size: 0x10
	struct FName TrackName; // Offset: 0x18 | Size: 0x8
	struct FName VectorPropertyName; // Offset: 0x20 | Size: 0x8
	char pad_0x28[0x18]; // Offset: 0x28 | Size: 0x18
};

// Object: ScriptStruct Engine.TimelineEventEntry
// Inherited Bytes: 0x0 | Struct Size: 0x14
struct FTimelineEventEntry {
	// Fields
	float Time; // Offset: 0x0 | Size: 0x4
	struct FDelegate EventFunc; // Offset: 0x4 | Size: 0x10
};

// Object: ScriptStruct Engine.ForceFeedbackParameters
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FForceFeedbackParameters {
	// Fields
	struct FName Tag; // Offset: 0x0 | Size: 0x8
	bool bLooping; // Offset: 0x8 | Size: 0x1
	bool bIgnoreTimeDilation; // Offset: 0x9 | Size: 0x1
	bool bPlayWhilePaused; // Offset: 0xa | Size: 0x1
	char pad_0xB[0x1]; // Offset: 0xb | Size: 0x1
	float Intensity; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct Engine.ViewTargetTransitionParams
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FViewTargetTransitionParams {
	// Fields
	float BlendTime; // Offset: 0x0 | Size: 0x4
	enum class EViewTargetBlendFunction BlendFunction; // Offset: 0x4 | Size: 0x1
	char pad_0x5[0x3]; // Offset: 0x5 | Size: 0x3
	float BlendExp; // Offset: 0x8 | Size: 0x4
	char bLockOutgoing : 1; // Offset: 0xc | Size: 0x1
	char bWaitScoutViewBeforeAssign : 1; // Offset: 0xc | Size: 0x1
	char pad_0xC_2 : 6; // Offset: 0xc | Size: 0x1
	char pad_0xD[0xb]; // Offset: 0xd | Size: 0xb
};

// Object: ScriptStruct Engine.UpdateLevelStreamingLevelStatus
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FUpdateLevelStreamingLevelStatus {
	// Fields
	struct FName PackageName; // Offset: 0x0 | Size: 0x8
	int32_t LODIndex; // Offset: 0x8 | Size: 0x4
	char bNewShouldBeLoaded : 1; // Offset: 0xc | Size: 0x1
	char bNewShouldBeVisible : 1; // Offset: 0xc | Size: 0x1
	char bNewShouldBlockOnLoad : 1; // Offset: 0xc | Size: 0x1
	char pad_0xC_3 : 5; // Offset: 0xc | Size: 0x1
	char pad_0xD[0x3]; // Offset: 0xd | Size: 0x3
};

// Object: ScriptStruct Engine.UpdateLevelVisibilityLevelInfo
// Inherited Bytes: 0x0 | Struct Size: 0x14
struct FUpdateLevelVisibilityLevelInfo {
	// Fields
	struct FName PackageName; // Offset: 0x0 | Size: 0x8
	struct FName Filename; // Offset: 0x8 | Size: 0x8
	char bIsVisible : 1; // Offset: 0x10 | Size: 0x1
	char pad_0x10_1 : 7; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x3]; // Offset: 0x11 | Size: 0x3
};

// Object: ScriptStruct Engine.ActiveForceFeedbackEffect
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FActiveForceFeedbackEffect {
	// Fields
	struct UForceFeedbackEffect* ForceFeedbackEffect; // Offset: 0x0 | Size: 0x8
	char pad_0x8[0x18]; // Offset: 0x8 | Size: 0x18
};

// Object: ScriptStruct Engine.WalkableSlopeOverride
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FWalkableSlopeOverride {
	// Fields
	enum class EWalkableSlopeBehavior WalkableSlopeBehavior; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	float WalkableSlopeAngle; // Offset: 0x4 | Size: 0x4
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
};

// Object: ScriptStruct Engine.BodyInstance
// Inherited Bytes: 0x0 | Struct Size: 0x130
struct FBodyInstance {
	// Fields
	char pad_0x0[0x6]; // Offset: 0x0 | Size: 0x6
	enum class ECollisionChannel ObjectType; // Offset: 0x6 | Size: 0x1
	char pad_0x7[0x1]; // Offset: 0x7 | Size: 0x1
	enum class ECollisionEnabled CollisionEnabled; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x1]; // Offset: 0x9 | Size: 0x1
	enum class ESleepFamily SleepFamily; // Offset: 0xa | Size: 0x1
	enum class EDOFMode DOFMode; // Offset: 0xb | Size: 0x1
	char bUseCCD : 1; // Offset: 0xc | Size: 0x1
	char bIgnoreAnalyticCollisions : 1; // Offset: 0xc | Size: 0x1
	char bNotifyRigidBodyCollision : 1; // Offset: 0xc | Size: 0x1
	char pad_0xC_3 : 1; // Offset: 0xc | Size: 0x1
	char bSimulatePhysics : 1; // Offset: 0xc | Size: 0x1
	char bOverrideMass : 1; // Offset: 0xc | Size: 0x1
	char bEnableGravity : 1; // Offset: 0xc | Size: 0x1
	char bAutoWeld : 1; // Offset: 0xc | Size: 0x1
	char bStartAwake : 1; // Offset: 0xd | Size: 0x1
	char bGenerateWakeEvents : 1; // Offset: 0xd | Size: 0x1
	char bUpdateMassWhenScaleChanges : 1; // Offset: 0xd | Size: 0x1
	char bLockTranslation : 1; // Offset: 0xd | Size: 0x1
	char bLockRotation : 1; // Offset: 0xd | Size: 0x1
	char bLockXTranslation : 1; // Offset: 0xd | Size: 0x1
	char bLockYTranslation : 1; // Offset: 0xd | Size: 0x1
	char bLockZTranslation : 1; // Offset: 0xd | Size: 0x1
	char bLockXRotation : 1; // Offset: 0xe | Size: 0x1
	char bLockYRotation : 1; // Offset: 0xe | Size: 0x1
	char bLockZRotation : 1; // Offset: 0xe | Size: 0x1
	char bOverrideMaxAngularVelocity : 1; // Offset: 0xe | Size: 0x1
	char pad_0xE_4 : 2; // Offset: 0xe | Size: 0x1
	char bOverrideMaxDepenetrationVelocity : 1; // Offset: 0xe | Size: 0x1
	char bOverrideWalkableSlopeOnInstance : 1; // Offset: 0xe | Size: 0x1
	char bInterpolateWhenSubStepping : 1; // Offset: 0xf | Size: 0x1
	char pad_0xF_1 : 7; // Offset: 0xf | Size: 0x1
	char pad_0x10[0xc]; // Offset: 0x10 | Size: 0xc
	struct FName CollisionProfileName; // Offset: 0x1c | Size: 0x8
	char PositionSolverIterationCount; // Offset: 0x24 | Size: 0x1
	char VelocitySolverIterationCount; // Offset: 0x25 | Size: 0x1
	char pad_0x26[0x2]; // Offset: 0x26 | Size: 0x2
	struct FCollisionResponse CollisionResponses; // Offset: 0x28 | Size: 0x30
	float MaxDepenetrationVelocity; // Offset: 0x58 | Size: 0x4
	float MassInKgOverride; // Offset: 0x5c | Size: 0x4
	char pad_0x60[0x8]; // Offset: 0x60 | Size: 0x8
	float LinearDamping; // Offset: 0x68 | Size: 0x4
	float AngularDamping; // Offset: 0x6c | Size: 0x4
	struct FVector CustomDOFPlaneNormal; // Offset: 0x70 | Size: 0xc
	struct FVector COMNudge; // Offset: 0x7c | Size: 0xc
	float MassScale; // Offset: 0x88 | Size: 0x4
	struct FVector InertiaTensorScale; // Offset: 0x8c | Size: 0xc
	char pad_0x98[0x10]; // Offset: 0x98 | Size: 0x10
	struct FWalkableSlopeOverride WalkableSlopeOverride; // Offset: 0xa8 | Size: 0x10
	struct UPhysicalMaterial* PhysMaterialOverride; // Offset: 0xb8 | Size: 0x8
	float MaxAngularVelocity; // Offset: 0xc0 | Size: 0x4
	float CustomSleepThresholdMultiplier; // Offset: 0xc4 | Size: 0x4
	float StabilizationThresholdMultiplier; // Offset: 0xc8 | Size: 0x4
	float PhysicsBlendWeight; // Offset: 0xcc | Size: 0x4
	char pad_0xD0[0x60]; // Offset: 0xd0 | Size: 0x60
};

// Object: ScriptStruct Engine.CollisionResponse
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FCollisionResponse {
	// Fields
	struct FCollisionResponseContainer ResponseToChannels; // Offset: 0x0 | Size: 0x20
	struct TArray<struct FResponseChannel> ResponseArray; // Offset: 0x20 | Size: 0x10
};

// Object: ScriptStruct Engine.ResponseChannel
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FResponseChannel {
	// Fields
	struct FName Channel; // Offset: 0x0 | Size: 0x8
	enum class ECollisionResponse Response; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x3]; // Offset: 0x9 | Size: 0x3
};

// Object: ScriptStruct Engine.CollisionResponseContainer
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FCollisionResponseContainer {
	// Fields
	enum class ECollisionResponse WorldStatic; // Offset: 0x0 | Size: 0x1
	enum class ECollisionResponse WorldDynamic; // Offset: 0x1 | Size: 0x1
	enum class ECollisionResponse Pawn; // Offset: 0x2 | Size: 0x1
	enum class ECollisionResponse Visibility; // Offset: 0x3 | Size: 0x1
	enum class ECollisionResponse Camera; // Offset: 0x4 | Size: 0x1
	enum class ECollisionResponse PhysicsBody; // Offset: 0x5 | Size: 0x1
	enum class ECollisionResponse Vehicle; // Offset: 0x6 | Size: 0x1
	enum class ECollisionResponse Destructible; // Offset: 0x7 | Size: 0x1
	enum class ECollisionResponse EngineTraceChannel1; // Offset: 0x8 | Size: 0x1
	enum class ECollisionResponse EngineTraceChannel2; // Offset: 0x9 | Size: 0x1
	enum class ECollisionResponse EngineTraceChannel3; // Offset: 0xa | Size: 0x1
	enum class ECollisionResponse EngineTraceChannel4; // Offset: 0xb | Size: 0x1
	enum class ECollisionResponse EngineTraceChannel5; // Offset: 0xc | Size: 0x1
	enum class ECollisionResponse EngineTraceChannel6; // Offset: 0xd | Size: 0x1
	enum class ECollisionResponse GameTraceChannel1; // Offset: 0xe | Size: 0x1
	enum class ECollisionResponse GameTraceChannel2; // Offset: 0xf | Size: 0x1
	enum class ECollisionResponse GameTraceChannel3; // Offset: 0x10 | Size: 0x1
	enum class ECollisionResponse GameTraceChannel4; // Offset: 0x11 | Size: 0x1
	enum class ECollisionResponse GameTraceChannel5; // Offset: 0x12 | Size: 0x1
	enum class ECollisionResponse GameTraceChannel6; // Offset: 0x13 | Size: 0x1
	enum class ECollisionResponse GameTraceChannel7; // Offset: 0x14 | Size: 0x1
	enum class ECollisionResponse GameTraceChannel8; // Offset: 0x15 | Size: 0x1
	enum class ECollisionResponse GameTraceChannel9; // Offset: 0x16 | Size: 0x1
	enum class ECollisionResponse GameTraceChannel10; // Offset: 0x17 | Size: 0x1
	enum class ECollisionResponse GameTraceChannel11; // Offset: 0x18 | Size: 0x1
	enum class ECollisionResponse GameTraceChannel12; // Offset: 0x19 | Size: 0x1
	enum class ECollisionResponse GameTraceChannel13; // Offset: 0x1a | Size: 0x1
	enum class ECollisionResponse GameTraceChannel14; // Offset: 0x1b | Size: 0x1
	enum class ECollisionResponse GameTraceChannel15; // Offset: 0x1c | Size: 0x1
	enum class ECollisionResponse GameTraceChannel16; // Offset: 0x1d | Size: 0x1
	enum class ECollisionResponse GameTraceChannel17; // Offset: 0x1e | Size: 0x1
	enum class ECollisionResponse GameTraceChannel18; // Offset: 0x1f | Size: 0x1
};

// Object: ScriptStruct Engine.CustomPrimitiveData
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FCustomPrimitiveData {
	// Fields
	struct TArray<float> Data; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Engine.LightingChannels
// Inherited Bytes: 0x0 | Struct Size: 0x1
struct FLightingChannels {
	// Fields
	char bChannel0 : 1; // Offset: 0x0 | Size: 0x1
	char bChannel1 : 1; // Offset: 0x0 | Size: 0x1
	char bChannel2 : 1; // Offset: 0x0 | Size: 0x1
	char pad_0x0_3 : 5; // Offset: 0x0 | Size: 0x1
};

// Object: ScriptStruct Engine.MultipassAttribute
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FMultipassAttribute {
	// Fields
	struct UMaterialInterface* MultipassMaterial; // Offset: 0x0 | Size: 0x8
	bool bUseIndependentAttribute; // Offset: 0x8 | Size: 0x1
	bool bForceFrontFaceCull; // Offset: 0x9 | Size: 0x1
	bool bIgnoreTranslucentSection; // Offset: 0xa | Size: 0x1
	bool bIgnoreMaskedSection; // Offset: 0xb | Size: 0x1
	int32_t MultiplePassTranslucencySortPriority; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct Engine.TableRowBase
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FTableRowBase {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
};

// Object: ScriptStruct Engine.ActorComponentInstanceData
// Inherited Bytes: 0x0 | Struct Size: 0x58
struct FActorComponentInstanceData {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
	struct UObject* SourceComponentTemplate; // Offset: 0x8 | Size: 0x8
	enum class EComponentCreationMethod SourceComponentCreationMethod; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x3]; // Offset: 0x11 | Size: 0x3
	int32_t SourceComponentTypeSerializedIndex; // Offset: 0x14 | Size: 0x4
	struct TArray<char> SavedProperties; // Offset: 0x18 | Size: 0x10
	struct TArray<struct FActorComponentDuplicatedObjectData> DuplicatedObjects; // Offset: 0x28 | Size: 0x10
	struct TArray<struct UObject*> ReferencedObjects; // Offset: 0x38 | Size: 0x10
	struct TArray<struct FName> ReferencedNames; // Offset: 0x48 | Size: 0x10
};

// Object: ScriptStruct Engine.ActorComponentDuplicatedObjectData
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FActorComponentDuplicatedObjectData {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Engine.AnimNode_Base
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FAnimNode_Base {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Engine.AnimNode_CustomProperty
// Inherited Bytes: 0x10 | Struct Size: 0x58
struct FAnimNode_CustomProperty : FAnimNode_Base {
	// Fields
	struct TArray<struct FName> SourcePropertyNames; // Offset: 0x10 | Size: 0x10
	struct TArray<struct FName> DestPropertyNames; // Offset: 0x20 | Size: 0x10
	struct UObject* TargetInstance; // Offset: 0x30 | Size: 0x8
	char pad_0x38[0x20]; // Offset: 0x38 | Size: 0x20
};

// Object: ScriptStruct Engine.PoseLinkBase
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FPoseLinkBase {
	// Fields
	int32_t LinkID; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0xc]; // Offset: 0x4 | Size: 0xc
};

// Object: ScriptStruct Engine.PoseLink
// Inherited Bytes: 0x10 | Struct Size: 0x10
struct FPoseLink : FPoseLinkBase {
};

// Object: ScriptStruct Engine.InputScaleBiasClamp
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FInputScaleBiasClamp {
	// Fields
	bool bMapRange; // Offset: 0x0 | Size: 0x1
	bool bClampResult; // Offset: 0x1 | Size: 0x1
	bool bInterpResult; // Offset: 0x2 | Size: 0x1
	char pad_0x3[0x1]; // Offset: 0x3 | Size: 0x1
	struct FInputRange InRange; // Offset: 0x4 | Size: 0x8
	struct FInputRange OutRange; // Offset: 0xc | Size: 0x8
	float Scale; // Offset: 0x14 | Size: 0x4
	float Bias; // Offset: 0x18 | Size: 0x4
	float ClampMin; // Offset: 0x1c | Size: 0x4
	float ClampMax; // Offset: 0x20 | Size: 0x4
	float InterpSpeedIncreasing; // Offset: 0x24 | Size: 0x4
	float InterpSpeedDecreasing; // Offset: 0x28 | Size: 0x4
	char pad_0x2C[0x4]; // Offset: 0x2c | Size: 0x4
};

// Object: ScriptStruct Engine.InputRange
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FInputRange {
	// Fields
	float Min; // Offset: 0x0 | Size: 0x4
	float Max; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct Engine.InputAlphaBoolBlend
// Inherited Bytes: 0x0 | Struct Size: 0x48
struct FInputAlphaBoolBlend {
	// Fields
	float BlendInTime; // Offset: 0x0 | Size: 0x4
	float BlendOutTime; // Offset: 0x4 | Size: 0x4
	enum class EAlphaBlendOption BlendOption; // Offset: 0x8 | Size: 0x1
	bool bInitialized; // Offset: 0x9 | Size: 0x1
	char pad_0xA[0x6]; // Offset: 0xa | Size: 0x6
	struct UCurveFloat* CustomCurve; // Offset: 0x10 | Size: 0x8
	struct FAlphaBlend AlphaBlend; // Offset: 0x18 | Size: 0x30
};

// Object: ScriptStruct Engine.AlphaBlend
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FAlphaBlend {
	// Fields
	struct UCurveFloat* CustomCurve; // Offset: 0x0 | Size: 0x8
	float BlendTime; // Offset: 0x8 | Size: 0x4
	char pad_0xC[0x18]; // Offset: 0xc | Size: 0x18
	enum class EAlphaBlendOption BlendOption; // Offset: 0x24 | Size: 0x1
	char pad_0x25[0xb]; // Offset: 0x25 | Size: 0xb
};

// Object: ScriptStruct Engine.InputScaleBias
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FInputScaleBias {
	// Fields
	float Scale; // Offset: 0x0 | Size: 0x4
	float Bias; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct Engine.AnimInstanceProxy
// Inherited Bytes: 0x0 | Struct Size: 0x6e0
struct FAnimInstanceProxy {
	// Fields
	char pad_0x0[0x6e0]; // Offset: 0x0 | Size: 0x6e0
};

// Object: ScriptStruct Engine.KeyHandleLookupTable
// Inherited Bytes: 0x0 | Struct Size: 0x60
struct FKeyHandleLookupTable {
	// Fields
	char pad_0x0[0x60]; // Offset: 0x0 | Size: 0x60
};

// Object: ScriptStruct Engine.InputBlendPose
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FInputBlendPose {
	// Fields
	struct TArray<struct FBranchFilter> BranchFilters; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Engine.BranchFilter
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FBranchFilter {
	// Fields
	struct FName BoneName; // Offset: 0x0 | Size: 0x8
	int32_t BlendDepth; // Offset: 0x8 | Size: 0x4
};

// Object: ScriptStruct Engine.ComponentSpacePoseLink
// Inherited Bytes: 0x10 | Struct Size: 0x10
struct FComponentSpacePoseLink : FPoseLinkBase {
};

// Object: ScriptStruct Engine.BoneReference
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FBoneReference {
	// Fields
	struct FName BoneName; // Offset: 0x0 | Size: 0x8
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
};

// Object: ScriptStruct Engine.FilePath
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FFilePath {
	// Fields
	struct FString FilePath; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Engine.DirectoryPath
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FDirectoryPath {
	// Fields
	struct FString Path; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Engine.PerPlatformFloat
// Inherited Bytes: 0x0 | Struct Size: 0x4
struct FPerPlatformFloat {
	// Fields
	float Default; // Offset: 0x0 | Size: 0x4
};

// Object: ScriptStruct Engine.PerPlatformInt
// Inherited Bytes: 0x0 | Struct Size: 0x4
struct FPerPlatformInt {
	// Fields
	int32_t Default; // Offset: 0x0 | Size: 0x4
};

// Object: ScriptStruct Engine.PerPlatformBool
// Inherited Bytes: 0x0 | Struct Size: 0x1
struct FPerPlatformBool {
	// Fields
	bool Default; // Offset: 0x0 | Size: 0x1
};

// Object: ScriptStruct Engine.RuntimeCurveLinearColor
// Inherited Bytes: 0x0 | Struct Size: 0x208
struct FRuntimeCurveLinearColor {
	// Fields
	struct FRichCurve ColorCurves[0x4]; // Offset: 0x0 | Size: 0x200
	struct UCurveLinearColor* ExternalCurve; // Offset: 0x200 | Size: 0x8
};

// Object: ScriptStruct Engine.MinimalViewInfo
// Inherited Bytes: 0x0 | Struct Size: 0x660
struct FMinimalViewInfo {
	// Fields
	struct FVector Location; // Offset: 0x0 | Size: 0xc
	struct FRotator Rotation; // Offset: 0xc | Size: 0xc
	float FOV; // Offset: 0x18 | Size: 0x4
	float DesiredFOV; // Offset: 0x1c | Size: 0x4
	float OrthoWidth; // Offset: 0x20 | Size: 0x4
	float OrthoNearClipPlane; // Offset: 0x24 | Size: 0x4
	float OrthoFarClipPlane; // Offset: 0x28 | Size: 0x4
	float AspectRatio; // Offset: 0x2c | Size: 0x4
	char bConstrainAspectRatio : 1; // Offset: 0x30 | Size: 0x1
	char bUseFieldOfViewForLOD : 1; // Offset: 0x30 | Size: 0x1
	char pad_0x30_2 : 6; // Offset: 0x30 | Size: 0x1
	enum class ECameraProjectionMode ProjectionMode; // Offset: 0x31 | Size: 0x1
	char pad_0x32[0x2]; // Offset: 0x32 | Size: 0x2
	float PostProcessBlendWeight; // Offset: 0x34 | Size: 0x4
	char pad_0x38[0x8]; // Offset: 0x38 | Size: 0x8
	struct FPostProcessSettings PostProcessSettings; // Offset: 0x40 | Size: 0x5d0
	struct FVector2D OffCenterProjectionOffset; // Offset: 0x610 | Size: 0x8
	char pad_0x618[0x48]; // Offset: 0x618 | Size: 0x48
};

// Object: ScriptStruct Engine.PostProcessSettings
// Inherited Bytes: 0x0 | Struct Size: 0x5d0
struct FPostProcessSettings {
	// Fields
	char bOverride_LDRSaturation : 1; // Offset: 0x0 | Size: 0x1
	char bOverride_LDRContrast : 1; // Offset: 0x0 | Size: 0x1
	char bOverride_LDRBrightness : 1; // Offset: 0x0 | Size: 0x1
	char bOverride_NightfellOpacity : 1; // Offset: 0x0 | Size: 0x1
	char bOverride_NightfellFadeness : 1; // Offset: 0x0 | Size: 0x1
	char bOverride_NightfellRadius : 1; // Offset: 0x0 | Size: 0x1
	char bOverride_NightfellSecondRadius : 1; // Offset: 0x0 | Size: 0x1
	char bOverride_NightfellLocation : 1; // Offset: 0x0 | Size: 0x1
	char bOverride_NightfellSecondLocation : 1; // Offset: 0x1 | Size: 0x1
	char bOverride_PCBloomIntensity : 1; // Offset: 0x1 | Size: 0x1
	char bOverride_PCBloomThreshold : 1; // Offset: 0x1 | Size: 0x1
	char bOverride_WhiteTemp : 1; // Offset: 0x1 | Size: 0x1
	char bOverride_WhiteTint : 1; // Offset: 0x1 | Size: 0x1
	char bOverride_ColorSaturation : 1; // Offset: 0x1 | Size: 0x1
	char bOverride_ColorContrast : 1; // Offset: 0x1 | Size: 0x1
	char bOverride_ColorGamma : 1; // Offset: 0x1 | Size: 0x1
	char bOverride_ColorGain : 1; // Offset: 0x2 | Size: 0x1
	char bOverride_ColorOffset : 1; // Offset: 0x2 | Size: 0x1
	char bOverride_ColorSaturationShadows : 1; // Offset: 0x2 | Size: 0x1
	char bOverride_ColorContrastShadows : 1; // Offset: 0x2 | Size: 0x1
	char bOverride_ColorGammaShadows : 1; // Offset: 0x2 | Size: 0x1
	char bOverride_ColorGainShadows : 1; // Offset: 0x2 | Size: 0x1
	char bOverride_ColorOffsetShadows : 1; // Offset: 0x2 | Size: 0x1
	char bOverride_ColorSaturationMidtones : 1; // Offset: 0x2 | Size: 0x1
	char bOverride_ColorContrastMidtones : 1; // Offset: 0x3 | Size: 0x1
	char bOverride_ColorGammaMidtones : 1; // Offset: 0x3 | Size: 0x1
	char bOverride_ColorGainMidtones : 1; // Offset: 0x3 | Size: 0x1
	char bOverride_ColorOffsetMidtones : 1; // Offset: 0x3 | Size: 0x1
	char bOverride_ColorSaturationHighlights : 1; // Offset: 0x3 | Size: 0x1
	char bOverride_ColorContrastHighlights : 1; // Offset: 0x3 | Size: 0x1
	char bOverride_ColorGammaHighlights : 1; // Offset: 0x3 | Size: 0x1
	char bOverride_ColorGainHighlights : 1; // Offset: 0x3 | Size: 0x1
	char bOverride_ColorOffsetHighlights : 1; // Offset: 0x4 | Size: 0x1
	char bOverride_ColorCorrectionShadowsMax : 1; // Offset: 0x4 | Size: 0x1
	char bOverride_ColorCorrectionHighlightsMin : 1; // Offset: 0x4 | Size: 0x1
	char bOverride_BlueCorrection : 1; // Offset: 0x4 | Size: 0x1
	char bOverride_ExpandGamut : 1; // Offset: 0x4 | Size: 0x1
	char bOverride_FilmWhitePoint : 1; // Offset: 0x4 | Size: 0x1
	char bOverride_FilmSaturation : 1; // Offset: 0x4 | Size: 0x1
	char bOverride_FilmChannelMixerRed : 1; // Offset: 0x4 | Size: 0x1
	char bOverride_FilmChannelMixerGreen : 1; // Offset: 0x5 | Size: 0x1
	char bOverride_FilmChannelMixerBlue : 1; // Offset: 0x5 | Size: 0x1
	char bOverride_FilmContrast : 1; // Offset: 0x5 | Size: 0x1
	char bOverride_FilmDynamicRange : 1; // Offset: 0x5 | Size: 0x1
	char bOverride_FilmHealAmount : 1; // Offset: 0x5 | Size: 0x1
	char bOverride_FilmToeAmount : 1; // Offset: 0x5 | Size: 0x1
	char bOverride_FilmShadowTint : 1; // Offset: 0x5 | Size: 0x1
	char bOverride_FilmShadowTintBlend : 1; // Offset: 0x5 | Size: 0x1
	char bOverride_FilmShadowTintAmount : 1; // Offset: 0x6 | Size: 0x1
	char bOverride_FilmSlope : 1; // Offset: 0x6 | Size: 0x1
	char bOverride_FilmToe : 1; // Offset: 0x6 | Size: 0x1
	char bOverride_FilmShoulder : 1; // Offset: 0x6 | Size: 0x1
	char bOverride_FilmBlackClip : 1; // Offset: 0x6 | Size: 0x1
	char bOverride_FilmWhiteClip : 1; // Offset: 0x6 | Size: 0x1
	char bOverride_SceneColorTint : 1; // Offset: 0x6 | Size: 0x1
	char bOverride_SceneFringeIntensity : 1; // Offset: 0x6 | Size: 0x1
	char bOverride_ChromaticAberrationStartOffset : 1; // Offset: 0x7 | Size: 0x1
	char bOverride_AmbientCubemapTint : 1; // Offset: 0x7 | Size: 0x1
	char bOverride_AmbientCubemapIntensity : 1; // Offset: 0x7 | Size: 0x1
	char bOverride_BloomMethod : 1; // Offset: 0x7 | Size: 0x1
	char bOverride_BloomIntensity : 1; // Offset: 0x7 | Size: 0x1
	char bOverride_BloomThreshold : 1; // Offset: 0x7 | Size: 0x1
	char bOverride_Bloom1Tint : 1; // Offset: 0x7 | Size: 0x1
	char bOverride_Bloom1Size : 1; // Offset: 0x7 | Size: 0x1
	char bOverride_Bloom2Size : 1; // Offset: 0x8 | Size: 0x1
	char bOverride_Bloom2Tint : 1; // Offset: 0x8 | Size: 0x1
	char bOverride_Bloom3Tint : 1; // Offset: 0x8 | Size: 0x1
	char bOverride_Bloom3Size : 1; // Offset: 0x8 | Size: 0x1
	char bOverride_Bloom4Tint : 1; // Offset: 0x8 | Size: 0x1
	char bOverride_Bloom4Size : 1; // Offset: 0x8 | Size: 0x1
	char bOverride_Bloom5Tint : 1; // Offset: 0x8 | Size: 0x1
	char bOverride_Bloom5Size : 1; // Offset: 0x8 | Size: 0x1
	char bOverride_Bloom6Tint : 1; // Offset: 0x9 | Size: 0x1
	char bOverride_Bloom6Size : 1; // Offset: 0x9 | Size: 0x1
	char bOverride_BloomSizeScale : 1; // Offset: 0x9 | Size: 0x1
	char bOverride_BloomConvolutionTexture : 1; // Offset: 0x9 | Size: 0x1
	char bOverride_BloomConvolutionSize : 1; // Offset: 0x9 | Size: 0x1
	char bOverride_BloomConvolutionCenterUV : 1; // Offset: 0x9 | Size: 0x1
	char bOverride_BloomConvolutionPreFilter : 1; // Offset: 0x9 | Size: 0x1
	char bOverride_BloomConvolutionPreFilterMin : 1; // Offset: 0x9 | Size: 0x1
	char bOverride_BloomConvolutionPreFilterMax : 1; // Offset: 0xa | Size: 0x1
	char bOverride_BloomConvolutionPreFilterMult : 1; // Offset: 0xa | Size: 0x1
	char bOverride_BloomConvolutionBufferScale : 1; // Offset: 0xa | Size: 0x1
	char bOverride_BloomDirtMaskIntensity : 1; // Offset: 0xa | Size: 0x1
	char bOverride_BloomDirtMaskTint : 1; // Offset: 0xa | Size: 0x1
	char bOverride_BloomDirtMask : 1; // Offset: 0xa | Size: 0x1
	char bOverride_CameraShutterSpeed : 1; // Offset: 0xa | Size: 0x1
	char bOverride_CameraISO : 1; // Offset: 0xa | Size: 0x1
	char bOverride_AutoExposureMethod : 1; // Offset: 0xb | Size: 0x1
	char bOverride_AutoExposureLowPercent : 1; // Offset: 0xb | Size: 0x1
	char bOverride_AutoExposureHighPercent : 1; // Offset: 0xb | Size: 0x1
	char bOverride_AutoExposureMinBrightness : 1; // Offset: 0xb | Size: 0x1
	char bOverride_AutoExposureMaxBrightness : 1; // Offset: 0xb | Size: 0x1
	char bOverride_AutoExposureCalibrationConstant : 1; // Offset: 0xb | Size: 0x1
	char bOverride_AutoExposureSpeedUp : 1; // Offset: 0xb | Size: 0x1
	char bOverride_AutoExposureSpeedDown : 1; // Offset: 0xb | Size: 0x1
	char bOverride_AutoExposureBias : 1; // Offset: 0xc | Size: 0x1
	char bOverride_AutoExposureBiasCurve : 1; // Offset: 0xc | Size: 0x1
	char bOverride_AutoExposureMeterMask : 1; // Offset: 0xc | Size: 0x1
	char bOverride_AutoExposureApplyPhysicalCameraExposure : 1; // Offset: 0xc | Size: 0x1
	char bOverride_HistogramLogMin : 1; // Offset: 0xc | Size: 0x1
	char bOverride_HistogramLogMax : 1; // Offset: 0xc | Size: 0x1
	char bOverride_LensFlareIntensity : 1; // Offset: 0xc | Size: 0x1
	char bOverride_LensFlareTint : 1; // Offset: 0xc | Size: 0x1
	char bOverride_LensFlareTints : 1; // Offset: 0xd | Size: 0x1
	char bOverride_LensFlareBokehSize : 1; // Offset: 0xd | Size: 0x1
	char bOverride_LensFlareBokehShape : 1; // Offset: 0xd | Size: 0x1
	char bOverride_LensFlareThreshold : 1; // Offset: 0xd | Size: 0x1
	char bOverride_VignetteIntensity : 1; // Offset: 0xd | Size: 0x1
	char bOverride_GrainIntensity : 1; // Offset: 0xd | Size: 0x1
	char bOverride_GrainJitter : 1; // Offset: 0xd | Size: 0x1
	char bOverride_AmbientOcclusionIntensity : 1; // Offset: 0xd | Size: 0x1
	char bOverride_AmbientOcclusionStaticFraction : 1; // Offset: 0xe | Size: 0x1
	char bOverride_AmbientOcclusionRadius : 1; // Offset: 0xe | Size: 0x1
	char bOverride_AmbientOcclusionFadeDistance : 1; // Offset: 0xe | Size: 0x1
	char bOverride_AmbientOcclusionFadeRadius : 1; // Offset: 0xe | Size: 0x1
	char bOverride_AmbientOcclusionDistance : 1; // Offset: 0xe | Size: 0x1
	char bOverride_AmbientOcclusionRadiusInWS : 1; // Offset: 0xe | Size: 0x1
	char bOverride_AmbientOcclusionPower : 1; // Offset: 0xe | Size: 0x1
	char bOverride_AmbientOcclusionBias : 1; // Offset: 0xe | Size: 0x1
	char bOverride_AmbientOcclusionQuality : 1; // Offset: 0xf | Size: 0x1
	char bOverride_AmbientOcclusionMipBlend : 1; // Offset: 0xf | Size: 0x1
	char bOverride_AmbientOcclusionMipScale : 1; // Offset: 0xf | Size: 0x1
	char bOverride_AmbientOcclusionMipThreshold : 1; // Offset: 0xf | Size: 0x1
	char bOverride_RayTracingAO : 1; // Offset: 0xf | Size: 0x1
	char bOverride_RayTracingAOSamplesPerPixel : 1; // Offset: 0xf | Size: 0x1
	char bOverride_LPVIntensity : 1; // Offset: 0xf | Size: 0x1
	char bOverride_LPVDirectionalOcclusionIntensity : 1; // Offset: 0xf | Size: 0x1
	char bOverride_LPVDirectionalOcclusionRadius : 1; // Offset: 0x10 | Size: 0x1
	char bOverride_LPVDiffuseOcclusionExponent : 1; // Offset: 0x10 | Size: 0x1
	char bOverride_LPVSpecularOcclusionExponent : 1; // Offset: 0x10 | Size: 0x1
	char bOverride_LPVDiffuseOcclusionIntensity : 1; // Offset: 0x10 | Size: 0x1
	char bOverride_LPVSpecularOcclusionIntensity : 1; // Offset: 0x10 | Size: 0x1
	char bOverride_LPVSize : 1; // Offset: 0x10 | Size: 0x1
	char bOverride_LPVSecondaryOcclusionIntensity : 1; // Offset: 0x10 | Size: 0x1
	char bOverride_LPVSecondaryBounceIntensity : 1; // Offset: 0x10 | Size: 0x1
	char bOverride_LPVGeometryVolumeBias : 1; // Offset: 0x11 | Size: 0x1
	char bOverride_LPVVplInjectionBias : 1; // Offset: 0x11 | Size: 0x1
	char bOverride_LPVEmissiveInjectionIntensity : 1; // Offset: 0x11 | Size: 0x1
	char bOverride_LPVFadeRange : 1; // Offset: 0x11 | Size: 0x1
	char bOverride_LPVDirectionalOcclusionFadeRange : 1; // Offset: 0x11 | Size: 0x1
	char bOverride_IndirectLightingColor : 1; // Offset: 0x11 | Size: 0x1
	char bOverride_IndirectLightingIntensity : 1; // Offset: 0x11 | Size: 0x1
	char bOverride_ColorGradingIntensity : 1; // Offset: 0x11 | Size: 0x1
	char bOverride_ColorGradingLUT : 1; // Offset: 0x12 | Size: 0x1
	char bOverride_DepthOfFieldFocalDistance : 1; // Offset: 0x12 | Size: 0x1
	char bOverride_DepthOfFieldFstop : 1; // Offset: 0x12 | Size: 0x1
	char bOverride_DepthOfFieldMinFstop : 1; // Offset: 0x12 | Size: 0x1
	char bOverride_DepthOfFieldBladeCount : 1; // Offset: 0x12 | Size: 0x1
	char bOverride_DepthOfFieldSensorWidth : 1; // Offset: 0x12 | Size: 0x1
	char bOverride_DepthOfFieldDepthBlurRadius : 1; // Offset: 0x12 | Size: 0x1
	char bOverride_DepthOfFieldDepthBlurAmount : 1; // Offset: 0x12 | Size: 0x1
	char bOverride_DepthOfFieldFocalRegion : 1; // Offset: 0x13 | Size: 0x1
	char bOverride_DepthOfFieldNearTransitionRegion : 1; // Offset: 0x13 | Size: 0x1
	char bOverride_DepthOfFieldFarTransitionRegion : 1; // Offset: 0x13 | Size: 0x1
	char bOverride_DepthOfFieldScale : 1; // Offset: 0x13 | Size: 0x1
	char bOverride_DepthOfFieldNearBlurSize : 1; // Offset: 0x13 | Size: 0x1
	char bOverride_DepthOfFieldFarBlurSize : 1; // Offset: 0x13 | Size: 0x1
	char bOverride_MobileHQGaussian : 1; // Offset: 0x13 | Size: 0x1
	char bOverride_DepthOfFieldOcclusion : 1; // Offset: 0x13 | Size: 0x1
	char bOverride_DepthOfFieldSkyFocusDistance : 1; // Offset: 0x14 | Size: 0x1
	char bOverride_DepthOfFieldVignetteSize : 1; // Offset: 0x14 | Size: 0x1
	char bOverride_MotionBlurAmount : 1; // Offset: 0x14 | Size: 0x1
	char bOverride_MotionBlurMax : 1; // Offset: 0x14 | Size: 0x1
	char bOverride_MotionBlurTargetFPS : 1; // Offset: 0x14 | Size: 0x1
	char bOverride_MotionBlurPerObjectSize : 1; // Offset: 0x14 | Size: 0x1
	char bOverride_ScreenPercentage : 1; // Offset: 0x14 | Size: 0x1
	char bOverride_ScreenSpaceReflectionIntensity : 1; // Offset: 0x14 | Size: 0x1
	char bOverride_ScreenSpaceReflectionQuality : 1; // Offset: 0x15 | Size: 0x1
	char bOverride_ScreenSpaceReflectionMaxRoughness : 1; // Offset: 0x15 | Size: 0x1
	char bOverride_ScreenSpaceReflectionRoughnessScale : 1; // Offset: 0x15 | Size: 0x1
	char bOverride_ReflectionsType : 1; // Offset: 0x15 | Size: 0x1
	char bOverride_RayTracingReflectionsMaxRoughness : 1; // Offset: 0x15 | Size: 0x1
	char bOverride_RayTracingReflectionsMaxBounces : 1; // Offset: 0x15 | Size: 0x1
	char bOverride_RayTracingReflectionsSamplesPerPixel : 1; // Offset: 0x15 | Size: 0x1
	char bOverride_RayTracingReflectionsShadows : 1; // Offset: 0x15 | Size: 0x1
	char bOverride_RayTracingReflectionsTranslucency : 1; // Offset: 0x16 | Size: 0x1
	char bOverride_TranslucencyType : 1; // Offset: 0x16 | Size: 0x1
	char bOverride_RayTracingTranslucencyMaxRoughness : 1; // Offset: 0x16 | Size: 0x1
	char bOverride_RayTracingTranslucencyRefractionRays : 1; // Offset: 0x16 | Size: 0x1
	char bOverride_RayTracingTranslucencySamplesPerPixel : 1; // Offset: 0x16 | Size: 0x1
	char bOverride_RayTracingTranslucencyShadows : 1; // Offset: 0x16 | Size: 0x1
	char bOverride_RayTracingTranslucencyRefraction : 1; // Offset: 0x16 | Size: 0x1
	char bOverride_RayTracingGI : 1; // Offset: 0x16 | Size: 0x1
	char bOverride_RayTracingGIMaxBounces : 1; // Offset: 0x17 | Size: 0x1
	char bOverride_RayTracingGISamplesPerPixel : 1; // Offset: 0x17 | Size: 0x1
	char bOverride_PathTracingMaxBounces : 1; // Offset: 0x17 | Size: 0x1
	char bOverride_PathTracingSamplesPerPixel : 1; // Offset: 0x17 | Size: 0x1
	char bMobileHQGaussian : 1; // Offset: 0x17 | Size: 0x1
	char pad_0x17_5 : 3; // Offset: 0x17 | Size: 0x1
	enum class EBloomMethod BloomMethod; // Offset: 0x18 | Size: 0x1
	enum class EAutoExposureMethod AutoExposureMethod; // Offset: 0x19 | Size: 0x1
	char pad_0x1A[0x2]; // Offset: 0x1a | Size: 0x2
	float WhiteTemp; // Offset: 0x1c | Size: 0x4
	float WhiteTint; // Offset: 0x20 | Size: 0x4
	char pad_0x24[0xc]; // Offset: 0x24 | Size: 0xc
	struct FVector4 LDRSaturation; // Offset: 0x30 | Size: 0x10
	struct FVector4 LDRContrast; // Offset: 0x40 | Size: 0x10
	struct FVector4 LDRBrightness; // Offset: 0x50 | Size: 0x10
	float NightfellRadius; // Offset: 0x60 | Size: 0x4
	float NightfellSecondRadius; // Offset: 0x64 | Size: 0x4
	float NightfellOpacity; // Offset: 0x68 | Size: 0x4
	float NightfellFadeness; // Offset: 0x6c | Size: 0x4
	struct FVector4 NightfellLocation; // Offset: 0x70 | Size: 0x10
	struct FVector4 NightfellSecondLocation; // Offset: 0x80 | Size: 0x10
	float PCBloomIntensity; // Offset: 0x90 | Size: 0x4
	float PCBloomThreshold; // Offset: 0x94 | Size: 0x4
	char pad_0x98[0x8]; // Offset: 0x98 | Size: 0x8
	struct FVector4 ColorSaturation; // Offset: 0xa0 | Size: 0x10
	struct FVector4 ColorContrast; // Offset: 0xb0 | Size: 0x10
	struct FVector4 ColorGamma; // Offset: 0xc0 | Size: 0x10
	struct FVector4 ColorGain; // Offset: 0xd0 | Size: 0x10
	struct FVector4 ColorOffset; // Offset: 0xe0 | Size: 0x10
	char pad_0xF0[0x10]; // Offset: 0xf0 | Size: 0x10
	struct FVector4 ColorSaturationShadows; // Offset: 0x100 | Size: 0x10
	struct FVector4 ColorContrastShadows; // Offset: 0x110 | Size: 0x10
	struct FVector4 ColorGammaShadows; // Offset: 0x120 | Size: 0x10
	struct FVector4 ColorGainShadows; // Offset: 0x130 | Size: 0x10
	struct FVector4 ColorOffsetShadows; // Offset: 0x140 | Size: 0x10
	struct FVector4 ColorSaturationMidtones; // Offset: 0x150 | Size: 0x10
	struct FVector4 ColorContrastMidtones; // Offset: 0x160 | Size: 0x10
	struct FVector4 ColorGammaMidtones; // Offset: 0x170 | Size: 0x10
	struct FVector4 ColorGainMidtones; // Offset: 0x180 | Size: 0x10
	struct FVector4 ColorOffsetMidtones; // Offset: 0x190 | Size: 0x10
	struct FVector4 ColorSaturationHighlights; // Offset: 0x1a0 | Size: 0x10
	struct FVector4 ColorContrastHighlights; // Offset: 0x1b0 | Size: 0x10
	struct FVector4 ColorGammaHighlights; // Offset: 0x1c0 | Size: 0x10
	struct FVector4 ColorGainHighlights; // Offset: 0x1d0 | Size: 0x10
	struct FVector4 ColorOffsetHighlights; // Offset: 0x1e0 | Size: 0x10
	float ColorCorrectionHighlightsMin; // Offset: 0x1f0 | Size: 0x4
	float ColorCorrectionShadowsMax; // Offset: 0x1f4 | Size: 0x4
	float BlueCorrection; // Offset: 0x1f8 | Size: 0x4
	float ExpandGamut; // Offset: 0x1fc | Size: 0x4
	float FilmSlope; // Offset: 0x200 | Size: 0x4
	float FilmToe; // Offset: 0x204 | Size: 0x4
	float FilmShoulder; // Offset: 0x208 | Size: 0x4
	float FilmBlackClip; // Offset: 0x20c | Size: 0x4
	float FilmWhiteClip; // Offset: 0x210 | Size: 0x4
	struct FLinearColor FilmWhitePoint; // Offset: 0x214 | Size: 0x10
	struct FLinearColor FilmShadowTint; // Offset: 0x224 | Size: 0x10
	float FilmShadowTintBlend; // Offset: 0x234 | Size: 0x4
	float FilmShadowTintAmount; // Offset: 0x238 | Size: 0x4
	float FilmSaturation; // Offset: 0x23c | Size: 0x4
	struct FLinearColor FilmChannelMixerRed; // Offset: 0x240 | Size: 0x10
	struct FLinearColor FilmChannelMixerGreen; // Offset: 0x250 | Size: 0x10
	struct FLinearColor FilmChannelMixerBlue; // Offset: 0x260 | Size: 0x10
	float FilmContrast; // Offset: 0x270 | Size: 0x4
	float FilmToeAmount; // Offset: 0x274 | Size: 0x4
	float FilmHealAmount; // Offset: 0x278 | Size: 0x4
	float FilmDynamicRange; // Offset: 0x27c | Size: 0x4
	struct FLinearColor SceneColorTint; // Offset: 0x280 | Size: 0x10
	float SceneFringeIntensity; // Offset: 0x290 | Size: 0x4
	float ChromaticAberrationStartOffset; // Offset: 0x294 | Size: 0x4
	float BloomIntensity; // Offset: 0x298 | Size: 0x4
	float BloomThreshold; // Offset: 0x29c | Size: 0x4
	float BloomSizeScale; // Offset: 0x2a0 | Size: 0x4
	float Bloom1Size; // Offset: 0x2a4 | Size: 0x4
	float Bloom2Size; // Offset: 0x2a8 | Size: 0x4
	float Bloom3Size; // Offset: 0x2ac | Size: 0x4
	float Bloom4Size; // Offset: 0x2b0 | Size: 0x4
	float Bloom5Size; // Offset: 0x2b4 | Size: 0x4
	float Bloom6Size; // Offset: 0x2b8 | Size: 0x4
	struct FLinearColor Bloom1Tint; // Offset: 0x2bc | Size: 0x10
	struct FLinearColor Bloom2Tint; // Offset: 0x2cc | Size: 0x10
	struct FLinearColor Bloom3Tint; // Offset: 0x2dc | Size: 0x10
	struct FLinearColor Bloom4Tint; // Offset: 0x2ec | Size: 0x10
	struct FLinearColor Bloom5Tint; // Offset: 0x2fc | Size: 0x10
	struct FLinearColor Bloom6Tint; // Offset: 0x30c | Size: 0x10
	float BloomConvolutionSize; // Offset: 0x31c | Size: 0x4
	struct UTexture2D* BloomConvolutionTexture; // Offset: 0x320 | Size: 0x8
	struct FVector2D BloomConvolutionCenterUV; // Offset: 0x328 | Size: 0x8
	float BloomConvolutionPreFilterMin; // Offset: 0x330 | Size: 0x4
	float BloomConvolutionPreFilterMax; // Offset: 0x334 | Size: 0x4
	float BloomConvolutionPreFilterMult; // Offset: 0x338 | Size: 0x4
	float BloomConvolutionBufferScale; // Offset: 0x33c | Size: 0x4
	struct UTexture* BloomDirtMask; // Offset: 0x340 | Size: 0x8
	float BloomDirtMaskIntensity; // Offset: 0x348 | Size: 0x4
	struct FLinearColor BloomDirtMaskTint; // Offset: 0x34c | Size: 0x10
	struct FLinearColor AmbientCubemapTint; // Offset: 0x35c | Size: 0x10
	float AmbientCubemapIntensity; // Offset: 0x36c | Size: 0x4
	struct UTextureCube* AmbientCubemap; // Offset: 0x370 | Size: 0x8
	float CameraShutterSpeed; // Offset: 0x378 | Size: 0x4
	float CameraISO; // Offset: 0x37c | Size: 0x4
	float DepthOfFieldFstop; // Offset: 0x380 | Size: 0x4
	float DepthOfFieldMinFstop; // Offset: 0x384 | Size: 0x4
	int32_t DepthOfFieldBladeCount; // Offset: 0x388 | Size: 0x4
	float AutoExposureBias; // Offset: 0x38c | Size: 0x4
	float AutoExposureBiasBackup; // Offset: 0x390 | Size: 0x4
	char bOverride_AutoExposureBiasBackup : 1; // Offset: 0x394 | Size: 0x1
	char AutoExposureApplyPhysicalCameraExposure : 1; // Offset: 0x394 | Size: 0x1
	char pad_0x394_2 : 6; // Offset: 0x394 | Size: 0x1
	char pad_0x395[0x3]; // Offset: 0x395 | Size: 0x3
	struct UCurveFloat* AutoExposureBiasCurve; // Offset: 0x398 | Size: 0x8
	struct UTexture* AutoExposureMeterMask; // Offset: 0x3a0 | Size: 0x8
	float AutoExposureLowPercent; // Offset: 0x3a8 | Size: 0x4
	float AutoExposureHighPercent; // Offset: 0x3ac | Size: 0x4
	float AutoExposureMinBrightness; // Offset: 0x3b0 | Size: 0x4
	float AutoExposureMaxBrightness; // Offset: 0x3b4 | Size: 0x4
	float AutoExposureSpeedUp; // Offset: 0x3b8 | Size: 0x4
	float AutoExposureSpeedDown; // Offset: 0x3bc | Size: 0x4
	float HistogramLogMin; // Offset: 0x3c0 | Size: 0x4
	float HistogramLogMax; // Offset: 0x3c4 | Size: 0x4
	float AutoExposureCalibrationConstant; // Offset: 0x3c8 | Size: 0x4
	float LensFlareIntensity; // Offset: 0x3cc | Size: 0x4
	struct FLinearColor LensFlareTint; // Offset: 0x3d0 | Size: 0x10
	float LensFlareBokehSize; // Offset: 0x3e0 | Size: 0x4
	float LensFlareThreshold; // Offset: 0x3e4 | Size: 0x4
	struct UTexture* LensFlareBokehShape; // Offset: 0x3e8 | Size: 0x8
	struct FLinearColor LensFlareTints[0x8]; // Offset: 0x3f0 | Size: 0x80
	float VignetteIntensity; // Offset: 0x470 | Size: 0x4
	float GrainJitter; // Offset: 0x474 | Size: 0x4
	float GrainIntensity; // Offset: 0x478 | Size: 0x4
	float AmbientOcclusionIntensity; // Offset: 0x47c | Size: 0x4
	char bOverride_SSGIAOIntensity : 1; // Offset: 0x480 | Size: 0x1
	char pad_0x480_1 : 7; // Offset: 0x480 | Size: 0x1
	char pad_0x481[0x3]; // Offset: 0x481 | Size: 0x3
	float SSGIAOIntensity; // Offset: 0x484 | Size: 0x4
	char bOverride_SSGIDiffuseIntensity : 1; // Offset: 0x488 | Size: 0x1
	char pad_0x488_1 : 7; // Offset: 0x488 | Size: 0x1
	char pad_0x489[0x3]; // Offset: 0x489 | Size: 0x3
	float SSGIDiffuseIntensity; // Offset: 0x48c | Size: 0x4
	float AmbientOcclusionStaticFraction; // Offset: 0x490 | Size: 0x4
	float AmbientOcclusionRadius; // Offset: 0x494 | Size: 0x4
	char AmbientOcclusionRadiusInWS : 1; // Offset: 0x498 | Size: 0x1
	char pad_0x498_1 : 7; // Offset: 0x498 | Size: 0x1
	char pad_0x499[0x3]; // Offset: 0x499 | Size: 0x3
	float AmbientOcclusionFadeDistance; // Offset: 0x49c | Size: 0x4
	float AmbientOcclusionFadeRadius; // Offset: 0x4a0 | Size: 0x4
	float AmbientOcclusionDistance; // Offset: 0x4a4 | Size: 0x4
	float AmbientOcclusionPower; // Offset: 0x4a8 | Size: 0x4
	float AmbientOcclusionBias; // Offset: 0x4ac | Size: 0x4
	float AmbientOcclusionQuality; // Offset: 0x4b0 | Size: 0x4
	float AmbientOcclusionMipBlend; // Offset: 0x4b4 | Size: 0x4
	float AmbientOcclusionMipScale; // Offset: 0x4b8 | Size: 0x4
	float AmbientOcclusionMipThreshold; // Offset: 0x4bc | Size: 0x4
	char RayTracingAO : 1; // Offset: 0x4c0 | Size: 0x1
	char pad_0x4C0_1 : 7; // Offset: 0x4c0 | Size: 0x1
	char pad_0x4C1[0x3]; // Offset: 0x4c1 | Size: 0x3
	int32_t RayTracingAOSamplesPerPixel; // Offset: 0x4c4 | Size: 0x4
	struct FLinearColor IndirectLightingColor; // Offset: 0x4c8 | Size: 0x10
	float IndirectLightingIntensity; // Offset: 0x4d8 | Size: 0x4
	enum class ERayTracingGlobalIlluminationType RayTracingGIType; // Offset: 0x4dc | Size: 0x1
	char pad_0x4DD[0x3]; // Offset: 0x4dd | Size: 0x3
	int32_t RayTracingGIMaxBounces; // Offset: 0x4e0 | Size: 0x4
	int32_t RayTracingGISamplesPerPixel; // Offset: 0x4e4 | Size: 0x4
	float ColorGradingIntensity; // Offset: 0x4e8 | Size: 0x4
	char pad_0x4EC[0x4]; // Offset: 0x4ec | Size: 0x4
	struct UTexture* ColorGradingLUT; // Offset: 0x4f0 | Size: 0x8
	float DepthOfFieldSensorWidth; // Offset: 0x4f8 | Size: 0x4
	float DepthOfFieldFocalDistance; // Offset: 0x4fc | Size: 0x4
	float DepthOfFieldDepthBlurAmount; // Offset: 0x500 | Size: 0x4
	float DepthOfFieldDepthBlurRadius; // Offset: 0x504 | Size: 0x4
	float DepthOfFieldFocalRegion; // Offset: 0x508 | Size: 0x4
	float DepthOfFieldNearTransitionRegion; // Offset: 0x50c | Size: 0x4
	float DepthOfFieldFarTransitionRegion; // Offset: 0x510 | Size: 0x4
	float DepthOfFieldScale; // Offset: 0x514 | Size: 0x4
	float DepthOfFieldNearBlurSize; // Offset: 0x518 | Size: 0x4
	float DepthOfFieldFarBlurSize; // Offset: 0x51c | Size: 0x4
	float DepthOfFieldOcclusion; // Offset: 0x520 | Size: 0x4
	float DepthOfFieldSkyFocusDistance; // Offset: 0x524 | Size: 0x4
	float DepthOfFieldVignetteSize; // Offset: 0x528 | Size: 0x4
	float MotionBlurAmount; // Offset: 0x52c | Size: 0x4
	float MotionBlurMax; // Offset: 0x530 | Size: 0x4
	int32_t MotionBlurTargetFPS; // Offset: 0x534 | Size: 0x4
	float MotionBlurPerObjectSize; // Offset: 0x538 | Size: 0x4
	float LPVIntensity; // Offset: 0x53c | Size: 0x4
	float LPVVplInjectionBias; // Offset: 0x540 | Size: 0x4
	float LPVSize; // Offset: 0x544 | Size: 0x4
	float LPVSecondaryOcclusionIntensity; // Offset: 0x548 | Size: 0x4
	float LPVSecondaryBounceIntensity; // Offset: 0x54c | Size: 0x4
	float LPVGeometryVolumeBias; // Offset: 0x550 | Size: 0x4
	float LPVEmissiveInjectionIntensity; // Offset: 0x554 | Size: 0x4
	float LPVDirectionalOcclusionIntensity; // Offset: 0x558 | Size: 0x4
	float LPVDirectionalOcclusionRadius; // Offset: 0x55c | Size: 0x4
	float LPVDiffuseOcclusionExponent; // Offset: 0x560 | Size: 0x4
	float LPVSpecularOcclusionExponent; // Offset: 0x564 | Size: 0x4
	float LPVDiffuseOcclusionIntensity; // Offset: 0x568 | Size: 0x4
	float LPVSpecularOcclusionIntensity; // Offset: 0x56c | Size: 0x4
	enum class EReflectionsType ReflectionsType; // Offset: 0x570 | Size: 0x1
	char pad_0x571[0x3]; // Offset: 0x571 | Size: 0x3
	float ScreenSpaceReflectionIntensity; // Offset: 0x574 | Size: 0x4
	float ScreenSpaceReflectionQuality; // Offset: 0x578 | Size: 0x4
	float ScreenSpaceReflectionMaxRoughness; // Offset: 0x57c | Size: 0x4
	float RayTracingReflectionsMaxRoughness; // Offset: 0x580 | Size: 0x4
	int32_t RayTracingReflectionsMaxBounces; // Offset: 0x584 | Size: 0x4
	int32_t RayTracingReflectionsSamplesPerPixel; // Offset: 0x588 | Size: 0x4
	enum class EReflectedAndRefractedRayTracedShadows RayTracingReflectionsShadows; // Offset: 0x58c | Size: 0x1
	char RayTracingReflectionsTranslucency : 1; // Offset: 0x58d | Size: 0x1
	char pad_0x58D_1 : 7; // Offset: 0x58d | Size: 0x1
	enum class ETranslucencyType TranslucencyType; // Offset: 0x58e | Size: 0x1
	char pad_0x58F[0x1]; // Offset: 0x58f | Size: 0x1
	float RayTracingTranslucencyMaxRoughness; // Offset: 0x590 | Size: 0x4
	int32_t RayTracingTranslucencyRefractionRays; // Offset: 0x594 | Size: 0x4
	int32_t RayTracingTranslucencySamplesPerPixel; // Offset: 0x598 | Size: 0x4
	enum class EReflectedAndRefractedRayTracedShadows RayTracingTranslucencyShadows; // Offset: 0x59c | Size: 0x1
	char RayTracingTranslucencyRefraction : 1; // Offset: 0x59d | Size: 0x1
	char pad_0x59D_1 : 7; // Offset: 0x59d | Size: 0x1
	char pad_0x59E[0x2]; // Offset: 0x59e | Size: 0x2
	int32_t PathTracingMaxBounces; // Offset: 0x5a0 | Size: 0x4
	int32_t PathTracingSamplesPerPixel; // Offset: 0x5a4 | Size: 0x4
	float PathTracingMaxPathExposure; // Offset: 0x5a8 | Size: 0x4
	char PathTracingEnableDenoiser : 1; // Offset: 0x5ac | Size: 0x1
	char PathTracingEnableEmissive : 1; // Offset: 0x5ac | Size: 0x1
	char pad_0x5AC_2 : 6; // Offset: 0x5ac | Size: 0x1
	char pad_0x5AD[0x3]; // Offset: 0x5ad | Size: 0x3
	float PathTracingFilterWidth; // Offset: 0x5b0 | Size: 0x4
	float LPVFadeRange; // Offset: 0x5b4 | Size: 0x4
	float LPVDirectionalOcclusionFadeRange; // Offset: 0x5b8 | Size: 0x4
	float ScreenPercentage; // Offset: 0x5bc | Size: 0x4
	struct FWeightedBlendables WeightedBlendables; // Offset: 0x5c0 | Size: 0x10
};

// Object: ScriptStruct Engine.WeightedBlendables
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FWeightedBlendables {
	// Fields
	struct TArray<struct FWeightedBlendable> Array; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Engine.WeightedBlendable
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FWeightedBlendable {
	// Fields
	float Weight; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct UObject* Object; // Offset: 0x8 | Size: 0x8
};

// Object: ScriptStruct Engine.NavAgentSelector
// Inherited Bytes: 0x0 | Struct Size: 0x4
struct FNavAgentSelector {
	// Fields
	char bSupportsAgent0 : 1; // Offset: 0x0 | Size: 0x1
	char bSupportsAgent1 : 1; // Offset: 0x0 | Size: 0x1
	char bSupportsAgent2 : 1; // Offset: 0x0 | Size: 0x1
	char bSupportsAgent3 : 1; // Offset: 0x0 | Size: 0x1
	char bSupportsAgent4 : 1; // Offset: 0x0 | Size: 0x1
	char bSupportsAgent5 : 1; // Offset: 0x0 | Size: 0x1
	char bSupportsAgent6 : 1; // Offset: 0x0 | Size: 0x1
	char bSupportsAgent7 : 1; // Offset: 0x0 | Size: 0x1
	char bSupportsAgent8 : 1; // Offset: 0x1 | Size: 0x1
	char bSupportsAgent9 : 1; // Offset: 0x1 | Size: 0x1
	char bSupportsAgent10 : 1; // Offset: 0x1 | Size: 0x1
	char bSupportsAgent11 : 1; // Offset: 0x1 | Size: 0x1
	char bSupportsAgent12 : 1; // Offset: 0x1 | Size: 0x1
	char bSupportsAgent13 : 1; // Offset: 0x1 | Size: 0x1
	char bSupportsAgent14 : 1; // Offset: 0x1 | Size: 0x1
	char bSupportsAgent15 : 1; // Offset: 0x1 | Size: 0x1
	char pad_0x2[0x2]; // Offset: 0x2 | Size: 0x2
};

// Object: ScriptStruct Engine.AnimNode_AssetPlayerBase
// Inherited Bytes: 0x10 | Struct Size: 0x40
struct FAnimNode_AssetPlayerBase : FAnimNode_Base {
	// Fields
	int32_t GroupIndex; // Offset: 0x10 | Size: 0x4
	enum class EAnimGroupRole GroupRole; // Offset: 0x14 | Size: 0x1
	bool bIgnoreForRelevancyTest; // Offset: 0x15 | Size: 0x1
	char pad_0x16[0x2]; // Offset: 0x16 | Size: 0x2
	struct FName AnimNodeTag; // Offset: 0x18 | Size: 0x8
	char pad_0x20[0x4]; // Offset: 0x20 | Size: 0x4
	float BlendWeight; // Offset: 0x24 | Size: 0x4
	float InternalTimeAccumulator; // Offset: 0x28 | Size: 0x4
	char pad_0x2C[0x14]; // Offset: 0x2c | Size: 0x14
};

// Object: ScriptStruct Engine.PerBoneBlendWeight
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FPerBoneBlendWeight {
	// Fields
	int32_t SourceIndex; // Offset: 0x0 | Size: 0x4
	float BlendWeight; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct Engine.PoseSnapshot
// Inherited Bytes: 0x0 | Struct Size: 0x38
struct FPoseSnapshot {
	// Fields
	struct TArray<struct FTransform> LocalTransforms; // Offset: 0x0 | Size: 0x10
	struct TArray<struct FName> BoneNames; // Offset: 0x10 | Size: 0x10
	struct FName SkeletalMeshName; // Offset: 0x20 | Size: 0x8
	struct FName SnapshotName; // Offset: 0x28 | Size: 0x8
	bool bIsValid; // Offset: 0x30 | Size: 0x1
	char pad_0x31[0x7]; // Offset: 0x31 | Size: 0x7
};

// Object: ScriptStruct Engine.SolverIterations
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FSolverIterations {
	// Fields
	int32_t SolverIterations; // Offset: 0x0 | Size: 0x4
	int32_t JointIterations; // Offset: 0x4 | Size: 0x4
	int32_t CollisionIterations; // Offset: 0x8 | Size: 0x4
	int32_t SolverPushOutIterations; // Offset: 0xc | Size: 0x4
	int32_t JointPushOutIterations; // Offset: 0x10 | Size: 0x4
	int32_t CollisionPushOutIterations; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct Engine.AnimNode_Root
// Inherited Bytes: 0x10 | Struct Size: 0x30
struct FAnimNode_Root : FAnimNode_Base {
	// Fields
	struct FPoseLink Result; // Offset: 0x10 | Size: 0x10
	struct FName Name; // Offset: 0x20 | Size: 0x8
	struct FName Group; // Offset: 0x28 | Size: 0x8
};

// Object: ScriptStruct Engine.AnimCurveParam
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FAnimCurveParam {
	// Fields
	struct FName Name; // Offset: 0x0 | Size: 0x8
	char pad_0x8[0x4]; // Offset: 0x8 | Size: 0x4
};

// Object: ScriptStruct Engine.SceneComponentInstanceData
// Inherited Bytes: 0x58 | Struct Size: 0xa8
struct FSceneComponentInstanceData : FActorComponentInstanceData {
	// Fields
	struct TMap<struct USceneComponent*, struct FTransform> AttachedInstanceComponents; // Offset: 0x58 | Size: 0x50
};

// Object: ScriptStruct Engine.PoolActorReferencer
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FPoolActorReferencer {
	// Fields
	struct UObject* Referencer; // Offset: 0x0 | Size: 0x8
	struct FName PropertyName; // Offset: 0x8 | Size: 0x8
};

// Object: ScriptStruct Engine.KAggregateGeom
// Inherited Bytes: 0x0 | Struct Size: 0x58
struct FKAggregateGeom {
	// Fields
	struct TArray<struct FKSphereElem> SphereElems; // Offset: 0x0 | Size: 0x10
	struct TArray<struct FKBoxElem> BoxElems; // Offset: 0x10 | Size: 0x10
	struct TArray<struct FKSphylElem> SphylElems; // Offset: 0x20 | Size: 0x10
	struct TArray<struct FKConvexElem> ConvexElems; // Offset: 0x30 | Size: 0x10
	struct TArray<struct FKTaperedCapsuleElem> TaperedCapsuleElems; // Offset: 0x40 | Size: 0x10
	char pad_0x50[0x8]; // Offset: 0x50 | Size: 0x8
};

// Object: ScriptStruct Engine.KShapeElem
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FKShapeElem {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
	float RestOffset; // Offset: 0x8 | Size: 0x4
	struct FName Name; // Offset: 0xc | Size: 0x8
	char pad_0x14[0x4]; // Offset: 0x14 | Size: 0x4
	char bContributeToMass : 1; // Offset: 0x18 | Size: 0x1
	char pad_0x18_1 : 7; // Offset: 0x18 | Size: 0x1
	char pad_0x19[0x17]; // Offset: 0x19 | Size: 0x17
};

// Object: ScriptStruct Engine.KTaperedCapsuleElem
// Inherited Bytes: 0x30 | Struct Size: 0x58
struct FKTaperedCapsuleElem : FKShapeElem {
	// Fields
	struct FVector Center; // Offset: 0x30 | Size: 0xc
	struct FRotator Rotation; // Offset: 0x3c | Size: 0xc
	float Radius0; // Offset: 0x48 | Size: 0x4
	float Radius1; // Offset: 0x4c | Size: 0x4
	float Length; // Offset: 0x50 | Size: 0x4
	char pad_0x54[0x4]; // Offset: 0x54 | Size: 0x4
};

// Object: ScriptStruct Engine.KConvexElem
// Inherited Bytes: 0x30 | Struct Size: 0xb0
struct FKConvexElem : FKShapeElem {
	// Fields
	struct TArray<struct FVector> VertexData; // Offset: 0x30 | Size: 0x10
	struct TArray<int32_t> IndexData; // Offset: 0x40 | Size: 0x10
	struct FBox ElemBox; // Offset: 0x50 | Size: 0x1c
	char pad_0x6C[0x4]; // Offset: 0x6c | Size: 0x4
	struct FTransform Transform; // Offset: 0x70 | Size: 0x30
	char pad_0xA0[0x10]; // Offset: 0xa0 | Size: 0x10
};

// Object: ScriptStruct Engine.KSphylElem
// Inherited Bytes: 0x30 | Struct Size: 0x50
struct FKSphylElem : FKShapeElem {
	// Fields
	struct FVector Center; // Offset: 0x30 | Size: 0xc
	struct FRotator Rotation; // Offset: 0x3c | Size: 0xc
	float Radius; // Offset: 0x48 | Size: 0x4
	float Length; // Offset: 0x4c | Size: 0x4
};

// Object: ScriptStruct Engine.KBoxElem
// Inherited Bytes: 0x30 | Struct Size: 0x58
struct FKBoxElem : FKShapeElem {
	// Fields
	struct FVector Center; // Offset: 0x30 | Size: 0xc
	struct FRotator Rotation; // Offset: 0x3c | Size: 0xc
	float X; // Offset: 0x48 | Size: 0x4
	float Y; // Offset: 0x4c | Size: 0x4
	float Z; // Offset: 0x50 | Size: 0x4
	char pad_0x54[0x4]; // Offset: 0x54 | Size: 0x4
};

// Object: ScriptStruct Engine.KSphereElem
// Inherited Bytes: 0x30 | Struct Size: 0x40
struct FKSphereElem : FKShapeElem {
	// Fields
	struct FVector Center; // Offset: 0x30 | Size: 0xc
	float Radius; // Offset: 0x3c | Size: 0x4
};

// Object: ScriptStruct Engine.AnimationGroupReference
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FAnimationGroupReference {
	// Fields
	struct FName GroupName; // Offset: 0x0 | Size: 0x8
	enum class EAnimGroupRole GroupRole; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x3]; // Offset: 0x9 | Size: 0x3
};

// Object: ScriptStruct Engine.AnimGroupInstance
// Inherited Bytes: 0x0 | Struct Size: 0x70
struct FAnimGroupInstance {
	// Fields
	char pad_0x0[0x70]; // Offset: 0x0 | Size: 0x70
};

// Object: ScriptStruct Engine.AnimTickRecord
// Inherited Bytes: 0x0 | Struct Size: 0x48
struct FAnimTickRecord {
	// Fields
	struct UAnimationAsset* SourceAsset; // Offset: 0x0 | Size: 0x8
	char pad_0x8[0x40]; // Offset: 0x8 | Size: 0x40
};

// Object: ScriptStruct Engine.MarkerSyncAnimPosition
// Inherited Bytes: 0x0 | Struct Size: 0x14
struct FMarkerSyncAnimPosition {
	// Fields
	struct FName PreviousMarkerName; // Offset: 0x0 | Size: 0x8
	struct FName NextMarkerName; // Offset: 0x8 | Size: 0x8
	float PositionBetweenMarkers; // Offset: 0x10 | Size: 0x4
};

// Object: ScriptStruct Engine.BlendFilter
// Inherited Bytes: 0x0 | Struct Size: 0x78
struct FBlendFilter {
	// Fields
	char pad_0x0[0x78]; // Offset: 0x0 | Size: 0x78
};

// Object: ScriptStruct Engine.BlendSampleData
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FBlendSampleData {
	// Fields
	int32_t SampleDataIndex; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct UAnimSequence* Animation; // Offset: 0x8 | Size: 0x8
	float TotalWeight; // Offset: 0x10 | Size: 0x4
	float Time; // Offset: 0x14 | Size: 0x4
	float PreviousTime; // Offset: 0x18 | Size: 0x4
	float SamplePlayRate; // Offset: 0x1c | Size: 0x4
	char pad_0x20[0x20]; // Offset: 0x20 | Size: 0x20
};

// Object: ScriptStruct Engine.AnimationRecordingSettings
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FAnimationRecordingSettings {
	// Fields
	bool bRecordInWorldSpace; // Offset: 0x0 | Size: 0x1
	bool bRemoveRootAnimation; // Offset: 0x1 | Size: 0x1
	bool bAutoSaveAsset; // Offset: 0x2 | Size: 0x1
	char pad_0x3[0x1]; // Offset: 0x3 | Size: 0x1
	float SampleRate; // Offset: 0x4 | Size: 0x4
	float Length; // Offset: 0x8 | Size: 0x4
	enum class ERichCurveInterpMode InterpMode; // Offset: 0xc | Size: 0x1
	enum class ERichCurveTangentMode TangentMode; // Offset: 0xd | Size: 0x1
	char pad_0xE[0x2]; // Offset: 0xe | Size: 0x2
};

// Object: ScriptStruct Engine.ComponentSpacePose
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FComponentSpacePose {
	// Fields
	struct TArray<struct FTransform> Transforms; // Offset: 0x0 | Size: 0x10
	struct TArray<struct FName> Names; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct Engine.LocalSpacePose
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FLocalSpacePose {
	// Fields
	struct TArray<struct FTransform> Transforms; // Offset: 0x0 | Size: 0x10
	struct TArray<struct FName> Names; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct Engine.NamedTransform
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FNamedTransform {
	// Fields
	struct FTransform Value; // Offset: 0x0 | Size: 0x30
	struct FName Name; // Offset: 0x30 | Size: 0x8
	char pad_0x38[0x8]; // Offset: 0x38 | Size: 0x8
};

// Object: ScriptStruct Engine.NamedColor
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FNamedColor {
	// Fields
	struct FColor Value; // Offset: 0x0 | Size: 0x4
	struct FName Name; // Offset: 0x4 | Size: 0x8
};

// Object: ScriptStruct Engine.NamedVector
// Inherited Bytes: 0x0 | Struct Size: 0x14
struct FNamedVector {
	// Fields
	struct FVector Value; // Offset: 0x0 | Size: 0xc
	struct FName Name; // Offset: 0xc | Size: 0x8
};

// Object: ScriptStruct Engine.NamedFloat
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FNamedFloat {
	// Fields
	float Value; // Offset: 0x0 | Size: 0x4
	struct FName Name; // Offset: 0x4 | Size: 0x8
};

// Object: ScriptStruct Engine.AnimParentNodeAssetOverride
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FAnimParentNodeAssetOverride {
	// Fields
	struct UAnimationAsset* NewAsset; // Offset: 0x0 | Size: 0x8
	struct FGuid ParentNodeGuid; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct Engine.AnimGroupInfo
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FAnimGroupInfo {
	// Fields
	struct FName Name; // Offset: 0x0 | Size: 0x8
	struct FLinearColor Color; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct Engine.AnimBlueprintDebugData
// Inherited Bytes: 0x0 | Struct Size: 0x1
struct FAnimBlueprintDebugData {
	// Fields
	char pad_0x0[0x1]; // Offset: 0x0 | Size: 0x1
};

// Object: ScriptStruct Engine.AnimationFrameSnapshot
// Inherited Bytes: 0x0 | Struct Size: 0x1
struct FAnimationFrameSnapshot {
	// Fields
	char pad_0x0[0x1]; // Offset: 0x0 | Size: 0x1
};

// Object: ScriptStruct Engine.StateMachineDebugData
// Inherited Bytes: 0x0 | Struct Size: 0xb0
struct FStateMachineDebugData {
	// Fields
	char pad_0x0[0xb0]; // Offset: 0x0 | Size: 0xb0
};

// Object: ScriptStruct Engine.StateMachineStateDebugData
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FStateMachineStateDebugData {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Engine.AnimBlueprintFunctionData
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FAnimBlueprintFunctionData {
	// Fields
	struct TFieldPath<FStructProperty> OutputPoseNodeProperty; // Offset: 0x0 | Size: 0x20
	struct TArray<struct TFieldPath<FStructProperty>> InputPoseNodeProperties; // Offset: 0x20 | Size: 0x10
	struct TArray<struct TFieldPath<FProperty>> InputProperties; // Offset: 0x30 | Size: 0x10
};

// Object: ScriptStruct Engine.AnimGraphBlendOptions
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FAnimGraphBlendOptions {
	// Fields
	float BlendInTime; // Offset: 0x0 | Size: 0x4
	float BlendOutTime; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct Engine.GraphAssetPlayerInformation
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FGraphAssetPlayerInformation {
	// Fields
	struct TArray<int32_t> PlayerNodeIndices; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Engine.CachedPoseIndices
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FCachedPoseIndices {
	// Fields
	struct TArray<int32_t> OrderedSavedPoseNodeIndices; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Engine.AnimBlueprintFunction
// Inherited Bytes: 0x0 | Struct Size: 0x68
struct FAnimBlueprintFunction {
	// Fields
	struct FName Name; // Offset: 0x0 | Size: 0x8
	struct FName Group; // Offset: 0x8 | Size: 0x8
	int32_t OutputPoseNodeIndex; // Offset: 0x10 | Size: 0x4
	char pad_0x14[0x4]; // Offset: 0x14 | Size: 0x4
	struct TArray<struct FName> InputPoseNames; // Offset: 0x18 | Size: 0x10
	struct TArray<int32_t> InputPoseNodeIndices; // Offset: 0x28 | Size: 0x10
	char pad_0x38[0x28]; // Offset: 0x38 | Size: 0x28
	bool bImplemented; // Offset: 0x60 | Size: 0x1
	char pad_0x61[0x7]; // Offset: 0x61 | Size: 0x7
};

// Object: ScriptStruct Engine.AnimTrack
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FAnimTrack {
	// Fields
	struct TArray<struct FAnimSegment> AnimSegments; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Engine.AnimSegment
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FAnimSegment {
	// Fields
	struct UAnimSequenceBase* AnimReference; // Offset: 0x0 | Size: 0x8
	float StartPos; // Offset: 0x8 | Size: 0x4
	float AnimStartTime; // Offset: 0xc | Size: 0x4
	float AnimEndTime; // Offset: 0x10 | Size: 0x4
	float AnimPlayRate; // Offset: 0x14 | Size: 0x4
	int32_t LoopingCount; // Offset: 0x18 | Size: 0x4
	char pad_0x1C[0x4]; // Offset: 0x1c | Size: 0x4
};

// Object: ScriptStruct Engine.RootMotionExtractionStep
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FRootMotionExtractionStep {
	// Fields
	struct UAnimSequence* AnimSequence; // Offset: 0x0 | Size: 0x8
	float StartPosition; // Offset: 0x8 | Size: 0x4
	float EndPosition; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct Engine.AnimationErrorStats
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FAnimationErrorStats {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Engine.RawCurveTracks
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FRawCurveTracks {
	// Fields
	struct TArray<struct FFloatCurve> FloatCurves; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Engine.AnimCurveBase
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FAnimCurveBase {
	// Fields
	struct FName LastObservedName; // Offset: 0x0 | Size: 0x8
	struct FSmartName Name; // Offset: 0x8 | Size: 0xc
	int32_t CurveTypeFlags; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct Engine.SmartName
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FSmartName {
	// Fields
	struct FName DisplayName; // Offset: 0x0 | Size: 0x8
	char pad_0x8[0x4]; // Offset: 0x8 | Size: 0x4
};

// Object: ScriptStruct Engine.FloatCurve
// Inherited Bytes: 0x18 | Struct Size: 0x98
struct FFloatCurve : FAnimCurveBase {
	// Fields
	struct FRichCurve FloatCurve; // Offset: 0x18 | Size: 0x80
};

// Object: ScriptStruct Engine.TransformCurve
// Inherited Bytes: 0x18 | Struct Size: 0x4e0
struct FTransformCurve : FAnimCurveBase {
	// Fields
	struct FVectorCurve TranslationCurve; // Offset: 0x18 | Size: 0x198
	struct FVectorCurve RotationCurve; // Offset: 0x1b0 | Size: 0x198
	struct FVectorCurve ScaleCurve; // Offset: 0x348 | Size: 0x198
};

// Object: ScriptStruct Engine.VectorCurve
// Inherited Bytes: 0x18 | Struct Size: 0x198
struct FVectorCurve : FAnimCurveBase {
	// Fields
	struct FRichCurve FloatCurves[0x3]; // Offset: 0x18 | Size: 0x180
};

// Object: ScriptStruct Engine.SlotEvaluationPose
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FSlotEvaluationPose {
	// Fields
	enum class EAdditiveAnimationType AdditiveType; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	float Weight; // Offset: 0x4 | Size: 0x4
	char pad_0x8[0x38]; // Offset: 0x8 | Size: 0x38
};

// Object: ScriptStruct Engine.A2Pose
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FA2Pose {
	// Fields
	struct TArray<struct FTransform> Bones; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Engine.A2CSPose
// Inherited Bytes: 0x10 | Struct Size: 0x28
struct FA2CSPose : FA2Pose {
	// Fields
	char pad_0x10[0x8]; // Offset: 0x10 | Size: 0x8
	struct TArray<char> ComponentSpaceFlags; // Offset: 0x18 | Size: 0x10
};

// Object: ScriptStruct Engine.OverrideAssetsTagForFilter
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FOverrideAssetsTagForFilter {
	// Fields
	struct TSet<struct FName> Tags; // Offset: 0x0 | Size: 0x50
};

// Object: ScriptStruct Engine.OverrideAnimGUIDs
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FOverrideAnimGUIDs {
	// Fields
	struct TSet<struct FGuid> Guids; // Offset: 0x0 | Size: 0x50
};

// Object: ScriptStruct Engine.QueuedDrawDebugItem
// Inherited Bytes: 0x0 | Struct Size: 0x68
struct FQueuedDrawDebugItem {
	// Fields
	enum class EDrawDebugItemType ItemType; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	struct FVector StartLoc; // Offset: 0x4 | Size: 0xc
	struct FVector EndLoc; // Offset: 0x10 | Size: 0xc
	struct FVector Center; // Offset: 0x1c | Size: 0xc
	struct FRotator Rotation; // Offset: 0x28 | Size: 0xc
	float Radius; // Offset: 0x34 | Size: 0x4
	float Size; // Offset: 0x38 | Size: 0x4
	int32_t Segments; // Offset: 0x3c | Size: 0x4
	struct FColor Color; // Offset: 0x40 | Size: 0x4
	bool bPersistentLines; // Offset: 0x44 | Size: 0x1
	char pad_0x45[0x3]; // Offset: 0x45 | Size: 0x3
	float LifeTime; // Offset: 0x48 | Size: 0x4
	float Thickness; // Offset: 0x4c | Size: 0x4
	struct FString Message; // Offset: 0x50 | Size: 0x10
	struct FVector2D TextScale; // Offset: 0x60 | Size: 0x8
};

// Object: ScriptStruct Engine.AnimLinkableElement
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FAnimLinkableElement {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
	struct UAnimMontage* LinkedMontage; // Offset: 0x8 | Size: 0x8
	int32_t SlotIndex; // Offset: 0x10 | Size: 0x4
	int32_t SegmentIndex; // Offset: 0x14 | Size: 0x4
	enum class EAnimLinkMethod LinkMethod; // Offset: 0x18 | Size: 0x1
	enum class EAnimLinkMethod CachedLinkMethod; // Offset: 0x19 | Size: 0x1
	char pad_0x1A[0x2]; // Offset: 0x1a | Size: 0x2
	float SegmentBeginTime; // Offset: 0x1c | Size: 0x4
	float SegmentLength; // Offset: 0x20 | Size: 0x4
	float LinkValue; // Offset: 0x24 | Size: 0x4
	struct UAnimSequenceBase* LinkedSequence; // Offset: 0x28 | Size: 0x8
};

// Object: ScriptStruct Engine.AnimMontageInstance
// Inherited Bytes: 0x0 | Struct Size: 0x1b0
struct FAnimMontageInstance {
	// Fields
	struct UAnimMontage* Montage; // Offset: 0x0 | Size: 0x8
	char pad_0x8[0x20]; // Offset: 0x8 | Size: 0x20
	bool bPlaying; // Offset: 0x28 | Size: 0x1
	char pad_0x29[0x3]; // Offset: 0x29 | Size: 0x3
	float DefaultBlendTimeMultiplier; // Offset: 0x2c | Size: 0x4
	char pad_0x30[0xb8]; // Offset: 0x30 | Size: 0xb8
	struct TArray<int32_t> NextSections; // Offset: 0xe8 | Size: 0x10
	struct TArray<int32_t> PrevSections; // Offset: 0xf8 | Size: 0x10
	char pad_0x108[0x10]; // Offset: 0x108 | Size: 0x10
	struct TArray<struct FAnimNotifyEvent> ActiveStateBranchingPoints; // Offset: 0x118 | Size: 0x10
	float Position; // Offset: 0x128 | Size: 0x4
	float PlayRate; // Offset: 0x12c | Size: 0x4
	struct FAlphaBlend Blend; // Offset: 0x130 | Size: 0x30
	char pad_0x160[0x28]; // Offset: 0x160 | Size: 0x28
	int32_t DisableRootMotionCount; // Offset: 0x188 | Size: 0x4
	char pad_0x18C[0x24]; // Offset: 0x18c | Size: 0x24
};

// Object: ScriptStruct Engine.AnimNotifyEvent
// Inherited Bytes: 0x30 | Struct Size: 0xc0
struct FAnimNotifyEvent : FAnimLinkableElement {
	// Fields
	float DisplayTime; // Offset: 0x30 | Size: 0x4
	float TriggerTimeOffset; // Offset: 0x34 | Size: 0x4
	float EndTriggerTimeOffset; // Offset: 0x38 | Size: 0x4
	float TriggerWeightThreshold; // Offset: 0x3c | Size: 0x4
	struct FName NotifyName; // Offset: 0x40 | Size: 0x8
	struct UAnimNotify* Notify; // Offset: 0x48 | Size: 0x8
	struct UAnimNotifyState* NotifyStateClass; // Offset: 0x50 | Size: 0x8
	float Duration; // Offset: 0x58 | Size: 0x4
	char pad_0x5C[0x4]; // Offset: 0x5c | Size: 0x4
	struct FAnimLinkableElement EndLink; // Offset: 0x60 | Size: 0x30
	bool bConvertedFromBranchingPoint; // Offset: 0x90 | Size: 0x1
	enum class EMontageNotifyTickType MontageTickType; // Offset: 0x91 | Size: 0x1
	char pad_0x92[0x2]; // Offset: 0x92 | Size: 0x2
	float NotifyTriggerChance; // Offset: 0x94 | Size: 0x4
	enum class ENotifyFilterType NotifyFilterType; // Offset: 0x98 | Size: 0x1
	char pad_0x99[0x3]; // Offset: 0x99 | Size: 0x3
	int32_t NotifyFilterLOD; // Offset: 0x9c | Size: 0x4
	int32_t NotifyFilterSignificanceLevel; // Offset: 0xa0 | Size: 0x4
	bool bTriggerOnDedicatedServer; // Offset: 0xa4 | Size: 0x1
	bool bTriggerOnFollower; // Offset: 0xa5 | Size: 0x1
	char pad_0xA6[0x2]; // Offset: 0xa6 | Size: 0x2
	int32_t TrackIndex; // Offset: 0xa8 | Size: 0x4
	char pad_0xAC[0x14]; // Offset: 0xac | Size: 0x14
};

// Object: ScriptStruct Engine.BranchingPointMarker
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FBranchingPointMarker {
	// Fields
	int32_t NotifyIndex; // Offset: 0x0 | Size: 0x4
	float TriggerTime; // Offset: 0x4 | Size: 0x4
	enum class EAnimNotifyEventType NotifyEventType; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x3]; // Offset: 0x9 | Size: 0x3
};

// Object: ScriptStruct Engine.BranchingPoint
// Inherited Bytes: 0x30 | Struct Size: 0x40
struct FBranchingPoint : FAnimLinkableElement {
	// Fields
	struct FName EventName; // Offset: 0x30 | Size: 0x8
	float DisplayTime; // Offset: 0x38 | Size: 0x4
	float TriggerTimeOffset; // Offset: 0x3c | Size: 0x4
};

// Object: ScriptStruct Engine.SlotAnimationTrack
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FSlotAnimationTrack {
	// Fields
	struct FName SlotName; // Offset: 0x0 | Size: 0x8
	struct FAnimTrack AnimTrack; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct Engine.CompositeSection
// Inherited Bytes: 0x30 | Struct Size: 0x58
struct FCompositeSection : FAnimLinkableElement {
	// Fields
	struct FName SectionName; // Offset: 0x30 | Size: 0x8
	float StartTime; // Offset: 0x38 | Size: 0x4
	struct FName NextSectionName; // Offset: 0x3c | Size: 0x8
	char pad_0x44[0x4]; // Offset: 0x44 | Size: 0x4
	struct TArray<struct UAnimMetaData*> MetaData; // Offset: 0x48 | Size: 0x10
};

// Object: ScriptStruct Engine.AnimNode_ApplyMeshSpaceAdditive
// Inherited Bytes: 0x10 | Struct Size: 0xd0
struct FAnimNode_ApplyMeshSpaceAdditive : FAnimNode_Base {
	// Fields
	struct FPoseLink Base; // Offset: 0x10 | Size: 0x10
	struct FPoseLink Additive; // Offset: 0x20 | Size: 0x10
	enum class EAnimAlphaInputType AlphaInputType; // Offset: 0x30 | Size: 0x1
	char pad_0x31[0x3]; // Offset: 0x31 | Size: 0x3
	float Alpha; // Offset: 0x34 | Size: 0x4
	char bAlphaBoolEnabled : 1; // Offset: 0x38 | Size: 0x1
	char pad_0x38_1 : 7; // Offset: 0x38 | Size: 0x1
	char pad_0x39[0x7]; // Offset: 0x39 | Size: 0x7
	struct FInputAlphaBoolBlend AlphaBoolBlend; // Offset: 0x40 | Size: 0x48
	struct FName AlphaCurveName; // Offset: 0x88 | Size: 0x8
	struct FInputScaleBias AlphaScaleBias; // Offset: 0x90 | Size: 0x8
	struct FInputScaleBiasClamp AlphaScaleBiasClamp; // Offset: 0x98 | Size: 0x30
	int32_t LODThreshold; // Offset: 0xc8 | Size: 0x4
	char pad_0xCC[0x4]; // Offset: 0xcc | Size: 0x4
};

// Object: ScriptStruct Engine.AnimNode_Inertialization
// Inherited Bytes: 0x10 | Struct Size: 0x70
struct FAnimNode_Inertialization : FAnimNode_Base {
	// Fields
	struct FPoseLink Source; // Offset: 0x10 | Size: 0x10
	char pad_0x20[0x50]; // Offset: 0x20 | Size: 0x50
};

// Object: ScriptStruct Engine.InertializationPoseDiff
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FInertializationPoseDiff {
	// Fields
	char pad_0x0[0x28]; // Offset: 0x0 | Size: 0x28
};

// Object: ScriptStruct Engine.InertializationCurveDiff
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FInertializationCurveDiff {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
};

// Object: ScriptStruct Engine.InertializationBoneDiff
// Inherited Bytes: 0x0 | Struct Size: 0x3c
struct FInertializationBoneDiff {
	// Fields
	char pad_0x0[0x3c]; // Offset: 0x0 | Size: 0x3c
};

// Object: ScriptStruct Engine.InertializationPose
// Inherited Bytes: 0x0 | Struct Size: 0x90
struct FInertializationPose {
	// Fields
	char pad_0x0[0x90]; // Offset: 0x0 | Size: 0x90
};

// Object: ScriptStruct Engine.AnimNode_LinkedAnimGraph
// Inherited Bytes: 0x58 | Struct Size: 0xa0
struct FAnimNode_LinkedAnimGraph : FAnimNode_CustomProperty {
	// Fields
	struct TArray<struct FPoseLink> InputPoses; // Offset: 0x58 | Size: 0x10
	struct TArray<struct FName> InputPoseNames; // Offset: 0x68 | Size: 0x10
	struct UAnimInstance* InstanceClass; // Offset: 0x78 | Size: 0x8
	struct FName Tag; // Offset: 0x80 | Size: 0x8
	char pad_0x88[0x10]; // Offset: 0x88 | Size: 0x10
	char bReceiveNotifiesFromLinkedInstances : 1; // Offset: 0x98 | Size: 0x1
	char bPropagateNotifiesToLinkedInstances : 1; // Offset: 0x98 | Size: 0x1
	char pad_0x98_2 : 6; // Offset: 0x98 | Size: 0x1
	char pad_0x99[0x7]; // Offset: 0x99 | Size: 0x7
};

// Object: ScriptStruct Engine.AnimNode_LinkedAnimLayer
// Inherited Bytes: 0xa0 | Struct Size: 0xb8
struct FAnimNode_LinkedAnimLayer : FAnimNode_LinkedAnimGraph {
	// Fields
	struct UAnimLayerInterface* Interface; // Offset: 0xa0 | Size: 0x8
	struct FName Layer; // Offset: 0xa8 | Size: 0x8
	bool bEnableDeferredConstructAnimInstance; // Offset: 0xb0 | Size: 0x1
	char pad_0xB1[0x7]; // Offset: 0xb1 | Size: 0x7
};

// Object: ScriptStruct Engine.AnimNode_LinkedInputPose
// Inherited Bytes: 0x10 | Struct Size: 0x78
struct FAnimNode_LinkedInputPose : FAnimNode_Base {
	// Fields
	struct FName Name; // Offset: 0x10 | Size: 0x8
	struct FName Graph; // Offset: 0x18 | Size: 0x8
	struct FPoseLink InputPose; // Offset: 0x20 | Size: 0x10
	char pad_0x30[0x48]; // Offset: 0x30 | Size: 0x48
};

// Object: ScriptStruct Engine.AnimNode_SaveCachedPose
// Inherited Bytes: 0x10 | Struct Size: 0xb8
struct FAnimNode_SaveCachedPose : FAnimNode_Base {
	// Fields
	struct FPoseLink Pose; // Offset: 0x10 | Size: 0x10
	struct FName CachePoseName; // Offset: 0x20 | Size: 0x8
	char pad_0x28[0x90]; // Offset: 0x28 | Size: 0x90
};

// Object: ScriptStruct Engine.AnimNode_SequencePlayer
// Inherited Bytes: 0x40 | Struct Size: 0x88
struct FAnimNode_SequencePlayer : FAnimNode_AssetPlayerBase {
	// Fields
	struct UAnimSequenceBase* Sequence; // Offset: 0x40 | Size: 0x8
	float PlayRateBasis; // Offset: 0x48 | Size: 0x4
	float PlayRate; // Offset: 0x4c | Size: 0x4
	struct FInputScaleBiasClamp PlayRateScaleBiasClamp; // Offset: 0x50 | Size: 0x30
	float StartPosition; // Offset: 0x80 | Size: 0x4
	bool bLoopAnimation; // Offset: 0x84 | Size: 0x1
	char pad_0x85[0x3]; // Offset: 0x85 | Size: 0x3
};

// Object: ScriptStruct Engine.AnimNode_StateMachine
// Inherited Bytes: 0x10 | Struct Size: 0xb0
struct FAnimNode_StateMachine : FAnimNode_Base {
	// Fields
	int32_t StateMachineIndexInClass; // Offset: 0x10 | Size: 0x4
	int32_t MaxTransitionsPerFrame; // Offset: 0x14 | Size: 0x4
	bool bSkipFirstUpdateTransition; // Offset: 0x18 | Size: 0x1
	bool bReinitializeOnBecomingRelevant; // Offset: 0x19 | Size: 0x1
	char pad_0x1A[0x96]; // Offset: 0x1a | Size: 0x96
};

// Object: ScriptStruct Engine.AnimationPotentialTransition
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FAnimationPotentialTransition {
	// Fields
	char pad_0x0[0x30]; // Offset: 0x0 | Size: 0x30
};

// Object: ScriptStruct Engine.AnimationActiveTransitionEntry
// Inherited Bytes: 0x0 | Struct Size: 0xc8
struct FAnimationActiveTransitionEntry {
	// Fields
	char pad_0x0[0xb8]; // Offset: 0x0 | Size: 0xb8
	struct UBlendProfile* BlendProfile; // Offset: 0xb8 | Size: 0x8
	char pad_0xC0[0x8]; // Offset: 0xc0 | Size: 0x8
};

// Object: ScriptStruct Engine.AnimNode_TransitionPoseEvaluator
// Inherited Bytes: 0x10 | Struct Size: 0x58
struct FAnimNode_TransitionPoseEvaluator : FAnimNode_Base {
	// Fields
	char pad_0x10[0x38]; // Offset: 0x10 | Size: 0x38
	int32_t FramesToCachePose; // Offset: 0x48 | Size: 0x4
	char pad_0x4C[0x4]; // Offset: 0x4c | Size: 0x4
	enum class EEvaluatorDataSource DataSource; // Offset: 0x50 | Size: 0x1
	enum class EEvaluatorMode EvaluatorMode; // Offset: 0x51 | Size: 0x1
	char pad_0x52[0x6]; // Offset: 0x52 | Size: 0x6
};

// Object: ScriptStruct Engine.AnimNode_TransitionResult
// Inherited Bytes: 0x10 | Struct Size: 0x28
struct FAnimNode_TransitionResult : FAnimNode_Base {
	// Fields
	bool bCanEnterTransition; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x17]; // Offset: 0x11 | Size: 0x17
};

// Object: ScriptStruct Engine.AnimNode_UseCachedPose
// Inherited Bytes: 0x10 | Struct Size: 0x28
struct FAnimNode_UseCachedPose : FAnimNode_Base {
	// Fields
	struct FPoseLink LinkToCachingNode; // Offset: 0x10 | Size: 0x10
	struct FName CachePoseName; // Offset: 0x20 | Size: 0x8
};

// Object: ScriptStruct Engine.ExposedValueHandler
// Inherited Bytes: 0x0 | Struct Size: 0x48
struct FExposedValueHandler {
	// Fields
	struct FName BoundFunction; // Offset: 0x0 | Size: 0x8
	struct TArray<struct FExposedValueCopyRecord> CopyRecords; // Offset: 0x8 | Size: 0x10
	struct UFunction* Function; // Offset: 0x18 | Size: 0x8
	struct TFieldPath<FStructProperty> ValueHandlerNodeProperty; // Offset: 0x20 | Size: 0x20
	char pad_0x40[0x8]; // Offset: 0x40 | Size: 0x8
};

// Object: ScriptStruct Engine.ExposedValueCopyRecord
// Inherited Bytes: 0x0 | Struct Size: 0x80
struct FExposedValueCopyRecord {
	// Fields
	struct FName SourcePropertyName; // Offset: 0x0 | Size: 0x8
	struct FName SourceSubPropertyName; // Offset: 0x8 | Size: 0x8
	int32_t SourceArrayIndex; // Offset: 0x10 | Size: 0x4
	bool bInstanceIsTarget; // Offset: 0x14 | Size: 0x1
	enum class EPostCopyOperation PostCopyOperation; // Offset: 0x15 | Size: 0x1
	enum class ECopyType CopyType; // Offset: 0x16 | Size: 0x1
	char pad_0x17[0x1]; // Offset: 0x17 | Size: 0x1
	struct TFieldPath<FProperty> DestProperty; // Offset: 0x18 | Size: 0x20
	int32_t DestArrayIndex; // Offset: 0x38 | Size: 0x4
	int32_t Size; // Offset: 0x3c | Size: 0x4
	struct TFieldPath<FProperty> CachedSourceProperty; // Offset: 0x40 | Size: 0x20
	struct TFieldPath<FProperty> CachedSourceStructSubProperty; // Offset: 0x60 | Size: 0x20
};

// Object: ScriptStruct Engine.AnimNode_ConvertLocalToComponentSpace
// Inherited Bytes: 0x10 | Struct Size: 0x20
struct FAnimNode_ConvertLocalToComponentSpace : FAnimNode_Base {
	// Fields
	struct FPoseLink LocalPose; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct Engine.AnimNode_ConvertComponentToLocalSpace
// Inherited Bytes: 0x10 | Struct Size: 0x20
struct FAnimNode_ConvertComponentToLocalSpace : FAnimNode_Base {
	// Fields
	struct FComponentSpacePoseLink ComponentPose; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct Engine.AnimNotifyQueue
// Inherited Bytes: 0x0 | Struct Size: 0x70
struct FAnimNotifyQueue {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x0 | Size: 0x10
	struct TArray<struct FAnimNotifyEventReference> AnimNotifies; // Offset: 0x10 | Size: 0x10
	struct TMap<struct FName, struct FAnimNotifyArray> UnfilteredMontageAnimNotifies; // Offset: 0x20 | Size: 0x50
};

// Object: ScriptStruct Engine.AnimNotifyArray
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FAnimNotifyArray {
	// Fields
	struct TArray<struct FAnimNotifyEventReference> Notifies; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Engine.AnimNotifyEventReference
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FAnimNotifyEventReference {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
	struct UObject* NotifySource; // Offset: 0x8 | Size: 0x8
};

// Object: ScriptStruct Engine.CompressedTrack
// Inherited Bytes: 0x0 | Struct Size: 0x38
struct FCompressedTrack {
	// Fields
	struct TArray<char> ByteStream; // Offset: 0x0 | Size: 0x10
	struct TArray<float> Times; // Offset: 0x10 | Size: 0x10
	float Mins[0x3]; // Offset: 0x20 | Size: 0xc
	float Ranges[0x3]; // Offset: 0x2c | Size: 0xc
};

// Object: ScriptStruct Engine.CurveTrack
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FCurveTrack {
	// Fields
	struct FName CurveName; // Offset: 0x0 | Size: 0x8
	struct TArray<float> CurveWeights; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct Engine.ScaleTrack
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FScaleTrack {
	// Fields
	struct TArray<struct FVector> ScaleKeys; // Offset: 0x0 | Size: 0x10
	struct TArray<float> Times; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct Engine.RotationTrack
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FRotationTrack {
	// Fields
	struct TArray<struct FQuat> RotKeys; // Offset: 0x0 | Size: 0x10
	struct TArray<float> Times; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct Engine.TranslationTrack
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FTranslationTrack {
	// Fields
	struct TArray<struct FVector> PosKeys; // Offset: 0x0 | Size: 0x10
	struct TArray<float> Times; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct Engine.AnimSequenceTrackContainer
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FAnimSequenceTrackContainer {
	// Fields
	struct TArray<struct FRawAnimSequenceTrack> AnimationTracks; // Offset: 0x0 | Size: 0x10
	struct TArray<struct FName> TrackNames; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct Engine.RawAnimSequenceTrack
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FRawAnimSequenceTrack {
	// Fields
	struct TArray<struct FVector> PosKeys; // Offset: 0x0 | Size: 0x10
	struct TArray<struct FQuat> RotKeys; // Offset: 0x10 | Size: 0x10
	struct TArray<struct FVector> ScaleKeys; // Offset: 0x20 | Size: 0x10
};

// Object: ScriptStruct Engine.AnimSetMeshLinkup
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FAnimSetMeshLinkup {
	// Fields
	struct TArray<int32_t> BoneToTrackTable; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Engine.AnimSingleNodeInstanceProxy
// Inherited Bytes: 0x6e0 | Struct Size: 0x830
struct FAnimSingleNodeInstanceProxy : FAnimInstanceProxy {
	// Fields
	char pad_0x6E0[0x150]; // Offset: 0x6e0 | Size: 0x150
};

// Object: ScriptStruct Engine.AnimNode_SingleNode
// Inherited Bytes: 0x10 | Struct Size: 0x30
struct FAnimNode_SingleNode : FAnimNode_Base {
	// Fields
	struct FPoseLink SourcePose; // Offset: 0x10 | Size: 0x10
	char pad_0x20[0x10]; // Offset: 0x20 | Size: 0x10
};

// Object: ScriptStruct Engine.BakedAnimationStateMachine
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FBakedAnimationStateMachine {
	// Fields
	struct FName MachineName; // Offset: 0x0 | Size: 0x8
	int32_t InitialState; // Offset: 0x8 | Size: 0x4
	char pad_0xC[0x4]; // Offset: 0xc | Size: 0x4
	struct TArray<struct FBakedAnimationState> States; // Offset: 0x10 | Size: 0x10
	struct TArray<struct FAnimationTransitionBetweenStates> Transitions; // Offset: 0x20 | Size: 0x10
};

// Object: ScriptStruct Engine.AnimationStateBase
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FAnimationStateBase {
	// Fields
	struct FName StateName; // Offset: 0x0 | Size: 0x8
};

// Object: ScriptStruct Engine.AnimationTransitionBetweenStates
// Inherited Bytes: 0x8 | Struct Size: 0x40
struct FAnimationTransitionBetweenStates : FAnimationStateBase {
	// Fields
	int32_t PreviousState; // Offset: 0x8 | Size: 0x4
	int32_t NextState; // Offset: 0xc | Size: 0x4
	float CrossfadeDuration; // Offset: 0x10 | Size: 0x4
	int32_t StartNotify; // Offset: 0x14 | Size: 0x4
	int32_t EndNotify; // Offset: 0x18 | Size: 0x4
	int32_t InterruptNotify; // Offset: 0x1c | Size: 0x4
	enum class EAlphaBlendOption BlendMode; // Offset: 0x20 | Size: 0x1
	char pad_0x21[0x7]; // Offset: 0x21 | Size: 0x7
	struct UCurveFloat* CustomCurve; // Offset: 0x28 | Size: 0x8
	struct UBlendProfile* BlendProfile; // Offset: 0x30 | Size: 0x8
	enum class ETransitionLogicType LogicType; // Offset: 0x38 | Size: 0x1
	char pad_0x39[0x7]; // Offset: 0x39 | Size: 0x7
};

// Object: ScriptStruct Engine.BakedAnimationState
// Inherited Bytes: 0x0 | Struct Size: 0x58
struct FBakedAnimationState {
	// Fields
	struct FName StateName; // Offset: 0x0 | Size: 0x8
	struct TArray<struct FBakedStateExitTransition> Transitions; // Offset: 0x8 | Size: 0x10
	int32_t StateRootNodeIndex; // Offset: 0x18 | Size: 0x4
	int32_t StartNotify; // Offset: 0x1c | Size: 0x4
	int32_t EndNotify; // Offset: 0x20 | Size: 0x4
	int32_t FullyBlendedNotify; // Offset: 0x24 | Size: 0x4
	bool bIsAConduit; // Offset: 0x28 | Size: 0x1
	char pad_0x29[0x3]; // Offset: 0x29 | Size: 0x3
	int32_t EntryRuleNodeIndex; // Offset: 0x2c | Size: 0x4
	struct TArray<int32_t> PlayerNodeIndices; // Offset: 0x30 | Size: 0x10
	struct TArray<int32_t> LayerNodeIndices; // Offset: 0x40 | Size: 0x10
	bool bAlwaysResetOnEntry; // Offset: 0x50 | Size: 0x1
	char pad_0x51[0x7]; // Offset: 0x51 | Size: 0x7
};

// Object: ScriptStruct Engine.BakedStateExitTransition
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FBakedStateExitTransition {
	// Fields
	int32_t CanTakeDelegateIndex; // Offset: 0x0 | Size: 0x4
	int32_t CustomResultNodeIndex; // Offset: 0x4 | Size: 0x4
	int32_t TransitionIndex; // Offset: 0x8 | Size: 0x4
	bool bDesiredTransitionReturnValue; // Offset: 0xc | Size: 0x1
	bool bAutomaticRemainingTimeRule; // Offset: 0xd | Size: 0x1
	char pad_0xE[0x2]; // Offset: 0xe | Size: 0x2
	struct TArray<int32_t> PoseEvaluatorLinks; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct Engine.AnimationState
// Inherited Bytes: 0x8 | Struct Size: 0x28
struct FAnimationState : FAnimationStateBase {
	// Fields
	struct TArray<struct FAnimationTransitionRule> Transitions; // Offset: 0x8 | Size: 0x10
	int32_t StateRootNodeIndex; // Offset: 0x18 | Size: 0x4
	int32_t StartNotify; // Offset: 0x1c | Size: 0x4
	int32_t EndNotify; // Offset: 0x20 | Size: 0x4
	int32_t FullyBlendedNotify; // Offset: 0x24 | Size: 0x4
};

// Object: ScriptStruct Engine.AnimationTransitionRule
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FAnimationTransitionRule {
	// Fields
	struct FName RuleToExecute; // Offset: 0x0 | Size: 0x8
	bool TransitionReturnVal; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x3]; // Offset: 0x9 | Size: 0x3
	int32_t TransitionIndex; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct Engine.TrackToSkeletonMap
// Inherited Bytes: 0x0 | Struct Size: 0x4
struct FTrackToSkeletonMap {
	// Fields
	int32_t BoneTreeIndex; // Offset: 0x0 | Size: 0x4
};

// Object: ScriptStruct Engine.MarkerSyncData
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FMarkerSyncData {
	// Fields
	struct TArray<struct FAnimSyncMarker> AuthoredSyncMarkers; // Offset: 0x0 | Size: 0x10
	char pad_0x10[0x10]; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct Engine.AnimSyncMarker
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FAnimSyncMarker {
	// Fields
	struct FName MarkerName; // Offset: 0x0 | Size: 0x8
	float Time; // Offset: 0x8 | Size: 0x4
};

// Object: ScriptStruct Engine.AnimNotifyTrack
// Inherited Bytes: 0x0 | Struct Size: 0x38
struct FAnimNotifyTrack {
	// Fields
	struct FName TrackName; // Offset: 0x0 | Size: 0x8
	struct FLinearColor TrackColor; // Offset: 0x8 | Size: 0x10
	char pad_0x18[0x20]; // Offset: 0x18 | Size: 0x20
};

// Object: ScriptStruct Engine.PerBoneBlendWeights
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FPerBoneBlendWeights {
	// Fields
	struct TArray<struct FPerBoneBlendWeight> BoneBlendWeights; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Engine.AssetImportInfo
// Inherited Bytes: 0x0 | Struct Size: 0x1
struct FAssetImportInfo {
	// Fields
	char pad_0x0[0x1]; // Offset: 0x0 | Size: 0x1
};

// Object: ScriptStruct Engine.PrimaryAssetRulesCustomOverride
// Inherited Bytes: 0x0 | Struct Size: 0x38
struct FPrimaryAssetRulesCustomOverride {
	// Fields
	struct FPrimaryAssetType PrimaryAssetType; // Offset: 0x0 | Size: 0x8
	struct FDirectoryPath FilterDirectory; // Offset: 0x8 | Size: 0x10
	struct FString FilterString; // Offset: 0x18 | Size: 0x10
	struct FPrimaryAssetRules Rules; // Offset: 0x28 | Size: 0xc
	char pad_0x34[0x4]; // Offset: 0x34 | Size: 0x4
};

// Object: ScriptStruct Engine.PrimaryAssetRules
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FPrimaryAssetRules {
	// Fields
	int32_t Priority; // Offset: 0x0 | Size: 0x4
	int32_t ChunkID; // Offset: 0x4 | Size: 0x4
	bool bApplyRecursively; // Offset: 0x8 | Size: 0x1
	enum class EPrimaryAssetCookRule CookRule; // Offset: 0x9 | Size: 0x1
	char pad_0xA[0x2]; // Offset: 0xa | Size: 0x2
};

// Object: ScriptStruct Engine.PrimaryAssetRulesOverride
// Inherited Bytes: 0x0 | Struct Size: 0x1c
struct FPrimaryAssetRulesOverride {
	// Fields
	struct FPrimaryAssetId PrimaryAssetId; // Offset: 0x0 | Size: 0x10
	struct FPrimaryAssetRules Rules; // Offset: 0x10 | Size: 0xc
};

// Object: ScriptStruct Engine.AssetManagerRedirect
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FAssetManagerRedirect {
	// Fields
	struct FString Old; // Offset: 0x0 | Size: 0x10
	struct FString New; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct Engine.PrimaryAssetTypeInfo
// Inherited Bytes: 0x0 | Struct Size: 0x88
struct FPrimaryAssetTypeInfo {
	// Fields
	struct FName PrimaryAssetType; // Offset: 0x0 | Size: 0x8
	struct TSoftClassPtr<UObject> AssetBaseClass; // Offset: 0x8 | Size: 0x28
	struct UObject* AssetBaseClassLoaded; // Offset: 0x30 | Size: 0x8
	bool bHasBlueprintClasses; // Offset: 0x38 | Size: 0x1
	bool bIsEditorOnly; // Offset: 0x39 | Size: 0x1
	char pad_0x3A[0x6]; // Offset: 0x3a | Size: 0x6
	struct TArray<struct FDirectoryPath> Directories; // Offset: 0x40 | Size: 0x10
	struct TArray<struct FSoftObjectPath> SpecificAssets; // Offset: 0x50 | Size: 0x10
	struct FPrimaryAssetRules Rules; // Offset: 0x60 | Size: 0xc
	char pad_0x6C[0x4]; // Offset: 0x6c | Size: 0x4
	struct TArray<struct FString> AssetScanPaths; // Offset: 0x70 | Size: 0x10
	bool bIsDynamicAsset; // Offset: 0x80 | Size: 0x1
	char pad_0x81[0x3]; // Offset: 0x81 | Size: 0x3
	int32_t NumberOfAssets; // Offset: 0x84 | Size: 0x4
};

// Object: ScriptStruct Engine.AssetMapping
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FAssetMapping {
	// Fields
	struct UAnimationAsset* SourceAsset; // Offset: 0x0 | Size: 0x8
	struct UAnimationAsset* TargetAsset; // Offset: 0x8 | Size: 0x8
};

// Object: ScriptStruct Engine.AtmospherePrecomputeInstanceData
// Inherited Bytes: 0xa8 | Struct Size: 0x138
struct FAtmospherePrecomputeInstanceData : FSceneComponentInstanceData {
	// Fields
	char pad_0xA8[0x90]; // Offset: 0xa8 | Size: 0x90
};

// Object: ScriptStruct Engine.AtmospherePrecomputeParameters
// Inherited Bytes: 0x0 | Struct Size: 0x2c
struct FAtmospherePrecomputeParameters {
	// Fields
	float DensityHeight; // Offset: 0x0 | Size: 0x4
	float DecayHeight; // Offset: 0x4 | Size: 0x4
	int32_t MaxScatteringOrder; // Offset: 0x8 | Size: 0x4
	int32_t TransmittanceTexWidth; // Offset: 0xc | Size: 0x4
	int32_t TransmittanceTexHeight; // Offset: 0x10 | Size: 0x4
	int32_t IrradianceTexWidth; // Offset: 0x14 | Size: 0x4
	int32_t IrradianceTexHeight; // Offset: 0x18 | Size: 0x4
	int32_t InscatterAltitudeSampleNum; // Offset: 0x1c | Size: 0x4
	int32_t InscatterMuNum; // Offset: 0x20 | Size: 0x4
	int32_t InscatterMuSNum; // Offset: 0x24 | Size: 0x4
	int32_t InscatterNuNum; // Offset: 0x28 | Size: 0x4
};

// Object: ScriptStruct Engine.BaseAttenuationSettings
// Inherited Bytes: 0x0 | Struct Size: 0xb0
struct FBaseAttenuationSettings {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
	enum class EAttenuationDistanceModel DistanceAlgorithm; // Offset: 0x8 | Size: 0x1
	enum class EAttenuationShape AttenuationShape; // Offset: 0x9 | Size: 0x1
	char pad_0xA[0x2]; // Offset: 0xa | Size: 0x2
	float dBAttenuationAtMax; // Offset: 0xc | Size: 0x4
	enum class ENaturalSoundFalloffMode FalloffMode; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x3]; // Offset: 0x11 | Size: 0x3
	struct FVector AttenuationShapeExtents; // Offset: 0x14 | Size: 0xc
	float ConeOffset; // Offset: 0x20 | Size: 0x4
	float FalloffDistance; // Offset: 0x24 | Size: 0x4
	struct FRuntimeFloatCurve CustomAttenuationCurve; // Offset: 0x28 | Size: 0x88
};

// Object: ScriptStruct Engine.AudioComponentParam
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FAudioComponentParam {
	// Fields
	struct FName ParamName; // Offset: 0x0 | Size: 0x8
	float FloatParam; // Offset: 0x8 | Size: 0x4
	bool BoolParam; // Offset: 0xc | Size: 0x1
	char pad_0xD[0x3]; // Offset: 0xd | Size: 0x3
	int32_t IntParam; // Offset: 0x10 | Size: 0x4
	char pad_0x14[0x4]; // Offset: 0x14 | Size: 0x4
	struct USoundWave* SoundWaveParam; // Offset: 0x18 | Size: 0x8
};

// Object: ScriptStruct Engine.AudioEffectParameters
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FAudioEffectParameters {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
};

// Object: ScriptStruct Engine.AudioReverbEffect
// Inherited Bytes: 0x8 | Struct Size: 0x48
struct FAudioReverbEffect : FAudioEffectParameters {
	// Fields
	char pad_0x8[0x40]; // Offset: 0x8 | Size: 0x40
};

// Object: ScriptStruct Engine.AudioQualitySettings
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FAudioQualitySettings {
	// Fields
	struct FText DisplayName; // Offset: 0x0 | Size: 0x18
	int32_t MaxChannels; // Offset: 0x18 | Size: 0x4
	char pad_0x1C[0x4]; // Offset: 0x1c | Size: 0x4
};

// Object: ScriptStruct Engine.InteriorSettings
// Inherited Bytes: 0x0 | Struct Size: 0x24
struct FInteriorSettings {
	// Fields
	bool bIsWorldSettings; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	float ExteriorVolume; // Offset: 0x4 | Size: 0x4
	float ExteriorTime; // Offset: 0x8 | Size: 0x4
	float ExteriorLPF; // Offset: 0xc | Size: 0x4
	float ExteriorLPFTime; // Offset: 0x10 | Size: 0x4
	float InteriorVolume; // Offset: 0x14 | Size: 0x4
	float InteriorTime; // Offset: 0x18 | Size: 0x4
	float InteriorLPF; // Offset: 0x1c | Size: 0x4
	float InteriorLPFTime; // Offset: 0x20 | Size: 0x4
};

// Object: ScriptStruct Engine.LaunchOnTestSettings
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FLaunchOnTestSettings {
	// Fields
	struct FFilePath LaunchOnTestmap; // Offset: 0x0 | Size: 0x10
	struct FString DeviceID; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct Engine.EditorMapPerformanceTestDefinition
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FEditorMapPerformanceTestDefinition {
	// Fields
	struct FSoftObjectPath PerformanceTestmap; // Offset: 0x0 | Size: 0x18
	int32_t TestTimer; // Offset: 0x18 | Size: 0x4
	char pad_0x1C[0x4]; // Offset: 0x1c | Size: 0x4
};

// Object: ScriptStruct Engine.BuildPromotionTestSettings
// Inherited Bytes: 0x0 | Struct Size: 0x1f0
struct FBuildPromotionTestSettings {
	// Fields
	struct FFilePath DefaultStaticMeshAsset; // Offset: 0x0 | Size: 0x10
	struct FBuildPromotionImportWorkflowSettings ImportWorkflow; // Offset: 0x10 | Size: 0x150
	struct FBuildPromotionOpenAssetSettings OpenAssets; // Offset: 0x160 | Size: 0x60
	struct FBuildPromotionNewProjectSettings NewProjectSettings; // Offset: 0x1c0 | Size: 0x20
	struct FFilePath SourceControlMaterial; // Offset: 0x1e0 | Size: 0x10
};

// Object: ScriptStruct Engine.BuildPromotionNewProjectSettings
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FBuildPromotionNewProjectSettings {
	// Fields
	struct FDirectoryPath NewProjectFolderOverride; // Offset: 0x0 | Size: 0x10
	struct FString NewProjectNameOverride; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct Engine.BuildPromotionOpenAssetSettings
// Inherited Bytes: 0x0 | Struct Size: 0x60
struct FBuildPromotionOpenAssetSettings {
	// Fields
	struct FFilePath BlueprintAsset; // Offset: 0x0 | Size: 0x10
	struct FFilePath MaterialAsset; // Offset: 0x10 | Size: 0x10
	struct FFilePath ParticleSystemAsset; // Offset: 0x20 | Size: 0x10
	struct FFilePath SkeletalMeshAsset; // Offset: 0x30 | Size: 0x10
	struct FFilePath StaticMeshAsset; // Offset: 0x40 | Size: 0x10
	struct FFilePath TextureAsset; // Offset: 0x50 | Size: 0x10
};

// Object: ScriptStruct Engine.BuildPromotionImportWorkflowSettings
// Inherited Bytes: 0x0 | Struct Size: 0x150
struct FBuildPromotionImportWorkflowSettings {
	// Fields
	struct FEditorImportWorkflowDefinition Diffuse; // Offset: 0x0 | Size: 0x20
	struct FEditorImportWorkflowDefinition Normal; // Offset: 0x20 | Size: 0x20
	struct FEditorImportWorkflowDefinition StaticMesh; // Offset: 0x40 | Size: 0x20
	struct FEditorImportWorkflowDefinition ReimportStaticMesh; // Offset: 0x60 | Size: 0x20
	struct FEditorImportWorkflowDefinition BlendShapeMesh; // Offset: 0x80 | Size: 0x20
	struct FEditorImportWorkflowDefinition MorphMesh; // Offset: 0xa0 | Size: 0x20
	struct FEditorImportWorkflowDefinition SkeletalMesh; // Offset: 0xc0 | Size: 0x20
	struct FEditorImportWorkflowDefinition Animation; // Offset: 0xe0 | Size: 0x20
	struct FEditorImportWorkflowDefinition Sound; // Offset: 0x100 | Size: 0x20
	struct FEditorImportWorkflowDefinition SurroundSound; // Offset: 0x120 | Size: 0x20
	struct TArray<struct FEditorImportWorkflowDefinition> OtherAssetsToImport; // Offset: 0x140 | Size: 0x10
};

// Object: ScriptStruct Engine.EditorImportWorkflowDefinition
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FEditorImportWorkflowDefinition {
	// Fields
	struct FFilePath ImportFilePath; // Offset: 0x0 | Size: 0x10
	struct TArray<struct FImportFactorySettingValues> FactorySettings; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct Engine.ImportFactorySettingValues
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FImportFactorySettingValues {
	// Fields
	struct FString SettingName; // Offset: 0x0 | Size: 0x10
	struct FString Value; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct Engine.BlueprintEditorPromotionSettings
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FBlueprintEditorPromotionSettings {
	// Fields
	struct FFilePath FirstMeshPath; // Offset: 0x0 | Size: 0x10
	struct FFilePath SecondMeshPath; // Offset: 0x10 | Size: 0x10
	struct FFilePath DefaultParticleAsset; // Offset: 0x20 | Size: 0x10
};

// Object: ScriptStruct Engine.ParticleEditorPromotionSettings
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FParticleEditorPromotionSettings {
	// Fields
	struct FFilePath DefaultParticleAsset; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Engine.MaterialEditorPromotionSettings
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FMaterialEditorPromotionSettings {
	// Fields
	struct FFilePath DefaultMaterialAsset; // Offset: 0x0 | Size: 0x10
	struct FFilePath DefaultDiffuseTexture; // Offset: 0x10 | Size: 0x10
	struct FFilePath DefaultNormalTexture; // Offset: 0x20 | Size: 0x10
};

// Object: ScriptStruct Engine.EditorImportExportTestDefinition
// Inherited Bytes: 0x0 | Struct Size: 0x38
struct FEditorImportExportTestDefinition {
	// Fields
	struct FFilePath ImportFilePath; // Offset: 0x0 | Size: 0x10
	struct FString ExportFileExtension; // Offset: 0x10 | Size: 0x10
	bool bSkipExport; // Offset: 0x20 | Size: 0x1
	char pad_0x21[0x7]; // Offset: 0x21 | Size: 0x7
	struct TArray<struct FImportFactorySettingValues> FactorySettings; // Offset: 0x28 | Size: 0x10
};

// Object: ScriptStruct Engine.ExternalToolDefinition
// Inherited Bytes: 0x0 | Struct Size: 0x60
struct FExternalToolDefinition {
	// Fields
	struct FString ToolName; // Offset: 0x0 | Size: 0x10
	struct FFilePath ExecutablePath; // Offset: 0x10 | Size: 0x10
	struct FString CommandLineOptions; // Offset: 0x20 | Size: 0x10
	struct FDirectoryPath WorkingDirectory; // Offset: 0x30 | Size: 0x10
	struct FString ScriptExtension; // Offset: 0x40 | Size: 0x10
	struct FDirectoryPath ScriptDirectory; // Offset: 0x50 | Size: 0x10
};

// Object: ScriptStruct Engine.NavAvoidanceData
// Inherited Bytes: 0x0 | Struct Size: 0x3c
struct FNavAvoidanceData {
	// Fields
	char pad_0x0[0x3c]; // Offset: 0x0 | Size: 0x3c
};

// Object: ScriptStruct Engine.BandwidthTestGenerator
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FBandwidthTestGenerator {
	// Fields
	struct TArray<struct FBandwidthTestItem> ReplicatedBuffers; // Offset: 0x0 | Size: 0x10
	char pad_0x10[0x10]; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct Engine.BandwidthTestItem
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FBandwidthTestItem {
	// Fields
	struct TArray<char> Kilobyte; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Engine.BlendProfileBoneEntry
// Inherited Bytes: 0x0 | Struct Size: 0x14
struct FBlendProfileBoneEntry {
	// Fields
	struct FBoneReference BoneReference; // Offset: 0x0 | Size: 0x10
	float BlendScale; // Offset: 0x10 | Size: 0x4
};

// Object: ScriptStruct Engine.PerBoneInterpolation
// Inherited Bytes: 0x0 | Struct Size: 0x14
struct FPerBoneInterpolation {
	// Fields
	struct FBoneReference BoneReference; // Offset: 0x0 | Size: 0x10
	float InterpolationSpeedPerSec; // Offset: 0x10 | Size: 0x4
};

// Object: ScriptStruct Engine.GridBlendSample
// Inherited Bytes: 0x0 | Struct Size: 0x1c
struct FGridBlendSample {
	// Fields
	struct FEditorElement GridElement; // Offset: 0x0 | Size: 0x18
	float BlendWeight; // Offset: 0x18 | Size: 0x4
};

// Object: ScriptStruct Engine.EditorElement
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FEditorElement {
	// Fields
	int32_t Indices[0x3]; // Offset: 0x0 | Size: 0xc
	float Weights[0x3]; // Offset: 0xc | Size: 0xc
};

// Object: ScriptStruct Engine.BlendSample
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FBlendSample {
	// Fields
	struct UAnimSequence* Animation; // Offset: 0x0 | Size: 0x8
	struct FVector SampleValue; // Offset: 0x8 | Size: 0xc
	float RateScale; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct Engine.BlendParameter
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FBlendParameter {
	// Fields
	struct FString DisplayName; // Offset: 0x0 | Size: 0x10
	float Min; // Offset: 0x10 | Size: 0x4
	float Max; // Offset: 0x14 | Size: 0x4
	int32_t GridNum; // Offset: 0x18 | Size: 0x4
	char pad_0x1C[0x4]; // Offset: 0x1c | Size: 0x4
};

// Object: ScriptStruct Engine.InterpolationParameter
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FInterpolationParameter {
	// Fields
	float InterpolationTime; // Offset: 0x0 | Size: 0x4
	enum class EFilterInterpolationType InterpolationType; // Offset: 0x4 | Size: 0x1
	char pad_0x5[0x3]; // Offset: 0x5 | Size: 0x3
};

// Object: ScriptStruct Engine.BPEditorBookmarkNode
// Inherited Bytes: 0x0 | Struct Size: 0x38
struct FBPEditorBookmarkNode {
	// Fields
	struct FGuid NodeGuid; // Offset: 0x0 | Size: 0x10
	struct FGuid ParentGuid; // Offset: 0x10 | Size: 0x10
	struct FText DisplayName; // Offset: 0x20 | Size: 0x18
};

// Object: ScriptStruct Engine.EditedDocumentInfo
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FEditedDocumentInfo {
	// Fields
	struct FSoftObjectPath EditedObjectPath; // Offset: 0x0 | Size: 0x18
	struct FVector2D SavedViewOffset; // Offset: 0x18 | Size: 0x8
	float SavedZoomAmount; // Offset: 0x20 | Size: 0x4
	char pad_0x24[0x4]; // Offset: 0x24 | Size: 0x4
	struct UObject* EditedObject; // Offset: 0x28 | Size: 0x8
};

// Object: ScriptStruct Engine.BPInterfaceDescription
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FBPInterfaceDescription {
	// Fields
	struct UInterface* Interface; // Offset: 0x0 | Size: 0x8
	struct TArray<struct UEdGraph*> Graphs; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct Engine.BPVariableDescription
// Inherited Bytes: 0x0 | Struct Size: 0xd0
struct FBPVariableDescription {
	// Fields
	struct FName VarName; // Offset: 0x0 | Size: 0x8
	struct FGuid VarGuid; // Offset: 0x8 | Size: 0x10
	struct FEdGraphPinType VarType; // Offset: 0x18 | Size: 0x58
	struct FString FriendlyName; // Offset: 0x70 | Size: 0x10
	struct FText Category; // Offset: 0x80 | Size: 0x18
	uint64_t PropertyFlags; // Offset: 0x98 | Size: 0x8
	struct FName RepNotifyFunc; // Offset: 0xa0 | Size: 0x8
	enum class ELifetimeCondition ReplicationCondition; // Offset: 0xa8 | Size: 0x1
	char pad_0xA9[0x7]; // Offset: 0xa9 | Size: 0x7
	struct TArray<struct FBPVariableMetaDataEntry> MetaDataArray; // Offset: 0xb0 | Size: 0x10
	struct FString DefaultValue; // Offset: 0xc0 | Size: 0x10
};

// Object: ScriptStruct Engine.BPVariableMetaDataEntry
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FBPVariableMetaDataEntry {
	// Fields
	struct FName DataKey; // Offset: 0x0 | Size: 0x8
	struct FString DataValue; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct Engine.EdGraphPinType
// Inherited Bytes: 0x0 | Struct Size: 0x58
struct FEdGraphPinType {
	// Fields
	struct FName PinCategory; // Offset: 0x0 | Size: 0x8
	struct FName PinSubCategory; // Offset: 0x8 | Size: 0x8
	struct TWeakObjectPtr<struct UObject> PinSubCategoryObject; // Offset: 0x10 | Size: 0x8
	struct FSimpleMemberReference PinSubCategoryMemberReference; // Offset: 0x18 | Size: 0x20
	struct FEdGraphTerminalType PinValueType; // Offset: 0x38 | Size: 0x1c
	enum class EPinContainerType ContainerType; // Offset: 0x54 | Size: 0x1
	char bIsArray : 1; // Offset: 0x55 | Size: 0x1
	char bIsReference : 1; // Offset: 0x55 | Size: 0x1
	char bIsConst : 1; // Offset: 0x55 | Size: 0x1
	char bIsWeakPointer : 1; // Offset: 0x55 | Size: 0x1
	char pad_0x55_4 : 4; // Offset: 0x55 | Size: 0x1
	char pad_0x56[0x2]; // Offset: 0x56 | Size: 0x2
};

// Object: ScriptStruct Engine.EdGraphTerminalType
// Inherited Bytes: 0x0 | Struct Size: 0x1c
struct FEdGraphTerminalType {
	// Fields
	struct FName TerminalCategory; // Offset: 0x0 | Size: 0x8
	struct FName TerminalSubCategory; // Offset: 0x8 | Size: 0x8
	struct TWeakObjectPtr<struct UObject> TerminalSubCategoryObject; // Offset: 0x10 | Size: 0x8
	bool bTerminalIsConst; // Offset: 0x18 | Size: 0x1
	bool bTerminalIsWeakPointer; // Offset: 0x19 | Size: 0x1
	char pad_0x1A[0x2]; // Offset: 0x1a | Size: 0x2
};

// Object: ScriptStruct Engine.BlueprintMacroCosmeticInfo
// Inherited Bytes: 0x0 | Struct Size: 0x1
struct FBlueprintMacroCosmeticInfo {
	// Fields
	char pad_0x0[0x1]; // Offset: 0x0 | Size: 0x1
};

// Object: ScriptStruct Engine.CompilerNativizationOptions
// Inherited Bytes: 0x0 | Struct Size: 0x80
struct FCompilerNativizationOptions {
	// Fields
	struct FName PlatformName; // Offset: 0x0 | Size: 0x8
	bool ServerOnlyPlatform; // Offset: 0x8 | Size: 0x1
	bool ClientOnlyPlatform; // Offset: 0x9 | Size: 0x1
	bool bExcludeMonolithicHeaders; // Offset: 0xa | Size: 0x1
	char pad_0xB[0x5]; // Offset: 0xb | Size: 0x5
	struct TArray<struct FName> ExcludedModules; // Offset: 0x10 | Size: 0x10
	struct TSet<struct FSoftObjectPath> ExcludedAssets; // Offset: 0x20 | Size: 0x50
	struct TArray<struct FString> ExcludedFolderPaths; // Offset: 0x70 | Size: 0x10
};

// Object: ScriptStruct Engine.BPComponentClassOverride
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FBPComponentClassOverride {
	// Fields
	struct FName ComponentName; // Offset: 0x0 | Size: 0x8
	struct UObject* ComponentClass; // Offset: 0x8 | Size: 0x8
};

// Object: ScriptStruct Engine.BlueprintCookedComponentInstancingData
// Inherited Bytes: 0x0 | Struct Size: 0x48
struct FBlueprintCookedComponentInstancingData {
	// Fields
	struct TArray<struct FBlueprintComponentChangedPropertyInfo> ChangedPropertyList; // Offset: 0x0 | Size: 0x10
	char pad_0x10[0x11]; // Offset: 0x10 | Size: 0x11
	bool bHasValidCookedData; // Offset: 0x21 | Size: 0x1
	char pad_0x22[0x26]; // Offset: 0x22 | Size: 0x26
};

// Object: ScriptStruct Engine.BlueprintComponentChangedPropertyInfo
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FBlueprintComponentChangedPropertyInfo {
	// Fields
	struct FName PropertyName; // Offset: 0x0 | Size: 0x8
	int32_t ArrayIndex; // Offset: 0x8 | Size: 0x4
	char pad_0xC[0x4]; // Offset: 0xc | Size: 0x4
	struct UStruct* PropertyScope; // Offset: 0x10 | Size: 0x8
};

// Object: ScriptStruct Engine.EventGraphFastCallPair
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FEventGraphFastCallPair {
	// Fields
	struct UFunction* FunctionToPatch; // Offset: 0x0 | Size: 0x8
	int32_t EventGraphCallOffset; // Offset: 0x8 | Size: 0x4
	char pad_0xC[0x4]; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct Engine.BlueprintDebugData
// Inherited Bytes: 0x0 | Struct Size: 0x1
struct FBlueprintDebugData {
	// Fields
	char pad_0x0[0x1]; // Offset: 0x0 | Size: 0x1
};

// Object: ScriptStruct Engine.PointerToUberGraphFrame
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FPointerToUberGraphFrame {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
};

// Object: ScriptStruct Engine.DebuggingInfoForSingleFunction
// Inherited Bytes: 0x0 | Struct Size: 0x190
struct FDebuggingInfoForSingleFunction {
	// Fields
	char pad_0x0[0x190]; // Offset: 0x0 | Size: 0x190
};

// Object: ScriptStruct Engine.NodeToCodeAssociation
// Inherited Bytes: 0x0 | Struct Size: 0x14
struct FNodeToCodeAssociation {
	// Fields
	char pad_0x0[0x14]; // Offset: 0x0 | Size: 0x14
};

// Object: ScriptStruct Engine.AnimCurveType
// Inherited Bytes: 0x0 | Struct Size: 0x2
struct FAnimCurveType {
	// Fields
	char pad_0x0[0x2]; // Offset: 0x0 | Size: 0x2
};

// Object: ScriptStruct Engine.BookmarkBaseJumpToSettings
// Inherited Bytes: 0x0 | Struct Size: 0x1
struct FBookmarkBaseJumpToSettings {
	// Fields
	char pad_0x0[0x1]; // Offset: 0x0 | Size: 0x1
};

// Object: ScriptStruct Engine.BookmarkJumpToSettings
// Inherited Bytes: 0x1 | Struct Size: 0x1
struct FBookmarkJumpToSettings : FBookmarkBaseJumpToSettings {
};

// Object: ScriptStruct Engine.Bookmark2DJumpToSettings
// Inherited Bytes: 0x0 | Struct Size: 0x1
struct FBookmark2DJumpToSettings {
	// Fields
	char pad_0x0[0x1]; // Offset: 0x0 | Size: 0x1
};

// Object: ScriptStruct Engine.GeomSelection
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FGeomSelection {
	// Fields
	int32_t Type; // Offset: 0x0 | Size: 0x4
	int32_t Index; // Offset: 0x4 | Size: 0x4
	int32_t SelectionIndex; // Offset: 0x8 | Size: 0x4
};

// Object: ScriptStruct Engine.BuilderPoly
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FBuilderPoly {
	// Fields
	struct TArray<int32_t> VertexIndices; // Offset: 0x0 | Size: 0x10
	int32_t Direction; // Offset: 0x10 | Size: 0x4
	struct FName ItemName; // Offset: 0x14 | Size: 0x8
	int32_t PolyFlags; // Offset: 0x1c | Size: 0x4
};

// Object: ScriptStruct Engine.CachedAnimTransitionData
// Inherited Bytes: 0x0 | Struct Size: 0x24
struct FCachedAnimTransitionData {
	// Fields
	struct FName StateMachineName; // Offset: 0x0 | Size: 0x8
	struct FName FromStateName; // Offset: 0x8 | Size: 0x8
	struct FName ToStateName; // Offset: 0x10 | Size: 0x8
	char pad_0x18[0xc]; // Offset: 0x18 | Size: 0xc
};

// Object: ScriptStruct Engine.CachedAnimRelevancyData
// Inherited Bytes: 0x0 | Struct Size: 0x1c
struct FCachedAnimRelevancyData {
	// Fields
	struct FName StateMachineName; // Offset: 0x0 | Size: 0x8
	struct FName StateName; // Offset: 0x8 | Size: 0x8
	char pad_0x10[0xc]; // Offset: 0x10 | Size: 0xc
};

// Object: ScriptStruct Engine.CachedAnimAssetPlayerData
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FCachedAnimAssetPlayerData {
	// Fields
	struct FName StateMachineName; // Offset: 0x0 | Size: 0x8
	struct FName StateName; // Offset: 0x8 | Size: 0x8
	char pad_0x10[0x8]; // Offset: 0x10 | Size: 0x8
};

// Object: ScriptStruct Engine.CachedAnimStateArray
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FCachedAnimStateArray {
	// Fields
	struct TArray<struct FCachedAnimStateData> States; // Offset: 0x0 | Size: 0x10
	char pad_0x10[0x8]; // Offset: 0x10 | Size: 0x8
};

// Object: ScriptStruct Engine.CachedAnimStateData
// Inherited Bytes: 0x0 | Struct Size: 0x1c
struct FCachedAnimStateData {
	// Fields
	struct FName StateMachineName; // Offset: 0x0 | Size: 0x8
	struct FName StateName; // Offset: 0x8 | Size: 0x8
	char pad_0x10[0xc]; // Offset: 0x10 | Size: 0xc
};

// Object: ScriptStruct Engine.ActiveCameraShakeInfo
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FActiveCameraShakeInfo {
	// Fields
	struct UCameraShake* ShakeInstance; // Offset: 0x0 | Size: 0x8
	struct TWeakObjectPtr<struct UCameraShakeSourceComponent> ShakeSource; // Offset: 0x8 | Size: 0x8
};

// Object: ScriptStruct Engine.PooledCameraShakes
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FPooledCameraShakes {
	// Fields
	struct TArray<struct UCameraShake*> PooledShakes; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Engine.VOscillator
// Inherited Bytes: 0x0 | Struct Size: 0x24
struct FVOscillator {
	// Fields
	struct FFOscillator X; // Offset: 0x0 | Size: 0xc
	struct FFOscillator Y; // Offset: 0xc | Size: 0xc
	struct FFOscillator Z; // Offset: 0x18 | Size: 0xc
};

// Object: ScriptStruct Engine.FOscillator
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FFOscillator {
	// Fields
	float Amplitude; // Offset: 0x0 | Size: 0x4
	float Frequency; // Offset: 0x4 | Size: 0x4
	enum class EInitialOscillatorOffset InitialOffset; // Offset: 0x8 | Size: 0x1
	enum class EOscillatorWaveform Waveform; // Offset: 0x9 | Size: 0x1
	char pad_0xA[0x2]; // Offset: 0xa | Size: 0x2
};

// Object: ScriptStruct Engine.ROscillator
// Inherited Bytes: 0x0 | Struct Size: 0x24
struct FROscillator {
	// Fields
	struct FFOscillator Pitch; // Offset: 0x0 | Size: 0xc
	struct FFOscillator Yaw; // Offset: 0xc | Size: 0xc
	struct FFOscillator Roll; // Offset: 0x18 | Size: 0xc
};

// Object: ScriptStruct Engine.DummySpacerCameraTypes
// Inherited Bytes: 0x0 | Struct Size: 0x1
struct FDummySpacerCameraTypes {
	// Fields
	char pad_0x0[0x1]; // Offset: 0x0 | Size: 0x1
};

// Object: ScriptStruct Engine.CanvasIcon
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FCanvasIcon {
	// Fields
	struct UTexture* Texture; // Offset: 0x0 | Size: 0x8
	float U; // Offset: 0x8 | Size: 0x4
	float V; // Offset: 0xc | Size: 0x4
	float UL; // Offset: 0x10 | Size: 0x4
	float VL; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct Engine.WrappedStringElement
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FWrappedStringElement {
	// Fields
	struct FString Value; // Offset: 0x0 | Size: 0x10
	struct FVector2D LineExtent; // Offset: 0x10 | Size: 0x8
};

// Object: ScriptStruct Engine.TextSizingParameters
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FTextSizingParameters {
	// Fields
	float DrawX; // Offset: 0x0 | Size: 0x4
	float DrawY; // Offset: 0x4 | Size: 0x4
	float DrawXL; // Offset: 0x8 | Size: 0x4
	float DrawYL; // Offset: 0xc | Size: 0x4
	struct FVector2D Scaling; // Offset: 0x10 | Size: 0x8
	struct UFont* DrawFont; // Offset: 0x18 | Size: 0x8
	struct FVector2D SpacingAdjust; // Offset: 0x20 | Size: 0x8
};

// Object: ScriptStruct Engine.ChildActorComponentInstanceData
// Inherited Bytes: 0xa8 | Struct Size: 0xd8
struct FChildActorComponentInstanceData : FSceneComponentInstanceData {
	// Fields
	struct AActor* ChildActorClass; // Offset: 0xa8 | Size: 0x8
	struct FName ChildActorName; // Offset: 0xb0 | Size: 0x8
	struct TArray<struct FChildActorAttachedActorInfo> AttachedActors; // Offset: 0xb8 | Size: 0x10
	char pad_0xC8[0x10]; // Offset: 0xc8 | Size: 0x10
};

// Object: ScriptStruct Engine.ChildActorAttachedActorInfo
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FChildActorAttachedActorInfo {
	// Fields
	struct TWeakObjectPtr<struct AActor> Actor; // Offset: 0x0 | Size: 0x8
	struct FName SocketName; // Offset: 0x8 | Size: 0x8
	struct FTransform RelativeTransform; // Offset: 0x10 | Size: 0x30
};

// Object: ScriptStruct Engine.CustomProfile
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FCustomProfile {
	// Fields
	struct FName Name; // Offset: 0x0 | Size: 0x8
	struct TArray<struct FResponseChannel> CustomResponses; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct Engine.CustomChannelSetup
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FCustomChannelSetup {
	// Fields
	enum class ECollisionChannel Channel; // Offset: 0x0 | Size: 0x1
	enum class ECollisionResponse DefaultResponse; // Offset: 0x1 | Size: 0x1
	bool bTraceType; // Offset: 0x2 | Size: 0x1
	bool bStaticObject; // Offset: 0x3 | Size: 0x1
	struct FName Name; // Offset: 0x4 | Size: 0x8
};

// Object: ScriptStruct Engine.CollisionResponseTemplate
// Inherited Bytes: 0x0 | Struct Size: 0x48
struct FCollisionResponseTemplate {
	// Fields
	struct FName Name; // Offset: 0x0 | Size: 0x8
	enum class ECollisionEnabled CollisionEnabled; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x1]; // Offset: 0x9 | Size: 0x1
	bool bCanModify; // Offset: 0xa | Size: 0x1
	char pad_0xB[0x21]; // Offset: 0xb | Size: 0x21
	struct FName ObjectTypeName; // Offset: 0x2c | Size: 0x8
	char pad_0x34[0x4]; // Offset: 0x34 | Size: 0x4
	struct TArray<struct FResponseChannel> CustomResponses; // Offset: 0x38 | Size: 0x10
};

// Object: ScriptStruct Engine.BlueprintComponentDelegateBinding
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FBlueprintComponentDelegateBinding {
	// Fields
	struct FName ComponentPropertyName; // Offset: 0x0 | Size: 0x8
	struct FName DelegatePropertyName; // Offset: 0x8 | Size: 0x8
	struct FName FunctionNameToBind; // Offset: 0x10 | Size: 0x8
};

// Object: ScriptStruct Engine.MeshUVChannelInfo
// Inherited Bytes: 0x0 | Struct Size: 0x14
struct FMeshUVChannelInfo {
	// Fields
	bool bInitialized; // Offset: 0x0 | Size: 0x1
	bool bOverrideDensities; // Offset: 0x1 | Size: 0x1
	char pad_0x2[0x2]; // Offset: 0x2 | Size: 0x2
	float LocalUVDensities[0x4]; // Offset: 0x4 | Size: 0x10
};

// Object: ScriptStruct Engine.AutoCompleteNode
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FAutoCompleteNode {
	// Fields
	int32_t IndexChar; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct TArray<int32_t> AutoCompleteListIndices; // Offset: 0x8 | Size: 0x10
	char pad_0x18[0x10]; // Offset: 0x18 | Size: 0x10
};

// Object: ScriptStruct Engine.AngularDriveConstraint
// Inherited Bytes: 0x0 | Struct Size: 0x4c
struct FAngularDriveConstraint {
	// Fields
	struct FConstraintDrive TwistDrive; // Offset: 0x0 | Size: 0x10
	struct FConstraintDrive SwingDrive; // Offset: 0x10 | Size: 0x10
	struct FConstraintDrive SlerpDrive; // Offset: 0x20 | Size: 0x10
	struct FRotator OrientationTarget; // Offset: 0x30 | Size: 0xc
	struct FVector AngularVelocityTarget; // Offset: 0x3c | Size: 0xc
	enum class EAngularDriveMode AngularDriveMode; // Offset: 0x48 | Size: 0x1
	char pad_0x49[0x3]; // Offset: 0x49 | Size: 0x3
};

// Object: ScriptStruct Engine.ConstraintDrive
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FConstraintDrive {
	// Fields
	float Stiffness; // Offset: 0x0 | Size: 0x4
	float Damping; // Offset: 0x4 | Size: 0x4
	float MaxForce; // Offset: 0x8 | Size: 0x4
	char bEnablePositionDrive : 1; // Offset: 0xc | Size: 0x1
	char bEnableVelocityDrive : 1; // Offset: 0xc | Size: 0x1
	char pad_0xC_2 : 6; // Offset: 0xc | Size: 0x1
	char pad_0xD[0x3]; // Offset: 0xd | Size: 0x3
};

// Object: ScriptStruct Engine.LinearDriveConstraint
// Inherited Bytes: 0x0 | Struct Size: 0x4c
struct FLinearDriveConstraint {
	// Fields
	struct FVector PositionTarget; // Offset: 0x0 | Size: 0xc
	struct FVector VelocityTarget; // Offset: 0xc | Size: 0xc
	struct FConstraintDrive XDrive; // Offset: 0x18 | Size: 0x10
	struct FConstraintDrive YDrive; // Offset: 0x28 | Size: 0x10
	struct FConstraintDrive ZDrive; // Offset: 0x38 | Size: 0x10
	char bEnablePositionDrive : 1; // Offset: 0x48 | Size: 0x1
	char pad_0x48_1 : 7; // Offset: 0x48 | Size: 0x1
	char pad_0x49[0x3]; // Offset: 0x49 | Size: 0x3
};

// Object: ScriptStruct Engine.ConstraintInstance
// Inherited Bytes: 0x0 | Struct Size: 0x1b8
struct FConstraintInstance {
	// Fields
	char pad_0x0[0x18]; // Offset: 0x0 | Size: 0x18
	struct FName JointName; // Offset: 0x18 | Size: 0x8
	struct FName ConstraintBone1; // Offset: 0x20 | Size: 0x8
	struct FName ConstraintBone2; // Offset: 0x28 | Size: 0x8
	struct FVector Pos1; // Offset: 0x30 | Size: 0xc
	struct FVector PriAxis1; // Offset: 0x3c | Size: 0xc
	struct FVector SecAxis1; // Offset: 0x48 | Size: 0xc
	struct FVector Pos2; // Offset: 0x54 | Size: 0xc
	struct FVector PriAxis2; // Offset: 0x60 | Size: 0xc
	struct FVector SecAxis2; // Offset: 0x6c | Size: 0xc
	struct FRotator AngularRotationOffset; // Offset: 0x78 | Size: 0xc
	char bScaleLinearLimits : 1; // Offset: 0x84 | Size: 0x1
	char pad_0x84_1 : 7; // Offset: 0x84 | Size: 0x1
	char pad_0x85[0x7]; // Offset: 0x85 | Size: 0x7
	struct FConstraintProfileProperties ProfileInstance; // Offset: 0x8c | Size: 0x104
	char pad_0x190[0x28]; // Offset: 0x190 | Size: 0x28
};

// Object: ScriptStruct Engine.ConstraintProfileProperties
// Inherited Bytes: 0x0 | Struct Size: 0x104
struct FConstraintProfileProperties {
	// Fields
	float ProjectionLinearTolerance; // Offset: 0x0 | Size: 0x4
	float ProjectionAngularTolerance; // Offset: 0x4 | Size: 0x4
	float LinearBreakThreshold; // Offset: 0x8 | Size: 0x4
	float AngularBreakThreshold; // Offset: 0xc | Size: 0x4
	struct FLinearConstraint LinearLimit; // Offset: 0x10 | Size: 0x1c
	struct FConeConstraint ConeLimit; // Offset: 0x2c | Size: 0x20
	struct FTwistConstraint TwistLimit; // Offset: 0x4c | Size: 0x1c
	struct FLinearDriveConstraint LinearDrive; // Offset: 0x68 | Size: 0x4c
	struct FAngularDriveConstraint AngularDrive; // Offset: 0xb4 | Size: 0x4c
	char bDisableCollision : 1; // Offset: 0x100 | Size: 0x1
	char bParentDominates : 1; // Offset: 0x100 | Size: 0x1
	char bEnableProjection : 1; // Offset: 0x100 | Size: 0x1
	char bAngularBreakable : 1; // Offset: 0x100 | Size: 0x1
	char bLinearBreakable : 1; // Offset: 0x100 | Size: 0x1
	char pad_0x100_5 : 3; // Offset: 0x100 | Size: 0x1
	char pad_0x101[0x3]; // Offset: 0x101 | Size: 0x3
};

// Object: ScriptStruct Engine.ConstraintBaseParams
// Inherited Bytes: 0x0 | Struct Size: 0x14
struct FConstraintBaseParams {
	// Fields
	float Stiffness; // Offset: 0x0 | Size: 0x4
	float Damping; // Offset: 0x4 | Size: 0x4
	float Restitution; // Offset: 0x8 | Size: 0x4
	float ContactDistance; // Offset: 0xc | Size: 0x4
	char bSoftConstraint : 1; // Offset: 0x10 | Size: 0x1
	char pad_0x10_1 : 7; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x3]; // Offset: 0x11 | Size: 0x3
};

// Object: ScriptStruct Engine.TwistConstraint
// Inherited Bytes: 0x14 | Struct Size: 0x1c
struct FTwistConstraint : FConstraintBaseParams {
	// Fields
	float TwistLimitDegrees; // Offset: 0x14 | Size: 0x4
	enum class EAngularConstraintMotion TwistMotion; // Offset: 0x18 | Size: 0x1
	char pad_0x19[0x3]; // Offset: 0x19 | Size: 0x3
};

// Object: ScriptStruct Engine.ConeConstraint
// Inherited Bytes: 0x14 | Struct Size: 0x20
struct FConeConstraint : FConstraintBaseParams {
	// Fields
	float Swing1LimitDegrees; // Offset: 0x14 | Size: 0x4
	float Swing2LimitDegrees; // Offset: 0x18 | Size: 0x4
	enum class EAngularConstraintMotion Swing1Motion; // Offset: 0x1c | Size: 0x1
	enum class EAngularConstraintMotion Swing2Motion; // Offset: 0x1d | Size: 0x1
	char pad_0x1E[0x2]; // Offset: 0x1e | Size: 0x2
};

// Object: ScriptStruct Engine.LinearConstraint
// Inherited Bytes: 0x14 | Struct Size: 0x1c
struct FLinearConstraint : FConstraintBaseParams {
	// Fields
	float Limit; // Offset: 0x14 | Size: 0x4
	enum class ELinearConstraintMotion XMotion; // Offset: 0x18 | Size: 0x1
	enum class ELinearConstraintMotion YMotion; // Offset: 0x19 | Size: 0x1
	enum class ELinearConstraintMotion ZMotion; // Offset: 0x1a | Size: 0x1
	char pad_0x1B[0x1]; // Offset: 0x1b | Size: 0x1
};

// Object: ScriptStruct Engine.CullDistanceSizePair
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FCullDistanceSizePair {
	// Fields
	float Size; // Offset: 0x0 | Size: 0x4
	float CullDistance; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct Engine.NamedCurveValue
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FNamedCurveValue {
	// Fields
	struct FName Name; // Offset: 0x0 | Size: 0x8
	float Value; // Offset: 0x8 | Size: 0x4
};

// Object: ScriptStruct Engine.DataTableCategoryHandle
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FDataTableCategoryHandle {
	// Fields
	struct UDataTable* DataTable; // Offset: 0x0 | Size: 0x8
	struct FName ColumnName; // Offset: 0x8 | Size: 0x8
	struct FName RowContents; // Offset: 0x10 | Size: 0x8
};

// Object: ScriptStruct Engine.DebugCameraControllerSettingsViewModeIndex
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FDebugCameraControllerSettingsViewModeIndex {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
	enum class EViewModeIndex ViewModeIndex; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x7]; // Offset: 0x9 | Size: 0x7
};

// Object: ScriptStruct Engine.DebugDisplayProperty
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FDebugDisplayProperty {
	// Fields
	struct UObject* Obj; // Offset: 0x0 | Size: 0x8
	struct UObject* WithinClass; // Offset: 0x8 | Size: 0x8
	char pad_0x10[0x10]; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct Engine.DebugTextInfo
// Inherited Bytes: 0x0 | Struct Size: 0x60
struct FDebugTextInfo {
	// Fields
	struct AActor* SrcActor; // Offset: 0x0 | Size: 0x8
	struct FVector SrcActorOffset; // Offset: 0x8 | Size: 0xc
	struct FVector SrcActorDesiredOffset; // Offset: 0x14 | Size: 0xc
	struct FString DebugText; // Offset: 0x20 | Size: 0x10
	float TimeRemaining; // Offset: 0x30 | Size: 0x4
	float Duration; // Offset: 0x34 | Size: 0x4
	struct FColor TextColor; // Offset: 0x38 | Size: 0x4
	char bAbsoluteLocation : 1; // Offset: 0x3c | Size: 0x1
	char bKeepAttachedToActor : 1; // Offset: 0x3c | Size: 0x1
	char bDrawShadow : 1; // Offset: 0x3c | Size: 0x1
	char pad_0x3C_3 : 5; // Offset: 0x3c | Size: 0x1
	char pad_0x3D[0x3]; // Offset: 0x3d | Size: 0x3
	struct FVector OrigActorLocation; // Offset: 0x40 | Size: 0xc
	char pad_0x4C[0x4]; // Offset: 0x4c | Size: 0x4
	struct UFont* Font; // Offset: 0x50 | Size: 0x8
	float FontScale; // Offset: 0x58 | Size: 0x4
	char pad_0x5C[0x4]; // Offset: 0x5c | Size: 0x4
};

// Object: ScriptStruct Engine.MulticastRecordOptions
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FMulticastRecordOptions {
	// Fields
	struct FString FuncPathName; // Offset: 0x0 | Size: 0x10
	bool bServerSkip; // Offset: 0x10 | Size: 0x1
	bool bClientSkip; // Offset: 0x11 | Size: 0x1
	char pad_0x12[0x6]; // Offset: 0x12 | Size: 0x6
};

// Object: ScriptStruct Engine.RollbackNetStartupActorInfo
// Inherited Bytes: 0x0 | Struct Size: 0xb0
struct FRollbackNetStartupActorInfo {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
	struct UObject* Archetype; // Offset: 0x8 | Size: 0x8
	char pad_0x10[0x90]; // Offset: 0x10 | Size: 0x90
	struct TArray<struct UObject*> ObjReferences; // Offset: 0xa0 | Size: 0x10
};

// Object: ScriptStruct Engine.MeshDeviceLODSettings
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FMeshDeviceLODSettings {
	// Fields
	struct FName LODGroupName; // Offset: 0x0 | Size: 0x8
	int32_t MinLODToLoad; // Offset: 0x8 | Size: 0x4
};

// Object: ScriptStruct Engine.DialogueWaveParameter
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FDialogueWaveParameter {
	// Fields
	struct UDialogueWave* DialogueWave; // Offset: 0x0 | Size: 0x8
	struct FDialogueContext Context; // Offset: 0x8 | Size: 0x18
};

// Object: ScriptStruct Engine.DialogueContext
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FDialogueContext {
	// Fields
	struct UDialogueVoice* Speaker; // Offset: 0x0 | Size: 0x8
	struct TArray<struct UDialogueVoice*> Targets; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct Engine.DialogueContextMapping
// Inherited Bytes: 0x0 | Struct Size: 0x38
struct FDialogueContextMapping {
	// Fields
	struct FDialogueContext Context; // Offset: 0x0 | Size: 0x18
	struct USoundWave* SoundWave; // Offset: 0x18 | Size: 0x8
	struct FString LocalizationKeyFormat; // Offset: 0x20 | Size: 0x10
	struct UDialogueSoundWaveProxy* Proxy; // Offset: 0x30 | Size: 0x8
};

// Object: ScriptStruct Engine.RawDistributionFloat
// Inherited Bytes: 0x20 | Struct Size: 0x30
struct FRawDistributionFloat : FRawDistribution {
	// Fields
	float MinValue; // Offset: 0x20 | Size: 0x4
	float MaxValue; // Offset: 0x24 | Size: 0x4
	struct UDistributionFloat* Distribution; // Offset: 0x28 | Size: 0x8
};

// Object: ScriptStruct Engine.RawDistributionVector
// Inherited Bytes: 0x20 | Struct Size: 0x48
struct FRawDistributionVector : FRawDistribution {
	// Fields
	float MinValue; // Offset: 0x20 | Size: 0x4
	float MaxValue; // Offset: 0x24 | Size: 0x4
	struct FVector MinValueVec; // Offset: 0x28 | Size: 0xc
	struct FVector MaxValueVec; // Offset: 0x34 | Size: 0xc
	struct UDistributionVector* Distribution; // Offset: 0x40 | Size: 0x8
};

// Object: ScriptStruct Engine.GraphReference
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FGraphReference {
	// Fields
	struct UEdGraph* MacroGraph; // Offset: 0x0 | Size: 0x8
	struct UBlueprint* GraphBlueprint; // Offset: 0x8 | Size: 0x8
	struct FGuid GraphGuid; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct Engine.EdGraphPinReference
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FEdGraphPinReference {
	// Fields
	struct TWeakObjectPtr<struct UEdGraphNode> OwningNode; // Offset: 0x0 | Size: 0x8
	struct FGuid PinId; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct Engine.EdGraphSchemaAction
// Inherited Bytes: 0x0 | Struct Size: 0x100
struct FEdGraphSchemaAction {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
	struct FText MenuDescription; // Offset: 0x8 | Size: 0x18
	struct FText TooltipDescription; // Offset: 0x20 | Size: 0x18
	struct FText Category; // Offset: 0x38 | Size: 0x18
	struct FText Keywords; // Offset: 0x50 | Size: 0x18
	int32_t Grouping; // Offset: 0x68 | Size: 0x4
	int32_t SectionID; // Offset: 0x6c | Size: 0x4
	struct TArray<struct FString> MenuDescriptionArray; // Offset: 0x70 | Size: 0x10
	struct TArray<struct FString> FullSearchTitlesArray; // Offset: 0x80 | Size: 0x10
	struct TArray<struct FString> FullSearchKeywordsArray; // Offset: 0x90 | Size: 0x10
	struct TArray<struct FString> FullSearchCategoryArray; // Offset: 0xa0 | Size: 0x10
	struct TArray<struct FString> LocalizedMenuDescriptionArray; // Offset: 0xb0 | Size: 0x10
	struct TArray<struct FString> LocalizedFullSearchTitlesArray; // Offset: 0xc0 | Size: 0x10
	struct TArray<struct FString> LocalizedFullSearchKeywordsArray; // Offset: 0xd0 | Size: 0x10
	struct TArray<struct FString> LocalizedFullSearchCategoryArray; // Offset: 0xe0 | Size: 0x10
	struct FString SearchText; // Offset: 0xf0 | Size: 0x10
};

// Object: ScriptStruct Engine.EdGraphSchemaAction_NewNode
// Inherited Bytes: 0x100 | Struct Size: 0x108
struct FEdGraphSchemaAction_NewNode : FEdGraphSchemaAction {
	// Fields
	struct UEdGraphNode* NodeTemplate; // Offset: 0x100 | Size: 0x8
};

// Object: ScriptStruct Engine.PluginRedirect
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FPluginRedirect {
	// Fields
	struct FString OldPluginName; // Offset: 0x0 | Size: 0x10
	struct FString NewPluginName; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct Engine.StructRedirect
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FStructRedirect {
	// Fields
	struct FName OldStructName; // Offset: 0x0 | Size: 0x8
	struct FName NewStructName; // Offset: 0x8 | Size: 0x8
};

// Object: ScriptStruct Engine.ClassRedirect
// Inherited Bytes: 0x0 | Struct Size: 0x3c
struct FClassRedirect {
	// Fields
	struct FName ObjectName; // Offset: 0x0 | Size: 0x8
	struct FName OldClassName; // Offset: 0x8 | Size: 0x8
	struct FName NewClassName; // Offset: 0x10 | Size: 0x8
	struct FName OldSubobjName; // Offset: 0x18 | Size: 0x8
	struct FName NewSubobjName; // Offset: 0x20 | Size: 0x8
	struct FName NewClassClass; // Offset: 0x28 | Size: 0x8
	struct FName NewClassPackage; // Offset: 0x30 | Size: 0x8
	bool InstanceOnly; // Offset: 0x38 | Size: 0x1
	char pad_0x39[0x3]; // Offset: 0x39 | Size: 0x3
};

// Object: ScriptStruct Engine.GameNameRedirect
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FGameNameRedirect {
	// Fields
	struct FName OldGameName; // Offset: 0x0 | Size: 0x8
	struct FName NewGameName; // Offset: 0x8 | Size: 0x8
};

// Object: ScriptStruct Engine.ScreenMessageString
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FScreenMessageString {
	// Fields
	uint64_t Key; // Offset: 0x0 | Size: 0x8
	struct FString ScreenMessage; // Offset: 0x8 | Size: 0x10
	struct FColor DisplayColor; // Offset: 0x18 | Size: 0x4
	float TimeToDisplay; // Offset: 0x1c | Size: 0x4
	float CurrentTimeDisplayed; // Offset: 0x20 | Size: 0x4
	struct FVector2D TextScale; // Offset: 0x24 | Size: 0x8
	char pad_0x2C[0x4]; // Offset: 0x2c | Size: 0x4
};

// Object: ScriptStruct Engine.DropNoteInfo
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FDropNoteInfo {
	// Fields
	struct FVector Location; // Offset: 0x0 | Size: 0xc
	struct FRotator Rotation; // Offset: 0xc | Size: 0xc
	struct FString Comment; // Offset: 0x18 | Size: 0x10
};

// Object: ScriptStruct Engine.StatColorMapping
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FStatColorMapping {
	// Fields
	struct FString StatName; // Offset: 0x0 | Size: 0x10
	struct TArray<struct FStatColorMapEntry> ColorMap; // Offset: 0x10 | Size: 0x10
	char DisableBlend : 1; // Offset: 0x20 | Size: 0x1
	char pad_0x20_1 : 7; // Offset: 0x20 | Size: 0x1
	char pad_0x21[0x7]; // Offset: 0x21 | Size: 0x7
};

// Object: ScriptStruct Engine.StatColorMapEntry
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FStatColorMapEntry {
	// Fields
	float In; // Offset: 0x0 | Size: 0x4
	struct FColor Out; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct Engine.WorldContext
// Inherited Bytes: 0x0 | Struct Size: 0x280
struct FWorldContext {
	// Fields
	char pad_0x0[0xd0]; // Offset: 0x0 | Size: 0xd0
	struct FURL LastURL; // Offset: 0xd0 | Size: 0x68
	struct FURL LastRemoteURL; // Offset: 0x138 | Size: 0x68
	struct UPendingNetGame* PendingNetGame; // Offset: 0x1a0 | Size: 0x8
	struct TArray<struct FFullyLoadedPackagesInfo> PackagesToFullyLoad; // Offset: 0x1a8 | Size: 0x10
	char pad_0x1B8[0x10]; // Offset: 0x1b8 | Size: 0x10
	struct TArray<struct ULevel*> LoadedLevelsForPendingMapChange; // Offset: 0x1c8 | Size: 0x10
	char pad_0x1D8[0x18]; // Offset: 0x1d8 | Size: 0x18
	struct TArray<struct UObjectReferencer*> ObjectReferencers; // Offset: 0x1f0 | Size: 0x10
	struct TArray<struct FLevelStreamingStatus> PendingLevelStreamingStatusUpdates; // Offset: 0x200 | Size: 0x10
	struct UGameViewportClient* GameViewport; // Offset: 0x210 | Size: 0x8
	struct UGameInstance* OwningGameInstance; // Offset: 0x218 | Size: 0x8
	struct TArray<struct FNamedNetDriver> ActiveNetDrivers; // Offset: 0x220 | Size: 0x10
	char pad_0x230[0x50]; // Offset: 0x230 | Size: 0x50
};

// Object: ScriptStruct Engine.NamedNetDriver
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FNamedNetDriver {
	// Fields
	struct UNetDriver* NetDriver; // Offset: 0x0 | Size: 0x8
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
};

// Object: ScriptStruct Engine.LevelStreamingStatus
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FLevelStreamingStatus {
	// Fields
	struct FName PackageName; // Offset: 0x0 | Size: 0x8
	char bShouldBeLoaded : 1; // Offset: 0x8 | Size: 0x1
	char bShouldBeVisible : 1; // Offset: 0x8 | Size: 0x1
	char pad_0x8_2 : 6; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x3]; // Offset: 0x9 | Size: 0x3
	uint32_t LODIndex; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct Engine.FullyLoadedPackagesInfo
// Inherited Bytes: 0x0 | Struct Size: 0x38
struct FFullyLoadedPackagesInfo {
	// Fields
	enum class EFullyLoadPackageType FullyLoadType; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x7]; // Offset: 0x1 | Size: 0x7
	struct FString Tag; // Offset: 0x8 | Size: 0x10
	struct TArray<struct FName> PackagesToLoad; // Offset: 0x18 | Size: 0x10
	struct TArray<struct UObject*> LoadedObjects; // Offset: 0x28 | Size: 0x10
};

// Object: ScriptStruct Engine.URL
// Inherited Bytes: 0x0 | Struct Size: 0x68
struct FURL {
	// Fields
	struct FString Protocol; // Offset: 0x0 | Size: 0x10
	struct FString Host; // Offset: 0x10 | Size: 0x10
	int32_t Port; // Offset: 0x20 | Size: 0x4
	int32_t Valid; // Offset: 0x24 | Size: 0x4
	struct FString Map; // Offset: 0x28 | Size: 0x10
	struct FString RedirectURL; // Offset: 0x38 | Size: 0x10
	struct TArray<struct FString> Op; // Offset: 0x48 | Size: 0x10
	struct FString Portal; // Offset: 0x58 | Size: 0x10
};

// Object: ScriptStruct Engine.NetDriverDefinition
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FNetDriverDefinition {
	// Fields
	struct FName DefName; // Offset: 0x0 | Size: 0x8
	struct FName DriverClassName; // Offset: 0x8 | Size: 0x8
	struct FName DriverClassNameFallback; // Offset: 0x10 | Size: 0x8
};

// Object: ScriptStruct Engine.ExposureSettings
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FExposureSettings {
	// Fields
	float FixedEV100; // Offset: 0x0 | Size: 0x4
	bool bFixed; // Offset: 0x4 | Size: 0x1
	char pad_0x5[0x3]; // Offset: 0x5 | Size: 0x3
};

// Object: ScriptStruct Engine.TickPrerequisite
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FTickPrerequisite {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Engine.CanvasUVTri
// Inherited Bytes: 0x0 | Struct Size: 0x60
struct FCanvasUVTri {
	// Fields
	struct FVector2D V0_Pos; // Offset: 0x0 | Size: 0x8
	struct FVector2D V0_UV; // Offset: 0x8 | Size: 0x8
	struct FLinearColor V0_Color; // Offset: 0x10 | Size: 0x10
	struct FVector2D V1_Pos; // Offset: 0x20 | Size: 0x8
	struct FVector2D V1_UV; // Offset: 0x28 | Size: 0x8
	struct FLinearColor V1_Color; // Offset: 0x30 | Size: 0x10
	struct FVector2D V2_Pos; // Offset: 0x40 | Size: 0x8
	struct FVector2D V2_UV; // Offset: 0x48 | Size: 0x8
	struct FLinearColor V2_Color; // Offset: 0x50 | Size: 0x10
};

// Object: ScriptStruct Engine.FontRenderInfo
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FFontRenderInfo {
	// Fields
	char bClipText : 1; // Offset: 0x0 | Size: 0x1
	char bEnableShadow : 1; // Offset: 0x0 | Size: 0x1
	char pad_0x0_2 : 6; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	struct FDepthFieldGlowInfo GlowInfo; // Offset: 0x4 | Size: 0x24
};

// Object: ScriptStruct Engine.DepthFieldGlowInfo
// Inherited Bytes: 0x0 | Struct Size: 0x24
struct FDepthFieldGlowInfo {
	// Fields
	char bEnableGlow : 1; // Offset: 0x0 | Size: 0x1
	char pad_0x0_1 : 7; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	struct FLinearColor GlowColor; // Offset: 0x4 | Size: 0x10
	struct FVector2D GlowOuterRadius; // Offset: 0x14 | Size: 0x8
	struct FVector2D GlowInnerRadius; // Offset: 0x1c | Size: 0x8
};

// Object: ScriptStruct Engine.Redirector
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FRedirector {
	// Fields
	struct FName OldName; // Offset: 0x0 | Size: 0x8
	struct FName NewName; // Offset: 0x8 | Size: 0x8
};

// Object: ScriptStruct Engine.CollectionReference
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FCollectionReference {
	// Fields
	struct FName CollectionName; // Offset: 0x0 | Size: 0x8
};

// Object: ScriptStruct Engine.ComponentReference
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FComponentReference {
	// Fields
	struct AActor* OtherActor; // Offset: 0x0 | Size: 0x8
	struct FName ComponentProperty; // Offset: 0x8 | Size: 0x8
	struct FString PathToComponent; // Offset: 0x10 | Size: 0x10
	char pad_0x20[0x8]; // Offset: 0x20 | Size: 0x8
};

// Object: ScriptStruct Engine.ConstrainComponentPropName
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FConstrainComponentPropName {
	// Fields
	struct FName ComponentName; // Offset: 0x0 | Size: 0x8
};

// Object: ScriptStruct Engine.RadialDamageEvent
// Inherited Bytes: 0x10 | Struct Size: 0x40
struct FRadialDamageEvent : FDamageEvent {
	// Fields
	struct FRadialDamageParams Params; // Offset: 0x10 | Size: 0x14
	struct FVector Origin; // Offset: 0x24 | Size: 0xc
	struct TArray<struct FHitResult> ComponentHits; // Offset: 0x30 | Size: 0x10
};

// Object: ScriptStruct Engine.RadialDamageParams
// Inherited Bytes: 0x0 | Struct Size: 0x14
struct FRadialDamageParams {
	// Fields
	float BaseDamage; // Offset: 0x0 | Size: 0x4
	float MinimumDamage; // Offset: 0x4 | Size: 0x4
	float InnerRadius; // Offset: 0x8 | Size: 0x4
	float OuterRadius; // Offset: 0xc | Size: 0x4
	float DamageFalloff; // Offset: 0x10 | Size: 0x4
};

// Object: ScriptStruct Engine.SkeletalMeshBuildSettings
// Inherited Bytes: 0x0 | Struct Size: 0x14
struct FSkeletalMeshBuildSettings {
	// Fields
	char bRecomputeNormals : 1; // Offset: 0x0 | Size: 0x1
	char bRecomputeTangents : 1; // Offset: 0x0 | Size: 0x1
	char bUseMikkTSpace : 1; // Offset: 0x0 | Size: 0x1
	char bComputeWeightedNormals : 1; // Offset: 0x0 | Size: 0x1
	char bRemoveDegenerates : 1; // Offset: 0x0 | Size: 0x1
	char bUseHighPrecisionTangentBasis : 1; // Offset: 0x0 | Size: 0x1
	char bUseFullPrecisionUVs : 1; // Offset: 0x0 | Size: 0x1
	char bBuildAdjacencyBuffer : 1; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	float ThresholdPosition; // Offset: 0x4 | Size: 0x4
	float ThresholdTangentNormal; // Offset: 0x8 | Size: 0x4
	float ThresholdUV; // Offset: 0xc | Size: 0x4
	float MorphThresholdPosition; // Offset: 0x10 | Size: 0x4
};

// Object: ScriptStruct Engine.MeshBuildSettings
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FMeshBuildSettings {
	// Fields
	char bUseMikkTSpace : 1; // Offset: 0x0 | Size: 0x1
	char bRecomputeNormals : 1; // Offset: 0x0 | Size: 0x1
	char bRecomputeTangents : 1; // Offset: 0x0 | Size: 0x1
	char bComputeWeightedNormals : 1; // Offset: 0x0 | Size: 0x1
	char bRemoveDegenerates : 1; // Offset: 0x0 | Size: 0x1
	char bBuildAdjacencyBuffer : 1; // Offset: 0x0 | Size: 0x1
	char bBuildReversedIndexBuffer : 1; // Offset: 0x0 | Size: 0x1
	char bUseHighPrecisionTangentBasis : 1; // Offset: 0x0 | Size: 0x1
	char bUseFullPrecisionUVs : 1; // Offset: 0x1 | Size: 0x1
	char bGenerateLightmapUVs : 1; // Offset: 0x1 | Size: 0x1
	char bGenerateDistanceFieldAsIfTwoSided : 1; // Offset: 0x1 | Size: 0x1
	char bSupportFaceRemap : 1; // Offset: 0x1 | Size: 0x1
	char pad_0x1_4 : 4; // Offset: 0x1 | Size: 0x1
	char pad_0x2[0x2]; // Offset: 0x2 | Size: 0x2
	int32_t MinLightmapResolution; // Offset: 0x4 | Size: 0x4
	int32_t SrcLightmapIndex; // Offset: 0x8 | Size: 0x4
	int32_t DstLightmapIndex; // Offset: 0xc | Size: 0x4
	float BuildScale; // Offset: 0x10 | Size: 0x4
	struct FVector BuildScale3D; // Offset: 0x14 | Size: 0xc
	float DistanceFieldResolutionScale; // Offset: 0x20 | Size: 0x4
	char pad_0x24[0x4]; // Offset: 0x24 | Size: 0x4
	struct UStaticMesh* DistanceFieldReplacementMesh; // Offset: 0x28 | Size: 0x8
};

// Object: ScriptStruct Engine.POV
// Inherited Bytes: 0x0 | Struct Size: 0x1c
struct FPOV {
	// Fields
	struct FVector Location; // Offset: 0x0 | Size: 0xc
	struct FRotator Rotation; // Offset: 0xc | Size: 0xc
	float FOV; // Offset: 0x18 | Size: 0x4
};

// Object: ScriptStruct Engine.AnimUpdateRateParameters
// Inherited Bytes: 0x0 | Struct Size: 0x88
struct FAnimUpdateRateParameters {
	// Fields
	char pad_0x0[0x1]; // Offset: 0x0 | Size: 0x1
	enum class EUpdateRateShiftBucket ShiftBucket; // Offset: 0x1 | Size: 0x1
	char bInterpolateSkippedFrames : 1; // Offset: 0x2 | Size: 0x1
	char bShouldUseLodMap : 1; // Offset: 0x2 | Size: 0x1
	char bShouldUseMinLod : 1; // Offset: 0x2 | Size: 0x1
	char bSkipUpdate : 1; // Offset: 0x2 | Size: 0x1
	char bSkipEvaluation : 1; // Offset: 0x2 | Size: 0x1
	char pad_0x2_5 : 3; // Offset: 0x2 | Size: 0x1
	char pad_0x3[0x1]; // Offset: 0x3 | Size: 0x1
	int32_t UpdateRate; // Offset: 0x4 | Size: 0x4
	int32_t EvaluationRate; // Offset: 0x8 | Size: 0x4
	float TickedPoseOffestTime; // Offset: 0xc | Size: 0x4
	float AdditionalTime; // Offset: 0x10 | Size: 0x4
	char pad_0x14[0x4]; // Offset: 0x14 | Size: 0x4
	int32_t BaseNonRenderedUpdateRate; // Offset: 0x18 | Size: 0x4
	int32_t MaxEvalRateForInterpolation; // Offset: 0x1c | Size: 0x4
	struct TArray<float> BaseVisibleDistanceFactorThesholds; // Offset: 0x20 | Size: 0x10
	struct TMap<int32_t, int32_t> LODToFrameSkipMap; // Offset: 0x30 | Size: 0x50
	int32_t SkippedUpdateFrames; // Offset: 0x80 | Size: 0x4
	int32_t SkippedEvalFrames; // Offset: 0x84 | Size: 0x4
};

// Object: ScriptStruct Engine.AnimSlotDesc
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FAnimSlotDesc {
	// Fields
	struct FName SlotName; // Offset: 0x0 | Size: 0x8
	int32_t NumChannels; // Offset: 0x8 | Size: 0x4
};

// Object: ScriptStruct Engine.AnimSlotInfo
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FAnimSlotInfo {
	// Fields
	struct FName SlotName; // Offset: 0x0 | Size: 0x8
	struct TArray<float> ChannelWeights; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct Engine.MTDResult
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FMTDResult {
	// Fields
	struct FVector Direction; // Offset: 0x0 | Size: 0xc
	float Distance; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct Engine.OverlapResult
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FOverlapResult {
	// Fields
	struct TWeakObjectPtr<struct AActor> Actor; // Offset: 0x0 | Size: 0x8
	struct TWeakObjectPtr<struct UPrimitiveComponent> Component; // Offset: 0x8 | Size: 0x8
	char pad_0x10[0x4]; // Offset: 0x10 | Size: 0x4
	char bBlockingHit : 1; // Offset: 0x14 | Size: 0x1
	char pad_0x14_1 : 7; // Offset: 0x14 | Size: 0x1
	char pad_0x15[0x3]; // Offset: 0x15 | Size: 0x3
};

// Object: ScriptStruct Engine.PrimitiveMaterialRef
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FPrimitiveMaterialRef {
	// Fields
	struct UPrimitiveComponent* Primitive; // Offset: 0x0 | Size: 0x8
	struct UDecalComponent* Decal; // Offset: 0x8 | Size: 0x8
	int32_t ElementIndex; // Offset: 0x10 | Size: 0x4
	char pad_0x14[0x4]; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct Engine.SwarmDebugOptions
// Inherited Bytes: 0x0 | Struct Size: 0x4
struct FSwarmDebugOptions {
	// Fields
	char bDistributionEnabled : 1; // Offset: 0x0 | Size: 0x1
	char bForceContentExport : 1; // Offset: 0x0 | Size: 0x1
	char bInitialized : 1; // Offset: 0x0 | Size: 0x1
	char pad_0x0_3 : 5; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
};

// Object: ScriptStruct Engine.LightmassDebugOptions
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FLightmassDebugOptions {
	// Fields
	char bDebugMode : 1; // Offset: 0x0 | Size: 0x1
	char bStatsEnabled : 1; // Offset: 0x0 | Size: 0x1
	char bGatherBSPSurfacesAcrossComponents : 1; // Offset: 0x0 | Size: 0x1
	char pad_0x0_3 : 5; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	float CoplanarTolerance; // Offset: 0x4 | Size: 0x4
	char bUseImmediateImport : 1; // Offset: 0x8 | Size: 0x1
	char bImmediateProcessMappings : 1; // Offset: 0x8 | Size: 0x1
	char bSortMappings : 1; // Offset: 0x8 | Size: 0x1
	char bDumpBinaryFiles : 1; // Offset: 0x8 | Size: 0x1
	char bDebugMaterials : 1; // Offset: 0x8 | Size: 0x1
	char bPadMappings : 1; // Offset: 0x8 | Size: 0x1
	char bDebugPaddings : 1; // Offset: 0x8 | Size: 0x1
	char bOnlyCalcDebugTexelMappings : 1; // Offset: 0x8 | Size: 0x1
	char bUseRandomColors : 1; // Offset: 0x9 | Size: 0x1
	char bColorBordersGreen : 1; // Offset: 0x9 | Size: 0x1
	char bColorByExecutionTime : 1; // Offset: 0x9 | Size: 0x1
	char pad_0x9_3 : 5; // Offset: 0x9 | Size: 0x1
	char pad_0xA[0x2]; // Offset: 0xa | Size: 0x2
	float ExecutionTimeDivisor; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct Engine.LightmassPrimitiveSettings
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FLightmassPrimitiveSettings {
	// Fields
	char bUseTwoSidedLighting : 1; // Offset: 0x0 | Size: 0x1
	char bShadowIndirectOnly : 1; // Offset: 0x0 | Size: 0x1
	char bUseEmissiveForStaticLighting : 1; // Offset: 0x0 | Size: 0x1
	char bUseVertexNormalForHemisphereGather : 1; // Offset: 0x0 | Size: 0x1
	char pad_0x0_4 : 4; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	float EmissiveLightFalloffExponent; // Offset: 0x4 | Size: 0x4
	float EmissiveLightExplicitInfluenceRadius; // Offset: 0x8 | Size: 0x4
	float EmissiveBoost; // Offset: 0xc | Size: 0x4
	float DiffuseBoost; // Offset: 0x10 | Size: 0x4
	float FullyOccludedSamplesFraction; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct Engine.LightmassLightSettings
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FLightmassLightSettings {
	// Fields
	float IndirectLightingSaturation; // Offset: 0x0 | Size: 0x4
	float ShadowExponent; // Offset: 0x4 | Size: 0x4
	bool bUseAreaShadowsForStationaryLight; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x3]; // Offset: 0x9 | Size: 0x3
};

// Object: ScriptStruct Engine.LightmassDirectionalLightSettings
// Inherited Bytes: 0xc | Struct Size: 0x10
struct FLightmassDirectionalLightSettings : FLightmassLightSettings {
	// Fields
	float LightSourceAngle; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct Engine.LightmassPointLightSettings
// Inherited Bytes: 0xc | Struct Size: 0xc
struct FLightmassPointLightSettings : FLightmassLightSettings {
};

// Object: ScriptStruct Engine.BasedPosition
// Inherited Bytes: 0x0 | Struct Size: 0x38
struct FBasedPosition {
	// Fields
	struct AActor* Base; // Offset: 0x0 | Size: 0x8
	struct FVector Position; // Offset: 0x8 | Size: 0xc
	struct FVector CachedBaseLocation; // Offset: 0x14 | Size: 0xc
	struct FRotator CachedBaseRotation; // Offset: 0x20 | Size: 0xc
	struct FVector CachedTransPosition; // Offset: 0x2c | Size: 0xc
};

// Object: ScriptStruct Engine.FractureEffect
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FFractureEffect {
	// Fields
	struct UParticleSystem* ParticleSystem; // Offset: 0x0 | Size: 0x8
	struct USoundBase* Sound; // Offset: 0x8 | Size: 0x8
};

// Object: ScriptStruct Engine.CollisionImpactData
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FCollisionImpactData {
	// Fields
	struct TArray<struct FRigidBodyContactInfo> ContactInfos; // Offset: 0x0 | Size: 0x10
	struct FVector TotalNormalImpulse; // Offset: 0x10 | Size: 0xc
	struct FVector TotalFrictionImpulse; // Offset: 0x1c | Size: 0xc
};

// Object: ScriptStruct Engine.RigidBodyContactInfo
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FRigidBodyContactInfo {
	// Fields
	struct FVector ContactPosition; // Offset: 0x0 | Size: 0xc
	struct FVector ContactNormal; // Offset: 0xc | Size: 0xc
	float ContactPenetration; // Offset: 0x18 | Size: 0x4
	char pad_0x1C[0x4]; // Offset: 0x1c | Size: 0x4
	struct UPhysicalMaterial* PhysMaterial[0x2]; // Offset: 0x20 | Size: 0x10
};

// Object: ScriptStruct Engine.RigidBodyErrorCorrection
// Inherited Bytes: 0x0 | Struct Size: 0x34
struct FRigidBodyErrorCorrection {
	// Fields
	float PingExtrapolation; // Offset: 0x0 | Size: 0x4
	float PingLimit; // Offset: 0x4 | Size: 0x4
	float ErrorPerLinearDifference; // Offset: 0x8 | Size: 0x4
	float ErrorPerAngularDifference; // Offset: 0xc | Size: 0x4
	float MaxRestoredStateError; // Offset: 0x10 | Size: 0x4
	float MaxLinearHardSnapDistance; // Offset: 0x14 | Size: 0x4
	float PositionLerp; // Offset: 0x18 | Size: 0x4
	float AngleLerp; // Offset: 0x1c | Size: 0x4
	float LinearVelocityCoefficient; // Offset: 0x20 | Size: 0x4
	float AngularVelocityCoefficient; // Offset: 0x24 | Size: 0x4
	float ErrorAccumulationSeconds; // Offset: 0x28 | Size: 0x4
	float ErrorAccumulationDistanceSq; // Offset: 0x2c | Size: 0x4
	float ErrorAccumulationSimilarity; // Offset: 0x30 | Size: 0x4
};

// Object: ScriptStruct Engine.RigidBodyState
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FRigidBodyState {
	// Fields
	struct FVector_NetQuantize100 Position; // Offset: 0x0 | Size: 0xc
	char pad_0xC[0x4]; // Offset: 0xc | Size: 0x4
	struct FQuat Quaternion; // Offset: 0x10 | Size: 0x10
	struct FVector_NetQuantize100 LinVel; // Offset: 0x20 | Size: 0xc
	struct FVector_NetQuantize100 AngVel; // Offset: 0x2c | Size: 0xc
	char Flags; // Offset: 0x38 | Size: 0x1
	char pad_0x39[0x7]; // Offset: 0x39 | Size: 0x7
};

// Object: ScriptStruct Engine.MaterialShadingModelField
// Inherited Bytes: 0x0 | Struct Size: 0x2
struct FMaterialShadingModelField {
	// Fields
	uint16_t ShadingModelField; // Offset: 0x0 | Size: 0x2
};

// Object: ScriptStruct Engine.SLDirectionalLightScattering
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FSLDirectionalLightScattering {
	// Fields
	float DirectionalInscatteringExponent_M; // Offset: 0x0 | Size: 0x4
	float DirectionalInscatteringStartDistance_M; // Offset: 0x4 | Size: 0x4
	float DirectionalInscatteringMaxDistance_M; // Offset: 0x8 | Size: 0x4
	struct FLinearColor DirectionalInscatteringColor_M; // Offset: 0xc | Size: 0x10
	float DirectionalInscatteringGamma_M; // Offset: 0x1c | Size: 0x4
};

// Object: ScriptStruct Engine.SLHeightFogData
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FSLHeightFogData {
	// Fields
	float HFogHeight; // Offset: 0x0 | Size: 0x4
	float HFogHeightFalloff; // Offset: 0x4 | Size: 0x4
	float HStartDistance; // Offset: 0x8 | Size: 0x4
	float HMaxFadingDistance; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct Engine.SLDistanceFogData
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FSLDistanceFogData {
	// Fields
	float DFogHeight; // Offset: 0x0 | Size: 0x4
	float DFogFallOff; // Offset: 0x4 | Size: 0x4
	float DMaxDistance; // Offset: 0x8 | Size: 0x4
	float DFogGamma; // Offset: 0xc | Size: 0x4
	float DMaxOpacity; // Offset: 0x10 | Size: 0x4
	float DStartDistance; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct Engine.ExponentialHeightFogData
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FExponentialHeightFogData {
	// Fields
	float FogDensity; // Offset: 0x0 | Size: 0x4
	float FogHeightFalloff; // Offset: 0x4 | Size: 0x4
	float FogHeightOffset; // Offset: 0x8 | Size: 0x4
};

// Object: ScriptStruct Engine.FontCharacter
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FFontCharacter {
	// Fields
	int32_t StartU; // Offset: 0x0 | Size: 0x4
	int32_t StartV; // Offset: 0x4 | Size: 0x4
	int32_t USize; // Offset: 0x8 | Size: 0x4
	int32_t VSize; // Offset: 0xc | Size: 0x4
	char TextureIndex; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x3]; // Offset: 0x11 | Size: 0x3
	int32_t VerticalOffset; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct Engine.FontImportOptionsData
// Inherited Bytes: 0x0 | Struct Size: 0xa8
struct FFontImportOptionsData {
	// Fields
	struct FString FontName; // Offset: 0x0 | Size: 0x10
	float Height; // Offset: 0x10 | Size: 0x4
	char bEnableAntialiasing : 1; // Offset: 0x14 | Size: 0x1
	char bEnableBold : 1; // Offset: 0x14 | Size: 0x1
	char bEnableItalic : 1; // Offset: 0x14 | Size: 0x1
	char bEnableUnderline : 1; // Offset: 0x14 | Size: 0x1
	char bAlphaOnly : 1; // Offset: 0x14 | Size: 0x1
	char pad_0x14_5 : 3; // Offset: 0x14 | Size: 0x1
	enum class EFontImportCharacterSet CharacterSet; // Offset: 0x15 | Size: 0x1
	char pad_0x16[0x2]; // Offset: 0x16 | Size: 0x2
	struct FString Chars; // Offset: 0x18 | Size: 0x10
	struct FString UnicodeRange; // Offset: 0x28 | Size: 0x10
	struct FString CharsFilePath; // Offset: 0x38 | Size: 0x10
	struct FString CharsFileWildcard; // Offset: 0x48 | Size: 0x10
	char bCreatePrintableOnly : 1; // Offset: 0x58 | Size: 0x1
	char bIncludeASCIIRange : 1; // Offset: 0x58 | Size: 0x1
	char pad_0x58_2 : 6; // Offset: 0x58 | Size: 0x1
	char pad_0x59[0x3]; // Offset: 0x59 | Size: 0x3
	struct FLinearColor ForegroundColor; // Offset: 0x5c | Size: 0x10
	char bEnableDropShadow : 1; // Offset: 0x6c | Size: 0x1
	char pad_0x6C_1 : 7; // Offset: 0x6c | Size: 0x1
	char pad_0x6D[0x3]; // Offset: 0x6d | Size: 0x3
	int32_t TexturePageWidth; // Offset: 0x70 | Size: 0x4
	int32_t TexturePageMaxHeight; // Offset: 0x74 | Size: 0x4
	int32_t XPadding; // Offset: 0x78 | Size: 0x4
	int32_t YPadding; // Offset: 0x7c | Size: 0x4
	int32_t ExtendBoxTop; // Offset: 0x80 | Size: 0x4
	int32_t ExtendBoxBottom; // Offset: 0x84 | Size: 0x4
	int32_t ExtendBoxRight; // Offset: 0x88 | Size: 0x4
	int32_t ExtendBoxLeft; // Offset: 0x8c | Size: 0x4
	char bEnableLegacyMode : 1; // Offset: 0x90 | Size: 0x1
	char pad_0x90_1 : 7; // Offset: 0x90 | Size: 0x1
	char pad_0x91[0x3]; // Offset: 0x91 | Size: 0x3
	int32_t Kerning; // Offset: 0x94 | Size: 0x4
	char bUseDistanceFieldAlpha : 1; // Offset: 0x98 | Size: 0x1
	char pad_0x98_1 : 7; // Offset: 0x98 | Size: 0x1
	char pad_0x99[0x3]; // Offset: 0x99 | Size: 0x3
	int32_t DistanceFieldScaleFactor; // Offset: 0x9c | Size: 0x4
	float DistanceFieldScanRadiusScale; // Offset: 0xa0 | Size: 0x4
	char pad_0xA4[0x4]; // Offset: 0xa4 | Size: 0x4
};

// Object: ScriptStruct Engine.ForceFeedbackAttenuationSettings
// Inherited Bytes: 0xb0 | Struct Size: 0xb0
struct FForceFeedbackAttenuationSettings : FBaseAttenuationSettings {
};

// Object: ScriptStruct Engine.ForceFeedbackChannelDetails
// Inherited Bytes: 0x0 | Struct Size: 0x90
struct FForceFeedbackChannelDetails {
	// Fields
	char bAffectsLeftLarge : 1; // Offset: 0x0 | Size: 0x1
	char bAffectsLeftSmall : 1; // Offset: 0x0 | Size: 0x1
	char bAffectsRightLarge : 1; // Offset: 0x0 | Size: 0x1
	char bAffectsRightSmall : 1; // Offset: 0x0 | Size: 0x1
	char pad_0x0_4 : 4; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x7]; // Offset: 0x1 | Size: 0x7
	struct FRuntimeFloatCurve Curve; // Offset: 0x8 | Size: 0x88
};

// Object: ScriptStruct Engine.PredictProjectilePathResult
// Inherited Bytes: 0x0 | Struct Size: 0xb8
struct FPredictProjectilePathResult {
	// Fields
	struct TArray<struct FPredictProjectilePathPointData> PathData; // Offset: 0x0 | Size: 0x10
	struct FPredictProjectilePathPointData LastTraceDestination; // Offset: 0x10 | Size: 0x1c
	struct FHitResult HitResult; // Offset: 0x2c | Size: 0x88
	char pad_0xB4[0x4]; // Offset: 0xb4 | Size: 0x4
};

// Object: ScriptStruct Engine.PredictProjectilePathPointData
// Inherited Bytes: 0x0 | Struct Size: 0x1c
struct FPredictProjectilePathPointData {
	// Fields
	struct FVector Location; // Offset: 0x0 | Size: 0xc
	struct FVector Velocity; // Offset: 0xc | Size: 0xc
	float Time; // Offset: 0x18 | Size: 0x4
};

// Object: ScriptStruct Engine.PredictProjectilePathParams
// Inherited Bytes: 0x0 | Struct Size: 0x70
struct FPredictProjectilePathParams {
	// Fields
	struct FVector StartLocation; // Offset: 0x0 | Size: 0xc
	struct FVector LaunchVelocity; // Offset: 0xc | Size: 0xc
	bool bTraceWithCollision; // Offset: 0x18 | Size: 0x1
	char pad_0x19[0x3]; // Offset: 0x19 | Size: 0x3
	float ProjectileRadius; // Offset: 0x1c | Size: 0x4
	float MaxSimTime; // Offset: 0x20 | Size: 0x4
	bool bTraceWithChannel; // Offset: 0x24 | Size: 0x1
	enum class ECollisionChannel TraceChannel; // Offset: 0x25 | Size: 0x1
	char pad_0x26[0x2]; // Offset: 0x26 | Size: 0x2
	struct TArray<enum class EObjectTypeQuery> ObjectTypes; // Offset: 0x28 | Size: 0x10
	struct TArray<struct FName> OnlyInfluencedActorTags; // Offset: 0x38 | Size: 0x10
	struct TArray<struct AActor*> ActorsToIgnore; // Offset: 0x48 | Size: 0x10
	float SimFrequency; // Offset: 0x58 | Size: 0x4
	float OverrideGravityZ; // Offset: 0x5c | Size: 0x4
	enum class EDrawDebugTrace DrawDebugType; // Offset: 0x60 | Size: 0x1
	char pad_0x61[0x3]; // Offset: 0x61 | Size: 0x3
	float DrawDebugTime; // Offset: 0x64 | Size: 0x4
	bool bTraceComplex; // Offset: 0x68 | Size: 0x1
	char pad_0x69[0x7]; // Offset: 0x69 | Size: 0x7
};

// Object: ScriptStruct Engine.ActiveHapticFeedbackEffect
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FActiveHapticFeedbackEffect {
	// Fields
	struct UHapticFeedbackEffect_Base* HapticEffect; // Offset: 0x0 | Size: 0x8
	char pad_0x8[0x10]; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct Engine.HapticFeedbackDetails_Curve
// Inherited Bytes: 0x0 | Struct Size: 0x110
struct FHapticFeedbackDetails_Curve {
	// Fields
	struct FRuntimeFloatCurve Frequency; // Offset: 0x0 | Size: 0x88
	struct FRuntimeFloatCurve Amplitude; // Offset: 0x88 | Size: 0x88
};

// Object: ScriptStruct Engine.ClusterNode
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FClusterNode {
	// Fields
	struct FVector BoundMin; // Offset: 0x0 | Size: 0xc
	int32_t FirstChild; // Offset: 0xc | Size: 0x4
	struct FVector BoundMax; // Offset: 0x10 | Size: 0xc
	int32_t LastChild; // Offset: 0x1c | Size: 0x4
	int32_t FirstInstance; // Offset: 0x20 | Size: 0x4
	int32_t LastInstance; // Offset: 0x24 | Size: 0x4
	struct FVector MinInstanceScale; // Offset: 0x28 | Size: 0xc
	struct FVector MaxInstanceScale; // Offset: 0x34 | Size: 0xc
};

// Object: ScriptStruct Engine.ClusterNode_DEPRECATED
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FClusterNode_DEPRECATED {
	// Fields
	struct FVector BoundMin; // Offset: 0x0 | Size: 0xc
	int32_t FirstChild; // Offset: 0xc | Size: 0x4
	struct FVector BoundMax; // Offset: 0x10 | Size: 0xc
	int32_t LastChild; // Offset: 0x1c | Size: 0x4
	int32_t FirstInstance; // Offset: 0x20 | Size: 0x4
	int32_t LastInstance; // Offset: 0x24 | Size: 0x4
};

// Object: ScriptStruct Engine.HLODProxyMesh
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FHLODProxyMesh {
	// Fields
	LazyObjectProperty LODActor; // Offset: 0x0 | Size: 0x1c
	char pad_0x1C[0x4]; // Offset: 0x1c | Size: 0x4
	struct UStaticMesh* StaticMesh; // Offset: 0x20 | Size: 0x8
	struct FName Key; // Offset: 0x28 | Size: 0x8
};

// Object: ScriptStruct Engine.ImportanceTexture
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FImportanceTexture {
	// Fields
	struct FIntPoint Size; // Offset: 0x0 | Size: 0x8
	int32_t NumMips; // Offset: 0x8 | Size: 0x4
	char pad_0xC[0x4]; // Offset: 0xc | Size: 0x4
	struct TArray<float> MarginalCDF; // Offset: 0x10 | Size: 0x10
	struct TArray<float> ConditionalCDF; // Offset: 0x20 | Size: 0x10
	struct TArray<struct FColor> TextureData; // Offset: 0x30 | Size: 0x10
	struct TWeakObjectPtr<struct UTexture2D> Texture; // Offset: 0x40 | Size: 0x8
	enum class EImportanceWeight Weighting; // Offset: 0x48 | Size: 0x1
	char pad_0x49[0x7]; // Offset: 0x49 | Size: 0x7
};

// Object: ScriptStruct Engine.ComponentOverrideRecord
// Inherited Bytes: 0x0 | Struct Size: 0x78
struct FComponentOverrideRecord {
	// Fields
	struct UObject* ComponentClass; // Offset: 0x0 | Size: 0x8
	struct UActorComponent* ComponentTemplate; // Offset: 0x8 | Size: 0x8
	struct FComponentKey ComponentKey; // Offset: 0x10 | Size: 0x20
	struct FBlueprintCookedComponentInstancingData CookedComponentInstancingData; // Offset: 0x30 | Size: 0x48
};

// Object: ScriptStruct Engine.ComponentKey
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FComponentKey {
	// Fields
	struct UObject* OwnerClass; // Offset: 0x0 | Size: 0x8
	struct FName SCSVariableName; // Offset: 0x8 | Size: 0x8
	struct FGuid AssociatedGuid; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct Engine.BlueprintInputDelegateBinding
// Inherited Bytes: 0x0 | Struct Size: 0x4
struct FBlueprintInputDelegateBinding {
	// Fields
	char bConsumeInput : 1; // Offset: 0x0 | Size: 0x1
	char bExecuteWhenPaused : 1; // Offset: 0x0 | Size: 0x1
	char bOverrideParentBinding : 1; // Offset: 0x0 | Size: 0x1
	char pad_0x0_3 : 5; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
};

// Object: ScriptStruct Engine.BlueprintInputActionDelegateBinding
// Inherited Bytes: 0x4 | Struct Size: 0x18
struct FBlueprintInputActionDelegateBinding : FBlueprintInputDelegateBinding {
	// Fields
	struct FName InputActionName; // Offset: 0x4 | Size: 0x8
	enum class EInputEvent InputKeyEvent; // Offset: 0xc | Size: 0x1
	char pad_0xD[0x3]; // Offset: 0xd | Size: 0x3
	struct FName FunctionNameToBind; // Offset: 0x10 | Size: 0x8
};

// Object: ScriptStruct Engine.BlueprintInputAxisDelegateBinding
// Inherited Bytes: 0x4 | Struct Size: 0x14
struct FBlueprintInputAxisDelegateBinding : FBlueprintInputDelegateBinding {
	// Fields
	struct FName InputAxisName; // Offset: 0x4 | Size: 0x8
	struct FName FunctionNameToBind; // Offset: 0xc | Size: 0x8
};

// Object: ScriptStruct Engine.BlueprintInputAxisKeyDelegateBinding
// Inherited Bytes: 0x4 | Struct Size: 0x28
struct FBlueprintInputAxisKeyDelegateBinding : FBlueprintInputDelegateBinding {
	// Fields
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct FKey AxisKey; // Offset: 0x8 | Size: 0x18
	struct FName FunctionNameToBind; // Offset: 0x20 | Size: 0x8
};

// Object: ScriptStruct Engine.CachedKeyToActionInfo
// Inherited Bytes: 0x0 | Struct Size: 0x70
struct FCachedKeyToActionInfo {
	// Fields
	struct UPlayerInput* PlayerInput; // Offset: 0x0 | Size: 0x8
	char pad_0x8[0x68]; // Offset: 0x8 | Size: 0x68
};

// Object: ScriptStruct Engine.BlueprintInputKeyDelegateBinding
// Inherited Bytes: 0x4 | Struct Size: 0x38
struct FBlueprintInputKeyDelegateBinding : FBlueprintInputDelegateBinding {
	// Fields
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct FInputChord InputChord; // Offset: 0x8 | Size: 0x20
	enum class EInputEvent InputKeyEvent; // Offset: 0x28 | Size: 0x1
	char pad_0x29[0x3]; // Offset: 0x29 | Size: 0x3
	struct FName FunctionNameToBind; // Offset: 0x2c | Size: 0x8
	char pad_0x34[0x4]; // Offset: 0x34 | Size: 0x4
};

// Object: ScriptStruct Engine.BlueprintInputTouchDelegateBinding
// Inherited Bytes: 0x4 | Struct Size: 0xc
struct FBlueprintInputTouchDelegateBinding : FBlueprintInputDelegateBinding {
	// Fields
	enum class EInputEvent InputKeyEvent; // Offset: 0x1 | Size: 0x1
	struct FName FunctionNameToBind; // Offset: 0x4 | Size: 0x8
};

// Object: ScriptStruct Engine.InstancedStaticMeshComponentInstanceData
// Inherited Bytes: 0xa8 | Struct Size: 0x140
struct FInstancedStaticMeshComponentInstanceData : FSceneComponentInstanceData {
	// Fields
	struct UStaticMesh* StaticMesh; // Offset: 0xa8 | Size: 0x8
	struct FInstancedStaticMeshLightMapInstanceData CachedStaticLighting; // Offset: 0xb0 | Size: 0x40
	struct TArray<struct FInstancedStaticMeshInstanceData> PerInstanceSMData; // Offset: 0xf0 | Size: 0x10
	struct TArray<float> PerInstanceSMCustomData; // Offset: 0x100 | Size: 0x10
	char pad_0x110[0x20]; // Offset: 0x110 | Size: 0x20
	int32_t InstancingRandomSeed; // Offset: 0x130 | Size: 0x4
	char pad_0x134[0xc]; // Offset: 0x134 | Size: 0xc
};

// Object: ScriptStruct Engine.InstancedStaticMeshInstanceData
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FInstancedStaticMeshInstanceData {
	// Fields
	struct FMatrix Transform; // Offset: 0x0 | Size: 0x40
};

// Object: ScriptStruct Engine.InstancedStaticMeshLightMapInstanceData
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FInstancedStaticMeshLightMapInstanceData {
	// Fields
	struct FTransform Transform; // Offset: 0x0 | Size: 0x30
	struct TArray<struct FGuid> MapBuildDataIds; // Offset: 0x30 | Size: 0x10
};

// Object: ScriptStruct Engine.InstancedStaticMeshMappingInfo
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FInstancedStaticMeshMappingInfo {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
};

// Object: ScriptStruct Engine.IntegralCurve
// Inherited Bytes: 0x68 | Struct Size: 0x80
struct FIntegralCurve : FIndexedCurve {
	// Fields
	struct TArray<struct FIntegralKey> Keys; // Offset: 0x68 | Size: 0x10
	int32_t DefaultValue; // Offset: 0x78 | Size: 0x4
	bool bUseDefaultValueBeforeFirstKey; // Offset: 0x7c | Size: 0x1
	char pad_0x7D[0x3]; // Offset: 0x7d | Size: 0x3
};

// Object: ScriptStruct Engine.IntegralKey
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FIntegralKey {
	// Fields
	float Time; // Offset: 0x0 | Size: 0x4
	int32_t Value; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct Engine.CurveEdTab
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FCurveEdTab {
	// Fields
	struct FString TabName; // Offset: 0x0 | Size: 0x10
	struct TArray<struct FCurveEdEntry> Curves; // Offset: 0x10 | Size: 0x10
	float ViewStartInput; // Offset: 0x20 | Size: 0x4
	float ViewEndInput; // Offset: 0x24 | Size: 0x4
	float ViewStartOutput; // Offset: 0x28 | Size: 0x4
	float ViewEndOutput; // Offset: 0x2c | Size: 0x4
};

// Object: ScriptStruct Engine.CurveEdEntry
// Inherited Bytes: 0x0 | Struct Size: 0x38
struct FCurveEdEntry {
	// Fields
	struct UObject* CurveObject; // Offset: 0x0 | Size: 0x8
	struct FColor CurveColor; // Offset: 0x8 | Size: 0x4
	char pad_0xC[0x4]; // Offset: 0xc | Size: 0x4
	struct FString CurveName; // Offset: 0x10 | Size: 0x10
	int32_t bHideCurve; // Offset: 0x20 | Size: 0x4
	int32_t bColorCurve; // Offset: 0x24 | Size: 0x4
	int32_t bFloatingPointColorCurve; // Offset: 0x28 | Size: 0x4
	int32_t bClamp; // Offset: 0x2c | Size: 0x4
	float ClampLow; // Offset: 0x30 | Size: 0x4
	float ClampHigh; // Offset: 0x34 | Size: 0x4
};

// Object: ScriptStruct Engine.InterpEdSelKey
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FInterpEdSelKey {
	// Fields
	struct UInterpGroup* Group; // Offset: 0x0 | Size: 0x8
	struct UInterpTrack* Track; // Offset: 0x8 | Size: 0x8
	int32_t KeyIndex; // Offset: 0x10 | Size: 0x4
	float UnsnappedPosition; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct Engine.CameraPreviewInfo
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FCameraPreviewInfo {
	// Fields
	struct APawn* PawnClass; // Offset: 0x0 | Size: 0x8
	struct UAnimSequence* AnimSeq; // Offset: 0x8 | Size: 0x8
	struct FVector Location; // Offset: 0x10 | Size: 0xc
	struct FRotator Rotation; // Offset: 0x1c | Size: 0xc
	struct APawn* PawnInst; // Offset: 0x28 | Size: 0x8
};

// Object: ScriptStruct Engine.SubTrackGroup
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FSubTrackGroup {
	// Fields
	struct FString GroupName; // Offset: 0x0 | Size: 0x10
	struct TArray<int32_t> TrackIndices; // Offset: 0x10 | Size: 0x10
	char bIsCollapsed : 1; // Offset: 0x20 | Size: 0x1
	char bIsSelected : 1; // Offset: 0x20 | Size: 0x1
	char pad_0x20_2 : 6; // Offset: 0x20 | Size: 0x1
	char pad_0x21[0x7]; // Offset: 0x21 | Size: 0x7
};

// Object: ScriptStruct Engine.SupportedSubTrackInfo
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FSupportedSubTrackInfo {
	// Fields
	struct UInterpTrack* SupportedClass; // Offset: 0x0 | Size: 0x8
	struct FString SubTrackName; // Offset: 0x8 | Size: 0x10
	int32_t GroupIndex; // Offset: 0x18 | Size: 0x4
	char pad_0x1C[0x4]; // Offset: 0x1c | Size: 0x4
};

// Object: ScriptStruct Engine.AnimControlTrackKey
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FAnimControlTrackKey {
	// Fields
	float StartTime; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct UAnimSequence* AnimSeq; // Offset: 0x8 | Size: 0x8
	float AnimStartOffset; // Offset: 0x10 | Size: 0x4
	float AnimEndOffset; // Offset: 0x14 | Size: 0x4
	float AnimPlayRate; // Offset: 0x18 | Size: 0x4
	char bLooping : 1; // Offset: 0x1c | Size: 0x1
	char bReverse : 1; // Offset: 0x1c | Size: 0x1
	char pad_0x1C_2 : 6; // Offset: 0x1c | Size: 0x1
	char pad_0x1D[0x3]; // Offset: 0x1d | Size: 0x3
};

// Object: ScriptStruct Engine.BoolTrackKey
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FBoolTrackKey {
	// Fields
	float Time; // Offset: 0x0 | Size: 0x4
	char Value : 1; // Offset: 0x4 | Size: 0x1
	char pad_0x4_1 : 7; // Offset: 0x4 | Size: 0x1
	char pad_0x5[0x3]; // Offset: 0x5 | Size: 0x3
};

// Object: ScriptStruct Engine.DirectorTrackCut
// Inherited Bytes: 0x0 | Struct Size: 0x14
struct FDirectorTrackCut {
	// Fields
	float Time; // Offset: 0x0 | Size: 0x4
	float TransitionTime; // Offset: 0x4 | Size: 0x4
	struct FName TargetCamGroup; // Offset: 0x8 | Size: 0x8
	int32_t ShotNumber; // Offset: 0x10 | Size: 0x4
};

// Object: ScriptStruct Engine.EventTrackKey
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FEventTrackKey {
	// Fields
	float Time; // Offset: 0x0 | Size: 0x4
	struct FName EventName; // Offset: 0x4 | Size: 0x8
};

// Object: ScriptStruct Engine.InterpLookupTrack
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FInterpLookupTrack {
	// Fields
	struct TArray<struct FInterpLookupPoint> Points; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Engine.InterpLookupPoint
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FInterpLookupPoint {
	// Fields
	struct FName GroupName; // Offset: 0x0 | Size: 0x8
	float Time; // Offset: 0x8 | Size: 0x4
};

// Object: ScriptStruct Engine.ParticleReplayTrackKey
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FParticleReplayTrackKey {
	// Fields
	float Time; // Offset: 0x0 | Size: 0x4
	float Duration; // Offset: 0x4 | Size: 0x4
	int32_t ClipIDNumber; // Offset: 0x8 | Size: 0x4
};

// Object: ScriptStruct Engine.SoundTrackKey
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FSoundTrackKey {
	// Fields
	float Time; // Offset: 0x0 | Size: 0x4
	float Volume; // Offset: 0x4 | Size: 0x4
	float Pitch; // Offset: 0x8 | Size: 0x4
	char pad_0xC[0x4]; // Offset: 0xc | Size: 0x4
	struct USoundBase* Sound; // Offset: 0x10 | Size: 0x8
};

// Object: ScriptStruct Engine.ToggleTrackKey
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FToggleTrackKey {
	// Fields
	float Time; // Offset: 0x0 | Size: 0x4
	enum class ETrackToggleAction ToggleAction; // Offset: 0x4 | Size: 0x1
	char pad_0x5[0x3]; // Offset: 0x5 | Size: 0x3
};

// Object: ScriptStruct Engine.VisibilityTrackKey
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FVisibilityTrackKey {
	// Fields
	float Time; // Offset: 0x0 | Size: 0x4
	enum class EVisibilityTrackAction Action; // Offset: 0x4 | Size: 0x1
	enum class EVisibilityTrackCondition ActiveCondition; // Offset: 0x5 | Size: 0x1
	char pad_0x6[0x2]; // Offset: 0x6 | Size: 0x2
};

// Object: ScriptStruct Engine.VectorSpringState
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FVectorSpringState {
	// Fields
	char pad_0x0[0x18]; // Offset: 0x0 | Size: 0x18
};

// Object: ScriptStruct Engine.FloatSpringState
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FFloatSpringState {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
};

// Object: ScriptStruct Engine.DrawToRenderTargetContext
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FDrawToRenderTargetContext {
	// Fields
	struct UTextureRenderTarget2D* RenderTarget; // Offset: 0x0 | Size: 0x8
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
};

// Object: ScriptStruct Engine.LatentActionManager
// Inherited Bytes: 0x0 | Struct Size: 0x60
struct FLatentActionManager {
	// Fields
	char pad_0x0[0x60]; // Offset: 0x0 | Size: 0x60
};

// Object: ScriptStruct Engine.LayerActorStats
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FLayerActorStats {
	// Fields
	struct UObject* Type; // Offset: 0x0 | Size: 0x8
	int32_t Total; // Offset: 0x8 | Size: 0x4
	char pad_0xC[0x4]; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct Engine.ReplicatedStaticActorDestructionInfo
// Inherited Bytes: 0x0 | Struct Size: 0x38
struct FReplicatedStaticActorDestructionInfo {
	// Fields
	char pad_0x0[0x30]; // Offset: 0x0 | Size: 0x30
	struct UObject* ObjClass; // Offset: 0x30 | Size: 0x8
};

// Object: ScriptStruct Engine.LevelSimplificationDetails
// Inherited Bytes: 0x0 | Struct Size: 0x12c
struct FLevelSimplificationDetails {
	// Fields
	bool bCreatePackagePerAsset; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	float DetailsPercentage; // Offset: 0x4 | Size: 0x4
	struct FMaterialProxySettings StaticMeshMaterialSettings; // Offset: 0x8 | Size: 0x88
	bool bOverrideLandscapeExportLOD; // Offset: 0x90 | Size: 0x1
	char pad_0x91[0x3]; // Offset: 0x91 | Size: 0x3
	int32_t LandscapeExportLOD; // Offset: 0x94 | Size: 0x4
	struct FMaterialProxySettings LandscapeMaterialSettings; // Offset: 0x98 | Size: 0x88
	bool bBakeFoliageToLandscape; // Offset: 0x120 | Size: 0x1
	bool bBakeGrassToLandscape; // Offset: 0x121 | Size: 0x1
	bool bGenerateMeshNormalMap; // Offset: 0x122 | Size: 0x1
	bool bGenerateMeshMetallicMap; // Offset: 0x123 | Size: 0x1
	bool bGenerateMeshRoughnessMap; // Offset: 0x124 | Size: 0x1
	bool bGenerateMeshSpecularMap; // Offset: 0x125 | Size: 0x1
	bool bGenerateLandscapeNormalMap; // Offset: 0x126 | Size: 0x1
	bool bGenerateLandscapeMetallicMap; // Offset: 0x127 | Size: 0x1
	bool bGenerateLandscapeRoughnessMap; // Offset: 0x128 | Size: 0x1
	bool bGenerateLandscapeSpecularMap; // Offset: 0x129 | Size: 0x1
	char pad_0x12A[0x2]; // Offset: 0x12a | Size: 0x2
};

// Object: ScriptStruct Engine.MaterialProxySettings
// Inherited Bytes: 0x0 | Struct Size: 0x88
struct FMaterialProxySettings {
	// Fields
	struct FIntPoint TextureSize; // Offset: 0x0 | Size: 0x8
	float GutterSpace; // Offset: 0x8 | Size: 0x4
	float MetallicConstant; // Offset: 0xc | Size: 0x4
	float RoughnessConstant; // Offset: 0x10 | Size: 0x4
	float AnisotropyConstant; // Offset: 0x14 | Size: 0x4
	float SpecularConstant; // Offset: 0x18 | Size: 0x4
	float OpacityConstant; // Offset: 0x1c | Size: 0x4
	float OpacityMaskConstant; // Offset: 0x20 | Size: 0x4
	float AmbientOcclusionConstant; // Offset: 0x24 | Size: 0x4
	enum class ETextureSizingType TextureSizingType; // Offset: 0x28 | Size: 0x1
	enum class EMaterialMergeType MaterialMergeType; // Offset: 0x29 | Size: 0x1
	enum class EBlendMode BlendMode; // Offset: 0x2a | Size: 0x1
	char bAllowTwoSidedMaterial : 1; // Offset: 0x2b | Size: 0x1
	char bNormalMap : 1; // Offset: 0x2b | Size: 0x1
	char bTangentMap : 1; // Offset: 0x2b | Size: 0x1
	char bMetallicMap : 1; // Offset: 0x2b | Size: 0x1
	char bRoughnessMap : 1; // Offset: 0x2b | Size: 0x1
	char bAnisotropyMap : 1; // Offset: 0x2b | Size: 0x1
	char bSpecularMap : 1; // Offset: 0x2b | Size: 0x1
	char bEmissiveMap : 1; // Offset: 0x2b | Size: 0x1
	char bOpacityMap : 1; // Offset: 0x2c | Size: 0x1
	char bOpacityMaskMap : 1; // Offset: 0x2c | Size: 0x1
	char bAmbientOcclusionMap : 1; // Offset: 0x2c | Size: 0x1
	char pad_0x2C_3 : 5; // Offset: 0x2c | Size: 0x1
	char pad_0x2D[0x3]; // Offset: 0x2d | Size: 0x3
	struct FIntPoint DiffuseTextureSize; // Offset: 0x30 | Size: 0x8
	struct FIntPoint NormalTextureSize; // Offset: 0x38 | Size: 0x8
	struct FIntPoint TangentTextureSize; // Offset: 0x40 | Size: 0x8
	struct FIntPoint MetallicTextureSize; // Offset: 0x48 | Size: 0x8
	struct FIntPoint RoughnessTextureSize; // Offset: 0x50 | Size: 0x8
	struct FIntPoint AnisotropyTextureSize; // Offset: 0x58 | Size: 0x8
	struct FIntPoint SpecularTextureSize; // Offset: 0x60 | Size: 0x8
	struct FIntPoint EmissiveTextureSize; // Offset: 0x68 | Size: 0x8
	struct FIntPoint OpacityTextureSize; // Offset: 0x70 | Size: 0x8
	struct FIntPoint OpacityMaskTextureSize; // Offset: 0x78 | Size: 0x8
	struct FIntPoint AmbientOcclusionTextureSize; // Offset: 0x80 | Size: 0x8
};

// Object: ScriptStruct Engine.StreamableTextureInstance
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FStreamableTextureInstance {
	// Fields
	char pad_0x0[0x28]; // Offset: 0x0 | Size: 0x28
};

// Object: ScriptStruct Engine.DynamicTextureInstance
// Inherited Bytes: 0x28 | Struct Size: 0x38
struct FDynamicTextureInstance : FStreamableTextureInstance {
	// Fields
	struct UTexture2D* Texture; // Offset: 0x28 | Size: 0x8
	bool bAttached; // Offset: 0x30 | Size: 0x1
	char pad_0x31[0x3]; // Offset: 0x31 | Size: 0x3
	float OriginalRadius; // Offset: 0x34 | Size: 0x4
};

// Object: ScriptStruct Engine.LevelSolarDecorationLightMapGUIDArray
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FLevelSolarDecorationLightMapGUIDArray {
	// Fields
	struct TArray<struct FGuid> MapBuildDataIdArray; // Offset: 0x0 | Size: 0x10
	struct TArray<uint32_t> LODNumArray; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct Engine.PrecomputedLightInstanceData
// Inherited Bytes: 0xa8 | Struct Size: 0x100
struct FPrecomputedLightInstanceData : FSceneComponentInstanceData {
	// Fields
	char pad_0xA8[0x8]; // Offset: 0xa8 | Size: 0x8
	struct FTransform Transform; // Offset: 0xb0 | Size: 0x30
	struct FGuid LightGuid; // Offset: 0xe0 | Size: 0x10
	int32_t PreviewShadowMapChannel; // Offset: 0xf0 | Size: 0x4
	char pad_0xF4[0xc]; // Offset: 0xf4 | Size: 0xc
};

// Object: ScriptStruct Engine.BatchedPoint
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FBatchedPoint {
	// Fields
	struct FVector Position; // Offset: 0x0 | Size: 0xc
	struct FLinearColor Color; // Offset: 0xc | Size: 0x10
	float PointSize; // Offset: 0x1c | Size: 0x4
	float RemainingLifeTime; // Offset: 0x20 | Size: 0x4
	char DepthPriority; // Offset: 0x24 | Size: 0x1
	char pad_0x25[0x3]; // Offset: 0x25 | Size: 0x3
};

// Object: ScriptStruct Engine.BatchedLine
// Inherited Bytes: 0x0 | Struct Size: 0x34
struct FBatchedLine {
	// Fields
	struct FVector Start; // Offset: 0x0 | Size: 0xc
	struct FVector End; // Offset: 0xc | Size: 0xc
	struct FLinearColor Color; // Offset: 0x18 | Size: 0x10
	float Thickness; // Offset: 0x28 | Size: 0x4
	float RemainingLifeTime; // Offset: 0x2c | Size: 0x4
	char DepthPriority; // Offset: 0x30 | Size: 0x1
	char pad_0x31[0x3]; // Offset: 0x31 | Size: 0x3
};

// Object: ScriptStruct Engine.ClientReceiveData
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FClientReceiveData {
	// Fields
	struct APlayerController* LocalPC; // Offset: 0x0 | Size: 0x8
	struct FName MessageType; // Offset: 0x8 | Size: 0x8
	int32_t MessageIndex; // Offset: 0x10 | Size: 0x4
	char pad_0x14[0x4]; // Offset: 0x14 | Size: 0x4
	struct FString MessageString; // Offset: 0x18 | Size: 0x10
	struct APlayerState* RelatedPlayerState_2; // Offset: 0x28 | Size: 0x8
	struct APlayerState* RelatedPlayerState_3; // Offset: 0x30 | Size: 0x8
	struct UObject* OptionalObject; // Offset: 0x38 | Size: 0x8
};

// Object: ScriptStruct Engine.ParameterGroupData
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FParameterGroupData {
	// Fields
	struct FString GroupName; // Offset: 0x0 | Size: 0x10
	int32_t GroupSortPriority; // Offset: 0x10 | Size: 0x4
	char pad_0x14[0x4]; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct Engine.MaterialSpriteElement
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FMaterialSpriteElement {
	// Fields
	struct UMaterialInterface* Material; // Offset: 0x0 | Size: 0x8
	struct UCurveFloat* DistanceToOpacityCurve; // Offset: 0x8 | Size: 0x8
	char bSizeIsInScreenSpace : 1; // Offset: 0x10 | Size: 0x1
	char pad_0x10_1 : 7; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x3]; // Offset: 0x11 | Size: 0x3
	float BaseSizeX; // Offset: 0x14 | Size: 0x4
	float BaseSizeY; // Offset: 0x18 | Size: 0x4
	char pad_0x1C[0x4]; // Offset: 0x1c | Size: 0x4
	struct UCurveFloat* DistanceToSizeCurve; // Offset: 0x20 | Size: 0x8
};

// Object: ScriptStruct Engine.MaterialCachedExpressionData
// Inherited Bytes: 0x0 | Struct Size: 0x228
struct FMaterialCachedExpressionData {
	// Fields
	struct FMaterialCachedParameters Parameters; // Offset: 0x0 | Size: 0x1a0
	struct TArray<struct UObject*> ReferencedTextures; // Offset: 0x1a0 | Size: 0x10
	struct TArray<struct FMaterialFunctionInfo> FunctionInfos; // Offset: 0x1b0 | Size: 0x10
	struct TArray<struct FMaterialParameterCollectionInfo> ParameterCollectionInfos; // Offset: 0x1c0 | Size: 0x10
	struct TArray<struct UMaterialFunctionInterface*> DefaultLayers; // Offset: 0x1d0 | Size: 0x10
	struct TArray<struct UMaterialFunctionInterface*> DefaultLayerBlends; // Offset: 0x1e0 | Size: 0x10
	struct TArray<struct ULandscapeGrassType*> GrassTypes; // Offset: 0x1f0 | Size: 0x10
	struct TArray<struct FName> DynamicParameterNames; // Offset: 0x200 | Size: 0x10
	struct TArray<bool> QualityLevelsUsed; // Offset: 0x210 | Size: 0x10
	char bHasRuntimeVirtualTextureOutput : 1; // Offset: 0x220 | Size: 0x1
	char bHasSceneColor : 1; // Offset: 0x220 | Size: 0x1
	char pad_0x220_2 : 6; // Offset: 0x220 | Size: 0x1
	char pad_0x221[0x7]; // Offset: 0x221 | Size: 0x7
};

// Object: ScriptStruct Engine.MaterialParameterCollectionInfo
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FMaterialParameterCollectionInfo {
	// Fields
	struct FGuid StateId; // Offset: 0x0 | Size: 0x10
	struct UMaterialParameterCollection* ParameterCollection; // Offset: 0x10 | Size: 0x8
};

// Object: ScriptStruct Engine.MaterialFunctionInfo
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FMaterialFunctionInfo {
	// Fields
	struct FGuid StateId; // Offset: 0x0 | Size: 0x10
	struct UMaterialFunctionInterface* Function; // Offset: 0x10 | Size: 0x8
};

// Object: ScriptStruct Engine.MaterialCachedParameters
// Inherited Bytes: 0x0 | Struct Size: 0x1a0
struct FMaterialCachedParameters {
	// Fields
	struct FMaterialCachedParameterEntry Entries[0x5]; // Offset: 0x0 | Size: 0x140
	struct TArray<float> ScalarValues; // Offset: 0x140 | Size: 0x10
	struct TArray<struct FLinearColor> VectorValues; // Offset: 0x150 | Size: 0x10
	struct TArray<struct UTexture*> TextureValues; // Offset: 0x160 | Size: 0x10
	struct TArray<struct UFont*> FontValues; // Offset: 0x170 | Size: 0x10
	struct TArray<int32_t> FontPageValues; // Offset: 0x180 | Size: 0x10
	struct TArray<struct URuntimeVirtualTexture*> RuntimeVirtualTextureValues; // Offset: 0x190 | Size: 0x10
};

// Object: ScriptStruct Engine.MaterialCachedParameterEntry
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FMaterialCachedParameterEntry {
	// Fields
	struct TArray<uint64_t> NameHashes; // Offset: 0x0 | Size: 0x10
	struct TArray<struct FMaterialParameterInfo> ParameterInfos; // Offset: 0x10 | Size: 0x10
	struct TArray<struct FGuid> ExpressionGuids; // Offset: 0x20 | Size: 0x10
	struct TArray<bool> Overrides; // Offset: 0x30 | Size: 0x10
};

// Object: ScriptStruct Engine.MaterialParameterInfo
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FMaterialParameterInfo {
	// Fields
	struct FName Name; // Offset: 0x0 | Size: 0x8
	enum class EMaterialParameterAssociation Association; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x3]; // Offset: 0x9 | Size: 0x3
	int32_t Index; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct Engine.ParameterChannelNames
// Inherited Bytes: 0x0 | Struct Size: 0x60
struct FParameterChannelNames {
	// Fields
	struct FText R; // Offset: 0x0 | Size: 0x18
	struct FText G; // Offset: 0x18 | Size: 0x18
	struct FText B; // Offset: 0x30 | Size: 0x18
	struct FText A; // Offset: 0x48 | Size: 0x18
};

// Object: ScriptStruct Engine.CustomDefine
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FCustomDefine {
	// Fields
	struct FString DefineName; // Offset: 0x0 | Size: 0x10
	struct FString DefineValue; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct Engine.CustomInput
// Inherited Bytes: 0x0 | Struct Size: 0x1c
struct FCustomInput {
	// Fields
	struct FName InputName; // Offset: 0x0 | Size: 0x8
	struct FExpressionInput Input; // Offset: 0x8 | Size: 0xc
	char pad_0x14[0x8]; // Offset: 0x14 | Size: 0x8
};

// Object: ScriptStruct Engine.FunctionExpressionOutput
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FFunctionExpressionOutput {
	// Fields
	struct UMaterialExpressionFunctionOutput* ExpressionOutput; // Offset: 0x0 | Size: 0x8
	struct FGuid ExpressionOutputId; // Offset: 0x8 | Size: 0x10
	struct FExpressionOutput Output; // Offset: 0x18 | Size: 0x8
};

// Object: ScriptStruct Engine.FunctionExpressionInput
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FFunctionExpressionInput {
	// Fields
	struct UMaterialExpressionFunctionInput* ExpressionInput; // Offset: 0x0 | Size: 0x8
	struct FGuid ExpressionInputId; // Offset: 0x8 | Size: 0x10
	struct FExpressionInput Input; // Offset: 0x18 | Size: 0xc
	char pad_0x24[0xc]; // Offset: 0x24 | Size: 0xc
};

// Object: ScriptStruct Engine.FontParameterValue
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FFontParameterValue {
	// Fields
	struct FMaterialParameterInfo ParameterInfo; // Offset: 0x0 | Size: 0x10
	struct UFont* FontValue; // Offset: 0x10 | Size: 0x8
	int32_t FontPage; // Offset: 0x18 | Size: 0x4
	struct FGuid ExpressionGUID; // Offset: 0x1c | Size: 0x10
	char pad_0x2C[0x4]; // Offset: 0x2c | Size: 0x4
};

// Object: ScriptStruct Engine.RuntimeVirtualTextureParameterValue
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FRuntimeVirtualTextureParameterValue {
	// Fields
	struct FMaterialParameterInfo ParameterInfo; // Offset: 0x0 | Size: 0x10
	struct URuntimeVirtualTexture* ParameterValue; // Offset: 0x10 | Size: 0x8
	struct FGuid ExpressionGUID; // Offset: 0x18 | Size: 0x10
};

// Object: ScriptStruct Engine.TextureParameterValue
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FTextureParameterValue {
	// Fields
	struct FMaterialParameterInfo ParameterInfo; // Offset: 0x0 | Size: 0x10
	struct UTexture* ParameterValue; // Offset: 0x10 | Size: 0x8
	struct FGuid ExpressionGUID; // Offset: 0x18 | Size: 0x10
};

// Object: ScriptStruct Engine.VectorParameterValue
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FVectorParameterValue {
	// Fields
	struct FMaterialParameterInfo ParameterInfo; // Offset: 0x0 | Size: 0x10
	struct FLinearColor ParameterValue; // Offset: 0x10 | Size: 0x10
	struct FGuid ExpressionGUID; // Offset: 0x20 | Size: 0x10
};

// Object: ScriptStruct Engine.ScalarParameterValue
// Inherited Bytes: 0x0 | Struct Size: 0x24
struct FScalarParameterValue {
	// Fields
	struct FMaterialParameterInfo ParameterInfo; // Offset: 0x0 | Size: 0x10
	float ParameterValue; // Offset: 0x10 | Size: 0x4
	struct FGuid ExpressionGUID; // Offset: 0x14 | Size: 0x10
};

// Object: ScriptStruct Engine.ScalarParameterAtlasInstanceData
// Inherited Bytes: 0x0 | Struct Size: 0x58
struct FScalarParameterAtlasInstanceData {
	// Fields
	bool bIsUsedAsAtlasPosition; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x7]; // Offset: 0x1 | Size: 0x7
	struct TSoftObjectPtr<UCurveLinearColor> Curve; // Offset: 0x8 | Size: 0x28
	struct TSoftObjectPtr<UCurveLinearColorAtlas> Atlas; // Offset: 0x30 | Size: 0x28
};

// Object: ScriptStruct Engine.MaterialInstanceBasePropertyOverrides
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FMaterialInstanceBasePropertyOverrides {
	// Fields
	char bOverride_OpacityMaskClipValue : 1; // Offset: 0x0 | Size: 0x1
	char bOverride_BlendMode : 1; // Offset: 0x0 | Size: 0x1
	char bOverride_ShadingModel : 1; // Offset: 0x0 | Size: 0x1
	char bOverride_DitheredLODTransition : 1; // Offset: 0x0 | Size: 0x1
	char bOverride_CastDynamicShadowAsMasked : 1; // Offset: 0x0 | Size: 0x1
	char bOverride_TwoSided : 1; // Offset: 0x0 | Size: 0x1
	char TwoSided : 1; // Offset: 0x0 | Size: 0x1
	char bOverride_AllowTwosidedFallback : 1; // Offset: 0x0 | Size: 0x1
	char bAllowTwosidedFallback : 1; // Offset: 0x1 | Size: 0x1
	char DitheredLODTransition : 1; // Offset: 0x1 | Size: 0x1
	char bCastDynamicShadowAsMasked : 1; // Offset: 0x1 | Size: 0x1
	char pad_0x1_3 : 5; // Offset: 0x1 | Size: 0x1
	enum class EBlendMode BlendMode; // Offset: 0x2 | Size: 0x1
	enum class EMaterialShadingModel ShadingModel; // Offset: 0x3 | Size: 0x1
	float OpacityMaskClipValue; // Offset: 0x4 | Size: 0x4
	char bOverride_ShadingRate : 1; // Offset: 0x8 | Size: 0x1
	char pad_0x8_1 : 7; // Offset: 0x8 | Size: 0x1
	enum class EMaterialShadingRate ShadingRate; // Offset: 0x9 | Size: 0x1
	char bOverride_SupportMobileDynamicPointLight : 1; // Offset: 0xa | Size: 0x1
	char SupportMobileDynamicPointLight : 1; // Offset: 0xa | Size: 0x1
	char pad_0xA_2 : 6; // Offset: 0xa | Size: 0x1
	char pad_0xB[0x1]; // Offset: 0xb | Size: 0x1
};

// Object: ScriptStruct Engine.MaterialTextureInfo
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FMaterialTextureInfo {
	// Fields
	float SamplingScale; // Offset: 0x0 | Size: 0x4
	int32_t UVChannelIndex; // Offset: 0x4 | Size: 0x4
	struct FName TextureName; // Offset: 0x8 | Size: 0x8
};

// Object: ScriptStruct Engine.LightmassMaterialInterfaceSettings
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FLightmassMaterialInterfaceSettings {
	// Fields
	float EmissiveBoost; // Offset: 0x0 | Size: 0x4
	float DiffuseBoost; // Offset: 0x4 | Size: 0x4
	float ExportResolutionScale; // Offset: 0x8 | Size: 0x4
	char bCastShadowAsMasked : 1; // Offset: 0xc | Size: 0x1
	char bOverrideCastShadowAsMasked : 1; // Offset: 0xc | Size: 0x1
	char bOverrideEmissiveBoost : 1; // Offset: 0xc | Size: 0x1
	char bOverrideDiffuseBoost : 1; // Offset: 0xc | Size: 0x1
	char bOverrideExportResolutionScale : 1; // Offset: 0xc | Size: 0x1
	char pad_0xC_5 : 3; // Offset: 0xc | Size: 0x1
	char pad_0xD[0x3]; // Offset: 0xd | Size: 0x3
};

// Object: ScriptStruct Engine.MaterialLayersFunctions
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FMaterialLayersFunctions {
	// Fields
	struct TArray<struct UMaterialFunctionInterface*> Layers; // Offset: 0x0 | Size: 0x10
	struct TArray<struct UMaterialFunctionInterface*> Blends; // Offset: 0x10 | Size: 0x10
	struct TArray<bool> LayerStates; // Offset: 0x20 | Size: 0x10
	struct FString KeyString; // Offset: 0x30 | Size: 0x10
};

// Object: ScriptStruct Engine.CollectionParameterBase
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FCollectionParameterBase {
	// Fields
	struct FName ParameterName; // Offset: 0x0 | Size: 0x8
	struct FGuid ID; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct Engine.CollectionVectorParameter
// Inherited Bytes: 0x18 | Struct Size: 0x28
struct FCollectionVectorParameter : FCollectionParameterBase {
	// Fields
	struct FLinearColor DefaultValue; // Offset: 0x18 | Size: 0x10
};

// Object: ScriptStruct Engine.CollectionScalarParameter
// Inherited Bytes: 0x18 | Struct Size: 0x1c
struct FCollectionScalarParameter : FCollectionParameterBase {
	// Fields
	float DefaultValue; // Offset: 0x18 | Size: 0x4
};

// Object: ScriptStruct Engine.InterpGroupActorInfo
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FInterpGroupActorInfo {
	// Fields
	struct FName ObjectName; // Offset: 0x0 | Size: 0x8
	struct TArray<struct AActor*> Actors; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct Engine.CameraCutInfo
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FCameraCutInfo {
	// Fields
	struct FVector Location; // Offset: 0x0 | Size: 0xc
	float Timestamp; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct Engine.MemberReference
// Inherited Bytes: 0x0 | Struct Size: 0x38
struct FMemberReference {
	// Fields
	struct UObject* MemberParent; // Offset: 0x0 | Size: 0x8
	struct FString MemberScope; // Offset: 0x8 | Size: 0x10
	struct FName MemberName; // Offset: 0x18 | Size: 0x8
	struct FGuid MemberGuid; // Offset: 0x20 | Size: 0x10
	bool bSelfContext; // Offset: 0x30 | Size: 0x1
	bool bWasDeprecated; // Offset: 0x31 | Size: 0x1
	char pad_0x32[0x6]; // Offset: 0x32 | Size: 0x6
};

// Object: ScriptStruct Engine.MeshInstancingSettings
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FMeshInstancingSettings {
	// Fields
	struct AActor* ActorClassToUse; // Offset: 0x0 | Size: 0x8
	int32_t InstanceReplacementThreshold; // Offset: 0x8 | Size: 0x4
	enum class EMeshInstancingReplacementMethod MeshReplacementMethod; // Offset: 0xc | Size: 0x1
	bool bSkipMeshesWithVertexColors; // Offset: 0xd | Size: 0x1
	bool bUseHLODVolumes; // Offset: 0xe | Size: 0x1
	char pad_0xF[0x1]; // Offset: 0xf | Size: 0x1
	struct UInstancedStaticMeshComponent* ISMComponentToUse; // Offset: 0x10 | Size: 0x8
};

// Object: ScriptStruct Engine.MeshMergingSettings
// Inherited Bytes: 0x0 | Struct Size: 0xa8
struct FMeshMergingSettings {
	// Fields
	int32_t TargetLightMapResolution; // Offset: 0x0 | Size: 0x4
	enum class EUVOutput OutputUVs[0x8]; // Offset: 0x4 | Size: 0x8
	struct FMaterialProxySettings MaterialSettings; // Offset: 0xc | Size: 0x88
	int32_t GutterSize; // Offset: 0x94 | Size: 0x4
	int32_t SpecificLOD; // Offset: 0x98 | Size: 0x4
	enum class EMeshLODSelectionType LODSelectionType; // Offset: 0x9c | Size: 0x1
	char bGenerateLightMapUV : 1; // Offset: 0x9d | Size: 0x1
	char bComputedLightMapResolution : 1; // Offset: 0x9d | Size: 0x1
	char bPivotPointAtZero : 1; // Offset: 0x9d | Size: 0x1
	char bMergePhysicsData : 1; // Offset: 0x9d | Size: 0x1
	char bMergeMaterials : 1; // Offset: 0x9d | Size: 0x1
	char bCreateMergedMaterial : 1; // Offset: 0x9d | Size: 0x1
	char bBakeVertexDataToMesh : 1; // Offset: 0x9d | Size: 0x1
	char bUseVertexDataForBakingMaterial : 1; // Offset: 0x9d | Size: 0x1
	char bUseTextureBinning : 1; // Offset: 0x9e | Size: 0x1
	char bReuseMeshLightmapUVs : 1; // Offset: 0x9e | Size: 0x1
	char bMergeEquivalentMaterials : 1; // Offset: 0x9e | Size: 0x1
	char bUseLandscapeCulling : 1; // Offset: 0x9e | Size: 0x1
	char bUseLandscapeRoadMode : 1; // Offset: 0x9e | Size: 0x1
	char bAutoPlacingMergedRoad : 1; // Offset: 0x9e | Size: 0x1
	char bIncludeImposters : 1; // Offset: 0x9e | Size: 0x1
	char bAllowDistanceField : 1; // Offset: 0x9e | Size: 0x1
	char pad_0x9F[0x1]; // Offset: 0x9f | Size: 0x1
	int32_t LandscapeRoadSplitFactor; // Offset: 0xa0 | Size: 0x4
	char pad_0xA4[0x4]; // Offset: 0xa4 | Size: 0x4
};

// Object: ScriptStruct Engine.MeshProxySettings
// Inherited Bytes: 0x0 | Struct Size: 0xa8
struct FMeshProxySettings {
	// Fields
	int32_t ScreenSize; // Offset: 0x0 | Size: 0x4
	float VoxelSize; // Offset: 0x4 | Size: 0x4
	struct FMaterialProxySettings MaterialSettings; // Offset: 0x8 | Size: 0x88
	float MergeDistance; // Offset: 0x90 | Size: 0x4
	struct FColor UnresolvedGeometryColor; // Offset: 0x94 | Size: 0x4
	float MaxRayCastDist; // Offset: 0x98 | Size: 0x4
	float HardAngleThreshold; // Offset: 0x9c | Size: 0x4
	int32_t LightMapResolution; // Offset: 0xa0 | Size: 0x4
	enum class EProxyNormalComputationMethod NormalCalculationMethod; // Offset: 0xa4 | Size: 0x1
	enum class ELandscapeCullingPrecision LandscapeCullingPrecision; // Offset: 0xa5 | Size: 0x1
	char bCalculateCorrectLODModel : 1; // Offset: 0xa6 | Size: 0x1
	char bOverrideVoxelSize : 1; // Offset: 0xa6 | Size: 0x1
	char bOverrideTransferDistance : 1; // Offset: 0xa6 | Size: 0x1
	char bUseHardAngleThreshold : 1; // Offset: 0xa6 | Size: 0x1
	char bComputeLightMapResolution : 1; // Offset: 0xa6 | Size: 0x1
	char bRecalculateNormals : 1; // Offset: 0xa6 | Size: 0x1
	char bUseLandscapeCulling : 1; // Offset: 0xa6 | Size: 0x1
	char bAllowAdjacency : 1; // Offset: 0xa6 | Size: 0x1
	char bAllowDistanceField : 1; // Offset: 0xa7 | Size: 0x1
	char bReuseMeshLightmapUVs : 1; // Offset: 0xa7 | Size: 0x1
	char bCreateCollision : 1; // Offset: 0xa7 | Size: 0x1
	char bAllowVertexColors : 1; // Offset: 0xa7 | Size: 0x1
	char bGenerateLightmapUVs : 1; // Offset: 0xa7 | Size: 0x1
	char pad_0xA7_5 : 3; // Offset: 0xa7 | Size: 0x1
};

// Object: ScriptStruct Engine.MeshReductionSettings
// Inherited Bytes: 0x0 | Struct Size: 0x24
struct FMeshReductionSettings {
	// Fields
	float PercentTriangles; // Offset: 0x0 | Size: 0x4
	float PercentVertices; // Offset: 0x4 | Size: 0x4
	float MaxDeviation; // Offset: 0x8 | Size: 0x4
	float PixelError; // Offset: 0xc | Size: 0x4
	float WeldingThreshold; // Offset: 0x10 | Size: 0x4
	float HardAngleThreshold; // Offset: 0x14 | Size: 0x4
	int32_t BaseLODModel; // Offset: 0x18 | Size: 0x4
	enum class EMeshFeatureImportance SilhouetteImportance; // Offset: 0x1c | Size: 0x1
	enum class EMeshFeatureImportance TextureImportance; // Offset: 0x1d | Size: 0x1
	enum class EMeshFeatureImportance ShadingImportance; // Offset: 0x1e | Size: 0x1
	char bRecalculateNormals : 1; // Offset: 0x1f | Size: 0x1
	char bGenerateUniqueLightmapUVs : 1; // Offset: 0x1f | Size: 0x1
	char bKeepSymmetry : 1; // Offset: 0x1f | Size: 0x1
	char bVisibilityAided : 1; // Offset: 0x1f | Size: 0x1
	char bCullOccluded : 1; // Offset: 0x1f | Size: 0x1
	char pad_0x1F_5 : 3; // Offset: 0x1f | Size: 0x1
	enum class EStaticMeshReductionTerimationCriterion TerminationCriterion; // Offset: 0x20 | Size: 0x1
	enum class EMeshFeatureImportance VisibilityAggressiveness; // Offset: 0x21 | Size: 0x1
	enum class EMeshFeatureImportance VertexColorImportance; // Offset: 0x22 | Size: 0x1
	char pad_0x23[0x1]; // Offset: 0x23 | Size: 0x1
};

// Object: ScriptStruct Engine.PurchaseInfo
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FPurchaseInfo {
	// Fields
	struct FString Identifier; // Offset: 0x0 | Size: 0x10
	struct FString DisplayName; // Offset: 0x10 | Size: 0x10
	struct FString DisplayDescription; // Offset: 0x20 | Size: 0x10
	struct FString DisplayPrice; // Offset: 0x30 | Size: 0x10
};

// Object: ScriptStruct Engine.NameCurve
// Inherited Bytes: 0x68 | Struct Size: 0x78
struct FNameCurve : FIndexedCurve {
	// Fields
	struct TArray<struct FNameCurveKey> Keys; // Offset: 0x68 | Size: 0x10
};

// Object: ScriptStruct Engine.NameCurveKey
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FNameCurveKey {
	// Fields
	float Time; // Offset: 0x0 | Size: 0x4
	struct FName Value; // Offset: 0x4 | Size: 0x8
};

// Object: ScriptStruct Engine.NavDataConfig
// Inherited Bytes: 0x30 | Struct Size: 0x78
struct FNavDataConfig : FNavAgentProperties {
	// Fields
	struct FName Name; // Offset: 0x30 | Size: 0x8
	struct FColor Color; // Offset: 0x38 | Size: 0x4
	struct FVector DefaultQueryExtent; // Offset: 0x3c | Size: 0xc
	struct AActor* NavigationDataClass; // Offset: 0x48 | Size: 0x8
	struct TSoftClassPtr<UObject> NavDataClass; // Offset: 0x50 | Size: 0x28
};

// Object: ScriptStruct Engine.NavigationLinkBase
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FNavigationLinkBase {
	// Fields
	float LeftProjectHeight; // Offset: 0x0 | Size: 0x4
	float MaxFallDownLength; // Offset: 0x4 | Size: 0x4
	char pad_0x8[0x4]; // Offset: 0x8 | Size: 0x4
	float SnapRadius; // Offset: 0xc | Size: 0x4
	float SnapHeight; // Offset: 0x10 | Size: 0x4
	struct FNavAgentSelector SupportedAgents; // Offset: 0x14 | Size: 0x4
	char bSupportsAgent0 : 1; // Offset: 0x18 | Size: 0x1
	char bSupportsAgent1 : 1; // Offset: 0x18 | Size: 0x1
	char bSupportsAgent2 : 1; // Offset: 0x18 | Size: 0x1
	char bSupportsAgent3 : 1; // Offset: 0x18 | Size: 0x1
	char bSupportsAgent4 : 1; // Offset: 0x18 | Size: 0x1
	char bSupportsAgent5 : 1; // Offset: 0x18 | Size: 0x1
	char bSupportsAgent6 : 1; // Offset: 0x18 | Size: 0x1
	char bSupportsAgent7 : 1; // Offset: 0x18 | Size: 0x1
	char bSupportsAgent8 : 1; // Offset: 0x19 | Size: 0x1
	char bSupportsAgent9 : 1; // Offset: 0x19 | Size: 0x1
	char bSupportsAgent10 : 1; // Offset: 0x19 | Size: 0x1
	char bSupportsAgent11 : 1; // Offset: 0x19 | Size: 0x1
	char bSupportsAgent12 : 1; // Offset: 0x19 | Size: 0x1
	char bSupportsAgent13 : 1; // Offset: 0x19 | Size: 0x1
	char bSupportsAgent14 : 1; // Offset: 0x19 | Size: 0x1
	char bSupportsAgent15 : 1; // Offset: 0x19 | Size: 0x1
	char pad_0x1A[0x2]; // Offset: 0x1a | Size: 0x2
	enum class ENavLinkDirection Direction; // Offset: 0x1c | Size: 0x1
	char bUseSnapHeight : 1; // Offset: 0x1d | Size: 0x1
	char bSnapToCheapestArea : 1; // Offset: 0x1d | Size: 0x1
	char bCustomFlag0 : 1; // Offset: 0x1d | Size: 0x1
	char bCustomFlag1 : 1; // Offset: 0x1d | Size: 0x1
	char bCustomFlag2 : 1; // Offset: 0x1d | Size: 0x1
	char bCustomFlag3 : 1; // Offset: 0x1d | Size: 0x1
	char bCustomFlag4 : 1; // Offset: 0x1d | Size: 0x1
	char bCustomFlag5 : 1; // Offset: 0x1d | Size: 0x1
	char bCustomFlag6 : 1; // Offset: 0x1e | Size: 0x1
	char bCustomFlag7 : 1; // Offset: 0x1e | Size: 0x1
	char pad_0x1E_2 : 6; // Offset: 0x1e | Size: 0x1
	char pad_0x1F[0x1]; // Offset: 0x1f | Size: 0x1
	struct UNavAreaBase* AreaClass; // Offset: 0x20 | Size: 0x8
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
};

// Object: ScriptStruct Engine.NavigationSegmentLink
// Inherited Bytes: 0x30 | Struct Size: 0x60
struct FNavigationSegmentLink : FNavigationLinkBase {
	// Fields
	struct FVector LeftStart; // Offset: 0x30 | Size: 0xc
	struct FVector LeftEnd; // Offset: 0x3c | Size: 0xc
	struct FVector RightStart; // Offset: 0x48 | Size: 0xc
	struct FVector RightEnd; // Offset: 0x54 | Size: 0xc
};

// Object: ScriptStruct Engine.NavigationLink
// Inherited Bytes: 0x30 | Struct Size: 0x48
struct FNavigationLink : FNavigationLinkBase {
	// Fields
	struct FVector Left; // Offset: 0x30 | Size: 0xc
	struct FVector Right; // Offset: 0x3c | Size: 0xc
};

// Object: ScriptStruct Engine.ChannelDefinition
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FChannelDefinition {
	// Fields
	struct FName ChannelName; // Offset: 0x0 | Size: 0x8
	struct FName ClassName; // Offset: 0x8 | Size: 0x8
	struct UObject* ChannelClass; // Offset: 0x10 | Size: 0x8
	int32_t StaticChannelIndex; // Offset: 0x18 | Size: 0x4
	bool bTickOnCreate; // Offset: 0x1c | Size: 0x1
	bool bServerOpen; // Offset: 0x1d | Size: 0x1
	bool bClientOpen; // Offset: 0x1e | Size: 0x1
	bool bInitialServer; // Offset: 0x1f | Size: 0x1
	bool bInitialClient; // Offset: 0x20 | Size: 0x1
	char pad_0x21[0x7]; // Offset: 0x21 | Size: 0x7
};

// Object: ScriptStruct Engine.PacketSimulationSettings
// Inherited Bytes: 0x0 | Struct Size: 0x34
struct FPacketSimulationSettings {
	// Fields
	int32_t PktLoss; // Offset: 0x0 | Size: 0x4
	int32_t PktLossMaxSize; // Offset: 0x4 | Size: 0x4
	int32_t PktLossMinSize; // Offset: 0x8 | Size: 0x4
	int32_t PktOrder; // Offset: 0xc | Size: 0x4
	int32_t PktDup; // Offset: 0x10 | Size: 0x4
	int32_t PktLag; // Offset: 0x14 | Size: 0x4
	int32_t PktLagVariance; // Offset: 0x18 | Size: 0x4
	int32_t PktLagMin; // Offset: 0x1c | Size: 0x4
	int32_t PktLagMax; // Offset: 0x20 | Size: 0x4
	int32_t PktIncomingLagMin; // Offset: 0x24 | Size: 0x4
	int32_t PktIncomingLagMax; // Offset: 0x28 | Size: 0x4
	int32_t PktIncomingLoss; // Offset: 0x2c | Size: 0x4
	int32_t PktJitter; // Offset: 0x30 | Size: 0x4
};

// Object: ScriptStruct Engine.NetworkEmulationProfileDescription
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FNetworkEmulationProfileDescription {
	// Fields
	struct FString ProfileName; // Offset: 0x0 | Size: 0x10
	struct FString ToolTip; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct Engine.NodeItem
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FNodeItem {
	// Fields
	struct FName ParentName; // Offset: 0x0 | Size: 0x8
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FTransform Transform; // Offset: 0x10 | Size: 0x30
};

// Object: ScriptStruct Engine.ParticleBurst
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FParticleBurst {
	// Fields
	int32_t count; // Offset: 0x0 | Size: 0x4
	int32_t CountLow; // Offset: 0x4 | Size: 0x4
	float Time; // Offset: 0x8 | Size: 0x4
};

// Object: ScriptStruct Engine.ParticleRandomSeedInfo
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FParticleRandomSeedInfo {
	// Fields
	struct FName ParameterName; // Offset: 0x0 | Size: 0x8
	char bGetSeedFromInstance : 1; // Offset: 0x8 | Size: 0x1
	char bInstanceSeedIsIndex : 1; // Offset: 0x8 | Size: 0x1
	char bResetSeedOnEmitterLooping : 1; // Offset: 0x8 | Size: 0x1
	char bRandomlySelectSeedArray : 1; // Offset: 0x8 | Size: 0x1
	char pad_0x8_4 : 4; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x7]; // Offset: 0x9 | Size: 0x7
	struct TArray<int32_t> RandomSeeds; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct Engine.ParticleCurvePair
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FParticleCurvePair {
	// Fields
	struct FString CurveName; // Offset: 0x0 | Size: 0x10
	struct UObject* CurveObject; // Offset: 0x10 | Size: 0x8
};

// Object: ScriptStruct Engine.BeamModifierOptions
// Inherited Bytes: 0x0 | Struct Size: 0x4
struct FBeamModifierOptions {
	// Fields
	char bModify : 1; // Offset: 0x0 | Size: 0x1
	char bScale : 1; // Offset: 0x0 | Size: 0x1
	char bLock : 1; // Offset: 0x0 | Size: 0x1
	char pad_0x0_3 : 5; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
};

// Object: ScriptStruct Engine.ParticleEvent_GenerateInfo
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FParticleEvent_GenerateInfo {
	// Fields
	enum class EParticleEventType Type; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	int32_t Frequency; // Offset: 0x4 | Size: 0x4
	int32_t ParticleFrequency; // Offset: 0x8 | Size: 0x4
	char FirstTimeOnly : 1; // Offset: 0xc | Size: 0x1
	char LastTimeOnly : 1; // Offset: 0xc | Size: 0x1
	char UseReflectedImpactVector : 1; // Offset: 0xc | Size: 0x1
	char bUseOrbitOffset : 1; // Offset: 0xc | Size: 0x1
	char pad_0xC_4 : 4; // Offset: 0xc | Size: 0x1
	char pad_0xD[0x3]; // Offset: 0xd | Size: 0x3
	struct FName CustomName; // Offset: 0x10 | Size: 0x8
	struct TArray<struct UParticleModuleEventSendToGame*> ParticleModuleEventsToSendToGame; // Offset: 0x18 | Size: 0x10
};

// Object: ScriptStruct Engine.LocationBoneSocketInfo
// Inherited Bytes: 0x0 | Struct Size: 0x14
struct FLocationBoneSocketInfo {
	// Fields
	struct FName BoneSocketName; // Offset: 0x0 | Size: 0x8
	struct FVector offset; // Offset: 0x8 | Size: 0xc
};

// Object: ScriptStruct Engine.OrbitOptions
// Inherited Bytes: 0x0 | Struct Size: 0x4
struct FOrbitOptions {
	// Fields
	char bProcessDuringSpawn : 1; // Offset: 0x0 | Size: 0x1
	char bProcessDuringUpdate : 1; // Offset: 0x0 | Size: 0x1
	char bUseEmitterTime : 1; // Offset: 0x0 | Size: 0x1
	char pad_0x0_3 : 5; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
};

// Object: ScriptStruct Engine.EmitterDynamicParameter
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FEmitterDynamicParameter {
	// Fields
	struct FName ParamName; // Offset: 0x0 | Size: 0x8
	char bUseEmitterTime : 1; // Offset: 0x8 | Size: 0x1
	char bSpawnTimeOnly : 1; // Offset: 0x8 | Size: 0x1
	char pad_0x8_2 : 6; // Offset: 0x8 | Size: 0x1
	enum class EEmitterDynamicParameterValue ValueMethod; // Offset: 0x9 | Size: 0x1
	char bScaleVelocityByParamValue : 1; // Offset: 0xa | Size: 0x1
	char pad_0xA_1 : 7; // Offset: 0xa | Size: 0x1
	char pad_0xB[0x5]; // Offset: 0xb | Size: 0x5
	struct FRawDistributionFloat ParamValue; // Offset: 0x10 | Size: 0x30
};

// Object: ScriptStruct Engine.BeamTargetData
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FBeamTargetData {
	// Fields
	struct FName TargetName; // Offset: 0x0 | Size: 0x8
	float TargetPercentage; // Offset: 0x8 | Size: 0x4
};

// Object: ScriptStruct Engine.GPUSpriteResourceData
// Inherited Bytes: 0x0 | Struct Size: 0x160
struct FGPUSpriteResourceData {
	// Fields
	struct TArray<struct FColor> QuantizedColorSamples; // Offset: 0x0 | Size: 0x10
	struct TArray<struct FColor> QuantizedMiscSamples; // Offset: 0x10 | Size: 0x10
	struct TArray<struct FColor> QuantizedSimulationAttrSamples; // Offset: 0x20 | Size: 0x10
	struct FVector4 ColorScale; // Offset: 0x30 | Size: 0x10
	struct FVector4 ColorBias; // Offset: 0x40 | Size: 0x10
	struct FVector4 MiscScale; // Offset: 0x50 | Size: 0x10
	struct FVector4 MiscBias; // Offset: 0x60 | Size: 0x10
	struct FVector4 SimulationAttrCurveScale; // Offset: 0x70 | Size: 0x10
	struct FVector4 SimulationAttrCurveBias; // Offset: 0x80 | Size: 0x10
	struct FVector4 SubImageSize; // Offset: 0x90 | Size: 0x10
	struct FVector4 SizeBySpeed; // Offset: 0xa0 | Size: 0x10
	struct FVector ConstantAcceleration; // Offset: 0xb0 | Size: 0xc
	struct FVector OrbitOffsetBase; // Offset: 0xbc | Size: 0xc
	struct FVector OrbitOffsetRange; // Offset: 0xc8 | Size: 0xc
	struct FVector OrbitFrequencyBase; // Offset: 0xd4 | Size: 0xc
	struct FVector OrbitFrequencyRange; // Offset: 0xe0 | Size: 0xc
	struct FVector OrbitPhaseBase; // Offset: 0xec | Size: 0xc
	struct FVector OrbitPhaseRange; // Offset: 0xf8 | Size: 0xc
	float GlobalVectorFieldScale; // Offset: 0x104 | Size: 0x4
	float GlobalVectorFieldTightness; // Offset: 0x108 | Size: 0x4
	float PerParticleVectorFieldScale; // Offset: 0x10c | Size: 0x4
	float PerParticleVectorFieldBias; // Offset: 0x110 | Size: 0x4
	float DragCoefficientScale; // Offset: 0x114 | Size: 0x4
	float DragCoefficientBias; // Offset: 0x118 | Size: 0x4
	float ResilienceScale; // Offset: 0x11c | Size: 0x4
	float ResilienceBias; // Offset: 0x120 | Size: 0x4
	float CollisionRadiusScale; // Offset: 0x124 | Size: 0x4
	float CollisionRadiusBias; // Offset: 0x128 | Size: 0x4
	float CollisionTimeBias; // Offset: 0x12c | Size: 0x4
	float CollisionRandomSpread; // Offset: 0x130 | Size: 0x4
	float CollisionRandomDistribution; // Offset: 0x134 | Size: 0x4
	float OneMinusFriction; // Offset: 0x138 | Size: 0x4
	float RotationRateScale; // Offset: 0x13c | Size: 0x4
	float CameraMotionBlurAmount; // Offset: 0x140 | Size: 0x4
	enum class EParticleScreenAlignment ScreenAlignment; // Offset: 0x144 | Size: 0x1
	enum class EParticleAxisLock LockAxisFlag; // Offset: 0x145 | Size: 0x1
	char pad_0x146[0x2]; // Offset: 0x146 | Size: 0x2
	struct FVector2D PivotOffset; // Offset: 0x148 | Size: 0x8
	char bRemoveHMDRoll : 1; // Offset: 0x150 | Size: 0x1
	char pad_0x150_1 : 7; // Offset: 0x150 | Size: 0x1
	char pad_0x151[0x3]; // Offset: 0x151 | Size: 0x3
	float MinFacingCameraBlendDistance; // Offset: 0x154 | Size: 0x4
	float MaxFacingCameraBlendDistance; // Offset: 0x158 | Size: 0x4
	char pad_0x15C[0x4]; // Offset: 0x15c | Size: 0x4
};

// Object: ScriptStruct Engine.GPUSpriteEmitterInfo
// Inherited Bytes: 0x0 | Struct Size: 0x270
struct FGPUSpriteEmitterInfo {
	// Fields
	struct UParticleModuleRequired* RequiredModule; // Offset: 0x0 | Size: 0x8
	struct UParticleModuleSpawn* SpawnModule; // Offset: 0x8 | Size: 0x8
	struct UParticleModuleSpawnPerUnit* SpawnPerUnitModule; // Offset: 0x10 | Size: 0x8
	struct TArray<struct UParticleModule*> SpawnModules; // Offset: 0x18 | Size: 0x10
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
	struct FGPUSpriteLocalVectorFieldInfo LocalVectorField; // Offset: 0x30 | Size: 0x70
	struct FFloatDistribution VectorFieldScale; // Offset: 0xa0 | Size: 0x20
	struct FFloatDistribution DragCoefficient; // Offset: 0xc0 | Size: 0x20
	struct FFloatDistribution PointAttractorStrength; // Offset: 0xe0 | Size: 0x20
	struct FFloatDistribution Resilience; // Offset: 0x100 | Size: 0x20
	struct FVector ConstantAcceleration; // Offset: 0x120 | Size: 0xc
	struct FVector PointAttractorPosition; // Offset: 0x12c | Size: 0xc
	float PointAttractorRadiusSq; // Offset: 0x138 | Size: 0x4
	struct FVector OrbitOffsetBase; // Offset: 0x13c | Size: 0xc
	struct FVector OrbitOffsetRange; // Offset: 0x148 | Size: 0xc
	struct FVector2D InvMaxSize; // Offset: 0x154 | Size: 0x8
	float InvRotationRateScale; // Offset: 0x15c | Size: 0x4
	float MaxLifetime; // Offset: 0x160 | Size: 0x4
	int32_t MaxParticleCount; // Offset: 0x164 | Size: 0x4
	enum class EParticleScreenAlignment ScreenAlignment; // Offset: 0x168 | Size: 0x1
	enum class EParticleAxisLock LockAxisFlag; // Offset: 0x169 | Size: 0x1
	char bEnableCollision : 1; // Offset: 0x16a | Size: 0x1
	char pad_0x16A_1 : 7; // Offset: 0x16a | Size: 0x1
	enum class EParticleCollisionMode CollisionMode; // Offset: 0x16b | Size: 0x1
	char bRemoveHMDRoll : 1; // Offset: 0x16c | Size: 0x1
	char pad_0x16C_1 : 7; // Offset: 0x16c | Size: 0x1
	char pad_0x16D[0x3]; // Offset: 0x16d | Size: 0x3
	float MinFacingCameraBlendDistance; // Offset: 0x170 | Size: 0x4
	float MaxFacingCameraBlendDistance; // Offset: 0x174 | Size: 0x4
	struct FRawDistributionVector DynamicColor; // Offset: 0x178 | Size: 0x48
	struct FRawDistributionFloat DynamicAlpha; // Offset: 0x1c0 | Size: 0x30
	struct FRawDistributionVector DynamicColorScale; // Offset: 0x1f0 | Size: 0x48
	struct FRawDistributionFloat DynamicAlphaScale; // Offset: 0x238 | Size: 0x30
	char pad_0x268[0x8]; // Offset: 0x268 | Size: 0x8
};

// Object: ScriptStruct Engine.GPUSpriteLocalVectorFieldInfo
// Inherited Bytes: 0x0 | Struct Size: 0x70
struct FGPUSpriteLocalVectorFieldInfo {
	// Fields
	struct UVectorField* Field; // Offset: 0x0 | Size: 0x8
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FTransform Transform; // Offset: 0x10 | Size: 0x30
	struct FRotator MinInitialRotation; // Offset: 0x40 | Size: 0xc
	struct FRotator MaxInitialRotation; // Offset: 0x4c | Size: 0xc
	struct FRotator RotationRate; // Offset: 0x58 | Size: 0xc
	float Intensity; // Offset: 0x64 | Size: 0x4
	float Tightness; // Offset: 0x68 | Size: 0x4
	char bIgnoreComponentTransform : 1; // Offset: 0x6c | Size: 0x1
	char bTileX : 1; // Offset: 0x6c | Size: 0x1
	char bTileY : 1; // Offset: 0x6c | Size: 0x1
	char bTileZ : 1; // Offset: 0x6c | Size: 0x1
	char bUseFixDT : 1; // Offset: 0x6c | Size: 0x1
	char pad_0x6C_5 : 3; // Offset: 0x6c | Size: 0x1
	char pad_0x6D[0x3]; // Offset: 0x6d | Size: 0x3
};

// Object: ScriptStruct Engine.NamedEmitterMaterial
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FNamedEmitterMaterial {
	// Fields
	struct FName Name; // Offset: 0x0 | Size: 0x8
	struct UMaterialInterface* Material; // Offset: 0x8 | Size: 0x8
};

// Object: ScriptStruct Engine.LODSoloTrack
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FLODSoloTrack {
	// Fields
	struct TArray<char> SoloEnableSetting; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Engine.ParticleSystemLOD
// Inherited Bytes: 0x0 | Struct Size: 0x1
struct FParticleSystemLOD {
	// Fields
	char pad_0x0[0x1]; // Offset: 0x0 | Size: 0x1
};

// Object: ScriptStruct Engine.ParticleSysParam
// Inherited Bytes: 0x0 | Struct Size: 0x80
struct FParticleSysParam {
	// Fields
	struct FName Name; // Offset: 0x0 | Size: 0x8
	enum class EParticleSysParamType ParamType; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x3]; // Offset: 0x9 | Size: 0x3
	float Scalar; // Offset: 0xc | Size: 0x4
	float Scalar_Low; // Offset: 0x10 | Size: 0x4
	struct FVector Vector; // Offset: 0x14 | Size: 0xc
	struct FVector Vector_Low; // Offset: 0x20 | Size: 0xc
	struct FColor Color; // Offset: 0x2c | Size: 0x4
	struct AActor* Actor; // Offset: 0x30 | Size: 0x8
	struct UMaterialInterface* Material; // Offset: 0x38 | Size: 0x8
	char pad_0x40[0x40]; // Offset: 0x40 | Size: 0x40
};

// Object: ScriptStruct Engine.ParticleSystemWorldManagerTickFunction
// Inherited Bytes: 0x28 | Struct Size: 0x30
struct FParticleSystemWorldManagerTickFunction : FTickFunction {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
};

// Object: ScriptStruct Engine.ParticleSystemReplayFrame
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FParticleSystemReplayFrame {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Engine.ParticleEmitterReplayFrame
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FParticleEmitterReplayFrame {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Engine.FreezablePerPlatformInt
// Inherited Bytes: 0x0 | Struct Size: 0x4
struct FFreezablePerPlatformInt {
	// Fields
	char pad_0x0[0x4]; // Offset: 0x0 | Size: 0x4
};

// Object: ScriptStruct Engine.PhysicalAnimationData
// Inherited Bytes: 0x0 | Struct Size: 0x24
struct FPhysicalAnimationData {
	// Fields
	struct FName BodyName; // Offset: 0x0 | Size: 0x8
	char bIsLocalSimulation : 1; // Offset: 0x8 | Size: 0x1
	char pad_0x8_1 : 7; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x3]; // Offset: 0x9 | Size: 0x3
	float OrientationStrength; // Offset: 0xc | Size: 0x4
	float AngularVelocityStrength; // Offset: 0x10 | Size: 0x4
	float PositionStrength; // Offset: 0x14 | Size: 0x4
	float VelocityStrength; // Offset: 0x18 | Size: 0x4
	float MaxLinearForce; // Offset: 0x1c | Size: 0x4
	float MaxAngularForce; // Offset: 0x20 | Size: 0x4
};

// Object: ScriptStruct Engine.TireFrictionScalePair
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FTireFrictionScalePair {
	// Fields
	struct UTireType* TireType; // Offset: 0x0 | Size: 0x8
	float FrictionScale; // Offset: 0x8 | Size: 0x4
	char pad_0xC[0x4]; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct Engine.PhysicalAnimationProfile
// Inherited Bytes: 0x0 | Struct Size: 0x2c
struct FPhysicalAnimationProfile {
	// Fields
	struct FName ProfileName; // Offset: 0x0 | Size: 0x8
	struct FPhysicalAnimationData PhysicalAnimationData; // Offset: 0x8 | Size: 0x24
};

// Object: ScriptStruct Engine.PhysicsConstraintProfileHandle
// Inherited Bytes: 0x0 | Struct Size: 0x10c
struct FPhysicsConstraintProfileHandle {
	// Fields
	struct FConstraintProfileProperties ProfileProperties; // Offset: 0x0 | Size: 0x104
	struct FName ProfileName; // Offset: 0x104 | Size: 0x8
};

// Object: ScriptStruct Engine.ChaosPhysicsSettings
// Inherited Bytes: 0x0 | Struct Size: 0x3
struct FChaosPhysicsSettings {
	// Fields
	enum class EChaosThreadingMode DefaultThreadingModel; // Offset: 0x0 | Size: 0x1
	enum class EChaosSolverTickMode DedicatedThreadTickMode; // Offset: 0x1 | Size: 0x1
	enum class EChaosBufferMode DedicatedThreadBufferMode; // Offset: 0x2 | Size: 0x1
};

// Object: ScriptStruct Engine.PhysicalSurfaceName
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FPhysicalSurfaceName {
	// Fields
	enum class EPhysicalSurface Type; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	struct FName Name; // Offset: 0x4 | Size: 0x8
};

// Object: ScriptStruct Engine.DelegateArray
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FDelegateArray {
	// Fields
	struct TArray<struct FDelegate> Delegates; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Engine.TViewTarget
// Inherited Bytes: 0x0 | Struct Size: 0x680
struct FTViewTarget {
	// Fields
	struct AActor* Target; // Offset: 0x0 | Size: 0x8
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FMinimalViewInfo POV; // Offset: 0x10 | Size: 0x660
	struct APlayerState* PlayerState; // Offset: 0x670 | Size: 0x8
	char pad_0x678[0x8]; // Offset: 0x678 | Size: 0x8
};

// Object: ScriptStruct Engine.CameraCacheEntry
// Inherited Bytes: 0x0 | Struct Size: 0x670
struct FCameraCacheEntry {
	// Fields
	float Timestamp; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0xc]; // Offset: 0x4 | Size: 0xc
	struct FMinimalViewInfo POV; // Offset: 0x10 | Size: 0x660
};

// Object: ScriptStruct Engine.InputActionSpeechMapping
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FInputActionSpeechMapping {
	// Fields
	struct FName ActionName; // Offset: 0x0 | Size: 0x8
	struct FName SpeechKeyword; // Offset: 0x8 | Size: 0x8
};

// Object: ScriptStruct Engine.InputAxisKeyMapping
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FInputAxisKeyMapping {
	// Fields
	struct FName AxisName; // Offset: 0x0 | Size: 0x8
	float Scale; // Offset: 0x8 | Size: 0x4
	char pad_0xC[0x4]; // Offset: 0xc | Size: 0x4
	struct FKey Key; // Offset: 0x10 | Size: 0x18
};

// Object: ScriptStruct Engine.InputActionKeyMapping
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FInputActionKeyMapping {
	// Fields
	struct FName ActionName; // Offset: 0x0 | Size: 0x8
	char bShift : 1; // Offset: 0x8 | Size: 0x1
	char bCtrl : 1; // Offset: 0x8 | Size: 0x1
	char bAlt : 1; // Offset: 0x8 | Size: 0x1
	char bCmd : 1; // Offset: 0x8 | Size: 0x1
	char pad_0x8_4 : 4; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x7]; // Offset: 0x9 | Size: 0x7
	struct FKey Key; // Offset: 0x10 | Size: 0x18
};

// Object: ScriptStruct Engine.InputAxisConfigEntry
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FInputAxisConfigEntry {
	// Fields
	struct FName AxisKeyName; // Offset: 0x0 | Size: 0x8
	struct FInputAxisProperties AxisProperties; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct Engine.InputAxisProperties
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FInputAxisProperties {
	// Fields
	float DeadZone; // Offset: 0x0 | Size: 0x4
	float Sensitivity; // Offset: 0x4 | Size: 0x4
	float Exponent; // Offset: 0x8 | Size: 0x4
	char bInvert : 1; // Offset: 0xc | Size: 0x1
	char pad_0xC_1 : 7; // Offset: 0xc | Size: 0x1
	char pad_0xD[0x3]; // Offset: 0xd | Size: 0x3
};

// Object: ScriptStruct Engine.KeyBind
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FKeyBind {
	// Fields
	struct FKey Key; // Offset: 0x0 | Size: 0x18
	struct FString Command; // Offset: 0x18 | Size: 0x10
	char Control : 1; // Offset: 0x28 | Size: 0x1
	char Shift : 1; // Offset: 0x28 | Size: 0x1
	char Alt : 1; // Offset: 0x28 | Size: 0x1
	char Cmd : 1; // Offset: 0x28 | Size: 0x1
	char bIgnoreCtrl : 1; // Offset: 0x28 | Size: 0x1
	char bIgnoreShift : 1; // Offset: 0x28 | Size: 0x1
	char bIgnoreAlt : 1; // Offset: 0x28 | Size: 0x1
	char bIgnoreCmd : 1; // Offset: 0x28 | Size: 0x1
	char bDisabled : 1; // Offset: 0x29 | Size: 0x1
	char pad_0x29_1 : 7; // Offset: 0x29 | Size: 0x1
	char pad_0x2A[0x6]; // Offset: 0x2a | Size: 0x6
};

// Object: ScriptStruct Engine.PlayerMuteList
// Inherited Bytes: 0x0 | Struct Size: 0x38
struct FPlayerMuteList {
	// Fields
	char pad_0x0[0x30]; // Offset: 0x0 | Size: 0x30
	bool bHasVoiceHandshakeCompleted; // Offset: 0x30 | Size: 0x1
	char pad_0x31[0x3]; // Offset: 0x31 | Size: 0x3
	int32_t VoiceChannelIdx; // Offset: 0x34 | Size: 0x4
};

// Object: ScriptStruct Engine.PoseDataContainer
// Inherited Bytes: 0x0 | Struct Size: 0x90
struct FPoseDataContainer {
	// Fields
	struct TArray<struct FSmartName> PoseNames; // Offset: 0x0 | Size: 0x10
	struct TArray<struct FName> Tracks; // Offset: 0x10 | Size: 0x10
	struct TMap<struct FName, int32_t> TrackMap; // Offset: 0x20 | Size: 0x50
	struct TArray<struct FPoseData> Poses; // Offset: 0x70 | Size: 0x10
	struct TArray<struct FAnimCurveBase> Curves; // Offset: 0x80 | Size: 0x10
};

// Object: ScriptStruct Engine.PoseData
// Inherited Bytes: 0x0 | Struct Size: 0x70
struct FPoseData {
	// Fields
	struct TArray<struct FTransform> LocalSpacePose; // Offset: 0x0 | Size: 0x10
	struct TMap<int32_t, int32_t> TrackToBufferIndex; // Offset: 0x10 | Size: 0x50
	struct TArray<float> CurveData; // Offset: 0x60 | Size: 0x10
};

// Object: ScriptStruct Engine.PreviewAssetAttachContainer
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FPreviewAssetAttachContainer {
	// Fields
	struct TArray<struct FPreviewAttachedObjectPair> AttachedObjects; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Engine.PreviewAttachedObjectPair
// Inherited Bytes: 0x0 | Struct Size: 0x38
struct FPreviewAttachedObjectPair {
	// Fields
	struct TSoftObjectPtr<UObject> AttachedObject; // Offset: 0x0 | Size: 0x28
	struct UObject* Object; // Offset: 0x28 | Size: 0x8
	struct FName AttachedTo; // Offset: 0x30 | Size: 0x8
};

// Object: ScriptStruct Engine.PreviewMeshCollectionEntry
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FPreviewMeshCollectionEntry {
	// Fields
	struct TSoftObjectPtr<USkeletalMesh> SkeletalMesh; // Offset: 0x0 | Size: 0x28
};

// Object: ScriptStruct Engine.PrimitiveComponentInstanceData
// Inherited Bytes: 0xa8 | Struct Size: 0xf0
struct FPrimitiveComponentInstanceData : FSceneComponentInstanceData {
	// Fields
	char pad_0xA8[0x8]; // Offset: 0xa8 | Size: 0x8
	struct FTransform ComponentTransform; // Offset: 0xb0 | Size: 0x30
	int32_t VisibilityId; // Offset: 0xe0 | Size: 0x4
	char pad_0xE4[0x4]; // Offset: 0xe4 | Size: 0x4
	struct UPrimitiveComponent* LODParent; // Offset: 0xe8 | Size: 0x8
};

// Object: ScriptStruct Engine.SpriteCategoryInfo
// Inherited Bytes: 0x0 | Struct Size: 0x38
struct FSpriteCategoryInfo {
	// Fields
	struct FName Category; // Offset: 0x0 | Size: 0x8
	struct FText DisplayName; // Offset: 0x8 | Size: 0x18
	struct FText Description; // Offset: 0x20 | Size: 0x18
};

// Object: ScriptStruct Engine.LevelNameAndTime
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FLevelNameAndTime {
	// Fields
	struct FString LevelName; // Offset: 0x0 | Size: 0x10
	uint32_t LevelChangeTimeInMS; // Offset: 0x10 | Size: 0x4
	char pad_0x14[0x4]; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct Engine.ReverbSettings
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FReverbSettings {
	// Fields
	bool bApplyReverb; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x7]; // Offset: 0x1 | Size: 0x7
	struct UReverbEffect* ReverbEffect; // Offset: 0x8 | Size: 0x8
	struct USoundEffectSubmixPreset* ReverbPluginEffect; // Offset: 0x10 | Size: 0x8
	float Volume; // Offset: 0x18 | Size: 0x4
	float FadeTime; // Offset: 0x1c | Size: 0x4
};

// Object: ScriptStruct Engine.CompressedRichCurve
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FCompressedRichCurve {
	// Fields
	char pad_0x0[0x18]; // Offset: 0x0 | Size: 0x18
};

// Object: ScriptStruct Engine.TransformBase
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FTransformBase {
	// Fields
	struct FName Node; // Offset: 0x0 | Size: 0x8
	struct FTransformBaseConstraint Constraints[0x2]; // Offset: 0x8 | Size: 0x20
};

// Object: ScriptStruct Engine.TransformBaseConstraint
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FTransformBaseConstraint {
	// Fields
	struct TArray<struct FRigTransformConstraint> TransformConstraints; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Engine.RigTransformConstraint
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FRigTransformConstraint {
	// Fields
	enum class EConstraintTransform TranformType; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	struct FName ParentSpace; // Offset: 0x4 | Size: 0x8
	float Weight; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct Engine.Node
// Inherited Bytes: 0x0 | Struct Size: 0x60
struct FNode {
	// Fields
	struct FName Name; // Offset: 0x0 | Size: 0x8
	struct FName ParentName; // Offset: 0x8 | Size: 0x8
	struct FTransform Transform; // Offset: 0x10 | Size: 0x30
	struct FString DisplayName; // Offset: 0x40 | Size: 0x10
	bool bAdvanced; // Offset: 0x50 | Size: 0x1
	char pad_0x51[0xf]; // Offset: 0x51 | Size: 0xf
};

// Object: ScriptStruct Engine.RootMotionSource
// Inherited Bytes: 0x0 | Struct Size: 0x90
struct FRootMotionSource {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
	uint16_t Priority; // Offset: 0x8 | Size: 0x2
	uint16_t LocalId; // Offset: 0xa | Size: 0x2
	enum class ERootMotionAccumulateMode AccumulateMode; // Offset: 0xc | Size: 0x1
	char pad_0xD[0x3]; // Offset: 0xd | Size: 0x3
	struct FName InstanceName; // Offset: 0x10 | Size: 0x8
	float StartTime; // Offset: 0x18 | Size: 0x4
	float CurrentTime; // Offset: 0x1c | Size: 0x4
	float PreviousTime; // Offset: 0x20 | Size: 0x4
	float Duration; // Offset: 0x24 | Size: 0x4
	struct FRootMotionSourceStatus status; // Offset: 0x28 | Size: 0x1
	struct FRootMotionSourceSettings Settings; // Offset: 0x29 | Size: 0x1
	bool bInLocalSpace; // Offset: 0x2a | Size: 0x1
	char pad_0x2B[0x5]; // Offset: 0x2b | Size: 0x5
	struct FRootMotionMovementParams RootMotionParams; // Offset: 0x30 | Size: 0x40
	struct FRootMotionFinishVelocitySettings FinishVelocityParams; // Offset: 0x70 | Size: 0x14
	char pad_0x84[0xc]; // Offset: 0x84 | Size: 0xc
};

// Object: ScriptStruct Engine.RootMotionFinishVelocitySettings
// Inherited Bytes: 0x0 | Struct Size: 0x14
struct FRootMotionFinishVelocitySettings {
	// Fields
	enum class ERootMotionFinishVelocityMode Mode; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	struct FVector SetVelocity; // Offset: 0x4 | Size: 0xc
	float ClampVelocity; // Offset: 0x10 | Size: 0x4
};

// Object: ScriptStruct Engine.RootMotionSourceStatus
// Inherited Bytes: 0x0 | Struct Size: 0x1
struct FRootMotionSourceStatus {
	// Fields
	char Flags; // Offset: 0x0 | Size: 0x1
};

// Object: ScriptStruct Engine.RootMotionSource_JumpForce
// Inherited Bytes: 0x90 | Struct Size: 0xc0
struct FRootMotionSource_JumpForce : FRootMotionSource {
	// Fields
	struct FRotator Rotation; // Offset: 0x84 | Size: 0xc
	float Distance; // Offset: 0x90 | Size: 0x4
	float Height; // Offset: 0x94 | Size: 0x4
	bool bDisableTimeout; // Offset: 0x98 | Size: 0x1
	struct UCurveVector* PathOffsetCurve; // Offset: 0xa0 | Size: 0x8
	struct UCurveFloat* TimeMappingCurve; // Offset: 0xa8 | Size: 0x8
	char pad_0xB5[0xb]; // Offset: 0xb5 | Size: 0xb
};

// Object: ScriptStruct Engine.RootMotionSource_MoveToDynamicForce
// Inherited Bytes: 0x90 | Struct Size: 0xc0
struct FRootMotionSource_MoveToDynamicForce : FRootMotionSource {
	// Fields
	struct FVector StartLocation; // Offset: 0x84 | Size: 0xc
	struct FVector InitialTargetLocation; // Offset: 0x90 | Size: 0xc
	struct FVector TargetLocation; // Offset: 0x9c | Size: 0xc
	bool bRestrictSpeedToExpected; // Offset: 0xa8 | Size: 0x1
	struct UCurveVector* PathOffsetCurve; // Offset: 0xb0 | Size: 0x8
	struct UCurveFloat* TimeMappingCurve; // Offset: 0xb8 | Size: 0x8
};

// Object: ScriptStruct Engine.RootMotionSource_MoveToForce
// Inherited Bytes: 0x90 | Struct Size: 0xb0
struct FRootMotionSource_MoveToForce : FRootMotionSource {
	// Fields
	struct FVector StartLocation; // Offset: 0x84 | Size: 0xc
	struct FVector TargetLocation; // Offset: 0x90 | Size: 0xc
	bool bRestrictSpeedToExpected; // Offset: 0x9c | Size: 0x1
	struct UCurveVector* PathOffsetCurve; // Offset: 0xa0 | Size: 0x8
};

// Object: ScriptStruct Engine.RootMotionSource_RadialForce
// Inherited Bytes: 0x90 | Struct Size: 0xd0
struct FRootMotionSource_RadialForce : FRootMotionSource {
	// Fields
	struct FVector Location; // Offset: 0x84 | Size: 0xc
	struct AActor* LocationActor; // Offset: 0x90 | Size: 0x8
	float Radius; // Offset: 0x98 | Size: 0x4
	float Strength; // Offset: 0x9c | Size: 0x4
	bool bIsPush; // Offset: 0xa0 | Size: 0x1
	bool bNoZForce; // Offset: 0xa1 | Size: 0x1
	struct UCurveFloat* StrengthDistanceFalloff; // Offset: 0xa8 | Size: 0x8
	struct UCurveFloat* StrengthOverTime; // Offset: 0xb0 | Size: 0x8
	bool bUseFixedWorldDirection; // Offset: 0xb8 | Size: 0x1
	struct FRotator FixedWorldDirection; // Offset: 0xbc | Size: 0xc
	char pad_0xCB[0x5]; // Offset: 0xcb | Size: 0x5
};

// Object: ScriptStruct Engine.RootMotionSource_ConstantForce
// Inherited Bytes: 0x90 | Struct Size: 0xa0
struct FRootMotionSource_ConstantForce : FRootMotionSource {
	// Fields
	struct FVector Force; // Offset: 0x84 | Size: 0xc
	struct UCurveFloat* StrengthOverTime; // Offset: 0x90 | Size: 0x8
};

// Object: ScriptStruct Engine.CameraExposureSettings
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FCameraExposureSettings {
	// Fields
	enum class EAutoExposureMethod Method; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	float LowPercent; // Offset: 0x4 | Size: 0x4
	float HighPercent; // Offset: 0x8 | Size: 0x4
	float MinBrightness; // Offset: 0xc | Size: 0x4
	float MaxBrightness; // Offset: 0x10 | Size: 0x4
	float SpeedUp; // Offset: 0x14 | Size: 0x4
	float SpeedDown; // Offset: 0x18 | Size: 0x4
	float Bias; // Offset: 0x1c | Size: 0x4
	struct UCurveFloat* BiasCurve; // Offset: 0x20 | Size: 0x8
	struct UTexture* MeterMask; // Offset: 0x28 | Size: 0x8
	float HistogramLogMin; // Offset: 0x30 | Size: 0x4
	float HistogramLogMax; // Offset: 0x34 | Size: 0x4
	float CalibrationConstant; // Offset: 0x38 | Size: 0x4
	char ApplyPhysicalCameraExposure : 1; // Offset: 0x3c | Size: 0x1
	char pad_0x3C_1 : 7; // Offset: 0x3c | Size: 0x1
	char pad_0x3D[0x3]; // Offset: 0x3d | Size: 0x3
};

// Object: ScriptStruct Engine.LensSettings
// Inherited Bytes: 0x0 | Struct Size: 0xe0
struct FLensSettings {
	// Fields
	struct FLensBloomSettings Bloom; // Offset: 0x0 | Size: 0xb8
	struct FLensImperfectionSettings Imperfections; // Offset: 0xb8 | Size: 0x20
	float ChromaticAberration; // Offset: 0xd8 | Size: 0x4
	char pad_0xDC[0x4]; // Offset: 0xdc | Size: 0x4
};

// Object: ScriptStruct Engine.LensImperfectionSettings
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FLensImperfectionSettings {
	// Fields
	struct UTexture* DirtMask; // Offset: 0x0 | Size: 0x8
	float DirtMaskIntensity; // Offset: 0x8 | Size: 0x4
	struct FLinearColor DirtMaskTint; // Offset: 0xc | Size: 0x10
	char pad_0x1C[0x4]; // Offset: 0x1c | Size: 0x4
};

// Object: ScriptStruct Engine.LensBloomSettings
// Inherited Bytes: 0x0 | Struct Size: 0xb8
struct FLensBloomSettings {
	// Fields
	struct FGaussianSumBloomSettings GaussianSum; // Offset: 0x0 | Size: 0x84
	char pad_0x84[0x4]; // Offset: 0x84 | Size: 0x4
	struct FConvolutionBloomSettings Convolution; // Offset: 0x88 | Size: 0x28
	enum class EBloomMethod Method; // Offset: 0xb0 | Size: 0x1
	char pad_0xB1[0x7]; // Offset: 0xb1 | Size: 0x7
};

// Object: ScriptStruct Engine.ConvolutionBloomSettings
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FConvolutionBloomSettings {
	// Fields
	struct UTexture2D* Texture; // Offset: 0x0 | Size: 0x8
	float Size; // Offset: 0x8 | Size: 0x4
	struct FVector2D CenterUV; // Offset: 0xc | Size: 0x8
	float PreFilterMin; // Offset: 0x14 | Size: 0x4
	float PreFilterMax; // Offset: 0x18 | Size: 0x4
	float PreFilterMult; // Offset: 0x1c | Size: 0x4
	float BufferScale; // Offset: 0x20 | Size: 0x4
	char pad_0x24[0x4]; // Offset: 0x24 | Size: 0x4
};

// Object: ScriptStruct Engine.GaussianSumBloomSettings
// Inherited Bytes: 0x0 | Struct Size: 0x84
struct FGaussianSumBloomSettings {
	// Fields
	float Intensity; // Offset: 0x0 | Size: 0x4
	float Threshold; // Offset: 0x4 | Size: 0x4
	float SizeScale; // Offset: 0x8 | Size: 0x4
	float Filter1Size; // Offset: 0xc | Size: 0x4
	float Filter2Size; // Offset: 0x10 | Size: 0x4
	float Filter3Size; // Offset: 0x14 | Size: 0x4
	float Filter4Size; // Offset: 0x18 | Size: 0x4
	float Filter5Size; // Offset: 0x1c | Size: 0x4
	float Filter6Size; // Offset: 0x20 | Size: 0x4
	struct FLinearColor Filter1Tint; // Offset: 0x24 | Size: 0x10
	struct FLinearColor Filter2Tint; // Offset: 0x34 | Size: 0x10
	struct FLinearColor Filter3Tint; // Offset: 0x44 | Size: 0x10
	struct FLinearColor Filter4Tint; // Offset: 0x54 | Size: 0x10
	struct FLinearColor Filter5Tint; // Offset: 0x64 | Size: 0x10
	struct FLinearColor Filter6Tint; // Offset: 0x74 | Size: 0x10
};

// Object: ScriptStruct Engine.FilmStockSettings
// Inherited Bytes: 0x0 | Struct Size: 0x14
struct FFilmStockSettings {
	// Fields
	float Slope; // Offset: 0x0 | Size: 0x4
	float Toe; // Offset: 0x4 | Size: 0x4
	float Shoulder; // Offset: 0x8 | Size: 0x4
	float BlackClip; // Offset: 0xc | Size: 0x4
	float WhiteClip; // Offset: 0x10 | Size: 0x4
};

// Object: ScriptStruct Engine.ColorGradingSettings
// Inherited Bytes: 0x0 | Struct Size: 0x190
struct FColorGradingSettings {
	// Fields
	struct FColorGradePerRangeSettings Global; // Offset: 0x0 | Size: 0x60
	struct FColorGradePerRangeSettings Shadows; // Offset: 0x60 | Size: 0x60
	struct FColorGradePerRangeSettings Midtones; // Offset: 0xc0 | Size: 0x60
	struct FColorGradePerRangeSettings Highlights; // Offset: 0x120 | Size: 0x60
	float ShadowsMax; // Offset: 0x180 | Size: 0x4
	float HighlightsMin; // Offset: 0x184 | Size: 0x4
	char pad_0x188[0x8]; // Offset: 0x188 | Size: 0x8
};

// Object: ScriptStruct Engine.ColorGradePerRangeSettings
// Inherited Bytes: 0x0 | Struct Size: 0x60
struct FColorGradePerRangeSettings {
	// Fields
	struct FVector4 Saturation; // Offset: 0x0 | Size: 0x10
	struct FVector4 Contrast; // Offset: 0x10 | Size: 0x10
	struct FVector4 Gamma; // Offset: 0x20 | Size: 0x10
	struct FVector4 Gain; // Offset: 0x30 | Size: 0x10
	struct FVector4 offset; // Offset: 0x40 | Size: 0x10
	char pad_0x50[0x10]; // Offset: 0x50 | Size: 0x10
};

// Object: ScriptStruct Engine.EngineShowFlagsSetting
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FEngineShowFlagsSetting {
	// Fields
	struct FString ShowFlagName; // Offset: 0x0 | Size: 0x10
	bool Enabled; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x7]; // Offset: 0x11 | Size: 0x7
};

// Object: ScriptStruct Engine.SimpleCurve
// Inherited Bytes: 0x70 | Struct Size: 0x80
struct FSimpleCurve : FRealCurve {
	// Fields
	enum class ERichCurveInterpMode InterpMode; // Offset: 0x6e | Size: 0x1
	struct TArray<struct FSimpleCurveKey> Keys; // Offset: 0x70 | Size: 0x10
};

// Object: ScriptStruct Engine.SimpleCurveKey
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FSimpleCurveKey {
	// Fields
	float Time; // Offset: 0x0 | Size: 0x4
	float Value; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct Engine.SingleAnimationPlayData
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FSingleAnimationPlayData {
	// Fields
	struct UAnimationAsset* AnimToPlay; // Offset: 0x0 | Size: 0x8
	char bSavedLooping : 1; // Offset: 0x8 | Size: 0x1
	char bSavedPlaying : 1; // Offset: 0x8 | Size: 0x1
	char pad_0x8_2 : 6; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x3]; // Offset: 0x9 | Size: 0x3
	float SavedPosition; // Offset: 0xc | Size: 0x4
	float SavedPlayRate; // Offset: 0x10 | Size: 0x4
	char pad_0x14[0x4]; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct Engine.SkeletalMaterial
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FSkeletalMaterial {
	// Fields
	struct UMaterialInterface* MaterialInterface; // Offset: 0x0 | Size: 0x8
	struct FName MaterialSlotName; // Offset: 0x8 | Size: 0x8
	struct FMeshUVChannelInfo UVChannelData; // Offset: 0x10 | Size: 0x14
	char pad_0x24[0x4]; // Offset: 0x24 | Size: 0x4
};

// Object: ScriptStruct Engine.ClothingAssetData_Legacy
// Inherited Bytes: 0x0 | Struct Size: 0x70
struct FClothingAssetData_Legacy {
	// Fields
	struct FName AssetName; // Offset: 0x0 | Size: 0x8
	struct FString ApexFileName; // Offset: 0x8 | Size: 0x10
	bool bClothPropertiesChanged; // Offset: 0x18 | Size: 0x1
	char pad_0x19[0x3]; // Offset: 0x19 | Size: 0x3
	struct FClothPhysicsProperties_Legacy PhysicsProperties; // Offset: 0x1c | Size: 0x50
	char pad_0x6C[0x4]; // Offset: 0x6c | Size: 0x4
};

// Object: ScriptStruct Engine.ClothPhysicsProperties_Legacy
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FClothPhysicsProperties_Legacy {
	// Fields
	float VerticalResistance; // Offset: 0x0 | Size: 0x4
	float HorizontalResistance; // Offset: 0x4 | Size: 0x4
	float BendResistance; // Offset: 0x8 | Size: 0x4
	float ShearResistance; // Offset: 0xc | Size: 0x4
	float Friction; // Offset: 0x10 | Size: 0x4
	float Damping; // Offset: 0x14 | Size: 0x4
	float TetherStiffness; // Offset: 0x18 | Size: 0x4
	float TetherLimit; // Offset: 0x1c | Size: 0x4
	float Drag; // Offset: 0x20 | Size: 0x4
	float StiffnessFrequency; // Offset: 0x24 | Size: 0x4
	float GravityScale; // Offset: 0x28 | Size: 0x4
	float MassScale; // Offset: 0x2c | Size: 0x4
	float InertiaBlend; // Offset: 0x30 | Size: 0x4
	float SelfCollisionThickness; // Offset: 0x34 | Size: 0x4
	float SelfCollisionSquashScale; // Offset: 0x38 | Size: 0x4
	float SelfCollisionStiffness; // Offset: 0x3c | Size: 0x4
	float SolverFrequency; // Offset: 0x40 | Size: 0x4
	float FiberCompression; // Offset: 0x44 | Size: 0x4
	float FiberExpansion; // Offset: 0x48 | Size: 0x4
	float FiberResistance; // Offset: 0x4c | Size: 0x4
};

// Object: ScriptStruct Engine.SkeletalMeshLODInfo
// Inherited Bytes: 0x0 | Struct Size: 0xb8
struct FSkeletalMeshLODInfo {
	// Fields
	struct FPerPlatformFloat ScreenSize; // Offset: 0x0 | Size: 0x4
	float LODHysteresis; // Offset: 0x4 | Size: 0x4
	struct TArray<int32_t> LODMaterialMap; // Offset: 0x8 | Size: 0x10
	struct FSkeletalMeshBuildSettings BuildSettings; // Offset: 0x18 | Size: 0x14
	struct FSkeletalMeshOptimizationSettings ReductionSettings; // Offset: 0x2c | Size: 0x3c
	struct TArray<struct FBoneReference> BonesToRemove; // Offset: 0x68 | Size: 0x10
	struct TArray<struct FBoneReference> BonesToPrioritize; // Offset: 0x78 | Size: 0x10
	float WeightOfPrioritization; // Offset: 0x88 | Size: 0x4
	char pad_0x8C[0x4]; // Offset: 0x8c | Size: 0x4
	struct UAnimSequence* BakePose; // Offset: 0x90 | Size: 0x8
	struct UAnimSequence* BakePoseOverride; // Offset: 0x98 | Size: 0x8
	struct FString SourceImportFilename; // Offset: 0xa0 | Size: 0x10
	enum class ESkinCacheUsage SkinCacheUsage; // Offset: 0xb0 | Size: 0x1
	char bHasBeenSimplified : 1; // Offset: 0xb1 | Size: 0x1
	char bHasPerLODVertexColors : 1; // Offset: 0xb1 | Size: 0x1
	char bAllowCPUAccess : 1; // Offset: 0xb1 | Size: 0x1
	char bSupportUniformlyDistributedSampling : 1; // Offset: 0xb1 | Size: 0x1
	char pad_0xB1_4 : 4; // Offset: 0xb1 | Size: 0x1
	char pad_0xB2[0x6]; // Offset: 0xb2 | Size: 0x6
};

// Object: ScriptStruct Engine.SkeletalMeshOptimizationSettings
// Inherited Bytes: 0x0 | Struct Size: 0x3c
struct FSkeletalMeshOptimizationSettings {
	// Fields
	enum class SkeletalMeshTerminationCriterion TerminationCriterion; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	float NumOfTrianglesPercentage; // Offset: 0x4 | Size: 0x4
	float NumOfVertPercentage; // Offset: 0x8 | Size: 0x4
	uint32_t MaxNumOfTriangles; // Offset: 0xc | Size: 0x4
	uint32_t MaxNumOfVerts; // Offset: 0x10 | Size: 0x4
	float MaxDeviationPercentage; // Offset: 0x14 | Size: 0x4
	enum class SkeletalMeshOptimizationType ReductionMethod; // Offset: 0x18 | Size: 0x1
	enum class SkeletalMeshOptimizationImportance SilhouetteImportance; // Offset: 0x19 | Size: 0x1
	enum class SkeletalMeshOptimizationImportance TextureImportance; // Offset: 0x1a | Size: 0x1
	enum class SkeletalMeshOptimizationImportance ShadingImportance; // Offset: 0x1b | Size: 0x1
	enum class SkeletalMeshOptimizationImportance SkinningImportance; // Offset: 0x1c | Size: 0x1
	char bRemapMorphTargets : 1; // Offset: 0x1d | Size: 0x1
	char bRecalcNormals : 1; // Offset: 0x1d | Size: 0x1
	char pad_0x1D_2 : 6; // Offset: 0x1d | Size: 0x1
	char pad_0x1E[0x2]; // Offset: 0x1e | Size: 0x2
	float WeldingThreshold; // Offset: 0x20 | Size: 0x4
	float NormalsThreshold; // Offset: 0x24 | Size: 0x4
	int32_t MaxBonesPerVertex; // Offset: 0x28 | Size: 0x4
	char bEnforceBoneBoundaries : 1; // Offset: 0x2c | Size: 0x1
	char pad_0x2C_1 : 7; // Offset: 0x2c | Size: 0x1
	char pad_0x2D[0x3]; // Offset: 0x2d | Size: 0x3
	float VolumeImportance; // Offset: 0x30 | Size: 0x4
	char bLockEdges : 1; // Offset: 0x34 | Size: 0x1
	char bLockColorBounaries : 1; // Offset: 0x34 | Size: 0x1
	char pad_0x34_2 : 6; // Offset: 0x34 | Size: 0x1
	char pad_0x35[0x3]; // Offset: 0x35 | Size: 0x3
	int32_t BaseLOD; // Offset: 0x38 | Size: 0x4
};

// Object: ScriptStruct Engine.SkeletalMeshClothBuildParams
// Inherited Bytes: 0x0 | Struct Size: 0x58
struct FSkeletalMeshClothBuildParams {
	// Fields
	struct TWeakObjectPtr<struct UClothingAssetBase> TargetAsset; // Offset: 0x0 | Size: 0x8
	int32_t TargetLod; // Offset: 0x8 | Size: 0x4
	bool bRemapParameters; // Offset: 0xc | Size: 0x1
	char pad_0xD[0x3]; // Offset: 0xd | Size: 0x3
	struct FString AssetName; // Offset: 0x10 | Size: 0x10
	int32_t LODIndex; // Offset: 0x20 | Size: 0x4
	int32_t SourceSection; // Offset: 0x24 | Size: 0x4
	bool bRemoveFromMesh; // Offset: 0x28 | Size: 0x1
	char pad_0x29[0x7]; // Offset: 0x29 | Size: 0x7
	struct TSoftObjectPtr<UPhysicsAsset> PhysicsAsset; // Offset: 0x30 | Size: 0x28
};

// Object: ScriptStruct Engine.BoneMirrorExport
// Inherited Bytes: 0x0 | Struct Size: 0x14
struct FBoneMirrorExport {
	// Fields
	struct FName BoneName; // Offset: 0x0 | Size: 0x8
	struct FName SourceBoneName; // Offset: 0x8 | Size: 0x8
	enum class EAxis BoneFlipAxis; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x3]; // Offset: 0x11 | Size: 0x3
};

// Object: ScriptStruct Engine.BoneMirrorInfo
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FBoneMirrorInfo {
	// Fields
	int32_t SourceIndex; // Offset: 0x0 | Size: 0x4
	enum class EAxis BoneFlipAxis; // Offset: 0x4 | Size: 0x1
	char pad_0x5[0x3]; // Offset: 0x5 | Size: 0x3
};

// Object: ScriptStruct Engine.SkeletalMeshComponentClothTickFunction
// Inherited Bytes: 0x28 | Struct Size: 0x30
struct FSkeletalMeshComponentClothTickFunction : FTickFunction {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
};

// Object: ScriptStruct Engine.SkeletalMeshComponentEndPhysicsTickFunction
// Inherited Bytes: 0x28 | Struct Size: 0x30
struct FSkeletalMeshComponentEndPhysicsTickFunction : FTickFunction {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
};

// Object: ScriptStruct Engine.SkeletalMeshLODGroupSettings
// Inherited Bytes: 0x0 | Struct Size: 0x80
struct FSkeletalMeshLODGroupSettings {
	// Fields
	struct FPerPlatformFloat ScreenSize; // Offset: 0x0 | Size: 0x4
	float LODHysteresis; // Offset: 0x4 | Size: 0x4
	enum class EBoneFilterActionOption BoneFilterActionOption; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x7]; // Offset: 0x9 | Size: 0x7
	struct TArray<struct FBoneFilter> BoneList; // Offset: 0x10 | Size: 0x10
	struct TArray<struct FName> BonesToPrioritize; // Offset: 0x20 | Size: 0x10
	float WeightOfPrioritization; // Offset: 0x30 | Size: 0x4
	char pad_0x34[0x4]; // Offset: 0x34 | Size: 0x4
	struct UAnimSequence* BakePose; // Offset: 0x38 | Size: 0x8
	struct FSkeletalMeshOptimizationSettings ReductionSettings; // Offset: 0x40 | Size: 0x3c
	char pad_0x7C[0x4]; // Offset: 0x7c | Size: 0x4
};

// Object: ScriptStruct Engine.BoneFilter
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FBoneFilter {
	// Fields
	bool bExcludeSelf; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	struct FName BoneName; // Offset: 0x4 | Size: 0x8
};

// Object: ScriptStruct Engine.SkeletalMeshSamplingInfo
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FSkeletalMeshSamplingInfo {
	// Fields
	struct TArray<struct FSkeletalMeshSamplingRegion> Regions; // Offset: 0x0 | Size: 0x10
	struct FSkeletalMeshSamplingBuiltData BuiltData; // Offset: 0x10 | Size: 0x20
};

// Object: ScriptStruct Engine.SkeletalMeshSamplingBuiltData
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FSkeletalMeshSamplingBuiltData {
	// Fields
	struct TArray<struct FSkeletalMeshSamplingLODBuiltData> WholeMeshBuiltData; // Offset: 0x0 | Size: 0x10
	struct TArray<struct FSkeletalMeshSamplingRegionBuiltData> RegionBuiltData; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct Engine.SkeletalMeshSamplingRegionBuiltData
// Inherited Bytes: 0x0 | Struct Size: 0x78
struct FSkeletalMeshSamplingRegionBuiltData {
	// Fields
	char pad_0x0[0x78]; // Offset: 0x0 | Size: 0x78
};

// Object: ScriptStruct Engine.SkeletalMeshSamplingLODBuiltData
// Inherited Bytes: 0x0 | Struct Size: 0x48
struct FSkeletalMeshSamplingLODBuiltData {
	// Fields
	char pad_0x0[0x48]; // Offset: 0x0 | Size: 0x48
};

// Object: ScriptStruct Engine.SkeletalMeshSamplingRegion
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FSkeletalMeshSamplingRegion {
	// Fields
	struct FName Name; // Offset: 0x0 | Size: 0x8
	int32_t LODIndex; // Offset: 0x8 | Size: 0x4
	char bSupportUniformlyDistributedSampling : 1; // Offset: 0xc | Size: 0x1
	char pad_0xC_1 : 7; // Offset: 0xc | Size: 0x1
	char pad_0xD[0x3]; // Offset: 0xd | Size: 0x3
	struct TArray<struct FSkeletalMeshSamplingRegionMaterialFilter> MaterialFilters; // Offset: 0x10 | Size: 0x10
	struct TArray<struct FSkeletalMeshSamplingRegionBoneFilter> BoneFilters; // Offset: 0x20 | Size: 0x10
};

// Object: ScriptStruct Engine.SkeletalMeshSamplingRegionBoneFilter
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FSkeletalMeshSamplingRegionBoneFilter {
	// Fields
	struct FName BoneName; // Offset: 0x0 | Size: 0x8
	char bIncludeOrExclude : 1; // Offset: 0x8 | Size: 0x1
	char bApplyToChildren : 1; // Offset: 0x8 | Size: 0x1
	char pad_0x8_2 : 6; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x3]; // Offset: 0x9 | Size: 0x3
};

// Object: ScriptStruct Engine.SkeletalMeshSamplingRegionMaterialFilter
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FSkeletalMeshSamplingRegionMaterialFilter {
	// Fields
	struct FName MaterialName; // Offset: 0x0 | Size: 0x8
};

// Object: ScriptStruct Engine.VirtualBone
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FVirtualBone {
	// Fields
	struct FName SourceBoneName; // Offset: 0x0 | Size: 0x8
	struct FName TargetBoneName; // Offset: 0x8 | Size: 0x8
	struct FName VirtualBoneName; // Offset: 0x10 | Size: 0x8
};

// Object: ScriptStruct Engine.AnimSlotGroup
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FAnimSlotGroup {
	// Fields
	struct FName GroupName; // Offset: 0x0 | Size: 0x8
	struct TArray<struct FName> SlotNames; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct Engine.RigConfiguration
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FRigConfiguration {
	// Fields
	struct URig* Rig; // Offset: 0x0 | Size: 0x8
	struct TArray<struct FNameMapping> BoneMappingTable; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct Engine.NameMapping
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FNameMapping {
	// Fields
	struct FName NodeName; // Offset: 0x0 | Size: 0x8
	struct FName BoneName; // Offset: 0x8 | Size: 0x8
};

// Object: ScriptStruct Engine.BoneReductionSetting
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FBoneReductionSetting {
	// Fields
	struct TArray<struct FName> BonesToRemove; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Engine.ReferencePose
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FReferencePose {
	// Fields
	struct FName PoseName; // Offset: 0x0 | Size: 0x8
	struct TArray<struct FTransform> ReferencePose; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct Engine.BoneNode
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FBoneNode {
	// Fields
	struct FName Name; // Offset: 0x0 | Size: 0x8
	int32_t ParentIndex; // Offset: 0x8 | Size: 0x4
	enum class EBoneTranslationRetargetingMode TranslationRetargetingMode; // Offset: 0xc | Size: 0x1
	char pad_0xD[0x3]; // Offset: 0xd | Size: 0x3
};

// Object: ScriptStruct Engine.SkeletonToMeshLinkup
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FSkeletonToMeshLinkup {
	// Fields
	struct TArray<int32_t> SkeletonToMeshTable; // Offset: 0x0 | Size: 0x10
	struct TArray<int32_t> MeshToSkeletonTable; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct Engine.SkelMeshComponentLODInfo
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FSkelMeshComponentLODInfo {
	// Fields
	struct TArray<bool> HiddenMaterials; // Offset: 0x0 | Size: 0x10
	char pad_0x10[0x18]; // Offset: 0x10 | Size: 0x18
};

// Object: ScriptStruct Engine.SkelMeshSkinWeightInfo
// Inherited Bytes: 0x0 | Struct Size: 0x3c
struct FSkelMeshSkinWeightInfo {
	// Fields
	int32_t Bones[0xc]; // Offset: 0x0 | Size: 0x30
	char Weights[0xc]; // Offset: 0x30 | Size: 0xc
};

// Object: ScriptStruct Engine.SkinWeightProfileInfo
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FSkinWeightProfileInfo {
	// Fields
	struct FName Name; // Offset: 0x0 | Size: 0x8
	struct FPerPlatformBool DefaultProfile; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x3]; // Offset: 0x9 | Size: 0x3
	struct FPerPlatformInt DefaultProfileFromLODIndex; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct Engine.TentDistribution
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FTentDistribution {
	// Fields
	float TipAltitude; // Offset: 0x0 | Size: 0x4
	float TipValue; // Offset: 0x4 | Size: 0x4
	float Width; // Offset: 0x8 | Size: 0x4
};

// Object: ScriptStruct Engine.PrecomputedSkyLightInstanceData
// Inherited Bytes: 0xa8 | Struct Size: 0x160
struct FPrecomputedSkyLightInstanceData : FSceneComponentInstanceData {
	// Fields
	struct FGuid LightGuid; // Offset: 0xa8 | Size: 0x10
	float AverageBrightness; // Offset: 0xb8 | Size: 0x4
	char pad_0xBC[0xa4]; // Offset: 0xbc | Size: 0xa4
};

// Object: ScriptStruct Engine.SmartNameContainer
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FSmartNameContainer {
	// Fields
	char pad_0x0[0x50]; // Offset: 0x0 | Size: 0x50
};

// Object: ScriptStruct Engine.SmartNameMapping
// Inherited Bytes: 0x0 | Struct Size: 0x70
struct FSmartNameMapping {
	// Fields
	char pad_0x0[0x70]; // Offset: 0x0 | Size: 0x70
};

// Object: ScriptStruct Engine.CurveMetaData
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FCurveMetaData {
	// Fields
	char pad_0x0[0x20]; // Offset: 0x0 | Size: 0x20
};

// Object: ScriptStruct Engine.SoundAttenuationSettings
// Inherited Bytes: 0xb0 | Struct Size: 0x3a0
struct FSoundAttenuationSettings : FBaseAttenuationSettings {
	// Fields
	char bAttenuate : 1; // Offset: 0xb0 | Size: 0x1
	char bSpatialize : 1; // Offset: 0xb0 | Size: 0x1
	char bAttenuateWithLPF : 1; // Offset: 0xb0 | Size: 0x1
	char bEnableListenerFocus : 1; // Offset: 0xb0 | Size: 0x1
	char bEnableFocusInterpolation : 1; // Offset: 0xb0 | Size: 0x1
	char bEnableOcclusion : 1; // Offset: 0xb0 | Size: 0x1
	char bUseComplexCollisionForOcclusion : 1; // Offset: 0xb0 | Size: 0x1
	char bEnableReverbSend : 1; // Offset: 0xb0 | Size: 0x1
	char bEnablePriorityAttenuation : 1; // Offset: 0xb1 | Size: 0x1
	char bApplyNormalizationToStereoSounds : 1; // Offset: 0xb1 | Size: 0x1
	char bEnableLogFrequencyScaling : 1; // Offset: 0xb1 | Size: 0x1
	char bEnableSubmixSends : 1; // Offset: 0xb1 | Size: 0x1
	char pad_0xB1_4 : 4; // Offset: 0xb1 | Size: 0x1
	enum class ESoundSpatializationAlgorithm SpatializationAlgorithm; // Offset: 0xb2 | Size: 0x1
	char pad_0xB3[0x1]; // Offset: 0xb3 | Size: 0x1
	float BinauralRadius; // Offset: 0xb4 | Size: 0x4
	enum class EAirAbsorptionMethod AbsorptionMethod; // Offset: 0xb8 | Size: 0x1
	enum class ECollisionChannel OcclusionTraceChannel; // Offset: 0xb9 | Size: 0x1
	enum class EReverbSendMethod ReverbSendMethod; // Offset: 0xba | Size: 0x1
	enum class EPriorityAttenuationMethod PriorityAttenuationMethod; // Offset: 0xbb | Size: 0x1
	float OmniRadius; // Offset: 0xbc | Size: 0x4
	float StereoSpread; // Offset: 0xc0 | Size: 0x4
	float LPFRadiusMin; // Offset: 0xc4 | Size: 0x4
	float LPFRadiusMax; // Offset: 0xc8 | Size: 0x4
	char pad_0xCC[0x4]; // Offset: 0xcc | Size: 0x4
	struct FRuntimeFloatCurve CustomLowpassAirAbsorptionCurve; // Offset: 0xd0 | Size: 0x88
	struct FRuntimeFloatCurve CustomHighpassAirAbsorptionCurve; // Offset: 0x158 | Size: 0x88
	float LPFFrequencyAtMin; // Offset: 0x1e0 | Size: 0x4
	float LPFFrequencyAtMax; // Offset: 0x1e4 | Size: 0x4
	float HPFFrequencyAtMin; // Offset: 0x1e8 | Size: 0x4
	float HPFFrequencyAtMax; // Offset: 0x1ec | Size: 0x4
	float FocusAzimuth; // Offset: 0x1f0 | Size: 0x4
	float NonFocusAzimuth; // Offset: 0x1f4 | Size: 0x4
	float FocusDistanceScale; // Offset: 0x1f8 | Size: 0x4
	float NonFocusDistanceScale; // Offset: 0x1fc | Size: 0x4
	float FocusPriorityScale; // Offset: 0x200 | Size: 0x4
	float NonFocusPriorityScale; // Offset: 0x204 | Size: 0x4
	float FocusVolumeAttenuation; // Offset: 0x208 | Size: 0x4
	float NonFocusVolumeAttenuation; // Offset: 0x20c | Size: 0x4
	float FocusAttackInterpSpeed; // Offset: 0x210 | Size: 0x4
	float FocusReleaseInterpSpeed; // Offset: 0x214 | Size: 0x4
	float OcclusionLowPassFilterFrequency; // Offset: 0x218 | Size: 0x4
	float OcclusionVolumeAttenuation; // Offset: 0x21c | Size: 0x4
	float OcclusionInterpolationTime; // Offset: 0x220 | Size: 0x4
	float ReverbWetLevelMin; // Offset: 0x224 | Size: 0x4
	float ReverbWetLevelMax; // Offset: 0x228 | Size: 0x4
	float ReverbDistanceMin; // Offset: 0x22c | Size: 0x4
	float ReverbDistanceMax; // Offset: 0x230 | Size: 0x4
	float ManualReverbSendLevel; // Offset: 0x234 | Size: 0x4
	struct FRuntimeFloatCurve CustomReverbSendCurve; // Offset: 0x238 | Size: 0x88
	struct TArray<struct FAttenuationSubmixSendSettings> SubmixSendSettings; // Offset: 0x2c0 | Size: 0x10
	float PriorityAttenuationMin; // Offset: 0x2d0 | Size: 0x4
	float PriorityAttenuationMax; // Offset: 0x2d4 | Size: 0x4
	float PriorityAttenuationDistanceMin; // Offset: 0x2d8 | Size: 0x4
	float PriorityAttenuationDistanceMax; // Offset: 0x2dc | Size: 0x4
	float ManualPriorityAttenuation; // Offset: 0x2e0 | Size: 0x4
	char pad_0x2E4[0x4]; // Offset: 0x2e4 | Size: 0x4
	struct FRuntimeFloatCurve CustomPriorityAttenuationCurve; // Offset: 0x2e8 | Size: 0x88
	struct FSoundAttenuationPluginSettings PluginSettings; // Offset: 0x370 | Size: 0x30
};

// Object: ScriptStruct Engine.SoundAttenuationPluginSettings
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FSoundAttenuationPluginSettings {
	// Fields
	struct TArray<struct USpatializationPluginSourceSettingsBase*> SpatializationPluginSettingsArray; // Offset: 0x0 | Size: 0x10
	struct TArray<struct UOcclusionPluginSourceSettingsBase*> OcclusionPluginSettingsArray; // Offset: 0x10 | Size: 0x10
	struct TArray<struct UReverbPluginSourceSettingsBase*> ReverbPluginSettingsArray; // Offset: 0x20 | Size: 0x10
};

// Object: ScriptStruct Engine.AttenuationSubmixSendSettings
// Inherited Bytes: 0x0 | Struct Size: 0xa8
struct FAttenuationSubmixSendSettings {
	// Fields
	struct USoundSubmix* Submix; // Offset: 0x0 | Size: 0x8
	enum class ESubmixSendMethod SubmixSendMethod; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x3]; // Offset: 0x9 | Size: 0x3
	float SubmixSendLevelMin; // Offset: 0xc | Size: 0x4
	float SubmixSendLevelMax; // Offset: 0x10 | Size: 0x4
	float SubmixSendDistanceMin; // Offset: 0x14 | Size: 0x4
	float SubmixSendDistanceMax; // Offset: 0x18 | Size: 0x4
	float ManualSubmixSendLevel; // Offset: 0x1c | Size: 0x4
	struct FRuntimeFloatCurve CustomSubmixSendCurve; // Offset: 0x20 | Size: 0x88
};

// Object: ScriptStruct Engine.PassiveSoundMixModifier
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FPassiveSoundMixModifier {
	// Fields
	struct USoundMix* SoundMix; // Offset: 0x0 | Size: 0x8
	float MinVolumeThreshold; // Offset: 0x8 | Size: 0x4
	float MaxVolumeThreshold; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct Engine.SoundClassProperties
// Inherited Bytes: 0x0 | Struct Size: 0x58
struct FSoundClassProperties {
	// Fields
	float Volume; // Offset: 0x0 | Size: 0x4
	float Pitch; // Offset: 0x4 | Size: 0x4
	float LowPassFilterFrequency; // Offset: 0x8 | Size: 0x4
	float AttenuationDistanceScale; // Offset: 0xc | Size: 0x4
	float StereoBleed; // Offset: 0x10 | Size: 0x4
	float LFEBleed; // Offset: 0x14 | Size: 0x4
	float VoiceCenterChannelVolume; // Offset: 0x18 | Size: 0x4
	float RadioFilterVolume; // Offset: 0x1c | Size: 0x4
	float RadioFilterVolumeThreshold; // Offset: 0x20 | Size: 0x4
	char bApplyEffects : 1; // Offset: 0x24 | Size: 0x1
	char bAlwaysPlay : 1; // Offset: 0x24 | Size: 0x1
	char bIsUISound : 1; // Offset: 0x24 | Size: 0x1
	char bIsMusic : 1; // Offset: 0x24 | Size: 0x1
	char bCenterChannelOnly : 1; // Offset: 0x24 | Size: 0x1
	char bApplyAmbientVolumes : 1; // Offset: 0x24 | Size: 0x1
	char bReverb : 1; // Offset: 0x24 | Size: 0x1
	char pad_0x24_7 : 1; // Offset: 0x24 | Size: 0x1
	char pad_0x25[0x3]; // Offset: 0x25 | Size: 0x3
	float Default2DReverbSendAmount; // Offset: 0x28 | Size: 0x4
	enum class EAudioOutputTarget OutputTarget; // Offset: 0x2c | Size: 0x1
	enum class ESoundWaveLoadingBehavior LoadingBehavior; // Offset: 0x2d | Size: 0x1
	char pad_0x2E[0x2]; // Offset: 0x2e | Size: 0x2
	struct USoundSubmix* DefaultSubmix; // Offset: 0x30 | Size: 0x8
	char pad_0x38[0x20]; // Offset: 0x38 | Size: 0x20
};

// Object: ScriptStruct Engine.SoundClassEditorData
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FSoundClassEditorData {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
};

// Object: ScriptStruct Engine.SoundConcurrencySettings
// Inherited Bytes: 0x0 | Struct Size: 0x1c
struct FSoundConcurrencySettings {
	// Fields
	int32_t MaxCount; // Offset: 0x0 | Size: 0x4
	char bLimitToOwner : 1; // Offset: 0x4 | Size: 0x1
	char pad_0x4_1 : 7; // Offset: 0x4 | Size: 0x1
	enum class EMaxConcurrentResolutionRule ResolutionRule; // Offset: 0x5 | Size: 0x1
	char pad_0x6[0x2]; // Offset: 0x6 | Size: 0x2
	float VolumeScale; // Offset: 0x8 | Size: 0x4
	float VolumeScaleAttackTime; // Offset: 0xc | Size: 0x4
	char bVolumeScaleCanRelease : 1; // Offset: 0x10 | Size: 0x1
	char pad_0x10_1 : 7; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x3]; // Offset: 0x11 | Size: 0x3
	float VolumeScaleReleaseTime; // Offset: 0x14 | Size: 0x4
	float VoiceStealReleaseTime; // Offset: 0x18 | Size: 0x4
};

// Object: ScriptStruct Engine.SoundNodeEditorData
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FSoundNodeEditorData {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
};

// Object: ScriptStruct Engine.SourceEffectChainEntry
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FSourceEffectChainEntry {
	// Fields
	struct USoundEffectSourcePreset* Preset; // Offset: 0x0 | Size: 0x8
	char bBypass : 1; // Offset: 0x8 | Size: 0x1
	char pad_0x8_1 : 7; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x7]; // Offset: 0x9 | Size: 0x7
};

// Object: ScriptStruct Engine.SoundGroup
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FSoundGroup {
	// Fields
	enum class ESoundGroup SoundGroup; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x7]; // Offset: 0x1 | Size: 0x7
	struct FString DisplayName; // Offset: 0x8 | Size: 0x10
	char bAlwaysDecompressOnLoad : 1; // Offset: 0x18 | Size: 0x1
	char pad_0x18_1 : 7; // Offset: 0x18 | Size: 0x1
	char pad_0x19[0x3]; // Offset: 0x19 | Size: 0x3
	float DecompressedDuration; // Offset: 0x1c | Size: 0x4
};

// Object: ScriptStruct Engine.SoundClassAdjuster
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FSoundClassAdjuster {
	// Fields
	struct USoundClass* SoundClassObject; // Offset: 0x0 | Size: 0x8
	float VolumeAdjuster; // Offset: 0x8 | Size: 0x4
	float PitchAdjuster; // Offset: 0xc | Size: 0x4
	float LowPassFilterFrequency; // Offset: 0x10 | Size: 0x4
	char bApplyToChildren : 1; // Offset: 0x14 | Size: 0x1
	char pad_0x14_1 : 7; // Offset: 0x14 | Size: 0x1
	char pad_0x15[0x3]; // Offset: 0x15 | Size: 0x3
	float VoiceCenterChannelVolumeAdjuster; // Offset: 0x18 | Size: 0x4
	char pad_0x1C[0x4]; // Offset: 0x1c | Size: 0x4
};

// Object: ScriptStruct Engine.AudioEQEffect
// Inherited Bytes: 0x8 | Struct Size: 0x40
struct FAudioEQEffect : FAudioEffectParameters {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	float FrequencyCenter0; // Offset: 0x10 | Size: 0x4
	float Gain0; // Offset: 0x14 | Size: 0x4
	float Bandwidth0; // Offset: 0x18 | Size: 0x4
	float FrequencyCenter1; // Offset: 0x1c | Size: 0x4
	float Gain1; // Offset: 0x20 | Size: 0x4
	float Bandwidth1; // Offset: 0x24 | Size: 0x4
	float FrequencyCenter2; // Offset: 0x28 | Size: 0x4
	float Gain2; // Offset: 0x2c | Size: 0x4
	float Bandwidth2; // Offset: 0x30 | Size: 0x4
	float FrequencyCenter3; // Offset: 0x34 | Size: 0x4
	float Gain3; // Offset: 0x38 | Size: 0x4
	float Bandwidth3; // Offset: 0x3c | Size: 0x4
};

// Object: ScriptStruct Engine.DistanceDatum
// Inherited Bytes: 0x0 | Struct Size: 0x14
struct FDistanceDatum {
	// Fields
	float FadeInDistanceStart; // Offset: 0x0 | Size: 0x4
	float FadeInDistanceEnd; // Offset: 0x4 | Size: 0x4
	float FadeOutDistanceStart; // Offset: 0x8 | Size: 0x4
	float FadeOutDistanceEnd; // Offset: 0xc | Size: 0x4
	float Volume; // Offset: 0x10 | Size: 0x4
};

// Object: ScriptStruct Engine.ModulatorContinuousParams
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FModulatorContinuousParams {
	// Fields
	struct FName ParameterName; // Offset: 0x0 | Size: 0x8
	float Default; // Offset: 0x8 | Size: 0x4
	float MinInput; // Offset: 0xc | Size: 0x4
	float MaxInput; // Offset: 0x10 | Size: 0x4
	float MinOutput; // Offset: 0x14 | Size: 0x4
	float MaxOutput; // Offset: 0x18 | Size: 0x4
	enum class ModulationParamMode ParamMode; // Offset: 0x1c | Size: 0x1
	char pad_0x1D[0x3]; // Offset: 0x1d | Size: 0x3
};

// Object: ScriptStruct Engine.SoundSourceBusSendInfo
// Inherited Bytes: 0x0 | Struct Size: 0xb0
struct FSoundSourceBusSendInfo {
	// Fields
	enum class ESourceBusSendLevelControlMethod SourceBusSendLevelControlMethod; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x7]; // Offset: 0x1 | Size: 0x7
	struct USoundSourceBus* SoundSourceBus; // Offset: 0x8 | Size: 0x8
	float SendLevel; // Offset: 0x10 | Size: 0x4
	float MinSendLevel; // Offset: 0x14 | Size: 0x4
	float MaxSendLevel; // Offset: 0x18 | Size: 0x4
	float MinSendDistance; // Offset: 0x1c | Size: 0x4
	float MaxSendDistance; // Offset: 0x20 | Size: 0x4
	char pad_0x24[0x4]; // Offset: 0x24 | Size: 0x4
	struct FRuntimeFloatCurve CustomSendLevelCurve; // Offset: 0x28 | Size: 0x88
};

// Object: ScriptStruct Engine.SoundSubmixSendInfo
// Inherited Bytes: 0x0 | Struct Size: 0xb0
struct FSoundSubmixSendInfo {
	// Fields
	enum class ESendLevelControlMethod SendLevelControlMethod; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x7]; // Offset: 0x1 | Size: 0x7
	struct USoundSubmixBase* SoundSubmix; // Offset: 0x8 | Size: 0x8
	float SendLevel; // Offset: 0x10 | Size: 0x4
	float MinSendLevel; // Offset: 0x14 | Size: 0x4
	float MaxSendLevel; // Offset: 0x18 | Size: 0x4
	float MinSendDistance; // Offset: 0x1c | Size: 0x4
	float MaxSendDistance; // Offset: 0x20 | Size: 0x4
	char pad_0x24[0x4]; // Offset: 0x24 | Size: 0x4
	struct FRuntimeFloatCurve CustomSendLevelCurve; // Offset: 0x28 | Size: 0x88
};

// Object: ScriptStruct Engine.SoundWaveEnvelopeTimeData
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FSoundWaveEnvelopeTimeData {
	// Fields
	float Amplitude; // Offset: 0x0 | Size: 0x4
	float TimeSec; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct Engine.SoundWaveSpectralTimeData
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FSoundWaveSpectralTimeData {
	// Fields
	struct TArray<struct FSoundWaveSpectralDataEntry> Data; // Offset: 0x0 | Size: 0x10
	float TimeSec; // Offset: 0x10 | Size: 0x4
	char pad_0x14[0x4]; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct Engine.SoundWaveSpectralDataEntry
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FSoundWaveSpectralDataEntry {
	// Fields
	float Magnitude; // Offset: 0x0 | Size: 0x4
	float NormalizedMagnitude; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct Engine.SoundWaveEnvelopeDataPerSound
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FSoundWaveEnvelopeDataPerSound {
	// Fields
	float Envelope; // Offset: 0x0 | Size: 0x4
	float PlaybackTime; // Offset: 0x4 | Size: 0x4
	struct USoundWave* SoundWave; // Offset: 0x8 | Size: 0x8
};

// Object: ScriptStruct Engine.SoundWaveSpectralDataPerSound
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FSoundWaveSpectralDataPerSound {
	// Fields
	struct TArray<struct FSoundWaveSpectralData> SpectralData; // Offset: 0x0 | Size: 0x10
	float PlaybackTime; // Offset: 0x10 | Size: 0x4
	char pad_0x14[0x4]; // Offset: 0x14 | Size: 0x4
	struct USoundWave* SoundWave; // Offset: 0x18 | Size: 0x8
};

// Object: ScriptStruct Engine.SoundWaveSpectralData
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FSoundWaveSpectralData {
	// Fields
	float FrequencyHz; // Offset: 0x0 | Size: 0x4
	float Magnitude; // Offset: 0x4 | Size: 0x4
	float NormalizedMagnitude; // Offset: 0x8 | Size: 0x4
};

// Object: ScriptStruct Engine.StreamedAudioPlatformData
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FStreamedAudioPlatformData {
	// Fields
	char pad_0x0[0x20]; // Offset: 0x0 | Size: 0x20
};

// Object: ScriptStruct Engine.SplineInstanceData
// Inherited Bytes: 0xa8 | Struct Size: 0x180
struct FSplineInstanceData : FSceneComponentInstanceData {
	// Fields
	bool bSplineHasBeenEdited; // Offset: 0xa8 | Size: 0x1
	char pad_0xA9[0x7]; // Offset: 0xa9 | Size: 0x7
	struct FSplineCurves SplineCurves; // Offset: 0xb0 | Size: 0x68
	struct FSplineCurves SplineCurvesPreUCS; // Offset: 0x118 | Size: 0x68
};

// Object: ScriptStruct Engine.SplineCurves
// Inherited Bytes: 0x0 | Struct Size: 0x68
struct FSplineCurves {
	// Fields
	struct FInterpCurveVector Position; // Offset: 0x0 | Size: 0x18
	struct FInterpCurveQuat Rotation; // Offset: 0x18 | Size: 0x18
	struct FInterpCurveVector Scale; // Offset: 0x30 | Size: 0x18
	struct FInterpCurveFloat ReparamTable; // Offset: 0x48 | Size: 0x18
	struct USplineMetadata* MetaData; // Offset: 0x60 | Size: 0x8
};

// Object: ScriptStruct Engine.SplinePoint
// Inherited Bytes: 0x0 | Struct Size: 0x44
struct FSplinePoint {
	// Fields
	float InputKey; // Offset: 0x0 | Size: 0x4
	struct FVector Position; // Offset: 0x4 | Size: 0xc
	struct FVector ArriveTangent; // Offset: 0x10 | Size: 0xc
	struct FVector LeaveTangent; // Offset: 0x1c | Size: 0xc
	struct FRotator Rotation; // Offset: 0x28 | Size: 0xc
	struct FVector Scale; // Offset: 0x34 | Size: 0xc
	enum class ESplinePointType Type; // Offset: 0x40 | Size: 0x1
	char pad_0x41[0x3]; // Offset: 0x41 | Size: 0x3
};

// Object: ScriptStruct Engine.SplineMeshInstanceData
// Inherited Bytes: 0xa8 | Struct Size: 0xd8
struct FSplineMeshInstanceData : FSceneComponentInstanceData {
	// Fields
	struct FVector StartPos; // Offset: 0xa8 | Size: 0xc
	struct FVector EndPos; // Offset: 0xb4 | Size: 0xc
	struct FVector StartTangent; // Offset: 0xc0 | Size: 0xc
	struct FVector EndTangent; // Offset: 0xcc | Size: 0xc
};

// Object: ScriptStruct Engine.SplineMeshParams
// Inherited Bytes: 0x0 | Struct Size: 0x58
struct FSplineMeshParams {
	// Fields
	struct FVector StartPos; // Offset: 0x0 | Size: 0xc
	struct FVector StartTangent; // Offset: 0xc | Size: 0xc
	struct FVector2D StartScale; // Offset: 0x18 | Size: 0x8
	float StartRoll; // Offset: 0x20 | Size: 0x4
	struct FVector2D StartOffset; // Offset: 0x24 | Size: 0x8
	struct FVector EndPos; // Offset: 0x2c | Size: 0xc
	struct FVector2D EndScale; // Offset: 0x38 | Size: 0x8
	struct FVector EndTangent; // Offset: 0x40 | Size: 0xc
	float EndRoll; // Offset: 0x4c | Size: 0x4
	struct FVector2D EndOffset; // Offset: 0x50 | Size: 0x8
};

// Object: ScriptStruct Engine.LODRange
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FLODRange {
	// Fields
	int32_t MinLOD; // Offset: 0x0 | Size: 0x4
	int32_t MaxLOD; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct Engine.MaterialRemapIndex
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FMaterialRemapIndex {
	// Fields
	uint32_t ImportVersionKey; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct TArray<int32_t> MaterialRemap; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct Engine.StaticMaterial
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FStaticMaterial {
	// Fields
	struct UMaterialInterface* MaterialInterface; // Offset: 0x0 | Size: 0x8
	struct FName MaterialSlotName; // Offset: 0x8 | Size: 0x8
	struct FName ImportedMaterialSlotName; // Offset: 0x10 | Size: 0x8
	struct FMeshUVChannelInfo UVChannelData; // Offset: 0x18 | Size: 0x14
	char pad_0x2C[0x4]; // Offset: 0x2c | Size: 0x4
};

// Object: ScriptStruct Engine.AssetEditorOrbitCameraPosition
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FAssetEditorOrbitCameraPosition {
	// Fields
	bool bIsSet; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	struct FVector CamOrbitPoint; // Offset: 0x4 | Size: 0xc
	struct FVector CamOrbitZoom; // Offset: 0x10 | Size: 0xc
	struct FRotator CamOrbitRotation; // Offset: 0x1c | Size: 0xc
};

// Object: ScriptStruct Engine.MeshSectionInfoMap
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FMeshSectionInfoMap {
	// Fields
	struct TMap<uint32_t, struct FMeshSectionInfo> Map; // Offset: 0x0 | Size: 0x50
};

// Object: ScriptStruct Engine.MeshSectionInfo
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FMeshSectionInfo {
	// Fields
	int32_t MaterialIndex; // Offset: 0x0 | Size: 0x4
	bool bEnableCollision; // Offset: 0x4 | Size: 0x1
	bool bCastShadow; // Offset: 0x5 | Size: 0x1
	bool bForceOpaque; // Offset: 0x6 | Size: 0x1
	char pad_0x7[0x1]; // Offset: 0x7 | Size: 0x1
};

// Object: ScriptStruct Engine.StaticMeshSourceModel
// Inherited Bytes: 0x0 | Struct Size: 0x70
struct FStaticMeshSourceModel {
	// Fields
	struct FMeshBuildSettings BuildSettings; // Offset: 0x0 | Size: 0x30
	struct FMeshReductionSettings ReductionSettings; // Offset: 0x30 | Size: 0x24
	float LODDistance; // Offset: 0x54 | Size: 0x4
	struct FPerPlatformFloat ScreenSize; // Offset: 0x58 | Size: 0x4
	char pad_0x5C[0x4]; // Offset: 0x5c | Size: 0x4
	struct FString SourceImportFilename; // Offset: 0x60 | Size: 0x10
};

// Object: ScriptStruct Engine.StaticMeshOptimizationSettings
// Inherited Bytes: 0x0 | Struct Size: 0x1c
struct FStaticMeshOptimizationSettings {
	// Fields
	enum class EOptimizationType ReductionMethod; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	float NumOfTrianglesPercentage; // Offset: 0x4 | Size: 0x4
	float MaxDeviationPercentage; // Offset: 0x8 | Size: 0x4
	float WeldingThreshold; // Offset: 0xc | Size: 0x4
	bool bRecalcNormals; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x3]; // Offset: 0x11 | Size: 0x3
	float NormalsThreshold; // Offset: 0x14 | Size: 0x4
	char SilhouetteImportance; // Offset: 0x18 | Size: 0x1
	char TextureImportance; // Offset: 0x19 | Size: 0x1
	char ShadingImportance; // Offset: 0x1a | Size: 0x1
	char pad_0x1B[0x1]; // Offset: 0x1b | Size: 0x1
};

// Object: ScriptStruct Engine.StaticMeshComponentInstanceData
// Inherited Bytes: 0xf0 | Struct Size: 0x130
struct FStaticMeshComponentInstanceData : FPrimitiveComponentInstanceData {
	// Fields
	struct UStaticMesh* StaticMesh; // Offset: 0xf0 | Size: 0x8
	struct TArray<struct FStaticMeshVertexColorLODData> VertexColorLODs; // Offset: 0xf8 | Size: 0x10
	struct TArray<struct FGuid> CachedStaticLighting; // Offset: 0x108 | Size: 0x10
	struct TArray<struct FStreamingTextureBuildInfo> StreamingTextureData; // Offset: 0x118 | Size: 0x10
	char pad_0x128[0x8]; // Offset: 0x128 | Size: 0x8
};

// Object: ScriptStruct Engine.StreamingTextureBuildInfo
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FStreamingTextureBuildInfo {
	// Fields
	uint32_t PackedRelativeBox; // Offset: 0x0 | Size: 0x4
	int32_t TextureLevelIndex; // Offset: 0x4 | Size: 0x4
	float TexelFactor; // Offset: 0x8 | Size: 0x4
};

// Object: ScriptStruct Engine.StaticMeshVertexColorLODData
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FStaticMeshVertexColorLODData {
	// Fields
	struct TArray<struct FPaintedVertex> PaintedVertices; // Offset: 0x0 | Size: 0x10
	struct TArray<struct FColor> VertexBufferColors; // Offset: 0x10 | Size: 0x10
	uint32_t LODIndex; // Offset: 0x20 | Size: 0x4
	char pad_0x24[0x4]; // Offset: 0x24 | Size: 0x4
};

// Object: ScriptStruct Engine.PaintedVertex
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FPaintedVertex {
	// Fields
	struct FVector Position; // Offset: 0x0 | Size: 0xc
	struct FColor Color; // Offset: 0xc | Size: 0x4
	struct FVector4 Normal; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct Engine.StaticMeshComponentLODInfo
// Inherited Bytes: 0x0 | Struct Size: 0x90
struct FStaticMeshComponentLODInfo {
	// Fields
	char pad_0x0[0x90]; // Offset: 0x0 | Size: 0x90
};

// Object: ScriptStruct Engine.StaticParameterSet
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FStaticParameterSet {
	// Fields
	struct TArray<struct FStaticSwitchParameter> StaticSwitchParameters; // Offset: 0x0 | Size: 0x10
	struct TArray<struct FStaticComponentMaskParameter> StaticComponentMaskParameters; // Offset: 0x10 | Size: 0x10
	struct TArray<struct FStaticTerrainLayerWeightParameter> TerrainLayerWeightParameters; // Offset: 0x20 | Size: 0x10
	struct TArray<struct FStaticMaterialLayersParameter> MaterialLayersParameters; // Offset: 0x30 | Size: 0x10
};

// Object: ScriptStruct Engine.StaticParameterBase
// Inherited Bytes: 0x0 | Struct Size: 0x24
struct FStaticParameterBase {
	// Fields
	struct FMaterialParameterInfo ParameterInfo; // Offset: 0x0 | Size: 0x10
	bool bOverride; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x3]; // Offset: 0x11 | Size: 0x3
	struct FGuid ExpressionGUID; // Offset: 0x14 | Size: 0x10
};

// Object: ScriptStruct Engine.StaticMaterialLayersParameter
// Inherited Bytes: 0x24 | Struct Size: 0x68
struct FStaticMaterialLayersParameter : FStaticParameterBase {
	// Fields
	char pad_0x24[0x4]; // Offset: 0x24 | Size: 0x4
	struct FMaterialLayersFunctions Value; // Offset: 0x28 | Size: 0x40
};

// Object: ScriptStruct Engine.StaticTerrainLayerWeightParameter
// Inherited Bytes: 0x24 | Struct Size: 0x2c
struct FStaticTerrainLayerWeightParameter : FStaticParameterBase {
	// Fields
	int32_t WeightmapIndex; // Offset: 0x24 | Size: 0x4
	bool bWeightBasedBlend; // Offset: 0x28 | Size: 0x1
	char pad_0x29[0x3]; // Offset: 0x29 | Size: 0x3
};

// Object: ScriptStruct Engine.StaticComponentMaskParameter
// Inherited Bytes: 0x24 | Struct Size: 0x28
struct FStaticComponentMaskParameter : FStaticParameterBase {
	// Fields
	bool R; // Offset: 0x24 | Size: 0x1
	bool G; // Offset: 0x25 | Size: 0x1
	bool B; // Offset: 0x26 | Size: 0x1
	bool A; // Offset: 0x27 | Size: 0x1
};

// Object: ScriptStruct Engine.StaticSwitchParameter
// Inherited Bytes: 0x24 | Struct Size: 0x28
struct FStaticSwitchParameter : FStaticParameterBase {
	// Fields
	bool Value; // Offset: 0x24 | Size: 0x1
	char pad_0x25[0x3]; // Offset: 0x25 | Size: 0x3
};

// Object: ScriptStruct Engine.EquirectProps
// Inherited Bytes: 0x0 | Struct Size: 0x48
struct FEquirectProps {
	// Fields
	struct FBox2D LeftUVRect; // Offset: 0x0 | Size: 0x14
	struct FBox2D RightUVRect; // Offset: 0x14 | Size: 0x14
	struct FVector2D LeftScale; // Offset: 0x28 | Size: 0x8
	struct FVector2D RightScale; // Offset: 0x30 | Size: 0x8
	struct FVector2D LeftBias; // Offset: 0x38 | Size: 0x8
	struct FVector2D RightBias; // Offset: 0x40 | Size: 0x8
};

// Object: ScriptStruct Engine.StringCurve
// Inherited Bytes: 0x68 | Struct Size: 0x88
struct FStringCurve : FIndexedCurve {
	// Fields
	struct FString DefaultValue; // Offset: 0x68 | Size: 0x10
	struct TArray<struct FStringCurveKey> Keys; // Offset: 0x78 | Size: 0x10
};

// Object: ScriptStruct Engine.StringCurveKey
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FStringCurveKey {
	// Fields
	float Time; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct FString Value; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct Engine.SubsurfaceProfileStruct
// Inherited Bytes: 0x0 | Struct Size: 0x8c
struct FSubsurfaceProfileStruct {
	// Fields
	struct FLinearColor SurfaceAlbedo; // Offset: 0x0 | Size: 0x10
	struct FLinearColor MeanFreePathColor; // Offset: 0x10 | Size: 0x10
	float MeanFreePathDistance; // Offset: 0x20 | Size: 0x4
	float WorldUnitScale; // Offset: 0x24 | Size: 0x4
	bool bEnableBurley; // Offset: 0x28 | Size: 0x1
	char pad_0x29[0x3]; // Offset: 0x29 | Size: 0x3
	float ScatterRadius; // Offset: 0x2c | Size: 0x4
	struct FLinearColor SubsurfaceColor; // Offset: 0x30 | Size: 0x10
	struct FLinearColor FalloffColor; // Offset: 0x40 | Size: 0x10
	struct FLinearColor BoundaryColorBleed; // Offset: 0x50 | Size: 0x10
	float ExtinctionScale; // Offset: 0x60 | Size: 0x4
	float NormalScale; // Offset: 0x64 | Size: 0x4
	float ScatteringDistribution; // Offset: 0x68 | Size: 0x4
	float IOR; // Offset: 0x6c | Size: 0x4
	float Roughness0; // Offset: 0x70 | Size: 0x4
	float Roughness1; // Offset: 0x74 | Size: 0x4
	float LobeMix; // Offset: 0x78 | Size: 0x4
	struct FLinearColor TransmissionTintColor; // Offset: 0x7c | Size: 0x10
};

// Object: ScriptStruct Engine.TextureFormatSettings
// Inherited Bytes: 0x0 | Struct Size: 0x2
struct FTextureFormatSettings {
	// Fields
	enum class TextureCompressionSettings CompressionSettings; // Offset: 0x0 | Size: 0x1
	char CompressionNoAlpha : 1; // Offset: 0x1 | Size: 0x1
	char CompressionNone : 1; // Offset: 0x1 | Size: 0x1
	char CompressionYCoCg : 1; // Offset: 0x1 | Size: 0x1
	char SRGB : 1; // Offset: 0x1 | Size: 0x1
	char pad_0x1_4 : 4; // Offset: 0x1 | Size: 0x1
};

// Object: ScriptStruct Engine.TexturePlatformData
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FTexturePlatformData {
	// Fields
	char pad_0x0[0x30]; // Offset: 0x0 | Size: 0x30
};

// Object: ScriptStruct Engine.TextureSource
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FTextureSource {
	// Fields
	char pad_0x0[0x30]; // Offset: 0x0 | Size: 0x30
};

// Object: ScriptStruct Engine.TextureSourceBlock
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FTextureSourceBlock {
	// Fields
	int32_t BlockX; // Offset: 0x0 | Size: 0x4
	int32_t BlockY; // Offset: 0x4 | Size: 0x4
	int32_t SizeX; // Offset: 0x8 | Size: 0x4
	int32_t SizeY; // Offset: 0xc | Size: 0x4
	int32_t NumSlices; // Offset: 0x10 | Size: 0x4
	int32_t NumMips; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct Engine.TextureLODGroup
// Inherited Bytes: 0x0 | Struct Size: 0x64
struct FTextureLODGroup {
	// Fields
	enum class TextureGroup Group; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0xb]; // Offset: 0x1 | Size: 0xb
	int32_t LODBias; // Offset: 0xc | Size: 0x4
	int32_t LODBias_Smaller; // Offset: 0x10 | Size: 0x4
	int32_t LODBias_Smallest; // Offset: 0x14 | Size: 0x4
	int32_t LODBias_Runtime; // Offset: 0x18 | Size: 0x4
	int32_t LODBias_GraphicsMemory; // Offset: 0x1c | Size: 0x4
	int32_t LODBias_SmallerGraphicsMemory; // Offset: 0x20 | Size: 0x4
	int32_t LODBias_SmallestGraphicsMemory; // Offset: 0x24 | Size: 0x4
	char pad_0x28[0x4]; // Offset: 0x28 | Size: 0x4
	int32_t NumStreamedMips; // Offset: 0x2c | Size: 0x4
	enum class TextureMipGenSettings MipGenSettings; // Offset: 0x30 | Size: 0x1
	char pad_0x31[0x3]; // Offset: 0x31 | Size: 0x3
	int32_t MinLODSize; // Offset: 0x34 | Size: 0x4
	int32_t MaxLODSize; // Offset: 0x38 | Size: 0x4
	int32_t MaxLODSize_Smaller; // Offset: 0x3c | Size: 0x4
	int32_t MaxLODSize_Smallest; // Offset: 0x40 | Size: 0x4
	int32_t OptionalLODBias; // Offset: 0x44 | Size: 0x4
	int32_t OptionalMaxLODSize; // Offset: 0x48 | Size: 0x4
	char pad_0x4C[0x4]; // Offset: 0x4c | Size: 0x4
	struct FName MinMagFilter; // Offset: 0x50 | Size: 0x8
	struct FName MipFilter; // Offset: 0x58 | Size: 0x8
	enum class ETextureMipLoadOptions MipLoadOptions; // Offset: 0x60 | Size: 0x1
	bool DuplicateNonOptionalMips; // Offset: 0x61 | Size: 0x1
	char pad_0x62[0x2]; // Offset: 0x62 | Size: 0x2
};

// Object: ScriptStruct Engine.StreamingRenderAssetPrimitiveInfo
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FStreamingRenderAssetPrimitiveInfo {
	// Fields
	struct UStreamableRenderAsset* RenderAsset; // Offset: 0x0 | Size: 0x8
	struct FBoxSphereBounds Bounds; // Offset: 0x8 | Size: 0x1c
	float TexelFactor; // Offset: 0x24 | Size: 0x4
	uint32_t PackedRelativeBox; // Offset: 0x28 | Size: 0x4
	char bAllowInvalidTexelFactorWhenUnregistered : 1; // Offset: 0x2c | Size: 0x1
	char pad_0x2C_1 : 7; // Offset: 0x2c | Size: 0x1
	char pad_0x2D[0x3]; // Offset: 0x2d | Size: 0x3
};

// Object: ScriptStruct Engine.TTTrackBase
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FTTTrackBase {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
	struct FName TrackName; // Offset: 0x8 | Size: 0x8
	bool bIsExternalCurve; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x7]; // Offset: 0x11 | Size: 0x7
};

// Object: ScriptStruct Engine.TTPropertyTrack
// Inherited Bytes: 0x18 | Struct Size: 0x20
struct FTTPropertyTrack : FTTTrackBase {
	// Fields
	struct FName PropertyName; // Offset: 0x14 | Size: 0x8
};

// Object: ScriptStruct Engine.TTLinearColorTrack
// Inherited Bytes: 0x20 | Struct Size: 0x28
struct FTTLinearColorTrack : FTTPropertyTrack {
	// Fields
	struct UCurveLinearColor* CurveLinearColor; // Offset: 0x20 | Size: 0x8
};

// Object: ScriptStruct Engine.TTVectorTrack
// Inherited Bytes: 0x20 | Struct Size: 0x28
struct FTTVectorTrack : FTTPropertyTrack {
	// Fields
	struct UCurveVector* CurveVector; // Offset: 0x20 | Size: 0x8
};

// Object: ScriptStruct Engine.TTFloatTrack
// Inherited Bytes: 0x20 | Struct Size: 0x28
struct FTTFloatTrack : FTTPropertyTrack {
	// Fields
	struct UCurveFloat* CurveFloat; // Offset: 0x20 | Size: 0x8
};

// Object: ScriptStruct Engine.TTEventTrack
// Inherited Bytes: 0x18 | Struct Size: 0x28
struct FTTEventTrack : FTTTrackBase {
	// Fields
	struct FName FunctionName; // Offset: 0x14 | Size: 0x8
	struct UCurveFloat* CurveKeys; // Offset: 0x20 | Size: 0x8
};

// Object: ScriptStruct Engine.TimeStretchCurveInstance
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FTimeStretchCurveInstance {
	// Fields
	bool bHasValidData; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x2f]; // Offset: 0x1 | Size: 0x2f
};

// Object: ScriptStruct Engine.TimeStretchCurve
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FTimeStretchCurve {
	// Fields
	float SamplingRate; // Offset: 0x0 | Size: 0x4
	float CurveValueMinPrecision; // Offset: 0x4 | Size: 0x4
	struct TArray<struct FTimeStretchCurveMarker> Markers; // Offset: 0x8 | Size: 0x10
	float Sum_dT_i_by_C_i[0x3]; // Offset: 0x18 | Size: 0xc
	char pad_0x24[0x4]; // Offset: 0x24 | Size: 0x4
};

// Object: ScriptStruct Engine.TimeStretchCurveMarker
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FTimeStretchCurveMarker {
	// Fields
	float Time[0x3]; // Offset: 0x0 | Size: 0xc
	float Alpha; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct Engine.TouchInputControl
// Inherited Bytes: 0x0 | Struct Size: 0x68
struct FTouchInputControl {
	// Fields
	struct UTexture2D* Image1; // Offset: 0x0 | Size: 0x8
	struct UTexture2D* Image2; // Offset: 0x8 | Size: 0x8
	struct FVector2D Center; // Offset: 0x10 | Size: 0x8
	struct FVector2D VisualSize; // Offset: 0x18 | Size: 0x8
	struct FVector2D ThumbSize; // Offset: 0x20 | Size: 0x8
	struct FVector2D InteractionSize; // Offset: 0x28 | Size: 0x8
	struct FVector2D InputScale; // Offset: 0x30 | Size: 0x8
	struct FKey MainInputKey; // Offset: 0x38 | Size: 0x18
	struct FKey AltInputKey; // Offset: 0x50 | Size: 0x18
};

// Object: ScriptStruct Engine.HardwareCursorReference
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FHardwareCursorReference {
	// Fields
	struct FName CursorPath; // Offset: 0x0 | Size: 0x8
	struct FVector2D HotSpot; // Offset: 0x8 | Size: 0x8
};

// Object: ScriptStruct Engine.GlobalColorThemeData
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FGlobalColorThemeData {
	// Fields
	struct FString Desc; // Offset: 0x0 | Size: 0x10
	struct FString Tag; // Offset: 0x10 | Size: 0x10
	struct TArray<struct FLinearColor> Colors; // Offset: 0x20 | Size: 0x10
};

// Object: ScriptStruct Engine.VirtualTextureBuildSettings
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FVirtualTextureBuildSettings {
	// Fields
	int32_t TileSize; // Offset: 0x0 | Size: 0x4
	int32_t TileBorderSize; // Offset: 0x4 | Size: 0x4
	bool bEnableCompressCrunch; // Offset: 0x8 | Size: 0x1
	bool bEnableCompressZlib; // Offset: 0x9 | Size: 0x1
	char pad_0xA[0x2]; // Offset: 0xa | Size: 0x2
};

// Object: ScriptStruct Engine.VirtualTextureSpacePoolConfig
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FVirtualTextureSpacePoolConfig {
	// Fields
	int32_t MinTileSize; // Offset: 0x0 | Size: 0x4
	int32_t MaxTileSize; // Offset: 0x4 | Size: 0x4
	struct TArray<enum class EPixelFormat> Formats; // Offset: 0x8 | Size: 0x10
	int32_t SizeInMegabyte; // Offset: 0x18 | Size: 0x4
	bool bAllowSizeScale; // Offset: 0x1c | Size: 0x1
	char pad_0x1D[0x3]; // Offset: 0x1d | Size: 0x3
};

// Object: ScriptStruct Engine.VoiceSettings
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FVoiceSettings {
	// Fields
	struct USceneComponent* ComponentToAttachTo; // Offset: 0x0 | Size: 0x8
	struct USoundAttenuation* AttenuationSettings; // Offset: 0x8 | Size: 0x8
	struct USoundEffectSourcePresetChain* SourceEffectChain; // Offset: 0x10 | Size: 0x8
};

// Object: ScriptStruct Engine.StreamingLevelsToConsider
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FStreamingLevelsToConsider {
	// Fields
	struct TArray<struct FLevelStreamingWrapper> StreamingLevels; // Offset: 0x0 | Size: 0x10
	char pad_0x10[0x18]; // Offset: 0x10 | Size: 0x18
};

// Object: ScriptStruct Engine.LevelStreamingWrapper
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FLevelStreamingWrapper {
	// Fields
	struct ULevelStreaming* StreamingLevel; // Offset: 0x0 | Size: 0x8
};

// Object: ScriptStruct Engine.LevelCollection
// Inherited Bytes: 0x0 | Struct Size: 0x78
struct FLevelCollection {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
	struct AGameStateBase* GameState; // Offset: 0x8 | Size: 0x8
	struct UNetDriver* NetDriver; // Offset: 0x10 | Size: 0x8
	struct UDemoNetDriver* DemoNetDriver; // Offset: 0x18 | Size: 0x8
	struct ULevel* PersistentLevel; // Offset: 0x20 | Size: 0x8
	struct TSet<struct ULevel*> Levels; // Offset: 0x28 | Size: 0x50
};

// Object: ScriptStruct Engine.EndPhysicsTickFunction
// Inherited Bytes: 0x28 | Struct Size: 0x30
struct FEndPhysicsTickFunction : FTickFunction {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
};

// Object: ScriptStruct Engine.StartPhysicsTickFunction
// Inherited Bytes: 0x28 | Struct Size: 0x30
struct FStartPhysicsTickFunction : FTickFunction {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
};

// Object: ScriptStruct Engine.LevelViewportInfo
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FLevelViewportInfo {
	// Fields
	struct FVector CamPosition; // Offset: 0x0 | Size: 0xc
	struct FRotator CamRotation; // Offset: 0xc | Size: 0xc
	float CamOrthoZoom; // Offset: 0x18 | Size: 0x4
	bool CamUpdated; // Offset: 0x1c | Size: 0x1
	char pad_0x1D[0x3]; // Offset: 0x1d | Size: 0x3
};

// Object: ScriptStruct Engine.WorldPSCPool
// Inherited Bytes: 0x0 | Struct Size: 0x58
struct FWorldPSCPool {
	// Fields
	struct TMap<struct UParticleSystem*, struct FPSCPool> WorldParticleSystemPools; // Offset: 0x0 | Size: 0x50
	char pad_0x50[0x8]; // Offset: 0x50 | Size: 0x8
};

// Object: ScriptStruct Engine.PSCPool
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FPSCPool {
	// Fields
	struct TArray<struct FPSCPoolElem> FreeElements; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct Engine.PSCPoolElem
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FPSCPoolElem {
	// Fields
	struct UParticleSystemComponent* PSC; // Offset: 0x0 | Size: 0x8
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
};

// Object: ScriptStruct Engine.BroadphaseSettings
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FBroadphaseSettings {
	// Fields
	bool bUseMBPOnClient; // Offset: 0x0 | Size: 0x1
	bool bUseMBPOnServer; // Offset: 0x1 | Size: 0x1
	bool bUseMBPOuterBounds; // Offset: 0x2 | Size: 0x1
	char pad_0x3[0x1]; // Offset: 0x3 | Size: 0x1
	struct FBox MBPBounds; // Offset: 0x4 | Size: 0x1c
	struct FBox MBPOuterBounds; // Offset: 0x20 | Size: 0x1c
	uint32_t MBPNumSubdivs; // Offset: 0x3c | Size: 0x4
};

// Object: ScriptStruct Engine.HierarchicalSimplification
// Inherited Bytes: 0x0 | Struct Size: 0x168
struct FHierarchicalSimplification {
	// Fields
	float TransitionScreenSize; // Offset: 0x0 | Size: 0x4
	float OverrideDrawDistance; // Offset: 0x4 | Size: 0x4
	char bUseOverrideDrawDistance : 1; // Offset: 0x8 | Size: 0x1
	char bAllowSpecificExclusion : 1; // Offset: 0x8 | Size: 0x1
	char bSimplifyMesh : 1; // Offset: 0x8 | Size: 0x1
	char bOnlyGenerateClustersForVolumes : 1; // Offset: 0x8 | Size: 0x1
	char bReusePreviousLevelClusters : 1; // Offset: 0x8 | Size: 0x1
	char pad_0x8_5 : 3; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x3]; // Offset: 0x9 | Size: 0x3
	struct FMeshProxySettings ProxySetting; // Offset: 0xc | Size: 0xa8
	struct FMeshMergingSettings MergeSetting; // Offset: 0xb4 | Size: 0xa8
	float DesiredBoundRadius; // Offset: 0x15c | Size: 0x4
	float DesiredFillingPercentage; // Offset: 0x160 | Size: 0x4
	int32_t MinNumberOfActorsToBuild; // Offset: 0x164 | Size: 0x4
};

// Object: ScriptStruct Engine.NetViewer
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FNetViewer {
	// Fields
	struct UNetConnection* Connection; // Offset: 0x0 | Size: 0x8
	struct AActor* InViewer; // Offset: 0x8 | Size: 0x8
	struct AActor* ViewTarget; // Offset: 0x10 | Size: 0x8
	struct FVector ViewLocation; // Offset: 0x18 | Size: 0xc
	struct FVector ViewDir; // Offset: 0x24 | Size: 0xc
};

// Object: ScriptStruct Engine.LightmassWorldInfoSettings
// Inherited Bytes: 0x0 | Struct Size: 0x4c
struct FLightmassWorldInfoSettings {
	// Fields
	float StaticLightingLevelScale; // Offset: 0x0 | Size: 0x4
	int32_t NumIndirectLightingBounces; // Offset: 0x4 | Size: 0x4
	int32_t NumSkyLightingBounces; // Offset: 0x8 | Size: 0x4
	float IndirectLightingQuality; // Offset: 0xc | Size: 0x4
	float IndirectLightingSmoothness; // Offset: 0x10 | Size: 0x4
	struct FColor EnvironmentColor; // Offset: 0x14 | Size: 0x4
	float EnvironmentIntensity; // Offset: 0x18 | Size: 0x4
	float EmissiveBoost; // Offset: 0x1c | Size: 0x4
	float DiffuseBoost; // Offset: 0x20 | Size: 0x4
	enum class EVolumeLightingMethod VolumeLightingMethod; // Offset: 0x24 | Size: 0x1
	char bUseAmbientOcclusion : 1; // Offset: 0x25 | Size: 0x1
	char bGenerateAmbientOcclusionMaterialMask : 1; // Offset: 0x25 | Size: 0x1
	char bVisualizeMaterialDiffuse : 1; // Offset: 0x25 | Size: 0x1
	char bVisualizeAmbientOcclusion : 1; // Offset: 0x25 | Size: 0x1
	char bCompressLightmaps : 1; // Offset: 0x25 | Size: 0x1
	char pad_0x25_5 : 3; // Offset: 0x25 | Size: 0x1
	char pad_0x26[0x2]; // Offset: 0x26 | Size: 0x2
	float VolumetricLightmapDetailCellSize; // Offset: 0x28 | Size: 0x4
	float VolumetricLightmapMaximumBrickMemoryMb; // Offset: 0x2c | Size: 0x4
	float VolumetricLightmapSphericalHarmonicSmoothing; // Offset: 0x30 | Size: 0x4
	float VolumeLightSamplePlacementScale; // Offset: 0x34 | Size: 0x4
	float DirectIlluminationOcclusionFraction; // Offset: 0x38 | Size: 0x4
	float IndirectIlluminationOcclusionFraction; // Offset: 0x3c | Size: 0x4
	float OcclusionExponent; // Offset: 0x40 | Size: 0x4
	float FullyOccludedSamplesFraction; // Offset: 0x44 | Size: 0x4
	float MaxOcclusionDistance; // Offset: 0x48 | Size: 0x4
};

