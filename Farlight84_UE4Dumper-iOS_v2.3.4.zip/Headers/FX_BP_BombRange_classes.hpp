#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass FX_BP_BombRange.FX_BP_BombRange_C
// Inherited Bytes: 0x290 | Struct Size: 0x2b0
struct AFX_BP_BombRange_C : ASolarBombActor {
	// Fields
	struct UStaticMeshComponent* FX_Cylinder_Range_High; // Offset: 0x290 | Size: 0x8
	struct UStaticMeshComponent* FX_Ring_Range_Low; // Offset: 0x298 | Size: 0x8
	struct UStaticMeshComponent* FX_GuideLine; // Offset: 0x2a0 | Size: 0x8
	struct USceneComponent* PositionAdjiust; // Offset: 0x2a8 | Size: 0x8
};

