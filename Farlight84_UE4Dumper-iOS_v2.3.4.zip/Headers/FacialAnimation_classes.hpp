#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class FacialAnimation.AudioCurveSourceComponent
// Inherited Bytes: 0x940 | Struct Size: 0x980
struct UAudioCurveSourceComponent : UAudioComponent {
	// Fields
	struct FName CurveSourceBindingName; // Offset: 0x940 | Size: 0x8
	float CurveSyncOffset; // Offset: 0x948 | Size: 0x4
	char pad_0x94C[0x34]; // Offset: 0x94c | Size: 0x34
};

