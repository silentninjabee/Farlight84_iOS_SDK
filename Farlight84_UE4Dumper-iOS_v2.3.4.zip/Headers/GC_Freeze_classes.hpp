#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass GC_Freeze.GC_Freeze_C
// Inherited Bytes: 0x370 | Struct Size: 0x440
struct AGC_Freeze_C : ASolarSkillGC_Freeze {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x370 | Size: 0x8
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x378 | Size: 0x8
	struct FMaterialChangeHandle MaterialChangeHandle; // Offset: 0x380 | Size: 0x8
	struct TMap<int32_t, struct FString> SoundPlayMap; // Offset: 0x388 | Size: 0x50
	struct TMap<int32_t, struct FString> SoundStopMap; // Offset: 0x3d8 | Size: 0x50
	struct UParticleSystemComponent* ParticleHandle; // Offset: 0x428 | Size: 0x8
	struct FString PlayingAudioEventName; // Offset: 0x430 | Size: 0x10

	// Functions

	// Object: Function GC_Freeze.GC_Freeze_C.RemoveFunc
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x8) ]
	void RemoveFunc(struct AActor* Actor);

	// Object: Function GC_Freeze.GC_Freeze_C.ActiveFunc
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x8) ]
	void ActiveFunc(struct AActor* TartgetActor);

	// Object: Function GC_Freeze.GC_Freeze_C.Is Teammate
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(3) Size(0x11) ]
	void Is Teammate(struct ASolarCharacter* Actor1, struct AActor* Actor2, bool& IsTeammate);

	// Object: Function GC_Freeze.GC_Freeze_C.PlaySoundEvent
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(2) Size(0x9) ]
	void PlaySoundEvent(struct AActor* TargetActor, bool bPlay);

	// Object: Function GC_Freeze.GC_Freeze_C.ReceiveBeginPlay
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void ReceiveBeginPlay();

	// Object: Function GC_Freeze.GC_Freeze_C.ReceiveEndPlay
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x1) ]
	void ReceiveEndPlay(enum class EEndPlayReason EndPlayReason);

	// Object: Function GC_Freeze.GC_Freeze_C.ExecuteUbergraph_GC_Freeze
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_GC_Freeze(int32_t EntryPoint);
};

