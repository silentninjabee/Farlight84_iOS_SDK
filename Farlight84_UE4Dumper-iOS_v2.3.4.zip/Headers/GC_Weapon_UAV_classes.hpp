#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass GC_Weapon_UAV.GC_Weapon_UAV_C
// Inherited Bytes: 0x50 | Struct Size: 0x58
struct UGC_Weapon_UAV_C : UGameplayCueNotify_Static {
	// Fields
	struct UParticleSystem* ParticleEffect; // Offset: 0x50 | Size: 0x8

	// Functions

	// Object: Function GC_Weapon_UAV.GC_Weapon_UAV_C.OnActive
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(3) Size(0xd9) ]
	bool OnActive(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters);
};

