#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct GameplayTasks.GameplayResourceSet
// Inherited Bytes: 0x0 | Struct Size: 0x2
struct FGameplayResourceSet {
	// Fields
	char pad_0x0[0x2]; // Offset: 0x0 | Size: 0x2
};

