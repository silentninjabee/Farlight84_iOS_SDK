#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass HUD_StripBulletContainer_New.HUD_StripBulletContainer_New_C
// Inherited Bytes: 0x520 | Struct Size: 0x520
struct UHUD_StripBulletContainer_New_C : UGridBulletContainerNew {
};

