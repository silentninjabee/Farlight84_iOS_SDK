#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass ImageTween.ImageTween_C
// Inherited Bytes: 0x3d0 | Struct Size: 0x3d0
struct UImageTween_C : UTweenImage {
};

