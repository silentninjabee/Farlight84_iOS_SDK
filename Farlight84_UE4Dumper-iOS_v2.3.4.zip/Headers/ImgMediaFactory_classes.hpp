#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class ImgMediaFactory.ImgMediaSettings
// Inherited Bytes: 0x28 | Struct Size: 0x68
struct UImgMediaSettings : UObject {
	// Fields
	struct FFrameRate DefaultFrameRate; // Offset: 0x28 | Size: 0x8
	float CacheBehindPercentage; // Offset: 0x30 | Size: 0x4
	float CacheSizeGB; // Offset: 0x34 | Size: 0x4
	int32_t CacheThreads; // Offset: 0x38 | Size: 0x4
	int32_t CacheThreadStackSizeKB; // Offset: 0x3c | Size: 0x4
	float GlobalCacheSizeGB; // Offset: 0x40 | Size: 0x4
	bool UseGlobalCache; // Offset: 0x44 | Size: 0x1
	char pad_0x45[0x3]; // Offset: 0x45 | Size: 0x3
	uint32_t ExrDecoderThreads; // Offset: 0x48 | Size: 0x4
	char pad_0x4C[0x4]; // Offset: 0x4c | Size: 0x4
	struct FString DefaultProxy; // Offset: 0x50 | Size: 0x10
	bool UseDefaultProxy; // Offset: 0x60 | Size: 0x1
	char pad_0x61[0x7]; // Offset: 0x61 | Size: 0x7
};

