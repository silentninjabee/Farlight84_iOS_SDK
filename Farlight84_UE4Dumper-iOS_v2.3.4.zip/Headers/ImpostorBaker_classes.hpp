#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class ImpostorBaker.KismetImpostorBakerLibrary
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UKismetImpostorBakerLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object: Function ImpostorBaker.KismetImpostorBakerLibrary.ConvertProceduralToStatic
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101f21c94
	// Return & Params: [ Num(4) Size(0x28) ]
	struct UStaticMesh* ConvertProceduralToStatic(struct UProceduralMeshComponent* ProceduralMeshComponent, struct FName MeshName, struct FString MeshPath);
};

