#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass IncludeWaterNavQueryFilter_LongRange.IncludeWaterNavQueryFilter_LongRange_C
// Inherited Bytes: 0x48 | Struct Size: 0x48
struct UIncludeWaterNavQueryFilter_LongRange_C : USolarNavQueryFilter {
};

