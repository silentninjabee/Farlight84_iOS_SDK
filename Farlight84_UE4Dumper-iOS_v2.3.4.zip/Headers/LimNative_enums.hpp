#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Enum LimNative.ELimNativeConvType
enum class ELimNativeConvType : uint8_t {
	Group = 0,
	Peer = 1,
	Room = 2,
	CustomGroup = 3,
	Robot = 4,
	System = 5,
	TempGroup = 6,
	ELimNativeConvType_MAX = 7
};

// Object: Enum LimNative.ELimNativeMsgDirType
enum class ELimNativeMsgDirType : uint8_t {
	After = 0,
	Around = 1,
	Before = 2,
	ELimNativeMsgDirType_MAX = 3
};

// Object: Enum LimNative.ELimNativeSupportedLanguage
enum class ELimNativeSupportedLanguage : uint8_t {
	DefaultLanguage = 0,
	SimplifiedChinese = 1,
	TraditionalChinese = 2,
	Arabic = 3,
	German = 4,
	English = 5,
	Spanish = 6,
	French = 7,
	Hindi = 8,
	Indonesian = 9,
	Italian = 10,
	Japanese = 11,
	Korean = 12,
	Malay = 13,
	Polish = 14,
	Portuguese = 15,
	Russian = 16,
	Thai = 17,
	Turkish = 18,
	Vietnamese = 19,
	Tagalog = 20,
	PO = 21,
	OP = 22,
	ELimNativeSupportedLanguage_MAX = 23
};

// Object: Enum LimNative.ELimNativeErrorType
enum class ELimNativeErrorType : uint8_t {
	OK = 0,
	ApiNotFound = 1,
	ParameterInvalid = 2,
	NetworkError = 3,
	InitializeError = 4,
	ResourceNotFound = 5,
	ApiTimeout = 6,
	LoginFailed = 7,
	MsgSendFailed = 8,
	MsgSendTimeout = 9,
	MsgBuildFailed = 10,
	MsgSetStateFailed = 11,
	ConvsGetFailed = 12,
	ConvDiscardFailed = 13,
	UnImplemented = 14,
	Exception = 15,
	UserInfoGetFailed = 16,
	JsonDecodeFailed = 17,
	Unknown = 18,
	ELimNativeErrorType_MAX = 19
};

// Object: Enum LimNative.ELimNativeMsgContentType
enum class ELimNativeMsgContentType : uint8_t {
	Unknown = 0,
	Text = 1,
	Voice = 2,
	Image = 3,
	Notification = 4,
	ShareGameCard = 5,
	CustomEmotion = 6,
	Recalled = 7,
	ELimNativeMsgContentType_MAX = 8
};

// Object: Enum LimNative.ELimNativeFriendStateType
enum class ELimNativeFriendStateType : uint8_t {
	InIdle = 0,
	InTeam = 1,
	InMatching = 2,
	InGaming = 3,
	Offline = 4,
	ELimNativeFriendStateType_MAX = 5
};

// Object: Enum LimNative.ELimNativeUserSexType
enum class ELimNativeUserSexType : uint8_t {
	Unknow = 0,
	Male = 1,
	FeMale = 2,
	ELimNativeUserSexType_MAX = 3
};

// Object: Enum LimNative.ELimNativeMsgState
enum class ELimNativeMsgState : uint8_t {
	Created = 0,
	Sending = 1,
	Sent = 2,
	Failed = 3,
	Unread = 4,
	Read = 5,
	ReadAll = 6,
	Played = 7,
	Revoked = 8,
	ELimNativeMsgState_MAX = 9
};

// Object: Enum LimNative.ELimNativePackType
enum class ELimNativePackType : uint8_t {
	StaticPicture = 0,
	DynamicPicture = 1,
	ELimNativePackType_MAX = 2
};

// Object: Enum LimNative.ELimNativeOSType
enum class ELimNativeOSType : uint8_t {
	Android = 0,
	iOS = 1,
	Windows = 2,
	ELimNativeOSType_MAX = 3
};

// Object: Enum LimNative.ELimNativeUserPeerStatus
enum class ELimNativeUserPeerStatus : uint8_t {
	Online = 0,
	Blocking = 1,
	Blocked = 2,
	ELimNativeUserPeerStatus_MAX = 3
};

// Object: Enum LimNative.ELimNativeUserAllowType
enum class ELimNativeUserAllowType : uint8_t {
	Any = 0,
	Confirm = 1,
	None = 2,
	ELimNativeUserAllowType_MAX = 3
};

// Object: Enum LimNative.ELimNativeProtType
enum class ELimNativeProtType : uint8_t {
	Game = 0,
	App = 1,
	ELimNativeProtType_MAX = 2
};

// Object: Enum LimNative.ELimNativeGroupRoleType
enum class ELimNativeGroupRoleType : uint8_t {
	Owner = 0,
	Admin = 1,
	Member = 2,
	ELimNativeGroupRoleType_MAX = 3
};

// Object: Enum LimNative.ELimNativeGroupJoinType
enum class ELimNativeGroupJoinType : uint8_t {
	Free = 0,
	Verify = 1,
	Forbidden = 2,
	ELimNativeGroupJoinType_MAX = 3
};

// Object: Enum LimNative.ELimNativeGroupType
enum class ELimNativeGroupType : uint8_t {
	Normal = 0,
	Temp = 1,
	Room = 2,
	Custom = 3,
	ELimNativeGroupType_MAX = 4
};

// Object: Enum LimNative.ELimNativeEventType
enum class ELimNativeEventType : uint8_t {
	SDKReady = 0,
	SDKError = 1,
	NetDisconnected = 2,
	NetConnecting = 3,
	NetConnected = 4,
	NetReconnected = 5,
	NetReconnecting = 6,
	NetInterrupt = 7,
	TokenRenewed = 8,
	TokenExpired = 9,
	KickedOut = 10,
	LoginFreqLimit = 11,
	Logining = 12,
	Logined = 13,
	MsgReceived = 14,
	MsgRevoked = 15,
	MsgRead = 16,
	MsgEdited = 17,
	MsgLogicReceived = 18,
	MsgCaptTriggerred = 19,
	MsgCaptDispose = 20,
	ConvsUpdated = 21,
	FriendChanged = 22,
	FriendRequestChanged = 23,
	BlockeeChanged = 24,
	BadgesChanged = 25,
	UnkownEvent = 26,
	ELimNativeEventType_MAX = 27
};

// Object: Enum LimNative.ELimNativeConvMentionType
enum class ELimNativeConvMentionType : uint8_t {
	AtMe = 0,
	AtAll = 1,
	AtAllMe = 2,
	ELimNativeConvMentionType_MAX = 3
};

