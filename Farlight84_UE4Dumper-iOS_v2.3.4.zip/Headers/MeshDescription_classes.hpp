#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class MeshDescription.MeshDescription
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UMeshDescription : UObject {
};

// Object: Class MeshDescription.MeshDescriptionBase
// Inherited Bytes: 0x28 | Struct Size: 0x390
struct UMeshDescriptionBase : UObject {
	// Fields
	char pad_0x28[0x368]; // Offset: 0x28 | Size: 0x368

	// Functions

	// Object: Function MeshDescription.MeshDescriptionBase.SetVertexPosition
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x104ef7010
	// Return & Params: [ Num(2) Size(0x10) ]
	void SetVertexPosition(struct FVertexID VertexID, struct FVector& Position);

	// Object: Function MeshDescription.MeshDescriptionBase.SetPolygonVertexInstance
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ef535c
	// Return & Params: [ Num(3) Size(0xc) ]
	void SetPolygonVertexInstance(struct FPolygonID PolygonID, int32_t PerimeterIndex, struct FVertexInstanceID VertexInstanceID);

	// Object: Function MeshDescription.MeshDescriptionBase.SetPolygonPolygonGroup
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ef5274
	// Return & Params: [ Num(2) Size(0x8) ]
	void SetPolygonPolygonGroup(struct FPolygonID PolygonID, struct FPolygonGroupID PolygonGroupID);

	// Object: Function MeshDescription.MeshDescriptionBase.ReversePolygonFacing
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ef51e8
	// Return & Params: [ Num(1) Size(0x4) ]
	void ReversePolygonFacing(struct FPolygonID PolygonID);

	// Object: Function MeshDescription.MeshDescriptionBase.ReserveNewVertices
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ef91f0
	// Return & Params: [ Num(1) Size(0x4) ]
	void ReserveNewVertices(int32_t NumberOfNewVertices);

	// Object: Function MeshDescription.MeshDescriptionBase.ReserveNewVertexInstances
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ef8f88
	// Return & Params: [ Num(1) Size(0x4) ]
	void ReserveNewVertexInstances(int32_t NumberOfNewVertexInstances);

	// Object: Function MeshDescription.MeshDescriptionBase.ReserveNewTriangles
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ef87c0
	// Return & Params: [ Num(1) Size(0x4) ]
	void ReserveNewTriangles(int32_t NumberOfNewTriangles);

	// Object: Function MeshDescription.MeshDescriptionBase.ReserveNewPolygons
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ef81f0
	// Return & Params: [ Num(1) Size(0x4) ]
	void ReserveNewPolygons(int32_t NumberOfNewPolygons);

	// Object: Function MeshDescription.MeshDescriptionBase.ReserveNewPolygonGroups
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ef7c20
	// Return & Params: [ Num(1) Size(0x4) ]
	void ReserveNewPolygonGroups(int32_t NumberOfNewPolygonGroups);

	// Object: Function MeshDescription.MeshDescriptionBase.ReserveNewEdges
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ef8bf8
	// Return & Params: [ Num(1) Size(0x4) ]
	void ReserveNewEdges(int32_t NumberOfNewEdges);

	// Object: Function MeshDescription.MeshDescriptionBase.IsVertexValid
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ef9008
	// Return & Params: [ Num(2) Size(0x5) ]
	bool IsVertexValid(struct FVertexID VertexID);

	// Object: Function MeshDescription.MeshDescriptionBase.IsVertexOrphaned
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ef799c
	// Return & Params: [ Num(2) Size(0x5) ]
	bool IsVertexOrphaned(struct FVertexID VertexID);

	// Object: Function MeshDescription.MeshDescriptionBase.IsVertexInstanceValid
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ef8c78
	// Return & Params: [ Num(2) Size(0x5) ]
	bool IsVertexInstanceValid(struct FVertexInstanceID VertexInstanceID);

	// Object: Function MeshDescription.MeshDescriptionBase.IsTriangleValid
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ef8270
	// Return & Params: [ Num(2) Size(0x5) ]
	bool IsTriangleValid(struct FTriangleID TriangleID);

	// Object: Function MeshDescription.MeshDescriptionBase.IsTrianglePartOfNgon
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ef6320
	// Return & Params: [ Num(2) Size(0x5) ]
	bool IsTrianglePartOfNgon(struct FTriangleID TriangleID);

	// Object: Function MeshDescription.MeshDescriptionBase.IsPolygonValid
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ef7ca0
	// Return & Params: [ Num(2) Size(0x5) ]
	bool IsPolygonValid(struct FPolygonID PolygonID);

	// Object: Function MeshDescription.MeshDescriptionBase.IsPolygonGroupValid
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ef7a38
	// Return & Params: [ Num(2) Size(0x5) ]
	bool IsPolygonGroupValid(struct FPolygonGroupID PolygonGroupID);

	// Object: Function MeshDescription.MeshDescriptionBase.IsEmpty
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ef9270
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsEmpty();

	// Object: Function MeshDescription.MeshDescriptionBase.IsEdgeValid
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ef8840
	// Return & Params: [ Num(2) Size(0x5) ]
	bool IsEdgeValid(struct FEdgeID EdgeID);

	// Object: Function MeshDescription.MeshDescriptionBase.IsEdgeInternalToPolygon
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ef69e0
	// Return & Params: [ Num(3) Size(0x9) ]
	bool IsEdgeInternalToPolygon(struct FEdgeID EdgeID, struct FPolygonID PolygonID);

	// Object: Function MeshDescription.MeshDescriptionBase.IsEdgeInternal
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ef6ad0
	// Return & Params: [ Num(2) Size(0x5) ]
	bool IsEdgeInternal(struct FEdgeID EdgeID);

	// Object: Function MeshDescription.MeshDescriptionBase.GetVertexVertexInstances
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ef7630
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetVertexVertexInstances(struct FVertexID VertexID, struct TArray<struct FVertexInstanceID>& OutVertexInstanceIDs);

	// Object: Function MeshDescription.MeshDescriptionBase.GetVertexPosition
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ef70ec
	// Return & Params: [ Num(2) Size(0x10) ]
	struct FVector GetVertexPosition(struct FVertexID VertexID);

	// Object: Function MeshDescription.MeshDescriptionBase.GetVertexPairEdge
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ef78ac
	// Return & Params: [ Num(3) Size(0xc) ]
	struct FEdgeID GetVertexPairEdge(struct FVertexID VertexID0, struct FVertexID VertexID1);

	// Object: Function MeshDescription.MeshDescriptionBase.GetVertexInstanceVertex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ef6f74
	// Return & Params: [ Num(2) Size(0x8) ]
	struct FVertexID GetVertexInstanceVertex(struct FVertexInstanceID VertexInstanceID);

	// Object: Function MeshDescription.MeshDescriptionBase.GetVertexInstancePairEdge
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ef6e84
	// Return & Params: [ Num(3) Size(0xc) ]
	struct FEdgeID GetVertexInstancePairEdge(struct FVertexInstanceID VertexInstanceID0, struct FVertexInstanceID VertexInstanceID1);

	// Object: Function MeshDescription.MeshDescriptionBase.GetVertexInstanceForTriangleVertex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ef5d8c
	// Return & Params: [ Num(3) Size(0xc) ]
	struct FVertexInstanceID GetVertexInstanceForTriangleVertex(struct FTriangleID TriangleID, struct FVertexID VertexID);

	// Object: Function MeshDescription.MeshDescriptionBase.GetVertexInstanceForPolygonVertex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ef548c
	// Return & Params: [ Num(3) Size(0xc) ]
	struct FVertexInstanceID GetVertexInstanceForPolygonVertex(struct FPolygonID PolygonID, struct FVertexID VertexID);

	// Object: Function MeshDescription.MeshDescriptionBase.GetVertexInstanceConnectedTriangles
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ef6d94
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetVertexInstanceConnectedTriangles(struct FVertexInstanceID VertexInstanceID, struct TArray<struct FTriangleID>& OutConnectedTriangleIDs);

	// Object: Function MeshDescription.MeshDescriptionBase.GetVertexInstanceConnectedPolygons
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ef6c08
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetVertexInstanceConnectedPolygons(struct FVertexInstanceID VertexInstanceID, struct TArray<struct FPolygonID>& OutConnectedPolygonIDs);

	// Object: Function MeshDescription.MeshDescriptionBase.GetVertexConnectedTriangles
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ef74a4
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetVertexConnectedTriangles(struct FVertexID VertexID, struct TArray<struct FTriangleID>& OutConnectedTriangleIDs);

	// Object: Function MeshDescription.MeshDescriptionBase.GetVertexConnectedPolygons
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ef7318
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetVertexConnectedPolygons(struct FVertexID VertexID, struct TArray<struct FPolygonID>& OutConnectedPolygonIDs);

	// Object: Function MeshDescription.MeshDescriptionBase.GetVertexConnectedEdges
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ef77bc
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetVertexConnectedEdges(struct FVertexID VertexID, struct TArray<struct FEdgeID>& OutEdgeIDs);

	// Object: Function MeshDescription.MeshDescriptionBase.GetVertexAdjacentVertices
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ef718c
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetVertexAdjacentVertices(struct FVertexID VertexID, struct TArray<struct FVertexID>& OutAdjacentVertexIDs);

	// Object: Function MeshDescription.MeshDescriptionBase.GetTriangleVertices
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ef605c
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetTriangleVertices(struct FTriangleID TriangleID, struct TArray<struct FVertexID>& OutVertexIDs);

	// Object: Function MeshDescription.MeshDescriptionBase.GetTriangleVertexInstances
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ef6230
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetTriangleVertexInstances(struct FTriangleID TriangleID, struct TArray<struct FVertexInstanceID>& OutVertexInstanceIDs);

	// Object: Function MeshDescription.MeshDescriptionBase.GetTriangleVertexInstance
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ef614c
	// Return & Params: [ Num(3) Size(0xc) ]
	struct FVertexInstanceID GetTriangleVertexInstance(struct FTriangleID TriangleID, int32_t Index);

	// Object: Function MeshDescription.MeshDescriptionBase.GetTrianglePolygonGroup
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ef63bc
	// Return & Params: [ Num(2) Size(0x8) ]
	struct FPolygonGroupID GetTrianglePolygonGroup(struct FTriangleID TriangleID);

	// Object: Function MeshDescription.MeshDescriptionBase.GetTrianglePolygon
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ef6458
	// Return & Params: [ Num(2) Size(0x8) ]
	struct FPolygonID GetTrianglePolygon(struct FTriangleID TriangleID);

	// Object: Function MeshDescription.MeshDescriptionBase.GetTriangleEdges
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ef5f6c
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetTriangleEdges(struct FTriangleID TriangleID, struct TArray<struct FEdgeID>& OutEdgeIDs);

	// Object: Function MeshDescription.MeshDescriptionBase.GetTriangleAdjacentTriangles
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ef5e7c
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetTriangleAdjacentTriangles(struct FTriangleID TriangleID, struct TArray<struct FTriangleID>& OutTriangleIDs);

	// Object: Function MeshDescription.MeshDescriptionBase.GetPolygonVertices
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ef5984
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetPolygonVertices(struct FPolygonID PolygonID, struct TArray<struct FVertexID>& OutVertexIDs);

	// Object: Function MeshDescription.MeshDescriptionBase.GetPolygonVertexInstances
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ef5b10
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetPolygonVertexInstances(struct FPolygonID PolygonID, struct TArray<struct FVertexInstanceID>& OutVertexInstanceIDs);

	// Object: Function MeshDescription.MeshDescriptionBase.GetPolygonTriangles
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ef5c9c
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetPolygonTriangles(struct FPolygonID PolygonID, struct TArray<struct FTriangleID>& OutTriangleIDs);

	// Object: Function MeshDescription.MeshDescriptionBase.GetPolygonPolygonGroup
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ef557c
	// Return & Params: [ Num(2) Size(0x8) ]
	struct FPolygonGroupID GetPolygonPolygonGroup(struct FPolygonID PolygonID);

	// Object: Function MeshDescription.MeshDescriptionBase.GetPolygonPerimeterEdges
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ef5894
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetPolygonPerimeterEdges(struct FPolygonID PolygonID, struct TArray<struct FEdgeID>& OutEdgeIDs);

	// Object: Function MeshDescription.MeshDescriptionBase.GetPolygonInternalEdges
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ef57a4
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetPolygonInternalEdges(struct FPolygonID PolygonID, struct TArray<struct FEdgeID>& OutEdgeIDs);

	// Object: Function MeshDescription.MeshDescriptionBase.GetPolygonGroupPolygons
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ef506c
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetPolygonGroupPolygons(struct FPolygonGroupID PolygonGroupID, struct TArray<struct FPolygonID>& OutPolygonIDs);

	// Object: Function MeshDescription.MeshDescriptionBase.GetPolygonAdjacentPolygons
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ef5618
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetPolygonAdjacentPolygons(struct FPolygonID PolygonID, struct TArray<struct FPolygonID>& OutPolygonIDs);

	// Object: Function MeshDescription.MeshDescriptionBase.GetNumVertexVertexInstances
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ef7594
	// Return & Params: [ Num(2) Size(0x8) ]
	int32_t GetNumVertexVertexInstances(struct FVertexID VertexID);

	// Object: Function MeshDescription.MeshDescriptionBase.GetNumVertexInstanceConnectedTriangles
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ef6cf8
	// Return & Params: [ Num(2) Size(0x8) ]
	int32_t GetNumVertexInstanceConnectedTriangles(struct FVertexInstanceID VertexInstanceID);

	// Object: Function MeshDescription.MeshDescriptionBase.GetNumVertexInstanceConnectedPolygons
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ef6b6c
	// Return & Params: [ Num(2) Size(0x8) ]
	int32_t GetNumVertexInstanceConnectedPolygons(struct FVertexInstanceID VertexInstanceID);

	// Object: Function MeshDescription.MeshDescriptionBase.GetNumVertexConnectedTriangles
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ef7408
	// Return & Params: [ Num(2) Size(0x8) ]
	int32_t GetNumVertexConnectedTriangles(struct FVertexID VertexID);

	// Object: Function MeshDescription.MeshDescriptionBase.GetNumVertexConnectedPolygons
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ef727c
	// Return & Params: [ Num(2) Size(0x8) ]
	int32_t GetNumVertexConnectedPolygons(struct FVertexID VertexID);

	// Object: Function MeshDescription.MeshDescriptionBase.GetNumVertexConnectedEdges
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ef7720
	// Return & Params: [ Num(2) Size(0x8) ]
	int32_t GetNumVertexConnectedEdges(struct FVertexID VertexID);

	// Object: Function MeshDescription.MeshDescriptionBase.GetNumPolygonVertices
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ef5a74
	// Return & Params: [ Num(2) Size(0x8) ]
	int32_t GetNumPolygonVertices(struct FPolygonID PolygonID);

	// Object: Function MeshDescription.MeshDescriptionBase.GetNumPolygonTriangles
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ef5c00
	// Return & Params: [ Num(2) Size(0x8) ]
	int32_t GetNumPolygonTriangles(struct FPolygonID PolygonID);

	// Object: Function MeshDescription.MeshDescriptionBase.GetNumPolygonInternalEdges
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ef5708
	// Return & Params: [ Num(2) Size(0x8) ]
	int32_t GetNumPolygonInternalEdges(struct FPolygonID PolygonID);

	// Object: Function MeshDescription.MeshDescriptionBase.GetNumPolygonGroupPolygons
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ef4fd0
	// Return & Params: [ Num(2) Size(0x8) ]
	int32_t GetNumPolygonGroupPolygons(struct FPolygonGroupID PolygonGroupID);

	// Object: Function MeshDescription.MeshDescriptionBase.GetNumEdgeConnectedTriangles
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ef6854
	// Return & Params: [ Num(2) Size(0x8) ]
	int32_t GetNumEdgeConnectedTriangles(struct FEdgeID EdgeID);

	// Object: Function MeshDescription.MeshDescriptionBase.GetNumEdgeConnectedPolygons
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ef66c8
	// Return & Params: [ Num(2) Size(0x8) ]
	int32_t GetNumEdgeConnectedPolygons(struct FEdgeID EdgeID);

	// Object: Function MeshDescription.MeshDescriptionBase.GetEdgeVertices
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ef64f4
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetEdgeVertices(struct FEdgeID EdgeID, struct TArray<struct FVertexID>& OutVertexIDs);

	// Object: Function MeshDescription.MeshDescriptionBase.GetEdgeVertex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ef65e4
	// Return & Params: [ Num(3) Size(0xc) ]
	struct FVertexID GetEdgeVertex(struct FEdgeID EdgeID, int32_t VertexNumber);

	// Object: Function MeshDescription.MeshDescriptionBase.GetEdgeConnectedTriangles
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ef68f0
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetEdgeConnectedTriangles(struct FEdgeID EdgeID, struct TArray<struct FTriangleID>& OutConnectedTriangleIDs);

	// Object: Function MeshDescription.MeshDescriptionBase.GetEdgeConnectedPolygons
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ef6764
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetEdgeConnectedPolygons(struct FEdgeID EdgeID, struct TArray<struct FPolygonID>& OutConnectedPolygonIDs);

	// Object: Function MeshDescription.MeshDescriptionBase.Empty
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ef92a4
	// Return & Params: [ Num(0) Size(0x0) ]
	void Empty();

	// Object: Function MeshDescription.MeshDescriptionBase.DeleteVertexInstance
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104ef8d14
	// Return & Params: [ Num(2) Size(0x18) ]
	void DeleteVertexInstance(struct FVertexInstanceID VertexInstanceID, struct TArray<struct FVertexID>& OrphanedVertices);

	// Object: Function MeshDescription.MeshDescriptionBase.DeleteVertex
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ef90a4
	// Return & Params: [ Num(1) Size(0x4) ]
	void DeleteVertex(struct FVertexID VertexID);

	// Object: Function MeshDescription.MeshDescriptionBase.DeleteTriangle
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104ef830c
	// Return & Params: [ Num(4) Size(0x38) ]
	void DeleteTriangle(struct FTriangleID TriangleID, struct TArray<struct FEdgeID>& OrphanedEdges, struct TArray<struct FVertexInstanceID>& OrphanedVertexInstances, struct TArray<struct FPolygonGroupID>& OrphanedPolygonGroupsPtr);

	// Object: Function MeshDescription.MeshDescriptionBase.DeletePolygonGroup
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ef7ad4
	// Return & Params: [ Num(1) Size(0x4) ]
	void DeletePolygonGroup(struct FPolygonGroupID PolygonGroupID);

	// Object: Function MeshDescription.MeshDescriptionBase.DeletePolygon
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104ef7d3c
	// Return & Params: [ Num(4) Size(0x38) ]
	void DeletePolygon(struct FPolygonID PolygonID, struct TArray<struct FEdgeID>& OrphanedEdges, struct TArray<struct FVertexInstanceID>& OrphanedVertexInstances, struct TArray<struct FPolygonGroupID>& OrphanedPolygonGroups);

	// Object: Function MeshDescription.MeshDescriptionBase.DeleteEdge
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104ef88dc
	// Return & Params: [ Num(2) Size(0x18) ]
	void DeleteEdge(struct FEdgeID EdgeID, struct TArray<struct FVertexID>& OrphanedVertices);

	// Object: Function MeshDescription.MeshDescriptionBase.CreateVertexWithID
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ef9130
	// Return & Params: [ Num(1) Size(0x4) ]
	void CreateVertexWithID(struct FVertexID VertexID);

	// Object: Function MeshDescription.MeshDescriptionBase.CreateVertexInstanceWithID
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ef8e04
	// Return & Params: [ Num(2) Size(0x8) ]
	void CreateVertexInstanceWithID(struct FVertexInstanceID VertexInstanceID, struct FVertexID VertexID);

	// Object: Function MeshDescription.MeshDescriptionBase.CreateVertexInstance
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ef8eec
	// Return & Params: [ Num(2) Size(0x8) ]
	struct FVertexInstanceID CreateVertexInstance(struct FVertexID VertexID);

	// Object: Function MeshDescription.MeshDescriptionBase.CreateVertex
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ef91bc
	// Return & Params: [ Num(1) Size(0x4) ]
	struct FVertexID CreateVertex();

	// Object: Function MeshDescription.MeshDescriptionBase.CreateTriangleWithID
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104ef84bc
	// Return & Params: [ Num(4) Size(0x28) ]
	void CreateTriangleWithID(struct FTriangleID TriangleID, struct FPolygonGroupID PolygonGroupID, struct TArray<struct FVertexInstanceID>& VertexInstanceIDs, struct TArray<struct FEdgeID>& NewEdgeIDs);

	// Object: Function MeshDescription.MeshDescriptionBase.CreateTriangle
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104ef8664
	// Return & Params: [ Num(4) Size(0x2c) ]
	struct FTriangleID CreateTriangle(struct FPolygonGroupID PolygonGroupID, struct TArray<struct FVertexInstanceID>& VertexInstanceIDs, struct TArray<struct FEdgeID>& NewEdgeIDs);

	// Object: Function MeshDescription.MeshDescriptionBase.CreatePolygonWithID
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104ef7eec
	// Return & Params: [ Num(4) Size(0x28) ]
	void CreatePolygonWithID(struct FPolygonID PolygonID, struct FPolygonGroupID PolygonGroupID, struct TArray<struct FVertexInstanceID>& VertexInstanceIDs, struct TArray<struct FEdgeID>& NewEdgeIDs);

	// Object: Function MeshDescription.MeshDescriptionBase.CreatePolygonGroupWithID
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ef7b60
	// Return & Params: [ Num(1) Size(0x4) ]
	void CreatePolygonGroupWithID(struct FPolygonGroupID PolygonGroupID);

	// Object: Function MeshDescription.MeshDescriptionBase.CreatePolygonGroup
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ef7bec
	// Return & Params: [ Num(1) Size(0x4) ]
	struct FPolygonGroupID CreatePolygonGroup();

	// Object: Function MeshDescription.MeshDescriptionBase.CreatePolygon
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104ef8094
	// Return & Params: [ Num(4) Size(0x2c) ]
	struct FPolygonID CreatePolygon(struct FPolygonGroupID PolygonGroupID, struct TArray<struct FVertexInstanceID>& VertexInstanceIDs, struct TArray<struct FEdgeID>& NewEdgeIDs);

	// Object: Function MeshDescription.MeshDescriptionBase.CreateEdgeWithID
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ef89cc
	// Return & Params: [ Num(3) Size(0xc) ]
	void CreateEdgeWithID(struct FEdgeID EdgeID, struct FVertexID VertexID0, struct FVertexID VertexID1);

	// Object: Function MeshDescription.MeshDescriptionBase.CreateEdge
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ef8b08
	// Return & Params: [ Num(3) Size(0xc) ]
	struct FEdgeID CreateEdge(struct FVertexID VertexID0, struct FVertexID VertexID1);

	// Object: Function MeshDescription.MeshDescriptionBase.ComputePolygonTriangulation
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ef515c
	// Return & Params: [ Num(1) Size(0x4) ]
	void ComputePolygonTriangulation(struct FPolygonID PolygonID);
};

