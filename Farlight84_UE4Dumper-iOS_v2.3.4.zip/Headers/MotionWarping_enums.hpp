#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Enum MotionWarping.EWarpPointAnimProvider
enum class EWarpPointAnimProvider : uint8_t {
	None = 0,
	Static = 1,
	Bone = 2,
	EWarpPointAnimProvider_MAX = 3
};

// Object: Enum MotionWarping.EMotionWarpRotationType
enum class EMotionWarpRotationType : uint8_t {
	Default = 0,
	Facing = 1,
	EMotionWarpRotationType_MAX = 2
};

// Object: Enum MotionWarping.ERootMotionModifierState
enum class ERootMotionModifierState : uint8_t {
	Waiting = 0,
	Active = 1,
	MarkedForRemoval = 2,
	Disabled = 3,
	ERootMotionModifierState_MAX = 4
};

