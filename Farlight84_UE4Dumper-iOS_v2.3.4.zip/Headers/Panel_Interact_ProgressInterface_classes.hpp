#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass Panel_Interact_ProgressInterface.Panel_Interact_ProgressInterface_C
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UPanel_Interact_ProgressInterface_C : UInterface {
	// Functions

	// Object: Function Panel_Interact_ProgressInterface.Panel_Interact_ProgressInterface_C.DoGetTagToInteractType
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x50) ]
	void DoGetTagToInteractType(struct TMap<struct FGameplayTag, enum class E_Interact_Type>& NewParam);

	// Object: Function Panel_Interact_ProgressInterface.Panel_Interact_ProgressInterface_C.DoEnablePassiveBuffDisplay
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(2) Size(0x8) ]
	void DoEnablePassiveBuffDisplay(int32_t CharacterId, int32_t LocalTextId);

	// Object: Function Panel_Interact_ProgressInterface.Panel_Interact_ProgressInterface_C.DoGetInteractType
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x1) ]
	void DoGetInteractType(enum class E_Interact_Type& NewParam);

	// Object: Function Panel_Interact_ProgressInterface.Panel_Interact_ProgressInterface_C.DoSetInteractType
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x1) ]
	void DoSetInteractType(enum class E_Interact_Type InteractType);

	// Object: Function Panel_Interact_ProgressInterface.Panel_Interact_ProgressInterface_C.DoPlayFadeInAnim
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void DoPlayFadeInAnim();
};

