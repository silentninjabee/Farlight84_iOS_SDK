#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: DynamicClass R_Weapon_Psm05_Set00_LOD0_Skeleton_AnimBlueprint.R_Weapon_Psm05_Set00_LOD0_Skeleton_AnimBlueprint_C
// Inherited Bytes: 0x300 | Struct Size: 0x390
struct UR_Weapon_Psm05_Set00_LOD0_Skeleton_AnimBlueprint_C : UWeaponAnimInstance {
	// Fields
	struct FAnimNode_Root AnimGraphNode_Root; // Offset: 0x300 | Size: 0x30
	struct FAnimNode_RefPose AnimGraphNode_LocalRefPose; // Offset: 0x330 | Size: 0x18
	struct FAnimNode_Slot AnimGraphNode_Slot; // Offset: 0x348 | Size: 0x48

	// Functions

	// Object: Function R_Weapon_Psm05_Set00_LOD0_Skeleton_AnimBlueprint.R_Weapon_Psm05_Set00_LOD0_Skeleton_AnimBlueprint_C.ExecuteUbergraph_R_Weapon_Psm05_Set00_LOD0_Skeleton_AnimBlueprint
	// Flags: [Final|Native|Public]
	// Offset: 0x101cb4574
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_R_Weapon_Psm05_Set00_LOD0_Skeleton_AnimBlueprint(int32_t bpp__EntryPoint__pf);

	// Object: Function R_Weapon_Psm05_Set00_LOD0_Skeleton_AnimBlueprint.R_Weapon_Psm05_Set00_LOD0_Skeleton_AnimBlueprint_C.AnimGraph
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101cb44d4
	// Return & Params: [ Num(1) Size(0x10) ]
	void AnimGraph(struct FPoseLink& bpp__AnimGraph__pf);
};

