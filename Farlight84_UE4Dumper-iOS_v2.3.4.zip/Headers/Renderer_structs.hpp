#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct Renderer.LightPropagationVolumeSettings
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FLightPropagationVolumeSettings {
	// Fields
	char bOverride_LPVIntensity : 1; // Offset: 0x0 | Size: 0x1
	char bOverride_LPVDirectionalOcclusionIntensity : 1; // Offset: 0x0 | Size: 0x1
	char bOverride_LPVDirectionalOcclusionRadius : 1; // Offset: 0x0 | Size: 0x1
	char bOverride_LPVDiffuseOcclusionExponent : 1; // Offset: 0x0 | Size: 0x1
	char bOverride_LPVSpecularOcclusionExponent : 1; // Offset: 0x0 | Size: 0x1
	char bOverride_LPVDiffuseOcclusionIntensity : 1; // Offset: 0x0 | Size: 0x1
	char bOverride_LPVSpecularOcclusionIntensity : 1; // Offset: 0x0 | Size: 0x1
	char bOverride_LPVSize : 1; // Offset: 0x0 | Size: 0x1
	char bOverride_LPVSecondaryOcclusionIntensity : 1; // Offset: 0x1 | Size: 0x1
	char bOverride_LPVSecondaryBounceIntensity : 1; // Offset: 0x1 | Size: 0x1
	char bOverride_LPVGeometryVolumeBias : 1; // Offset: 0x1 | Size: 0x1
	char bOverride_LPVVplInjectionBias : 1; // Offset: 0x1 | Size: 0x1
	char bOverride_LPVEmissiveInjectionIntensity : 1; // Offset: 0x1 | Size: 0x1
	char pad_0x1_5 : 3; // Offset: 0x1 | Size: 0x1
	char pad_0x2[0x2]; // Offset: 0x2 | Size: 0x2
	float LPVIntensity; // Offset: 0x4 | Size: 0x4
	float LPVVplInjectionBias; // Offset: 0x8 | Size: 0x4
	float LPVSize; // Offset: 0xc | Size: 0x4
	float LPVSecondaryOcclusionIntensity; // Offset: 0x10 | Size: 0x4
	float LPVSecondaryBounceIntensity; // Offset: 0x14 | Size: 0x4
	float LPVGeometryVolumeBias; // Offset: 0x18 | Size: 0x4
	float LPVEmissiveInjectionIntensity; // Offset: 0x1c | Size: 0x4
	float LPVDirectionalOcclusionIntensity; // Offset: 0x20 | Size: 0x4
	float LPVDirectionalOcclusionRadius; // Offset: 0x24 | Size: 0x4
	float LPVDiffuseOcclusionExponent; // Offset: 0x28 | Size: 0x4
	float LPVSpecularOcclusionExponent; // Offset: 0x2c | Size: 0x4
	float LPVDiffuseOcclusionIntensity; // Offset: 0x30 | Size: 0x4
	float LPVSpecularOcclusionIntensity; // Offset: 0x34 | Size: 0x4
	float LPVFadeRange; // Offset: 0x38 | Size: 0x4
	float LPVDirectionalOcclusionFadeRange; // Offset: 0x3c | Size: 0x4
};

