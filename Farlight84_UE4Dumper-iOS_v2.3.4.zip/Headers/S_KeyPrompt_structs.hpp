#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: UserDefinedStruct S_KeyPrompt.S_KeyPrompt
// Inherited Bytes: 0x0 | Struct Size: 0x6a
struct FS_KeyPrompt {
	// Fields
	struct FS_KeyPromptKeyBoard KeyBoardInfo_2_B90AE02F4CB9AD0D665AA28F9A2AC172; // Offset: 0x0 | Size: 0x68
	struct FS_KeyPromptMouse MouseInfo_5_1D9DBA59409F03B589D048980CD6DE69; // Offset: 0x68 | Size: 0x1
	struct FS_KeyPromptGamepad GamepadInfo_8_3CFBCBFC40895FDC0CCA05AD4C6BBEFC; // Offset: 0x69 | Size: 0x1
};

