#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: UserDefinedStruct S_SkillState.S_SkillState
// Inherited Bytes: 0x0 | Struct Size: 0x4
struct FS_SkillState {
	// Fields
	enum class ERoleSkillOperation Super_11_1687CEEF476DE16EEE6A42B53EC116E7; // Offset: 0x0 | Size: 0x1
	enum class ERoleSkillOperation Tactical_1_15_36D081C34231A20607055BA95F67E65B; // Offset: 0x1 | Size: 0x1
	enum class ERoleSkillOperation Tactical_2_16_32941DBD423D7A5321C1EEAB08668EBD; // Offset: 0x2 | Size: 0x1
	enum class ERoleSkillOperation Tactical_3_17_895B2BD741113F7BF94DAF975F993B30; // Offset: 0x3 | Size: 0x1
};

