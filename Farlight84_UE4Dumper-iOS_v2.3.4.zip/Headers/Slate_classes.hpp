#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class Slate.ButtonWidgetStyle
// Inherited Bytes: 0x30 | Struct Size: 0x450
struct UButtonWidgetStyle : USlateWidgetStyleContainerBase {
	// Fields
	struct FButtonStyle ButtonStyle; // Offset: 0x30 | Size: 0x420
};

// Object: Class Slate.CheckBoxWidgetStyle
// Inherited Bytes: 0x30 | Struct Size: 0x960
struct UCheckBoxWidgetStyle : USlateWidgetStyleContainerBase {
	// Fields
	struct FCheckBoxStyle CheckBoxStyle; // Offset: 0x30 | Size: 0x930
};

// Object: Class Slate.ComboBoxWidgetStyle
// Inherited Bytes: 0x30 | Struct Size: 0x6b0
struct UComboBoxWidgetStyle : USlateWidgetStyleContainerBase {
	// Fields
	struct FComboBoxStyle ComboBoxStyle; // Offset: 0x30 | Size: 0x680
};

// Object: Class Slate.ComboButtonWidgetStyle
// Inherited Bytes: 0x30 | Struct Size: 0x670
struct UComboButtonWidgetStyle : USlateWidgetStyleContainerBase {
	// Fields
	struct FComboButtonStyle ComboButtonStyle; // Offset: 0x30 | Size: 0x640
};

// Object: Class Slate.EditableTextBoxWidgetStyle
// Inherited Bytes: 0x30 | Struct Size: 0xd90
struct UEditableTextBoxWidgetStyle : USlateWidgetStyleContainerBase {
	// Fields
	struct FEditableTextBoxStyle EditableTextBoxStyle; // Offset: 0x30 | Size: 0xd60
};

// Object: Class Slate.EditableTextWidgetStyle
// Inherited Bytes: 0x30 | Struct Size: 0x3a0
struct UEditableTextWidgetStyle : USlateWidgetStyleContainerBase {
	// Fields
	struct FEditableTextStyle EditableTextStyle; // Offset: 0x30 | Size: 0x370
};

// Object: Class Slate.ProgressWidgetStyle
// Inherited Bytes: 0x30 | Struct Size: 0x310
struct UProgressWidgetStyle : USlateWidgetStyleContainerBase {
	// Fields
	struct FProgressBarStyle ProgressBarStyle; // Offset: 0x30 | Size: 0x2e0
};

// Object: Class Slate.ScrollBarWidgetStyle
// Inherited Bytes: 0x30 | Struct Size: 0x8b0
struct UScrollBarWidgetStyle : USlateWidgetStyleContainerBase {
	// Fields
	struct FScrollBarStyle ScrollBarStyle; // Offset: 0x30 | Size: 0x880
};

// Object: Class Slate.ScrollBoxWidgetStyle
// Inherited Bytes: 0x30 | Struct Size: 0x400
struct UScrollBoxWidgetStyle : USlateWidgetStyleContainerBase {
	// Fields
	struct FScrollBoxStyle ScrollBoxStyle; // Offset: 0x30 | Size: 0x3d0
};

// Object: Class Slate.SlateSettings
// Inherited Bytes: 0x28 | Struct Size: 0x30
struct USlateSettings : UObject {
	// Fields
	bool bExplicitCanvasChildZOrder; // Offset: 0x28 | Size: 0x1
	char pad_0x29[0x7]; // Offset: 0x29 | Size: 0x7
};

// Object: Class Slate.SpinBoxWidgetStyle
// Inherited Bytes: 0x30 | Struct Size: 0x530
struct USpinBoxWidgetStyle : USlateWidgetStyleContainerBase {
	// Fields
	struct FSpinBoxStyle SpinBoxStyle; // Offset: 0x30 | Size: 0x500
};

// Object: Class Slate.TextBlockWidgetStyle
// Inherited Bytes: 0x30 | Struct Size: 0x4e0
struct UTextBlockWidgetStyle : USlateWidgetStyleContainerBase {
	// Fields
	struct FTextBlockStyle TextBlockStyle; // Offset: 0x30 | Size: 0x4b0
};

// Object: Class Slate.ToolMenuBase
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UToolMenuBase : UObject {
};

