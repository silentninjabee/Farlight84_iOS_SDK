#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass SolarGameInstance.SolarGameInstance_C
// Inherited Bytes: 0xa60 | Struct Size: 0xa78
struct USolarGameInstance_C : USolarGameInstanceBase {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0xa60 | Size: 0x8
	struct FMulticastInlineDelegate OnBroadcastModeChanged; // Offset: 0xa68 | Size: 0x10

	// Functions

	// Object: DelegateFunction SolarGameInstance.SolarGameInstance_C.OnRefreshFirebaseToken_2C10A5FA7042BCCE535BF9A9237340F3
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1014413c8
	// Return & Params: [ Num(1) Size(0x10) ]
	void OnRefreshFirebaseToken_2C10A5FA7042BCCE535BF9A9237340F3(struct FString FirebaseToken);

	// Object: DelegateFunction SolarGameInstance.SolarGameInstance_C.OnClearCommunityRedhint_818BEA999B4CF342436AF38924E704CE
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1014413c8
	// Return & Params: [ Num(1) Size(0x10) ]
	void OnClearCommunityRedhint_818BEA999B4CF342436AF38924E704CE(struct FString ResultStr);

	// Object: DelegateFunction SolarGameInstance.SolarGameInstance_C.OnGetCommunityRedhint_55DB097C4D45D2A2167917A505C2944B
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1014413c8
	// Return & Params: [ Num(1) Size(0x10) ]
	void OnGetCommunityRedhint_55DB097C4D45D2A2167917A505C2944B(struct FString ResultStr);

	// Object: DelegateFunction SolarGameInstance.SolarGameInstance_C.OnExitCommunity_BC13C1140640533784E952B2D37F5778
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1014413c8
	// Return & Params: [ Num(1) Size(0x10) ]
	void OnExitCommunity_BC13C1140640533784E952B2D37F5778(struct FString ResultStr);

	// Object: DelegateFunction SolarGameInstance.SolarGameInstance_C.OnInitCommunity_8C84BC8E9B48C53CEF7B1EB1E586823D
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1014413c8
	// Return & Params: [ Num(1) Size(0x10) ]
	void OnInitCommunity_8C84BC8E9B48C53CEF7B1EB1E586823D(struct FString ResultStr);

	// Object: DelegateFunction SolarGameInstance.SolarGameInstance_C.OnIOSLLHPayFinished_10238BFCE9488D4624B9B788C6982B7F
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1014413c8
	// Return & Params: [ Num(6) Size(0x31) ]
	void OnIOSLLHPayFinished_10238BFCE9488D4624B9B788C6982B7F(bool bSuccess, int32_t ErrorCode, struct FString ErrorMsg, int32_t PayValue, struct FString ProductID, enum class ELLHSDKPayType PayType);

	// Object: DelegateFunction SolarGameInstance.SolarGameInstance_C.OnIOSQuerySkus_A45DCDCE5147A17AFF83BAA94DB0F3BD
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x1014413c8
	// Return & Params: [ Num(2) Size(0x20) ]
	void OnIOSQuerySkus_A45DCDCE5147A17AFF83BAA94DB0F3BD(struct FLLHSDKGenericSkuItemsDetailList ItemsDetailList, struct TArray<struct FString>& InvalidProductIDs);

	// Object: DelegateFunction SolarGameInstance.SolarGameInstance_C.OnInternalBrowserOpen_D6E08737A541854FA5A424AE486621EA
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1014413c8
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnInternalBrowserOpen_D6E08737A541854FA5A424AE486621EA();

	// Object: DelegateFunction SolarGameInstance.SolarGameInstance_C.OnBrowserClosed_574A18CD8C43BFADF16AD697176D0B1E
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1014413c8
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnBrowserClosed_574A18CD8C43BFADF16AD697176D0B1E();

	// Object: DelegateFunction SolarGameInstance.SolarGameInstance_C.OnReceiveNotification_03A16A31A848650CC79F3D9CE0D6510F
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1014413c8
	// Return & Params: [ Num(1) Size(0x4) ]
	void OnReceiveNotification_03A16A31A848650CC79F3D9CE0D6510F(int32_t NotificationType);

	// Object: DelegateFunction SolarGameInstance.SolarGameInstance_C.OnWifiStateChanged_A351BFA8AE41A98AB4BCA489A35BC39E
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1014413c8
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnWifiStateChanged_A351BFA8AE41A98AB4BCA489A35BC39E(bool bEnabled);

	// Object: Function SolarGameInstance.SolarGameInstance_C.OnScopeChanged
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x101456f90
	// Return & Params: [ Num(2) Size(0x2) ]
	void OnScopeChanged(enum class EScope InLastScope, enum class EScope InCurScope);

	// Object: Function SolarGameInstance.SolarGameInstance_C.SolarGM_AddItemLua
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x101456f90
	// Return & Params: [ Num(2) Size(0x8) ]
	void SolarGM_AddItemLua(int32_t ItemID, int32_t count);

	// Object: Function SolarGameInstance.SolarGameInstance_C.LuaStartGameFrameWork
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x101456f90
	// Return & Params: [ Num(0) Size(0x0) ]
	void LuaStartGameFrameWork();

	// Object: Function SolarGameInstance.SolarGameInstance_C.ShutDownLimSdk
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x101456f90
	// Return & Params: [ Num(0) Size(0x0) ]
	void ShutDownLimSdk();

	// Object: Function SolarGameInstance.SolarGameInstance_C.ExecuteChangeAudioModeLuaCall
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x101456f90
	// Return & Params: [ Num(1) Size(0x1) ]
	void ExecuteChangeAudioModeLuaCall(bool bTurnOn);

	// Object: Function SolarGameInstance.SolarGameInstance_C.SolarGM_TestCrashWithLua
	// Flags: [Exec|Event|Public|BlueprintEvent]
	// Offset: 0x101456f90
	// Return & Params: [ Num(0) Size(0x0) ]
	void SolarGM_TestCrashWithLua();

	// Object: Function SolarGameInstance.SolarGameInstance_C.CheckSavedDirFiles
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x101456f90
	// Return & Params: [ Num(1) Size(0x10) ]
	void CheckSavedDirFiles(struct TArray<struct FString>& Files);

	// Object: Function SolarGameInstance.SolarGameInstance_C.LuaInitGameFrameWork
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x101456f90
	// Return & Params: [ Num(0) Size(0x0) ]
	void LuaInitGameFrameWork();

	// Object: Function SolarGameInstance.SolarGameInstance_C.SolarGM_QuickMatchLua
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x101456f90
	// Return & Params: [ Num(2) Size(0x8) ]
	void SolarGM_QuickMatchLua(int32_t mapID, int32_t ruleID);

	// Object: Function SolarGameInstance.SolarGameInstance_C.ReportLoadingInfoToBI
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x101456f90
	// Return & Params: [ Num(3) Size(0x15) ]
	void ReportLoadingInfoToBI(struct TArray<struct FString>& LoadingInfo, float LoadingTime, bool bIsFinished);

	// Object: Function SolarGameInstance.SolarGameInstance_C.LuaGetBroadcastHeroNameCopy
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(2) Size(0x20) ]
	void LuaGetBroadcastHeroNameCopy(struct FString SolarPlayerId, struct FString& BroadcastPlayerName);

	// Object: Function SolarGameInstance.SolarGameInstance_C.ReceiveShutdown
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x101456f90
	// Return & Params: [ Num(0) Size(0x0) ]
	void ReceiveShutdown();

	// Object: Function SolarGameInstance.SolarGameInstance_C.ReceiveClientWasKicked
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x101456f90
	// Return & Params: [ Num(1) Size(0x10) ]
	void ReceiveClientWasKicked(struct FString KickReason);

	// Object: Function SolarGameInstance.SolarGameInstance_C.SolarGM_AddWeaponExpLua
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x101456f90
	// Return & Params: [ Num(2) Size(0x8) ]
	void SolarGM_AddWeaponExpLua(int32_t weaponid, int32_t count);

	// Object: Function SolarGameInstance.SolarGameInstance_C.LuaGetBroadcastPlayerNameCopy
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(2) Size(0x20) ]
	void LuaGetBroadcastPlayerNameCopy(struct FString SolarPlayerId, struct FString& BroadcastPlayerName);

	// Object: Function SolarGameInstance.SolarGameInstance_C.OnDisconnect
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x101456f90
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnDisconnect();

	// Object: Function SolarGameInstance.SolarGameInstance_C.ExecuteBackKeyLuaCall
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x101456f90
	// Return & Params: [ Num(0) Size(0x0) ]
	void ExecuteBackKeyLuaCall();

	// Object: Function SolarGameInstance.SolarGameInstance_C.SolarGM_LobbyLua
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x101456f90
	// Return & Params: [ Num(2) Size(0x20) ]
	void SolarGM_LobbyLua(struct FString CmdName, struct TArray<struct FString>& Params);

	// Object: Function SolarGameInstance.SolarGameInstance_C.HandleNetworkError
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x101456f90
	// Return & Params: [ Num(2) Size(0x2) ]
	void HandleNetworkError(enum class ENetworkFailure FailureType, bool bIsServer);

	// Object: Function SolarGameInstance.SolarGameInstance_C.OnOtherNetworkFailureDisconnect
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x101456f90
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnOtherNetworkFailureDisconnect();

	// Object: Function SolarGameInstance.SolarGameInstance_C.InitLuaClasses
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x101456f90
	// Return & Params: [ Num(0) Size(0x0) ]
	void InitLuaClasses();

	// Object: Function SolarGameInstance.SolarGameInstance_C.SolarGM_TransmitGMLua
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x101456f90
	// Return & Params: [ Num(2) Size(0x20) ]
	void SolarGM_TransmitGMLua(struct FString playerName, struct TArray<struct FString>& GmArray);

	// Object: Function SolarGameInstance.SolarGameInstance_C.SolarGM_TestEnsureMsgWithLua
	// Flags: [Exec|Event|Public|BlueprintEvent]
	// Offset: 0x101456f90
	// Return & Params: [ Num(0) Size(0x0) ]
	void SolarGM_TestEnsureMsgWithLua();

	// Object: Function SolarGameInstance.SolarGameInstance_C.RegisterNetworkManager
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x101456f90
	// Return & Params: [ Num(0) Size(0x0) ]
	void RegisterNetworkManager();

	// Object: Function SolarGameInstance.SolarGameInstance_C.ShutDownRTCSdk
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x101456f90
	// Return & Params: [ Num(0) Size(0x0) ]
	void ShutDownRTCSdk();

	// Object: Function SolarGameInstance.SolarGameInstance_C.AsyncDownLoadConfigFile
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x101456f90
	// Return & Params: [ Num(2) Size(0x18) ]
	void AsyncDownLoadConfigFile(int64_t TaskID, struct FString URL);

	// Object: Function SolarGameInstance.SolarGameInstance_C.ShutDownPCSDK
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x101456f90
	// Return & Params: [ Num(0) Size(0x0) ]
	void ShutDownPCSDK();

	// Object: Function SolarGameInstance.SolarGameInstance_C.LuaOnBroadcastModeChanged
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void LuaOnBroadcastModeChanged();

	// Object: Function SolarGameInstance.SolarGameInstance_C.LuaGetBroadcastPlayerName
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101456f90
	// Return & Params: [ Num(2) Size(0x20) ]
	void LuaGetBroadcastPlayerName(struct FString SolarPlayerId, struct FString& BroadcastPlayerName);

	// Object: Function SolarGameInstance.SolarGameInstance_C.LuaGetBroadcastHeroName
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101456f90
	// Return & Params: [ Num(2) Size(0x20) ]
	void LuaGetBroadcastHeroName(struct FString SolarPlayerId, struct FString& BroadcastPlayerName);

	// Object: Function SolarGameInstance.SolarGameInstance_C.SolarGM_TestCrashWithBP
	// Flags: [Exec|Event|Public|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void SolarGM_TestCrashWithBP();

	// Object: Function SolarGameInstance.SolarGameInstance_C.SolarGM_TestEnsureMsgWithBP
	// Flags: [Exec|Event|Public|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void SolarGM_TestEnsureMsgWithBP();

	// Object: Function SolarGameInstance.SolarGameInstance_C.ExecuteUbergraph_SolarGameInstance
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_SolarGameInstance(int32_t EntryPoint);

	// Object: Function SolarGameInstance.SolarGameInstance_C.OnBroadcastModeChanged__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnBroadcastModeChanged__DelegateSignature();
};

