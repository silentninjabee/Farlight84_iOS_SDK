#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct SpinePlugin.SpineEvent
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FSpineEvent {
	// Fields
	struct FString Name; // Offset: 0x0 | Size: 0x10
	struct FString StringValue; // Offset: 0x10 | Size: 0x10
	int32_t IntValue; // Offset: 0x20 | Size: 0x4
	float FloatValue; // Offset: 0x24 | Size: 0x4
	float Time; // Offset: 0x28 | Size: 0x4
	char pad_0x2C[0x4]; // Offset: 0x2c | Size: 0x4
};

// Object: ScriptStruct SpinePlugin.SpineAnimationStateMixData
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FSpineAnimationStateMixData {
	// Fields
	struct FString From; // Offset: 0x0 | Size: 0x10
	struct FString To; // Offset: 0x10 | Size: 0x10
	float Mix; // Offset: 0x20 | Size: 0x4
	char pad_0x24[0x4]; // Offset: 0x24 | Size: 0x4
};

