#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass TickerWidget.TickerWidget_C
// Inherited Bytes: 0x490 | Struct Size: 0x5d8
struct UTickerWidget_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x490 | Size: 0x8
	struct URichTextBlock* RichText; // Offset: 0x498 | Size: 0x8
	struct USizeBox* SizeBox; // Offset: 0x4a0 | Size: 0x8
	struct UCanvasPanel* TextPanel; // Offset: 0x4a8 | Size: 0x8
	struct FText Text; // Offset: 0x4b0 | Size: 0x18
	bool bEnableTickering; // Offset: 0x4c8 | Size: 0x1
	char pad_0x4C9[0x3]; // Offset: 0x4c9 | Size: 0x3
	float LoopIntervalDuration; // Offset: 0x4cc | Size: 0x4
	float AnimationSpeed; // Offset: 0x4d0 | Size: 0x4
	bool bCanTicker; // Offset: 0x4d4 | Size: 0x1
	char pad_0x4D5[0x3]; // Offset: 0x4d5 | Size: 0x3
	float OriTextWidth; // Offset: 0x4d8 | Size: 0x4
	char pad_0x4DC[0x4]; // Offset: 0x4dc | Size: 0x4
	struct FText ShortenedText; // Offset: 0x4e0 | Size: 0x18
	struct FTimerHandle TimerHandle; // Offset: 0x4f8 | Size: 0x8
	bool bEnableLocText; // Offset: 0x500 | Size: 0x1
	char pad_0x501[0x3]; // Offset: 0x501 | Size: 0x3
	int32_t LocTextID; // Offset: 0x504 | Size: 0x4
	bool bIsAnimationPlaying; // Offset: 0x508 | Size: 0x1
	char pad_0x509[0x3]; // Offset: 0x509 | Size: 0x3
	float TargetXVal; // Offset: 0x50c | Size: 0x4
	float DeltaTime; // Offset: 0x510 | Size: 0x4
	char pad_0x514[0x4]; // Offset: 0x514 | Size: 0x4
	struct FTimerHandle TickerTimerHandle; // Offset: 0x518 | Size: 0x8
	struct FSlateFontInfo Font; // Offset: 0x520 | Size: 0x68
	struct FSlateColor TxtColor; // Offset: 0x588 | Size: 0x28
	struct FLinearColor ShadowColor; // Offset: 0x5b0 | Size: 0x10
	struct FVector2D ShadowOffset; // Offset: 0x5c0 | Size: 0x8
	struct FVector2D Size; // Offset: 0x5c8 | Size: 0x8
	float Direction; // Offset: 0x5d0 | Size: 0x4
	bool bAlwaysTickering; // Offset: 0x5d4 | Size: 0x1
	enum class ETextJustify Justification; // Offset: 0x5d5 | Size: 0x1
	bool bAlwaysKeepJustification; // Offset: 0x5d6 | Size: 0x1
	enum class ETextJustify NewVar_1; // Offset: 0x5d7 | Size: 0x1

	// Functions

	// Object: Function TickerWidget.TickerWidget_C.UpdateText
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void UpdateText();

	// Object: Function TickerWidget.TickerWidget_C.ApplyJustification
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void ApplyJustification();

	// Object: Function TickerWidget.TickerWidget_C.CanTicker
	// Flags: [Private|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void CanTicker();

	// Object: Function TickerWidget.TickerWidget_C.PlayerTickerAnimHelper
	// Flags: [Private|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void PlayerTickerAnimHelper();

	// Object: Function TickerWidget.TickerWidget_C.SetTextEditorLoc
	// Flags: [Private|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void SetTextEditorLoc();

	// Object: Function TickerWidget.TickerWidget_C.StopTickerAnimation
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void StopTickerAnimation();

	// Object: Function TickerWidget.TickerWidget_C.PlayTickerAnimation
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void PlayTickerAnimation();

	// Object: Function TickerWidget.TickerWidget_C.SetText
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x18) ]
	void SetText(struct FText InText);

	// Object: Function TickerWidget.TickerWidget_C.OnSynchronizeProperties
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnSynchronizeProperties();

	// Object: Function TickerWidget.TickerWidget_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function TickerWidget.TickerWidget_C.OnHide
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnHide();

	// Object: Function TickerWidget.TickerWidget_C.OnSolarUIClosed
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnSolarUIClosed();

	// Object: Function TickerWidget.TickerWidget_C.Tick
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(2) Size(0x3c) ]
	void Tick(struct FGeometry MyGeometry, float InDeltaTime);

	// Object: Function TickerWidget.TickerWidget_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void Construct();

	// Object: Function TickerWidget.TickerWidget_C.OnLocalLangChangedEx
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x10) ]
	void OnLocalLangChangedEx(struct FString InLang);

	// Object: Function TickerWidget.TickerWidget_C.ExecuteUbergraph_TickerWidget
	// Flags: [Final|UbergraphFunction|HasDefaults]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_TickerWidget(int32_t EntryPoint);
};

