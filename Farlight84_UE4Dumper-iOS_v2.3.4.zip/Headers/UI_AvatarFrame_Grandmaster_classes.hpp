#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_AvatarFrame_Grandmaster.UI_AvatarFrame_Grandmaster_C
// Inherited Bytes: 0x490 | Struct Size: 0x4d0
struct UUI_AvatarFrame_Grandmaster_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x490 | Size: 0x8
	struct UWidgetAnimation* Loop_Anim; // Offset: 0x498 | Size: 0x8
	struct UImage* Img_Season; // Offset: 0x4a0 | Size: 0x8
	struct FMulticastInlineDelegate On Clicked; // Offset: 0x4a8 | Size: 0x10
	struct FMulticastInlineDelegate On Released; // Offset: 0x4b8 | Size: 0x10
	struct UTexture2D* NewVar_1; // Offset: 0x4c8 | Size: 0x8

	// Functions

	// Object: Function UI_AvatarFrame_Grandmaster.UI_AvatarFrame_Grandmaster_C.GetModuleName
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();

	// Object: Function UI_AvatarFrame_Grandmaster.UI_AvatarFrame_Grandmaster_C.SetAvatarIcon
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetAvatarIcon(int32_t InAvatarID);

	// Object: Function UI_AvatarFrame_Grandmaster.UI_AvatarFrame_Grandmaster_C.SetEmptyState
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetEmptyState(bool IsEmpty);

	// Object: Function UI_AvatarFrame_Grandmaster.UI_AvatarFrame_Grandmaster_C.SetPlayerGender
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetPlayerGender(enum class E_Type_Gender Gender);

	// Object: Function UI_AvatarFrame_Grandmaster.UI_AvatarFrame_Grandmaster_C.SetSocialIcon
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetSocialIcon(enum class E_Type_Social Social);

	// Object: Function UI_AvatarFrame_Grandmaster.UI_AvatarFrame_Grandmaster_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_AvatarFrame_Grandmaster.UI_AvatarFrame_Grandmaster_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void Construct();

	// Object: Function UI_AvatarFrame_Grandmaster.UI_AvatarFrame_Grandmaster_C.Update
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void Update();

	// Object: Function UI_AvatarFrame_Grandmaster.UI_AvatarFrame_Grandmaster_C.ExecuteUbergraph_UI_AvatarFrame_Grandmaster
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_AvatarFrame_Grandmaster(int32_t EntryPoint);

	// Object: Function UI_AvatarFrame_Grandmaster.UI_AvatarFrame_Grandmaster_C.On Released__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void On Released__DelegateSignature();

	// Object: Function UI_AvatarFrame_Grandmaster.UI_AvatarFrame_Grandmaster_C.On Clicked__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void On Clicked__DelegateSignature();
};

