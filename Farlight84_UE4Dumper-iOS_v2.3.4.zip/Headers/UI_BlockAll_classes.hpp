#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_BlockAll.UI_BlockAll_C
// Inherited Bytes: 0x490 | Struct Size: 0x498
struct UUI_BlockAll_C : USolarUserWidget {
	// Fields
	struct UCanvasPanel* Panel_Block; // Offset: 0x490 | Size: 0x8

	// Functions

	// Object: Function UI_BlockAll.UI_BlockAll_C.Destruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x101456f90
	// Return & Params: [ Num(0) Size(0x0) ]
	void Destruct();

	// Object: Function UI_BlockAll.UI_BlockAll_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x101456f90
	// Return & Params: [ Num(0) Size(0x0) ]
	void Construct();

	// Object: Function UI_BlockAll.UI_BlockAll_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();
};

