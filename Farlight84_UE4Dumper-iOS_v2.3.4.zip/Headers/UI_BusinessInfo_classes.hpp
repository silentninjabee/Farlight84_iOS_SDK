#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_BusinessInfo.UI_BusinessInfo_C
// Inherited Bytes: 0x490 | Struct Size: 0x518
struct UUI_BusinessInfo_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x490 | Size: 0x8
	struct UImage* Img_LvlBg_2; // Offset: 0x498 | Size: 0x8
	struct UUI_Component_NationalFlag_C* Img_NationFlag; // Offset: 0x4a0 | Size: 0x8
	struct UImage* Img_PlayerNumber_2; // Offset: 0x4a8 | Size: 0x8
	struct USizeBox* SizeBox_Rank; // Offset: 0x4b0 | Size: 0x8
	struct USolarTextBlock* Txt_Lvl; // Offset: 0x4b8 | Size: 0x8
	struct USolarTextBlock* Txt_Name; // Offset: 0x4c0 | Size: 0x8
	struct USolarTextBlock* Txt_RankName; // Offset: 0x4c8 | Size: 0x8
	struct UUI_Input_Device_C* UI_Input_Device; // Offset: 0x4d0 | Size: 0x8
	struct UUI_Rank_Icon_Small_C* UI_Rank_Icon_Small; // Offset: 0x4d8 | Size: 0x8
	struct UObject* TargetImg; // Offset: 0x4e0 | Size: 0x8
	struct FLinearColor TargetColor; // Offset: 0x4e8 | Size: 0x10
	struct TArray<struct UObject*> TeamPosImg; // Offset: 0x4f8 | Size: 0x10
	struct TArray<struct FLinearColor> Color; // Offset: 0x508 | Size: 0x10

	// Functions

	// Object: Function UI_BusinessInfo.UI_BusinessInfo_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();

	// Object: Function UI_BusinessInfo.UI_BusinessInfo_C.Set Player Number
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x4) ]
	void Set Player Number(int32_t PlayerNumber);

	// Object: Function UI_BusinessInfo.UI_BusinessInfo_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_BusinessInfo.UI_BusinessInfo_C.OnRefreshWidget
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x4) ]
	void OnRefreshWidget(int32_t Index);

	// Object: Function UI_BusinessInfo.UI_BusinessInfo_C.ExecuteUbergraph_UI_BusinessInfo
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_BusinessInfo(int32_t EntryPoint);
};

