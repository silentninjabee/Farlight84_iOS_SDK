#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass UI_Component_HyperLink.UI_Component_HyperLink_C
// Inherited Bytes: 0xb50 | Struct Size: 0xb50
struct UUI_Component_HyperLink_C : USolarHyperLinkRichText {
	// Functions

	// Object: Function UI_Component_HyperLink.UI_Component_HyperLink_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();
};

