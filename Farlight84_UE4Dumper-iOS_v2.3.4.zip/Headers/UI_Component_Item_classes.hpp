#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Component_Item.UI_Component_Item_C
// Inherited Bytes: 0x490 | Struct Size: 0x5c6
struct UUI_Component_Item_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x490 | Size: 0x8
	struct UWidgetAnimation* Anim_SerialTask_Unlock; // Offset: 0x498 | Size: 0x8
	struct UWidgetAnimation* Reset_Anim; // Offset: 0x4a0 | Size: 0x8
	struct UWidgetAnimation* Anim_Exchange; // Offset: 0x4a8 | Size: 0x8
	struct UWidgetAnimation* Anim_Loop; // Offset: 0x4b0 | Size: 0x8
	struct UWidgetAnimation* Puzzle_Unlock_Anim; // Offset: 0x4b8 | Size: 0x8
	struct UWidgetAnimation* Sold_Anim; // Offset: 0x4c0 | Size: 0x8
	struct UWidgetAnimation* Enter_Anim; // Offset: 0x4c8 | Size: 0x8
	struct UWidgetAnimation* Receive_Anim; // Offset: 0x4d0 | Size: 0x8
	struct UButton* Btn_Item; // Offset: 0x4d8 | Size: 0x8
	struct UImage* Image_TrialTag; // Offset: 0x4e0 | Size: 0x8
	struct UImage* Img_BG; // Offset: 0x4e8 | Size: 0x8
	struct UImage* Img_Bg_light; // Offset: 0x4f0 | Size: 0x8
	struct UImage* Img_BG_NoQuality; // Offset: 0x4f8 | Size: 0x8
	struct UImage* img_Equiped; // Offset: 0x500 | Size: 0x8
	struct UImage* Img_Icon; // Offset: 0x508 | Size: 0x8
	struct UImage* Img_Light_Lines; // Offset: 0x510 | Size: 0x8
	struct UImage* Img_Light_Wipes; // Offset: 0x518 | Size: 0x8
	struct UImage* Img_Light_Wipes_2; // Offset: 0x520 | Size: 0x8
	struct UImage* Img_Loop_Light; // Offset: 0x528 | Size: 0x8
	struct UImage* Img_Puzzle; // Offset: 0x530 | Size: 0x8
	struct UImage* Img_Selected; // Offset: 0x538 | Size: 0x8
	struct UImage* Img_Sold_Mask; // Offset: 0x540 | Size: 0x8
	struct UOverlay* Overlay_Random; // Offset: 0x548 | Size: 0x8
	struct UOverlay* Overlay_Recycle; // Offset: 0x550 | Size: 0x8
	struct UCanvasPanel* Panel_Claim; // Offset: 0x558 | Size: 0x8
	struct UOverlay* Received; // Offset: 0x560 | Size: 0x8
	struct USizeBox* Size_Item; // Offset: 0x568 | Size: 0x8
	struct USolarRedHint_General_C* SolarRedHint_General; // Offset: 0x570 | Size: 0x8
	struct UWidgetSwitcher* Switcher_Item; // Offset: 0x578 | Size: 0x8
	struct USolarRichTextBlock* Txt_ChatBubble; // Offset: 0x580 | Size: 0x8
	struct USolarTextBlock* Txt_Number; // Offset: 0x588 | Size: 0x8
	struct USolarTextBlock* Txt_Owned; // Offset: 0x590 | Size: 0x8
	struct UUI_Component_Item_VoiceSlot_C* UI_Component_Item_VideoSlot; // Offset: 0x598 | Size: 0x8
	struct UUI_Component_MR_C* UI_Component_MR; // Offset: 0x5a0 | Size: 0x8
	struct UImage* Unlock; // Offset: 0x5a8 | Size: 0x8
	enum class E_Type_Item ItemState; // Offset: 0x5b0 | Size: 0x1
	char pad_0x5B1[0x3]; // Offset: 0x5b1 | Size: 0x3
	int32_t ; // Offset: 0x5b4 | Size: 0x4
	enum class E_Item_Quality Quality; // Offset: 0x5b8 | Size: 0x1
	bool Select; // Offset: 0x5b9 | Size: 0x1
	bool Experience; // Offset: 0x5ba | Size: 0x1
	bool Num; // Offset: 0x5bb | Size: 0x1
	bool Puzzle; // Offset: 0x5bc | Size: 0x1
	bool Equiped; // Offset: 0x5bd | Size: 0x1
	bool RedHint; // Offset: 0x5be | Size: 0x1
	char pad_0x5BF[0x1]; // Offset: 0x5bf | Size: 0x1
	int32_t Txt_Size; // Offset: 0x5c0 | Size: 0x4
	bool NoQuality; // Offset: 0x5c4 | Size: 0x1
	bool IsRecycle; // Offset: 0x5c5 | Size: 0x1

	// Functions

	// Object: DelegateFunction UI_Component_Item.UI_Component_Item_C.OnClicked_5A6798A45C48172FDACB24A91F771508
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1014413c8
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_5A6798A45C48172FDACB24A91F771508();

	// Object: Function UI_Component_Item.UI_Component_Item_C.BP_OnItemSelectionChangedCopy
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x1) ]
	void BP_OnItemSelectionChangedCopy(bool bIsSelected);

	// Object: Function UI_Component_Item.UI_Component_Item_C.PlayEnterAnim
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x101456f90
	// Return & Params: [ Num(0) Size(0x0) ]
	void PlayEnterAnim();

	// Object: Function UI_Component_Item.UI_Component_Item_C.OnListItemObjectSetCopy
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x8) ]
	void OnListItemObjectSetCopy(struct UObject* ListItemObject);

	// Object: Function UI_Component_Item.UI_Component_Item_C.SetIcon_LuaCopy
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void SetIcon_LuaCopy();

	// Object: Function UI_Component_Item.UI_Component_Item_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();

	// Object: Function UI_Component_Item.UI_Component_Item_C.SequenceEvent__ENTRYPOINTUI_Component_Item_3
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void SequenceEvent__ENTRYPOINTUI_Component_Item_3();

	// Object: Function UI_Component_Item.UI_Component_Item_C.SequenceEvent__ENTRYPOINTUI_Component_Item_2
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void SequenceEvent__ENTRYPOINTUI_Component_Item_2();

	// Object: Function UI_Component_Item.UI_Component_Item_C.SequenceEvent__ENTRYPOINTUI_Component_Item_1
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void SequenceEvent__ENTRYPOINTUI_Component_Item_1();

	// Object: Function UI_Component_Item.UI_Component_Item_C.PlaySerialTaskUnlockAnim
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void PlaySerialTaskUnlockAnim();

	// Object: Function UI_Component_Item.UI_Component_Item_C.SetIcon_Lua
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101456f90
	// Return & Params: [ Num(0) Size(0x0) ]
	void SetIcon_Lua();

	// Object: Function UI_Component_Item.UI_Component_Item_C.BP_OnEntryReleased
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void BP_OnEntryReleased();

	// Object: Function UI_Component_Item.UI_Component_Item_C.BP_OnItemExpansionChanged
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x1) ]
	void BP_OnItemExpansionChanged(bool bIsExpanded);

	// Object: Function UI_Component_Item.UI_Component_Item_C.BP_OnItemSelectionChanged
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x101456f90
	// Return & Params: [ Num(1) Size(0x1) ]
	void BP_OnItemSelectionChanged(bool bIsSelected);

	// Object: Function UI_Component_Item.UI_Component_Item_C.OnListItemObjectSet
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x101456f90
	// Return & Params: [ Num(1) Size(0x8) ]
	void OnListItemObjectSet(struct UObject* ListItemObject);

	// Object: Function UI_Component_Item.UI_Component_Item_C.PlaySound_Puzzle_Unlock_Anim
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void PlaySound_Puzzle_Unlock_Anim();

	// Object: Function UI_Component_Item.UI_Component_Item_C.PlaySound_Anim_Exchange
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void PlaySound_Anim_Exchange();

	// Object: Function UI_Component_Item.UI_Component_Item_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_Component_Item.UI_Component_Item_C.ChangItemState
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void ChangItemState();

	// Object: Function UI_Component_Item.UI_Component_Item_C.PlayReceiveAnimEvent
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void PlayReceiveAnimEvent();

	// Object: Function UI_Component_Item.UI_Component_Item_C.StopReceiveAnimEvent
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void StopReceiveAnimEvent();

	// Object: Function UI_Component_Item.UI_Component_Item_C.ExecuteUbergraph_UI_Component_Item
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_Component_Item(int32_t EntryPoint);
};

