#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Component_NationalFlag.UI_Component_NationalFlag_C
// Inherited Bytes: 0x4c0 | Struct Size: 0x4dd
struct UUI_Component_NationalFlag_C : UUIComponentNationalFlag {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x4c0 | Size: 0x8
	struct USizeBox* SizeBox_1; // Offset: 0x4c8 | Size: 0x8
	struct UWidgetSwitcher* WidgetSwitcher_Flag; // Offset: 0x4d0 | Size: 0x8
	float Size; // Offset: 0x4d8 | Size: 0x4
	enum class E_FlagType FlagType; // Offset: 0x4dc | Size: 0x1

	// Functions

	// Object: Function UI_Component_NationalFlag.UI_Component_NationalFlag_C.SetDefaultNationalFlag
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101456f90
	// Return & Params: [ Num(0) Size(0x0) ]
	void SetDefaultNationalFlag();

	// Object: Function UI_Component_NationalFlag.UI_Component_NationalFlag_C.SetDefaultClanFlag
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101456f90
	// Return & Params: [ Num(0) Size(0x0) ]
	void SetDefaultClanFlag();

	// Object: Function UI_Component_NationalFlag.UI_Component_NationalFlag_C.Destruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x101456f90
	// Return & Params: [ Num(0) Size(0x0) ]
	void Destruct();

	// Object: Function UI_Component_NationalFlag.UI_Component_NationalFlag_C.IsBroadCastMode
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101456f90
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsBroadCastMode();

	// Object: Function UI_Component_NationalFlag.UI_Component_NationalFlag_C.OnSolarUIClosed
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x101456f90
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnSolarUIClosed();

	// Object: Function UI_Component_NationalFlag.UI_Component_NationalFlag_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x101456f90
	// Return & Params: [ Num(0) Size(0x0) ]
	void Construct();

	// Object: Function UI_Component_NationalFlag.UI_Component_NationalFlag_C.OnInitialized
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x101456f90
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnInitialized();

	// Object: Function UI_Component_NationalFlag.UI_Component_NationalFlag_C.OnSolarUIOpened
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x101456f90
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnSolarUIOpened();

	// Object: Function UI_Component_NationalFlag.UI_Component_NationalFlag_C.IsExclusiveFlagId
	// Flags: [Event|Protected|BlueprintEvent|Const]
	// Offset: 0x101456f90
	// Return & Params: [ Num(2) Size(0x5) ]
	bool IsExclusiveFlagId(int32_t InFlagID);

	// Object: Function UI_Component_NationalFlag.UI_Component_NationalFlag_C.LoadClanFlagByUrl
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101456f90
	// Return & Params: [ Num(0) Size(0x0) ]
	void LoadClanFlagByUrl();

	// Object: Function UI_Component_NationalFlag.UI_Component_NationalFlag_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();

	// Object: Function UI_Component_NationalFlag.UI_Component_NationalFlag_C.SetEmptyClan
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void SetEmptyClan();

	// Object: Function UI_Component_NationalFlag.UI_Component_NationalFlag_C.SetFlagType
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetFlagType(enum class E_FlagType FlagType);

	// Object: Function UI_Component_NationalFlag.UI_Component_NationalFlag_C.Set UI State
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void Set UI State();

	// Object: Function UI_Component_NationalFlag.UI_Component_NationalFlag_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_Component_NationalFlag.UI_Component_NationalFlag_C.SetNationalFlagType
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void SetNationalFlagType();

	// Object: Function UI_Component_NationalFlag.UI_Component_NationalFlag_C.SetClanFlagType
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void SetClanFlagType();

	// Object: Function UI_Component_NationalFlag.UI_Component_NationalFlag_C.ExecuteUbergraph_UI_Component_NationalFlag
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_Component_NationalFlag(int32_t EntryPoint);
};

