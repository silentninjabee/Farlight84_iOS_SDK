#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Component_PlayerName.UI_Component_PlayerName_C
// Inherited Bytes: 0x490 | Struct Size: 0x808
struct UUI_Component_PlayerName_C : UUIComponentPlayerName {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x490 | Size: 0x8
	struct USolarTextBlock* Txt_PlayerName; // Offset: 0x498 | Size: 0x8
	struct FS_VIP_TxtInfo DefaultTxtInfo; // Offset: 0x4a0 | Size: 0x90
	enum class E_Type_PlayerName_Vip_Color VIP_State; // Offset: 0x530 | Size: 0x1
	char pad_0x531[0x7]; // Offset: 0x531 | Size: 0x7
	struct TMap<enum class E_Type_PlayerName_Vip_Color, struct FS_VIP_TxtInfo> VIP_TxtInfos; // Offset: 0x538 | Size: 0x50
	bool Cheater; // Offset: 0x588 | Size: 0x1
	char pad_0x589[0x7]; // Offset: 0x589 | Size: 0x7
	struct FS_VIP_TxtInfo CheatTxtInfo; // Offset: 0x590 | Size: 0x90
	bool Killed; // Offset: 0x620 | Size: 0x1
	char pad_0x621[0x7]; // Offset: 0x621 | Size: 0x7
	struct FS_VIP_TxtInfo KilledTxtInfo; // Offset: 0x628 | Size: 0x90
	bool bSpecialSelf; // Offset: 0x6b8 | Size: 0x1
	char pad_0x6B9[0x7]; // Offset: 0x6b9 | Size: 0x7
	struct FS_VIP_TxtInfo SpecialSelfTxtInfo; // Offset: 0x6c0 | Size: 0x90
	struct FS_VIP_TxtInfo CurTxtInfo; // Offset: 0x750 | Size: 0x90
	struct FText DefaultText; // Offset: 0x7e0 | Size: 0x18
	struct TArray<struct FS_VIP_TxtInfo> VIP_TxtInfoArray; // Offset: 0x7f8 | Size: 0x10

	// Functions

	// Object: Function UI_Component_PlayerName.UI_Component_PlayerName_C.SetIsKilled
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetIsKilled(bool IsKilled);

	// Object: Function UI_Component_PlayerName.UI_Component_PlayerName_C.SetIsCheater
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetIsCheater(bool bCheater);

	// Object: Function UI_Component_PlayerName.UI_Component_PlayerName_C.SetVipStyle
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetVipStyle(enum class E_Type_PlayerName_Vip_Color VIP_Type);

	// Object: Function UI_Component_PlayerName.UI_Component_PlayerName_C.SetPlayerNameAndStyle
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(4) Size(0x13) ]
	void SetPlayerNameAndStyle(struct FString NickName, bool bCheat, enum class E_Type_PlayerName_Vip_Color VIP_Type, bool bKilled);

	// Object: Function UI_Component_PlayerName.UI_Component_PlayerName_C.SetPlayerName
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetPlayerName(struct FString NickName);

	// Object: Function UI_Component_PlayerName.UI_Component_PlayerName_C.SetDefaultStyle
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetDefaultStyle(bool bSpecialSelf);

	// Object: Function UI_Component_PlayerName.UI_Component_PlayerName_C.SetNameStyle
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(3) Size(0x3) ]
	void SetNameStyle(bool bCheater, enum class E_Type_PlayerName_Vip_Color VIP_State, bool bKilled);

	// Object: Function UI_Component_PlayerName.UI_Component_PlayerName_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_Component_PlayerName.UI_Component_PlayerName_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void Construct();

	// Object: Function UI_Component_PlayerName.UI_Component_PlayerName_C.ReSize
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void ReSize();

	// Object: Function UI_Component_PlayerName.UI_Component_PlayerName_C.UpdatePlayerNameAndStyle
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(4) Size(0x13) ]
	void UpdatePlayerNameAndStyle(struct FString NickName, char VipType, bool bCheat, bool bKilled);

	// Object: Function UI_Component_PlayerName.UI_Component_PlayerName_C.SetText
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetText(struct FString Content);

	// Object: Function UI_Component_PlayerName.UI_Component_PlayerName_C.SetTextColorAndOpacity
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x28) ]
	void SetTextColorAndOpacity(struct FSlateColor InColor);

	// Object: Function UI_Component_PlayerName.UI_Component_PlayerName_C.SetStyle
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(3) Size(0x3) ]
	void SetStyle(char VipType, bool bCheat, bool bKilled);

	// Object: Function UI_Component_PlayerName.UI_Component_PlayerName_C.SetDeath
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetDeath(bool bDeath);

	// Object: Function UI_Component_PlayerName.UI_Component_PlayerName_C.SetVip
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetVip(char VipType);

	// Object: Function UI_Component_PlayerName.UI_Component_PlayerName_C.SetCheater
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetCheater(bool bCheat);

	// Object: Function UI_Component_PlayerName.UI_Component_PlayerName_C.SetIsSpecialSelf
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetIsSpecialSelf(bool bSelfStyle);

	// Object: Function UI_Component_PlayerName.UI_Component_PlayerName_C.ExecuteUbergraph_UI_Component_PlayerName
	// Flags: [Final|UbergraphFunction|HasDefaults]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_Component_PlayerName(int32_t EntryPoint);
};

