#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Component_SeasonImprint.UI_Component_SeasonImprint_C
// Inherited Bytes: 0x490 | Struct Size: 0x4d1
struct UUI_Component_SeasonImprint_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x490 | Size: 0x8
	struct UWidgetAnimation* Anim_Active; // Offset: 0x498 | Size: 0x8
	struct UImage* Image_Light; // Offset: 0x4a0 | Size: 0x8
	struct UImage* Image_Unlight; // Offset: 0x4a8 | Size: 0x8
	struct UImage* Img_BG; // Offset: 0x4b0 | Size: 0x8
	struct USizeBox* SizeBox_Icon; // Offset: 0x4b8 | Size: 0x8
	struct UWidgetSwitcher* WidgetSwitcher_Imprint; // Offset: 0x4c0 | Size: 0x8
	bool bIsLight; // Offset: 0x4c8 | Size: 0x1
	char pad_0x4C9[0x3]; // Offset: 0x4c9 | Size: 0x3
	int32_t Size; // Offset: 0x4cc | Size: 0x4
	bool ShowBg; // Offset: 0x4d0 | Size: 0x1

	// Functions

	// Object: Function UI_Component_SeasonImprint.UI_Component_SeasonImprint_C.Destruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x101456f90
	// Return & Params: [ Num(0) Size(0x0) ]
	void Destruct();

	// Object: Function UI_Component_SeasonImprint.UI_Component_SeasonImprint_C.OnInitialized
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x101456f90
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnInitialized();

	// Object: Function UI_Component_SeasonImprint.UI_Component_SeasonImprint_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x101456f90
	// Return & Params: [ Num(0) Size(0x0) ]
	void Construct();

	// Object: Function UI_Component_SeasonImprint.UI_Component_SeasonImprint_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();

	// Object: Function UI_Component_SeasonImprint.UI_Component_SeasonImprint_C.SetSeasonID
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(2) Size(0x5) ]
	void SetSeasonID(int32_t SeasonID, bool bHideIfNoData);

	// Object: Function UI_Component_SeasonImprint.UI_Component_SeasonImprint_C.RefreshLight
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void RefreshLight();

	// Object: Function UI_Component_SeasonImprint.UI_Component_SeasonImprint_C.SetImprintLight
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetImprintLight(bool bIsLight);

	// Object: Function UI_Component_SeasonImprint.UI_Component_SeasonImprint_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_Component_SeasonImprint.UI_Component_SeasonImprint_C.ExecuteUbergraph_UI_Component_SeasonImprint
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_Component_SeasonImprint(int32_t EntryPoint);
};

