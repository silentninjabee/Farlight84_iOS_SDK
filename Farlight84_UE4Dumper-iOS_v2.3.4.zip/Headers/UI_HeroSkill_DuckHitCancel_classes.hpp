#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_HeroSkill_DuckHitCancel.UI_HeroSkill_DuckHitCancel_C
// Inherited Bytes: 0x5c0 | Struct Size: 0x5d0
struct UUI_HeroSkill_DuckHitCancel_C : UCrossHairWidget {
	// Fields
	struct UGaugeImage_C* Progress_Hit; // Offset: 0x5c0 | Size: 0x8
	struct UImage* SpreadImg_coredot; // Offset: 0x5c8 | Size: 0x8

	// Functions

	// Object: Function UI_HeroSkill_DuckHitCancel.UI_HeroSkill_DuckHitCancel_C.UpdateRatio
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x4) ]
	void UpdateRatio(float Ratio);
};

