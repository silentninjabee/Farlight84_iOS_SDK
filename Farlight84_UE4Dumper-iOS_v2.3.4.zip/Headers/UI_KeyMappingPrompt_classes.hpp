#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_KeyMappingPrompt.UI_KeyMappingPrompt_C
// Inherited Bytes: 0x4e0 | Struct Size: 0x555
struct UUI_KeyMappingPrompt_C : USolarComponentKeyMappingPrompt {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x4e0 | Size: 0x8
	struct UWidgetAnimation* Anim_Press; // Offset: 0x4e8 | Size: 0x8
	struct UOverlay* Empty; // Offset: 0x4f0 | Size: 0x8
	struct UOverlay* EmptyDisable; // Offset: 0x4f8 | Size: 0x8
	struct UHorizontalBox* HorizontalLayout; // Offset: 0x500 | Size: 0x8
	struct USizeBox* Icon; // Offset: 0x508 | Size: 0x8
	struct UImage* Img_BG; // Offset: 0x510 | Size: 0x8
	struct UOverlay* Overlay_Root; // Offset: 0x518 | Size: 0x8
	struct UCanvasPanel* Panel_Hold; // Offset: 0x520 | Size: 0x8
	struct USolarTextBlock* Txt_Hold; // Offset: 0x528 | Size: 0x8
	struct UTextBlock* Txt_Key; // Offset: 0x530 | Size: 0x8
	struct USolarTextBlock* Txt_Shortcut; // Offset: 0x538 | Size: 0x8
	struct USolarTextBlock* Txt_ShortcutLeft; // Offset: 0x540 | Size: 0x8
	struct UVerticalBox* VerticalBoxRoot; // Offset: 0x548 | Size: 0x8
	enum class E_KeyPromptStyle Style; // Offset: 0x550 | Size: 0x1
	bool bDisableEmpty; // Offset: 0x551 | Size: 0x1
	bool bEnableInputSettingHide; // Offset: 0x552 | Size: 0x1
	bool bOnlyDisplayMouseAndKeyboard; // Offset: 0x553 | Size: 0x1
	bool bEnableBtn; // Offset: 0x554 | Size: 0x1

	// Functions

	// Object: Function UI_KeyMappingPrompt.UI_KeyMappingPrompt_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();

	// Object: Function UI_KeyMappingPrompt.UI_KeyMappingPrompt_C.SetEnableBtn
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetEnableBtn(bool bInEnableBtn);

	// Object: Function UI_KeyMappingPrompt.UI_KeyMappingPrompt_C.SetKeyPromptCustomInfo
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x70) ]
	void SetKeyPromptCustomInfo(struct FS_KeyPrompt InInfo);

	// Object: Function UI_KeyMappingPrompt.UI_KeyMappingPrompt_C.SetOnlyDisplayMouseAndKeyboard
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetOnlyDisplayMouseAndKeyboard(bool bInOnlyDisplayMouseAndKeyboard);

	// Object: Function UI_KeyMappingPrompt.UI_KeyMappingPrompt_C.SetEnableInputSettingHide
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetEnableInputSettingHide(bool bEnable);

	// Object: Function UI_KeyMappingPrompt.UI_KeyMappingPrompt_C.SetOperationTypeImpl
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetOperationTypeImpl(enum class E_InputOperationType InType);

	// Object: Function UI_KeyMappingPrompt.UI_KeyMappingPrompt_C.SetEnableEmptyDispaly
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetEnableEmptyDispaly(bool bEnable);

	// Object: Function UI_KeyMappingPrompt.UI_KeyMappingPrompt_C.SetStyle
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetStyle(enum class E_KeyPromptStyle Style);

	// Object: Function UI_KeyMappingPrompt.UI_KeyMappingPrompt_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_KeyMappingPrompt.UI_KeyMappingPrompt_C.OnLoadAdapterSlotWidgetFinished
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnLoadAdapterSlotWidgetFinished();

	// Object: Function UI_KeyMappingPrompt.UI_KeyMappingPrompt_C.RefreshKeyDisplayEmpty
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void RefreshKeyDisplayEmpty();

	// Object: Function UI_KeyMappingPrompt.UI_KeyMappingPrompt_C.ExecuteUbergraph_UI_KeyMappingPrompt
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_KeyMappingPrompt(int32_t EntryPoint);
};

