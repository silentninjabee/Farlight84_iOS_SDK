#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_LobbyBase.UI_LobbyBase_C
// Inherited Bytes: 0x4e0 | Struct Size: 0x4e8
struct UUI_LobbyBase_C : USolarPanelWidget {
	// Fields
	struct UPanelWidget* VideoWrapper; // Offset: 0x4e0 | Size: 0x8

	// Functions

	// Object: Function UI_LobbyBase.UI_LobbyBase_C.InitLobbyBase
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x8) ]
	void InitLobbyBase(struct UPanelWidget* InVideo);
};

