#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Lobby_Battery.UI_Lobby_Battery_C
// Inherited Bytes: 0x260 | Struct Size: 0x640
struct UUI_Lobby_Battery_C : UUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x260 | Size: 0x8
	struct UImage* Img_Charging; // Offset: 0x268 | Size: 0x8
	struct UProgressBar* ProgressBar_Battery; // Offset: 0x270 | Size: 0x8
	char pad_0x278[0x8]; // Offset: 0x278 | Size: 0x8
	struct FSlateBrush ProgressBarBgImage; // Offset: 0x280 | Size: 0xf0
	struct FSlateBrush ProgressBarMarqueeImage; // Offset: 0x370 | Size: 0xf0
	struct FSlateBrush ProgressBarFillNormal; // Offset: 0x460 | Size: 0xf0
	struct FSlateBrush ProgressBarFillCharging; // Offset: 0x550 | Size: 0xf0

	// Functions

	// Object: Function UI_Lobby_Battery.UI_Lobby_Battery_C.ForceRefreshBatteryUI
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void ForceRefreshBatteryUI();

	// Object: Function UI_Lobby_Battery.UI_Lobby_Battery_C.RefreshBatteryUI
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(2) Size(0x5) ]
	void RefreshBatteryUI(int32_t BatteryLevelNewParam, bool bCharging);

	// Object: Function UI_Lobby_Battery.UI_Lobby_Battery_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_Lobby_Battery.UI_Lobby_Battery_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void Construct();

	// Object: Function UI_Lobby_Battery.UI_Lobby_Battery_C.EventRefreshBatteryUI
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void EventRefreshBatteryUI();

	// Object: Function UI_Lobby_Battery.UI_Lobby_Battery_C.Destruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void Destruct();

	// Object: Function UI_Lobby_Battery.UI_Lobby_Battery_C.ExecuteUbergraph_UI_Lobby_Battery
	// Flags: [Final|UbergraphFunction|HasDefaults]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_Lobby_Battery(int32_t EntryPoint);
};

