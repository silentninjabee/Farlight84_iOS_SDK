#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Lobby_Invite_Btn.UI_Lobby_Invite_Btn_C
// Inherited Bytes: 0x490 | Struct Size: 0x4b2
struct UUI_Lobby_Invite_Btn_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x490 | Size: 0x8
	struct UButton* Btn_Invite; // Offset: 0x498 | Size: 0x8
	struct UImage* Img_BG_2; // Offset: 0x4a0 | Size: 0x8
	struct UOverlay* Overlay_Txt; // Offset: 0x4a8 | Size: 0x8
	bool IsDesktop; // Offset: 0x4b0 | Size: 0x1
	enum class E_Type_State_Button StateDesktop; // Offset: 0x4b1 | Size: 0x1

	// Functions

	// Object: DelegateFunction UI_Lobby_Invite_Btn.UI_Lobby_Invite_Btn_C.OnClicked_C0622C47B94C154D8384ABA06CC11C10
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1014413c8
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_C0622C47B94C154D8384ABA06CC11C10();

	// Object: DelegateFunction UI_Lobby_Invite_Btn.UI_Lobby_Invite_Btn_C.OnClicked_EB35A127AC49137800925F9F4654D1AF
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1014413c8
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_EB35A127AC49137800925F9F4654D1AF();

	// Object: DelegateFunction UI_Lobby_Invite_Btn.UI_Lobby_Invite_Btn_C.OnClicked_25120387B34B29027D9058BE9B79E5DA
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1014413c8
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_25120387B34B29027D9058BE9B79E5DA();

	// Object: Function UI_Lobby_Invite_Btn.UI_Lobby_Invite_Btn_C.OnInitialized
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x101456f90
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnInitialized();

	// Object: Function UI_Lobby_Invite_Btn.UI_Lobby_Invite_Btn_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();

	// Object: Function UI_Lobby_Invite_Btn.UI_Lobby_Invite_Btn_C.SetStateDesktop
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(2) Size(0x2) ]
	void SetStateDesktop(bool IsDesktop, enum class E_Type_State_Button StateDesktop);

	// Object: Function UI_Lobby_Invite_Btn.UI_Lobby_Invite_Btn_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_Lobby_Invite_Btn.UI_Lobby_Invite_Btn_C.ExecuteUbergraph_UI_Lobby_Invite_Btn
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_Lobby_Invite_Btn(int32_t EntryPoint);
};

