#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Lobby_Mate.UI_Lobby_Mate_C
// Inherited Bytes: 0x490 | Struct Size: 0x531
struct UUI_Lobby_Mate_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x490 | Size: 0x8
	struct UButton* Btn_Cancel; // Offset: 0x498 | Size: 0x8
	struct USolarButton* Btn_Warmup; // Offset: 0x4a0 | Size: 0x8
	struct UImage* Img_BG; // Offset: 0x4a8 | Size: 0x8
	struct UImage* img_BtnBg; // Offset: 0x4b0 | Size: 0x8
	struct UImage* Img_Map; // Offset: 0x4b8 | Size: 0x8
	struct UImage* Img_MapTick; // Offset: 0x4c0 | Size: 0x8
	struct UImage* Img_Match; // Offset: 0x4c8 | Size: 0x8
	struct UImage* Img_Matching; // Offset: 0x4d0 | Size: 0x8
	struct UImage* Img_Warmup; // Offset: 0x4d8 | Size: 0x8
	struct UCanvasPanel* Panel_BtnCancel; // Offset: 0x4e0 | Size: 0x8
	struct UCanvasPanel* Panel_Map; // Offset: 0x4e8 | Size: 0x8
	struct UUI_Lobby_Mate_Progress_C* Panel_Progress; // Offset: 0x4f0 | Size: 0x8
	struct UCanvasPanel* Panel_Warmup; // Offset: 0x4f8 | Size: 0x8
	struct UWidgetSwitcher* Switcher_MatchState; // Offset: 0x500 | Size: 0x8
	struct USolarTextBlock* Txt_Btn; // Offset: 0x508 | Size: 0x8
	struct USolarTextBlock* Txt_Map; // Offset: 0x510 | Size: 0x8
	struct USolarTextBlock* Txt_MateState; // Offset: 0x518 | Size: 0x8
	struct USolarTextBlock* Txt_Warmup; // Offset: 0x520 | Size: 0x8
	struct UUI_KeyPrompt_C* UI_KeyPrompt_Cancel; // Offset: 0x528 | Size: 0x8
	enum class E_Lobby_Mate_State MateState; // Offset: 0x530 | Size: 0x1

	// Functions

	// Object: DelegateFunction UI_Lobby_Mate.UI_Lobby_Mate_C.OnClicked_A8E3D31C2345C5FE5C73C5A3F70119FA
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1014413c8
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_A8E3D31C2345C5FE5C73C5A3F70119FA();

	// Object: DelegateFunction UI_Lobby_Mate.UI_Lobby_Mate_C.OnClicked_6947EEC95A49F770F995919F760482C4
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1014413c8
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_6947EEC95A49F770F995919F760482C4();

	// Object: Function UI_Lobby_Mate.UI_Lobby_Mate_C.OnSolarUIClosed
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x101456f90
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnSolarUIClosed();

	// Object: Function UI_Lobby_Mate.UI_Lobby_Mate_C.OnInitialized
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x101456f90
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnInitialized();

	// Object: Function UI_Lobby_Mate.UI_Lobby_Mate_C.OnSolarUIOpened
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x101456f90
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnSolarUIOpened();

	// Object: Function UI_Lobby_Mate.UI_Lobby_Mate_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();

	// Object: Function UI_Lobby_Mate.UI_Lobby_Mate_C.SetProgressImgMaskPosition
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void SetProgressImgMaskPosition();

	// Object: Function UI_Lobby_Mate.UI_Lobby_Mate_C.GetPercent
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x4) ]
	void GetPercent(float& NewParam);

	// Object: Function UI_Lobby_Mate.UI_Lobby_Mate_C.SetPercent
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetPercent(float NewParam);

	// Object: Function UI_Lobby_Mate.UI_Lobby_Mate_C.SetMateState
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetMateState(enum class E_Lobby_Mate_State MateState);

	// Object: Function UI_Lobby_Mate.UI_Lobby_Mate_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_Lobby_Mate.UI_Lobby_Mate_C.ExecuteUbergraph_UI_Lobby_Mate
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_Lobby_Mate(int32_t EntryPoint);
};

