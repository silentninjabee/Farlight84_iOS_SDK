#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Lobby_Name_Version_Slot.UI_Lobby_Name_Version_Slot_C
// Inherited Bytes: 0x490 | Struct Size: 0x4cb
struct UUI_Lobby_Name_Version_Slot_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x490 | Size: 0x8
	struct USolarButton* Btn_Action; // Offset: 0x498 | Size: 0x8
	struct UImage* Img_BG; // Offset: 0x4a0 | Size: 0x8
	struct UImage* Img_Icon; // Offset: 0x4a8 | Size: 0x8
	struct UImage* Img_Line; // Offset: 0x4b0 | Size: 0x8
	struct USolarTextBlock* txt; // Offset: 0x4b8 | Size: 0x8
	enum class E_Type_State_Button BtnType; // Offset: 0x4c0 | Size: 0x1
	char pad_0x4C1[0x3]; // Offset: 0x4c1 | Size: 0x3
	int32_t Text; // Offset: 0x4c4 | Size: 0x4
	bool IsLine; // Offset: 0x4c8 | Size: 0x1
	bool Issocialize; // Offset: 0x4c9 | Size: 0x1
	enum class E_Type_Version VersionType; // Offset: 0x4ca | Size: 0x1

	// Functions

	// Object: Function UI_Lobby_Name_Version_Slot.UI_Lobby_Name_Version_Slot_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();

	// Object: Function UI_Lobby_Name_Version_Slot.UI_Lobby_Name_Version_Slot_C.SetVersionType
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetVersionType(enum class E_Type_Version Type);

	// Object: Function UI_Lobby_Name_Version_Slot.UI_Lobby_Name_Version_Slot_C.SetBtnType
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetBtnType(enum class E_Type_State_Button BtnType);

	// Object: Function UI_Lobby_Name_Version_Slot.UI_Lobby_Name_Version_Slot_C.BP_OnEntryReleased
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void BP_OnEntryReleased();

	// Object: Function UI_Lobby_Name_Version_Slot.UI_Lobby_Name_Version_Slot_C.BP_OnItemExpansionChanged
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x1) ]
	void BP_OnItemExpansionChanged(bool bIsExpanded);

	// Object: Function UI_Lobby_Name_Version_Slot.UI_Lobby_Name_Version_Slot_C.BP_OnItemSelectionChanged
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x1) ]
	void BP_OnItemSelectionChanged(bool bIsSelected);

	// Object: Function UI_Lobby_Name_Version_Slot.UI_Lobby_Name_Version_Slot_C.OnListItemObjectSet
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x8) ]
	void OnListItemObjectSet(struct UObject* ListItemObject);

	// Object: Function UI_Lobby_Name_Version_Slot.UI_Lobby_Name_Version_Slot_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_Lobby_Name_Version_Slot.UI_Lobby_Name_Version_Slot_C.BndEvt__Btn_Action_K2Node_ComponentBoundEvent_0_OnButtonHoverEvent__DelegateSignature
	// Flags: [BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void BndEvt__Btn_Action_K2Node_ComponentBoundEvent_0_OnButtonHoverEvent__DelegateSignature();

	// Object: Function UI_Lobby_Name_Version_Slot.UI_Lobby_Name_Version_Slot_C.BndEvt__Btn_Action_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature
	// Flags: [BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void BndEvt__Btn_Action_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature();

	// Object: Function UI_Lobby_Name_Version_Slot.UI_Lobby_Name_Version_Slot_C.ExecuteUbergraph_UI_Lobby_Name_Version_Slot
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_Lobby_Name_Version_Slot(int32_t EntryPoint);
};

