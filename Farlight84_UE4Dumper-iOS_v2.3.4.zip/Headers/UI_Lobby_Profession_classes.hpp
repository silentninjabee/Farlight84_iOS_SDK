#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Lobby_Profession.UI_Lobby_Profession_C
// Inherited Bytes: 0x490 | Struct Size: 0x4d0
struct UUI_Lobby_Profession_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x490 | Size: 0x8
	struct USolarButton* Btn_Change; // Offset: 0x498 | Size: 0x8
	struct UImage* Img_Icon; // Offset: 0x4a0 | Size: 0x8
	struct UImage* img_iconBg; // Offset: 0x4a8 | Size: 0x8
	struct UImage* img_iconBorder; // Offset: 0x4b0 | Size: 0x8
	struct UImage* img_iconBorder_2; // Offset: 0x4b8 | Size: 0x8
	struct UOverlay* Overlay_2; // Offset: 0x4c0 | Size: 0x8
	bool Myself; // Offset: 0x4c8 | Size: 0x1
	enum class E_ProfessionType ProfessionType; // Offset: 0x4c9 | Size: 0x1
	char pad_0x4CA[0x2]; // Offset: 0x4ca | Size: 0x2
	int32_t Index; // Offset: 0x4cc | Size: 0x4

	// Functions

	// Object: DelegateFunction UI_Lobby_Profession.UI_Lobby_Profession_C.OnClicked_2EBDA195CD4F9078193C9398D6272CF7
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1014413c8
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_2EBDA195CD4F9078193C9398D6272CF7();

	// Object: DelegateFunction UI_Lobby_Profession.UI_Lobby_Profession_C.OnClicked_FC977D99EA4E8508C6BB9692AA3A3C0B
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1014413c8
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_FC977D99EA4E8508C6BB9692AA3A3C0B();

	// Object: DelegateFunction UI_Lobby_Profession.UI_Lobby_Profession_C.OnClicked_9DBAF933EB48AEB850AB29A1757199A4
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1014413c8
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_9DBAF933EB48AEB850AB29A1757199A4();

	// Object: DelegateFunction UI_Lobby_Profession.UI_Lobby_Profession_C.OnClicked_8C3F8C80914A172DBCF853B26AB106D6
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1014413c8
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_8C3F8C80914A172DBCF853B26AB106D6();

	// Object: Function UI_Lobby_Profession.UI_Lobby_Profession_C.Destruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x101456f90
	// Return & Params: [ Num(0) Size(0x0) ]
	void Destruct();

	// Object: Function UI_Lobby_Profession.UI_Lobby_Profession_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x101456f90
	// Return & Params: [ Num(0) Size(0x0) ]
	void Construct();

	// Object: Function UI_Lobby_Profession.UI_Lobby_Profession_C.OnInitialized
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x101456f90
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnInitialized();

	// Object: Function UI_Lobby_Profession.UI_Lobby_Profession_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();

	// Object: Function UI_Lobby_Profession.UI_Lobby_Profession_C.SetSelection
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetSelection(char Index);

	// Object: Function UI_Lobby_Profession.UI_Lobby_Profession_C.UpdateState
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void UpdateState();

	// Object: Function UI_Lobby_Profession.UI_Lobby_Profession_C.Render
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void Render();

	// Object: Function UI_Lobby_Profession.UI_Lobby_Profession_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_Lobby_Profession.UI_Lobby_Profession_C.ExecuteUbergraph_UI_Lobby_Profession
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_Lobby_Profession(int32_t EntryPoint);
};

