#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C
// Inherited Bytes: 0x490 | Struct Size: 0x5b0
struct UUI_Lobby_TeamMember_Operation_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x490 | Size: 0x8
	struct UButton* Btn_Buff; // Offset: 0x498 | Size: 0x8
	struct USolarButton* Btn_QuitTeam; // Offset: 0x4a0 | Size: 0x8
	struct USolarButton* Btn_ShowOperationPanel; // Offset: 0x4a8 | Size: 0x8
	struct USolarButton* Button_Emoji; // Offset: 0x4b0 | Size: 0x8
	struct USolarButton* Button_Emoji_Close; // Offset: 0x4b8 | Size: 0x8
	struct UUI_Component_Emoji_List_C* Emoji_List; // Offset: 0x4c0 | Size: 0x8
	struct USolarCheckBox* EmojiBtn; // Offset: 0x4c8 | Size: 0x8
	struct UImage* Img_AppDeactivated_Mark; // Offset: 0x4d0 | Size: 0x8
	struct UImage* Img_BG; // Offset: 0x4d8 | Size: 0x8
	struct UImage* Img_Buff; // Offset: 0x4e0 | Size: 0x8
	struct UImage* Img_BusinessCard_Hover; // Offset: 0x4e8 | Size: 0x8
	struct UImage* Img_Captain; // Offset: 0x4f0 | Size: 0x8
	struct UImage* Img_MicroPhone_Mark; // Offset: 0x4f8 | Size: 0x8
	struct UImage* Img_NameColor; // Offset: 0x500 | Size: 0x8
	struct UImage* Img_OpenCard; // Offset: 0x508 | Size: 0x8
	struct UImage* Img_QuitTeam_Hover; // Offset: 0x510 | Size: 0x8
	struct UOverlay* Img_Ready_Mark; // Offset: 0x518 | Size: 0x8
	struct UImage* Img_Top; // Offset: 0x520 | Size: 0x8
	struct UOverlay* Overlay_Vip; // Offset: 0x528 | Size: 0x8
	struct UCanvasPanel* Panel_Buff; // Offset: 0x530 | Size: 0x8
	struct UCanvasPanel* Panel_Captain; // Offset: 0x538 | Size: 0x8
	struct UCanvasPanel* Panel_Emoji; // Offset: 0x540 | Size: 0x8
	struct UCanvasPanel* Panel_Voice; // Offset: 0x548 | Size: 0x8
	struct USizeBox* SizeBox_2; // Offset: 0x550 | Size: 0x8
	struct USizeBox* SizeBox_Wave; // Offset: 0x558 | Size: 0x8
	struct USolarTextBlock* Text_NickName; // Offset: 0x560 | Size: 0x8
	struct UUI_Chat_Wave_C* UI_Chat_Wave; // Offset: 0x568 | Size: 0x8
	struct UUI_Component_Platform_C* UI_Component_Platform; // Offset: 0x570 | Size: 0x8
	struct UUI_Component_PlayerName_C* UI_Component_PlayerName; // Offset: 0x578 | Size: 0x8
	struct UUI_Lobby_Name_Version_C* UI_Lobby_Name_Version; // Offset: 0x580 | Size: 0x8
	struct UUI_MicroPhoneSetting_C* UI_MicroPhoneSetting; // Offset: 0x588 | Size: 0x8
	struct UUI_Rank_Icon_Small_C* UI_Rank_Icon_Small; // Offset: 0x590 | Size: 0x8
	struct UUI_Vip_Icon_Type_C* UI_Vip_Icon_Type; // Offset: 0x598 | Size: 0x8
	int32_t IndexInLobby; // Offset: 0x5a0 | Size: 0x4
	bool Steam; // Offset: 0x5a4 | Size: 0x1
	enum class E_Type_State_Button StatePlayernameHD; // Offset: 0x5a5 | Size: 0x1
	enum class E_Type_State_Button StateQuitHD; // Offset: 0x5a6 | Size: 0x1
	bool IsHD; // Offset: 0x5a7 | Size: 0x1
	bool IsHighlight; // Offset: 0x5a8 | Size: 0x1
	char pad_0x5A9[0x3]; // Offset: 0x5a9 | Size: 0x3
	int32_t Num; // Offset: 0x5ac | Size: 0x4

	// Functions

	// Object: DelegateFunction UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.OnClicked_BE7E7D5D834C974581119F87DC4A1B8C
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1014413c8
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_BE7E7D5D834C974581119F87DC4A1B8C();

	// Object: DelegateFunction UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.OnClicked_48CD5EF4134DD18B441093A6EA076524
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1014413c8
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_48CD5EF4134DD18B441093A6EA076524();

	// Object: DelegateFunction UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.OnClicked_B682F113C64B64FF7CE53A8D7EEFC29A
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1014413c8
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_B682F113C64B64FF7CE53A8D7EEFC29A();

	// Object: DelegateFunction UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.OnClicked_20D3B22B454B188D69005D91BF20B00D
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1014413c8
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_20D3B22B454B188D69005D91BF20B00D();

	// Object: DelegateFunction UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.OnClicked_A950D73C084DB54F418752AD9EEA3006
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1014413c8
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_A950D73C084DB54F418752AD9EEA3006();

	// Object: DelegateFunction UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.OnClicked_51E588E7A4424B58BB4DEF8F462791E8
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1014413c8
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_51E588E7A4424B58BB4DEF8F462791E8();

	// Object: DelegateFunction UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.OnClicked_5E95AD1A044174AB3B2BC69074652B84
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1014413c8
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_5E95AD1A044174AB3B2BC69074652B84();

	// Object: DelegateFunction UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.OnClicked_9DC3B7F38947682859FBFABAB28E0D7A
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1014413c8
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_9DC3B7F38947682859FBFABAB28E0D7A();

	// Object: DelegateFunction UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.OnClicked_643EA7159448F99A99D413945F513DF3
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1014413c8
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_643EA7159448F99A99D413945F513DF3();

	// Object: DelegateFunction UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.OnClicked_70A127F732405E5C2964098693C13116
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1014413c8
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_70A127F732405E5C2964098693C13116();

	// Object: DelegateFunction UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.OnClicked_03B298CFF34EB57A6A36068F1865DD26
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1014413c8
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_03B298CFF34EB57A6A36068F1865DD26();

	// Object: DelegateFunction UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.OnClicked_5686E3B221452DD7D35D4084EAE361DF
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1014413c8
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_5686E3B221452DD7D35D4084EAE361DF();

	// Object: DelegateFunction UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.OnCheckStateChanged_A159809679480864E7281CA546F74409
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1014413c8
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnCheckStateChanged_A159809679480864E7281CA546F74409(bool bIsChecked);

	// Object: DelegateFunction UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.OnCheckStateChanged_200C91044E4BBB53DCEDA28A8AC6ED14
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1014413c8
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnCheckStateChanged_200C91044E4BBB53DCEDA28A8AC6ED14(bool bIsChecked);

	// Object: DelegateFunction UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.OnCheckStateChanged_8056899DC64A3738039F39A58A61795E
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1014413c8
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnCheckStateChanged_8056899DC64A3738039F39A58A61795E(bool bIsChecked);

	// Object: DelegateFunction UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.OnCheckStateChanged_018588F6B84DF990415C7192438E5DCD
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1014413c8
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnCheckStateChanged_018588F6B84DF990415C7192438E5DCD(bool bIsChecked);

	// Object: Function UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.Destruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x101456f90
	// Return & Params: [ Num(0) Size(0x0) ]
	void Destruct();

	// Object: Function UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.ConstructCopy
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void ConstructCopy();

	// Object: Function UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.OnHide
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x101456f90
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnHide();

	// Object: Function UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.OnShow
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x101456f90
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnShow();

	// Object: Function UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.OnInitialized
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x101456f90
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnInitialized();

	// Object: Function UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();

	// Object: Function UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.SetIsSelf
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetIsSelf(bool IsSelf);

	// Object: Function UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.SetNameColor
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetNameColor(int32_t Num);

	// Object: Function UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.SetBuffHighlight
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetBuffHighlight(bool IsHighlight);

	// Object: Function UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.SetHD
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetHD(bool IsHD);

	// Object: Function UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.SetStateQuitHD
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetStateQuitHD(enum class E_Type_State_Button StateQuitHD);

	// Object: Function UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.SetStatePlayernameHD
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetStatePlayernameHD(enum class E_Type_State_Button StatePlayernameHD);

	// Object: Function UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x101456f90
	// Return & Params: [ Num(0) Size(0x0) ]
	void Construct();

	// Object: Function UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.ExecuteUbergraph_UI_Lobby_TeamMember_Operation
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_Lobby_TeamMember_Operation(int32_t EntryPoint);
};

