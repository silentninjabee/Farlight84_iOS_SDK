#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Lobby_Topup.UI_Lobby_Topup_C
// Inherited Bytes: 0x490 | Struct Size: 0x4b1
struct UUI_Lobby_Topup_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x490 | Size: 0x8
	struct UImage* Img_VX_Deco; // Offset: 0x498 | Size: 0x8
	struct UScaleBox* ScaleBox_1; // Offset: 0x4a0 | Size: 0x8
	struct USolarTextBlock* SolarTextBlock_64; // Offset: 0x4a8 | Size: 0x8
	enum class E_Type_State_Button StateDesktop; // Offset: 0x4b0 | Size: 0x1

	// Functions

	// Object: Function UI_Lobby_Topup.UI_Lobby_Topup_C.SetStateDesktop
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetStateDesktop(enum class E_Type_State_Button StateDesktop);

	// Object: Function UI_Lobby_Topup.UI_Lobby_Topup_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_Lobby_Topup.UI_Lobby_Topup_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void Construct();

	// Object: Function UI_Lobby_Topup.UI_Lobby_Topup_C.ExecuteUbergraph_UI_Lobby_Topup
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_Lobby_Topup(int32_t EntryPoint);
};

