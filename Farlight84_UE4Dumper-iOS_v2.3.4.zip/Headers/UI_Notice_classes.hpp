#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Notice.UI_Notice_C
// Inherited Bytes: 0x490 | Struct Size: 0x4f8
struct UUI_Notice_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x490 | Size: 0x8
	struct UWidgetAnimation* Out; // Offset: 0x498 | Size: 0x8
	struct UWidgetAnimation* In; // Offset: 0x4a0 | Size: 0x8
	struct UImage* Img_Icon_3; // Offset: 0x4a8 | Size: 0x8
	struct UImage* Img_Icon_bg_3; // Offset: 0x4b0 | Size: 0x8
	struct URichTextBlock* Text; // Offset: 0x4b8 | Size: 0x8
	struct TArray<struct FS_Notice> Queue; // Offset: 0x4c0 | Size: 0x10
	bool QueueFinished; // Offset: 0x4d0 | Size: 0x1
	char pad_0x4D1[0x7]; // Offset: 0x4d1 | Size: 0x7
	struct FS_Notice ; // Offset: 0x4d8 | Size: 0x20

	// Functions

	// Object: Function UI_Notice.UI_Notice_C.SetStyle
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x20) ]
	void SetStyle(struct FS_Notice& S_Notice);

	// Object: Function UI_Notice.UI_Notice_C.
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x20) ]
	void (struct FS_Notice& S_Notice);

	// Object: Function UI_Notice.UI_Notice_C.
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void ();

	// Object: Function UI_Notice.UI_Notice_C.
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x20) ]
	void (struct FS_Notice& S_Notice);

	// Object: Function UI_Notice.UI_Notice_C.
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x20) ]
	void (struct FS_Notice );

	// Object: Function UI_Notice.UI_Notice_C.ShowNext
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void ShowNext();

	// Object: Function UI_Notice.UI_Notice_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_Notice.UI_Notice_C.ExecuteUbergraph_UI_Notice
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_Notice(int32_t EntryPoint);
};

