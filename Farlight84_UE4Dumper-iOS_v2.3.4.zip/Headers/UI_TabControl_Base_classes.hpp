#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_TabControl_Base.UI_TabControl_Base_C
// Inherited Bytes: 0x490 | Struct Size: 0x5a9
struct UUI_TabControl_Base_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x490 | Size: 0x8
	enum class E_TabStyle Style; // Offset: 0x498 | Size: 0x1
	char pad_0x499[0x7]; // Offset: 0x499 | Size: 0x7
	struct UWidgetSwitcher* BindSwitcher; // Offset: 0x4a0 | Size: 0x8
	struct FString DefaultSelection; // Offset: 0x4a8 | Size: 0x10
	struct TMap<struct FString, struct FS_TabItem> QueryItem_base; // Offset: 0x4b8 | Size: 0x50
	struct TMap<struct FString, struct UBP_TabItemObj_C*> QueryItem; // Offset: 0x508 | Size: 0x50
	struct FMulticastInlineDelegate OnActiveTabChanged; // Offset: 0x558 | Size: 0x10
	struct UListView* BindList; // Offset: 0x568 | Size: 0x8
	struct FVector2D ItemDefaultSize; // Offset: 0x570 | Size: 0x8
	struct TArray<struct FS_TabItem> PresetItems; // Offset: 0x578 | Size: 0x10
	struct TArray<struct FS_TabItem> Items; // Offset: 0x588 | Size: 0x10
	struct FString CurrentSelection; // Offset: 0x598 | Size: 0x10
	bool IsDisableScroll; // Offset: 0x5a8 | Size: 0x1

	// Functions

	// Object: Function UI_TabControl_Base.UI_TabControl_Base_C.OnInitialized
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x101456f90
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnInitialized();

	// Object: Function UI_TabControl_Base.UI_TabControl_Base_C.Destruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x101456f90
	// Return & Params: [ Num(0) Size(0x0) ]
	void Destruct();

	// Object: Function UI_TabControl_Base.UI_TabControl_Base_C.OnDeinitialize
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x101456f90
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnDeinitialize();

	// Object: Function UI_TabControl_Base.UI_TabControl_Base_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();

	// Object: Function UI_TabControl_Base.UI_TabControl_Base_C.SetSelectedIndexPrev
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void SetSelectedIndexPrev();

	// Object: Function UI_TabControl_Base.UI_TabControl_Base_C.SetSelectedIndexNext
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void SetSelectedIndexNext();

	// Object: Function UI_TabControl_Base.UI_TabControl_Base_C.AddItemByItemData
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(2) Size(0x59) ]
	void AddItemByItemData(struct FS_TabItem TabData, bool& Success);

	// Object: Function UI_TabControl_Base.UI_TabControl_Base_C.AddSizedItem
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(7) Size(0x49) ]
	void AddSizedItem(struct FString Key, struct FString Text, struct UObject* Icon, struct FS_HintData HintDotData, struct UWidget* LinkWidget, struct FVector2D Szie, bool& Success);

	// Object: Function UI_TabControl_Base.UI_TabControl_Base_C.ReviseItem
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(6) Size(0x41) ]
	void ReviseItem(struct FString Key, struct FString Text, struct UObject* Icon, struct FS_HintData HintDotData, struct UWidget* LinkWidget, bool& Success);

	// Object: Function UI_TabControl_Base.UI_TabControl_Base_C.RefreshAllItems
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void RefreshAllItems();

	// Object: Function UI_TabControl_Base.UI_TabControl_Base_C.InsertItem
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(6) Size(0x48) ]
	void InsertItem(int32_t Index, struct FString Key, struct FString Text, struct UObject* Icon, struct FS_HintData HintDotData, struct UWidget* LinkWidget);

	// Object: Function UI_TabControl_Base.UI_TabControl_Base_C.AddItemByPreset
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x58) ]
	void AddItemByPreset(struct FS_TabItem& S_TabItem);

	// Object: Function UI_TabControl_Base.UI_TabControl_Base_C.BindChildWidget
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void BindChildWidget();

	// Object: Function UI_TabControl_Base.UI_TabControl_Base_C.SetBindWidget
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetBindWidget(struct UListView*& BindList);

	// Object: Function UI_TabControl_Base.UI_TabControl_Base_C.ScrollToItem
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(3) Size(0x18) ]
	void ScrollToItem(struct FString Key, bool Active, float InScrollOffset);

	// Object: Function UI_TabControl_Base.UI_TabControl_Base_C.ClearItems
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void ClearItems();

	// Object: Function UI_TabControl_Base.UI_TabControl_Base_C.SetStyle
	// Flags: [Private|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void SetStyle();

	// Object: Function UI_TabControl_Base.UI_TabControl_Base_C.GetKeys
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x10) ]
	void GetKeys(struct TArray<struct FString>& Keys);

	// Object: Function UI_TabControl_Base.UI_TabControl_Base_C.AddPresetItem
	// Flags: [Private|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void AddPresetItem();

	// Object: Function UI_TabControl_Base.UI_TabControl_Base_C.SetActiveTab
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(2) Size(0x11) ]
	void SetActiveTab(struct FString Key, bool& Success);

	// Object: Function UI_TabControl_Base.UI_TabControl_Base_C.GetLinkedWidgetByKey
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetLinkedWidgetByKey(struct FString Key, struct UWidget*& Widget);

	// Object: Function UI_TabControl_Base.UI_TabControl_Base_C.RemoveItem
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(2) Size(0x11) ]
	void RemoveItem(struct FString Key, bool& Success);

	// Object: Function UI_TabControl_Base.UI_TabControl_Base_C.AddItem
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(6) Size(0x41) ]
	void AddItem(struct FString Key, struct FString Text, struct UObject* Icon, struct FS_HintData HintDotData, struct UWidget* LinkWidget, bool& Success);

	// Object: Function UI_TabControl_Base.UI_TabControl_Base_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_TabControl_Base.UI_TabControl_Base_C.OnItemClicked
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x8) ]
	void OnItemClicked(struct UObject* Item);

	// Object: Function UI_TabControl_Base.UI_TabControl_Base_C.OnItemSelected
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(2) Size(0x9) ]
	void OnItemSelected(struct UObject* Item, bool bIsSelected);

	// Object: Function UI_TabControl_Base.UI_TabControl_Base_C.BP_OnItemIsHoveredChanged_Event
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(2) Size(0x9) ]
	void BP_OnItemIsHoveredChanged_Event(struct UObject* Item, bool bIsHovered);

	// Object: Function UI_TabControl_Base.UI_TabControl_Base_C.ExecuteUbergraph_UI_TabControl_Base
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_TabControl_Base(int32_t EntryPoint);

	// Object: Function UI_TabControl_Base.UI_TabControl_Base_C.OnActiveTabChanged__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(2) Size(0x14) ]
	void OnActiveTabChanged__DelegateSignature(struct FString Key, int32_t Index);
};

