#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_TabControl_Horizontal_Slot.UI_TabControl_Horizontal_Slot_C
// Inherited Bytes: 0x509 | Struct Size: 0x561
struct UUI_TabControl_Horizontal_Slot_C : UBP_Tab_ItemBase_C {
	// Fields
	char pad_0x509[0x7]; // Offset: 0x509 | Size: 0x7
	struct UImage* Img_BG; // Offset: 0x510 | Size: 0x8
	struct UImage* Img_Icon; // Offset: 0x518 | Size: 0x8
	struct UImage* Img_Line; // Offset: 0x520 | Size: 0x8
	struct UImage* Img_VerticalLine; // Offset: 0x528 | Size: 0x8
	struct UScaleBox* ScaleBox_1Line; // Offset: 0x530 | Size: 0x8
	struct USizeBox* SizeBox_Icon; // Offset: 0x538 | Size: 0x8
	struct USizeBox* SizeBox_SecendTab; // Offset: 0x540 | Size: 0x8
	struct USolarRedHint_General_C* Solar_RedHintPoint; // Offset: 0x548 | Size: 0x8
	struct USolarTextBlock* Txt_Tap; // Offset: 0x550 | Size: 0x8
	struct FVector2D SizeMin; // Offset: 0x558 | Size: 0x8
	bool IsFrist; // Offset: 0x560 | Size: 0x1

	// Functions

	// Object: Function UI_TabControl_Horizontal_Slot.UI_TabControl_Horizontal_Slot_C.InitWidget
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(3) Size(0x18) ]
	void InitWidget(struct USolarRedHint_General_C*& HintWidget, struct USolarTextBlock*& Text, struct UImage*& Icon);

	// Object: Function UI_TabControl_Horizontal_Slot.UI_TabControl_Horizontal_Slot_C.SetStyle
	// Flags: [Protected|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetStyle(enum class E_TabStyle Style);

	// Object: Function UI_TabControl_Horizontal_Slot.UI_TabControl_Horizontal_Slot_C.SetSelected
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetSelected(bool IsSelected);
};

