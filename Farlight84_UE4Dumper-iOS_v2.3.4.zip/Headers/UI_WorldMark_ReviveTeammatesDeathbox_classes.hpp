#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_WorldMark_ReviveTeammatesDeathbox.UI_WorldMark_ReviveTeammatesDeathbox_C
// Inherited Bytes: 0x550 | Struct Size: 0x5d8
struct UUI_WorldMark_ReviveTeammatesDeathbox_C : UActorMarkBase {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x550 | Size: 0x8
	struct UTextBlock* Distance; // Offset: 0x558 | Size: 0x8
	struct UImage* Img_BG; // Offset: 0x560 | Size: 0x8
	struct UImage* Img_Light; // Offset: 0x568 | Size: 0x8
	struct UImage* Img_Light_2; // Offset: 0x570 | Size: 0x8
	struct UImage* Img_Revival; // Offset: 0x578 | Size: 0x8
	struct UVerticalBox* Panel; // Offset: 0x580 | Size: 0x8
	struct UScaleBox* ScaleBox_1; // Offset: 0x588 | Size: 0x8
	int32_t HideDistance; // Offset: 0x590 | Size: 0x4
	char pad_0x594[0x4]; // Offset: 0x594 | Size: 0x4
	struct TArray<struct FLinearColor> Color_2; // Offset: 0x598 | Size: 0x10
	struct TArray<struct FLinearColor> Color_3; // Offset: 0x5a8 | Size: 0x10
	struct FString PlayerId; // Offset: 0x5b8 | Size: 0x10
	struct FString DistanceLocalString; // Offset: 0x5c8 | Size: 0x10

	// Functions

	// Object: Function UI_WorldMark_ReviveTeammatesDeathbox.UI_WorldMark_ReviveTeammatesDeathbox_C.Set Player ID And Change Color
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x10) ]
	void Set Player ID And Change Color(struct FString PlayerId);

	// Object: Function UI_WorldMark_ReviveTeammatesDeathbox.UI_WorldMark_ReviveTeammatesDeathbox_C.SetColor
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetColor(char Index);

	// Object: Function UI_WorldMark_ReviveTeammatesDeathbox.UI_WorldMark_ReviveTeammatesDeathbox_C.GetVisibility_1
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class ESlateVisibility GetVisibility_1();

	// Object: Function UI_WorldMark_ReviveTeammatesDeathbox.UI_WorldMark_ReviveTeammatesDeathbox_C.Get_Distance_Text
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x18) ]
	struct FText Get_Distance_Text();

	// Object: Function UI_WorldMark_ReviveTeammatesDeathbox.UI_WorldMark_ReviveTeammatesDeathbox_C.SetIcon
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(2) Size(0xc) ]
	void SetIcon(struct UWidget* Content, int32_t );

	// Object: Function UI_WorldMark_ReviveTeammatesDeathbox.UI_WorldMark_ReviveTeammatesDeathbox_C.Tick
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(2) Size(0x3c) ]
	void Tick(struct FGeometry MyGeometry, float InDeltaTime);

	// Object: Function UI_WorldMark_ReviveTeammatesDeathbox.UI_WorldMark_ReviveTeammatesDeathbox_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_WorldMark_ReviveTeammatesDeathbox.UI_WorldMark_ReviveTeammatesDeathbox_C.OnInitialized
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnInitialized();

	// Object: Function UI_WorldMark_ReviveTeammatesDeathbox.UI_WorldMark_ReviveTeammatesDeathbox_C.ExecuteUbergraph_UI_WorldMark_ReviveTeammatesDeathbox
	// Flags: [Final|UbergraphFunction|HasDefaults]
	// Offset: 0x103dfd478
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_WorldMark_ReviveTeammatesDeathbox(int32_t EntryPoint);
};

