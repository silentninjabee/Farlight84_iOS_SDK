#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass WAT_WL05.WAT_WL05_C
// Inherited Bytes: 0xe8 | Struct Size: 0xe8
struct UWAT_WL05_C : USolarWeaponAT_FireBurst {
};

