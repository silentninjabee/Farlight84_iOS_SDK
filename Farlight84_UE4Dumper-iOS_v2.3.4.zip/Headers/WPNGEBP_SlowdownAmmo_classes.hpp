#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass WPNGEBP_SlowdownAmmo.WPNGEBP_SlowdownAmmo_C
// Inherited Bytes: 0x878 | Struct Size: 0x878
struct UWPNGEBP_SlowdownAmmo_C : UGameplayEffect {
};

