#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class ActorSequence.ActorSequence
// Inherited Bytes: 0x348 | Struct Size: 0x370
struct UActorSequence : UMovieSceneSequence {
	// Fields
	struct UMovieScene* MovieScene; // Offset: 0x348 | Size: 0x8
	struct FActorSequenceObjectReferenceMap ObjectReferences; // Offset: 0x350 | Size: 0x20
};

// Object: Class ActorSequence.ActorSequenceComponent
// Inherited Bytes: 0xb0 | Struct Size: 0xd8
struct UActorSequenceComponent : UActorComponent {
	// Fields
	struct FMovieSceneSequencePlaybackSettings PlaybackSettings; // Offset: 0xb0 | Size: 0x14
	char pad_0xC4[0x4]; // Offset: 0xc4 | Size: 0x4
	struct UActorSequence* Sequence; // Offset: 0xc8 | Size: 0x8
	struct UActorSequencePlayer* SequencePlayer; // Offset: 0xd0 | Size: 0x8
};

// Object: Class ActorSequence.ActorSequencePlayer
// Inherited Bytes: 0x888 | Struct Size: 0x888
struct UActorSequencePlayer : UMovieSceneSequencePlayer {
};

