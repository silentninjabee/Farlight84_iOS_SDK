#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class AnimGraphRuntime.AnimSequencerInstance
// Inherited Bytes: 0x270 | Struct Size: 0x270
struct UAnimSequencerInstance : UAnimInstance {
};

// Object: Class AnimGraphRuntime.AnimNotify_PlayMontageNotify
// Inherited Bytes: 0x38 | Struct Size: 0x40
struct UAnimNotify_PlayMontageNotify : UAnimNotify {
	// Fields
	struct FName NotifyName; // Offset: 0x38 | Size: 0x8
};

// Object: Class AnimGraphRuntime.AnimNotify_PlayMontageNotifyWindow
// Inherited Bytes: 0x30 | Struct Size: 0x38
struct UAnimNotify_PlayMontageNotifyWindow : UAnimNotifyState {
	// Fields
	struct FName NotifyName; // Offset: 0x2c | Size: 0x8
};

// Object: Class AnimGraphRuntime.KismetAnimationLibrary
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UKismetAnimationLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object: Function AnimGraphRuntime.KismetAnimationLibrary.K2_TwoBoneIK
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x1048ad44c
	// Return & Params: [ Num(10) Size(0x60) ]
	void K2_TwoBoneIK(struct FVector& RootPos, struct FVector& JointPos, struct FVector& EndPos, struct FVector& JointTarget, struct FVector& Effector, struct FVector& OutJointPos, struct FVector& OutEndPos, bool bAllowStretching, float StartStretchRatio, float MaxStretchScale);

	// Object: Function AnimGraphRuntime.KismetAnimationLibrary.K2_StartProfilingTimer
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1048ac318
	// Return & Params: [ Num(0) Size(0x0) ]
	void K2_StartProfilingTimer();

	// Object: Function AnimGraphRuntime.KismetAnimationLibrary.K2_MakePerlinNoiseVectorAndRemap
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x1048aca94
	// Return & Params: [ Num(10) Size(0x30) ]
	struct FVector K2_MakePerlinNoiseVectorAndRemap(float X, float Y, float Z, float RangeOutMinX, float RangeOutMaxX, float RangeOutMinY, float RangeOutMaxY, float RangeOutMinZ, float RangeOutMaxZ);

	// Object: Function AnimGraphRuntime.KismetAnimationLibrary.K2_MakePerlinNoiseAndRemap
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1048ac980
	// Return & Params: [ Num(4) Size(0x10) ]
	float K2_MakePerlinNoiseAndRemap(float Value, float RangeOutMin, float RangeOutMax);

	// Object: Function AnimGraphRuntime.KismetAnimationLibrary.K2_LookAt
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x1048ad1bc
	// Return & Params: [ Num(7) Size(0x90) ]
	struct FTransform K2_LookAt(struct FTransform& CurrentTransform, struct FVector& TargetPosition, struct FVector LookAtVector, bool bUseUpVector, struct FVector UpVector, float ClampConeInDegree);

	// Object: Function AnimGraphRuntime.KismetAnimationLibrary.K2_EndProfilingTimer
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1048ac22c
	// Return & Params: [ Num(3) Size(0x1c) ]
	float K2_EndProfilingTimer(bool bLog, struct FString LogPrefix);

	// Object: Function AnimGraphRuntime.KismetAnimationLibrary.K2_DistanceBetweenTwoSocketsAndMapRange
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1048ace84
	// Return & Params: [ Num(11) Size(0x34) ]
	float K2_DistanceBetweenTwoSocketsAndMapRange(struct USkeletalMeshComponent* Component, struct FName SocketOrBoneNameA, enum class ERelativeTransformSpace SocketSpaceA, struct FName SocketOrBoneNameB, enum class ERelativeTransformSpace SocketSpaceB, bool bRemapRange, float InRangeMin, float InRangeMax, float OutRangeMin, float OutRangeMax);

	// Object: Function AnimGraphRuntime.KismetAnimationLibrary.K2_DirectionBetweenSockets
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x1048acd6c
	// Return & Params: [ Num(4) Size(0x24) ]
	struct FVector K2_DirectionBetweenSockets(struct USkeletalMeshComponent* Component, struct FName SocketOrBoneNameFrom, struct FName SocketOrBoneNameTo);

	// Object: Function AnimGraphRuntime.KismetAnimationLibrary.K2_CalculateVelocityFromSockets
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1048ac32c
	// Return & Params: [ Num(13) Size(0xfc) ]
	float K2_CalculateVelocityFromSockets(float DeltaSeconds, struct USkeletalMeshComponent* Component, struct FName SocketOrBoneName, struct FName ReferenceSocketOrBone, enum class ERelativeTransformSpace SocketSpace, struct FVector OffsetInBoneSpace, struct FPositionHistory& History, int32_t NumberOfSamples, float VelocityMin, float VelocityMax, enum class EEasingFuncType EasingType, struct FRuntimeFloatCurve& CustomCurve);

	// Object: Function AnimGraphRuntime.KismetAnimationLibrary.K2_CalculateVelocityFromPositionHistory
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1048ac76c
	// Return & Params: [ Num(7) Size(0x50) ]
	float K2_CalculateVelocityFromPositionHistory(float DeltaSeconds, struct FVector Position, struct FPositionHistory& History, int32_t NumberOfSamples, float VelocityMin, float VelocityMax);
};

// Object: Class AnimGraphRuntime.PlayMontageCallbackProxy
// Inherited Bytes: 0x28 | Struct Size: 0xa8
struct UPlayMontageCallbackProxy : UObject {
	// Fields
	struct FMulticastInlineDelegate OnCompleted; // Offset: 0x28 | Size: 0x10
	struct FMulticastInlineDelegate OnBlendOut; // Offset: 0x38 | Size: 0x10
	struct FMulticastInlineDelegate OnInterrupted; // Offset: 0x48 | Size: 0x10
	struct FMulticastInlineDelegate OnNotifyBegin; // Offset: 0x58 | Size: 0x10
	struct FMulticastInlineDelegate OnNotifyEnd; // Offset: 0x68 | Size: 0x10
	char pad_0x78[0x30]; // Offset: 0x78 | Size: 0x30

	// Functions

	// Object: Function AnimGraphRuntime.PlayMontageCallbackProxy.OnNotifyEndReceived
	// Flags: [Final|Native|Protected|HasOutParms]
	// Offset: 0x1048addf4
	// Return & Params: [ Num(2) Size(0x28) ]
	void OnNotifyEndReceived(struct FName NotifyName, struct FBranchingPointNotifyPayload& BranchingPointNotifyPayload);

	// Object: Function AnimGraphRuntime.PlayMontageCallbackProxy.OnNotifyBeginReceived
	// Flags: [Final|Native|Protected|HasOutParms]
	// Offset: 0x1048adecc
	// Return & Params: [ Num(2) Size(0x28) ]
	void OnNotifyBeginReceived(struct FName NotifyName, struct FBranchingPointNotifyPayload& BranchingPointNotifyPayload);

	// Object: Function AnimGraphRuntime.PlayMontageCallbackProxy.OnMontageEnded
	// Flags: [Final|Native|Protected]
	// Offset: 0x1048adfa4
	// Return & Params: [ Num(2) Size(0x9) ]
	void OnMontageEnded(struct UAnimMontage* Montage, bool bInterrupted);

	// Object: Function AnimGraphRuntime.PlayMontageCallbackProxy.OnMontageBlendingOut
	// Flags: [Final|Native|Protected]
	// Offset: 0x1048ae078
	// Return & Params: [ Num(2) Size(0x9) ]
	void OnMontageBlendingOut(struct UAnimMontage* Montage, bool bInterrupted);

	// Object: Function AnimGraphRuntime.PlayMontageCallbackProxy.CreateProxyObjectForPlayMontage
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1048ae14c
	// Return & Params: [ Num(6) Size(0x28) ]
	struct UPlayMontageCallbackProxy* CreateProxyObjectForPlayMontage(struct USkeletalMeshComponent* InSkeletalMeshComponent, struct UAnimMontage* MontageToPlay, float PlayRate, float StartingPosition, struct FName StartingSection);
};

// Object: Class AnimGraphRuntime.SequencerAnimationSupport
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct USequencerAnimationSupport : UInterface {
};

