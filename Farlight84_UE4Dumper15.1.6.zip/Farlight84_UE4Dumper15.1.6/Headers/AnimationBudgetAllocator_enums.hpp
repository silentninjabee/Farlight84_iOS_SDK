#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Enum AnimationBudgetAllocator.ESkeletalMeshAnimDetailMode
enum class ESkeletalMeshAnimDetailMode : uint8_t {
	SMADM_Low = 0,
	SMADM_Medium = 1,
	SMADM_High = 2,
	SMADM_MAX = 3
};

