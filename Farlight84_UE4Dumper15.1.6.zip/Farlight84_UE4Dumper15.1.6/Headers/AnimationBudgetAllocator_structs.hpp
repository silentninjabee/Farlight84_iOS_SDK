#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct AnimationBudgetAllocator.AnimationBudgetAllocatorParameters
// Inherited Bytes: 0x0 | Struct Size: 0x54
struct FAnimationBudgetAllocatorParameters {
	// Fields
	float BudgetInMs; // Offset: 0x0 | Size: 0x4
	float MinQuality; // Offset: 0x4 | Size: 0x4
	int32_t MaxTickRate; // Offset: 0x8 | Size: 0x4
	float WorkUnitSmoothingSpeed; // Offset: 0xc | Size: 0x4
	float AlwaysTickFalloffAggression; // Offset: 0x10 | Size: 0x4
	float InterpolationFalloffAggression; // Offset: 0x14 | Size: 0x4
	int32_t InterpolationMaxRate; // Offset: 0x18 | Size: 0x4
	int32_t MaxInterpolatedComponents; // Offset: 0x1c | Size: 0x4
	float InterpolationTickMultiplier; // Offset: 0x20 | Size: 0x4
	float InitialEstimatedWorkUnitTimeMs; // Offset: 0x24 | Size: 0x4
	int32_t MaxTickedOffsreenComponents; // Offset: 0x28 | Size: 0x4
	int32_t StateChangeThrottleInFrames; // Offset: 0x2c | Size: 0x4
	float BudgetFactorBeforeReducedWork; // Offset: 0x30 | Size: 0x4
	float BudgetFactorBeforeReducedWorkEpsilon; // Offset: 0x34 | Size: 0x4
	float BudgetPressureSmoothingSpeed; // Offset: 0x38 | Size: 0x4
	int32_t ReducedWorkThrottleMinInFrames; // Offset: 0x3c | Size: 0x4
	int32_t ReducedWorkThrottleMaxInFrames; // Offset: 0x40 | Size: 0x4
	float BudgetFactorBeforeAggressiveReducedWork; // Offset: 0x44 | Size: 0x4
	int32_t ReducedWorkThrottleMaxPerFrame; // Offset: 0x48 | Size: 0x4
	float BudgetPressureBeforeEmergencyReducedWork; // Offset: 0x4c | Size: 0x4
	float AlwaysTickSignificanceThreshold; // Offset: 0x50 | Size: 0x4
};

