#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct AnimationSharing.TickAnimationSharingFunction
// Inherited Bytes: 0x28 | Struct Size: 0x30
struct FTickAnimationSharingFunction : FTickFunction {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
};

// Object: ScriptStruct AnimationSharing.AnimationSharingScalability
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FAnimationSharingScalability {
	// Fields
	struct FPerPlatformBool UseBlendTransitions; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	struct FPerPlatformFloat BlendSignificanceValue; // Offset: 0x4 | Size: 0x4
	struct FPerPlatformInt MaximumNumberConcurrentBlends; // Offset: 0x8 | Size: 0x4
	struct FPerPlatformFloat TickSignificanceValue; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct AnimationSharing.PerSkeletonAnimationSharingSetup
// Inherited Bytes: 0x0 | Struct Size: 0x38
struct FPerSkeletonAnimationSharingSetup {
	// Fields
	struct USkeleton* Skeleton; // Offset: 0x0 | Size: 0x8
	struct USkeletalMesh* SkeletalMesh; // Offset: 0x8 | Size: 0x8
	struct UAnimSharingTransitionInstance* BlendAnimBlueprint; // Offset: 0x10 | Size: 0x8
	struct UAnimSharingAdditiveInstance* AdditiveAnimBlueprint; // Offset: 0x18 | Size: 0x8
	struct UAnimationSharingStateProcessor* StateProcessorClass; // Offset: 0x20 | Size: 0x8
	struct TArray<struct FAnimationStateEntry> AnimationStates; // Offset: 0x28 | Size: 0x10
};

// Object: ScriptStruct AnimationSharing.AnimationStateEntry
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FAnimationStateEntry {
	// Fields
	char State; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x7]; // Offset: 0x1 | Size: 0x7
	struct TArray<struct FAnimationSetup> AnimationSetups; // Offset: 0x8 | Size: 0x10
	bool bOnDemand; // Offset: 0x18 | Size: 0x1
	bool bAdditive; // Offset: 0x19 | Size: 0x1
	char pad_0x1A[0x2]; // Offset: 0x1a | Size: 0x2
	float BlendTime; // Offset: 0x1c | Size: 0x4
	bool bReturnToPreviousState; // Offset: 0x20 | Size: 0x1
	bool bSetNextState; // Offset: 0x21 | Size: 0x1
	char NextState; // Offset: 0x22 | Size: 0x1
	char pad_0x23[0x1]; // Offset: 0x23 | Size: 0x1
	struct FPerPlatformInt MaximumNumberOfConcurrentInstances; // Offset: 0x24 | Size: 0x4
	float WiggleTimePercentage; // Offset: 0x28 | Size: 0x4
	bool bRequiresCurves; // Offset: 0x2c | Size: 0x1
	char pad_0x2D[0x3]; // Offset: 0x2d | Size: 0x3
};

// Object: ScriptStruct AnimationSharing.AnimationSetup
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FAnimationSetup {
	// Fields
	struct UAnimSequence* AnimSequence; // Offset: 0x0 | Size: 0x8
	struct UAnimSharingStateInstance* AnimBlueprint; // Offset: 0x8 | Size: 0x8
	struct FPerPlatformInt NumRandomizedInstances; // Offset: 0x10 | Size: 0x4
	struct FPerPlatformBool Enabled; // Offset: 0x14 | Size: 0x1
	char pad_0x15[0x3]; // Offset: 0x15 | Size: 0x3
};

