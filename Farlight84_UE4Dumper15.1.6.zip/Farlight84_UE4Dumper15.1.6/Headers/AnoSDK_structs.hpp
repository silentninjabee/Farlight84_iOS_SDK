#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct AnoSDK.AnoSDKAntiData
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FAnoSDKAntiData {
	// Fields
	int32_t Length; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct FString AntiData; // Offset: 0x8 | Size: 0x10
};

