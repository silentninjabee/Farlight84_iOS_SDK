#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class AssetTags.AssetTagsSubsystem
// Inherited Bytes: 0x30 | Struct Size: 0x30
struct UAssetTagsSubsystem : UEngineSubsystem {
	// Functions

	// Object: Function AssetTags.AssetTagsSubsystem.GetCollectionsContainingAssetPtr
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10253e514
	// Return & Params: [ Num(2) Size(0x18) ]
	struct TArray<struct FName> GetCollectionsContainingAssetPtr(struct UObject* AssetPtr);

	// Object: Function AssetTags.AssetTagsSubsystem.GetCollectionsContainingAssetData
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10253e5ec
	// Return & Params: [ Num(2) Size(0x60) ]
	struct TArray<struct FName> GetCollectionsContainingAssetData(struct FAssetData& AssetData);

	// Object: Function AssetTags.AssetTagsSubsystem.GetCollectionsContainingAsset
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10253e730
	// Return & Params: [ Num(2) Size(0x18) ]
	struct TArray<struct FName> GetCollectionsContainingAsset(struct FName AssetPathName);

	// Object: Function AssetTags.AssetTagsSubsystem.GetCollections
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10253ea04
	// Return & Params: [ Num(1) Size(0x10) ]
	struct TArray<struct FName> GetCollections();

	// Object: Function AssetTags.AssetTagsSubsystem.GetAssetsInCollection
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10253e808
	// Return & Params: [ Num(2) Size(0x18) ]
	struct TArray<struct FAssetData> GetAssetsInCollection(struct FName Name);

	// Object: Function AssetTags.AssetTagsSubsystem.CollectionExists
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10253ea84
	// Return & Params: [ Num(2) Size(0x9) ]
	bool CollectionExists(struct FName Name);
};

