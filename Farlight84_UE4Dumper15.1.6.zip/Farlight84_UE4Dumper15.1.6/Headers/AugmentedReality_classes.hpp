#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class AugmentedReality.ARBlueprintLibrary
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UARBlueprintLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object: Function AugmentedReality.ARBlueprintLibrary.UnpinComponent
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10413e458
	// Return & Params: [ Num(1) Size(0x8) ]
	void UnpinComponent(struct USceneComponent* ComponentToUnpin);

	// Object: Function AugmentedReality.ARBlueprintLibrary.StopARSession
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10413f5d0
	// Return & Params: [ Num(0) Size(0x0) ]
	void StopARSession();

	// Object: Function AugmentedReality.ARBlueprintLibrary.StartARSession
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10413f5f8
	// Return & Params: [ Num(1) Size(0x8) ]
	void StartARSession(struct UARSessionConfig* SessionConfig);

	// Object: Function AugmentedReality.ARBlueprintLibrary.SetAlignmentTransform
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10413f434
	// Return & Params: [ Num(1) Size(0x30) ]
	void SetAlignmentTransform(struct FTransform& InAlignmentTransform);

	// Object: Function AugmentedReality.ARBlueprintLibrary.RemovePin
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10413e3e0
	// Return & Params: [ Num(1) Size(0x8) ]
	void RemovePin(struct UARPin* PinToRemove);

	// Object: Function AugmentedReality.ARBlueprintLibrary.PinComponentToTraceResult
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10413e4d0
	// Return & Params: [ Num(4) Size(0x80) ]
	struct UARPin* PinComponentToTraceResult(struct USceneComponent* ComponentToPin, struct FARTraceResult& TraceResult, struct FName DebugName);

	// Object: Function AugmentedReality.ARBlueprintLibrary.PinComponent
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10413e67c
	// Return & Params: [ Num(5) Size(0x58) ]
	struct UARPin* PinComponent(struct USceneComponent* ComponentToPin, struct FTransform& PinToWorldTransform, struct UARTrackedGeometry* TrackedGeometry, struct FName DebugName);

	// Object: Function AugmentedReality.ARBlueprintLibrary.PauseARSession
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10413f5e4
	// Return & Params: [ Num(0) Size(0x0) ]
	void PauseARSession();

	// Object: Function AugmentedReality.ARBlueprintLibrary.LineTraceTrackedObjects3D
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x10413ed80
	// Return & Params: [ Num(7) Size(0x30) ]
	struct TArray<struct FARTraceResult> LineTraceTrackedObjects3D(struct FVector Start, struct FVector End, bool bTestFeaturePoints, bool bTestGroundPlane, bool bTestPlaneExtents, bool bTestPlaneBoundaryPolygon);

	// Object: Function AugmentedReality.ARBlueprintLibrary.LineTraceTrackedObjects
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x10413f100
	// Return & Params: [ Num(6) Size(0x20) ]
	struct TArray<struct FARTraceResult> LineTraceTrackedObjects(struct FVector2D ScreenCoord, bool bTestFeaturePoints, bool bTestGroundPlane, bool bTestPlaneExtents, bool bTestPlaneBoundaryPolygon);

	// Object: Function AugmentedReality.ARBlueprintLibrary.IsSessionTypeSupported
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x10413ebb0
	// Return & Params: [ Num(2) Size(0x2) ]
	bool IsSessionTypeSupported(enum class EARSessionType SessionType);

	// Object: Function AugmentedReality.ARBlueprintLibrary.IsSessionTrackingFeatureSupported
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x10413dc88
	// Return & Params: [ Num(3) Size(0x3) ]
	bool IsSessionTrackingFeatureSupported(enum class EARSessionType SessionType, enum class EARSessionTrackingFeature SessionTrackingFeature);

	// Object: Function AugmentedReality.ARBlueprintLibrary.IsARSupported
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10413f670
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsARSupported();

	// Object: Function AugmentedReality.ARBlueprintLibrary.GetWorldMappingStatus
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x10413e064
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class EARWorldMappingState GetWorldMappingStatus();

	// Object: Function AugmentedReality.ARBlueprintLibrary.GetTrackingQualityReason
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x10413ed18
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class EARTrackingQualityReason GetTrackingQualityReason();

	// Object: Function AugmentedReality.ARBlueprintLibrary.GetTrackingQuality
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x10413ed4c
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class EARTrackingQuality GetTrackingQuality();

	// Object: Function AugmentedReality.ARBlueprintLibrary.GetSupportedVideoFormats
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10413df20
	// Return & Params: [ Num(2) Size(0x18) ]
	struct TArray<struct FARVideoFormat> GetSupportedVideoFormats(enum class EARSessionType SessionType);

	// Object: Function AugmentedReality.ARBlueprintLibrary.GetSessionConfig
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x10413f50c
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UARSessionConfig* GetSessionConfig();

	// Object: Function AugmentedReality.ARBlueprintLibrary.GetPointCloud
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x10413dfe4
	// Return & Params: [ Num(1) Size(0x10) ]
	struct TArray<struct FVector> GetPointCloud();

	// Object: Function AugmentedReality.ARBlueprintLibrary.GetPersonSegmentationImage
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10413da80
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UARTextureCameraImage* GetPersonSegmentationImage();

	// Object: Function AugmentedReality.ARBlueprintLibrary.GetPersonSegmentationDepthImage
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10413da4c
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UARTextureCameraImage* GetPersonSegmentationDepthImage();

	// Object: Function AugmentedReality.ARBlueprintLibrary.GetCurrentLightEstimate
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x10413e83c
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UARLightEstimate* GetCurrentLightEstimate();

	// Object: Function AugmentedReality.ARBlueprintLibrary.GetCameraImage
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10413ec64
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UARTextureCameraImage* GetCameraImage();

	// Object: Function AugmentedReality.ARBlueprintLibrary.GetCameraDepth
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10413ec30
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UARTextureCameraDepth* GetCameraDepth();

	// Object: Function AugmentedReality.ARBlueprintLibrary.GetARSessionStatus
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x10413f540
	// Return & Params: [ Num(1) Size(0x18) ]
	struct FARSessionStatus GetARSessionStatus();

	// Object: Function AugmentedReality.ARBlueprintLibrary.GetAllTrackedPoses
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10413dab4
	// Return & Params: [ Num(1) Size(0x10) ]
	struct TArray<struct UARTrackedPose*> GetAllTrackedPoses();

	// Object: Function AugmentedReality.ARBlueprintLibrary.GetAllTrackedPoints
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10413e260
	// Return & Params: [ Num(1) Size(0x10) ]
	struct TArray<struct UARTrackedPoint*> GetAllTrackedPoints();

	// Object: Function AugmentedReality.ARBlueprintLibrary.GetAllTrackedPlanes
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10413e2e0
	// Return & Params: [ Num(1) Size(0x10) ]
	struct TArray<struct UARPlaneGeometry*> GetAllTrackedPlanes();

	// Object: Function AugmentedReality.ARBlueprintLibrary.GetAllTrackedImages
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10413e1e0
	// Return & Params: [ Num(1) Size(0x10) ]
	struct TArray<struct UARTrackedImage*> GetAllTrackedImages();

	// Object: Function AugmentedReality.ARBlueprintLibrary.GetAllTrackedEnvironmentCaptureProbes
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10413e160
	// Return & Params: [ Num(1) Size(0x10) ]
	struct TArray<struct UAREnvironmentCaptureProbe*> GetAllTrackedEnvironmentCaptureProbes();

	// Object: Function AugmentedReality.ARBlueprintLibrary.GetAllTracked2DPoses
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10413db34
	// Return & Params: [ Num(1) Size(0x10) ]
	struct TArray<struct FARPose2D> GetAllTracked2DPoses();

	// Object: Function AugmentedReality.ARBlueprintLibrary.GetAllPins
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10413e360
	// Return & Params: [ Num(1) Size(0x10) ]
	struct TArray<struct UARPin*> GetAllPins();

	// Object: Function AugmentedReality.ARBlueprintLibrary.GetAllGeometries
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10413ec98
	// Return & Params: [ Num(1) Size(0x10) ]
	struct TArray<struct UARTrackedGeometry*> GetAllGeometries();

	// Object: Function AugmentedReality.ARBlueprintLibrary.DebugDrawTrackedGeometry
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x10413ea10
	// Return & Params: [ Num(5) Size(0x28) ]
	void DebugDrawTrackedGeometry(struct UARTrackedGeometry* TrackedGeometry, struct UObject* WorldContextObject, struct FLinearColor Color, float OutlineThickness, float PersistForSeconds);

	// Object: Function AugmentedReality.ARBlueprintLibrary.DebugDrawPin
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x10413e870
	// Return & Params: [ Num(5) Size(0x28) ]
	void DebugDrawPin(struct UARPin* ARPin, struct UObject* WorldContextObject, struct FLinearColor Color, float Scale, float PersistForSeconds);

	// Object: Function AugmentedReality.ARBlueprintLibrary.AddRuntimeCandidateImage
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10413dd54
	// Return & Params: [ Num(5) Size(0x30) ]
	struct UARCandidateImage* AddRuntimeCandidateImage(struct UARSessionConfig* SessionConfig, struct UTexture2D* CandidateTexture, struct FString FriendlyName, float PhysicalWidth);

	// Object: Function AugmentedReality.ARBlueprintLibrary.AddManualEnvironmentCaptureProbe
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x10413e098
	// Return & Params: [ Num(3) Size(0x19) ]
	bool AddManualEnvironmentCaptureProbe(struct FVector Location, struct FVector Extent);
};

// Object: Class AugmentedReality.ARTraceResultLibrary
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UARTraceResultLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object: Function AugmentedReality.ARTraceResultLibrary.GetTrackedGeometry
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x1041407f0
	// Return & Params: [ Num(2) Size(0x68) ]
	struct UARTrackedGeometry* GetTrackedGeometry(struct FARTraceResult& TraceResult);

	// Object: Function AugmentedReality.ARTraceResultLibrary.GetTraceChannel
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x1041406dc
	// Return & Params: [ Num(2) Size(0x61) ]
	enum class EARLineTraceChannels GetTraceChannel(struct FARTraceResult& TraceResult);

	// Object: Function AugmentedReality.ARTraceResultLibrary.GetLocalToWorldTransform
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x104140904
	// Return & Params: [ Num(2) Size(0x90) ]
	struct FTransform GetLocalToWorldTransform(struct FARTraceResult& TraceResult);

	// Object: Function AugmentedReality.ARTraceResultLibrary.GetLocalToTrackingTransform
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x104140a28
	// Return & Params: [ Num(2) Size(0x90) ]
	struct FTransform GetLocalToTrackingTransform(struct FARTraceResult& TraceResult);

	// Object: Function AugmentedReality.ARTraceResultLibrary.GetDistanceFromCamera
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x104140b4c
	// Return & Params: [ Num(2) Size(0x64) ]
	float GetDistanceFromCamera(struct FARTraceResult& TraceResult);
};

// Object: Class AugmentedReality.ARBaseAsyncTaskBlueprintProxy
// Inherited Bytes: 0x30 | Struct Size: 0x58
struct UARBaseAsyncTaskBlueprintProxy : UBlueprintAsyncActionBase {
	// Fields
	char pad_0x30[0x28]; // Offset: 0x30 | Size: 0x28
};

// Object: Class AugmentedReality.ARSaveWorldAsyncTaskBlueprintProxy
// Inherited Bytes: 0x58 | Struct Size: 0x88
struct UARSaveWorldAsyncTaskBlueprintProxy : UARBaseAsyncTaskBlueprintProxy {
	// Fields
	struct FMulticastInlineDelegate OnSuccess; // Offset: 0x58 | Size: 0x10
	struct FMulticastInlineDelegate OnFailed; // Offset: 0x68 | Size: 0x10
	char pad_0x78[0x10]; // Offset: 0x78 | Size: 0x10

	// Functions

	// Object: Function AugmentedReality.ARSaveWorldAsyncTaskBlueprintProxy.ARSaveWorld
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104141188
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UARSaveWorldAsyncTaskBlueprintProxy* ARSaveWorld(struct UObject* WorldContextObject);
};

// Object: Class AugmentedReality.ARGetCandidateObjectAsyncTaskBlueprintProxy
// Inherited Bytes: 0x58 | Struct Size: 0xa0
struct UARGetCandidateObjectAsyncTaskBlueprintProxy : UARBaseAsyncTaskBlueprintProxy {
	// Fields
	struct FMulticastInlineDelegate OnSuccess; // Offset: 0x58 | Size: 0x10
	struct FMulticastInlineDelegate OnFailed; // Offset: 0x68 | Size: 0x10
	char pad_0x78[0x28]; // Offset: 0x78 | Size: 0x28

	// Functions

	// Object: Function AugmentedReality.ARGetCandidateObjectAsyncTaskBlueprintProxy.ARGetCandidateObject
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x1041415d8
	// Return & Params: [ Num(4) Size(0x28) ]
	struct UARGetCandidateObjectAsyncTaskBlueprintProxy* ARGetCandidateObject(struct UObject* WorldContextObject, struct FVector Location, struct FVector Extent);
};

// Object: Class AugmentedReality.ARLightEstimate
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UARLightEstimate : UObject {
};

// Object: Class AugmentedReality.ARBasicLightEstimate
// Inherited Bytes: 0x28 | Struct Size: 0x40
struct UARBasicLightEstimate : UARLightEstimate {
	// Fields
	float AmbientIntensityLumens; // Offset: 0x28 | Size: 0x4
	float AmbientColorTemperatureKelvin; // Offset: 0x2c | Size: 0x4
	struct FLinearColor AmbientColor; // Offset: 0x30 | Size: 0x10

	// Functions

	// Object: Function AugmentedReality.ARBasicLightEstimate.GetAmbientIntensityLumens
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104141c60
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetAmbientIntensityLumens();

	// Object: Function AugmentedReality.ARBasicLightEstimate.GetAmbientColorTemperatureKelvin
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104141c2c
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetAmbientColorTemperatureKelvin();

	// Object: Function AugmentedReality.ARBasicLightEstimate.GetAmbientColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104141bec
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FLinearColor GetAmbientColor();
};

// Object: Class AugmentedReality.AROriginActor
// Inherited Bytes: 0x228 | Struct Size: 0x228
struct AAROriginActor : AActor {
};

// Object: Class AugmentedReality.ARPin
// Inherited Bytes: 0x28 | Struct Size: 0xf0
struct UARPin : UObject {
	// Fields
	struct UARTrackedGeometry* TrackedGeometry; // Offset: 0x28 | Size: 0x8
	struct USceneComponent* PinnedComponent; // Offset: 0x30 | Size: 0x8
	char pad_0x38[0x8]; // Offset: 0x38 | Size: 0x8
	struct FTransform LocalToTrackingTransform; // Offset: 0x40 | Size: 0x30
	struct FTransform LocalToAlignedTrackingTransform; // Offset: 0x70 | Size: 0x30
	enum class EARTrackingState TrackingState; // Offset: 0xa0 | Size: 0x1
	char pad_0xA1[0x1f]; // Offset: 0xa1 | Size: 0x1f
	struct FMulticastInlineDelegate OnARTrackingStateChanged; // Offset: 0xc0 | Size: 0x10
	struct FMulticastInlineDelegate OnARTransformUpdated; // Offset: 0xd0 | Size: 0x10
	char pad_0xE0[0x10]; // Offset: 0xe0 | Size: 0x10

	// Functions

	// Object: Function AugmentedReality.ARPin.GetTrackingState
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1041422a0
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class EARTrackingState GetTrackingState();

	// Object: Function AugmentedReality.ARPin.GetTrackedGeometry
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10414226c
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UARTrackedGeometry* GetTrackedGeometry();

	// Object: Function AugmentedReality.ARPin.GetPinnedComponent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104142238
	// Return & Params: [ Num(1) Size(0x8) ]
	struct USceneComponent* GetPinnedComponent();

	// Object: Function AugmentedReality.ARPin.GetLocalToWorldTransform
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1041422d4
	// Return & Params: [ Num(1) Size(0x30) ]
	struct FTransform GetLocalToWorldTransform();

	// Object: Function AugmentedReality.ARPin.GetLocalToTrackingTransform
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10414234c
	// Return & Params: [ Num(1) Size(0x30) ]
	struct FTransform GetLocalToTrackingTransform();

	// Object: Function AugmentedReality.ARPin.GetDebugName
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10414208c
	// Return & Params: [ Num(1) Size(0x8) ]
	struct FName GetDebugName();

	// Object: Function AugmentedReality.ARPin.DebugDraw
	// Flags: [Native|Public|HasOutParms|HasDefaults|Const]
	// Offset: 0x1041420c0
	// Return & Params: [ Num(4) Size(0x20) ]
	void DebugDraw(struct UWorld* World, struct FLinearColor& Color, float Scale, float PersistForSeconds);
};

// Object: Class AugmentedReality.ARSessionConfig
// Inherited Bytes: 0x30 | Struct Size: 0xa8
struct UARSessionConfig : UDataAsset {
	// Fields
	bool bGenerateMeshDataFromTrackedGeometry; // Offset: 0x30 | Size: 0x1
	bool bGenerateCollisionForMeshData; // Offset: 0x31 | Size: 0x1
	bool bGenerateNavMeshForMeshData; // Offset: 0x32 | Size: 0x1
	bool bUseMeshDataForOcclusion; // Offset: 0x33 | Size: 0x1
	bool bRenderMeshDataInWireframe; // Offset: 0x34 | Size: 0x1
	bool bTrackSceneObjects; // Offset: 0x35 | Size: 0x1
	bool bUsePersonSegmentationForOcclusion; // Offset: 0x36 | Size: 0x1
	enum class EARWorldAlignment WorldAlignment; // Offset: 0x37 | Size: 0x1
	enum class EARSessionType SessionType; // Offset: 0x38 | Size: 0x1
	enum class EARPlaneDetectionMode PlaneDetectionMode; // Offset: 0x39 | Size: 0x1
	bool bHorizontalPlaneDetection; // Offset: 0x3a | Size: 0x1
	bool bVerticalPlaneDetection; // Offset: 0x3b | Size: 0x1
	bool bEnableAutoFocus; // Offset: 0x3c | Size: 0x1
	enum class EARLightEstimationMode LightEstimationMode; // Offset: 0x3d | Size: 0x1
	enum class EARFrameSyncMode FrameSyncMode; // Offset: 0x3e | Size: 0x1
	bool bEnableAutomaticCameraOverlay; // Offset: 0x3f | Size: 0x1
	bool bEnableAutomaticCameraTracking; // Offset: 0x40 | Size: 0x1
	bool bResetCameraTracking; // Offset: 0x41 | Size: 0x1
	bool bResetTrackedObjects; // Offset: 0x42 | Size: 0x1
	char pad_0x43[0x5]; // Offset: 0x43 | Size: 0x5
	struct TArray<struct UARCandidateImage*> CandidateImages; // Offset: 0x48 | Size: 0x10
	int32_t MaxNumSimultaneousImagesTracked; // Offset: 0x58 | Size: 0x4
	enum class EAREnvironmentCaptureProbeType EnvironmentCaptureProbeType; // Offset: 0x5c | Size: 0x1
	char pad_0x5D[0x3]; // Offset: 0x5d | Size: 0x3
	struct TArray<char> WorldMapData; // Offset: 0x60 | Size: 0x10
	struct TArray<struct UARCandidateObject*> CandidateObjects; // Offset: 0x70 | Size: 0x10
	struct FARVideoFormat DesiredVideoFormat; // Offset: 0x80 | Size: 0xc
	enum class EARFaceTrackingDirection FaceTrackingDirection; // Offset: 0x8c | Size: 0x1
	enum class EARFaceTrackingUpdate FaceTrackingUpdate; // Offset: 0x8d | Size: 0x1
	char pad_0x8E[0x2]; // Offset: 0x8e | Size: 0x2
	struct TArray<char> SerializedARCandidateImageDatabase; // Offset: 0x90 | Size: 0x10
	enum class EARSessionTrackingFeature EnabledSessionTrackingFeature; // Offset: 0xa0 | Size: 0x1
	char pad_0xA1[0x7]; // Offset: 0xa1 | Size: 0x7

	// Functions

	// Object: Function AugmentedReality.ARSessionConfig.ShouldResetTrackedObjects
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10414343c
	// Return & Params: [ Num(1) Size(0x1) ]
	bool ShouldResetTrackedObjects();

	// Object: Function AugmentedReality.ARSessionConfig.ShouldResetCameraTracking
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1041434f8
	// Return & Params: [ Num(1) Size(0x1) ]
	bool ShouldResetCameraTracking();

	// Object: Function AugmentedReality.ARSessionConfig.ShouldRenderCameraOverlay
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10414361c
	// Return & Params: [ Num(1) Size(0x1) ]
	bool ShouldRenderCameraOverlay();

	// Object: Function AugmentedReality.ARSessionConfig.ShouldEnableCameraTracking
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1041435e8
	// Return & Params: [ Num(1) Size(0x1) ]
	bool ShouldEnableCameraTracking();

	// Object: Function AugmentedReality.ARSessionConfig.ShouldEnableAutoFocus
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1041435b4
	// Return & Params: [ Num(1) Size(0x1) ]
	bool ShouldEnableAutoFocus();

	// Object: Function AugmentedReality.ARSessionConfig.SetWorldMapData
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1041430d4
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetWorldMapData(struct TArray<char> WorldMapData);

	// Object: Function AugmentedReality.ARSessionConfig.SetSessionTrackingFeatureToEnable
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104142c5c
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetSessionTrackingFeatureToEnable(enum class EARSessionTrackingFeature InSessionTrackingFeature);

	// Object: Function AugmentedReality.ARSessionConfig.SetResetTrackedObjects
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1041433b4
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetResetTrackedObjects(bool bNewValue);

	// Object: Function AugmentedReality.ARSessionConfig.SetResetCameraTracking
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104143470
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetResetCameraTracking(bool bNewValue);

	// Object: Function AugmentedReality.ARSessionConfig.SetFaceTrackingUpdate
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104142d10
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetFaceTrackingUpdate(enum class EARFaceTrackingUpdate InUpdate);

	// Object: Function AugmentedReality.ARSessionConfig.SetFaceTrackingDirection
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104142dc4
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetFaceTrackingDirection(enum class EARFaceTrackingDirection InDirection);

	// Object: Function AugmentedReality.ARSessionConfig.SetEnableAutoFocus
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10414352c
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetEnableAutoFocus(bool bNewValue);

	// Object: Function AugmentedReality.ARSessionConfig.SetDesiredVideoFormat
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104142e78
	// Return & Params: [ Num(1) Size(0xc) ]
	void SetDesiredVideoFormat(struct FARVideoFormat NewFormat);

	// Object: Function AugmentedReality.ARSessionConfig.SetCandidateObjectList
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104142fb8
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetCandidateObjectList(struct TArray<struct UARCandidateObject*>& InCandidateObjects);

	// Object: Function AugmentedReality.ARSessionConfig.GetWorldMapData
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1041431c4
	// Return & Params: [ Num(1) Size(0x10) ]
	struct TArray<char> GetWorldMapData();

	// Object: Function AugmentedReality.ARSessionConfig.GetWorldAlignment
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104143720
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class EARWorldAlignment GetWorldAlignment();

	// Object: Function AugmentedReality.ARSessionConfig.GetSessionType
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1041436ec
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class EARSessionType GetSessionType();

	// Object: Function AugmentedReality.ARSessionConfig.GetPlaneDetectionMode
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1041436b8
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class EARPlaneDetectionMode GetPlaneDetectionMode();

	// Object: Function AugmentedReality.ARSessionConfig.GetMaxNumSimultaneousImagesTracked
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10414327c
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetMaxNumSimultaneousImagesTracked();

	// Object: Function AugmentedReality.ARSessionConfig.GetLightEstimationMode
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104143684
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class EARLightEstimationMode GetLightEstimationMode();

	// Object: Function AugmentedReality.ARSessionConfig.GetFrameSyncMode
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104143650
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class EARFrameSyncMode GetFrameSyncMode();

	// Object: Function AugmentedReality.ARSessionConfig.GetFaceTrackingUpdate
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104142d90
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class EARFaceTrackingUpdate GetFaceTrackingUpdate();

	// Object: Function AugmentedReality.ARSessionConfig.GetFaceTrackingDirection
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104142e44
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class EARFaceTrackingDirection GetFaceTrackingDirection();

	// Object: Function AugmentedReality.ARSessionConfig.GetEnvironmentCaptureProbeType
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104143248
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class EAREnvironmentCaptureProbeType GetEnvironmentCaptureProbeType();

	// Object: Function AugmentedReality.ARSessionConfig.GetEnabledSessionTrackingFeature
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104142cdc
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class EARSessionTrackingFeature GetEnabledSessionTrackingFeature();

	// Object: Function AugmentedReality.ARSessionConfig.GetDesiredVideoFormat
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104142f00
	// Return & Params: [ Num(1) Size(0xc) ]
	struct FARVideoFormat GetDesiredVideoFormat();

	// Object: Function AugmentedReality.ARSessionConfig.GetCandidateObjectList
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104143050
	// Return & Params: [ Num(1) Size(0x10) ]
	struct TArray<struct UARCandidateObject*> GetCandidateObjectList();

	// Object: Function AugmentedReality.ARSessionConfig.GetCandidateImageList
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104143330
	// Return & Params: [ Num(1) Size(0x10) ]
	struct TArray<struct UARCandidateImage*> GetCandidateImageList();

	// Object: Function AugmentedReality.ARSessionConfig.AddCandidateObject
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104142f38
	// Return & Params: [ Num(1) Size(0x8) ]
	void AddCandidateObject(struct UARCandidateObject* CandidateObject);

	// Object: Function AugmentedReality.ARSessionConfig.AddCandidateImage
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1041432b0
	// Return & Params: [ Num(1) Size(0x8) ]
	void AddCandidateImage(struct UARCandidateImage* NewCandidateImage);
};

// Object: Class AugmentedReality.ARSharedWorldGameMode
// Inherited Bytes: 0x310 | Struct Size: 0x378
struct AARSharedWorldGameMode : AGameMode {
	// Fields
	int32_t BufferSizePerChunk; // Offset: 0x30c | Size: 0x4
	char pad_0x314[0x64]; // Offset: 0x314 | Size: 0x64

	// Functions

	// Object: Function AugmentedReality.ARSharedWorldGameMode.SetPreviewImageData
	// Flags: [Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable]
	// Offset: 0x104145650
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetPreviewImageData(struct TArray<char> ImageData);

	// Object: Function AugmentedReality.ARSharedWorldGameMode.SetARWorldSharingIsReady
	// Flags: [Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable]
	// Offset: 0x10414554c
	// Return & Params: [ Num(0) Size(0x0) ]
	void SetARWorldSharingIsReady();

	// Object: Function AugmentedReality.ARSharedWorldGameMode.SetARSharedWorldData
	// Flags: [Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable]
	// Offset: 0x104145560
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetARSharedWorldData(struct TArray<char> ARWorldData);

	// Object: Function AugmentedReality.ARSharedWorldGameMode.GetARSharedWorldGameState
	// Flags: [Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable]
	// Offset: 0x104145518
	// Return & Params: [ Num(1) Size(0x8) ]
	struct AARSharedWorldGameState* GetARSharedWorldGameState();
};

// Object: Class AugmentedReality.ARSharedWorldGameState
// Inherited Bytes: 0x2b0 | Struct Size: 0x2e8
struct AARSharedWorldGameState : AGameState {
	// Fields
	struct TArray<char> PreviewImageData; // Offset: 0x2b0 | Size: 0x10
	struct TArray<char> ARWorldData; // Offset: 0x2c0 | Size: 0x10
	int32_t PreviewImageBytesTotal; // Offset: 0x2d0 | Size: 0x4
	int32_t ARWorldBytesTotal; // Offset: 0x2d4 | Size: 0x4
	int32_t PreviewImageBytesDelivered; // Offset: 0x2d8 | Size: 0x4
	int32_t ARWorldBytesDelivered; // Offset: 0x2dc | Size: 0x4
	char pad_0x2E0[0x8]; // Offset: 0x2e0 | Size: 0x8

	// Functions

	// Object: Function AugmentedReality.ARSharedWorldGameState.K2_OnARWorldMapIsReady
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x103a43990
	// Return & Params: [ Num(0) Size(0x0) ]
	void K2_OnARWorldMapIsReady();
};

// Object: Class AugmentedReality.ARSharedWorldPlayerController
// Inherited Bytes: 0x5a8 | Struct Size: 0x5a8
struct AARSharedWorldPlayerController : APlayerController {
	// Functions

	// Object: Function AugmentedReality.ARSharedWorldPlayerController.ServerMarkReadyForReceiving
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	// Offset: 0x1041460a4
	// Return & Params: [ Num(0) Size(0x0) ]
	void ServerMarkReadyForReceiving();

	// Object: Function AugmentedReality.ARSharedWorldPlayerController.ClientUpdatePreviewImageData
	// Flags: [Net|NetReliableNative|Event|Public|NetClient|NetValidate]
	// Offset: 0x104145e8c
	// Return & Params: [ Num(2) Size(0x18) ]
	void ClientUpdatePreviewImageData(int32_t Offset, struct TArray<char> Buffer);

	// Object: Function AugmentedReality.ARSharedWorldPlayerController.ClientUpdateARWorldData
	// Flags: [Net|NetReliableNative|Event|Public|NetClient|NetValidate]
	// Offset: 0x104145d78
	// Return & Params: [ Num(2) Size(0x18) ]
	void ClientUpdateARWorldData(int32_t Offset, struct TArray<char> Buffer);

	// Object: Function AugmentedReality.ARSharedWorldPlayerController.ClientInitSharedWorld
	// Flags: [Net|NetReliableNative|Event|Public|NetClient|NetValidate]
	// Offset: 0x104145fa0
	// Return & Params: [ Num(2) Size(0x8) ]
	void ClientInitSharedWorld(int32_t PreviewImageSize, int32_t ARWorldDataSize);
};

// Object: Class AugmentedReality.ARSkyLight
// Inherited Bytes: 0x238 | Struct Size: 0x248
struct AARSkyLight : ASkyLight {
	// Fields
	struct UAREnvironmentCaptureProbe* CaptureProbe; // Offset: 0x238 | Size: 0x8
	char pad_0x240[0x8]; // Offset: 0x240 | Size: 0x8

	// Functions

	// Object: Function AugmentedReality.ARSkyLight.SetEnvironmentCaptureProbe
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10414669c
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetEnvironmentCaptureProbe(struct UAREnvironmentCaptureProbe* InCaptureProbe);
};

// Object: Class AugmentedReality.ARTexture
// Inherited Bytes: 0xb8 | Struct Size: 0xd8
struct UARTexture : UTexture {
	// Fields
	enum class EARTextureType TextureType; // Offset: 0xb8 | Size: 0x1
	char pad_0xB9[0x3]; // Offset: 0xb9 | Size: 0x3
	float Timestamp; // Offset: 0xbc | Size: 0x4
	struct FGuid ExternalTextureGuid; // Offset: 0xc0 | Size: 0x10
	struct FVector2D Size; // Offset: 0xd0 | Size: 0x8
};

// Object: Class AugmentedReality.ARTextureCameraImage
// Inherited Bytes: 0xd8 | Struct Size: 0xd8
struct UARTextureCameraImage : UARTexture {
};

// Object: Class AugmentedReality.ARTextureCameraDepth
// Inherited Bytes: 0xd8 | Struct Size: 0xe0
struct UARTextureCameraDepth : UARTexture {
	// Fields
	enum class EARDepthQuality DepthQuality; // Offset: 0xd8 | Size: 0x1
	enum class EARDepthAccuracy DepthAccuracy; // Offset: 0xd9 | Size: 0x1
	bool bIsTemporallySmoothed; // Offset: 0xda | Size: 0x1
	char pad_0xDB[0x5]; // Offset: 0xdb | Size: 0x5
};

// Object: Class AugmentedReality.AREnvironmentCaptureProbeTexture
// Inherited Bytes: 0x110 | Struct Size: 0x130
struct UAREnvironmentCaptureProbeTexture : UTextureCube {
	// Fields
	enum class EARTextureType TextureType; // Offset: 0x110 | Size: 0x1
	char pad_0x111[0x3]; // Offset: 0x111 | Size: 0x3
	float Timestamp; // Offset: 0x114 | Size: 0x4
	struct FGuid ExternalTextureGuid; // Offset: 0x118 | Size: 0x10
	struct FVector2D Size; // Offset: 0x128 | Size: 0x8
};

// Object: Class AugmentedReality.ARTraceResultDummy
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UARTraceResultDummy : UObject {
};

// Object: Class AugmentedReality.ARTrackedGeometry
// Inherited Bytes: 0x28 | Struct Size: 0xf0
struct UARTrackedGeometry : UObject {
	// Fields
	struct FGuid UniqueId; // Offset: 0x28 | Size: 0x10
	char pad_0x38[0x8]; // Offset: 0x38 | Size: 0x8
	struct FTransform LocalToTrackingTransform; // Offset: 0x40 | Size: 0x30
	struct FTransform LocalToAlignedTrackingTransform; // Offset: 0x70 | Size: 0x30
	enum class EARTrackingState TrackingState; // Offset: 0xa0 | Size: 0x1
	char pad_0xA1[0xf]; // Offset: 0xa1 | Size: 0xf
	struct UMRMeshComponent* UnderlyingMesh; // Offset: 0xb0 | Size: 0x8
	enum class EARObjectClassification ObjectClassification; // Offset: 0xb8 | Size: 0x1
	char pad_0xB9[0x17]; // Offset: 0xb9 | Size: 0x17
	int32_t LastUpdateFrameNumber; // Offset: 0xd0 | Size: 0x4
	char pad_0xD4[0xc]; // Offset: 0xd4 | Size: 0xc
	struct FName DebugName; // Offset: 0xe0 | Size: 0x8
	char pad_0xE8[0x8]; // Offset: 0xe8 | Size: 0x8

	// Functions

	// Object: Function AugmentedReality.ARTrackedGeometry.IsTracked
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104147888
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsTracked();

	// Object: Function AugmentedReality.ARTrackedGeometry.GetUnderlyingMesh
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1041477b8
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UMRMeshComponent* GetUnderlyingMesh();

	// Object: Function AugmentedReality.ARTrackedGeometry.GetTrackingState
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1041478bc
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class EARTrackingState GetTrackingState();

	// Object: Function AugmentedReality.ARTrackedGeometry.GetObjectClassification
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10414779c
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class EARObjectClassification GetObjectClassification();

	// Object: Function AugmentedReality.ARTrackedGeometry.GetLocalToWorldTransform
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104147968
	// Return & Params: [ Num(1) Size(0x30) ]
	struct FTransform GetLocalToWorldTransform();

	// Object: Function AugmentedReality.ARTrackedGeometry.GetLocalToTrackingTransform
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1041478f0
	// Return & Params: [ Num(1) Size(0x30) ]
	struct FTransform GetLocalToTrackingTransform();

	// Object: Function AugmentedReality.ARTrackedGeometry.GetLastUpdateTimestamp
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1041477ec
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetLastUpdateTimestamp();

	// Object: Function AugmentedReality.ARTrackedGeometry.GetLastUpdateFrameNumber
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104147820
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetLastUpdateFrameNumber();

	// Object: Function AugmentedReality.ARTrackedGeometry.GetDebugName
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104147854
	// Return & Params: [ Num(1) Size(0x8) ]
	struct FName GetDebugName();
};

// Object: Class AugmentedReality.ARPlaneGeometry
// Inherited Bytes: 0xf0 | Struct Size: 0x120
struct UARPlaneGeometry : UARTrackedGeometry {
	// Fields
	enum class EARPlaneOrientation Orientation; // Offset: 0xe8 | Size: 0x1
	struct FVector Center; // Offset: 0xec | Size: 0xc
	struct FVector Extent; // Offset: 0xf8 | Size: 0xc
	char pad_0x109[0xf]; // Offset: 0x109 | Size: 0xf
	struct UARPlaneGeometry* SubsumedBy; // Offset: 0x118 | Size: 0x8

	// Functions

	// Object: Function AugmentedReality.ARPlaneGeometry.GetSubsumedBy
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104147f0c
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UARPlaneGeometry* GetSubsumedBy();

	// Object: Function AugmentedReality.ARPlaneGeometry.GetOrientation
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104147ef0
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class EARPlaneOrientation GetOrientation();

	// Object: Function AugmentedReality.ARPlaneGeometry.GetExtent
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104147ff4
	// Return & Params: [ Num(1) Size(0xc) ]
	struct FVector GetExtent();

	// Object: Function AugmentedReality.ARPlaneGeometry.GetCenter
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104148018
	// Return & Params: [ Num(1) Size(0xc) ]
	struct FVector GetCenter();

	// Object: Function AugmentedReality.ARPlaneGeometry.GetBoundaryPolygonInLocalSpace
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104147f28
	// Return & Params: [ Num(1) Size(0x10) ]
	struct TArray<struct FVector> GetBoundaryPolygonInLocalSpace();
};

// Object: Class AugmentedReality.ARTrackedPoint
// Inherited Bytes: 0xf0 | Struct Size: 0xf0
struct UARTrackedPoint : UARTrackedGeometry {
};

// Object: Class AugmentedReality.ARTrackedImage
// Inherited Bytes: 0xf0 | Struct Size: 0x100
struct UARTrackedImage : UARTrackedGeometry {
	// Fields
	struct UARCandidateImage* DetectedImage; // Offset: 0xe8 | Size: 0x8
	struct FVector2D EstimatedSize; // Offset: 0xf0 | Size: 0x8

	// Functions

	// Object: Function AugmentedReality.ARTrackedImage.GetEstimateSize
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x104148828
	// Return & Params: [ Num(1) Size(0x8) ]
	struct FVector2D GetEstimateSize();

	// Object: Function AugmentedReality.ARTrackedImage.GetDetectedImage
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104148860
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UARCandidateImage* GetDetectedImage();
};

// Object: Class AugmentedReality.ARTrackedQRCode
// Inherited Bytes: 0x100 | Struct Size: 0x110
struct UARTrackedQRCode : UARTrackedImage {
	// Fields
	struct FString QRCode; // Offset: 0xf8 | Size: 0x10
	int32_t Version; // Offset: 0x108 | Size: 0x4
};

// Object: Class AugmentedReality.ARFaceGeometry
// Inherited Bytes: 0xf0 | Struct Size: 0x1e0
struct UARFaceGeometry : UARTrackedGeometry {
	// Fields
	struct FVector LookAtTarget; // Offset: 0xe8 | Size: 0xc
	bool bIsTracked; // Offset: 0xf4 | Size: 0x1
	struct TMap<enum class EARFaceBlendShape, float> BlendShapes; // Offset: 0xf8 | Size: 0x50
	char pad_0x14D[0x93]; // Offset: 0x14d | Size: 0x93

	// Functions

	// Object: Function AugmentedReality.ARFaceGeometry.GetWorldSpaceEyeTransform
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104148e74
	// Return & Params: [ Num(2) Size(0x40) ]
	struct FTransform GetWorldSpaceEyeTransform(enum class EAREye Eye);

	// Object: Function AugmentedReality.ARFaceGeometry.GetLocalSpaceEyeTransform
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104148f40
	// Return & Params: [ Num(2) Size(0x40) ]
	struct FTransform GetLocalSpaceEyeTransform(enum class EAREye Eye);

	// Object: Function AugmentedReality.ARFaceGeometry.GetBlendShapeValue
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1041490ac
	// Return & Params: [ Num(2) Size(0x8) ]
	float GetBlendShapeValue(enum class EARFaceBlendShape BlendShape);

	// Object: Function AugmentedReality.ARFaceGeometry.GetBlendShapes
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104148fdc
	// Return & Params: [ Num(1) Size(0x50) ]
	struct TMap<enum class EARFaceBlendShape, float> GetBlendShapes();
};

// Object: Class AugmentedReality.AREnvironmentCaptureProbe
// Inherited Bytes: 0xf0 | Struct Size: 0x100
struct UAREnvironmentCaptureProbe : UARTrackedGeometry {
	// Fields
	char pad_0xF0[0x8]; // Offset: 0xf0 | Size: 0x8
	struct UAREnvironmentCaptureProbeTexture* EnvironmentCaptureTexture; // Offset: 0xf8 | Size: 0x8

	// Functions

	// Object: Function AugmentedReality.AREnvironmentCaptureProbe.GetExtent
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104149698
	// Return & Params: [ Num(1) Size(0xc) ]
	struct FVector GetExtent();

	// Object: Function AugmentedReality.AREnvironmentCaptureProbe.GetEnvironmentCaptureTexture
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x104149664
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UAREnvironmentCaptureProbeTexture* GetEnvironmentCaptureTexture();
};

// Object: Class AugmentedReality.ARTrackedObject
// Inherited Bytes: 0xf0 | Struct Size: 0xf0
struct UARTrackedObject : UARTrackedGeometry {
	// Fields
	struct UARCandidateObject* DetectedObject; // Offset: 0xe8 | Size: 0x8

	// Functions

	// Object: Function AugmentedReality.ARTrackedObject.GetDetectedObject
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1041499f4
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UARCandidateObject* GetDetectedObject();
};

// Object: Class AugmentedReality.ARTrackedPose
// Inherited Bytes: 0xf0 | Struct Size: 0x140
struct UARTrackedPose : UARTrackedGeometry {
	// Fields
	char pad_0xF0[0x50]; // Offset: 0xf0 | Size: 0x50

	// Functions

	// Object: Function AugmentedReality.ARTrackedPose.GetTrackedPoseData
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104149e80
	// Return & Params: [ Num(1) Size(0x50) ]
	struct FARPose3D GetTrackedPoseData();
};

// Object: Class AugmentedReality.ARTrackableNotifyComponent
// Inherited Bytes: 0xb0 | Struct Size: 0x200
struct UARTrackableNotifyComponent : UActorComponent {
	// Fields
	struct FMulticastInlineDelegate OnAddTrackedGeometry; // Offset: 0xb0 | Size: 0x10
	struct FMulticastInlineDelegate OnUpdateTrackedGeometry; // Offset: 0xc0 | Size: 0x10
	struct FMulticastInlineDelegate OnRemoveTrackedGeometry; // Offset: 0xd0 | Size: 0x10
	struct FMulticastInlineDelegate OnAddTrackedPlane; // Offset: 0xe0 | Size: 0x10
	struct FMulticastInlineDelegate OnUpdateTrackedPlane; // Offset: 0xf0 | Size: 0x10
	struct FMulticastInlineDelegate OnRemoveTrackedPlane; // Offset: 0x100 | Size: 0x10
	struct FMulticastInlineDelegate OnAddTrackedPoint; // Offset: 0x110 | Size: 0x10
	struct FMulticastInlineDelegate OnUpdateTrackedPoint; // Offset: 0x120 | Size: 0x10
	struct FMulticastInlineDelegate OnRemoveTrackedPoint; // Offset: 0x130 | Size: 0x10
	struct FMulticastInlineDelegate OnAddTrackedImage; // Offset: 0x140 | Size: 0x10
	struct FMulticastInlineDelegate OnUpdateTrackedImage; // Offset: 0x150 | Size: 0x10
	struct FMulticastInlineDelegate OnRemoveTrackedImage; // Offset: 0x160 | Size: 0x10
	struct FMulticastInlineDelegate OnAddTrackedFace; // Offset: 0x170 | Size: 0x10
	struct FMulticastInlineDelegate OnUpdateTrackedFace; // Offset: 0x180 | Size: 0x10
	struct FMulticastInlineDelegate OnRemoveTrackedFace; // Offset: 0x190 | Size: 0x10
	struct FMulticastInlineDelegate OnAddTrackedEnvProbe; // Offset: 0x1a0 | Size: 0x10
	struct FMulticastInlineDelegate OnUpdateTrackedEnvProbe; // Offset: 0x1b0 | Size: 0x10
	struct FMulticastInlineDelegate OnRemoveTrackedEnvProbe; // Offset: 0x1c0 | Size: 0x10
	struct FMulticastInlineDelegate OnAddTrackedObject; // Offset: 0x1d0 | Size: 0x10
	struct FMulticastInlineDelegate OnUpdateTrackedObject; // Offset: 0x1e0 | Size: 0x10
	struct FMulticastInlineDelegate OnRemoveTrackedObject; // Offset: 0x1f0 | Size: 0x10
};

// Object: Class AugmentedReality.ARTypesDummyClass
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UARTypesDummyClass : UObject {
};

// Object: Class AugmentedReality.ARCandidateImage
// Inherited Bytes: 0x30 | Struct Size: 0x58
struct UARCandidateImage : UDataAsset {
	// Fields
	struct UTexture2D* CandidateTexture; // Offset: 0x30 | Size: 0x8
	struct FString FriendlyName; // Offset: 0x38 | Size: 0x10
	float Width; // Offset: 0x48 | Size: 0x4
	float Height; // Offset: 0x4c | Size: 0x4
	enum class EARCandidateImageOrientation Orientation; // Offset: 0x50 | Size: 0x1
	char pad_0x51[0x7]; // Offset: 0x51 | Size: 0x7

	// Functions

	// Object: Function AugmentedReality.ARCandidateImage.GetPhysicalWidth
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10414b118
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetPhysicalWidth();

	// Object: Function AugmentedReality.ARCandidateImage.GetPhysicalHeight
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10414b0fc
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetPhysicalHeight();

	// Object: Function AugmentedReality.ARCandidateImage.GetOrientation
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10414b0e0
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class EARCandidateImageOrientation GetOrientation();

	// Object: Function AugmentedReality.ARCandidateImage.GetFriendlyName
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10414b134
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetFriendlyName();

	// Object: Function AugmentedReality.ARCandidateImage.GetCandidateTexture
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10414b1b8
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UTexture2D* GetCandidateTexture();
};

// Object: Class AugmentedReality.ARCandidateObject
// Inherited Bytes: 0x30 | Struct Size: 0x70
struct UARCandidateObject : UDataAsset {
	// Fields
	struct TArray<char> CandidateObjectData; // Offset: 0x30 | Size: 0x10
	struct FString FriendlyName; // Offset: 0x40 | Size: 0x10
	struct FBox BoundingBox; // Offset: 0x50 | Size: 0x1c
	char pad_0x6C[0x4]; // Offset: 0x6c | Size: 0x4

	// Functions

	// Object: Function AugmentedReality.ARCandidateObject.SetFriendlyName
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10414b6e0
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetFriendlyName(struct FString NewName);

	// Object: Function AugmentedReality.ARCandidateObject.SetCandidateObjectData
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10414b840
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetCandidateObjectData(struct TArray<char>& InCandidateObject);

	// Object: Function AugmentedReality.ARCandidateObject.SetBoundingBox
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10414b600
	// Return & Params: [ Num(1) Size(0x1c) ]
	void SetBoundingBox(struct FBox& InBoundingBox);

	// Object: Function AugmentedReality.ARCandidateObject.GetFriendlyName
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10414b7bc
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetFriendlyName();

	// Object: Function AugmentedReality.ARCandidateObject.GetCandidateObjectData
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10414b938
	// Return & Params: [ Num(1) Size(0x10) ]
	struct TArray<char> GetCandidateObjectData();

	// Object: Function AugmentedReality.ARCandidateObject.GetBoundingBox
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10414b6bc
	// Return & Params: [ Num(1) Size(0x1c) ]
	struct FBox GetBoundingBox();
};

