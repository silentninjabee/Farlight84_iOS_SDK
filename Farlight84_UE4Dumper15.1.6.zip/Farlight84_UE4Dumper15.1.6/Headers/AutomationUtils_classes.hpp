#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class AutomationUtils.AutomationUtilsBlueprintLibrary
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UAutomationUtilsBlueprintLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object: Function AutomationUtils.AutomationUtilsBlueprintLibrary.TakeGameplayAutomationScreenshot
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1024182b8
	// Return & Params: [ Num(4) Size(0x28) ]
	void TakeGameplayAutomationScreenshot(struct FString ScreenshotName, float MaxGlobalError, float MaxLocalError, struct FString MapNameOverride);
};

