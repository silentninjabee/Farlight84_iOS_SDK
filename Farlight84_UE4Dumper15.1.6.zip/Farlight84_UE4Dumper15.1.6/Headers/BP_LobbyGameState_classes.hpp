#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_LobbyGameState.BP_LobbyGameState_C
// Inherited Bytes: 0x300 | Struct Size: 0x308
struct ABP_LobbyGameState_C : ASolarGameStateBase {
	// Fields
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x300 | Size: 0x8
};

