#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_SolarGameSettingsRange.BP_SolarGameSettingsRange_C
// Inherited Bytes: 0x180 | Struct Size: 0x180
struct UBP_SolarGameSettingsRange_C : USolarGameSettingsRange {
};

