#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Enum BlockoutToolsPlugin.EBlockoutMaterialType
enum class EBlockoutMaterialType : uint8_t {
	BlockoutMaterialType_Grid = 0,
	BlockoutMaterialType_CustomMaterial = 1,
	BlockoutMaterialType_MAX = 2
};

