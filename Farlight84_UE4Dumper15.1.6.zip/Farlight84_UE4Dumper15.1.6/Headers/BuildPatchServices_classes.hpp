#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class BuildPatchServices.BuildPatchManifest
// Inherited Bytes: 0x28 | Struct Size: 0x120
struct UBuildPatchManifest : UObject {
	// Fields
	char ManifestFileVersion; // Offset: 0x28 | Size: 0x1
	bool bIsFileData; // Offset: 0x29 | Size: 0x1
	char pad_0x2A[0x2]; // Offset: 0x2a | Size: 0x2
	uint32_t AppId; // Offset: 0x2c | Size: 0x4
	struct FString AppName; // Offset: 0x30 | Size: 0x10
	struct FString BuildVersion; // Offset: 0x40 | Size: 0x10
	struct FString LaunchExe; // Offset: 0x50 | Size: 0x10
	struct FString LaunchCommand; // Offset: 0x60 | Size: 0x10
	struct TSet<struct FString> PrereqIds; // Offset: 0x70 | Size: 0x50
	struct FString PrereqName; // Offset: 0xc0 | Size: 0x10
	struct FString PrereqPath; // Offset: 0xd0 | Size: 0x10
	struct FString PrereqArgs; // Offset: 0xe0 | Size: 0x10
	struct TArray<struct FFileManifestData> FileManifestList; // Offset: 0xf0 | Size: 0x10
	struct TArray<struct FChunkInfoData> ChunkList; // Offset: 0x100 | Size: 0x10
	struct TArray<struct FCustomFieldData> CustomFields; // Offset: 0x110 | Size: 0x10
};

