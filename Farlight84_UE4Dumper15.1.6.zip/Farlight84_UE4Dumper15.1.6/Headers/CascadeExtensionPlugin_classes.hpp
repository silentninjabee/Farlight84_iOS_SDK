#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class CascadeExtensionPlugin.AbstractParticleModule
// Inherited Bytes: 0x30 | Struct Size: 0x60
struct UAbstractParticleModule : UParticleModule {
	// Fields
	struct FParticleRandomSeedInfo RandomSeedInfo; // Offset: 0x30 | Size: 0x20
	int32_t StartDelay; // Offset: 0x50 | Size: 0x4
	int32_t MaxDuration; // Offset: 0x54 | Size: 0x4
	int32_t LoopAfter; // Offset: 0x58 | Size: 0x4
	char pad_0x5C[0x4]; // Offset: 0x5c | Size: 0x4
};

// Object: Class CascadeExtensionPlugin.ParticleModuleLocationHeightmap
// Inherited Bytes: 0x60 | Struct Size: 0xa8
struct UParticleModuleLocationHeightmap : UAbstractParticleModule {
	// Fields
	struct UTexture2D* HeightmapTexture; // Offset: 0x60 | Size: 0x8
	bool UpdateWithTick; // Offset: 0x68 | Size: 0x1
	bool SmoothUpdate; // Offset: 0x69 | Size: 0x1
	char pad_0x6A[0x2]; // Offset: 0x6a | Size: 0x2
	struct FBox MapBounds; // Offset: 0x6c | Size: 0x1c
	float Intensity; // Offset: 0x88 | Size: 0x4
	char pad_0x8C[0x1c]; // Offset: 0x8c | Size: 0x1c
};

// Object: Class CascadeExtensionPlugin.ParticleDataProvider
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UParticleDataProvider : UInterface {
	// Functions

	// Object: Function CascadeExtensionPlugin.ParticleDataProvider.UpdateParticle
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x101832000
	// Return & Params: [ Num(2) Size(0x88) ]
	struct FParticleProperties UpdateParticle(struct FParticleProperties currentParticleProperties);

	// Object: Function CascadeExtensionPlugin.ParticleDataProvider.SpawnParticle
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x1018320d0
	// Return & Params: [ Num(2) Size(0x88) ]
	struct FParticleProperties SpawnParticle(struct FParticleProperties currentParticleProperties);
};

// Object: Class CascadeExtensionPlugin.ParticleModuleCustomData
// Inherited Bytes: 0x60 | Struct Size: 0x70
struct UParticleModuleCustomData : UAbstractParticleModule {
	// Fields
	struct FName DataProviderParameterName; // Offset: 0x60 | Size: 0x8
	bool UpdatedSpawnedParticles; // Offset: 0x68 | Size: 0x1
	bool UpdatedTickedParticles; // Offset: 0x69 | Size: 0x1
	bool UseLocationFromProvider; // Offset: 0x6a | Size: 0x1
	bool UseVelocityFromProvider; // Offset: 0x6b | Size: 0x1
	bool UseSizeFromProvider; // Offset: 0x6c | Size: 0x1
	bool UseColorFromProvider; // Offset: 0x6d | Size: 0x1
	bool UseRotationFromProvider; // Offset: 0x6e | Size: 0x1
	bool UseRotationRateFromProvider; // Offset: 0x6f | Size: 0x1
};

// Object: Class CascadeExtensionPlugin.ParticleModuleSwarmMovement
// Inherited Bytes: 0x60 | Struct Size: 0xa0
struct UParticleModuleSwarmMovement : UAbstractParticleModule {
	// Fields
	float PerceptionRadius; // Offset: 0x60 | Size: 0x4
	float MaxAcceleration; // Offset: 0x64 | Size: 0x4
	float MaxVelocity; // Offset: 0x68 | Size: 0x4
	float SeparationWeight; // Offset: 0x6c | Size: 0x4
	float AlignmentWeight; // Offset: 0x70 | Size: 0x4
	float CohesionWeight; // Offset: 0x74 | Size: 0x4
	float BlindspotAngleDeg; // Offset: 0x78 | Size: 0x4
	enum class EDistanceWeight SeparationDistanceWeight; // Offset: 0x7c | Size: 0x1
	char pad_0x7D[0x3]; // Offset: 0x7d | Size: 0x3
	struct TArray<struct FVector> SteeringTargets; // Offset: 0x80 | Size: 0x10
	float SteeringWeight; // Offset: 0x90 | Size: 0x4
	enum class EDistanceWeight SteeringTargetDistanceWeight; // Offset: 0x94 | Size: 0x1
	char pad_0x95[0x3]; // Offset: 0x95 | Size: 0x3
	struct FName DynamicSteeringPointProviderName; // Offset: 0x98 | Size: 0x8
};

// Object: Class CascadeExtensionPlugin.ParticleModuleSortOrder
// Inherited Bytes: 0x60 | Struct Size: 0x68
struct UParticleModuleSortOrder : UAbstractParticleModule {
	// Fields
	int32_t SortOrder; // Offset: 0x60 | Size: 0x4
	char pad_0x64[0x4]; // Offset: 0x64 | Size: 0x4
};

// Object: Class CascadeExtensionPlugin.ParticleModuleDecalComponent
// Inherited Bytes: 0x60 | Struct Size: 0x120
struct UParticleModuleDecalComponent : UAbstractParticleModule {
	// Fields
	struct TArray<struct UMaterialInterface*> DecalMaterials; // Offset: 0x60 | Size: 0x10
	struct FRawDistributionVector DecalScale; // Offset: 0x70 | Size: 0x48
	bool ScaleWithParticleSize; // Offset: 0xb8 | Size: 0x1
	char pad_0xB9[0x7]; // Offset: 0xb9 | Size: 0x7
	struct FRawDistributionVector DecalRotation; // Offset: 0xc0 | Size: 0x48
	bool RotateToParticleVelocity; // Offset: 0x108 | Size: 0x1
	char pad_0x109[0x3]; // Offset: 0x109 | Size: 0x3
	int32_t SortOrder; // Offset: 0x10c | Size: 0x4
	bool OptimizeDecalComponentUsage; // Offset: 0x110 | Size: 0x1
	char pad_0x111[0x3]; // Offset: 0x111 | Size: 0x3
	struct FName MaterialColorParameter; // Offset: 0x114 | Size: 0x8
	char pad_0x11C[0x4]; // Offset: 0x11c | Size: 0x4
};

// Object: Class CascadeExtensionPlugin.ParticleModuleVelocityTurbulence
// Inherited Bytes: 0x60 | Struct Size: 0x80
struct UParticleModuleVelocityTurbulence : UAbstractParticleModule {
	// Fields
	struct FVector Intensity; // Offset: 0x60 | Size: 0xc
	float LengthScale; // Offset: 0x6c | Size: 0x4
	float Tightness; // Offset: 0x70 | Size: 0x4
	float MaxAcceleration; // Offset: 0x74 | Size: 0x4
	float MaxVelocity; // Offset: 0x78 | Size: 0x4
	char pad_0x7C[0x4]; // Offset: 0x7c | Size: 0x4
};

// Object: Class CascadeExtensionPlugin.ParticleModuleLocationJiggle
// Inherited Bytes: 0x60 | Struct Size: 0xa8
struct UParticleModuleLocationJiggle : UAbstractParticleModule {
	// Fields
	struct FRawDistributionVector Intensity; // Offset: 0x60 | Size: 0x48
};

// Object: Class CascadeExtensionPlugin.ParticleModuleLocationSpiral
// Inherited Bytes: 0x60 | Struct Size: 0x120
struct UParticleModuleLocationSpiral : UAbstractParticleModule {
	// Fields
	struct FRawDistributionVector StartLocation; // Offset: 0x60 | Size: 0x48
	struct FRawDistributionFloat Radius; // Offset: 0xa8 | Size: 0x30
	float DeltaAngle; // Offset: 0xd8 | Size: 0x4
	float EllipseA; // Offset: 0xdc | Size: 0x4
	float EllipseB; // Offset: 0xe0 | Size: 0x4
	char pad_0xE4[0x4]; // Offset: 0xe4 | Size: 0x4
	struct FRawDistributionFloat DiscHeight; // Offset: 0xe8 | Size: 0x30
	float FalloffFactor; // Offset: 0x118 | Size: 0x4
	char pad_0x11C[0x4]; // Offset: 0x11c | Size: 0x4
};

// Object: Class CascadeExtensionPlugin.ParticleDecalComponent
// Inherited Bytes: 0x390 | Struct Size: 0x3a0
struct UParticleDecalComponent : UDecalComponent {
	// Fields
	int32_t ModuleID; // Offset: 0x388 | Size: 0x4
	float TimeLeftUntilDestruction; // Offset: 0x38c | Size: 0x4
	struct FVector BaseScale; // Offset: 0x390 | Size: 0xc
};

// Object: Class CascadeExtensionPlugin.ParticleModuleForcePoints
// Inherited Bytes: 0x60 | Struct Size: 0x88
struct UParticleModuleForcePoints : UAbstractParticleModule {
	// Fields
	float Intensity; // Offset: 0x60 | Size: 0x4
	char pad_0x64[0x4]; // Offset: 0x64 | Size: 0x4
	struct TArray<struct FVector> Points; // Offset: 0x68 | Size: 0x10
	enum class EDistanceWeight SeparationDistanceWeight; // Offset: 0x78 | Size: 0x1
	char pad_0x79[0x3]; // Offset: 0x79 | Size: 0x3
	float DistanceScale; // Offset: 0x7c | Size: 0x4
	struct FName DynamicForcePointProviderName; // Offset: 0x80 | Size: 0x8
};

// Object: Class CascadeExtensionPlugin.ParticleModuleLocationMesh
// Inherited Bytes: 0x60 | Struct Size: 0x150
struct UParticleModuleLocationMesh : UAbstractParticleModule {
	// Fields
	struct UStaticMesh* SurfaceMesh; // Offset: 0x60 | Size: 0x8
	struct FName DynamicMeshParameterName; // Offset: 0x68 | Size: 0x8
	struct FTransform MeshTransform; // Offset: 0x70 | Size: 0x30
	bool EqualTriangeWeight; // Offset: 0xa0 | Size: 0x1
	char pad_0xA1[0x7]; // Offset: 0xa1 | Size: 0x7
	struct FRawDistributionFloat VelocityScale; // Offset: 0xa8 | Size: 0x30
	char pad_0xD8[0x78]; // Offset: 0xd8 | Size: 0x78

	// Functions

	// Object: Function CascadeExtensionPlugin.ParticleModuleLocationMesh.OnCachedActorDestroyed
	// Flags: [Final|Native|Private]
	// Offset: 0x101836418
	// Return & Params: [ Num(1) Size(0x8) ]
	void OnCachedActorDestroyed(struct AActor* DestroyedActor);
};

// Object: Class CascadeExtensionPlugin.ParticleModuleLocationDonut
// Inherited Bytes: 0x60 | Struct Size: 0x78
struct UParticleModuleLocationDonut : UAbstractParticleModule {
	// Fields
	struct FVector Center; // Offset: 0x60 | Size: 0xc
	float MinRadius; // Offset: 0x6c | Size: 0x4
	float MaxRadius; // Offset: 0x70 | Size: 0x4
	bool SurfaceOnly; // Offset: 0x74 | Size: 0x1
	bool IsFlat; // Offset: 0x75 | Size: 0x1
	char pad_0x76[0x2]; // Offset: 0x76 | Size: 0x2
};

// Object: Class CascadeExtensionPlugin.ParticleModuleColorTexture
// Inherited Bytes: 0x60 | Struct Size: 0xb0
struct UParticleModuleColorTexture : UAbstractParticleModule {
	// Fields
	struct UTexture2D* ColorIndexTexture; // Offset: 0x60 | Size: 0x8
	bool UpdateWithTick; // Offset: 0x68 | Size: 0x1
	char pad_0x69[0x3]; // Offset: 0x69 | Size: 0x3
	struct FBox MapBounds; // Offset: 0x6c | Size: 0x1c
	enum class ESpaceAxis ParticleAxisToTextureX; // Offset: 0x88 | Size: 0x1
	enum class ESpaceAxis ParticleAxisToTextureY; // Offset: 0x89 | Size: 0x1
	char pad_0x8A[0x2]; // Offset: 0x8a | Size: 0x2
	float Intensity; // Offset: 0x8c | Size: 0x4
	bool UseTextureAlpha; // Offset: 0x90 | Size: 0x1
	char pad_0x91[0x1f]; // Offset: 0x91 | Size: 0x1f
};

// Object: Class CascadeExtensionPlugin.ParticleModuleSizeBySpeedOverTime
// Inherited Bytes: 0x60 | Struct Size: 0xc8
struct UParticleModuleSizeBySpeedOverTime : UAbstractParticleModule {
	// Fields
	struct FRawDistributionVector Size; // Offset: 0x60 | Size: 0x48
	bool InvertSpeed; // Offset: 0xa8 | Size: 0x1
	char pad_0xA9[0x3]; // Offset: 0xa9 | Size: 0x3
	struct FVector MaxSize; // Offset: 0xac | Size: 0xc
	struct FVector MinSize; // Offset: 0xb8 | Size: 0xc
	char pad_0xC4[0x4]; // Offset: 0xc4 | Size: 0x4
};

// Object: Class CascadeExtensionPlugin.MeshDataProvider
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UMeshDataProvider : UInterface {
	// Functions

	// Object: Function CascadeExtensionPlugin.MeshDataProvider.GetMeshTriangleData
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x101837bbc
	// Return & Params: [ Num(1) Size(0x20) ]
	struct FMeshTriangleData GetMeshTriangleData();

	// Object: Function CascadeExtensionPlugin.MeshDataProvider.GetDataRevision
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x101837b80
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetDataRevision();
};

// Object: Class CascadeExtensionPlugin.ForcePointDataProvider
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UForcePointDataProvider : UInterface {
	// Functions

	// Object: Function CascadeExtensionPlugin.ForcePointDataProvider.GetForcePoints
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x101838d8c
	// Return & Params: [ Num(1) Size(0x20) ]
	struct FForcePoints GetForcePoints();
};

