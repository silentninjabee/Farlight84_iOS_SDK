#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct CascadeExtensionPlugin.ParticleProperties
// Inherited Bytes: 0x0 | Struct Size: 0x44
struct FParticleProperties {
	// Fields
	int32_t ParticleId; // Offset: 0x0 | Size: 0x4
	float RelativeTime; // Offset: 0x4 | Size: 0x4
	struct FVector Location; // Offset: 0x8 | Size: 0xc
	struct FVector Velocity; // Offset: 0x14 | Size: 0xc
	struct FVector Size; // Offset: 0x20 | Size: 0xc
	struct FLinearColor Color; // Offset: 0x2c | Size: 0x10
	float Rotation; // Offset: 0x3c | Size: 0x4
	float RotationRate; // Offset: 0x40 | Size: 0x4
};

// Object: ScriptStruct CascadeExtensionPlugin.MeshTriangleData
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FMeshTriangleData {
	// Fields
	struct TArray<struct FVector> Vertices; // Offset: 0x0 | Size: 0x10
	struct TArray<struct FTriangleIndices> Indices; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct CascadeExtensionPlugin.TriangleIndices
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FTriangleIndices {
	// Fields
	int32_t v0; // Offset: 0x0 | Size: 0x4
	int32_t v1; // Offset: 0x4 | Size: 0x4
	int32_t v2; // Offset: 0x8 | Size: 0x4
};

// Object: ScriptStruct CascadeExtensionPlugin.ForcePoints
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FForcePoints {
	// Fields
	float Intensity; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct TArray<struct FVector> PointLocations; // Offset: 0x8 | Size: 0x10
	enum class EDistanceWeight SeparationDistanceWeight; // Offset: 0x18 | Size: 0x1
	char pad_0x19[0x3]; // Offset: 0x19 | Size: 0x3
	float DistanceScale; // Offset: 0x1c | Size: 0x4
};

