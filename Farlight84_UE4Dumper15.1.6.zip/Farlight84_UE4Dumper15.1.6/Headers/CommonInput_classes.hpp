#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class CommonInput.CommonUIInputData
// Inherited Bytes: 0x28 | Struct Size: 0x48
struct UCommonUIInputData : UObject {
	// Fields
	struct FDataTableRowHandle DefaultClickAction; // Offset: 0x28 | Size: 0x10
	struct FDataTableRowHandle DefaultBackAction; // Offset: 0x38 | Size: 0x10
};

// Object: Class CommonInput.CommonInputBaseControllerData
// Inherited Bytes: 0x28 | Struct Size: 0x100
struct UCommonInputBaseControllerData : UObject {
	// Fields
	enum class ECommonInputType InputType; // Offset: 0x28 | Size: 0x1
	char pad_0x29[0x3]; // Offset: 0x29 | Size: 0x3
	struct FName GamepadName; // Offset: 0x2c | Size: 0x8
	char pad_0x34[0x4]; // Offset: 0x34 | Size: 0x4
	struct FText GamepadDisplayName; // Offset: 0x38 | Size: 0x18
	struct FText GamepadCategory; // Offset: 0x50 | Size: 0x18
	struct FText GamepadPlatformName; // Offset: 0x68 | Size: 0x18
	struct TArray<struct FInputDeviceIdentifierPair> GamepadHardwareIdMapping; // Offset: 0x80 | Size: 0x10
	struct TSoftObjectPtr<UTexture2D> ControllerTexture; // Offset: 0x90 | Size: 0x28
	struct TSoftObjectPtr<UTexture2D> ControllerButtonMaskTexture; // Offset: 0xb8 | Size: 0x28
	struct TArray<struct FCommonInputKeyBrushConfiguration> InputBrushDataMap; // Offset: 0xe0 | Size: 0x10
	struct TArray<struct FCommonInputKeySetBrushConfiguration> InputBrushKeySets; // Offset: 0xf0 | Size: 0x10

	// Functions

	// Object: Function CommonInput.CommonInputBaseControllerData.GetRegisteredGamepads
	// Flags: [Final|Native|Static|Public]
	// Offset: 0x101728da4
	// Return & Params: [ Num(1) Size(0x10) ]
	struct TArray<struct FName> GetRegisteredGamepads();
};

// Object: Class CommonInput.CommonInputSettings
// Inherited Bytes: 0x28 | Struct Size: 0x110
struct UCommonInputSettings : UObject {
	// Fields
	struct TSoftClassPtr<UObject> InputData; // Offset: 0x28 | Size: 0x28
	struct TMap<struct FName, struct FCommonInputPlatformBaseData> CommonInputPlatformData; // Offset: 0x50 | Size: 0x50
	bool bEnableInputMethodThrashingProtection; // Offset: 0xa0 | Size: 0x1
	char pad_0xA1[0x3]; // Offset: 0xa1 | Size: 0x3
	int32_t InputMethodThrashingLimit; // Offset: 0xa4 | Size: 0x4
	double InputMethodThrashingWindowInSeconds; // Offset: 0xa8 | Size: 0x8
	double InputMethodThrashingCooldownInSeconds; // Offset: 0xb0 | Size: 0x8
	bool bAllowOutOfFocusDeviceInput; // Offset: 0xb8 | Size: 0x1
	char pad_0xB9[0x7]; // Offset: 0xb9 | Size: 0x7
	struct UCommonUIInputData* InputDataClass; // Offset: 0xc0 | Size: 0x8
	struct FCommonInputPlatformBaseData CurrentPlatform; // Offset: 0xc8 | Size: 0x48

	// Functions

	// Object: Function CommonInput.CommonInputSettings.GetRegisteredPlatforms
	// Flags: [Final|Native|Static|Private]
	// Offset: 0x101729170
	// Return & Params: [ Num(1) Size(0x10) ]
	struct TArray<struct FName> GetRegisteredPlatforms();
};

// Object: Class CommonInput.CommonInputSubsystem
// Inherited Bytes: 0x30 | Struct Size: 0xf8
struct UCommonInputSubsystem : ULocalPlayerSubsystem {
	// Fields
	char pad_0x30[0x20]; // Offset: 0x30 | Size: 0x20
	struct FMulticastInlineDelegate OnInputMethodChanged; // Offset: 0x50 | Size: 0x10
	int32_t NumberOfInputMethodChangesRecently; // Offset: 0x60 | Size: 0x4
	char pad_0x64[0x4]; // Offset: 0x64 | Size: 0x4
	double LastInputMethodChangeTime; // Offset: 0x68 | Size: 0x8
	double LastTimeInputMethodThrashingBegan; // Offset: 0x70 | Size: 0x8
	enum class ECommonInputType LastInputType; // Offset: 0x78 | Size: 0x1
	enum class ECommonInputType CurrentInputType; // Offset: 0x79 | Size: 0x1
	char pad_0x7A[0x2]; // Offset: 0x7a | Size: 0x2
	struct FName GamepadInputType; // Offset: 0x7c | Size: 0x8
	char pad_0x84[0x4]; // Offset: 0x84 | Size: 0x4
	struct TMap<struct FName, enum class ECommonInputType> CurrentInputLocks; // Offset: 0x88 | Size: 0x50
	char pad_0xD8[0x18]; // Offset: 0xd8 | Size: 0x18
	bool bIsGamepadSimulatedClick; // Offset: 0xf0 | Size: 0x1
	char pad_0xF1[0x7]; // Offset: 0xf1 | Size: 0x7

	// Functions

	// Object: Function CommonInput.CommonInputSubsystem.ShouldShowInputKeys
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x101729564
	// Return & Params: [ Num(1) Size(0x1) ]
	bool ShouldShowInputKeys();

	// Object: Function CommonInput.CommonInputSubsystem.SetGamepadInputType
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1017295cc
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetGamepadInputType(struct FName InGamepadInputType);

	// Object: Function CommonInput.CommonInputSubsystem.SetCurrentInputType
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101729680
	// Return & Params: [ Num(2) Size(0x2) ]
	bool SetCurrentInputType(enum class ECommonInputType NewInputType);

	// Object: Function CommonInput.CommonInputSubsystem.SetCanChangeInputMethod
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1017294dc
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetCanChangeInputMethod(bool bCanChange);

	// Object: Function CommonInput.CommonInputSubsystem.IsUsingPointerInput
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x101729598
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsUsingPointerInput();

	// Object: Function CommonInput.CommonInputSubsystem.IsInputMethodActive
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x101729778
	// Return & Params: [ Num(2) Size(0x2) ]
	bool IsInputMethodActive(enum class ECommonInputType InputMethod);

	// Object: Function CommonInput.CommonInputSubsystem.GetDefaultInputType
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x101729710
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class ECommonInputType GetDefaultInputType();

	// Object: Function CommonInput.CommonInputSubsystem.GetCurrentInputType
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x101729744
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class ECommonInputType GetCurrentInputType();

	// Object: Function CommonInput.CommonInputSubsystem.GetCurrentGamepadName
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10172964c
	// Return & Params: [ Num(1) Size(0x8) ]
	struct FName GetCurrentGamepadName();
};

