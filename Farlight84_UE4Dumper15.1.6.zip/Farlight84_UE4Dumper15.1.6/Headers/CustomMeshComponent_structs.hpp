#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct CustomMeshComponent.CustomMeshTriangle
// Inherited Bytes: 0x0 | Struct Size: 0x24
struct FCustomMeshTriangle {
	// Fields
	struct FVector Vertex0; // Offset: 0x0 | Size: 0xc
	struct FVector Vertex1; // Offset: 0xc | Size: 0xc
	struct FVector Vertex2; // Offset: 0x18 | Size: 0xc
};

