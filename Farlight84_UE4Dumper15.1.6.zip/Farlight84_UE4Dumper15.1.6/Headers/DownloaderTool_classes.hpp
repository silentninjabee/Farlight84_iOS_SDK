#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class DownloaderTool.DownloaderHttpTask
// Inherited Bytes: 0x28 | Struct Size: 0xc8
struct UDownloaderHttpTask : UObject {
	// Fields
	struct FMulticastInlineDelegate OnTaskProgress; // Offset: 0x28 | Size: 0x10
	struct FMulticastInlineDelegate OnTaskSuccess; // Offset: 0x38 | Size: 0x10
	struct FMulticastInlineDelegate OnTaskFailed; // Offset: 0x48 | Size: 0x10
	char pad_0x58[0x70]; // Offset: 0x58 | Size: 0x70
};

// Object: Class DownloaderTool.DownloaderUtils
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UDownloaderUtils : UObject {
	// Functions

	// Object: Function DownloaderTool.DownloaderUtils.StringFileRawData
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10184ae74
	// Return & Params: [ Num(2) Size(0x58) ]
	struct FString StringFileRawData(struct FDownloaderResponse& InResponse);

	// Object: Function DownloaderTool.DownloaderUtils.SaveResponseToCache
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10184a8f0
	// Return & Params: [ Num(2) Size(0x58) ]
	void SaveResponseToCache(struct FDownloaderResponse& InResponse, struct FString CachePath);

	// Object: Function DownloaderTool.DownloaderUtils.GetVerbFromJsonRequestStr
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10184ac20
	// Return & Params: [ Num(2) Size(0x20) ]
	struct FString GetVerbFromJsonRequestStr(struct FString JsonRequestStr);

	// Object: Function DownloaderTool.DownloaderUtils.GetResponseFromCache
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10184a704
	// Return & Params: [ Num(3) Size(0x68) ]
	struct FDownloaderResponse GetResponseFromCache(struct FString InUrl, struct FString CachePath);

	// Object: Function DownloaderTool.DownloaderUtils.GetHeadersFromJsonRequestStr
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10184aac4
	// Return & Params: [ Num(2) Size(0x60) ]
	struct TMap<struct FString, struct FString> GetHeadersFromJsonRequestStr(struct FString JsonRequestStr);

	// Object: Function DownloaderTool.DownloaderUtils.execConvertRawDataToTexture
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10184afa0
	// Return & Params: [ Num(3) Size(0x20) ]
	struct UTexture2DDynamic* execConvertRawDataToTexture(struct TArray<char>& Data, int32_t& DataLength);

	// Object: Function DownloaderTool.DownloaderUtils.DecodeFileRawData
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10184ad48
	// Return & Params: [ Num(2) Size(0x58) ]
	struct FString DecodeFileRawData(struct FDownloaderResponse& InResponse);
};

