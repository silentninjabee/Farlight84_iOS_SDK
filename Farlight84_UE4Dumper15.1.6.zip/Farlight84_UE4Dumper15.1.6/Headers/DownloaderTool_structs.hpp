#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct DownloaderTool.DownloaderResponse
// Inherited Bytes: 0x0 | Struct Size: 0x48
struct FDownloaderResponse {
	// Fields
	struct FString URL; // Offset: 0x0 | Size: 0x10
	int32_t ErrorCode; // Offset: 0x10 | Size: 0x4
	char pad_0x14[0x4]; // Offset: 0x14 | Size: 0x4
	struct TArray<char> Data; // Offset: 0x18 | Size: 0x10
	bool bWasSuccessful; // Offset: 0x28 | Size: 0x1
	char pad_0x29[0x3]; // Offset: 0x29 | Size: 0x3
	int32_t ContentLength; // Offset: 0x2c | Size: 0x4
	int32_t DataLength; // Offset: 0x30 | Size: 0x4
	char pad_0x34[0x4]; // Offset: 0x34 | Size: 0x4
	int64_t Timestamp; // Offset: 0x38 | Size: 0x8
	enum class ERawDataAction RawDataAction; // Offset: 0x40 | Size: 0x1
	char pad_0x41[0x7]; // Offset: 0x41 | Size: 0x7
};

// Object: ScriptStruct DownloaderTool.DownloaderTaskInfo
// Inherited Bytes: 0x0 | Struct Size: 0x70
struct FDownloaderTaskInfo {
	// Fields
	struct FString URL; // Offset: 0x0 | Size: 0x10
	struct FString JsonRequestStr; // Offset: 0x10 | Size: 0x10
	bool bCompleted; // Offset: 0x20 | Size: 0x1
	char pad_0x21[0x7]; // Offset: 0x21 | Size: 0x7
	int64_t CompleteTimeStamp; // Offset: 0x28 | Size: 0x8
	bool bUsingResumeTrans; // Offset: 0x30 | Size: 0x1
	bool bForceRedownload; // Offset: 0x31 | Size: 0x1
	bool bSaveToCache; // Offset: 0x32 | Size: 0x1
	char pad_0x33[0x5]; // Offset: 0x33 | Size: 0x5
	struct FString FileDirectory; // Offset: 0x38 | Size: 0x10
	struct FString Filename; // Offset: 0x48 | Size: 0x10
	struct FString FileExtension; // Offset: 0x58 | Size: 0x10
	enum class ERawDataAction RawDataAction; // Offset: 0x68 | Size: 0x1
	char pad_0x69[0x7]; // Offset: 0x69 | Size: 0x7
};

