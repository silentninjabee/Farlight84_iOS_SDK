#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct EngineMessages.EngineServiceNotification
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FEngineServiceNotification {
	// Fields
	struct FString Text; // Offset: 0x0 | Size: 0x10
	double TimeSeconds; // Offset: 0x10 | Size: 0x8
};

// Object: ScriptStruct EngineMessages.EngineServiceTerminate
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FEngineServiceTerminate {
	// Fields
	struct FString UserName; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct EngineMessages.EngineServiceExecuteCommand
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FEngineServiceExecuteCommand {
	// Fields
	struct FString Command; // Offset: 0x0 | Size: 0x10
	struct FString UserName; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct EngineMessages.EngineServiceAuthGrant
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FEngineServiceAuthGrant {
	// Fields
	struct FString UserName; // Offset: 0x0 | Size: 0x10
	struct FString UserToGrant; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct EngineMessages.EngineServiceAuthDeny
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FEngineServiceAuthDeny {
	// Fields
	struct FString UserName; // Offset: 0x0 | Size: 0x10
	struct FString UserToDeny; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct EngineMessages.EngineServicePong
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FEngineServicePong {
	// Fields
	struct FString CurrentLevel; // Offset: 0x0 | Size: 0x10
	int32_t EngineVersion; // Offset: 0x10 | Size: 0x4
	bool HasBegunPlay; // Offset: 0x14 | Size: 0x1
	char pad_0x15[0x3]; // Offset: 0x15 | Size: 0x3
	struct FGuid instanceID; // Offset: 0x18 | Size: 0x10
	struct FString InstanceType; // Offset: 0x28 | Size: 0x10
	struct FGuid SessionId; // Offset: 0x38 | Size: 0x10
	float WorldTimeSeconds; // Offset: 0x48 | Size: 0x4
	char pad_0x4C[0x4]; // Offset: 0x4c | Size: 0x4
};

// Object: ScriptStruct EngineMessages.EngineServicePing
// Inherited Bytes: 0x0 | Struct Size: 0x1
struct FEngineServicePing {
	// Fields
	char pad_0x0[0x1]; // Offset: 0x0 | Size: 0x1
};

