#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct EngineSettings.AutoCompleteCommand
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FAutoCompleteCommand {
	// Fields
	struct FString Command; // Offset: 0x0 | Size: 0x10
	struct FString Desc; // Offset: 0x10 | Size: 0x10
	char pad_0x20[0x8]; // Offset: 0x20 | Size: 0x8
};

// Object: ScriptStruct EngineSettings.GameModeName
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FGameModeName {
	// Fields
	struct FString Name; // Offset: 0x0 | Size: 0x10
	struct FSoftClassPath GameMode; // Offset: 0x10 | Size: 0x18
};

