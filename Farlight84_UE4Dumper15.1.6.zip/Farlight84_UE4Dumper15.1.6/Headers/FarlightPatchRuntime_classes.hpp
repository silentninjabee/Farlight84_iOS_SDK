#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class FarlightPatchRuntime.PakHelper
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UPakHelper : UObject {
	// Functions

	// Object: Function FarlightPatchRuntime.PakHelper.ReloadRedirectSettingsFromIni
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102390a50
	// Return & Params: [ Num(1) Size(0x10) ]
	void ReloadRedirectSettingsFromIni(struct FString IniPath);

	// Object: Function FarlightPatchRuntime.PakHelper.ReloadIniFile
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102390b10
	// Return & Params: [ Num(3) Size(0x21) ]
	bool ReloadIniFile(struct FString StrippedConfigFileName, struct FString FilePath);

	// Object: Function FarlightPatchRuntime.PakHelper.ReloadGameUserSettings
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102390ad4
	// Return & Params: [ Num(0) Size(0x0) ]
	void ReloadGameUserSettings();

	// Object: Function FarlightPatchRuntime.PakHelper.ReloadDeviceProfiles
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102390ae8
	// Return & Params: [ Num(0) Size(0x0) ]
	void ReloadDeviceProfiles();

	// Object: Function FarlightPatchRuntime.PakHelper.ReloadCVarSettingsFromIni
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102390afc
	// Return & Params: [ Num(0) Size(0x0) ]
	void ReloadCVarSettingsFromIni();

	// Object: Function FarlightPatchRuntime.PakHelper.OpenShaderPatchLibrary
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102390bf4
	// Return & Params: [ Num(3) Size(0x21) ]
	void OpenShaderPatchLibrary(struct FString ShaderPatchLibraryName, struct FString LibraryDir, bool& bShaderPatchLibUnique);

	// Object: Function FarlightPatchRuntime.PakHelper.MountPak
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102390da8
	// Return & Params: [ Num(3) Size(0x15) ]
	bool MountPak(struct FString InPakFilename, int32_t PakOrder);

	// Object: Function FarlightPatchRuntime.PakHelper.GetStrippedConfigFileName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10239098c
	// Return & Params: [ Num(2) Size(0x20) ]
	struct FString GetStrippedConfigFileName(struct FString IniName);

	// Object: Function FarlightPatchRuntime.PakHelper.GetProjectName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102390d28
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetProjectName();

	// Object: Function FarlightPatchRuntime.PakHelper.CreatePakWriter
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102390e80
	// Return & Params: [ Num(3) Size(0x28) ]
	struct UPakWriter* CreatePakWriter(struct FString InFilename, struct FString InMountPoint);

	// Object: Function FarlightPatchRuntime.PakHelper.CreatePakReader
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102390f64
	// Return & Params: [ Num(3) Size(0x20) ]
	struct UPakReader* CreatePakReader(struct FString InFilename, bool bLoadIndex);
};

// Object: Class FarlightPatchRuntime.PakReader
// Inherited Bytes: 0x28 | Struct Size: 0x50
struct UPakReader : UObject {
	// Fields
	char pad_0x28[0x28]; // Offset: 0x28 | Size: 0x28

	// Functions

	// Object: Function FarlightPatchRuntime.PakReader.GetTotalSize
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1023917d8
	// Return & Params: [ Num(1) Size(0x8) ]
	int64_t GetTotalSize();

	// Object: Function FarlightPatchRuntime.PakReader.GetPakIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1023917f4
	// Return & Params: [ Num(1) Size(0x10) ]
	struct TArray<struct FPakEntryInfo> GetPakIndex();

	// Object: Function FarlightPatchRuntime.PakReader.Close
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102391918
	// Return & Params: [ Num(0) Size(0x0) ]
	void Close();
};

// Object: Class FarlightPatchRuntime.PakWriter
// Inherited Bytes: 0x28 | Struct Size: 0xc0
struct UPakWriter : UObject {
	// Fields
	char pad_0x28[0x98]; // Offset: 0x28 | Size: 0x98
};

