#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass GA_VehicleWeaponFire.GA_VehicleWeaponFire_C
// Inherited Bytes: 0x500 | Struct Size: 0x500
struct UGA_VehicleWeaponFire_C : USolarVehicleGA_WeaponFire {
};

