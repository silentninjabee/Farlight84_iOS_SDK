#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct GameplayTags.GameplayTagContainer
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FGameplayTagContainer {
	// Fields
	struct TArray<struct FGameplayTag> GameplayTags; // Offset: 0x0 | Size: 0x10
	struct TArray<struct FGameplayTag> ParentTags; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct GameplayTags.GameplayTag
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FGameplayTag {
	// Fields
	struct FName TagName; // Offset: 0x0 | Size: 0x8
};

// Object: ScriptStruct GameplayTags.GameplayTagQuery
// Inherited Bytes: 0x0 | Struct Size: 0x48
struct FGameplayTagQuery {
	// Fields
	int32_t TokenStreamVersion; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct TArray<struct FGameplayTag> TagDictionary; // Offset: 0x8 | Size: 0x10
	struct TArray<char> QueryTokenStream; // Offset: 0x18 | Size: 0x10
	struct FString UserDescription; // Offset: 0x28 | Size: 0x10
	struct FString AutoDescription; // Offset: 0x38 | Size: 0x10
};

// Object: ScriptStruct GameplayTags.GameplayTagCreationWidgetHelper
// Inherited Bytes: 0x0 | Struct Size: 0x1
struct FGameplayTagCreationWidgetHelper {
	// Fields
	char pad_0x0[0x1]; // Offset: 0x0 | Size: 0x1
};

// Object: ScriptStruct GameplayTags.GameplayTagReferenceHelper
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FGameplayTagReferenceHelper {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct GameplayTags.GameplayTagNode
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FGameplayTagNode {
	// Fields
	char pad_0x0[0x50]; // Offset: 0x0 | Size: 0x50
};

// Object: ScriptStruct GameplayTags.GameplayTagSource
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FGameplayTagSource {
	// Fields
	struct FName SourceName; // Offset: 0x0 | Size: 0x8
	enum class EGameplayTagSourceType SourceType; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x7]; // Offset: 0x9 | Size: 0x7
	struct UGameplayTagsList* SourceTagList; // Offset: 0x10 | Size: 0x8
	struct URestrictedGameplayTagsList* SourceRestrictedTagList; // Offset: 0x18 | Size: 0x8
};

// Object: ScriptStruct GameplayTags.GameplayTagTableRow
// Inherited Bytes: 0x8 | Struct Size: 0x20
struct FGameplayTagTableRow : FTableRowBase {
	// Fields
	struct FName Tag; // Offset: 0x8 | Size: 0x8
	struct FString DevComment; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct GameplayTags.RestrictedGameplayTagTableRow
// Inherited Bytes: 0x20 | Struct Size: 0x28
struct FRestrictedGameplayTagTableRow : FGameplayTagTableRow {
	// Fields
	bool bAllowNonRestrictedChildren; // Offset: 0x20 | Size: 0x1
	char pad_0x21[0x7]; // Offset: 0x21 | Size: 0x7
};

// Object: ScriptStruct GameplayTags.RestrictedConfigInfo
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FRestrictedConfigInfo {
	// Fields
	struct FString RestrictedConfigName; // Offset: 0x0 | Size: 0x10
	struct TArray<struct FString> Owners; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct GameplayTags.GameplayTagCategoryRemap
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FGameplayTagCategoryRemap {
	// Fields
	struct FString BaseCategory; // Offset: 0x0 | Size: 0x10
	struct TArray<struct FString> RemapCategories; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct GameplayTags.GameplayTagRedirect
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FGameplayTagRedirect {
	// Fields
	struct FName OldTagName; // Offset: 0x0 | Size: 0x8
	struct FName NewTagName; // Offset: 0x8 | Size: 0x8
};

