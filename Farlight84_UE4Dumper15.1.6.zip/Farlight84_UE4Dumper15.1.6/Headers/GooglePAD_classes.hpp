#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class GooglePAD.GooglePADFunctionLibrary
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UGooglePADFunctionLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object: Function GooglePAD.GooglePADFunctionLibrary.ShowCellularDataConfirmation
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105aad65c
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class EGooglePADErrorCode ShowCellularDataConfirmation();

	// Object: Function GooglePAD.GooglePADFunctionLibrary.RequestRemoval
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105aad690
	// Return & Params: [ Num(2) Size(0x11) ]
	enum class EGooglePADErrorCode RequestRemoval(struct FString Name);

	// Object: Function GooglePAD.GooglePADFunctionLibrary.RequestInfo
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105aadd58
	// Return & Params: [ Num(2) Size(0x11) ]
	enum class EGooglePADErrorCode RequestInfo(struct TArray<struct FString> AssetPacks);

	// Object: Function GooglePAD.GooglePADFunctionLibrary.RequestDownload
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105aadba8
	// Return & Params: [ Num(2) Size(0x11) ]
	enum class EGooglePADErrorCode RequestDownload(struct TArray<struct FString> AssetPacks);

	// Object: Function GooglePAD.GooglePADFunctionLibrary.ReleaseDownloadState
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105aad89c
	// Return & Params: [ Num(1) Size(0x4) ]
	void ReleaseDownloadState(int32_t State);

	// Object: Function GooglePAD.GooglePADFunctionLibrary.ReleaseAssetPackLocation
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105aad474
	// Return & Params: [ Num(1) Size(0x4) ]
	void ReleaseAssetPackLocation(int32_t Location);

	// Object: Function GooglePAD.GooglePADFunctionLibrary.GetTotalBytesToDownload
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105aad71c
	// Return & Params: [ Num(2) Size(0x8) ]
	int32_t GetTotalBytesToDownload(int32_t State);

	// Object: Function GooglePAD.GooglePADFunctionLibrary.GetStorageMethod
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105aad3f4
	// Return & Params: [ Num(2) Size(0x5) ]
	enum class EGooglePADStorageMethod GetStorageMethod(int32_t Location);

	// Object: Function GooglePAD.GooglePADFunctionLibrary.GetShowCellularDataConfirmationStatus
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105aad5d0
	// Return & Params: [ Num(2) Size(0x2) ]
	enum class EGooglePADErrorCode GetShowCellularDataConfirmationStatus(enum class EGooglePADCellularDataConfirmStatus& status);

	// Object: Function GooglePAD.GooglePADFunctionLibrary.GetDownloadStatus
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105aad81c
	// Return & Params: [ Num(2) Size(0x5) ]
	enum class EGooglePADDownloadStatus GetDownloadStatus(int32_t State);

	// Object: Function GooglePAD.GooglePADFunctionLibrary.GetDownloadState
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105aad914
	// Return & Params: [ Num(3) Size(0x15) ]
	enum class EGooglePADErrorCode GetDownloadState(struct FString Name, int32_t& State);

	// Object: Function GooglePAD.GooglePADFunctionLibrary.GetBytesDownloaded
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105aad79c
	// Return & Params: [ Num(2) Size(0x8) ]
	int32_t GetBytesDownloaded(int32_t State);

	// Object: Function GooglePAD.GooglePADFunctionLibrary.GetAssetsPath
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105aad330
	// Return & Params: [ Num(2) Size(0x18) ]
	struct FString GetAssetsPath(int32_t Location);

	// Object: Function GooglePAD.GooglePADFunctionLibrary.GetAssetPackLocation
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105aad4ec
	// Return & Params: [ Num(3) Size(0x15) ]
	enum class EGooglePADErrorCode GetAssetPackLocation(struct FString Name, int32_t& Location);

	// Object: Function GooglePAD.GooglePADFunctionLibrary.CancelDownload
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x105aad9f8
	// Return & Params: [ Num(2) Size(0x11) ]
	enum class EGooglePADErrorCode CancelDownload(struct TArray<struct FString> AssetPacks);
};

