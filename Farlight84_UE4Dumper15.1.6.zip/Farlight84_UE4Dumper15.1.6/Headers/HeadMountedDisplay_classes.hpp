#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class HeadMountedDisplay.HeadMountedDisplayFunctionLibrary
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UHeadMountedDisplayFunctionLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.UpdateExternalTrackingHMDPosition
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10416111c
	// Return & Params: [ Num(1) Size(0x30) ]
	void UpdateExternalTrackingHMDPosition(struct FTransform& ExternalTrackingTransform);

	// Object: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.SetWorldToMetersScale
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1041614b4
	// Return & Params: [ Num(2) Size(0xc) ]
	void SetWorldToMetersScale(struct UObject* WorldContext, float NewScale);

	// Object: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.SetTrackingOrigin
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1041613bc
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetTrackingOrigin(enum class EHMDTrackingOrigin Origin);

	// Object: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.SetSpectatorScreenTexture
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104160f18
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetSpectatorScreenTexture(struct UTexture* InTexture);

	// Object: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.SetSpectatorScreenModeTexturePlusEyeLayout
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x104160ccc
	// Return & Params: [ Num(7) Size(0x23) ]
	void SetSpectatorScreenModeTexturePlusEyeLayout(struct FVector2D EyeRectMin, struct FVector2D EyeRectMax, struct FVector2D TextureRectMin, struct FVector2D TextureRectMax, bool bDrawEyeFirst, bool bClearBlack, bool bUseAlpha);

	// Object: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.SetSpectatorScreenMode
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104160f90
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetSpectatorScreenMode(enum class ESpectatorScreenMode Mode);

	// Object: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.SetClippingPlanes
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1041615e0
	// Return & Params: [ Num(2) Size(0x8) ]
	void SetClippingPlanes(float Near, float Far);

	// Object: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.ResetOrientationAndPosition
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1041616a0
	// Return & Params: [ Num(2) Size(0x5) ]
	void ResetOrientationAndPosition(float Yaw, enum class EOrientPositionSelector options);

	// Object: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.IsSpectatorScreenModeControllable
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x104161008
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsSpectatorScreenModeControllable();

	// Object: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.IsInLowPersistenceMode
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1041617d4
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsInLowPersistenceMode();

	// Object: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.IsHeadMountedDisplayEnabled
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x10416213c
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsHeadMountedDisplayEnabled();

	// Object: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.IsHeadMountedDisplayConnected
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x104162108
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsHeadMountedDisplayConnected();

	// Object: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.IsDeviceTracking
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1041606ec
	// Return & Params: [ Num(2) Size(0xd) ]
	bool IsDeviceTracking(struct FXRDeviceId& XRDeviceId);

	// Object: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.HasValidTrackingPosition
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x104161f10
	// Return & Params: [ Num(1) Size(0x1) ]
	bool HasValidTrackingPosition();

	// Object: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.GetWorldToMetersScale
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x104161434
	// Return & Params: [ Num(2) Size(0xc) ]
	float GetWorldToMetersScale(struct UObject* WorldContext);

	// Object: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.GetVRFocusState
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x10416103c
	// Return & Params: [ Num(2) Size(0x2) ]
	void GetVRFocusState(bool& bUseFocus, bool& bHasFocus);

	// Object: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.GetTrackingToWorldTransform
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x1041612cc
	// Return & Params: [ Num(2) Size(0x40) ]
	struct FTransform GetTrackingToWorldTransform(struct UObject* WorldContext);

	// Object: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.GetTrackingSensorParameters
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x104161aa4
	// Return & Params: [ Num(11) Size(0x3c) ]
	void GetTrackingSensorParameters(struct FVector& Origin, struct FRotator& Rotation, float& LeftFOV, float& RightFOV, float& TopFOV, float& BottomFOV, float& Distance, float& NearPlane, float& FarPlane, bool& IsActive, int32_t Index);

	// Object: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.GetTrackingOrigin
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x104161388
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class EHMDTrackingOrigin GetTrackingOrigin();

	// Object: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.GetScreenPercentage
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1041615ac
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetScreenPercentage();

	// Object: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.GetPositionalTrackingCameraParameters
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x1041617ec
	// Return & Params: [ Num(7) Size(0x2c) ]
	void GetPositionalTrackingCameraParameters(struct FVector& CameraOrigin, struct FRotator& CameraRotation, float& HFOV, float& VFOV, float& CameraDistance, float& NearPlane, float& FarPlane);

	// Object: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.GetPixelDensity
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x104161578
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetPixelDensity();

	// Object: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.GetOrientationAndPosition
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x104161f44
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetOrientationAndPosition(struct FRotator& DeviceRotation, struct FVector& DevicePosition);

	// Object: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.GetNumOfTrackingSensors
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x104161edc
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetNumOfTrackingSensors();

	// Object: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.GetHMDWornState
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x104162018
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class EHMDWornState GetHMDWornState();

	// Object: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.GetHMDDeviceName
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x10416204c
	// Return & Params: [ Num(1) Size(0x8) ]
	struct FName GetHMDDeviceName();

	// Object: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.GetDeviceWorldPose
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10416077c
	// Return & Params: [ Num(6) Size(0x34) ]
	void GetDeviceWorldPose(struct UObject* WorldContext, struct FXRDeviceId& XRDeviceId, bool& bIsTracked, struct FRotator& Orientation, bool& bHasPositionalTracking, struct FVector& Position);

	// Object: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.GetDevicePose
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1041609c4
	// Return & Params: [ Num(5) Size(0x2c) ]
	void GetDevicePose(struct FXRDeviceId& XRDeviceId, bool& bIsTracked, struct FRotator& Orientation, bool& bHasPositionalTracking, struct FVector& Position);

	// Object: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.EnumerateTrackedDevices
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104160bbc
	// Return & Params: [ Num(3) Size(0x20) ]
	struct TArray<struct FXRDeviceId> EnumerateTrackedDevices(struct FName SystemId, enum class EXRTrackedDeviceType DeviceType);

	// Object: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.EnableLowPersistenceMode
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104161764
	// Return & Params: [ Num(1) Size(0x1) ]
	void EnableLowPersistenceMode(bool bEnable);

	// Object: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.EnableHMD
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104162080
	// Return & Params: [ Num(2) Size(0x2) ]
	bool EnableHMD(bool bEnable);

	// Object: Function HeadMountedDisplay.HeadMountedDisplayFunctionLibrary.CalibrateExternalTrackingToHMD
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1041611f4
	// Return & Params: [ Num(1) Size(0x30) ]
	void CalibrateExternalTrackingToHMD(struct FTransform& ExternalTrackingTransform);
};

// Object: Class HeadMountedDisplay.MotionControllerComponent
// Inherited Bytes: 0x570 | Struct Size: 0x630
struct UMotionControllerComponent : UPrimitiveComponent {
	// Fields
	int32_t PlayerIndex; // Offset: 0x570 | Size: 0x4
	enum class EControllerHand Hand; // Offset: 0x574 | Size: 0x1
	char pad_0x575[0x3]; // Offset: 0x575 | Size: 0x3
	struct FName MotionSource; // Offset: 0x578 | Size: 0x8
	char bDisableLowLatencyUpdate : 1; // Offset: 0x580 | Size: 0x1
	char pad_0x580_1 : 7; // Offset: 0x580 | Size: 0x1
	enum class ETrackingStatus CurrentTrackingStatus; // Offset: 0x581 | Size: 0x1
	bool bDisplayDeviceModel; // Offset: 0x582 | Size: 0x1
	char pad_0x583[0x1]; // Offset: 0x583 | Size: 0x1
	struct FName DisplayModelSource; // Offset: 0x584 | Size: 0x8
	char pad_0x58C[0x4]; // Offset: 0x58c | Size: 0x4
	struct UStaticMesh* CustomDisplayMesh; // Offset: 0x590 | Size: 0x8
	struct TArray<struct UMaterialInterface*> DisplayMeshMaterialOverrides; // Offset: 0x598 | Size: 0x10
	char pad_0x5A8[0x68]; // Offset: 0x5a8 | Size: 0x68
	struct UPrimitiveComponent* DisplayComponent; // Offset: 0x610 | Size: 0x8
	char pad_0x618[0x18]; // Offset: 0x618 | Size: 0x18

	// Functions

	// Object: Function HeadMountedDisplay.MotionControllerComponent.SetTrackingSource
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1041636f4
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetTrackingSource(enum class EControllerHand NewSource);

	// Object: Function HeadMountedDisplay.MotionControllerComponent.SetTrackingMotionSource
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104163640
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetTrackingMotionSource(struct FName NewSource);

	// Object: Function HeadMountedDisplay.MotionControllerComponent.SetShowDeviceModel
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104163874
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetShowDeviceModel(bool bShowControllerModel);

	// Object: Function HeadMountedDisplay.MotionControllerComponent.SetDisplayModelSource
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1041637f4
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetDisplayModelSource(struct FName NewDisplayModelSource);

	// Object: Function HeadMountedDisplay.MotionControllerComponent.SetCustomDisplayMesh
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104163774
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetCustomDisplayMesh(struct UStaticMesh* NewDisplayMesh);

	// Object: Function HeadMountedDisplay.MotionControllerComponent.SetAssociatedPlayerIndex
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1041635c0
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetAssociatedPlayerIndex(int32_t NewPlayer);

	// Object: Function HeadMountedDisplay.MotionControllerComponent.OnMotionControllerUpdated
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103a43990
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnMotionControllerUpdated();

	// Object: Function HeadMountedDisplay.MotionControllerComponent.IsTracked
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1041638fc
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsTracked();

	// Object: Function HeadMountedDisplay.MotionControllerComponent.GetTrackingSource
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1041636c0
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class EControllerHand GetTrackingSource();

	// Object: Function HeadMountedDisplay.MotionControllerComponent.GetParameterValue
	// Flags: [Final|Native|Protected|HasOutParms|BlueprintCallable]
	// Offset: 0x1041634d8
	// Return & Params: [ Num(3) Size(0x10) ]
	float GetParameterValue(struct FName InName, bool& bValueFound);

	// Object: Function HeadMountedDisplay.MotionControllerComponent.GetHandJointPosition
	// Flags: [Final|Native|Protected|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1041633e8
	// Return & Params: [ Num(3) Size(0x14) ]
	struct FVector GetHandJointPosition(int32_t jointIndex, bool& bValueFound);
};

// Object: Class HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UMotionTrackedDeviceFunctionLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object: Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.SetIsControllerMotionTrackingEnabledByDefault
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104164830
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetIsControllerMotionTrackingEnabledByDefault(bool Enable);

	// Object: Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.IsMotionTrackingEnabledForSource
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x104164630
	// Return & Params: [ Num(3) Size(0xd) ]
	bool IsMotionTrackingEnabledForSource(int32_t PlayerIndex, struct FName SourceName);

	// Object: Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.IsMotionTrackingEnabledForDevice
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1041646fc
	// Return & Params: [ Num(3) Size(0x6) ]
	bool IsMotionTrackingEnabledForDevice(int32_t PlayerIndex, enum class EControllerHand Hand);

	// Object: Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.IsMotionTrackingEnabledForComponent
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1041645b0
	// Return & Params: [ Num(2) Size(0x9) ]
	bool IsMotionTrackingEnabledForComponent(struct UMotionControllerComponent* MotionControllerComponent);

	// Object: Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.IsMotionTrackedDeviceCountManagementNecessary
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1041648b0
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsMotionTrackedDeviceCountManagementNecessary();

	// Object: Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.IsMotionSourceTracking
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104163f8c
	// Return & Params: [ Num(3) Size(0xd) ]
	bool IsMotionSourceTracking(int32_t PlayerIndex, struct FName SourceName);

	// Object: Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.GetMotionTrackingEnabledControllerCount
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1041647c8
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetMotionTrackingEnabledControllerCount();

	// Object: Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.GetMaximumMotionTrackedControllerCount
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1041647fc
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetMaximumMotionTrackedControllerCount();

	// Object: Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.GetActiveTrackingSystemName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104164058
	// Return & Params: [ Num(1) Size(0x8) ]
	struct FName GetActiveTrackingSystemName();

	// Object: Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.EnumerateMotionSources
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10416408c
	// Return & Params: [ Num(1) Size(0x10) ]
	struct TArray<struct FName> EnumerateMotionSources();

	// Object: Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.EnableMotionTrackingOfSource
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104164418
	// Return & Params: [ Num(3) Size(0xd) ]
	bool EnableMotionTrackingOfSource(int32_t PlayerIndex, struct FName SourceName);

	// Object: Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.EnableMotionTrackingOfDevice
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1041644e4
	// Return & Params: [ Num(3) Size(0x6) ]
	bool EnableMotionTrackingOfDevice(int32_t PlayerIndex, enum class EControllerHand Hand);

	// Object: Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.EnableMotionTrackingForComponent
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104164398
	// Return & Params: [ Num(2) Size(0x9) ]
	bool EnableMotionTrackingForComponent(struct UMotionControllerComponent* MotionControllerComponent);

	// Object: Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.DisableMotionTrackingOfSource
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104164210
	// Return & Params: [ Num(2) Size(0xc) ]
	void DisableMotionTrackingOfSource(int32_t PlayerIndex, struct FName SourceName);

	// Object: Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.DisableMotionTrackingOfDevice
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1041642d4
	// Return & Params: [ Num(2) Size(0x5) ]
	void DisableMotionTrackingOfDevice(int32_t PlayerIndex, enum class EControllerHand Hand);

	// Object: Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.DisableMotionTrackingOfControllersForPlayer
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10416410c
	// Return & Params: [ Num(1) Size(0x4) ]
	void DisableMotionTrackingOfControllersForPlayer(int32_t PlayerIndex);

	// Object: Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.DisableMotionTrackingOfAllControllers
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104164184
	// Return & Params: [ Num(0) Size(0x0) ]
	void DisableMotionTrackingOfAllControllers();

	// Object: Function HeadMountedDisplay.MotionTrackedDeviceFunctionLibrary.DisableMotionTrackingForComponent
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104164198
	// Return & Params: [ Num(1) Size(0x8) ]
	void DisableMotionTrackingForComponent(struct UMotionControllerComponent* MotionControllerComponent);
};

// Object: Class HeadMountedDisplay.VRNotificationsComponent
// Inherited Bytes: 0xb0 | Struct Size: 0x140
struct UVRNotificationsComponent : UActorComponent {
	// Fields
	struct FMulticastInlineDelegate HMDTrackingInitializingAndNeedsHMDToBeTrackedDelegate; // Offset: 0xb0 | Size: 0x10
	struct FMulticastInlineDelegate HMDTrackingInitializedDelegate; // Offset: 0xc0 | Size: 0x10
	struct FMulticastInlineDelegate HMDRecenteredDelegate; // Offset: 0xd0 | Size: 0x10
	struct FMulticastInlineDelegate HMDLostDelegate; // Offset: 0xe0 | Size: 0x10
	struct FMulticastInlineDelegate HMDReconnectedDelegate; // Offset: 0xf0 | Size: 0x10
	struct FMulticastInlineDelegate HMDConnectCanceledDelegate; // Offset: 0x100 | Size: 0x10
	struct FMulticastInlineDelegate HMDPutOnHeadDelegate; // Offset: 0x110 | Size: 0x10
	struct FMulticastInlineDelegate HMDRemovedFromHeadDelegate; // Offset: 0x120 | Size: 0x10
	struct FMulticastInlineDelegate VRControllerRecenteredDelegate; // Offset: 0x130 | Size: 0x10
};

// Object: Class HeadMountedDisplay.XRAssetFunctionLibrary
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UXRAssetFunctionLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object: Function HeadMountedDisplay.XRAssetFunctionLibrary.AddNamedDeviceVisualizationComponentBlocking
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1041651a0
	// Return & Params: [ Num(7) Size(0x68) ]
	struct UPrimitiveComponent* AddNamedDeviceVisualizationComponentBlocking(struct AActor* Target, struct FName SystemName, struct FName DeviceName, bool bManualAttachment, struct FTransform& RelativeTransform, struct FXRDeviceId& XRDeviceId);

	// Object: Function HeadMountedDisplay.XRAssetFunctionLibrary.AddDeviceVisualizationComponentBlocking
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x104165414
	// Return & Params: [ Num(5) Size(0x58) ]
	struct UPrimitiveComponent* AddDeviceVisualizationComponentBlocking(struct AActor* Target, struct FXRDeviceId& XRDeviceId, bool bManualAttachment, struct FTransform& RelativeTransform);
};

// Object: Class HeadMountedDisplay.AsyncTask_LoadXRDeviceVisComponent
// Inherited Bytes: 0x30 | Struct Size: 0x60
struct UAsyncTask_LoadXRDeviceVisComponent : UBlueprintAsyncActionBase {
	// Fields
	struct FMulticastInlineDelegate OnModelLoaded; // Offset: 0x30 | Size: 0x10
	struct FMulticastInlineDelegate OnLoadFailure; // Offset: 0x40 | Size: 0x10
	char pad_0x50[0x8]; // Offset: 0x50 | Size: 0x8
	struct UPrimitiveComponent* SpawnedComponent; // Offset: 0x58 | Size: 0x8

	// Functions

	// Object: Function HeadMountedDisplay.AsyncTask_LoadXRDeviceVisComponent.AddNamedDeviceVisualizationComponentAsync
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x104165abc
	// Return & Params: [ Num(8) Size(0x70) ]
	struct UAsyncTask_LoadXRDeviceVisComponent* AddNamedDeviceVisualizationComponentAsync(struct AActor* Target, struct FName SystemName, struct FName DeviceName, bool bManualAttachment, struct FTransform& RelativeTransform, struct FXRDeviceId& XRDeviceId, struct UPrimitiveComponent*& NewComponent);

	// Object: Function HeadMountedDisplay.AsyncTask_LoadXRDeviceVisComponent.AddDeviceVisualizationComponentAsync
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x104165878
	// Return & Params: [ Num(6) Size(0x60) ]
	struct UAsyncTask_LoadXRDeviceVisComponent* AddDeviceVisualizationComponentAsync(struct AActor* Target, struct FXRDeviceId& XRDeviceId, bool bManualAttachment, struct FTransform& RelativeTransform, struct UPrimitiveComponent*& NewComponent);
};

// Object: Class HeadMountedDisplay.XRLoadingScreenFunctionLibrary
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UXRLoadingScreenFunctionLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object: Function HeadMountedDisplay.XRLoadingScreenFunctionLibrary.ShowLoadingScreen
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1041661a4
	// Return & Params: [ Num(0) Size(0x0) ]
	void ShowLoadingScreen();

	// Object: Function HeadMountedDisplay.XRLoadingScreenFunctionLibrary.SetLoadingScreen
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x1041663bc
	// Return & Params: [ Num(5) Size(0x1e) ]
	void SetLoadingScreen(struct UTexture* Texture, struct FVector2D Scale, struct FVector Offset, bool bShowLoadingMovie, bool bShowOnSet);

	// Object: Function HeadMountedDisplay.XRLoadingScreenFunctionLibrary.HideLoadingScreen
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104166190
	// Return & Params: [ Num(0) Size(0x0) ]
	void HideLoadingScreen();

	// Object: Function HeadMountedDisplay.XRLoadingScreenFunctionLibrary.ClearLoadingScreenSplashes
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1041663a8
	// Return & Params: [ Num(0) Size(0x0) ]
	void ClearLoadingScreenSplashes();

	// Object: Function HeadMountedDisplay.XRLoadingScreenFunctionLibrary.AddLoadingScreenSplash
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x1041661b8
	// Return & Params: [ Num(6) Size(0x35) ]
	void AddLoadingScreenSplash(struct UTexture* Texture, struct FVector Translation, struct FRotator Rotation, struct FVector2D Size, struct FRotator DeltaRotation, bool bClearBeforeAdd);
};

