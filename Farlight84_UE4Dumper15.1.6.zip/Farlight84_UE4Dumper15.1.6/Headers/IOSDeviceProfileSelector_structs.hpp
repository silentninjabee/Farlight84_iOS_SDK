#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct IOSDeviceProfileSelector.IOSProfileMatch
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FIOSProfileMatch {
	// Fields
	struct FString Profile; // Offset: 0x0 | Size: 0x10
	struct FIOSProfileMatchItem Match; // Offset: 0x10 | Size: 0x30
};

// Object: ScriptStruct IOSDeviceProfileSelector.IOSProfileMatchItem
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FIOSProfileMatchItem {
	// Fields
	struct FString DeviceType; // Offset: 0x0 | Size: 0x10
	struct FString MajorString; // Offset: 0x10 | Size: 0x10
	struct FString MinorString; // Offset: 0x20 | Size: 0x10
};

