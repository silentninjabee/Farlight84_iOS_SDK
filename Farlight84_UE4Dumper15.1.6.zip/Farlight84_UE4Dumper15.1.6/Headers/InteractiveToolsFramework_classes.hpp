#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class InteractiveToolsFramework.InputBehavior
// Inherited Bytes: 0x28 | Struct Size: 0x30
struct UInputBehavior : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
};

// Object: Class InteractiveToolsFramework.AnyButtonInputBehavior
// Inherited Bytes: 0x30 | Struct Size: 0x70
struct UAnyButtonInputBehavior : UInputBehavior {
	// Fields
	char pad_0x30[0x40]; // Offset: 0x30 | Size: 0x40
};

// Object: Class InteractiveToolsFramework.InteractiveGizmoBuilder
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UInteractiveGizmoBuilder : UObject {
};

// Object: Class InteractiveToolsFramework.AxisAngleGizmoBuilder
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UAxisAngleGizmoBuilder : UInteractiveGizmoBuilder {
};

// Object: Class InteractiveToolsFramework.InteractiveGizmo
// Inherited Bytes: 0x28 | Struct Size: 0x38
struct UInteractiveGizmo : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
	struct UInputBehaviorSet* InputBehaviors; // Offset: 0x30 | Size: 0x8
};

// Object: Class InteractiveToolsFramework.AxisAngleGizmo
// Inherited Bytes: 0x38 | Struct Size: 0xf0
struct UAxisAngleGizmo : UInteractiveGizmo {
	// Fields
	char pad_0x38[0x10]; // Offset: 0x38 | Size: 0x10
	struct TScriptInterface<IGizmoAxisSource> AxisSource; // Offset: 0x48 | Size: 0x10
	struct TScriptInterface<IGizmoFloatParameterSource> AngleSource; // Offset: 0x58 | Size: 0x10
	struct TScriptInterface<IGizmoClickTarget> HitTarget; // Offset: 0x68 | Size: 0x10
	struct TScriptInterface<IGizmoStateTarget> StateTarget; // Offset: 0x78 | Size: 0x10
	bool bInInteraction; // Offset: 0x88 | Size: 0x1
	char pad_0x89[0x3]; // Offset: 0x89 | Size: 0x3
	struct FVector RotationOrigin; // Offset: 0x8c | Size: 0xc
	struct FVector RotationAxis; // Offset: 0x98 | Size: 0xc
	struct FVector RotationPlaneX; // Offset: 0xa4 | Size: 0xc
	struct FVector RotationPlaneY; // Offset: 0xb0 | Size: 0xc
	struct FVector InteractionStartPoint; // Offset: 0xbc | Size: 0xc
	struct FVector InteractionCurPoint; // Offset: 0xc8 | Size: 0xc
	float InteractionStartAngle; // Offset: 0xd4 | Size: 0x4
	float InteractionCurAngle; // Offset: 0xd8 | Size: 0x4
	char pad_0xDC[0x14]; // Offset: 0xdc | Size: 0x14
};

// Object: Class InteractiveToolsFramework.AxisPositionGizmoBuilder
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UAxisPositionGizmoBuilder : UInteractiveGizmoBuilder {
};

// Object: Class InteractiveToolsFramework.AxisPositionGizmo
// Inherited Bytes: 0x38 | Struct Size: 0xd8
struct UAxisPositionGizmo : UInteractiveGizmo {
	// Fields
	char pad_0x38[0x10]; // Offset: 0x38 | Size: 0x10
	struct TScriptInterface<IGizmoAxisSource> AxisSource; // Offset: 0x48 | Size: 0x10
	struct TScriptInterface<IGizmoFloatParameterSource> ParameterSource; // Offset: 0x58 | Size: 0x10
	struct TScriptInterface<IGizmoClickTarget> HitTarget; // Offset: 0x68 | Size: 0x10
	struct TScriptInterface<IGizmoStateTarget> StateTarget; // Offset: 0x78 | Size: 0x10
	bool bEnableSignedAxis; // Offset: 0x88 | Size: 0x1
	bool bInInteraction; // Offset: 0x89 | Size: 0x1
	char pad_0x8A[0x2]; // Offset: 0x8a | Size: 0x2
	struct FVector InteractionOrigin; // Offset: 0x8c | Size: 0xc
	struct FVector InteractionAxis; // Offset: 0x98 | Size: 0xc
	struct FVector InteractionStartPoint; // Offset: 0xa4 | Size: 0xc
	struct FVector InteractionCurPoint; // Offset: 0xb0 | Size: 0xc
	float InteractionStartParameter; // Offset: 0xbc | Size: 0x4
	float InteractionCurParameter; // Offset: 0xc0 | Size: 0x4
	float ParameterSign; // Offset: 0xc4 | Size: 0x4
	char pad_0xC8[0x10]; // Offset: 0xc8 | Size: 0x10
};

// Object: Class InteractiveToolsFramework.GizmoConstantAxisSource
// Inherited Bytes: 0x28 | Struct Size: 0x48
struct UGizmoConstantAxisSource : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
	struct FVector Origin; // Offset: 0x30 | Size: 0xc
	struct FVector Direction; // Offset: 0x3c | Size: 0xc
};

// Object: Class InteractiveToolsFramework.GizmoConstantFrameAxisSource
// Inherited Bytes: 0x28 | Struct Size: 0x60
struct UGizmoConstantFrameAxisSource : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
	struct FVector Origin; // Offset: 0x30 | Size: 0xc
	struct FVector Direction; // Offset: 0x3c | Size: 0xc
	struct FVector TangentX; // Offset: 0x48 | Size: 0xc
	struct FVector TangentY; // Offset: 0x54 | Size: 0xc
};

// Object: Class InteractiveToolsFramework.GizmoWorldAxisSource
// Inherited Bytes: 0x28 | Struct Size: 0x40
struct UGizmoWorldAxisSource : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
	struct FVector Origin; // Offset: 0x30 | Size: 0xc
	int32_t AxisIndex; // Offset: 0x3c | Size: 0x4
};

// Object: Class InteractiveToolsFramework.GizmoComponentAxisSource
// Inherited Bytes: 0x28 | Struct Size: 0x40
struct UGizmoComponentAxisSource : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
	struct USceneComponent* Component; // Offset: 0x30 | Size: 0x8
	int32_t AxisIndex; // Offset: 0x38 | Size: 0x4
	bool bLocalAxes; // Offset: 0x3c | Size: 0x1
	char pad_0x3D[0x3]; // Offset: 0x3d | Size: 0x3
};

// Object: Class InteractiveToolsFramework.InteractiveToolPropertySet
// Inherited Bytes: 0x28 | Struct Size: 0x50
struct UInteractiveToolPropertySet : UObject {
	// Fields
	char pad_0x28[0x18]; // Offset: 0x28 | Size: 0x18
	struct UObject* CachedProperties; // Offset: 0x40 | Size: 0x8
	bool bIsPropertySetEnabled; // Offset: 0x48 | Size: 0x1
	char pad_0x49[0x7]; // Offset: 0x49 | Size: 0x7
};

// Object: Class InteractiveToolsFramework.BrushBaseProperties
// Inherited Bytes: 0x50 | Struct Size: 0x68
struct UBrushBaseProperties : UInteractiveToolPropertySet {
	// Fields
	float BrushSize; // Offset: 0x4c | Size: 0x4
	bool bSpecifyRadius; // Offset: 0x50 | Size: 0x1
	float BrushRadius; // Offset: 0x54 | Size: 0x4
	float BrushStrength; // Offset: 0x58 | Size: 0x4
	float BrushFalloffAmount; // Offset: 0x5c | Size: 0x4
	bool bShowStrength; // Offset: 0x60 | Size: 0x1
	bool bShowFalloff; // Offset: 0x61 | Size: 0x1
	char pad_0x63[0x5]; // Offset: 0x63 | Size: 0x5
};

// Object: Class InteractiveToolsFramework.InteractiveTool
// Inherited Bytes: 0x28 | Struct Size: 0x80
struct UInteractiveTool : UObject {
	// Fields
	char pad_0x28[0x20]; // Offset: 0x28 | Size: 0x20
	struct UInputBehaviorSet* InputBehaviors; // Offset: 0x48 | Size: 0x8
	struct TArray<struct UObject*> ToolPropertyObjects; // Offset: 0x50 | Size: 0x10
	char pad_0x60[0x20]; // Offset: 0x60 | Size: 0x20
};

// Object: Class InteractiveToolsFramework.SingleSelectionTool
// Inherited Bytes: 0x80 | Struct Size: 0x88
struct USingleSelectionTool : UInteractiveTool {
	// Fields
	char pad_0x80[0x8]; // Offset: 0x80 | Size: 0x8
};

// Object: Class InteractiveToolsFramework.MeshSurfacePointTool
// Inherited Bytes: 0x88 | Struct Size: 0xc0
struct UMeshSurfacePointTool : USingleSelectionTool {
	// Fields
	char pad_0x88[0x38]; // Offset: 0x88 | Size: 0x38
};

// Object: Class InteractiveToolsFramework.BaseBrushTool
// Inherited Bytes: 0xc0 | Struct Size: 0x1b8
struct UBaseBrushTool : UMeshSurfacePointTool {
	// Fields
	struct UBrushBaseProperties* BrushProperties; // Offset: 0xc0 | Size: 0x8
	bool bInBrushStroke; // Offset: 0xc8 | Size: 0x1
	char pad_0xC9[0x3]; // Offset: 0xc9 | Size: 0x3
	struct FBrushStampData LastBrushStamp; // Offset: 0xcc | Size: 0xa8
	char pad_0x174[0x14]; // Offset: 0x174 | Size: 0x14
	struct TSoftClassPtr<UObject> PropertyClass; // Offset: 0x188 | Size: 0x28
	struct UBrushStampIndicator* BrushStampIndicator; // Offset: 0x1b0 | Size: 0x8
};

// Object: Class InteractiveToolsFramework.BrushStampIndicatorBuilder
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UBrushStampIndicatorBuilder : UInteractiveGizmoBuilder {
};

// Object: Class InteractiveToolsFramework.BrushStampIndicator
// Inherited Bytes: 0x38 | Struct Size: 0xb0
struct UBrushStampIndicator : UInteractiveGizmo {
	// Fields
	float BrushRadius; // Offset: 0x38 | Size: 0x4
	float BrushFalloff; // Offset: 0x3c | Size: 0x4
	struct FVector BrushPosition; // Offset: 0x40 | Size: 0xc
	struct FVector BrushNormal; // Offset: 0x4c | Size: 0xc
	bool bDrawIndicatorLines; // Offset: 0x58 | Size: 0x1
	bool bDrawRadiusCircle; // Offset: 0x59 | Size: 0x1
	bool bDrawFalloffCircle; // Offset: 0x5a | Size: 0x1
	char pad_0x5B[0x1]; // Offset: 0x5b | Size: 0x1
	int32_t SampleStepCount; // Offset: 0x5c | Size: 0x4
	struct FLinearColor LineColor; // Offset: 0x60 | Size: 0x10
	float LineThickness; // Offset: 0x70 | Size: 0x4
	bool bDepthTested; // Offset: 0x74 | Size: 0x1
	bool bDrawSecondaryLines; // Offset: 0x75 | Size: 0x1
	char pad_0x76[0x2]; // Offset: 0x76 | Size: 0x2
	float SecondaryLineThickness; // Offset: 0x78 | Size: 0x4
	struct FLinearColor SecondaryLineColor; // Offset: 0x7c | Size: 0x10
	char pad_0x8C[0x4]; // Offset: 0x8c | Size: 0x4
	struct UPrimitiveComponent* AttachedComponent; // Offset: 0x90 | Size: 0x8
	char pad_0x98[0x18]; // Offset: 0x98 | Size: 0x18
};

// Object: Class InteractiveToolsFramework.ClickDragInputBehavior
// Inherited Bytes: 0x70 | Struct Size: 0x130
struct UClickDragInputBehavior : UAnyButtonInputBehavior {
	// Fields
	char pad_0x70[0xa0]; // Offset: 0x70 | Size: 0xa0
	bool bUpdateModifiersDuringDrag; // Offset: 0x110 | Size: 0x1
	char pad_0x111[0x1f]; // Offset: 0x111 | Size: 0x1f
};

// Object: Class InteractiveToolsFramework.LocalClickDragInputBehavior
// Inherited Bytes: 0x130 | Struct Size: 0x270
struct ULocalClickDragInputBehavior : UClickDragInputBehavior {
	// Fields
	char pad_0x130[0x140]; // Offset: 0x130 | Size: 0x140
};

// Object: Class InteractiveToolsFramework.InteractiveToolBuilder
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UInteractiveToolBuilder : UObject {
};

// Object: Class InteractiveToolsFramework.ClickDragToolBuilder
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UClickDragToolBuilder : UInteractiveToolBuilder {
};

// Object: Class InteractiveToolsFramework.ClickDragTool
// Inherited Bytes: 0x80 | Struct Size: 0x88
struct UClickDragTool : UInteractiveTool {
	// Fields
	char pad_0x80[0x8]; // Offset: 0x80 | Size: 0x8
};

// Object: Class InteractiveToolsFramework.InternalToolFrameworkActor
// Inherited Bytes: 0x228 | Struct Size: 0x228
struct AInternalToolFrameworkActor : AActor {
};

// Object: Class InteractiveToolsFramework.GizmoActor
// Inherited Bytes: 0x228 | Struct Size: 0x228
struct AGizmoActor : AInternalToolFrameworkActor {
};

// Object: Class InteractiveToolsFramework.GizmoBaseComponent
// Inherited Bytes: 0x570 | Struct Size: 0x590
struct UGizmoBaseComponent : UPrimitiveComponent {
	// Fields
	struct FLinearColor Color; // Offset: 0x570 | Size: 0x10
	float HoverSizeMultiplier; // Offset: 0x580 | Size: 0x4
	float PixelHitDistanceThreshold; // Offset: 0x584 | Size: 0x4
	char pad_0x588[0x8]; // Offset: 0x588 | Size: 0x8

	// Functions

	// Object: Function InteractiveToolsFramework.GizmoBaseComponent.UpdateWorldLocalState
	// Flags: [Final|Native|Public]
	// Offset: 0x1058d75a8
	// Return & Params: [ Num(1) Size(0x1) ]
	void UpdateWorldLocalState(bool bWorldIn);

	// Object: Function InteractiveToolsFramework.GizmoBaseComponent.UpdateHoverState
	// Flags: [Final|Native|Public]
	// Offset: 0x1058d7638
	// Return & Params: [ Num(1) Size(0x1) ]
	void UpdateHoverState(bool bHoveringIn);
};

// Object: Class InteractiveToolsFramework.GizmoArrowComponent
// Inherited Bytes: 0x590 | Struct Size: 0x5b0
struct UGizmoArrowComponent : UGizmoBaseComponent {
	// Fields
	struct FVector Direction; // Offset: 0x590 | Size: 0xc
	float Gap; // Offset: 0x59c | Size: 0x4
	float Length; // Offset: 0x5a0 | Size: 0x4
	float Thickness; // Offset: 0x5a4 | Size: 0x4
	char pad_0x5A8[0x8]; // Offset: 0x5a8 | Size: 0x8
};

// Object: Class InteractiveToolsFramework.GizmoBoxComponent
// Inherited Bytes: 0x590 | Struct Size: 0x5d0
struct UGizmoBoxComponent : UGizmoBaseComponent {
	// Fields
	struct FVector Origin; // Offset: 0x590 | Size: 0xc
	char pad_0x59C[0x4]; // Offset: 0x59c | Size: 0x4
	struct FQuat Rotation; // Offset: 0x5a0 | Size: 0x10
	struct FVector Dimensions; // Offset: 0x5b0 | Size: 0xc
	float LineThickness; // Offset: 0x5bc | Size: 0x4
	bool bRemoveHiddenLines; // Offset: 0x5c0 | Size: 0x1
	bool bEnableAxisFlip; // Offset: 0x5c1 | Size: 0x1
	char pad_0x5C2[0xe]; // Offset: 0x5c2 | Size: 0xe
};

// Object: Class InteractiveToolsFramework.GizmoCircleComponent
// Inherited Bytes: 0x590 | Struct Size: 0x5b0
struct UGizmoCircleComponent : UGizmoBaseComponent {
	// Fields
	struct FVector Normal; // Offset: 0x590 | Size: 0xc
	float Radius; // Offset: 0x59c | Size: 0x4
	float Thickness; // Offset: 0x5a0 | Size: 0x4
	int32_t NumSides; // Offset: 0x5a4 | Size: 0x4
	bool bViewAligned; // Offset: 0x5a8 | Size: 0x1
	bool bOnlyAllowFrontFacingHits; // Offset: 0x5a9 | Size: 0x1
	char pad_0x5AA[0x6]; // Offset: 0x5aa | Size: 0x6
};

// Object: Class InteractiveToolsFramework.GizmoTransformSource
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UGizmoTransformSource : UInterface {
	// Functions

	// Object: Function InteractiveToolsFramework.GizmoTransformSource.SetTransform
	// Flags: [Native|Public|HasOutParms|HasDefaults]
	// Offset: 0x1058d7ec8
	// Return & Params: [ Num(1) Size(0x30) ]
	void SetTransform(struct FTransform& NewTransform);

	// Object: Function InteractiveToolsFramework.GizmoTransformSource.GetTransform
	// Flags: [Native|Public|HasDefaults|Const]
	// Offset: 0x1058d7fb0
	// Return & Params: [ Num(1) Size(0x30) ]
	struct FTransform GetTransform();
};

// Object: Class InteractiveToolsFramework.GizmoAxisSource
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UGizmoAxisSource : UInterface {
	// Functions

	// Object: Function InteractiveToolsFramework.GizmoAxisSource.HasTangentVectors
	// Flags: [Native|Public|Const]
	// Offset: 0x1058d852c
	// Return & Params: [ Num(1) Size(0x1) ]
	bool HasTangentVectors();

	// Object: Function InteractiveToolsFramework.GizmoAxisSource.GetTangentVectors
	// Flags: [Native|Public|HasOutParms|HasDefaults|Const]
	// Offset: 0x1058d8440
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetTangentVectors(struct FVector& TangentXOut, struct FVector& TangentYOut);

	// Object: Function InteractiveToolsFramework.GizmoAxisSource.GetOrigin
	// Flags: [Native|Public|HasDefaults|Const]
	// Offset: 0x1058d85a8
	// Return & Params: [ Num(1) Size(0xc) ]
	struct FVector GetOrigin();

	// Object: Function InteractiveToolsFramework.GizmoAxisSource.GetDirection
	// Flags: [Native|Public|HasDefaults|Const]
	// Offset: 0x1058d8568
	// Return & Params: [ Num(1) Size(0xc) ]
	struct FVector GetDirection();
};

// Object: Class InteractiveToolsFramework.GizmoClickTarget
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UGizmoClickTarget : UInterface {
	// Functions

	// Object: Function InteractiveToolsFramework.GizmoClickTarget.UpdateHoverState
	// Flags: [Native|Public|Const]
	// Offset: 0x1058d89dc
	// Return & Params: [ Num(1) Size(0x1) ]
	void UpdateHoverState(bool bHovering);
};

// Object: Class InteractiveToolsFramework.GizmoStateTarget
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UGizmoStateTarget : UInterface {
	// Functions

	// Object: Function InteractiveToolsFramework.GizmoStateTarget.EndUpdate
	// Flags: [Native|Public]
	// Offset: 0x1058d8d7c
	// Return & Params: [ Num(0) Size(0x0) ]
	void EndUpdate();

	// Object: Function InteractiveToolsFramework.GizmoStateTarget.BeginUpdate
	// Flags: [Native|Public]
	// Offset: 0x1058d8d98
	// Return & Params: [ Num(0) Size(0x0) ]
	void BeginUpdate();
};

// Object: Class InteractiveToolsFramework.GizmoFloatParameterSource
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UGizmoFloatParameterSource : UInterface {
	// Functions

	// Object: Function InteractiveToolsFramework.GizmoFloatParameterSource.SetParameter
	// Flags: [Native|Public]
	// Offset: 0x1058d9120
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetParameter(float NewValue);

	// Object: Function InteractiveToolsFramework.GizmoFloatParameterSource.GetParameter
	// Flags: [Native|Public|Const]
	// Offset: 0x1058d91c4
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetParameter();

	// Object: Function InteractiveToolsFramework.GizmoFloatParameterSource.EndModify
	// Flags: [Native|Public]
	// Offset: 0x1058d9104
	// Return & Params: [ Num(0) Size(0x0) ]
	void EndModify();

	// Object: Function InteractiveToolsFramework.GizmoFloatParameterSource.BeginModify
	// Flags: [Native|Public]
	// Offset: 0x1058d91a8
	// Return & Params: [ Num(0) Size(0x0) ]
	void BeginModify();
};

// Object: Class InteractiveToolsFramework.GizmoVec2ParameterSource
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UGizmoVec2ParameterSource : UInterface {
	// Functions

	// Object: Function InteractiveToolsFramework.GizmoVec2ParameterSource.SetParameter
	// Flags: [Native|Public|HasOutParms|HasDefaults]
	// Offset: 0x1058d9604
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetParameter(struct FVector2D& NewValue);

	// Object: Function InteractiveToolsFramework.GizmoVec2ParameterSource.GetParameter
	// Flags: [Native|Public|HasDefaults|Const]
	// Offset: 0x1058d96b0
	// Return & Params: [ Num(1) Size(0x8) ]
	struct FVector2D GetParameter();

	// Object: Function InteractiveToolsFramework.GizmoVec2ParameterSource.EndModify
	// Flags: [Native|Public]
	// Offset: 0x1058d95e8
	// Return & Params: [ Num(0) Size(0x0) ]
	void EndModify();

	// Object: Function InteractiveToolsFramework.GizmoVec2ParameterSource.BeginModify
	// Flags: [Native|Public]
	// Offset: 0x1058d9694
	// Return & Params: [ Num(0) Size(0x0) ]
	void BeginModify();
};

// Object: Class InteractiveToolsFramework.GizmoLineHandleComponent
// Inherited Bytes: 0x590 | Struct Size: 0x5c0
struct UGizmoLineHandleComponent : UGizmoBaseComponent {
	// Fields
	struct FVector Normal; // Offset: 0x590 | Size: 0xc
	float HandleSize; // Offset: 0x59c | Size: 0x4
	float Thickness; // Offset: 0x5a0 | Size: 0x4
	struct FVector Direction; // Offset: 0x5a4 | Size: 0xc
	float Length; // Offset: 0x5b0 | Size: 0x4
	bool bImageScale; // Offset: 0x5b4 | Size: 0x1
	char pad_0x5B5[0xb]; // Offset: 0x5b5 | Size: 0xb
};

// Object: Class InteractiveToolsFramework.GizmoRectangleComponent
// Inherited Bytes: 0x590 | Struct Size: 0x5c0
struct UGizmoRectangleComponent : UGizmoBaseComponent {
	// Fields
	struct FVector DirectionX; // Offset: 0x590 | Size: 0xc
	struct FVector DirectionY; // Offset: 0x59c | Size: 0xc
	float OffsetX; // Offset: 0x5a8 | Size: 0x4
	float OffsetY; // Offset: 0x5ac | Size: 0x4
	float LengthX; // Offset: 0x5b0 | Size: 0x4
	float LengthY; // Offset: 0x5b4 | Size: 0x4
	float Thickness; // Offset: 0x5b8 | Size: 0x4
	char SegmentFlags; // Offset: 0x5bc | Size: 0x1
	char pad_0x5BD[0x3]; // Offset: 0x5bd | Size: 0x3
};

// Object: Class InteractiveToolsFramework.GizmoLambdaHitTarget
// Inherited Bytes: 0x28 | Struct Size: 0xb0
struct UGizmoLambdaHitTarget : UObject {
	// Fields
	char pad_0x28[0x88]; // Offset: 0x28 | Size: 0x88
};

// Object: Class InteractiveToolsFramework.GizmoComponentHitTarget
// Inherited Bytes: 0x28 | Struct Size: 0x80
struct UGizmoComponentHitTarget : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
	struct UPrimitiveComponent* Component; // Offset: 0x30 | Size: 0x8
	char pad_0x38[0x48]; // Offset: 0x38 | Size: 0x48
};

// Object: Class InteractiveToolsFramework.InputBehaviorSet
// Inherited Bytes: 0x28 | Struct Size: 0x38
struct UInputBehaviorSet : UObject {
	// Fields
	struct TArray<struct FBehaviorInfo> Behaviors; // Offset: 0x28 | Size: 0x10
};

// Object: Class InteractiveToolsFramework.InputBehaviorSource
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UInputBehaviorSource : UInterface {
};

// Object: Class InteractiveToolsFramework.InputRouter
// Inherited Bytes: 0x28 | Struct Size: 0xb0
struct UInputRouter : UObject {
	// Fields
	bool bAutoInvalidateOnHover; // Offset: 0x28 | Size: 0x1
	bool bAutoInvalidateOnCapture; // Offset: 0x29 | Size: 0x1
	char pad_0x2A[0xe]; // Offset: 0x2a | Size: 0xe
	struct UInputBehaviorSet* ActiveInputBehaviors; // Offset: 0x38 | Size: 0x8
	char pad_0x40[0x70]; // Offset: 0x40 | Size: 0x70
};

// Object: Class InteractiveToolsFramework.InteractionMechanic
// Inherited Bytes: 0x28 | Struct Size: 0x30
struct UInteractionMechanic : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
};

// Object: Class InteractiveToolsFramework.InteractiveGizmoManager
// Inherited Bytes: 0x28 | Struct Size: 0xb8
struct UInteractiveGizmoManager : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
	struct TArray<struct FActiveGizmo> ActiveGizmos; // Offset: 0x30 | Size: 0x10
	char pad_0x40[0x18]; // Offset: 0x40 | Size: 0x18
	struct TMap<struct FString, struct UInteractiveGizmoBuilder*> GizmoBuilders; // Offset: 0x58 | Size: 0x50
	char pad_0xA8[0x10]; // Offset: 0xa8 | Size: 0x10
};

// Object: Class InteractiveToolsFramework.ToolContextTransactionProvider
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UToolContextTransactionProvider : UInterface {
};

// Object: Class InteractiveToolsFramework.InteractiveToolManager
// Inherited Bytes: 0x28 | Struct Size: 0x138
struct UInteractiveToolManager : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
	struct UInteractiveTool* ActiveLeftTool; // Offset: 0x30 | Size: 0x8
	struct UInteractiveTool* ActiveRightTool; // Offset: 0x38 | Size: 0x8
	char pad_0x40[0x50]; // Offset: 0x40 | Size: 0x50
	struct TMap<struct FString, struct UInteractiveToolBuilder*> ToolBuilders; // Offset: 0x90 | Size: 0x50
	char pad_0xE0[0x58]; // Offset: 0xe0 | Size: 0x58
};

// Object: Class InteractiveToolsFramework.ToolFrameworkComponent
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UToolFrameworkComponent : UInterface {
};

// Object: Class InteractiveToolsFramework.InteractiveToolsContext
// Inherited Bytes: 0x28 | Struct Size: 0x98
struct UInteractiveToolsContext : UObject {
	// Fields
	char pad_0x28[0x30]; // Offset: 0x28 | Size: 0x30
	struct UInputRouter* InputRouter; // Offset: 0x58 | Size: 0x8
	struct UInteractiveToolManager* ToolManager; // Offset: 0x60 | Size: 0x8
	struct UInteractiveGizmoManager* GizmoManager; // Offset: 0x68 | Size: 0x8
	struct TSoftClassPtr<UObject> ToolManagerClass; // Offset: 0x70 | Size: 0x28
};

// Object: Class InteractiveToolsFramework.IntervalGizmoActor
// Inherited Bytes: 0x228 | Struct Size: 0x240
struct AIntervalGizmoActor : AGizmoActor {
	// Fields
	struct UGizmoLineHandleComponent* UpIntervalComponent; // Offset: 0x228 | Size: 0x8
	struct UGizmoLineHandleComponent* DownIntervalComponent; // Offset: 0x230 | Size: 0x8
	struct UGizmoLineHandleComponent* ForwardIntervalComponent; // Offset: 0x238 | Size: 0x8
};

// Object: Class InteractiveToolsFramework.IntervalGizmoBuilder
// Inherited Bytes: 0x28 | Struct Size: 0xc0
struct UIntervalGizmoBuilder : UInteractiveGizmoBuilder {
	// Fields
	char pad_0x28[0x98]; // Offset: 0x28 | Size: 0x98
};

// Object: Class InteractiveToolsFramework.IntervalGizmo
// Inherited Bytes: 0x38 | Struct Size: 0x130
struct UIntervalGizmo : UInteractiveGizmo {
	// Fields
	struct UGizmoTransformChangeStateTarget* StateTarget; // Offset: 0x38 | Size: 0x8
	char pad_0x40[0x10]; // Offset: 0x40 | Size: 0x10
	struct UTransformProxy* TransformProxy; // Offset: 0x50 | Size: 0x8
	struct TArray<struct UPrimitiveComponent*> ActiveComponents; // Offset: 0x58 | Size: 0x10
	struct TArray<struct UInteractiveGizmo*> ActiveGizmos; // Offset: 0x68 | Size: 0x10
	char pad_0x78[0x18]; // Offset: 0x78 | Size: 0x18
	struct UGizmoComponentAxisSource* AxisYSource; // Offset: 0x90 | Size: 0x8
	struct UGizmoComponentAxisSource* AxisZSource; // Offset: 0x98 | Size: 0x8
	char pad_0xA0[0x90]; // Offset: 0xa0 | Size: 0x90
};

// Object: Class InteractiveToolsFramework.GizmoBaseFloatParameterSource
// Inherited Bytes: 0x28 | Struct Size: 0x48
struct UGizmoBaseFloatParameterSource : UObject {
	// Fields
	char pad_0x28[0x20]; // Offset: 0x28 | Size: 0x20
};

// Object: Class InteractiveToolsFramework.GizmoAxisIntervalParameterSource
// Inherited Bytes: 0x48 | Struct Size: 0x60
struct UGizmoAxisIntervalParameterSource : UGizmoBaseFloatParameterSource {
	// Fields
	struct TScriptInterface<IGizmoFloatParameterSource> FloatParameterSource; // Offset: 0x48 | Size: 0x10
	float MinParameter; // Offset: 0x58 | Size: 0x4
	float MaxParameter; // Offset: 0x5c | Size: 0x4
};

// Object: Class InteractiveToolsFramework.KeyAsModifierInputBehavior
// Inherited Bytes: 0x30 | Struct Size: 0x110
struct UKeyAsModifierInputBehavior : UInputBehavior {
	// Fields
	char pad_0x30[0xe0]; // Offset: 0x30 | Size: 0xe0
};

// Object: Class InteractiveToolsFramework.MeshSurfacePointToolBuilder
// Inherited Bytes: 0x28 | Struct Size: 0x30
struct UMeshSurfacePointToolBuilder : UInteractiveToolBuilder {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
};

// Object: Class InteractiveToolsFramework.MouseHoverBehavior
// Inherited Bytes: 0x30 | Struct Size: 0x98
struct UMouseHoverBehavior : UInputBehavior {
	// Fields
	char pad_0x30[0x68]; // Offset: 0x30 | Size: 0x68
};

// Object: Class InteractiveToolsFramework.MultiClickSequenceInputBehavior
// Inherited Bytes: 0x70 | Struct Size: 0x120
struct UMultiClickSequenceInputBehavior : UAnyButtonInputBehavior {
	// Fields
	char pad_0x70[0xb0]; // Offset: 0x70 | Size: 0xb0
};

// Object: Class InteractiveToolsFramework.MultiSelectionTool
// Inherited Bytes: 0x80 | Struct Size: 0x90
struct UMultiSelectionTool : UInteractiveTool {
	// Fields
	char pad_0x80[0x10]; // Offset: 0x80 | Size: 0x10
};

// Object: Class InteractiveToolsFramework.GizmoLocalFloatParameterSource
// Inherited Bytes: 0x48 | Struct Size: 0x58
struct UGizmoLocalFloatParameterSource : UGizmoBaseFloatParameterSource {
	// Fields
	float Value; // Offset: 0x48 | Size: 0x4
	struct FGizmoFloatParameterChange LastChange; // Offset: 0x4c | Size: 0x8
	char pad_0x54[0x4]; // Offset: 0x54 | Size: 0x4
};

// Object: Class InteractiveToolsFramework.GizmoBaseVec2ParameterSource
// Inherited Bytes: 0x28 | Struct Size: 0x48
struct UGizmoBaseVec2ParameterSource : UObject {
	// Fields
	char pad_0x28[0x20]; // Offset: 0x28 | Size: 0x20
};

// Object: Class InteractiveToolsFramework.GizmoLocalVec2ParameterSource
// Inherited Bytes: 0x48 | Struct Size: 0x60
struct UGizmoLocalVec2ParameterSource : UGizmoBaseVec2ParameterSource {
	// Fields
	struct FVector2D Value; // Offset: 0x48 | Size: 0x8
	struct FGizmoVec2ParameterChange LastChange; // Offset: 0x50 | Size: 0x10
};

// Object: Class InteractiveToolsFramework.GizmoAxisTranslationParameterSource
// Inherited Bytes: 0x48 | Struct Size: 0x110
struct UGizmoAxisTranslationParameterSource : UGizmoBaseFloatParameterSource {
	// Fields
	char pad_0x48[0x48]; // Offset: 0x48 | Size: 0x48
	struct TScriptInterface<IGizmoAxisSource> AxisSource; // Offset: 0x90 | Size: 0x10
	struct TScriptInterface<IGizmoTransformSource> TransformSource; // Offset: 0xa0 | Size: 0x10
	float Parameter; // Offset: 0xb0 | Size: 0x4
	struct FGizmoFloatParameterChange LastChange; // Offset: 0xb4 | Size: 0x8
	struct FVector CurTranslationAxis; // Offset: 0xbc | Size: 0xc
	struct FVector CurTranslationOrigin; // Offset: 0xc8 | Size: 0xc
	char pad_0xD4[0xc]; // Offset: 0xd4 | Size: 0xc
	struct FTransform InitialTransform; // Offset: 0xe0 | Size: 0x30
};

// Object: Class InteractiveToolsFramework.GizmoPlaneTranslationParameterSource
// Inherited Bytes: 0x48 | Struct Size: 0x130
struct UGizmoPlaneTranslationParameterSource : UGizmoBaseVec2ParameterSource {
	// Fields
	char pad_0x48[0x48]; // Offset: 0x48 | Size: 0x48
	struct TScriptInterface<IGizmoAxisSource> AxisSource; // Offset: 0x90 | Size: 0x10
	struct TScriptInterface<IGizmoTransformSource> TransformSource; // Offset: 0xa0 | Size: 0x10
	struct FVector2D Parameter; // Offset: 0xb0 | Size: 0x8
	struct FGizmoVec2ParameterChange LastChange; // Offset: 0xb8 | Size: 0x10
	struct FVector CurTranslationOrigin; // Offset: 0xc8 | Size: 0xc
	struct FVector CurTranslationNormal; // Offset: 0xd4 | Size: 0xc
	struct FVector CurTranslationAxisX; // Offset: 0xe0 | Size: 0xc
	struct FVector CurTranslationAxisY; // Offset: 0xec | Size: 0xc
	char pad_0xF8[0x8]; // Offset: 0xf8 | Size: 0x8
	struct FTransform InitialTransform; // Offset: 0x100 | Size: 0x30
};

// Object: Class InteractiveToolsFramework.GizmoAxisRotationParameterSource
// Inherited Bytes: 0x48 | Struct Size: 0xc0
struct UGizmoAxisRotationParameterSource : UGizmoBaseFloatParameterSource {
	// Fields
	struct TScriptInterface<IGizmoAxisSource> AxisSource; // Offset: 0x48 | Size: 0x10
	struct TScriptInterface<IGizmoTransformSource> TransformSource; // Offset: 0x58 | Size: 0x10
	float Angle; // Offset: 0x68 | Size: 0x4
	struct FGizmoFloatParameterChange LastChange; // Offset: 0x6c | Size: 0x8
	struct FVector CurRotationAxis; // Offset: 0x74 | Size: 0xc
	struct FVector CurRotationOrigin; // Offset: 0x80 | Size: 0xc
	char pad_0x8C[0x4]; // Offset: 0x8c | Size: 0x4
	struct FTransform InitialTransform; // Offset: 0x90 | Size: 0x30
};

// Object: Class InteractiveToolsFramework.GizmoUniformScaleParameterSource
// Inherited Bytes: 0x48 | Struct Size: 0xf0
struct UGizmoUniformScaleParameterSource : UGizmoBaseVec2ParameterSource {
	// Fields
	struct TScriptInterface<IGizmoAxisSource> AxisSource; // Offset: 0x48 | Size: 0x10
	struct TScriptInterface<IGizmoTransformSource> TransformSource; // Offset: 0x58 | Size: 0x10
	float ScaleMultiplier; // Offset: 0x68 | Size: 0x4
	struct FVector2D Parameter; // Offset: 0x6c | Size: 0x8
	struct FGizmoVec2ParameterChange LastChange; // Offset: 0x74 | Size: 0x10
	struct FVector CurScaleOrigin; // Offset: 0x84 | Size: 0xc
	struct FVector CurScaleNormal; // Offset: 0x90 | Size: 0xc
	struct FVector CurScaleAxisX; // Offset: 0x9c | Size: 0xc
	struct FVector CurScaleAxisY; // Offset: 0xa8 | Size: 0xc
	char pad_0xB4[0xc]; // Offset: 0xb4 | Size: 0xc
	struct FTransform InitialTransform; // Offset: 0xc0 | Size: 0x30
};

// Object: Class InteractiveToolsFramework.GizmoAxisScaleParameterSource
// Inherited Bytes: 0x48 | Struct Size: 0xc0
struct UGizmoAxisScaleParameterSource : UGizmoBaseFloatParameterSource {
	// Fields
	struct TScriptInterface<IGizmoAxisSource> AxisSource; // Offset: 0x48 | Size: 0x10
	struct TScriptInterface<IGizmoTransformSource> TransformSource; // Offset: 0x58 | Size: 0x10
	float ScaleMultiplier; // Offset: 0x68 | Size: 0x4
	float Parameter; // Offset: 0x6c | Size: 0x4
	struct FGizmoFloatParameterChange LastChange; // Offset: 0x70 | Size: 0x8
	struct FVector CurScaleAxis; // Offset: 0x78 | Size: 0xc
	struct FVector CurScaleOrigin; // Offset: 0x84 | Size: 0xc
	struct FTransform InitialTransform; // Offset: 0x90 | Size: 0x30
};

// Object: Class InteractiveToolsFramework.GizmoPlaneScaleParameterSource
// Inherited Bytes: 0x48 | Struct Size: 0x130
struct UGizmoPlaneScaleParameterSource : UGizmoBaseVec2ParameterSource {
	// Fields
	char pad_0x48[0x48]; // Offset: 0x48 | Size: 0x48
	struct TScriptInterface<IGizmoAxisSource> AxisSource; // Offset: 0x90 | Size: 0x10
	struct TScriptInterface<IGizmoTransformSource> TransformSource; // Offset: 0xa0 | Size: 0x10
	float ScaleMultiplier; // Offset: 0xb0 | Size: 0x4
	struct FVector2D Parameter; // Offset: 0xb4 | Size: 0x8
	struct FGizmoVec2ParameterChange LastChange; // Offset: 0xbc | Size: 0x10
	struct FVector CurScaleOrigin; // Offset: 0xcc | Size: 0xc
	struct FVector CurScaleNormal; // Offset: 0xd8 | Size: 0xc
	struct FVector CurScaleAxisX; // Offset: 0xe4 | Size: 0xc
	struct FVector CurScaleAxisY; // Offset: 0xf0 | Size: 0xc
	char pad_0xFC[0x4]; // Offset: 0xfc | Size: 0x4
	struct FTransform InitialTransform; // Offset: 0x100 | Size: 0x30
};

// Object: Class InteractiveToolsFramework.PlanePositionGizmoBuilder
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UPlanePositionGizmoBuilder : UInteractiveGizmoBuilder {
};

// Object: Class InteractiveToolsFramework.PlanePositionGizmo
// Inherited Bytes: 0x38 | Struct Size: 0x100
struct UPlanePositionGizmo : UInteractiveGizmo {
	// Fields
	char pad_0x38[0x10]; // Offset: 0x38 | Size: 0x10
	struct TScriptInterface<IGizmoAxisSource> AxisSource; // Offset: 0x48 | Size: 0x10
	struct TScriptInterface<IGizmoVec2ParameterSource> ParameterSource; // Offset: 0x58 | Size: 0x10
	struct TScriptInterface<IGizmoClickTarget> HitTarget; // Offset: 0x68 | Size: 0x10
	struct TScriptInterface<IGizmoStateTarget> StateTarget; // Offset: 0x78 | Size: 0x10
	bool bEnableSignedAxis; // Offset: 0x88 | Size: 0x1
	bool bFlipX; // Offset: 0x89 | Size: 0x1
	bool bFlipY; // Offset: 0x8a | Size: 0x1
	bool bInInteraction; // Offset: 0x8b | Size: 0x1
	struct FVector InteractionOrigin; // Offset: 0x8c | Size: 0xc
	struct FVector InteractionNormal; // Offset: 0x98 | Size: 0xc
	struct FVector InteractionAxisX; // Offset: 0xa4 | Size: 0xc
	struct FVector InteractionAxisY; // Offset: 0xb0 | Size: 0xc
	struct FVector InteractionStartPoint; // Offset: 0xbc | Size: 0xc
	struct FVector InteractionCurPoint; // Offset: 0xc8 | Size: 0xc
	struct FVector2D InteractionStartParameter; // Offset: 0xd4 | Size: 0x8
	struct FVector2D InteractionCurParameter; // Offset: 0xdc | Size: 0x8
	struct FVector2D ParameterSigns; // Offset: 0xe4 | Size: 0x8
	char pad_0xEC[0x14]; // Offset: 0xec | Size: 0x14
};

// Object: Class InteractiveToolsFramework.SelectionSet
// Inherited Bytes: 0x28 | Struct Size: 0x40
struct USelectionSet : UObject {
	// Fields
	char pad_0x28[0x18]; // Offset: 0x28 | Size: 0x18
};

// Object: Class InteractiveToolsFramework.MeshSelectionSet
// Inherited Bytes: 0x40 | Struct Size: 0x80
struct UMeshSelectionSet : USelectionSet {
	// Fields
	struct TArray<int32_t> Vertices; // Offset: 0x40 | Size: 0x10
	struct TArray<int32_t> Edges; // Offset: 0x50 | Size: 0x10
	struct TArray<int32_t> Faces; // Offset: 0x60 | Size: 0x10
	struct TArray<int32_t> Groups; // Offset: 0x70 | Size: 0x10
};

// Object: Class InteractiveToolsFramework.SingleClickInputBehavior
// Inherited Bytes: 0x70 | Struct Size: 0x120
struct USingleClickInputBehavior : UAnyButtonInputBehavior {
	// Fields
	char pad_0x70[0x40]; // Offset: 0x70 | Size: 0x40
	bool HitTestOnRelease; // Offset: 0xb0 | Size: 0x1
	char pad_0xB1[0x6f]; // Offset: 0xb1 | Size: 0x6f
};

// Object: Class InteractiveToolsFramework.SingleClickToolBuilder
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct USingleClickToolBuilder : UInteractiveToolBuilder {
};

// Object: Class InteractiveToolsFramework.SingleClickTool
// Inherited Bytes: 0x80 | Struct Size: 0x88
struct USingleClickTool : UInteractiveTool {
	// Fields
	char pad_0x80[0x8]; // Offset: 0x80 | Size: 0x8
};

// Object: Class InteractiveToolsFramework.GizmoNilStateTarget
// Inherited Bytes: 0x28 | Struct Size: 0x30
struct UGizmoNilStateTarget : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
};

// Object: Class InteractiveToolsFramework.GizmoLambdaStateTarget
// Inherited Bytes: 0x28 | Struct Size: 0xb0
struct UGizmoLambdaStateTarget : UObject {
	// Fields
	char pad_0x28[0x88]; // Offset: 0x28 | Size: 0x88
};

// Object: Class InteractiveToolsFramework.GizmoObjectModifyStateTarget
// Inherited Bytes: 0x28 | Struct Size: 0x58
struct UGizmoObjectModifyStateTarget : UObject {
	// Fields
	char pad_0x28[0x30]; // Offset: 0x28 | Size: 0x30
};

// Object: Class InteractiveToolsFramework.GizmoTransformChangeStateTarget
// Inherited Bytes: 0x28 | Struct Size: 0xe0
struct UGizmoTransformChangeStateTarget : UObject {
	// Fields
	char pad_0x28[0x28]; // Offset: 0x28 | Size: 0x28
	struct TScriptInterface<IToolContextTransactionProvider> TransactionManager; // Offset: 0x50 | Size: 0x10
	char pad_0x60[0x80]; // Offset: 0x60 | Size: 0x80
};

// Object: Class InteractiveToolsFramework.TransformGizmoActor
// Inherited Bytes: 0x228 | Struct Size: 0x2a8
struct ATransformGizmoActor : AGizmoActor {
	// Fields
	struct UPrimitiveComponent* TranslateX; // Offset: 0x228 | Size: 0x8
	struct UPrimitiveComponent* TranslateY; // Offset: 0x230 | Size: 0x8
	struct UPrimitiveComponent* TranslateZ; // Offset: 0x238 | Size: 0x8
	struct UPrimitiveComponent* TranslateYZ; // Offset: 0x240 | Size: 0x8
	struct UPrimitiveComponent* TranslateXZ; // Offset: 0x248 | Size: 0x8
	struct UPrimitiveComponent* TranslateXY; // Offset: 0x250 | Size: 0x8
	struct UPrimitiveComponent* RotateX; // Offset: 0x258 | Size: 0x8
	struct UPrimitiveComponent* RotateY; // Offset: 0x260 | Size: 0x8
	struct UPrimitiveComponent* RotateZ; // Offset: 0x268 | Size: 0x8
	struct UPrimitiveComponent* UniformScale; // Offset: 0x270 | Size: 0x8
	struct UPrimitiveComponent* AxisScaleX; // Offset: 0x278 | Size: 0x8
	struct UPrimitiveComponent* AxisScaleY; // Offset: 0x280 | Size: 0x8
	struct UPrimitiveComponent* AxisScaleZ; // Offset: 0x288 | Size: 0x8
	struct UPrimitiveComponent* PlaneScaleYZ; // Offset: 0x290 | Size: 0x8
	struct UPrimitiveComponent* PlaneScaleXZ; // Offset: 0x298 | Size: 0x8
	struct UPrimitiveComponent* PlaneScaleXY; // Offset: 0x2a0 | Size: 0x8
};

// Object: Class InteractiveToolsFramework.TransformGizmoBuilder
// Inherited Bytes: 0x28 | Struct Size: 0xc0
struct UTransformGizmoBuilder : UInteractiveGizmoBuilder {
	// Fields
	char pad_0x28[0x98]; // Offset: 0x28 | Size: 0x98
};

// Object: Class InteractiveToolsFramework.TransformGizmo
// Inherited Bytes: 0x38 | Struct Size: 0x180
struct UTransformGizmo : UInteractiveGizmo {
	// Fields
	char pad_0x38[0x8]; // Offset: 0x38 | Size: 0x8
	struct UTransformProxy* ActiveTarget; // Offset: 0x40 | Size: 0x8
	bool bSnapToWorldGrid; // Offset: 0x48 | Size: 0x1
	bool bUseContextCoordinateSystem; // Offset: 0x49 | Size: 0x1
	char pad_0x4A[0x2]; // Offset: 0x4a | Size: 0x2
	enum class EToolContextCoordinateSystem CurrentCoordinateSystem; // Offset: 0x4c | Size: 0x4
	char pad_0x50[0x90]; // Offset: 0x50 | Size: 0x90
	struct TArray<struct UPrimitiveComponent*> ActiveComponents; // Offset: 0xe0 | Size: 0x10
	struct TArray<struct UPrimitiveComponent*> NonuniformScaleComponents; // Offset: 0xf0 | Size: 0x10
	struct TArray<struct UInteractiveGizmo*> ActiveGizmos; // Offset: 0x100 | Size: 0x10
	char pad_0x110[0x10]; // Offset: 0x110 | Size: 0x10
	struct UGizmoConstantFrameAxisSource* CameraAxisSource; // Offset: 0x120 | Size: 0x8
	struct UGizmoComponentAxisSource* AxisXSource; // Offset: 0x128 | Size: 0x8
	struct UGizmoComponentAxisSource* AxisYSource; // Offset: 0x130 | Size: 0x8
	struct UGizmoComponentAxisSource* AxisZSource; // Offset: 0x138 | Size: 0x8
	struct UGizmoComponentAxisSource* UnitAxisXSource; // Offset: 0x140 | Size: 0x8
	struct UGizmoComponentAxisSource* UnitAxisYSource; // Offset: 0x148 | Size: 0x8
	struct UGizmoComponentAxisSource* UnitAxisZSource; // Offset: 0x150 | Size: 0x8
	struct UGizmoTransformChangeStateTarget* StateTarget; // Offset: 0x158 | Size: 0x8
	struct UGizmoScaledTransformSource* ScaledTransformSource; // Offset: 0x160 | Size: 0x8
	char pad_0x168[0x18]; // Offset: 0x168 | Size: 0x18
};

// Object: Class InteractiveToolsFramework.TransformProxy
// Inherited Bytes: 0x28 | Struct Size: 0xf0
struct UTransformProxy : UObject {
	// Fields
	char pad_0x28[0x48]; // Offset: 0x28 | Size: 0x48
	bool bRotatePerObject; // Offset: 0x70 | Size: 0x1
	bool bSetPivotMode; // Offset: 0x71 | Size: 0x1
	char pad_0x72[0x1e]; // Offset: 0x72 | Size: 0x1e
	struct FTransform SharedTransform; // Offset: 0x90 | Size: 0x30
	struct FTransform InitialSharedTransform; // Offset: 0xc0 | Size: 0x30
};

// Object: Class InteractiveToolsFramework.GizmoBaseTransformSource
// Inherited Bytes: 0x28 | Struct Size: 0x48
struct UGizmoBaseTransformSource : UObject {
	// Fields
	char pad_0x28[0x20]; // Offset: 0x28 | Size: 0x20
};

// Object: Class InteractiveToolsFramework.GizmoComponentWorldTransformSource
// Inherited Bytes: 0x48 | Struct Size: 0x58
struct UGizmoComponentWorldTransformSource : UGizmoBaseTransformSource {
	// Fields
	struct USceneComponent* Component; // Offset: 0x48 | Size: 0x8
	bool bModifyComponentOnTransform; // Offset: 0x50 | Size: 0x1
	char pad_0x51[0x7]; // Offset: 0x51 | Size: 0x7
};

// Object: Class InteractiveToolsFramework.GizmoScaledTransformSource
// Inherited Bytes: 0x48 | Struct Size: 0xe0
struct UGizmoScaledTransformSource : UGizmoBaseTransformSource {
	// Fields
	struct TScriptInterface<IGizmoTransformSource> ChildTransformSource; // Offset: 0x48 | Size: 0x10
	char pad_0x58[0x88]; // Offset: 0x58 | Size: 0x88
};

// Object: Class InteractiveToolsFramework.GizmoTransformProxyTransformSource
// Inherited Bytes: 0x48 | Struct Size: 0x50
struct UGizmoTransformProxyTransformSource : UGizmoBaseTransformSource {
	// Fields
	struct UTransformProxy* Proxy; // Offset: 0x48 | Size: 0x8
};

