#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class LLHSDK.LLHSDKAppUtils
// Inherited Bytes: 0x28 | Struct Size: 0x38
struct ULLHSDKAppUtils : UObject {
	// Fields
	struct FMulticastInlineDelegate OnSteamUserStatesUpdate; // Offset: 0x28 | Size: 0x10

	// Functions

	// Object: Function LLHSDK.LLHSDKAppUtils.ShowSteamVirtualKeyboard
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10156cfd4
	// Return & Params: [ Num(1) Size(0x1) ]
	bool ShowSteamVirtualKeyboard();

	// Object: Function LLHSDK.LLHSDKAppUtils.SDKConfigIsMultiDetect
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10156d788
	// Return & Params: [ Num(1) Size(0x1) ]
	bool SDKConfigIsMultiDetect();

	// Object: Function LLHSDK.LLHSDKAppUtils.SDKConfigIsDebug
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10156d7bc
	// Return & Params: [ Num(1) Size(0x1) ]
	bool SDKConfigIsDebug();

	// Object: DelegateFunction LLHSDK.LLHSDKAppUtils.OnSteamUserStatesUpdate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(4) Size(0x28) ]
	void OnSteamUserStatesUpdate__DelegateSignature(struct FString SteamId, bool IsFriend, bool Online, struct FString FriendName);

	// Object: Function LLHSDK.LLHSDKAppUtils.IsSteamFriendOnline
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10156d1c4
	// Return & Params: [ Num(2) Size(0x11) ]
	bool IsSteamFriendOnline(struct FString SteamId);

	// Object: Function LLHSDK.LLHSDKAppUtils.IsSimulator
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10156d530
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsSimulator();

	// Object: Function LLHSDK.LLHSDKAppUtils.IsPlatformSteamDeck
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10156d008
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsPlatformSteamDeck();

	// Object: Function LLHSDK.LLHSDKAppUtils.IsPackageInstalled
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10156d618
	// Return & Params: [ Num(2) Size(0x11) ]
	bool IsPackageInstalled(struct FString InPackageName);

	// Object: Function LLHSDK.LLHSDKAppUtils.IsGrayRelease
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10156d4fc
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsGrayRelease();

	// Object: Function LLHSDK.LLHSDKAppUtils.InviteSteamUserToGame
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10156d408
	// Return & Params: [ Num(2) Size(0x11) ]
	bool InviteSteamUserToGame(struct FString SteamId);

	// Object: Function LLHSDK.LLHSDKAppUtils.GetVersionName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10156db70
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetVersionName();

	// Object: Function LLHSDK.LLHSDKAppUtils.GetVersionCode
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10156dbf0
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetVersionCode();

	// Object: Function LLHSDK.LLHSDKAppUtils.GetSteamFriendsOnlineList
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10156d050
	// Return & Params: [ Num(1) Size(0x10) ]
	struct TArray<bool> GetSteamFriendsOnlineList();

	// Object: Function LLHSDK.LLHSDKAppUtils.GetSteamFriendsNameList
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10156d0d0
	// Return & Params: [ Num(1) Size(0x10) ]
	struct TArray<struct FString> GetSteamFriendsNameList();

	// Object: Function LLHSDK.LLHSDKAppUtils.GetSteamFriendName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10156d250
	// Return & Params: [ Num(2) Size(0x20) ]
	struct FString GetSteamFriendName(struct FString SteamId);

	// Object: Function LLHSDK.LLHSDKAppUtils.GetSteamFriendIDList
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10156d314
	// Return & Params: [ Num(1) Size(0x10) ]
	struct TArray<struct FString> GetSteamFriendIDList();

	// Object: Function LLHSDK.LLHSDKAppUtils.GetSteamFriendCount
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10156d494
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetSteamFriendCount();

	// Object: Function LLHSDK.LLHSDKAppUtils.GetSDKVersionName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10156da70
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetSDKVersionName();

	// Object: Function LLHSDK.LLHSDKAppUtils.GetSDKVersionCode
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10156daf0
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetSDKVersionCode();

	// Object: Function LLHSDK.LLHSDKAppUtils.GetRunningProcessName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10156d598
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetRunningProcessName();

	// Object: Function LLHSDK.LLHSDKAppUtils.GetOperatingSystemId
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10156dcf0
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetOperatingSystemId();

	// Object: Function LLHSDK.LLHSDKAppUtils.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10156de04
	// Return & Params: [ Num(1) Size(0x8) ]
	struct ULLHSDKAppUtils* GetInstance();

	// Object: Function LLHSDK.LLHSDKAppUtils.GetGameTime
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10156d564
	// Return & Params: [ Num(1) Size(0x8) ]
	int64_t GetGameTime();

	// Object: Function LLHSDK.LLHSDKAppUtils.GetGameID
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10156d7f0
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetGameID();

	// Object: Function LLHSDK.LLHSDKAppUtils.GetEnvId
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10156d708
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetEnvId();

	// Object: Function LLHSDK.LLHSDKAppUtils.GetDeviceUUID
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10156dd70
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetDeviceUUID();

	// Object: Function LLHSDK.LLHSDKAppUtils.GetChannelID
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10156d870
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetChannelID();

	// Object: Function LLHSDK.LLHSDKAppUtils.GetBiosUUID
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10156dc70
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetBiosUUID();

	// Object: Function LLHSDK.LLHSDKAppUtils.GetAppName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10156d8f0
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetAppName();

	// Object: Function LLHSDK.LLHSDKAppUtils.GetAppIDRaw
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10156d970
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetAppIDRaw();

	// Object: Function LLHSDK.LLHSDKAppUtils.GetAppID
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10156d9f0
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetAppID();

	// Object: Function LLHSDK.LLHSDKAppUtils.DoesDistributeForDomestic
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10156d4c8
	// Return & Params: [ Num(1) Size(0x1) ]
	bool DoesDistributeForDomestic();

	// Object: Function LLHSDK.LLHSDKAppUtils.DismissSteamVirtualKeyboard
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10156cfc0
	// Return & Params: [ Num(0) Size(0x0) ]
	void DismissSteamVirtualKeyboard();

	// Object: Function LLHSDK.LLHSDKAppUtils.DestoryInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10156ddf0
	// Return & Params: [ Num(0) Size(0x0) ]
	void DestoryInstance();

	// Object: Function LLHSDK.LLHSDKAppUtils.BindOnlineSubsystemSteamPresence
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10156d03c
	// Return & Params: [ Num(0) Size(0x0) ]
	void BindOnlineSubsystemSteamPresence();
};

// Object: Class LLHSDK.LLHSDKCommunity
// Inherited Bytes: 0x28 | Struct Size: 0x78
struct ULLHSDKCommunity : UObject {
	// Fields
	struct FMulticastInlineDelegate OnInitCommunity; // Offset: 0x28 | Size: 0x10
	struct FMulticastInlineDelegate OnExitCommunity; // Offset: 0x38 | Size: 0x10
	struct FMulticastInlineDelegate OnGetCommunityRedhint; // Offset: 0x48 | Size: 0x10
	struct FMulticastInlineDelegate OnClearCommunityRedhint; // Offset: 0x58 | Size: 0x10
	struct FMulticastInlineDelegate OnImageDownload; // Offset: 0x68 | Size: 0x10

	// Functions

	// Object: DelegateFunction LLHSDK.LLHSDKCommunity.OnInitCommunity__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(1) Size(0x10) ]
	void OnInitCommunity__DelegateSignature(struct FString ResultStr);

	// Object: DelegateFunction LLHSDK.LLHSDKCommunity.OnImageDownload__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnImageDownload__DelegateSignature(bool bSuccess);

	// Object: DelegateFunction LLHSDK.LLHSDKCommunity.OnGetCommunityRedhint__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(1) Size(0x10) ]
	void OnGetCommunityRedhint__DelegateSignature(struct FString ResultStr);

	// Object: DelegateFunction LLHSDK.LLHSDKCommunity.OnExitCommunity__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(1) Size(0x10) ]
	void OnExitCommunity__DelegateSignature(struct FString ResultStr);

	// Object: DelegateFunction LLHSDK.LLHSDKCommunity.OnClearCommunityRedhint__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(1) Size(0x10) ]
	void OnClearCommunityRedhint__DelegateSignature(struct FString ResultStr);

	// Object: Function LLHSDK.LLHSDKCommunity.InitCommunityConfig
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10156f308
	// Return & Params: [ Num(3) Size(0x30) ]
	void InitCommunityConfig(struct FString UrlInfo, struct FString ReqMethod, struct FString ExtraHttpParams);

	// Object: Function LLHSDK.LLHSDKCommunity.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10156f450
	// Return & Params: [ Num(1) Size(0x8) ]
	struct ULLHSDKCommunity* GetInstance();

	// Object: Function LLHSDK.LLHSDKCommunity.GetCommunityRedHint
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10156f0a0
	// Return & Params: [ Num(3) Size(0x30) ]
	void GetCommunityRedHint(struct FString URL, struct FString ReqMethod, struct FString ExtraHttpParams);

	// Object: Function LLHSDK.LLHSDKCommunity.ExitCommunity
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10156f1d4
	// Return & Params: [ Num(3) Size(0x30) ]
	void ExitCommunity(struct FString URL, struct FString ReqMethod, struct FString ExtraHttpParams);

	// Object: Function LLHSDK.LLHSDKCommunity.DownloadImage
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10156ee90
	// Return & Params: [ Num(2) Size(0x20) ]
	void DownloadImage(struct FString URL, struct FString FilePath);

	// Object: Function LLHSDK.LLHSDKCommunity.DestoryInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10156f43c
	// Return & Params: [ Num(0) Size(0x0) ]
	void DestoryInstance();

	// Object: Function LLHSDK.LLHSDKCommunity.ClearCommunityRedHint
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10156ef6c
	// Return & Params: [ Num(3) Size(0x30) ]
	void ClearCommunityRedHint(struct FString URL, struct FString ReqMethod, struct FString ExtraHttpParams);
};

// Object: Class LLHSDK.LLHSDKCustomerService
// Inherited Bytes: 0x28 | Struct Size: 0x40
struct ULLHSDKCustomerService : UObject {
	// Fields
	struct FMulticastInlineDelegate OnReceiveNotification; // Offset: 0x28 | Size: 0x10
	char pad_0x38[0x8]; // Offset: 0x38 | Size: 0x8

	// Functions

	// Object: Function LLHSDK.LLHSDKCustomerService.ShowCustomerServicePage
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10156fb18
	// Return & Params: [ Num(1) Size(0x10) ]
	void ShowCustomerServicePage(struct FString ExtInfoStr);

	// Object: Function LLHSDK.LLHSDKCustomerService.SetCustomerServiceDebug
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10156f9f8
	// Return & Params: [ Num(3) Size(0x20) ]
	void SetCustomerServiceDebug(bool& bIsPspDebug, struct FString PlayerId, int64_t ServerId);

	// Object: DelegateFunction LLHSDK.LLHSDKCustomerService.OnReceiveNotification__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(1) Size(0x4) ]
	void OnReceiveNotification__DelegateSignature(int32_t NotificationType);

	// Object: Function LLHSDK.LLHSDKCustomerService.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10156fbb0
	// Return & Params: [ Num(1) Size(0x8) ]
	struct ULLHSDKCustomerService* GetInstance();

	// Object: Function LLHSDK.LLHSDKCustomerService.DestoryInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10156fb9c
	// Return & Params: [ Num(0) Size(0x0) ]
	void DestoryInstance();
};

// Object: Class LLHSDK.LLHSDKDeviceUtils
// Inherited Bytes: 0x28 | Struct Size: 0x48
struct ULLHSDKDeviceUtils : UObject {
	// Fields
	struct FMulticastInlineDelegate OnGoogleAdID; // Offset: 0x28 | Size: 0x10
	struct FMulticastInlineDelegate OnDeviceScore; // Offset: 0x38 | Size: 0x10

	// Functions

	// Object: DelegateFunction LLHSDK.LLHSDKDeviceUtils.OnGoogleAdID__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(1) Size(0x10) ]
	void OnGoogleAdID__DelegateSignature(struct FString GoogleAdID);

	// Object: DelegateFunction LLHSDK.LLHSDKDeviceUtils.OnDeviceScore__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(1) Size(0x4) ]
	void OnDeviceScore__DelegateSignature(int32_t DeviceScore);

	// Object: Function LLHSDK.LLHSDKDeviceUtils.IsEmulator
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101573d4c
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsEmulator();

	// Object: Function LLHSDK.LLHSDKDeviceUtils.GetTotalRAM
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101573c4c
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetTotalRAM();

	// Object: Function LLHSDK.LLHSDKDeviceUtils.GetTotalMemorySize
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101573d80
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetTotalMemorySize();

	// Object: Function LLHSDK.LLHSDKDeviceUtils.GetTimezoneName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101573f00
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetTimezoneName();

	// Object: Function LLHSDK.LLHSDKDeviceUtils.GetOSVersion
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101573f80
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetOSVersion();

	// Object: Function LLHSDK.LLHSDKDeviceUtils.GetNetworkTypeEnum
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101574200
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class ELLHSDKNetworkType GetNetworkTypeEnum();

	// Object: Function LLHSDK.LLHSDKDeviceUtils.GetNetworkType
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101574234
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetNetworkType();

	// Object: Function LLHSDK.LLHSDKDeviceUtils.GetMacAddress
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1015742b4
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetMacAddress();

	// Object: Function LLHSDK.LLHSDKDeviceUtils.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10157455c
	// Return & Params: [ Num(1) Size(0x8) ]
	struct ULLHSDKDeviceUtils* GetInstance();

	// Object: Function LLHSDK.LLHSDKDeviceUtils.GetIMSI
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101574180
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetIMSI();

	// Object: Function LLHSDK.LLHSDKDeviceUtils.GetIDFA
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1015743c8
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetIDFA();

	// Object: Function LLHSDK.LLHSDKDeviceUtils.GetGoogleAdID
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1015743b4
	// Return & Params: [ Num(0) Size(0x0) ]
	void GetGoogleAdID();

	// Object: Function LLHSDK.LLHSDKDeviceUtils.GetDisplayMetrics
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101573ab8
	// Return & Params: [ Num(1) Size(0x10) ]
	struct TArray<float> GetDisplayMetrics();

	// Object: Function LLHSDK.LLHSDKDeviceUtils.GetDisplayCutout
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101573b38
	// Return & Params: [ Num(1) Size(0x10) ]
	struct TArray<float> GetDisplayCutout();

	// Object: Function LLHSDK.LLHSDKDeviceUtils.GetDeviceType
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101574100
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetDeviceType();

	// Object: Function LLHSDK.LLHSDKDeviceUtils.GetDeviceScore
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101573bb8
	// Return & Params: [ Num(0) Size(0x0) ]
	void GetDeviceScore();

	// Object: Function LLHSDK.LLHSDKDeviceUtils.GetDeviceModel
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101574000
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetDeviceModel();

	// Object: Function LLHSDK.LLHSDKDeviceUtils.GetDeviceID
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1015744c8
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetDeviceID();

	// Object: Function LLHSDK.LLHSDKDeviceUtils.GetDeviceCarrier
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101574334
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetDeviceCarrier();

	// Object: Function LLHSDK.LLHSDKDeviceUtils.GetDeviceBrand
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101574080
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetDeviceBrand();

	// Object: Function LLHSDK.LLHSDKDeviceUtils.GetDeviceAbi
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101573ccc
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetDeviceAbi();

	// Object: Function LLHSDK.LLHSDKDeviceUtils.GetCPUModel
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101573e80
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetCPUModel();

	// Object: Function LLHSDK.LLHSDKDeviceUtils.GetCPUHardWareName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101573e00
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetCPUHardWareName();

	// Object: Function LLHSDK.LLHSDKDeviceUtils.GetAvailableRAM
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101573bcc
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetAvailableRAM();

	// Object: Function LLHSDK.LLHSDKDeviceUtils.GetAndroidID
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101574448
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetAndroidID();

	// Object: Function LLHSDK.LLHSDKDeviceUtils.DestoryInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101574548
	// Return & Params: [ Num(0) Size(0x0) ]
	void DestoryInstance();
};

// Object: Class LLHSDK.LLHSDKLocalization
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct ULLHSDKLocalization : UObject {
	// Functions

	// Object: Function LLHSDK.LLHSDKLocalization.SetLocaleName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1015751b4
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetLocaleName(struct FString InLocale);

	// Object: Function LLHSDK.LLHSDKLocalization.SetLocale
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101575290
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetLocale(enum class ELLHSDKSupportedLanguage InLocale);

	// Object: Function LLHSDK.LLHSDKLocalization.GetLocaleName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10157505c
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetLocaleName();

	// Object: Function LLHSDK.LLHSDKLocalization.GetLocaleInfo
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1015750dc
	// Return & Params: [ Num(1) Size(0x20) ]
	struct FLLHSDKLocaleInfo GetLocaleInfo();

	// Object: Function LLHSDK.LLHSDKLocalization.GetLocaleEnum
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101575180
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class ELLHSDKSupportedLanguage GetLocaleEnum();

	// Object: Function LLHSDK.LLHSDKLocalization.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10157531c
	// Return & Params: [ Num(1) Size(0x8) ]
	struct ULLHSDKLocalization* GetInstance();

	// Object: Function LLHSDK.LLHSDKLocalization.DestoryInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101575308
	// Return & Params: [ Num(0) Size(0x0) ]
	void DestoryInstance();
};

// Object: Class LLHSDK.LLHSDKLogin
// Inherited Bytes: 0x28 | Struct Size: 0x1f8
struct ULLHSDKLogin : UObject {
	// Fields
	struct FMulticastInlineDelegate OnInitFinish; // Offset: 0x28 | Size: 0x10
	struct FMulticastInlineDelegate OnLoginFinish; // Offset: 0x38 | Size: 0x10
	struct FMulticastInlineDelegate OnLoginFailed; // Offset: 0x48 | Size: 0x10
	struct FMulticastInlineDelegate OnBindFinish; // Offset: 0x58 | Size: 0x10
	struct FMulticastInlineDelegate OnSwitchAccountFinish; // Offset: 0x68 | Size: 0x10
	struct FMulticastInlineDelegate OnSwitchAccountFailed; // Offset: 0x78 | Size: 0x10
	struct FMulticastInlineDelegate OnProtocolClick; // Offset: 0x88 | Size: 0x10
	struct FMulticastInlineDelegate OnLimSteamSDKInited; // Offset: 0x98 | Size: 0x10
	struct FMulticastInlineDelegate OnSteamAutoLogin; // Offset: 0xa8 | Size: 0x10
	struct FMulticastInlineDelegate OnSteamRegister; // Offset: 0xb8 | Size: 0x10
	struct FMulticastInlineDelegate OnGetSteamRegisterUrl; // Offset: 0xc8 | Size: 0x10
	struct FMulticastInlineDelegate OnGetThirdPartyLoginResult; // Offset: 0xd8 | Size: 0x10
	struct FMulticastInlineDelegate OnSteamBindUrlGet; // Offset: 0xe8 | Size: 0x10
	struct FMulticastInlineDelegate OnSteamLoginResultSet; // Offset: 0xf8 | Size: 0x10
	struct FMulticastInlineDelegate OnSteamGetAccountInfo; // Offset: 0x108 | Size: 0x10
	struct FMulticastInlineDelegate OnSteamBindFinish; // Offset: 0x118 | Size: 0x10
	struct FMulticastInlineDelegate OnNSSDKInited; // Offset: 0x128 | Size: 0x10
	struct FMulticastInlineDelegate OnNSLoginStart; // Offset: 0x138 | Size: 0x10
	struct FMulticastInlineDelegate OnNSAccountInfoGet; // Offset: 0x148 | Size: 0x10
	struct FMulticastInlineDelegate OnLimPCSDKInited; // Offset: 0x158 | Size: 0x10
	struct FMulticastInlineDelegate OnLimPCSDKEventCallback; // Offset: 0x168 | Size: 0x10
	struct FMulticastInlineDelegate OnLimPCSDKLogin; // Offset: 0x178 | Size: 0x10
	struct FMulticastInlineDelegate OnLimPCSDKLogout; // Offset: 0x188 | Size: 0x10
	struct FMulticastInlineDelegate OnLimPCSDKOpenAccountPage; // Offset: 0x198 | Size: 0x10
	struct FMulticastInlineDelegate OnLimPCSDKOpenSwitchAccountPage; // Offset: 0x1a8 | Size: 0x10
	struct FMulticastInlineDelegate OnLimPCSDKLanguageChange; // Offset: 0x1b8 | Size: 0x10
	struct FMulticastInlineDelegate OnLimPCSDKGetUserInfo; // Offset: 0x1c8 | Size: 0x10
	struct FMulticastInlineDelegate OnLimPCSDKCommonReportPoint; // Offset: 0x1d8 | Size: 0x10
	struct FString LimPCAlilogFields; // Offset: 0x1e8 | Size: 0x10

	// Functions

	// Object: Function LLHSDK.LLHSDKLogin.UpdateSteamCallBack
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1015763ec
	// Return & Params: [ Num(0) Size(0x0) ]
	void UpdateSteamCallBack();

	// Object: Function LLHSDK.LLHSDKLogin.SwitchOrLinkAccount
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101576ee0
	// Return & Params: [ Num(0) Size(0x0) ]
	void SwitchOrLinkAccount();

	// Object: Function LLHSDK.LLHSDKLogin.SteamRegister
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10157675c
	// Return & Params: [ Num(2) Size(0x11) ]
	bool SteamRegister(struct FString Params);

	// Object: Function LLHSDK.LLHSDKLogin.SteamLoginResultSet
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1015765a4
	// Return & Params: [ Num(2) Size(0x11) ]
	bool SteamLoginResultSet(struct FString Params);

	// Object: Function LLHSDK.LLHSDKLogin.SteamGetAccountInfo
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10157648c
	// Return & Params: [ Num(2) Size(0x11) ]
	bool SteamGetAccountInfo(struct FString Params);

	// Object: Function LLHSDK.LLHSDKLogin.SteamFree
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101576748
	// Return & Params: [ Num(0) Size(0x0) ]
	void SteamFree();

	// Object: Function LLHSDK.LLHSDKLogin.SteamBindUrlGet
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101576518
	// Return & Params: [ Num(2) Size(0x11) ]
	bool SteamBindUrlGet(struct FString Params);

	// Object: Function LLHSDK.LLHSDKLogin.SteamAutoLogin
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1015767e8
	// Return & Params: [ Num(2) Size(0x11) ]
	bool SteamAutoLogin(struct FString Params);

	// Object: Function LLHSDK.LLHSDKLogin.ShowProtocolViewV2Ok
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101576900
	// Return & Params: [ Num(0) Size(0x0) ]
	void ShowProtocolViewV2Ok();

	// Object: Function LLHSDK.LLHSDKLogin.ShowProtocolViewV2Confirm
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101576914
	// Return & Params: [ Num(0) Size(0x0) ]
	void ShowProtocolViewV2Confirm();

	// Object: Function LLHSDK.LLHSDKLogin.SetLimPCSDKLogHandler
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101575f10
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t SetLimPCSDKLogHandler();

	// Object: Function LLHSDK.LLHSDKLogin.SetLimPCSDKEventHandler
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101575edc
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t SetLimPCSDKEventHandler();

	// Object: Function LLHSDK.LLHSDKLogin.SetLimPCAlilogFieldsData
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1015762a0
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetLimPCAlilogFieldsData(struct FString LimPCAlilogFieldsStr);

	// Object: Function LLHSDK.LLHSDKLogin.QueryCurrentUserInfo
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101576a34
	// Return & Params: [ Num(1) Size(0x140) ]
	struct FLLHSDKLoginUserInfo QueryCurrentUserInfo();

	// Object: Function LLHSDK.LLHSDKLogin.QueryCurrentUser
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101576d6c
	// Return & Params: [ Num(1) Size(0x48) ]
	struct FLLHSDKLoginUser QueryCurrentUser();

	// Object: Function LLHSDK.LLHSDKLogin.OpenSteamBindPage
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101576630
	// Return & Params: [ Num(2) Size(0x11) ]
	bool OpenSteamBindPage(struct FString URL);

	// Object: Function LLHSDK.LLHSDKLogin.OpenLIMPCSwitchAccPage
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101575d48
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t OpenLIMPCSwitchAccPage();

	// Object: Function LLHSDK.LLHSDKLogin.OpenLIMPCAccountPage
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101575d7c
	// Return & Params: [ Num(2) Size(0x14) ]
	int32_t OpenLIMPCAccountPage(struct FString Params);

	// Object: DelegateFunction LLHSDK.LLHSDKLogin.OnProtocolClick__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnProtocolClick__DelegateSignature(bool bConfirmed);

	// Object: DelegateFunction LLHSDK.LLHSDKLogin.OnLoginFinish__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(3) Size(0x21) ]
	void OnLoginFinish__DelegateSignature(struct FString AppUid, struct FString AppToken, enum class ELLHSDKLoginType LoginType);

	// Object: DelegateFunction LLHSDK.LLHSDKLogin.OnLoginFailed__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(2) Size(0x8) ]
	void OnLoginFailed__DelegateSignature(enum class ELLHSDKLoginType LoginType, int32_t ErrorCode);

	// Object: DelegateFunction LLHSDK.LLHSDKLogin.OnInitFinish__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnInitFinish__DelegateSignature();

	// Object: DelegateFunction LLHSDK.LLHSDKLogin.OnBindFinish__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(4) Size(0x29) ]
	void OnBindFinish__DelegateSignature(bool bSuccess, struct FString AppUid, struct FString AppToken, enum class ELLHSDKLoginType LoginType);

	// Object: Function LLHSDK.LLHSDKLogin.NSLogout
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10157605c
	// Return & Params: [ Num(0) Size(0x0) ]
	void NSLogout();

	// Object: Function LLHSDK.LLHSDKLogin.NSLoginStart
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101576070
	// Return & Params: [ Num(2) Size(0x11) ]
	bool NSLoginStart(struct FString Params);

	// Object: Function LLHSDK.LLHSDKLogin.NSFinalize
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1015760fc
	// Return & Params: [ Num(0) Size(0x0) ]
	void NSFinalize();

	// Object: Function LLHSDK.LLHSDKLogin.NSAccountInfoGet
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101575fd0
	// Return & Params: [ Num(2) Size(0x11) ]
	bool NSAccountInfoGet(struct FString Params);

	// Object: Function LLHSDK.LLHSDKLogin.LogoutLimPCSDK
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101575e08
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t LogoutLimPCSDK();

	// Object: Function LLHSDK.LLHSDKLogin.Logout
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101576e98
	// Return & Params: [ Num(0) Size(0x0) ]
	void Logout();

	// Object: Function LLHSDK.LLHSDKLogin.LoginUserInfo_ToString
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10157695c
	// Return & Params: [ Num(2) Size(0x150) ]
	struct FString LoginUserInfo_ToString(struct FLLHSDKLoginUserInfo& InUserInfo);

	// Object: Function LLHSDK.LLHSDKLogin.LoginUser_ToString
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101576c18
	// Return & Params: [ Num(2) Size(0x58) ]
	struct FString LoginUser_ToString(struct FLLHSDKLoginUser& InUser);

	// Object: Function LLHSDK.LLHSDKLogin.LoginLimPCSDK
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101575e3c
	// Return & Params: [ Num(2) Size(0x14) ]
	int32_t LoginLimPCSDK(struct FString Params);

	// Object: Function LLHSDK.LLHSDKLogin.Login
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101576ef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void Login();

	// Object: DelegateFunction LLHSDK.LLHSDKLogin.LimSteamSDKCallBack__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(1) Size(0x10) ]
	void LimSteamSDKCallBack__DelegateSignature(struct FString Datas);

	// Object: DelegateFunction LLHSDK.LLHSDKLogin.LimPCSDKCallBack__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(1) Size(0x10) ]
	void LimPCSDKCallBack__DelegateSignature(struct FString Datas);

	// Object: DelegateFunction LLHSDK.LLHSDKLogin.LimOnSteamLoginResultSet__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(3) Size(0x30) ]
	void LimOnSteamLoginResultSet__DelegateSignature(struct FString AppUid, struct FString AppToken, struct FString AppId);

	// Object: Function LLHSDK.LLHSDKLogin.IsInitFinish
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101576eac
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsInitFinish();

	// Object: Function LLHSDK.LLHSDKLogin.IsCurrentUserNewReg
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101576928
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsCurrentUserNewReg();

	// Object: Function LLHSDK.LLHSDKLogin.InitNSSDK
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101576110
	// Return & Params: [ Num(2) Size(0x11) ]
	bool InitNSSDK(struct FString Params);

	// Object: Function LLHSDK.LLHSDKLogin.InitLimSteamSDK
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101576874
	// Return & Params: [ Num(2) Size(0x11) ]
	bool InitLimSteamSDK(struct FString Params);

	// Object: Function LLHSDK.LLHSDKLogin.InitLimPCSDK
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101575f44
	// Return & Params: [ Num(2) Size(0x14) ]
	int32_t InitLimPCSDK(struct FString Params);

	// Object: Function LLHSDK.LLHSDKLogin.GetSteamToken
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101576324
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetSteamToken();

	// Object: Function LLHSDK.LLHSDKLogin.GetSteamRegisterUrl
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1015766bc
	// Return & Params: [ Num(2) Size(0x11) ]
	bool GetSteamRegisterUrl(struct FString Params);

	// Object: Function LLHSDK.LLHSDKLogin.GetLimPCUserInfo
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101575c30
	// Return & Params: [ Num(2) Size(0x14) ]
	int32_t GetLimPCUserInfo(struct FString Params);

	// Object: Function LLHSDK.LLHSDKLogin.GetLimPCAlilogFieldsData
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101576220
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetLimPCAlilogFieldsData();

	// Object: Function LLHSDK.LLHSDKLogin.GetLimPCAlilogFields
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101575b70
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetLimPCAlilogFields();

	// Object: Function LLHSDK.LLHSDKLogin.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101576f1c
	// Return & Params: [ Num(1) Size(0x8) ]
	struct ULLHSDKLogin* GetInstance();

	// Object: Function LLHSDK.LLHSDKLogin.FreeLimPCSDK
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101575ec8
	// Return & Params: [ Num(0) Size(0x0) ]
	void FreeLimPCSDK();

	// Object: Function LLHSDK.LLHSDKLogin.DoSteamBind
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101576400
	// Return & Params: [ Num(2) Size(0x11) ]
	bool DoSteamBind(struct FString URL);

	// Object: Function LLHSDK.LLHSDKLogin.DestoryInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101576f08
	// Return & Params: [ Num(0) Size(0x0) ]
	void DestoryInstance();

	// Object: Function LLHSDK.LLHSDKLogin.DAPLogAdd
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10157619c
	// Return & Params: [ Num(1) Size(0x10) ]
	void DAPLogAdd(struct FString Params);

	// Object: Function LLHSDK.LLHSDKLogin.CommonReportLimPCPoint
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101575ba4
	// Return & Params: [ Num(2) Size(0x14) ]
	int32_t CommonReportLimPCPoint(struct FString Params);

	// Object: Function LLHSDK.LLHSDKLogin.ClearAutoLogin
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101576e64
	// Return & Params: [ Num(1) Size(0x1) ]
	bool ClearAutoLogin();

	// Object: Function LLHSDK.LLHSDKLogin.ChangeLIMPCLanguage
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101575cbc
	// Return & Params: [ Num(2) Size(0x14) ]
	int32_t ChangeLIMPCLanguage(struct FString Params);

	// Object: Function LLHSDK.LLHSDKLogin.CanContinueLogin
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1015763a4
	// Return & Params: [ Num(1) Size(0x1) ]
	bool CanContinueLogin();

	// Object: Function LLHSDK.LLHSDKLogin.CancelSteamCallBack
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1015763d8
	// Return & Params: [ Num(0) Size(0x0) ]
	void CancelSteamCallBack();
};

// Object: Class LLHSDK.LLHSDKMisc
// Inherited Bytes: 0x28 | Struct Size: 0x148
struct ULLHSDKMisc : UObject {
	// Fields
	struct FMulticastInlineDelegate OnBrowserClosed; // Offset: 0x28 | Size: 0x10
	struct FMulticastInlineDelegate OnScreenshotCaptured; // Offset: 0x38 | Size: 0x10
	char pad_0x48[0x8]; // Offset: 0x48 | Size: 0x8
	struct FMulticastInlineDelegate OnFacebookPhotoShared; // Offset: 0x50 | Size: 0x10
	char pad_0x60[0x8]; // Offset: 0x60 | Size: 0x8
	struct FMulticastInlineDelegate OnSystemShared; // Offset: 0x68 | Size: 0x10
	char pad_0x78[0x8]; // Offset: 0x78 | Size: 0x8
	struct FMulticastInlineDelegate OnGetFacebookToken; // Offset: 0x80 | Size: 0x10
	char pad_0x90[0x8]; // Offset: 0x90 | Size: 0x8
	struct FMulticastInlineDelegate OnQueryThirdPartyUserInfo; // Offset: 0x98 | Size: 0x10
	char pad_0xA8[0x8]; // Offset: 0xa8 | Size: 0x8
	struct FMulticastInlineDelegate OnRefreshFirebaseToken; // Offset: 0xb0 | Size: 0x10
	char pad_0xC0[0x8]; // Offset: 0xc0 | Size: 0x8
	struct FMulticastInlineDelegate OnHttpDiagnosisCallBack; // Offset: 0xc8 | Size: 0x10
	struct FMulticastInlineDelegate OnPingDiagnosisCallBack; // Offset: 0xd8 | Size: 0x10
	struct FMulticastInlineDelegate OnTcpPingDiagnosisCallBack; // Offset: 0xe8 | Size: 0x10
	struct FMulticastInlineDelegate OnMtrDiagnosisCallBack; // Offset: 0xf8 | Size: 0x10
	struct FMulticastInlineDelegate OnDnsDiagnosisCallBack; // Offset: 0x108 | Size: 0x10
	struct FMulticastInlineDelegate OnLimPCOpenWebview; // Offset: 0x118 | Size: 0x10
	struct FMulticastInlineDelegate OnLimPCCloseWebview; // Offset: 0x128 | Size: 0x10
	struct FMulticastInlineDelegate OnPickFileFromAlbumCallBack; // Offset: 0x138 | Size: 0x10

	// Functions

	// Object: Function LLHSDK.LLHSDKMisc.UpdateNetworkExtensions
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1015789a4
	// Return & Params: [ Num(2) Size(0x20) ]
	void UpdateNetworkExtensions(struct FString InUserId, struct FString InDeviceID);

	// Object: Function LLHSDK.LLHSDKMisc.TwitterShareText
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10157914c
	// Return & Params: [ Num(1) Size(0x10) ]
	void TwitterShareText(struct FString InText);

	// Object: Function LLHSDK.LLHSDKMisc.TwitterSharePhoto
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101579070
	// Return & Params: [ Num(2) Size(0x20) ]
	void TwitterSharePhoto(struct FString InText, struct FString InFilePath);

	// Object: Function LLHSDK.LLHSDKMisc.TryToEnableAndroidNotification
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101578f34
	// Return & Params: [ Num(0) Size(0x0) ]
	void TryToEnableAndroidNotification();

	// Object: Function LLHSDK.LLHSDKMisc.TcpPingDetect
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1015786c8
	// Return & Params: [ Num(2) Size(0x14) ]
	void TcpPingDetect(struct FString InDomain, int32_t Port);

	// Object: Function LLHSDK.LLHSDKMisc.SystemShare
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1015794d0
	// Return & Params: [ Num(3) Size(0x28) ]
	void SystemShare(int32_t& ShareType, struct FString Description, struct FString FilePath);

	// Object: Function LLHSDK.LLHSDKMisc.StartIOSFarlightBrowserWithOrientation
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101579858
	// Return & Params: [ Num(3) Size(0x21) ]
	void StartIOSFarlightBrowserWithOrientation(struct FString URL, struct FString Title, enum class ELLHSDKScreenOrientation Orientation);

	// Object: Function LLHSDK.LLHSDKMisc.StartBrowserWithOrientation
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101579980
	// Return & Params: [ Num(3) Size(0x21) ]
	void StartBrowserWithOrientation(struct FString URL, struct FString Title, enum class ELLHSDKScreenOrientation Orientation);

	// Object: Function LLHSDK.LLHSDKMisc.StartBrowser
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101579aa8
	// Return & Params: [ Num(2) Size(0x20) ]
	void StartBrowser(struct FString URL, struct FString Title);

	// Object: Function LLHSDK.LLHSDKMisc.SetNetworkPolicyDomain
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101578920
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetNetworkPolicyDomain(struct FString InDomain);

	// Object: Function LLHSDK.LLHSDKMisc.SetNetworkMultipleDetect
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1015788a0
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetNetworkMultipleDetect(bool InEnable);

	// Object: Function LLHSDK.LLHSDKMisc.SetNetworkDiagnosisDeviceID
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101578b00
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetNetworkDiagnosisDeviceID(struct FString InDeviceID);

	// Object: Function LLHSDK.LLHSDKMisc.RestartApplication
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101579c38
	// Return & Params: [ Num(1) Size(0x10) ]
	void RestartApplication(struct FString IntentString);

	// Object: Function LLHSDK.LLHSDKMisc.RefreshFirebaseMessagingToken
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101579664
	// Return & Params: [ Num(0) Size(0x0) ]
	void RefreshFirebaseMessagingToken();

	// Object: Function LLHSDK.LLHSDKMisc.RefreshAndroidMediaScanner
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101578fec
	// Return & Params: [ Num(1) Size(0x10) ]
	void RefreshAndroidMediaScanner(struct FString InFullFilePath);

	// Object: Function LLHSDK.LLHSDKMisc.QueryThirdPartUserInfo
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101578fb0
	// Return & Params: [ Num(0) Size(0x0) ]
	void QueryThirdPartUserInfo();

	// Object: Function LLHSDK.LLHSDKMisc.PingDetect
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101578798
	// Return & Params: [ Num(1) Size(0x10) ]
	void PingDetect(struct FString InDomain);

	// Object: Function LLHSDK.LLHSDKMisc.PickFileFromAlbum
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101578fd8
	// Return & Params: [ Num(0) Size(0x0) ]
	void PickFileFromAlbum();

	// Object: Function LLHSDK.LLHSDKMisc.OpenSteamPayWebPage
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101578eb0
	// Return & Params: [ Num(1) Size(0x10) ]
	void OpenSteamPayWebPage(struct FString URL);

	// Object: Function LLHSDK.LLHSDKMisc.OpenLimPCWebPage
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101578e2c
	// Return & Params: [ Num(1) Size(0x10) ]
	void OpenLimPCWebPage(struct FString Params);

	// Object: DelegateFunction LLHSDK.LLHSDKMisc.OnSystemShared__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnSystemShared__DelegateSignature(bool bSuccess);

	// Object: DelegateFunction LLHSDK.LLHSDKMisc.OnScreenshotCapturedEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(1) Size(0x10) ]
	void OnScreenshotCapturedEvent__DelegateSignature(struct FString FullPath);

	// Object: DelegateFunction LLHSDK.LLHSDKMisc.OnRefreshFirebaseToken__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(1) Size(0x10) ]
	void OnRefreshFirebaseToken__DelegateSignature(struct FString FirebaseToken);

	// Object: DelegateFunction LLHSDK.LLHSDKMisc.OnQueryThirdPartUserInfo__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(3) Size(0x18) ]
	void OnQueryThirdPartUserInfo__DelegateSignature(bool Success, int32_t ErrorCode, struct TArray<struct FSDKSocialUserInfo> SocialUserInfoList);

	// Object: DelegateFunction LLHSDK.LLHSDKMisc.OnPickFileFromAlbumFinishEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(2) Size(0x14) ]
	void OnPickFileFromAlbumFinishEvent__DelegateSignature(struct FString PickFilePath, int32_t ErrorCode);

	// Object: DelegateFunction LLHSDK.LLHSDKMisc.OnLimPCOpenWebview__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(1) Size(0x10) ]
	void OnLimPCOpenWebview__DelegateSignature(struct FString Params);

	// Object: DelegateFunction LLHSDK.LLHSDKMisc.OnLimPCCloseWebview__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(1) Size(0x10) ]
	void OnLimPCCloseWebview__DelegateSignature(struct FString Params);

	// Object: DelegateFunction LLHSDK.LLHSDKMisc.OnGetFacebookToken__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(5) Size(0x48) ]
	void OnGetFacebookToken__DelegateSignature(bool Result, struct FString Token, struct FString ApplicationId, struct FString UserId, struct FString GraphDomain);

	// Object: DelegateFunction LLHSDK.LLHSDKMisc.OnFacebookPhotoShared__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(2) Size(0x11) ]
	void OnFacebookPhotoShared__DelegateSignature(struct FString FilePath, bool bSuccess);

	// Object: DelegateFunction LLHSDK.LLHSDKMisc.OnBrowserClosed__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnBrowserClosed__DelegateSignature();

	// Object: DelegateFunction LLHSDK.LLHSDKMisc.NetworkDiagnosisCallback__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(2) Size(0x20) ]
	void NetworkDiagnosisCallback__DelegateSignature(struct FString Type, struct FString Ret);

	// Object: Function LLHSDK.LLHSDKMisc.MtrDetect
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101578644
	// Return & Params: [ Num(1) Size(0x10) ]
	void MtrDetect(struct FString InDomain);

	// Object: Function LLHSDK.LLHSDKMisc.JumpToMarket
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10157977c
	// Return & Params: [ Num(2) Size(0x20) ]
	void JumpToMarket(struct FString InAppPkg, struct FString InMarketPkg);

	// Object: Function LLHSDK.LLHSDKMisc.JumpToAppStore
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1015796f8
	// Return & Params: [ Num(1) Size(0x10) ]
	void JumpToAppStore(struct FString AppStoreUrl);

	// Object: Function LLHSDK.LLHSDKMisc.IsFacebookShareable
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1015795fc
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsFacebookShareable();

	// Object: Function LLHSDK.LLHSDKMisc.IsAppRooted
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101578f7c
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsAppRooted();

	// Object: Function LLHSDK.LLHSDKMisc.IsAndroidNotificationEnabled
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101578f48
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsAndroidNotificationEnabled();

	// Object: Function LLHSDK.LLHSDKMisc.InitNetworkDiagnosis
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101578b84
	// Return & Params: [ Num(7) Size(0x70) ]
	void InitNetworkDiagnosis(struct FString InProject, struct FString InSecretKey, struct FString InEndPoint, struct FString InAccessKeyId, struct FString InAccessKeySecret, struct FString InUid, struct FString InChannel);

	// Object: Function LLHSDK.LLHSDKMisc.HttpDetect
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10157881c
	// Return & Params: [ Num(1) Size(0x10) ]
	void HttpDetect(struct FString InUrl);

	// Object: Function LLHSDK.LLHSDKMisc.GetNetworkDiagnosisDeviceID
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101578a80
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetNetworkDiagnosisDeviceID();

	// Object: Function LLHSDK.LLHSDKMisc.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101579cd0
	// Return & Params: [ Num(1) Size(0x8) ]
	struct ULLHSDKMisc* GetInstance();

	// Object: Function LLHSDK.LLHSDKMisc.GetFirebaseMessagingToken
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101579678
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetFirebaseMessagingToken();

	// Object: Function LLHSDK.LLHSDKMisc.GetFacebookToken
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101578fc4
	// Return & Params: [ Num(0) Size(0x0) ]
	void GetFacebookToken();

	// Object: Function LLHSDK.LLHSDKMisc.FacebookSharePhotoWithFileAndDescription
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10157935c
	// Return & Params: [ Num(2) Size(0x20) ]
	void FacebookSharePhotoWithFileAndDescription(struct FString Description, struct FString FilePath);

	// Object: Function LLHSDK.LLHSDKMisc.FacebookSharePhotoByPath
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101579438
	// Return & Params: [ Num(1) Size(0x10) ]
	void FacebookSharePhotoByPath(struct FString InFilePath);

	// Object: Function LLHSDK.LLHSDKMisc.FacebookSharePhoto
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1015794bc
	// Return & Params: [ Num(0) Size(0x0) ]
	void FacebookSharePhoto();

	// Object: Function LLHSDK.LLHSDKMisc.FacebookShareLink
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1015791d0
	// Return & Params: [ Num(4) Size(0x40) ]
	void FacebookShareLink(struct FString InLinkURL, struct FString InPreviewURL, struct FString InTitle, struct FString InDesc);

	// Object: Function LLHSDK.LLHSDKMisc.DnsDetect
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101578568
	// Return & Params: [ Num(2) Size(0x20) ]
	void DnsDetect(struct FString InServer, struct FString InDomain);

	// Object: Function LLHSDK.LLHSDKMisc.DestoryInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101579cbc
	// Return & Params: [ Num(0) Size(0x0) ]
	void DestoryInstance();

	// Object: Function LLHSDK.LLHSDKMisc.CloseLimPCWebPageAll
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101578e18
	// Return & Params: [ Num(0) Size(0x0) ]
	void CloseLimPCWebPageAll();

	// Object: Function LLHSDK.LLHSDKMisc.CheckGyroSensorSupport
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101579630
	// Return & Params: [ Num(1) Size(0x1) ]
	bool CheckGyroSensorSupport();
};

// Object: Class LLHSDK.LLHSDKPay
// Inherited Bytes: 0x28 | Struct Size: 0x160
struct ULLHSDKPay : UObject {
	// Fields
	struct FMulticastInlineDelegate OnLSteamQuerySkus; // Offset: 0x28 | Size: 0x10
	struct FMulticastInlineDelegate OnLSteamSDKPayApplied; // Offset: 0x38 | Size: 0x10
	struct FMulticastInlineDelegate OnLimPCQueryPriceLadder; // Offset: 0x48 | Size: 0x10
	struct FMulticastInlineDelegate OnLimPCQueryPriceLadderWithRegion; // Offset: 0x58 | Size: 0x10
	struct FMulticastInlineDelegate OnLimPCPayApplied; // Offset: 0x68 | Size: 0x10
	struct FMulticastInlineDelegate OnSwitchSDKPayGetConsumables; // Offset: 0x78 | Size: 0x10
	struct FMulticastInlineDelegate OnSwitchSDKPayGetConsumableItems; // Offset: 0x88 | Size: 0x10
	struct FMulticastInlineDelegate OnSwitchSDKPayEShopOpen; // Offset: 0x98 | Size: 0x10
	struct FMulticastInlineDelegate OnSwitchSDKPayOrdersCheck; // Offset: 0xa8 | Size: 0x10
	struct FMulticastInlineDelegate OnSwitchSDKPayOrdersConsume; // Offset: 0xb8 | Size: 0x10
	struct FMulticastInlineDelegate OnGooglePayFinished; // Offset: 0xc8 | Size: 0x10
	struct FMulticastInlineDelegate OnGoogleQuerySkuItemDetails; // Offset: 0xd8 | Size: 0x10
	struct FMulticastInlineDelegate OnGoogleQuerySkuItemDetailsSubscription; // Offset: 0xe8 | Size: 0x10
	struct FMulticastInlineDelegate OnGetGoogleConsumeGoods; // Offset: 0xf8 | Size: 0x10
	struct FMulticastInlineDelegate OnGetGoogleConsumePointsGoods; // Offset: 0x108 | Size: 0x10
	struct FMulticastInlineDelegate OnIOSQuerySkus; // Offset: 0x118 | Size: 0x10
	struct FMulticastInlineDelegate OnIOSLLHPayFinished; // Offset: 0x128 | Size: 0x10
	struct FMulticastInlineDelegate OnGetIOSPurchaseExtNull; // Offset: 0x138 | Size: 0x10
	char pad_0x148[0x18]; // Offset: 0x148 | Size: 0x18

	// Functions

	// Object: Function LLHSDK.LLHSDKPay.Test_Google_SkuItemDetailsToString
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10157c880
	// Return & Params: [ Num(2) Size(0x20) ]
	struct FString Test_Google_SkuItemDetailsToString(struct FLLHSDKGenericSkuItemsDetailList InDetails);

	// Object: DelegateFunction LLHSDK.LLHSDKPay.SwitchSDKPayOrdersConsume__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(1) Size(0x10) ]
	void SwitchSDKPayOrdersConsume__DelegateSignature(struct FString Datas);

	// Object: DelegateFunction LLHSDK.LLHSDKPay.SwitchSDKPayOrdersCheck__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(1) Size(0x10) ]
	void SwitchSDKPayOrdersCheck__DelegateSignature(struct FString Datas);

	// Object: DelegateFunction LLHSDK.LLHSDKPay.SwitchSDKPayGetConsumables__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(1) Size(0x10) ]
	void SwitchSDKPayGetConsumables__DelegateSignature(struct FString Datas);

	// Object: DelegateFunction LLHSDK.LLHSDKPay.SwitchSDKPayGetConsumableItems__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(1) Size(0x10) ]
	void SwitchSDKPayGetConsumableItems__DelegateSignature(struct FString Datas);

	// Object: DelegateFunction LLHSDK.LLHSDKPay.SwitchSDKPayEShopOpen__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(1) Size(0x10) ]
	void SwitchSDKPayEShopOpen__DelegateSignature(struct FString Datas);

	// Object: Function LLHSDK.LLHSDKPay.Switch_OrdersConsume
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10157bf90
	// Return & Params: [ Num(1) Size(0x10) ]
	void Switch_OrdersConsume(struct FString Params);

	// Object: Function LLHSDK.LLHSDKPay.Switch_OrdersCheck
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10157c014
	// Return & Params: [ Num(1) Size(0x10) ]
	void Switch_OrdersCheck(struct FString Params);

	// Object: Function LLHSDK.LLHSDKPay.Switch_GetConsumables
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10157c1a0
	// Return & Params: [ Num(1) Size(0x10) ]
	void Switch_GetConsumables(struct FString Params);

	// Object: Function LLHSDK.LLHSDKPay.Switch_GetConsumableItems
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10157c11c
	// Return & Params: [ Num(1) Size(0x10) ]
	void Switch_GetConsumableItems(struct FString Params);

	// Object: Function LLHSDK.LLHSDKPay.Switch_EShopOpen
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10157c098
	// Return & Params: [ Num(1) Size(0x10) ]
	void Switch_EShopOpen(struct FString Params);

	// Object: Function LLHSDK.LLHSDKPay.SteamQuerySkus
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10157c3c4
	// Return & Params: [ Num(1) Size(0x10) ]
	void SteamQuerySkus(struct FString Params);

	// Object: Function LLHSDK.LLHSDKPay.Steam_StartPay
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10157c340
	// Return & Params: [ Num(1) Size(0x10) ]
	void Steam_StartPay(struct FString SteamPayInfo);

	// Object: Function LLHSDK.LLHSDKPay.SetPayNotifyUrl
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10157c448
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetPayNotifyUrl(struct FString InNotifyUrl);

	// Object: DelegateFunction LLHSDK.LLHSDKPay.OnLLHQuerySkus__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103a43990
	// Return & Params: [ Num(2) Size(0x20) ]
	void OnLLHQuerySkus__DelegateSignature(struct FLLHSDKGenericSkuItemsDetailList ItemsDetailList, struct TArray<struct FString>& InvalidProductIDs);

	// Object: DelegateFunction LLHSDK.LLHSDKPay.OnLLHPayFinished__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(6) Size(0x31) ]
	void OnLLHPayFinished__DelegateSignature(bool bSuccess, int32_t ErrorCode, struct FString ErrorMsg, int32_t PayValue, struct FString ProductID, enum class ELLHSDKPayType PayType);

	// Object: DelegateFunction LLHSDK.LLHSDKPay.OnGoogleQuerySkuSubItemDetails__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(3) Size(0x18) ]
	void OnGoogleQuerySkuSubItemDetails__DelegateSignature(bool bSuccess, int32_t ErrorCode, struct FString ItemsDetailListJsonString);

	// Object: DelegateFunction LLHSDK.LLHSDKPay.OnGoogleQuerySkuItemDetails__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(3) Size(0x18) ]
	void OnGoogleQuerySkuItemDetails__DelegateSignature(bool bSuccess, int32_t ErrorCode, struct FString ItemsDetailListJsonString);

	// Object: DelegateFunction LLHSDK.LLHSDKPay.OnGooglePayFinished__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(5) Size(0x21) ]
	void OnGooglePayFinished__DelegateSignature(bool bSuccess, int32_t ErrorCode, int32_t Price, struct FString ItemID, enum class ELLHSDKPayType PayType);

	// Object: DelegateFunction LLHSDK.LLHSDKPay.OnGetIOSPurchaseExtNull__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(2) Size(0x20) ]
	void OnGetIOSPurchaseExtNull__DelegateSignature(struct FString AppUid, struct FString ProductID);

	// Object: DelegateFunction LLHSDK.LLHSDKPay.OnGetGoogleConsumeGoods__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103a43990
	// Return & Params: [ Num(1) Size(0x10) ]
	void OnGetGoogleConsumeGoods__DelegateSignature(struct TArray<struct FString>& Skus);

	// Object: DelegateFunction LLHSDK.LLHSDKPay.LSteamSDKQuerySkus__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(1) Size(0x10) ]
	void LSteamSDKQuerySkus__DelegateSignature(struct FString Datas);

	// Object: DelegateFunction LLHSDK.LLHSDKPay.LSteamSDKPayApplied__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(1) Size(0x10) ]
	void LSteamSDKPayApplied__DelegateSignature(struct FString Datas);

	// Object: Function LLHSDK.LLHSDKPay.LimPCStartPay
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10157c224
	// Return & Params: [ Num(1) Size(0x10) ]
	void LimPCStartPay(struct FString Params);

	// Object: DelegateFunction LLHSDK.LLHSDKPay.LimPCSDKQueryPriceLadder__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(1) Size(0x10) ]
	void LimPCSDKQueryPriceLadder__DelegateSignature(struct FString Datas);

	// Object: DelegateFunction LLHSDK.LLHSDKPay.LimPCSDKPayApplied__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(1) Size(0x10) ]
	void LimPCSDKPayApplied__DelegateSignature(struct FString Datas);

	// Object: Function LLHSDK.LLHSDKPay.LimPCQueryPriceLadderWithRegion
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10157c2a8
	// Return & Params: [ Num(1) Size(0x10) ]
	void LimPCQueryPriceLadderWithRegion(struct FString Params);

	// Object: Function LLHSDK.LLHSDKPay.LimPCQueryPriceLadder
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10157c32c
	// Return & Params: [ Num(0) Size(0x0) ]
	void LimPCQueryPriceLadder();

	// Object: Function LLHSDK.LLHSDKPay.IOS_SetUserPayExtInCallback
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10157c4cc
	// Return & Params: [ Num(2) Size(0x20) ]
	void IOS_SetUserPayExtInCallback(struct FString ProductID, struct FString PayExt);

	// Object: Function LLHSDK.LLHSDKPay.IOS_SetUserPayExt
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10157c5a8
	// Return & Params: [ Num(1) Size(0x10) ]
	void IOS_SetUserPayExt(struct FString PayExt);

	// Object: Function LLHSDK.LLHSDKPay.IOS_SetAutoPayExt
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10157c660
	// Return & Params: [ Num(1) Size(0x1) ]
	void IOS_SetAutoPayExt(bool bEnabled);

	// Object: Function LLHSDK.LLHSDKPay.IOS_QuerySkus
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10157c7bc
	// Return & Params: [ Num(1) Size(0x10) ]
	void IOS_QuerySkus(struct TArray<struct FString>& ProductIDs);

	// Object: Function LLHSDK.LLHSDKPay.IOS_LLHPay
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10157c6e0
	// Return & Params: [ Num(2) Size(0x20) ]
	void IOS_LLHPay(struct FString ProductID, struct FString PayExt);

	// Object: Function LLHSDK.LLHSDKPay.IOS_GetAutoPayExt
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10157c62c
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IOS_GetAutoPayExt();

	// Object: Function LLHSDK.LLHSDKPay.Google_StartPaySubscription
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10157cf0c
	// Return & Params: [ Num(2) Size(0x20) ]
	void Google_StartPaySubscription(struct FString PayItemID, struct FString PayContext);

	// Object: Function LLHSDK.LLHSDKPay.Google_StartPay
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10157d09c
	// Return & Params: [ Num(2) Size(0x20) ]
	void Google_StartPay(struct FString PayItemID, struct FString PayContext);

	// Object: Function LLHSDK.LLHSDKPay.Google_QuerySkuItemDetailsSubscription
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10157d22c
	// Return & Params: [ Num(1) Size(0x10) ]
	void Google_QuerySkuItemDetailsSubscription(struct TArray<struct FString> Items);

	// Object: Function LLHSDK.LLHSDKPay.Google_QuerySkuItemDetails
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10157d3d0
	// Return & Params: [ Num(1) Size(0x10) ]
	void Google_QuerySkuItemDetails(struct TArray<struct FString> Items);

	// Object: Function LLHSDK.LLHSDKPay.Google_HasConsumePointsGoods
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10157cdb0
	// Return & Params: [ Num(1) Size(0x1) ]
	bool Google_HasConsumePointsGoods();

	// Object: Function LLHSDK.LLHSDKPay.Google_HasConsumeGoods
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10157ced8
	// Return & Params: [ Num(1) Size(0x1) ]
	bool Google_HasConsumeGoods();

	// Object: Function LLHSDK.LLHSDKPay.Google_GetConsumePointsGoods
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10157ccbc
	// Return & Params: [ Num(1) Size(0x10) ]
	struct TArray<struct FString> Google_GetConsumePointsGoods();

	// Object: Function LLHSDK.LLHSDKPay.Google_GetConsumeGoods
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10157cde4
	// Return & Params: [ Num(1) Size(0x10) ]
	struct TArray<struct FString> Google_GetConsumeGoods();

	// Object: Function LLHSDK.LLHSDKPay.Google_ConsumeGoods
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10157c9b0
	// Return & Params: [ Num(2) Size(0x20) ]
	void Google_ConsumeGoods(struct TArray<struct FString> Skus, struct TArray<struct FString> Contexts);

	// Object: Function LLHSDK.LLHSDKPay.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10157d588
	// Return & Params: [ Num(1) Size(0x8) ]
	struct ULLHSDKPay* GetInstance();

	// Object: Function LLHSDK.LLHSDKPay.DestoryInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10157d574
	// Return & Params: [ Num(0) Size(0x0) ]
	void DestoryInstance();
};

// Object: Class LLHSDK.LLHSDKReport
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct ULLHSDKReport : UObject {
	// Functions

	// Object: Function LLHSDK.LLHSDKReport.ReportToThirdParty_TwoParams
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10157f3dc
	// Return & Params: [ Num(4) Size(0x31) ]
	bool ReportToThirdParty_TwoParams(struct FString EventName, struct FString Parameter1, struct FString Parameter2);

	// Object: Function LLHSDK.LLHSDKReport.ReportToThirdParty_ThreeParams
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10157f248
	// Return & Params: [ Num(5) Size(0x41) ]
	bool ReportToThirdParty_ThreeParams(struct FString EventName, struct FString Parameter1, struct FString Parameter2, struct FString Parameter3);

	// Object: Function LLHSDK.LLHSDKReport.ReportToThirdParty_OneParam
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10157f518
	// Return & Params: [ Num(3) Size(0x21) ]
	bool ReportToThirdParty_OneParam(struct FString EventName, struct FString Parameter);

	// Object: Function LLHSDK.LLHSDKReport.ReportToThirdParty_FourParams
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10157f05c
	// Return & Params: [ Num(6) Size(0x51) ]
	bool ReportToThirdParty_FourParams(struct FString EventName, struct FString Parameter1, struct FString Parameter2, struct FString Parameter3, struct FString Parameter4);

	// Object: Function LLHSDK.LLHSDKReport.ReportToThirdParty_FiveParams
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10157ee18
	// Return & Params: [ Num(7) Size(0x61) ]
	bool ReportToThirdParty_FiveParams(struct FString EventName, struct FString Parameter1, struct FString Parameter2, struct FString Parameter3, struct FString Parameter4, struct FString Parameter5);

	// Object: Function LLHSDK.LLHSDKReport.ReportToThirdParty
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10157f5fc
	// Return & Params: [ Num(2) Size(0x11) ]
	bool ReportToThirdParty(struct FString EventName);

	// Object: Function LLHSDK.LLHSDKReport.ReportRevenueToThirdParty_TwoParams
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10157e980
	// Return & Params: [ Num(6) Size(0x49) ]
	bool ReportRevenueToThirdParty_TwoParams(struct FString EventName, enum class ELLHSDKReportCurrencyType Currency, struct FString Revenue, struct FString Parameter1, struct FString Parameter2);

	// Object: Function LLHSDK.LLHSDKReport.ReportRevenueToThirdParty_ThreeParams
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10157e748
	// Return & Params: [ Num(7) Size(0x59) ]
	bool ReportRevenueToThirdParty_ThreeParams(struct FString EventName, enum class ELLHSDKReportCurrencyType Currency, struct FString Revenue, struct FString Parameter1, struct FString Parameter2, struct FString Parameter3);

	// Object: Function LLHSDK.LLHSDKReport.ReportRevenueToThirdParty_OneParam
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10157eb60
	// Return & Params: [ Num(5) Size(0x39) ]
	bool ReportRevenueToThirdParty_OneParam(struct FString EventName, enum class ELLHSDKReportCurrencyType Currency, struct FString Revenue, struct FString Parameter);

	// Object: Function LLHSDK.LLHSDKReport.ReportRevenueToThirdParty_FourParams
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10157e4b8
	// Return & Params: [ Num(8) Size(0x69) ]
	bool ReportRevenueToThirdParty_FourParams(struct FString EventName, enum class ELLHSDKReportCurrencyType Currency, struct FString Revenue, struct FString Parameter1, struct FString Parameter2, struct FString Parameter3, struct FString Parameter4);

	// Object: Function LLHSDK.LLHSDKReport.ReportRevenueToThirdParty_FiveParams
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10157e1d0
	// Return & Params: [ Num(9) Size(0x79) ]
	bool ReportRevenueToThirdParty_FiveParams(struct FString EventName, enum class ELLHSDKReportCurrencyType Currency, struct FString Revenue, struct FString Parameter1, struct FString Parameter2, struct FString Parameter3, struct FString Parameter4, struct FString Parameter5);

	// Object: Function LLHSDK.LLHSDKReport.ReportRevenueToThirdParty
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10157ece8
	// Return & Params: [ Num(4) Size(0x29) ]
	bool ReportRevenueToThirdParty(struct FString EventName, enum class ELLHSDKReportCurrencyType Currency, struct FString Revenue);

	// Object: Function LLHSDK.LLHSDKReport.ReportJsonToLilithImmediate
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10157f688
	// Return & Params: [ Num(3) Size(0x21) ]
	bool ReportJsonToLilithImmediate(struct FString EventName, struct FString JsonContentStr);

	// Object: Function LLHSDK.LLHSDKReport.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10157f780
	// Return & Params: [ Num(1) Size(0x8) ]
	struct ULLHSDKReport* GetInstance();

	// Object: Function LLHSDK.LLHSDKReport.DestoryInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10157f76c
	// Return & Params: [ Num(0) Size(0x0) ]
	void DestoryInstance();
};

// Object: Class LLHSDK.LLHSDKSettings
// Inherited Bytes: 0x38 | Struct Size: 0x338
struct ULLHSDKSettings : UDeveloperSettings {
	// Fields
	enum class EDistributionRegion DistributionRegion; // Offset: 0x38 | Size: 0x1
	enum class EReleaseType ReleaseType; // Offset: 0x39 | Size: 0x1
	bool bIsSDKDebuggable; // Offset: 0x3a | Size: 0x1
	bool bIsGrayRelease; // Offset: 0x3b | Size: 0x1
	char pad_0x3C[0x4]; // Offset: 0x3c | Size: 0x4
	struct FString SDKGroupName; // Offset: 0x40 | Size: 0x10
	struct FString SDKFeatureName; // Offset: 0x50 | Size: 0x10
	struct FString SDKVersion; // Offset: 0x60 | Size: 0x10
	bool bHasFacebook; // Offset: 0x70 | Size: 0x1
	bool bHasTiktok; // Offset: 0x71 | Size: 0x1
	bool bHasFirebaseMessaging; // Offset: 0x72 | Size: 0x1
	bool bHasJiGuangPush; // Offset: 0x73 | Size: 0x1
	char pad_0x74[0x4]; // Offset: 0x74 | Size: 0x4
	struct FString SDKAppIdForGrayRelease; // Offset: 0x78 | Size: 0x10
	struct FString SDKGameIdForGrayRelease; // Offset: 0x88 | Size: 0x10
	struct FString PspAppIdForGrayRelease; // Offset: 0x98 | Size: 0x10
	struct FString AndroidDebugParkwayEnvIdForGrayRelease; // Offset: 0xa8 | Size: 0x10
	struct FString AndroidReleaseParkwayEnvIdForGrayRelease; // Offset: 0xb8 | Size: 0x10
	struct FString FacebookAppIDForGrayRelease; // Offset: 0xc8 | Size: 0x10
	struct FString FacebookContentProviderForGrayRelease; // Offset: 0xd8 | Size: 0x10
	struct FString SDKAppId; // Offset: 0xe8 | Size: 0x10
	struct FString SDKGameId; // Offset: 0xf8 | Size: 0x10
	struct FString FacebookContentProvider; // Offset: 0x108 | Size: 0x10
	struct FString FacebookAppID; // Offset: 0x118 | Size: 0x10
	struct FString IOSFacebookContentProvider; // Offset: 0x128 | Size: 0x10
	struct FString IOSFacebookAppID; // Offset: 0x138 | Size: 0x10
	struct FString PspAppId; // Offset: 0x148 | Size: 0x10
	struct FString AndroidDebugParkwayEnvId; // Offset: 0x158 | Size: 0x10
	struct FString AndroidReleaseParkwayEnvId; // Offset: 0x168 | Size: 0x10
	struct FString IOSDebugParkwayEnvId; // Offset: 0x178 | Size: 0x10
	struct FString IOSReleaseParkwayEnvId; // Offset: 0x188 | Size: 0x10
	struct FString SteamDebugParkwayEnvId; // Offset: 0x198 | Size: 0x10
	struct FString SteamReleaseParkwayEnvId; // Offset: 0x1a8 | Size: 0x10
	struct FString OffcialWinDebugParkwayEnvId; // Offset: 0x1b8 | Size: 0x10
	struct FString OffcialWinReleaseParkwayEnvId; // Offset: 0x1c8 | Size: 0x10
	struct FString EpicDebugParkwayEnvId; // Offset: 0x1d8 | Size: 0x10
	struct FString EpicReleaseParkwayEnvId; // Offset: 0x1e8 | Size: 0x10
	struct FString SDKAppIdForDomesticRelease; // Offset: 0x1f8 | Size: 0x10
	struct FString SDKGameIdForDomesticRelease; // Offset: 0x208 | Size: 0x10
	struct FString AndroidDebugParkwayEnvIdForDomesticRelease; // Offset: 0x218 | Size: 0x10
	struct FString AndroidReleaseParkwayEnvIdForDomesticRelease; // Offset: 0x228 | Size: 0x10
	struct FString IOSDebugParkwayEnvIdForDomesticRelease; // Offset: 0x238 | Size: 0x10
	struct FString IOSReleaseParkwayEnvIdForDomesticRelease; // Offset: 0x248 | Size: 0x10
	struct FString PspAppIdForDomesticRelease; // Offset: 0x258 | Size: 0x10
	struct FString OffcialWinDebugParkwayEnvIdForDomesticRelease; // Offset: 0x268 | Size: 0x10
	struct FString OffcialWinReleaseParkwayEnvIdForDomesticRelease; // Offset: 0x278 | Size: 0x10
	bool bAndroidXEnabled; // Offset: 0x288 | Size: 0x1
	bool bMultiDexEnabled; // Offset: 0x289 | Size: 0x1
	bool bShouldUseOverridedConfig; // Offset: 0x28a | Size: 0x1
	char pad_0x28B[0x5]; // Offset: 0x28b | Size: 0x5
	struct FString FirebaseCoreVersion; // Offset: 0x290 | Size: 0x10
	struct FString FirebaseMessagingVersion; // Offset: 0x2a0 | Size: 0x10
	struct FString GoogleServicesVersion; // Offset: 0x2b0 | Size: 0x10
	struct FString PlayServicesBasementVersion; // Offset: 0x2c0 | Size: 0x10
	enum class ELLHSDKGravity PlayPhoneGravity; // Offset: 0x2d0 | Size: 0x1
	bool bEnableAndroidScreenshotListener; // Offset: 0x2d1 | Size: 0x1
	bool bEnableAndroidMultipleDetect; // Offset: 0x2d2 | Size: 0x1
	bool bShowLogo; // Offset: 0x2d3 | Size: 0x1
	enum class ELLHSDKLoginUIStyle LoginUIStyle; // Offset: 0x2d4 | Size: 0x1
	bool bIOSShouldUseOverridedConfig; // Offset: 0x2d5 | Size: 0x1
	bool bIOSShowTermsByServer; // Offset: 0x2d6 | Size: 0x1
	char pad_0x2D7[0x1]; // Offset: 0x2d7 | Size: 0x1
	struct FString FacebookDisplayName; // Offset: 0x2d8 | Size: 0x10
	struct FString QQAppID; // Offset: 0x2e8 | Size: 0x10
	struct FString WechatAppID; // Offset: 0x2f8 | Size: 0x10
	struct FString GoogleReversedClientID; // Offset: 0x308 | Size: 0x10
	struct FString TwitterAPIKey; // Offset: 0x318 | Size: 0x10
	struct FString DefaultNSUserTrackingUsageDescription; // Offset: 0x328 | Size: 0x10
};

