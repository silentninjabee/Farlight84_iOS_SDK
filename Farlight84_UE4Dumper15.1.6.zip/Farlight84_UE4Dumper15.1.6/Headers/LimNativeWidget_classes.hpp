#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class LimNativeWidget.AudioPermissionHelperProxy
// Inherited Bytes: 0x28 | Struct Size: 0x48
struct UAudioPermissionHelperProxy : UObject {
	// Fields
	char pad_0x28[0x20]; // Offset: 0x28 | Size: 0x20

	// Functions

	// Object: Function LimNativeWidget.AudioPermissionHelperProxy.OnAndroidPermissionResult
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101468190
	// Return & Params: [ Num(2) Size(0x20) ]
	void OnAndroidPermissionResult(struct TArray<struct FString>& Permissions, struct TArray<bool>& Results);

	// Object: Function LimNativeWidget.AudioPermissionHelperProxy.CheckIOSAudioPermission
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1014682e8
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class EIOSAudioPermissionState CheckIOSAudioPermission();

	// Object: Function LimNativeWidget.AudioPermissionHelperProxy.CheckAndroidAudioPermission
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10146831c
	// Return & Params: [ Num(1) Size(0x1) ]
	bool CheckAndroidAudioPermission();

	// Object: Function LimNativeWidget.AudioPermissionHelperProxy.AcquireIOSAudioPermission
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1014682c0
	// Return & Params: [ Num(0) Size(0x0) ]
	void AcquireIOSAudioPermission();

	// Object: Function LimNativeWidget.AudioPermissionHelperProxy.AcquireAndroidAudioPermission
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1014682d4
	// Return & Params: [ Num(0) Size(0x0) ]
	void AcquireAndroidAudioPermission();
};

// Object: Class LimNativeWidget.ChatGMEManager
// Inherited Bytes: 0x28 | Struct Size: 0x798
struct UChatGMEManager : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
	struct FLimNativeLowLevelWrapper ctx; // Offset: 0x30 | Size: 0x10
	struct FMulticastInlineDelegate OnEnterRoom; // Offset: 0x40 | Size: 0x10
	char pad_0x50[0x18]; // Offset: 0x50 | Size: 0x18
	struct FMulticastInlineDelegate OnExitRoom; // Offset: 0x68 | Size: 0x10
	char pad_0x78[0x18]; // Offset: 0x78 | Size: 0x18
	struct FMulticastInlineDelegate OnRoomDisconnect; // Offset: 0x90 | Size: 0x10
	char pad_0xA0[0x18]; // Offset: 0xa0 | Size: 0x18
	struct FMulticastInlineDelegate OnUserUpdate; // Offset: 0xb8 | Size: 0x10
	char pad_0xC8[0x18]; // Offset: 0xc8 | Size: 0x18
	struct FMulticastInlineDelegate OnNumberOfUsersUpdate; // Offset: 0xe0 | Size: 0x10
	char pad_0xF0[0x18]; // Offset: 0xf0 | Size: 0x18
	struct FMulticastInlineDelegate OnNumberOfAudioStreamsUpdate; // Offset: 0x108 | Size: 0x10
	char pad_0x118[0x18]; // Offset: 0x118 | Size: 0x18
	struct FMulticastInlineDelegate OnReconnectStart; // Offset: 0x130 | Size: 0x10
	char pad_0x140[0x18]; // Offset: 0x140 | Size: 0x18
	struct FMulticastInlineDelegate OnReconnectSuccess; // Offset: 0x158 | Size: 0x10
	char pad_0x168[0x18]; // Offset: 0x168 | Size: 0x18
	struct FMulticastInlineDelegate OnSwitchRoom; // Offset: 0x180 | Size: 0x10
	char pad_0x190[0x18]; // Offset: 0x190 | Size: 0x18
	struct FMulticastInlineDelegate OnChangeRoomType; // Offset: 0x1a8 | Size: 0x10
	char pad_0x1B8[0x18]; // Offset: 0x1b8 | Size: 0x18
	struct FMulticastInlineDelegate OnAudioDataEmpty; // Offset: 0x1d0 | Size: 0x10
	char pad_0x1E0[0x18]; // Offset: 0x1e0 | Size: 0x18
	struct FMulticastInlineDelegate OnRoomSharingStart; // Offset: 0x1f8 | Size: 0x10
	char pad_0x208[0x18]; // Offset: 0x208 | Size: 0x18
	struct FMulticastInlineDelegate OnRoomSharingStop; // Offset: 0x220 | Size: 0x10
	char pad_0x230[0x18]; // Offset: 0x230 | Size: 0x18
	struct FMulticastInlineDelegate OnRecordCompleted; // Offset: 0x248 | Size: 0x10
	char pad_0x258[0x18]; // Offset: 0x258 | Size: 0x18
	struct FMulticastInlineDelegate OnRecordPreviewCompleted; // Offset: 0x270 | Size: 0x10
	char pad_0x280[0x18]; // Offset: 0x280 | Size: 0x18
	struct FMulticastInlineDelegate OnRecordMixCompleted; // Offset: 0x298 | Size: 0x10
	char pad_0x2A8[0x18]; // Offset: 0x2a8 | Size: 0x18
	struct FMulticastInlineDelegate OnAudioRouteUpdate; // Offset: 0x2c0 | Size: 0x10
	char pad_0x2D0[0x18]; // Offset: 0x2d0 | Size: 0x18
	struct FMulticastInlineDelegate OnSpeakerDefaultDeviceChanged; // Offset: 0x2e8 | Size: 0x10
	char pad_0x2F8[0x18]; // Offset: 0x2f8 | Size: 0x18
	struct FMulticastInlineDelegate OnSpeakerNewDevice; // Offset: 0x310 | Size: 0x10
	char pad_0x320[0x18]; // Offset: 0x320 | Size: 0x18
	struct FMulticastInlineDelegate OnSpeakerLostDevice; // Offset: 0x338 | Size: 0x10
	char pad_0x348[0x18]; // Offset: 0x348 | Size: 0x18
	struct FMulticastInlineDelegate OnMicNewDevice; // Offset: 0x360 | Size: 0x10
	char pad_0x370[0x18]; // Offset: 0x370 | Size: 0x18
	struct FMulticastInlineDelegate OnMicLostDevice; // Offset: 0x388 | Size: 0x10
	char pad_0x398[0x18]; // Offset: 0x398 | Size: 0x18
	struct FMulticastInlineDelegate OnMicDefaultDeviceChanged; // Offset: 0x3b0 | Size: 0x10
	char pad_0x3C0[0x18]; // Offset: 0x3c0 | Size: 0x18
	struct FMulticastInlineDelegate OnAudioRouteChanged; // Offset: 0x3d8 | Size: 0x10
	char pad_0x3E8[0x18]; // Offset: 0x3e8 | Size: 0x18
	struct FMulticastInlineDelegate OnUserVolumes; // Offset: 0x400 | Size: 0x10
	char pad_0x410[0x18]; // Offset: 0x410 | Size: 0x18
	struct FMulticastInlineDelegate OnChangeRoomQuality; // Offset: 0x428 | Size: 0x10
	char pad_0x438[0x18]; // Offset: 0x438 | Size: 0x18
	struct FMulticastInlineDelegate OnAccompanyFinish; // Offset: 0x450 | Size: 0x10
	char pad_0x460[0x18]; // Offset: 0x460 | Size: 0x18
	struct FMulticastInlineDelegate OnServerAudioRouteEvent; // Offset: 0x478 | Size: 0x10
	char pad_0x488[0x18]; // Offset: 0x488 | Size: 0x18
	struct FMulticastInlineDelegate OnCustomDataUpdate; // Offset: 0x4a0 | Size: 0x10
	char pad_0x4B0[0x18]; // Offset: 0x4b0 | Size: 0x18
	struct FMulticastInlineDelegate OnRealtimeASR; // Offset: 0x4c8 | Size: 0x10
	char pad_0x4D8[0x18]; // Offset: 0x4d8 | Size: 0x18
	struct FMulticastInlineDelegate OnChorusEvent; // Offset: 0x4f0 | Size: 0x10
	char pad_0x500[0x18]; // Offset: 0x500 | Size: 0x18
	struct FMulticastInlineDelegate OnChangeTeamId; // Offset: 0x518 | Size: 0x10
	char pad_0x528[0x18]; // Offset: 0x528 | Size: 0x18
	struct FMulticastInlineDelegate OnAudioReady; // Offset: 0x540 | Size: 0x10
	char pad_0x550[0x18]; // Offset: 0x550 | Size: 0x18
	struct FMulticastInlineDelegate OnHardwareTestRecordFinish; // Offset: 0x568 | Size: 0x10
	char pad_0x578[0x18]; // Offset: 0x578 | Size: 0x18
	struct FMulticastInlineDelegate OnHardwareTestPreviewFinish; // Offset: 0x590 | Size: 0x10
	char pad_0x5A0[0x18]; // Offset: 0x5a0 | Size: 0x18
	struct FMulticastInlineDelegate OnPTTRecordComplete; // Offset: 0x5b8 | Size: 0x10
	char pad_0x5C8[0x18]; // Offset: 0x5c8 | Size: 0x18
	struct FMulticastInlineDelegate OnPTTUploadComplete; // Offset: 0x5e0 | Size: 0x10
	char pad_0x5F0[0x18]; // Offset: 0x5f0 | Size: 0x18
	struct FMulticastInlineDelegate OnPTTDownloadComplete; // Offset: 0x608 | Size: 0x10
	char pad_0x618[0x18]; // Offset: 0x618 | Size: 0x18
	struct FMulticastInlineDelegate OnPTTPlayComplete; // Offset: 0x630 | Size: 0x10
	char pad_0x640[0x18]; // Offset: 0x640 | Size: 0x18
	struct FMulticastInlineDelegate OnPTTSpeech2TextComplete; // Offset: 0x658 | Size: 0x10
	char pad_0x668[0x18]; // Offset: 0x668 | Size: 0x18
	struct FMulticastInlineDelegate OnPTTStreamingRecognitionComplete; // Offset: 0x680 | Size: 0x10
	char pad_0x690[0x18]; // Offset: 0x690 | Size: 0x18
	struct FMulticastInlineDelegate OnPTTStreamingRecognitionIsRunning; // Offset: 0x6a8 | Size: 0x10
	char pad_0x6B8[0x18]; // Offset: 0x6b8 | Size: 0x18
	struct FMulticastInlineDelegate OnRoomManagementOperator; // Offset: 0x6d0 | Size: 0x10
	char pad_0x6E0[0x18]; // Offset: 0x6e0 | Size: 0x18
	struct FMulticastInlineDelegate OnPermissionResult; // Offset: 0x6f8 | Size: 0x10
	char pad_0x708[0x90]; // Offset: 0x708 | Size: 0x90

	// Functions

	// Object: Function LimNativeWidget.ChatGMEManager.UpdateSelfPosition
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x101469f70
	// Return & Params: [ Num(1) Size(0xc) ]
	void UpdateSelfPosition(struct FVector InSelfPosition);

	// Object: Function LimNativeWidget.ChatGMEManager.UpdateAudioRecvRange
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101469ff0
	// Return & Params: [ Num(1) Size(0x4) ]
	void UpdateAudioRecvRange(int32_t InRange);

	// Object: Function LimNativeWidget.ChatGMEManager.UnRegisterLuaEvent
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x103a43990
	// Return & Params: [ Num(0) Size(0x0) ]
	void UnRegisterLuaEvent();

	// Object: Function LimNativeWidget.ChatGMEManager.Uninit
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10146b284
	// Return & Params: [ Num(0) Size(0x0) ]
	void Uninit();

	// Object: Function LimNativeWidget.ChatGMEManager.SwitchRoomCompatible
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10146af18
	// Return & Params: [ Num(3) Size(0x21) ]
	bool SwitchRoomCompatible(struct FString InRoomId, struct FString GmeToken);

	// Object: Function LimNativeWidget.ChatGMEManager.SwitchRoom
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10146b100
	// Return & Params: [ Num(2) Size(0x11) ]
	bool SwitchRoom(struct FString InRoomId);

	// Object: Function LimNativeWidget.ChatGMEManager.SetRangeAudioTeamID
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10146ae30
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetRangeAudioTeamID(int32_t InTeamId);

	// Object: Function LimNativeWidget.ChatGMEManager.SetRangeAudioMode
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10146adb0
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetRangeAudioMode(enum class EChatGMERangeAudioMode InAudioMode);

	// Object: Function LimNativeWidget.ChatGMEManager.SetAudioSendAndRecvRules
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10146a438
	// Return & Params: [ Num(4) Size(0x30) ]
	void SetAudioSendAndRecvRules(enum class EChatGMEAudioRouteSendType SendType, struct TArray<struct FString> SendOpenIDList, enum class EChatGMEAudioRouteRecvType RecvType, struct TArray<struct FString> RecvOpenIDList);

	// Object: Function LimNativeWidget.ChatGMEManager.SelectSpeak
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10146a070
	// Return & Params: [ Num(1) Size(0x10) ]
	void SelectSpeak(struct FString InDeviceID);

	// Object: Function LimNativeWidget.ChatGMEManager.SelectMic
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10146a0fc
	// Return & Params: [ Num(1) Size(0x10) ]
	void SelectMic(struct FString InDeviceID);

	// Object: Function LimNativeWidget.ChatGMEManager.PreInit
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10146b5c8
	// Return & Params: [ Num(0) Size(0x0) ]
	void PreInit();

	// Object: DelegateFunction LimNativeWidget.ChatGMEManager.OnUserVolumesDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(1) Size(0x58) ]
	void OnUserVolumesDelegate__DelegateSignature(struct FChatGMEDataUserVolumes InData);

	// Object: DelegateFunction LimNativeWidget.ChatGMEManager.OnUserUpdateDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(1) Size(0x20) ]
	void OnUserUpdateDelegate__DelegateSignature(struct FChatGMEDataUserUpdate InData);

	// Object: DelegateFunction LimNativeWidget.ChatGMEManager.OnRoomManagementOperatorDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(1) Size(0x50) ]
	void OnRoomManagementOperatorDelegate__DelegateSignature(struct FChatGMEDataRoomOperator InData);

	// Object: DelegateFunction LimNativeWidget.ChatGMEManager.OnResultDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(1) Size(0x28) ]
	void OnResultDelegate__DelegateSignature(struct FChatGMEDataResult Result);

	// Object: DelegateFunction LimNativeWidget.ChatGMEManager.OnRecordCompletedDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(1) Size(0x48) ]
	void OnRecordCompletedDelegate__DelegateSignature(struct FChatGMEDataRecordCompleted InData);

	// Object: DelegateFunction LimNativeWidget.ChatGMEManager.OnNumberOfUsersUpdateDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(1) Size(0x18) ]
	void OnNumberOfUsersUpdateDelegate__DelegateSignature(struct FChatGMEDataNumberOfUserUpdate InData);

	// Object: DelegateFunction LimNativeWidget.ChatGMEManager.OnNumberOfAudioStreamsUpdateDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(1) Size(0x10) ]
	void OnNumberOfAudioStreamsUpdateDelegate__DelegateSignature(struct FChatGMEDataNumberOfAudioStreamsUpdate InData);

	// Object: DelegateFunction LimNativeWidget.ChatGMEManager.OnNotifyFileInfoDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(1) Size(0x58) ]
	void OnNotifyFileInfoDelegate__DelegateSignature(struct FChatGMEDataFileInfo InData);

	// Object: DelegateFunction LimNativeWidget.ChatGMEManager.OnNotifyDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(1) Size(0x10) ]
	void OnNotifyDelegate__DelegateSignature(struct FString InData);

	// Object: Function LimNativeWidget.ChatGMEManager.OnGetAuthBuffer
	// Flags: [Final|Native|Protected|HasOutParms]
	// Offset: 0x101469528
	// Return & Params: [ Num(2) Size(0x78) ]
	void OnGetAuthBuffer(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeGetGMETokenCallBack& RetData);

	// Object: DelegateFunction LimNativeWidget.ChatGMEManager.OnDeviceChangedDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(1) Size(0x50) ]
	void OnDeviceChangedDelegate__DelegateSignature(struct FChatGMEDataDeviceInfo InData);

	// Object: DelegateFunction LimNativeWidget.ChatGMEManager.OnChangeRoomTypeDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(1) Size(0x28) ]
	void OnChangeRoomTypeDelegate__DelegateSignature(struct FChatGMEDataChangeRoomType InData);

	// Object: DelegateFunction LimNativeWidget.ChatGMEManager.OnChangeRoomQualityDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(1) Size(0x18) ]
	void OnChangeRoomQualityDelegate__DelegateSignature(struct FChatGMEDataRoomQuality InData);

	// Object: DelegateFunction LimNativeWidget.ChatGMEManager.OnAndroidPermissionResult__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnAndroidPermissionResult__DelegateSignature(bool bSuccess);

	// Object: Function LimNativeWidget.ChatGMEManager.MediaMute
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10146a7e0
	// Return & Params: [ Num(2) Size(0x11) ]
	void MediaMute(struct FString InUserId, bool InMute);

	// Object: Function LimNativeWidget.ChatGMEManager.IsRoomEntered
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10146aeb0
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsRoomEntered();

	// Object: Function LimNativeWidget.ChatGMEManager.IsAudioSendEnabled
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10146a95c
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsAudioSendEnabled();

	// Object: Function LimNativeWidget.ChatGMEManager.IsAudioRecvEnabled
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10146a928
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsAudioRecvEnabled();

	// Object: Function LimNativeWidget.ChatGMEManager.IsAudioPlayDeviceEnabled
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10146aaa0
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsAudioPlayDeviceEnabled();

	// Object: Function LimNativeWidget.ChatGMEManager.IsAudioCaptureDeviceEnabled
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10146aad4
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsAudioCaptureDeviceEnabled();

	// Object: Function LimNativeWidget.ChatGMEManager.InnerEnableMic
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10146ac18
	// Return & Params: [ Num(1) Size(0x1) ]
	void InnerEnableMic(bool InEnable);

	// Object: Function LimNativeWidget.ChatGMEManager.InitGME
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10146b298
	// Return & Params: [ Num(2) Size(0x20) ]
	void InitGME(struct FString InEnvId, struct FString InGMEUserID);

	// Object: Function LimNativeWidget.ChatGMEManager.Init
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10146b43c
	// Return & Params: [ Num(3) Size(0x30) ]
	void Init(struct FString InUserId, struct FString InAppId, struct FString InEnvId);

	// Object: Function LimNativeWidget.ChatGMEManager.GetSpeakerState
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10146a8f4
	// Return & Params: [ Num(1) Size(0x1) ]
	bool GetSpeakerState();

	// Object: Function LimNativeWidget.ChatGMEManager.GetSpeakerList
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10146a188
	// Return & Params: [ Num(1) Size(0x10) ]
	struct TArray<struct FChatGMEDataDeviceInfo> GetSpeakerList();

	// Object: Function LimNativeWidget.ChatGMEManager.GetRecordingLocalFilePath
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101469ef0
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetRecordingLocalFilePath();

	// Object: Function LimNativeWidget.ChatGMEManager.GetMicState
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10146a8c0
	// Return & Params: [ Num(1) Size(0x1) ]
	bool GetMicState();

	// Object: Function LimNativeWidget.ChatGMEManager.GetMicList
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10146a2e0
	// Return & Params: [ Num(1) Size(0x10) ]
	struct TArray<struct FChatGMEDataDeviceInfo> GetMicList();

	// Object: Function LimNativeWidget.ChatGMEManager.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10146b5f0
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UChatGMEManager* GetInstance();

	// Object: Function LimNativeWidget.ChatGMEManager.GameUploadRecordedFileCompatible
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101469ca4
	// Return & Params: [ Num(2) Size(0x20) ]
	void GameUploadRecordedFileCompatible(struct FString FilePath, struct FString Token);

	// Object: Function LimNativeWidget.ChatGMEManager.GameUploadRecordedFile
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101469d88
	// Return & Params: [ Num(1) Size(0x10) ]
	void GameUploadRecordedFile(struct FString FilePath);

	// Object: Function LimNativeWidget.ChatGMEManager.GameStopRecording
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101469e50
	// Return & Params: [ Num(0) Size(0x0) ]
	void GameStopRecording();

	// Object: Function LimNativeWidget.ChatGMEManager.GameStopPlayFile
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1014699e4
	// Return & Params: [ Num(0) Size(0x0) ]
	void GameStopPlayFile();

	// Object: Function LimNativeWidget.ChatGMEManager.GameStartRecording
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101469e64
	// Return & Params: [ Num(1) Size(0x10) ]
	void GameStartRecording(struct FString FilePath);

	// Object: Function LimNativeWidget.ChatGMEManager.GameSetSpeakerVolume
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10146978c
	// Return & Params: [ Num(2) Size(0x8) ]
	int32_t GameSetSpeakerVolume(int32_t Volume);

	// Object: Function LimNativeWidget.ChatGMEManager.GameSetMicVolume
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101469884
	// Return & Params: [ Num(2) Size(0x8) ]
	int32_t GameSetMicVolume(int32_t MicVolume);

	// Object: Function LimNativeWidget.ChatGMEManager.GameResumeRecording
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101469e14
	// Return & Params: [ Num(0) Size(0x0) ]
	void GameResumeRecording();

	// Object: Function LimNativeWidget.ChatGMEManager.GamePlayRecordedFile
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1014699f8
	// Return & Params: [ Num(1) Size(0x10) ]
	void GamePlayRecordedFile(struct FString FilePath);

	// Object: Function LimNativeWidget.ChatGMEManager.GamePauseRecording
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101469e28
	// Return & Params: [ Num(0) Size(0x0) ]
	void GamePauseRecording();

	// Object: Function LimNativeWidget.ChatGMEManager.GameGetVoiceFileDuration
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101469948
	// Return & Params: [ Num(2) Size(0x14) ]
	int32_t GameGetVoiceFileDuration(struct FString FilePath);

	// Object: Function LimNativeWidget.ChatGMEManager.GameGetSpeakerVolume
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101469758
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GameGetSpeakerVolume();

	// Object: Function LimNativeWidget.ChatGMEManager.GameGetSpeakerLevel
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10146981c
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GameGetSpeakerLevel();

	// Object: Function LimNativeWidget.ChatGMEManager.GameGetMicVolume
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101469850
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GameGetMicVolume();

	// Object: Function LimNativeWidget.ChatGMEManager.GameGetMicLevel
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101469914
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GameGetMicLevel();

	// Object: Function LimNativeWidget.ChatGMEManager.GameDownloadRecordedFileeCompatible
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101469a84
	// Return & Params: [ Num(3) Size(0x30) ]
	void GameDownloadRecordedFileeCompatible(struct FString FileID, struct FString FilePath, struct FString Token);

	// Object: Function LimNativeWidget.ChatGMEManager.GameDownloadRecordedFile
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101469bc0
	// Return & Params: [ Num(2) Size(0x20) ]
	void GameDownloadRecordedFile(struct FString FileID, struct FString FilePath);

	// Object: Function LimNativeWidget.ChatGMEManager.GameCancleRecording
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101469e3c
	// Return & Params: [ Num(0) Size(0x0) ]
	void GameCancleRecording();

	// Object: Function LimNativeWidget.ChatGMEManager.ExitRoom
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10146aee4
	// Return & Params: [ Num(1) Size(0x1) ]
	bool ExitRoom();

	// Object: Function LimNativeWidget.ChatGMEManager.EnterRoomCompatible
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10146b00c
	// Return & Params: [ Num(3) Size(0x21) ]
	bool EnterRoomCompatible(struct FString InRoomId, struct FString GmeToken);

	// Object: Function LimNativeWidget.ChatGMEManager.EnterRoom
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10146b19c
	// Return & Params: [ Num(3) Size(0x12) ]
	bool EnterRoom(struct FString InRoomId, enum class EChatGMERoomType InRoomType);

	// Object: Function LimNativeWidget.ChatGMEManager.EnableSpeaker
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10146ad28
	// Return & Params: [ Num(1) Size(0x1) ]
	void EnableSpeaker(bool InEnable);

	// Object: Function LimNativeWidget.ChatGMEManager.EnableMic
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10146aca0
	// Return & Params: [ Num(1) Size(0x1) ]
	void EnableMic(bool InEnable);

	// Object: Function LimNativeWidget.ChatGMEManager.EnableAudioSend
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10146aa18
	// Return & Params: [ Num(1) Size(0x1) ]
	void EnableAudioSend(bool bEnable);

	// Object: Function LimNativeWidget.ChatGMEManager.EnableAudioRecv
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10146a990
	// Return & Params: [ Num(1) Size(0x1) ]
	void EnableAudioRecv(bool bEnable);

	// Object: Function LimNativeWidget.ChatGMEManager.EnableAudioPlayDevice
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10146ab08
	// Return & Params: [ Num(1) Size(0x1) ]
	void EnableAudioPlayDevice(bool InEnable);

	// Object: Function LimNativeWidget.ChatGMEManager.EnableAudioCaptureDevice
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10146ab90
	// Return & Params: [ Num(1) Size(0x1) ]
	void EnableAudioCaptureDevice(bool InEnable);

	// Object: Function LimNativeWidget.ChatGMEManager.DestroyInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10146b5dc
	// Return & Params: [ Num(0) Size(0x0) ]
	void DestroyInstance();

	// Object: Function LimNativeWidget.ChatGMEManager.DeleteCacheFiles
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101469744
	// Return & Params: [ Num(0) Size(0x0) ]
	void DeleteCacheFiles();

	// Object: Function LimNativeWidget.ChatGMEManager.CheckPlatformMicPermission
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101469710
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t CheckPlatformMicPermission();
};

// Object: Class LimNativeWidget.ChatListEmojiEntryData
// Inherited Bytes: 0x28 | Struct Size: 0x120
struct UChatListEmojiEntryData : UObject {
	// Fields
	struct FString Tag; // Offset: 0x28 | Size: 0x10
	char pad_0x38[0x8]; // Offset: 0x38 | Size: 0x8
	struct FSlateBrush Image; // Offset: 0x40 | Size: 0xe0
};

// Object: Class LimNativeWidget.ChatListEntryDataBase
// Inherited Bytes: 0x28 | Struct Size: 0x98
struct UChatListEntryDataBase : UObject {
	// Fields
	enum class ELimNativeMsgContentType MessageType; // Offset: 0x28 | Size: 0x1
	char pad_0x29[0x7]; // Offset: 0x29 | Size: 0x7
	struct FDateTime Timestamp; // Offset: 0x30 | Size: 0x8
	struct FString SenderId; // Offset: 0x38 | Size: 0x10
	struct FString SenderName; // Offset: 0x48 | Size: 0x10
	struct FString SenderAvatarUrl; // Offset: 0x58 | Size: 0x10
	enum class ELimNativeMsgState MsgState; // Offset: 0x68 | Size: 0x1
	char pad_0x69[0x7]; // Offset: 0x69 | Size: 0x7
	struct FString ConvID; // Offset: 0x70 | Size: 0x10
	enum class ELimNativeConvType ConvType; // Offset: 0x80 | Size: 0x1
	char pad_0x81[0x7]; // Offset: 0x81 | Size: 0x7
	struct FString MsgId; // Offset: 0x88 | Size: 0x10
};

// Object: Class LimNativeWidget.ChatListEntryDataText
// Inherited Bytes: 0x98 | Struct Size: 0xa8
struct UChatListEntryDataText : UChatListEntryDataBase {
	// Fields
	struct FString Message; // Offset: 0x98 | Size: 0x10
};

// Object: Class LimNativeWidget.ChatListEntryDataSystem
// Inherited Bytes: 0x98 | Struct Size: 0xa8
struct UChatListEntryDataSystem : UChatListEntryDataBase {
	// Fields
	struct FString Message; // Offset: 0x98 | Size: 0x10
};

// Object: Class LimNativeWidget.ChatListEntryDataVoice
// Inherited Bytes: 0x98 | Struct Size: 0xd0
struct UChatListEntryDataVoice : UChatListEntryDataBase {
	// Fields
	struct FString UUID; // Offset: 0x98 | Size: 0x10
	struct FString URL; // Offset: 0xa8 | Size: 0x10
	struct FString Size; // Offset: 0xb8 | Size: 0x10
	int32_t Duration; // Offset: 0xc8 | Size: 0x4
	char pad_0xCC[0x4]; // Offset: 0xcc | Size: 0x4
};

// Object: Class LimNativeWidget.ChatListEntryDataImage
// Inherited Bytes: 0x98 | Struct Size: 0xe0
struct UChatListEntryDataImage : UChatListEntryDataBase {
	// Fields
	struct FString UUID; // Offset: 0x98 | Size: 0x10
	struct FString Fmt; // Offset: 0xa8 | Size: 0x10
	struct FString URL; // Offset: 0xb8 | Size: 0x10
	int32_t Width; // Offset: 0xc8 | Size: 0x4
	int32_t Height; // Offset: 0xcc | Size: 0x4
	struct FString Size; // Offset: 0xd0 | Size: 0x10
};

// Object: Class LimNativeWidget.ChatListEntryDataCustomEmotion
// Inherited Bytes: 0x98 | Struct Size: 0xf0
struct UChatListEntryDataCustomEmotion : UChatListEntryDataBase {
	// Fields
	struct FString PackName; // Offset: 0x98 | Size: 0x10
	enum class ELimNativePackType PackType; // Offset: 0xa8 | Size: 0x1
	char pad_0xA9[0x7]; // Offset: 0xa9 | Size: 0x7
	struct FString EmotionName; // Offset: 0xb0 | Size: 0x10
	struct FString EmotionId; // Offset: 0xc0 | Size: 0x10
	struct FString EmotionUrl; // Offset: 0xd0 | Size: 0x10
	struct FString Desc; // Offset: 0xe0 | Size: 0x10
};

// Object: Class LimNativeWidget.ChatListEntryDataShaderedGameCard
// Inherited Bytes: 0x98 | Struct Size: 0x100
struct UChatListEntryDataShaderedGameCard : UChatListEntryDataBase {
	// Fields
	int32_t Type; // Offset: 0x98 | Size: 0x4
	char pad_0x9C[0x4]; // Offset: 0x9c | Size: 0x4
	struct FString Text; // Offset: 0xa0 | Size: 0x10
	struct FString Title; // Offset: 0xb0 | Size: 0x10
	struct FString Detail; // Offset: 0xc0 | Size: 0x10
	struct FString Img; // Offset: 0xd0 | Size: 0x10
	struct FString URL; // Offset: 0xe0 | Size: 0x10
	struct FString Extra; // Offset: 0xf0 | Size: 0x10
};

// Object: Class LimNativeWidget.ChatListUserEntryData
// Inherited Bytes: 0x28 | Struct Size: 0x78
struct UChatListUserEntryData : UObject {
	// Fields
	struct FString Uid; // Offset: 0x28 | Size: 0x10
	struct FString NickName; // Offset: 0x38 | Size: 0x10
	struct FString AvatarUrl; // Offset: 0x48 | Size: 0x10
	struct FString AvatarFrameUrl; // Offset: 0x58 | Size: 0x10
	enum class ELimNativeUserSexType Sex; // Offset: 0x68 | Size: 0x1
	char pad_0x69[0x3]; // Offset: 0x69 | Size: 0x3
	int32_t VipLevel; // Offset: 0x6c | Size: 0x4
	bool IsShowVip; // Offset: 0x70 | Size: 0x1
	enum class ELimNativeFriendStateType OnlineState; // Offset: 0x71 | Size: 0x1
	char pad_0x72[0x2]; // Offset: 0x72 | Size: 0x2
	int32_t UnreadCount; // Offset: 0x74 | Size: 0x4
};

// Object: Class LimNativeWidget.LimChatManager
// Inherited Bytes: 0x28 | Struct Size: 0x320
struct ULimChatManager : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
	struct ULimNative* LimNativeInstance; // Offset: 0x30 | Size: 0x8
	struct FLimNativeLowLevelWrapper ctx; // Offset: 0x38 | Size: 0x10
	struct FString CurrentLanguage; // Offset: 0x48 | Size: 0x10
	struct FMulticastInlineDelegate OnLoginCallBackHandle; // Offset: 0x58 | Size: 0x10
	struct FMulticastInlineDelegate OnConvsGetCallBackHandle; // Offset: 0x68 | Size: 0x10
	struct FMulticastInlineDelegate OnNewGetMessageHandle; // Offset: 0x78 | Size: 0x10
	struct FMulticastInlineDelegate OnMessageReceivedHandle; // Offset: 0x88 | Size: 0x10
	struct FMulticastInlineDelegate OnNewMessageReceivedHandle; // Offset: 0x98 | Size: 0x10
	struct FMulticastInlineDelegate OnMessageSendCallBackHandle; // Offset: 0xa8 | Size: 0x10
	struct FMulticastInlineDelegate OnNewMessageSendCallBackHandle; // Offset: 0xb8 | Size: 0x10
	struct FMulticastInlineDelegate OnReceiveLogicMsgHandle; // Offset: 0xc8 | Size: 0x10
	struct FMulticastInlineDelegate OnConvDiscardHandle; // Offset: 0xd8 | Size: 0x10
	struct FMulticastInlineDelegate OnConfigInfoHandle; // Offset: 0xe8 | Size: 0x10
	struct FMulticastInlineDelegate OnGetConnStatHandle; // Offset: 0xf8 | Size: 0x10
	struct FMulticastInlineDelegate OnNetStatHandle; // Offset: 0x108 | Size: 0x10
	struct FMulticastInlineDelegate OnGetConfigChatLevelHandle; // Offset: 0x118 | Size: 0x10
	struct FMulticastInlineDelegate OnTextTranslateDynamicDelegate; // Offset: 0x128 | Size: 0x10
	struct FString SelfRoleID; // Offset: 0x138 | Size: 0x10
	struct FChatListConvData CurrentConvData; // Offset: 0x148 | Size: 0x18
	struct TArray<struct FLimNativeConversationData> ConvListFullData; // Offset: 0x160 | Size: 0x10
	struct TArray<struct FNewChatListMessageData> ChatMsgDataList; // Offset: 0x170 | Size: 0x10
	struct TArray<struct FLimNativeConvChatLevelConfigData> ChatLevelDataList; // Offset: 0x180 | Size: 0x10
	struct TMap<struct FChatListConvData, struct FString> MsgIDMap; // Offset: 0x190 | Size: 0x50
	struct TArray<struct FChatListUserData> PeerDataList; // Offset: 0x1e0 | Size: 0x10
	struct TArray<struct FChatListUserData> FriendDataList; // Offset: 0x1f0 | Size: 0x10
	struct TMap<struct FChatListConvData, struct FString> BaseMsgIDMap; // Offset: 0x200 | Size: 0x50
	struct TMap<struct FChatListConvData, int32_t> UnreadMsgMap; // Offset: 0x250 | Size: 0x50
	struct FMulticastInlineDelegate OnGetFriendsCallBackHandle; // Offset: 0x2a0 | Size: 0x10
	struct FMulticastInlineDelegate OnGetUserHandle; // Offset: 0x2b0 | Size: 0x10
	struct FMulticastInlineDelegate OnGetUserListHandle; // Offset: 0x2c0 | Size: 0x10
	struct FMulticastInlineDelegate OnGetUserListStateHandle; // Offset: 0x2d0 | Size: 0x10
	struct FMulticastInlineDelegate OnRedHintUpdateHandle; // Offset: 0x2e0 | Size: 0x10
	struct FMulticastInlineDelegate OnInputBoxChangeHandle; // Offset: 0x2f0 | Size: 0x10
	char pad_0x300[0x20]; // Offset: 0x300 | Size: 0x20

	// Functions

	// Object: Function LimNativeWidget.LimChatManager.UnRegisterLuaEvent
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x103a43990
	// Return & Params: [ Num(0) Size(0x0) ]
	void UnRegisterLuaEvent();

	// Object: Function LimNativeWidget.LimChatManager.UnInitChatManager
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101474a0c
	// Return & Params: [ Num(0) Size(0x0) ]
	void UnInitChatManager();

	// Object: Function LimNativeWidget.LimChatManager.TranslateText
	// Flags: [Final|Native|Public]
	// Offset: 0x101473710
	// Return & Params: [ Num(3) Size(0x30) ]
	void TranslateText(struct FString Text, struct FString Lang, struct FString ExtraInfo);

	// Object: Function LimNativeWidget.LimChatManager.SwitchConvTo
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101473484
	// Return & Params: [ Num(2) Size(0x19) ]
	void SwitchConvTo(struct FChatListConvData& InConvData, bool RefreshConvList);

	// Object: Function LimNativeWidget.LimChatManager.SetCtxLanguage
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1014745e4
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetCtxLanguage(struct FString Lang);

	// Object: Function LimNativeWidget.LimChatManager.SetConvRead
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1014739d4
	// Return & Params: [ Num(1) Size(0x18) ]
	void SetConvRead(struct FChatListConvData& ConvData);

	// Object: Function LimNativeWidget.LimChatManager.SetConvMsgRead
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10147384c
	// Return & Params: [ Num(4) Size(0x38) ]
	void SetConvMsgRead(struct FString ConvID, enum class ELimNativeConvType ConvType, struct FString MsgId, struct FString Extra);

	// Object: Function LimNativeWidget.LimChatManager.SendVoiceMessageToConv
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101473a70
	// Return & Params: [ Num(4) Size(0x38) ]
	void SendVoiceMessageToConv(struct FString ConvID, enum class ELimNativeConvType ConvType, struct FString FileID, struct FString Extra);

	// Object: Function LimNativeWidget.LimChatManager.SendTextMessageToConv
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101473c48
	// Return & Params: [ Num(4) Size(0x38) ]
	void SendTextMessageToConv(struct FString ConvID, enum class ELimNativeConvType ConvType, struct FString Message, struct FString Extra);

	// Object: Function LimNativeWidget.LimChatManager.SendTextMessage
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101473e20
	// Return & Params: [ Num(2) Size(0x20) ]
	void SendTextMessage(struct FString Message, struct FString Extra);

	// Object: Function LimNativeWidget.LimChatManager.PostInitChatManager
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101474a20
	// Return & Params: [ Num(2) Size(0x120) ]
	void PostInitChatManager(struct FLimNativeReportConfig ReportConfig, struct FLimNativeParkConfig ParkConfig);

	// Object: Function LimNativeWidget.LimChatManager.OpenChatUI
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101473574
	// Return & Params: [ Num(4) Size(0x28) ]
	struct UUserWidget* OpenChatUI(struct UObject* WorldContextObject, struct FString ChatWidgetPath, int32_t ZOrder);

	// Object: DelegateFunction LimNativeWidget.LimChatManager.OnTextTranslateDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(4) Size(0x38) ]
	void OnTextTranslateDynamicDelegate__DelegateSignature(bool TranslateRes, struct FString TranslatedText, struct FString Translator, struct FString ExtraInfo);

	// Object: DelegateFunction LimNativeWidget.LimChatManager.OnSendMessageCallBackDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103a43990
	// Return & Params: [ Num(1) Size(0x98) ]
	void OnSendMessageCallBackDynamicDelegate__DelegateSignature(struct FChatListMessageData& MsgCallBack);

	// Object: DelegateFunction LimNativeWidget.LimChatManager.OnRedHintUpdateDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnRedHintUpdateDynamicDelegate__DelegateSignature();

	// Object: DelegateFunction LimNativeWidget.LimChatManager.OnReceiveMessageDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103a43990
	// Return & Params: [ Num(1) Size(0x98) ]
	void OnReceiveMessageDynamicDelegate__DelegateSignature(struct FChatListMessageData& Msg);

	// Object: DelegateFunction LimNativeWidget.LimChatManager.OnReceiveLogicMessageDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103a43990
	// Return & Params: [ Num(2) Size(0x20) ]
	void OnReceiveLogicMessageDynamicDelegate__DelegateSignature(int32_t MsgType, struct FLimNativeDataBizFullObj& NativeMsg);

	// Object: Function LimNativeWidget.LimChatManager.OnOpenChatUI
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1014736fc
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnOpenChatUI();

	// Object: DelegateFunction LimNativeWidget.LimChatManager.OnNewSendMessageCallBackDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103a43990
	// Return & Params: [ Num(3) Size(0x18c) ]
	void OnNewSendMessageCallBackDynamicDelegate__DelegateSignature(struct FNewChatListMessageData& MsgCallBack, struct FString RetData, int32_t Code);

	// Object: DelegateFunction LimNativeWidget.LimChatManager.OnNewReceiveMessageDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103a43990
	// Return & Params: [ Num(1) Size(0x178) ]
	void OnNewReceiveMessageDynamicDelegate__DelegateSignature(struct FNewChatListMessageData& Msg);

	// Object: Function LimNativeWidget.LimChatManager.OnMiscConfigInfoHandle
	// Flags: [Final|Native|Protected|HasOutParms]
	// Offset: 0x101471e38
	// Return & Params: [ Num(2) Size(0x80) ]
	void OnMiscConfigInfoHandle(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeGetMiscConfigInfoCallBack& RetData);

	// Object: Function LimNativeWidget.LimChatManager.OnMessageSend
	// Flags: [Final|Native|Protected|HasOutParms]
	// Offset: 0x101472714
	// Return & Params: [ Num(2) Size(0xd0) ]
	void OnMessageSend(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnSendMsgCallBack& RetData);

	// Object: Function LimNativeWidget.LimChatManager.OnMessageReceived
	// Flags: [Final|Native|Protected|HasOutParms]
	// Offset: 0x1014728c8
	// Return & Params: [ Num(2) Size(0x50) ]
	void OnMessageReceived(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnMsgReceivedEventCallBack& RetData);

	// Object: DelegateFunction LimNativeWidget.LimChatManager.OnLoginDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(3) Size(0x18) ]
	void OnLoginDynamicDelegate__DelegateSignature(bool LoginRes, int32_t Code, struct FString RetData);

	// Object: Function LimNativeWidget.LimChatManager.OnLogin
	// Flags: [Final|Native|Protected|HasOutParms]
	// Offset: 0x101472558
	// Return & Params: [ Num(2) Size(0x40) ]
	void OnLogin(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnLoginCallBack& RetData);

	// Object: Function LimNativeWidget.LimChatManager.OnLogicMsgReceived
	// Flags: [Final|Native|Protected|HasOutParms]
	// Offset: 0x1014721ec
	// Return & Params: [ Num(2) Size(0x48) ]
	void OnLogicMsgReceived(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnMsgLogicReceivedEventCallBack& RetData);

	// Object: Function LimNativeWidget.LimChatManager.OnLog
	// Flags: [Final|Native|Protected|HasOutParms]
	// Offset: 0x101472e14
	// Return & Params: [ Num(2) Size(0x20) ]
	void OnLog(struct FLimNativeLowLevelWrapper& InWrapper, struct FString Data);

	// Object: DelegateFunction LimNativeWidget.LimChatManager.OnInputBoxStateChangeDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(5) Size(0x14) ]
	void OnInputBoxStateChangeDelegate__DelegateSignature(bool bUp, int32_t Left, int32_t Top, int32_t Right, int32_t Bottom);

	// Object: DelegateFunction LimNativeWidget.LimChatManager.OnGetUsersStateCallBackDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnGetUsersStateCallBackDynamicDelegate__DelegateSignature();

	// Object: DelegateFunction LimNativeWidget.LimChatManager.OnGetUsersCallBackDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103a43990
	// Return & Params: [ Num(1) Size(0x10) ]
	void OnGetUsersCallBackDynamicDelegate__DelegateSignature(struct TArray<struct FChatListUserData>& UserDataList);

	// Object: Function LimNativeWidget.LimChatManager.OnGetUserListState
	// Flags: [Final|Native|Protected|HasOutParms]
	// Offset: 0x101470fb8
	// Return & Params: [ Num(2) Size(0xb8) ]
	void OnGetUserListState(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnGetUsersStateCallBack& RetData);

	// Object: Function LimNativeWidget.LimChatManager.OnGetUserListInfo
	// Flags: [Final|Native|Protected|HasOutParms]
	// Offset: 0x101471154
	// Return & Params: [ Num(2) Size(0x78) ]
	void OnGetUserListInfo(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnGetUsersCallBack& RetData);

	// Object: Function LimNativeWidget.LimChatManager.OnGetUserInfo
	// Flags: [Final|Native|Protected|HasOutParms]
	// Offset: 0x101471358
	// Return & Params: [ Num(2) Size(0x178) ]
	void OnGetUserInfo(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnGetUserCallBack& RetData);

	// Object: DelegateFunction LimNativeWidget.LimChatManager.OnGetUserCallBackDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103a43990
	// Return & Params: [ Num(1) Size(0x50) ]
	void OnGetUserCallBackDynamicDelegate__DelegateSignature(struct FChatListUserData& UserData);

	// Object: Function LimNativeWidget.LimChatManager.OnGetTextTranslateHandle
	// Flags: [Final|Native|Protected|HasOutParms]
	// Offset: 0x101471778
	// Return & Params: [ Num(2) Size(0x98) ]
	void OnGetTextTranslateHandle(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeTextTranslateCallBack& RetData);

	// Object: Function LimNativeWidget.LimChatManager.OnGetNetStatHandle
	// Flags: [Final|Native|Protected|HasOutParms]
	// Offset: 0x101471b80
	// Return & Params: [ Num(2) Size(0x14) ]
	void OnGetNetStatHandle(struct FLimNativeLowLevelWrapper& InWrapper, int32_t RetData);

	// Object: DelegateFunction LimNativeWidget.LimChatManager.OnGetNetStatDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(1) Size(0x4) ]
	void OnGetNetStatDynamicDelegate__DelegateSignature(int32_t val);

	// Object: Function LimNativeWidget.LimChatManager.OnGetMessageInRange
	// Flags: [Final|Native|Protected|HasOutParms]
	// Offset: 0x101472a94
	// Return & Params: [ Num(2) Size(0x58) ]
	void OnGetMessageInRange(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnGetMsgsCallBack& RetData);

	// Object: DelegateFunction LimNativeWidget.LimChatManager.OnGetMessageDataDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(3) Size(0x19) ]
	void OnGetMessageDataDynamicDelegate__DelegateSignature(int32_t Code, struct FString ConvID, enum class ELimNativeConvType ConvType);

	// Object: DelegateFunction LimNativeWidget.LimChatManager.OnGetFriendsCallBackDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103a43990
	// Return & Params: [ Num(1) Size(0x10) ]
	void OnGetFriendsCallBackDynamicDelegate__DelegateSignature(struct TArray<struct FChatListUserData>& FriendList);

	// Object: Function LimNativeWidget.LimChatManager.OnGetFriends
	// Flags: [Final|Native|Protected|HasOutParms]
	// Offset: 0x101471574
	// Return & Params: [ Num(2) Size(0x78) ]
	void OnGetFriends(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnGetFriendCallBack& RetData);

	// Object: Function LimNativeWidget.LimChatManager.OnGetConnStateHandle
	// Flags: [Final|Native|Protected|HasOutParms]
	// Offset: 0x101471cb0
	// Return & Params: [ Num(2) Size(0x50) ]
	void OnGetConnStateHandle(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeGetConnStateCallBack& RetData);

	// Object: DelegateFunction LimNativeWidget.LimChatManager.OnGetConnStatDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(2) Size(0x8) ]
	void OnGetConnStatDynamicDelegate__DelegateSignature(bool Result, int32_t val);

	// Object: DelegateFunction LimNativeWidget.LimChatManager.OnConvsGetDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnConvsGetDynamicDelegate__DelegateSignature(bool GetConvRes);

	// Object: Function LimNativeWidget.LimChatManager.OnConvRead
	// Flags: [Final|Native|Protected|HasOutParms]
	// Offset: 0x10147239c
	// Return & Params: [ Num(2) Size(0x40) ]
	void OnConvRead(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnSetConvReadCallBack& RetData);

	// Object: Function LimNativeWidget.LimChatManager.OnConvListGet
	// Flags: [Final|Native|Protected|HasOutParms]
	// Offset: 0x101472c48
	// Return & Params: [ Num(2) Size(0x58) ]
	void OnConvListGet(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnConvsGetCallBack& RetData);

	// Object: DelegateFunction LimNativeWidget.LimChatManager.OnConvHandleDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103a43990
	// Return & Params: [ Num(2) Size(0x40) ]
	void OnConvHandleDynamicDelegate__DelegateSignature(bool Result, struct FLimNativeConvHandleCallBackData& Data);

	// Object: Function LimNativeWidget.LimChatManager.OnConvHandle
	// Flags: [Final|Native|Protected|HasOutParms]
	// Offset: 0x101472014
	// Return & Params: [ Num(2) Size(0x78) ]
	void OnConvHandle(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnConvHandleCallBack& RetData);

	// Object: Function LimNativeWidget.LimChatManager.OnConvChatLevelConfig
	// Flags: [Final|Native|Protected|HasOutParms]
	// Offset: 0x10147197c
	// Return & Params: [ Num(2) Size(0x50) ]
	void OnConvChatLevelConfig(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnGetConvChatLevelConfigCallBack& RetData);

	// Object: DelegateFunction LimNativeWidget.LimChatManager.OnConfigInfoHandleDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(2) Size(0x8) ]
	void OnConfigInfoHandleDynamicDelegate__DelegateSignature(bool Result, int32_t val);

	// Object: DelegateFunction LimNativeWidget.LimChatManager.OnConfigGetChatLevlDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnConfigGetChatLevlDynamicDelegate__DelegateSignature(bool Result);

	// Object: Function LimNativeWidget.LimChatManager.Logout
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1014743e4
	// Return & Params: [ Num(0) Size(0x0) ]
	void Logout();

	// Object: Function LimNativeWidget.LimChatManager.Login
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1014743f8
	// Return & Params: [ Num(5) Size(0x50) ]
	void Login(struct FString InAppId, struct FString InAppUserID, struct FString InToken, struct FString InRoleID, struct FString InExtra);

	// Object: Function LimNativeWidget.LimChatManager.InitChatManager
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101474bf8
	// Return & Params: [ Num(3) Size(0x98) ]
	void InitChatManager(struct FLimNativeInitConfig InitConfig, struct FString InEnvId, struct FString InGMEUserID);

	// Object: Function LimNativeWidget.LimChatManager.GetUserListState
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101473f04
	// Return & Params: [ Num(1) Size(0x10) ]
	void GetUserListState(struct TArray<struct FString>& InUserIDList);

	// Object: Function LimNativeWidget.LimChatManager.GetUserListInfo
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101473fd0
	// Return & Params: [ Num(1) Size(0x10) ]
	void GetUserListInfo(struct TArray<struct FString> InUserIDList);

	// Object: Function LimNativeWidget.LimChatManager.GetUserInfo
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101474180
	// Return & Params: [ Num(1) Size(0x10) ]
	void GetUserInfo(struct FString InUserId);

	// Object: Function LimNativeWidget.LimChatManager.GetMiscConfigInfo
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1014743bc
	// Return & Params: [ Num(0) Size(0x0) ]
	void GetMiscConfigInfo();

	// Object: Function LimNativeWidget.LimChatManager.GetMessageInRange
	// Flags: [Final|Native|Public]
	// Offset: 0x101474220
	// Return & Params: [ Num(4) Size(0x38) ]
	void GetMessageInRange(struct FString ConvID, enum class ELimNativeConvType ConvType, struct FString FromMsgId, struct FString ToMsgId);

	// Object: Function LimNativeWidget.LimChatManager.GetMessage
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101473334
	// Return & Params: [ Num(1) Size(0x18) ]
	void GetMessage(struct FChatListConvData& TargetConv);

	// Object: Function LimNativeWidget.LimChatManager.GetLimSlssvrTest
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1014747d8
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetLimSlssvrTest();

	// Object: Function LimNativeWidget.LimChatManager.GetLimSlssvrDomesticTest
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1014746d8
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetLimSlssvrDomesticTest();

	// Object: Function LimNativeWidget.LimChatManager.GetLimSlssvrDomestic
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101474758
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetLimSlssvrDomestic();

	// Object: Function LimNativeWidget.LimChatManager.GetLimSlssvr
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101474858
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetLimSlssvr();

	// Object: Function LimNativeWidget.LimChatManager.GetLimSDKRegionDomestic
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10147490c
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetLimSDKRegionDomestic();

	// Object: Function LimNativeWidget.LimChatManager.GetLimSDKRegion
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10147498c
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetLimSDKRegion();

	// Object: Function LimNativeWidget.LimChatManager.GetLimGameID
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1014748d8
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetLimGameID();

	// Object: Function LimNativeWidget.LimChatManager.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101474ec8
	// Return & Params: [ Num(1) Size(0x8) ]
	struct ULimChatManager* GetInstance();

	// Object: Function LimNativeWidget.LimChatManager.GetFriendList
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10147420c
	// Return & Params: [ Num(0) Size(0x0) ]
	void GetFriendList();

	// Object: Function LimNativeWidget.LimChatManager.GetFarlightDomainDomestic
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101474670
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetFarlightDomainDomestic();

	// Object: Function LimNativeWidget.LimChatManager.GetFarlightDomain
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1014746a4
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetFarlightDomain();

	// Object: Function LimNativeWidget.LimChatManager.GetConvMessage
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1014730a4
	// Return & Params: [ Num(4) Size(0x38) ]
	void GetConvMessage(struct FString ConvID, enum class ELimNativeConvType ConvType, struct FString FromMsgId, struct FString ToMsgId);

	// Object: Function LimNativeWidget.LimChatManager.GetConvList
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1014743d0
	// Return & Params: [ Num(0) Size(0x0) ]
	void GetConvList();

	// Object: Function LimNativeWidget.LimChatManager.GetConvChatLevelConfig
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101472f50
	// Return & Params: [ Num(0) Size(0x0) ]
	void GetConvChatLevelConfig();

	// Object: Function LimNativeWidget.LimChatManager.GetConnState
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1014743a8
	// Return & Params: [ Num(0) Size(0x0) ]
	void GetConnState();

	// Object: Function LimNativeWidget.LimChatManager.DiscardConv
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101472f64
	// Return & Params: [ Num(2) Size(0x11) ]
	void DiscardConv(struct FString ConvID, enum class ELimNativeConvType ConvType);

	// Object: Function LimNativeWidget.LimChatManager.DestroyInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101474eb4
	// Return & Params: [ Num(0) Size(0x0) ]
	void DestroyInstance();

	// Object: Function LimNativeWidget.LimChatManager.CheckTargetIsContainIn
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x1014733d8
	// Return & Params: [ Num(2) Size(0x19) ]
	bool CheckTargetIsContainIn(struct FChatListConvData& InConvData);
};

// Object: Class LimNativeWidget.LimNativeWidgetSettings
// Inherited Bytes: 0x38 | Struct Size: 0x1c8
struct ULimNativeWidgetSettings : UDeveloperSettings {
	// Fields
	struct FString rDownloadPath; // Offset: 0x38 | Size: 0x10
	int32_t FileIOThreadIntervalMs; // Offset: 0x48 | Size: 0x4
	float CachedDiskFileExpiredDuration; // Offset: 0x4c | Size: 0x4
	float CachedResponseExpiredDuration; // Offset: 0x50 | Size: 0x4
	int32_t CachedResponseMaxCount; // Offset: 0x54 | Size: 0x4
	struct FSoftObjectPath LocalizationTable; // Offset: 0x58 | Size: 0x18
	struct FString EnvId; // Offset: 0x70 | Size: 0x10
	struct FString GME_AppId; // Offset: 0x80 | Size: 0x10
	struct FString GME_PrivateKey; // Offset: 0x90 | Size: 0x10
	struct FString GME_Test_AppId; // Offset: 0xa0 | Size: 0x10
	struct FString GME_Test_PrivateKey; // Offset: 0xb0 | Size: 0x10
	bool bTestGmeEnv; // Offset: 0xc0 | Size: 0x1
	char pad_0xC1[0x3]; // Offset: 0xc1 | Size: 0x3
	float GME_EventTick; // Offset: 0xc4 | Size: 0x4
	int32_t MaxRecordingTime; // Offset: 0xc8 | Size: 0x4
	bool bShowLimSdkLog; // Offset: 0xcc | Size: 0x1
	char pad_0xCD[0x3]; // Offset: 0xcd | Size: 0x3
	struct FString Lim_SDKRegion; // Offset: 0xd0 | Size: 0x10
	struct FString Lim_SDKRegion_Domestic; // Offset: 0xe0 | Size: 0x10
	int32_t Lim_GameID; // Offset: 0xf0 | Size: 0x4
	char pad_0xF4[0x4]; // Offset: 0xf4 | Size: 0x4
	struct FString Lim_Slssvr; // Offset: 0xf8 | Size: 0x10
	struct FString Lim_Slssvr_Test; // Offset: 0x108 | Size: 0x10
	struct FString Lim_Slssvr_Domestic; // Offset: 0x118 | Size: 0x10
	struct FString Lim_Slssvr_Domestic_Test; // Offset: 0x128 | Size: 0x10
	int32_t Use_Farlight_Domain; // Offset: 0x138 | Size: 0x4
	int32_t Use_Farlight_Domain_Domestic; // Offset: 0x13c | Size: 0x4
	struct FString Nertc_AppKey; // Offset: 0x140 | Size: 0x10
	struct FString Nertc_AppToken; // Offset: 0x150 | Size: 0x10
	struct FString Nertc_Test_AppKey; // Offset: 0x160 | Size: 0x10
	struct FString Nertc_Test_AppToken; // Offset: 0x170 | Size: 0x10
	struct FString Agora_AppKey; // Offset: 0x180 | Size: 0x10
	struct FString Agora_AppToken; // Offset: 0x190 | Size: 0x10
	struct FString Agora_Test_AppKey; // Offset: 0x1a0 | Size: 0x10
	struct FString Agora_Test_AppToken; // Offset: 0x1b0 | Size: 0x10
	bool bEnvOversea; // Offset: 0x1c0 | Size: 0x1
	char pad_0x1C1[0x7]; // Offset: 0x1c1 | Size: 0x7

	// Functions

	// Object: Function LimNativeWidget.LimNativeWidgetSettings.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101478ce0
	// Return & Params: [ Num(1) Size(0x8) ]
	struct ULimNativeWidgetSettings* GetInstance();
};

// Object: Class LimNativeWidget.NertcManager
// Inherited Bytes: 0x28 | Struct Size: 0xe0
struct UNertcManager : UObject {
	// Fields
	char pad_0x28[0x10]; // Offset: 0x28 | Size: 0x10
	struct FMulticastInlineDelegate OnPermissionResult; // Offset: 0x38 | Size: 0x10
	struct FMulticastInlineDelegate OnEnterRoom; // Offset: 0x48 | Size: 0x10
	struct FMulticastInlineDelegate OnExitRoom; // Offset: 0x58 | Size: 0x10
	struct FMulticastInlineDelegate OnConnectionChanged; // Offset: 0x68 | Size: 0x10
	struct FMulticastInlineDelegate OnNertcUserInfoUpdate; // Offset: 0x78 | Size: 0x10
	struct FMulticastInlineDelegate OnNertcLocalInfoUpdate; // Offset: 0x88 | Size: 0x10
	struct FMulticastInlineDelegate OnUserRoomStateChange; // Offset: 0x98 | Size: 0x10
	struct FMulticastInlineDelegate OnAudioStateChanged; // Offset: 0xa8 | Size: 0x10
	struct TArray<int32_t> MuteUIDList; // Offset: 0xb8 | Size: 0x10
	char pad_0xC8[0x18]; // Offset: 0xc8 | Size: 0x18

	// Functions

	// Object: Function LimNativeWidget.NertcManager.UpdateSelfPosition
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x101479ecc
	// Return & Params: [ Num(2) Size(0x18) ]
	void UpdateSelfPosition(struct FVector& InSelfPosition, struct FRotator& InSelfRotator);

	// Object: Function LimNativeWidget.NertcManager.UpdateAudioRecvRange
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101479fb0
	// Return & Params: [ Num(1) Size(0x4) ]
	void UpdateAudioRecvRange(int32_t InRange);

	// Object: Function LimNativeWidget.NertcManager.UnRegisterLuaEvent
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x103a43990
	// Return & Params: [ Num(0) Size(0x0) ]
	void UnRegisterLuaEvent();

	// Object: Function LimNativeWidget.NertcManager.Uninit
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10147a6e0
	// Return & Params: [ Num(0) Size(0x0) ]
	void Uninit();

	// Object: Function LimNativeWidget.NertcManager.SwitchRoom
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10147a2a8
	// Return & Params: [ Num(5) Size(0x2c) ]
	void SwitchRoom(struct FString RoomID, struct FString AppToken, int32_t Uid, int32_t TeamID, int32_t AudioDistance);

	// Object: Function LimNativeWidget.NertcManager.SetSubscribeAudioOnlyBy
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101479a18
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetSubscribeAudioOnlyBy(struct TArray<int32_t>& OpenIDList);

	// Object: Function LimNativeWidget.NertcManager.SetSubscribeAudioBlocklist
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101479b48
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetSubscribeAudioBlocklist(struct TArray<int32_t>& OpenIDList);

	// Object: Function LimNativeWidget.NertcManager.SetSubscribeAudioAllowlist
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101479ab0
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetSubscribeAudioAllowlist(struct TArray<int32_t>& OpenIDList);

	// Object: Function LimNativeWidget.NertcManager.SetRangeAudioTeamID
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10147a138
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetRangeAudioTeamID(int32_t TeamID);

	// Object: Function LimNativeWidget.NertcManager.SetRangeAudioMode
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10147a0b8
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetRangeAudioMode(enum class EChatGMERangeAudioMode InAudioMode);

	// Object: Function LimNativeWidget.NertcManager.SetClientRole
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10147a1ec
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetClientRole(bool bBroadCast);

	// Object: Function LimNativeWidget.NertcManager.SetAudioSessionRestriction
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101479254
	// Return & Params: [ Num(0) Size(0x0) ]
	void SetAudioSessionRestriction();

	// Object: Function LimNativeWidget.NertcManager.SetAudioSendAndRecvRules
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101479be0
	// Return & Params: [ Num(4) Size(0x30) ]
	void SetAudioSendAndRecvRules(enum class EChatGMEAudioRouteSendType InSendType, struct TArray<int32_t>& InSendOpenIDList, enum class EChatGMEAudioRouteRecvType InRecvType, struct TArray<int32_t>& InRecvOpenIDList);

	// Object: Function LimNativeWidget.NertcManager.SelectSpeak
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101479398
	// Return & Params: [ Num(1) Size(0x10) ]
	void SelectSpeak(struct FString InDeviceID);

	// Object: Function LimNativeWidget.NertcManager.SelectMic
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101479424
	// Return & Params: [ Num(1) Size(0x10) ]
	void SelectMic(struct FString InDeviceID);

	// Object: DelegateFunction LimNativeWidget.NertcManager.OnUserRoomStateChange__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(2) Size(0x8) ]
	void OnUserRoomStateChange__DelegateSignature(bool EnterRoom, int32_t Uid);

	// Object: DelegateFunction LimNativeWidget.NertcManager.OnUserInfoUpdateDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(1) Size(0x10) ]
	void OnUserInfoUpdateDelegate__DelegateSignature(struct FNertcUserUpdateData UserData);

	// Object: DelegateFunction LimNativeWidget.NertcManager.OnNertcConnectionChange__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(2) Size(0x8) ]
	void OnNertcConnectionChange__DelegateSignature(int32_t State, int32_t reason);

	// Object: DelegateFunction LimNativeWidget.NertcManager.OnLocalUserVolumeChanged__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(2) Size(0x5) ]
	void OnLocalUserVolumeChanged__DelegateSignature(int32_t Volume, bool bVad);

	// Object: DelegateFunction LimNativeWidget.NertcManager.OnExitRoomDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(2) Size(0x10) ]
	void OnExitRoomDelegate__DelegateSignature(int32_t Result, int64_t reason);

	// Object: DelegateFunction LimNativeWidget.NertcManager.OnEnterRoomDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(4) Size(0x18) ]
	void OnEnterRoomDelegate__DelegateSignature(int64_t RoomID, int32_t Uid, int32_t Result, int64_t Elapsed);

	// Object: DelegateFunction LimNativeWidget.NertcManager.OnAudioDeviceStateChanged__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnAudioDeviceStateChanged__DelegateSignature(bool bChanged);

	// Object: DelegateFunction LimNativeWidget.NertcManager.OnAndroidPermissionResult__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103a43990
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnAndroidPermissionResult__DelegateSignature(bool bSuccess);

	// Object: Function LimNativeWidget.NertcManager.MuteLocalStream
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101479d74
	// Return & Params: [ Num(1) Size(0x1) ]
	void MuteLocalStream(bool bMute);

	// Object: Function LimNativeWidget.NertcManager.MediaMute
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101479dfc
	// Return & Params: [ Num(2) Size(0x5) ]
	void MediaMute(int32_t Uid, bool bMute);

	// Object: Function LimNativeWidget.NertcManager.IsRoomEntered
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10147a1b8
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsRoomEntered();

	// Object: Function LimNativeWidget.NertcManager.IsInRTCRoom
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10147a274
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsInRTCRoom();

	// Object: Function LimNativeWidget.NertcManager.InnerEnterRoom
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10147a480
	// Return & Params: [ Num(3) Size(0x24) ]
	void InnerEnterRoom(struct FString RoomID, struct FString AppToken, int32_t Uid);

	// Object: Function LimNativeWidget.NertcManager.InnerEnableMic
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101479880
	// Return & Params: [ Num(1) Size(0x1) ]
	void InnerEnableMic(bool InEnable);

	// Object: Function LimNativeWidget.NertcManager.Init
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10147a6f4
	// Return & Params: [ Num(1) Size(0x10) ]
	void Init(struct FString Appkey);

	// Object: Function LimNativeWidget.NertcManager.GetSpeakerList
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1014794b0
	// Return & Params: [ Num(1) Size(0x10) ]
	struct TArray<struct FChatGMEDataDeviceInfo> GetSpeakerList();

	// Object: Function LimNativeWidget.NertcManager.GetMicList
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101479608
	// Return & Params: [ Num(1) Size(0x10) ]
	struct TArray<struct FChatGMEDataDeviceInfo> GetMicList();

	// Object: Function LimNativeWidget.NertcManager.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10147a794
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UNertcManager* GetInstance();

	// Object: Function LimNativeWidget.NertcManager.GameSetSpeakerVolume
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101479760
	// Return & Params: [ Num(2) Size(0x8) ]
	int32_t GameSetSpeakerVolume(int32_t Volume);

	// Object: Function LimNativeWidget.NertcManager.GameSetMicVolume
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1014797f0
	// Return & Params: [ Num(2) Size(0x8) ]
	int32_t GameSetMicVolume(int32_t MicVolume);

	// Object: Function LimNativeWidget.NertcManager.ExitRoom
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10147a46c
	// Return & Params: [ Num(0) Size(0x0) ]
	void ExitRoom();

	// Object: Function LimNativeWidget.NertcManager.EnterRoom
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10147a5b0
	// Return & Params: [ Num(3) Size(0x24) ]
	void EnterRoom(struct FString RoomID, struct FString AppToken, int32_t Uid);

	// Object: Function LimNativeWidget.NertcManager.EnableSpeaker
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101479990
	// Return & Params: [ Num(1) Size(0x1) ]
	void EnableSpeaker(bool InEnable);

	// Object: Function LimNativeWidget.NertcManager.EnableRangeVoice
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10147a030
	// Return & Params: [ Num(1) Size(0x1) ]
	void EnableRangeVoice(bool bEnbale);

	// Object: Function LimNativeWidget.NertcManager.EnableMic
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101479908
	// Return & Params: [ Num(1) Size(0x1) ]
	void EnableMic(bool InEnable);

	// Object: Function LimNativeWidget.NertcManager.EnabelAudioIndication
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101479268
	// Return & Params: [ Num(3) Size(0x9) ]
	void EnabelAudioIndication(bool InEnable, int32_t millions, bool bEnbaleLocal);

	// Object: Function LimNativeWidget.NertcManager.DestroyInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10147a780
	// Return & Params: [ Num(0) Size(0x0) ]
	void DestroyInstance();
};

