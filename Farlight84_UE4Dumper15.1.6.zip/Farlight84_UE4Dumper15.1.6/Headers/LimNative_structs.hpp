#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct LimNative.LimNativeLowLevelWrapper
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FLimNativeLowLevelWrapper {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct LimNative.LimNativeDataObjectBase
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FLimNativeDataObjectBase {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
};

// Object: ScriptStruct LimNative.UidList
// Inherited Bytes: 0x8 | Struct Size: 0x18
struct FUidList : FLimNativeDataObjectBase {
	// Fields
	struct TArray<struct FString> Uids; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct LimNative.LimNativeInitConfig
// Inherited Bytes: 0x8 | Struct Size: 0x78
struct FLimNativeInitConfig : FLimNativeDataObjectBase {
	// Fields
	enum class ELimNativeSupportedLanguage Lang; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x3]; // Offset: 0x9 | Size: 0x3
	int32_t Mode; // Offset: 0xc | Size: 0x4
	struct FString EnvId; // Offset: 0x10 | Size: 0x10
	struct FString AppId; // Offset: 0x20 | Size: 0x10
	struct FString SDKRegion; // Offset: 0x30 | Size: 0x10
	int32_t GameID; // Offset: 0x40 | Size: 0x4
	char pad_0x44[0x4]; // Offset: 0x44 | Size: 0x4
	struct FString SlsSvr; // Offset: 0x48 | Size: 0x10
	int32_t FarlightDomain; // Offset: 0x58 | Size: 0x4
	char pad_0x5C[0x4]; // Offset: 0x5c | Size: 0x4
	struct FString ParkEnvID; // Offset: 0x60 | Size: 0x10
	int32_t Timeout; // Offset: 0x70 | Size: 0x4
	int32_t UseHttps; // Offset: 0x74 | Size: 0x4
};

// Object: ScriptStruct LimNative.LimNativeDataCallBackBase
// Inherited Bytes: 0x8 | Struct Size: 0x30
struct FLimNativeDataCallBackBase : FLimNativeDataObjectBase {
	// Fields
	struct FString FuncName; // Offset: 0x8 | Size: 0x10
	enum class ELimNativeErrorType ErrorCode; // Offset: 0x18 | Size: 0x1
	char pad_0x19[0x3]; // Offset: 0x19 | Size: 0x3
	int32_t Code; // Offset: 0x1c | Size: 0x4
	struct FString Message; // Offset: 0x20 | Size: 0x10
};

// Object: ScriptStruct LimNative.LimNativeFriendCommonCallBack
// Inherited Bytes: 0x30 | Struct Size: 0x58
struct FLimNativeFriendCommonCallBack : FLimNativeDataCallBackBase {
	// Fields
	struct FLimNativeDataCallBackDataBase ResultData; // Offset: 0x30 | Size: 0x28
};

// Object: ScriptStruct LimNative.LimNativeDataCallBackDataBase
// Inherited Bytes: 0x8 | Struct Size: 0x28
struct FLimNativeDataCallBackDataBase : FLimNativeDataObjectBase {
	// Fields
	struct FLimNativeResult ResultData; // Offset: 0x8 | Size: 0x20
};

// Object: ScriptStruct LimNative.LimNativeResult
// Inherited Bytes: 0x8 | Struct Size: 0x20
struct FLimNativeResult : FLimNativeDataObjectBase {
	// Fields
	int32_t ErrCode; // Offset: 0x8 | Size: 0x4
	char pad_0xC[0x4]; // Offset: 0xc | Size: 0x4
	struct FString ErrMsg; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct LimNative.LimNativeOnGroupMemberAddCallBack
// Inherited Bytes: 0x30 | Struct Size: 0x98
struct FLimNativeOnGroupMemberAddCallBack : FLimNativeDataCallBackBase {
	// Fields
	struct FLimNativeIMGroup Data; // Offset: 0x30 | Size: 0x68
};

// Object: ScriptStruct LimNative.LimNativeIMGroupBrief
// Inherited Bytes: 0x8 | Struct Size: 0x38
struct FLimNativeIMGroupBrief : FLimNativeDataObjectBase {
	// Fields
	struct FString ChannelId; // Offset: 0x8 | Size: 0x10
	struct FString Name; // Offset: 0x18 | Size: 0x10
	struct FString Extra; // Offset: 0x28 | Size: 0x10
};

// Object: ScriptStruct LimNative.LimNativeIMGroup
// Inherited Bytes: 0x38 | Struct Size: 0x68
struct FLimNativeIMGroup : FLimNativeIMGroupBrief {
	// Fields
	struct FString GameID; // Offset: 0x38 | Size: 0x10
	struct FString Uid; // Offset: 0x48 | Size: 0x10
	struct TArray<struct FLimNativeIMChannelMember> members; // Offset: 0x58 | Size: 0x10
};

// Object: ScriptStruct LimNative.LimNativeIMChannelMember
// Inherited Bytes: 0x8 | Struct Size: 0x38
struct FLimNativeIMChannelMember : FLimNativeDataObjectBase {
	// Fields
	struct FString ChannelId; // Offset: 0x8 | Size: 0x10
	struct FString Uid; // Offset: 0x18 | Size: 0x10
	struct FString Role; // Offset: 0x28 | Size: 0x10
};

// Object: ScriptStruct LimNative.LimNativeOnConvHandleCallBack
// Inherited Bytes: 0x30 | Struct Size: 0x68
struct FLimNativeOnConvHandleCallBack : FLimNativeDataCallBackBase {
	// Fields
	struct FLimNativeConvHandleCallBackData Data; // Offset: 0x30 | Size: 0x38
};

// Object: ScriptStruct LimNative.LimNativeConvHandleCallBackData
// Inherited Bytes: 0x8 | Struct Size: 0x38
struct FLimNativeConvHandleCallBackData : FLimNativeDataObjectBase {
	// Fields
	struct FLimNativeResult Result; // Offset: 0x8 | Size: 0x20
	struct FString Msg; // Offset: 0x28 | Size: 0x10
};

// Object: ScriptStruct LimNative.LimNativeOnConvsGetCallBack
// Inherited Bytes: 0x30 | Struct Size: 0x48
struct FLimNativeOnConvsGetCallBack : FLimNativeDataCallBackBase {
	// Fields
	struct FLimNativeOnConvsGetCallBackData Data; // Offset: 0x30 | Size: 0x18
};

// Object: ScriptStruct LimNative.LimNativeOnConvsGetCallBackData
// Inherited Bytes: 0x8 | Struct Size: 0x18
struct FLimNativeOnConvsGetCallBackData : FLimNativeDataObjectBase {
	// Fields
	struct TArray<struct FLimNativeConversationData> ConvList; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct LimNative.LimNativeConversationData
// Inherited Bytes: 0x8 | Struct Size: 0xb0
struct FLimNativeConversationData : FLimNativeDataObjectBase {
	// Fields
	struct FString ConvID; // Offset: 0x8 | Size: 0x10
	enum class ELimNativeConvType ConvType; // Offset: 0x18 | Size: 0x1
	char pad_0x19[0x3]; // Offset: 0x19 | Size: 0x3
	int32_t SubType; // Offset: 0x1c | Size: 0x4
	struct FString Name; // Offset: 0x20 | Size: 0x10
	struct FString Avatar; // Offset: 0x30 | Size: 0x10
	int32_t UnreadCount; // Offset: 0x40 | Size: 0x4
	char pad_0x44[0x4]; // Offset: 0x44 | Size: 0x4
	struct FString LastMsgId; // Offset: 0x48 | Size: 0x10
	enum class ELimNativeMsgContentType LastMsgType; // Offset: 0x58 | Size: 0x1
	char pad_0x59[0x7]; // Offset: 0x59 | Size: 0x7
	struct FString LastMsgTs; // Offset: 0x60 | Size: 0x10
	struct FString LastReadMsgId; // Offset: 0x70 | Size: 0x10
	struct FString LastMsgContent; // Offset: 0x80 | Size: 0x10
	struct FString BaseMsgId; // Offset: 0x90 | Size: 0x10
	struct FString Flags; // Offset: 0xa0 | Size: 0x10
};

// Object: ScriptStruct LimNative.LimNativeOnCreateFriendRequestCallBack
// Inherited Bytes: 0x30 | Struct Size: 0x68
struct FLimNativeOnCreateFriendRequestCallBack : FLimNativeDataCallBackBase {
	// Fields
	struct FCreateFriendRequestData FriendRequestCallBackData; // Offset: 0x30 | Size: 0x38
};

// Object: ScriptStruct LimNative.CreateFriendRequestData
// Inherited Bytes: 0x28 | Struct Size: 0x38
struct FCreateFriendRequestData : FLimNativeDataCallBackDataBase {
	// Fields
	struct FString RequestID; // Offset: 0x28 | Size: 0x10
};

// Object: ScriptStruct LimNative.LimNativeOnCreateGroupCallBack
// Inherited Bytes: 0x30 | Struct Size: 0x98
struct FLimNativeOnCreateGroupCallBack : FLimNativeDataCallBackBase {
	// Fields
	struct FLimNativeIMGroup Data; // Offset: 0x30 | Size: 0x68
};

// Object: ScriptStruct LimNative.LimNativeOnGroupDestoryCallBack
// Inherited Bytes: 0x30 | Struct Size: 0x30
struct FLimNativeOnGroupDestoryCallBack : FLimNativeDataCallBackBase {
};

// Object: ScriptStruct LimNative.LimNativeOnGroupAttrGetAllCallBack
// Inherited Bytes: 0x30 | Struct Size: 0x30
struct FLimNativeOnGroupAttrGetAllCallBack : FLimNativeDataCallBackBase {
};

// Object: ScriptStruct LimNative.LimNativeOnGetBlockeesCallBack
// Inherited Bytes: 0x30 | Struct Size: 0x68
struct FLimNativeOnGetBlockeesCallBack : FLimNativeDataCallBackBase {
	// Fields
	struct FGetBlockeesData Data; // Offset: 0x30 | Size: 0x38
};

// Object: ScriptStruct LimNative.GetBlockeesData
// Inherited Bytes: 0x28 | Struct Size: 0x38
struct FGetBlockeesData : FLimNativeDataCallBackDataBase {
	// Fields
	struct TArray<struct FLimUserInfo> UserInfoList; // Offset: 0x28 | Size: 0x10
};

// Object: ScriptStruct LimNative.LimUserInfo
// Inherited Bytes: 0x8 | Struct Size: 0x38
struct FLimUserInfo : FLimNativeDataObjectBase {
	// Fields
	struct FString Uid; // Offset: 0x8 | Size: 0x10
	struct FString NickName; // Offset: 0x18 | Size: 0x10
	struct FString AvatarUrl; // Offset: 0x28 | Size: 0x10
};

// Object: ScriptStruct LimNative.LimNativeOnGetCommonMsgsCallBack
// Inherited Bytes: 0x30 | Struct Size: 0x68
struct FLimNativeOnGetCommonMsgsCallBack : FLimNativeDataCallBackBase {
	// Fields
	struct FLimNativeGetCommonCallBackData Data; // Offset: 0x30 | Size: 0x38
};

// Object: ScriptStruct LimNative.LimNativeGetCommonCallBackData
// Inherited Bytes: 0x8 | Struct Size: 0x38
struct FLimNativeGetCommonCallBackData : FLimNativeDataObjectBase {
	// Fields
	struct TArray<struct FLimNativeCommonMsg> CommonMessages; // Offset: 0x8 | Size: 0x10
	struct FLimNativeResult Result; // Offset: 0x18 | Size: 0x20
};

// Object: ScriptStruct LimNative.LimNativeCommonMsg
// Inherited Bytes: 0x8 | Struct Size: 0x60
struct FLimNativeCommonMsg : FLimNativeDataObjectBase {
	// Fields
	struct FString ServerMsgId; // Offset: 0x8 | Size: 0x10
	struct FString TargetId; // Offset: 0x18 | Size: 0x10
	int32_t TargetType; // Offset: 0x28 | Size: 0x4
	char pad_0x2C[0x4]; // Offset: 0x2c | Size: 0x4
	struct FLimNativeCommonMsgData Data; // Offset: 0x30 | Size: 0x20
	struct FString Timestamp; // Offset: 0x50 | Size: 0x10
};

// Object: ScriptStruct LimNative.LimNativeCommonMsgData
// Inherited Bytes: 0x8 | Struct Size: 0x20
struct FLimNativeCommonMsgData : FLimNativeDataObjectBase {
	// Fields
	int32_t Type; // Offset: 0x8 | Size: 0x4
	char pad_0xC[0x14]; // Offset: 0xc | Size: 0x14
};

// Object: ScriptStruct LimNative.LimNativeOnGetConfigCallBack
// Inherited Bytes: 0x30 | Struct Size: 0x50
struct FLimNativeOnGetConfigCallBack : FLimNativeDataCallBackBase {
	// Fields
	struct FLimNativeIMConfig Data; // Offset: 0x30 | Size: 0x20
};

// Object: ScriptStruct LimNative.LimNativeIMConfig
// Inherited Bytes: 0x8 | Struct Size: 0x20
struct FLimNativeIMConfig : FLimNativeDataObjectBase {
	// Fields
	enum class ELimNativeSupportedLanguage Lang; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x7]; // Offset: 0x9 | Size: 0x7
	struct FString ResDir; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct LimNative.LimNativeGetConnStateCallBack
// Inherited Bytes: 0x30 | Struct Size: 0x40
struct FLimNativeGetConnStateCallBack : FLimNativeDataCallBackBase {
	// Fields
	struct FLimNativConnStateData Data; // Offset: 0x30 | Size: 0x10
};

// Object: ScriptStruct LimNative.LimNativConnStateData
// Inherited Bytes: 0x8 | Struct Size: 0x10
struct FLimNativConnStateData : FLimNativeDataObjectBase {
	// Fields
	int32_t Connect_State; // Offset: 0x8 | Size: 0x4
	char pad_0xC[0x4]; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct LimNative.LimNativeOnGetConvChatLevelConfigCallBack
// Inherited Bytes: 0x30 | Struct Size: 0x40
struct FLimNativeOnGetConvChatLevelConfigCallBack : FLimNativeDataCallBackBase {
	// Fields
	struct TArray<struct FLimNativeConvChatLevelConfigData> DataList; // Offset: 0x30 | Size: 0x10
};

// Object: ScriptStruct LimNative.LimNativeConvChatLevelConfigData
// Inherited Bytes: 0x28 | Struct Size: 0x48
struct FLimNativeConvChatLevelConfigData : FLimNativeDataCallBackDataBase {
	// Fields
	enum class ELimNativeConvType ConvType; // Offset: 0x28 | Size: 0x1
	char pad_0x29[0x3]; // Offset: 0x29 | Size: 0x3
	int32_t Level; // Offset: 0x2c | Size: 0x4
	int32_t Interval; // Offset: 0x30 | Size: 0x4
	char pad_0x34[0x4]; // Offset: 0x34 | Size: 0x4
	struct TArray<struct FLimNativeConvNumLimitData> NumLimits; // Offset: 0x38 | Size: 0x10
};

// Object: ScriptStruct LimNative.LimNativeConvNumLimitData
// Inherited Bytes: 0x8 | Struct Size: 0x10
struct FLimNativeConvNumLimitData : FLimNativeDataObjectBase {
	// Fields
	int32_t Duration; // Offset: 0x8 | Size: 0x4
	int32_t Number; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct LimNative.LimNativeOnGetFriendRequestCallBack
// Inherited Bytes: 0x30 | Struct Size: 0x78
struct FLimNativeOnGetFriendRequestCallBack : FLimNativeDataCallBackBase {
	// Fields
	struct FGetFriendRequestData GetFriendRequestData; // Offset: 0x30 | Size: 0x48
};

// Object: ScriptStruct LimNative.GetFriendRequestData
// Inherited Bytes: 0x28 | Struct Size: 0x48
struct FGetFriendRequestData : FLimNativeDataCallBackDataBase {
	// Fields
	struct TArray<struct FSendFriendRequestData> SendRequests; // Offset: 0x28 | Size: 0x10
	struct TArray<struct FReceivedFriendRequestData> ReceiveRequests; // Offset: 0x38 | Size: 0x10
};

// Object: ScriptStruct LimNative.ReceivedFriendRequestData
// Inherited Bytes: 0x8 | Struct Size: 0x60
struct FReceivedFriendRequestData : FLimNativeDataObjectBase {
	// Fields
	struct FString RequestID; // Offset: 0x8 | Size: 0x10
	struct FString TargetId; // Offset: 0x18 | Size: 0x10
	struct FString NickName; // Offset: 0x28 | Size: 0x10
	struct FString AvatarUrl; // Offset: 0x38 | Size: 0x10
	struct FString Timestamp; // Offset: 0x48 | Size: 0x10
	bool IsOffLineRequest; // Offset: 0x58 | Size: 0x1
	char pad_0x59[0x7]; // Offset: 0x59 | Size: 0x7
};

// Object: ScriptStruct LimNative.SendFriendRequestData
// Inherited Bytes: 0x8 | Struct Size: 0x58
struct FSendFriendRequestData : FLimNativeDataObjectBase {
	// Fields
	struct FString RequestID; // Offset: 0x8 | Size: 0x10
	struct FString TargetId; // Offset: 0x18 | Size: 0x10
	struct FString NickName; // Offset: 0x28 | Size: 0x10
	struct FString AvatarUrl; // Offset: 0x38 | Size: 0x10
	struct FString Timestamp; // Offset: 0x48 | Size: 0x10
};

// Object: ScriptStruct LimNative.LimNativeOnGetFriendCallBack
// Inherited Bytes: 0x30 | Struct Size: 0x68
struct FLimNativeOnGetFriendCallBack : FLimNativeDataCallBackBase {
	// Fields
	struct FFriendInfoList FriendData; // Offset: 0x30 | Size: 0x38
};

// Object: ScriptStruct LimNative.FriendInfoList
// Inherited Bytes: 0x28 | Struct Size: 0x38
struct FFriendInfoList : FLimNativeDataCallBackDataBase {
	// Fields
	struct TArray<struct FFriendInfo> FriendList; // Offset: 0x28 | Size: 0x10
};

// Object: ScriptStruct LimNative.FriendInfo
// Inherited Bytes: 0x8 | Struct Size: 0x1d0
struct FFriendInfo : FLimNativeDataObjectBase {
	// Fields
	struct FString Uid; // Offset: 0x8 | Size: 0x10
	struct FString NickName; // Offset: 0x18 | Size: 0x10
	struct FString AvatarUrl; // Offset: 0x28 | Size: 0x10
	enum class ELimNativeUserSexType Sex; // Offset: 0x38 | Size: 0x1
	char pad_0x39[0x7]; // Offset: 0x39 | Size: 0x7
	struct FGuild Guild; // Offset: 0x40 | Size: 0x48
	struct FKingdom Kingdom; // Offset: 0x88 | Size: 0x48
	struct TArray<struct FSubTitleItem> SubTitleList; // Offset: 0xd0 | Size: 0x10
	struct FString BadgeUrl; // Offset: 0xe0 | Size: 0x10
	struct FString AvatarFrameUrl; // Offset: 0xf0 | Size: 0x10
	struct FBubbleConfigs BubbleConfigs; // Offset: 0x100 | Size: 0xa8
	int32_t VipLevel; // Offset: 0x1a8 | Size: 0x4
	bool IsShowVip; // Offset: 0x1ac | Size: 0x1
	char pad_0x1AD[0x3]; // Offset: 0x1ad | Size: 0x3
	int32_t ServerTime; // Offset: 0x1b0 | Size: 0x4
	int32_t LastFetchTime; // Offset: 0x1b4 | Size: 0x4
	struct FPresence Presence; // Offset: 0x1b8 | Size: 0x18
};

// Object: ScriptStruct LimNative.Presence
// Inherited Bytes: 0x8 | Struct Size: 0x18
struct FPresence : FLimNativeDataObjectBase {
	// Fields
	bool IsOnline; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x3]; // Offset: 0x9 | Size: 0x3
	int32_t TeamID; // Offset: 0xc | Size: 0x4
	int32_t TeamStatus; // Offset: 0x10 | Size: 0x4
	bool IsInMyTeam; // Offset: 0x14 | Size: 0x1
	enum class ELimNativeFriendStateType FriendState; // Offset: 0x15 | Size: 0x1
	char pad_0x16[0x2]; // Offset: 0x16 | Size: 0x2
};

// Object: ScriptStruct LimNative.BubbleConfigs
// Inherited Bytes: 0x8 | Struct Size: 0xa8
struct FBubbleConfigs : FLimNativeDataObjectBase {
	// Fields
	struct FBubbleConfig LeftNormal; // Offset: 0x8 | Size: 0x28
	struct FBubbleConfig LeftPressed; // Offset: 0x30 | Size: 0x28
	struct FBubbleConfig RightNormal; // Offset: 0x58 | Size: 0x28
	struct FBubbleConfig RightPressed; // Offset: 0x80 | Size: 0x28
};

// Object: ScriptStruct LimNative.BubbleConfig
// Inherited Bytes: 0x8 | Struct Size: 0x28
struct FBubbleConfig : FLimNativeDataObjectBase {
	// Fields
	struct FString URL; // Offset: 0x8 | Size: 0x10
	float Top; // Offset: 0x18 | Size: 0x4
	float Left; // Offset: 0x1c | Size: 0x4
	float Bottom; // Offset: 0x20 | Size: 0x4
	float Right; // Offset: 0x24 | Size: 0x4
};

// Object: ScriptStruct LimNative.SubTitleItem
// Inherited Bytes: 0x8 | Struct Size: 0x38
struct FSubTitleItem : FLimNativeDataObjectBase {
	// Fields
	struct FString Key; // Offset: 0x8 | Size: 0x10
	struct FString Content; // Offset: 0x18 | Size: 0x10
	struct FString BGUrl; // Offset: 0x28 | Size: 0x10
};

// Object: ScriptStruct LimNative.Kingdom
// Inherited Bytes: 0x8 | Struct Size: 0x48
struct FKingdom : FLimNativeDataObjectBase {
	// Fields
	struct FString StoryId; // Offset: 0x8 | Size: 0x10
	struct FString KingdomId; // Offset: 0x18 | Size: 0x10
	struct FString Name; // Offset: 0x28 | Size: 0x10
	struct FString AvatarUrl; // Offset: 0x38 | Size: 0x10
};

// Object: ScriptStruct LimNative.Guild
// Inherited Bytes: 0x8 | Struct Size: 0x48
struct FGuild : FLimNativeDataObjectBase {
	// Fields
	struct FString ID; // Offset: 0x8 | Size: 0x10
	struct FString Name; // Offset: 0x18 | Size: 0x10
	struct FString AvatarUrl; // Offset: 0x28 | Size: 0x10
	struct FString AbbrName; // Offset: 0x38 | Size: 0x10
};

// Object: ScriptStruct LimNative.LimNativeGetGMETokenCallBack
// Inherited Bytes: 0x30 | Struct Size: 0x68
struct FLimNativeGetGMETokenCallBack : FLimNativeDataCallBackBase {
	// Fields
	struct FLimNativeGetGMETokenData Data; // Offset: 0x30 | Size: 0x38
};

// Object: ScriptStruct LimNative.LimNativeGetGMETokenData
// Inherited Bytes: 0x28 | Struct Size: 0x38
struct FLimNativeGetGMETokenData : FLimNativeDataCallBackDataBase {
	// Fields
	struct TArray<char> AuthBuffer; // Offset: 0x28 | Size: 0x10
};

// Object: ScriptStruct LimNative.LimNativeOnGroupAttrGetCallBack
// Inherited Bytes: 0x30 | Struct Size: 0x30
struct FLimNativeOnGroupAttrGetCallBack : FLimNativeDataCallBackBase {
};

// Object: ScriptStruct LimNative.LimNativeOnGroupGetCallBack
// Inherited Bytes: 0x30 | Struct Size: 0x98
struct FLimNativeOnGroupGetCallBack : FLimNativeDataCallBackBase {
	// Fields
	struct FLimNativeIMGroup Data; // Offset: 0x30 | Size: 0x68
};

// Object: ScriptStruct LimNative.LimNativeOnGroupMemberGetCallBack
// Inherited Bytes: 0x30 | Struct Size: 0x30
struct FLimNativeOnGroupMemberGetCallBack : FLimNativeDataCallBackBase {
};

// Object: ScriptStruct LimNative.LimNativeOnGroupMembersGetCallBack
// Inherited Bytes: 0x30 | Struct Size: 0x98
struct FLimNativeOnGroupMembersGetCallBack : FLimNativeDataCallBackBase {
	// Fields
	struct FLimNativeIMGroup Data; // Offset: 0x30 | Size: 0x68
};

// Object: ScriptStruct LimNative.LimNativeOnGroupsGetCallBack
// Inherited Bytes: 0x30 | Struct Size: 0x50
struct FLimNativeOnGroupsGetCallBack : FLimNativeDataCallBackBase {
	// Fields
	struct FString GameID; // Offset: 0x30 | Size: 0x10
	struct TArray<struct FLimNativeIMGroupBrief> Channels; // Offset: 0x40 | Size: 0x10
};

// Object: ScriptStruct LimNative.LimNativeGetMiscConfigInfoCallBack
// Inherited Bytes: 0x30 | Struct Size: 0x70
struct FLimNativeGetMiscConfigInfoCallBack : FLimNativeDataCallBackBase {
	// Fields
	struct FLimNativeGetConfigInfoData Data; // Offset: 0x30 | Size: 0x40
};

// Object: ScriptStruct LimNative.LimNativeGetConfigInfoData
// Inherited Bytes: 0x28 | Struct Size: 0x40
struct FLimNativeGetConfigInfoData : FLimNativeDataCallBackDataBase {
	// Fields
	struct FLimNativConfigInfoData Data; // Offset: 0x28 | Size: 0x10
	int32_t ResultCode; // Offset: 0x38 | Size: 0x4
	char pad_0x3C[0x4]; // Offset: 0x3c | Size: 0x4
};

// Object: ScriptStruct LimNative.LimNativConfigInfoData
// Inherited Bytes: 0x8 | Struct Size: 0x10
struct FLimNativConfigInfoData : FLimNativeDataObjectBase {
	// Fields
	int32_t Interval; // Offset: 0x8 | Size: 0x4
	char pad_0xC[0x4]; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct LimNative.LimNativeOnGetMsgsCallBack
// Inherited Bytes: 0x30 | Struct Size: 0x48
struct FLimNativeOnGetMsgsCallBack : FLimNativeDataCallBackBase {
	// Fields
	struct FLimNativeMsgConvData Data; // Offset: 0x30 | Size: 0x18
};

// Object: ScriptStruct LimNative.LimNativeMsgConvData
// Inherited Bytes: 0x8 | Struct Size: 0x18
struct FLimNativeMsgConvData : FLimNativeDataObjectBase {
	// Fields
	struct TArray<struct FLimNativeMsgConvListData> MsgConvList; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct LimNative.LimNativeMsgConvListData
// Inherited Bytes: 0x8 | Struct Size: 0x30
struct FLimNativeMsgConvListData : FLimNativeDataObjectBase {
	// Fields
	struct FString ConvID; // Offset: 0x8 | Size: 0x10
	enum class ELimNativeConvType ConvType; // Offset: 0x18 | Size: 0x1
	char pad_0x19[0x7]; // Offset: 0x19 | Size: 0x7
	struct TArray<struct FLimNativeMsgListData> MsgList; // Offset: 0x20 | Size: 0x10
};

// Object: ScriptStruct LimNative.LimNativeOnChatMsgCallBackData
// Inherited Bytes: 0x8 | Struct Size: 0x90
struct FLimNativeOnChatMsgCallBackData : FLimNativeDataObjectBase {
	// Fields
	struct FString MsgId; // Offset: 0x8 | Size: 0x10
	enum class ELimNativeMsgState State; // Offset: 0x18 | Size: 0x1
	char pad_0x19[0x7]; // Offset: 0x19 | Size: 0x7
	struct FLimNativeIMChatMessage Msg; // Offset: 0x20 | Size: 0x70
};

// Object: ScriptStruct LimNative.LimNativeIMChatMessage
// Inherited Bytes: 0x8 | Struct Size: 0x70
struct FLimNativeIMChatMessage : FLimNativeDataObjectBase {
	// Fields
	struct FLimNativeIMChatMessageInfo BaseInfo; // Offset: 0x8 | Size: 0x50
	char pad_0x58[0x10]; // Offset: 0x58 | Size: 0x10
	enum class ELimNativeMsgContentType MsgType; // Offset: 0x68 | Size: 0x1
	char pad_0x69[0x7]; // Offset: 0x69 | Size: 0x7
};

// Object: ScriptStruct LimNative.LimNativeIMChatMessageInfo
// Inherited Bytes: 0x8 | Struct Size: 0x50
struct FLimNativeIMChatMessageInfo : FLimNativeDataObjectBase {
	// Fields
	struct FString ConvID; // Offset: 0x8 | Size: 0x10
	enum class ELimNativeConvType ConvType; // Offset: 0x18 | Size: 0x1
	enum class ELimNativeMsgContentType MsgType; // Offset: 0x19 | Size: 0x1
	char pad_0x1A[0x6]; // Offset: 0x1a | Size: 0x6
	struct FString Ext; // Offset: 0x20 | Size: 0x10
	struct FString Nonce; // Offset: 0x30 | Size: 0x10
	struct FString Timestamp; // Offset: 0x40 | Size: 0x10
};

// Object: ScriptStruct LimNative.LimNativeMsgListData
// Inherited Bytes: 0x90 | Struct Size: 0xa8
struct FLimNativeMsgListData : FLimNativeOnChatMsgCallBackData {
	// Fields
	struct FString SenderId; // Offset: 0x90 | Size: 0x10
	bool IsISent; // Offset: 0xa0 | Size: 0x1
	char pad_0xA1[0x7]; // Offset: 0xa1 | Size: 0x7
};

// Object: ScriptStruct LimNative.LimNativeGetOssTokenCallBack
// Inherited Bytes: 0x30 | Struct Size: 0xd0
struct FLimNativeGetOssTokenCallBack : FLimNativeDataCallBackBase {
	// Fields
	struct FLimNativeGetOssTokenData Data; // Offset: 0x30 | Size: 0xa0
};

// Object: ScriptStruct LimNative.LimNativeGetOssTokenData
// Inherited Bytes: 0x28 | Struct Size: 0xa0
struct FLimNativeGetOssTokenData : FLimNativeDataCallBackDataBase {
	// Fields
	struct FLimNativeOssTokenData Data; // Offset: 0x28 | Size: 0x70
	int32_t ResultCode; // Offset: 0x98 | Size: 0x4
	char pad_0x9C[0x4]; // Offset: 0x9c | Size: 0x4
};

// Object: ScriptStruct LimNative.LimNativeOssTokenData
// Inherited Bytes: 0x8 | Struct Size: 0x70
struct FLimNativeOssTokenData : FLimNativeDataObjectBase {
	// Fields
	struct FString AssessKeyID; // Offset: 0x8 | Size: 0x10
	struct FString AccessKeySecret; // Offset: 0x18 | Size: 0x10
	int32_t ExpirationUtc; // Offset: 0x28 | Size: 0x4
	char pad_0x2C[0x4]; // Offset: 0x2c | Size: 0x4
	struct FString SecurityToken; // Offset: 0x30 | Size: 0x10
	struct FString Bucket; // Offset: 0x40 | Size: 0x10
	struct FString EndPoint; // Offset: 0x50 | Size: 0x10
	struct FString FilePath; // Offset: 0x60 | Size: 0x10
};

// Object: ScriptStruct LimNative.LimNativeOnGetUserCallBack
// Inherited Bytes: 0x30 | Struct Size: 0x168
struct FLimNativeOnGetUserCallBack : FLimNativeDataCallBackBase {
	// Fields
	struct FLimNativeGetUserData Data; // Offset: 0x30 | Size: 0x138
};

// Object: ScriptStruct LimNative.LimNativeGetUserData
// Inherited Bytes: 0x28 | Struct Size: 0x138
struct FLimNativeGetUserData : FLimNativeDataCallBackDataBase {
	// Fields
	struct FString AvatarFrameUrl; // Offset: 0x28 | Size: 0x10
	struct FString AvatarUrl; // Offset: 0x38 | Size: 0x10
	int32_t CreateTime; // Offset: 0x48 | Size: 0x4
	char pad_0x4C[0x4]; // Offset: 0x4c | Size: 0x4
	struct FGuild Guild; // Offset: 0x50 | Size: 0x48
	struct FKingdom Kingdom; // Offset: 0x98 | Size: 0x48
	int32_t LastFetchTime; // Offset: 0xe0 | Size: 0x4
	char pad_0xE4[0x4]; // Offset: 0xe4 | Size: 0x4
	struct FString NickName; // Offset: 0xe8 | Size: 0x10
	int32_t ServerTime; // Offset: 0xf8 | Size: 0x4
	bool IsShowVip; // Offset: 0xfc | Size: 0x1
	char pad_0xFD[0x3]; // Offset: 0xfd | Size: 0x3
	struct TArray<struct FSubTitleItem> SubTitleList; // Offset: 0x100 | Size: 0x10
	struct FString Uid; // Offset: 0x110 | Size: 0x10
	int32_t VipLevel; // Offset: 0x120 | Size: 0x4
	char pad_0x124[0x4]; // Offset: 0x124 | Size: 0x4
	struct FString GameExtra; // Offset: 0x128 | Size: 0x10
};

// Object: ScriptStruct LimNative.LimNativeOnGetUsersCallBack
// Inherited Bytes: 0x30 | Struct Size: 0x68
struct FLimNativeOnGetUsersCallBack : FLimNativeDataCallBackBase {
	// Fields
	struct FLimNativeGetUsersData Data; // Offset: 0x30 | Size: 0x38
};

// Object: ScriptStruct LimNative.LimNativeGetUsersData
// Inherited Bytes: 0x28 | Struct Size: 0x38
struct FLimNativeGetUsersData : FLimNativeDataCallBackDataBase {
	// Fields
	struct TArray<struct FLimNativeGetUserData> DataResultList; // Offset: 0x28 | Size: 0x10
};

// Object: ScriptStruct LimNative.LimNativeOnGetUsersStateCallBack
// Inherited Bytes: 0x30 | Struct Size: 0xa8
struct FLimNativeOnGetUsersStateCallBack : FLimNativeDataCallBackBase {
	// Fields
	struct FUsersPresence Data; // Offset: 0x30 | Size: 0x78
};

// Object: ScriptStruct LimNative.UsersPresence
// Inherited Bytes: 0x28 | Struct Size: 0x78
struct FUsersPresence : FLimNativeDataCallBackDataBase {
	// Fields
	struct TMap<struct FString, struct FPresence> Result; // Offset: 0x28 | Size: 0x50
};

// Object: ScriptStruct LimNative.LimNativeOnGroupJoinCallBack
// Inherited Bytes: 0x30 | Struct Size: 0x30
struct FLimNativeOnGroupJoinCallBack : FLimNativeDataCallBackBase {
};

// Object: ScriptStruct LimNative.LimNativeOnLoginCallBack
// Inherited Bytes: 0x30 | Struct Size: 0x30
struct FLimNativeOnLoginCallBack : FLimNativeDataCallBackBase {
};

// Object: ScriptStruct LimNative.LimNativeOnLogoutCallBack
// Inherited Bytes: 0x30 | Struct Size: 0x30
struct FLimNativeOnLogoutCallBack : FLimNativeDataCallBackBase {
};

// Object: ScriptStruct LimNative.LimNativeOnMsgLogicReceivedEventCallBack
// Inherited Bytes: 0x8 | Struct Size: 0x38
struct FLimNativeOnMsgLogicReceivedEventCallBack : FLimNativeDataObjectBase {
	// Fields
	struct FLimNativeMsgLogiMsgData Data; // Offset: 0x8 | Size: 0x30
};

// Object: ScriptStruct LimNative.LimNativeMsgLogiMsgData
// Inherited Bytes: 0x8 | Struct Size: 0x30
struct FLimNativeMsgLogiMsgData : FLimNativeDataObjectBase {
	// Fields
	struct FLimNativeMsgLogiCommonMsgData Data; // Offset: 0x8 | Size: 0x28
};

// Object: ScriptStruct LimNative.LimNativeMsgLogiCommonMsgData
// Inherited Bytes: 0x8 | Struct Size: 0x28
struct FLimNativeMsgLogiCommonMsgData : FLimNativeDataObjectBase {
	// Fields
	int32_t Type; // Offset: 0x8 | Size: 0x4
	char pad_0xC[0x4]; // Offset: 0xc | Size: 0x4
	struct FLimNativeDataBizFullObj BizObj; // Offset: 0x10 | Size: 0x18
};

// Object: ScriptStruct LimNative.LimNativeDataBizFullObj
// Inherited Bytes: 0x8 | Struct Size: 0x18
struct FLimNativeDataBizFullObj : FLimNativeDataObjectBase {
	// Fields
	struct FString Uid; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct LimNative.LimNativeOnMsgReceivedEventCallBack
// Inherited Bytes: 0x8 | Struct Size: 0x40
struct FLimNativeOnMsgReceivedEventCallBack : FLimNativeDataObjectBase {
	// Fields
	struct FLimNativeOnMsgReceivedData Data; // Offset: 0x8 | Size: 0x38
};

// Object: ScriptStruct LimNative.LimNativeOnMsgReceivedData
// Inherited Bytes: 0x28 | Struct Size: 0x38
struct FLimNativeOnMsgReceivedData : FLimNativeDataCallBackDataBase {
	// Fields
	struct TArray<struct FLimNativeReceivedMsgData> MsgDataList; // Offset: 0x28 | Size: 0x10
};

// Object: ScriptStruct LimNative.LimNativeReceivedMsgData
// Inherited Bytes: 0x28 | Struct Size: 0xc8
struct FLimNativeReceivedMsgData : FLimNativeDataCallBackDataBase {
	// Fields
	struct FString LanguageList; // Offset: 0x28 | Size: 0x10
	struct FString SenderId; // Offset: 0x38 | Size: 0x10
	struct FString MsgId; // Offset: 0x48 | Size: 0x10
	struct FLimNativeIMChatMessage Msg; // Offset: 0x58 | Size: 0x70
};

// Object: ScriptStruct LimNative.LimNativeOnMsgRevokedEventCallBack
// Inherited Bytes: 0x8 | Struct Size: 0x60
struct FLimNativeOnMsgRevokedEventCallBack : FLimNativeDataObjectBase {
	// Fields
	struct FLimNativeOnMsgRevokedData Data; // Offset: 0x8 | Size: 0x58
};

// Object: ScriptStruct LimNative.LimNativeOnMsgRevokedData
// Inherited Bytes: 0x28 | Struct Size: 0x58
struct FLimNativeOnMsgRevokedData : FLimNativeDataCallBackDataBase {
	// Fields
	struct FString ConvID; // Offset: 0x28 | Size: 0x10
	enum class ELimNativeConvType ConvType; // Offset: 0x38 | Size: 0x1
	char pad_0x39[0x7]; // Offset: 0x39 | Size: 0x7
	struct FString MessageId; // Offset: 0x40 | Size: 0x10
	int32_t SenderId; // Offset: 0x50 | Size: 0x4
	char pad_0x54[0x4]; // Offset: 0x54 | Size: 0x4
};

// Object: ScriptStruct LimNative.LimNativeOnGroupQuitCallBack
// Inherited Bytes: 0x30 | Struct Size: 0x50
struct FLimNativeOnGroupQuitCallBack : FLimNativeDataCallBackBase {
	// Fields
	struct FString GameID; // Offset: 0x30 | Size: 0x10
	struct FString ChannelId; // Offset: 0x40 | Size: 0x10
};

// Object: ScriptStruct LimNative.LimNativeOnGroupMemberRemoveCallBack
// Inherited Bytes: 0x30 | Struct Size: 0x98
struct FLimNativeOnGroupMemberRemoveCallBack : FLimNativeDataCallBackBase {
	// Fields
	struct FLimNativeIMGroup Data; // Offset: 0x30 | Size: 0x68
};

// Object: ScriptStruct LimNative.LimNativeOnRevokeMsgCallBack
// Inherited Bytes: 0x30 | Struct Size: 0x30
struct FLimNativeOnRevokeMsgCallBack : FLimNativeDataCallBackBase {
};

// Object: ScriptStruct LimNative.LimNativeOnSendMsgCallBack
// Inherited Bytes: 0x30 | Struct Size: 0xc0
struct FLimNativeOnSendMsgCallBack : FLimNativeDataCallBackBase {
	// Fields
	struct FLimNativeOnChatMsgCallBackData Data; // Offset: 0x30 | Size: 0x90
};

// Object: ScriptStruct LimNative.LimNativeOnSetConvReadCallBack
// Inherited Bytes: 0x30 | Struct Size: 0x30
struct FLimNativeOnSetConvReadCallBack : FLimNativeDataCallBackBase {
};

// Object: ScriptStruct LimNative.LimNativeOnGroupAttrSetCallBack
// Inherited Bytes: 0x30 | Struct Size: 0x30
struct FLimNativeOnGroupAttrSetCallBack : FLimNativeDataCallBackBase {
};

// Object: ScriptStruct LimNative.LimNativeLanguageConfig
// Inherited Bytes: 0x8 | Struct Size: 0x10
struct FLimNativeLanguageConfig : FLimNativeDataObjectBase {
	// Fields
	enum class ELimNativeSupportedLanguage Lang; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x7]; // Offset: 0x9 | Size: 0x7
};

// Object: ScriptStruct LimNative.LimNativeOnSetMsgStateCallBack
// Inherited Bytes: 0x30 | Struct Size: 0x30
struct FLimNativeOnSetMsgStateCallBack : FLimNativeDataCallBackBase {
};

// Object: ScriptStruct LimNative.LimNativeParkConfig
// Inherited Bytes: 0x8 | Struct Size: 0x58
struct FLimNativeParkConfig : FLimNativeDataObjectBase {
	// Fields
	struct FString App_Id; // Offset: 0x8 | Size: 0x10
	struct FString Sdk_Env; // Offset: 0x18 | Size: 0x10
	struct FString Sdk_Region; // Offset: 0x28 | Size: 0x10
	struct FString Gid; // Offset: 0x38 | Size: 0x10
	struct FString SlsSvr; // Offset: 0x48 | Size: 0x10
};

// Object: ScriptStruct LimNative.LimNativeReportConfig
// Inherited Bytes: 0x8 | Struct Size: 0xc8
struct FLimNativeReportConfig : FLimNativeDataObjectBase {
	// Fields
	struct FString PackageName; // Offset: 0x8 | Size: 0x10
	struct FString Android_Id; // Offset: 0x18 | Size: 0x10
	struct FString Goodle_Aid; // Offset: 0x28 | Size: 0x10
	struct FString Os_Version; // Offset: 0x38 | Size: 0x10
	struct FString Mac; // Offset: 0x48 | Size: 0x10
	struct FString Device_Model; // Offset: 0x58 | Size: 0x10
	struct FString Open_Id; // Offset: 0x68 | Size: 0x10
	struct FString Idfa; // Offset: 0x78 | Size: 0x10
	struct FString App_Version; // Offset: 0x88 | Size: 0x10
	struct FString Server_Id; // Offset: 0x98 | Size: 0x10
	struct FString Device_Id; // Offset: 0xa8 | Size: 0x10
	struct FString SlsSvr; // Offset: 0xb8 | Size: 0x10
};

// Object: ScriptStruct LimNative.LimNativeResDirConfig
// Inherited Bytes: 0x8 | Struct Size: 0x18
struct FLimNativeResDirConfig : FLimNativeDataObjectBase {
	// Fields
	struct FString ResDir; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct LimNative.LimNativeTextTranslateCallBack
// Inherited Bytes: 0x30 | Struct Size: 0x88
struct FLimNativeTextTranslateCallBack : FLimNativeDataCallBackBase {
	// Fields
	struct FLimNativeTextTranslateData Data; // Offset: 0x30 | Size: 0x58
};

// Object: ScriptStruct LimNative.LimNativeTextTranslateData
// Inherited Bytes: 0x28 | Struct Size: 0x58
struct FLimNativeTextTranslateData : FLimNativeDataCallBackDataBase {
	// Fields
	struct FString TranslatedText; // Offset: 0x28 | Size: 0x10
	struct FString Translator; // Offset: 0x38 | Size: 0x10
	struct FString ExtraInfo; // Offset: 0x48 | Size: 0x10
};

// Object: ScriptStruct LimNative.LimNativeIMChatMessageBase
// Inherited Bytes: 0x8 | Struct Size: 0x58
struct FLimNativeIMChatMessageBase : FLimNativeDataObjectBase {
	// Fields
	char pad_0x8[0x50]; // Offset: 0x8 | Size: 0x50
};

// Object: ScriptStruct LimNative.LimNativeIMEmotionMessage
// Inherited Bytes: 0x58 | Struct Size: 0xb0
struct FLimNativeIMEmotionMessage : FLimNativeIMChatMessageBase {
	// Fields
	struct FString PackName; // Offset: 0x58 | Size: 0x10
	enum class ELimNativePackType PackType; // Offset: 0x68 | Size: 0x1
	char pad_0x69[0x7]; // Offset: 0x69 | Size: 0x7
	struct FString EmotionName; // Offset: 0x70 | Size: 0x10
	struct FString EmotionId; // Offset: 0x80 | Size: 0x10
	struct FString EmotionUrl; // Offset: 0x90 | Size: 0x10
	struct FString Desc; // Offset: 0xa0 | Size: 0x10
};

// Object: ScriptStruct LimNative.LimNativeIMImageMessage
// Inherited Bytes: 0x58 | Struct Size: 0xa0
struct FLimNativeIMImageMessage : FLimNativeIMChatMessageBase {
	// Fields
	struct FString UUID; // Offset: 0x58 | Size: 0x10
	struct FString Fmt; // Offset: 0x68 | Size: 0x10
	struct FString URL; // Offset: 0x78 | Size: 0x10
	int32_t Width; // Offset: 0x88 | Size: 0x4
	int32_t Height; // Offset: 0x8c | Size: 0x4
	struct FString Size; // Offset: 0x90 | Size: 0x10
};

// Object: ScriptStruct LimNative.LimNativeIMShareMessage
// Inherited Bytes: 0x58 | Struct Size: 0xc0
struct FLimNativeIMShareMessage : FLimNativeIMChatMessageBase {
	// Fields
	int32_t Type; // Offset: 0x58 | Size: 0x4
	char pad_0x5C[0x4]; // Offset: 0x5c | Size: 0x4
	struct FString Text; // Offset: 0x60 | Size: 0x10
	struct FString Title; // Offset: 0x70 | Size: 0x10
	struct FString Detail; // Offset: 0x80 | Size: 0x10
	struct FString Img; // Offset: 0x90 | Size: 0x10
	struct FString URL; // Offset: 0xa0 | Size: 0x10
	struct FString Extra; // Offset: 0xb0 | Size: 0x10
};

// Object: ScriptStruct LimNative.LimNativeIMTextMessage
// Inherited Bytes: 0x58 | Struct Size: 0x68
struct FLimNativeIMTextMessage : FLimNativeIMChatMessageBase {
	// Fields
	struct FString Text; // Offset: 0x58 | Size: 0x10
};

// Object: ScriptStruct LimNative.LimNativeIMTextWithAtMessage
// Inherited Bytes: 0x58 | Struct Size: 0x68
struct FLimNativeIMTextWithAtMessage : FLimNativeIMChatMessageBase {
	// Fields
	struct FString Text; // Offset: 0x58 | Size: 0x10
};

// Object: ScriptStruct LimNative.LimNativeIMVoiceMessage
// Inherited Bytes: 0x58 | Struct Size: 0x90
struct FLimNativeIMVoiceMessage : FLimNativeIMChatMessageBase {
	// Fields
	struct FString UUID; // Offset: 0x58 | Size: 0x10
	struct FString URL; // Offset: 0x68 | Size: 0x10
	struct FString Size; // Offset: 0x78 | Size: 0x10
	int32_t Duration; // Offset: 0x88 | Size: 0x4
	char pad_0x8C[0x4]; // Offset: 0x8c | Size: 0x4
};

// Object: ScriptStruct LimNative.LimNativeSetMsgState
// Inherited Bytes: 0x8 | Struct Size: 0x40
struct FLimNativeSetMsgState : FLimNativeDataObjectBase {
	// Fields
	enum class ELimNativeConvType ConvType; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x7]; // Offset: 0x9 | Size: 0x7
	struct FString ConvID; // Offset: 0x10 | Size: 0x10
	enum class ELimNativeMsgContentType MsgType; // Offset: 0x20 | Size: 0x1
	char pad_0x21[0x7]; // Offset: 0x21 | Size: 0x7
	struct FString MsgId; // Offset: 0x28 | Size: 0x10
	enum class ELimNativeMsgState MsgState; // Offset: 0x38 | Size: 0x1
	char pad_0x39[0x7]; // Offset: 0x39 | Size: 0x7
};

// Object: ScriptStruct LimNative.LimNativeOnMsgLogicReceivedData
// Inherited Bytes: 0x28 | Struct Size: 0x38
struct FLimNativeOnMsgLogicReceivedData : FLimNativeDataCallBackDataBase {
	// Fields
	struct TArray<struct FLimNativeCommonMsg> CommonMessage; // Offset: 0x28 | Size: 0x10
};

// Object: ScriptStruct LimNative.LimNativeBizObjFriendBase
// Inherited Bytes: 0x8 | Struct Size: 0x48
struct FLimNativeBizObjFriendBase : FLimNativeDataObjectBase {
	// Fields
	struct FString Uid; // Offset: 0x8 | Size: 0x10
	struct FString NickName; // Offset: 0x18 | Size: 0x10
	struct FString AvatarUrl; // Offset: 0x28 | Size: 0x10
	struct FString AvatarFrameUrl; // Offset: 0x38 | Size: 0x10
};

// Object: ScriptStruct LimNative.LimNativeBizObjRefreshFriend
// Inherited Bytes: 0x48 | Struct Size: 0x58
struct FLimNativeBizObjRefreshFriend : FLimNativeBizObjFriendBase {
	// Fields
	struct FString EmblemUrls; // Offset: 0x48 | Size: 0x10
};

// Object: ScriptStruct LimNative.LimNativeBizObjFriendRequest
// Inherited Bytes: 0x48 | Struct Size: 0x98
struct FLimNativeBizObjFriendRequest : FLimNativeBizObjFriendBase {
	// Fields
	struct FString RequestID; // Offset: 0x48 | Size: 0x10
	struct FString RequestMsg; // Offset: 0x58 | Size: 0x10
	struct FString RequestSource; // Offset: 0x68 | Size: 0x10
	struct FString Timestamp; // Offset: 0x78 | Size: 0x10
	struct FString Lang; // Offset: 0x88 | Size: 0x10
};

// Object: ScriptStruct LimNative.LimNativeBizObjGroupBase
// Inherited Bytes: 0x8 | Struct Size: 0x18
struct FLimNativeBizObjGroupBase : FLimNativeDataObjectBase {
	// Fields
	struct FString groupid; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct LimNative.LimNativeBizObjExitGroup
// Inherited Bytes: 0x18 | Struct Size: 0x30
struct FLimNativeBizObjExitGroup : FLimNativeBizObjGroupBase {
	// Fields
	enum class ELimNativeGroupType Type; // Offset: 0x18 | Size: 0x1
	char pad_0x19[0x7]; // Offset: 0x19 | Size: 0x7
	struct FString Uid; // Offset: 0x20 | Size: 0x10
};

// Object: ScriptStruct LimNative.LimNativeBizObjGroupPerms
// Inherited Bytes: 0x18 | Struct Size: 0x28
struct FLimNativeBizObjGroupPerms : FLimNativeBizObjGroupBase {
	// Fields
	struct FString Perms; // Offset: 0x18 | Size: 0x10
};

// Object: ScriptStruct LimNative.LimNativeIMNotificationMessage
// Inherited Bytes: 0x58 | Struct Size: 0x68
struct FLimNativeIMNotificationMessage : FLimNativeIMChatMessageBase {
	// Fields
	struct FString Text; // Offset: 0x58 | Size: 0x10
};

// Object: ScriptStruct LimNative.LimNativeEventDataBase
// Inherited Bytes: 0x8 | Struct Size: 0x40
struct FLimNativeEventDataBase : FLimNativeDataObjectBase {
	// Fields
	struct FString JsonData; // Offset: 0x8 | Size: 0x10
	struct FString ErrorCode; // Offset: 0x18 | Size: 0x10
	struct FString Message; // Offset: 0x28 | Size: 0x10
	enum class ELimNativeEventType EventCode; // Offset: 0x38 | Size: 0x1
	char pad_0x39[0x7]; // Offset: 0x39 | Size: 0x7
};

