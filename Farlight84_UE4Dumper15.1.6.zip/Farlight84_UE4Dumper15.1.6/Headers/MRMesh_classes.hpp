#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class MRMesh.MeshReconstructorBase
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UMeshReconstructorBase : UObject {
	// Functions

	// Object: Function MRMesh.MeshReconstructorBase.StopReconstruction
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x10412f580
	// Return & Params: [ Num(0) Size(0x0) ]
	void StopReconstruction();

	// Object: Function MRMesh.MeshReconstructorBase.StartReconstruction
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x10412f59c
	// Return & Params: [ Num(0) Size(0x0) ]
	void StartReconstruction();

	// Object: Function MRMesh.MeshReconstructorBase.PauseReconstruction
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x10412f564
	// Return & Params: [ Num(0) Size(0x0) ]
	void PauseReconstruction();

	// Object: Function MRMesh.MeshReconstructorBase.IsReconstructionStarted
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10412f528
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsReconstructionStarted();

	// Object: Function MRMesh.MeshReconstructorBase.IsReconstructionPaused
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10412f4ec
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsReconstructionPaused();

	// Object: Function MRMesh.MeshReconstructorBase.DisconnectMRMesh
	// Flags: [Native|Public]
	// Offset: 0x10412f448
	// Return & Params: [ Num(0) Size(0x0) ]
	void DisconnectMRMesh();

	// Object: Function MRMesh.MeshReconstructorBase.ConnectMRMesh
	// Flags: [Native|Public]
	// Offset: 0x10412f464
	// Return & Params: [ Num(1) Size(0x8) ]
	void ConnectMRMesh(struct UMRMeshComponent* Mesh);
};

// Object: Class MRMesh.MockDataMeshTrackerComponent
// Inherited Bytes: 0x350 | Struct Size: 0x3c0
struct UMockDataMeshTrackerComponent : USceneComponent {
	// Fields
	struct FMulticastInlineDelegate OnMeshTrackerUpdated; // Offset: 0x348 | Size: 0x10
	bool ScanWorld; // Offset: 0x358 | Size: 0x1
	bool RequestNormals; // Offset: 0x359 | Size: 0x1
	bool RequestVertexConfidence; // Offset: 0x35a | Size: 0x1
	enum class EMeshTrackerVertexColorMode VertexColorMode; // Offset: 0x35b | Size: 0x1
	struct TArray<struct FColor> BlockVertexColors; // Offset: 0x360 | Size: 0x10
	struct FLinearColor VertexColorFromConfidenceZero; // Offset: 0x370 | Size: 0x10
	struct FLinearColor VertexColorFromConfidenceOne; // Offset: 0x380 | Size: 0x10
	float UpdateInterval; // Offset: 0x390 | Size: 0x4
	struct UMRMeshComponent* MRMesh; // Offset: 0x398 | Size: 0x8
	char pad_0x3A0[0x20]; // Offset: 0x3a0 | Size: 0x20

	// Functions

	// Object: DelegateFunction MRMesh.MockDataMeshTrackerComponent.OnMockDataMeshTrackerUpdated__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103a43990
	// Return & Params: [ Num(5) Size(0x48) ]
	void OnMockDataMeshTrackerUpdated__DelegateSignature(int32_t Index, struct TArray<struct FVector>& Vertices, struct TArray<int32_t>& Triangles, struct TArray<struct FVector>& Normals, struct TArray<float>& Confidence);

	// Object: Function MRMesh.MockDataMeshTrackerComponent.DisconnectMRMesh
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10412fbdc
	// Return & Params: [ Num(1) Size(0x8) ]
	void DisconnectMRMesh(struct UMRMeshComponent* InMRMeshPtr);

	// Object: Function MRMesh.MockDataMeshTrackerComponent.ConnectMRMesh
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10412fc5c
	// Return & Params: [ Num(1) Size(0x8) ]
	void ConnectMRMesh(struct UMRMeshComponent* InMRMeshPtr);
};

// Object: Class MRMesh.MRMeshComponent
// Inherited Bytes: 0x570 | Struct Size: 0x5f0
struct UMRMeshComponent : UPrimitiveComponent {
	// Fields
	char pad_0x570[0x8]; // Offset: 0x570 | Size: 0x8
	struct UMaterialInterface* Material; // Offset: 0x578 | Size: 0x8
	bool bCreateMeshProxySections; // Offset: 0x580 | Size: 0x1
	bool bUpdateNavMeshOnMeshUpdate; // Offset: 0x581 | Size: 0x1
	bool bNeverCreateCollisionMesh; // Offset: 0x582 | Size: 0x1
	char pad_0x583[0x5]; // Offset: 0x583 | Size: 0x5
	struct UBodySetup* CachedBodySetup; // Offset: 0x588 | Size: 0x8
	struct TArray<struct UBodySetup*> BodySetups; // Offset: 0x590 | Size: 0x10
	struct UMaterialInterface* WireframeMaterial; // Offset: 0x5a0 | Size: 0x8
	char pad_0x5A8[0x48]; // Offset: 0x5a8 | Size: 0x48

	// Functions

	// Object: Function MRMesh.MRMeshComponent.IsConnected
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10412ff58
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsConnected();

	// Object: Function MRMesh.MRMeshComponent.ForceNavMeshUpdate
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10412ff44
	// Return & Params: [ Num(0) Size(0x0) ]
	void ForceNavMeshUpdate();

	// Object: Function MRMesh.MRMeshComponent.Clear
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10412ff28
	// Return & Params: [ Num(0) Size(0x0) ]
	void Clear();
};

