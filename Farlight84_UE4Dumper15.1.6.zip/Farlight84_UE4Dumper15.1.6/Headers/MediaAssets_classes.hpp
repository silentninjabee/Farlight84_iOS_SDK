#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class MediaAssets.MediaSource
// Inherited Bytes: 0x28 | Struct Size: 0x80
struct UMediaSource : UObject {
	// Fields
	char pad_0x28[0x58]; // Offset: 0x28 | Size: 0x58

	// Functions

	// Object: Function MediaAssets.MediaSource.Validate
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c32b90
	// Return & Params: [ Num(1) Size(0x1) ]
	bool Validate();

	// Object: Function MediaAssets.MediaSource.SetMediaOptionString
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104c327f8
	// Return & Params: [ Num(2) Size(0x18) ]
	void SetMediaOptionString(struct FName& Key, struct FString Value);

	// Object: Function MediaAssets.MediaSource.SetMediaOptionInt64
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104c328dc
	// Return & Params: [ Num(2) Size(0x10) ]
	void SetMediaOptionInt64(struct FName& Key, int64_t Value);

	// Object: Function MediaAssets.MediaSource.SetMediaOptionFloat
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104c329c0
	// Return & Params: [ Num(2) Size(0xc) ]
	void SetMediaOptionFloat(struct FName& Key, float Value);

	// Object: Function MediaAssets.MediaSource.SetMediaOptionBool
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104c32aa4
	// Return & Params: [ Num(2) Size(0x9) ]
	void SetMediaOptionBool(struct FName& Key, bool Value);

	// Object: Function MediaAssets.MediaSource.GetUrl
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c32bcc
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetUrl();
};

// Object: Class MediaAssets.BaseMediaSource
// Inherited Bytes: 0x80 | Struct Size: 0x88
struct UBaseMediaSource : UMediaSource {
	// Fields
	struct FName playerName; // Offset: 0x80 | Size: 0x8
};

// Object: Class MediaAssets.FileMediaSource
// Inherited Bytes: 0x88 | Struct Size: 0xb0
struct UFileMediaSource : UBaseMediaSource {
	// Fields
	struct FString FilePath; // Offset: 0x88 | Size: 0x10
	bool PrecacheFile; // Offset: 0x98 | Size: 0x1
	char pad_0x99[0x17]; // Offset: 0x99 | Size: 0x17

	// Functions

	// Object: Function MediaAssets.FileMediaSource.SetFilePath
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c2b4b0
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetFilePath(struct FString Path);
};

// Object: Class MediaAssets.MediaBlueprintFunctionLibrary
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UMediaBlueprintFunctionLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object: Function MediaAssets.MediaBlueprintFunctionLibrary.EnumerateWebcamCaptureDevices
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104c2bc84
	// Return & Params: [ Num(2) Size(0x14) ]
	void EnumerateWebcamCaptureDevices(struct TArray<struct FMediaCaptureDevice>& OutDevices, int32_t Filter);

	// Object: Function MediaAssets.MediaBlueprintFunctionLibrary.EnumerateVideoCaptureDevices
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104c2bdec
	// Return & Params: [ Num(2) Size(0x14) ]
	void EnumerateVideoCaptureDevices(struct TArray<struct FMediaCaptureDevice>& OutDevices, int32_t Filter);

	// Object: Function MediaAssets.MediaBlueprintFunctionLibrary.EnumerateAudioCaptureDevices
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104c2bf54
	// Return & Params: [ Num(2) Size(0x14) ]
	void EnumerateAudioCaptureDevices(struct TArray<struct FMediaCaptureDevice>& OutDevices, int32_t Filter);
};

// Object: Class MediaAssets.MediaComponent
// Inherited Bytes: 0xb0 | Struct Size: 0xc0
struct UMediaComponent : UActorComponent {
	// Fields
	struct UMediaTexture* MediaTexture; // Offset: 0xb0 | Size: 0x8
	struct UMediaPlayer* MediaPlayer; // Offset: 0xb8 | Size: 0x8

	// Functions

	// Object: Function MediaAssets.MediaComponent.GetMediaTexture
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c2c390
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UMediaTexture* GetMediaTexture();

	// Object: Function MediaAssets.MediaComponent.GetMediaPlayer
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c2c3c4
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UMediaPlayer* GetMediaPlayer();
};

// Object: Class MediaAssets.MediaPlayer
// Inherited Bytes: 0x28 | Struct Size: 0x138
struct UMediaPlayer : UObject {
	// Fields
	struct FMulticastInlineDelegate OnEndReached; // Offset: 0x28 | Size: 0x10
	struct FMulticastInlineDelegate OnMediaClosed; // Offset: 0x38 | Size: 0x10
	struct FMulticastInlineDelegate OnMediaOpened; // Offset: 0x48 | Size: 0x10
	struct FMulticastInlineDelegate OnMediaOpenFailed; // Offset: 0x58 | Size: 0x10
	struct FMulticastInlineDelegate OnPlaybackResumed; // Offset: 0x68 | Size: 0x10
	struct FMulticastInlineDelegate OnPlaybackSuspended; // Offset: 0x78 | Size: 0x10
	struct FMulticastInlineDelegate OnSeekCompleted; // Offset: 0x88 | Size: 0x10
	struct FMulticastInlineDelegate OnTracksChanged; // Offset: 0x98 | Size: 0x10
	struct FTimespan CacheAhead; // Offset: 0xa8 | Size: 0x8
	struct FTimespan CacheBehind; // Offset: 0xb0 | Size: 0x8
	struct FTimespan CacheBehindGame; // Offset: 0xb8 | Size: 0x8
	bool NativeAudioOut; // Offset: 0xc0 | Size: 0x1
	bool PlayOnOpen; // Offset: 0xc1 | Size: 0x1
	char Shuffle : 1; // Offset: 0xc2 | Size: 0x1
	char Loop : 1; // Offset: 0xc2 | Size: 0x1
	char pad_0xC2_2 : 6; // Offset: 0xc2 | Size: 0x1
	char pad_0xC3[0x5]; // Offset: 0xc3 | Size: 0x5
	struct UMediaPlaylist* Playlist; // Offset: 0xc8 | Size: 0x8
	int32_t PlaylistIndex; // Offset: 0xd0 | Size: 0x4
	char pad_0xD4[0x4]; // Offset: 0xd4 | Size: 0x4
	struct FTimespan TimeDelay; // Offset: 0xd8 | Size: 0x8
	float HorizontalFieldOfView; // Offset: 0xe0 | Size: 0x4
	float VerticalFieldOfView; // Offset: 0xe4 | Size: 0x4
	struct FRotator ViewRotation; // Offset: 0xe8 | Size: 0xc
	char pad_0xF4[0x2c]; // Offset: 0xf4 | Size: 0x2c
	struct FGuid PlayerGuid; // Offset: 0x120 | Size: 0x10
	char pad_0x130[0x8]; // Offset: 0x130 | Size: 0x8

	// Functions

	// Object: Function MediaAssets.MediaPlayer.SupportsSeeking
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c2ca18
	// Return & Params: [ Num(1) Size(0x1) ]
	bool SupportsSeeking();

	// Object: Function MediaAssets.MediaPlayer.SupportsScrubbing
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c2ca4c
	// Return & Params: [ Num(1) Size(0x1) ]
	bool SupportsScrubbing();

	// Object: Function MediaAssets.MediaPlayer.SupportsRate
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c2ca80
	// Return & Params: [ Num(3) Size(0x6) ]
	bool SupportsRate(float Rate, bool Unthinned);

	// Object: Function MediaAssets.MediaPlayer.SetViewRotation
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x104c2cbe0
	// Return & Params: [ Num(3) Size(0xe) ]
	bool SetViewRotation(struct FRotator& Rotation, bool Absolute);

	// Object: Function MediaAssets.MediaPlayer.SetViewField
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c2ccd0
	// Return & Params: [ Num(4) Size(0xa) ]
	bool SetViewField(float Horizontal, float Vertical, bool Absolute);

	// Object: Function MediaAssets.MediaPlayer.SetVideoTrackFrameRate
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c2cdfc
	// Return & Params: [ Num(4) Size(0xd) ]
	bool SetVideoTrackFrameRate(int32_t TrackIndex, int32_t FormatIndex, float FrameRate);

	// Object: Function MediaAssets.MediaPlayer.SetTrackFormat
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c2cf20
	// Return & Params: [ Num(4) Size(0xd) ]
	bool SetTrackFormat(enum class EMediaPlayerTrack TrackType, int32_t TrackIndex, int32_t FormatIndex);

	// Object: Function MediaAssets.MediaPlayer.SetTimeDelay
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x104c2cb64
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetTimeDelay(struct FTimespan TimeDelay);

	// Object: Function MediaAssets.MediaPlayer.SetRate
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c2d0d4
	// Return & Params: [ Num(2) Size(0x5) ]
	bool SetRate(float Rate);

	// Object: Function MediaAssets.MediaPlayer.SetNativeVolume
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c2d044
	// Return & Params: [ Num(2) Size(0x5) ]
	bool SetNativeVolume(float Volume);

	// Object: Function MediaAssets.MediaPlayer.SetMediaOptions
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c2d164
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetMediaOptions(struct UMediaSource* options);

	// Object: Function MediaAssets.MediaPlayer.SetLooping
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c2d1e4
	// Return & Params: [ Num(2) Size(0x2) ]
	bool SetLooping(bool Looping);

	// Object: Function MediaAssets.MediaPlayer.SetDesiredPlayerName
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c2d27c
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetDesiredPlayerName(struct FName playerName);

	// Object: Function MediaAssets.MediaPlayer.SetBlockOnTime
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x104c2d2fc
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetBlockOnTime(struct FTimespan& Time);

	// Object: Function MediaAssets.MediaPlayer.SelectTrack
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c2d384
	// Return & Params: [ Num(3) Size(0x9) ]
	bool SelectTrack(enum class EMediaPlayerTrack TrackType, int32_t TrackIndex);

	// Object: Function MediaAssets.MediaPlayer.Seek
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x104c2d460
	// Return & Params: [ Num(2) Size(0x9) ]
	bool Seek(struct FTimespan& Time);

	// Object: Function MediaAssets.MediaPlayer.Rewind
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c2d4f8
	// Return & Params: [ Num(1) Size(0x1) ]
	bool Rewind();

	// Object: Function MediaAssets.MediaPlayer.Reopen
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c2d52c
	// Return & Params: [ Num(1) Size(0x1) ]
	bool Reopen();

	// Object: Function MediaAssets.MediaPlayer.Previous
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c2d560
	// Return & Params: [ Num(1) Size(0x1) ]
	bool Previous();

	// Object: Function MediaAssets.MediaPlayer.PlayAndSeek
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c2d594
	// Return & Params: [ Num(0) Size(0x0) ]
	void PlayAndSeek();

	// Object: Function MediaAssets.MediaPlayer.Play
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c2d5a8
	// Return & Params: [ Num(1) Size(0x1) ]
	bool Play();

	// Object: Function MediaAssets.MediaPlayer.Pause
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c2d5dc
	// Return & Params: [ Num(1) Size(0x1) ]
	bool Pause();

	// Object: Function MediaAssets.MediaPlayer.OpenUrl
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c2d610
	// Return & Params: [ Num(2) Size(0x11) ]
	bool OpenUrl(struct FString URL);

	// Object: Function MediaAssets.MediaPlayer.OpenSourceWithOptions
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104c2d8ac
	// Return & Params: [ Num(3) Size(0x39) ]
	bool OpenSourceWithOptions(struct UMediaSource* MediaSource, struct FMediaPlayerOptions& options);

	// Object: Function MediaAssets.MediaPlayer.OpenSourceLatent
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104c2d6ac
	// Return & Params: [ Num(5) Size(0x59) ]
	void OpenSourceLatent(struct UObject* WorldContextObject, struct FLatentActionInfo LatentInfo, struct UMediaSource* MediaSource, struct FMediaPlayerOptions& options, bool& bSuccess);

	// Object: Function MediaAssets.MediaPlayer.OpenSource
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c2d9a4
	// Return & Params: [ Num(2) Size(0x9) ]
	bool OpenSource(struct UMediaSource* MediaSource);

	// Object: Function MediaAssets.MediaPlayer.OpenPlaylistIndex
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c2da34
	// Return & Params: [ Num(3) Size(0xd) ]
	bool OpenPlaylistIndex(struct UMediaPlaylist* InPlaylist, int32_t Index);

	// Object: Function MediaAssets.MediaPlayer.OpenPlaylist
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c2db10
	// Return & Params: [ Num(2) Size(0x9) ]
	bool OpenPlaylist(struct UMediaPlaylist* InPlaylist);

	// Object: Function MediaAssets.MediaPlayer.OpenFile
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c2dba4
	// Return & Params: [ Num(2) Size(0x11) ]
	bool OpenFile(struct FString FilePath);

	// Object: Function MediaAssets.MediaPlayer.Next
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c2dc40
	// Return & Params: [ Num(1) Size(0x1) ]
	bool Next();

	// Object: Function MediaAssets.MediaPlayer.IsReady
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c2dc74
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsReady();

	// Object: Function MediaAssets.MediaPlayer.IsPreparing
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c2dcdc
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsPreparing();

	// Object: Function MediaAssets.MediaPlayer.IsPlaying
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c2dd10
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsPlaying();

	// Object: Function MediaAssets.MediaPlayer.IsPaused
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c2dd44
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsPaused();

	// Object: Function MediaAssets.MediaPlayer.IsLooping
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c2dd78
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsLooping();

	// Object: Function MediaAssets.MediaPlayer.IsConnecting
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c2ddac
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsConnecting();

	// Object: Function MediaAssets.MediaPlayer.IsClosed
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c2dca8
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsClosed();

	// Object: Function MediaAssets.MediaPlayer.IsBuffering
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c2dde0
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsBuffering();

	// Object: Function MediaAssets.MediaPlayer.HasError
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c2de14
	// Return & Params: [ Num(1) Size(0x1) ]
	bool HasError();

	// Object: Function MediaAssets.MediaPlayer.GetViewRotation
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c2de7c
	// Return & Params: [ Num(1) Size(0xc) ]
	struct FRotator GetViewRotation();

	// Object: Function MediaAssets.MediaPlayer.GetVideoTrackType
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c2deb4
	// Return & Params: [ Num(3) Size(0x18) ]
	struct FString GetVideoTrackType(int32_t TrackIndex, int32_t FormatIndex);

	// Object: Function MediaAssets.MediaPlayer.GetVideoTrackFrameRates
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c2dfd4
	// Return & Params: [ Num(3) Size(0x18) ]
	struct FFloatRange GetVideoTrackFrameRates(int32_t TrackIndex, int32_t FormatIndex);

	// Object: Function MediaAssets.MediaPlayer.GetVideoTrackFrameRate
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c2e0ac
	// Return & Params: [ Num(3) Size(0xc) ]
	float GetVideoTrackFrameRate(int32_t TrackIndex, int32_t FormatIndex);

	// Object: Function MediaAssets.MediaPlayer.GetVideoTrackDimensions
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c2e184
	// Return & Params: [ Num(3) Size(0x10) ]
	struct FIntPoint GetVideoTrackDimensions(int32_t TrackIndex, int32_t FormatIndex);

	// Object: Function MediaAssets.MediaPlayer.GetVideoTrackAspectRatio
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c2e25c
	// Return & Params: [ Num(3) Size(0xc) ]
	float GetVideoTrackAspectRatio(int32_t TrackIndex, int32_t FormatIndex);

	// Object: Function MediaAssets.MediaPlayer.GetVerticalFieldOfView
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c2e334
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetVerticalFieldOfView();

	// Object: Function MediaAssets.MediaPlayer.GetUrl
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c2e368
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetUrl();

	// Object: Function MediaAssets.MediaPlayer.GetTrackLanguage
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c2e3ec
	// Return & Params: [ Num(3) Size(0x18) ]
	struct FString GetTrackLanguage(enum class EMediaPlayerTrack TrackType, int32_t TrackIndex);

	// Object: Function MediaAssets.MediaPlayer.GetTrackFormat
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c2e510
	// Return & Params: [ Num(3) Size(0xc) ]
	int32_t GetTrackFormat(enum class EMediaPlayerTrack TrackType, int32_t TrackIndex);

	// Object: Function MediaAssets.MediaPlayer.GetTrackDisplayName
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c2e5ec
	// Return & Params: [ Num(3) Size(0x20) ]
	struct FText GetTrackDisplayName(enum class EMediaPlayerTrack TrackType, int32_t TrackIndex);

	// Object: Function MediaAssets.MediaPlayer.GetTimeDelay
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c2de48
	// Return & Params: [ Num(1) Size(0x8) ]
	struct FTimespan GetTimeDelay();

	// Object: Function MediaAssets.MediaPlayer.GetTime
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c2e79c
	// Return & Params: [ Num(1) Size(0x8) ]
	struct FTimespan GetTime();

	// Object: Function MediaAssets.MediaPlayer.GetSupportedRates
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c2e7d0
	// Return & Params: [ Num(2) Size(0x11) ]
	void GetSupportedRates(struct TArray<struct FFloatRange>& OutRates, bool Unthinned);

	// Object: Function MediaAssets.MediaPlayer.GetSelectedTrack
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c2e8bc
	// Return & Params: [ Num(2) Size(0x8) ]
	int32_t GetSelectedTrack(enum class EMediaPlayerTrack TrackType);

	// Object: Function MediaAssets.MediaPlayer.GetRate
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c2e94c
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetRate();

	// Object: Function MediaAssets.MediaPlayer.GetPlaylistIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c2e980
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetPlaylistIndex();

	// Object: Function MediaAssets.MediaPlayer.GetPlaylist
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c2e99c
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UMediaPlaylist* GetPlaylist();

	// Object: Function MediaAssets.MediaPlayer.GetPlayerName
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c2e9b8
	// Return & Params: [ Num(1) Size(0x8) ]
	struct FName GetPlayerName();

	// Object: Function MediaAssets.MediaPlayer.GetNumTracks
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c2eac8
	// Return & Params: [ Num(2) Size(0x8) ]
	int32_t GetNumTracks(enum class EMediaPlayerTrack TrackType);

	// Object: Function MediaAssets.MediaPlayer.GetNumTrackFormats
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c2e9ec
	// Return & Params: [ Num(3) Size(0xc) ]
	int32_t GetNumTrackFormats(enum class EMediaPlayerTrack TrackType, int32_t TrackIndex);

	// Object: Function MediaAssets.MediaPlayer.GetMediaName
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c2eb58
	// Return & Params: [ Num(1) Size(0x18) ]
	struct FText GetMediaName();

	// Object: Function MediaAssets.MediaPlayer.GetLastVideoSampleProcessedTime
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c2e734
	// Return & Params: [ Num(1) Size(0x8) ]
	struct FTimespan GetLastVideoSampleProcessedTime();

	// Object: Function MediaAssets.MediaPlayer.GetLastAudioSampleProcessedTime
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c2e768
	// Return & Params: [ Num(1) Size(0x8) ]
	struct FTimespan GetLastAudioSampleProcessedTime();

	// Object: Function MediaAssets.MediaPlayer.GetHorizontalFieldOfView
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c2ec08
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetHorizontalFieldOfView();

	// Object: Function MediaAssets.MediaPlayer.GetDuration
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c2ec3c
	// Return & Params: [ Num(1) Size(0x8) ]
	struct FTimespan GetDuration();

	// Object: Function MediaAssets.MediaPlayer.GetDesiredPlayerName
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c2ec70
	// Return & Params: [ Num(1) Size(0x8) ]
	struct FName GetDesiredPlayerName();

	// Object: Function MediaAssets.MediaPlayer.GetAudioTrackType
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c2eca4
	// Return & Params: [ Num(3) Size(0x18) ]
	struct FString GetAudioTrackType(int32_t TrackIndex, int32_t FormatIndex);

	// Object: Function MediaAssets.MediaPlayer.GetAudioTrackSampleRate
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c2edc4
	// Return & Params: [ Num(3) Size(0xc) ]
	int32_t GetAudioTrackSampleRate(int32_t TrackIndex, int32_t FormatIndex);

	// Object: Function MediaAssets.MediaPlayer.GetAudioTrackChannels
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c2ee9c
	// Return & Params: [ Num(3) Size(0xc) ]
	int32_t GetAudioTrackChannels(int32_t TrackIndex, int32_t FormatIndex);

	// Object: Function MediaAssets.MediaPlayer.Close
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c2ef74
	// Return & Params: [ Num(0) Size(0x0) ]
	void Close();

	// Object: Function MediaAssets.MediaPlayer.CanPlayUrl
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c2ef88
	// Return & Params: [ Num(2) Size(0x11) ]
	bool CanPlayUrl(struct FString URL);

	// Object: Function MediaAssets.MediaPlayer.CanPlaySource
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c2f024
	// Return & Params: [ Num(2) Size(0x9) ]
	bool CanPlaySource(struct UMediaSource* MediaSource);

	// Object: Function MediaAssets.MediaPlayer.CanPause
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c2f0b4
	// Return & Params: [ Num(1) Size(0x1) ]
	bool CanPause();
};

// Object: Class MediaAssets.MediaPlaylist
// Inherited Bytes: 0x28 | Struct Size: 0x38
struct UMediaPlaylist : UObject {
	// Fields
	struct TArray<struct UMediaSource*> Items; // Offset: 0x28 | Size: 0x10

	// Functions

	// Object: Function MediaAssets.MediaPlaylist.Replace
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c30ca8
	// Return & Params: [ Num(3) Size(0x11) ]
	bool Replace(int32_t Index, struct UMediaSource* Replacement);

	// Object: Function MediaAssets.MediaPlaylist.RemoveAt
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c30d84
	// Return & Params: [ Num(2) Size(0x5) ]
	bool RemoveAt(int32_t Index);

	// Object: Function MediaAssets.MediaPlaylist.Remove
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c30e14
	// Return & Params: [ Num(2) Size(0x9) ]
	bool Remove(struct UMediaSource* MediaSource);

	// Object: Function MediaAssets.MediaPlaylist.Num
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c30ea4
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t Num();

	// Object: Function MediaAssets.MediaPlaylist.Insert
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c30ec0
	// Return & Params: [ Num(2) Size(0xc) ]
	void Insert(struct UMediaSource* MediaSource, int32_t Index);

	// Object: Function MediaAssets.MediaPlaylist.GetRandom
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104c30f8c
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UMediaSource* GetRandom(int32_t& OutIndex);

	// Object: Function MediaAssets.MediaPlaylist.GetPrevious
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104c31028
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UMediaSource* GetPrevious(int32_t& InOutIndex);

	// Object: Function MediaAssets.MediaPlaylist.GetNext
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104c310c4
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UMediaSource* GetNext(int32_t& InOutIndex);

	// Object: Function MediaAssets.MediaPlaylist.Get
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c31160
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UMediaSource* Get(int32_t Index);

	// Object: Function MediaAssets.MediaPlaylist.AddUrl
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c311f0
	// Return & Params: [ Num(2) Size(0x11) ]
	bool AddUrl(struct FString URL);

	// Object: Function MediaAssets.MediaPlaylist.AddFile
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c3128c
	// Return & Params: [ Num(2) Size(0x11) ]
	bool AddFile(struct FString FilePath);

	// Object: Function MediaAssets.MediaPlaylist.Add
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c31328
	// Return & Params: [ Num(2) Size(0x9) ]
	bool Add(struct UMediaSource* MediaSource);
};

// Object: Class MediaAssets.MediaSoundComponent
// Inherited Bytes: 0x820 | Struct Size: 0xa70
struct UMediaSoundComponent : USynthComponent {
	// Fields
	enum class EMediaSoundChannels Channels; // Offset: 0x820 | Size: 0x4
	bool DynamicRateAdjustment; // Offset: 0x824 | Size: 0x1
	char pad_0x825[0x3]; // Offset: 0x825 | Size: 0x3
	float RateAdjustmentFactor; // Offset: 0x828 | Size: 0x4
	struct FFloatRange RateAdjustmentRange; // Offset: 0x82c | Size: 0x10
	char pad_0x83C[0x4]; // Offset: 0x83c | Size: 0x4
	struct UMediaPlayer* MediaPlayer; // Offset: 0x840 | Size: 0x8
	char pad_0x848[0x228]; // Offset: 0x848 | Size: 0x228

	// Functions

	// Object: Function MediaAssets.MediaSoundComponent.SetSpectralAnalysisSettings
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c31e9c
	// Return & Params: [ Num(2) Size(0x11) ]
	void SetSpectralAnalysisSettings(struct TArray<float> InFrequenciesToAnalyze, enum class EMediaSoundComponentFFTSize InFFTSize);

	// Object: Function MediaAssets.MediaSoundComponent.SetMediaPlayer
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c32064
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetMediaPlayer(struct UMediaPlayer* NewMediaPlayer);

	// Object: Function MediaAssets.MediaSoundComponent.SetEnvelopeFollowingsettings
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c31ccc
	// Return & Params: [ Num(2) Size(0x8) ]
	void SetEnvelopeFollowingsettings(int32_t AttackTimeMsec, int32_t ReleaseTimeMsec);

	// Object: Function MediaAssets.MediaSoundComponent.SetEnableSpectralAnalysis
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c31fdc
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetEnableSpectralAnalysis(bool bInSpectralAnalysisEnabled);

	// Object: Function MediaAssets.MediaSoundComponent.SetEnableEnvelopeFollowing
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c31d94
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetEnableEnvelopeFollowing(bool bInEnvelopeFollowing);

	// Object: Function MediaAssets.MediaSoundComponent.GetSpectralData
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c31e1c
	// Return & Params: [ Num(1) Size(0x10) ]
	struct TArray<struct FMediaSoundComponentSpectralData> GetSpectralData();

	// Object: Function MediaAssets.MediaSoundComponent.GetMediaPlayer
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c320e4
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UMediaPlayer* GetMediaPlayer();

	// Object: Function MediaAssets.MediaSoundComponent.GetEnvelopeValue
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c31c98
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetEnvelopeValue();

	// Object: Function MediaAssets.MediaSoundComponent.BP_GetAttenuationSettingsToApply
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104c32118
	// Return & Params: [ Num(2) Size(0x3a1) ]
	bool BP_GetAttenuationSettingsToApply(struct FSoundAttenuationSettings& OutAttenuationSettings);
};

// Object: Class MediaAssets.MediaTexture
// Inherited Bytes: 0xb8 | Struct Size: 0x1a0
struct UMediaTexture : UTexture {
	// Fields
	enum class TextureAddress AddressX; // Offset: 0xb8 | Size: 0x1
	enum class TextureAddress AddressY; // Offset: 0xb9 | Size: 0x1
	bool AutoClear; // Offset: 0xba | Size: 0x1
	char pad_0xBB[0x1]; // Offset: 0xbb | Size: 0x1
	struct FLinearColor ClearColor; // Offset: 0xbc | Size: 0x10
	bool EnableGenMips; // Offset: 0xcc | Size: 0x1
	char NumMips; // Offset: 0xcd | Size: 0x1
	char pad_0xCE[0x2]; // Offset: 0xce | Size: 0x2
	struct UMediaPlayer* MediaPlayer; // Offset: 0xd0 | Size: 0x8
	char pad_0xD8[0xc8]; // Offset: 0xd8 | Size: 0xc8

	// Functions

	// Object: Function MediaAssets.MediaTexture.SetMediaPlayer
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c32ff8
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetMediaPlayer(struct UMediaPlayer* NewMediaPlayer);

	// Object: Function MediaAssets.MediaTexture.GetWidth
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c33078
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetWidth();

	// Object: Function MediaAssets.MediaTexture.GetMediaPlayer
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c330ac
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UMediaPlayer* GetMediaPlayer();

	// Object: Function MediaAssets.MediaTexture.GetHeight
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c330e0
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetHeight();

	// Object: Function MediaAssets.MediaTexture.GetAspectRatio
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c33114
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetAspectRatio();
};

// Object: Class MediaAssets.PlatformMediaSource
// Inherited Bytes: 0x80 | Struct Size: 0x88
struct UPlatformMediaSource : UMediaSource {
	// Fields
	struct UMediaSource* MediaSource; // Offset: 0x80 | Size: 0x8
};

// Object: Class MediaAssets.StreamMediaSource
// Inherited Bytes: 0x88 | Struct Size: 0x98
struct UStreamMediaSource : UBaseMediaSource {
	// Fields
	struct FString StreamUrl; // Offset: 0x88 | Size: 0x10
};

// Object: Class MediaAssets.TimeSynchronizableMediaSource
// Inherited Bytes: 0x88 | Struct Size: 0x98
struct UTimeSynchronizableMediaSource : UBaseMediaSource {
	// Fields
	bool bUseTimeSynchronization; // Offset: 0x88 | Size: 0x1
	char pad_0x89[0x3]; // Offset: 0x89 | Size: 0x3
	int32_t FrameDelay; // Offset: 0x8c | Size: 0x4
	double TimeDelay; // Offset: 0x90 | Size: 0x8
};

