#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct MeshDescription.ElementID
// Inherited Bytes: 0x0 | Struct Size: 0x4
struct FElementID {
	// Fields
	int32_t IDValue; // Offset: 0x0 | Size: 0x4
};

// Object: ScriptStruct MeshDescription.PolygonGroupID
// Inherited Bytes: 0x4 | Struct Size: 0x4
struct FPolygonGroupID : FElementID {
};

// Object: ScriptStruct MeshDescription.PolygonID
// Inherited Bytes: 0x4 | Struct Size: 0x4
struct FPolygonID : FElementID {
};

// Object: ScriptStruct MeshDescription.VertexID
// Inherited Bytes: 0x4 | Struct Size: 0x4
struct FVertexID : FElementID {
};

// Object: ScriptStruct MeshDescription.VertexInstanceID
// Inherited Bytes: 0x4 | Struct Size: 0x4
struct FVertexInstanceID : FElementID {
};

// Object: ScriptStruct MeshDescription.EdgeID
// Inherited Bytes: 0x4 | Struct Size: 0x4
struct FEdgeID : FElementID {
};

// Object: ScriptStruct MeshDescription.TriangleID
// Inherited Bytes: 0x4 | Struct Size: 0x4
struct FTriangleID : FElementID {
};

