#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class MovieSceneCapture.MovieSceneCaptureProtocolBase
// Inherited Bytes: 0x28 | Struct Size: 0x58
struct UMovieSceneCaptureProtocolBase : UObject {
	// Fields
	char pad_0x28[0x28]; // Offset: 0x28 | Size: 0x28
	enum class EMovieSceneCaptureProtocolState State; // Offset: 0x50 | Size: 0x1
	char pad_0x51[0x7]; // Offset: 0x51 | Size: 0x7

	// Functions

	// Object: Function MovieSceneCapture.MovieSceneCaptureProtocolBase.IsCapturing
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c5d31c
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsCapturing();

	// Object: Function MovieSceneCapture.MovieSceneCaptureProtocolBase.GetState
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c5d36c
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class EMovieSceneCaptureProtocolState GetState();
};

// Object: Class MovieSceneCapture.MovieSceneAudioCaptureProtocolBase
// Inherited Bytes: 0x58 | Struct Size: 0x58
struct UMovieSceneAudioCaptureProtocolBase : UMovieSceneCaptureProtocolBase {
};

// Object: Class MovieSceneCapture.NullAudioCaptureProtocol
// Inherited Bytes: 0x58 | Struct Size: 0x58
struct UNullAudioCaptureProtocol : UMovieSceneAudioCaptureProtocolBase {
};

// Object: Class MovieSceneCapture.MasterAudioSubmixCaptureProtocol
// Inherited Bytes: 0x58 | Struct Size: 0x90
struct UMasterAudioSubmixCaptureProtocol : UMovieSceneAudioCaptureProtocolBase {
	// Fields
	struct FString Filename; // Offset: 0x58 | Size: 0x10
	char pad_0x68[0x28]; // Offset: 0x68 | Size: 0x28
};

// Object: Class MovieSceneCapture.MovieSceneImageCaptureProtocolBase
// Inherited Bytes: 0x58 | Struct Size: 0x58
struct UMovieSceneImageCaptureProtocolBase : UMovieSceneCaptureProtocolBase {
};

// Object: Class MovieSceneCapture.CompositionGraphCaptureProtocol
// Inherited Bytes: 0x58 | Struct Size: 0xc0
struct UCompositionGraphCaptureProtocol : UMovieSceneImageCaptureProtocolBase {
	// Fields
	struct FCompositionGraphCapturePasses IncludeRenderPasses; // Offset: 0x58 | Size: 0x10
	bool bCaptureFramesInHDR; // Offset: 0x68 | Size: 0x1
	char pad_0x69[0x3]; // Offset: 0x69 | Size: 0x3
	int32_t HDRCompressionQuality; // Offset: 0x6c | Size: 0x4
	enum class EHDRCaptureGamut CaptureGamut; // Offset: 0x70 | Size: 0x1
	char pad_0x71[0x7]; // Offset: 0x71 | Size: 0x7
	struct FSoftObjectPath PostProcessingMaterial; // Offset: 0x78 | Size: 0x18
	bool bDisableScreenPercentage; // Offset: 0x90 | Size: 0x1
	char pad_0x91[0x7]; // Offset: 0x91 | Size: 0x7
	struct UMaterialInterface* PostProcessingMaterialPtr; // Offset: 0x98 | Size: 0x8
	char pad_0xA0[0x20]; // Offset: 0xa0 | Size: 0x20
};

// Object: Class MovieSceneCapture.FrameGrabberProtocol
// Inherited Bytes: 0x58 | Struct Size: 0x68
struct UFrameGrabberProtocol : UMovieSceneImageCaptureProtocolBase {
	// Fields
	char pad_0x58[0x10]; // Offset: 0x58 | Size: 0x10
};

// Object: Class MovieSceneCapture.ImageSequenceProtocol
// Inherited Bytes: 0x68 | Struct Size: 0xd8
struct UImageSequenceProtocol : UFrameGrabberProtocol {
	// Fields
	char pad_0x68[0x70]; // Offset: 0x68 | Size: 0x70
};

// Object: Class MovieSceneCapture.CompressedImageSequenceProtocol
// Inherited Bytes: 0xd8 | Struct Size: 0xe0
struct UCompressedImageSequenceProtocol : UImageSequenceProtocol {
	// Fields
	int32_t CompressionQuality; // Offset: 0xd8 | Size: 0x4
	char pad_0xDC[0x4]; // Offset: 0xdc | Size: 0x4
};

// Object: Class MovieSceneCapture.ImageSequenceProtocol_BMP
// Inherited Bytes: 0xd8 | Struct Size: 0xd8
struct UImageSequenceProtocol_BMP : UImageSequenceProtocol {
};

// Object: Class MovieSceneCapture.ImageSequenceProtocol_PNG
// Inherited Bytes: 0xe0 | Struct Size: 0xe0
struct UImageSequenceProtocol_PNG : UCompressedImageSequenceProtocol {
};

// Object: Class MovieSceneCapture.ImageSequenceProtocol_JPG
// Inherited Bytes: 0xe0 | Struct Size: 0xe0
struct UImageSequenceProtocol_JPG : UCompressedImageSequenceProtocol {
};

// Object: Class MovieSceneCapture.ImageSequenceProtocol_EXR
// Inherited Bytes: 0xd8 | Struct Size: 0xe8
struct UImageSequenceProtocol_EXR : UImageSequenceProtocol {
	// Fields
	bool bCompressed; // Offset: 0xd8 | Size: 0x1
	enum class EHDRCaptureGamut CaptureGamut; // Offset: 0xd9 | Size: 0x1
	char pad_0xDA[0xe]; // Offset: 0xda | Size: 0xe
};

// Object: Class MovieSceneCapture.MovieSceneCaptureInterface
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UMovieSceneCaptureInterface : UInterface {
};

// Object: Class MovieSceneCapture.MovieSceneCapture
// Inherited Bytes: 0x28 | Struct Size: 0x220
struct UMovieSceneCapture : UObject {
	// Fields
	char pad_0x28[0x10]; // Offset: 0x28 | Size: 0x10
	struct FSoftClassPath ImageCaptureProtocolType; // Offset: 0x38 | Size: 0x18
	struct FSoftClassPath AudioCaptureProtocolType; // Offset: 0x50 | Size: 0x18
	struct UMovieSceneImageCaptureProtocolBase* ImageCaptureProtocol; // Offset: 0x68 | Size: 0x8
	struct UMovieSceneAudioCaptureProtocolBase* AudioCaptureProtocol; // Offset: 0x70 | Size: 0x8
	struct FMovieSceneCaptureSettings Settings; // Offset: 0x78 | Size: 0x70
	bool bUseSeparateProcess; // Offset: 0xe8 | Size: 0x1
	bool bCloseEditorWhenCaptureStarts; // Offset: 0xe9 | Size: 0x1
	char pad_0xEA[0x6]; // Offset: 0xea | Size: 0x6
	struct FString AdditionalCommandLineArguments; // Offset: 0xf0 | Size: 0x10
	struct FString InheritedCommandLineArguments; // Offset: 0x100 | Size: 0x10
	char pad_0x110[0x110]; // Offset: 0x110 | Size: 0x110

	// Functions

	// Object: Function MovieSceneCapture.MovieSceneCapture.SetImageCaptureProtocolType
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c5c6f8
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetImageCaptureProtocolType(struct UMovieSceneCaptureProtocolBase* ProtocolType);

	// Object: Function MovieSceneCapture.MovieSceneCapture.SetAudioCaptureProtocolType
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c5c678
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetAudioCaptureProtocolType(struct UMovieSceneCaptureProtocolBase* ProtocolType);

	// Object: Function MovieSceneCapture.MovieSceneCapture.GetImageCaptureProtocol
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c5c794
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UMovieSceneCaptureProtocolBase* GetImageCaptureProtocol();

	// Object: Function MovieSceneCapture.MovieSceneCapture.GetAudioCaptureProtocol
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c5c778
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UMovieSceneCaptureProtocolBase* GetAudioCaptureProtocol();
};

// Object: Class MovieSceneCapture.LevelCapture
// Inherited Bytes: 0x220 | Struct Size: 0x240
struct ULevelCapture : UMovieSceneCapture {
	// Fields
	bool bAutoStartCapture; // Offset: 0x220 | Size: 0x1
	char pad_0x221[0xb]; // Offset: 0x221 | Size: 0xb
	struct FGuid PrerequisiteActorId; // Offset: 0x22c | Size: 0x10
	char pad_0x23C[0x4]; // Offset: 0x23c | Size: 0x4
};

// Object: Class MovieSceneCapture.MovieSceneCaptureEnvironment
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UMovieSceneCaptureEnvironment : UObject {
	// Functions

	// Object: Function MovieSceneCapture.MovieSceneCaptureEnvironment.IsCaptureInProgress
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104c5cd64
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsCaptureInProgress();

	// Object: Function MovieSceneCapture.MovieSceneCaptureEnvironment.GetCaptureFrameNumber
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x104c5cdcc
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetCaptureFrameNumber();

	// Object: Function MovieSceneCapture.MovieSceneCaptureEnvironment.GetCaptureElapsedTime
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x104c5cd98
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetCaptureElapsedTime();

	// Object: Function MovieSceneCapture.MovieSceneCaptureEnvironment.FindImageCaptureProtocol
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104c5cd30
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UMovieSceneImageCaptureProtocolBase* FindImageCaptureProtocol();

	// Object: Function MovieSceneCapture.MovieSceneCaptureEnvironment.FindAudioCaptureProtocol
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104c5ccfc
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UMovieSceneAudioCaptureProtocolBase* FindAudioCaptureProtocol();
};

// Object: Class MovieSceneCapture.UserDefinedCaptureProtocol
// Inherited Bytes: 0x58 | Struct Size: 0xd8
struct UUserDefinedCaptureProtocol : UMovieSceneImageCaptureProtocolBase {
	// Fields
	struct UWorld* World; // Offset: 0x58 | Size: 0x8
	char pad_0x60[0x78]; // Offset: 0x60 | Size: 0x78

	// Functions

	// Object: Function MovieSceneCapture.UserDefinedCaptureProtocol.StopCapturingFinalPixels
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c5ddb8
	// Return & Params: [ Num(0) Size(0x0) ]
	void StopCapturingFinalPixels();

	// Object: Function MovieSceneCapture.UserDefinedCaptureProtocol.StartCapturingFinalPixels
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104c5ddcc
	// Return & Params: [ Num(1) Size(0x50) ]
	void StartCapturingFinalPixels(struct FCapturedPixelsID& StreamID);

	// Object: Function MovieSceneCapture.UserDefinedCaptureProtocol.ResolveBuffer
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104c5de8c
	// Return & Params: [ Num(2) Size(0x58) ]
	void ResolveBuffer(struct UTexture* Buffer, struct FCapturedPixelsID& BufferID);

	// Object: Function MovieSceneCapture.UserDefinedCaptureProtocol.OnWarmUp
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103a43990
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnWarmUp();

	// Object: Function MovieSceneCapture.UserDefinedCaptureProtocol.OnTick
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103a43990
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnTick();

	// Object: Function MovieSceneCapture.UserDefinedCaptureProtocol.OnStartCapture
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103a43990
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnStartCapture();

	// Object: Function MovieSceneCapture.UserDefinedCaptureProtocol.OnSetup
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x104c5dfc8
	// Return & Params: [ Num(1) Size(0x1) ]
	bool OnSetup();

	// Object: Function MovieSceneCapture.UserDefinedCaptureProtocol.OnPreTick
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103a43990
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnPreTick();

	// Object: Function MovieSceneCapture.UserDefinedCaptureProtocol.OnPixelsReceived
	// Flags: [Event|Protected|HasOutParms|BlueprintEvent]
	// Offset: 0x103a43990
	// Return & Params: [ Num(3) Size(0x70) ]
	void OnPixelsReceived(struct FCapturedPixels& Pixels, struct FCapturedPixelsID& ID, struct FFrameMetrics FrameMetrics);

	// Object: Function MovieSceneCapture.UserDefinedCaptureProtocol.OnPauseCapture
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103a43990
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnPauseCapture();

	// Object: Function MovieSceneCapture.UserDefinedCaptureProtocol.OnFinalize
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103a43990
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnFinalize();

	// Object: Function MovieSceneCapture.UserDefinedCaptureProtocol.OnCaptureFrame
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103a43990
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnCaptureFrame();

	// Object: Function MovieSceneCapture.UserDefinedCaptureProtocol.OnCanFinalize
	// Flags: [Native|Event|Protected|BlueprintEvent|Const]
	// Offset: 0x104c5df8c
	// Return & Params: [ Num(1) Size(0x1) ]
	bool OnCanFinalize();

	// Object: Function MovieSceneCapture.UserDefinedCaptureProtocol.OnBeginFinalize
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103a43990
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnBeginFinalize();

	// Object: Function MovieSceneCapture.UserDefinedCaptureProtocol.GetCurrentFrameMetrics
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c5dcb0
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FFrameMetrics GetCurrentFrameMetrics();

	// Object: Function MovieSceneCapture.UserDefinedCaptureProtocol.GenerateFilename
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c5dccc
	// Return & Params: [ Num(2) Size(0x20) ]
	struct FString GenerateFilename(struct FFrameMetrics& InFrameMetrics);
};

// Object: Class MovieSceneCapture.UserDefinedImageCaptureProtocol
// Inherited Bytes: 0xd8 | Struct Size: 0xe0
struct UUserDefinedImageCaptureProtocol : UUserDefinedCaptureProtocol {
	// Fields
	enum class EDesiredImageFormat Format; // Offset: 0xd8 | Size: 0x1
	bool bEnableCompression; // Offset: 0xd9 | Size: 0x1
	char pad_0xDA[0x2]; // Offset: 0xda | Size: 0x2
	int32_t CompressionQuality; // Offset: 0xdc | Size: 0x4

	// Functions

	// Object: Function MovieSceneCapture.UserDefinedImageCaptureProtocol.WriteImageToDisk
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104c5eb00
	// Return & Params: [ Num(4) Size(0x71) ]
	void WriteImageToDisk(struct FCapturedPixels& PixelData, struct FCapturedPixelsID& StreamID, struct FFrameMetrics& FrameMetrics, bool bCopyImageData);

	// Object: Function MovieSceneCapture.UserDefinedImageCaptureProtocol.GenerateFilenameForCurrentFrame
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c5ed14
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GenerateFilenameForCurrentFrame();

	// Object: Function MovieSceneCapture.UserDefinedImageCaptureProtocol.GenerateFilenameForBuffer
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104c5ed94
	// Return & Params: [ Num(3) Size(0x68) ]
	struct FString GenerateFilenameForBuffer(struct UTexture* Buffer, struct FCapturedPixelsID& StreamID);
};

// Object: Class MovieSceneCapture.VideoCaptureProtocol
// Inherited Bytes: 0x68 | Struct Size: 0x80
struct UVideoCaptureProtocol : UFrameGrabberProtocol {
	// Fields
	bool bUseCompression; // Offset: 0x68 | Size: 0x1
	char pad_0x69[0x3]; // Offset: 0x69 | Size: 0x3
	float CompressionQuality; // Offset: 0x6c | Size: 0x4
	char pad_0x70[0x10]; // Offset: 0x70 | Size: 0x10
};

