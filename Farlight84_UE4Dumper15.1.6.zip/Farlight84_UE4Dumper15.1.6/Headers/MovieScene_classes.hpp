#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class MovieScene.MovieSceneSignedObject
// Inherited Bytes: 0x28 | Struct Size: 0x50
struct UMovieSceneSignedObject : UObject {
	// Fields
	struct FGuid Signature; // Offset: 0x28 | Size: 0x10
	char pad_0x38[0x18]; // Offset: 0x38 | Size: 0x18
};

// Object: Class MovieScene.MovieSceneSection
// Inherited Bytes: 0x50 | Struct Size: 0xd8
struct UMovieSceneSection : UMovieSceneSignedObject {
	// Fields
	struct FMovieSceneSectionEvalOptions EvalOptions; // Offset: 0x50 | Size: 0x2
	char pad_0x52[0x6]; // Offset: 0x52 | Size: 0x6
	struct FMovieSceneEasingSettings Easing; // Offset: 0x58 | Size: 0x38
	struct FMovieSceneFrameRange SectionRange; // Offset: 0x90 | Size: 0x10
	struct FFrameNumber PreRollFrames; // Offset: 0xa0 | Size: 0x4
	struct FFrameNumber PostRollFrames; // Offset: 0xa4 | Size: 0x4
	int32_t RowIndex; // Offset: 0xa8 | Size: 0x4
	int32_t OverlapPriority; // Offset: 0xac | Size: 0x4
	char bIsActive : 1; // Offset: 0xb0 | Size: 0x1
	char bIsLocked : 1; // Offset: 0xb0 | Size: 0x1
	char pad_0xB0_2 : 6; // Offset: 0xb0 | Size: 0x1
	char pad_0xB1[0x3]; // Offset: 0xb1 | Size: 0x3
	float StartTime; // Offset: 0xb4 | Size: 0x4
	float EndTime; // Offset: 0xb8 | Size: 0x4
	float PrerollTime; // Offset: 0xbc | Size: 0x4
	float PostrollTime; // Offset: 0xc0 | Size: 0x4
	char bIsInfinite : 1; // Offset: 0xc4 | Size: 0x1
	char pad_0xC4_1 : 7; // Offset: 0xc4 | Size: 0x1
	bool bSupportsInfiniteRange; // Offset: 0xc5 | Size: 0x1
	struct FOptionalMovieSceneBlendType BlendType; // Offset: 0xc6 | Size: 0x2
	char pad_0xC8[0x10]; // Offset: 0xc8 | Size: 0x10

	// Functions

	// Object: Function MovieScene.MovieSceneSection.SetRowIndex
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10482753c
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetRowIndex(int32_t NewRowIndex);

	// Object: Function MovieScene.MovieSceneSection.SetPreRollFrames
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10482729c
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetPreRollFrames(int32_t InPreRollFrames);

	// Object: Function MovieScene.MovieSceneSection.SetPostRollFrames
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1048271f4
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetPostRollFrames(int32_t InPostRollFrames);

	// Object: Function MovieScene.MovieSceneSection.SetOverlapPriority
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1048274a4
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetOverlapPriority(int32_t NewPriority);

	// Object: Function MovieScene.MovieSceneSection.SetIsLocked
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104827348
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetIsLocked(bool bInIsLocked);

	// Object: Function MovieScene.MovieSceneSection.SetIsActive
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1048273f8
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetIsActive(bool bInIsActive);

	// Object: Function MovieScene.MovieSceneSection.SetCompletionMode
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10482765c
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetCompletionMode(enum class EMovieSceneCompletionMode InCompletionMode);

	// Object: Function MovieScene.MovieSceneSection.SetBlendType
	// Flags: [RequiredAPI|Native|Public|BlueprintCallable]
	// Offset: 0x1048275b8
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetBlendType(enum class EMovieSceneBlendType InBlendType);

	// Object: Function MovieScene.MovieSceneSection.IsLocked
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104827328
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsLocked();

	// Object: Function MovieScene.MovieSceneSection.IsActive
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1048273d8
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsActive();

	// Object: Function MovieScene.MovieSceneSection.GetRowIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104827520
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetRowIndex();

	// Object: Function MovieScene.MovieSceneSection.GetPreRollFrames
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104827280
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetPreRollFrames();

	// Object: Function MovieScene.MovieSceneSection.GetPostRollFrames
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1048271d8
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetPostRollFrames();

	// Object: Function MovieScene.MovieSceneSection.GetOverlapPriority
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104827488
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetOverlapPriority();

	// Object: Function MovieScene.MovieSceneSection.GetCompletionMode
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1048276d8
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class EMovieSceneCompletionMode GetCompletionMode();

	// Object: Function MovieScene.MovieSceneSection.GetBlendType
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104827640
	// Return & Params: [ Num(1) Size(0x2) ]
	struct FOptionalMovieSceneBlendType GetBlendType();
};

// Object: Class MovieScene.MovieSceneTrack
// Inherited Bytes: 0x50 | Struct Size: 0x58
struct UMovieSceneTrack : UMovieSceneSignedObject {
	// Fields
	struct FMovieSceneTrackEvalOptions EvalOptions; // Offset: 0x50 | Size: 0x4
	char pad_0x54[0x1]; // Offset: 0x54 | Size: 0x1
	bool bIsEvalDisabled; // Offset: 0x55 | Size: 0x1
	char pad_0x56[0x2]; // Offset: 0x56 | Size: 0x2
};

// Object: Class MovieScene.MovieSceneNameableTrack
// Inherited Bytes: 0x58 | Struct Size: 0x58
struct UMovieSceneNameableTrack : UMovieSceneTrack {
};

// Object: Class MovieScene.MovieSceneSequence
// Inherited Bytes: 0x50 | Struct Size: 0x348
struct UMovieSceneSequence : UMovieSceneSignedObject {
	// Fields
	struct FMovieSceneEvaluationTemplate PrecompiledEvaluationTemplate; // Offset: 0x50 | Size: 0x2f0
	enum class EMovieSceneCompletionMode DefaultCompletionMode; // Offset: 0x340 | Size: 0x1
	bool bParentContextsAreSignificant; // Offset: 0x341 | Size: 0x1
	bool bPlayableDirectly; // Offset: 0x342 | Size: 0x1
	char pad_0x343[0x5]; // Offset: 0x343 | Size: 0x5

	// Functions

	// Object: Function MovieScene.MovieSceneSequence.FindBindingsByTag
	// Flags: [Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104828280
	// Return & Params: [ Num(2) Size(0x18) ]
	struct TArray<struct FMovieSceneObjectBindingID> FindBindingsByTag(struct FName InBindingName);

	// Object: Function MovieScene.MovieSceneSequence.FindBindingByTag
	// Flags: [Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104828364
	// Return & Params: [ Num(2) Size(0x20) ]
	struct FMovieSceneObjectBindingID FindBindingByTag(struct FName InBindingName);
};

// Object: Class MovieScene.MovieSceneSubSection
// Inherited Bytes: 0xd8 | Struct Size: 0x150
struct UMovieSceneSubSection : UMovieSceneSection {
	// Fields
	struct FMovieSceneSectionParameters Parameters; // Offset: 0xd8 | Size: 0x24
	float StartOffset; // Offset: 0xfc | Size: 0x4
	float TimeScale; // Offset: 0x100 | Size: 0x4
	float PrerollTime; // Offset: 0x104 | Size: 0x4
	struct UMovieSceneSequence* SubSequence; // Offset: 0x108 | Size: 0x8
	LazyObjectProperty ActorToRecord; // Offset: 0x110 | Size: 0x1c
	char pad_0x12C[0x4]; // Offset: 0x12c | Size: 0x4
	struct FString TargetSequenceName; // Offset: 0x130 | Size: 0x10
	struct FDirectoryPath TargetPathToRecordTo; // Offset: 0x140 | Size: 0x10

	// Functions

	// Object: Function MovieScene.MovieSceneSubSection.SetSequence
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104832118
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetSequence(struct UMovieSceneSequence* Sequence);

	// Object: Function MovieScene.MovieSceneSubSection.GetSequence
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104832198
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UMovieSceneSequence* GetSequence();
};

// Object: Class MovieScene.MovieSceneSubTrack
// Inherited Bytes: 0x58 | Struct Size: 0x68
struct UMovieSceneSubTrack : UMovieSceneNameableTrack {
	// Fields
	struct TArray<struct UMovieSceneSection*> Sections; // Offset: 0x58 | Size: 0x10
};

// Object: Class MovieScene.MovieSceneSequencePlayer
// Inherited Bytes: 0x28 | Struct Size: 0x888
struct UMovieSceneSequencePlayer : UObject {
	// Fields
	char pad_0x28[0x3e0]; // Offset: 0x28 | Size: 0x3e0
	struct FMulticastInlineDelegate OnPlay; // Offset: 0x408 | Size: 0x10
	struct FMulticastInlineDelegate OnPlayReverse; // Offset: 0x418 | Size: 0x10
	struct FMulticastInlineDelegate OnStop; // Offset: 0x428 | Size: 0x10
	struct FMulticastInlineDelegate OnPause; // Offset: 0x438 | Size: 0x10
	struct FMulticastInlineDelegate OnFinished; // Offset: 0x448 | Size: 0x10
	enum class EMovieScenePlayerStatus status; // Offset: 0x458 | Size: 0x1
	char bReversePlayback : 1; // Offset: 0x459 | Size: 0x1
	char pad_0x459_1 : 7; // Offset: 0x459 | Size: 0x1
	char pad_0x45A[0x6]; // Offset: 0x45a | Size: 0x6
	struct UMovieSceneSequence* Sequence; // Offset: 0x460 | Size: 0x8
	struct FFrameNumber StartTime; // Offset: 0x468 | Size: 0x4
	int32_t DurationFrames; // Offset: 0x46c | Size: 0x4
	int32_t CurrentNumLoops; // Offset: 0x470 | Size: 0x4
	char pad_0x474[0x14]; // Offset: 0x474 | Size: 0x14
	struct FMovieSceneSequencePlaybackSettings PlaybackSettings; // Offset: 0x488 | Size: 0x14
	char pad_0x49C[0x4]; // Offset: 0x49c | Size: 0x4
	struct FMovieSceneRootEvaluationTemplateInstance RootTemplateInstance; // Offset: 0x4a0 | Size: 0x320
	char pad_0x7C0[0x68]; // Offset: 0x7c0 | Size: 0x68
	struct FMovieSceneSequenceReplProperties NetSyncProps; // Offset: 0x828 | Size: 0x10
	struct TScriptInterface<IMovieScenePlaybackClient> PlaybackClient; // Offset: 0x838 | Size: 0x10
	char pad_0x848[0x40]; // Offset: 0x848 | Size: 0x40

	// Functions

	// Object: Function MovieScene.MovieSceneSequencePlayer.StopAtCurrentTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1048308bc
	// Return & Params: [ Num(0) Size(0x0) ]
	void StopAtCurrentTime();

	// Object: Function MovieScene.MovieSceneSequencePlayer.Stop
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1048308d0
	// Return & Params: [ Num(0) Size(0x0) ]
	void Stop();

	// Object: Function MovieScene.MovieSceneSequencePlayer.SetTimeRange
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1048301e4
	// Return & Params: [ Num(2) Size(0x8) ]
	void SetTimeRange(float StartTime, float Duration);

	// Object: Function MovieScene.MovieSceneSequencePlayer.SetPlayRate
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10482fbc0
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetPlayRate(float PlayRate);

	// Object: Function MovieScene.MovieSceneSequencePlayer.SetPlaybackRange
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10483057c
	// Return & Params: [ Num(2) Size(0x8) ]
	void SetPlaybackRange(float NewStartTime, float NewEndTime);

	// Object: Function MovieScene.MovieSceneSequencePlayer.SetPlaybackPosition
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104830644
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetPlaybackPosition(float NewPlaybackPosition);

	// Object: Function MovieScene.MovieSceneSequencePlayer.SetFrameRate
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1048303bc
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetFrameRate(struct FFrameRate FrameRate);

	// Object: Function MovieScene.MovieSceneSequencePlayer.SetFrameRange
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1048302ac
	// Return & Params: [ Num(2) Size(0x8) ]
	void SetFrameRange(int32_t StartFrame, int32_t Duration);

	// Object: Function MovieScene.MovieSceneSequencePlayer.SetDisableCameraCuts
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10482fb30
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetDisableCameraCuts(bool bInDisableCameraCuts);

	// Object: Function MovieScene.MovieSceneSequencePlayer.ScrubToSeconds
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10482ff64
	// Return & Params: [ Num(1) Size(0x4) ]
	void ScrubToSeconds(float TimeInSeconds);

	// Object: Function MovieScene.MovieSceneSequencePlayer.ScrubToMarkedFrame
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10482fdac
	// Return & Params: [ Num(2) Size(0x11) ]
	bool ScrubToMarkedFrame(struct FString InLabel);

	// Object: Function MovieScene.MovieSceneSequencePlayer.ScrubToFrame
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1048300e4
	// Return & Params: [ Num(1) Size(0x8) ]
	void ScrubToFrame(struct FFrameTime NewPosition);

	// Object: Function MovieScene.MovieSceneSequencePlayer.Scrub
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1048308e4
	// Return & Params: [ Num(0) Size(0x0) ]
	void Scrub();

	// Object: Function MovieScene.MovieSceneSequencePlayer.RPC_OnStopEvent
	// Flags: [Final|Net|NetReliableNative|Event|NetMulticast|Private]
	// Offset: 0x10482f7e0
	// Return & Params: [ Num(1) Size(0x8) ]
	void RPC_OnStopEvent(struct FFrameTime StoppedTime);

	// Object: Function MovieScene.MovieSceneSequencePlayer.RPC_ExplicitServerUpdateEvent
	// Flags: [Final|Net|NetReliableNative|Event|NetMulticast|Private]
	// Offset: 0x10482f868
	// Return & Params: [ Num(2) Size(0xc) ]
	void RPC_ExplicitServerUpdateEvent(enum class EUpdatePositionMethod Method, struct FFrameTime RelevantTime);

	// Object: Function MovieScene.MovieSceneSequencePlayer.PlayToSeconds
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10482ffe4
	// Return & Params: [ Num(1) Size(0x4) ]
	void PlayToSeconds(float TimeInSeconds);

	// Object: Function MovieScene.MovieSceneSequencePlayer.PlayToMarkedFrame
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10482fe48
	// Return & Params: [ Num(2) Size(0x11) ]
	bool PlayToMarkedFrame(struct FString InLabel);

	// Object: Function MovieScene.MovieSceneSequencePlayer.PlayToFrame
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104830164
	// Return & Params: [ Num(1) Size(0x8) ]
	void PlayToFrame(struct FFrameTime NewPosition);

	// Object: Function MovieScene.MovieSceneSequencePlayer.PlayReverse
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1048309a0
	// Return & Params: [ Num(0) Size(0x0) ]
	void PlayReverse();

	// Object: Function MovieScene.MovieSceneSequencePlayer.PlayLooping
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10483090c
	// Return & Params: [ Num(1) Size(0x4) ]
	void PlayLooping(int32_t NumLoops);

	// Object: Function MovieScene.MovieSceneSequencePlayer.Play
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1048309b4
	// Return & Params: [ Num(0) Size(0x0) ]
	void Play();

	// Object: Function MovieScene.MovieSceneSequencePlayer.Pause
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1048308f8
	// Return & Params: [ Num(0) Size(0x0) ]
	void Pause();

	// Object: Function MovieScene.MovieSceneSequencePlayer.JumpToSeconds
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10482fee4
	// Return & Params: [ Num(1) Size(0x4) ]
	void JumpToSeconds(float TimeInSeconds);

	// Object: Function MovieScene.MovieSceneSequencePlayer.JumpToPosition
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1048304fc
	// Return & Params: [ Num(1) Size(0x4) ]
	void JumpToPosition(float NewPlaybackPosition);

	// Object: Function MovieScene.MovieSceneSequencePlayer.JumpToMarkedFrame
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10482fd10
	// Return & Params: [ Num(2) Size(0x11) ]
	bool JumpToMarkedFrame(struct FString InLabel);

	// Object: Function MovieScene.MovieSceneSequencePlayer.JumpToFrame
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104830064
	// Return & Params: [ Num(1) Size(0x8) ]
	void JumpToFrame(struct FFrameTime NewPosition);

	// Object: Function MovieScene.MovieSceneSequencePlayer.IsReversed
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10482fc74
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsReversed();

	// Object: Function MovieScene.MovieSceneSequencePlayer.IsPlaying
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10482fcdc
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsPlaying();

	// Object: Function MovieScene.MovieSceneSequencePlayer.IsPaused
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10482fca8
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsPaused();

	// Object: Function MovieScene.MovieSceneSequencePlayer.GoToEndAndStop
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1048308a8
	// Return & Params: [ Num(0) Size(0x0) ]
	void GoToEndAndStop();

	// Object: Function MovieScene.MovieSceneSequencePlayer.GetStartTime
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10483039c
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FQualifiedFrameTime GetStartTime();

	// Object: Function MovieScene.MovieSceneSequencePlayer.GetPlayRate
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10482fc40
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetPlayRate();

	// Object: Function MovieScene.MovieSceneSequencePlayer.GetPlaybackStart
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10483077c
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetPlaybackStart();

	// Object: Function MovieScene.MovieSceneSequencePlayer.GetPlaybackPosition
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104830800
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetPlaybackPosition();

	// Object: Function MovieScene.MovieSceneSequencePlayer.GetPlaybackEnd
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104830724
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetPlaybackEnd();

	// Object: Function MovieScene.MovieSceneSequencePlayer.GetObjectBindings
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10482f93c
	// Return & Params: [ Num(2) Size(0x18) ]
	struct TArray<struct FMovieSceneObjectBindingID> GetObjectBindings(struct UObject* InObject);

	// Object: Function MovieScene.MovieSceneSequencePlayer.GetLength
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1048307cc
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetLength();

	// Object: Function MovieScene.MovieSceneSequencePlayer.GetFrameRate
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104830444
	// Return & Params: [ Num(1) Size(0x8) ]
	struct FFrameRate GetFrameRate();

	// Object: Function MovieScene.MovieSceneSequencePlayer.GetFrameDuration
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104830460
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetFrameDuration();

	// Object: Function MovieScene.MovieSceneSequencePlayer.GetEndTime
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104830374
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FQualifiedFrameTime GetEndTime();

	// Object: Function MovieScene.MovieSceneSequencePlayer.GetDuration
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104830494
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FQualifiedFrameTime GetDuration();

	// Object: Function MovieScene.MovieSceneSequencePlayer.GetDisableCameraCuts
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10482fb10
	// Return & Params: [ Num(1) Size(0x1) ]
	bool GetDisableCameraCuts();

	// Object: Function MovieScene.MovieSceneSequencePlayer.GetCurrentTime
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1048304c8
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FQualifiedFrameTime GetCurrentTime();

	// Object: Function MovieScene.MovieSceneSequencePlayer.GetBoundObjects
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10482fa14
	// Return & Params: [ Num(2) Size(0x28) ]
	struct TArray<struct UObject*> GetBoundObjects(struct FMovieSceneObjectBindingID ObjectBinding);

	// Object: Function MovieScene.MovieSceneSequencePlayer.ChangePlaybackDirection
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10483098c
	// Return & Params: [ Num(0) Size(0x0) ]
	void ChangePlaybackDirection();
};

// Object: Class MovieScene.MovieSceneCustomClockSource
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UMovieSceneCustomClockSource : UInterface {
	// Functions

	// Object: Function MovieScene.MovieSceneCustomClockSource.OnTick
	// Flags: [Native|Public]
	// Offset: 0x10481730c
	// Return & Params: [ Num(2) Size(0x8) ]
	void OnTick(float DeltaSeconds, float InPlayRate);

	// Object: Function MovieScene.MovieSceneCustomClockSource.OnStopPlaying
	// Flags: [Native|Public|HasOutParms]
	// Offset: 0x1048171cc
	// Return & Params: [ Num(1) Size(0x10) ]
	void OnStopPlaying(struct FQualifiedFrameTime& InStopTime);

	// Object: Function MovieScene.MovieSceneCustomClockSource.OnStartPlaying
	// Flags: [Native|Public|HasOutParms]
	// Offset: 0x10481726c
	// Return & Params: [ Num(1) Size(0x10) ]
	void OnStartPlaying(struct FQualifiedFrameTime& InStartTime);

	// Object: Function MovieScene.MovieSceneCustomClockSource.OnRequestCurrentTime
	// Flags: [Native|Public|HasOutParms]
	// Offset: 0x1048170cc
	// Return & Params: [ Num(3) Size(0x1c) ]
	struct FFrameTime OnRequestCurrentTime(struct FQualifiedFrameTime& InCurrentTime, float InPlayRate);
};

// Object: Class MovieScene.MovieScenePlaybackClient
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UMovieScenePlaybackClient : UInterface {
};

// Object: Class MovieScene.MovieScene
// Inherited Bytes: 0x50 | Struct Size: 0x148
struct UMovieScene : UMovieSceneSignedObject {
	// Fields
	struct TArray<struct FMovieSceneSpawnable> Spawnables; // Offset: 0x50 | Size: 0x10
	struct TArray<struct FMovieScenePossessable> Possessables; // Offset: 0x60 | Size: 0x10
	struct TArray<struct FMovieSceneBinding> ObjectBindings; // Offset: 0x70 | Size: 0x10
	struct TMap<struct FName, struct FMovieSceneObjectBindingIDs> BindingGroups; // Offset: 0x80 | Size: 0x50
	struct TArray<struct UMovieSceneTrack*> MasterTracks; // Offset: 0xd0 | Size: 0x10
	struct UMovieSceneTrack* CameraCutTrack; // Offset: 0xe0 | Size: 0x8
	struct FMovieSceneFrameRange SelectionRange; // Offset: 0xe8 | Size: 0x10
	struct FMovieSceneFrameRange PlaybackRange; // Offset: 0xf8 | Size: 0x10
	struct FFrameRate TickResolution; // Offset: 0x108 | Size: 0x8
	struct FFrameRate DisplayRate; // Offset: 0x110 | Size: 0x8
	enum class EMovieSceneEvaluationType EvaluationType; // Offset: 0x118 | Size: 0x1
	enum class EUpdateClockSource ClockSource; // Offset: 0x119 | Size: 0x1
	char pad_0x11A[0x6]; // Offset: 0x11a | Size: 0x6
	struct FSoftObjectPath CustomClockSourcePath; // Offset: 0x120 | Size: 0x18
	struct TArray<struct FMovieSceneMarkedFrame> MarkedFrames; // Offset: 0x138 | Size: 0x10
};

// Object: Class MovieScene.MovieSceneBindingOverrides
// Inherited Bytes: 0x28 | Struct Size: 0x90
struct UMovieSceneBindingOverrides : UObject {
	// Fields
	struct TArray<struct FMovieSceneBindingOverrideData> BindingData; // Offset: 0x28 | Size: 0x10
	char pad_0x38[0x58]; // Offset: 0x38 | Size: 0x58
};

// Object: Class MovieScene.MovieSceneBindingOwnerInterface
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UMovieSceneBindingOwnerInterface : UInterface {
};

// Object: Class MovieScene.MovieSceneBuiltInEasingFunction
// Inherited Bytes: 0x28 | Struct Size: 0x38
struct UMovieSceneBuiltInEasingFunction : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
	enum class EMovieSceneBuiltInEasing Type; // Offset: 0x30 | Size: 0x1
	char pad_0x31[0x7]; // Offset: 0x31 | Size: 0x7
};

// Object: Class MovieScene.MovieSceneEasingExternalCurve
// Inherited Bytes: 0x28 | Struct Size: 0x38
struct UMovieSceneEasingExternalCurve : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
	struct UCurveFloat* Curve; // Offset: 0x30 | Size: 0x8
};

// Object: Class MovieScene.MovieSceneEasingFunction
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UMovieSceneEasingFunction : UInterface {
	// Functions

	// Object: Function MovieScene.MovieSceneEasingFunction.OnEvaluate
	// Flags: [Event|Protected|BlueprintCallable|BlueprintEvent|BlueprintPure|Const]
	// Offset: 0x103a43990
	// Return & Params: [ Num(2) Size(0x8) ]
	float OnEvaluate(float Interp);
};

// Object: Class MovieScene.MovieSceneFolder
// Inherited Bytes: 0x28 | Struct Size: 0x70
struct UMovieSceneFolder : UObject {
	// Fields
	struct FName FolderName; // Offset: 0x28 | Size: 0x8
	struct TArray<struct UMovieSceneFolder*> ChildFolders; // Offset: 0x30 | Size: 0x10
	struct TArray<struct UMovieSceneTrack*> ChildMasterTracks; // Offset: 0x40 | Size: 0x10
	struct TArray<struct FString> ChildObjectBindingStrings; // Offset: 0x50 | Size: 0x10
	char pad_0x60[0x10]; // Offset: 0x60 | Size: 0x10
};

// Object: Class MovieScene.MovieSceneKeyProxy
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UMovieSceneKeyProxy : UInterface {
};

// Object: Class MovieScene.TestMovieSceneTrack
// Inherited Bytes: 0x58 | Struct Size: 0x68
struct UTestMovieSceneTrack : UMovieSceneTrack {
	// Fields
	bool bHighPassFilter; // Offset: 0x56 | Size: 0x1
	struct TArray<struct UMovieSceneSection*> SectionArray; // Offset: 0x58 | Size: 0x10
};

// Object: Class MovieScene.TestMovieSceneSection
// Inherited Bytes: 0xd8 | Struct Size: 0xd8
struct UTestMovieSceneSection : UMovieSceneSection {
};

// Object: Class MovieScene.TestMovieSceneSequence
// Inherited Bytes: 0x348 | Struct Size: 0x350
struct UTestMovieSceneSequence : UMovieSceneSequence {
	// Fields
	struct UMovieScene* MovieScene; // Offset: 0x348 | Size: 0x8
};

// Object: Class MovieScene.TestMovieSceneSubTrack
// Inherited Bytes: 0x68 | Struct Size: 0x78
struct UTestMovieSceneSubTrack : UMovieSceneSubTrack {
	// Fields
	struct TArray<struct UMovieSceneSection*> SectionArray; // Offset: 0x68 | Size: 0x10
};

// Object: Class MovieScene.TestMovieSceneSubSection
// Inherited Bytes: 0x150 | Struct Size: 0x150
struct UTestMovieSceneSubSection : UMovieSceneSubSection {
};

