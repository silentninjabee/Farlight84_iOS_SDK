#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class NavigationSystem.NavArea
// Inherited Bytes: 0x30 | Struct Size: 0x48
struct UNavArea : UNavAreaBase {
	// Fields
	float DefaultCost; // Offset: 0x2c | Size: 0x4
	float FixedAreaEnteringCost; // Offset: 0x30 | Size: 0x4
	struct FColor DrawColor; // Offset: 0x34 | Size: 0x4
	struct FNavAgentSelector SupportedAgents; // Offset: 0x38 | Size: 0x4
	char bSupportsAgent0 : 1; // Offset: 0x3c | Size: 0x1
	char bSupportsAgent1 : 1; // Offset: 0x3c | Size: 0x1
	char bSupportsAgent2 : 1; // Offset: 0x3c | Size: 0x1
	char bSupportsAgent3 : 1; // Offset: 0x3c | Size: 0x1
	char bSupportsAgent4 : 1; // Offset: 0x3c | Size: 0x1
	char bSupportsAgent5 : 1; // Offset: 0x3c | Size: 0x1
	char bSupportsAgent6 : 1; // Offset: 0x3c | Size: 0x1
	char bSupportsAgent7 : 1; // Offset: 0x3c | Size: 0x1
	char bSupportsAgent8 : 1; // Offset: 0x3d | Size: 0x1
	char bSupportsAgent9 : 1; // Offset: 0x3d | Size: 0x1
	char bSupportsAgent10 : 1; // Offset: 0x3d | Size: 0x1
	char bSupportsAgent11 : 1; // Offset: 0x3d | Size: 0x1
	char bSupportsAgent12 : 1; // Offset: 0x3d | Size: 0x1
	char bSupportsAgent13 : 1; // Offset: 0x3d | Size: 0x1
	char bSupportsAgent14 : 1; // Offset: 0x3d | Size: 0x1
	char bSupportsAgent15 : 1; // Offset: 0x3d | Size: 0x1
	char pad_0x42[0x6]; // Offset: 0x42 | Size: 0x6
};

// Object: Class NavigationSystem.NavRelevantComponent
// Inherited Bytes: 0xb0 | Struct Size: 0xe0
struct UNavRelevantComponent : UActorComponent {
	// Fields
	char pad_0xB0[0x24]; // Offset: 0xb0 | Size: 0x24
	char bAttachToOwnersRoot : 1; // Offset: 0xd4 | Size: 0x1
	char pad_0xD4_1 : 7; // Offset: 0xd4 | Size: 0x1
	char pad_0xD5[0x3]; // Offset: 0xd5 | Size: 0x3
	struct UObject* CachedNavParent; // Offset: 0xd8 | Size: 0x8

	// Functions

	// Object: Function NavigationSystem.NavRelevantComponent.SetNavigationRelevancy
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1059d1db0
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetNavigationRelevancy(bool bRelevant);
};

// Object: Class NavigationSystem.NavLinkCustomComponent
// Inherited Bytes: 0xe0 | Struct Size: 0x188
struct UNavLinkCustomComponent : UNavRelevantComponent {
	// Fields
	char pad_0xE0[0x8]; // Offset: 0xe0 | Size: 0x8
	uint32_t NavLinkUserId; // Offset: 0xe8 | Size: 0x4
	char pad_0xEC[0x4]; // Offset: 0xec | Size: 0x4
	struct UNavArea* EnabledAreaClass; // Offset: 0xf0 | Size: 0x8
	struct UNavArea* DisabledAreaClass; // Offset: 0xf8 | Size: 0x8
	struct FNavAgentSelector SupportedAgents; // Offset: 0x100 | Size: 0x4
	struct FVector LinkRelativeStart; // Offset: 0x104 | Size: 0xc
	struct FVector LinkRelativeEnd; // Offset: 0x110 | Size: 0xc
	enum class ENavLinkDirection LinkDirection; // Offset: 0x11c | Size: 0x1
	char bLinkEnabled : 1; // Offset: 0x11d | Size: 0x1
	char bNotifyWhenEnabled : 1; // Offset: 0x11d | Size: 0x1
	char bNotifyWhenDisabled : 1; // Offset: 0x11d | Size: 0x1
	char bCreateBoxObstacle : 1; // Offset: 0x11d | Size: 0x1
	char pad_0x11D_4 : 4; // Offset: 0x11d | Size: 0x1
	char pad_0x11E[0x2]; // Offset: 0x11e | Size: 0x2
	struct FVector ObstacleOffset; // Offset: 0x120 | Size: 0xc
	struct FVector ObstacleExtent; // Offset: 0x12c | Size: 0xc
	struct UNavArea* ObstacleAreaClass; // Offset: 0x138 | Size: 0x8
	float BroadcastRadius; // Offset: 0x140 | Size: 0x4
	float BroadcastInterval; // Offset: 0x144 | Size: 0x4
	enum class ECollisionChannel BroadcastChannel; // Offset: 0x148 | Size: 0x1
	char pad_0x149[0x3f]; // Offset: 0x149 | Size: 0x3f
};

// Object: Class NavigationSystem.NavModifierComponent
// Inherited Bytes: 0xe0 | Struct Size: 0x140
struct UNavModifierComponent : UNavRelevantComponent {
	// Fields
	struct UNavArea* AreaClass; // Offset: 0xe0 | Size: 0x8
	struct FVector FailsafeExtent; // Offset: 0xe8 | Size: 0xc
	char bIncludeAgentHeight : 1; // Offset: 0xf4 | Size: 0x1
	char pad_0xF4_1 : 7; // Offset: 0xf4 | Size: 0x1
	char pad_0xF5[0x4b]; // Offset: 0xf5 | Size: 0x4b

	// Functions

	// Object: Function NavigationSystem.NavModifierComponent.SetAreaClass
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1059d172c
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetAreaClass(struct UNavArea* NewAreaClass);
};

// Object: Class NavigationSystem.NavigationQueryFilter
// Inherited Bytes: 0x28 | Struct Size: 0x48
struct UNavigationQueryFilter : UObject {
	// Fields
	struct TArray<struct FNavigationFilterArea> Areas; // Offset: 0x28 | Size: 0x10
	struct FNavigationFilterFlags IncludeFlags; // Offset: 0x38 | Size: 0x4
	struct FNavigationFilterFlags ExcludeFlags; // Offset: 0x3c | Size: 0x4
	char pad_0x40[0x8]; // Offset: 0x40 | Size: 0x8
};

// Object: Class NavigationSystem.NavigationData
// Inherited Bytes: 0x228 | Struct Size: 0x408
struct ANavigationData : AActor {
	// Fields
	char pad_0x228[0x8]; // Offset: 0x228 | Size: 0x8
	struct UPrimitiveComponent* RenderingComp; // Offset: 0x230 | Size: 0x8
	struct FNavDataConfig NavDataConfig; // Offset: 0x238 | Size: 0x78
	char bEnableDrawing : 1; // Offset: 0x2b0 | Size: 0x1
	char bForceRebuildOnLoad : 1; // Offset: 0x2b0 | Size: 0x1
	char bAutoDestroyWhenNoNavigation : 1; // Offset: 0x2b0 | Size: 0x1
	char bCanBeMainNavData : 1; // Offset: 0x2b0 | Size: 0x1
	char bCanSpawnOnRebuild : 1; // Offset: 0x2b0 | Size: 0x1
	char bRebuildAtRuntime : 1; // Offset: 0x2b0 | Size: 0x1
	char pad_0x2B0_6 : 2; // Offset: 0x2b0 | Size: 0x1
	enum class ERuntimeGenerationType RuntimeGeneration; // Offset: 0x2b1 | Size: 0x1
	char pad_0x2B2[0x2]; // Offset: 0x2b2 | Size: 0x2
	float ObservedPathsTickInterval; // Offset: 0x2b4 | Size: 0x4
	uint32_t DataVersion; // Offset: 0x2b8 | Size: 0x4
	char pad_0x2BC[0xe4]; // Offset: 0x2bc | Size: 0xe4
	struct TArray<struct FSupportedAreaData> SupportedAreas; // Offset: 0x3a0 | Size: 0x10
	char pad_0x3B0[0x58]; // Offset: 0x3b0 | Size: 0x58
};

// Object: Class NavigationSystem.AbstractNavData
// Inherited Bytes: 0x408 | Struct Size: 0x408
struct AAbstractNavData : ANavigationData {
};

// Object: Class NavigationSystem.CrowdManagerBase
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UCrowdManagerBase : UObject {
};

// Object: Class NavigationSystem.NavArea_Default
// Inherited Bytes: 0x48 | Struct Size: 0x48
struct UNavArea_Default : UNavArea {
};

// Object: Class NavigationSystem.NavArea_LowHeight
// Inherited Bytes: 0x48 | Struct Size: 0x48
struct UNavArea_LowHeight : UNavArea {
};

// Object: Class NavigationSystem.NavArea_Null
// Inherited Bytes: 0x48 | Struct Size: 0x48
struct UNavArea_Null : UNavArea {
};

// Object: Class NavigationSystem.NavArea_Obstacle
// Inherited Bytes: 0x48 | Struct Size: 0x48
struct UNavArea_Obstacle : UNavArea {
};

// Object: Class NavigationSystem.NavAreaMeta
// Inherited Bytes: 0x48 | Struct Size: 0x48
struct UNavAreaMeta : UNavArea {
};

// Object: Class NavigationSystem.NavAreaMeta_SwitchByAgent
// Inherited Bytes: 0x48 | Struct Size: 0xc8
struct UNavAreaMeta_SwitchByAgent : UNavAreaMeta {
	// Fields
	struct UNavArea* Agent0Area; // Offset: 0x48 | Size: 0x8
	struct UNavArea* Agent1Area; // Offset: 0x50 | Size: 0x8
	struct UNavArea* Agent2Area; // Offset: 0x58 | Size: 0x8
	struct UNavArea* Agent3Area; // Offset: 0x60 | Size: 0x8
	struct UNavArea* Agent4Area; // Offset: 0x68 | Size: 0x8
	struct UNavArea* Agent5Area; // Offset: 0x70 | Size: 0x8
	struct UNavArea* Agent6Area; // Offset: 0x78 | Size: 0x8
	struct UNavArea* Agent7Area; // Offset: 0x80 | Size: 0x8
	struct UNavArea* Agent8Area; // Offset: 0x88 | Size: 0x8
	struct UNavArea* Agent9Area; // Offset: 0x90 | Size: 0x8
	struct UNavArea* Agent10Area; // Offset: 0x98 | Size: 0x8
	struct UNavArea* Agent11Area; // Offset: 0xa0 | Size: 0x8
	struct UNavArea* Agent12Area; // Offset: 0xa8 | Size: 0x8
	struct UNavArea* Agent13Area; // Offset: 0xb0 | Size: 0x8
	struct UNavArea* Agent14Area; // Offset: 0xb8 | Size: 0x8
	struct UNavArea* Agent15Area; // Offset: 0xc0 | Size: 0x8
};

// Object: Class NavigationSystem.NavCollision
// Inherited Bytes: 0x70 | Struct Size: 0xd8
struct UNavCollision : UNavCollisionBase {
	// Fields
	char pad_0x70[0x10]; // Offset: 0x70 | Size: 0x10
	struct TArray<struct FNavCollisionCylinder> CylinderCollision; // Offset: 0x80 | Size: 0x10
	struct TArray<struct FNavCollisionBox> BoxCollision; // Offset: 0x90 | Size: 0x10
	struct UNavArea* AreaClass; // Offset: 0xa0 | Size: 0x8
	char bGatherConvexGeometry : 1; // Offset: 0xa8 | Size: 0x1
	char bCreateOnClient : 1; // Offset: 0xa8 | Size: 0x1
	char pad_0xA8_2 : 6; // Offset: 0xa8 | Size: 0x1
	char pad_0xA9[0x2f]; // Offset: 0xa9 | Size: 0x2f
};

// Object: Class NavigationSystem.NavigationGraph
// Inherited Bytes: 0x408 | Struct Size: 0x408
struct ANavigationGraph : ANavigationData {
};

// Object: Class NavigationSystem.NavigationGraphNode
// Inherited Bytes: 0x228 | Struct Size: 0x228
struct ANavigationGraphNode : AActor {
};

// Object: Class NavigationSystem.NavigationGraphNodeComponent
// Inherited Bytes: 0x350 | Struct Size: 0x370
struct UNavigationGraphNodeComponent : USceneComponent {
	// Fields
	struct FNavGraphNode Node; // Offset: 0x348 | Size: 0x18
	struct UNavigationGraphNodeComponent* NextNodeComponent; // Offset: 0x360 | Size: 0x8
	struct UNavigationGraphNodeComponent* PrevNodeComponent; // Offset: 0x368 | Size: 0x8
};

// Object: Class NavigationSystem.NavigationInvokerComponent
// Inherited Bytes: 0xb0 | Struct Size: 0xb8
struct UNavigationInvokerComponent : UActorComponent {
	// Fields
	float TileGenerationRadius; // Offset: 0xb0 | Size: 0x4
	float TileRemovalRadius; // Offset: 0xb4 | Size: 0x4
};

// Object: Class NavigationSystem.NavigationPath
// Inherited Bytes: 0x28 | Struct Size: 0x80
struct UNavigationPath : UObject {
	// Fields
	struct FMulticastInlineDelegate PathUpdatedNotifier; // Offset: 0x28 | Size: 0x10
	struct TArray<struct FVector> PathPoints; // Offset: 0x38 | Size: 0x10
	enum class ENavigationOptionFlag RecalculateOnInvalidation; // Offset: 0x48 | Size: 0x1
	char pad_0x49[0x37]; // Offset: 0x49 | Size: 0x37

	// Functions

	// Object: Function NavigationSystem.NavigationPath.IsValid
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1059c9c44
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsValid();

	// Object: Function NavigationSystem.NavigationPath.IsStringPulled
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1059c9c10
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsStringPulled();

	// Object: Function NavigationSystem.NavigationPath.IsPartial
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1059c9c78
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsPartial();

	// Object: Function NavigationSystem.NavigationPath.GetPathLength
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1059c9ce0
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetPathLength();

	// Object: Function NavigationSystem.NavigationPath.GetPathCost
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1059c9cac
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetPathCost();

	// Object: Function NavigationSystem.NavigationPath.GetDebugString
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1059c9e70
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetDebugString();

	// Object: Function NavigationSystem.NavigationPath.EnableRecalculationOnInvalidation
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1059c9d14
	// Return & Params: [ Num(1) Size(0x1) ]
	void EnableRecalculationOnInvalidation(enum class ENavigationOptionFlag DoRecalculation);

	// Object: Function NavigationSystem.NavigationPath.EnableDebugDrawing
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x1059c9d94
	// Return & Params: [ Num(2) Size(0x14) ]
	void EnableDebugDrawing(bool bShouldDrawDebugData, struct FLinearColor PathColor);
};

// Object: Class NavigationSystem.NavigationPathGenerator
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UNavigationPathGenerator : UInterface {
};

// Object: Class NavigationSystem.NavigationSystemV1
// Inherited Bytes: 0x28 | Struct Size: 0x570
struct UNavigationSystemV1 : UNavigationSystemBase {
	// Fields
	struct ANavigationData* MainNavData; // Offset: 0x28 | Size: 0x8
	struct ANavigationData* AbstractNavData; // Offset: 0x30 | Size: 0x8
	struct FName DefaultAgentName; // Offset: 0x38 | Size: 0x8
	struct TSoftClassPtr<UObject> CrowdManagerClass; // Offset: 0x40 | Size: 0x28
	char bAutoCreateNavigationData : 1; // Offset: 0x68 | Size: 0x1
	char bSpawnNavDataInNavBoundsLevel : 1; // Offset: 0x68 | Size: 0x1
	char bAllowClientSideNavigation : 1; // Offset: 0x68 | Size: 0x1
	char bShouldDiscardSubLevelNavData : 1; // Offset: 0x68 | Size: 0x1
	char bTickWhilePaused : 1; // Offset: 0x68 | Size: 0x1
	char bSupportRebuilding : 1; // Offset: 0x68 | Size: 0x1
	char bInitialBuildingLocked : 1; // Offset: 0x68 | Size: 0x1
	char pad_0x68_7 : 1; // Offset: 0x68 | Size: 0x1
	char bSkipAgentHeightCheckWhenPickingNavData : 1; // Offset: 0x69 | Size: 0x1
	char pad_0x69_1 : 7; // Offset: 0x69 | Size: 0x1
	enum class ENavDataGatheringModeConfig DataGatheringMode; // Offset: 0x6a | Size: 0x1
	char bGenerateNavigationOnlyAroundNavigationInvokers : 1; // Offset: 0x6b | Size: 0x1
	char pad_0x6B_1 : 7; // Offset: 0x6b | Size: 0x1
	float ActiveTilesUpdateInterval; // Offset: 0x6c | Size: 0x4
	struct TArray<struct FNavDataConfig> SupportedAgents; // Offset: 0x70 | Size: 0x10
	struct FNavAgentSelector SupportedAgentsMask; // Offset: 0x80 | Size: 0x4
	char pad_0x84[0x4]; // Offset: 0x84 | Size: 0x4
	struct TArray<struct ANavigationData*> NavDataSet; // Offset: 0x88 | Size: 0x10
	struct TArray<struct ANavigationData*> NavDataRegistrationQueue; // Offset: 0x98 | Size: 0x10
	char pad_0xA8[0x10]; // Offset: 0xa8 | Size: 0x10
	struct FMulticastInlineDelegate OnNavDataRegisteredEvent; // Offset: 0xb8 | Size: 0x10
	struct FMulticastInlineDelegate OnNavigationGenerationFinishedDelegate; // Offset: 0xc8 | Size: 0x10
	char pad_0xD8[0xec]; // Offset: 0xd8 | Size: 0xec
	enum class FNavigationSystemRunMode OperationMode; // Offset: 0x1c4 | Size: 0x1
	char pad_0x1C5[0x387]; // Offset: 0x1c5 | Size: 0x387
	float DirtyAreasUpdateFreq; // Offset: 0x54c | Size: 0x4
	char pad_0x550[0x20]; // Offset: 0x550 | Size: 0x20

	// Functions

	// Object: Function NavigationSystem.NavigationSystemV1.UnregisterNavigationInvoker
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1059cb514
	// Return & Params: [ Num(1) Size(0x8) ]
	void UnregisterNavigationInvoker(struct AActor* Invoker);

	// Object: Function NavigationSystem.NavigationSystemV1.SimpleMoveToLocation
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1059cac28
	// Return & Params: [ Num(2) Size(0x14) ]
	void SimpleMoveToLocation(struct AController* Controller, struct FVector& Goal);

	// Object: Function NavigationSystem.NavigationSystemV1.SimpleMoveToActor
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1059cacf0
	// Return & Params: [ Num(2) Size(0x10) ]
	void SimpleMoveToActor(struct AController* Controller, struct AActor* Goal);

	// Object: Function NavigationSystem.NavigationSystemV1.SetMaxSimultaneousTileGenerationJobsCount
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1059cb6bc
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetMaxSimultaneousTileGenerationJobsCount(int32_t MaxNumberOfJobs);

	// Object: Function NavigationSystem.NavigationSystemV1.SetGeometryGatheringMode
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1059cb494
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetGeometryGatheringMode(enum class ENavDataGatheringModeConfig NewMode);

	// Object: Function NavigationSystem.NavigationSystemV1.ResetMaxSimultaneousTileGenerationJobsCount
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1059cb6a8
	// Return & Params: [ Num(0) Size(0x0) ]
	void ResetMaxSimultaneousTileGenerationJobsCount();

	// Object: Function NavigationSystem.NavigationSystemV1.RegisterNavigationInvoker
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1059cb594
	// Return & Params: [ Num(3) Size(0x10) ]
	void RegisterNavigationInvoker(struct AActor* Invoker, float TileGenerationRadius, float TileRemovalRadius);

	// Object: Function NavigationSystem.NavigationSystemV1.ProjectPointToNavigation
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x1059cb130
	// Return & Params: [ Num(6) Size(0x40) ]
	struct FVector ProjectPointToNavigation(struct UObject* WorldContextObject, struct FVector& Point, struct ANavigationData* NavData, struct UNavigationQueryFilter* FilterClass, struct FVector QueryExtent);

	// Object: Function NavigationSystem.NavigationSystemV1.OnNavigationBoundsUpdated
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1059cb2f0
	// Return & Params: [ Num(1) Size(0x8) ]
	void OnNavigationBoundsUpdated(struct ANavMeshBoundsVolume* NavVolume);

	// Object: Function NavigationSystem.NavigationSystemV1.NavigationRaycast
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1059cb73c
	// Return & Params: [ Num(7) Size(0x41) ]
	bool NavigationRaycast(struct UObject* WorldContextObject, struct FVector& RayStart, struct FVector& RayEnd, struct FVector& HitLocation, struct UNavigationQueryFilter* FilterClass, struct AController* Querier);

	// Object: Function NavigationSystem.NavigationSystemV1.K2_ReplaceAreaInOctreeData
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1059cb370
	// Return & Params: [ Num(4) Size(0x19) ]
	bool K2_ReplaceAreaInOctreeData(struct UObject* Object, struct UNavArea* OldArea, struct UNavArea* NewArea);

	// Object: Function NavigationSystem.NavigationSystemV1.K2_ProjectPointToNavigation
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x1059cc698
	// Return & Params: [ Num(7) Size(0x3d) ]
	bool K2_ProjectPointToNavigation(struct UObject* WorldContextObject, struct FVector& Point, struct FVector& ProjectedLocation, struct ANavigationData* NavData, struct UNavigationQueryFilter* FilterClass, struct FVector QueryExtent);

	// Object: Function NavigationSystem.NavigationSystemV1.K2_GetRandomReachablePointInRadius
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x1059cc488
	// Return & Params: [ Num(7) Size(0x39) ]
	bool K2_GetRandomReachablePointInRadius(struct UObject* WorldContextObject, struct FVector& Origin, struct FVector& RandomLocation, float Radius, struct ANavigationData* NavData, struct UNavigationQueryFilter* FilterClass);

	// Object: Function NavigationSystem.NavigationSystemV1.K2_GetRandomPointInNavigableRadius
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x1059caa18
	// Return & Params: [ Num(7) Size(0x39) ]
	bool K2_GetRandomPointInNavigableRadius(struct UObject* WorldContextObject, struct FVector& Origin, struct FVector& RandomLocation, float Radius, struct ANavigationData* NavData, struct UNavigationQueryFilter* FilterClass);

	// Object: Function NavigationSystem.NavigationSystemV1.K2_GetRandomLocationInNavigableRadius
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1059cc278
	// Return & Params: [ Num(7) Size(0x39) ]
	bool K2_GetRandomLocationInNavigableRadius(struct UObject* WorldContextObject, struct FVector& Origin, struct FVector& RandomLocation, float Radius, struct ANavigationData* NavData, struct UNavigationQueryFilter* FilterClass);

	// Object: Function NavigationSystem.NavigationSystemV1.IsNavigationBeingBuiltOrLocked
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1059cbd28
	// Return & Params: [ Num(2) Size(0x9) ]
	bool IsNavigationBeingBuiltOrLocked(struct UObject* WorldContextObject);

	// Object: Function NavigationSystem.NavigationSystemV1.IsNavigationBeingBuilt
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1059cbda8
	// Return & Params: [ Num(2) Size(0x9) ]
	bool IsNavigationBeingBuilt(struct UObject* WorldContextObject);

	// Object: Function NavigationSystem.NavigationSystemV1.GetRandomReachablePointInRadius
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x1059caf70
	// Return & Params: [ Num(6) Size(0x34) ]
	struct FVector GetRandomReachablePointInRadius(struct UObject* WorldContextObject, struct FVector& Origin, float Radius, struct ANavigationData* NavData, struct UNavigationQueryFilter* FilterClass);

	// Object: Function NavigationSystem.NavigationSystemV1.GetRandomPointInNavigableRadius
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x1059cadb0
	// Return & Params: [ Num(6) Size(0x34) ]
	struct FVector GetRandomPointInNavigableRadius(struct UObject* WorldContextObject, struct FVector& Origin, float Radius, struct ANavigationData* NavData, struct UNavigationQueryFilter* FilterClass);

	// Object: Function NavigationSystem.NavigationSystemV1.GetPathLength
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x1059cbe28
	// Return & Params: [ Num(7) Size(0x39) ]
	enum class ENavigationQueryResult GetPathLength(struct UObject* WorldContextObject, struct FVector& PathStart, struct FVector& PathEnd, float& PathLength, struct ANavigationData* NavData, struct UNavigationQueryFilter* FilterClass);

	// Object: Function NavigationSystem.NavigationSystemV1.GetPathCost
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x1059cc050
	// Return & Params: [ Num(7) Size(0x39) ]
	enum class ENavigationQueryResult GetPathCost(struct UObject* WorldContextObject, struct FVector& PathStart, struct FVector& PathEnd, float& PathCost, struct ANavigationData* NavData, struct UNavigationQueryFilter* FilterClass);

	// Object: Function NavigationSystem.NavigationSystemV1.GetNavigationSystem
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1059cc8a4
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UNavigationSystemV1* GetNavigationSystem(struct UObject* WorldContextObject);

	// Object: Function NavigationSystem.NavigationSystemV1.FindPathToLocationSynchronously
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1059cbb64
	// Return & Params: [ Num(6) Size(0x38) ]
	struct UNavigationPath* FindPathToLocationSynchronously(struct UObject* WorldContextObject, struct FVector& PathStart, struct FVector& PathEnd, struct AActor* PathfindingContext, struct UNavigationQueryFilter* FilterClass);

	// Object: Function NavigationSystem.NavigationSystemV1.FindPathToActorSynchronously
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1059cb95c
	// Return & Params: [ Num(7) Size(0x40) ]
	struct UNavigationPath* FindPathToActorSynchronously(struct UObject* WorldContextObject, struct FVector& PathStart, struct AActor* GoalActor, float TetherDistance, struct AActor* PathfindingContext, struct UNavigationQueryFilter* FilterClass);
};

// Object: Class NavigationSystem.NavigationSystemModuleConfig
// Inherited Bytes: 0x50 | Struct Size: 0x50
struct UNavigationSystemModuleConfig : UNavigationSystemConfig {
	// Fields
	char bStrictlyStatic : 1; // Offset: 0x4d | Size: 0x1
	char bCreateOnClient : 1; // Offset: 0x4d | Size: 0x1
	char bAutoSpawnMissingNavData : 1; // Offset: 0x4d | Size: 0x1
	char bSpawnNavDataInNavBoundsLevel : 1; // Offset: 0x4d | Size: 0x1
};

// Object: Class NavigationSystem.NavigationTestingActor
// Inherited Bytes: 0x228 | Struct Size: 0x318
struct ANavigationTestingActor : AActor {
	// Fields
	char pad_0x228[0x10]; // Offset: 0x228 | Size: 0x10
	struct UCapsuleComponent* CapsuleComponent; // Offset: 0x238 | Size: 0x8
	struct UNavigationInvokerComponent* InvokerComponent; // Offset: 0x240 | Size: 0x8
	char bActAsNavigationInvoker : 1; // Offset: 0x248 | Size: 0x1
	char pad_0x248_1 : 7; // Offset: 0x248 | Size: 0x1
	char pad_0x249[0x7]; // Offset: 0x249 | Size: 0x7
	struct FNavAgentProperties NavAgentProps; // Offset: 0x250 | Size: 0x30
	struct FVector QueryingExtent; // Offset: 0x280 | Size: 0xc
	char pad_0x28C[0x4]; // Offset: 0x28c | Size: 0x4
	struct ANavigationData* MyNavData; // Offset: 0x290 | Size: 0x8
	struct FVector ProjectedLocation; // Offset: 0x298 | Size: 0xc
	char bProjectedLocationValid : 1; // Offset: 0x2a4 | Size: 0x1
	char bSearchStart : 1; // Offset: 0x2a4 | Size: 0x1
	char pad_0x2A4_2 : 6; // Offset: 0x2a4 | Size: 0x1
	char pad_0x2A5[0x3]; // Offset: 0x2a5 | Size: 0x3
	float CostLimitFactor; // Offset: 0x2a8 | Size: 0x4
	float MinimumCostLimit; // Offset: 0x2ac | Size: 0x4
	char bBacktracking : 1; // Offset: 0x2b0 | Size: 0x1
	char bUseHierarchicalPathfinding : 1; // Offset: 0x2b0 | Size: 0x1
	char bGatherDetailedInfo : 1; // Offset: 0x2b0 | Size: 0x1
	char bDrawDistanceToWall : 1; // Offset: 0x2b0 | Size: 0x1
	char bShowNodePool : 1; // Offset: 0x2b0 | Size: 0x1
	char bShowBestPath : 1; // Offset: 0x2b0 | Size: 0x1
	char bShowDiffWithPreviousStep : 1; // Offset: 0x2b0 | Size: 0x1
	char bShouldBeVisibleInGame : 1; // Offset: 0x2b0 | Size: 0x1
	enum class ENavCostDisplay CostDisplayMode; // Offset: 0x2b1 | Size: 0x1
	char pad_0x2B2[0x2]; // Offset: 0x2b2 | Size: 0x2
	struct FVector2D TextCanvasOffset; // Offset: 0x2b4 | Size: 0x8
	char bPathExist : 1; // Offset: 0x2bc | Size: 0x1
	char bPathIsPartial : 1; // Offset: 0x2bc | Size: 0x1
	char bPathSearchOutOfNodes : 1; // Offset: 0x2bc | Size: 0x1
	char pad_0x2BC_3 : 5; // Offset: 0x2bc | Size: 0x1
	char pad_0x2BD[0x3]; // Offset: 0x2bd | Size: 0x3
	float PathfindingTime; // Offset: 0x2c0 | Size: 0x4
	float PathCost; // Offset: 0x2c4 | Size: 0x4
	int32_t PathfindingSteps; // Offset: 0x2c8 | Size: 0x4
	char pad_0x2CC[0x4]; // Offset: 0x2cc | Size: 0x4
	struct ANavigationTestingActor* OtherActor; // Offset: 0x2d0 | Size: 0x8
	struct UNavigationQueryFilter* FilterClass; // Offset: 0x2d8 | Size: 0x8
	int32_t ShowStepIndex; // Offset: 0x2e0 | Size: 0x4
	float OffsetFromCornersDistance; // Offset: 0x2e4 | Size: 0x4
	char pad_0x2E8[0x30]; // Offset: 0x2e8 | Size: 0x30
};

// Object: Class NavigationSystem.NavLinkComponent
// Inherited Bytes: 0x570 | Struct Size: 0x590
struct UNavLinkComponent : UPrimitiveComponent {
	// Fields
	char pad_0x570[0x8]; // Offset: 0x570 | Size: 0x8
	struct TArray<struct FNavigationLink> Links; // Offset: 0x578 | Size: 0x10
	char pad_0x588[0x8]; // Offset: 0x588 | Size: 0x8
};

// Object: Class NavigationSystem.NavLinkCustomInterface
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UNavLinkCustomInterface : UInterface {
};

// Object: Class NavigationSystem.NavLinkHostInterface
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UNavLinkHostInterface : UInterface {
};

// Object: Class NavigationSystem.NavLinkRenderingComponent
// Inherited Bytes: 0x570 | Struct Size: 0x570
struct UNavLinkRenderingComponent : UPrimitiveComponent {
};

// Object: Class NavigationSystem.NavLinkTrivial
// Inherited Bytes: 0x50 | Struct Size: 0x50
struct UNavLinkTrivial : UNavLinkDefinition {
};

// Object: Class NavigationSystem.NavMeshBoundsVolume
// Inherited Bytes: 0x260 | Struct Size: 0x268
struct ANavMeshBoundsVolume : AVolume {
	// Fields
	struct FNavAgentSelector SupportedAgents; // Offset: 0x260 | Size: 0x4
	char pad_0x264[0x4]; // Offset: 0x264 | Size: 0x4
};

// Object: Class NavigationSystem.NavMeshRenderingComponent
// Inherited Bytes: 0x570 | Struct Size: 0x580
struct UNavMeshRenderingComponent : UPrimitiveComponent {
	// Fields
	char pad_0x570[0x10]; // Offset: 0x570 | Size: 0x10
};

// Object: Class NavigationSystem.NavModifierVolume
// Inherited Bytes: 0x260 | Struct Size: 0x270
struct ANavModifierVolume : AVolume {
	// Fields
	char pad_0x260[0x8]; // Offset: 0x260 | Size: 0x8
	struct UNavArea* AreaClass; // Offset: 0x268 | Size: 0x8

	// Functions

	// Object: Function NavigationSystem.NavModifierVolume.SetAreaClass
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1059d19e4
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetAreaClass(struct UNavArea* NewAreaClass);
};

// Object: Class NavigationSystem.NavNodeInterface
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UNavNodeInterface : UInterface {
};

// Object: Class NavigationSystem.NavSystemConfigOverride
// Inherited Bytes: 0x228 | Struct Size: 0x238
struct ANavSystemConfigOverride : AActor {
	// Fields
	struct UNavigationSystemConfig* NavigationSystemConfig; // Offset: 0x228 | Size: 0x8
	enum class ENavSystemOverridePolicy OverridePolicy; // Offset: 0x230 | Size: 0x1
	char bLoadOnClient : 1; // Offset: 0x231 | Size: 0x1
	char pad_0x231_1 : 7; // Offset: 0x231 | Size: 0x1
	char pad_0x232[0x6]; // Offset: 0x232 | Size: 0x6
};

// Object: Class NavigationSystem.NavTestRenderingComponent
// Inherited Bytes: 0x570 | Struct Size: 0x570
struct UNavTestRenderingComponent : UPrimitiveComponent {
};

// Object: Class NavigationSystem.RecastFilter_UseDefaultArea
// Inherited Bytes: 0x48 | Struct Size: 0x48
struct URecastFilter_UseDefaultArea : UNavigationQueryFilter {
};

// Object: Class NavigationSystem.RecastNavMesh
// Inherited Bytes: 0x408 | Struct Size: 0x4c0
struct ARecastNavMesh : ANavigationData {
	// Fields
	char bDrawTriangleEdges : 1; // Offset: 0x404 | Size: 0x1
	char bDrawPolyEdges : 1; // Offset: 0x404 | Size: 0x1
	char bDrawFilledPolys : 1; // Offset: 0x404 | Size: 0x1
	char bDrawNavMeshEdges : 1; // Offset: 0x404 | Size: 0x1
	char bDrawTileBounds : 1; // Offset: 0x404 | Size: 0x1
	char bDrawPathCollidingGeometry : 1; // Offset: 0x404 | Size: 0x1
	char bDrawTileLabels : 1; // Offset: 0x404 | Size: 0x1
	char bDrawPolygonLabels : 1; // Offset: 0x404 | Size: 0x1
	char bDrawDefaultPolygonCost : 1; // Offset: 0x405 | Size: 0x1
	char bDrawLabelsOnPathNodes : 1; // Offset: 0x405 | Size: 0x1
	char bDrawNavLinks : 1; // Offset: 0x405 | Size: 0x1
	char bDrawFailedNavLinks : 1; // Offset: 0x405 | Size: 0x1
	char bDrawClusters : 1; // Offset: 0x405 | Size: 0x1
	char bDrawOctree : 1; // Offset: 0x405 | Size: 0x1
	char bDrawOctreeDetails : 1; // Offset: 0x405 | Size: 0x1
	char bDrawMarkedForbiddenPolys : 1; // Offset: 0x405 | Size: 0x1
	char bDistinctlyDrawTilesBeingBuilt : 1; // Offset: 0x406 | Size: 0x1
	char bDrawNavMesh : 1; // Offset: 0x406 | Size: 0x1
	float DrawOffset; // Offset: 0x408 | Size: 0x4
	char bFixedTilePoolSize : 1; // Offset: 0x40c | Size: 0x1
	char pad_0x40E_3 : 5; // Offset: 0x40e | Size: 0x1
	char pad_0x40F[0x1]; // Offset: 0x40f | Size: 0x1
	int32_t TilePoolSize; // Offset: 0x410 | Size: 0x4
	float TileSizeUU; // Offset: 0x414 | Size: 0x4
	float CellSize; // Offset: 0x418 | Size: 0x4
	float CellHeight; // Offset: 0x41c | Size: 0x4
	float AgentRadius; // Offset: 0x420 | Size: 0x4
	float AgentHeight; // Offset: 0x424 | Size: 0x4
	float AgentMaxHeight; // Offset: 0x428 | Size: 0x4
	float AgentMaxSlope; // Offset: 0x42c | Size: 0x4
	float AgentMaxStepHeight; // Offset: 0x430 | Size: 0x4
	float MinRegionArea; // Offset: 0x434 | Size: 0x4
	float MergeRegionSize; // Offset: 0x438 | Size: 0x4
	float MaxSimplificationError; // Offset: 0x43c | Size: 0x4
	int32_t MaxSimultaneousTileGenerationJobsCount; // Offset: 0x440 | Size: 0x4
	int32_t TileNumberHardLimit; // Offset: 0x444 | Size: 0x4
	int32_t PolyRefTileBits; // Offset: 0x448 | Size: 0x4
	int32_t PolyRefNavPolyBits; // Offset: 0x44c | Size: 0x4
	int32_t PolyRefSaltBits; // Offset: 0x450 | Size: 0x4
	struct FVector NavMeshOriginOffset; // Offset: 0x454 | Size: 0xc
	float DefaultDrawDistance; // Offset: 0x460 | Size: 0x4
	float DefaultMaxSearchNodes; // Offset: 0x464 | Size: 0x4
	float DefaultMaxHierarchicalSearchNodes; // Offset: 0x468 | Size: 0x4
	enum class ERecastPartitioning RegionPartitioning; // Offset: 0x46c | Size: 0x1
	enum class ERecastPartitioning LayerPartitioning; // Offset: 0x46d | Size: 0x1
	char pad_0x46E[0x2]; // Offset: 0x46e | Size: 0x2
	int32_t RegionChunkSplits; // Offset: 0x470 | Size: 0x4
	int32_t LayerChunkSplits; // Offset: 0x474 | Size: 0x4
	char bSortNavigationAreasByCost : 1; // Offset: 0x478 | Size: 0x1
	char bPerformVoxelFiltering : 1; // Offset: 0x478 | Size: 0x1
	char bMarkLowHeightAreas : 1; // Offset: 0x478 | Size: 0x1
	char bFilterLowSpanSequences : 1; // Offset: 0x478 | Size: 0x1
	char bFilterLowSpanFromTileCache : 1; // Offset: 0x478 | Size: 0x1
	char bDoFullyAsyncNavDataGathering : 1; // Offset: 0x478 | Size: 0x1
	char bUseBetterOffsetsFromCorners : 1; // Offset: 0x478 | Size: 0x1
	char bStoreEmptyTileLayers : 1; // Offset: 0x478 | Size: 0x1
	char bUseVirtualFilters : 1; // Offset: 0x479 | Size: 0x1
	char bAllowNavLinkAsPathEnd : 1; // Offset: 0x479 | Size: 0x1
	char bUseVoxelCache : 1; // Offset: 0x479 | Size: 0x1
	char pad_0x479_3 : 5; // Offset: 0x479 | Size: 0x1
	char pad_0x47A[0x2]; // Offset: 0x47a | Size: 0x2
	float TileSetUpdateInterval; // Offset: 0x47c | Size: 0x4
	float HeuristicScale; // Offset: 0x480 | Size: 0x4
	float VerticalDeviationFromGroundCompensation; // Offset: 0x484 | Size: 0x4
	char pad_0x488[0x38]; // Offset: 0x488 | Size: 0x38

	// Functions

	// Object: Function NavigationSystem.RecastNavMesh.K2_ReplaceAreaInTileBounds
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x1059d25b8
	// Return & Params: [ Num(5) Size(0x32) ]
	bool K2_ReplaceAreaInTileBounds(struct FBox Bounds, struct UNavArea* OldArea, struct UNavArea* NewArea, bool ReplaceLinks);
};

// Object: Class NavigationSystem.RecastNavMeshDataChunk
// Inherited Bytes: 0x30 | Struct Size: 0x40
struct URecastNavMeshDataChunk : UNavigationDataChunk {
	// Fields
	char pad_0x30[0x10]; // Offset: 0x30 | Size: 0x10
};

