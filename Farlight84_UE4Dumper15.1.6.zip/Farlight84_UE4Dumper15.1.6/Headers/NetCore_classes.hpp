#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class NetCore.NetAnalyticsAggregatorConfig
// Inherited Bytes: 0x28 | Struct Size: 0x38
struct UNetAnalyticsAggregatorConfig : UObject {
	// Fields
	struct TArray<struct FNetAnalyticsDataConfig> NetAnalyticsData; // Offset: 0x28 | Size: 0x10
};

