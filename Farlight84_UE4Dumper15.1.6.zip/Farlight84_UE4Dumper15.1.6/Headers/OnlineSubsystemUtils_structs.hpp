#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct OnlineSubsystemUtils.BlueprintSessionResult
// Inherited Bytes: 0x0 | Struct Size: 0x108
struct FBlueprintSessionResult {
	// Fields
	char pad_0x0[0x108]; // Offset: 0x0 | Size: 0x108
};

// Object: ScriptStruct OnlineSubsystemUtils.InAppPurchaseReceiptInfo2
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FInAppPurchaseReceiptInfo2 {
	// Fields
	struct FString ItemName; // Offset: 0x0 | Size: 0x10
	struct FString ItemID; // Offset: 0x10 | Size: 0x10
	struct FString ValidationInfo; // Offset: 0x20 | Size: 0x10
};

// Object: ScriptStruct OnlineSubsystemUtils.OnlineProxyStoreOffer
// Inherited Bytes: 0x0 | Struct Size: 0x110
struct FOnlineProxyStoreOffer {
	// Fields
	struct FString OfferId; // Offset: 0x0 | Size: 0x10
	struct FText Title; // Offset: 0x10 | Size: 0x18
	struct FText Description; // Offset: 0x28 | Size: 0x18
	struct FText LongDescription; // Offset: 0x40 | Size: 0x18
	struct FText RegularPriceText; // Offset: 0x58 | Size: 0x18
	int32_t RegularPrice; // Offset: 0x70 | Size: 0x4
	char pad_0x74[0x4]; // Offset: 0x74 | Size: 0x4
	struct FText PriceText; // Offset: 0x78 | Size: 0x18
	int32_t NumericPrice; // Offset: 0x90 | Size: 0x4
	char pad_0x94[0x4]; // Offset: 0x94 | Size: 0x4
	struct FString CurrencyCode; // Offset: 0x98 | Size: 0x10
	struct FDateTime ReleaseDate; // Offset: 0xa8 | Size: 0x8
	struct FDateTime ExpirationDate; // Offset: 0xb0 | Size: 0x8
	enum class EOnlineProxyStoreOfferDiscountType DiscountType; // Offset: 0xb8 | Size: 0x1
	char pad_0xB9[0x7]; // Offset: 0xb9 | Size: 0x7
	struct TMap<struct FString, struct FString> DynamicFields; // Offset: 0xc0 | Size: 0x50
};

// Object: ScriptStruct OnlineSubsystemUtils.InAppPurchaseRestoreInfo2
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FInAppPurchaseRestoreInfo2 {
	// Fields
	struct FString ItemName; // Offset: 0x0 | Size: 0x10
	struct FString ItemID; // Offset: 0x10 | Size: 0x10
	struct FString ValidationInfo; // Offset: 0x20 | Size: 0x10
};

// Object: ScriptStruct OnlineSubsystemUtils.InAppPurchaseReceiptInfo
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FInAppPurchaseReceiptInfo {
	// Fields
	struct FString ItemName; // Offset: 0x0 | Size: 0x10
	struct FString ItemID; // Offset: 0x10 | Size: 0x10
	struct FString ValidationInfo; // Offset: 0x20 | Size: 0x10
};

// Object: ScriptStruct OnlineSubsystemUtils.InAppPurchaseProductInfo2
// Inherited Bytes: 0x0 | Struct Size: 0xf8
struct FInAppPurchaseProductInfo2 {
	// Fields
	struct FString Identifier; // Offset: 0x0 | Size: 0x10
	struct FString TransactionIdentifier; // Offset: 0x10 | Size: 0x10
	struct FString DisplayName; // Offset: 0x20 | Size: 0x10
	struct FString DisplayDescription; // Offset: 0x30 | Size: 0x10
	struct FString DisplayPrice; // Offset: 0x40 | Size: 0x10
	float RawPrice; // Offset: 0x50 | Size: 0x4
	char pad_0x54[0x4]; // Offset: 0x54 | Size: 0x4
	struct FString CurrencyCode; // Offset: 0x58 | Size: 0x10
	struct FString CurrencySymbol; // Offset: 0x68 | Size: 0x10
	struct FString DecimalSeparator; // Offset: 0x78 | Size: 0x10
	struct FString GroupingSeparator; // Offset: 0x88 | Size: 0x10
	struct FString ReceiptData; // Offset: 0x98 | Size: 0x10
	struct TMap<struct FString, struct FString> DynamicFields; // Offset: 0xa8 | Size: 0x50
};

// Object: ScriptStruct OnlineSubsystemUtils.InAppPurchaseProductRequest2
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FInAppPurchaseProductRequest2 {
	// Fields
	struct FString ProductIdentifier; // Offset: 0x0 | Size: 0x10
	bool bIsConsumable; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x7]; // Offset: 0x11 | Size: 0x7
};

// Object: ScriptStruct OnlineSubsystemUtils.PlayerReservation
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FPlayerReservation {
	// Fields
	struct FUniqueNetIdRepl UniqueId; // Offset: 0x0 | Size: 0x28
	struct FString ValidationStr; // Offset: 0x28 | Size: 0x10
	struct FString Platform; // Offset: 0x38 | Size: 0x10
	bool bAllowCrossplay; // Offset: 0x48 | Size: 0x1
	char pad_0x49[0x3]; // Offset: 0x49 | Size: 0x3
	float ElapsedTime; // Offset: 0x4c | Size: 0x4
};

// Object: ScriptStruct OnlineSubsystemUtils.PIELoginSettingsInternal
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FPIELoginSettingsInternal {
	// Fields
	struct FString ID; // Offset: 0x0 | Size: 0x10
	struct FString Token; // Offset: 0x10 | Size: 0x10
	struct FString Type; // Offset: 0x20 | Size: 0x10
	struct TArray<char> TokenBytes; // Offset: 0x30 | Size: 0x10
};

// Object: ScriptStruct OnlineSubsystemUtils.PartyReservation
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FPartyReservation {
	// Fields
	int32_t TeamNum; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct FUniqueNetIdRepl PartyLeader; // Offset: 0x8 | Size: 0x28
	struct TArray<struct FPlayerReservation> PartyMembers; // Offset: 0x30 | Size: 0x10
	struct TArray<struct FPlayerReservation> RemovedPartyMembers; // Offset: 0x40 | Size: 0x10
};

// Object: ScriptStruct OnlineSubsystemUtils.SpectatorReservation
// Inherited Bytes: 0x0 | Struct Size: 0x78
struct FSpectatorReservation {
	// Fields
	struct FUniqueNetIdRepl SpectatorId; // Offset: 0x0 | Size: 0x28
	struct FPlayerReservation Spectator; // Offset: 0x28 | Size: 0x50
};

