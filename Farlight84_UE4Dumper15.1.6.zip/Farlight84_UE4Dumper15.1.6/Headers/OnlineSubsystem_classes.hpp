#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class OnlineSubsystem.NamedInterfaces
// Inherited Bytes: 0x28 | Struct Size: 0x60
struct UNamedInterfaces : UObject {
	// Fields
	struct TArray<struct FNamedInterface> NamedInterfaces; // Offset: 0x28 | Size: 0x10
	struct TArray<struct FNamedInterfaceDef> NamedInterfaceDefs; // Offset: 0x38 | Size: 0x10
	char pad_0x48[0x18]; // Offset: 0x48 | Size: 0x18
};

// Object: Class OnlineSubsystem.TurnBasedMatchInterface
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UTurnBasedMatchInterface : UInterface {
	// Functions

	// Object: Function OnlineSubsystem.TurnBasedMatchInterface.OnMatchReceivedTurn
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x103a43990
	// Return & Params: [ Num(2) Size(0x11) ]
	void OnMatchReceivedTurn(struct FString Match, bool bDidBecomeActive);

	// Object: Function OnlineSubsystem.TurnBasedMatchInterface.OnMatchEnded
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x103a43990
	// Return & Params: [ Num(1) Size(0x10) ]
	void OnMatchEnded(struct FString Match);
};

