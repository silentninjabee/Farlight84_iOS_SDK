#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class OodleHandlerComponent.OodleTrainerCommandlet
// Inherited Bytes: 0x80 | Struct Size: 0x98
struct UOodleTrainerCommandlet : UCommandlet {
	// Fields
	bool bCompressionTest; // Offset: 0x79 | Size: 0x1
	int32_t HashTableSize; // Offset: 0x7c | Size: 0x4
	int32_t DictionarySize; // Offset: 0x80 | Size: 0x4
	int32_t DictionaryTrials; // Offset: 0x84 | Size: 0x4
	int32_t TrialRandomness; // Offset: 0x88 | Size: 0x4
	int32_t TrialGenerations; // Offset: 0x8c | Size: 0x4
	bool bNoTrials; // Offset: 0x90 | Size: 0x1
	char pad_0x96[0x2]; // Offset: 0x96 | Size: 0x2
};

