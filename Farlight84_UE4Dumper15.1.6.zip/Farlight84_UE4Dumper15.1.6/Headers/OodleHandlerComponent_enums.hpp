#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Enum OodleHandlerComponent.EOodleEnableMode
enum class EOodleEnableMode : uint8_t {
	AlwaysEnabled = 0,
	WhenCompressedPacketReceived = 1,
	EOodleEnableMode_MAX = 2
};

