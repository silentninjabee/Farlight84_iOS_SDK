#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class Paper2D.MaterialExpressionSpriteTextureSampler
// Inherited Bytes: 0xf0 | Struct Size: 0x110
struct UMaterialExpressionSpriteTextureSampler : UMaterialExpressionTextureSampleParameter2D {
	// Fields
	bool bSampleAdditionalTextures; // Offset: 0xec | Size: 0x1
	int32_t AdditionalSlotIndex; // Offset: 0xf0 | Size: 0x4
	char pad_0xF5[0x3]; // Offset: 0xf5 | Size: 0x3
	struct FText SlotDisplayName; // Offset: 0xf8 | Size: 0x18
};

// Object: Class Paper2D.PaperCharacter
// Inherited Bytes: 0x4d0 | Struct Size: 0x4d0
struct APaperCharacter : ACharacter {
	// Fields
	struct UPaperFlipbookComponent* Sprite; // Offset: 0x4c8 | Size: 0x8
};

// Object: Class Paper2D.PaperFlipbook
// Inherited Bytes: 0x28 | Struct Size: 0x50
struct UPaperFlipbook : UObject {
	// Fields
	float FramesPerSecond; // Offset: 0x28 | Size: 0x4
	char pad_0x2C[0x4]; // Offset: 0x2c | Size: 0x4
	struct TArray<struct FPaperFlipbookKeyFrame> KeyFrames; // Offset: 0x30 | Size: 0x10
	struct UMaterialInterface* DefaultMaterial; // Offset: 0x40 | Size: 0x8
	enum class EFlipbookCollisionMode CollisionSource; // Offset: 0x48 | Size: 0x1
	char pad_0x49[0x7]; // Offset: 0x49 | Size: 0x7

	// Functions

	// Object: Function Paper2D.PaperFlipbook.IsValidKeyFrameIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102352ef8
	// Return & Params: [ Num(2) Size(0x5) ]
	bool IsValidKeyFrameIndex(int32_t Index);

	// Object: Function Paper2D.PaperFlipbook.GetTotalDuration
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102353234
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetTotalDuration();

	// Object: Function Paper2D.PaperFlipbook.GetSpriteAtTime
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10235306c
	// Return & Params: [ Num(3) Size(0x10) ]
	struct UPaperSprite* GetSpriteAtTime(float Time, bool bClampToEnds);

	// Object: Function Paper2D.PaperFlipbook.GetSpriteAtFrame
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102352fdc
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UPaperSprite* GetSpriteAtFrame(int32_t FrameIndex);

	// Object: Function Paper2D.PaperFlipbook.GetNumKeyFrames
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102352fc0
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetNumKeyFrames();

	// Object: Function Paper2D.PaperFlipbook.GetNumFrames
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102353268
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetNumFrames();

	// Object: Function Paper2D.PaperFlipbook.GetKeyFrameIndexAtTime
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102353150
	// Return & Params: [ Num(3) Size(0xc) ]
	int32_t GetKeyFrameIndexAtTime(float Time, bool bClampToEnds);
};

// Object: Class Paper2D.PaperFlipbookActor
// Inherited Bytes: 0x228 | Struct Size: 0x230
struct APaperFlipbookActor : AActor {
	// Fields
	struct UPaperFlipbookComponent* RenderComponent; // Offset: 0x228 | Size: 0x8
};

// Object: Class Paper2D.PaperFlipbookComponent
// Inherited Bytes: 0x5b0 | Struct Size: 0x5f0
struct UPaperFlipbookComponent : UMeshComponent {
	// Fields
	struct UPaperFlipbook* SourceFlipbook; // Offset: 0x5a8 | Size: 0x8
	struct UMaterialInterface* Material; // Offset: 0x5b0 | Size: 0x8
	float PlayRate; // Offset: 0x5b8 | Size: 0x4
	char bLooping : 1; // Offset: 0x5bc | Size: 0x1
	char bReversePlayback : 1; // Offset: 0x5bc | Size: 0x1
	char bPlaying : 1; // Offset: 0x5bc | Size: 0x1
	float AccumulatedTime; // Offset: 0x5c0 | Size: 0x4
	int32_t CachedFrameIndex; // Offset: 0x5c4 | Size: 0x4
	struct FLinearColor SpriteColor; // Offset: 0x5c8 | Size: 0x10
	struct UBodySetup* CachedBodySetup; // Offset: 0x5d8 | Size: 0x8
	struct FMulticastInlineDelegate OnFinishedPlaying; // Offset: 0x5e0 | Size: 0x10

	// Functions

	// Object: Function Paper2D.PaperFlipbookComponent.Stop
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102353dfc
	// Return & Params: [ Num(0) Size(0x0) ]
	void Stop();

	// Object: Function Paper2D.PaperFlipbookComponent.SetSpriteColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x102353e60
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetSpriteColor(struct FLinearColor NewColor);

	// Object: Function Paper2D.PaperFlipbookComponent.SetPlayRate
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102353a4c
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetPlayRate(float NewRate);

	// Object: Function Paper2D.PaperFlipbookComponent.SetPlaybackPositionInFrames
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102353cc4
	// Return & Params: [ Num(2) Size(0x5) ]
	void SetPlaybackPositionInFrames(int32_t NewFramePosition, bool bFireEvents);

	// Object: Function Paper2D.PaperFlipbookComponent.SetPlaybackPosition
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102353bbc
	// Return & Params: [ Num(2) Size(0x5) ]
	void SetPlaybackPosition(float NewPosition, bool bFireEvents);

	// Object: Function Paper2D.PaperFlipbookComponent.SetNewTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102353998
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetNewTime(float NewTime);

	// Object: Function Paper2D.PaperFlipbookComponent.SetLooping
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102353b00
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetLooping(bool bNewLooping);

	// Object: Function Paper2D.PaperFlipbookComponent.SetFlipbook
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102353f1c
	// Return & Params: [ Num(2) Size(0x9) ]
	bool SetFlipbook(struct UPaperFlipbook* NewFlipbook);

	// Object: Function Paper2D.PaperFlipbookComponent.ReverseFromEnd
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102353e10
	// Return & Params: [ Num(0) Size(0x0) ]
	void ReverseFromEnd();

	// Object: Function Paper2D.PaperFlipbookComponent.Reverse
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102353e24
	// Return & Params: [ Num(0) Size(0x0) ]
	void Reverse();

	// Object: Function Paper2D.PaperFlipbookComponent.PlayFromStart
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102353e38
	// Return & Params: [ Num(0) Size(0x0) ]
	void PlayFromStart();

	// Object: Function Paper2D.PaperFlipbookComponent.Play
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102353e4c
	// Return & Params: [ Num(0) Size(0x0) ]
	void Play();

	// Object: Function Paper2D.PaperFlipbookComponent.OnRep_SourceFlipbook
	// Flags: [Final|Native|Protected]
	// Offset: 0x10235387c
	// Return & Params: [ Num(1) Size(0x8) ]
	void OnRep_SourceFlipbook(struct UPaperFlipbook* OldFlipbook);

	// Object: Function Paper2D.PaperFlipbookComponent.IsReversing
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102353d94
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsReversing();

	// Object: Function Paper2D.PaperFlipbookComponent.IsPlaying
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102353dc8
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsPlaying();

	// Object: Function Paper2D.PaperFlipbookComponent.IsLooping
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102353acc
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsLooping();

	// Object: Function Paper2D.PaperFlipbookComponent.GetPlayRate
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102353a18
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetPlayRate();

	// Object: Function Paper2D.PaperFlipbookComponent.GetPlaybackPositionInFrames
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102353c90
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetPlaybackPositionInFrames();

	// Object: Function Paper2D.PaperFlipbookComponent.GetPlaybackPosition
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102353b88
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetPlaybackPosition();

	// Object: Function Paper2D.PaperFlipbookComponent.GetFlipbookLengthInFrames
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102353930
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetFlipbookLengthInFrames();

	// Object: Function Paper2D.PaperFlipbookComponent.GetFlipbookLength
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102353964
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetFlipbookLength();

	// Object: Function Paper2D.PaperFlipbookComponent.GetFlipbookFramerate
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1023538fc
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetFlipbookFramerate();

	// Object: Function Paper2D.PaperFlipbookComponent.GetFlipbook
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x102353ee0
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UPaperFlipbook* GetFlipbook();
};

// Object: Class Paper2D.PaperGroupedSpriteActor
// Inherited Bytes: 0x228 | Struct Size: 0x230
struct APaperGroupedSpriteActor : AActor {
	// Fields
	struct UPaperGroupedSpriteComponent* RenderComponent; // Offset: 0x228 | Size: 0x8
};

// Object: Class Paper2D.PaperGroupedSpriteComponent
// Inherited Bytes: 0x5b0 | Struct Size: 0x5e0
struct UPaperGroupedSpriteComponent : UMeshComponent {
	// Fields
	struct TArray<struct UMaterialInterface*> InstanceMaterials; // Offset: 0x5a8 | Size: 0x10
	struct TArray<struct FSpriteInstanceData> PerInstanceSpriteData; // Offset: 0x5b8 | Size: 0x10
	char pad_0x5D0[0x10]; // Offset: 0x5d0 | Size: 0x10

	// Functions

	// Object: Function Paper2D.PaperGroupedSpriteComponent.UpdateInstanceTransform
	// Flags: [Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102354f80
	// Return & Params: [ Num(6) Size(0x44) ]
	bool UpdateInstanceTransform(int32_t InstanceIndex, struct FTransform& NewInstanceTransform, bool bWorldSpace, bool bMarkRenderStateDirty, bool bTeleport);

	// Object: Function Paper2D.PaperGroupedSpriteComponent.UpdateInstanceColor
	// Flags: [Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x102354e4c
	// Return & Params: [ Num(4) Size(0x16) ]
	bool UpdateInstanceColor(int32_t InstanceIndex, struct FLinearColor NewInstanceColor, bool bMarkRenderStateDirty);

	// Object: Function Paper2D.PaperGroupedSpriteComponent.SortInstancesAlongAxis
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x102354ce4
	// Return & Params: [ Num(1) Size(0xc) ]
	void SortInstancesAlongAxis(struct FVector WorldSpaceSortAxis);

	// Object: Function Paper2D.PaperGroupedSpriteComponent.RemoveInstance
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102354db4
	// Return & Params: [ Num(2) Size(0x5) ]
	bool RemoveInstance(int32_t InstanceIndex);

	// Object: Function Paper2D.PaperGroupedSpriteComponent.GetInstanceTransform
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1023551c8
	// Return & Params: [ Num(4) Size(0x42) ]
	bool GetInstanceTransform(int32_t InstanceIndex, struct FTransform& OutInstanceTransform, bool bWorldSpace);

	// Object: Function Paper2D.PaperGroupedSpriteComponent.GetInstanceCount
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102354d64
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetInstanceCount();

	// Object: Function Paper2D.PaperGroupedSpriteComponent.ClearInstances
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102354d98
	// Return & Params: [ Num(0) Size(0x0) ]
	void ClearInstances();

	// Object: Function Paper2D.PaperGroupedSpriteComponent.AddInstance
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10235534c
	// Return & Params: [ Num(5) Size(0x50) ]
	int32_t AddInstance(struct FTransform& Transform, struct UPaperSprite* Sprite, bool bWorldSpace, struct FLinearColor Color);
};

// Object: Class Paper2D.PaperRuntimeSettings
// Inherited Bytes: 0x28 | Struct Size: 0x30
struct UPaperRuntimeSettings : UObject {
	// Fields
	bool bEnableSpriteAtlasGroups; // Offset: 0x28 | Size: 0x1
	bool bEnableTerrainSplineEditing; // Offset: 0x29 | Size: 0x1
	bool bResizeSpriteDataToMatchTextures; // Offset: 0x2a | Size: 0x1
	char pad_0x2B[0x5]; // Offset: 0x2b | Size: 0x5
};

// Object: Class Paper2D.PaperSprite
// Inherited Bytes: 0x28 | Struct Size: 0xa8
struct UPaperSprite : UObject {
	// Fields
	char pad_0x28[0x10]; // Offset: 0x28 | Size: 0x10
	struct TArray<struct UTexture*> AdditionalSourceTextures; // Offset: 0x38 | Size: 0x10
	struct FVector2D BakedSourceUV; // Offset: 0x48 | Size: 0x8
	struct FVector2D BakedSourceDimension; // Offset: 0x50 | Size: 0x8
	struct UTexture2D* BakedSourceTexture; // Offset: 0x58 | Size: 0x8
	struct UMaterialInterface* DefaultMaterial; // Offset: 0x60 | Size: 0x8
	struct UMaterialInterface* AlternateMaterial; // Offset: 0x68 | Size: 0x8
	struct TArray<struct FPaperSpriteSocket> Sockets; // Offset: 0x70 | Size: 0x10
	enum class ESpriteCollisionMode SpriteCollisionDomain; // Offset: 0x80 | Size: 0x1
	char pad_0x81[0x3]; // Offset: 0x81 | Size: 0x3
	float PixelsPerUnrealUnit; // Offset: 0x84 | Size: 0x4
	struct UBodySetup* BodySetup; // Offset: 0x88 | Size: 0x8
	int32_t AlternateMaterialSplitIndex; // Offset: 0x90 | Size: 0x4
	char pad_0x94[0x4]; // Offset: 0x94 | Size: 0x4
	struct TArray<struct FVector4> BakedRenderData; // Offset: 0x98 | Size: 0x10
};

// Object: Class Paper2D.PaperSpriteActor
// Inherited Bytes: 0x228 | Struct Size: 0x230
struct APaperSpriteActor : AActor {
	// Fields
	struct UPaperSpriteComponent* RenderComponent; // Offset: 0x228 | Size: 0x8
};

// Object: Class Paper2D.PaperSpriteAtlas
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UPaperSpriteAtlas : UObject {
};

// Object: Class Paper2D.PaperSpriteBlueprintLibrary
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UPaperSpriteBlueprintLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object: Function Paper2D.PaperSpriteBlueprintLibrary.MakeBrushFromSprite
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1023563b4
	// Return & Params: [ Num(4) Size(0xf0) ]
	struct FSlateBrush MakeBrushFromSprite(struct UPaperSprite* Sprite, int32_t Width, int32_t Height);
};

// Object: Class Paper2D.PaperSpriteComponent
// Inherited Bytes: 0x5b0 | Struct Size: 0x5d0
struct UPaperSpriteComponent : UMeshComponent {
	// Fields
	struct UPaperSprite* SourceSprite; // Offset: 0x5a8 | Size: 0x8
	struct UMaterialInterface* MaterialOverride; // Offset: 0x5b0 | Size: 0x8
	struct FLinearColor SpriteColor; // Offset: 0x5b8 | Size: 0x10

	// Functions

	// Object: Function Paper2D.PaperSpriteComponent.SetSpriteColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x102356858
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetSpriteColor(struct FLinearColor NewColor);

	// Object: Function Paper2D.PaperSpriteComponent.SetSprite
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102356914
	// Return & Params: [ Num(2) Size(0x9) ]
	bool SetSprite(struct UPaperSprite* NewSprite);

	// Object: Function Paper2D.PaperSpriteComponent.GetSprite
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1023568d8
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UPaperSprite* GetSprite();
};

// Object: Class Paper2D.PaperTerrainActor
// Inherited Bytes: 0x228 | Struct Size: 0x240
struct APaperTerrainActor : AActor {
	// Fields
	struct USceneComponent* DummyRoot; // Offset: 0x228 | Size: 0x8
	struct UPaperTerrainSplineComponent* SplineComponent; // Offset: 0x230 | Size: 0x8
	struct UPaperTerrainComponent* RenderComponent; // Offset: 0x238 | Size: 0x8
};

// Object: Class Paper2D.PaperTerrainComponent
// Inherited Bytes: 0x570 | Struct Size: 0x5d0
struct UPaperTerrainComponent : UPrimitiveComponent {
	// Fields
	struct UPaperTerrainMaterial* TerrainMaterial; // Offset: 0x570 | Size: 0x8
	bool bClosedSpline; // Offset: 0x578 | Size: 0x1
	bool bFilledSpline; // Offset: 0x579 | Size: 0x1
	char pad_0x57A[0x6]; // Offset: 0x57a | Size: 0x6
	struct UPaperTerrainSplineComponent* AssociatedSpline; // Offset: 0x580 | Size: 0x8
	int32_t RandomSeed; // Offset: 0x588 | Size: 0x4
	float SegmentOverlapAmount; // Offset: 0x58c | Size: 0x4
	struct FLinearColor TerrainColor; // Offset: 0x590 | Size: 0x10
	int32_t ReparamStepsPerSegment; // Offset: 0x5a0 | Size: 0x4
	enum class ESpriteCollisionMode SpriteCollisionDomain; // Offset: 0x5a4 | Size: 0x1
	char pad_0x5A5[0x3]; // Offset: 0x5a5 | Size: 0x3
	float CollisionThickness; // Offset: 0x5a8 | Size: 0x4
	char pad_0x5AC[0x4]; // Offset: 0x5ac | Size: 0x4
	struct UBodySetup* CachedBodySetup; // Offset: 0x5b0 | Size: 0x8
	char pad_0x5B8[0x18]; // Offset: 0x5b8 | Size: 0x18

	// Functions

	// Object: Function Paper2D.PaperTerrainComponent.SetTerrainColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x102356fe8
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetTerrainColor(struct FLinearColor NewColor);
};

// Object: Class Paper2D.PaperTerrainMaterial
// Inherited Bytes: 0x30 | Struct Size: 0x48
struct UPaperTerrainMaterial : UDataAsset {
	// Fields
	struct TArray<struct FPaperTerrainMaterialRule> Rules; // Offset: 0x30 | Size: 0x10
	struct UPaperSprite* InteriorFill; // Offset: 0x40 | Size: 0x8
};

// Object: Class Paper2D.PaperTerrainSplineComponent
// Inherited Bytes: 0x660 | Struct Size: 0x670
struct UPaperTerrainSplineComponent : USplineComponent {
	// Fields
	char pad_0x660[0x10]; // Offset: 0x660 | Size: 0x10
};

// Object: Class Paper2D.PaperTileLayer
// Inherited Bytes: 0x28 | Struct Size: 0x98
struct UPaperTileLayer : UObject {
	// Fields
	struct FText LayerName; // Offset: 0x28 | Size: 0x18
	int32_t LayerWidth; // Offset: 0x40 | Size: 0x4
	int32_t LayerHeight; // Offset: 0x44 | Size: 0x4
	char bHiddenInGame : 1; // Offset: 0x48 | Size: 0x1
	char bLayerCollides : 1; // Offset: 0x48 | Size: 0x1
	char bOverrideCollisionThickness : 1; // Offset: 0x48 | Size: 0x1
	char bOverrideCollisionOffset : 1; // Offset: 0x48 | Size: 0x1
	char pad_0x48_4 : 4; // Offset: 0x48 | Size: 0x1
	char pad_0x49[0x3]; // Offset: 0x49 | Size: 0x3
	float CollisionThicknessOverride; // Offset: 0x4c | Size: 0x4
	float CollisionOffsetOverride; // Offset: 0x50 | Size: 0x4
	struct FLinearColor LayerColor; // Offset: 0x54 | Size: 0x10
	int32_t AllocatedWidth; // Offset: 0x64 | Size: 0x4
	int32_t AllocatedHeight; // Offset: 0x68 | Size: 0x4
	char pad_0x6C[0x4]; // Offset: 0x6c | Size: 0x4
	struct TArray<struct FPaperTileInfo> AllocatedCells; // Offset: 0x70 | Size: 0x10
	struct UPaperTileSet* TileSet; // Offset: 0x80 | Size: 0x8
	struct TArray<int32_t> AllocatedGrid; // Offset: 0x88 | Size: 0x10
};

// Object: Class Paper2D.PaperTileMap
// Inherited Bytes: 0x28 | Struct Size: 0xa8
struct UPaperTileMap : UObject {
	// Fields
	int32_t MapWidth; // Offset: 0x28 | Size: 0x4
	int32_t MapHeight; // Offset: 0x2c | Size: 0x4
	int32_t TileWidth; // Offset: 0x30 | Size: 0x4
	int32_t TileHeight; // Offset: 0x34 | Size: 0x4
	float PixelsPerUnrealUnit; // Offset: 0x38 | Size: 0x4
	float SeparationPerTileX; // Offset: 0x3c | Size: 0x4
	float SeparationPerTileY; // Offset: 0x40 | Size: 0x4
	float SeparationPerLayer; // Offset: 0x44 | Size: 0x4
	struct TSoftObjectPtr<UPaperTileSet> SelectedTileSet; // Offset: 0x48 | Size: 0x28
	struct UMaterialInterface* Material; // Offset: 0x70 | Size: 0x8
	struct TArray<struct UPaperTileLayer*> TileLayers; // Offset: 0x78 | Size: 0x10
	float CollisionThickness; // Offset: 0x88 | Size: 0x4
	enum class ESpriteCollisionMode SpriteCollisionDomain; // Offset: 0x8c | Size: 0x1
	enum class ETileMapProjectionMode ProjectionMode; // Offset: 0x8d | Size: 0x1
	char pad_0x8E[0x2]; // Offset: 0x8e | Size: 0x2
	int32_t HexSideLength; // Offset: 0x90 | Size: 0x4
	char pad_0x94[0x4]; // Offset: 0x94 | Size: 0x4
	struct UBodySetup* BodySetup; // Offset: 0x98 | Size: 0x8
	int32_t LayerNameIndex; // Offset: 0xa0 | Size: 0x4
	char pad_0xA4[0x4]; // Offset: 0xa4 | Size: 0x4
};

// Object: Class Paper2D.PaperTileMapActor
// Inherited Bytes: 0x228 | Struct Size: 0x230
struct APaperTileMapActor : AActor {
	// Fields
	struct UPaperTileMapComponent* RenderComponent; // Offset: 0x228 | Size: 0x8
};

// Object: Class Paper2D.PaperTileMapComponent
// Inherited Bytes: 0x5b0 | Struct Size: 0x600
struct UPaperTileMapComponent : UMeshComponent {
	// Fields
	int32_t MapWidth; // Offset: 0x5a4 | Size: 0x4
	int32_t MapHeight; // Offset: 0x5a8 | Size: 0x4
	int32_t TileWidth; // Offset: 0x5ac | Size: 0x4
	int32_t TileHeight; // Offset: 0x5b0 | Size: 0x4
	struct UPaperTileSet* DefaultLayerTileSet; // Offset: 0x5b8 | Size: 0x8
	struct UMaterialInterface* Material; // Offset: 0x5c0 | Size: 0x8
	struct TArray<struct UPaperTileLayer*> TileLayers; // Offset: 0x5c8 | Size: 0x10
	struct FLinearColor TileMapColor; // Offset: 0x5d8 | Size: 0x10
	int32_t UseSingleLayerIndex; // Offset: 0x5e8 | Size: 0x4
	bool bUseSingleLayer; // Offset: 0x5ec | Size: 0x1
	struct UPaperTileMap* TileMap; // Offset: 0x5f0 | Size: 0x8
	char pad_0x5FD[0x3]; // Offset: 0x5fd | Size: 0x3

	// Functions

	// Object: Function Paper2D.PaperTileMapComponent.SetTileMapColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x102358c30
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetTileMapColor(struct FLinearColor NewColor);

	// Object: Function Paper2D.PaperTileMapComponent.SetTileMap
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x1023591d0
	// Return & Params: [ Num(2) Size(0x9) ]
	bool SetTileMap(struct UPaperTileMap* NewTileMap);

	// Object: Function Paper2D.PaperTileMapComponent.SetTile
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102358dec
	// Return & Params: [ Num(4) Size(0x20) ]
	void SetTile(int32_t X, int32_t Y, int32_t Layer, struct FPaperTileInfo NewValue);

	// Object: Function Paper2D.PaperTileMapComponent.SetLayerColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x102358ac8
	// Return & Params: [ Num(2) Size(0x14) ]
	void SetLayerColor(struct FLinearColor NewColor, int32_t Layer);

	// Object: Function Paper2D.PaperTileMapComponent.SetLayerCollision
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1023582a4
	// Return & Params: [ Num(7) Size(0x15) ]
	void SetLayerCollision(int32_t Layer, bool bHasCollision, bool bOverrideThickness, float CustomThickness, bool bOverrideOffset, float CustomOffset, bool bRebuildCollision);

	// Object: Function Paper2D.PaperTileMapComponent.SetDefaultCollisionThickness
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102358528
	// Return & Params: [ Num(2) Size(0x5) ]
	void SetDefaultCollisionThickness(float Thickness, bool bRebuildCollision);

	// Object: Function Paper2D.PaperTileMapComponent.ResizeMap
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102358d24
	// Return & Params: [ Num(2) Size(0x8) ]
	void ResizeMap(int32_t NewWidthInTiles, int32_t NewHeightInTiles);

	// Object: Function Paper2D.PaperTileMapComponent.RebuildCollision
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102358290
	// Return & Params: [ Num(0) Size(0x0) ]
	void RebuildCollision();

	// Object: Function Paper2D.PaperTileMapComponent.OwnsTileMap
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102359268
	// Return & Params: [ Num(1) Size(0x1) ]
	bool OwnsTileMap();

	// Object: Function Paper2D.PaperTileMapComponent.MakeTileMapEditable
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102358ab4
	// Return & Params: [ Num(0) Size(0x0) ]
	void MakeTileMapEditable();

	// Object: Function Paper2D.PaperTileMapComponent.GetTilePolygon
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1023585fc
	// Return & Params: [ Num(5) Size(0x1d) ]
	void GetTilePolygon(int32_t TileX, int32_t TileY, struct TArray<struct FVector>& Points, int32_t LayerIndex, bool bWorldSpace);

	// Object: Function Paper2D.PaperTileMapComponent.GetTileMapColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102358cb0
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FLinearColor GetTileMapColor();

	// Object: Function Paper2D.PaperTileMapComponent.GetTileCornerPosition
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10235893c
	// Return & Params: [ Num(5) Size(0x1c) ]
	struct FVector GetTileCornerPosition(int32_t TileX, int32_t TileY, int32_t LayerIndex, bool bWorldSpace);

	// Object: Function Paper2D.PaperTileMapComponent.GetTileCenterPosition
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1023587c4
	// Return & Params: [ Num(5) Size(0x1c) ]
	struct FVector GetTileCenterPosition(int32_t TileX, int32_t TileY, int32_t LayerIndex, bool bWorldSpace);

	// Object: Function Paper2D.PaperTileMapComponent.GetTile
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102358f5c
	// Return & Params: [ Num(4) Size(0x20) ]
	struct FPaperTileInfo GetTile(int32_t X, int32_t Y, int32_t Layer);

	// Object: Function Paper2D.PaperTileMapComponent.GetMapSize
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102359084
	// Return & Params: [ Num(3) Size(0xc) ]
	void GetMapSize(int32_t& MapWidth, int32_t& MapHeight, int32_t& NumLayers);

	// Object: Function Paper2D.PaperTileMapComponent.GetLayerColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102358b94
	// Return & Params: [ Num(2) Size(0x14) ]
	struct FLinearColor GetLayerColor(int32_t Layer);

	// Object: Function Paper2D.PaperTileMapComponent.CreateNewTileMap
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10235929c
	// Return & Params: [ Num(6) Size(0x15) ]
	void CreateNewTileMap(int32_t MapWidth, int32_t MapHeight, int32_t TileWidth, int32_t TileHeight, float PixelsPerUnrealUnit, bool bCreateLayer);

	// Object: Function Paper2D.PaperTileMapComponent.AddNewLayer
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102358cf0
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UPaperTileLayer* AddNewLayer();
};

// Object: Class Paper2D.PaperTileSet
// Inherited Bytes: 0x28 | Struct Size: 0xa8
struct UPaperTileSet : UObject {
	// Fields
	struct FIntPoint TileSize; // Offset: 0x28 | Size: 0x8
	struct UTexture2D* TileSheet; // Offset: 0x30 | Size: 0x8
	struct TArray<struct UTexture*> AdditionalSourceTextures; // Offset: 0x38 | Size: 0x10
	struct FIntMargin BorderMargin; // Offset: 0x48 | Size: 0x10
	struct FIntPoint PerTileSpacing; // Offset: 0x58 | Size: 0x8
	struct FIntPoint DrawingOffset; // Offset: 0x60 | Size: 0x8
	int32_t WidthInTiles; // Offset: 0x68 | Size: 0x4
	int32_t HeightInTiles; // Offset: 0x6c | Size: 0x4
	int32_t AllocatedWidth; // Offset: 0x70 | Size: 0x4
	int32_t AllocatedHeight; // Offset: 0x74 | Size: 0x4
	struct TArray<struct FPaperTileMetadata> PerTileData; // Offset: 0x78 | Size: 0x10
	struct TArray<struct FPaperTileSetTerrain> Terrains; // Offset: 0x88 | Size: 0x10
	int32_t TileWidth; // Offset: 0x98 | Size: 0x4
	int32_t TileHeight; // Offset: 0x9c | Size: 0x4
	int32_t Margin; // Offset: 0xa0 | Size: 0x4
	int32_t Spacing; // Offset: 0xa4 | Size: 0x4
};

// Object: Class Paper2D.TileMapBlueprintLibrary
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UTileMapBlueprintLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object: Function Paper2D.TileMapBlueprintLibrary.MakeTile
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x10235a728
	// Return & Params: [ Num(6) Size(0x28) ]
	struct FPaperTileInfo MakeTile(int32_t TileIndex, struct UPaperTileSet* TileSet, bool bFlipH, bool bFlipV, bool bFlipD);

	// Object: Function Paper2D.TileMapBlueprintLibrary.GetTileUserData
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x10235ac20
	// Return & Params: [ Num(2) Size(0x18) ]
	struct FName GetTileUserData(struct FPaperTileInfo Tile);

	// Object: Function Paper2D.TileMapBlueprintLibrary.GetTileTransform
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x10235ab5c
	// Return & Params: [ Num(2) Size(0x40) ]
	struct FTransform GetTileTransform(struct FPaperTileInfo Tile);

	// Object: Function Paper2D.TileMapBlueprintLibrary.BreakTile
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x10235a904
	// Return & Params: [ Num(6) Size(0x23) ]
	void BreakTile(struct FPaperTileInfo Tile, int32_t& TileIndex, struct UPaperTileSet*& TileSet, bool& bFlipH, bool& bFlipV, bool& bFlipD);
};

