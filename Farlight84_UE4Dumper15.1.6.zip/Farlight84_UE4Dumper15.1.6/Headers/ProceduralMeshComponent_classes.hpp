#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class ProceduralMeshComponent.KismetProceduralMeshLibrary
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UKismetProceduralMeshLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object: Function ProceduralMeshComponent.KismetProceduralMeshLibrary.SliceProceduralMesh
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1013f8748
	// Return & Params: [ Num(7) Size(0x40) ]
	void SliceProceduralMesh(struct UProceduralMeshComponent* InProcMesh, struct FVector PlanePosition, struct FVector PlaneNormal, bool bCreateOtherHalf, struct UProceduralMeshComponent*& OutOtherHalfProcMesh, enum class EProcMeshSliceCapOption CapOption, struct UMaterialInterface* CapMaterial);

	// Object: Function ProceduralMeshComponent.KismetProceduralMeshLibrary.GetSectionFromStaticMesh
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1013f8db0
	// Return & Params: [ Num(8) Size(0x60) ]
	void GetSectionFromStaticMesh(struct UStaticMesh* InMesh, int32_t LODIndex, int32_t SectionIndex, struct TArray<struct FVector>& Vertices, struct TArray<int32_t>& Triangles, struct TArray<struct FVector>& Normals, struct TArray<struct FVector2D>& UVs, struct TArray<struct FProcMeshTangent>& Tangents);

	// Object: Function ProceduralMeshComponent.KismetProceduralMeshLibrary.GetSectionFromProceduralMesh
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1013f89a4
	// Return & Params: [ Num(7) Size(0x60) ]
	void GetSectionFromProceduralMesh(struct UProceduralMeshComponent* InProcMesh, int32_t SectionIndex, struct TArray<struct FVector>& Vertices, struct TArray<int32_t>& Triangles, struct TArray<struct FVector>& Normals, struct TArray<struct FVector2D>& UVs, struct TArray<struct FProcMeshTangent>& Tangents);

	// Object: Function ProceduralMeshComponent.KismetProceduralMeshLibrary.GenerateBoxMesh
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1013f9a94
	// Return & Params: [ Num(6) Size(0x60) ]
	void GenerateBoxMesh(struct FVector BoxRadius, struct TArray<struct FVector>& Vertices, struct TArray<int32_t>& Triangles, struct TArray<struct FVector>& Normals, struct TArray<struct FVector2D>& UVs, struct TArray<struct FProcMeshTangent>& Tangents);

	// Object: Function ProceduralMeshComponent.KismetProceduralMeshLibrary.CreateGridMeshWelded
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1013f932c
	// Return & Params: [ Num(6) Size(0x3c) ]
	void CreateGridMeshWelded(int32_t NumX, int32_t NumY, struct TArray<int32_t>& Triangles, struct TArray<struct FVector>& Vertices, struct TArray<struct FVector2D>& UVs, float GridSpacing);

	// Object: Function ProceduralMeshComponent.KismetProceduralMeshLibrary.CreateGridMeshTriangles
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1013f9554
	// Return & Params: [ Num(4) Size(0x20) ]
	void CreateGridMeshTriangles(int32_t NumX, int32_t NumY, bool bWinding, struct TArray<int32_t>& Triangles);

	// Object: Function ProceduralMeshComponent.KismetProceduralMeshLibrary.CreateGridMeshSplit
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1013f90a0
	// Return & Params: [ Num(7) Size(0x4c) ]
	void CreateGridMeshSplit(int32_t NumX, int32_t NumY, struct TArray<int32_t>& Triangles, struct TArray<struct FVector>& Vertices, struct TArray<struct FVector2D>& UVs, struct TArray<struct FVector2D>& UV1s, float GridSpacing);

	// Object: Function ProceduralMeshComponent.KismetProceduralMeshLibrary.CopyProceduralMeshFromStaticMeshComponent
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1013f8c4c
	// Return & Params: [ Num(4) Size(0x19) ]
	void CopyProceduralMeshFromStaticMeshComponent(struct UStaticMeshComponent* StaticMeshComponent, int32_t LODIndex, struct UProceduralMeshComponent* ProcMeshComponent, bool bCreateCollision);

	// Object: Function ProceduralMeshComponent.KismetProceduralMeshLibrary.ConvertQuadToTriangles
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1013f96d4
	// Return & Params: [ Num(5) Size(0x20) ]
	void ConvertQuadToTriangles(struct TArray<int32_t>& Triangles, int32_t Vert0, int32_t Vert1, int32_t Vert2, int32_t Vert3);

	// Object: Function ProceduralMeshComponent.KismetProceduralMeshLibrary.CalculateTangentsForMesh
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1013f9884
	// Return & Params: [ Num(5) Size(0x50) ]
	void CalculateTangentsForMesh(struct TArray<struct FVector>& Vertices, struct TArray<int32_t>& Triangles, struct TArray<struct FVector2D>& UVs, struct TArray<struct FVector>& Normals, struct TArray<struct FProcMeshTangent>& Tangents);
};

// Object: Class ProceduralMeshComponent.ProceduralMeshComponent
// Inherited Bytes: 0x5b0 | Struct Size: 0x610
struct UProceduralMeshComponent : UMeshComponent {
	// Fields
	bool bUseComplexAsSimpleCollision; // Offset: 0x5b0 | Size: 0x1
	bool bUseAsyncCooking; // Offset: 0x5b1 | Size: 0x1
	char pad_0x5B2[0x6]; // Offset: 0x5b2 | Size: 0x6
	struct UBodySetup* ProcMeshBodySetup; // Offset: 0x5b8 | Size: 0x8
	struct TArray<struct FProcMeshSection> ProcMeshSections; // Offset: 0x5c0 | Size: 0x10
	struct TArray<struct FKConvexElem> CollisionConvexElems; // Offset: 0x5d0 | Size: 0x10
	struct FBoxSphereBounds LocalBounds; // Offset: 0x5e0 | Size: 0x1c
	char pad_0x5FC[0x4]; // Offset: 0x5fc | Size: 0x4
	struct TArray<struct UBodySetup*> AsyncBodySetupQueue; // Offset: 0x600 | Size: 0x10

	// Functions

	// Object: Function ProceduralMeshComponent.ProceduralMeshComponent.UpdateMeshSection_LinearColor
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1013fa8f8
	// Return & Params: [ Num(9) Size(0x88) ]
	void UpdateMeshSection_LinearColor(int32_t SectionIndex, struct TArray<struct FVector>& Vertices, struct TArray<struct FVector>& Normals, struct TArray<struct FVector2D>& UV0, struct TArray<struct FVector2D>& UV1, struct TArray<struct FVector2D>& UV2, struct TArray<struct FVector2D>& UV3, struct TArray<struct FLinearColor>& VertexColors, struct TArray<struct FProcMeshTangent>& Tangents);

	// Object: Function ProceduralMeshComponent.ProceduralMeshComponent.UpdateMeshSection
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1013fac80
	// Return & Params: [ Num(6) Size(0x58) ]
	void UpdateMeshSection(int32_t SectionIndex, struct TArray<struct FVector>& Vertices, struct TArray<struct FVector>& Normals, struct TArray<struct FVector2D>& UV0, struct TArray<struct FColor>& VertexColors, struct TArray<struct FProcMeshTangent>& Tangents);

	// Object: Function ProceduralMeshComponent.ProceduralMeshComponent.SetMeshSectionVisible
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1013fa794
	// Return & Params: [ Num(2) Size(0x5) ]
	void SetMeshSectionVisible(int32_t SectionIndex, bool bNewVisibility);

	// Object: Function ProceduralMeshComponent.ProceduralMeshComponent.IsMeshSectionVisible
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1013fa704
	// Return & Params: [ Num(2) Size(0x5) ]
	bool IsMeshSectionVisible(int32_t SectionIndex);

	// Object: Function ProceduralMeshComponent.ProceduralMeshComponent.GetNumSections
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1013fa6d0
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetNumSections();

	// Object: Function ProceduralMeshComponent.ProceduralMeshComponent.CreateMeshSection_LinearColor
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1013faf00
	// Return & Params: [ Num(11) Size(0x99) ]
	void CreateMeshSection_LinearColor(int32_t SectionIndex, struct TArray<struct FVector>& Vertices, struct TArray<int32_t>& Triangles, struct TArray<struct FVector>& Normals, struct TArray<struct FVector2D>& UV0, struct TArray<struct FVector2D>& UV1, struct TArray<struct FVector2D>& UV2, struct TArray<struct FVector2D>& UV3, struct TArray<struct FLinearColor>& VertexColors, struct TArray<struct FProcMeshTangent>& Tangents, bool bCreateCollision);

	// Object: Function ProceduralMeshComponent.ProceduralMeshComponent.CreateMeshSection
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1013fb338
	// Return & Params: [ Num(8) Size(0x69) ]
	void CreateMeshSection(int32_t SectionIndex, struct TArray<struct FVector>& Vertices, struct TArray<int32_t>& Triangles, struct TArray<struct FVector>& Normals, struct TArray<struct FVector2D>& UV0, struct TArray<struct FColor>& VertexColors, struct TArray<struct FProcMeshTangent>& Tangents, bool bCreateCollision);

	// Object: Function ProceduralMeshComponent.ProceduralMeshComponent.ClearMeshSection
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1013fa878
	// Return & Params: [ Num(1) Size(0x4) ]
	void ClearMeshSection(int32_t SectionIndex);

	// Object: Function ProceduralMeshComponent.ProceduralMeshComponent.ClearCollisionConvexMeshes
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1013fa5c8
	// Return & Params: [ Num(0) Size(0x0) ]
	void ClearCollisionConvexMeshes();

	// Object: Function ProceduralMeshComponent.ProceduralMeshComponent.ClearAllMeshSections
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1013fa864
	// Return & Params: [ Num(0) Size(0x0) ]
	void ClearAllMeshSections();

	// Object: Function ProceduralMeshComponent.ProceduralMeshComponent.AddCollisionConvexMesh
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1013fa5dc
	// Return & Params: [ Num(1) Size(0x10) ]
	void AddCollisionConvexMesh(struct TArray<struct FVector> ConvexVerts);
};

