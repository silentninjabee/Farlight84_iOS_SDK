#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct ProceduralMeshComponent.ProcMeshSection
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FProcMeshSection {
	// Fields
	struct TArray<struct FProcMeshVertex> ProcVertexBuffer; // Offset: 0x0 | Size: 0x10
	struct TArray<uint32_t> ProcIndexBuffer; // Offset: 0x10 | Size: 0x10
	struct FBox SectionLocalBox; // Offset: 0x20 | Size: 0x1c
	bool bEnableCollision; // Offset: 0x3c | Size: 0x1
	bool bSectionVisible; // Offset: 0x3d | Size: 0x1
	char pad_0x3E[0x2]; // Offset: 0x3e | Size: 0x2
};

// Object: ScriptStruct ProceduralMeshComponent.ProcMeshVertex
// Inherited Bytes: 0x0 | Struct Size: 0x4c
struct FProcMeshVertex {
	// Fields
	struct FVector Position; // Offset: 0x0 | Size: 0xc
	struct FVector Normal; // Offset: 0xc | Size: 0xc
	struct FProcMeshTangent Tangent; // Offset: 0x18 | Size: 0x10
	struct FColor Color; // Offset: 0x28 | Size: 0x4
	struct FVector2D UV0; // Offset: 0x2c | Size: 0x8
	struct FVector2D UV1; // Offset: 0x34 | Size: 0x8
	struct FVector2D UV2; // Offset: 0x3c | Size: 0x8
	struct FVector2D UV3; // Offset: 0x44 | Size: 0x8
};

// Object: ScriptStruct ProceduralMeshComponent.ProcMeshTangent
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FProcMeshTangent {
	// Fields
	struct FVector TangentX; // Offset: 0x0 | Size: 0xc
	bool bFlipTangentY; // Offset: 0xc | Size: 0x1
	char pad_0xD[0x3]; // Offset: 0xd | Size: 0x3
};

