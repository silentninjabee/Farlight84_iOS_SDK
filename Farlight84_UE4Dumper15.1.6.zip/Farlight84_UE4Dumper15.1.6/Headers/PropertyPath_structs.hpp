#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct PropertyPath.CachedPropertyPath
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FCachedPropertyPath {
	// Fields
	struct TArray<struct FPropertyPathSegment> Segments; // Offset: 0x0 | Size: 0x10
	char pad_0x10[0x8]; // Offset: 0x10 | Size: 0x8
	struct UFunction* CachedFunction; // Offset: 0x18 | Size: 0x8
	char pad_0x20[0x8]; // Offset: 0x20 | Size: 0x8
};

// Object: ScriptStruct PropertyPath.PropertyPathSegment
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FPropertyPathSegment {
	// Fields
	struct FName Name; // Offset: 0x0 | Size: 0x8
	int32_t ArrayIndex; // Offset: 0x8 | Size: 0x4
	char pad_0xC[0x4]; // Offset: 0xc | Size: 0x4
	struct UStruct* Struct; // Offset: 0x10 | Size: 0x8
	char pad_0x18[0x10]; // Offset: 0x18 | Size: 0x10
};

