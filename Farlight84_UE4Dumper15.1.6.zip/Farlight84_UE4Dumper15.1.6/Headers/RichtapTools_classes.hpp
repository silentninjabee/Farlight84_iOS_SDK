#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class RichtapTools.RichtapController
// Inherited Bytes: 0x28 | Struct Size: 0x90
struct URichtapController : UObject {
	// Fields
	char pad_0x28[0x18]; // Offset: 0x28 | Size: 0x18
	struct TMap<struct FString, struct URichtapClip*> HeDataMap; // Offset: 0x40 | Size: 0x50

	// Functions

	// Object: Function RichtapTools.RichtapController.SetRichtapEnable
	// Flags: [Final|Native|Public]
	// Offset: 0x10166eb60
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetRichtapEnable(bool On);

	// Object: Function RichtapTools.RichtapController.SetEnableWinRichtap
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10166ea60
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetEnableWinRichtap(bool bIsEnableWinRichtap);

	// Object: Function RichtapTools.RichtapController.SetEnableRichtap
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10166eae0
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetEnableRichtap(bool bIsEnableRichtap);
};

