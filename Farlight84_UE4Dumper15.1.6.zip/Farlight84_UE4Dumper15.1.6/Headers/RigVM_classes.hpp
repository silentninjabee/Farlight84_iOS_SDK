#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class RigVM.RigVM
// Inherited Bytes: 0x28 | Struct Size: 0x240
struct URigVM : UObject {
	// Fields
	struct FRigVMMemoryContainer WorkMemory; // Offset: 0x28 | Size: 0xa0
	struct FRigVMMemoryContainer LiteralMemory; // Offset: 0xc8 | Size: 0xa0
	struct FRigVMByteCode ByteCode; // Offset: 0x168 | Size: 0x10
	struct FRigVMInstructionArray Instructions; // Offset: 0x178 | Size: 0x10
	struct TArray<struct FName> FunctionNames; // Offset: 0x188 | Size: 0x10
	char pad_0x198[0x10]; // Offset: 0x198 | Size: 0x10
	struct TArray<struct FRigVMParameter> Parameters; // Offset: 0x1a8 | Size: 0x10
	struct TMap<struct FName, int32_t> ParametersNameMap; // Offset: 0x1b8 | Size: 0x50
	char pad_0x208[0x38]; // Offset: 0x208 | Size: 0x38

	// Functions

	// Object: Function RigVM.RigVM.SetParameterValueVector2D
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x105921e68
	// Return & Params: [ Num(3) Size(0x14) ]
	void SetParameterValueVector2D(struct FName& InParameterName, struct FVector2D& InValue, int32_t InArrayIndex);

	// Object: Function RigVM.RigVM.SetParameterValueVector
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x105921c78
	// Return & Params: [ Num(3) Size(0x18) ]
	void SetParameterValueVector(struct FName& InParameterName, struct FVector& InValue, int32_t InArrayIndex);

	// Object: Function RigVM.RigVM.SetParameterValueTransform
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x105921850
	// Return & Params: [ Num(3) Size(0x44) ]
	void SetParameterValueTransform(struct FName& InParameterName, struct FTransform& InValue, int32_t InArrayIndex);

	// Object: Function RigVM.RigVM.SetParameterValueString
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105922030
	// Return & Params: [ Num(3) Size(0x1c) ]
	void SetParameterValueString(struct FName& InParameterName, struct FString InValue, int32_t InArrayIndex);

	// Object: Function RigVM.RigVM.SetParameterValueQuat
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x105921a98
	// Return & Params: [ Num(3) Size(0x24) ]
	void SetParameterValueQuat(struct FName& InParameterName, struct FQuat& InValue, int32_t InArrayIndex);

	// Object: Function RigVM.RigVM.SetParameterValueName
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105922160
	// Return & Params: [ Num(3) Size(0x14) ]
	void SetParameterValueName(struct FName& InParameterName, struct FName& InValue, int32_t InArrayIndex);

	// Object: Function RigVM.RigVM.SetParameterValueInt
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10592232c
	// Return & Params: [ Num(3) Size(0x10) ]
	void SetParameterValueInt(struct FName& InParameterName, int32_t InValue, int32_t InArrayIndex);

	// Object: Function RigVM.RigVM.SetParameterValueFloat
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1059224f4
	// Return & Params: [ Num(3) Size(0x10) ]
	void SetParameterValueFloat(struct FName& InParameterName, float InValue, int32_t InArrayIndex);

	// Object: Function RigVM.RigVM.SetParameterValueBool
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1059226bc
	// Return & Params: [ Num(3) Size(0x10) ]
	void SetParameterValueBool(struct FName& InParameterName, bool InValue, int32_t InArrayIndex);

	// Object: Function RigVM.RigVM.GetRigVMFunctionName
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x105923828
	// Return & Params: [ Num(2) Size(0x18) ]
	struct FString GetRigVMFunctionName(int32_t InFunctionIndex);

	// Object: Function RigVM.RigVM.GetParameterValueVector2D
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x105922dec
	// Return & Params: [ Num(3) Size(0x14) ]
	struct FVector2D GetParameterValueVector2D(struct FName& InParameterName, int32_t InArrayIndex);

	// Object: Function RigVM.RigVM.GetParameterValueVector
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x105922c40
	// Return & Params: [ Num(3) Size(0x18) ]
	struct FVector GetParameterValueVector(struct FName& InParameterName, int32_t InArrayIndex);

	// Object: Function RigVM.RigVM.GetParameterValueTransform
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x105922890
	// Return & Params: [ Num(3) Size(0x40) ]
	struct FTransform GetParameterValueTransform(struct FName& InParameterName, int32_t InArrayIndex);

	// Object: Function RigVM.RigVM.GetParameterValueString
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105922f84
	// Return & Params: [ Num(3) Size(0x20) ]
	struct FString GetParameterValueString(struct FName& InParameterName, int32_t InArrayIndex);

	// Object: Function RigVM.RigVM.GetParameterValueQuat
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x105922aa8
	// Return & Params: [ Num(3) Size(0x20) ]
	struct FQuat GetParameterValueQuat(struct FName& InParameterName, int32_t InArrayIndex);

	// Object: Function RigVM.RigVM.GetParameterValueName
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1059230c0
	// Return & Params: [ Num(3) Size(0x14) ]
	struct FName GetParameterValueName(struct FName& InParameterName, int32_t InArrayIndex);

	// Object: Function RigVM.RigVM.GetParameterValueInt
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10592324c
	// Return & Params: [ Num(3) Size(0x10) ]
	int32_t GetParameterValueInt(struct FName& InParameterName, int32_t InArrayIndex);

	// Object: Function RigVM.RigVM.GetParameterValueFloat
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1059233d8
	// Return & Params: [ Num(3) Size(0x10) ]
	float GetParameterValueFloat(struct FName& InParameterName, int32_t InArrayIndex);

	// Object: Function RigVM.RigVM.GetParameterValueBool
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105923564
	// Return & Params: [ Num(3) Size(0xd) ]
	bool GetParameterValueBool(struct FName& InParameterName, int32_t InArrayIndex);

	// Object: Function RigVM.RigVM.GetParameterArraySize
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1059236f8
	// Return & Params: [ Num(2) Size(0xc) ]
	int32_t GetParameterArraySize(struct FName& InParameterName);

	// Object: Function RigVM.RigVM.Execute
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1059239e8
	// Return & Params: [ Num(1) Size(0x1) ]
	bool Execute();

	// Object: Function RigVM.RigVM.AddRigVMFunction
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x105923900
	// Return & Params: [ Num(3) Size(0x14) ]
	int32_t AddRigVMFunction(struct UScriptStruct* InRigVMStruct, struct FName& InMethodName);
};

