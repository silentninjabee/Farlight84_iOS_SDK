#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct RigVM.RigVMExecuteContext
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FRigVMExecuteContext {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct RigVM.RigVMStruct
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FRigVMStruct {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
};

// Object: ScriptStruct RigVM.RigVMParameter
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FRigVMParameter {
	// Fields
	enum class ERigVMParameterType Type; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	struct FName Name; // Offset: 0x4 | Size: 0x8
	int32_t RegisterIndex; // Offset: 0xc | Size: 0x4
	struct FString CPPType; // Offset: 0x10 | Size: 0x10
	struct UScriptStruct* ScriptStruct; // Offset: 0x20 | Size: 0x8
	struct FName ScriptStructPath; // Offset: 0x28 | Size: 0x8
};

// Object: ScriptStruct RigVM.RigVMByteCode
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FRigVMByteCode {
	// Fields
	struct TArray<char> ByteCode; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct RigVM.RigVMInstructionArray
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FRigVMInstructionArray {
	// Fields
	struct TArray<struct FRigVMInstruction> Instructions; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct RigVM.RigVMInstruction
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FRigVMInstruction {
	// Fields
	enum class ERigVMOpCode OpCode; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x7]; // Offset: 0x1 | Size: 0x7
	uint64_t ByteCodeIndex; // Offset: 0x8 | Size: 0x8
};

// Object: ScriptStruct RigVM.RigVMMemoryContainer
// Inherited Bytes: 0x0 | Struct Size: 0xa0
struct FRigVMMemoryContainer {
	// Fields
	bool bUseNameMap; // Offset: 0x0 | Size: 0x1
	enum class ERigVMMemoryType MemoryType; // Offset: 0x1 | Size: 0x1
	char pad_0x2[0x6]; // Offset: 0x2 | Size: 0x6
	struct TArray<struct FRigVMRegister> Registers; // Offset: 0x8 | Size: 0x10
	struct TArray<struct FRigVMRegisterOffset> RegisterOffsets; // Offset: 0x18 | Size: 0x10
	struct TArray<char> Data; // Offset: 0x28 | Size: 0x10
	struct TArray<struct UScriptStruct*> ScriptStructs; // Offset: 0x38 | Size: 0x10
	struct TMap<struct FName, int32_t> NameMap; // Offset: 0x48 | Size: 0x50
	bool bEncounteredErrorDuringLoad; // Offset: 0x98 | Size: 0x1
	char pad_0x99[0x7]; // Offset: 0x99 | Size: 0x7
};

// Object: ScriptStruct RigVM.RigVMRegisterOffset
// Inherited Bytes: 0x0 | Struct Size: 0x38
struct FRigVMRegisterOffset {
	// Fields
	struct TArray<int32_t> Segments; // Offset: 0x0 | Size: 0x10
	enum class ERigVMRegisterType Type; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x3]; // Offset: 0x11 | Size: 0x3
	struct FName CPPType; // Offset: 0x14 | Size: 0x8
	char pad_0x1C[0x4]; // Offset: 0x1c | Size: 0x4
	struct UScriptStruct* ScriptStruct; // Offset: 0x20 | Size: 0x8
	struct FName ScriptStructPath; // Offset: 0x28 | Size: 0x8
	uint16_t ElementSize; // Offset: 0x30 | Size: 0x2
	char pad_0x32[0x6]; // Offset: 0x32 | Size: 0x6
};

// Object: ScriptStruct RigVM.RigVMRegister
// Inherited Bytes: 0x0 | Struct Size: 0x24
struct FRigVMRegister {
	// Fields
	enum class ERigVMRegisterType Type; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	uint32_t ByteIndex; // Offset: 0x4 | Size: 0x4
	uint16_t ElementSize; // Offset: 0x8 | Size: 0x2
	uint16_t ElementCount; // Offset: 0xa | Size: 0x2
	uint16_t SliceIndex; // Offset: 0xc | Size: 0x2
	uint16_t SliceCount; // Offset: 0xe | Size: 0x2
	char AlignmentBytes; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x1]; // Offset: 0x11 | Size: 0x1
	uint16_t TrailingBytes; // Offset: 0x12 | Size: 0x2
	struct FName Name; // Offset: 0x14 | Size: 0x8
	int32_t ScriptStructIndex; // Offset: 0x1c | Size: 0x4
	bool bIsArray; // Offset: 0x20 | Size: 0x1
	char pad_0x21[0x3]; // Offset: 0x21 | Size: 0x3
};

// Object: ScriptStruct RigVM.RigVMOperand
// Inherited Bytes: 0x0 | Struct Size: 0x6
struct FRigVMOperand {
	// Fields
	enum class ERigVMMemoryType MemoryType; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x1]; // Offset: 0x1 | Size: 0x1
	uint16_t RegisterIndex; // Offset: 0x2 | Size: 0x2
	uint16_t RegisterOffset; // Offset: 0x4 | Size: 0x2
};

// Object: ScriptStruct RigVM.RigVMStatistics
// Inherited Bytes: 0x0 | Struct Size: 0x2c
struct FRigVMStatistics {
	// Fields
	uint32_t BytesForCDO; // Offset: 0x0 | Size: 0x4
	uint32_t BytesPerInstance; // Offset: 0x4 | Size: 0x4
	struct FRigVMMemoryStatistics LiteralMemory; // Offset: 0x8 | Size: 0xc
	struct FRigVMMemoryStatistics WorkMemory; // Offset: 0x14 | Size: 0xc
	uint32_t BytesForCaching; // Offset: 0x20 | Size: 0x4
	struct FRigVMByteCodeStatistics ByteCode; // Offset: 0x24 | Size: 0x8
};

// Object: ScriptStruct RigVM.RigVMByteCodeStatistics
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FRigVMByteCodeStatistics {
	// Fields
	uint32_t InstructionCount; // Offset: 0x0 | Size: 0x4
	uint32_t DataBytes; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct RigVM.RigVMMemoryStatistics
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FRigVMMemoryStatistics {
	// Fields
	uint32_t RegisterCount; // Offset: 0x0 | Size: 0x4
	uint32_t DataBytes; // Offset: 0x4 | Size: 0x4
	uint32_t TotalBytes; // Offset: 0x8 | Size: 0x4
};

