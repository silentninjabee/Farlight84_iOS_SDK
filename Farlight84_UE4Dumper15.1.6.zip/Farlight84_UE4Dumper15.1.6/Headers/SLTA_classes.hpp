#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class SLTA.SLTA_BPL
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct USLTA_BPL : UObject {
	// Functions

	// Object: Function SLTA.SLTA_BPL.WriteTxt
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1023d1a70
	// Return & Params: [ Num(3) Size(0x21) ]
	bool WriteTxt(struct FString saveString, struct FString Path);

	// Object: Function SLTA.SLTA_BPL.SLTA_SetDetailMode
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1023d1da8
	// Return & Params: [ Num(1) Size(0x8) ]
	void SLTA_SetDetailMode(struct USceneComponent* _sceneComponent);

	// Object: Function SLTA.SLTA_BPL.SLTA_GetPrimitivesRHI
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1023d1d40
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t SLTA_GetPrimitivesRHI();

	// Object: Function SLTA.SLTA_BPL.SLTA_GetLightMapIndex
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1023d2354
	// Return & Params: [ Num(2) Size(0xc) ]
	int32_t SLTA_GetLightMapIndex(struct UStaticMeshComponent* _ustaticMeshComponent);

	// Object: Function SLTA.SLTA_BPL.SLTA_GetLightMapCoordinateBias
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x1023d23d4
	// Return & Params: [ Num(2) Size(0x20) ]
	struct FVector4 SLTA_GetLightMapCoordinateBias(struct UStaticMeshComponent* _ustaticMeshComponent);

	// Object: Function SLTA.SLTA_BPL.SLTA_GetDrawcalls
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1023d1d74
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t SLTA_GetDrawcalls();

	// Object: Function SLTA.SLTA_BPL.SLTA_GetCustomPrimitiveData
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1023d2270
	// Return & Params: [ Num(2) Size(0x18) ]
	struct TArray<float> SLTA_GetCustomPrimitiveData(struct UPrimitiveComponent* _primitive);

	// Object: Function SLTA.SLTA_BPL.SLTA_ArrayToCSV
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1023d1e20
	// Return & Params: [ Num(7) Size(0x46) ]
	bool SLTA_ArrayToCSV(struct FString SaveDirectory, struct FString Filename, struct FString TitleName, struct TArray<struct FString> SaveText, int32_t ArrayIndex, bool AllowOverwriting);

	// Object: Function SLTA.SLTA_BPL.ReadTxt
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1023d1c14
	// Return & Params: [ Num(2) Size(0x20) ]
	struct FString ReadTxt(struct FString Path);
};

