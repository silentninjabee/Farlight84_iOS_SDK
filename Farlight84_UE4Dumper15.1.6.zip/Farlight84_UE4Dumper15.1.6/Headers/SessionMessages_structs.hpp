#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct SessionMessages.SessionServiceLogUnsubscribe
// Inherited Bytes: 0x0 | Struct Size: 0x1
struct FSessionServiceLogUnsubscribe {
	// Fields
	char pad_0x0[0x1]; // Offset: 0x0 | Size: 0x1
};

// Object: ScriptStruct SessionMessages.SessionServiceLogSubscribe
// Inherited Bytes: 0x0 | Struct Size: 0x1
struct FSessionServiceLogSubscribe {
	// Fields
	char pad_0x0[0x1]; // Offset: 0x0 | Size: 0x1
};

// Object: ScriptStruct SessionMessages.SessionServiceLog
// Inherited Bytes: 0x0 | Struct Size: 0x38
struct FSessionServiceLog {
	// Fields
	struct FName Category; // Offset: 0x0 | Size: 0x8
	struct FString Data; // Offset: 0x8 | Size: 0x10
	struct FGuid instanceID; // Offset: 0x18 | Size: 0x10
	double TimeSeconds; // Offset: 0x28 | Size: 0x8
	char Verbosity; // Offset: 0x30 | Size: 0x1
	char pad_0x31[0x7]; // Offset: 0x31 | Size: 0x7
};

// Object: ScriptStruct SessionMessages.SessionServicePong
// Inherited Bytes: 0x0 | Struct Size: 0x90
struct FSessionServicePong {
	// Fields
	bool Authorized; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x7]; // Offset: 0x1 | Size: 0x7
	struct FString BuildDate; // Offset: 0x8 | Size: 0x10
	struct FString DeviceName; // Offset: 0x18 | Size: 0x10
	struct FGuid instanceID; // Offset: 0x28 | Size: 0x10
	struct FString InstanceName; // Offset: 0x38 | Size: 0x10
	struct FString PlatformName; // Offset: 0x48 | Size: 0x10
	struct FGuid SessionId; // Offset: 0x58 | Size: 0x10
	struct FString SessionName; // Offset: 0x68 | Size: 0x10
	struct FString SessionOwner; // Offset: 0x78 | Size: 0x10
	bool Standalone; // Offset: 0x88 | Size: 0x1
	char pad_0x89[0x7]; // Offset: 0x89 | Size: 0x7
};

// Object: ScriptStruct SessionMessages.SessionServicePing
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FSessionServicePing {
	// Fields
	struct FString UserName; // Offset: 0x0 | Size: 0x10
};

