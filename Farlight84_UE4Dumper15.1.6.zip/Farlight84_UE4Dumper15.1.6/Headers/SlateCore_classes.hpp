#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class SlateCore.FontBulkData
// Inherited Bytes: 0x28 | Struct Size: 0x88
struct UFontBulkData : UObject {
	// Fields
	char pad_0x28[0x60]; // Offset: 0x28 | Size: 0x60
};

// Object: Class SlateCore.FontFaceInterface
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UFontFaceInterface : UInterface {
};

// Object: Class SlateCore.FontProviderInterface
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UFontProviderInterface : UInterface {
};

// Object: Class SlateCore.SlateTypes
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct USlateTypes : UObject {
};

// Object: Class SlateCore.SlateWidgetStyleAsset
// Inherited Bytes: 0x28 | Struct Size: 0x30
struct USlateWidgetStyleAsset : UObject {
	// Fields
	struct USlateWidgetStyleContainerBase* CustomStyle; // Offset: 0x28 | Size: 0x8
};

// Object: Class SlateCore.SlateWidgetStyleContainerBase
// Inherited Bytes: 0x28 | Struct Size: 0x30
struct USlateWidgetStyleContainerBase : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
};

// Object: Class SlateCore.SlateWidgetStyleContainerInterface
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct USlateWidgetStyleContainerInterface : UInterface {
};

