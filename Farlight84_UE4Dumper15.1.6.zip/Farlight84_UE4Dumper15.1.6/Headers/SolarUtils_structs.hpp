#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct SolarUtils.SolarAggregationTickFunction
// Inherited Bytes: 0x28 | Struct Size: 0x30
struct FSolarAggregationTickFunction : FTickFunction {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
};

