#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct SolarlandDeviceId.DummyObject
// Inherited Bytes: 0x0 | Struct Size: 0x1
struct FDummyObject {
	// Fields
	char pad_0x0[0x1]; // Offset: 0x0 | Size: 0x1
};

