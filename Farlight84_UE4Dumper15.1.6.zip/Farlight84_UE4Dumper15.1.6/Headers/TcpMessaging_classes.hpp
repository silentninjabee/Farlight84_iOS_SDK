#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class TcpMessaging.TcpMessagingSettings
// Inherited Bytes: 0x28 | Struct Size: 0x58
struct UTcpMessagingSettings : UObject {
	// Fields
	bool EnableTransport; // Offset: 0x28 | Size: 0x1
	char pad_0x29[0x7]; // Offset: 0x29 | Size: 0x7
	struct FString ListenEndpoint; // Offset: 0x30 | Size: 0x10
	struct TArray<struct FString> ConnectToEndpoints; // Offset: 0x40 | Size: 0x10
	int32_t ConnectionRetryDelay; // Offset: 0x50 | Size: 0x4
	bool bStopServiceWhenAppDeactivates; // Offset: 0x54 | Size: 0x1
	char pad_0x55[0x3]; // Offset: 0x55 | Size: 0x3
};

