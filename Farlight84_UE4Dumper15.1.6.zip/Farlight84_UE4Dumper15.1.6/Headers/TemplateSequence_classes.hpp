#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class TemplateSequence.TemplateSequence
// Inherited Bytes: 0x348 | Struct Size: 0x3f0
struct UTemplateSequence : UMovieSceneSequence {
	// Fields
	struct UMovieScene* MovieScene; // Offset: 0x348 | Size: 0x8
	struct TSoftClassPtr<UObject> BoundActorClass; // Offset: 0x350 | Size: 0x28
	struct TSoftObjectPtr<AActor> BoundPreviewActor; // Offset: 0x378 | Size: 0x28
	struct TMap<struct FGuid, struct FName> BoundActorComponents; // Offset: 0x3a0 | Size: 0x50
};

// Object: Class TemplateSequence.CameraAnimationSequence
// Inherited Bytes: 0x3f0 | Struct Size: 0x3f0
struct UCameraAnimationSequence : UTemplateSequence {
};

// Object: Class TemplateSequence.TemplateSequenceActor
// Inherited Bytes: 0x228 | Struct Size: 0x278
struct ATemplateSequenceActor : AActor {
	// Fields
	char pad_0x228[0x8]; // Offset: 0x228 | Size: 0x8
	struct FMovieSceneSequencePlaybackSettings PlaybackSettings; // Offset: 0x230 | Size: 0x14
	char pad_0x244[0x4]; // Offset: 0x244 | Size: 0x4
	struct UTemplateSequencePlayer* SequencePlayer; // Offset: 0x248 | Size: 0x8
	struct FSoftObjectPath TemplateSequence; // Offset: 0x250 | Size: 0x18
	struct FTemplateSequenceBindingOverrideData BindingOverride; // Offset: 0x268 | Size: 0xc
	char pad_0x274[0x4]; // Offset: 0x274 | Size: 0x4

	// Functions

	// Object: Function TemplateSequence.TemplateSequenceActor.SetSequence
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102459e44
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetSequence(struct UTemplateSequence* InSequence);

	// Object: Function TemplateSequence.TemplateSequenceActor.SetBinding
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102459d90
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetBinding(struct AActor* Actor);

	// Object: Function TemplateSequence.TemplateSequenceActor.LoadSequence
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102459ec4
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UTemplateSequence* LoadSequence();

	// Object: Function TemplateSequence.TemplateSequenceActor.GetSequencePlayer
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102459e10
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UTemplateSequencePlayer* GetSequencePlayer();

	// Object: Function TemplateSequence.TemplateSequenceActor.GetSequence
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102459ef8
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UTemplateSequence* GetSequence();
};

// Object: Class TemplateSequence.TemplateSequencePlayer
// Inherited Bytes: 0x888 | Struct Size: 0x890
struct UTemplateSequencePlayer : UMovieSceneSequencePlayer {
	// Fields
	char pad_0x888[0x8]; // Offset: 0x888 | Size: 0x8

	// Functions

	// Object: Function TemplateSequence.TemplateSequencePlayer.CreateTemplateSequencePlayer
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10245a60c
	// Return & Params: [ Num(5) Size(0x38) ]
	struct UTemplateSequencePlayer* CreateTemplateSequencePlayer(struct UObject* WorldContextObject, struct UTemplateSequence* TemplateSequence, struct FMovieSceneSequencePlaybackSettings Settings, struct ATemplateSequenceActor*& OutActor);
};

// Object: Class TemplateSequence.TemplateSequenceSection
// Inherited Bytes: 0x150 | Struct Size: 0x150
struct UTemplateSequenceSection : UMovieSceneSubSection {
};

// Object: Class TemplateSequence.TemplateSequenceTrack
// Inherited Bytes: 0x68 | Struct Size: 0x68
struct UTemplateSequenceTrack : UMovieSceneSubTrack {
};

