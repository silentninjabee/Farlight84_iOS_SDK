#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_LoadingBase.UI_LoadingBase_C
// Inherited Bytes: 0x4a8 | Struct Size: 0x4b0
struct UUI_LoadingBase_C : ULoadingUIBase {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x4a8 | Size: 0x8

	// Functions

	// Object: Function UI_LoadingBase.UI_LoadingBase_C.StartLoading
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103a43990
	// Return & Params: [ Num(0) Size(0x0) ]
	void StartLoading();

	// Object: Function UI_LoadingBase.UI_LoadingBase_C.FinishLoading
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103a43990
	// Return & Params: [ Num(0) Size(0x0) ]
	void FinishLoading();

	// Object: Function UI_LoadingBase.UI_LoadingBase_C.ExecuteUbergraph_UI_LoadingBase
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103a43990
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_LoadingBase(int32_t EntryPoint);
};

