#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Root.UI_Root_C
// Inherited Bytes: 0x400 | Struct Size: 0x494
struct UUI_Root_C : USolarUIRoot {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x400 | Size: 0x8
	struct UCanvasPanel* BattleNoticeRoot; // Offset: 0x408 | Size: 0x8
	struct UCanvasPanel* BattleRoot; // Offset: 0x410 | Size: 0x8
	struct UCanvasPanel* BattleRootGuide; // Offset: 0x418 | Size: 0x8
	struct UCanvasPanel* BattleRootOverlay; // Offset: 0x420 | Size: 0x8
	struct UCanvasPanel* CommonRoot; // Offset: 0x428 | Size: 0x8
	struct UCanvasPanel* ExternalToolsRoot; // Offset: 0x430 | Size: 0x8
	struct UCanvasPanel* Guide; // Offset: 0x438 | Size: 0x8
	struct UCanvasPanel* Loading; // Offset: 0x440 | Size: 0x8
	struct UCanvasPanel* Map; // Offset: 0x448 | Size: 0x8
	struct UCanvasPanel* MiddleRoot; // Offset: 0x450 | Size: 0x8
	struct UCanvasPanel* NoticeRoot; // Offset: 0x458 | Size: 0x8
	struct UCanvasPanel* PopRoot; // Offset: 0x460 | Size: 0x8
	struct UCanvasPanel* Reconnecting; // Offset: 0x468 | Size: 0x8
	struct UCanvasPanel* TipsRoot; // Offset: 0x470 | Size: 0x8
	struct UCanvasPanel* UnderBattleRoot; // Offset: 0x478 | Size: 0x8
	float AdapterOffsetLeft; // Offset: 0x480 | Size: 0x4
	float AdapterOffsetRight; // Offset: 0x484 | Size: 0x4
	bool EnableAutoAdaptation; // Offset: 0x488 | Size: 0x1
	char pad_0x489[0x3]; // Offset: 0x489 | Size: 0x3
	float AdapterOffsetLeftDesktop; // Offset: 0x48c | Size: 0x4
	float AdapterOffsetRightDesktop; // Offset: 0x490 | Size: 0x4

	// Functions

	// Object: Function UI_Root.UI_Root_C.OnInitialized
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x1015ce728
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnInitialized();

	// Object: Function UI_Root.UI_Root_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x1015ce728
	// Return & Params: [ Num(0) Size(0x0) ]
	void Construct();

	// Object: Function UI_Root.UI_Root_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x103a43990
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();

	// Object: Function UI_Root.UI_Root_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103a43990
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_Root.UI_Root_C.CustomEvent_1
	// Flags: [HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103a43990
	// Return & Params: [ Num(3) Size(0x20) ]
	void CustomEvent_1(struct UObject* Publisher, struct UObject* Payload, struct TArray<struct FString>& MetaData);

	// Object: Function UI_Root.UI_Root_C.ExecuteUbergraph_UI_Root
	// Flags: [Final|UbergraphFunction|HasDefaults]
	// Offset: 0x103a43990
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_Root(int32_t EntryPoint);
};

