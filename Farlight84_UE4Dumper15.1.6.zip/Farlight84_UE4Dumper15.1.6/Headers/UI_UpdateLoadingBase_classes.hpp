#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_UpdateLoadingBase.UI_UpdateLoadingBase_C
// Inherited Bytes: 0x4b0 | Struct Size: 0x4c8
struct UUI_UpdateLoadingBase_C : UUI_LoadingBase_C {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x4b0 | Size: 0x8
	struct UHorizontalBox* HorizontalBox_4; // Offset: 0x4b8 | Size: 0x8
	struct UCanvasPanel* Panel_Load; // Offset: 0x4c0 | Size: 0x8

	// Functions

	// Object: Function UI_UpdateLoadingBase.UI_UpdateLoadingBase_C.SetPercentText
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103a43990
	// Return & Params: [ Num(1) Size(0x18) ]
	void SetPercentText(struct FText NewParam);

	// Object: Function UI_UpdateLoadingBase.UI_UpdateLoadingBase_C.SetImgBgHidden
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103a43990
	// Return & Params: [ Num(0) Size(0x0) ]
	void SetImgBgHidden();

	// Object: Function UI_UpdateLoadingBase.UI_UpdateLoadingBase_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103a43990
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_UpdateLoadingBase.UI_UpdateLoadingBase_C.Tick
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103a43990
	// Return & Params: [ Num(2) Size(0x3c) ]
	void Tick(struct FGeometry MyGeometry, float InDeltaTime);

	// Object: Function UI_UpdateLoadingBase.UI_UpdateLoadingBase_C.ExecuteUbergraph_UI_UpdateLoadingBase
	// Flags: [Final|UbergraphFunction|HasDefaults]
	// Offset: 0x103a43990
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_UpdateLoadingBase(int32_t EntryPoint);
};

