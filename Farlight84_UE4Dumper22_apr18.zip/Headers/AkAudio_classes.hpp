#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class AkAudio.AkPortalComponent
// Inherited Bytes: 0x360 | Struct Size: 0x410
struct UAkPortalComponent : USceneComponent {
	// Fields
	bool bDynamic; // Offset: 0x354 | Size: 0x1
	enum class AkAcousticPortalState InitialState; // Offset: 0x355 | Size: 0x1
	float ObstructionRefreshInterval; // Offset: 0x358 | Size: 0x4
	enum class ECollisionChannel ObstructionCollisionChannel; // Offset: 0x35c | Size: 0x1
	char pad_0x367[0xa9]; // Offset: 0x367 | Size: 0xa9

	// Functions

	// Object: Function AkAudio.AkPortalComponent.PortalPlacementValid
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10210bfd8
	// Return & Params: [ Num(1) Size(0x1) ]
	bool PortalPlacementValid();

	// Object: Function AkAudio.AkPortalComponent.OpenPortal
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10210c0a8
	// Return & Params: [ Num(0) Size(0x0) ]
	void OpenPortal();

	// Object: Function AkAudio.AkPortalComponent.GetPrimitiveParent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10210c02c
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UPrimitiveComponent* GetPrimitiveParent();

	// Object: Function AkAudio.AkPortalComponent.GetCurrentState
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10210c060
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class AkAcousticPortalState GetCurrentState();

	// Object: Function AkAudio.AkPortalComponent.ClosePortal
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10210c094
	// Return & Params: [ Num(0) Size(0x0) ]
	void ClosePortal();
};

// Object: Class AkAudio.AkAcousticPortal
// Inherited Bytes: 0x268 | Struct Size: 0x278
struct AAkAcousticPortal : AVolume {
	// Fields
	struct UAkPortalComponent* Portal; // Offset: 0x268 | Size: 0x8
	enum class AkAcousticPortalState InitialState; // Offset: 0x270 | Size: 0x1
	bool bRequiresStateMigration; // Offset: 0x271 | Size: 0x1
	char pad_0x272[0x6]; // Offset: 0x272 | Size: 0x6

	// Functions

	// Object: Function AkAudio.AkAcousticPortal.OpenPortal
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10210c640
	// Return & Params: [ Num(0) Size(0x0) ]
	void OpenPortal();

	// Object: Function AkAudio.AkAcousticPortal.GetCurrentState
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10210c5f8
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class AkAcousticPortalState GetCurrentState();

	// Object: Function AkAudio.AkAcousticPortal.ClosePortal
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10210c62c
	// Return & Params: [ Num(0) Size(0x0) ]
	void ClosePortal();
};

// Object: Class AkAudio.AkAudioType
// Inherited Bytes: 0x28 | Struct Size: 0x40
struct UAkAudioType : UObject {
	// Fields
	uint32_t ShortID; // Offset: 0x28 | Size: 0x4
	char pad_0x2C[0x4]; // Offset: 0x2c | Size: 0x4
	struct TArray<struct UObject*> UserData; // Offset: 0x30 | Size: 0x10
};

// Object: Class AkAudio.AkAcousticTexture
// Inherited Bytes: 0x40 | Struct Size: 0x40
struct UAkAcousticTexture : UAkAudioType {
};

// Object: Class AkAudio.AkAcousticTextureSetComponent
// Inherited Bytes: 0x360 | Struct Size: 0x370
struct UAkAcousticTextureSetComponent : USceneComponent {
	// Fields
	char pad_0x360[0x10]; // Offset: 0x360 | Size: 0x10
};

// Object: Class AkAudio.AkAmbientSound
// Inherited Bytes: 0x230 | Struct Size: 0x288
struct AAkAmbientSound : AActor {
	// Fields
	struct UAkAudioEvent* AkAudioEvent; // Offset: 0x230 | Size: 0x8
	struct UAkComponent* AkComponent; // Offset: 0x238 | Size: 0x8
	bool StopWhenOwnerIsDestroyed; // Offset: 0x240 | Size: 0x1
	bool AutoPost; // Offset: 0x241 | Size: 0x1
	char pad_0x242[0x46]; // Offset: 0x242 | Size: 0x46

	// Functions

	// Object: Function AkAudio.AkAmbientSound.StopAmbientSound
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x10210cf8c
	// Return & Params: [ Num(0) Size(0x0) ]
	void StopAmbientSound();

	// Object: Function AkAudio.AkAmbientSound.StartAmbientSound
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x10210cfa0
	// Return & Params: [ Num(0) Size(0x0) ]
	void StartAmbientSound();
};

// Object: Class AkAudio.AkAndroidInitializationSettings
// Inherited Bytes: 0x28 | Struct Size: 0xf8
struct UAkAndroidInitializationSettings : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
	struct FAkCommonInitializationSettingsWithSampleRate CommonSettings; // Offset: 0x30 | Size: 0x68
	struct FAkCommunicationSettingsWithSystemInitialization CommunicationSettings; // Offset: 0x98 | Size: 0x28
	struct FAkAndroidAdvancedInitializationSettings AdvancedSettings; // Offset: 0xc0 | Size: 0x38

	// Functions

	// Object: Function AkAudio.AkAndroidInitializationSettings.MigrateMultiCoreRendering
	// Flags: [Final|Native|Public]
	// Offset: 0x10210d63c
	// Return & Params: [ Num(1) Size(0x1) ]
	void MigrateMultiCoreRendering(bool NewValue);
};

// Object: Class AkAudio.AkPlatformInfo
// Inherited Bytes: 0x28 | Struct Size: 0x70
struct UAkPlatformInfo : UObject {
	// Fields
	char pad_0x28[0x48]; // Offset: 0x28 | Size: 0x48
};

// Object: Class AkAudio.AkAndroidPlatformInfo
// Inherited Bytes: 0x70 | Struct Size: 0x70
struct UAkAndroidPlatformInfo : UAkPlatformInfo {
};

// Object: Class AkAudio.AkAssetData
// Inherited Bytes: 0x28 | Struct Size: 0x60
struct UAkAssetData : UObject {
	// Fields
	uint32_t CachedHash; // Offset: 0x28 | Size: 0x4
	char pad_0x2C[0x34]; // Offset: 0x2c | Size: 0x34
};

// Object: Class AkAudio.AkAssetDataWithMedia
// Inherited Bytes: 0x60 | Struct Size: 0x70
struct UAkAssetDataWithMedia : UAkAssetData {
	// Fields
	struct TArray<struct UAkMediaAsset*> MediaList; // Offset: 0x60 | Size: 0x10
};

// Object: Class AkAudio.AkAssetPlatformData
// Inherited Bytes: 0x28 | Struct Size: 0x30
struct UAkAssetPlatformData : UObject {
	// Fields
	struct UAkAssetData* CurrentAssetData; // Offset: 0x28 | Size: 0x8
};

// Object: Class AkAudio.AkAssetBase
// Inherited Bytes: 0x40 | Struct Size: 0x50
struct UAkAssetBase : UAkAudioType {
	// Fields
	struct UAkAssetPlatformData* PlatformAssetData; // Offset: 0x40 | Size: 0x8
	char pad_0x48[0x8]; // Offset: 0x48 | Size: 0x8
};

// Object: Class AkAudio.AkAudioBank
// Inherited Bytes: 0x50 | Struct Size: 0x120
struct UAkAudioBank : UAkAssetBase {
	// Fields
	bool AutoLoad; // Offset: 0x49 | Size: 0x1
	struct TMap<struct FString, struct TSoftObjectPtr<UAkAssetPlatformData>> LocalizedPlatformAssetDataMap; // Offset: 0x50 | Size: 0x50
	struct TSet<struct TSoftObjectPtr<UAkAudioEvent>> LinkedAkEvents; // Offset: 0xa0 | Size: 0x50
	struct UAkAssetPlatformData* CurrentLocalizedPlatformAssetData; // Offset: 0xf0 | Size: 0x8
	char pad_0xF9[0x27]; // Offset: 0xf9 | Size: 0x27
};

// Object: Class AkAudio.AkAssetDataSwitchContainerData
// Inherited Bytes: 0x28 | Struct Size: 0x78
struct UAkAssetDataSwitchContainerData : UObject {
	// Fields
	struct TSoftObjectPtr<UAkGroupValue> GroupValue; // Offset: 0x28 | Size: 0x28
	struct UAkGroupValue* DefaultGroupValue; // Offset: 0x50 | Size: 0x8
	struct TArray<struct UAkMediaAsset*> MediaList; // Offset: 0x58 | Size: 0x10
	struct TArray<struct UAkAssetDataSwitchContainerData*> Children; // Offset: 0x68 | Size: 0x10
};

// Object: Class AkAudio.AkAssetDataSwitchContainer
// Inherited Bytes: 0x70 | Struct Size: 0x88
struct UAkAssetDataSwitchContainer : UAkAssetDataWithMedia {
	// Fields
	struct TArray<struct UAkAssetDataSwitchContainerData*> SwitchContainers; // Offset: 0x70 | Size: 0x10
	struct UAkGroupValue* DefaultGroupValue; // Offset: 0x80 | Size: 0x8
};

// Object: Class AkAudio.AkAudioEventData
// Inherited Bytes: 0x88 | Struct Size: 0x268
struct UAkAudioEventData : UAkAssetDataSwitchContainer {
	// Fields
	float MaxAttenuationRadius; // Offset: 0x88 | Size: 0x4
	bool IsInfinite; // Offset: 0x8c | Size: 0x1
	char pad_0x8D[0x3]; // Offset: 0x8d | Size: 0x3
	float MinimumDuration; // Offset: 0x90 | Size: 0x4
	float MaximumDuration; // Offset: 0x94 | Size: 0x4
	struct TMap<struct FString, struct UAkAssetDataSwitchContainer*> LocalizedMedia; // Offset: 0x98 | Size: 0x50
	struct TSet<struct UAkAudioEvent*> PostedEvents; // Offset: 0xe8 | Size: 0x50
	struct TSet<struct UAkAuxBus*> UserDefinedSends; // Offset: 0x138 | Size: 0x50
	struct TSet<struct UAkTrigger*> PostedTriggers; // Offset: 0x188 | Size: 0x50
	struct TSet<struct UAkGroupValue*> GroupValues; // Offset: 0x1d8 | Size: 0x50
	char pad_0x228[0x40]; // Offset: 0x228 | Size: 0x40
};

// Object: Class AkAudio.AkAudioEvent
// Inherited Bytes: 0x50 | Struct Size: 0xe0
struct UAkAudioEvent : UAkAssetBase {
	// Fields
	struct TMap<struct FString, struct TSoftObjectPtr<UAkAssetPlatformData>> LocalizedPlatformAssetDataMap; // Offset: 0x50 | Size: 0x50
	struct UAkAudioBank* RequiredBank; // Offset: 0xa0 | Size: 0x8
	char pad_0xA8[0x8]; // Offset: 0xa8 | Size: 0x8
	struct UAkAssetPlatformData* CurrentLocalizedPlatformData; // Offset: 0xb0 | Size: 0x8
	float MaxAttenuationRadius; // Offset: 0xb8 | Size: 0x4
	bool IsInfinite; // Offset: 0xbc | Size: 0x1
	char pad_0xBD[0x3]; // Offset: 0xbd | Size: 0x3
	float MinimumDuration; // Offset: 0xc0 | Size: 0x4
	float MaximumDuration; // Offset: 0xc4 | Size: 0x4
	char pad_0xC8[0x18]; // Offset: 0xc8 | Size: 0x18

	// Functions

	// Object: Function AkAudio.AkAudioEvent.GetMinimumDuration
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10210ede8
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetMinimumDuration();

	// Object: Function AkAudio.AkAudioEvent.GetMaximumDuration
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10210edb4
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetMaximumDuration();

	// Object: Function AkAudio.AkAudioEvent.GetMaxAttenuationRadius
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10210ee50
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetMaxAttenuationRadius();

	// Object: Function AkAudio.AkAudioEvent.GetIsInfinite
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10210ee1c
	// Return & Params: [ Num(1) Size(0x1) ]
	bool GetIsInfinite();
};

// Object: Class AkAudio.AkGameObject
// Inherited Bytes: 0x360 | Struct Size: 0x380
struct UAkGameObject : USceneComponent {
	// Fields
	struct UAkAudioEvent* AkAudioEvent; // Offset: 0x358 | Size: 0x8
	struct FString EventName; // Offset: 0x360 | Size: 0x10
	char pad_0x378[0x8]; // Offset: 0x378 | Size: 0x8

	// Functions

	// Object: Function AkAudio.AkGameObject.Stop
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x10211548c
	// Return & Params: [ Num(0) Size(0x0) ]
	void Stop();

	// Object: Function AkAudio.AkGameObject.SetRTPCValue
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|Const]
	// Offset: 0x1021152b0
	// Return & Params: [ Num(4) Size(0x20) ]
	void SetRTPCValue(struct UAkRtpc* RTPCValue, float Value, int32_t InterpolationTimeMs, struct FString RTPC);

	// Object: Function AkAudio.AkGameObject.PostAssociatedAkEventAsync
	// Flags: [BlueprintCosmetic|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1021159b4
	// Return & Params: [ Num(6) Size(0x4c) ]
	void PostAssociatedAkEventAsync(struct UObject* WorldContextObject, int32_t CallbackMask, struct FDelegate& PostEventCallback, struct TArray<struct FAkExternalSourceInfo>& ExternalSources, struct FLatentActionInfo LatentInfo, int32_t& PlayingID);

	// Object: Function AkAudio.AkGameObject.PostAssociatedAkEvent
	// Flags: [BlueprintCosmetic|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102115c44
	// Return & Params: [ Num(4) Size(0x2c) ]
	int32_t PostAssociatedAkEvent(int32_t CallbackMask, struct FDelegate& PostEventCallback, struct TArray<struct FAkExternalSourceInfo>& ExternalSources);

	// Object: Function AkAudio.AkGameObject.PostAkEventAsync
	// Flags: [BlueprintCosmetic|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1021154a0
	// Return & Params: [ Num(7) Size(0x50) ]
	void PostAkEventAsync(struct UObject* WorldContextObject, struct UAkAudioEvent* AkEvent, int32_t& PlayingID, int32_t CallbackMask, struct FDelegate& PostEventCallback, struct TArray<struct FAkExternalSourceInfo>& ExternalSources, struct FLatentActionInfo LatentInfo);

	// Object: Function AkAudio.AkGameObject.PostAkEvent
	// Flags: [BlueprintCosmetic|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102115778
	// Return & Params: [ Num(6) Size(0x44) ]
	int32_t PostAkEvent(struct UAkAudioEvent* AkEvent, int32_t CallbackMask, struct FDelegate& PostEventCallback, struct TArray<struct FAkExternalSourceInfo>& ExternalSources, struct FString in_EventName);

	// Object: Function AkAudio.AkGameObject.GetRTPCValue
	// Flags: [Final|BlueprintCosmetic|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102115038
	// Return & Params: [ Num(6) Size(0x2c) ]
	void GetRTPCValue(struct UAkRtpc* RTPCValue, enum class ERTPCValueType InputValueType, float& Value, enum class ERTPCValueType& OutputValueType, struct FString RTPC, int32_t PlayingID);
};

// Object: Class AkAudio.AkComponent
// Inherited Bytes: 0x380 | Struct Size: 0x560
struct UAkComponent : UAkGameObject {
	// Fields
	bool bUseSpatialAudio; // Offset: 0x372 | Size: 0x1
	enum class ECollisionChannel OcclusionCollisionChannel; // Offset: 0x378 | Size: 0x1
	char EnableSpotReflectors : 1; // Offset: 0x379 | Size: 0x1
	float OuterRadius; // Offset: 0x37c | Size: 0x4
	float InnerRadius; // Offset: 0x380 | Size: 0x4
	struct UAkAuxBus* EarlyReflectionAuxBus; // Offset: 0x388 | Size: 0x8
	struct FString EarlyReflectionAuxBusName; // Offset: 0x390 | Size: 0x10
	int32_t EarlyReflectionOrder; // Offset: 0x3a0 | Size: 0x4
	float EarlyReflectionBusSendGain; // Offset: 0x3a4 | Size: 0x4
	float EarlyReflectionMaxPathLength; // Offset: 0x3a8 | Size: 0x4
	float roomReverbAuxBusGain; // Offset: 0x3ac | Size: 0x4
	int32_t diffractionMaxEdges; // Offset: 0x3b0 | Size: 0x4
	int32_t diffractionMaxPaths; // Offset: 0x3b4 | Size: 0x4
	float diffractionMaxPathLength; // Offset: 0x3b8 | Size: 0x4
	char DrawFirstOrderReflections : 1; // Offset: 0x3bc | Size: 0x1
	char DrawSecondOrderReflections : 1; // Offset: 0x3bc | Size: 0x1
	char DrawHigherOrderReflections : 1; // Offset: 0x3bc | Size: 0x1
	char DrawDiffraction : 1; // Offset: 0x3bc | Size: 0x1
	bool StopWhenOwnerDestroyed; // Offset: 0x3bd | Size: 0x1
	char pad_0x3BF_5 : 3; // Offset: 0x3bf | Size: 0x1
	float AttenuationScalingFactor; // Offset: 0x3c0 | Size: 0x4
	float OcclusionRefreshInterval; // Offset: 0x3c4 | Size: 0x4
	bool bUseReverbVolumes; // Offset: 0x3c8 | Size: 0x1
	char pad_0x3C9[0x16f]; // Offset: 0x3c9 | Size: 0x16f
	bool bIsInDoor; // Offset: 0x538 | Size: 0x1
	bool AutoUpdatePosition; // Offset: 0x539 | Size: 0x1
	bool EnableOccObsRTPC; // Offset: 0x53a | Size: 0x1
	bool AutoPostEvent; // Offset: 0x53b | Size: 0x1
	float DistanceToListener; // Offset: 0x53c | Size: 0x4
	bool IsListeningToSelf; // Offset: 0x540 | Size: 0x1
	char pad_0x541[0x1f]; // Offset: 0x541 | Size: 0x1f

	// Functions

	// Object: Function AkAudio.AkComponent.UseReverbVolumes
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x102110850
	// Return & Params: [ Num(1) Size(0x1) ]
	void UseReverbVolumes(bool inUseReverbVolumes);

	// Object: Function AkAudio.AkComponent.UseEarlyReflections
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102110638
	// Return & Params: [ Num(6) Size(0x28) ]
	void UseEarlyReflections(struct UAkAuxBus* AuxBus, int32_t Order, float BusSendGain, float MaxPathLength, bool SpotReflectors, struct FString AuxBusName);

	// Object: Function AkAudio.AkComponent.SetSwitch
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x1021109f8
	// Return & Params: [ Num(3) Size(0x28) ]
	void SetSwitch(struct UAkSwitchValue* SwitchValue, struct FString SwitchGroup, struct FString SwitchState);

	// Object: Function AkAudio.AkComponent.SetStopWhenOwnerDestroyed
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x102110970
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetStopWhenOwnerDestroyed(bool bStopWhenOwnerDestroyed);

	// Object: Function AkAudio.AkComponent.SetOutputBusVolume
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x1021104ac
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetOutputBusVolume(float BusVolume);

	// Object: Function AkAudio.AkComponent.SetListeners
	// Flags: [Final|BlueprintCosmetic|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1021108d8
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetListeners(struct TArray<struct UAkComponent*>& Listeners);

	// Object: Function AkAudio.AkComponent.SetGameObjectRadius
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102111444
	// Return & Params: [ Num(2) Size(0x8) ]
	void SetGameObjectRadius(float in_outerRadius, float in_innerRadius);

	// Object: Function AkAudio.AkComponent.SetEarlyReflectionsVolume
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x10211052c
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetEarlyReflectionsVolume(float SendVolume);

	// Object: Function AkAudio.AkComponent.SetEarlyReflectionsAuxBus
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x1021105ac
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetEarlyReflectionsAuxBus(struct FString AuxBusName);

	// Object: Function AkAudio.AkComponent.SetAttenuationScalingFactor
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x10211042c
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetAttenuationScalingFactor(float Value);

	// Object: Function AkAudio.AkComponent.PostTrigger
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x102110bd4
	// Return & Params: [ Num(2) Size(0x18) ]
	void PostTrigger(struct UAkTrigger* TriggerValue, struct FString Trigger);

	// Object: Function AkAudio.AkComponent.PostAssociatedAkEventAndWaitForEndAsync
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102111174
	// Return & Params: [ Num(3) Size(0x30) ]
	void PostAssociatedAkEventAndWaitForEndAsync(int32_t& PlayingID, struct TArray<struct FAkExternalSourceInfo>& ExternalSources, struct FLatentActionInfo LatentInfo);

	// Object: Function AkAudio.AkComponent.PostAssociatedAkEventAndWaitForEnd
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102111300
	// Return & Params: [ Num(3) Size(0x2c) ]
	int32_t PostAssociatedAkEventAndWaitForEnd(struct TArray<struct FAkExternalSourceInfo>& ExternalSources, struct FLatentActionInfo LatentInfo);

	// Object: Function AkAudio.AkComponent.PostAkEventByName
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x102110d18
	// Return & Params: [ Num(2) Size(0x14) ]
	int32_t PostAkEventByName(struct FString in_EventName);

	// Object: Function AkAudio.AkComponent.PostAkEventAndWaitForEndAsync
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102110db4
	// Return & Params: [ Num(4) Size(0x38) ]
	void PostAkEventAndWaitForEndAsync(struct UAkAudioEvent* AkEvent, int32_t& PlayingID, struct TArray<struct FAkExternalSourceInfo>& ExternalSources, struct FLatentActionInfo LatentInfo);

	// Object: Function AkAudio.AkComponent.PostAkEventAndWaitForEnd
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102110f8c
	// Return & Params: [ Num(5) Size(0x44) ]
	int32_t PostAkEventAndWaitForEnd(struct UAkAudioEvent* AkEvent, struct FString in_EventName, struct TArray<struct FAkExternalSourceInfo>& ExternalSources, struct FLatentActionInfo LatentInfo);

	// Object: Function AkAudio.AkComponent.GetCurrentRoom
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1021103dc
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UAkRoomComponent* GetCurrentRoom();

	// Object: Function AkAudio.AkComponent.GetAttenuationRadius
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1021103f8
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetAttenuationRadius();
};

// Object: Class AkAudio.AkAudioInputComponent
// Inherited Bytes: 0x560 | Struct Size: 0x590
struct UAkAudioInputComponent : UAkComponent {
	// Fields
	char pad_0x560[0x30]; // Offset: 0x560 | Size: 0x30

	// Functions

	// Object: Function AkAudio.AkAudioInputComponent.PostAssociatedAudioInputEvent
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x10210f2b8
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t PostAssociatedAudioInputEvent();
};

// Object: Class AkAudio.AkAuxBus
// Inherited Bytes: 0x50 | Struct Size: 0x58
struct UAkAuxBus : UAkAssetBase {
	// Fields
	struct UAkAudioBank* RequiredBank; // Offset: 0x50 | Size: 0x8
};

// Object: Class AkAudio.AkCheckBox
// Inherited Bytes: 0x150 | Struct Size: 0xec0
struct UAkCheckBox : UContentWidget {
	// Fields
	char pad_0x150[0x348]; // Offset: 0x150 | Size: 0x348
	enum class ECheckBoxState CheckedState; // Offset: 0x498 | Size: 0x1
	char pad_0x499[0x3]; // Offset: 0x499 | Size: 0x3
	struct FDelegate CheckedStateDelegate; // Offset: 0x49c | Size: 0x10
	char pad_0x4AC[0x4]; // Offset: 0x4ac | Size: 0x4
	struct FCheckBoxStyle WidgetStyle; // Offset: 0x4b0 | Size: 0x930
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0xde0 | Size: 0x1
	bool IsFocusable; // Offset: 0xde1 | Size: 0x1
	char pad_0xDE2[0x6]; // Offset: 0xde2 | Size: 0x6
	struct FAkBoolPropertyToControl ThePropertyToControl; // Offset: 0xde8 | Size: 0x10
	struct FAkWwiseItemToControl ItemToControl; // Offset: 0xdf8 | Size: 0x40
	struct FMulticastInlineDelegate AkOnCheckStateChanged; // Offset: 0xe38 | Size: 0x10
	struct FMulticastInlineDelegate OnItemDropped; // Offset: 0xe48 | Size: 0x10
	struct FMulticastInlineDelegate OnPropertyDropped; // Offset: 0xe58 | Size: 0x10
	char pad_0xE68[0x58]; // Offset: 0xe68 | Size: 0x58

	// Functions

	// Object: Function AkAudio.AkCheckBox.SetIsChecked
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10210fd44
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetIsChecked(bool InIsChecked);

	// Object: Function AkAudio.AkCheckBox.SetCheckedState
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10210fcc4
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetCheckedState(enum class ECheckBoxState InCheckedState);

	// Object: Function AkAudio.AkCheckBox.SetAkItemId
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10210fc38
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetAkItemId(struct FGuid& ItemID);

	// Object: Function AkAudio.AkCheckBox.SetAkBoolProperty
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10210fb78
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetAkBoolProperty(struct FString ItemProperty);

	// Object: Function AkAudio.AkCheckBox.IsPressed
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10210fe34
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsPressed();

	// Object: Function AkAudio.AkCheckBox.IsChecked
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10210fe00
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsChecked();

	// Object: Function AkAudio.AkCheckBox.GetCheckedState
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10210fdcc
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class ECheckBoxState GetCheckedState();

	// Object: Function AkAudio.AkCheckBox.GetAkProperty
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10210fad8
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetAkProperty();

	// Object: Function AkAudio.AkCheckBox.GetAkItemId
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10210fc04
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FGuid GetAkItemId();
};

// Object: Class AkAudio.DrawPortalComponent
// Inherited Bytes: 0x5d0 | Struct Size: 0x5d0
struct UDrawPortalComponent : UPrimitiveComponent {
};

// Object: Class AkAudio.DrawRoomComponent
// Inherited Bytes: 0x5d0 | Struct Size: 0x5d0
struct UDrawRoomComponent : UPrimitiveComponent {
};

// Object: Class AkAudio.AkFolder
// Inherited Bytes: 0x40 | Struct Size: 0xb8
struct UAkFolder : UAkAudioType {
	// Fields
	struct FString UnrealFolderPath; // Offset: 0x40 | Size: 0x10
	struct FString WwiseFolderPath; // Offset: 0x50 | Size: 0x10
	char pad_0x60[0x58]; // Offset: 0x60 | Size: 0x58
};

// Object: Class AkAudio.AkGameplayStatics
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UAkGameplayStatics : UBlueprintFunctionLibrary {
	// Functions

	// Object: Function AkAudio.AkGameplayStatics.WakeupFromSuspend
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10211c6dc
	// Return & Params: [ Num(0) Size(0x0) ]
	void WakeupFromSuspend();

	// Object: Function AkAudio.AkGameplayStatics.UseReverbVolumes
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1021185f0
	// Return & Params: [ Num(2) Size(0x10) ]
	void UseReverbVolumes(bool inUseReverbVolumes, struct AActor* Actor);

	// Object: Function AkAudio.AkGameplayStatics.UseEarlyReflections
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10211839c
	// Return & Params: [ Num(7) Size(0x30) ]
	void UseEarlyReflections(struct AActor* Actor, struct UAkAuxBus* AuxBus, int32_t Order, float BusSendGain, float MaxPathLength, bool SpotReflectors, struct FString AuxBusName);

	// Object: Function AkAudio.AkGameplayStatics.UpdatePostedEventMultiPositions
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10211c600
	// Return & Params: [ Num(2) Size(0x18) ]
	void UpdatePostedEventMultiPositions(struct UAkComponent* AkComponent, struct TArray<struct FTransform>& Positions);

	// Object: Function AkAudio.AkGameplayStatics.UpdateDopplerEffectDatas
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x102116620
	// Return & Params: [ Num(3) Size(0x20) ]
	void UpdateDopplerEffectDatas(struct AActor* SoundingObj, struct FVector SoundingObjPos, struct FVector ListeningObjPos);

	// Object: Function AkAudio.AkGameplayStatics.UnloadBankByNameAsync
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102116f1c
	// Return & Params: [ Num(2) Size(0x20) ]
	void UnloadBankByNameAsync(struct FString BankName, struct FDelegate& BankUnloadedCallback);

	// Object: Function AkAudio.AkGameplayStatics.UnloadBankByName
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102117008
	// Return & Params: [ Num(1) Size(0x10) ]
	void UnloadBankByName(struct FString BankName);

	// Object: Function AkAudio.AkGameplayStatics.UnloadBankAsync
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10211708c
	// Return & Params: [ Num(2) Size(0x18) ]
	void UnloadBankAsync(struct UAkAudioBank* Bank, struct FDelegate& BankUnloadedCallback);

	// Object: Function AkAudio.AkGameplayStatics.UnloadBank
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10211716c
	// Return & Params: [ Num(4) Size(0x38) ]
	void UnloadBank(struct UAkAudioBank* Bank, struct FString BankName, struct FLatentActionInfo LatentInfo, struct UObject* WorldContextObject);

	// Object: Function AkAudio.AkGameplayStatics.Suspend
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10211c6f0
	// Return & Params: [ Num(1) Size(0x1) ]
	void Suspend(bool in_bRenderAnyway);

	// Object: Function AkAudio.AkGameplayStatics.StopSoundOnComponentbyname
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10211a8a0
	// Return & Params: [ Num(3) Size(0x1c) ]
	int32_t StopSoundOnComponentbyname(struct FString SoundName, struct UActorComponent* Component);

	// Object: Function AkAudio.AkGameplayStatics.StopSoundOnComponent
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10211a9e0
	// Return & Params: [ Num(3) Size(0x14) ]
	int32_t StopSoundOnComponent(struct UAkAudioEvent* AkEvent, struct UActorComponent* Component);

	// Object: Function AkAudio.AkGameplayStatics.StopSoundbyname
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10211ac18
	// Return & Params: [ Num(3) Size(0x1c) ]
	int32_t StopSoundbyname(struct FString SoundName, struct AActor* Actor);

	// Object: Function AkAudio.AkGameplayStatics.StopSound2Dbyname
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10211aaa8
	// Return & Params: [ Num(2) Size(0x14) ]
	int32_t StopSound2Dbyname(struct FString SoundName);

	// Object: Function AkAudio.AkGameplayStatics.StopSound2D
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10211ab98
	// Return & Params: [ Num(2) Size(0xc) ]
	int32_t StopSound2D(struct UAkAudioEvent* AkEvent);

	// Object: Function AkAudio.AkGameplayStatics.StopSound
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10211ad58
	// Return & Params: [ Num(3) Size(0x14) ]
	int32_t StopSound(struct UAkAudioEvent* AkEvent, struct AActor* Actor);

	// Object: Function AkAudio.AkGameplayStatics.StopProfilerCapture
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102116d68
	// Return & Params: [ Num(0) Size(0x0) ]
	void StopProfilerCapture();

	// Object: Function AkAudio.AkGameplayStatics.StopOutputCapture
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102116e00
	// Return & Params: [ Num(0) Size(0x0) ]
	void StopOutputCapture();

	// Object: Function AkAudio.AkGameplayStatics.StopAllAmbientSounds
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1021177d0
	// Return & Params: [ Num(1) Size(0x8) ]
	void StopAllAmbientSounds(struct UObject* WorldContextObject);

	// Object: Function AkAudio.AkGameplayStatics.StopAll
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102117960
	// Return & Params: [ Num(0) Size(0x0) ]
	void StopAll();

	// Object: Function AkAudio.AkGameplayStatics.StopActor
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102117974
	// Return & Params: [ Num(1) Size(0x8) ]
	void StopActor(struct AActor* Actor);

	// Object: Function AkAudio.AkGameplayStatics.StartProfilerCapture
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102116d7c
	// Return & Params: [ Num(1) Size(0x10) ]
	void StartProfilerCapture(struct FString Filename);

	// Object: Function AkAudio.AkGameplayStatics.StartOutputCapture
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102116e98
	// Return & Params: [ Num(1) Size(0x10) ]
	void StartOutputCapture(struct FString Filename);

	// Object: Function AkAudio.AkGameplayStatics.StartAllAmbientSounds
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102117848
	// Return & Params: [ Num(1) Size(0x8) ]
	void StartAllAmbientSounds(struct UObject* WorldContextObject);

	// Object: Function AkAudio.AkGameplayStatics.SpawnAkComponentAtLocation
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x102119408
	// Return & Params: [ Num(8) Size(0x50) ]
	struct UAkComponent* SpawnAkComponentAtLocation(struct UObject* WorldContextObject, struct UAkAudioEvent* AkEvent, struct FVector Location, struct FRotator Orientation, bool AutoPost, struct FString EventName, bool AutoDestroy);

	// Object: Function AkAudio.AkGameplayStatics.SetSwitchToListenerbyname
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10211b568
	// Return & Params: [ Num(2) Size(0x20) ]
	void SetSwitchToListenerbyname(struct FString SwitchGroup, struct FString SwitchState);

	// Object: Function AkAudio.AkGameplayStatics.SetSwitchToListener
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10211b6f8
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetSwitchToListener(struct UAkSwitchValue* SwitchValue);

	// Object: Function AkAudio.AkGameplayStatics.SetSwitchToComponentbyname
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10211b770
	// Return & Params: [ Num(3) Size(0x28) ]
	void SetSwitchToComponentbyname(struct UActorComponent* Component, struct FString SwitchGroup, struct FString SwitchState);

	// Object: Function AkAudio.AkGameplayStatics.SetSwitchToComponent
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10211b95c
	// Return & Params: [ Num(2) Size(0x10) ]
	void SetSwitchToComponent(struct UAkSwitchValue* SwitchValue, struct UActorComponent* Component);

	// Object: Function AkAudio.AkGameplayStatics.SetSwitchbyname
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10211ba1c
	// Return & Params: [ Num(3) Size(0x28) ]
	void SetSwitchbyname(struct AActor* Actor, struct FString SwitchGroup, struct FString SwitchState);

	// Object: Function AkAudio.AkGameplayStatics.SetSwitch
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102118c94
	// Return & Params: [ Num(4) Size(0x20) ]
	void SetSwitch(struct UAkSwitchValue* SwitchValue, struct AActor* Actor, struct FName SwitchGroup, struct FName SwitchState);

	// Object: Function AkAudio.AkGameplayStatics.SetState
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102118ef4
	// Return & Params: [ Num(3) Size(0x18) ]
	void SetState(struct UAkStateValue* StateValue, struct FName StateGroup, struct FName State);

	// Object: Function AkAudio.AkGameplayStatics.SetSpeakerAngles
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102117ab0
	// Return & Params: [ Num(3) Size(0x28) ]
	void SetSpeakerAngles(struct TArray<float>& SpeakerAngles, float HeightAngle, struct FString DeviceShareset);

	// Object: Function AkAudio.AkGameplayStatics.SetRTPCValueToListenerbyname
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10211ae20
	// Return & Params: [ Num(3) Size(0x18) ]
	void SetRTPCValueToListenerbyname(struct FString RTPC, float Value, int32_t InterpolationTimeMs);

	// Object: Function AkAudio.AkGameplayStatics.SetRTPCValueToListener
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10211af9c
	// Return & Params: [ Num(3) Size(0x10) ]
	void SetRTPCValueToListener(struct UAkRtpc* RTPCValue, float Value, int32_t InterpolationTimeMs);

	// Object: Function AkAudio.AkGameplayStatics.SetRTPCValueToComponentbyname
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10211b0ac
	// Return & Params: [ Num(4) Size(0x20) ]
	void SetRTPCValueToComponentbyname(struct FString RTPC, float Value, int32_t InterpolationTimeMs, struct UActorComponent* Component);

	// Object: Function AkAudio.AkGameplayStatics.SetRTPCValueToComponent
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10211b25c
	// Return & Params: [ Num(4) Size(0x18) ]
	void SetRTPCValueToComponent(struct UAkRtpc* RTPCValue, float Value, int32_t InterpolationTimeMs, struct UActorComponent* Component);

	// Object: Function AkAudio.AkGameplayStatics.SetRTPCValuebyname
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10211b3b8
	// Return & Params: [ Num(4) Size(0x20) ]
	void SetRTPCValuebyname(struct FString RTPC, float Value, int32_t InterpolationTimeMs, struct AActor* Actor);

	// Object: Function AkAudio.AkGameplayStatics.SetRTPCValue
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102119264
	// Return & Params: [ Num(5) Size(0x20) ]
	void SetRTPCValue(struct UAkRtpc* RTPCValue, float Value, int32_t InterpolationTimeMs, struct AActor* Actor, struct FName RTPC);

	// Object: Function AkAudio.AkGameplayStatics.SetReflectionsOrder
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1021182d4
	// Return & Params: [ Num(2) Size(0x5) ]
	void SetReflectionsOrder(int32_t Order, bool RefreshPaths);

	// Object: Function AkAudio.AkGameplayStatics.SetPortalToPortalObstruction
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102117fb0
	// Return & Params: [ Num(3) Size(0x14) ]
	void SetPortalToPortalObstruction(struct UAkPortalComponent* PortalComponent0, struct UAkPortalComponent* PortalComponent1, float ObstructionValue);

	// Object: Function AkAudio.AkGameplayStatics.SetPortalObstructionAndOcclusion
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1021181c8
	// Return & Params: [ Num(3) Size(0x10) ]
	void SetPortalObstructionAndOcclusion(struct UAkPortalComponent* PortalComponent, float ObstructionValue, float OcclusionValue);

	// Object: Function AkAudio.AkGameplayStatics.SetPanningRule
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102117da4
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetPanningRule(enum class PanningRule PanRule);

	// Object: Function AkAudio.AkGameplayStatics.SetOutputBusVolume
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102117eec
	// Return & Params: [ Num(2) Size(0x10) ]
	void SetOutputBusVolume(float BusVolume, struct AActor* Actor);

	// Object: Function AkAudio.AkGameplayStatics.SetOcclusionScalingFactor
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102116ce8
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetOcclusionScalingFactor(float ScalingFactor);

	// Object: Function AkAudio.AkGameplayStatics.SetOcclusionRefreshInterval
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1021179ec
	// Return & Params: [ Num(2) Size(0x10) ]
	void SetOcclusionRefreshInterval(float RefreshInterval, struct AActor* Actor);

	// Object: Function AkAudio.AkGameplayStatics.SetMultiplePositions
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102118b08
	// Return & Params: [ Num(3) Size(0x19) ]
	void SetMultiplePositions(struct UAkComponent* GameObjectAkComponent, struct TArray<struct FTransform> Positions, enum class AkMultiPositionType MultiPositionType);

	// Object: Function AkAudio.AkGameplayStatics.SetMultipleChannelMaskEmitterPositions
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1021186c0
	// Return & Params: [ Num(4) Size(0x29) ]
	void SetMultipleChannelMaskEmitterPositions(struct UAkComponent* GameObjectAkComponent, struct TArray<struct FAkChannelMask> ChannelMasks, struct TArray<struct FTransform> Positions, enum class AkMultiPositionType MultiPositionType);

	// Object: Function AkAudio.AkGameplayStatics.SetMultipleChannelEmitterPositions
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1021188e4
	// Return & Params: [ Num(4) Size(0x29) ]
	void SetMultipleChannelEmitterPositions(struct UAkComponent* GameObjectAkComponent, struct TArray<enum class AkChannelConfiguration> ChannelMasks, struct TArray<struct FTransform> Positions, enum class AkMultiPositionType MultiPositionType);

	// Object: Function AkAudio.AkGameplayStatics.SetGameObjectToPortalObstruction
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1021180bc
	// Return & Params: [ Num(3) Size(0x14) ]
	void SetGameObjectToPortalObstruction(struct UAkComponent* GameObjectAkComponent, struct UAkPortalComponent* PortalComponent, float ObstructionValue);

	// Object: Function AkAudio.AkGameplayStatics.SetCurrentAudioCultureAsync
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102116930
	// Return & Params: [ Num(2) Size(0x20) ]
	void SetCurrentAudioCultureAsync(struct FString AudioCulture, struct FDelegate& Completed);

	// Object: Function AkAudio.AkGameplayStatics.SetCurrentAudioCulture
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102116a1c
	// Return & Params: [ Num(3) Size(0x30) ]
	void SetCurrentAudioCulture(struct FString AudioCulture, struct FLatentActionInfo LatentInfo, struct UObject* WorldContextObject);

	// Object: Function AkAudio.AkGameplayStatics.SetBusConfig
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102117e1c
	// Return & Params: [ Num(2) Size(0x11) ]
	void SetBusConfig(struct FString BusName, enum class AkChannelConfiguration ChannelConfiguration);

	// Object: Function AkAudio.AkGameplayStatics.ReplaceMainOutput
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102117d14
	// Return & Params: [ Num(1) Size(0x18) ]
	void ReplaceMainOutput(struct FAkOutputSettings& MainOutputSettings);

	// Object: Function AkAudio.AkGameplayStatics.PostTrigger
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102118de8
	// Return & Params: [ Num(3) Size(0x18) ]
	void PostTrigger(struct UAkTrigger* TriggerValue, struct AActor* Actor, struct FName Trigger);

	// Object: Function AkAudio.AkGameplayStatics.PostEventByName
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102119ccc
	// Return & Params: [ Num(3) Size(0x19) ]
	void PostEventByName(struct FString EventName, struct AActor* Actor, bool bStopWhenAttachedToDestroyed);

	// Object: Function AkAudio.AkGameplayStatics.PostEventAttached
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10211a670
	// Return & Params: [ Num(6) Size(0x34) ]
	int32_t PostEventAttached(struct UAkAudioEvent* AkEvent, struct AActor* Actor, struct FName AttachPointName, bool bStopWhenAttachedToDestroyed, struct FString EventName);

	// Object: Function AkAudio.AkGameplayStatics.PostEventAtLocationByName
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x1021199b8
	// Return & Params: [ Num(4) Size(0x30) ]
	void PostEventAtLocationByName(struct FString EventName, struct FVector Location, struct FRotator Orientation, struct UObject* WorldContextObject);

	// Object: Function AkAudio.AkGameplayStatics.PostEventAtLocation
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x102119b18
	// Return & Params: [ Num(6) Size(0x3c) ]
	int32_t PostEventAtLocation(struct UAkAudioEvent* AkEvent, struct FVector Location, struct FRotator Orientation, struct FString EventName, struct UObject* WorldContextObject);

	// Object: Function AkAudio.AkGameplayStatics.PostEvent
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10211a348
	// Return & Params: [ Num(8) Size(0x54) ]
	int32_t PostEvent(struct UAkAudioEvent* AkEvent, struct AActor* Actor, int32_t CallbackMask, struct FDelegate& PostEventCallback, struct TArray<struct FAkExternalSourceInfo>& ExternalSources, bool bStopWhenAttachedToDestroyed, struct FString EventName);

	// Object: Function AkAudio.AkGameplayStatics.PostAndWaitForEndOfEventAsync
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102119df0
	// Return & Params: [ Num(6) Size(0x40) ]
	void PostAndWaitForEndOfEventAsync(struct UAkAudioEvent* AkEvent, struct AActor* Actor, int32_t& PlayingID, bool bStopWhenAttachedToDestroyed, struct TArray<struct FAkExternalSourceInfo>& ExternalSources, struct FLatentActionInfo LatentInfo);

	// Object: Function AkAudio.AkGameplayStatics.PostAndWaitForEndOfEvent
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10211a060
	// Return & Params: [ Num(7) Size(0x54) ]
	int32_t PostAndWaitForEndOfEvent(struct UAkAudioEvent* AkEvent, struct AActor* Actor, bool bStopWhenAttachedToDestroyed, struct TArray<struct FAkExternalSourceInfo>& ExternalSources, struct FString EventName, struct FLatentActionInfo LatentInfo);

	// Object: Function AkAudio.AkGameplayStatics.PlaySoundToComponentbyname
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10211becc
	// Return & Params: [ Num(4) Size(0x20) ]
	int32_t PlaySoundToComponentbyname(struct FString SoundName, struct UActorComponent* Component, bool bStopWhenAttachedToDestroyed);

	// Object: Function AkAudio.AkGameplayStatics.PlaySoundToComponent
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10211c048
	// Return & Params: [ Num(4) Size(0x18) ]
	int32_t PlaySoundToComponent(struct UAkAudioEvent* AkEvent, struct UActorComponent* Component, bool bStopWhenAttachedToDestroyed);

	// Object: Function AkAudio.AkGameplayStatics.PlaySoundbyname
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10211c368
	// Return & Params: [ Num(4) Size(0x20) ]
	int32_t PlaySoundbyname(struct FString SoundName, struct AActor* Actor, bool bStopWhenAttachedToDestroyed);

	// Object: Function AkAudio.AkGameplayStatics.PlaySoundAtLocationbyname
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x10211bc08
	// Return & Params: [ Num(5) Size(0x34) ]
	int32_t PlaySoundAtLocationbyname(struct FString SoundName, struct FVector Location, struct FRotator Orientation, struct UObject* WorldContextObject);

	// Object: Function AkAudio.AkGameplayStatics.PlaySoundAtLocation
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x10211bd70
	// Return & Params: [ Num(5) Size(0x2c) ]
	int32_t PlaySoundAtLocation(struct UAkAudioEvent* AkEvent, struct FVector Location, struct FRotator Orientation, struct UObject* WorldContextObject);

	// Object: Function AkAudio.AkGameplayStatics.PlaySound2Dbyname
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10211c164
	// Return & Params: [ Num(3) Size(0x18) ]
	int32_t PlaySound2Dbyname(struct FString SoundName, bool bStopWhenAttachedToDestroyed);

	// Object: Function AkAudio.AkGameplayStatics.PlaySound2D
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10211c294
	// Return & Params: [ Num(3) Size(0x10) ]
	int32_t PlaySound2D(struct UAkAudioEvent* AkEvent, bool bStopWhenAttachedToDestroyed);

	// Object: Function AkAudio.AkGameplayStatics.PlaySound
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10211c4e4
	// Return & Params: [ Num(4) Size(0x18) ]
	int32_t PlaySound(struct UAkAudioEvent* AkEvent, struct AActor* Actor, bool bStopWhenAttachedToDestroyed);

	// Object: Function AkAudio.AkGameplayStatics.LoadInitBank
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1021172f4
	// Return & Params: [ Num(0) Size(0x0) ]
	void LoadInitBank();

	// Object: Function AkAudio.AkGameplayStatics.LoadBanks
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102117308
	// Return & Params: [ Num(2) Size(0x11) ]
	void LoadBanks(struct TArray<struct UAkAudioBank*>& SoundBanks, bool SynchronizeSoundBanks);

	// Object: Function AkAudio.AkGameplayStatics.LoadBankByNameAsync
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1021173e4
	// Return & Params: [ Num(2) Size(0x20) ]
	void LoadBankByNameAsync(struct FString BankName, struct FDelegate& BankLoadedCallback);

	// Object: Function AkAudio.AkGameplayStatics.LoadBankByName
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1021174d0
	// Return & Params: [ Num(1) Size(0x10) ]
	void LoadBankByName(struct FString BankName);

	// Object: Function AkAudio.AkGameplayStatics.LoadBankAsync
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102117554
	// Return & Params: [ Num(2) Size(0x18) ]
	void LoadBankAsync(struct UAkAudioBank* Bank, struct FDelegate& BankLoadedCallback);

	// Object: Function AkAudio.AkGameplayStatics.LoadBank
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102117634
	// Return & Params: [ Num(4) Size(0x38) ]
	void LoadBank(struct UAkAudioBank* Bank, struct FString BankName, struct FLatentActionInfo LatentInfo, struct UObject* WorldContextObject);

	// Object: Function AkAudio.AkGameplayStatics.IsGame
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10211c770
	// Return & Params: [ Num(2) Size(0x9) ]
	bool IsGame(struct UObject* WorldContextObject);

	// Object: Function AkAudio.AkGameplayStatics.IsEditor
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10211c7f0
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsEditor();

	// Object: Function AkAudio.AkGameplayStatics.GetSpeakerAngles
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102117bdc
	// Return & Params: [ Num(3) Size(0x28) ]
	void GetSpeakerAngles(struct TArray<float>& SpeakerAngles, float& HeightAngle, struct FString DeviceShareset);

	// Object: Function AkAudio.AkGameplayStatics.GetRTPCValue
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102119000
	// Return & Params: [ Num(7) Size(0x28) ]
	void GetRTPCValue(struct UAkRtpc* RTPCValue, int32_t PlayingID, enum class ERTPCValueType InputValueType, float& Value, enum class ERTPCValueType& OutputValueType, struct AActor* Actor, struct FName RTPC);

	// Object: Function AkAudio.AkGameplayStatics.GetOcclusionScalingFactor
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102116cc4
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetOcclusionScalingFactor();

	// Object: Function AkAudio.AkGameplayStatics.GetDopplerEffectDatas
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x10211642c
	// Return & Params: [ Num(7) Size(0x30) ]
	float GetDopplerEffectDatas(struct AActor* SoundingObj, struct FVector SoundingObjPos, struct FVector ListeningObjPos, float AddDopplerIntensity, float MinusDopplerIntensity, float DeltaTime);

	// Object: Function AkAudio.AkGameplayStatics.GetCurrentAudioCulture
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102116c44
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetCurrentAudioCulture();

	// Object: Function AkAudio.AkGameplayStatics.GetAvailableAudioCultures
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102116b58
	// Return & Params: [ Num(1) Size(0x10) ]
	struct TArray<struct FString> GetAvailableAudioCultures();

	// Object: Function AkAudio.AkGameplayStatics.GetAkMediaAssetUserData
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1021167a0
	// Return & Params: [ Num(3) Size(0x18) ]
	struct UObject* GetAkMediaAssetUserData(struct UAkMediaAsset* Instance, struct UObject* Type);

	// Object: Function AkAudio.AkGameplayStatics.GetAkComponent
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10211c824
	// Return & Params: [ Num(6) Size(0x30) ]
	struct UAkComponent* GetAkComponent(struct USceneComponent* AttachToComponent, bool& ComponentCreated, struct FName AttachPointName, struct FVector Location, enum class EAttachLocation LocationType);

	// Object: Function AkAudio.AkGameplayStatics.GetAkAudioTypeUserData
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102116868
	// Return & Params: [ Num(3) Size(0x18) ]
	struct UObject* GetAkAudioTypeUserData(struct UAkAudioType* Instance, struct UObject* Type);

	// Object: Function AkAudio.AkGameplayStatics.ExecuteActionOnPlayingID
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10211966c
	// Return & Params: [ Num(4) Size(0xd) ]
	void ExecuteActionOnPlayingID(enum class AkActionOnEventType ActionType, int32_t PlayingID, int32_t TransitionDuration, enum class EAkCurveInterpolation FadeCurve);

	// Object: Function AkAudio.AkGameplayStatics.ExecuteActionOnEvent
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1021197c4
	// Return & Params: [ Num(6) Size(0x24) ]
	void ExecuteActionOnEvent(struct UAkAudioEvent* AkEvent, enum class AkActionOnEventType ActionType, struct AActor* Actor, int32_t TransitionDuration, enum class EAkCurveInterpolation FadeCurve, int32_t PlayingID);

	// Object: Function AkAudio.AkGameplayStatics.ClearDopplerEffectDatas
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102116728
	// Return & Params: [ Num(1) Size(0x8) ]
	void ClearDopplerEffectDatas(struct AActor* SoundingObj);

	// Object: Function AkAudio.AkGameplayStatics.ClearBanks
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1021177bc
	// Return & Params: [ Num(0) Size(0x0) ]
	void ClearBanks();

	// Object: Function AkAudio.AkGameplayStatics.CancelEventCallback
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1021178c0
	// Return & Params: [ Num(1) Size(0x10) ]
	void CancelEventCallback(struct FDelegate& PostEventCallback);

	// Object: Function AkAudio.AkGameplayStatics.ApplyDopplerEffectDatas
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x10211628c
	// Return & Params: [ Num(5) Size(0x20) ]
	void ApplyDopplerEffectDatas(struct AActor* SoundingObj, struct FVector ListeningObjPos, float AddDopplerIntensity, float MinusDopplerIntensity, float DeltaTime);

	// Object: Function AkAudio.AkGameplayStatics.AddOutputCaptureMarker
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102116e14
	// Return & Params: [ Num(1) Size(0x10) ]
	void AddOutputCaptureMarker(struct FString MarkerText);
};

// Object: Class AkAudio.AkCallbackInfo
// Inherited Bytes: 0x28 | Struct Size: 0x30
struct UAkCallbackInfo : UObject {
	// Fields
	struct UAkComponent* AkComponent; // Offset: 0x28 | Size: 0x8
};

// Object: Class AkAudio.AkEventCallbackInfo
// Inherited Bytes: 0x30 | Struct Size: 0x38
struct UAkEventCallbackInfo : UAkCallbackInfo {
	// Fields
	int32_t PlayingID; // Offset: 0x30 | Size: 0x4
	int32_t EventId; // Offset: 0x34 | Size: 0x4
};

// Object: Class AkAudio.AkMIDIEventCallbackInfo
// Inherited Bytes: 0x38 | Struct Size: 0x48
struct UAkMIDIEventCallbackInfo : UAkEventCallbackInfo {
	// Fields
	char pad_0x38[0x10]; // Offset: 0x38 | Size: 0x10

	// Functions

	// Object: Function AkAudio.AkMIDIEventCallbackInfo.GetType
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1021220f0
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class EAkMidiEventType GetType();

	// Object: Function AkAudio.AkMIDIEventCallbackInfo.GetProgramChange
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102121bd4
	// Return & Params: [ Num(2) Size(0x4) ]
	bool GetProgramChange(struct FAkMidiProgramChange& AsProgramChange);

	// Object: Function AkAudio.AkMIDIEventCallbackInfo.GetPitchBend
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102121db0
	// Return & Params: [ Num(2) Size(0x9) ]
	bool GetPitchBend(struct FAkMidiPitchBend& AsPitchBend);

	// Object: Function AkAudio.AkMIDIEventCallbackInfo.GetNoteOn
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102121f84
	// Return & Params: [ Num(2) Size(0x5) ]
	bool GetNoteOn(struct FAkMidiNoteOnOff& AsNoteOn);

	// Object: Function AkAudio.AkMIDIEventCallbackInfo.GetNoteOff
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102121ee8
	// Return & Params: [ Num(2) Size(0x5) ]
	bool GetNoteOff(struct FAkMidiNoteOnOff& AsNoteOff);

	// Object: Function AkAudio.AkMIDIEventCallbackInfo.GetNoteAftertouch
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102121d14
	// Return & Params: [ Num(2) Size(0x5) ]
	bool GetNoteAftertouch(struct FAkMidiNoteAftertouch& AsNoteAftertouch);

	// Object: Function AkAudio.AkMIDIEventCallbackInfo.GetGeneric
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102122020
	// Return & Params: [ Num(2) Size(0x5) ]
	bool GetGeneric(struct FAkMidiGeneric& AsGeneric);

	// Object: Function AkAudio.AkMIDIEventCallbackInfo.GetChannelAftertouch
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102121c74
	// Return & Params: [ Num(2) Size(0x4) ]
	bool GetChannelAftertouch(struct FAkMidiChannelAftertouch& AsChannelAftertouch);

	// Object: Function AkAudio.AkMIDIEventCallbackInfo.GetChannel
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1021220bc
	// Return & Params: [ Num(1) Size(0x1) ]
	char GetChannel();

	// Object: Function AkAudio.AkMIDIEventCallbackInfo.GetCc
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102121e4c
	// Return & Params: [ Num(2) Size(0x5) ]
	bool GetCc(struct FAkMidiCc& AsCc);
};

// Object: Class AkAudio.AkMarkerCallbackInfo
// Inherited Bytes: 0x38 | Struct Size: 0x50
struct UAkMarkerCallbackInfo : UAkEventCallbackInfo {
	// Fields
	int32_t Identifier; // Offset: 0x38 | Size: 0x4
	int32_t Position; // Offset: 0x3c | Size: 0x4
	struct FString Label; // Offset: 0x40 | Size: 0x10
};

// Object: Class AkAudio.AkDurationCallbackInfo
// Inherited Bytes: 0x38 | Struct Size: 0x50
struct UAkDurationCallbackInfo : UAkEventCallbackInfo {
	// Fields
	float Duration; // Offset: 0x38 | Size: 0x4
	float EstimatedDuration; // Offset: 0x3c | Size: 0x4
	int32_t AudioNodeID; // Offset: 0x40 | Size: 0x4
	int32_t MediaID; // Offset: 0x44 | Size: 0x4
	bool bStreaming; // Offset: 0x48 | Size: 0x1
	char pad_0x49[0x7]; // Offset: 0x49 | Size: 0x7
};

// Object: Class AkAudio.AkMusicSyncCallbackInfo
// Inherited Bytes: 0x30 | Struct Size: 0x70
struct UAkMusicSyncCallbackInfo : UAkCallbackInfo {
	// Fields
	int32_t PlayingID; // Offset: 0x30 | Size: 0x4
	struct FAkSegmentInfo SegmentInfo; // Offset: 0x34 | Size: 0x24
	enum class EAkCallbackType MusicSyncType; // Offset: 0x58 | Size: 0x1
	char pad_0x59[0x7]; // Offset: 0x59 | Size: 0x7
	struct FString UserCueName; // Offset: 0x60 | Size: 0x10
};

// Object: Class AkAudio.AkGeometryComponent
// Inherited Bytes: 0x370 | Struct Size: 0x4f0
struct UAkGeometryComponent : UAkAcousticTextureSetComponent {
	// Fields
	enum class AkMeshType MeshType; // Offset: 0x369 | Size: 0x1
	int32_t LOD; // Offset: 0x36c | Size: 0x4
	float WeldingThreshold; // Offset: 0x370 | Size: 0x4
	struct TMap<struct UMaterialInterface*, struct FAkGeometrySurfaceOverride> StaticMeshSurfaceOverride; // Offset: 0x378 | Size: 0x50
	struct FAkGeometrySurfaceOverride CollisionMeshSurfaceOverride; // Offset: 0x3c8 | Size: 0x18
	char bEnableDiffraction : 1; // Offset: 0x3e0 | Size: 0x1
	char bEnableDiffractionOnBoundaryEdges : 1; // Offset: 0x3e0 | Size: 0x1
	char pad_0x3E1_2 : 6; // Offset: 0x3e1 | Size: 0x1
	char pad_0x3E2[0x6]; // Offset: 0x3e2 | Size: 0x6
	struct AActor* AssociatedRoom; // Offset: 0x3e8 | Size: 0x8
	char pad_0x3F0[0x10]; // Offset: 0x3f0 | Size: 0x10
	struct FAkGeometryData GeometryData; // Offset: 0x400 | Size: 0x50
	struct TMap<int32_t, float> SurfaceAreas; // Offset: 0x450 | Size: 0x50
	char pad_0x4A0[0x50]; // Offset: 0x4a0 | Size: 0x50

	// Functions

	// Object: Function AkAudio.AkGeometryComponent.UpdateGeometry
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102122e44
	// Return & Params: [ Num(0) Size(0x0) ]
	void UpdateGeometry();

	// Object: Function AkAudio.AkGeometryComponent.SendGeometry
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102122e30
	// Return & Params: [ Num(0) Size(0x0) ]
	void SendGeometry();

	// Object: Function AkAudio.AkGeometryComponent.RemoveGeometry
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102122e58
	// Return & Params: [ Num(0) Size(0x0) ]
	void RemoveGeometry();

	// Object: Function AkAudio.AkGeometryComponent.ConvertMesh
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102122e6c
	// Return & Params: [ Num(0) Size(0x0) ]
	void ConvertMesh();
};

// Object: Class AkAudio.AkGroupValue
// Inherited Bytes: 0x40 | Struct Size: 0x68
struct UAkGroupValue : UAkAudioType {
	// Fields
	struct TArray<struct TSoftObjectPtr<UAkMediaAsset>> MediaDependencies; // Offset: 0x40 | Size: 0x10
	uint32_t GroupShortID; // Offset: 0x50 | Size: 0x4
	char pad_0x54[0x14]; // Offset: 0x54 | Size: 0x14
};

// Object: Class AkAudio.AkHololensInitializationSettings
// Inherited Bytes: 0x28 | Struct Size: 0xf0
struct UAkHololensInitializationSettings : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
	struct FAkCommonInitializationSettingsWithSampleRate CommonSettings; // Offset: 0x30 | Size: 0x68
	struct FAkCommunicationSettingsWithSystemInitialization CommunicationSettings; // Offset: 0x98 | Size: 0x28
	struct FAkHololensAdvancedInitializationSettings AdvancedSettings; // Offset: 0xc0 | Size: 0x30

	// Functions

	// Object: Function AkAudio.AkHololensInitializationSettings.MigrateMultiCoreRendering
	// Flags: [Final|Native|Public]
	// Offset: 0x1021238fc
	// Return & Params: [ Num(1) Size(0x1) ]
	void MigrateMultiCoreRendering(bool NewValue);
};

// Object: Class AkAudio.AkHololensPlatformInfo
// Inherited Bytes: 0x70 | Struct Size: 0x70
struct UAkHololensPlatformInfo : UAkPlatformInfo {
};

// Object: Class AkAudio.AkInitBankAssetData
// Inherited Bytes: 0x70 | Struct Size: 0x80
struct UAkInitBankAssetData : UAkAssetDataWithMedia {
	// Fields
	struct TArray<struct FAkPluginInfo> PluginInfos; // Offset: 0x70 | Size: 0x10
};

// Object: Class AkAudio.AkInitBank
// Inherited Bytes: 0x50 | Struct Size: 0x70
struct UAkInitBank : UAkAssetBase {
	// Fields
	struct TArray<struct FString> AvailableAudioCultures; // Offset: 0x50 | Size: 0x10
	struct FString DefaultLanguage; // Offset: 0x60 | Size: 0x10
};

// Object: Class AkAudio.AkIOSInitializationSettings
// Inherited Bytes: 0x28 | Struct Size: 0x100
struct UAkIOSInitializationSettings : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
	struct FAkCommonInitializationSettingsWithSampleRate CommonSettings; // Offset: 0x30 | Size: 0x68
	struct FAkAudioSession AudioSession; // Offset: 0x98 | Size: 0xc
	char pad_0xA4[0x4]; // Offset: 0xa4 | Size: 0x4
	struct FAkCommunicationSettingsWithSystemInitialization CommunicationSettings; // Offset: 0xa8 | Size: 0x28
	struct FAkAdvancedInitializationSettings AdvancedSettings; // Offset: 0xd0 | Size: 0x2c
	char pad_0xFC[0x4]; // Offset: 0xfc | Size: 0x4
};

// Object: Class AkAudio.AkIOSPlatformInfo
// Inherited Bytes: 0x70 | Struct Size: 0x70
struct UAkIOSPlatformInfo : UAkPlatformInfo {
};

// Object: Class AkAudio.AkItemBoolPropertiesConv
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UAkItemBoolPropertiesConv : UBlueprintFunctionLibrary {
	// Functions

	// Object: Function AkAudio.AkItemBoolPropertiesConv.Conv_FAkBoolPropertyToControlToText
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x10212ac14
	// Return & Params: [ Num(2) Size(0x28) ]
	struct FText Conv_FAkBoolPropertyToControlToText(struct FAkBoolPropertyToControl& INAkBoolPropertyToControl);

	// Object: Function AkAudio.AkItemBoolPropertiesConv.Conv_FAkBoolPropertyToControlToString
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x10212ad20
	// Return & Params: [ Num(2) Size(0x20) ]
	struct FString Conv_FAkBoolPropertyToControlToString(struct FAkBoolPropertyToControl& INAkBoolPropertyToControl);
};

// Object: Class AkAudio.AkItemBoolProperties
// Inherited Bytes: 0x138 | Struct Size: 0x178
struct UAkItemBoolProperties : UWidget {
	// Fields
	struct FMulticastInlineDelegate OnSelectionChanged; // Offset: 0x138 | Size: 0x10
	struct FMulticastInlineDelegate OnPropertyDragged; // Offset: 0x148 | Size: 0x10
	char pad_0x158[0x20]; // Offset: 0x158 | Size: 0x20

	// Functions

	// Object: Function AkAudio.AkItemBoolProperties.SetSearchText
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x10212b05c
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetSearchText(struct FString newText);

	// Object: Function AkAudio.AkItemBoolProperties.GetSelectedProperty
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10212b168
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetSelectedProperty();

	// Object: Function AkAudio.AkItemBoolProperties.GetSearchText
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10212b0e8
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetSearchText();
};

// Object: Class AkAudio.AkItemPropertiesConv
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UAkItemPropertiesConv : UBlueprintFunctionLibrary {
	// Functions

	// Object: Function AkAudio.AkItemPropertiesConv.Conv_FAkPropertyToControlToText
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x10212b618
	// Return & Params: [ Num(2) Size(0x28) ]
	struct FText Conv_FAkPropertyToControlToText(struct FAkPropertyToControl& INAkPropertyToControl);

	// Object: Function AkAudio.AkItemPropertiesConv.Conv_FAkPropertyToControlToString
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x10212b724
	// Return & Params: [ Num(2) Size(0x20) ]
	struct FString Conv_FAkPropertyToControlToString(struct FAkPropertyToControl& INAkPropertyToControl);
};

// Object: Class AkAudio.AkItemProperties
// Inherited Bytes: 0x138 | Struct Size: 0x178
struct UAkItemProperties : UWidget {
	// Fields
	struct FMulticastInlineDelegate OnSelectionChanged; // Offset: 0x138 | Size: 0x10
	struct FMulticastInlineDelegate OnPropertyDragged; // Offset: 0x148 | Size: 0x10
	char pad_0x158[0x20]; // Offset: 0x158 | Size: 0x20

	// Functions

	// Object: Function AkAudio.AkItemProperties.SetSearchText
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x10212ba60
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetSearchText(struct FString newText);

	// Object: Function AkAudio.AkItemProperties.GetSelectedProperty
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10212bb6c
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetSelectedProperty();

	// Object: Function AkAudio.AkItemProperties.GetSearchText
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10212baec
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetSearchText();
};

// Object: Class AkAudio.AkLateReverbComponent
// Inherited Bytes: 0x360 | Struct Size: 0x3e0
struct UAkLateReverbComponent : USceneComponent {
	// Fields
	char bEnable : 1; // Offset: 0x354 | Size: 0x1
	float SendLevel; // Offset: 0x358 | Size: 0x4
	float FadeRate; // Offset: 0x35c | Size: 0x4
	float Priority; // Offset: 0x360 | Size: 0x4
	bool AutoAssignAuxBus; // Offset: 0x364 | Size: 0x1
	struct UAkAuxBus* AuxBus; // Offset: 0x368 | Size: 0x8
	struct FString AuxBusName; // Offset: 0x370 | Size: 0x10
	char pad_0x385_1 : 7; // Offset: 0x385 | Size: 0x1
	char pad_0x386[0x2]; // Offset: 0x386 | Size: 0x2
	struct UAkAuxBus* AuxBusManual; // Offset: 0x388 | Size: 0x8
	char pad_0x390[0x50]; // Offset: 0x390 | Size: 0x50

	// Functions

	// Object: Function AkAudio.AkLateReverbComponent.AssociateAkTextureSetComponent
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10212beac
	// Return & Params: [ Num(1) Size(0x8) ]
	void AssociateAkTextureSetComponent(struct UAkAcousticTextureSetComponent* textureSetComponent);
};

// Object: Class AkAudio.AkLinuxInitializationSettings
// Inherited Bytes: 0x28 | Struct Size: 0xf0
struct UAkLinuxInitializationSettings : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
	struct FAkCommonInitializationSettingsWithSampleRate CommonSettings; // Offset: 0x30 | Size: 0x68
	struct FAkCommunicationSettingsWithSystemInitialization CommunicationSettings; // Offset: 0x98 | Size: 0x28
	struct FAkAdvancedInitializationSettingsWithMultiCoreRendering AdvancedSettings; // Offset: 0xc0 | Size: 0x30

	// Functions

	// Object: Function AkAudio.AkLinuxInitializationSettings.MigrateMultiCoreRendering
	// Flags: [Final|Native|Public]
	// Offset: 0x10212c2fc
	// Return & Params: [ Num(1) Size(0x1) ]
	void MigrateMultiCoreRendering(bool NewValue);
};

// Object: Class AkAudio.AkLinuxPlatformInfo
// Inherited Bytes: 0x70 | Struct Size: 0x70
struct UAkLinuxPlatformInfo : UAkPlatformInfo {
};

// Object: Class AkAudio.AkMacInitializationSettings
// Inherited Bytes: 0x28 | Struct Size: 0xf0
struct UAkMacInitializationSettings : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
	struct FAkCommonInitializationSettingsWithSampleRate CommonSettings; // Offset: 0x30 | Size: 0x68
	struct FAkCommunicationSettingsWithSystemInitialization CommunicationSettings; // Offset: 0x98 | Size: 0x28
	struct FAkAdvancedInitializationSettingsWithMultiCoreRendering AdvancedSettings; // Offset: 0xc0 | Size: 0x30

	// Functions

	// Object: Function AkAudio.AkMacInitializationSettings.MigrateMultiCoreRendering
	// Flags: [Final|Native|Public]
	// Offset: 0x10212c6c0
	// Return & Params: [ Num(1) Size(0x1) ]
	void MigrateMultiCoreRendering(bool NewValue);
};

// Object: Class AkAudio.AkMacPlatformInfo
// Inherited Bytes: 0x70 | Struct Size: 0x70
struct UAkMacPlatformInfo : UAkPlatformInfo {
};

// Object: Class AkAudio.AkMediaAssetData
// Inherited Bytes: 0x28 | Struct Size: 0x60
struct UAkMediaAssetData : UObject {
	// Fields
	bool IsStreamed; // Offset: 0x28 | Size: 0x1
	bool UseDeviceMemory; // Offset: 0x29 | Size: 0x1
	char pad_0x2A[0x36]; // Offset: 0x2a | Size: 0x36
};

// Object: Class AkAudio.AkMediaAsset
// Inherited Bytes: 0x28 | Struct Size: 0x58
struct UAkMediaAsset : UObject {
	// Fields
	uint32_t ID; // Offset: 0x28 | Size: 0x4
	bool AutoLoad; // Offset: 0x2c | Size: 0x1
	char pad_0x2D[0x3]; // Offset: 0x2d | Size: 0x3
	struct TArray<struct UObject*> UserData; // Offset: 0x30 | Size: 0x10
	struct UAkMediaAssetData* CurrentMediaAssetData; // Offset: 0x40 | Size: 0x8
	char pad_0x48[0x10]; // Offset: 0x48 | Size: 0x10
};

// Object: Class AkAudio.AkLocalizedMediaAsset
// Inherited Bytes: 0x58 | Struct Size: 0x58
struct UAkLocalizedMediaAsset : UAkMediaAsset {
};

// Object: Class AkAudio.AkExternalMediaAsset
// Inherited Bytes: 0x58 | Struct Size: 0xb0
struct UAkExternalMediaAsset : UAkMediaAsset {
	// Fields
	char pad_0x58[0x58]; // Offset: 0x58 | Size: 0x58
};

// Object: Class AkAudio.AkPlatformInitialisationSettingsBase
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UAkPlatformInitialisationSettingsBase : UInterface {
};

// Object: Class AkAudio.AkPS4InitializationSettings
// Inherited Bytes: 0x28 | Struct Size: 0xf0
struct UAkPS4InitializationSettings : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
	struct FAkCommonInitializationSettings CommonSettings; // Offset: 0x30 | Size: 0x60
	struct FAkCommunicationSettingsWithSystemInitialization CommunicationSettings; // Offset: 0x90 | Size: 0x28
	struct FAkPS4AdvancedInitializationSettings AdvancedSettings; // Offset: 0xb8 | Size: 0x38

	// Functions

	// Object: Function AkAudio.AkPS4InitializationSettings.MigrateMultiCoreRendering
	// Flags: [Final|Native|Public]
	// Offset: 0x10212d688
	// Return & Params: [ Num(1) Size(0x1) ]
	void MigrateMultiCoreRendering(bool NewValue);
};

// Object: Class AkAudio.AkPS4PlatformInfo
// Inherited Bytes: 0x70 | Struct Size: 0x70
struct UAkPS4PlatformInfo : UAkPlatformInfo {
};

// Object: Class AkAudio.AkReverbVolume
// Inherited Bytes: 0x268 | Struct Size: 0x2a0
struct AAkReverbVolume : AVolume {
	// Fields
	char bEnabled : 1; // Offset: 0x268 | Size: 0x1
	char pad_0x268_1 : 7; // Offset: 0x268 | Size: 0x1
	char pad_0x269[0x7]; // Offset: 0x269 | Size: 0x7
	struct UAkAuxBus* AuxBus; // Offset: 0x270 | Size: 0x8
	struct FString AuxBusName; // Offset: 0x278 | Size: 0x10
	float SendLevel; // Offset: 0x288 | Size: 0x4
	float FadeRate; // Offset: 0x28c | Size: 0x4
	float Priority; // Offset: 0x290 | Size: 0x4
	char pad_0x294[0x4]; // Offset: 0x294 | Size: 0x4
	struct UAkLateReverbComponent* LateReverbComponent; // Offset: 0x298 | Size: 0x8
};

// Object: Class AkAudio.AkRoomComponent
// Inherited Bytes: 0x380 | Struct Size: 0x3a0
struct UAkRoomComponent : UAkGameObject {
	// Fields
	char bEnable : 1; // Offset: 0x372 | Size: 0x1
	bool bDynamic; // Offset: 0x373 | Size: 0x1
	float Priority; // Offset: 0x374 | Size: 0x4
	float WallOcclusion; // Offset: 0x378 | Size: 0x4
	float AuxSendLevel; // Offset: 0x37c | Size: 0x4
	bool AutoPost; // Offset: 0x380 | Size: 0x1
	char pad_0x38E_1 : 7; // Offset: 0x38e | Size: 0x1
	char pad_0x38F[0x1]; // Offset: 0x38f | Size: 0x1
	struct UAkAcousticTextureSetComponent* GeometryComponent; // Offset: 0x390 | Size: 0x8
	char pad_0x398[0x8]; // Offset: 0x398 | Size: 0x8

	// Functions

	// Object: Function AkAudio.AkRoomComponent.GetPrimitiveParent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10212dc64
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UPrimitiveComponent* GetPrimitiveParent();
};

// Object: Class AkAudio.AkRtpc
// Inherited Bytes: 0x40 | Struct Size: 0x40
struct UAkRtpc : UAkAudioType {
};

// Object: Class AkAudio.AkSettings
// Inherited Bytes: 0x28 | Struct Size: 0x2b8
struct UAkSettings : UObject {
	// Fields
	char MaxSimultaneousReverbVolumes; // Offset: 0x28 | Size: 0x1
	char pad_0x29[0x7]; // Offset: 0x29 | Size: 0x7
	struct FFilePath WwiseProjectPath; // Offset: 0x30 | Size: 0x10
	struct FDirectoryPath WwiseSoundDataFolder; // Offset: 0x40 | Size: 0x10
	bool bAutoConnectToWAAPI; // Offset: 0x50 | Size: 0x1
	enum class ECollisionChannel DefaultOcclusionCollisionChannel; // Offset: 0x51 | Size: 0x1
	enum class ECollisionChannel DefaultFitToGeometryCollisionChannel; // Offset: 0x52 | Size: 0x1
	char pad_0x53[0x5]; // Offset: 0x53 | Size: 0x5
	struct TMap<struct TSoftObjectPtr<UPhysicalMaterial>, struct FAkGeometrySurfacePropertiesToMap> AkGeometryMap; // Offset: 0x58 | Size: 0x50
	float GlobalDecayAbsorption; // Offset: 0xa8 | Size: 0x4
	char pad_0xAC[0x4]; // Offset: 0xac | Size: 0x4
	struct TSoftObjectPtr<UAkAuxBus> DefaultReverbAuxBus; // Offset: 0xb0 | Size: 0x28
	struct TMap<float, struct TSoftObjectPtr<UAkAuxBus>> EnvironmentDecayAuxBusMap; // Offset: 0xd8 | Size: 0x50
	struct FString HFDampingName; // Offset: 0x128 | Size: 0x10
	struct FString DecayEstimateName; // Offset: 0x138 | Size: 0x10
	struct FString TimeToFirstReflectionName; // Offset: 0x148 | Size: 0x10
	struct TSoftObjectPtr<UAkRtpc> HFDampingRTPC; // Offset: 0x158 | Size: 0x28
	struct TSoftObjectPtr<UAkRtpc> DecayEstimateRTPC; // Offset: 0x180 | Size: 0x28
	struct TSoftObjectPtr<UAkRtpc> TimeToFirstReflectionRTPC; // Offset: 0x1a8 | Size: 0x28
	struct TMap<struct FGuid, struct FAkAcousticTextureParams> AcousticTextureParamsMap; // Offset: 0x1d0 | Size: 0x50
	bool SplitSwitchContainerMedia; // Offset: 0x220 | Size: 0x1
	bool SplitMediaPerFolder; // Offset: 0x221 | Size: 0x1
	bool UseEventBasedPackaging; // Offset: 0x222 | Size: 0x1
	bool EnableAutomaticAssetSynchronization; // Offset: 0x223 | Size: 0x1
	char pad_0x224[0x4]; // Offset: 0x224 | Size: 0x4
	struct FString CommandletCommitMessage; // Offset: 0x228 | Size: 0x10
	struct TMap<struct FString, struct FString> UnrealCultureToWwiseCulture; // Offset: 0x238 | Size: 0x50
	bool AskedToUseNewAssetManagement; // Offset: 0x288 | Size: 0x1
	bool bEnableMultiCoreRendering; // Offset: 0x289 | Size: 0x1
	bool MigratedEnableMultiCoreRendering; // Offset: 0x28a | Size: 0x1
	bool FixupRedirectorsDuringMigration; // Offset: 0x28b | Size: 0x1
	char pad_0x28C[0x4]; // Offset: 0x28c | Size: 0x4
	struct FDirectoryPath WwiseWindowsInstallationPath; // Offset: 0x290 | Size: 0x10
	struct FFilePath WwiseMacInstallationPath; // Offset: 0x2a0 | Size: 0x10
	char pad_0x2B0[0x8]; // Offset: 0x2b0 | Size: 0x8
};

// Object: Class AkAudio.AkSettingsPerUser
// Inherited Bytes: 0x28 | Struct Size: 0x80
struct UAkSettingsPerUser : UObject {
	// Fields
	struct FDirectoryPath WwiseWindowsInstallationPath; // Offset: 0x28 | Size: 0x10
	struct FFilePath WwiseMacInstallationPath; // Offset: 0x38 | Size: 0x10
	bool EnableAutomaticAssetSynchronization; // Offset: 0x48 | Size: 0x1
	char pad_0x49[0x7]; // Offset: 0x49 | Size: 0x7
	struct FString WaapiIPAddress; // Offset: 0x50 | Size: 0x10
	uint32_t WaapiPort; // Offset: 0x60 | Size: 0x4
	bool bAutoConnectToWAAPI; // Offset: 0x64 | Size: 0x1
	bool AutoSyncSelection; // Offset: 0x65 | Size: 0x1
	bool SuppressWwiseProjectPathWarnings; // Offset: 0x66 | Size: 0x1
	bool SoundDataGenerationSkipLanguage; // Offset: 0x67 | Size: 0x1
	char pad_0x68[0x18]; // Offset: 0x68 | Size: 0x18
};

// Object: Class AkAudio.AkSlider
// Inherited Bytes: 0x138 | Struct Size: 0x7e0
struct UAkSlider : UWidget {
	// Fields
	float Value; // Offset: 0x138 | Size: 0x4
	struct FDelegate ValueDelegate; // Offset: 0x13c | Size: 0x10
	char pad_0x14C[0x4]; // Offset: 0x14c | Size: 0x4
	struct FSliderStyle WidgetStyle; // Offset: 0x150 | Size: 0x5c0
	enum class EOrientation Orientation; // Offset: 0x710 | Size: 0x1
	char pad_0x711[0x3]; // Offset: 0x711 | Size: 0x3
	struct FLinearColor SliderBarColor; // Offset: 0x714 | Size: 0x10
	struct FLinearColor SliderHandleColor; // Offset: 0x724 | Size: 0x10
	bool IndentHandle; // Offset: 0x734 | Size: 0x1
	bool Locked; // Offset: 0x735 | Size: 0x1
	char pad_0x736[0x2]; // Offset: 0x736 | Size: 0x2
	float StepSize; // Offset: 0x738 | Size: 0x4
	bool IsFocusable; // Offset: 0x73c | Size: 0x1
	char pad_0x73D[0x3]; // Offset: 0x73d | Size: 0x3
	struct FAkPropertyToControl ThePropertyToControl; // Offset: 0x740 | Size: 0x10
	struct FAkWwiseItemToControl ItemToControl; // Offset: 0x750 | Size: 0x40
	struct FMulticastInlineDelegate OnValueChanged; // Offset: 0x790 | Size: 0x10
	struct FMulticastInlineDelegate OnItemDropped; // Offset: 0x7a0 | Size: 0x10
	struct FMulticastInlineDelegate OnPropertyDropped; // Offset: 0x7b0 | Size: 0x10
	char pad_0x7C0[0x20]; // Offset: 0x7c0 | Size: 0x20

	// Functions

	// Object: Function AkAudio.AkSlider.SetValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10212f030
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetValue(float InValue);

	// Object: Function AkAudio.AkSlider.SetStepSize
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10212eea0
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetStepSize(float InValue);

	// Object: Function AkAudio.AkSlider.SetSliderHandleColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x10212eda0
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetSliderHandleColor(struct FLinearColor InValue);

	// Object: Function AkAudio.AkSlider.SetSliderBarColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x10212ee20
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetSliderBarColor(struct FLinearColor InValue);

	// Object: Function AkAudio.AkSlider.SetLocked
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10212ef20
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetLocked(bool InValue);

	// Object: Function AkAudio.AkSlider.SetIndentHandle
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10212efa8
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetIndentHandle(bool InValue);

	// Object: Function AkAudio.AkSlider.SetAkSliderItemProperty
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10212ec54
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetAkSliderItemProperty(struct FString ItemProperty);

	// Object: Function AkAudio.AkSlider.SetAkSliderItemId
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x10212ed14
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetAkSliderItemId(struct FGuid& ItemID);

	// Object: Function AkAudio.AkSlider.GetValue
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10212f0b0
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetValue();

	// Object: Function AkAudio.AkSlider.GetAkSliderItemProperty
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10212ebb4
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetAkSliderItemProperty();

	// Object: Function AkAudio.AkSlider.GetAkSliderItemId
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10212ece0
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FGuid GetAkSliderItemId();
};

// Object: Class AkAudio.AkSpatialAudioVolume
// Inherited Bytes: 0x268 | Struct Size: 0x280
struct AAkSpatialAudioVolume : AVolume {
	// Fields
	struct UAkSurfaceReflectorSetComponent* SurfaceReflectorSet; // Offset: 0x268 | Size: 0x8
	struct UAkLateReverbComponent* LateReverb; // Offset: 0x270 | Size: 0x8
	struct UAkRoomComponent* Room; // Offset: 0x278 | Size: 0x8
};

// Object: Class AkAudio.AkSpotReflector
// Inherited Bytes: 0x230 | Struct Size: 0x258
struct AAkSpotReflector : AActor {
	// Fields
	struct UAkAuxBus* EarlyReflectionAuxBus; // Offset: 0x230 | Size: 0x8
	struct FString EarlyReflectionAuxBusName; // Offset: 0x238 | Size: 0x10
	struct UAkAcousticTexture* AcousticTexture; // Offset: 0x248 | Size: 0x8
	float DistanceScalingFactor; // Offset: 0x250 | Size: 0x4
	float Level; // Offset: 0x254 | Size: 0x4
};

// Object: Class AkAudio.AkStateValue
// Inherited Bytes: 0x68 | Struct Size: 0x68
struct UAkStateValue : UAkGroupValue {
};

// Object: Class AkAudio.AkSurfaceReflectorSetComponent
// Inherited Bytes: 0x370 | Struct Size: 0x3a0
struct UAkSurfaceReflectorSetComponent : UAkAcousticTextureSetComponent {
	// Fields
	char bEnableSurfaceReflectors : 1; // Offset: 0x369 | Size: 0x1
	struct TArray<struct FAkPoly> AcousticPolys; // Offset: 0x370 | Size: 0x10
	char bEnableDiffraction : 1; // Offset: 0x380 | Size: 0x1
	char bEnableDiffractionOnBoundaryEdges : 1; // Offset: 0x380 | Size: 0x1
	char pad_0x380_3 : 5; // Offset: 0x380 | Size: 0x1
	char pad_0x381[0x7]; // Offset: 0x381 | Size: 0x7
	struct AActor* AssociatedRoom; // Offset: 0x388 | Size: 0x8
	char pad_0x390[0x10]; // Offset: 0x390 | Size: 0x10

	// Functions

	// Object: Function AkAudio.AkSurfaceReflectorSetComponent.UpdateSurfaceReflectorSet
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102134134
	// Return & Params: [ Num(0) Size(0x0) ]
	void UpdateSurfaceReflectorSet();

	// Object: Function AkAudio.AkSurfaceReflectorSetComponent.SendSurfaceReflectorSet
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10213415c
	// Return & Params: [ Num(0) Size(0x0) ]
	void SendSurfaceReflectorSet();

	// Object: Function AkAudio.AkSurfaceReflectorSetComponent.RemoveSurfaceReflectorSet
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102134148
	// Return & Params: [ Num(0) Size(0x0) ]
	void RemoveSurfaceReflectorSet();
};

// Object: Class AkAudio.AkSwitchInitializationSettings
// Inherited Bytes: 0x28 | Struct Size: 0xf0
struct UAkSwitchInitializationSettings : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
	struct FAkCommonInitializationSettingsWithSampleRate CommonSettings; // Offset: 0x30 | Size: 0x68
	struct FAkCommunicationSettingsWithCommSelection CommunicationSettings; // Offset: 0x98 | Size: 0x28
	struct FAkAdvancedInitializationSettingsWithMultiCoreRendering AdvancedSettings; // Offset: 0xc0 | Size: 0x30

	// Functions

	// Object: Function AkAudio.AkSwitchInitializationSettings.MigrateMultiCoreRendering
	// Flags: [Final|Native|Public]
	// Offset: 0x102134520
	// Return & Params: [ Num(1) Size(0x1) ]
	void MigrateMultiCoreRendering(bool NewValue);
};

// Object: Class AkAudio.AkSwitchPlatformInfo
// Inherited Bytes: 0x70 | Struct Size: 0x70
struct UAkSwitchPlatformInfo : UAkPlatformInfo {
};

// Object: Class AkAudio.AkSwitchValue
// Inherited Bytes: 0x68 | Struct Size: 0x68
struct UAkSwitchValue : UAkGroupValue {
};

// Object: Class AkAudio.AkTrigger
// Inherited Bytes: 0x40 | Struct Size: 0x40
struct UAkTrigger : UAkAudioType {
};

// Object: Class AkAudio.AkTVOSInitializationSettings
// Inherited Bytes: 0x28 | Struct Size: 0x100
struct UAkTVOSInitializationSettings : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
	struct FAkCommonInitializationSettingsWithSampleRate CommonSettings; // Offset: 0x30 | Size: 0x68
	struct FAkAudioSession AudioSession; // Offset: 0x98 | Size: 0xc
	char pad_0xA4[0x4]; // Offset: 0xa4 | Size: 0x4
	struct FAkCommunicationSettingsWithSystemInitialization CommunicationSettings; // Offset: 0xa8 | Size: 0x28
	struct FAkAdvancedInitializationSettings AdvancedSettings; // Offset: 0xd0 | Size: 0x2c
	char pad_0xFC[0x4]; // Offset: 0xfc | Size: 0x4
};

// Object: Class AkAudio.AkTVOSPlatformInfo
// Inherited Bytes: 0x70 | Struct Size: 0x70
struct UAkTVOSPlatformInfo : UAkPlatformInfo {
};

// Object: Class AkAudio.AkWaapiCalls
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UAkWaapiCalls : UBlueprintFunctionLibrary {
	// Functions

	// Object: Function AkAudio.AkWaapiCalls.Unsubscribe
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1021352f0
	// Return & Params: [ Num(3) Size(0x20) ]
	struct FAKWaapiJsonObject Unsubscribe(struct FAkWaapiSubscriptionId& SubscriptionId, bool& UnsubscriptionDone);

	// Object: Function AkAudio.AkWaapiCalls.SubscribeToWaapi
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1021354bc
	// Return & Params: [ Num(6) Size(0x50) ]
	struct FAKWaapiJsonObject SubscribeToWaapi(struct FAkWaapiUri& WaapiUri, struct FAKWaapiJsonObject& WaapiOptions, struct FDelegate& Callback, struct FAkWaapiSubscriptionId& SubscriptionId, bool& SubscriptionDone);

	// Object: Function AkAudio.AkWaapiCalls.SetSubscriptionID
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102135dac
	// Return & Params: [ Num(2) Size(0xc) ]
	void SetSubscriptionID(struct FAkWaapiSubscriptionId& Subscription, int32_t ID);

	// Object: Function AkAudio.AkWaapiCalls.RegisterWaapiProjectLoadedCallback
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102135c78
	// Return & Params: [ Num(2) Size(0x11) ]
	bool RegisterWaapiProjectLoadedCallback(struct FDelegate& Callback);

	// Object: Function AkAudio.AkWaapiCalls.RegisterWaapiConnectionLostCallback
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102135bd0
	// Return & Params: [ Num(2) Size(0x11) ]
	bool RegisterWaapiConnectionLostCallback(struct FDelegate& Callback);

	// Object: Function AkAudio.AkWaapiCalls.GetSubscriptionID
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102135d20
	// Return & Params: [ Num(2) Size(0xc) ]
	int32_t GetSubscriptionID(struct FAkWaapiSubscriptionId& Subscription);

	// Object: Function AkAudio.AkWaapiCalls.Conv_FAkWaapiSubscriptionIdToText
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x102135120
	// Return & Params: [ Num(2) Size(0x20) ]
	struct FText Conv_FAkWaapiSubscriptionIdToText(struct FAkWaapiSubscriptionId& INAkWaapiSubscriptionId);

	// Object: Function AkAudio.AkWaapiCalls.Conv_FAkWaapiSubscriptionIdToString
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x102135220
	// Return & Params: [ Num(2) Size(0x18) ]
	struct FString Conv_FAkWaapiSubscriptionIdToString(struct FAkWaapiSubscriptionId& INAkWaapiSubscriptionId);

	// Object: Function AkAudio.AkWaapiCalls.CallWaapi
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102135850
	// Return & Params: [ Num(4) Size(0x40) ]
	struct FAKWaapiJsonObject CallWaapi(struct FAkWaapiUri& WaapiUri, struct FAKWaapiJsonObject& WaapiArgs, struct FAKWaapiJsonObject& WaapiOptions);
};

// Object: Class AkAudio.SAkWaapiFieldNamesConv
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct USAkWaapiFieldNamesConv : UBlueprintFunctionLibrary {
	// Functions

	// Object: Function AkAudio.SAkWaapiFieldNamesConv.Conv_FAkWaapiFieldNamesToText
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x102136460
	// Return & Params: [ Num(2) Size(0x28) ]
	struct FText Conv_FAkWaapiFieldNamesToText(struct FAkWaapiFieldNames& INAkWaapiFieldNames);

	// Object: Function AkAudio.SAkWaapiFieldNamesConv.Conv_FAkWaapiFieldNamesToString
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x10213656c
	// Return & Params: [ Num(2) Size(0x20) ]
	struct FString Conv_FAkWaapiFieldNamesToString(struct FAkWaapiFieldNames& INAkWaapiFieldNames);
};

// Object: Class AkAudio.AkWaapiJsonManager
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UAkWaapiJsonManager : UBlueprintFunctionLibrary {
	// Functions

	// Object: Function AkAudio.AkWaapiJsonManager.SetStringField
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102138ec0
	// Return & Params: [ Num(4) Size(0x40) ]
	struct FAKWaapiJsonObject SetStringField(struct FAkWaapiFieldNames& FieldName, struct FString FieldValue, struct FAKWaapiJsonObject Target);

	// Object: Function AkAudio.AkWaapiJsonManager.SetObjectField
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1021383dc
	// Return & Params: [ Num(4) Size(0x40) ]
	struct FAKWaapiJsonObject SetObjectField(struct FAkWaapiFieldNames& FieldName, struct FAKWaapiJsonObject FieldValue, struct FAKWaapiJsonObject Target);

	// Object: Function AkAudio.AkWaapiJsonManager.SetNumberField
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102138840
	// Return & Params: [ Num(4) Size(0x38) ]
	struct FAKWaapiJsonObject SetNumberField(struct FAkWaapiFieldNames& FieldName, float FieldValue, struct FAKWaapiJsonObject Target);

	// Object: Function AkAudio.AkWaapiJsonManager.SetBoolField
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102138b78
	// Return & Params: [ Num(4) Size(0x38) ]
	struct FAKWaapiJsonObject SetBoolField(struct FAkWaapiFieldNames& FieldName, bool FieldValue, struct FAKWaapiJsonObject Target);

	// Object: Function AkAudio.AkWaapiJsonManager.SetArrayStringFields
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10213804c
	// Return & Params: [ Num(4) Size(0x40) ]
	struct FAKWaapiJsonObject SetArrayStringFields(struct FAkWaapiFieldNames& FieldName, struct TArray<struct FString>& FieldStringValues, struct FAKWaapiJsonObject Target);

	// Object: Function AkAudio.AkWaapiJsonManager.SetArrayObjectFields
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102137c68
	// Return & Params: [ Num(4) Size(0x40) ]
	struct FAKWaapiJsonObject SetArrayObjectFields(struct FAkWaapiFieldNames& FieldName, struct TArray<struct FAKWaapiJsonObject>& FieldObjectValues, struct FAKWaapiJsonObject Target);

	// Object: Function AkAudio.AkWaapiJsonManager.GetStringField
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102137a1c
	// Return & Params: [ Num(3) Size(0x30) ]
	struct FString GetStringField(struct FAkWaapiFieldNames& FieldName, struct FAKWaapiJsonObject Target);

	// Object: Function AkAudio.AkWaapiJsonManager.GetObjectField
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1021370f4
	// Return & Params: [ Num(3) Size(0x30) ]
	struct FAKWaapiJsonObject GetObjectField(struct FAkWaapiFieldNames& FieldName, struct FAKWaapiJsonObject Target);

	// Object: Function AkAudio.AkWaapiJsonManager.GetNumberField
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1021375fc
	// Return & Params: [ Num(3) Size(0x24) ]
	float GetNumberField(struct FAkWaapiFieldNames& FieldName, struct FAKWaapiJsonObject Target);

	// Object: Function AkAudio.AkWaapiJsonManager.GetIntegerField
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1021373ec
	// Return & Params: [ Num(3) Size(0x24) ]
	int32_t GetIntegerField(struct FAkWaapiFieldNames& FieldName, struct FAKWaapiJsonObject Target);

	// Object: Function AkAudio.AkWaapiJsonManager.GetBoolField
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10213780c
	// Return & Params: [ Num(3) Size(0x21) ]
	bool GetBoolField(struct FAkWaapiFieldNames& FieldName, struct FAKWaapiJsonObject Target);

	// Object: Function AkAudio.AkWaapiJsonManager.GetArrayField
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102136d4c
	// Return & Params: [ Num(3) Size(0x30) ]
	struct TArray<struct FAKWaapiJsonObject> GetArrayField(struct FAkWaapiFieldNames& FieldName, struct FAKWaapiJsonObject Target);

	// Object: Function AkAudio.AkWaapiJsonManager.Conv_FAKWaapiJsonObjectToText
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x102136934
	// Return & Params: [ Num(2) Size(0x28) ]
	struct FText Conv_FAKWaapiJsonObjectToText(struct FAKWaapiJsonObject INAKWaapiJsonObject);

	// Object: Function AkAudio.AkWaapiJsonManager.Conv_FAKWaapiJsonObjectToString
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x102136b5c
	// Return & Params: [ Num(2) Size(0x20) ]
	struct FString Conv_FAKWaapiJsonObjectToString(struct FAKWaapiJsonObject INAKWaapiJsonObject);
};

// Object: Class AkAudio.AkWaapiUriConv
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UAkWaapiUriConv : UBlueprintFunctionLibrary {
	// Functions

	// Object: Function AkAudio.AkWaapiUriConv.Conv_FAkWaapiUriToText
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x1021398a4
	// Return & Params: [ Num(2) Size(0x28) ]
	struct FText Conv_FAkWaapiUriToText(struct FAkWaapiUri& INAkWaapiUri);

	// Object: Function AkAudio.AkWaapiUriConv.Conv_FAkWaapiUriToString
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x1021399b0
	// Return & Params: [ Num(2) Size(0x20) ]
	struct FString Conv_FAkWaapiUriToString(struct FAkWaapiUri& INAkWaapiUri);
};

// Object: Class AkAudio.AkWindowsInitializationSettings
// Inherited Bytes: 0x28 | Struct Size: 0xf8
struct UAkWindowsInitializationSettings : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
	struct FAkCommonInitializationSettingsWithSampleRate CommonSettings; // Offset: 0x30 | Size: 0x68
	struct FAkCommunicationSettingsWithSystemInitialization CommunicationSettings; // Offset: 0x98 | Size: 0x28
	struct FAkWindowsAdvancedInitializationSettings AdvancedSettings; // Offset: 0xc0 | Size: 0x34
	char pad_0xF4[0x4]; // Offset: 0xf4 | Size: 0x4

	// Functions

	// Object: Function AkAudio.AkWindowsInitializationSettings.MigrateMultiCoreRendering
	// Flags: [Final|Native|Public]
	// Offset: 0x102139dd0
	// Return & Params: [ Num(1) Size(0x1) ]
	void MigrateMultiCoreRendering(bool NewValue);
};

// Object: Class AkAudio.AkWin32PlatformInfo
// Inherited Bytes: 0x70 | Struct Size: 0x70
struct UAkWin32PlatformInfo : UAkPlatformInfo {
};

// Object: Class AkAudio.AkWin64PlatformInfo
// Inherited Bytes: 0x70 | Struct Size: 0x70
struct UAkWin64PlatformInfo : UAkPlatformInfo {
};

// Object: Class AkAudio.AkWindowsPlatformInfo
// Inherited Bytes: 0x70 | Struct Size: 0x70
struct UAkWindowsPlatformInfo : UAkWin64PlatformInfo {
};

// Object: Class AkAudio.AkWwiseTree
// Inherited Bytes: 0x138 | Struct Size: 0x178
struct UAkWwiseTree : UWidget {
	// Fields
	struct FMulticastInlineDelegate OnSelectionChanged; // Offset: 0x138 | Size: 0x10
	struct FMulticastInlineDelegate OnItemDragged; // Offset: 0x148 | Size: 0x10
	char pad_0x158[0x20]; // Offset: 0x158 | Size: 0x20

	// Functions

	// Object: Function AkAudio.AkWwiseTree.SetSearchText
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x10213a480
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetSearchText(struct FString newText);

	// Object: Function AkAudio.AkWwiseTree.GetSelectedItem
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10213a58c
	// Return & Params: [ Num(1) Size(0x30) ]
	struct FAkWwiseObjectDetails GetSelectedItem();

	// Object: Function AkAudio.AkWwiseTree.GetSearchText
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10213a50c
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetSearchText();
};

// Object: Class AkAudio.AkWwiseTreeSelector
// Inherited Bytes: 0x138 | Struct Size: 0x198
struct UAkWwiseTreeSelector : UWidget {
	// Fields
	struct FMulticastInlineDelegate OnSelectionChanged; // Offset: 0x138 | Size: 0x10
	struct FMulticastInlineDelegate OnItemDragged; // Offset: 0x148 | Size: 0x10
	char pad_0x158[0x40]; // Offset: 0x158 | Size: 0x40
};

// Object: Class AkAudio.AkXboxOneInitializationSettings
// Inherited Bytes: 0x28 | Struct Size: 0xf8
struct UAkXboxOneInitializationSettings : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
	struct FAkCommonInitializationSettings CommonSettings; // Offset: 0x30 | Size: 0x60
	struct FAkXboxOneApuHeapInitializationSettings ApuHeapSettings; // Offset: 0x90 | Size: 0x8
	struct FAkCommunicationSettingsWithSystemInitialization CommunicationSettings; // Offset: 0x98 | Size: 0x28
	struct FAkXboxOneAdvancedInitializationSettings AdvancedSettings; // Offset: 0xc0 | Size: 0x34
	char pad_0xF4[0x4]; // Offset: 0xf4 | Size: 0x4

	// Functions

	// Object: Function AkAudio.AkXboxOneInitializationSettings.MigrateMultiCoreRendering
	// Flags: [Final|Native|Public]
	// Offset: 0x10213abfc
	// Return & Params: [ Num(1) Size(0x1) ]
	void MigrateMultiCoreRendering(bool NewValue);
};

// Object: Class AkAudio.AkXboxOnePlatformInfo
// Inherited Bytes: 0x70 | Struct Size: 0x70
struct UAkXboxOnePlatformInfo : UAkPlatformInfo {
};

// Object: Class AkAudio.AudioManager
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UAudioManager : UBlueprintFunctionLibrary {
	// Functions

	// Object: Function AkAudio.AudioManager.UnmuteWwiseAudio
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102140348
	// Return & Params: [ Num(0) Size(0x0) ]
	void UnmuteWwiseAudio();

	// Object: Function AkAudio.AudioManager.UnloadBankByName
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102141c00
	// Return & Params: [ Num(5) Size(0x21) ]
	bool UnloadBankByName(struct FString BankName, bool Async, bool IgnoreCounter, struct UObject* Context);

	// Object: Function AkAudio.AudioManager.UnloadBank
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102141d90
	// Return & Params: [ Num(5) Size(0x19) ]
	bool UnloadBank(struct UAkAudioBank* BankReference, bool Async, bool IgnoreCounter, struct UObject* Context);

	// Object: Function AkAudio.AudioManager.StopEventByName
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1021413c4
	// Return & Params: [ Num(4) Size(0x1d) ]
	bool StopEventByName(struct FString EventName, struct UAkGameObject* Emitter, float FadeOutTime);

	// Object: Function AkAudio.AudioManager.StopEvent
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1021414e8
	// Return & Params: [ Num(4) Size(0x15) ]
	bool StopEvent(struct UAkAudioEvent* EventReference, struct UAkGameObject* Emitter, float FadeOutTime);

	// Object: Function AkAudio.AudioManager.SetVoiceVolume
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102140370
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetVoiceVolume(float Volume);

	// Object: Function AkAudio.AudioManager.SetVoiceEnabled
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1021404d8
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetVoiceEnabled(bool Enabled);

	// Object: Function AkAudio.AudioManager.SetSwitch
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102140d24
	// Return & Params: [ Num(4) Size(0x29) ]
	bool SetSwitch(struct FString SwitchGroupName, struct FString SwitchName, struct UAkGameObject* Target);

	// Object: Function AkAudio.AudioManager.SetState
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102140ffc
	// Return & Params: [ Num(4) Size(0x29) ]
	bool SetState(struct FString StateGroupName, struct FString StateName, struct UObject* Context);

	// Object: Function AkAudio.AudioManager.SetSoundVolume
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102140460
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetSoundVolume(float Volume);

	// Object: Function AkAudio.AudioManager.SetSoundEnabled
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1021405d8
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetSoundEnabled(bool Enabled);

	// Object: Function AkAudio.AudioManager.SetMusicVolume
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1021403e8
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetMusicVolume(float Volume);

	// Object: Function AkAudio.AudioManager.SetMusicEnabled
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102140558
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetMusicEnabled(bool Enabled);

	// Object: Function AkAudio.AudioManager.SetGlobalRTPC
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102140808
	// Return & Params: [ Num(5) Size(0x21) ]
	bool SetGlobalRTPC(struct FString ParameterName, float Value, float UpdateTolerance, struct UObject* Context);

	// Object: Function AkAudio.AudioManager.SetEmitterRTPC
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102140974
	// Return & Params: [ Num(5) Size(0x25) ]
	bool SetEmitterRTPC(struct FString ParameterName, float Value, struct UAkGameObject* Emitter, float UpdateTolerance);

	// Object: Function AkAudio.AudioManager.ResetRTPCValue
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102140730
	// Return & Params: [ Num(3) Size(0x19) ]
	bool ResetRTPCValue(struct FString ParameterName, struct UAkGameObject* Emitter);

	// Object: Function AkAudio.AudioManager.PlayEventAtLocationByName
	// Flags: [Final|Native|Static|Public|HasDefaults]
	// Offset: 0x1021415fc
	// Return & Params: [ Num(5) Size(0x34) ]
	uint32_t PlayEventAtLocationByName(struct FString EventName, struct FVector Location, struct FRotator Rotation, struct UObject* Context);

	// Object: Function AkAudio.AudioManager.PlayEventAtLocation
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x102141764
	// Return & Params: [ Num(5) Size(0x2c) ]
	int32_t PlayEventAtLocation(struct UAkAudioEvent* EventReference, struct FVector Location, struct FRotator Rotation, struct UObject* Context);

	// Object: Function AkAudio.AudioManager.PlayEvent3DByName
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1021418c0
	// Return & Params: [ Num(3) Size(0x1c) ]
	int32_t PlayEvent3DByName(struct FString EventName, struct UAkGameObject* Emitter);

	// Object: Function AkAudio.AudioManager.PlayEvent3D
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102141998
	// Return & Params: [ Num(3) Size(0x14) ]
	int32_t PlayEvent3D(struct UAkAudioEvent* EventReference, struct UAkGameObject* Emitter);

	// Object: Function AkAudio.AudioManager.PlayEvent2DByName
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102141a60
	// Return & Params: [ Num(3) Size(0x1c) ]
	int32_t PlayEvent2DByName(struct FString EventName, struct UObject* Context);

	// Object: Function AkAudio.AudioManager.PlayEvent2D
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102141b38
	// Return & Params: [ Num(3) Size(0x14) ]
	int32_t PlayEvent2D(struct UAkAudioEvent* EventReference, struct UObject* Context);

	// Object: Function AkAudio.AudioManager.MuteWwiseAudio
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10214035c
	// Return & Params: [ Num(0) Size(0x0) ]
	void MuteWwiseAudio();

	// Object: Function AkAudio.AudioManager.LoadBankByName
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102141f14
	// Return & Params: [ Num(4) Size(0x21) ]
	bool LoadBankByName(struct FString BankName, bool Async, struct UObject* Context);

	// Object: Function AkAudio.AudioManager.LoadBank
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10214204c
	// Return & Params: [ Num(4) Size(0x19) ]
	bool LoadBank(struct UAkAudioBank* BankReference, bool Async, struct UObject* Context);

	// Object: Function AkAudio.AudioManager.IsSwitchAt
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102140bf4
	// Return & Params: [ Num(4) Size(0x29) ]
	bool IsSwitchAt(struct FString SwitchGroupName, struct FString SwitchName, struct UAkGameObject* Target);

	// Object: Function AkAudio.AudioManager.IsStateAt
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102140f18
	// Return & Params: [ Num(3) Size(0x21) ]
	bool IsStateAt(struct FString StateGroupName, struct FString StateName);

	// Object: Function AkAudio.AudioManager.IsEventPlaying
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10214112c
	// Return & Params: [ Num(3) Size(0x19) ]
	bool IsEventPlaying(struct FString EventName, struct UAkGameObject* Emitter);

	// Object: Function AkAudio.AudioManager.GetSwitch
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102140ae4
	// Return & Params: [ Num(3) Size(0x28) ]
	struct FString GetSwitch(struct FString SwitchGroupName, struct UAkGameObject* Target);

	// Object: Function AkAudio.AudioManager.GetState
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102140e54
	// Return & Params: [ Num(2) Size(0x20) ]
	struct FString GetState(struct FString StateGroupName);

	// Object: Function AkAudio.AudioManager.GetRTPCValue
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102140658
	// Return & Params: [ Num(3) Size(0x1c) ]
	float GetRTPCValue(struct FString ParameterName, struct UAkGameObject* Emitter);

	// Object: Function AkAudio.AudioManager.ExecuteActionOnEvent
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102141204
	// Return & Params: [ Num(5) Size(0x21) ]
	bool ExecuteActionOnEvent(struct FString EventName, struct UAkGameObject* Emitter, enum class AkActionOnEventType ActionType, float FadeTime);
};

// Object: Class AkAudio.BankHandler
// Inherited Bytes: 0x28 | Struct Size: 0x68
struct UBankHandler : UObject {
	// Fields
	char pad_0x28[0x40]; // Offset: 0x28 | Size: 0x40

	// Functions

	// Object: Function AkAudio.BankHandler.OnBankAsyncUnloaded
	// Flags: [Final|Native|Public]
	// Offset: 0x102142ea4
	// Return & Params: [ Num(2) Size(0x8) ]
	void OnBankAsyncUnloaded(enum class EAkResult Result, uint32_t BankId);

	// Object: Function AkAudio.BankHandler.OnBankAsyncLoaded
	// Flags: [Final|Native|Public]
	// Offset: 0x102142f70
	// Return & Params: [ Num(2) Size(0x8) ]
	void OnBankAsyncLoaded(enum class EAkResult Result, uint32_t BankId);
};

// Object: Class AkAudio.BankManager
// Inherited Bytes: 0x30 | Struct Size: 0x110
struct UBankManager : UGameInstanceSubsystem {
	// Fields
	char pad_0x30[0x10]; // Offset: 0x30 | Size: 0x10
	struct TMap<struct FName, struct FName> EventToBankMap; // Offset: 0x40 | Size: 0x50
	char pad_0x90[0x20]; // Offset: 0x90 | Size: 0x20
	struct TMap<struct FName, struct UBankHandler*> AllBanks; // Offset: 0xb0 | Size: 0x50
	struct TArray<struct UBankHandler*> AutoUnloadBanksToCheck; // Offset: 0x100 | Size: 0x10

	// Functions

	// Object: Function AkAudio.BankManager.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x102143430
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UBankManager* GetInstance(struct UObject* WorldContextObject);
};

// Object: Class AkAudio.EmitterManager
// Inherited Bytes: 0x30 | Struct Size: 0x100
struct UEmitterManager : UWorldSubsystem {
	// Fields
	char pad_0x30[0x10]; // Offset: 0x30 | Size: 0x10
	struct TArray<struct UAkComponent*> TickableEmitters; // Offset: 0x40 | Size: 0x10
	char pad_0x50[0x8]; // Offset: 0x50 | Size: 0x8
	struct UAkComponent* SelfEmitter; // Offset: 0x58 | Size: 0x8
	struct TMap<struct UAkGameObject*, struct FCachedGameSyncData> EmitterGameSyncData; // Offset: 0x60 | Size: 0x50
	struct TMap<struct AActor*, struct FEventCooldownData> EmitterCooldownData; // Offset: 0xb0 | Size: 0x50

	// Functions

	// Object: Function AkAudio.EmitterManager.SetSelfEmitter
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102143b98
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetSelfEmitter(struct UAkComponent* Emitter);

	// Object: Function AkAudio.EmitterManager.RemoveSelfEmitter
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102143aa0
	// Return & Params: [ Num(1) Size(0x8) ]
	void RemoveSelfEmitter(struct UObject* WorldContextObject);

	// Object: Function AkAudio.EmitterManager.IsSelfEmitter
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102143b18
	// Return & Params: [ Num(2) Size(0x9) ]
	bool IsSelfEmitter(struct UAkComponent* Emitter);

	// Object: Function AkAudio.EmitterManager.GetSelfEmitter
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102143c10
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UAkComponent* GetSelfEmitter(struct UObject* WorldContextObject);

	// Object: Function AkAudio.EmitterManager.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x102143c90
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UEmitterManager* GetInstance(struct UObject* WorldContextObject);
};

// Object: Class AkAudio.InterpTrackAkAudioEvent
// Inherited Bytes: 0x90 | Struct Size: 0xa8
struct UInterpTrackAkAudioEvent : UInterpTrackVectorBase {
	// Fields
	struct TArray<struct FAkAudioEventTrackKey> Events; // Offset: 0x90 | Size: 0x10
	char bContinueEventOnMatineeEnd : 1; // Offset: 0xa0 | Size: 0x1
	char pad_0xA0_1 : 7; // Offset: 0xa0 | Size: 0x1
	char pad_0xA1[0x7]; // Offset: 0xa1 | Size: 0x7
};

// Object: Class AkAudio.InterpTrackAkAudioRTPC
// Inherited Bytes: 0x90 | Struct Size: 0xa8
struct UInterpTrackAkAudioRTPC : UInterpTrackFloatBase {
	// Fields
	struct FString Param; // Offset: 0x90 | Size: 0x10
	char bPlayOnReverse : 1; // Offset: 0xa0 | Size: 0x1
	char bContinueRTPCOnMatineeEnd : 1; // Offset: 0xa0 | Size: 0x1
	char pad_0xA0_2 : 6; // Offset: 0xa0 | Size: 0x1
	char pad_0xA1[0x7]; // Offset: 0xa1 | Size: 0x7
};

// Object: Class AkAudio.InterpTrackInstAkAudioEvent
// Inherited Bytes: 0x28 | Struct Size: 0x30
struct UInterpTrackInstAkAudioEvent : UInterpTrackInst {
	// Fields
	float LastUpdatePosition; // Offset: 0x28 | Size: 0x4
	char pad_0x2C[0x4]; // Offset: 0x2c | Size: 0x4
};

// Object: Class AkAudio.InterpTrackInstAkAudioRTPC
// Inherited Bytes: 0x28 | Struct Size: 0x30
struct UInterpTrackInstAkAudioRTPC : UInterpTrackInst {
	// Fields
	float LastUpdatePosition; // Offset: 0x28 | Size: 0x4
	char pad_0x2C[0x4]; // Offset: 0x2c | Size: 0x4
};

// Object: Class AkAudio.ListenerManager
// Inherited Bytes: 0x30 | Struct Size: 0x58
struct UListenerManager : UWorldSubsystem {
	// Fields
	char pad_0x30[0x10]; // Offset: 0x30 | Size: 0x10
	struct TArray<struct UAkComponent*> DefaultListeners; // Offset: 0x40 | Size: 0x10
	struct UAkComponent* SpatialAudioListener; // Offset: 0x50 | Size: 0x8

	// Functions

	// Object: Function AkAudio.ListenerManager.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1021448ac
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UListenerManager* GetInstance(struct UObject* WorldContextObject);
};

// Object: Class AkAudio.MovieSceneAkAudioEventSection
// Inherited Bytes: 0xd8 | Struct Size: 0x1d8
struct UMovieSceneAkAudioEventSection : UMovieSceneSection {
	// Fields
	char pad_0xD8[0x58]; // Offset: 0xd8 | Size: 0x58
	struct UAkAudioEvent* Event; // Offset: 0x130 | Size: 0x8
	bool RetriggerEvent; // Offset: 0x138 | Size: 0x1
	char pad_0x139[0x3]; // Offset: 0x139 | Size: 0x3
	int32_t ScrubTailLengthMs; // Offset: 0x13c | Size: 0x4
	bool StopAtSectionEnd; // Offset: 0x140 | Size: 0x1
	char pad_0x141[0x7]; // Offset: 0x141 | Size: 0x7
	struct FString EventName; // Offset: 0x148 | Size: 0x10
	char pad_0x158[0x20]; // Offset: 0x158 | Size: 0x20
	float MaxSourceDuration; // Offset: 0x178 | Size: 0x4
	char pad_0x17C[0x4]; // Offset: 0x17c | Size: 0x4
	struct FString MaxDurationSourceID; // Offset: 0x180 | Size: 0x10
	char pad_0x190[0x48]; // Offset: 0x190 | Size: 0x48
};

// Object: Class AkAudio.MovieSceneAkTrack
// Inherited Bytes: 0x58 | Struct Size: 0x70
struct UMovieSceneAkTrack : UMovieSceneTrack {
	// Fields
	struct TArray<struct UMovieSceneSection*> Sections; // Offset: 0x58 | Size: 0x10
	char bIsAMasterTrack : 1; // Offset: 0x68 | Size: 0x1
	char pad_0x68_1 : 7; // Offset: 0x68 | Size: 0x1
	char pad_0x69[0x7]; // Offset: 0x69 | Size: 0x7
};

// Object: Class AkAudio.MovieSceneAkAudioEventTrack
// Inherited Bytes: 0x70 | Struct Size: 0x70
struct UMovieSceneAkAudioEventTrack : UMovieSceneAkTrack {
};

// Object: Class AkAudio.MovieSceneAkAudioRTPCSection
// Inherited Bytes: 0xd8 | Struct Size: 0x240
struct UMovieSceneAkAudioRTPCSection : UMovieSceneSection {
	// Fields
	struct UAkRtpc* RTPC; // Offset: 0xd8 | Size: 0x8
	struct FString Name; // Offset: 0xe0 | Size: 0x10
	struct FRichCurve FloatCurve; // Offset: 0xf0 | Size: 0x80
	struct FMovieSceneFloatChannelSerializationHelper FloatChannelSerializationHelper; // Offset: 0x170 | Size: 0x30
	struct FMovieSceneFloatChannel RTPCChannel; // Offset: 0x1a0 | Size: 0xa0
};

// Object: Class AkAudio.MovieSceneAkAudioRTPCTrack
// Inherited Bytes: 0x70 | Struct Size: 0x70
struct UMovieSceneAkAudioRTPCTrack : UMovieSceneAkTrack {
};

// Object: Class AkAudio.PostEventAsync
// Inherited Bytes: 0x30 | Struct Size: 0xa0
struct UPostEventAsync : UBlueprintAsyncActionBase {
	// Fields
	struct FMulticastInlineDelegate Completed; // Offset: 0x30 | Size: 0x10
	char pad_0x40[0x60]; // Offset: 0x40 | Size: 0x60

	// Functions

	// Object: Function AkAudio.PostEventAsync.PostEventAsync
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102145af8
	// Return & Params: [ Num(8) Size(0x50) ]
	struct UPostEventAsync* PostEventAsync(struct UObject* WorldContextObject, struct UAkAudioEvent* AkEvent, struct AActor* Actor, int32_t CallbackMask, struct FDelegate& PostEventCallback, struct TArray<struct FAkExternalSourceInfo>& ExternalSources, bool bStopWhenAttachedToDestroyed);

	// Object: Function AkAudio.PostEventAsync.PollPostEventFuture
	// Flags: [Final|Native|Private]
	// Offset: 0x102145ae4
	// Return & Params: [ Num(0) Size(0x0) ]
	void PollPostEventFuture();
};

// Object: Class AkAudio.PostEventAtLocationAsync
// Inherited Bytes: 0x30 | Struct Size: 0x80
struct UPostEventAtLocationAsync : UBlueprintAsyncActionBase {
	// Fields
	struct FMulticastInlineDelegate Completed; // Offset: 0x30 | Size: 0x10
	char pad_0x40[0x40]; // Offset: 0x40 | Size: 0x40

	// Functions

	// Object: Function AkAudio.PostEventAtLocationAsync.PostEventAtLocationAsync
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x102149438
	// Return & Params: [ Num(5) Size(0x30) ]
	struct UPostEventAtLocationAsync* PostEventAtLocationAsync(struct UObject* WorldContextObject, struct UAkAudioEvent* AkEvent, struct FVector Location, struct FRotator Orientation);

	// Object: Function AkAudio.PostEventAtLocationAsync.PollPostEventFuture
	// Flags: [Final|Native|Private]
	// Offset: 0x102149424
	// Return & Params: [ Num(0) Size(0x0) ]
	void PollPostEventFuture();
};

// Object: Class AkAudio.SpatialAudioManager
// Inherited Bytes: 0x30 | Struct Size: 0x30
struct USpatialAudioManager : UWorldSubsystem {
	// Functions

	// Object: Function AkAudio.SpatialAudioManager.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x102149ae0
	// Return & Params: [ Num(2) Size(0x10) ]
	struct USpatialAudioManager* GetInstance(struct UObject* WorldContextObject);
};

// Object: Class AkAudio.WwiseDataQuery
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UWwiseDataQuery : UObject {
};

