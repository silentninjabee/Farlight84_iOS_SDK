#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: DynamicClass Anim_LobbyCharacter_FS_Normal.Anim_LobbyCharacter_FS_Normal_C
// Inherited Bytes: 0x740 | Struct Size: 0x740
struct UAnim_LobbyCharacter_FS_Normal_C : UAnim_LobbyCharacter_Default_C {
};

