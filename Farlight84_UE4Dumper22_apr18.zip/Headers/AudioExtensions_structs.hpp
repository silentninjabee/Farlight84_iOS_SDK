#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct AudioExtensions.SoundModulationParameter
// Inherited Bytes: 0x0 | Struct Size: 0x14
struct FSoundModulationParameter {
	// Fields
	struct FName Control; // Offset: 0x0 | Size: 0x8
	float Value; // Offset: 0x8 | Size: 0x4
	char pad_0xC[0x8]; // Offset: 0xc | Size: 0x8
};

// Object: ScriptStruct AudioExtensions.SoundModulation
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FSoundModulation {
	// Fields
	struct TArray<struct USoundModulationPluginSourceSettingsBase*> Settings; // Offset: 0x0 | Size: 0x10
};

