#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BPC_EXPSpringModeComponent.BPC_EXPSpringModeComponent_C
// Inherited Bytes: 0x1b0 | Struct Size: 0x1b8
struct UBPC_EXPSpringModeComponent_C : USolarExpSpringModeComponent {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x1b0 | Size: 0x8

	// Functions

	// Object: Function BPC_EXPSpringModeComponent.BPC_EXPSpringModeComponent_C.GetExpSpringExpNum
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(3) Size(0xc) ]
	int32_t GetExpSpringExpNum(int32_t FullExpOut, char OnSpringTeamNum);

	// Object: Function BPC_EXPSpringModeComponent.BPC_EXPSpringModeComponent_C.GetExpSpringOpenNum
	// Flags: [Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(3) Size(0x3) ]
	char GetExpSpringOpenNum(char DefaultOpenNum, char LiveTeamNum);

	// Object: Function BPC_EXPSpringModeComponent.BPC_EXPSpringModeComponent_C.CreateAirDrop
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x4) ]
	void CreateAirDrop(int32_t ChestID);

	// Object: Function BPC_EXPSpringModeComponent.BPC_EXPSpringModeComponent_C.ExecuteUbergraph_BPC_EXPSpringModeComponent
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_BPC_EXPSpringModeComponent(int32_t EntryPoint);
};

