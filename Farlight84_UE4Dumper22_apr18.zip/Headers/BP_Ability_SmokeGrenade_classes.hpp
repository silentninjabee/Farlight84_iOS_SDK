#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_Ability_SmokeGrenade.BP_Ability_SmokeGrenade_C
// Inherited Bytes: 0x230 | Struct Size: 0x280
struct ABP_Ability_SmokeGrenade_C : AWeaponHitAbility {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x230 | Size: 0x8
	struct UParticleSystemComponent* FX_SmokeShell; // Offset: 0x238 | Size: 0x8
	struct UAkComponent* AkAudioComponent; // Offset: 0x240 | Size: 0x8
	struct USphereComponent* Sphere; // Offset: 0x248 | Size: 0x8
	struct USolarGameplaySmokeComponent* Smoke; // Offset: 0x250 | Size: 0x8
	float SmokeFadeOut_Alpha_3E9C3E664BF7E30B8AC9DD9276A8ACCE; // Offset: 0x258 | Size: 0x4
	enum class ETimelineDirection SmokeFadeOut__Direction_3E9C3E664BF7E30B8AC9DD9276A8ACCE; // Offset: 0x25c | Size: 0x1
	char pad_0x25D[0x3]; // Offset: 0x25d | Size: 0x3
	struct UTimelineComponent* SmokeFadeOut; // Offset: 0x260 | Size: 0x8
	float SmokeFadeIn_Alpha_3B8839634FFDF220C79937AFE6C47DC9; // Offset: 0x268 | Size: 0x4
	enum class ETimelineDirection SmokeFadeIn__Direction_3B8839634FFDF220C79937AFE6C47DC9; // Offset: 0x26c | Size: 0x1
	char pad_0x26D[0x3]; // Offset: 0x26d | Size: 0x3
	struct UTimelineComponent* SmokeFadeIn; // Offset: 0x270 | Size: 0x8
	int32_t TranslucentSortPriority; // Offset: 0x278 | Size: 0x4
	float SmokeVFXLifeTime; // Offset: 0x27c | Size: 0x4

	// Functions

	// Object: Function BP_Ability_SmokeGrenade.BP_Ability_SmokeGrenade_C.SmokeFadeIn__FinishedFunc
	// Flags: [BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(0) Size(0x0) ]
	void SmokeFadeIn__FinishedFunc();

	// Object: Function BP_Ability_SmokeGrenade.BP_Ability_SmokeGrenade_C.SmokeFadeIn__UpdateFunc
	// Flags: [BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(0) Size(0x0) ]
	void SmokeFadeIn__UpdateFunc();

	// Object: Function BP_Ability_SmokeGrenade.BP_Ability_SmokeGrenade_C.SmokeFadeOut__FinishedFunc
	// Flags: [BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(0) Size(0x0) ]
	void SmokeFadeOut__FinishedFunc();

	// Object: Function BP_Ability_SmokeGrenade.BP_Ability_SmokeGrenade_C.SmokeFadeOut__UpdateFunc
	// Flags: [BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(0) Size(0x0) ]
	void SmokeFadeOut__UpdateFunc();

	// Object: Function BP_Ability_SmokeGrenade.BP_Ability_SmokeGrenade_C.ReceiveBeginPlay
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(0) Size(0x0) ]
	void ReceiveBeginPlay();

	// Object: Function BP_Ability_SmokeGrenade.BP_Ability_SmokeGrenade_C.ReceiveEndPlay
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x1) ]
	void ReceiveEndPlay(enum class EEndPlayReason EndPlayReason);

	// Object: Function BP_Ability_SmokeGrenade.BP_Ability_SmokeGrenade_C.ExecuteUbergraph_BP_Ability_SmokeGrenade
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_BP_Ability_SmokeGrenade(int32_t EntryPoint);
};

