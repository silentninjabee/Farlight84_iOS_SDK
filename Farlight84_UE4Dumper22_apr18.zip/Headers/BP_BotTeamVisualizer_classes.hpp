#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_BotTeamVisualizer.BP_BotTeamVisualizer_C
// Inherited Bytes: 0x3a8 | Struct Size: 0x3a8
struct ABP_BotTeamVisualizer_C : ASolarBotTeamVisualizer {
};

