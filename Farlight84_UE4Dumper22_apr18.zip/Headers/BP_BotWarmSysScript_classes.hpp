#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_BotWarmSysScript.BP_BotWarmSysScript_C
// Inherited Bytes: 0x278 | Struct Size: 0x278
struct UBP_BotWarmSysScript_C : USolarBotWarmSystemScript {
};

