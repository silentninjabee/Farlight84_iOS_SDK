#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_Character_BattleRoyale.BP_Character_BattleRoyale_C
// Inherited Bytes: 0x2a78 | Struct Size: 0x2b10
struct ABP_Character_BattleRoyale_C : ABP_Character_Framework_C {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x2a78 | Size: 0x8
	struct FMulticastInlineDelegate OnPlayerRevive; // Offset: 0x2a80 | Size: 0x10
	struct UActorMarkBase* DeathBoxMark; // Offset: 0x2a90 | Size: 0x8
	struct TArray<struct UMapMarkBase*> DeathBoxMiniMapMark; // Offset: 0x2a98 | Size: 0x10
	int32_t Index; // Offset: 0x2aa8 | Size: 0x4
	int32_t UI_Relive_StartTime; // Offset: 0x2aac | Size: 0x4
	struct FTimerHandle LandedDetectionHandel; // Offset: 0x2ab0 | Size: 0x8
	struct ABP_SI_RebornLine_C* RebornLine; // Offset: 0x2ab8 | Size: 0x8
	struct TMap<int32_t, float> Level-Damage; // Offset: 0x2ac0 | Size: 0x50

	// Functions

	// Object: Function BP_Character_BattleRoyale.BP_Character_BattleRoyale_C.GetWeaponLevelDamageBonus
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x4) ]
	void GetWeaponLevelDamageBonus(float& Result);

	// Object: Function BP_Character_BattleRoyale.BP_Character_BattleRoyale_C.Death Cleanup UI
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(0) Size(0x0) ]
	void Death Cleanup UI();

	// Object: Function BP_Character_BattleRoyale.BP_Character_BattleRoyale_C.TakeDamageResolve
	// Flags: [Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(5) Size(0x124) ]
	float TakeDamageResolve(float Damage, struct FSolarPointDamageEvent& DamageEvent, struct ASCMPlayerState* EventInstigator, struct AActor* DamageCauser);

	// Object: Function BP_Character_BattleRoyale.BP_Character_BattleRoyale_C.OnShouldTakeDamage
	// Flags: [Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x104039718
	// Return & Params: [ Num(5) Size(0x121) ]
	bool OnShouldTakeDamage(float Damage, struct FSolarPointDamageEvent& DamageEvent, struct ASCMPlayerState* EventInstigator, struct AActor* DamageCauser);

	// Object: Function BP_Character_BattleRoyale.BP_Character_BattleRoyale_C.SetReviveCameraFade
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetReviveCameraFade(float Time);

	// Object: Function BP_Character_BattleRoyale.BP_Character_BattleRoyale_C.ReceiveBeginPlay
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(0) Size(0x0) ]
	void ReceiveBeginPlay();

	// Object: Function BP_Character_BattleRoyale.BP_Character_BattleRoyale_C.Debug Set DayAndNightTime
	// Flags: [Net|NetServer|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x4) ]
	void Debug Set DayAndNightTime(float Time);

	// Object: Function BP_Character_BattleRoyale.BP_Character_BattleRoyale_C.SetMapID
	// Flags: [Net|NetMulticast|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetMapID(int32_t mapID);

	// Object: Function BP_Character_BattleRoyale.BP_Character_BattleRoyale_C.BeginPlayBlueprint
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(0) Size(0x0) ]
	void BeginPlayBlueprint();

	// Object: Function BP_Character_BattleRoyale.BP_Character_BattleRoyale_C.OnCharacterEjectStateChanged
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnCharacterEjectStateChanged(enum class ECharacterEjectState State);

	// Object: Function BP_Character_BattleRoyale.BP_Character_BattleRoyale_C.ExecuteUbergraph_BP_Character_BattleRoyale
	// Flags: [Final|UbergraphFunction|HasDefaults]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_BP_Character_BattleRoyale(int32_t EntryPoint);

	// Object: Function BP_Character_BattleRoyale.BP_Character_BattleRoyale_C.OnPlayerRevive__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x8) ]
	void OnPlayerRevive__DelegateSignature(struct ASolarCharacter* TargetCharacter);
};

