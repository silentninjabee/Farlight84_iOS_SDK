#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_ConfigSave.BP_ConfigSave_C
// Inherited Bytes: 0x28 | Struct Size: 0x119
struct UBP_ConfigSave_C : USaveGame {
	// Fields
	bool bEnableAiTeammate; // Offset: 0x28 | Size: 0x1
	bool bEnableCustomRoom; // Offset: 0x29 | Size: 0x1
	char pad_0x2A[0x6]; // Offset: 0x2a | Size: 0x6
	struct FCustomRoomData CustomRoomConfig; // Offset: 0x30 | Size: 0xe8
	bool bIsCustomRoomHost; // Offset: 0x118 | Size: 0x1
};

