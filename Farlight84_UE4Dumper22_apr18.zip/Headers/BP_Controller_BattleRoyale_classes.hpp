#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_Controller_BattleRoyale.BP_Controller_BattleRoyale_C
// Inherited Bytes: 0x10bc | Struct Size: 0x10bc
struct ABP_Controller_BattleRoyale_C : ABP_Controller_Framework_C {
};

