#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_DGActiveMatEffect.BP_DGActiveMatEffect_C
// Inherited Bytes: 0x1d0 | Struct Size: 0x1d0
struct UBP_DGActiveMatEffect_C : UMaterialVariableEffect {
};

