#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_DefenderManager.BP_DefenderManager_C
// Inherited Bytes: 0x2b0 | Struct Size: 0x2d2
struct ABP_DefenderManager_C : ADefenderManager {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x2b0 | Size: 0x8
	struct UUI_OpeningShow_C* DefenderUI; // Offset: 0x2b8 | Size: 0x8
	float ShowTime-Defender; // Offset: 0x2c0 | Size: 0x4
	float ShowTime-Self; // Offset: 0x2c4 | Size: 0x4
	enum class E_State_DefenderManager UiState; // Offset: 0x2c8 | Size: 0x1
	char pad_0x2C9[0x3]; // Offset: 0x2c9 | Size: 0x3
	int32_t TerminatorReward; // Offset: 0x2cc | Size: 0x4
	bool DataReady; // Offset: 0x2d0 | Size: 0x1
	bool bBattleStarted; // Offset: 0x2d1 | Size: 0x1

	// Functions

	// Object: Function BP_DefenderManager.BP_DefenderManager_C.GetTotalTime
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetTotalTime();

	// Object: Function BP_DefenderManager.BP_DefenderManager_C.OnRep_BattleStarted
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnRep_BattleStarted();

	// Object: Function BP_DefenderManager.BP_DefenderManager_C.DataTraceDefender
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x104039718
	// Return & Params: [ Num(3) Size(0x28) ]
	void DataTraceDefender(struct ASolarPlayerState* Target, struct FString& Name, struct FString& Data);

	// Object: Function BP_DefenderManager.BP_DefenderManager_C.GetExtraReward
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x4) ]
	void GetExtraReward(int32_t& Reward);

	// Object: Function BP_DefenderManager.BP_DefenderManager_C.SetShowTime
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(2) Size(0x8) ]
	void SetShowTime(float ShowTime-Self, float ShowTime-Defender);

	// Object: Function BP_DefenderManager.BP_DefenderManager_C.GetUI
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x8) ]
	void GetUI(struct UUI_OpeningShow_C*& Output_Get);

	// Object: Function BP_DefenderManager.BP_DefenderManager_C.OnRep_UIState
	// Flags: [HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnRep_UIState();

	// Object: Function BP_DefenderManager.BP_DefenderManager_C.ReceiveBeginPlay
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(0) Size(0x0) ]
	void ReceiveBeginPlay();

	// Object: Function BP_DefenderManager.BP_DefenderManager_C.[S]ShowDefenderUI
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(0) Size(0x0) ]
	void [S]ShowDefenderUI();

	// Object: Function BP_DefenderManager.BP_DefenderManager_C.OnUIStateChanged
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnUIStateChanged(enum class E_State_DefenderManager UiState);

	// Object: Function BP_DefenderManager.BP_DefenderManager_C.OnDefenderDataReady
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnDefenderDataReady();

	// Object: Function BP_DefenderManager.BP_DefenderManager_C.ShowDefenderUIForReplay
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(0) Size(0x0) ]
	void ShowDefenderUIForReplay();

	// Object: Function BP_DefenderManager.BP_DefenderManager_C.OnSideHeroPickEnd_Event_1
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x10) ]
	void OnSideHeroPickEnd_Event_1(struct FString Side);

	// Object: Function BP_DefenderManager.BP_DefenderManager_C.CustomEvent_1
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x1) ]
	void CustomEvent_1(enum class ESCMInGameState NewState);

	// Object: Function BP_DefenderManager.BP_DefenderManager_C.ShowDefenderUI
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(0) Size(0x0) ]
	void ShowDefenderUI();

	// Object: Function BP_DefenderManager.BP_DefenderManager_C.OnDefenderAllActorReady
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnDefenderAllActorReady();

	// Object: Function BP_DefenderManager.BP_DefenderManager_C.ExecuteUbergraph_BP_DefenderManager
	// Flags: [Final|UbergraphFunction|HasDefaults]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_BP_DefenderManager(int32_t EntryPoint);
};

