#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_DissolvedDeath.BP_DissolvedDeath_C
// Inherited Bytes: 0x1d0 | Struct Size: 0x1d0
struct UBP_DissolvedDeath_C : UMaterialVariableEffect {
};

