#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_LobbyGameState.BP_LobbyGameState_C
// Inherited Bytes: 0x328 | Struct Size: 0x330
struct ABP_LobbyGameState_C : ASolarGameStateBase {
	// Fields
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x328 | Size: 0x8
};

