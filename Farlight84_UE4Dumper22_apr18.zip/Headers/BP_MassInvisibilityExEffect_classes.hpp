#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_MassInvisibilityExEffect.BP_MassInvisibilityExEffect_C
// Inherited Bytes: 0x1d0 | Struct Size: 0x1d0
struct UBP_MassInvisibilityExEffect_C : UMaterialVariableEffect {
};

