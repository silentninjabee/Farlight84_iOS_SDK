#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_PBagsOffgas_Common.BP_PBagsOffgas_Common_C
// Inherited Bytes: 0x288 | Struct Size: 0x2a8
struct ABP_PBagsOffgas_Common_C : ASolarBackpackSFX {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x288 | Size: 0x8
	struct UParticleSystemComponent* FX_BoostClimb_Start; // Offset: 0x290 | Size: 0x8
	struct UParticleSystemComponent* FX_PowerBag_MainJet; // Offset: 0x298 | Size: 0x8
	struct USceneComponent* VFX; // Offset: 0x2a0 | Size: 0x8

	// Functions

	// Object: Function BP_PBagsOffgas_Common.BP_PBagsOffgas_Common_C.BackpackSFXBegin
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(2) Size(0x2) ]
	void BackpackSFXBegin(enum class EFXJetType InJetType, bool GroundDetected);

	// Object: Function BP_PBagsOffgas_Common.BP_PBagsOffgas_Common_C.BackpackSFXEnd
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(0) Size(0x0) ]
	void BackpackSFXEnd();

	// Object: Function BP_PBagsOffgas_Common.BP_PBagsOffgas_Common_C.OnBackpackTrailAssembling
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(2) Size(0xa9) ]
	void OnBackpackTrailAssembling(struct FBackpackTrailAssemblingParams& Params, enum class EBackpackPropellingMode PropellingMode);

	// Object: Function BP_PBagsOffgas_Common.BP_PBagsOffgas_Common_C.ExecuteUbergraph_BP_PBagsOffgas_Common
	// Flags: [Final|UbergraphFunction|HasDefaults]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_BP_PBagsOffgas_Common(int32_t EntryPoint);
};

