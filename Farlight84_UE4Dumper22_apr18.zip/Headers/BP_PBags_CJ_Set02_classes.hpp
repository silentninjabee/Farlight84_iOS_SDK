#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_PBags_CJ_Set02.BP_PBags_CJ_Set02_C
// Inherited Bytes: 0x338 | Struct Size: 0x338
struct ABP_PBags_CJ_Set02_C : ABP_SolarBackpackActor_C {
};

