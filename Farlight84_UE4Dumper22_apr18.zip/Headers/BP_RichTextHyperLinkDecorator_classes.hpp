#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_RichTextHyperLinkDecorator.BP_RichTextHyperLinkDecorator_C
// Inherited Bytes: 0x40 | Struct Size: 0x48
struct UBP_RichTextHyperLinkDecorator_C : UHyperlinkDecorator {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x40 | Size: 0x8

	// Functions

	// Object: Function BP_RichTextHyperLinkDecorator.BP_RichTextHyperLinkDecorator_C.ClickFunc
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(0) Size(0x0) ]
	void ClickFunc();

	// Object: Function BP_RichTextHyperLinkDecorator.BP_RichTextHyperLinkDecorator_C.ExecuteUbergraph_BP_RichTextHyperLinkDecorator
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_BP_RichTextHyperLinkDecorator(int32_t EntryPoint);
};

