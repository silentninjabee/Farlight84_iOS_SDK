#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_RollingDuckShiledComponent.BP_RollingDuckShiledComponent_C
// Inherited Bytes: 0x830 | Struct Size: 0x830
struct UBP_RollingDuckShiledComponent_C : UStaticMeshComponent {
};

