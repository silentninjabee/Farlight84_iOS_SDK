#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_Sniper_B9A01_Set00_Preview.BP_Sniper_B9A01_Set00_Preview_C
// Inherited Bytes: 0x6a8 | Struct Size: 0x6a8
struct ABP_Sniper_B9A01_Set00_Preview_C : ABP_Weaponry_Base_Preview_C {
};

