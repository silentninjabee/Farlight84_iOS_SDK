#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_SolarBombingManager.BP_SolarBombingManager_C
// Inherited Bytes: 0x270 | Struct Size: 0x278
struct ABP_SolarBombingManager_C : ASolarBombingZoneManager {
	// Fields
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x270 | Size: 0x8

	// Functions

	// Object: Function BP_SolarBombingManager.BP_SolarBombingManager_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();
};

