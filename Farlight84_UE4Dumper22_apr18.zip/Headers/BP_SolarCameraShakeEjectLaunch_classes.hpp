#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_SolarCameraShakeEjectLaunch.BP_SolarCameraShakeEjectLaunch_C
// Inherited Bytes: 0x160 | Struct Size: 0x160
struct UBP_SolarCameraShakeEjectLaunch_C : UCameraShake {
};

