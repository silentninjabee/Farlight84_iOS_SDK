#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_SolarCheatManager.BP_SolarCheatManager_C
// Inherited Bytes: 0x3b0 | Struct Size: 0x3b0
struct UBP_SolarCheatManager_C : USolarCheatManager {
};

