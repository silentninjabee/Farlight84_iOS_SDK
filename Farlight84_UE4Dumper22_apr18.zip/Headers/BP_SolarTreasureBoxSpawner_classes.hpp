#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_SolarTreasureBoxSpawner.BP_SolarTreasureBoxSpawner_C
// Inherited Bytes: 0x430 | Struct Size: 0x468
struct ABP_SolarTreasureBoxSpawner_C : ASolarTreasureBoxSpawner {
	// Fields
	struct USolarNavModifierComponent* SolarNavModifier; // Offset: 0x430 | Size: 0x8
	struct UStaticMeshComponent* Cube; // Offset: 0x438 | Size: 0x8
	struct UArrowComponent* Arrow; // Offset: 0x440 | Size: 0x8
	struct UStaticMeshComponent* BoxCube; // Offset: 0x448 | Size: 0x8
	struct USceneComponent* SceneRoot; // Offset: 0x450 | Size: 0x8
	struct TArray<struct FLinearColor> GroupMatColors; // Offset: 0x458 | Size: 0x10

	// Functions

	// Object: Function BP_SolarTreasureBoxSpawner.BP_SolarTreasureBoxSpawner_C.UserConstructionScript
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(0) Size(0x0) ]
	void UserConstructionScript();
};

