#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_WL03_DissolvedDeath.BP_WL03_DissolvedDeath_C
// Inherited Bytes: 0x1d0 | Struct Size: 0x1d0
struct UBP_WL03_DissolvedDeath_C : UMaterialVariableEffect {
};

