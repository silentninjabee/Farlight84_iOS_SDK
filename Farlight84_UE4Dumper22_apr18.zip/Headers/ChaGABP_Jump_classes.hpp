#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGABP_Jump.ChaGABP_Jump_C
// Inherited Bytes: 0x4c0 | Struct Size: 0x4c0
struct UChaGABP_Jump_C : UChaGA_Jump {
};

