#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGABP_OpenTreasureBox.ChaGABP_OpenTreasureBox_C
// Inherited Bytes: 0x4c8 | Struct Size: 0x4c8
struct UChaGABP_OpenTreasureBox_C : UChaGA_OpenTreasureBox {
};

