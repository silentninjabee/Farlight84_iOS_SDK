#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGABP_SkydiveFly.ChaGABP_SkydiveFly_C
// Inherited Bytes: 0x4f0 | Struct Size: 0x4f0
struct UChaGABP_SkydiveFly_C : UChaGA_SkydiveFly {
};

