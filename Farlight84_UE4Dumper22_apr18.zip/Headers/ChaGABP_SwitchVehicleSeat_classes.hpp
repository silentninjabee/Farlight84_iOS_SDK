#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGABP_SwitchVehicleSeat.ChaGABP_SwitchVehicleSeat_C
// Inherited Bytes: 0x4c0 | Struct Size: 0x4c0
struct UChaGABP_SwitchVehicleSeat_C : UChaGA_SwitchVehicleSeat {
};

