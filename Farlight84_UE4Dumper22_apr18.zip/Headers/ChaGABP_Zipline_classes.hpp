#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGABP_Zipline.ChaGABP_Zipline_C
// Inherited Bytes: 0x508 | Struct Size: 0x508
struct UChaGABP_Zipline_C : UChaGA_Zipline {
};

