#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGCBP_DamageToleranceOverflow.ChaGCBP_DamageToleranceOverflow_C
// Inherited Bytes: 0x50 | Struct Size: 0x50
struct UChaGCBP_DamageToleranceOverflow_C : UGameplayCueNotify_Static {
	// Functions

	// Object: Function ChaGCBP_DamageToleranceOverflow.ChaGCBP_DamageToleranceOverflow_C.OnExecute
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const]
	// Offset: 0x104039718
	// Return & Params: [ Num(3) Size(0xd9) ]
	bool OnExecute(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters);
};

