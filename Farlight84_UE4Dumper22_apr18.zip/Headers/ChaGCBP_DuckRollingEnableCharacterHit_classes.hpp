#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGCBP_DuckRollingEnableCharacterHit.ChaGCBP_DuckRollingEnableCharacterHit_C
// Inherited Bytes: 0x388 | Struct Size: 0x3c4
struct AChaGCBP_DuckRollingEnableCharacterHit_C : AChaGC_CharacterActorCueBase {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x388 | Size: 0x8
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x390 | Size: 0x8
	struct UB_DuckRollingProxyComponent_C* ProxyCompoent; // Offset: 0x398 | Size: 0x8
	struct UParticleSystem* ParticleAsset; // Offset: 0x3a0 | Size: 0x8
	struct UB_DuckRollingMeshComponent_C* MeshComponent; // Offset: 0x3a8 | Size: 0x8
	struct UParticleSystemComponent*  ParticleComponent; // Offset: 0x3b0 | Size: 0x8
	struct FRotator RotationOffset; // Offset: 0x3b8 | Size: 0xc

	// Functions

	// Object: Function ChaGCBP_DuckRollingEnableCharacterHit.ChaGCBP_DuckRollingEnableCharacterHit_C.OnRemove
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(3) Size(0xd9) ]
	bool OnRemove(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters);

	// Object: Function ChaGCBP_DuckRollingEnableCharacterHit.ChaGCBP_DuckRollingEnableCharacterHit_C.WhileActive
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(3) Size(0xd9) ]
	bool WhileActive(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters);

	// Object: Function ChaGCBP_DuckRollingEnableCharacterHit.ChaGCBP_DuckRollingEnableCharacterHit_C.ReceiveTick
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x4) ]
	void ReceiveTick(float DeltaSeconds);

	// Object: Function ChaGCBP_DuckRollingEnableCharacterHit.ChaGCBP_DuckRollingEnableCharacterHit_C.ReceiveEndPlay
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x1) ]
	void ReceiveEndPlay(enum class EEndPlayReason EndPlayReason);

	// Object: Function ChaGCBP_DuckRollingEnableCharacterHit.ChaGCBP_DuckRollingEnableCharacterHit_C.ExecuteUbergraph_ChaGCBP_DuckRollingEnableCharacterHit
	// Flags: [Final|UbergraphFunction|HasDefaults]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_ChaGCBP_DuckRollingEnableCharacterHit(int32_t EntryPoint);
};

