#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGCBP_JohnWick.ChaGCBP_JohnWick_C
// Inherited Bytes: 0x3d0 | Struct Size: 0x3d8
struct AChaGCBP_JohnWick_C : AChaGC_JohnWick {
	// Fields
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x3d0 | Size: 0x8
};

