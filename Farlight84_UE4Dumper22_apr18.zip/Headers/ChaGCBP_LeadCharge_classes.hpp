#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGCBP_LeadCharge.ChaGCBP_LeadCharge_C
// Inherited Bytes: 0x388 | Struct Size: 0x3a8
struct AChaGCBP_LeadCharge_C : AChaGC_CharacterActorCueBase {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x388 | Size: 0x8
	struct UParticleSystemComponent* FX_MCP_Ball_Path; // Offset: 0x390 | Size: 0x8
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x398 | Size: 0x8
	struct ASolarCharacter* OwnerCharacter; // Offset: 0x3a0 | Size: 0x8

	// Functions

	// Object: Function ChaGCBP_LeadCharge.ChaGCBP_LeadCharge_C.WhileActiveInternal
	// Flags: [Event|Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(3) Size(0xd9) ]
	bool WhileActiveInternal(struct ASolarCharacter* Character, struct FGameplayCueParameters& Parameters);

	// Object: Function ChaGCBP_LeadCharge.ChaGCBP_LeadCharge_C.OnRemoveInternal
	// Flags: [Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(3) Size(0xd9) ]
	bool OnRemoveInternal(struct ASolarCharacter* NullableCharacter, struct FGameplayCueParameters& Parameters);

	// Object: Function ChaGCBP_LeadCharge.ChaGCBP_LeadCharge_C.OnActiveInternal
	// Flags: [Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(3) Size(0xd9) ]
	bool OnActiveInternal(struct ASolarCharacter* Character, struct FGameplayCueParameters& Parameters);

	// Object: Function ChaGCBP_LeadCharge.ChaGCBP_LeadCharge_C.ReceiveTick
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x4) ]
	void ReceiveTick(float DeltaSeconds);

	// Object: Function ChaGCBP_LeadCharge.ChaGCBP_LeadCharge_C.ExecuteUbergraph_ChaGCBP_LeadCharge
	// Flags: [Final|UbergraphFunction|HasDefaults]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_ChaGCBP_LeadCharge(int32_t EntryPoint);
};

