#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGCBP_RescueOnWin.ChaGCBP_RescueOnWin_C
// Inherited Bytes: 0x388 | Struct Size: 0x390
struct AChaGCBP_RescueOnWin_C : AChaGC_CharacterActorCueBase {
	// Fields
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x388 | Size: 0x8
};

