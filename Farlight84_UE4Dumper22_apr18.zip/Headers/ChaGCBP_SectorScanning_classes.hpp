#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGCBP_SectorScanning.ChaGCBP_SectorScanning_C
// Inherited Bytes: 0x390 | Struct Size: 0x398
struct AChaGCBP_SectorScanning_C : AChaGC_SuperSkillActorCueBase {
	// Fields
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x390 | Size: 0x8
};

