#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGCBP_SummonTowerHoldEar.ChaGCBP_SummonTowerHoldEar_C
// Inherited Bytes: 0x3e0 | Struct Size: 0x3e8
struct AChaGCBP_SummonTowerHoldEar_C : AChaGC_SummonTowerHoldEar {
	// Fields
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x3e0 | Size: 0x8
};

