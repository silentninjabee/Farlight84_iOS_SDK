#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGCBP_ThunderFlash_Release.ChaGCBP_ThunderFlash_Release_C
// Inherited Bytes: 0x388 | Struct Size: 0x390
struct AChaGCBP_ThunderFlash_Release_C : AChaGC_CharacterActorCueBase {
	// Fields
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x388 | Size: 0x8
};

