#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass Crosshair_CarWeapon_Flame_New.Crosshair_CarWeapon_Flame_New_C
// Inherited Bytes: 0x748 | Struct Size: 0x7a9
struct UCrosshair_CarWeapon_Flame_New_C : UVehicleWeaponCrossHairWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x748 | Size: 0x8
	struct UWidgetAnimation* Overheat_Anim_Quit; // Offset: 0x750 | Size: 0x8
	struct UWidgetAnimation* Overheat_Anim_Enter; // Offset: 0x758 | Size: 0x8
	struct UCanvasPanel* Container_SecondReticle; // Offset: 0x760 | Size: 0x8
	struct UCanvasPanel* Coredot; // Offset: 0x768 | Size: 0x8
	struct UImage* img_normal; // Offset: 0x770 | Size: 0x8
	struct UImage* img_overload; // Offset: 0x778 | Size: 0x8
	struct UImage* Img_Overload_vx; // Offset: 0x780 | Size: 0x8
	struct UCanvasPanel* panel_overload; // Offset: 0x788 | Size: 0x8
	struct UImage* ReticleDirection; // Offset: 0x790 | Size: 0x8
	struct UImage* SpreadImg_coredot; // Offset: 0x798 | Size: 0x8
	struct UWidgetSwitcher* wgs_status; // Offset: 0x7a0 | Size: 0x8
	bool IsOverloading; // Offset: 0x7a8 | Size: 0x1

	// Functions

	// Object: Function Crosshair_CarWeapon_Flame_New.Crosshair_CarWeapon_Flame_New_C.OnOverloadChanged
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnOverloadChanged(bool InOverload);

	// Object: Function Crosshair_CarWeapon_Flame_New.Crosshair_CarWeapon_Flame_New_C.SetWidgetResources
	// Flags: [Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(7) Size(0x38) ]
	void SetWidgetResources(struct UCanvasPanel*& InSecondReticlePanel, struct UImage*& InReticleDirectionImage, struct UImage*& InRangedImage, struct USizeBox*& InAssistLockSizeBox, struct UCanvasPanel*& InChangeNewAssistLockPawnPanel, struct UCanvasPanel*& InEnterLockPawnPanel, struct UCanvasPanel*& InCanvas_Dynamic);

	// Object: Function Crosshair_CarWeapon_Flame_New.Crosshair_CarWeapon_Flame_New_C.OnOverloadStateChanged
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnOverloadStateChanged(bool bEnter);

	// Object: Function Crosshair_CarWeapon_Flame_New.Crosshair_CarWeapon_Flame_New_C.OnAnimationFinished
	// Flags: [BlueprintCosmetic|Event|Protected|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x8) ]
	void OnAnimationFinished(struct UWidgetAnimation* Animation);

	// Object: Function Crosshair_CarWeapon_Flame_New.Crosshair_CarWeapon_Flame_New_C.OnCrosshairInNormalState
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnCrosshairInNormalState();

	// Object: Function Crosshair_CarWeapon_Flame_New.Crosshair_CarWeapon_Flame_New_C.ExecuteUbergraph_Crosshair_CarWeapon_Flame_New
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_Crosshair_CarWeapon_Flame_New(int32_t EntryPoint);
};

