#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass Crosshair_CarWeapon_Gatling.Crosshair_CarWeapon_Gatling_C
// Inherited Bytes: 0x748 | Struct Size: 0x779
struct UCrosshair_CarWeapon_Gatling_C : UVehicleWeaponCrossHairWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x748 | Size: 0x8
	struct UCanvasPanel* Coredot; // Offset: 0x750 | Size: 0x8
	struct UCanvasPanel* SpreadCanvasPanel; // Offset: 0x758 | Size: 0x8
	struct UImage* SpreadImg_coredot; // Offset: 0x760 | Size: 0x8
	struct UImage* SpreadImg_leftarrow_2; // Offset: 0x768 | Size: 0x8
	struct UImage* SpreadImg_rightarrow_2; // Offset: 0x770 | Size: 0x8
	bool NewlyControlled; // Offset: 0x778 | Size: 0x1

	// Functions

	// Object: Function Crosshair_CarWeapon_Gatling.Crosshair_CarWeapon_Gatling_C.CalculateRotAngle
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(4) Size(0x10) ]
	void CalculateRotAngle(float DeltaTime, float InSpeed, bool bFire, float& OutAngle);

	// Object: Function Crosshair_CarWeapon_Gatling.Crosshair_CarWeapon_Gatling_C.OnUpdateGatlingRoll
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(3) Size(0x9) ]
	void OnUpdateGatlingRoll(float DeltaTmie, float InRollSpeedInterp, bool bWantFire);

	// Object: Function Crosshair_CarWeapon_Gatling.Crosshair_CarWeapon_Gatling_C.OnCrosshairInNormalState
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnCrosshairInNormalState();

	// Object: Function Crosshair_CarWeapon_Gatling.Crosshair_CarWeapon_Gatling_C.ExecuteUbergraph_Crosshair_CarWeapon_Gatling
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_Crosshair_CarWeapon_Gatling(int32_t EntryPoint);
};

