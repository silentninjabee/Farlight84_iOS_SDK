#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass Crosshair_Simple.Crosshair_Simple_C
// Inherited Bytes: 0x5c0 | Struct Size: 0x5f8
struct UCrosshair_Simple_C : UCrossHairWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x5c0 | Size: 0x8
	struct UWidgetAnimation* Simple_Anim; // Offset: 0x5c8 | Size: 0x8
	struct UImage* SpreadImg_coredot; // Offset: 0x5d0 | Size: 0x8
	struct UImage* SpreadImg_downarrow; // Offset: 0x5d8 | Size: 0x8
	struct UImage* SpreadImg_leftarrow; // Offset: 0x5e0 | Size: 0x8
	struct UImage* SpreadImg_rightarrow; // Offset: 0x5e8 | Size: 0x8
	struct UImage* SpreadImg_uparrow; // Offset: 0x5f0 | Size: 0x8

	// Functions

	// Object: Function Crosshair_Simple.Crosshair_Simple_C.InitializeCrosshairSpread
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x4) ]
	void InitializeCrosshairSpread(float Spread);

	// Object: Function Crosshair_Simple.Crosshair_Simple_C.SetCrosshairSprite
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(2) Size(0x10) ]
	void SetCrosshairSprite(struct UPaperSprite* InCenterSprite, struct UPaperSprite* InSprite);

	// Object: Function Crosshair_Simple.Crosshair_Simple_C.ExecuteUbergraph_Crosshair_Simple
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_Crosshair_Simple(int32_t EntryPoint);
};

