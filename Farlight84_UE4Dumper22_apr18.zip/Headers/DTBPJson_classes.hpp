#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class DTBPJson.DTBPJsonBPLib
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UDTBPJsonBPLib : UBlueprintFunctionLibrary {
	// Functions

	// Object: Function DTBPJson.DTBPJsonBPLib.StructToJson
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x1021c7270
	// Return & Params: [ Num(3) Size(0x19) ]
	void StructToJson(struct FDTStruct& Struct, struct FString& Json, bool PrettyPrint);

	// Object: Function DTBPJson.DTBPJsonBPLib.JsonToStruct
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x1021c7170
	// Return & Params: [ Num(2) Size(0x18) ]
	void JsonToStruct(struct FDTStruct& Struct, struct FString Json);
};

