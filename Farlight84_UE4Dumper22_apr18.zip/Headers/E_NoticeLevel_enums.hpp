#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: UserDefinedEnum E_NoticeLevel.E_NoticeLevel
enum class E_NoticeLevel : uint8_t {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator2 = 2,
	E_MAX = 3
};

