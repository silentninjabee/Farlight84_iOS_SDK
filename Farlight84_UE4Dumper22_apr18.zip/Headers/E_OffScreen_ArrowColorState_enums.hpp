#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: UserDefinedEnum E_OffScreen_ArrowColorState.E_OffScreen_ArrowColorState
enum class E_OffScreen_ArrowColorState : uint8_t {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator2 = 2,
	E_OffScreen_MAX = 3
};

