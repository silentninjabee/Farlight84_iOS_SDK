#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass EmergencyAirbag.EmergencyAirbag_C
// Inherited Bytes: 0x230 | Struct Size: 0x240
struct AEmergencyAirbag_C : AActor {
	// Fields
	struct UStaticMeshComponent* Sphere; // Offset: 0x230 | Size: 0x8
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x238 | Size: 0x8
};

