#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass FL_CustomMode.FL_CustomMode_C
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UFL_CustomMode_C : UBlueprintFunctionLibrary {
	// Functions

	// Object: Function FL_CustomMode.FL_CustomMode_C.Get Portrait from Avatar ID
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x104039718
	// Return & Params: [ Num(3) Size(0x18) ]
	void Get Portrait from Avatar ID(int32_t Avatar ID, struct UObject* __WorldContext, struct UTexture2D*& Portrait Texture);

	// Object: Function FL_CustomMode.FL_CustomMode_C.Get Loc Request Componet
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(3) Size(0x18) ]
	struct ULocal_RequestMessage_C* Get Loc Request Componet(struct UObject* WorldContextObject, struct UObject* __WorldContext);

	// Object: Function FL_CustomMode.FL_CustomMode_C.[s]BindOnPlayerReconnected
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(3) Size(0x19) ]
	void [s]BindOnPlayerReconnected(struct FDelegate& Event, struct UObject* __WorldContext, bool& bSuccess);

	// Object: Function FL_CustomMode.FL_CustomMode_C.[s]BindOnPlayerDisconnected
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(3) Size(0x19) ]
	void [s]BindOnPlayerDisconnected(struct FDelegate& Event, struct UObject* __WorldContext, bool& bSuccess);

	// Object: Function FL_CustomMode.FL_CustomMode_C.
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(3) Size(0x14) ]
	void (int32_t ID, struct UObject* __WorldContext, int32_t& );

	// Object: Function FL_CustomMode.FL_CustomMode_C.
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(4) Size(0x1c) ]
	void (int32_t ID, struct UObject* __WorldContext, struct UTexture2D*& , int32_t& );

	// Object: Function FL_CustomMode.FL_CustomMode_C.
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(5) Size(0x20) ]
	void (int32_t ID, struct UObject* __WorldContext, struct UTexture2D*& , int32_t& , int32_t& PartsType);

	// Object: Function FL_CustomMode.FL_CustomMode_C.
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(6) Size(0x34) ]
	void (int32_t ID, struct UObject* __WorldContext, struct UPaperSprite*& , struct TArray<float>& HUDColor, struct UTexture2D*& , int32_t& Parts Type);

	// Object: Function FL_CustomMode.FL_CustomMode_C.Pawn is a vehicle
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x104039718
	// Return & Params: [ Num(3) Size(0x11) ]
	void Pawn is a vehicle(struct APawn* Pawn, struct UObject* __WorldContext, bool& Result);

	// Object: Function FL_CustomMode.FL_CustomMode_C.GetNetMode
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x104039718
	// Return & Params: [ Num(2) Size(0x9) ]
	enum class ESolarNetMode GetNetMode(struct UObject* __WorldContext);

	// Object: Function FL_CustomMode.FL_CustomMode_C.[c]BindOnReceiveRequest
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(2) Size(0x18) ]
	void [c]BindOnReceiveRequest(struct FDelegate& Event, struct UObject* __WorldContext);

	// Object: Function FL_CustomMode.FL_CustomMode_C.[c]BindOnRequestReplied
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(2) Size(0x18) ]
	void [c]BindOnRequestReplied(struct FDelegate& Event, struct UObject* __WorldContext);

	// Object: Function FL_CustomMode.FL_CustomMode_C.[s]BindOnRequestDealt
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(3) Size(0x20) ]
	void [s]BindOnRequestDealt(struct FDelegate& Event, struct UObject* __WorldContext, struct ABP_RequestMessage_C*& RequestManager);

	// Object: Function FL_CustomMode.FL_CustomMode_C.GetRequestComponet
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x104039718
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UBPC_RequestMessage_C* GetRequestComponet(struct UObject* __WorldContext);

	// Object: Function FL_CustomMode.FL_CustomMode_C.Name2String
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x104039718
	// Return & Params: [ Num(3) Size(0x28) ]
	void Name2String(struct TArray<struct FName>& Names, struct UObject* __WorldContext, struct TArray<struct FString>& Strings);

	// Object: Function FL_CustomMode.FL_CustomMode_C.ArrayContain
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x104039718
	// Return & Params: [ Num(4) Size(0x29) ]
	void ArrayContain(struct TArray<struct FString>& Main, struct TArray<struct FString>& Sub, struct UObject* __WorldContext, bool& Contain);

	// Object: Function FL_CustomMode.FL_CustomMode_C.
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x104039718
	// Return & Params: [ Num(3) Size(0x28) ]
	void (int32_t , struct UObject* __WorldContext, struct FText& );

	// Object: Function FL_CustomMode.FL_CustomMode_C.
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x104039718
	// Return & Params: [ Num(5) Size(0x24) ]
	void (int32_t , int32_t , struct TArray<int32_t>& , struct UObject* __WorldContext, int32_t& Result);

	// Object: Function FL_CustomMode.FL_CustomMode_C.
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x104039718
	// Return & Params: [ Num(2) Size(0x9) ]
	void (struct UObject* __WorldContext, enum class ESolarBuildConfiguration& );

	// Object: Function FL_CustomMode.FL_CustomMode_C.Number 2Letter
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x104039718
	// Return & Params: [ Num(3) Size(0x20) ]
	void Number 2Letter(int32_t Number, struct UObject* __WorldContext, struct FString& Letter);

	// Object: Function FL_CustomMode.FL_CustomMode_C.
	// Flags: [Static|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(2) Size(0x10) ]
	void (float , struct UObject* __WorldContext);

	// Object: Function FL_CustomMode.FL_CustomMode_C.
	// Flags: [Static|Private|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x104039718
	// Return & Params: [ Num(2) Size(0x10) ]
	void (struct UObject* __WorldContext, struct UUI_Notice_Noya_C*& NoyaWidget);

	// Object: Function FL_CustomMode.FL_CustomMode_C.
	// Flags: [Static|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(2) Size(0x58) ]
	void (struct TMap<char, bool> , struct UObject* __WorldContext);

	// Object: Function FL_CustomMode.FL_CustomMode_C.
	// Flags: [Static|Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(4) Size(0x20) ]
	void (enum class E_NoticeType_Noya , float , struct FString , struct UObject* __WorldContext);

	// Object: Function FL_CustomMode.FL_CustomMode_C.
	// Flags: [Static|Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(6) Size(0x78) ]
	void (enum class E_NoticeType_Noya , float , struct FString , struct TMap<char, bool> , int32_t , struct UObject* __WorldContext);

	// Object: Function FL_CustomMode.FL_CustomMode_C.
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(3) Size(0x11) ]
	enum class EDriveState (struct AActor* NewParam, struct UObject* __WorldContext);

	// Object: Function FL_CustomMode.FL_CustomMode_C.
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x104039718
	// Return & Params: [ Num(3) Size(0x28) ]
	void (struct TArray<struct AActor*>& , struct UObject* __WorldContext, struct TArray<struct FString>& Result);

	// Object: Function FL_CustomMode.FL_CustomMode_C.
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x104039718
	// Return & Params: [ Num(3) Size(0x28) ]
	void (struct FVector Vector, struct UObject* __WorldContext, struct FString& str);

	// Object: Function FL_CustomMode.FL_CustomMode_C.
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(6) Size(0x30) ]
	void (struct UMapMarkBase* InMapMarkClass, struct FVector InMarkPos, bool EdgeSupport, int32_t ZOrder, struct UObject* __WorldContext, struct UMapMarkBase*& Output);

	// Object: Function FL_CustomMode.FL_CustomMode_C.
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x104039718
	// Return & Params: [ Num(3) Size(0x11) ]
	void (struct ASolarCharacter* , struct UObject* __WorldContext, enum class ECharacterHealthState& );

	// Object: Function FL_CustomMode.FL_CustomMode_C.
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x104039718
	// Return & Params: [ Num(6) Size(0x29) ]
	void (struct FVector , bool , struct UObject* __WorldContext, struct FVector& , float& Z, bool& );

	// Object: Function FL_CustomMode.FL_CustomMode_C.ToInt(StringArray)
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x104039718
	// Return & Params: [ Num(3) Size(0x28) ]
	void ToInt(StringArray)(struct TArray<struct FString>& str, struct UObject* __WorldContext, struct TArray<int32_t>& Int);

	// Object: Function FL_CustomMode.FL_CustomMode_C.
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x104039718
	// Return & Params: [ Num(3) Size(0x11) ]
	void (struct ASolarCharacter* , struct UObject* __WorldContext, bool& );

	// Object: Function FL_CustomMode.FL_CustomMode_C.
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x104039718
	// Return & Params: [ Num(4) Size(0x30) ]
	void (struct TArray<struct ASolarMapElementBase*>& Array, int32_t , struct UObject* __WorldContext, struct TArray<struct ASolarMapElementBase*>& Resault);

	// Object: Function FL_CustomMode.FL_CustomMode_C.
	// Flags: [Static|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(3) Size(0x18) ]
	void (struct UWidget* Target, bool Visiable, struct UObject* __WorldContext);

	// Object: Function FL_CustomMode.FL_CustomMode_C.
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x104039718
	// Return & Params: [ Num(4) Size(0x14) ]
	void (int32_t ItemCount, int32_t PageCapacity, struct UObject* __WorldContext, int32_t& PageCount);

	// Object: Function FL_CustomMode.FL_CustomMode_C.
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x104039718
	// Return & Params: [ Num(5) Size(0x1c) ]
	void (int32_t , int32_t , int32_t , struct UObject* __WorldContext, int32_t& );

	// Object: Function FL_CustomMode.FL_CustomMode_C.
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(4) Size(0x20) ]
	void (struct UUserWidget* Target, struct UObject* __WorldContext, bool& Visible, struct UUserWidget*& Widget);

	// Object: Function FL_CustomMode.FL_CustomMode_C.
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x104039718
	// Return & Params: [ Num(3) Size(0x11) ]
	void (struct ASolarCharacter* , struct UObject* __WorldContext, bool& );

	// Object: Function FL_CustomMode.FL_CustomMode_C.
	// Flags: [Static|Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(4) Size(0x28) ]
	void (struct UObject* , struct FString , enum class E_NoticeLevel , struct UObject* __WorldContext);

	// Object: Function FL_CustomMode.FL_CustomMode_C.Convert(ToString)
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x104039718
	// Return & Params: [ Num(3) Size(0x30) ]
	void Convert(ToString)(struct FKey Key, struct UObject* __WorldContext, struct FString& KeyString);
};

