#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass GA_Scan_On_Hit_Level2.GA_Scan_On_Hit_Level2_C
// Inherited Bytes: 0x490 | Struct Size: 0x490
struct UGA_Scan_On_Hit_Level2_C : UWeaponScanAbility {
};

