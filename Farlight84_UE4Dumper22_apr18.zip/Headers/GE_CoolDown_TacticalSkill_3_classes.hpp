#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass GE_CoolDown_TacticalSkill_3.GE_CoolDown_TacticalSkill_2_C
// Inherited Bytes: 0x878 | Struct Size: 0x878
struct UGE_CoolDown_TacticalSkill_2_C : UGameplayEffect {
};

