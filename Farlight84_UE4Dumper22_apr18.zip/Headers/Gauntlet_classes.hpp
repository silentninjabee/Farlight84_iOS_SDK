#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class Gauntlet.GauntletTestController
// Inherited Bytes: 0x28 | Struct Size: 0x30
struct UGauntletTestController : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
};

// Object: Class Gauntlet.GauntletTestControllerBootTest
// Inherited Bytes: 0x30 | Struct Size: 0x30
struct UGauntletTestControllerBootTest : UGauntletTestController {
};

// Object: Class Gauntlet.GauntletTestControllerErrorTest
// Inherited Bytes: 0x30 | Struct Size: 0x50
struct UGauntletTestControllerErrorTest : UGauntletTestController {
	// Fields
	char pad_0x30[0x20]; // Offset: 0x30 | Size: 0x20
};

