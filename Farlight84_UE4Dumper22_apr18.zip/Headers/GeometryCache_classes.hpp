#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class GeometryCache.GeometryCache
// Inherited Bytes: 0x28 | Struct Size: 0x68
struct UGeometryCache : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
	struct TArray<struct UMaterialInterface*> Materials; // Offset: 0x30 | Size: 0x10
	struct TArray<struct UGeometryCacheTrack*> Tracks; // Offset: 0x40 | Size: 0x10
	char pad_0x50[0x10]; // Offset: 0x50 | Size: 0x10
	int32_t StartFrame; // Offset: 0x60 | Size: 0x4
	int32_t EndFrame; // Offset: 0x64 | Size: 0x4
};

// Object: Class GeometryCache.GeometryCacheActor
// Inherited Bytes: 0x230 | Struct Size: 0x238
struct AGeometryCacheActor : AActor {
	// Fields
	struct UGeometryCacheComponent* GeometryCacheComponent; // Offset: 0x230 | Size: 0x8

	// Functions

	// Object: Function GeometryCache.GeometryCacheActor.GetGeometryCacheComponent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022eae50
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UGeometryCacheComponent* GetGeometryCacheComponent();
};

// Object: Class GeometryCache.GeometryCacheCodecBase
// Inherited Bytes: 0x28 | Struct Size: 0x38
struct UGeometryCacheCodecBase : UObject {
	// Fields
	struct TArray<int32_t> TopologyRanges; // Offset: 0x28 | Size: 0x10
};

// Object: Class GeometryCache.GeometryCacheCodecRaw
// Inherited Bytes: 0x38 | Struct Size: 0x40
struct UGeometryCacheCodecRaw : UGeometryCacheCodecBase {
	// Fields
	int32_t DummyProperty; // Offset: 0x38 | Size: 0x4
	char pad_0x3C[0x4]; // Offset: 0x3c | Size: 0x4
};

// Object: Class GeometryCache.GeometryCacheCodecV1
// Inherited Bytes: 0x38 | Struct Size: 0x40
struct UGeometryCacheCodecV1 : UGeometryCacheCodecBase {
	// Fields
	char pad_0x38[0x8]; // Offset: 0x38 | Size: 0x8
};

// Object: Class GeometryCache.GeometryCacheComponent
// Inherited Bytes: 0x680 | Struct Size: 0x6d0
struct UGeometryCacheComponent : UMeshComponent {
	// Fields
	struct UGeometryCache* GeometryCache; // Offset: 0x678 | Size: 0x8
	bool bRunning; // Offset: 0x680 | Size: 0x1
	bool bLooping; // Offset: 0x681 | Size: 0x1
	float StartTimeOffset; // Offset: 0x684 | Size: 0x4
	float PlaybackSpeed; // Offset: 0x688 | Size: 0x4
	int32_t NumTracks; // Offset: 0x68c | Size: 0x4
	float ElapsedTime; // Offset: 0x690 | Size: 0x4
	char pad_0x69A[0x2a]; // Offset: 0x69a | Size: 0x2a
	float Duration; // Offset: 0x6c4 | Size: 0x4
	bool bManualTick; // Offset: 0x6c8 | Size: 0x1
	char pad_0x6C9[0x7]; // Offset: 0x6c9 | Size: 0x7

	// Functions

	// Object: Function GeometryCache.GeometryCacheComponent.TickAtThisTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022eb670
	// Return & Params: [ Num(4) Size(0x7) ]
	void TickAtThisTime(float Time, bool bInIsRunning, bool bInBackwards, bool bInIsLooping);

	// Object: Function GeometryCache.GeometryCacheComponent.Stop
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022ebbe8
	// Return & Params: [ Num(0) Size(0x0) ]
	void Stop();

	// Object: Function GeometryCache.GeometryCacheComponent.SetStartTimeOffset
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022eb8cc
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetStartTimeOffset(float NewStartTimeOffset);

	// Object: Function GeometryCache.GeometryCacheComponent.SetPlaybackSpeed
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022eba10
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetPlaybackSpeed(float NewPlaybackSpeed);

	// Object: Function GeometryCache.GeometryCacheComponent.SetLooping
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022ebac4
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetLooping(bool bNewLooping);

	// Object: Function GeometryCache.GeometryCacheComponent.SetGeometryCache
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022eb980
	// Return & Params: [ Num(2) Size(0x9) ]
	bool SetGeometryCache(struct UGeometryCache* NewGeomCache);

	// Object: Function GeometryCache.GeometryCacheComponent.PlayReversedFromEnd
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022ebc10
	// Return & Params: [ Num(0) Size(0x0) ]
	void PlayReversedFromEnd();

	// Object: Function GeometryCache.GeometryCacheComponent.PlayReversed
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022ebc24
	// Return & Params: [ Num(0) Size(0x0) ]
	void PlayReversed();

	// Object: Function GeometryCache.GeometryCacheComponent.PlayFromStart
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022ebc38
	// Return & Params: [ Num(0) Size(0x0) ]
	void PlayFromStart();

	// Object: Function GeometryCache.GeometryCacheComponent.Play
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022ebc4c
	// Return & Params: [ Num(0) Size(0x0) ]
	void Play();

	// Object: Function GeometryCache.GeometryCacheComponent.Pause
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1022ebbfc
	// Return & Params: [ Num(0) Size(0x0) ]
	void Pause();

	// Object: Function GeometryCache.GeometryCacheComponent.IsPlayingReversed
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022ebb80
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsPlayingReversed();

	// Object: Function GeometryCache.GeometryCacheComponent.IsPlaying
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022ebbb4
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsPlaying();

	// Object: Function GeometryCache.GeometryCacheComponent.IsLooping
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022ebb4c
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsLooping();

	// Object: Function GeometryCache.GeometryCacheComponent.GetStartTimeOffset
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022eb94c
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetStartTimeOffset();

	// Object: Function GeometryCache.GeometryCacheComponent.GetPlaybackSpeed
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022eba90
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetPlaybackSpeed();

	// Object: Function GeometryCache.GeometryCacheComponent.GetPlaybackDirection
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022eb864
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetPlaybackDirection();

	// Object: Function GeometryCache.GeometryCacheComponent.GetNumberOfFrames
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022eb7fc
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetNumberOfFrames();

	// Object: Function GeometryCache.GeometryCacheComponent.GetDuration
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022eb830
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetDuration();

	// Object: Function GeometryCache.GeometryCacheComponent.GetAnimationTime
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1022eb898
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetAnimationTime();
};

// Object: Class GeometryCache.GeometryCacheTrack
// Inherited Bytes: 0x28 | Struct Size: 0x58
struct UGeometryCacheTrack : UObject {
	// Fields
	float Duration; // Offset: 0x28 | Size: 0x4
	char pad_0x2C[0x2c]; // Offset: 0x2c | Size: 0x2c
};

// Object: Class GeometryCache.GeometryCacheTrack_FlipbookAnimation
// Inherited Bytes: 0x58 | Struct Size: 0x78
struct UGeometryCacheTrack_FlipbookAnimation : UGeometryCacheTrack {
	// Fields
	uint32_t NumMeshSamples; // Offset: 0x54 | Size: 0x4
	char pad_0x5C[0x1c]; // Offset: 0x5c | Size: 0x1c

	// Functions

	// Object: Function GeometryCache.GeometryCacheTrack_FlipbookAnimation.AddMeshSample
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x1022ec97c
	// Return & Params: [ Num(2) Size(0xac) ]
	void AddMeshSample(struct FGeometryCacheMeshData& MeshData, float SampleTime);
};

// Object: Class GeometryCache.GeometryCacheTrackStreamable
// Inherited Bytes: 0x58 | Struct Size: 0xd0
struct UGeometryCacheTrackStreamable : UGeometryCacheTrack {
	// Fields
	struct UGeometryCacheCodecBase* Codec; // Offset: 0x58 | Size: 0x8
	char pad_0x60[0x68]; // Offset: 0x60 | Size: 0x68
	float StartSampleTime; // Offset: 0xc8 | Size: 0x4
	char pad_0xCC[0x4]; // Offset: 0xcc | Size: 0x4
};

// Object: Class GeometryCache.GeometryCacheTrack_TransformAnimation
// Inherited Bytes: 0x58 | Struct Size: 0x100
struct UGeometryCacheTrack_TransformAnimation : UGeometryCacheTrack {
	// Fields
	char pad_0x58[0xa8]; // Offset: 0x58 | Size: 0xa8

	// Functions

	// Object: Function GeometryCache.GeometryCacheTrack_TransformAnimation.SetMesh
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x1022ece8c
	// Return & Params: [ Num(1) Size(0xa8) ]
	void SetMesh(struct FGeometryCacheMeshData& NewMeshData);
};

// Object: Class GeometryCache.GeometryCacheTrack_TransformGroupAnimation
// Inherited Bytes: 0x58 | Struct Size: 0x100
struct UGeometryCacheTrack_TransformGroupAnimation : UGeometryCacheTrack {
	// Fields
	char pad_0x58[0xa8]; // Offset: 0x58 | Size: 0xa8

	// Functions

	// Object: Function GeometryCache.GeometryCacheTrack_TransformGroupAnimation.SetMesh
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x1022ed158
	// Return & Params: [ Num(1) Size(0xa8) ]
	void SetMesh(struct FGeometryCacheMeshData& NewMeshData);
};

