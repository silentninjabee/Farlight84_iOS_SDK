#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class GeometryCollectionEngine.ChaosDestructionListener
// Inherited Bytes: 0x360 | Struct Size: 0x580
struct UChaosDestructionListener : USceneComponent {
	// Fields
	char bIsCollisionEventListeningEnabled : 1; // Offset: 0x354 | Size: 0x1
	char bIsBreakingEventListeningEnabled : 1; // Offset: 0x354 | Size: 0x1
	char bIsTrailingEventListeningEnabled : 1; // Offset: 0x354 | Size: 0x1
	struct FChaosCollisionEventRequestSettings CollisionEventRequestSettings; // Offset: 0x358 | Size: 0x18
	struct FChaosBreakingEventRequestSettings BreakingEventRequestSettings; // Offset: 0x370 | Size: 0x18
	struct FChaosTrailingEventRequestSettings TrailingEventRequestSettings; // Offset: 0x388 | Size: 0x18
	struct TSet<struct AChaosSolverActor*> ChaosSolverActors; // Offset: 0x3a0 | Size: 0x50
	struct TSet<struct AGeometryCollectionActor*> GeometryCollectionActors; // Offset: 0x3f0 | Size: 0x50
	struct FMulticastInlineDelegate OnCollisionEvents; // Offset: 0x440 | Size: 0x10
	struct FMulticastInlineDelegate OnBreakingEvents; // Offset: 0x450 | Size: 0x10
	struct FMulticastInlineDelegate OnTrailingEvents; // Offset: 0x460 | Size: 0x10
	char pad_0x478_3 : 5; // Offset: 0x478 | Size: 0x1
	char pad_0x479[0x107]; // Offset: 0x479 | Size: 0x107

	// Functions

	// Object: Function GeometryCollectionEngine.ChaosDestructionListener.SortTrailingEvents
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105e324c0
	// Return & Params: [ Num(2) Size(0x11) ]
	void SortTrailingEvents(struct TArray<struct FChaosTrailingEventData>& TrailingEvents, enum class EChaosTrailingSortMethod SortMethod);

	// Object: Function GeometryCollectionEngine.ChaosDestructionListener.SortCollisionEvents
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105e32688
	// Return & Params: [ Num(2) Size(0x11) ]
	void SortCollisionEvents(struct TArray<struct FChaosCollisionEventData>& CollisionEvents, enum class EChaosCollisionSortMethod SortMethod);

	// Object: Function GeometryCollectionEngine.ChaosDestructionListener.SortBreakingEvents
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105e325a4
	// Return & Params: [ Num(2) Size(0x11) ]
	void SortBreakingEvents(struct TArray<struct FChaosBreakingEventData>& BreakingEvents, enum class EChaosBreakingSortMethod SortMethod);

	// Object: Function GeometryCollectionEngine.ChaosDestructionListener.SetTrailingEventRequestSettings
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105e32938
	// Return & Params: [ Num(1) Size(0x18) ]
	void SetTrailingEventRequestSettings(struct FChaosTrailingEventRequestSettings& InSettings);

	// Object: Function GeometryCollectionEngine.ChaosDestructionListener.SetTrailingEventEnabled
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105e327a0
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetTrailingEventEnabled(bool bIsEnabled);

	// Object: Function GeometryCollectionEngine.ChaosDestructionListener.SetCollisionEventRequestSettings
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105e32a68
	// Return & Params: [ Num(1) Size(0x18) ]
	void SetCollisionEventRequestSettings(struct FChaosCollisionEventRequestSettings& InSettings);

	// Object: Function GeometryCollectionEngine.ChaosDestructionListener.SetCollisionEventEnabled
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105e328b0
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetCollisionEventEnabled(bool bIsEnabled);

	// Object: Function GeometryCollectionEngine.ChaosDestructionListener.SetBreakingEventRequestSettings
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x105e329d0
	// Return & Params: [ Num(1) Size(0x18) ]
	void SetBreakingEventRequestSettings(struct FChaosBreakingEventRequestSettings& InSettings);

	// Object: Function GeometryCollectionEngine.ChaosDestructionListener.SetBreakingEventEnabled
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105e32828
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetBreakingEventEnabled(bool bIsEnabled);

	// Object: Function GeometryCollectionEngine.ChaosDestructionListener.RemoveGeometryCollectionActor
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105e32b00
	// Return & Params: [ Num(1) Size(0x8) ]
	void RemoveGeometryCollectionActor(struct AGeometryCollectionActor* GeometryCollectionActor);

	// Object: Function GeometryCollectionEngine.ChaosDestructionListener.RemoveChaosSolverActor
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105e32c00
	// Return & Params: [ Num(1) Size(0x8) ]
	void RemoveChaosSolverActor(struct AChaosSolverActor* ChaosSolverActor);

	// Object: Function GeometryCollectionEngine.ChaosDestructionListener.IsEventListening
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105e3276c
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsEventListening();

	// Object: Function GeometryCollectionEngine.ChaosDestructionListener.AddGeometryCollectionActor
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105e32b80
	// Return & Params: [ Num(1) Size(0x8) ]
	void AddGeometryCollectionActor(struct AGeometryCollectionActor* GeometryCollectionActor);

	// Object: Function GeometryCollectionEngine.ChaosDestructionListener.AddChaosSolverActor
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105e32c80
	// Return & Params: [ Num(1) Size(0x8) ]
	void AddChaosSolverActor(struct AChaosSolverActor* ChaosSolverActor);
};

// Object: Class GeometryCollectionEngine.GeometryCollectionActor
// Inherited Bytes: 0x230 | Struct Size: 0x240
struct AGeometryCollectionActor : AActor {
	// Fields
	struct UGeometryCollectionComponent* GeometryCollectionComponent; // Offset: 0x230 | Size: 0x8
	struct UGeometryCollectionDebugDrawComponent* GeometryCollectionDebugDrawComponent; // Offset: 0x238 | Size: 0x8

	// Functions

	// Object: Function GeometryCollectionEngine.GeometryCollectionActor.RaycastSingle
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x105e33b44
	// Return & Params: [ Num(4) Size(0xa1) ]
	bool RaycastSingle(struct FVector Start, struct FVector End, struct FHitResult& OutHit);
};

// Object: Class GeometryCollectionEngine.GeometryCollectionCache
// Inherited Bytes: 0x28 | Struct Size: 0x50
struct UGeometryCollectionCache : UObject {
	// Fields
	struct FRecordedTransformTrack RecordedData; // Offset: 0x28 | Size: 0x10
	struct UGeometryCollection* SupportedCollection; // Offset: 0x38 | Size: 0x8
	struct FGuid CompatibleCollectionState; // Offset: 0x40 | Size: 0x10
};

// Object: Class GeometryCollectionEngine.GeometryCollectionComponent
// Inherited Bytes: 0x680 | Struct Size: 0xac0
struct UGeometryCollectionComponent : UMeshComponent {
	// Fields
	struct AChaosSolverActor* ChaosSolverActor; // Offset: 0x680 | Size: 0x8
	char pad_0x688[0xe0]; // Offset: 0x688 | Size: 0xe0
	struct UGeometryCollection* RestCollection; // Offset: 0x768 | Size: 0x8
	struct TArray<struct AFieldSystemActor*> InitializationFields; // Offset: 0x770 | Size: 0x10
	bool Simulating; // Offset: 0x780 | Size: 0x1
	char pad_0x781[0x7]; // Offset: 0x781 | Size: 0x7
	enum class EObjectStateTypeEnum ObjectType; // Offset: 0x788 | Size: 0x1
	bool EnableClustering; // Offset: 0x789 | Size: 0x1
	char pad_0x78A[0x2]; // Offset: 0x78a | Size: 0x2
	int32_t ClusterGroupIndex; // Offset: 0x78c | Size: 0x4
	int32_t MaxClusterLevel; // Offset: 0x790 | Size: 0x4
	char pad_0x794[0x4]; // Offset: 0x794 | Size: 0x4
	struct TArray<float> DamageThreshold; // Offset: 0x798 | Size: 0x10
	enum class EClusterConnectionTypeEnum ClusterConnectionType; // Offset: 0x7a8 | Size: 0x1
	char pad_0x7A9[0x3]; // Offset: 0x7a9 | Size: 0x3
	int32_t CollisionGroup; // Offset: 0x7ac | Size: 0x4
	float CollisionSampleFraction; // Offset: 0x7b0 | Size: 0x4
	float LinearEtherDrag; // Offset: 0x7b4 | Size: 0x4
	float AngularEtherDrag; // Offset: 0x7b8 | Size: 0x4
	char pad_0x7BC[0x4]; // Offset: 0x7bc | Size: 0x4
	struct UChaosPhysicalMaterial* PhysicalMaterial; // Offset: 0x7c0 | Size: 0x8
	enum class EInitialVelocityTypeEnum InitialVelocityType; // Offset: 0x7c8 | Size: 0x1
	char pad_0x7C9[0x3]; // Offset: 0x7c9 | Size: 0x3
	struct FVector InitialLinearVelocity; // Offset: 0x7cc | Size: 0xc
	struct FVector InitialAngularVelocity; // Offset: 0x7d8 | Size: 0xc
	char pad_0x7E4[0x4]; // Offset: 0x7e4 | Size: 0x4
	struct FGeomComponentCacheParameters CacheParameters; // Offset: 0x7e8 | Size: 0x50
	struct FMulticastInlineDelegate NotifyGeometryCollectionPhysicsStateChange; // Offset: 0x838 | Size: 0x10
	struct FMulticastInlineDelegate NotifyGeometryCollectionPhysicsLoadingStateChange; // Offset: 0x848 | Size: 0x10
	char pad_0x858[0x18]; // Offset: 0x858 | Size: 0x18
	struct FMulticastInlineDelegate OnChaosBreakEvent; // Offset: 0x870 | Size: 0x10
	float DesiredCacheTime; // Offset: 0x880 | Size: 0x4
	bool CachePlayback; // Offset: 0x884 | Size: 0x1
	char pad_0x885[0x3]; // Offset: 0x885 | Size: 0x3
	struct FMulticastInlineDelegate OnChaosPhysicsCollision; // Offset: 0x888 | Size: 0x10
	bool bNotifyBreaks; // Offset: 0x898 | Size: 0x1
	bool bNotifyCollisions; // Offset: 0x899 | Size: 0x1
	char pad_0x89A[0x1fe]; // Offset: 0x89a | Size: 0x1fe
	struct UBodySetup* DummyBodySetup; // Offset: 0xa98 | Size: 0x8
	char pad_0xAA0[0x20]; // Offset: 0xaa0 | Size: 0x20

	// Functions

	// Object: Function GeometryCollectionEngine.GeometryCollectionComponent.SetNotifyBreaks
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105e3461c
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetNotifyBreaks(bool bNewNotifyBreaks);

	// Object: Function GeometryCollectionEngine.GeometryCollectionComponent.ReceivePhysicsCollision
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x70) ]
	void ReceivePhysicsCollision(struct FChaosPhysicsCollisionInfo& CollisionInfo);

	// Object: DelegateFunction GeometryCollectionEngine.GeometryCollectionComponent.NotifyGeometryCollectionPhysicsStateChange__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x8) ]
	void NotifyGeometryCollectionPhysicsStateChange__DelegateSignature(struct UGeometryCollectionComponent* FracturedComponent);

	// Object: DelegateFunction GeometryCollectionEngine.GeometryCollectionComponent.NotifyGeometryCollectionPhysicsLoadingStateChange__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x8) ]
	void NotifyGeometryCollectionPhysicsLoadingStateChange__DelegateSignature(struct UGeometryCollectionComponent* FracturedComponent);

	// Object: Function GeometryCollectionEngine.GeometryCollectionComponent.ApplyPhysicsField
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105e346a4
	// Return & Params: [ Num(4) Size(0x18) ]
	void ApplyPhysicsField(bool Enabled, enum class EGeometryCollectionPhysicsTypeEnum Target, struct UFieldSystemMetaData* MetaData, struct UFieldNodeBase* Field);

	// Object: Function GeometryCollectionEngine.GeometryCollectionComponent.ApplyKinematicField
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x105e34818
	// Return & Params: [ Num(2) Size(0x10) ]
	void ApplyKinematicField(float Radius, struct FVector Position);
};

// Object: Class GeometryCollectionEngine.GeometryCollectionDebugDrawActor
// Inherited Bytes: 0x230 | Struct Size: 0x318
struct AGeometryCollectionDebugDrawActor : AActor {
	// Fields
	struct FGeometryCollectionDebugDrawWarningMessage WarningMessage; // Offset: 0x230 | Size: 0x1
	char pad_0x231[0x7]; // Offset: 0x231 | Size: 0x7
	struct FGeometryCollectionDebugDrawActorSelectedRigidBody SelectedRigidBody; // Offset: 0x238 | Size: 0x18
	bool bDebugDrawWholeCollection; // Offset: 0x250 | Size: 0x1
	bool bDebugDrawHierarchy; // Offset: 0x251 | Size: 0x1
	bool bDebugDrawClustering; // Offset: 0x252 | Size: 0x1
	enum class EGeometryCollectionDebugDrawActorHideGeometry HideGeometry; // Offset: 0x253 | Size: 0x1
	bool bShowRigidBodyId; // Offset: 0x254 | Size: 0x1
	bool bShowRigidBodyCollision; // Offset: 0x255 | Size: 0x1
	bool bCollisionAtOrigin; // Offset: 0x256 | Size: 0x1
	bool bShowRigidBodyTransform; // Offset: 0x257 | Size: 0x1
	bool bShowRigidBodyInertia; // Offset: 0x258 | Size: 0x1
	bool bShowRigidBodyVelocity; // Offset: 0x259 | Size: 0x1
	bool bShowRigidBodyForce; // Offset: 0x25a | Size: 0x1
	bool bShowRigidBodyInfos; // Offset: 0x25b | Size: 0x1
	bool bShowTransformIndex; // Offset: 0x25c | Size: 0x1
	bool bShowTransform; // Offset: 0x25d | Size: 0x1
	bool bShowParent; // Offset: 0x25e | Size: 0x1
	bool bShowLevel; // Offset: 0x25f | Size: 0x1
	bool bShowConnectivityEdges; // Offset: 0x260 | Size: 0x1
	bool bShowGeometryIndex; // Offset: 0x261 | Size: 0x1
	bool bShowGeometryTransform; // Offset: 0x262 | Size: 0x1
	bool bShowBoundingBox; // Offset: 0x263 | Size: 0x1
	bool bShowFaces; // Offset: 0x264 | Size: 0x1
	bool bShowFaceIndices; // Offset: 0x265 | Size: 0x1
	bool bShowFaceNormals; // Offset: 0x266 | Size: 0x1
	bool bShowSingleFace; // Offset: 0x267 | Size: 0x1
	int32_t SingleFaceIndex; // Offset: 0x268 | Size: 0x4
	bool bShowVertices; // Offset: 0x26c | Size: 0x1
	bool bShowVertexIndices; // Offset: 0x26d | Size: 0x1
	bool bShowVertexNormals; // Offset: 0x26e | Size: 0x1
	bool bUseActiveVisualization; // Offset: 0x26f | Size: 0x1
	float PointThickness; // Offset: 0x270 | Size: 0x4
	float LineThickness; // Offset: 0x274 | Size: 0x4
	bool bTextShadow; // Offset: 0x278 | Size: 0x1
	char pad_0x279[0x3]; // Offset: 0x279 | Size: 0x3
	float TextScale; // Offset: 0x27c | Size: 0x4
	float NormalScale; // Offset: 0x280 | Size: 0x4
	float AxisScale; // Offset: 0x284 | Size: 0x4
	float ArrowScale; // Offset: 0x288 | Size: 0x4
	struct FColor RigidBodyIdColor; // Offset: 0x28c | Size: 0x4
	float RigidBodyTransformScale; // Offset: 0x290 | Size: 0x4
	struct FColor RigidBodyCollisionColor; // Offset: 0x294 | Size: 0x4
	struct FColor RigidBodyInertiaColor; // Offset: 0x298 | Size: 0x4
	struct FColor RigidBodyVelocityColor; // Offset: 0x29c | Size: 0x4
	struct FColor RigidBodyForceColor; // Offset: 0x2a0 | Size: 0x4
	struct FColor RigidBodyInfoColor; // Offset: 0x2a4 | Size: 0x4
	struct FColor TransformIndexColor; // Offset: 0x2a8 | Size: 0x4
	float TransformScale; // Offset: 0x2ac | Size: 0x4
	struct FColor LevelColor; // Offset: 0x2b0 | Size: 0x4
	struct FColor ParentColor; // Offset: 0x2b4 | Size: 0x4
	float ConnectivityEdgeThickness; // Offset: 0x2b8 | Size: 0x4
	struct FColor GeometryIndexColor; // Offset: 0x2bc | Size: 0x4
	float GeometryTransformScale; // Offset: 0x2c0 | Size: 0x4
	struct FColor BoundingBoxColor; // Offset: 0x2c4 | Size: 0x4
	struct FColor FaceColor; // Offset: 0x2c8 | Size: 0x4
	struct FColor FaceIndexColor; // Offset: 0x2cc | Size: 0x4
	struct FColor FaceNormalColor; // Offset: 0x2d0 | Size: 0x4
	struct FColor SingleFaceColor; // Offset: 0x2d4 | Size: 0x4
	struct FColor VertexColor; // Offset: 0x2d8 | Size: 0x4
	struct FColor VertexIndexColor; // Offset: 0x2dc | Size: 0x4
	struct FColor VertexNormalColor; // Offset: 0x2e0 | Size: 0x4
	char pad_0x2E4[0x4]; // Offset: 0x2e4 | Size: 0x4
	struct UBillboardComponent* SpriteComponent; // Offset: 0x2e8 | Size: 0x8
	char pad_0x2F0[0x28]; // Offset: 0x2f0 | Size: 0x28
};

// Object: Class GeometryCollectionEngine.GeometryCollectionDebugDrawComponent
// Inherited Bytes: 0xb0 | Struct Size: 0xc8
struct UGeometryCollectionDebugDrawComponent : UActorComponent {
	// Fields
	struct AGeometryCollectionDebugDrawActor* GeometryCollectionDebugDrawActor; // Offset: 0xb0 | Size: 0x8
	struct AGeometryCollectionRenderLevelSetActor* GeometryCollectionRenderLevelSetActor; // Offset: 0xb8 | Size: 0x8
	char pad_0xC0[0x8]; // Offset: 0xc0 | Size: 0x8
};

// Object: Class GeometryCollectionEngine.GeometryCollection
// Inherited Bytes: 0x28 | Struct Size: 0xd0
struct UGeometryCollection : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
	struct TArray<struct UMaterialInterface*> Materials; // Offset: 0x30 | Size: 0x10
	enum class ECollisionTypeEnum CollisionType; // Offset: 0x40 | Size: 0x1
	enum class EImplicitTypeEnum ImplicitType; // Offset: 0x41 | Size: 0x1
	char pad_0x42[0x2]; // Offset: 0x42 | Size: 0x2
	int32_t MinLevelSetResolution; // Offset: 0x44 | Size: 0x4
	int32_t MaxLevelSetResolution; // Offset: 0x48 | Size: 0x4
	int32_t MinClusterLevelSetResolution; // Offset: 0x4c | Size: 0x4
	int32_t MaxClusterLevelSetResolution; // Offset: 0x50 | Size: 0x4
	float CollisionObjectReductionPercentage; // Offset: 0x54 | Size: 0x4
	bool bMassAsDensity; // Offset: 0x58 | Size: 0x1
	char pad_0x59[0x3]; // Offset: 0x59 | Size: 0x3
	float Mass; // Offset: 0x5c | Size: 0x4
	float MinimumMassClamp; // Offset: 0x60 | Size: 0x4
	float CollisionParticlesFraction; // Offset: 0x64 | Size: 0x4
	int32_t MaximumCollisionParticles; // Offset: 0x68 | Size: 0x4
	char pad_0x6C[0x4]; // Offset: 0x6c | Size: 0x4
	struct TArray<struct FGeometryCollectionSizeSpecificData> SizeSpecificData; // Offset: 0x70 | Size: 0x10
	bool EnableRemovePiecesOnFracture; // Offset: 0x80 | Size: 0x1
	char pad_0x81[0x7]; // Offset: 0x81 | Size: 0x7
	struct TArray<struct UMaterialInterface*> RemoveOnFractureMaterials; // Offset: 0x88 | Size: 0x10
	struct FGuid PersistentGuid; // Offset: 0x98 | Size: 0x10
	struct FGuid StateGuid; // Offset: 0xa8 | Size: 0x10
	int32_t BoneSelectedMaterialIndex; // Offset: 0xb8 | Size: 0x4
	char pad_0xBC[0x14]; // Offset: 0xbc | Size: 0x14
};

// Object: Class GeometryCollectionEngine.GeometryCollectionRenderLevelSetActor
// Inherited Bytes: 0x230 | Struct Size: 0x2d0
struct AGeometryCollectionRenderLevelSetActor : AActor {
	// Fields
	struct UVolumeTexture* TargetVolumeTexture; // Offset: 0x230 | Size: 0x8
	struct UMaterial* RayMarchMaterial; // Offset: 0x238 | Size: 0x8
	float SurfaceTolerance; // Offset: 0x240 | Size: 0x4
	float Isovalue; // Offset: 0x244 | Size: 0x4
	bool Enabled; // Offset: 0x248 | Size: 0x1
	bool RenderVolumeBoundingBox; // Offset: 0x249 | Size: 0x1
	char pad_0x24A[0x86]; // Offset: 0x24a | Size: 0x86
};

// Object: Class GeometryCollectionEngine.SkeletalMeshSimulationComponent
// Inherited Bytes: 0xb0 | Struct Size: 0x138
struct USkeletalMeshSimulationComponent : UActorComponent {
	// Fields
	char pad_0xB0[0x8]; // Offset: 0xb0 | Size: 0x8
	struct UChaosPhysicalMaterial* PhysicalMaterial; // Offset: 0xb8 | Size: 0x8
	struct AChaosSolverActor* ChaosSolverActor; // Offset: 0xc0 | Size: 0x8
	struct UPhysicsAsset* OverridePhysicsAsset; // Offset: 0xc8 | Size: 0x8
	bool bSimulating; // Offset: 0xd0 | Size: 0x1
	bool bNotifyCollisions; // Offset: 0xd1 | Size: 0x1
	enum class EObjectStateTypeEnum ObjectType; // Offset: 0xd2 | Size: 0x1
	char pad_0xD3[0x1]; // Offset: 0xd3 | Size: 0x1
	float Density; // Offset: 0xd4 | Size: 0x4
	float MinMass; // Offset: 0xd8 | Size: 0x4
	float MaxMass; // Offset: 0xdc | Size: 0x4
	enum class ECollisionTypeEnum CollisionType; // Offset: 0xe0 | Size: 0x1
	char pad_0xE1[0x3]; // Offset: 0xe1 | Size: 0x3
	float ImplicitShapeParticlesPerUnitArea; // Offset: 0xe4 | Size: 0x4
	int32_t ImplicitShapeMinNumParticles; // Offset: 0xe8 | Size: 0x4
	int32_t ImplicitShapeMaxNumParticles; // Offset: 0xec | Size: 0x4
	int32_t MinLevelSetResolution; // Offset: 0xf0 | Size: 0x4
	int32_t MaxLevelSetResolution; // Offset: 0xf4 | Size: 0x4
	int32_t CollisionGroup; // Offset: 0xf8 | Size: 0x4
	enum class EInitialVelocityTypeEnum InitialVelocityType; // Offset: 0xfc | Size: 0x1
	char pad_0xFD[0x3]; // Offset: 0xfd | Size: 0x3
	struct FVector InitialLinearVelocity; // Offset: 0x100 | Size: 0xc
	struct FVector InitialAngularVelocity; // Offset: 0x10c | Size: 0xc
	struct FMulticastInlineDelegate OnChaosPhysicsCollision; // Offset: 0x118 | Size: 0x10
	char pad_0x128[0x10]; // Offset: 0x128 | Size: 0x10

	// Functions

	// Object: Function GeometryCollectionEngine.SkeletalMeshSimulationComponent.ReceivePhysicsCollision
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x70) ]
	void ReceivePhysicsCollision(struct FChaosPhysicsCollisionInfo& CollisionInfo);
};

// Object: Class GeometryCollectionEngine.StaticMeshSimulationComponent
// Inherited Bytes: 0xb0 | Struct Size: 0x138
struct UStaticMeshSimulationComponent : UActorComponent {
	// Fields
	char pad_0xB0[0x8]; // Offset: 0xb0 | Size: 0x8
	bool Simulating; // Offset: 0xb8 | Size: 0x1
	bool bNotifyCollisions; // Offset: 0xb9 | Size: 0x1
	enum class EObjectStateTypeEnum ObjectType; // Offset: 0xba | Size: 0x1
	char pad_0xBB[0x1]; // Offset: 0xbb | Size: 0x1
	float Mass; // Offset: 0xbc | Size: 0x4
	enum class ECollisionTypeEnum CollisionType; // Offset: 0xc0 | Size: 0x1
	enum class EImplicitTypeEnum ImplicitType; // Offset: 0xc1 | Size: 0x1
	char pad_0xC2[0x2]; // Offset: 0xc2 | Size: 0x2
	int32_t MinLevelSetResolution; // Offset: 0xc4 | Size: 0x4
	int32_t MaxLevelSetResolution; // Offset: 0xc8 | Size: 0x4
	enum class EInitialVelocityTypeEnum InitialVelocityType; // Offset: 0xcc | Size: 0x1
	char pad_0xCD[0x3]; // Offset: 0xcd | Size: 0x3
	struct FVector InitialLinearVelocity; // Offset: 0xd0 | Size: 0xc
	struct FVector InitialAngularVelocity; // Offset: 0xdc | Size: 0xc
	float DamageThreshold; // Offset: 0xe8 | Size: 0x4
	char pad_0xEC[0x4]; // Offset: 0xec | Size: 0x4
	struct UChaosPhysicalMaterial* PhysicalMaterial; // Offset: 0xf0 | Size: 0x8
	struct AChaosSolverActor* ChaosSolverActor; // Offset: 0xf8 | Size: 0x8
	struct FMulticastInlineDelegate OnChaosPhysicsCollision; // Offset: 0x100 | Size: 0x10
	char pad_0x110[0x10]; // Offset: 0x110 | Size: 0x10
	struct TArray<struct UPrimitiveComponent*> SimulatedComponents; // Offset: 0x120 | Size: 0x10
	char pad_0x130[0x8]; // Offset: 0x130 | Size: 0x8

	// Functions

	// Object: Function GeometryCollectionEngine.StaticMeshSimulationComponent.ReceivePhysicsCollision
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x70) ]
	void ReceivePhysicsCollision(struct FChaosPhysicsCollisionInfo& CollisionInfo);

	// Object: Function GeometryCollectionEngine.StaticMeshSimulationComponent.ForceRecreatePhysicsState
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x105e35c64
	// Return & Params: [ Num(0) Size(0x0) ]
	void ForceRecreatePhysicsState();
};

