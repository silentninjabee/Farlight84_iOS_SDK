#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass HUD_StripBulletContainer_New.HUD_StripBulletContainer_New_C
// Inherited Bytes: 0x508 | Struct Size: 0x518
struct UHUD_StripBulletContainer_New_C : UGridBulletContainerNew {
	// Fields
	struct UWidgetAnimation* Anim_Light; // Offset: 0x508 | Size: 0x8
	struct UWidgetAnimation* Anim_Empty; // Offset: 0x510 | Size: 0x8
};

