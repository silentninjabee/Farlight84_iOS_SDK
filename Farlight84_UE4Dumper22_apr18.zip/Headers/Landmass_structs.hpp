#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct Landmass.LandmassBrushEffectsList
// Inherited Bytes: 0x0 | Struct Size: 0x60
struct FLandmassBrushEffectsList {
	// Fields
	struct FBrushEffectBlurring Blurring; // Offset: 0x0 | Size: 0x8
	struct FBrushEffectCurlNoise CurlNoise; // Offset: 0x8 | Size: 0x10
	struct FBrushEffectDisplacement Displacement; // Offset: 0x18 | Size: 0x28
	struct FBrushEffectSmoothBlending SmoothBlending; // Offset: 0x40 | Size: 0x8
	struct FBrushEffectTerracing Terracing; // Offset: 0x48 | Size: 0x14
	char pad_0x5C[0x4]; // Offset: 0x5c | Size: 0x4
};

// Object: ScriptStruct Landmass.BrushEffectTerracing
// Inherited Bytes: 0x0 | Struct Size: 0x14
struct FBrushEffectTerracing {
	// Fields
	float TerraceAlpha; // Offset: 0x0 | Size: 0x4
	float TerraceSpacing; // Offset: 0x4 | Size: 0x4
	float TerraceSmoothness; // Offset: 0x8 | Size: 0x4
	float MaskLength; // Offset: 0xc | Size: 0x4
	float MaskStartOffset; // Offset: 0x10 | Size: 0x4
};

// Object: ScriptStruct Landmass.BrushEffectSmoothBlending
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FBrushEffectSmoothBlending {
	// Fields
	float InnerSmoothDistance; // Offset: 0x0 | Size: 0x4
	float OuterSmoothDistance; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct Landmass.BrushEffectDisplacement
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FBrushEffectDisplacement {
	// Fields
	float DisplacementHeight; // Offset: 0x0 | Size: 0x4
	float DisplacementTiling; // Offset: 0x4 | Size: 0x4
	struct UTexture2D* Texture; // Offset: 0x8 | Size: 0x8
	float Midpoint; // Offset: 0x10 | Size: 0x4
	struct FLinearColor Channel; // Offset: 0x14 | Size: 0x10
	float WeightmapInfluence; // Offset: 0x24 | Size: 0x4
};

// Object: ScriptStruct Landmass.BrushEffectCurlNoise
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FBrushEffectCurlNoise {
	// Fields
	float Curl1Amount; // Offset: 0x0 | Size: 0x4
	float Curl2Amount; // Offset: 0x4 | Size: 0x4
	float Curl1Tiling; // Offset: 0x8 | Size: 0x4
	float Curl2Tiling; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct Landmass.BrushEffectBlurring
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FBrushEffectBlurring {
	// Fields
	bool bBlurShape; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	int32_t Radius; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct Landmass.BrushEffectCurves
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FBrushEffectCurves {
	// Fields
	bool bUseCurveChannel; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x7]; // Offset: 0x1 | Size: 0x7
	struct UCurveFloat* ElevationCurveAsset; // Offset: 0x8 | Size: 0x8
	float ChannelEdgeOffset; // Offset: 0x10 | Size: 0x4
	float ChannelDepth; // Offset: 0x14 | Size: 0x4
	float CurveRampWidth; // Offset: 0x18 | Size: 0x4
	char pad_0x1C[0x4]; // Offset: 0x1c | Size: 0x4
};

// Object: ScriptStruct Landmass.LandmassFalloffSettings
// Inherited Bytes: 0x0 | Struct Size: 0x14
struct FLandmassFalloffSettings {
	// Fields
	enum class EBrushFalloffMode FalloffMode; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	float FalloffAngle; // Offset: 0x4 | Size: 0x4
	float FalloffWidth; // Offset: 0x8 | Size: 0x4
	float EdgeOffset; // Offset: 0xc | Size: 0x4
	float ZOffset; // Offset: 0x10 | Size: 0x4
};

// Object: ScriptStruct Landmass.LandmassTerrainCarvingSettings
// Inherited Bytes: 0x0 | Struct Size: 0x80
struct FLandmassTerrainCarvingSettings {
	// Fields
	enum class EBrushBlendType BlendMode; // Offset: 0x0 | Size: 0x1
	bool bInvertShape; // Offset: 0x1 | Size: 0x1
	char pad_0x2[0x2]; // Offset: 0x2 | Size: 0x2
	struct FLandmassFalloffSettings FalloffSettings; // Offset: 0x4 | Size: 0x14
	struct FLandmassBrushEffectsList Effects; // Offset: 0x18 | Size: 0x60
	int32_t Priority; // Offset: 0x78 | Size: 0x4
	char pad_0x7C[0x4]; // Offset: 0x7c | Size: 0x4
};

