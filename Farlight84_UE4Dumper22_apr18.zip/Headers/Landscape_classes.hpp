#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class Landscape.ControlPointMeshActor
// Inherited Bytes: 0x230 | Struct Size: 0x238
struct AControlPointMeshActor : AActor {
	// Fields
	struct UControlPointMeshComponent* ControlPointMeshComponent; // Offset: 0x230 | Size: 0x8
};

// Object: Class Landscape.ControlPointMeshComponent
// Inherited Bytes: 0x830 | Struct Size: 0x830
struct UControlPointMeshComponent : UStaticMeshComponent {
	// Fields
	float VirtualTextureMainPassMaxDrawDistance; // Offset: 0x828 | Size: 0x4
};

// Object: Class Landscape.LandscapeProxy
// Inherited Bytes: 0x230 | Struct Size: 0x568
struct ALandscapeProxy : AActor {
	// Fields
	struct ULandscapeSplinesComponent* SplineComponent; // Offset: 0x230 | Size: 0x8
	struct FGuid LandscapeGuid; // Offset: 0x238 | Size: 0x10
	struct FIntPoint LandscapeSectionOffset; // Offset: 0x248 | Size: 0x8
	int32_t MaxLODLevel; // Offset: 0x250 | Size: 0x4
	float LODDistanceFactor; // Offset: 0x254 | Size: 0x4
	enum class ELandscapeLODFalloff LODFalloff; // Offset: 0x258 | Size: 0x1
	char pad_0x259[0x3]; // Offset: 0x259 | Size: 0x3
	float ComponentScreenSizeToUseSubSections; // Offset: 0x25c | Size: 0x4
	float LOD0ScreenSize; // Offset: 0x260 | Size: 0x4
	float LOD0DistributionSetting; // Offset: 0x264 | Size: 0x4
	float LODDistributionSetting; // Offset: 0x268 | Size: 0x4
	float TessellationComponentScreenSize; // Offset: 0x26c | Size: 0x4
	bool UseTessellationComponentScreenSizeFalloff; // Offset: 0x270 | Size: 0x1
	char pad_0x271[0x3]; // Offset: 0x271 | Size: 0x3
	float TessellationComponentScreenSizeFalloff; // Offset: 0x274 | Size: 0x4
	int32_t OccluderGeometryLOD; // Offset: 0x278 | Size: 0x4
	int32_t StaticLightingLOD; // Offset: 0x27c | Size: 0x4
	struct UPhysicalMaterial* DefaultPhysMaterial; // Offset: 0x280 | Size: 0x8
	float StreamingDistanceMultiplier; // Offset: 0x288 | Size: 0x4
	char pad_0x28C[0x4]; // Offset: 0x28c | Size: 0x4
	struct UMaterialInterface* LandscapeMaterial; // Offset: 0x290 | Size: 0x8
	char pad_0x298[0x20]; // Offset: 0x298 | Size: 0x20
	struct UMaterialInterface* LandscapeHoleMaterial; // Offset: 0x2b8 | Size: 0x8
	struct TArray<struct FLandscapeProxyMaterialOverride> LandscapeMaterialsOverride; // Offset: 0x2c0 | Size: 0x10
	bool bMeshHoles; // Offset: 0x2d0 | Size: 0x1
	char MeshHolesMaxLod; // Offset: 0x2d1 | Size: 0x1
	char pad_0x2D2[0x6]; // Offset: 0x2d2 | Size: 0x6
	struct TArray<struct URuntimeVirtualTexture*> RuntimeVirtualTextures; // Offset: 0x2d8 | Size: 0x10
	int32_t VirtualTextureNumLods; // Offset: 0x2e8 | Size: 0x4
	int32_t VirtualTextureLodBias; // Offset: 0x2ec | Size: 0x4
	enum class ERuntimeVirtualTextureMainPassType VirtualTextureRenderPassType; // Offset: 0x2f0 | Size: 0x1
	char pad_0x2F1[0x3]; // Offset: 0x2f1 | Size: 0x3
	float NegativeZBoundsExtension; // Offset: 0x2f4 | Size: 0x4
	float PositiveZBoundsExtension; // Offset: 0x2f8 | Size: 0x4
	char pad_0x2FC[0x4]; // Offset: 0x2fc | Size: 0x4
	struct TArray<struct ULandscapeComponent*> LandscapeComponents; // Offset: 0x300 | Size: 0x10
	struct TArray<struct ULandscapeHeightfieldCollisionComponent*> CollisionComponents; // Offset: 0x310 | Size: 0x10
	struct TArray<struct UHierarchicalInstancedStaticMeshComponent*> FoliageComponents; // Offset: 0x320 | Size: 0x10
	char pad_0x330[0x64]; // Offset: 0x330 | Size: 0x64
	bool bHasLandscapeGrass; // Offset: 0x394 | Size: 0x1
	char pad_0x395[0x3]; // Offset: 0x395 | Size: 0x3
	float StaticLightingResolution; // Offset: 0x398 | Size: 0x4
	char bCastStaticShadow : 1; // Offset: 0x39c | Size: 0x1
	char bCastShadowAsTwoSided : 1; // Offset: 0x39c | Size: 0x1
	char bCastFarShadow : 1; // Offset: 0x39c | Size: 0x1
	char bAffectDistanceFieldLighting : 1; // Offset: 0x39c | Size: 0x1
	char pad_0x39C_4 : 4; // Offset: 0x39c | Size: 0x1
	struct FLightingChannels LightingChannels; // Offset: 0x39d | Size: 0x1
	char bUseMaterialPositionOffsetInStaticLighting : 1; // Offset: 0x39e | Size: 0x1
	char bRenderCustomDepth : 1; // Offset: 0x39e | Size: 0x1
	char pad_0x39E_2 : 6; // Offset: 0x39e | Size: 0x1
	char pad_0x39F[0x1]; // Offset: 0x39f | Size: 0x1
	int32_t CustomDepthStencilValue; // Offset: 0x3a0 | Size: 0x4
	float LDMaxDrawDistance; // Offset: 0x3a4 | Size: 0x4
	struct FLightmassPrimitiveSettings LightmassSettings; // Offset: 0x3a8 | Size: 0x18
	int32_t CollisionMipLevel; // Offset: 0x3c0 | Size: 0x4
	int32_t SimpleCollisionMipLevel; // Offset: 0x3c4 | Size: 0x4
	float CollisionThickness; // Offset: 0x3c8 | Size: 0x4
	char pad_0x3CC[0x4]; // Offset: 0x3cc | Size: 0x4
	struct FBodyInstance BodyInstance; // Offset: 0x3d0 | Size: 0x130
	char bGenerateOverlapEvents : 1; // Offset: 0x500 | Size: 0x1
	char bBakeMaterialPositionOffsetIntoCollision : 1; // Offset: 0x500 | Size: 0x1
	char pad_0x500_2 : 6; // Offset: 0x500 | Size: 0x1
	char pad_0x501[0x3]; // Offset: 0x501 | Size: 0x3
	int32_t ComponentSizeQuads; // Offset: 0x504 | Size: 0x4
	int32_t SubsectionSizeQuads; // Offset: 0x508 | Size: 0x4
	int32_t NumSubsections; // Offset: 0x50c | Size: 0x4
	char bUsedForNavigation : 1; // Offset: 0x510 | Size: 0x1
	char bFillCollisionUnderLandscapeForNavmesh : 1; // Offset: 0x510 | Size: 0x1
	char pad_0x510_2 : 6; // Offset: 0x510 | Size: 0x1
	bool bUseDynamicMaterialInstance; // Offset: 0x511 | Size: 0x1
	enum class ENavDataGatheringMode NavigationGeometryGatheringMode; // Offset: 0x512 | Size: 0x1
	bool bUseLandscapeForCullingInvisibleHLODVertices; // Offset: 0x513 | Size: 0x1
	bool bHasLayersContent; // Offset: 0x514 | Size: 0x1
	char pad_0x515[0x3]; // Offset: 0x515 | Size: 0x3
	struct TMap<struct UTexture2D*, struct ULandscapeWeightmapUsage*> WeightmapUsageMap; // Offset: 0x518 | Size: 0x50

	// Functions

	// Object: Function Landscape.LandscapeProxy.SetLandscapeMaterialVectorParameterValue
	// Flags: [Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x104d578dc
	// Return & Params: [ Num(2) Size(0x18) ]
	void SetLandscapeMaterialVectorParameterValue(struct FName ParameterName, struct FLinearColor Value);

	// Object: Function Landscape.LandscapeProxy.SetLandscapeMaterialTextureParameterValue
	// Flags: [Final|RequiredAPI|Native|Public|BlueprintCallable]
	// Offset: 0x104d579a4
	// Return & Params: [ Num(2) Size(0x10) ]
	void SetLandscapeMaterialTextureParameterValue(struct FName ParameterName, struct UTexture* Value);

	// Object: Function Landscape.LandscapeProxy.SetLandscapeMaterialScalarParameterValue
	// Flags: [Final|RequiredAPI|Native|Public|BlueprintCallable]
	// Offset: 0x104d57810
	// Return & Params: [ Num(2) Size(0xc) ]
	void SetLandscapeMaterialScalarParameterValue(struct FName ParameterName, float Value);

	// Object: Function Landscape.LandscapeProxy.EditorSetLandscapeMaterial
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104d57dfc
	// Return & Params: [ Num(1) Size(0x8) ]
	void EditorSetLandscapeMaterial(struct UMaterialInterface* NewLandscapeMaterial);

	// Object: Function Landscape.LandscapeProxy.EditorApplySpline
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104d57a6c
	// Return & Params: [ Num(11) Size(0x30) ]
	void EditorApplySpline(struct USplineComponent* InSplineComponent, float StartWidth, float EndWidth, float StartSideFalloff, float EndSideFalloff, float StartRoll, float EndRoll, int32_t NumSubdivisions, bool bRaiseHeights, bool bLowerHeights, struct ULandscapeLayerInfoObject* PaintLayer);

	// Object: Function Landscape.LandscapeProxy.ChangeUseTessellationComponentScreenSizeFalloff
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104d57f04
	// Return & Params: [ Num(1) Size(0x1) ]
	void ChangeUseTessellationComponentScreenSizeFalloff(bool InComponentScreenSizeToUseSubSections);

	// Object: Function Landscape.LandscapeProxy.ChangeTessellationComponentScreenSizeFalloff
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104d57e7c
	// Return & Params: [ Num(1) Size(0x4) ]
	void ChangeTessellationComponentScreenSizeFalloff(float InUseTessellationComponentScreenSizeFalloff);

	// Object: Function Landscape.LandscapeProxy.ChangeTessellationComponentScreenSize
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104d5801c
	// Return & Params: [ Num(1) Size(0x4) ]
	void ChangeTessellationComponentScreenSize(float InTessellationComponentScreenSize);

	// Object: Function Landscape.LandscapeProxy.ChangeLODDistanceFactor
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104d580a4
	// Return & Params: [ Num(1) Size(0x4) ]
	void ChangeLODDistanceFactor(float InLODDistanceFactor);

	// Object: Function Landscape.LandscapeProxy.ChangeComponentScreenSizeToUseSubSections
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104d57f94
	// Return & Params: [ Num(1) Size(0x4) ]
	void ChangeComponentScreenSizeToUseSubSections(float InComponentScreenSizeToUseSubSections);
};

// Object: Class Landscape.Landscape
// Inherited Bytes: 0x568 | Struct Size: 0x568
struct ALandscape : ALandscapeProxy {
};

// Object: Class Landscape.LandscapeBlueprintBrushBase
// Inherited Bytes: 0x230 | Struct Size: 0x230
struct ALandscapeBlueprintBrushBase : AActor {
	// Functions

	// Object: Function Landscape.LandscapeBlueprintBrushBase.RequestLandscapeUpdate
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104d50fb4
	// Return & Params: [ Num(0) Size(0x0) ]
	void RequestLandscapeUpdate();

	// Object: Function Landscape.LandscapeBlueprintBrushBase.Render
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(4) Size(0x20) ]
	struct UTextureRenderTarget2D* Render(bool InIsHeightmap, struct UTextureRenderTarget2D* InCombinedResult, struct FName& InWeightmapLayerName);

	// Object: Function Landscape.LandscapeBlueprintBrushBase.Initialize
	// Flags: [Event|Public|HasOutParms|HasDefaults|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(3) Size(0x40) ]
	void Initialize(struct FTransform& InLandscapeTransform, struct FIntPoint& InLandscapeSize, struct FIntPoint& InLandscapeRenderTargetSize);

	// Object: Function Landscape.LandscapeBlueprintBrushBase.GetBlueprintRenderDependencies
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x10) ]
	void GetBlueprintRenderDependencies(struct TArray<struct UTexture2D*>& OutStreamableAssets);
};

// Object: Class Landscape.LandscapeComponent
// Inherited Bytes: 0x5d0 | Struct Size: 0x7c0
struct ULandscapeComponent : UPrimitiveComponent {
	// Fields
	int32_t SectionBaseX; // Offset: 0x5c8 | Size: 0x4
	int32_t SectionBaseY; // Offset: 0x5cc | Size: 0x4
	int32_t ComponentSizeQuads; // Offset: 0x5d0 | Size: 0x4
	int32_t SubsectionSizeQuads; // Offset: 0x5d4 | Size: 0x4
	int32_t NumSubsections; // Offset: 0x5d8 | Size: 0x4
	struct UMaterialInterface* OverrideMaterial; // Offset: 0x5e0 | Size: 0x8
	struct UMaterialInterface* OverrideHoleMaterial; // Offset: 0x5e8 | Size: 0x8
	struct TArray<struct FLandscapeComponentMaterialOverride> OverrideMaterials; // Offset: 0x5f0 | Size: 0x10
	int32_t OverrideMaxLODLevel; // Offset: 0x600 | Size: 0x4
	struct TArray<struct UMaterialInstanceConstant*> MaterialInstances; // Offset: 0x608 | Size: 0x10
	struct TArray<struct UMaterialInstanceDynamic*> MaterialInstancesDynamic; // Offset: 0x618 | Size: 0x10
	struct TArray<int8_t> LODIndexToMaterialIndex; // Offset: 0x628 | Size: 0x10
	struct TArray<int8_t> MaterialIndexToDisabledTessellationMaterial; // Offset: 0x638 | Size: 0x10
	struct UTexture2D* XYOffsetmapTexture; // Offset: 0x648 | Size: 0x8
	struct FVector4 WeightmapScaleBias; // Offset: 0x650 | Size: 0x10
	float WeightmapSubsectionOffset; // Offset: 0x660 | Size: 0x4
	char pad_0x664[0xc]; // Offset: 0x664 | Size: 0xc
	struct FVector4 HeightmapScaleBias; // Offset: 0x670 | Size: 0x10
	struct FBox CachedLocalBox; // Offset: 0x680 | Size: 0x1c
	LazyObjectProperty CollisionComponent; // Offset: 0x69c | Size: 0x1c
	struct UTexture2D* HeightmapTexture; // Offset: 0x6b8 | Size: 0x8
	struct TArray<struct FWeightmapLayerAllocationInfo> WeightmapLayerAllocations; // Offset: 0x6c0 | Size: 0x10
	struct TArray<struct UTexture2D*> WeightmapTextures; // Offset: 0x6d0 | Size: 0x10
	struct FGuid MapBuildDataId; // Offset: 0x6e0 | Size: 0x10
	struct TArray<struct FGuid> IrrelevantLights; // Offset: 0x6f0 | Size: 0x10
	int32_t CollisionMipLevel; // Offset: 0x700 | Size: 0x4
	int32_t SimpleCollisionMipLevel; // Offset: 0x704 | Size: 0x4
	float NegativeZBoundsExtension; // Offset: 0x708 | Size: 0x4
	float PositiveZBoundsExtension; // Offset: 0x70c | Size: 0x4
	float StaticLightingResolution; // Offset: 0x710 | Size: 0x4
	int32_t ForcedLOD; // Offset: 0x714 | Size: 0x4
	int32_t LODBias; // Offset: 0x718 | Size: 0x4
	struct FGuid StateId; // Offset: 0x71c | Size: 0x10
	struct FGuid BakedTextureMaterialGuid; // Offset: 0x72c | Size: 0x10
	char pad_0x73C[0x4]; // Offset: 0x73c | Size: 0x4
	struct UTexture2D* GIBakedBaseColorTexture; // Offset: 0x740 | Size: 0x8
	char MobileBlendableLayerMask; // Offset: 0x748 | Size: 0x1
	char pad_0x749[0x7]; // Offset: 0x749 | Size: 0x7
	struct UMaterialInterface* MobileMaterialInterface; // Offset: 0x750 | Size: 0x8
	struct TArray<struct UMaterialInterface*> MobileMaterialInterfaces; // Offset: 0x758 | Size: 0x10
	struct TArray<struct UTexture2D*> MobileWeightmapTextures; // Offset: 0x768 | Size: 0x10
	char pad_0x778[0x48]; // Offset: 0x778 | Size: 0x48

	// Functions

	// Object: Function Landscape.LandscapeComponent.GetMaterialInstanceDynamic
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104d51b38
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UMaterialInstanceDynamic* GetMaterialInstanceDynamic(int32_t InIndex);

	// Object: Function Landscape.LandscapeComponent.EditorGetPaintLayerWeightByNameAtLocation
	// Flags: [Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x104d51968
	// Return & Params: [ Num(3) Size(0x18) ]
	float EditorGetPaintLayerWeightByNameAtLocation(struct FVector& InLocation, struct FName InPaintLayerName);

	// Object: Function Landscape.LandscapeComponent.EditorGetPaintLayerWeightAtLocation
	// Flags: [Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x104d51a50
	// Return & Params: [ Num(3) Size(0x1c) ]
	float EditorGetPaintLayerWeightAtLocation(struct FVector& InLocation, struct ULandscapeLayerInfoObject* PaintLayer);
};

// Object: Class Landscape.LandscapeGizmoActor
// Inherited Bytes: 0x230 | Struct Size: 0x230
struct ALandscapeGizmoActor : AActor {
};

// Object: Class Landscape.LandscapeGizmoActiveActor
// Inherited Bytes: 0x230 | Struct Size: 0x280
struct ALandscapeGizmoActiveActor : ALandscapeGizmoActor {
	// Fields
	char pad_0x230[0x50]; // Offset: 0x230 | Size: 0x50
};

// Object: Class Landscape.LandscapeGizmoRenderComponent
// Inherited Bytes: 0x5d0 | Struct Size: 0x5d0
struct ULandscapeGizmoRenderComponent : UPrimitiveComponent {
};

// Object: Class Landscape.LandscapeGrassType
// Inherited Bytes: 0x28 | Struct Size: 0x60
struct ULandscapeGrassType : UObject {
	// Fields
	struct TArray<struct FGrassVariety> GrassVarieties; // Offset: 0x28 | Size: 0x10
	char bEnableDensityScaling : 1; // Offset: 0x38 | Size: 0x1
	char pad_0x38_1 : 7; // Offset: 0x38 | Size: 0x1
	char pad_0x39[0x7]; // Offset: 0x39 | Size: 0x7
	struct UStaticMesh* GrassMesh; // Offset: 0x40 | Size: 0x8
	float GrassDensity; // Offset: 0x48 | Size: 0x4
	float PlacementJitter; // Offset: 0x4c | Size: 0x4
	int32_t StartCullDistance; // Offset: 0x50 | Size: 0x4
	int32_t EndCullDistance; // Offset: 0x54 | Size: 0x4
	bool RandomRotation; // Offset: 0x58 | Size: 0x1
	bool AlignToSurface; // Offset: 0x59 | Size: 0x1
	char pad_0x5A[0x6]; // Offset: 0x5a | Size: 0x6
};

// Object: Class Landscape.LandscapeHeightfieldCollisionComponent
// Inherited Bytes: 0x5d0 | Struct Size: 0x6b0
struct ULandscapeHeightfieldCollisionComponent : UPrimitiveComponent {
	// Fields
	struct TArray<struct ULandscapeLayerInfoObject*> ComponentLayerInfos; // Offset: 0x5c8 | Size: 0x10
	int32_t SectionBaseX; // Offset: 0x5d8 | Size: 0x4
	int32_t SectionBaseY; // Offset: 0x5dc | Size: 0x4
	int32_t CollisionSizeQuads; // Offset: 0x5e0 | Size: 0x4
	float CollisionScale; // Offset: 0x5e4 | Size: 0x4
	int32_t SimpleCollisionSizeQuads; // Offset: 0x5e8 | Size: 0x4
	struct TArray<char> CollisionQuadFlags; // Offset: 0x5f0 | Size: 0x10
	struct FGuid HeightfieldGuid; // Offset: 0x600 | Size: 0x10
	struct FBox CachedLocalBox; // Offset: 0x610 | Size: 0x1c
	LazyObjectProperty RenderComponent; // Offset: 0x62c | Size: 0x1c
	char pad_0x64C[0xc]; // Offset: 0x64c | Size: 0xc
	struct TArray<struct UPhysicalMaterial*> CookedPhysicalMaterials; // Offset: 0x658 | Size: 0x10
	char pad_0x668[0x48]; // Offset: 0x668 | Size: 0x48

	// Functions

	// Object: Function Landscape.LandscapeHeightfieldCollisionComponent.GetRenderComponent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104d52ab0
	// Return & Params: [ Num(1) Size(0x8) ]
	struct ULandscapeComponent* GetRenderComponent();
};

// Object: Class Landscape.LandscapeInfo
// Inherited Bytes: 0x28 | Struct Size: 0x210
struct ULandscapeInfo : UObject {
	// Fields
	LazyObjectProperty LandscapeActor; // Offset: 0x28 | Size: 0x1c
	struct FGuid LandscapeGuid; // Offset: 0x44 | Size: 0x10
	int32_t ComponentSizeQuads; // Offset: 0x54 | Size: 0x4
	int32_t SubsectionSizeQuads; // Offset: 0x58 | Size: 0x4
	int32_t ComponentNumSubsections; // Offset: 0x5c | Size: 0x4
	struct FVector DrawScale; // Offset: 0x60 | Size: 0xc
	char pad_0x6C[0xa4]; // Offset: 0x6c | Size: 0xa4
	struct TArray<struct ALandscapeStreamingProxy*> Proxies; // Offset: 0x110 | Size: 0x10
	char pad_0x120[0xf0]; // Offset: 0x120 | Size: 0xf0
};

// Object: Class Landscape.LandscapeInfoMap
// Inherited Bytes: 0x28 | Struct Size: 0x80
struct ULandscapeInfoMap : UObject {
	// Fields
	char pad_0x28[0x58]; // Offset: 0x28 | Size: 0x58
};

// Object: Class Landscape.LandscapeLayerInfoObject
// Inherited Bytes: 0x28 | Struct Size: 0x50
struct ULandscapeLayerInfoObject : UObject {
	// Fields
	struct FName LayerName; // Offset: 0x28 | Size: 0x8
	struct UPhysicalMaterial* PhysMaterial; // Offset: 0x30 | Size: 0x8
	float Hardness; // Offset: 0x38 | Size: 0x4
	struct FLinearColor LayerUsageDebugColor; // Offset: 0x3c | Size: 0x10
	char pad_0x4C[0x4]; // Offset: 0x4c | Size: 0x4
};

// Object: Class Landscape.LandscapeMaterialInstanceConstant
// Inherited Bytes: 0x428 | Struct Size: 0x440
struct ULandscapeMaterialInstanceConstant : UMaterialInstanceConstant {
	// Fields
	struct TArray<struct FLandscapeMaterialTextureStreamingInfo> TextureStreamingInfo; // Offset: 0x428 | Size: 0x10
	char bIsLayerThumbnail : 1; // Offset: 0x438 | Size: 0x1
	char bDisableTessellation : 1; // Offset: 0x438 | Size: 0x1
	char bMobile : 1; // Offset: 0x438 | Size: 0x1
	char bEditorToolUsage : 1; // Offset: 0x438 | Size: 0x1
	char pad_0x438_4 : 4; // Offset: 0x438 | Size: 0x1
	char pad_0x439[0x7]; // Offset: 0x439 | Size: 0x7
};

// Object: Class Landscape.LandscapeMeshCollisionComponent
// Inherited Bytes: 0x6b0 | Struct Size: 0x6c0
struct ULandscapeMeshCollisionComponent : ULandscapeHeightfieldCollisionComponent {
	// Fields
	struct FGuid MeshGuid; // Offset: 0x6a8 | Size: 0x10
};

// Object: Class Landscape.LandscapeMeshProxyActor
// Inherited Bytes: 0x230 | Struct Size: 0x238
struct ALandscapeMeshProxyActor : AActor {
	// Fields
	struct ULandscapeMeshProxyComponent* LandscapeMeshProxyComponent; // Offset: 0x230 | Size: 0x8
};

// Object: Class Landscape.LandscapeMeshProxyComponent
// Inherited Bytes: 0x830 | Struct Size: 0x850
struct ULandscapeMeshProxyComponent : UStaticMeshComponent {
	// Fields
	struct FGuid LandscapeGuid; // Offset: 0x828 | Size: 0x10
	struct TArray<struct FIntPoint> ProxyComponentBases; // Offset: 0x838 | Size: 0x10
	int8_t ProxyLOD; // Offset: 0x848 | Size: 0x1
};

// Object: Class Landscape.LandscapeSettings
// Inherited Bytes: 0x38 | Struct Size: 0x50
struct ULandscapeSettings : UDeveloperSettings {
	// Fields
	int32_t MaxNumberOfLayers; // Offset: 0x38 | Size: 0x4
	bool bForceFourLayers; // Offset: 0x3c | Size: 0x1
	bool bPrintLayerInfos; // Offset: 0x3d | Size: 0x1
	char pad_0x3E[0x2]; // Offset: 0x3e | Size: 0x2
	struct TArray<struct FLandscapeSplineSegmentSurfaceName> LandscapeSplineSegmentSurfaces; // Offset: 0x40 | Size: 0x10
};

// Object: Class Landscape.LandscapeSplinesComponent
// Inherited Bytes: 0x5d0 | Struct Size: 0x600
struct ULandscapeSplinesComponent : UPrimitiveComponent {
	// Fields
	struct TArray<struct ULandscapeSplineControlPoint*> ControlPoints; // Offset: 0x5c8 | Size: 0x10
	struct TArray<struct ULandscapeSplineSegment*> Segments; // Offset: 0x5d8 | Size: 0x10
	struct TArray<struct UMeshComponent*> CookedForeignMeshComponents; // Offset: 0x5e8 | Size: 0x10

	// Functions

	// Object: Function Landscape.LandscapeSplinesComponent.GetSplineMeshComponents
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104d5af9c
	// Return & Params: [ Num(1) Size(0x10) ]
	struct TArray<struct USplineMeshComponent*> GetSplineMeshComponents();
};

// Object: Class Landscape.LandscapeSplineControlPoint
// Inherited Bytes: 0x28 | Struct Size: 0xa8
struct ULandscapeSplineControlPoint : UObject {
	// Fields
	struct FVector Location; // Offset: 0x28 | Size: 0xc
	struct FRotator Rotation; // Offset: 0x34 | Size: 0xc
	float Width; // Offset: 0x40 | Size: 0x4
	float LayerWidthRatio; // Offset: 0x44 | Size: 0x4
	float SideFalloff; // Offset: 0x48 | Size: 0x4
	float LeftSideFalloffFactor; // Offset: 0x4c | Size: 0x4
	float RightSideFalloffFactor; // Offset: 0x50 | Size: 0x4
	float LeftSideLayerFalloffFactor; // Offset: 0x54 | Size: 0x4
	float RightSideLayerFalloffFactor; // Offset: 0x58 | Size: 0x4
	float EndFalloff; // Offset: 0x5c | Size: 0x4
	struct TArray<struct FLandscapeSplineConnection> ConnectedSegments; // Offset: 0x60 | Size: 0x10
	struct TArray<struct FLandscapeSplineInterpPoint> Points; // Offset: 0x70 | Size: 0x10
	struct FBox Bounds; // Offset: 0x80 | Size: 0x1c
	char pad_0x9C[0x4]; // Offset: 0x9c | Size: 0x4
	struct UControlPointMeshComponent* LocalMeshComponent; // Offset: 0xa0 | Size: 0x8
};

// Object: Class Landscape.LandscapeSplineSegment
// Inherited Bytes: 0x28 | Struct Size: 0xb8
struct ULandscapeSplineSegment : UObject {
	// Fields
	struct FLandscapeSplineSegmentConnection Connections[0x2]; // Offset: 0x28 | Size: 0x30
	enum class ELandscapeSplineSegmentSurface SurfaceType; // Offset: 0x58 | Size: 0x1
	char bBranchTrunk : 1; // Offset: 0x59 | Size: 0x1
	char pad_0x59_1 : 7; // Offset: 0x59 | Size: 0x1
	char pad_0x5A[0x6]; // Offset: 0x5a | Size: 0x6
	struct FInterpCurveVector SplineInfo; // Offset: 0x60 | Size: 0x18
	struct TArray<struct FLandscapeSplineInterpPoint> Points; // Offset: 0x78 | Size: 0x10
	struct FBox Bounds; // Offset: 0x88 | Size: 0x1c
	char pad_0xA4[0x4]; // Offset: 0xa4 | Size: 0x4
	struct TArray<struct USplineMeshComponent*> LocalMeshComponents; // Offset: 0xa8 | Size: 0x10
};

// Object: Class Landscape.LandscapeStreamingProxy
// Inherited Bytes: 0x568 | Struct Size: 0x588
struct ALandscapeStreamingProxy : ALandscapeProxy {
	// Fields
	LazyObjectProperty LandscapeActor; // Offset: 0x568 | Size: 0x1c
	char pad_0x584[0x4]; // Offset: 0x584 | Size: 0x4
};

// Object: Class Landscape.LandscapeSubsystem
// Inherited Bytes: 0x30 | Struct Size: 0x98
struct ULandscapeSubsystem : UWorldSubsystem {
	// Fields
	char pad_0x30[0x68]; // Offset: 0x30 | Size: 0x68
};

// Object: Class Landscape.LandscapeWeightmapUsage
// Inherited Bytes: 0x28 | Struct Size: 0x58
struct ULandscapeWeightmapUsage : UObject {
	// Fields
	struct ULandscapeComponent* ChannelUsage[0x4]; // Offset: 0x28 | Size: 0x20
	struct FGuid LayerGuid; // Offset: 0x48 | Size: 0x10
};

// Object: Class Landscape.MaterialExpressionLandscapeGrassOutput
// Inherited Bytes: 0x40 | Struct Size: 0x50
struct UMaterialExpressionLandscapeGrassOutput : UMaterialExpressionCustomOutput {
	// Fields
	struct TArray<struct FGrassInput> GrassTypes; // Offset: 0x40 | Size: 0x10
};

// Object: Class Landscape.MaterialExpressionLandscapeLayerBlend
// Inherited Bytes: 0x40 | Struct Size: 0x60
struct UMaterialExpressionLandscapeLayerBlend : UMaterialExpression {
	// Fields
	struct TArray<struct FLayerBlendInput> Layers; // Offset: 0x40 | Size: 0x10
	struct FGuid ExpressionGUID; // Offset: 0x50 | Size: 0x10
};

// Object: Class Landscape.MaterialExpressionLandscapeLayerCoords
// Inherited Bytes: 0x40 | Struct Size: 0x50
struct UMaterialExpressionLandscapeLayerCoords : UMaterialExpression {
	// Fields
	enum class ETerrainCoordMappingType MappingType; // Offset: 0x39 | Size: 0x1
	enum class ELandscapeCustomizedCoordType CustomUVType; // Offset: 0x3a | Size: 0x1
	float MappingScale; // Offset: 0x3c | Size: 0x4
	float MappingRotation; // Offset: 0x40 | Size: 0x4
	float MappingPanU; // Offset: 0x44 | Size: 0x4
	float MappingPanV; // Offset: 0x48 | Size: 0x4
};

// Object: Class Landscape.MaterialExpressionLandscapeLayerSample
// Inherited Bytes: 0x40 | Struct Size: 0x58
struct UMaterialExpressionLandscapeLayerSample : UMaterialExpression {
	// Fields
	struct FName ParameterName; // Offset: 0x3c | Size: 0x8
	float PreviewWeight; // Offset: 0x44 | Size: 0x4
	struct FGuid ExpressionGUID; // Offset: 0x48 | Size: 0x10
};

// Object: Class Landscape.MaterialExpressionLandscapeLayerSwitch
// Inherited Bytes: 0x40 | Struct Size: 0x80
struct UMaterialExpressionLandscapeLayerSwitch : UMaterialExpression {
	// Fields
	struct FExpressionInput LayerUsed; // Offset: 0x3c | Size: 0xc
	char pad_0x4C[0x4]; // Offset: 0x4c | Size: 0x4
	struct FExpressionInput LayerNotUsed; // Offset: 0x50 | Size: 0xc
	char pad_0x5C[0x8]; // Offset: 0x5c | Size: 0x8
	struct FName ParameterName; // Offset: 0x64 | Size: 0x8
	char PreviewUsed : 1; // Offset: 0x6c | Size: 0x1
	char pad_0x6C_1 : 7; // Offset: 0x6c | Size: 0x1
	char pad_0x6D[0x3]; // Offset: 0x6d | Size: 0x3
	struct FGuid ExpressionGUID; // Offset: 0x70 | Size: 0x10
};

// Object: Class Landscape.MaterialExpressionLandscapeLayerWeight
// Inherited Bytes: 0x40 | Struct Size: 0x90
struct UMaterialExpressionLandscapeLayerWeight : UMaterialExpression {
	// Fields
	struct FExpressionInput Base; // Offset: 0x3c | Size: 0xc
	char pad_0x4C[0x4]; // Offset: 0x4c | Size: 0x4
	struct FExpressionInput Layer; // Offset: 0x50 | Size: 0xc
	char pad_0x5C[0x8]; // Offset: 0x5c | Size: 0x8
	struct FName ParameterName; // Offset: 0x64 | Size: 0x8
	float PreviewWeight; // Offset: 0x6c | Size: 0x4
	struct FVector ConstBase; // Offset: 0x70 | Size: 0xc
	struct FGuid ExpressionGUID; // Offset: 0x7c | Size: 0x10
	char pad_0x8C[0x4]; // Offset: 0x8c | Size: 0x4
};

// Object: Class Landscape.MaterialExpressionLandscapeVisibilityMask
// Inherited Bytes: 0x40 | Struct Size: 0x50
struct UMaterialExpressionLandscapeVisibilityMask : UMaterialExpression {
	// Fields
	struct FGuid ExpressionGUID; // Offset: 0x3c | Size: 0x10
};

