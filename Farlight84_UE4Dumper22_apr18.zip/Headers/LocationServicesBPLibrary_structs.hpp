#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct LocationServicesBPLibrary.LocationServicesData
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FLocationServicesData {
	// Fields
	float Timestamp; // Offset: 0x0 | Size: 0x4
	float Longitude; // Offset: 0x4 | Size: 0x4
	float Latitude; // Offset: 0x8 | Size: 0x4
	float HorizontalAccuracy; // Offset: 0xc | Size: 0x4
	float VerticalAccuracy; // Offset: 0x10 | Size: 0x4
	float Altitude; // Offset: 0x14 | Size: 0x4
};

