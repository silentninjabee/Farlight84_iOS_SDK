#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct MediaAssets.MediaCaptureDevice
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FMediaCaptureDevice {
	// Fields
	struct FText DisplayName; // Offset: 0x0 | Size: 0x18
	struct FString URL; // Offset: 0x18 | Size: 0x10
};

// Object: ScriptStruct MediaAssets.MediaSoundComponentSpectralData
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FMediaSoundComponentSpectralData {
	// Fields
	float FrequencyHz; // Offset: 0x0 | Size: 0x4
	float Magnitude; // Offset: 0x4 | Size: 0x4
};

