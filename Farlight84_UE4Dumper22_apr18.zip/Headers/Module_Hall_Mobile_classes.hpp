#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass Module_Hall_Mobile.Module_Hall_Mobile_C
// Inherited Bytes: 0x238 | Struct Size: 0x238
struct AModule_Hall_Mobile_C : ALevelScriptActor {
};

