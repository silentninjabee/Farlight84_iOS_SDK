#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: DynamicClass R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_C
// Inherited Bytes: 0x300 | Struct Size: 0xa40
struct UR_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_C : UWeaponAnimInstance {
	// Fields
	struct FAnimNode_Root AnimGraphNode_Root; // Offset: 0x300 | Size: 0x30
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_19; // Offset: 0x330 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_18; // Offset: 0x358 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_17; // Offset: 0x380 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_16; // Offset: 0x3a8 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_15; // Offset: 0x3d0 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_14; // Offset: 0x3f8 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_13; // Offset: 0x420 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_12; // Offset: 0x448 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_11; // Offset: 0x470 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_10; // Offset: 0x498 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_9; // Offset: 0x4c0 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_8; // Offset: 0x4e8 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_7; // Offset: 0x510 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_6; // Offset: 0x538 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_5; // Offset: 0x560 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_4; // Offset: 0x588 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_3; // Offset: 0x5b0 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_2; // Offset: 0x5d8 | Size: 0x28
	struct FAnimNode_StateResult AnimGraphNode_StateResult_9; // Offset: 0x600 | Size: 0x30
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_3; // Offset: 0x630 | Size: 0x88
	struct FAnimNode_StateResult AnimGraphNode_StateResult_8; // Offset: 0x6b8 | Size: 0x30
	struct FAnimNode_StateResult AnimGraphNode_StateResult_7; // Offset: 0x6e8 | Size: 0x30
	struct FAnimNode_StateResult AnimGraphNode_StateResult_6; // Offset: 0x718 | Size: 0x30
	struct FAnimNode_StateResult AnimGraphNode_StateResult_5; // Offset: 0x748 | Size: 0x30
	struct FAnimNode_StateResult AnimGraphNode_StateResult_4; // Offset: 0x778 | Size: 0x30
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2; // Offset: 0x7a8 | Size: 0x88
	struct FAnimNode_StateResult AnimGraphNode_StateResult_3; // Offset: 0x830 | Size: 0x30
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer; // Offset: 0x860 | Size: 0x88
	struct FAnimNode_StateResult AnimGraphNode_StateResult_2; // Offset: 0x8e8 | Size: 0x30
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult; // Offset: 0x918 | Size: 0x28
	struct FAnimNode_StateResult AnimGraphNode_StateResult; // Offset: 0x940 | Size: 0x30
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine; // Offset: 0x970 | Size: 0xb0
	struct FAnimMsgData K2Node_MakeStruct_AnimMsgData; // Offset: 0xa20 | Size: 0x8
	struct TArray<struct FAnimMsgData> K2Node_MakeArray_Array; // Offset: 0xa28 | Size: 0x10
	char pad_0xA38[0x8]; // Offset: 0xa38 | Size: 0x8

	// Functions

	// Object: Function R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_C.TestAPI
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x101f9c0c4
	// Return & Params: [ Num(0) Size(0x0) ]
	void TestAPI();

	// Object: Function R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_C.InterruptAnim
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x101f9c16c
	// Return & Params: [ Num(0) Size(0x0) ]
	void InterruptAnim();

	// Object: Function R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_F1D9DDBB413911FB9DAB608900412973
	// Flags: [Native|Public]
	// Offset: 0x101f9be78
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_F1D9DDBB413911FB9DAB608900412973();

	// Object: Function R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_ED21629F443C13EB618022956A31D19A
	// Flags: [Native|Public]
	// Offset: 0x101f9bf04
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_ED21629F443C13EB618022956A31D19A();

	// Object: Function R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_DF0EDC2A4C9FD52DDBFB5AB16F296F1F
	// Flags: [Native|Public]
	// Offset: 0x101f9bfac
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_DF0EDC2A4C9FD52DDBFB5AB16F296F1F();

	// Object: Function R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_C56C131748626A9573F10282DB5E5052
	// Flags: [Native|Public]
	// Offset: 0x101f9c08c
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_C56C131748626A9573F10282DB5E5052();

	// Object: Function R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_C03C50F94DB6AE0D2D3E5C9ED0973F8F
	// Flags: [Native|Public]
	// Offset: 0x101f9c000
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_C03C50F94DB6AE0D2D3E5C9ED0973F8F();

	// Object: Function R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_AAD002E1429649E2A71240AC589B09B4
	// Flags: [Native|Public]
	// Offset: 0x101f9bf74
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_AAD002E1429649E2A71240AC589B09B4();

	// Object: Function R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_AA031CB74743982BEE3C5797368DAA52
	// Flags: [Native|Public]
	// Offset: 0x101f9beb0
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_AA031CB74743982BEE3C5797368DAA52();

	// Object: Function R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_A5160CCA42B37A4C3B4188B28169B213
	// Flags: [Native|Public]
	// Offset: 0x101f9bee8
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_A5160CCA42B37A4C3B4188B28169B213();

	// Object: Function R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_A2FAECDE4FDF2B0F0058E592F914226B
	// Flags: [Native|Public]
	// Offset: 0x101f9bf58
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_A2FAECDE4FDF2B0F0058E592F914226B();

	// Object: Function R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_94B2047B4C3C85D5F4207DBB55087639
	// Flags: [Native|Public]
	// Offset: 0x101f9bf20
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_94B2047B4C3C85D5F4207DBB55087639();

	// Object: Function R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_75627B5046C82AA9436B29B4F5249E44
	// Flags: [Native|Public]
	// Offset: 0x101f9becc
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_75627B5046C82AA9436B29B4F5249E44();

	// Object: Function R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_57810D744E7C3FBDD015CAA7F41F4FC9
	// Flags: [Native|Public]
	// Offset: 0x101f9bf3c
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_57810D744E7C3FBDD015CAA7F41F4FC9();

	// Object: Function R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_3B7C19954B39C84A940DAAA2F33497FF
	// Flags: [Native|Public]
	// Offset: 0x101f9c0a8
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_3B7C19954B39C84A940DAAA2F33497FF();

	// Object: Function R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_3894EEFF4AF65DB06E1EF6B3E50D61C8
	// Flags: [Native|Public]
	// Offset: 0x101f9be94
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_3894EEFF4AF65DB06E1EF6B3E50D61C8();

	// Object: Function R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_22B64B724989FED60A22A891E13B0124
	// Flags: [Native|Public]
	// Offset: 0x101f9c038
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_22B64B724989FED60A22A891E13B0124();

	// Object: Function R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_157669F74CFD34995FC79C884849B3AC
	// Flags: [Native|Public]
	// Offset: 0x101f9bfc8
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_157669F74CFD34995FC79C884849B3AC();

	// Object: Function R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_12DD48B84B001C059F7A2AB37F97FCFB
	// Flags: [Native|Public]
	// Offset: 0x101f9bfe4
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_12DD48B84B001C059F7A2AB37F97FCFB();

	// Object: Function R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_0C1E6158487EAC02C7B875B4515A137E
	// Flags: [Native|Public]
	// Offset: 0x101f9bf90
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_0C1E6158487EAC02C7B875B4515A137E();

	// Object: Function R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_096C1B414C4EC717A873538B7A500073
	// Flags: [Native|Public]
	// Offset: 0x101f9c0fc
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_096C1B414C4EC717A873538B7A500073();

	// Object: Function R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_SequencePlayer_B88F52044BA7D36ADD40709403A148A7
	// Flags: [Native|Public]
	// Offset: 0x101f9c054
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_SequencePlayer_B88F52044BA7D36ADD40709403A148A7();

	// Object: Function R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_SequencePlayer_9521C87845A62B5E05A2FC98EEAE4394
	// Flags: [Native|Public]
	// Offset: 0x101f9c01c
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_SequencePlayer_9521C87845A62B5E05A2FC98EEAE4394();

	// Object: Function R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_SequencePlayer_6E0892AF47D14DE4DBFCD6A9DD05BF1F
	// Flags: [Native|Public]
	// Offset: 0x101f9c070
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_SequencePlayer_6E0892AF47D14DE4DBFCD6A9DD05BF1F();

	// Object: Function R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_C.AnimNotify_QuitIdle
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x101f9c150
	// Return & Params: [ Num(0) Size(0x0) ]
	void AnimNotify_QuitIdle();

	// Object: Function R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_C.AnimNotify_QuitFire
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x101f9c118
	// Return & Params: [ Num(0) Size(0x0) ]
	void AnimNotify_QuitFire();

	// Object: Function R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_C.AnimNotify_EnterIdle
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x101f9c134
	// Return & Params: [ Num(0) Size(0x0) ]
	void AnimNotify_EnterIdle();

	// Object: Function R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_C.AnimNotify_EnterFire
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x101f9c0e0
	// Return & Params: [ Num(0) Size(0x0) ]
	void AnimNotify_EnterFire();

	// Object: Function R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_9A06_Set00_LODP_Skeleton_AnimBlueprint_C.AnimGraph
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101f9bdd8
	// Return & Params: [ Num(1) Size(0x10) ]
	void AnimGraph(struct FPoseLink& bpp__AnimGraph__pf);
};

