#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass SCS_IronMan_Brake_Impact.SCS_IronMan_Brake_Impact_C
// Inherited Bytes: 0x190 | Struct Size: 0x190
struct USCS_IronMan_Brake_Impact_C : USolarCameraShake {
};

