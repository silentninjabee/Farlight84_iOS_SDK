#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class SGSRSpatialUpscaling.SGSR_Settings
// Inherited Bytes: 0x28 | Struct Size: 0x30
struct USGSR_Settings : UObject {
	// Fields
	char bHalfPrecision : 1; // Offset: 0x28 | Size: 0x1
	char pad_0x28_1 : 7; // Offset: 0x28 | Size: 0x1
	enum class ESGSRTarget Target; // Offset: 0x29 | Size: 0x1
	char pad_0x2A[0x6]; // Offset: 0x2a | Size: 0x6
};

