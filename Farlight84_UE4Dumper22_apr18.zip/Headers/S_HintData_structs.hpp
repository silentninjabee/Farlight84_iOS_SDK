#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: UserDefinedStruct S_HintData.S_HintData
// Inherited Bytes: 0x0 | Struct Size: 0xd
struct FS_HintData {
	// Fields
	int64_t Key_14_D775E56C482FB0DD62C084A4047E30ED; // Offset: 0x0 | Size: 0x8
	enum class ERedHintPath Path_7_6229F76641F2B5DD8915A592798C0451; // Offset: 0x8 | Size: 0x1
	bool bAutoRefresh_9_E2E903644E809943087FCDAB89AF4410; // Offset: 0x9 | Size: 0x1
	enum class E_Type_RedHint Style_13_2AE8F5AD43CAA7BCF6308795DC0100A4; // Offset: 0xa | Size: 0x1
	bool UseNewHintPath_16_A4D6B349462D89C92AAB53BE7861BD98; // Offset: 0xb | Size: 0x1
	enum class E_RedHintPath_New HintPathNew_19_C2D90A2D48E1A602D0F679A3C784D6A8; // Offset: 0xc | Size: 0x1
};

