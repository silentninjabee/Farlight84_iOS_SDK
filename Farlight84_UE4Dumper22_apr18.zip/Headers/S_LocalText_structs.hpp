#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: UserDefinedStruct S_LocalText.S_LocalText
// Inherited Bytes: 0x0 | Struct Size: 0x19
struct FS_LocalText {
	// Fields
	struct FString Text_10_0BCC6D364B34819FB16DFD8CA26152FC; // Offset: 0x0 | Size: 0x10
	bool EnableLocText_6_11B3C81542F91C4FB7E526A5ED375AAD; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x3]; // Offset: 0x11 | Size: 0x3
	int32_t LocTextKey_7_5BB8F41B4BC9C16BFBD028AA88C6AB18; // Offset: 0x14 | Size: 0x4
	bool Upper_12_BD35C702426221CA30C0998E11654165; // Offset: 0x18 | Size: 0x1
};

