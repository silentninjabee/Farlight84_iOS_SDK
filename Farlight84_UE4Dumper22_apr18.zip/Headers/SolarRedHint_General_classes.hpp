#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass SolarRedHint_General.SolarRedHint_General_C
// Inherited Bytes: 0x490 | Struct Size: 0x4b5
struct USolarRedHint_General_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x490 | Size: 0x8
	struct UImage* Img_HintPoint; // Offset: 0x498 | Size: 0x8
	struct UTextBlock* Text_HintNum; // Offset: 0x4a0 | Size: 0x8
	int64_t HintKey; // Offset: 0x4a8 | Size: 0x8
	enum class ERedHintPath HintPath; // Offset: 0x4b0 | Size: 0x1
	bool IsAutoRefresh; // Offset: 0x4b1 | Size: 0x1
	enum class E_Type_RedHint Type; // Offset: 0x4b2 | Size: 0x1
	bool UseNewHintPath; // Offset: 0x4b3 | Size: 0x1
	enum class E_RedHintPath_New HintPathNew; // Offset: 0x4b4 | Size: 0x1

	// Functions

	// Object: Function SolarRedHint_General.SolarRedHint_General_C.OnSetHintDataCompleteCopy
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnSetHintDataCompleteCopy();

	// Object: Function SolarRedHint_General.SolarRedHint_General_C.Destruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x101785338
	// Return & Params: [ Num(0) Size(0x0) ]
	void Destruct();

	// Object: Function SolarRedHint_General.SolarRedHint_General_C.OnInitialized
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x101785338
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnInitialized();

	// Object: Function SolarRedHint_General.SolarRedHint_General_C.ConstructCopy
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(0) Size(0x0) ]
	void ConstructCopy();

	// Object: Function SolarRedHint_General.SolarRedHint_General_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();

	// Object: Function SolarRedHint_General.SolarRedHint_General_C.OnSetHintDataComplete
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101785338
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnSetHintDataComplete();

	// Object: Function SolarRedHint_General.SolarRedHint_General_C.SetStyle
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetStyle(enum class E_Type_RedHint Type);

	// Object: Function SolarRedHint_General.SolarRedHint_General_C.SetHintData
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(6) Size(0xd) ]
	void SetHintData(int64_t Key, enum class ERedHintPath Path, bool bAutoRefresh, enum class E_Type_RedHint Type, bool bNewHintPath, enum class E_RedHintPath_New NewPath);

	// Object: Function SolarRedHint_General.SolarRedHint_General_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function SolarRedHint_General.SolarRedHint_General_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x101785338
	// Return & Params: [ Num(0) Size(0x0) ]
	void Construct();

	// Object: Function SolarRedHint_General.SolarRedHint_General_C.ExecuteUbergraph_SolarRedHint_General
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_SolarRedHint_General(int32_t EntryPoint);
};

