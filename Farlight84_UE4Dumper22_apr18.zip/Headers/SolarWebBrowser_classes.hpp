#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class SolarWebBrowser.WebBrowser
// Inherited Bytes: 0x138 | Struct Size: 0x1b8
struct UWebBrowser : UWidget {
	// Fields
	struct FMulticastInlineDelegate OnUrlChanged; // Offset: 0x138 | Size: 0x10
	struct FMulticastInlineDelegate OnBeforePopup; // Offset: 0x148 | Size: 0x10
	struct FMulticastInlineDelegate OnBeforeNavigation; // Offset: 0x158 | Size: 0x10
	struct TArray<struct FString> URLKeywordWithoutNavigation; // Offset: 0x168 | Size: 0x10
	struct FString InitialURL; // Offset: 0x178 | Size: 0x10
	bool bSupportsTransparency; // Offset: 0x188 | Size: 0x1
	char pad_0x189[0x3]; // Offset: 0x189 | Size: 0x3
	int32_t FrameRate; // Offset: 0x18c | Size: 0x4
	bool bEnableMouseTransparency; // Offset: 0x190 | Size: 0x1
	char pad_0x191[0x3]; // Offset: 0x191 | Size: 0x3
	float MouseTransparencyThreshold; // Offset: 0x194 | Size: 0x4
	float MouseTransparencyDelay; // Offset: 0x198 | Size: 0x4
	bool bEnableVirtualPointerTransparency; // Offset: 0x19c | Size: 0x1
	char pad_0x19D[0x3]; // Offset: 0x19d | Size: 0x3
	float VirtualPointerTransparencyThreshold; // Offset: 0x1a0 | Size: 0x4
	bool bCustomCursors; // Offset: 0x1a4 | Size: 0x1
	char pad_0x1A5[0x13]; // Offset: 0x1a5 | Size: 0x13

	// Functions

	// Object: Function SolarWebBrowser.WebBrowser.Unfocus
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1019139c8
	// Return & Params: [ Num(1) Size(0x1) ]
	void Unfocus(enum class EMouseCaptureMode MouseCaptureMode);

	// Object: Function SolarWebBrowser.WebBrowser.Unbind
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101913bf8
	// Return & Params: [ Num(2) Size(0x18) ]
	void Unbind(struct FString Name, struct UObject* Object);

	// Object: Function SolarWebBrowser.WebBrowser.StopLoad
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101913b94
	// Return & Params: [ Num(0) Size(0x0) ]
	void StopLoad();

	// Object: Function SolarWebBrowser.WebBrowser.SetURLWithoutNavigation
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101913ac8
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetURLWithoutNavigation(struct TArray<struct FString>& URLs);

	// Object: Function SolarWebBrowser.WebBrowser.ResetMousePosition
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1019139b4
	// Return & Params: [ Num(0) Size(0x0) ]
	void ResetMousePosition();

	// Object: Function SolarWebBrowser.WebBrowser.Reload
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101913ba8
	// Return & Params: [ Num(0) Size(0x0) ]
	void Reload();

	// Object: Function SolarWebBrowser.WebBrowser.ReadTexturePixels
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1019136c0
	// Return & Params: [ Num(5) Size(0x20) ]
	struct TArray<struct FColor> ReadTexturePixels(int32_t X, int32_t Y, int32_t Width, int32_t Height);

	// Object: Function SolarWebBrowser.WebBrowser.ReadTexturePixel
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x101913874
	// Return & Params: [ Num(3) Size(0xc) ]
	struct FColor ReadTexturePixel(int32_t X, int32_t Y);

	// Object: DelegateFunction SolarWebBrowser.WebBrowser.OnUrlChanged__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x18) ]
	void OnUrlChanged__DelegateSignature(struct FText& Text);

	// Object: DelegateFunction SolarWebBrowser.WebBrowser.OnBeforePopup__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x104039718
	// Return & Params: [ Num(2) Size(0x20) ]
	void OnBeforePopup__DelegateSignature(struct FString URL, struct FString Frame);

	// Object: DelegateFunction SolarWebBrowser.WebBrowser.OnBeforeNavigation__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x10) ]
	void OnBeforeNavigation__DelegateSignature(struct FString URL);

	// Object: Function SolarWebBrowser.WebBrowser.LoadURL
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1019141ec
	// Return & Params: [ Num(1) Size(0x10) ]
	void LoadURL(struct FString NewURL);

	// Object: Function SolarWebBrowser.WebBrowser.LoadString
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101914048
	// Return & Params: [ Num(2) Size(0x20) ]
	void LoadString(struct FString Contents, struct FString DummyURL);

	// Object: Function SolarWebBrowser.WebBrowser.IsVirtualPointerTransparencyEnabled
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x101913658
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsVirtualPointerTransparencyEnabled();

	// Object: Function SolarWebBrowser.WebBrowser.IsMouseTransparencyEnabled
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10191368c
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsMouseTransparencyEnabled();

	// Object: Function SolarWebBrowser.WebBrowser.GetUrl
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x101913da8
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetUrl();

	// Object: Function SolarWebBrowser.WebBrowser.GetTitleText
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x101913e28
	// Return & Params: [ Num(1) Size(0x18) ]
	struct FText GetTitleText();

	// Object: Function SolarWebBrowser.WebBrowser.GetTextureWidth
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x101913980
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetTextureWidth();

	// Object: Function SolarWebBrowser.WebBrowser.GetTextureHeight
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10191394c
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetTextureHeight();

	// Object: Function SolarWebBrowser.WebBrowser.Focus
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101913a48
	// Return & Params: [ Num(1) Size(0x1) ]
	void Focus(enum class EMouseLockMode MouseLockMode);

	// Object: Function SolarWebBrowser.WebBrowser.ExecuteJavascript
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101913fbc
	// Return & Params: [ Num(1) Size(0x10) ]
	void ExecuteJavascript(struct FString ScriptText);

	// Object: Function SolarWebBrowser.WebBrowser.EnableIME
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101913be4
	// Return & Params: [ Num(0) Size(0x0) ]
	void EnableIME();

	// Object: Function SolarWebBrowser.WebBrowser.DisableIME
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101913bd0
	// Return & Params: [ Num(0) Size(0x0) ]
	void DisableIME();

	// Object: Function SolarWebBrowser.WebBrowser.CloseSelf
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101913bbc
	// Return & Params: [ Num(0) Size(0x0) ]
	void CloseSelf();

	// Object: Function SolarWebBrowser.WebBrowser.CallJavascriptFunction
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101913ed8
	// Return & Params: [ Num(2) Size(0x20) ]
	void CallJavascriptFunction(struct FString Function, struct FString Data);

	// Object: Function SolarWebBrowser.WebBrowser.Bind
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101913cd0
	// Return & Params: [ Num(2) Size(0x18) ]
	void Bind(struct FString Name, struct UObject* Object);
};

