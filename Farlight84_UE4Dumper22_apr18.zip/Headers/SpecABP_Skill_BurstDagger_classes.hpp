#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: DynamicClass SpecABP_Skill_BurstDagger.SpecABP_Skill_BurstDagger_C
// Inherited Bytes: 0x5350 | Struct Size: 0x5350
struct USpecABP_Skill_BurstDagger_C : USpecABP_Skill_OneHandThrow_C {
};

