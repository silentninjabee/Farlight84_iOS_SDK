#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: DynamicClass SpecABP_Skill_KeepFiring.SpecABP_Skill_KeepFiring_C
// Inherited Bytes: 0x310 | Struct Size: 0x6d0
struct USpecABP_Skill_KeepFiring_C : USolarSpecABP_Skill {
	// Fields
	char pad_0x310[0x8]; // Offset: 0x310 | Size: 0x8
	struct FAnimNode_Root AnimGraphNode_Root_2; // Offset: 0x318 | Size: 0x30
	struct FAnimNode_LinkedInputPose AnimGraphNode_LinkedInputPose; // Offset: 0x348 | Size: 0x78
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer; // Offset: 0x3c0 | Size: 0x88
	struct FAnimNode_RotationOffsetBlendSpace AnimGraphNode_RotationOffsetBlendSpace; // Offset: 0x448 | Size: 0x198
	struct FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend; // Offset: 0x5e0 | Size: 0xc0
	struct FAnimNode_Root AnimGraphNode_Root; // Offset: 0x6a0 | Size: 0x30

	// Functions

	// Object: Function SpecABP_Skill_KeepFiring.SpecABP_Skill_KeepFiring_C.SkillAnimationLayer
	// Flags: [Native|Event|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101fb8c2c
	// Return & Params: [ Num(2) Size(0x20) ]
	void SkillAnimationLayer(struct FPoseLink bpp__BasePose__pf, struct FPoseLink& bpp__SkillAnimationLayer__pf);

	// Object: Function SpecABP_Skill_KeepFiring.SpecABP_Skill_KeepFiring_C.EvaluateGraphExposedInputs_ExecuteUbergraph_SpecABP_Skill_KeepFiring_AnimGraphNode_RotationOffsetBlendSpace_519BC4914BD91B5DA5A3F58792D43A5B
	// Flags: [Native|Public]
	// Offset: 0x101fb8db8
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_SpecABP_Skill_KeepFiring_AnimGraphNode_RotationOffsetBlendSpace_519BC4914BD91B5DA5A3F58792D43A5B();

	// Object: Function SpecABP_Skill_KeepFiring.SpecABP_Skill_KeepFiring_C.AnimGraph
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101fb8d18
	// Return & Params: [ Num(1) Size(0x10) ]
	void AnimGraph(struct FPoseLink& bpp__AnimGraph__pf);
};

