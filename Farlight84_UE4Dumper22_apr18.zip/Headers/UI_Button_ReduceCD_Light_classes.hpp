#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Button_ReduceCD_Light.UI_Button_ReduceCD_Light_C
// Inherited Bytes: 0x260 | Struct Size: 0x294
struct UUI_Button_ReduceCD_Light_C : UUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x260 | Size: 0x8
	struct UImage* MI_RingGlow; // Offset: 0x268 | Size: 0x8
	struct UImage* MI_RingGlow_2; // Offset: 0x270 | Size: 0x8
	struct USizeBox* SizeBox_1; // Offset: 0x278 | Size: 0x8
	float Size; // Offset: 0x280 | Size: 0x4
	struct FLinearColor Color; // Offset: 0x284 | Size: 0x10

	// Functions

	// Object: Function UI_Button_ReduceCD_Light.UI_Button_ReduceCD_Light_C.RefreshColor
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(0) Size(0x0) ]
	void RefreshColor();

	// Object: Function UI_Button_ReduceCD_Light.UI_Button_ReduceCD_Light_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_Button_ReduceCD_Light.UI_Button_ReduceCD_Light_C.ExecuteUbergraph_UI_Button_ReduceCD_Light
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_Button_ReduceCD_Light(int32_t EntryPoint);
};

