#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_ChatPanel.UI_ChatPanel_C
// Inherited Bytes: 0x490 | Struct Size: 0x4e1
struct UUI_ChatPanel_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x490 | Size: 0x8
	struct UButton* Btn_Interaction; // Offset: 0x498 | Size: 0x8
	struct UWidgetSwitcher* Chat_Switcher; // Offset: 0x4a0 | Size: 0x8
	struct UImage* Img_Message; // Offset: 0x4a8 | Size: 0x8
	struct UImage* Img_message_bg03; // Offset: 0x4b0 | Size: 0x8
	struct URichTextBlock* Message; // Offset: 0x4b8 | Size: 0x8
	struct UTextBlock* UnreadMessageCount; // Offset: 0x4c0 | Size: 0x8
	struct UOverlay* UnreadMessageNotifyPanel; // Offset: 0x4c8 | Size: 0x8
	struct UWidgetSwitcher* WidgetSwitcher_ChatType; // Offset: 0x4d0 | Size: 0x8
	struct UWidgetSwitcher* WidgetSwitcher_RedHint; // Offset: 0x4d8 | Size: 0x8
	enum class E_Type_State_Button StateDesktop; // Offset: 0x4e0 | Size: 0x1

	// Functions

	// Object: DelegateFunction UI_ChatPanel.UI_ChatPanel_C.OnClicked_1F8445B7D34BF185EE4BF28C2343FAB4
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10176f770
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_1F8445B7D34BF185EE4BF28C2343FAB4();

	// Object: Function UI_ChatPanel.UI_ChatPanel_C.Destruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x101785338
	// Return & Params: [ Num(0) Size(0x0) ]
	void Destruct();

	// Object: Function UI_ChatPanel.UI_ChatPanel_C.OnSolarUIClosed
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x101785338
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnSolarUIClosed();

	// Object: Function UI_ChatPanel.UI_ChatPanel_C.OnSolarUIOpened
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x101785338
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnSolarUIOpened();

	// Object: Function UI_ChatPanel.UI_ChatPanel_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x101785338
	// Return & Params: [ Num(0) Size(0x0) ]
	void Construct();

	// Object: Function UI_ChatPanel.UI_ChatPanel_C.OnInitialized
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x101785338
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnInitialized();

	// Object: Function UI_ChatPanel.UI_ChatPanel_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();

	// Object: Function UI_ChatPanel.UI_ChatPanel_C.SetStateDesktop
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetStateDesktop(enum class E_Type_State_Button StateHD);

	// Object: Function UI_ChatPanel.UI_ChatPanel_C.SetMsgText
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(4) Size(0x38) ]
	void SetMsgText(char ChatType, struct FString playerName, struct FString Msg, struct FString& OutputText);

	// Object: Function UI_ChatPanel.UI_ChatPanel_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_ChatPanel.UI_ChatPanel_C.ExecuteUbergraph_UI_ChatPanel
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_ChatPanel(int32_t EntryPoint);
};

