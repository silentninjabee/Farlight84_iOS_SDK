#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Chat_Wave.UI_Chat_Wave_C
// Inherited Bytes: 0x490 | Struct Size: 0x498
struct UUI_Chat_Wave_C : USolarUserWidget {
	// Fields
	struct UWidgetAnimation* Anim_Loop; // Offset: 0x490 | Size: 0x8
};

