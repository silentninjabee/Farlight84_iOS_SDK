#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Component_Btn.UI_Component_Btn_C
// Inherited Bytes: 0x498 | Struct Size: 0x5c1
struct UUI_Component_Btn_C : UComponentButtonBaseWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x498 | Size: 0x8
	struct UWidgetAnimation* Anim_Enter; // Offset: 0x4a0 | Size: 0x8
	struct UWidgetAnimation* Anim_Remind; // Offset: 0x4a8 | Size: 0x8
	struct UWidgetAnimation* Anim_Hold; // Offset: 0x4b0 | Size: 0x8
	struct UWidgetAnimation* Anim_Hover; // Offset: 0x4b8 | Size: 0x8
	struct USolarImage* Img_Btn; // Offset: 0x4c0 | Size: 0x8
	struct USolarImage* Img_Icon; // Offset: 0x4c8 | Size: 0x8
	struct USolarImage* Img_Mask; // Offset: 0x4d0 | Size: 0x8
	struct USolarImage* Img_Shadow; // Offset: 0x4d8 | Size: 0x8
	struct UCanvasPanel* Panel_Press; // Offset: 0x4e0 | Size: 0x8
	struct UScaleBox* ScaleBox; // Offset: 0x4e8 | Size: 0x8
	struct USizeBox* Size_Btn; // Offset: 0x4f0 | Size: 0x8
	struct USizeBox* Size_Icon; // Offset: 0x4f8 | Size: 0x8
	struct USolarTextBlock* Text_Btn; // Offset: 0x500 | Size: 0x8
	struct UUI_Component_Hover_Square_4px_C* UI_Component_Hover_Square_4px; // Offset: 0x508 | Size: 0x8
	struct UNamedSlot* WidgetSlot; // Offset: 0x510 | Size: 0x8
	enum class E_Type_Btn BtnType; // Offset: 0x518 | Size: 0x1
	enum class E_State_Btn BtnState; // Offset: 0x519 | Size: 0x1
	char pad_0x51A[0x2]; // Offset: 0x51a | Size: 0x2
	struct FVector2D BtnSize; // Offset: 0x51c | Size: 0x8
	bool IsUseBtnImag; // Offset: 0x524 | Size: 0x1
	bool IsUseText; // Offset: 0x525 | Size: 0x1
	char pad_0x526[0x2]; // Offset: 0x526 | Size: 0x2
	struct FString Text; // Offset: 0x528 | Size: 0x10
	bool IsUseLocID; // Offset: 0x538 | Size: 0x1
	char pad_0x539[0x3]; // Offset: 0x539 | Size: 0x3
	int32_t LocID; // Offset: 0x53c | Size: 0x4
	enum class ESolarSupportLanguages PreviewLang; // Offset: 0x540 | Size: 0x1
	char pad_0x541[0x7]; // Offset: 0x541 | Size: 0x7
	struct FMulticastInlineDelegate OnClicked; // Offset: 0x548 | Size: 0x10
	struct FMulticastInlineDelegate OnPressed; // Offset: 0x558 | Size: 0x10
	struct FMulticastInlineDelegate OnReleased; // Offset: 0x568 | Size: 0x10
	bool IsIcon; // Offset: 0x578 | Size: 0x1
	char pad_0x579[0x7]; // Offset: 0x579 | Size: 0x7
	struct UObject* Icon; // Offset: 0x580 | Size: 0x8
	struct FVector2D Icon_Size; // Offset: 0x588 | Size: 0x8
	struct FSoftObjectPath OnClickedSound; // Offset: 0x590 | Size: 0x18
	int32_t Txt_Size; // Offset: 0x5a8 | Size: 0x4
	bool CustomColor; // Offset: 0x5ac | Size: 0x1
	char pad_0x5AD[0x3]; // Offset: 0x5ad | Size: 0x3
	struct FLinearColor TxtColor; // Offset: 0x5b0 | Size: 0x10
	bool CustomMask; // Offset: 0x5c0 | Size: 0x1

	// Functions

	// Object: Function UI_Component_Btn.UI_Component_Btn_C.StopAnims
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(0) Size(0x0) ]
	void StopAnims();

	// Object: Function UI_Component_Btn.UI_Component_Btn_C.IsAvailable
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x1) ]
	void IsAvailable(bool& Availble);

	// Object: Function UI_Component_Btn.UI_Component_Btn_C.SetBtnTxt
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetBtnTxt(struct FString NewParam);

	// Object: Function UI_Component_Btn.UI_Component_Btn_C.SetBtnState
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetBtnState(enum class E_State_Btn State);

	// Object: Function UI_Component_Btn.UI_Component_Btn_C.GetLocalText
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetLocalText();

	// Object: Function UI_Component_Btn.UI_Component_Btn_C.SetBtnText
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(2) Size(0x11) ]
	void SetBtnText(struct FString , enum class E_State_Btn );

	// Object: Function UI_Component_Btn.UI_Component_Btn_C.Update
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x1) ]
	void Update(bool IsDesignTime);

	// Object: Function UI_Component_Btn.UI_Component_Btn_C.BndEvt__OperateArea_K2Node_ComponentBoundEvent_6_OnButtonClickedEvent__DelegateSignature
	// Flags: [BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(0) Size(0x0) ]
	void BndEvt__OperateArea_K2Node_ComponentBoundEvent_6_OnButtonClickedEvent__DelegateSignature();

	// Object: Function UI_Component_Btn.UI_Component_Btn_C.BndEvt__OperateArea_K2Node_ComponentBoundEvent_7_OnButtonPressedEvent__DelegateSignature
	// Flags: [BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(0) Size(0x0) ]
	void BndEvt__OperateArea_K2Node_ComponentBoundEvent_7_OnButtonPressedEvent__DelegateSignature();

	// Object: Function UI_Component_Btn.UI_Component_Btn_C.BndEvt__OperateArea_K2Node_ComponentBoundEvent_8_OnButtonReleasedEvent__DelegateSignature
	// Flags: [BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(0) Size(0x0) ]
	void BndEvt__OperateArea_K2Node_ComponentBoundEvent_8_OnButtonReleasedEvent__DelegateSignature();

	// Object: Function UI_Component_Btn.UI_Component_Btn_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_Component_Btn.UI_Component_Btn_C.OnLocalLangChangedEx
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x10) ]
	void OnLocalLangChangedEx(struct FString InLang);

	// Object: Function UI_Component_Btn.UI_Component_Btn_C.ExecuteUbergraph_UI_Component_Btn
	// Flags: [Final|UbergraphFunction|HasDefaults]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_Component_Btn(int32_t EntryPoint);

	// Object: Function UI_Component_Btn.UI_Component_Btn_C.OnReleased__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnReleased__DelegateSignature();

	// Object: Function UI_Component_Btn.UI_Component_Btn_C.OnClicked__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked__DelegateSignature();

	// Object: Function UI_Component_Btn.UI_Component_Btn_C.OnPressed__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnPressed__DelegateSignature();
};

