#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Component_Keyboard.UI_Component_Keyboard_C
// Inherited Bytes: 0x260 | Struct Size: 0x33a
struct UUI_Component_Keyboard_C : USolarComponentKeyboard {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x260 | Size: 0x8
	struct UImage* Img_BG; // Offset: 0x268 | Size: 0x8
	struct UImage* Img_BG_2; // Offset: 0x270 | Size: 0x8
	struct UImage* Img_Bg_Frame; // Offset: 0x278 | Size: 0x8
	struct UImage* Img_Bg_Frame_2; // Offset: 0x280 | Size: 0x8
	struct UImage* Img_Key; // Offset: 0x288 | Size: 0x8
	struct UImage* Img_Key_2; // Offset: 0x290 | Size: 0x8
	struct USolarImage* Img_PlusIcon; // Offset: 0x298 | Size: 0x8
	struct UWidgetSwitcher* KeyAndMouseSwitcher; // Offset: 0x2a0 | Size: 0x8
	struct UUI_Component_Mouse_C* Mouse; // Offset: 0x2a8 | Size: 0x8
	struct USizeBox* SizeBox_1; // Offset: 0x2b0 | Size: 0x8
	struct USizeBox* SizeBox_2; // Offset: 0x2b8 | Size: 0x8
	struct UTextBlock* Txt_Key; // Offset: 0x2c0 | Size: 0x8
	struct UTextBlock* Txt_Key_2; // Offset: 0x2c8 | Size: 0x8
	struct FS_KeyPromptKeyBoard KeyBoardInfo; // Offset: 0x2d0 | Size: 0x68
	bool NewVar_1; // Offset: 0x338 | Size: 0x1
	bool bHasSecondKey; // Offset: 0x339 | Size: 0x1

	// Functions

	// Object: Function UI_Component_Keyboard.UI_Component_Keyboard_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();

	// Object: Function UI_Component_Keyboard.UI_Component_Keyboard_C.BP_RefreshTxtOrImgKey
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(3) Size(0x30) ]
	void BP_RefreshTxtOrImgKey(struct FInputChord InInputChord, struct UTextBlock* InTxtKey, struct UImage* InImgKey);

	// Object: Function UI_Component_Keyboard.UI_Component_Keyboard_C.SetKeyBoardCustomInfo
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(2) Size(0x69) ]
	void SetKeyBoardCustomInfo(struct FS_KeyPromptKeyBoard InKeyBoardInfo, struct FS_KeyPromptMouse InMouseInfo);

	// Object: Function UI_Component_Keyboard.UI_Component_Keyboard_C.BP_RefreshKeyboardUIAll
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(0) Size(0x0) ]
	void BP_RefreshKeyboardUIAll();

	// Object: Function UI_Component_Keyboard.UI_Component_Keyboard_C.BP_RefreshKeyboardUI
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(6) Size(0x30) ]
	void BP_RefreshKeyboardUI(struct UTextBlock* InTxtKey, struct UImage* InImgBg, struct USizeBox* InSizeBox, struct UImage* InImgFrame, struct UTextBlock* InTxtColor, struct UImage* InImgColor);

	// Object: Function UI_Component_Keyboard.UI_Component_Keyboard_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_Component_Keyboard.UI_Component_Keyboard_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(0) Size(0x0) ]
	void Construct();

	// Object: Function UI_Component_Keyboard.UI_Component_Keyboard_C.RefreshKeyboardUIImpl
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x10) ]
	void RefreshKeyboardUIImpl(struct TArray<struct FInputChord>& InputChordArray);

	// Object: Function UI_Component_Keyboard.UI_Component_Keyboard_C.ExecuteUbergraph_UI_Component_Keyboard
	// Flags: [Final|UbergraphFunction|HasDefaults]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_Component_Keyboard(int32_t EntryPoint);
};

