#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Component_Platform.UI_Component_Platform_C
// Inherited Bytes: 0x490 | Struct Size: 0x4b0
struct UUI_Component_Platform_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x490 | Size: 0x8
	struct UImage* Img_Icon; // Offset: 0x498 | Size: 0x8
	struct USizeBox* Size_Icon; // Offset: 0x4a0 | Size: 0x8
	enum class E_Platform E_Platform; // Offset: 0x4a8 | Size: 0x1
	bool UseIcon; // Offset: 0x4a9 | Size: 0x1
	char pad_0x4AA[0x2]; // Offset: 0x4aa | Size: 0x2
	int32_t IconSize; // Offset: 0x4ac | Size: 0x4

	// Functions

	// Object: Function UI_Component_Platform.UI_Component_Platform_C.SetBlendPlatform
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetBlendPlatform(bool UseIcon);

	// Object: Function UI_Component_Platform.UI_Component_Platform_C.SetSizeState
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetSizeState(enum class E_Platform Platform);

	// Object: Function UI_Component_Platform.UI_Component_Platform_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_Component_Platform.UI_Component_Platform_C.ExecuteUbergraph_UI_Component_Platform
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_Component_Platform(int32_t EntryPoint);
};

