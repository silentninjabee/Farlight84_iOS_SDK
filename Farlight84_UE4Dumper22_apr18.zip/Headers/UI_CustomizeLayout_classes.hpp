#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_CustomizeLayout.UI_CustomizeLayout_C
// Inherited Bytes: 0x490 | Struct Size: 0xff0
struct UUI_CustomizeLayout_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x490 | Size: 0x8
	struct UImage* Avatar; // Offset: 0x498 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* BT_Angle_Drag; // Offset: 0x4a0 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* BT_AutoFire_Drag; // Offset: 0x4a8 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* BT_Backpack_Drag; // Offset: 0x4b0 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* BT_BattleChatInfo; // Offset: 0x4b8 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* BT_BattleUI_Map; // Offset: 0x4c0 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* BT_Crouch_Drag; // Offset: 0x4c8 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* BT_Dog_Drag; // Offset: 0x4d0 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* BT_Emoji_Drag; // Offset: 0x4d8 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* BT_Emoji_Drag_2; // Offset: 0x4e0 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* BT_Emoji_Drag_3; // Offset: 0x4e8 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* BT_Fire_Drag; // Offset: 0x4f0 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* BT_Fire_Right_Drag; // Offset: 0x4f8 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* BT_FollowDance_Drag; // Offset: 0x500 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* BT_Gunsight_Drag; // Offset: 0x508 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* BT_JoystickSprint_Drag; // Offset: 0x510 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* BT_JoystickSprintHint_Drag; // Offset: 0x518 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* BT_Jump_Drag; // Offset: 0x520 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* BT_Mark_Drag; // Offset: 0x528 | Size: 0x8
	struct UImage* BT_Mask_Grid_Forbidden; // Offset: 0x530 | Size: 0x8
	struct UImage* BT_Mask_Grid_Forbidden_2; // Offset: 0x538 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* BT_Message_Drag; // Offset: 0x540 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* BT_MicroPhoneOperation_Drag; // Offset: 0x548 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* BT_Parachute_Drag; // Offset: 0x550 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* BT_PickUp_Drag; // Offset: 0x558 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* BT_PickUp_Drag_2; // Offset: 0x560 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* BT_PickUp_Drag_3; // Offset: 0x568 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* BT_PickUp_Drag_4; // Offset: 0x570 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* BT_PickupBox_Drag; // Offset: 0x578 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* BT_Progress_CountDown_Drag; // Offset: 0x580 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* BT_Progress_ShieldUpgrade_Drag; // Offset: 0x588 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* BT_QuickADS_Drag; // Offset: 0x590 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* BT_Reload_Drag; // Offset: 0x598 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* BT_Scope_Drag; // Offset: 0x5a0 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* BT_Settings_Drag; // Offset: 0x5a8 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* BT_ShieldAutoRE_Drag; // Offset: 0x5b0 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* BT_SpectatorList_Drag; // Offset: 0x5b8 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* BT_SuperSkill_Drag; // Offset: 0x5c0 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* BT_Switch_Drag; // Offset: 0x5c8 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* BT_SwitchWeapon_Drag; // Offset: 0x5d0 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* BT_TacticalSkill_Drag; // Offset: 0x5d8 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* BT_TacticalSkill_Drag_2; // Offset: 0x5e0 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* BT_TeammateStates_Drag; // Offset: 0x5e8 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* BT_Top3Victory_Drag; // Offset: 0x5f0 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* BT_Vehicle_Drag; // Offset: 0x5f8 | Size: 0x8
	struct USolarInputButton* BT_Vehicle_Drive; // Offset: 0x600 | Size: 0x8
	struct USolarInputButton* BT_Vehicle_Passenger; // Offset: 0x608 | Size: 0x8
	struct USolarInputButton* BT_Vehicle_Repair; // Offset: 0x610 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* BT_WalkJoyStick_Drag; // Offset: 0x618 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* BT_Weapon_Drag; // Offset: 0x620 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* BT_Weapon_Drag_2; // Offset: 0x628 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* BT_Weapon_Drag_3; // Offset: 0x630 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* BT_Zipline_Drag; // Offset: 0x638 | Size: 0x8
	struct UButton* Btn_ChangeStyle; // Offset: 0x640 | Size: 0x8
	struct UImage* Btn_Parachute; // Offset: 0x648 | Size: 0x8
	struct UImage* Btn_Switch; // Offset: 0x650 | Size: 0x8
	struct UCanvasPanel* CanvasPanel_7; // Offset: 0x658 | Size: 0x8
	struct UTextBlock* Debug; // Offset: 0x660 | Size: 0x8
	struct UTextBlock* Debug_2; // Offset: 0x668 | Size: 0x8
	struct UTextBlock* Debug_3; // Offset: 0x670 | Size: 0x8
	struct UTextBlock* Debug_4; // Offset: 0x678 | Size: 0x8
	struct UImage* FreeLookIcon; // Offset: 0x680 | Size: 0x8
	struct UHorizontalBox* HorizontalBox_Btn; // Offset: 0x688 | Size: 0x8
	struct UImage* Icon_BOX; // Offset: 0x690 | Size: 0x8
	struct UImage* Icon_Post_Full; // Offset: 0x698 | Size: 0x8
	struct UImage* Icon_Power; // Offset: 0x6a0 | Size: 0x8
	struct UImage* icon_Skill; // Offset: 0x6a8 | Size: 0x8
	struct UImage* icon_Skill_2; // Offset: 0x6b0 | Size: 0x8
	struct UImage* Icon_Sun_Full; // Offset: 0x6b8 | Size: 0x8
	struct UImage* Image; // Offset: 0x6c0 | Size: 0x8
	struct UImage* Image_105; // Offset: 0x6c8 | Size: 0x8
	struct UImage* Image_271; // Offset: 0x6d0 | Size: 0x8
	struct UImage* ImageWarnning; // Offset: 0x6d8 | Size: 0x8
	struct UImage* Img_Arrow_2; // Offset: 0x6e0 | Size: 0x8
	struct UImage* Img_Arrow_3; // Offset: 0x6e8 | Size: 0x8
	struct UImage* Img_BG_3; // Offset: 0x6f0 | Size: 0x8
	struct UImage* Img_BG_4; // Offset: 0x6f8 | Size: 0x8
	struct UImage* Img_BG_5; // Offset: 0x700 | Size: 0x8
	struct UImage* Img_BG_7; // Offset: 0x708 | Size: 0x8
	struct UImage* Img_BG_8; // Offset: 0x710 | Size: 0x8
	struct USolarImage* Img_BG_9; // Offset: 0x718 | Size: 0x8
	struct USolarImage* Img_BG_13; // Offset: 0x720 | Size: 0x8
	struct USolarImage* img_Bg_Border_4; // Offset: 0x728 | Size: 0x8
	struct UImage* Img_BG_Selected; // Offset: 0x730 | Size: 0x8
	struct UImage* Img_Change; // Offset: 0x738 | Size: 0x8
	struct UImage* Img_Change_bg; // Offset: 0x740 | Size: 0x8
	struct UImage* Img_Dog; // Offset: 0x748 | Size: 0x8
	struct UImage* Img_Drive; // Offset: 0x750 | Size: 0x8
	struct UImage* Img_Drive_2; // Offset: 0x758 | Size: 0x8
	struct UImage* Img_Emoji; // Offset: 0x760 | Size: 0x8
	struct UImage* Img_Emoji_2; // Offset: 0x768 | Size: 0x8
	struct UImage* Img_Emoji_3; // Offset: 0x770 | Size: 0x8
	struct UImage* Img_Emoji_4; // Offset: 0x778 | Size: 0x8
	struct UImage* Img_Emoji_5; // Offset: 0x780 | Size: 0x8
	struct UImage* Img_Emoji_6; // Offset: 0x788 | Size: 0x8
	struct UImage* Img_Emoji_7; // Offset: 0x790 | Size: 0x8
	struct UImage* Img_Emoji_8; // Offset: 0x798 | Size: 0x8
	struct UImage* Img_Emoji_Select; // Offset: 0x7a0 | Size: 0x8
	struct UImage* Img_Emoji_Select_2; // Offset: 0x7a8 | Size: 0x8
	struct UImage* Img_Emoji_Select_3; // Offset: 0x7b0 | Size: 0x8
	struct UImage* Img_Head; // Offset: 0x7b8 | Size: 0x8
	struct UImage* Img_Head_4; // Offset: 0x7c0 | Size: 0x8
	struct UImage* Img_Head_5; // Offset: 0x7c8 | Size: 0x8
	struct UImage* Img_Icon_2; // Offset: 0x7d0 | Size: 0x8
	struct UImage* Img_Icon_9; // Offset: 0x7d8 | Size: 0x8
	struct UImage* Img_Icon_10; // Offset: 0x7e0 | Size: 0x8
	struct UImage* Img_Icon_11; // Offset: 0x7e8 | Size: 0x8
	struct UImage* Img_Icon_13; // Offset: 0x7f0 | Size: 0x8
	struct UImage* Img_Icon_14; // Offset: 0x7f8 | Size: 0x8
	struct UImage* Img_Icon_Power_Bg; // Offset: 0x800 | Size: 0x8
	struct UImage* Img_JoystickSprint_Select; // Offset: 0x808 | Size: 0x8
	struct UImage* Img_JoystickSprintHint_Select; // Offset: 0x810 | Size: 0x8
	struct UImage* Img_Light; // Offset: 0x818 | Size: 0x8
	struct UImage* Img_PlayerBG; // Offset: 0x820 | Size: 0x8
	struct UImage* Img_PlayerBG_3; // Offset: 0x828 | Size: 0x8
	struct UImage* Img_PlayerBG_4; // Offset: 0x830 | Size: 0x8
	struct UImage* Img_Power_Bg; // Offset: 0x838 | Size: 0x8
	struct UImage* Img_Quality_Bg; // Offset: 0x840 | Size: 0x8
	struct UImage* Img_Quality_Bg_2; // Offset: 0x848 | Size: 0x8
	struct UImage* Img_Quality_Bg_3; // Offset: 0x850 | Size: 0x8
	struct UImage* Img_Quality_Bg_4; // Offset: 0x858 | Size: 0x8
	struct UImage* Img_Quality_Bg_5; // Offset: 0x860 | Size: 0x8
	struct UImage* Img_Quality_Bg_6; // Offset: 0x868 | Size: 0x8
	struct UImage* Img_Quality_Bg_7; // Offset: 0x870 | Size: 0x8
	struct UImage* Img_Quality_Bg_8; // Offset: 0x878 | Size: 0x8
	struct UImage* Img_Quality_Bg_9; // Offset: 0x880 | Size: 0x8
	struct UImage* Img_Quality_Bg_10; // Offset: 0x888 | Size: 0x8
	struct UImage* Img_Quality_Bg_11; // Offset: 0x890 | Size: 0x8
	struct UImage* Img_Quality_Bg_12; // Offset: 0x898 | Size: 0x8
	struct UImage* Img_Quality_Bg_13; // Offset: 0x8a0 | Size: 0x8
	struct UImage* Img_Quality_Bg_14; // Offset: 0x8a8 | Size: 0x8
	struct UImage* Img_Quality_Bg_15; // Offset: 0x8b0 | Size: 0x8
	struct UImage* Img_Quality_Bg_16; // Offset: 0x8b8 | Size: 0x8
	struct UImage* Img_Quality_BG_Line; // Offset: 0x8c0 | Size: 0x8
	struct UImage* Img_Quality_BG_Line_2; // Offset: 0x8c8 | Size: 0x8
	struct UImage* Img_Quality_BG_Line_3; // Offset: 0x8d0 | Size: 0x8
	struct UImage* Img_Quality_BG_Line_4; // Offset: 0x8d8 | Size: 0x8
	struct UImage* Img_Quality_BG_Line_5; // Offset: 0x8e0 | Size: 0x8
	struct UImage* Img_Quality_BG_Line_6; // Offset: 0x8e8 | Size: 0x8
	struct UImage* Img_Quality_BG_Line_7; // Offset: 0x8f0 | Size: 0x8
	struct UImage* Img_Quality_BG_Line_8; // Offset: 0x8f8 | Size: 0x8
	struct UImage* Img_Quality_BG_Line_10; // Offset: 0x900 | Size: 0x8
	struct UImage* Img_Quality_BG_Line_11; // Offset: 0x908 | Size: 0x8
	struct UImage* Img_Quality_BG_Line_12; // Offset: 0x910 | Size: 0x8
	struct UImage* Img_Quality_BG_Line_13; // Offset: 0x918 | Size: 0x8
	struct UImage* Img_Quality_BG_Line_14; // Offset: 0x920 | Size: 0x8
	struct UImage* img_Relive; // Offset: 0x928 | Size: 0x8
	struct UImage* img_Relive_2; // Offset: 0x930 | Size: 0x8
	struct UImage* img_Relive_3; // Offset: 0x938 | Size: 0x8
	struct UImage* Img_Scope; // Offset: 0x940 | Size: 0x8
	struct UImage* Img_Scope_2; // Offset: 0x948 | Size: 0x8
	struct UImage* Img_Scope_3; // Offset: 0x950 | Size: 0x8
	struct UImage* Img_Scope_Border; // Offset: 0x958 | Size: 0x8
	struct UImage* Img_Scope_Select; // Offset: 0x960 | Size: 0x8
	struct UImage* Img_Select; // Offset: 0x968 | Size: 0x8
	struct UImage* Img_Select_2; // Offset: 0x970 | Size: 0x8
	struct UImage* Img_Select_3; // Offset: 0x978 | Size: 0x8
	struct UImage* Img_Select_4; // Offset: 0x980 | Size: 0x8
	struct UImage* Img_Select_5; // Offset: 0x988 | Size: 0x8
	struct UImage* Img_Select_6; // Offset: 0x990 | Size: 0x8
	struct UImage* Img_Select_7; // Offset: 0x998 | Size: 0x8
	struct UImage* Img_Select_8; // Offset: 0x9a0 | Size: 0x8
	struct UImage* Img_Select_9; // Offset: 0x9a8 | Size: 0x8
	struct UImage* Img_Select_10; // Offset: 0x9b0 | Size: 0x8
	struct UImage* Img_Select_11; // Offset: 0x9b8 | Size: 0x8
	struct UImage* Img_Select_12; // Offset: 0x9c0 | Size: 0x8
	struct UImage* Img_Select_13; // Offset: 0x9c8 | Size: 0x8
	struct UImage* Img_Select_14; // Offset: 0x9d0 | Size: 0x8
	struct UImage* Img_Select_15; // Offset: 0x9d8 | Size: 0x8
	struct UImage* Img_Select_16; // Offset: 0x9e0 | Size: 0x8
	struct UImage* Img_Select_17; // Offset: 0x9e8 | Size: 0x8
	struct UImage* Img_Select_18; // Offset: 0x9f0 | Size: 0x8
	struct UImage* Img_Select_19; // Offset: 0x9f8 | Size: 0x8
	struct UImage* Img_Select_20; // Offset: 0xa00 | Size: 0x8
	struct UImage* Img_Select_23; // Offset: 0xa08 | Size: 0x8
	struct UImage* Img_Select_24; // Offset: 0xa10 | Size: 0x8
	struct UImage* Img_Select_25; // Offset: 0xa18 | Size: 0x8
	struct UImage* Img_Select_26; // Offset: 0xa20 | Size: 0x8
	struct UImage* Img_Select_27; // Offset: 0xa28 | Size: 0x8
	struct UImage* Img_Select_28; // Offset: 0xa30 | Size: 0x8
	struct UImage* Img_Select_29; // Offset: 0xa38 | Size: 0x8
	struct UImage* Img_Select_31; // Offset: 0xa40 | Size: 0x8
	struct UImage* Img_Select_BattleChatInfo; // Offset: 0xa48 | Size: 0x8
	struct UImage* Img_Select_Dog; // Offset: 0xa50 | Size: 0x8
	struct UImage* Img_Select_Message; // Offset: 0xa58 | Size: 0x8
	struct UImage* Img_Select_PickupBox; // Offset: 0xa60 | Size: 0x8
	struct UImage* Img_Select_QuickADS; // Offset: 0xa68 | Size: 0x8
	struct UImage* Img_Select_ShieldUpgrade; // Offset: 0xa70 | Size: 0x8
	struct UImage* Img_Select_SwitchWeapon; // Offset: 0xa78 | Size: 0x8
	struct UImage* Img_Select_TacticalSkill; // Offset: 0xa80 | Size: 0x8
	struct UImage* Img_Select_TacticalSkill_2; // Offset: 0xa88 | Size: 0x8
	struct UImage* Img_Select_Top3Victory; // Offset: 0xa90 | Size: 0x8
	struct UImage* Img_Select_Zipline; // Offset: 0xa98 | Size: 0x8
	struct UImage* Img_Shield; // Offset: 0xaa0 | Size: 0x8
	struct UImage* Img_State; // Offset: 0xaa8 | Size: 0x8
	struct UImage* Img_Tip_MarkedPoint; // Offset: 0xab0 | Size: 0x8
	struct UImage* Img_Tip_MarkedPoint_3; // Offset: 0xab8 | Size: 0x8
	struct UImage* Img_Tip_MarkedPoint_4; // Offset: 0xac0 | Size: 0x8
	struct UImage* Img_WalkJoyStick_Select; // Offset: 0xac8 | Size: 0x8
	struct UOverlay* Item; // Offset: 0xad0 | Size: 0x8
	struct UOverlay* Item_2; // Offset: 0xad8 | Size: 0x8
	struct UOverlay* Item_3; // Offset: 0xae0 | Size: 0x8
	struct UOverlay* Item_4; // Offset: 0xae8 | Size: 0x8
	struct UOverlay* Item_5; // Offset: 0xaf0 | Size: 0x8
	struct UOverlay* Item_6; // Offset: 0xaf8 | Size: 0x8
	struct UOverlay* Item_7; // Offset: 0xb00 | Size: 0x8
	struct UOverlay* Item_8; // Offset: 0xb08 | Size: 0x8
	struct UOverlay* Item_9; // Offset: 0xb10 | Size: 0x8
	struct UOverlay* Item_10; // Offset: 0xb18 | Size: 0x8
	struct UOverlay* Item_11; // Offset: 0xb20 | Size: 0x8
	struct UOverlay* Item_12; // Offset: 0xb28 | Size: 0x8
	struct UOverlay* Item_13; // Offset: 0xb30 | Size: 0x8
	struct UImage* ItemImage; // Offset: 0xb38 | Size: 0x8
	struct UImage* ItemImage_2; // Offset: 0xb40 | Size: 0x8
	struct UImage* ItemImage_3; // Offset: 0xb48 | Size: 0x8
	struct UImage* ItemImage_4; // Offset: 0xb50 | Size: 0x8
	struct UImage* ItemImage_5; // Offset: 0xb58 | Size: 0x8
	struct UImage* ItemImage_6; // Offset: 0xb60 | Size: 0x8
	struct UImage* ItemImage_7; // Offset: 0xb68 | Size: 0x8
	struct UImage* ItemImage_8; // Offset: 0xb70 | Size: 0x8
	struct UImage* ItemImage_9; // Offset: 0xb78 | Size: 0x8
	struct UImage* ItemImage_10; // Offset: 0xb80 | Size: 0x8
	struct UImage* ItemImage_11; // Offset: 0xb88 | Size: 0x8
	struct UImage* ItemImage_12; // Offset: 0xb90 | Size: 0x8
	struct UImage* ItemImage_13; // Offset: 0xb98 | Size: 0x8
	struct USolarTextBlock* ItemName; // Offset: 0xba0 | Size: 0x8
	struct USolarTextBlock* ItemName_2; // Offset: 0xba8 | Size: 0x8
	struct USolarTextBlock* ItemName_3; // Offset: 0xbb0 | Size: 0x8
	struct USolarTextBlock* ItemName_4; // Offset: 0xbb8 | Size: 0x8
	struct USolarTextBlock* ItemName_5; // Offset: 0xbc0 | Size: 0x8
	struct USolarTextBlock* ItemName_6; // Offset: 0xbc8 | Size: 0x8
	struct USolarTextBlock* ItemName_7; // Offset: 0xbd0 | Size: 0x8
	struct USolarTextBlock* ItemName_8; // Offset: 0xbd8 | Size: 0x8
	struct USolarTextBlock* ItemName_9; // Offset: 0xbe0 | Size: 0x8
	struct USolarTextBlock* ItemName_10; // Offset: 0xbe8 | Size: 0x8
	struct USolarTextBlock* ItemName_11; // Offset: 0xbf0 | Size: 0x8
	struct USolarTextBlock* ItemName_12; // Offset: 0xbf8 | Size: 0x8
	struct USolarTextBlock* ItemName_13; // Offset: 0xc00 | Size: 0x8
	struct UUI_Customize_Data_C* LayoutData; // Offset: 0xc08 | Size: 0x8
	struct UOverlay* Overlay; // Offset: 0xc10 | Size: 0x8
	struct UCanvasPanel* Panel_AngleView; // Offset: 0xc18 | Size: 0x8
	struct UCanvasPanel* Panel_AutoFire; // Offset: 0xc20 | Size: 0x8
	struct UCanvasPanel* Panel_Backpack; // Offset: 0xc28 | Size: 0x8
	struct UCanvasPanel* Panel_BattleChatInfo; // Offset: 0xc30 | Size: 0x8
	struct UCanvasPanel* Panel_BattleUI_Map; // Offset: 0xc38 | Size: 0x8
	struct UCanvasPanel* Panel_ChangeStyle; // Offset: 0xc40 | Size: 0x8
	struct UCanvasPanel* Panel_Consume; // Offset: 0xc48 | Size: 0x8
	struct UCanvasPanel* Panel_Crouch; // Offset: 0xc50 | Size: 0x8
	struct UCanvasPanel* Panel_DisableAngleView; // Offset: 0xc58 | Size: 0x8
	struct UCanvasPanel* Panel_DisableBattleChat; // Offset: 0xc60 | Size: 0x8
	struct UCanvasPanel* Panel_DisableEmoji; // Offset: 0xc68 | Size: 0x8
	struct UCanvasPanel* Panel_DisableFire; // Offset: 0xc70 | Size: 0x8
	struct UCanvasPanel* Panel_DisableFireRight; // Offset: 0xc78 | Size: 0x8
	struct UCanvasPanel* Panel_DisableGunsight; // Offset: 0xc80 | Size: 0x8
	struct UCanvasPanel* Panel_DisableSwitchWeapon; // Offset: 0xc88 | Size: 0x8
	struct UCanvasPanel* Panel_Dog; // Offset: 0xc90 | Size: 0x8
	struct UCanvasPanel* Panel_Emoji; // Offset: 0xc98 | Size: 0x8
	struct UCanvasPanel* Panel_Emoji_Box; // Offset: 0xca0 | Size: 0x8
	struct UCanvasPanel* Panel_Emoji_Select; // Offset: 0xca8 | Size: 0x8
	struct UCanvasPanel* Panel_Emoji_Switch; // Offset: 0xcb0 | Size: 0x8
	struct UCanvasPanel* Panel_Fire; // Offset: 0xcb8 | Size: 0x8
	struct UCanvasPanel* Panel_Fire_Right; // Offset: 0xcc0 | Size: 0x8
	struct UCanvasPanel* Panel_FollowDance; // Offset: 0xcc8 | Size: 0x8
	struct UCanvasPanel* Panel_Gunsight; // Offset: 0xcd0 | Size: 0x8
	struct UCanvasPanel* Panel_HP; // Offset: 0xcd8 | Size: 0x8
	struct UCanvasPanel* Panel_Info; // Offset: 0xce0 | Size: 0x8
	struct UCanvasPanel* Panel_Info_3; // Offset: 0xce8 | Size: 0x8
	struct UCanvasPanel* Panel_Info_4; // Offset: 0xcf0 | Size: 0x8
	struct UCanvasPanel* Panel_JoystickSprint; // Offset: 0xcf8 | Size: 0x8
	struct UCanvasPanel* Panel_JoystickSprintHint; // Offset: 0xd00 | Size: 0x8
	struct UCanvasPanel* Panel_Jump; // Offset: 0xd08 | Size: 0x8
	struct UCanvasPanel* Panel_Line; // Offset: 0xd10 | Size: 0x8
	struct UCanvasPanel* Panel_Mark; // Offset: 0xd18 | Size: 0x8
	struct UCanvasPanel* Panel_Message; // Offset: 0xd20 | Size: 0x8
	struct UCanvasPanel* Panel_Message_Select; // Offset: 0xd28 | Size: 0x8
	struct UCanvasPanel* Panel_Message_Switch; // Offset: 0xd30 | Size: 0x8
	struct UCanvasPanel* Panel_MicroPhoneOperation; // Offset: 0xd38 | Size: 0x8
	struct UCanvasPanel* Panel_Parachute; // Offset: 0xd40 | Size: 0x8
	struct UCanvasPanel* Panel_PickUp; // Offset: 0xd48 | Size: 0x8
	struct UCanvasPanel* Panel_PickupBox; // Offset: 0xd50 | Size: 0x8
	struct UCanvasPanel* Panel_PickUpList; // Offset: 0xd58 | Size: 0x8
	struct UCanvasPanel* Panel_PickUpList_Box; // Offset: 0xd60 | Size: 0x8
	struct UCanvasPanel* Panel_PickUpList_hand; // Offset: 0xd68 | Size: 0x8
	struct UCanvasPanel* Panel_PlayerHead; // Offset: 0xd70 | Size: 0x8
	struct UCanvasPanel* Panel_PlayerHead_3; // Offset: 0xd78 | Size: 0x8
	struct UCanvasPanel* Panel_PlayerHead_4; // Offset: 0xd80 | Size: 0x8
	struct UCanvasPanel* Panel_Progress_CountDown; // Offset: 0xd88 | Size: 0x8
	struct UCanvasPanel* Panel_QuickADS; // Offset: 0xd90 | Size: 0x8
	struct UCanvasPanel* Panel_Reload; // Offset: 0xd98 | Size: 0x8
	struct UCanvasPanel* Panel_Scope; // Offset: 0xda0 | Size: 0x8
	struct UCanvasPanel* Panel_ScopeList; // Offset: 0xda8 | Size: 0x8
	struct UCanvasPanel* Panel_Settings; // Offset: 0xdb0 | Size: 0x8
	struct UCanvasPanel* Panel_ShieldAutoRE; // Offset: 0xdb8 | Size: 0x8
	struct USolarAdapterWidget* Panel_ShieldAutoRE_KeyMapping; // Offset: 0xdc0 | Size: 0x8
	struct USolarAdapterWidget* Panel_ShieldAutoRE_KeyMapping_2; // Offset: 0xdc8 | Size: 0x8
	struct USolarAdapterWidget* Panel_ShieldAutoRE_KeyMapping_3; // Offset: 0xdd0 | Size: 0x8
	struct USolarAdapterWidget* Panel_ShieldAutoRE_KeyMapping_4; // Offset: 0xdd8 | Size: 0x8
	struct UCanvasPanel* Panel_ShieldUpgrade; // Offset: 0xde0 | Size: 0x8
	struct UCanvasPanel* Panel_SpectatorItems; // Offset: 0xde8 | Size: 0x8
	struct UCanvasPanel* Panel_SpectatorList; // Offset: 0xdf0 | Size: 0x8
	struct UCanvasPanel* Panel_SuperSkill; // Offset: 0xdf8 | Size: 0x8
	struct UCanvasPanel* Panel_Switch; // Offset: 0xe00 | Size: 0x8
	struct UCanvasPanel* Panel_SwitchWeapon; // Offset: 0xe08 | Size: 0x8
	struct UCanvasPanel* Panel_Tab; // Offset: 0xe10 | Size: 0x8
	struct UCanvasPanel* Panel_TacticalSkill; // Offset: 0xe18 | Size: 0x8
	struct UCanvasPanel* Panel_TacticalSkill_3; // Offset: 0xe20 | Size: 0x8
	struct UCanvasPanel* Panel_TaskItems; // Offset: 0xe28 | Size: 0x8
	struct UCanvasPanel* Panel_TeammateStates; // Offset: 0xe30 | Size: 0x8
	struct UCanvasPanel* Panel_Top3Victory; // Offset: 0xe38 | Size: 0x8
	struct UCanvasPanel* Panel_Vehicle_Drive_Passenger; // Offset: 0xe40 | Size: 0x8
	struct UCanvasPanel* Panel_WalkJoyStick; // Offset: 0xe48 | Size: 0x8
	struct UCanvasPanel* Panel_WalkJoyStickScaleAndOpacity; // Offset: 0xe50 | Size: 0x8
	struct UCanvasPanel* Panel_Weapon_2; // Offset: 0xe58 | Size: 0x8
	struct UCanvasPanel* Panel_Weapon_3; // Offset: 0xe60 | Size: 0x8
	struct UCanvasPanel* Panel_Weapon_4; // Offset: 0xe68 | Size: 0x8
	struct UCanvasPanel* Panel_Zipline; // Offset: 0xe70 | Size: 0x8
	struct UOverlay* Plane_Notice; // Offset: 0xe78 | Size: 0x8
	struct UImage* PoisonBar; // Offset: 0xe80 | Size: 0x8
	struct UImage* Progress_RecyclingResurrection; // Offset: 0xe88 | Size: 0x8
	struct UImage* Progress_RecyclingResurrection_2; // Offset: 0xe90 | Size: 0x8
	struct UImage* Progress_RecyclingResurrection_3; // Offset: 0xe98 | Size: 0x8
	struct UProgressBar* ProgressBar_Lv; // Offset: 0xea0 | Size: 0x8
	struct USolarRichTextBlock* RichText_2; // Offset: 0xea8 | Size: 0x8
	struct USolarRichTextBlock* RichText_3; // Offset: 0xeb0 | Size: 0x8
	struct USolarRichTextBlock* RichText_4; // Offset: 0xeb8 | Size: 0x8
	struct USolarRichTextBlock* RichText_5; // Offset: 0xec0 | Size: 0x8
	struct USizeBox* SizeBox_Container_2; // Offset: 0xec8 | Size: 0x8
	struct USizeBox* SizeBox_Container_3; // Offset: 0xed0 | Size: 0x8
	struct USizeBox* SizeBox_Container_4; // Offset: 0xed8 | Size: 0x8
	struct USizeBox* SizeBox_Relive; // Offset: 0xee0 | Size: 0x8
	struct USizeBox* SizeBox_Relive_2; // Offset: 0xee8 | Size: 0x8
	struct USizeBox* SizeBox_Relive_3; // Offset: 0xef0 | Size: 0x8
	struct UTextBlock* TB_ExtraEnergy; // Offset: 0xef8 | Size: 0x8
	struct UTextBlock* TB_ExtraEnergy_Max; // Offset: 0xf00 | Size: 0x8
	struct UTextBlock* Text_NickName; // Offset: 0xf08 | Size: 0x8
	struct UTextBlock* Text_NickName_3; // Offset: 0xf10 | Size: 0x8
	struct UTextBlock* Text_NickName_4; // Offset: 0xf18 | Size: 0x8
	struct USolarTextBlock* TextBlock_Drive; // Offset: 0xf20 | Size: 0x8
	struct USolarTextBlock* TextBlock_Drive_2; // Offset: 0xf28 | Size: 0x8
	struct USolarTextBlock* TextBlock_Passenger; // Offset: 0xf30 | Size: 0x8
	struct UTextBlock* TextDistance; // Offset: 0xf38 | Size: 0x8
	struct UTextBlock* TextTime; // Offset: 0xf40 | Size: 0x8
	struct UCanvasPanel* TimePanel; // Offset: 0xf48 | Size: 0x8
	struct USolarTextBlock* Txt_FollowDance; // Offset: 0xf50 | Size: 0x8
	struct USolarTextBlock* Txt_Interact; // Offset: 0xf58 | Size: 0x8
	struct USolarTextBlock* Txt_Lvl; // Offset: 0xf60 | Size: 0x8
	struct USolarTextBlock* Txt_Lvl_1; // Offset: 0xf68 | Size: 0x8
	struct USolarTextBlock* Txt_Lvl_2; // Offset: 0xf70 | Size: 0x8
	struct USolarTextBlock* Txt_Lvl_4; // Offset: 0xf78 | Size: 0x8
	struct USolarTextBlock* Txt_Lvl_5; // Offset: 0xf80 | Size: 0x8
	struct USolarTextBlock* Txt_Notice; // Offset: 0xf88 | Size: 0x8
	struct UTextBlock* Txt_Restore_Num; // Offset: 0xf90 | Size: 0x8
	struct USolarTextBlock* Txt_Scope; // Offset: 0xf98 | Size: 0x8
	struct USolarTextBlock* Txt_TeamPos; // Offset: 0xfa0 | Size: 0x8
	struct USolarTextBlock* Txt_TeamPos_3; // Offset: 0xfa8 | Size: 0x8
	struct USolarTextBlock* Txt_TeamPos_4; // Offset: 0xfb0 | Size: 0x8
	struct UTextBlock* Txt_ViewerNum; // Offset: 0xfb8 | Size: 0x8
	struct UTextBlock* Txt_ViewerNum_2; // Offset: 0xfc0 | Size: 0x8
	struct UUI_Notice_Top3Victory_C* UI_Notice_Top3Victory; // Offset: 0xfc8 | Size: 0x8
	struct UHorizontalBox* Vehicle_Drive; // Offset: 0xfd0 | Size: 0x8
	struct UHorizontalBox* Vehicle_Passenger; // Offset: 0xfd8 | Size: 0x8
	struct UWidgetSwitcher* WidgetSwitcher_VehicleRepair; // Offset: 0xfe0 | Size: 0x8
	struct UCanvasPanel* ; // Offset: 0xfe8 | Size: 0x8

	// Functions

	// Object: Function UI_CustomizeLayout.UI_CustomizeLayout_C.OnInitialized
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x101785338
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnInitialized();

	// Object: Function UI_CustomizeLayout.UI_CustomizeLayout_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();

	// Object: Function UI_CustomizeLayout.UI_CustomizeLayout_C.Get_Hero01_CheckedState_1
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class ECheckBoxState Get_Hero01_CheckedState_1();

	// Object: Function UI_CustomizeLayout.UI_CustomizeLayout_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_CustomizeLayout.UI_CustomizeLayout_C.ExecuteUbergraph_UI_CustomizeLayout
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_CustomizeLayout(int32_t EntryPoint);
};

