#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Customize_Data.UI_Customize_Data_C
// Inherited Bytes: 0x260 | Struct Size: 0x270
struct UUI_Customize_Data_C : UUserWidget {
	// Fields
	struct TArray<struct FS_Customize_Element> ElementConfig; // Offset: 0x260 | Size: 0x10
};

