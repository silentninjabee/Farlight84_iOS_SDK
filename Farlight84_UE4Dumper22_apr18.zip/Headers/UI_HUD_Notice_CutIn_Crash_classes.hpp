#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_HUD_Notice_CutIn_Crash.UI_HUD_Notice_CutIn_Crash_C
// Inherited Bytes: 0x260 | Struct Size: 0x288
struct UUI_HUD_Notice_CutIn_Crash_C : UUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x260 | Size: 0x8
	struct UWidgetAnimation* ant_exit; // Offset: 0x268 | Size: 0x8
	struct UWidgetAnimation* Loop_Nova_Anim; // Offset: 0x270 | Size: 0x8
	struct UWidgetAnimation* Appear_Anim; // Offset: 0x278 | Size: 0x8
	struct USolarTextBlock* Txt_Nova; // Offset: 0x280 | Size: 0x8

	// Functions

	// Object: Function UI_HUD_Notice_CutIn_Crash.UI_HUD_Notice_CutIn_Crash_C.show
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x10) ]
	void show(struct FString );

	// Object: Function UI_HUD_Notice_CutIn_Crash.UI_HUD_Notice_CutIn_Crash_C.Close
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(0) Size(0x0) ]
	void Close();

	// Object: Function UI_HUD_Notice_CutIn_Crash.UI_HUD_Notice_CutIn_Crash_C.ExecuteUbergraph_UI_HUD_Notice_CutIn_Crash
	// Flags: [Final|UbergraphFunction|HasDefaults]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_HUD_Notice_CutIn_Crash(int32_t EntryPoint);
};

