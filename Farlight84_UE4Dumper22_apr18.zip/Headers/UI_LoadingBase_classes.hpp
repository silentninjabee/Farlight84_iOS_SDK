#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_LoadingBase.UI_LoadingBase_C
// Inherited Bytes: 0x4c8 | Struct Size: 0x4c8
struct UUI_LoadingBase_C : ULoadingUIBase {
};

