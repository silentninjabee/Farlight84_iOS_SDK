#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Lobby_Invite_Btn.UI_Lobby_Invite_Btn_C
// Inherited Bytes: 0x490 | Struct Size: 0x4b2
struct UUI_Lobby_Invite_Btn_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x490 | Size: 0x8
	struct UButton* Btn_Invite; // Offset: 0x498 | Size: 0x8
	struct UImage* Img_BG_2; // Offset: 0x4a0 | Size: 0x8
	struct UOverlay* Overlay_Txt; // Offset: 0x4a8 | Size: 0x8
	bool IsDesktop; // Offset: 0x4b0 | Size: 0x1
	enum class E_Type_State_Button StateDesktop; // Offset: 0x4b1 | Size: 0x1

	// Functions

	// Object: DelegateFunction UI_Lobby_Invite_Btn.UI_Lobby_Invite_Btn_C.OnClicked_C7A8CBFBB945E208F940C3A343FEEF7F
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10176f770
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_C7A8CBFBB945E208F940C3A343FEEF7F();

	// Object: DelegateFunction UI_Lobby_Invite_Btn.UI_Lobby_Invite_Btn_C.OnClicked_B7AF9D1F454F7ED04834A6ACE9ACA4CB
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10176f770
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_B7AF9D1F454F7ED04834A6ACE9ACA4CB();

	// Object: DelegateFunction UI_Lobby_Invite_Btn.UI_Lobby_Invite_Btn_C.OnClicked_28567405ED47C06A666E6B92F724214B
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10176f770
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_28567405ED47C06A666E6B92F724214B();

	// Object: Function UI_Lobby_Invite_Btn.UI_Lobby_Invite_Btn_C.OnInitialized
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x101785338
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnInitialized();

	// Object: Function UI_Lobby_Invite_Btn.UI_Lobby_Invite_Btn_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();

	// Object: Function UI_Lobby_Invite_Btn.UI_Lobby_Invite_Btn_C.SetStateDesktop
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(2) Size(0x2) ]
	void SetStateDesktop(bool IsDesktop, enum class E_Type_State_Button StateDesktop);

	// Object: Function UI_Lobby_Invite_Btn.UI_Lobby_Invite_Btn_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_Lobby_Invite_Btn.UI_Lobby_Invite_Btn_C.ExecuteUbergraph_UI_Lobby_Invite_Btn
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_Lobby_Invite_Btn(int32_t EntryPoint);
};

