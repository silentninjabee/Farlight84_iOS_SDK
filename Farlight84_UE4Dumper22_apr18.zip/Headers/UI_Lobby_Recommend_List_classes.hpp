#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Lobby_Recommend_List.UI_Lobby_Recommend_List_C
// Inherited Bytes: 0x490 | Struct Size: 0x4d0
struct UUI_Lobby_Recommend_List_C : USolarUserWidget {
	// Fields
	struct UButton* Btn_Recruit; // Offset: 0x490 | Size: 0x8
	struct UButton* Btn_Social; // Offset: 0x498 | Size: 0x8
	struct USolarListView* List_Invite; // Offset: 0x4a0 | Size: 0x8
	struct UCanvasPanel* Panel_Recruit; // Offset: 0x4a8 | Size: 0x8
	struct UCanvasPanel* Panel_Social; // Offset: 0x4b0 | Size: 0x8
	struct USolarRedHint_General_C* RedHint_Social; // Offset: 0x4b8 | Size: 0x8
	struct UWidgetSwitcher* Switcher_Friend; // Offset: 0x4c0 | Size: 0x8
	struct UTextBlock* Txt_Num; // Offset: 0x4c8 | Size: 0x8

	// Functions

	// Object: DelegateFunction UI_Lobby_Recommend_List.UI_Lobby_Recommend_List_C.OnClicked_9929EB3BED45DA3C19294A9C2F3CAD3E
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10176f770
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_9929EB3BED45DA3C19294A9C2F3CAD3E();

	// Object: DelegateFunction UI_Lobby_Recommend_List.UI_Lobby_Recommend_List_C.OnClicked_5476742D4848974347FFE0A9FFB3A3B9
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10176f770
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_5476742D4848974347FFE0A9FFB3A3B9();

	// Object: Function UI_Lobby_Recommend_List.UI_Lobby_Recommend_List_C.OnSolarUIClosed
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x101785338
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnSolarUIClosed();

	// Object: Function UI_Lobby_Recommend_List.UI_Lobby_Recommend_List_C.OnInitialized
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x101785338
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnInitialized();

	// Object: Function UI_Lobby_Recommend_List.UI_Lobby_Recommend_List_C.OnSolarUIOpened
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x101785338
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnSolarUIOpened();

	// Object: Function UI_Lobby_Recommend_List.UI_Lobby_Recommend_List_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();
};

