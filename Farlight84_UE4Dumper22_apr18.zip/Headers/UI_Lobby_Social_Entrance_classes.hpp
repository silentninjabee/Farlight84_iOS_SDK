#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Lobby_Social_Entrance.UI_Lobby_Social_Entrance_C
// Inherited Bytes: 0x490 | Struct Size: 0x531
struct UUI_Lobby_Social_Entrance_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x490 | Size: 0x8
	struct UButton* Btn_Close; // Offset: 0x498 | Size: 0x8
	struct UButton* Btn_Discord; // Offset: 0x4a0 | Size: 0x8
	struct UButton* Btn_Facebook; // Offset: 0x4a8 | Size: 0x8
	struct UButton* Btn_Instagram; // Offset: 0x4b0 | Size: 0x8
	struct UButton* Btn_LiveVideo; // Offset: 0x4b8 | Size: 0x8
	struct UButton* Btn_TikTok; // Offset: 0x4c0 | Size: 0x8
	struct UButton* Btn_YouTube; // Offset: 0x4c8 | Size: 0x8
	struct UCanvasPanel* Discord; // Offset: 0x4d0 | Size: 0x8
	struct UCanvasPanel* FACEBOOK; // Offset: 0x4d8 | Size: 0x8
	struct UCanvasPanel* Instagram; // Offset: 0x4e0 | Size: 0x8
	struct UCanvasPanel* Panel_LiveVideo; // Offset: 0x4e8 | Size: 0x8
	struct USolarRedHint_General_C* SolarHintPoint_Red; // Offset: 0x4f0 | Size: 0x8
	struct USolarRedHint_General_C* SolarRedHint_General; // Offset: 0x4f8 | Size: 0x8
	struct USolarRedHint_General_C* SolarRedHint_General_49; // Offset: 0x500 | Size: 0x8
	struct USolarRedHint_General_C* SolarRedHint_General_96; // Offset: 0x508 | Size: 0x8
	struct USolarRedHint_General_C* SolarRedHint_Instagram; // Offset: 0x510 | Size: 0x8
	struct USolarRedHint_General_C* SolarRedHint_TikTok; // Offset: 0x518 | Size: 0x8
	struct UCanvasPanel* TikTok; // Offset: 0x520 | Size: 0x8
	struct UCanvasPanel* YouTube; // Offset: 0x528 | Size: 0x8
	bool isShowGuide; // Offset: 0x530 | Size: 0x1

	// Functions

	// Object: DelegateFunction UI_Lobby_Social_Entrance.UI_Lobby_Social_Entrance_C.OnClicked_AC1DBE851C4D356A8C2C61AAACBA35FC
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10176f770
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_AC1DBE851C4D356A8C2C61AAACBA35FC();

	// Object: DelegateFunction UI_Lobby_Social_Entrance.UI_Lobby_Social_Entrance_C.OnClicked_6BC4C6DC1147AC11E746D98E2B9F964F
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10176f770
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_6BC4C6DC1147AC11E746D98E2B9F964F();

	// Object: DelegateFunction UI_Lobby_Social_Entrance.UI_Lobby_Social_Entrance_C.OnClicked_18732AF22D437CFE0A4AFF9014504BFF
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10176f770
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_18732AF22D437CFE0A4AFF9014504BFF();

	// Object: DelegateFunction UI_Lobby_Social_Entrance.UI_Lobby_Social_Entrance_C.OnClicked_5324ACAD1440938A9D06ABAC8223F5C8
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10176f770
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_5324ACAD1440938A9D06ABAC8223F5C8();

	// Object: DelegateFunction UI_Lobby_Social_Entrance.UI_Lobby_Social_Entrance_C.OnClicked_BE243300CE4A9D75736906A796F0B6AE
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10176f770
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_BE243300CE4A9D75736906A796F0B6AE();

	// Object: DelegateFunction UI_Lobby_Social_Entrance.UI_Lobby_Social_Entrance_C.OnClicked_533B443BCB40E271AFC39082DA80C098
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10176f770
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_533B443BCB40E271AFC39082DA80C098();

	// Object: DelegateFunction UI_Lobby_Social_Entrance.UI_Lobby_Social_Entrance_C.OnClicked_30BAA0B9D34C65D248ABCA9D86E18E2C
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10176f770
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_30BAA0B9D34C65D248ABCA9D86E18E2C();

	// Object: Function UI_Lobby_Social_Entrance.UI_Lobby_Social_Entrance_C.OnInitialized
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x101785338
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnInitialized();

	// Object: Function UI_Lobby_Social_Entrance.UI_Lobby_Social_Entrance_C.OnSolarUIClosed
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x101785338
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnSolarUIClosed();

	// Object: Function UI_Lobby_Social_Entrance.UI_Lobby_Social_Entrance_C.OnSolarUIOpened
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x101785338
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnSolarUIOpened();

	// Object: Function UI_Lobby_Social_Entrance.UI_Lobby_Social_Entrance_C.ConstructCopy
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(0) Size(0x0) ]
	void ConstructCopy();

	// Object: Function UI_Lobby_Social_Entrance.UI_Lobby_Social_Entrance_C.Destruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x101785338
	// Return & Params: [ Num(0) Size(0x0) ]
	void Destruct();

	// Object: Function UI_Lobby_Social_Entrance.UI_Lobby_Social_Entrance_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();

	// Object: Function UI_Lobby_Social_Entrance.UI_Lobby_Social_Entrance_C.ShowGuide
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x1) ]
	void ShowGuide(bool ShowGuide);

	// Object: Function UI_Lobby_Social_Entrance.UI_Lobby_Social_Entrance_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_Lobby_Social_Entrance.UI_Lobby_Social_Entrance_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x101785338
	// Return & Params: [ Num(0) Size(0x0) ]
	void Construct();

	// Object: Function UI_Lobby_Social_Entrance.UI_Lobby_Social_Entrance_C.ExecuteUbergraph_UI_Lobby_Social_Entrance
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_Lobby_Social_Entrance(int32_t EntryPoint);
};

