#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C
// Inherited Bytes: 0x490 | Struct Size: 0x5b0
struct UUI_Lobby_TeamMember_Operation_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x490 | Size: 0x8
	struct UButton* Btn_Buff; // Offset: 0x498 | Size: 0x8
	struct USolarButton* Btn_QuitTeam; // Offset: 0x4a0 | Size: 0x8
	struct USolarButton* Btn_ShowOperationPanel; // Offset: 0x4a8 | Size: 0x8
	struct USolarButton* Button_Emoji; // Offset: 0x4b0 | Size: 0x8
	struct USolarButton* Button_Emoji_Close; // Offset: 0x4b8 | Size: 0x8
	struct UUI_Component_Emoji_List_C* Emoji_List; // Offset: 0x4c0 | Size: 0x8
	struct USolarCheckBox* EmojiBtn; // Offset: 0x4c8 | Size: 0x8
	struct UImage* Img_AppDeactivated_Mark; // Offset: 0x4d0 | Size: 0x8
	struct UImage* Img_BG; // Offset: 0x4d8 | Size: 0x8
	struct UImage* Img_Buff; // Offset: 0x4e0 | Size: 0x8
	struct UImage* Img_BusinessCard_Hover; // Offset: 0x4e8 | Size: 0x8
	struct UImage* Img_Captain; // Offset: 0x4f0 | Size: 0x8
	struct UImage* Img_MicroPhone_Mark; // Offset: 0x4f8 | Size: 0x8
	struct UImage* Img_NameColor; // Offset: 0x500 | Size: 0x8
	struct UImage* Img_OpenCard; // Offset: 0x508 | Size: 0x8
	struct UImage* Img_QuitTeam_Hover; // Offset: 0x510 | Size: 0x8
	struct UOverlay* Img_Ready_Mark; // Offset: 0x518 | Size: 0x8
	struct UImage* Img_Top; // Offset: 0x520 | Size: 0x8
	struct UOverlay* Overlay_Vip; // Offset: 0x528 | Size: 0x8
	struct UCanvasPanel* Panel_Buff; // Offset: 0x530 | Size: 0x8
	struct UCanvasPanel* Panel_Captain; // Offset: 0x538 | Size: 0x8
	struct UCanvasPanel* Panel_Emoji; // Offset: 0x540 | Size: 0x8
	struct UCanvasPanel* Panel_Voice; // Offset: 0x548 | Size: 0x8
	struct USizeBox* SizeBox_2; // Offset: 0x550 | Size: 0x8
	struct USizeBox* SizeBox_Wave; // Offset: 0x558 | Size: 0x8
	struct USolarTextBlock* Text_NickName; // Offset: 0x560 | Size: 0x8
	struct UUI_Chat_Wave_C* UI_Chat_Wave; // Offset: 0x568 | Size: 0x8
	struct UUI_Component_Platform_C* UI_Component_Platform; // Offset: 0x570 | Size: 0x8
	struct UUI_Component_PlayerName_C* UI_Component_PlayerName; // Offset: 0x578 | Size: 0x8
	struct UUI_Lobby_Name_Version_C* UI_Lobby_Name_Version; // Offset: 0x580 | Size: 0x8
	struct UUI_MicroPhoneSetting_C* UI_MicroPhoneSetting; // Offset: 0x588 | Size: 0x8
	struct UUI_Rank_Icon_Small_C* UI_Rank_Icon_Small; // Offset: 0x590 | Size: 0x8
	struct UUI_Vip_Icon_Type_C* UI_Vip_Icon_Type; // Offset: 0x598 | Size: 0x8
	int32_t IndexInLobby; // Offset: 0x5a0 | Size: 0x4
	bool Steam; // Offset: 0x5a4 | Size: 0x1
	enum class E_Type_State_Button StatePlayernameHD; // Offset: 0x5a5 | Size: 0x1
	enum class E_Type_State_Button StateQuitHD; // Offset: 0x5a6 | Size: 0x1
	bool IsHD; // Offset: 0x5a7 | Size: 0x1
	bool IsHighlight; // Offset: 0x5a8 | Size: 0x1
	char pad_0x5A9[0x3]; // Offset: 0x5a9 | Size: 0x3
	int32_t Num; // Offset: 0x5ac | Size: 0x4

	// Functions

	// Object: DelegateFunction UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.OnClicked_69EAE4EAAA45DD02E06270B47A2865B5
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10176f770
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_69EAE4EAAA45DD02E06270B47A2865B5();

	// Object: DelegateFunction UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.OnClicked_A857BBFF9D49A7437B0330AEDDF8D1E3
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10176f770
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_A857BBFF9D49A7437B0330AEDDF8D1E3();

	// Object: DelegateFunction UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.OnClicked_1E9CE10AB94E4EFDB3F24E99E18BCCB7
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10176f770
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_1E9CE10AB94E4EFDB3F24E99E18BCCB7();

	// Object: DelegateFunction UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.OnClicked_B638A214954D20B83F1233A9B4A4E48D
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10176f770
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_B638A214954D20B83F1233A9B4A4E48D();

	// Object: DelegateFunction UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.OnClicked_F5070DDC0D48EB9016F8708D9103CDB1
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10176f770
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_F5070DDC0D48EB9016F8708D9103CDB1();

	// Object: DelegateFunction UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.OnClicked_6387FB12744F3ADCD0DB9091A2A60E14
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10176f770
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_6387FB12744F3ADCD0DB9091A2A60E14();

	// Object: DelegateFunction UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.OnClicked_059A201E00437F3F3E0311AF31460190
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10176f770
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_059A201E00437F3F3E0311AF31460190();

	// Object: DelegateFunction UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.OnClicked_2D2F1B5C754AC3A93E882089D5916900
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10176f770
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_2D2F1B5C754AC3A93E882089D5916900();

	// Object: DelegateFunction UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.OnClicked_86454D1AE14198511B98E38AE83E8263
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10176f770
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_86454D1AE14198511B98E38AE83E8263();

	// Object: DelegateFunction UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.OnClicked_A1AE70CBE0425CE78B9E7099E18505B6
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10176f770
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_A1AE70CBE0425CE78B9E7099E18505B6();

	// Object: DelegateFunction UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.OnClicked_9713E7E4C247AF38208CF8ADF9F2D8FA
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10176f770
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_9713E7E4C247AF38208CF8ADF9F2D8FA();

	// Object: DelegateFunction UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.OnClicked_825EB5454B4909F08039938B85F90FC1
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10176f770
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_825EB5454B4909F08039938B85F90FC1();

	// Object: DelegateFunction UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.OnCheckStateChanged_18C088AAFF4B5D8C07CB23A311E2DA01
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10176f770
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnCheckStateChanged_18C088AAFF4B5D8C07CB23A311E2DA01(bool bIsChecked);

	// Object: DelegateFunction UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.OnCheckStateChanged_A06E1E20DE4740CDF18ECF8610E8B868
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10176f770
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnCheckStateChanged_A06E1E20DE4740CDF18ECF8610E8B868(bool bIsChecked);

	// Object: DelegateFunction UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.OnCheckStateChanged_D64028A3BC4A4735301012B3EC55EEF3
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10176f770
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnCheckStateChanged_D64028A3BC4A4735301012B3EC55EEF3(bool bIsChecked);

	// Object: DelegateFunction UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.OnCheckStateChanged_44F4DA87B54E82F7F33A3D85B0000E86
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10176f770
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnCheckStateChanged_44F4DA87B54E82F7F33A3D85B0000E86(bool bIsChecked);

	// Object: Function UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.OnHide
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x101785338
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnHide();

	// Object: Function UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.OnShow
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x101785338
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnShow();

	// Object: Function UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.OnInitialized
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x101785338
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnInitialized();

	// Object: Function UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.ConstructCopy
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(0) Size(0x0) ]
	void ConstructCopy();

	// Object: Function UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.Destruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x101785338
	// Return & Params: [ Num(0) Size(0x0) ]
	void Destruct();

	// Object: Function UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();

	// Object: Function UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.SetIsSelf
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetIsSelf(bool IsSelf);

	// Object: Function UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.SetNameColor
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetNameColor(int32_t Num);

	// Object: Function UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.SetBuffHighlight
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetBuffHighlight(bool IsHighlight);

	// Object: Function UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.SetHD
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetHD(bool IsHD);

	// Object: Function UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.SetStateQuitHD
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetStateQuitHD(enum class E_Type_State_Button StateQuitHD);

	// Object: Function UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.SetStatePlayernameHD
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetStatePlayernameHD(enum class E_Type_State_Button StatePlayernameHD);

	// Object: Function UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x101785338
	// Return & Params: [ Num(0) Size(0x0) ]
	void Construct();

	// Object: Function UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.ExecuteUbergraph_UI_Lobby_TeamMember_Operation
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_Lobby_TeamMember_Operation(int32_t EntryPoint);
};

