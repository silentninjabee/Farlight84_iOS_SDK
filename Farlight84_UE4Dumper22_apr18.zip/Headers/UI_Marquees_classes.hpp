#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Marquees.UI_Marquees_C
// Inherited Bytes: 0x490 | Struct Size: 0x4b0
struct UUI_Marquees_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x490 | Size: 0x8
	struct UImage* Img_BG; // Offset: 0x498 | Size: 0x8
	struct UCanvasPanel* Panel_Marquees; // Offset: 0x4a0 | Size: 0x8
	struct USolarTextBlock* Txt_Marquees; // Offset: 0x4a8 | Size: 0x8

	// Functions

	// Object: Function UI_Marquees.UI_Marquees_C.ReceiveTick
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x101785338
	// Return & Params: [ Num(2) Size(0x3c) ]
	void ReceiveTick(struct FGeometry& MyGeometry, float InDeltaTime);

	// Object: Function UI_Marquees.UI_Marquees_C.OnSolarUIOpened
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x101785338
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnSolarUIOpened();

	// Object: Function UI_Marquees.UI_Marquees_C.OnSolarUIClosed
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x101785338
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnSolarUIClosed();

	// Object: Function UI_Marquees.UI_Marquees_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x101785338
	// Return & Params: [ Num(0) Size(0x0) ]
	void Construct();

	// Object: Function UI_Marquees.UI_Marquees_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();

	// Object: Function UI_Marquees.UI_Marquees_C.Tick
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(2) Size(0x3c) ]
	void Tick(struct FGeometry MyGeometry, float InDeltaTime);

	// Object: Function UI_Marquees.UI_Marquees_C.ExecuteUbergraph_UI_Marquees
	// Flags: [Final|UbergraphFunction|HasDefaults]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_Marquees(int32_t EntryPoint);
};

