#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Notice_Top3Victory.UI_Notice_Top3Victory_C
// Inherited Bytes: 0x490 | Struct Size: 0x4e4
struct UUI_Notice_Top3Victory_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x490 | Size: 0x8
	struct UWidgetAnimation* Anim_Exit; // Offset: 0x498 | Size: 0x8
	struct UWidgetAnimation* Anim_Enter; // Offset: 0x4a0 | Size: 0x8
	struct USolarButton* Btn_Continue; // Offset: 0x4a8 | Size: 0x8
	struct UUI_Component_Btn_C* Btn_Exit; // Offset: 0x4b0 | Size: 0x8
	struct UTextBlock* Txt_CD; // Offset: 0x4b8 | Size: 0x8
	int32_t CDToDisappear; // Offset: 0x4c0 | Size: 0x4
	char pad_0x4C4[0x4]; // Offset: 0x4c4 | Size: 0x4
	struct FTimerHandle DisappearTimerHandle; // Offset: 0x4c8 | Size: 0x8
	int32_t CurDurationTime; // Offset: 0x4d0 | Size: 0x4
	struct FName TopTeamEscape; // Offset: 0x4d4 | Size: 0x8
	struct FName TopTeamCoutinue; // Offset: 0x4dc | Size: 0x8

	// Functions

	// Object: Function UI_Notice_Top3Victory.UI_Notice_Top3Victory_C.Finished_497153C24AA18B528A73B38092D5F8EC
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(0) Size(0x0) ]
	void Finished_497153C24AA18B528A73B38092D5F8EC();

	// Object: Function UI_Notice_Top3Victory.UI_Notice_Top3Victory_C.Finished_0712D09449752CBFBAB27D9A54CF9CDB
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(0) Size(0x0) ]
	void Finished_0712D09449752CBFBAB27D9A54CF9CDB();

	// Object: Function UI_Notice_Top3Victory.UI_Notice_Top3Victory_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(0) Size(0x0) ]
	void Construct();

	// Object: Function UI_Notice_Top3Victory.UI_Notice_Top3Victory_C.BndEvt__Btn_Exit_K2Node_ComponentBoundEvent_0_OnClicked__DelegateSignature
	// Flags: [BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(0) Size(0x0) ]
	void BndEvt__Btn_Exit_K2Node_ComponentBoundEvent_0_OnClicked__DelegateSignature();

	// Object: Function UI_Notice_Top3Victory.UI_Notice_Top3Victory_C.CustomEvent_1
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(0) Size(0x0) ]
	void CustomEvent_1();

	// Object: Function UI_Notice_Top3Victory.UI_Notice_Top3Victory_C.BndEvt__Btn_Continue_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature
	// Flags: [BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(0) Size(0x0) ]
	void BndEvt__Btn_Continue_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature();

	// Object: Function UI_Notice_Top3Victory.UI_Notice_Top3Victory_C.NotifyDisapppear
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(0) Size(0x0) ]
	void NotifyDisapppear();

	// Object: Function UI_Notice_Top3Victory.UI_Notice_Top3Victory_C.Top3
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(0) Size(0x0) ]
	void Top3();

	// Object: Function UI_Notice_Top3Victory.UI_Notice_Top3Victory_C.OnTopTeamEscape
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnTopTeamEscape();

	// Object: Function UI_Notice_Top3Victory.UI_Notice_Top3Victory_C.CustomEvent_2
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(0) Size(0x0) ]
	void CustomEvent_2();

	// Object: Function UI_Notice_Top3Victory.UI_Notice_Top3Victory_C.Destruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(0) Size(0x0) ]
	void Destruct();

	// Object: Function UI_Notice_Top3Victory.UI_Notice_Top3Victory_C.OnTopTeamContinue
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnTopTeamContinue();

	// Object: Function UI_Notice_Top3Victory.UI_Notice_Top3Victory_C.CustomEvent_3
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(0) Size(0x0) ]
	void CustomEvent_3();

	// Object: Function UI_Notice_Top3Victory.UI_Notice_Top3Victory_C.ExecuteUbergraph_UI_Notice_Top3Victory
	// Flags: [Final|UbergraphFunction|HasDefaults]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_Notice_Top3Victory(int32_t EntryPoint);
};

