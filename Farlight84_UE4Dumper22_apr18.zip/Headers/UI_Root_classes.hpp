#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Root.UI_Root_C
// Inherited Bytes: 0x490 | Struct Size: 0x524
struct UUI_Root_C : USolarUIRoot {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x490 | Size: 0x8
	struct UCanvasPanel* BattleNoticeRoot; // Offset: 0x498 | Size: 0x8
	struct UCanvasPanel* BattleRoot; // Offset: 0x4a0 | Size: 0x8
	struct UCanvasPanel* BattleRootGuide; // Offset: 0x4a8 | Size: 0x8
	struct UCanvasPanel* BattleRootOverlay; // Offset: 0x4b0 | Size: 0x8
	struct UCanvasPanel* CommonRoot; // Offset: 0x4b8 | Size: 0x8
	struct UCanvasPanel* ExternalToolsRoot; // Offset: 0x4c0 | Size: 0x8
	struct UCanvasPanel* Guide; // Offset: 0x4c8 | Size: 0x8
	struct UCanvasPanel* Loading; // Offset: 0x4d0 | Size: 0x8
	struct UCanvasPanel* Map; // Offset: 0x4d8 | Size: 0x8
	struct UCanvasPanel* MiddleRoot; // Offset: 0x4e0 | Size: 0x8
	struct UCanvasPanel* NoticeRoot; // Offset: 0x4e8 | Size: 0x8
	struct UCanvasPanel* PopRoot; // Offset: 0x4f0 | Size: 0x8
	struct UCanvasPanel* Reconnecting; // Offset: 0x4f8 | Size: 0x8
	struct UCanvasPanel* TipsRoot; // Offset: 0x500 | Size: 0x8
	struct UCanvasPanel* UnderBattleRoot; // Offset: 0x508 | Size: 0x8
	float AdapterOffsetLeft; // Offset: 0x510 | Size: 0x4
	float AdapterOffsetRight; // Offset: 0x514 | Size: 0x4
	bool EnableAutoAdaptation; // Offset: 0x518 | Size: 0x1
	char pad_0x519[0x3]; // Offset: 0x519 | Size: 0x3
	float AdapterOffsetLeftDesktop; // Offset: 0x51c | Size: 0x4
	float AdapterOffsetRightDesktop; // Offset: 0x520 | Size: 0x4

	// Functions

	// Object: Function UI_Root.UI_Root_C.OnInitialized
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x101785338
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnInitialized();

	// Object: Function UI_Root.UI_Root_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x101785338
	// Return & Params: [ Num(0) Size(0x0) ]
	void Construct();

	// Object: Function UI_Root.UI_Root_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();

	// Object: Function UI_Root.UI_Root_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_Root.UI_Root_C.CustomEvent_1
	// Flags: [HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(3) Size(0x20) ]
	void CustomEvent_1(struct UObject* Publisher, struct UObject* Payload, struct TArray<struct FString>& MetaData);

	// Object: Function UI_Root.UI_Root_C.ExecuteUbergraph_UI_Root
	// Flags: [Final|UbergraphFunction|HasDefaults]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_Root(int32_t EntryPoint);
};

