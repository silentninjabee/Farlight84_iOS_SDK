#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_SeasonRank_NewSeason.UI_SeasonRank_NewSeason_C
// Inherited Bytes: 0x490 | Struct Size: 0x5a2
struct UUI_SeasonRank_NewSeason_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x490 | Size: 0x8
	struct UWidgetAnimation* Anim_Skin_Out; // Offset: 0x498 | Size: 0x8
	struct UWidgetAnimation* Anim_Skin_Enter; // Offset: 0x4a0 | Size: 0x8
	struct UWidgetAnimation* Anim_Rank_Enter; // Offset: 0x4a8 | Size: 0x8
	struct UWidgetAnimation* Anim_NewSeason_Loop; // Offset: 0x4b0 | Size: 0x8
	struct UWidgetAnimation* Anim_NewSeason_Enter; // Offset: 0x4b8 | Size: 0x8
	struct UButton* Btn_Continue; // Offset: 0x4c0 | Size: 0x8
	struct UButton* Btn_Start_Season; // Offset: 0x4c8 | Size: 0x8
	struct UCanvasPanel* CanvasPanel_Begin; // Offset: 0x4d0 | Size: 0x8
	struct UCanvasPanel* CanvasPanel_Continue; // Offset: 0x4d8 | Size: 0x8
	struct UCanvasPanel* CanvasPanel_Rank; // Offset: 0x4e0 | Size: 0x8
	struct UCanvasPanel* CanvasPanel_Skin; // Offset: 0x4e8 | Size: 0x8
	struct UImage* Img_Advanced_BG; // Offset: 0x4f0 | Size: 0x8
	struct UImage* Img_Advanced_Skin; // Offset: 0x4f8 | Size: 0x8
	struct UImage* Img_Foundation_BG; // Offset: 0x500 | Size: 0x8
	struct UImage* Img_Foundation_Skin; // Offset: 0x508 | Size: 0x8
	struct UCanvasPanel* Panel_Advanced; // Offset: 0x510 | Size: 0x8
	struct UCanvasPanel* Panel_Advanced_Skin_BG; // Offset: 0x518 | Size: 0x8
	struct UCanvasPanel* Panel_Foundation; // Offset: 0x520 | Size: 0x8
	struct UCanvasPanel* Panel_Foundation_Skin_BG; // Offset: 0x528 | Size: 0x8
	struct UCanvasPanel* Panel_Start_Season; // Offset: 0x530 | Size: 0x8
	struct USizeBox* SizeBox_Mark; // Offset: 0x538 | Size: 0x8
	struct UWidgetSwitcher* Switcher_Season_Rank; // Offset: 0x540 | Size: 0x8
	struct USolarTextBlock* Txt_Advanced_CharacterName; // Offset: 0x548 | Size: 0x8
	struct USolarTextBlock* Txt_Advanced_SkinName; // Offset: 0x550 | Size: 0x8
	struct USolarTextBlock* Txt_Foundation_CharacterName; // Offset: 0x558 | Size: 0x8
	struct USolarTextBlock* Txt_Foundation_SkinName; // Offset: 0x560 | Size: 0x8
	struct USolarTextBlock* Txt_FullName_Big; // Offset: 0x568 | Size: 0x8
	struct USolarTextBlock* Txt_FullName_Small; // Offset: 0x570 | Size: 0x8
	struct USolarTextBlock* Txt_RankLevel; // Offset: 0x578 | Size: 0x8
	struct USolarTextBlock* Txt_ShortName_Big; // Offset: 0x580 | Size: 0x8
	struct USolarTextBlock* Txt_ShortName_Small; // Offset: 0x588 | Size: 0x8
	struct UUI_Component_SeasonImprint_C* UI_Component_SeasonImprint; // Offset: 0x590 | Size: 0x8
	struct UUI_Rank_Icon_C* UI_Rank_Icon; // Offset: 0x598 | Size: 0x8
	enum class E_Item_Quality BasicQuality; // Offset: 0x5a0 | Size: 0x1
	enum class E_Item_Quality AdvancedQuality; // Offset: 0x5a1 | Size: 0x1

	// Functions

	// Object: DelegateFunction UI_SeasonRank_NewSeason.UI_SeasonRank_NewSeason_C.Delegate_30E45B294A44EF77903594AF02EDE320
	// Flags: [Public|Delegate]
	// Offset: 0x10176f770
	// Return & Params: [ Num(0) Size(0x0) ]
	void Delegate_30E45B294A44EF77903594AF02EDE320();

	// Object: DelegateFunction UI_SeasonRank_NewSeason.UI_SeasonRank_NewSeason_C.Delegate_1F2BCE98D5457F66F0FF2AADDC4ABFB0
	// Flags: [Public|Delegate]
	// Offset: 0x10176f770
	// Return & Params: [ Num(0) Size(0x0) ]
	void Delegate_1F2BCE98D5457F66F0FF2AADDC4ABFB0();

	// Object: DelegateFunction UI_SeasonRank_NewSeason.UI_SeasonRank_NewSeason_C.Delegate_C03717B1EC4F1F2C3B24E698A7DCA3D4
	// Flags: [Public|Delegate]
	// Offset: 0x10176f770
	// Return & Params: [ Num(0) Size(0x0) ]
	void Delegate_C03717B1EC4F1F2C3B24E698A7DCA3D4();

	// Object: DelegateFunction UI_SeasonRank_NewSeason.UI_SeasonRank_NewSeason_C.Delegate_98291A2B5E40F8CA5188B4ADC27F6557
	// Flags: [Public|Delegate]
	// Offset: 0x10176f770
	// Return & Params: [ Num(0) Size(0x0) ]
	void Delegate_98291A2B5E40F8CA5188B4ADC27F6557();

	// Object: DelegateFunction UI_SeasonRank_NewSeason.UI_SeasonRank_NewSeason_C.OnClicked_CC8FFB427C4FD2993302FB909E71073F
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10176f770
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_CC8FFB427C4FD2993302FB909E71073F();

	// Object: DelegateFunction UI_SeasonRank_NewSeason.UI_SeasonRank_NewSeason_C.OnClicked_ECEE6400384967C2EE26E2B656D4C2BA
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x10176f770
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_ECEE6400384967C2EE26E2B656D4C2BA();

	// Object: Function UI_SeasonRank_NewSeason.UI_SeasonRank_NewSeason_C.OnSolarUIOpened
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x101785338
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnSolarUIOpened();

	// Object: Function UI_SeasonRank_NewSeason.UI_SeasonRank_NewSeason_C.OnRankChangeLuaCallCopy
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnRankChangeLuaCallCopy();

	// Object: Function UI_SeasonRank_NewSeason.UI_SeasonRank_NewSeason_C.OnInitialized
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x101785338
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnInitialized();

	// Object: Function UI_SeasonRank_NewSeason.UI_SeasonRank_NewSeason_C.OnImprintActiveLuaCallCopy
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnImprintActiveLuaCallCopy();

	// Object: Function UI_SeasonRank_NewSeason.UI_SeasonRank_NewSeason_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();

	// Object: Function UI_SeasonRank_NewSeason.UI_SeasonRank_NewSeason_C.SequenceEvent__ENTRYPOINTUI_SeasonRank_NewSeason_2
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(0) Size(0x0) ]
	void SequenceEvent__ENTRYPOINTUI_SeasonRank_NewSeason_2();

	// Object: Function UI_SeasonRank_NewSeason.UI_SeasonRank_NewSeason_C.SequenceEvent__ENTRYPOINTUI_SeasonRank_NewSeason_1
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(0) Size(0x0) ]
	void SequenceEvent__ENTRYPOINTUI_SeasonRank_NewSeason_1();

	// Object: Function UI_SeasonRank_NewSeason.UI_SeasonRank_NewSeason_C.OnRankChangeLuaCall
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101785338
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnRankChangeLuaCall();

	// Object: Function UI_SeasonRank_NewSeason.UI_SeasonRank_NewSeason_C.SetImagesQualityColor
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(2) Size(0x9) ]
	void SetImagesQualityColor(struct UPanelWidget* Target, enum class E_Item_Quality Index);

	// Object: Function UI_SeasonRank_NewSeason.UI_SeasonRank_NewSeason_C.OnImprintActiveLuaCall
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101785338
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnImprintActiveLuaCall();

	// Object: Function UI_SeasonRank_NewSeason.UI_SeasonRank_NewSeason_C.SetAdvancedSkinQuality
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetAdvancedSkinQuality(enum class E_Item_Quality AdvancedQuality);

	// Object: Function UI_SeasonRank_NewSeason.UI_SeasonRank_NewSeason_C.SetBasicSkinQuality
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetBasicSkinQuality(enum class E_Item_Quality BasicQuality);

	// Object: Function UI_SeasonRank_NewSeason.UI_SeasonRank_NewSeason_C.OnImprintActive
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnImprintActive();

	// Object: Function UI_SeasonRank_NewSeason.UI_SeasonRank_NewSeason_C.OnRankChange
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnRankChange();

	// Object: Function UI_SeasonRank_NewSeason.UI_SeasonRank_NewSeason_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_SeasonRank_NewSeason.UI_SeasonRank_NewSeason_C.ExecuteUbergraph_UI_SeasonRank_NewSeason
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_SeasonRank_NewSeason(int32_t EntryPoint);
};

