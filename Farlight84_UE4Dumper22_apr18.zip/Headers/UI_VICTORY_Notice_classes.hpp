#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_VICTORY_Notice.UI_VICTORY_Notice_C
// Inherited Bytes: 0x4e8 | Struct Size: 0x510
struct UUI_VICTORY_Notice_C : UUINoticeBase {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x4e8 | Size: 0x8
	struct USolarAdapterWidget* NoticeVICTORY; // Offset: 0x4f0 | Size: 0x8
	struct USafeZone* SafeZone_1; // Offset: 0x4f8 | Size: 0x8
	struct FMulticastInlineDelegate OnEnablePlayerInput; // Offset: 0x500 | Size: 0x10

	// Functions

	// Object: Function UI_VICTORY_Notice.UI_VICTORY_Notice_C.Get Actual UICount Down Time
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x4) ]
	void Get Actual UICount Down Time(float& CountDownTime);

	// Object: Function UI_VICTORY_Notice.UI_VICTORY_Notice_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(0) Size(0x0) ]
	void Construct();

	// Object: Function UI_VICTORY_Notice.UI_VICTORY_Notice_C.OnSolarUIOpened
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnSolarUIOpened();

	// Object: Function UI_VICTORY_Notice.UI_VICTORY_Notice_C.EV_OnAppearAnimFinished
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(0) Size(0x0) ]
	void EV_OnAppearAnimFinished();

	// Object: Function UI_VICTORY_Notice.UI_VICTORY_Notice_C.ExecuteUbergraph_UI_VICTORY_Notice
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_VICTORY_Notice(int32_t EntryPoint);

	// Object: Function UI_VICTORY_Notice.UI_VICTORY_Notice_C.OnEnablePlayerInput__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnEnablePlayerInput__DelegateSignature();
};

