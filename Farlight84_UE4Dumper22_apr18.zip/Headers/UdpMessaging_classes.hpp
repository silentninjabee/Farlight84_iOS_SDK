#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class UdpMessaging.UdpMessagingSettings
// Inherited Bytes: 0x28 | Struct Size: 0xa0
struct UUdpMessagingSettings : UObject {
	// Fields
	bool EnableTransport; // Offset: 0x28 | Size: 0x1
	bool bAutoRepair; // Offset: 0x29 | Size: 0x1
	bool bStopServiceWhenAppDeactivates; // Offset: 0x2a | Size: 0x1
	char pad_0x2B[0x5]; // Offset: 0x2b | Size: 0x5
	struct FString UnicastEndpoint; // Offset: 0x30 | Size: 0x10
	struct FString MulticastEndpoint; // Offset: 0x40 | Size: 0x10
	enum class EUdpMessageFormat MessageFormat; // Offset: 0x50 | Size: 0x1
	char MulticastTimeToLive; // Offset: 0x51 | Size: 0x1
	char pad_0x52[0x6]; // Offset: 0x52 | Size: 0x6
	struct TArray<struct FString> StaticEndpoints; // Offset: 0x58 | Size: 0x10
	bool EnableTunnel; // Offset: 0x68 | Size: 0x1
	char pad_0x69[0x7]; // Offset: 0x69 | Size: 0x7
	struct FString TunnelUnicastEndpoint; // Offset: 0x70 | Size: 0x10
	struct FString TunnelMulticastEndpoint; // Offset: 0x80 | Size: 0x10
	struct TArray<struct FString> RemoteTunnelEndpoints; // Offset: 0x90 | Size: 0x10
};

