#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class UnLua.UnLuaInterface
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UUnLuaInterface : UInterface {
	// Functions

	// Object: Function UnLua.UnLuaInterface.GetModuleName
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x10181808c
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();
};

// Object: Class UnLua.UnLuaManager
// Inherited Bytes: 0x28 | Struct Size: 0x5b8
struct UUnLuaManager : UObject {
	// Fields
	char pad_0x28[0x590]; // Offset: 0x28 | Size: 0x590

	// Functions

	// Object: Function UnLua.UnLuaManager.TriggerAnimNotify
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(0) Size(0x0) ]
	void TriggerAnimNotify();

	// Object: Function UnLua.UnLuaManager.OnLatentActionCompleted
	// Flags: [Final|Native|Public]
	// Offset: 0x1018184d8
	// Return & Params: [ Num(1) Size(0x4) ]
	void OnLatentActionCompleted(int32_t LinkID);

	// Object: Function UnLua.UnLuaManager.OnActorDestroyed
	// Flags: [Final|Native|Public]
	// Offset: 0x101818558
	// Return & Params: [ Num(1) Size(0x8) ]
	void OnActorDestroyed(struct AActor* Actor);

	// Object: Function UnLua.UnLuaManager.InputVectorAxis
	// Flags: [Event|Public|HasOutParms|HasDefaults|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0xc) ]
	void InputVectorAxis(struct FVector& AxisValue);

	// Object: Function UnLua.UnLuaManager.InputTouch
	// Flags: [Event|Public|HasOutParms|HasDefaults|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(2) Size(0x10) ]
	void InputTouch(enum class ETouchIndex FingerIndex, struct FVector& Location);

	// Object: Function UnLua.UnLuaManager.InputGesture
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x4) ]
	void InputGesture(float Value);

	// Object: Function UnLua.UnLuaManager.InputAxis
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x4) ]
	void InputAxis(float AxisValue);

	// Object: Function UnLua.UnLuaManager.InputAction
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x18) ]
	void InputAction(struct FKey Key);
};

// Object: Class UnLua.UnLuaPerformanceTestProxy
// Inherited Bytes: 0x230 | Struct Size: 0x290
struct AUnLuaPerformanceTestProxy : AActor {
	// Fields
	char pad_0x230[0x8]; // Offset: 0x230 | Size: 0x8
	int32_t MeshID; // Offset: 0x238 | Size: 0x4
	char pad_0x23C[0x4]; // Offset: 0x23c | Size: 0x4
	struct FString MeshName; // Offset: 0x240 | Size: 0x10
	struct FVector COM; // Offset: 0x250 | Size: 0xc
	char pad_0x25C[0x4]; // Offset: 0x25c | Size: 0x4
	struct TArray<int32_t> Indices; // Offset: 0x260 | Size: 0x10
	struct TArray<struct FVector> Positions; // Offset: 0x270 | Size: 0x10
	struct TArray<struct FVector> PredictedPositions; // Offset: 0x280 | Size: 0x10

	// Functions

	// Object: Function UnLua.UnLuaPerformanceTestProxy.UpdatePositions
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101818d9c
	// Return & Params: [ Num(1) Size(0x10) ]
	void UpdatePositions(struct TArray<struct FVector>& NewPositions);

	// Object: Function UnLua.UnLuaPerformanceTestProxy.UpdateMeshName
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1018190e8
	// Return & Params: [ Num(2) Size(0x20) ]
	struct FString UpdateMeshName(struct FString NewName);

	// Object: Function UnLua.UnLuaPerformanceTestProxy.UpdateMeshID
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1018191bc
	// Return & Params: [ Num(2) Size(0x8) ]
	int32_t UpdateMeshID(int32_t NewId);

	// Object: Function UnLua.UnLuaPerformanceTestProxy.UpdateIndices
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101818ecc
	// Return & Params: [ Num(1) Size(0x10) ]
	void UpdateIndices(struct TArray<int32_t>& NewIndices);

	// Object: Function UnLua.UnLuaPerformanceTestProxy.Simulate
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101819344
	// Return & Params: [ Num(1) Size(0x4) ]
	void Simulate(float DeltaTime);

	// Object: Function UnLua.UnLuaPerformanceTestProxy.Raycast
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x101818ffc
	// Return & Params: [ Num(3) Size(0x19) ]
	bool Raycast(struct FVector& Origin, struct FVector& Direction);

	// Object: Function UnLua.UnLuaPerformanceTestProxy.NOP
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1018193c4
	// Return & Params: [ Num(0) Size(0x0) ]
	void NOP();

	// Object: Function UnLua.UnLuaPerformanceTestProxy.GetPredictedPositions
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x101818d14
	// Return & Params: [ Num(1) Size(0x10) ]
	struct TArray<struct FVector> GetPredictedPositions();

	// Object: Function UnLua.UnLuaPerformanceTestProxy.GetPositions
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x101818e34
	// Return & Params: [ Num(1) Size(0x10) ]
	void GetPositions(struct TArray<struct FVector>& OutPositions);

	// Object: Function UnLua.UnLuaPerformanceTestProxy.GetMeshName
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10181928c
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetMeshName();

	// Object: Function UnLua.UnLuaPerformanceTestProxy.GetMeshInfo
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x101818aac
	// Return & Params: [ Num(7) Size(0x59) ]
	bool GetMeshInfo(int32_t& OutMeshID, struct FString& OutMeshName, struct FVector& OutCOM, struct TArray<int32_t>& OutIndices, struct TArray<struct FVector>& OutPositions, struct TArray<struct FVector>& OutPredictedPositions);

	// Object: Function UnLua.UnLuaPerformanceTestProxy.GetMeshID
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x101819310
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetMeshID();

	// Object: Function UnLua.UnLuaPerformanceTestProxy.GetIndices
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x101818f64
	// Return & Params: [ Num(1) Size(0x10) ]
	void GetIndices(struct TArray<int32_t>& OutIndices);

	// Object: Function UnLua.UnLuaPerformanceTestProxy.GetCOM
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10181924c
	// Return & Params: [ Num(1) Size(0xc) ]
	struct FVector GetCOM();
};

