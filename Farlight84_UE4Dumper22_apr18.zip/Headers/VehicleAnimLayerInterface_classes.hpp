#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: DynamicClass VehicleAnimLayerInterface.VehicleAnimLayerInterface_C
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UVehicleAnimLayerInterface_C : UAnimLayerInterface {
	// Functions

	// Object: Function VehicleAnimLayerInterface.VehicleAnimLayerInterface_C.VehicleLocamotion
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x104039718
	// Return & Params: [ Num(1) Size(0x10) ]
	void VehicleLocamotion(struct FPoseLink& bpp__VehicleLocamotion__pf);
};

