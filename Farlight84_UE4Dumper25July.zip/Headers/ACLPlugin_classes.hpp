#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class ACLPlugin.AnimationCompressionLibraryDatabase
// Inherited Bytes: 0x28 | Struct Size: 0x158
struct UAnimationCompressionLibraryDatabase : UObject {
	// Fields
	struct TArray<char> CookedCompressedBytes; // Offset: 0x28 | Size: 0x10
	struct TArray<uint64_t> CookedAnimSequenceMappings; // Offset: 0x38 | Size: 0x10
	char pad_0x48[0x108]; // Offset: 0x48 | Size: 0x108
	uint32_t MaxStreamRequestSizeKB; // Offset: 0x150 | Size: 0x4
	char pad_0x154[0x4]; // Offset: 0x154 | Size: 0x4

	// Functions

	// Object: Function ACLPlugin.AnimationCompressionLibraryDatabase.SetVisualFidelity
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x103393aa4
	// Return & Params: [ Num(5) Size(0x2a) ]
	void SetVisualFidelity(struct UObject* WorldContextObject, struct FLatentActionInfo LatentInfo, struct UAnimationCompressionLibraryDatabase* DatabaseAsset, enum class ACLVisualFidelityChangeResult& Result, enum class ACLVisualFidelity VisualFidelity);

	// Object: Function ACLPlugin.AnimationCompressionLibraryDatabase.GetVisualFidelity
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x103393a24
	// Return & Params: [ Num(2) Size(0x9) ]
	enum class ACLVisualFidelity GetVisualFidelity(struct UAnimationCompressionLibraryDatabase* DatabaseAsset);
};

// Object: Class ACLPlugin.AnimBoneCompressionCodec_ACLBase
// Inherited Bytes: 0x38 | Struct Size: 0x38
struct UAnimBoneCompressionCodec_ACLBase : UAnimBoneCompressionCodec {
};

// Object: Class ACLPlugin.AnimBoneCompressionCodec_ACL
// Inherited Bytes: 0x38 | Struct Size: 0x40
struct UAnimBoneCompressionCodec_ACL : UAnimBoneCompressionCodec_ACLBase {
	// Fields
	struct UAnimBoneCompressionCodec* SafetyFallbackCodec; // Offset: 0x38 | Size: 0x8
};

// Object: Class ACLPlugin.AnimBoneCompressionCodec_ACLCustom
// Inherited Bytes: 0x38 | Struct Size: 0x38
struct UAnimBoneCompressionCodec_ACLCustom : UAnimBoneCompressionCodec_ACLBase {
};

// Object: Class ACLPlugin.AnimBoneCompressionCodec_ACLDatabase
// Inherited Bytes: 0x38 | Struct Size: 0x40
struct UAnimBoneCompressionCodec_ACLDatabase : UAnimBoneCompressionCodec_ACLBase {
	// Fields
	struct UAnimationCompressionLibraryDatabase* DatabaseAsset; // Offset: 0x38 | Size: 0x8
};

// Object: Class ACLPlugin.AnimBoneCompressionCodec_ACLSafe
// Inherited Bytes: 0x38 | Struct Size: 0x38
struct UAnimBoneCompressionCodec_ACLSafe : UAnimBoneCompressionCodec_ACLBase {
};

// Object: Class ACLPlugin.AnimCurveCompressionCodec_ACL
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UAnimCurveCompressionCodec_ACL : UAnimCurveCompressionCodec {
};

