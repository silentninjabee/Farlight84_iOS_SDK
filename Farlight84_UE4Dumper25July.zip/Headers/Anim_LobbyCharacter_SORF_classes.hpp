#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: DynamicClass Anim_LobbyCharacter_SORF.Anim_LobbyCharacter_SORF_C
// Inherited Bytes: 0xa50 | Struct Size: 0xa50
struct UAnim_LobbyCharacter_SORF_C : UAnim_LobbyCharacter_Default_C {
};

