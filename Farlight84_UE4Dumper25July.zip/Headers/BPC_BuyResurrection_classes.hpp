#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BPC_BuyResurrection.BPC_BuyResurrection_C
// Inherited Bytes: 0x190 | Struct Size: 0x1c4
struct UBPC_BuyResurrection_C : USolarResurrectionComponent {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x190 | Size: 0x8
	struct UUI_BuyResurrectionPanel_C* UI_BuyResurrectionPanel; // Offset: 0x198 | Size: 0x8
	struct ABP_ReviveItemManger_BattleRoyale_C* ReviveItemManger; // Offset: 0x1a0 | Size: 0x8
	int32_t SuccessTime; // Offset: 0x1a8 | Size: 0x4
	bool BuyResurrectionSwitch; // Offset: 0x1ac | Size: 0x1
	char pad_0x1AD[0x3]; // Offset: 0x1ad | Size: 0x3
	float RemindTeammateEffectCooldown; // Offset: 0x1b0 | Size: 0x4
	float BuyResurrectionInvincibleTime; // Offset: 0x1b4 | Size: 0x4
	struct FVector RebornLoc; // Offset: 0x1b8 | Size: 0xc

	// Functions

	// Object: Function BPC_BuyResurrection.BPC_BuyResurrection_C.CheckAllTeammateDied
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x1) ]
	void CheckAllTeammateDied(bool& IfAllDied);

	// Object: Function BPC_BuyResurrection.BPC_BuyResurrection_C.RefreshUI
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void RefreshUI();

	// Object: Function BPC_BuyResurrection.BPC_BuyResurrection_C.GetTeammatesArr
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x10) ]
	struct TArray<struct ASCMPlayerState*> GetTeammatesArr();

	// Object: Function BPC_BuyResurrection.BPC_BuyResurrection_C.On All Teammates Killed
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void On All Teammates Killed();

	// Object: Function BPC_BuyResurrection.BPC_BuyResurrection_C.Get Alive Team Player Num
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(2) Size(0xc) ]
	void Get Alive Team Player Num(struct ASCMPlayerState* OutPlayer, int32_t& Num);

	// Object: Function BPC_BuyResurrection.BPC_BuyResurrection_C.Show Buy Resurrection UI
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x1) ]
	void Show Buy Resurrection UI(bool Visible);

	// Object: Function BPC_BuyResurrection.BPC_BuyResurrection_C.Event_LeaveWhileWaiting
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void Event_LeaveWhileWaiting();

	// Object: Function BPC_BuyResurrection.BPC_BuyResurrection_C.ClientDoCameraFade
	// Flags: [Net|NetReliableNetClient|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void ClientDoCameraFade();

	// Object: Function BPC_BuyResurrection.BPC_BuyResurrection_C.Event_OnRevivingComplete
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x10) ]
	void Event_OnRevivingComplete(struct FString PlayerId);

	// Object: Function BPC_BuyResurrection.BPC_BuyResurrection_C.Event_OnRevivedComplete
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void Event_OnRevivedComplete();

	// Object: Function BPC_BuyResurrection.BPC_BuyResurrection_C.Event_OnResurrectionStateChanged
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x1) ]
	void Event_OnResurrectionStateChanged(enum class EResurrectionState LastState);

	// Object: Function BPC_BuyResurrection.BPC_BuyResurrection_C.OnReviveSelf
	// Flags: [Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(2) Size(0x10) ]
	void OnReviveSelf(bool bOverrideLocation, struct FVector& ReviveLocation);

	// Object: Function BPC_BuyResurrection.BPC_BuyResurrection_C.ExecuteUbergraph_BPC_BuyResurrection
	// Flags: [Final|UbergraphFunction|HasDefaults]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_BPC_BuyResurrection(int32_t EntryPoint);
};

