#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BPC_EXPSpringGameComponent.BPC_EXPSpringGameComponent_C
// Inherited Bytes: 0x248 | Struct Size: 0x248
struct UBPC_EXPSpringGameComponent_C : USolarExpSpringGameComponent {
};

