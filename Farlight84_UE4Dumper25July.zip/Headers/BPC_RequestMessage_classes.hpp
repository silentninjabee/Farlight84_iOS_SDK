#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BPC_RequestMessage.BPC_RequestMessage_C
// Inherited Bytes: 0xc0 | Struct Size: 0x140
struct UBPC_RequestMessage_C : UActorComponent {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0xc0 | Size: 0x8
	struct TMap<struct FString, struct UBP_MessageObj_C*> Queryer; // Offset: 0xc8 | Size: 0x50
	struct FMulticastInlineDelegate OnReceiveRequest; // Offset: 0x118 | Size: 0x10
	struct FMulticastInlineDelegate OnGetReply; // Offset: 0x128 | Size: 0x10
	struct ABP_RequestMessage_C* CommonMessageManager; // Offset: 0x138 | Size: 0x8

	// Functions

	// Object: Function BPC_RequestMessage.BPC_RequestMessage_C.GetOwnerPlayerID
	// Flags: [Private|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x4) ]
	void GetOwnerPlayerID(int32_t& PlayerId);

	// Object: Function BPC_RequestMessage.BPC_RequestMessage_C.ToMessageInfo
	// Flags: [Private|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(2) Size(0x1c) ]
	void ToMessageInfo(struct FString Key, struct FS_MessageRequest& MessageInfo);

	// Object: Function BPC_RequestMessage.BPC_RequestMessage_C.ToString
	// Flags: [Private|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(2) Size(0x20) ]
	void ToString(struct FS_MessageRequest MessageInfo, struct FString& Key);

	// Object: Function BPC_RequestMessage.BPC_RequestMessage_C.ReceiveBeginPlay
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void ReceiveBeginPlay();

	// Object: Function BPC_RequestMessage.BPC_RequestMessage_C.ReceiveRequest
	// Flags: [Net|NetClient|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0xc) ]
	void ReceiveRequest(struct FS_MessageRequest Info);

	// Object: Function BPC_RequestMessage.BPC_RequestMessage_C.SendReply
	// Flags: [Net|NetClient|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(2) Size(0xd) ]
	void SendReply(struct FS_MessageRequest Info, bool Reply);

	// Object: Function BPC_RequestMessage.BPC_RequestMessage_C.ExecuteUbergraph_BPC_RequestMessage
	// Flags: [Final|UbergraphFunction|HasDefaults]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_BPC_RequestMessage(int32_t EntryPoint);

	// Object: Function BPC_RequestMessage.BPC_RequestMessage_C.OnGetReply__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(4) Size(0x18) ]
	void OnGetReply__DelegateSignature(struct FString Handle, bool Reply, char Type, int32_t ReplierPlayerID);

	// Object: Function BPC_RequestMessage.BPC_RequestMessage_C.OnReceiveRequest__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(3) Size(0x18) ]
	void OnReceiveRequest__DelegateSignature(struct FString Handle, char Type, int32_t SenderPlayerID);
};

