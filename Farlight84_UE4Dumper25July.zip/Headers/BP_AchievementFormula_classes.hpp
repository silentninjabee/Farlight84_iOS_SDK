#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_AchievementFormula.BP_AchievementFormula_C
// Inherited Bytes: 0x248 | Struct Size: 0x250
struct ABP_AchievementFormula_C : AAchievementFormula {
	// Fields
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x248 | Size: 0x8

	// Functions

	// Object: Function BP_AchievementFormula.BP_AchievementFormula_C.AchAdvancedWeapon
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x4) ]
	void AchAdvancedWeapon(int32_t AchievementID);

	// Object: Function BP_AchievementFormula.BP_AchievementFormula_C. AchTBubbleKill
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x4) ]
	void  AchTBubbleKill(int32_t AchievementID);

	// Object: Function BP_AchievementFormula.BP_AchievementFormula_C.AchTAirSpeed
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x4) ]
	void AchTAirSpeed(int32_t AchievementID);

	// Object: Function BP_AchievementFormula.BP_AchievementFormula_C.AchTAirTrapeze
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x4) ]
	void AchTAirTrapeze(int32_t AchievementID);

	// Object: Function BP_AchievementFormula.BP_AchievementFormula_C.AchTAirUmbrella
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x4) ]
	void AchTAirUmbrella(int32_t AchievementID);

	// Object: Function BP_AchievementFormula.BP_AchievementFormula_C.AchTRevengeKill
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x4) ]
	void AchTRevengeKill(int32_t AchievementID);

	// Object: Function BP_AchievementFormula.BP_AchievementFormula_C.AchTBombingDie
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x4) ]
	void AchTBombingDie(int32_t AchievementID);

	// Object: Function BP_AchievementFormula.BP_AchievementFormula_C.AchTFistKill 
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x4) ]
	void AchTFistKill (int32_t AchievementID);

	// Object: Function BP_AchievementFormula.BP_AchievementFormula_C.AchTMarsWin
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x4) ]
	void AchTMarsWin(int32_t AchievementID);

	// Object: Function BP_AchievementFormula.BP_AchievementFormula_C.AchTDie
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x4) ]
	void AchTDie(int32_t AchievementID);

	// Object: Function BP_AchievementFormula.BP_AchievementFormula_C.AchTenemyVehicle
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x4) ]
	void AchTenemyVehicle(int32_t AchievementID);

	// Object: Function BP_AchievementFormula.BP_AchievementFormula_C.AchTOpenBoxNum
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x4) ]
	void AchTOpenBoxNum(int32_t AchievementID);

	// Object: Function BP_AchievementFormula.BP_AchievementFormula_C.AchTBlindSniper
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x4) ]
	void AchTBlindSniper(int32_t AchievementID);

	// Object: Function BP_AchievementFormula.BP_AchievementFormula_C.AchTFirstKill
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x4) ]
	void AchTFirstKill(int32_t AchievementID);

	// Object: Function BP_AchievementFormula.BP_AchievementFormula_C.AchTOnlyLiveWin
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x4) ]
	void AchTOnlyLiveWin(int32_t AchievementID);

	// Object: Function BP_AchievementFormula.BP_AchievementFormula_C.AchTSkyKill
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x4) ]
	void AchTSkyKill(int32_t AchievementID);

	// Object: Function BP_AchievementFormula.BP_AchievementFormula_C.AchTRescue
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x4) ]
	void AchTRescue(int32_t AchievementID);

	// Object: Function BP_AchievementFormula.BP_AchievementFormula_C.AchTAssistWin
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x4) ]
	void AchTAssistWin(int32_t AchievementID);

	// Object: Function BP_AchievementFormula.BP_AchievementFormula_C.AchTDyingWin
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x4) ]
	void AchTDyingWin(int32_t AchievementID);

	// Object: Function BP_AchievementFormula.BP_AchievementFormula_C. AchTLimitWin
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x4) ]
	void  AchTLimitWin(int32_t AchievementID);

	// Object: Function BP_AchievementFormula.BP_AchievementFormula_C.GetSolarGameState
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x8) ]
	void GetSolarGameState(struct ASolarGameState*& Out);

	// Object: Function BP_AchievementFormula.BP_AchievementFormula_C.GetPlayerData
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x8) ]
	void GetPlayerData(struct UPlayerStatisticsData*& Out);

	// Object: Function BP_AchievementFormula.BP_AchievementFormula_C.GetAchievement
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x8) ]
	void GetAchievement(struct USolarAchievementComponent*& AchievementComponent);

	// Object: Function BP_AchievementFormula.BP_AchievementFormula_C.GetSolarPlayerState
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x8) ]
	void GetSolarPlayerState(struct ASolarPlayerState*& OutResult);

	// Object: Function BP_AchievementFormula.BP_AchievementFormula_C. AchTHPKill
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x4) ]
	void  AchTHPKill(int32_t AchievementID);

	// Object: Function BP_AchievementFormula.BP_AchievementFormula_C.AchTUseVehicle
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x4) ]
	void AchTUseVehicle(int32_t AchievementID);

	// Object: Function BP_AchievementFormula.BP_AchievementFormula_C.AchTMinuteKill
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x4) ]
	void AchTMinuteKill(int32_t AchievementID);
};

