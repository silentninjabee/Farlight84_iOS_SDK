#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_BotAIController.BP_BotAIController_C
// Inherited Bytes: 0x870 | Struct Size: 0x880
struct ABP_BotAIController_C : ASolarBotAIController {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x870 | Size: 0x8
	struct UObject* NewVar_1; // Offset: 0x878 | Size: 0x8

	// Functions

	// Object: Function BP_BotAIController.BP_BotAIController_C.SetWarmGameClock
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetWarmGameClock(bool Enable);

	// Object: Function BP_BotAIController.BP_BotAIController_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();

	// Object: Function BP_BotAIController.BP_BotAIController_C.ReceiveBeginPlay
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void ReceiveBeginPlay();

	// Object: Function BP_BotAIController.BP_BotAIController_C.ReceiveTick
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x4) ]
	void ReceiveTick(float DeltaSeconds);

	// Object: Function BP_BotAIController.BP_BotAIController_C.ExecuteUbergraph_BP_BotAIController
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_BP_BotAIController(int32_t EntryPoint);
};

