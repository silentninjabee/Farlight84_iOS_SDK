#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_BotGameplayManager.BP_BotGameplayManager_C
// Inherited Bytes: 0x50 | Struct Size: 0x50
struct UBP_BotGameplayManager_C : USolarBotGameplayTaskManager {
};

