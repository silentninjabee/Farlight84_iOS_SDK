#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_DissolvedDeathController.BP_DissolvedDeathController_C
// Inherited Bytes: 0x40 | Struct Size: 0x40
struct UBP_DissolvedDeathController_C : UTimedEffectController {
};

