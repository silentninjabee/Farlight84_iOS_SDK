#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_DissolvedDeath.BP_DissolvedDeath_C
// Inherited Bytes: 0x240 | Struct Size: 0x240
struct UBP_DissolvedDeath_C : UMaterialVariableEffect {
};

