#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_GameState_BattleRoyale.BP_GameState_BattleRoyale_C
// Inherited Bytes: 0x9e0 | Struct Size: 0xa50
struct ABP_GameState_BattleRoyale_C : ABattleRoyaleGameState {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x9e0 | Size: 0x8
	struct UBPC_PlayerManager_C* BPC_PlayerManager; // Offset: 0x9e8 | Size: 0x8
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x9f0 | Size: 0x8
	int32_t mapID; // Offset: 0x9f8 | Size: 0x4
	int32_t AirlineID; // Offset: 0x9fc | Size: 0x4
	enum class E_BattleState_BattleRoyale BattleState; // Offset: 0xa00 | Size: 0x1
	char pad_0xA01[0x7]; // Offset: 0xa01 | Size: 0x7
	struct FMulticastInlineDelegate BroadcastBattleStateChange; // Offset: 0xa08 | Size: 0x10
	struct FString WinTeam; // Offset: 0xa18 | Size: 0x10
	bool HasTop3Team; // Offset: 0xa28 | Size: 0x1
	char pad_0xA29[0x7]; // Offset: 0xa29 | Size: 0x7
	struct FMulticastInlineDelegate OnBasicSystemReady_1; // Offset: 0xa30 | Size: 0x10
	struct FMulticastInlineDelegate OnGameStateChanged; // Offset: 0xa40 | Size: 0x10

	// Functions

	// Object: Function BP_GameState_BattleRoyale.BP_GameState_BattleRoyale_C.CloseEmptyVictoryUI
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void CloseEmptyVictoryUI();

	// Object: Function BP_GameState_BattleRoyale.BP_GameState_BattleRoyale_C.OnRep_HasTop3Team
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnRep_HasTop3Team();

	// Object: Function BP_GameState_BattleRoyale.BP_GameState_BattleRoyale_C.ShowEmptyVictoryUI
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void ShowEmptyVictoryUI();

	// Object: Function BP_GameState_BattleRoyale.BP_GameState_BattleRoyale_C.OnRep_WinTeam
	// Flags: [HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnRep_WinTeam();

	// Object: Function BP_GameState_BattleRoyale.BP_GameState_BattleRoyale_C.ShowVictoryUI
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void ShowVictoryUI();

	// Object: Function BP_GameState_BattleRoyale.BP_GameState_BattleRoyale_C.OnRep_BattleState
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnRep_BattleState();

	// Object: Function BP_GameState_BattleRoyale.BP_GameState_BattleRoyale_C.OnRep_MapID
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnRep_MapID();

	// Object: Function BP_GameState_BattleRoyale.BP_GameState_BattleRoyale_C.ReceiveBeginPlay
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void ReceiveBeginPlay();

	// Object: Function BP_GameState_BattleRoyale.BP_GameState_BattleRoyale_C.OnBattleStateChange
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnBattleStateChange(enum class E_BattleState_BattleRoyale ChangeType);

	// Object: Function BP_GameState_BattleRoyale.BP_GameState_BattleRoyale_C.BattleEnd
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x10) ]
	void BattleEnd(struct FString WinTeam);

	// Object: Function BP_GameState_BattleRoyale.BP_GameState_BattleRoyale_C.OnConfigInit
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnConfigInit();

	// Object: Function BP_GameState_BattleRoyale.BP_GameState_BattleRoyale_C.OnShowVictoryUI
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnShowVictoryUI();

	// Object: Function BP_GameState_BattleRoyale.BP_GameState_BattleRoyale_C.NetMulticastCelebrateBattleEnd
	// Flags: [Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0xc) ]
	void NetMulticastCelebrateBattleEnd(struct FVector Location);

	// Object: Function BP_GameState_BattleRoyale.BP_GameState_BattleRoyale_C.CelebrateBattleEnd_2
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0xc) ]
	void CelebrateBattleEnd_2(struct FVector Location);

	// Object: Function BP_GameState_BattleRoyale.BP_GameState_BattleRoyale_C.OnDataManagerPrepare
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnDataManagerPrepare();

	// Object: Function BP_GameState_BattleRoyale.BP_GameState_BattleRoyale_C.ExecuteUbergraph_BP_GameState_BattleRoyale
	// Flags: [Final|UbergraphFunction|HasDefaults]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_BP_GameState_BattleRoyale(int32_t EntryPoint);

	// Object: Function BP_GameState_BattleRoyale.BP_GameState_BattleRoyale_C.OnGameStateChanged__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnGameStateChanged__DelegateSignature(enum class ESCMInGameState NewState);

	// Object: Function BP_GameState_BattleRoyale.BP_GameState_BattleRoyale_C.OnBasicSystemReady_0__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnBasicSystemReady_0__DelegateSignature();

	// Object: Function BP_GameState_BattleRoyale.BP_GameState_BattleRoyale_C.BroadcastBattleStateChange__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x1) ]
	void BroadcastBattleStateChange__DelegateSignature(enum class E_BattleState_BattleRoyale Now State);
};

