#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_GeneralInteractionListConfig.BP_GeneralInteractionListConfig_C
// Inherited Bytes: 0x80 | Struct Size: 0x180
struct UBP_GeneralInteractionListConfig_C : UGeneralInteractionButtonConfigDataAsset {
	// Fields
	struct TMap<struct FGameplayTag, enum class E_Interact_Type> TagToInteactType; // Offset: 0x80 | Size: 0x50
	struct TArray<struct FBPS_InteractionButtonViewConfig> ViewConfig; // Offset: 0xd0 | Size: 0x10
	struct TMap<enum class E_Interact_Type, enum class E_Interact_Type> NormalToBuff; // Offset: 0xe0 | Size: 0x50
	struct TMap<enum class E_Interact_Type, enum class E_Interact_Type> BuffToNormal; // Offset: 0x130 | Size: 0x50
};

