#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_HumanoidTaget_Stand.BP_HumanoidTaget_Stand_C
// Inherited Bytes: 0x2c8 | Struct Size: 0x34c
struct ABP_HumanoidTaget_Stand_C : AHumanoidTarget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x2c8 | Size: 0x8
	struct UCapsuleComponent* Body; // Offset: 0x2d0 | Size: 0x8
	struct USphereComponent* head; // Offset: 0x2d8 | Size: 0x8
	struct UStaticMeshComponent* SM_TL_PB_BuoyPlateA; // Offset: 0x2e0 | Size: 0x8
	struct UStaticMeshComponent* SM_TL_PB_Buoy; // Offset: 0x2e8 | Size: 0x8
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x2f0 | Size: 0x8
	float Revive_Revive_7830FF06447762C762EC2ABAF2AA291C; // Offset: 0x2f8 | Size: 0x4
	enum class ETimelineDirection Revive__Direction_7830FF06447762C762EC2ABAF2AA291C; // Offset: 0x2fc | Size: 0x1
	char pad_0x2FD[0x3]; // Offset: 0x2fd | Size: 0x3
	struct UTimelineComponent* Revive; // Offset: 0x300 | Size: 0x8
	float Down_down_86CBB4A64F3673ADF4F4CC9BBFEE8353; // Offset: 0x308 | Size: 0x4
	enum class ETimelineDirection Down__Direction_86CBB4A64F3673ADF4F4CC9BBFEE8353; // Offset: 0x30c | Size: 0x1
	char pad_0x30D[0x3]; // Offset: 0x30d | Size: 0x3
	struct UTimelineComponent* Down; // Offset: 0x310 | Size: 0x8
	float TakenDamage; // Offset: 0x318 | Size: 0x4
	float CriticalMultiplier; // Offset: 0x31c | Size: 0x4
	bool IsDowned; // Offset: 0x320 | Size: 0x1
	char pad_0x321[0x3]; // Offset: 0x321 | Size: 0x3
	float Health; // Offset: 0x324 | Size: 0x4
	struct FVector DownedPosition; // Offset: 0x328 | Size: 0xc
	float ReviveTime; // Offset: 0x334 | Size: 0x4
	struct FMulticastInlineDelegate OnStateChanged; // Offset: 0x338 | Size: 0x10
	float Position; // Offset: 0x348 | Size: 0x4

	// Functions

	// Object: Function BP_HumanoidTaget_Stand.BP_HumanoidTaget_Stand_C.OnRep_Position
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnRep_Position();

	// Object: Function BP_HumanoidTaget_Stand.BP_HumanoidTaget_Stand_C.GetCenterLocation
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0xc) ]
	struct FVector GetCenterLocation();

	// Object: Function BP_HumanoidTaget_Stand.BP_HumanoidTaget_Stand_C.OnRep_IsDowned
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnRep_IsDowned();

	// Object: Function BP_HumanoidTaget_Stand.BP_HumanoidTaget_Stand_C.Down__FinishedFunc
	// Flags: [BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void Down__FinishedFunc();

	// Object: Function BP_HumanoidTaget_Stand.BP_HumanoidTaget_Stand_C.Down__UpdateFunc
	// Flags: [BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void Down__UpdateFunc();

	// Object: Function BP_HumanoidTaget_Stand.BP_HumanoidTaget_Stand_C.Revive__FinishedFunc
	// Flags: [BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void Revive__FinishedFunc();

	// Object: Function BP_HumanoidTaget_Stand.BP_HumanoidTaget_Stand_C.Revive__UpdateFunc
	// Flags: [BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void Revive__UpdateFunc();

	// Object: Function BP_HumanoidTaget_Stand.BP_HumanoidTaget_Stand_C.SetHealth
	// Flags: [Net|NetServer|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void SetHealth();

	// Object: Function BP_HumanoidTaget_Stand.BP_HumanoidTaget_Stand_C.ReviveTarget
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void ReviveTarget();

	// Object: Function BP_HumanoidTaget_Stand.BP_HumanoidTaget_Stand_C.ServerOnTargetTakeDamage
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(2) Size(0x10) ]
	void ServerOnTargetTakeDamage(float Damage, struct AActor* DamageCauser);

	// Object: Function BP_HumanoidTaget_Stand.BP_HumanoidTaget_Stand_C.DownAnim
	// Flags: [Net|NetMulticast|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void DownAnim();

	// Object: Function BP_HumanoidTaget_Stand.BP_HumanoidTaget_Stand_C.ReviveAnim
	// Flags: [Net|NetMulticast|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void ReviveAnim();

	// Object: Function BP_HumanoidTaget_Stand.BP_HumanoidTaget_Stand_C.ReceiveBeginPlay
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void ReceiveBeginPlay();

	// Object: Function BP_HumanoidTaget_Stand.BP_HumanoidTaget_Stand_C.ExecuteUbergraph_BP_HumanoidTaget_Stand
	// Flags: [Final|UbergraphFunction|HasDefaults]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_BP_HumanoidTaget_Stand(int32_t EntryPoint);

	// Object: Function BP_HumanoidTaget_Stand.BP_HumanoidTaget_Stand_C.OnStateChanged__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnStateChanged__DelegateSignature(bool bIsDwon);
};

