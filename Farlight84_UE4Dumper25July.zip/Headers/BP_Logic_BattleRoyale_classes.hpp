#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C
// Inherited Bytes: 0x1da | Struct Size: 0x4a8
struct UBP_Logic_BattleRoyale_C : UBP_Logic_Framework_C {
	// Fields
	char pad_0x1DA[0x6]; // Offset: 0x1da | Size: 0x6
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x1e0 | Size: 0x8
	int32_t WaitTime; // Offset: 0x1e8 | Size: 0x4
	char pad_0x1EC[0x4]; // Offset: 0x1ec | Size: 0x4
	struct TArray<struct APlayerStart*> WaitinglandStart; // Offset: 0x1f0 | Size: 0x10
	struct ABP_GameState_BattleRoyale_C* GameState; // Offset: 0x200 | Size: 0x8
	struct FMulticastInlineDelegate OnGoInToBattleState; // Offset: 0x208 | Size: 0x10
	bool bWarmGame; // Offset: 0x218 | Size: 0x1
	char pad_0x219[0x7]; // Offset: 0x219 | Size: 0x7
	struct FSolarTablesData_WarmGameMode WarmGameInfo; // Offset: 0x220 | Size: 0x78
	struct UDataTable* BattleTimeline; // Offset: 0x298 | Size: 0x8
	struct TMap<int32_t, struct FS_EventList_BattleRoyal> EventList; // Offset: 0x2a0 | Size: 0x50
	struct UBP_MapInfoComponent_C* MapInfo; // Offset: 0x2f0 | Size: 0x8
	int32_t ShrinkIndex; // Offset: 0x2f8 | Size: 0x4
	char pad_0x2FC[0x4]; // Offset: 0x2fc | Size: 0x4
	struct ABP_BattleRoylePoisonCircle_C* PoisonCircle; // Offset: 0x300 | Size: 0x8
	struct ABP_SolarBombingManager_C* BoomingManager; // Offset: 0x308 | Size: 0x8
	enum class E_BattleState_BattleRoyale ModeBattleState; // Offset: 0x310 | Size: 0x1
	char pad_0x311[0x7]; // Offset: 0x311 | Size: 0x7
	struct TArray<struct FVector> AirDropPosHistoryRecord; // Offset: 0x318 | Size: 0x10
	int32_t AiLevel; // Offset: 0x328 | Size: 0x4
	char pad_0x32C[0x4]; // Offset: 0x32c | Size: 0x4
	struct TMap<enum class E_BattleEvent_BattleRoyale, bool> ModeEventValid; // Offset: 0x330 | Size: 0x50
	int32_t TotalPlayer; // Offset: 0x380 | Size: 0x4
	char pad_0x384[0x4]; // Offset: 0x384 | Size: 0x4
	struct ABP_ReviveItemManger_BattleRoyale_C* ReviveManager; // Offset: 0x388 | Size: 0x8
	struct ABP_Formula_BattleRoyale_C* BR Formula Manager; // Offset: 0x390 | Size: 0x8
	struct UDataTable* UnfetteredAreaTimeline; // Offset: 0x398 | Size: 0x8
	int32_t TeamMemberCount; // Offset: 0x3a0 | Size: 0x4
	char pad_0x3A4[0x4]; // Offset: 0x3a4 | Size: 0x4
	struct UBehaviorTree* BotBehaviorTree; // Offset: 0x3a8 | Size: 0x8
	struct TArray<struct ASCMPlayerState*> PlayersQuitOnWaitingLand; // Offset: 0x3b0 | Size: 0x10
	int32_t PlayerCountMax; // Offset: 0x3c0 | Size: 0x4
	bool bCanSpawnAI; // Offset: 0x3c4 | Size: 0x1
	char pad_0x3C5[0x3]; // Offset: 0x3c5 | Size: 0x3
	struct ABP_BattleRoylePoisonCircle_C* PoisonCircleClass; // Offset: 0x3c8 | Size: 0x8
	struct ASolarBotAIController* AIController; // Offset: 0x3d0 | Size: 0x8
	struct ABP_DefenderManager_C* DefenderManager; // Offset: 0x3d8 | Size: 0x8
	struct TArray<float> RadiusArr; // Offset: 0x3e0 | Size: 0x10
	int32_t AILevelMax; // Offset: 0x3f0 | Size: 0x4
	char pad_0x3F4[0x4]; // Offset: 0x3f4 | Size: 0x4
	struct FMulticastInlineDelegate BattleStateChanged; // Offset: 0x3f8 | Size: 0x10
	int32_t PlayerCountBattleStart; // Offset: 0x408 | Size: 0x4
	int32_t ChestSpawnerID; // Offset: 0x40c | Size: 0x4
	struct UGameplayAbility* CelebrateWinnerGAClass; // Offset: 0x410 | Size: 0x8
	struct TArray<float> MinOffsetArr; // Offset: 0x418 | Size: 0x10
	struct TArray<float> MaxOffsetArr; // Offset: 0x428 | Size: 0x10
	bool EnableUnfetteredArea; // Offset: 0x438 | Size: 0x1
	char pad_0x439[0x7]; // Offset: 0x439 | Size: 0x7
	struct TMap<int32_t, struct FExpSpringPreSelectData> ExpSpringTimelineData; // Offset: 0x440 | Size: 0x50
	int32_t ReviveItemNum; // Offset: 0x490 | Size: 0x4
	float GameplayTime; // Offset: 0x494 | Size: 0x4
	struct TArray<float> PoisonDamageArr; // Offset: 0x498 | Size: 0x10

	// Functions

	// Object: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.InitExpSpringPoint
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(2) Size(0x18) ]
	void InitExpSpringPoint(struct TArray<struct FName>& RowNameList, struct UDataTable*& BattleTimeline);

	// Object: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.ReadyToFinal
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x1) ]
	void ReadyToFinal(bool& Result);

	// Object: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.BP_Logic_BattleRoyale_AutoGenFunc
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void BP_Logic_BattleRoyale_AutoGenFunc();

	// Object: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.InEnableUnfetteredArea
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x1) ]
	void InEnableUnfetteredArea(bool& IsEnable);

	// Object: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.GetWeaponIDByCharacter
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(3) Size(0x10) ]
	void GetWeaponIDByCharacter(struct ASolarCharacter* InCharacter, int32_t InSlot, int32_t& OutWeaponID);

	// Object: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.SetUnfetteredAreaTimeline
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void SetUnfetteredAreaTimeline();

	// Object: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.GetPlayerDataTraceByPlayer
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(2) Size(0x58) ]
	void GetPlayerDataTraceByPlayer(struct ABP_PlayerState_BattleRoyale_C* InPlayerState, struct TMap<struct FString, struct FString>& Map);

	// Object: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.HandleWinnerTeamPostSlomo
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x8) ]
	void HandleWinnerTeamPostSlomo(struct ASolarTeamInfo* WinnerTeam);

	// Object: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.HandleWinnerTeamPreSlomo
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x8) ]
	void HandleWinnerTeamPreSlomo(struct ASolarTeamInfo* WinnerTeam);

	// Object: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.PresettleAll
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void PresettleAll();

	// Object: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.DealTeammateAISettle
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x8) ]
	void DealTeammateAISettle(struct ASolarPlayerState* Player);

	// Object: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.Custom Room Start
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void Custom Room Start();

	// Object: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.SendItemToPlayer
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(2) Size(0x58) ]
	void SendItemToPlayer(struct ASolarPlayerState* Player, struct TMap<int32_t, int32_t>& ItemMap);

	// Object: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.GetVehicleDataTrace
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x50) ]
	void GetVehicleDataTrace(struct TMap<struct FString, struct FString>& Map);

	// Object: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.Init Poison Circle
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void Init Poison Circle();

	// Object: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.SetSkillStateByBattleState
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void SetSkillStateByBattleState();

	// Object: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.Get Shrink Index
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t Get Shrink Index();

	// Object: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.GetWeaponID
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(2) Size(0x8) ]
	void GetWeaponID(int32_t ItemID, int32_t& weaponid);

	// Object: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.VehicleDataTrace
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void VehicleDataTrace();

	// Object: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.GetPlayerDataTrace
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(2) Size(0x58) ]
	void GetPlayerDataTrace(struct ABP_PlayerState_BattleRoyale_C* Player, struct TMap<struct FString, struct FString>& Map);

	// Object: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.ReceivePlayerReJoinRequest
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(3) Size(0x21) ]
	bool ReceivePlayerReJoinRequest(struct FString PlayerId, struct FString& ErrorMsg);

	// Object: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.GetAiLevel
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(2) Size(0xc) ]
	void GetAiLevel(struct ASolarPlayerState* Target, int32_t& DefaultDifficultyLevel);

	// Object: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.Get Config
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x8) ]
	void Get Config(struct UCFG_BattleRoyale_C*& CFG);

	// Object: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.DataTrace
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void DataTrace();

	// Object: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.UpdatePlayerData
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x8) ]
	void UpdatePlayerData(struct ASolarPlayerState* Target);

	// Object: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.PreSettleDeal
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(2) Size(0x9) ]
	void PreSettleDeal(struct ASCMPlayerState* Player, enum class ESCMPlayerOutType OutType);

	// Object: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.Will Master Leaving Disband Room
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x1) ]
	void Will Master Leaving Disband Room(bool& Result);

	// Object: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.Is Master Disbanding Legal
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x1) ]
	void Is Master Disbanding Legal(bool& Result);

	// Object: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.Is Kick Out Legal
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x1) ]
	void Is Kick Out Legal(bool& Result);

	// Object: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.Is Side Switch Legal
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x1) ]
	void Is Side Switch Legal(bool& Result);

	// Object: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.BuyResurrectionDeal
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x8) ]
	void BuyResurrectionDeal(struct APlayerState* Player);

	// Object: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.UpdateWinnerData
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x10) ]
	void UpdateWinnerData(struct FString Team);

	// Object: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.IsLamster
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(3) Size(0xa) ]
	bool IsLamster(struct ASCMPlayerState* Player, enum class ESCMPlayerOutType Index);

	// Object: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.CanPlayerBattle
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(2) Size(0x9) ]
	bool CanPlayerBattle(struct ASCMPlayerState* Player);

	// Object: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.UpdateTeamData
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(2) Size(0x11) ]
	void UpdateTeamData(struct FString Team, bool& bAced);

	// Object: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.GetConiReviveManager
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x8) ]
	void GetConiReviveManager(struct ABP_ReviveItemManger_BattleRoyale_C*& Output_Get);

	// Object: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.QuitImmediately
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(3) Size(0x11) ]
	void QuitImmediately(enum class ESCMPlayerOutType Index, struct ASCMPlayerState* InputPin, bool& SendToSettle);

	// Object: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.Update Player Data Trace
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x8) ]
	void Update Player Data Trace(struct ASCMPlayerState* PlayerState);

	// Object: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.Create Airdrop
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(4) Size(0x38) ]
	void Create Airdrop(int32_t ChestID, int32_t Num, int32_t NoticeID, struct FGameplayEventFilterConfig Config);

	// Object: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.StartCruising
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void StartCruising();

	// Object: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.InitElements
	// Flags: [Private|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void InitElements();

	// Object: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.Get Map Info
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x8) ]
	void Get Map Info(struct UBP_MapInfoComponent_C*& MapInfo);

	// Object: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.Init Timeline Event
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x8) ]
	void Init Timeline Event(struct UDataTable*& BattleTimeline);

	// Object: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.ExecuteBattleEvent
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x80) ]
	void ExecuteBattleEvent(struct FS_Event_BattleRoyale& S_Event_BattleRoyale);

	// Object: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.UpdateBattleState
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x1) ]
	void UpdateBattleState(enum class E_BattleState_BattleRoyale NewState);

	// Object: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.GetGameState
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x8) ]
	void GetGameState(struct ABP_GameState_BattleRoyale_C*& Output_Get);

	// Object: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.GetPlayerStartOnWaitingland
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x10) ]
	void GetPlayerStartOnWaitingland(struct TArray<struct APlayerStart*>& PlayerStarts);

	// Object: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.GetBattleRoyaleMode
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x8) ]
	void GetBattleRoyaleMode(struct ABP_Mode_BattleRoyale_C*& AsBP SCM Battle Royale);

	// Object: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.InitModeSetting
	// Flags: [Protected|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void InitModeSetting();

	// Object: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.GMSpawnAI
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void GMSpawnAI();

	// Object: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.ReceiveBattleTick
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(2) Size(0x8) ]
	void ReceiveBattleTick(float BattleTime, float DeltaTime);

	// Object: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.PreSettle
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(2) Size(0x9) ]
	void PreSettle(struct ASCMPlayerState* Player, enum class ESCMPlayerOutType OutType);

	// Object: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.BattleInitFinished
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void BattleInitFinished();

	// Object: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.OnDSClose
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnDSClose();

	// Object: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.ReceivePlayerJoinBattle
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(2) Size(0x9) ]
	void ReceivePlayerJoinBattle(struct ASCMPlayerState* NewPlayer, bool IsAI);

	// Object: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.ReceivePlayerBattleEnd
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(2) Size(0x9) ]
	void ReceivePlayerBattleEnd(struct ASCMPlayerState* Player, enum class ESCMPlayerOutType OutType);

	// Object: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.OnActiveUnfetteredArea
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnActiveUnfetteredArea(bool bActive);

	// Object: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.OnMatchingClosed
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x4) ]
	void OnMatchingClosed(int32_t RPCId);

	// Object: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.HandleFinal
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void HandleFinal();

	// Object: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.Snapshot
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void Snapshot();

	// Object: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.VehicleSnapshot
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void VehicleSnapshot();

	// Object: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.HandleMatchHasStarted
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void HandleMatchHasStarted();

	// Object: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.HandleMatchHasEnded
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void HandleMatchHasEnded();

	// Object: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.ExecuteUbergraph_BP_Logic_BattleRoyale
	// Flags: [Final|UbergraphFunction|HasDefaults]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_BP_Logic_BattleRoyale(int32_t EntryPoint);

	// Object: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.BattleStateChanged__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x1) ]
	void BattleStateChanged__DelegateSignature(enum class E_BattleState_BattleRoyale NewState);

	// Object: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.OnGoInToBattleState__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnGoInToBattleState__DelegateSignature();
};

