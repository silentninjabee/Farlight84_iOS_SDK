#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_PBagsTrail_Common.BP_PBagsTrail_Common_C
// Inherited Bytes: 0x2a0 | Struct Size: 0x2e9
struct ABP_PBagsTrail_Common_C : ASolarBackpackSFX {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x2a0 | Size: 0x8
	struct UParticleSystemComponent* FX_WallRunStop; // Offset: 0x2a8 | Size: 0x8
	struct UParticleSystemComponent* FX_WallRunLoop; // Offset: 0x2b0 | Size: 0x8
	struct UParticleSystemComponent* FX_trail; // Offset: 0x2b8 | Size: 0x8
	struct UParticleSystemComponent* FX_DropSlowDown; // Offset: 0x2c0 | Size: 0x8
	struct UParticleSystemComponent* FX_SkyDivingLanding; // Offset: 0x2c8 | Size: 0x8
	struct USceneComponent* VFX; // Offset: 0x2d0 | Size: 0x8
	float TrailFade_Size_581709C845BD673DB0841C82710F99F1; // Offset: 0x2d8 | Size: 0x4
	enum class ETimelineDirection TrailFade__Direction_581709C845BD673DB0841C82710F99F1; // Offset: 0x2dc | Size: 0x1
	char pad_0x2DD[0x3]; // Offset: 0x2dd | Size: 0x3
	struct UTimelineComponent* TrailFade; // Offset: 0x2e0 | Size: 0x8
	bool IsWallrun; // Offset: 0x2e8 | Size: 0x1

	// Functions

	// Object: Function BP_PBagsTrail_Common.BP_PBagsTrail_Common_C.SetCameraFadeEnable
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetCameraFadeEnable(bool bInEnable);

	// Object: Function BP_PBagsTrail_Common.BP_PBagsTrail_Common_C.ClearParticleTemplate
	// Flags: [Event|Protected|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void ClearParticleTemplate();

	// Object: Function BP_PBagsTrail_Common.BP_PBagsTrail_Common_C.OnWallRun
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnWallRun();

	// Object: Function BP_PBagsTrail_Common.BP_PBagsTrail_Common_C.BackpackSFXEnd
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void BackpackSFXEnd();

	// Object: Function BP_PBagsTrail_Common.BP_PBagsTrail_Common_C.BackpackSFXLaunch
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(3) Size(0x1c) ]
	void BackpackSFXLaunch(bool GroundDetected, struct FVector& GroundLocation, struct FVector& GroundNormal);

	// Object: Function BP_PBagsTrail_Common.BP_PBagsTrail_Common_C.BackpackSFXBegin
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(2) Size(0x2) ]
	void BackpackSFXBegin(enum class EFXJetType InJetType, bool GroundDetected);

	// Object: Function BP_PBagsTrail_Common.BP_PBagsTrail_Common_C.UpdateTrailParticle
	// Flags: [Protected|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0xa8) ]
	void UpdateTrailParticle(struct FBackpackTrailAssemblingParams SoftObjectRef);

	// Object: Function BP_PBagsTrail_Common.BP_PBagsTrail_Common_C.GetTrailEffectComponent
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UParticleSystemComponent* GetTrailEffectComponent();

	// Object: Function BP_PBagsTrail_Common.BP_PBagsTrail_Common_C.FX_FinishDeactive
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void FX_FinishDeactive();

	// Object: Function BP_PBagsTrail_Common.BP_PBagsTrail_Common_C.SkyDivingLanding
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void SkyDivingLanding();

	// Object: Function BP_PBagsTrail_Common.BP_PBagsTrail_Common_C.DropSlowDown
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void DropSlowDown();

	// Object: Function BP_PBagsTrail_Common.BP_PBagsTrail_Common_C.Normal Jet Fly
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void Normal Jet Fly();

	// Object: Function BP_PBagsTrail_Common.BP_PBagsTrail_Common_C.FX_InitializeDeactive
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void FX_InitializeDeactive();

	// Object: Function BP_PBagsTrail_Common.BP_PBagsTrail_Common_C.TrailFade__FinishedFunc
	// Flags: [BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void TrailFade__FinishedFunc();

	// Object: Function BP_PBagsTrail_Common.BP_PBagsTrail_Common_C.TrailFade__UpdateFunc
	// Flags: [BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void TrailFade__UpdateFunc();

	// Object: Function BP_PBagsTrail_Common.BP_PBagsTrail_Common_C.OnBackpackTrailAssembling
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(2) Size(0xa9) ]
	void OnBackpackTrailAssembling(struct FBackpackTrailAssemblingParams& Params, enum class EBackpackPropellingMode PropellingMode);

	// Object: Function BP_PBagsTrail_Common.BP_PBagsTrail_Common_C.TryFadeOutTrail
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void TryFadeOutTrail();

	// Object: Function BP_PBagsTrail_Common.BP_PBagsTrail_Common_C.wallrunstop
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void wallrunstop();

	// Object: Function BP_PBagsTrail_Common.BP_PBagsTrail_Common_C.StopFadeOut
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void StopFadeOut();

	// Object: Function BP_PBagsTrail_Common.BP_PBagsTrail_Common_C.ExecuteUbergraph_BP_PBagsTrail_Common
	// Flags: [Final|UbergraphFunction|HasDefaults]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_BP_PBagsTrail_Common(int32_t EntryPoint);
};

