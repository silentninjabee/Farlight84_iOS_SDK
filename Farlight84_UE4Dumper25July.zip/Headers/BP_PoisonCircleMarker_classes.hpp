#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_PoisonCircleMarker.BP_PoisonCircleMarker_C
// Inherited Bytes: 0x2b8 | Struct Size: 0x2c8
struct ABP_PoisonCircleMarker_C : ASolarMapElementBase {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x2b8 | Size: 0x8
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x2c0 | Size: 0x8

	// Functions

	// Object: Function BP_PoisonCircleMarker.BP_PoisonCircleMarker_C.ReceiveBeginPlay
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void ReceiveBeginPlay();

	// Object: Function BP_PoisonCircleMarker.BP_PoisonCircleMarker_C.ExecuteUbergraph_BP_PoisonCircleMarker
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_BP_PoisonCircleMarker(int32_t EntryPoint);
};

