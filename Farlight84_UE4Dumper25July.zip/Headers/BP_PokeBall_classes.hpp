#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_PokeBall.BP_PokeBall_C
// Inherited Bytes: 0x310 | Struct Size: 0x310
struct ABP_PokeBall_C : ASolarSkill_PokeBall {
};

