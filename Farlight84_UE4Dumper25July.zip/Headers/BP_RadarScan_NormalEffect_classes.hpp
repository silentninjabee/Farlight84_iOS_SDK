#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_RadarScan_NormalEffect.BP_RadarScan_NormalEffect_C
// Inherited Bytes: 0x230 | Struct Size: 0x230
struct UBP_RadarScan_NormalEffect_C : UMaterialSimpleEffect {
};

