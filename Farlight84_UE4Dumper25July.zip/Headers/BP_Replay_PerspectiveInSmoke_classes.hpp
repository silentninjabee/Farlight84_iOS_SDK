#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_Replay_PerspectiveInSmoke.BP_Replay_PerspectiveInSmoke_C
// Inherited Bytes: 0x1b0 | Struct Size: 0x1b0
struct UBP_Replay_PerspectiveInSmoke_C : USolarReplayPerspectiveInSmokeEffect {
};

