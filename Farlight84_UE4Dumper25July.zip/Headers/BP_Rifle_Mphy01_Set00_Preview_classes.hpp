#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_Rifle_Mphy01_Set00_Preview.BP_Rifle_Mphy01_Set00_Preview_C
// Inherited Bytes: 0x6d8 | Struct Size: 0x6d8
struct ABP_Rifle_Mphy01_Set00_Preview_C : ABP_Weaponry_Base_Preview_C {
};

