#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_SI_Tacticalbox.BP_SI_Tacticalbox_C
// Inherited Bytes: 0x7c8 | Struct Size: 0x7d0
struct ABP_SI_Tacticalbox_C : ATacticalTreasureBox {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x7c8 | Size: 0x8

	// Functions

	// Object: Function BP_SI_Tacticalbox.BP_SI_Tacticalbox_C.PlayOpenAnimation
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void PlayOpenAnimation();

	// Object: Function BP_SI_Tacticalbox.BP_SI_Tacticalbox_C.ExecuteUbergraph_BP_SI_Tacticalbox
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_BP_SI_Tacticalbox(int32_t EntryPoint);
};

