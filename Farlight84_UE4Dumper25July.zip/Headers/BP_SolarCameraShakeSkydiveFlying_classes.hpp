#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_SolarCameraShakeSkydiveFlying.BP_SolarCameraShakeSkydiveFlying_C
// Inherited Bytes: 0x160 | Struct Size: 0x160
struct UBP_SolarCameraShakeSkydiveFlying_C : UCameraShake {
};

