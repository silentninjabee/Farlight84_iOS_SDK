#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_SolarCapsuleActorRoot.BP_SolarCapsuleActorRoot_C
// Inherited Bytes: 0x418 | Struct Size: 0x418
struct ABP_SolarCapsuleActorRoot_C : ASolarCapsuleRoot {
};

