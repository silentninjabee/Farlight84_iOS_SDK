#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_SolarCheatManager.BP_SolarCheatManager_C
// Inherited Bytes: 0x3b0 | Struct Size: 0x3b0
struct UBP_SolarCheatManager_C : USolarCheatManager {
	// Functions

	// Object: Function BP_SolarCheatManager.BP_SolarCheatManager_C.SolarGM_TestResurrectCapsule
	// Flags: [Exec|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void SolarGM_TestResurrectCapsule();
};

