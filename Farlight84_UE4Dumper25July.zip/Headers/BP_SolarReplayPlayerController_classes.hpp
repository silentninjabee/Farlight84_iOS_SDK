#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_SolarReplayPlayerController.BP_SolarReplayPlayerController_C
// Inherited Bytes: 0x1318 | Struct Size: 0x1320
struct ABP_SolarReplayPlayerController_C : ASolarReplayPlayerController {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x1318 | Size: 0x8

	// Functions

	// Object: Function BP_SolarReplayPlayerController.BP_SolarReplayPlayerController_C.InpActEvt_F10_K2Node_InputKeyEvent_1
	// Flags: [BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x18) ]
	void InpActEvt_F10_K2Node_InputKeyEvent_1(struct FKey Key);

	// Object: Function BP_SolarReplayPlayerController.BP_SolarReplayPlayerController_C.ExecuteUbergraph_BP_SolarReplayPlayerController
	// Flags: [Final|UbergraphFunction|HasDefaults]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_BP_SolarReplayPlayerController(int32_t EntryPoint);
};

