#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_SolarTreasureBoxSpawner.BP_SolarTreasureBoxSpawner_C
// Inherited Bytes: 0x4c0 | Struct Size: 0x4f8
struct ABP_SolarTreasureBoxSpawner_C : ASolarTreasureBoxSpawner {
	// Fields
	struct USolarNavModifierComponent* SolarNavModifier; // Offset: 0x4c0 | Size: 0x8
	struct UStaticMeshComponent* Cube; // Offset: 0x4c8 | Size: 0x8
	struct UArrowComponent* Arrow; // Offset: 0x4d0 | Size: 0x8
	struct UStaticMeshComponent* BoxCube; // Offset: 0x4d8 | Size: 0x8
	struct USceneComponent* SceneRoot; // Offset: 0x4e0 | Size: 0x8
	struct TArray<struct FLinearColor> GroupMatColors; // Offset: 0x4e8 | Size: 0x10

	// Functions

	// Object: Function BP_SolarTreasureBoxSpawner.BP_SolarTreasureBoxSpawner_C.UserConstructionScript
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void UserConstructionScript();
};

