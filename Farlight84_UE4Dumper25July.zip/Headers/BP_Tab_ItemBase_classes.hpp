#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass BP_Tab_ItemBase.BP_Tab_ItemBase_C
// Inherited Bytes: 0x490 | Struct Size: 0x509
struct UBP_Tab_ItemBase_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x490 | Size: 0x8
	struct FString Text; // Offset: 0x498 | Size: 0x10
	struct FVector2D Size; // Offset: 0x4a8 | Size: 0x8
	struct FS_HintData HintData; // Offset: 0x4b0 | Size: 0x10
	enum class E_TabStyle Style; // Offset: 0x4c0 | Size: 0x1
	char pad_0x4C1[0x7]; // Offset: 0x4c1 | Size: 0x7
	struct USolarRedHint_General_C* HintWidget; // Offset: 0x4c8 | Size: 0x8
	bool bSelected; // Offset: 0x4d0 | Size: 0x1
	char pad_0x4D1[0x7]; // Offset: 0x4d1 | Size: 0x7
	struct FMulticastInlineDelegate ItemSelected; // Offset: 0x4d8 | Size: 0x10
	struct USolarTextBlock* wText; // Offset: 0x4e8 | Size: 0x8
	struct UBP_TabItemObj_C* Obj; // Offset: 0x4f0 | Size: 0x8
	struct UImage* Icon; // Offset: 0x4f8 | Size: 0x8
	struct UObject* IconImage; // Offset: 0x500 | Size: 0x8
	bool Hovered; // Offset: 0x508 | Size: 0x1

	// Functions

	// Object: Function BP_Tab_ItemBase.BP_Tab_ItemBase_C.ShowBubbleBox
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x1) ]
	void ShowBubbleBox(bool bIsShow);

	// Object: Function BP_Tab_ItemBase.BP_Tab_ItemBase_C.OnHovered
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnHovered(bool IsHovered);

	// Object: Function BP_Tab_ItemBase.BP_Tab_ItemBase_C.ReviseWidget
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void ReviseWidget();

	// Object: Function BP_Tab_ItemBase.BP_Tab_ItemBase_C.SetProperties
	// Flags: [Private|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetProperties(struct UBP_TabItemObj_C* Obj);

	// Object: Function BP_Tab_ItemBase.BP_Tab_ItemBase_C.UpdateWidget
	// Flags: [Private|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void UpdateWidget();

	// Object: Function BP_Tab_ItemBase.BP_Tab_ItemBase_C.InitWidget
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(3) Size(0x18) ]
	void InitWidget(struct USolarRedHint_General_C*& HintWidget, struct USolarTextBlock*& Text, struct UImage*& Icon);

	// Object: Function BP_Tab_ItemBase.BP_Tab_ItemBase_C.SetSelected
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetSelected(bool IsSelected);

	// Object: Function BP_Tab_ItemBase.BP_Tab_ItemBase_C.SetStyle
	// Flags: [Protected|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetStyle(enum class E_TabStyle Style);

	// Object: Function BP_Tab_ItemBase.BP_Tab_ItemBase_C.SetHintData
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetHintData(struct FS_HintData& S_HintData);

	// Object: Function BP_Tab_ItemBase.BP_Tab_ItemBase_C.SetItemSize
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetItemSize(struct FVector2D Size);

	// Object: Function BP_Tab_ItemBase.BP_Tab_ItemBase_C.BP_OnItemExpansionChanged
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x1) ]
	void BP_OnItemExpansionChanged(bool bIsExpanded);

	// Object: Function BP_Tab_ItemBase.BP_Tab_ItemBase_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function BP_Tab_ItemBase.BP_Tab_ItemBase_C.OnListItemObjectSet
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x8) ]
	void OnListItemObjectSet(struct UObject* ListItemObject);

	// Object: Function BP_Tab_ItemBase.BP_Tab_ItemBase_C.BP_OnItemSelectionChanged
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x1) ]
	void BP_OnItemSelectionChanged(bool bIsSelected);

	// Object: Function BP_Tab_ItemBase.BP_Tab_ItemBase_C.OnRevised
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnRevised();

	// Object: Function BP_Tab_ItemBase.BP_Tab_ItemBase_C.OnLocalLangChangedEx
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x10) ]
	void OnLocalLangChangedEx(struct FString InLang);

	// Object: Function BP_Tab_ItemBase.BP_Tab_ItemBase_C.BP_OnEntryReleased
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void BP_OnEntryReleased();

	// Object: Function BP_Tab_ItemBase.BP_Tab_ItemBase_C.ExecuteUbergraph_BP_Tab_ItemBase
	// Flags: [Final|UbergraphFunction|HasDefaults]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_BP_Tab_ItemBase(int32_t EntryPoint);

	// Object: Function BP_Tab_ItemBase.BP_Tab_ItemBase_C.ItemSelected__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x10) ]
	void ItemSelected__DelegateSignature(struct FString Key);
};

