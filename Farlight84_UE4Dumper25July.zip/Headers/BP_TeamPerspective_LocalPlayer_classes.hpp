#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_TeamPerspective_LocalPlayer.BP_TeamPerspective_LocalPlayer_C
// Inherited Bytes: 0x1d0 | Struct Size: 0x1d0
struct UBP_TeamPerspective_LocalPlayer_C : UMultiplePassMaterialEffect {
};

