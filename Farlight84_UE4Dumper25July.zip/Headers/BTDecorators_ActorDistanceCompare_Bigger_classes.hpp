#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BTDecorators_ActorDistanceCompare_Bigger.BTDecorators_ActorDistanceCompare_Bigger_C
// Inherited Bytes: 0x98 | Struct Size: 0x13c
struct UBTDecorators_ActorDistanceCompare_Bigger_C : UBTDecorator_BlueprintBase {
	// Fields
	struct FBlackboardKeySelector 1_1; // Offset: 0x98 | Size: 0x28
	struct FBlackboardKeySelector 1_2; // Offset: 0xc0 | Size: 0x28
	struct FBlackboardKeySelector 2_1; // Offset: 0xe8 | Size: 0x28
	struct FBlackboardKeySelector 2_2; // Offset: 0x110 | Size: 0x28
	float DistanceToCompare; // Offset: 0x138 | Size: 0x4

	// Functions

	// Object: Function BTDecorators_ActorDistanceCompare_Bigger.BTDecorators_ActorDistanceCompare_Bigger_C.PerformConditionCheckAI
	// Flags: [Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(3) Size(0x11) ]
	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn);
};

