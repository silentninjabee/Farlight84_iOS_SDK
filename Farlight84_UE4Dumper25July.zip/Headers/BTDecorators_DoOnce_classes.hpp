#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BTDecorators_DoOnce.BTDecorators_DoOnce_C
// Inherited Bytes: 0x98 | Struct Size: 0xc0
struct UBTDecorators_DoOnce_C : UBTDecorator_BlueprintBase {
	// Fields
	struct FBlackboardKeySelector DoOnce; // Offset: 0x98 | Size: 0x28

	// Functions

	// Object: Function BTDecorators_DoOnce.BTDecorators_DoOnce_C.PerformConditionCheckAI
	// Flags: [Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(3) Size(0x11) ]
	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn);
};

