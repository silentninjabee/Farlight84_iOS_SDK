#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BTDecorators_Random.BTDecorators_Random_C
// Inherited Bytes: 0x98 | Struct Size: 0x9c
struct UBTDecorators_Random_C : UBTDecorator_BlueprintBase {
	// Fields
	float NewVar_2; // Offset: 0x98 | Size: 0x4

	// Functions

	// Object: Function BTDecorators_Random.BTDecorators_Random_C.PerformConditionCheckAI
	// Flags: [Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(3) Size(0x11) ]
	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn);
};

