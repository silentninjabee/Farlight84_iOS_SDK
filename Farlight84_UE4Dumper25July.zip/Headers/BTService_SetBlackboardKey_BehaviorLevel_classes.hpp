#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BTService_SetBlackboardKey_BehaviorLevel.BTService_SetBlackboardKey_BehaviorLevel_C
// Inherited Bytes: 0x90 | Struct Size: 0xf8
struct UBTService_SetBlackboardKey_BehaviorLevel_C : UBTService_BlueprintBase {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x90 | Size: 0x8
	struct FBlackboardKeySelector BlackboardKey; // Offset: 0x98 | Size: 0x28
	struct FBlackboardKeySelector Behavior Level Key; // Offset: 0xc0 | Size: 0x28
	float ValueBL1; // Offset: 0xe8 | Size: 0x4
	float ValueBL2; // Offset: 0xec | Size: 0x4
	float ValueBL3; // Offset: 0xf0 | Size: 0x4
	float ValueBL4; // Offset: 0xf4 | Size: 0x4

	// Functions

	// Object: Function BTService_SetBlackboardKey_BehaviorLevel.BTService_SetBlackboardKey_BehaviorLevel_C.ReceiveTickAI
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(3) Size(0x14) ]
	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds);

	// Object: Function BTService_SetBlackboardKey_BehaviorLevel.BTService_SetBlackboardKey_BehaviorLevel_C.ExecuteUbergraph_BTService_SetBlackboardKey_BehaviorLevel
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_BTService_SetBlackboardKey_BehaviorLevel(int32_t EntryPoint);
};

