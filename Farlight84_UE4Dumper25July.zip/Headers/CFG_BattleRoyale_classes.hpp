#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass CFG_BattleRoyale.CFG_BattleRoyale_C
// Inherited Bytes: 0x6c0 | Struct Size: 0x8f4
struct UCFG_BattleRoyale_C : UCFG_Framework_C {
	// Fields
	int32_t ; // Offset: 0x6c0 | Size: 0x4
	int32_t ; // Offset: 0x6c4 | Size: 0x4
	int32_t ; // Offset: 0x6c8 | Size: 0x4
	char pad_0x6CC[0x4]; // Offset: 0x6cc | Size: 0x4
	struct TSoftObjectPtr<UBehaviorTree> ; // Offset: 0x6d0 | Size: 0x28
	struct TSoftObjectPtr<UBehaviorTree> ; // Offset: 0x6f8 | Size: 0x28
	struct TSoftObjectPtr<UBehaviorTree> ; // Offset: 0x720 | Size: 0x28
	int32_t ; // Offset: 0x748 | Size: 0x4
	char pad_0x74C[0x4]; // Offset: 0x74c | Size: 0x4
	struct UDataTable* ; // Offset: 0x750 | Size: 0x8
	int32_t ; // Offset: 0x758 | Size: 0x4
	char pad_0x75C[0x4]; // Offset: 0x75c | Size: 0x4
	struct TSoftClassPtr<UObject> AIController; // Offset: 0x760 | Size: 0x28
	bool ; // Offset: 0x788 | Size: 0x1
	char pad_0x789[0x3]; // Offset: 0x789 | Size: 0x3
	float ; // Offset: 0x78c | Size: 0x4
	float ; // Offset: 0x790 | Size: 0x4
	int32_t ; // Offset: 0x794 | Size: 0x4
	int32_t ; // Offset: 0x798 | Size: 0x4
	int32_t ; // Offset: 0x79c | Size: 0x4
	int32_t ; // Offset: 0x7a0 | Size: 0x4
	char pad_0x7A4[0x4]; // Offset: 0x7a4 | Size: 0x4
	struct UDataTable* ; // Offset: 0x7a8 | Size: 0x8
	int32_t ; // Offset: 0x7b0 | Size: 0x4
	struct FInt32Range ; // Offset: 0x7b4 | Size: 0x10
	struct FInt32Range ; // Offset: 0x7c4 | Size: 0x10
	float ; // Offset: 0x7d4 | Size: 0x4
	struct FS_SkillState ; // Offset: 0x7d8 | Size: 0x4
	struct FS_SkillState ; // Offset: 0x7dc | Size: 0x4
	struct TMap<int32_t, int32_t> ; // Offset: 0x7e0 | Size: 0x50
	struct TMap<int32_t, int32_t> ; // Offset: 0x830 | Size: 0x50
	struct FS_SkillState ; // Offset: 0x880 | Size: 0x4
	struct FS_SkillState ; // Offset: 0x884 | Size: 0x4
	bool ; // Offset: 0x888 | Size: 0x1
	struct FS_SkillState ; // Offset: 0x889 | Size: 0x4
	char pad_0x88D[0x3]; // Offset: 0x88d | Size: 0x3
	int32_t TopVictoryTeamRank; // Offset: 0x890 | Size: 0x4
	int32_t MaxBattleCountDown; // Offset: 0x894 | Size: 0x4
	bool ; // Offset: 0x898 | Size: 0x1
	bool ; // Offset: 0x899 | Size: 0x1
	char pad_0x89A[0x6]; // Offset: 0x89a | Size: 0x6
	struct TMap<int32_t, struct FString> ; // Offset: 0x8a0 | Size: 0x50
	int32_t ; // Offset: 0x8f0 | Size: 0x4

	// Functions

	// Object: Function CFG_BattleRoyale.CFG_BattleRoyale_C.GetSkillStateByNameEnum
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(2) Size(0x5) ]
	void GetSkillStateByNameEnum(enum class ESkillStateNameEnum Enum, struct FS_SkillState& Out);
};

