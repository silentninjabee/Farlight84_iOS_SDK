#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass CS_TacticalDodge.CS_TacticalDodge_C
// Inherited Bytes: 0x160 | Struct Size: 0x160
struct UCS_TacticalDodge_C : UCameraShake {
};

