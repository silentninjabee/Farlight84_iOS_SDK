#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class CableComponent.CableActor
// Inherited Bytes: 0x248 | Struct Size: 0x250
struct ACableActor : AActor {
	// Fields
	struct UCableComponent* CableComponent; // Offset: 0x248 | Size: 0x8
};

// Object: Class CableComponent.CableComponent
// Inherited Bytes: 0x690 | Struct Size: 0x710
struct UCableComponent : UMeshComponent {
	// Fields
	bool bAttachStart; // Offset: 0x681 | Size: 0x1
	bool bAttachEnd; // Offset: 0x682 | Size: 0x1
	struct FComponentReference AttachEndTo; // Offset: 0x688 | Size: 0x28
	struct FName AttachEndToSocketName; // Offset: 0x6b0 | Size: 0x8
	struct FVector EndLocation; // Offset: 0x6b8 | Size: 0xc
	float CableLength; // Offset: 0x6c4 | Size: 0x4
	int32_t NumSegments; // Offset: 0x6c8 | Size: 0x4
	float SubstepTime; // Offset: 0x6cc | Size: 0x4
	int32_t SolverIterations; // Offset: 0x6d0 | Size: 0x4
	bool bEnableStiffness; // Offset: 0x6d4 | Size: 0x1
	bool bUseSubstepping; // Offset: 0x6d5 | Size: 0x1
	bool bSkipCableUpdateWhenNotVisible; // Offset: 0x6d6 | Size: 0x1
	bool bSkipCableUpdateWhenNotOwnerRecentlyRendered; // Offset: 0x6d7 | Size: 0x1
	bool bEnableCollision; // Offset: 0x6d8 | Size: 0x1
	float CollisionFriction; // Offset: 0x6dc | Size: 0x4
	struct FVector CableForce; // Offset: 0x6e0 | Size: 0xc
	float CableGravityScale; // Offset: 0x6ec | Size: 0x4
	float CableWidth; // Offset: 0x6f0 | Size: 0x4
	int32_t NumSides; // Offset: 0x6f4 | Size: 0x4
	float TileMaterial; // Offset: 0x6f8 | Size: 0x4
	char pad_0x703[0xd]; // Offset: 0x703 | Size: 0xd

	// Functions

	// Object: Function CableComponent.CableComponent.SetAttachEndToComponent
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x103514968
	// Return & Params: [ Num(2) Size(0x10) ]
	void SetAttachEndToComponent(struct USceneComponent* Component, struct FName SocketName);

	// Object: Function CableComponent.CableComponent.SetAttachEndTo
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x103514898
	// Return & Params: [ Num(3) Size(0x18) ]
	void SetAttachEndTo(struct AActor* Actor, struct FName ComponentProperty, struct FName SocketName);

	// Object: Function CableComponent.CableComponent.GetCableParticleLocations
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1035147e4
	// Return & Params: [ Num(1) Size(0x10) ]
	void GetCableParticleLocations(struct TArray<struct FVector>& Locations);

	// Object: Function CableComponent.CableComponent.GetAttachedComponent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x103514850
	// Return & Params: [ Num(1) Size(0x8) ]
	struct USceneComponent* GetAttachedComponent();

	// Object: Function CableComponent.CableComponent.GetAttachedActor
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x103514874
	// Return & Params: [ Num(1) Size(0x8) ]
	struct AActor* GetAttachedActor();
};

