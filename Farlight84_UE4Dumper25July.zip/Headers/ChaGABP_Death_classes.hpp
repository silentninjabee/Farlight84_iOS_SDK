#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGABP_Death.ChaGABP_Death_C
// Inherited Bytes: 0x528 | Struct Size: 0x528
struct UChaGABP_Death_C : UChaGA_Death {
};

