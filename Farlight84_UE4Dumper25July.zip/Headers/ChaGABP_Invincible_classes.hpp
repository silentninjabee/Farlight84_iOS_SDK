#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGABP_Invincible.ChaGABP_Invincible_C
// Inherited Bytes: 0x528 | Struct Size: 0x528
struct UChaGABP_Invincible_C : UChaGA_Invincible {
};

