#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGABP_JetSlowFalling.ChaGABP_JetSlowFalling_C
// Inherited Bytes: 0x528 | Struct Size: 0x528
struct UChaGABP_JetSlowFalling_C : UChaGA_JetSlowFalling {
};

