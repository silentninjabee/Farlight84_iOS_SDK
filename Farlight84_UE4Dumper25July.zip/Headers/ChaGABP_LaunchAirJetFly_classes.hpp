#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGABP_LaunchAirJetFly.ChaGABP_LaunchAirJetFly_C
// Inherited Bytes: 0x540 | Struct Size: 0x540
struct UChaGABP_LaunchAirJetFly_C : UChaGA_LaunchAirJetFly {
};

