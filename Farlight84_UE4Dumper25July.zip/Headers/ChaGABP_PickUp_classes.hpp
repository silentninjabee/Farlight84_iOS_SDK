#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGABP_PickUp.ChaGABP_PickUp_C
// Inherited Bytes: 0x578 | Struct Size: 0x578
struct UChaGABP_PickUp_C : UChaGA_PickUp {
};

