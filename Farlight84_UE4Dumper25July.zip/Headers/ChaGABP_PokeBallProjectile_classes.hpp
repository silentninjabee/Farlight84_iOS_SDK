#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGABP_PokeBallProjectile.ChaGABP_PokeBallProjectile_C
// Inherited Bytes: 0xa00 | Struct Size: 0xa00
struct UChaGABP_PokeBallProjectile_C : USolarSkillGA_Projectile {
};

