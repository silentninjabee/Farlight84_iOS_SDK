#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGABP_SkydiveFly.ChaGABP_SkydiveFly_C
// Inherited Bytes: 0x570 | Struct Size: 0x570
struct UChaGABP_SkydiveFly_C : UChaGA_SkydiveFly {
};

