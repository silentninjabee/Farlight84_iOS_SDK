#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGABP_SlideTackle.ChaGABP_SlideTackle_C
// Inherited Bytes: 0x560 | Struct Size: 0x560
struct UChaGABP_SlideTackle_C : UChaGA_SlideTackle {
};

