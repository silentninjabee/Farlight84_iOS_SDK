#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGABP_Swap.ChaGABP_Swap_C
// Inherited Bytes: 0x528 | Struct Size: 0x528
struct UChaGABP_Swap_C : UChaGA_Swap {
};

