#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGABP_Treat.ChaGABP_Treat_C
// Inherited Bytes: 0x550 | Struct Size: 0x550
struct UChaGABP_Treat_C : UChaGA_Treat {
};

