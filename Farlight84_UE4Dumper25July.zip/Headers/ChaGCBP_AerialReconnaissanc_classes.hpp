#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGCBP_AerialReconnaissanc.ChaGCBP_AerialReconnaissanc_C
// Inherited Bytes: 0x3a8 | Struct Size: 0x3b0
struct AChaGCBP_AerialReconnaissanc_C : AChaGC_AerialReconnaissanc {
	// Fields
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x3a8 | Size: 0x8
};

