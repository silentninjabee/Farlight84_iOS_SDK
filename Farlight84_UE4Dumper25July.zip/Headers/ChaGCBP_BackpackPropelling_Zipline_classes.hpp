#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGCBP_BackpackPropelling_Zipline.ChaGCBP_BackpackPropelling_Zipline_C
// Inherited Bytes: 0x78 | Struct Size: 0x78
struct UChaGCBP_BackpackPropelling_Zipline_C : UChaGC_BackpackPropelling {
};

