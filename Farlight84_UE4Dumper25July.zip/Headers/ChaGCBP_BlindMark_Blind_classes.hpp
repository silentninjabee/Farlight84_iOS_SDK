#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGCBP_BlindMark_Blind.ChaGCBP_BlindMark_Blind_C
// Inherited Bytes: 0x3a0 | Struct Size: 0x3a9
struct AChaGCBP_BlindMark_Blind_C : AChaGC_CharacterActorCueBase {
	// Fields
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x3a0 | Size: 0x8
	bool HasSetLowPassFilter; // Offset: 0x3a8 | Size: 0x1

	// Functions

	// Object: Function ChaGCBP_BlindMark_Blind.ChaGCBP_BlindMark_Blind_C.OnRemoveInternal
	// Flags: [Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(3) Size(0xd9) ]
	bool OnRemoveInternal(struct ASolarCharacter* NullableCharacter, struct FGameplayCueParameters& Parameters);

	// Object: Function ChaGCBP_BlindMark_Blind.ChaGCBP_BlindMark_Blind_C.WhileActiveInternal
	// Flags: [Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(3) Size(0xd9) ]
	bool WhileActiveInternal(struct ASolarCharacter* Character, struct FGameplayCueParameters& Parameters);
};

