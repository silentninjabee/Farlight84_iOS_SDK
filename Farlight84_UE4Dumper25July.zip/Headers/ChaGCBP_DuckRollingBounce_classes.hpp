#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGCBP_DuckRollingBounce.ChaGCBP_DuckRollingBounce_C
// Inherited Bytes: 0x3a0 | Struct Size: 0x3b0
struct AChaGCBP_DuckRollingBounce_C : AChaGC_CharacterActorCueBase {
	// Fields
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x3a0 | Size: 0x8
	struct UParticleSystem* ParticleAsset; // Offset: 0x3a8 | Size: 0x8

	// Functions

	// Object: Function ChaGCBP_DuckRollingBounce.ChaGCBP_DuckRollingBounce_C.OnExecuteInternal
	// Flags: [Event|Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(3) Size(0xd9) ]
	bool OnExecuteInternal(struct ASolarCharacter* Character, struct FGameplayCueParameters& Parameters);
};

