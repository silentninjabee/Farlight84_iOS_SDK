#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGCBP_SkywardDiveScoutShow.ChaGCBP_SkywardDiveScoutShow_C
// Inherited Bytes: 0x2e8 | Struct Size: 0x2f0
struct AChaGCBP_SkywardDiveScoutShow_C : AChaGC_SkywardDiveScoutShow {
	// Fields
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x2e8 | Size: 0x8
};

