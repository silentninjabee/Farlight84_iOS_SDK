#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGCBP_SlideTacklePropelling.ChaGCBP_SlideTacklePropelling_C
// Inherited Bytes: 0x78 | Struct Size: 0x78
struct UChaGCBP_SlideTacklePropelling_C : UChaGC_BackpackPropelling {
};

