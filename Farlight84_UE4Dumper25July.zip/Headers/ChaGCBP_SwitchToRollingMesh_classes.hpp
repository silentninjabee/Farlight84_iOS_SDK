#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGCBP_SwitchToRollingMesh.ChaGCBP_SwitchToRollingMesh_C
// Inherited Bytes: 0x3a0 | Struct Size: 0x461
struct AChaGCBP_SwitchToRollingMesh_C : AChaGC_SwitchToDuckRollingMesh {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x3a0 | Size: 0x8
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x3a8 | Size: 0x8
	float Timeline_In_FxFade_8BBDA8D746ED656413E1B4B6DF587EEF; // Offset: 0x3b0 | Size: 0x4
	enum class ETimelineDirection Timeline_In__Direction_8BBDA8D746ED656413E1B4B6DF587EEF; // Offset: 0x3b4 | Size: 0x1
	char pad_0x3B5[0x3]; // Offset: 0x3b5 | Size: 0x3
	struct UTimelineComponent* Timeline_In; // Offset: 0x3b8 | Size: 0x8
	float Timeline_out_FxFade_9284E6954ADCE205A6F32C8A9F13E5CB; // Offset: 0x3c0 | Size: 0x4
	enum class ETimelineDirection Timeline_out__Direction_9284E6954ADCE205A6F32C8A9F13E5CB; // Offset: 0x3c4 | Size: 0x1
	char pad_0x3C5[0x3]; // Offset: 0x3c5 | Size: 0x3
	struct UTimelineComponent* Timeline_out; // Offset: 0x3c8 | Size: 0x8
	struct UParticleSystem* SmokeParticleAsset; // Offset: 0x3d0 | Size: 0x8
	char pad_0x3D8[0x8]; // Offset: 0x3d8 | Size: 0x8
	struct FTransform SmokeParticleRelativeTransform; // Offset: 0x3e0 | Size: 0x30
	struct UB_DuckRollingMeshComponent_C* MeshComponent; // Offset: 0x410 | Size: 0x8
	struct UParticleSystemComponent*  ParticleComponent; // Offset: 0x418 | Size: 0x8
	struct UCurveFloat* SpeedToSmokeRatCurve; // Offset: 0x420 | Size: 0x8
	struct UCurveFloat* SpeedToFxRatCurve; // Offset: 0x428 | Size: 0x8
	bool IsPlayingRolingLoop; // Offset: 0x430 | Size: 0x1
	bool IsPlayingAirLoop; // Offset: 0x431 | Size: 0x1
	char pad_0x432[0x6]; // Offset: 0x432 | Size: 0x6
	struct ASolarCharacter* SolarCharacter; // Offset: 0x438 | Size: 0x8
	struct FSoundGroupPlayContext StartRollingLoopContext; // Offset: 0x440 | Size: 0x10
	struct FSoundGroupPlayContext StartAirLoopContext; // Offset: 0x450 | Size: 0x10
	bool CanRemove; // Offset: 0x460 | Size: 0x1

	// Functions

	// Object: Function ChaGCBP_SwitchToRollingMesh.ChaGCBP_SwitchToRollingMesh_C.TryStopAirLoop
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void TryStopAirLoop();

	// Object: Function ChaGCBP_SwitchToRollingMesh.ChaGCBP_SwitchToRollingMesh_C.TryStopRollingLoop
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void TryStopRollingLoop();

	// Object: Function ChaGCBP_SwitchToRollingMesh.ChaGCBP_SwitchToRollingMesh_C.TryStartAirLoop
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void TryStartAirLoop();

	// Object: Function ChaGCBP_SwitchToRollingMesh.ChaGCBP_SwitchToRollingMesh_C.TryStartRollingLoop
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void TryStartRollingLoop();

	// Object: Function ChaGCBP_SwitchToRollingMesh.ChaGCBP_SwitchToRollingMesh_C.StopLoopSound
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void StopLoopSound();

	// Object: Function ChaGCBP_SwitchToRollingMesh.ChaGCBP_SwitchToRollingMesh_C.UpdateRollingSound
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void UpdateRollingSound();

	// Object: Function ChaGCBP_SwitchToRollingMesh.ChaGCBP_SwitchToRollingMesh_C.UpdateParticleParamsBySpeed
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x4) ]
	void UpdateParticleParamsBySpeed(float Speed);

	// Object: Function ChaGCBP_SwitchToRollingMesh.ChaGCBP_SwitchToRollingMesh_C.OnRemoveInternal
	// Flags: [Event|Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(3) Size(0xd9) ]
	bool OnRemoveInternal(struct ASolarCharacter* NullableCharacter, struct FGameplayCueParameters& Parameters);

	// Object: Function ChaGCBP_SwitchToRollingMesh.ChaGCBP_SwitchToRollingMesh_C.WhileActiveInternal
	// Flags: [Event|Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(3) Size(0xd9) ]
	bool WhileActiveInternal(struct ASolarCharacter* Character, struct FGameplayCueParameters& Parameters);

	// Object: Function ChaGCBP_SwitchToRollingMesh.ChaGCBP_SwitchToRollingMesh_C.OnActiveInternal
	// Flags: [Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(3) Size(0xd9) ]
	bool OnActiveInternal(struct ASolarCharacter* Character, struct FGameplayCueParameters& Parameters);

	// Object: Function ChaGCBP_SwitchToRollingMesh.ChaGCBP_SwitchToRollingMesh_C.Timeline_In__FinishedFunc
	// Flags: [BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void Timeline_In__FinishedFunc();

	// Object: Function ChaGCBP_SwitchToRollingMesh.ChaGCBP_SwitchToRollingMesh_C.Timeline_In__UpdateFunc
	// Flags: [BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void Timeline_In__UpdateFunc();

	// Object: Function ChaGCBP_SwitchToRollingMesh.ChaGCBP_SwitchToRollingMesh_C.Timeline_out__FinishedFunc
	// Flags: [BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void Timeline_out__FinishedFunc();

	// Object: Function ChaGCBP_SwitchToRollingMesh.ChaGCBP_SwitchToRollingMesh_C.Timeline_out__UpdateFunc
	// Flags: [BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void Timeline_out__UpdateFunc();

	// Object: Function ChaGCBP_SwitchToRollingMesh.ChaGCBP_SwitchToRollingMesh_C.ReceiveTick
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x4) ]
	void ReceiveTick(float DeltaSeconds);

	// Object: Function ChaGCBP_SwitchToRollingMesh.ChaGCBP_SwitchToRollingMesh_C.ReceiveEndPlay
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x1) ]
	void ReceiveEndPlay(enum class EEndPlayReason EndPlayReason);

	// Object: Function ChaGCBP_SwitchToRollingMesh.ChaGCBP_SwitchToRollingMesh_C.FadeIn
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void FadeIn();

	// Object: Function ChaGCBP_SwitchToRollingMesh.ChaGCBP_SwitchToRollingMesh_C.FadeOut
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void FadeOut();

	// Object: Function ChaGCBP_SwitchToRollingMesh.ChaGCBP_SwitchToRollingMesh_C.ExecuteUbergraph_ChaGCBP_SwitchToRollingMesh
	// Flags: [Final|UbergraphFunction|HasDefaults]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_ChaGCBP_SwitchToRollingMesh(int32_t EntryPoint);
};

