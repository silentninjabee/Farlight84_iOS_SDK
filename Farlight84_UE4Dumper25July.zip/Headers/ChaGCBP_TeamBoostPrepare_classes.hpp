#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGCBP_TeamBoostPrepare.ChaGCBP_TeamBoostPrepare_C
// Inherited Bytes: 0x3a0 | Struct Size: 0x3a8
struct AChaGCBP_TeamBoostPrepare_C : AChaGC_CharacterActorCueBase {
	// Fields
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x3a0 | Size: 0x8
};

