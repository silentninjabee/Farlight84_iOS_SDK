#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGEBP_HoldingSkill_Tactical_3.ChaGEBP_HoldingSkill_Tactical_2_C
// Inherited Bytes: 0x878 | Struct Size: 0x878
struct UChaGEBP_HoldingSkill_Tactical_2_C : UGameplayEffect {
};

