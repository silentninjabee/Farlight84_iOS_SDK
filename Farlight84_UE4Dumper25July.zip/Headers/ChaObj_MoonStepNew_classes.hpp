#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaObj_MoonStepNew.ChaObj_MoonStepNew_C
// Inherited Bytes: 0x650 | Struct Size: 0x650
struct UChaObj_MoonStepNew_C : UMoonStepStateObj {
};

