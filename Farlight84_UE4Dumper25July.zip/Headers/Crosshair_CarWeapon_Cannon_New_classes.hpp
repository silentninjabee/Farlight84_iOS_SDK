#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass Crosshair_CarWeapon_Cannon_New.Crosshair_CarWeapon_Cannon_New_C
// Inherited Bytes: 0x750 | Struct Size: 0x778
struct UCrosshair_CarWeapon_Cannon_New_C : UVehicleWeaponCrossHairWidget {
	// Fields
	struct UWidgetAnimation* Anim_CD_Out; // Offset: 0x750 | Size: 0x8
	struct UWidgetAnimation* Anim_CD_Enter; // Offset: 0x758 | Size: 0x8
	struct UCanvasPanel* Canvas_Dynamic; // Offset: 0x760 | Size: 0x8
	struct UImage* ReticleDirection; // Offset: 0x768 | Size: 0x8
	struct UImage* SpreadImg_coredot; // Offset: 0x770 | Size: 0x8

	// Functions

	// Object: Function Crosshair_CarWeapon_Cannon_New.Crosshair_CarWeapon_Cannon_New_C.SetWidgetResources
	// Flags: [Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(7) Size(0x38) ]
	void SetWidgetResources(struct UCanvasPanel*& InSecondReticlePanel, struct UImage*& InReticleDirectionImage, struct UImage*& InRangedImage, struct USizeBox*& InAssistLockSizeBox, struct UCanvasPanel*& InChangeNewAssistLockPawnPanel, struct UCanvasPanel*& InEnterLockPawnPanel, struct UCanvasPanel*& InCanvas_Dynamic);
};

