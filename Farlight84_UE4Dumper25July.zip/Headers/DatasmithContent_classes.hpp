#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class DatasmithContent.DatasmithObjectTemplate
// Inherited Bytes: 0x28 | Struct Size: 0x30
struct UDatasmithObjectTemplate : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
};

// Object: Class DatasmithContent.DatasmithActorTemplate
// Inherited Bytes: 0x30 | Struct Size: 0xd0
struct UDatasmithActorTemplate : UDatasmithObjectTemplate {
	// Fields
	struct TSet<struct FName> Layers; // Offset: 0x30 | Size: 0x50
	struct TSet<struct FName> Tags; // Offset: 0x80 | Size: 0x50
};

// Object: Class DatasmithContent.DatasmithAdditionalData
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UDatasmithAdditionalData : UObject {
};

// Object: Class DatasmithContent.DatasmithAreaLightActor
// Inherited Bytes: 0x248 | Struct Size: 0x2a0
struct ADatasmithAreaLightActor : AActor {
	// Fields
	enum class EDatasmithAreaLightActorType LightType; // Offset: 0x248 | Size: 0x1
	enum class EDatasmithAreaLightActorShape LightShape; // Offset: 0x249 | Size: 0x1
	char pad_0x24A[0x2]; // Offset: 0x24a | Size: 0x2
	struct FVector2D Dimensions; // Offset: 0x24c | Size: 0x8
	float Intensity; // Offset: 0x254 | Size: 0x4
	enum class ELightUnits IntensityUnits; // Offset: 0x258 | Size: 0x1
	char pad_0x259[0x3]; // Offset: 0x259 | Size: 0x3
	struct FLinearColor Color; // Offset: 0x25c | Size: 0x10
	float Temperature; // Offset: 0x26c | Size: 0x4
	struct UTextureLightProfile* IESTexture; // Offset: 0x270 | Size: 0x8
	bool bUseIESBrightness; // Offset: 0x278 | Size: 0x1
	char pad_0x279[0x3]; // Offset: 0x279 | Size: 0x3
	float IESBrightnessScale; // Offset: 0x27c | Size: 0x4
	struct FRotator Rotation; // Offset: 0x280 | Size: 0xc
	float SourceRadius; // Offset: 0x28c | Size: 0x4
	float SourceLength; // Offset: 0x290 | Size: 0x4
	float AttenuationRadius; // Offset: 0x294 | Size: 0x4
	float SpotlightInnerAngle; // Offset: 0x298 | Size: 0x4
	float SpotlightOuterAngle; // Offset: 0x29c | Size: 0x4
};

// Object: Class DatasmithContent.DatasmithAreaLightActorTemplate
// Inherited Bytes: 0x30 | Struct Size: 0x98
struct UDatasmithAreaLightActorTemplate : UDatasmithObjectTemplate {
	// Fields
	enum class EDatasmithAreaLightActorType LightType; // Offset: 0x29 | Size: 0x1
	enum class EDatasmithAreaLightActorShape LightShape; // Offset: 0x2a | Size: 0x1
	struct FVector2D Dimensions; // Offset: 0x2c | Size: 0x8
	struct FLinearColor Color; // Offset: 0x34 | Size: 0x10
	float Intensity; // Offset: 0x44 | Size: 0x4
	enum class ELightUnits IntensityUnits; // Offset: 0x48 | Size: 0x1
	float Temperature; // Offset: 0x4c | Size: 0x4
	struct TSoftObjectPtr<UTextureLightProfile> IESTexture; // Offset: 0x50 | Size: 0x28
	bool bUseIESBrightness; // Offset: 0x78 | Size: 0x1
	float IESBrightnessScale; // Offset: 0x7c | Size: 0x4
	struct FRotator Rotation; // Offset: 0x80 | Size: 0xc
	float SourceRadius; // Offset: 0x8c | Size: 0x4
	float SourceLength; // Offset: 0x90 | Size: 0x4
	float AttenuationRadius; // Offset: 0x94 | Size: 0x4
};

// Object: Class DatasmithContent.DatasmithAssetImportData
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UDatasmithAssetImportData : UAssetImportData {
};

// Object: Class DatasmithContent.DatasmithStaticMeshImportData
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UDatasmithStaticMeshImportData : UDatasmithAssetImportData {
};

// Object: Class DatasmithContent.DatasmithStaticMeshCADImportData
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UDatasmithStaticMeshCADImportData : UDatasmithStaticMeshImportData {
};

// Object: Class DatasmithContent.DatasmithSceneImportData
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UDatasmithSceneImportData : UAssetImportData {
};

// Object: Class DatasmithContent.DatasmithTranslatedSceneImportData
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UDatasmithTranslatedSceneImportData : UDatasmithSceneImportData {
};

// Object: Class DatasmithContent.DatasmithCADImportSceneData
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UDatasmithCADImportSceneData : UDatasmithSceneImportData {
};

// Object: Class DatasmithContent.DatasmithMDLSceneImportData
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UDatasmithMDLSceneImportData : UDatasmithSceneImportData {
};

// Object: Class DatasmithContent.DatasmithGLTFSceneImportData
// Inherited Bytes: 0x28 | Struct Size: 0x70
struct UDatasmithGLTFSceneImportData : UDatasmithSceneImportData {
	// Fields
	struct FString Generator; // Offset: 0x28 | Size: 0x10
	float Version; // Offset: 0x38 | Size: 0x4
	char pad_0x3C[0x4]; // Offset: 0x3c | Size: 0x4
	struct FString Author; // Offset: 0x40 | Size: 0x10
	struct FString License; // Offset: 0x50 | Size: 0x10
	struct FString Source; // Offset: 0x60 | Size: 0x10
};

// Object: Class DatasmithContent.DatasmithStaticMeshGLTFImportData
// Inherited Bytes: 0x28 | Struct Size: 0x38
struct UDatasmithStaticMeshGLTFImportData : UDatasmithStaticMeshImportData {
	// Fields
	struct FString SourceMeshName; // Offset: 0x28 | Size: 0x10
};

// Object: Class DatasmithContent.DatasmithFBXSceneImportData
// Inherited Bytes: 0x28 | Struct Size: 0x48
struct UDatasmithFBXSceneImportData : UDatasmithSceneImportData {
	// Fields
	bool bGenerateLightmapUVs; // Offset: 0x28 | Size: 0x1
	char pad_0x29[0x7]; // Offset: 0x29 | Size: 0x7
	struct FString TexturesDir; // Offset: 0x30 | Size: 0x10
	char IntermediateSerialization; // Offset: 0x40 | Size: 0x1
	bool bColorizeMaterials; // Offset: 0x41 | Size: 0x1
	char pad_0x42[0x6]; // Offset: 0x42 | Size: 0x6
};

// Object: Class DatasmithContent.DatasmithDeltaGenAssetImportData
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UDatasmithDeltaGenAssetImportData : UDatasmithAssetImportData {
};

// Object: Class DatasmithContent.DatasmithDeltaGenSceneImportData
// Inherited Bytes: 0x48 | Struct Size: 0x88
struct UDatasmithDeltaGenSceneImportData : UDatasmithFBXSceneImportData {
	// Fields
	bool bMergeNodes; // Offset: 0x42 | Size: 0x1
	bool bOptimizeDuplicatedNodes; // Offset: 0x43 | Size: 0x1
	bool bRemoveInvisibleNodes; // Offset: 0x44 | Size: 0x1
	bool bSimplifyNodeHierarchy; // Offset: 0x45 | Size: 0x1
	bool bImportVar; // Offset: 0x46 | Size: 0x1
	struct FString VarPath; // Offset: 0x48 | Size: 0x10
	bool bImportPos; // Offset: 0x58 | Size: 0x1
	char pad_0x5E[0x2]; // Offset: 0x5e | Size: 0x2
	struct FString PosPath; // Offset: 0x60 | Size: 0x10
	bool bImportTml; // Offset: 0x70 | Size: 0x1
	char pad_0x71[0x7]; // Offset: 0x71 | Size: 0x7
	struct FString TmlPath; // Offset: 0x78 | Size: 0x10
};

// Object: Class DatasmithContent.DatasmithVREDAssetImportData
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UDatasmithVREDAssetImportData : UDatasmithAssetImportData {
};

// Object: Class DatasmithContent.DatasmithVREDSceneImportData
// Inherited Bytes: 0x48 | Struct Size: 0xa0
struct UDatasmithVREDSceneImportData : UDatasmithFBXSceneImportData {
	// Fields
	bool bMergeNodes; // Offset: 0x42 | Size: 0x1
	bool bOptimizeDuplicatedNodes; // Offset: 0x43 | Size: 0x1
	bool bImportMats; // Offset: 0x44 | Size: 0x1
	struct FString MatsPath; // Offset: 0x48 | Size: 0x10
	bool bImportVar; // Offset: 0x58 | Size: 0x1
	bool bCleanVar; // Offset: 0x59 | Size: 0x1
	char pad_0x5D[0x3]; // Offset: 0x5d | Size: 0x3
	struct FString VarPath; // Offset: 0x60 | Size: 0x10
	bool bImportLightInfo; // Offset: 0x70 | Size: 0x1
	char pad_0x71[0x7]; // Offset: 0x71 | Size: 0x7
	struct FString LightInfoPath; // Offset: 0x78 | Size: 0x10
	bool bImportClipInfo; // Offset: 0x88 | Size: 0x1
	char pad_0x89[0x7]; // Offset: 0x89 | Size: 0x7
	struct FString ClipInfoPath; // Offset: 0x90 | Size: 0x10
};

// Object: Class DatasmithContent.DatasmithIFCSceneImportData
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UDatasmithIFCSceneImportData : UDatasmithSceneImportData {
};

// Object: Class DatasmithContent.DatasmithStaticMeshIFCImportData
// Inherited Bytes: 0x28 | Struct Size: 0x38
struct UDatasmithStaticMeshIFCImportData : UDatasmithStaticMeshImportData {
	// Fields
	struct FString SourceGlobalId; // Offset: 0x28 | Size: 0x10
};

// Object: Class DatasmithContent.DatasmithAssetUserData
// Inherited Bytes: 0x28 | Struct Size: 0x78
struct UDatasmithAssetUserData : UAssetUserData {
	// Fields
	struct TMap<struct FName, struct FString> MetaData; // Offset: 0x28 | Size: 0x50
};

// Object: Class DatasmithContent.DatasmithCineCameraActorTemplate
// Inherited Bytes: 0x30 | Struct Size: 0x60
struct UDatasmithCineCameraActorTemplate : UDatasmithObjectTemplate {
	// Fields
	struct FDatasmithCameraLookatTrackingSettingsTemplate LookatTrackingSettings; // Offset: 0x30 | Size: 0x30
};

// Object: Class DatasmithContent.DatasmithCineCameraComponentTemplate
// Inherited Bytes: 0x30 | Struct Size: 0x90
struct UDatasmithCineCameraComponentTemplate : UDatasmithObjectTemplate {
	// Fields
	struct FDatasmithCameraFilmbackSettingsTemplate FilmbackSettings; // Offset: 0x2c | Size: 0x8
	struct FDatasmithCameraLensSettingsTemplate LensSettings; // Offset: 0x34 | Size: 0x4
	struct FDatasmithCameraFocusSettingsTemplate FocusSettings; // Offset: 0x38 | Size: 0x8
	float CurrentFocalLength; // Offset: 0x40 | Size: 0x4
	float CurrentAperture; // Offset: 0x44 | Size: 0x4
	char pad_0x4C[0x4]; // Offset: 0x4c | Size: 0x4
	struct FDatasmithPostProcessSettingsTemplate PostProcessSettings; // Offset: 0x50 | Size: 0x40
};

// Object: Class DatasmithContent.DatasmithContentBlueprintLibrary
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UDatasmithContentBlueprintLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object: Function DatasmithContent.DatasmithContentBlueprintLibrary.GetDatasmithUserDataValueForKey
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102a75bb4
	// Return & Params: [ Num(3) Size(0x20) ]
	struct FString GetDatasmithUserDataValueForKey(struct UObject* Object, struct FName Key);

	// Object: Function DatasmithContent.DatasmithContentBlueprintLibrary.GetDatasmithUserDataKeysAndValuesForValue
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102a75a88
	// Return & Params: [ Num(4) Size(0x38) ]
	void GetDatasmithUserDataKeysAndValuesForValue(struct UObject* Object, struct FString StringToMatch, struct TArray<struct FName>& OutKeys, struct TArray<struct FString>& OutValues);

	// Object: Function DatasmithContent.DatasmithContentBlueprintLibrary.GetDatasmithUserData
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102a75c94
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UDatasmithAssetUserData* GetDatasmithUserData(struct UObject* Object);
};

// Object: Class DatasmithContent.DatasmithCustomActionBase
// Inherited Bytes: 0x28 | Struct Size: 0x30
struct UDatasmithCustomActionBase : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
};

// Object: Class DatasmithContent.DatasmithImportedSequencesActor
// Inherited Bytes: 0x248 | Struct Size: 0x258
struct ADatasmithImportedSequencesActor : AActor {
	// Fields
	struct TArray<struct ULevelSequence*> ImportedSequences; // Offset: 0x248 | Size: 0x10

	// Functions

	// Object: Function DatasmithContent.DatasmithImportedSequencesActor.PlayLevelSequence
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102a75e5c
	// Return & Params: [ Num(1) Size(0x8) ]
	void PlayLevelSequence(struct ULevelSequence* SequenceToPlay);
};

// Object: Class DatasmithContent.DatasmithOptionsBase
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UDatasmithOptionsBase : UObject {
};

// Object: Class DatasmithContent.DatasmithCommonTessellationOptions
// Inherited Bytes: 0x28 | Struct Size: 0x38
struct UDatasmithCommonTessellationOptions : UDatasmithOptionsBase {
	// Fields
	struct FDatasmithTessellationOptions options; // Offset: 0x28 | Size: 0x10
};

// Object: Class DatasmithContent.DatasmithImportOptions
// Inherited Bytes: 0x28 | Struct Size: 0x78
struct UDatasmithImportOptions : UDatasmithOptionsBase {
	// Fields
	enum class EDatasmithImportSearchPackagePolicy SearchPackagePolicy; // Offset: 0x28 | Size: 0x1
	enum class EDatasmithImportAssetConflictPolicy MaterialConflictPolicy; // Offset: 0x29 | Size: 0x1
	enum class EDatasmithImportAssetConflictPolicy TextureConflictPolicy; // Offset: 0x2a | Size: 0x1
	enum class EDatasmithImportActorPolicy StaticMeshActorImportPolicy; // Offset: 0x2b | Size: 0x1
	enum class EDatasmithImportActorPolicy LightImportPolicy; // Offset: 0x2c | Size: 0x1
	enum class EDatasmithImportActorPolicy CameraImportPolicy; // Offset: 0x2d | Size: 0x1
	enum class EDatasmithImportActorPolicy OtherActorImportPolicy; // Offset: 0x2e | Size: 0x1
	enum class EDatasmithImportMaterialQuality MaterialQuality; // Offset: 0x2f | Size: 0x1
	char pad_0x30[0x4]; // Offset: 0x30 | Size: 0x4
	struct FDatasmithImportBaseOptions BaseOptions; // Offset: 0x34 | Size: 0x14
	struct FDatasmithReimportOptions ReimportOptions; // Offset: 0x48 | Size: 0x2
	char pad_0x4A[0x6]; // Offset: 0x4a | Size: 0x6
	struct FString Filename; // Offset: 0x50 | Size: 0x10
	struct FString FilePath; // Offset: 0x60 | Size: 0x10
	char pad_0x70[0x8]; // Offset: 0x70 | Size: 0x8
};

// Object: Class DatasmithContent.DatasmithLandscapeTemplate
// Inherited Bytes: 0x30 | Struct Size: 0x40
struct UDatasmithLandscapeTemplate : UDatasmithObjectTemplate {
	// Fields
	struct UMaterialInterface* LandscapeMaterial; // Offset: 0x30 | Size: 0x8
	int32_t StaticLightingLOD; // Offset: 0x38 | Size: 0x4
	char pad_0x3C[0x4]; // Offset: 0x3c | Size: 0x4
};

// Object: Class DatasmithContent.DatasmithLightComponentTemplate
// Inherited Bytes: 0x30 | Struct Size: 0x58
struct UDatasmithLightComponentTemplate : UDatasmithObjectTemplate {
	// Fields
	char bVisible : 1; // Offset: 0x29 | Size: 0x1
	char CastShadows : 1; // Offset: 0x29 | Size: 0x1
	char bUseTemperature : 1; // Offset: 0x29 | Size: 0x1
	char bUseIESBrightness : 1; // Offset: 0x29 | Size: 0x1
	float Intensity; // Offset: 0x2c | Size: 0x4
	float Temperature; // Offset: 0x30 | Size: 0x4
	float IESBrightnessScale; // Offset: 0x34 | Size: 0x4
	struct FLinearColor LightColor; // Offset: 0x38 | Size: 0x10
	struct UMaterialInterface* LightFunctionMaterial; // Offset: 0x48 | Size: 0x8
	struct UTextureLightProfile* IESTexture; // Offset: 0x50 | Size: 0x8
};

// Object: Class DatasmithContent.DatasmithMaterialInstanceTemplate
// Inherited Bytes: 0x30 | Struct Size: 0x198
struct UDatasmithMaterialInstanceTemplate : UDatasmithObjectTemplate {
	// Fields
	struct TSoftObjectPtr<UMaterialInterface> ParentMaterial; // Offset: 0x30 | Size: 0x28
	struct TMap<struct FName, float> ScalarParameterValues; // Offset: 0x58 | Size: 0x50
	struct TMap<struct FName, struct FLinearColor> VectorParameterValues; // Offset: 0xa8 | Size: 0x50
	struct TMap<struct FName, struct TSoftObjectPtr<UTexture>> TextureParameterValues; // Offset: 0xf8 | Size: 0x50
	struct FDatasmithStaticParameterSetTemplate StaticParameters; // Offset: 0x148 | Size: 0x50
};

// Object: Class DatasmithContent.DatasmithPointLightComponentTemplate
// Inherited Bytes: 0x30 | Struct Size: 0x38
struct UDatasmithPointLightComponentTemplate : UDatasmithObjectTemplate {
	// Fields
	enum class ELightUnits IntensityUnits; // Offset: 0x29 | Size: 0x1
	float SourceRadius; // Offset: 0x2c | Size: 0x4
	float SourceLength; // Offset: 0x30 | Size: 0x4
	float AttenuationRadius; // Offset: 0x34 | Size: 0x4
};

// Object: Class DatasmithContent.DatasmithPostProcessVolumeTemplate
// Inherited Bytes: 0x30 | Struct Size: 0x80
struct UDatasmithPostProcessVolumeTemplate : UDatasmithObjectTemplate {
	// Fields
	struct FDatasmithPostProcessSettingsTemplate Settings; // Offset: 0x30 | Size: 0x40
	char bEnabled : 1; // Offset: 0x70 | Size: 0x1
	char bUnbound : 1; // Offset: 0x70 | Size: 0x1
	char pad_0x70_2 : 6; // Offset: 0x70 | Size: 0x1
	char pad_0x71[0xf]; // Offset: 0x71 | Size: 0xf
};

// Object: Class DatasmithContent.DatasmithScene
// Inherited Bytes: 0x28 | Struct Size: 0x30
struct UDatasmithScene : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
};

// Object: Class DatasmithContent.DatasmithSceneActor
// Inherited Bytes: 0x248 | Struct Size: 0x2a0
struct ADatasmithSceneActor : AActor {
	// Fields
	struct UDatasmithScene* Scene; // Offset: 0x248 | Size: 0x8
	struct TMap<struct FName, struct TSoftObjectPtr<AActor>> RelatedActors; // Offset: 0x250 | Size: 0x50
};

// Object: Class DatasmithContent.DatasmithSceneComponentTemplate
// Inherited Bytes: 0x30 | Struct Size: 0xe0
struct UDatasmithSceneComponentTemplate : UDatasmithObjectTemplate {
	// Fields
	struct FTransform RelativeTransform; // Offset: 0x30 | Size: 0x30
	enum class EComponentMobility Mobility; // Offset: 0x60 | Size: 0x1
	char pad_0x61[0x7]; // Offset: 0x61 | Size: 0x7
	struct TSoftObjectPtr<USceneComponent> AttachParent; // Offset: 0x68 | Size: 0x28
	struct TSet<struct FName> Tags; // Offset: 0x90 | Size: 0x50
};

// Object: Class DatasmithContent.DatasmithSkyLightComponentTemplate
// Inherited Bytes: 0x30 | Struct Size: 0x38
struct UDatasmithSkyLightComponentTemplate : UDatasmithObjectTemplate {
	// Fields
	enum class ESkyLightSourceType SourceType; // Offset: 0x29 | Size: 0x1
	int32_t CubemapResolution; // Offset: 0x2c | Size: 0x4
	struct UTextureCube* Cubemap; // Offset: 0x30 | Size: 0x8
};

// Object: Class DatasmithContent.DatasmithSpotLightComponentTemplate
// Inherited Bytes: 0x30 | Struct Size: 0x38
struct UDatasmithSpotLightComponentTemplate : UDatasmithObjectTemplate {
	// Fields
	float InnerConeAngle; // Offset: 0x2c | Size: 0x4
	float OuterConeAngle; // Offset: 0x30 | Size: 0x4
};

// Object: Class DatasmithContent.DatasmithStaticMeshComponentTemplate
// Inherited Bytes: 0x30 | Struct Size: 0x48
struct UDatasmithStaticMeshComponentTemplate : UDatasmithObjectTemplate {
	// Fields
	struct UStaticMesh* StaticMesh; // Offset: 0x30 | Size: 0x8
	struct TArray<struct UMaterialInterface*> OverrideMaterials; // Offset: 0x38 | Size: 0x10
};

// Object: Class DatasmithContent.DatasmithStaticMeshTemplate
// Inherited Bytes: 0x30 | Struct Size: 0xa8
struct UDatasmithStaticMeshTemplate : UDatasmithObjectTemplate {
	// Fields
	struct FDatasmithMeshSectionInfoMapTemplate SectionInfoMap; // Offset: 0x30 | Size: 0x50
	int32_t LightMapCoordinateIndex; // Offset: 0x80 | Size: 0x4
	int32_t LightMapResolution; // Offset: 0x84 | Size: 0x4
	struct TArray<struct FDatasmithMeshBuildSettingsTemplate> BuildSettings; // Offset: 0x88 | Size: 0x10
	struct TArray<struct FDatasmithStaticMaterialTemplate> StaticMaterials; // Offset: 0x98 | Size: 0x10
};

