#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: UserDefinedEnum E_Lobby_Ping_State.E_Lobby_Ping_State
enum class E_Lobby_Ping_State : uint8_t {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator2 = 2,
	E_Lobby_Ping_MAX = 3
};

