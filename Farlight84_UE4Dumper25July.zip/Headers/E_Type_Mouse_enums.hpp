#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: UserDefinedEnum E_Type_Mouse.E_Type_Mouse
enum class E_Type_Mouse : uint8_t {
	NewEnumerator5 = 0,
	NewEnumerator21 = 1,
	NewEnumerator22 = 2,
	NewEnumerator23 = 3,
	NewEnumerator24 = 4,
	NewEnumerator27 = 5,
	NewEnumerator25 = 6,
	NewEnumerator26 = 7,
	E_Type_MAX = 8
};

