#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: UserDefinedEnum E_Type_Version.E_Type_Version
enum class E_Type_Version : uint8_t {
	NewEnumerator3 = 0,
	NewEnumerator4 = 1,
	NewEnumerator0 = 2,
	NewEnumerator5 = 3,
	NewEnumerator7 = 4,
	NewEnumerator6 = 5,
	NewEnumerator1 = 6,
	NewEnumerator2 = 7,
	E_Type_MAX = 8
};

