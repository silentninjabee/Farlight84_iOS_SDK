#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass FL_ColorUtility.FL_ColorUtility_C
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UFL_ColorUtility_C : UBlueprintFunctionLibrary {
	// Functions

	// Object: Function FL_ColorUtility.FL_ColorUtility_C.GetLobbyQualityColor
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(5) Size(0x38) ]
	void GetLobbyQualityColor(enum class E_Item_Quality Quilty, struct UObject* Widget, struct UObject* __WorldContext, struct FLinearColor& TxtColor, struct FLinearColor& FrameColor);

	// Object: Function FL_ColorUtility.FL_ColorUtility_C.GetColor
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(3) Size(0x20) ]
	void GetColor(struct FName , struct UObject* __WorldContext, struct FLinearColor& Color);
};

