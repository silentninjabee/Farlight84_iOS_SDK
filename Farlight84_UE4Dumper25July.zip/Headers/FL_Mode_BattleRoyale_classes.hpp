#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass FL_Mode_BattleRoyale.FL_Mode_BattleRoyale_C
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UFL_Mode_BattleRoyale_C : UBlueprintFunctionLibrary {
	// Functions

	// Object: Function FL_Mode_BattleRoyale.FL_Mode_BattleRoyale_C.[s]UpdateTeamCountMax
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(2) Size(0xc) ]
	int32_t [s]UpdateTeamCountMax(struct UObject* __WorldContext);

	// Object: Function FL_Mode_BattleRoyale.FL_Mode_BattleRoyale_C.OutputLog
	// Flags: [Static|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(3) Size(0x60) ]
	void OutputLog(enum class E_BattleLog_BattleRoyale LogType, struct TMap<struct FString, struct FString> InputPin, struct UObject* __WorldContext);
};

