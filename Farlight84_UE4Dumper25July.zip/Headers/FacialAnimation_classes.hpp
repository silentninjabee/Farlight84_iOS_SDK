#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class FacialAnimation.AudioCurveSourceComponent
// Inherited Bytes: 0x950 | Struct Size: 0x990
struct UAudioCurveSourceComponent : UAudioComponent {
	// Fields
	struct FName CurveSourceBindingName; // Offset: 0x950 | Size: 0x8
	float CurveSyncOffset; // Offset: 0x958 | Size: 0x4
	char pad_0x95C[0x34]; // Offset: 0x95c | Size: 0x34
};

