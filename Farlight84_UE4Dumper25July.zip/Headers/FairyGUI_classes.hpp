#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class FairyGUI.DragDropManager
// Inherited Bytes: 0x28 | Struct Size: 0x48
struct UDragDropManager : UObject {
	// Fields
	struct UGLoader* Agent; // Offset: 0x28 | Size: 0x8
	char pad_0x30[0x18]; // Offset: 0x30 | Size: 0x18

	// Functions

	// Object: Function FairyGUI.DragDropManager.StartDrag
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102d3deec
	// Return & Params: [ Num(4) Size(0x30) ]
	void StartDrag(struct FString InIcon, struct FNVariant& InUserData, int32_t InUserIndex, int32_t InPointerIndex);

	// Object: Function FairyGUI.DragDropManager.IsDragging
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d3e048
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsDragging();

	// Object: Function FairyGUI.DragDropManager.GetAgent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d3e088
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UGLoader* GetAgent();

	// Object: Function FairyGUI.DragDropManager.Cancel
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d3dedc
	// Return & Params: [ Num(0) Size(0x0) ]
	void Cancel();
};

// Object: Class FairyGUI.EventContext
// Inherited Bytes: 0x28 | Struct Size: 0x78
struct UEventContext : UObject {
	// Fields
	char pad_0x28[0x50]; // Offset: 0x28 | Size: 0x50

	// Functions

	// Object: Function FairyGUI.EventContext.StopPropagation
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d3e218
	// Return & Params: [ Num(0) Size(0x0) ]
	void StopPropagation();

	// Object: Function FairyGUI.EventContext.PreventDefault
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d3e1e8
	// Return & Params: [ Num(0) Size(0x0) ]
	void PreventDefault();

	// Object: Function FairyGUI.EventContext.IsPropagationStopped
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d3e204
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsPropagationStopped();

	// Object: Function FairyGUI.EventContext.IsDoubleClick
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d3e24c
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsDoubleClick();

	// Object: Function FairyGUI.EventContext.IsDefaultPrevented
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d3e1d4
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsDefaultPrevented();

	// Object: Function FairyGUI.EventContext.GetWheelDelta
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d3e438
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetWheelDelta();

	// Object: Function FairyGUI.EventContext.GetUserIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d3e450
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetUserIndex();

	// Object: Function FairyGUI.EventContext.GetType
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d3e48c
	// Return & Params: [ Num(1) Size(0x8) ]
	struct FName GetType();

	// Object: Function FairyGUI.EventContext.GetSender
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d3e4b8
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UGObject* GetSender();

	// Object: Function FairyGUI.EventContext.GetPointerPosition
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d3e478
	// Return & Params: [ Num(1) Size(0x8) ]
	struct FVector2D GetPointerPosition();

	// Object: Function FairyGUI.EventContext.GetPointerIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d3e464
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetPointerIndex();

	// Object: Function FairyGUI.EventContext.GetPointerEvent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d3e330
	// Return & Params: [ Num(1) Size(0x70) ]
	struct FPointerEvent GetPointerEvent();

	// Object: Function FairyGUI.EventContext.GetMouseButton
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d3e348
	// Return & Params: [ Num(1) Size(0x18) ]
	struct FKey GetMouseButton();

	// Object: Function FairyGUI.EventContext.GetKeyEvent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d3e284
	// Return & Params: [ Num(1) Size(0x38) ]
	struct FKeyEvent GetKeyEvent();

	// Object: Function FairyGUI.EventContext.GetInitiator
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d3e4a0
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UGObject* GetInitiator();

	// Object: Function FairyGUI.EventContext.GetData
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d3e234
	// Return & Params: [ Num(1) Size(0x18) ]
	struct FNVariant GetData();

	// Object: Function FairyGUI.EventContext.GetClickCount
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d3e26c
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetClickCount();

	// Object: Function FairyGUI.EventContext.CaptureTouch
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d3e1b8
	// Return & Params: [ Num(0) Size(0x0) ]
	void CaptureTouch();
};

// Object: Class FairyGUI.FairyApplication
// Inherited Bytes: 0x28 | Struct Size: 0xc0
struct UFairyApplication : UObject {
	// Fields
	struct UGRoot* UIRoot; // Offset: 0x28 | Size: 0x8
	struct UDragDropManager* DragDropManager; // Offset: 0x30 | Size: 0x8
	struct TArray<struct UEventContext*> EventContextPool; // Offset: 0x38 | Size: 0x10
	char pad_0x48[0x78]; // Offset: 0x48 | Size: 0x78

	// Functions

	// Object: Function FairyGUI.FairyApplication.SetSoundVolumeScale
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d3e928
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetSoundVolumeScale(float InVolumeScale);

	// Object: Function FairyGUI.FairyApplication.SetSoundEnabled
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d3e99c
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetSoundEnabled(bool InEnabled);

	// Object: Function FairyGUI.FairyApplication.PlaySound
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d3ea0c
	// Return & Params: [ Num(2) Size(0x14) ]
	void PlaySound(struct FString URL, float VolumeScale);

	// Object: Function FairyGUI.FairyApplication.IsSoundEnabled
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d3e9f8
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsSoundEnabled();

	// Object: Function FairyGUI.FairyApplication.GetUIRoot
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d3ec54
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UGRoot* GetUIRoot();

	// Object: Function FairyGUI.FairyApplication.GetTouchPosition
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x102d3ebb0
	// Return & Params: [ Num(3) Size(0x10) ]
	struct FVector2D GetTouchPosition(int32_t InUserIndex, int32_t InPointerIndex);

	// Object: Function FairyGUI.FairyApplication.GetTouchCount
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d3eb8c
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetTouchCount();

	// Object: Function FairyGUI.FairyApplication.GetSoundVolumeScale
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d3e984
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetSoundVolumeScale();

	// Object: Function FairyGUI.FairyApplication.GetObjectUnderPoint
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102d3eb30
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UGObject* GetObjectUnderPoint(struct FVector2D& ScreenspacePosition);

	// Object: Function FairyGUI.FairyApplication.GetDragDropManager
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d3ec3c
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UDragDropManager* GetDragDropManager();

	// Object: Function FairyGUI.FairyApplication.Get
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x102d3ec78
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UFairyApplication* Get(struct UObject* WorldContextObject);

	// Object: Function FairyGUI.FairyApplication.CancelClick
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d3eaa8
	// Return & Params: [ Num(2) Size(0x8) ]
	void CancelClick(int32_t InUserIndex, int32_t InPointerIndex);
};

// Object: Class FairyGUI.FairyBlueprintLibrary
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UFairyBlueprintLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object: Function FairyGUI.FairyBlueprintLibrary.TweenVector2
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102d3f0bc
	// Return & Params: [ Num(8) Size(0x48) ]
	struct FTweenerHandle TweenVector2(struct FVector2D& StartValue, struct FVector2D& EndValue, enum class EEaseType EaseType, float Duration, int32_t Repeat, struct FDelegate& OnUpdate, struct FDelegate& OnComplete);

	// Object: Function FairyGUI.FairyBlueprintLibrary.TweenFloat
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102d3f2a4
	// Return & Params: [ Num(8) Size(0x40) ]
	struct FTweenerHandle TweenFloat(float StartValue, float EndValue, enum class EEaseType EaseType, float Duration, int32_t Repeat, struct FDelegate& OnUpdate, struct FDelegate& OnComplete);

	// Object: Function FairyGUI.FairyBlueprintLibrary.SetVariantUObject
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102d3f470
	// Return & Params: [ Num(3) Size(0x38) ]
	struct FNVariant SetVariantUObject(struct FNVariant& InVariant, struct UObject* InValue);

	// Object: Function FairyGUI.FairyBlueprintLibrary.SetVariantString
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102d3f5fc
	// Return & Params: [ Num(3) Size(0x40) ]
	struct FNVariant SetVariantString(struct FNVariant& InVariant, struct FString InValue);

	// Object: Function FairyGUI.FairyBlueprintLibrary.SetVariantInt
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102d3f7ac
	// Return & Params: [ Num(3) Size(0x38) ]
	struct FNVariant SetVariantInt(struct FNVariant& InVariant, int32_t InValue);

	// Object: Function FairyGUI.FairyBlueprintLibrary.SetVariantFloat
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102d3f6e8
	// Return & Params: [ Num(3) Size(0x38) ]
	struct FNVariant SetVariantFloat(struct FNVariant& InVariant, float InValue);

	// Object: Function FairyGUI.FairyBlueprintLibrary.SetVariantColor
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102d3f534
	// Return & Params: [ Num(3) Size(0x38) ]
	struct FNVariant SetVariantColor(struct FNVariant& InVariant, struct FColor& InValue);

	// Object: Function FairyGUI.FairyBlueprintLibrary.SetVariantBool
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102d3f880
	// Return & Params: [ Num(3) Size(0x38) ]
	struct FNVariant SetVariantBool(struct FNVariant& InVariant, bool bInValue);

	// Object: Function FairyGUI.FairyBlueprintLibrary.SetUIConfig
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102d3fd24
	// Return & Params: [ Num(1) Size(0xc0) ]
	void SetUIConfig(struct FUIConfig& InConfig);

	// Object: Function FairyGUI.FairyBlueprintLibrary.SetPackageItemExtension
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102d3efb0
	// Return & Params: [ Num(2) Size(0x18) ]
	void SetPackageItemExtension(struct FString URL, struct UGComponent* ClassType);

	// Object: Function FairyGUI.FairyBlueprintLibrary.KillTween
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102d3f030
	// Return & Params: [ Num(2) Size(0x9) ]
	void KillTween(struct FTweenerHandle& Handle, bool bSetComplete);

	// Object: Function FairyGUI.FairyBlueprintLibrary.GetVariantAsUObject
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x102d3f954
	// Return & Params: [ Num(3) Size(0x28) ]
	struct UObject* GetVariantAsUObject(struct FNVariant& InVariant, struct UObject* ClassType);

	// Object: Function FairyGUI.FairyBlueprintLibrary.GetVariantAsString
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x102d3faa4
	// Return & Params: [ Num(2) Size(0x28) ]
	struct FString GetVariantAsString(struct FNVariant& InVariant);

	// Object: Function FairyGUI.FairyBlueprintLibrary.GetVariantAsInt
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x102d3fc0c
	// Return & Params: [ Num(2) Size(0x1c) ]
	int32_t GetVariantAsInt(struct FNVariant& InVariant);

	// Object: Function FairyGUI.FairyBlueprintLibrary.GetVariantAsFloat
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x102d3fb80
	// Return & Params: [ Num(2) Size(0x1c) ]
	float GetVariantAsFloat(struct FNVariant& InVariant);

	// Object: Function FairyGUI.FairyBlueprintLibrary.GetVariantAsColor
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x102d3fa18
	// Return & Params: [ Num(2) Size(0x1c) ]
	struct FColor GetVariantAsColor(struct FNVariant& InVariant);

	// Object: Function FairyGUI.FairyBlueprintLibrary.GetVariantAsBool
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x102d3fc98
	// Return & Params: [ Num(2) Size(0x19) ]
	bool GetVariantAsBool(struct FNVariant& InVariant);

	// Object: Function FairyGUI.FairyBlueprintLibrary.GetUIConfig
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x102d3fd98
	// Return & Params: [ Num(1) Size(0xc0) ]
	struct FUIConfig GetUIConfig();
};

// Object: Class FairyGUI.GObject
// Inherited Bytes: 0x28 | Struct Size: 0x340
struct UGObject : UObject {
	// Fields
	struct FMulticastInlineDelegate OnClick; // Offset: 0x28 | Size: 0x10
	struct FMulticastInlineDelegate OnTouchBegin; // Offset: 0x38 | Size: 0x10
	struct FMulticastInlineDelegate OnTouchMove; // Offset: 0x48 | Size: 0x10
	struct FMulticastInlineDelegate OnTouchEnd; // Offset: 0x58 | Size: 0x10
	struct FMulticastInlineDelegate OnRollOver; // Offset: 0x68 | Size: 0x10
	struct FMulticastInlineDelegate OnRollOut; // Offset: 0x78 | Size: 0x10
	struct FMulticastInlineDelegate OnDragStart; // Offset: 0x88 | Size: 0x10
	struct FMulticastInlineDelegate OnDragMove; // Offset: 0x98 | Size: 0x10
	struct FMulticastInlineDelegate OnDragEnd; // Offset: 0xa8 | Size: 0x10
	struct FMulticastInlineDelegate OnGearStop; // Offset: 0xb8 | Size: 0x10
	struct FMulticastInlineDelegate OnAddedToStage; // Offset: 0xc8 | Size: 0x10
	struct FMulticastInlineDelegate OnRemovedFromStage; // Offset: 0xd8 | Size: 0x10
	struct FString ID; // Offset: 0xe8 | Size: 0x10
	struct FString Name; // Offset: 0xf8 | Size: 0x10
	struct FVector2D SourceSize; // Offset: 0x108 | Size: 0x8
	struct FVector2D InitSize; // Offset: 0x110 | Size: 0x8
	struct FVector2D MinSize; // Offset: 0x118 | Size: 0x8
	struct FVector2D MaxSize; // Offset: 0x120 | Size: 0x8
	struct FNVariant UserData; // Offset: 0x128 | Size: 0x18
	char pad_0x140[0x200]; // Offset: 0x140 | Size: 0x200

	// Functions

	// Object: Function FairyGUI.GObject.StopDrag
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d48748
	// Return & Params: [ Num(0) Size(0x0) ]
	void StopDrag();

	// Object: Function FairyGUI.GObject.StartDrag
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d48758
	// Return & Params: [ Num(2) Size(0x8) ]
	void StartDrag(int32_t UserIndex, int32_t PointerIndex);

	// Object: Function FairyGUI.GObject.SetYMin
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4916c
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetYMin(float InYMin);

	// Object: Function FairyGUI.GObject.SetY
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4927c
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetY(float InY);

	// Object: Function FairyGUI.GObject.SetXMin
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d491c8
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetXMin(float InXMin);

	// Object: Function FairyGUI.GObject.SetX
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d492c8
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetX(float InX);

	// Object: Function FairyGUI.GObject.SetWidth
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d49100
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetWidth(float InWidth);

	// Object: Function FairyGUI.GObject.SetVisible
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d48bdc
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetVisible(bool bInVisible);

	// Object: Function FairyGUI.GObject.SetTouchable
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d48b74
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetTouchable(bool bInTouchable);

	// Object: Function FairyGUI.GObject.SetTooltips
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d488a4
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetTooltips(struct FString InTooltips);

	// Object: Function FairyGUI.GObject.SetText
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102d48a08
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetText(struct FString InText);

	// Object: Function FairyGUI.GObject.SetSortingOrder
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d48b24
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetSortingOrder(int32_t InSortingOrder);

	// Object: Function FairyGUI.GObject.SetSkew
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102d48d34
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetSkew(struct FVector2D& InSkew);

	// Object: Function FairyGUI.GObject.SetSize
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102d48ff8
	// Return & Params: [ Num(2) Size(0x9) ]
	void SetSize(struct FVector2D& InSize, bool bIgnorePivot);

	// Object: Function FairyGUI.GObject.SetScaleY
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d48de4
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetScaleY(float InScaleY);

	// Object: Function FairyGUI.GObject.SetScaleX
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d48e50
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetScaleX(float InScaleX);

	// Object: Function FairyGUI.GObject.SetScale
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102d48d8c
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetScale(struct FVector2D& InScale);

	// Object: Function FairyGUI.GObject.SetRotation
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d48ce8
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetRotation(float InRotation);

	// Object: Function FairyGUI.GObject.SetPosition
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102d49224
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetPosition(struct FVector2D& InPosition);

	// Object: Function FairyGUI.GObject.SetPivot
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102d48ed4
	// Return & Params: [ Num(2) Size(0x9) ]
	void SetPivot(struct FVector2D& InPivot, bool bAsAnchor);

	// Object: Function FairyGUI.GObject.SetParentToRoot
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d482a0
	// Return & Params: [ Num(0) Size(0x0) ]
	void SetParentToRoot();

	// Object: Function FairyGUI.GObject.SetParent
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d482b0
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetParent(struct UGObject* InParent);

	// Object: Function FairyGUI.GObject.SetIcon
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102d48954
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetIcon(struct FString InIcon);

	// Object: Function FairyGUI.GObject.SetHeight
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d49094
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetHeight(float InHeight);

	// Object: Function FairyGUI.GObject.SetGroup
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d48abc
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetGroup(struct UGGroup* InGroup);

	// Object: Function FairyGUI.GObject.SetGrayed
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d48c3c
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetGrayed(bool bInGrayed);

	// Object: Function FairyGUI.GObject.SetDraggable
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d48844
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetDraggable(bool bInDraggable);

	// Object: Function FairyGUI.GObject.SetDragBounds
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102d487c8
	// Return & Params: [ Num(1) Size(0x14) ]
	void SetDragBounds(struct FBox2D& InBounds);

	// Object: Function FairyGUI.GObject.SetAlpha
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d48c9c
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetAlpha(float InAlpha);

	// Object: Function FairyGUI.GObject.RootToLocalRect
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102d48558
	// Return & Params: [ Num(2) Size(0x28) ]
	struct FBox2D RootToLocalRect(struct FBox2D& InRect);

	// Object: Function FairyGUI.GObject.RootToLocal
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102d4859c
	// Return & Params: [ Num(2) Size(0x10) ]
	struct FVector2D RootToLocal(struct FVector2D& InPoint);

	// Object: Function FairyGUI.GObject.RemoveRelation
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d48318
	// Return & Params: [ Num(2) Size(0x9) ]
	void RemoveRelation(struct UGObject* Obj, enum class ERelationType RelationType);

	// Object: Function FairyGUI.GObject.RemoveFromParent
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d48224
	// Return & Params: [ Num(0) Size(0x0) ]
	void RemoveFromParent();

	// Object: Function FairyGUI.GObject.OnTouchMoveHandler
	// Flags: [Final|Native|Private]
	// Offset: 0x102d48080
	// Return & Params: [ Num(1) Size(0x8) ]
	void OnTouchMoveHandler(struct UEventContext* Context);

	// Object: Function FairyGUI.GObject.OnTouchEndHandler
	// Flags: [Final|Native|Private]
	// Offset: 0x102d48040
	// Return & Params: [ Num(1) Size(0x8) ]
	void OnTouchEndHandler(struct UEventContext* Context);

	// Object: Function FairyGUI.GObject.OnTouchBeginHandler
	// Flags: [Final|Native|Private]
	// Offset: 0x102d480c0
	// Return & Params: [ Num(1) Size(0x8) ]
	void OnTouchBeginHandler(struct UEventContext* Context);

	// Object: Function FairyGUI.GObject.OnStage
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d48234
	// Return & Params: [ Num(1) Size(0x1) ]
	bool OnStage();

	// Object: Function FairyGUI.GObject.OnRollOverHandler
	// Flags: [Final|Native|Private]
	// Offset: 0x102d48140
	// Return & Params: [ Num(1) Size(0x8) ]
	void OnRollOverHandler(struct UEventContext* Context);

	// Object: Function FairyGUI.GObject.OnRollOutHandler
	// Flags: [Final|Native|Private]
	// Offset: 0x102d48100
	// Return & Params: [ Num(1) Size(0x8) ]
	void OnRollOutHandler(struct UEventContext* Context);

	// Object: Function FairyGUI.GObject.MakeFullScreen
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d48f70
	// Return & Params: [ Num(1) Size(0x1) ]
	void MakeFullScreen(bool bRestraint);

	// Object: Function FairyGUI.GObject.LocalToRootRect
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102d48440
	// Return & Params: [ Num(2) Size(0x28) ]
	struct FBox2D LocalToRootRect(struct FBox2D& InRect);

	// Object: Function FairyGUI.GObject.LocalToRoot
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102d48484
	// Return & Params: [ Num(2) Size(0x10) ]
	struct FVector2D LocalToRoot(struct FVector2D& InPoint);

	// Object: Function FairyGUI.GObject.LocalToGlobalRect
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102d484cc
	// Return & Params: [ Num(2) Size(0x28) ]
	struct FBox2D LocalToGlobalRect(struct FBox2D& InRect);

	// Object: Function FairyGUI.GObject.LocalToGlobal
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102d48510
	// Return & Params: [ Num(2) Size(0x10) ]
	struct FVector2D LocalToGlobal(struct FVector2D& InPoint);

	// Object: Function FairyGUI.GObject.IsVisible
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d48c20
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsVisible();

	// Object: Function FairyGUI.GObject.IsTouchable
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d48bb8
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsTouchable();

	// Object: Function FairyGUI.GObject.IsPivotAsAnchor
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d48ebc
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsPivotAsAnchor();

	// Object: Function FairyGUI.GObject.IsGrayed
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d48c80
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsGrayed();

	// Object: Function FairyGUI.GObject.IsDraggable
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d48888
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsDraggable();

	// Object: Function FairyGUI.GObject.GlobalToLocalRect
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102d485e4
	// Return & Params: [ Num(2) Size(0x28) ]
	struct FBox2D GlobalToLocalRect(struct FBox2D& InRect);

	// Object: Function FairyGUI.GObject.GlobalToLocal
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102d48628
	// Return & Params: [ Num(2) Size(0x10) ]
	struct FVector2D GlobalToLocal(struct FVector2D& InPoint);

	// Object: Function FairyGUI.GObject.GetYMin
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d491a4
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetYMin();

	// Object: Function FairyGUI.GObject.GetY
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d492b4
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetY();

	// Object: Function FairyGUI.GObject.GetXMin
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d49200
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetXMin();

	// Object: Function FairyGUI.GObject.GetX
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d49300
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetX();

	// Object: Function FairyGUI.GObject.GetWidth
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d49158
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetWidth();

	// Object: Function FairyGUI.GObject.GetUIRoot
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d4827c
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UGRoot* GetUIRoot();

	// Object: Function FairyGUI.GObject.GetTreeNode
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d481ac
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UGTreeNode* GetTreeNode();

	// Object: Function FairyGUI.GObject.GetTooltips
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d48900
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetTooltips();

	// Object: Function FairyGUI.GObject.GetText
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d48a68
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetText();

	// Object: Function FairyGUI.GObject.GetSortingOrder
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d48b5c
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetSortingOrder();

	// Object: Function FairyGUI.GObject.GetSkew
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d48d78
	// Return & Params: [ Num(1) Size(0x8) ]
	struct FVector2D GetSkew();

	// Object: Function FairyGUI.GObject.GetSize
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d49080
	// Return & Params: [ Num(1) Size(0x8) ]
	struct FVector2D GetSize();

	// Object: Function FairyGUI.GObject.GetScaleY
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d48e3c
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetScaleY();

	// Object: Function FairyGUI.GObject.GetScaleX
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d48ea8
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetScaleX();

	// Object: Function FairyGUI.GObject.GetScale
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d48dd0
	// Return & Params: [ Num(1) Size(0x8) ]
	struct FVector2D GetScale();

	// Object: Function FairyGUI.GObject.GetRotation
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d48d20
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetRotation();

	// Object: Function FairyGUI.GObject.GetResourceURL
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d48700
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetResourceURL();

	// Object: Function FairyGUI.GObject.GetResourceName
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d486b8
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetResourceName();

	// Object: Function FairyGUI.GObject.GetPosition
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d49268
	// Return & Params: [ Num(1) Size(0x8) ]
	struct FVector2D GetPosition();

	// Object: Function FairyGUI.GObject.GetPivot
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d48f5c
	// Return & Params: [ Num(1) Size(0x8) ]
	struct FVector2D GetPivot();

	// Object: Function FairyGUI.GObject.GetParent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d482f0
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UGComponent* GetParent();

	// Object: Function FairyGUI.GObject.GetPackageName
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d48670
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetPackageName();

	// Object: Function FairyGUI.GObject.GetIcon
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d489b4
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetIcon();

	// Object: Function FairyGUI.GObject.GetHeight
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d490ec
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetHeight();

	// Object: Function FairyGUI.GObject.GetGroup
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d48afc
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UGGroup* GetGroup();

	// Object: Function FairyGUI.GObject.GetDraggingObject
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102d48180
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UGObject* GetDraggingObject();

	// Object: Function FairyGUI.GObject.GetDragBounds
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d4880c
	// Return & Params: [ Num(1) Size(0x14) ]
	struct FBox2D GetDragBounds();

	// Object: Function FairyGUI.GObject.GetApp
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d48258
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UFairyApplication* GetApp();

	// Object: Function FairyGUI.GObject.GetAlpha
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d48cd4
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetAlpha();

	// Object: Function FairyGUI.GObject.Center
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d48fb4
	// Return & Params: [ Num(1) Size(0x1) ]
	void Center(bool bRestraint);

	// Object: Function FairyGUI.GObject.CastTo
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d481c0
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UGObject* CastTo(struct UGObject* ClassType);

	// Object: Function FairyGUI.GObject.AddRelation
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4838c
	// Return & Params: [ Num(3) Size(0xa) ]
	void AddRelation(struct UGObject* Obj, enum class ERelationType RelationType, bool bUsePercent);
};

// Object: Class FairyGUI.GComponent
// Inherited Bytes: 0x340 | Struct Size: 0x448
struct UGComponent : UGObject {
	// Fields
	struct FMulticastInlineDelegate OnDrop; // Offset: 0x340 | Size: 0x10
	struct FMulticastInlineDelegate OnScroll; // Offset: 0x350 | Size: 0x10
	struct FMulticastInlineDelegate OnScrollEnd; // Offset: 0x360 | Size: 0x10
	struct FMulticastInlineDelegate OnPullUpRelease; // Offset: 0x370 | Size: 0x10
	struct FMulticastInlineDelegate OnPullDownRelease; // Offset: 0x380 | Size: 0x10
	char pad_0x390[0x8]; // Offset: 0x390 | Size: 0x8
	struct TArray<struct UGObject*> Children; // Offset: 0x398 | Size: 0x10
	struct TArray<struct UGController*> Controllers; // Offset: 0x3a8 | Size: 0x10
	struct TArray<struct UTransition*> Transitions; // Offset: 0x3b8 | Size: 0x10
	struct UScrollPane* ScrollPane; // Offset: 0x3c8 | Size: 0x8
	char pad_0x3D0[0x78]; // Offset: 0x3d0 | Size: 0x78

	// Functions

	// Object: Function FairyGUI.GComponent.SwapChildrenAt
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d41e4c
	// Return & Params: [ Num(2) Size(0x8) ]
	void SwapChildrenAt(int32_t Index1, int32_t Index2);

	// Object: Function FairyGUI.GComponent.SwapChildren
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d41eb4
	// Return & Params: [ Num(2) Size(0x10) ]
	void SwapChildren(struct UGObject* Child1, struct UGObject* Child2);

	// Object: Function FairyGUI.GComponent.SetViewWidth
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d419d0
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetViewWidth(float InViewWidth);

	// Object: Function FairyGUI.GComponent.SetViewHeight
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d41974
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetViewHeight(float InViewHeight);

	// Object: Function FairyGUI.GComponent.SetOpaque
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d41b70
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetOpaque(bool bInOpaque);

	// Object: Function FairyGUI.GComponent.SetMargin
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102d41af4
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetMargin(struct FMargin& InMargin);

	// Object: Function FairyGUI.GComponent.SetChildrenRenderOrder
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d41a90
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetChildrenRenderOrder(enum class EChildrenRenderOrder InChildrenRenderOrder);

	// Object: Function FairyGUI.GComponent.SetChildIndexBefore
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d41f3c
	// Return & Params: [ Num(3) Size(0x10) ]
	int32_t SetChildIndexBefore(struct UGObject* Child, int32_t Index);

	// Object: Function FairyGUI.GComponent.SetChildIndex
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d41fb0
	// Return & Params: [ Num(2) Size(0xc) ]
	void SetChildIndex(struct UGObject* Child, int32_t Index);

	// Object: Function FairyGUI.GComponent.SetBoundsChangedFlag
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d41964
	// Return & Params: [ Num(0) Size(0x0) ]
	void SetBoundsChangedFlag();

	// Object: Function FairyGUI.GComponent.SetApexIndex
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d41a44
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetApexIndex(int32_t InApedIndex);

	// Object: Function FairyGUI.GComponent.RemoveChildren
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d42310
	// Return & Params: [ Num(2) Size(0x8) ]
	void RemoveChildren(int32_t BeginIndex, int32_t EndIndex);

	// Object: Function FairyGUI.GComponent.RemoveChildAt
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102d42378
	// Return & Params: [ Num(1) Size(0x4) ]
	void RemoveChildAt(int32_t Index);

	// Object: Function FairyGUI.GComponent.RemoveChild
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d423cc
	// Return & Params: [ Num(1) Size(0x8) ]
	void RemoveChild(struct UGObject* Child);

	// Object: Function FairyGUI.GComponent.OnClickChild
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102d41860
	// Return & Params: [ Num(2) Size(0x20) ]
	void OnClickChild(struct FString ChildName, struct FDelegate& Delegate);

	// Object: Function FairyGUI.GComponent.NumChildren
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d41e28
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t NumChildren();

	// Object: Function FairyGUI.GComponent.K2_OnConstruct
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void K2_OnConstruct();

	// Object: Function FairyGUI.GComponent.IsOpaque
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d41bb4
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsOpaque();

	// Object: Function FairyGUI.GComponent.IsChildInView
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d41d8c
	// Return & Params: [ Num(2) Size(0x9) ]
	bool IsChildInView(struct UGObject* Child);

	// Object: Function FairyGUI.GComponent.IsAncestorOf
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d41de8
	// Return & Params: [ Num(2) Size(0x9) ]
	bool IsAncestorOf(struct UGObject* Obj);

	// Object: Function FairyGUI.GComponent.GetViewWidth
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d41a08
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetViewWidth();

	// Object: Function FairyGUI.GComponent.GetViewHeight
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d419ac
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetViewHeight();

	// Object: Function FairyGUI.GComponent.GetTransitionAt
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d41bd8
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UTransition* GetTransitionAt(int32_t Index);

	// Object: Function FairyGUI.GComponent.GetTransition
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d41c3c
	// Return & Params: [ Num(2) Size(0x18) ]
	struct UTransition* GetTransition(struct FString TransitionName);

	// Object: Function FairyGUI.GComponent.GetScrollPane
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d41a2c
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UScrollPane* GetScrollPane();

	// Object: Function FairyGUI.GComponent.GetMargin
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d41b58
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FMargin GetMargin();

	// Object: Function FairyGUI.GComponent.GetFirstChildInView
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d41d68
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetFirstChildInView();

	// Object: Function FairyGUI.GComponent.GetControllerAt
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d41d04
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UGController* GetControllerAt(int32_t Index);

	// Object: Function FairyGUI.GComponent.GetController
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d41ca0
	// Return & Params: [ Num(2) Size(0x18) ]
	struct UGController* GetController(struct FString ControllerName);

	// Object: Function FairyGUI.GComponent.GetChildrenRenderOrder
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d41ae0
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class EChildrenRenderOrder GetChildrenRenderOrder();

	// Object: Function FairyGUI.GComponent.GetChildInGroup
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d42088
	// Return & Params: [ Num(4) Size(0x28) ]
	struct UGObject* GetChildInGroup(struct UGGroup* Group, struct FString ChildName, struct UGObject* ClassType);

	// Object: Function FairyGUI.GComponent.GetChildIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d42048
	// Return & Params: [ Num(2) Size(0xc) ]
	int32_t GetChildIndex(struct UGObject* Child);

	// Object: Function FairyGUI.GComponent.GetChildByPath
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d42164
	// Return & Params: [ Num(3) Size(0x20) ]
	struct UGObject* GetChildByPath(struct FString Path, struct UGObject* ClassType);

	// Object: Function FairyGUI.GComponent.GetChildAt
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d42264
	// Return & Params: [ Num(3) Size(0x18) ]
	struct UGObject* GetChildAt(int32_t Index, struct UGObject* ClassType);

	// Object: Function FairyGUI.GComponent.GetChild
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d421e4
	// Return & Params: [ Num(3) Size(0x20) ]
	struct UGObject* GetChild(struct FString ChildName, struct UGObject* ClassType);

	// Object: Function FairyGUI.GComponent.GetApexIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d41a7c
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetApexIndex();

	// Object: Function FairyGUI.GComponent.EnsureBoundsCorrect
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d41954
	// Return & Params: [ Num(0) Size(0x0) ]
	void EnsureBoundsCorrect();

	// Object: Function FairyGUI.GComponent.AddChildAt
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102d4241c
	// Return & Params: [ Num(3) Size(0x18) ]
	struct UGObject* AddChildAt(struct UGObject* Child, int32_t Index);

	// Object: Function FairyGUI.GComponent.AddChild
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d42498
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UGObject* AddChild(struct UGObject* Child);
};

// Object: Class FairyGUI.GButton
// Inherited Bytes: 0x448 | Struct Size: 0x4f8
struct UGButton : UGComponent {
	// Fields
	struct FMulticastInlineDelegate OnChanged; // Offset: 0x448 | Size: 0x10
	bool bChangeStateOnClick; // Offset: 0x458 | Size: 0x1
	char pad_0x459[0x9f]; // Offset: 0x459 | Size: 0x9f

	// Functions

	// Object: Function FairyGUI.GButton.SetTitleFontSize
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4059c
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetTitleFontSize(int32_t InFontSize);

	// Object: Function FairyGUI.GButton.SetTitleColor
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102d40610
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetTitleColor(struct FColor& InColor);

	// Object: Function FairyGUI.GButton.SetTitle
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d407e8
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetTitle(struct FString InTitle);

	// Object: Function FairyGUI.GButton.SetSelectedTitle
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4073c
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetSelectedTitle(struct FString InTitle);

	// Object: Function FairyGUI.GButton.SetSelectedIcon
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d40690
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetSelectedIcon(struct FString InIcon);

	// Object: Function FairyGUI.GButton.SetSelected
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4052c
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetSelected(bool bInSelected);

	// Object: Function FairyGUI.GButton.SetRelatedController
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d404bc
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetRelatedController(struct UGController* InController);

	// Object: Function FairyGUI.GButton.IsSelected
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d40588
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsSelected();

	// Object: Function FairyGUI.GButton.GetTitleFontSize
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d405ec
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetTitleFontSize();

	// Object: Function FairyGUI.GButton.GetTitleColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d4066c
	// Return & Params: [ Num(1) Size(0x4) ]
	struct FColor GetTitleColor();

	// Object: Function FairyGUI.GButton.GetTitle
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d40840
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetTitle();

	// Object: Function FairyGUI.GButton.GetSelectedTitle
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d40798
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetSelectedTitle();

	// Object: Function FairyGUI.GButton.GetSelectedIcon
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d406ec
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetSelectedIcon();

	// Object: Function FairyGUI.GButton.GetRelatedController
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d40518
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UGController* GetRelatedController();
};

// Object: Class FairyGUI.GComboBox
// Inherited Bytes: 0x448 | Struct Size: 0x4d0
struct UGComboBox : UGComponent {
	// Fields
	int32_t VisibleItemCount; // Offset: 0x448 | Size: 0x4
	enum class EPopupDirection PopupDirection; // Offset: 0x44c | Size: 0x1
	char pad_0x44D[0x3]; // Offset: 0x44d | Size: 0x3
	struct TArray<struct FString> Items; // Offset: 0x450 | Size: 0x10
	struct TArray<struct FString> Icons; // Offset: 0x460 | Size: 0x10
	struct TArray<struct FString> Values; // Offset: 0x470 | Size: 0x10
	struct FMulticastInlineDelegate OnChanged; // Offset: 0x480 | Size: 0x10
	struct UGComponent* DropdownObject; // Offset: 0x490 | Size: 0x8
	char pad_0x498[0x38]; // Offset: 0x498 | Size: 0x38

	// Functions

	// Object: Function FairyGUI.GComboBox.SetValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d40ce0
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetValue(struct FString InValue);

	// Object: Function FairyGUI.GComboBox.SetTitleFontSize
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d40d84
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetTitleFontSize(int32_t InFontSize);

	// Object: Function FairyGUI.GComboBox.SetTitleColor
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102d40df8
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetTitleColor(struct FColor& InColor);

	// Object: Function FairyGUI.GComboBox.SetTitle
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d40e78
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetTitle(struct FString InTitle);

	// Object: Function FairyGUI.GComboBox.SetSelectionController
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d40c0c
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetSelectionController(struct UGController* InController);

	// Object: Function FairyGUI.GComboBox.SetSelectedIndex
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d40c7c
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetSelectedIndex(int32_t InIndex);

	// Object: Function FairyGUI.GComboBox.Refresh
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d40be8
	// Return & Params: [ Num(0) Size(0x0) ]
	void Refresh();

	// Object: Function FairyGUI.GComboBox.GetValue
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d40d3c
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetValue();

	// Object: Function FairyGUI.GComboBox.GetTitleFontSize
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d40dd4
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetTitleFontSize();

	// Object: Function FairyGUI.GComboBox.GetTitleColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d40e54
	// Return & Params: [ Num(1) Size(0x4) ]
	struct FColor GetTitleColor();

	// Object: Function FairyGUI.GComboBox.GetTitle
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d40ed0
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetTitle();

	// Object: Function FairyGUI.GComboBox.GetSelectionController
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d40c68
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UGController* GetSelectionController();

	// Object: Function FairyGUI.GComboBox.GetSelectedIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d40ccc
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetSelectedIndex();

	// Object: Function FairyGUI.GComboBox.GetDropdown
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d40bf8
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UGObject* GetDropdown();
};

// Object: Class FairyGUI.GController
// Inherited Bytes: 0x28 | Struct Size: 0x90
struct UGController : UObject {
	// Fields
	char pad_0x28[0x68]; // Offset: 0x28 | Size: 0x68

	// Functions

	// Object: Function FairyGUI.GController.SetSelectedPage
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d42ddc
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetSelectedPage(struct FString PageName);

	// Object: Function FairyGUI.GController.SetSelectedIndex
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d42e90
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetSelectedIndex(int32_t Index);

	// Object: Function FairyGUI.GController.GetSelectedPage
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d42e48
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetSelectedPage();

	// Object: Function FairyGUI.GController.GetSelectedIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d42ec8
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetSelectedIndex();
};

// Object: Class FairyGUI.GGraph
// Inherited Bytes: 0x340 | Struct Size: 0x350
struct UGGraph : UGObject {
	// Fields
	char pad_0x340[0x10]; // Offset: 0x340 | Size: 0x10

	// Functions

	// Object: Function FairyGUI.GGraph.SetColor
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102d43620
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetColor(struct FColor& InColor);

	// Object: Function FairyGUI.GGraph.IsEmpty
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d42ff0
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsEmpty();

	// Object: Function FairyGUI.GGraph.GetColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d43674
	// Return & Params: [ Num(1) Size(0x4) ]
	struct FColor GetColor();

	// Object: Function FairyGUI.GGraph.DrawRoundRect
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102d433f0
	// Return & Params: [ Num(7) Size(0x1c) ]
	void DrawRoundRect(float LineWidth, struct FColor& LineColor, struct FColor& FillColor, float TopLeftRadius, float TopRightRadius, float BottomLeftRadius, float BottomRightRadius);

	// Object: Function FairyGUI.GGraph.DrawRegularPolygon
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102d43024
	// Return & Params: [ Num(6) Size(0x28) ]
	void DrawRegularPolygon(int32_t Sides, float LineWidth, struct FColor& LineColor, struct FColor& FillColor, float Rotation, struct TArray<float>& Distances);

	// Object: Function FairyGUI.GGraph.DrawRect
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102d43574
	// Return & Params: [ Num(3) Size(0xc) ]
	void DrawRect(float LineWidth, struct FColor& LineColor, struct FColor& FillColor);

	// Object: Function FairyGUI.GGraph.DrawPolygon
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102d431b4
	// Return & Params: [ Num(4) Size(0x20) ]
	void DrawPolygon(float LineWidth, struct FColor& LineColor, struct FColor& FillColor, struct TArray<struct FVector2D>& Points);

	// Object: Function FairyGUI.GGraph.DrawEllipse
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102d432d8
	// Return & Params: [ Num(5) Size(0x14) ]
	void DrawEllipse(float LineWidth, struct FColor& LineColor, struct FColor& FillColor, float StartDegree, float EndDegree);

	// Object: Function FairyGUI.GGraph.Clear
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d43014
	// Return & Params: [ Num(0) Size(0x0) ]
	void Clear();
};

// Object: Class FairyGUI.GGroup
// Inherited Bytes: 0x340 | Struct Size: 0x370
struct UGGroup : UGObject {
	// Fields
	char pad_0x340[0x30]; // Offset: 0x340 | Size: 0x30

	// Functions

	// Object: Function FairyGUI.GGroup.SetMainGridMinSize
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d43920
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetMainGridMinSize(int32_t InSize);

	// Object: Function FairyGUI.GGroup.SetMainGridIndex
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4396c
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetMainGridIndex(int32_t InIndex);

	// Object: Function FairyGUI.GGroup.SetLineGap
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d43a68
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetLineGap(int32_t InLineGap);

	// Object: Function FairyGUI.GGroup.SetLayout
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d43b00
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetLayout(enum class EGroupLayoutType InLayout);

	// Object: Function FairyGUI.GGroup.SetExcludeInvisibles
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d43a10
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetExcludeInvisibles(bool bInFlag);

	// Object: Function FairyGUI.GGroup.SetColumnGap
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d43ab4
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetColumnGap(int32_t InColumnGap);

	// Object: Function FairyGUI.GGroup.SetBoundsChangedFlag
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d438dc
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetBoundsChangedFlag(bool bPositionChangedOnly);

	// Object: Function FairyGUI.GGroup.SetAutoSizeDisabled
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d439b8
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetAutoSizeDisabled(bool bInFlag);

	// Object: Function FairyGUI.GGroup.IsExcludeInvisibles
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d43a54
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsExcludeInvisibles();

	// Object: Function FairyGUI.GGroup.IsAutoSizeDisabled
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d439fc
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsAutoSizeDisabled();

	// Object: Function FairyGUI.GGroup.GetMainGridMinSize
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d43958
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetMainGridMinSize();

	// Object: Function FairyGUI.GGroup.GetMainGridIndex
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d439a4
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetMainGridIndex();

	// Object: Function FairyGUI.GGroup.GetLineGap
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d43aa0
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetLineGap();

	// Object: Function FairyGUI.GGroup.GetLayout
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d43b50
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class EGroupLayoutType GetLayout();

	// Object: Function FairyGUI.GGroup.GetColumnGap
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d43aec
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetColumnGap();

	// Object: Function FairyGUI.GGroup.EnsureBoundsCorrect
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d438cc
	// Return & Params: [ Num(0) Size(0x0) ]
	void EnsureBoundsCorrect();
};

// Object: Class FairyGUI.GImage
// Inherited Bytes: 0x340 | Struct Size: 0x350
struct UGImage : UGObject {
	// Fields
	char pad_0x340[0x10]; // Offset: 0x340 | Size: 0x10

	// Functions

	// Object: Function FairyGUI.GImage.SetFlip
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d44138
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetFlip(enum class EFlipType InFlip);

	// Object: Function FairyGUI.GImage.SetFillOrigin
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d43ff0
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetFillOrigin(int32_t Origin);

	// Object: Function FairyGUI.GImage.SetFillMethod
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4404c
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetFillMethod(enum class EFillMethod Method);

	// Object: Function FairyGUI.GImage.SetFillClockwise
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d43f88
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetFillClockwise(bool bClockwise);

	// Object: Function FairyGUI.GImage.SetFillAmount
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d43f2c
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetFillAmount(float Amount);

	// Object: Function FairyGUI.GImage.SetColor
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102d440c0
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetColor(struct FColor& InColor);

	// Object: Function FairyGUI.GImage.IsFillClockwise
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d43fcc
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsFillClockwise();

	// Object: Function FairyGUI.GImage.GetFlip
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d44188
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class EFlipType GetFlip();

	// Object: Function FairyGUI.GImage.GetFillOrigin
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d44028
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetFillOrigin();

	// Object: Function FairyGUI.GImage.GetFillMethod
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d4409c
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class EFillMethod GetFillMethod();

	// Object: Function FairyGUI.GImage.GetFillAmount
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d43f64
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetFillAmount();

	// Object: Function FairyGUI.GImage.GetColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d44114
	// Return & Params: [ Num(1) Size(0x4) ]
	struct FColor GetColor();
};

// Object: Class FairyGUI.GLabel
// Inherited Bytes: 0x448 | Struct Size: 0x458
struct UGLabel : UGComponent {
	// Fields
	char pad_0x448[0x10]; // Offset: 0x448 | Size: 0x10

	// Functions

	// Object: Function FairyGUI.GLabel.SetTitleFontSize
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d44488
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetTitleFontSize(int32_t Value);

	// Object: Function FairyGUI.GLabel.SetTitleColor
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102d444e4
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetTitleColor(struct FColor& InColor);

	// Object: Function FairyGUI.GLabel.SetTitle
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4455c
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetTitle(struct FString InTitle);

	// Object: Function FairyGUI.GLabel.GetTitleFontSize
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d444c0
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetTitleFontSize();

	// Object: Function FairyGUI.GLabel.GetTitleColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d44538
	// Return & Params: [ Num(1) Size(0x4) ]
	struct FColor GetTitleColor();

	// Object: Function FairyGUI.GLabel.GetTitle
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d445c4
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetTitle();
};

// Object: Class FairyGUI.GList
// Inherited Bytes: 0x448 | Struct Size: 0x500
struct UGList : UGComponent {
	// Fields
	struct FMulticastInlineDelegate OnClickItem; // Offset: 0x448 | Size: 0x10
	bool bScrollItemToViewOnClick; // Offset: 0x458 | Size: 0x1
	bool bFoldInvisibleItems; // Offset: 0x459 | Size: 0x1
	char pad_0x45A[0xa6]; // Offset: 0x45a | Size: 0xa6

	// Functions

	// Object: Function FairyGUI.GList.SetVirtualAndLoop
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d44ce8
	// Return & Params: [ Num(0) Size(0x0) ]
	void SetVirtualAndLoop();

	// Object: Function FairyGUI.GList.SetVirtual
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d44cf8
	// Return & Params: [ Num(0) Size(0x0) ]
	void SetVirtual();

	// Object: Function FairyGUI.GList.SetVerticalAlign
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d451e4
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetVerticalAlign(enum class EVerticalAlignType InVerticalAlign);

	// Object: Function FairyGUI.GList.SetSelectionMode
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d45124
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetSelectionMode(enum class EListSelectionMode InMode);

	// Object: Function FairyGUI.GList.SetSelectionController
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d44d08
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetSelectionController(struct UGController* InController);

	// Object: Function FairyGUI.GList.SetSelectedIndex
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d44f74
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetSelectedIndex(int32_t Index);

	// Object: Function FairyGUI.GList.SetNumItems
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d44c68
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetNumItems(int32_t InNumItems);

	// Object: Function FairyGUI.GList.SetLineGap
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d452ac
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetLineGap(int32_t InLineGap);

	// Object: Function FairyGUI.GList.SetLineCount
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d45390
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetLineCount(int32_t InLineCount);

	// Object: Function FairyGUI.GList.SetLayout
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d453dc
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetLayout(enum class EListLayoutType InLayout);

	// Object: Function FairyGUI.GList.SetItemRenderer
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102d449b8
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetItemRenderer(struct FDelegate& InItemRenderer);

	// Object: Function FairyGUI.GList.SetItemProvider
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102d447e0
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetItemProvider(struct FDelegate& InItemProvider);

	// Object: Function FairyGUI.GList.SetDefaultItem
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d45440
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetDefaultItem(struct FString InDefaultItem);

	// Object: Function FairyGUI.GList.SetColumnGap
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d452f8
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetColumnGap(int32_t InColumnGap);

	// Object: Function FairyGUI.GList.SetColumnCount
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d45344
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetColumnCount(int32_t InColumnCount);

	// Object: Function FairyGUI.GList.SetAutoResizeItem
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4518c
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetAutoResizeItem(bool bFlag);

	// Object: Function FairyGUI.GList.SetAlign
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d45248
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetAlign(enum class EAlignType InAlign);

	// Object: Function FairyGUI.GList.SelectReverse
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d44e94
	// Return & Params: [ Num(0) Size(0x0) ]
	void SelectReverse();

	// Object: Function FairyGUI.GList.SelectAll
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d44ea4
	// Return & Params: [ Num(0) Size(0x0) ]
	void SelectAll();

	// Object: Function FairyGUI.GList.ScrollToView
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d44d70
	// Return & Params: [ Num(3) Size(0x6) ]
	void ScrollToView(int32_t Index, bool bAnimation, bool bSetFirst);

	// Object: Function FairyGUI.GList.ResizeToFit
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d44e2c
	// Return & Params: [ Num(2) Size(0x8) ]
	void ResizeToFit(int32_t ItemCount, int32_t InMinSize);

	// Object: Function FairyGUI.GList.RemoveSelection
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d44ec4
	// Return & Params: [ Num(1) Size(0x4) ]
	void RemoveSelection(int32_t Index);

	// Object: Function FairyGUI.GList.RemoveChildToPoolAt
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d45088
	// Return & Params: [ Num(1) Size(0x4) ]
	void RemoveChildToPoolAt(int32_t Index);

	// Object: Function FairyGUI.GList.RemoveChildToPool
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d45038
	// Return & Params: [ Num(1) Size(0x8) ]
	void RemoveChildToPool(struct UGObject* Child);

	// Object: Function FairyGUI.GList.RemoveChildrenToPool
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d44fd0
	// Return & Params: [ Num(2) Size(0x8) ]
	void RemoveChildrenToPool(int32_t BeginIndex, int32_t EndIndex);

	// Object: Function FairyGUI.GList.RefreshVirtualList
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d44cc4
	// Return & Params: [ Num(0) Size(0x0) ]
	void RefreshVirtualList();

	// Object: Function FairyGUI.GList.OnClickItemHandler
	// Flags: [Final|Native|Private]
	// Offset: 0x102d44790
	// Return & Params: [ Num(1) Size(0x8) ]
	void OnClickItemHandler(struct UEventContext* Context);

	// Object: Function FairyGUI.GList.ItemIndexToChildIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d44ba0
	// Return & Params: [ Num(2) Size(0x8) ]
	int32_t ItemIndexToChildIndex(int32_t Index);

	// Object: Function FairyGUI.GList.IsVirtual
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d44cd4
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsVirtual();

	// Object: Function FairyGUI.GList.GetVerticalAlign
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d45234
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class EVerticalAlignType GetVerticalAlign();

	// Object: Function FairyGUI.GList.GetSelectionMode
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d45178
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class EListSelectionMode GetSelectionMode();

	// Object: Function FairyGUI.GList.GetSelectionController
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d44d58
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UGController* GetSelectionController();

	// Object: Function FairyGUI.GList.GetSelectedIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d44fac
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetSelectedIndex();

	// Object: Function FairyGUI.GList.GetNumItems
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d44ca0
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetNumItems();

	// Object: Function FairyGUI.GList.GetLineGap
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d452e4
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetLineGap();

	// Object: Function FairyGUI.GList.GetLineCount
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d453c8
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetLineCount();

	// Object: Function FairyGUI.GList.GetLayout
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d4542c
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class EListLayoutType GetLayout();

	// Object: Function FairyGUI.GList.GetDefaultItem
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d454ac
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetDefaultItem();

	// Object: Function FairyGUI.GList.GetColumnGap
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d45330
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetColumnGap();

	// Object: Function FairyGUI.GList.GetColumnCount
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4537c
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetColumnCount();

	// Object: Function FairyGUI.GList.GetAutoResizeItem
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d451d0
	// Return & Params: [ Num(1) Size(0x1) ]
	bool GetAutoResizeItem();

	// Object: Function FairyGUI.GList.GetAlign
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d45298
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class EAlignType GetAlign();

	// Object: Function FairyGUI.GList.ClearSelection
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d44eb4
	// Return & Params: [ Num(0) Size(0x0) ]
	void ClearSelection();

	// Object: Function FairyGUI.GList.ChildIndexToItemIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d44c04
	// Return & Params: [ Num(2) Size(0x8) ]
	int32_t ChildIndexToItemIndex(int32_t Index);

	// Object: Function FairyGUI.GList.AddSelection
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d44efc
	// Return & Params: [ Num(2) Size(0x5) ]
	void AddSelection(int32_t Index, bool bScrollItToView);

	// Object: Function FairyGUI.GList.AddItemFromPool
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d450c0
	// Return & Params: [ Num(2) Size(0x18) ]
	struct UGObject* AddItemFromPool(struct FString URL);
};

// Object: Class FairyGUI.GLoader
// Inherited Bytes: 0x340 | Struct Size: 0x3a0
struct UGLoader : UGObject {
	// Fields
	char pad_0x340[0x30]; // Offset: 0x340 | Size: 0x30
	struct UGObject* Content2; // Offset: 0x370 | Size: 0x8
	char pad_0x378[0x28]; // Offset: 0x378 | Size: 0x28

	// Functions

	// Object: Function FairyGUI.GLoader.SetVerticalAlign
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d46e9c
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetVerticalAlign(enum class EVerticalAlignType InVerticalAlign);

	// Object: Function FairyGUI.GLoader.SetURL
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d46f64
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetURL(struct FString InUrl);

	// Object: Function FairyGUI.GLoader.SetShrinkOnly
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d46d78
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetShrinkOnly(bool bInShrinkOnly);

	// Object: Function FairyGUI.GLoader.SetPlaying
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d46aa0
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetPlaying(bool bInPlaying);

	// Object: Function FairyGUI.GLoader.SetFrame
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d46a44
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetFrame(int32_t InFrame);

	// Object: Function FairyGUI.GLoader.SetFlip
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d46d04
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetFlip(enum class EFlipType InFlip);

	// Object: Function FairyGUI.GLoader.SetFillOrigin
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d46bcc
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetFillOrigin(int32_t Origin);

	// Object: Function FairyGUI.GLoader.SetFillMethod
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d46c28
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetFillMethod(enum class EFillMethod Method);

	// Object: Function FairyGUI.GLoader.SetFillClockwise
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d46b64
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetFillClockwise(bool bClockwise);

	// Object: Function FairyGUI.GLoader.SetFillAmount
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d46b08
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetFillAmount(float Amount);

	// Object: Function FairyGUI.GLoader.SetFill
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d46dd8
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetFill(enum class ELoaderFillType InFillType);

	// Object: Function FairyGUI.GLoader.SetColor
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102d46c9c
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetColor(struct FColor& InColor);

	// Object: Function FairyGUI.GLoader.SetAutoSize
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d46e3c
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetAutoSize(bool bInAutoSize);

	// Object: Function FairyGUI.GLoader.SetAlign
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d46f00
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetAlign(enum class EAlignType InAlign);

	// Object: Function FairyGUI.GLoader.IsShrinkOnly
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d46dbc
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsShrinkOnly();

	// Object: Function FairyGUI.GLoader.IsPlaying
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d46ae4
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsPlaying();

	// Object: Function FairyGUI.GLoader.IsFillClockwise
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d46ba8
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsFillClockwise();

	// Object: Function FairyGUI.GLoader.GetVerticalAlign
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d46eec
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class EVerticalAlignType GetVerticalAlign();

	// Object: Function FairyGUI.GLoader.GetUrl
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d46fc0
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetUrl();

	// Object: Function FairyGUI.GLoader.GetFrame
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d46a7c
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetFrame();

	// Object: Function FairyGUI.GLoader.GetFlip
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d46d54
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class EFlipType GetFlip();

	// Object: Function FairyGUI.GLoader.GetFillOrigin
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d46c04
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetFillOrigin();

	// Object: Function FairyGUI.GLoader.GetFillMethod
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d46c78
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class EFillMethod GetFillMethod();

	// Object: Function FairyGUI.GLoader.GetFillAmount
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d46b40
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetFillAmount();

	// Object: Function FairyGUI.GLoader.GetFill
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d46e28
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class ELoaderFillType GetFill();

	// Object: Function FairyGUI.GLoader.GetColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d46ce0
	// Return & Params: [ Num(1) Size(0x4) ]
	struct FColor GetColor();

	// Object: Function FairyGUI.GLoader.GetAutoSize
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d46e80
	// Return & Params: [ Num(1) Size(0x1) ]
	bool GetAutoSize();

	// Object: Function FairyGUI.GLoader.GetAlign
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d46f50
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class EAlignType GetAlign();
};

// Object: Class FairyGUI.GLoader3D
// Inherited Bytes: 0x340 | Struct Size: 0x378
struct UGLoader3D : UGObject {
	// Fields
	char pad_0x340[0x38]; // Offset: 0x340 | Size: 0x38

	// Functions

	// Object: Function FairyGUI.GLoader3D.SetURL
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d476f0
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetURL(struct FString InUrl);

	// Object: Function FairyGUI.GLoader3D.SetColor
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102d47688
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetColor(struct FColor& InColor);

	// Object: Function FairyGUI.GLoader3D.GetUrl
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d4774c
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetUrl();

	// Object: Function FairyGUI.GLoader3D.GetColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d476cc
	// Return & Params: [ Num(1) Size(0x4) ]
	struct FColor GetColor();
};

// Object: Class FairyGUI.GMovieClip
// Inherited Bytes: 0x340 | Struct Size: 0x350
struct UGMovieClip : UGObject {
	// Fields
	char pad_0x340[0x10]; // Offset: 0x340 | Size: 0x10

	// Functions

	// Object: Function FairyGUI.GMovieClip.SetTimeScale
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d47c44
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetTimeScale(float InTimeScale);

	// Object: Function FairyGUI.GMovieClip.SetPlaySettings
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102d478b4
	// Return & Params: [ Num(5) Size(0x20) ]
	void SetPlaySettings(struct FDelegate& InCompleteCallback, int32_t InStart, int32_t InEnd, int32_t InTimes, int32_t InEndAt);

	// Object: Function FairyGUI.GMovieClip.SetPlaying
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d47cfc
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetPlaying(bool bInPlaying);

	// Object: Function FairyGUI.GMovieClip.SetFrame
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d47ca0
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetFrame(int32_t InFrame);

	// Object: Function FairyGUI.GMovieClip.SetFlip
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d47b98
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetFlip(enum class EFlipType InFlip);

	// Object: Function FairyGUI.GMovieClip.SetColor
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102d47b30
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetColor(struct FColor& InColor);

	// Object: Function FairyGUI.GMovieClip.IsPlaying
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d47d40
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsPlaying();

	// Object: Function FairyGUI.GMovieClip.GetTimeScale
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d47c7c
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetTimeScale();

	// Object: Function FairyGUI.GMovieClip.GetFrame
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d47cd8
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetFrame();

	// Object: Function FairyGUI.GMovieClip.GetFlip
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d47be8
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class EFlipType GetFlip();

	// Object: Function FairyGUI.GMovieClip.GetColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d47b74
	// Return & Params: [ Num(1) Size(0x4) ]
	struct FColor GetColor();

	// Object: Function FairyGUI.GMovieClip.Advance
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d47c0c
	// Return & Params: [ Num(1) Size(0x4) ]
	void Advance(float Time);
};

// Object: Class FairyGUI.GProgressBar
// Inherited Bytes: 0x448 | Struct Size: 0x490
struct UGProgressBar : UGComponent {
	// Fields
	char pad_0x448[0x48]; // Offset: 0x448 | Size: 0x48

	// Functions

	// Object: Function FairyGUI.GProgressBar.TweenValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4ab10
	// Return & Params: [ Num(2) Size(0x8) ]
	void TweenValue(float InValue, float Duration);

	// Object: Function FairyGUI.GProgressBar.SetValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4ab74
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetValue(float InValue);

	// Object: Function FairyGUI.GProgressBar.SetTitleType
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4ac70
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetTitleType(enum class EProgressTitleType InType);

	// Object: Function FairyGUI.GProgressBar.SetMin
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4ac1c
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetMin(float InMin);

	// Object: Function FairyGUI.GProgressBar.SetMax
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4abc8
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetMax(float InMax);

	// Object: Function FairyGUI.GProgressBar.GetValue
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d4abb4
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetValue();

	// Object: Function FairyGUI.GProgressBar.GetTitleType
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d4acc0
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class EProgressTitleType GetTitleType();

	// Object: Function FairyGUI.GProgressBar.GetMin
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d4ac5c
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetMin();

	// Object: Function FairyGUI.GProgressBar.GetMax
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d4ac08
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetMax();
};

// Object: Class FairyGUI.GTextField
// Inherited Bytes: 0x340 | Struct Size: 0x3c0
struct UGTextField : UGObject {
	// Fields
	char pad_0x340[0x80]; // Offset: 0x340 | Size: 0x80

	// Functions

	// Object: Function FairyGUI.GTextField.SetVar
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4bb58
	// Return & Params: [ Num(3) Size(0x28) ]
	struct UGTextField* SetVar(struct FString VarKey, struct FString VarValue);

	// Object: Function FairyGUI.GTextField.SetUBBEnabled
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102d4be1c
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetUBBEnabled(bool InEnabled);

	// Object: Function FairyGUI.GTextField.SetTextFormat
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102d4bc48
	// Return & Params: [ Num(1) Size(0x40) ]
	void SetTextFormat(struct FNTextFormat& InTextFormat);

	// Object: Function FairyGUI.GTextField.SetSingleLine
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102d4bd28
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetSingleLine(bool InSingleLine);

	// Object: Function FairyGUI.GTextField.SetAutoSize
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x102d4bd90
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetAutoSize(enum class EAutoSizeType InAutoSize);

	// Object: Function FairyGUI.GTextField.IsUBBEnabled
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d4be60
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsUBBEnabled();

	// Object: Function FairyGUI.GTextField.IsSingleLine
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d4bd6c
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsSingleLine();

	// Object: Function FairyGUI.GTextField.GetTextSize
	// Flags: [Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x102d4bc14
	// Return & Params: [ Num(1) Size(0x8) ]
	struct FVector2D GetTextSize();

	// Object: Function FairyGUI.GTextField.GetTextFormat
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x102d4bcac
	// Return & Params: [ Num(1) Size(0x40) ]
	struct FNTextFormat GetTextFormat();

	// Object: Function FairyGUI.GTextField.GetAutoSize
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d4bdf8
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class EAutoSizeType GetAutoSize();

	// Object: Function FairyGUI.GTextField.FlushVars
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4bb48
	// Return & Params: [ Num(0) Size(0x0) ]
	void FlushVars();

	// Object: Function FairyGUI.GTextField.ApplyFormat
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4bc38
	// Return & Params: [ Num(0) Size(0x0) ]
	void ApplyFormat();
};

// Object: Class FairyGUI.GRichTextField
// Inherited Bytes: 0x3c0 | Struct Size: 0x3d0
struct UGRichTextField : UGTextField {
	// Fields
	struct FMulticastInlineDelegate OnClickLink; // Offset: 0x3c0 | Size: 0x10
};

// Object: Class FairyGUI.GRoot
// Inherited Bytes: 0x448 | Struct Size: 0x490
struct UGRoot : UGComponent {
	// Fields
	struct UGGraph* ModalLayer; // Offset: 0x448 | Size: 0x8
	struct UGObject* ModalWaitPane; // Offset: 0x450 | Size: 0x8
	struct UGObject* TooltipWin; // Offset: 0x458 | Size: 0x8
	struct UGObject* DefaultTooltipWin; // Offset: 0x460 | Size: 0x8
	char pad_0x468[0x28]; // Offset: 0x468 | Size: 0x28

	// Functions

	// Object: Function FairyGUI.GRoot.TogglePopup
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4b054
	// Return & Params: [ Num(3) Size(0x11) ]
	void TogglePopup(struct UGObject* PopUp, struct UGObject* AtObject, enum class EPopupDirection Direction);

	// Object: Function FairyGUI.GRoot.ShowTooltipsWin
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4af64
	// Return & Params: [ Num(1) Size(0x8) ]
	void ShowTooltipsWin(struct UGObject* InTooltipWin);

	// Object: Function FairyGUI.GRoot.ShowTooltips
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4af9c
	// Return & Params: [ Num(1) Size(0x10) ]
	void ShowTooltips(struct FString Text);

	// Object: Function FairyGUI.GRoot.ShowPopup
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4b110
	// Return & Params: [ Num(3) Size(0x11) ]
	void ShowPopup(struct UGObject* PopUp, struct UGObject* AtObject, enum class EPopupDirection Direction);

	// Object: Function FairyGUI.GRoot.ShowModalWait
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4b268
	// Return & Params: [ Num(0) Size(0x0) ]
	void ShowModalWait();

	// Object: Function FairyGUI.GRoot.IsModalWaiting
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d4b1cc
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsModalWaiting();

	// Object: Function FairyGUI.GRoot.HideTooltips
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4af54
	// Return & Params: [ Num(0) Size(0x0) ]
	void HideTooltips();

	// Object: Function FairyGUI.GRoot.HidePopup
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4b01c
	// Return & Params: [ Num(1) Size(0x8) ]
	void HidePopup(struct UGObject* PopUp);

	// Object: Function FairyGUI.GRoot.HasModalWindow
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d4b1f0
	// Return & Params: [ Num(1) Size(0x1) ]
	bool HasModalWindow();

	// Object: Function FairyGUI.GRoot.HasAnyPopup
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d4aff8
	// Return & Params: [ Num(1) Size(0x1) ]
	bool HasAnyPopup();

	// Object: Function FairyGUI.GRoot.GetTopWindow
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d4b214
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UGWindow* GetTopWindow();

	// Object: Function FairyGUI.GRoot.Get
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x102d4b2b0
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UGRoot* Get(struct UObject* WorldContextObject);

	// Object: Function FairyGUI.GRoot.CloseModalWait
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4b258
	// Return & Params: [ Num(0) Size(0x0) ]
	void CloseModalWait();

	// Object: Function FairyGUI.GRoot.CloseAllWindows
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4b238
	// Return & Params: [ Num(0) Size(0x0) ]
	void CloseAllWindows();

	// Object: Function FairyGUI.GRoot.CloseAllExceptModals
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4b248
	// Return & Params: [ Num(0) Size(0x0) ]
	void CloseAllExceptModals();

	// Object: Function FairyGUI.GRoot.BringToFront
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4b278
	// Return & Params: [ Num(1) Size(0x8) ]
	void BringToFront(struct UGWindow* Window);
};

// Object: Class FairyGUI.GScrollBar
// Inherited Bytes: 0x448 | Struct Size: 0x490
struct UGScrollBar : UGComponent {
	// Fields
	char pad_0x448[0x48]; // Offset: 0x448 | Size: 0x48
};

// Object: Class FairyGUI.GSlider
// Inherited Bytes: 0x448 | Struct Size: 0x4b8
struct UGSlider : UGComponent {
	// Fields
	bool bChangeOnClick; // Offset: 0x448 | Size: 0x1
	bool bCanDrag; // Offset: 0x449 | Size: 0x1
	char pad_0x44A[0x6]; // Offset: 0x44a | Size: 0x6
	struct FMulticastInlineDelegate OnChanged; // Offset: 0x450 | Size: 0x10
	char pad_0x460[0x58]; // Offset: 0x460 | Size: 0x58

	// Functions

	// Object: Function FairyGUI.GSlider.SetWholeNumbers
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4b70c
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetWholeNumbers(bool bWholeNumbers);

	// Object: Function FairyGUI.GSlider.SetValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4b76c
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetValue(float InValue);

	// Object: Function FairyGUI.GSlider.SetTitleType
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4b868
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetTitleType(enum class EProgressTitleType InTitleType);

	// Object: Function FairyGUI.GSlider.SetMin
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4b814
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetMin(float InMin);

	// Object: Function FairyGUI.GSlider.SetMax
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4b7c0
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetMax(float InMax);

	// Object: Function FairyGUI.GSlider.GetWholeNumbers
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d4b758
	// Return & Params: [ Num(1) Size(0x1) ]
	bool GetWholeNumbers();

	// Object: Function FairyGUI.GSlider.GetValue
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d4b7ac
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetValue();

	// Object: Function FairyGUI.GSlider.GetTitleType
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d4b8b8
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class EProgressTitleType GetTitleType();

	// Object: Function FairyGUI.GSlider.GetMin
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d4b854
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetMin();

	// Object: Function FairyGUI.GSlider.GetMax
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d4b800
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetMax();
};

// Object: Class FairyGUI.GTextInput
// Inherited Bytes: 0x340 | Struct Size: 0x3b8
struct UGTextInput : UGObject {
	// Fields
	struct FMulticastInlineDelegate OnSubmit; // Offset: 0x340 | Size: 0x10
	char pad_0x350[0x68]; // Offset: 0x350 | Size: 0x68

	// Functions

	// Object: Function FairyGUI.GTextInput.SetTextFormat
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102d4c2ec
	// Return & Params: [ Num(1) Size(0x40) ]
	void SetTextFormat(struct FNTextFormat& InTextFormat);

	// Object: Function FairyGUI.GTextInput.SetSingleLine
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4c3b0
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetSingleLine(bool InSingleLine);

	// Object: Function FairyGUI.GTextInput.SetRestrict
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4c158
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetRestrict(struct FString InRestrict);

	// Object: Function FairyGUI.GTextInput.SetPrompt
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4c280
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetPrompt(struct FString InPrompt);

	// Object: Function FairyGUI.GTextInput.SetPassword
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4c234
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetPassword(bool bInPassword);

	// Object: Function FairyGUI.GTextInput.SetMaxLength
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4c1b4
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetMaxLength(int32_t InMaxLength);

	// Object: Function FairyGUI.GTextInput.SetKeyboardType
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4c1f4
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetKeyboardType(int32_t InKeyboardType);

	// Object: Function FairyGUI.GTextInput.IsSingleLine
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d4c3fc
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsSingleLine();

	// Object: Function FairyGUI.GTextInput.GetTextFormat
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x102d4c350
	// Return & Params: [ Num(1) Size(0x40) ]
	struct FNTextFormat GetTextFormat();

	// Object: Function FairyGUI.GTextInput.ApplyFormat
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4c2dc
	// Return & Params: [ Num(0) Size(0x0) ]
	void ApplyFormat();
};

// Object: Class FairyGUI.GTree
// Inherited Bytes: 0x500 | Struct Size: 0x538
struct UGTree : UGList {
	// Fields
	int32_t Indent; // Offset: 0x500 | Size: 0x4
	int32_t ClickToExpand; // Offset: 0x504 | Size: 0x4
	struct UGTreeNode* RootNode; // Offset: 0x508 | Size: 0x8
	char pad_0x510[0x28]; // Offset: 0x510 | Size: 0x28

	// Functions

	// Object: Function FairyGUI.GTree.UnselectNode
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4cb24
	// Return & Params: [ Num(1) Size(0x8) ]
	void UnselectNode(struct UGTreeNode* Node);

	// Object: Function FairyGUI.GTree.SetTreeNodeRenderer
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102d4c8c0
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetTreeNodeRenderer(struct FDelegate& InDelegate);

	// Object: Function FairyGUI.GTree.SetOnTreeNodeWillExpand
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102d4c6cc
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetOnTreeNodeWillExpand(struct FDelegate& InDelegate);

	// Object: Function FairyGUI.GTree.SelectNode
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4cb5c
	// Return & Params: [ Num(2) Size(0x9) ]
	void SelectNode(struct UGTreeNode* Node, bool bScrollItToView);

	// Object: Function FairyGUI.GTree.OnCellTouchBegin
	// Flags: [Final|Native|Private]
	// Offset: 0x102d4c694
	// Return & Params: [ Num(1) Size(0x8) ]
	void OnCellTouchBegin(struct UEventContext* Context);

	// Object: Function FairyGUI.GTree.GetSelectedNodes
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d4cbd4
	// Return & Params: [ Num(1) Size(0x10) ]
	void GetSelectedNodes(struct TArray<struct UGTreeNode*>& Result);

	// Object: Function FairyGUI.GTree.GetSelectedNode
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d4cc44
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UGTreeNode* GetSelectedNode();

	// Object: Function FairyGUI.GTree.GetRootNode
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d4cc68
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UGTreeNode* GetRootNode();

	// Object: Function FairyGUI.GTree.ExpandAll
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4caec
	// Return & Params: [ Num(1) Size(0x8) ]
	void ExpandAll(struct UGTreeNode* Node);

	// Object: Function FairyGUI.GTree.CollapseAll
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4cab4
	// Return & Params: [ Num(1) Size(0x8) ]
	void CollapseAll(struct UGTreeNode* Node);
};

// Object: Class FairyGUI.GTreeNode
// Inherited Bytes: 0x28 | Struct Size: 0x80
struct UGTreeNode : UObject {
	// Fields
	struct FNVariant UserData; // Offset: 0x28 | Size: 0x18
	char pad_0x40[0x10]; // Offset: 0x40 | Size: 0x10
	struct UGComponent* Cell; // Offset: 0x50 | Size: 0x8
	struct TArray<struct UGTreeNode*> Children; // Offset: 0x58 | Size: 0x10
	char pad_0x68[0x18]; // Offset: 0x68 | Size: 0x18

	// Functions

	// Object: Function FairyGUI.GTreeNode.SwapChildrenAt
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4cf0c
	// Return & Params: [ Num(2) Size(0x8) ]
	void SwapChildrenAt(int32_t Index1, int32_t Index2);

	// Object: Function FairyGUI.GTreeNode.SwapChildren
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4cf68
	// Return & Params: [ Num(2) Size(0x10) ]
	void SwapChildren(struct UGTreeNode* Child, struct UGTreeNode* Child2);

	// Object: Function FairyGUI.GTreeNode.SetText
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4d3c0
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetText(struct FString InText);

	// Object: Function FairyGUI.GTreeNode.SetParent
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4d51c
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetParent(struct UGTreeNode* InParent);

	// Object: Function FairyGUI.GTreeNode.SetIcon
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4d314
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetIcon(struct FString InIcon);

	// Object: Function FairyGUI.GTreeNode.SetExpaned
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4d480
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetExpaned(bool bInExpanded);

	// Object: Function FairyGUI.GTreeNode.SetChildIndex
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4cfdc
	// Return & Params: [ Num(2) Size(0xc) ]
	void SetChildIndex(struct UGTreeNode* Child, int32_t Index);

	// Object: Function FairyGUI.GTreeNode.RemoveChildren
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4d154
	// Return & Params: [ Num(2) Size(0x8) ]
	void RemoveChildren(int32_t BeginIndex, int32_t EndIndex);

	// Object: Function FairyGUI.GTreeNode.RemoveChildAt
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4d1b0
	// Return & Params: [ Num(1) Size(0x4) ]
	void RemoveChildAt(int32_t Index);

	// Object: Function FairyGUI.GTreeNode.RemoveChild
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4d1f0
	// Return & Params: [ Num(1) Size(0x8) ]
	void RemoveChild(struct UGTreeNode* Child);

	// Object: Function FairyGUI.GTreeNode.NumChildren
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d4cee8
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t NumChildren();

	// Object: Function FairyGUI.GTreeNode.IsFolder
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d4d46c
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsFolder();

	// Object: Function FairyGUI.GTreeNode.IsExpanded
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d4d4cc
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsExpanded();

	// Object: Function FairyGUI.GTreeNode.GetTree
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d4d4f4
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UGTree* GetTree();

	// Object: Function FairyGUI.GTreeNode.GetText
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d4d41c
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetText();

	// Object: Function FairyGUI.GTreeNode.GetPrevSibling
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d4d0d8
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UGTreeNode* GetPrevSibling();

	// Object: Function FairyGUI.GTreeNode.GetParent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d4d554
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UGTreeNode* GetParent();

	// Object: Function FairyGUI.GTreeNode.GetNextSibling
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d4d0b4
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UGTreeNode* GetNextSibling();

	// Object: Function FairyGUI.GTreeNode.GetIcon
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d4d370
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetIcon();

	// Object: Function FairyGUI.GTreeNode.GetChildIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d4d060
	// Return & Params: [ Num(2) Size(0xc) ]
	int32_t GetChildIndex(struct UGTreeNode* Child);

	// Object: Function FairyGUI.GTreeNode.GetChildAt
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d4d0fc
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UGTreeNode* GetChildAt(int32_t Index);

	// Object: Function FairyGUI.GTreeNode.GetCell
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d4d4e0
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UGComponent* GetCell();

	// Object: Function FairyGUI.GTreeNode.CreateNode
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102d4d57c
	// Return & Params: [ Num(3) Size(0x20) ]
	struct UGTreeNode* CreateNode(bool bIsFolder, struct FString ResourceURL);

	// Object: Function FairyGUI.GTreeNode.AddChildAt
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4d228
	// Return & Params: [ Num(3) Size(0x18) ]
	struct UGTreeNode* AddChildAt(struct UGTreeNode* Child, int32_t Index);

	// Object: Function FairyGUI.GTreeNode.AddChild
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4d2c0
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UGTreeNode* AddChild(struct UGTreeNode* Child);
};

// Object: Class FairyGUI.GWindow
// Inherited Bytes: 0x448 | Struct Size: 0x4f0
struct UGWindow : UGComponent {
	// Fields
	bool bBringToFontOnClick; // Offset: 0x448 | Size: 0x1
	char pad_0x449[0x3]; // Offset: 0x449 | Size: 0x3
	struct FDelegate InitCallback; // Offset: 0x44c | Size: 0x10
	struct FDelegate ShownCallback; // Offset: 0x45c | Size: 0x10
	struct FDelegate HideCallback; // Offset: 0x46c | Size: 0x10
	struct FDelegate ShowingCallback; // Offset: 0x47c | Size: 0x10
	struct FDelegate HidingCallback; // Offset: 0x48c | Size: 0x10
	char pad_0x49C[0x4]; // Offset: 0x49c | Size: 0x4
	struct UGComponent* ContentPane; // Offset: 0x4a0 | Size: 0x8
	struct UGObject* ModalWaitPane; // Offset: 0x4a8 | Size: 0x8
	struct UGComponent* FrameObject; // Offset: 0x4b0 | Size: 0x8
	struct UGObject* CloseButton; // Offset: 0x4b8 | Size: 0x8
	struct UGObject* DragArea; // Offset: 0x4c0 | Size: 0x8
	struct UGObject* ContentArea; // Offset: 0x4c8 | Size: 0x8
	char pad_0x4D0[0x20]; // Offset: 0x4d0 | Size: 0x20

	// Functions

	// Object: Function FairyGUI.GWindow.ToggleStatus
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4df10
	// Return & Params: [ Num(0) Size(0x0) ]
	void ToggleStatus();

	// Object: Function FairyGUI.GWindow.ShowModalWait
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4ddf8
	// Return & Params: [ Num(1) Size(0x4) ]
	void ShowModalWait(int32_t InRequestingCmd);

	// Object: Function FairyGUI.GWindow.Show
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4df40
	// Return & Params: [ Num(0) Size(0x0) ]
	void Show();

	// Object: Function FairyGUI.GWindow.SetModal
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4de38
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetModal(bool bInModal);

	// Object: Function FairyGUI.GWindow.SetDragArea
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4dca8
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetDragArea(struct UGObject* Obj);

	// Object: Function FairyGUI.GWindow.SetContentPane
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4dd54
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetContentPane(struct UGComponent* Obj);

	// Object: Function FairyGUI.GWindow.SetContentArea
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4dc58
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetContentArea(struct UGObject* Obj);

	// Object: Function FairyGUI.GWindow.SetCloseButton
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4dcf4
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetCloseButton(struct UGObject* Obj);

	// Object: Function FairyGUI.GWindow.OnDragStartHandler
	// Flags: [Final|Native|Private]
	// Offset: 0x102d4dbd4
	// Return & Params: [ Num(1) Size(0x8) ]
	void OnDragStartHandler(struct UEventContext* Context);

	// Object: Function FairyGUI.GWindow.IsTop
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d4deb4
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsTop();

	// Object: Function FairyGUI.GWindow.IsShowing
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d4ded8
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsShowing();

	// Object: Function FairyGUI.GWindow.IsModal
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d4de9c
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsModal();

	// Object: Function FairyGUI.GWindow.HideImmediately
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4df20
	// Return & Params: [ Num(0) Size(0x0) ]
	void HideImmediately();

	// Object: Function FairyGUI.GWindow.Hide
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4df30
	// Return & Params: [ Num(0) Size(0x0) ]
	void Hide();

	// Object: Function FairyGUI.GWindow.GetModalWaitingPane
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d4dc44
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UGObject* GetModalWaitingPane();

	// Object: Function FairyGUI.GWindow.GetFrame
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d4dd40
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UGComponent* GetFrame();

	// Object: Function FairyGUI.GWindow.GetDragArea
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d4dce0
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UGObject* GetDragArea();

	// Object: Function FairyGUI.GWindow.GetContentPane
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d4dd8c
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UGComponent* GetContentPane();

	// Object: Function FairyGUI.GWindow.GetContentArea
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d4dc94
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UGObject* GetContentArea();

	// Object: Function FairyGUI.GWindow.GetCloseButton
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d4dd2c
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UGObject* GetCloseButton();

	// Object: Function FairyGUI.GWindow.CreateWidget
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102d4df50
	// Return & Params: [ Num(4) Size(0x30) ]
	struct UGWindow* CreateWidget(struct FString PackageName, struct FString ResourceName, struct UObject* WorldContextObject);

	// Object: Function FairyGUI.GWindow.CloseModalWait
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4dda0
	// Return & Params: [ Num(2) Size(0x5) ]
	bool CloseModalWait(int32_t InRequestingCmd);

	// Object: Function FairyGUI.GWindow.CloseEventHandler
	// Flags: [Final|Native|Protected]
	// Offset: 0x102d4dc0c
	// Return & Params: [ Num(1) Size(0x8) ]
	void CloseEventHandler(struct UEventContext* Context);

	// Object: Function FairyGUI.GWindow.BringToFront
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4df00
	// Return & Params: [ Num(0) Size(0x0) ]
	void BringToFront();
};

// Object: Class FairyGUI.NTexture
// Inherited Bytes: 0x28 | Struct Size: 0x78
struct UNTexture : UObject {
	// Fields
	struct UNTexture* Root; // Offset: 0x28 | Size: 0x8
	struct UTexture2D* NativeTexture; // Offset: 0x30 | Size: 0x8
	char pad_0x38[0x40]; // Offset: 0x38 | Size: 0x40
};

// Object: Class FairyGUI.PopupMenu
// Inherited Bytes: 0x28 | Struct Size: 0x38
struct UPopupMenu : UObject {
	// Fields
	struct UGComponent* ContentPane; // Offset: 0x28 | Size: 0x8
	char pad_0x30[0x8]; // Offset: 0x30 | Size: 0x8

	// Functions

	// Object: Function FairyGUI.PopupMenu.Show
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4f494
	// Return & Params: [ Num(2) Size(0x9) ]
	void Show(struct UGObject* AtObject, enum class EPopupDirection Dir);

	// Object: Function FairyGUI.PopupMenu.SetItemVisible
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4f7b8
	// Return & Params: [ Num(2) Size(0x11) ]
	void SetItemVisible(struct FString Name, bool bVisible);

	// Object: Function FairyGUI.PopupMenu.SetItemText
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4f834
	// Return & Params: [ Num(2) Size(0x20) ]
	void SetItemText(struct FString Name, struct FString Caption);

	// Object: Function FairyGUI.PopupMenu.SetItemGrayed
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4f73c
	// Return & Params: [ Num(2) Size(0x11) ]
	void SetItemGrayed(struct FString Name, bool bGrayed);

	// Object: Function FairyGUI.PopupMenu.SetItemChecked
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4f644
	// Return & Params: [ Num(2) Size(0x11) ]
	void SetItemChecked(struct FString Name, bool bCheck);

	// Object: Function FairyGUI.PopupMenu.SetItemCheckable
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4f6c0
	// Return & Params: [ Num(2) Size(0x11) ]
	void SetItemCheckable(struct FString Name, bool bCheckable);

	// Object: Function FairyGUI.PopupMenu.RemoveItem
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4f574
	// Return & Params: [ Num(2) Size(0x11) ]
	bool RemoveItem(struct FString Name);

	// Object: Function FairyGUI.PopupMenu.IsItemChecked
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d4f5dc
	// Return & Params: [ Num(2) Size(0x11) ]
	bool IsItemChecked(struct FString Name);

	// Object: Function FairyGUI.PopupMenu.GetList
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d4f518
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UGList* GetList();

	// Object: Function FairyGUI.PopupMenu.GetItemName
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d4f8e4
	// Return & Params: [ Num(2) Size(0x18) ]
	struct FString GetItemName(int32_t Index);

	// Object: Function FairyGUI.PopupMenu.GetItemCount
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d4f540
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetItemCount();

	// Object: Function FairyGUI.PopupMenu.GetContentPane
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d4f52c
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UGComponent* GetContentPane();

	// Object: Function FairyGUI.PopupMenu.CreatePopupMenu
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102d4fb48
	// Return & Params: [ Num(3) Size(0x20) ]
	struct UPopupMenu* CreatePopupMenu(struct FString ResourceURL, struct UObject* WorldContextObject);

	// Object: Function FairyGUI.PopupMenu.ClearItems
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4f564
	// Return & Params: [ Num(0) Size(0x0) ]
	void ClearItems();

	// Object: Function FairyGUI.PopupMenu.AddSeperator
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4f96c
	// Return & Params: [ Num(0) Size(0x0) ]
	void AddSeperator();

	// Object: Function FairyGUI.PopupMenu.AddItemAt
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102d4f97c
	// Return & Params: [ Num(4) Size(0x30) ]
	struct UGButton* AddItemAt(struct FString Caption, int32_t Index, struct FDelegate& Callback);

	// Object: Function FairyGUI.PopupMenu.AddItem
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102d4fa84
	// Return & Params: [ Num(3) Size(0x28) ]
	struct UGButton* AddItem(struct FString Caption, struct FDelegate& Callback);
};

// Object: Class FairyGUI.ScrollPane
// Inherited Bytes: 0x28 | Struct Size: 0x150
struct UScrollPane : UObject {
	// Fields
	char bBouncebackEffect : 1; // Offset: 0x28 | Size: 0x1
	char bTouchEffect : 1; // Offset: 0x28 | Size: 0x1
	char bInertiaDisabled : 1; // Offset: 0x28 | Size: 0x1
	char bMouseWheelEnabled : 1; // Offset: 0x28 | Size: 0x1
	char bSnapToItem : 1; // Offset: 0x28 | Size: 0x1
	char bPageMode : 1; // Offset: 0x28 | Size: 0x1
	char pad_0x28_6 : 2; // Offset: 0x28 | Size: 0x1
	char pad_0x29[0x3]; // Offset: 0x29 | Size: 0x3
	float DecelerationRate; // Offset: 0x2c | Size: 0x4
	float ScrollStep; // Offset: 0x30 | Size: 0x4
	char pad_0x34[0x4]; // Offset: 0x34 | Size: 0x4
	struct UGController* PageController; // Offset: 0x38 | Size: 0x8
	char pad_0x40[0x28]; // Offset: 0x40 | Size: 0x28
	struct UGScrollBar* HzScrollBar; // Offset: 0x68 | Size: 0x8
	struct UGScrollBar* VtScrollBar; // Offset: 0x70 | Size: 0x8
	struct UGComponent* Header; // Offset: 0x78 | Size: 0x8
	struct UGComponent* Footer; // Offset: 0x80 | Size: 0x8
	char pad_0x88[0xc8]; // Offset: 0x88 | Size: 0xc8

	// Functions

	// Object: Function FairyGUI.ScrollPane.SetPosY
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d5069c
	// Return & Params: [ Num(2) Size(0x5) ]
	void SetPosY(float Value, bool bAnimation);

	// Object: Function FairyGUI.ScrollPane.SetPosX
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d50710
	// Return & Params: [ Num(2) Size(0x5) ]
	void SetPosX(float Value, bool bAnimation);

	// Object: Function FairyGUI.ScrollPane.SetPercY
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d50594
	// Return & Params: [ Num(2) Size(0x5) ]
	void SetPercY(float Value, bool bAnimation);

	// Object: Function FairyGUI.ScrollPane.SetPercX
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d50618
	// Return & Params: [ Num(2) Size(0x5) ]
	void SetPercX(float Value, bool bAnimation);

	// Object: Function FairyGUI.ScrollPane.SetPageY
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d500d8
	// Return & Params: [ Num(2) Size(0x5) ]
	void SetPageY(int32_t PageY, bool bAnimation);

	// Object: Function FairyGUI.ScrollPane.SetPageX
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d50168
	// Return & Params: [ Num(2) Size(0x5) ]
	void SetPageX(int32_t PageX, bool bAnimation);

	// Object: Function FairyGUI.ScrollPane.ScrollUp
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d5042c
	// Return & Params: [ Num(2) Size(0x5) ]
	void ScrollUp(float Ratio, bool bAnimation);

	// Object: Function FairyGUI.ScrollPane.ScrollToView
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d5025c
	// Return & Params: [ Num(3) Size(0xa) ]
	void ScrollToView(struct UGObject* Obj, bool bAnimation, bool bSetFirst);

	// Object: Function FairyGUI.ScrollPane.ScrollTop
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d50380
	// Return & Params: [ Num(1) Size(0x1) ]
	void ScrollTop(bool bAnimation);

	// Object: Function FairyGUI.ScrollPane.ScrollRight
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d5048c
	// Return & Params: [ Num(2) Size(0x5) ]
	void ScrollRight(float Ratio, bool bAnimation);

	// Object: Function FairyGUI.ScrollPane.ScrollLeft
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d504ec
	// Return & Params: [ Num(2) Size(0x5) ]
	void ScrollLeft(float Ratio, bool bAnimation);

	// Object: Function FairyGUI.ScrollPane.ScrollDown
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d503cc
	// Return & Params: [ Num(2) Size(0x5) ]
	void ScrollDown(float Ratio, bool bAnimation);

	// Object: Function FairyGUI.ScrollPane.ScrollBottom
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d50334
	// Return & Params: [ Num(1) Size(0x1) ]
	void ScrollBottom(bool bAnimation);

	// Object: Function FairyGUI.ScrollPane.LockHeader
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d50028
	// Return & Params: [ Num(1) Size(0x4) ]
	void LockHeader(int32_t Size);

	// Object: Function FairyGUI.ScrollPane.LockFooter
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4ffe8
	// Return & Params: [ Num(1) Size(0x4) ]
	void LockFooter(int32_t Size);

	// Object: Function FairyGUI.ScrollPane.IsRightMost
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d5054c
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsRightMost();

	// Object: Function FairyGUI.ScrollPane.IsChildInView
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d501f8
	// Return & Params: [ Num(2) Size(0x9) ]
	bool IsChildInView(struct UGObject* Obj);

	// Object: Function FairyGUI.ScrollPane.IsBottomMost
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d50570
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsBottomMost();

	// Object: Function FairyGUI.ScrollPane.GetVtScrollBar
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d50798
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UGScrollBar* GetVtScrollBar();

	// Object: Function FairyGUI.ScrollPane.GetViewSize
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d50068
	// Return & Params: [ Num(1) Size(0x8) ]
	struct FVector2D GetViewSize();

	// Object: Function FairyGUI.ScrollPane.GetScrollingPosY
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d50090
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetScrollingPosY();

	// Object: Function FairyGUI.ScrollPane.GetScrollingPosX
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d500b4
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetScrollingPosX();

	// Object: Function FairyGUI.ScrollPane.GetPosY
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d506fc
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetPosY();

	// Object: Function FairyGUI.ScrollPane.GetPosX
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d50770
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetPosX();

	// Object: Function FairyGUI.ScrollPane.GetPercY
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d505f4
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetPercY();

	// Object: Function FairyGUI.ScrollPane.GetPercX
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d50678
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetPercX();

	// Object: Function FairyGUI.ScrollPane.GetPageY
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d50144
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetPageY();

	// Object: Function FairyGUI.ScrollPane.GetPageX
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d501d4
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetPageX();

	// Object: Function FairyGUI.ScrollPane.GetHzScrollBar
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d50784
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UGScrollBar* GetHzScrollBar();

	// Object: Function FairyGUI.ScrollPane.GetHeader
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d507c0
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UGComponent* GetHeader();

	// Object: Function FairyGUI.ScrollPane.GetFooter
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d507ac
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UGComponent* GetFooter();

	// Object: Function FairyGUI.ScrollPane.GetContentSize
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d5007c
	// Return & Params: [ Num(1) Size(0x8) ]
	struct FVector2D GetContentSize();

	// Object: Function FairyGUI.ScrollPane.CancelDragging
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d4ffd8
	// Return & Params: [ Num(0) Size(0x0) ]
	void CancelDragging();
};

// Object: Class FairyGUI.Transition
// Inherited Bytes: 0x28 | Struct Size: 0xa8
struct UTransition : UObject {
	// Fields
	struct FString Name; // Offset: 0x28 | Size: 0x10
	char pad_0x38[0x70]; // Offset: 0x38 | Size: 0x70

	// Functions

	// Object: Function FairyGUI.Transition.Stop
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d51578
	// Return & Params: [ Num(2) Size(0x2) ]
	void Stop(bool bSetToComplete, bool bProcessCallback);

	// Object: Function FairyGUI.Transition.SetValue
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102d51394
	// Return & Params: [ Num(2) Size(0x20) ]
	void SetValue(struct FString InLabel, struct TArray<struct FNVariant>& InValues);

	// Object: Function FairyGUI.Transition.SetTimeScale
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d50fd4
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetTimeScale(float InTimeScale);

	// Object: Function FairyGUI.Transition.SetTarget
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d5113c
	// Return & Params: [ Num(2) Size(0x18) ]
	void SetTarget(struct FString InLabel, struct UGObject* InTarget);

	// Object: Function FairyGUI.Transition.SetPaused
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d51470
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetPaused(bool bInPaused);

	// Object: Function FairyGUI.Transition.SetHook
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d511d4
	// Return & Params: [ Num(2) Size(0x20) ]
	void SetHook(struct FString InLabel, struct FDelegate Callback);

	// Object: Function FairyGUI.Transition.SetDuration
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d510a4
	// Return & Params: [ Num(2) Size(0x14) ]
	void SetDuration(struct FString InLabel, float InDuration);

	// Object: Function FairyGUI.Transition.SetAutoPlay
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d514bc
	// Return & Params: [ Num(3) Size(0xc) ]
	void SetAutoPlay(bool bInAutoPlay, int32_t InTimes, float InDelay);

	// Object: Function FairyGUI.Transition.PlayReverse
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102d5163c
	// Return & Params: [ Num(3) Size(0x18) ]
	void PlayReverse(struct FDelegate& InCompleteCallback, int32_t InTimes, float InDelay);

	// Object: Function FairyGUI.Transition.Play
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102d51840
	// Return & Params: [ Num(5) Size(0x20) ]
	void Play(struct FDelegate& InCompleteCallback, int32_t InTimes, float InDelay, float InStartTime, float InEndTime);

	// Object: Function FairyGUI.Transition.GetTimeScale
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d51028
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetTimeScale();

	// Object: Function FairyGUI.Transition.GetLabelTime
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d5103c
	// Return & Params: [ Num(2) Size(0x14) ]
	float GetLabelTime(struct FString InLabel);

	// Object: Function FairyGUI.Transition.ClearHooks
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d511c4
	// Return & Params: [ Num(0) Size(0x0) ]
	void ClearHooks();

	// Object: Function FairyGUI.Transition.ChangePlayTimes
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d515fc
	// Return & Params: [ Num(1) Size(0x4) ]
	void ChangePlayTimes(int32_t InTimes);
};

// Object: Class FairyGUI.UIPackage
// Inherited Bytes: 0x28 | Struct Size: 0x1e8
struct UUIPackage : UObject {
	// Fields
	char pad_0x28[0x30]; // Offset: 0x28 | Size: 0x30
	struct UUIPackageAsset* Asset; // Offset: 0x58 | Size: 0x8
	char pad_0x60[0x188]; // Offset: 0x60 | Size: 0x188

	// Functions

	// Object: Function FairyGUI.UIPackage.SetVar
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102d52468
	// Return & Params: [ Num(2) Size(0x20) ]
	void SetVar(struct FString VarKey, struct FString VarValue);

	// Object: Function FairyGUI.UIPackage.SetBranch
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102d52598
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetBranch(struct FString InBranch);

	// Object: Function FairyGUI.UIPackage.RemovePackage
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102d52370
	// Return & Params: [ Num(2) Size(0x18) ]
	void RemovePackage(struct FString IDOrName, struct UObject* WorldContextObject);

	// Object: Function FairyGUI.UIPackage.RemoveAllPackages
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102d52360
	// Return & Params: [ Num(0) Size(0x0) ]
	void RemoveAllPackages();

	// Object: Function FairyGUI.UIPackage.RegisterFont
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102d52054
	// Return & Params: [ Num(2) Size(0x18) ]
	void RegisterFont(struct FString FontFace, struct UObject* Font);

	// Object: Function FairyGUI.UIPackage.GetVar
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102d524f4
	// Return & Params: [ Num(2) Size(0x20) ]
	struct FString GetVar(struct FString VarKey);

	// Object: Function FairyGUI.UIPackage.GetPackageByName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102d52290
	// Return & Params: [ Num(2) Size(0x18) ]
	struct UUIPackage* GetPackageByName(struct FString PackageName);

	// Object: Function FairyGUI.UIPackage.GetPackageByID
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102d522f8
	// Return & Params: [ Num(2) Size(0x18) ]
	struct UUIPackage* GetPackageByID(struct FString PackageID);

	// Object: Function FairyGUI.UIPackage.GetName
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d51fa4
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetName();

	// Object: Function FairyGUI.UIPackage.GetID
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x102d51ffc
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetID();

	// Object: Function FairyGUI.UIPackage.GetBranch
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102d525fc
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetBranch();

	// Object: Function FairyGUI.UIPackage.CreateObjectFromURL
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102d520cc
	// Return & Params: [ Num(4) Size(0x28) ]
	struct UGObject* CreateObjectFromURL(struct FString URL, struct UObject* WorldContextObject, struct UGObject* ClassType);

	// Object: Function FairyGUI.UIPackage.CreateObject
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102d52188
	// Return & Params: [ Num(5) Size(0x38) ]
	struct UGObject* CreateObject(struct FString PackageName, struct FString ResourceName, struct UObject* WorldContextObject, struct UGObject* ClassType);

	// Object: Function FairyGUI.UIPackage.AddPackage
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102d523e8
	// Return & Params: [ Num(3) Size(0x18) ]
	struct UUIPackage* AddPackage(struct UUIPackageAsset* InAsset, struct UObject* WorldContextObject);
};

// Object: Class FairyGUI.UIPackageStatic
// Inherited Bytes: 0x28 | Struct Size: 0x188
struct UUIPackageStatic : UObject {
	// Fields
	struct TArray<struct UUIPackage*> PackageList; // Offset: 0x28 | Size: 0x10
	char pad_0x38[0x100]; // Offset: 0x38 | Size: 0x100
	struct TMap<struct FString, struct UObject*> Fonts; // Offset: 0x138 | Size: 0x50
};

// Object: Class FairyGUI.UIPackageAsset
// Inherited Bytes: 0x28 | Struct Size: 0x38
struct UUIPackageAsset : UObject {
	// Fields
	struct TArray<char> Data; // Offset: 0x28 | Size: 0x10
};

