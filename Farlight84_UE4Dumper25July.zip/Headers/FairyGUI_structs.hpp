#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct FairyGUI.TweenValue
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FTweenValue {
	// Fields
	float X; // Offset: 0x0 | Size: 0x4
	float Y; // Offset: 0x4 | Size: 0x4
	float Z; // Offset: 0x8 | Size: 0x4
	float W; // Offset: 0xc | Size: 0x4
	char pad_0x10[0x8]; // Offset: 0x10 | Size: 0x8
};

// Object: ScriptStruct FairyGUI.NTextFormat
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FNTextFormat {
	// Fields
	struct FString Face; // Offset: 0x0 | Size: 0x10
	int32_t Size; // Offset: 0x10 | Size: 0x4
	struct FColor Color; // Offset: 0x14 | Size: 0x4
	bool bBold; // Offset: 0x18 | Size: 0x1
	bool bItalic; // Offset: 0x19 | Size: 0x1
	bool bUnderline; // Offset: 0x1a | Size: 0x1
	char pad_0x1B[0x1]; // Offset: 0x1b | Size: 0x1
	int32_t LineSpacing; // Offset: 0x1c | Size: 0x4
	int32_t LetterSpacing; // Offset: 0x20 | Size: 0x4
	enum class EAlignType Align; // Offset: 0x24 | Size: 0x1
	enum class EVerticalAlignType VerticalAlign; // Offset: 0x25 | Size: 0x1
	char pad_0x26[0x2]; // Offset: 0x26 | Size: 0x2
	struct FColor OutlineColor; // Offset: 0x28 | Size: 0x4
	int32_t OutlineSize; // Offset: 0x2c | Size: 0x4
	struct FColor ShadowColor; // Offset: 0x30 | Size: 0x4
	struct FVector2D ShadowOffset; // Offset: 0x34 | Size: 0x8
	char pad_0x3C[0x4]; // Offset: 0x3c | Size: 0x4
};

// Object: ScriptStruct FairyGUI.NVariant
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FNVariant {
	// Fields
	char pad_0x0[0x18]; // Offset: 0x0 | Size: 0x18
};

// Object: ScriptStruct FairyGUI.TweenerHandle
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FTweenerHandle {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
};

// Object: ScriptStruct FairyGUI.UIConfig
// Inherited Bytes: 0x0 | Struct Size: 0xc0
struct FUIConfig {
	// Fields
	struct FString DefaultFont; // Offset: 0x0 | Size: 0x10
	struct FString ButtonSound; // Offset: 0x10 | Size: 0x10
	float ButtonSoundVolumeScale; // Offset: 0x20 | Size: 0x4
	int32_t DefaultScrollStep; // Offset: 0x24 | Size: 0x4
	float DefaultScrollDecelerationRate; // Offset: 0x28 | Size: 0x4
	bool DefaultScrollTouchEffect; // Offset: 0x2c | Size: 0x1
	bool DefaultScrollBounceEffect; // Offset: 0x2d | Size: 0x1
	enum class EScrollBarDisplayType DefaultScrollBarDisplay; // Offset: 0x2e | Size: 0x1
	char pad_0x2F[0x1]; // Offset: 0x2f | Size: 0x1
	struct FString VerticalScrollBar; // Offset: 0x30 | Size: 0x10
	struct FString HorizontalScrollBar; // Offset: 0x40 | Size: 0x10
	int32_t TouchDragSensitivity; // Offset: 0x50 | Size: 0x4
	int32_t ClickDragSensitivity; // Offset: 0x54 | Size: 0x4
	int32_t TouchScrollSensitivity; // Offset: 0x58 | Size: 0x4
	int32_t DefaultComboBoxVisibleItemCount; // Offset: 0x5c | Size: 0x4
	struct FString GlobalModalWaiting; // Offset: 0x60 | Size: 0x10
	struct FColor ModalLayerColor; // Offset: 0x70 | Size: 0x4
	char pad_0x74[0x4]; // Offset: 0x74 | Size: 0x4
	struct FString TooltipsWin; // Offset: 0x78 | Size: 0x10
	bool BringWindowToFrontOnClick; // Offset: 0x88 | Size: 0x1
	char pad_0x89[0x7]; // Offset: 0x89 | Size: 0x7
	struct FString WindowModalWaiting; // Offset: 0x90 | Size: 0x10
	struct FString PopupMenu; // Offset: 0xa0 | Size: 0x10
	struct FString PopupMenuSeperator; // Offset: 0xb0 | Size: 0x10
};

