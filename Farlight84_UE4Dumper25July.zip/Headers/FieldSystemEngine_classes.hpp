#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class FieldSystemEngine.FieldSystemActor
// Inherited Bytes: 0x248 | Struct Size: 0x250
struct AFieldSystemActor : AActor {
	// Fields
	struct UFieldSystemComponent* FieldSystemComponent; // Offset: 0x248 | Size: 0x8
};

// Object: Class FieldSystemEngine.FieldSystem
// Inherited Bytes: 0x28 | Struct Size: 0x38
struct UFieldSystem : UObject {
	// Fields
	char pad_0x28[0x10]; // Offset: 0x28 | Size: 0x10
};

// Object: Class FieldSystemEngine.FieldSystemComponent
// Inherited Bytes: 0x5e0 | Struct Size: 0x620
struct UFieldSystemComponent : UPrimitiveComponent {
	// Fields
	struct UFieldSystem* FieldSystem; // Offset: 0x5d8 | Size: 0x8
	char pad_0x5E8[0x8]; // Offset: 0x5e8 | Size: 0x8
	struct TArray<struct TSoftObjectPtr<AChaosSolverActor>> SupportedSolvers; // Offset: 0x5f0 | Size: 0x10
	char pad_0x600[0x20]; // Offset: 0x600 | Size: 0x20

	// Functions

	// Object: Function FieldSystemEngine.FieldSystemComponent.ResetFieldSystem
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1057f37f0
	// Return & Params: [ Num(0) Size(0x0) ]
	void ResetFieldSystem();

	// Object: Function FieldSystemEngine.FieldSystemComponent.ApplyUniformVectorFalloffForce
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x1057f39c0
	// Return & Params: [ Num(5) Size(0x24) ]
	void ApplyUniformVectorFalloffForce(bool Enabled, struct FVector Position, struct FVector Direction, float Radius, float Magnitude);

	// Object: Function FieldSystemEngine.FieldSystemComponent.ApplyStrainField
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x1057f38c8
	// Return & Params: [ Num(5) Size(0x1c) ]
	void ApplyStrainField(bool Enabled, struct FVector Position, float Radius, float Magnitude, int32_t Iterations);

	// Object: Function FieldSystemEngine.FieldSystemComponent.ApplyStayDynamicField
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x1057f3c4c
	// Return & Params: [ Num(3) Size(0x14) ]
	void ApplyStayDynamicField(bool Enabled, struct FVector Position, float Radius);

	// Object: Function FieldSystemEngine.FieldSystemComponent.ApplyRadialVectorFalloffForce
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x1057f3af0
	// Return & Params: [ Num(4) Size(0x18) ]
	void ApplyRadialVectorFalloffForce(bool Enabled, struct FVector Position, float Radius, float Magnitude);

	// Object: Function FieldSystemEngine.FieldSystemComponent.ApplyRadialForce
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x1057f3bb8
	// Return & Params: [ Num(3) Size(0x14) ]
	void ApplyRadialForce(bool Enabled, struct FVector Position, float Magnitude);

	// Object: Function FieldSystemEngine.FieldSystemComponent.ApplyPhysicsField
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1057f3804
	// Return & Params: [ Num(4) Size(0x18) ]
	void ApplyPhysicsField(bool Enabled, enum class EFieldPhysicsType Target, struct UFieldSystemMetaData* MetaData, struct UFieldNodeBase* Field);

	// Object: Function FieldSystemEngine.FieldSystemComponent.ApplyLinearForce
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x1057f3ce0
	// Return & Params: [ Num(3) Size(0x14) ]
	void ApplyLinearForce(bool Enabled, struct FVector Direction, float Magnitude);

	// Object: Function FieldSystemEngine.FieldSystemComponent.AddFieldCommand
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1057f372c
	// Return & Params: [ Num(4) Size(0x18) ]
	void AddFieldCommand(bool Enabled, enum class EFieldPhysicsType Target, struct UFieldSystemMetaData* MetaData, struct UFieldNodeBase* Field);
};

// Object: Class FieldSystemEngine.FieldSystemMetaData
// Inherited Bytes: 0xc0 | Struct Size: 0xc0
struct UFieldSystemMetaData : UActorComponent {
};

// Object: Class FieldSystemEngine.FieldSystemMetaDataIteration
// Inherited Bytes: 0xc0 | Struct Size: 0xc8
struct UFieldSystemMetaDataIteration : UFieldSystemMetaData {
	// Fields
	int32_t Iterations; // Offset: 0xc0 | Size: 0x4
	char pad_0xC4[0x4]; // Offset: 0xc4 | Size: 0x4

	// Functions

	// Object: Function FieldSystemEngine.FieldSystemMetaDataIteration.SetMetaDataIteration
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1057f408c
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UFieldSystemMetaDataIteration* SetMetaDataIteration(int32_t Iterations);
};

// Object: Class FieldSystemEngine.FieldSystemMetaDataProcessingResolution
// Inherited Bytes: 0xc0 | Struct Size: 0xc8
struct UFieldSystemMetaDataProcessingResolution : UFieldSystemMetaData {
	// Fields
	enum class EFieldResolutionType ResolutionType; // Offset: 0xc0 | Size: 0x1
	char pad_0xC1[0x7]; // Offset: 0xc1 | Size: 0x7

	// Functions

	// Object: Function FieldSystemEngine.FieldSystemMetaDataProcessingResolution.SetMetaDataaProcessingResolutionType
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1057f4180
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UFieldSystemMetaDataProcessingResolution* SetMetaDataaProcessingResolutionType(enum class EFieldResolutionType ResolutionType);
};

// Object: Class FieldSystemEngine.FieldNodeBase
// Inherited Bytes: 0xc0 | Struct Size: 0xc0
struct UFieldNodeBase : UActorComponent {
};

// Object: Class FieldSystemEngine.FieldNodeInt
// Inherited Bytes: 0xc0 | Struct Size: 0xc0
struct UFieldNodeInt : UFieldNodeBase {
};

// Object: Class FieldSystemEngine.FieldNodeFloat
// Inherited Bytes: 0xc0 | Struct Size: 0xc0
struct UFieldNodeFloat : UFieldNodeBase {
};

// Object: Class FieldSystemEngine.FieldNodeVector
// Inherited Bytes: 0xc0 | Struct Size: 0xc0
struct UFieldNodeVector : UFieldNodeBase {
};

// Object: Class FieldSystemEngine.UniformInteger
// Inherited Bytes: 0xc0 | Struct Size: 0xc8
struct UUniformInteger : UFieldNodeInt {
	// Fields
	int32_t Magnitude; // Offset: 0xc0 | Size: 0x4
	char pad_0xC4[0x4]; // Offset: 0xc4 | Size: 0x4

	// Functions

	// Object: Function FieldSystemEngine.UniformInteger.SetUniformInteger
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1057f45d0
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UUniformInteger* SetUniformInteger(int32_t Magnitude);
};

// Object: Class FieldSystemEngine.RadialIntMask
// Inherited Bytes: 0xc0 | Struct Size: 0xe0
struct URadialIntMask : UFieldNodeInt {
	// Fields
	float Radius; // Offset: 0xc0 | Size: 0x4
	struct FVector Position; // Offset: 0xc4 | Size: 0xc
	int32_t InteriorValue; // Offset: 0xd0 | Size: 0x4
	int32_t ExteriorValue; // Offset: 0xd4 | Size: 0x4
	enum class ESetMaskConditionType SetMaskCondition; // Offset: 0xd8 | Size: 0x1
	char pad_0xD9[0x7]; // Offset: 0xd9 | Size: 0x7

	// Functions

	// Object: Function FieldSystemEngine.RadialIntMask.SetRadialIntMask
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x1057f46d8
	// Return & Params: [ Num(6) Size(0x28) ]
	struct URadialIntMask* SetRadialIntMask(float Radius, struct FVector Position, int32_t InteriorValue, int32_t ExteriorValue, enum class ESetMaskConditionType SetMaskConditionIn);
};

// Object: Class FieldSystemEngine.UniformScalar
// Inherited Bytes: 0xc0 | Struct Size: 0xc8
struct UUniformScalar : UFieldNodeFloat {
	// Fields
	float Magnitude; // Offset: 0xc0 | Size: 0x4
	char pad_0xC4[0x4]; // Offset: 0xc4 | Size: 0x4

	// Functions

	// Object: Function FieldSystemEngine.UniformScalar.SetUniformScalar
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1057f48d0
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UUniformScalar* SetUniformScalar(float Magnitude);
};

// Object: Class FieldSystemEngine.RadialFalloff
// Inherited Bytes: 0xc0 | Struct Size: 0xe8
struct URadialFalloff : UFieldNodeFloat {
	// Fields
	float Magnitude; // Offset: 0xc0 | Size: 0x4
	float MinRange; // Offset: 0xc4 | Size: 0x4
	float MaxRange; // Offset: 0xc8 | Size: 0x4
	float Default; // Offset: 0xcc | Size: 0x4
	float Radius; // Offset: 0xd0 | Size: 0x4
	struct FVector Position; // Offset: 0xd4 | Size: 0xc
	enum class EFieldFalloffType Falloff; // Offset: 0xe0 | Size: 0x1
	char pad_0xE1[0x7]; // Offset: 0xe1 | Size: 0x7

	// Functions

	// Object: Function FieldSystemEngine.RadialFalloff.SetRadialFalloff
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x1057f49dc
	// Return & Params: [ Num(8) Size(0x30) ]
	struct URadialFalloff* SetRadialFalloff(float Magnitude, float MinRange, float MaxRange, float Default, float Radius, struct FVector Position, enum class EFieldFalloffType Falloff);
};

// Object: Class FieldSystemEngine.PlaneFalloff
// Inherited Bytes: 0xc0 | Struct Size: 0xf0
struct UPlaneFalloff : UFieldNodeFloat {
	// Fields
	float Magnitude; // Offset: 0xc0 | Size: 0x4
	float MinRange; // Offset: 0xc4 | Size: 0x4
	float MaxRange; // Offset: 0xc8 | Size: 0x4
	float Default; // Offset: 0xcc | Size: 0x4
	float Distance; // Offset: 0xd0 | Size: 0x4
	struct FVector Position; // Offset: 0xd4 | Size: 0xc
	struct FVector Normal; // Offset: 0xe0 | Size: 0xc
	enum class EFieldFalloffType Falloff; // Offset: 0xec | Size: 0x1
	char pad_0xED[0x3]; // Offset: 0xed | Size: 0x3

	// Functions

	// Object: Function FieldSystemEngine.PlaneFalloff.SetPlaneFalloff
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x1057f4bdc
	// Return & Params: [ Num(9) Size(0x38) ]
	struct UPlaneFalloff* SetPlaneFalloff(float Magnitude, float MinRange, float MaxRange, float Default, float Distance, struct FVector Position, struct FVector Normal, enum class EFieldFalloffType Falloff);
};

// Object: Class FieldSystemEngine.BoxFalloff
// Inherited Bytes: 0xc0 | Struct Size: 0x110
struct UBoxFalloff : UFieldNodeFloat {
	// Fields
	float Magnitude; // Offset: 0xc0 | Size: 0x4
	float MinRange; // Offset: 0xc4 | Size: 0x4
	float MaxRange; // Offset: 0xc8 | Size: 0x4
	float Default; // Offset: 0xcc | Size: 0x4
	struct FTransform Transform; // Offset: 0xd0 | Size: 0x30
	enum class EFieldFalloffType Falloff; // Offset: 0x100 | Size: 0x1
	char pad_0x101[0xf]; // Offset: 0x101 | Size: 0xf

	// Functions

	// Object: Function FieldSystemEngine.BoxFalloff.SetBoxFalloff
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x1057f4e1c
	// Return & Params: [ Num(7) Size(0x50) ]
	struct UBoxFalloff* SetBoxFalloff(float Magnitude, float MinRange, float MaxRange, float Default, struct FTransform Transform, enum class EFieldFalloffType Falloff);
};

// Object: Class FieldSystemEngine.NoiseField
// Inherited Bytes: 0xc0 | Struct Size: 0x100
struct UNoiseField : UFieldNodeFloat {
	// Fields
	float MinRange; // Offset: 0xc0 | Size: 0x4
	float MaxRange; // Offset: 0xc4 | Size: 0x4
	char pad_0xC8[0x8]; // Offset: 0xc8 | Size: 0x8
	struct FTransform Transform; // Offset: 0xd0 | Size: 0x30

	// Functions

	// Object: Function FieldSystemEngine.NoiseField.SetNoiseField
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x1057f50c4
	// Return & Params: [ Num(4) Size(0x48) ]
	struct UNoiseField* SetNoiseField(float MinRange, float MaxRange, struct FTransform Transform);
};

// Object: Class FieldSystemEngine.UniformVector
// Inherited Bytes: 0xc0 | Struct Size: 0xd0
struct UUniformVector : UFieldNodeVector {
	// Fields
	float Magnitude; // Offset: 0xc0 | Size: 0x4
	struct FVector Direction; // Offset: 0xc4 | Size: 0xc

	// Functions

	// Object: Function FieldSystemEngine.UniformVector.SetUniformVector
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x1057f5268
	// Return & Params: [ Num(3) Size(0x18) ]
	struct UUniformVector* SetUniformVector(float Magnitude, struct FVector Direction);
};

// Object: Class FieldSystemEngine.RadialVector
// Inherited Bytes: 0xc0 | Struct Size: 0xd0
struct URadialVector : UFieldNodeVector {
	// Fields
	float Magnitude; // Offset: 0xc0 | Size: 0x4
	struct FVector Position; // Offset: 0xc4 | Size: 0xc

	// Functions

	// Object: Function FieldSystemEngine.RadialVector.SetRadialVector
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x1057f53a8
	// Return & Params: [ Num(3) Size(0x18) ]
	struct URadialVector* SetRadialVector(float Magnitude, struct FVector Position);
};

// Object: Class FieldSystemEngine.RandomVector
// Inherited Bytes: 0xc0 | Struct Size: 0xc8
struct URandomVector : UFieldNodeVector {
	// Fields
	float Magnitude; // Offset: 0xc0 | Size: 0x4
	char pad_0xC4[0x4]; // Offset: 0xc4 | Size: 0x4

	// Functions

	// Object: Function FieldSystemEngine.RandomVector.SetRandomVector
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1057f54e8
	// Return & Params: [ Num(2) Size(0x10) ]
	struct URandomVector* SetRandomVector(float Magnitude);
};

// Object: Class FieldSystemEngine.OperatorField
// Inherited Bytes: 0xc0 | Struct Size: 0xe0
struct UOperatorField : UFieldNodeBase {
	// Fields
	float Magnitude; // Offset: 0xc0 | Size: 0x4
	char pad_0xC4[0x4]; // Offset: 0xc4 | Size: 0x4
	struct UFieldNodeBase* RightField; // Offset: 0xc8 | Size: 0x8
	struct UFieldNodeBase* LeftField; // Offset: 0xd0 | Size: 0x8
	enum class EFieldOperationType Operation; // Offset: 0xd8 | Size: 0x1
	char pad_0xD9[0x7]; // Offset: 0xd9 | Size: 0x7

	// Functions

	// Object: Function FieldSystemEngine.OperatorField.SetOperatorField
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1057f55f4
	// Return & Params: [ Num(5) Size(0x28) ]
	struct UOperatorField* SetOperatorField(float Magnitude, struct UFieldNodeBase* RightField, struct UFieldNodeBase* LeftField, enum class EFieldOperationType Operation);
};

// Object: Class FieldSystemEngine.ToIntegerField
// Inherited Bytes: 0xc0 | Struct Size: 0xc8
struct UToIntegerField : UFieldNodeInt {
	// Fields
	struct UFieldNodeFloat* FloatField; // Offset: 0xc0 | Size: 0x8

	// Functions

	// Object: Function FieldSystemEngine.ToIntegerField.SetToIntegerField
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1057f57ac
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UToIntegerField* SetToIntegerField(struct UFieldNodeFloat* FloatField);
};

// Object: Class FieldSystemEngine.ToFloatField
// Inherited Bytes: 0xc0 | Struct Size: 0xc8
struct UToFloatField : UFieldNodeFloat {
	// Fields
	struct UFieldNodeInt* IntField; // Offset: 0xc0 | Size: 0x8

	// Functions

	// Object: Function FieldSystemEngine.ToFloatField.SetToFloatField
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1057f58c0
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UToFloatField* SetToFloatField(struct UFieldNodeInt* IntegerField);
};

// Object: Class FieldSystemEngine.CullingField
// Inherited Bytes: 0xc0 | Struct Size: 0xd8
struct UCullingField : UFieldNodeBase {
	// Fields
	struct UFieldNodeBase* Culling; // Offset: 0xc0 | Size: 0x8
	struct UFieldNodeBase* Field; // Offset: 0xc8 | Size: 0x8
	enum class EFieldCullingOperationType Operation; // Offset: 0xd0 | Size: 0x1
	char pad_0xD1[0x7]; // Offset: 0xd1 | Size: 0x7

	// Functions

	// Object: Function FieldSystemEngine.CullingField.SetCullingField
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1057f59d4
	// Return & Params: [ Num(4) Size(0x20) ]
	struct UCullingField* SetCullingField(struct UFieldNodeBase* Culling, struct UFieldNodeBase* Field, enum class EFieldCullingOperationType Operation);
};

// Object: Class FieldSystemEngine.ReturnResultsTerminal
// Inherited Bytes: 0xc0 | Struct Size: 0xc0
struct UReturnResultsTerminal : UFieldNodeBase {
	// Functions

	// Object: Function FieldSystemEngine.ReturnResultsTerminal.SetReturnResultsTerminal
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1057f5b54
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UReturnResultsTerminal* SetReturnResultsTerminal();
};

