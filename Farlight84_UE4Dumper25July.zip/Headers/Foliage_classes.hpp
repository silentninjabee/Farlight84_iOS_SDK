#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class Foliage.FoliageInstancedStaticMeshComponent
// Inherited Bytes: 0xa00 | Struct Size: 0xa30
struct UFoliageInstancedStaticMeshComponent : UHierarchicalInstancedStaticMeshComponent {
	// Fields
	struct FMulticastInlineDelegate OnInstanceTakePointDamage; // Offset: 0x9f8 | Size: 0x10
	struct FMulticastInlineDelegate OnInstanceTakeRadialDamage; // Offset: 0xa08 | Size: 0x10
	struct FGuid GenerationGuid; // Offset: 0xa18 | Size: 0x10
};

// Object: Class Foliage.FoliageStatistics
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UFoliageStatistics : UBlueprintFunctionLibrary {
	// Functions

	// Object: Function Foliage.FoliageStatistics.FoliageOverlappingSphereCount
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x104e50d20
	// Return & Params: [ Num(5) Size(0x24) ]
	int32_t FoliageOverlappingSphereCount(struct UObject* WorldContextObject, struct UStaticMesh* StaticMesh, struct FVector CenterPosition, float Radius);

	// Object: Function Foliage.FoliageStatistics.FoliageOverlappingBoxCount
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x104e50c50
	// Return & Params: [ Num(4) Size(0x30) ]
	int32_t FoliageOverlappingBoxCount(struct UObject* WorldContextObject, struct UStaticMesh* StaticMesh, struct FBox Box);
};

// Object: Class Foliage.FoliageType
// Inherited Bytes: 0x28 | Struct Size: 0x398
struct UFoliageType : UObject {
	// Fields
	struct FGuid UpdateGuid; // Offset: 0x28 | Size: 0x10
	float Density; // Offset: 0x38 | Size: 0x4
	float DensityAdjustmentFactor; // Offset: 0x3c | Size: 0x4
	float Radius; // Offset: 0x40 | Size: 0x4
	bool bSingleInstanceModeOverrideRadius; // Offset: 0x44 | Size: 0x1
	char pad_0x45[0x3]; // Offset: 0x45 | Size: 0x3
	float SingleInstanceModeRadius; // Offset: 0x48 | Size: 0x4
	enum class EFoliageScaling Scaling; // Offset: 0x4c | Size: 0x1
	char pad_0x4D[0x3]; // Offset: 0x4d | Size: 0x3
	struct FFloatInterval ScaleX; // Offset: 0x50 | Size: 0x8
	struct FFloatInterval ScaleY; // Offset: 0x58 | Size: 0x8
	struct FFloatInterval ScaleZ; // Offset: 0x60 | Size: 0x8
	struct FFoliageVertexColorChannelMask VertexColorMaskByChannel[0x4]; // Offset: 0x68 | Size: 0x30
	enum class FoliageVertexColorMask VertexColorMask; // Offset: 0x98 | Size: 0x1
	char pad_0x99[0x3]; // Offset: 0x99 | Size: 0x3
	float VertexColorMaskThreshold; // Offset: 0x9c | Size: 0x4
	char VertexColorMaskInvert : 1; // Offset: 0xa0 | Size: 0x1
	char pad_0xA0_1 : 7; // Offset: 0xa0 | Size: 0x1
	char pad_0xA1[0x3]; // Offset: 0xa1 | Size: 0x3
	struct FFloatInterval ZOffset; // Offset: 0xa4 | Size: 0x8
	char AlignToNormal : 1; // Offset: 0xac | Size: 0x1
	char pad_0xAC_1 : 7; // Offset: 0xac | Size: 0x1
	char pad_0xAD[0x3]; // Offset: 0xad | Size: 0x3
	float AlignMaxAngle; // Offset: 0xb0 | Size: 0x4
	char RandomYaw : 1; // Offset: 0xb4 | Size: 0x1
	char pad_0xB4_1 : 7; // Offset: 0xb4 | Size: 0x1
	char pad_0xB5[0x3]; // Offset: 0xb5 | Size: 0x3
	float RandomPitchAngle; // Offset: 0xb8 | Size: 0x4
	struct FFloatInterval GroundSlopeAngle; // Offset: 0xbc | Size: 0x8
	struct FFloatInterval Height; // Offset: 0xc4 | Size: 0x8
	bool UseCustomLODScale; // Offset: 0xcc | Size: 0x1
	char pad_0xCD[0x3]; // Offset: 0xcd | Size: 0x3
	struct TArray<struct FName> LandscapeLayers; // Offset: 0xd0 | Size: 0x10
	float MinimumLayerWeight; // Offset: 0xe0 | Size: 0x4
	char pad_0xE4[0x4]; // Offset: 0xe4 | Size: 0x4
	struct TArray<struct FName> ExclusionLandscapeLayers; // Offset: 0xe8 | Size: 0x10
	float MinimumExclusionLayerWeight; // Offset: 0xf8 | Size: 0x4
	struct FName LandscapeLayer; // Offset: 0xfc | Size: 0x8
	char CollisionWithWorld : 1; // Offset: 0x104 | Size: 0x1
	char pad_0x104_1 : 7; // Offset: 0x104 | Size: 0x1
	char pad_0x105[0x3]; // Offset: 0x105 | Size: 0x3
	struct FVector CollisionScale; // Offset: 0x108 | Size: 0xc
	struct FBoxSphereBounds MeshBounds; // Offset: 0x114 | Size: 0x1c
	struct FVector LowBoundOriginRadius; // Offset: 0x130 | Size: 0xc
	enum class EComponentMobility Mobility; // Offset: 0x13c | Size: 0x1
	char pad_0x13D[0x3]; // Offset: 0x13d | Size: 0x3
	struct FInt32Interval CullDistance; // Offset: 0x140 | Size: 0x8
	char bEnableStaticLighting : 1; // Offset: 0x148 | Size: 0x1
	char CastShadow : 1; // Offset: 0x148 | Size: 0x1
	char CastFarShadow : 1; // Offset: 0x148 | Size: 0x1
	char bAffectDynamicIndirectLighting : 1; // Offset: 0x148 | Size: 0x1
	char bAffectDistanceFieldLighting : 1; // Offset: 0x148 | Size: 0x1
	char bCastDynamicShadow : 1; // Offset: 0x148 | Size: 0x1
	char bCastStaticShadow : 1; // Offset: 0x148 | Size: 0x1
	char bCastShadowAsTwoSided : 1; // Offset: 0x148 | Size: 0x1
	char bReceivesDecals : 1; // Offset: 0x149 | Size: 0x1
	char bOverrideLightMapRes : 1; // Offset: 0x149 | Size: 0x1
	char pad_0x149_2 : 6; // Offset: 0x149 | Size: 0x1
	char pad_0x14A[0x2]; // Offset: 0x14a | Size: 0x2
	int32_t OverriddenLightMapRes; // Offset: 0x14c | Size: 0x4
	char bMinimizeLightmapRes : 1; // Offset: 0x150 | Size: 0x1
	char bForceGenLightmap : 1; // Offset: 0x150 | Size: 0x1
	char pad_0x150_2 : 6; // Offset: 0x150 | Size: 0x1
	enum class ELightmapType LightmapType; // Offset: 0x151 | Size: 0x1
	char bUseAsOccluder : 1; // Offset: 0x152 | Size: 0x1
	char pad_0x152_1 : 7; // Offset: 0x152 | Size: 0x1
	char pad_0x153[0x5]; // Offset: 0x153 | Size: 0x5
	struct FBodyInstance BodyInstance; // Offset: 0x158 | Size: 0x130
	enum class EHasCustomNavigableGeometry CustomNavigableGeometry; // Offset: 0x288 | Size: 0x1
	struct FLightingChannels LightingChannels; // Offset: 0x289 | Size: 0x1
	char bRenderCustomDepth : 1; // Offset: 0x28a | Size: 0x1
	char pad_0x28A_1 : 7; // Offset: 0x28a | Size: 0x1
	char pad_0x28B[0x1]; // Offset: 0x28b | Size: 0x1
	int32_t CustomDepthStencilValue; // Offset: 0x28c | Size: 0x4
	int32_t TranslucencySortPriority; // Offset: 0x290 | Size: 0x4
	char pad_0x294[0x4]; // Offset: 0x294 | Size: 0x4
	struct TArray<struct FSelectInstanceInfo> SelectInstancesData; // Offset: 0x298 | Size: 0x10
	char pad_0x2A8[0x8]; // Offset: 0x2a8 | Size: 0x8
	float CollisionRadius; // Offset: 0x2b0 | Size: 0x4
	float ShadeRadius; // Offset: 0x2b4 | Size: 0x4
	int32_t NumSteps; // Offset: 0x2b8 | Size: 0x4
	float InitialSeedDensity; // Offset: 0x2bc | Size: 0x4
	float AverageSpreadDistance; // Offset: 0x2c0 | Size: 0x4
	float SpreadVariance; // Offset: 0x2c4 | Size: 0x4
	int32_t SeedsPerStep; // Offset: 0x2c8 | Size: 0x4
	int32_t DistributionSeed; // Offset: 0x2cc | Size: 0x4
	float MaxInitialSeedOffset; // Offset: 0x2d0 | Size: 0x4
	bool bCanGrowInShade; // Offset: 0x2d4 | Size: 0x1
	bool bSpawnsInShade; // Offset: 0x2d5 | Size: 0x1
	char pad_0x2D6[0x2]; // Offset: 0x2d6 | Size: 0x2
	float MaxInitialAge; // Offset: 0x2d8 | Size: 0x4
	float MaxAge; // Offset: 0x2dc | Size: 0x4
	float OverlapPriority; // Offset: 0x2e0 | Size: 0x4
	struct FFloatInterval ProceduralScale; // Offset: 0x2e4 | Size: 0x8
	char pad_0x2EC[0x4]; // Offset: 0x2ec | Size: 0x4
	struct FRuntimeFloatCurve ScaleCurve; // Offset: 0x2f0 | Size: 0x88
	int32_t ChangeCount; // Offset: 0x378 | Size: 0x4
	char ReapplyDensity : 1; // Offset: 0x37c | Size: 0x1
	char ReapplyRadius : 1; // Offset: 0x37c | Size: 0x1
	char ReapplyAlignToNormal : 1; // Offset: 0x37c | Size: 0x1
	char ReapplyRandomYaw : 1; // Offset: 0x37c | Size: 0x1
	char ReapplyScaling : 1; // Offset: 0x37c | Size: 0x1
	char ReapplyScaleX : 1; // Offset: 0x37c | Size: 0x1
	char ReapplyScaleY : 1; // Offset: 0x37c | Size: 0x1
	char ReapplyScaleZ : 1; // Offset: 0x37c | Size: 0x1
	char ReapplyRandomPitchAngle : 1; // Offset: 0x37d | Size: 0x1
	char ReapplyGroundSlope : 1; // Offset: 0x37d | Size: 0x1
	char ReapplyHeight : 1; // Offset: 0x37d | Size: 0x1
	char ReapplyLandscapeLayers : 1; // Offset: 0x37d | Size: 0x1
	char ReapplyZOffset : 1; // Offset: 0x37d | Size: 0x1
	char ReapplyCollisionWithWorld : 1; // Offset: 0x37d | Size: 0x1
	char ReapplyVertexColorMask : 1; // Offset: 0x37d | Size: 0x1
	char bEnableDensityScaling : 1; // Offset: 0x37d | Size: 0x1
	char pad_0x37E[0x2]; // Offset: 0x37e | Size: 0x2
	struct TArray<struct URuntimeVirtualTexture*> RuntimeVirtualTextures; // Offset: 0x380 | Size: 0x10
	int32_t VirtualTextureCullMips; // Offset: 0x390 | Size: 0x4
	enum class ERuntimeVirtualTextureMainPassType VirtualTextureRenderPassType; // Offset: 0x394 | Size: 0x1
	char pad_0x395[0x3]; // Offset: 0x395 | Size: 0x3
};

// Object: Class Foliage.FoliageType_Actor
// Inherited Bytes: 0x398 | Struct Size: 0x3a8
struct UFoliageType_Actor : UFoliageType {
	// Fields
	struct AActor* ActorClass; // Offset: 0x398 | Size: 0x8
	bool bShouldAttachToBaseComponent; // Offset: 0x3a0 | Size: 0x1
	char pad_0x3A1[0x7]; // Offset: 0x3a1 | Size: 0x7
};

// Object: Class Foliage.FoliageType_InstancedStaticMesh
// Inherited Bytes: 0x398 | Struct Size: 0x3c8
struct UFoliageType_InstancedStaticMesh : UFoliageType {
	// Fields
	struct UStaticMesh* Mesh; // Offset: 0x398 | Size: 0x8
	struct TArray<struct UMaterialInterface*> OverrideMaterials; // Offset: 0x3a0 | Size: 0x10
	struct UFoliageInstancedStaticMeshComponent* ComponentClass; // Offset: 0x3b0 | Size: 0x8
	struct UStaticMesh* StaticMeshStaticLightingProxy; // Offset: 0x3b8 | Size: 0x8
	bool bUseLightmapPerPixelPerInstance; // Offset: 0x3c0 | Size: 0x1
	char pad_0x3C1[0x3]; // Offset: 0x3c1 | Size: 0x3
	int32_t OverrideCVarMinVertsToSplitNode; // Offset: 0x3c4 | Size: 0x4
};

// Object: Class Foliage.InstancedFoliageActor
// Inherited Bytes: 0x248 | Struct Size: 0x298
struct AInstancedFoliageActor : AActor {
	// Fields
	char pad_0x248[0x50]; // Offset: 0x248 | Size: 0x50
};

// Object: Class Foliage.InteractiveFoliageActor
// Inherited Bytes: 0x258 | Struct Size: 0x2b8
struct AInteractiveFoliageActor : AStaticMeshActor {
	// Fields
	struct UCapsuleComponent* CapsuleComponent; // Offset: 0x258 | Size: 0x8
	struct FVector TouchingActorEntryPosition; // Offset: 0x260 | Size: 0xc
	struct FVector FoliageVelocity; // Offset: 0x26c | Size: 0xc
	struct FVector FoliageForce; // Offset: 0x278 | Size: 0xc
	struct FVector FoliagePosition; // Offset: 0x284 | Size: 0xc
	float FoliageDamageImpulseScale; // Offset: 0x290 | Size: 0x4
	float FoliageTouchImpulseScale; // Offset: 0x294 | Size: 0x4
	float FoliageStiffness; // Offset: 0x298 | Size: 0x4
	float FoliageStiffnessQuadratic; // Offset: 0x29c | Size: 0x4
	float FoliageDamping; // Offset: 0x2a0 | Size: 0x4
	float MaxDamageImpulse; // Offset: 0x2a4 | Size: 0x4
	float MaxTouchImpulse; // Offset: 0x2a8 | Size: 0x4
	float MaxForce; // Offset: 0x2ac | Size: 0x4
	float Mass; // Offset: 0x2b0 | Size: 0x4
	char pad_0x2B4[0x4]; // Offset: 0x2b4 | Size: 0x4

	// Functions

	// Object: Function Foliage.InteractiveFoliageActor.CapsuleTouched
	// Flags: [Final|Native|Protected|HasOutParms]
	// Offset: 0x104e514b0
	// Return & Params: [ Num(6) Size(0xa8) ]
	void CapsuleTouched(struct UPrimitiveComponent* OverlappedComp, struct AActor* Other, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& OverlapInfo);
};

// Object: Class Foliage.InteractiveFoliageComponent
// Inherited Bytes: 0x840 | Struct Size: 0x840
struct UInteractiveFoliageComponent : UStaticMeshComponent {
};

// Object: Class Foliage.ProceduralFoliageBlockingVolume
// Inherited Bytes: 0x280 | Struct Size: 0x288
struct AProceduralFoliageBlockingVolume : AVolume {
	// Fields
	struct AProceduralFoliageVolume* ProceduralFoliageVolume; // Offset: 0x280 | Size: 0x8
};

// Object: Class Foliage.ProceduralFoliageComponent
// Inherited Bytes: 0xc0 | Struct Size: 0xe8
struct UProceduralFoliageComponent : UActorComponent {
	// Fields
	struct UProceduralFoliageSpawner* FoliageSpawner; // Offset: 0xc0 | Size: 0x8
	float TileOverlap; // Offset: 0xc8 | Size: 0x4
	char pad_0xCC[0x4]; // Offset: 0xcc | Size: 0x4
	struct AVolume* SpawningVolume; // Offset: 0xd0 | Size: 0x8
	struct FGuid ProceduralGuid; // Offset: 0xd8 | Size: 0x10
};

// Object: Class Foliage.ProceduralFoliageSpawner
// Inherited Bytes: 0x28 | Struct Size: 0x68
struct UProceduralFoliageSpawner : UObject {
	// Fields
	int32_t RandomSeed; // Offset: 0x28 | Size: 0x4
	float TileSize; // Offset: 0x2c | Size: 0x4
	int32_t NumUniqueTiles; // Offset: 0x30 | Size: 0x4
	float MinimumQuadTreeSize; // Offset: 0x34 | Size: 0x4
	char pad_0x38[0x8]; // Offset: 0x38 | Size: 0x8
	struct TArray<struct FFoliageTypeObject> FoliageTypes; // Offset: 0x40 | Size: 0x10
	char pad_0x50[0x18]; // Offset: 0x50 | Size: 0x18

	// Functions

	// Object: Function Foliage.ProceduralFoliageSpawner.Simulate
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104e518a0
	// Return & Params: [ Num(1) Size(0x4) ]
	void Simulate(int32_t NumSteps);
};

// Object: Class Foliage.ProceduralFoliageTile
// Inherited Bytes: 0x28 | Struct Size: 0x158
struct UProceduralFoliageTile : UObject {
	// Fields
	struct UProceduralFoliageSpawner* FoliageSpawner; // Offset: 0x28 | Size: 0x8
	char pad_0x30[0xa0]; // Offset: 0x30 | Size: 0xa0
	struct TArray<struct FProceduralFoliageInstance> InstancesArray; // Offset: 0xd0 | Size: 0x10
	char pad_0xE0[0x78]; // Offset: 0xe0 | Size: 0x78
};

// Object: Class Foliage.ProceduralFoliageVolume
// Inherited Bytes: 0x280 | Struct Size: 0x288
struct AProceduralFoliageVolume : AVolume {
	// Fields
	struct UProceduralFoliageComponent* ProceduralComponent; // Offset: 0x280 | Size: 0x8
};

