#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass GA_Scan_On_Hit.GA_Scan_On_Hit_C
// Inherited Bytes: 0x7a8 | Struct Size: 0x7a8
struct UGA_Scan_On_Hit_C : UWeaponScanAbility {
};

