#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass GC_ScreenFX_Poison.GC_ScreenFX_Poison_C
// Inherited Bytes: 0x2b8 | Struct Size: 0x2c0
struct AGC_ScreenFX_Poison_C : AGameplayCueNotify_Actor {
	// Fields
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x2b8 | Size: 0x8

	// Functions

	// Object: Function GC_ScreenFX_Poison.GC_ScreenFX_Poison_C.IsObservationTarget
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(2) Size(0x9) ]
	bool IsObservationTarget(struct ASolarCharacter* Target);

	// Object: Function GC_ScreenFX_Poison.GC_ScreenFX_Poison_C.OnRemove
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(3) Size(0xd9) ]
	bool OnRemove(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters);

	// Object: Function GC_ScreenFX_Poison.GC_ScreenFX_Poison_C.OnActive
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(3) Size(0xd9) ]
	bool OnActive(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters);
};

