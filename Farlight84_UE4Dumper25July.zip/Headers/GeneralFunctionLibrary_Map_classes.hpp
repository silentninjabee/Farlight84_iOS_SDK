#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass GeneralFunctionLibrary_Map.GeneralFunctionLibrary_Map_C
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UGeneralFunctionLibrary_Map_C : UBlueprintFunctionLibrary {
	// Functions

	// Object: Function GeneralFunctionLibrary_Map.GeneralFunctionLibrary_Map_C.[S]Create Air Drop by Out Come ID Auto Trace Ground Height_Rain
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(8) Size(0x60) ]
	void [S]Create Air Drop by Out Come ID Auto Trace Ground Height_Rain(struct UObject* WorldContextObject, struct TArray<struct FTransform>& , struct ASolarTreasureBoxSpawner* , int32_t ChestID, bool bUseAirship, int32_t NoticeID, struct FGameplayEventFilterConfig Config, struct UObject* __WorldContext);

	// Object: Function GeneralFunctionLibrary_Map.GeneralFunctionLibrary_Map_C.[ C]Debug Drawing Poison Circle
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(4) Size(0x30) ]
	void [ C]Debug Drawing Poison Circle(struct TArray<struct FVector>& CenterArr, struct UObject* __WorldContext1, struct TArray<float>& Radius, struct UObject* __WorldContext);

	// Object: Function GeneralFunctionLibrary_Map.GeneralFunctionLibrary_Map_C.[ C]Get Viewport Focused Character
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(3) Size(0x18) ]
	void [ C]Get Viewport Focused Character(struct UObject* WorldContextObject, struct UObject* __WorldContext, struct ASolarCharacter*& Character);

	// Object: Function GeneralFunctionLibrary_Map.GeneralFunctionLibrary_Map_C.CircularInterceptPoint
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(9) Size(0x40) ]
	void CircularInterceptPoint(struct FVector2D CenterPoint, float LargeRadius, float SmallRadius, float TruncationAngle, struct UObject* __WorldContext, struct FVector2D& LargePointStart, struct FVector2D& LargePointEnd, struct FVector2D& SmallPointStart, struct FVector2D& SmallPointEnd);

	// Object: Function GeneralFunctionLibrary_Map.GeneralFunctionLibrary_Map_C.[ S]Get Point On Line
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(5) Size(0x30) ]
	void [ S]Get Point On Line(struct TArray<struct FVector2D>& Sample, struct FVector2D StartPoint, float Length, struct UObject* __WorldContext, struct FVector2D& TargetPoint);

	// Object: Function GeneralFunctionLibrary_Map.GeneralFunctionLibrary_Map_C.[S]Create Air Drop by Out Come ID Auto Trace Ground Height
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(8) Size(0x88) ]
	void [S]Create Air Drop by Out Come ID Auto Trace Ground Height(struct UObject* WorldContextObject, struct FTransform& , struct ASolarTreasureBoxSpawner* , int32_t ChestID, bool bUseAirship, int32_t NoticeID, struct FGameplayEventFilterConfig Config, struct UObject* __WorldContext);

	// Object: Function GeneralFunctionLibrary_Map.GeneralFunctionLibrary_Map_C.[ S]Create Air Drop by Item ID Auto Trace Ground Height
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(6) Size(0x58) ]
	void [ S]Create Air Drop by Item ID Auto Trace Ground Height(struct UObject* WorldContextObject, struct FTransform& , struct ASolarTreasureBoxSpawner* , int32_t ChestID, int32_t , struct UObject* __WorldContext);
};

