#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class IOSRuntimeSettings.IOSRuntimeSettings
// Inherited Bytes: 0x28 | Struct Size: 0x218
struct UIOSRuntimeSettings : UObject {
	// Fields
	char bEnableGameCenterSupport : 1; // Offset: 0x28 | Size: 0x1
	char bEnableCloudKitSupport : 1; // Offset: 0x28 | Size: 0x1
	char pad_0x28_2 : 6; // Offset: 0x28 | Size: 0x1
	enum class EIOSCloudKitSyncStrategy IOSCloudKitSyncStrategy; // Offset: 0x29 | Size: 0x1
	char bEnableRemoteNotificationsSupport : 1; // Offset: 0x2a | Size: 0x1
	char bEnableBackgroundFetch : 1; // Offset: 0x2a | Size: 0x1
	char pad_0x2A_2 : 6; // Offset: 0x2a | Size: 0x1
	bool bSupportsMetal; // Offset: 0x2b | Size: 0x1
	bool bSupportsMetalMRT; // Offset: 0x2c | Size: 0x1
	bool bCookPVRTCTextures; // Offset: 0x2d | Size: 0x1
	bool bCookASTCTextures; // Offset: 0x2e | Size: 0x1
	bool bBuildAsFramework; // Offset: 0x2f | Size: 0x1
	struct FIOSBuildResourceDirectory WindowsMetalToolchainOverride; // Offset: 0x30 | Size: 0x10
	bool bGeneratedSYMFile; // Offset: 0x40 | Size: 0x1
	bool bGeneratedSYMBundle; // Offset: 0x41 | Size: 0x1
	bool bGenerateCrashReportSymbols; // Offset: 0x42 | Size: 0x1
	bool bGenerateXCArchive; // Offset: 0x43 | Size: 0x1
	bool bDevForArmV7; // Offset: 0x44 | Size: 0x1
	bool bDevForArm64; // Offset: 0x45 | Size: 0x1
	bool bDevForArmV7S; // Offset: 0x46 | Size: 0x1
	bool bShipForArmV7; // Offset: 0x47 | Size: 0x1
	bool bShipForArm64; // Offset: 0x48 | Size: 0x1
	bool bShipForArmV7S; // Offset: 0x49 | Size: 0x1
	bool bShipForBitcode; // Offset: 0x4a | Size: 0x1
	bool bEnableAdvertisingIdentifier; // Offset: 0x4b | Size: 0x1
	char pad_0x4C[0x4]; // Offset: 0x4c | Size: 0x4
	struct FString AdditionalLinkerFlags; // Offset: 0x50 | Size: 0x10
	struct FString AdditionalShippingLinkerFlags; // Offset: 0x60 | Size: 0x10
	struct FString RemoteServerName; // Offset: 0x70 | Size: 0x10
	bool bUseRSync; // Offset: 0x80 | Size: 0x1
	char pad_0x81[0x7]; // Offset: 0x81 | Size: 0x7
	struct FString RSyncUsername; // Offset: 0x88 | Size: 0x10
	struct FIOSBuildResourceDirectory CwRsyncInstallPath; // Offset: 0x98 | Size: 0x10
	struct FString SSHPrivateKeyLocation; // Offset: 0xa8 | Size: 0x10
	struct FIOSBuildResourceFilePath SSHPrivateKeyOverridePath; // Offset: 0xb8 | Size: 0x10
	bool bTreatRemoteAsSeparateController; // Offset: 0xc8 | Size: 0x1
	bool bAllowRemoteRotation; // Offset: 0xc9 | Size: 0x1
	bool bUseRemoteAsVirtualJoystick; // Offset: 0xca | Size: 0x1
	bool bUseRemoteAbsoluteDpadValues; // Offset: 0xcb | Size: 0x1
	bool bAllowControllers; // Offset: 0xcc | Size: 0x1
	bool bControllersBlockDeviceFeedback; // Offset: 0xcd | Size: 0x1
	bool bDisableMotionData; // Offset: 0xce | Size: 0x1
	char bSupportsPortraitOrientation : 1; // Offset: 0xcf | Size: 0x1
	char bSupportsUpsideDownOrientation : 1; // Offset: 0xcf | Size: 0x1
	char bSupportsLandscapeLeftOrientation : 1; // Offset: 0xcf | Size: 0x1
	char bSupportsLandscapeRightOrientation : 1; // Offset: 0xcf | Size: 0x1
	char bSupportsITunesFileSharing : 1; // Offset: 0xcf | Size: 0x1
	char bSupportsFilesApp : 1; // Offset: 0xcf | Size: 0x1
	char pad_0xCF_6 : 2; // Offset: 0xcf | Size: 0x1
	enum class EIOSLandscapeOrientation PreferredLandscapeOrientation; // Offset: 0xd0 | Size: 0x1
	char pad_0xD1[0x7]; // Offset: 0xd1 | Size: 0x7
	struct FString BundleDisplayName; // Offset: 0xd8 | Size: 0x10
	struct FString BundleName; // Offset: 0xe8 | Size: 0x10
	struct FString BundleIdentifier; // Offset: 0xf8 | Size: 0x10
	struct FString VersionInfo; // Offset: 0x108 | Size: 0x10
	enum class EPowerUsageFrameRateLock FrameRateLock; // Offset: 0x118 | Size: 0x1
	bool bEnableDynamicMaxFPS; // Offset: 0x119 | Size: 0x1
	enum class EIOSVersion MinimumiOSVersion; // Offset: 0x11a | Size: 0x1
	char bSupportsIPad : 1; // Offset: 0x11b | Size: 0x1
	char bSupportsIPhone : 1; // Offset: 0x11b | Size: 0x1
	char pad_0x11B_2 : 6; // Offset: 0x11b | Size: 0x1
	char pad_0x11C[0x4]; // Offset: 0x11c | Size: 0x4
	struct FString AdditionalPlistData; // Offset: 0x120 | Size: 0x10
	bool bCustomLaunchscreenStoryboard; // Offset: 0x130 | Size: 0x1
	bool bEnableFacebookSupport; // Offset: 0x131 | Size: 0x1
	char pad_0x132[0x6]; // Offset: 0x132 | Size: 0x6
	struct FString FacebookAppID; // Offset: 0x138 | Size: 0x10
	struct FString MobileProvision; // Offset: 0x148 | Size: 0x10
	struct FString SigningCertificate; // Offset: 0x158 | Size: 0x10
	bool bAutomaticSigning; // Offset: 0x168 | Size: 0x1
	char pad_0x169[0x7]; // Offset: 0x169 | Size: 0x7
	struct FString IOSTeamID; // Offset: 0x170 | Size: 0x10
	bool bDisableHTTPS; // Offset: 0x180 | Size: 0x1
	char MaxShaderLanguageVersion; // Offset: 0x181 | Size: 0x1
	bool UseFastIntrinsics; // Offset: 0x182 | Size: 0x1
	bool ForceFloats; // Offset: 0x183 | Size: 0x1
	bool EnableMathOptimisations; // Offset: 0x184 | Size: 0x1
	char pad_0x185[0x3]; // Offset: 0x185 | Size: 0x3
	int32_t IndirectArgumentTier; // Offset: 0x188 | Size: 0x4
	bool bUseIntegratedKeyboard; // Offset: 0x18c | Size: 0x1
	char pad_0x18D[0x3]; // Offset: 0x18d | Size: 0x3
	int32_t AudioSampleRate; // Offset: 0x190 | Size: 0x4
	int32_t AudioCallbackBufferFrameSize; // Offset: 0x194 | Size: 0x4
	int32_t AudioNumBuffersToEnqueue; // Offset: 0x198 | Size: 0x4
	int32_t AudioMaxChannels; // Offset: 0x19c | Size: 0x4
	int32_t AudioNumSourceWorkers; // Offset: 0x1a0 | Size: 0x4
	char pad_0x1A4[0x4]; // Offset: 0x1a4 | Size: 0x4
	struct FString SpatializationPlugin; // Offset: 0x1a8 | Size: 0x10
	struct FString ReverbPlugin; // Offset: 0x1b8 | Size: 0x10
	struct FString OcclusionPlugin; // Offset: 0x1c8 | Size: 0x10
	struct FPlatformRuntimeAudioCompressionOverrides CompressionOverrides; // Offset: 0x1d8 | Size: 0x10
	bool bUseAudioStreamCaching; // Offset: 0x1e8 | Size: 0x1
	char pad_0x1E9[0x3]; // Offset: 0x1e9 | Size: 0x3
	int32_t CacheSizeKB; // Offset: 0x1ec | Size: 0x4
	bool bResampleForDevice; // Offset: 0x1f0 | Size: 0x1
	char pad_0x1F1[0x3]; // Offset: 0x1f1 | Size: 0x3
	int32_t SoundCueCookQualityIndex; // Offset: 0x1f4 | Size: 0x4
	float MaxSampleRate; // Offset: 0x1f8 | Size: 0x4
	float HighSampleRate; // Offset: 0x1fc | Size: 0x4
	float MedSampleRate; // Offset: 0x200 | Size: 0x4
	float LowSampleRate; // Offset: 0x204 | Size: 0x4
	float MinSampleRate; // Offset: 0x208 | Size: 0x4
	float CompressionQualityModifier; // Offset: 0x20c | Size: 0x4
	float AutoStreamingThreshold; // Offset: 0x210 | Size: 0x4
	char pad_0x214[0x4]; // Offset: 0x214 | Size: 0x4
};

