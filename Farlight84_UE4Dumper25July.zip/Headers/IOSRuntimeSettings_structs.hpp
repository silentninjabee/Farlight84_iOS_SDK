#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct IOSRuntimeSettings.IOSBuildResourceDirectory
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FIOSBuildResourceDirectory {
	// Fields
	struct FString Path; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct IOSRuntimeSettings.IOSBuildResourceFilePath
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FIOSBuildResourceFilePath {
	// Fields
	struct FString FilePath; // Offset: 0x0 | Size: 0x10
};

