#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct JsonUtilities.JsonObjectWrapper
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FJsonObjectWrapper {
	// Fields
	struct FString JsonString; // Offset: 0x0 | Size: 0x10
	char pad_0x10[0x10]; // Offset: 0x10 | Size: 0x10
};

