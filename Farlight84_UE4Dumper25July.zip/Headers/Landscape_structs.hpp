#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct Landscape.LandscapeLayer
// Inherited Bytes: 0x0 | Struct Size: 0x88
struct FLandscapeLayer {
	// Fields
	struct FGuid Guid; // Offset: 0x0 | Size: 0x10
	struct FName Name; // Offset: 0x10 | Size: 0x8
	bool bVisible; // Offset: 0x18 | Size: 0x1
	bool bLocked; // Offset: 0x19 | Size: 0x1
	char pad_0x1A[0x2]; // Offset: 0x1a | Size: 0x2
	float HeightmapAlpha; // Offset: 0x1c | Size: 0x4
	float WeightmapAlpha; // Offset: 0x20 | Size: 0x4
	enum class ELandscapeBlendMode BlendMode; // Offset: 0x24 | Size: 0x1
	char pad_0x25[0x3]; // Offset: 0x25 | Size: 0x3
	struct TArray<struct FLandscapeLayerBrush> Brushes; // Offset: 0x28 | Size: 0x10
	struct TMap<struct ULandscapeLayerInfoObject*, bool> WeightmapLayerAllocationBlend; // Offset: 0x38 | Size: 0x50
};

// Object: ScriptStruct Landscape.LandscapeLayerBrush
// Inherited Bytes: 0x0 | Struct Size: 0x1
struct FLandscapeLayerBrush {
	// Fields
	char pad_0x0[0x1]; // Offset: 0x0 | Size: 0x1
};

// Object: ScriptStruct Landscape.LandscapeLayerComponentData
// Inherited Bytes: 0x0 | Struct Size: 0x38
struct FLandscapeLayerComponentData {
	// Fields
	struct FHeightmapData HeightmapData; // Offset: 0x0 | Size: 0x8
	struct FWeightmapData WeightmapData; // Offset: 0x8 | Size: 0x30
};

// Object: ScriptStruct Landscape.WeightmapData
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FWeightmapData {
	// Fields
	struct TArray<struct UTexture2D*> Textures; // Offset: 0x0 | Size: 0x10
	struct TArray<struct FWeightmapLayerAllocationInfo> LayerAllocations; // Offset: 0x10 | Size: 0x10
	struct TArray<struct ULandscapeWeightmapUsage*> TextureUsages; // Offset: 0x20 | Size: 0x10
};

// Object: ScriptStruct Landscape.WeightmapLayerAllocationInfo
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FWeightmapLayerAllocationInfo {
	// Fields
	struct ULandscapeLayerInfoObject* LayerInfo; // Offset: 0x0 | Size: 0x8
	char WeightmapTextureIndex; // Offset: 0x8 | Size: 0x1
	char WeightmapTextureChannel; // Offset: 0x9 | Size: 0x1
	char pad_0xA[0x6]; // Offset: 0xa | Size: 0x6
};

// Object: ScriptStruct Landscape.HeightmapData
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FHeightmapData {
	// Fields
	struct UTexture2D* Texture; // Offset: 0x0 | Size: 0x8
};

// Object: ScriptStruct Landscape.LandscapeComponentMaterialOverride
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FLandscapeComponentMaterialOverride {
	// Fields
	struct FPerPlatformInt LODIndex; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct UMaterialInterface* Material; // Offset: 0x8 | Size: 0x8
};

// Object: ScriptStruct Landscape.LandscapeEditToolRenderData
// Inherited Bytes: 0x0 | Struct Size: 0x38
struct FLandscapeEditToolRenderData {
	// Fields
	struct UMaterialInterface* ToolMaterial; // Offset: 0x0 | Size: 0x8
	struct UMaterialInterface* GizmoMaterial; // Offset: 0x8 | Size: 0x8
	int32_t SelectedType; // Offset: 0x10 | Size: 0x4
	int32_t DebugChannelR; // Offset: 0x14 | Size: 0x4
	int32_t DebugChannelG; // Offset: 0x18 | Size: 0x4
	int32_t DebugChannelB; // Offset: 0x1c | Size: 0x4
	struct UTexture2D* DataTexture; // Offset: 0x20 | Size: 0x8
	struct UTexture2D* LayerContributionTexture; // Offset: 0x28 | Size: 0x8
	struct UTexture2D* DirtyTexture; // Offset: 0x30 | Size: 0x8
};

// Object: ScriptStruct Landscape.GizmoSelectData
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FGizmoSelectData {
	// Fields
	char pad_0x0[0x50]; // Offset: 0x0 | Size: 0x50
};

// Object: ScriptStruct Landscape.GrassVariety
// Inherited Bytes: 0x0 | Struct Size: 0x48
struct FGrassVariety {
	// Fields
	struct UStaticMesh* GrassMesh; // Offset: 0x0 | Size: 0x8
	struct FPerPlatformFloat GrassDensity; // Offset: 0x8 | Size: 0x4
	bool bUseGrid; // Offset: 0xc | Size: 0x1
	char pad_0xD[0x3]; // Offset: 0xd | Size: 0x3
	float PlacementJitter; // Offset: 0x10 | Size: 0x4
	struct FPerPlatformInt StartCullDistance; // Offset: 0x14 | Size: 0x4
	struct FPerPlatformInt EndCullDistance; // Offset: 0x18 | Size: 0x4
	int32_t MinLOD; // Offset: 0x1c | Size: 0x4
	enum class EGrassScaling Scaling; // Offset: 0x20 | Size: 0x1
	char pad_0x21[0x3]; // Offset: 0x21 | Size: 0x3
	struct FFloatInterval ScaleX; // Offset: 0x24 | Size: 0x8
	struct FFloatInterval ScaleY; // Offset: 0x2c | Size: 0x8
	struct FFloatInterval ScaleZ; // Offset: 0x34 | Size: 0x8
	bool RandomRotation; // Offset: 0x3c | Size: 0x1
	bool AlignToSurface; // Offset: 0x3d | Size: 0x1
	bool bUseLandscapeLightmap; // Offset: 0x3e | Size: 0x1
	struct FLightingChannels LightingChannels; // Offset: 0x3f | Size: 0x1
	bool bReceivesDecals; // Offset: 0x40 | Size: 0x1
	bool bCastDynamicShadow; // Offset: 0x41 | Size: 0x1
	bool bKeepInstanceBufferCPUCopy; // Offset: 0x42 | Size: 0x1
	bool bUseLightmapPerPixelPerInstance; // Offset: 0x43 | Size: 0x1
	int32_t OverrideCVarMinVertsToSplitNode; // Offset: 0x44 | Size: 0x4
};

// Object: ScriptStruct Landscape.LandscapeInfoLayerSettings
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FLandscapeInfoLayerSettings {
	// Fields
	struct ULandscapeLayerInfoObject* LayerInfoObj; // Offset: 0x0 | Size: 0x8
	struct FName LayerName; // Offset: 0x8 | Size: 0x8
};

// Object: ScriptStruct Landscape.LandscapeMaterialTextureStreamingInfo
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FLandscapeMaterialTextureStreamingInfo {
	// Fields
	struct FName TextureName; // Offset: 0x0 | Size: 0x8
	float TexelFactor; // Offset: 0x8 | Size: 0x4
};

// Object: ScriptStruct Landscape.LandscapeProxyMaterialOverride
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FLandscapeProxyMaterialOverride {
	// Fields
	struct FPerPlatformInt LODIndex; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct UMaterialInterface* Material; // Offset: 0x8 | Size: 0x8
};

// Object: ScriptStruct Landscape.LandscapeImportLayerInfo
// Inherited Bytes: 0x0 | Struct Size: 0x1
struct FLandscapeImportLayerInfo {
	// Fields
	char pad_0x0[0x1]; // Offset: 0x0 | Size: 0x1
};

// Object: ScriptStruct Landscape.LandscapeLayerStruct
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FLandscapeLayerStruct {
	// Fields
	struct ULandscapeLayerInfoObject* LayerInfoObj; // Offset: 0x0 | Size: 0x8
};

// Object: ScriptStruct Landscape.LandscapeEditorLayerSettings
// Inherited Bytes: 0x0 | Struct Size: 0x1
struct FLandscapeEditorLayerSettings {
	// Fields
	char pad_0x0[0x1]; // Offset: 0x0 | Size: 0x1
};

// Object: ScriptStruct Landscape.LandscapeSplineSegmentSurfaceName
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FLandscapeSplineSegmentSurfaceName {
	// Fields
	enum class ELandscapeSplineSegmentSurface Type; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	struct FName Name; // Offset: 0x4 | Size: 0x8
};

// Object: ScriptStruct Landscape.LandscapeSplineConnection
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FLandscapeSplineConnection {
	// Fields
	struct ULandscapeSplineSegment* Segment; // Offset: 0x0 | Size: 0x8
	char End : 1; // Offset: 0x8 | Size: 0x1
	char pad_0x8_1 : 7; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x7]; // Offset: 0x9 | Size: 0x7
};

// Object: ScriptStruct Landscape.ForeignWorldSplineData
// Inherited Bytes: 0x0 | Struct Size: 0x1
struct FForeignWorldSplineData {
	// Fields
	char pad_0x0[0x1]; // Offset: 0x0 | Size: 0x1
};

// Object: ScriptStruct Landscape.ForeignSplineSegmentData
// Inherited Bytes: 0x0 | Struct Size: 0x1
struct FForeignSplineSegmentData {
	// Fields
	char pad_0x0[0x1]; // Offset: 0x0 | Size: 0x1
};

// Object: ScriptStruct Landscape.ForeignControlPointData
// Inherited Bytes: 0x0 | Struct Size: 0x1
struct FForeignControlPointData {
	// Fields
	char pad_0x0[0x1]; // Offset: 0x0 | Size: 0x1
};

// Object: ScriptStruct Landscape.LandscapeSplineMeshEntry
// Inherited Bytes: 0x0 | Struct Size: 0x38
struct FLandscapeSplineMeshEntry {
	// Fields
	struct UStaticMesh* Mesh; // Offset: 0x0 | Size: 0x8
	struct TArray<struct UMaterialInterface*> MaterialOverrides; // Offset: 0x8 | Size: 0x10
	char bCenterH : 1; // Offset: 0x18 | Size: 0x1
	char pad_0x18_1 : 7; // Offset: 0x18 | Size: 0x1
	char pad_0x19[0x3]; // Offset: 0x19 | Size: 0x3
	struct FVector2D CenterAdjust; // Offset: 0x1c | Size: 0x8
	char bScaleToWidth : 1; // Offset: 0x24 | Size: 0x1
	char pad_0x24_1 : 7; // Offset: 0x24 | Size: 0x1
	char pad_0x25[0x3]; // Offset: 0x25 | Size: 0x3
	struct FVector Scale; // Offset: 0x28 | Size: 0xc
	enum class LandscapeSplineMeshOrientation Orientation; // Offset: 0x34 | Size: 0x1
	enum class ESplineMeshAxis ForwardAxis; // Offset: 0x35 | Size: 0x1
	enum class ESplineMeshAxis UpAxis; // Offset: 0x36 | Size: 0x1
	char pad_0x37[0x1]; // Offset: 0x37 | Size: 0x1
};

// Object: ScriptStruct Landscape.LandscapeSplineSegmentConnection
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FLandscapeSplineSegmentConnection {
	// Fields
	struct ULandscapeSplineControlPoint* ControlPoint; // Offset: 0x0 | Size: 0x8
	float TangentLen; // Offset: 0x8 | Size: 0x4
	struct FName SocketName; // Offset: 0xc | Size: 0x8
	char pad_0x14[0x4]; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct Landscape.LandscapeSplineInterpPoint
// Inherited Bytes: 0x0 | Struct Size: 0x70
struct FLandscapeSplineInterpPoint {
	// Fields
	struct FVector Center; // Offset: 0x0 | Size: 0xc
	struct FVector Left; // Offset: 0xc | Size: 0xc
	struct FVector Right; // Offset: 0x18 | Size: 0xc
	struct FVector FalloffLeft; // Offset: 0x24 | Size: 0xc
	struct FVector FalloffRight; // Offset: 0x30 | Size: 0xc
	struct FVector LayerLeft; // Offset: 0x3c | Size: 0xc
	struct FVector LayerRight; // Offset: 0x48 | Size: 0xc
	struct FVector LayerFalloffLeft; // Offset: 0x54 | Size: 0xc
	struct FVector LayerFalloffRight; // Offset: 0x60 | Size: 0xc
	float StartEndFalloff; // Offset: 0x6c | Size: 0x4
};

// Object: ScriptStruct Landscape.GrassInput
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FGrassInput {
	// Fields
	struct FName Name; // Offset: 0x0 | Size: 0x8
	struct ULandscapeGrassType* GrassType; // Offset: 0x8 | Size: 0x8
	struct FExpressionInput Input; // Offset: 0x10 | Size: 0xc
	char pad_0x1C[0xc]; // Offset: 0x1c | Size: 0xc
};

// Object: ScriptStruct Landscape.LayerBlendInput
// Inherited Bytes: 0x0 | Struct Size: 0x48
struct FLayerBlendInput {
	// Fields
	struct FName LayerName; // Offset: 0x0 | Size: 0x8
	enum class ELandscapeLayerBlendType BlendType; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x3]; // Offset: 0x9 | Size: 0x3
	struct FExpressionInput LayerInput; // Offset: 0xc | Size: 0xc
	char pad_0x18[0x8]; // Offset: 0x18 | Size: 0x8
	struct FExpressionInput HeightInput; // Offset: 0x20 | Size: 0xc
	char pad_0x2C[0x8]; // Offset: 0x2c | Size: 0x8
	float PreviewWeight; // Offset: 0x34 | Size: 0x4
	struct FVector ConstLayerInput; // Offset: 0x38 | Size: 0xc
	float ConstHeightInput; // Offset: 0x44 | Size: 0x4
};

