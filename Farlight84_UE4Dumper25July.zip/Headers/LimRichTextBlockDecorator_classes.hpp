#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass LimRichTextBlockDecorator.LimRichTextBlockDecorator_C
// Inherited Bytes: 0x30 | Struct Size: 0x30
struct ULimRichTextBlockDecorator_C : URichTextBlockImageDecorator {
};

