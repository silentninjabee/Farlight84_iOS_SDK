#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class MRMesh.MeshReconstructorBase
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UMeshReconstructorBase : UObject {
	// Functions

	// Object: Function MRMesh.MeshReconstructorBase.StopReconstruction
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104a61464
	// Return & Params: [ Num(0) Size(0x0) ]
	void StopReconstruction();

	// Object: Function MRMesh.MeshReconstructorBase.StartReconstruction
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104a61478
	// Return & Params: [ Num(0) Size(0x0) ]
	void StartReconstruction();

	// Object: Function MRMesh.MeshReconstructorBase.PauseReconstruction
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104a61450
	// Return & Params: [ Num(0) Size(0x0) ]
	void PauseReconstruction();

	// Object: Function MRMesh.MeshReconstructorBase.IsReconstructionStarted
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104a61428
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsReconstructionStarted();

	// Object: Function MRMesh.MeshReconstructorBase.IsReconstructionPaused
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104a61400
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsReconstructionPaused();

	// Object: Function MRMesh.MeshReconstructorBase.DisconnectMRMesh
	// Flags: [Native|Public]
	// Offset: 0x104a61398
	// Return & Params: [ Num(0) Size(0x0) ]
	void DisconnectMRMesh();

	// Object: Function MRMesh.MeshReconstructorBase.ConnectMRMesh
	// Flags: [Native|Public]
	// Offset: 0x104a613ac
	// Return & Params: [ Num(1) Size(0x8) ]
	void ConnectMRMesh(struct UMRMeshComponent* Mesh);
};

// Object: Class MRMesh.MockDataMeshTrackerComponent
// Inherited Bytes: 0x370 | Struct Size: 0x3e0
struct UMockDataMeshTrackerComponent : USceneComponent {
	// Fields
	struct FMulticastInlineDelegate OnMeshTrackerUpdated; // Offset: 0x368 | Size: 0x10
	bool ScanWorld; // Offset: 0x378 | Size: 0x1
	bool RequestNormals; // Offset: 0x379 | Size: 0x1
	bool RequestVertexConfidence; // Offset: 0x37a | Size: 0x1
	enum class EMeshTrackerVertexColorMode VertexColorMode; // Offset: 0x37b | Size: 0x1
	struct TArray<struct FColor> BlockVertexColors; // Offset: 0x380 | Size: 0x10
	struct FLinearColor VertexColorFromConfidenceZero; // Offset: 0x390 | Size: 0x10
	struct FLinearColor VertexColorFromConfidenceOne; // Offset: 0x3a0 | Size: 0x10
	float UpdateInterval; // Offset: 0x3b0 | Size: 0x4
	struct UMRMeshComponent* MRMesh; // Offset: 0x3b8 | Size: 0x8
	char pad_0x3C0[0x20]; // Offset: 0x3c0 | Size: 0x20

	// Functions

	// Object: DelegateFunction MRMesh.MockDataMeshTrackerComponent.OnMockDataMeshTrackerUpdated__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(5) Size(0x48) ]
	void OnMockDataMeshTrackerUpdated__DelegateSignature(int32_t Index, struct TArray<struct FVector>& Vertices, struct TArray<int32_t>& Triangles, struct TArray<struct FVector>& Normals, struct TArray<float>& Confidence);

	// Object: Function MRMesh.MockDataMeshTrackerComponent.DisconnectMRMesh
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104a61674
	// Return & Params: [ Num(1) Size(0x8) ]
	void DisconnectMRMesh(struct UMRMeshComponent* InMRMeshPtr);

	// Object: Function MRMesh.MockDataMeshTrackerComponent.ConnectMRMesh
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104a616ac
	// Return & Params: [ Num(1) Size(0x8) ]
	void ConnectMRMesh(struct UMRMeshComponent* InMRMeshPtr);
};

// Object: Class MRMesh.MRMeshComponent
// Inherited Bytes: 0x5e0 | Struct Size: 0x650
struct UMRMeshComponent : UPrimitiveComponent {
	// Fields
	struct UMaterialInterface* Material; // Offset: 0x5e0 | Size: 0x8
	bool bCreateMeshProxySections; // Offset: 0x5e8 | Size: 0x1
	bool bUpdateNavMeshOnMeshUpdate; // Offset: 0x5e9 | Size: 0x1
	bool bNeverCreateCollisionMesh; // Offset: 0x5ea | Size: 0x1
	char pad_0x5EB[0x5]; // Offset: 0x5eb | Size: 0x5
	struct UBodySetup* CachedBodySetup; // Offset: 0x5f0 | Size: 0x8
	struct TArray<struct UBodySetup*> BodySetups; // Offset: 0x5f8 | Size: 0x10
	struct UMaterialInterface* WireframeMaterial; // Offset: 0x608 | Size: 0x8
	char pad_0x610[0x40]; // Offset: 0x610 | Size: 0x40

	// Functions

	// Object: Function MRMesh.MRMeshComponent.IsConnected
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104a617d8
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsConnected();

	// Object: Function MRMesh.MRMeshComponent.ForceNavMeshUpdate
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104a617c4
	// Return & Params: [ Num(0) Size(0x0) ]
	void ForceNavMeshUpdate();

	// Object: Function MRMesh.MRMeshComponent.Clear
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104a617b0
	// Return & Params: [ Num(0) Size(0x0) ]
	void Clear();
};

