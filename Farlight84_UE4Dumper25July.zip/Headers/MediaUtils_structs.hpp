#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct MediaUtils.MediaPlayerOptions
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FMediaPlayerOptions {
	// Fields
	struct FMediaPlayerTrackOptions Tracks; // Offset: 0x0 | Size: 0x1c
	char pad_0x1C[0x4]; // Offset: 0x1c | Size: 0x4
	struct FTimespan SeekTime; // Offset: 0x20 | Size: 0x8
	enum class EMediaPlayerOptionBooleanOverride PlayOnOpen; // Offset: 0x28 | Size: 0x1
	enum class EMediaPlayerOptionBooleanOverride Loop; // Offset: 0x29 | Size: 0x1
	char pad_0x2A[0x6]; // Offset: 0x2a | Size: 0x6
};

// Object: ScriptStruct MediaUtils.MediaPlayerTrackOptions
// Inherited Bytes: 0x0 | Struct Size: 0x1c
struct FMediaPlayerTrackOptions {
	// Fields
	int32_t Audio; // Offset: 0x0 | Size: 0x4
	int32_t Caption; // Offset: 0x4 | Size: 0x4
	int32_t MetaData; // Offset: 0x8 | Size: 0x4
	int32_t Script; // Offset: 0xc | Size: 0x4
	int32_t Subtitle; // Offset: 0x10 | Size: 0x4
	int32_t Text; // Offset: 0x14 | Size: 0x4
	int32_t Video; // Offset: 0x18 | Size: 0x4
};

