#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Enum MeshWidget.EUIMeshTransform
enum class EUIMeshTransform : uint8_t {
	Perspective = 0,
	Orthographic = 1,
	EUIMeshTransform_MAX = 2
};

