#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class MotionWarping.AnimNotifyState_MotionWarping
// Inherited Bytes: 0x30 | Struct Size: 0x38
struct UAnimNotifyState_MotionWarping : UAnimNotifyState {
	// Fields
	struct URootMotionModifier* RootMotionModifier; // Offset: 0x30 | Size: 0x8

	// Functions

	// Object: Function MotionWarping.AnimNotifyState_MotionWarping.OnWarpUpdate
	// Flags: [Event|Public|BlueprintEvent|Const]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(2) Size(0x10) ]
	void OnWarpUpdate(struct UMotionWarpingComponent* MotionWarpingComp, struct URootMotionModifier* Modifier);

	// Object: Function MotionWarping.AnimNotifyState_MotionWarping.OnWarpEnd
	// Flags: [Event|Public|BlueprintEvent|Const]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(2) Size(0x10) ]
	void OnWarpEnd(struct UMotionWarpingComponent* MotionWarpingComp, struct URootMotionModifier* Modifier);

	// Object: Function MotionWarping.AnimNotifyState_MotionWarping.OnWarpBegin
	// Flags: [Event|Public|BlueprintEvent|Const]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(2) Size(0x10) ]
	void OnWarpBegin(struct UMotionWarpingComponent* MotionWarpingComp, struct URootMotionModifier* Modifier);

	// Object: Function MotionWarping.AnimNotifyState_MotionWarping.OnRootMotionModifierUpdate
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x1010c6378
	// Return & Params: [ Num(2) Size(0x10) ]
	void OnRootMotionModifierUpdate(struct UMotionWarpingComponent* MotionWarpingComp, struct URootMotionModifier* Modifier);

	// Object: Function MotionWarping.AnimNotifyState_MotionWarping.OnRootMotionModifierDeactivate
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x1010c62bc
	// Return & Params: [ Num(2) Size(0x10) ]
	void OnRootMotionModifierDeactivate(struct UMotionWarpingComponent* MotionWarpingComp, struct URootMotionModifier* Modifier);

	// Object: Function MotionWarping.AnimNotifyState_MotionWarping.OnRootMotionModifierActivate
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x1010c6434
	// Return & Params: [ Num(2) Size(0x10) ]
	void OnRootMotionModifierActivate(struct UMotionWarpingComponent* MotionWarpingComp, struct URootMotionModifier* Modifier);

	// Object: Function MotionWarping.AnimNotifyState_MotionWarping.AddRootMotionModifier
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	// Offset: 0x1010c64f0
	// Return & Params: [ Num(5) Size(0x20) ]
	struct URootMotionModifier* AddRootMotionModifier(struct UMotionWarpingComponent* MotionWarpingComp, struct UAnimSequenceBase* Animation, float StartTime, float EndTime);
};

// Object: Class MotionWarping.MotionWarpingUtilities
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UMotionWarpingUtilities : UBlueprintFunctionLibrary {
	// Functions

	// Object: Function MotionWarping.MotionWarpingUtilities.GetMotionWarpingWindowsFromAnimation
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102a03c20
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetMotionWarpingWindowsFromAnimation(struct UAnimSequenceBase* Animation, struct TArray<struct FMotionWarpingWindowData>& OutWindows);

	// Object: Function MotionWarping.MotionWarpingUtilities.GetMotionWarpingWindowsForWarpTargetFromAnimation
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102a03b64
	// Return & Params: [ Num(3) Size(0x20) ]
	void GetMotionWarpingWindowsForWarpTargetFromAnimation(struct UAnimSequenceBase* Animation, struct FName WarpTargetName, struct TArray<struct FMotionWarpingWindowData>& OutWindows);

	// Object: Function MotionWarping.MotionWarpingUtilities.ExtractRootMotionFromAnimation
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x102a03cb8
	// Return & Params: [ Num(4) Size(0x40) ]
	struct FTransform ExtractRootMotionFromAnimation(struct UAnimSequenceBase* Animation, float StartTime, float EndTime);
};

// Object: Class MotionWarping.MotionWarpingComponent
// Inherited Bytes: 0xc0 | Struct Size: 0x170
struct UMotionWarpingComponent : UActorComponent {
	// Fields
	bool bSearchForWindowsInAnimsWithinMontages; // Offset: 0xc0 | Size: 0x1
	char pad_0xC1[0x7]; // Offset: 0xc1 | Size: 0x7
	struct FMulticastInlineDelegate OnPreUpdate; // Offset: 0xc8 | Size: 0x10
	struct TWeakObjectPtr<struct ACharacter> CharacterOwner; // Offset: 0xd8 | Size: 0x8
	struct TArray<struct URootMotionModifier*> Modifiers; // Offset: 0xe0 | Size: 0x10
	struct TMap<struct FName, struct FMotionWarpingTarget> WarpTargetMap; // Offset: 0xf0 | Size: 0x50
	char pad_0x140[0x30]; // Offset: 0x140 | Size: 0x30

	// Functions

	// Object: Function MotionWarping.MotionWarpingComponent.RemoveWarpTarget
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102a03ec0
	// Return & Params: [ Num(2) Size(0xc) ]
	int32_t RemoveWarpTarget(struct FName WarpTargetName);

	// Object: Function MotionWarping.MotionWarpingComponent.DisableAllRootMotionModifiers
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102a0446c
	// Return & Params: [ Num(0) Size(0x0) ]
	void DisableAllRootMotionModifiers();

	// Object: Function MotionWarping.MotionWarpingComponent.AddOrUpdateWarpTargetFromTransform
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x102a04280
	// Return & Params: [ Num(2) Size(0x40) ]
	void AddOrUpdateWarpTargetFromTransform(struct FName WarpTargetName, struct FTransform TargetTransform);

	// Object: Function MotionWarping.MotionWarpingComponent.AddOrUpdateWarpTargetFromLocationAndRotation
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x102a03f4c
	// Return & Params: [ Num(3) Size(0x20) ]
	void AddOrUpdateWarpTargetFromLocationAndRotation(struct FName WarpTargetName, struct FVector TargetLocation, struct FRotator TargetRotation);

	// Object: Function MotionWarping.MotionWarpingComponent.AddOrUpdateWarpTargetFromLocation
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x102a0408c
	// Return & Params: [ Num(2) Size(0x14) ]
	void AddOrUpdateWarpTargetFromLocation(struct FName WarpTargetName, struct FVector TargetLocation);

	// Object: Function MotionWarping.MotionWarpingComponent.AddOrUpdateWarpTargetFromComponent
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102a04178
	// Return & Params: [ Num(4) Size(0x19) ]
	void AddOrUpdateWarpTargetFromComponent(struct FName WarpTargetName, struct USceneComponent* Component, struct FName BoneName, bool bFollowComponent);

	// Object: Function MotionWarping.MotionWarpingComponent.AddOrUpdateWarpTarget
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x102a04370
	// Return & Params: [ Num(2) Size(0x60) ]
	void AddOrUpdateWarpTarget(struct FName WarpTargetName, struct FMotionWarpingTarget& WarpTarget);
};

// Object: Class MotionWarping.RootMotionModifier
// Inherited Bytes: 0x28 | Struct Size: 0xc0
struct URootMotionModifier : UObject {
	// Fields
	struct TWeakObjectPtr<struct UAnimSequenceBase> Animation; // Offset: 0x28 | Size: 0x8
	float StartTime; // Offset: 0x30 | Size: 0x4
	float EndTime; // Offset: 0x34 | Size: 0x4
	float PreviousPosition; // Offset: 0x38 | Size: 0x4
	float CurrentPosition; // Offset: 0x3c | Size: 0x4
	float Weight; // Offset: 0x40 | Size: 0x4
	bool bInLocalSpace; // Offset: 0x44 | Size: 0x1
	char pad_0x45[0xb]; // Offset: 0x45 | Size: 0xb
	struct FTransform StartTransform; // Offset: 0x50 | Size: 0x30
	float ActualStartTime; // Offset: 0x80 | Size: 0x4
	struct FDelegate OnActivateDelegate; // Offset: 0x84 | Size: 0x10
	struct FDelegate OnUpdateDelegate; // Offset: 0x94 | Size: 0x10
	struct FDelegate OnDeactivateDelegate; // Offset: 0xa4 | Size: 0x10
	enum class ERootMotionModifierState State; // Offset: 0xb4 | Size: 0x1
	char pad_0xB5[0xb]; // Offset: 0xb5 | Size: 0xb
};

// Object: Class MotionWarping.RootMotionModifier_Warp
// Inherited Bytes: 0xc0 | Struct Size: 0x1b0
struct URootMotionModifier_Warp : URootMotionModifier {
	// Fields
	struct FName WarpTargetName; // Offset: 0xb8 | Size: 0x8
	enum class EWarpPointAnimProvider WarpPointAnimProvider; // Offset: 0xc0 | Size: 0x1
	char pad_0xC9[0x7]; // Offset: 0xc9 | Size: 0x7
	struct FTransform WarpPointAnimTransform; // Offset: 0xd0 | Size: 0x30
	struct FName WarpPointAnimBoneName; // Offset: 0x100 | Size: 0x8
	bool bWarpTranslation; // Offset: 0x108 | Size: 0x1
	bool bIgnoreZAxis; // Offset: 0x109 | Size: 0x1
	bool bOnlyZAxis; // Offset: 0x10a | Size: 0x1
	bool bWarpRotation; // Offset: 0x10b | Size: 0x1
	enum class EMotionWarpRotationType RotationType; // Offset: 0x10c | Size: 0x1
	char pad_0x10D[0x3]; // Offset: 0x10d | Size: 0x3
	float WarpRotationTimeMultiplier; // Offset: 0x110 | Size: 0x4
	char pad_0x114[0xc]; // Offset: 0x114 | Size: 0xc
	struct FTransform CachedTargetTransform; // Offset: 0x120 | Size: 0x30
	char pad_0x150[0x60]; // Offset: 0x150 | Size: 0x60
};

// Object: Class MotionWarping.RootMotionModifier_SimpleWarp
// Inherited Bytes: 0x1b0 | Struct Size: 0x1b0
struct URootMotionModifier_SimpleWarp : URootMotionModifier_Warp {
};

// Object: Class MotionWarping.RootMotionModifier_Scale
// Inherited Bytes: 0xc0 | Struct Size: 0xd0
struct URootMotionModifier_Scale : URootMotionModifier {
	// Fields
	struct FVector Scale; // Offset: 0xb8 | Size: 0xc
	char pad_0xCC[0x4]; // Offset: 0xcc | Size: 0x4
};

// Object: Class MotionWarping.RootMotionModifier_ApplyInput
// Inherited Bytes: 0xc0 | Struct Size: 0xd0
struct URootMotionModifier_ApplyInput : URootMotionModifier {
	// Fields
	float Scale; // Offset: 0xb8 | Size: 0x4
	char pad_0xC4[0xc]; // Offset: 0xc4 | Size: 0xc
};

// Object: Class MotionWarping.RootMotionModifier_AdjustmentBlendWarp
// Inherited Bytes: 0x1b0 | Struct Size: 0x280
struct URootMotionModifier_AdjustmentBlendWarp : URootMotionModifier_Warp {
	// Fields
	bool bWarpIKBones; // Offset: 0x1b0 | Size: 0x1
	char pad_0x1B1[0x7]; // Offset: 0x1b1 | Size: 0x7
	struct TArray<struct FName> IKBones; // Offset: 0x1b8 | Size: 0x10
	char pad_0x1C8[0x8]; // Offset: 0x1c8 | Size: 0x8
	struct FTransform CachedMeshTransform; // Offset: 0x1d0 | Size: 0x30
	struct FTransform CachedMeshRelativeTransform; // Offset: 0x200 | Size: 0x30
	struct FTransform CachedRootMotion; // Offset: 0x230 | Size: 0x30
	struct FAnimSequenceTrackContainer Result; // Offset: 0x260 | Size: 0x20

	// Functions

	// Object: Function MotionWarping.RootMotionModifier_AdjustmentBlendWarp.GetAdjustmentBlendIKBoneTransformAndAlpha
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x102a04a94
	// Return & Params: [ Num(4) Size(0x44) ]
	void GetAdjustmentBlendIKBoneTransformAndAlpha(struct ACharacter* Character, struct FName BoneName, struct FTransform& OutTransform, float& OutAlpha);

	// Object: Function MotionWarping.RootMotionModifier_AdjustmentBlendWarp.AddRootMotionModifierAdjustmentBlendWarp
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x102a04bc4
	// Return & Params: [ Num(14) Size(0x88) ]
	struct URootMotionModifier_AdjustmentBlendWarp* AddRootMotionModifierAdjustmentBlendWarp(struct UMotionWarpingComponent* InMotionWarpingComp, struct UAnimSequenceBase* InAnimation, float InStartTime, float InEndTime, struct FName InWarpTargetName, enum class EWarpPointAnimProvider InWarpPointAnimProvider, struct FTransform InWarpPointAnimTransform, struct FName InWarpPointAnimBoneName, bool bInWarpTranslation, bool bInIgnoreZAxis, bool bInWarpRotation, bool bInWarpIKBones, struct TArray<struct FName>& InIKBones);
};

// Object: Class MotionWarping.RootMotionModifier_SkewWarp
// Inherited Bytes: 0x1b0 | Struct Size: 0x1e0
struct URootMotionModifier_SkewWarp : URootMotionModifier_Warp {
	// Fields
	char pad_0x1B0[0x1c]; // Offset: 0x1b0 | Size: 0x1c
	float MaxWarpDistance; // Offset: 0x1cc | Size: 0x4
	float MaxWarpAngle; // Offset: 0x1d0 | Size: 0x4
	bool bClampByWarpDir2D; // Offset: 0x1d4 | Size: 0x1
	char pad_0x1D5[0xb]; // Offset: 0x1d5 | Size: 0xb

	// Functions

	// Object: Function MotionWarping.RootMotionModifier_SkewWarp.AddRootMotionModifierSkewWarp
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x102a0502c
	// Return & Params: [ Num(14) Size(0x78) ]
	struct URootMotionModifier_SkewWarp* AddRootMotionModifierSkewWarp(struct UMotionWarpingComponent* InMotionWarpingComp, struct UAnimSequenceBase* InAnimation, float InStartTime, float InEndTime, struct FName InWarpTargetName, enum class EWarpPointAnimProvider InWarpPointAnimProvider, struct FTransform InWarpPointAnimTransform, struct FName InWarpPointAnimBoneName, bool bInWarpTranslation, bool bInIgnoreZAxis, bool bInWarpRotation, enum class EMotionWarpRotationType InRotationType, float InWarpRotationTimeMultiplier);
};

