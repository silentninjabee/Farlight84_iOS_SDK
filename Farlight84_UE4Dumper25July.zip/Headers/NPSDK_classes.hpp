#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class NPSDK.NPSDK
// Inherited Bytes: 0x28 | Struct Size: 0x48
struct UNPSDK : UObject {
	// Fields
	char pad_0x28[0x20]; // Offset: 0x28 | Size: 0x20

	// Functions

	// Object: Function NPSDK.NPSDK.OnRecvTokResultNotify
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d8fd60
	// Return & Params: [ Num(1) Size(0x10) ]
	void OnRecvTokResultNotify(struct FString Data);

	// Object: Function NPSDK.NPSDK.OnRecvConfigNotify
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x102d8fdbc
	// Return & Params: [ Num(1) Size(0x10) ]
	void OnRecvConfigNotify(struct FString Data);

	// Object: Function NPSDK.NPSDK.NPHtpSetRoleInfo
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102d8fe18
	// Return & Params: [ Num(8) Size(0x6c) ]
	int32_t NPHtpSetRoleInfo(struct FString BusinessId, struct FString RoleID, struct FString RoleName, struct FString RoleAccount, struct FString RoleServer, int32_t ServerId, struct FString GameJson);

	// Object: Function NPSDK.NPSDK.NPHtpInit
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102d8fffc
	// Return & Params: [ Num(5) Size(0x3c) ]
	int32_t NPHtpInit(struct FString ProductID, struct FString GameKey, int32_t ServerType, struct FString Channel);

	// Object: Function NPSDK.NPSDK.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102d90138
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UNPSDK* GetInstance();

	// Object: Function NPSDK.NPSDK.DestroyInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x102d90124
	// Return & Params: [ Num(0) Size(0x0) ]
	void DestroyInstance();
};

// Object: Class NPSDK.NPSDKSettings
// Inherited Bytes: 0x38 | Struct Size: 0x40
struct UNPSDKSettings : UDeveloperSettings {
	// Fields
	bool bEnableNPSDK; // Offset: 0x38 | Size: 0x1
	char pad_0x39[0x7]; // Offset: 0x39 | Size: 0x7
};

