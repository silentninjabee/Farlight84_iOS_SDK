#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct OnlineSubsystem.InAppPurchaseProductInfo
// Inherited Bytes: 0x0 | Struct Size: 0xa8
struct FInAppPurchaseProductInfo {
	// Fields
	struct FString Identifier; // Offset: 0x0 | Size: 0x10
	struct FString TransactionIdentifier; // Offset: 0x10 | Size: 0x10
	struct FString DisplayName; // Offset: 0x20 | Size: 0x10
	struct FString DisplayDescription; // Offset: 0x30 | Size: 0x10
	struct FString DisplayPrice; // Offset: 0x40 | Size: 0x10
	float RawPrice; // Offset: 0x50 | Size: 0x4
	char pad_0x54[0x4]; // Offset: 0x54 | Size: 0x4
	struct FString CurrencyCode; // Offset: 0x58 | Size: 0x10
	struct FString CurrencySymbol; // Offset: 0x68 | Size: 0x10
	struct FString DecimalSeparator; // Offset: 0x78 | Size: 0x10
	struct FString GroupingSeparator; // Offset: 0x88 | Size: 0x10
	struct FString ReceiptData; // Offset: 0x98 | Size: 0x10
};

// Object: ScriptStruct OnlineSubsystem.InAppPurchaseRestoreInfo
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FInAppPurchaseRestoreInfo {
	// Fields
	struct FString Identifier; // Offset: 0x0 | Size: 0x10
	struct FString ReceiptData; // Offset: 0x10 | Size: 0x10
	struct FString TransactionIdentifier; // Offset: 0x20 | Size: 0x10
};

// Object: ScriptStruct OnlineSubsystem.NamedInterfaceDef
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FNamedInterfaceDef {
	// Fields
	struct FName InterfaceName; // Offset: 0x0 | Size: 0x8
	struct FString InterfaceClassName; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct OnlineSubsystem.NamedInterface
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FNamedInterface {
	// Fields
	struct FName InterfaceName; // Offset: 0x0 | Size: 0x8
	struct UObject* InterfaceObject; // Offset: 0x8 | Size: 0x8
};

// Object: ScriptStruct OnlineSubsystem.InAppPurchaseProductRequest
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FInAppPurchaseProductRequest {
	// Fields
	struct FString ProductIdentifier; // Offset: 0x0 | Size: 0x10
	bool bIsConsumable; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x7]; // Offset: 0x11 | Size: 0x7
};

