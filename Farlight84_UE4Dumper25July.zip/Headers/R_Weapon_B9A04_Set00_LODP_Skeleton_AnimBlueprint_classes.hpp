#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: DynamicClass R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_C
// Inherited Bytes: 0x300 | Struct Size: 0xa40
struct UR_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_C : UWeaponAnimInstance {
	// Fields
	struct FAnimNode_Root AnimGraphNode_Root; // Offset: 0x300 | Size: 0x30
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_19; // Offset: 0x330 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_18; // Offset: 0x358 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_17; // Offset: 0x380 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_16; // Offset: 0x3a8 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_15; // Offset: 0x3d0 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_14; // Offset: 0x3f8 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_13; // Offset: 0x420 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_12; // Offset: 0x448 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_11; // Offset: 0x470 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_10; // Offset: 0x498 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_9; // Offset: 0x4c0 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_8; // Offset: 0x4e8 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_7; // Offset: 0x510 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_6; // Offset: 0x538 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_5; // Offset: 0x560 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_4; // Offset: 0x588 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_3; // Offset: 0x5b0 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_2; // Offset: 0x5d8 | Size: 0x28
	struct FAnimNode_StateResult AnimGraphNode_StateResult_9; // Offset: 0x600 | Size: 0x30
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_3; // Offset: 0x630 | Size: 0x88
	struct FAnimNode_StateResult AnimGraphNode_StateResult_8; // Offset: 0x6b8 | Size: 0x30
	struct FAnimNode_StateResult AnimGraphNode_StateResult_7; // Offset: 0x6e8 | Size: 0x30
	struct FAnimNode_StateResult AnimGraphNode_StateResult_6; // Offset: 0x718 | Size: 0x30
	struct FAnimNode_StateResult AnimGraphNode_StateResult_5; // Offset: 0x748 | Size: 0x30
	struct FAnimNode_StateResult AnimGraphNode_StateResult_4; // Offset: 0x778 | Size: 0x30
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2; // Offset: 0x7a8 | Size: 0x88
	struct FAnimNode_StateResult AnimGraphNode_StateResult_3; // Offset: 0x830 | Size: 0x30
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer; // Offset: 0x860 | Size: 0x88
	struct FAnimNode_StateResult AnimGraphNode_StateResult_2; // Offset: 0x8e8 | Size: 0x30
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult; // Offset: 0x918 | Size: 0x28
	struct FAnimNode_StateResult AnimGraphNode_StateResult; // Offset: 0x940 | Size: 0x30
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine; // Offset: 0x970 | Size: 0xb0
	struct FAnimMsgData K2Node_MakeStruct_AnimMsgData; // Offset: 0xa20 | Size: 0x8
	struct TArray<struct FAnimMsgData> K2Node_MakeArray_Array; // Offset: 0xa28 | Size: 0x10
	char pad_0xA38[0x8]; // Offset: 0xa38 | Size: 0x8

	// Functions

	// Object: Function R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_C.TestAPI
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x103231f58
	// Return & Params: [ Num(0) Size(0x0) ]
	void TestAPI();

	// Object: Function R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_C.InterruptAnim
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x103231f6c
	// Return & Params: [ Num(0) Size(0x0) ]
	void InterruptAnim();

	// Object: Function R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_F24ACCD04F9816FE9D766B945C515A17
	// Flags: [Native|Public]
	// Offset: 0x103231e98
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_F24ACCD04F9816FE9D766B945C515A17();

	// Object: Function R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_EE537D0E40457B0C18FCAEBC0C3ED399
	// Flags: [Native|Public]
	// Offset: 0x103231f1c
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_EE537D0E40457B0C18FCAEBC0C3ED399();

	// Object: Function R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_E0229C914BA4E5771C33CCBDC40559C5
	// Flags: [Native|Public]
	// Offset: 0x103231ed4
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_E0229C914BA4E5771C33CCBDC40559C5();

	// Object: Function R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_D066E4F445D8B9D17E881E99F7DDFDFC
	// Flags: [Native|Public]
	// Offset: 0x103231f20
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_D066E4F445D8B9D17E881E99F7DDFDFC();

	// Object: Function R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_C56C131748626A9573F10282DB5E5052
	// Flags: [Native|Public]
	// Offset: 0x103231f40
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_C56C131748626A9573F10282DB5E5052();

	// Object: Function R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_BC0CF4F64A6C98918E7513B5D9394953
	// Flags: [Native|Public]
	// Offset: 0x103231ee8
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_BC0CF4F64A6C98918E7513B5D9394953();

	// Object: Function R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_B4B62B9D47B0C1161E6CE19216D27AEA
	// Flags: [Native|Public]
	// Offset: 0x103231f10
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_B4B62B9D47B0C1161E6CE19216D27AEA();

	// Object: Function R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_AABE1C004ECF87A2034CCA88B05CDD38
	// Flags: [Native|Public]
	// Offset: 0x103231f2c
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_AABE1C004ECF87A2034CCA88B05CDD38();

	// Object: Function R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_A863A2F74187E8118A2F6D8E60300523
	// Flags: [Native|Public]
	// Offset: 0x103231f24
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_A863A2F74187E8118A2F6D8E60300523();

	// Object: Function R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_84EB688D49FE8D60181894BF737AC498
	// Flags: [Native|Public]
	// Offset: 0x103231ec0
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_84EB688D49FE8D60181894BF737AC498();

	// Object: Function R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_7B529D21433A869664E2179B4C613BA5
	// Flags: [Native|Public]
	// Offset: 0x103231f14
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_7B529D21433A869664E2179B4C613BA5();

	// Object: Function R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_77EDB4C1425DF2DF774DAEB1479B3048
	// Flags: [Native|Public]
	// Offset: 0x103231f60
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_77EDB4C1425DF2DF774DAEB1479B3048();

	// Object: Function R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_6CEE3A2D414CEB6E9949B3AE8B35E54E
	// Flags: [Native|Public]
	// Offset: 0x103231efc
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_6CEE3A2D414CEB6E9949B3AE8B35E54E();

	// Object: Function R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_68B6675247DA823995BD8A8473A86377
	// Flags: [Native|Public]
	// Offset: 0x103231f44
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_68B6675247DA823995BD8A8473A86377();

	// Object: Function R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_50AE56FC480E668DE2BAE78A71FF5789
	// Flags: [Native|Public]
	// Offset: 0x103231eac
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_50AE56FC480E668DE2BAE78A71FF5789();

	// Object: Function R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_47B480004460910C1D11029F8F7F5163
	// Flags: [Native|Public]
	// Offset: 0x101443c34
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_47B480004460910C1D11029F8F7F5163();

	// Object: Function R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_37A891C448B1ADADFF382886CBBA43FF
	// Flags: [Native|Public]
	// Offset: 0x103231f28
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_37A891C448B1ADADFF382886CBBA43FF();

	// Object: Function R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_13B1B2364014E8EE709B10992D43ECBF
	// Flags: [Native|Public]
	// Offset: 0x103231f34
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_13B1B2364014E8EE709B10992D43ECBF();

	// Object: Function R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_0011171C434B57CADB4A22B6D1C6DEF5
	// Flags: [Native|Public]
	// Offset: 0x103231f18
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_0011171C434B57CADB4A22B6D1C6DEF5();

	// Object: Function R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_SequencePlayer_FD9E62FB4BF9F8E65B55ABB0CCD5B28C
	// Flags: [Native|Public]
	// Offset: 0x103231f3c
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_SequencePlayer_FD9E62FB4BF9F8E65B55ABB0CCD5B28C();

	// Object: Function R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_SequencePlayer_E4E641294B19BA48572E4BAAE5E32FA9
	// Flags: [Native|Public]
	// Offset: 0x103231f30
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_SequencePlayer_E4E641294B19BA48572E4BAAE5E32FA9();

	// Object: Function R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_SequencePlayer_7208B17C4942AAB3573456B9468769AA
	// Flags: [Native|Public]
	// Offset: 0x103231f38
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_AnimGraphNode_SequencePlayer_7208B17C4942AAB3573456B9468769AA();

	// Object: Function R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_C.AnimNotify_QuitIdle
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x103231f68
	// Return & Params: [ Num(0) Size(0x0) ]
	void AnimNotify_QuitIdle();

	// Object: Function R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_C.AnimNotify_QuitFire
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x103231f64
	// Return & Params: [ Num(0) Size(0x0) ]
	void AnimNotify_QuitFire();

	// Object: Function R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_C.AnimNotify_EnterIdle
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x101443c50
	// Return & Params: [ Num(0) Size(0x0) ]
	void AnimNotify_EnterIdle();

	// Object: Function R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_C.AnimNotify_EnterFire
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x103231f5c
	// Return & Params: [ Num(0) Size(0x0) ]
	void AnimNotify_EnterFire();

	// Object: Function R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_B9A04_Set00_LODP_Skeleton_AnimBlueprint_C.AnimGraph
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x103231e54
	// Return & Params: [ Num(1) Size(0x10) ]
	void AnimGraph(struct FPoseLink& bpp__AnimGraph__pf);
};

