#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: DynamicClass R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint.R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_C
// Inherited Bytes: 0x300 | Struct Size: 0xa40
struct UR_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_C : UWeaponAnimInstance {
	// Fields
	struct FAnimNode_Root AnimGraphNode_Root; // Offset: 0x300 | Size: 0x30
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_19; // Offset: 0x330 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_18; // Offset: 0x358 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_17; // Offset: 0x380 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_16; // Offset: 0x3a8 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_15; // Offset: 0x3d0 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_14; // Offset: 0x3f8 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_13; // Offset: 0x420 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_12; // Offset: 0x448 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_11; // Offset: 0x470 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_10; // Offset: 0x498 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_9; // Offset: 0x4c0 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_8; // Offset: 0x4e8 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_7; // Offset: 0x510 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_6; // Offset: 0x538 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_5; // Offset: 0x560 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_4; // Offset: 0x588 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_3; // Offset: 0x5b0 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_2; // Offset: 0x5d8 | Size: 0x28
	struct FAnimNode_StateResult AnimGraphNode_StateResult_9; // Offset: 0x600 | Size: 0x30
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_3; // Offset: 0x630 | Size: 0x88
	struct FAnimNode_StateResult AnimGraphNode_StateResult_8; // Offset: 0x6b8 | Size: 0x30
	struct FAnimNode_StateResult AnimGraphNode_StateResult_7; // Offset: 0x6e8 | Size: 0x30
	struct FAnimNode_StateResult AnimGraphNode_StateResult_6; // Offset: 0x718 | Size: 0x30
	struct FAnimNode_StateResult AnimGraphNode_StateResult_5; // Offset: 0x748 | Size: 0x30
	struct FAnimNode_StateResult AnimGraphNode_StateResult_4; // Offset: 0x778 | Size: 0x30
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2; // Offset: 0x7a8 | Size: 0x88
	struct FAnimNode_StateResult AnimGraphNode_StateResult_3; // Offset: 0x830 | Size: 0x30
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer; // Offset: 0x860 | Size: 0x88
	struct FAnimNode_StateResult AnimGraphNode_StateResult_2; // Offset: 0x8e8 | Size: 0x30
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult; // Offset: 0x918 | Size: 0x28
	struct FAnimNode_StateResult AnimGraphNode_StateResult; // Offset: 0x940 | Size: 0x30
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine; // Offset: 0x970 | Size: 0xb0
	struct FAnimMsgData K2Node_MakeStruct_AnimMsgData; // Offset: 0xa20 | Size: 0x8
	struct TArray<struct FAnimMsgData> K2Node_MakeArray_Array; // Offset: 0xa28 | Size: 0x10
	char pad_0xA38[0x8]; // Offset: 0xa38 | Size: 0x8

	// Functions

	// Object: Function R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint.R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_C.TestAPI
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x103232b98
	// Return & Params: [ Num(0) Size(0x0) ]
	void TestAPI();

	// Object: Function R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint.R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_C.InterruptAnim
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x103232bc8
	// Return & Params: [ Num(0) Size(0x0) ]
	void InterruptAnim();

	// Object: Function R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint.R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_FC0194B2401EA22381DBF39C55947FF9
	// Flags: [Native|Public]
	// Offset: 0x103232b3c
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_FC0194B2401EA22381DBF39C55947FF9();

	// Object: Function R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint.R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_E401BBA149B0DABC77E320A5D26F161C
	// Flags: [Native|Public]
	// Offset: 0x103232b44
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_E401BBA149B0DABC77E320A5D26F161C();

	// Object: Function R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint.R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_C959CBB24B6E3FBB125D5386BA83BA89
	// Flags: [Native|Public]
	// Offset: 0x103232b38
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_C959CBB24B6E3FBB125D5386BA83BA89();

	// Object: Function R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint.R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_C56C131748626A9573F10282DB5E5052
	// Flags: [Native|Public]
	// Offset: 0x103232b90
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_C56C131748626A9573F10282DB5E5052();

	// Object: Function R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint.R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_968E57334D0560E0D81E8F8CBF255866
	// Flags: [Native|Public]
	// Offset: 0x103232b60
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_968E57334D0560E0D81E8F8CBF255866();

	// Object: Function R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint.R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_90C97F4B4CBC8816A38216BE138E6F89
	// Flags: [Native|Public]
	// Offset: 0x103232b54
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_90C97F4B4CBC8816A38216BE138E6F89();

	// Object: Function R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint.R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_902489064567DB8F1C7F35A412FC55BD
	// Flags: [Native|Public]
	// Offset: 0x103232b50
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_902489064567DB8F1C7F35A412FC55BD();

	// Object: Function R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint.R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_8E281982451991810FB1CDBE5C7AB333
	// Flags: [Native|Public]
	// Offset: 0x103232b4c
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_8E281982451991810FB1CDBE5C7AB333();

	// Object: Function R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint.R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_75414DB244FBB7A53F3CE18A9FB7157B
	// Flags: [Native|Public]
	// Offset: 0x103232b34
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_75414DB244FBB7A53F3CE18A9FB7157B();

	// Object: Function R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint.R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_73C2053F48EBA57AE80C7EB511A1ED8A
	// Flags: [Native|Public]
	// Offset: 0x103232b48
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_73C2053F48EBA57AE80C7EB511A1ED8A();

	// Object: Function R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint.R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_666390444F55176B8452A3ADD88C04EC
	// Flags: [Native|Public]
	// Offset: 0x103232b58
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_666390444F55176B8452A3ADD88C04EC();

	// Object: Function R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint.R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_57FE46434F01218D85EC4697425396E0
	// Flags: [Native|Public]
	// Offset: 0x103232b2c
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_57FE46434F01218D85EC4697425396E0();

	// Object: Function R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint.R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_57691DF54B9855E9DD506B9FCCB61EA7
	// Flags: [Native|Public]
	// Offset: 0x103232b64
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_57691DF54B9855E9DD506B9FCCB61EA7();

	// Object: Function R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint.R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_4ADDE6E04C5F8810E1EEA58820D214AE
	// Flags: [Native|Public]
	// Offset: 0x103232b94
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_4ADDE6E04C5F8810E1EEA58820D214AE();

	// Object: Function R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint.R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_43F44591410E60EB2C5CD2B43DEB8E8E
	// Flags: [Native|Public]
	// Offset: 0x103232b5c
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_43F44591410E60EB2C5CD2B43DEB8E8E();

	// Object: Function R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint.R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_2C342F604862980A804FF2996F90C087
	// Flags: [Native|Public]
	// Offset: 0x103232b40
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_2C342F604862980A804FF2996F90C087();

	// Object: Function R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint.R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_28F31C444D5EA218BB1A38AACC8722F3
	// Flags: [Native|Public]
	// Offset: 0x103232b30
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_28F31C444D5EA218BB1A38AACC8722F3();

	// Object: Function R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint.R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_20E8B10A4E9FF7BA091039BFD5B13AD8
	// Flags: [Native|Public]
	// Offset: 0x103232ba0
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_20E8B10A4E9FF7BA091039BFD5B13AD8();

	// Object: Function R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint.R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_056EEB8B459D1AC625DFDB8AC5C35452
	// Flags: [Native|Public]
	// Offset: 0x103232b84
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_056EEB8B459D1AC625DFDB8AC5C35452();

	// Object: Function R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint.R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_SequencePlayer_9CEFF7884F12CE6C82E80A8548619832
	// Flags: [Native|Public]
	// Offset: 0x103232b80
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_SequencePlayer_9CEFF7884F12CE6C82E80A8548619832();

	// Object: Function R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint.R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_SequencePlayer_696B215C4C93CC06D553F2B7970E6146
	// Flags: [Native|Public]
	// Offset: 0x103232b88
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_SequencePlayer_696B215C4C93CC06D553F2B7970E6146();

	// Object: Function R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint.R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_SequencePlayer_0D0A1C5849872911C76BD99ABCFFA34E
	// Flags: [Native|Public]
	// Offset: 0x103232b8c
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_SequencePlayer_0D0A1C5849872911C76BD99ABCFFA34E();

	// Object: Function R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint.R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_C.AnimNotify_QuitIdle
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x103232bc4
	// Return & Params: [ Num(0) Size(0x0) ]
	void AnimNotify_QuitIdle();

	// Object: Function R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint.R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_C.AnimNotify_QuitFire
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x103232ba4
	// Return & Params: [ Num(0) Size(0x0) ]
	void AnimNotify_QuitFire();

	// Object: Function R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint.R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_C.AnimNotify_EnterIdle
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x103232ba8
	// Return & Params: [ Num(0) Size(0x0) ]
	void AnimNotify_EnterIdle();

	// Object: Function R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint.R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_C.AnimNotify_EnterFire
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x103232b9c
	// Return & Params: [ Num(0) Size(0x0) ]
	void AnimNotify_EnterFire();

	// Object: Function R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint.R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_C.AnimGraph
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x103232af4
	// Return & Params: [ Num(1) Size(0x10) ]
	void AnimGraph(struct FPoseLink& bpp__AnimGraph__pf);
};

