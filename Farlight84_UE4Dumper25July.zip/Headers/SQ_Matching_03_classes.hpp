#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass SQ_Matching_03.SequenceDirector_C
// Inherited Bytes: 0x30 | Struct Size: 0x38
struct USequenceDirector_C : ULevelSequenceDirector {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x30 | Size: 0x8

	// Functions

	// Object: Function SQ_Matching_03.SequenceDirector_C.SequenceEvent__ENTRYPOINTSequenceDirector_2
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x8) ]
	void SequenceEvent__ENTRYPOINTSequenceDirector_2(struct UStaticMeshComponent* StaticMeshComponent0);

	// Object: Function SQ_Matching_03.SequenceDirector_C.SequenceEvent__ENTRYPOINTSequenceDirector_1
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x8) ]
	void SequenceEvent__ENTRYPOINTSequenceDirector_1(struct UStaticMeshComponent* StaticMeshComponent0);

	// Object: Function SQ_Matching_03.SequenceDirector_C.ResetMiFixedFovByScreenSize
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(4) Size(0x20) ]
	void ResetMiFixedFovByScreenSize(struct UStaticMeshComponent* StaticMeshComponent0, int32_t ElementIndex, struct UMaterialInterface* SourceMaterial, struct FName OptionalName);

	// Object: Function SQ_Matching_03.SequenceDirector_C.ExecuteUbergraph_SequenceDirector
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_SequenceDirector(int32_t EntryPoint);
};

