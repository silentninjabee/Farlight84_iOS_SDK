#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: UserDefinedStruct S_EventList_BattleRoyal.S_EventList_BattleRoyal
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FS_EventList_BattleRoyal {
	// Fields
	struct TArray<struct FS_Event_BattleRoyale> EventList_3_9C55B4BD476EE1024C917DAC11DB6F31; // Offset: 0x0 | Size: 0x10
};

