#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: UserDefinedStruct S_KeyPromptGamepad.S_KeyPromptGamepad
// Inherited Bytes: 0x0 | Struct Size: 0x1
struct FS_KeyPromptGamepad {
	// Fields
	bool MemberVar_0_B90AE02F4CB9AD0D665AA28F9A2AC172; // Offset: 0x0 | Size: 0x1
};

