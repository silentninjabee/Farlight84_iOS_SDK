#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: UserDefinedStruct S_KeyPromptKeyBoard.S_KeyPromptKeyBoard
// Inherited Bytes: 0x0 | Struct Size: 0x68
struct FS_KeyPromptKeyBoard {
	// Fields
	struct FLinearColor BgColor_2_B90AE02F4CB9AD0D665AA28F9A2AC172; // Offset: 0x0 | Size: 0x10
	int32_t FontSize_5_3519D57C41DC7FD8DC74729EB654DCBA; // Offset: 0x10 | Size: 0x4
	struct FVector2D BgSize_8_734A1B214070AE4C1235A5A5E6C9846E; // Offset: 0x14 | Size: 0x8
	struct FLinearColor FrameColor_11_7DC26D3E422D4404F9456E972E80A82C; // Offset: 0x1c | Size: 0x10
	char pad_0x2C[0x4]; // Offset: 0x2c | Size: 0x4
	struct FSlateColor FontColor_16_E6BA2266442348FA427E25A3D34A2AF9; // Offset: 0x30 | Size: 0x28
	struct FLinearColor ImgColor_19_110032324758E641DC33699848D52BCA; // Offset: 0x58 | Size: 0x10
};

