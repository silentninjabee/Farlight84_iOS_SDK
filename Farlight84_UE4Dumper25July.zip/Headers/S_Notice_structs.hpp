#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: UserDefinedStruct S_Notice.S_Notice
// Inherited Bytes: 0x0 | Struct Size: 0x19
struct FS_Notice {
	// Fields
	struct UObject* Icon_23_BE1B67524B1209FD0942B6B9560F62CC; // Offset: 0x0 | Size: 0x8
	struct FString Text_24_2592C444471410BA3FD02289094D92BE; // Offset: 0x8 | Size: 0x10
	enum class E_NoticeLevel NoticeLevel_25_2D9897214095D9FC1F3636B3132BC0AD; // Offset: 0x18 | Size: 0x1
};

