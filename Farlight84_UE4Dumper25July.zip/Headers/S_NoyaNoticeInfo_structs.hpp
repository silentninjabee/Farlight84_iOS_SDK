#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: UserDefinedStruct S_NoyaNoticeInfo.S_NoyaNoticeInfo
// Inherited Bytes: 0x0 | Struct Size: 0x6c
struct FS_NoyaNoticeInfo {
	// Fields
	enum class E_NoticeType_Noya Type_19_61521B0446EAF964ED4414B88CA78D95; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	float LifeTime_20_BD882D5545761162ABC2D8B45FABE100; // Offset: 0x4 | Size: 0x4
	struct FString Text_21_231C41074F4B39F8D3276B9B458D1D31; // Offset: 0x8 | Size: 0x10
	struct TMap<char, bool> TriggerCondition_24_461190CB4B9B8C849665FEBEA709D091; // Offset: 0x18 | Size: 0x50
	int32_t MaxTiggerTimes_23_1487705444240010E31DD4A6A175CACD; // Offset: 0x68 | Size: 0x4
};

