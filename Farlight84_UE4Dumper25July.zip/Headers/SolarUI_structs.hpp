#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct SolarUI.SolarWidgetNavigationData
// Inherited Bytes: 0x0 | Struct Size: 0x1
struct FSolarWidgetNavigationData {
	// Fields
	char bHasNavUp : 1; // Offset: 0x0 | Size: 0x1
	char bHasNavDown : 1; // Offset: 0x0 | Size: 0x1
	char bHasNavLeft : 1; // Offset: 0x0 | Size: 0x1
	char bHasNavRight : 1; // Offset: 0x0 | Size: 0x1
	char pad_0x0_4 : 4; // Offset: 0x0 | Size: 0x1
};

// Object: ScriptStruct SolarUI.PlayAnimationParams
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FPlayAnimationParams {
	// Fields
	char pad_0x0[0x40]; // Offset: 0x0 | Size: 0x40
};

// Object: ScriptStruct SolarUI.WidgetOverrideParam
// Inherited Bytes: 0x0 | Struct Size: 0x150
struct FWidgetOverrideParam {
	// Fields
	enum class EWidgetOverrideParamType Type; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	struct FName ChildName; // Offset: 0x4 | Size: 0x8
	bool bEnableLocText; // Offset: 0xc | Size: 0x1
	char pad_0xD[0x3]; // Offset: 0xd | Size: 0x3
	struct FText Text; // Offset: 0x10 | Size: 0x18
	int32_t LocTextID; // Offset: 0x28 | Size: 0x4
	char pad_0x2C[0x4]; // Offset: 0x2c | Size: 0x4
	struct FSlateBrush Brush; // Offset: 0x30 | Size: 0xf0
	struct FString CustomParameter; // Offset: 0x120 | Size: 0x10
	struct FGameplayTag GameplayTag; // Offset: 0x130 | Size: 0x8
	struct TArray<struct FString> MetaData; // Offset: 0x138 | Size: 0x10
	char pad_0x148[0x8]; // Offset: 0x148 | Size: 0x8
};

// Object: ScriptStruct SolarUI.SolarUIMapPanelSlotAdapterEntry
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FSolarUIMapPanelSlotAdapterEntry {
	// Fields
	struct UPanelSlot* SrcPanelSlotClass; // Offset: 0x0 | Size: 0x8
	struct USolarPanelSlotAdapter* DstPanelSlotClass; // Offset: 0x8 | Size: 0x8
};

// Object: ScriptStruct SolarUI.SolarUIMapWidgetAdapterEntry
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FSolarUIMapWidgetAdapterEntry {
	// Fields
	struct UWidget* SrcWidgetClass; // Offset: 0x0 | Size: 0x8
	struct USolarWidgetAdapter* DstWidgetClass; // Offset: 0x8 | Size: 0x8
};

