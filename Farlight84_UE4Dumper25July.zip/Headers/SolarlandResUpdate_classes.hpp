#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class SolarlandResUpdate.SolarlandResUpdater
// Inherited Bytes: 0x28 | Struct Size: 0x30
struct USolarlandResUpdater : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
};

// Object: Class SolarlandResUpdate.DownloadFileTask
// Inherited Bytes: 0x28 | Struct Size: 0xf0
struct UDownloadFileTask : UObject {
	// Fields
	struct FMulticastInlineDelegate OnDownloadComplete; // Offset: 0x28 | Size: 0x10
	struct FMulticastInlineDelegate OnDownloadProgress; // Offset: 0x38 | Size: 0x10
	struct FMulticastInlineDelegate OnDownloadFailed; // Offset: 0x48 | Size: 0x10
	char pad_0x58[0x98]; // Offset: 0x58 | Size: 0x98

	// Functions

	// Object: Function SolarlandResUpdate.DownloadFileTask.StartDownload
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1044bb008
	// Return & Params: [ Num(0) Size(0x0) ]
	void StartDownload();

	// Object: Function SolarlandResUpdate.DownloadFileTask.SetTaskComplete
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1044baff8
	// Return & Params: [ Num(0) Size(0x0) ]
	void SetTaskComplete();

	// Object: Function SolarlandResUpdate.DownloadFileTask.SetSaveToFile
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1044baed0
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetSaveToFile(bool InSet);

	// Object: Function SolarlandResUpdate.DownloadFileTask.SetForceRedownload
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1044bafb0
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetForceRedownload(bool inForceRedownload);

	// Object: Function SolarlandResUpdate.DownloadFileTask.SetForceCheckSize
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1044baf20
	// Return & Params: [ Num(2) Size(0x8) ]
	void SetForceCheckSize(bool InIfForceCheckSize, int32_t InTotalSize);

	// Object: Function SolarlandResUpdate.DownloadFileTask.OnWriteFileComplete
	// Flags: [Final|Native|Private|BlueprintCallable]
	// Offset: 0x1044bae38
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnWriteFileComplete(bool bWriteResult);

	// Object: Function SolarlandResUpdate.DownloadFileTask.GetUrl
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1044bae70
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetUrl();

	// Object: Function SolarlandResUpdate.DownloadFileTask.CreateNoFile
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1044bb018
	// Return & Params: [ Num(3) Size(0x20) ]
	struct UDownloadFileTask* CreateNoFile(struct FString URL, bool bByChunk);

	// Object: Function SolarlandResUpdate.DownloadFileTask.Create
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1044bb0b8
	// Return & Params: [ Num(7) Size(0x40) ]
	struct UDownloadFileTask* Create(struct FString URL, struct FString FileDirectory, struct FString Filename, bool bByChunk, bool bForceWrite, bool bAsyncWrite);

	// Object: Function SolarlandResUpdate.DownloadFileTask.CancelDownload
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1044bafe8
	// Return & Params: [ Num(0) Size(0x0) ]
	void CancelDownload();
};

