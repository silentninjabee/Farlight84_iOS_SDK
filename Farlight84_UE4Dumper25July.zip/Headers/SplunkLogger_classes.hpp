#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class SplunkLogger.PipelineCacheConfig
// Inherited Bytes: 0x28 | Struct Size: 0x38
struct UPipelineCacheConfig : UObject {
	// Fields
	struct FString PSOServer; // Offset: 0x28 | Size: 0x10
};

