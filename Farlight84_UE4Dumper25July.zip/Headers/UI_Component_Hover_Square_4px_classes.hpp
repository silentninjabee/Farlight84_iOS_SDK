#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Component_Hover_Square_4px.UI_Component_Hover_Square_4px_C
// Inherited Bytes: 0x490 | Struct Size: 0x505
struct UUI_Component_Hover_Square_4px_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x490 | Size: 0x8
	struct UWidgetAnimation* Anim_Hover; // Offset: 0x498 | Size: 0x8
	struct UNamedSlot* Content; // Offset: 0x4a0 | Size: 0x8
	struct UImage* Img_Frame_Hover; // Offset: 0x4a8 | Size: 0x8
	struct UImage* Img_Frame_Sel; // Offset: 0x4b0 | Size: 0x8
	struct UImage* Img_VX_Loop; // Offset: 0x4b8 | Size: 0x8
	struct UImage* Img_VX_Loop_Special; // Offset: 0x4c0 | Size: 0x8
	struct UCanvasPanel* Panel_Hover; // Offset: 0x4c8 | Size: 0x8
	struct UCanvasPanel* Panel_loop; // Offset: 0x4d0 | Size: 0x8
	bool Hover; // Offset: 0x4d8 | Size: 0x1
	bool Select; // Offset: 0x4d9 | Size: 0x1
	char pad_0x4DA[0x2]; // Offset: 0x4da | Size: 0x2
	struct FLinearColor Color_Select; // Offset: 0x4dc | Size: 0x10
	struct FLinearColor Color_Hover; // Offset: 0x4ec | Size: 0x10
	float Loop_Offset; // Offset: 0x4fc | Size: 0x4
	float Loop_Size; // Offset: 0x500 | Size: 0x4
	bool ShowSpeicalLight; // Offset: 0x504 | Size: 0x1

	// Functions

	// Object: Function UI_Component_Hover_Square_4px.UI_Component_Hover_Square_4px_C.SetSelect
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetSelect(bool Select);

	// Object: Function UI_Component_Hover_Square_4px.UI_Component_Hover_Square_4px_C.SetHover
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetHover(bool Hover);

	// Object: Function UI_Component_Hover_Square_4px.UI_Component_Hover_Square_4px_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_Component_Hover_Square_4px.UI_Component_Hover_Square_4px_C.OnMouseEnter
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(2) Size(0xa8) ]
	void OnMouseEnter(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent);

	// Object: Function UI_Component_Hover_Square_4px.UI_Component_Hover_Square_4px_C.OnMouseLeave
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x70) ]
	void OnMouseLeave(struct FPointerEvent& MouseEvent);

	// Object: Function UI_Component_Hover_Square_4px.UI_Component_Hover_Square_4px_C.ExecuteUbergraph_UI_Component_Hover_Square_4px
	// Flags: [Final|UbergraphFunction|HasDefaults]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_Component_Hover_Square_4px(int32_t EntryPoint);
};

