#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Emote_Common_UR_022.UI_Emote_Common_UR_022_C
// Inherited Bytes: 0x6e8 | Struct Size: 0x718
struct UUI_Emote_Common_UR_022_C : UEmojiBubbleWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x6e8 | Size: 0x8
	struct UWidgetAnimation* EmojiEnd_Anim_2; // Offset: 0x6f0 | Size: 0x8
	struct UWidgetAnimation* EmojiBegin_Anim_2; // Offset: 0x6f8 | Size: 0x8
	struct UImage* img_Emoji_Bg; // Offset: 0x700 | Size: 0x8
	struct UImage* img_Emoji_Bg_2; // Offset: 0x708 | Size: 0x8
	struct UCanvasPanel* Panel_Emoji; // Offset: 0x710 | Size: 0x8

	// Functions

	// Object: Function UI_Emote_Common_UR_022.UI_Emote_Common_UR_022_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_Emote_Common_UR_022.UI_Emote_Common_UR_022_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void Construct();

	// Object: Function UI_Emote_Common_UR_022.UI_Emote_Common_UR_022_C.ExecuteUbergraph_UI_Emote_Common_UR_022
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_Emote_Common_UR_022(int32_t EntryPoint);
};

