#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_FL84Logo_Anim.UI_FL84Logo_Anim_C
// Inherited Bytes: 0x490 | Struct Size: 0x4d8
struct UUI_FL84Logo_Anim_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x490 | Size: 0x8
	struct UWidgetAnimation* Anim_Loop; // Offset: 0x498 | Size: 0x8
	struct UUIMeshWidget* UIMesh_1_2; // Offset: 0x4a0 | Size: 0x8
	struct UUIMeshWidget* UIMesh_1_3; // Offset: 0x4a8 | Size: 0x8
	struct UUIMeshWidget* UIMesh_2_2; // Offset: 0x4b0 | Size: 0x8
	struct UUIMeshWidget* UIMesh_2_3; // Offset: 0x4b8 | Size: 0x8
	struct UUIMeshWidget* UIMesh_3_2; // Offset: 0x4c0 | Size: 0x8
	struct UUIMeshWidget* UIMesh_3_3; // Offset: 0x4c8 | Size: 0x8
	struct UUIMeshWidget* UIMesh_Triangle; // Offset: 0x4d0 | Size: 0x8

	// Functions

	// Object: Function UI_FL84Logo_Anim.UI_FL84Logo_Anim_C.StopAnimationLoop
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void StopAnimationLoop();

	// Object: Function UI_FL84Logo_Anim.UI_FL84Logo_Anim_C.PlayAnimationLoop
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void PlayAnimationLoop();

	// Object: Function UI_FL84Logo_Anim.UI_FL84Logo_Anim_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_FL84Logo_Anim.UI_FL84Logo_Anim_C.ExecuteUbergraph_UI_FL84Logo_Anim
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_FL84Logo_Anim(int32_t EntryPoint);
};

