#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_HUD_Notice_BuyResurrection.UI_HUD_Notice_BuyResurrection_C
// Inherited Bytes: 0x4e8 | Struct Size: 0x520
struct UUI_HUD_Notice_BuyResurrection_C : UUI_NoticeBase_C {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x4e8 | Size: 0x8
	struct UWidgetAnimation* ant_exit; // Offset: 0x4f0 | Size: 0x8
	struct UWidgetAnimation* Appear_Anim; // Offset: 0x4f8 | Size: 0x8
	struct UImage* Img_Txt_bg; // Offset: 0x500 | Size: 0x8
	struct URichTextBlock* Txt_Ballte_Notice_2; // Offset: 0x508 | Size: 0x8
	struct USolarTextBlock* Txt_Ballte_Notice_4; // Offset: 0x510 | Size: 0x8
	struct USolarTextBlock* Txt_Ballte_Notice_5; // Offset: 0x518 | Size: 0x8

	// Functions

	// Object: Function UI_HUD_Notice_BuyResurrection.UI_HUD_Notice_BuyResurrection_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void Construct();

	// Object: Function UI_HUD_Notice_BuyResurrection.UI_HUD_Notice_BuyResurrection_C.ShowNotice
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(2) Size(0x14) ]
	void ShowNotice(struct FString Text, float Duration);

	// Object: Function UI_HUD_Notice_BuyResurrection.UI_HUD_Notice_BuyResurrection_C.ExecuteUbergraph_UI_HUD_Notice_BuyResurrection
	// Flags: [Final|UbergraphFunction|HasDefaults]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_HUD_Notice_BuyResurrection(int32_t EntryPoint);
};

