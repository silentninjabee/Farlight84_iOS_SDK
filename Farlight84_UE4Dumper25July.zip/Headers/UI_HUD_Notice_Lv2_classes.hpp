#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_HUD_Notice_Lv2.UI_HUD_Notice_Lv2_C
// Inherited Bytes: 0x4e8 | Struct Size: 0x528
struct UUI_HUD_Notice_Lv2_C : UUI_NoticeBase_C {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x4e8 | Size: 0x8
	struct UWidgetAnimation* ant_exit; // Offset: 0x4f0 | Size: 0x8
	struct UWidgetAnimation* Appear_Anim; // Offset: 0x4f8 | Size: 0x8
	struct UBackgroundBlur* Blur_Mask; // Offset: 0x500 | Size: 0x8
	struct UImage* Img_Icon; // Offset: 0x508 | Size: 0x8
	struct USolarImage* Img_Icon_bg; // Offset: 0x510 | Size: 0x8
	struct USolarImage* Img_Txt_bg; // Offset: 0x518 | Size: 0x8
	struct USolarRichTextBlock* Txt_Ballte_Notice; // Offset: 0x520 | Size: 0x8

	// Functions

	// Object: Function UI_HUD_Notice_Lv2.UI_HUD_Notice_Lv2_C.GetExitAnimation
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UWidgetAnimation* GetExitAnimation();

	// Object: Function UI_HUD_Notice_Lv2.UI_HUD_Notice_Lv2_C.GetEnterAnimation
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UWidgetAnimation* GetEnterAnimation();

	// Object: Function UI_HUD_Notice_Lv2.UI_HUD_Notice_Lv2_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void Construct();

	// Object: Function UI_HUD_Notice_Lv2.UI_HUD_Notice_Lv2_C.ExecuteUbergraph_UI_HUD_Notice_Lv2
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_HUD_Notice_Lv2(int32_t EntryPoint);
};

