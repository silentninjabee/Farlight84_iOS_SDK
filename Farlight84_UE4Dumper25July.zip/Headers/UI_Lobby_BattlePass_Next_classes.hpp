#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Lobby_BattlePass_Next.UI_Lobby_BattlePass_Next_C
// Inherited Bytes: 0x490 | Struct Size: 0x54b
struct UUI_Lobby_BattlePass_Next_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x490 | Size: 0x8
	struct UWidgetAnimation* Loop_Anim; // Offset: 0x498 | Size: 0x8
	struct UWidgetAnimation* Anim_Upgrade; // Offset: 0x4a0 | Size: 0x8
	struct UWidgetAnimation* Anim_Loop; // Offset: 0x4a8 | Size: 0x8
	struct UWidgetAnimation* Anim_Max_Upgrade; // Offset: 0x4b0 | Size: 0x8
	struct UButton* Btn_BattlePass; // Offset: 0x4b8 | Size: 0x8
	struct UImage* Img_Arrow_Glow; // Offset: 0x4c0 | Size: 0x8
	struct UImage* Img_Arrow_Glow_2; // Offset: 0x4c8 | Size: 0x8
	struct UImage* Img_Arrow_Glow_3; // Offset: 0x4d0 | Size: 0x8
	struct UImage* Img_Bg_light; // Offset: 0x4d8 | Size: 0x8
	struct UImage* Img_BPBG; // Offset: 0x4e0 | Size: 0x8
	struct UImage* img_Hero; // Offset: 0x4e8 | Size: 0x8
	struct UImage* img_Hero_3; // Offset: 0x4f0 | Size: 0x8
	struct UImage* Img_Weapon; // Offset: 0x4f8 | Size: 0x8
	struct UImage* Level_Progress; // Offset: 0x500 | Size: 0x8
	struct UUI_Lobby_BattlePass_NewTag_C* NewTag; // Offset: 0x508 | Size: 0x8
	struct UCanvasPanel* Panel_BattlePass; // Offset: 0x510 | Size: 0x8
	struct UScaleBox* Scale_BattlePass; // Offset: 0x518 | Size: 0x8
	struct UScaleBox* ScaleBox_Type; // Offset: 0x520 | Size: 0x8
	struct USolarRedHint_General_C* SolarRedHint_General_2; // Offset: 0x528 | Size: 0x8
	struct USolarTextBlock* Txt_BattlePass; // Offset: 0x530 | Size: 0x8
	struct UTextBlock* Txt_Battlepass_Level; // Offset: 0x538 | Size: 0x8
	struct USolarTextBlock* Txt_Type; // Offset: 0x540 | Size: 0x8
	bool isMax; // Offset: 0x548 | Size: 0x1
	bool isUpdate; // Offset: 0x549 | Size: 0x1
	bool isClaim; // Offset: 0x54a | Size: 0x1

	// Functions

	// Object: DelegateFunction UI_Lobby_BattlePass_Next.UI_Lobby_BattlePass_Next_C.OnClicked_F1E590F3FD487E9B0B7387B230F01C04
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1011445c0
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_F1E590F3FD487E9B0B7387B230F01C04();

	// Object: Function UI_Lobby_BattlePass_Next.UI_Lobby_BattlePass_Next_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();

	// Object: Function UI_Lobby_BattlePass_Next.UI_Lobby_BattlePass_Next_C.SetClaimable
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetClaimable(bool NewParam);

	// Object: Function UI_Lobby_BattlePass_Next.UI_Lobby_BattlePass_Next_C.SetUpdate
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetUpdate(bool NewParam);

	// Object: Function UI_Lobby_BattlePass_Next.UI_Lobby_BattlePass_Next_C.SetLevel
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetLevel(bool NewParam);

	// Object: Function UI_Lobby_BattlePass_Next.UI_Lobby_BattlePass_Next_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_Lobby_BattlePass_Next.UI_Lobby_BattlePass_Next_C.BattlePassStateChange_Event
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void BattlePassStateChange_Event();

	// Object: Function UI_Lobby_BattlePass_Next.UI_Lobby_BattlePass_Next_C.BattlePassPlayUpgradeAnimation
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void BattlePassPlayUpgradeAnimation();

	// Object: Function UI_Lobby_BattlePass_Next.UI_Lobby_BattlePass_Next_C.ExecuteUbergraph_UI_Lobby_BattlePass_Next
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_Lobby_BattlePass_Next(int32_t EntryPoint);
};

