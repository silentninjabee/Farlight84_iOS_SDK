#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Lobby_Ping.UI_Lobby_Ping_C
// Inherited Bytes: 0x490 | Struct Size: 0x872
struct UUI_Lobby_Ping_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x490 | Size: 0x8
	struct UImage* Img_Ping; // Offset: 0x498 | Size: 0x8
	struct USizeBox* SizeBox_1; // Offset: 0x4a0 | Size: 0x8
	struct UUI_Resident_Ping_C* UI_Resident_Ping; // Offset: 0x4a8 | Size: 0x8
	struct FSlateBrush ProgressBarBgImage; // Offset: 0x4b0 | Size: 0xf0
	struct FSlateBrush ProgressBarMarqueeImage; // Offset: 0x5a0 | Size: 0xf0
	struct FSlateBrush ProgressBarFillNormal; // Offset: 0x690 | Size: 0xf0
	struct FSlateBrush ProgressBarFillCharging; // Offset: 0x780 | Size: 0xf0
	enum class E_Lobby_Latency LobbyLatency; // Offset: 0x870 | Size: 0x1
	bool bWifi; // Offset: 0x871 | Size: 0x1

	// Functions

	// Object: Function UI_Lobby_Ping.UI_Lobby_Ping_C.Destruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x1011558ac
	// Return & Params: [ Num(0) Size(0x0) ]
	void Destruct();

	// Object: Function UI_Lobby_Ping.UI_Lobby_Ping_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x1011558ac
	// Return & Params: [ Num(0) Size(0x0) ]
	void Construct();

	// Object: Function UI_Lobby_Ping.UI_Lobby_Ping_C.OnInitialized
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x1011558ac
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnInitialized();

	// Object: Function UI_Lobby_Ping.UI_Lobby_Ping_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();

	// Object: Function UI_Lobby_Ping.UI_Lobby_Ping_C.UpdateLobbyLatency
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x4) ]
	void UpdateLobbyLatency(int32_t NewParam);

	// Object: Function UI_Lobby_Ping.UI_Lobby_Ping_C.RefreshLatencyIcon
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void RefreshLatencyIcon();

	// Object: Function UI_Lobby_Ping.UI_Lobby_Ping_C.OnMouseButtonDown
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(3) Size(0x160) ]
	struct FEventReply OnMouseButtonDown(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent);

	// Object: Function UI_Lobby_Ping.UI_Lobby_Ping_C.OnFocusLost
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x8) ]
	void OnFocusLost(struct FFocusEvent InFocusEvent);

	// Object: Function UI_Lobby_Ping.UI_Lobby_Ping_C.ExecuteUbergraph_UI_Lobby_Ping
	// Flags: [Final|UbergraphFunction|HasDefaults]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_Lobby_Ping(int32_t EntryPoint);
};

