#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Lobby_RoomInvite_MIni_Popup.UI_Lobby_RoomInvite_MIni_Popup_C
// Inherited Bytes: 0x260 | Struct Size: 0x44b
struct UUI_Lobby_RoomInvite_MIni_Popup_C : UUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x260 | Size: 0x8
	struct UWidgetAnimation* Anim_Loop; // Offset: 0x268 | Size: 0x8
	struct UWidgetAnimation* Anim_Enter; // Offset: 0x270 | Size: 0x8
	struct USolarButton* Btn_Join_Common; // Offset: 0x278 | Size: 0x8
	struct USolarButton* Btn_Join_League; // Offset: 0x280 | Size: 0x8
	struct USolarButton* Btn_Joining; // Offset: 0x288 | Size: 0x8
	struct UButton* Btn_Player; // Offset: 0x290 | Size: 0x8
	struct UButton* Btn_Player_2; // Offset: 0x298 | Size: 0x8
	struct USolarButton* Btn_Watch; // Offset: 0x2a0 | Size: 0x8
	struct UHorizontalBox* HorizentalBox_Match; // Offset: 0x2a8 | Size: 0x8
	struct UHorizontalBox* HorizentalBox_Spectator; // Offset: 0x2b0 | Size: 0x8
	struct UHorizontalBox* HorizontalBox_Join_2; // Offset: 0x2b8 | Size: 0x8
	struct UHorizontalBox* HorizontalBox_Joining_2; // Offset: 0x2c0 | Size: 0x8
	struct UHorizontalBox* HorizontalBox_Player; // Offset: 0x2c8 | Size: 0x8
	struct UHorizontalBox* HorizontalBox_Progress_Time; // Offset: 0x2d0 | Size: 0x8
	struct UHorizontalBox* HorizontalBox_Title_Common; // Offset: 0x2d8 | Size: 0x8
	struct UHorizontalBox* HorizontalBox_Title_League; // Offset: 0x2e0 | Size: 0x8
	struct UHorizontalBox* HorizontalBox_Watch; // Offset: 0x2e8 | Size: 0x8
	struct UImage* Img_BG_Invitation; // Offset: 0x2f0 | Size: 0x8
	struct UImage* Img_Bg_light; // Offset: 0x2f8 | Size: 0x8
	struct UImage* Img_BG_Light_01; // Offset: 0x300 | Size: 0x8
	struct UImage* Img_Btn_Join; // Offset: 0x308 | Size: 0x8
	struct UImage* Img_Btn_Join_2; // Offset: 0x310 | Size: 0x8
	struct UImage* Img_Btn_Joining_Close; // Offset: 0x318 | Size: 0x8
	struct UImage* Img_Btn_Watch; // Offset: 0x320 | Size: 0x8
	struct UImage* Img_Division; // Offset: 0x328 | Size: 0x8
	struct UImage* Img_Join_Common_Light; // Offset: 0x330 | Size: 0x8
	struct UImage* Img_Join_Light; // Offset: 0x338 | Size: 0x8
	struct USolarImageURL* Img_League_Icon; // Offset: 0x340 | Size: 0x8
	struct UImage* Img_Time_Icon; // Offset: 0x348 | Size: 0x8
	struct UImage* Img_Title_Bg; // Offset: 0x350 | Size: 0x8
	struct UImage* Img_Title_Bg_2; // Offset: 0x358 | Size: 0x8
	struct UImage* Img_Title_Bg_3; // Offset: 0x360 | Size: 0x8
	struct UImage* Img_Watch_Light; // Offset: 0x368 | Size: 0x8
	struct UOverlay* Overlay_Avatar; // Offset: 0x370 | Size: 0x8
	struct UOverlay* Overlay_Avatar_2; // Offset: 0x378 | Size: 0x8
	struct UOverlay* Overlay_Cup; // Offset: 0x380 | Size: 0x8
	struct UCanvasPanel* Panel_Info_CreateRoom; // Offset: 0x388 | Size: 0x8
	struct UCanvasPanel* Panel_Info_Invitation; // Offset: 0x390 | Size: 0x8
	struct UCanvasPanel* Panel_Pop_Common; // Offset: 0x398 | Size: 0x8
	struct UCanvasPanel* Panel_Pop_League; // Offset: 0x3a0 | Size: 0x8
	struct USolarTextBlock* Txt_Capacity; // Offset: 0x3a8 | Size: 0x8
	struct USolarTextBlock* Txt_GameMode; // Offset: 0x3b0 | Size: 0x8
	struct UTickerWidget_C* Txt_Invitation; // Offset: 0x3b8 | Size: 0x8
	struct USolarTextBlock* Txt_Invitation_2; // Offset: 0x3c0 | Size: 0x8
	struct USolarTextBlock* Txt_Join; // Offset: 0x3c8 | Size: 0x8
	struct USolarTextBlock* Txt_Join_Common; // Offset: 0x3d0 | Size: 0x8
	struct USolarTextBlock* Txt_Joining; // Offset: 0x3d8 | Size: 0x8
	struct USolarTextBlock* Txt_League_Name_2; // Offset: 0x3e0 | Size: 0x8
	struct USolarTextBlock* Txt_Map; // Offset: 0x3e8 | Size: 0x8
	struct UTextBlock* Txt_OBCurr; // Offset: 0x3f0 | Size: 0x8
	struct UTextBlock* Txt_OBCurr_2; // Offset: 0x3f8 | Size: 0x8
	struct UTextBlock* Txt_OBCurr_4; // Offset: 0x400 | Size: 0x8
	struct USolarTextBlock* Txt_OBTotal; // Offset: 0x408 | Size: 0x8
	struct USolarTextBlock* Txt_PlayerIn; // Offset: 0x410 | Size: 0x8
	struct USolarTextBlock* Txt_Progress_Time; // Offset: 0x418 | Size: 0x8
	struct USolarTextBlock* Txt_RoomName; // Offset: 0x420 | Size: 0x8
	struct USolarTextBlock* Txt_Watch; // Offset: 0x428 | Size: 0x8
	struct UUI_Component_Close_C* UI_Component_Close; // Offset: 0x430 | Size: 0x8
	struct UUI_Component_PlayerHead_C* UI_Component_PlayerHead; // Offset: 0x438 | Size: 0x8
	struct UUI_Component_PlayerHead_C* UI_Component_PlayerHead_2; // Offset: 0x440 | Size: 0x8
	enum class T_Type_System_Push Pop_Type; // Offset: 0x448 | Size: 0x1
	enum class T_Type_Button Btn_Type; // Offset: 0x449 | Size: 0x1
	bool IsNeedShow; // Offset: 0x44a | Size: 0x1

	// Functions

	// Object: DelegateFunction UI_Lobby_RoomInvite_MIni_Popup.UI_Lobby_RoomInvite_MIni_Popup_C.OnClicked_AC6DA1D8634C3B55630789949D8623C3
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1011445c0
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_AC6DA1D8634C3B55630789949D8623C3();

	// Object: DelegateFunction UI_Lobby_RoomInvite_MIni_Popup.UI_Lobby_RoomInvite_MIni_Popup_C.OnClicked_CEF6C6248642745301C91D9016281367
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1011445c0
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_CEF6C6248642745301C91D9016281367();

	// Object: Function UI_Lobby_RoomInvite_MIni_Popup.UI_Lobby_RoomInvite_MIni_Popup_C.OnClicked_823786D0B84A9A2EEF97648E58C726B2
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	// Offset: 0x1011445c0
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_823786D0B84A9A2EEF97648E58C726B2();

	// Object: Function UI_Lobby_RoomInvite_MIni_Popup.UI_Lobby_RoomInvite_MIni_Popup_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x1011558ac
	// Return & Params: [ Num(0) Size(0x0) ]
	void Construct();

	// Object: Function UI_Lobby_RoomInvite_MIni_Popup.UI_Lobby_RoomInvite_MIni_Popup_C.Destruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x1011558ac
	// Return & Params: [ Num(0) Size(0x0) ]
	void Destruct();

	// Object: Function UI_Lobby_RoomInvite_MIni_Popup.UI_Lobby_RoomInvite_MIni_Popup_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();

	// Object: Function UI_Lobby_RoomInvite_MIni_Popup.UI_Lobby_RoomInvite_MIni_Popup_C.Update_Btn
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x1) ]
	void Update_Btn(enum class T_Type_Button NewParam);

	// Object: Function UI_Lobby_RoomInvite_MIni_Popup.UI_Lobby_RoomInvite_MIni_Popup_C.SetType
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetType(enum class T_Type_System_Push Type);

	// Object: Function UI_Lobby_RoomInvite_MIni_Popup.UI_Lobby_RoomInvite_MIni_Popup_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_Lobby_RoomInvite_MIni_Popup.UI_Lobby_RoomInvite_MIni_Popup_C.ExecuteUbergraph_UI_Lobby_RoomInvite_MIni_Popup
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_Lobby_RoomInvite_MIni_Popup(int32_t EntryPoint);
};

