#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Lobby_StartBtn_New.UI_Lobby_StartBtn_New_C
// Inherited Bytes: 0x490 | Struct Size: 0x5bd
struct UUI_Lobby_StartBtn_New_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x490 | Size: 0x8
	struct UWidgetAnimation* Anim_Matching_Exit; // Offset: 0x498 | Size: 0x8
	struct UWidgetAnimation* Anim_Matching_Enter; // Offset: 0x4a0 | Size: 0x8
	struct UButton* Btn_Activity_Point; // Offset: 0x4a8 | Size: 0x8
	struct UButton* Btn_Clan_Join; // Offset: 0x4b0 | Size: 0x8
	struct UButton* Btn_Clan_Reward; // Offset: 0x4b8 | Size: 0x8
	struct USolarButton* Btn_Gamemode; // Offset: 0x4c0 | Size: 0x8
	struct USolarButton* Btn_Start; // Offset: 0x4c8 | Size: 0x8
	struct UButton* Btn_Tournament_Reward; // Offset: 0x4d0 | Size: 0x8
	struct UUI_Component_NationalFlag_C* ClanFlag; // Offset: 0x4d8 | Size: 0x8
	struct UImage* Img_Activity_BG; // Offset: 0x4e0 | Size: 0x8
	struct UImage* Img_Activity_BG_Light; // Offset: 0x4e8 | Size: 0x8
	struct UImage* Img_Activity_BG_Light_2; // Offset: 0x4f0 | Size: 0x8
	struct UImage* Img_Activity_BG_Light_3; // Offset: 0x4f8 | Size: 0x8
	struct UImage* Img_Activity_BG_Light_4; // Offset: 0x500 | Size: 0x8
	struct UImage* Img_Btn; // Offset: 0x508 | Size: 0x8
	struct UImage* Img_Map; // Offset: 0x510 | Size: 0x8
	struct UCanvasPanel* Panel_Activity_All; // Offset: 0x518 | Size: 0x8
	struct UCanvasPanel* Panel_Battle; // Offset: 0x520 | Size: 0x8
	struct USolarRedHint_General_C* RedHint_More; // Offset: 0x528 | Size: 0x8
	struct USolarRichTextBlock* SolarRichTextBlock_Team; // Offset: 0x530 | Size: 0x8
	struct USolarTextBlock* Text_Start; // Offset: 0x538 | Size: 0x8
	struct UTickerWidget_C* TickerWidget_Join; // Offset: 0x540 | Size: 0x8
	struct UTickerWidget_C* TickerWidget_Reward; // Offset: 0x548 | Size: 0x8
	struct UCanvasPanel* TutorialSlotPanel; // Offset: 0x550 | Size: 0x8
	struct USolarRichTextBlock* Txt_Activity_Point; // Offset: 0x558 | Size: 0x8
	struct USolarTextBlock* Txt_GameMode; // Offset: 0x560 | Size: 0x8
	struct USolarTextBlock* Txt_GameModeGroup; // Offset: 0x568 | Size: 0x8
	struct UTextBlock* Txt_Team_Num; // Offset: 0x570 | Size: 0x8
	struct URichTextBlock* Txt_Tournament_Reward; // Offset: 0x578 | Size: 0x8
	struct UUI_Component_Platform_C* UI_Component_Platform; // Offset: 0x580 | Size: 0x8
	struct UUI_Component_TeamNum_C* UI_Component_TeamNum; // Offset: 0x588 | Size: 0x8
	struct UUI_KeyPrompt_C* UI_KeyPrompt_Prepare; // Offset: 0x590 | Size: 0x8
	struct UUI_KeyPrompt_C* UI_KeyPrompt_Start; // Offset: 0x598 | Size: 0x8
	struct UUI_Lobby_Mate_C* UI_Lobby_Mate; // Offset: 0x5a0 | Size: 0x8
	struct UUI_Rank_Icon_C* UI_Rank_Icon; // Offset: 0x5a8 | Size: 0x8
	struct UWidgetSwitcher* WidgetSwitcher_Activity; // Offset: 0x5b0 | Size: 0x8
	enum class E_Lobby_StartBtn_State StartBtn; // Offset: 0x5b8 | Size: 0x1
	bool PC; // Offset: 0x5b9 | Size: 0x1
	bool Ready; // Offset: 0x5ba | Size: 0x1
	bool Leader; // Offset: 0x5bb | Size: 0x1
	bool Matching; // Offset: 0x5bc | Size: 0x1

	// Functions

	// Object: DelegateFunction UI_Lobby_StartBtn_New.UI_Lobby_StartBtn_New_C.OnInputDeviceChanged_647B82329544FF31173F2F8111CE46F1
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1011445c0
	// Return & Params: [ Num(1) Size(0xc) ]
	void OnInputDeviceChanged_647B82329544FF31173F2F8111CE46F1(struct FInputDeviceProxy InputDeviceProxy);

	// Object: DelegateFunction UI_Lobby_StartBtn_New.UI_Lobby_StartBtn_New_C.OnClicked_383F346B9143E26458BA9AB3A2A10939
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1011445c0
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_383F346B9143E26458BA9AB3A2A10939();

	// Object: DelegateFunction UI_Lobby_StartBtn_New.UI_Lobby_StartBtn_New_C.OnClicked_66397D713A4CDA1F17272D8040D462AC
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1011445c0
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_66397D713A4CDA1F17272D8040D462AC();

	// Object: DelegateFunction UI_Lobby_StartBtn_New.UI_Lobby_StartBtn_New_C.OnClicked_94953ECA9B4F533ADA011BAD4B379E99
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1011445c0
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_94953ECA9B4F533ADA011BAD4B379E99();

	// Object: DelegateFunction UI_Lobby_StartBtn_New.UI_Lobby_StartBtn_New_C.OnClicked_EFBF7F86D147614A5D3AC197053BC269
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1011445c0
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_EFBF7F86D147614A5D3AC197053BC269();

	// Object: DelegateFunction UI_Lobby_StartBtn_New.UI_Lobby_StartBtn_New_C.OnClicked_2CE362BF514046DF48451990A9009AB3
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1011445c0
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_2CE362BF514046DF48451990A9009AB3();

	// Object: DelegateFunction UI_Lobby_StartBtn_New.UI_Lobby_StartBtn_New_C.OnClicked_54E4F62C1B4C8AB5C5A38D8E2FACFE33
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1011445c0
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_54E4F62C1B4C8AB5C5A38D8E2FACFE33();

	// Object: DelegateFunction UI_Lobby_StartBtn_New.UI_Lobby_StartBtn_New_C.OnClicked_D774A6F232492FA79389AE9BF27AADC2
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1011445c0
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_D774A6F232492FA79389AE9BF27AADC2();

	// Object: Function UI_Lobby_StartBtn_New.UI_Lobby_StartBtn_New_C.Destruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x1011558ac
	// Return & Params: [ Num(0) Size(0x0) ]
	void Destruct();

	// Object: Function UI_Lobby_StartBtn_New.UI_Lobby_StartBtn_New_C.ReceiveTick
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x1011558ac
	// Return & Params: [ Num(2) Size(0x3c) ]
	void ReceiveTick(struct FGeometry& MyGeometry, float InDeltaTime);

	// Object: Function UI_Lobby_StartBtn_New.UI_Lobby_StartBtn_New_C.OnSolarUIClosed
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x1011558ac
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnSolarUIClosed();

	// Object: Function UI_Lobby_StartBtn_New.UI_Lobby_StartBtn_New_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x1011558ac
	// Return & Params: [ Num(0) Size(0x0) ]
	void Construct();

	// Object: Function UI_Lobby_StartBtn_New.UI_Lobby_StartBtn_New_C.OnSolarUIOpened
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x1011558ac
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnSolarUIOpened();

	// Object: Function UI_Lobby_StartBtn_New.UI_Lobby_StartBtn_New_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();

	// Object: Function UI_Lobby_StartBtn_New.UI_Lobby_StartBtn_New_C.UpdatePanelState
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(3) Size(0x3) ]
	void UpdatePanelState(bool Leader, bool Matching, bool Ready);

	// Object: Function UI_Lobby_StartBtn_New.UI_Lobby_StartBtn_New_C.UpdatePlatformBlendState
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x1) ]
	void UpdatePlatformBlendState(bool PC);

	// Object: Function UI_Lobby_StartBtn_New.UI_Lobby_StartBtn_New_C.SetStartBtn
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetStartBtn(enum class E_Lobby_StartBtn_State StartBtn);

	// Object: Function UI_Lobby_StartBtn_New.UI_Lobby_StartBtn_New_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_Lobby_StartBtn_New.UI_Lobby_StartBtn_New_C.ExecuteUbergraph_UI_Lobby_StartBtn_New
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_Lobby_StartBtn_New(int32_t EntryPoint);
};

