#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Lobby_TeamInvite_Popup.UI_Lobby_TeamInvite_Popup_C
// Inherited Bytes: 0x490 | Struct Size: 0x5f9
struct UUI_Lobby_TeamInvite_Popup_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x490 | Size: 0x8
	struct UWidgetAnimation* RightToLeft_Anim; // Offset: 0x498 | Size: 0x8
	struct USolarButton* Btn_Join_Common; // Offset: 0x4a0 | Size: 0x8
	struct UButton* Btn_Player; // Offset: 0x4a8 | Size: 0x8
	struct UButton* Btn_Player_3; // Offset: 0x4b0 | Size: 0x8
	struct USolarCheckBox* CheckBox_Type; // Offset: 0x4b8 | Size: 0x8
	struct UHorizontalBox* HorizentalBox_Spectator; // Offset: 0x4c0 | Size: 0x8
	struct UHorizontalBox* HorizontalBox_CreateRoom_Invitation; // Offset: 0x4c8 | Size: 0x8
	struct UHorizontalBox* HorizontalBox_Player; // Offset: 0x4d0 | Size: 0x8
	struct UHorizontalBox* HorizontalBox_Team_Application; // Offset: 0x4d8 | Size: 0x8
	struct UImage* Img_BG_2; // Offset: 0x4e0 | Size: 0x8
	struct UImage* Img_Btn_Join; // Offset: 0x4e8 | Size: 0x8
	struct UImage* Img_GameMode_Icon; // Offset: 0x4f0 | Size: 0x8
	struct UImage* Img_GameMode_Icon_3; // Offset: 0x4f8 | Size: 0x8
	struct UImage* Img_Join_Common_Light; // Offset: 0x500 | Size: 0x8
	struct UImage* Img_Title_Bg_2; // Offset: 0x508 | Size: 0x8
	struct UOverlay* Overlay_Avatar; // Offset: 0x510 | Size: 0x8
	struct UOverlay* Overlay_Avatar_3; // Offset: 0x518 | Size: 0x8
	struct UCanvasPanel* Panel_Info_CreateRoom_Invitation; // Offset: 0x520 | Size: 0x8
	struct UCanvasPanel* Panel_Info_Invitation; // Offset: 0x528 | Size: 0x8
	struct UCanvasPanel* Panel_Pop_Common; // Offset: 0x530 | Size: 0x8
	struct UCanvasPanel* Panel_Prompt; // Offset: 0x538 | Size: 0x8
	struct UProgressBar* ProgressBar_CountDown; // Offset: 0x540 | Size: 0x8
	struct USolarRichTextBlock* RichTxt_LvlRequired; // Offset: 0x548 | Size: 0x8
	struct UScaleBox* ScaleBox_Match; // Offset: 0x550 | Size: 0x8
	struct USolarTextBlock* Text_RemarkName; // Offset: 0x558 | Size: 0x8
	struct UHorizontalBox* Title; // Offset: 0x560 | Size: 0x8
	struct USolarTextBlock* Txt_Capacity; // Offset: 0x568 | Size: 0x8
	struct USolarTextBlock* Txt_GameMode_2; // Offset: 0x570 | Size: 0x8
	struct USolarTextBlock* Txt_GameMode_3; // Offset: 0x578 | Size: 0x8
	struct USolarTextBlock* Txt_Invitation; // Offset: 0x580 | Size: 0x8
	struct USolarTextBlock* Txt_Join_Common; // Offset: 0x588 | Size: 0x8
	struct USolarTextBlock* Txt_Map; // Offset: 0x590 | Size: 0x8
	struct USolarTextBlock* Txt_Map_2; // Offset: 0x598 | Size: 0x8
	struct UTextBlock* Txt_OBCurr; // Offset: 0x5a0 | Size: 0x8
	struct USolarTextBlock* Txt_OBTotal; // Offset: 0x5a8 | Size: 0x8
	struct USolarTextBlock* Txt_PlayerIn; // Offset: 0x5b0 | Size: 0x8
	struct USolarTextBlock* Txt_Team_Invitation_Info; // Offset: 0x5b8 | Size: 0x8
	struct USolarTextBlock* Txt_Team_Invitation_Info_2; // Offset: 0x5c0 | Size: 0x8
	struct USolarTextBlock* Txt_Title; // Offset: 0x5c8 | Size: 0x8
	struct UUI_Component_Close_C* UI_Component_Close; // Offset: 0x5d0 | Size: 0x8
	struct UUI_Component_Hover_Square_4px_C* UI_Component_Hover_Square_4px; // Offset: 0x5d8 | Size: 0x8
	struct UUI_Component_PlayerHead_C* UI_Component_PlayerHead_2; // Offset: 0x5e0 | Size: 0x8
	struct UUI_Component_PlayerHead_C* UI_Component_PlayerHead_3; // Offset: 0x5e8 | Size: 0x8
	struct UUI_Component_PlayerName_C* UI_Component_PlayerName; // Offset: 0x5f0 | Size: 0x8
	enum class T_Type_Invitation Pop_Type; // Offset: 0x5f8 | Size: 0x1

	// Functions

	// Object: DelegateFunction UI_Lobby_TeamInvite_Popup.UI_Lobby_TeamInvite_Popup_C.OnCheckStateChanged_5BD6609E0A45593949384BAADF5E8834
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1011445c0
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnCheckStateChanged_5BD6609E0A45593949384BAADF5E8834(bool bIsChecked);

	// Object: Function UI_Lobby_TeamInvite_Popup.UI_Lobby_TeamInvite_Popup_C.OnClicked_80ED60D5F3421EF7BC52DF8D03C442FA
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	// Offset: 0x1011445c0
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_80ED60D5F3421EF7BC52DF8D03C442FA();

	// Object: DelegateFunction UI_Lobby_TeamInvite_Popup.UI_Lobby_TeamInvite_Popup_C.OnClicked_05AB5EF03E47B72F6E04F787F1E7C776
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1011445c0
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_05AB5EF03E47B72F6E04F787F1E7C776();

	// Object: Function UI_Lobby_TeamInvite_Popup.UI_Lobby_TeamInvite_Popup_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x1011558ac
	// Return & Params: [ Num(0) Size(0x0) ]
	void Construct();

	// Object: Function UI_Lobby_TeamInvite_Popup.UI_Lobby_TeamInvite_Popup_C.Destruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x1011558ac
	// Return & Params: [ Num(0) Size(0x0) ]
	void Destruct();

	// Object: Function UI_Lobby_TeamInvite_Popup.UI_Lobby_TeamInvite_Popup_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();

	// Object: Function UI_Lobby_TeamInvite_Popup.UI_Lobby_TeamInvite_Popup_C.SetDownBG
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetDownBG(enum class T_Type_Invitation Type);

	// Object: Function UI_Lobby_TeamInvite_Popup.UI_Lobby_TeamInvite_Popup_C.SetType
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetType(enum class T_Type_Invitation Pop_Type);

	// Object: Function UI_Lobby_TeamInvite_Popup.UI_Lobby_TeamInvite_Popup_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_Lobby_TeamInvite_Popup.UI_Lobby_TeamInvite_Popup_C.ExecuteUbergraph_UI_Lobby_TeamInvite_Popup
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_Lobby_TeamInvite_Popup(int32_t EntryPoint);
};

