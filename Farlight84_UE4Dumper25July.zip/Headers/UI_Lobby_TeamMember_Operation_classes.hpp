#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C
// Inherited Bytes: 0x490 | Struct Size: 0x590
struct UUI_Lobby_TeamMember_Operation_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x490 | Size: 0x8
	struct UWidgetAnimation* Anim_Ping_Hover; // Offset: 0x498 | Size: 0x8
	struct UWidgetAnimation* Anim_Ready; // Offset: 0x4a0 | Size: 0x8
	struct USolarMenuButton* Btn_HoverPing; // Offset: 0x4a8 | Size: 0x8
	struct USolarButton* Btn_QuitTeam; // Offset: 0x4b0 | Size: 0x8
	struct USolarButton* Btn_ShowOperationPanel; // Offset: 0x4b8 | Size: 0x8
	struct UCanvasPanel* CanvasPanel_Ping; // Offset: 0x4c0 | Size: 0x8
	struct UUI_Component_Hover_Square_3px_C* Hover_OpenCard; // Offset: 0x4c8 | Size: 0x8
	struct UUI_Component_Hover_Square_3px_C* Hover_QuitTeam; // Offset: 0x4d0 | Size: 0x8
	struct UImage* Img_AppDeactivated_Mark; // Offset: 0x4d8 | Size: 0x8
	struct UImage* Img_NameColor; // Offset: 0x4e0 | Size: 0x8
	struct UImage* Img_OpenCard; // Offset: 0x4e8 | Size: 0x8
	struct UImage* Img_OpenCardBg; // Offset: 0x4f0 | Size: 0x8
	struct UImage* Img_Ping; // Offset: 0x4f8 | Size: 0x8
	struct UHorizontalBox* Img_Ready_Mark; // Offset: 0x500 | Size: 0x8
	struct UOverlay* Overlay_Vip; // Offset: 0x508 | Size: 0x8
	struct UHorizontalBox* Panel_Captain; // Offset: 0x510 | Size: 0x8
	struct UOverlay* Panel_OpenCard; // Offset: 0x518 | Size: 0x8
	struct USizeBox* SizeBox_PingTips; // Offset: 0x520 | Size: 0x8
	struct USizeBox* SizeBox_Wave; // Offset: 0x528 | Size: 0x8
	struct UWidgetSwitcher* Switcher_Preparation; // Offset: 0x530 | Size: 0x8
	struct UUI_Lobby_TeamMember_Tips_C* TeamMember_Tips; // Offset: 0x538 | Size: 0x8
	struct USolarTextBlock* Text_NickName; // Offset: 0x540 | Size: 0x8
	struct USolarTextBlock* Txt_Captain; // Offset: 0x548 | Size: 0x8
	struct UUI_Chat_Wave_C* UI_Chat_Wave; // Offset: 0x550 | Size: 0x8
	struct UUI_Component_Platform_C* UI_Component_Platform; // Offset: 0x558 | Size: 0x8
	struct UUI_Component_PlayerName_C* UI_Component_PlayerName; // Offset: 0x560 | Size: 0x8
	struct UUI_Rank_Icon_Small_C* UI_Rank_Icon_Small; // Offset: 0x568 | Size: 0x8
	struct UUI_Resident_Ping_C* UI_Resident_Ping; // Offset: 0x570 | Size: 0x8
	struct UUI_Vip_Icon_Type_C* UI_Vip_Icon_Type; // Offset: 0x578 | Size: 0x8
	int32_t IndexInLobby; // Offset: 0x580 | Size: 0x4
	bool Steam; // Offset: 0x584 | Size: 0x1
	enum class E_Type_State_Button StatePlayernameHD; // Offset: 0x585 | Size: 0x1
	enum class E_Type_State_Button StateQuitHD; // Offset: 0x586 | Size: 0x1
	bool IsHD; // Offset: 0x587 | Size: 0x1
	bool IsHighlight; // Offset: 0x588 | Size: 0x1
	char pad_0x589[0x3]; // Offset: 0x589 | Size: 0x3
	int32_t Num; // Offset: 0x58c | Size: 0x4

	// Functions

	// Object: DelegateFunction UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.OnCloseMenuEntry_6696FBC1EC4DDCC02C778C8581DF6ED0
	// Flags: [Public|Delegate]
	// Offset: 0x1011445c0
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnCloseMenuEntry_6696FBC1EC4DDCC02C778C8581DF6ED0();

	// Object: DelegateFunction UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.OnOpenMenuEntry_2F7A30F5624094AA8E2919B3B5AE9584
	// Flags: [Public|Delegate]
	// Offset: 0x1011445c0
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UWidget* OnOpenMenuEntry_2F7A30F5624094AA8E2919B3B5AE9584();

	// Object: DelegateFunction UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.OnCloseMenuEntry_A4997930AB4EA7E4B0BC2A8B3122B042
	// Flags: [Public|Delegate]
	// Offset: 0x1011445c0
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnCloseMenuEntry_A4997930AB4EA7E4B0BC2A8B3122B042();

	// Object: DelegateFunction UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.OnOpenMenuEntry_77F887B50941D0C63231F0AAD04C8B8D
	// Flags: [Public|Delegate]
	// Offset: 0x1011445c0
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UWidget* OnOpenMenuEntry_77F887B50941D0C63231F0AAD04C8B8D();

	// Object: DelegateFunction UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.OnCloseMenuEntry_A77C77DCB94BA6C0736E6797453CE945
	// Flags: [Public|Delegate]
	// Offset: 0x1011445c0
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnCloseMenuEntry_A77C77DCB94BA6C0736E6797453CE945();

	// Object: DelegateFunction UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.OnOpenMenuEntry_9257B88A9C4E453DEA1C599B3CB75002
	// Flags: [Public|Delegate]
	// Offset: 0x1011445c0
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UWidget* OnOpenMenuEntry_9257B88A9C4E453DEA1C599B3CB75002();

	// Object: DelegateFunction UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.OnCloseMenuEntry_4A8C92AE2F41169163A83BB42BCC2EEF
	// Flags: [Public|Delegate]
	// Offset: 0x1011445c0
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnCloseMenuEntry_4A8C92AE2F41169163A83BB42BCC2EEF();

	// Object: DelegateFunction UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.OnOpenMenuEntry_595480666A422BA188922EB47E8C7D7C
	// Flags: [Public|Delegate]
	// Offset: 0x1011445c0
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UWidget* OnOpenMenuEntry_595480666A422BA188922EB47E8C7D7C();

	// Object: DelegateFunction UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.OnClicked_D8CDA800A046616C18F803BDC7417B04
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1011445c0
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_D8CDA800A046616C18F803BDC7417B04();

	// Object: DelegateFunction UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.OnClicked_AC9BE2DD4640747B121083AC434B5056
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1011445c0
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_AC9BE2DD4640747B121083AC434B5056();

	// Object: DelegateFunction UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.OnClicked_F2EFBE07F44DF19B02BE639B5125B2FF
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1011445c0
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_F2EFBE07F44DF19B02BE639B5125B2FF();

	// Object: DelegateFunction UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.OnClicked_D4E09281F94CD9EB2CDAAF89805A4271
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1011445c0
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_D4E09281F94CD9EB2CDAAF89805A4271();

	// Object: DelegateFunction UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.OnClicked_22EB16939847CDE4E1F62DBBCCBEAB4B
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1011445c0
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_22EB16939847CDE4E1F62DBBCCBEAB4B();

	// Object: DelegateFunction UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.OnClicked_1115D0DBA54D62E2A00EC6B61E393E6E
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1011445c0
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_1115D0DBA54D62E2A00EC6B61E393E6E();

	// Object: DelegateFunction UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.OnClicked_6951F6184F4949FB3C103D98E78CB96C
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1011445c0
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_6951F6184F4949FB3C103D98E78CB96C();

	// Object: DelegateFunction UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.OnClicked_2E7E0C5EE54401E624ED8AB1339DB0D5
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1011445c0
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_2E7E0C5EE54401E624ED8AB1339DB0D5();

	// Object: Function UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.ConstructCopy
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void ConstructCopy();

	// Object: Function UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.Destruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x1011558ac
	// Return & Params: [ Num(0) Size(0x0) ]
	void Destruct();

	// Object: Function UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.OnInitialized
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x1011558ac
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnInitialized();

	// Object: Function UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();

	// Object: Function UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.SetPlayerPingState
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(3) Size(0x3) ]
	void SetPlayerPingState(bool IsPC, bool IsWifi, enum class E_Lobby_Ping_State PingState);

	// Object: Function UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.SetIsSelf
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetIsSelf(bool IsSelf);

	// Object: Function UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.SetNameColor
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetNameColor(int32_t Num);

	// Object: Function UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.SetHD
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetHD(bool IsHD);

	// Object: Function UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.SetStateQuitHD
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetStateQuitHD(enum class E_Type_State_Button StateQuitHD);

	// Object: Function UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.SetStatePlayernameHD
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetStatePlayernameHD(enum class E_Type_State_Button StatePlayernameHD);

	// Object: Function UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x1011558ac
	// Return & Params: [ Num(0) Size(0x0) ]
	void Construct();

	// Object: Function UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.BndEvt__Btn_ShowOperationPanel_K2Node_ComponentBoundEvent_0_OnButtonHoverEvent__DelegateSignature
	// Flags: [BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void BndEvt__Btn_ShowOperationPanel_K2Node_ComponentBoundEvent_0_OnButtonHoverEvent__DelegateSignature();

	// Object: Function UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.BndEvt__Btn_QuitTeam_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature
	// Flags: [BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void BndEvt__Btn_QuitTeam_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature();

	// Object: Function UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.BndEvt__Btn_QuitTeam_K2Node_ComponentBoundEvent_2_OnButtonHoverEvent__DelegateSignature
	// Flags: [BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void BndEvt__Btn_QuitTeam_K2Node_ComponentBoundEvent_2_OnButtonHoverEvent__DelegateSignature();

	// Object: Function UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.BndEvt__Btn_ShowOperationPanel_K2Node_ComponentBoundEvent_3_OnButtonHoverEvent__DelegateSignature
	// Flags: [BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void BndEvt__Btn_ShowOperationPanel_K2Node_ComponentBoundEvent_3_OnButtonHoverEvent__DelegateSignature();

	// Object: Function UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.BndEvt__Btn_HoverPing_K2Node_ComponentBoundEvent_4_OnButtonHoverEvent__DelegateSignature
	// Flags: [BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void BndEvt__Btn_HoverPing_K2Node_ComponentBoundEvent_4_OnButtonHoverEvent__DelegateSignature();

	// Object: Function UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.BndEvt__Btn_HoverPing_K2Node_ComponentBoundEvent_5_OnButtonHoverEvent__DelegateSignature
	// Flags: [BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void BndEvt__Btn_HoverPing_K2Node_ComponentBoundEvent_5_OnButtonHoverEvent__DelegateSignature();

	// Object: Function UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.ReceivePlatformLayout
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x1) ]
	void ReceivePlatformLayout(enum class USolarWidgetLayoutType InLayoutType);

	// Object: Function UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.ExecuteUbergraph_UI_Lobby_TeamMember_Operation
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_Lobby_TeamMember_Operation(int32_t EntryPoint);
};

