#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Lobby_TeamMember_Tips.UI_Lobby_TeamMember_Tips_C
// Inherited Bytes: 0x490 | Struct Size: 0x4a4
struct UUI_Lobby_TeamMember_Tips_C : USolarUserWidget {
	// Fields
	struct UWidgetAnimation* Anim_Tips; // Offset: 0x490 | Size: 0x8
	struct USolarTextBlock* Txt_Tips; // Offset: 0x498 | Size: 0x8
	float DurationTime; // Offset: 0x4a0 | Size: 0x4

	// Functions

	// Object: DelegateFunction UI_Lobby_TeamMember_Tips.UI_Lobby_TeamMember_Tips_C.Delegate_943D5F6DE744C81EFDD0CDB3990D120A
	// Flags: [Public|Delegate]
	// Offset: 0x1011445c0
	// Return & Params: [ Num(0) Size(0x0) ]
	void Delegate_943D5F6DE744C81EFDD0CDB3990D120A();

	// Object: DelegateFunction UI_Lobby_TeamMember_Tips.UI_Lobby_TeamMember_Tips_C.Delegate_E6E1943C8D40450292B5B589BCC62D1E
	// Flags: [Public|Delegate]
	// Offset: 0x1011445c0
	// Return & Params: [ Num(0) Size(0x0) ]
	void Delegate_E6E1943C8D40450292B5B589BCC62D1E();

	// Object: DelegateFunction UI_Lobby_TeamMember_Tips.UI_Lobby_TeamMember_Tips_C.Delegate_5DB3E4835B4832D68643508DB2FBD9B3
	// Flags: [Public|Delegate]
	// Offset: 0x1011445c0
	// Return & Params: [ Num(0) Size(0x0) ]
	void Delegate_5DB3E4835B4832D68643508DB2FBD9B3();

	// Object: DelegateFunction UI_Lobby_TeamMember_Tips.UI_Lobby_TeamMember_Tips_C.Delegate_D808301CF9462D44FD9FDDA09C965088
	// Flags: [Public|Delegate]
	// Offset: 0x1011445c0
	// Return & Params: [ Num(0) Size(0x0) ]
	void Delegate_D808301CF9462D44FD9FDDA09C965088();

	// Object: Function UI_Lobby_TeamMember_Tips.UI_Lobby_TeamMember_Tips_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x1011558ac
	// Return & Params: [ Num(0) Size(0x0) ]
	void Construct();

	// Object: Function UI_Lobby_TeamMember_Tips.UI_Lobby_TeamMember_Tips_C.Destruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x1011558ac
	// Return & Params: [ Num(0) Size(0x0) ]
	void Destruct();

	// Object: Function UI_Lobby_TeamMember_Tips.UI_Lobby_TeamMember_Tips_C.OnInitialized
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x1011558ac
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnInitialized();

	// Object: Function UI_Lobby_TeamMember_Tips.UI_Lobby_TeamMember_Tips_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();
};

