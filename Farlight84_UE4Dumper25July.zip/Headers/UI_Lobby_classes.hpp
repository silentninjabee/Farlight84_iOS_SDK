#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Lobby.UI_Lobby_C
// Inherited Bytes: 0x4e8 | Struct Size: 0x990
struct UUI_Lobby_C : UUI_LobbyBase_C {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x4e8 | Size: 0x8
	struct UWidgetAnimation* Anim_Loop; // Offset: 0x4f0 | Size: 0x8
	struct UWidgetAnimation* Anim_Enter; // Offset: 0x4f8 | Size: 0x8
	struct UCanvasPanel* Adapter; // Offset: 0x500 | Size: 0x8
	struct USolarButton* Btn_Activity; // Offset: 0x508 | Size: 0x8
	struct UButton* Btn_Buff; // Offset: 0x510 | Size: 0x8
	struct UButton* Btn_Character; // Offset: 0x518 | Size: 0x8
	struct UButton* Btn_Clan; // Offset: 0x520 | Size: 0x8
	struct UButton* Btn_Collection; // Offset: 0x528 | Size: 0x8
	struct UButton* Btn_MailBox; // Offset: 0x530 | Size: 0x8
	struct UButton* Btn_More; // Offset: 0x538 | Size: 0x8
	struct UButton* Btn_Multimedia; // Offset: 0x540 | Size: 0x8
	struct UButton* Btn_PopupLayer; // Offset: 0x548 | Size: 0x8
	struct UButton* Btn_Raffle; // Offset: 0x550 | Size: 0x8
	struct USolarButton* Btn_Rank; // Offset: 0x558 | Size: 0x8
	struct UButton* Btn_Settings; // Offset: 0x560 | Size: 0x8
	struct USolarButton* Btn_Shop; // Offset: 0x568 | Size: 0x8
	struct UButton* Btn_Task; // Offset: 0x570 | Size: 0x8
	struct UButton* Btn_Topup; // Offset: 0x578 | Size: 0x8
	struct UBtn_Unlock_Anim_1_C* Btn_Unlock_Anim_Activity; // Offset: 0x580 | Size: 0x8
	struct UBtn_Unlock_Anim_1_C* Btn_Unlock_Anim_Clan; // Offset: 0x588 | Size: 0x8
	struct UBtn_Unlock_Anim_1_C* Btn_Unlock_Anim_Collection; // Offset: 0x590 | Size: 0x8
	struct UBtn_Unlock_Anim_1_C* Btn_Unlock_Anim_Heros; // Offset: 0x598 | Size: 0x8
	struct UBtn_Unlock_Anim_1_C* Btn_Unlock_Anim_Raffle; // Offset: 0x5a0 | Size: 0x8
	struct UBtn_Unlock_Anim_1_C* Btn_Unlock_Anim_Rank; // Offset: 0x5a8 | Size: 0x8
	struct UBtn_Unlock_Anim_1_C* Btn_Unlock_Anim_Shop; // Offset: 0x5b0 | Size: 0x8
	struct UBtn_Unlock_Anim_1_C* Btn_Unlock_Anim_SupplyBox; // Offset: 0x5b8 | Size: 0x8
	struct UBtn_Unlock_Anim_1_C* Btn_Unlock_Anim_Task; // Offset: 0x5c0 | Size: 0x8
	struct UBtn_Unlock_Anim_1_C* Btn_Unlock_Anim_Tournament; // Offset: 0x5c8 | Size: 0x8
	struct UButton* Button_CloseEmoji; // Offset: 0x5d0 | Size: 0x8
	struct USolarButton* Button_Emoji; // Offset: 0x5d8 | Size: 0x8
	struct USolarButton* Button_Emoji_Close; // Offset: 0x5e0 | Size: 0x8
	struct UCanvasPanel* CanvasPanel_Container; // Offset: 0x5e8 | Size: 0x8
	struct UUI_Component_NationalFlag_C* ClanFlag; // Offset: 0x5f0 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* DragPanel_2; // Offset: 0x5f8 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* DragPanel_3; // Offset: 0x600 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* DragPanel_4; // Offset: 0x608 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* DragPanel_5; // Offset: 0x610 | Size: 0x8
	struct UUI_Component_Emoji_List_C* Emoji_List; // Offset: 0x618 | Size: 0x8
	struct USolarCheckBox* EmojiBtn; // Offset: 0x620 | Size: 0x8
	struct UScaleBox* EmoteScaleBox_2; // Offset: 0x628 | Size: 0x8
	struct UScaleBox* EmoteScaleBox_3; // Offset: 0x630 | Size: 0x8
	struct UScaleBox* EmoteScaleBox_4; // Offset: 0x638 | Size: 0x8
	struct UScaleBox* EmoteScaleBox_5; // Offset: 0x640 | Size: 0x8
	struct USolarRedHint_General_C* HintPoint_Clan; // Offset: 0x648 | Size: 0x8
	struct USolarRedHint_General_C* HintPoint_Content; // Offset: 0x650 | Size: 0x8
	struct UImage* Img_Activity; // Offset: 0x658 | Size: 0x8
	struct UImage* Img_UnlockAnim; // Offset: 0x660 | Size: 0x8
	struct UUI_Component_LobbyDownloadBtn_C* LobbyDownloadBtn; // Offset: 0x668 | Size: 0x8
	struct UUI_TabControl_Horizontal_C* MB_Tab; // Offset: 0x670 | Size: 0x8
	struct UOverlay* Overlay_BattlePass; // Offset: 0x678 | Size: 0x8
	struct UCanvasPanel* Panel; // Offset: 0x680 | Size: 0x8
	struct UCanvasPanel* Panel_Activity; // Offset: 0x688 | Size: 0x8
	struct UCanvasPanel* Panel_ActivityContent; // Offset: 0x690 | Size: 0x8
	struct UCanvasPanel* Panel_Buff; // Offset: 0x698 | Size: 0x8
	struct UCanvasPanel* Panel_Clan; // Offset: 0x6a0 | Size: 0x8
	struct UCanvasPanel* Panel_Clan_Content; // Offset: 0x6a8 | Size: 0x8
	struct UCanvasPanel* Panel_Collection; // Offset: 0x6b0 | Size: 0x8
	struct UCanvasPanel* Panel_Collection_Content; // Offset: 0x6b8 | Size: 0x8
	struct UCanvasPanel* Panel_Commerce; // Offset: 0x6c0 | Size: 0x8
	struct UCanvasPanel* Panel_Emoji; // Offset: 0x6c8 | Size: 0x8
	struct UCanvasPanel* Panel_Heros; // Offset: 0x6d0 | Size: 0x8
	struct UCanvasPanel* Panel_Heros_Content; // Offset: 0x6d8 | Size: 0x8
	struct UCanvasPanel* Panel_Invite; // Offset: 0x6e0 | Size: 0x8
	struct UCanvasPanel* Panel_MailBox; // Offset: 0x6e8 | Size: 0x8
	struct UCanvasPanel* Panel_More; // Offset: 0x6f0 | Size: 0x8
	struct UCanvasPanel* Panel_Multimedia; // Offset: 0x6f8 | Size: 0x8
	struct UUI_TabControl_Horizontal_C* Panel_Overview; // Offset: 0x700 | Size: 0x8
	struct UCanvasPanel* Panel_Profession; // Offset: 0x708 | Size: 0x8
	struct UCanvasPanel* Panel_Raffle; // Offset: 0x710 | Size: 0x8
	struct UCanvasPanel* Panel_RaffleContent; // Offset: 0x718 | Size: 0x8
	struct UCanvasPanel* Panel_Rank; // Offset: 0x720 | Size: 0x8
	struct UCanvasPanel* Panel_Rank_Content; // Offset: 0x728 | Size: 0x8
	struct UCanvasPanel* Panel_RedPacket; // Offset: 0x730 | Size: 0x8
	struct UUI_Lobby_Season_Reward_C* Panel_Season; // Offset: 0x738 | Size: 0x8
	struct UCanvasPanel* Panel_Settings; // Offset: 0x740 | Size: 0x8
	struct UCanvasPanel* Panel_Shop; // Offset: 0x748 | Size: 0x8
	struct UCanvasPanel* Panel_Shop_Content; // Offset: 0x750 | Size: 0x8
	struct UCanvasPanel* Panel_Store; // Offset: 0x758 | Size: 0x8
	struct UCanvasPanel* Panel_Store_Content; // Offset: 0x760 | Size: 0x8
	struct UCanvasPanel* Panel_SupplyBox; // Offset: 0x768 | Size: 0x8
	struct UCanvasPanel* Panel_SupplyBox_Content; // Offset: 0x770 | Size: 0x8
	struct UHorizontalBox* Panel_System; // Offset: 0x778 | Size: 0x8
	struct UCanvasPanel* Panel_Task; // Offset: 0x780 | Size: 0x8
	struct UCanvasPanel* Panel_Task_Content; // Offset: 0x788 | Size: 0x8
	struct UUI_TabControl_Horizontal_C* Panel_Team; // Offset: 0x790 | Size: 0x8
	struct UCanvasPanel* Panel_Topup; // Offset: 0x798 | Size: 0x8
	struct UCanvasPanel* Panel_Tournament; // Offset: 0x7a0 | Size: 0x8
	struct UCanvasPanel* Panel_Tournament_Content; // Offset: 0x7a8 | Size: 0x8
	struct UCanvasPanel* Panel_Tournament_Content_2; // Offset: 0x7b0 | Size: 0x8
	struct UCanvasPanel* PopupLayer; // Offset: 0x7b8 | Size: 0x8
	struct UUI_Lobby_Profession_C* Profession_2; // Offset: 0x7c0 | Size: 0x8
	struct UUI_Lobby_Profession_C* Profession_3; // Offset: 0x7c8 | Size: 0x8
	struct UUI_Lobby_Profession_C* Profession_4; // Offset: 0x7d0 | Size: 0x8
	struct UUI_Lobby_Profession_C* Profession_5; // Offset: 0x7d8 | Size: 0x8
	struct USolarRedHint_General_C* Red_Rank; // Offset: 0x7e0 | Size: 0x8
	struct USolarRedHint_General_C* Red_Shop; // Offset: 0x7e8 | Size: 0x8
	struct USolarRedHint_General_C* RedHint_Capsulers; // Offset: 0x7f0 | Size: 0x8
	struct USolarRedHint_General_C* RedHint_Collection; // Offset: 0x7f8 | Size: 0x8
	struct USolarRedHint_General_C* RedHint_E-Mail; // Offset: 0x800 | Size: 0x8
	struct USolarRedHint_General_C* RedHint_More; // Offset: 0x808 | Size: 0x8
	struct USolarRedHint_General_C* RedHint_Multimedia; // Offset: 0x810 | Size: 0x8
	struct USolarRedHint_General_C* RedHint_Task; // Offset: 0x818 | Size: 0x8
	struct USizeBox* SizeBox_BattlePass; // Offset: 0x820 | Size: 0x8
	struct USizeBox* SizeBox_Buff; // Offset: 0x828 | Size: 0x8
	struct USizeBox* SizeBox_Commerce; // Offset: 0x830 | Size: 0x8
	struct USizeBox* SizeBox_EventBp; // Offset: 0x838 | Size: 0x8
	struct USolarRedHint_General_C* SolarRedHint_General; // Offset: 0x840 | Size: 0x8
	struct USolarRedHint_General_C* SolarRedHint_General_2; // Offset: 0x848 | Size: 0x8
	struct UUI_Lobby_TeamMember_Operation_C* TeamMember_CallingCard_2; // Offset: 0x850 | Size: 0x8
	struct UUI_Lobby_TeamMember_Operation_C* TeamMember_CallingCard_3; // Offset: 0x858 | Size: 0x8
	struct UUI_Lobby_TeamMember_Operation_C* TeamMember_CallingCard_4; // Offset: 0x860 | Size: 0x8
	struct UUI_Lobby_TeamMember_Operation_C* TeamMember_CallingCard_5; // Offset: 0x868 | Size: 0x8
	struct UTextBlock* Text_MatchInfo; // Offset: 0x870 | Size: 0x8
	struct UTextBlock* Text_RoomInfo; // Offset: 0x878 | Size: 0x8
	struct USolarTextBlock* Txt_Clan; // Offset: 0x880 | Size: 0x8
	struct USolarTextBlock* Txt_Clan_2; // Offset: 0x888 | Size: 0x8
	struct UUI_ChatPanel_C* UI_ChatPanel; // Offset: 0x890 | Size: 0x8
	struct UUI_Lobby_Banner_C* UI_Lobby_Banner; // Offset: 0x898 | Size: 0x8
	struct UUI_Lobby_Battery_C* UI_Lobby_Battery; // Offset: 0x8a0 | Size: 0x8
	struct UUI_Lobby_BattlePass_C* UI_Lobby_BattlePass; // Offset: 0x8a8 | Size: 0x8
	struct UUI_Lobby_BattlePass3_C* UI_Lobby_BattlePass3; // Offset: 0x8b0 | Size: 0x8
	struct UUI_Lobby_BattlePass_Next_C* UI_Lobby_BattlePass_Next; // Offset: 0x8b8 | Size: 0x8
	struct UUI_Currency_Bar_C* UI_Lobby_Currency; // Offset: 0x8c0 | Size: 0x8
	struct UUI_Lobby_DownLoad_C* UI_Lobby_DownLoad; // Offset: 0x8c8 | Size: 0x8
	struct UUI_Lobby_EventBp_01_C* UI_Lobby_EventBp_01; // Offset: 0x8d0 | Size: 0x8
	struct UUI_Lobby_GameRecommend_C* UI_Lobby_GameRecommend; // Offset: 0x8d8 | Size: 0x8
	struct UUI_Lobby_Invite_Btn_C* UI_Lobby_Invite_Btn_2; // Offset: 0x8e0 | Size: 0x8
	struct UUI_Lobby_Invite_Btn_C* UI_Lobby_Invite_Btn_3; // Offset: 0x8e8 | Size: 0x8
	struct UUI_Lobby_Invite_Btn_C* UI_Lobby_Invite_Btn_4; // Offset: 0x8f0 | Size: 0x8
	struct UUI_Lobby_Mainmenu_C* UI_Lobby_MainMenu; // Offset: 0x8f8 | Size: 0x8
	struct UUI_Lobby_MatchRoom_C* UI_Lobby_MatchRoom; // Offset: 0x900 | Size: 0x8
	struct UUI_Lobby_Mission_Reward_C* UI_Lobby_Mission_Reward; // Offset: 0x908 | Size: 0x8
	struct UUI_Lobby_Name_Version_Panel_C* UI_Lobby_Name_Version_Panel; // Offset: 0x910 | Size: 0x8
	struct UUI_Lobby_Ping_C* UI_Lobby_Ping; // Offset: 0x918 | Size: 0x8
	struct UUI_Lobby_PlayerInfo_C* UI_Lobby_PlayerInfo; // Offset: 0x920 | Size: 0x8
	struct UUI_Lobby_Recharge_Rebate_C* UI_Lobby_Recharge_Rebate; // Offset: 0x928 | Size: 0x8
	struct UUI_Lobby_Recommend_List_C* UI_Lobby_Recommend_List; // Offset: 0x930 | Size: 0x8
	struct UUI_Lobby_RedPacket_C* UI_Lobby_RedPacket; // Offset: 0x938 | Size: 0x8
	struct UUI_Lobby_Social_Entrance_C* UI_Lobby_Social_Entrance; // Offset: 0x940 | Size: 0x8
	struct UUI_Lobby_StartBtn_New_C* UI_Lobby_StartBtn; // Offset: 0x948 | Size: 0x8
	struct UUI_Lobby_SupplyBox_C* UI_Lobby_SupplyBox; // Offset: 0x950 | Size: 0x8
	struct UUI_Lobby_Topup_C* UI_Lobby_Topup; // Offset: 0x958 | Size: 0x8
	struct UUI_Lobby_Tournament_C* UI_Lobby_Tournament; // Offset: 0x960 | Size: 0x8
	struct UUI_Lobby_Tournament_C* UI_Lobby_Tournament_2; // Offset: 0x968 | Size: 0x8
	struct UUI_Lobby_Voice_Panel_C* UI_Lobby_Voice_Panel; // Offset: 0x970 | Size: 0x8
	struct UUI_Rank_Icon_Small_C* UI_Rank_Icon_Small; // Offset: 0x978 | Size: 0x8
	struct UTextBlock* UserId; // Offset: 0x980 | Size: 0x8
	struct UCanvasPanel* Video; // Offset: 0x988 | Size: 0x8

	// Functions

	// Object: DelegateFunction UI_Lobby.UI_Lobby_C.OnRegisterEvent_52BA50997143CDF77C99AD98901585E2
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1011445c0
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnRegisterEvent_52BA50997143CDF77C99AD98901585E2();

	// Object: DelegateFunction UI_Lobby.UI_Lobby_C.OnClicked_BA3A0627F148034BE7B72387337A2156
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1011445c0
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_BA3A0627F148034BE7B72387337A2156();

	// Object: DelegateFunction UI_Lobby.UI_Lobby_C.OnClicked_9749A268C449ACDAF14EE7AEB9BD19DB
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1011445c0
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_9749A268C449ACDAF14EE7AEB9BD19DB();

	// Object: DelegateFunction UI_Lobby.UI_Lobby_C.OnClicked_7279ABFFD64F42F2AB4056997B565907
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1011445c0
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_7279ABFFD64F42F2AB4056997B565907();

	// Object: DelegateFunction UI_Lobby.UI_Lobby_C.OnClicked_C47F09B8ED481FD22BBAC5A2F2609E73
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1011445c0
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_C47F09B8ED481FD22BBAC5A2F2609E73();

	// Object: DelegateFunction UI_Lobby.UI_Lobby_C.OnClicked_B2965CAE4F4A454099D23C9AA7248916
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1011445c0
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_B2965CAE4F4A454099D23C9AA7248916();

	// Object: DelegateFunction UI_Lobby.UI_Lobby_C.OnClicked_534CB70E5A45CCC5FF2079A7E73A29E6
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1011445c0
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_534CB70E5A45CCC5FF2079A7E73A29E6();

	// Object: DelegateFunction UI_Lobby.UI_Lobby_C.OnClicked_378AE00AB048476A21EE069EE37D942F
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1011445c0
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_378AE00AB048476A21EE069EE37D942F();

	// Object: DelegateFunction UI_Lobby.UI_Lobby_C.OnClicked_1D7C525B5945553F21453F872CAE1A79
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1011445c0
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_1D7C525B5945553F21453F872CAE1A79();

	// Object: DelegateFunction UI_Lobby.UI_Lobby_C.OnBrowserClosed_550ACD18874429EE4F48B48CC31C46CC
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1011445c0
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnBrowserClosed_550ACD18874429EE4F48B48CC31C46CC();

	// Object: DelegateFunction UI_Lobby.UI_Lobby_C.OnClicked_3533CF17194EED564DF4CC9C8ED04CA0
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1011445c0
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_3533CF17194EED564DF4CC9C8ED04CA0();

	// Object: DelegateFunction UI_Lobby.UI_Lobby_C.OnClicked_1E9ED153B948E870F181A9BA91BEB287
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1011445c0
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_1E9ED153B948E870F181A9BA91BEB287();

	// Object: DelegateFunction UI_Lobby.UI_Lobby_C.OnClicked_1CA38D83354D3A863FF58DAB95F3C2DF
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1011445c0
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_1CA38D83354D3A863FF58DAB95F3C2DF();

	// Object: DelegateFunction UI_Lobby.UI_Lobby_C.OnClicked_153AB2D7BD4537595A1308BF661EFAA9
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1011445c0
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_153AB2D7BD4537595A1308BF661EFAA9();

	// Object: DelegateFunction UI_Lobby.UI_Lobby_C.OnClicked_4999FAB52C48FB2099C98B8BAB116498
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1011445c0
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_4999FAB52C48FB2099C98B8BAB116498();

	// Object: DelegateFunction UI_Lobby.UI_Lobby_C.OnClicked_2924E79AD74E3F881DD5429EE1BE19D3
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1011445c0
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_2924E79AD74E3F881DD5429EE1BE19D3();

	// Object: DelegateFunction UI_Lobby.UI_Lobby_C.OnClicked_4376D2A79F4755C702A7849C3B0A534A
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1011445c0
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_4376D2A79F4755C702A7849C3B0A534A();

	// Object: DelegateFunction UI_Lobby.UI_Lobby_C.OnClicked_0028DA4FA345FD58C6386A84BC6A91C2
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1011445c0
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_0028DA4FA345FD58C6386A84BC6A91C2();

	// Object: DelegateFunction UI_Lobby.UI_Lobby_C.OnClicked_EB7A90143E43D4EAE66175B836AB3192
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1011445c0
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_EB7A90143E43D4EAE66175B836AB3192();

	// Object: DelegateFunction UI_Lobby.UI_Lobby_C.OnClicked_4A5A57E9DB4E5B5F0146D087D3F37DC0
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1011445c0
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_4A5A57E9DB4E5B5F0146D087D3F37DC0();

	// Object: DelegateFunction UI_Lobby.UI_Lobby_C.OnClicked_65723656904EC36E2AB64AB1BF62A16E
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1011445c0
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_65723656904EC36E2AB64AB1BF62A16E();

	// Object: DelegateFunction UI_Lobby.UI_Lobby_C.OnClicked_CC33E53DE1418A07B5C60EA70D747D0C
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1011445c0
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_CC33E53DE1418A07B5C60EA70D747D0C();

	// Object: DelegateFunction UI_Lobby.UI_Lobby_C.OnClicked_DAED5F4AAF4E18B9E99AD48D80EC841A
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1011445c0
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_DAED5F4AAF4E18B9E99AD48D80EC841A();

	// Object: Function UI_Lobby.UI_Lobby_C.OnAnimationFinished
	// Flags: [BlueprintCosmetic|Native|Event|Protected|BlueprintEvent]
	// Offset: 0x1011558ac
	// Return & Params: [ Num(1) Size(0x8) ]
	void OnAnimationFinished(struct UWidgetAnimation* Animation);

	// Object: Function UI_Lobby.UI_Lobby_C.OnHide
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x1011558ac
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnHide();

	// Object: Function UI_Lobby.UI_Lobby_C.OnBackKey
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x1011558ac
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnBackKey(enum class EWidgetBackKeyType BackKeyType);

	// Object: Function UI_Lobby.UI_Lobby_C.Destruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x1011558ac
	// Return & Params: [ Num(0) Size(0x0) ]
	void Destruct();

	// Object: Function UI_Lobby.UI_Lobby_C.OnSolarUIClosed
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x1011558ac
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnSolarUIClosed();

	// Object: Function UI_Lobby.UI_Lobby_C.OnInitialized
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x1011558ac
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnInitialized();

	// Object: Function UI_Lobby.UI_Lobby_C.ConstructCopy
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void ConstructCopy();

	// Object: Function UI_Lobby.UI_Lobby_C.OnShow
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x1011558ac
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnShow();

	// Object: Function UI_Lobby.UI_Lobby_C.OnSolarUIOpened
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x1011558ac
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnSolarUIOpened();

	// Object: Function UI_Lobby.UI_Lobby_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();

	// Object: Function UI_Lobby.UI_Lobby_C.Widget_3_NavigateCustom
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(3) Size(0x18) ]
	void Widget_3_NavigateCustom(enum class EUINavigation Direction, struct UWidget* FromWidget, struct UWidget*& OutWidget);

	// Object: Function UI_Lobby.UI_Lobby_C.Widget_3_Navigate
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UWidget* Widget_3_Navigate(enum class EUINavigation Navigation);

	// Object: Function UI_Lobby.UI_Lobby_C.Widget_2_CanNavigate
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(4) Size(0x19) ]
	void Widget_2_CanNavigate(enum class EUINavigation Direction, struct UWidget* FromWidget, struct UWidget* ToWidget, bool& CanNavigate);

	// Object: Function UI_Lobby.UI_Lobby_C.Widget_2_NavigateCustom
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(3) Size(0x18) ]
	void Widget_2_NavigateCustom(enum class EUINavigation Direction, struct UWidget* FromWidget, struct UWidget*& OutWidget);

	// Object: Function UI_Lobby.UI_Lobby_C.Widget_2_Navigate
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UWidget* Widget_2_Navigate(enum class EUINavigation Navigation);

	// Object: Function UI_Lobby.UI_Lobby_C.Widget_3_CanNavigate
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(4) Size(0x19) ]
	void Widget_3_CanNavigate(enum class EUINavigation Direction, struct UWidget* FromWidget, struct UWidget* ToWidget, bool& CanNavigate);

	// Object: Function UI_Lobby.UI_Lobby_C.Widget_1_NavigateCustom
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(3) Size(0x18) ]
	void Widget_1_NavigateCustom(enum class EUINavigation Direction, struct UWidget* FromWidget, struct UWidget*& OutWidget);

	// Object: Function UI_Lobby.UI_Lobby_C.Widget_1_Navigate
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UWidget* Widget_1_Navigate(enum class EUINavigation Navigation);

	// Object: Function UI_Lobby.UI_Lobby_C.Widget_0_CanNavigate
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(4) Size(0x19) ]
	void Widget_0_CanNavigate(enum class EUINavigation Direction, struct UWidget* FromWidget, struct UWidget* ToWidget, bool& CanNavigate);

	// Object: Function UI_Lobby.UI_Lobby_C.Widget_0_NavigateCustom
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(3) Size(0x18) ]
	void Widget_0_NavigateCustom(enum class EUINavigation Direction, struct UWidget* FromWidget, struct UWidget*& OutWidget);

	// Object: Function UI_Lobby.UI_Lobby_C.Widget_0_Navigate
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UWidget* Widget_0_Navigate(enum class EUINavigation Navigation);

	// Object: Function UI_Lobby.UI_Lobby_C.Widget_1_CanNavigate
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(4) Size(0x19) ]
	void Widget_1_CanNavigate(enum class EUINavigation Direction, struct UWidget* FromWidget, struct UWidget* ToWidget, bool& CanNavigate);

	// Object: Function UI_Lobby.UI_Lobby_C.SetLevel
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetLevel(int32_t Level);

	// Object: Function UI_Lobby.UI_Lobby_C.GetAnimTargetLocation
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(3) Size(0x18) ]
	void GetAnimTargetLocation(struct UWidget* TargetObject, struct UWidget* UserObject, struct FVector2D& TargetLocation);

	// Object: Function UI_Lobby.UI_Lobby_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_Lobby.UI_Lobby_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x1011558ac
	// Return & Params: [ Num(0) Size(0x0) ]
	void Construct();

	// Object: Function UI_Lobby.UI_Lobby_C.ReceiveShow
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void ReceiveShow();

	// Object: Function UI_Lobby.UI_Lobby_C.ExecuteUbergraph_UI_Lobby
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_Lobby(int32_t EntryPoint);
};

