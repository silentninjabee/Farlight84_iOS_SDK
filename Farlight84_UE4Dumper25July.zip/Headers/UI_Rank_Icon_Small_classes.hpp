#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Rank_Icon_Small.UI_Rank_Icon_Small_C
// Inherited Bytes: 0x490 | Struct Size: 0x4ec
struct UUI_Rank_Icon_Small_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x490 | Size: 0x8
	struct UImage* Img_Rank; // Offset: 0x498 | Size: 0x8
	struct UImage* Img_Rank_Word; // Offset: 0x4a0 | Size: 0x8
	struct UImage* Img_TxtBg_2; // Offset: 0x4a8 | Size: 0x8
	struct USizeBox* Size_Rank; // Offset: 0x4b0 | Size: 0x8
	struct USizeBox* Size_Txt; // Offset: 0x4b8 | Size: 0x8
	struct USolarTextBlock* TextBlock_StarNum; // Offset: 0x4c0 | Size: 0x8
	struct USolarTextBlock* Txt_LegendRank; // Offset: 0x4c8 | Size: 0x8
	struct UWidgetSwitcher* WidgetSwitcher_Detail; // Offset: 0x4d0 | Size: 0x8
	int32_t LevelID; // Offset: 0x4d8 | Size: 0x4
	bool Star; // Offset: 0x4dc | Size: 0x1
	char pad_0x4DD[0x3]; // Offset: 0x4dd | Size: 0x3
	int32_t IconSize; // Offset: 0x4e0 | Size: 0x4
	struct FVector2D TxtSize; // Offset: 0x4e4 | Size: 0x8

	// Functions

	// Object: Function UI_Rank_Icon_Small.UI_Rank_Icon_Small_C.OnSolarUIOpened
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x1011558ac
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnSolarUIOpened();

	// Object: Function UI_Rank_Icon_Small.UI_Rank_Icon_Small_C.OnInitialized
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x1011558ac
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnInitialized();

	// Object: Function UI_Rank_Icon_Small.UI_Rank_Icon_Small_C.FormatViewCopy
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x4) ]
	void FormatViewCopy(int32_t LevelID);

	// Object: Function UI_Rank_Icon_Small.UI_Rank_Icon_Small_C.OnSolarUIClosed
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x1011558ac
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnSolarUIClosed();

	// Object: Function UI_Rank_Icon_Small.UI_Rank_Icon_Small_C.FormatViewJustIconCopy
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x4) ]
	void FormatViewJustIconCopy(int32_t LevelID);

	// Object: Function UI_Rank_Icon_Small.UI_Rank_Icon_Small_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();

	// Object: Function UI_Rank_Icon_Small.UI_Rank_Icon_Small_C.FormatViewJustIcon
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x1011558ac
	// Return & Params: [ Num(1) Size(0x4) ]
	void FormatViewJustIcon(int32_t LevelID);

	// Object: Function UI_Rank_Icon_Small.UI_Rank_Icon_Small_C.SetStar
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetStar(bool Star);

	// Object: Function UI_Rank_Icon_Small.UI_Rank_Icon_Small_C.FormatView
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x1011558ac
	// Return & Params: [ Num(1) Size(0x4) ]
	void FormatView(int32_t LevelID);

	// Object: Function UI_Rank_Icon_Small.UI_Rank_Icon_Small_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_Rank_Icon_Small.UI_Rank_Icon_Small_C.SetRankIconView
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetRankIconView(int32_t Param);

	// Object: Function UI_Rank_Icon_Small.UI_Rank_Icon_Small_C.ExecuteUbergraph_UI_Rank_Icon_Small
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_Rank_Icon_Small(int32_t EntryPoint);
};

