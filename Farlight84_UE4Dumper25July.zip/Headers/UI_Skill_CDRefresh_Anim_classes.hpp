#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Skill_CDRefresh_Anim.UI_Skill_CDRefresh_Anim_C
// Inherited Bytes: 0x260 | Struct Size: 0x29c
struct UUI_Skill_CDRefresh_Anim_C : UUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x260 | Size: 0x8
	struct UWidgetAnimation* Refresh_Anim; // Offset: 0x268 | Size: 0x8
	struct UImage* MI_Glow; // Offset: 0x270 | Size: 0x8
	struct UImage* MI_RingGlow_2; // Offset: 0x278 | Size: 0x8
	struct USizeBox* SizeBox_1; // Offset: 0x280 | Size: 0x8
	float Size; // Offset: 0x288 | Size: 0x4
	struct FLinearColor Color; // Offset: 0x28c | Size: 0x10

	// Functions

	// Object: Function UI_Skill_CDRefresh_Anim.UI_Skill_CDRefresh_Anim_C.SetColor
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetColor(struct FLinearColor Color);

	// Object: Function UI_Skill_CDRefresh_Anim.UI_Skill_CDRefresh_Anim_C.Play
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void Play();

	// Object: Function UI_Skill_CDRefresh_Anim.UI_Skill_CDRefresh_Anim_C.RefreshColor
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void RefreshColor();

	// Object: Function UI_Skill_CDRefresh_Anim.UI_Skill_CDRefresh_Anim_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_Skill_CDRefresh_Anim.UI_Skill_CDRefresh_Anim_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(0) Size(0x0) ]
	void Construct();

	// Object: Function UI_Skill_CDRefresh_Anim.UI_Skill_CDRefresh_Anim_C.ExecuteUbergraph_UI_Skill_CDRefresh_Anim
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_Skill_CDRefresh_Anim(int32_t EntryPoint);
};

