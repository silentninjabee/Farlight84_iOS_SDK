#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_TeamInvite_Container.UI_TeamInvite_Container_C
// Inherited Bytes: 0x490 | Struct Size: 0x4b8
struct UUI_TeamInvite_Container_C : USolarUserWidget {
	// Fields
	struct UCanvasPanel* Adapter; // Offset: 0x490 | Size: 0x8
	struct UCanvasPanel* CanvasPanel_Container; // Offset: 0x498 | Size: 0x8
	struct UCanvasPanel* Panel; // Offset: 0x4a0 | Size: 0x8
	struct UUI_Lobby_RoomInvite_MIni_Popup_C* UI_Lobby_RoomInvite_MIni_Popup; // Offset: 0x4a8 | Size: 0x8
	struct UUI_Lobby_TeamInvite_Mini_Popup_C* UI_Lobby_TeamInvite_MIni_Popup; // Offset: 0x4b0 | Size: 0x8

	// Functions

	// Object: Function UI_TeamInvite_Container.UI_TeamInvite_Container_C.OnShow
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x1011558ac
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnShow();

	// Object: Function UI_TeamInvite_Container.UI_TeamInvite_Container_C.OnSolarUIOpened
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x1011558ac
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnSolarUIOpened();

	// Object: Function UI_TeamInvite_Container.UI_TeamInvite_Container_C.OnInitialized
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x1011558ac
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnInitialized();

	// Object: Function UI_TeamInvite_Container.UI_TeamInvite_Container_C.OnSolarUIClosed
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x1011558ac
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnSolarUIClosed();

	// Object: Function UI_TeamInvite_Container.UI_TeamInvite_Container_C.OnHide
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x1011558ac
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnHide();

	// Object: Function UI_TeamInvite_Container.UI_TeamInvite_Container_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x101f0eef4
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();
};

