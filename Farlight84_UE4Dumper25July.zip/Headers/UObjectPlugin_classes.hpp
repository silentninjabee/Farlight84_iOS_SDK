#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class UObjectPlugin.MyPluginObject
// Inherited Bytes: 0x28 | Struct Size: 0x38
struct UMyPluginObject : UObject {
	// Fields
	struct FMyPluginStruct MyStruct; // Offset: 0x28 | Size: 0x10
};

