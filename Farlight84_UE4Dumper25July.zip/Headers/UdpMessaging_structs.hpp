#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct UdpMessaging.UdpMockMessage
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FUdpMockMessage {
	// Fields
	struct TArray<char> Data; // Offset: 0x0 | Size: 0x10
};

