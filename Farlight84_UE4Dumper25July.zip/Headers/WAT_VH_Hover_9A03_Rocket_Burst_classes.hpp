#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass WAT_VH_Hover_9A03_Rocket_Burst.WAT_VH_Hover_9A03_Rocket_Burst_C
// Inherited Bytes: 0xe8 | Struct Size: 0xe8
struct UWAT_VH_Hover_9A03_Rocket_Burst_C : USolarWeaponAT_FireBurst {
};

