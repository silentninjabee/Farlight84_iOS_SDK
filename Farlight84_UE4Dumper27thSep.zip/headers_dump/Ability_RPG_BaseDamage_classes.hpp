#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass Ability_RPG_BaseDamage.Ability_RPG_BaseDamage_C
// Size: 0x3b8 // Inherited bytes: 0x3b0
struct AAbility_RPG_BaseDamage_C : AWeaponAbilityBase {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x3b0 // Size: 0x08

	// Functions

	// Object Name: Function Ability_RPG_BaseDamage.Ability_RPG_BaseDamage_C.OnLoaded_F1E8D1D244089792BF00E29440E0F852
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnLoaded_F1E8D1D244089792BF00E29440E0F852(struct UObject* Loaded); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Ability_RPG_BaseDamage.Ability_RPG_BaseDamage_C.ReceiveBeginPlay
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveBeginPlay(); // Offset: 0x103339bc4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Ability_RPG_BaseDamage.Ability_RPG_BaseDamage_C.ExecuteUbergraph_Ability_RPG_BaseDamage
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_Ability_RPG_BaseDamage(int32_t EntryPoint); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x4)
};

