#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass Ability_Rifle_EMphy03_BaseDamage.Ability_Rifle_EMphy03_BaseDamage_C
// Size: 0x318 // Inherited bytes: 0x310
struct AAbility_Rifle_EMphy03_BaseDamage_C : ASolarAbility {
	// Fields
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x310 // Size: 0x08
};

