#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass Ability_VH_Hover_WL04_StickyBomb_Explode.Ability_VH_Hover_WL04_StickyBomb_Explode_C
// Size: 0x320 // Inherited bytes: 0x310
struct AAbility_VH_Hover_WL04_StickyBomb_Explode_C : ASolarAbility {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x310 // Size: 0x08
	struct UParticleSystemComponent* FX_Hover_WL04_Hit; // Offset: 0x318 // Size: 0x08

	// Functions

	// Object Name: Function Ability_VH_Hover_WL04_StickyBomb_Explode.Ability_VH_Hover_WL04_StickyBomb_Explode_C.ReceiveBeginPlay
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveBeginPlay(); // Offset: 0x103339bc4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Ability_VH_Hover_WL04_StickyBomb_Explode.Ability_VH_Hover_WL04_StickyBomb_Explode_C.ExecuteUbergraph_Ability_VH_Hover_WL04_StickyBomb_Explode
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_Ability_VH_Hover_WL04_StickyBomb_Explode(int32_t EntryPoint); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x4)
};

