#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class AnimGraphRuntime.AnimSequencerInstance
// Size: 0x270 // Inherited bytes: 0x270
struct UAnimSequencerInstance : UAnimInstance {
};

// Object Name: Class AnimGraphRuntime.AnimNotify_PlayMontageNotify
// Size: 0x40 // Inherited bytes: 0x38
struct UAnimNotify_PlayMontageNotify : UAnimNotify {
	// Fields
	struct FName NotifyName; // Offset: 0x38 // Size: 0x08
};

// Object Name: Class AnimGraphRuntime.AnimNotify_PlayMontageNotifyWindow
// Size: 0x38 // Inherited bytes: 0x30
struct UAnimNotify_PlayMontageNotifyWindow : UAnimNotifyState {
	// Fields
	struct FName NotifyName; // Offset: 0x2c // Size: 0x08
};

// Object Name: Class AnimGraphRuntime.KismetAnimationLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct UKismetAnimationLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function AnimGraphRuntime.KismetAnimationLibrary.K2_TwoBoneIK
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	void K2_TwoBoneIK(struct FVector& RootPos, struct FVector& JointPos, struct FVector& EndPos, struct FVector& JointTarget, struct FVector& Effector, struct FVector& OutJointPos, struct FVector& OutEndPos, bool bAllowStretching, float StartStretchRatio, float MaxStretchScale); // Offset: 0x1041a4914 // Return & Params: Num(10) Size(0x60)

	// Object Name: Function AnimGraphRuntime.KismetAnimationLibrary.K2_StartProfilingTimer
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void K2_StartProfilingTimer(); // Offset: 0x1041a37e0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AnimGraphRuntime.KismetAnimationLibrary.K2_MakePerlinNoiseVectorAndRemap
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	struct FVector K2_MakePerlinNoiseVectorAndRemap(float X, float Y, float Z, float RangeOutMinX, float RangeOutMaxX, float RangeOutMinY, float RangeOutMaxY, float RangeOutMinZ, float RangeOutMaxZ); // Offset: 0x1041a3f5c // Return & Params: Num(10) Size(0x30)

	// Object Name: Function AnimGraphRuntime.KismetAnimationLibrary.K2_MakePerlinNoiseAndRemap
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	float K2_MakePerlinNoiseAndRemap(float Value, float RangeOutMin, float RangeOutMax); // Offset: 0x1041a3e48 // Return & Params: Num(4) Size(0x10)

	// Object Name: Function AnimGraphRuntime.KismetAnimationLibrary.K2_LookAt
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	struct FTransform K2_LookAt(struct FTransform& CurrentTransform, struct FVector& TargetPosition, struct FVector LookAtVector, bool bUseUpVector, struct FVector UpVector, float ClampConeInDegree); // Offset: 0x1041a4684 // Return & Params: Num(7) Size(0x90)

	// Object Name: Function AnimGraphRuntime.KismetAnimationLibrary.K2_EndProfilingTimer
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	float K2_EndProfilingTimer(bool bLog, struct FString LogPrefix); // Offset: 0x1041a36f4 // Return & Params: Num(3) Size(0x1c)

	// Object Name: Function AnimGraphRuntime.KismetAnimationLibrary.K2_DistanceBetweenTwoSocketsAndMapRange
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	float K2_DistanceBetweenTwoSocketsAndMapRange(struct USkeletalMeshComponent* Component, struct FName SocketOrBoneNameA, enum class ERelativeTransformSpace SocketSpaceA, struct FName SocketOrBoneNameB, enum class ERelativeTransformSpace SocketSpaceB, bool bRemapRange, float InRangeMin, float InRangeMax, float OutRangeMin, float OutRangeMax); // Offset: 0x1041a434c // Return & Params: Num(11) Size(0x34)

	// Object Name: Function AnimGraphRuntime.KismetAnimationLibrary.K2_DirectionBetweenSockets
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	struct FVector K2_DirectionBetweenSockets(struct USkeletalMeshComponent* Component, struct FName SocketOrBoneNameFrom, struct FName SocketOrBoneNameTo); // Offset: 0x1041a4234 // Return & Params: Num(4) Size(0x24)

	// Object Name: Function AnimGraphRuntime.KismetAnimationLibrary.K2_CalculateVelocityFromSockets
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	float K2_CalculateVelocityFromSockets(float DeltaSeconds, struct USkeletalMeshComponent* Component, struct FName SocketOrBoneName, struct FName ReferenceSocketOrBone, enum class ERelativeTransformSpace SocketSpace, struct FVector OffsetInBoneSpace, struct FPositionHistory& History, int32_t NumberOfSamples, float VelocityMin, float VelocityMax, enum class EEasingFuncType EasingType, struct FRuntimeFloatCurve& CustomCurve); // Offset: 0x1041a37f4 // Return & Params: Num(13) Size(0xfc)

	// Object Name: Function AnimGraphRuntime.KismetAnimationLibrary.K2_CalculateVelocityFromPositionHistory
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	float K2_CalculateVelocityFromPositionHistory(float DeltaSeconds, struct FVector Position, struct FPositionHistory& History, int32_t NumberOfSamples, float VelocityMin, float VelocityMax); // Offset: 0x1041a3c34 // Return & Params: Num(7) Size(0x50)
};

// Object Name: Class AnimGraphRuntime.PlayMontageCallbackProxy
// Size: 0xa8 // Inherited bytes: 0x28
struct UPlayMontageCallbackProxy : UObject {
	// Fields
	struct FMulticastInlineDelegate OnCompleted; // Offset: 0x28 // Size: 0x10
	struct FMulticastInlineDelegate OnBlendOut; // Offset: 0x38 // Size: 0x10
	struct FMulticastInlineDelegate OnInterrupted; // Offset: 0x48 // Size: 0x10
	struct FMulticastInlineDelegate OnNotifyBegin; // Offset: 0x58 // Size: 0x10
	struct FMulticastInlineDelegate OnNotifyEnd; // Offset: 0x68 // Size: 0x10
	char pad_0x78[0x30]; // Offset: 0x78 // Size: 0x30

	// Functions

	// Object Name: Function AnimGraphRuntime.PlayMontageCallbackProxy.OnNotifyEndReceived
	// Flags: [Final|Native|Protected|HasOutParms]
	void OnNotifyEndReceived(struct FName NotifyName, struct FBranchingPointNotifyPayload& BranchingPointNotifyPayload); // Offset: 0x1041a52bc // Return & Params: Num(2) Size(0x28)

	// Object Name: Function AnimGraphRuntime.PlayMontageCallbackProxy.OnNotifyBeginReceived
	// Flags: [Final|Native|Protected|HasOutParms]
	void OnNotifyBeginReceived(struct FName NotifyName, struct FBranchingPointNotifyPayload& BranchingPointNotifyPayload); // Offset: 0x1041a5394 // Return & Params: Num(2) Size(0x28)

	// Object Name: Function AnimGraphRuntime.PlayMontageCallbackProxy.OnMontageEnded
	// Flags: [Final|Native|Protected]
	void OnMontageEnded(struct UAnimMontage* Montage, bool bInterrupted); // Offset: 0x1041a546c // Return & Params: Num(2) Size(0x9)

	// Object Name: Function AnimGraphRuntime.PlayMontageCallbackProxy.OnMontageBlendingOut
	// Flags: [Final|Native|Protected]
	void OnMontageBlendingOut(struct UAnimMontage* Montage, bool bInterrupted); // Offset: 0x1041a5540 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function AnimGraphRuntime.PlayMontageCallbackProxy.CreateProxyObjectForPlayMontage
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UPlayMontageCallbackProxy* CreateProxyObjectForPlayMontage(struct USkeletalMeshComponent* InSkeletalMeshComponent, struct UAnimMontage* MontageToPlay, float PlayRate, float StartingPosition, struct FName StartingSection); // Offset: 0x1041a5614 // Return & Params: Num(6) Size(0x28)
};

// Object Name: Class AnimGraphRuntime.SequencerAnimationSupport
// Size: 0x28 // Inherited bytes: 0x28
struct USequencerAnimationSupport : UInterface {
};

