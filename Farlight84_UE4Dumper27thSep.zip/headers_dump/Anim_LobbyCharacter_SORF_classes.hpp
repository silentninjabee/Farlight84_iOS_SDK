#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: DynamicClass Anim_LobbyCharacter_SORF.Anim_LobbyCharacter_SORF_C
// Size: 0x6c0 // Inherited bytes: 0x6c0
struct UAnim_LobbyCharacter_SORF_C : UAnim_LobbyCharacter_Default_C {
};

