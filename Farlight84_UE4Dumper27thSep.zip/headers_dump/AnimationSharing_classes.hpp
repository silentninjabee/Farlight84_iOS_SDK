#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class AnimationSharing.AnimSharingStateInstance
// Size: 0x290 // Inherited bytes: 0x270
struct UAnimSharingStateInstance : UAnimInstance {
	// Fields
	struct UAnimSequence* AnimationToPlay; // Offset: 0x268 // Size: 0x08
	float PermutationTimeOffset; // Offset: 0x270 // Size: 0x04
	float PlayRate; // Offset: 0x274 // Size: 0x04
	bool bStateBool; // Offset: 0x278 // Size: 0x01
	struct UAnimSharingInstance* Instance; // Offset: 0x280 // Size: 0x08
	char pad_0x289[0x7]; // Offset: 0x289 // Size: 0x07

	// Functions

	// Object Name: Function AnimationSharing.AnimSharingStateInstance.GetInstancedActors
	// Flags: [Final|Native|Protected|HasOutParms|BlueprintCallable]
	void GetInstancedActors(struct TArray<struct AActor*>& Actors); // Offset: 0x101e8a70c // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class AnimationSharing.AnimSharingTransitionInstance
// Size: 0x280 // Inherited bytes: 0x270
struct UAnimSharingTransitionInstance : UAnimInstance {
	// Fields
	struct TWeakObjectPtr<struct USkeletalMeshComponent> FromComponent; // Offset: 0x268 // Size: 0x08
	struct TWeakObjectPtr<struct USkeletalMeshComponent> ToComponent; // Offset: 0x270 // Size: 0x08
	float BlendTime; // Offset: 0x278 // Size: 0x04
	bool bBlendBool; // Offset: 0x27c // Size: 0x01
};

// Object Name: Class AnimationSharing.AnimSharingAdditiveInstance
// Size: 0x280 // Inherited bytes: 0x270
struct UAnimSharingAdditiveInstance : UAnimInstance {
	// Fields
	struct TWeakObjectPtr<struct USkeletalMeshComponent> BaseComponent; // Offset: 0x268 // Size: 0x08
	struct TWeakObjectPtr<struct UAnimSequence> AdditiveAnimation; // Offset: 0x270 // Size: 0x08
	float Alpha; // Offset: 0x278 // Size: 0x04
	bool bStateBool; // Offset: 0x27c // Size: 0x01
};

// Object Name: Class AnimationSharing.AnimSharingInstance
// Size: 0x138 // Inherited bytes: 0x28
struct UAnimSharingInstance : UObject {
	// Fields
	struct TArray<struct AActor*> RegisteredActors; // Offset: 0x28 // Size: 0x10
	char pad_0x38[0x70]; // Offset: 0x38 // Size: 0x70
	struct UAnimationSharingStateProcessor* StateProcessor; // Offset: 0xa8 // Size: 0x08
	char pad_0xB0[0x38]; // Offset: 0xb0 // Size: 0x38
	struct TArray<struct UAnimSequence*> UsedAnimationSequences; // Offset: 0xe8 // Size: 0x10
	char pad_0xF8[0x10]; // Offset: 0xf8 // Size: 0x10
	struct UEnum* StateEnum; // Offset: 0x108 // Size: 0x08
	struct AActor* SharingActor; // Offset: 0x110 // Size: 0x08
	char pad_0x118[0x20]; // Offset: 0x118 // Size: 0x20
};

// Object Name: Class AnimationSharing.AnimationSharingManager
// Size: 0x88 // Inherited bytes: 0x28
struct UAnimationSharingManager : UObject {
	// Fields
	struct TArray<struct USkeleton*> Skeletons; // Offset: 0x28 // Size: 0x10
	struct TArray<struct UAnimSharingInstance*> PerSkeletonData; // Offset: 0x38 // Size: 0x10
	char pad_0x48[0x40]; // Offset: 0x48 // Size: 0x40

	// Functions

	// Object Name: Function AnimationSharing.AnimationSharingManager.RegisterActorWithSkeletonBP
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RegisterActorWithSkeletonBP(struct AActor* InActor, struct USkeleton* SharingSkeleton); // Offset: 0x101e8b56c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function AnimationSharing.AnimationSharingManager.GetAnimationSharingManager
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UAnimationSharingManager* GetAnimationSharingManager(struct UObject* WorldContextObject); // Offset: 0x101e8b6fc // Return & Params: Num(2) Size(0x10)

	// Object Name: Function AnimationSharing.AnimationSharingManager.CreateAnimationSharingManager
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool CreateAnimationSharingManager(struct UObject* WorldContextObject, struct UAnimationSharingSetup* Setup); // Offset: 0x101e8b634 // Return & Params: Num(3) Size(0x11)

	// Object Name: Function AnimationSharing.AnimationSharingManager.AnimationSharingEnabled
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	bool AnimationSharingEnabled(); // Offset: 0x101e8b538 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class AnimationSharing.AnimationSharingSetup
// Size: 0x48 // Inherited bytes: 0x28
struct UAnimationSharingSetup : UObject {
	// Fields
	struct TArray<struct FPerSkeletonAnimationSharingSetup> SkeletonSetups; // Offset: 0x28 // Size: 0x10
	struct FAnimationSharingScalability ScalabilitySettings; // Offset: 0x38 // Size: 0x10
};

// Object Name: Class AnimationSharing.AnimationSharingStateProcessor
// Size: 0x50 // Inherited bytes: 0x28
struct UAnimationSharingStateProcessor : UObject {
	// Fields
	struct TSoftObjectPtr<UEnum> AnimationStateEnum; // Offset: 0x28 // Size: 0x28

	// Functions

	// Object Name: Function AnimationSharing.AnimationSharingStateProcessor.ProcessActorState
	// Flags: [Native|Event|Public|HasOutParms|BlueprintEvent]
	void ProcessActorState(int32_t& OutState, struct AActor* InActor, char CurrentState, char OnDemandState, bool& bShouldProcess); // Offset: 0x101e8c294 // Return & Params: Num(5) Size(0x13)

	// Object Name: Function AnimationSharing.AnimationSharingStateProcessor.GetAnimationStateEnum
	// Flags: [Native|Event|Public|BlueprintEvent]
	struct UEnum* GetAnimationStateEnum(); // Offset: 0x101e8c258 // Return & Params: Num(1) Size(0x8)
};

