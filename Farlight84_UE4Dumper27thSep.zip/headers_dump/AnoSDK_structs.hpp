#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct AnoSDK.AnoSDKAntiData
// Size: 0x18 // Inherited bytes: 0x00
struct FAnoSDKAntiData {
	// Fields
	int32_t Length; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString AntiData; // Offset: 0x08 // Size: 0x10
};

