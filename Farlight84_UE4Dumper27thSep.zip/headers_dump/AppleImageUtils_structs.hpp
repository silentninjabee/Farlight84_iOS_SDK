#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct AppleImageUtils.AppleImageUtilsImageConversionResult
// Size: 0x20 // Inherited bytes: 0x00
struct FAppleImageUtilsImageConversionResult {
	// Fields
	struct FString Error; // Offset: 0x00 // Size: 0x10
	struct TArray<char> ImageData; // Offset: 0x10 // Size: 0x10
};

