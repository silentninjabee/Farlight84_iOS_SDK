#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct AudioExtensions.SoundModulationParameter
// Size: 0x14 // Inherited bytes: 0x00
struct FSoundModulationParameter {
	// Fields
	struct FName Control; // Offset: 0x00 // Size: 0x08
	float Value; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x8]; // Offset: 0x0c // Size: 0x08
};

// Object Name: ScriptStruct AudioExtensions.SoundModulation
// Size: 0x10 // Inherited bytes: 0x00
struct FSoundModulation {
	// Fields
	struct TArray<struct USoundModulationPluginSourceSettingsBase*> Settings; // Offset: 0x00 // Size: 0x10
};

