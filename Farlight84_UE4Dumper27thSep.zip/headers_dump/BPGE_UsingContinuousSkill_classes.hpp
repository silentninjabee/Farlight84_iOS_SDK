#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BPGE_UsingContinuousSkill.BPGE_UsingContinuousSkill_C
// Size: 0x848 // Inherited bytes: 0x848
struct UBPGE_UsingContinuousSkill_C : UGameplayEffect {
};

