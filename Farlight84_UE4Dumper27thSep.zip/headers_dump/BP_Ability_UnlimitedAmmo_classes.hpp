#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_Ability_UnlimitedAmmo.BP_Ability_UnlimitedAmmo_C
// Size: 0x420 // Inherited bytes: 0x3b0
struct ABP_Ability_UnlimitedAmmo_C : AWeaponHitAbility {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x3b0 // Size: 0x08
	struct UParticleSystemComponent* FX_Buff_AbilityIncrease; // Offset: 0x3b8 // Size: 0x08
	struct UParticleSystemComponent* Fx_WeaponBuff; // Offset: 0x3c0 // Size: 0x08
	struct ASolarCharacter* CacheCharacter; // Offset: 0x3c8 // Size: 0x08
	struct FName CharacterEffectSocketName; // Offset: 0x3d0 // Size: 0x08
	struct UUserWidget* ScreenEffectClass; // Offset: 0x3d8 // Size: 0x08
	struct UUserWidget* CacheScreenEffect; // Offset: 0x3e0 // Size: 0x08
	struct FString SoundName1P; // Offset: 0x3e8 // Size: 0x10
	struct FString SoundName3P; // Offset: 0x3f8 // Size: 0x10
	struct FString SoundName3PEnemy; // Offset: 0x408 // Size: 0x10
	struct ASolarWeapon* CacheWeapon; // Offset: 0x418 // Size: 0x08

	// Functions

	// Object Name: Function BP_Ability_UnlimitedAmmo.BP_Ability_UnlimitedAmmo_C.ReceiveBeginPlay
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveBeginPlay(); // Offset: 0x103339bc4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_Ability_UnlimitedAmmo.BP_Ability_UnlimitedAmmo_C.ReceiveEndPlay
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveEndPlay(enum class EEndPlayReason EndPlayReason); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function BP_Ability_UnlimitedAmmo.BP_Ability_UnlimitedAmmo_C.EndWhenUnhold
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EndWhenUnhold(); // Offset: 0x103339bc4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_Ability_UnlimitedAmmo.BP_Ability_UnlimitedAmmo_C.ExecuteUbergraph_BP_Ability_UnlimitedAmmo
	// Flags: [Final|UbergraphFunction|HasDefaults]
	void ExecuteUbergraph_BP_Ability_UnlimitedAmmo(int32_t EntryPoint); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x4)
};

