#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass BP_HUD_BulletBase.BP_HUD_BulletBase_C
// Size: 0x268 // Inherited bytes: 0x260
struct UBP_HUD_BulletBase_C : UUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x260 // Size: 0x08

	// Functions

	// Object Name: Function BP_HUD_BulletBase.BP_HUD_BulletBase_C.GetReloadBulletAnimation
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void GetReloadBulletAnimation(struct UWidgetAnimation*& OutReloadAniamtion); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function BP_HUD_BulletBase.BP_HUD_BulletBase_C.PlayReloadBulletAnimation
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void PlayReloadBulletAnimation(); // Offset: 0x103339bc4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_HUD_BulletBase.BP_HUD_BulletBase_C.SetBulletVisible
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetBulletVisible(bool InbVisilble); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function BP_HUD_BulletBase.BP_HUD_BulletBase_C.ReloadFinish
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void ReloadFinish(int32_t InReservedAmmo, int32_t InMaxAmmo); // Offset: 0x103339bc4 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function BP_HUD_BulletBase.BP_HUD_BulletBase_C.SetBulletLightEffect
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetBulletLightEffect(float InProgress); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function BP_HUD_BulletBase.BP_HUD_BulletBase_C.GetBulletGaugeWidget
	// Flags: [Protected|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void GetBulletGaugeWidget(struct UUserWidget*& OutBulletGaugeWidget); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function BP_HUD_BulletBase.BP_HUD_BulletBase_C.UpdateBulletGaugeProgress
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void UpdateBulletGaugeProgress(float InBulletGaugeProgress); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function BP_HUD_BulletBase.BP_HUD_BulletBase_C.GetUpdateBulletStateAnimation
	// Flags: [Protected|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void GetUpdateBulletStateAnimation(struct UWidgetAnimation*& OutUpdateBulletStateAnimation); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function BP_HUD_BulletBase.BP_HUD_BulletBase_C.PlayUpdateBulletStateAnimation
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void PlayUpdateBulletStateAnimation(bool InbReload); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function BP_HUD_BulletBase.BP_HUD_BulletBase_C.OnActiveCrosshair
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void OnActiveCrosshair(struct UUserWidget* InActiveCrosshair); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function BP_HUD_BulletBase.BP_HUD_BulletBase_C.OnChangeOverloadState
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void OnChangeOverloadState(bool InbQuitState); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function BP_HUD_BulletBase.BP_HUD_BulletBase_C.OnChangeReloadState
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void OnChangeReloadState(bool InbQuitState, bool bReloadSpeedup); // Offset: 0x103339bc4 // Return & Params: Num(2) Size(0x2)

	// Object Name: Function BP_HUD_BulletBase.BP_HUD_BulletBase_C.OnInsufficientAmmo
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void OnInsufficientAmmo(); // Offset: 0x103339bc4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_HUD_BulletBase.BP_HUD_BulletBase_C.OnUpdateCharge
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void OnUpdateCharge(bool InbCharging, int32_t InChargeMode, float InChargeProgress); // Offset: 0x103339bc4 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function BP_HUD_BulletBase.BP_HUD_BulletBase_C.OnUpdateCoolDown
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void OnUpdateCoolDown(float InReloadProgress); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function BP_HUD_BulletBase.BP_HUD_BulletBase_C.OnUpdateOverload
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void OnUpdateOverload(float InOverloadProgress, float InOverloadWarningRate, bool InbOverloadState); // Offset: 0x103339bc4 // Return & Params: Num(3) Size(0x9)

	// Object Name: Function BP_HUD_BulletBase.BP_HUD_BulletBase_C.OnUpdateAmmo
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void OnUpdateAmmo(int32_t InReservedAmmo, int32_t InMaxAmmo, float InAmmoProgress, bool InbFirst); // Offset: 0x103339bc4 // Return & Params: Num(4) Size(0xd)

	// Object Name: Function BP_HUD_BulletBase.BP_HUD_BulletBase_C.OnUpdateReload
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void OnUpdateReload(float InReloadProgress, int32_t InReloadAmmo, int32_t InMaxAmmo); // Offset: 0x103339bc4 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function BP_HUD_BulletBase.BP_HUD_BulletBase_C.OnReloadFinish
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void OnReloadFinish(bool InbReloadSuccess, int32_t InReloadAmmo, int32_t InReservedAmmo, int32_t InMaxAmmo, float InAmmoProgress); // Offset: 0x103339bc4 // Return & Params: Num(5) Size(0x14)

	// Object Name: Function BP_HUD_BulletBase.BP_HUD_BulletBase_C.ExecuteUbergraph_BP_HUD_BulletBase
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_BP_HUD_BulletBase(int32_t EntryPoint); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x4)
};

