#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_QuickSummon_Forward.BP_QuickSummon_Forward_C
// Size: 0x40 // Inherited bytes: 0x28
struct UBP_QuickSummon_Forward_C : USolarQuickSummonProxy {
	// Fields
	float CheckHeightUp; // Offset: 0x28 // Size: 0x04
	float CheckHeightDown; // Offset: 0x2c // Size: 0x04
	struct TArray<float> CheckDistanceArray; // Offset: 0x30 // Size: 0x10

	// Functions

	// Object Name: Function BP_QuickSummon_Forward.BP_QuickSummon_Forward_C.TryGetSummonHitResult
	// Flags: [Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	bool TryGetSummonHitResult(struct FHitResult& OutHitResult, struct AActor* InSummoner, struct USolarSummonDetectionConfig* InSummonConfig); // Offset: 0x103339bc4 // Return & Params: Num(4) Size(0x99)
};

