#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_Rifle_Mphy01_Set00_Preview.BP_Rifle_Mphy01_Set00_Preview_C
// Size: 0x688 // Inherited bytes: 0x688
struct ABP_Rifle_Mphy01_Set00_Preview_C : ABP_Weaponry_Base_Preview_C {
};

