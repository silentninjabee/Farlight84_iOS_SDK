#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_SORF_Normal_LodP_Prop.BP_SORF_Normal_LodP_Prop_C
// Size: 0x5a0 // Inherited bytes: 0x591
struct ABP_SORF_Normal_LodP_Prop_C : APreviewActorBase_C {
	// Fields
	char pad_0x591[0x7]; // Offset: 0x591 // Size: 0x07
	struct UStaticMeshComponent* Avatar_SORF_Prop_Normal_LodP; // Offset: 0x598 // Size: 0x08
};

