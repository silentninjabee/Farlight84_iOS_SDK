#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_Sniper_B9A01_Set00_Preview.BP_Sniper_B9A01_Set00_Preview_C
// Size: 0x688 // Inherited bytes: 0x688
struct ABP_Sniper_B9A01_Set00_Preview_C : ABP_Weaponry_Base_Preview_C {
};

