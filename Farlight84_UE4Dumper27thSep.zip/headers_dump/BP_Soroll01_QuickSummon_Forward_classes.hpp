#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_Soroll01_QuickSummon_Forward.BP_Soroll01_QuickSummon_Forward_C
// Size: 0x40 // Inherited bytes: 0x40
struct UBP_Soroll01_QuickSummon_Forward_C : UBP_QuickSummon_Forward_C {
};

