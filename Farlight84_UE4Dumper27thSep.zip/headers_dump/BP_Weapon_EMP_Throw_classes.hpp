#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_Weapon_EMP_Throw.BP_Weapon_EMP_Throw_C
// Size: 0x5a0 // Inherited bytes: 0x5a0
struct ABP_Weapon_EMP_Throw_C : ASolarSkill_EMP {
};

