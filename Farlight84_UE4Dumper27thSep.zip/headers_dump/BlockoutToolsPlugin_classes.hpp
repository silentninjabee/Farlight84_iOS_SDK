#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class BlockoutToolsPlugin.BlockoutToolsParent
// Size: 0x2b0 // Inherited bytes: 0x228
struct ABlockoutToolsParent : AActor {
	// Fields
	struct USceneComponent* Root; // Offset: 0x228 // Size: 0x08
	struct UBillboardComponent* Billboard; // Offset: 0x230 // Size: 0x08
	struct UMaterialInterface* BlockoutGridParent; // Offset: 0x238 // Size: 0x08
	struct UMaterialInstanceDynamic* BlockoutGridMID; // Offset: 0x240 // Size: 0x08
	struct UMaterialInterface* BlockoutCurrentMaterial; // Offset: 0x248 // Size: 0x08
	struct TArray<struct UStaticMeshComponent*> BlockoutMeshComponents; // Offset: 0x250 // Size: 0x10
	enum class EBlockoutMaterialType BlockoutMaterialType; // Offset: 0x260 // Size: 0x01
	char pad_0x261[0x3]; // Offset: 0x261 // Size: 0x03
	struct FLinearColor BlockoutMaterialColor; // Offset: 0x264 // Size: 0x10
	bool bBlockoutMaterialUseGrid; // Offset: 0x274 // Size: 0x01
	char pad_0x275[0x3]; // Offset: 0x275 // Size: 0x03
	float BlockoutMaterialGridSize; // Offset: 0x278 // Size: 0x04
	float BlockoutMaterialCheckerLuminance; // Offset: 0x27c // Size: 0x04
	bool bBlockoutMaterialUseTopColor; // Offset: 0x280 // Size: 0x01
	char pad_0x281[0x3]; // Offset: 0x281 // Size: 0x03
	struct FLinearColor BlockoutMaterialTopColor; // Offset: 0x284 // Size: 0x10
	bool bUseCustomMaterial; // Offset: 0x294 // Size: 0x01
	char pad_0x295[0x3]; // Offset: 0x295 // Size: 0x03
	struct UMaterialInterface* CustomMaterial; // Offset: 0x298 // Size: 0x08
	struct UMaterialInterface* BlockoutCustomMaterial; // Offset: 0x2a0 // Size: 0x08
	bool bBlockoutEnableCollisions; // Offset: 0x2a8 // Size: 0x01
	bool bBlockoutCastShadows; // Offset: 0x2a9 // Size: 0x01
	char pad_0x2AA[0x6]; // Offset: 0x2aa // Size: 0x06

	// Functions

	// Object Name: Function BlockoutToolsPlugin.BlockoutToolsParent.RerunConstructionScript
	// Flags: [Final|Native|Private|BlueprintCallable]
	void RerunConstructionScript(); // Offset: 0x101065c28 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BlockoutToolsPlugin.BlockoutToolsParent.BlockoutSetMaterial
	// Flags: [Final|Native|Private|BlueprintCallable]
	void BlockoutSetMaterial(); // Offset: 0x101065c14 // Return & Params: Num(0) Size(0x0)
};

