#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class CableComponent.CableActor
// Size: 0x230 // Inherited bytes: 0x228
struct ACableActor : AActor {
	// Fields
	struct UCableComponent* CableComponent; // Offset: 0x228 // Size: 0x08
};

// Object Name: Class CableComponent.CableComponent
// Size: 0x630 // Inherited bytes: 0x5b0
struct UCableComponent : UMeshComponent {
	// Fields
	bool bAttachStart; // Offset: 0x5a1 // Size: 0x01
	bool bAttachEnd; // Offset: 0x5a2 // Size: 0x01
	struct FComponentReference AttachEndTo; // Offset: 0x5a8 // Size: 0x28
	struct FName AttachEndToSocketName; // Offset: 0x5d0 // Size: 0x08
	struct FVector EndLocation; // Offset: 0x5d8 // Size: 0x0c
	float CableLength; // Offset: 0x5e4 // Size: 0x04
	int32_t NumSegments; // Offset: 0x5e8 // Size: 0x04
	float SubstepTime; // Offset: 0x5ec // Size: 0x04
	int32_t SolverIterations; // Offset: 0x5f0 // Size: 0x04
	bool bEnableStiffness; // Offset: 0x5f4 // Size: 0x01
	bool bEnableCollision; // Offset: 0x5f5 // Size: 0x01
	float CollisionFriction; // Offset: 0x5f8 // Size: 0x04
	struct FVector CableForce; // Offset: 0x5fc // Size: 0x0c
	float CableGravityScale; // Offset: 0x608 // Size: 0x04
	float CableWidth; // Offset: 0x60c // Size: 0x04
	int32_t NumSides; // Offset: 0x610 // Size: 0x04
	float TileMaterial; // Offset: 0x614 // Size: 0x04
	char pad_0x620[0x10]; // Offset: 0x620 // Size: 0x10

	// Functions

	// Object Name: Function CableComponent.CableComponent.SetAttachEndToComponent
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAttachEndToComponent(struct USceneComponent* Component, struct FName SocketName); // Offset: 0x101fe6a64 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function CableComponent.CableComponent.SetAttachEndTo
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAttachEndTo(struct AActor* Actor, struct FName ComponentProperty, struct FName SocketName); // Offset: 0x101fe6950 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function CableComponent.CableComponent.GetCableParticleLocations
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetCableParticleLocations(struct TArray<struct FVector>& Locations); // Offset: 0x101fe6850 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function CableComponent.CableComponent.GetAttachedComponent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct USceneComponent* GetAttachedComponent(); // Offset: 0x101fe68e8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function CableComponent.CableComponent.GetAttachedActor
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct AActor* GetAttachedActor(); // Offset: 0x101fe691c // Return & Params: Num(1) Size(0x8)
};

