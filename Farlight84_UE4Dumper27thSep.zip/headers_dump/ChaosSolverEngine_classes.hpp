#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class ChaosSolverEngine.ChaosDebugDrawComponent
// Size: 0xb8 // Inherited bytes: 0xb0
struct UChaosDebugDrawComponent : UActorComponent {
	// Fields
	char pad_0xB0[0x8]; // Offset: 0xb0 // Size: 0x08
};

// Object Name: Class ChaosSolverEngine.ChaosEventListenerComponent
// Size: 0xb8 // Inherited bytes: 0xb0
struct UChaosEventListenerComponent : UActorComponent {
	// Fields
	char pad_0xB0[0x8]; // Offset: 0xb0 // Size: 0x08
};

// Object Name: Class ChaosSolverEngine.ChaosGameplayEventDispatcher
// Size: 0x270 // Inherited bytes: 0xb8
struct UChaosGameplayEventDispatcher : UChaosEventListenerComponent {
	// Fields
	char pad_0xB8[0x110]; // Offset: 0xb8 // Size: 0x110
	struct TMap<struct UPrimitiveComponent*, struct FChaosHandlerSet> CollisionEventRegistrations; // Offset: 0x1c8 // Size: 0x50
	struct TMap<struct UPrimitiveComponent*, struct FBreakEventCallbackWrapper> BreakEventRegistrations; // Offset: 0x218 // Size: 0x50
	char pad_0x268[0x8]; // Offset: 0x268 // Size: 0x08
};

// Object Name: Class ChaosSolverEngine.ChaosNotifyHandlerInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UChaosNotifyHandlerInterface : UInterface {
};

// Object Name: Class ChaosSolverEngine.ChaosSolverEngineBlueprintLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct UChaosSolverEngineBlueprintLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function ChaosSolverEngine.ChaosSolverEngineBlueprintLibrary.ConvertPhysicsCollisionToHitResult
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FHitResult ConvertPhysicsCollisionToHitResult(struct FChaosPhysicsCollisionInfo& PhysicsCollision); // Offset: 0x105175904 // Return & Params: Num(2) Size(0xf8)
};

// Object Name: Class ChaosSolverEngine.ChaosSolver
// Size: 0x28 // Inherited bytes: 0x28
struct UChaosSolver : UObject {
};

// Object Name: Class ChaosSolverEngine.ChaosSolverActor
// Size: 0x2b0 // Inherited bytes: 0x228
struct AChaosSolverActor : AActor {
	// Fields
	float TimeStepMultiplier; // Offset: 0x228 // Size: 0x04
	int32_t CollisionIterations; // Offset: 0x22c // Size: 0x04
	int32_t PushOutIterations; // Offset: 0x230 // Size: 0x04
	int32_t PushOutPairIterations; // Offset: 0x234 // Size: 0x04
	float ClusterConnectionFactor; // Offset: 0x238 // Size: 0x04
	enum class EClusterConnectionTypeEnum ClusterUnionConnectionType; // Offset: 0x23c // Size: 0x01
	bool DoGenerateCollisionData; // Offset: 0x23d // Size: 0x01
	char pad_0x23E[0x2]; // Offset: 0x23e // Size: 0x02
	struct FSolverCollisionFilterSettings CollisionFilterSettings; // Offset: 0x240 // Size: 0x10
	bool DoGenerateBreakingData; // Offset: 0x250 // Size: 0x01
	char pad_0x251[0x3]; // Offset: 0x251 // Size: 0x03
	struct FSolverBreakingFilterSettings BreakingFilterSettings; // Offset: 0x254 // Size: 0x10
	bool DoGenerateTrailingData; // Offset: 0x264 // Size: 0x01
	char pad_0x265[0x3]; // Offset: 0x265 // Size: 0x03
	struct FSolverTrailingFilterSettings TrailingFilterSettings; // Offset: 0x268 // Size: 0x10
	bool bHasFloor; // Offset: 0x278 // Size: 0x01
	char pad_0x279[0x3]; // Offset: 0x279 // Size: 0x03
	float FloorHeight; // Offset: 0x27c // Size: 0x04
	float MassScale; // Offset: 0x280 // Size: 0x04
	bool bGenerateContactGraph; // Offset: 0x284 // Size: 0x01
	struct FChaosDebugSubstepControl ChaosDebugSubstepControl; // Offset: 0x285 // Size: 0x03
	struct UBillboardComponent* SpriteComponent; // Offset: 0x288 // Size: 0x08
	char pad_0x290[0x18]; // Offset: 0x290 // Size: 0x18
	struct UChaosGameplayEventDispatcher* GameplayEventDispatcherComponent; // Offset: 0x2a8 // Size: 0x08

	// Functions

	// Object Name: Function ChaosSolverEngine.ChaosSolverActor.SetSolverActive
	// Flags: [Native|Public|BlueprintCallable]
	void SetSolverActive(bool bActive); // Offset: 0x105175f14 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function ChaosSolverEngine.ChaosSolverActor.SetAsCurrentWorldSolver
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAsCurrentWorldSolver(); // Offset: 0x105175fa4 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class ChaosSolverEngine.ChaosSolverSettings
// Size: 0x58 // Inherited bytes: 0x38
struct UChaosSolverSettings : UDeveloperSettings {
	// Fields
	char pad_0x38[0x8]; // Offset: 0x38 // Size: 0x08
	struct FSoftClassPath DefaultChaosSolverActorClass; // Offset: 0x40 // Size: 0x18
};

