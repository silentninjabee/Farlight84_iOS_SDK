#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class ClothingSystemRuntimeCommon.ClothConfigCommon
// Size: 0x28 // Inherited bytes: 0x28
struct UClothConfigCommon : UClothConfigBase {
};

// Object Name: Class ClothingSystemRuntimeCommon.ClothSharedConfigCommon
// Size: 0x28 // Inherited bytes: 0x28
struct UClothSharedConfigCommon : UClothConfigCommon {
};

// Object Name: Class ClothingSystemRuntimeCommon.ClothingAssetCustomData
// Size: 0x28 // Inherited bytes: 0x28
struct UClothingAssetCustomData : UObject {
};

// Object Name: Class ClothingSystemRuntimeCommon.ClothingAssetCommon
// Size: 0x1f0 // Inherited bytes: 0x48
struct UClothingAssetCommon : UClothingAssetBase {
	// Fields
	struct UPhysicsAsset* PhysicsAsset; // Offset: 0x48 // Size: 0x08
	struct TMap<struct FName, struct UClothConfigBase*> ClothConfigs; // Offset: 0x50 // Size: 0x50
	struct UClothConfigBase* ClothSharedSimConfig; // Offset: 0xa0 // Size: 0x08
	struct UClothConfigBase* ClothSimConfig; // Offset: 0xa8 // Size: 0x08
	struct UClothConfigBase* ChaosClothSimConfig; // Offset: 0xb0 // Size: 0x08
	struct TArray<struct UClothLODDataCommon_Legacy*> ClothLODData; // Offset: 0xb8 // Size: 0x10
	struct TArray<struct FClothLODDataCommon> LODData; // Offset: 0xc8 // Size: 0x10
	struct TArray<int32_t> LodMap; // Offset: 0xd8 // Size: 0x10
	struct TArray<struct FName> UsedBoneNames; // Offset: 0xe8 // Size: 0x10
	struct TArray<int32_t> UsedBoneIndices; // Offset: 0xf8 // Size: 0x10
	int32_t ReferenceBoneIndex; // Offset: 0x108 // Size: 0x04
	char pad_0x10C[0x4]; // Offset: 0x10c // Size: 0x04
	struct UClothingAssetCustomData* CustomData; // Offset: 0x110 // Size: 0x08
	struct FClothConfig_Legacy ClothConfig; // Offset: 0x118 // Size: 0xd4
	char pad_0x1EC[0x4]; // Offset: 0x1ec // Size: 0x04
};

// Object Name: Class ClothingSystemRuntimeCommon.ClothLODDataCommon_Legacy
// Size: 0x188 // Inherited bytes: 0x28
struct UClothLODDataCommon_Legacy : UObject {
	// Fields
	struct UClothPhysicalMeshDataBase_Legacy* PhysicalMeshData; // Offset: 0x28 // Size: 0x08
	struct FClothPhysicalMeshData ClothPhysicalMeshData; // Offset: 0x30 // Size: 0xf8
	struct FClothCollisionData CollisionData; // Offset: 0x128 // Size: 0x40
	char pad_0x168[0x20]; // Offset: 0x168 // Size: 0x20
};

