#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class ClothingSystemRuntimeInterface.ClothConfigBase
// Size: 0x28 // Inherited bytes: 0x28
struct UClothConfigBase : UObject {
};

// Object Name: Class ClothingSystemRuntimeInterface.ClothSharedSimConfigBase
// Size: 0x28 // Inherited bytes: 0x28
struct UClothSharedSimConfigBase : UObject {
};

// Object Name: Class ClothingSystemRuntimeInterface.ClothingAssetBase
// Size: 0x48 // Inherited bytes: 0x28
struct UClothingAssetBase : UObject {
	// Fields
	struct FString ImportedFilePath; // Offset: 0x28 // Size: 0x10
	struct FGuid AssetGuid; // Offset: 0x38 // Size: 0x10
};

// Object Name: Class ClothingSystemRuntimeInterface.ClothingSimulationFactory
// Size: 0x28 // Inherited bytes: 0x28
struct UClothingSimulationFactory : UObject {
};

// Object Name: Class ClothingSystemRuntimeInterface.ClothingSimulationInteractor
// Size: 0x30 // Inherited bytes: 0x28
struct UClothingSimulationInteractor : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08

	// Functions

	// Object Name: Function ClothingSystemRuntimeInterface.ClothingSimulationInteractor.SetAnimDriveSpringStiffness
	// Flags: [Native|Public|BlueprintCallable]
	void SetAnimDriveSpringStiffness(float InStiffness); // Offset: 0x1044ff13c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function ClothingSystemRuntimeInterface.ClothingSimulationInteractor.PhysicsAssetUpdated
	// Flags: [Native|Public|BlueprintCallable]
	void PhysicsAssetUpdated(); // Offset: 0x1044ff1e0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function ClothingSystemRuntimeInterface.ClothingSimulationInteractor.EnableGravityOverride
	// Flags: [Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void EnableGravityOverride(struct FVector& InVector); // Offset: 0x1044ff0ac // Return & Params: Num(1) Size(0xc)

	// Object Name: Function ClothingSystemRuntimeInterface.ClothingSimulationInteractor.DisableGravityOverride
	// Flags: [Native|Public|BlueprintCallable]
	void DisableGravityOverride(); // Offset: 0x1044ff090 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function ClothingSystemRuntimeInterface.ClothingSimulationInteractor.ClothConfigUpdated
	// Flags: [Native|Public|BlueprintCallable]
	void ClothConfigUpdated(); // Offset: 0x1044ff1c4 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class ClothingSystemRuntimeInterface.ClothPhysicalMeshDataBase_Legacy
// Size: 0xe0 // Inherited bytes: 0x28
struct UClothPhysicalMeshDataBase_Legacy : UObject {
	// Fields
	struct TArray<struct FVector> Vertices; // Offset: 0x28 // Size: 0x10
	struct TArray<struct FVector> Normals; // Offset: 0x38 // Size: 0x10
	struct TArray<uint32_t> Indices; // Offset: 0x48 // Size: 0x10
	struct TArray<float> InverseMasses; // Offset: 0x58 // Size: 0x10
	struct TArray<struct FClothVertBoneData> BoneData; // Offset: 0x68 // Size: 0x10
	int32_t NumFixedVerts; // Offset: 0x78 // Size: 0x04
	int32_t MaxBoneWeights; // Offset: 0x7c // Size: 0x04
	struct TArray<uint32_t> SelfCollisionIndices; // Offset: 0x80 // Size: 0x10
	char pad_0x90[0x50]; // Offset: 0x90 // Size: 0x50
};

