#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Crosshair_AutoFire_Anim.Crosshair_AutoFire_Anim_C
// Size: 0x378 // Inherited bytes: 0x348
struct UCrosshair_AutoFire_Anim_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x348 // Size: 0x08
	struct UWidgetAnimation* Anim_AutoFire_3; // Offset: 0x350 // Size: 0x08
	struct UWidgetAnimation* Anim_AutoFire_2; // Offset: 0x358 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_1; // Offset: 0x360 // Size: 0x08
	struct UImage* Img_AutoFire_2; // Offset: 0x368 // Size: 0x08
	struct UImage* Img_coredot; // Offset: 0x370 // Size: 0x08

	// Functions

	// Object Name: Function Crosshair_AutoFire_Anim.Crosshair_AutoFire_Anim_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Construct(); // Offset: 0x103339bc4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Crosshair_AutoFire_Anim.Crosshair_AutoFire_Anim_C.ExecuteUbergraph_Crosshair_AutoFire_Anim
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_Crosshair_AutoFire_Anim(int32_t EntryPoint); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x4)
};

