#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Crosshair_CarWeapon_Float.Crosshair_CarWeapon_Float_C
// Size: 0x54e // Inherited bytes: 0x488
struct UCrosshair_CarWeapon_Float_C : UVehicleWeaponCrossHairWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x488 // Size: 0x08
	struct UWidgetAnimation* Normal_Anim; // Offset: 0x490 // Size: 0x08
	struct UWidgetAnimation* Aim_Anim; // Offset: 0x498 // Size: 0x08
	struct UWidgetAnimation* Overheat_Anim_Quit; // Offset: 0x4a0 // Size: 0x08
	struct UWidgetAnimation* Fullcharge_Anim; // Offset: 0x4a8 // Size: 0x08
	struct UWidgetAnimation* Overheat_Anim_Enter; // Offset: 0x4b0 // Size: 0x08
	struct UCanvasPanel* Container_SecondReticle; // Offset: 0x4b8 // Size: 0x08
	struct UCanvasPanel* Coredot; // Offset: 0x4c0 // Size: 0x08
	struct UImage* img_charge; // Offset: 0x4c8 // Size: 0x08
	struct UImage* Img_Circle; // Offset: 0x4d0 // Size: 0x08
	struct UImage* Img_Circle_2; // Offset: 0x4d8 // Size: 0x08
	struct UImage* Img_Glow; // Offset: 0x4e0 // Size: 0x08
	struct UImage* img_overload_cordot; // Offset: 0x4e8 // Size: 0x08
	struct UCanvasPanel* Panel_Aim; // Offset: 0x4f0 // Size: 0x08
	struct UCanvasPanel* panel_enlarge; // Offset: 0x4f8 // Size: 0x08
	struct UImage* ReticleDirection; // Offset: 0x500 // Size: 0x08
	struct UImage* SpreadImg_coredot; // Offset: 0x508 // Size: 0x08
	struct UImage* SpreadImg_coredot_3; // Offset: 0x510 // Size: 0x08
	struct UImage* SpreadImg_coredot_5; // Offset: 0x518 // Size: 0x08
	struct UWidgetSwitcher* wgs_enlarge; // Offset: 0x520 // Size: 0x08
	struct UWidgetSwitcher* wgs_overload; // Offset: 0x528 // Size: 0x08
	float ChargeProgress; // Offset: 0x530 // Size: 0x04
	bool IsChargingLast; // Offset: 0x534 // Size: 0x01
	char pad_0x535[0x3]; // Offset: 0x535 // Size: 0x03
	struct FVector2D OriChargeSize; // Offset: 0x538 // Size: 0x08
	bool IsCharging; // Offset: 0x540 // Size: 0x01
	char pad_0x541[0x3]; // Offset: 0x541 // Size: 0x03
	struct FVector2D TempSize; // Offset: 0x544 // Size: 0x08
	bool IsOverloading; // Offset: 0x54c // Size: 0x01
	bool bLockedEnemy; // Offset: 0x54d // Size: 0x01

	// Functions

	// Object Name: Function Crosshair_CarWeapon_Float.Crosshair_CarWeapon_Float_C.OnOverloadChanged
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void OnOverloadChanged(bool InOverload); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Crosshair_CarWeapon_Float.Crosshair_CarWeapon_Float_C.Set Charge Panel Size
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void Set Charge Panel Size(); // Offset: 0x103339bc4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Crosshair_CarWeapon_Float.Crosshair_CarWeapon_Float_C.SetChargeProgress
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetChargeProgress(); // Offset: 0x103339bc4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Crosshair_CarWeapon_Float.Crosshair_CarWeapon_Float_C.SetWidgetResources
	// Flags: [Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent]
	void SetWidgetResources(struct UCanvasPanel*& InSecondReticlePanel, struct UImage*& InReticleDirectionImage, struct UImage*& InRangedImage, struct USizeBox*& InAssistLockSizeBox, struct UCanvasPanel*& InChangeNewAssistLockPawnPanel, struct UCanvasPanel*& InEnterLockPawnPanel, struct UCanvasPanel*& InCanvas_Dynamic); // Offset: 0x103339bc4 // Return & Params: Num(7) Size(0x38)

	// Object Name: Function Crosshair_CarWeapon_Float.Crosshair_CarWeapon_Float_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Construct(); // Offset: 0x103339bc4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Crosshair_CarWeapon_Float.Crosshair_CarWeapon_Float_C.OnUpdateChargeProgress
	// Flags: [Event|Protected|BlueprintEvent]
	void OnUpdateChargeProgress(bool InbCharging, int32_t InChargeMode, float InChargeProgress, int32_t InChargeBurstCount); // Offset: 0x103339bc4 // Return & Params: Num(4) Size(0x10)

	// Object Name: Function Crosshair_CarWeapon_Float.Crosshair_CarWeapon_Float_C.OnOverloadStateChanged
	// Flags: [Event|Protected|BlueprintEvent]
	void OnOverloadStateChanged(bool bEnter); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Crosshair_CarWeapon_Float.Crosshair_CarWeapon_Float_C.OnCrosshairInNormalState
	// Flags: [Event|Protected|BlueprintEvent]
	void OnCrosshairInNormalState(); // Offset: 0x103339bc4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Crosshair_CarWeapon_Float.Crosshair_CarWeapon_Float_C.OnAnimationFinished
	// Flags: [BlueprintCosmetic|Event|Protected|BlueprintEvent]
	void OnAnimationFinished(struct UWidgetAnimation* Animation); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Crosshair_CarWeapon_Float.Crosshair_CarWeapon_Float_C.OnUpdateAimState
	// Flags: [Event|Protected|BlueprintEvent]
	void OnUpdateAimState(bool InbLockEnemy); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Crosshair_CarWeapon_Float.Crosshair_CarWeapon_Float_C.ExecuteUbergraph_Crosshair_CarWeapon_Float
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_Crosshair_CarWeapon_Float(int32_t EntryPoint); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x4)
};

