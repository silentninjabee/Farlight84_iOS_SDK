#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Crosshair_CarWeapon_Rocket.Crosshair_CarWeapon_Rocket_C
// Size: 0x4d0 // Inherited bytes: 0x488
struct UCrosshair_CarWeapon_Rocket_C : UVehicleWeaponCrossHairWidget {
	// Fields
	struct UCanvasPanel* Container_SecondReticle; // Offset: 0x488 // Size: 0x08
	struct UCanvasPanel* Coredot; // Offset: 0x490 // Size: 0x08
	struct UImage* ForbidImg; // Offset: 0x498 // Size: 0x08
	struct UHUD_Overload_C* HUD_Overload; // Offset: 0x4a0 // Size: 0x08
	struct UHUD_Reload_C* HUD_Reload; // Offset: 0x4a8 // Size: 0x08
	struct UImage* ReticleDirection; // Offset: 0x4b0 // Size: 0x08
	struct UImage* SpreadImg_coredot; // Offset: 0x4b8 // Size: 0x08
	struct UImage* SpreadImg_coredot_2; // Offset: 0x4c0 // Size: 0x08
	struct UImage* SpreadImg_coredot_3; // Offset: 0x4c8 // Size: 0x08

	// Functions

	// Object Name: Function Crosshair_CarWeapon_Rocket.Crosshair_CarWeapon_Rocket_C.GetOverloadWidget
	// Flags: [Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent]
	struct UUserWidget* GetOverloadWidget(); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Crosshair_CarWeapon_Rocket.Crosshair_CarWeapon_Rocket_C.SetWidgetResources
	// Flags: [Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent]
	void SetWidgetResources(struct UCanvasPanel*& InSecondReticlePanel, struct UImage*& InReticleDirectionImage, struct UImage*& InRangedImage, struct USizeBox*& InAssistLockSizeBox, struct UCanvasPanel*& InChangeNewAssistLockPawnPanel, struct UCanvasPanel*& InEnterLockPawnPanel, struct UCanvasPanel*& InCanvas_Dynamic); // Offset: 0x103339bc4 // Return & Params: Num(7) Size(0x38)
};

