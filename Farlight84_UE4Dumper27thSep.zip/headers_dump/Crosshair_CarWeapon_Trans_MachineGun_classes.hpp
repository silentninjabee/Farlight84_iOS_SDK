#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Crosshair_CarWeapon_Trans_MachineGun.Crosshair_CarWeapon_Trans_MachineGun_C
// Size: 0x528 // Inherited bytes: 0x488
struct UCrosshair_CarWeapon_Trans_MachineGun_C : UVehicleWeaponCrossHairWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x488 // Size: 0x08
	struct UWidgetAnimation* Anim_transform; // Offset: 0x490 // Size: 0x08
	struct UCanvasPanel* Container_SecondReticle; // Offset: 0x498 // Size: 0x08
	struct UCanvasPanel* Coredot; // Offset: 0x4a0 // Size: 0x08
	struct UImage* downarrow; // Offset: 0x4a8 // Size: 0x08
	struct UImage* img_flame; // Offset: 0x4b0 // Size: 0x08
	struct UImage* img_lb; // Offset: 0x4b8 // Size: 0x08
	struct UImage* img_lt; // Offset: 0x4c0 // Size: 0x08
	struct UImage* img_rb; // Offset: 0x4c8 // Size: 0x08
	struct UImage* img_rt; // Offset: 0x4d0 // Size: 0x08
	struct UImage* leftarrow; // Offset: 0x4d8 // Size: 0x08
	struct UCanvasPanel* panel_trans; // Offset: 0x4e0 // Size: 0x08
	struct UImage* ReticleDirection; // Offset: 0x4e8 // Size: 0x08
	struct UImage* rightarrow; // Offset: 0x4f0 // Size: 0x08
	struct UImage* SpreadImg_coredot; // Offset: 0x4f8 // Size: 0x08
	struct UImage* SpreadImg_Downarrow_2; // Offset: 0x500 // Size: 0x08
	struct UImage* SpreadImg_Leftarrow_2; // Offset: 0x508 // Size: 0x08
	struct UImage* SpreadImg_Rightarrow_2; // Offset: 0x510 // Size: 0x08
	struct UImage* SpreadImg_uparrow_2; // Offset: 0x518 // Size: 0x08
	struct UImage* uparrow; // Offset: 0x520 // Size: 0x08

	// Functions

	// Object Name: Function Crosshair_CarWeapon_Trans_MachineGun.Crosshair_CarWeapon_Trans_MachineGun_C.SetWidgetResources
	// Flags: [Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent]
	void SetWidgetResources(struct UCanvasPanel*& InSecondReticlePanel, struct UImage*& InReticleDirectionImage, struct UImage*& InRangedImage, struct USizeBox*& InAssistLockSizeBox, struct UCanvasPanel*& InChangeNewAssistLockPawnPanel, struct UCanvasPanel*& InEnterLockPawnPanel, struct UCanvasPanel*& InCanvas_Dynamic); // Offset: 0x103339bc4 // Return & Params: Num(7) Size(0x38)

	// Object Name: Function Crosshair_CarWeapon_Trans_MachineGun.Crosshair_CarWeapon_Trans_MachineGun_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Construct(); // Offset: 0x103339bc4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Crosshair_CarWeapon_Trans_MachineGun.Crosshair_CarWeapon_Trans_MachineGun_C.OnTransformerWeaponChanged
	// Flags: [Event|Protected|BlueprintEvent]
	void OnTransformerWeaponChanged(enum class ETransformerType InType); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Crosshair_CarWeapon_Trans_MachineGun.Crosshair_CarWeapon_Trans_MachineGun_C.ExecuteUbergraph_Crosshair_CarWeapon_Trans_MachineGun
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_Crosshair_CarWeapon_Trans_MachineGun(int32_t EntryPoint); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x4)
};

