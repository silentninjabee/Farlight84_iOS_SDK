#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Crosshair_Carweapon_WL09Rocket.Crosshair_Carweapon_WL09Rocket_C
// Size: 0x548 // Inherited bytes: 0x488
struct UCrosshair_Carweapon_WL09Rocket_C : UVehicleWeaponCrossHairWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x488 // Size: 0x08
	struct UCanvasPanel* Coredot; // Offset: 0x490 // Size: 0x08
	struct UImage* Img_Bullet_2; // Offset: 0x498 // Size: 0x08
	struct UImage* Img_Bullet_3; // Offset: 0x4a0 // Size: 0x08
	struct UImage* Img_Bullet_4; // Offset: 0x4a8 // Size: 0x08
	struct UImage* Img_Bullet_5; // Offset: 0x4b0 // Size: 0x08
	struct UImage* Img_Bullet_6; // Offset: 0x4b8 // Size: 0x08
	struct UImage* Img_Bullet_7; // Offset: 0x4c0 // Size: 0x08
	struct UImage* Img_Bullet_8; // Offset: 0x4c8 // Size: 0x08
	struct UImage* Img_Bullet_9; // Offset: 0x4d0 // Size: 0x08
	struct UImage* Img_Bullet_10; // Offset: 0x4d8 // Size: 0x08
	struct UImage* Img_Bullet_11; // Offset: 0x4e0 // Size: 0x08
	struct UImage* Img_Bullet_12; // Offset: 0x4e8 // Size: 0x08
	struct UImage* Img_Bullet_13; // Offset: 0x4f0 // Size: 0x08
	struct UImage* Img_Bullet_14; // Offset: 0x4f8 // Size: 0x08
	struct UImage* Img_Bullet_15; // Offset: 0x500 // Size: 0x08
	struct UImage* Img_Bullet_16; // Offset: 0x508 // Size: 0x08
	struct UImage* Img_Bullet_17; // Offset: 0x510 // Size: 0x08
	struct UCanvasPanel* Panel_Reload; // Offset: 0x518 // Size: 0x08
	struct UImage* SpreadImg_coredot; // Offset: 0x520 // Size: 0x08
	struct USolarTextBlock* Txt_Distance; // Offset: 0x528 // Size: 0x08
	int32_t LastRservedAmmo; // Offset: 0x530 // Size: 0x04
	char pad_0x534[0x4]; // Offset: 0x534 // Size: 0x04
	struct TArray<struct UImage*> BulletImage; // Offset: 0x538 // Size: 0x10

	// Functions

	// Object Name: Function Crosshair_Carweapon_WL09Rocket.Crosshair_Carweapon_WL09Rocket_C.OnAmmoCounterChanged
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void OnAmmoCounterChanged(int32_t Counter); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Crosshair_Carweapon_WL09Rocket.Crosshair_Carweapon_WL09Rocket_C.OnAmmoChanged
	// Flags: [Event|Protected|BlueprintEvent]
	void OnAmmoChanged(int32_t InReservedAmmo, int32_t InMaxAmmo, bool InbFirst); // Offset: 0x103339bc4 // Return & Params: Num(3) Size(0x9)

	// Object Name: Function Crosshair_Carweapon_WL09Rocket.Crosshair_Carweapon_WL09Rocket_C.OnUpdateReloadProgress
	// Flags: [Event|Protected|BlueprintEvent]
	void OnUpdateReloadProgress(float InReloadProgress, int32_t InReservedAmmo, int32_t InMaxAmmo); // Offset: 0x103339bc4 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function Crosshair_Carweapon_WL09Rocket.Crosshair_Carweapon_WL09Rocket_C.OnInitialized
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void OnInitialized(); // Offset: 0x103339bc4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Crosshair_Carweapon_WL09Rocket.Crosshair_Carweapon_WL09Rocket_C.OnReloadFinished
	// Flags: [Event|Protected|BlueprintEvent]
	void OnReloadFinished(bool InbReloadSuccess, int32_t InReloadAmmo, int32_t InReservedAmmo, int32_t InMaxAmmo); // Offset: 0x103339bc4 // Return & Params: Num(4) Size(0x10)

	// Object Name: Function Crosshair_Carweapon_WL09Rocket.Crosshair_Carweapon_WL09Rocket_C.OnUpdateAimTargetDistance
	// Flags: [Event|Public|BlueprintEvent]
	void OnUpdateAimTargetDistance(float InDistance); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Crosshair_Carweapon_WL09Rocket.Crosshair_Carweapon_WL09Rocket_C.ExecuteUbergraph_Crosshair_Carweapon_WL09Rocket
	// Flags: [Final|UbergraphFunction|HasDefaults]
	void ExecuteUbergraph_Crosshair_Carweapon_WL09Rocket(int32_t EntryPoint); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x4)
};

