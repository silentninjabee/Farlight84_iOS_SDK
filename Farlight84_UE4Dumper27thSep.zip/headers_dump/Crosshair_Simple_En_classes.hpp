#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Crosshair_Simple_En.Crosshair_Simple_En_C
// Size: 0x351 // Inherited bytes: 0x300
struct UCrosshair_Simple_En_C : UCrossHairWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x300 // Size: 0x08
	struct UWidgetAnimation* Simple_EN_Anim; // Offset: 0x308 // Size: 0x08
	struct UImage* ForbidImg; // Offset: 0x310 // Size: 0x08
	struct UHUD_Bullet_Simple_C* HUD_Bullet_Simple; // Offset: 0x318 // Size: 0x08
	struct UHUD_Reload_C* HUD_Reload; // Offset: 0x320 // Size: 0x08
	struct UImage* SpreadImg_coredot; // Offset: 0x328 // Size: 0x08
	struct UImage* SpreadImg_Downarrow; // Offset: 0x330 // Size: 0x08
	struct UImage* SpreadImg_Leftarrow; // Offset: 0x338 // Size: 0x08
	struct UImage* SpreadImg_Rightarrow; // Offset: 0x340 // Size: 0x08
	struct UImage* SpreadImg_uparrow; // Offset: 0x348 // Size: 0x08
	enum class E_UI_Bullet_Type ; // Offset: 0x350 // Size: 0x01

	// Functions

	// Object Name: Function Crosshair_Simple_En.Crosshair_Simple_En_C.GetReloadWidget
	// Flags: [Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent]
	struct UUserWidget* GetReloadWidget(); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Crosshair_Simple_En.Crosshair_Simple_En_C.GetAmmoWidget
	// Flags: [Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent]
	struct UUserWidget* GetAmmoWidget(); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Crosshair_Simple_En.Crosshair_Simple_En_C.Update
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void Update(); // Offset: 0x103339bc4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Crosshair_Simple_En.Crosshair_Simple_En_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Construct(); // Offset: 0x103339bc4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Crosshair_Simple_En.Crosshair_Simple_En_C.ExecuteUbergraph_Crosshair_Simple_En
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_Crosshair_Simple_En(int32_t EntryPoint); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x4)
};

