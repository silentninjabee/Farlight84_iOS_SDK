#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Crosshair_Simple_Sniper.Crosshair_Simple_Sniper_C
// Size: 0x330 // Inherited bytes: 0x300
struct UCrosshair_Simple_Sniper_C : UCrossHairWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x300 // Size: 0x08
	struct UWidgetAnimation* Sniper_Anim; // Offset: 0x308 // Size: 0x08
	struct UImage* SpreadImg_coredot; // Offset: 0x310 // Size: 0x08
	struct UImage* SpreadImg_Leftarrow; // Offset: 0x318 // Size: 0x08
	struct UImage* SpreadImg_Rightarrow; // Offset: 0x320 // Size: 0x08
	struct UImage* SpreadImg_uparrow; // Offset: 0x328 // Size: 0x08

	// Functions

	// Object Name: Function Crosshair_Simple_Sniper.Crosshair_Simple_Sniper_C.InitializeCrosshairSpread
	// Flags: [Event|Protected|BlueprintEvent]
	void InitializeCrosshairSpread(float Spread); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Crosshair_Simple_Sniper.Crosshair_Simple_Sniper_C.SetCrosshairSprite
	// Flags: [Event|Protected|BlueprintEvent]
	void SetCrosshairSprite(struct UPaperSprite* InSprite); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Crosshair_Simple_Sniper.Crosshair_Simple_Sniper_C.ExecuteUbergraph_Crosshair_Simple_Sniper
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_Crosshair_Simple_Sniper(int32_t EntryPoint); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x4)
};

