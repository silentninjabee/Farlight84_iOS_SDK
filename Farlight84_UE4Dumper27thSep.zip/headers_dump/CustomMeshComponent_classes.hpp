#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class CustomMeshComponent.CustomMeshComponent
// Size: 0x5c0 // Inherited bytes: 0x5b0
struct UCustomMeshComponent : UMeshComponent {
	// Fields
	char pad_0x5B0[0x10]; // Offset: 0x5b0 // Size: 0x10

	// Functions

	// Object Name: Function CustomMeshComponent.CustomMeshComponent.SetCustomMeshTriangles
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	bool SetCustomMeshTriangles(struct TArray<struct FCustomMeshTriangle>& Triangles); // Offset: 0x101fe93f8 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function CustomMeshComponent.CustomMeshComponent.ClearCustomMeshTriangles
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearCustomMeshTriangles(); // Offset: 0x101fe934c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function CustomMeshComponent.CustomMeshComponent.AddCustomMeshTriangles
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void AddCustomMeshTriangles(struct TArray<struct FCustomMeshTriangle>& Triangles); // Offset: 0x101fe9360 // Return & Params: Num(1) Size(0x10)
};

