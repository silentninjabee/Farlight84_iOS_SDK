#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass DefaultSolarGameModeLockSettings.DefaultSolarGameModeLockSettings_C
// Size: 0x98 // Inherited bytes: 0x98
struct UDefaultSolarGameModeLockSettings_C : USolarGameModeLockSettings {
};

