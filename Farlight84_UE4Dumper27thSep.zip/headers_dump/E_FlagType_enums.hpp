#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum E_FlagType.E_FlagType
enum class E_FlagType : uint8 {
	NationalFlag = 0,
	ClanFlag = 1,
	E MAX = 2
};

