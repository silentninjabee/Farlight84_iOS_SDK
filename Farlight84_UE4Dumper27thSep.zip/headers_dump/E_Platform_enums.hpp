#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum E_Platform.E_Platform
enum class E_Platform : uint8 {
	None = 0,
	Pc = 1,
	Phone = 2,
	Console = 3,
	Other = 4,
	E MAX = 5
};

