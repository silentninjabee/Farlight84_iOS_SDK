#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum E_ProfessionType.E_ProfessionType
enum class E_ProfessionType : uint8 {
	Assault = 0,
	Umbra = 1,
	Pulse = 2,
	Position = 3,
	E MAX = 4
};

