#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum E_Type_Btn.E_Type_Btn
enum class E_Type_Btn : uint8 {
	MainBtn = 0,
	SecondaryBtn = 1,
	ShopBtn = 2,
	StrongBtn = 3,
	WeakBtn = 4,
	LeagueBtn = 5,
	ThirdlyBtn = 6,
	ThirdlyStrongBtn = 7,
	E Type MAX = 8
};

