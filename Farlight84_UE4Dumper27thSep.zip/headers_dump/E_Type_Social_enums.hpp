#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum E_Type_Social.E_Type_Social
enum class E_Type_Social : uint8 {
	None = 0,
	Twitter = 1,
	Facebook = 2,
	E Type MAX = 3
};

