#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass Effect_Anti-vehicle_Weapon01.Effect_Anti-vehicle_Weapon01_C
// Size: 0x198 // Inherited bytes: 0x198
struct UEffect_Anti-vehicle_Weapon01_C : USolarAbilityEffect {
};

