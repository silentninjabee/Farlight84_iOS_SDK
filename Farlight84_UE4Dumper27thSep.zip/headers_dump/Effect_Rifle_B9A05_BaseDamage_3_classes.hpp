#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass Effect_Rifle_B9A05_BaseDamage_3.Effect_Rifle_B9A05_BaseDamage_2_C
// Size: 0x198 // Inherited bytes: 0x198
struct UEffect_Rifle_B9A05_BaseDamage_2_C : USolarAbilityEffect {
};

