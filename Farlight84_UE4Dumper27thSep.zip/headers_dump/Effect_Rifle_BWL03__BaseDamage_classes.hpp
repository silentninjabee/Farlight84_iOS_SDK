#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass Effect_Rifle_BWL03__BaseDamage.Effect_Rifle_BWL03__BaseDamage_C
// Size: 0x198 // Inherited bytes: 0x198
struct UEffect_Rifle_BWL03__BaseDamage_C : USolarAbilityEffect {
};

