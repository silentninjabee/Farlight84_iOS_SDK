#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass Effect_Sniper_BaseDamage.Effect_Sniper_BaseDamage_C
// Size: 0x198 // Inherited bytes: 0x198
struct UEffect_Sniper_BaseDamage_C : USolarAbilityEffect {
};

