#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass Effect_VehicleWeapon_ShapedGun.Effect_VehicleWeapon_ShapedGun_C
// Size: 0x198 // Inherited bytes: 0x198
struct UEffect_VehicleWeapon_ShapedGun_C : USolarAbilityEffect {
};

