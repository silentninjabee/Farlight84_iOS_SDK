#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum EnhancedInput.EInputActionValueType
enum class EInputActionValueType : uint8 {
	Boolean = 0,
	Axis1D = 1,
	Axis2D = 2,
	Axis3D = 3,
	EInputActionValueType_MAX = 4
};

// Object Name: Enum EnhancedInput.EMappingQueryIssue
enum class EMappingQueryIssue : uint8 {
	NoIssue = 0,
	ReservedByAction = 1,
	HidesExistingMapping = 2,
	HiddenByExistingMapping = 4,
	CollisionWithMappingInSameContext = 8,
	ForcesTypePromotion = 16,
	ForcesTypeDemotion = 32,
	EMappingQueryIssue_MAX = 33
};

// Object Name: Enum EnhancedInput.EMappingQueryResult
enum class EMappingQueryResult : uint8 {
	Error_EnhancedInputNotEnabled = 0,
	Error_InputContextNotInActiveContexts = 1,
	Error_InvalidAction = 2,
	NotMappable = 3,
	MappingAvailable = 4,
	EMappingQueryResult_MAX = 5
};

// Object Name: Enum EnhancedInput.EInputAxisSwizzle
enum class EInputAxisSwizzle : uint8 {
	YXZ = 0,
	ZYX = 1,
	XZY = 2,
	YZX = 3,
	ZXY = 4,
	EInputAxisSwizzle_MAX = 5
};

// Object Name: Enum EnhancedInput.EFOVScalingType
enum class EFOVScalingType : uint8 {
	Standard = 0,
	UE4_BackCompat = 1,
	EFOVScalingType_MAX = 2
};

// Object Name: Enum EnhancedInput.EDeadZoneType
enum class EDeadZoneType : uint8 {
	Axial = 0,
	Radial = 1,
	EDeadZoneType_MAX = 2
};

// Object Name: Enum EnhancedInput.EModifierExecutionPhase
enum class EModifierExecutionPhase : uint8 {
	PerInput = 0,
	FinalValue = 1,
	NumPhases = 2,
	EModifierExecutionPhase_MAX = 3
};

// Object Name: Enum EnhancedInput.ETriggerTypeEx
enum class ETriggerTypeEx : uint8 {
	Explicit = 0,
	Implicit = 1,
	Blocker = 2,
	ETriggerTypeEx_MAX = 3
};

// Object Name: Enum EnhancedInput.ETriggerEvent
enum class ETriggerEvent : uint8 {
	None = 0,
	Started = 1,
	Ongoing = 2,
	Canceled = 3,
	Triggered = 4,
	Completed = 5,
	ETriggerEvent_MAX = 6
};

// Object Name: Enum EnhancedInput.ETriggerState
enum class ETriggerState : uint8 {
	None = 0,
	Ongoing = 1,
	Triggered = 2,
	ETriggerState_MAX = 3
};

