#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct EyeTracker.EyeTrackerStereoGazeData
// Size: 0x40 // Inherited bytes: 0x00
struct FEyeTrackerStereoGazeData {
	// Fields
	struct FVector LeftEyeOrigin; // Offset: 0x00 // Size: 0x0c
	struct FVector LeftEyeDirection; // Offset: 0x0c // Size: 0x0c
	struct FVector RightEyeOrigin; // Offset: 0x18 // Size: 0x0c
	struct FVector RightEyeDirection; // Offset: 0x24 // Size: 0x0c
	struct FVector FixationPoint; // Offset: 0x30 // Size: 0x0c
	float ConfidenceValue; // Offset: 0x3c // Size: 0x04
};

// Object Name: ScriptStruct EyeTracker.EyeTrackerGazeData
// Size: 0x28 // Inherited bytes: 0x00
struct FEyeTrackerGazeData {
	// Fields
	struct FVector GazeOrigin; // Offset: 0x00 // Size: 0x0c
	struct FVector GazeDirection; // Offset: 0x0c // Size: 0x0c
	struct FVector FixationPoint; // Offset: 0x18 // Size: 0x0c
	float ConfidenceValue; // Offset: 0x24 // Size: 0x04
};

