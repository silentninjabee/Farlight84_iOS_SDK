#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class GeometryCache.GeometryCache
// Size: 0x68 // Inherited bytes: 0x28
struct UGeometryCache : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08
	struct TArray<struct UMaterialInterface*> Materials; // Offset: 0x30 // Size: 0x10
	struct TArray<struct UGeometryCacheTrack*> Tracks; // Offset: 0x40 // Size: 0x10
	char pad_0x50[0x10]; // Offset: 0x50 // Size: 0x10
	int32_t StartFrame; // Offset: 0x60 // Size: 0x04
	int32_t EndFrame; // Offset: 0x64 // Size: 0x04
};

// Object Name: Class GeometryCache.GeometryCacheActor
// Size: 0x230 // Inherited bytes: 0x228
struct AGeometryCacheActor : AActor {
	// Fields
	struct UGeometryCacheComponent* GeometryCacheComponent; // Offset: 0x228 // Size: 0x08

	// Functions

	// Object Name: Function GeometryCache.GeometryCacheActor.GetGeometryCacheComponent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UGeometryCacheComponent* GetGeometryCacheComponent(); // Offset: 0x101eae46c // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class GeometryCache.GeometryCacheCodecBase
// Size: 0x38 // Inherited bytes: 0x28
struct UGeometryCacheCodecBase : UObject {
	// Fields
	struct TArray<int32_t> TopologyRanges; // Offset: 0x28 // Size: 0x10
};

// Object Name: Class GeometryCache.GeometryCacheCodecRaw
// Size: 0x40 // Inherited bytes: 0x38
struct UGeometryCacheCodecRaw : UGeometryCacheCodecBase {
	// Fields
	int32_t DummyProperty; // Offset: 0x38 // Size: 0x04
	char pad_0x3C[0x4]; // Offset: 0x3c // Size: 0x04
};

// Object Name: Class GeometryCache.GeometryCacheCodecV1
// Size: 0x40 // Inherited bytes: 0x38
struct UGeometryCacheCodecV1 : UGeometryCacheCodecBase {
	// Fields
	char pad_0x38[0x8]; // Offset: 0x38 // Size: 0x08
};

// Object Name: Class GeometryCache.GeometryCacheComponent
// Size: 0x600 // Inherited bytes: 0x5b0
struct UGeometryCacheComponent : UMeshComponent {
	// Fields
	struct UGeometryCache* GeometryCache; // Offset: 0x5a8 // Size: 0x08
	bool bRunning; // Offset: 0x5b0 // Size: 0x01
	bool bLooping; // Offset: 0x5b1 // Size: 0x01
	float StartTimeOffset; // Offset: 0x5b4 // Size: 0x04
	float PlaybackSpeed; // Offset: 0x5b8 // Size: 0x04
	int32_t NumTracks; // Offset: 0x5bc // Size: 0x04
	float ElapsedTime; // Offset: 0x5c0 // Size: 0x04
	char pad_0x5CA[0x2a]; // Offset: 0x5ca // Size: 0x2a
	float Duration; // Offset: 0x5f4 // Size: 0x04
	bool bManualTick; // Offset: 0x5f8 // Size: 0x01
	char pad_0x5F9[0x7]; // Offset: 0x5f9 // Size: 0x07

	// Functions

	// Object Name: Function GeometryCache.GeometryCacheComponent.TickAtThisTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	void TickAtThisTime(float Time, bool bInIsRunning, bool bInBackwards, bool bInIsLooping); // Offset: 0x101eaec8c // Return & Params: Num(4) Size(0x7)

	// Object Name: Function GeometryCache.GeometryCacheComponent.Stop
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Stop(); // Offset: 0x101eaf204 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function GeometryCache.GeometryCacheComponent.SetStartTimeOffset
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetStartTimeOffset(float NewStartTimeOffset); // Offset: 0x101eaeee8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function GeometryCache.GeometryCacheComponent.SetPlaybackSpeed
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPlaybackSpeed(float NewPlaybackSpeed); // Offset: 0x101eaf02c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function GeometryCache.GeometryCacheComponent.SetLooping
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetLooping(bool bNewLooping); // Offset: 0x101eaf0e0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function GeometryCache.GeometryCacheComponent.SetGeometryCache
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool SetGeometryCache(struct UGeometryCache* NewGeomCache); // Offset: 0x101eaef9c // Return & Params: Num(2) Size(0x9)

	// Object Name: Function GeometryCache.GeometryCacheComponent.PlayReversedFromEnd
	// Flags: [Final|Native|Public|BlueprintCallable]
	void PlayReversedFromEnd(); // Offset: 0x101eaf22c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function GeometryCache.GeometryCacheComponent.PlayReversed
	// Flags: [Final|Native|Public|BlueprintCallable]
	void PlayReversed(); // Offset: 0x101eaf240 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function GeometryCache.GeometryCacheComponent.PlayFromStart
	// Flags: [Final|Native|Public|BlueprintCallable]
	void PlayFromStart(); // Offset: 0x101eaf254 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function GeometryCache.GeometryCacheComponent.Play
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Play(); // Offset: 0x101eaf268 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function GeometryCache.GeometryCacheComponent.Pause
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Pause(); // Offset: 0x101eaf218 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function GeometryCache.GeometryCacheComponent.IsPlayingReversed
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsPlayingReversed(); // Offset: 0x101eaf19c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function GeometryCache.GeometryCacheComponent.IsPlaying
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsPlaying(); // Offset: 0x101eaf1d0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function GeometryCache.GeometryCacheComponent.IsLooping
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsLooping(); // Offset: 0x101eaf168 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function GeometryCache.GeometryCacheComponent.GetStartTimeOffset
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetStartTimeOffset(); // Offset: 0x101eaef68 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function GeometryCache.GeometryCacheComponent.GetPlaybackSpeed
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetPlaybackSpeed(); // Offset: 0x101eaf0ac // Return & Params: Num(1) Size(0x4)

	// Object Name: Function GeometryCache.GeometryCacheComponent.GetPlaybackDirection
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetPlaybackDirection(); // Offset: 0x101eaee80 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function GeometryCache.GeometryCacheComponent.GetNumberOfFrames
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetNumberOfFrames(); // Offset: 0x101eaee18 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function GeometryCache.GeometryCacheComponent.GetDuration
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetDuration(); // Offset: 0x101eaee4c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function GeometryCache.GeometryCacheComponent.GetAnimationTime
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetAnimationTime(); // Offset: 0x101eaeeb4 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class GeometryCache.GeometryCacheTrack
// Size: 0x58 // Inherited bytes: 0x28
struct UGeometryCacheTrack : UObject {
	// Fields
	float Duration; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x2c]; // Offset: 0x2c // Size: 0x2c
};

// Object Name: Class GeometryCache.GeometryCacheTrack_FlipbookAnimation
// Size: 0x78 // Inherited bytes: 0x58
struct UGeometryCacheTrack_FlipbookAnimation : UGeometryCacheTrack {
	// Fields
	uint32_t NumMeshSamples; // Offset: 0x54 // Size: 0x04
	char pad_0x5C[0x1c]; // Offset: 0x5c // Size: 0x1c

	// Functions

	// Object Name: Function GeometryCache.GeometryCacheTrack_FlipbookAnimation.AddMeshSample
	// Flags: [Final|Native|Public|HasOutParms]
	void AddMeshSample(struct FGeometryCacheMeshData& MeshData, float SampleTime); // Offset: 0x101eaff98 // Return & Params: Num(2) Size(0xac)
};

// Object Name: Class GeometryCache.GeometryCacheTrackStreamable
// Size: 0xd0 // Inherited bytes: 0x58
struct UGeometryCacheTrackStreamable : UGeometryCacheTrack {
	// Fields
	struct UGeometryCacheCodecBase* Codec; // Offset: 0x58 // Size: 0x08
	char pad_0x60[0x68]; // Offset: 0x60 // Size: 0x68
	float StartSampleTime; // Offset: 0xc8 // Size: 0x04
	char pad_0xCC[0x4]; // Offset: 0xcc // Size: 0x04
};

// Object Name: Class GeometryCache.GeometryCacheTrack_TransformAnimation
// Size: 0x100 // Inherited bytes: 0x58
struct UGeometryCacheTrack_TransformAnimation : UGeometryCacheTrack {
	// Fields
	char pad_0x58[0xa8]; // Offset: 0x58 // Size: 0xa8

	// Functions

	// Object Name: Function GeometryCache.GeometryCacheTrack_TransformAnimation.SetMesh
	// Flags: [Final|Native|Public|HasOutParms]
	void SetMesh(struct FGeometryCacheMeshData& NewMeshData); // Offset: 0x101eb04a8 // Return & Params: Num(1) Size(0xa8)
};

// Object Name: Class GeometryCache.GeometryCacheTrack_TransformGroupAnimation
// Size: 0x100 // Inherited bytes: 0x58
struct UGeometryCacheTrack_TransformGroupAnimation : UGeometryCacheTrack {
	// Fields
	char pad_0x58[0xa8]; // Offset: 0x58 // Size: 0xa8

	// Functions

	// Object Name: Function GeometryCache.GeometryCacheTrack_TransformGroupAnimation.SetMesh
	// Flags: [Final|Native|Public|HasOutParms]
	void SetMesh(struct FGeometryCacheMeshData& NewMeshData); // Offset: 0x101eb0774 // Return & Params: Num(1) Size(0xa8)
};

