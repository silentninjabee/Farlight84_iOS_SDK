#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct GeometryCache.TrackRenderData
// Size: 0x70 // Inherited bytes: 0x00
struct FTrackRenderData {
	// Fields
	char pad_0x0[0x70]; // Offset: 0x00 // Size: 0x70
};

// Object Name: ScriptStruct GeometryCache.GeometryCacheMeshData
// Size: 0xa8 // Inherited bytes: 0x00
struct FGeometryCacheMeshData {
	// Fields
	char pad_0x0[0xa8]; // Offset: 0x00 // Size: 0xa8
};

// Object Name: ScriptStruct GeometryCache.GeometryCacheVertexInfo
// Size: 0x08 // Inherited bytes: 0x00
struct FGeometryCacheVertexInfo {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct GeometryCache.GeometryCacheMeshBatchInfo
// Size: 0x0c // Inherited bytes: 0x00
struct FGeometryCacheMeshBatchInfo {
	// Fields
	char pad_0x0[0xc]; // Offset: 0x00 // Size: 0x0c
};

