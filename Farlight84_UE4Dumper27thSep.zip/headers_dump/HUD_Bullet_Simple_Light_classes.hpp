#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass HUD_Bullet_Simple_Light.HUD_Bullet_Simple_Light_C
// Size: 0x271 // Inherited bytes: 0x260
struct UHUD_Bullet_Simple_Light_C : UUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x260 // Size: 0x08
	struct UWidgetAnimation* Gauge_Anim; // Offset: 0x268 // Size: 0x08
	enum class E_UI_Bullet_Type ; // Offset: 0x270 // Size: 0x01

	// Functions

	// Object Name: Function HUD_Bullet_Simple_Light.HUD_Bullet_Simple_Light_C.BP_OnEntryReleased
	// Flags: [Event|Protected|BlueprintEvent]
	void BP_OnEntryReleased(); // Offset: 0x103339bc4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function HUD_Bullet_Simple_Light.HUD_Bullet_Simple_Light_C.BP_OnItemExpansionChanged
	// Flags: [Event|Protected|BlueprintEvent]
	void BP_OnItemExpansionChanged(bool bIsExpanded); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function HUD_Bullet_Simple_Light.HUD_Bullet_Simple_Light_C.BP_OnItemSelectionChanged
	// Flags: [Event|Protected|BlueprintEvent]
	void BP_OnItemSelectionChanged(bool bIsSelected); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function HUD_Bullet_Simple_Light.HUD_Bullet_Simple_Light_C.OnListItemObjectSet
	// Flags: [Event|Protected|BlueprintEvent]
	void OnListItemObjectSet(struct UObject* ListItemObject); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function HUD_Bullet_Simple_Light.HUD_Bullet_Simple_Light_C.ExecuteUbergraph_HUD_Bullet_Simple_Light
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_HUD_Bullet_Simple_Light(int32_t EntryPoint); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x4)
};

