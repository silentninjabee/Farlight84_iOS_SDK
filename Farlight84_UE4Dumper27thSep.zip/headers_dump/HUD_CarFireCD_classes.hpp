#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass HUD_CarFireCD.HUD_CarFireCD_C
// Size: 0x360 // Inherited bytes: 0x360
struct UHUD_CarFireCD_C : USolarWeaponRechamberWidget {
};

