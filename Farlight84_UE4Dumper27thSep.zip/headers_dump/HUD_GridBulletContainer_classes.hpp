#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass HUD_GridBulletContainer.HUD_GridBulletContainer_C
// Size: 0x650 // Inherited bytes: 0x438
struct UHUD_GridBulletContainer_C : UGridBulletContainer {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x438 // Size: 0x08
	struct UImage* bg_BulletEmpty; // Offset: 0x440 // Size: 0x08
	struct UImage* bg_BulletEmptyShine; // Offset: 0x448 // Size: 0x08
	struct UImage* bg_BulletGrid; // Offset: 0x450 // Size: 0x08
	struct UImage* Img_LightAll; // Offset: 0x458 // Size: 0x08
	int32_t CurrentBulletForDebug; // Offset: 0x460 // Size: 0x04
	int32_t MaxBulletForDebug; // Offset: 0x464 // Size: 0x04
	struct FProgressBarStyle NewVar_1; // Offset: 0x468 // Size: 0x1d0
	bool IsMaxAmmoChanged; // Offset: 0x638 // Size: 0x01
	char pad_0x639[0x7]; // Offset: 0x639 // Size: 0x07
	struct TArray<struct UWidget*> DivisorWidgetArray; // Offset: 0x640 // Size: 0x10

	// Functions

	// Object Name: Function HUD_GridBulletContainer.HUD_GridBulletContainer_C.ReceiveUpdateMaxAmmoEvent
	// Flags: [Event|Protected|BlueprintCallable|BlueprintEvent]
	void ReceiveUpdateMaxAmmoEvent(int32_t InMaxAmmo); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function HUD_GridBulletContainer.HUD_GridBulletContainer_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Construct(); // Offset: 0x103339bc4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function HUD_GridBulletContainer.HUD_GridBulletContainer_C.ExecuteUbergraph_HUD_GridBulletContainer
	// Flags: [Final|UbergraphFunction|HasDefaults]
	void ExecuteUbergraph_HUD_GridBulletContainer(int32_t EntryPoint); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x4)
};

