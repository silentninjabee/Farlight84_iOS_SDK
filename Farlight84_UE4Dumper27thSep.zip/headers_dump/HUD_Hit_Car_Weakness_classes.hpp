#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass HUD_Hit_Car_Weakness.HUD_Hit_Car_Weakness_C
// Size: 0x350 // Inherited bytes: 0x348
struct UHUD_Hit_Car_Weakness_C : USolarUserWidget {
	// Fields
	struct UWidgetAnimation* Anim_Hit_Car_Weakness; // Offset: 0x348 // Size: 0x08
};

