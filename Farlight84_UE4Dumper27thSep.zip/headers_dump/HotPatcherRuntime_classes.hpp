#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class HotPatcherRuntime.FlibAssetManageHelper
// Size: 0x28 // Inherited bytes: 0x28
struct UFlibAssetManageHelper : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function HotPatcherRuntime.FlibAssetManageHelper.SaveStringToFile
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool SaveStringToFile(struct FString InFile, struct FString inString); // Offset: 0x101e538e8 // Return & Params: Num(3) Size(0x21)

	// Object Name: Function HotPatcherRuntime.FlibAssetManageHelper.PackagePathToFilename
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString PackagePathToFilename(struct FString InPackagePath); // Offset: 0x101e54a04 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function HotPatcherRuntime.FlibAssetManageHelper.ModuleIsEnabled
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool ModuleIsEnabled(struct FString InModuleName); // Offset: 0x101e534b8 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function HotPatcherRuntime.FlibAssetManageHelper.LongPackageNameToPackagePath
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString LongPackageNameToPackagePath(struct FString InLongPackageName); // Offset: 0x101e54850 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function HotPatcherRuntime.FlibAssetManageHelper.LoadFileToString
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool LoadFileToString(struct FString InFile, struct FString& OutString); // Offset: 0x101e537f8 // Return & Params: Num(3) Size(0x21)

	// Object Name: Function HotPatcherRuntime.FlibAssetManageHelper.GetSpecifyAssetDetail
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	bool GetSpecifyAssetDetail(struct FString InLongPackageName, struct FAssetDetail& OutAssetDetail); // Offset: 0x101e541cc // Return & Params: Num(3) Size(0x29)

	// Object Name: Function HotPatcherRuntime.FlibAssetManageHelper.GetRedirectorList
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	bool GetRedirectorList(struct TArray<struct FString>& InFilterPackagePaths, struct TArray<struct FAssetDetail>& OutRedirector); // Offset: 0x101e542b8 // Return & Params: Num(3) Size(0x21)

	// Object Name: Function HotPatcherRuntime.FlibAssetManageHelper.GetPluginModuleAbsDir
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool GetPluginModuleAbsDir(struct FString InPluginModuleName, struct FString& OutPath); // Offset: 0x101e532d8 // Return & Params: Num(3) Size(0x21)

	// Object Name: Function HotPatcherRuntime.FlibAssetManageHelper.GetModuleNameByRelativePath
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool GetModuleNameByRelativePath(struct FString InRelativePath, struct FString& OutModuleName); // Offset: 0x101e53544 // Return & Params: Num(3) Size(0x21)

	// Object Name: Function HotPatcherRuntime.FlibAssetManageHelper.GetEnableModuleAbsDir
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool GetEnableModuleAbsDir(struct FString InModuleName, struct FString& OutPath); // Offset: 0x101e533c8 // Return & Params: Num(3) Size(0x21)

	// Object Name: Function HotPatcherRuntime.FlibAssetManageHelper.GetAssetReferenceEx
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	bool GetAssetReferenceEx(struct FAssetDetail& InAsset, struct TArray<enum class EAssetRegistryDependencyTypeEx>& SearchAssetDepTypes, struct TArray<struct FAssetDetail>& OutRefAsset); // Offset: 0x101e543e8 // Return & Params: Num(4) Size(0x39)

	// Object Name: Function HotPatcherRuntime.FlibAssetManageHelper.GetAssetPackageGUID
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool GetAssetPackageGUID(struct FString InPackagePath, struct FName& OutGUID); // Offset: 0x101e5476c // Return & Params: Num(3) Size(0x19)

	// Object Name: Function HotPatcherRuntime.FlibAssetManageHelper.GetAllEnabledModuleName
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetAllEnabledModuleName(struct TMap<struct FString, struct FString>& OutModules); // Offset: 0x101e53634 // Return & Params: Num(1) Size(0x50)

	// Object Name: Function HotPatcherRuntime.FlibAssetManageHelper.FindFilesRecursive
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool FindFilesRecursive(struct FString InStartDir, struct TArray<struct FString>& OutFileList, bool InRecursive); // Offset: 0x101e53160 // Return & Params: Num(4) Size(0x22)

	// Object Name: Function HotPatcherRuntime.FlibAssetManageHelper.FilterNoRefAssetsWithIgnoreFilter
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	void FilterNoRefAssetsWithIgnoreFilter(struct TArray<struct FAssetDetail>& InAssetsDetail, struct TArray<struct FString>& InIgnoreFilters, struct TArray<struct FAssetDetail>& OutHasRefAssetsDetail, struct TArray<struct FAssetDetail>& OutDontHasRefAssetsDetail); // Offset: 0x101e53e9c // Return & Params: Num(4) Size(0x40)

	// Object Name: Function HotPatcherRuntime.FlibAssetManageHelper.FilterNoRefAssets
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	void FilterNoRefAssets(struct TArray<struct FAssetDetail>& InAssetsDetail, struct TArray<struct FAssetDetail>& OutHasRefAssetsDetail, struct TArray<struct FAssetDetail>& OutDontHasRefAssetsDetail); // Offset: 0x101e5407c // Return & Params: Num(3) Size(0x30)

	// Object Name: Function HotPatcherRuntime.FlibAssetManageHelper.FilenameToPackagePath
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool FilenameToPackagePath(struct FString InAbsPath, struct FString& OutPackagePath); // Offset: 0x101e54914 // Return & Params: Num(3) Size(0x21)

	// Object Name: Function HotPatcherRuntime.FlibAssetManageHelper.ExportCookPakCommandToFile
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool ExportCookPakCommandToFile(struct TArray<struct FString>& InCommand, struct FString InFile); // Offset: 0x101e539cc // Return & Params: Num(3) Size(0x21)

	// Object Name: Function HotPatcherRuntime.FlibAssetManageHelper.ConvRelativeDirToAbsDir
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool ConvRelativeDirToAbsDir(struct FString InRelativePath, struct FString& OutAbsPath); // Offset: 0x101e53708 // Return & Params: Num(3) Size(0x21)

	// Object Name: Function HotPatcherRuntime.FlibAssetManageHelper.ConvLongPackageNameToCookedPath
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool ConvLongPackageNameToCookedPath(struct FString InProjectAbsDir, struct FString InPlatformName, struct FString InLongPackageName, struct TArray<struct FString>& OutCookedAssetPath, struct TArray<struct FString>& OutCookedAssetRelativePath); // Offset: 0x101e53af0 // Return & Params: Num(6) Size(0x51)

	// Object Name: Function HotPatcherRuntime.FlibAssetManageHelper.CombineAssetsDetailAsFAssetDepenInfo
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	bool CombineAssetsDetailAsFAssetDepenInfo(struct TArray<struct FAssetDetail>& InAssetsDetailList, struct FAssetDependenciesInfo& OutAssetInfo); // Offset: 0x101e53d5c // Return & Params: Num(3) Size(0x61)

	// Object Name: Function HotPatcherRuntime.FlibAssetManageHelper.CombineAssetDependencies
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FAssetDependenciesInfo CombineAssetDependencies(struct FAssetDependenciesInfo& A, struct FAssetDependenciesInfo& B); // Offset: 0x101e54538 // Return & Params: Num(3) Size(0xf0)
};

// Object Name: Class HotPatcherRuntime.FlibPakHelper
// Size: 0x28 // Inherited bytes: 0x28
struct UFlibPakHelper : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function HotPatcherRuntime.FlibPakHelper.UnMountPak
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool UnMountPak(struct FString PakPath); // Offset: 0x101e5d018 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function HotPatcherRuntime.FlibPakHelper.ScanPlatformDirectory
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool ScanPlatformDirectory(struct FString InRelativePath, bool bIncludeFile, bool bIncludeDir, bool bRecursively, struct TArray<struct FString>& OutResault); // Offset: 0x101e5cca0 // Return & Params: Num(6) Size(0x29)

	// Object Name: Function HotPatcherRuntime.FlibPakHelper.ScanExtenPakFiles
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct TArray<struct FString> ScanExtenPakFiles(); // Offset: 0x101e5c8dc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function HotPatcherRuntime.FlibPakHelper.ScanExtenFilesInDirectory
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool ScanExtenFilesInDirectory(struct FString InRelativePath, struct FString InExtenPostfix, bool InRecursively, struct TArray<struct FString>& OutFiles); // Offset: 0x101e5cac4 // Return & Params: Num(5) Size(0x39)

	// Object Name: Function HotPatcherRuntime.FlibPakHelper.ScanAllVersionDescribleFiles
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct TArray<struct FString> ScanAllVersionDescribleFiles(); // Offset: 0x101e5c9d0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function HotPatcherRuntime.FlibPakHelper.ReloadShaderbytecode
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void ReloadShaderbytecode(); // Offset: 0x101e5c6bc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function HotPatcherRuntime.FlibPakHelper.OpenPSO
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool OpenPSO(struct FString Name); // Offset: 0x101e5c6d0 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function HotPatcherRuntime.FlibPakHelper.MountPak
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool MountPak(struct FString PakPath, int32_t PakOrder, struct FString InMountPoint); // Offset: 0x101e5d0a4 // Return & Params: Num(4) Size(0x29)

	// Object Name: Function HotPatcherRuntime.FlibPakHelper.LoadShaderbytecode
	// Flags: [Final|Exec|Native|Static|Public|BlueprintCallable]
	bool LoadShaderbytecode(struct FString LibraryName, struct FString LibraryDir); // Offset: 0x101e5c5d8 // Return & Params: Num(3) Size(0x21)

	// Object Name: Function HotPatcherRuntime.FlibPakHelper.LoadAssetRegistry
	// Flags: [Final|Exec|Native|Static|Public|BlueprintCallable]
	bool LoadAssetRegistry(struct FString LibraryName, struct FString LibraryDir); // Offset: 0x101e5c470 // Return & Params: Num(3) Size(0x21)

	// Object Name: Function HotPatcherRuntime.FlibPakHelper.GetPakOrderByPakPath
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int32_t GetPakOrderByPakPath(struct FString PakFile); // Offset: 0x101e5c75c // Return & Params: Num(2) Size(0x14)

	// Object Name: Function HotPatcherRuntime.FlibPakHelper.GetAllMountedPaks
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct TArray<struct FString> GetAllMountedPaks(); // Offset: 0x101e5c7e8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function HotPatcherRuntime.FlibPakHelper.ExecMountPak
	// Flags: [Final|Exec|Native|Static|Public]
	void ExecMountPak(struct FString InPakPath, int32_t InPakOrder, struct FString InMountPoint); // Offset: 0x101e5d1d4 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function HotPatcherRuntime.FlibPakHelper.CreateFileByBytes
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool CreateFileByBytes(struct FString InFile, struct TArray<char>& InBytes, int32_t InWriteFlag); // Offset: 0x101e5cedc // Return & Params: Num(4) Size(0x25)

	// Object Name: Function HotPatcherRuntime.FlibPakHelper.CloseShaderbytecode
	// Flags: [Final|Exec|Native|Static|Public|BlueprintCallable]
	void CloseShaderbytecode(struct FString LibraryName); // Offset: 0x101e5c554 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class HotPatcherRuntime.FlibPatchParserHelper
// Size: 0x28 // Inherited bytes: 0x28
struct UFlibPatchParserHelper : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function HotPatcherRuntime.FlibPatchParserHelper.ReloadShaderbytecode
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void ReloadShaderbytecode(); // Offset: 0x101e5dc20 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function HotPatcherRuntime.FlibPatchParserHelper.LoadShaderbytecode
	// Flags: [Final|Exec|Native|Static|Public|BlueprintCallable]
	bool LoadShaderbytecode(struct FString LibraryName, struct FString LibraryDir); // Offset: 0x101e5db3c // Return & Params: Num(3) Size(0x21)

	// Object Name: Function HotPatcherRuntime.FlibPatchParserHelper.HashStringWithSHA1
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString HashStringWithSHA1(struct FString inString); // Offset: 0x101e5e1b4 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function HotPatcherRuntime.FlibPatchParserHelper.GetProjectName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetProjectName(); // Offset: 0x101e5f12c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function HotPatcherRuntime.FlibPatchParserHelper.GetProjectIniFiles
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct TArray<struct FString> GetProjectIniFiles(struct FString InProjectDir, struct FString InPlatformName); // Offset: 0x101e5de9c // Return & Params: Num(3) Size(0x30)

	// Object Name: Function HotPatcherRuntime.FlibPatchParserHelper.GetProjectFilePath
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetProjectFilePath(); // Offset: 0x101e5f0ac // Return & Params: Num(1) Size(0x10)

	// Object Name: Function HotPatcherRuntime.FlibPatchParserHelper.GetPakFileInfo
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool GetPakFileInfo(struct FString InFile, struct FPakFileInfo& OutFileInfo); // Offset: 0x101e5e830 // Return & Params: Num(3) Size(0x39)

	// Object Name: Function HotPatcherRuntime.FlibPatchParserHelper.GetIniConfigs
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct TArray<struct FString> GetIniConfigs(struct FString InSearchDir, struct FString InPlatformName); // Offset: 0x101e5e028 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function HotPatcherRuntime.FlibPatchParserHelper.GetEngineConfigs
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct TArray<struct FString> GetEngineConfigs(struct FString InPlatformName); // Offset: 0x101e5dd68 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function HotPatcherRuntime.FlibPatchParserHelper.GetEnabledPluginConfigs
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct TArray<struct FString> GetEnabledPluginConfigs(struct FString InPlatformName); // Offset: 0x101e5dc34 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function HotPatcherRuntime.FlibPatchParserHelper.GetCookedShaderBytecodeFiles
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool GetCookedShaderBytecodeFiles(struct FString InProjectAbsDir, struct FString InProjectName, struct FString InPlatformName, bool InGalobalBytecode, bool InProjectBytecode, struct TArray<struct FString>& OutFiles); // Offset: 0x101e5e278 // Return & Params: Num(7) Size(0x49)

	// Object Name: Function HotPatcherRuntime.FlibPatchParserHelper.GetCookedGlobalShaderCacheFiles
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct TArray<struct FString> GetCookedGlobalShaderCacheFiles(struct FString InProjectDir, struct FString InPlatformName); // Offset: 0x101e5e6a4 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function HotPatcherRuntime.FlibPatchParserHelper.GetCookedAssetRegistryFiles
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool GetCookedAssetRegistryFiles(struct FString InProjectAbsDir, struct FString InProjectName, struct FString InPlatformName, struct FString& OutFiles); // Offset: 0x101e5e504 // Return & Params: Num(5) Size(0x41)

	// Object Name: Function HotPatcherRuntime.FlibPatchParserHelper.GetAvailableMaps
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct TArray<struct FString> GetAvailableMaps(struct FString GameName, bool IncludeEngineMaps, bool IncludePluginMaps, bool Sorted); // Offset: 0x101e5f1ac // Return & Params: Num(5) Size(0x28)

	// Object Name: Function HotPatcherRuntime.FlibPatchParserHelper.GetAllExFilesByPlatform
	// Flags: [Final|Native|Static|Public|HasOutParms]
	struct FPlatformExternFiles GetAllExFilesByPlatform(struct FPlatformExternAssets& InPlatformConf, bool InGeneratedHash); // Offset: 0x101e5e93c // Return & Params: Num(3) Size(0x48)

	// Object Name: Function HotPatcherRuntime.FlibPatchParserHelper.DiffVersionAssets
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool DiffVersionAssets(struct FAssetDependenciesInfo& InNewVersion, struct FAssetDependenciesInfo& InBaseVersion, struct FAssetDependenciesInfo& OutAddAsset, struct FAssetDependenciesInfo& OutModifyAsset, struct FAssetDependenciesInfo& OutDeleteAsset); // Offset: 0x101e5ed40 // Return & Params: Num(6) Size(0x191)

	// Object Name: Function HotPatcherRuntime.FlibPatchParserHelper.DiffVersionAllPlatformExFiles
	// Flags: [Final|Native|Static|Public|HasOutParms]
	bool DiffVersionAllPlatformExFiles(struct FHotPatcherVersion& InBaseVersion, struct FHotPatcherVersion& InNewVersion, struct TMap<enum class ETargetPlatform, struct FPatchVersionExternDiff>& OutDiff); // Offset: 0x101e5eafc // Return & Params: Num(4) Size(0x281)

	// Object Name: Function HotPatcherRuntime.FlibPatchParserHelper.CloseShaderbytecode
	// Flags: [Final|Exec|Native|Static|Public|BlueprintCallable]
	void CloseShaderbytecode(struct FString LibraryName); // Offset: 0x101e5dab8 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class HotPatcherRuntime.FlibShaderPipelineCacheHelper
// Size: 0x28 // Inherited bytes: 0x28
struct UFlibShaderPipelineCacheHelper : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function HotPatcherRuntime.FlibShaderPipelineCacheHelper.SavePipelineFileCache
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool SavePipelineFileCache(enum class EPSOSaveMode Mode); // Offset: 0x101e5ff88 // Return & Params: Num(2) Size(0x2)

	// Object Name: Function HotPatcherRuntime.FlibShaderPipelineCacheHelper.LoadShaderPipelineCache
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool LoadShaderPipelineCache(struct FString Name); // Offset: 0x101e60090 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function HotPatcherRuntime.FlibShaderPipelineCacheHelper.IsEnabledUsePSO
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsEnabledUsePSO(); // Offset: 0x101e5fe44 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function HotPatcherRuntime.FlibShaderPipelineCacheHelper.IsEnabledSaveBoundPSOLog
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsEnabledSaveBoundPSOLog(); // Offset: 0x101e5fddc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function HotPatcherRuntime.FlibShaderPipelineCacheHelper.IsEnabledLogPSO
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsEnabledLogPSO(); // Offset: 0x101e5fe10 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function HotPatcherRuntime.FlibShaderPipelineCacheHelper.EnableShaderPipelineCache
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool EnableShaderPipelineCache(bool bEnable); // Offset: 0x101e60008 // Return & Params: Num(2) Size(0x2)

	// Object Name: Function HotPatcherRuntime.FlibShaderPipelineCacheHelper.EnableSaveBoundPSOLog
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool EnableSaveBoundPSOLog(bool bEnable); // Offset: 0x101e5fe78 // Return & Params: Num(2) Size(0x2)

	// Object Name: Function HotPatcherRuntime.FlibShaderPipelineCacheHelper.EnableLogPSO
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool EnableLogPSO(bool bEnable); // Offset: 0x101e5ff00 // Return & Params: Num(2) Size(0x2)
};

// Object Name: Class HotPatcherRuntime.MountListener
// Size: 0x98 // Inherited bytes: 0x28
struct UMountListener : UObject {
	// Fields
	struct FMulticastInlineDelegate OnMountPakDelegate; // Offset: 0x28 // Size: 0x10
	struct FMulticastInlineDelegate OnUnMountPakDelegate; // Offset: 0x38 // Size: 0x10
	char pad_0x48[0x50]; // Offset: 0x48 // Size: 0x50

	// Functions

	// Object Name: Function HotPatcherRuntime.MountListener.Init
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Init(); // Offset: 0x101e679c8 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class HotPatcherRuntime.ScopedSlowTaskContext
// Size: 0x30 // Inherited bytes: 0x28
struct UScopedSlowTaskContext : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08
};

