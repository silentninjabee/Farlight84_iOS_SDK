#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass ImageTween.ImageTween_C
// Size: 0x3d0 // Inherited bytes: 0x3d0
struct UImageTween_C : UTweenImage {
};

