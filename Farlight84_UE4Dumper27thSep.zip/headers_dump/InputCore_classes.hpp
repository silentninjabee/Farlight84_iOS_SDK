#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class InputCore.InputCoreTypes
// Size: 0x28 // Inherited bytes: 0x28
struct UInputCoreTypes : UObject {
};

