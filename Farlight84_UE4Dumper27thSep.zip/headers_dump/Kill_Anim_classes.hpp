#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass Kill_Anim.Kill_Anim_C
// Size: 0x278 // Inherited bytes: 0x260
struct UKill_Anim_C : UUserWidget {
	// Fields
	struct UWidgetAnimation* KnockDown_Anim; // Offset: 0x260 // Size: 0x08
	struct UWidgetAnimation* Kill_Anim; // Offset: 0x268 // Size: 0x08
	struct UCanvasPanel* Panel_Kill; // Offset: 0x270 // Size: 0x08
};

