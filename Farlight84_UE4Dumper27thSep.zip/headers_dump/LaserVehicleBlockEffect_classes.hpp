#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass LaserVehicleBlockEffect.LaserVehicleBlockEffect_C
// Size: 0x848 // Inherited bytes: 0x848
struct ULaserVehicleBlockEffect_C : UGameplayEffect {
};

