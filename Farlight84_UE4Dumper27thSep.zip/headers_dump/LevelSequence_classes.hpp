#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class LevelSequence.LevelSequence
// Size: 0x498 // Inherited bytes: 0x348
struct ULevelSequence : UMovieSceneSequence {
	// Fields
	struct UMovieScene* MovieScene; // Offset: 0x348 // Size: 0x08
	struct FLevelSequenceObjectReferenceMap ObjectReferences; // Offset: 0x350 // Size: 0x50
	struct FLevelSequenceBindingReferences BindingReferences; // Offset: 0x3a0 // Size: 0xa0
	struct TMap<struct FString, struct FLevelSequenceObject> PossessedObjects; // Offset: 0x440 // Size: 0x50
	struct UObject* DirectorClass; // Offset: 0x490 // Size: 0x08

	// Functions

	// Object Name: Function LevelSequence.LevelSequence.RemoveMetaDataByClass
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RemoveMetaDataByClass(struct UObject* InClass); // Offset: 0x10453ae70 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function LevelSequence.LevelSequence.FindOrAddMetaDataByClass
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UObject* FindOrAddMetaDataByClass(struct UObject* InClass); // Offset: 0x10453af58 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function LevelSequence.LevelSequence.FindMetaDataByClass
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UObject* FindMetaDataByClass(struct UObject* InClass); // Offset: 0x10453afd0 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function LevelSequence.LevelSequence.CopyMetaData
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UObject* CopyMetaData(struct UObject* InMetaData); // Offset: 0x10453aee0 // Return & Params: Num(2) Size(0x10)
};

// Object Name: Class LevelSequence.LevelSequenceActor
// Size: 0x2b8 // Inherited bytes: 0x228
struct ALevelSequenceActor : AActor {
	// Fields
	char pad_0x228[0x10]; // Offset: 0x228 // Size: 0x10
	struct FMovieSceneSequencePlaybackSettings PlaybackSettings; // Offset: 0x238 // Size: 0x14
	char pad_0x24C[0x4]; // Offset: 0x24c // Size: 0x04
	struct ULevelSequencePlayer* SequencePlayer; // Offset: 0x250 // Size: 0x08
	struct FSoftObjectPath LevelSequence; // Offset: 0x258 // Size: 0x18
	struct TArray<struct AActor*> AdditionalEventReceivers; // Offset: 0x270 // Size: 0x10
	struct FLevelSequenceCameraSettings CameraSettings; // Offset: 0x280 // Size: 0x02
	char pad_0x282[0x6]; // Offset: 0x282 // Size: 0x06
	struct ULevelSequenceBurnInOptions* BurnInOptions; // Offset: 0x288 // Size: 0x08
	struct UMovieSceneBindingOverrides* BindingOverrides; // Offset: 0x290 // Size: 0x08
	char bAutoPlay : 1; // Offset: 0x298 // Size: 0x01
	char bOverrideInstanceData : 1; // Offset: 0x298 // Size: 0x01
	char bReplicatePlayback : 1; // Offset: 0x298 // Size: 0x01
	char pad_0x298_3 : 5; // Offset: 0x298 // Size: 0x01
	char pad_0x299[0x7]; // Offset: 0x299 // Size: 0x07
	struct UObject* DefaultInstanceData; // Offset: 0x2a0 // Size: 0x08
	struct ULevelSequenceBurnIn* BurnInInstance; // Offset: 0x2a8 // Size: 0x08
	bool bShowBurnin; // Offset: 0x2b0 // Size: 0x01
	char pad_0x2B1[0x7]; // Offset: 0x2b1 // Size: 0x07

	// Functions

	// Object Name: Function LevelSequence.LevelSequenceActor.ShowBurnin
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ShowBurnin(); // Offset: 0x10453c6e8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LevelSequence.LevelSequenceActor.SetSequence
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSequence(struct ULevelSequence* InSequence); // Offset: 0x10453c900 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function LevelSequence.LevelSequenceActor.SetReplicatePlayback
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetReplicatePlayback(bool ReplicatePlayback); // Offset: 0x10453c744 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LevelSequence.LevelSequenceActor.SetEventReceivers
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetEventReceivers(struct TArray<struct AActor*> AdditionalReceivers); // Offset: 0x10453c7cc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LevelSequence.LevelSequenceActor.SetBindingByTag
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetBindingByTag(struct FName BindingTag, struct TArray<struct AActor*>& Actors, bool bAllowBindingsFromAsset); // Offset: 0x10453c454 // Return & Params: Num(3) Size(0x19)

	// Object Name: Function LevelSequence.LevelSequenceActor.SetBinding
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetBinding(struct FMovieSceneObjectBindingID Binding, struct TArray<struct AActor*>& Actors, bool bAllowBindingsFromAsset); // Offset: 0x10453c58c // Return & Params: Num(3) Size(0x29)

	// Object Name: Function LevelSequence.LevelSequenceActor.ResetBindings
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ResetBindings(); // Offset: 0x10453bf84 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LevelSequence.LevelSequenceActor.ResetBinding
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ResetBinding(struct FMovieSceneObjectBindingID Binding); // Offset: 0x10453bf98 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function LevelSequence.LevelSequenceActor.RemoveBindingByTag
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RemoveBindingByTag(struct FName Tag, struct AActor* Actor); // Offset: 0x10453c03c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function LevelSequence.LevelSequenceActor.RemoveBinding
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RemoveBinding(struct FMovieSceneObjectBindingID Binding, struct AActor* Actor); // Offset: 0x10453c104 // Return & Params: Num(2) Size(0x20)

	// Object Name: DelegateFunction LevelSequence.LevelSequenceActor.OnLevelSequenceLoaded__DelegateSignature
	// Flags: [Public|Delegate]
	void OnLevelSequenceLoaded__DelegateSignature(); // Offset: 0x103339bc4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LevelSequence.LevelSequenceActor.LoadSequence
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct ULevelSequence* LoadSequence(); // Offset: 0x10453c980 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function LevelSequence.LevelSequenceActor.HideBurnin
	// Flags: [Final|Native|Public|BlueprintCallable]
	void HideBurnin(); // Offset: 0x10453c6fc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LevelSequence.LevelSequenceActor.GetSequencePlayer
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct ULevelSequencePlayer* GetSequencePlayer(); // Offset: 0x10453c710 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function LevelSequence.LevelSequenceActor.GetSequence
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct ULevelSequence* GetSequence(); // Offset: 0x10453c9b4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function LevelSequence.LevelSequenceActor.FindNamedBindings
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct TArray<struct FMovieSceneObjectBindingID> FindNamedBindings(struct FName Tag); // Offset: 0x10453bdf8 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function LevelSequence.LevelSequenceActor.FindNamedBinding
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FMovieSceneObjectBindingID FindNamedBinding(struct FName Tag); // Offset: 0x10453bedc // Return & Params: Num(2) Size(0x20)

	// Object Name: Function LevelSequence.LevelSequenceActor.AddBindingByTag
	// Flags: [Final|Native|Public|BlueprintCallable]
	void AddBindingByTag(struct FName BindingTag, struct AActor* Actor, bool bAllowBindingsFromAsset); // Offset: 0x10453c1f4 // Return & Params: Num(3) Size(0x11)

	// Object Name: Function LevelSequence.LevelSequenceActor.AddBinding
	// Flags: [Final|Native|Public|BlueprintCallable]
	void AddBinding(struct FMovieSceneObjectBindingID Binding, struct AActor* Actor, bool bAllowBindingsFromAsset); // Offset: 0x10453c310 // Return & Params: Num(3) Size(0x21)
};

// Object Name: Class LevelSequence.DefaultLevelSequenceInstanceData
// Size: 0x70 // Inherited bytes: 0x28
struct UDefaultLevelSequenceInstanceData : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08
	struct AActor* TransformOriginActor; // Offset: 0x30 // Size: 0x08
	char pad_0x38[0x8]; // Offset: 0x38 // Size: 0x08
	struct FTransform TransformOrigin; // Offset: 0x40 // Size: 0x30
};

// Object Name: Class LevelSequence.LevelSequenceMetaData
// Size: 0x28 // Inherited bytes: 0x28
struct ULevelSequenceMetaData : UInterface {
};

// Object Name: Class LevelSequence.LevelSequenceBurnInInitSettings
// Size: 0x28 // Inherited bytes: 0x28
struct ULevelSequenceBurnInInitSettings : UObject {
};

// Object Name: Class LevelSequence.LevelSequenceBurnInOptions
// Size: 0x50 // Inherited bytes: 0x28
struct ULevelSequenceBurnInOptions : UObject {
	// Fields
	bool bUseBurnIn; // Offset: 0x28 // Size: 0x01
	char pad_0x29[0x7]; // Offset: 0x29 // Size: 0x07
	struct FSoftClassPath BurnInClass; // Offset: 0x30 // Size: 0x18
	struct ULevelSequenceBurnInInitSettings* Settings; // Offset: 0x48 // Size: 0x08

	// Functions

	// Object Name: Function LevelSequence.LevelSequenceBurnInOptions.SetBurnIn
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetBurnIn(struct FSoftClassPath InBurnInClass); // Offset: 0x10453b96c // Return & Params: Num(1) Size(0x18)
};

// Object Name: Class LevelSequence.LevelSequenceBurnIn
// Size: 0x320 // Inherited bytes: 0x260
struct ULevelSequenceBurnIn : UUserWidget {
	// Fields
	struct FLevelSequencePlayerSnapshot FrameInformation; // Offset: 0x260 // Size: 0xb8
	struct ALevelSequenceActor* LevelSequenceActor; // Offset: 0x318 // Size: 0x08

	// Functions

	// Object Name: Function LevelSequence.LevelSequenceBurnIn.SetSettings
	// Flags: [Event|Public|BlueprintEvent]
	void SetSettings(struct UObject* InSettings); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function LevelSequence.LevelSequenceBurnIn.GetSettingsClass
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	struct ULevelSequenceBurnInInitSettings* GetSettingsClass(); // Offset: 0x10453d6bc // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class LevelSequence.LevelSequenceDirector
// Size: 0x30 // Inherited bytes: 0x28
struct ULevelSequenceDirector : UObject {
	// Fields
	struct ULevelSequencePlayer* Player; // Offset: 0x28 // Size: 0x08

	// Functions

	// Object Name: Function LevelSequence.LevelSequenceDirector.OnCreated
	// Flags: [Event|Public|BlueprintEvent]
	void OnCreated(); // Offset: 0x103339bc4 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class LevelSequence.LegacyLevelSequenceDirectorBlueprint
// Size: 0xa0 // Inherited bytes: 0xa0
struct ULegacyLevelSequenceDirectorBlueprint : UBlueprint {
};

// Object Name: Class LevelSequence.LevelSequencePlayer
// Size: 0x9a0 // Inherited bytes: 0x888
struct ULevelSequencePlayer : UMovieSceneSequencePlayer {
	// Fields
	struct FMulticastInlineDelegate OnCameraCut; // Offset: 0x888 // Size: 0x10
	char pad_0x898[0x108]; // Offset: 0x898 // Size: 0x108

	// Functions

	// Object Name: Function LevelSequence.LevelSequencePlayer.GetActiveCameraComponent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UCameraComponent* GetActiveCameraComponent(); // Offset: 0x10453e3f4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function LevelSequence.LevelSequencePlayer.CreateLevelSequencePlayer
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct ULevelSequencePlayer* CreateLevelSequencePlayer(struct UObject* WorldContextObject, struct ULevelSequence* LevelSequence, struct FMovieSceneSequencePlaybackSettings Settings, struct ALevelSequenceActor*& OutActor); // Offset: 0x10453e42c // Return & Params: Num(5) Size(0x38)
};

// Object Name: Class LevelSequence.LevelSequenceMediaController
// Size: 0x250 // Inherited bytes: 0x228
struct ALevelSequenceMediaController : AActor {
	// Fields
	char pad_0x228[0x8]; // Offset: 0x228 // Size: 0x08
	struct ALevelSequenceActor* Sequence; // Offset: 0x230 // Size: 0x08
	struct UMediaComponent* MediaComponent; // Offset: 0x238 // Size: 0x08
	float ServerStartTimeSeconds; // Offset: 0x240 // Size: 0x04
	char pad_0x244[0xc]; // Offset: 0x244 // Size: 0x0c

	// Functions

	// Object Name: Function LevelSequence.LevelSequenceMediaController.SynchronizeToServer
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SynchronizeToServer(float DesyncThresholdSeconds); // Offset: 0x10453e8ec // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LevelSequence.LevelSequenceMediaController.Play
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Play(); // Offset: 0x10453e9a4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LevelSequence.LevelSequenceMediaController.OnRep_ServerStartTimeSeconds
	// Flags: [Final|Native|Private]
	void OnRep_ServerStartTimeSeconds(); // Offset: 0x10453e8d8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LevelSequence.LevelSequenceMediaController.GetSequence
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct ALevelSequenceActor* GetSequence(); // Offset: 0x10453e96c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function LevelSequence.LevelSequenceMediaController.GetMediaComponent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UMediaComponent* GetMediaComponent(); // Offset: 0x10453e988 // Return & Params: Num(1) Size(0x8)
};

