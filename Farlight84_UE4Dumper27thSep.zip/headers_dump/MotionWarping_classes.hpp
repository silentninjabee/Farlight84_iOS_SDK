#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class MotionWarping.AnimNotifyState_MotionWarping
// Size: 0x38 // Inherited bytes: 0x30
struct UAnimNotifyState_MotionWarping : UAnimNotifyState {
	// Fields
	struct URootMotionModifier* RootMotionModifier; // Offset: 0x30 // Size: 0x08

	// Functions

	// Object Name: Function MotionWarping.AnimNotifyState_MotionWarping.OnWarpUpdate
	// Flags: [Event|Public|BlueprintEvent|Const]
	void OnWarpUpdate(struct UMotionWarpingComponent* MotionWarpingComp, struct URootMotionModifier* Modifier); // Offset: 0x103339bc4 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function MotionWarping.AnimNotifyState_MotionWarping.OnWarpEnd
	// Flags: [Event|Public|BlueprintEvent|Const]
	void OnWarpEnd(struct UMotionWarpingComponent* MotionWarpingComp, struct URootMotionModifier* Modifier); // Offset: 0x103339bc4 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function MotionWarping.AnimNotifyState_MotionWarping.OnWarpBegin
	// Flags: [Event|Public|BlueprintEvent|Const]
	void OnWarpBegin(struct UMotionWarpingComponent* MotionWarpingComp, struct URootMotionModifier* Modifier); // Offset: 0x103339bc4 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function MotionWarping.AnimNotifyState_MotionWarping.OnRootMotionModifierUpdate
	// Flags: [Final|Native|Public|Const]
	void OnRootMotionModifierUpdate(struct UMotionWarpingComponent* MotionWarpingComp, struct URootMotionModifier* Modifier); // Offset: 0x101126b74 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function MotionWarping.AnimNotifyState_MotionWarping.OnRootMotionModifierDeactivate
	// Flags: [Final|Native|Public|Const]
	void OnRootMotionModifierDeactivate(struct UMotionWarpingComponent* MotionWarpingComp, struct URootMotionModifier* Modifier); // Offset: 0x101126aac // Return & Params: Num(2) Size(0x10)

	// Object Name: Function MotionWarping.AnimNotifyState_MotionWarping.OnRootMotionModifierActivate
	// Flags: [Final|Native|Public|Const]
	void OnRootMotionModifierActivate(struct UMotionWarpingComponent* MotionWarpingComp, struct URootMotionModifier* Modifier); // Offset: 0x101126c3c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function MotionWarping.AnimNotifyState_MotionWarping.AddRootMotionModifier
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	struct URootMotionModifier* AddRootMotionModifier(struct UMotionWarpingComponent* MotionWarpingComp, struct UAnimSequenceBase* Animation, float StartTime, float EndTime); // Offset: 0x101126d04 // Return & Params: Num(5) Size(0x20)
};

// Object Name: Class MotionWarping.MotionWarpingUtilities
// Size: 0x28 // Inherited bytes: 0x28
struct UMotionWarpingUtilities : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function MotionWarping.MotionWarpingUtilities.GetMotionWarpingWindowsFromAnimation
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetMotionWarpingWindowsFromAnimation(struct UAnimSequenceBase* Animation, struct TArray<struct FMotionWarpingWindowData>& OutWindows); // Offset: 0x101127990 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function MotionWarping.MotionWarpingUtilities.GetMotionWarpingWindowsForWarpTargetFromAnimation
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetMotionWarpingWindowsForWarpTargetFromAnimation(struct UAnimSequenceBase* Animation, struct FName WarpTargetName, struct TArray<struct FMotionWarpingWindowData>& OutWindows); // Offset: 0x10112786c // Return & Params: Num(3) Size(0x20)

	// Object Name: Function MotionWarping.MotionWarpingUtilities.ExtractRootMotionFromAnimation
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	struct FTransform ExtractRootMotionFromAnimation(struct UAnimSequenceBase* Animation, float StartTime, float EndTime); // Offset: 0x101127a6c // Return & Params: Num(4) Size(0x40)
};

// Object Name: Class MotionWarping.MotionWarpingComponent
// Size: 0x148 // Inherited bytes: 0xb0
struct UMotionWarpingComponent : UActorComponent {
	// Fields
	bool bSearchForWindowsInAnimsWithinMontages; // Offset: 0xb0 // Size: 0x01
	char pad_0xB1[0x7]; // Offset: 0xb1 // Size: 0x07
	struct FMulticastInlineDelegate OnPreUpdate; // Offset: 0xb8 // Size: 0x10
	struct TWeakObjectPtr<struct ACharacter> CharacterOwner; // Offset: 0xc8 // Size: 0x08
	struct TArray<struct URootMotionModifier*> Modifiers; // Offset: 0xd0 // Size: 0x10
	struct TMap<struct FName, struct FMotionWarpingTarget> WarpTargetMap; // Offset: 0xe0 // Size: 0x50
	char pad_0x130[0x18]; // Offset: 0x130 // Size: 0x18

	// Functions

	// Object Name: Function MotionWarping.MotionWarpingComponent.RemoveWarpTarget
	// Flags: [Final|Native|Public|BlueprintCallable]
	int32_t RemoveWarpTarget(struct FName WarpTargetName); // Offset: 0x101127e90 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function MotionWarping.MotionWarpingComponent.DisableAllRootMotionModifiers
	// Flags: [Final|Native|Public|BlueprintCallable]
	void DisableAllRootMotionModifiers(); // Offset: 0x10112857c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function MotionWarping.MotionWarpingComponent.AddOrUpdateWarpTargetFromTransform
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void AddOrUpdateWarpTargetFromTransform(struct FName WarpTargetName, struct FTransform TargetTransform); // Offset: 0x101128334 // Return & Params: Num(2) Size(0x40)

	// Object Name: Function MotionWarping.MotionWarpingComponent.AddOrUpdateWarpTargetFromLocationAndRotation
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void AddOrUpdateWarpTargetFromLocationAndRotation(struct FName WarpTargetName, struct FVector TargetLocation, struct FRotator TargetRotation); // Offset: 0x101127f20 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function MotionWarping.MotionWarpingComponent.AddOrUpdateWarpTargetFromLocation
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void AddOrUpdateWarpTargetFromLocation(struct FName WarpTargetName, struct FVector TargetLocation); // Offset: 0x1011280a4 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function MotionWarping.MotionWarpingComponent.AddOrUpdateWarpTargetFromComponent
	// Flags: [Final|Native|Public|BlueprintCallable]
	void AddOrUpdateWarpTargetFromComponent(struct FName WarpTargetName, struct USceneComponent* Component, struct FName BoneName, bool bFollowComponent); // Offset: 0x1011281cc // Return & Params: Num(4) Size(0x19)

	// Object Name: Function MotionWarping.MotionWarpingComponent.AddOrUpdateWarpTarget
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void AddOrUpdateWarpTarget(struct FName WarpTargetName, struct FMotionWarpingTarget& WarpTarget); // Offset: 0x101128458 // Return & Params: Num(2) Size(0x60)
};

// Object Name: Class MotionWarping.RootMotionModifier
// Size: 0xc0 // Inherited bytes: 0x28
struct URootMotionModifier : UObject {
	// Fields
	struct TWeakObjectPtr<struct UAnimSequenceBase> Animation; // Offset: 0x28 // Size: 0x08
	float StartTime; // Offset: 0x30 // Size: 0x04
	float EndTime; // Offset: 0x34 // Size: 0x04
	float PreviousPosition; // Offset: 0x38 // Size: 0x04
	float CurrentPosition; // Offset: 0x3c // Size: 0x04
	float Weight; // Offset: 0x40 // Size: 0x04
	bool bInLocalSpace; // Offset: 0x44 // Size: 0x01
	char pad_0x45[0xb]; // Offset: 0x45 // Size: 0x0b
	struct FTransform StartTransform; // Offset: 0x50 // Size: 0x30
	float ActualStartTime; // Offset: 0x80 // Size: 0x04
	struct FDelegate OnActivateDelegate; // Offset: 0x84 // Size: 0x10
	struct FDelegate OnUpdateDelegate; // Offset: 0x94 // Size: 0x10
	struct FDelegate OnDeactivateDelegate; // Offset: 0xa4 // Size: 0x10
	enum class ERootMotionModifierState State; // Offset: 0xb4 // Size: 0x01
	char pad_0xB5[0xb]; // Offset: 0xb5 // Size: 0x0b
};

// Object Name: Class MotionWarping.RootMotionModifier_Warp
// Size: 0x1b0 // Inherited bytes: 0xc0
struct URootMotionModifier_Warp : URootMotionModifier {
	// Fields
	struct FName WarpTargetName; // Offset: 0xb8 // Size: 0x08
	enum class EWarpPointAnimProvider WarpPointAnimProvider; // Offset: 0xc0 // Size: 0x01
	char pad_0xC9[0x7]; // Offset: 0xc9 // Size: 0x07
	struct FTransform WarpPointAnimTransform; // Offset: 0xd0 // Size: 0x30
	struct FName WarpPointAnimBoneName; // Offset: 0x100 // Size: 0x08
	bool bWarpTranslation; // Offset: 0x108 // Size: 0x01
	bool bIgnoreZAxis; // Offset: 0x109 // Size: 0x01
	bool bOnlyZAxis; // Offset: 0x10a // Size: 0x01
	bool bWarpRotation; // Offset: 0x10b // Size: 0x01
	enum class EMotionWarpRotationType RotationType; // Offset: 0x10c // Size: 0x01
	char pad_0x10D[0x3]; // Offset: 0x10d // Size: 0x03
	float WarpRotationTimeMultiplier; // Offset: 0x110 // Size: 0x04
	char pad_0x114[0xc]; // Offset: 0x114 // Size: 0x0c
	struct FTransform CachedTargetTransform; // Offset: 0x120 // Size: 0x30
	char pad_0x150[0x60]; // Offset: 0x150 // Size: 0x60
};

// Object Name: Class MotionWarping.RootMotionModifier_SimpleWarp
// Size: 0x1b0 // Inherited bytes: 0x1b0
struct URootMotionModifier_SimpleWarp : URootMotionModifier_Warp {
};

// Object Name: Class MotionWarping.RootMotionModifier_Scale
// Size: 0xd0 // Inherited bytes: 0xc0
struct URootMotionModifier_Scale : URootMotionModifier {
	// Fields
	struct FVector Scale; // Offset: 0xb8 // Size: 0x0c
	char pad_0xCC[0x4]; // Offset: 0xcc // Size: 0x04
};

// Object Name: Class MotionWarping.RootMotionModifier_AdjustmentBlendWarp
// Size: 0x280 // Inherited bytes: 0x1b0
struct URootMotionModifier_AdjustmentBlendWarp : URootMotionModifier_Warp {
	// Fields
	bool bWarpIKBones; // Offset: 0x1b0 // Size: 0x01
	char pad_0x1B1[0x7]; // Offset: 0x1b1 // Size: 0x07
	struct TArray<struct FName> IKBones; // Offset: 0x1b8 // Size: 0x10
	char pad_0x1C8[0x8]; // Offset: 0x1c8 // Size: 0x08
	struct FTransform CachedMeshTransform; // Offset: 0x1d0 // Size: 0x30
	struct FTransform CachedMeshRelativeTransform; // Offset: 0x200 // Size: 0x30
	struct FTransform CachedRootMotion; // Offset: 0x230 // Size: 0x30
	struct FAnimSequenceTrackContainer Result; // Offset: 0x260 // Size: 0x20

	// Functions

	// Object Name: Function MotionWarping.RootMotionModifier_AdjustmentBlendWarp.GetAdjustmentBlendIKBoneTransformAndAlpha
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	void GetAdjustmentBlendIKBoneTransformAndAlpha(struct ACharacter* Character, struct FName BoneName, struct FTransform& OutTransform, float& OutAlpha); // Offset: 0x101129534 // Return & Params: Num(4) Size(0x44)

	// Object Name: Function MotionWarping.RootMotionModifier_AdjustmentBlendWarp.AddRootMotionModifierAdjustmentBlendWarp
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct URootMotionModifier_AdjustmentBlendWarp* AddRootMotionModifierAdjustmentBlendWarp(struct UMotionWarpingComponent* InMotionWarpingComp, struct UAnimSequenceBase* InAnimation, float InStartTime, float InEndTime, struct FName InWarpTargetName, enum class EWarpPointAnimProvider InWarpPointAnimProvider, struct FTransform InWarpPointAnimTransform, struct FName InWarpPointAnimBoneName, bool bInWarpTranslation, bool bInIgnoreZAxis, bool bInWarpRotation, bool bInWarpIKBones, struct TArray<struct FName>& InIKBones); // Offset: 0x1011296f0 // Return & Params: Num(14) Size(0x88)
};

// Object Name: Class MotionWarping.RootMotionModifier_SkewWarp
// Size: 0x1d0 // Inherited bytes: 0x1b0
struct URootMotionModifier_SkewWarp : URootMotionModifier_Warp {
	// Fields
	char pad_0x1B0[0x4]; // Offset: 0x1b0 // Size: 0x04
	float MaxWarpDistance; // Offset: 0x1b4 // Size: 0x04
	bool bClampByWarpDir2D; // Offset: 0x1b8 // Size: 0x01
	char pad_0x1B9[0x17]; // Offset: 0x1b9 // Size: 0x17

	// Functions

	// Object Name: Function MotionWarping.RootMotionModifier_SkewWarp.AddRootMotionModifierSkewWarp
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	struct URootMotionModifier_SkewWarp* AddRootMotionModifierSkewWarp(struct UMotionWarpingComponent* InMotionWarpingComp, struct UAnimSequenceBase* InAnimation, float InStartTime, float InEndTime, struct FName InWarpTargetName, enum class EWarpPointAnimProvider InWarpPointAnimProvider, struct FTransform InWarpPointAnimTransform, struct FName InWarpPointAnimBoneName, bool bInWarpTranslation, bool bInIgnoreZAxis, bool bInWarpRotation, enum class EMotionWarpRotationType InRotationType, float InWarpRotationTimeMultiplier); // Offset: 0x101129fdc // Return & Params: Num(14) Size(0x78)
};

