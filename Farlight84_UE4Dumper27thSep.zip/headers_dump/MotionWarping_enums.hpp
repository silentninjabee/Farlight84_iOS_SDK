#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum MotionWarping.EWarpPointAnimProvider
enum class EWarpPointAnimProvider : uint8 {
	None = 0,
	Static = 1,
	Bone = 2,
	EWarpPointAnimProvider_MAX = 3
};

// Object Name: Enum MotionWarping.EMotionWarpRotationType
enum class EMotionWarpRotationType : uint8 {
	Default = 0,
	Facing = 1,
	EMotionWarpRotationType_MAX = 2
};

// Object Name: Enum MotionWarping.ERootMotionModifierState
enum class ERootMotionModifierState : uint8 {
	Waiting = 0,
	Active = 1,
	MarkedForRemoval = 2,
	Disabled = 3,
	ERootMotionModifierState_MAX = 4
};

