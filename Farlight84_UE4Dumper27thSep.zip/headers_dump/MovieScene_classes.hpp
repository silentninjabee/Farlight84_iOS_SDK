#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class MovieScene.MovieSceneSignedObject
// Size: 0x50 // Inherited bytes: 0x28
struct UMovieSceneSignedObject : UObject {
	// Fields
	struct FGuid Signature; // Offset: 0x28 // Size: 0x10
	char pad_0x38[0x18]; // Offset: 0x38 // Size: 0x18
};

// Object Name: Class MovieScene.MovieSceneSection
// Size: 0xd8 // Inherited bytes: 0x50
struct UMovieSceneSection : UMovieSceneSignedObject {
	// Fields
	struct FMovieSceneSectionEvalOptions EvalOptions; // Offset: 0x50 // Size: 0x02
	char pad_0x52[0x6]; // Offset: 0x52 // Size: 0x06
	struct FMovieSceneEasingSettings Easing; // Offset: 0x58 // Size: 0x38
	struct FMovieSceneFrameRange SectionRange; // Offset: 0x90 // Size: 0x10
	struct FFrameNumber PreRollFrames; // Offset: 0xa0 // Size: 0x04
	struct FFrameNumber PostRollFrames; // Offset: 0xa4 // Size: 0x04
	int32_t RowIndex; // Offset: 0xa8 // Size: 0x04
	int32_t OverlapPriority; // Offset: 0xac // Size: 0x04
	char bIsActive : 1; // Offset: 0xb0 // Size: 0x01
	char bIsLocked : 1; // Offset: 0xb0 // Size: 0x01
	char pad_0xB0_2 : 6; // Offset: 0xb0 // Size: 0x01
	char pad_0xB1[0x3]; // Offset: 0xb1 // Size: 0x03
	float StartTime; // Offset: 0xb4 // Size: 0x04
	float EndTime; // Offset: 0xb8 // Size: 0x04
	float PrerollTime; // Offset: 0xbc // Size: 0x04
	float PostrollTime; // Offset: 0xc0 // Size: 0x04
	char bIsInfinite : 1; // Offset: 0xc4 // Size: 0x01
	char pad_0xC4_1 : 7; // Offset: 0xc4 // Size: 0x01
	bool bSupportsInfiniteRange; // Offset: 0xc5 // Size: 0x01
	struct FOptionalMovieSceneBlendType BlendType; // Offset: 0xc6 // Size: 0x02
	char pad_0xC8[0x10]; // Offset: 0xc8 // Size: 0x10

	// Functions

	// Object Name: Function MovieScene.MovieSceneSection.SetRowIndex
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetRowIndex(int32_t NewRowIndex); // Offset: 0x10411e65c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MovieScene.MovieSceneSection.SetPreRollFrames
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPreRollFrames(int32_t InPreRollFrames); // Offset: 0x10411e3bc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MovieScene.MovieSceneSection.SetPostRollFrames
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPostRollFrames(int32_t InPostRollFrames); // Offset: 0x10411e314 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MovieScene.MovieSceneSection.SetOverlapPriority
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetOverlapPriority(int32_t NewPriority); // Offset: 0x10411e5c4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MovieScene.MovieSceneSection.SetIsLocked
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetIsLocked(bool bInIsLocked); // Offset: 0x10411e468 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function MovieScene.MovieSceneSection.SetIsActive
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetIsActive(bool bInIsActive); // Offset: 0x10411e518 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function MovieScene.MovieSceneSection.SetCompletionMode
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetCompletionMode(enum class EMovieSceneCompletionMode InCompletionMode); // Offset: 0x10411e77c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function MovieScene.MovieSceneSection.SetBlendType
	// Flags: [RequiredAPI|Native|Public|BlueprintCallable]
	void SetBlendType(enum class EMovieSceneBlendType InBlendType); // Offset: 0x10411e6d8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function MovieScene.MovieSceneSection.IsLocked
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsLocked(); // Offset: 0x10411e448 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function MovieScene.MovieSceneSection.IsActive
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsActive(); // Offset: 0x10411e4f8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function MovieScene.MovieSceneSection.GetRowIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetRowIndex(); // Offset: 0x10411e640 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MovieScene.MovieSceneSection.GetPreRollFrames
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetPreRollFrames(); // Offset: 0x10411e3a0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MovieScene.MovieSceneSection.GetPostRollFrames
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetPostRollFrames(); // Offset: 0x10411e2f8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MovieScene.MovieSceneSection.GetOverlapPriority
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetOverlapPriority(); // Offset: 0x10411e5a8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MovieScene.MovieSceneSection.GetCompletionMode
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	enum class EMovieSceneCompletionMode GetCompletionMode(); // Offset: 0x10411e7f8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function MovieScene.MovieSceneSection.GetBlendType
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FOptionalMovieSceneBlendType GetBlendType(); // Offset: 0x10411e760 // Return & Params: Num(1) Size(0x2)
};

// Object Name: Class MovieScene.MovieSceneTrack
// Size: 0x58 // Inherited bytes: 0x50
struct UMovieSceneTrack : UMovieSceneSignedObject {
	// Fields
	struct FMovieSceneTrackEvalOptions EvalOptions; // Offset: 0x50 // Size: 0x04
	char pad_0x54[0x1]; // Offset: 0x54 // Size: 0x01
	bool bIsEvalDisabled; // Offset: 0x55 // Size: 0x01
	char pad_0x56[0x2]; // Offset: 0x56 // Size: 0x02
};

// Object Name: Class MovieScene.MovieSceneNameableTrack
// Size: 0x58 // Inherited bytes: 0x58
struct UMovieSceneNameableTrack : UMovieSceneTrack {
};

// Object Name: Class MovieScene.MovieSceneSequence
// Size: 0x348 // Inherited bytes: 0x50
struct UMovieSceneSequence : UMovieSceneSignedObject {
	// Fields
	struct FMovieSceneEvaluationTemplate PrecompiledEvaluationTemplate; // Offset: 0x50 // Size: 0x2f0
	enum class EMovieSceneCompletionMode DefaultCompletionMode; // Offset: 0x340 // Size: 0x01
	bool bParentContextsAreSignificant; // Offset: 0x341 // Size: 0x01
	bool bPlayableDirectly; // Offset: 0x342 // Size: 0x01
	char pad_0x343[0x5]; // Offset: 0x343 // Size: 0x05

	// Functions

	// Object Name: Function MovieScene.MovieSceneSequence.FindBindingsByTag
	// Flags: [Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct TArray<struct FMovieSceneObjectBindingID> FindBindingsByTag(struct FName InBindingName); // Offset: 0x10411f3a0 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function MovieScene.MovieSceneSequence.FindBindingByTag
	// Flags: [Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FMovieSceneObjectBindingID FindBindingByTag(struct FName InBindingName); // Offset: 0x10411f484 // Return & Params: Num(2) Size(0x20)
};

// Object Name: Class MovieScene.MovieSceneSubSection
// Size: 0x150 // Inherited bytes: 0xd8
struct UMovieSceneSubSection : UMovieSceneSection {
	// Fields
	struct FMovieSceneSectionParameters Parameters; // Offset: 0xd8 // Size: 0x24
	float StartOffset; // Offset: 0xfc // Size: 0x04
	float TimeScale; // Offset: 0x100 // Size: 0x04
	float PrerollTime; // Offset: 0x104 // Size: 0x04
	struct UMovieSceneSequence* SubSequence; // Offset: 0x108 // Size: 0x08
	LazyObjectProperty ActorToRecord; // Offset: 0x110 // Size: 0x1c
	char pad_0x12C[0x4]; // Offset: 0x12c // Size: 0x04
	struct FString TargetSequenceName; // Offset: 0x130 // Size: 0x10
	struct FDirectoryPath TargetPathToRecordTo; // Offset: 0x140 // Size: 0x10

	// Functions

	// Object Name: Function MovieScene.MovieSceneSubSection.SetSequence
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSequence(struct UMovieSceneSequence* Sequence); // Offset: 0x1041292b8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function MovieScene.MovieSceneSubSection.GetSequence
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UMovieSceneSequence* GetSequence(); // Offset: 0x104129338 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class MovieScene.MovieSceneSubTrack
// Size: 0x68 // Inherited bytes: 0x58
struct UMovieSceneSubTrack : UMovieSceneNameableTrack {
	// Fields
	struct TArray<struct UMovieSceneSection*> Sections; // Offset: 0x58 // Size: 0x10
};

// Object Name: Class MovieScene.MovieSceneSequencePlayer
// Size: 0x888 // Inherited bytes: 0x28
struct UMovieSceneSequencePlayer : UObject {
	// Fields
	char pad_0x28[0x3e0]; // Offset: 0x28 // Size: 0x3e0
	struct FMulticastInlineDelegate OnPlay; // Offset: 0x408 // Size: 0x10
	struct FMulticastInlineDelegate OnPlayReverse; // Offset: 0x418 // Size: 0x10
	struct FMulticastInlineDelegate OnStop; // Offset: 0x428 // Size: 0x10
	struct FMulticastInlineDelegate OnPause; // Offset: 0x438 // Size: 0x10
	struct FMulticastInlineDelegate OnFinished; // Offset: 0x448 // Size: 0x10
	enum class EMovieScenePlayerStatus status; // Offset: 0x458 // Size: 0x01
	char bReversePlayback : 1; // Offset: 0x459 // Size: 0x01
	char pad_0x459_1 : 7; // Offset: 0x459 // Size: 0x01
	char pad_0x45A[0x6]; // Offset: 0x45a // Size: 0x06
	struct UMovieSceneSequence* Sequence; // Offset: 0x460 // Size: 0x08
	struct FFrameNumber StartTime; // Offset: 0x468 // Size: 0x04
	int32_t DurationFrames; // Offset: 0x46c // Size: 0x04
	int32_t CurrentNumLoops; // Offset: 0x470 // Size: 0x04
	char pad_0x474[0x14]; // Offset: 0x474 // Size: 0x14
	struct FMovieSceneSequencePlaybackSettings PlaybackSettings; // Offset: 0x488 // Size: 0x14
	char pad_0x49C[0x4]; // Offset: 0x49c // Size: 0x04
	struct FMovieSceneRootEvaluationTemplateInstance RootTemplateInstance; // Offset: 0x4a0 // Size: 0x320
	char pad_0x7C0[0x68]; // Offset: 0x7c0 // Size: 0x68
	struct FMovieSceneSequenceReplProperties NetSyncProps; // Offset: 0x828 // Size: 0x10
	struct TScriptInterface<IMovieScenePlaybackClient> PlaybackClient; // Offset: 0x838 // Size: 0x10
	char pad_0x848[0x40]; // Offset: 0x848 // Size: 0x40

	// Functions

	// Object Name: Function MovieScene.MovieSceneSequencePlayer.StopAtCurrentTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StopAtCurrentTime(); // Offset: 0x104127a5c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function MovieScene.MovieSceneSequencePlayer.Stop
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Stop(); // Offset: 0x104127a70 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function MovieScene.MovieSceneSequencePlayer.SetTimeRange
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetTimeRange(float StartTime, float Duration); // Offset: 0x104127384 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function MovieScene.MovieSceneSequencePlayer.SetPlayRate
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPlayRate(float PlayRate); // Offset: 0x104126d60 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MovieScene.MovieSceneSequencePlayer.SetPlaybackRange
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPlaybackRange(float NewStartTime, float NewEndTime); // Offset: 0x10412771c // Return & Params: Num(2) Size(0x8)

	// Object Name: Function MovieScene.MovieSceneSequencePlayer.SetPlaybackPosition
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPlaybackPosition(float NewPlaybackPosition); // Offset: 0x1041277e4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MovieScene.MovieSceneSequencePlayer.SetFrameRate
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetFrameRate(struct FFrameRate FrameRate); // Offset: 0x10412755c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function MovieScene.MovieSceneSequencePlayer.SetFrameRange
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetFrameRange(int32_t StartFrame, int32_t Duration); // Offset: 0x10412744c // Return & Params: Num(2) Size(0x8)

	// Object Name: Function MovieScene.MovieSceneSequencePlayer.SetDisableCameraCuts
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetDisableCameraCuts(bool bInDisableCameraCuts); // Offset: 0x104126cd0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function MovieScene.MovieSceneSequencePlayer.ScrubToSeconds
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ScrubToSeconds(float TimeInSeconds); // Offset: 0x104127104 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MovieScene.MovieSceneSequencePlayer.ScrubToMarkedFrame
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool ScrubToMarkedFrame(struct FString InLabel); // Offset: 0x104126f4c // Return & Params: Num(2) Size(0x11)

	// Object Name: Function MovieScene.MovieSceneSequencePlayer.ScrubToFrame
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ScrubToFrame(struct FFrameTime NewPosition); // Offset: 0x104127284 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function MovieScene.MovieSceneSequencePlayer.Scrub
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Scrub(); // Offset: 0x104127a84 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function MovieScene.MovieSceneSequencePlayer.RPC_OnStopEvent
	// Flags: [Final|Net|NetReliableNative|Event|NetMulticast|Private]
	void RPC_OnStopEvent(struct FFrameTime StoppedTime); // Offset: 0x104126980 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function MovieScene.MovieSceneSequencePlayer.RPC_ExplicitServerUpdateEvent
	// Flags: [Final|Net|NetReliableNative|Event|NetMulticast|Private]
	void RPC_ExplicitServerUpdateEvent(enum class EUpdatePositionMethod Method, struct FFrameTime RelevantTime); // Offset: 0x104126a08 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function MovieScene.MovieSceneSequencePlayer.PlayToSeconds
	// Flags: [Final|Native|Public|BlueprintCallable]
	void PlayToSeconds(float TimeInSeconds); // Offset: 0x104127184 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MovieScene.MovieSceneSequencePlayer.PlayToMarkedFrame
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool PlayToMarkedFrame(struct FString InLabel); // Offset: 0x104126fe8 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function MovieScene.MovieSceneSequencePlayer.PlayToFrame
	// Flags: [Final|Native|Public|BlueprintCallable]
	void PlayToFrame(struct FFrameTime NewPosition); // Offset: 0x104127304 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function MovieScene.MovieSceneSequencePlayer.PlayReverse
	// Flags: [Final|Native|Public|BlueprintCallable]
	void PlayReverse(); // Offset: 0x104127b40 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function MovieScene.MovieSceneSequencePlayer.PlayLooping
	// Flags: [Final|Native|Public|BlueprintCallable]
	void PlayLooping(int32_t NumLoops); // Offset: 0x104127aac // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MovieScene.MovieSceneSequencePlayer.Play
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Play(); // Offset: 0x104127b54 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function MovieScene.MovieSceneSequencePlayer.Pause
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Pause(); // Offset: 0x104127a98 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function MovieScene.MovieSceneSequencePlayer.JumpToSeconds
	// Flags: [Final|Native|Public|BlueprintCallable]
	void JumpToSeconds(float TimeInSeconds); // Offset: 0x104127084 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MovieScene.MovieSceneSequencePlayer.JumpToPosition
	// Flags: [Final|Native|Public|BlueprintCallable]
	void JumpToPosition(float NewPlaybackPosition); // Offset: 0x10412769c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MovieScene.MovieSceneSequencePlayer.JumpToMarkedFrame
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool JumpToMarkedFrame(struct FString InLabel); // Offset: 0x104126eb0 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function MovieScene.MovieSceneSequencePlayer.JumpToFrame
	// Flags: [Final|Native|Public|BlueprintCallable]
	void JumpToFrame(struct FFrameTime NewPosition); // Offset: 0x104127204 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function MovieScene.MovieSceneSequencePlayer.IsReversed
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsReversed(); // Offset: 0x104126e14 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function MovieScene.MovieSceneSequencePlayer.IsPlaying
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsPlaying(); // Offset: 0x104126e7c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function MovieScene.MovieSceneSequencePlayer.IsPaused
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsPaused(); // Offset: 0x104126e48 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function MovieScene.MovieSceneSequencePlayer.GoToEndAndStop
	// Flags: [Final|Native|Public|BlueprintCallable]
	void GoToEndAndStop(); // Offset: 0x104127a48 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function MovieScene.MovieSceneSequencePlayer.GetStartTime
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FQualifiedFrameTime GetStartTime(); // Offset: 0x10412753c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function MovieScene.MovieSceneSequencePlayer.GetPlayRate
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetPlayRate(); // Offset: 0x104126de0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MovieScene.MovieSceneSequencePlayer.GetPlaybackStart
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetPlaybackStart(); // Offset: 0x10412791c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MovieScene.MovieSceneSequencePlayer.GetPlaybackPosition
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetPlaybackPosition(); // Offset: 0x1041279a0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MovieScene.MovieSceneSequencePlayer.GetPlaybackEnd
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetPlaybackEnd(); // Offset: 0x1041278c4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MovieScene.MovieSceneSequencePlayer.GetObjectBindings
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct TArray<struct FMovieSceneObjectBindingID> GetObjectBindings(struct UObject* InObject); // Offset: 0x104126adc // Return & Params: Num(2) Size(0x18)

	// Object Name: Function MovieScene.MovieSceneSequencePlayer.GetLength
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetLength(); // Offset: 0x10412796c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MovieScene.MovieSceneSequencePlayer.GetFrameRate
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FFrameRate GetFrameRate(); // Offset: 0x1041275e4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function MovieScene.MovieSceneSequencePlayer.GetFrameDuration
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetFrameDuration(); // Offset: 0x104127600 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MovieScene.MovieSceneSequencePlayer.GetEndTime
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FQualifiedFrameTime GetEndTime(); // Offset: 0x104127514 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function MovieScene.MovieSceneSequencePlayer.GetDuration
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FQualifiedFrameTime GetDuration(); // Offset: 0x104127634 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function MovieScene.MovieSceneSequencePlayer.GetDisableCameraCuts
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool GetDisableCameraCuts(); // Offset: 0x104126cb0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function MovieScene.MovieSceneSequencePlayer.GetCurrentTime
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FQualifiedFrameTime GetCurrentTime(); // Offset: 0x104127668 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function MovieScene.MovieSceneSequencePlayer.GetBoundObjects
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct TArray<struct UObject*> GetBoundObjects(struct FMovieSceneObjectBindingID ObjectBinding); // Offset: 0x104126bb4 // Return & Params: Num(2) Size(0x28)

	// Object Name: Function MovieScene.MovieSceneSequencePlayer.ChangePlaybackDirection
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ChangePlaybackDirection(); // Offset: 0x104127b2c // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class MovieScene.MovieSceneCustomClockSource
// Size: 0x28 // Inherited bytes: 0x28
struct UMovieSceneCustomClockSource : UInterface {
	// Functions

	// Object Name: Function MovieScene.MovieSceneCustomClockSource.OnTick
	// Flags: [Native|Public]
	void OnTick(float DeltaSeconds, float InPlayRate); // Offset: 0x10410e3a8 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function MovieScene.MovieSceneCustomClockSource.OnStopPlaying
	// Flags: [Native|Public|HasOutParms]
	void OnStopPlaying(struct FQualifiedFrameTime& InStopTime); // Offset: 0x10410e268 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function MovieScene.MovieSceneCustomClockSource.OnStartPlaying
	// Flags: [Native|Public|HasOutParms]
	void OnStartPlaying(struct FQualifiedFrameTime& InStartTime); // Offset: 0x10410e308 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function MovieScene.MovieSceneCustomClockSource.OnRequestCurrentTime
	// Flags: [Native|Public|HasOutParms]
	struct FFrameTime OnRequestCurrentTime(struct FQualifiedFrameTime& InCurrentTime, float InPlayRate); // Offset: 0x10410e168 // Return & Params: Num(3) Size(0x1c)
};

// Object Name: Class MovieScene.MovieScenePlaybackClient
// Size: 0x28 // Inherited bytes: 0x28
struct UMovieScenePlaybackClient : UInterface {
};

// Object Name: Class MovieScene.MovieScene
// Size: 0x148 // Inherited bytes: 0x50
struct UMovieScene : UMovieSceneSignedObject {
	// Fields
	struct TArray<struct FMovieSceneSpawnable> Spawnables; // Offset: 0x50 // Size: 0x10
	struct TArray<struct FMovieScenePossessable> Possessables; // Offset: 0x60 // Size: 0x10
	struct TArray<struct FMovieSceneBinding> ObjectBindings; // Offset: 0x70 // Size: 0x10
	struct TMap<struct FName, struct FMovieSceneObjectBindingIDs> BindingGroups; // Offset: 0x80 // Size: 0x50
	struct TArray<struct UMovieSceneTrack*> MasterTracks; // Offset: 0xd0 // Size: 0x10
	struct UMovieSceneTrack* CameraCutTrack; // Offset: 0xe0 // Size: 0x08
	struct FMovieSceneFrameRange SelectionRange; // Offset: 0xe8 // Size: 0x10
	struct FMovieSceneFrameRange PlaybackRange; // Offset: 0xf8 // Size: 0x10
	struct FFrameRate TickResolution; // Offset: 0x108 // Size: 0x08
	struct FFrameRate DisplayRate; // Offset: 0x110 // Size: 0x08
	enum class EMovieSceneEvaluationType EvaluationType; // Offset: 0x118 // Size: 0x01
	enum class EUpdateClockSource ClockSource; // Offset: 0x119 // Size: 0x01
	char pad_0x11A[0x6]; // Offset: 0x11a // Size: 0x06
	struct FSoftObjectPath CustomClockSourcePath; // Offset: 0x120 // Size: 0x18
	struct TArray<struct FMovieSceneMarkedFrame> MarkedFrames; // Offset: 0x138 // Size: 0x10
};

// Object Name: Class MovieScene.MovieSceneBindingOverrides
// Size: 0x90 // Inherited bytes: 0x28
struct UMovieSceneBindingOverrides : UObject {
	// Fields
	struct TArray<struct FMovieSceneBindingOverrideData> BindingData; // Offset: 0x28 // Size: 0x10
	char pad_0x38[0x58]; // Offset: 0x38 // Size: 0x58
};

// Object Name: Class MovieScene.MovieSceneBindingOwnerInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UMovieSceneBindingOwnerInterface : UInterface {
};

// Object Name: Class MovieScene.MovieSceneBuiltInEasingFunction
// Size: 0x38 // Inherited bytes: 0x28
struct UMovieSceneBuiltInEasingFunction : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08
	enum class EMovieSceneBuiltInEasing Type; // Offset: 0x30 // Size: 0x01
	char pad_0x31[0x7]; // Offset: 0x31 // Size: 0x07
};

// Object Name: Class MovieScene.MovieSceneEasingExternalCurve
// Size: 0x38 // Inherited bytes: 0x28
struct UMovieSceneEasingExternalCurve : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08
	struct UCurveFloat* Curve; // Offset: 0x30 // Size: 0x08
};

// Object Name: Class MovieScene.MovieSceneEasingFunction
// Size: 0x28 // Inherited bytes: 0x28
struct UMovieSceneEasingFunction : UInterface {
	// Functions

	// Object Name: Function MovieScene.MovieSceneEasingFunction.OnEvaluate
	// Flags: [Event|Protected|BlueprintCallable|BlueprintEvent|BlueprintPure|Const]
	float OnEvaluate(float Interp); // Offset: 0x103339bc4 // Return & Params: Num(2) Size(0x8)
};

// Object Name: Class MovieScene.MovieSceneFolder
// Size: 0x70 // Inherited bytes: 0x28
struct UMovieSceneFolder : UObject {
	// Fields
	struct FName FolderName; // Offset: 0x28 // Size: 0x08
	struct TArray<struct UMovieSceneFolder*> ChildFolders; // Offset: 0x30 // Size: 0x10
	struct TArray<struct UMovieSceneTrack*> ChildMasterTracks; // Offset: 0x40 // Size: 0x10
	struct TArray<struct FString> ChildObjectBindingStrings; // Offset: 0x50 // Size: 0x10
	char pad_0x60[0x10]; // Offset: 0x60 // Size: 0x10
};

// Object Name: Class MovieScene.MovieSceneKeyProxy
// Size: 0x28 // Inherited bytes: 0x28
struct UMovieSceneKeyProxy : UInterface {
};

// Object Name: Class MovieScene.TestMovieSceneTrack
// Size: 0x68 // Inherited bytes: 0x58
struct UTestMovieSceneTrack : UMovieSceneTrack {
	// Fields
	bool bHighPassFilter; // Offset: 0x56 // Size: 0x01
	struct TArray<struct UMovieSceneSection*> SectionArray; // Offset: 0x58 // Size: 0x10
};

// Object Name: Class MovieScene.TestMovieSceneSection
// Size: 0xd8 // Inherited bytes: 0xd8
struct UTestMovieSceneSection : UMovieSceneSection {
};

// Object Name: Class MovieScene.TestMovieSceneSequence
// Size: 0x350 // Inherited bytes: 0x348
struct UTestMovieSceneSequence : UMovieSceneSequence {
	// Fields
	struct UMovieScene* MovieScene; // Offset: 0x348 // Size: 0x08
};

// Object Name: Class MovieScene.TestMovieSceneSubTrack
// Size: 0x78 // Inherited bytes: 0x68
struct UTestMovieSceneSubTrack : UMovieSceneSubTrack {
	// Fields
	struct TArray<struct UMovieSceneSection*> SectionArray; // Offset: 0x68 // Size: 0x10
};

// Object Name: Class MovieScene.TestMovieSceneSubSection
// Size: 0x150 // Inherited bytes: 0x150
struct UTestMovieSceneSubSection : UMovieSceneSubSection {
};

