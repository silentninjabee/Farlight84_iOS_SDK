#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class PhysXVehicles.WheeledVehicleMovementComponent
// Size: 0x288 // Inherited bytes: 0x138
struct UWheeledVehicleMovementComponent : UPawnMovementComponent {
	// Fields
	char pad_0x138[0x8]; // Offset: 0x138 // Size: 0x08
	char bDeprecatedSpringOffsetMode : 1; // Offset: 0x140 // Size: 0x01
	char bReverseAsBrake : 1; // Offset: 0x140 // Size: 0x01
	char bUseRVOAvoidance : 1; // Offset: 0x140 // Size: 0x01
	char bRawHandbrakeInput : 1; // Offset: 0x140 // Size: 0x01
	char bRawGearUpInput : 1; // Offset: 0x140 // Size: 0x01
	char bRawGearDownInput : 1; // Offset: 0x140 // Size: 0x01
	char bWasAvoidanceUpdated : 1; // Offset: 0x140 // Size: 0x01
	char pad_0x140_7 : 1; // Offset: 0x140 // Size: 0x01
	char pad_0x141[0x3]; // Offset: 0x141 // Size: 0x03
	float Mass; // Offset: 0x144 // Size: 0x04
	struct TArray<struct FWheelSetup> WheelSetups; // Offset: 0x148 // Size: 0x10
	float DragCoefficient; // Offset: 0x158 // Size: 0x04
	float ChassisWidth; // Offset: 0x15c // Size: 0x04
	float ChassisHeight; // Offset: 0x160 // Size: 0x04
	float DragArea; // Offset: 0x164 // Size: 0x04
	float EstimatedMaxEngineSpeed; // Offset: 0x168 // Size: 0x04
	float MaxEngineRPM; // Offset: 0x16c // Size: 0x04
	float DebugDragMagnitude; // Offset: 0x170 // Size: 0x04
	struct FVector InertiaTensorScale; // Offset: 0x174 // Size: 0x0c
	float MinNormalizedTireLoad; // Offset: 0x180 // Size: 0x04
	float MinNormalizedTireLoadFiltered; // Offset: 0x184 // Size: 0x04
	float MaxNormalizedTireLoad; // Offset: 0x188 // Size: 0x04
	float MaxNormalizedTireLoadFiltered; // Offset: 0x18c // Size: 0x04
	float ThresholdLongitudinalSpeed; // Offset: 0x190 // Size: 0x04
	int32_t LowForwardSpeedSubStepCount; // Offset: 0x194 // Size: 0x04
	int32_t HighForwardSpeedSubStepCount; // Offset: 0x198 // Size: 0x04
	char pad_0x19C[0x4]; // Offset: 0x19c // Size: 0x04
	struct TArray<struct UVehicleWheel*> Wheels; // Offset: 0x1a0 // Size: 0x10
	char pad_0x1B0[0x18]; // Offset: 0x1b0 // Size: 0x18
	float RVOAvoidanceRadius; // Offset: 0x1c8 // Size: 0x04
	float RVOAvoidanceHeight; // Offset: 0x1cc // Size: 0x04
	float AvoidanceConsiderationRadius; // Offset: 0x1d0 // Size: 0x04
	float RVOSteeringStep; // Offset: 0x1d4 // Size: 0x04
	float RVOThrottleStep; // Offset: 0x1d8 // Size: 0x04
	int32_t AvoidanceUID; // Offset: 0x1dc // Size: 0x04
	struct FNavAvoidanceMask AvoidanceGroup; // Offset: 0x1e0 // Size: 0x04
	struct FNavAvoidanceMask GroupsToAvoid; // Offset: 0x1e4 // Size: 0x04
	struct FNavAvoidanceMask GroupsToIgnore; // Offset: 0x1e8 // Size: 0x04
	float AvoidanceWeight; // Offset: 0x1ec // Size: 0x04
	struct FVector PendingLaunchVelocity; // Offset: 0x1f0 // Size: 0x0c
	struct FReplicatedVehicleState ReplicatedState; // Offset: 0x1fc // Size: 0x14
	char pad_0x210[0x4]; // Offset: 0x210 // Size: 0x04
	float RawSteeringInput; // Offset: 0x214 // Size: 0x04
	float RawThrottleInput; // Offset: 0x218 // Size: 0x04
	float RawBrakeInput; // Offset: 0x21c // Size: 0x04
	float SteeringInput; // Offset: 0x220 // Size: 0x04
	float ThrottleInput; // Offset: 0x224 // Size: 0x04
	float BrakeInput; // Offset: 0x228 // Size: 0x04
	float HandbrakeInput; // Offset: 0x22c // Size: 0x04
	float IdleBrakeInput; // Offset: 0x230 // Size: 0x04
	float StopThreshold; // Offset: 0x234 // Size: 0x04
	float WrongDirectionThreshold; // Offset: 0x238 // Size: 0x04
	struct FVehicleInputRate ThrottleInputRate; // Offset: 0x23c // Size: 0x08
	struct FVehicleInputRate BrakeInputRate; // Offset: 0x244 // Size: 0x08
	struct FVehicleInputRate HandbrakeInputRate; // Offset: 0x24c // Size: 0x08
	struct FVehicleInputRate SteeringInputRate; // Offset: 0x254 // Size: 0x08
	char pad_0x25C[0x24]; // Offset: 0x25c // Size: 0x24
	struct AController* OverrideController; // Offset: 0x280 // Size: 0x08

	// Functions

	// Object Name: Function PhysXVehicles.WheeledVehicleMovementComponent.SetUseAutoGears
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetUseAutoGears(bool bUseAuto); // Offset: 0x1053bb5e4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function PhysXVehicles.WheeledVehicleMovementComponent.SetThrottleInput
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetThrottleInput(float Throttle); // Offset: 0x1053bb9d4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PhysXVehicles.WheeledVehicleMovementComponent.SetTargetGear
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetTargetGear(int32_t GearNum, bool bImmediate); // Offset: 0x1053bb66c // Return & Params: Num(2) Size(0x5)

	// Object Name: Function PhysXVehicles.WheeledVehicleMovementComponent.SetSteeringInput
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSteeringInput(float Steering); // Offset: 0x1053bb8d4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PhysXVehicles.WheeledVehicleMovementComponent.SetHandbrakeInput
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetHandbrakeInput(bool bNewHandbrake); // Offset: 0x1053bb84c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function PhysXVehicles.WheeledVehicleMovementComponent.SetGroupsToIgnoreMask
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetGroupsToIgnoreMask(struct FNavAvoidanceMask& GroupMask); // Offset: 0x1053bb194 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PhysXVehicles.WheeledVehicleMovementComponent.SetGroupsToIgnore
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetGroupsToIgnore(int32_t GroupFlags); // Offset: 0x1053bb21c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PhysXVehicles.WheeledVehicleMovementComponent.SetGroupsToAvoidMask
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetGroupsToAvoidMask(struct FNavAvoidanceMask& GroupMask); // Offset: 0x1053bb29c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PhysXVehicles.WheeledVehicleMovementComponent.SetGroupsToAvoid
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetGroupsToAvoid(int32_t GroupFlags); // Offset: 0x1053bb324 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PhysXVehicles.WheeledVehicleMovementComponent.SetGearUp
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetGearUp(bool bNewGearUp); // Offset: 0x1053bb7c4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function PhysXVehicles.WheeledVehicleMovementComponent.SetGearDown
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetGearDown(bool bNewGearDown); // Offset: 0x1053bb73c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function PhysXVehicles.WheeledVehicleMovementComponent.SetBrakeInput
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetBrakeInput(float Brake); // Offset: 0x1053bb954 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PhysXVehicles.WheeledVehicleMovementComponent.SetAvoidanceGroupMask
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetAvoidanceGroupMask(struct FNavAvoidanceMask& GroupMask); // Offset: 0x1053bb3a4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PhysXVehicles.WheeledVehicleMovementComponent.SetAvoidanceGroup
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAvoidanceGroup(int32_t GroupFlags); // Offset: 0x1053bb42c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PhysXVehicles.WheeledVehicleMovementComponent.SetAvoidanceEnabled
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAvoidanceEnabled(bool bEnable); // Offset: 0x1053bb10c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function PhysXVehicles.WheeledVehicleMovementComponent.ServerUpdateState
	// Flags: [Net|NetReliableNative|Event|Protected|NetServer|NetValidate]
	void ServerUpdateState(float InSteeringInput, float InThrottleInput, float InBrakeInput, float InHandbrakeInput, int32_t CurrentGear); // Offset: 0x1053baf18 // Return & Params: Num(5) Size(0x14)

	// Object Name: Function PhysXVehicles.WheeledVehicleMovementComponent.GetUseAutoGears
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool GetUseAutoGears(); // Offset: 0x1053bb4ac // Return & Params: Num(1) Size(0x1)

	// Object Name: Function PhysXVehicles.WheeledVehicleMovementComponent.GetTargetGear
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetTargetGear(); // Offset: 0x1053bb4e0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PhysXVehicles.WheeledVehicleMovementComponent.GetForwardSpeed
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetForwardSpeed(); // Offset: 0x1053bb5b0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PhysXVehicles.WheeledVehicleMovementComponent.GetEngineRotationSpeed
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetEngineRotationSpeed(); // Offset: 0x1053bb57c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PhysXVehicles.WheeledVehicleMovementComponent.GetEngineMaxRotationSpeed
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetEngineMaxRotationSpeed(); // Offset: 0x1053bb548 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PhysXVehicles.WheeledVehicleMovementComponent.GetCurrentGear
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetCurrentGear(); // Offset: 0x1053bb514 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class PhysXVehicles.SimpleWheeledVehicleMovementComponent
// Size: 0x288 // Inherited bytes: 0x288
struct USimpleWheeledVehicleMovementComponent : UWheeledVehicleMovementComponent {
	// Functions

	// Object Name: Function PhysXVehicles.SimpleWheeledVehicleMovementComponent.SetSteerAngle
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSteerAngle(float SteerAngle, int32_t WheelIndex); // Offset: 0x1053b94a8 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function PhysXVehicles.SimpleWheeledVehicleMovementComponent.SetDriveTorque
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetDriveTorque(float DriveTorque, int32_t WheelIndex); // Offset: 0x1053b9574 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function PhysXVehicles.SimpleWheeledVehicleMovementComponent.SetBrakeTorque
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetBrakeTorque(float BrakeTorque, int32_t WheelIndex); // Offset: 0x1053b9640 // Return & Params: Num(2) Size(0x8)
};

// Object Name: Class PhysXVehicles.TireConfig
// Size: 0x50 // Inherited bytes: 0x30
struct UTireConfig : UDataAsset {
	// Fields
	float FrictionScale; // Offset: 0x30 // Size: 0x04
	char pad_0x34[0x4]; // Offset: 0x34 // Size: 0x04
	struct TArray<struct FTireConfigMaterialFriction> TireFrictionScales; // Offset: 0x38 // Size: 0x10
	char pad_0x48[0x8]; // Offset: 0x48 // Size: 0x08
};

// Object Name: Class PhysXVehicles.VehicleAnimInstance
// Size: 0x980 // Inherited bytes: 0x270
struct UVehicleAnimInstance : UAnimInstance {
	// Fields
	char pad_0x270[0x700]; // Offset: 0x270 // Size: 0x700
	struct UWheeledVehicleMovementComponent* WheeledVehicleMovementComponent; // Offset: 0x970 // Size: 0x08
	char pad_0x978[0x8]; // Offset: 0x978 // Size: 0x08

	// Functions

	// Object Name: Function PhysXVehicles.VehicleAnimInstance.GetVehicle
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct AWheeledVehicle* GetVehicle(); // Offset: 0x1053b9f8c // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class PhysXVehicles.VehicleWheel
// Size: 0xf0 // Inherited bytes: 0x28
struct UVehicleWheel : UObject {
	// Fields
	struct UStaticMesh* CollisionMesh; // Offset: 0x28 // Size: 0x08
	bool bDontCreateShape; // Offset: 0x30 // Size: 0x01
	bool bAutoAdjustCollisionSize; // Offset: 0x31 // Size: 0x01
	char pad_0x32[0x2]; // Offset: 0x32 // Size: 0x02
	struct FVector Offset; // Offset: 0x34 // Size: 0x0c
	float ShapeRadius; // Offset: 0x40 // Size: 0x04
	float ShapeWidth; // Offset: 0x44 // Size: 0x04
	float Mass; // Offset: 0x48 // Size: 0x04
	float DampingRate; // Offset: 0x4c // Size: 0x04
	float SteerAngle; // Offset: 0x50 // Size: 0x04
	bool bAffectedByHandbrake; // Offset: 0x54 // Size: 0x01
	char pad_0x55[0x3]; // Offset: 0x55 // Size: 0x03
	struct UTireType* TireType; // Offset: 0x58 // Size: 0x08
	struct UTireConfig* TireConfig; // Offset: 0x60 // Size: 0x08
	float LatStiffMaxLoad; // Offset: 0x68 // Size: 0x04
	float LatStiffValue; // Offset: 0x6c // Size: 0x04
	float LongStiffValue; // Offset: 0x70 // Size: 0x04
	float SuspensionForceOffset; // Offset: 0x74 // Size: 0x04
	float SuspensionMaxRaise; // Offset: 0x78 // Size: 0x04
	float SuspensionMaxDrop; // Offset: 0x7c // Size: 0x04
	float SuspensionNaturalFrequency; // Offset: 0x80 // Size: 0x04
	float SuspensionDampingRatio; // Offset: 0x84 // Size: 0x04
	enum class EWheelSweepType SweepType; // Offset: 0x88 // Size: 0x01
	char pad_0x89[0x3]; // Offset: 0x89 // Size: 0x03
	float MaxBrakeTorque; // Offset: 0x8c // Size: 0x04
	float MaxHandBrakeTorque; // Offset: 0x90 // Size: 0x04
	char pad_0x94[0x4]; // Offset: 0x94 // Size: 0x04
	struct UWheeledVehicleMovementComponent* VehicleSim; // Offset: 0x98 // Size: 0x08
	int32_t WheelIndex; // Offset: 0xa0 // Size: 0x04
	float DebugLongSlip; // Offset: 0xa4 // Size: 0x04
	float DebugLatSlip; // Offset: 0xa8 // Size: 0x04
	float DebugNormalizedTireLoad; // Offset: 0xac // Size: 0x04
	char pad_0xB0[0x4]; // Offset: 0xb0 // Size: 0x04
	float DebugWheelTorque; // Offset: 0xb4 // Size: 0x04
	float DebugLongForce; // Offset: 0xb8 // Size: 0x04
	float DebugLatForce; // Offset: 0xbc // Size: 0x04
	struct FVector Location; // Offset: 0xc0 // Size: 0x0c
	struct FVector OldLocation; // Offset: 0xcc // Size: 0x0c
	struct FVector Velocity; // Offset: 0xd8 // Size: 0x0c
	char pad_0xE4[0xc]; // Offset: 0xe4 // Size: 0x0c

	// Functions

	// Object Name: Function PhysXVehicles.VehicleWheel.IsInAir
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsInAir(); // Offset: 0x1053ba4e4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function PhysXVehicles.VehicleWheel.GetSuspensionOffset
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetSuspensionOffset(); // Offset: 0x1053ba518 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PhysXVehicles.VehicleWheel.GetSteerAngle
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetSteerAngle(); // Offset: 0x1053ba580 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function PhysXVehicles.VehicleWheel.GetRotationAngle
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetRotationAngle(); // Offset: 0x1053ba54c // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class PhysXVehicles.WheeledVehicle
// Size: 0x298 // Inherited bytes: 0x288
struct AWheeledVehicle : APawn {
	// Fields
	struct USkeletalMeshComponent* Mesh; // Offset: 0x288 // Size: 0x08
	struct UWheeledVehicleMovementComponent* VehicleMovement; // Offset: 0x290 // Size: 0x08
};

// Object Name: Class PhysXVehicles.WheeledVehicleMovementComponent4W
// Size: 0x400 // Inherited bytes: 0x288
struct UWheeledVehicleMovementComponent4W : UWheeledVehicleMovementComponent {
	// Fields
	struct FVehicleEngineData EngineSetup; // Offset: 0x288 // Size: 0xa0
	struct FVehicleDifferential4WData DifferentialSetup; // Offset: 0x328 // Size: 0x1c
	float AckermannAccuracy; // Offset: 0x344 // Size: 0x04
	struct FVehicleTransmissionData TransmissionSetup; // Offset: 0x348 // Size: 0x30
	struct FRuntimeFloatCurve SteeringCurve; // Offset: 0x378 // Size: 0x88
};

