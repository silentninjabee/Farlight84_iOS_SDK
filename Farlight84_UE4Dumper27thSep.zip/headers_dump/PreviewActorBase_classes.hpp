#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass PreviewActorBase.PreviewActorBase_C
// Size: 0x591 // Inherited bytes: 0x540
struct APreviewActorBase_C : APreviewActor {
	// Fields
	struct TMap<int32_t, struct FTransform> EmoteActions; // Offset: 0x540 // Size: 0x50
	bool bRotatedByMesh; // Offset: 0x590 // Size: 0x01

	// Functions

	// Object Name: Function PreviewActorBase.PreviewActorBase_C.SetMeshRelativeRotationOnYaw
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SetMeshRelativeRotationOnYaw(float Delta); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x4)
};

