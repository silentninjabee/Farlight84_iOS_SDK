#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass Projectile_B9A08_Primary.Projectile_B9A08_Primary_C
// Size: 0x508 // Inherited bytes: 0x508
struct AProjectile_B9A08_Primary_C : ADefaultProjBullet_C {
};

