#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass Projectile_BMphy0_Primary.Projectile_BMphy0_Primary_C
// Size: 0x508 // Inherited bytes: 0x508
struct AProjectile_BMphy0_Primary_C : ADefaultProjBullet_C {
};

