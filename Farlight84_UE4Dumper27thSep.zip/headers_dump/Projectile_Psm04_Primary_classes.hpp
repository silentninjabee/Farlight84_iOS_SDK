#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass Projectile_Psm04_Primary.Projectile_Psm04_Primary_C
// Size: 0x508 // Inherited bytes: 0x508
struct AProjectile_Psm04_Primary_C : ADefaultProjBullet_C {
};

