#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass Projectile_SniperEPsm02_Primary.Projectile_SniperEPsm02_Primary_C
// Size: 0x510 // Inherited bytes: 0x508
struct AProjectile_SniperEPsm02_Primary_C : ADefaultProjBullet_C {
	// Fields
	struct UParticleSystemComponent* Bullet; // Offset: 0x508 // Size: 0x08
};

