#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass Projectile_VH_Hover_Soroll03_TurretA1.Projectile_VH_Hover_Soroll03_TurretA1_C
// Size: 0x510 // Inherited bytes: 0x508
struct AProjectile_VH_Hover_Soroll03_TurretA1_C : ADefaultProjBullet_C {
	// Fields
	struct UParticleSystemComponent* Bullet; // Offset: 0x508 // Size: 0x08
};

