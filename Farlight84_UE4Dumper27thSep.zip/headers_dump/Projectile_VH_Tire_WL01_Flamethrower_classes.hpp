#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass Projectile_VH_Tire_WL01_Flamethrower.Projectile_VH_Tire_WL01_Flamethrower_C
// Size: 0x510 // Inherited bytes: 0x508
struct AProjectile_VH_Tire_WL01_Flamethrower_C : ADefaultProjBullet_C {
	// Fields
	struct UParticleSystemComponent* Bullet; // Offset: 0x508 // Size: 0x08
};

