#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class SLTA.SLTA_BPL
// Size: 0x28 // Inherited bytes: 0x28
struct USLTA_BPL : UObject {
	// Functions

	// Object Name: Function SLTA.SLTA_BPL.WriteTxt
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool WriteTxt(struct FString saveString, struct FString Path); // Offset: 0x101e73094 // Return & Params: Num(3) Size(0x21)

	// Object Name: Function SLTA.SLTA_BPL.SLTA_SetDetailMode
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SLTA_SetDetailMode(struct USceneComponent* _sceneComponent); // Offset: 0x101e733cc // Return & Params: Num(1) Size(0x8)

	// Object Name: Function SLTA.SLTA_BPL.SLTA_GetPrimitivesRHI
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int32_t SLTA_GetPrimitivesRHI(); // Offset: 0x101e73364 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SLTA.SLTA_BPL.SLTA_GetLightMapIndex
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	int32_t SLTA_GetLightMapIndex(struct UStaticMeshComponent* _ustaticMeshComponent); // Offset: 0x101e73978 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function SLTA.SLTA_BPL.SLTA_GetLightMapCoordinateBias
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	struct FVector4 SLTA_GetLightMapCoordinateBias(struct UStaticMeshComponent* _ustaticMeshComponent); // Offset: 0x101e739f8 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function SLTA.SLTA_BPL.SLTA_GetDrawcalls
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int32_t SLTA_GetDrawcalls(); // Offset: 0x101e73398 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SLTA.SLTA_BPL.SLTA_GetCustomPrimitiveData
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct TArray<float> SLTA_GetCustomPrimitiveData(struct UPrimitiveComponent* _primitive); // Offset: 0x101e73894 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function SLTA.SLTA_BPL.SLTA_ArrayToCSV
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool SLTA_ArrayToCSV(struct FString SaveDirectory, struct FString Filename, struct FString TitleName, struct TArray<struct FString> SaveText, int32_t ArrayIndex, bool AllowOverwriting); // Offset: 0x101e73444 // Return & Params: Num(7) Size(0x46)

	// Object Name: Function SLTA.SLTA_BPL.ReadTxt
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString ReadTxt(struct FString Path); // Offset: 0x101e73238 // Return & Params: Num(2) Size(0x20)
};

