#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct S_VIP_TxtINfo.S_VIP_TxtInfo
// Size: 0x88 // Inherited bytes: 0x00
struct FS_VIP_TxtInfo {
	// Fields
	struct FSlateColor TxtColor_5_A6B51141413091A415CEED8A906D4D30; // Offset: 0x00 // Size: 0x28
	struct FSlateFontInfo TxtFontInfo_8_E2A2CC3F4902DE6BD87CA899D6EBD7E5; // Offset: 0x28 // Size: 0x60
};

