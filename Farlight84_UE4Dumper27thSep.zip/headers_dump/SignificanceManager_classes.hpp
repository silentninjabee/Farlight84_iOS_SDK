#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class SignificanceManager.SignificanceManager
// Size: 0x138 // Inherited bytes: 0x28
struct USignificanceManager : UObject {
	// Fields
	char pad_0x28[0xf8]; // Offset: 0x28 // Size: 0xf8
	struct FSoftClassPath SignificanceManagerClassName; // Offset: 0x120 // Size: 0x18
};

