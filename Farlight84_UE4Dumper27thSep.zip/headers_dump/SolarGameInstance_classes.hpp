#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass SolarGameInstance.SolarGameInstance_C
// Size: 0x9d0 // Inherited bytes: 0x9b8
struct USolarGameInstance_C : USolarGameInstanceBase {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x9b8 // Size: 0x08
	struct FMulticastInlineDelegate OnBroadcastModeChanged; // Offset: 0x9c0 // Size: 0x10

	// Functions

	// Object Name: Function SolarGameInstance.SolarGameInstance_C.LuaOnBroadcastModeChanged
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void LuaOnBroadcastModeChanged(); // Offset: 0x103339bc4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SolarGameInstance.SolarGameInstance_C.LuaGetBroadcastPlayerName
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void LuaGetBroadcastPlayerName(struct FString SolarPlayerID, struct FString& BroadcastPlayerName); // Offset: 0x10138cf2c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function SolarGameInstance.SolarGameInstance_C.LuaGetBroadcastHeroName
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void LuaGetBroadcastHeroName(struct FString SolarPlayerID, struct FString& BroadcastPlayerName); // Offset: 0x10138cf2c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function SolarGameInstance.SolarGameInstance_C.SolarGM_TestCrashWithBP
	// Flags: [Exec|Event|Public|BlueprintEvent]
	void SolarGM_TestCrashWithBP(); // Offset: 0x103339bc4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SolarGameInstance.SolarGameInstance_C.SolarGM_TestEnsureMsgWithBP
	// Flags: [Exec|Event|Public|BlueprintEvent]
	void SolarGM_TestEnsureMsgWithBP(); // Offset: 0x103339bc4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SolarGameInstance.SolarGameInstance_C.ExecuteUbergraph_SolarGameInstance
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_SolarGameInstance(int32_t EntryPoint); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SolarGameInstance.SolarGameInstance_C.OnBroadcastModeChanged__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void OnBroadcastModeChanged__DelegateSignature(); // Offset: 0x103339bc4 // Return & Params: Num(0) Size(0x0)
};

