#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass SolarRedHint_General.SolarRedHint_General_C
// Size: 0x36b // Inherited bytes: 0x348
struct USolarRedHint_General_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x348 // Size: 0x08
	struct UImage* Img_HintPoint; // Offset: 0x350 // Size: 0x08
	struct UTextBlock* Text_HintNum; // Offset: 0x358 // Size: 0x08
	int64_t HintKey; // Offset: 0x360 // Size: 0x08
	enum class ERedHintPath HintPath; // Offset: 0x368 // Size: 0x01
	bool IsAutoRefresh; // Offset: 0x369 // Size: 0x01
	enum class E_Type_RedHint Type; // Offset: 0x36a // Size: 0x01

	// Functions

	// Object Name: Function SolarRedHint_General.SolarRedHint_General_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	struct FString GetModuleName(); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function SolarRedHint_General.SolarRedHint_General_C.OnSetHintDataComplete
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void OnSetHintDataComplete(); // Offset: 0x10138cf2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SolarRedHint_General.SolarRedHint_General_C.SetStyle
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetStyle(enum class E_Type_RedHint Type); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function SolarRedHint_General.SolarRedHint_General_C.SetHintData
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetHintData(int64_t Key, enum class ERedHintPath Path, bool bAutoRefresh, enum class E_Type_RedHint Type); // Offset: 0x103339bc4 // Return & Params: Num(4) Size(0xb)

	// Object Name: Function SolarRedHint_General.SolarRedHint_General_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void PreConstruct(bool IsDesignTime); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function SolarRedHint_General.SolarRedHint_General_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Construct(); // Offset: 0x10138cf2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SolarRedHint_General.SolarRedHint_General_C.ExecuteUbergraph_SolarRedHint_General
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_SolarRedHint_General(int32_t EntryPoint); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x4)
};

