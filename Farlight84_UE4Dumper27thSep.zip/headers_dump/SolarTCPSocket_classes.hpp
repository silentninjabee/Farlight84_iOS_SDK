#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class SolarTCPSocket.SolarTCPSocketClient
// Size: 0x2b8 // Inherited bytes: 0x228
struct ASolarTCPSocketClient : AActor {
	// Fields
	int32_t SendBufferSize; // Offset: 0x228 // Size: 0x04
	int32_t ReceiveBufferSize; // Offset: 0x22c // Size: 0x04
	float TimeBetweenTicks; // Offset: 0x230 // Size: 0x04
	char pad_0x234[0x84]; // Offset: 0x234 // Size: 0x84

	// Functions

	// Object Name: Function SolarTCPSocket.SolarTCPSocketClient.SendData
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool SendData(int32_t ConnectionId, struct TArray<char> Data); // Offset: 0x101e04380 // Return & Params: Num(3) Size(0x19)

	// Object Name: Function SolarTCPSocket.SolarTCPSocketClient.Disconnect
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Disconnect(int32_t ConnectionId); // Offset: 0x101e044bc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SolarTCPSocket.SolarTCPSocketClient.Connect
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void Connect(struct FString IP, int32_t Port, struct FDelegate& OnConnected, struct FDelegate& OnDisconnected, struct FDelegate& OnMessageReceived, int32_t& ConnectionId); // Offset: 0x101e0453c // Return & Params: Num(6) Size(0x48)
};

