#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct SolarlandDeviceId.DummyObject
// Size: 0x01 // Inherited bytes: 0x00
struct FDummyObject {
	// Fields
	char pad_0x0[0x1]; // Offset: 0x00 // Size: 0x01
};

