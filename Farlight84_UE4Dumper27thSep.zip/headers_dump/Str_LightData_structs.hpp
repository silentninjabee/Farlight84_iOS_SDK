#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct Str_LightData.Str_LightData
// Size: 0x70 // Inherited bytes: 0x00
struct FStr_LightData {
	// Fields
	struct FStr_DirectionalLightSetting DirectionalLightSetting_8_652AA6EC4864A03310E86FB1505F4BFA; // Offset: 0x00 // Size: 0x38
	struct FStr_SkyLightSetting SkyLightSetting_2_D57A042E4F37A86B5F7C70BDC7D2CF8C; // Offset: 0x38 // Size: 0x08
	struct FStr_EdgeLightSetting EdgeLightSetting_12_36AD4D4A4FA15CCD9E68109626546B69; // Offset: 0x40 // Size: 0x30
};

