#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct Str_SkyLightSetting.Str_SkyLightSetting
// Size: 0x08 // Inherited bytes: 0x00
struct FStr_SkyLightSetting {
	// Fields
	float Intensity_2_BF70603C48E1FB710393B6A01DE85371; // Offset: 0x00 // Size: 0x04
	struct FColor LightColor_17_3C5C22CB456CE00B5DFC4297338C4B22; // Offset: 0x04 // Size: 0x04
};

