#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass TickerWidget.TickerWidget_C
// Size: 0x488 // Inherited bytes: 0x348
struct UTickerWidget_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x348 // Size: 0x08
	struct URichTextBlock* RichText; // Offset: 0x350 // Size: 0x08
	struct USizeBox* SizeBox; // Offset: 0x358 // Size: 0x08
	struct UCanvasPanel* TextPanel; // Offset: 0x360 // Size: 0x08
	struct FText Text; // Offset: 0x368 // Size: 0x18
	bool bEnableTickering; // Offset: 0x380 // Size: 0x01
	char pad_0x381[0x3]; // Offset: 0x381 // Size: 0x03
	float LoopIntervalDuration; // Offset: 0x384 // Size: 0x04
	float AnimationSpeed; // Offset: 0x388 // Size: 0x04
	bool bCanTicker; // Offset: 0x38c // Size: 0x01
	char pad_0x38D[0x3]; // Offset: 0x38d // Size: 0x03
	float OriTextWidth; // Offset: 0x390 // Size: 0x04
	char pad_0x394[0x4]; // Offset: 0x394 // Size: 0x04
	struct FText ShortenedText; // Offset: 0x398 // Size: 0x18
	struct FTimerHandle TimerHandle; // Offset: 0x3b0 // Size: 0x08
	bool bEnableLocText; // Offset: 0x3b8 // Size: 0x01
	char pad_0x3B9[0x3]; // Offset: 0x3b9 // Size: 0x03
	int32_t LocTextID; // Offset: 0x3bc // Size: 0x04
	bool bIsAnimationPlaying; // Offset: 0x3c0 // Size: 0x01
	char pad_0x3C1[0x3]; // Offset: 0x3c1 // Size: 0x03
	float TargetXVal; // Offset: 0x3c4 // Size: 0x04
	float DeltaTime; // Offset: 0x3c8 // Size: 0x04
	char pad_0x3CC[0x4]; // Offset: 0x3cc // Size: 0x04
	struct FTimerHandle TickerTimerHandle; // Offset: 0x3d0 // Size: 0x08
	struct FSlateFontInfo Font; // Offset: 0x3d8 // Size: 0x60
	struct FSlateColor TxtColor; // Offset: 0x438 // Size: 0x28
	struct FLinearColor ShadowColor; // Offset: 0x460 // Size: 0x10
	struct FVector2D ShadowOffset; // Offset: 0x470 // Size: 0x08
	struct FVector2D Size; // Offset: 0x478 // Size: 0x08
	float Direction; // Offset: 0x480 // Size: 0x04
	bool bAlwaysTickering; // Offset: 0x484 // Size: 0x01
	enum class ETextJustify Justification; // Offset: 0x485 // Size: 0x01
	bool bAlwaysKeepJustification; // Offset: 0x486 // Size: 0x01
	enum class ETextJustify NewVar_1; // Offset: 0x487 // Size: 0x01

	// Functions

	// Object Name: Function TickerWidget.TickerWidget_C.UpdateText
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void UpdateText(); // Offset: 0x103339bc4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function TickerWidget.TickerWidget_C.ApplyJustification
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void ApplyJustification(); // Offset: 0x103339bc4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function TickerWidget.TickerWidget_C.CanTicker
	// Flags: [Private|BlueprintCallable|BlueprintEvent]
	void CanTicker(); // Offset: 0x103339bc4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function TickerWidget.TickerWidget_C.PlayerTickerAnimHelper
	// Flags: [Private|BlueprintCallable|BlueprintEvent]
	void PlayerTickerAnimHelper(); // Offset: 0x103339bc4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function TickerWidget.TickerWidget_C.SetTextEditorLoc
	// Flags: [Private|BlueprintCallable|BlueprintEvent]
	void SetTextEditorLoc(); // Offset: 0x103339bc4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function TickerWidget.TickerWidget_C.StopTickerAnimation
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void StopTickerAnimation(); // Offset: 0x103339bc4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function TickerWidget.TickerWidget_C.PlayTickerAnimation
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void PlayTickerAnimation(); // Offset: 0x103339bc4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function TickerWidget.TickerWidget_C.SetText
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetText(struct FText InText); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function TickerWidget.TickerWidget_C.OnSynchronizeProperties
	// Flags: [Event|Public|BlueprintEvent]
	void OnSynchronizeProperties(); // Offset: 0x103339bc4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function TickerWidget.TickerWidget_C.OnHide
	// Flags: [Event|Protected|BlueprintEvent]
	void OnHide(); // Offset: 0x103339bc4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function TickerWidget.TickerWidget_C.OnSolarUIClosed
	// Flags: [Event|Protected|BlueprintEvent]
	void OnSolarUIClosed(); // Offset: 0x103339bc4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function TickerWidget.TickerWidget_C.Tick
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Offset: 0x103339bc4 // Return & Params: Num(2) Size(0x3c)

	// Object Name: Function TickerWidget.TickerWidget_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Construct(); // Offset: 0x103339bc4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function TickerWidget.TickerWidget_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void PreConstruct(bool IsDesignTime); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function TickerWidget.TickerWidget_C.CustomEvent_1
	// Flags: [HasOutParms|BlueprintCallable|BlueprintEvent]
	void CustomEvent_1(struct UObject* Publisher, struct UObject* Payload, struct TArray<struct FString>& MetaData); // Offset: 0x103339bc4 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function TickerWidget.TickerWidget_C.ExecuteUbergraph_TickerWidget
	// Flags: [Final|UbergraphFunction|HasDefaults]
	void ExecuteUbergraph_TickerWidget(int32_t EntryPoint); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x4)
};

