#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct TimeManagement.TimedDataInputEvaluationData
// Size: 0x08 // Inherited bytes: 0x00
struct FTimedDataInputEvaluationData {
	// Fields
	float DistanceToNewestSampleSeconds; // Offset: 0x00 // Size: 0x04
	float DistanceToOldestSampleSeconds; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct TimeManagement.TimedDataChannelSampleTime
// Size: 0x18 // Inherited bytes: 0x00
struct FTimedDataChannelSampleTime {
	// Fields
	char pad_0x0[0x18]; // Offset: 0x00 // Size: 0x18
};

