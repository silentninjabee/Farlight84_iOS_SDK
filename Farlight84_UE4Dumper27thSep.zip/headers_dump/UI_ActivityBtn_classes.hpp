#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_ActivityBtn.UI_ActivityBtn_C
// Size: 0x388 // Inherited bytes: 0x348
struct UUI_ActivityBtn_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x348 // Size: 0x08
	struct UBackgroundBlur* BgBlur; // Offset: 0x350 // Size: 0x08
	struct USolarButton* Btn_TurnTo; // Offset: 0x358 // Size: 0x08
	struct USolarImageURL* ImageURL; // Offset: 0x360 // Size: 0x08
	struct UImage* img_Mask; // Offset: 0x368 // Size: 0x08
	struct UCanvasPanel* Panel_Loading; // Offset: 0x370 // Size: 0x08
	struct USolarTextBlock* Txt_Loading; // Offset: 0x378 // Size: 0x08
	struct UUI_Component_Close_C* UI_Component_Close; // Offset: 0x380 // Size: 0x08

	// Functions

	// Object Name: Function UI_ActivityBtn.UI_ActivityBtn_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	struct FString GetModuleName(); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UI_ActivityBtn.UI_ActivityBtn_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Construct(); // Offset: 0x103339bc4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_ActivityBtn.UI_ActivityBtn_C.BP_EventSetBlur
	// Flags: [BlueprintCallable|BlueprintEvent]
	void BP_EventSetBlur(); // Offset: 0x103339bc4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_ActivityBtn.UI_ActivityBtn_C.ExecuteUbergraph_UI_ActivityBtn
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_UI_ActivityBtn(int32_t EntryPoint); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x4)
};

