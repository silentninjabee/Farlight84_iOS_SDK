#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_Component_Close.UI_Component_Close_C
// Size: 0x394 // Inherited bytes: 0x348
struct UUI_Component_Close_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x348 // Size: 0x08
	struct USolarButton* Btn_Close; // Offset: 0x350 // Size: 0x08
	struct UImage* Img_Close_Nml; // Offset: 0x358 // Size: 0x08
	struct FMulticastInlineDelegate OnClicked; // Offset: 0x360 // Size: 0x10
	bool Black; // Offset: 0x370 // Size: 0x01
	char pad_0x371[0x7]; // Offset: 0x371 // Size: 0x07
	struct FMulticastInlineDelegate OnPressed; // Offset: 0x378 // Size: 0x10
	bool White; // Offset: 0x388 // Size: 0x01
	char pad_0x389[0x3]; // Offset: 0x389 // Size: 0x03
	struct FVector2D Icon_Size; // Offset: 0x38c // Size: 0x08

	// Functions

	// Object Name: Function UI_Component_Close.UI_Component_Close_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	struct FString GetModuleName(); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UI_Component_Close.UI_Component_Close_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void PreConstruct(bool IsDesignTime); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Component_Close.UI_Component_Close_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Construct(); // Offset: 0x10138cf2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Component_Close.UI_Component_Close_C.BndEvt__Btn_Close_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature
	// Flags: [BlueprintEvent]
	void BndEvt__Btn_Close_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Offset: 0x103339bc4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Component_Close.UI_Component_Close_C.BndEvt__Btn_Close_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature
	// Flags: [BlueprintEvent]
	void BndEvt__Btn_Close_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature(); // Offset: 0x103339bc4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Component_Close.UI_Component_Close_C.BndEvt__Btn_Close_K2Node_ComponentBoundEvent_2_OnButtonHoverEvent__DelegateSignature
	// Flags: [BlueprintEvent]
	void BndEvt__Btn_Close_K2Node_ComponentBoundEvent_2_OnButtonHoverEvent__DelegateSignature(); // Offset: 0x103339bc4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Component_Close.UI_Component_Close_C.BndEvt__Btn_Close_K2Node_ComponentBoundEvent_3_OnButtonPressedEvent__DelegateSignature
	// Flags: [BlueprintEvent]
	void BndEvt__Btn_Close_K2Node_ComponentBoundEvent_3_OnButtonPressedEvent__DelegateSignature(); // Offset: 0x103339bc4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Component_Close.UI_Component_Close_C.ExecuteUbergraph_UI_Component_Close
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_UI_Component_Close(int32_t EntryPoint); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UI_Component_Close.UI_Component_Close_C.OnPressed__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void OnPressed__DelegateSignature(); // Offset: 0x103339bc4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Component_Close.UI_Component_Close_C.OnClicked__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void OnClicked__DelegateSignature(); // Offset: 0x103339bc4 // Return & Params: Num(0) Size(0x0)
};

