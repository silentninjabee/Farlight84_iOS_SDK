#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_Component_NationalFlag.UI_Component_NationalFlag_C
// Size: 0x395 // Inherited bytes: 0x378
struct UUI_Component_NationalFlag_C : UUIComponentNationalFlag {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x378 // Size: 0x08
	struct USizeBox* SizeBox_1; // Offset: 0x380 // Size: 0x08
	struct UWidgetSwitcher* WidgetSwitcher_Flag; // Offset: 0x388 // Size: 0x08
	float Size; // Offset: 0x390 // Size: 0x04
	enum class E_FlagType FlagType; // Offset: 0x394 // Size: 0x01

	// Functions

	// Object Name: Function UI_Component_NationalFlag.UI_Component_NationalFlag_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	struct FString GetModuleName(); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UI_Component_NationalFlag.UI_Component_NationalFlag_C.SetEmptyClan
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetEmptyClan(); // Offset: 0x103339bc4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Component_NationalFlag.UI_Component_NationalFlag_C.SetFlagType
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetFlagType(enum class E_FlagType FlagType); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Component_NationalFlag.UI_Component_NationalFlag_C.Set UI State
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void Set UI State(); // Offset: 0x103339bc4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Component_NationalFlag.UI_Component_NationalFlag_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void PreConstruct(bool IsDesignTime); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Component_NationalFlag.UI_Component_NationalFlag_C.SetNationalFlagType
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void SetNationalFlagType(); // Offset: 0x103339bc4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Component_NationalFlag.UI_Component_NationalFlag_C.SetClanFlagType
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void SetClanFlagType(); // Offset: 0x103339bc4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Component_NationalFlag.UI_Component_NationalFlag_C.ExecuteUbergraph_UI_Component_NationalFlag
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_UI_Component_NationalFlag(int32_t EntryPoint); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x4)
};

