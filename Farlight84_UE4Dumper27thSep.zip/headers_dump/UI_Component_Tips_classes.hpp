#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_Component_Tips.UI_Component_Tips_C
// Size: 0x434 // Inherited bytes: 0x348
struct UUI_Component_Tips_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x348 // Size: 0x08
	struct UWidgetAnimation* Anim_Exit; // Offset: 0x350 // Size: 0x08
	struct UWidgetAnimation* Anim_Loop; // Offset: 0x358 // Size: 0x08
	struct UWidgetAnimation* Anim_Enter; // Offset: 0x360 // Size: 0x08
	struct UOverlay* Arrow_B; // Offset: 0x368 // Size: 0x08
	struct UOverlay* Arrow_L; // Offset: 0x370 // Size: 0x08
	struct UOverlay* Arrow_R; // Offset: 0x378 // Size: 0x08
	struct UImage* Img_Bg; // Offset: 0x380 // Size: 0x08
	struct UImage* Img_Light; // Offset: 0x388 // Size: 0x08
	struct UImage* Img_Light_2; // Offset: 0x390 // Size: 0x08
	struct UImage* Img_Mininum; // Offset: 0x398 // Size: 0x08
	struct USolarListView* List_Item; // Offset: 0x3a0 // Size: 0x08
	struct UUI_Target_Medal_Challenge_S_C* Medal_2; // Offset: 0x3a8 // Size: 0x08
	struct UUI_Target_Medal_Challenge_S_C* Medal_3; // Offset: 0x3b0 // Size: 0x08
	struct UUI_Target_Medal_Challenge_S_C* Medal_4; // Offset: 0x3b8 // Size: 0x08
	struct UUI_Target_Medal_Challenge_S_C* Medal_5; // Offset: 0x3c0 // Size: 0x08
	struct UHorizontalBox* Panel_Medal; // Offset: 0x3c8 // Size: 0x08
	struct USizeBox* SizeBox_2; // Offset: 0x3d0 // Size: 0x08
	struct USpacer* Spacer_390; // Offset: 0x3d8 // Size: 0x08
	struct USolarTextBlock* Txt_Details; // Offset: 0x3e0 // Size: 0x08
	struct USolarTextBlock* Txt_Num; // Offset: 0x3e8 // Size: 0x08
	struct USolarTextBlock* Txt_Title; // Offset: 0x3f0 // Size: 0x08
	struct UUI_Component_Btn_C* UI_Component_Btn; // Offset: 0x3f8 // Size: 0x08
	struct UUI_Component_Item_C* UI_Component_Item; // Offset: 0x400 // Size: 0x08
	struct UVerticalBox* VerticalBox_41; // Offset: 0x408 // Size: 0x08
	bool Left; // Offset: 0x410 // Size: 0x01
	bool Right; // Offset: 0x411 // Size: 0x01
	bool Btn; // Offset: 0x412 // Size: 0x01
	bool Num; // Offset: 0x413 // Size: 0x01
	bool Item; // Offset: 0x414 // Size: 0x01
	char pad_0x415[0x3]; // Offset: 0x415 // Size: 0x03
	float Location; // Offset: 0x418 // Size: 0x04
	bool Title; // Offset: 0x41c // Size: 0x01
	bool Medal; // Offset: 0x41d // Size: 0x01
	bool Task; // Offset: 0x41e // Size: 0x01
	bool Detail; // Offset: 0x41f // Size: 0x01
	bool Bottom; // Offset: 0x420 // Size: 0x01
	enum class ESlateColorStylingMode NewVar_1; // Offset: 0x421 // Size: 0x01
	char pad_0x422[0x2]; // Offset: 0x422 // Size: 0x02
	struct FLinearColor NewVar_2; // Offset: 0x424 // Size: 0x10

	// Functions

	// Object Name: Function UI_Component_Tips.UI_Component_Tips_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	struct FString GetModuleName(); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UI_Component_Tips.UI_Component_Tips_C.BP_OnEntryReleased
	// Flags: [Event|Protected|BlueprintEvent]
	void BP_OnEntryReleased(); // Offset: 0x103339bc4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Component_Tips.UI_Component_Tips_C.BP_OnItemExpansionChanged
	// Flags: [Event|Protected|BlueprintEvent]
	void BP_OnItemExpansionChanged(bool bIsExpanded); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Component_Tips.UI_Component_Tips_C.BP_OnItemSelectionChanged
	// Flags: [Event|Protected|BlueprintEvent]
	void BP_OnItemSelectionChanged(bool bIsSelected); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Component_Tips.UI_Component_Tips_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void PreConstruct(bool IsDesignTime); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Component_Tips.UI_Component_Tips_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Construct(); // Offset: 0x103339bc4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Component_Tips.UI_Component_Tips_C.ChangeTipStatus
	// Flags: [BlueprintCallable|BlueprintEvent]
	void ChangeTipStatus(); // Offset: 0x103339bc4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Component_Tips.UI_Component_Tips_C.ExecuteUbergraph_UI_Component_Tips
	// Flags: [Final|UbergraphFunction|HasDefaults]
	void ExecuteUbergraph_UI_Component_Tips(int32_t EntryPoint); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x4)
};

