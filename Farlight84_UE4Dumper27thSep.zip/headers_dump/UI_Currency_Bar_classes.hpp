#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_Currency_Bar.UI_Currency_Bar_C
// Size: 0x418 // Inherited bytes: 0x348
struct UUI_Currency_Bar_C : USolarUserWidget {
	// Fields
	struct UButton* Btn_charge; // Offset: 0x348 // Size: 0x08
	struct UImage* img_charge; // Offset: 0x350 // Size: 0x08
	struct UImage* Img_Currency; // Offset: 0x358 // Size: 0x08
	struct UImage* Img_Currency_2; // Offset: 0x360 // Size: 0x08
	struct UImage* Img_Currency_01; // Offset: 0x368 // Size: 0x08
	struct UImage* Img_Currency_02; // Offset: 0x370 // Size: 0x08
	struct UImage* Line_3; // Offset: 0x378 // Size: 0x08
	struct UImage* Line_4; // Offset: 0x380 // Size: 0x08
	struct UImage* Line_5; // Offset: 0x388 // Size: 0x08
	struct UImage* Line_6; // Offset: 0x390 // Size: 0x08
	struct UOverlay* Overlay_Vip; // Offset: 0x398 // Size: 0x08
	struct UCanvasPanel* Panel_Currency_01; // Offset: 0x3a0 // Size: 0x08
	struct UCanvasPanel* Panel_Currency_02; // Offset: 0x3a8 // Size: 0x08
	struct UCanvasPanel* Panel_Currency_03; // Offset: 0x3b0 // Size: 0x08
	struct UCanvasPanel* Panel_Currency_04; // Offset: 0x3b8 // Size: 0x08
	struct UCanvasPanel* Panel_Root; // Offset: 0x3c0 // Size: 0x08
	struct USolarButton* SolarBtn_BG; // Offset: 0x3c8 // Size: 0x08
	struct USolarButton* SolarBtn_BG_2; // Offset: 0x3d0 // Size: 0x08
	struct USolarButton* SolarBtn_BG_3; // Offset: 0x3d8 // Size: 0x08
	struct USolarButton* SolarBtn_BG_02; // Offset: 0x3e0 // Size: 0x08
	struct USolarRedHint_General_C* SolarRedHint_General; // Offset: 0x3e8 // Size: 0x08
	struct UTextBlock* Txt_Number; // Offset: 0x3f0 // Size: 0x08
	struct UTextBlock* Txt_Number_2; // Offset: 0x3f8 // Size: 0x08
	struct UTextBlock* Txt_Number_01; // Offset: 0x400 // Size: 0x08
	struct UTextBlock* Txt_Number_02; // Offset: 0x408 // Size: 0x08
	struct UUI_Vip_Cards_C* UI_Vip_Cards; // Offset: 0x410 // Size: 0x08

	// Functions

	// Object Name: Function UI_Currency_Bar.UI_Currency_Bar_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	struct FString GetModuleName(); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x10)
};

