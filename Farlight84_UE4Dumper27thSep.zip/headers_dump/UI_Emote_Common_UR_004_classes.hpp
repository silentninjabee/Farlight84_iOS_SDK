#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_Emote_Common_UR_004.UI_Emote_Common_UR_004_C
// Size: 0x5c0 // Inherited bytes: 0x590
struct UUI_Emote_Common_UR_004_C : UEmojiBubbleWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x590 // Size: 0x08
	struct UWidgetAnimation* EmojiEnd_Anim_2; // Offset: 0x598 // Size: 0x08
	struct UWidgetAnimation* EmojiBegin_Anim_2; // Offset: 0x5a0 // Size: 0x08
	struct UImage* img_Emoji_Bg; // Offset: 0x5a8 // Size: 0x08
	struct UImage* img_Emoji_Bg_2; // Offset: 0x5b0 // Size: 0x08
	struct UCanvasPanel* Panel_Emoji; // Offset: 0x5b8 // Size: 0x08

	// Functions

	// Object Name: Function UI_Emote_Common_UR_004.UI_Emote_Common_UR_004_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void PreConstruct(bool IsDesignTime); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Emote_Common_UR_004.UI_Emote_Common_UR_004_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Construct(); // Offset: 0x103339bc4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Emote_Common_UR_004.UI_Emote_Common_UR_004_C.ExecuteUbergraph_UI_Emote_Common_UR_004
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_UI_Emote_Common_UR_004(int32_t EntryPoint); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x4)
};

