#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_Lobby_DownLoad_Slot.UI_Lobby_DownLoad_Slot_C
// Size: 0x3b8 // Inherited bytes: 0x358
struct UUI_Lobby_DownLoad_Slot_C : USolarItemCardViewWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x358 // Size: 0x08
	struct USolarButton* Btn_Down; // Offset: 0x360 // Size: 0x08
	struct USolarButton* Btn_Downing; // Offset: 0x368 // Size: 0x08
	struct USolarButton* Btn_Pause; // Offset: 0x370 // Size: 0x08
	struct USolarImage* Img_Line; // Offset: 0x378 // Size: 0x08
	struct UOverlay* Overlay_Finish; // Offset: 0x380 // Size: 0x08
	struct UProgressBar* ProgressBar_Download; // Offset: 0x388 // Size: 0x08
	struct USolarTextBlock* Text_Title; // Offset: 0x390 // Size: 0x08
	struct USolarTextBlock* Txt_Numb; // Offset: 0x398 // Size: 0x08
	struct USolarTextBlock* Txt_Speed; // Offset: 0x3a0 // Size: 0x08
	struct UWidgetSwitcher* WidgetSwitcher_Btn; // Offset: 0x3a8 // Size: 0x08
	struct UWidgetSwitcher* WidgetSwitcher_Text; // Offset: 0x3b0 // Size: 0x08

	// Functions

	// Object Name: Function UI_Lobby_DownLoad_Slot.UI_Lobby_DownLoad_Slot_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	struct FString GetModuleName(); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UI_Lobby_DownLoad_Slot.UI_Lobby_DownLoad_Slot_C.SetLineState
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetLineState(bool IsHide); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Lobby_DownLoad_Slot.UI_Lobby_DownLoad_Slot_C.DownStatusChanged
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void DownStatusChanged(enum class ESolarItemDownloadType NewParam); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Lobby_DownLoad_Slot.UI_Lobby_DownLoad_Slot_C.BP_OnEntryReleased
	// Flags: [Event|Protected|BlueprintEvent]
	void BP_OnEntryReleased(); // Offset: 0x103339bc4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Lobby_DownLoad_Slot.UI_Lobby_DownLoad_Slot_C.BP_OnItemExpansionChanged
	// Flags: [Event|Protected|BlueprintEvent]
	void BP_OnItemExpansionChanged(bool bIsExpanded); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Lobby_DownLoad_Slot.UI_Lobby_DownLoad_Slot_C.BP_OnItemSelectionChanged
	// Flags: [Event|Protected|BlueprintEvent]
	void BP_OnItemSelectionChanged(bool bIsSelected); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Lobby_DownLoad_Slot.UI_Lobby_DownLoad_Slot_C.OnListItemObjectSet
	// Flags: [Event|Protected|BlueprintEvent]
	void OnListItemObjectSet(struct UObject* ListItemObject); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UI_Lobby_DownLoad_Slot.UI_Lobby_DownLoad_Slot_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void PreConstruct(bool IsDesignTime); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Lobby_DownLoad_Slot.UI_Lobby_DownLoad_Slot_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Construct(); // Offset: 0x103339bc4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Lobby_DownLoad_Slot.UI_Lobby_DownLoad_Slot_C.BndEvt__Btn_Downing_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature
	// Flags: [BlueprintEvent]
	void BndEvt__Btn_Downing_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Offset: 0x103339bc4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Lobby_DownLoad_Slot.UI_Lobby_DownLoad_Slot_C.ExecuteUbergraph_UI_Lobby_DownLoad_Slot
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_UI_Lobby_DownLoad_Slot(int32_t EntryPoint); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x4)
};

