#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_Lobby_MedalShow.UI_Lobby_MedalShow_C
// Size: 0x36c // Inherited bytes: 0x348
struct UUI_Lobby_MedalShow_C : USolarUserWidget {
	// Fields
	struct UImage* Img_MedalBG; // Offset: 0x348 // Size: 0x08
	struct UUI_Target_Card_Medal_Item_C* MedalItem_2; // Offset: 0x350 // Size: 0x08
	struct UUI_Target_Card_Medal_Item_C* MedalItem_3; // Offset: 0x358 // Size: 0x08
	struct UUI_Target_Card_Medal_Item_C* MedalItem_4; // Offset: 0x360 // Size: 0x08
	int32_t IndexInLobby; // Offset: 0x368 // Size: 0x04

	// Functions

	// Object Name: Function UI_Lobby_MedalShow.UI_Lobby_MedalShow_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	struct FString GetModuleName(); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x10)
};

