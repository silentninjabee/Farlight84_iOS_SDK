#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_Lobby_Mention_Container.UI_Lobby_Mention_Container_C
// Size: 0x350 // Inherited bytes: 0x348
struct UUI_Lobby_Mention_Container_C : USolarUserWidget {
	// Fields
	struct UCanvasPanel* CanvasPanel_Container; // Offset: 0x348 // Size: 0x08

	// Functions

	// Object Name: Function UI_Lobby_Mention_Container.UI_Lobby_Mention_Container_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	struct FString GetModuleName(); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x10)
};

