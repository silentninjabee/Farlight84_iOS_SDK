#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_Lobby_RoomInvite_Popup.UI_Lobby_RoomInvite_Popup_C
// Size: 0x57b // Inherited bytes: 0x348
struct UUI_Lobby_RoomInvite_Popup_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x348 // Size: 0x08
	struct UWidgetAnimation* Anim_Loop; // Offset: 0x350 // Size: 0x08
	struct UWidgetAnimation* Anim_Exit; // Offset: 0x358 // Size: 0x08
	struct UWidgetAnimation* Anim_Enter; // Offset: 0x360 // Size: 0x08
	struct USolarButton* Btn_Join_Common; // Offset: 0x368 // Size: 0x08
	struct USolarButton* Btn_Join_League; // Offset: 0x370 // Size: 0x08
	struct USolarButton* Btn_Joining; // Offset: 0x378 // Size: 0x08
	struct UButton* Btn_Player; // Offset: 0x380 // Size: 0x08
	struct UButton* Btn_Player_2; // Offset: 0x388 // Size: 0x08
	struct USolarButton* Btn_Watch; // Offset: 0x390 // Size: 0x08
	struct UHorizontalBox* HorizentalBox_Match; // Offset: 0x398 // Size: 0x08
	struct UHorizontalBox* HorizentalBox_Spectator; // Offset: 0x3a0 // Size: 0x08
	struct UHorizontalBox* HorizontalBox_Join; // Offset: 0x3a8 // Size: 0x08
	struct UHorizontalBox* HorizontalBox_Joining_2; // Offset: 0x3b0 // Size: 0x08
	struct UHorizontalBox* HorizontalBox_League; // Offset: 0x3b8 // Size: 0x08
	struct UHorizontalBox* HorizontalBox_Player; // Offset: 0x3c0 // Size: 0x08
	struct UHorizontalBox* HorizontalBox_Title_Common; // Offset: 0x3c8 // Size: 0x08
	struct UHorizontalBox* HorizontalBox_Title_Common_2; // Offset: 0x3d0 // Size: 0x08
	struct UHorizontalBox* HorizontalBox_Title_League; // Offset: 0x3d8 // Size: 0x08
	struct UHorizontalBox* HorizontalBox_Watch; // Offset: 0x3e0 // Size: 0x08
	struct UImage* Img_BG_Light; // Offset: 0x3e8 // Size: 0x08
	struct UImage* Img_BG_Light_01; // Offset: 0x3f0 // Size: 0x08
	struct UImage* Img_Btn_Join; // Offset: 0x3f8 // Size: 0x08
	struct UImage* Img_Btn_Join_2; // Offset: 0x400 // Size: 0x08
	struct UImage* Img_Btn_Joining_Close; // Offset: 0x408 // Size: 0x08
	struct UImage* Img_Btn_Watch; // Offset: 0x410 // Size: 0x08
	struct UImage* Img_Division; // Offset: 0x418 // Size: 0x08
	struct UImage* Img_Join_Common_Light; // Offset: 0x420 // Size: 0x08
	struct UImage* Img_Join_Light; // Offset: 0x428 // Size: 0x08
	struct USolarImageURL* Img_League_Icon; // Offset: 0x430 // Size: 0x08
	struct UImage* Img_Title_BG; // Offset: 0x438 // Size: 0x08
	struct UImage* Img_Title_BG_2; // Offset: 0x440 // Size: 0x08
	struct UImage* Img_Watch_Light; // Offset: 0x448 // Size: 0x08
	struct UOverlay* Overlay_Avatar; // Offset: 0x450 // Size: 0x08
	struct UOverlay* Overlay_Avatar_2; // Offset: 0x458 // Size: 0x08
	struct UOverlay* Overlay_Cup; // Offset: 0x460 // Size: 0x08
	struct UCanvasPanel* Panel_Info_CreateRoom; // Offset: 0x468 // Size: 0x08
	struct UCanvasPanel* Panel_Info_Invitation; // Offset: 0x470 // Size: 0x08
	struct UCanvasPanel* Panel_Pop_Common; // Offset: 0x478 // Size: 0x08
	struct UCanvasPanel* Panel_Pop_League; // Offset: 0x480 // Size: 0x08
	struct USolarRichTextBlock* RichTxt_LvlRequired; // Offset: 0x488 // Size: 0x08
	struct USolarTextBlock* Txt_Capacity; // Offset: 0x490 // Size: 0x08
	struct USolarTextBlock* Txt_Clan_Quantity; // Offset: 0x498 // Size: 0x08
	struct USolarTextBlock* Txt_GameMode; // Offset: 0x4a0 // Size: 0x08
	struct USolarTextBlock* Txt_GameMode_2; // Offset: 0x4a8 // Size: 0x08
	struct USolarTextBlock* Txt_Invitation; // Offset: 0x4b0 // Size: 0x08
	struct USolarTextBlock* Txt_Join; // Offset: 0x4b8 // Size: 0x08
	struct USolarTextBlock* Txt_Join_Common; // Offset: 0x4c0 // Size: 0x08
	struct USolarTextBlock* Txt_Joining; // Offset: 0x4c8 // Size: 0x08
	struct USolarTextBlock* Txt_League_Name; // Offset: 0x4d0 // Size: 0x08
	struct USolarTextBlock* Txt_Map; // Offset: 0x4d8 // Size: 0x08
	struct USolarTextBlock* Txt_Map_2; // Offset: 0x4e0 // Size: 0x08
	struct USolarTextBlock* Txt_Map_3; // Offset: 0x4e8 // Size: 0x08
	struct USolarTextBlock* Txt_Mode; // Offset: 0x4f0 // Size: 0x08
	struct USolarTextBlock* Txt_Number; // Offset: 0x4f8 // Size: 0x08
	struct UTextBlock* Txt_OBCurr; // Offset: 0x500 // Size: 0x08
	struct UTextBlock* Txt_OBCurr_2; // Offset: 0x508 // Size: 0x08
	struct UTextBlock* Txt_OBCurr_4; // Offset: 0x510 // Size: 0x08
	struct USolarTextBlock* Txt_OBTotal; // Offset: 0x518 // Size: 0x08
	struct USolarTextBlock* Txt_PlayerIn; // Offset: 0x520 // Size: 0x08
	struct UTextBlock* Txt_PlayerName; // Offset: 0x528 // Size: 0x08
	struct USolarTextBlock* Txt_Progress_Des; // Offset: 0x530 // Size: 0x08
	struct USolarTextBlock* Txt_Progress_Time; // Offset: 0x538 // Size: 0x08
	struct USolarTextBlock* Txt_RoomName; // Offset: 0x540 // Size: 0x08
	struct USolarTextBlock* Txt_Watch; // Offset: 0x548 // Size: 0x08
	struct UUI_Component_Close_C* UI_Component_Close; // Offset: 0x550 // Size: 0x08
	struct UUI_Component_Platform_C* UI_Component_Platform; // Offset: 0x558 // Size: 0x08
	struct UUI_Component_PlayerHead_C* UI_Component_PlayerHead; // Offset: 0x560 // Size: 0x08
	struct UUI_Component_PlayerHead_C* UI_Component_PlayerHead_2; // Offset: 0x568 // Size: 0x08
	struct UVerticalBox* VerticalBox_League; // Offset: 0x570 // Size: 0x08
	enum class E_Type_CreateRoom_Gender Gender; // Offset: 0x578 // Size: 0x01
	enum class T_Type_System_Push Pop_Type; // Offset: 0x579 // Size: 0x01
	enum class T_Type_Button Btn_Type; // Offset: 0x57a // Size: 0x01

	// Functions

	// Object Name: Function UI_Lobby_RoomInvite_Popup.UI_Lobby_RoomInvite_Popup_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	struct FString GetModuleName(); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UI_Lobby_RoomInvite_Popup.UI_Lobby_RoomInvite_Popup_C.Update_Btn
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void Update_Btn(enum class T_Type_Button NewParam); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Lobby_RoomInvite_Popup.UI_Lobby_RoomInvite_Popup_C.SetType
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SetType(enum class T_Type_System_Push NewParam); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Lobby_RoomInvite_Popup.UI_Lobby_RoomInvite_Popup_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void PreConstruct(bool IsDesignTime); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Lobby_RoomInvite_Popup.UI_Lobby_RoomInvite_Popup_C.ExecuteUbergraph_UI_Lobby_RoomInvite_Popup
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_UI_Lobby_RoomInvite_Popup(int32_t EntryPoint); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x4)
};

