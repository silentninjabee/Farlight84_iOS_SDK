#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_Lobby_Sanctuary.UI_Lobby_Sanctuary_C
// Size: 0x392 // Inherited bytes: 0x348
struct UUI_Lobby_Sanctuary_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x348 // Size: 0x08
	struct UButton* Btn_Sanctuary; // Offset: 0x350 // Size: 0x08
	struct UBtn_Unlock_Anim_2_C* Btn_Unlock_Anim_2; // Offset: 0x358 // Size: 0x08
	struct UImage* Img_Arrow; // Offset: 0x360 // Size: 0x08
	struct UCanvasPanel* Panel_Sanctuary; // Offset: 0x368 // Size: 0x08
	struct UCanvasPanel* Panel_SanctuaryContent; // Offset: 0x370 // Size: 0x08
	struct UUI_Anim_Circle_1_C* Sanctuary_Matching; // Offset: 0x378 // Size: 0x08
	struct UHorizontalBox* Txt_Sanctuary; // Offset: 0x380 // Size: 0x08
	struct UOverlay* UI_Lobby_Sanctuary; // Offset: 0x388 // Size: 0x08
	bool Locked; // Offset: 0x390 // Size: 0x01
	bool Matching; // Offset: 0x391 // Size: 0x01

	// Functions

	// Object Name: Function UI_Lobby_Sanctuary.UI_Lobby_Sanctuary_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	struct FString GetModuleName(); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UI_Lobby_Sanctuary.UI_Lobby_Sanctuary_C.BP_RefreshSanctuaryUI
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void BP_RefreshSanctuaryUI(bool bInLocked, bool bInMatching); // Offset: 0x103339bc4 // Return & Params: Num(2) Size(0x2)

	// Object Name: Function UI_Lobby_Sanctuary.UI_Lobby_Sanctuary_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void PreConstruct(bool IsDesignTime); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Lobby_Sanctuary.UI_Lobby_Sanctuary_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Construct(); // Offset: 0x10138cf2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Lobby_Sanctuary.UI_Lobby_Sanctuary_C.ExecuteUbergraph_UI_Lobby_Sanctuary
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_UI_Lobby_Sanctuary(int32_t EntryPoint); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x4)
};

