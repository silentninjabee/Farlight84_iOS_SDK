#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_Rank_Icon_Small.UI_Rank_Icon_Small_C
// Size: 0x39c // Inherited bytes: 0x348
struct UUI_Rank_Icon_Small_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x348 // Size: 0x08
	struct UImage* Img_Rank; // Offset: 0x350 // Size: 0x08
	struct UImage* Img_Rank_Word; // Offset: 0x358 // Size: 0x08
	struct USizeBox* Size_Rank; // Offset: 0x360 // Size: 0x08
	struct USizeBox* Size_Txt; // Offset: 0x368 // Size: 0x08
	struct USolarTextBlock* TextBlock_StarNum; // Offset: 0x370 // Size: 0x08
	struct USolarTextBlock* Txt_LegendRank; // Offset: 0x378 // Size: 0x08
	struct UWidgetSwitcher* WidgetSwitcher_Detail; // Offset: 0x380 // Size: 0x08
	int32_t LevelID; // Offset: 0x388 // Size: 0x04
	bool STAR; // Offset: 0x38c // Size: 0x01
	char pad_0x38D[0x3]; // Offset: 0x38d // Size: 0x03
	int32_t IconSize; // Offset: 0x390 // Size: 0x04
	struct FVector2D TxtSize; // Offset: 0x394 // Size: 0x08

	// Functions

	// Object Name: Function UI_Rank_Icon_Small.UI_Rank_Icon_Small_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	struct FString GetModuleName(); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UI_Rank_Icon_Small.UI_Rank_Icon_Small_C.FormatViewJustIcon
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void FormatViewJustIcon(int32_t LevelID); // Offset: 0x10138cf2c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UI_Rank_Icon_Small.UI_Rank_Icon_Small_C.SetStar
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetStar(bool STAR); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Rank_Icon_Small.UI_Rank_Icon_Small_C.FormatView
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void FormatView(int32_t LevelID); // Offset: 0x10138cf2c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UI_Rank_Icon_Small.UI_Rank_Icon_Small_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void PreConstruct(bool IsDesignTime); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Rank_Icon_Small.UI_Rank_Icon_Small_C.SetRankIconView
	// Flags: [BlueprintCallable|BlueprintEvent]
	void SetRankIconView(int32_t Param); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UI_Rank_Icon_Small.UI_Rank_Icon_Small_C.ExecuteUbergraph_UI_Rank_Icon_Small
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_UI_Rank_Icon_Small(int32_t EntryPoint); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x4)
};

