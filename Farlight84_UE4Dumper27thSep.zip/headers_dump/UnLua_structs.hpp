#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct UnLua.PropertyCollector
// Size: 0x01 // Inherited bytes: 0x00
struct FPropertyCollector {
	// Fields
	enum class ETutorialTriggerType None; // Offset: 0x00 // Size: 0x01
	struct AActor* None; // Offset: 0x00 // Size: 0x08
	int32_t None; // Offset: 0x00 // Size: 0x04
	struct UObject* None; // Offset: 0x00 // Size: 0x08
	struct FTutorialTableRow None; // Offset: 0x00 // Size: 0x98
	struct FGateAddress_Dep None; // Offset: 0x00 // Size: 0x20
	struct FServerInfo_Dep None; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct UnLua.InSightEvent
// Size: 0x01 // Inherited bytes: 0x00
struct FInSightEvent {
	// Fields
	char pad_0x0[0x1]; // Offset: 0x00 // Size: 0x01
};

