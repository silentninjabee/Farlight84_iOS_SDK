#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass WAT_VH_Hover_9A03_Rocket_Burst.WAT_VH_Hover_9A03_Rocket_Burst_C
// Size: 0xf0 // Inherited bytes: 0xf0
struct UWAT_VH_Hover_9A03_Rocket_Burst_C : USolarWeaponAT_FireBurst {
};

