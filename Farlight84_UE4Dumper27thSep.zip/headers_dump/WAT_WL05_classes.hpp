#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass WAT_WL05.WAT_WL05_C
// Size: 0xf0 // Inherited bytes: 0xf0
struct UWAT_WL05_C : USolarWeaponAT_FireBurst {
};

