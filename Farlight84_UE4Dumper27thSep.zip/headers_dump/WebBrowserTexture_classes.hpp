#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class WebBrowserTexture.WebBrowserTexture
// Size: 0x100 // Inherited bytes: 0xb8
struct UWebBrowserTexture : UTexture {
	// Fields
	char pad_0xB8[0x48]; // Offset: 0xb8 // Size: 0x48
};

