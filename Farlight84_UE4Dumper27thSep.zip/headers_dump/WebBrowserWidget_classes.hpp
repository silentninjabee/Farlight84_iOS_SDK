#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class WebBrowserWidget.WebBrowser
// Size: 0x1a0 // Inherited bytes: 0x138
struct UWebBrowser : UWidget {
	// Fields
	struct FMulticastInlineDelegate OnUrlChanged; // Offset: 0x138 // Size: 0x10
	struct FMulticastInlineDelegate OnBeforePopup; // Offset: 0x148 // Size: 0x10
	struct FMulticastInlineDelegate OnBeforeNavigation; // Offset: 0x158 // Size: 0x10
	struct TArray<struct FString> URLKeywordWithoutNavigation; // Offset: 0x168 // Size: 0x10
	struct FString InitialURL; // Offset: 0x178 // Size: 0x10
	bool bSupportsTransparency; // Offset: 0x188 // Size: 0x01
	char pad_0x189[0x17]; // Offset: 0x189 // Size: 0x17

	// Functions

	// Object Name: Function WebBrowserWidget.WebBrowser.StopLoad
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StopLoad(); // Offset: 0x1014ed360 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function WebBrowserWidget.WebBrowser.SetURLWithoutNavigation
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetURLWithoutNavigation(struct TArray<struct FString>& URLs); // Offset: 0x1014ed294 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function WebBrowserWidget.WebBrowser.Reload
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Reload(); // Offset: 0x1014ed374 // Return & Params: Num(0) Size(0x0)

	// Object Name: DelegateFunction WebBrowserWidget.WebBrowser.OnUrlChanged__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void OnUrlChanged__DelegateSignature(struct FText& Text); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x18)

	// Object Name: DelegateFunction WebBrowserWidget.WebBrowser.OnBeforePopup__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnBeforePopup__DelegateSignature(struct FString URL, struct FString Frame); // Offset: 0x103339bc4 // Return & Params: Num(2) Size(0x20)

	// Object Name: DelegateFunction WebBrowserWidget.WebBrowser.OnBeforeNavigation__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnBeforeNavigation__DelegateSignature(struct FString URL); // Offset: 0x103339bc4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function WebBrowserWidget.WebBrowser.LoadURL
	// Flags: [Final|Native|Public|BlueprintCallable]
	void LoadURL(struct FString NewURL); // Offset: 0x1014ed820 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function WebBrowserWidget.WebBrowser.LoadString
	// Flags: [Final|Native|Public|BlueprintCallable]
	void LoadString(struct FString Contents, struct FString DummyURL); // Offset: 0x1014ed67c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function WebBrowserWidget.WebBrowser.GetUrl
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FString GetUrl(); // Offset: 0x1014ed4c8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function WebBrowserWidget.WebBrowser.GetTitleText
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FText GetTitleText(); // Offset: 0x1014ed548 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function WebBrowserWidget.WebBrowser.ExecuteJavascript
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ExecuteJavascript(struct FString ScriptText); // Offset: 0x1014ed5f0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function WebBrowserWidget.WebBrowser.CloseSelf
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CloseSelf(); // Offset: 0x1014ed388 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function WebBrowserWidget.WebBrowser.BindUObject
	// Flags: [Final|Native|Public|BlueprintCallable]
	void BindUObject(struct FString Name, struct UObject* Object, bool bIsPermanent); // Offset: 0x1014ed39c // Return & Params: Num(3) Size(0x19)
};

// Object Name: Class WebBrowserWidget.WebBrowserAssetManager
// Size: 0x78 // Inherited bytes: 0x28
struct UWebBrowserAssetManager : UObject {
	// Fields
	struct TSoftObjectPtr<UMaterial> DefaultMaterial; // Offset: 0x28 // Size: 0x28
	char pad_0x50[0x28]; // Offset: 0x50 // Size: 0x28
};

