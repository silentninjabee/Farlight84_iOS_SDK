#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: DynamicClass ABP_SolarCharacter_FPP.ABP_SolarCharacter_FPP_C
// Size: 0x680 // Inherited bytes: 0x270
struct UABP_SolarCharacter_FPP_C : UAnimInstance {
	// Fields
	struct FAnimNode_Root AnimGraphNode_Root; // Offset: 0x268 // Size: 0x30
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_2; // Offset: 0x298 // Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult; // Offset: 0x2c0 // Size: 0x28
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_3; // Offset: 0x2e8 // Size: 0x78
	struct FAnimNode_StateResult AnimGraphNode_StateResult_2; // Offset: 0x360 // Size: 0x30
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2; // Offset: 0x390 // Size: 0x78
	struct FAnimNode_StateResult AnimGraphNode_StateResult; // Offset: 0x408 // Size: 0x30
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine; // Offset: 0x438 // Size: 0xb0
	struct FAnimNode_Slot AnimGraphNode_Slot; // Offset: 0x4e8 // Size: 0x48
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer; // Offset: 0x530 // Size: 0x78
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool; // Offset: 0x5a8 // Size: 0xa0
	struct ASolarCharacter* SolarCharacter; // Offset: 0x648 // Size: 0x08
	bool IsScopeAim; // Offset: 0x650 // Size: 0x01
	float ScopeFadeTime; // Offset: 0x654 // Size: 0x04
	bool IsWalking; // Offset: 0x658 // Size: 0x01
	bool IsShooting; // Offset: 0x659 // Size: 0x01
	bool ShootDouble; // Offset: 0x65a // Size: 0x01
	float Horizontal; // Offset: 0x65c // Size: 0x04
	float Vertical; // Offset: 0x660 // Size: 0x04
	bool bUseAnim; // Offset: 0x664 // Size: 0x01
	float K2Node_Event_DeltaTimeX; // Offset: 0x668 // Size: 0x04
	char pad_0x66D[0x3]; // Offset: 0x66d // Size: 0x03
	struct ASolarCharacter* K2Node_DynamicCast_AsSolar_Character; // Offset: 0x670 // Size: 0x08
	bool K2Node_DynamicCast_bSuccess; // Offset: 0x678 // Size: 0x01
	char pad_0x679[0x7]; // Offset: 0x679 // Size: 0x07

	// Functions

	// Object Name: Function ABP_SolarCharacter_FPP.ABP_SolarCharacter_FPP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_SolarCharacter_FPP_AnimGraphNode_TransitionResult_768665AB4918F96C9C3C8F92EF926EE4
	// Flags: [Native|Public]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_SolarCharacter_FPP_AnimGraphNode_TransitionResult_768665AB4918F96C9C3C8F92EF926EE4(); // Offset: 0x101930264 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function ABP_SolarCharacter_FPP.ABP_SolarCharacter_FPP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_SolarCharacter_FPP_AnimGraphNode_TransitionResult_01B670704C4A0F8E519CD8A192C5E1D6
	// Flags: [Native|Public]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_SolarCharacter_FPP_AnimGraphNode_TransitionResult_01B670704C4A0F8E519CD8A192C5E1D6(); // Offset: 0x10193022c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function ABP_SolarCharacter_FPP.ABP_SolarCharacter_FPP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_SolarCharacter_FPP_AnimGraphNode_BlendListByBool_F136F87A4DDCD2678555C9B592100DA7
	// Flags: [Native|Public]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_SolarCharacter_FPP_AnimGraphNode_BlendListByBool_F136F87A4DDCD2678555C9B592100DA7(); // Offset: 0x101930248 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function ABP_SolarCharacter_FPP.ABP_SolarCharacter_FPP_C.BlueprintUpdateAnimation
	// Flags: [Native|Event|Public]
	void BlueprintUpdateAnimation(float bpp__DeltaTimeX__pf); // Offset: 0x101930280 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function ABP_SolarCharacter_FPP.ABP_SolarCharacter_FPP_C.BlueprintInitializeAnimation
	// Flags: [Native|Event|Public]
	void BlueprintInitializeAnimation(); // Offset: 0x101930320 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function ABP_SolarCharacter_FPP.ABP_SolarCharacter_FPP_C.BlueprintBeginPlay
	// Flags: [Native|Event|Public]
	void BlueprintBeginPlay(); // Offset: 0x101930304 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function ABP_SolarCharacter_FPP.ABP_SolarCharacter_FPP_C.AnimGraph
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	void AnimGraph(struct FPoseLink& bpp__AnimGraph__pf); // Offset: 0x10193018c // Return & Params: Num(1) Size(0x10)
};

