#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: DynamicClass Anim_LAnim_LobbyCharacter_YJ_WithPhysics.Anim_LAnim_LobbyCharacter_YJ_WithPhysics_C
// Size: 0x1f10 // Inherited bytes: 0x270
struct UAnim_LAnim_LobbyCharacter_YJ_WithPhysics_C : USolarLobbyAnimInstance {
	// Fields
	struct FAnimNode_Root AnimGraphNode_Root_2; // Offset: 0x270 // Size: 0x30
	struct FAnimNode_LinkedInputPose AnimGraphNode_LinkedInputPose; // Offset: 0x2a0 // Size: 0x78
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace; // Offset: 0x318 // Size: 0x20
	char pad_0x338[0x8]; // Offset: 0x338 // Size: 0x08
	struct FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_9; // Offset: 0x340 // Size: 0x250
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace; // Offset: 0x590 // Size: 0x20
	struct FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_8; // Offset: 0x5b0 // Size: 0x250
	struct FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_7; // Offset: 0x800 // Size: 0x250
	struct FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_6; // Offset: 0xa50 // Size: 0x250
	struct FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_5; // Offset: 0xca0 // Size: 0x250
	struct FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_4; // Offset: 0xef0 // Size: 0x250
	struct FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_3; // Offset: 0x1140 // Size: 0x250
	struct FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics_2; // Offset: 0x1390 // Size: 0x250
	struct FAnimNode_KawaiiPhysics AnimGraphNode_KawaiiPhysics; // Offset: 0x15e0 // Size: 0x250
	struct FAnimNode_Root AnimGraphNode_Root; // Offset: 0x1830 // Size: 0x30
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_2; // Offset: 0x1860 // Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult; // Offset: 0x1888 // Size: 0x28
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_3; // Offset: 0x18b0 // Size: 0x78
	struct FAnimNode_StateResult AnimGraphNode_StateResult_2; // Offset: 0x1928 // Size: 0x30
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2; // Offset: 0x1958 // Size: 0x78
	struct FAnimNode_StateResult AnimGraphNode_StateResult; // Offset: 0x19d0 // Size: 0x30
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine; // Offset: 0x1a00 // Size: 0xb0
	struct FAnimNode_LinkedAnimLayer AnimGraphNode_LinkedAnimLayer; // Offset: 0x1ab0 // Size: 0xb8
	struct FAnimNode_TwoWayBlend AnimGraphNode_TwoWayBlend_2; // Offset: 0x1b68 // Size: 0xc8
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose; // Offset: 0x1c30 // Size: 0xb8
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_2; // Offset: 0x1ce8 // Size: 0x28
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose; // Offset: 0x1d10 // Size: 0x28
	struct FAnimNode_Slot AnimGraphNode_Slot; // Offset: 0x1d38 // Size: 0x48
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer; // Offset: 0x1d80 // Size: 0x78
	struct FAnimNode_TwoWayBlend AnimGraphNode_TwoWayBlend; // Offset: 0x1df8 // Size: 0xc8
	struct UAnimSequenceBase* IdleAnim; // Offset: 0x1ec0 // Size: 0x08
	struct UAnimSequenceBase* CurIdleShow; // Offset: 0x1ec8 // Size: 0x08
	struct TArray<struct UAnimSequenceBase*> IdleShowList; // Offset: 0x1ed0 // Size: 0x10
	bool ShouldPlayShow; // Offset: 0x1ee0 // Size: 0x01
	char pad_0x1EE1[0x3]; // Offset: 0x1ee1 // Size: 0x03
	float ShowCDTime; // Offset: 0x1ee4 // Size: 0x04
	struct FTimerHandle IdleShowCD; // Offset: 0x1ee8 // Size: 0x08
	int32_t MaxNum; // Offset: 0x1ef0 // Size: 0x04
	bool EnablePhysics; // Offset: 0x1ef4 // Size: 0x01
	bool EnablePhysicsForMVP; // Offset: 0x1ef5 // Size: 0x01
	bool IdleShowDisablePhysics; // Offset: 0x1ef6 // Size: 0x01
	bool InIdleShow; // Offset: 0x1ef7 // Size: 0x01
	bool CharacterCanBeLooked; // Offset: 0x1ef8 // Size: 0x01
	bool K2Node_Event_IsVisible; // Offset: 0x1ef9 // Size: 0x01
	char pad_0x1EFA[0x2]; // Offset: 0x1efa // Size: 0x02
	struct FDelegate K2Node_CreateDelegate_OutputDelegate; // Offset: 0x1efc // Size: 0x10
	char pad_0x1F0C[0x4]; // Offset: 0x1f0c // Size: 0x04

	// Functions

	// Object Name: Function Anim_LAnim_LobbyCharacter_YJ_WithPhysics.Anim_LAnim_LobbyCharacter_YJ_WithPhysics_C.UsingKawaiiPhysics
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	void UsingKawaiiPhysics(struct FPoseLink bpp__InPose__pf, struct FPoseLink& bpp__UsingKawaiiPhysics__pf); // Offset: 0x10194f5d8 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function Anim_LAnim_LobbyCharacter_YJ_WithPhysics.Anim_LAnim_LobbyCharacter_YJ_WithPhysics_C.SetCharacterCanBeLooked
	// Flags: [Native|Event|Public]
	void SetCharacterCanBeLooked(bool bpp__IsVisible__pf); // Offset: 0x10194f8b0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Anim_LAnim_LobbyCharacter_YJ_WithPhysics.Anim_LAnim_LobbyCharacter_YJ_WithPhysics_C.Rand Idle Show BP
	// Flags: [Native|Public|BlueprintCallable]
	void Rand Idle Show BP(); // Offset: 0x10194f760 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Anim_LAnim_LobbyCharacter_YJ_WithPhysics.Anim_LAnim_LobbyCharacter_YJ_WithPhysics_C.RandIdleShow
	// Flags: [Native|Event|Public]
	void RandIdleShow(); // Offset: 0x10194f894 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Anim_LAnim_LobbyCharacter_YJ_WithPhysics.Anim_LAnim_LobbyCharacter_YJ_WithPhysics_C.PlayIdleShow
	// Flags: [Native|Public|BlueprintCallable]
	void PlayIdleShow(); // Offset: 0x10194f85c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Anim_LAnim_LobbyCharacter_YJ_WithPhysics.Anim_LAnim_LobbyCharacter_YJ_WithPhysics_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_LAnim_LobbyCharacter_YJ_WithPhysics_AnimGraphNode_TwoWayBlend_DD4F43D643A1933455AB6FBA04D3A934
	// Flags: [Native|Public]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_LAnim_LobbyCharacter_YJ_WithPhysics_AnimGraphNode_TwoWayBlend_DD4F43D643A1933455AB6FBA04D3A934(); // Offset: 0x10194f77c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Anim_LAnim_LobbyCharacter_YJ_WithPhysics.Anim_LAnim_LobbyCharacter_YJ_WithPhysics_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_LAnim_LobbyCharacter_YJ_WithPhysics_AnimGraphNode_TwoWayBlend_B3E20B3D4576802299919FBB3C7AB8BD
	// Flags: [Native|Public]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_LAnim_LobbyCharacter_YJ_WithPhysics_AnimGraphNode_TwoWayBlend_B3E20B3D4576802299919FBB3C7AB8BD(); // Offset: 0x10194f798 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Anim_LAnim_LobbyCharacter_YJ_WithPhysics.Anim_LAnim_LobbyCharacter_YJ_WithPhysics_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_LAnim_LobbyCharacter_YJ_WithPhysics_AnimGraphNode_TransitionResult_D61A333844A6447FE13D5E9091EA6B11
	// Flags: [Native|Public]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_LAnim_LobbyCharacter_YJ_WithPhysics_AnimGraphNode_TransitionResult_D61A333844A6447FE13D5E9091EA6B11(); // Offset: 0x10194f824 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Anim_LAnim_LobbyCharacter_YJ_WithPhysics.Anim_LAnim_LobbyCharacter_YJ_WithPhysics_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_LAnim_LobbyCharacter_YJ_WithPhysics_AnimGraphNode_TransitionResult_96CDD72B44E1D0660830B99995001C86
	// Flags: [Native|Public]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_LAnim_LobbyCharacter_YJ_WithPhysics_AnimGraphNode_TransitionResult_96CDD72B44E1D0660830B99995001C86(); // Offset: 0x10194f808 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Anim_LAnim_LobbyCharacter_YJ_WithPhysics.Anim_LAnim_LobbyCharacter_YJ_WithPhysics_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_LAnim_LobbyCharacter_YJ_WithPhysics_AnimGraphNode_SequencePlayer_EC3AFAED45F6C04B98AF35830F9CC345
	// Flags: [Native|Public]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_LAnim_LobbyCharacter_YJ_WithPhysics_AnimGraphNode_SequencePlayer_EC3AFAED45F6C04B98AF35830F9CC345(); // Offset: 0x10194f7ec // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Anim_LAnim_LobbyCharacter_YJ_WithPhysics.Anim_LAnim_LobbyCharacter_YJ_WithPhysics_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_LAnim_LobbyCharacter_YJ_WithPhysics_AnimGraphNode_SequencePlayer_7002C6C445FEED34AE2E2BA193AE9F39
	// Flags: [Native|Public]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_LAnim_LobbyCharacter_YJ_WithPhysics_AnimGraphNode_SequencePlayer_7002C6C445FEED34AE2E2BA193AE9F39(); // Offset: 0x10194f7b4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Anim_LAnim_LobbyCharacter_YJ_WithPhysics.Anim_LAnim_LobbyCharacter_YJ_WithPhysics_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_LAnim_LobbyCharacter_YJ_WithPhysics_AnimGraphNode_SequencePlayer_19F748D544C91EFAA6959D8B587AC643
	// Flags: [Native|Public]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_LAnim_LobbyCharacter_YJ_WithPhysics_AnimGraphNode_SequencePlayer_19F748D544C91EFAA6959D8B587AC643(); // Offset: 0x10194f7d0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Anim_LAnim_LobbyCharacter_YJ_WithPhysics.Anim_LAnim_LobbyCharacter_YJ_WithPhysics_C.AnimNotify_IdleShowStart
	// Flags: [Native|Public|BlueprintCallable]
	void AnimNotify_IdleShowStart(); // Offset: 0x10194f840 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Anim_LAnim_LobbyCharacter_YJ_WithPhysics.Anim_LAnim_LobbyCharacter_YJ_WithPhysics_C.AnimNotify_IdleAnimStart
	// Flags: [Native|Public|BlueprintCallable]
	void AnimNotify_IdleAnimStart(); // Offset: 0x10194f878 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Anim_LAnim_LobbyCharacter_YJ_WithPhysics.Anim_LAnim_LobbyCharacter_YJ_WithPhysics_C.AnimGraph
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	void AnimGraph(struct FPoseLink& bpp__AnimGraph__pf); // Offset: 0x10194f6c0 // Return & Params: Num(1) Size(0x10)
};

