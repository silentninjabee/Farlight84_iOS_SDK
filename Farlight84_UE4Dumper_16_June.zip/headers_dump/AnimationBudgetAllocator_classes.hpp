#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class AnimationBudgetAllocator.AnimationBudgetBlueprintLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct UAnimationBudgetBlueprintLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function AnimationBudgetAllocator.AnimationBudgetBlueprintLibrary.SetAnimationBudgetParameters
	// Flags: [Final|Native|Static|Private|HasOutParms|BlueprintCallable]
	void SetAnimationBudgetParameters(struct UObject* WorldContextObject, struct FAnimationBudgetAllocatorParameters& InParameters); // Offset: 0x100f1cc18 // Return & Params: Num(2) Size(0x5c)

	// Object Name: Function AnimationBudgetAllocator.AnimationBudgetBlueprintLibrary.EnableAnimationBudget
	// Flags: [Final|Native|Static|Private|BlueprintCallable]
	void EnableAnimationBudget(struct UObject* WorldContextObject, bool bEnabled); // Offset: 0x100f1cd54 // Return & Params: Num(2) Size(0x9)
};

// Object Name: Class AnimationBudgetAllocator.SkeletalMeshComponentBudgeted
// Size: 0xc70 // Inherited bytes: 0xc50
struct USkeletalMeshComponentBudgeted : USkeletalMeshComponent {
	// Fields
	char pad_0xC50[0x18]; // Offset: 0xc50 // Size: 0x18
	char bAutoRegisterWithBudgetAllocator : 1; // Offset: 0xc68 // Size: 0x01
	char bAutoCalculateSignificance : 1; // Offset: 0xc68 // Size: 0x01
	char bShouldUseActorRenderedFlag : 1; // Offset: 0xc68 // Size: 0x01
	char pad_0xC68_3 : 5; // Offset: 0xc68 // Size: 0x01
	char pad_0xC69[0x7]; // Offset: 0xc69 // Size: 0x07

	// Functions

	// Object Name: Function AnimationBudgetAllocator.SkeletalMeshComponentBudgeted.SetAutoRegisterWithBudgetAllocator
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAutoRegisterWithBudgetAllocator(bool bInAutoRegisterWithBudgetAllocator); // Offset: 0x100f1d0b0 // Return & Params: Num(1) Size(0x1)
};

