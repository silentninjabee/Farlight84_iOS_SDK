#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class AssetTags.AssetTagsSubsystem
// Size: 0x30 // Inherited bytes: 0x30
struct UAssetTagsSubsystem : UEngineSubsystem {
	// Functions

	// Object Name: Function AssetTags.AssetTagsSubsystem.GetCollectionsContainingAssetPtr
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct TArray<struct FName> GetCollectionsContainingAssetPtr(struct UObject* AssetPtr); // Offset: 0x101d54660 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function AssetTags.AssetTagsSubsystem.GetCollectionsContainingAssetData
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	struct TArray<struct FName> GetCollectionsContainingAssetData(struct FAssetData& AssetData); // Offset: 0x101d54734 // Return & Params: Num(2) Size(0x60)

	// Object Name: Function AssetTags.AssetTagsSubsystem.GetCollectionsContainingAsset
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct TArray<struct FName> GetCollectionsContainingAsset(struct FName AssetPathName); // Offset: 0x101d54878 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function AssetTags.AssetTagsSubsystem.GetCollections
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct TArray<struct FName> GetCollections(); // Offset: 0x101d54b44 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AssetTags.AssetTagsSubsystem.GetAssetsInCollection
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct TArray<struct FAssetData> GetAssetsInCollection(struct FName Name); // Offset: 0x101d5494c // Return & Params: Num(2) Size(0x18)

	// Object Name: Function AssetTags.AssetTagsSubsystem.CollectionExists
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool CollectionExists(struct FName Name); // Offset: 0x101d54bc4 // Return & Params: Num(2) Size(0x9)
};

