#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BPC_AiManagerBase.BPC_AiManagerBase_C
// Size: 0xe8 // Inherited bytes: 0xb0
struct UBPC_AiManagerBase_C : UActorComponent {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0xb0 // Size: 0x08
	struct FString PreSpawnAiSide; // Offset: 0xb8 // Size: 0x10
	int32_t TeammateCount; // Offset: 0xc8 // Size: 0x04
	char pad_0xCC[0x4]; // Offset: 0xcc // Size: 0x04
	struct TArray<struct ASCMPlayerState*> AIList; // Offset: 0xd0 // Size: 0x10
	int32_t AILevelMax; // Offset: 0xe0 // Size: 0x04
	int32_t DefaultAiLevel; // Offset: 0xe4 // Size: 0x04

	// Functions

	// Object Name: Function BPC_AiManagerBase.BPC_AiManagerBase_C.GetRandomDifficulty
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void GetRandomDifficulty(int32_t& Difficulty); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function BPC_AiManagerBase.BPC_AiManagerBase_C.GetMemberAIOrder
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void GetMemberAIOrder(struct TMap<struct FString, int32_t>& Side-Count); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x50)

	// Object Name: Function BPC_AiManagerBase.BPC_AiManagerBase_C.ReceiveBeginPlay
	// Flags: [Event|Public|BlueprintEvent]
	void ReceiveBeginPlay(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BPC_AiManagerBase.BPC_AiManagerBase_C.OnPlayerJoin
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnPlayerJoin(struct ASCMPlayerState* NewPlayer, bool bIsAi); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x9)

	// Object Name: Function BPC_AiManagerBase.BPC_AiManagerBase_C.CustomEvent_1
	// Flags: [BlueprintCallable|BlueprintEvent]
	void CustomEvent_1(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BPC_AiManagerBase.BPC_AiManagerBase_C.ExecuteUbergraph_BPC_AiManagerBase
	// Flags: [Final|UbergraphFunction|HasDefaults]
	void ExecuteUbergraph_BPC_AiManagerBase(int32_t EntryPoint); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x4)
};

