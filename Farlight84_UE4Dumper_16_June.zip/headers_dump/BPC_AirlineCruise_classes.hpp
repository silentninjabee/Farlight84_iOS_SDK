#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BPC_AirlineCruise.BPC_AirlineCruise_C
// Size: 0x291 // Inherited bytes: 0x190
struct UBPC_AirlineCruise_C : UAirlineCruiseComponent {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x190 // Size: 0x08
	int32_t AirLineID; // Offset: 0x198 // Size: 0x04
	char pad_0x19C[0x4]; // Offset: 0x19c // Size: 0x04
	struct TMap<struct ASolarPlayerState*, struct FVector> EjectLocation; // Offset: 0x1a0 // Size: 0x50
	struct TMap<struct ASolarPlayerState*, struct FVector> LandLocation; // Offset: 0x1f0 // Size: 0x50
	struct TArray<struct ASolarPlayerState*> ForceJumpPlayerList; // Offset: 0x240 // Size: 0x10
	struct TArray<struct ASolarCharacter*> CruisePlayers; // Offset: 0x250 // Size: 0x10
	struct FAirlineData AirlineData; // Offset: 0x260 // Size: 0x28
	float Height; // Offset: 0x288 // Size: 0x04
	float Speed; // Offset: 0x28c // Size: 0x04
	bool ClearAllItems; // Offset: 0x290 // Size: 0x01

	// Functions

	// Object Name: Function BPC_AirlineCruise.BPC_AirlineCruise_C.GetPlayerForceJumped
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	bool GetPlayerForceJumped(struct ASolarPlayerState*& TargetPlayer); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x9)

	// Object Name: Function BPC_AirlineCruise.BPC_AirlineCruise_C.GetPlayerLandLocation
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void GetPlayerLandLocation(struct ASolarPlayerState*& TargetPlayer, struct FVector& Location, bool& Succeed); // Offset: 0x102f8211c // Return & Params: Num(3) Size(0x15)

	// Object Name: Function BPC_AirlineCruise.BPC_AirlineCruise_C.GetPlayerEjectLocation
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void GetPlayerEjectLocation(struct ASolarPlayerState*& TargetPlayer, struct FVector& Location, bool& Succeed); // Offset: 0x102f8211c // Return & Params: Num(3) Size(0x15)

	// Object Name: Function BPC_AirlineCruise.BPC_AirlineCruise_C.GetAirlineData_RealWorld
	// Flags: [Protected|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void GetAirlineData_RealWorld(struct FAirlineData& AirlineData, struct FVector2D& LineStart, struct FVector2D& LineEnd, struct FVector2D& JumpStart, struct FVector2D& JumpEnd); // Offset: 0x102f8211c // Return & Params: Num(5) Size(0x48)

	// Object Name: Function BPC_AirlineCruise.BPC_AirlineCruise_C.MiniMap2RealWorld
	// Flags: [Protected|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void MiniMap2RealWorld(struct FVector2D JumpStart, struct FVector2D JumpEnd, struct FVector2D LineStart, struct FVector2D LineEnd, struct FVector2D& JumpStartR, struct FVector2D& JumpEndR, struct FVector2D& LineStartR, struct FVector2D& LineEndR); // Offset: 0x102f8211c // Return & Params: Num(8) Size(0x40)

	// Object Name: Function BPC_AirlineCruise.BPC_AirlineCruise_C.StartParachutingWithRandomAirline
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void StartParachutingWithRandomAirline(struct TArray<struct ASolarCharacter*>& TargetCharacters, int32_t& Air Line ID); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x14)

	// Object Name: Function BPC_AirlineCruise.BPC_AirlineCruise_C.StartParachuting
	// Flags: [HasOutParms|BlueprintCallable|BlueprintEvent]
	void StartParachuting(struct TArray<struct ASolarCharacter*>& TargetCharacters, bool ClearAllItems, int32_t AirLineID, struct FAirlineData& AirlineData); // Offset: 0x102f8211c // Return & Params: Num(4) Size(0x40)

	// Object Name: Function BPC_AirlineCruise.BPC_AirlineCruise_C.OnPlayerEjectingStateChanged
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnPlayerEjectingStateChanged(enum class E_CharacterEjectState State, struct ASolarCharacter* TargetCharacter); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function BPC_AirlineCruise.BPC_AirlineCruise_C.ExecuteUbergraph_BPC_AirlineCruise
	// Flags: [Final|UbergraphFunction|HasDefaults]
	void ExecuteUbergraph_BPC_AirlineCruise(int32_t EntryPoint); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x4)
};

