#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BPC_BuyResurrection.BPC_BuyResurrection_C
// Size: 0x1cc // Inherited bytes: 0xb8
struct UBPC_BuyResurrection_C : USolarResurrectionComponent {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0xb8 // Size: 0x08
	struct UUI_BuyResurrectionPanel_C* UI_BuyResurrectionPanel; // Offset: 0xc0 // Size: 0x08
	struct ABP_DI_DeathBoxA_TreasureBox_C* DeathBoxRef; // Offset: 0xc8 // Size: 0x08
	struct FVector DeathBoxLoc; // Offset: 0xd0 // Size: 0x0c
	enum class E_BuyResurrectionsState State; // Offset: 0xdc // Size: 0x01
	char pad_0xDD[0x3]; // Offset: 0xdd // Size: 0x03
	int32_t WaitingTime; // Offset: 0xe0 // Size: 0x04
	float ReturnRatio; // Offset: 0xe4 // Size: 0x04
	float StartTime; // Offset: 0xe8 // Size: 0x04
	char pad_0xEC[0x4]; // Offset: 0xec // Size: 0x04
	struct FMulticastInlineDelegate NewStateChange; // Offset: 0xf0 // Size: 0x10
	int32_t NumberOfApplications; // Offset: 0x100 // Size: 0x04
	bool bDeductedOnlyOnceFalg; // Offset: 0x104 // Size: 0x01
	char pad_0x105[0x3]; // Offset: 0x105 // Size: 0x03
	int32_t TeammateSalary; // Offset: 0x108 // Size: 0x04
	int32_t ItemID; // Offset: 0x10c // Size: 0x04
	struct ASolarCharacter* HelpYourTeammates; // Offset: 0x110 // Size: 0x08
	int32_t CompLimitedTime; // Offset: 0x118 // Size: 0x04
	int32_t PurchasesNum; // Offset: 0x11c // Size: 0x04
	struct ASCMPlayerState* WaitingResurrectedPlayer; // Offset: 0x120 // Size: 0x08
	struct FVector CharacterFlyOffset; // Offset: 0x128 // Size: 0x0c
	bool DelayFlag; // Offset: 0x134 // Size: 0x01
	char pad_0x135[0x3]; // Offset: 0x135 // Size: 0x03
	struct FTimerHandle DelaySetTimeOutHandle; // Offset: 0x138 // Size: 0x08
	float BP_SI_RebornLine_Life; // Offset: 0x140 // Size: 0x04
	int32_t SaveTeammatesNum; // Offset: 0x144 // Size: 0x04
	int32_t ZomborgNum; // Offset: 0x148 // Size: 0x04
	char pad_0x14C[0x4]; // Offset: 0x14c // Size: 0x04
	struct TArray<struct FString> SavedTeammateIDArr; // Offset: 0x150 // Size: 0x10
	struct TArray<int32_t> SavedTeammateBonusArr; // Offset: 0x160 // Size: 0x10
	struct FTimerHandle EndJudgmentHander; // Offset: 0x170 // Size: 0x08
	struct TArray<struct FString> SavedTeammateNameArr; // Offset: 0x178 // Size: 0x10
	struct ABP_ReviveItemManger_BattleRoyale_C* ReviveItemManger; // Offset: 0x188 // Size: 0x08
	struct ASolarCharacter* NoneVal; // Offset: 0x190 // Size: 0x08
	int32_t SuccessTime; // Offset: 0x198 // Size: 0x04
	bool TimeLimitDoOnceFlag; // Offset: 0x19c // Size: 0x01
	bool BuyResurrectionSwitch; // Offset: 0x19d // Size: 0x01
	char pad_0x19E[0x2]; // Offset: 0x19e // Size: 0x02
	float TimeoutAccTime; // Offset: 0x1a0 // Size: 0x04
	bool bIsTimeoutCountDownPaused; // Offset: 0x1a4 // Size: 0x01
	char pad_0x1A5[0x3]; // Offset: 0x1a5 // Size: 0x03
	struct FMulticastInlineDelegate TimeoutCountDownStateChanged; // Offset: 0x1a8 // Size: 0x10
	struct FTimerHandle DelayPauseTimeoutHandle; // Offset: 0x1b8 // Size: 0x08
	float ResurrectionClutchTime; // Offset: 0x1c0 // Size: 0x04
	float RemindTeammateEffectCooldown; // Offset: 0x1c4 // Size: 0x04
	float BuyResurrectionInvincibleTime; // Offset: 0x1c8 // Size: 0x04

	// Functions

	// Object Name: Function BPC_BuyResurrection.BPC_BuyResurrection_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	struct FString GetModuleName(); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function BPC_BuyResurrection.BPC_BuyResurrection_C.Get Death Box Loc
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void Get Death Box Loc(struct FVector& Loc); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0xc)

	// Object Name: Function BPC_BuyResurrection.BPC_BuyResurrection_C.Set Death Box Ref
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void Set Death Box Ref(struct ABP_DI_DeathBoxA_TreasureBox_C* InDeathbox); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function BPC_BuyResurrection.BPC_BuyResurrection_C.OnRep_bIsTimeoutCountDownPaused
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnRep_bIsTimeoutCountDownPaused(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BPC_BuyResurrection.BPC_BuyResurrection_C.RefreshUI
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void RefreshUI(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BPC_BuyResurrection.BPC_BuyResurrection_C.OnRep_CompLimitedTime
	// Flags: [HasDefaults|BlueprintCallable|BlueprintEvent]
	void OnRep_CompLimitedTime(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BPC_BuyResurrection.BPC_BuyResurrection_C.Get Wait Time Remaining
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void Get Wait Time Remaining(int32_t& RemainTime); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function BPC_BuyResurrection.BPC_BuyResurrection_C.GetTeammatesArr
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	struct TArray<struct ASCMPlayerState*> GetTeammatesArr(); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function BPC_BuyResurrection.BPC_BuyResurrection_C.On All Teammates Killed
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void On All Teammates Killed(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BPC_BuyResurrection.BPC_BuyResurrection_C.Get Alive Team Player Num
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void Get Alive Team Player Num(struct ASCMPlayerState* OutPlayer, int32_t& Num); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0xc)

	// Object Name: Function BPC_BuyResurrection.BPC_BuyResurrection_C.Get the number of purchases
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void Get the number of purchases(int32_t& PurchasesNum); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function BPC_BuyResurrection.BPC_BuyResurrection_C.OnRep_State
	// Flags: [HasDefaults|BlueprintCallable|BlueprintEvent]
	void OnRep_State(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BPC_BuyResurrection.BPC_BuyResurrection_C.Show Buy Resurrection UI
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void Show Buy Resurrection UI(bool Visible); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function BPC_BuyResurrection.BPC_BuyResurrection_C.ReceiveBeginPlay
	// Flags: [Event|Public|BlueprintEvent]
	void ReceiveBeginPlay(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BPC_BuyResurrection.BPC_BuyResurrection_C.Event_RebirthCharacter
	// Flags: [BlueprintCallable|BlueprintEvent]
	void Event_RebirthCharacter(struct ASolarPlayerState* CostPlayer); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function BPC_BuyResurrection.BPC_BuyResurrection_C.Event_EnterBuyResurrectionProcess
	// Flags: [BlueprintCallable|BlueprintEvent]
	void Event_EnterBuyResurrectionProcess(struct ASolarPlayerState* PlayerState, bool Affordable); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x9)

	// Object Name: Function BPC_BuyResurrection.BPC_BuyResurrection_C.Event_OnSuccessfulPurchase
	// Flags: [BlueprintCallable|BlueprintEvent]
	void Event_OnSuccessfulPurchase(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BPC_BuyResurrection.BPC_BuyResurrection_C.Event_LeaveWhileWaiting
	// Flags: [BlueprintCallable|BlueprintEvent]
	void Event_LeaveWhileWaiting(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BPC_BuyResurrection.BPC_BuyResurrection_C.Event_CheckAllDeath
	// Flags: [BlueprintCallable|BlueprintEvent]
	void Event_CheckAllDeath(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BPC_BuyResurrection.BPC_BuyResurrection_C.Event_RespondReconnection
	// Flags: [BlueprintCallable|BlueprintEvent]
	void Event_RespondReconnection(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BPC_BuyResurrection.BPC_BuyResurrection_C.BuyResurrectionTimeOut
	// Flags: [BlueprintCallable|BlueprintEvent]
	void BuyResurrectionTimeOut(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BPC_BuyResurrection.BPC_BuyResurrection_C.EndJudgment
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EndJudgment(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BPC_BuyResurrection.BPC_BuyResurrection_C.Event_NotificationOverTimeLimit
	// Flags: [Net|NetReliableNetClient|BlueprintCallable|BlueprintEvent]
	void Event_NotificationOverTimeLimit(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BPC_BuyResurrection.BPC_BuyResurrection_C.Event_OnReviveComplete
	// Flags: [BlueprintCallable|BlueprintEvent]
	void Event_OnReviveComplete(struct FString PlayerId); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function BPC_BuyResurrection.BPC_BuyResurrection_C.ClientDoCameraFade
	// Flags: [Net|NetReliableNetClient|BlueprintCallable|BlueprintEvent]
	void ClientDoCameraFade(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BPC_BuyResurrection.BPC_BuyResurrection_C.OnBattleStartEvent
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnBattleStartEvent(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BPC_BuyResurrection.BPC_BuyResurrection_C.BeginTimeoutCountDown
	// Flags: [BlueprintCallable|BlueprintEvent]
	void BeginTimeoutCountDown(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BPC_BuyResurrection.BPC_BuyResurrection_C.DelaySetTimeOut
	// Flags: [BlueprintCallable|BlueprintEvent]
	void DelaySetTimeOut(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BPC_BuyResurrection.BPC_BuyResurrection_C.PauseTimeoutCountDownInternal
	// Flags: [BlueprintCallable|BlueprintEvent]
	void PauseTimeoutCountDownInternal(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BPC_BuyResurrection.BPC_BuyResurrection_C.ContinueTimeoutCountDownInternal
	// Flags: [BlueprintCallable|BlueprintEvent]
	void ContinueTimeoutCountDownInternal(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BPC_BuyResurrection.BPC_BuyResurrection_C.LazyPauseTimeoutCountDownAtLastRemainTime
	// Flags: [BlueprintCallable|BlueprintEvent]
	void LazyPauseTimeoutCountDownAtLastRemainTime(float TimeRemainToPause); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function BPC_BuyResurrection.BPC_BuyResurrection_C.TryContinueTimeoutCountDown
	// Flags: [BlueprintCallable|BlueprintEvent]
	void TryContinueTimeoutCountDown(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BPC_BuyResurrection.BPC_BuyResurrection_C.OnPostRepNotifies
	// Flags: [Event|Protected|BlueprintEvent]
	void OnPostRepNotifies(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BPC_BuyResurrection.BPC_BuyResurrection_C.ExecuteUbergraph_BPC_BuyResurrection
	// Flags: [Final|UbergraphFunction|HasDefaults]
	void ExecuteUbergraph_BPC_BuyResurrection(int32_t EntryPoint); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function BPC_BuyResurrection.BPC_BuyResurrection_C.TimeoutCountDownStateChanged__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void TimeoutCountDownStateChanged__DelegateSignature(bool bPaused); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function BPC_BuyResurrection.BPC_BuyResurrection_C.NewStateChange__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void NewStateChange__DelegateSignature(enum class E_BuyResurrectionsState State); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x1)
};

