#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BPC_CountDown.BPC_CountDown_C
// Size: 0x121 // Inherited bytes: 0xb0
struct UBPC_CountDown_C : UActorComponent {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0xb0 // Size: 0x08
	struct UUI_CountDown_C* CountDownWidget; // Offset: 0xb8 // Size: 0x08
	int32_t Time; // Offset: 0xc0 // Size: 0x04
	char pad_0xC4[0x4]; // Offset: 0xc4 // Size: 0x04
	struct FTimerHandle Timer; // Offset: 0xc8 // Size: 0x08
	int32_t LocalTime; // Offset: 0xd0 // Size: 0x04
	char pad_0xD4[0x4]; // Offset: 0xd4 // Size: 0x04
	struct FTimerHandle LocalTimer; // Offset: 0xd8 // Size: 0x08
	struct FMulticastInlineDelegate OnLocalTimeChange; // Offset: 0xe0 // Size: 0x10
	struct FMulticastInlineDelegate OnCountDownFinished; // Offset: 0xf0 // Size: 0x10
	int32_t MatchingText; // Offset: 0x100 // Size: 0x04
	int32_t MatchingTime; // Offset: 0x104 // Size: 0x04
	struct FMulticastInlineDelegate OnMatchCountDownFinished; // Offset: 0x108 // Size: 0x10
	struct FTimerHandle TimerMatch; // Offset: 0x118 // Size: 0x08
	bool bCountDownFinished; // Offset: 0x120 // Size: 0x01

	// Functions

	// Object Name: Function BPC_CountDown.BPC_CountDown_C.[S]StopMatchCountDown
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void [S]StopMatchCountDown(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BPC_CountDown.BPC_CountDown_C.[S]StartMatchCountDown
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void [S]StartMatchCountDown(int32_t MatchTime, struct FDelegate& Event); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x14)

	// Object Name: Function BPC_CountDown.BPC_CountDown_C.[S]StartCountDown
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void [S]StartCountDown(int32_t Time, struct FDelegate& Event); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x14)

	// Object Name: Function BPC_CountDown.BPC_CountDown_C.[C]StopCountDown
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void [C]StopCountDown(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BPC_CountDown.BPC_CountDown_C.OnRep_Time
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnRep_Time(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BPC_CountDown.BPC_CountDown_C.GetCountDownWidget
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void GetCountDownWidget(struct UUI_CountDown_C*& Output_Get1); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function BPC_CountDown.BPC_CountDown_C.ReceiveBeginPlay
	// Flags: [Event|Public|BlueprintEvent]
	void ReceiveBeginPlay(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BPC_CountDown.BPC_CountDown_C.StartCountDown
	// Flags: [BlueprintCallable|BlueprintEvent]
	void StartCountDown(int32_t Time); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function BPC_CountDown.BPC_CountDown_C.OnCountDownTime
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnCountDownTime(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BPC_CountDown.BPC_CountDown_C.[C]ClientCountDown
	// Flags: [BlueprintCallable|BlueprintEvent]
	void [C]ClientCountDown(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BPC_CountDown.BPC_CountDown_C.CountDownTick
	// Flags: [BlueprintCallable|BlueprintEvent]
	void CountDownTick(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BPC_CountDown.BPC_CountDown_C.MCountDownTick
	// Flags: [Net|NetMulticast|BlueprintCallable|BlueprintEvent]
	void MCountDownTick(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BPC_CountDown.BPC_CountDown_C.CustomEvent_1
	// Flags: [BlueprintCallable|BlueprintEvent]
	void CustomEvent_1(enum class ESCMInGameState NewState); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function BPC_CountDown.BPC_CountDown_C.ExecuteUbergraph_BPC_CountDown
	// Flags: [Final|UbergraphFunction|HasDefaults]
	void ExecuteUbergraph_BPC_CountDown(int32_t EntryPoint); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function BPC_CountDown.BPC_CountDown_C.OnMatchCountDownFinished__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void OnMatchCountDownFinished__DelegateSignature(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BPC_CountDown.BPC_CountDown_C.OnCountDownFinished__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void OnCountDownFinished__DelegateSignature(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BPC_CountDown.BPC_CountDown_C.OnLocalTimeChange__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void OnLocalTimeChange__DelegateSignature(int32_t Time); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x4)
};

