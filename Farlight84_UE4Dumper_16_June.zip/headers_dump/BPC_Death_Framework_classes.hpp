#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BPC_Death_Framework.BPC_Death_Framework_C
// Size: 0x112 // Inherited bytes: 0xd0
struct UBPC_Death_Framework_C : UCGMDeathComponent {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0xd0 // Size: 0x08
	struct FMulticastInlineDelegate OnPlayerDie; // Offset: 0xd8 // Size: 0x10
	struct FMulticastInlineDelegate OnPlayerResurrect; // Offset: 0xe8 // Size: 0x10
	struct FMulticastInlineDelegate OnPlayerKill; // Offset: 0xf8 // Size: 0x10
	struct ABP_DefenderManager_C* DefenderManager; // Offset: 0x108 // Size: 0x08
	struct FS_SkillState SkillStateAfterRevive; // Offset: 0x110 // Size: 0x02

	// Functions

	// Object Name: Function BPC_Death_Framework.BPC_Death_Framework_C.GMRevive
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void GMRevive(struct ASCMPlayerState* InKilled, bool& AutoRevive); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x9)

	// Object Name: Function BPC_Death_Framework.BPC_Death_Framework_C.Try Buy Resurrect
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void Try Buy Resurrect(struct ASCMPlayerState* Player, struct FSolarPointDamageEvent DamageEvent, bool& Succeed); // Offset: 0x102f8211c // Return & Params: Num(3) Size(0x111)

	// Object Name: Function BPC_Death_Framework.BPC_Death_Framework_C.CheckTerminator
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	bool CheckTerminator(struct ASCMPlayerState* InKiller, struct ASCMPlayerState* InKilled); // Offset: 0x102f8211c // Return & Params: Num(3) Size(0x11)

	// Object Name: Function BPC_Death_Framework.BPC_Death_Framework_C.GetDefenderManager
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void GetDefenderManager(struct ABP_DefenderManager_C*& AsBP Defender Manager); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function BPC_Death_Framework.BPC_Death_Framework_C.UpdateDataTrace
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void UpdateDataTrace(enum class E_DeathType Type, struct ASCMPlayerState* Killer, struct ASCMPlayerState* Killed, struct FSolarPointDamageEvent& DamageEvent, struct AActor* DamageCauser, struct TMap<struct FString, struct FString> AdditionalData); // Offset: 0x102f8211c // Return & Params: Num(6) Size(0x178)

	// Object Name: Function BPC_Death_Framework.BPC_Death_Framework_C.ReceivePlayerKill
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	void ReceivePlayerKill(struct ASCMPlayerState* Killer, struct ASCMPlayerState* Killed, struct TArray<struct ASCMPlayerState*>& Assists, struct FSolarPointDamageEvent& InDamageEvent, struct AActor* InDamageCauser); // Offset: 0x102f8211c // Return & Params: Num(5) Size(0x130)

	// Object Name: Function BPC_Death_Framework.BPC_Death_Framework_C.ReceivePlayerDeathVerge
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	void ReceivePlayerDeathVerge(struct ASCMPlayerState* InAttacker, struct ASCMPlayerState* InDeathVergePlayer, struct FSolarPointDamageEvent& InDamageEvent, struct AActor* InDamageCauser); // Offset: 0x102f8211c // Return & Params: Num(4) Size(0x120)

	// Object Name: Function BPC_Death_Framework.BPC_Death_Framework_C.ReceivePlayerResurrect
	// Flags: [Event|Public|BlueprintEvent]
	void ReceivePlayerResurrect(struct ASolarCharacter* ResurrectCharacter, struct ASCMPlayerState* ResurrectPlayer); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function BPC_Death_Framework.BPC_Death_Framework_C.ExecuteUbergraph_BPC_Death_Framework
	// Flags: [Final|UbergraphFunction|HasDefaults]
	void ExecuteUbergraph_BPC_Death_Framework(int32_t EntryPoint); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function BPC_Death_Framework.BPC_Death_Framework_C.OnPlayerKill__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void OnPlayerKill__DelegateSignature(struct ABP_PlayerState_Framework_C* Player); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function BPC_Death_Framework.BPC_Death_Framework_C.OnPlayerResurrect__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void OnPlayerResurrect__DelegateSignature(struct ABP_PlayerState_Framework_C* Player); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function BPC_Death_Framework.BPC_Death_Framework_C.OnPlayerDie__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void OnPlayerDie__DelegateSignature(struct ABP_PlayerState_Framework_C* Player); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x8)
};

