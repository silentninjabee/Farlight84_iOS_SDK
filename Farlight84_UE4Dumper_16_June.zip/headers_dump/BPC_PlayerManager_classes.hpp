#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BPC_PlayerManager.BPC_PlayerManager_C
// Size: 0x140 // Inherited bytes: 0xb0
struct UBPC_PlayerManager_C : UActorComponent {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0xb0 // Size: 0x08
	struct TArray<struct ABP_PlayerState_Framework_C*> AliveRealPlayers; // Offset: 0xb8 // Size: 0x10
	struct TArray<struct ABP_PlayerState_Framework_C*> AliveAiPlayers; // Offset: 0xc8 // Size: 0x10
	struct UBPC_Death_Framework_C* DeathComponent; // Offset: 0xd8 // Size: 0x08
	struct TArray<struct ABP_PlayerState_Framework_C*> RealPlayers; // Offset: 0xe0 // Size: 0x10
	struct TMap<struct FString, int32_t> SideRealPlayerCount; // Offset: 0xf0 // Size: 0x50

	// Functions

	// Object Name: Function BPC_PlayerManager.BPC_PlayerManager_C.GetPlayerList
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	struct TArray<struct ABP_PlayerState_Framework_C*> GetPlayerList(enum class E_PlayerListType Type); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x18)

	// Object Name: Function BPC_PlayerManager.BPC_PlayerManager_C.ReceiveBeginPlay
	// Flags: [Event|Public|BlueprintEvent]
	void ReceiveBeginPlay(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BPC_PlayerManager.BPC_PlayerManager_C.OnPlayerDie
	// Flags: [Net|NetMulticast|BlueprintCallable|BlueprintEvent]
	void OnPlayerDie(struct ABP_PlayerState_Framework_C* Player); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function BPC_PlayerManager.BPC_PlayerManager_C.OnPlayerResurrect
	// Flags: [Net|NetMulticast|BlueprintCallable|BlueprintEvent]
	void OnPlayerResurrect(struct ABP_PlayerState_Framework_C* Player); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function BPC_PlayerManager.BPC_PlayerManager_C.BattleStart
	// Flags: [Net|NetMulticast|BlueprintCallable|BlueprintEvent]
	void BattleStart(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BPC_PlayerManager.BPC_PlayerManager_C.PlayerOut
	// Flags: [BlueprintCallable|BlueprintEvent]
	void PlayerOut(struct ABP_PlayerState_Framework_C* Player); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function BPC_PlayerManager.BPC_PlayerManager_C.OnPlayerJoin
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnPlayerJoin(struct ASCMPlayerState* NewPlayer, bool bIsAi); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x9)

	// Object Name: Function BPC_PlayerManager.BPC_PlayerManager_C.ExecuteUbergraph_BPC_PlayerManager
	// Flags: [Final|UbergraphFunction|HasDefaults]
	void ExecuteUbergraph_BPC_PlayerManager(int32_t EntryPoint); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x4)
};

