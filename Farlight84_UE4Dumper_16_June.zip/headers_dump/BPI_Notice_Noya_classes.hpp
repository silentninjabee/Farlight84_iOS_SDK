#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BPI_Notice_Noya.BPI_Notice_Noya_C
// Size: 0x28 // Inherited bytes: 0x28
struct UBPI_Notice_Noya_C : UInterface {
	// Functions

	// Object Name: Function BPI_Notice_Noya.BPI_Notice_Noya_C.Close
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void Close(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BPI_Notice_Noya.BPI_Notice_Noya_C.Show
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void Show(struct FString ); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x10)
};

