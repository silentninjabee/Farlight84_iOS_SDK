#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_AiCompElement.BP_AiCompElement_C
// Size: 0x394 // Inherited bytes: 0x280
struct ABP_AiCompElement_C : ASCMMapElementBase {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x280 // Size: 0x08
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x288 // Size: 0x08
	struct ABP_PlayerState_Framework_C* TargetPlayer; // Offset: 0x290 // Size: 0x08
	int32_t WaveIndex; // Offset: 0x298 // Size: 0x04
	char pad_0x29C[0x4]; // Offset: 0x29c // Size: 0x04
	struct FTimerHandle TimeOutHandler; // Offset: 0x2a0 // Size: 0x08
	int32_t NextWaveStart; // Offset: 0x2a8 // Size: 0x04
	char pad_0x2AC[0x4]; // Offset: 0x2ac // Size: 0x04
	struct TArray<struct ABP_PlayerState_Framework_C*> TriggeredAi; // Offset: 0x2b0 // Size: 0x10
	struct FS_TriggerItem_AiCompBase TriggerSetting; // Offset: 0x2c0 // Size: 0x98
	int32_t Recheck; // Offset: 0x358 // Size: 0x04
	char pad_0x35C[0x4]; // Offset: 0x35c // Size: 0x04
	struct TArray<struct FString> PopedGroup; // Offset: 0x360 // Size: 0x10
	struct ABP_AiCompManagerBase_C* AiCompManager; // Offset: 0x370 // Size: 0x08
	struct TArray<struct ABP_PlayerState_Framework_C*> TriggeredPlayers; // Offset: 0x378 // Size: 0x10
	struct ABP_AiCompManagerBase_C* AiCompElement; // Offset: 0x388 // Size: 0x08
	int32_t ID; // Offset: 0x390 // Size: 0x04

	// Functions

	// Object Name: Function BP_AiCompElement.BP_AiCompElement_C.GetAiNum
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	struct FString GetAiNum(struct TArray<struct FS_AiGroup_AiCompBase>& AiGroupValue); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function BP_AiCompElement.BP_AiCompElement_C.GetPlayerDataTrace
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	struct TMap<struct FString, struct FString> GetPlayerDataTrace(struct ASolarPlayerState* Player, struct FString FinishAccompany, struct FString Type, struct FString TriggerType); // Offset: 0x102f8211c // Return & Params: Num(5) Size(0x88)

	// Object Name: Function BP_AiCompElement.BP_AiCompElement_C.GetWeaponPartIdList
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void GetWeaponPartIdList(struct TArray<int32_t>& ID); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function BP_AiCompElement.BP_AiCompElement_C.CheckNumberArray
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void CheckNumberArray(struct TArray<int32_t>& Number, struct TMap<enum class E_FilterParameterType_AiCompBase, struct FString> Parameter, bool& Return); // Offset: 0x102f8211c // Return & Params: Num(3) Size(0x61)

	// Object Name: Function BP_AiCompElement.BP_AiCompElement_C.GetWeaponPartId
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void GetWeaponPartId(int32_t PartID, int32_t& ItemID); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x8)

	// Object Name: Function BP_AiCompElement.BP_AiCompElement_C.CheckTargetPlayerEquipment
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void CheckTargetPlayerEquipment(struct TMap<enum class E_FilterParameterType_AiCompBase, struct FString>& Parameter, bool& Return); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x51)

	// Object Name: Function BP_AiCompElement.BP_AiCompElement_C.CheckEnemyNumber
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void CheckEnemyNumber(struct TMap<enum class E_FilterParameterType_AiCompBase, struct FString> Parameter, bool& Return); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x51)

	// Object Name: Function BP_AiCompElement.BP_AiCompElement_C.CheckTeammateNumber
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void CheckTeammateNumber(struct TMap<enum class E_FilterParameterType_AiCompBase, struct FString> Parameter, bool& Return); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x51)

	// Object Name: Function BP_AiCompElement.BP_AiCompElement_C.CheckTargetPlayerItem
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void CheckTargetPlayerItem(struct TMap<enum class E_FilterParameterType_AiCompBase, struct FString> Parameter, bool& Return); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x51)

	// Object Name: Function BP_AiCompElement.BP_AiCompElement_C.CheckTargetPlayerCauseDamage
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void CheckTargetPlayerCauseDamage(struct TMap<enum class E_FilterParameterType_AiCompBase, struct FString> Parameter, bool& Return); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x51)

	// Object Name: Function BP_AiCompElement.BP_AiCompElement_C.CheckTargetPlayerKillNumber
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void CheckTargetPlayerKillNumber(struct TMap<enum class E_FilterParameterType_AiCompBase, struct FString> Parameter, bool& Return); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x51)

	// Object Name: Function BP_AiCompElement.BP_AiCompElement_C.GetItemNumber
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void GetItemNumber(int32_t ItemID, struct ASolarPlayerState* Target, int32_t& Number); // Offset: 0x102f8211c // Return & Params: Num(3) Size(0x14)

	// Object Name: Function BP_AiCompElement.BP_AiCompElement_C.CheckNumber
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void CheckNumber(int32_t Number, struct TMap<enum class E_FilterParameterType_AiCompBase, struct FString> Parameter, bool& Return); // Offset: 0x102f8211c // Return & Params: Num(3) Size(0x59)

	// Object Name: Function BP_AiCompElement.BP_AiCompElement_C.CheckFilterGroup
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void CheckFilterGroup(struct FS_FilterGroup_AiCompBase& Filter, bool& Result); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x11)

	// Object Name: Function BP_AiCompElement.BP_AiCompElement_C.GetPlayerLocation
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void GetPlayerLocation(struct ASolarPlayerState* Player, struct FVector& Location); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x14)

	// Object Name: Function BP_AiCompElement.BP_AiCompElement_C.CheckFilter
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void CheckFilter(struct FS_Filter_AiCompBase& Filter, bool& Result); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x19)

	// Object Name: Function BP_AiCompElement.BP_AiCompElement_C.CheckWaveValid
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void CheckWaveValid(bool& Valid); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function BP_AiCompElement.BP_AiCompElement_C.BreakAiWave
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void BreakAiWave(struct FString WaveSetting, struct TArray<int32_t>& Result); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function BP_AiCompElement.BP_AiCompElement_C.GetAiCompManager
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void GetAiCompManager(struct ABP_AiCompManagerBase_C*& AiCompManager); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function BP_AiCompElement.BP_AiCompElement_C.GetRandomLocation
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void GetRandomLocation(struct FVector Center, int32_t Radius, struct FVector& Location); // Offset: 0x102f8211c // Return & Params: Num(3) Size(0x1c)

	// Object Name: Function BP_AiCompElement.BP_AiCompElement_C.PopAiByGroup
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void PopAiByGroup(struct FS_AiGroupSetting_AiCompBase GroupSettings, struct TArray<struct FString>& Except); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function BP_AiCompElement.BP_AiCompElement_C.ReceiveBeginPlay
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveBeginPlay(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_AiCompElement.BP_AiCompElement_C.AiCompFinish
	// Flags: [BlueprintCallable|BlueprintEvent]
	void AiCompFinish(enum class E_AiCompElementFinishType Success); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function BP_AiCompElement.BP_AiCompElement_C.Init
	// Flags: [BlueprintCallable|BlueprintEvent]
	void Init(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_AiCompElement.BP_AiCompElement_C.PopAi
	// Flags: [BlueprintCallable|BlueprintEvent]
	void PopAi(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_AiCompElement.BP_AiCompElement_C.BasicSystemReady
	// Flags: [BlueprintCallable|BlueprintEvent]
	void BasicSystemReady(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_AiCompElement.BP_AiCompElement_C.OnPlayerDie
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnPlayerDie(struct ABP_PlayerState_Framework_C* Player); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function BP_AiCompElement.BP_AiCompElement_C.Reinit
	// Flags: [BlueprintCallable|BlueprintEvent]
	void Reinit(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_AiCompElement.BP_AiCompElement_C.PopOneAiFailed
	// Flags: [BlueprintCallable|BlueprintEvent]
	void PopOneAiFailed(struct FS_AiSetting_AiCompBase Setting); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x1c0)

	// Object Name: Function BP_AiCompElement.BP_AiCompElement_C.Timeout
	// Flags: [BlueprintCallable|BlueprintEvent]
	void Timeout(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_AiCompElement.BP_AiCompElement_C.ExecuteUbergraph_BP_AiCompElement
	// Flags: [Final|UbergraphFunction|HasDefaults]
	void ExecuteUbergraph_BP_AiCompElement(int32_t EntryPoint); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x4)
};

