#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_AiCompManagerBase.BP_AiCompManagerBase_C
// Size: 0x748 // Inherited bytes: 0x280
struct ABP_AiCompManagerBase_C : ASCMMapElementBase {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x280 // Size: 0x08
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x288 // Size: 0x08
	bool CheckPreserve; // Offset: 0x290 // Size: 0x01
	char pad_0x291[0x3]; // Offset: 0x291 // Size: 0x03
	int32_t SilenceCheckTime; // Offset: 0x294 // Size: 0x04
	int32_t SilenceCheckCycle; // Offset: 0x298 // Size: 0x04
	struct FName WarmGameID; // Offset: 0x29c // Size: 0x08
	int32_t MaxTeamCount; // Offset: 0x2a4 // Size: 0x04
	struct UDataTable* ActionTimelineDT; // Offset: 0x2a8 // Size: 0x08
	struct UDataTable* DownsizingTimelineDT; // Offset: 0x2b0 // Size: 0x08
	struct TMap<int32_t, struct FS_Trigger_AiCompBase> ActionTimeline; // Offset: 0x2b8 // Size: 0x50
	struct TMap<int32_t, struct FIntPoint> DownsizingTimeline; // Offset: 0x308 // Size: 0x50
	int32_t BattleTime; // Offset: 0x358 // Size: 0x04
	float SilenceDistance1; // Offset: 0x35c // Size: 0x04
	float SilenceDistance2; // Offset: 0x360 // Size: 0x04
	struct FVector SilenceLocation; // Offset: 0x364 // Size: 0x0c
	struct TMap<struct FString, enum class E_AiState_AiCompBase> Ai-State; // Offset: 0x370 // Size: 0x50
	struct TMap<struct FString, int32_t> PreservedSide; // Offset: 0x3c0 // Size: 0x50
	struct TArray<struct FS_TriggerItem_AiCompBase> CurrentTrigger; // Offset: 0x410 // Size: 0x10
	int32_t DownsizingTarget; // Offset: 0x420 // Size: 0x04
	int32_t DownsizingEnd; // Offset: 0x424 // Size: 0x04
	struct FTimerHandle DownsizeHandler; // Offset: 0x428 // Size: 0x08
	int32_t DownsizeNumber; // Offset: 0x430 // Size: 0x04
	char pad_0x434[0x4]; // Offset: 0x434 // Size: 0x04
	struct UDataTable* ItemUpdateTimelineDT; // Offset: 0x438 // Size: 0x08
	struct TMap<int32_t, struct FS_AiItemSetting_AiCompBase> ItemUpdateTimeline; // Offset: 0x440 // Size: 0x50
	struct FS_AiItemSetting_AiCompBase CurrentItemSetting; // Offset: 0x490 // Size: 0xf0
	struct UDataTable* DeathBoxTimelineDT; // Offset: 0x580 // Size: 0x08
	struct TMap<int32_t, struct FS_DeathBoxTimelineRow_AiCompBase> DeathBoxTimeline; // Offset: 0x588 // Size: 0x50
	struct FS_AiItemSetting_AiCompBase CurrentDeathBox; // Offset: 0x5d8 // Size: 0xf0
	struct TMap<enum class E_TriggerType_AiCompBase, struct FS_Trigger_AiCompBase> Type-Trigger; // Offset: 0x6c8 // Size: 0x50
	int32_t MinAliveRealPlayer; // Offset: 0x718 // Size: 0x04
	int32_t MaxBattleTime; // Offset: 0x71c // Size: 0x04
	struct USBattleRoyaleGameModeAIComp* AiCompManager; // Offset: 0x720 // Size: 0x08
	float DownsizeDuration; // Offset: 0x728 // Size: 0x04
	char pad_0x72C[0x4]; // Offset: 0x72c // Size: 0x04
	struct UBP_Logic_BattleRoyale_C* MainLogic; // Offset: 0x730 // Size: 0x08
	struct TArray<struct ASCMPlayerState*> RealPlayerList; // Offset: 0x738 // Size: 0x10

	// Functions

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.PopAllAI
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void PopAllAI(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.GetAIController
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	struct ASolarBotAIController* GetAIController(struct ASolarPlayerState* PlayerState); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.InitRealPlayerList
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void InitRealPlayerList(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.KillAI
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void KillAI(struct ASolarPlayerState* Player); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.GetMainLogic
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void GetMainLogic(struct UBP_Logic_BattleRoyale_C*& AsBP Logic Battle Royale); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.Attrition
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void Attrition(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.GetDataTrace
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void GetDataTrace(struct FString PlayerId, struct TMap<struct FString, struct FString>& Return); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x60)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.GetAiCompManager
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void GetAiCompManager(struct USBattleRoyaleGameModeAIComp*& Output_Get); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.SetItem
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SetItem(struct ASolarCharacter* Character, struct FS_AiItemSetting_AiCompBase& Item); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0xf8)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.GetDeathBoxExtraStuff
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void GetDeathBoxExtraStuff(struct ASolarPlayerState* Bot, struct ASolarPlayerState* Player, struct TMap<int32_t, int32_t>& Stuff); // Offset: 0x102f8211c // Return & Params: Num(3) Size(0x60)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.Kill Ai Through Random Damage Event
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void Kill Ai Through Random Damage Event(struct ASCMPlayerState* Killed, struct ASCMPlayerState* Killer); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.GetKiller
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	struct ASolarCharacter* GetKiller(); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.GetTeamWithRealPlayerCount
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	int32_t GetTeamWithRealPlayerCount(); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.SetAiIsPreset
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetAiIsPreset(struct ASolarCharacter* AiCharacter); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.InitDeathBoxTimeline
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void InitDeathBoxTimeline(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.InitItemTimeline
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void InitItemTimeline(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.InitDownsizeTimeline
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void InitDownsizeTimeline(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.InitActionTimeline
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void InitActionTimeline(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.RemoveTriggerWithParam
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	struct TArray<struct FS_TriggerItem_AiCompBase> RemoveTriggerWithParam(struct TArray<struct FS_TriggerItem_AiCompBase>& TriggerList, struct TMap<struct FString, struct FString> Param); // Offset: 0x102f8211c // Return & Params: Num(3) Size(0x70)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.CheckTriggerParam
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	bool CheckTriggerParam(struct TMap<struct FString, struct FString> Param, struct FS_TriggerItem_AiCompBase Trigger); // Offset: 0x102f8211c // Return & Params: Num(3) Size(0xe9)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.Get Alive Player Number
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	int32_t Get Alive Player Number(); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.TriggerAiByEventType
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void TriggerAiByEventType(enum class E_TriggerType_AiCompBase Type, struct ABP_PlayerState_Framework_C* TargetPlayer, struct TMap<struct FString, struct FString> Parameter); // Offset: 0x102f8211c // Return & Params: Num(3) Size(0x60)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.GetAiByType
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void GetAiByType(enum class E_AiState_AiCompBase Type, struct TArray<struct FString>& Return); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x18)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.CheckDeathBoxTimeline
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void CheckDeathBoxTimeline(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.GetWeaponPartItemId
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void GetWeaponPartItemId(int32_t PartID, int32_t& ItemID); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x8)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.GetRandomWeaponParts
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void GetRandomWeaponParts(struct TMap<enum class E_WeaponParts_AiCompBase, struct FS_EquipmentArray_AiCompBase> PartSetting, struct FWeaponPartsData OriginPart, struct FWeaponPartsData& Part); // Offset: 0x102f8211c // Return & Params: Num(3) Size(0xa0)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.CheckItemUpdateTimeline
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void CheckItemUpdateTimeline(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.UpdateSelectionListWithTargetId
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void UpdateSelectionListWithTargetId(struct TArray<int32_t>& TargetId, struct TMap<int32_t, int32_t> DefaultSelectionList, struct TMap<int32_t, int32_t>& UpdateSelectionList); // Offset: 0x102f8211c // Return & Params: Num(3) Size(0xb0)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.TeamHasRealPlayer
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	bool TeamHasRealPlayer(struct FString Side); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x11)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.GetHigherLevelWeaponId
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void GetHigherLevelWeaponId(int32_t WeaponItemID, struct TArray<int32_t>& TargetItemId); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x18)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.UpdateAiWeapon
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void UpdateAiWeapon(struct ASolarCharacter* AiCharacter, enum class EWeaponSlotType WeaponSlot, struct TMap<int32_t, int32_t> weaponid, struct TMap<enum class E_WeaponParts_AiCompBase, struct FS_EquipmentArray_AiCompBase> WeaponPartSetting, enum class EWeaponSlotType& Slot, int32_t& NewWeapon, struct FWeaponPartsData& Part); // Offset: 0x102f8211c // Return & Params: Num(7) Size(0xe0)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.SetAiData
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SetAiData(struct ASolarCharacter* AiCharacter, struct TMap<enum class E_AiDataSettingType_AiCompBase, struct FIntPoint> DataSetting); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x58)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.PopOneId
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void PopOneId(struct TMap<int32_t, int32_t> IdArray, int32_t& ID); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x54)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.SetAiCharacter
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SetAiCharacter(int32_t CharacterId, struct ABP_PlayerState_Framework_C* AI); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.SetAiDifficulty
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SetAiDifficulty(int32_t Diffifulty, struct ASolarCharacter* AiCharacter); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.SetTeleVehicle
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetTeleVehicle(struct ASolarCharacter* AiCharacter, struct FS_VehicleSetting_AiCompBase Vehicle); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x60)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.GetRandomTeleCenter
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void GetRandomTeleCenter(struct AActor* PlayerCharacter, struct FIntPoint Radius, struct FIntPoint Angle, struct FVector& Center); // Offset: 0x102f8211c // Return & Params: Num(4) Size(0x24)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.SetTeleCenter
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SetTeleCenter(struct ASolarCharacter* AiCharacter, struct FS_TeleCenterSetting_AiCompBase TeleCenter, struct ASolarCharacter* Player); // Offset: 0x102f8211c // Return & Params: Num(3) Size(0x28)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.SetPopAi
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetPopAi(struct FS_AiSetting_AiCompBase Setting, struct ABP_PlayerState_Framework_C* AI, struct ABP_PlayerState_Framework_C* TargetPlayer); // Offset: 0x102f8211c // Return & Params: Num(3) Size(0x1d0)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.SetTargetCharacter
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SetTargetCharacter(struct ASolarCharacter* AiCharacter, struct UObject* PlayerCharacter); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.Check Downsizing Timeline
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void Check Downsizing Timeline(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.GetAiNumberByType
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void GetAiNumberByType(struct TArray<enum class E_AiState_AiCompBase>& Type, int32_t& Number); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x14)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.Update Ai State
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void Update Ai State(struct ASolarPlayerState* AI, enum class E_AiState_AiCompBase NewState); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x9)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.StartAiComp
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void StartAiComp(struct ABP_PlayerState_Framework_C* TargetPlayer, struct FS_TriggerItem_AiCompBase Trigger); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0xa0)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.GetPreservedSideByAiNumber
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void GetPreservedSideByAiNumber(int32_t Number, struct TArray<struct FString>& Side); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x18)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.GetRandomLocation
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void GetRandomLocation(struct FVector Center, int32_t Radius, struct FVector& Location); // Offset: 0x102f8211c // Return & Params: Num(3) Size(0x1c)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.GetPopAi
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void GetPopAi(int32_t RequiredNumber, struct TArray<struct FString>& Except, enum class E_AiState_AiCompBase NewState, struct TArray<struct FString>& Return, struct TArray<struct FString>& PopSide); // Offset: 0x102f8211c // Return & Params: Num(5) Size(0x40)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.PopSingleAi
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void PopSingleAi(struct ABP_PlayerState_Framework_C* AI, struct ABP_PlayerState_Framework_C* Player, struct FS_AiSetting_AiCompBase AiSetting, bool& Success); // Offset: 0x102f8211c // Return & Params: Num(4) Size(0x1d1)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.InitAiData
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void InitAiData(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.Insight
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	bool Insight(struct ABP_PlayerState_Framework_C* Player, struct ASolarPlayerState* AI); // Offset: 0x102f8211c // Return & Params: Num(3) Size(0x11)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.GetPlayerLocation
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void GetPlayerLocation(struct ASolarPlayerState* PlayerState, struct FVector& Location); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x14)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.PreserveAi
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void PreserveAi(struct ABP_PlayerState_Framework_C* AI); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.ShouldAiCheckSilence
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void ShouldAiCheckSilence(struct ABP_PlayerState_Framework_C* AI, bool& Result); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x9)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.GetAliveRealPlayers
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void GetAliveRealPlayers(struct TArray<struct ABP_PlayerState_Framework_C*>& AliveRealPlayers); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.GetAliveAiPlayers
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void GetAliveAiPlayers(struct TArray<struct ABP_PlayerState_Framework_C*>& AliveAiPlayers); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.CheckSingleTimelineTrigger
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void CheckSingleTimelineTrigger(struct FS_TriggerItem_AiCompBase TimelineTrigger); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x98)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.CheckActionTimeline
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void CheckActionTimeline(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.InitTimeline
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void InitTimeline(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.CheckSingleAiState
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void CheckSingleAiState(struct ABP_PlayerState_Framework_C* AI, bool& NotHasPlayerAround); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x9)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.Check Preserve
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void Check Preserve(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.OnCompleted_2B14868C46B96136A1D9A18ADBB5AD62
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnCompleted_2B14868C46B96136A1D9A18ADBB5AD62(struct ASolarPlayerWeapon* Weapon); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.Tick
	// Flags: [BlueprintCallable|BlueprintEvent]
	void Tick(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.SetDownsizingTimer
	// Flags: [BlueprintCallable|BlueprintEvent]
	void SetDownsizingTimer(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.KillPreservedAi
	// Flags: [BlueprintCallable|BlueprintEvent]
	void KillPreservedAi(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.OnPreserveAi
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnPreserveAi(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.OnTriggerChange
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnTriggerChange(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.OnUpdateAiItem
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnUpdateAiItem(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.PopOneAi
	// Flags: [BlueprintCallable|BlueprintEvent]
	void PopOneAi(struct ABP_PlayerState_Framework_C* AI, struct ABP_PlayerState_Framework_C* TargetPlayer, struct FS_AiSetting_AiCompBase Setting); // Offset: 0x102f8211c // Return & Params: Num(3) Size(0x1d0)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.PopAll
	// Flags: [BlueprintCallable|BlueprintEvent]
	void PopAll(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.Init
	// Flags: [BlueprintCallable|BlueprintEvent]
	void Init(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.BattleStart
	// Flags: [BlueprintCallable|BlueprintEvent]
	void BattleStart(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.Event_SetAiItem
	// Flags: [HasOutParms|BlueprintCallable|BlueprintEvent]
	void Event_SetAiItem(struct TArray<struct FS_AiItem>& ItemList, struct ASolarCharacter* Character); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x18)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.PlayerDie
	// Flags: [BlueprintCallable|BlueprintEvent]
	void PlayerDie(struct ABP_PlayerState_Framework_C* Player); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function BP_AiCompManagerBase.BP_AiCompManagerBase_C.ExecuteUbergraph_BP_AiCompManagerBase
	// Flags: [Final|UbergraphFunction|HasDefaults]
	void ExecuteUbergraph_BP_AiCompManagerBase(int32_t EntryPoint); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x4)
};

