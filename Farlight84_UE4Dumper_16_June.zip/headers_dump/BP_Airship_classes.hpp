#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_Airship.BP_Airship_C
// Size: 0x490 // Inherited bytes: 0x490
struct ABP_Airship_C : ASolarAirship {
};

