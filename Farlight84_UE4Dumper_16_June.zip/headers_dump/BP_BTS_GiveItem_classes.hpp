#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_BTS_GiveItem.BP_BTS_GiveItem_C
// Size: 0xb8 // Inherited bytes: 0x90
struct UBP_BTS_GiveItem_C : UBTService_BlueprintBase {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x90 // Size: 0x08
	struct ASolarBotAIController* SelfController; // Offset: 0x98 // Size: 0x08
	struct APawn* ControlledPawn; // Offset: 0xa0 // Size: 0x08
	struct TArray<int32_t> NewVar_1; // Offset: 0xa8 // Size: 0x10

	// Functions

	// Object Name: Function BP_BTS_GiveItem.BP_BTS_GiveItem_C.ReceiveTickAI
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds); // Offset: 0x102f8211c // Return & Params: Num(3) Size(0x14)

	// Object Name: Function BP_BTS_GiveItem.BP_BTS_GiveItem_C.ReceiveSearchStartAI
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveSearchStartAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function BP_BTS_GiveItem.BP_BTS_GiveItem_C.ReceiveActivationAI
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveActivationAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function BP_BTS_GiveItem.BP_BTS_GiveItem_C.ExecuteUbergraph_BP_BTS_GiveItem
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_BP_BTS_GiveItem(int32_t EntryPoint); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x4)
};

