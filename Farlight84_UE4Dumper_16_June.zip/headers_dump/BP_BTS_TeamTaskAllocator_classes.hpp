#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_BTS_TeamTaskAllocator.BP_BTS_TeamTaskAllocator_C
// Size: 0x1b0 // Inherited bytes: 0x160
struct UBP_BTS_TeamTaskAllocator_C : USolarBTS_TeamTaskAllocation {
	// Fields
	struct FBlackboardKeySelector DyingTeammate; // Offset: 0x160 // Size: 0x28
	struct FBlackboardKeySelector AccompanyPlayer; // Offset: 0x188 // Size: 0x28

	// Functions

	// Object Name: Function BP_BTS_TeamTaskAllocator.BP_BTS_TeamTaskAllocator_C.DebugEachTaskScoreItem
	// Flags: [Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const]
	void DebugEachTaskScoreItem(struct FSolarScoringItemStruct& TaskScore, enum class ESolarTaskScoringItemType& ItemType, float Score, float Value); // Offset: 0x102f8211c // Return & Params: Num(4) Size(0x20)

	// Object Name: Function BP_BTS_TeamTaskAllocator.BP_BTS_TeamTaskAllocator_C.DebugAllTaskScore
	// Flags: [Event|Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const]
	void DebugAllTaskScore(struct TArray<struct FSolarScoringItemStruct>& TaskScoresList); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function BP_BTS_TeamTaskAllocator.BP_BTS_TeamTaskAllocator_C.CheckIfRescueBot
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	bool CheckIfRescueBot(struct ASolarBotAIController* InController, char InState); // Offset: 0x102f8211c // Return & Params: Num(3) Size(0xa)

	// Object Name: Function BP_BTS_TeamTaskAllocator.BP_BTS_TeamTaskAllocator_C.GetSuitableRescueBot
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|Const]
	struct ASolarBotAIController* GetSuitableRescueBot(struct ASolarCharacter* TeammateInDanger, struct USolarBotAITeamManager* TeamManager); // Offset: 0x102f8211c // Return & Params: Num(3) Size(0x18)

	// Object Name: Function BP_BTS_TeamTaskAllocator.BP_BTS_TeamTaskAllocator_C.SelfUpdateTaskState
	// Flags: [Public|BlueprintCallable|BlueprintEvent|Const]
	void SelfUpdateTaskState(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)
};

