#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_BTT_SetBlackBoardKey.BP_BTT_SetBlackBoardKey_C
// Size: 0xd9 // Inherited bytes: 0xa8
struct UBP_BTT_SetBlackBoardKey_C : UBTTask_BlueprintBase {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0xa8 // Size: 0x08
	struct FBlackboardKeySelector BlackboardKey; // Offset: 0xb0 // Size: 0x28
	bool TrueOrFalse; // Offset: 0xd8 // Size: 0x01

	// Functions

	// Object Name: Function BP_BTT_SetBlackBoardKey.BP_BTT_SetBlackBoardKey_C.ReceiveExecuteAI
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function BP_BTT_SetBlackBoardKey.BP_BTT_SetBlackBoardKey_C.ExecuteUbergraph_BP_BTT_SetBlackBoardKey
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_BP_BTT_SetBlackBoardKey(int32_t EntryPoint); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x4)
};

