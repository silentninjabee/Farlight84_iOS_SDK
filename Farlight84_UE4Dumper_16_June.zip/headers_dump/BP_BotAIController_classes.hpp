#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_BotAIController.BP_BotAIController_C
// Size: 0x658 // Inherited bytes: 0x650
struct ABP_BotAIController_C : ASolarBotAIController {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x650 // Size: 0x08

	// Functions

	// Object Name: Function BP_BotAIController.BP_BotAIController_C.SetWarmGameClock
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetWarmGameClock(bool Enable); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function BP_BotAIController.BP_BotAIController_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	struct FString GetModuleName(); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function BP_BotAIController.BP_BotAIController_C.ReceiveBeginPlay
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveBeginPlay(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_BotAIController.BP_BotAIController_C.ExecuteUbergraph_BP_BotAIController
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_BP_BotAIController(int32_t EntryPoint); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x4)
};

