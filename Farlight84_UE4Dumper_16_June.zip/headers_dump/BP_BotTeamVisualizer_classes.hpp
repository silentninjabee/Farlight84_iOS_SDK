#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_BotTeamVisualizer.BP_BotTeamVisualizer_C
// Size: 0x250 // Inherited bytes: 0x250
struct ABP_BotTeamVisualizer_C : ASolarBotTeamVisualizer {
};

