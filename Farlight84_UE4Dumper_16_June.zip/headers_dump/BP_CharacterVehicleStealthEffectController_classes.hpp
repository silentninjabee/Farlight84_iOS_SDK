#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_CharacterVehicleStealthEffectController.BP_CharacterVehicleStealthEffectController_C
// Size: 0x40 // Inherited bytes: 0x40
struct UBP_CharacterVehicleStealthEffectController_C : USimpleEffectController {
};

