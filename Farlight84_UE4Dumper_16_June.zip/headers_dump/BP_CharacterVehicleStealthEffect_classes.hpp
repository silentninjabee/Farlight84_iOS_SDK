#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_CharacterVehicleStealthEffect.BP_CharacterVehicleStealthEffect_C
// Size: 0xd0 // Inherited bytes: 0xd0
struct UBP_CharacterVehicleStealthEffect_C : UMaterialVariableEffect {
};

