#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_ConfigSave.BP_ConfigSave_C
// Size: 0xa1 // Inherited bytes: 0x28
struct UBP_ConfigSave_C : USaveGame {
	// Fields
	bool bEnableAiTeammate; // Offset: 0x28 // Size: 0x01
	bool bEnableCustomRoom; // Offset: 0x29 // Size: 0x01
	char pad_0x2A[0x6]; // Offset: 0x2a // Size: 0x06
	struct FCustomRoomData CustomRoomConfig; // Offset: 0x30 // Size: 0x70
	bool bIsCustomRoomHost; // Offset: 0xa0 // Size: 0x01
};

