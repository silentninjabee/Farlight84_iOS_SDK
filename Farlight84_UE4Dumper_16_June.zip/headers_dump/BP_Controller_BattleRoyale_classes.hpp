#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_Controller_BattleRoyale.BP_Controller_BattleRoyale_C
// Size: 0xc74 // Inherited bytes: 0xc74
struct ABP_Controller_BattleRoyale_C : ABP_Controller_Framework_C {
};

