#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_DI_DeathBoxA_TreasureBox.BP_DI_DeathBoxA_TreasureBox_C
// Size: 0x73c // Inherited bytes: 0x6e0
struct ABP_DI_DeathBoxA_TreasureBox_C : ADeathTreasureBox {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x6e0 // Size: 0x08
	struct USceneComponent* FX_Position; // Offset: 0x6e8 // Size: 0x08
	struct USceneComponent* Charge_VFX; // Offset: 0x6f0 // Size: 0x08
	struct TArray<struct UParticleSystemComponent*> ChargeEffects; // Offset: 0x6f8 // Size: 0x10
	bool ResurrectionComplete; // Offset: 0x708 // Size: 0x01
	char pad_0x709[0x7]; // Offset: 0x709 // Size: 0x07
	struct TArray<struct FLinearColor> QualityMap; // Offset: 0x710 // Size: 0x10
	struct TArray<struct TSoftObjectPtr<UParticleSystem>> DeadBox_Particle; // Offset: 0x720 // Size: 0x10
	struct UParticleSystemComponent* QualityEffect; // Offset: 0x730 // Size: 0x08
	int32_t NewBoxParticle; // Offset: 0x738 // Size: 0x04

	// Functions

	// Object Name: Function BP_DI_DeathBoxA_TreasureBox.BP_DI_DeathBoxA_TreasureBox_C.CanBuyResurrect
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const]
	bool CanBuyResurrect(struct ASolarCharacter* InReqCharacter); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x9)

	// Object Name: Function BP_DI_DeathBoxA_TreasureBox.BP_DI_DeathBoxA_TreasureBox_C.IsSameTeam
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	bool IsSameTeam(char CharacterTeamID); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x2)

	// Object Name: Function BP_DI_DeathBoxA_TreasureBox.BP_DI_DeathBoxA_TreasureBox_C.RemoveEffect
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void RemoveEffect(struct ASolarCharacter* NewParam); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function BP_DI_DeathBoxA_TreasureBox.BP_DI_DeathBoxA_TreasureBox_C.Add Effect
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void Add Effect(struct ASolarCharacter* NewParam); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function BP_DI_DeathBoxA_TreasureBox.BP_DI_DeathBoxA_TreasureBox_C.UserConstructionScript
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void UserConstructionScript(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_DI_DeathBoxA_TreasureBox.BP_DI_DeathBoxA_TreasureBox_C.ReceiveAddEffect
	// Flags: [Event|Public|BlueprintEvent]
	void ReceiveAddEffect(struct ASolarCharacter* SolarChar); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function BP_DI_DeathBoxA_TreasureBox.BP_DI_DeathBoxA_TreasureBox_C.ReceiveRemoveEffect
	// Flags: [Event|Public|BlueprintEvent]
	void ReceiveRemoveEffect(struct ASolarCharacter* SolarChar); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function BP_DI_DeathBoxA_TreasureBox.BP_DI_DeathBoxA_TreasureBox_C.ReceiveSetUIEnable
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveSetUIEnable(bool IsShow); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function BP_DI_DeathBoxA_TreasureBox.BP_DI_DeathBoxA_TreasureBox_C.ReceiveEndPlay
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveEndPlay(enum class EEndPlayReason EndPlayReason); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function BP_DI_DeathBoxA_TreasureBox.BP_DI_DeathBoxA_TreasureBox_C.ReceiveBeginPlay
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveBeginPlay(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_DI_DeathBoxA_TreasureBox.BP_DI_DeathBoxA_TreasureBox_C.ExecuteUbergraph_BP_DI_DeathBoxA_TreasureBox
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_BP_DI_DeathBoxA_TreasureBox(int32_t EntryPoint); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x4)
};

