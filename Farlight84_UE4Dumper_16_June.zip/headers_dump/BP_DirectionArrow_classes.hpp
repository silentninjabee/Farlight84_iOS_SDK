#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_DirectionArrow.BP_DirectionArrow_C
// Size: 0x248 // Inherited bytes: 0x228
struct ABP_DirectionArrow_C : AActor {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x228 // Size: 0x08
	struct UStaticMeshComponent* FX_G_Mesh_Arrow_Guide_001; // Offset: 0x230 // Size: 0x08
	struct USceneComponent* Scene; // Offset: 0x238 // Size: 0x08
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x240 // Size: 0x08

	// Functions

	// Object Name: Function BP_DirectionArrow.BP_DirectionArrow_C.Init
	// Flags: [BlueprintCallable|BlueprintEvent]
	void Init(struct AActor* AttachTarget, float Scale, struct FVector Position); // Offset: 0x102f8211c // Return & Params: Num(3) Size(0x18)

	// Object Name: Function BP_DirectionArrow.BP_DirectionArrow_C.SetVisiblity
	// Flags: [BlueprintCallable|BlueprintEvent]
	void SetVisiblity(bool NewVisiblity); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function BP_DirectionArrow.BP_DirectionArrow_C.UpdateDirection
	// Flags: [BlueprintCallable|BlueprintEvent]
	void UpdateDirection(struct FRotator Rotation); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0xc)

	// Object Name: Function BP_DirectionArrow.BP_DirectionArrow_C.ExecuteUbergraph_BP_DirectionArrow
	// Flags: [Final|UbergraphFunction|HasDefaults]
	void ExecuteUbergraph_BP_DirectionArrow(int32_t EntryPoint); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x4)
};

