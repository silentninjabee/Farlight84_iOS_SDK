#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: DynamicClass BP_Fog.BP_Fog_C
// Size: 0x3b0 // Inherited bytes: 0x228
struct ABP_Fog_C : AActor {
	// Fields
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x228 // Size: 0x08
	struct FTimerHandle LoopTimer; // Offset: 0x230 // Size: 0x08
	struct AExponentialHeightFog* HeightFog; // Offset: 0x238 // Size: 0x08
	float Fog_MinZ; // Offset: 0x240 // Size: 0x04
	float Fog_MaxZ; // Offset: 0x244 // Size: 0x04
	float Fog_Add_Z; // Offset: 0x248 // Size: 0x04
	bool StopLoop; // Offset: 0x24c // Size: 0x01
	char pad_0x24D[0x3]; // Offset: 0x24d // Size: 0x03
	float Character_MaxZ; // Offset: 0x250 // Size: 0x04
	float Character_MinZ; // Offset: 0x254 // Size: 0x04
	float Not Add Height; // Offset: 0x258 // Size: 0x04
	struct FLinearColor FogColor; // Offset: 0x25c // Size: 0x10
	float GlobalTreeCullDistance; // Offset: 0x26c // Size: 0x04
	struct ASolarWaterActorNew* WaterActor; // Offset: 0x270 // Size: 0x08
	struct FLinearColor FogColorDown; // Offset: 0x278 // Size: 0x10
	struct ASolarCharacter* Solar Character; // Offset: 0x288 // Size: 0x08
	bool Temp_bool_Has_Been_Initd_Variable; // Offset: 0x290 // Size: 0x01
	bool Temp_bool_IsClosed_Variable; // Offset: 0x291 // Size: 0x01
	char pad_0x292[0x2]; // Offset: 0x292 // Size: 0x02
	float CallFunc_BreakVector_X; // Offset: 0x294 // Size: 0x04
	float CallFunc_BreakVector_Y; // Offset: 0x298 // Size: 0x04
	float CallFunc_BreakVector_Z; // Offset: 0x29c // Size: 0x04
	struct TArray<struct AExponentialHeightFog*> CallFunc_GetAllActorsOfClass_OutActors; // Offset: 0x2a0 // Size: 0x10
	struct AExponentialHeightFog* CallFunc_Array_Get_Item; // Offset: 0x2b0 // Size: 0x08
	float CallFunc_BreakVector_X_2; // Offset: 0x2b8 // Size: 0x04
	float CallFunc_BreakVector_Y_2; // Offset: 0x2bc // Size: 0x04
	float CallFunc_BreakVector_Z_2; // Offset: 0x2c0 // Size: 0x04
	bool K2Node_SwitchInteger_CmpSuccess; // Offset: 0x2c4 // Size: 0x01
	char pad_0x2C5[0x3]; // Offset: 0x2c5 // Size: 0x03
	struct FDelegate K2Node_CreateDelegate_OutputDelegate; // Offset: 0x2c8 // Size: 0x10
	enum class E_BattleState_BattleRoyale K2Node_CustomEvent_Now_State; // Offset: 0x2d8 // Size: 0x01
	char pad_0x2D9[0x7]; // Offset: 0x2d9 // Size: 0x07
	struct ASolarCharacter* K2Node_CustomEvent_Solar_Character_2; // Offset: 0x2e0 // Size: 0x08
	struct ASolarCharacter* K2Node_CustomEvent_Solar_Character; // Offset: 0x2e8 // Size: 0x08
	float CallFunc_BreakVector_X_3; // Offset: 0x2f0 // Size: 0x04
	float CallFunc_BreakVector_Y_3; // Offset: 0x2f4 // Size: 0x04
	float CallFunc_BreakVector_Z_3; // Offset: 0x2f8 // Size: 0x04
	float CallFunc_BreakVector_X_4; // Offset: 0x2fc // Size: 0x04
	float CallFunc_BreakVector_Y_4; // Offset: 0x300 // Size: 0x04
	float CallFunc_BreakVector_Z_4; // Offset: 0x304 // Size: 0x04
	struct FHitResult CallFunc_K2_SetActorLocation_SweepHitResult; // Offset: 0x308 // Size: 0x88
	struct ASolarPlayerController* K2Node_DynamicCast_AsSolar_Player_Controller; // Offset: 0x390 // Size: 0x08
	bool K2Node_DynamicCast_bSuccess; // Offset: 0x398 // Size: 0x01
	char pad_0x399[0x7]; // Offset: 0x399 // Size: 0x07
	struct ASolarPlayerController* K2Node_DynamicCast_AsSolar_Player_Controller_2; // Offset: 0x3a0 // Size: 0x08
	bool K2Node_DynamicCast_bSuccess_2; // Offset: 0x3a8 // Size: 0x01
	char pad_0x3A9[0x7]; // Offset: 0x3a9 // Size: 0x07

	// Functions

	// Object Name: Function BP_Fog.BP_Fog_C.UserConstructionScript
	// Flags: [Native|Event|Public|BlueprintCallable]
	void UserConstructionScript(); // Offset: 0x101966850 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_Fog.BP_Fog_C.SetFogLocationZ
	// Flags: [Native|Public|BlueprintCallable]
	void SetFogLocationZ(); // Offset: 0x10196686c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_Fog.BP_Fog_C.RequestFogToSettle
	// Flags: [Native|Public|BlueprintCallable]
	void RequestFogToSettle(struct ASolarCharacter* bpp__SolarxCharacter__pfT); // Offset: 0x101966990 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function BP_Fog.BP_Fog_C.OnBattleStart
	// Flags: [Native|Public|BlueprintCallable]
	void OnBattleStart(enum class E_BattleState_BattleRoyale bpp__NowxState__pfT); // Offset: 0x101966888 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function BP_Fog.BP_Fog_C.Fog_Change
	// Flags: [Native|Public|BlueprintCallable]
	void Fog_Change(struct ASolarCharacter* bpp__SolarxCharacter__pfT); // Offset: 0x10196690c // Return & Params: Num(1) Size(0x8)
};

