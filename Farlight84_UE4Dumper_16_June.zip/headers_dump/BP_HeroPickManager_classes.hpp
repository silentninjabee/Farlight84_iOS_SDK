#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_HeroPickManager.BP_HeroPickManager_C
// Size: 0x280 // Inherited bytes: 0x258
struct ABP_HeroPickManager_C : AHeroPickManager {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x258 // Size: 0x08
	struct FMulticastInlineDelegate OnAllHeroPickEnd; // Offset: 0x260 // Size: 0x10
	struct FMulticastInlineDelegate OnSideHeroPickEnd; // Offset: 0x270 // Size: 0x10

	// Functions

	// Object Name: Function BP_HeroPickManager.BP_HeroPickManager_C.ReceiveAllHeroPickEnd
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveAllHeroPickEnd(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_HeroPickManager.BP_HeroPickManager_C.ReceiveSidePickHeroEnd
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveSidePickHeroEnd(struct FString SideName); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function BP_HeroPickManager.BP_HeroPickManager_C.ExecuteUbergraph_BP_HeroPickManager
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_BP_HeroPickManager(int32_t EntryPoint); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function BP_HeroPickManager.BP_HeroPickManager_C.OnSideHeroPickEnd__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void OnSideHeroPickEnd__DelegateSignature(struct FString Side); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function BP_HeroPickManager.BP_HeroPickManager_C.OnAllHeroPickEnd__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void OnAllHeroPickEnd__DelegateSignature(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)
};

