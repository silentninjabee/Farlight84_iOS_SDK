#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C
// Size: 0x3c8 // Inherited bytes: 0x19a
struct UBP_Logic_BattleRoyale_C : UBP_Logic_Framework_C {
	// Fields
	char pad_0x19A[0x6]; // Offset: 0x19a // Size: 0x06
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x1a0 // Size: 0x08
	int32_t WaitTime; // Offset: 0x1a8 // Size: 0x04
	char pad_0x1AC[0x4]; // Offset: 0x1ac // Size: 0x04
	struct TArray<struct APlayerStart*> WaitinglandStart; // Offset: 0x1b0 // Size: 0x10
	struct ABP_GameState_BattleRoyale_C* GameState; // Offset: 0x1c0 // Size: 0x08
	struct FMulticastInlineDelegate OnGoInToBattleState; // Offset: 0x1c8 // Size: 0x10
	bool bWarmGame; // Offset: 0x1d8 // Size: 0x01
	char pad_0x1D9[0x7]; // Offset: 0x1d9 // Size: 0x07
	struct FSolarTablesData_WarmGameMode WarmGameInfo; // Offset: 0x1e0 // Size: 0x50
	struct UDataTable* BattleTimeline; // Offset: 0x230 // Size: 0x08
	struct TMap<int32_t, struct FS_EventList_BattleRoyal> EventList; // Offset: 0x238 // Size: 0x50
	struct UBP_MapInfoComponent_C* MapInfo; // Offset: 0x288 // Size: 0x08
	int32_t ShrinkIndex; // Offset: 0x290 // Size: 0x04
	char pad_0x294[0x4]; // Offset: 0x294 // Size: 0x04
	struct ABP_BattleRoylePoisonCircle_C* PoisonCircle; // Offset: 0x298 // Size: 0x08
	struct ABP_SolarBombingManager_C* BoomingManager; // Offset: 0x2a0 // Size: 0x08
	enum class E_BattleState_BattleRoyale ModeBattleState; // Offset: 0x2a8 // Size: 0x01
	char pad_0x2A9[0x7]; // Offset: 0x2a9 // Size: 0x07
	struct TArray<struct FVector> AirDropPosHistoryRecord; // Offset: 0x2b0 // Size: 0x10
	int32_t AILevel; // Offset: 0x2c0 // Size: 0x04
	int32_t DSTime; // Offset: 0x2c4 // Size: 0x04
	struct TMap<enum class E_BattleEvent_BattleRoyale, bool> ModeEventValid; // Offset: 0x2c8 // Size: 0x50
	int32_t TotalPlayer; // Offset: 0x318 // Size: 0x04
	char pad_0x31C[0x4]; // Offset: 0x31c // Size: 0x04
	struct TArray<struct FString> AliveSides; // Offset: 0x320 // Size: 0x10
	struct TArray<struct ASCMPlayerState*> AlivePlayers; // Offset: 0x330 // Size: 0x10
	struct ABP_ReviveItemManger_BattleRoyale_C* ReviveManager; // Offset: 0x340 // Size: 0x08
	struct ABP_Formula_BattleRoyale_C* BR Formula Manager; // Offset: 0x348 // Size: 0x08
	int32_t TeamMemberCount; // Offset: 0x350 // Size: 0x04
	char pad_0x354[0x4]; // Offset: 0x354 // Size: 0x04
	struct UBehaviorTree* BotBehaviorTree; // Offset: 0x358 // Size: 0x08
	struct TArray<struct ASCMPlayerState*> PlayersQuitOnWaitingLand; // Offset: 0x360 // Size: 0x10
	int32_t PlayerCountMax; // Offset: 0x370 // Size: 0x04
	bool bCanSpawnAI; // Offset: 0x374 // Size: 0x01
	char pad_0x375[0x3]; // Offset: 0x375 // Size: 0x03
	struct ABP_BattleRoylePoisonCircle_C* PoisonCircleClass; // Offset: 0x378 // Size: 0x08
	struct ASolarBotAIController* AIController; // Offset: 0x380 // Size: 0x08
	struct ABP_DefenderManager_C* DefenderManager; // Offset: 0x388 // Size: 0x08
	struct TArray<float> RadiusArr; // Offset: 0x390 // Size: 0x10
	int32_t AILevelMax; // Offset: 0x3a0 // Size: 0x04
	char pad_0x3A4[0x4]; // Offset: 0x3a4 // Size: 0x04
	struct FMulticastInlineDelegate BattleStateChanged; // Offset: 0x3a8 // Size: 0x10
	int32_t PlayerCountBattleStart; // Offset: 0x3b8 // Size: 0x04
	int32_t ChestSpawnerID; // Offset: 0x3bc // Size: 0x04
	struct UBPC_AiManagerBattleRoyale_C* AiManager; // Offset: 0x3c0 // Size: 0x08

	// Functions

	// Object Name: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.PresettleAll
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void PresettleAll(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.DealTeammateAISettle
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void DealTeammateAISettle(struct ASolarPlayerState* Player); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.Custom Room Start
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void Custom Room Start(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.SendItemToPlayer
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SendItemToPlayer(struct ASolarPlayerState* Player, struct TMap<int32_t, int32_t>& ItemMap); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x58)

	// Object Name: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.GetVehicleDataTrace
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void GetVehicleDataTrace(struct TMap<struct FString, struct FString>& Map); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x50)

	// Object Name: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.Init Poison Circle
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void Init Poison Circle(struct UBP_MapInfoComponent_C*& MapInfo); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.GetAiManager
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void GetAiManager(struct UBPC_AiManagerBattleRoyale_C*& Output_Get); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.SetSkillStateByBattleState
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetSkillStateByBattleState(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.Get Shrink Index
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	int32_t Get Shrink Index(); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.TryPushBattleState
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void TryPushBattleState(enum class E_BattleState_BattleRoyale TargetState, bool ForcePush); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x2)

	// Object Name: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.GetWeaponID
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void GetWeaponID(int32_t ItemID, int32_t& weaponid); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x8)

	// Object Name: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.VehicleDataTrace
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void VehicleDataTrace(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.GetPlayerDataTrace
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void GetPlayerDataTrace(struct ABP_PlayerState_BattleRoyale_C* Player, struct TMap<struct FString, struct FString>& Map); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x58)

	// Object Name: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.KickOutExcessAI
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void KickOutExcessAI(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.ReceivePlayerReJoinRequest
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	bool ReceivePlayerReJoinRequest(struct FString PlayerId, struct FString& ErrorMsg); // Offset: 0x102f8211c // Return & Params: Num(3) Size(0x21)

	// Object Name: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.GetAiLevel
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void GetAiLevel(struct ASolarPlayerState* Target, int32_t& DefaultDifficultyLevel); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0xc)

	// Object Name: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.Get Config
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void Get Config(struct UCFG_BattleRoyale_C*& CFG); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.DataTrace
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void DataTrace(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.UpdatePlayerData
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void UpdatePlayerData(struct ASolarPlayerState* Target); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.PreSettleDeal
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void PreSettleDeal(struct ASCMPlayerState* Player, enum class ESCMPlayerOutType OutType); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x9)

	// Object Name: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.Will Master Leaving Disband Room
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void Will Master Leaving Disband Room(bool& Result); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.Is Master Disbanding Legal
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void Is Master Disbanding Legal(bool& Result); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.Is Kick Out Legal
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void Is Kick Out Legal(bool& Result); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.Is Side Switch Legal
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void Is Side Switch Legal(bool& Result); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.BuyResurrectionDeal
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void BuyResurrectionDeal(struct APlayerState* Player); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.UpdateWinnerData
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void UpdateWinnerData(struct FString Side); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.IsLamster
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	bool IsLamster(struct ASCMPlayerState* Player, enum class ESCMPlayerOutType Index); // Offset: 0x102f8211c // Return & Params: Num(3) Size(0xa)

	// Object Name: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.CanPlayerBattle
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	bool CanPlayerBattle(struct ASCMPlayerState* Player); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x9)

	// Object Name: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.UpdateTeamData
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void UpdateTeamData(struct FString Side, bool& bAced); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x11)

	// Object Name: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.IsSideAced
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void IsSideAced(struct FString Side, bool& Aced); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x11)

	// Object Name: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.GetConiReviveManager
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void GetConiReviveManager(struct ABP_ReviveItemManger_BattleRoyale_C*& Output_Get); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.IsAllowReconnectGame
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	bool IsAllowReconnectGame(struct ASCMPlayerState* InPC); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x9)

	// Object Name: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.QuitImmediately
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void QuitImmediately(enum class ESCMPlayerOutType Index, struct ASCMPlayerState* InputPin, bool& SendToSettle); // Offset: 0x102f8211c // Return & Params: Num(3) Size(0x11)

	// Object Name: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.TempSpawnAIGroup
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void TempSpawnAIGroup(struct FString Side, int32_t count, int32_t AILevel); // Offset: 0x102f8211c // Return & Params: Num(3) Size(0x18)

	// Object Name: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.Update Player Data Trace
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void Update Player Data Trace(struct ASCMPlayerState* PlayerState); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.Create Airdrop
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void Create Airdrop(int32_t ChestID); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.StartCruising
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void StartCruising(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.InitElements
	// Flags: [Private|HasDefaults|BlueprintCallable|BlueprintEvent]
	void InitElements(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.Get Map Info
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void Get Map Info(struct UBP_MapInfoComponent_C*& MapInfo); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.Init Timeline Event
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void Init Timeline Event(struct UDataTable*& BattleTimeline); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.ExecuteBattleEvent
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void ExecuteBattleEvent(struct FS_Event_BattleRoyale& S_Event_BattleRoyale); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x58)

	// Object Name: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.UpdateAliveSideAndPlayer
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void UpdateAliveSideAndPlayer(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.UpdateBattleState
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void UpdateBattleState(enum class E_BattleState_BattleRoyale NewState); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.GetGameState
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void GetGameState(struct ABP_GameState_BattleRoyale_C*& Output_Get); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.GetPlayerStartOnWaitingland
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void GetPlayerStartOnWaitingland(struct TArray<struct APlayerStart*>& PlayerStarts); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.GetBattleRoyaleMode
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void GetBattleRoyaleMode(struct ABP_Mode_BattleRoyale_C*& AsBP SCM Battle Royale); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.InitModeSetting
	// Flags: [Protected|HasDefaults|BlueprintCallable|BlueprintEvent]
	void InitModeSetting(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.GMSpawnAI
	// Flags: [BlueprintCallable|BlueprintEvent]
	void GMSpawnAI(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.OnMatchEnd
	// Flags: [Event|Public|BlueprintEvent]
	void OnMatchEnd(int32_t RPCID); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.OnBattleStateChanged
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnBattleStateChanged(enum class E_BattleState_BattleRoyale OldState, enum class E_BattleState_BattleRoyale NewState); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x2)

	// Object Name: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.ReceiveBattleTick
	// Flags: [Event|Public|BlueprintEvent]
	void ReceiveBattleTick(float BattleTime, float DeltaTime); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x8)

	// Object Name: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.PreSettle
	// Flags: [BlueprintCallable|BlueprintEvent]
	void PreSettle(struct ASCMPlayerState* Player, enum class ESCMPlayerOutType OutType); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x9)

	// Object Name: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.PlayerBuyResurrected
	// Flags: [BlueprintCallable|BlueprintEvent]
	void PlayerBuyResurrected(struct ABP_PlayerState_BattleRoyale_C* Player); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.BattleInitFinished
	// Flags: [BlueprintCallable|BlueprintEvent]
	void BattleInitFinished(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.OnDSClose
	// Flags: [Event|Public|BlueprintEvent]
	void OnDSClose(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.ReceivePlayerJoinBattle
	// Flags: [Event|Public|BlueprintEvent]
	void ReceivePlayerJoinBattle(struct ASCMPlayerState* NewPlayer, bool IsAI); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x9)

	// Object Name: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.ReceivePlayerBattleEnd
	// Flags: [Event|Public|BlueprintEvent]
	void ReceivePlayerBattleEnd(struct ASCMPlayerState* Player, enum class ESCMPlayerOutType OutType); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x9)

	// Object Name: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.MatchEnd
	// Flags: [BlueprintCallable|BlueprintEvent]
	void MatchEnd(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.VehicleSnapshot
	// Flags: [BlueprintCallable|BlueprintEvent]
	void VehicleSnapshot(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.Snapshot
	// Flags: [BlueprintCallable|BlueprintEvent]
	void Snapshot(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.CustomEvent_1
	// Flags: [BlueprintCallable|BlueprintEvent]
	void CustomEvent_1(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.OnCountDownFinished
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnCountDownFinished(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.ExecuteUbergraph_BP_Logic_BattleRoyale
	// Flags: [Final|UbergraphFunction|HasDefaults]
	void ExecuteUbergraph_BP_Logic_BattleRoyale(int32_t EntryPoint); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.BattleStateChanged__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void BattleStateChanged__DelegateSignature(enum class E_BattleState_BattleRoyale NewState); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function BP_Logic_BattleRoyale.BP_Logic_BattleRoyale_C.OnGoInToBattleState__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void OnGoInToBattleState__DelegateSignature(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)
};

