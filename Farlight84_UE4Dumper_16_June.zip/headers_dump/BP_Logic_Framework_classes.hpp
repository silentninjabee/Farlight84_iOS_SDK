#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_Logic_Framework.BP_Logic_Framework_C
// Size: 0x19a // Inherited bytes: 0x130
struct UBP_Logic_Framework_C : UCGMLogicComponent {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x130 // Size: 0x08
	struct FMulticastInlineDelegate OnBattleStart; // Offset: 0x138 // Size: 0x10
	struct FMulticastInlineDelegate OnPlayerOut; // Offset: 0x148 // Size: 0x10
	bool bBattleStarted; // Offset: 0x158 // Size: 0x01
	bool bZeroMatchFinished; // Offset: 0x159 // Size: 0x01
	char pad_0x15A[0x6]; // Offset: 0x15a // Size: 0x06
	struct FMulticastInlineDelegate OnPlayerJoin; // Offset: 0x160 // Size: 0x10
	struct FMulticastInlineDelegate OnZeroMatchFinished; // Offset: 0x170 // Size: 0x10
	bool bConfigInitiated; // Offset: 0x180 // Size: 0x01
	char pad_0x181[0x7]; // Offset: 0x181 // Size: 0x07
	struct FMulticastInlineDelegate OnConfigInitiated; // Offset: 0x188 // Size: 0x10
	bool bUseNewAiComp; // Offset: 0x198 // Size: 0x01
	bool bDSClosing; // Offset: 0x199 // Size: 0x01

	// Functions

	// Object Name: Function BP_Logic_Framework.BP_Logic_Framework_C.Custom Room Start
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void Custom Room Start(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_Logic_Framework.BP_Logic_Framework_C.OnPlayerQuit
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void OnPlayerQuit(struct ASCMPlayerState* Player); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function BP_Logic_Framework.BP_Logic_Framework_C.PresettleAll
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void PresettleAll(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_Logic_Framework.BP_Logic_Framework_C.UpdateSidePlayerInfo
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void UpdateSidePlayerInfo(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_Logic_Framework.BP_Logic_Framework_C.FinishConfigInitiate
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void FinishConfigInitiate(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_Logic_Framework.BP_Logic_Framework_C.Update
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void Update(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_Logic_Framework.BP_Logic_Framework_C.Get Current Player Count
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void Get Current Player Count(int32_t& Result); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function BP_Logic_Framework.BP_Logic_Framework_C.ReceiveBeginPlay
	// Flags: [Event|Public|BlueprintEvent]
	void ReceiveBeginPlay(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_Logic_Framework.BP_Logic_Framework_C.OnPlayerOfflineTimeOut
	// Flags: [Event|Public|BlueprintEvent]
	void OnPlayerOfflineTimeOut(struct ASCMPlayerState* OfflineTimeoutPlayer); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function BP_Logic_Framework.BP_Logic_Framework_C.OnPlayerGiveUp
	// Flags: [Event|Public|BlueprintEvent]
	void OnPlayerGiveUp(struct ASCMPlayerState* OfflineTimeoutPlayer); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function BP_Logic_Framework.BP_Logic_Framework_C.PreSettle
	// Flags: [BlueprintCallable|BlueprintEvent]
	void PreSettle(struct ASCMPlayerState* Player, enum class ESCMPlayerOutType OutType); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x9)

	// Object Name: Function BP_Logic_Framework.BP_Logic_Framework_C.ReceivePlayerBattleEnd
	// Flags: [Event|Public|BlueprintEvent]
	void ReceivePlayerBattleEnd(struct ASCMPlayerState* Player, enum class ESCMPlayerOutType OutType); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x9)

	// Object Name: Function BP_Logic_Framework.BP_Logic_Framework_C.BattleInitFinished
	// Flags: [BlueprintCallable|BlueprintEvent]
	void BattleInitFinished(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_Logic_Framework.BP_Logic_Framework_C.ReceiveServerLevelLoaded
	// Flags: [Event|Public|BlueprintEvent]
	void ReceiveServerLevelLoaded(struct FString LevelName); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function BP_Logic_Framework.BP_Logic_Framework_C.ReceiveBattleBegin
	// Flags: [Event|Public|BlueprintEvent]
	void ReceiveBattleBegin(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_Logic_Framework.BP_Logic_Framework_C.OnPlayerDisconnect
	// Flags: [Event|Public|BlueprintEvent]
	void OnPlayerDisconnect(struct ASCMPlayerState* OfflinePlayer); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function BP_Logic_Framework.BP_Logic_Framework_C.OnMatchEnd
	// Flags: [Event|Public|BlueprintEvent]
	void OnMatchEnd(int32_t RPCID); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function BP_Logic_Framework.BP_Logic_Framework_C.ReceivePlayerJoinBattle
	// Flags: [Event|Public|BlueprintEvent]
	void ReceivePlayerJoinBattle(struct ASCMPlayerState* NewPlayer, bool IsAI); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x9)

	// Object Name: Function BP_Logic_Framework.BP_Logic_Framework_C.OnDSClose
	// Flags: [Event|Public|BlueprintEvent]
	void OnDSClose(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_Logic_Framework.BP_Logic_Framework_C.OnPlayerCheat
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnPlayerCheat(struct ASCMPlayerState* CheatPlayer); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function BP_Logic_Framework.BP_Logic_Framework_C.ExecuteUbergraph_BP_Logic_Framework
	// Flags: [Final|UbergraphFunction|HasDefaults]
	void ExecuteUbergraph_BP_Logic_Framework(int32_t EntryPoint); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function BP_Logic_Framework.BP_Logic_Framework_C.OnConfigInitiated__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void OnConfigInitiated__DelegateSignature(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_Logic_Framework.BP_Logic_Framework_C.OnZeroMatchFinished__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void OnZeroMatchFinished__DelegateSignature(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_Logic_Framework.BP_Logic_Framework_C.OnPlayerJoin__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void OnPlayerJoin__DelegateSignature(struct ASCMPlayerState* NewPlayer, bool bIsAi); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x9)

	// Object Name: Function BP_Logic_Framework.BP_Logic_Framework_C.OnPlayerOut__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void OnPlayerOut__DelegateSignature(struct ABP_PlayerState_Framework_C* Player); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function BP_Logic_Framework.BP_Logic_Framework_C.OnBattleStart__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void OnBattleStart__DelegateSignature(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)
};

