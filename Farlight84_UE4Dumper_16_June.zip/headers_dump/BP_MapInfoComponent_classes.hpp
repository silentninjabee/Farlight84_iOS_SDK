#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_MapInfoComponent.BP_MapInfoComponent_C
// Size: 0x2a4 // Inherited bytes: 0x180
struct UBP_MapInfoComponent_C : UCGMMapInfo {
	// Fields
	struct FAirlineData Airline; // Offset: 0x180 // Size: 0x28
	struct TArray<struct FVector> SafeAreaCenters; // Offset: 0x1a8 // Size: 0x10
	bool StaticAirline; // Offset: 0x1b8 // Size: 0x01
	bool StaticSafeArea; // Offset: 0x1b9 // Size: 0x01
	char pad_0x1BA[0x6]; // Offset: 0x1ba // Size: 0x06
	struct UDataTable* DT_EventTimeline_BattleRoyale; // Offset: 0x1c0 // Size: 0x08
	bool UsePoisonCircleMarker; // Offset: 0x1c8 // Size: 0x01
	char pad_0x1C9[0x3]; // Offset: 0x1c9 // Size: 0x03
	struct FVector2D TempDir; // Offset: 0x1cc // Size: 0x08
	bool UseFakePoint; // Offset: 0x1d4 // Size: 0x01
	char pad_0x1D5[0x3]; // Offset: 0x1d5 // Size: 0x03
	struct TMap<int32_t, struct FVector2D> FakePointRangeArr; // Offset: 0x1d8 // Size: 0x50
	bool UseFakeBombPoint; // Offset: 0x228 // Size: 0x01
	char pad_0x229[0x7]; // Offset: 0x229 // Size: 0x07
	struct TMap<int32_t, struct FVector2D> FakeBombPointRangeArr; // Offset: 0x230 // Size: 0x50
	struct FVector PreCirclePoint; // Offset: 0x280 // Size: 0x0c
	char pad_0x28C[0x4]; // Offset: 0x28c // Size: 0x04
	struct TArray<float> CircleRadiusArr; // Offset: 0x290 // Size: 0x10
	int32_t StaticAirlineID; // Offset: 0x2a0 // Size: 0x04

	// Functions

	// Object Name: Function BP_MapInfoComponent.BP_MapInfoComponent_C.Calculate Required Parameters
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void Calculate Required Parameters(struct TArray<float>& RadiusArr, int32_t Index, float& Radius, float& MaxOffset, float& GoToTheCentreRadius); // Offset: 0x102f8211c // Return & Params: Num(5) Size(0x20)

	// Object Name: Function BP_MapInfoComponent.BP_MapInfoComponent_C.Random Get Fake Bomb Point
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void Random Get Fake Bomb Point(int32_t& Key, struct FVector& Pos, bool& Success); // Offset: 0x102f8211c // Return & Params: Num(3) Size(0x11)

	// Object Name: Function BP_MapInfoComponent.BP_MapInfoComponent_C.SetFakeBombPointRangeArrr
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetFakeBombPointRangeArrr(struct TMap<int32_t, struct FVector2D> FakeBombPointRangeArr); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x50)

	// Object Name: Function BP_MapInfoComponent.BP_MapInfoComponent_C.SetFakePointRnageArr
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetFakePointRnageArr(struct TMap<int32_t, struct FVector2D> FakePointRnageArr); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x50)

	// Object Name: Function BP_MapInfoComponent.BP_MapInfoComponent_C.Get Safe Area Centers Len
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void Get Safe Area Centers Len(int32_t& Len); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function BP_MapInfoComponent.BP_MapInfoComponent_C.CalculateFakePoint
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void CalculateFakePoint(struct FVector Centre, float SmallRadiu, float LargeRadiu, int32_t Index, struct FVector& Pos); // Offset: 0x102f8211c // Return & Params: Num(5) Size(0x24)

	// Object Name: Function BP_MapInfoComponent.BP_MapInfoComponent_C.Join Next
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void Join Next(float Radius, float MaxOffset, int32_t LastIndex, struct TArray<struct FVector>& TargetArray, float GoToTheCentreRadius); // Offset: 0x102f8211c // Return & Params: Num(5) Size(0x24)

	// Object Name: Function BP_MapInfoComponent.BP_MapInfoComponent_C.Random Selection
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void Random Selection(float TargetDisMax, float Radius, struct TArray<struct FVector>& TargetArray, bool NeedCheckBoundary, bool& Add); // Offset: 0x102f8211c // Return & Params: Num(5) Size(0x1a)

	// Object Name: Function BP_MapInfoComponent.BP_MapInfoComponent_C.JudgeBoundary
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void JudgeBoundary(struct FVector Pos, float Radius, bool& DontInBoundary); // Offset: 0x102f8211c // Return & Params: Num(3) Size(0x11)

	// Object Name: Function BP_MapInfoComponent.BP_MapInfoComponent_C.Calculate Poison Circle Point Array
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void Calculate Poison Circle Point Array(struct TArray<float>& RadiusArr); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function BP_MapInfoComponent.BP_MapInfoComponent_C.Get Safe Area Center
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void Get Safe Area Center(int32_t Index, struct FVector& Pos); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function BP_MapInfoComponent.BP_MapInfoComponent_C.GetAirline
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	int32_t GetAirline(struct FAirlineData& Airline); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x2c)

	// Object Name: Function BP_MapInfoComponent.BP_MapInfoComponent_C.SetStaticSafeArea
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void SetStaticSafeArea(struct TArray<struct FVector>& SafeAreaCenters); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function BP_MapInfoComponent.BP_MapInfoComponent_C.SetStaticAirline
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetStaticAirline(struct FAirlineData Airline, int32_t StaticAirlineID); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x2c)
};

