#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_Mode_Framework.BP_Mode_Framework_C
// Size: 0x5d8 // Inherited bytes: 0x5c8
struct ABP_Mode_Framework_C : ASCustomGameMode {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x5c8 // Size: 0x08
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x5d0 // Size: 0x08

	// Functions

	// Object Name: Function BP_Mode_Framework.BP_Mode_Framework_C.K2_PostLogin
	// Flags: [Event|Public|BlueprintEvent]
	void K2_PostLogin(struct APlayerController* NewPlayer); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function BP_Mode_Framework.BP_Mode_Framework_C.K2_OnLogout
	// Flags: [Event|Public|BlueprintEvent]
	void K2_OnLogout(struct AController* ExitingController); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function BP_Mode_Framework.BP_Mode_Framework_C.ExecuteUbergraph_BP_Mode_Framework
	// Flags: [Final|UbergraphFunction|HasDefaults]
	void ExecuteUbergraph_BP_Mode_Framework(int32_t EntryPoint); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x4)
};

