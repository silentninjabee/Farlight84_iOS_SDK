#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_QuickSummon_Around.BP_QuickSummon_Around_C
// Size: 0x38 // Inherited bytes: 0x38
struct UBP_QuickSummon_Around_C : USolarQuickSummonProxy {
	// Functions

	// Object Name: Function BP_QuickSummon_Around.BP_QuickSummon_Around_C.IsPlaceable
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	bool IsPlaceable(struct AActor* Summoner); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x9)
};

