#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_QuickSummon_Forward.BP_QuickSummon_Forward_C
// Size: 0x60 // Inherited bytes: 0x38
struct UBP_QuickSummon_Forward_C : USolarQuickSummonProxy {
	// Fields
	float CheckHeightUp; // Offset: 0x38 // Size: 0x04
	float CheckHeightDown; // Offset: 0x3c // Size: 0x04
	struct FVector SummonDirection; // Offset: 0x40 // Size: 0x0c
	char pad_0x4C[0x4]; // Offset: 0x4c // Size: 0x04
	struct TArray<float> CheckDistanceArray; // Offset: 0x50 // Size: 0x10

	// Functions

	// Object Name: Function BP_QuickSummon_Forward.BP_QuickSummon_Forward_C.IsPlaceable
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	bool IsPlaceable(struct AActor* Summoner); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x9)
};

