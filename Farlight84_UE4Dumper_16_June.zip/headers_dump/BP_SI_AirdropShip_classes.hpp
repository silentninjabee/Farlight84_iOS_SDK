#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_SI_AirdropShip.BP_SI_AirdropShip_C
// Size: 0x2e8 // Inherited bytes: 0x280
struct ABP_SI_AirdropShip_C : ASCMMapElementBase {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x280 // Size: 0x08
	struct UStaticMeshComponent* Airdropship; // Offset: 0x288 // Size: 0x08
	struct USceneComponent* Scene; // Offset: 0x290 // Size: 0x08
	float TL_Move_MovePercent_3755E1654BBA2D1D5946D69E7B12C849; // Offset: 0x298 // Size: 0x04
	enum class ETimelineDirection TL_Move__Direction_3755E1654BBA2D1D5946D69E7B12C849; // Offset: 0x29c // Size: 0x01
	char pad_0x29D[0x3]; // Offset: 0x29d // Size: 0x03
	struct UTimelineComponent* TL_Move; // Offset: 0x2a0 // Size: 0x08
	float TL_MatParameter_Dissolve_C27A8BEA48A6A9AFC6FB2DA0F53EDDEE; // Offset: 0x2a8 // Size: 0x04
	enum class ETimelineDirection TL_MatParameter__Direction_C27A8BEA48A6A9AFC6FB2DA0F53EDDEE; // Offset: 0x2ac // Size: 0x01
	char pad_0x2AD[0x3]; // Offset: 0x2ad // Size: 0x03
	struct UTimelineComponent* TL_MatParameter; // Offset: 0x2b0 // Size: 0x08
	float TL_UpDown_UpDownPercent_BD5CDCD24E44D39C909693AB24080166; // Offset: 0x2b8 // Size: 0x04
	enum class ETimelineDirection TL_UpDown__Direction_BD5CDCD24E44D39C909693AB24080166; // Offset: 0x2bc // Size: 0x01
	char pad_0x2BD[0x3]; // Offset: 0x2bd // Size: 0x03
	struct UTimelineComponent* TL_UpDown; // Offset: 0x2c0 // Size: 0x08
	float TimeToComplete; // Offset: 0x2c8 // Size: 0x04
	float OffsetZ; // Offset: 0x2cc // Size: 0x04
	float UpDownRate; // Offset: 0x2d0 // Size: 0x04
	int32_t count; // Offset: 0x2d4 // Size: 0x04
	struct USplineComponent* SplineCache; // Offset: 0x2d8 // Size: 0x08
	float PlaybackPosition; // Offset: 0x2e0 // Size: 0x04
	float FixValue; // Offset: 0x2e4 // Size: 0x04

	// Functions

	// Object Name: Function BP_SI_AirdropShip.BP_SI_AirdropShip_C.OnRep_SplineCache
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnRep_SplineCache(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_SI_AirdropShip.BP_SI_AirdropShip_C.ShipMove
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void ShipMove(float Alpha); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function BP_SI_AirdropShip.BP_SI_AirdropShip_C.OnRep_PlaybackPosition
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnRep_PlaybackPosition(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_SI_AirdropShip.BP_SI_AirdropShip_C.GetSpline
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	struct USplineComponent* GetSpline(); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function BP_SI_AirdropShip.BP_SI_AirdropShip_C.TL_UpDown__FinishedFunc
	// Flags: [BlueprintEvent]
	void TL_UpDown__FinishedFunc(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_SI_AirdropShip.BP_SI_AirdropShip_C.TL_UpDown__UpdateFunc
	// Flags: [BlueprintEvent]
	void TL_UpDown__UpdateFunc(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_SI_AirdropShip.BP_SI_AirdropShip_C.TL_MatParameter__FinishedFunc
	// Flags: [BlueprintEvent]
	void TL_MatParameter__FinishedFunc(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_SI_AirdropShip.BP_SI_AirdropShip_C.TL_MatParameter__UpdateFunc
	// Flags: [BlueprintEvent]
	void TL_MatParameter__UpdateFunc(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_SI_AirdropShip.BP_SI_AirdropShip_C.TL_Move__FinishedFunc
	// Flags: [BlueprintEvent]
	void TL_Move__FinishedFunc(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_SI_AirdropShip.BP_SI_AirdropShip_C.TL_Move__UpdateFunc
	// Flags: [BlueprintEvent]
	void TL_Move__UpdateFunc(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_SI_AirdropShip.BP_SI_AirdropShip_C.ReceiveBeginPlay
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveBeginPlay(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_SI_AirdropShip.BP_SI_AirdropShip_C.ReceiveTick
	// Flags: [Event|Public|BlueprintEvent]
	void ReceiveTick(float DeltaSeconds); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function BP_SI_AirdropShip.BP_SI_AirdropShip_C.ShipDissolve
	// Flags: [BlueprintCallable|BlueprintEvent]
	void ShipDissolve(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_SI_AirdropShip.BP_SI_AirdropShip_C.ShipAppear
	// Flags: [BlueprintCallable|BlueprintEvent]
	void ShipAppear(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_SI_AirdropShip.BP_SI_AirdropShip_C.ShipToMove
	// Flags: [BlueprintCallable|BlueprintEvent]
	void ShipToMove(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_SI_AirdropShip.BP_SI_AirdropShip_C.ExecuteUbergraph_BP_SI_AirdropShip
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_BP_SI_AirdropShip(int32_t EntryPoint); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x4)
};

