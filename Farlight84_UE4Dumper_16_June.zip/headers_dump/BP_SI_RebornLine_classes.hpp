#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_SI_RebornLine.BP_SI_RebornLine_C
// Size: 0x248 // Inherited bytes: 0x228
struct ABP_SI_RebornLine_C : AActor {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x228 // Size: 0x08
	struct UStaticMeshComponent* FX_Tag; // Offset: 0x230 // Size: 0x08
	struct UStaticMeshComponent* FX_Tag_Glow; // Offset: 0x238 // Size: 0x08
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x240 // Size: 0x08

	// Functions

	// Object Name: Function BP_SI_RebornLine.BP_SI_RebornLine_C.Event_SetWaitingColor
	// Flags: [BlueprintCallable|BlueprintEvent]
	void Event_SetWaitingColor(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_SI_RebornLine.BP_SI_RebornLine_C.Event_SetFinishColor
	// Flags: [BlueprintCallable|BlueprintEvent]
	void Event_SetFinishColor(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_SI_RebornLine.BP_SI_RebornLine_C.ExecuteUbergraph_BP_SI_RebornLine
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_BP_SI_RebornLine(int32_t EntryPoint); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x4)
};

