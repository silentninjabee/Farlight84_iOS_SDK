#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_SolarCameraShakeJetPackLaunch.BP_SolarCameraShakeJetPackLaunch_C
// Size: 0x160 // Inherited bytes: 0x160
struct UBP_SolarCameraShakeJetPackLaunch_C : UCameraShake {
};

