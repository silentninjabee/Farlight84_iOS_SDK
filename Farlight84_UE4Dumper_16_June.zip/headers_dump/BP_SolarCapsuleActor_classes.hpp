#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_SolarCapsuleActor.BP_SolarCapsuleActor_C
// Size: 0x358 // Inherited bytes: 0x350
struct ABP_SolarCapsuleActor_C : ASolarCapsuleActor {
	// Fields
	struct UStaticMeshComponent* FX_G_Cricle_Spread_002; // Offset: 0x350 // Size: 0x08
};

