#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_SolarFlyTrail.BP_SolarFlyTrail_C
// Size: 0x5a8 // Inherited bytes: 0x5a0
struct ABP_SolarFlyTrail_C : ASolarFlyTrail {
	// Fields
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x5a0 // Size: 0x08
};

