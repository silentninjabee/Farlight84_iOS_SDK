#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_SolarItemSpawner.BP_SolarItemSpawner_C
// Size: 0x3a8 // Inherited bytes: 0x390
struct ABP_SolarItemSpawner_C : ASolarItemSpawner {
	// Fields
	struct UStaticMeshComponent* Cube; // Offset: 0x390 // Size: 0x08
	struct UBillboardComponent* Billboard; // Offset: 0x398 // Size: 0x08
	struct USceneComponent* SceneRoot; // Offset: 0x3a0 // Size: 0x08

	// Functions

	// Object Name: Function BP_SolarItemSpawner.BP_SolarItemSpawner_C.UserConstructionScript
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void UserConstructionScript(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)
};

