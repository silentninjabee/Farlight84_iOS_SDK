#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_SolarNavQueryFilter_ExcludeJetAndVault.BP_SolarNavQueryFilter_ExcludeJetAndVault_C
// Size: 0x48 // Inherited bytes: 0x48
struct UBP_SolarNavQueryFilter_ExcludeJetAndVault_C : USolarNavQueryFilter {
};

