#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_SolarTreasureBoxSpawner.BP_SolarTreasureBoxSpawner_C
// Size: 0x440 // Inherited bytes: 0x420
struct ABP_SolarTreasureBoxSpawner_C : ASolarTreasureBoxSpawner {
	// Fields
	struct UArrowComponent* Arrow; // Offset: 0x420 // Size: 0x08
	struct UStaticMeshComponent* Cube; // Offset: 0x428 // Size: 0x08
	struct UBillboardComponent* Billboard; // Offset: 0x430 // Size: 0x08
	struct USceneComponent* SceneRoot; // Offset: 0x438 // Size: 0x08
};

