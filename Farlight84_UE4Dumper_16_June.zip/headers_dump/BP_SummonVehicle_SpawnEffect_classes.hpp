#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_SummonVehicle_SpawnEffect.BP_SummonVehicle_SpawnEffect_C
// Size: 0x284 // Inherited bytes: 0x24c
struct ABP_SummonVehicle_SpawnEffect_C : ABP_Summon_Placeholder_C {
	// Fields
	char pad_0x24C[0x4]; // Offset: 0x24c // Size: 0x04
	struct UStaticMeshComponent* VH_Tire_WL01_A_LOD0; // Offset: 0x250 // Size: 0x08
	struct UStaticMeshComponent* VH_Tire_WL01_A_Summon; // Offset: 0x258 // Size: 0x08
	struct UStaticMeshComponent* DepthOnly; // Offset: 0x260 // Size: 0x08
	bool DepthCullEnabled; // Offset: 0x268 // Size: 0x01
	char pad_0x269[0x7]; // Offset: 0x269 // Size: 0x07
	struct UMaterialInterface* Preview; // Offset: 0x270 // Size: 0x08
	struct UMaterial* DepthMaterial; // Offset: 0x278 // Size: 0x08
	float GradientMask_Offset; // Offset: 0x280 // Size: 0x04

	// Functions

	// Object Name: Function BP_SummonVehicle_SpawnEffect.BP_SummonVehicle_SpawnEffect_C.SetSummonMesh
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetSummonMesh(struct UStaticMesh* InVehicleMesh); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function BP_SummonVehicle_SpawnEffect.BP_SummonVehicle_SpawnEffect_C.UpdateSpawnEffect
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void UpdateSpawnEffect(float InMaskOffset); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function BP_SummonVehicle_SpawnEffect.BP_SummonVehicle_SpawnEffect_C.UserConstructionScript
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void UserConstructionScript(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)
};

