#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_WarmGameLogic_NoramlWarmGame.BP_WarmGameLogic_NoramlWarmGame_C
// Size: 0x350 // Inherited bytes: 0x238
struct ABP_WarmGameLogic_NoramlWarmGame_C : ABP_WarmGameLogicBase_C {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x238 // Size: 0x08
	struct TMap<int32_t, struct FVector2D> ; // Offset: 0x240 // Size: 0x50
	struct TMap<int32_t, struct FVector2D> ; // Offset: 0x290 // Size: 0x50
	struct UDataTable* BattleTimelineConfig; // Offset: 0x2e0 // Size: 0x08
	struct TMap<int32_t, struct FVector2D> ; // Offset: 0x2e8 // Size: 0x50
	int32_t AirLineID; // Offset: 0x338 // Size: 0x04
	char pad_0x33C[0x4]; // Offset: 0x33c // Size: 0x04
	struct TArray<struct FVector> PoisonCircleCenterArray; // Offset: 0x340 // Size: 0x10

	// Functions

	// Object Name: Function BP_WarmGameLogic_NoramlWarmGame.BP_WarmGameLogic_NoramlWarmGame_C.
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void (struct UBP_MapInfoComponent_C* InputPin); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function BP_WarmGameLogic_NoramlWarmGame.BP_WarmGameLogic_NoramlWarmGame_C.
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void (struct UBP_MapInfoComponent_C* MapInfo); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function BP_WarmGameLogic_NoramlWarmGame.BP_WarmGameLogic_NoramlWarmGame_C.Event_ExecLogic
	// Flags: [BlueprintCallable|BlueprintEvent]
	void Event_ExecLogic(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_WarmGameLogic_NoramlWarmGame.BP_WarmGameLogic_NoramlWarmGame_C.ExecuteUbergraph_BP_WarmGameLogic_NoramlWarmGame
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_BP_WarmGameLogic_NoramlWarmGame(int32_t EntryPoint); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x4)
};

