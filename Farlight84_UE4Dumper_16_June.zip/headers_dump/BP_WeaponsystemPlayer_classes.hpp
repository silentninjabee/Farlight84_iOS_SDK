#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_WeaponsystemPlayer.BP_WeaponsystemPlayer_C
// Size: 0x310 // Inherited bytes: 0x310
struct UBP_WeaponsystemPlayer_C : UWeaponSystemPlayer {
};

