#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_YJ_R_LodP_Prop_Set01.BP_YJ_R_LodP_Prop_Set01_C
// Size: 0x238 // Inherited bytes: 0x238
struct ABP_YJ_R_LodP_Prop_Set01_C : AStaticMeshActor {
};

