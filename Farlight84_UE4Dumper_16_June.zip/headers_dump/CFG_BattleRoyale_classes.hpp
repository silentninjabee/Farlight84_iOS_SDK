#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass CFG_BattleRoyale.CFG_BattleRoyale_C
// Size: 0x31f // Inherited bytes: 0x1e9
struct UCFG_BattleRoyale_C : UCFG_Framework_C {
	// Fields
	char pad_0x1E9[0x3]; // Offset: 0x1e9 // Size: 0x03
	int32_t ; // Offset: 0x1ec // Size: 0x04
	int32_t ; // Offset: 0x1f0 // Size: 0x04
	int32_t ; // Offset: 0x1f4 // Size: 0x04
	struct UBehaviorTree* ; // Offset: 0x1f8 // Size: 0x08
	struct UBehaviorTree* ; // Offset: 0x200 // Size: 0x08
	struct UBehaviorTree* ; // Offset: 0x208 // Size: 0x08
	int32_t ; // Offset: 0x210 // Size: 0x04
	char pad_0x214[0x4]; // Offset: 0x214 // Size: 0x04
	struct UDataTable* ; // Offset: 0x218 // Size: 0x08
	int32_t ; // Offset: 0x220 // Size: 0x04
	char pad_0x224[0x4]; // Offset: 0x224 // Size: 0x04
	struct ASolarBotAIController* AIController; // Offset: 0x228 // Size: 0x08
	bool ; // Offset: 0x230 // Size: 0x01
	char pad_0x231[0x3]; // Offset: 0x231 // Size: 0x03
	float ; // Offset: 0x234 // Size: 0x04
	float ; // Offset: 0x238 // Size: 0x04
	int32_t ; // Offset: 0x23c // Size: 0x04
	int32_t ; // Offset: 0x240 // Size: 0x04
	int32_t ; // Offset: 0x244 // Size: 0x04
	int32_t ; // Offset: 0x248 // Size: 0x04
	int32_t ; // Offset: 0x24c // Size: 0x04
	struct FInt32Range ; // Offset: 0x250 // Size: 0x10
	struct FInt32Range ; // Offset: 0x260 // Size: 0x10
	float ; // Offset: 0x270 // Size: 0x04
	struct FS_SkillState ; // Offset: 0x274 // Size: 0x02
	struct FS_SkillState ; // Offset: 0x276 // Size: 0x02
	struct TMap<int32_t, int32_t> ; // Offset: 0x278 // Size: 0x50
	struct TMap<int32_t, int32_t> ; // Offset: 0x2c8 // Size: 0x50
	struct FS_SkillState ; // Offset: 0x318 // Size: 0x02
	struct FS_SkillState ; // Offset: 0x31a // Size: 0x02
	bool ; // Offset: 0x31c // Size: 0x01
	struct FS_SkillState ; // Offset: 0x31d // Size: 0x02
};

