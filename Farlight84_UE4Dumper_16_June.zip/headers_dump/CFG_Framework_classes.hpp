#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass CFG_Framework.CFG_Framework_C
// Size: 0x1e9 // Inherited bytes: 0x1e0
struct UCFG_Framework_C : UCGMGameplayConfig {
	// Fields
	struct UBP_ConfigSave_C* ModeConfig; // Offset: 0x1e0 // Size: 0x08
	bool ; // Offset: 0x1e8 // Size: 0x01

	// Functions

	// Object Name: Function CFG_Framework.CFG_Framework_C.GetCustomRoomData
	// Flags: [Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	struct FCustomRoomData GetCustomRoomData(); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x70)

	// Object Name: Function CFG_Framework.CFG_Framework_C.IsCustomRoomMode
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	bool IsCustomRoomMode(); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function CFG_Framework.CFG_Framework_C.GetSavedConfig
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void GetSavedConfig(struct UBP_ConfigSave_C*& AsBP Config Save, bool& bSuccess); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x9)
};

