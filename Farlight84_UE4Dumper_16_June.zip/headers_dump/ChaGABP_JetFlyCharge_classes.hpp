#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass ChaGABP_JetFlyCharge.ChaGABP_JetFlyCharge_C
// Size: 0x4b0 // Inherited bytes: 0x4b0
struct UChaGABP_JetFlyCharge_C : UChaGA_JetFlyCharge {
};

