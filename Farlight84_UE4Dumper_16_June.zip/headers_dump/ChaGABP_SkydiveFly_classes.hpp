#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass ChaGABP_SkydiveFly.ChaGABP_SkydiveFly_C
// Size: 0x460 // Inherited bytes: 0x460
struct UChaGABP_SkydiveFly_C : UChaGA_SkydiveFly {
};

