#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass ChaGABP_Swim.ChaGABP_Swim_C
// Size: 0x458 // Inherited bytes: 0x458
struct UChaGABP_Swim_C : UChaGA_Swim {
};

