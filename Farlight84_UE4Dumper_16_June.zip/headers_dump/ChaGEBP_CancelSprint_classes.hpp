#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass ChaGEBP_CancelSprint.ChaGEBP_CancelSprint_C
// Size: 0x848 // Inherited bytes: 0x848
struct UChaGEBP_CancelSprint_C : UGameplayEffect {
};

