#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass ChaGEBP_ExtraHJetTimes.ChaGEBP_ExtraHJetTimes_C
// Size: 0x848 // Inherited bytes: 0x848
struct UChaGEBP_ExtraHJetTimes_C : UGameplayEffect {
};

