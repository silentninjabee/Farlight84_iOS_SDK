#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum ClothingSystemRuntimeNv.EClothingWindMethodNv
enum class EClothingWindMethodNv : uint8 {
	Legacy = 0,
	Accurate = 1,
	EClothingWindMethodNv_MAX = 2
};

