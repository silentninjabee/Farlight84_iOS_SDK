#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass EQC_SolarPlayerContext.EQC_SolarPlayerContext_C
// Size: 0x30 // Inherited bytes: 0x30
struct UEQC_SolarPlayerContext_C : UEnvQueryContext_BlueprintBase {
	// Functions

	// Object Name: Function EQC_SolarPlayerContext.EQC_SolarPlayerContext_C.ProvideSingleActor
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	void ProvideSingleActor(struct UObject* QuerierObject, struct AActor* QuerierActor, struct AActor*& ResultingActor); // Offset: 0x102f8211c // Return & Params: Num(3) Size(0x18)
};

