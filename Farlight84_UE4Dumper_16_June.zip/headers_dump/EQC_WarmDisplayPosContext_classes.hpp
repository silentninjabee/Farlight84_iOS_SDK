#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass EQC_WarmDisplayPosContext.EQC_WarmDisplayPosContext_C
// Size: 0x30 // Inherited bytes: 0x30
struct UEQC_WarmDisplayPosContext_C : UEnvQueryContext_BlueprintBase {
	// Functions

	// Object Name: Function EQC_WarmDisplayPosContext.EQC_WarmDisplayPosContext_C.ProvideSingleLocation
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	void ProvideSingleLocation(struct UObject* QuerierObject, struct AActor* QuerierActor, struct FVector& ResultingLocation); // Offset: 0x102f8211c // Return & Params: Num(3) Size(0x1c)
};

