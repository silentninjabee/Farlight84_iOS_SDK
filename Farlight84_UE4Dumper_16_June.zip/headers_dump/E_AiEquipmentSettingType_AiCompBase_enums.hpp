#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum E_AiEquipmentSettingType_AiCompBase.E_AiEquipmentSettingType_AiCompBase
enum class E_AiEquipmentSettingType_AiCompBase : uint8 {
	None = 0,
	PrimaryWeapon = 1,
	SecondaryWeapon = 2,
	Shield = 3,
	VerticalJet = 4,
	HorizontalJet = 5,
	SummonGun = 6,
	E Ai Equipment Setting Type MAX = 7
};

