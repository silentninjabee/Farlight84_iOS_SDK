#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum E_AiState_AiCompBase.E_AiState_AiCompBase
enum class E_AiState_AiCompBase : uint8 {
	None = 0,
	Active = 1,
	Preserved = 2,
	Triggered = 3,
	Killer = 4,
	Killed = 5,
	E Ai State MAX = 6
};

