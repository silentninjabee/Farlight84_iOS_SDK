#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum E_BattleEvent_BattleRoyale.E_BattleEvent_BattleRoyale
enum class E_BattleEvent_BattleRoyale : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator2 = 2,
	NewEnumerator3 = 3,
	NewEnumerator4 = 4,
	NewEnumerator5 = 5,
	E Battle Event MAX = 6
};

