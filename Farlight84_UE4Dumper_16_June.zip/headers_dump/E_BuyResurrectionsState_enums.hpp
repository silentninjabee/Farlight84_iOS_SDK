#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum E_BuyResurrectionsState.E_BuyResurrectionsState
enum class E_BuyResurrectionsState : uint8 {
	None = 0,
	DeathWaitingToBuy = 1,
	NotBuy = 2,
	SuccessfullyResurrected = 3,
	WaitingTeammatesHelp = 4,
	GiveUp = 5,
	TimeOut = 6,
	AllTeammatesDied = 7,
	E MAX = 8
};

