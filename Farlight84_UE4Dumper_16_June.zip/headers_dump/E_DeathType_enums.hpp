#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum E_DeathType.E_DeathType
enum class E_DeathType : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	E MAX = 2
};

