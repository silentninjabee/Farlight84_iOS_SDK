#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum E_DefenderPlayerType.E_DefenderPlayerType
enum class E_DefenderPlayerType : uint8 {
	Normal = 0,
	Defender = 1,
	Terminator = 2,
	E MAX = 3
};

