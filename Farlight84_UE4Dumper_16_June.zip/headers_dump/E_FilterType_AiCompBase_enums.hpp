#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum E_FilterType_AiCompBase.E_FilterType_AiCompBase
enum class E_FilterType_AiCompBase : uint8 {
	None = 0,
	NewEnumerator0 = 1,
	NewEnumerator1 = 2,
	NewEnumerator2 = 3,
	NewEnumerator3 = 4,
	NewEnumerator4 = 5,
	NewEnumerator5 = 6,
	NewEnumerator6 = 7,
	NewEnumerator8 = 8,
	NewEnumerator9 = 9,
	E Filter Type MAX = 10
};

