#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum E_GMCommand_BattleRoyale.E_GMCommand_BattleRoyale
enum class E_GMCommand_BattleRoyale : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator7 = 1,
	NewEnumerator1 = 2,
	NewEnumerator2 = 3,
	NewEnumerator3 = 4,
	NewEnumerator5 = 5,
	NewEnumerator6 = 6,
	NewEnumerator8 = 7,
	NewEnumerator9 = 8,
	E GMCommand MAX = 9
};

