#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum E_PlayerListType.E_PlayerListType
enum class E_PlayerListType : uint8 {
	AliveRealPlayer = 0,
	AliveAiPlayer = 1,
	E MAX = 2
};

