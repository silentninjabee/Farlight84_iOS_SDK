#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum E_Type_Mouse.E_Type_Mouse
enum class E_Type_Mouse : uint8 {
	LeftMouseButton = 0,
	MiddleMouseButton = 1,
	RightMouseButton = 2,
	ThumbMouseButton = 3,
	ThumbMouseButton2 = 4,
	E Type MAX = 5
};

