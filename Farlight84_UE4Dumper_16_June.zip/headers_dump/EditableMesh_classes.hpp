#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class EditableMesh.EditableMeshAdapter
// Size: 0x28 // Inherited bytes: 0x28
struct UEditableMeshAdapter : UObject {
};

// Object Name: Class EditableMesh.EditableGeometryCollectionAdapter
// Size: 0xd8 // Inherited bytes: 0x28
struct UEditableGeometryCollectionAdapter : UEditableMeshAdapter {
	// Fields
	struct UGeometryCollection* GeometryCollection; // Offset: 0x28 // Size: 0x08
	struct UGeometryCollection* OriginalGeometryCollection; // Offset: 0x30 // Size: 0x08
	int32_t GeometryCollectionLODIndex; // Offset: 0x38 // Size: 0x04
	char pad_0x3C[0x9c]; // Offset: 0x3c // Size: 0x9c
};

// Object Name: Class EditableMesh.EditableMesh
// Size: 0x678 // Inherited bytes: 0x28
struct UEditableMesh : UObject {
	// Fields
	char pad_0x28[0x390]; // Offset: 0x28 // Size: 0x390
	struct TArray<struct UEditableMeshAdapter*> Adapters; // Offset: 0x3b8 // Size: 0x10
	char pad_0x3C8[0x8]; // Offset: 0x3c8 // Size: 0x08
	int32_t TextureCoordinateCount; // Offset: 0x3d0 // Size: 0x04
	char pad_0x3D4[0x148]; // Offset: 0x3d4 // Size: 0x148
	int32_t PendingCompactCounter; // Offset: 0x51c // Size: 0x04
	int32_t SubdivisionCount; // Offset: 0x520 // Size: 0x04
	char pad_0x524[0x154]; // Offset: 0x524 // Size: 0x154

	// Functions

	// Object Name: Function EditableMesh.EditableMesh.WeldVertices
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void WeldVertices(struct TArray<struct FVertexID>& VertexIDs, struct FVertexID& OutNewVertexID); // Offset: 0x10117cecc // Return & Params: Num(2) Size(0x14)

	// Object Name: Function EditableMesh.EditableMesh.TryToRemoveVertex
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void TryToRemoveVertex(struct FVertexID VertexID, bool& bOutWasVertexRemoved, struct FEdgeID& OutNewEdgeID); // Offset: 0x10117e058 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function EditableMesh.EditableMesh.TryToRemovePolygonEdge
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void TryToRemovePolygonEdge(struct FEdgeID EdgeID, bool& bOutWasEdgeRemoved, struct FPolygonID& OutNewPolygonID); // Offset: 0x10117e1a4 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function EditableMesh.EditableMesh.TriangulatePolygons
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void TriangulatePolygons(struct TArray<struct FPolygonID>& PolygonIDs, struct TArray<struct FPolygonID>& OutNewTrianglePolygons); // Offset: 0x10117d278 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function EditableMesh.EditableMesh.TessellatePolygons
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void TessellatePolygons(struct TArray<struct FPolygonID>& PolygonIDs, enum class ETriangleTessellationMode TriangleTessellationMode, struct TArray<struct FPolygonID>& OutNewPolygonIDs); // Offset: 0x10117cd88 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function EditableMesh.EditableMesh.StartModification
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StartModification(enum class EMeshModificationType MeshModificationType, enum class EMeshTopologyChange MeshTopologyChange); // Offset: 0x101182bc0 // Return & Params: Num(2) Size(0x2)

	// Object Name: Function EditableMesh.EditableMesh.SplitPolygons
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SplitPolygons(struct TArray<struct FPolygonToSplit>& PolygonsToSplit, struct TArray<struct FEdgeID>& OutNewEdgeIDs); // Offset: 0x10117f504 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function EditableMesh.EditableMesh.SplitPolygonalMesh
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void SplitPolygonalMesh(struct FPlane& InPlane, struct TArray<struct FPolygonID>& PolygonIDs1, struct TArray<struct FPolygonID>& PolygonIDs2, struct TArray<struct FEdgeID>& BoundaryIDs); // Offset: 0x10117ca30 // Return & Params: Num(4) Size(0x40)

	// Object Name: Function EditableMesh.EditableMesh.SplitEdge
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SplitEdge(struct FEdgeID EdgeID, struct TArray<float>& Splits, struct TArray<struct FVertexID>& OutNewVertexIDs); // Offset: 0x10117f780 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function EditableMesh.EditableMesh.SetVerticesCornerSharpness
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetVerticesCornerSharpness(struct TArray<struct FVertexID>& VertexIDs, struct TArray<float>& VerticesNewCornerSharpness); // Offset: 0x10117d6e4 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function EditableMesh.EditableMesh.SetVerticesAttributes
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetVerticesAttributes(struct TArray<struct FAttributesForVertex>& AttributesForVertices); // Offset: 0x10117e628 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function EditableMesh.EditableMesh.SetVertexInstancesAttributes
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetVertexInstancesAttributes(struct TArray<struct FAttributesForVertexInstance>& AttributesForVertexInstances); // Offset: 0x10117e560 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function EditableMesh.EditableMesh.SetTextureCoordinateCount
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetTextureCoordinateCount(int32_t NumTexCoords); // Offset: 0x10117cd0c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function EditableMesh.EditableMesh.SetSubdivisionCount
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSubdivisionCount(int32_t NewSubdivisionCount); // Offset: 0x10117fa54 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function EditableMesh.EditableMesh.SetPolygonsVertexAttributes
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetPolygonsVertexAttributes(struct TArray<struct FVertexAttributesForPolygon>& VertexAttributesForPolygons); // Offset: 0x10117e404 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function EditableMesh.EditableMesh.SetEdgesHardnessAutomatically
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetEdgesHardnessAutomatically(struct TArray<struct FEdgeID>& EdgeIDs, float MaxDotProductForSoftEdge); // Offset: 0x10117d40c // Return & Params: Num(2) Size(0x14)

	// Object Name: Function EditableMesh.EditableMesh.SetEdgesHardness
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetEdgesHardness(struct TArray<struct FEdgeID>& EdgeIDs, struct TArray<bool>& EdgesNewIsHard); // Offset: 0x10117d4ec // Return & Params: Num(2) Size(0x20)

	// Object Name: Function EditableMesh.EditableMesh.SetEdgesCreaseSharpness
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetEdgesCreaseSharpness(struct TArray<struct FEdgeID>& EdgeIDs, struct TArray<float>& EdgesNewCreaseSharpness); // Offset: 0x10117d5e8 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function EditableMesh.EditableMesh.SetEdgesAttributes
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetEdgesAttributes(struct TArray<struct FAttributesForEdge>& AttributesForEdges); // Offset: 0x10117e498 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function EditableMesh.EditableMesh.SetAllowUndo
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAllowUndo(bool bInAllowUndo); // Offset: 0x101181984 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function EditableMesh.EditableMesh.SetAllowSpatialDatabase
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAllowSpatialDatabase(bool bInAllowSpatialDatabase); // Offset: 0x1011818e4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function EditableMesh.EditableMesh.SetAllowCompact
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAllowCompact(bool bInAllowCompact); // Offset: 0x101181814 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function EditableMesh.EditableMesh.SearchSpatialDatabaseForPolygonsPotentiallyIntersectingPlane
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	void SearchSpatialDatabaseForPolygonsPotentiallyIntersectingPlane(struct FPlane& InPlane, struct TArray<struct FPolygonID>& OutPolygons); // Offset: 0x10117fad0 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function EditableMesh.EditableMesh.SearchSpatialDatabaseForPolygonsPotentiallyIntersectingLineSegment
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	void SearchSpatialDatabaseForPolygonsPotentiallyIntersectingLineSegment(struct FVector LineSegmentStart, struct FVector LineSegmentEnd, struct TArray<struct FPolygonID>& OutPolygons); // Offset: 0x10117fcb8 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function EditableMesh.EditableMesh.SearchSpatialDatabaseForPolygonsInVolume
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void SearchSpatialDatabaseForPolygonsInVolume(struct TArray<struct FPlane>& Planes, struct TArray<struct FPolygonID>& OutPolygons); // Offset: 0x10117fbbc // Return & Params: Num(2) Size(0x20)

	// Object Name: Function EditableMesh.EditableMesh.RevertInstance
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UEditableMesh* RevertInstance(); // Offset: 0x1011829ec // Return & Params: Num(1) Size(0x8)

	// Object Name: Function EditableMesh.EditableMesh.Revert
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Revert(); // Offset: 0x101182a20 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function EditableMesh.EditableMesh.RebuildRenderMesh
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RebuildRenderMesh(); // Offset: 0x101182c80 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function EditableMesh.EditableMesh.QuadrangulateMesh
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void QuadrangulateMesh(struct TArray<struct FPolygonID>& OutNewPolygonIDs); // Offset: 0x10117cc74 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function EditableMesh.EditableMesh.PropagateInstanceChanges
	// Flags: [Final|Native|Public|BlueprintCallable]
	void PropagateInstanceChanges(); // Offset: 0x1011829d8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function EditableMesh.EditableMesh.MoveVertices
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void MoveVertices(struct TArray<struct FVertexToMove>& VerticesToMove); // Offset: 0x10117f9bc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function EditableMesh.EditableMesh.MakeVertexID
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FVertexID MakeVertexID(int32_t VertexIndex); // Offset: 0x10118170c // Return & Params: Num(2) Size(0x8)

	// Object Name: Function EditableMesh.EditableMesh.MakePolygonID
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FPolygonID MakePolygonID(int32_t PolygonIndex); // Offset: 0x1011815a4 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function EditableMesh.EditableMesh.MakePolygonGroupID
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FPolygonGroupID MakePolygonGroupID(int32_t PolygonGroupIndex); // Offset: 0x10118161c // Return & Params: Num(2) Size(0x8)

	// Object Name: Function EditableMesh.EditableMesh.MakeEdgeID
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FEdgeID MakeEdgeID(int32_t EdgeIndex); // Offset: 0x101181694 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function EditableMesh.EditableMesh.IsValidVertex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsValidVertex(struct FVertexID VertexID); // Offset: 0x10118290c // Return & Params: Num(2) Size(0x5)

	// Object Name: Function EditableMesh.EditableMesh.IsValidPolygonGroup
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsValidPolygonGroup(struct FPolygonGroupID PolygonGroupID); // Offset: 0x1011820e8 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function EditableMesh.EditableMesh.IsValidPolygon
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsValidPolygon(struct FPolygonID PolygonID); // Offset: 0x101181eac // Return & Params: Num(2) Size(0x5)

	// Object Name: Function EditableMesh.EditableMesh.IsValidEdge
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsValidEdge(struct FEdgeID EdgeID); // Offset: 0x1011823fc // Return & Params: Num(2) Size(0x5)

	// Object Name: Function EditableMesh.EditableMesh.IsUndoAllowed
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsUndoAllowed(); // Offset: 0x101181a04 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function EditableMesh.EditableMesh.IsSpatialDatabaseAllowed
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsSpatialDatabaseAllowed(); // Offset: 0x101181968 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function EditableMesh.EditableMesh.IsPreviewingSubdivisions
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsPreviewingSubdivisions(); // Offset: 0x1011814d4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function EditableMesh.EditableMesh.IsOrphanedVertex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsOrphanedVertex(struct FVertexID VertexID); // Offset: 0x101182874 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function EditableMesh.EditableMesh.IsCompactAllowed
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsCompactAllowed(); // Offset: 0x101181894 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function EditableMesh.EditableMesh.IsCommittedAsInstance
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsCommittedAsInstance(); // Offset: 0x101182ad4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function EditableMesh.EditableMesh.IsCommitted
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsCommitted(); // Offset: 0x101182b08 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function EditableMesh.EditableMesh.IsBeingModified
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsBeingModified(); // Offset: 0x101181a20 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function EditableMesh.EditableMesh.InvalidVertexID
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FVertexID InvalidVertexID(); // Offset: 0x1011817f0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function EditableMesh.EditableMesh.InvalidPolygonID
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FPolygonID InvalidPolygonID(); // Offset: 0x101181784 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function EditableMesh.EditableMesh.InvalidPolygonGroupID
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FPolygonGroupID InvalidPolygonGroupID(); // Offset: 0x1011817a8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function EditableMesh.EditableMesh.InvalidEdgeID
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FEdgeID InvalidEdgeID(); // Offset: 0x1011817cc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function EditableMesh.EditableMesh.InsetPolygons
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void InsetPolygons(struct TArray<struct FPolygonID>& PolygonIDs, float InsetFixedDistance, float InsetProgressTowardCenter, enum class EInsetPolygonsMode Mode, struct TArray<struct FPolygonID>& OutNewCenterPolygonIDs, struct TArray<struct FPolygonID>& OutNewSidePolygonIDs); // Offset: 0x10117d9c0 // Return & Params: Num(6) Size(0x40)

	// Object Name: Function EditableMesh.EditableMesh.InsertEdgeLoop
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void InsertEdgeLoop(struct FEdgeID EdgeID, struct TArray<float>& Splits, struct TArray<struct FEdgeID>& OutNewEdgeIDs); // Offset: 0x10117f630 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function EditableMesh.EditableMesh.InitializeAdapters
	// Flags: [Final|Native|Public|BlueprintCallable]
	void InitializeAdapters(); // Offset: 0x101182c94 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function EditableMesh.EditableMesh.GetVertexPairEdge
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	struct FEdgeID GetVertexPairEdge(struct FVertexID VertexID, struct FVertexID NextVertexID, bool& bOutEdgeWindingIsReversed); // Offset: 0x101180fe8 // Return & Params: Num(4) Size(0x10)

	// Object Name: Function EditableMesh.EditableMesh.GetVertexInstanceVertex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FVertexID GetVertexInstanceVertex(struct FVertexInstanceID VertexInstanceID); // Offset: 0x101182638 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function EditableMesh.EditableMesh.GetVertexInstanceCount
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetVertexInstanceCount(); // Offset: 0x1011826d0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function EditableMesh.EditableMesh.GetVertexInstanceConnectedPolygons
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetVertexInstanceConnectedPolygons(struct FVertexInstanceID VertexInstanceID, struct TArray<struct FPolygonID>& OutConnectedPolygonIDs); // Offset: 0x101181210 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function EditableMesh.EditableMesh.GetVertexInstanceConnectedPolygonCount
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetVertexInstanceConnectedPolygonCount(struct FVertexInstanceID VertexInstanceID); // Offset: 0x1011825a0 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function EditableMesh.EditableMesh.GetVertexInstanceConnectedPolygon
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FPolygonID GetVertexInstanceConnectedPolygon(struct FVertexInstanceID VertexInstanceID, int32_t ConnectedPolygonNumber); // Offset: 0x1011824c8 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function EditableMesh.EditableMesh.GetVertexCount
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetVertexCount(); // Offset: 0x1011829a4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function EditableMesh.EditableMesh.GetVertexConnectedPolygons
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetVertexConnectedPolygons(struct FVertexID VertexID, struct TArray<struct FPolygonID>& OutConnectedPolygonIDs); // Offset: 0x1011812fc // Return & Params: Num(2) Size(0x18)

	// Object Name: Function EditableMesh.EditableMesh.GetVertexConnectedEdges
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetVertexConnectedEdges(struct FVertexID VertexID, struct TArray<struct FEdgeID>& OutConnectedEdgeIDs); // Offset: 0x1011813e8 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function EditableMesh.EditableMesh.GetVertexConnectedEdgeCount
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetVertexConnectedEdgeCount(struct FVertexID VertexID); // Offset: 0x1011827dc // Return & Params: Num(2) Size(0x8)

	// Object Name: Function EditableMesh.EditableMesh.GetVertexConnectedEdge
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FEdgeID GetVertexConnectedEdge(struct FVertexID VertexID, int32_t ConnectedEdgeNumber); // Offset: 0x101182704 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function EditableMesh.EditableMesh.GetVertexAdjacentVertices
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetVertexAdjacentVertices(struct FVertexID VertexID, struct TArray<struct FVertexID>& OutAdjacentVertexIDs); // Offset: 0x101181124 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function EditableMesh.EditableMesh.GetTextureCoordinateCount
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetTextureCoordinateCount(); // Offset: 0x10118153c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function EditableMesh.EditableMesh.GetSubdivisionLimitData
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FSubdivisionLimitData GetSubdivisionLimitData(); // Offset: 0x1011800e4 // Return & Params: Num(1) Size(0x30)

	// Object Name: Function EditableMesh.EditableMesh.GetSubdivisionCount
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetSubdivisionCount(); // Offset: 0x101181508 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function EditableMesh.EditableMesh.GetPolygonTriangulatedTriangleCount
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetPolygonTriangulatedTriangleCount(struct FPolygonID PolygonID); // Offset: 0x101181b34 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function EditableMesh.EditableMesh.GetPolygonTriangulatedTriangle
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FTriangleID GetPolygonTriangulatedTriangle(struct FPolygonID PolygonID, int32_t PolygonTriangleNumber); // Offset: 0x101181a5c // Return & Params: Num(3) Size(0xc)

	// Object Name: Function EditableMesh.EditableMesh.GetPolygonPerimeterVertices
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetPolygonPerimeterVertices(struct FPolygonID PolygonID, struct TArray<struct FVertexID>& OutPolygonPerimeterVertexIDs); // Offset: 0x101180a54 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function EditableMesh.EditableMesh.GetPolygonPerimeterVertexInstances
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetPolygonPerimeterVertexInstances(struct FPolygonID PolygonID, struct TArray<struct FVertexInstanceID>& OutPolygonPerimeterVertexInstanceIDs); // Offset: 0x101180968 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function EditableMesh.EditableMesh.GetPolygonPerimeterVertexInstance
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FVertexInstanceID GetPolygonPerimeterVertexInstance(struct FPolygonID PolygonID, int32_t PolygonVertexNumber); // Offset: 0x101181bcc // Return & Params: Num(3) Size(0xc)

	// Object Name: Function EditableMesh.EditableMesh.GetPolygonPerimeterVertexCount
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetPolygonPerimeterVertexCount(struct FPolygonID PolygonID); // Offset: 0x101181d7c // Return & Params: Num(2) Size(0x8)

	// Object Name: Function EditableMesh.EditableMesh.GetPolygonPerimeterVertex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FVertexID GetPolygonPerimeterVertex(struct FPolygonID PolygonID, int32_t PolygonVertexNumber); // Offset: 0x101181ca4 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function EditableMesh.EditableMesh.GetPolygonPerimeterEdges
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetPolygonPerimeterEdges(struct FPolygonID PolygonID, struct TArray<struct FEdgeID>& OutPolygonPerimeterEdgeIDs); // Offset: 0x10118074c // Return & Params: Num(2) Size(0x18)

	// Object Name: Function EditableMesh.EditableMesh.GetPolygonPerimeterEdgeCount
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetPolygonPerimeterEdgeCount(struct FPolygonID PolygonID); // Offset: 0x101180b40 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function EditableMesh.EditableMesh.GetPolygonPerimeterEdge
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	struct FEdgeID GetPolygonPerimeterEdge(struct FPolygonID PolygonID, int32_t PerimeterEdgeNumber, bool& bOutEdgeWindingIsReversedForPolygon); // Offset: 0x101180838 // Return & Params: Num(4) Size(0x10)

	// Object Name: Function EditableMesh.EditableMesh.GetPolygonInGroup
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FPolygonID GetPolygonInGroup(struct FPolygonGroupID PolygonGroupID, int32_t PolygonNumber); // Offset: 0x101181f78 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function EditableMesh.EditableMesh.GetPolygonGroupCount
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetPolygonGroupCount(); // Offset: 0x101182180 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function EditableMesh.EditableMesh.GetPolygonCountInGroup
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetPolygonCountInGroup(struct FPolygonGroupID PolygonGroupID); // Offset: 0x101182050 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function EditableMesh.EditableMesh.GetPolygonCount
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetPolygonCount(); // Offset: 0x101181f44 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function EditableMesh.EditableMesh.GetPolygonAdjacentPolygons
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetPolygonAdjacentPolygons(struct FPolygonID PolygonID, struct TArray<struct FPolygonID>& OutAdjacentPolygons); // Offset: 0x101180660 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function EditableMesh.EditableMesh.GetGroupForPolygon
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FPolygonGroupID GetGroupForPolygon(struct FPolygonID PolygonID); // Offset: 0x101181e14 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function EditableMesh.EditableMesh.GetFirstValidPolygonGroup
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FPolygonGroupID GetFirstValidPolygonGroup(); // Offset: 0x101181570 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function EditableMesh.EditableMesh.GetEdgeVertices
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetEdgeVertices(struct FEdgeID EdgeID, struct FVertexID& OutEdgeVertexID0, struct FVertexID& OutEdgeVertexID1); // Offset: 0x101180e94 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function EditableMesh.EditableMesh.GetEdgeVertex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FVertexID GetEdgeVertex(struct FEdgeID EdgeID, int32_t EdgeVertexNumber); // Offset: 0x101182324 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function EditableMesh.EditableMesh.GetEdgeThatConnectsVertices
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FEdgeID GetEdgeThatConnectsVertices(struct FVertexID VertexID0, struct FVertexID VertexID1); // Offset: 0x101180bd8 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function EditableMesh.EditableMesh.GetEdgeLoopElements
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetEdgeLoopElements(struct FEdgeID EdgeID, struct TArray<struct FEdgeID>& EdgeLoopIDs); // Offset: 0x101180cbc // Return & Params: Num(2) Size(0x18)

	// Object Name: Function EditableMesh.EditableMesh.GetEdgeCount
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetEdgeCount(); // Offset: 0x101182494 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function EditableMesh.EditableMesh.GetEdgeConnectedPolygons
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetEdgeConnectedPolygons(struct FEdgeID EdgeID, struct TArray<struct FPolygonID>& OutConnectedPolygonIDs); // Offset: 0x101180da8 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function EditableMesh.EditableMesh.GetEdgeConnectedPolygonCount
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetEdgeConnectedPolygonCount(struct FEdgeID EdgeID); // Offset: 0x10118228c // Return & Params: Num(2) Size(0x8)

	// Object Name: Function EditableMesh.EditableMesh.GetEdgeConnectedPolygon
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FPolygonID GetEdgeConnectedPolygon(struct FEdgeID EdgeID, int32_t ConnectedPolygonNumber); // Offset: 0x1011821b4 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function EditableMesh.EditableMesh.GeneratePolygonTangentsAndNormals
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void GeneratePolygonTangentsAndNormals(struct TArray<struct FPolygonID>& PolygonIDs); // Offset: 0x10117cbdc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function EditableMesh.EditableMesh.FlipPolygons
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void FlipPolygons(struct TArray<struct FPolygonID>& PolygonIDs); // Offset: 0x10117d374 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function EditableMesh.EditableMesh.FindPolygonPerimeterVertexNumberForVertex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t FindPolygonPerimeterVertexNumberForVertex(struct FPolygonID PolygonID, struct FVertexID VertexID); // Offset: 0x10118057c // Return & Params: Num(3) Size(0xc)

	// Object Name: Function EditableMesh.EditableMesh.FindPolygonPerimeterEdgeNumberForVertices
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t FindPolygonPerimeterEdgeNumberForVertices(struct FPolygonID PolygonID, struct FVertexID EdgeVertexID0, struct FVertexID EdgeVertexID1); // Offset: 0x10118044c // Return & Params: Num(4) Size(0x10)

	// Object Name: Function EditableMesh.EditableMesh.FindPolygonLoop
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void FindPolygonLoop(struct FEdgeID EdgeID, struct TArray<struct FEdgeID>& OutEdgeLoopEdgeIDs, struct TArray<struct FEdgeID>& OutFlippedEdgeIDs, struct TArray<struct FEdgeID>& OutReversedEdgeIDPathToTake, struct TArray<struct FPolygonID>& OutPolygonIDsToSplit); // Offset: 0x10117fdd8 // Return & Params: Num(5) Size(0x48)

	// Object Name: Function EditableMesh.EditableMesh.ExtrudePolygons
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void ExtrudePolygons(struct TArray<struct FPolygonID>& Polygons, float ExtrudeDistance, bool bKeepNeighborsTogether, struct TArray<struct FPolygonID>& OutNewExtrudedFrontPolygons); // Offset: 0x10117dec4 // Return & Params: Num(4) Size(0x28)

	// Object Name: Function EditableMesh.EditableMesh.ExtendVertices
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void ExtendVertices(struct TArray<struct FVertexID>& VertexIDs, bool bOnlyExtendClosestEdge, struct FVector ReferencePosition, struct TArray<struct FVertexID>& OutNewExtendedVertexIDs); // Offset: 0x10117dbe4 // Return & Params: Num(4) Size(0x30)

	// Object Name: Function EditableMesh.EditableMesh.ExtendEdges
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void ExtendEdges(struct TArray<struct FEdgeID>& EdgeIDs, bool bWeldNeighbors, struct TArray<struct FEdgeID>& OutNewExtendedEdgeIDs); // Offset: 0x10117dd74 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function EditableMesh.EditableMesh.EndModification
	// Flags: [Final|Native|Public|BlueprintCallable]
	void EndModification(bool bFromUndo); // Offset: 0x101182b3c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function EditableMesh.EditableMesh.DeleteVertexInstances
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void DeleteVertexInstances(struct TArray<struct FVertexInstanceID>& VertexInstanceIDsToDelete, bool bDeleteOrphanedVertices); // Offset: 0x10117efdc // Return & Params: Num(2) Size(0x11)

	// Object Name: Function EditableMesh.EditableMesh.DeleteVertexAndConnectedEdgesAndPolygons
	// Flags: [Final|Native|Public|BlueprintCallable]
	void DeleteVertexAndConnectedEdgesAndPolygons(struct FVertexID VertexID, bool bDeleteOrphanedEdges, bool bDeleteOrphanedVertices, bool bDeleteOrphanedVertexInstances, bool bDeleteEmptyPolygonGroups); // Offset: 0x10117f15c // Return & Params: Num(5) Size(0x8)

	// Object Name: Function EditableMesh.EditableMesh.DeletePolygons
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void DeletePolygons(struct TArray<struct FPolygonID>& PolygonIDsToDelete, bool bDeleteOrphanedEdges, bool bDeleteOrphanedVertices, bool bDeleteOrphanedVertexInstances, bool bDeleteEmptyPolygonGroups); // Offset: 0x10117e6f0 // Return & Params: Num(5) Size(0x14)

	// Object Name: Function EditableMesh.EditableMesh.DeletePolygonGroups
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void DeletePolygonGroups(struct TArray<struct FPolygonGroupID>& PolygonGroupIDs); // Offset: 0x10117d0b0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function EditableMesh.EditableMesh.DeleteOrphanVertices
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void DeleteOrphanVertices(struct TArray<struct FVertexID>& VertexIDsToDelete); // Offset: 0x10117f0c4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function EditableMesh.EditableMesh.DeleteEdges
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void DeleteEdges(struct TArray<struct FEdgeID>& EdgeIDsToDelete, bool bDeleteOrphanedVertices); // Offset: 0x10117eef4 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function EditableMesh.EditableMesh.DeleteEdgeAndConnectedPolygons
	// Flags: [Final|Native|Public|BlueprintCallable]
	void DeleteEdgeAndConnectedPolygons(struct FEdgeID EdgeID, bool bDeleteOrphanedEdges, bool bDeleteOrphanedVertices, bool bDeleteOrphanedVertexInstances, bool bDeleteEmptyPolygonGroups); // Offset: 0x10117f330 // Return & Params: Num(5) Size(0x8)

	// Object Name: Function EditableMesh.EditableMesh.CreateVertices
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void CreateVertices(struct TArray<struct FVertexToCreate>& VerticesToCreate, struct TArray<struct FVertexID>& OutNewVertexIDs); // Offset: 0x10117ece4 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function EditableMesh.EditableMesh.CreateVertexInstances
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void CreateVertexInstances(struct TArray<struct FVertexInstanceToCreate>& VertexInstancesToCreate, struct TArray<struct FVertexInstanceID>& OutNewVertexInstanceIDs); // Offset: 0x10117ebb8 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function EditableMesh.EditableMesh.CreatePolygons
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void CreatePolygons(struct TArray<struct FPolygonToCreate>& PolygonsToCreate, struct TArray<struct FPolygonID>& OutNewPolygonIDs, struct TArray<struct FEdgeID>& OutNewEdgeIDs); // Offset: 0x10117e8d0 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function EditableMesh.EditableMesh.CreatePolygonGroups
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void CreatePolygonGroups(struct TArray<struct FPolygonGroupToCreate>& PolygonGroupsToCreate, struct TArray<struct FPolygonGroupID>& OutNewPolygonGroupIDs); // Offset: 0x10117d148 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function EditableMesh.EditableMesh.CreateMissingPolygonPerimeterEdges
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void CreateMissingPolygonPerimeterEdges(struct FPolygonID PolygonID, struct TArray<struct FEdgeID>& OutNewEdgeIDs); // Offset: 0x10117f8d0 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function EditableMesh.EditableMesh.CreateEmptyVertexRange
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void CreateEmptyVertexRange(int32_t NumVerticesToCreate, struct TArray<struct FVertexID>& OutNewVertexIDs); // Offset: 0x10117ee14 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function EditableMesh.EditableMesh.CreateEdges
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void CreateEdges(struct TArray<struct FEdgeToCreate>& EdgesToCreate, struct TArray<struct FEdgeID>& OutNewEdgeIDs); // Offset: 0x10117ea8c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function EditableMesh.EditableMesh.ComputePolygonsSharedEdges
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void ComputePolygonsSharedEdges(struct TArray<struct FPolygonID>& PolygonIDs, struct TArray<struct FEdgeID>& OutSharedEdgeIDs); // Offset: 0x10117ffe8 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function EditableMesh.EditableMesh.ComputePolygonPlane
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FPlane ComputePolygonPlane(struct FPolygonID PolygonID); // Offset: 0x101180274 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function EditableMesh.EditableMesh.ComputePolygonNormal
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FVector ComputePolygonNormal(struct FPolygonID PolygonID); // Offset: 0x1011801d8 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function EditableMesh.EditableMesh.ComputePolygonCenter
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FVector ComputePolygonCenter(struct FPolygonID PolygonID); // Offset: 0x101180318 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function EditableMesh.EditableMesh.ComputeBoundingBoxAndSphere
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FBoxSphereBounds ComputeBoundingBoxAndSphere(); // Offset: 0x1011803b4 // Return & Params: Num(1) Size(0x1c)

	// Object Name: Function EditableMesh.EditableMesh.ComputeBoundingBox
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FBox ComputeBoundingBox(); // Offset: 0x101180400 // Return & Params: Num(1) Size(0x1c)

	// Object Name: Function EditableMesh.EditableMesh.CommitInstance
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UEditableMesh* CommitInstance(struct UPrimitiveComponent* ComponentToInstanceTo); // Offset: 0x101182a34 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function EditableMesh.EditableMesh.Commit
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Commit(); // Offset: 0x101182ac0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function EditableMesh.EditableMesh.ChangePolygonsVertexInstances
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void ChangePolygonsVertexInstances(struct TArray<struct FChangeVertexInstancesForPolygon>& VertexInstancesForPolygons); // Offset: 0x10117e2f0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function EditableMesh.EditableMesh.BevelPolygons
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void BevelPolygons(struct TArray<struct FPolygonID>& PolygonIDs, float BevelFixedDistance, float BevelProgressTowardCenter, struct TArray<struct FPolygonID>& OutNewCenterPolygonIDs, struct TArray<struct FPolygonID>& OutNewSidePolygonIDs); // Offset: 0x10117d7e0 // Return & Params: Num(5) Size(0x38)

	// Object Name: Function EditableMesh.EditableMesh.AssignPolygonsToPolygonGroups
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void AssignPolygonsToPolygonGroups(struct TArray<struct FPolygonGroupForPolygon>& PolygonGroupForPolygons, bool bDeleteOrphanedPolygonGroups); // Offset: 0x10117cfc8 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function EditableMesh.EditableMesh.AnyChangesToUndo
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool AnyChangesToUndo(); // Offset: 0x1011818b0 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class EditableMesh.EditableMeshFactory
// Size: 0x28 // Inherited bytes: 0x28
struct UEditableMeshFactory : UObject {
	// Functions

	// Object Name: Function EditableMesh.EditableMeshFactory.MakeEditableMesh
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UEditableMesh* MakeEditableMesh(struct UPrimitiveComponent* PrimitiveComponent, int32_t LODIndex); // Offset: 0x101187d04 // Return & Params: Num(3) Size(0x18)
};

// Object Name: Class EditableMesh.EditableStaticMeshAdapter
// Size: 0xe0 // Inherited bytes: 0x28
struct UEditableStaticMeshAdapter : UEditableMeshAdapter {
	// Fields
	struct UStaticMesh* StaticMesh; // Offset: 0x28 // Size: 0x08
	struct UStaticMesh* OriginalStaticMesh; // Offset: 0x30 // Size: 0x08
	int32_t StaticMeshLODIndex; // Offset: 0x38 // Size: 0x04
	char pad_0x3C[0xa4]; // Offset: 0x3c // Size: 0xa4
};

