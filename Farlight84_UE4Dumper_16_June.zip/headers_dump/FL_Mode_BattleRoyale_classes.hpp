#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass FL_Mode_BattleRoyale.FL_Mode_BattleRoyale_C
// Size: 0x28 // Inherited bytes: 0x28
struct UFL_Mode_BattleRoyale_C : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function FL_Mode_BattleRoyale.FL_Mode_BattleRoyale_C.[A]PersonalRank
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void [A]PersonalRank(struct FString PlayerId, struct UObject* __WorldContext, int32_t& OutValue); // Offset: 0x102f8211c // Return & Params: Num(3) Size(0x1c)

	// Object Name: Function FL_Mode_BattleRoyale.FL_Mode_BattleRoyale_C.[A]SideRank
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void [A]SideRank(struct FString Side, struct UObject* __WorldContext, int32_t& OutValue); // Offset: 0x102f8211c // Return & Params: Num(3) Size(0x1c)

	// Object Name: Function FL_Mode_BattleRoyale.FL_Mode_BattleRoyale_C.[A]SideAced
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void [A]SideAced(struct FString SideName, struct UObject* __WorldContext, bool& OutValue); // Offset: 0x102f8211c // Return & Params: Num(3) Size(0x19)

	// Object Name: Function FL_Mode_BattleRoyale.FL_Mode_BattleRoyale_C.[s]UpdateTeamCountMax
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	int32_t [s]UpdateTeamCountMax(struct UObject* __WorldContext); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0xc)

	// Object Name: Function FL_Mode_BattleRoyale.FL_Mode_BattleRoyale_C.OutputLog
	// Flags: [Static|Public|BlueprintCallable|BlueprintEvent]
	void OutputLog(enum class E_BattleLog_BattleRoyale LogType, struct TMap<struct FString, struct FString> InputPin, struct UObject* __WorldContext); // Offset: 0x102f8211c // Return & Params: Num(3) Size(0x60)
};

