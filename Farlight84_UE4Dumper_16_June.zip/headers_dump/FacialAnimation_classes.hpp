#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class FacialAnimation.AudioCurveSourceComponent
// Size: 0x970 // Inherited bytes: 0x930
struct UAudioCurveSourceComponent : UAudioComponent {
	// Fields
	struct FName CurveSourceBindingName; // Offset: 0x930 // Size: 0x08
	float CurveSyncOffset; // Offset: 0x938 // Size: 0x04
	char pad_0x93C[0x34]; // Offset: 0x93c // Size: 0x34
};

