#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class FieldSystemEngine.FieldSystemActor
// Size: 0x230 // Inherited bytes: 0x228
struct AFieldSystemActor : AActor {
	// Fields
	struct UFieldSystemComponent* FieldSystemComponent; // Offset: 0x228 // Size: 0x08
};

// Object Name: Class FieldSystemEngine.FieldSystem
// Size: 0x38 // Inherited bytes: 0x28
struct UFieldSystem : UObject {
	// Fields
	char pad_0x28[0x10]; // Offset: 0x28 // Size: 0x10
};

// Object Name: Class FieldSystemEngine.FieldSystemComponent
// Size: 0x5b0 // Inherited bytes: 0x570
struct UFieldSystemComponent : UPrimitiveComponent {
	// Fields
	struct UFieldSystem* FieldSystem; // Offset: 0x570 // Size: 0x08
	char pad_0x578[0x10]; // Offset: 0x578 // Size: 0x10
	struct TArray<struct TSoftObjectPtr<AChaosSolverActor>> SupportedSolvers; // Offset: 0x588 // Size: 0x10
	char pad_0x598[0x18]; // Offset: 0x598 // Size: 0x18

	// Functions

	// Object Name: Function FieldSystemEngine.FieldSystemComponent.ResetFieldSystem
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ResetFieldSystem(); // Offset: 0x104d7de4c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function FieldSystemEngine.FieldSystemComponent.ApplyUniformVectorFalloffForce
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void ApplyUniformVectorFalloffForce(bool Enabled, struct FVector Position, struct FVector Direction, float Radius, float Magnitude); // Offset: 0x104d7e150 // Return & Params: Num(5) Size(0x24)

	// Object Name: Function FieldSystemEngine.FieldSystemComponent.ApplyStrainField
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void ApplyStrainField(bool Enabled, struct FVector Position, float Radius, float Magnitude, int32_t Iterations); // Offset: 0x104d7dfb8 // Return & Params: Num(5) Size(0x1c)

	// Object Name: Function FieldSystemEngine.FieldSystemComponent.ApplyStayDynamicField
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void ApplyStayDynamicField(bool Enabled, struct FVector Position, float Radius); // Offset: 0x104d7e54c // Return & Params: Num(3) Size(0x14)

	// Object Name: Function FieldSystemEngine.FieldSystemComponent.ApplyRadialVectorFalloffForce
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void ApplyRadialVectorFalloffForce(bool Enabled, struct FVector Position, float Radius, float Magnitude); // Offset: 0x104d7e2e4 // Return & Params: Num(4) Size(0x18)

	// Object Name: Function FieldSystemEngine.FieldSystemComponent.ApplyRadialForce
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void ApplyRadialForce(bool Enabled, struct FVector Position, float Magnitude); // Offset: 0x104d7e438 // Return & Params: Num(3) Size(0x14)

	// Object Name: Function FieldSystemEngine.FieldSystemComponent.ApplyPhysicsField
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ApplyPhysicsField(bool Enabled, enum class EFieldPhysicsType Target, struct UFieldSystemMetaData* MetaData, struct UFieldNodeBase* Field); // Offset: 0x104d7de60 // Return & Params: Num(4) Size(0x18)

	// Object Name: Function FieldSystemEngine.FieldSystemComponent.ApplyLinearForce
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void ApplyLinearForce(bool Enabled, struct FVector Direction, float Magnitude); // Offset: 0x104d7e660 // Return & Params: Num(3) Size(0x14)

	// Object Name: Function FieldSystemEngine.FieldSystemComponent.AddFieldCommand
	// Flags: [Final|Native|Public|BlueprintCallable]
	void AddFieldCommand(bool Enabled, enum class EFieldPhysicsType Target, struct UFieldSystemMetaData* MetaData, struct UFieldNodeBase* Field); // Offset: 0x104d7dcf4 // Return & Params: Num(4) Size(0x18)
};

// Object Name: Class FieldSystemEngine.FieldSystemMetaData
// Size: 0xb0 // Inherited bytes: 0xb0
struct UFieldSystemMetaData : UActorComponent {
};

// Object Name: Class FieldSystemEngine.FieldSystemMetaDataIteration
// Size: 0xb8 // Inherited bytes: 0xb0
struct UFieldSystemMetaDataIteration : UFieldSystemMetaData {
	// Fields
	int32_t Iterations; // Offset: 0xb0 // Size: 0x04
	char pad_0xB4[0x4]; // Offset: 0xb4 // Size: 0x04

	// Functions

	// Object Name: Function FieldSystemEngine.FieldSystemMetaDataIteration.SetMetaDataIteration
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	struct UFieldSystemMetaDataIteration* SetMetaDataIteration(int32_t Iterations); // Offset: 0x104d7efe4 // Return & Params: Num(2) Size(0x10)
};

// Object Name: Class FieldSystemEngine.FieldSystemMetaDataProcessingResolution
// Size: 0xb8 // Inherited bytes: 0xb0
struct UFieldSystemMetaDataProcessingResolution : UFieldSystemMetaData {
	// Fields
	enum class EFieldResolutionType ResolutionType; // Offset: 0xb0 // Size: 0x01
	char pad_0xB1[0x7]; // Offset: 0xb1 // Size: 0x07

	// Functions

	// Object Name: Function FieldSystemEngine.FieldSystemMetaDataProcessingResolution.SetMetaDataaProcessingResolutionType
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	struct UFieldSystemMetaDataProcessingResolution* SetMetaDataaProcessingResolutionType(enum class EFieldResolutionType ResolutionType); // Offset: 0x104d7f380 // Return & Params: Num(2) Size(0x10)
};

// Object Name: Class FieldSystemEngine.FieldNodeBase
// Size: 0xb0 // Inherited bytes: 0xb0
struct UFieldNodeBase : UActorComponent {
};

// Object Name: Class FieldSystemEngine.FieldNodeInt
// Size: 0xb0 // Inherited bytes: 0xb0
struct UFieldNodeInt : UFieldNodeBase {
};

// Object Name: Class FieldSystemEngine.FieldNodeFloat
// Size: 0xb0 // Inherited bytes: 0xb0
struct UFieldNodeFloat : UFieldNodeBase {
};

// Object Name: Class FieldSystemEngine.FieldNodeVector
// Size: 0xb0 // Inherited bytes: 0xb0
struct UFieldNodeVector : UFieldNodeBase {
};

// Object Name: Class FieldSystemEngine.UniformInteger
// Size: 0xb8 // Inherited bytes: 0xb0
struct UUniformInteger : UFieldNodeInt {
	// Fields
	int32_t Magnitude; // Offset: 0xb0 // Size: 0x04
	char pad_0xB4[0x4]; // Offset: 0xb4 // Size: 0x04

	// Functions

	// Object Name: Function FieldSystemEngine.UniformInteger.SetUniformInteger
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	struct UUniformInteger* SetUniformInteger(int32_t Magnitude); // Offset: 0x104d7fdbc // Return & Params: Num(2) Size(0x10)
};

// Object Name: Class FieldSystemEngine.RadialIntMask
// Size: 0xd0 // Inherited bytes: 0xb0
struct URadialIntMask : UFieldNodeInt {
	// Fields
	float Radius; // Offset: 0xb0 // Size: 0x04
	struct FVector Position; // Offset: 0xb4 // Size: 0x0c
	int32_t InteriorValue; // Offset: 0xc0 // Size: 0x04
	int32_t ExteriorValue; // Offset: 0xc4 // Size: 0x04
	enum class ESetMaskConditionType SetMaskCondition; // Offset: 0xc8 // Size: 0x01
	char pad_0xC9[0x7]; // Offset: 0xc9 // Size: 0x07

	// Functions

	// Object Name: Function FieldSystemEngine.RadialIntMask.SetRadialIntMask
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	struct URadialIntMask* SetRadialIntMask(float Radius, struct FVector Position, int32_t InteriorValue, int32_t ExteriorValue, enum class ESetMaskConditionType SetMaskConditionIn); // Offset: 0x104d8016c // Return & Params: Num(6) Size(0x28)
};

// Object Name: Class FieldSystemEngine.UniformScalar
// Size: 0xb8 // Inherited bytes: 0xb0
struct UUniformScalar : UFieldNodeFloat {
	// Fields
	float Magnitude; // Offset: 0xb0 // Size: 0x04
	char pad_0xB4[0x4]; // Offset: 0xb4 // Size: 0x04

	// Functions

	// Object Name: Function FieldSystemEngine.UniformScalar.SetUniformScalar
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	struct UUniformScalar* SetUniformScalar(float Magnitude); // Offset: 0x104d80630 // Return & Params: Num(2) Size(0x10)
};

// Object Name: Class FieldSystemEngine.RadialFalloff
// Size: 0xd8 // Inherited bytes: 0xb0
struct URadialFalloff : UFieldNodeFloat {
	// Fields
	float Magnitude; // Offset: 0xb0 // Size: 0x04
	float MinRange; // Offset: 0xb4 // Size: 0x04
	float MaxRange; // Offset: 0xb8 // Size: 0x04
	float Default; // Offset: 0xbc // Size: 0x04
	float Radius; // Offset: 0xc0 // Size: 0x04
	struct FVector Position; // Offset: 0xc4 // Size: 0x0c
	enum class EFieldFalloffType Falloff; // Offset: 0xd0 // Size: 0x01
	char pad_0xD1[0x7]; // Offset: 0xd1 // Size: 0x07

	// Functions

	// Object Name: Function FieldSystemEngine.RadialFalloff.SetRadialFalloff
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	struct URadialFalloff* SetRadialFalloff(float Magnitude, float MinRange, float MaxRange, float Default, float Radius, struct FVector Position, enum class EFieldFalloffType Falloff); // Offset: 0x104d809e4 // Return & Params: Num(8) Size(0x30)
};

// Object Name: Class FieldSystemEngine.PlaneFalloff
// Size: 0xe0 // Inherited bytes: 0xb0
struct UPlaneFalloff : UFieldNodeFloat {
	// Fields
	float Magnitude; // Offset: 0xb0 // Size: 0x04
	float MinRange; // Offset: 0xb4 // Size: 0x04
	float MaxRange; // Offset: 0xb8 // Size: 0x04
	float Default; // Offset: 0xbc // Size: 0x04
	float Distance; // Offset: 0xc0 // Size: 0x04
	struct FVector Position; // Offset: 0xc4 // Size: 0x0c
	struct FVector Normal; // Offset: 0xd0 // Size: 0x0c
	enum class EFieldFalloffType Falloff; // Offset: 0xdc // Size: 0x01
	char pad_0xDD[0x3]; // Offset: 0xdd // Size: 0x03

	// Functions

	// Object Name: Function FieldSystemEngine.PlaneFalloff.SetPlaneFalloff
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	struct UPlaneFalloff* SetPlaneFalloff(float Magnitude, float MinRange, float MaxRange, float Default, float Distance, struct FVector Position, struct FVector Normal, enum class EFieldFalloffType Falloff); // Offset: 0x104d80f44 // Return & Params: Num(9) Size(0x38)
};

// Object Name: Class FieldSystemEngine.BoxFalloff
// Size: 0x100 // Inherited bytes: 0xb0
struct UBoxFalloff : UFieldNodeFloat {
	// Fields
	float Magnitude; // Offset: 0xb0 // Size: 0x04
	float MinRange; // Offset: 0xb4 // Size: 0x04
	float MaxRange; // Offset: 0xb8 // Size: 0x04
	float Default; // Offset: 0xbc // Size: 0x04
	struct FTransform Transform; // Offset: 0xc0 // Size: 0x30
	enum class EFieldFalloffType Falloff; // Offset: 0xf0 // Size: 0x01
	char pad_0xF1[0xf]; // Offset: 0xf1 // Size: 0x0f

	// Functions

	// Object Name: Function FieldSystemEngine.BoxFalloff.SetBoxFalloff
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	struct UBoxFalloff* SetBoxFalloff(float Magnitude, float MinRange, float MaxRange, float Default, struct FTransform Transform, enum class EFieldFalloffType Falloff); // Offset: 0x104d814f4 // Return & Params: Num(7) Size(0x50)
};

// Object Name: Class FieldSystemEngine.NoiseField
// Size: 0xf0 // Inherited bytes: 0xb0
struct UNoiseField : UFieldNodeFloat {
	// Fields
	float MinRange; // Offset: 0xb0 // Size: 0x04
	float MaxRange; // Offset: 0xb4 // Size: 0x04
	char pad_0xB8[0x8]; // Offset: 0xb8 // Size: 0x08
	struct FTransform Transform; // Offset: 0xc0 // Size: 0x30

	// Functions

	// Object Name: Function FieldSystemEngine.NoiseField.SetNoiseField
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	struct UNoiseField* SetNoiseField(float MinRange, float MaxRange, struct FTransform Transform); // Offset: 0x104d81a70 // Return & Params: Num(4) Size(0x48)
};

// Object Name: Class FieldSystemEngine.UniformVector
// Size: 0xc0 // Inherited bytes: 0xb0
struct UUniformVector : UFieldNodeVector {
	// Fields
	float Magnitude; // Offset: 0xb0 // Size: 0x04
	struct FVector Direction; // Offset: 0xb4 // Size: 0x0c

	// Functions

	// Object Name: Function FieldSystemEngine.UniformVector.SetUniformVector
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	struct UUniformVector* SetUniformVector(float Magnitude, struct FVector Direction); // Offset: 0x104d81f34 // Return & Params: Num(3) Size(0x18)
};

// Object Name: Class FieldSystemEngine.RadialVector
// Size: 0xc0 // Inherited bytes: 0xb0
struct URadialVector : UFieldNodeVector {
	// Fields
	float Magnitude; // Offset: 0xb0 // Size: 0x04
	struct FVector Position; // Offset: 0xb4 // Size: 0x0c

	// Functions

	// Object Name: Function FieldSystemEngine.RadialVector.SetRadialVector
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	struct URadialVector* SetRadialVector(float Magnitude, struct FVector Position); // Offset: 0x104d82328 // Return & Params: Num(3) Size(0x18)
};

// Object Name: Class FieldSystemEngine.RandomVector
// Size: 0xb8 // Inherited bytes: 0xb0
struct URandomVector : UFieldNodeVector {
	// Fields
	float Magnitude; // Offset: 0xb0 // Size: 0x04
	char pad_0xB4[0x4]; // Offset: 0xb4 // Size: 0x04

	// Functions

	// Object Name: Function FieldSystemEngine.RandomVector.SetRandomVector
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	struct URandomVector* SetRandomVector(float Magnitude); // Offset: 0x104d8271c // Return & Params: Num(2) Size(0x10)
};

// Object Name: Class FieldSystemEngine.OperatorField
// Size: 0xd0 // Inherited bytes: 0xb0
struct UOperatorField : UFieldNodeBase {
	// Fields
	float Magnitude; // Offset: 0xb0 // Size: 0x04
	char pad_0xB4[0x4]; // Offset: 0xb4 // Size: 0x04
	struct UFieldNodeBase* RightField; // Offset: 0xb8 // Size: 0x08
	struct UFieldNodeBase* LeftField; // Offset: 0xc0 // Size: 0x08
	enum class EFieldOperationType Operation; // Offset: 0xc8 // Size: 0x01
	char pad_0xC9[0x7]; // Offset: 0xc9 // Size: 0x07

	// Functions

	// Object Name: Function FieldSystemEngine.OperatorField.SetOperatorField
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	struct UOperatorField* SetOperatorField(float Magnitude, struct UFieldNodeBase* RightField, struct UFieldNodeBase* LeftField, enum class EFieldOperationType Operation); // Offset: 0x104d82ad0 // Return & Params: Num(5) Size(0x28)
};

// Object Name: Class FieldSystemEngine.ToIntegerField
// Size: 0xb8 // Inherited bytes: 0xb0
struct UToIntegerField : UFieldNodeInt {
	// Fields
	struct UFieldNodeFloat* FloatField; // Offset: 0xb0 // Size: 0x08

	// Functions

	// Object Name: Function FieldSystemEngine.ToIntegerField.SetToIntegerField
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	struct UToIntegerField* SetToIntegerField(struct UFieldNodeFloat* FloatField); // Offset: 0x104d82f54 // Return & Params: Num(2) Size(0x10)
};

// Object Name: Class FieldSystemEngine.ToFloatField
// Size: 0xb8 // Inherited bytes: 0xb0
struct UToFloatField : UFieldNodeFloat {
	// Fields
	struct UFieldNodeInt* IntField; // Offset: 0xb0 // Size: 0x08

	// Functions

	// Object Name: Function FieldSystemEngine.ToFloatField.SetToFloatField
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	struct UToFloatField* SetToFloatField(struct UFieldNodeInt* IntegerField); // Offset: 0x104d83304 // Return & Params: Num(2) Size(0x10)
};

// Object Name: Class FieldSystemEngine.CullingField
// Size: 0xc8 // Inherited bytes: 0xb0
struct UCullingField : UFieldNodeBase {
	// Fields
	struct UFieldNodeBase* Culling; // Offset: 0xb0 // Size: 0x08
	struct UFieldNodeBase* Field; // Offset: 0xb8 // Size: 0x08
	enum class EFieldCullingOperationType Operation; // Offset: 0xc0 // Size: 0x01
	char pad_0xC1[0x7]; // Offset: 0xc1 // Size: 0x07

	// Functions

	// Object Name: Function FieldSystemEngine.CullingField.SetCullingField
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	struct UCullingField* SetCullingField(struct UFieldNodeBase* Culling, struct UFieldNodeBase* Field, enum class EFieldCullingOperationType Operation); // Offset: 0x104d836b4 // Return & Params: Num(4) Size(0x20)
};

// Object Name: Class FieldSystemEngine.ReturnResultsTerminal
// Size: 0xb0 // Inherited bytes: 0xb0
struct UReturnResultsTerminal : UFieldNodeBase {
	// Functions

	// Object Name: Function FieldSystemEngine.ReturnResultsTerminal.SetReturnResultsTerminal
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	struct UReturnResultsTerminal* SetReturnResultsTerminal(); // Offset: 0x104d83aec // Return & Params: Num(1) Size(0x8)
};

