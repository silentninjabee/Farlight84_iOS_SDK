#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass GA_PoisonCircleDamage.GA_PoisonCircleDamage_C
// Size: 0x410 // Inherited bytes: 0x400
struct UGA_PoisonCircleDamage_C : UGameplayAbility {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x400 // Size: 0x08
	struct FActiveGameplayEffectHandle GE_Handle; // Offset: 0x408 // Size: 0x08

	// Functions

	// Object Name: Function GA_PoisonCircleDamage.GA_PoisonCircleDamage_C.OnFinished_3BE324254553E5A1BFDA9CA16B65FC97
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnFinished_3BE324254553E5A1BFDA9CA16B65FC97(int32_t ActionNumber); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function GA_PoisonCircleDamage.GA_PoisonCircleDamage_C.OnPerformAction_3BE324254553E5A1BFDA9CA16B65FC97
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnPerformAction_3BE324254553E5A1BFDA9CA16B65FC97(int32_t ActionNumber); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function GA_PoisonCircleDamage.GA_PoisonCircleDamage_C.OnFinish_E1A2BBC649F292D42CB5B98AC3109144
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnFinish_E1A2BBC649F292D42CB5B98AC3109144(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function GA_PoisonCircleDamage.GA_PoisonCircleDamage_C.K2_ActivateAbility
	// Flags: [Event|Protected|BlueprintEvent]
	void K2_ActivateAbility(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function GA_PoisonCircleDamage.GA_PoisonCircleDamage_C.K2_OnEndAbility
	// Flags: [Event|Protected|BlueprintEvent]
	void K2_OnEndAbility(bool bWasCancelled); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function GA_PoisonCircleDamage.GA_PoisonCircleDamage_C.ExecuteUbergraph_GA_PoisonCircleDamage
	// Flags: [Final|UbergraphFunction|HasDefaults]
	void ExecuteUbergraph_GA_PoisonCircleDamage(int32_t EntryPoint); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x4)
};

