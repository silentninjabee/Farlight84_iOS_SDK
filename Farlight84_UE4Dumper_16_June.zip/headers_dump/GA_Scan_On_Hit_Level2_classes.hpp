#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass GA_Scan_On_Hit_Level2.GA_Scan_On_Hit_Level2_C
// Size: 0x490 // Inherited bytes: 0x490
struct UGA_Scan_On_Hit_Level2_C : UWeaponScanAbility {
};

