#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass GeneralFunctionLibrary_Map.GeneralFunctionLibrary_Map_C
// Size: 0x28 // Inherited bytes: 0x28
struct UGeneralFunctionLibrary_Map_C : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function GeneralFunctionLibrary_Map.GeneralFunctionLibrary_Map_C.[ C]Debug Drawing Poison Circle
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void [ C]Debug Drawing Poison Circle(struct TArray<struct FVector>& CenterArr, struct UObject* __WorldContext1, struct TArray<float>& Radius, struct UObject* __WorldContext); // Offset: 0x102f8211c // Return & Params: Num(4) Size(0x30)

	// Object Name: Function GeneralFunctionLibrary_Map.GeneralFunctionLibrary_Map_C.[ C]Get Viewport Focused Character
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void [ C]Get Viewport Focused Character(struct UObject* WorldContextObject, struct UObject* __WorldContext, struct ASolarCharacter*& Character); // Offset: 0x102f8211c // Return & Params: Num(3) Size(0x18)

	// Object Name: Function GeneralFunctionLibrary_Map.GeneralFunctionLibrary_Map_C.CircularInterceptPoint
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void CircularInterceptPoint(struct FVector2D CenterPoint, float LargeRadius, float SmallRadius, float TruncationAngle, struct UObject* __WorldContext, struct FVector2D& LargePointStart, struct FVector2D& LargePointEnd, struct FVector2D& SmallPointStart, struct FVector2D& SmallPointEnd); // Offset: 0x102f8211c // Return & Params: Num(9) Size(0x40)

	// Object Name: Function GeneralFunctionLibrary_Map.GeneralFunctionLibrary_Map_C.
	// Flags: [Static|Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void (bool Show, struct UObject* WorldContextObject, struct UObject* __WorldContext); // Offset: 0x102f8211c // Return & Params: Num(3) Size(0x18)

	// Object Name: Function GeneralFunctionLibrary_Map.GeneralFunctionLibrary_Map_C.[ S]Get Point On Line
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void [ S]Get Point On Line(struct TArray<struct FVector2D>& Sample, struct FVector2D StartPoint, float Length, struct UObject* __WorldContext, struct FVector2D& TargetPoint); // Offset: 0x102f8211c // Return & Params: Num(5) Size(0x30)

	// Object Name: Function GeneralFunctionLibrary_Map.GeneralFunctionLibrary_Map_C.[S]Create Air Drop by Out Come ID Auto Trace Ground Height
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void [S]Create Air Drop by Out Come ID Auto Trace Ground Height(struct UObject* WorldContextObject, struct FTransform& , struct ASolarTreasureBoxSpawner* , int32_t , int32_t ChestID, int32_t , bool bUseAirship, struct UObject* __WorldContext); // Offset: 0x102f8211c // Return & Params: Num(8) Size(0x60)

	// Object Name: Function GeneralFunctionLibrary_Map.GeneralFunctionLibrary_Map_C.[S]CreateAirDropByItemID_AutoTraceGroundHeight
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void [S]CreateAirDropByItemID_AutoTraceGroundHeight(struct UObject* WorldContextObject, struct FTransform& , struct ASolarTreasureBoxSpawner* , struct TArray<struct FSolarItemData>& , int32_t ChestID, int32_t , struct UObject* __WorldContext); // Offset: 0x102f8211c // Return & Params: Num(7) Size(0x68)
};

