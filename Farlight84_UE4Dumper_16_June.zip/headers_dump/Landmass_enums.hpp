#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum Landmass.EBrushFalloffMode
enum class EBrushFalloffMode : uint8 {
	Angle = 0,
	Width = 1,
	EBrushFalloffMode_MAX = 2
};

// Object Name: Enum Landmass.EBrushBlendType
enum class EBrushBlendType : uint8 {
	AlphaBlend = 0,
	Min = 1,
	Max = 2,
	Additive = 3
};

