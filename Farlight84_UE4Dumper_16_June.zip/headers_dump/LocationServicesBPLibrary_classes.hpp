#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class LocationServicesBPLibrary.LocationServices
// Size: 0x28 // Inherited bytes: 0x28
struct ULocationServices : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function LocationServicesBPLibrary.LocationServices.StopLocationServices
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool StopLocationServices(); // Offset: 0x101d5ee24 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LocationServicesBPLibrary.LocationServices.StartLocationServices
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool StartLocationServices(); // Offset: 0x101d5ee58 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LocationServicesBPLibrary.LocationServices.IsLocationAccuracyAvailable
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsLocationAccuracyAvailable(enum class ELocationAccuracy Accuracy); // Offset: 0x101d5ed28 // Return & Params: Num(2) Size(0x2)

	// Object Name: Function LocationServicesBPLibrary.LocationServices.InitLocationServices
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool InitLocationServices(enum class ELocationAccuracy Accuracy, float UpdateFrequency, float MinDistanceFilter); // Offset: 0x101d5ee8c // Return & Params: Num(4) Size(0xd)

	// Object Name: Function LocationServicesBPLibrary.LocationServices.GetLocationServicesImpl
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct ULocationServicesImpl* GetLocationServicesImpl(); // Offset: 0x101d5ed04 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function LocationServicesBPLibrary.LocationServices.GetLastKnownLocation
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FLocationServicesData GetLastKnownLocation(); // Offset: 0x101d5edd8 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function LocationServicesBPLibrary.LocationServices.AreLocationServicesEnabled
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool AreLocationServicesEnabled(); // Offset: 0x101d5eda4 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class LocationServicesBPLibrary.LocationServicesImpl
// Size: 0x38 // Inherited bytes: 0x28
struct ULocationServicesImpl : UObject {
	// Fields
	struct FMulticastInlineDelegate OnLocationChanged; // Offset: 0x28 // Size: 0x10
};

