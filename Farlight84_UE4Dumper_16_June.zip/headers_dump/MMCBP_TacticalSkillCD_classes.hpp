#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass MMCBP_TacticalSkillCD.MMCBP_TacticalSkillCD_C
// Size: 0x40 // Inherited bytes: 0x40
struct UMMCBP_TacticalSkillCD_C : UMMC_GenericCooldown {
};

