#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class MeshDescription.MeshDescription
// Size: 0x28 // Inherited bytes: 0x28
struct UMeshDescription : UObject {
};

// Object Name: Class MeshDescription.MeshDescriptionBase
// Size: 0x390 // Inherited bytes: 0x28
struct UMeshDescriptionBase : UObject {
	// Fields
	char pad_0x28[0x368]; // Offset: 0x28 // Size: 0x368

	// Functions

	// Object Name: Function MeshDescription.MeshDescriptionBase.SetVertexPosition
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void SetVertexPosition(struct FVertexID VertexID, struct FVector& Position); // Offset: 0x1040900e4 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function MeshDescription.MeshDescriptionBase.SetPolygonVertexInstance
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPolygonVertexInstance(struct FPolygonID PolygonID, int32_t PerimeterIndex, struct FVertexInstanceID VertexInstanceID); // Offset: 0x10408e4fc // Return & Params: Num(3) Size(0xc)

	// Object Name: Function MeshDescription.MeshDescriptionBase.SetPolygonPolygonGroup
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPolygonPolygonGroup(struct FPolygonID PolygonID, struct FPolygonGroupID PolygonGroupID); // Offset: 0x10408e420 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function MeshDescription.MeshDescriptionBase.ReversePolygonFacing
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ReversePolygonFacing(struct FPolygonID PolygonID); // Offset: 0x10408e398 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MeshDescription.MeshDescriptionBase.ReserveNewVertices
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ReserveNewVertices(int32_t NumberOfNewVertices); // Offset: 0x1040921ec // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MeshDescription.MeshDescriptionBase.ReserveNewVertexInstances
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ReserveNewVertexInstances(int32_t NumberOfNewVertexInstances); // Offset: 0x104091f94 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MeshDescription.MeshDescriptionBase.ReserveNewTriangles
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ReserveNewTriangles(int32_t NumberOfNewTriangles); // Offset: 0x104091814 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MeshDescription.MeshDescriptionBase.ReserveNewPolygons
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ReserveNewPolygons(int32_t NumberOfNewPolygons); // Offset: 0x104091260 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MeshDescription.MeshDescriptionBase.ReserveNewPolygonGroups
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ReserveNewPolygonGroups(int32_t NumberOfNewPolygonGroups); // Offset: 0x104090cac // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MeshDescription.MeshDescriptionBase.ReserveNewEdges
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ReserveNewEdges(int32_t NumberOfNewEdges); // Offset: 0x104091c20 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MeshDescription.MeshDescriptionBase.IsVertexValid
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsVertexValid(struct FVertexID VertexID); // Offset: 0x104092010 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function MeshDescription.MeshDescriptionBase.IsVertexOrphaned
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsVertexOrphaned(struct FVertexID VertexID); // Offset: 0x104090a38 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function MeshDescription.MeshDescriptionBase.IsVertexInstanceValid
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsVertexInstanceValid(struct FVertexInstanceID VertexInstanceID); // Offset: 0x104091c9c // Return & Params: Num(2) Size(0x5)

	// Object Name: Function MeshDescription.MeshDescriptionBase.IsTriangleValid
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsTriangleValid(struct FTriangleID TriangleID); // Offset: 0x1040912dc // Return & Params: Num(2) Size(0x5)

	// Object Name: Function MeshDescription.MeshDescriptionBase.IsTrianglePartOfNgon
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsTrianglePartOfNgon(struct FTriangleID TriangleID); // Offset: 0x10408f450 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function MeshDescription.MeshDescriptionBase.IsPolygonValid
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsPolygonValid(struct FPolygonID PolygonID); // Offset: 0x104090d28 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function MeshDescription.MeshDescriptionBase.IsPolygonGroupValid
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsPolygonGroupValid(struct FPolygonGroupID PolygonGroupID); // Offset: 0x104090ad0 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function MeshDescription.MeshDescriptionBase.IsEmpty
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsEmpty(); // Offset: 0x104092268 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function MeshDescription.MeshDescriptionBase.IsEdgeValid
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsEdgeValid(struct FEdgeID EdgeID); // Offset: 0x104091890 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function MeshDescription.MeshDescriptionBase.IsEdgeInternalToPolygon
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsEdgeInternalToPolygon(struct FEdgeID EdgeID, struct FPolygonID PolygonID); // Offset: 0x10408fae4 // Return & Params: Num(3) Size(0x9)

	// Object Name: Function MeshDescription.MeshDescriptionBase.IsEdgeInternal
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsEdgeInternal(struct FEdgeID EdgeID); // Offset: 0x10408fbc8 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetVertexVertexInstances
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetVertexVertexInstances(struct FVertexID VertexID, struct TArray<struct FVertexInstanceID>& OutVertexInstanceIDs); // Offset: 0x1040906e4 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetVertexPosition
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FVector GetVertexPosition(struct FVertexID VertexID); // Offset: 0x1040901bc // Return & Params: Num(2) Size(0x10)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetVertexPairEdge
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FEdgeID GetVertexPairEdge(struct FVertexID VertexID0, struct FVertexID VertexID1); // Offset: 0x104090954 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetVertexInstanceVertex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FVertexID GetVertexInstanceVertex(struct FVertexInstanceID VertexInstanceID); // Offset: 0x10409004c // Return & Params: Num(2) Size(0x8)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetVertexInstancePairEdge
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FEdgeID GetVertexInstancePairEdge(struct FVertexInstanceID VertexInstanceID0, struct FVertexInstanceID VertexInstanceID1); // Offset: 0x10408ff68 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetVertexInstanceForTriangleVertex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FVertexInstanceID GetVertexInstanceForTriangleVertex(struct FTriangleID TriangleID, struct FVertexID VertexID); // Offset: 0x10408eee4 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetVertexInstanceForPolygonVertex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FVertexInstanceID GetVertexInstanceForPolygonVertex(struct FPolygonID PolygonID, struct FVertexID VertexID); // Offset: 0x10408e618 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetVertexInstanceConnectedTriangles
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetVertexInstanceConnectedTriangles(struct FVertexInstanceID VertexInstanceID, struct TArray<struct FTriangleID>& OutConnectedTriangleIDs); // Offset: 0x10408fe7c // Return & Params: Num(2) Size(0x18)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetVertexInstanceConnectedPolygons
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetVertexInstanceConnectedPolygons(struct FVertexInstanceID VertexInstanceID, struct TArray<struct FPolygonID>& OutConnectedPolygonIDs); // Offset: 0x10408fcf8 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetVertexConnectedTriangles
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetVertexConnectedTriangles(struct FVertexID VertexID, struct TArray<struct FTriangleID>& OutConnectedTriangleIDs); // Offset: 0x104090560 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetVertexConnectedPolygons
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetVertexConnectedPolygons(struct FVertexID VertexID, struct TArray<struct FPolygonID>& OutConnectedPolygonIDs); // Offset: 0x1040903dc // Return & Params: Num(2) Size(0x18)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetVertexConnectedEdges
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetVertexConnectedEdges(struct FVertexID VertexID, struct TArray<struct FEdgeID>& OutEdgeIDs); // Offset: 0x104090868 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetVertexAdjacentVertices
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetVertexAdjacentVertices(struct FVertexID VertexID, struct TArray<struct FVertexID>& OutAdjacentVertexIDs); // Offset: 0x104090258 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetTriangleVertices
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetTriangleVertices(struct FTriangleID TriangleID, struct TArray<struct FVertexID>& OutVertexIDs); // Offset: 0x10408f1a0 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetTriangleVertexInstances
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetTriangleVertexInstances(struct FTriangleID TriangleID, struct TArray<struct FVertexInstanceID>& OutVertexInstanceIDs); // Offset: 0x10408f364 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetTriangleVertexInstance
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FVertexInstanceID GetTriangleVertexInstance(struct FTriangleID TriangleID, int32_t Index); // Offset: 0x10408f28c // Return & Params: Num(3) Size(0xc)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetTrianglePolygonGroup
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FPolygonGroupID GetTrianglePolygonGroup(struct FTriangleID TriangleID); // Offset: 0x10408f4e8 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetTrianglePolygon
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FPolygonID GetTrianglePolygon(struct FTriangleID TriangleID); // Offset: 0x10408f580 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetTriangleEdges
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetTriangleEdges(struct FTriangleID TriangleID, struct TArray<struct FEdgeID>& OutEdgeIDs); // Offset: 0x10408f0b4 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetTriangleAdjacentTriangles
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetTriangleAdjacentTriangles(struct FTriangleID TriangleID, struct TArray<struct FTriangleID>& OutTriangleIDs); // Offset: 0x10408efc8 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetPolygonVertices
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetPolygonVertices(struct FPolygonID PolygonID, struct TArray<struct FVertexID>& OutVertexIDs); // Offset: 0x10408eaf0 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetPolygonVertexInstances
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetPolygonVertexInstances(struct FPolygonID PolygonID, struct TArray<struct FVertexInstanceID>& OutVertexInstanceIDs); // Offset: 0x10408ec74 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetPolygonTriangles
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetPolygonTriangles(struct FPolygonID PolygonID, struct TArray<struct FTriangleID>& OutTriangleIDs); // Offset: 0x10408edf8 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetPolygonPolygonGroup
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FPolygonGroupID GetPolygonPolygonGroup(struct FPolygonID PolygonID); // Offset: 0x10408e6fc // Return & Params: Num(2) Size(0x8)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetPolygonPerimeterEdges
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetPolygonPerimeterEdges(struct FPolygonID PolygonID, struct TArray<struct FEdgeID>& OutEdgeIDs); // Offset: 0x10408ea04 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetPolygonInternalEdges
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetPolygonInternalEdges(struct FPolygonID PolygonID, struct TArray<struct FEdgeID>& OutEdgeIDs); // Offset: 0x10408e918 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetPolygonGroupPolygons
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetPolygonGroupPolygons(struct FPolygonGroupID PolygonGroupID, struct TArray<struct FPolygonID>& OutPolygonIDs); // Offset: 0x10408e224 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetPolygonAdjacentPolygons
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetPolygonAdjacentPolygons(struct FPolygonID PolygonID, struct TArray<struct FPolygonID>& OutPolygonIDs); // Offset: 0x10408e794 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetNumVertexVertexInstances
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetNumVertexVertexInstances(struct FVertexID VertexID); // Offset: 0x10409064c // Return & Params: Num(2) Size(0x8)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetNumVertexInstanceConnectedTriangles
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetNumVertexInstanceConnectedTriangles(struct FVertexInstanceID VertexInstanceID); // Offset: 0x10408fde4 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetNumVertexInstanceConnectedPolygons
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetNumVertexInstanceConnectedPolygons(struct FVertexInstanceID VertexInstanceID); // Offset: 0x10408fc60 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetNumVertexConnectedTriangles
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetNumVertexConnectedTriangles(struct FVertexID VertexID); // Offset: 0x1040904c8 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetNumVertexConnectedPolygons
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetNumVertexConnectedPolygons(struct FVertexID VertexID); // Offset: 0x104090344 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetNumVertexConnectedEdges
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetNumVertexConnectedEdges(struct FVertexID VertexID); // Offset: 0x1040907d0 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetNumPolygonVertices
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetNumPolygonVertices(struct FPolygonID PolygonID); // Offset: 0x10408ebdc // Return & Params: Num(2) Size(0x8)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetNumPolygonTriangles
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetNumPolygonTriangles(struct FPolygonID PolygonID); // Offset: 0x10408ed60 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetNumPolygonInternalEdges
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetNumPolygonInternalEdges(struct FPolygonID PolygonID); // Offset: 0x10408e880 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetNumPolygonGroupPolygons
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetNumPolygonGroupPolygons(struct FPolygonGroupID PolygonGroupID); // Offset: 0x10408e18c // Return & Params: Num(2) Size(0x8)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetNumEdgeConnectedTriangles
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetNumEdgeConnectedTriangles(struct FEdgeID EdgeID); // Offset: 0x10408f960 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetNumEdgeConnectedPolygons
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetNumEdgeConnectedPolygons(struct FEdgeID EdgeID); // Offset: 0x10408f7dc // Return & Params: Num(2) Size(0x8)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetEdgeVertices
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetEdgeVertices(struct FEdgeID EdgeID, struct TArray<struct FVertexID>& OutVertexIDs); // Offset: 0x10408f618 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetEdgeVertex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FVertexID GetEdgeVertex(struct FEdgeID EdgeID, int32_t VertexNumber); // Offset: 0x10408f704 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetEdgeConnectedTriangles
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetEdgeConnectedTriangles(struct FEdgeID EdgeID, struct TArray<struct FTriangleID>& OutConnectedTriangleIDs); // Offset: 0x10408f9f8 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetEdgeConnectedPolygons
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetEdgeConnectedPolygons(struct FEdgeID EdgeID, struct TArray<struct FPolygonID>& OutConnectedPolygonIDs); // Offset: 0x10408f874 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function MeshDescription.MeshDescriptionBase.Empty
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Empty(); // Offset: 0x10409229c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function MeshDescription.MeshDescriptionBase.DeleteVertexInstance
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void DeleteVertexInstance(struct FVertexInstanceID VertexInstanceID, struct TArray<struct FVertexID>& OrphanedVertices); // Offset: 0x104091d34 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function MeshDescription.MeshDescriptionBase.DeleteVertex
	// Flags: [Final|Native|Public|BlueprintCallable]
	void DeleteVertex(struct FVertexID VertexID); // Offset: 0x1040920a8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MeshDescription.MeshDescriptionBase.DeleteTriangle
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void DeleteTriangle(struct FTriangleID TriangleID, struct TArray<struct FEdgeID>& OrphanedEdges, struct TArray<struct FVertexInstanceID>& OrphanedVertexInstances, struct TArray<struct FPolygonGroupID>& OrphanedPolygonGroupsPtr); // Offset: 0x104091374 // Return & Params: Num(4) Size(0x38)

	// Object Name: Function MeshDescription.MeshDescriptionBase.DeletePolygonGroup
	// Flags: [Final|Native|Public|BlueprintCallable]
	void DeletePolygonGroup(struct FPolygonGroupID PolygonGroupID); // Offset: 0x104090b68 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MeshDescription.MeshDescriptionBase.DeletePolygon
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void DeletePolygon(struct FPolygonID PolygonID, struct TArray<struct FEdgeID>& OrphanedEdges, struct TArray<struct FVertexInstanceID>& OrphanedVertexInstances, struct TArray<struct FPolygonGroupID>& OrphanedPolygonGroups); // Offset: 0x104090dc0 // Return & Params: Num(4) Size(0x38)

	// Object Name: Function MeshDescription.MeshDescriptionBase.DeleteEdge
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void DeleteEdge(struct FEdgeID EdgeID, struct TArray<struct FVertexID>& OrphanedVertices); // Offset: 0x104091928 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function MeshDescription.MeshDescriptionBase.CreateVertexWithID
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CreateVertexWithID(struct FVertexID VertexID); // Offset: 0x104092130 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MeshDescription.MeshDescriptionBase.CreateVertexInstanceWithID
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CreateVertexInstanceWithID(struct FVertexInstanceID VertexInstanceID, struct FVertexID VertexID); // Offset: 0x104091e20 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function MeshDescription.MeshDescriptionBase.CreateVertexInstance
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FVertexInstanceID CreateVertexInstance(struct FVertexID VertexID); // Offset: 0x104091efc // Return & Params: Num(2) Size(0x8)

	// Object Name: Function MeshDescription.MeshDescriptionBase.CreateVertex
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FVertexID CreateVertex(); // Offset: 0x1040921b8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MeshDescription.MeshDescriptionBase.CreateTriangleWithID
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void CreateTriangleWithID(struct FTriangleID TriangleID, struct FPolygonGroupID PolygonGroupID, struct TArray<struct FVertexInstanceID>& VertexInstanceIDs, struct TArray<struct FEdgeID>& NewEdgeIDs); // Offset: 0x104091520 // Return & Params: Num(4) Size(0x28)

	// Object Name: Function MeshDescription.MeshDescriptionBase.CreateTriangle
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	struct FTriangleID CreateTriangle(struct FPolygonGroupID PolygonGroupID, struct TArray<struct FVertexInstanceID>& VertexInstanceIDs, struct TArray<struct FEdgeID>& NewEdgeIDs); // Offset: 0x1040916bc // Return & Params: Num(4) Size(0x2c)

	// Object Name: Function MeshDescription.MeshDescriptionBase.CreatePolygonWithID
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void CreatePolygonWithID(struct FPolygonID PolygonID, struct FPolygonGroupID PolygonGroupID, struct TArray<struct FVertexInstanceID>& VertexInstanceIDs, struct TArray<struct FEdgeID>& NewEdgeIDs); // Offset: 0x104090f6c // Return & Params: Num(4) Size(0x28)

	// Object Name: Function MeshDescription.MeshDescriptionBase.CreatePolygonGroupWithID
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CreatePolygonGroupWithID(struct FPolygonGroupID PolygonGroupID); // Offset: 0x104090bf0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MeshDescription.MeshDescriptionBase.CreatePolygonGroup
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FPolygonGroupID CreatePolygonGroup(); // Offset: 0x104090c78 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MeshDescription.MeshDescriptionBase.CreatePolygon
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	struct FPolygonID CreatePolygon(struct FPolygonGroupID PolygonGroupID, struct TArray<struct FVertexInstanceID>& VertexInstanceIDs, struct TArray<struct FEdgeID>& NewEdgeIDs); // Offset: 0x104091108 // Return & Params: Num(4) Size(0x2c)

	// Object Name: Function MeshDescription.MeshDescriptionBase.CreateEdgeWithID
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CreateEdgeWithID(struct FEdgeID EdgeID, struct FVertexID VertexID0, struct FVertexID VertexID1); // Offset: 0x104091a14 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function MeshDescription.MeshDescriptionBase.CreateEdge
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FEdgeID CreateEdge(struct FVertexID VertexID0, struct FVertexID VertexID1); // Offset: 0x104091b3c // Return & Params: Num(3) Size(0xc)

	// Object Name: Function MeshDescription.MeshDescriptionBase.ComputePolygonTriangulation
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ComputePolygonTriangulation(struct FPolygonID PolygonID); // Offset: 0x10408e310 // Return & Params: Num(1) Size(0x4)
};

