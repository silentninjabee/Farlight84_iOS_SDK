#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct S_Event_BattleRoyale.S_Event_BattleRoyale
// Size: 0x58 // Inherited bytes: 0x00
struct FS_Event_BattleRoyale {
	// Fields
	int32_t BattleTime_15_6488AAB44E84633B11E7DF844AD3B376; // Offset: 0x00 // Size: 0x04
	enum class E_BattleEvent_BattleRoyale EventType_11_8FC191774137C63ED18FD5987B59941D; // Offset: 0x04 // Size: 0x01
	char pad_0x5[0x3]; // Offset: 0x05 // Size: 0x03
	struct TMap<struct FString, struct FString> EventParam_10_DC47076342DAE72F001FD1A032026480; // Offset: 0x08 // Size: 0x50
};

