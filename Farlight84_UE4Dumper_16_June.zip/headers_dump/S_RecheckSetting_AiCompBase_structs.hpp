#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct S_RecheckSetting_AiCompBase.S_RecheckSetting_AiCompBase
// Size: 0x08 // Inherited bytes: 0x00
struct FS_RecheckSetting_AiCompBase {
	// Fields
	int32_t RecheckNumber_2_97C2889540DE0A60DF6715922C7B8FC4; // Offset: 0x00 // Size: 0x04
	int32_t RecheckTime_4_5D651E194E66838571BE3FA34A3F2083; // Offset: 0x04 // Size: 0x04
};

