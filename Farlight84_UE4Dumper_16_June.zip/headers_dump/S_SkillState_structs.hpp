#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct S_SkillState.S_SkillState
// Size: 0x02 // Inherited bytes: 0x00
struct FS_SkillState {
	// Fields
	enum class ERoleSkillOperation UniqueAbility_4_1687CEEF476DE16EEE6A42B53EC116E7; // Offset: 0x00 // Size: 0x01
	enum class ERoleSkillOperation TacticsAbility_5_36D081C34231A20607055BA95F67E65B; // Offset: 0x01 // Size: 0x01
};

