#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct S_TeleCenterSetting_AiCompBase.S_TeleCenterSetting_AiCompBase
// Size: 0x14 // Inherited bytes: 0x00
struct FS_TeleCenterSetting_AiCompBase {
	// Fields
	bool SetTeleCenter_1_934127A647EC01FB0575C181F0207AD2; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	struct FIntPoint TeleportRadius_6_B6A052FC42B8B1735E5AFF9F69A260B8; // Offset: 0x04 // Size: 0x08
	struct FIntPoint TeleportAngle_7_E56785284B82170AB9B865A013E3A222; // Offset: 0x0c // Size: 0x08
};

