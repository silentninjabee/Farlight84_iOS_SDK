#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct S_VehicleSetting_AiCompBase.S_VehicleSetting_AiCompBase
// Size: 0x58 // Inherited bytes: 0x00
struct FS_VehicleSetting_AiCompBase {
	// Fields
	bool HasVehicle_1_65D3F5CB42EABC653978A3BB187614F1; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct TMap<int32_t, int32_t> VehicleId_6_1DD8025A4E78B76EFC5B37B83362D226; // Offset: 0x08 // Size: 0x50
};

