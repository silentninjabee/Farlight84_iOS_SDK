#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct S_WarmGameSetting_AiCompbASE.S_WarmGameSetting_AiCompBase
// Size: 0x38 // Inherited bytes: 0x00
struct FS_WarmGameSetting_AiCompBase {
	// Fields
	int32_t MaxiumTeam_12_C517CE564EDE787AE3734383D264A254; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString Comment_15_FE32996349B1C0680A106781D7EE6C86; // Offset: 0x08 // Size: 0x10
	struct UDataTable* Action_5_7DB1AB4A46E32BB245EB5BAAECC0C063; // Offset: 0x18 // Size: 0x08
	struct UDataTable* Item_7_22057775450469E40587299341C57CCC; // Offset: 0x20 // Size: 0x08
	struct UDataTable* Downsize_9_CFC5DE0B4AE8A479571703AEE5031A22; // Offset: 0x28 // Size: 0x08
	struct UDataTable* DeathBox_11_BD72AB2C4EC6B2999BF1C99A081A2563; // Offset: 0x30 // Size: 0x08
};

