#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct Serialization.StructSerializerTestStruct
// Size: 0x450 // Inherited bytes: 0x00
struct FStructSerializerTestStruct {
	// Fields
	struct FStructSerializerNumericTestStruct Numerics; // Offset: 0x00 // Size: 0x30
	struct FStructSerializerBooleanTestStruct Booleans; // Offset: 0x30 // Size: 0x03
	char pad_0x33[0x5]; // Offset: 0x33 // Size: 0x05
	struct FStructSerializerObjectTestStruct Objects; // Offset: 0x38 // Size: 0xa0
	char pad_0xD8[0x8]; // Offset: 0xd8 // Size: 0x08
	struct FStructSerializerBuiltinTestStruct Builtins; // Offset: 0xe0 // Size: 0x90
	struct FStructSerializerArrayTestStruct Arrays; // Offset: 0x170 // Size: 0x60
	struct FStructSerializerMapTestStruct Maps; // Offset: 0x1d0 // Size: 0x140
	struct FStructSerializerSetTestStruct Sets; // Offset: 0x310 // Size: 0x140
};

// Object Name: ScriptStruct Serialization.StructSerializerSetTestStruct
// Size: 0x140 // Inherited bytes: 0x00
struct FStructSerializerSetTestStruct {
	// Fields
	struct TSet<struct FString> StrSet; // Offset: 0x00 // Size: 0x50
	struct TSet<int32_t> IntSet; // Offset: 0x50 // Size: 0x50
	struct TSet<struct FName> NameSet; // Offset: 0xa0 // Size: 0x50
	struct TSet<struct FStructSerializerBuiltinTestStruct> StructSet; // Offset: 0xf0 // Size: 0x50
};

// Object Name: ScriptStruct Serialization.StructSerializerBuiltinTestStruct
// Size: 0x90 // Inherited bytes: 0x00
struct FStructSerializerBuiltinTestStruct {
	// Fields
	struct FGuid Guid; // Offset: 0x00 // Size: 0x10
	struct FName Name; // Offset: 0x10 // Size: 0x08
	struct FString String; // Offset: 0x18 // Size: 0x10
	struct FText Text; // Offset: 0x28 // Size: 0x18
	struct FVector Vector; // Offset: 0x40 // Size: 0x0c
	char pad_0x4C[0x4]; // Offset: 0x4c // Size: 0x04
	struct FVector4 Vector4; // Offset: 0x50 // Size: 0x10
	struct FRotator Rotator; // Offset: 0x60 // Size: 0x0c
	char pad_0x6C[0x4]; // Offset: 0x6c // Size: 0x04
	struct FQuat Quat; // Offset: 0x70 // Size: 0x10
	struct FColor Color; // Offset: 0x80 // Size: 0x04
	char pad_0x84[0xc]; // Offset: 0x84 // Size: 0x0c
};

// Object Name: ScriptStruct Serialization.StructSerializerMapTestStruct
// Size: 0x140 // Inherited bytes: 0x00
struct FStructSerializerMapTestStruct {
	// Fields
	struct TMap<int32_t, struct FString> IntToStr; // Offset: 0x00 // Size: 0x50
	struct TMap<struct FString, struct FString> StrToStr; // Offset: 0x50 // Size: 0x50
	struct TMap<struct FString, struct FVector> StrToVec; // Offset: 0xa0 // Size: 0x50
	struct TMap<struct FString, struct FStructSerializerBuiltinTestStruct> StrToStruct; // Offset: 0xf0 // Size: 0x50
};

// Object Name: ScriptStruct Serialization.StructSerializerArrayTestStruct
// Size: 0x60 // Inherited bytes: 0x00
struct FStructSerializerArrayTestStruct {
	// Fields
	struct TArray<int32_t> Int32Array; // Offset: 0x00 // Size: 0x10
	struct TArray<char> ByteArray; // Offset: 0x10 // Size: 0x10
	int32_t StaticSingleElement; // Offset: 0x20 // Size: 0x04
	int32_t StaticInt32Array[0x3]; // Offset: 0x24 // Size: 0x0c
	float StaticFloatArray[0x3]; // Offset: 0x30 // Size: 0x0c
	char pad_0x3C[0x4]; // Offset: 0x3c // Size: 0x04
	struct TArray<struct FVector> VectorArray; // Offset: 0x40 // Size: 0x10
	struct TArray<struct FStructSerializerBuiltinTestStruct> StructArray; // Offset: 0x50 // Size: 0x10
};

// Object Name: ScriptStruct Serialization.StructSerializerObjectTestStruct
// Size: 0xa0 // Inherited bytes: 0x00
struct FStructSerializerObjectTestStruct {
	// Fields
	struct UObject* Class; // Offset: 0x00 // Size: 0x08
	struct UMetaData* SubClass; // Offset: 0x08 // Size: 0x08
	struct TSoftClassPtr<UObject> SoftClass; // Offset: 0x10 // Size: 0x28
	struct UObject* Object; // Offset: 0x38 // Size: 0x08
	struct TWeakObjectPtr<struct UMetaData> WeakObject; // Offset: 0x40 // Size: 0x08
	struct TSoftObjectPtr<UMetaData> SoftObject; // Offset: 0x48 // Size: 0x28
	struct FSoftClassPath ClassPath; // Offset: 0x70 // Size: 0x18
	struct FSoftObjectPath ObjectPath; // Offset: 0x88 // Size: 0x18
};

// Object Name: ScriptStruct Serialization.StructSerializerBooleanTestStruct
// Size: 0x03 // Inherited bytes: 0x00
struct FStructSerializerBooleanTestStruct {
	// Fields
	bool BoolFalse; // Offset: 0x00 // Size: 0x01
	bool BoolTrue; // Offset: 0x01 // Size: 0x01
	char Bitfield0 : 1; // Offset: 0x02 // Size: 0x01
	char Bitfield1 : 1; // Offset: 0x02 // Size: 0x01
	char Bitfield2Set : 1; // Offset: 0x02 // Size: 0x01
	char Bitfield3 : 1; // Offset: 0x02 // Size: 0x01
	char Bitfield4Set : 1; // Offset: 0x02 // Size: 0x01
	char Bitfield5Set : 1; // Offset: 0x02 // Size: 0x01
	char Bitfield6 : 1; // Offset: 0x02 // Size: 0x01
	char Bitfield7Set : 1; // Offset: 0x02 // Size: 0x01
};

// Object Name: ScriptStruct Serialization.StructSerializerNumericTestStruct
// Size: 0x30 // Inherited bytes: 0x00
struct FStructSerializerNumericTestStruct {
	// Fields
	int8_t int8; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x1]; // Offset: 0x01 // Size: 0x01
	int16_t int16; // Offset: 0x02 // Size: 0x02
	int32_t int32; // Offset: 0x04 // Size: 0x04
	int64_t int64; // Offset: 0x08 // Size: 0x08
	char uint8; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x1]; // Offset: 0x11 // Size: 0x01
	uint16_t uint16; // Offset: 0x12 // Size: 0x02
	uint32_t uint32; // Offset: 0x14 // Size: 0x04
	uint64_t uint64; // Offset: 0x18 // Size: 0x08
	float float; // Offset: 0x20 // Size: 0x04
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
	double Double; // Offset: 0x28 // Size: 0x08
};

// Object Name: ScriptStruct Serialization.StructSerializerByteArray
// Size: 0x38 // Inherited bytes: 0x00
struct FStructSerializerByteArray {
	// Fields
	int32_t Dummy1; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<char> ByteArray; // Offset: 0x08 // Size: 0x10
	int32_t Dummy2; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
	struct TArray<int8_t> Int8Array; // Offset: 0x20 // Size: 0x10
	int32_t Dummy3; // Offset: 0x30 // Size: 0x04
	char pad_0x34[0x4]; // Offset: 0x34 // Size: 0x04
};

