#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: DynamicClass SkillAnimLayerInterface.SkillAnimLayerInterface_C
// Size: 0x28 // Inherited bytes: 0x28
struct USkillAnimLayerInterface_C : UAnimLayerInterface {
	// Functions

	// Object Name: Function SkillAnimLayerInterface.SkillAnimLayerInterface_C.SkillAnimationLayer
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void SkillAnimationLayer(struct FPoseLink bpp__BasePose__pf, struct FPoseLink& bpp__SkillAnimationLayer__pf); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x20)
};

