#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass SolarGameInstance.SolarGameInstance_C
// Size: 0x7f0 // Inherited bytes: 0x7f0
struct USolarGameInstance_C : USolarGameInstanceBase {
};

