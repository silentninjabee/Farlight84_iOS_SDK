#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_Anim_Waiting.UI_Anim_Waiting_C
// Size: 0x350 // Inherited bytes: 0x340
struct UUI_Anim_Waiting_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x340 // Size: 0x08
	struct UWidgetAnimation* Anim_Loop; // Offset: 0x348 // Size: 0x08

	// Functions

	// Object Name: Function UI_Anim_Waiting.UI_Anim_Waiting_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void PreConstruct(bool IsDesignTime); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Anim_Waiting.UI_Anim_Waiting_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Construct(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Anim_Waiting.UI_Anim_Waiting_C.ExecuteUbergraph_UI_Anim_Waiting
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_UI_Anim_Waiting(int32_t EntryPoint); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x4)
};

