#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_BlockAll.UI_BlockAll_C
// Size: 0x348 // Inherited bytes: 0x340
struct UUI_BlockAll_C : USolarUserWidget {
	// Fields
	struct UCanvasPanel* Panel_Block; // Offset: 0x340 // Size: 0x08

	// Functions

	// Object Name: Function UI_BlockAll.UI_BlockAll_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	struct FString GetModuleName(); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x10)
};

