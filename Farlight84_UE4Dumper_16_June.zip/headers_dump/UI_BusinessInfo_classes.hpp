#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_BusinessInfo.UI_BusinessInfo_C
// Size: 0x3c0 // Inherited bytes: 0x340
struct UUI_BusinessInfo_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x340 // Size: 0x08
	struct UImage* Img_LvlBg; // Offset: 0x348 // Size: 0x08
	struct UImage* Img_LvlBg_2; // Offset: 0x350 // Size: 0x08
	struct UUI_Component_NationalFlag_C* Img_NationFlag; // Offset: 0x358 // Size: 0x08
	struct UImage* Img_PlayerNumber_2; // Offset: 0x360 // Size: 0x08
	struct UImage* Img_Rankicon; // Offset: 0x368 // Size: 0x08
	struct USolarTextBlock* Txt_Lvl; // Offset: 0x370 // Size: 0x08
	struct USolarTextBlock* Txt_Name; // Offset: 0x378 // Size: 0x08
	struct USolarTextBlock* Txt_RankName; // Offset: 0x380 // Size: 0x08
	struct UObject* TargetImg; // Offset: 0x388 // Size: 0x08
	struct FLinearColor TargetColor; // Offset: 0x390 // Size: 0x10
	struct TArray<struct UObject*> TeamPosImg; // Offset: 0x3a0 // Size: 0x10
	struct TArray<struct FLinearColor> Color; // Offset: 0x3b0 // Size: 0x10

	// Functions

	// Object Name: Function UI_BusinessInfo.UI_BusinessInfo_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	struct FString GetModuleName(); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UI_BusinessInfo.UI_BusinessInfo_C.Set Player Number
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void Set Player Number(int32_t PlayerNumber); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UI_BusinessInfo.UI_BusinessInfo_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void PreConstruct(bool IsDesignTime); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_BusinessInfo.UI_BusinessInfo_C.OnRefreshWidget
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnRefreshWidget(int32_t Index); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UI_BusinessInfo.UI_BusinessInfo_C.ExecuteUbergraph_UI_BusinessInfo
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_UI_BusinessInfo(int32_t EntryPoint); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x4)
};

