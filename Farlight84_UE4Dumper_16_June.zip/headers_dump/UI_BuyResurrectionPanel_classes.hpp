#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_BuyResurrectionPanel.UI_BuyResurrectionPanel_C
// Size: 0x379 // Inherited bytes: 0x340
struct UUI_BuyResurrectionPanel_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x340 // Size: 0x08
	struct UCanvasPanel* Root; // Offset: 0x348 // Size: 0x08
	struct UUI_Component_Btn_C* UI_Component_Btn_HUD; // Offset: 0x350 // Size: 0x08
	struct UUI_HUD_Notice_BuyResurrection_C* UI_HUD_Notice_BuyResurrection; // Offset: 0x358 // Size: 0x08
	struct UBPC_BuyResurrection_C* BuyComp; // Offset: 0x360 // Size: 0x08
	struct FString NotifyString; // Offset: 0x368 // Size: 0x10
	bool bIsNotifyInCD; // Offset: 0x378 // Size: 0x01

	// Functions

	// Object Name: Function UI_BuyResurrectionPanel.UI_BuyResurrectionPanel_C.Set Btn Vis
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void Set Btn Vis(bool Show); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_BuyResurrectionPanel.UI_BuyResurrectionPanel_C.Set Btna And Tip Visibility
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void Set Btna And Tip Visibility(bool Visibility); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_BuyResurrectionPanel.UI_BuyResurrectionPanel_C.Event_Init
	// Flags: [BlueprintCallable|BlueprintEvent]
	void Event_Init(struct UBPC_BuyResurrection_C* BuyComp); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UI_BuyResurrectionPanel.UI_BuyResurrectionPanel_C.EventOnStateChange
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventOnStateChange(enum class E_BuyResurrectionsState State); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_BuyResurrectionPanel.UI_BuyResurrectionPanel_C.Tick
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x3c)

	// Object Name: Function UI_BuyResurrectionPanel.UI_BuyResurrectionPanel_C.BndEvt__UI_Component_Btn_HUD_K2Node_ComponentBoundEvent_0_OnClicked__DelegateSignature
	// Flags: [BlueprintEvent]
	void BndEvt__UI_Component_Btn_HUD_K2Node_ComponentBoundEvent_0_OnClicked__DelegateSignature(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_BuyResurrectionPanel.UI_BuyResurrectionPanel_C.OnTeammateReviveStateChanged
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnTeammateReviveStateChanged(struct ASolarPlayerState* RevivingMePlayer); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UI_BuyResurrectionPanel.UI_BuyResurrectionPanel_C.ExecuteUbergraph_UI_BuyResurrectionPanel
	// Flags: [Final|UbergraphFunction|HasDefaults]
	void ExecuteUbergraph_UI_BuyResurrectionPanel(int32_t EntryPoint); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x4)
};

