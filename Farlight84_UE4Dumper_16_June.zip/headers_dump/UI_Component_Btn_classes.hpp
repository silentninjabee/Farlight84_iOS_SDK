#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_Component_Btn.UI_Component_Btn_C
// Size: 0x429 // Inherited bytes: 0x348
struct UUI_Component_Btn_C : UComponentButtonBaseWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x348 // Size: 0x08
	struct UWidgetAnimation* Anim_Hold; // Offset: 0x350 // Size: 0x08
	struct UWidgetAnimation* Anim_Hover; // Offset: 0x358 // Size: 0x08
	struct USolarImage* Img_Btn; // Offset: 0x360 // Size: 0x08
	struct USolarImage* Img_Icon; // Offset: 0x368 // Size: 0x08
	struct USolarImage* img_Mask; // Offset: 0x370 // Size: 0x08
	struct USolarImage* Img_Shadow; // Offset: 0x378 // Size: 0x08
	struct UCanvasPanel* Panel_Press; // Offset: 0x380 // Size: 0x08
	struct UScaleBox* ScaleBox; // Offset: 0x388 // Size: 0x08
	struct USizeBox* Size_Btn; // Offset: 0x390 // Size: 0x08
	struct USizeBox* Size_Icon; // Offset: 0x398 // Size: 0x08
	struct USolarTextBlock* Text_Btn; // Offset: 0x3a0 // Size: 0x08
	struct UNamedSlot* WidgetSlot; // Offset: 0x3a8 // Size: 0x08
	enum class E_Type_Btn BtnType; // Offset: 0x3b0 // Size: 0x01
	enum class E_State_Btn BtnState; // Offset: 0x3b1 // Size: 0x01
	char pad_0x3B2[0x2]; // Offset: 0x3b2 // Size: 0x02
	struct FVector2D BtnSize; // Offset: 0x3b4 // Size: 0x08
	bool IsUseBtnImag; // Offset: 0x3bc // Size: 0x01
	bool IsUseText; // Offset: 0x3bd // Size: 0x01
	char pad_0x3BE[0x2]; // Offset: 0x3be // Size: 0x02
	struct FString Text; // Offset: 0x3c0 // Size: 0x10
	bool IsUseLocID; // Offset: 0x3d0 // Size: 0x01
	char pad_0x3D1[0x3]; // Offset: 0x3d1 // Size: 0x03
	int32_t LocID; // Offset: 0x3d4 // Size: 0x04
	enum class ESolarSupportLanguages PreviewLang; // Offset: 0x3d8 // Size: 0x01
	char pad_0x3D9[0x7]; // Offset: 0x3d9 // Size: 0x07
	struct FMulticastInlineDelegate OnClicked; // Offset: 0x3e0 // Size: 0x10
	struct FMulticastInlineDelegate OnPressed; // Offset: 0x3f0 // Size: 0x10
	struct FMulticastInlineDelegate OnReleased; // Offset: 0x400 // Size: 0x10
	bool IsIcon; // Offset: 0x410 // Size: 0x01
	char pad_0x411[0x7]; // Offset: 0x411 // Size: 0x07
	struct UObject* Icon; // Offset: 0x418 // Size: 0x08
	struct FVector2D Icon_Size; // Offset: 0x420 // Size: 0x08
	enum class E_Type_Btn NewVar_1; // Offset: 0x428 // Size: 0x01

	// Functions

	// Object Name: Function UI_Component_Btn.UI_Component_Btn_C.SetBtnTxt
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SetBtnTxt(struct FString NewParam); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UI_Component_Btn.UI_Component_Btn_C.SetBtnState
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetBtnState(enum class E_State_Btn State); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Component_Btn.UI_Component_Btn_C.GetLocalText
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	struct FString GetLocalText(); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UI_Component_Btn.UI_Component_Btn_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void PreConstruct(bool IsDesignTime); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Component_Btn.UI_Component_Btn_C.Update
	// Flags: [BlueprintCallable|BlueprintEvent]
	void Update(bool IsDesignTime); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Component_Btn.UI_Component_Btn_C.SetBtnText
	// Flags: [BlueprintCallable|BlueprintEvent]
	void SetBtnText(struct FString , enum class E_State_Btn ); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x11)

	// Object Name: Function UI_Component_Btn.UI_Component_Btn_C.BndEvt__OperateArea_K2Node_ComponentBoundEvent_6_OnButtonClickedEvent__DelegateSignature
	// Flags: [BlueprintEvent]
	void BndEvt__OperateArea_K2Node_ComponentBoundEvent_6_OnButtonClickedEvent__DelegateSignature(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Component_Btn.UI_Component_Btn_C.BndEvt__OperateArea_K2Node_ComponentBoundEvent_7_OnButtonPressedEvent__DelegateSignature
	// Flags: [BlueprintEvent]
	void BndEvt__OperateArea_K2Node_ComponentBoundEvent_7_OnButtonPressedEvent__DelegateSignature(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Component_Btn.UI_Component_Btn_C.BndEvt__OperateArea_K2Node_ComponentBoundEvent_8_OnButtonReleasedEvent__DelegateSignature
	// Flags: [BlueprintEvent]
	void BndEvt__OperateArea_K2Node_ComponentBoundEvent_8_OnButtonReleasedEvent__DelegateSignature(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Component_Btn.UI_Component_Btn_C.ExecuteUbergraph_UI_Component_Btn
	// Flags: [Final|UbergraphFunction|HasDefaults]
	void ExecuteUbergraph_UI_Component_Btn(int32_t EntryPoint); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UI_Component_Btn.UI_Component_Btn_C.OnReleased__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void OnReleased__DelegateSignature(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Component_Btn.UI_Component_Btn_C.OnClicked__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void OnClicked__DelegateSignature(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Component_Btn.UI_Component_Btn_C.OnPressed__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void OnPressed__DelegateSignature(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)
};

