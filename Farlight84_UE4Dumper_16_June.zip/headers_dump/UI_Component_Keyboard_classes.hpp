#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_Component_Keyboard.UI_Component_Keyboard_C
// Size: 0x310 // Inherited bytes: 0x2a0
struct UUI_Component_Keyboard_C : USolarComponentKeyWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x2a0 // Size: 0x08
	struct UImage* Img_BG; // Offset: 0x2a8 // Size: 0x08
	struct UImage* Img_BG_2; // Offset: 0x2b0 // Size: 0x08
	struct USolarImage* Img_PlusIcon; // Offset: 0x2b8 // Size: 0x08
	struct UWidgetSwitcher* KeyAndMouseSwitcher; // Offset: 0x2c0 // Size: 0x08
	struct UUI_Component_Mouse_C* Mouse; // Offset: 0x2c8 // Size: 0x08
	struct USizeBox* SizeBox_1; // Offset: 0x2d0 // Size: 0x08
	struct USizeBox* SizeBox_2; // Offset: 0x2d8 // Size: 0x08
	struct UTextBlock* Txt_Key; // Offset: 0x2e0 // Size: 0x08
	struct UTextBlock* Txt_Key_2; // Offset: 0x2e8 // Size: 0x08
	bool Red; // Offset: 0x2f0 // Size: 0x01
	bool Yellow; // Offset: 0x2f1 // Size: 0x01
	char pad_0x2F2[0x2]; // Offset: 0x2f2 // Size: 0x02
	int32_t Font_Size; // Offset: 0x2f4 // Size: 0x04
	struct FVector2D BG_Size; // Offset: 0x2f8 // Size: 0x08
	bool bCustomRefresh; // Offset: 0x300 // Size: 0x01
	char pad_0x301[0x7]; // Offset: 0x301 // Size: 0x07
	struct UTextBlock* NewVar_1; // Offset: 0x308 // Size: 0x08

	// Functions

	// Object Name: Function UI_Component_Keyboard.UI_Component_Keyboard_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	struct FString GetModuleName(); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UI_Component_Keyboard.UI_Component_Keyboard_C.BP_RefreshKeyboardUI
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void BP_RefreshKeyboardUI(struct UTextBlock* InTxtKey, struct UImage* InImgBg, struct USizeBox* InSizeBox); // Offset: 0x102f8211c // Return & Params: Num(3) Size(0x18)

	// Object Name: Function UI_Component_Keyboard.UI_Component_Keyboard_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void PreConstruct(bool IsDesignTime); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Component_Keyboard.UI_Component_Keyboard_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Construct(); // Offset: 0x101364770 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Component_Keyboard.UI_Component_Keyboard_C.ExecuteUbergraph_UI_Component_Keyboard
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_UI_Component_Keyboard(int32_t EntryPoint); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x4)
};

