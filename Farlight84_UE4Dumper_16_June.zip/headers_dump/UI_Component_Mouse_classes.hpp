#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_Component_Mouse.UI_Component_Mouse_C
// Size: 0x2a4 // Inherited bytes: 0x260
struct UUI_Component_Mouse_C : UUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x260 // Size: 0x08
	struct UCanvasPanel* Direction; // Offset: 0x268 // Size: 0x08
	struct UImage* Img_Mouse; // Offset: 0x270 // Size: 0x08
	struct USizeBox* SizeBox_1; // Offset: 0x278 // Size: 0x08
	enum class E_Type_Mouse Mouse; // Offset: 0x280 // Size: 0x01
	bool HUD; // Offset: 0x281 // Size: 0x01
	char pad_0x282[0x6]; // Offset: 0x282 // Size: 0x06
	struct FString ActionName; // Offset: 0x288 // Size: 0x10
	bool bCustomRefresh; // Offset: 0x298 // Size: 0x01
	char pad_0x299[0x3]; // Offset: 0x299 // Size: 0x03
	struct FVector2D Size; // Offset: 0x29c // Size: 0x08

	// Functions

	// Object Name: Function UI_Component_Mouse.UI_Component_Mouse_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	struct FString GetModuleName(); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UI_Component_Mouse.UI_Component_Mouse_C.SetData
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void SetData(struct FKey KeySetting, enum class E_Type_Mouse& Type, bool& Succeed); // Offset: 0x102f8211c // Return & Params: Num(3) Size(0x1a)

	// Object Name: Function UI_Component_Mouse.UI_Component_Mouse_C.UpdateImage
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void UpdateImage(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Component_Mouse.UI_Component_Mouse_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void PreConstruct(bool IsDesignTime); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Component_Mouse.UI_Component_Mouse_C.ExecuteUbergraph_UI_Component_Mouse
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_UI_Component_Mouse(int32_t EntryPoint); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x4)
};

