#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_Component_NationalFlag.UI_Component_NationalFlag_C
// Size: 0x37c // Inherited bytes: 0x368
struct UUI_Component_NationalFlag_C : UUIComponentNationalFlag {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x368 // Size: 0x08
	struct USizeBox* SizeBox_1; // Offset: 0x370 // Size: 0x08
	float Size; // Offset: 0x378 // Size: 0x04

	// Functions

	// Object Name: Function UI_Component_NationalFlag.UI_Component_NationalFlag_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	struct FString GetModuleName(); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UI_Component_NationalFlag.UI_Component_NationalFlag_C.Set UI State
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void Set UI State(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Component_NationalFlag.UI_Component_NationalFlag_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void PreConstruct(bool IsDesignTime); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Component_NationalFlag.UI_Component_NationalFlag_C.ExecuteUbergraph_UI_Component_NationalFlag
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_UI_Component_NationalFlag(int32_t EntryPoint); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x4)
};

