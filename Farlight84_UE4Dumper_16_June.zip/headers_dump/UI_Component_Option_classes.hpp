#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_Component_Option.UI_Component_Option_C
// Size: 0x300 // Inherited bytes: 0x280
struct UUI_Component_Option_C : USolarCheckButtonWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x280 // Size: 0x08
	struct UCanvasPanel* Panel_Disabled; // Offset: 0x288 // Size: 0x08
	struct USolarCheckBox* SolarCheckBox_Option; // Offset: 0x290 // Size: 0x08
	struct USolarTextBlock* Txt_Option; // Offset: 0x298 // Size: 0x08
	bool UseText; // Offset: 0x2a0 // Size: 0x01
	char pad_0x2A1[0x7]; // Offset: 0x2a1 // Size: 0x07
	struct FText Text; // Offset: 0x2a8 // Size: 0x18
	int32_t TextID; // Offset: 0x2c0 // Size: 0x04
	enum class ESolarSupportLanguages TextPreviewLang; // Offset: 0x2c4 // Size: 0x01
	char pad_0x2C5[0x3]; // Offset: 0x2c5 // Size: 0x03
	struct FSlateFontSizeForLang SpecialLangFont; // Offset: 0x2c8 // Size: 0x18
	bool Disabled; // Offset: 0x2e0 // Size: 0x01
	char pad_0x2E1[0x7]; // Offset: 0x2e1 // Size: 0x07
	struct FMulticastInlineDelegate OnOptionCheckStateChanged; // Offset: 0x2e8 // Size: 0x10
	bool bCustomClicked; // Offset: 0x2f8 // Size: 0x01
	char pad_0x2F9[0x3]; // Offset: 0x2f9 // Size: 0x03
	int32_t OptionType; // Offset: 0x2fc // Size: 0x04

	// Functions

	// Object Name: Function UI_Component_Option.UI_Component_Option_C.SetEnabled
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SetEnabled(bool Enabled); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Component_Option.UI_Component_Option_C.SetOptionType
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetOptionType(int32_t OptionType); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UI_Component_Option.UI_Component_Option_C.ManualOptionSetIsChecked
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void ManualOptionSetIsChecked(bool bIsChecked); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Component_Option.UI_Component_Option_C.BndEvt__SolarCheckBox_Option_K2Node_ComponentBoundEvent_0_OnCheckBoxComponentStateChanged__DelegateSignature
	// Flags: [BlueprintEvent]
	void BndEvt__SolarCheckBox_Option_K2Node_ComponentBoundEvent_0_OnCheckBoxComponentStateChanged__DelegateSignature(bool bIsChecked); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Component_Option.UI_Component_Option_C.OnSelected
	// Flags: [Event|Protected|BlueprintEvent]
	void OnSelected(bool bSelected); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Component_Option.UI_Component_Option_C.SetDisbaled
	// Flags: [BlueprintCallable|BlueprintEvent]
	void SetDisbaled(bool Disabled); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Component_Option.UI_Component_Option_C.RefreshOptionTxtUI
	// Flags: [BlueprintCallable|BlueprintEvent]
	void RefreshOptionTxtUI(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Component_Option.UI_Component_Option_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void PreConstruct(bool IsDesignTime); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Component_Option.UI_Component_Option_C.ExecuteUbergraph_UI_Component_Option
	// Flags: [Final|UbergraphFunction|HasDefaults]
	void ExecuteUbergraph_UI_Component_Option(int32_t EntryPoint); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UI_Component_Option.UI_Component_Option_C.OnOptionCheckStateChanged__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void OnOptionCheckStateChanged__DelegateSignature(bool bIsChecked); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x1)
};

