#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_Component_Proficiency.UI_Component_Proficiency_C
// Size: 0x281 // Inherited bytes: 0x260
struct UUI_Component_Proficiency_C : UUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x260 // Size: 0x08
	struct UImage* Img_ProficiencyIcon; // Offset: 0x268 // Size: 0x08
	struct USizeBox* SizeBox_1; // Offset: 0x270 // Size: 0x08
	float Size; // Offset: 0x278 // Size: 0x04
	int32_t Lvl; // Offset: 0x27c // Size: 0x04
	bool S; // Offset: 0x280 // Size: 0x01

	// Functions

	// Object Name: Function UI_Component_Proficiency.UI_Component_Proficiency_C.SetLvl
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetLvl(int32_t Lvl, bool S); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x5)

	// Object Name: Function UI_Component_Proficiency.UI_Component_Proficiency_C.SetSize
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetSize(float Size); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UI_Component_Proficiency.UI_Component_Proficiency_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void PreConstruct(bool IsDesignTime); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Component_Proficiency.UI_Component_Proficiency_C.ExecuteUbergraph_UI_Component_Proficiency
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_UI_Component_Proficiency(int32_t EntryPoint); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x4)
};

