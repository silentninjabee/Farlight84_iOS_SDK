#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_Component_Tips.UI_Component_Tips_C
// Size: 0x3f1 // Inherited bytes: 0x340
struct UUI_Component_Tips_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x340 // Size: 0x08
	struct UWidgetAnimation* Anim_Exit; // Offset: 0x348 // Size: 0x08
	struct UWidgetAnimation* Anim_Enter; // Offset: 0x350 // Size: 0x08
	struct UImage* Img_Arrow_B; // Offset: 0x358 // Size: 0x08
	struct UImage* Img_Arrow_L; // Offset: 0x360 // Size: 0x08
	struct UImage* Img_Arrow_R; // Offset: 0x368 // Size: 0x08
	struct UImage* Img_BG; // Offset: 0x370 // Size: 0x08
	struct USolarListView* List_Item; // Offset: 0x378 // Size: 0x08
	struct UUI_Target_Medal_Challenge_S_C* Medal_2; // Offset: 0x380 // Size: 0x08
	struct UUI_Target_Medal_Challenge_S_C* Medal_3; // Offset: 0x388 // Size: 0x08
	struct UUI_Target_Medal_Challenge_S_C* Medal_4; // Offset: 0x390 // Size: 0x08
	struct UUI_Target_Medal_Challenge_S_C* Medal_5; // Offset: 0x398 // Size: 0x08
	struct UHorizontalBox* Panel_Medal; // Offset: 0x3a0 // Size: 0x08
	struct USpacer* Spacer_390; // Offset: 0x3a8 // Size: 0x08
	struct USolarTextBlock* Txt_Details; // Offset: 0x3b0 // Size: 0x08
	struct USolarTextBlock* Txt_Num; // Offset: 0x3b8 // Size: 0x08
	struct USolarTextBlock* Txt_Title; // Offset: 0x3c0 // Size: 0x08
	struct UUI_Component_Btn_C* UI_Component_Btn; // Offset: 0x3c8 // Size: 0x08
	struct UUI_Component_Item_C* UI_Component_Item; // Offset: 0x3d0 // Size: 0x08
	struct UVerticalBox* VerticalBox_41; // Offset: 0x3d8 // Size: 0x08
	bool Left; // Offset: 0x3e0 // Size: 0x01
	bool Right; // Offset: 0x3e1 // Size: 0x01
	bool Btn; // Offset: 0x3e2 // Size: 0x01
	bool Num; // Offset: 0x3e3 // Size: 0x01
	bool Item; // Offset: 0x3e4 // Size: 0x01
	char pad_0x3E5[0x3]; // Offset: 0x3e5 // Size: 0x03
	float Location; // Offset: 0x3e8 // Size: 0x04
	bool Title; // Offset: 0x3ec // Size: 0x01
	bool Medal; // Offset: 0x3ed // Size: 0x01
	bool Task; // Offset: 0x3ee // Size: 0x01
	bool Detail; // Offset: 0x3ef // Size: 0x01
	bool Bottom; // Offset: 0x3f0 // Size: 0x01

	// Functions

	// Object Name: Function UI_Component_Tips.UI_Component_Tips_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	struct FString GetModuleName(); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UI_Component_Tips.UI_Component_Tips_C.BP_OnEntryReleased
	// Flags: [Event|Protected|BlueprintEvent]
	void BP_OnEntryReleased(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Component_Tips.UI_Component_Tips_C.BP_OnItemExpansionChanged
	// Flags: [Event|Protected|BlueprintEvent]
	void BP_OnItemExpansionChanged(bool bIsExpanded); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Component_Tips.UI_Component_Tips_C.BP_OnItemSelectionChanged
	// Flags: [Event|Protected|BlueprintEvent]
	void BP_OnItemSelectionChanged(bool bIsSelected); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Component_Tips.UI_Component_Tips_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void PreConstruct(bool IsDesignTime); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Component_Tips.UI_Component_Tips_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Construct(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Component_Tips.UI_Component_Tips_C.ChangeTipStatus
	// Flags: [BlueprintCallable|BlueprintEvent]
	void ChangeTipStatus(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Component_Tips.UI_Component_Tips_C.ExecuteUbergraph_UI_Component_Tips
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_UI_Component_Tips(int32_t EntryPoint); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x4)
};

