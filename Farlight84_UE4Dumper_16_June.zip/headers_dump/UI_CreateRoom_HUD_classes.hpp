#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_CreateRoom_HUD.UI_CreateRoom_HUD_C
// Size: 0x3c1 // Inherited bytes: 0x340
struct UUI_CreateRoom_HUD_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x340 // Size: 0x08
	struct UButton* Btn_CantStart; // Offset: 0x348 // Size: 0x08
	struct UUI_Component_Btn_C* Btn_GameStart; // Offset: 0x350 // Size: 0x08
	struct UUI_Component_Btn_C* Btn_RoomManage; // Offset: 0x358 // Size: 0x08
	struct USolarAdapterWidget* Panel_Shortcut; // Offset: 0x360 // Size: 0x08
	struct USolarAdapterWidget* Panel_Shortcut_2; // Offset: 0x368 // Size: 0x08
	struct UHorizontalBox* panel_spectators; // Offset: 0x370 // Size: 0x08
	struct USolarRichTextBlock* Txt_CountDown; // Offset: 0x378 // Size: 0x08
	struct USolarTextBlock* Txt_Spectators; // Offset: 0x380 // Size: 0x08
	struct USolarTextBlock* Txt_Spectators_2; // Offset: 0x388 // Size: 0x08
	struct USolarTextBlock* Txt_Spectators_3; // Offset: 0x390 // Size: 0x08
	struct UUI_Component_Keyboard_C* UI_Component_Keyboard; // Offset: 0x398 // Size: 0x08
	struct UUI_Component_Keyboard_C* UI_Component_Keyboard_2; // Offset: 0x3a0 // Size: 0x08
	struct UUI_Component_Keyboard_C* UI_Component_Keyboard_4; // Offset: 0x3a8 // Size: 0x08
	struct UWidgetSwitcher* WidgetSwitcher_Manage; // Offset: 0x3b0 // Size: 0x08
	struct UWidgetSwitcher* WidgetSwitcher_Start; // Offset: 0x3b8 // Size: 0x08
	bool bIsOwner; // Offset: 0x3c0 // Size: 0x01

	// Functions

	// Object Name: Function UI_CreateRoom_HUD.UI_CreateRoom_HUD_C.SetOnwerMode
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SetOnwerMode(bool IsOwner); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_CreateRoom_HUD.UI_CreateRoom_HUD_C.ShowSpectator
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void ShowSpectator(bool Show); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_CreateRoom_HUD.UI_CreateRoom_HUD_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Construct(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_CreateRoom_HUD.UI_CreateRoom_HUD_C.Start Ticking
	// Flags: [BlueprintCallable|BlueprintEvent]
	void Start Ticking(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_CreateRoom_HUD.UI_CreateRoom_HUD_C.TikTok
	// Flags: [BlueprintCallable|BlueprintEvent]
	void TikTok(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_CreateRoom_HUD.UI_CreateRoom_HUD_C.BndEvt__UI_Component_Btn_K2Node_ComponentBoundEvent_0_OnClicked__DelegateSignature
	// Flags: [BlueprintEvent]
	void BndEvt__UI_Component_Btn_K2Node_ComponentBoundEvent_0_OnClicked__DelegateSignature(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_CreateRoom_HUD.UI_CreateRoom_HUD_C.BndEvt__UI_Component_Btn_1_K2Node_ComponentBoundEvent_1_OnClicked__DelegateSignature
	// Flags: [BlueprintEvent]
	void BndEvt__UI_Component_Btn_1_K2Node_ComponentBoundEvent_1_OnClicked__DelegateSignature(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_CreateRoom_HUD.UI_CreateRoom_HUD_C.Update Button State
	// Flags: [BlueprintCallable|BlueprintEvent]
	void Update Button State(bool Can Start); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_CreateRoom_HUD.UI_CreateRoom_HUD_C.BndEvt__Btn_CantStart_K2Node_ComponentBoundEvent_2_OnButtonClickedEvent__DelegateSignature
	// Flags: [BlueprintEvent]
	void BndEvt__Btn_CantStart_K2Node_ComponentBoundEvent_2_OnButtonClickedEvent__DelegateSignature(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_CreateRoom_HUD.UI_CreateRoom_HUD_C.OnInitialized
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void OnInitialized(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_CreateRoom_HUD.UI_CreateRoom_HUD_C.OnRoomInfoSwitch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnRoomInfoSwitch(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_CreateRoom_HUD.UI_CreateRoom_HUD_C.OnStartGame
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnStartGame(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_CreateRoom_HUD.UI_CreateRoom_HUD_C.Event_RoomInfoSwitch
	// Flags: [BlueprintCallable|BlueprintEvent]
	void Event_RoomInfoSwitch(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_CreateRoom_HUD.UI_CreateRoom_HUD_C.Event_GameStart
	// Flags: [BlueprintCallable|BlueprintEvent]
	void Event_GameStart(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_CreateRoom_HUD.UI_CreateRoom_HUD_C.OnShow
	// Flags: [Event|Protected|BlueprintEvent]
	void OnShow(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_CreateRoom_HUD.UI_CreateRoom_HUD_C.OnHide
	// Flags: [Event|Protected|BlueprintEvent]
	void OnHide(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_CreateRoom_HUD.UI_CreateRoom_HUD_C.ExecuteUbergraph_UI_CreateRoom_HUD
	// Flags: [Final|UbergraphFunction|HasDefaults]
	void ExecuteUbergraph_UI_CreateRoom_HUD(int32_t EntryPoint); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x4)
};

