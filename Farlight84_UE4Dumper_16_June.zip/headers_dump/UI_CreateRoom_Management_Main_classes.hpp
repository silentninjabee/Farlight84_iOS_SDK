#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_CreateRoom_Management_Main.UI_CreateRoom_Management_Main_C
// Size: 0x4e9 // Inherited bytes: 0x340
struct UUI_CreateRoom_Management_Main_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x340 // Size: 0x08
	struct UWidgetAnimation* Anim_OB_Exit; // Offset: 0x348 // Size: 0x08
	struct UWidgetAnimation* Anim_OB_Enter; // Offset: 0x350 // Size: 0x08
	struct UWidgetAnimation* Enter_Anim; // Offset: 0x358 // Size: 0x08
	struct UButton* Btn_CantStart; // Offset: 0x360 // Size: 0x08
	struct UUI_Component_Btn_C* Btn_Invite; // Offset: 0x368 // Size: 0x08
	struct USolarButton* Btn_SpectateList; // Offset: 0x370 // Size: 0x08
	struct UUI_Component_Btn_C* Btn_StartGame; // Offset: 0x378 // Size: 0x08
	struct UButton* Button_BanSwap; // Offset: 0x380 // Size: 0x08
	struct USolarCheckBox* Guest_Invite; // Offset: 0x388 // Size: 0x08
	struct USolarCheckBox* Guest_Swap; // Offset: 0x390 // Size: 0x08
	struct UHorizontalBox* HorizontalBox_SubGameModeInfo_2; // Offset: 0x398 // Size: 0x08
	struct UOverlay* MessageBox; // Offset: 0x3a0 // Size: 0x08
	struct UUI_Component_Option_C* Option_Invite; // Offset: 0x3a8 // Size: 0x08
	struct UUI_Component_Option_C* Option_Swap; // Offset: 0x3b0 // Size: 0x08
	struct UCanvasPanel* Panel_Guest; // Offset: 0x3b8 // Size: 0x08
	struct UCanvasPanel* Panel_Homeowner; // Offset: 0x3c0 // Size: 0x08
	struct UCanvasPanel* panel_Spectate; // Offset: 0x3c8 // Size: 0x08
	struct UParticleSystemWidget* Par_Spark; // Offset: 0x3d0 // Size: 0x08
	struct USolarRichTextBlock* RichText_Members; // Offset: 0x3d8 // Size: 0x08
	struct UTileView* TileView_Player_Info_1M; // Offset: 0x3e0 // Size: 0x08
	struct UTileView* TileView_Player_Info_2M; // Offset: 0x3e8 // Size: 0x08
	struct UTileView* TileView_Player_Info_4M; // Offset: 0x3f0 // Size: 0x08
	struct USolarTextBlock* Txt_CountDown_2; // Offset: 0x3f8 // Size: 0x08
	struct USolarTextBlock* Txt_Map; // Offset: 0x400 // Size: 0x08
	struct USolarTextBlock* Txt_Members; // Offset: 0x408 // Size: 0x08
	struct USolarTextBlock* Txt_Mode; // Offset: 0x410 // Size: 0x08
	struct USolarTextBlock* Txt_Password_3; // Offset: 0x418 // Size: 0x08
	struct USolarTextBlock* Txt_RankedMatch; // Offset: 0x420 // Size: 0x08
	struct USolarTextBlock* Txt_Room_ID; // Offset: 0x428 // Size: 0x08
	struct USolarTextBlock* Txt_Room_ID_3; // Offset: 0x430 // Size: 0x08
	struct USolarRichTextBlock* Txt_Viewer_Num; // Offset: 0x438 // Size: 0x08
	struct UUI_Component_ReturnBtn_C* UI_Component_ReturnBtn; // Offset: 0x440 // Size: 0x08
	struct UUI_CreateRoom_SocialList_C* UI_CreateRoom_SocialList; // Offset: 0x448 // Size: 0x08
	struct UUI_CreateRoom_Management_Team_OB_C* UI_Management_OB; // Offset: 0x450 // Size: 0x08
	struct UWidgetSwitcher* WidgetSwitcher_Down; // Offset: 0x458 // Size: 0x08
	enum class E_Type_Team_Member Team_Member_Count; // Offset: 0x460 // Size: 0x01
	char pad_0x461[0x3]; // Offset: 0x461 // Size: 0x03
	int32_t Max Member Count; // Offset: 0x464 // Size: 0x04
	struct FString Selected Player; // Offset: 0x468 // Size: 0x10
	int32_t SelcetedPos; // Offset: 0x478 // Size: 0x04
	char pad_0x47C[0x4]; // Offset: 0x47c // Size: 0x04
	struct FString Selected Side; // Offset: 0x480 // Size: 0x10
	struct UUI_CreateRoom_Management_Player_Info_C* SelectedInfoWidget; // Offset: 0x490 // Size: 0x08
	struct FString ToDeletePlayer; // Offset: 0x498 // Size: 0x10
	int32_t MaxOBPlayerCount; // Offset: 0x4a8 // Size: 0x04
	bool SelectedOB; // Offset: 0x4ac // Size: 0x01
	char pad_0x4AD[0x3]; // Offset: 0x4ad // Size: 0x03
	int32_t NowOBPlayerCount; // Offset: 0x4b0 // Size: 0x04
	char pad_0x4B4[0x4]; // Offset: 0x4b4 // Size: 0x04
	struct TArray<struct UUI_CreateRoom_Management_Team_C*> All Team Widgets; // Offset: 0x4b8 // Size: 0x10
	struct UObject* _TileViewInitItem; // Offset: 0x4c8 // Size: 0x08
	struct UObject* _TileViewInitWidget; // Offset: 0x4d0 // Size: 0x08
	struct FMulticastInlineDelegate OnEnableInviteChanged; // Offset: 0x4d8 // Size: 0x10
	enum class ERoomModeType RoomMode; // Offset: 0x4e8 // Size: 0x01

	// Functions

	// Object Name: Function UI_CreateRoom_Management_Main.UI_CreateRoom_Management_Main_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	struct FString GetModuleName(); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UI_CreateRoom_Management_Main.UI_CreateRoom_Management_Main_C.OnConfirmKickPlayerOut
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void OnConfirmKickPlayerOut(struct ASCMPlayerState* Player); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UI_CreateRoom_Management_Main.UI_CreateRoom_Management_Main_C.RestoreSelectedWidgets
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void RestoreSelectedWidgets(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_CreateRoom_Management_Main.UI_CreateRoom_Management_Main_C.RestoreSelectedParams
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void RestoreSelectedParams(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_CreateRoom_Management_Main.UI_CreateRoom_Management_Main_C.CallLuaShowKickConfirmWindow
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void CallLuaShowKickConfirmWindow(struct ASCMPlayerState* PS); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UI_CreateRoom_Management_Main.UI_CreateRoom_Management_Main_C.IsGuestSwapOpen
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void IsGuestSwapOpen(bool& bIsOpen); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_CreateRoom_Management_Main.UI_CreateRoom_Management_Main_C.CallLuaOnGuestInviteChanged
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void CallLuaOnGuestInviteChanged(bool bIsChecked); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_CreateRoom_Management_Main.UI_CreateRoom_Management_Main_C.RefreshGuestData
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void RefreshGuestData(bool bEnableSwap, bool bEnableInvite); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x2)

	// Object Name: Function UI_CreateRoom_Management_Main.UI_CreateRoom_Management_Main_C.Get Active TileView
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void Get Active TileView(struct UTileView*& Result); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UI_CreateRoom_Management_Main.UI_CreateRoom_Management_Main_C.Trim Pending Removal Players
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void Trim Pending Removal Players(struct TArray<struct ASCMPlayerState*>& Player List, struct TArray<struct ASCMPlayerState*>& Trimmed Player List); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function UI_CreateRoom_Management_Main.UI_CreateRoom_Management_Main_C.PlayEnter
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void PlayEnter(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_CreateRoom_Management_Main.UI_CreateRoom_Management_Main_C.Set Room Mode
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void Set Room Mode(enum class ERoomModeType RoomMode); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_CreateRoom_Management_Main.UI_CreateRoom_Management_Main_C.GetPlayerByIDAndOB
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void GetPlayerByIDAndOB(struct FString PlayerId, bool bIsOB, struct ASCMPlayerState*& Player); // Offset: 0x102f8211c // Return & Params: Num(3) Size(0x20)

	// Object Name: Function UI_CreateRoom_Management_Main.UI_CreateRoom_Management_Main_C.RefreshOB
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void RefreshOB(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_CreateRoom_Management_Main.UI_CreateRoom_Management_Main_C.Init OB
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void Init OB(int32_t OBPlayerCount); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UI_CreateRoom_Management_Main.UI_CreateRoom_Management_Main_C.Update Button State
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void Update Button State(bool Can Start); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_CreateRoom_Management_Main.UI_CreateRoom_Management_Main_C.State Team
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void State Team(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_CreateRoom_Management_Main.UI_CreateRoom_Management_Main_C.Init Room Mgmt UI
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void Init Room Mgmt UI(enum class E_Type_Team_Member Team Type, struct FString Master Name, struct FString Room PW, struct FString Room ID, int32_t ModeName LocalID, int32_t ModeGroup LocalID, int32_t MaxOBPlayerCount, enum class ERoomModeType RoomMode); // Offset: 0x102f8211c // Return & Params: Num(8) Size(0x45)

	// Object Name: Function UI_CreateRoom_Management_Main.UI_CreateRoom_Management_Main_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void PreConstruct(bool IsDesignTime); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_CreateRoom_Management_Main.UI_CreateRoom_Management_Main_C.Start Ticking
	// Flags: [BlueprintCallable|BlueprintEvent]
	void Start Ticking(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_CreateRoom_Management_Main.UI_CreateRoom_Management_Main_C.TikTok
	// Flags: [BlueprintCallable|BlueprintEvent]
	void TikTok(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_CreateRoom_Management_Main.UI_CreateRoom_Management_Main_C.OnMemberCountChanged
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnMemberCountChanged(int32_t NowCount, int32_t MaxCount, bool Can Start); // Offset: 0x102f8211c // Return & Params: Num(3) Size(0x9)

	// Object Name: Function UI_CreateRoom_Management_Main.UI_CreateRoom_Management_Main_C.BndEvt__Btn_StartGame_K2Node_ComponentBoundEvent_1_OnClicked__DelegateSignature
	// Flags: [BlueprintEvent]
	void BndEvt__Btn_StartGame_K2Node_ComponentBoundEvent_1_OnClicked__DelegateSignature(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_CreateRoom_Management_Main.UI_CreateRoom_Management_Main_C.BndEvt__TileView_Player_Info_K2Node_ComponentBoundEvent_2_OnListEntryInitializedDynamic__DelegateSignature
	// Flags: [BlueprintEvent]
	void BndEvt__TileView_Player_Info_K2Node_ComponentBoundEvent_2_OnListEntryInitializedDynamic__DelegateSignature(struct UObject* Item, struct UUserWidget* Widget); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UI_CreateRoom_Management_Main.UI_CreateRoom_Management_Main_C.BndEvt__TileView_Player_Info_K2Node_ComponentBoundEvent_4_OnListEntryGeneratedDynamic__DelegateSignature
	// Flags: [BlueprintEvent]
	void BndEvt__TileView_Player_Info_K2Node_ComponentBoundEvent_4_OnListEntryGeneratedDynamic__DelegateSignature(struct UUserWidget* Widget); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UI_CreateRoom_Management_Main.UI_CreateRoom_Management_Main_C.BndEvt__Btn_CantStart_K2Node_ComponentBoundEvent_3_OnButtonClickedEvent__DelegateSignature
	// Flags: [BlueprintEvent]
	void BndEvt__Btn_CantStart_K2Node_ComponentBoundEvent_3_OnButtonClickedEvent__DelegateSignature(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_CreateRoom_Management_Main.UI_CreateRoom_Management_Main_C.InitDeletePanel
	// Flags: [BlueprintCallable|BlueprintEvent]
	void InitDeletePanel(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_CreateRoom_Management_Main.UI_CreateRoom_Management_Main_C.ALL_WIDGET Selection
	// Flags: [BlueprintCallable|BlueprintEvent]
	void ALL_WIDGET Selection(bool Selection is OB, struct UUI_CreateRoom_Management_Player_Info_C* SelectedInfoWidget); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UI_CreateRoom_Management_Main.UI_CreateRoom_Management_Main_C.ALL_WIDGET Deselection
	// Flags: [BlueprintCallable|BlueprintEvent]
	void ALL_WIDGET Deselection(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_CreateRoom_Management_Main.UI_CreateRoom_Management_Main_C.ALL_WIDGET Update
	// Flags: [BlueprintCallable|BlueprintEvent]
	void ALL_WIDGET Update(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_CreateRoom_Management_Main.UI_CreateRoom_Management_Main_C.BndEvt__TileView_Player_Info_2M_K2Node_ComponentBoundEvent_5_OnListEntryInitializedDynamic__DelegateSignature
	// Flags: [BlueprintEvent]
	void BndEvt__TileView_Player_Info_2M_K2Node_ComponentBoundEvent_5_OnListEntryInitializedDynamic__DelegateSignature(struct UObject* Item, struct UUserWidget* Widget); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UI_CreateRoom_Management_Main.UI_CreateRoom_Management_Main_C.BndEvt__TileView_Player_Info_4M_K2Node_ComponentBoundEvent_6_OnListEntryInitializedDynamic__DelegateSignature
	// Flags: [BlueprintEvent]
	void BndEvt__TileView_Player_Info_4M_K2Node_ComponentBoundEvent_6_OnListEntryInitializedDynamic__DelegateSignature(struct UObject* Item, struct UUserWidget* Widget); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UI_CreateRoom_Management_Main.UI_CreateRoom_Management_Main_C.BndEvt__TileView_Player_Info_2M_K2Node_ComponentBoundEvent_7_OnListEntryGeneratedDynamic__DelegateSignature
	// Flags: [BlueprintEvent]
	void BndEvt__TileView_Player_Info_2M_K2Node_ComponentBoundEvent_7_OnListEntryGeneratedDynamic__DelegateSignature(struct UUserWidget* Widget); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UI_CreateRoom_Management_Main.UI_CreateRoom_Management_Main_C.BndEvt__TileView_Player_Info_4M_K2Node_ComponentBoundEvent_8_OnListEntryGeneratedDynamic__DelegateSignature
	// Flags: [BlueprintEvent]
	void BndEvt__TileView_Player_Info_4M_K2Node_ComponentBoundEvent_8_OnListEntryGeneratedDynamic__DelegateSignature(struct UUserWidget* Widget); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UI_CreateRoom_Management_Main.UI_CreateRoom_Management_Main_C.BndEvt__Option_Swap_K2Node_ComponentBoundEvent_12_OnOptionCheckStateChanged__DelegateSignature
	// Flags: [BlueprintEvent]
	void BndEvt__Option_Swap_K2Node_ComponentBoundEvent_12_OnOptionCheckStateChanged__DelegateSignature(bool bIsChecked); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_CreateRoom_Management_Main.UI_CreateRoom_Management_Main_C.BndEvt__Option_Invite_K2Node_ComponentBoundEvent_13_OnOptionCheckStateChanged__DelegateSignature
	// Flags: [BlueprintEvent]
	void BndEvt__Option_Invite_K2Node_ComponentBoundEvent_13_OnOptionCheckStateChanged__DelegateSignature(bool bIsChecked); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_CreateRoom_Management_Main.UI_CreateRoom_Management_Main_C.BndEvt__Button_BanSwap_K2Node_ComponentBoundEvent_10_OnButtonClickedEvent__DelegateSignature
	// Flags: [BlueprintEvent]
	void BndEvt__Button_BanSwap_K2Node_ComponentBoundEvent_10_OnButtonClickedEvent__DelegateSignature(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_CreateRoom_Management_Main.UI_CreateRoom_Management_Main_C.BndEvt__Guest_Invite_K2Node_ComponentBoundEvent_9_OnCheckBoxComponentStateChanged__DelegateSignature
	// Flags: [BlueprintEvent]
	void BndEvt__Guest_Invite_K2Node_ComponentBoundEvent_9_OnCheckBoxComponentStateChanged__DelegateSignature(bool bIsChecked); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_CreateRoom_Management_Main.UI_CreateRoom_Management_Main_C.Side_WIDGET Update
	// Flags: [BlueprintCallable|BlueprintEvent]
	void Side_WIDGET Update(struct FString Side); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UI_CreateRoom_Management_Main.UI_CreateRoom_Management_Main_C.BndEvt__UI_Component_ReturnBtn_K2Node_ComponentBoundEvent_11_OnClicked__DelegateSignature
	// Flags: [BlueprintEvent]
	void BndEvt__UI_Component_ReturnBtn_K2Node_ComponentBoundEvent_11_OnClicked__DelegateSignature(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_CreateRoom_Management_Main.UI_CreateRoom_Management_Main_C.OnShow
	// Flags: [Event|Protected|BlueprintEvent]
	void OnShow(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_CreateRoom_Management_Main.UI_CreateRoom_Management_Main_C.OnEvnetCloseAction
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnEvnetCloseAction(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_CreateRoom_Management_Main.UI_CreateRoom_Management_Main_C.ReceiveHide
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveHide(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_CreateRoom_Management_Main.UI_CreateRoom_Management_Main_C.OB UI EventBinding
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OB UI EventBinding(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_CreateRoom_Management_Main.UI_CreateRoom_Management_Main_C.Trigger Flag Update
	// Flags: [BlueprintCallable|BlueprintEvent]
	void Trigger Flag Update(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_CreateRoom_Management_Main.UI_CreateRoom_Management_Main_C.OnDeleteClicked
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnDeleteClicked(struct FString Clicked Player, struct FString Clicked Side); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function UI_CreateRoom_Management_Main.UI_CreateRoom_Management_Main_C.OnSlotClicked
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnSlotClicked(struct FString Clicked Player, struct FString Clicked Side, bool Is OB, int32_t PosIndex, struct UUI_CreateRoom_Management_Team_C* TeamWidget, struct UUI_CreateRoom_Management_Player_Info_C* InfoWidget); // Offset: 0x102f8211c // Return & Params: Num(6) Size(0x38)

	// Object Name: Function UI_CreateRoom_Management_Main.UI_CreateRoom_Management_Main_C.ExecuteUbergraph_UI_CreateRoom_Management_Main
	// Flags: [Final|UbergraphFunction|HasDefaults]
	void ExecuteUbergraph_UI_CreateRoom_Management_Main(int32_t EntryPoint); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UI_CreateRoom_Management_Main.UI_CreateRoom_Management_Main_C.OnEnableInviteChanged__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void OnEnableInviteChanged__DelegateSignature(bool bEnable); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x1)
};

