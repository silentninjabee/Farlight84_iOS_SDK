#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_Customize_Data.UI_Customize_Data_C
// Size: 0x270 // Inherited bytes: 0x260
struct UUI_Customize_Data_C : UUserWidget {
	// Fields
	struct TArray<struct FS_Customize_Element> ElementConfig; // Offset: 0x260 // Size: 0x10
};

