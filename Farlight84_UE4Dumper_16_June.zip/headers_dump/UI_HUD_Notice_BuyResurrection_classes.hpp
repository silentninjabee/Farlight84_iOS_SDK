#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_HUD_Notice_BuyResurrection.UI_HUD_Notice_BuyResurrection_C
// Size: 0x3a0 // Inherited bytes: 0x368
struct UUI_HUD_Notice_BuyResurrection_C : UUI_NoticeBase_C {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x368 // Size: 0x08
	struct UWidgetAnimation* ant_exit; // Offset: 0x370 // Size: 0x08
	struct UWidgetAnimation* Appear_Anim; // Offset: 0x378 // Size: 0x08
	struct UImage* Img_Txt_bg; // Offset: 0x380 // Size: 0x08
	struct URichTextBlock* Txt_Ballte_Notice_2; // Offset: 0x388 // Size: 0x08
	struct USolarTextBlock* Txt_Ballte_Notice_4; // Offset: 0x390 // Size: 0x08
	struct USolarTextBlock* Txt_Ballte_Notice_5; // Offset: 0x398 // Size: 0x08

	// Functions

	// Object Name: Function UI_HUD_Notice_BuyResurrection.UI_HUD_Notice_BuyResurrection_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Construct(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_HUD_Notice_BuyResurrection.UI_HUD_Notice_BuyResurrection_C.ShowNotice
	// Flags: [BlueprintCallable|BlueprintEvent]
	void ShowNotice(struct FString Text, float Duration); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x14)

	// Object Name: Function UI_HUD_Notice_BuyResurrection.UI_HUD_Notice_BuyResurrection_C.ExecuteUbergraph_UI_HUD_Notice_BuyResurrection
	// Flags: [Final|UbergraphFunction|HasDefaults]
	void ExecuteUbergraph_UI_HUD_Notice_BuyResurrection(int32_t EntryPoint); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x4)
};

