#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_Lobby_Banner_Slot.UI_Lobby_Banner_Slot_C
// Size: 0x358 // Inherited bytes: 0x340
struct UUI_Lobby_Banner_Slot_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x340 // Size: 0x08
	struct USolarImageURL* ImageURL; // Offset: 0x348 // Size: 0x08
	struct UImage* Img_Default; // Offset: 0x350 // Size: 0x08

	// Functions

	// Object Name: Function UI_Lobby_Banner_Slot.UI_Lobby_Banner_Slot_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	struct FString GetModuleName(); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UI_Lobby_Banner_Slot.UI_Lobby_Banner_Slot_C.BP_OnEntryReleased
	// Flags: [Event|Protected|BlueprintEvent]
	void BP_OnEntryReleased(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Lobby_Banner_Slot.UI_Lobby_Banner_Slot_C.BP_OnItemExpansionChanged
	// Flags: [Event|Protected|BlueprintEvent]
	void BP_OnItemExpansionChanged(bool bIsExpanded); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Lobby_Banner_Slot.UI_Lobby_Banner_Slot_C.BP_OnItemSelectionChanged
	// Flags: [Event|Protected|BlueprintEvent]
	void BP_OnItemSelectionChanged(bool bIsSelected); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Lobby_Banner_Slot.UI_Lobby_Banner_Slot_C.OnListItemObjectSet
	// Flags: [Event|Protected|BlueprintEvent]
	void OnListItemObjectSet(struct UObject* ListItemObject); // Offset: 0x101364770 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UI_Lobby_Banner_Slot.UI_Lobby_Banner_Slot_C.ExecuteUbergraph_UI_Lobby_Banner_Slot
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_UI_Lobby_Banner_Slot(int32_t EntryPoint); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x4)
};

