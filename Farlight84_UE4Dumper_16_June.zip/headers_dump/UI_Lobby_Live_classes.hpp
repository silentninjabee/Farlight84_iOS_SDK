#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_Lobby_Live.UI_Lobby_Live_C
// Size: 0x279 // Inherited bytes: 0x260
struct UUI_Lobby_Live_C : UUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x260 // Size: 0x08
	struct UWidgetAnimation* Loop_Anim; // Offset: 0x268 // Size: 0x08
	struct USolarRedHint_General_C* SolarHintPoint_Red; // Offset: 0x270 // Size: 0x08
	bool HintPoint; // Offset: 0x278 // Size: 0x01

	// Functions

	// Object Name: Function UI_Lobby_Live.UI_Lobby_Live_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void PreConstruct(bool IsDesignTime); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Lobby_Live.UI_Lobby_Live_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Construct(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Lobby_Live.UI_Lobby_Live_C.ExecuteUbergraph_UI_Lobby_Live
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_UI_Lobby_Live(int32_t EntryPoint); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x4)
};

