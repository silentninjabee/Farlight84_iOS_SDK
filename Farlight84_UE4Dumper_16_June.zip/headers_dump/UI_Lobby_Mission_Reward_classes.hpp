#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_Lobby_Mission_Reward.UI_Lobby_Mission_Reward_C
// Size: 0x368 // Inherited bytes: 0x340
struct UUI_Lobby_Mission_Reward_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x340 // Size: 0x08
	struct UWidgetAnimation* Anim_Enter; // Offset: 0x348 // Size: 0x08
	struct UButton* Btn_MissionReward; // Offset: 0x350 // Size: 0x08
	struct UImage* Img_Icon; // Offset: 0x358 // Size: 0x08
	struct USolarTextBlock* Txt_GameRecommend; // Offset: 0x360 // Size: 0x08

	// Functions

	// Object Name: Function UI_Lobby_Mission_Reward.UI_Lobby_Mission_Reward_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	struct FString GetModuleName(); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UI_Lobby_Mission_Reward.UI_Lobby_Mission_Reward_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Construct(); // Offset: 0x101364770 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Lobby_Mission_Reward.UI_Lobby_Mission_Reward_C.ExecuteUbergraph_UI_Lobby_Mission_Reward
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_UI_Lobby_Mission_Reward(int32_t EntryPoint); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x4)
};

