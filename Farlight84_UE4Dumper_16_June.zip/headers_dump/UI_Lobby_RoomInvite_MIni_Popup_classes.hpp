#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_Lobby_RoomInvite_MIni_Popup.UI_Lobby_RoomInvite_MIni_Popup_C
// Size: 0x492 // Inherited bytes: 0x260
struct UUI_Lobby_RoomInvite_MIni_Popup_C : UUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x260 // Size: 0x08
	struct UWidgetAnimation* Anim_Loop; // Offset: 0x268 // Size: 0x08
	struct UWidgetAnimation* Anim_Enter; // Offset: 0x270 // Size: 0x08
	struct USolarButton* Btn_Join_Common; // Offset: 0x278 // Size: 0x08
	struct USolarButton* Btn_Join_League; // Offset: 0x280 // Size: 0x08
	struct USolarButton* Btn_Joining; // Offset: 0x288 // Size: 0x08
	struct UButton* Btn_Player; // Offset: 0x290 // Size: 0x08
	struct UButton* Btn_Player_2; // Offset: 0x298 // Size: 0x08
	struct UButton* Btn_Player_3; // Offset: 0x2a0 // Size: 0x08
	struct UButton* Btn_Player_4; // Offset: 0x2a8 // Size: 0x08
	struct UButton* Btn_Player_5; // Offset: 0x2b0 // Size: 0x08
	struct USolarButton* Btn_Watch; // Offset: 0x2b8 // Size: 0x08
	struct UHorizontalBox* HorizentalBox_Match; // Offset: 0x2c0 // Size: 0x08
	struct UHorizontalBox* HorizentalBox_Spectator; // Offset: 0x2c8 // Size: 0x08
	struct UHorizontalBox* HorizontalBox_Join_2; // Offset: 0x2d0 // Size: 0x08
	struct UHorizontalBox* HorizontalBox_Joining_2; // Offset: 0x2d8 // Size: 0x08
	struct UHorizontalBox* HorizontalBox_Player; // Offset: 0x2e0 // Size: 0x08
	struct UHorizontalBox* HorizontalBox_Progress_Time; // Offset: 0x2e8 // Size: 0x08
	struct UHorizontalBox* HorizontalBox_Title_Common; // Offset: 0x2f0 // Size: 0x08
	struct UHorizontalBox* HorizontalBox_Title_League; // Offset: 0x2f8 // Size: 0x08
	struct UHorizontalBox* HorizontalBox_Watch; // Offset: 0x300 // Size: 0x08
	struct UImage* Img_BG_Invitation; // Offset: 0x308 // Size: 0x08
	struct UImage* Img_BG_Light; // Offset: 0x310 // Size: 0x08
	struct UImage* Img_BG_Light_01; // Offset: 0x318 // Size: 0x08
	struct UImage* Img_Btn_Join; // Offset: 0x320 // Size: 0x08
	struct UImage* Img_Btn_Join_2; // Offset: 0x328 // Size: 0x08
	struct UImage* Img_Btn_Joining_Close; // Offset: 0x330 // Size: 0x08
	struct UImage* Img_Btn_Watch; // Offset: 0x338 // Size: 0x08
	struct UImage* Img_Join_Common_Light; // Offset: 0x340 // Size: 0x08
	struct UImage* Img_Join_Light; // Offset: 0x348 // Size: 0x08
	struct USolarImageURL* Img_League_Icon; // Offset: 0x350 // Size: 0x08
	struct UImage* Img_Time_Icon; // Offset: 0x358 // Size: 0x08
	struct UImage* Img_Title_BG; // Offset: 0x360 // Size: 0x08
	struct UImage* Img_Title_BG_2; // Offset: 0x368 // Size: 0x08
	struct UImage* Img_Title_BG_3; // Offset: 0x370 // Size: 0x08
	struct UImage* Img_Watch_Light; // Offset: 0x378 // Size: 0x08
	struct UOverlay* Overlay_Avatar; // Offset: 0x380 // Size: 0x08
	struct UOverlay* Overlay_Avatar_2; // Offset: 0x388 // Size: 0x08
	struct UOverlay* Overlay_Avatar_3; // Offset: 0x390 // Size: 0x08
	struct UOverlay* Overlay_Avatar_4; // Offset: 0x398 // Size: 0x08
	struct UOverlay* Overlay_Avatar_5; // Offset: 0x3a0 // Size: 0x08
	struct UOverlay* Overlay_Cup; // Offset: 0x3a8 // Size: 0x08
	struct UCanvasPanel* Panel_Info_CreateRoom; // Offset: 0x3b0 // Size: 0x08
	struct UCanvasPanel* Panel_Info_Invitation; // Offset: 0x3b8 // Size: 0x08
	struct UCanvasPanel* Panel_Pop_Common; // Offset: 0x3c0 // Size: 0x08
	struct UCanvasPanel* Panel_Pop_League; // Offset: 0x3c8 // Size: 0x08
	struct USolarTextBlock* Txt_Capacity; // Offset: 0x3d0 // Size: 0x08
	struct USolarTextBlock* Txt_GameMode; // Offset: 0x3d8 // Size: 0x08
	struct UTickerWidget_C* Txt_Invitation; // Offset: 0x3e0 // Size: 0x08
	struct USolarTextBlock* Txt_Invitation_2; // Offset: 0x3e8 // Size: 0x08
	struct USolarTextBlock* Txt_Join; // Offset: 0x3f0 // Size: 0x08
	struct USolarTextBlock* Txt_Join_Common; // Offset: 0x3f8 // Size: 0x08
	struct USolarTextBlock* Txt_Joining; // Offset: 0x400 // Size: 0x08
	struct USolarTextBlock* Txt_League_Name_2; // Offset: 0x408 // Size: 0x08
	struct USolarTextBlock* Txt_Map; // Offset: 0x410 // Size: 0x08
	struct UTextBlock* Txt_OBCurr; // Offset: 0x418 // Size: 0x08
	struct UTextBlock* Txt_OBCurr_2; // Offset: 0x420 // Size: 0x08
	struct UTextBlock* Txt_OBCurr_4; // Offset: 0x428 // Size: 0x08
	struct USolarTextBlock* Txt_OBTotal; // Offset: 0x430 // Size: 0x08
	struct USolarTextBlock* Txt_PlayerIn; // Offset: 0x438 // Size: 0x08
	struct USolarTextBlock* Txt_Progress_Time; // Offset: 0x440 // Size: 0x08
	struct USolarTextBlock* Txt_RoomName; // Offset: 0x448 // Size: 0x08
	struct USolarTextBlock* Txt_Watch; // Offset: 0x450 // Size: 0x08
	struct UUI_Component_Close_C* UI_Component_Close; // Offset: 0x458 // Size: 0x08
	struct UUI_Component_NationalFlag_C* UI_Component_NationalFlag_2; // Offset: 0x460 // Size: 0x08
	struct UUI_Component_PlayerHead_C* UI_Component_PlayerHead; // Offset: 0x468 // Size: 0x08
	struct UUI_Component_PlayerHead_C* UI_Component_PlayerHead_2; // Offset: 0x470 // Size: 0x08
	struct UUI_Component_PlayerHead_C* UI_Component_PlayerHead_3; // Offset: 0x478 // Size: 0x08
	struct UUI_Component_PlayerHead_C* UI_Component_PlayerHead_4; // Offset: 0x480 // Size: 0x08
	struct UUI_Component_PlayerHead_C* UI_Component_PlayerHead_5; // Offset: 0x488 // Size: 0x08
	enum class T_Type_System_Push Pop_Type; // Offset: 0x490 // Size: 0x01
	enum class T_Type_Button Btn_Type; // Offset: 0x491 // Size: 0x01

	// Functions

	// Object Name: Function UI_Lobby_RoomInvite_MIni_Popup.UI_Lobby_RoomInvite_MIni_Popup_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	struct FString GetModuleName(); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UI_Lobby_RoomInvite_MIni_Popup.UI_Lobby_RoomInvite_MIni_Popup_C.Update_Btn
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void Update_Btn(enum class T_Type_Button NewParam); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Lobby_RoomInvite_MIni_Popup.UI_Lobby_RoomInvite_MIni_Popup_C.SetType
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SetType(enum class T_Type_System_Push Type); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Lobby_RoomInvite_MIni_Popup.UI_Lobby_RoomInvite_MIni_Popup_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void PreConstruct(bool IsDesignTime); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Lobby_RoomInvite_MIni_Popup.UI_Lobby_RoomInvite_MIni_Popup_C.ExecuteUbergraph_UI_Lobby_RoomInvite_MIni_Popup
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_UI_Lobby_RoomInvite_MIni_Popup(int32_t EntryPoint); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x4)
};

