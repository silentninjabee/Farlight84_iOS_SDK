#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_Lobby_Social_Entrance.UI_Lobby_Social_Entrance_C
// Size: 0x3d9 // Inherited bytes: 0x340
struct UUI_Lobby_Social_Entrance_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x340 // Size: 0x08
	struct UButton* Btn_Discord; // Offset: 0x348 // Size: 0x08
	struct UButton* Btn_Facebook; // Offset: 0x350 // Size: 0x08
	struct UButton* Btn_Instagram; // Offset: 0x358 // Size: 0x08
	struct UButton* Btn_LiveVideo; // Offset: 0x360 // Size: 0x08
	struct UButton* Btn_TikTok; // Offset: 0x368 // Size: 0x08
	struct UButton* Btn_YouTube; // Offset: 0x370 // Size: 0x08
	struct UCanvasPanel* Discord; // Offset: 0x378 // Size: 0x08
	struct UCanvasPanel* FACEBOOK; // Offset: 0x380 // Size: 0x08
	struct UCanvasPanel* Instagram; // Offset: 0x388 // Size: 0x08
	struct UCanvasPanel* Panel_LiveVideo; // Offset: 0x390 // Size: 0x08
	struct USolarRedHint_General_C* SolarRedHint_General; // Offset: 0x398 // Size: 0x08
	struct USolarRedHint_General_C* SolarRedHint_General_49; // Offset: 0x3a0 // Size: 0x08
	struct USolarRedHint_General_C* SolarRedHint_General_96; // Offset: 0x3a8 // Size: 0x08
	struct USolarRedHint_General_C* SolarRedHint_Instagram; // Offset: 0x3b0 // Size: 0x08
	struct USolarRedHint_General_C* SolarRedHint_TikTok; // Offset: 0x3b8 // Size: 0x08
	struct UCanvasPanel* TikTok; // Offset: 0x3c0 // Size: 0x08
	struct UUI_Lobby_Live_C* UI_Lobby_Live; // Offset: 0x3c8 // Size: 0x08
	struct UCanvasPanel* YouTube; // Offset: 0x3d0 // Size: 0x08
	bool isShowGuide; // Offset: 0x3d8 // Size: 0x01

	// Functions

	// Object Name: Function UI_Lobby_Social_Entrance.UI_Lobby_Social_Entrance_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	struct FString GetModuleName(); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UI_Lobby_Social_Entrance.UI_Lobby_Social_Entrance_C.ShowGuide
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void ShowGuide(bool ShowGuide); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Lobby_Social_Entrance.UI_Lobby_Social_Entrance_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void PreConstruct(bool IsDesignTime); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Lobby_Social_Entrance.UI_Lobby_Social_Entrance_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Construct(); // Offset: 0x101364770 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Lobby_Social_Entrance.UI_Lobby_Social_Entrance_C.ExecuteUbergraph_UI_Lobby_Social_Entrance
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_UI_Lobby_Social_Entrance(int32_t EntryPoint); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x4)
};

