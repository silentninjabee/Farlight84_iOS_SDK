#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_MapMark_ReviveTeammates.UI_MapMark_ReviveTeammates_C
// Size: 0x3f8 // Inherited bytes: 0x380
struct UUI_MapMark_ReviveTeammates_C : UMapMarkBase {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x380 // Size: 0x08
	struct UWidgetAnimation* Occupy_Loop_Anim; // Offset: 0x388 // Size: 0x08
	struct UImage* Img_BG; // Offset: 0x390 // Size: 0x08
	struct UImage* img_Light; // Offset: 0x398 // Size: 0x08
	struct UImage* img_Light_2; // Offset: 0x3a0 // Size: 0x08
	struct UImage* Img_Revival; // Offset: 0x3a8 // Size: 0x08
	struct UVerticalBox* Panel; // Offset: 0x3b0 // Size: 0x08
	struct UScaleBox* ScaleBox_1; // Offset: 0x3b8 // Size: 0x08
	int32_t HideDistance; // Offset: 0x3c0 // Size: 0x04
	char pad_0x3C4[0x4]; // Offset: 0x3c4 // Size: 0x04
	struct TArray<struct FLinearColor> Color_2; // Offset: 0x3c8 // Size: 0x10
	struct TArray<struct FLinearColor> Color_3; // Offset: 0x3d8 // Size: 0x10
	struct FString PlayerId; // Offset: 0x3e8 // Size: 0x10

	// Functions

	// Object Name: Function UI_MapMark_ReviveTeammates.UI_MapMark_ReviveTeammates_C.Set Player ID And Change Color
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void Set Player ID And Change Color(struct FString PlayerId); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UI_MapMark_ReviveTeammates.UI_MapMark_ReviveTeammates_C.SetColor
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetColor(char Index); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_MapMark_ReviveTeammates.UI_MapMark_ReviveTeammates_C.SetIcon
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetIcon(struct UWidget* Content, int32_t ); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0xc)

	// Object Name: Function UI_MapMark_ReviveTeammates.UI_MapMark_ReviveTeammates_C.Event_PlayAnim
	// Flags: [BlueprintCallable|BlueprintEvent]
	void Event_PlayAnim(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_MapMark_ReviveTeammates.UI_MapMark_ReviveTeammates_C.Tick
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x3c)

	// Object Name: Function UI_MapMark_ReviveTeammates.UI_MapMark_ReviveTeammates_C.ExecuteUbergraph_UI_MapMark_ReviveTeammates
	// Flags: [Final|UbergraphFunction|HasDefaults]
	void ExecuteUbergraph_UI_MapMark_ReviveTeammates(int32_t EntryPoint); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x4)
};

