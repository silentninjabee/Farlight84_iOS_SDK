#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_Notice.UI_Notice_C
// Size: 0x3a8 // Inherited bytes: 0x340
struct UUI_Notice_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x340 // Size: 0x08
	struct UWidgetAnimation* Out; // Offset: 0x348 // Size: 0x08
	struct UWidgetAnimation* In; // Offset: 0x350 // Size: 0x08
	struct UImage* Img_Icon_3; // Offset: 0x358 // Size: 0x08
	struct UImage* Img_Icon_bg_3; // Offset: 0x360 // Size: 0x08
	struct URichTextBlock* Text; // Offset: 0x368 // Size: 0x08
	struct TArray<struct FS_Notice> Queue; // Offset: 0x370 // Size: 0x10
	bool QueueFinished; // Offset: 0x380 // Size: 0x01
	char pad_0x381[0x7]; // Offset: 0x381 // Size: 0x07
	struct FS_Notice ; // Offset: 0x388 // Size: 0x20

	// Functions

	// Object Name: Function UI_Notice.UI_Notice_C.SetStyle
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SetStyle(struct FS_Notice& S_Notice); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x20)

	// Object Name: Function UI_Notice.UI_Notice_C.
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void (struct FS_Notice& S_Notice); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x20)

	// Object Name: Function UI_Notice.UI_Notice_C.
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void (); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Notice.UI_Notice_C.
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void (struct FS_Notice& S_Notice); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x20)

	// Object Name: Function UI_Notice.UI_Notice_C.
	// Flags: [BlueprintCallable|BlueprintEvent]
	void (struct FS_Notice ); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x20)

	// Object Name: Function UI_Notice.UI_Notice_C.ShowNext
	// Flags: [BlueprintCallable|BlueprintEvent]
	void ShowNext(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Notice.UI_Notice_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void PreConstruct(bool IsDesignTime); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Notice.UI_Notice_C.ExecuteUbergraph_UI_Notice
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_UI_Notice(int32_t EntryPoint); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x4)
};

