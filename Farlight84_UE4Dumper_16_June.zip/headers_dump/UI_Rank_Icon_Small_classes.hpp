#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_Rank_Icon_Small.UI_Rank_Icon_Small_C
// Size: 0x35c // Inherited bytes: 0x340
struct UUI_Rank_Icon_Small_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x340 // Size: 0x08
	struct UImage* Img_Rank; // Offset: 0x348 // Size: 0x08
	struct UImage* Img_Rank_Word; // Offset: 0x350 // Size: 0x08
	int32_t LevelID; // Offset: 0x358 // Size: 0x04

	// Functions

	// Object Name: Function UI_Rank_Icon_Small.UI_Rank_Icon_Small_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	struct FString GetModuleName(); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UI_Rank_Icon_Small.UI_Rank_Icon_Small_C.FormatView
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void FormatView(int32_t LevelID); // Offset: 0x101364770 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UI_Rank_Icon_Small.UI_Rank_Icon_Small_C.SetRankIconView
	// Flags: [BlueprintCallable|BlueprintEvent]
	void SetRankIconView(int32_t Param); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UI_Rank_Icon_Small.UI_Rank_Icon_Small_C.ExecuteUbergraph_UI_Rank_Icon_Small
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_UI_Rank_Icon_Small(int32_t EntryPoint); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x4)
};

