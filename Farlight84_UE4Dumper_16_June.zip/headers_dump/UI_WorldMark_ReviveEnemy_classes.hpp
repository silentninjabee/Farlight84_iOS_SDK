#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_WorldMark_ReviveEnemy.UI_WorldMark_ReviveEnemy_C
// Size: 0x408 // Inherited bytes: 0x398
struct UUI_WorldMark_ReviveEnemy_C : UActorMarkBase {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x398 // Size: 0x08
	struct UImage* Img_BG; // Offset: 0x3a0 // Size: 0x08
	struct UImage* img_Light; // Offset: 0x3a8 // Size: 0x08
	struct UImage* Img_Revival; // Offset: 0x3b0 // Size: 0x08
	struct UScaleBox* ScaleBox_1; // Offset: 0x3b8 // Size: 0x08
	int32_t HideDistance; // Offset: 0x3c0 // Size: 0x04
	char pad_0x3C4[0x4]; // Offset: 0x3c4 // Size: 0x04
	struct TArray<struct FLinearColor> Color_2; // Offset: 0x3c8 // Size: 0x10
	struct TArray<struct FLinearColor> Color_3; // Offset: 0x3d8 // Size: 0x10
	struct FString PlayerId; // Offset: 0x3e8 // Size: 0x10
	struct FString DistanceLocalString; // Offset: 0x3f8 // Size: 0x10

	// Functions

	// Object Name: Function UI_WorldMark_ReviveEnemy.UI_WorldMark_ReviveEnemy_C.GetVisibility_1
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	enum class ESlateVisibility GetVisibility_1(); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_WorldMark_ReviveEnemy.UI_WorldMark_ReviveEnemy_C.Get_Distance_Text
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	struct FText Get_Distance_Text(); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x18)

	// Object Name: Function UI_WorldMark_ReviveEnemy.UI_WorldMark_ReviveEnemy_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void PreConstruct(bool IsDesignTime); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_WorldMark_ReviveEnemy.UI_WorldMark_ReviveEnemy_C.OnInitialized
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void OnInitialized(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_WorldMark_ReviveEnemy.UI_WorldMark_ReviveEnemy_C.ExecuteUbergraph_UI_WorldMark_ReviveEnemy
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_UI_WorldMark_ReviveEnemy(int32_t EntryPoint); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x4)
};

