#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_WorldMark_ReviveTeammatesDeathbox.UI_WorldMark_ReviveTeammatesDeathbox_C
// Size: 0x420 // Inherited bytes: 0x398
struct UUI_WorldMark_ReviveTeammatesDeathbox_C : UActorMarkBase {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x398 // Size: 0x08
	struct UTextBlock* Distance; // Offset: 0x3a0 // Size: 0x08
	struct UImage* Img_BG; // Offset: 0x3a8 // Size: 0x08
	struct UImage* img_Light; // Offset: 0x3b0 // Size: 0x08
	struct UImage* img_Light_2; // Offset: 0x3b8 // Size: 0x08
	struct UImage* Img_Revival; // Offset: 0x3c0 // Size: 0x08
	struct UVerticalBox* Panel; // Offset: 0x3c8 // Size: 0x08
	struct UScaleBox* ScaleBox_1; // Offset: 0x3d0 // Size: 0x08
	int32_t HideDistance; // Offset: 0x3d8 // Size: 0x04
	char pad_0x3DC[0x4]; // Offset: 0x3dc // Size: 0x04
	struct TArray<struct FLinearColor> Color_2; // Offset: 0x3e0 // Size: 0x10
	struct TArray<struct FLinearColor> Color_3; // Offset: 0x3f0 // Size: 0x10
	struct FString PlayerId; // Offset: 0x400 // Size: 0x10
	struct FString DistanceLocalString; // Offset: 0x410 // Size: 0x10

	// Functions

	// Object Name: Function UI_WorldMark_ReviveTeammatesDeathbox.UI_WorldMark_ReviveTeammatesDeathbox_C.Set Player ID And Change Color
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void Set Player ID And Change Color(struct FString PlayerId); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UI_WorldMark_ReviveTeammatesDeathbox.UI_WorldMark_ReviveTeammatesDeathbox_C.SetColor
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SetColor(char Index); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_WorldMark_ReviveTeammatesDeathbox.UI_WorldMark_ReviveTeammatesDeathbox_C.GetVisibility_1
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	enum class ESlateVisibility GetVisibility_1(); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_WorldMark_ReviveTeammatesDeathbox.UI_WorldMark_ReviveTeammatesDeathbox_C.Get_Distance_Text
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	struct FText Get_Distance_Text(); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x18)

	// Object Name: Function UI_WorldMark_ReviveTeammatesDeathbox.UI_WorldMark_ReviveTeammatesDeathbox_C.SetIcon
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetIcon(struct UWidget* Content, int32_t ); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0xc)

	// Object Name: Function UI_WorldMark_ReviveTeammatesDeathbox.UI_WorldMark_ReviveTeammatesDeathbox_C.Tick
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Offset: 0x102f8211c // Return & Params: Num(2) Size(0x3c)

	// Object Name: Function UI_WorldMark_ReviveTeammatesDeathbox.UI_WorldMark_ReviveTeammatesDeathbox_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void PreConstruct(bool IsDesignTime); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_WorldMark_ReviveTeammatesDeathbox.UI_WorldMark_ReviveTeammatesDeathbox_C.OnInitialized
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void OnInitialized(); // Offset: 0x102f8211c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_WorldMark_ReviveTeammatesDeathbox.UI_WorldMark_ReviveTeammatesDeathbox_C.ExecuteUbergraph_UI_WorldMark_ReviveTeammatesDeathbox
	// Flags: [Final|UbergraphFunction|HasDefaults]
	void ExecuteUbergraph_UI_WorldMark_ReviveTeammatesDeathbox(int32_t EntryPoint); // Offset: 0x102f8211c // Return & Params: Num(1) Size(0x4)
};

