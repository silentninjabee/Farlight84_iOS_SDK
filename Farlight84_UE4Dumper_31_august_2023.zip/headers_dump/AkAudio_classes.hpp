#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class AkAudio.AkPortalComponent
// Size: 0x400 // Inherited bytes: 0x350
struct UAkPortalComponent : USceneComponent {
	// Fields
	bool bDynamic; // Offset: 0x344 // Size: 0x01
	enum class AkAcousticPortalState InitialState; // Offset: 0x345 // Size: 0x01
	float ObstructionRefreshInterval; // Offset: 0x348 // Size: 0x04
	enum class ECollisionChannel ObstructionCollisionChannel; // Offset: 0x34c // Size: 0x01
	char pad_0x357[0xa9]; // Offset: 0x357 // Size: 0xa9

	// Functions

	// Object Name: Function AkAudio.AkPortalComponent.PortalPlacementValid
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool PortalPlacementValid(); // Offset: 0x101d8702c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AkAudio.AkPortalComponent.OpenPortal
	// Flags: [Final|Native|Public|BlueprintCallable]
	void OpenPortal(); // Offset: 0x101d870fc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AkAudio.AkPortalComponent.GetPrimitiveParent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UPrimitiveComponent* GetPrimitiveParent(); // Offset: 0x101d87080 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function AkAudio.AkPortalComponent.GetCurrentState
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	enum class AkAcousticPortalState GetCurrentState(); // Offset: 0x101d870b4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AkAudio.AkPortalComponent.ClosePortal
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClosePortal(); // Offset: 0x101d870e8 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class AkAudio.AkAcousticPortal
// Size: 0x270 // Inherited bytes: 0x260
struct AAkAcousticPortal : AVolume {
	// Fields
	struct UAkPortalComponent* Portal; // Offset: 0x260 // Size: 0x08
	enum class AkAcousticPortalState InitialState; // Offset: 0x268 // Size: 0x01
	bool bRequiresStateMigration; // Offset: 0x269 // Size: 0x01
	char pad_0x26A[0x6]; // Offset: 0x26a // Size: 0x06

	// Functions

	// Object Name: Function AkAudio.AkAcousticPortal.OpenPortal
	// Flags: [Final|Native|Public|BlueprintCallable]
	void OpenPortal(); // Offset: 0x101d87694 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AkAudio.AkAcousticPortal.GetCurrentState
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	enum class AkAcousticPortalState GetCurrentState(); // Offset: 0x101d8764c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AkAudio.AkAcousticPortal.ClosePortal
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClosePortal(); // Offset: 0x101d87680 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class AkAudio.AkAudioType
// Size: 0x40 // Inherited bytes: 0x28
struct UAkAudioType : UObject {
	// Fields
	uint32_t ShortID; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
	struct TArray<struct UObject*> UserData; // Offset: 0x30 // Size: 0x10
};

// Object Name: Class AkAudio.AkAcousticTexture
// Size: 0x40 // Inherited bytes: 0x40
struct UAkAcousticTexture : UAkAudioType {
};

// Object Name: Class AkAudio.AkAcousticTextureSetComponent
// Size: 0x360 // Inherited bytes: 0x350
struct UAkAcousticTextureSetComponent : USceneComponent {
	// Fields
	char pad_0x350[0x10]; // Offset: 0x350 // Size: 0x10
};

// Object Name: Class AkAudio.AkAmbientSound
// Size: 0x280 // Inherited bytes: 0x228
struct AAkAmbientSound : AActor {
	// Fields
	struct UAkAudioEvent* AkAudioEvent; // Offset: 0x228 // Size: 0x08
	struct UAkComponent* AkComponent; // Offset: 0x230 // Size: 0x08
	bool StopWhenOwnerIsDestroyed; // Offset: 0x238 // Size: 0x01
	bool AutoPost; // Offset: 0x239 // Size: 0x01
	char pad_0x23A[0x46]; // Offset: 0x23a // Size: 0x46

	// Functions

	// Object Name: Function AkAudio.AkAmbientSound.StopAmbientSound
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void StopAmbientSound(); // Offset: 0x101d87fe0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AkAudio.AkAmbientSound.StartAmbientSound
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void StartAmbientSound(); // Offset: 0x101d87ff4 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class AkAudio.AkAndroidInitializationSettings
// Size: 0xf8 // Inherited bytes: 0x28
struct UAkAndroidInitializationSettings : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08
	struct FAkCommonInitializationSettingsWithSampleRate CommonSettings; // Offset: 0x30 // Size: 0x68
	struct FAkCommunicationSettingsWithSystemInitialization CommunicationSettings; // Offset: 0x98 // Size: 0x28
	struct FAkAndroidAdvancedInitializationSettings AdvancedSettings; // Offset: 0xc0 // Size: 0x38

	// Functions

	// Object Name: Function AkAudio.AkAndroidInitializationSettings.MigrateMultiCoreRendering
	// Flags: [Final|Native|Public]
	void MigrateMultiCoreRendering(bool NewValue); // Offset: 0x101d88690 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class AkAudio.AkPlatformInfo
// Size: 0x70 // Inherited bytes: 0x28
struct UAkPlatformInfo : UObject {
	// Fields
	char pad_0x28[0x48]; // Offset: 0x28 // Size: 0x48
};

// Object Name: Class AkAudio.AkAndroidPlatformInfo
// Size: 0x70 // Inherited bytes: 0x70
struct UAkAndroidPlatformInfo : UAkPlatformInfo {
};

// Object Name: Class AkAudio.AkAssetData
// Size: 0x60 // Inherited bytes: 0x28
struct UAkAssetData : UObject {
	// Fields
	uint32_t CachedHash; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x34]; // Offset: 0x2c // Size: 0x34
};

// Object Name: Class AkAudio.AkAssetDataWithMedia
// Size: 0x70 // Inherited bytes: 0x60
struct UAkAssetDataWithMedia : UAkAssetData {
	// Fields
	struct TArray<struct UAkMediaAsset*> MediaList; // Offset: 0x60 // Size: 0x10
};

// Object Name: Class AkAudio.AkAssetPlatformData
// Size: 0x30 // Inherited bytes: 0x28
struct UAkAssetPlatformData : UObject {
	// Fields
	struct UAkAssetData* CurrentAssetData; // Offset: 0x28 // Size: 0x08
};

// Object Name: Class AkAudio.AkAssetBase
// Size: 0x50 // Inherited bytes: 0x40
struct UAkAssetBase : UAkAudioType {
	// Fields
	struct UAkAssetPlatformData* PlatformAssetData; // Offset: 0x40 // Size: 0x08
	char pad_0x48[0x8]; // Offset: 0x48 // Size: 0x08
};

// Object Name: Class AkAudio.AkAudioBank
// Size: 0x120 // Inherited bytes: 0x50
struct UAkAudioBank : UAkAssetBase {
	// Fields
	bool AutoLoad; // Offset: 0x49 // Size: 0x01
	struct TMap<struct FString, struct TSoftObjectPtr<UAkAssetPlatformData>> LocalizedPlatformAssetDataMap; // Offset: 0x50 // Size: 0x50
	struct TSet<struct TSoftObjectPtr<UAkAudioEvent>> LinkedAkEvents; // Offset: 0xa0 // Size: 0x50
	struct UAkAssetPlatformData* CurrentLocalizedPlatformAssetData; // Offset: 0xf0 // Size: 0x08
	char pad_0xF9[0x27]; // Offset: 0xf9 // Size: 0x27
};

// Object Name: Class AkAudio.AkAssetDataSwitchContainerData
// Size: 0x78 // Inherited bytes: 0x28
struct UAkAssetDataSwitchContainerData : UObject {
	// Fields
	struct TSoftObjectPtr<UAkGroupValue> GroupValue; // Offset: 0x28 // Size: 0x28
	struct UAkGroupValue* DefaultGroupValue; // Offset: 0x50 // Size: 0x08
	struct TArray<struct UAkMediaAsset*> MediaList; // Offset: 0x58 // Size: 0x10
	struct TArray<struct UAkAssetDataSwitchContainerData*> Children; // Offset: 0x68 // Size: 0x10
};

// Object Name: Class AkAudio.AkAssetDataSwitchContainer
// Size: 0x88 // Inherited bytes: 0x70
struct UAkAssetDataSwitchContainer : UAkAssetDataWithMedia {
	// Fields
	struct TArray<struct UAkAssetDataSwitchContainerData*> SwitchContainers; // Offset: 0x70 // Size: 0x10
	struct UAkGroupValue* DefaultGroupValue; // Offset: 0x80 // Size: 0x08
};

// Object Name: Class AkAudio.AkAudioEventData
// Size: 0x268 // Inherited bytes: 0x88
struct UAkAudioEventData : UAkAssetDataSwitchContainer {
	// Fields
	float MaxAttenuationRadius; // Offset: 0x88 // Size: 0x04
	bool IsInfinite; // Offset: 0x8c // Size: 0x01
	char pad_0x8D[0x3]; // Offset: 0x8d // Size: 0x03
	float MinimumDuration; // Offset: 0x90 // Size: 0x04
	float MaximumDuration; // Offset: 0x94 // Size: 0x04
	struct TMap<struct FString, struct UAkAssetDataSwitchContainer*> LocalizedMedia; // Offset: 0x98 // Size: 0x50
	struct TSet<struct UAkAudioEvent*> PostedEvents; // Offset: 0xe8 // Size: 0x50
	struct TSet<struct UAkAuxBus*> UserDefinedSends; // Offset: 0x138 // Size: 0x50
	struct TSet<struct UAkTrigger*> PostedTriggers; // Offset: 0x188 // Size: 0x50
	struct TSet<struct UAkGroupValue*> GroupValues; // Offset: 0x1d8 // Size: 0x50
	char pad_0x228[0x40]; // Offset: 0x228 // Size: 0x40
};

// Object Name: Class AkAudio.AkAudioEvent
// Size: 0xe0 // Inherited bytes: 0x50
struct UAkAudioEvent : UAkAssetBase {
	// Fields
	struct TMap<struct FString, struct TSoftObjectPtr<UAkAssetPlatformData>> LocalizedPlatformAssetDataMap; // Offset: 0x50 // Size: 0x50
	struct UAkAudioBank* RequiredBank; // Offset: 0xa0 // Size: 0x08
	char pad_0xA8[0x8]; // Offset: 0xa8 // Size: 0x08
	struct UAkAssetPlatformData* CurrentLocalizedPlatformData; // Offset: 0xb0 // Size: 0x08
	float MaxAttenuationRadius; // Offset: 0xb8 // Size: 0x04
	bool IsInfinite; // Offset: 0xbc // Size: 0x01
	char pad_0xBD[0x3]; // Offset: 0xbd // Size: 0x03
	float MinimumDuration; // Offset: 0xc0 // Size: 0x04
	float MaximumDuration; // Offset: 0xc4 // Size: 0x04
	char pad_0xC8[0x18]; // Offset: 0xc8 // Size: 0x18

	// Functions

	// Object Name: Function AkAudio.AkAudioEvent.GetMinimumDuration
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetMinimumDuration(); // Offset: 0x101d89e3c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function AkAudio.AkAudioEvent.GetMaximumDuration
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetMaximumDuration(); // Offset: 0x101d89e08 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function AkAudio.AkAudioEvent.GetMaxAttenuationRadius
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetMaxAttenuationRadius(); // Offset: 0x101d89ea4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function AkAudio.AkAudioEvent.GetIsInfinite
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool GetIsInfinite(); // Offset: 0x101d89e70 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class AkAudio.AkGameObject
// Size: 0x370 // Inherited bytes: 0x350
struct UAkGameObject : USceneComponent {
	// Fields
	struct UAkAudioEvent* AkAudioEvent; // Offset: 0x348 // Size: 0x08
	struct FString EventName; // Offset: 0x350 // Size: 0x10
	char pad_0x368[0x8]; // Offset: 0x368 // Size: 0x08

	// Functions

	// Object Name: Function AkAudio.AkGameObject.Stop
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void Stop(); // Offset: 0x101d902ec // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AkAudio.AkGameObject.SetRTPCValue
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|Const]
	void SetRTPCValue(struct UAkRtpc* RTPCValue, float Value, int32_t InterpolationTimeMs, struct FString RTPC); // Offset: 0x101d90110 // Return & Params: Num(4) Size(0x20)

	// Object Name: Function AkAudio.AkGameObject.PostAssociatedAkEventAsync
	// Flags: [BlueprintCosmetic|Native|Public|HasOutParms|BlueprintCallable]
	void PostAssociatedAkEventAsync(struct UObject* WorldContextObject, int32_t CallbackMask, struct FDelegate& PostEventCallback, struct TArray<struct FAkExternalSourceInfo>& ExternalSources, struct FLatentActionInfo LatentInfo, int32_t& PlayingID); // Offset: 0x101d9086c // Return & Params: Num(6) Size(0x4c)

	// Object Name: Function AkAudio.AkGameObject.PostAssociatedAkEvent
	// Flags: [BlueprintCosmetic|Native|Public|HasOutParms|BlueprintCallable]
	int32_t PostAssociatedAkEvent(int32_t CallbackMask, struct FDelegate& PostEventCallback, struct TArray<struct FAkExternalSourceInfo>& ExternalSources); // Offset: 0x101d90b28 // Return & Params: Num(4) Size(0x2c)

	// Object Name: Function AkAudio.AkGameObject.PostAkEventAsync
	// Flags: [BlueprintCosmetic|Native|Public|HasOutParms|BlueprintCallable]
	void PostAkEventAsync(struct UObject* WorldContextObject, struct UAkAudioEvent* AkEvent, int32_t& PlayingID, int32_t CallbackMask, struct FDelegate& PostEventCallback, struct TArray<struct FAkExternalSourceInfo>& ExternalSources, struct FLatentActionInfo LatentInfo); // Offset: 0x101d90300 // Return & Params: Num(7) Size(0x50)

	// Object Name: Function AkAudio.AkGameObject.PostAkEvent
	// Flags: [BlueprintCosmetic|Native|Public|HasOutParms|BlueprintCallable]
	int32_t PostAkEvent(struct UAkAudioEvent* AkEvent, int32_t CallbackMask, struct FDelegate& PostEventCallback, struct TArray<struct FAkExternalSourceInfo>& ExternalSources, struct FString in_EventName); // Offset: 0x101d90604 // Return & Params: Num(6) Size(0x44)

	// Object Name: Function AkAudio.AkGameObject.GetRTPCValue
	// Flags: [Final|BlueprintCosmetic|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetRTPCValue(struct UAkRtpc* RTPCValue, enum class ERTPCValueType InputValueType, float& Value, enum class ERTPCValueType& OutputValueType, struct FString RTPC, int32_t PlayingID); // Offset: 0x101d8fe98 // Return & Params: Num(6) Size(0x2c)
};

// Object Name: Class AkAudio.AkComponent
// Size: 0x530 // Inherited bytes: 0x370
struct UAkComponent : UAkGameObject {
	// Fields
	bool bUseSpatialAudio; // Offset: 0x362 // Size: 0x01
	bool bIsInDoor; // Offset: 0x368 // Size: 0x01
	enum class ECollisionChannel OcclusionCollisionChannel; // Offset: 0x369 // Size: 0x01
	char EnableSpotReflectors : 1; // Offset: 0x36a // Size: 0x01
	float OuterRadius; // Offset: 0x36c // Size: 0x04
	float InnerRadius; // Offset: 0x370 // Size: 0x04
	struct UAkAuxBus* EarlyReflectionAuxBus; // Offset: 0x378 // Size: 0x08
	struct FString EarlyReflectionAuxBusName; // Offset: 0x380 // Size: 0x10
	int32_t EarlyReflectionOrder; // Offset: 0x390 // Size: 0x04
	float EarlyReflectionBusSendGain; // Offset: 0x394 // Size: 0x04
	float EarlyReflectionMaxPathLength; // Offset: 0x398 // Size: 0x04
	float roomReverbAuxBusGain; // Offset: 0x39c // Size: 0x04
	int32_t diffractionMaxEdges; // Offset: 0x3a0 // Size: 0x04
	int32_t diffractionMaxPaths; // Offset: 0x3a4 // Size: 0x04
	float diffractionMaxPathLength; // Offset: 0x3a8 // Size: 0x04
	char DrawFirstOrderReflections : 1; // Offset: 0x3ac // Size: 0x01
	char DrawSecondOrderReflections : 1; // Offset: 0x3ac // Size: 0x01
	char DrawHigherOrderReflections : 1; // Offset: 0x3ac // Size: 0x01
	char DrawDiffraction : 1; // Offset: 0x3ac // Size: 0x01
	bool StopWhenOwnerDestroyed; // Offset: 0x3ad // Size: 0x01
	float AttenuationScalingFactor; // Offset: 0x3b0 // Size: 0x04
	float OcclusionRefreshInterval; // Offset: 0x3b4 // Size: 0x04
	bool bUseReverbVolumes; // Offset: 0x3b8 // Size: 0x01
	char pad_0x3B9_5 : 3; // Offset: 0x3b9 // Size: 0x01
	char pad_0x3BA[0x176]; // Offset: 0x3ba // Size: 0x176

	// Functions

	// Object Name: Function AkAudio.AkComponent.UseReverbVolumes
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void UseReverbVolumes(bool inUseReverbVolumes); // Offset: 0x101d8b888 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AkAudio.AkComponent.UseEarlyReflections
	// Flags: [Final|Native|Public|BlueprintCallable]
	void UseEarlyReflections(struct UAkAuxBus* AuxBus, int32_t Order, float BusSendGain, float MaxPathLength, bool SpotReflectors, struct FString AuxBusName); // Offset: 0x101d8b670 // Return & Params: Num(6) Size(0x28)

	// Object Name: Function AkAudio.AkComponent.SetSwitch
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void SetSwitch(struct UAkSwitchValue* SwitchValue, struct FString SwitchGroup, struct FString SwitchState); // Offset: 0x101d8ba30 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function AkAudio.AkComponent.SetStopWhenOwnerDestroyed
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void SetStopWhenOwnerDestroyed(bool bStopWhenOwnerDestroyed); // Offset: 0x101d8b9a8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AkAudio.AkComponent.SetOutputBusVolume
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void SetOutputBusVolume(float BusVolume); // Offset: 0x101d8b4e4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function AkAudio.AkComponent.SetListeners
	// Flags: [Final|BlueprintCosmetic|Native|Public|HasOutParms|BlueprintCallable]
	void SetListeners(struct TArray<struct UAkComponent*>& Listeners); // Offset: 0x101d8b910 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AkAudio.AkComponent.SetGameObjectRadius
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetGameObjectRadius(float in_outerRadius, float in_innerRadius); // Offset: 0x101d8c47c // Return & Params: Num(2) Size(0x8)

	// Object Name: Function AkAudio.AkComponent.SetEarlyReflectionsVolume
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void SetEarlyReflectionsVolume(float SendVolume); // Offset: 0x101d8b564 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function AkAudio.AkComponent.SetEarlyReflectionsAuxBus
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void SetEarlyReflectionsAuxBus(struct FString AuxBusName); // Offset: 0x101d8b5e4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AkAudio.AkComponent.SetAttenuationScalingFactor
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void SetAttenuationScalingFactor(float Value); // Offset: 0x101d8b464 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function AkAudio.AkComponent.PostTrigger
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void PostTrigger(struct UAkTrigger* TriggerValue, struct FString Trigger); // Offset: 0x101d8bc0c // Return & Params: Num(2) Size(0x18)

	// Object Name: Function AkAudio.AkComponent.PostAssociatedAkEventAndWaitForEndAsync
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void PostAssociatedAkEventAndWaitForEndAsync(int32_t& PlayingID, struct TArray<struct FAkExternalSourceInfo>& ExternalSources, struct FLatentActionInfo LatentInfo); // Offset: 0x101d8c1ac // Return & Params: Num(3) Size(0x30)

	// Object Name: Function AkAudio.AkComponent.PostAssociatedAkEventAndWaitForEnd
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	int32_t PostAssociatedAkEventAndWaitForEnd(struct TArray<struct FAkExternalSourceInfo>& ExternalSources, struct FLatentActionInfo LatentInfo); // Offset: 0x101d8c338 // Return & Params: Num(3) Size(0x2c)

	// Object Name: Function AkAudio.AkComponent.PostAkEventByName
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	int32_t PostAkEventByName(struct FString in_EventName); // Offset: 0x101d8bd50 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function AkAudio.AkComponent.PostAkEventAndWaitForEndAsync
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void PostAkEventAndWaitForEndAsync(struct UAkAudioEvent* AkEvent, int32_t& PlayingID, struct TArray<struct FAkExternalSourceInfo>& ExternalSources, struct FLatentActionInfo LatentInfo); // Offset: 0x101d8bdec // Return & Params: Num(4) Size(0x38)

	// Object Name: Function AkAudio.AkComponent.PostAkEventAndWaitForEnd
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	int32_t PostAkEventAndWaitForEnd(struct UAkAudioEvent* AkEvent, struct FString in_EventName, struct TArray<struct FAkExternalSourceInfo>& ExternalSources, struct FLatentActionInfo LatentInfo); // Offset: 0x101d8bfc4 // Return & Params: Num(5) Size(0x44)

	// Object Name: Function AkAudio.AkComponent.GetAttenuationRadius
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetAttenuationRadius(); // Offset: 0x101d8b430 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class AkAudio.AkAudioInputComponent
// Size: 0x560 // Inherited bytes: 0x530
struct UAkAudioInputComponent : UAkComponent {
	// Fields
	char pad_0x530[0x30]; // Offset: 0x530 // Size: 0x30

	// Functions

	// Object Name: Function AkAudio.AkAudioInputComponent.PostAssociatedAudioInputEvent
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	int32_t PostAssociatedAudioInputEvent(); // Offset: 0x101d8a30c // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class AkAudio.AkAuxBus
// Size: 0x58 // Inherited bytes: 0x50
struct UAkAuxBus : UAkAssetBase {
	// Fields
	struct UAkAudioBank* RequiredBank; // Offset: 0x50 // Size: 0x08
};

// Object Name: Class AkAudio.AkCheckBox
// Size: 0xb98 // Inherited bytes: 0x150
struct UAkCheckBox : UContentWidget {
	// Fields
	char pad_0x150[0x348]; // Offset: 0x150 // Size: 0x348
	enum class ECheckBoxState CheckedState; // Offset: 0x498 // Size: 0x01
	char pad_0x499[0x3]; // Offset: 0x499 // Size: 0x03
	struct FDelegate CheckedStateDelegate; // Offset: 0x49c // Size: 0x10
	char pad_0x4AC[0x4]; // Offset: 0x4ac // Size: 0x04
	struct FCheckBoxStyle WidgetStyle; // Offset: 0x4b0 // Size: 0x610
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0xac0 // Size: 0x01
	bool IsFocusable; // Offset: 0xac1 // Size: 0x01
	char pad_0xAC2[0x6]; // Offset: 0xac2 // Size: 0x06
	struct FAkBoolPropertyToControl ThePropertyToControl; // Offset: 0xac8 // Size: 0x10
	struct FAkWwiseItemToControl ItemToControl; // Offset: 0xad8 // Size: 0x40
	struct FMulticastInlineDelegate AkOnCheckStateChanged; // Offset: 0xb18 // Size: 0x10
	struct FMulticastInlineDelegate OnItemDropped; // Offset: 0xb28 // Size: 0x10
	struct FMulticastInlineDelegate OnPropertyDropped; // Offset: 0xb38 // Size: 0x10
	char pad_0xB48[0x50]; // Offset: 0xb48 // Size: 0x50

	// Functions

	// Object Name: Function AkAudio.AkCheckBox.SetIsChecked
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetIsChecked(bool InIsChecked); // Offset: 0x101d8ad98 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AkAudio.AkCheckBox.SetCheckedState
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetCheckedState(enum class ECheckBoxState InCheckedState); // Offset: 0x101d8ad18 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AkAudio.AkCheckBox.SetAkItemId
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void SetAkItemId(struct FGuid& ItemID); // Offset: 0x101d8ac8c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AkAudio.AkCheckBox.SetAkBoolProperty
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAkBoolProperty(struct FString ItemProperty); // Offset: 0x101d8abcc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AkAudio.AkCheckBox.IsPressed
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsPressed(); // Offset: 0x101d8ae88 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AkAudio.AkCheckBox.IsChecked
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsChecked(); // Offset: 0x101d8ae54 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AkAudio.AkCheckBox.GetCheckedState
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	enum class ECheckBoxState GetCheckedState(); // Offset: 0x101d8ae20 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AkAudio.AkCheckBox.GetAkProperty
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FString GetAkProperty(); // Offset: 0x101d8ab2c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AkAudio.AkCheckBox.GetAkItemId
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FGuid GetAkItemId(); // Offset: 0x101d8ac58 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class AkAudio.DrawPortalComponent
// Size: 0x570 // Inherited bytes: 0x570
struct UDrawPortalComponent : UPrimitiveComponent {
};

// Object Name: Class AkAudio.DrawRoomComponent
// Size: 0x570 // Inherited bytes: 0x570
struct UDrawRoomComponent : UPrimitiveComponent {
};

// Object Name: Class AkAudio.AkFolder
// Size: 0xb8 // Inherited bytes: 0x40
struct UAkFolder : UAkAudioType {
	// Fields
	struct FString UnrealFolderPath; // Offset: 0x40 // Size: 0x10
	struct FString WwiseFolderPath; // Offset: 0x50 // Size: 0x10
	char pad_0x60[0x58]; // Offset: 0x60 // Size: 0x58
};

// Object Name: Class AkAudio.AkGameplayStatics
// Size: 0x28 // Inherited bytes: 0x28
struct UAkGameplayStatics : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function AkAudio.AkGameplayStatics.WakeupFromSuspend
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void WakeupFromSuspend(); // Offset: 0x101d97370 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AkAudio.AkGameplayStatics.UseReverbVolumes
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void UseReverbVolumes(bool inUseReverbVolumes, struct AActor* Actor); // Offset: 0x101d93258 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function AkAudio.AkGameplayStatics.UseEarlyReflections
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void UseEarlyReflections(struct AActor* Actor, struct UAkAuxBus* AuxBus, int32_t Order, float BusSendGain, float MaxPathLength, bool SpotReflectors, struct FString AuxBusName); // Offset: 0x101d93004 // Return & Params: Num(7) Size(0x30)

	// Object Name: Function AkAudio.AkGameplayStatics.UpdatePostedEventMultiPositions
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasOutParms|BlueprintCallable]
	void UpdatePostedEventMultiPositions(struct UAkComponent* AkComponent, struct TArray<struct FTransform>& Positions); // Offset: 0x101d97294 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function AkAudio.AkGameplayStatics.UpdateDopplerEffectDatas
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void UpdateDopplerEffectDatas(struct AActor* SoundingObj, struct AActor* ListeningObj); // Offset: 0x101d91238 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function AkAudio.AkGameplayStatics.UnloadBankByNameAsync
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasOutParms|BlueprintCallable]
	void UnloadBankByNameAsync(struct FString BankName, struct FDelegate& BankUnloadedCallback); // Offset: 0x101d91aa8 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function AkAudio.AkGameplayStatics.UnloadBankByName
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void UnloadBankByName(struct FString BankName); // Offset: 0x101d91bc0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AkAudio.AkGameplayStatics.UnloadBankAsync
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void UnloadBankAsync(struct UAkAudioBank* Bank, struct FDelegate& BankUnloadedCallback); // Offset: 0x101d91c44 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function AkAudio.AkGameplayStatics.UnloadBank
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void UnloadBank(struct UAkAudioBank* Bank, struct FString BankName, struct FLatentActionInfo LatentInfo, struct UObject* WorldContextObject); // Offset: 0x101d91d50 // Return & Params: Num(4) Size(0x38)

	// Object Name: Function AkAudio.AkGameplayStatics.Suspend
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void Suspend(bool in_bRenderAnyway); // Offset: 0x101d97384 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AkAudio.AkGameplayStatics.StopSoundOnComponentbyname
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	int32_t StopSoundOnComponentbyname(struct FString SoundName, struct UActorComponent* Component); // Offset: 0x101d95534 // Return & Params: Num(3) Size(0x1c)

	// Object Name: Function AkAudio.AkGameplayStatics.StopSoundOnComponent
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	int32_t StopSoundOnComponent(struct UAkAudioEvent* AkEvent, struct UActorComponent* Component); // Offset: 0x101d95674 // Return & Params: Num(3) Size(0x14)

	// Object Name: Function AkAudio.AkGameplayStatics.StopSoundbyname
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	int32_t StopSoundbyname(struct FString SoundName, struct AActor* Actor); // Offset: 0x101d958ac // Return & Params: Num(3) Size(0x1c)

	// Object Name: Function AkAudio.AkGameplayStatics.StopSound2Dbyname
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	int32_t StopSound2Dbyname(struct FString SoundName); // Offset: 0x101d9573c // Return & Params: Num(2) Size(0x14)

	// Object Name: Function AkAudio.AkGameplayStatics.StopSound2D
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	int32_t StopSound2D(struct UAkAudioEvent* AkEvent); // Offset: 0x101d9582c // Return & Params: Num(2) Size(0xc)

	// Object Name: Function AkAudio.AkGameplayStatics.StopSound
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	int32_t StopSound(struct UAkAudioEvent* AkEvent, struct AActor* Actor); // Offset: 0x101d959ec // Return & Params: Num(3) Size(0x14)

	// Object Name: Function AkAudio.AkGameplayStatics.StopProfilerCapture
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void StopProfilerCapture(); // Offset: 0x101d918f4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AkAudio.AkGameplayStatics.StopOutputCapture
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void StopOutputCapture(); // Offset: 0x101d9198c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AkAudio.AkGameplayStatics.StopAllAmbientSounds
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void StopAllAmbientSounds(struct UObject* WorldContextObject); // Offset: 0x101d9240c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function AkAudio.AkGameplayStatics.StopAll
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void StopAll(); // Offset: 0x101d925c8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AkAudio.AkGameplayStatics.StopActor
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void StopActor(struct AActor* Actor); // Offset: 0x101d925dc // Return & Params: Num(1) Size(0x8)

	// Object Name: Function AkAudio.AkGameplayStatics.StartProfilerCapture
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void StartProfilerCapture(struct FString Filename); // Offset: 0x101d91908 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AkAudio.AkGameplayStatics.StartOutputCapture
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void StartOutputCapture(struct FString Filename); // Offset: 0x101d91a24 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AkAudio.AkGameplayStatics.StartAllAmbientSounds
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void StartAllAmbientSounds(struct UObject* WorldContextObject); // Offset: 0x101d92484 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function AkAudio.AkGameplayStatics.SpawnAkComponentAtLocation
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasDefaults|BlueprintCallable]
	struct UAkComponent* SpawnAkComponentAtLocation(struct UObject* WorldContextObject, struct UAkAudioEvent* AkEvent, struct FVector Location, struct FRotator Orientation, bool AutoPost, struct FString EventName, bool AutoDestroy); // Offset: 0x101d94070 // Return & Params: Num(8) Size(0x50)

	// Object Name: Function AkAudio.AkGameplayStatics.SetSwitchToListenerbyname
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void SetSwitchToListenerbyname(struct FString SwitchGroup, struct FString SwitchState); // Offset: 0x101d961fc // Return & Params: Num(2) Size(0x20)

	// Object Name: Function AkAudio.AkGameplayStatics.SetSwitchToListener
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void SetSwitchToListener(struct UAkSwitchValue* SwitchValue); // Offset: 0x101d9638c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function AkAudio.AkGameplayStatics.SetSwitchToComponentbyname
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void SetSwitchToComponentbyname(struct UActorComponent* Component, struct FString SwitchGroup, struct FString SwitchState); // Offset: 0x101d96404 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function AkAudio.AkGameplayStatics.SetSwitchToComponent
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void SetSwitchToComponent(struct UAkSwitchValue* SwitchValue, struct UActorComponent* Component); // Offset: 0x101d965f0 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function AkAudio.AkGameplayStatics.SetSwitchbyname
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void SetSwitchbyname(struct AActor* Actor, struct FString SwitchGroup, struct FString SwitchState); // Offset: 0x101d966b0 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function AkAudio.AkGameplayStatics.SetSwitch
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void SetSwitch(struct UAkSwitchValue* SwitchValue, struct AActor* Actor, struct FName SwitchGroup, struct FName SwitchState); // Offset: 0x101d938fc // Return & Params: Num(4) Size(0x20)

	// Object Name: Function AkAudio.AkGameplayStatics.SetState
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void SetState(struct UAkStateValue* StateValue, struct FName StateGroup, struct FName State); // Offset: 0x101d93b5c // Return & Params: Num(3) Size(0x18)

	// Object Name: Function AkAudio.AkGameplayStatics.SetSpeakerAngles
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void SetSpeakerAngles(struct TArray<float>& SpeakerAngles, float HeightAngle, struct FString DeviceShareset); // Offset: 0x101d92718 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function AkAudio.AkGameplayStatics.SetRTPCValueToListenerbyname
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void SetRTPCValueToListenerbyname(struct FString RTPC, float Value, int32_t InterpolationTimeMs); // Offset: 0x101d95ab4 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function AkAudio.AkGameplayStatics.SetRTPCValueToListener
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void SetRTPCValueToListener(struct UAkRtpc* RTPCValue, float Value, int32_t InterpolationTimeMs); // Offset: 0x101d95c30 // Return & Params: Num(3) Size(0x10)

	// Object Name: Function AkAudio.AkGameplayStatics.SetRTPCValueToComponentbyname
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void SetRTPCValueToComponentbyname(struct FString RTPC, float Value, int32_t InterpolationTimeMs, struct UActorComponent* Component); // Offset: 0x101d95d40 // Return & Params: Num(4) Size(0x20)

	// Object Name: Function AkAudio.AkGameplayStatics.SetRTPCValueToComponent
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void SetRTPCValueToComponent(struct UAkRtpc* RTPCValue, float Value, int32_t InterpolationTimeMs, struct UActorComponent* Component); // Offset: 0x101d95ef0 // Return & Params: Num(4) Size(0x18)

	// Object Name: Function AkAudio.AkGameplayStatics.SetRTPCValuebyname
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void SetRTPCValuebyname(struct FString RTPC, float Value, int32_t InterpolationTimeMs, struct AActor* Actor); // Offset: 0x101d9604c // Return & Params: Num(4) Size(0x20)

	// Object Name: Function AkAudio.AkGameplayStatics.SetRTPCValue
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void SetRTPCValue(struct UAkRtpc* RTPCValue, float Value, int32_t InterpolationTimeMs, struct AActor* Actor, struct FName RTPC); // Offset: 0x101d93ecc // Return & Params: Num(5) Size(0x20)

	// Object Name: Function AkAudio.AkGameplayStatics.SetReflectionsOrder
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetReflectionsOrder(int32_t Order, bool RefreshPaths); // Offset: 0x101d92f3c // Return & Params: Num(2) Size(0x5)

	// Object Name: Function AkAudio.AkGameplayStatics.SetPortalToPortalObstruction
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetPortalToPortalObstruction(struct UAkPortalComponent* PortalComponent0, struct UAkPortalComponent* PortalComponent1, float ObstructionValue); // Offset: 0x101d92c18 // Return & Params: Num(3) Size(0x14)

	// Object Name: Function AkAudio.AkGameplayStatics.SetPortalObstructionAndOcclusion
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetPortalObstructionAndOcclusion(struct UAkPortalComponent* PortalComponent, float ObstructionValue, float OcclusionValue); // Offset: 0x101d92e30 // Return & Params: Num(3) Size(0x10)

	// Object Name: Function AkAudio.AkGameplayStatics.SetPanningRule
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetPanningRule(enum class PanningRule PanRule); // Offset: 0x101d92a0c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AkAudio.AkGameplayStatics.SetOutputBusVolume
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void SetOutputBusVolume(float BusVolume, struct AActor* Actor); // Offset: 0x101d92b54 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function AkAudio.AkGameplayStatics.SetOcclusionScalingFactor
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetOcclusionScalingFactor(float ScalingFactor); // Offset: 0x101d91874 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function AkAudio.AkGameplayStatics.SetOcclusionRefreshInterval
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void SetOcclusionRefreshInterval(float RefreshInterval, struct AActor* Actor); // Offset: 0x101d92654 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function AkAudio.AkGameplayStatics.SetMultiplePositions
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetMultiplePositions(struct UAkComponent* GameObjectAkComponent, struct TArray<struct FTransform> Positions, enum class AkMultiPositionType MultiPositionType); // Offset: 0x101d93770 // Return & Params: Num(3) Size(0x19)

	// Object Name: Function AkAudio.AkGameplayStatics.SetMultipleChannelMaskEmitterPositions
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetMultipleChannelMaskEmitterPositions(struct UAkComponent* GameObjectAkComponent, struct TArray<struct FAkChannelMask> ChannelMasks, struct TArray<struct FTransform> Positions, enum class AkMultiPositionType MultiPositionType); // Offset: 0x101d93328 // Return & Params: Num(4) Size(0x29)

	// Object Name: Function AkAudio.AkGameplayStatics.SetMultipleChannelEmitterPositions
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetMultipleChannelEmitterPositions(struct UAkComponent* GameObjectAkComponent, struct TArray<enum class AkChannelConfiguration> ChannelMasks, struct TArray<struct FTransform> Positions, enum class AkMultiPositionType MultiPositionType); // Offset: 0x101d9354c // Return & Params: Num(4) Size(0x29)

	// Object Name: Function AkAudio.AkGameplayStatics.SetGameObjectToPortalObstruction
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetGameObjectToPortalObstruction(struct UAkComponent* GameObjectAkComponent, struct UAkPortalComponent* PortalComponent, float ObstructionValue); // Offset: 0x101d92d24 // Return & Params: Num(3) Size(0x14)

	// Object Name: Function AkAudio.AkGameplayStatics.SetCurrentAudioCultureAsync
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void SetCurrentAudioCultureAsync(struct FString AudioCulture, struct FDelegate& Completed); // Offset: 0x101d91488 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function AkAudio.AkGameplayStatics.SetCurrentAudioCulture
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetCurrentAudioCulture(struct FString AudioCulture, struct FLatentActionInfo LatentInfo, struct UObject* WorldContextObject); // Offset: 0x101d915a0 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function AkAudio.AkGameplayStatics.SetBusConfig
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetBusConfig(struct FString BusName, enum class AkChannelConfiguration ChannelConfiguration); // Offset: 0x101d92a84 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function AkAudio.AkGameplayStatics.ReplaceMainOutput
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void ReplaceMainOutput(struct FAkOutputSettings& MainOutputSettings); // Offset: 0x101d9297c // Return & Params: Num(1) Size(0x18)

	// Object Name: Function AkAudio.AkGameplayStatics.PostTrigger
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void PostTrigger(struct UAkTrigger* TriggerValue, struct AActor* Actor, struct FName Trigger); // Offset: 0x101d93a50 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function AkAudio.AkGameplayStatics.PostEventByName
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void PostEventByName(struct FString EventName, struct AActor* Actor, bool bStopWhenAttachedToDestroyed); // Offset: 0x101d94934 // Return & Params: Num(3) Size(0x19)

	// Object Name: Function AkAudio.AkGameplayStatics.PostEventAttached
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	int32_t PostEventAttached(struct UAkAudioEvent* AkEvent, struct AActor* Actor, struct FName AttachPointName, bool bStopWhenAttachedToDestroyed, struct FString EventName); // Offset: 0x101d95304 // Return & Params: Num(6) Size(0x34)

	// Object Name: Function AkAudio.AkGameplayStatics.PostEventAtLocationByName
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasDefaults|BlueprintCallable]
	void PostEventAtLocationByName(struct FString EventName, struct FVector Location, struct FRotator Orientation, struct UObject* WorldContextObject); // Offset: 0x101d94620 // Return & Params: Num(4) Size(0x30)

	// Object Name: Function AkAudio.AkGameplayStatics.PostEventAtLocation
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasDefaults|BlueprintCallable]
	int32_t PostEventAtLocation(struct UAkAudioEvent* AkEvent, struct FVector Location, struct FRotator Orientation, struct FString EventName, struct UObject* WorldContextObject); // Offset: 0x101d94780 // Return & Params: Num(6) Size(0x3c)

	// Object Name: Function AkAudio.AkGameplayStatics.PostEvent
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasOutParms|BlueprintCallable]
	int32_t PostEvent(struct UAkAudioEvent* AkEvent, struct AActor* Actor, int32_t CallbackMask, struct FDelegate& PostEventCallback, struct TArray<struct FAkExternalSourceInfo>& ExternalSources, bool bStopWhenAttachedToDestroyed, struct FString EventName); // Offset: 0x101d94fb0 // Return & Params: Num(8) Size(0x54)

	// Object Name: Function AkAudio.AkGameplayStatics.PostAndWaitForEndOfEventAsync
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void PostAndWaitForEndOfEventAsync(struct UAkAudioEvent* AkEvent, struct AActor* Actor, int32_t& PlayingID, bool bStopWhenAttachedToDestroyed, struct TArray<struct FAkExternalSourceInfo>& ExternalSources, struct FLatentActionInfo LatentInfo); // Offset: 0x101d94a58 // Return & Params: Num(6) Size(0x40)

	// Object Name: Function AkAudio.AkGameplayStatics.PostAndWaitForEndOfEvent
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	int32_t PostAndWaitForEndOfEvent(struct UAkAudioEvent* AkEvent, struct AActor* Actor, bool bStopWhenAttachedToDestroyed, struct TArray<struct FAkExternalSourceInfo>& ExternalSources, struct FString EventName, struct FLatentActionInfo LatentInfo); // Offset: 0x101d94cc8 // Return & Params: Num(7) Size(0x54)

	// Object Name: Function AkAudio.AkGameplayStatics.PlaySoundToComponentbyname
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	int32_t PlaySoundToComponentbyname(struct FString SoundName, struct UActorComponent* Component, bool bStopWhenAttachedToDestroyed); // Offset: 0x101d96b60 // Return & Params: Num(4) Size(0x20)

	// Object Name: Function AkAudio.AkGameplayStatics.PlaySoundToComponent
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	int32_t PlaySoundToComponent(struct UAkAudioEvent* AkEvent, struct UActorComponent* Component, bool bStopWhenAttachedToDestroyed); // Offset: 0x101d96cdc // Return & Params: Num(4) Size(0x18)

	// Object Name: Function AkAudio.AkGameplayStatics.PlaySoundbyname
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	int32_t PlaySoundbyname(struct FString SoundName, struct AActor* Actor, bool bStopWhenAttachedToDestroyed); // Offset: 0x101d96ffc // Return & Params: Num(4) Size(0x20)

	// Object Name: Function AkAudio.AkGameplayStatics.PlaySoundAtLocationbyname
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasDefaults|BlueprintCallable]
	int32_t PlaySoundAtLocationbyname(struct FString SoundName, struct FVector Location, struct FRotator Orientation, struct UObject* WorldContextObject); // Offset: 0x101d9689c // Return & Params: Num(5) Size(0x34)

	// Object Name: Function AkAudio.AkGameplayStatics.PlaySoundAtLocation
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasDefaults|BlueprintCallable]
	int32_t PlaySoundAtLocation(struct UAkAudioEvent* AkEvent, struct FVector Location, struct FRotator Orientation, struct UObject* WorldContextObject); // Offset: 0x101d96a04 // Return & Params: Num(5) Size(0x2c)

	// Object Name: Function AkAudio.AkGameplayStatics.PlaySound2Dbyname
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	int32_t PlaySound2Dbyname(struct FString SoundName, bool bStopWhenAttachedToDestroyed); // Offset: 0x101d96df8 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function AkAudio.AkGameplayStatics.PlaySound2D
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	int32_t PlaySound2D(struct UAkAudioEvent* AkEvent, bool bStopWhenAttachedToDestroyed); // Offset: 0x101d96f28 // Return & Params: Num(3) Size(0x10)

	// Object Name: Function AkAudio.AkGameplayStatics.PlaySound
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	int32_t PlaySound(struct UAkAudioEvent* AkEvent, struct AActor* Actor, bool bStopWhenAttachedToDestroyed); // Offset: 0x101d97178 // Return & Params: Num(4) Size(0x18)

	// Object Name: Function AkAudio.AkGameplayStatics.LoadInitBank
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void LoadInitBank(); // Offset: 0x101d91ed8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AkAudio.AkGameplayStatics.LoadBanks
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasOutParms|BlueprintCallable]
	void LoadBanks(struct TArray<struct UAkAudioBank*>& SoundBanks, bool SynchronizeSoundBanks); // Offset: 0x101d91eec // Return & Params: Num(2) Size(0x11)

	// Object Name: Function AkAudio.AkGameplayStatics.LoadBankByNameAsync
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasOutParms|BlueprintCallable]
	void LoadBankByNameAsync(struct FString BankName, struct FDelegate& BankLoadedCallback); // Offset: 0x101d91fc8 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function AkAudio.AkGameplayStatics.LoadBankByName
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void LoadBankByName(struct FString BankName); // Offset: 0x101d920e0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AkAudio.AkGameplayStatics.LoadBankAsync
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void LoadBankAsync(struct UAkAudioBank* Bank, struct FDelegate& BankLoadedCallback); // Offset: 0x101d92164 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function AkAudio.AkGameplayStatics.LoadBank
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void LoadBank(struct UAkAudioBank* Bank, struct FString BankName, struct FLatentActionInfo LatentInfo, struct UObject* WorldContextObject); // Offset: 0x101d92270 // Return & Params: Num(4) Size(0x38)

	// Object Name: Function AkAudio.AkGameplayStatics.IsGame
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsGame(struct UObject* WorldContextObject); // Offset: 0x101d97404 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function AkAudio.AkGameplayStatics.IsEditor
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsEditor(); // Offset: 0x101d97484 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AkAudio.AkGameplayStatics.GetSpeakerAngles
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetSpeakerAngles(struct TArray<float>& SpeakerAngles, float& HeightAngle, struct FString DeviceShareset); // Offset: 0x101d92844 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function AkAudio.AkGameplayStatics.GetRTPCValue
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetRTPCValue(struct UAkRtpc* RTPCValue, int32_t PlayingID, enum class ERTPCValueType InputValueType, float& Value, enum class ERTPCValueType& OutputValueType, struct AActor* Actor, struct FName RTPC); // Offset: 0x101d93c68 // Return & Params: Num(7) Size(0x28)

	// Object Name: Function AkAudio.AkGameplayStatics.GetOcclusionScalingFactor
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	float GetOcclusionScalingFactor(); // Offset: 0x101d91850 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function AkAudio.AkGameplayStatics.GetDopplerEffectDatas
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	float GetDopplerEffectDatas(struct AActor* SoundingObj, struct AActor* ListeningObj, float DopplerIntensity, float DeltaTime); // Offset: 0x101d910dc // Return & Params: Num(5) Size(0x1c)

	// Object Name: Function AkAudio.AkGameplayStatics.GetCurrentAudioCulture
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetCurrentAudioCulture(); // Offset: 0x101d917d0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AkAudio.AkGameplayStatics.GetAvailableAudioCultures
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct TArray<struct FString> GetAvailableAudioCultures(); // Offset: 0x101d916dc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AkAudio.AkGameplayStatics.GetAkMediaAssetUserData
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UObject* GetAkMediaAssetUserData(struct UAkMediaAsset* Instance, struct UObject* Type); // Offset: 0x101d912f8 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function AkAudio.AkGameplayStatics.GetAkComponent
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UAkComponent* GetAkComponent(struct USceneComponent* AttachToComponent, bool& ComponentCreated, struct FName AttachPointName, struct FVector Location, enum class EAttachLocation LocationType); // Offset: 0x101d974b8 // Return & Params: Num(6) Size(0x30)

	// Object Name: Function AkAudio.AkGameplayStatics.GetAkAudioTypeUserData
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UObject* GetAkAudioTypeUserData(struct UAkAudioType* Instance, struct UObject* Type); // Offset: 0x101d913c0 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function AkAudio.AkGameplayStatics.ExecuteActionOnPlayingID
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void ExecuteActionOnPlayingID(enum class AkActionOnEventType ActionType, int32_t PlayingID, int32_t TransitionDuration, enum class EAkCurveInterpolation FadeCurve); // Offset: 0x101d942d4 // Return & Params: Num(4) Size(0xd)

	// Object Name: Function AkAudio.AkGameplayStatics.ExecuteActionOnEvent
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void ExecuteActionOnEvent(struct UAkAudioEvent* AkEvent, enum class AkActionOnEventType ActionType, struct AActor* Actor, int32_t TransitionDuration, enum class EAkCurveInterpolation FadeCurve, int32_t PlayingID); // Offset: 0x101d9442c // Return & Params: Num(6) Size(0x24)

	// Object Name: Function AkAudio.AkGameplayStatics.ClearBanks
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void ClearBanks(); // Offset: 0x101d923f8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AkAudio.AkGameplayStatics.CancelEventCallback
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasOutParms|BlueprintCallable]
	void CancelEventCallback(struct FDelegate& PostEventCallback); // Offset: 0x101d924fc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AkAudio.AkGameplayStatics.AddOutputCaptureMarker
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	void AddOutputCaptureMarker(struct FString MarkerText); // Offset: 0x101d919a0 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class AkAudio.AkCallbackInfo
// Size: 0x30 // Inherited bytes: 0x28
struct UAkCallbackInfo : UObject {
	// Fields
	struct UAkComponent* AkComponent; // Offset: 0x28 // Size: 0x08
};

// Object Name: Class AkAudio.AkEventCallbackInfo
// Size: 0x38 // Inherited bytes: 0x30
struct UAkEventCallbackInfo : UAkCallbackInfo {
	// Fields
	int32_t PlayingID; // Offset: 0x30 // Size: 0x04
	int32_t EventId; // Offset: 0x34 // Size: 0x04
};

// Object Name: Class AkAudio.AkMIDIEventCallbackInfo
// Size: 0x48 // Inherited bytes: 0x38
struct UAkMIDIEventCallbackInfo : UAkEventCallbackInfo {
	// Fields
	char pad_0x38[0x10]; // Offset: 0x38 // Size: 0x10

	// Functions

	// Object Name: Function AkAudio.AkMIDIEventCallbackInfo.GetType
	// Flags: [Final|Native|Public|BlueprintCallable]
	enum class EAkMidiEventType GetType(); // Offset: 0x101d9ccb0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AkAudio.AkMIDIEventCallbackInfo.GetProgramChange
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	bool GetProgramChange(struct FAkMidiProgramChange& AsProgramChange); // Offset: 0x101d9c794 // Return & Params: Num(2) Size(0x4)

	// Object Name: Function AkAudio.AkMIDIEventCallbackInfo.GetPitchBend
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	bool GetPitchBend(struct FAkMidiPitchBend& AsPitchBend); // Offset: 0x101d9c970 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function AkAudio.AkMIDIEventCallbackInfo.GetNoteOn
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	bool GetNoteOn(struct FAkMidiNoteOnOff& AsNoteOn); // Offset: 0x101d9cb44 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function AkAudio.AkMIDIEventCallbackInfo.GetNoteOff
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	bool GetNoteOff(struct FAkMidiNoteOnOff& AsNoteOff); // Offset: 0x101d9caa8 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function AkAudio.AkMIDIEventCallbackInfo.GetNoteAftertouch
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	bool GetNoteAftertouch(struct FAkMidiNoteAftertouch& AsNoteAftertouch); // Offset: 0x101d9c8d4 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function AkAudio.AkMIDIEventCallbackInfo.GetGeneric
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	bool GetGeneric(struct FAkMidiGeneric& AsGeneric); // Offset: 0x101d9cbe0 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function AkAudio.AkMIDIEventCallbackInfo.GetChannelAftertouch
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	bool GetChannelAftertouch(struct FAkMidiChannelAftertouch& AsChannelAftertouch); // Offset: 0x101d9c834 // Return & Params: Num(2) Size(0x4)

	// Object Name: Function AkAudio.AkMIDIEventCallbackInfo.GetChannel
	// Flags: [Final|Native|Public|BlueprintCallable]
	char GetChannel(); // Offset: 0x101d9cc7c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AkAudio.AkMIDIEventCallbackInfo.GetCc
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	bool GetCc(struct FAkMidiCc& AsCc); // Offset: 0x101d9ca0c // Return & Params: Num(2) Size(0x5)
};

// Object Name: Class AkAudio.AkMarkerCallbackInfo
// Size: 0x50 // Inherited bytes: 0x38
struct UAkMarkerCallbackInfo : UAkEventCallbackInfo {
	// Fields
	int32_t Identifier; // Offset: 0x38 // Size: 0x04
	int32_t Position; // Offset: 0x3c // Size: 0x04
	struct FString Label; // Offset: 0x40 // Size: 0x10
};

// Object Name: Class AkAudio.AkDurationCallbackInfo
// Size: 0x50 // Inherited bytes: 0x38
struct UAkDurationCallbackInfo : UAkEventCallbackInfo {
	// Fields
	float Duration; // Offset: 0x38 // Size: 0x04
	float EstimatedDuration; // Offset: 0x3c // Size: 0x04
	int32_t AudioNodeID; // Offset: 0x40 // Size: 0x04
	int32_t MediaID; // Offset: 0x44 // Size: 0x04
	bool bStreaming; // Offset: 0x48 // Size: 0x01
	char pad_0x49[0x7]; // Offset: 0x49 // Size: 0x07
};

// Object Name: Class AkAudio.AkMusicSyncCallbackInfo
// Size: 0x70 // Inherited bytes: 0x30
struct UAkMusicSyncCallbackInfo : UAkCallbackInfo {
	// Fields
	int32_t PlayingID; // Offset: 0x30 // Size: 0x04
	struct FAkSegmentInfo SegmentInfo; // Offset: 0x34 // Size: 0x24
	enum class EAkCallbackType MusicSyncType; // Offset: 0x58 // Size: 0x01
	char pad_0x59[0x7]; // Offset: 0x59 // Size: 0x07
	struct FString UserCueName; // Offset: 0x60 // Size: 0x10
};

// Object Name: Class AkAudio.AkGeometryComponent
// Size: 0x4e0 // Inherited bytes: 0x360
struct UAkGeometryComponent : UAkAcousticTextureSetComponent {
	// Fields
	enum class AkMeshType MeshType; // Offset: 0x359 // Size: 0x01
	int32_t LOD; // Offset: 0x35c // Size: 0x04
	float WeldingThreshold; // Offset: 0x360 // Size: 0x04
	struct TMap<struct UMaterialInterface*, struct FAkGeometrySurfaceOverride> StaticMeshSurfaceOverride; // Offset: 0x368 // Size: 0x50
	struct FAkGeometrySurfaceOverride CollisionMeshSurfaceOverride; // Offset: 0x3b8 // Size: 0x18
	char bEnableDiffraction : 1; // Offset: 0x3d0 // Size: 0x01
	char bEnableDiffractionOnBoundaryEdges : 1; // Offset: 0x3d0 // Size: 0x01
	char pad_0x3D1_2 : 6; // Offset: 0x3d1 // Size: 0x01
	char pad_0x3D2[0x6]; // Offset: 0x3d2 // Size: 0x06
	struct AActor* AssociatedRoom; // Offset: 0x3d8 // Size: 0x08
	char pad_0x3E0[0x10]; // Offset: 0x3e0 // Size: 0x10
	struct FAkGeometryData GeometryData; // Offset: 0x3f0 // Size: 0x50
	struct TMap<int32_t, float> SurfaceAreas; // Offset: 0x440 // Size: 0x50
	char pad_0x490[0x50]; // Offset: 0x490 // Size: 0x50

	// Functions

	// Object Name: Function AkAudio.AkGeometryComponent.UpdateGeometry
	// Flags: [Final|Native|Public|BlueprintCallable]
	void UpdateGeometry(); // Offset: 0x101d9da04 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AkAudio.AkGeometryComponent.SendGeometry
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SendGeometry(); // Offset: 0x101d9d9f0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AkAudio.AkGeometryComponent.RemoveGeometry
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RemoveGeometry(); // Offset: 0x101d9da18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AkAudio.AkGeometryComponent.ConvertMesh
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ConvertMesh(); // Offset: 0x101d9da2c // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class AkAudio.AkGroupValue
// Size: 0x68 // Inherited bytes: 0x40
struct UAkGroupValue : UAkAudioType {
	// Fields
	struct TArray<struct TSoftObjectPtr<UAkMediaAsset>> MediaDependencies; // Offset: 0x40 // Size: 0x10
	uint32_t GroupShortID; // Offset: 0x50 // Size: 0x04
	char pad_0x54[0x14]; // Offset: 0x54 // Size: 0x14
};

// Object Name: Class AkAudio.AkHololensInitializationSettings
// Size: 0xf0 // Inherited bytes: 0x28
struct UAkHololensInitializationSettings : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08
	struct FAkCommonInitializationSettingsWithSampleRate CommonSettings; // Offset: 0x30 // Size: 0x68
	struct FAkCommunicationSettingsWithSystemInitialization CommunicationSettings; // Offset: 0x98 // Size: 0x28
	struct FAkHololensAdvancedInitializationSettings AdvancedSettings; // Offset: 0xc0 // Size: 0x30

	// Functions

	// Object Name: Function AkAudio.AkHololensInitializationSettings.MigrateMultiCoreRendering
	// Flags: [Final|Native|Public]
	void MigrateMultiCoreRendering(bool NewValue); // Offset: 0x101d9e4bc // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class AkAudio.AkHololensPlatformInfo
// Size: 0x70 // Inherited bytes: 0x70
struct UAkHololensPlatformInfo : UAkPlatformInfo {
};

// Object Name: Class AkAudio.AkInitBankAssetData
// Size: 0x80 // Inherited bytes: 0x70
struct UAkInitBankAssetData : UAkAssetDataWithMedia {
	// Fields
	struct TArray<struct FAkPluginInfo> PluginInfos; // Offset: 0x70 // Size: 0x10
};

// Object Name: Class AkAudio.AkInitBank
// Size: 0x70 // Inherited bytes: 0x50
struct UAkInitBank : UAkAssetBase {
	// Fields
	struct TArray<struct FString> AvailableAudioCultures; // Offset: 0x50 // Size: 0x10
	struct FString DefaultLanguage; // Offset: 0x60 // Size: 0x10
};

// Object Name: Class AkAudio.AkIOSInitializationSettings
// Size: 0x100 // Inherited bytes: 0x28
struct UAkIOSInitializationSettings : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08
	struct FAkCommonInitializationSettingsWithSampleRate CommonSettings; // Offset: 0x30 // Size: 0x68
	struct FAkAudioSession AudioSession; // Offset: 0x98 // Size: 0x0c
	char pad_0xA4[0x4]; // Offset: 0xa4 // Size: 0x04
	struct FAkCommunicationSettingsWithSystemInitialization CommunicationSettings; // Offset: 0xa8 // Size: 0x28
	struct FAkAdvancedInitializationSettings AdvancedSettings; // Offset: 0xd0 // Size: 0x2c
	char pad_0xFC[0x4]; // Offset: 0xfc // Size: 0x04
};

// Object Name: Class AkAudio.AkIOSPlatformInfo
// Size: 0x70 // Inherited bytes: 0x70
struct UAkIOSPlatformInfo : UAkPlatformInfo {
};

// Object Name: Class AkAudio.AkItemBoolPropertiesConv
// Size: 0x28 // Inherited bytes: 0x28
struct UAkItemBoolPropertiesConv : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function AkAudio.AkItemBoolPropertiesConv.Conv_FAkBoolPropertyToControlToText
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FText Conv_FAkBoolPropertyToControlToText(struct FAkBoolPropertyToControl& INAkBoolPropertyToControl); // Offset: 0x101da57e0 // Return & Params: Num(2) Size(0x28)

	// Object Name: Function AkAudio.AkItemBoolPropertiesConv.Conv_FAkBoolPropertyToControlToString
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FString Conv_FAkBoolPropertyToControlToString(struct FAkBoolPropertyToControl& INAkBoolPropertyToControl); // Offset: 0x101da58e4 // Return & Params: Num(2) Size(0x20)
};

// Object Name: Class AkAudio.AkItemBoolProperties
// Size: 0x178 // Inherited bytes: 0x138
struct UAkItemBoolProperties : UWidget {
	// Fields
	struct FMulticastInlineDelegate OnSelectionChanged; // Offset: 0x138 // Size: 0x10
	struct FMulticastInlineDelegate OnPropertyDragged; // Offset: 0x148 // Size: 0x10
	char pad_0x158[0x20]; // Offset: 0x158 // Size: 0x20

	// Functions

	// Object Name: Function AkAudio.AkItemBoolProperties.SetSearchText
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void SetSearchText(struct FString newText); // Offset: 0x101da5c20 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AkAudio.AkItemBoolProperties.GetSelectedProperty
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FString GetSelectedProperty(); // Offset: 0x101da5d2c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AkAudio.AkItemBoolProperties.GetSearchText
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FString GetSearchText(); // Offset: 0x101da5cac // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class AkAudio.AkItemPropertiesConv
// Size: 0x28 // Inherited bytes: 0x28
struct UAkItemPropertiesConv : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function AkAudio.AkItemPropertiesConv.Conv_FAkPropertyToControlToText
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FText Conv_FAkPropertyToControlToText(struct FAkPropertyToControl& INAkPropertyToControl); // Offset: 0x101da61dc // Return & Params: Num(2) Size(0x28)

	// Object Name: Function AkAudio.AkItemPropertiesConv.Conv_FAkPropertyToControlToString
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FString Conv_FAkPropertyToControlToString(struct FAkPropertyToControl& INAkPropertyToControl); // Offset: 0x101da62e0 // Return & Params: Num(2) Size(0x20)
};

// Object Name: Class AkAudio.AkItemProperties
// Size: 0x178 // Inherited bytes: 0x138
struct UAkItemProperties : UWidget {
	// Fields
	struct FMulticastInlineDelegate OnSelectionChanged; // Offset: 0x138 // Size: 0x10
	struct FMulticastInlineDelegate OnPropertyDragged; // Offset: 0x148 // Size: 0x10
	char pad_0x158[0x20]; // Offset: 0x158 // Size: 0x20

	// Functions

	// Object Name: Function AkAudio.AkItemProperties.SetSearchText
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void SetSearchText(struct FString newText); // Offset: 0x101da661c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AkAudio.AkItemProperties.GetSelectedProperty
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FString GetSelectedProperty(); // Offset: 0x101da6728 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AkAudio.AkItemProperties.GetSearchText
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FString GetSearchText(); // Offset: 0x101da66a8 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class AkAudio.AkLateReverbComponent
// Size: 0x3d0 // Inherited bytes: 0x350
struct UAkLateReverbComponent : USceneComponent {
	// Fields
	char bEnable : 1; // Offset: 0x344 // Size: 0x01
	float SendLevel; // Offset: 0x348 // Size: 0x04
	float FadeRate; // Offset: 0x34c // Size: 0x04
	float Priority; // Offset: 0x350 // Size: 0x04
	bool AutoAssignAuxBus; // Offset: 0x354 // Size: 0x01
	struct UAkAuxBus* AuxBus; // Offset: 0x358 // Size: 0x08
	struct FString AuxBusName; // Offset: 0x360 // Size: 0x10
	char pad_0x375_1 : 7; // Offset: 0x375 // Size: 0x01
	char pad_0x376[0x2]; // Offset: 0x376 // Size: 0x02
	struct UAkAuxBus* AuxBusManual; // Offset: 0x378 // Size: 0x08
	char pad_0x380[0x50]; // Offset: 0x380 // Size: 0x50

	// Functions

	// Object Name: Function AkAudio.AkLateReverbComponent.AssociateAkTextureSetComponent
	// Flags: [Final|Native|Public|BlueprintCallable]
	void AssociateAkTextureSetComponent(struct UAkAcousticTextureSetComponent* textureSetComponent); // Offset: 0x101da6a68 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class AkAudio.AkLinuxInitializationSettings
// Size: 0xf0 // Inherited bytes: 0x28
struct UAkLinuxInitializationSettings : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08
	struct FAkCommonInitializationSettingsWithSampleRate CommonSettings; // Offset: 0x30 // Size: 0x68
	struct FAkCommunicationSettingsWithSystemInitialization CommunicationSettings; // Offset: 0x98 // Size: 0x28
	struct FAkAdvancedInitializationSettingsWithMultiCoreRendering AdvancedSettings; // Offset: 0xc0 // Size: 0x30

	// Functions

	// Object Name: Function AkAudio.AkLinuxInitializationSettings.MigrateMultiCoreRendering
	// Flags: [Final|Native|Public]
	void MigrateMultiCoreRendering(bool NewValue); // Offset: 0x101da6eb8 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class AkAudio.AkLinuxPlatformInfo
// Size: 0x70 // Inherited bytes: 0x70
struct UAkLinuxPlatformInfo : UAkPlatformInfo {
};

// Object Name: Class AkAudio.AkMacInitializationSettings
// Size: 0xf0 // Inherited bytes: 0x28
struct UAkMacInitializationSettings : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08
	struct FAkCommonInitializationSettingsWithSampleRate CommonSettings; // Offset: 0x30 // Size: 0x68
	struct FAkCommunicationSettingsWithSystemInitialization CommunicationSettings; // Offset: 0x98 // Size: 0x28
	struct FAkAdvancedInitializationSettingsWithMultiCoreRendering AdvancedSettings; // Offset: 0xc0 // Size: 0x30

	// Functions

	// Object Name: Function AkAudio.AkMacInitializationSettings.MigrateMultiCoreRendering
	// Flags: [Final|Native|Public]
	void MigrateMultiCoreRendering(bool NewValue); // Offset: 0x101da727c // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class AkAudio.AkMacPlatformInfo
// Size: 0x70 // Inherited bytes: 0x70
struct UAkMacPlatformInfo : UAkPlatformInfo {
};

// Object Name: Class AkAudio.AkMediaAssetData
// Size: 0x60 // Inherited bytes: 0x28
struct UAkMediaAssetData : UObject {
	// Fields
	bool IsStreamed; // Offset: 0x28 // Size: 0x01
	bool UseDeviceMemory; // Offset: 0x29 // Size: 0x01
	char pad_0x2A[0x36]; // Offset: 0x2a // Size: 0x36
};

// Object Name: Class AkAudio.AkMediaAsset
// Size: 0x58 // Inherited bytes: 0x28
struct UAkMediaAsset : UObject {
	// Fields
	uint32_t ID; // Offset: 0x28 // Size: 0x04
	bool AutoLoad; // Offset: 0x2c // Size: 0x01
	char pad_0x2D[0x3]; // Offset: 0x2d // Size: 0x03
	struct TArray<struct UObject*> UserData; // Offset: 0x30 // Size: 0x10
	struct UAkMediaAssetData* CurrentMediaAssetData; // Offset: 0x40 // Size: 0x08
	char pad_0x48[0x10]; // Offset: 0x48 // Size: 0x10
};

// Object Name: Class AkAudio.AkLocalizedMediaAsset
// Size: 0x58 // Inherited bytes: 0x58
struct UAkLocalizedMediaAsset : UAkMediaAsset {
};

// Object Name: Class AkAudio.AkExternalMediaAsset
// Size: 0xb0 // Inherited bytes: 0x58
struct UAkExternalMediaAsset : UAkMediaAsset {
	// Fields
	char pad_0x58[0x58]; // Offset: 0x58 // Size: 0x58
};

// Object Name: Class AkAudio.AkPlatformInitialisationSettingsBase
// Size: 0x28 // Inherited bytes: 0x28
struct UAkPlatformInitialisationSettingsBase : UInterface {
};

// Object Name: Class AkAudio.AkPS4InitializationSettings
// Size: 0xf0 // Inherited bytes: 0x28
struct UAkPS4InitializationSettings : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08
	struct FAkCommonInitializationSettings CommonSettings; // Offset: 0x30 // Size: 0x60
	struct FAkCommunicationSettingsWithSystemInitialization CommunicationSettings; // Offset: 0x90 // Size: 0x28
	struct FAkPS4AdvancedInitializationSettings AdvancedSettings; // Offset: 0xb8 // Size: 0x38

	// Functions

	// Object Name: Function AkAudio.AkPS4InitializationSettings.MigrateMultiCoreRendering
	// Flags: [Final|Native|Public]
	void MigrateMultiCoreRendering(bool NewValue); // Offset: 0x101da8244 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class AkAudio.AkPS4PlatformInfo
// Size: 0x70 // Inherited bytes: 0x70
struct UAkPS4PlatformInfo : UAkPlatformInfo {
};

// Object Name: Class AkAudio.AkReverbVolume
// Size: 0x298 // Inherited bytes: 0x260
struct AAkReverbVolume : AVolume {
	// Fields
	char bEnabled : 1; // Offset: 0x260 // Size: 0x01
	char pad_0x260_1 : 7; // Offset: 0x260 // Size: 0x01
	char pad_0x261[0x7]; // Offset: 0x261 // Size: 0x07
	struct UAkAuxBus* AuxBus; // Offset: 0x268 // Size: 0x08
	struct FString AuxBusName; // Offset: 0x270 // Size: 0x10
	float SendLevel; // Offset: 0x280 // Size: 0x04
	float FadeRate; // Offset: 0x284 // Size: 0x04
	float Priority; // Offset: 0x288 // Size: 0x04
	char pad_0x28C[0x4]; // Offset: 0x28c // Size: 0x04
	struct UAkLateReverbComponent* LateReverbComponent; // Offset: 0x290 // Size: 0x08
};

// Object Name: Class AkAudio.AkRoomComponent
// Size: 0x390 // Inherited bytes: 0x370
struct UAkRoomComponent : UAkGameObject {
	// Fields
	char bEnable : 1; // Offset: 0x362 // Size: 0x01
	bool bDynamic; // Offset: 0x363 // Size: 0x01
	float Priority; // Offset: 0x364 // Size: 0x04
	float WallOcclusion; // Offset: 0x368 // Size: 0x04
	float AuxSendLevel; // Offset: 0x36c // Size: 0x04
	bool AutoPost; // Offset: 0x370 // Size: 0x01
	char pad_0x37E_1 : 7; // Offset: 0x37e // Size: 0x01
	char pad_0x37F[0x1]; // Offset: 0x37f // Size: 0x01
	struct UAkAcousticTextureSetComponent* GeometryComponent; // Offset: 0x380 // Size: 0x08
	char pad_0x388[0x8]; // Offset: 0x388 // Size: 0x08

	// Functions

	// Object Name: Function AkAudio.AkRoomComponent.GetPrimitiveParent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UPrimitiveComponent* GetPrimitiveParent(); // Offset: 0x101da8820 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class AkAudio.AkRtpc
// Size: 0x40 // Inherited bytes: 0x40
struct UAkRtpc : UAkAudioType {
};

// Object Name: Class AkAudio.AkSettings
// Size: 0x2b8 // Inherited bytes: 0x28
struct UAkSettings : UObject {
	// Fields
	char MaxSimultaneousReverbVolumes; // Offset: 0x28 // Size: 0x01
	char pad_0x29[0x7]; // Offset: 0x29 // Size: 0x07
	struct FFilePath WwiseProjectPath; // Offset: 0x30 // Size: 0x10
	struct FDirectoryPath WwiseSoundDataFolder; // Offset: 0x40 // Size: 0x10
	bool bAutoConnectToWAAPI; // Offset: 0x50 // Size: 0x01
	enum class ECollisionChannel DefaultOcclusionCollisionChannel; // Offset: 0x51 // Size: 0x01
	enum class ECollisionChannel DefaultFitToGeometryCollisionChannel; // Offset: 0x52 // Size: 0x01
	char pad_0x53[0x5]; // Offset: 0x53 // Size: 0x05
	struct TMap<struct TSoftObjectPtr<UPhysicalMaterial>, struct FAkGeometrySurfacePropertiesToMap> AkGeometryMap; // Offset: 0x58 // Size: 0x50
	float GlobalDecayAbsorption; // Offset: 0xa8 // Size: 0x04
	char pad_0xAC[0x4]; // Offset: 0xac // Size: 0x04
	struct TSoftObjectPtr<UAkAuxBus> DefaultReverbAuxBus; // Offset: 0xb0 // Size: 0x28
	struct TMap<float, struct TSoftObjectPtr<UAkAuxBus>> EnvironmentDecayAuxBusMap; // Offset: 0xd8 // Size: 0x50
	struct FString HFDampingName; // Offset: 0x128 // Size: 0x10
	struct FString DecayEstimateName; // Offset: 0x138 // Size: 0x10
	struct FString TimeToFirstReflectionName; // Offset: 0x148 // Size: 0x10
	struct TSoftObjectPtr<UAkRtpc> HFDampingRTPC; // Offset: 0x158 // Size: 0x28
	struct TSoftObjectPtr<UAkRtpc> DecayEstimateRTPC; // Offset: 0x180 // Size: 0x28
	struct TSoftObjectPtr<UAkRtpc> TimeToFirstReflectionRTPC; // Offset: 0x1a8 // Size: 0x28
	struct TMap<struct FGuid, struct FAkAcousticTextureParams> AcousticTextureParamsMap; // Offset: 0x1d0 // Size: 0x50
	bool SplitSwitchContainerMedia; // Offset: 0x220 // Size: 0x01
	bool SplitMediaPerFolder; // Offset: 0x221 // Size: 0x01
	bool UseEventBasedPackaging; // Offset: 0x222 // Size: 0x01
	bool EnableAutomaticAssetSynchronization; // Offset: 0x223 // Size: 0x01
	char pad_0x224[0x4]; // Offset: 0x224 // Size: 0x04
	struct FString CommandletCommitMessage; // Offset: 0x228 // Size: 0x10
	struct TMap<struct FString, struct FString> UnrealCultureToWwiseCulture; // Offset: 0x238 // Size: 0x50
	bool AskedToUseNewAssetManagement; // Offset: 0x288 // Size: 0x01
	bool bEnableMultiCoreRendering; // Offset: 0x289 // Size: 0x01
	bool MigratedEnableMultiCoreRendering; // Offset: 0x28a // Size: 0x01
	bool FixupRedirectorsDuringMigration; // Offset: 0x28b // Size: 0x01
	char pad_0x28C[0x4]; // Offset: 0x28c // Size: 0x04
	struct FDirectoryPath WwiseWindowsInstallationPath; // Offset: 0x290 // Size: 0x10
	struct FFilePath WwiseMacInstallationPath; // Offset: 0x2a0 // Size: 0x10
	char pad_0x2B0[0x8]; // Offset: 0x2b0 // Size: 0x08
};

// Object Name: Class AkAudio.AkSettingsPerUser
// Size: 0x80 // Inherited bytes: 0x28
struct UAkSettingsPerUser : UObject {
	// Fields
	struct FDirectoryPath WwiseWindowsInstallationPath; // Offset: 0x28 // Size: 0x10
	struct FFilePath WwiseMacInstallationPath; // Offset: 0x38 // Size: 0x10
	bool EnableAutomaticAssetSynchronization; // Offset: 0x48 // Size: 0x01
	char pad_0x49[0x7]; // Offset: 0x49 // Size: 0x07
	struct FString WaapiIPAddress; // Offset: 0x50 // Size: 0x10
	uint32_t WaapiPort; // Offset: 0x60 // Size: 0x04
	bool bAutoConnectToWAAPI; // Offset: 0x64 // Size: 0x01
	bool AutoSyncSelection; // Offset: 0x65 // Size: 0x01
	bool SuppressWwiseProjectPathWarnings; // Offset: 0x66 // Size: 0x01
	bool SoundDataGenerationSkipLanguage; // Offset: 0x67 // Size: 0x01
	char pad_0x68[0x18]; // Offset: 0x68 // Size: 0x18
};

// Object Name: Class AkAudio.AkSlider
// Size: 0x5c0 // Inherited bytes: 0x138
struct UAkSlider : UWidget {
	// Fields
	float Value; // Offset: 0x138 // Size: 0x04
	struct FDelegate ValueDelegate; // Offset: 0x13c // Size: 0x10
	char pad_0x14C[0x4]; // Offset: 0x14c // Size: 0x04
	struct FSliderStyle WidgetStyle; // Offset: 0x150 // Size: 0x3a0
	enum class EOrientation Orientation; // Offset: 0x4f0 // Size: 0x01
	char pad_0x4F1[0x3]; // Offset: 0x4f1 // Size: 0x03
	struct FLinearColor SliderBarColor; // Offset: 0x4f4 // Size: 0x10
	struct FLinearColor SliderHandleColor; // Offset: 0x504 // Size: 0x10
	bool IndentHandle; // Offset: 0x514 // Size: 0x01
	bool Locked; // Offset: 0x515 // Size: 0x01
	char pad_0x516[0x2]; // Offset: 0x516 // Size: 0x02
	float StepSize; // Offset: 0x518 // Size: 0x04
	bool IsFocusable; // Offset: 0x51c // Size: 0x01
	char pad_0x51D[0x3]; // Offset: 0x51d // Size: 0x03
	struct FAkPropertyToControl ThePropertyToControl; // Offset: 0x520 // Size: 0x10
	struct FAkWwiseItemToControl ItemToControl; // Offset: 0x530 // Size: 0x40
	struct FMulticastInlineDelegate OnValueChanged; // Offset: 0x570 // Size: 0x10
	struct FMulticastInlineDelegate OnItemDropped; // Offset: 0x580 // Size: 0x10
	struct FMulticastInlineDelegate OnPropertyDropped; // Offset: 0x590 // Size: 0x10
	char pad_0x5A0[0x20]; // Offset: 0x5a0 // Size: 0x20

	// Functions

	// Object Name: Function AkAudio.AkSlider.SetValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetValue(float InValue); // Offset: 0x101da9bec // Return & Params: Num(1) Size(0x4)

	// Object Name: Function AkAudio.AkSlider.SetStepSize
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetStepSize(float InValue); // Offset: 0x101da9a5c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function AkAudio.AkSlider.SetSliderHandleColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetSliderHandleColor(struct FLinearColor InValue); // Offset: 0x101da995c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AkAudio.AkSlider.SetSliderBarColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetSliderBarColor(struct FLinearColor InValue); // Offset: 0x101da99dc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AkAudio.AkSlider.SetLocked
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetLocked(bool InValue); // Offset: 0x101da9adc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AkAudio.AkSlider.SetIndentHandle
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetIndentHandle(bool InValue); // Offset: 0x101da9b64 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AkAudio.AkSlider.SetAkSliderItemProperty
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAkSliderItemProperty(struct FString ItemProperty); // Offset: 0x101da9810 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AkAudio.AkSlider.SetAkSliderItemId
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void SetAkSliderItemId(struct FGuid& ItemID); // Offset: 0x101da98d0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AkAudio.AkSlider.GetValue
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetValue(); // Offset: 0x101da9c6c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function AkAudio.AkSlider.GetAkSliderItemProperty
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FString GetAkSliderItemProperty(); // Offset: 0x101da9770 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AkAudio.AkSlider.GetAkSliderItemId
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FGuid GetAkSliderItemId(); // Offset: 0x101da989c // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class AkAudio.AkSpatialAudioVolume
// Size: 0x278 // Inherited bytes: 0x260
struct AAkSpatialAudioVolume : AVolume {
	// Fields
	struct UAkSurfaceReflectorSetComponent* SurfaceReflectorSet; // Offset: 0x260 // Size: 0x08
	struct UAkLateReverbComponent* LateReverb; // Offset: 0x268 // Size: 0x08
	struct UAkRoomComponent* Room; // Offset: 0x270 // Size: 0x08
};

// Object Name: Class AkAudio.AkSpotReflector
// Size: 0x250 // Inherited bytes: 0x228
struct AAkSpotReflector : AActor {
	// Fields
	struct UAkAuxBus* EarlyReflectionAuxBus; // Offset: 0x228 // Size: 0x08
	struct FString EarlyReflectionAuxBusName; // Offset: 0x230 // Size: 0x10
	struct UAkAcousticTexture* AcousticTexture; // Offset: 0x240 // Size: 0x08
	float DistanceScalingFactor; // Offset: 0x248 // Size: 0x04
	float Level; // Offset: 0x24c // Size: 0x04
};

// Object Name: Class AkAudio.AkStateValue
// Size: 0x68 // Inherited bytes: 0x68
struct UAkStateValue : UAkGroupValue {
};

// Object Name: Class AkAudio.AkSurfaceReflectorSetComponent
// Size: 0x390 // Inherited bytes: 0x360
struct UAkSurfaceReflectorSetComponent : UAkAcousticTextureSetComponent {
	// Fields
	char bEnableSurfaceReflectors : 1; // Offset: 0x359 // Size: 0x01
	struct TArray<struct FAkPoly> AcousticPolys; // Offset: 0x360 // Size: 0x10
	char bEnableDiffraction : 1; // Offset: 0x370 // Size: 0x01
	char bEnableDiffractionOnBoundaryEdges : 1; // Offset: 0x370 // Size: 0x01
	char pad_0x370_3 : 5; // Offset: 0x370 // Size: 0x01
	char pad_0x371[0x7]; // Offset: 0x371 // Size: 0x07
	struct AActor* AssociatedRoom; // Offset: 0x378 // Size: 0x08
	char pad_0x380[0x10]; // Offset: 0x380 // Size: 0x10

	// Functions

	// Object Name: Function AkAudio.AkSurfaceReflectorSetComponent.UpdateSurfaceReflectorSet
	// Flags: [Final|Native|Public|BlueprintCallable]
	void UpdateSurfaceReflectorSet(); // Offset: 0x101daece0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AkAudio.AkSurfaceReflectorSetComponent.SendSurfaceReflectorSet
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SendSurfaceReflectorSet(); // Offset: 0x101daed08 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AkAudio.AkSurfaceReflectorSetComponent.RemoveSurfaceReflectorSet
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RemoveSurfaceReflectorSet(); // Offset: 0x101daecf4 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class AkAudio.AkSwitchInitializationSettings
// Size: 0xf0 // Inherited bytes: 0x28
struct UAkSwitchInitializationSettings : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08
	struct FAkCommonInitializationSettingsWithSampleRate CommonSettings; // Offset: 0x30 // Size: 0x68
	struct FAkCommunicationSettingsWithCommSelection CommunicationSettings; // Offset: 0x98 // Size: 0x28
	struct FAkAdvancedInitializationSettingsWithMultiCoreRendering AdvancedSettings; // Offset: 0xc0 // Size: 0x30

	// Functions

	// Object Name: Function AkAudio.AkSwitchInitializationSettings.MigrateMultiCoreRendering
	// Flags: [Final|Native|Public]
	void MigrateMultiCoreRendering(bool NewValue); // Offset: 0x101daf0cc // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class AkAudio.AkSwitchPlatformInfo
// Size: 0x70 // Inherited bytes: 0x70
struct UAkSwitchPlatformInfo : UAkPlatformInfo {
};

// Object Name: Class AkAudio.AkSwitchValue
// Size: 0x68 // Inherited bytes: 0x68
struct UAkSwitchValue : UAkGroupValue {
};

// Object Name: Class AkAudio.AkTrigger
// Size: 0x40 // Inherited bytes: 0x40
struct UAkTrigger : UAkAudioType {
};

// Object Name: Class AkAudio.AkTVOSInitializationSettings
// Size: 0x100 // Inherited bytes: 0x28
struct UAkTVOSInitializationSettings : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08
	struct FAkCommonInitializationSettingsWithSampleRate CommonSettings; // Offset: 0x30 // Size: 0x68
	struct FAkAudioSession AudioSession; // Offset: 0x98 // Size: 0x0c
	char pad_0xA4[0x4]; // Offset: 0xa4 // Size: 0x04
	struct FAkCommunicationSettingsWithSystemInitialization CommunicationSettings; // Offset: 0xa8 // Size: 0x28
	struct FAkAdvancedInitializationSettings AdvancedSettings; // Offset: 0xd0 // Size: 0x2c
	char pad_0xFC[0x4]; // Offset: 0xfc // Size: 0x04
};

// Object Name: Class AkAudio.AkTVOSPlatformInfo
// Size: 0x70 // Inherited bytes: 0x70
struct UAkTVOSPlatformInfo : UAkPlatformInfo {
};

// Object Name: Class AkAudio.AkWaapiCalls
// Size: 0x28 // Inherited bytes: 0x28
struct UAkWaapiCalls : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function AkAudio.AkWaapiCalls.Unsubscribe
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct FAKWaapiJsonObject Unsubscribe(struct FAkWaapiSubscriptionId& SubscriptionId, bool& UnsubscriptionDone); // Offset: 0x101dafe94 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function AkAudio.AkWaapiCalls.SubscribeToWaapi
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct FAKWaapiJsonObject SubscribeToWaapi(struct FAkWaapiUri& WaapiUri, struct FAKWaapiJsonObject& WaapiOptions, struct FDelegate& Callback, struct FAkWaapiSubscriptionId& SubscriptionId, bool& SubscriptionDone); // Offset: 0x101db0050 // Return & Params: Num(6) Size(0x50)

	// Object Name: Function AkAudio.AkWaapiCalls.SetSubscriptionID
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void SetSubscriptionID(struct FAkWaapiSubscriptionId& Subscription, int32_t ID); // Offset: 0x101db098c // Return & Params: Num(2) Size(0xc)

	// Object Name: Function AkAudio.AkWaapiCalls.RegisterWaapiProjectLoadedCallback
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool RegisterWaapiProjectLoadedCallback(struct FDelegate& Callback); // Offset: 0x101db082c // Return & Params: Num(2) Size(0x11)

	// Object Name: Function AkAudio.AkWaapiCalls.RegisterWaapiConnectionLostCallback
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool RegisterWaapiConnectionLostCallback(struct FDelegate& Callback); // Offset: 0x101db0758 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function AkAudio.AkWaapiCalls.GetSubscriptionID
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	int32_t GetSubscriptionID(struct FAkWaapiSubscriptionId& Subscription); // Offset: 0x101db0900 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function AkAudio.AkWaapiCalls.Conv_FAkWaapiSubscriptionIdToText
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FText Conv_FAkWaapiSubscriptionIdToText(struct FAkWaapiSubscriptionId& INAkWaapiSubscriptionId); // Offset: 0x101dafccc // Return & Params: Num(2) Size(0x20)

	// Object Name: Function AkAudio.AkWaapiCalls.Conv_FAkWaapiSubscriptionIdToString
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FString Conv_FAkWaapiSubscriptionIdToString(struct FAkWaapiSubscriptionId& INAkWaapiSubscriptionId); // Offset: 0x101dafdc4 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function AkAudio.AkWaapiCalls.CallWaapi
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct FAKWaapiJsonObject CallWaapi(struct FAkWaapiUri& WaapiUri, struct FAKWaapiJsonObject& WaapiArgs, struct FAKWaapiJsonObject& WaapiOptions); // Offset: 0x101db03f8 // Return & Params: Num(4) Size(0x40)
};

// Object Name: Class AkAudio.SAkWaapiFieldNamesConv
// Size: 0x28 // Inherited bytes: 0x28
struct USAkWaapiFieldNamesConv : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function AkAudio.SAkWaapiFieldNamesConv.Conv_FAkWaapiFieldNamesToText
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FText Conv_FAkWaapiFieldNamesToText(struct FAkWaapiFieldNames& INAkWaapiFieldNames); // Offset: 0x101db1040 // Return & Params: Num(2) Size(0x28)

	// Object Name: Function AkAudio.SAkWaapiFieldNamesConv.Conv_FAkWaapiFieldNamesToString
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FString Conv_FAkWaapiFieldNamesToString(struct FAkWaapiFieldNames& INAkWaapiFieldNames); // Offset: 0x101db1144 // Return & Params: Num(2) Size(0x20)
};

// Object Name: Class AkAudio.AkWaapiJsonManager
// Size: 0x28 // Inherited bytes: 0x28
struct UAkWaapiJsonManager : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function AkAudio.AkWaapiJsonManager.SetStringField
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct FAKWaapiJsonObject SetStringField(struct FAkWaapiFieldNames& FieldName, struct FString FieldValue, struct FAKWaapiJsonObject Target); // Offset: 0x101db3938 // Return & Params: Num(4) Size(0x40)

	// Object Name: Function AkAudio.AkWaapiJsonManager.SetObjectField
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct FAKWaapiJsonObject SetObjectField(struct FAkWaapiFieldNames& FieldName, struct FAKWaapiJsonObject FieldValue, struct FAKWaapiJsonObject Target); // Offset: 0x101db2ec4 // Return & Params: Num(4) Size(0x40)

	// Object Name: Function AkAudio.AkWaapiJsonManager.SetNumberField
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct FAKWaapiJsonObject SetNumberField(struct FAkWaapiFieldNames& FieldName, float FieldValue, struct FAKWaapiJsonObject Target); // Offset: 0x101db32f8 // Return & Params: Num(4) Size(0x38)

	// Object Name: Function AkAudio.AkWaapiJsonManager.SetBoolField
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct FAKWaapiJsonObject SetBoolField(struct FAkWaapiFieldNames& FieldName, bool FieldValue, struct FAKWaapiJsonObject Target); // Offset: 0x101db3610 // Return & Params: Num(4) Size(0x38)

	// Object Name: Function AkAudio.AkWaapiJsonManager.SetArrayStringFields
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct FAKWaapiJsonObject SetArrayStringFields(struct FAkWaapiFieldNames& FieldName, struct TArray<struct FString>& FieldStringValues, struct FAKWaapiJsonObject Target); // Offset: 0x101db2b54 // Return & Params: Num(4) Size(0x40)

	// Object Name: Function AkAudio.AkWaapiJsonManager.SetArrayObjectFields
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct FAKWaapiJsonObject SetArrayObjectFields(struct FAkWaapiFieldNames& FieldName, struct TArray<struct FAKWaapiJsonObject>& FieldObjectValues, struct FAKWaapiJsonObject Target); // Offset: 0x101db2798 // Return & Params: Num(4) Size(0x40)

	// Object Name: Function AkAudio.AkWaapiJsonManager.GetStringField
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct FString GetStringField(struct FAkWaapiFieldNames& FieldName, struct FAKWaapiJsonObject Target); // Offset: 0x101db255c // Return & Params: Num(3) Size(0x30)

	// Object Name: Function AkAudio.AkWaapiJsonManager.GetObjectField
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct FAKWaapiJsonObject GetObjectField(struct FAkWaapiFieldNames& FieldName, struct FAKWaapiJsonObject Target); // Offset: 0x101db1c84 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function AkAudio.AkWaapiJsonManager.GetNumberField
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	float GetNumberField(struct FAkWaapiFieldNames& FieldName, struct FAKWaapiJsonObject Target); // Offset: 0x101db215c // Return & Params: Num(3) Size(0x24)

	// Object Name: Function AkAudio.AkWaapiJsonManager.GetIntegerField
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	int32_t GetIntegerField(struct FAkWaapiFieldNames& FieldName, struct FAKWaapiJsonObject Target); // Offset: 0x101db1f5c // Return & Params: Num(3) Size(0x24)

	// Object Name: Function AkAudio.AkWaapiJsonManager.GetBoolField
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool GetBoolField(struct FAkWaapiFieldNames& FieldName, struct FAKWaapiJsonObject Target); // Offset: 0x101db235c // Return & Params: Num(3) Size(0x21)

	// Object Name: Function AkAudio.AkWaapiJsonManager.GetArrayField
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct TArray<struct FAKWaapiJsonObject> GetArrayField(struct FAkWaapiFieldNames& FieldName, struct FAKWaapiJsonObject Target); // Offset: 0x101db18fc // Return & Params: Num(3) Size(0x30)

	// Object Name: Function AkAudio.AkWaapiJsonManager.Conv_FAKWaapiJsonObjectToText
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FText Conv_FAKWaapiJsonObjectToText(struct FAKWaapiJsonObject INAKWaapiJsonObject); // Offset: 0x101db150c // Return & Params: Num(2) Size(0x28)

	// Object Name: Function AkAudio.AkWaapiJsonManager.Conv_FAKWaapiJsonObjectToString
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FString Conv_FAKWaapiJsonObjectToString(struct FAKWaapiJsonObject INAKWaapiJsonObject); // Offset: 0x101db171c // Return & Params: Num(2) Size(0x20)
};

// Object Name: Class AkAudio.AkWaapiUriConv
// Size: 0x28 // Inherited bytes: 0x28
struct UAkWaapiUriConv : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function AkAudio.AkWaapiUriConv.Conv_FAkWaapiUriToText
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FText Conv_FAkWaapiUriToText(struct FAkWaapiUri& INAkWaapiUri); // Offset: 0x101db42fc // Return & Params: Num(2) Size(0x28)

	// Object Name: Function AkAudio.AkWaapiUriConv.Conv_FAkWaapiUriToString
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FString Conv_FAkWaapiUriToString(struct FAkWaapiUri& INAkWaapiUri); // Offset: 0x101db4400 // Return & Params: Num(2) Size(0x20)
};

// Object Name: Class AkAudio.AkWindowsInitializationSettings
// Size: 0xf8 // Inherited bytes: 0x28
struct UAkWindowsInitializationSettings : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08
	struct FAkCommonInitializationSettingsWithSampleRate CommonSettings; // Offset: 0x30 // Size: 0x68
	struct FAkCommunicationSettingsWithSystemInitialization CommunicationSettings; // Offset: 0x98 // Size: 0x28
	struct FAkWindowsAdvancedInitializationSettings AdvancedSettings; // Offset: 0xc0 // Size: 0x34
	char pad_0xF4[0x4]; // Offset: 0xf4 // Size: 0x04

	// Functions

	// Object Name: Function AkAudio.AkWindowsInitializationSettings.MigrateMultiCoreRendering
	// Flags: [Final|Native|Public]
	void MigrateMultiCoreRendering(bool NewValue); // Offset: 0x101db4820 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class AkAudio.AkWin32PlatformInfo
// Size: 0x70 // Inherited bytes: 0x70
struct UAkWin32PlatformInfo : UAkPlatformInfo {
};

// Object Name: Class AkAudio.AkWin64PlatformInfo
// Size: 0x70 // Inherited bytes: 0x70
struct UAkWin64PlatformInfo : UAkPlatformInfo {
};

// Object Name: Class AkAudio.AkWindowsPlatformInfo
// Size: 0x70 // Inherited bytes: 0x70
struct UAkWindowsPlatformInfo : UAkWin64PlatformInfo {
};

// Object Name: Class AkAudio.AkWwiseTree
// Size: 0x178 // Inherited bytes: 0x138
struct UAkWwiseTree : UWidget {
	// Fields
	struct FMulticastInlineDelegate OnSelectionChanged; // Offset: 0x138 // Size: 0x10
	struct FMulticastInlineDelegate OnItemDragged; // Offset: 0x148 // Size: 0x10
	char pad_0x158[0x20]; // Offset: 0x158 // Size: 0x20

	// Functions

	// Object Name: Function AkAudio.AkWwiseTree.SetSearchText
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	void SetSearchText(struct FString newText); // Offset: 0x101db4ed0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AkAudio.AkWwiseTree.GetSelectedItem
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FAkWwiseObjectDetails GetSelectedItem(); // Offset: 0x101db4fdc // Return & Params: Num(1) Size(0x30)

	// Object Name: Function AkAudio.AkWwiseTree.GetSearchText
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FString GetSearchText(); // Offset: 0x101db4f5c // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class AkAudio.AkWwiseTreeSelector
// Size: 0x198 // Inherited bytes: 0x138
struct UAkWwiseTreeSelector : UWidget {
	// Fields
	struct FMulticastInlineDelegate OnSelectionChanged; // Offset: 0x138 // Size: 0x10
	struct FMulticastInlineDelegate OnItemDragged; // Offset: 0x148 // Size: 0x10
	char pad_0x158[0x40]; // Offset: 0x158 // Size: 0x40
};

// Object Name: Class AkAudio.AkXboxOneInitializationSettings
// Size: 0xf8 // Inherited bytes: 0x28
struct UAkXboxOneInitializationSettings : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08
	struct FAkCommonInitializationSettings CommonSettings; // Offset: 0x30 // Size: 0x60
	struct FAkXboxOneApuHeapInitializationSettings ApuHeapSettings; // Offset: 0x90 // Size: 0x08
	struct FAkCommunicationSettingsWithSystemInitialization CommunicationSettings; // Offset: 0x98 // Size: 0x28
	struct FAkXboxOneAdvancedInitializationSettings AdvancedSettings; // Offset: 0xc0 // Size: 0x34
	char pad_0xF4[0x4]; // Offset: 0xf4 // Size: 0x04

	// Functions

	// Object Name: Function AkAudio.AkXboxOneInitializationSettings.MigrateMultiCoreRendering
	// Flags: [Final|Native|Public]
	void MigrateMultiCoreRendering(bool NewValue); // Offset: 0x101db564c // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class AkAudio.AkXboxOnePlatformInfo
// Size: 0x70 // Inherited bytes: 0x70
struct UAkXboxOnePlatformInfo : UAkPlatformInfo {
};

// Object Name: Class AkAudio.InterpTrackAkAudioEvent
// Size: 0xa8 // Inherited bytes: 0x90
struct UInterpTrackAkAudioEvent : UInterpTrackVectorBase {
	// Fields
	struct TArray<struct FAkAudioEventTrackKey> Events; // Offset: 0x90 // Size: 0x10
	char bContinueEventOnMatineeEnd : 1; // Offset: 0xa0 // Size: 0x01
	char pad_0xA0_1 : 7; // Offset: 0xa0 // Size: 0x01
	char pad_0xA1[0x7]; // Offset: 0xa1 // Size: 0x07
};

// Object Name: Class AkAudio.InterpTrackAkAudioRTPC
// Size: 0xa8 // Inherited bytes: 0x90
struct UInterpTrackAkAudioRTPC : UInterpTrackFloatBase {
	// Fields
	struct FString Param; // Offset: 0x90 // Size: 0x10
	char bPlayOnReverse : 1; // Offset: 0xa0 // Size: 0x01
	char bContinueRTPCOnMatineeEnd : 1; // Offset: 0xa0 // Size: 0x01
	char pad_0xA0_2 : 6; // Offset: 0xa0 // Size: 0x01
	char pad_0xA1[0x7]; // Offset: 0xa1 // Size: 0x07
};

// Object Name: Class AkAudio.InterpTrackInstAkAudioEvent
// Size: 0x30 // Inherited bytes: 0x28
struct UInterpTrackInstAkAudioEvent : UInterpTrackInst {
	// Fields
	float LastUpdatePosition; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
};

// Object Name: Class AkAudio.InterpTrackInstAkAudioRTPC
// Size: 0x30 // Inherited bytes: 0x28
struct UInterpTrackInstAkAudioRTPC : UInterpTrackInst {
	// Fields
	float LastUpdatePosition; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
};

// Object Name: Class AkAudio.MovieSceneAkAudioEventSection
// Size: 0x1d8 // Inherited bytes: 0xd8
struct UMovieSceneAkAudioEventSection : UMovieSceneSection {
	// Fields
	char pad_0xD8[0x58]; // Offset: 0xd8 // Size: 0x58
	struct UAkAudioEvent* Event; // Offset: 0x130 // Size: 0x08
	bool RetriggerEvent; // Offset: 0x138 // Size: 0x01
	char pad_0x139[0x3]; // Offset: 0x139 // Size: 0x03
	int32_t ScrubTailLengthMs; // Offset: 0x13c // Size: 0x04
	bool StopAtSectionEnd; // Offset: 0x140 // Size: 0x01
	char pad_0x141[0x7]; // Offset: 0x141 // Size: 0x07
	struct FString EventName; // Offset: 0x148 // Size: 0x10
	char pad_0x158[0x20]; // Offset: 0x158 // Size: 0x20
	float MaxSourceDuration; // Offset: 0x178 // Size: 0x04
	char pad_0x17C[0x4]; // Offset: 0x17c // Size: 0x04
	struct FString MaxDurationSourceID; // Offset: 0x180 // Size: 0x10
	char pad_0x190[0x48]; // Offset: 0x190 // Size: 0x48
};

// Object Name: Class AkAudio.MovieSceneAkTrack
// Size: 0x70 // Inherited bytes: 0x58
struct UMovieSceneAkTrack : UMovieSceneTrack {
	// Fields
	struct TArray<struct UMovieSceneSection*> Sections; // Offset: 0x58 // Size: 0x10
	char bIsAMasterTrack : 1; // Offset: 0x68 // Size: 0x01
	char pad_0x68_1 : 7; // Offset: 0x68 // Size: 0x01
	char pad_0x69[0x7]; // Offset: 0x69 // Size: 0x07
};

// Object Name: Class AkAudio.MovieSceneAkAudioEventTrack
// Size: 0x70 // Inherited bytes: 0x70
struct UMovieSceneAkAudioEventTrack : UMovieSceneAkTrack {
};

// Object Name: Class AkAudio.MovieSceneAkAudioRTPCSection
// Size: 0x240 // Inherited bytes: 0xd8
struct UMovieSceneAkAudioRTPCSection : UMovieSceneSection {
	// Fields
	struct UAkRtpc* RTPC; // Offset: 0xd8 // Size: 0x08
	struct FString Name; // Offset: 0xe0 // Size: 0x10
	struct FRichCurve FloatCurve; // Offset: 0xf0 // Size: 0x80
	struct FMovieSceneFloatChannelSerializationHelper FloatChannelSerializationHelper; // Offset: 0x170 // Size: 0x30
	struct FMovieSceneFloatChannel RTPCChannel; // Offset: 0x1a0 // Size: 0xa0
};

// Object Name: Class AkAudio.MovieSceneAkAudioRTPCTrack
// Size: 0x70 // Inherited bytes: 0x70
struct UMovieSceneAkAudioRTPCTrack : UMovieSceneAkTrack {
};

// Object Name: Class AkAudio.PostEventAsync
// Size: 0xa0 // Inherited bytes: 0x30
struct UPostEventAsync : UBlueprintAsyncActionBase {
	// Fields
	struct FMulticastInlineDelegate Completed; // Offset: 0x30 // Size: 0x10
	char pad_0x40[0x60]; // Offset: 0x40 // Size: 0x60

	// Functions

	// Object Name: Function AkAudio.PostEventAsync.PostEventAsync
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct UPostEventAsync* PostEventAsync(struct UObject* WorldContextObject, struct UAkAudioEvent* AkEvent, struct AActor* Actor, int32_t CallbackMask, struct FDelegate& PostEventCallback, struct TArray<struct FAkExternalSourceInfo>& ExternalSources, bool bStopWhenAttachedToDestroyed); // Offset: 0x101dbc1d0 // Return & Params: Num(8) Size(0x50)

	// Object Name: Function AkAudio.PostEventAsync.PollPostEventFuture
	// Flags: [Final|Native|Private]
	void PollPostEventFuture(); // Offset: 0x101dbc1bc // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class AkAudio.PostEventAtLocationAsync
// Size: 0x80 // Inherited bytes: 0x30
struct UPostEventAtLocationAsync : UBlueprintAsyncActionBase {
	// Fields
	struct FMulticastInlineDelegate Completed; // Offset: 0x30 // Size: 0x10
	char pad_0x40[0x40]; // Offset: 0x40 // Size: 0x40

	// Functions

	// Object Name: Function AkAudio.PostEventAtLocationAsync.PostEventAtLocationAsync
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasDefaults|BlueprintCallable]
	struct UPostEventAtLocationAsync* PostEventAtLocationAsync(struct UObject* WorldContextObject, struct UAkAudioEvent* AkEvent, struct FVector Location, struct FRotator Orientation); // Offset: 0x101dbc95c // Return & Params: Num(5) Size(0x30)

	// Object Name: Function AkAudio.PostEventAtLocationAsync.PollPostEventFuture
	// Flags: [Final|Native|Private]
	void PollPostEventFuture(); // Offset: 0x101dbc948 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class AkAudio.WwiseDataQuery
// Size: 0x28 // Inherited bytes: 0x28
struct UWwiseDataQuery : UObject {
};

