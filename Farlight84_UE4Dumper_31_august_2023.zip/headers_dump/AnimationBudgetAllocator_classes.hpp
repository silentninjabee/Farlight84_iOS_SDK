#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class AnimationBudgetAllocator.AnimationBudgetBlueprintLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct UAnimationBudgetBlueprintLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function AnimationBudgetAllocator.AnimationBudgetBlueprintLibrary.SetAnimationBudgetParameters
	// Flags: [Final|Native|Static|Private|HasOutParms|BlueprintCallable]
	void SetAnimationBudgetParameters(struct UObject* WorldContextObject, struct FAnimationBudgetAllocatorParameters& InParameters); // Offset: 0x100f1d058 // Return & Params: Num(2) Size(0x5c)

	// Object Name: Function AnimationBudgetAllocator.AnimationBudgetBlueprintLibrary.EnableAnimationBudget
	// Flags: [Final|Native|Static|Private|BlueprintCallable]
	void EnableAnimationBudget(struct UObject* WorldContextObject, bool bEnabled); // Offset: 0x100f1d198 // Return & Params: Num(2) Size(0x9)
};

// Object Name: Class AnimationBudgetAllocator.SkeletalMeshComponentBudgeted
// Size: 0xc80 // Inherited bytes: 0xc50
struct USkeletalMeshComponentBudgeted : USkeletalMeshComponent {
	// Fields
	enum class ESkeletalMeshAnimDetailMode AnimDetailMode; // Offset: 0xc48 // Size: 0x01
	char pad_0xC51[0x1f]; // Offset: 0xc51 // Size: 0x1f
	char bAutoRegisterWithBudgetAllocator : 1; // Offset: 0xc70 // Size: 0x01
	char bAutoCalculateSignificance : 1; // Offset: 0xc70 // Size: 0x01
	char bShouldUseActorRenderedFlag : 1; // Offset: 0xc70 // Size: 0x01
	char pad_0xC70_3 : 5; // Offset: 0xc70 // Size: 0x01
	char pad_0xC71[0xf]; // Offset: 0xc71 // Size: 0x0f

	// Functions

	// Object Name: Function AnimationBudgetAllocator.SkeletalMeshComponentBudgeted.SetAutoRegisterWithBudgetAllocator
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAutoRegisterWithBudgetAllocator(bool bInAutoRegisterWithBudgetAllocator); // Offset: 0x100f1d5bc // Return & Params: Num(1) Size(0x1)
};

