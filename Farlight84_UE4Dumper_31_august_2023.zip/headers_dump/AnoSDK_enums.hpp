#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum AnoSDK.ETssSDKEntryId
enum class ETssSDKEntryId : uint8 {
	QZONE = 0,
	MM = 1,
	FACEBOOK = 2,
	TWITTER = 3,
	LINE = 4,
	WHATSAPP = 5,
	GAMECENTER = 6,
	GOOGLEPLAY = 7,
	VK = 8,
	KUAISHOU = 9,
	APPLE = 10,
	NEXON = 11,
	NAVER = 12,
	GARENA = 13,
	HUAWEI = 14,
	RIOT = 15,
	NINTENDO = 16,
	PSN = 17,
	MICROSOFT = 18,
	EA = 19,
	FARLIGHT = 20,
	OTHERS = 21,
	ETssSDKEntryId_MAX = 22
};

// Object Name: Enum AnoSDK.ETssSDKRequestCmdId
enum class ETssSDKRequestCmdId : uint8 {
	IsEmulator = 0,
	CommQuery = 1,
	InitSwitchStr = 2,
	ETssSDKRequestCmdId_MAX = 3
};

