#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class AppleImageUtils.AppleImageUtilsBaseAsyncTaskBlueprintProxy
// Size: 0x90 // Inherited bytes: 0x28
struct UAppleImageUtilsBaseAsyncTaskBlueprintProxy : UObject {
	// Fields
	char pad_0x28[0x10]; // Offset: 0x28 // Size: 0x10
	struct FMulticastInlineDelegate OnSuccess; // Offset: 0x38 // Size: 0x10
	struct FMulticastInlineDelegate OnFailure; // Offset: 0x48 // Size: 0x10
	char pad_0x58[0x10]; // Offset: 0x58 // Size: 0x10
	struct FAppleImageUtilsImageConversionResult ConversionResult; // Offset: 0x68 // Size: 0x20
	char pad_0x88[0x8]; // Offset: 0x88 // Size: 0x08

	// Functions

	// Object Name: Function AppleImageUtils.AppleImageUtilsBaseAsyncTaskBlueprintProxy.CreateProxyObjectForConvertToTIFF
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UAppleImageUtilsBaseAsyncTaskBlueprintProxy* CreateProxyObjectForConvertToTIFF(struct UTexture* SourceImage, bool bWantColor, bool bUseGpu, float Scale, enum class ETextureRotationDirection Rotate); // Offset: 0x101fcc618 // Return & Params: Num(6) Size(0x20)

	// Object Name: Function AppleImageUtils.AppleImageUtilsBaseAsyncTaskBlueprintProxy.CreateProxyObjectForConvertToPNG
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UAppleImageUtilsBaseAsyncTaskBlueprintProxy* CreateProxyObjectForConvertToPNG(struct UTexture* SourceImage, bool bWantColor, bool bUseGpu, float Scale, enum class ETextureRotationDirection Rotate); // Offset: 0x101fcc448 // Return & Params: Num(6) Size(0x20)

	// Object Name: Function AppleImageUtils.AppleImageUtilsBaseAsyncTaskBlueprintProxy.CreateProxyObjectForConvertToJPEG
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UAppleImageUtilsBaseAsyncTaskBlueprintProxy* CreateProxyObjectForConvertToJPEG(struct UTexture* SourceImage, int32_t Quality, bool bWantColor, bool bUseGpu, float Scale, enum class ETextureRotationDirection Rotate); // Offset: 0x101fcca04 // Return & Params: Num(7) Size(0x20)

	// Object Name: Function AppleImageUtils.AppleImageUtilsBaseAsyncTaskBlueprintProxy.CreateProxyObjectForConvertToHEIF
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UAppleImageUtilsBaseAsyncTaskBlueprintProxy* CreateProxyObjectForConvertToHEIF(struct UTexture* SourceImage, int32_t Quality, bool bWantColor, bool bUseGpu, float Scale, enum class ETextureRotationDirection Rotate); // Offset: 0x101fcc7e8 // Return & Params: Num(7) Size(0x20)
};

// Object Name: Class AppleImageUtils.AppleImageInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UAppleImageInterface : UInterface {
};

