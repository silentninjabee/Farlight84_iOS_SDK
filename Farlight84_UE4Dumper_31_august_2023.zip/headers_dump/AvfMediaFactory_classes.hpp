#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class AvfMediaFactory.AvfMediaSettings
// Size: 0x30 // Inherited bytes: 0x28
struct UAvfMediaSettings : UObject {
	// Fields
	bool NativeAudioOut; // Offset: 0x28 // Size: 0x01
	char pad_0x29[0x7]; // Offset: 0x29 // Size: 0x07
};

