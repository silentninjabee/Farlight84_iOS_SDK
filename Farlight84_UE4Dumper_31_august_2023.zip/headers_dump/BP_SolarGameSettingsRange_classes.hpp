#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_SolarGameSettingsRange.BP_SolarGameSettingsRange_C
// Size: 0x170 // Inherited bytes: 0x170
struct UBP_SolarGameSettingsRange_C : USolarGameSettingsRange {
};

