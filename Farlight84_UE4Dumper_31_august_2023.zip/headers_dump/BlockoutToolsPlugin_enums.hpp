#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum BlockoutToolsPlugin.EBlockoutMaterialType
enum class EBlockoutMaterialType : uint8 {
	BlockoutMaterialType_Grid = 0,
	BlockoutMaterialType_CustomMaterial = 1,
	BlockoutMaterialType_MAX = 2
};

