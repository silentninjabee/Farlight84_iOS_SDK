#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct ClothingSystemRuntimeCommon.ClothConfig_Legacy
// Size: 0xd4 // Inherited bytes: 0x00
struct FClothConfig_Legacy {
	// Fields
	enum class EClothingWindMethod_Legacy WindMethod; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	struct FClothConstraintSetup_Legacy VerticalConstraintConfig; // Offset: 0x04 // Size: 0x10
	struct FClothConstraintSetup_Legacy HorizontalConstraintConfig; // Offset: 0x14 // Size: 0x10
	struct FClothConstraintSetup_Legacy BendConstraintConfig; // Offset: 0x24 // Size: 0x10
	struct FClothConstraintSetup_Legacy ShearConstraintConfig; // Offset: 0x34 // Size: 0x10
	float SelfCollisionRadius; // Offset: 0x44 // Size: 0x04
	float SelfCollisionStiffness; // Offset: 0x48 // Size: 0x04
	float SelfCollisionCullScale; // Offset: 0x4c // Size: 0x04
	struct FVector Damping; // Offset: 0x50 // Size: 0x0c
	float Friction; // Offset: 0x5c // Size: 0x04
	float WindDragCoefficient; // Offset: 0x60 // Size: 0x04
	float WindLiftCoefficient; // Offset: 0x64 // Size: 0x04
	struct FVector LinearDrag; // Offset: 0x68 // Size: 0x0c
	struct FVector AngularDrag; // Offset: 0x74 // Size: 0x0c
	struct FVector LinearInertiaScale; // Offset: 0x80 // Size: 0x0c
	struct FVector AngularInertiaScale; // Offset: 0x8c // Size: 0x0c
	struct FVector CentrifugalInertiaScale; // Offset: 0x98 // Size: 0x0c
	float SolverFrequency; // Offset: 0xa4 // Size: 0x04
	float StiffnessFrequency; // Offset: 0xa8 // Size: 0x04
	float GravityScale; // Offset: 0xac // Size: 0x04
	struct FVector GravityOverride; // Offset: 0xb0 // Size: 0x0c
	bool bUseGravityOverride; // Offset: 0xbc // Size: 0x01
	char pad_0xBD[0x3]; // Offset: 0xbd // Size: 0x03
	float TetherStiffness; // Offset: 0xc0 // Size: 0x04
	float TetherLimit; // Offset: 0xc4 // Size: 0x04
	float CollisionThickness; // Offset: 0xc8 // Size: 0x04
	float AnimDriveSpringStiffness; // Offset: 0xcc // Size: 0x04
	float AnimDriveDamperStiffness; // Offset: 0xd0 // Size: 0x04
};

// Object Name: ScriptStruct ClothingSystemRuntimeCommon.ClothConstraintSetup_Legacy
// Size: 0x10 // Inherited bytes: 0x00
struct FClothConstraintSetup_Legacy {
	// Fields
	float Stiffness; // Offset: 0x00 // Size: 0x04
	float StiffnessMultiplier; // Offset: 0x04 // Size: 0x04
	float StretchLimit; // Offset: 0x08 // Size: 0x04
	float CompressionLimit; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct ClothingSystemRuntimeCommon.ClothLODDataCommon
// Size: 0x158 // Inherited bytes: 0x00
struct FClothLODDataCommon {
	// Fields
	struct FClothPhysicalMeshData PhysicalMeshData; // Offset: 0x00 // Size: 0xf8
	struct FClothCollisionData CollisionData; // Offset: 0xf8 // Size: 0x40
	char pad_0x138[0x20]; // Offset: 0x138 // Size: 0x20
};

// Object Name: ScriptStruct ClothingSystemRuntimeCommon.ClothPhysicalMeshData
// Size: 0xf8 // Inherited bytes: 0x00
struct FClothPhysicalMeshData {
	// Fields
	struct TArray<struct FVector> Vertices; // Offset: 0x00 // Size: 0x10
	struct TArray<struct FVector> Normals; // Offset: 0x10 // Size: 0x10
	struct TArray<uint32_t> Indices; // Offset: 0x20 // Size: 0x10
	struct TMap<uint32_t, struct FPointWeightMap> WeightMaps; // Offset: 0x30 // Size: 0x50
	struct TArray<float> InverseMasses; // Offset: 0x80 // Size: 0x10
	struct TArray<struct FClothVertBoneData> BoneData; // Offset: 0x90 // Size: 0x10
	int32_t MaxBoneWeights; // Offset: 0xa0 // Size: 0x04
	int32_t NumFixedVerts; // Offset: 0xa4 // Size: 0x04
	struct TArray<uint32_t> SelfCollisionIndices; // Offset: 0xa8 // Size: 0x10
	struct TArray<float> MaxDistances; // Offset: 0xb8 // Size: 0x10
	struct TArray<float> BackstopDistances; // Offset: 0xc8 // Size: 0x10
	struct TArray<float> BackstopRadiuses; // Offset: 0xd8 // Size: 0x10
	struct TArray<float> AnimDriveMultipliers; // Offset: 0xe8 // Size: 0x10
};

// Object Name: ScriptStruct ClothingSystemRuntimeCommon.PointWeightMap
// Size: 0x10 // Inherited bytes: 0x00
struct FPointWeightMap {
	// Fields
	struct TArray<float> Values; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct ClothingSystemRuntimeCommon.ClothParameterMask_Legacy
// Size: 0x30 // Inherited bytes: 0x00
struct FClothParameterMask_Legacy {
	// Fields
	struct FName MaskName; // Offset: 0x00 // Size: 0x08
	enum class EWeightMapTargetCommon CurrentTarget; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x3]; // Offset: 0x09 // Size: 0x03
	float MaxValue; // Offset: 0x0c // Size: 0x04
	float MinValue; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct TArray<float> Values; // Offset: 0x18 // Size: 0x10
	bool bEnabled; // Offset: 0x28 // Size: 0x01
	char pad_0x29[0x7]; // Offset: 0x29 // Size: 0x07
};

