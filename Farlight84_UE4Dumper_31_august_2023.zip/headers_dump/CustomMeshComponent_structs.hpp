#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct CustomMeshComponent.CustomMeshTriangle
// Size: 0x24 // Inherited bytes: 0x00
struct FCustomMeshTriangle {
	// Fields
	struct FVector Vertex0; // Offset: 0x00 // Size: 0x0c
	struct FVector Vertex1; // Offset: 0x0c // Size: 0x0c
	struct FVector Vertex2; // Offset: 0x18 // Size: 0x0c
};

