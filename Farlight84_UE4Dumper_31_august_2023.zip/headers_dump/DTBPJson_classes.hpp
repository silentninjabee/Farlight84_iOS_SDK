#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class DTBPJson.DTBPJsonBPLib
// Size: 0x28 // Inherited bytes: 0x28
struct UDTBPJsonBPLib : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function DTBPJson.DTBPJsonBPLib.StructToJson
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	void StructToJson(struct FDTStruct& Struct, struct FString& Json, bool PrettyPrint); // Offset: 0x101e1b320 // Return & Params: Num(3) Size(0x19)

	// Object Name: Function DTBPJson.DTBPJsonBPLib.JsonToStruct
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	void JsonToStruct(struct FDTStruct& Struct, struct FString Json); // Offset: 0x101e1b220 // Return & Params: Num(2) Size(0x18)
};

