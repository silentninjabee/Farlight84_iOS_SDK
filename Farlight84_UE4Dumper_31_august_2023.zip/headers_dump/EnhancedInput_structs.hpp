#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct EnhancedInput.InputActionValue
// Size: 0x10 // Inherited bytes: 0x00
struct FInputActionValue {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct EnhancedInput.EnhancedActionKeyMapping
// Size: 0x48 // Inherited bytes: 0x00
struct FEnhancedActionKeyMapping {
	// Fields
	struct UInputAction* Action; // Offset: 0x00 // Size: 0x08
	struct FKey Key; // Offset: 0x08 // Size: 0x18
	char bShouldBeIgnored : 1; // Offset: 0x20 // Size: 0x01
	char pad_0x20_1 : 7; // Offset: 0x20 // Size: 0x01
	char pad_0x21[0x7]; // Offset: 0x21 // Size: 0x07
	struct TArray<struct UInputTrigger*> Triggers; // Offset: 0x28 // Size: 0x10
	struct TArray<struct UInputModifier*> Modifiers; // Offset: 0x38 // Size: 0x10
};

// Object Name: ScriptStruct EnhancedInput.BlueprintEnhancedInputActionBinding
// Size: 0x18 // Inherited bytes: 0x00
struct FBlueprintEnhancedInputActionBinding {
	// Fields
	struct UInputAction* InputAction; // Offset: 0x00 // Size: 0x08
	enum class ETriggerEvent TriggerEvent; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x3]; // Offset: 0x09 // Size: 0x03
	struct FName FunctionNameToBind; // Offset: 0x0c // Size: 0x08
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct EnhancedInput.InputActionInstance
// Size: 0x70 // Inherited bytes: 0x00
struct FInputActionInstance {
	// Fields
	struct UInputAction* SourceAction; // Offset: 0x00 // Size: 0x08
	char pad_0x8[0x8]; // Offset: 0x08 // Size: 0x08
	struct TArray<struct UInputTrigger*> Triggers; // Offset: 0x10 // Size: 0x10
	struct TArray<struct UInputModifier*> Modifiers; // Offset: 0x20 // Size: 0x10
	struct TArray<struct UInputModifier*> PerInputModifiers; // Offset: 0x30 // Size: 0x10
	struct TArray<struct UInputModifier*> FinalValueModifiers; // Offset: 0x40 // Size: 0x10
	char pad_0x50[0x10]; // Offset: 0x50 // Size: 0x10
	float ElapsedProcessedTime; // Offset: 0x60 // Size: 0x04
	float ElapsedTriggeredTime; // Offset: 0x64 // Size: 0x04
	enum class ETriggerEvent TriggerEvent; // Offset: 0x68 // Size: 0x01
	char pad_0x69[0x7]; // Offset: 0x69 // Size: 0x07
};

// Object Name: ScriptStruct EnhancedInput.BlueprintInputDebugKeyDelegateBinding
// Size: 0x30 // Inherited bytes: 0x00
struct FBlueprintInputDebugKeyDelegateBinding {
	// Fields
	struct FInputChord InputChord; // Offset: 0x00 // Size: 0x20
	enum class EInputEvent InputKeyEvent; // Offset: 0x20 // Size: 0x01
	char pad_0x21[0x3]; // Offset: 0x21 // Size: 0x03
	struct FName FunctionNameToBind; // Offset: 0x24 // Size: 0x08
	bool bExecuteWhenPaused; // Offset: 0x2c // Size: 0x01
	char pad_0x2D[0x3]; // Offset: 0x2d // Size: 0x03
};

// Object Name: ScriptStruct EnhancedInput.MappingQueryIssue
// Size: 0x18 // Inherited bytes: 0x00
struct FMappingQueryIssue {
	// Fields
	enum class EMappingQueryIssue Issue; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct UInputMappingContext* BlockingContext; // Offset: 0x08 // Size: 0x08
	struct UInputAction* BlockingAction; // Offset: 0x10 // Size: 0x08
};

