#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class FarlightPatchRuntime.PakHelper
// Size: 0x28 // Inherited bytes: 0x28
struct UPakHelper : UObject {
	// Functions

	// Object Name: Function FarlightPatchRuntime.PakHelper.ReloadIniFile
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool ReloadIniFile(struct FString StrippedConfigFileName, struct FString FilePath); // Offset: 0x101e1fa14 // Return & Params: Num(3) Size(0x21)

	// Object Name: Function FarlightPatchRuntime.PakHelper.ReloadGameUserSettings
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void ReloadGameUserSettings(); // Offset: 0x101e1f9d8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function FarlightPatchRuntime.PakHelper.ReloadDeviceProfiles
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void ReloadDeviceProfiles(); // Offset: 0x101e1f9ec // Return & Params: Num(0) Size(0x0)

	// Object Name: Function FarlightPatchRuntime.PakHelper.ReloadCVarSettingsFromIni
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void ReloadCVarSettingsFromIni(); // Offset: 0x101e1fa00 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function FarlightPatchRuntime.PakHelper.OpenShaderPatchLibrary
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void OpenShaderPatchLibrary(struct FString ShaderPatchLibraryName, struct FString LibraryDir, bool& bShaderPatchLibUnique); // Offset: 0x101e1faf8 // Return & Params: Num(3) Size(0x21)

	// Object Name: Function FarlightPatchRuntime.PakHelper.MountPak
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool MountPak(struct FString InPakFilename, int32_t PakOrder); // Offset: 0x101e1fcac // Return & Params: Num(3) Size(0x15)

	// Object Name: Function FarlightPatchRuntime.PakHelper.GetStrippedConfigFileName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetStrippedConfigFileName(struct FString IniName); // Offset: 0x101e1f914 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function FarlightPatchRuntime.PakHelper.GetProjectName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetProjectName(); // Offset: 0x101e1fc2c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function FarlightPatchRuntime.PakHelper.CreatePakWriter
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UPakWriter* CreatePakWriter(struct FString InFilename, struct FString InMountPoint); // Offset: 0x101e1fd84 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function FarlightPatchRuntime.PakHelper.CreatePakReader
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UPakReader* CreatePakReader(struct FString InFilename, bool bLoadIndex); // Offset: 0x101e1fe68 // Return & Params: Num(3) Size(0x20)
};

// Object Name: Class FarlightPatchRuntime.PakReader
// Size: 0x50 // Inherited bytes: 0x28
struct UPakReader : UObject {
	// Fields
	char pad_0x28[0x28]; // Offset: 0x28 // Size: 0x28

	// Functions

	// Object Name: Function FarlightPatchRuntime.PakReader.GetTotalSize
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int64_t GetTotalSize(); // Offset: 0x101e20690 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function FarlightPatchRuntime.PakReader.GetPakIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct TArray<struct FPakEntryInfo> GetPakIndex(); // Offset: 0x101e206ac // Return & Params: Num(1) Size(0x10)

	// Object Name: Function FarlightPatchRuntime.PakReader.Close
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Close(); // Offset: 0x101e207d0 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class FarlightPatchRuntime.PakWriter
// Size: 0xc0 // Inherited bytes: 0x28
struct UPakWriter : UObject {
	// Fields
	char pad_0x28[0x98]; // Offset: 0x28 // Size: 0x98
};

