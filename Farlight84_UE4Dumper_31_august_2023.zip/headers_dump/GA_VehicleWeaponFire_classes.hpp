#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass GA_VehicleWeaponFire.GA_VehicleWeaponFire_C
// Size: 0x4e8 // Inherited bytes: 0x4e8
struct UGA_VehicleWeaponFire_C : USolarVehicleGA_WeaponFire {
};

