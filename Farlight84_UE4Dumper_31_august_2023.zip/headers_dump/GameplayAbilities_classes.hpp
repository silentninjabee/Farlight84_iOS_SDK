#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class GameplayAbilities.AbilitySystemBlueprintLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct UAbilitySystemBlueprintLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.TargetDataHasOrigin
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	bool TargetDataHasOrigin(struct FGameplayAbilityTargetDataHandle& TargetData, int32_t Index); // Offset: 0x100fd5ae8 // Return & Params: Num(3) Size(0x2d)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.TargetDataHasHitResult
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	bool TargetDataHasHitResult(struct FGameplayAbilityTargetDataHandle& HitResult, int32_t Index); // Offset: 0x100fd5e18 // Return & Params: Num(3) Size(0x2d)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.TargetDataHasEndPoint
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	bool TargetDataHasEndPoint(struct FGameplayAbilityTargetDataHandle& TargetData, int32_t Index); // Offset: 0x100fd57b4 // Return & Params: Num(3) Size(0x2d)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.TargetDataHasActor
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	bool TargetDataHasActor(struct FGameplayAbilityTargetDataHandle& TargetData, int32_t Index); // Offset: 0x100fd5f94 // Return & Params: Num(3) Size(0x2d)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.SetStackCountToMax
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FGameplayEffectSpecHandle SetStackCountToMax(struct FGameplayEffectSpecHandle SpecHandle); // Offset: 0x100fcf368 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.SetStackCount
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FGameplayEffectSpecHandle SetStackCount(struct FGameplayEffectSpecHandle SpecHandle, int32_t StackCount); // Offset: 0x100fcf594 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.SetDuration
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FGameplayEffectSpecHandle SetDuration(struct FGameplayEffectSpecHandle SpecHandle, float Duration); // Offset: 0x100fd084c // Return & Params: Num(3) Size(0x28)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.SendGameplayEventToActor
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SendGameplayEventToActor(struct AActor* Actor, struct FGameplayTag EventTag, struct FGameplayEventData Payload); // Offset: 0x100fd8f00 // Return & Params: Num(3) Size(0xc0)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.NotEqual_GameplayAttributeGameplayAttribute
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	bool NotEqual_GameplayAttributeGameplayAttribute(struct FGameplayAttribute AttributeA, struct FGameplayAttribute AttributeB); // Offset: 0x100fd8014 // Return & Params: Num(3) Size(0x71)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.MakeSpecHandle
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FGameplayEffectSpecHandle MakeSpecHandle(struct UGameplayEffect* InGameplayEffect, struct AActor* InInstigator, struct AActor* InEffectCauser, float InLevel); // Offset: 0x100fd68c0 // Return & Params: Num(5) Size(0x30)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.MakeGameplayCueParameters
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	struct FGameplayCueParameters MakeGameplayCueParameters(float NormalizedMagnitude, float RawMagnitude, struct FGameplayEffectContextHandle EffectContext, struct FGameplayTag MatchedTagName, struct FGameplayTag OriginalTag, struct FGameplayTagContainer AggregatedSourceTags, struct FGameplayTagContainer AggregatedTargetTags, struct FVector Location, struct FVector Normal, struct AActor* Instigator, struct AActor* EffectCauser, struct UObject* SourceObject, struct UPhysicalMaterial* PhysicalMaterial, int32_t GameplayEffectLevel, int32_t AbilityLevel, struct USceneComponent* TargetAttachComponent); // Offset: 0x100fd1750 // Return & Params: Num(17) Size(0x178)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.MakeFilterHandle
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FGameplayTargetDataFilterHandle MakeFilterHandle(struct FGameplayTargetDataFilter Filter, struct AActor* FilterActor); // Offset: 0x100fd6af8 // Return & Params: Num(3) Size(0x40)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.IsValid
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	bool IsValid(struct FGameplayAttribute Attribute); // Offset: 0x100fd8e28 // Return & Params: Num(2) Size(0x39)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.IsInstigatorLocallyControlledPlayer
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	bool IsInstigatorLocallyControlledPlayer(struct FGameplayCueParameters Parameters); // Offset: 0x100fd3eb0 // Return & Params: Num(2) Size(0xc1)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.IsInstigatorLocallyControlled
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	bool IsInstigatorLocallyControlled(struct FGameplayCueParameters Parameters); // Offset: 0x100fd4110 // Return & Params: Num(2) Size(0xc1)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.HasHitResult
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	bool HasHitResult(struct FGameplayCueParameters Parameters); // Offset: 0x100fd346c // Return & Params: Num(2) Size(0xc1)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetTargetDataOrigin
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	struct FTransform GetTargetDataOrigin(struct FGameplayAbilityTargetDataHandle& TargetData, int32_t Index); // Offset: 0x100fd5930 // Return & Params: Num(3) Size(0x60)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetTargetDataEndPointTransform
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	struct FTransform GetTargetDataEndPointTransform(struct FGameplayAbilityTargetDataHandle& TargetData, int32_t Index); // Offset: 0x100fd547c // Return & Params: Num(3) Size(0x60)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetTargetDataEndPoint
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	struct FVector GetTargetDataEndPoint(struct FGameplayAbilityTargetDataHandle& TargetData, int32_t Index); // Offset: 0x100fd5634 // Return & Params: Num(3) Size(0x38)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetOrigin
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	struct FVector GetOrigin(struct FGameplayCueParameters Parameters); // Offset: 0x100fd29c4 // Return & Params: Num(2) Size(0xcc)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetModifiedAttributeMagnitude
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	float GetModifiedAttributeMagnitude(struct FGameplayEffectSpecHandle SpecHandle, struct FGameplayAttribute Attribute); // Offset: 0x100fcecac // Return & Params: Num(3) Size(0x4c)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetInstigatorTransform
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	struct FTransform GetInstigatorTransform(struct FGameplayCueParameters Parameters); // Offset: 0x100fd2c2c // Return & Params: Num(2) Size(0xf0)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetInstigatorActor
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct AActor* GetInstigatorActor(struct FGameplayCueParameters Parameters); // Offset: 0x100fd2ec8 // Return & Params: Num(2) Size(0xc8)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetHitResultFromTargetData
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FHitResult GetHitResultFromTargetData(struct FGameplayAbilityTargetDataHandle& HitResult, int32_t Index); // Offset: 0x100fd5c64 // Return & Params: Num(3) Size(0xb4)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetHitResult
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FHitResult GetHitResult(struct FGameplayCueParameters Parameters); // Offset: 0x100fd36cc // Return & Params: Num(2) Size(0x148)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetGameplayCueEndLocationAndNormal
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	bool GetGameplayCueEndLocationAndNormal(struct AActor* TargetActor, struct FGameplayCueParameters Parameters, struct FVector& Location, struct FVector& Normal); // Offset: 0x100fd2620 // Return & Params: Num(5) Size(0xe1)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetGameplayCueDirection
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	bool GetGameplayCueDirection(struct AActor* TargetActor, struct FGameplayCueParameters Parameters, struct FVector& Direction); // Offset: 0x100fd22d8 // Return & Params: Num(4) Size(0xd5)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetFloatAttributeFromAbilitySystemComponent
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	float GetFloatAttributeFromAbilitySystemComponent(struct UAbilitySystemComponent* AbilitySystem, struct FGameplayAttribute Attribute, bool& bSuccessfullyFoundAttribute); // Offset: 0x100fd8b28 // Return & Params: Num(4) Size(0x48)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetFloatAttributeBaseFromAbilitySystemComponent
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	float GetFloatAttributeBaseFromAbilitySystemComponent(struct UAbilitySystemComponent* AbilitySystemComponent, struct FGameplayAttribute Attribute, bool& bSuccessfullyFoundAttribute); // Offset: 0x100fd8828 // Return & Params: Num(4) Size(0x48)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetFloatAttributeBase
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	float GetFloatAttributeBase(struct AActor* Actor, struct FGameplayAttribute Attribute, bool& bSuccessfullyFoundAttribute); // Offset: 0x100fd89a8 // Return & Params: Num(4) Size(0x48)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetFloatAttribute
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	float GetFloatAttribute(struct AActor* Actor, struct FGameplayAttribute Attribute, bool& bSuccessfullyFoundAttribute); // Offset: 0x100fd8ca8 // Return & Params: Num(4) Size(0x48)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetEffectContext
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FGameplayEffectContextHandle GetEffectContext(struct FGameplayEffectSpecHandle SpecHandle); // Offset: 0x100fcf138 // Return & Params: Num(2) Size(0x28)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetDataCountFromTargetData
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	int32_t GetDataCountFromTargetData(struct FGameplayAbilityTargetDataHandle& TargetData); // Offset: 0x100fd74ec // Return & Params: Num(2) Size(0x2c)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetAllLinkedGameplayEffectSpecHandles
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct TArray<struct FGameplayEffectSpecHandle> GetAllLinkedGameplayEffectSpecHandles(struct FGameplayEffectSpecHandle SpecHandle); // Offset: 0x100fcee98 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetAllActorsFromTargetData
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct TArray<struct AActor*> GetAllActorsFromTargetData(struct FGameplayAbilityTargetDataHandle& TargetData); // Offset: 0x100fd62d8 // Return & Params: Num(2) Size(0x38)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetActorsFromTargetData
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct TArray<struct AActor*> GetActorsFromTargetData(struct FGameplayAbilityTargetDataHandle& TargetData, int32_t Index); // Offset: 0x100fd6448 // Return & Params: Num(3) Size(0x40)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetActorCount
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	int32_t GetActorCount(struct FGameplayCueParameters Parameters); // Offset: 0x100fd3c50 // Return & Params: Num(2) Size(0xc4)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetActorByIndex
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct AActor* GetActorByIndex(struct FGameplayCueParameters Parameters, int32_t Index); // Offset: 0x100fd3984 // Return & Params: Num(3) Size(0xd0)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetActiveGameplayEffectTotalDuration
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	float GetActiveGameplayEffectTotalDuration(struct FActiveGameplayEffectHandle ActiveHandle); // Offset: 0x100fcea04 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetActiveGameplayEffectStartTime
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	float GetActiveGameplayEffectStartTime(struct FActiveGameplayEffectHandle ActiveHandle); // Offset: 0x100fceb14 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetActiveGameplayEffectStackLimitCount
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int32_t GetActiveGameplayEffectStackLimitCount(struct FActiveGameplayEffectHandle ActiveHandle); // Offset: 0x100fceb9c // Return & Params: Num(2) Size(0xc)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetActiveGameplayEffectStackCount
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int32_t GetActiveGameplayEffectStackCount(struct FActiveGameplayEffectHandle ActiveHandle); // Offset: 0x100fcec24 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetActiveGameplayEffectRemainingDuration
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	float GetActiveGameplayEffectRemainingDuration(struct UObject* WorldContextObject, struct FActiveGameplayEffectHandle ActiveHandle); // Offset: 0x100fce92c // Return & Params: Num(3) Size(0x14)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetActiveGameplayEffectExpectedEndTime
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	float GetActiveGameplayEffectExpectedEndTime(struct FActiveGameplayEffectHandle ActiveHandle); // Offset: 0x100fcea8c // Return & Params: Num(2) Size(0xc)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetActiveGameplayEffectDebugString
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FString GetActiveGameplayEffectDebugString(struct FActiveGameplayEffectHandle ActiveHandle); // Offset: 0x100fce860 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetAbilitySystemComponent
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct UAbilitySystemComponent* GetAbilitySystemComponent(struct AActor* Actor); // Offset: 0x100fd9154 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.ForwardGameplayCueToTarget
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void ForwardGameplayCueToTarget(struct TScriptInterface<IGameplayCueInterface> TargetCueInterface, enum class EGameplayCueEvent EventType, struct FGameplayCueParameters Parameters); // Offset: 0x100fd3128 // Return & Params: Num(3) Size(0xd8)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.FilterTargetData
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FGameplayAbilityTargetDataHandle FilterTargetData(struct FGameplayAbilityTargetDataHandle& TargetDataHandle, struct FGameplayTargetDataFilterHandle ActorFilterClass); // Offset: 0x100fd6cc4 // Return & Params: Num(3) Size(0x60)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.EvaluateAttributeValueWithTagsAndBase
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	float EvaluateAttributeValueWithTagsAndBase(struct UAbilitySystemComponent* AbilitySystem, struct FGameplayAttribute Attribute, struct FGameplayTagContainer& SourceTags, struct FGameplayTagContainer& TargetTags, float BaseValue, bool& bSuccess); // Offset: 0x100fd830c // Return & Params: Num(7) Size(0x8c)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.EvaluateAttributeValueWithTags
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	float EvaluateAttributeValueWithTags(struct UAbilitySystemComponent* AbilitySystem, struct FGameplayAttribute Attribute, struct FGameplayTagContainer& SourceTags, struct FGameplayTagContainer& TargetTags, bool& bSuccess); // Offset: 0x100fd85c0 // Return & Params: Num(6) Size(0x88)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.EqualEqual_GameplayAttributeGameplayAttribute
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	bool EqualEqual_GameplayAttributeGameplayAttribute(struct FGameplayAttribute AttributeA, struct FGameplayAttribute AttributeB); // Offset: 0x100fd8190 // Return & Params: Num(3) Size(0x71)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.EffectContextSetOrigin
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	void EffectContextSetOrigin(struct FGameplayEffectContextHandle EffectContext, struct FVector Origin); // Offset: 0x100fd4930 // Return & Params: Num(2) Size(0x24)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.EffectContextIsValid
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	bool EffectContextIsValid(struct FGameplayEffectContextHandle EffectContext); // Offset: 0x100fd530c // Return & Params: Num(2) Size(0x19)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.EffectContextIsInstigatorLocallyControlled
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	bool EffectContextIsInstigatorLocallyControlled(struct FGameplayEffectContextHandle EffectContext); // Offset: 0x100fd519c // Return & Params: Num(2) Size(0x19)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.EffectContextHasHitResult
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	bool EffectContextHasHitResult(struct FGameplayEffectContextHandle EffectContext); // Offset: 0x100fd4e94 // Return & Params: Num(2) Size(0x19)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.EffectContextGetSourceObject
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct UObject* EffectContextGetSourceObject(struct FGameplayEffectContextHandle EffectContext); // Offset: 0x100fd4370 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.EffectContextGetOriginalInstigatorActor
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct AActor* EffectContextGetOriginalInstigatorActor(struct FGameplayEffectContextHandle EffectContext); // Offset: 0x100fd4650 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.EffectContextGetOrigin
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	struct FVector EffectContextGetOrigin(struct FGameplayEffectContextHandle EffectContext); // Offset: 0x100fd4ae0 // Return & Params: Num(2) Size(0x24)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.EffectContextGetInstigatorActor
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct AActor* EffectContextGetInstigatorActor(struct FGameplayEffectContextHandle EffectContext); // Offset: 0x100fd47c0 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.EffectContextGetHitResult
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FHitResult EffectContextGetHitResult(struct FGameplayEffectContextHandle EffectContext); // Offset: 0x100fd5004 // Return & Params: Num(2) Size(0xa0)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.EffectContextGetEffectCauser
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct AActor* EffectContextGetEffectCauser(struct FGameplayEffectContextHandle EffectContext); // Offset: 0x100fd44e0 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.EffectContextAddHitResult
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void EffectContextAddHitResult(struct FGameplayEffectContextHandle EffectContext, struct FHitResult HitResult, bool bReset); // Offset: 0x100fd4c54 // Return & Params: Num(3) Size(0xa1)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.DoesTargetDataContainActor
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	bool DoesTargetDataContainActor(struct FGameplayAbilityTargetDataHandle& TargetData, int32_t Index, struct AActor* Actor); // Offset: 0x100fd6110 // Return & Params: Num(4) Size(0x39)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.DoesGameplayCueMeetTagRequirements
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	bool DoesGameplayCueMeetTagRequirements(struct FGameplayCueParameters Parameters, struct FGameplayTagRequirements& SourceTagReqs, struct FGameplayTagRequirements& TargetTagReqs); // Offset: 0x100fd1f34 // Return & Params: Num(4) Size(0x161)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.CloneSpecHandle
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FGameplayEffectSpecHandle CloneSpecHandle(struct AActor* InNewInstigator, struct AActor* InEffectCauser, struct FGameplayEffectSpecHandle GameplayEffectSpecHandle_Clone); // Offset: 0x100fd65fc // Return & Params: Num(4) Size(0x30)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.BreakGameplayCueParameters
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	void BreakGameplayCueParameters(struct FGameplayCueParameters& Parameters, float& NormalizedMagnitude, float& RawMagnitude, struct FGameplayEffectContextHandle& EffectContext, struct FGameplayTag& MatchedTagName, struct FGameplayTag& OriginalTag, struct FGameplayTagContainer& AggregatedSourceTags, struct FGameplayTagContainer& AggregatedTargetTags, struct FVector& Location, struct FVector& Normal, struct AActor*& Instigator, struct AActor*& EffectCauser, struct UObject*& SourceObject, struct UPhysicalMaterial*& PhysicalMaterial, int32_t& GameplayEffectLevel, int32_t& AbilityLevel, struct USceneComponent*& TargetAttachComponent); // Offset: 0x100fd104c // Return & Params: Num(17) Size(0x178)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.AssignTagSetByCallerMagnitude
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FGameplayEffectSpecHandle AssignTagSetByCallerMagnitude(struct FGameplayEffectSpecHandle SpecHandle, struct FGameplayTag DataTag, float Magnitude); // Offset: 0x100fd0ac4 // Return & Params: Num(4) Size(0x30)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.AssignSetByCallerMagnitude
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FGameplayEffectSpecHandle AssignSetByCallerMagnitude(struct FGameplayEffectSpecHandle SpecHandle, struct FName DataName, float Magnitude); // Offset: 0x100fd0d88 // Return & Params: Num(4) Size(0x30)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.AppendTargetDataHandle
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct FGameplayAbilityTargetDataHandle AppendTargetDataHandle(struct FGameplayAbilityTargetDataHandle TargetHandle, struct FGameplayAbilityTargetDataHandle& HandleToAdd); // Offset: 0x100fd7b3c // Return & Params: Num(3) Size(0x78)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.AddLinkedGameplayEffectSpec
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FGameplayEffectSpecHandle AddLinkedGameplayEffectSpec(struct FGameplayEffectSpecHandle SpecHandle, struct FGameplayEffectSpecHandle LinkedGameplayEffectSpec); // Offset: 0x100fcfa84 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.AddLinkedGameplayEffect
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FGameplayEffectSpecHandle AddLinkedGameplayEffect(struct FGameplayEffectSpecHandle SpecHandle, struct UGameplayEffect* LinkedGameplayEffect); // Offset: 0x100fcf80c // Return & Params: Num(3) Size(0x28)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.AddGrantedTags
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FGameplayEffectSpecHandle AddGrantedTags(struct FGameplayEffectSpecHandle SpecHandle, struct FGameplayTagContainer NewGameplayTags); // Offset: 0x100fd0310 // Return & Params: Num(3) Size(0x40)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.AddGrantedTag
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FGameplayEffectSpecHandle AddGrantedTag(struct FGameplayEffectSpecHandle SpecHandle, struct FGameplayTag NewGameplayTag); // Offset: 0x100fd05d4 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.AddAssetTags
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FGameplayEffectSpecHandle AddAssetTags(struct FGameplayEffectSpecHandle SpecHandle, struct FGameplayTagContainer NewGameplayTags); // Offset: 0x100fcfdd4 // Return & Params: Num(3) Size(0x40)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.AddAssetTag
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FGameplayEffectSpecHandle AddAssetTag(struct FGameplayEffectSpecHandle SpecHandle, struct FGameplayTag NewGameplayTag); // Offset: 0x100fd0098 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.AbilityTargetDataFromLocations
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FGameplayAbilityTargetDataHandle AbilityTargetDataFromLocations(struct FGameplayAbilityTargetingLocationInfo& SourceLocation, struct FGameplayAbilityTargetingLocationInfo& TargetLocation); // Offset: 0x100fd784c // Return & Params: Num(3) Size(0xe8)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.AbilityTargetDataFromHitResult
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FGameplayAbilityTargetDataHandle AbilityTargetDataFromHitResult(struct FHitResult& HitResult); // Offset: 0x100fd7620 // Return & Params: Num(2) Size(0xb0)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.AbilityTargetDataFromActorArray
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FGameplayAbilityTargetDataHandle AbilityTargetDataFromActorArray(struct TArray<struct AActor*>& ActorArray, bool OneTargetPerHandle); // Offset: 0x100fd7084 // Return & Params: Num(3) Size(0x40)

	// Object Name: Function GameplayAbilities.AbilitySystemBlueprintLibrary.AbilityTargetDataFromActor
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FGameplayAbilityTargetDataHandle AbilityTargetDataFromActor(struct AActor* Actor); // Offset: 0x100fd72e0 // Return & Params: Num(2) Size(0x30)
};

// Object Name: Class GameplayAbilities.AbilitySystemComponent
// Size: 0x12f8 // Inherited bytes: 0x120
struct UAbilitySystemComponent : UGameplayTasksComponent {
	// Fields
	char pad_0x120[0x10]; // Offset: 0x120 // Size: 0x10
	struct TArray<struct FAttributeDefaults> DefaultStartingData; // Offset: 0x130 // Size: 0x10
	struct TArray<struct UAttributeSet*> SpawnedAttributes; // Offset: 0x140 // Size: 0x10
	struct FName AffectedAnimInstanceTag; // Offset: 0x150 // Size: 0x08
	char pad_0x158[0x1a0]; // Offset: 0x158 // Size: 0x1a0
	float OutgoingDuration; // Offset: 0x2f8 // Size: 0x04
	float IncomingDuration; // Offset: 0x2fc // Size: 0x04
	char pad_0x300[0x20]; // Offset: 0x300 // Size: 0x20
	struct TArray<struct FString> ClientDebugStrings; // Offset: 0x320 // Size: 0x10
	struct TArray<struct FString> ServerDebugStrings; // Offset: 0x330 // Size: 0x10
	char pad_0x340[0x60]; // Offset: 0x340 // Size: 0x60
	bool UserAbilityActivationInhibited; // Offset: 0x3a0 // Size: 0x01
	bool ReplicationProxyEnabled; // Offset: 0x3a1 // Size: 0x01
	bool bSuppressGrantAbility; // Offset: 0x3a2 // Size: 0x01
	bool bSuppressGameplayCues; // Offset: 0x3a3 // Size: 0x01
	char pad_0x3A4[0x4]; // Offset: 0x3a4 // Size: 0x04
	struct TArray<struct AGameplayAbilityTargetActor*> SpawnedTargetActors; // Offset: 0x3a8 // Size: 0x10
	char pad_0x3B8[0x28]; // Offset: 0x3b8 // Size: 0x28
	struct AActor* OwnerActor; // Offset: 0x3e0 // Size: 0x08
	struct AActor* AvatarActor; // Offset: 0x3e8 // Size: 0x08
	char pad_0x3F0[0x10]; // Offset: 0x3f0 // Size: 0x10
	struct FGameplayAbilitySpecContainer ActivatableAbilities; // Offset: 0x400 // Size: 0x120
	char pad_0x520[0x30]; // Offset: 0x520 // Size: 0x30
	struct TArray<struct UGameplayAbility*> AllReplicatedInstancedAbilities; // Offset: 0x550 // Size: 0x10
	char pad_0x560[0x1d0]; // Offset: 0x560 // Size: 0x1d0
	struct FGameplayAbilityRepAnimMontage RepAnimMontageInfo; // Offset: 0x730 // Size: 0x38
	bool bCachedIsNetSimulated; // Offset: 0x768 // Size: 0x01
	bool bPendingMontageRep; // Offset: 0x769 // Size: 0x01
	char pad_0x76A[0x6]; // Offset: 0x76a // Size: 0x06
	struct FGameplayAbilityLocalAnimMontage LocalAnimMontageInfo; // Offset: 0x770 // Size: 0x30
	char pad_0x7A0[0xa0]; // Offset: 0x7a0 // Size: 0xa0
	struct FActiveGameplayEffectsContainer ActiveGameplayEffects; // Offset: 0x840 // Size: 0x480
	struct FActiveGameplayCueContainer ActiveGameplayCues; // Offset: 0xcc0 // Size: 0x128
	struct FActiveGameplayCueContainer MinimalReplicationGameplayCues; // Offset: 0xde8 // Size: 0x128
	char pad_0xF10[0x128]; // Offset: 0xf10 // Size: 0x128
	struct TArray<char> BlockedAbilityBindings; // Offset: 0x1038 // Size: 0x10
	char pad_0x1048[0x128]; // Offset: 0x1048 // Size: 0x128
	struct FMinimalReplicationTagCountMap MinimalReplicationTags; // Offset: 0x1170 // Size: 0x60
	char pad_0x11D0[0x10]; // Offset: 0x11d0 // Size: 0x10
	struct FReplicatedPredictionKeyMap ReplicatedPredictionKeyMap; // Offset: 0x11e0 // Size: 0x118

	// Functions

	// Object Name: Function GameplayAbilities.AbilitySystemComponent.TryActivateAbilityByClass
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool TryActivateAbilityByClass(struct UGameplayAbility* InAbilityToActivate, bool bAllowRemoteActivation); // Offset: 0x100fdd894 // Return & Params: Num(3) Size(0xa)

	// Object Name: Function GameplayAbilities.AbilitySystemComponent.TryActivateAbilitiesByTag
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	bool TryActivateAbilitiesByTag(struct FGameplayTagContainer& GameplayTagContainer, bool bAllowRemoteActivation); // Offset: 0x100fdd978 // Return & Params: Num(3) Size(0x22)

	// Object Name: Function GameplayAbilities.AbilitySystemComponent.TargetConfirm
	// Flags: [Native|Public|BlueprintCallable]
	void TargetConfirm(); // Offset: 0x100fdd0e0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function GameplayAbilities.AbilitySystemComponent.TargetCancel
	// Flags: [Native|Public|BlueprintCallable]
	void TargetCancel(); // Offset: 0x100fdd0c4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function GameplayAbilities.AbilitySystemComponent.SetUserAbilityActivationInhibited
	// Flags: [Native|Public|BlueprintCallable]
	void SetUserAbilityActivationInhibited(bool NewInhibit); // Offset: 0x100fdd0fc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function GameplayAbilities.AbilitySystemComponent.SetActiveGameplayEffectLevelUsingQuery
	// Flags: [BlueprintAuthorityOnly|Native|Public|BlueprintCallable]
	void SetActiveGameplayEffectLevelUsingQuery(struct FGameplayEffectQuery Query, int32_t NewLevel); // Offset: 0x100fdff3c // Return & Params: Num(2) Size(0x154)

	// Object Name: Function GameplayAbilities.AbilitySystemComponent.SetActiveGameplayEffectLevel
	// Flags: [BlueprintAuthorityOnly|Native|Public|BlueprintCallable]
	void SetActiveGameplayEffectLevel(struct FActiveGameplayEffectHandle ActiveHandle, int32_t NewLevel); // Offset: 0x100fe0038 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function GameplayAbilities.AbilitySystemComponent.ServerTryActivateAbilityWithEventData
	// Flags: [Net|NetReliableNative|Event|Protected|NetServer|NetValidate]
	void ServerTryActivateAbilityWithEventData(struct FGameplayAbilitySpecHandle AbilityToActivate, bool InputPressed, struct FPredictionKey PredictionKey, struct FGameplayEventData TriggerEventData); // Offset: 0x100fdbeb0 // Return & Params: Num(4) Size(0xd0)

	// Object Name: Function GameplayAbilities.AbilitySystemComponent.ServerTryActivateAbility
	// Flags: [Net|NetReliableNative|Event|Protected|NetServer|NetValidate]
	void ServerTryActivateAbility(struct FGameplayAbilitySpecHandle AbilityToActivate, bool InputPressed, struct FPredictionKey PredictionKey); // Offset: 0x100fdc2e4 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function GameplayAbilities.AbilitySystemComponent.ServerSetReplicatedTargetDataCancelled
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	void ServerSetReplicatedTargetDataCancelled(struct FGameplayAbilitySpecHandle AbilityHandle, struct FPredictionKey AbilityOriginalPredictionKey, struct FPredictionKey CurrentPredictionKey); // Offset: 0x100fdc614 // Return & Params: Num(3) Size(0x38)

	// Object Name: Function GameplayAbilities.AbilitySystemComponent.ServerSetReplicatedTargetData
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	void ServerSetReplicatedTargetData(struct FGameplayAbilitySpecHandle AbilityHandle, struct FPredictionKey AbilityOriginalPredictionKey, struct FGameplayAbilityTargetDataHandle ReplicatedTargetDataHandle, struct FGameplayTag ApplicationTag, struct FPredictionKey CurrentPredictionKey); // Offset: 0x100fdc7d4 // Return & Params: Num(5) Size(0x68)

	// Object Name: Function GameplayAbilities.AbilitySystemComponent.ServerSetReplicatedEventWithPayload
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	void ServerSetReplicatedEventWithPayload(enum class EAbilityGenericReplicatedEvent EventType, struct FGameplayAbilitySpecHandle AbilityHandle, struct FPredictionKey AbilityOriginalPredictionKey, struct FPredictionKey CurrentPredictionKey, struct FVector_NetQuantize100 VectorPayload); // Offset: 0x100fdcc24 // Return & Params: Num(5) Size(0x44)

	// Object Name: Function GameplayAbilities.AbilitySystemComponent.ServerSetReplicatedEvent
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	void ServerSetReplicatedEvent(enum class EAbilityGenericReplicatedEvent EventType, struct FGameplayAbilitySpecHandle AbilityHandle, struct FPredictionKey AbilityOriginalPredictionKey, struct FPredictionKey CurrentPredictionKey); // Offset: 0x100fdce9c // Return & Params: Num(4) Size(0x38)

	// Object Name: Function GameplayAbilities.AbilitySystemComponent.ServerSetInputReleased
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	void ServerSetInputReleased(struct FGameplayAbilitySpecHandle AbilityHandle); // Offset: 0x100fdc494 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function GameplayAbilities.AbilitySystemComponent.ServerSetInputPressed
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	void ServerSetInputPressed(struct FGameplayAbilitySpecHandle AbilityHandle); // Offset: 0x100fdc554 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function GameplayAbilities.AbilitySystemComponent.ServerPrintDebug_RequestWithStrings
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	void ServerPrintDebug_RequestWithStrings(struct TArray<struct FString> Strings); // Offset: 0x100fdd740 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function GameplayAbilities.AbilitySystemComponent.ServerPrintDebug_Request
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	void ServerPrintDebug_Request(); // Offset: 0x100fdd838 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function GameplayAbilities.AbilitySystemComponent.ServerEndAbility
	// Flags: [Net|NetReliableNative|Event|Protected|NetServer|NetValidate]
	void ServerEndAbility(struct FGameplayAbilitySpecHandle AbilityToEnd, struct FGameplayAbilityActivationInfo ActivationInfo, struct FPredictionKey PredictionKey); // Offset: 0x100fdbc88 // Return & Params: Num(3) Size(0x40)

	// Object Name: Function GameplayAbilities.AbilitySystemComponent.ServerCurrentMontageSetPlayRate
	// Flags: [Net|NetReliableNative|Event|Protected|NetServer|NetValidate]
	void ServerCurrentMontageSetPlayRate(struct UAnimMontage* ClientAnimMontage, float InPlayRate); // Offset: 0x100fdb170 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function GameplayAbilities.AbilitySystemComponent.ServerCurrentMontageSetNextSectionName
	// Flags: [Net|NetReliableNative|Event|Protected|NetServer|NetValidate]
	void ServerCurrentMontageSetNextSectionName(struct UAnimMontage* ClientAnimMontage, float ClientPosition, struct FName SectionName, struct FName NextSectionName); // Offset: 0x100fdb380 // Return & Params: Num(4) Size(0x1c)

	// Object Name: Function GameplayAbilities.AbilitySystemComponent.ServerCurrentMontageJumpToSectionName
	// Flags: [Net|NetReliableNative|Event|Protected|NetServer|NetValidate]
	void ServerCurrentMontageJumpToSectionName(struct UAnimMontage* ClientAnimMontage, struct FName SectionName); // Offset: 0x100fdb27c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function GameplayAbilities.AbilitySystemComponent.ServerCancelAbility
	// Flags: [Net|NetReliableNative|Event|Protected|NetServer|NetValidate]
	void ServerCancelAbility(struct FGameplayAbilitySpecHandle AbilityToCancel, struct FGameplayAbilityActivationInfo ActivationInfo); // Offset: 0x100fdba7c // Return & Params: Num(2) Size(0x28)

	// Object Name: Function GameplayAbilities.AbilitySystemComponent.ServerAbilityRPCBatch
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	void ServerAbilityRPCBatch(struct FServerAbilityRPCBatch BatchInfo); // Offset: 0x100fdd1c0 // Return & Params: Num(1) Size(0x50)

	// Object Name: Function GameplayAbilities.AbilitySystemComponent.RemoveActiveGameplayEffectBySourceEffect
	// Flags: [BlueprintAuthorityOnly|Native|Public|BlueprintCallable]
	void RemoveActiveGameplayEffectBySourceEffect(struct UGameplayEffect* GameplayEffect, struct UAbilitySystemComponent* InstigatorAbilitySystemComponent, int32_t StacksToRemove); // Offset: 0x100fe0644 // Return & Params: Num(3) Size(0x14)

	// Object Name: Function GameplayAbilities.AbilitySystemComponent.RemoveActiveGameplayEffect
	// Flags: [BlueprintAuthorityOnly|Native|Public|BlueprintCallable]
	bool RemoveActiveGameplayEffect(struct FActiveGameplayEffectHandle Handle, int32_t StacksToRemove); // Offset: 0x100fe0760 // Return & Params: Num(3) Size(0xd)

	// Object Name: Function GameplayAbilities.AbilitySystemComponent.RemoveActiveEffectsWithTags
	// Flags: [Final|Native|Public|BlueprintCallable]
	int32_t RemoveActiveEffectsWithTags(struct FGameplayTagContainer Tags); // Offset: 0x100fdf6dc // Return & Params: Num(2) Size(0x24)

	// Object Name: Function GameplayAbilities.AbilitySystemComponent.RemoveActiveEffectsWithSourceTags
	// Flags: [Final|Native|Public|BlueprintCallable]
	int32_t RemoveActiveEffectsWithSourceTags(struct FGameplayTagContainer Tags); // Offset: 0x100fdf604 // Return & Params: Num(2) Size(0x24)

	// Object Name: Function GameplayAbilities.AbilitySystemComponent.RemoveActiveEffectsWithGrantedTags
	// Flags: [Final|Native|Public|BlueprintCallable]
	int32_t RemoveActiveEffectsWithGrantedTags(struct FGameplayTagContainer Tags); // Offset: 0x100fdf454 // Return & Params: Num(2) Size(0x24)

	// Object Name: Function GameplayAbilities.AbilitySystemComponent.RemoveActiveEffectsWithAppliedTags
	// Flags: [Final|Native|Public|BlueprintCallable]
	int32_t RemoveActiveEffectsWithAppliedTags(struct FGameplayTagContainer Tags); // Offset: 0x100fdf52c // Return & Params: Num(2) Size(0x24)

	// Object Name: Function GameplayAbilities.AbilitySystemComponent.OnRep_ServerDebugString
	// Flags: [Native|Public]
	void OnRep_ServerDebugString(); // Offset: 0x100fdd5f4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function GameplayAbilities.AbilitySystemComponent.OnRep_ReplicatedAnimMontage
	// Flags: [Native|Protected]
	void OnRep_ReplicatedAnimMontage(); // Offset: 0x100fdb524 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function GameplayAbilities.AbilitySystemComponent.OnRep_OwningActor
	// Flags: [Final|Native|Public]
	void OnRep_OwningActor(); // Offset: 0x100fdd0b0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function GameplayAbilities.AbilitySystemComponent.OnRep_ClientDebugString
	// Flags: [Native|Public]
	void OnRep_ClientDebugString(); // Offset: 0x100fdd610 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function GameplayAbilities.AbilitySystemComponent.OnRep_ActivateAbilities
	// Flags: [Native|Protected]
	void OnRep_ActivateAbilities(); // Offset: 0x100fdc478 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function GameplayAbilities.AbilitySystemComponent.NetMulticast_InvokeGameplayCuesExecuted_WithParams
	// Flags: [Net|Native|Event|NetMulticast|Public]
	void NetMulticast_InvokeGameplayCuesExecuted_WithParams(struct FGameplayTagContainer GameplayCueTags, struct FPredictionKey PredictionKey, struct FGameplayCueParameters GameplayCueParameters); // Offset: 0x100fde78c // Return & Params: Num(3) Size(0xf8)

	// Object Name: Function GameplayAbilities.AbilitySystemComponent.NetMulticast_InvokeGameplayCuesExecuted
	// Flags: [Net|Native|Event|NetMulticast|Public]
	void NetMulticast_InvokeGameplayCuesExecuted(struct FGameplayTagContainer GameplayCueTags, struct FPredictionKey PredictionKey, struct FGameplayEffectContextHandle EffectContext); // Offset: 0x100fdeddc // Return & Params: Num(3) Size(0x50)

	// Object Name: Function GameplayAbilities.AbilitySystemComponent.NetMulticast_InvokeGameplayCuesAddedAndWhileActive_WithParams
	// Flags: [Net|Native|Event|NetMulticast|Public]
	void NetMulticast_InvokeGameplayCuesAddedAndWhileActive_WithParams(struct FGameplayTagContainer GameplayCueTags, struct FPredictionKey PredictionKey, struct FGameplayCueParameters GameplayCueParameters); // Offset: 0x100fddb14 // Return & Params: Num(3) Size(0xf8)

	// Object Name: Function GameplayAbilities.AbilitySystemComponent.NetMulticast_InvokeGameplayCueExecuted_WithParams
	// Flags: [Net|Native|Event|NetMulticast|Public]
	void NetMulticast_InvokeGameplayCueExecuted_WithParams(struct FGameplayTag GameplayCueTag, struct FPredictionKey PredictionKey, struct FGameplayCueParameters GameplayCueParameters); // Offset: 0x100fdead4 // Return & Params: Num(3) Size(0xe0)

	// Object Name: Function GameplayAbilities.AbilitySystemComponent.NetMulticast_InvokeGameplayCueExecuted_FromSpec
	// Flags: [Net|Native|Event|NetMulticast|Public]
	void NetMulticast_InvokeGameplayCueExecuted_FromSpec(struct FGameplayEffectSpecForRPC Spec, struct FPredictionKey PredictionKey); // Offset: 0x100fdf26c // Return & Params: Num(2) Size(0x90)

	// Object Name: Function GameplayAbilities.AbilitySystemComponent.NetMulticast_InvokeGameplayCueExecuted
	// Flags: [Net|Native|Event|NetMulticast|Public]
	void NetMulticast_InvokeGameplayCueExecuted(struct FGameplayTag GameplayCueTag, struct FPredictionKey PredictionKey, struct FGameplayEffectContextHandle EffectContext); // Offset: 0x100fdf04c // Return & Params: Num(3) Size(0x38)

	// Object Name: Function GameplayAbilities.AbilitySystemComponent.NetMulticast_InvokeGameplayCueAddedAndWhileActive_WithParams
	// Flags: [Net|Native|Event|NetMulticast|Public]
	void NetMulticast_InvokeGameplayCueAddedAndWhileActive_WithParams(struct FGameplayTag GameplayCueTag, struct FPredictionKey PredictionKey, struct FGameplayCueParameters GameplayCueParameters); // Offset: 0x100fdde5c // Return & Params: Num(3) Size(0xe0)

	// Object Name: Function GameplayAbilities.AbilitySystemComponent.NetMulticast_InvokeGameplayCueAddedAndWhileActive_FromSpec
	// Flags: [Net|Native|Event|NetMulticast|Public]
	void NetMulticast_InvokeGameplayCueAddedAndWhileActive_FromSpec(struct FGameplayEffectSpecForRPC Spec, struct FPredictionKey PredictionKey); // Offset: 0x100fde164 // Return & Params: Num(2) Size(0x90)

	// Object Name: Function GameplayAbilities.AbilitySystemComponent.NetMulticast_InvokeGameplayCueAdded_WithParams
	// Flags: [Net|Native|Event|NetMulticast|Public]
	void NetMulticast_InvokeGameplayCueAdded_WithParams(struct FGameplayTag GameplayCueTag, struct FPredictionKey PredictionKey, struct FGameplayCueParameters Parameters); // Offset: 0x100fde264 // Return & Params: Num(3) Size(0xe0)

	// Object Name: Function GameplayAbilities.AbilitySystemComponent.NetMulticast_InvokeGameplayCueAdded
	// Flags: [Net|Native|Event|NetMulticast|Public]
	void NetMulticast_InvokeGameplayCueAdded(struct FGameplayTag GameplayCueTag, struct FPredictionKey PredictionKey, struct FGameplayEffectContextHandle EffectContext); // Offset: 0x100fde56c // Return & Params: Num(3) Size(0x38)

	// Object Name: Function GameplayAbilities.AbilitySystemComponent.MakeOutgoingSpec
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FGameplayEffectSpecHandle MakeOutgoingSpec(struct UGameplayEffect* GameplayEffectClass, float Level, struct FGameplayEffectContextHandle Context); // Offset: 0x100fe0360 // Return & Params: Num(4) Size(0x38)

	// Object Name: Function GameplayAbilities.AbilitySystemComponent.MakeEffectContext
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FGameplayEffectContextHandle MakeEffectContext(); // Offset: 0x100fe0240 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function GameplayAbilities.AbilitySystemComponent.K2_InitStats
	// Flags: [Final|Native|Public|BlueprintCallable]
	void K2_InitStats(struct UAttributeSet* Attributes, struct UDataTable* DataTable); // Offset: 0x100fe0a90 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function GameplayAbilities.AbilitySystemComponent.IsGameplayCueActive
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsGameplayCueActive(struct FGameplayTag GameplayCueTag); // Offset: 0x100fdda7c // Return & Params: Num(2) Size(0x9)

	// Object Name: Function GameplayAbilities.AbilitySystemComponent.GetUserAbilityActivationInhibited
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool GetUserAbilityActivationInhibited(); // Offset: 0x100fdd18c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function GameplayAbilities.AbilitySystemComponent.GetGameplayEffectMagnitude
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetGameplayEffectMagnitude(struct FActiveGameplayEffectHandle Handle, struct FGameplayAttribute Attribute); // Offset: 0x100fdfe08 // Return & Params: Num(3) Size(0x44)

	// Object Name: Function GameplayAbilities.AbilitySystemComponent.GetGameplayEffectCount
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	int32_t GetGameplayEffectCount(struct UGameplayEffect* SourceGameplayEffect, struct UAbilitySystemComponent* OptionalInstigatorFilterComponent, bool bEnforceOnGoingCheck); // Offset: 0x100fe0114 // Return & Params: Num(4) Size(0x18)

	// Object Name: Function GameplayAbilities.AbilitySystemComponent.GetActiveEffectsWithAllTags
	// Flags: [Final|Native|Public|BlueprintCallable|Const]
	struct TArray<struct FActiveGameplayEffectHandle> GetActiveEffectsWithAllTags(struct FGameplayTagContainer Tags); // Offset: 0x100fdf7b4 // Return & Params: Num(2) Size(0x30)

	// Object Name: Function GameplayAbilities.AbilitySystemComponent.GetActiveEffects
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|Const]
	struct TArray<struct FActiveGameplayEffectHandle> GetActiveEffects(struct FGameplayEffectQuery& Query); // Offset: 0x100fdf8c8 // Return & Params: Num(2) Size(0x160)

	// Object Name: Function GameplayAbilities.AbilitySystemComponent.ClientTryActivateAbility
	// Flags: [Net|NetReliableNative|Event|Protected|NetClient]
	void ClientTryActivateAbility(struct FGameplayAbilitySpecHandle AbilityToActivate); // Offset: 0x100fdbe24 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function GameplayAbilities.AbilitySystemComponent.ClientSetReplicatedEvent
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	void ClientSetReplicatedEvent(enum class EAbilityGenericReplicatedEvent EventType, struct FGameplayAbilitySpecHandle AbilityHandle, struct FPredictionKey AbilityOriginalPredictionKey); // Offset: 0x100fdcadc // Return & Params: Num(3) Size(0x20)

	// Object Name: Function GameplayAbilities.AbilitySystemComponent.ClientPrintDebug_Response
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	void ClientPrintDebug_Response(struct TArray<struct FString> Strings, int32_t GameFlags); // Offset: 0x100fdd62c // Return & Params: Num(2) Size(0x14)

	// Object Name: Function GameplayAbilities.AbilitySystemComponent.ClientEndAbility
	// Flags: [Net|NetReliableNative|Event|Protected|NetClient]
	void ClientEndAbility(struct FGameplayAbilitySpecHandle AbilityToEnd, struct FGameplayAbilityActivationInfo ActivationInfo); // Offset: 0x100fdbba4 // Return & Params: Num(2) Size(0x28)

	// Object Name: Function GameplayAbilities.AbilitySystemComponent.ClientCancelAbility
	// Flags: [Net|NetReliableNative|Event|Protected|NetClient]
	void ClientCancelAbility(struct FGameplayAbilitySpecHandle AbilityToCancel, struct FGameplayAbilityActivationInfo ActivationInfo); // Offset: 0x100fdb998 // Return & Params: Num(2) Size(0x28)

	// Object Name: Function GameplayAbilities.AbilitySystemComponent.ClientActivateAbilitySucceedWithEventData
	// Flags: [Net|NetReliableNative|Event|Protected|NetClient]
	void ClientActivateAbilitySucceedWithEventData(struct FGameplayAbilitySpecHandle AbilityToActivate, struct FPredictionKey PredictionKey, struct FGameplayEventData TriggerEventData); // Offset: 0x100fdb540 // Return & Params: Num(3) Size(0xd0)

	// Object Name: Function GameplayAbilities.AbilitySystemComponent.ClientActivateAbilitySucceed
	// Flags: [Net|NetReliableNative|Event|Protected|NetClient]
	void ClientActivateAbilitySucceed(struct FGameplayAbilitySpecHandle AbilityToActivate, struct FPredictionKey PredictionKey); // Offset: 0x100fdb7c8 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function GameplayAbilities.AbilitySystemComponent.ClientActivateAbilityFailed
	// Flags: [Net|NetReliableNative|Event|Protected|NetClient]
	void ClientActivateAbilityFailed(struct FGameplayAbilitySpecHandle AbilityToActivate, int16_t PredictionKey); // Offset: 0x100fdb8c0 // Return & Params: Num(2) Size(0x6)

	// Object Name: Function GameplayAbilities.AbilitySystemComponent.BP_ApplyGameplayEffectToTarget
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FActiveGameplayEffectHandle BP_ApplyGameplayEffectToTarget(struct UGameplayEffect* GameplayEffectClass, struct UAbilitySystemComponent* Target, float Level, struct FGameplayEffectContextHandle Context); // Offset: 0x100fdfbb4 // Return & Params: Num(5) Size(0x38)

	// Object Name: Function GameplayAbilities.AbilitySystemComponent.BP_ApplyGameplayEffectToSelf
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FActiveGameplayEffectHandle BP_ApplyGameplayEffectToSelf(struct UGameplayEffect* GameplayEffectClass, float Level, struct FGameplayEffectContextHandle EffectContext); // Offset: 0x100fdf9a8 // Return & Params: Num(4) Size(0x30)

	// Object Name: Function GameplayAbilities.AbilitySystemComponent.BP_ApplyGameplayEffectSpecToTarget
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	struct FActiveGameplayEffectHandle BP_ApplyGameplayEffectSpecToTarget(struct FGameplayEffectSpecHandle& SpecHandle, struct UAbilitySystemComponent* Target); // Offset: 0x100fe094c // Return & Params: Num(3) Size(0x20)

	// Object Name: Function GameplayAbilities.AbilitySystemComponent.BP_ApplyGameplayEffectSpecToSelf
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	struct FActiveGameplayEffectHandle BP_ApplyGameplayEffectSpecToSelf(struct FGameplayEffectSpecHandle& SpecHandle); // Offset: 0x100fe084c // Return & Params: Num(2) Size(0x18)

	// Object Name: DelegateFunction GameplayAbilities.AbilitySystemComponent.AbilityConfirmOrCancel__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void AbilityConfirmOrCancel__DelegateSignature(); // Offset: 0x1032ea4b8 // Return & Params: Num(0) Size(0x0)

	// Object Name: DelegateFunction GameplayAbilities.AbilitySystemComponent.AbilityAbilityKey__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void AbilityAbilityKey__DelegateSignature(int32_t InputID); // Offset: 0x1032ea4b8 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class GameplayAbilities.AbilitySystemDebugHUD
// Size: 0x318 // Inherited bytes: 0x318
struct AAbilitySystemDebugHUD : AHUD {
};

// Object Name: Class GameplayAbilities.AbilitySystemGlobals
// Size: 0x260 // Inherited bytes: 0x28
struct UAbilitySystemGlobals : UObject {
	// Fields
	struct FSoftClassPath AbilitySystemGlobalsClassName; // Offset: 0x28 // Size: 0x18
	char pad_0x40[0x28]; // Offset: 0x40 // Size: 0x28
	struct FGameplayTag ActivateFailIsDeadTag; // Offset: 0x68 // Size: 0x08
	struct FName ActivateFailIsDeadName; // Offset: 0x70 // Size: 0x08
	struct FGameplayTag ActivateFailCooldownTag; // Offset: 0x78 // Size: 0x08
	struct FName ActivateFailCooldownName; // Offset: 0x80 // Size: 0x08
	struct FGameplayTag ActivateFailCostTag; // Offset: 0x88 // Size: 0x08
	struct FName ActivateFailCostName; // Offset: 0x90 // Size: 0x08
	struct FGameplayTag ActivateFailTagsBlockedTag; // Offset: 0x98 // Size: 0x08
	struct FName ActivateFailTagsBlockedName; // Offset: 0xa0 // Size: 0x08
	struct FGameplayTag ActivateFailTagsMissingTag; // Offset: 0xa8 // Size: 0x08
	struct FName ActivateFailTagsMissingName; // Offset: 0xb0 // Size: 0x08
	struct FGameplayTag ActivateFailNetworkingTag; // Offset: 0xb8 // Size: 0x08
	struct FName ActivateFailNetworkingName; // Offset: 0xc0 // Size: 0x08
	int32_t MinimalReplicationTagCountBits; // Offset: 0xc8 // Size: 0x04
	char pad_0xCC[0x4]; // Offset: 0xcc // Size: 0x04
	struct FNetSerializeScriptStructCache TargetDataStructCache; // Offset: 0xd0 // Size: 0x10
	bool bAllowGameplayModEvaluationChannels; // Offset: 0xe0 // Size: 0x01
	enum class EGameplayModEvaluationChannel DefaultGameplayModEvaluationChannel; // Offset: 0xe1 // Size: 0x01
	char pad_0xE2[0x2]; // Offset: 0xe2 // Size: 0x02
	struct FName GameplayModEvaluationChannelAliases[0xa]; // Offset: 0xe4 // Size: 0x50
	char pad_0x134[0x4]; // Offset: 0x134 // Size: 0x04
	struct FSoftObjectPath GlobalCurveTableName; // Offset: 0x138 // Size: 0x18
	struct UCurveTable* GlobalCurveTable; // Offset: 0x150 // Size: 0x08
	struct FSoftObjectPath GlobalAttributeMetaDataTableName; // Offset: 0x158 // Size: 0x18
	struct UDataTable* GlobalAttributeMetaDataTable; // Offset: 0x170 // Size: 0x08
	struct FSoftObjectPath GlobalAttributeSetDefaultsTableName; // Offset: 0x178 // Size: 0x18
	struct TArray<struct FSoftObjectPath> GlobalAttributeSetDefaultsTableNames; // Offset: 0x190 // Size: 0x10
	struct TArray<struct UCurveTable*> GlobalAttributeDefaultsTables; // Offset: 0x1a0 // Size: 0x10
	struct FSoftObjectPath GlobalGameplayCueManagerClass; // Offset: 0x1b0 // Size: 0x18
	struct FSoftObjectPath GlobalGameplayCueManagerName; // Offset: 0x1c8 // Size: 0x18
	struct TArray<struct FString> GameplayCueNotifyPaths; // Offset: 0x1e0 // Size: 0x10
	struct FSoftObjectPath GameplayTagResponseTableName; // Offset: 0x1f0 // Size: 0x18
	struct UGameplayTagReponseTable* GameplayTagResponseTable; // Offset: 0x208 // Size: 0x08
	bool PredictTargetGameplayEffects; // Offset: 0x210 // Size: 0x01
	char pad_0x211[0x7]; // Offset: 0x211 // Size: 0x07
	struct UGameplayCueManager* GlobalGameplayCueManager; // Offset: 0x218 // Size: 0x08
	char pad_0x220[0x40]; // Offset: 0x220 // Size: 0x40

	// Functions

	// Object Name: Function GameplayAbilities.AbilitySystemGlobals.ToggleIgnoreAbilitySystemCosts
	// Flags: [Exec|Native|Public]
	void ToggleIgnoreAbilitySystemCosts(); // Offset: 0x100fe4c68 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function GameplayAbilities.AbilitySystemGlobals.ToggleIgnoreAbilitySystemCooldowns
	// Flags: [Exec|Native|Public]
	void ToggleIgnoreAbilitySystemCooldowns(); // Offset: 0x100fe4c84 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class GameplayAbilities.AbilitySystemInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UAbilitySystemInterface : UInterface {
};

// Object Name: Class GameplayAbilities.AbilitySystemReplicationProxyInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UAbilitySystemReplicationProxyInterface : UInterface {
};

// Object Name: Class GameplayAbilities.AttributeSet
// Size: 0x30 // Inherited bytes: 0x28
struct UAttributeSet : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08
};

// Object Name: Class GameplayAbilities.AbilitySystemTestAttributeSet
// Size: 0x70 // Inherited bytes: 0x30
struct UAbilitySystemTestAttributeSet : UAttributeSet {
	// Fields
	float MaxHealth; // Offset: 0x2c // Size: 0x04
	float Health; // Offset: 0x30 // Size: 0x04
	float Mana; // Offset: 0x34 // Size: 0x04
	float MaxMana; // Offset: 0x38 // Size: 0x04
	float Damage; // Offset: 0x3c // Size: 0x04
	float SpellDamage; // Offset: 0x40 // Size: 0x04
	float PhysicalDamage; // Offset: 0x44 // Size: 0x04
	float CritChance; // Offset: 0x48 // Size: 0x04
	float CritMultiplier; // Offset: 0x4c // Size: 0x04
	float ArmorDamageReduction; // Offset: 0x50 // Size: 0x04
	float DodgeChance; // Offset: 0x54 // Size: 0x04
	float LifeSteal; // Offset: 0x58 // Size: 0x04
	float Strength; // Offset: 0x5c // Size: 0x04
	float StackingAttribute1; // Offset: 0x60 // Size: 0x04
	float StackingAttribute2; // Offset: 0x64 // Size: 0x04
	float NoStackAttribute; // Offset: 0x68 // Size: 0x04
};

// Object Name: Class GameplayAbilities.AbilitySystemTestPawn
// Size: 0x2d0 // Inherited bytes: 0x2b0
struct AAbilitySystemTestPawn : ADefaultPawn {
	// Fields
	char pad_0x2B0[0x18]; // Offset: 0x2b0 // Size: 0x18
	struct UAbilitySystemComponent* AbilitySystemComponent; // Offset: 0x2c8 // Size: 0x08
};

// Object Name: Class GameplayAbilities.AbilityTask
// Size: 0x78 // Inherited bytes: 0x60
struct UAbilityTask : UGameplayTask {
	// Fields
	struct UGameplayAbility* Ability; // Offset: 0x60 // Size: 0x08
	struct UAbilitySystemComponent* AbilitySystemComponent; // Offset: 0x68 // Size: 0x08
	char pad_0x70[0x8]; // Offset: 0x70 // Size: 0x08
};

// Object Name: Class GameplayAbilities.AbilityTask_ApplyRootMotion_Base
// Size: 0xa8 // Inherited bytes: 0x78
struct UAbilityTask_ApplyRootMotion_Base : UAbilityTask {
	// Fields
	struct FName ForceName; // Offset: 0x74 // Size: 0x08
	enum class ERootMotionFinishVelocityMode FinishVelocityMode; // Offset: 0x7c // Size: 0x01
	struct FVector FinishSetVelocity; // Offset: 0x80 // Size: 0x0c
	float FinishClampVelocity; // Offset: 0x8c // Size: 0x04
	struct UCharacterMovementComponent* MovementComponent; // Offset: 0x90 // Size: 0x08
	char pad_0x99[0xf]; // Offset: 0x99 // Size: 0x0f
};

// Object Name: Class GameplayAbilities.AbilityTask_ApplyRootMotionConstantForce
// Size: 0xd8 // Inherited bytes: 0xa8
struct UAbilityTask_ApplyRootMotionConstantForce : UAbilityTask_ApplyRootMotion_Base {
	// Fields
	struct FMulticastInlineDelegate OnFinish; // Offset: 0xa8 // Size: 0x10
	struct FVector WorldDirection; // Offset: 0xb8 // Size: 0x0c
	float Strength; // Offset: 0xc4 // Size: 0x04
	float Duration; // Offset: 0xc8 // Size: 0x04
	bool bIsAdditive; // Offset: 0xcc // Size: 0x01
	char pad_0xCD[0x3]; // Offset: 0xcd // Size: 0x03
	struct UCurveFloat* StrengthOverTime; // Offset: 0xd0 // Size: 0x08

	// Functions

	// Object Name: Function GameplayAbilities.AbilityTask_ApplyRootMotionConstantForce.ApplyRootMotionConstantForce
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	struct UAbilityTask_ApplyRootMotionConstantForce* ApplyRootMotionConstantForce(struct UGameplayAbility* OwningAbility, struct FName TaskInstanceName, struct FVector WorldDirection, float Strength, float Duration, bool bIsAdditive, struct UCurveFloat* StrengthOverTime, enum class ERootMotionFinishVelocityMode VelocityOnFinishMode, struct FVector SetVelocityOnFinish, float ClampVelocityOnFinish); // Offset: 0x100fe613c // Return & Params: Num(11) Size(0x50)
};

// Object Name: Class GameplayAbilities.AbilityTask_ApplyRootMotionJumpForce
// Size: 0x100 // Inherited bytes: 0xa8
struct UAbilityTask_ApplyRootMotionJumpForce : UAbilityTask_ApplyRootMotion_Base {
	// Fields
	struct FMulticastInlineDelegate OnFinish; // Offset: 0xa8 // Size: 0x10
	struct FMulticastInlineDelegate OnLanded; // Offset: 0xb8 // Size: 0x10
	struct FRotator Rotation; // Offset: 0xc8 // Size: 0x0c
	float Distance; // Offset: 0xd4 // Size: 0x04
	float Height; // Offset: 0xd8 // Size: 0x04
	float Duration; // Offset: 0xdc // Size: 0x04
	float MinimumLandedTriggerTime; // Offset: 0xe0 // Size: 0x04
	bool bFinishOnLanded; // Offset: 0xe4 // Size: 0x01
	char pad_0xE5[0x3]; // Offset: 0xe5 // Size: 0x03
	struct UCurveVector* PathOffsetCurve; // Offset: 0xe8 // Size: 0x08
	struct UCurveFloat* TimeMappingCurve; // Offset: 0xf0 // Size: 0x08
	char pad_0xF8[0x8]; // Offset: 0xf8 // Size: 0x08

	// Functions

	// Object Name: Function GameplayAbilities.AbilityTask_ApplyRootMotionJumpForce.OnLandedCallback
	// Flags: [Final|Native|Public|HasOutParms]
	void OnLandedCallback(struct FHitResult& Hit); // Offset: 0x100fe6df8 // Return & Params: Num(1) Size(0x88)

	// Object Name: Function GameplayAbilities.AbilityTask_ApplyRootMotionJumpForce.Finish
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Finish(); // Offset: 0x100fe6ea0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function GameplayAbilities.AbilityTask_ApplyRootMotionJumpForce.ApplyRootMotionJumpForce
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	struct UAbilityTask_ApplyRootMotionJumpForce* ApplyRootMotionJumpForce(struct UGameplayAbility* OwningAbility, struct FName TaskInstanceName, struct FRotator Rotation, float Distance, float Height, float Duration, float MinimumLandedTriggerTime, bool bFinishOnLanded, enum class ERootMotionFinishVelocityMode VelocityOnFinishMode, struct FVector SetVelocityOnFinish, float ClampVelocityOnFinish, struct UCurveVector* PathOffsetCurve, struct UCurveFloat* TimeMappingCurve); // Offset: 0x100fe69e0 // Return & Params: Num(14) Size(0x58)
};

// Object Name: Class GameplayAbilities.AbilityTask_ApplyRootMotionMoveToActorForce
// Size: 0x120 // Inherited bytes: 0xa8
struct UAbilityTask_ApplyRootMotionMoveToActorForce : UAbilityTask_ApplyRootMotion_Base {
	// Fields
	struct FMulticastInlineDelegate OnFinished; // Offset: 0xa8 // Size: 0x10
	char pad_0xB8[0x8]; // Offset: 0xb8 // Size: 0x08
	struct FVector StartLocation; // Offset: 0xc0 // Size: 0x0c
	struct FVector TargetLocation; // Offset: 0xcc // Size: 0x0c
	struct AActor* TargetActor; // Offset: 0xd8 // Size: 0x08
	struct FVector TargetLocationOffset; // Offset: 0xe0 // Size: 0x0c
	enum class ERootMotionMoveToActorTargetOffsetType OffsetAlignment; // Offset: 0xec // Size: 0x01
	char pad_0xED[0x3]; // Offset: 0xed // Size: 0x03
	float Duration; // Offset: 0xf0 // Size: 0x04
	bool bDisableDestinationReachedInterrupt; // Offset: 0xf4 // Size: 0x01
	bool bSetNewMovementMode; // Offset: 0xf5 // Size: 0x01
	enum class EMovementMode NewMovementMode; // Offset: 0xf6 // Size: 0x01
	bool bRestrictSpeedToExpected; // Offset: 0xf7 // Size: 0x01
	struct UCurveVector* PathOffsetCurve; // Offset: 0xf8 // Size: 0x08
	struct UCurveFloat* TimeMappingCurve; // Offset: 0x100 // Size: 0x08
	struct UCurveFloat* TargetLerpSpeedHorizontalCurve; // Offset: 0x108 // Size: 0x08
	struct UCurveFloat* TargetLerpSpeedVerticalCurve; // Offset: 0x110 // Size: 0x08
	char pad_0x118[0x8]; // Offset: 0x118 // Size: 0x08

	// Functions

	// Object Name: Function GameplayAbilities.AbilityTask_ApplyRootMotionMoveToActorForce.OnTargetActorSwapped
	// Flags: [Final|Native|Public]
	void OnTargetActorSwapped(struct AActor* OriginalTarget, struct AActor* NewTarget); // Offset: 0x100fe7650 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function GameplayAbilities.AbilityTask_ApplyRootMotionMoveToActorForce.OnRep_TargetLocation
	// Flags: [Final|Native|Protected]
	void OnRep_TargetLocation(); // Offset: 0x100fe763c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function GameplayAbilities.AbilityTask_ApplyRootMotionMoveToActorForce.ApplyRootMotionMoveToTargetDataActorForce
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	struct UAbilityTask_ApplyRootMotionMoveToActorForce* ApplyRootMotionMoveToTargetDataActorForce(struct UGameplayAbility* OwningAbility, struct FName TaskInstanceName, struct FGameplayAbilityTargetDataHandle TargetDataHandle, int32_t TargetDataIndex, int32_t TargetActorIndex, struct FVector TargetLocationOffset, enum class ERootMotionMoveToActorTargetOffsetType OffsetAlignment, float Duration, struct UCurveFloat* TargetLerpSpeedHorizontal, struct UCurveFloat* TargetLerpSpeedVertical, bool bSetNewMovementMode, enum class EMovementMode MovementMode, bool bRestrictSpeedToExpected, struct UCurveVector* PathOffsetCurve, struct UCurveFloat* TimeMappingCurve, enum class ERootMotionFinishVelocityMode VelocityOnFinishMode, struct FVector SetVelocityOnFinish, float ClampVelocityOnFinish, bool bDisableDestinationReachedInterrupt); // Offset: 0x100fe7718 // Return & Params: Num(20) Size(0xa0)

	// Object Name: Function GameplayAbilities.AbilityTask_ApplyRootMotionMoveToActorForce.ApplyRootMotionMoveToActorForce
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	struct UAbilityTask_ApplyRootMotionMoveToActorForce* ApplyRootMotionMoveToActorForce(struct UGameplayAbility* OwningAbility, struct FName TaskInstanceName, struct AActor* TargetActor, struct FVector TargetLocationOffset, enum class ERootMotionMoveToActorTargetOffsetType OffsetAlignment, float Duration, struct UCurveFloat* TargetLerpSpeedHorizontal, struct UCurveFloat* TargetLerpSpeedVertical, bool bSetNewMovementMode, enum class EMovementMode MovementMode, bool bRestrictSpeedToExpected, struct UCurveVector* PathOffsetCurve, struct UCurveFloat* TimeMappingCurve, enum class ERootMotionFinishVelocityMode VelocityOnFinishMode, struct FVector SetVelocityOnFinish, float ClampVelocityOnFinish, bool bDisableDestinationReachedInterrupt); // Offset: 0x100fe7f00 // Return & Params: Num(18) Size(0x78)
};

// Object Name: Class GameplayAbilities.AbilityTask_ApplyRootMotionMoveToForce
// Size: 0xf8 // Inherited bytes: 0xa8
struct UAbilityTask_ApplyRootMotionMoveToForce : UAbilityTask_ApplyRootMotion_Base {
	// Fields
	struct FMulticastInlineDelegate OnTimedOut; // Offset: 0xa8 // Size: 0x10
	struct FMulticastInlineDelegate OnTimedOutAndDestinationReached; // Offset: 0xb8 // Size: 0x10
	struct FVector StartLocation; // Offset: 0xc8 // Size: 0x0c
	struct FVector TargetLocation; // Offset: 0xd4 // Size: 0x0c
	float Duration; // Offset: 0xe0 // Size: 0x04
	bool bSetNewMovementMode; // Offset: 0xe4 // Size: 0x01
	enum class EMovementMode NewMovementMode; // Offset: 0xe5 // Size: 0x01
	bool bRestrictSpeedToExpected; // Offset: 0xe6 // Size: 0x01
	char pad_0xE7[0x1]; // Offset: 0xe7 // Size: 0x01
	struct UCurveVector* PathOffsetCurve; // Offset: 0xe8 // Size: 0x08
	char pad_0xF0[0x8]; // Offset: 0xf0 // Size: 0x08

	// Functions

	// Object Name: Function GameplayAbilities.AbilityTask_ApplyRootMotionMoveToForce.ApplyRootMotionMoveToForce
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	struct UAbilityTask_ApplyRootMotionMoveToForce* ApplyRootMotionMoveToForce(struct UGameplayAbility* OwningAbility, struct FName TaskInstanceName, struct FVector TargetLocation, float Duration, bool bSetNewMovementMode, enum class EMovementMode MovementMode, bool bRestrictSpeedToExpected, struct UCurveVector* PathOffsetCurve, enum class ERootMotionFinishVelocityMode VelocityOnFinishMode, struct FVector SetVelocityOnFinish, float ClampVelocityOnFinish); // Offset: 0x100fe8d74 // Return & Params: Num(12) Size(0x50)
};

// Object Name: Class GameplayAbilities.AbilityTask_ApplyRootMotionRadialForce
// Size: 0x100 // Inherited bytes: 0xa8
struct UAbilityTask_ApplyRootMotionRadialForce : UAbilityTask_ApplyRootMotion_Base {
	// Fields
	struct FMulticastInlineDelegate OnFinish; // Offset: 0xa8 // Size: 0x10
	struct FVector Location; // Offset: 0xb8 // Size: 0x0c
	char pad_0xC4[0x4]; // Offset: 0xc4 // Size: 0x04
	struct AActor* LocationActor; // Offset: 0xc8 // Size: 0x08
	float Strength; // Offset: 0xd0 // Size: 0x04
	float Duration; // Offset: 0xd4 // Size: 0x04
	float Radius; // Offset: 0xd8 // Size: 0x04
	bool bIsPush; // Offset: 0xdc // Size: 0x01
	bool bIsAdditive; // Offset: 0xdd // Size: 0x01
	bool bNoZForce; // Offset: 0xde // Size: 0x01
	char pad_0xDF[0x1]; // Offset: 0xdf // Size: 0x01
	struct UCurveFloat* StrengthDistanceFalloff; // Offset: 0xe0 // Size: 0x08
	struct UCurveFloat* StrengthOverTime; // Offset: 0xe8 // Size: 0x08
	bool bUseFixedWorldDirection; // Offset: 0xf0 // Size: 0x01
	char pad_0xF1[0x3]; // Offset: 0xf1 // Size: 0x03
	struct FRotator FixedWorldDirection; // Offset: 0xf4 // Size: 0x0c

	// Functions

	// Object Name: Function GameplayAbilities.AbilityTask_ApplyRootMotionRadialForce.ApplyRootMotionRadialForce
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	struct UAbilityTask_ApplyRootMotionRadialForce* ApplyRootMotionRadialForce(struct UGameplayAbility* OwningAbility, struct FName TaskInstanceName, struct FVector Location, struct AActor* LocationActor, float Strength, float Duration, float Radius, bool bIsPush, bool bIsAdditive, bool bNoZForce, struct UCurveFloat* StrengthDistanceFalloff, struct UCurveFloat* StrengthOverTime, bool bUseFixedWorldDirection, struct FRotator FixedWorldDirection, enum class ERootMotionFinishVelocityMode VelocityOnFinishMode, struct FVector SetVelocityOnFinish, float ClampVelocityOnFinish); // Offset: 0x100fe9710 // Return & Params: Num(18) Size(0x78)
};

// Object Name: Class GameplayAbilities.AbilityTask_MoveToLocation
// Size: 0xc0 // Inherited bytes: 0x78
struct UAbilityTask_MoveToLocation : UAbilityTask {
	// Fields
	struct FMulticastInlineDelegate OnTargetLocationReached; // Offset: 0x78 // Size: 0x10
	char pad_0x88[0x4]; // Offset: 0x88 // Size: 0x04
	struct FVector StartLocation; // Offset: 0x8c // Size: 0x0c
	struct FVector TargetLocation; // Offset: 0x98 // Size: 0x0c
	float DurationOfMovement; // Offset: 0xa4 // Size: 0x04
	char pad_0xA8[0x8]; // Offset: 0xa8 // Size: 0x08
	struct UCurveFloat* LerpCurve; // Offset: 0xb0 // Size: 0x08
	struct UCurveVector* LerpCurveVector; // Offset: 0xb8 // Size: 0x08

	// Functions

	// Object Name: Function GameplayAbilities.AbilityTask_MoveToLocation.MoveToLocation
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	struct UAbilityTask_MoveToLocation* MoveToLocation(struct UGameplayAbility* OwningAbility, struct FName TaskInstanceName, struct FVector Location, float Duration, struct UCurveFloat* OptionalInterpolationCurve, struct UCurveVector* OptionalVectorInterpolationCurve); // Offset: 0x100fea424 // Return & Params: Num(7) Size(0x38)
};

// Object Name: Class GameplayAbilities.AbilityTask_NetworkSyncPoint
// Size: 0x90 // Inherited bytes: 0x78
struct UAbilityTask_NetworkSyncPoint : UAbilityTask {
	// Fields
	struct FMulticastInlineDelegate OnSync; // Offset: 0x78 // Size: 0x10
	char pad_0x88[0x8]; // Offset: 0x88 // Size: 0x08

	// Functions

	// Object Name: Function GameplayAbilities.AbilityTask_NetworkSyncPoint.WaitNetSync
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UAbilityTask_NetworkSyncPoint* WaitNetSync(struct UGameplayAbility* OwningAbility, enum class EAbilityTaskNetSyncType SyncType); // Offset: 0x100fec29c // Return & Params: Num(3) Size(0x18)

	// Object Name: Function GameplayAbilities.AbilityTask_NetworkSyncPoint.OnSignalCallback
	// Flags: [Final|Native|Public]
	void OnSignalCallback(); // Offset: 0x100fec368 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class GameplayAbilities.AbilityTask_PlayMontageAndWait
// Size: 0x100 // Inherited bytes: 0x78
struct UAbilityTask_PlayMontageAndWait : UAbilityTask {
	// Fields
	struct FMulticastInlineDelegate OnCompleted; // Offset: 0x78 // Size: 0x10
	struct FMulticastInlineDelegate OnBlendOut; // Offset: 0x88 // Size: 0x10
	struct FMulticastInlineDelegate OnInterrupted; // Offset: 0x98 // Size: 0x10
	struct FMulticastInlineDelegate OnCancelled; // Offset: 0xa8 // Size: 0x10
	char pad_0xB8[0x28]; // Offset: 0xb8 // Size: 0x28
	struct UAnimMontage* MontageToPlay; // Offset: 0xe0 // Size: 0x08
	float Rate; // Offset: 0xe8 // Size: 0x04
	struct FName StartSection; // Offset: 0xec // Size: 0x08
	float AnimRootMotionTranslationScale; // Offset: 0xf4 // Size: 0x04
	bool bStopWhenAbilityEnds; // Offset: 0xf8 // Size: 0x01
	bool bInterruptedCalledBeforeBlendingOut; // Offset: 0xf9 // Size: 0x01
	char pad_0xFA[0x6]; // Offset: 0xfa // Size: 0x06

	// Functions

	// Object Name: Function GameplayAbilities.AbilityTask_PlayMontageAndWait.OnMontageInterrupted
	// Flags: [Final|Native|Public]
	void OnMontageInterrupted(); // Offset: 0x100fecae8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function GameplayAbilities.AbilityTask_PlayMontageAndWait.OnMontageEnded
	// Flags: [Final|Native|Public]
	void OnMontageEnded(struct UAnimMontage* Montage, bool bInterrupted); // Offset: 0x100feca14 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function GameplayAbilities.AbilityTask_PlayMontageAndWait.OnMontageBlendingOut
	// Flags: [Final|Native|Public]
	void OnMontageBlendingOut(struct UAnimMontage* Montage, bool bInterrupted); // Offset: 0x100fecafc // Return & Params: Num(2) Size(0x9)

	// Object Name: Function GameplayAbilities.AbilityTask_PlayMontageAndWait.CreatePlayMontageAndWaitProxy
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UAbilityTask_PlayMontageAndWait* CreatePlayMontageAndWaitProxy(struct UGameplayAbility* OwningAbility, struct FName TaskInstanceName, struct UAnimMontage* MontageToPlay, float Rate, struct FName StartSection, bool bStopWhenAbilityEnds, float AnimRootMotionTranslationScale); // Offset: 0x100fec7bc // Return & Params: Num(8) Size(0x38)
};

// Object Name: Class GameplayAbilities.AbilityTask_Repeat
// Size: 0xb0 // Inherited bytes: 0x78
struct UAbilityTask_Repeat : UAbilityTask {
	// Fields
	struct FMulticastInlineDelegate OnPerformAction; // Offset: 0x78 // Size: 0x10
	struct FMulticastInlineDelegate OnFinished; // Offset: 0x88 // Size: 0x10
	char pad_0x98[0x18]; // Offset: 0x98 // Size: 0x18

	// Functions

	// Object Name: Function GameplayAbilities.AbilityTask_Repeat.RepeatAction
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UAbilityTask_Repeat* RepeatAction(struct UGameplayAbility* OwningAbility, float TimeBetweenActions, int32_t TotalActionCount); // Offset: 0x100fed0e4 // Return & Params: Num(4) Size(0x18)
};

// Object Name: Class GameplayAbilities.AbilityTask_SpawnActor
// Size: 0xc0 // Inherited bytes: 0x78
struct UAbilityTask_SpawnActor : UAbilityTask {
	// Fields
	struct FMulticastInlineDelegate Success; // Offset: 0x78 // Size: 0x10
	struct FMulticastInlineDelegate DidNotSpawn; // Offset: 0x88 // Size: 0x10
	char pad_0x98[0x28]; // Offset: 0x98 // Size: 0x28

	// Functions

	// Object Name: Function GameplayAbilities.AbilityTask_SpawnActor.SpawnActor
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UAbilityTask_SpawnActor* SpawnActor(struct UGameplayAbility* OwningAbility, struct FGameplayAbilityTargetDataHandle TargetData, struct AActor* Class); // Offset: 0x100fedc3c // Return & Params: Num(4) Size(0x40)

	// Object Name: Function GameplayAbilities.AbilityTask_SpawnActor.FinishSpawningActor
	// Flags: [Final|Native|Public|BlueprintCallable]
	void FinishSpawningActor(struct UGameplayAbility* OwningAbility, struct FGameplayAbilityTargetDataHandle TargetData, struct AActor* SpawnedActor); // Offset: 0x100fed5f0 // Return & Params: Num(3) Size(0x38)

	// Object Name: Function GameplayAbilities.AbilityTask_SpawnActor.BeginSpawningActor
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	bool BeginSpawningActor(struct UGameplayAbility* OwningAbility, struct FGameplayAbilityTargetDataHandle TargetData, struct AActor* Class, struct AActor*& SpawnedActor); // Offset: 0x100fed8e0 // Return & Params: Num(5) Size(0x41)
};

// Object Name: Class GameplayAbilities.AbilityTask_StartAbilityState
// Size: 0xb0 // Inherited bytes: 0x78
struct UAbilityTask_StartAbilityState : UAbilityTask {
	// Fields
	struct FMulticastInlineDelegate OnStateEnded; // Offset: 0x78 // Size: 0x10
	struct FMulticastInlineDelegate OnStateInterrupted; // Offset: 0x88 // Size: 0x10
	char pad_0x98[0x18]; // Offset: 0x98 // Size: 0x18

	// Functions

	// Object Name: Function GameplayAbilities.AbilityTask_StartAbilityState.StartAbilityState
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UAbilityTask_StartAbilityState* StartAbilityState(struct UGameplayAbility* OwningAbility, struct FName StateName, bool bEndCurrentState); // Offset: 0x100fee3c4 // Return & Params: Num(4) Size(0x20)
};

// Object Name: Class GameplayAbilities.AbilityTask_VisualizeTargeting
// Size: 0xa0 // Inherited bytes: 0x78
struct UAbilityTask_VisualizeTargeting : UAbilityTask {
	// Fields
	struct FMulticastInlineDelegate TimeElapsed; // Offset: 0x78 // Size: 0x10
	char pad_0x88[0x18]; // Offset: 0x88 // Size: 0x18

	// Functions

	// Object Name: Function GameplayAbilities.AbilityTask_VisualizeTargeting.VisualizeTargetingUsingActor
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UAbilityTask_VisualizeTargeting* VisualizeTargetingUsingActor(struct UGameplayAbility* OwningAbility, struct AGameplayAbilityTargetActor* TargetActor, struct FName TaskInstanceName, float Duration); // Offset: 0x100feead8 // Return & Params: Num(5) Size(0x28)

	// Object Name: Function GameplayAbilities.AbilityTask_VisualizeTargeting.VisualizeTargeting
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UAbilityTask_VisualizeTargeting* VisualizeTargeting(struct UGameplayAbility* OwningAbility, struct AGameplayAbilityTargetActor* Class, struct FName TaskInstanceName, float Duration); // Offset: 0x100feec38 // Return & Params: Num(5) Size(0x28)

	// Object Name: Function GameplayAbilities.AbilityTask_VisualizeTargeting.FinishSpawningActor
	// Flags: [Final|Native|Public|BlueprintCallable]
	void FinishSpawningActor(struct UGameplayAbility* OwningAbility, struct AGameplayAbilityTargetActor* SpawnedActor); // Offset: 0x100fee8e0 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function GameplayAbilities.AbilityTask_VisualizeTargeting.BeginSpawningActor
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	bool BeginSpawningActor(struct UGameplayAbility* OwningAbility, struct AGameplayAbilityTargetActor* Class, struct AGameplayAbilityTargetActor*& SpawnedActor); // Offset: 0x100fee9a8 // Return & Params: Num(4) Size(0x19)
};

// Object Name: Class GameplayAbilities.AbilityTask_WaitAbilityActivate
// Size: 0x140 // Inherited bytes: 0x78
struct UAbilityTask_WaitAbilityActivate : UAbilityTask {
	// Fields
	struct FMulticastInlineDelegate OnActivate; // Offset: 0x78 // Size: 0x10
	char pad_0x88[0xb8]; // Offset: 0x88 // Size: 0xb8

	// Functions

	// Object Name: Function GameplayAbilities.AbilityTask_WaitAbilityActivate.WaitForAbilityActivateWithTagRequirements
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UAbilityTask_WaitAbilityActivate* WaitForAbilityActivateWithTagRequirements(struct UGameplayAbility* OwningAbility, struct FGameplayTagRequirements TagRequirements, bool IncludeTriggeredAbilities, bool TriggerOnce); // Offset: 0x100fef47c // Return & Params: Num(5) Size(0x68)

	// Object Name: Function GameplayAbilities.AbilityTask_WaitAbilityActivate.WaitForAbilityActivate_Query
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UAbilityTask_WaitAbilityActivate* WaitForAbilityActivate_Query(struct UGameplayAbility* OwningAbility, struct FGameplayTagQuery Query, bool IncludeTriggeredAbilities, bool TriggerOnce); // Offset: 0x100fef27c // Return & Params: Num(5) Size(0x60)

	// Object Name: Function GameplayAbilities.AbilityTask_WaitAbilityActivate.WaitForAbilityActivate
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UAbilityTask_WaitAbilityActivate* WaitForAbilityActivate(struct UGameplayAbility* OwningAbility, struct FGameplayTag WithTag, struct FGameplayTag WithoutTag, bool IncludeTriggeredAbilities, bool TriggerOnce); // Offset: 0x100fef6d8 // Return & Params: Num(6) Size(0x28)

	// Object Name: Function GameplayAbilities.AbilityTask_WaitAbilityActivate.OnAbilityActivate
	// Flags: [Final|Native|Public]
	void OnAbilityActivate(struct UGameplayAbility* ActivatedAbility); // Offset: 0x100fef8a0 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class GameplayAbilities.AbilityTask_WaitAbilityCommit
// Size: 0xf0 // Inherited bytes: 0x78
struct UAbilityTask_WaitAbilityCommit : UAbilityTask {
	// Fields
	struct FMulticastInlineDelegate OnCommit; // Offset: 0x78 // Size: 0x10
	char pad_0x88[0x68]; // Offset: 0x88 // Size: 0x68

	// Functions

	// Object Name: Function GameplayAbilities.AbilityTask_WaitAbilityCommit.WaitForAbilityCommit_Query
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UAbilityTask_WaitAbilityCommit* WaitForAbilityCommit_Query(struct UGameplayAbility* OwningAbility, struct FGameplayTagQuery Query, bool TriggerOnce); // Offset: 0x100fefe40 // Return & Params: Num(4) Size(0x60)

	// Object Name: Function GameplayAbilities.AbilityTask_WaitAbilityCommit.WaitForAbilityCommit
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UAbilityTask_WaitAbilityCommit* WaitForAbilityCommit(struct UGameplayAbility* OwningAbility, struct FGameplayTag WithTag, struct FGameplayTag WithoutTage, bool TriggerOnce); // Offset: 0x100feffe4 // Return & Params: Num(5) Size(0x28)

	// Object Name: Function GameplayAbilities.AbilityTask_WaitAbilityCommit.OnAbilityCommit
	// Flags: [Final|Native|Public]
	void OnAbilityCommit(struct UGameplayAbility* ActivatedAbility); // Offset: 0x100ff014c // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class GameplayAbilities.AbilityTask_WaitAttributeChange
// Size: 0xf0 // Inherited bytes: 0x78
struct UAbilityTask_WaitAttributeChange : UAbilityTask {
	// Fields
	struct FMulticastInlineDelegate OnChange; // Offset: 0x78 // Size: 0x10
	char pad_0x88[0x60]; // Offset: 0x88 // Size: 0x60
	struct UAbilitySystemComponent* ExternalOwner; // Offset: 0xe8 // Size: 0x08

	// Functions

	// Object Name: Function GameplayAbilities.AbilityTask_WaitAttributeChange.WaitForAttributeChangeWithComparison
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UAbilityTask_WaitAttributeChange* WaitForAttributeChangeWithComparison(struct UGameplayAbility* OwningAbility, struct FGameplayAttribute InAttribute, struct FGameplayTag InWithTag, struct FGameplayTag InWithoutTag, enum class EWaitAttributeChangeComparison InComparisonType, float InComparisonValue, bool TriggerOnce, struct AActor* OptionalExternalOwner); // Offset: 0x100ff070c // Return & Params: Num(9) Size(0x70)

	// Object Name: Function GameplayAbilities.AbilityTask_WaitAttributeChange.WaitForAttributeChange
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UAbilityTask_WaitAttributeChange* WaitForAttributeChange(struct UGameplayAbility* OwningAbility, struct FGameplayAttribute Attribute, struct FGameplayTag WithSrcTag, struct FGameplayTag WithoutSrcTag, bool TriggerOnce, struct AActor* OptionalExternalOwner); // Offset: 0x100ff0a08 // Return & Params: Num(7) Size(0x68)
};

// Object Name: Class GameplayAbilities.AbilityTask_WaitAttributeChangeRatioThreshold
// Size: 0x138 // Inherited bytes: 0x78
struct UAbilityTask_WaitAttributeChangeRatioThreshold : UAbilityTask {
	// Fields
	struct FMulticastInlineDelegate OnChange; // Offset: 0x78 // Size: 0x10
	char pad_0x88[0xa8]; // Offset: 0x88 // Size: 0xa8
	struct UAbilitySystemComponent* ExternalOwner; // Offset: 0x130 // Size: 0x08

	// Functions

	// Object Name: Function GameplayAbilities.AbilityTask_WaitAttributeChangeRatioThreshold.WaitForAttributeChangeRatioThreshold
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UAbilityTask_WaitAttributeChangeRatioThreshold* WaitForAttributeChangeRatioThreshold(struct UGameplayAbility* OwningAbility, struct FGameplayAttribute AttributeNumerator, struct FGameplayAttribute AttributeDenominator, enum class EWaitAttributeChangeComparison ComparisonType, float ComparisonValue, bool bTriggerOnce, struct AActor* OptionalExternalOwner); // Offset: 0x100ff10cc // Return & Params: Num(8) Size(0x98)
};

// Object Name: Class GameplayAbilities.AbilityTask_WaitAttributeChangeThreshold
// Size: 0xe8 // Inherited bytes: 0x78
struct UAbilityTask_WaitAttributeChangeThreshold : UAbilityTask {
	// Fields
	struct FMulticastInlineDelegate OnChange; // Offset: 0x78 // Size: 0x10
	char pad_0x88[0x58]; // Offset: 0x88 // Size: 0x58
	struct UAbilitySystemComponent* ExternalOwner; // Offset: 0xe0 // Size: 0x08

	// Functions

	// Object Name: Function GameplayAbilities.AbilityTask_WaitAttributeChangeThreshold.WaitForAttributeChangeThreshold
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UAbilityTask_WaitAttributeChangeThreshold* WaitForAttributeChangeThreshold(struct UGameplayAbility* OwningAbility, struct FGameplayAttribute Attribute, enum class EWaitAttributeChangeComparison ComparisonType, float ComparisonValue, bool bTriggerOnce, struct AActor* OptionalExternalOwner); // Offset: 0x100ff17d8 // Return & Params: Num(7) Size(0x60)
};

// Object Name: Class GameplayAbilities.AbilityTask_WaitCancel
// Size: 0x90 // Inherited bytes: 0x78
struct UAbilityTask_WaitCancel : UAbilityTask {
	// Fields
	struct FMulticastInlineDelegate OnCancel; // Offset: 0x78 // Size: 0x10
	char pad_0x88[0x8]; // Offset: 0x88 // Size: 0x08

	// Functions

	// Object Name: Function GameplayAbilities.AbilityTask_WaitCancel.WaitCancel
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UAbilityTask_WaitCancel* WaitCancel(struct UGameplayAbility* OwningAbility); // Offset: 0x100ff1e3c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function GameplayAbilities.AbilityTask_WaitCancel.OnLocalCancelCallback
	// Flags: [Final|Native|Public]
	void OnLocalCancelCallback(); // Offset: 0x100ff1ebc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function GameplayAbilities.AbilityTask_WaitCancel.OnCancelCallback
	// Flags: [Final|Native|Public]
	void OnCancelCallback(); // Offset: 0x100ff1ed0 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class GameplayAbilities.AbilityTask_WaitConfirm
// Size: 0x98 // Inherited bytes: 0x78
struct UAbilityTask_WaitConfirm : UAbilityTask {
	// Fields
	struct FMulticastInlineDelegate OnConfirm; // Offset: 0x78 // Size: 0x10
	char pad_0x88[0x10]; // Offset: 0x88 // Size: 0x10

	// Functions

	// Object Name: Function GameplayAbilities.AbilityTask_WaitConfirm.WaitConfirm
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UAbilityTask_WaitConfirm* WaitConfirm(struct UGameplayAbility* OwningAbility); // Offset: 0x100ff2324 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function GameplayAbilities.AbilityTask_WaitConfirm.OnConfirmCallback
	// Flags: [Final|Native|Public]
	void OnConfirmCallback(struct UGameplayAbility* InAbility); // Offset: 0x100ff23a4 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class GameplayAbilities.AbilityTask_WaitConfirmCancel
// Size: 0xa0 // Inherited bytes: 0x78
struct UAbilityTask_WaitConfirmCancel : UAbilityTask {
	// Fields
	struct FMulticastInlineDelegate OnConfirm; // Offset: 0x78 // Size: 0x10
	struct FMulticastInlineDelegate OnCancel; // Offset: 0x88 // Size: 0x10
	char pad_0x98[0x8]; // Offset: 0x98 // Size: 0x08

	// Functions

	// Object Name: Function GameplayAbilities.AbilityTask_WaitConfirmCancel.WaitConfirmCancel
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UAbilityTask_WaitConfirmCancel* WaitConfirmCancel(struct UGameplayAbility* OwningAbility); // Offset: 0x100ff2864 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function GameplayAbilities.AbilityTask_WaitConfirmCancel.OnLocalConfirmCallback
	// Flags: [Final|Native|Public]
	void OnLocalConfirmCallback(); // Offset: 0x100ff28f8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function GameplayAbilities.AbilityTask_WaitConfirmCancel.OnLocalCancelCallback
	// Flags: [Final|Native|Public]
	void OnLocalCancelCallback(); // Offset: 0x100ff28e4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function GameplayAbilities.AbilityTask_WaitConfirmCancel.OnConfirmCallback
	// Flags: [Final|Native|Public]
	void OnConfirmCallback(); // Offset: 0x100ff2920 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function GameplayAbilities.AbilityTask_WaitConfirmCancel.OnCancelCallback
	// Flags: [Final|Native|Public]
	void OnCancelCallback(); // Offset: 0x100ff290c // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class GameplayAbilities.AbilityTask_WaitDelay
// Size: 0x98 // Inherited bytes: 0x78
struct UAbilityTask_WaitDelay : UAbilityTask {
	// Fields
	struct FMulticastInlineDelegate OnFinish; // Offset: 0x78 // Size: 0x10
	char pad_0x88[0x10]; // Offset: 0x88 // Size: 0x10

	// Functions

	// Object Name: Function GameplayAbilities.AbilityTask_WaitDelay.WaitDelay
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UAbilityTask_WaitDelay* WaitDelay(struct UGameplayAbility* OwningAbility, float Time); // Offset: 0x100ff2e58 // Return & Params: Num(3) Size(0x18)
};

// Object Name: Class GameplayAbilities.AbilityTask_WaitGameplayEffectApplied
// Size: 0x1d0 // Inherited bytes: 0x78
struct UAbilityTask_WaitGameplayEffectApplied : UAbilityTask {
	// Fields
	char pad_0x78[0x148]; // Offset: 0x78 // Size: 0x148
	struct UAbilitySystemComponent* ExternalOwner; // Offset: 0x1c0 // Size: 0x08
	char pad_0x1C8[0x8]; // Offset: 0x1c8 // Size: 0x08

	// Functions

	// Object Name: Function GameplayAbilities.AbilityTask_WaitGameplayEffectApplied.OnApplyGameplayEffectCallback
	// Flags: [Final|Native|Public|HasOutParms]
	void OnApplyGameplayEffectCallback(struct UAbilitySystemComponent* Target, struct FGameplayEffectSpec& SpecApplied, struct FActiveGameplayEffectHandle ActiveHandle); // Offset: 0x100ff32cc // Return & Params: Num(3) Size(0x2a8)
};

// Object Name: Class GameplayAbilities.AbilityTask_WaitGameplayEffectApplied_Self
// Size: 0x1f0 // Inherited bytes: 0x1d0
struct UAbilityTask_WaitGameplayEffectApplied_Self : UAbilityTask_WaitGameplayEffectApplied {
	// Fields
	struct FMulticastInlineDelegate OnApplied; // Offset: 0x1d0 // Size: 0x10
	char pad_0x1E0[0x10]; // Offset: 0x1e0 // Size: 0x10

	// Functions

	// Object Name: Function GameplayAbilities.AbilityTask_WaitGameplayEffectApplied_Self.WaitGameplayEffectAppliedToSelf_Query
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UAbilityTask_WaitGameplayEffectApplied_Self* WaitGameplayEffectAppliedToSelf_Query(struct UGameplayAbility* OwningAbility, struct FGameplayTargetDataFilterHandle SourceFilter, struct FGameplayTagQuery SourceTagQuery, struct FGameplayTagQuery TargetTagQuery, bool TriggerOnce, struct AActor* OptionalExternalOwner, bool ListenForPeriodicEffect); // Offset: 0x100ff3678 // Return & Params: Num(8) Size(0xc8)

	// Object Name: Function GameplayAbilities.AbilityTask_WaitGameplayEffectApplied_Self.WaitGameplayEffectAppliedToSelf
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UAbilityTask_WaitGameplayEffectApplied_Self* WaitGameplayEffectAppliedToSelf(struct UGameplayAbility* OwningAbility, struct FGameplayTargetDataFilterHandle SourceFilter, struct FGameplayTagRequirements SourceTagRequirements, struct FGameplayTagRequirements TargetTagRequirements, bool TriggerOnce, struct AActor* OptionalExternalOwner, bool ListenForPeriodicEffect); // Offset: 0x100ff3aa8 // Return & Params: Num(8) Size(0xd8)
};

// Object Name: Class GameplayAbilities.AbilityTask_WaitGameplayEffectApplied_Target
// Size: 0x1f0 // Inherited bytes: 0x1d0
struct UAbilityTask_WaitGameplayEffectApplied_Target : UAbilityTask_WaitGameplayEffectApplied {
	// Fields
	struct FMulticastInlineDelegate OnApplied; // Offset: 0x1d0 // Size: 0x10
	char pad_0x1E0[0x10]; // Offset: 0x1e0 // Size: 0x10

	// Functions

	// Object Name: Function GameplayAbilities.AbilityTask_WaitGameplayEffectApplied_Target.WaitGameplayEffectAppliedToTarget_Query
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UAbilityTask_WaitGameplayEffectApplied_Target* WaitGameplayEffectAppliedToTarget_Query(struct UGameplayAbility* OwningAbility, struct FGameplayTargetDataFilterHandle SourceFilter, struct FGameplayTagQuery SourceTagQuery, struct FGameplayTagQuery TargetTagQuery, bool TriggerOnce, struct AActor* OptionalExternalOwner, bool ListenForPeriodicEffect); // Offset: 0x100ff5b98 // Return & Params: Num(8) Size(0xc8)

	// Object Name: Function GameplayAbilities.AbilityTask_WaitGameplayEffectApplied_Target.WaitGameplayEffectAppliedToTarget
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UAbilityTask_WaitGameplayEffectApplied_Target* WaitGameplayEffectAppliedToTarget(struct UGameplayAbility* OwningAbility, struct FGameplayTargetDataFilterHandle TargetFilter, struct FGameplayTagRequirements SourceTagRequirements, struct FGameplayTagRequirements TargetTagRequirements, bool TriggerOnce, struct AActor* OptionalExternalOwner, bool ListenForPeriodicEffects); // Offset: 0x100ff5fc8 // Return & Params: Num(8) Size(0xd8)
};

// Object Name: Class GameplayAbilities.AbilityTask_WaitGameplayEffectBlockedImmunity
// Size: 0x140 // Inherited bytes: 0x78
struct UAbilityTask_WaitGameplayEffectBlockedImmunity : UAbilityTask {
	// Fields
	struct FMulticastInlineDelegate bLocked; // Offset: 0x78 // Size: 0x10
	char pad_0x88[0xa8]; // Offset: 0x88 // Size: 0xa8
	struct UAbilitySystemComponent* ExternalOwner; // Offset: 0x130 // Size: 0x08
	char pad_0x138[0x8]; // Offset: 0x138 // Size: 0x08

	// Functions

	// Object Name: Function GameplayAbilities.AbilityTask_WaitGameplayEffectBlockedImmunity.WaitGameplayEffectBlockedByImmunity
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UAbilityTask_WaitGameplayEffectBlockedImmunity* WaitGameplayEffectBlockedByImmunity(struct UGameplayAbility* OwningAbility, struct FGameplayTagRequirements SourceTagRequirements, struct FGameplayTagRequirements TargetTagRequirements, struct AActor* OptionalExternalTarget, bool OnlyTriggerOnce); // Offset: 0x100ff69a0 // Return & Params: Num(6) Size(0xc0)
};

// Object Name: Class GameplayAbilities.AbilityTask_WaitGameplayEffectRemoved
// Size: 0xb8 // Inherited bytes: 0x78
struct UAbilityTask_WaitGameplayEffectRemoved : UAbilityTask {
	// Fields
	struct FMulticastInlineDelegate OnRemoved; // Offset: 0x78 // Size: 0x10
	struct FMulticastInlineDelegate InvalidHandle; // Offset: 0x88 // Size: 0x10
	char pad_0x98[0x20]; // Offset: 0x98 // Size: 0x20

	// Functions

	// Object Name: Function GameplayAbilities.AbilityTask_WaitGameplayEffectRemoved.WaitForGameplayEffectRemoved
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UAbilityTask_WaitGameplayEffectRemoved* WaitForGameplayEffectRemoved(struct UGameplayAbility* OwningAbility, struct FActiveGameplayEffectHandle Handle); // Offset: 0x100ff70f0 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function GameplayAbilities.AbilityTask_WaitGameplayEffectRemoved.OnGameplayEffectRemoved
	// Flags: [Final|Native|Public|HasOutParms]
	void OnGameplayEffectRemoved(struct FGameplayEffectRemovalInfo& InGameplayEffectRemovalInfo); // Offset: 0x100ff71c8 // Return & Params: Num(1) Size(0x20)
};

// Object Name: Class GameplayAbilities.AbilityTask_WaitGameplayEffectStackChange
// Size: 0xb0 // Inherited bytes: 0x78
struct UAbilityTask_WaitGameplayEffectStackChange : UAbilityTask {
	// Fields
	struct FMulticastInlineDelegate OnChange; // Offset: 0x78 // Size: 0x10
	struct FMulticastInlineDelegate InvalidHandle; // Offset: 0x88 // Size: 0x10
	char pad_0x98[0x18]; // Offset: 0x98 // Size: 0x18

	// Functions

	// Object Name: Function GameplayAbilities.AbilityTask_WaitGameplayEffectStackChange.WaitForGameplayEffectStackChange
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UAbilityTask_WaitGameplayEffectStackChange* WaitForGameplayEffectStackChange(struct UGameplayAbility* OwningAbility, struct FActiveGameplayEffectHandle Handle); // Offset: 0x100ff7704 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function GameplayAbilities.AbilityTask_WaitGameplayEffectStackChange.OnGameplayEffectStackChange
	// Flags: [Final|Native|Public]
	void OnGameplayEffectStackChange(struct FActiveGameplayEffectHandle Handle, int32_t NewCount, int32_t OldCount); // Offset: 0x100ff77dc // Return & Params: Num(3) Size(0x10)
};

// Object Name: Class GameplayAbilities.AbilityTask_WaitGameplayEvent
// Size: 0xa8 // Inherited bytes: 0x78
struct UAbilityTask_WaitGameplayEvent : UAbilityTask {
	// Fields
	struct FMulticastInlineDelegate EventReceived; // Offset: 0x78 // Size: 0x10
	char pad_0x88[0x8]; // Offset: 0x88 // Size: 0x08
	struct UAbilitySystemComponent* OptionalExternalTarget; // Offset: 0x90 // Size: 0x08
	char pad_0x98[0x10]; // Offset: 0x98 // Size: 0x10

	// Functions

	// Object Name: Function GameplayAbilities.AbilityTask_WaitGameplayEvent.WaitGameplayEvent
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UAbilityTask_WaitGameplayEvent* WaitGameplayEvent(struct UGameplayAbility* OwningAbility, struct FGameplayTag EventTag, struct AActor* OptionalExternalTarget, bool OnlyTriggerOnce, bool OnlyMatchExact); // Offset: 0x100ff7d38 // Return & Params: Num(6) Size(0x28)
};

// Object Name: Class GameplayAbilities.AbilityTask_WaitGameplayTag
// Size: 0x98 // Inherited bytes: 0x78
struct UAbilityTask_WaitGameplayTag : UAbilityTask {
	// Fields
	char pad_0x78[0x8]; // Offset: 0x78 // Size: 0x08
	struct UAbilitySystemComponent* OptionalExternalTarget; // Offset: 0x80 // Size: 0x08
	char pad_0x88[0x10]; // Offset: 0x88 // Size: 0x10

	// Functions

	// Object Name: Function GameplayAbilities.AbilityTask_WaitGameplayTag.GameplayTagCallback
	// Flags: [Native|Public]
	void GameplayTagCallback(struct FGameplayTag Tag, int32_t NewCount); // Offset: 0x100ff8e50 // Return & Params: Num(2) Size(0xc)
};

// Object Name: Class GameplayAbilities.AbilityTask_WaitGameplayTagAdded
// Size: 0xa8 // Inherited bytes: 0x98
struct UAbilityTask_WaitGameplayTagAdded : UAbilityTask_WaitGameplayTag {
	// Fields
	struct FMulticastInlineDelegate Added; // Offset: 0x98 // Size: 0x10

	// Functions

	// Object Name: Function GameplayAbilities.AbilityTask_WaitGameplayTagAdded.WaitGameplayTagAdd
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UAbilityTask_WaitGameplayTagAdded* WaitGameplayTagAdd(struct UGameplayAbility* OwningAbility, struct FGameplayTag Tag, struct AActor* InOptionalExternalTarget, bool OnlyTriggerOnce); // Offset: 0x100ff830c // Return & Params: Num(5) Size(0x28)
};

// Object Name: Class GameplayAbilities.AbilityTask_WaitGameplayTagRemoved
// Size: 0xa8 // Inherited bytes: 0x98
struct UAbilityTask_WaitGameplayTagRemoved : UAbilityTask_WaitGameplayTag {
	// Fields
	struct FMulticastInlineDelegate Removed; // Offset: 0x98 // Size: 0x10

	// Functions

	// Object Name: Function GameplayAbilities.AbilityTask_WaitGameplayTagRemoved.WaitGameplayTagRemove
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UAbilityTask_WaitGameplayTagRemoved* WaitGameplayTagRemove(struct UGameplayAbility* OwningAbility, struct FGameplayTag Tag, struct AActor* InOptionalExternalTarget, bool OnlyTriggerOnce); // Offset: 0x100ff8934 // Return & Params: Num(5) Size(0x28)
};

// Object Name: Class GameplayAbilities.AbilityTask_WaitInputPress
// Size: 0x98 // Inherited bytes: 0x78
struct UAbilityTask_WaitInputPress : UAbilityTask {
	// Fields
	struct FMulticastInlineDelegate OnPress; // Offset: 0x78 // Size: 0x10
	char pad_0x88[0x10]; // Offset: 0x88 // Size: 0x10

	// Functions

	// Object Name: Function GameplayAbilities.AbilityTask_WaitInputPress.WaitInputPress
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UAbilityTask_WaitInputPress* WaitInputPress(struct UGameplayAbility* OwningAbility, bool bTestAlreadyPressed); // Offset: 0x100ff908c // Return & Params: Num(3) Size(0x18)

	// Object Name: Function GameplayAbilities.AbilityTask_WaitInputPress.OnPressCallback
	// Flags: [Final|Native|Public]
	void OnPressCallback(); // Offset: 0x100ff9160 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class GameplayAbilities.AbilityTask_WaitInputRelease
// Size: 0x98 // Inherited bytes: 0x78
struct UAbilityTask_WaitInputRelease : UAbilityTask {
	// Fields
	struct FMulticastInlineDelegate OnRelease; // Offset: 0x78 // Size: 0x10
	char pad_0x88[0x10]; // Offset: 0x88 // Size: 0x10

	// Functions

	// Object Name: Function GameplayAbilities.AbilityTask_WaitInputRelease.WaitInputRelease
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UAbilityTask_WaitInputRelease* WaitInputRelease(struct UGameplayAbility* OwningAbility, bool bTestAlreadyReleased); // Offset: 0x100ff95c0 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function GameplayAbilities.AbilityTask_WaitInputRelease.OnReleaseCallback
	// Flags: [Final|Native|Public]
	void OnReleaseCallback(); // Offset: 0x100ff9694 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class GameplayAbilities.AbilityTask_WaitMovementModeChange
// Size: 0x98 // Inherited bytes: 0x78
struct UAbilityTask_WaitMovementModeChange : UAbilityTask {
	// Fields
	struct FMulticastInlineDelegate OnChange; // Offset: 0x78 // Size: 0x10
	char pad_0x88[0x10]; // Offset: 0x88 // Size: 0x10

	// Functions

	// Object Name: Function GameplayAbilities.AbilityTask_WaitMovementModeChange.OnMovementModeChange
	// Flags: [Final|Native|Public]
	void OnMovementModeChange(struct ACharacter* Character, enum class EMovementMode PrevMovementMode, char PreviousCustomMode); // Offset: 0x100ff9bc0 // Return & Params: Num(3) Size(0xa)

	// Object Name: Function GameplayAbilities.AbilityTask_WaitMovementModeChange.CreateWaitMovementModeChange
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UAbilityTask_WaitMovementModeChange* CreateWaitMovementModeChange(struct UGameplayAbility* OwningAbility, enum class EMovementMode NewMode); // Offset: 0x100ff9af4 // Return & Params: Num(3) Size(0x18)
};

// Object Name: Class GameplayAbilities.AbilityTask_WaitOverlap
// Size: 0x88 // Inherited bytes: 0x78
struct UAbilityTask_WaitOverlap : UAbilityTask {
	// Fields
	struct FMulticastInlineDelegate OnOverLap; // Offset: 0x78 // Size: 0x10

	// Functions

	// Object Name: Function GameplayAbilities.AbilityTask_WaitOverlap.WaitForOverlap
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UAbilityTask_WaitOverlap* WaitForOverlap(struct UGameplayAbility* OwningAbility); // Offset: 0x100ffa118 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function GameplayAbilities.AbilityTask_WaitOverlap.OnHitCallback
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults]
	void OnHitCallback(struct UPrimitiveComponent* HitComp, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult& Hit); // Offset: 0x100ffa198 // Return & Params: Num(5) Size(0xac)
};

// Object Name: Class GameplayAbilities.AbilityTask_WaitTargetData
// Size: 0xb8 // Inherited bytes: 0x78
struct UAbilityTask_WaitTargetData : UAbilityTask {
	// Fields
	struct FMulticastInlineDelegate ValidData; // Offset: 0x78 // Size: 0x10
	struct FMulticastInlineDelegate Cancelled; // Offset: 0x88 // Size: 0x10
	struct AGameplayAbilityTargetActor* TargetClass; // Offset: 0x98 // Size: 0x08
	struct AGameplayAbilityTargetActor* TargetActor; // Offset: 0xa0 // Size: 0x08
	char pad_0xA8[0x10]; // Offset: 0xa8 // Size: 0x10

	// Functions

	// Object Name: Function GameplayAbilities.AbilityTask_WaitTargetData.WaitTargetDataUsingActor
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UAbilityTask_WaitTargetData* WaitTargetDataUsingActor(struct UGameplayAbility* OwningAbility, struct FName TaskInstanceName, enum class EGameplayTargetingConfirmation ConfirmationType, struct AGameplayAbilityTargetActor* TargetActor); // Offset: 0x100ffaa40 // Return & Params: Num(5) Size(0x28)

	// Object Name: Function GameplayAbilities.AbilityTask_WaitTargetData.WaitTargetData
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UAbilityTask_WaitTargetData* WaitTargetData(struct UGameplayAbility* OwningAbility, struct FName TaskInstanceName, enum class EGameplayTargetingConfirmation ConfirmationType, struct AGameplayAbilityTargetActor* Class); // Offset: 0x100ffaba0 // Return & Params: Num(5) Size(0x28)

	// Object Name: Function GameplayAbilities.AbilityTask_WaitTargetData.OnTargetDataReplicatedCancelledCallback
	// Flags: [Final|Native|Public]
	void OnTargetDataReplicatedCancelledCallback(); // Offset: 0x100ffaf68 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function GameplayAbilities.AbilityTask_WaitTargetData.OnTargetDataReplicatedCallback
	// Flags: [Final|Native|Public|HasOutParms]
	void OnTargetDataReplicatedCallback(struct FGameplayAbilityTargetDataHandle& Data, struct FGameplayTag ActivationTag); // Offset: 0x100ffaf7c // Return & Params: Num(2) Size(0x30)

	// Object Name: Function GameplayAbilities.AbilityTask_WaitTargetData.OnTargetDataReadyCallback
	// Flags: [Final|Native|Public|HasOutParms]
	void OnTargetDataReadyCallback(struct FGameplayAbilityTargetDataHandle& Data); // Offset: 0x100ffae34 // Return & Params: Num(1) Size(0x28)

	// Object Name: Function GameplayAbilities.AbilityTask_WaitTargetData.OnTargetDataCancelledCallback
	// Flags: [Final|Native|Public|HasOutParms]
	void OnTargetDataCancelledCallback(struct FGameplayAbilityTargetDataHandle& Data); // Offset: 0x100ffad00 // Return & Params: Num(1) Size(0x28)

	// Object Name: Function GameplayAbilities.AbilityTask_WaitTargetData.K2_ExternalConfirm
	// Flags: [Final|Native|Public|BlueprintCallable]
	void K2_ExternalConfirm(bool bEndTask); // Offset: 0x100ffa7b8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function GameplayAbilities.AbilityTask_WaitTargetData.K2_ExternalCancel
	// Flags: [Final|Native|Public|BlueprintCallable]
	void K2_ExternalCancel(); // Offset: 0x100ffa79c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function GameplayAbilities.AbilityTask_WaitTargetData.FinishSpawningActor
	// Flags: [Final|Native|Public|BlueprintCallable]
	void FinishSpawningActor(struct UGameplayAbility* OwningAbility, struct AGameplayAbilityTargetActor* SpawnedActor); // Offset: 0x100ffa848 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function GameplayAbilities.AbilityTask_WaitTargetData.BeginSpawningActor
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	bool BeginSpawningActor(struct UGameplayAbility* OwningAbility, struct AGameplayAbilityTargetActor* Class, struct AGameplayAbilityTargetActor*& SpawnedActor); // Offset: 0x100ffa910 // Return & Params: Num(4) Size(0x19)
};

// Object Name: Class GameplayAbilities.AbilityTask_WaitVelocityChange
// Size: 0xa0 // Inherited bytes: 0x78
struct UAbilityTask_WaitVelocityChange : UAbilityTask {
	// Fields
	struct FMulticastInlineDelegate OnVelocityChage; // Offset: 0x78 // Size: 0x10
	struct UMovementComponent* CachedMovementComponent; // Offset: 0x88 // Size: 0x08
	char pad_0x90[0x10]; // Offset: 0x90 // Size: 0x10

	// Functions

	// Object Name: Function GameplayAbilities.AbilityTask_WaitVelocityChange.CreateWaitVelocityChange
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	struct UAbilityTask_WaitVelocityChange* CreateWaitVelocityChange(struct UGameplayAbility* OwningAbility, struct FVector Direction, float MinimumMagnitude); // Offset: 0x100ffb7b0 // Return & Params: Num(4) Size(0x20)
};

// Object Name: Class GameplayAbilities.GameplayAbility
// Size: 0x400 // Inherited bytes: 0x28
struct UGameplayAbility : UObject {
	// Fields
	char pad_0x28[0x80]; // Offset: 0x28 // Size: 0x80
	struct FGameplayTagContainer AbilityTags; // Offset: 0xa8 // Size: 0x20
	bool bReplicateInputDirectly; // Offset: 0xc8 // Size: 0x01
	bool RemoteInstanceEnded; // Offset: 0xc9 // Size: 0x01
	char pad_0xCA[0x4]; // Offset: 0xca // Size: 0x04
	enum class EGameplayAbilityReplicationPolicy ReplicationPolicy; // Offset: 0xce // Size: 0x01
	enum class EGameplayAbilityInstancingPolicy InstancingPolicy; // Offset: 0xcf // Size: 0x01
	bool bServerRespectsRemoteAbilityCancellation; // Offset: 0xd0 // Size: 0x01
	bool bRetriggerInstancedAbility; // Offset: 0xd1 // Size: 0x01
	char pad_0xD2[0x6]; // Offset: 0xd2 // Size: 0x06
	struct FGameplayAbilityActivationInfo CurrentActivationInfo; // Offset: 0xd8 // Size: 0x20
	struct FGameplayEventData CurrentEventData; // Offset: 0xf8 // Size: 0xb0
	enum class EGameplayAbilityNetExecutionPolicy NetExecutionPolicy; // Offset: 0x1a8 // Size: 0x01
	enum class EGameplayAbilityNetSecurityPolicy NetSecurityPolicy; // Offset: 0x1a9 // Size: 0x01
	char pad_0x1AA[0x6]; // Offset: 0x1aa // Size: 0x06
	struct UGameplayEffect* CostGameplayEffectClass; // Offset: 0x1b0 // Size: 0x08
	struct TArray<struct FAbilityTriggerData> AbilityTriggers; // Offset: 0x1b8 // Size: 0x10
	struct UGameplayEffect* CooldownGameplayEffectClass; // Offset: 0x1c8 // Size: 0x08
	struct FGameplayTagQuery CancelAbilitiesMatchingTagQuery; // Offset: 0x1d0 // Size: 0x48
	struct FGameplayTagContainer CancelAbilitiesWithTag; // Offset: 0x218 // Size: 0x20
	struct FGameplayTagContainer BlockAbilitiesWithTag; // Offset: 0x238 // Size: 0x20
	struct FGameplayTagContainer ActivationOwnedTags; // Offset: 0x258 // Size: 0x20
	struct FGameplayTagContainer ActivationRequiredTags; // Offset: 0x278 // Size: 0x20
	struct FGameplayTagContainer ActivationBlockedTags; // Offset: 0x298 // Size: 0x20
	struct FGameplayTagContainer SourceRequiredTags; // Offset: 0x2b8 // Size: 0x20
	struct FGameplayTagContainer SourceBlockedTags; // Offset: 0x2d8 // Size: 0x20
	struct FGameplayTagContainer TargetRequiredTags; // Offset: 0x2f8 // Size: 0x20
	struct FGameplayTagContainer TargetBlockedTags; // Offset: 0x318 // Size: 0x20
	char pad_0x338[0x20]; // Offset: 0x338 // Size: 0x20
	struct TArray<struct UGameplayTask*> ActiveTasks; // Offset: 0x358 // Size: 0x10
	char pad_0x368[0x10]; // Offset: 0x368 // Size: 0x10
	struct UAnimMontage* CurrentMontage; // Offset: 0x378 // Size: 0x08
	char pad_0x380[0x60]; // Offset: 0x380 // Size: 0x60
	bool bIsActive; // Offset: 0x3e0 // Size: 0x01
	bool bIsCancelable; // Offset: 0x3e1 // Size: 0x01
	bool bIsBlockingOtherAbilities; // Offset: 0x3e2 // Size: 0x01
	char pad_0x3E3[0x15]; // Offset: 0x3e3 // Size: 0x15
	bool bMarkPendingKillOnAbilityEnd; // Offset: 0x3f8 // Size: 0x01
	char pad_0x3F9[0x7]; // Offset: 0x3f9 // Size: 0x07

	// Functions

	// Object Name: Function GameplayAbilities.GameplayAbility.SetShouldBlockOtherAbilities
	// Flags: [Native|Public|BlueprintCallable]
	void SetShouldBlockOtherAbilities(bool bShouldBlockAbilities); // Offset: 0x100ffe38c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function GameplayAbilities.GameplayAbility.SetCanBeCanceled
	// Flags: [Native|Public|BlueprintCallable]
	void SetCanBeCanceled(bool bCanBeCanceled); // Offset: 0x100ffe2e8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function GameplayAbilities.GameplayAbility.SendGameplayEvent
	// Flags: [Native|Protected|BlueprintCallable]
	void SendGameplayEvent(struct FGameplayTag EventTag, struct FGameplayEventData Payload); // Offset: 0x100ffddb8 // Return & Params: Num(2) Size(0xb8)

	// Object Name: Function GameplayAbilities.GameplayAbility.RemoveGrantedByEffect
	// Flags: [Native|Public|BlueprintCallable]
	void RemoveGrantedByEffect(); // Offset: 0x100ffdfd0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function GameplayAbilities.GameplayAbility.MontageStop
	// Flags: [Final|Native|Protected|BlueprintCallable]
	void MontageStop(float OverrideBlendOutTime); // Offset: 0x100ffc4a0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function GameplayAbilities.GameplayAbility.MontageSetNextSectionName
	// Flags: [Final|Native|Protected|BlueprintCallable]
	void MontageSetNextSectionName(struct FName FromSectionName, struct FName ToSectionName); // Offset: 0x100ffc520 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function GameplayAbilities.GameplayAbility.MontageJumpToSection
	// Flags: [Final|Native|Protected|BlueprintCallable]
	void MontageJumpToSection(struct FName SectionName); // Offset: 0x100ffc5e8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function GameplayAbilities.GameplayAbility.MakeTargetLocationInfoFromOwnerSkeletalMeshComponent
	// Flags: [Final|Native|Protected|BlueprintCallable|BlueprintPure]
	struct FGameplayAbilityTargetingLocationInfo MakeTargetLocationInfoFromOwnerSkeletalMeshComponent(struct FName SocketName); // Offset: 0x100ffc31c // Return & Params: Num(2) Size(0x70)

	// Object Name: Function GameplayAbilities.GameplayAbility.MakeTargetLocationInfoFromOwnerActor
	// Flags: [Final|Native|Protected|BlueprintCallable|BlueprintPure]
	struct FGameplayAbilityTargetingLocationInfo MakeTargetLocationInfoFromOwnerActor(); // Offset: 0x100ffc408 // Return & Params: Num(1) Size(0x60)

	// Object Name: Function GameplayAbilities.GameplayAbility.MakeOutgoingGameplayEffectSpec
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FGameplayEffectSpecHandle MakeOutgoingGameplayEffectSpec(struct UGameplayEffect* GameplayEffectClass, float Level); // Offset: 0x100ffe450 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function GameplayAbilities.GameplayAbility.K2_ShouldAbilityRespondToEvent
	// Flags: [Event|Protected|BlueprintEvent|Const]
	bool K2_ShouldAbilityRespondToEvent(struct FGameplayAbilityActorInfo ActorInfo, struct FGameplayEventData Payload); // Offset: 0x1032ea4b8 // Return & Params: Num(3) Size(0xf9)

	// Object Name: Function GameplayAbilities.GameplayAbility.K2_RemoveGameplayCue
	// Flags: [Native|Protected|BlueprintCallable]
	void K2_RemoveGameplayCue(struct FGameplayTag GameplayCueTag); // Offset: 0x100ffc8bc // Return & Params: Num(1) Size(0x8)

	// Object Name: Function GameplayAbilities.GameplayAbility.K2_OnEndAbility
	// Flags: [Event|Protected|BlueprintEvent]
	void K2_OnEndAbility(bool bWasCancelled); // Offset: 0x1032ea4b8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function GameplayAbilities.GameplayAbility.K2_ExecuteGameplayCueWithParams
	// Flags: [Native|Protected|HasOutParms|BlueprintCallable]
	void K2_ExecuteGameplayCueWithParams(struct FGameplayTag GameplayCueTag, struct FGameplayCueParameters& GameplayCueParameters); // Offset: 0x100ffcd58 // Return & Params: Num(2) Size(0xc8)

	// Object Name: Function GameplayAbilities.GameplayAbility.K2_ExecuteGameplayCue
	// Flags: [Native|Protected|BlueprintCallable]
	void K2_ExecuteGameplayCue(struct FGameplayTag GameplayCueTag, struct FGameplayEffectContextHandle Context); // Offset: 0x100ffcf14 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function GameplayAbilities.GameplayAbility.K2_EndAbility
	// Flags: [Native|Protected|BlueprintCallable]
	void K2_EndAbility(); // Offset: 0x100ffdd9c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function GameplayAbilities.GameplayAbility.K2_CommitExecute
	// Flags: [Event|Public|BlueprintEvent]
	void K2_CommitExecute(); // Offset: 0x1032ea4b8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function GameplayAbilities.GameplayAbility.K2_CommitAbilityCost
	// Flags: [Native|Public|BlueprintCallable]
	bool K2_CommitAbilityCost(bool BroadcastCommitEvent); // Offset: 0x100ffe114 // Return & Params: Num(2) Size(0x2)

	// Object Name: Function GameplayAbilities.GameplayAbility.K2_CommitAbilityCooldown
	// Flags: [Native|Public|BlueprintCallable]
	bool K2_CommitAbilityCooldown(bool BroadcastCommitEvent, bool ForceCooldown); // Offset: 0x100ffe1b4 // Return & Params: Num(3) Size(0x3)

	// Object Name: Function GameplayAbilities.GameplayAbility.K2_CommitAbility
	// Flags: [Native|Public|BlueprintCallable]
	bool K2_CommitAbility(); // Offset: 0x100ffe2ac // Return & Params: Num(1) Size(0x1)

	// Object Name: Function GameplayAbilities.GameplayAbility.K2_CheckAbilityCost
	// Flags: [Native|Public|BlueprintCallable]
	bool K2_CheckAbilityCost(); // Offset: 0x100ffe09c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function GameplayAbilities.GameplayAbility.K2_CheckAbilityCooldown
	// Flags: [Native|Public|BlueprintCallable]
	bool K2_CheckAbilityCooldown(); // Offset: 0x100ffe0d8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function GameplayAbilities.GameplayAbility.K2_CancelAbility
	// Flags: [Final|Native|Public|BlueprintCallable]
	void K2_CancelAbility(); // Offset: 0x100ffe378 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function GameplayAbilities.GameplayAbility.K2_CanActivateAbility
	// Flags: [Event|Protected|HasOutParms|BlueprintEvent|Const]
	bool K2_CanActivateAbility(struct FGameplayAbilityActorInfo ActorInfo, struct FGameplayTagContainer& RelevantTags); // Offset: 0x1032ea4b8 // Return & Params: Num(3) Size(0x69)

	// Object Name: Function GameplayAbilities.GameplayAbility.K2_ApplyGameplayEffectSpecToTarget
	// Flags: [Final|Native|Protected|BlueprintCallable]
	struct TArray<struct FActiveGameplayEffectHandle> K2_ApplyGameplayEffectSpecToTarget(struct FGameplayEffectSpecHandle EffectSpecHandle, struct FGameplayAbilityTargetDataHandle TargetData); // Offset: 0x100ffd3c8 // Return & Params: Num(3) Size(0x48)

	// Object Name: Function GameplayAbilities.GameplayAbility.K2_ApplyGameplayEffectSpecToOwner
	// Flags: [Final|Native|Protected|BlueprintCallable]
	struct FActiveGameplayEffectHandle K2_ApplyGameplayEffectSpecToOwner(struct FGameplayEffectSpecHandle EffectSpecHandle); // Offset: 0x100ffdb04 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function GameplayAbilities.GameplayAbility.K2_AddGameplayCueWithParams
	// Flags: [Native|Protected|HasOutParms|BlueprintCallable]
	void K2_AddGameplayCueWithParams(struct FGameplayTag GameplayCueTag, struct FGameplayCueParameters& GameplayCueParameter, bool bRemoveOnAbilityEnd); // Offset: 0x100ffc944 // Return & Params: Num(3) Size(0xc9)

	// Object Name: Function GameplayAbilities.GameplayAbility.K2_AddGameplayCue
	// Flags: [Native|Protected|BlueprintCallable]
	void K2_AddGameplayCue(struct FGameplayTag GameplayCueTag, struct FGameplayEffectContextHandle Context, bool bRemoveOnAbilityEnd); // Offset: 0x100ffcb4c // Return & Params: Num(3) Size(0x21)

	// Object Name: Function GameplayAbilities.GameplayAbility.K2_ActivateAbilityFromEvent
	// Flags: [Event|Protected|HasOutParms|BlueprintEvent]
	void K2_ActivateAbilityFromEvent(struct FGameplayEventData& EventData); // Offset: 0x1032ea4b8 // Return & Params: Num(1) Size(0xb0)

	// Object Name: Function GameplayAbilities.GameplayAbility.K2_ActivateAbility
	// Flags: [Event|Protected|BlueprintEvent]
	void K2_ActivateAbility(); // Offset: 0x1032ea4b8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function GameplayAbilities.GameplayAbility.InvalidateClientPredictionKey
	// Flags: [Final|Native|Public|BlueprintCallable|Const]
	void InvalidateClientPredictionKey(); // Offset: 0x100ffdfec // Return & Params: Num(0) Size(0x0)

	// Object Name: Function GameplayAbilities.GameplayAbility.GetOwningComponentFromActorInfo
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct USkeletalMeshComponent* GetOwningComponentFromActorInfo(); // Offset: 0x100ffea9c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function GameplayAbilities.GameplayAbility.GetOwningActorFromActorInfo
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct AActor* GetOwningActorFromActorInfo(); // Offset: 0x100ffeb04 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function GameplayAbilities.GameplayAbility.GetGrantedByEffectContext
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FGameplayEffectContextHandle GetGrantedByEffectContext(); // Offset: 0x100ffe950 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function GameplayAbilities.GameplayAbility.GetCurrentSourceObject
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UObject* GetCurrentSourceObject(); // Offset: 0x100ffe000 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function GameplayAbilities.GameplayAbility.GetCurrentMontage
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UAnimMontage* GetCurrentMontage(); // Offset: 0x100ffe068 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function GameplayAbilities.GameplayAbility.GetCooldownTimeRemaining
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetCooldownTimeRemaining(); // Offset: 0x100ffe41c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function GameplayAbilities.GameplayAbility.GetContextFromOwner
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FGameplayEffectContextHandle GetContextFromOwner(struct FGameplayAbilityTargetDataHandle OptionalTargetData); // Offset: 0x100ffe604 // Return & Params: Num(2) Size(0x40)

	// Object Name: Function GameplayAbilities.GameplayAbility.GetAvatarActorFromActorInfo
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct AActor* GetAvatarActorFromActorInfo(); // Offset: 0x100ffead0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function GameplayAbilities.GameplayAbility.GetActorInfo
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FGameplayAbilityActorInfo GetActorInfo(); // Offset: 0x100ffeb38 // Return & Params: Num(1) Size(0x48)

	// Object Name: Function GameplayAbilities.GameplayAbility.GetAbilitySystemComponentFromActorInfo
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UAbilitySystemComponent* GetAbilitySystemComponentFromActorInfo(); // Offset: 0x100ffea68 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function GameplayAbilities.GameplayAbility.GetAbilityLevel
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetAbilityLevel(); // Offset: 0x100ffe034 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function GameplayAbilities.GameplayAbility.EndTaskByInstanceName
	// Flags: [Final|Native|Protected|BlueprintCallable]
	void EndTaskByInstanceName(struct FName InstanceName); // Offset: 0x100ffc768 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function GameplayAbilities.GameplayAbility.EndAbilityState
	// Flags: [Final|Native|Protected|BlueprintCallable]
	void EndAbilityState(struct FName OptionalStateNameToEnd); // Offset: 0x100ffc668 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function GameplayAbilities.GameplayAbility.ConfirmTaskByInstanceName
	// Flags: [Final|Native|Protected|BlueprintCallable]
	void ConfirmTaskByInstanceName(struct FName InstanceName, bool bEndTask); // Offset: 0x100ffc7e8 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function GameplayAbilities.GameplayAbility.CancelTaskByInstanceName
	// Flags: [Final|Native|Protected|BlueprintCallable]
	void CancelTaskByInstanceName(struct FName InstanceName); // Offset: 0x100ffc6e8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function GameplayAbilities.GameplayAbility.BP_RemoveGameplayEffectFromOwnerWithHandle
	// Flags: [Final|Native|Protected|BlueprintCallable]
	void BP_RemoveGameplayEffectFromOwnerWithHandle(struct FActiveGameplayEffectHandle Handle, int32_t StacksToRemove); // Offset: 0x100ffd0cc // Return & Params: Num(2) Size(0xc)

	// Object Name: Function GameplayAbilities.GameplayAbility.BP_RemoveGameplayEffectFromOwnerWithGrantedTags
	// Flags: [Final|Native|Protected|BlueprintCallable]
	void BP_RemoveGameplayEffectFromOwnerWithGrantedTags(struct FGameplayTagContainer WithGrantedTags, int32_t StacksToRemove); // Offset: 0x100ffd1a0 // Return & Params: Num(2) Size(0x24)

	// Object Name: Function GameplayAbilities.GameplayAbility.BP_RemoveGameplayEffectFromOwnerWithAssetTags
	// Flags: [Final|Native|Protected|BlueprintCallable]
	void BP_RemoveGameplayEffectFromOwnerWithAssetTags(struct FGameplayTagContainer WithAssetTags, int32_t StacksToRemove); // Offset: 0x100ffd2b4 // Return & Params: Num(2) Size(0x24)

	// Object Name: Function GameplayAbilities.GameplayAbility.BP_ApplyGameplayEffectToTarget
	// Flags: [Final|Native|Protected|BlueprintCallable]
	struct TArray<struct FActiveGameplayEffectHandle> BP_ApplyGameplayEffectToTarget(struct FGameplayAbilityTargetDataHandle TargetData, struct UGameplayEffect* GameplayEffectClass, int32_t GameplayEffectLevel, int32_t Stacks); // Offset: 0x100ffd780 // Return & Params: Num(5) Size(0x48)

	// Object Name: Function GameplayAbilities.GameplayAbility.BP_ApplyGameplayEffectToOwner
	// Flags: [Final|Native|Protected|BlueprintCallable]
	struct FActiveGameplayEffectHandle BP_ApplyGameplayEffectToOwner(struct UGameplayEffect* GameplayEffectClass, int32_t GameplayEffectLevel, int32_t Stacks); // Offset: 0x100ffdc70 // Return & Params: Num(4) Size(0x18)
};

// Object Name: Class GameplayAbilities.GameplayAbility_CharacterJump
// Size: 0x400 // Inherited bytes: 0x400
struct UGameplayAbility_CharacterJump : UGameplayAbility {
};

// Object Name: Class GameplayAbilities.GameplayAbility_Montage
// Size: 0x438 // Inherited bytes: 0x400
struct UGameplayAbility_Montage : UGameplayAbility {
	// Fields
	struct UAnimMontage* MontageToPlay; // Offset: 0x400 // Size: 0x08
	float PlayRate; // Offset: 0x408 // Size: 0x04
	struct FName SectionName; // Offset: 0x40c // Size: 0x08
	char pad_0x414[0x4]; // Offset: 0x414 // Size: 0x04
	struct TArray<struct UGameplayEffect*> GameplayEffectClassesWhileAnimating; // Offset: 0x418 // Size: 0x10
	struct TArray<struct UGameplayEffect*> GameplayEffectsWhileAnimating; // Offset: 0x428 // Size: 0x10
};

// Object Name: Class GameplayAbilities.GameplayAbilityBlueprint
// Size: 0xa0 // Inherited bytes: 0xa0
struct UGameplayAbilityBlueprint : UBlueprint {
};

// Object Name: Class GameplayAbilities.GameplayAbilitySet
// Size: 0x40 // Inherited bytes: 0x30
struct UGameplayAbilitySet : UDataAsset {
	// Fields
	struct TArray<struct FGameplayAbilityBindInfo> Abilities; // Offset: 0x30 // Size: 0x10
};

// Object Name: Class GameplayAbilities.GameplayAbilityTargetActor
// Size: 0x330 // Inherited bytes: 0x228
struct AGameplayAbilityTargetActor : AActor {
	// Fields
	bool ShouldProduceTargetDataOnServer; // Offset: 0x228 // Size: 0x01
	char pad_0x229[0x7]; // Offset: 0x229 // Size: 0x07
	struct FGameplayAbilityTargetingLocationInfo StartLocation; // Offset: 0x230 // Size: 0x60
	char pad_0x290[0x30]; // Offset: 0x290 // Size: 0x30
	struct APlayerController* MasterPC; // Offset: 0x2c0 // Size: 0x08
	struct UGameplayAbility* OwningAbility; // Offset: 0x2c8 // Size: 0x08
	bool bDestroyOnConfirmation; // Offset: 0x2d0 // Size: 0x01
	char pad_0x2D1[0x7]; // Offset: 0x2d1 // Size: 0x07
	struct AActor* SourceActor; // Offset: 0x2d8 // Size: 0x08
	struct FWorldReticleParameters ReticleParams; // Offset: 0x2e0 // Size: 0x0c
	char pad_0x2EC[0x4]; // Offset: 0x2ec // Size: 0x04
	struct AGameplayAbilityWorldReticle* ReticleClass; // Offset: 0x2f0 // Size: 0x08
	struct FGameplayTargetDataFilterHandle Filter; // Offset: 0x2f8 // Size: 0x10
	bool bDebug; // Offset: 0x308 // Size: 0x01
	char pad_0x309[0x17]; // Offset: 0x309 // Size: 0x17
	struct UAbilitySystemComponent* GenericDelegateBoundASC; // Offset: 0x320 // Size: 0x08
	char pad_0x328[0x8]; // Offset: 0x328 // Size: 0x08

	// Functions

	// Object Name: Function GameplayAbilities.GameplayAbilityTargetActor.ConfirmTargeting
	// Flags: [Native|Public]
	void ConfirmTargeting(); // Offset: 0x101002fcc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function GameplayAbilities.GameplayAbilityTargetActor.CancelTargeting
	// Flags: [Native|Public]
	void CancelTargeting(); // Offset: 0x101002fb0 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class GameplayAbilities.GameplayAbilityTargetActor_Trace
// Size: 0x340 // Inherited bytes: 0x330
struct AGameplayAbilityTargetActor_Trace : AGameplayAbilityTargetActor {
	// Fields
	float MaxRange; // Offset: 0x328 // Size: 0x04
	struct FCollisionProfileName TraceProfile; // Offset: 0x32c // Size: 0x08
	bool bTraceAffectsAimPitch; // Offset: 0x334 // Size: 0x01
	char pad_0x33D[0x3]; // Offset: 0x33d // Size: 0x03
};

// Object Name: Class GameplayAbilities.GameplayAbilityTargetActor_GroundTrace
// Size: 0x360 // Inherited bytes: 0x340
struct AGameplayAbilityTargetActor_GroundTrace : AGameplayAbilityTargetActor_Trace {
	// Fields
	float CollisionRadius; // Offset: 0x340 // Size: 0x04
	float CollisionHeight; // Offset: 0x344 // Size: 0x04
	char pad_0x348[0x18]; // Offset: 0x348 // Size: 0x18
};

// Object Name: Class GameplayAbilities.GameplayAbilityTargetActor_ActorPlacement
// Size: 0x380 // Inherited bytes: 0x360
struct AGameplayAbilityTargetActor_ActorPlacement : AGameplayAbilityTargetActor_GroundTrace {
	// Fields
	struct UObject* PlacedActorClass; // Offset: 0x360 // Size: 0x08
	struct UMaterialInterface* PlacedActorMaterial; // Offset: 0x368 // Size: 0x08
	char pad_0x370[0x10]; // Offset: 0x370 // Size: 0x10
};

// Object Name: Class GameplayAbilities.GameplayAbilityTargetActor_Radius
// Size: 0x330 // Inherited bytes: 0x330
struct AGameplayAbilityTargetActor_Radius : AGameplayAbilityTargetActor {
	// Fields
	float Radius; // Offset: 0x328 // Size: 0x04
};

// Object Name: Class GameplayAbilities.GameplayAbilityTargetActor_SingleLineTrace
// Size: 0x340 // Inherited bytes: 0x340
struct AGameplayAbilityTargetActor_SingleLineTrace : AGameplayAbilityTargetActor_Trace {
};

// Object Name: Class GameplayAbilities.GameplayAbilityWorldReticle
// Size: 0x248 // Inherited bytes: 0x228
struct AGameplayAbilityWorldReticle : AActor {
	// Fields
	struct FWorldReticleParameters Parameters; // Offset: 0x228 // Size: 0x0c
	bool bFaceOwnerFlat; // Offset: 0x234 // Size: 0x01
	bool bSnapToTargetedActor; // Offset: 0x235 // Size: 0x01
	bool bIsTargetValid; // Offset: 0x236 // Size: 0x01
	bool bIsTargetAnActor; // Offset: 0x237 // Size: 0x01
	struct APlayerController* MasterPC; // Offset: 0x238 // Size: 0x08
	struct AActor* TargetingActor; // Offset: 0x240 // Size: 0x08

	// Functions

	// Object Name: Function GameplayAbilities.GameplayAbilityWorldReticle.SetReticleMaterialParamVector
	// Flags: [Event|Public|HasDefaults|BlueprintEvent]
	void SetReticleMaterialParamVector(struct FName ParamName, struct FVector Value); // Offset: 0x1032ea4b8 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function GameplayAbilities.GameplayAbilityWorldReticle.SetReticleMaterialParamFloat
	// Flags: [Event|Public|BlueprintEvent]
	void SetReticleMaterialParamFloat(struct FName ParamName, float Value); // Offset: 0x1032ea4b8 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function GameplayAbilities.GameplayAbilityWorldReticle.OnValidTargetChanged
	// Flags: [Event|Public|BlueprintEvent]
	void OnValidTargetChanged(bool bNewValue); // Offset: 0x1032ea4b8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function GameplayAbilities.GameplayAbilityWorldReticle.OnTargetingAnActor
	// Flags: [Event|Public|BlueprintEvent]
	void OnTargetingAnActor(bool bNewValue); // Offset: 0x1032ea4b8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function GameplayAbilities.GameplayAbilityWorldReticle.OnParametersInitialized
	// Flags: [Event|Public|BlueprintEvent]
	void OnParametersInitialized(); // Offset: 0x1032ea4b8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function GameplayAbilities.GameplayAbilityWorldReticle.FaceTowardSource
	// Flags: [Final|Native|Public|BlueprintCallable]
	void FaceTowardSource(bool bFaceIn2D); // Offset: 0x1010051dc // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class GameplayAbilities.GameplayAbilityWorldReticle_ActorVisualization
// Size: 0x260 // Inherited bytes: 0x248
struct AGameplayAbilityWorldReticle_ActorVisualization : AGameplayAbilityWorldReticle {
	// Fields
	struct UCapsuleComponent* CollisionComponent; // Offset: 0x248 // Size: 0x08
	struct TArray<struct UActorComponent*> VisualizationComponents; // Offset: 0x250 // Size: 0x10
};

// Object Name: Class GameplayAbilities.GameplayCueInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UGameplayCueInterface : UInterface {
	// Functions

	// Object Name: Function GameplayAbilities.GameplayCueInterface.ForwardGameplayCueToParent
	// Flags: [BlueprintCosmetic|Native|Public|BlueprintCallable]
	void ForwardGameplayCueToParent(); // Offset: 0x10100f394 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function GameplayAbilities.GameplayCueInterface.BlueprintCustomHandler
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void BlueprintCustomHandler(enum class EGameplayCueEvent EventType, struct FGameplayCueParameters Parameters); // Offset: 0x1032ea4b8 // Return & Params: Num(2) Size(0xc8)
};

// Object Name: Class GameplayAbilities.GameplayCueManager
// Size: 0x310 // Inherited bytes: 0x30
struct UGameplayCueManager : UDataAsset {
	// Fields
	char pad_0x30[0x18]; // Offset: 0x30 // Size: 0x18
	struct FGameplayCueObjectLibrary RuntimeGameplayCueObjectLibrary; // Offset: 0x48 // Size: 0x50
	struct FGameplayCueObjectLibrary EditorGameplayCueObjectLibrary; // Offset: 0x98 // Size: 0x50
	char pad_0xE8[0x1c8]; // Offset: 0xe8 // Size: 0x1c8
	struct TArray<struct UObject*> LoadedGameplayCueNotifyClasses; // Offset: 0x2b0 // Size: 0x10
	struct TArray<struct AGameplayCueNotify_Actor*> GameplayCueClassesForPreallocation; // Offset: 0x2c0 // Size: 0x10
	struct TArray<struct FGameplayCuePendingExecute> PendingExecuteCues; // Offset: 0x2d0 // Size: 0x10
	int32_t GameplayCueSendContextCount; // Offset: 0x2e0 // Size: 0x04
	char pad_0x2E4[0x4]; // Offset: 0x2e4 // Size: 0x04
	struct TArray<struct FPreallocationInfo> PreallocationInfoList_Internal; // Offset: 0x2e8 // Size: 0x10
	char pad_0x2F8[0x18]; // Offset: 0x2f8 // Size: 0x18
};

// Object Name: Class GameplayAbilities.GameplayCueNotify_Actor
// Size: 0x298 // Inherited bytes: 0x228
struct AGameplayCueNotify_Actor : AActor {
	// Fields
	bool bAutoDestroyOnRemove; // Offset: 0x228 // Size: 0x01
	char pad_0x229[0x3]; // Offset: 0x229 // Size: 0x03
	float AutoDestroyDelay; // Offset: 0x22c // Size: 0x04
	bool WarnIfTimelineIsStillRunning; // Offset: 0x230 // Size: 0x01
	bool WarnIfLatentActionIsStillRunning; // Offset: 0x231 // Size: 0x01
	char pad_0x232[0x2]; // Offset: 0x232 // Size: 0x02
	struct FGameplayTag GameplayCueTag; // Offset: 0x234 // Size: 0x08
	char pad_0x23C[0x4]; // Offset: 0x23c // Size: 0x04
	struct FGameplayTagReferenceHelper ReferenceHelper; // Offset: 0x240 // Size: 0x10
	struct FName GameplayCueName; // Offset: 0x250 // Size: 0x08
	bool bAutoAttachToOwner; // Offset: 0x258 // Size: 0x01
	bool IsOverride; // Offset: 0x259 // Size: 0x01
	bool bUniqueInstancePerInstigator; // Offset: 0x25a // Size: 0x01
	bool bUniqueInstancePerSourceObject; // Offset: 0x25b // Size: 0x01
	bool bAllowMultipleOnActiveEvents; // Offset: 0x25c // Size: 0x01
	bool bAllowMultipleWhileActiveEvents; // Offset: 0x25d // Size: 0x01
	char pad_0x25E[0x2]; // Offset: 0x25e // Size: 0x02
	int32_t NumPreallocatedInstances; // Offset: 0x260 // Size: 0x04
	char pad_0x264[0x34]; // Offset: 0x264 // Size: 0x34

	// Functions

	// Object Name: Function GameplayAbilities.GameplayCueNotify_Actor.WhileActive
	// Flags: [Native|Event|Public|HasOutParms|BlueprintEvent]
	bool WhileActive(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters); // Offset: 0x10100fdc4 // Return & Params: Num(3) Size(0xc9)

	// Object Name: Function GameplayAbilities.GameplayCueNotify_Actor.OnRemove
	// Flags: [Native|Event|Public|HasOutParms|BlueprintEvent]
	bool OnRemove(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters); // Offset: 0x10100fc00 // Return & Params: Num(3) Size(0xc9)

	// Object Name: Function GameplayAbilities.GameplayCueNotify_Actor.OnOwnerDestroyed
	// Flags: [Native|Public]
	void OnOwnerDestroyed(struct AActor* DestroyedActor); // Offset: 0x10101032c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function GameplayAbilities.GameplayCueNotify_Actor.OnExecute
	// Flags: [Native|Event|Public|HasOutParms|BlueprintEvent]
	bool OnExecute(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters); // Offset: 0x10101014c // Return & Params: Num(3) Size(0xc9)

	// Object Name: Function GameplayAbilities.GameplayCueNotify_Actor.OnActive
	// Flags: [Native|Event|Public|HasOutParms|BlueprintEvent]
	bool OnActive(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters); // Offset: 0x10100ff88 // Return & Params: Num(3) Size(0xc9)

	// Object Name: Function GameplayAbilities.GameplayCueNotify_Actor.K2_HandleGameplayCue
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	void K2_HandleGameplayCue(struct AActor* MyTarget, enum class EGameplayCueEvent EventType, struct FGameplayCueParameters& Parameters); // Offset: 0x1032ea4b8 // Return & Params: Num(3) Size(0xd0)

	// Object Name: Function GameplayAbilities.GameplayCueNotify_Actor.K2_EndGameplayCue
	// Flags: [Native|Public|BlueprintCallable]
	void K2_EndGameplayCue(); // Offset: 0x101010310 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class GameplayAbilities.GameplayCueNotify_Static
// Size: 0x50 // Inherited bytes: 0x28
struct UGameplayCueNotify_Static : UObject {
	// Fields
	struct FGameplayTag GameplayCueTag; // Offset: 0x28 // Size: 0x08
	struct FGameplayTagReferenceHelper ReferenceHelper; // Offset: 0x30 // Size: 0x10
	struct FName GameplayCueName; // Offset: 0x40 // Size: 0x08
	bool IsOverride; // Offset: 0x48 // Size: 0x01
	char pad_0x49[0x7]; // Offset: 0x49 // Size: 0x07

	// Functions

	// Object Name: Function GameplayAbilities.GameplayCueNotify_Static.WhileActive
	// Flags: [Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const]
	bool WhileActive(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters); // Offset: 0x101011760 // Return & Params: Num(3) Size(0xc9)

	// Object Name: Function GameplayAbilities.GameplayCueNotify_Static.OnRemove
	// Flags: [Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const]
	bool OnRemove(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters); // Offset: 0x10101159c // Return & Params: Num(3) Size(0xc9)

	// Object Name: Function GameplayAbilities.GameplayCueNotify_Static.OnExecute
	// Flags: [Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const]
	bool OnExecute(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters); // Offset: 0x101011ae8 // Return & Params: Num(3) Size(0xc9)

	// Object Name: Function GameplayAbilities.GameplayCueNotify_Static.OnActive
	// Flags: [Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const]
	bool OnActive(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters); // Offset: 0x101011924 // Return & Params: Num(3) Size(0xc9)

	// Object Name: Function GameplayAbilities.GameplayCueNotify_Static.K2_HandleGameplayCue
	// Flags: [Event|Public|HasOutParms|BlueprintEvent|Const]
	void K2_HandleGameplayCue(struct AActor* MyTarget, enum class EGameplayCueEvent EventType, struct FGameplayCueParameters& Parameters); // Offset: 0x1032ea4b8 // Return & Params: Num(3) Size(0xd0)
};

// Object Name: Class GameplayAbilities.GameplayCueNotify_HitImpact
// Size: 0x60 // Inherited bytes: 0x50
struct UGameplayCueNotify_HitImpact : UGameplayCueNotify_Static {
	// Fields
	struct USoundBase* Sound; // Offset: 0x50 // Size: 0x08
	struct UParticleSystem* ParticleSystem; // Offset: 0x58 // Size: 0x08
};

// Object Name: Class GameplayAbilities.GameplayCueSet
// Size: 0x90 // Inherited bytes: 0x30
struct UGameplayCueSet : UDataAsset {
	// Fields
	struct TArray<struct FGameplayCueNotifyData> GameplayCueData; // Offset: 0x30 // Size: 0x10
	char pad_0x40[0x50]; // Offset: 0x40 // Size: 0x50
};

// Object Name: Class GameplayAbilities.GameplayCueTranslator
// Size: 0x28 // Inherited bytes: 0x28
struct UGameplayCueTranslator : UObject {
};

// Object Name: Class GameplayAbilities.GameplayCueTranslator_Test
// Size: 0x28 // Inherited bytes: 0x28
struct UGameplayCueTranslator_Test : UGameplayCueTranslator {
};

// Object Name: Class GameplayAbilities.GameplayEffect
// Size: 0x848 // Inherited bytes: 0x28
struct UGameplayEffect : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08
	enum class EGameplayEffectDurationType DurationPolicy; // Offset: 0x30 // Size: 0x01
	char pad_0x31[0x7]; // Offset: 0x31 // Size: 0x07
	struct FGameplayEffectModifierMagnitude DurationMagnitude; // Offset: 0x38 // Size: 0x1a8
	struct FScalableFloat Period; // Offset: 0x1e0 // Size: 0x20
	bool bExecutePeriodicEffectOnApplication; // Offset: 0x200 // Size: 0x01
	enum class EGameplayEffectPeriodInhibitionRemovedPolicy PeriodicInhibitionPolicy; // Offset: 0x201 // Size: 0x01
	char pad_0x202[0x6]; // Offset: 0x202 // Size: 0x06
	struct TArray<struct FGameplayModifierInfo> Modifiers; // Offset: 0x208 // Size: 0x10
	struct TArray<struct FGameplayEffectExecutionDefinition> Executions; // Offset: 0x218 // Size: 0x10
	struct FScalableFloat ChanceToApplyToTarget; // Offset: 0x228 // Size: 0x20
	struct TArray<struct UGameplayEffectCustomApplicationRequirement*> ApplicationRequirements; // Offset: 0x248 // Size: 0x10
	struct TArray<struct UGameplayEffect*> TargetEffectClasses; // Offset: 0x258 // Size: 0x10
	struct TArray<struct FConditionalGameplayEffect> ConditionalGameplayEffects; // Offset: 0x268 // Size: 0x10
	struct TArray<struct UGameplayEffect*> OverflowEffects; // Offset: 0x278 // Size: 0x10
	bool bDenyOverflowApplication; // Offset: 0x288 // Size: 0x01
	bool bClearStackOnOverflow; // Offset: 0x289 // Size: 0x01
	char pad_0x28A[0x6]; // Offset: 0x28a // Size: 0x06
	struct TArray<struct UGameplayEffect*> PrematureExpirationEffectClasses; // Offset: 0x290 // Size: 0x10
	struct TArray<struct UGameplayEffect*> RoutineExpirationEffectClasses; // Offset: 0x2a0 // Size: 0x10
	bool bRequireModifierSuccessToTriggerCues; // Offset: 0x2b0 // Size: 0x01
	bool bSuppressStackingCues; // Offset: 0x2b1 // Size: 0x01
	char pad_0x2B2[0x6]; // Offset: 0x2b2 // Size: 0x06
	struct TArray<struct FGameplayEffectCue> GameplayCues; // Offset: 0x2b8 // Size: 0x10
	struct UGameplayEffectUIData* UIData; // Offset: 0x2c8 // Size: 0x08
	struct FInheritedTagContainer InheritableGameplayEffectTags; // Offset: 0x2d0 // Size: 0x60
	struct FInheritedTagContainer InheritableOwnedTagsContainer; // Offset: 0x330 // Size: 0x60
	struct FGameplayTagRequirements OngoingTagRequirements; // Offset: 0x390 // Size: 0x50
	struct FGameplayTagRequirements ApplicationTagRequirements; // Offset: 0x3e0 // Size: 0x50
	struct FGameplayTagRequirements RemovalTagRequirements; // Offset: 0x430 // Size: 0x50
	struct FGameplayTagRequirements RemovalSourceTagRequirements; // Offset: 0x480 // Size: 0x50
	struct FInheritedTagContainer RemoveGameplayEffectsWithTags; // Offset: 0x4d0 // Size: 0x60
	struct FGameplayTagRequirements GrantedApplicationImmunityTags; // Offset: 0x530 // Size: 0x50
	struct FGameplayEffectQuery GrantedApplicationImmunityQuery; // Offset: 0x580 // Size: 0x150
	char pad_0x6D0[0x8]; // Offset: 0x6d0 // Size: 0x08
	struct FGameplayEffectQuery RemoveGameplayEffectQuery; // Offset: 0x6d8 // Size: 0x150
	char pad_0x828[0x1]; // Offset: 0x828 // Size: 0x01
	enum class EGameplayEffectStackingType StackingType; // Offset: 0x829 // Size: 0x01
	char pad_0x82A[0x2]; // Offset: 0x82a // Size: 0x02
	int32_t StackLimitCount; // Offset: 0x82c // Size: 0x04
	enum class EGameplayEffectStackingDurationPolicy StackDurationRefreshPolicy; // Offset: 0x830 // Size: 0x01
	enum class EGameplayEffectStackingPeriodPolicy StackPeriodResetPolicy; // Offset: 0x831 // Size: 0x01
	enum class EGameplayEffectStackingExpirationPolicy StackExpirationPolicy; // Offset: 0x832 // Size: 0x01
	char pad_0x833[0x5]; // Offset: 0x833 // Size: 0x05
	struct TArray<struct FGameplayAbilitySpecDef> GrantedAbilities; // Offset: 0x838 // Size: 0x10
};

// Object Name: Class GameplayAbilities.GameplayEffectCalculation
// Size: 0x38 // Inherited bytes: 0x28
struct UGameplayEffectCalculation : UObject {
	// Fields
	struct TArray<struct FGameplayEffectAttributeCaptureDefinition> RelevantAttributesToCapture; // Offset: 0x28 // Size: 0x10
};

// Object Name: Class GameplayAbilities.GameplayEffectCustomApplicationRequirement
// Size: 0x28 // Inherited bytes: 0x28
struct UGameplayEffectCustomApplicationRequirement : UObject {
	// Functions

	// Object Name: Function GameplayAbilities.GameplayEffectCustomApplicationRequirement.CanApplyGameplayEffect
	// Flags: [Native|Event|Public|HasOutParms|BlueprintEvent|Const]
	bool CanApplyGameplayEffect(struct UGameplayEffect* GameplayEffect, struct FGameplayEffectSpec& Spec, struct UAbilitySystemComponent* ASC); // Offset: 0x10101d488 // Return & Params: Num(4) Size(0x2a9)
};

// Object Name: Class GameplayAbilities.GameplayEffectExecutionCalculation
// Size: 0x40 // Inherited bytes: 0x38
struct UGameplayEffectExecutionCalculation : UGameplayEffectCalculation {
	// Fields
	bool bRequiresPassedInTags; // Offset: 0x38 // Size: 0x01
	char pad_0x39[0x7]; // Offset: 0x39 // Size: 0x07

	// Functions

	// Object Name: Function GameplayAbilities.GameplayEffectExecutionCalculation.Execute
	// Flags: [Native|Event|Public|HasOutParms|BlueprintEvent|Const]
	void Execute(struct FGameplayEffectCustomExecutionParameters& ExecutionParams, struct FGameplayEffectCustomExecutionOutput& OutExecutionOutput); // Offset: 0x10101dc3c // Return & Params: Num(2) Size(0x110)
};

// Object Name: Class GameplayAbilities.GameplayEffectUIData
// Size: 0x28 // Inherited bytes: 0x28
struct UGameplayEffectUIData : UObject {
};

// Object Name: Class GameplayAbilities.GameplayEffectUIData_TextOnly
// Size: 0x40 // Inherited bytes: 0x28
struct UGameplayEffectUIData_TextOnly : UGameplayEffectUIData {
	// Fields
	struct FText Description; // Offset: 0x28 // Size: 0x18
};

// Object Name: Class GameplayAbilities.GameplayModMagnitudeCalculation
// Size: 0x40 // Inherited bytes: 0x38
struct UGameplayModMagnitudeCalculation : UGameplayEffectCalculation {
	// Fields
	bool bAllowNonNetAuthorityDependencyRegistration; // Offset: 0x38 // Size: 0x01
	char pad_0x39[0x7]; // Offset: 0x39 // Size: 0x07

	// Functions

	// Object Name: Function GameplayAbilities.GameplayModMagnitudeCalculation.CalculateBaseMagnitude
	// Flags: [Native|Event|Public|HasOutParms|BlueprintEvent|Const]
	float CalculateBaseMagnitude(struct FGameplayEffectSpec& Spec); // Offset: 0x10101f710 // Return & Params: Num(2) Size(0x29c)
};

// Object Name: Class GameplayAbilities.GameplayTagReponseTable
// Size: 0x1e8 // Inherited bytes: 0x30
struct UGameplayTagReponseTable : UDataAsset {
	// Fields
	struct TArray<struct FGameplayTagResponseTableEntry> Entries; // Offset: 0x30 // Size: 0x10
	char pad_0x40[0x1a8]; // Offset: 0x40 // Size: 0x1a8

	// Functions

	// Object Name: Function GameplayAbilities.GameplayTagReponseTable.TagResponseEvent
	// Flags: [Final|Native|Protected]
	void TagResponseEvent(struct FGameplayTag Tag, int32_t NewCount, struct UAbilitySystemComponent* ASC, int32_t idx); // Offset: 0x10102004c // Return & Params: Num(4) Size(0x1c)
};

// Object Name: Class GameplayAbilities.TickableAttributeSetInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UTickableAttributeSetInterface : UInterface {
};

