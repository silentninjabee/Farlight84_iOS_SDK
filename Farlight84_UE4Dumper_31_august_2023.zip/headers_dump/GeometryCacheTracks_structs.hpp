#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct GeometryCacheTracks.MovieSceneGeometryCacheParams
// Size: 0x40 // Inherited bytes: 0x00
struct FMovieSceneGeometryCacheParams {
	// Fields
	struct UGeometryCache* GeometryCacheAsset; // Offset: 0x00 // Size: 0x08
	struct FFrameNumber FirstLoopStartFrameOffset; // Offset: 0x08 // Size: 0x04
	struct FFrameNumber StartFrameOffset; // Offset: 0x0c // Size: 0x04
	struct FFrameNumber EndFrameOffset; // Offset: 0x10 // Size: 0x04
	float PlayRate; // Offset: 0x14 // Size: 0x04
	char bReverse : 1; // Offset: 0x18 // Size: 0x01
	char pad_0x18_1 : 7; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x3]; // Offset: 0x19 // Size: 0x03
	float StartOffset; // Offset: 0x1c // Size: 0x04
	float EndOffset; // Offset: 0x20 // Size: 0x04
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
	struct FSoftObjectPath GeometryCache; // Offset: 0x28 // Size: 0x18
};

// Object Name: ScriptStruct GeometryCacheTracks.MovieSceneGeometryCacheSectionTemplate
// Size: 0x60 // Inherited bytes: 0x18
struct FMovieSceneGeometryCacheSectionTemplate : FMovieSceneEvalTemplate {
	// Fields
	struct FMovieSceneGeometryCacheSectionTemplateParameters Params; // Offset: 0x18 // Size: 0x48
};

// Object Name: ScriptStruct GeometryCacheTracks.MovieSceneGeometryCacheSectionTemplateParameters
// Size: 0x48 // Inherited bytes: 0x40
struct FMovieSceneGeometryCacheSectionTemplateParameters : FMovieSceneGeometryCacheParams {
	// Fields
	struct FFrameNumber SectionStartTime; // Offset: 0x40 // Size: 0x04
	struct FFrameNumber SectionEndTime; // Offset: 0x44 // Size: 0x04
};

