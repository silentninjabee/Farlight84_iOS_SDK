#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class GeometryCollectionTracks.MovieSceneGeometryCollectionSection
// Size: 0x108 // Inherited bytes: 0xd8
struct UMovieSceneGeometryCollectionSection : UMovieSceneSection {
	// Fields
	struct FMovieSceneGeometryCollectionParams Params; // Offset: 0xd8 // Size: 0x30
};

// Object Name: Class GeometryCollectionTracks.MovieSceneGeometryCollectionTrack
// Size: 0x68 // Inherited bytes: 0x58
struct UMovieSceneGeometryCollectionTrack : UMovieSceneNameableTrack {
	// Fields
	struct TArray<struct UMovieSceneSection*> AnimationSections; // Offset: 0x58 // Size: 0x10
};

