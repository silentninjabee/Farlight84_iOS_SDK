#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class GooglePAD.GooglePADFunctionLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct UGooglePADFunctionLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function GooglePAD.GooglePADFunctionLibrary.ShowCellularDataConfirmation
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	enum class EGooglePADErrorCode ShowCellularDataConfirmation(); // Offset: 0x10534a574 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function GooglePAD.GooglePADFunctionLibrary.RequestRemoval
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	enum class EGooglePADErrorCode RequestRemoval(struct FString Name); // Offset: 0x10534a5a8 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function GooglePAD.GooglePADFunctionLibrary.RequestInfo
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	enum class EGooglePADErrorCode RequestInfo(struct TArray<struct FString> AssetPacks); // Offset: 0x10534ac70 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function GooglePAD.GooglePADFunctionLibrary.RequestDownload
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	enum class EGooglePADErrorCode RequestDownload(struct TArray<struct FString> AssetPacks); // Offset: 0x10534aac0 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function GooglePAD.GooglePADFunctionLibrary.ReleaseDownloadState
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void ReleaseDownloadState(int32_t State); // Offset: 0x10534a7b4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function GooglePAD.GooglePADFunctionLibrary.ReleaseAssetPackLocation
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void ReleaseAssetPackLocation(int32_t Location); // Offset: 0x10534a38c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function GooglePAD.GooglePADFunctionLibrary.GetTotalBytesToDownload
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int32_t GetTotalBytesToDownload(int32_t State); // Offset: 0x10534a634 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function GooglePAD.GooglePADFunctionLibrary.GetStorageMethod
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	enum class EGooglePADStorageMethod GetStorageMethod(int32_t Location); // Offset: 0x10534a30c // Return & Params: Num(2) Size(0x5)

	// Object Name: Function GooglePAD.GooglePADFunctionLibrary.GetShowCellularDataConfirmationStatus
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	enum class EGooglePADErrorCode GetShowCellularDataConfirmationStatus(enum class EGooglePADCellularDataConfirmStatus& status); // Offset: 0x10534a4e8 // Return & Params: Num(2) Size(0x2)

	// Object Name: Function GooglePAD.GooglePADFunctionLibrary.GetDownloadStatus
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	enum class EGooglePADDownloadStatus GetDownloadStatus(int32_t State); // Offset: 0x10534a734 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function GooglePAD.GooglePADFunctionLibrary.GetDownloadState
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	enum class EGooglePADErrorCode GetDownloadState(struct FString Name, int32_t& State); // Offset: 0x10534a82c // Return & Params: Num(3) Size(0x15)

	// Object Name: Function GooglePAD.GooglePADFunctionLibrary.GetBytesDownloaded
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int32_t GetBytesDownloaded(int32_t State); // Offset: 0x10534a6b4 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function GooglePAD.GooglePADFunctionLibrary.GetAssetsPath
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetAssetsPath(int32_t Location); // Offset: 0x10534a248 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function GooglePAD.GooglePADFunctionLibrary.GetAssetPackLocation
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	enum class EGooglePADErrorCode GetAssetPackLocation(struct FString Name, int32_t& Location); // Offset: 0x10534a404 // Return & Params: Num(3) Size(0x15)

	// Object Name: Function GooglePAD.GooglePADFunctionLibrary.CancelDownload
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	enum class EGooglePADErrorCode CancelDownload(struct TArray<struct FString> AssetPacks); // Offset: 0x10534a910 // Return & Params: Num(2) Size(0x11)
};

