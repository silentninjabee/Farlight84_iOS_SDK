#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct IOSDeviceProfileSelector.IOSProfileMatch
// Size: 0x40 // Inherited bytes: 0x00
struct FIOSProfileMatch {
	// Fields
	struct FString Profile; // Offset: 0x00 // Size: 0x10
	struct FIOSProfileMatchItem Match; // Offset: 0x10 // Size: 0x30
};

// Object Name: ScriptStruct IOSDeviceProfileSelector.IOSProfileMatchItem
// Size: 0x30 // Inherited bytes: 0x00
struct FIOSProfileMatchItem {
	// Fields
	struct FString DeviceType; // Offset: 0x00 // Size: 0x10
	struct FString MajorString; // Offset: 0x10 // Size: 0x10
	struct FString MinorString; // Offset: 0x20 // Size: 0x10
};

