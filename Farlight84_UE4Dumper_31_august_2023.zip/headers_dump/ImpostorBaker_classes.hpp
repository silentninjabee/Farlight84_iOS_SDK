#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class ImpostorBaker.KismetImpostorBakerLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct UKismetImpostorBakerLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function ImpostorBaker.KismetImpostorBakerLibrary.ConvertProceduralToStatic
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UStaticMesh* ConvertProceduralToStatic(struct UProceduralMeshComponent* ProceduralMeshComponent, struct FName MeshName, struct FString MeshPath); // Offset: 0x101e5d510 // Return & Params: Num(4) Size(0x28)
};

