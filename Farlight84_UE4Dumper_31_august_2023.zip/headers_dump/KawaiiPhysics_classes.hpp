#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class KawaiiPhysics.KawaiiPhysicsLimitsDataAsset
// Size: 0x60 // Inherited bytes: 0x30
struct UKawaiiPhysicsLimitsDataAsset : UDataAsset {
	// Fields
	struct TArray<struct FSphericalLimit> SphericalLimits; // Offset: 0x30 // Size: 0x10
	struct TArray<struct FCapsuleLimit> CapsuleLimits; // Offset: 0x40 // Size: 0x10
	struct TArray<struct FPlanarLimit> PlanarLimits; // Offset: 0x50 // Size: 0x10
};

