#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct Landmass.LandmassBrushEffectsList
// Size: 0x60 // Inherited bytes: 0x00
struct FLandmassBrushEffectsList {
	// Fields
	struct FBrushEffectBlurring Blurring; // Offset: 0x00 // Size: 0x08
	struct FBrushEffectCurlNoise CurlNoise; // Offset: 0x08 // Size: 0x10
	struct FBrushEffectDisplacement Displacement; // Offset: 0x18 // Size: 0x28
	struct FBrushEffectSmoothBlending SmoothBlending; // Offset: 0x40 // Size: 0x08
	struct FBrushEffectTerracing Terracing; // Offset: 0x48 // Size: 0x14
	char pad_0x5C[0x4]; // Offset: 0x5c // Size: 0x04
};

// Object Name: ScriptStruct Landmass.BrushEffectTerracing
// Size: 0x14 // Inherited bytes: 0x00
struct FBrushEffectTerracing {
	// Fields
	float TerraceAlpha; // Offset: 0x00 // Size: 0x04
	float TerraceSpacing; // Offset: 0x04 // Size: 0x04
	float TerraceSmoothness; // Offset: 0x08 // Size: 0x04
	float MaskLength; // Offset: 0x0c // Size: 0x04
	float MaskStartOffset; // Offset: 0x10 // Size: 0x04
};

// Object Name: ScriptStruct Landmass.BrushEffectSmoothBlending
// Size: 0x08 // Inherited bytes: 0x00
struct FBrushEffectSmoothBlending {
	// Fields
	float InnerSmoothDistance; // Offset: 0x00 // Size: 0x04
	float OuterSmoothDistance; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct Landmass.BrushEffectDisplacement
// Size: 0x28 // Inherited bytes: 0x00
struct FBrushEffectDisplacement {
	// Fields
	float DisplacementHeight; // Offset: 0x00 // Size: 0x04
	float DisplacementTiling; // Offset: 0x04 // Size: 0x04
	struct UTexture2D* Texture; // Offset: 0x08 // Size: 0x08
	float Midpoint; // Offset: 0x10 // Size: 0x04
	struct FLinearColor Channel; // Offset: 0x14 // Size: 0x10
	float WeightmapInfluence; // Offset: 0x24 // Size: 0x04
};

// Object Name: ScriptStruct Landmass.BrushEffectCurlNoise
// Size: 0x10 // Inherited bytes: 0x00
struct FBrushEffectCurlNoise {
	// Fields
	float Curl1Amount; // Offset: 0x00 // Size: 0x04
	float Curl2Amount; // Offset: 0x04 // Size: 0x04
	float Curl1Tiling; // Offset: 0x08 // Size: 0x04
	float Curl2Tiling; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct Landmass.BrushEffectBlurring
// Size: 0x08 // Inherited bytes: 0x00
struct FBrushEffectBlurring {
	// Fields
	bool bBlurShape; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	int32_t Radius; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct Landmass.BrushEffectCurves
// Size: 0x20 // Inherited bytes: 0x00
struct FBrushEffectCurves {
	// Fields
	bool bUseCurveChannel; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct UCurveFloat* ElevationCurveAsset; // Offset: 0x08 // Size: 0x08
	float ChannelEdgeOffset; // Offset: 0x10 // Size: 0x04
	float ChannelDepth; // Offset: 0x14 // Size: 0x04
	float CurveRampWidth; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct Landmass.LandmassFalloffSettings
// Size: 0x14 // Inherited bytes: 0x00
struct FLandmassFalloffSettings {
	// Fields
	enum class EBrushFalloffMode FalloffMode; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float FalloffAngle; // Offset: 0x04 // Size: 0x04
	float FalloffWidth; // Offset: 0x08 // Size: 0x04
	float EdgeOffset; // Offset: 0x0c // Size: 0x04
	float ZOffset; // Offset: 0x10 // Size: 0x04
};

// Object Name: ScriptStruct Landmass.LandmassTerrainCarvingSettings
// Size: 0x80 // Inherited bytes: 0x00
struct FLandmassTerrainCarvingSettings {
	// Fields
	enum class EBrushBlendType BlendMode; // Offset: 0x00 // Size: 0x01
	bool bInvertShape; // Offset: 0x01 // Size: 0x01
	char pad_0x2[0x2]; // Offset: 0x02 // Size: 0x02
	struct FLandmassFalloffSettings FalloffSettings; // Offset: 0x04 // Size: 0x14
	struct FLandmassBrushEffectsList Effects; // Offset: 0x18 // Size: 0x60
	int32_t Priority; // Offset: 0x78 // Size: 0x04
	char pad_0x7C[0x4]; // Offset: 0x7c // Size: 0x04
};

