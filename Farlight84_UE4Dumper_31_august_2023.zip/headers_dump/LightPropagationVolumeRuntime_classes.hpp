#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class LightPropagationVolumeRuntime.LightPropagationVolumeBlendable
// Size: 0x78 // Inherited bytes: 0x28
struct ULightPropagationVolumeBlendable : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08
	struct FLightPropagationVolumeSettings Settings; // Offset: 0x30 // Size: 0x40
	float BlendWeight; // Offset: 0x70 // Size: 0x04
	char pad_0x74[0x4]; // Offset: 0x74 // Size: 0x04
};

