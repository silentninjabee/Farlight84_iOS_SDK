#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct LimNativeWidget.ChatGMEDataResult
// Size: 0x28 // Inherited bytes: 0x00
struct FChatGMEDataResult {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
	bool bSuccess; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x7]; // Offset: 0x09 // Size: 0x07
	struct FString ErrorInfo; // Offset: 0x10 // Size: 0x10
	int32_t ErrorCode; // Offset: 0x20 // Size: 0x04
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
};

// Object Name: ScriptStruct LimNativeWidget.ChatGMEDataDeviceInfo
// Size: 0x50 // Inherited bytes: 0x28
struct FChatGMEDataDeviceInfo : FChatGMEDataResult {
	// Fields
	struct FString DeviceID; // Offset: 0x28 // Size: 0x10
	struct FString DeviceName; // Offset: 0x38 // Size: 0x10
	bool bNewDevice; // Offset: 0x48 // Size: 0x01
	bool bUsedDevice; // Offset: 0x49 // Size: 0x01
	char pad_0x4A[0x6]; // Offset: 0x4a // Size: 0x06
};

// Object Name: ScriptStruct LimNativeWidget.ChatGMEDataRoomQuality
// Size: 0x18 // Inherited bytes: 0x00
struct FChatGMEDataRoomQuality {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
	int32_t Weight; // Offset: 0x08 // Size: 0x04
	float Loss; // Offset: 0x0c // Size: 0x04
	int32_t Delay; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct LimNativeWidget.ChatGMEDataChangeRoomType
// Size: 0x28 // Inherited bytes: 0x28
struct FChatGMEDataChangeRoomType : FChatGMEDataResult {
	// Fields
	enum class EChatGMERoomTypeSubEvent NewRoomType; // Offset: 0x24 // Size: 0x01
};

// Object Name: ScriptStruct LimNativeWidget.ChatGMEDataFileInfo
// Size: 0x58 // Inherited bytes: 0x28
struct FChatGMEDataFileInfo : FChatGMEDataResult {
	// Fields
	struct FString FileID; // Offset: 0x28 // Size: 0x10
	struct FString FilePath; // Offset: 0x38 // Size: 0x10
	struct FString Text; // Offset: 0x48 // Size: 0x10
};

// Object Name: ScriptStruct LimNativeWidget.ChatGMEDataNumberOfAudioStreamsUpdate
// Size: 0x10 // Inherited bytes: 0x00
struct FChatGMEDataNumberOfAudioStreamsUpdate {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
	int32_t AudioStreamsNum; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct LimNativeWidget.ChatGMEDataNumberOfUserUpdate
// Size: 0x18 // Inherited bytes: 0x00
struct FChatGMEDataNumberOfUserUpdate {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
	int32_t AllUserNum; // Offset: 0x08 // Size: 0x04
	int32_t AccUserNum; // Offset: 0x0c // Size: 0x04
	int32_t ProxyUserNum; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct LimNativeWidget.ChatGMEDataRecordCompleted
// Size: 0x48 // Inherited bytes: 0x28
struct FChatGMEDataRecordCompleted : FChatGMEDataResult {
	// Fields
	struct FString FilePath; // Offset: 0x28 // Size: 0x10
	struct FString Duration; // Offset: 0x38 // Size: 0x10
};

// Object Name: ScriptStruct LimNativeWidget.ChatGMEDataRoomOperator
// Size: 0x50 // Inherited bytes: 0x28
struct FChatGMEDataRoomOperator : FChatGMEDataResult {
	// Fields
	struct FString SenderId; // Offset: 0x28 // Size: 0x10
	struct FString ReceiverId; // Offset: 0x38 // Size: 0x10
	enum class EChatGMERoomManagementOp OperateType; // Offset: 0x48 // Size: 0x01
	bool bOpenCmd; // Offset: 0x49 // Size: 0x01
	char pad_0x4A[0x6]; // Offset: 0x4a // Size: 0x06
};

// Object Name: ScriptStruct LimNativeWidget.ChatGMEDataUserUpdate
// Size: 0x20 // Inherited bytes: 0x00
struct FChatGMEDataUserUpdate {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
	enum class EChatGMEEventIDUserUpdate EventId; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x7]; // Offset: 0x09 // Size: 0x07
	struct TArray<struct FString> UserList; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct LimNativeWidget.ChatGMEDataUserVolumes
// Size: 0x58 // Inherited bytes: 0x00
struct FChatGMEDataUserVolumes {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
	struct TMap<struct FString, float> Volumes; // Offset: 0x08 // Size: 0x50
};

// Object Name: ScriptStruct LimNativeWidget.ChatListConvData
// Size: 0x18 // Inherited bytes: 0x00
struct FChatListConvData {
	// Fields
	struct FString ConvID; // Offset: 0x00 // Size: 0x10
	enum class ELimNativeConvType ConvType; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x7]; // Offset: 0x11 // Size: 0x07
};

// Object Name: ScriptStruct LimNativeWidget.ChatListUserData
// Size: 0x50 // Inherited bytes: 0x00
struct FChatListUserData {
	// Fields
	struct FString Uid; // Offset: 0x00 // Size: 0x10
	struct FString NickName; // Offset: 0x10 // Size: 0x10
	struct FString AvatarUrl; // Offset: 0x20 // Size: 0x10
	struct FString AvatarFrameUrl; // Offset: 0x30 // Size: 0x10
	enum class ELimNativeUserSexType Sex; // Offset: 0x40 // Size: 0x01
	char pad_0x41[0x3]; // Offset: 0x41 // Size: 0x03
	int32_t VipLevel; // Offset: 0x44 // Size: 0x04
	bool IsShowVip; // Offset: 0x48 // Size: 0x01
	enum class ELimNativeFriendStateType OnlineState; // Offset: 0x49 // Size: 0x01
	char pad_0x4A[0x6]; // Offset: 0x4a // Size: 0x06
};

// Object Name: ScriptStruct LimNativeWidget.NewChatListMessageData
// Size: 0x178 // Inherited bytes: 0x00
struct FNewChatListMessageData {
	// Fields
	struct FString SendId; // Offset: 0x00 // Size: 0x10
	struct FString MsgId; // Offset: 0x10 // Size: 0x10
	enum class ELimNativeMsgState MsgState; // Offset: 0x20 // Size: 0x01
	char pad_0x21[0x7]; // Offset: 0x21 // Size: 0x07
	struct FString MsgContent; // Offset: 0x28 // Size: 0x10
	struct FString UUID; // Offset: 0x38 // Size: 0x10
	struct FString URL; // Offset: 0x48 // Size: 0x10
	struct FString Size; // Offset: 0x58 // Size: 0x10
	int32_t Duration; // Offset: 0x68 // Size: 0x04
	char pad_0x6C[0x4]; // Offset: 0x6c // Size: 0x04
	struct FString Ext; // Offset: 0x70 // Size: 0x10
	enum class ELimNativeMsgContentType MsgType; // Offset: 0x80 // Size: 0x01
	char pad_0x81[0x7]; // Offset: 0x81 // Size: 0x07
	struct FString ConvID; // Offset: 0x88 // Size: 0x10
	enum class ELimNativeConvType ConvType; // Offset: 0x98 // Size: 0x01
	char pad_0x99[0x7]; // Offset: 0x99 // Size: 0x07
	struct FString Timestamp; // Offset: 0xa0 // Size: 0x10
	struct FLimNativeIMChatMessage MsgData; // Offset: 0xb0 // Size: 0x70
	struct FLimNativeIMChatMessageBase MsgBase; // Offset: 0x120 // Size: 0x58
};

// Object Name: ScriptStruct LimNativeWidget.ChatListMessageData
// Size: 0x98 // Inherited bytes: 0x00
struct FChatListMessageData {
	// Fields
	struct FString SendId; // Offset: 0x00 // Size: 0x10
	struct FString MsgId; // Offset: 0x10 // Size: 0x10
	enum class ELimNativeMsgState MsgState; // Offset: 0x20 // Size: 0x01
	char pad_0x21[0x7]; // Offset: 0x21 // Size: 0x07
	struct FLimNativeIMChatMessage MsgData; // Offset: 0x28 // Size: 0x70
};

// Object Name: ScriptStruct LimNativeWidget.NertcUserUpdateData
// Size: 0x10 // Inherited bytes: 0x00
struct FNertcUserUpdateData {
	// Fields
	struct TArray<struct FString> UserList; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct LimNativeWidget.ChatLogicMessageData
// Size: 0x10 // Inherited bytes: 0x00
struct FChatLogicMessageData {
	// Fields
	int32_t Type; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FLimNativeDataObjectBase BizObj; // Offset: 0x08 // Size: 0x08
};

