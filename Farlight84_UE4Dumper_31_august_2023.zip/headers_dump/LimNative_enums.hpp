#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum LimNative.ELimNativeConvType
enum class ELimNativeConvType : uint8 {
	Group = 0,
	Peer = 1,
	Room = 2,
	CustomGroup = 3,
	Robot = 4,
	System = 5,
	TempGroup = 6,
	ELimNativeConvType_MAX = 7
};

// Object Name: Enum LimNative.ELimNativeMsgDirType
enum class ELimNativeMsgDirType : uint8 {
	After = 0,
	Around = 1,
	Before = 2,
	ELimNativeMsgDirType_MAX = 3
};

// Object Name: Enum LimNative.ELimNativeSupportedLanguage
enum class ELimNativeSupportedLanguage : uint8 {
	DefaultLanguage = 0,
	SimplifiedChinese = 1,
	TraditionalChinese = 2,
	Arabic = 3,
	German = 4,
	English = 5,
	Spanish = 6,
	French = 7,
	Hindi = 8,
	Indonesian = 9,
	Italian = 10,
	Japanese = 11,
	Korean = 12,
	Malay = 13,
	Polish = 14,
	Portuguese = 15,
	Russian = 16,
	Thai = 17,
	Turkish = 18,
	Vietnamese = 19,
	Tagalog = 20,
	PO = 21,
	OP = 22,
	ELimNativeSupportedLanguage_MAX = 23
};

// Object Name: Enum LimNative.ELimNativeErrorType
enum class ELimNativeErrorType : uint8 {
	OK = 0,
	ApiNotFound = 1,
	ParameterInvalid = 2,
	NetworkError = 3,
	InitializeError = 4,
	ResourceNotFound = 5,
	ApiTimeout = 6,
	LoginFailed = 7,
	MsgSendFailed = 8,
	MsgSendTimeout = 9,
	MsgBuildFailed = 10,
	MsgSetStateFailed = 11,
	ConvsGetFailed = 12,
	ConvDiscardFailed = 13,
	UnImplemented = 14,
	Exception = 15,
	UserInfoGetFailed = 16,
	JsonDecodeFailed = 17,
	Unknown = 18,
	ELimNativeErrorType_MAX = 19
};

// Object Name: Enum LimNative.ELimNativeMsgContentType
enum class ELimNativeMsgContentType : uint8 {
	Unknown = 0,
	Text = 1,
	Voice = 2,
	Image = 3,
	Notification = 4,
	ShareGameCard = 5,
	CustomEmotion = 6,
	Recalled = 7,
	ELimNativeMsgContentType_MAX = 8
};

// Object Name: Enum LimNative.ELimNativeFriendStateType
enum class ELimNativeFriendStateType : uint8 {
	InIdle = 0,
	InTeam = 1,
	InMatching = 2,
	InGaming = 3,
	Offline = 4,
	ELimNativeFriendStateType_MAX = 5
};

// Object Name: Enum LimNative.ELimNativeUserSexType
enum class ELimNativeUserSexType : uint8 {
	Unknow = 0,
	Male = 1,
	FeMale = 2,
	ELimNativeUserSexType_MAX = 3
};

// Object Name: Enum LimNative.ELimNativeMsgState
enum class ELimNativeMsgState : uint8 {
	Created = 0,
	Sending = 1,
	Sent = 2,
	Failed = 3,
	Unread = 4,
	Read = 5,
	ReadAll = 6,
	Played = 7,
	Revoked = 8,
	ELimNativeMsgState_MAX = 9
};

// Object Name: Enum LimNative.ELimNativePackType
enum class ELimNativePackType : uint8 {
	StaticPicture = 0,
	DynamicPicture = 1,
	ELimNativePackType_MAX = 2
};

// Object Name: Enum LimNative.ELimNativeOSType
enum class ELimNativeOSType : uint8 {
	Android = 0,
	iOS = 1,
	Windows = 2,
	ELimNativeOSType_MAX = 3
};

// Object Name: Enum LimNative.ELimNativeUserPeerStatus
enum class ELimNativeUserPeerStatus : uint8 {
	Online = 0,
	Blocking = 1,
	Blocked = 2,
	ELimNativeUserPeerStatus_MAX = 3
};

// Object Name: Enum LimNative.ELimNativeUserAllowType
enum class ELimNativeUserAllowType : uint8 {
	Any = 0,
	Confirm = 1,
	None = 2,
	ELimNativeUserAllowType_MAX = 3
};

// Object Name: Enum LimNative.ELimNativeProtType
enum class ELimNativeProtType : uint8 {
	Game = 0,
	App = 1,
	ELimNativeProtType_MAX = 2
};

// Object Name: Enum LimNative.ELimNativeGroupRoleType
enum class ELimNativeGroupRoleType : uint8 {
	Owner = 0,
	Admin = 1,
	Member = 2,
	ELimNativeGroupRoleType_MAX = 3
};

// Object Name: Enum LimNative.ELimNativeGroupJoinType
enum class ELimNativeGroupJoinType : uint8 {
	Free = 0,
	Verify = 1,
	Forbidden = 2,
	ELimNativeGroupJoinType_MAX = 3
};

// Object Name: Enum LimNative.ELimNativeGroupType
enum class ELimNativeGroupType : uint8 {
	Normal = 0,
	Temp = 1,
	Room = 2,
	Custom = 3,
	ELimNativeGroupType_MAX = 4
};

// Object Name: Enum LimNative.ELimNativeEventType
enum class ELimNativeEventType : uint8 {
	SDKReady = 0,
	SDKError = 1,
	NetDisconnected = 2,
	NetConnecting = 3,
	NetConnected = 4,
	NetReconnected = 5,
	NetReconnecting = 6,
	NetInterrupt = 7,
	TokenRenewed = 8,
	TokenExpired = 9,
	KickedOut = 10,
	LoginFreqLimit = 11,
	Logining = 12,
	Logined = 13,
	MsgReceived = 14,
	MsgRevoked = 15,
	MsgRead = 16,
	MsgEdited = 17,
	MsgLogicReceived = 18,
	MsgCaptTriggerred = 19,
	MsgCaptDispose = 20,
	ConvsUpdated = 21,
	FriendChanged = 22,
	FriendRequestChanged = 23,
	BlockeeChanged = 24,
	BadgesChanged = 25,
	UnkownEvent = 26,
	ELimNativeEventType_MAX = 27
};

// Object Name: Enum LimNative.ELimNativeConvMentionType
enum class ELimNativeConvMentionType : uint8 {
	AtMe = 0,
	AtAll = 1,
	AtAllMe = 2,
	ELimNativeConvMentionType_MAX = 3
};

