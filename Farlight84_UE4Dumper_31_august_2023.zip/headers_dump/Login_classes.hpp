#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass Login.Login_C
// Size: 0x230 // Inherited bytes: 0x230
struct ALogin_C : ALevelScriptActor {
	// Functions

	// Object Name: Function Login.Login_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	struct FString GetModuleName(); // Offset: 0x1032ea4b8 // Return & Params: Num(1) Size(0x10)
};

