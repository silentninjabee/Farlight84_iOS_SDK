#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class MediaCompositing.MovieSceneMediaPlayerPropertySection
// Size: 0xe8 // Inherited bytes: 0xd8
struct UMovieSceneMediaPlayerPropertySection : UMovieSceneSection {
	// Fields
	struct UMediaSource* MediaSource; // Offset: 0xd8 // Size: 0x08
	bool bLoop; // Offset: 0xe0 // Size: 0x01
	char pad_0xE1[0x7]; // Offset: 0xe1 // Size: 0x07
};

// Object Name: Class MediaCompositing.MovieSceneMediaPlayerPropertyTrack
// Size: 0x88 // Inherited bytes: 0x88
struct UMovieSceneMediaPlayerPropertyTrack : UMovieScenePropertyTrack {
};

// Object Name: Class MediaCompositing.MovieSceneMediaSection
// Size: 0x108 // Inherited bytes: 0xd8
struct UMovieSceneMediaSection : UMovieSceneSection {
	// Fields
	struct UMediaSource* MediaSource; // Offset: 0xd8 // Size: 0x08
	bool bLooping; // Offset: 0xe0 // Size: 0x01
	char pad_0xE1[0x3]; // Offset: 0xe1 // Size: 0x03
	struct FFrameNumber StartFrameOffset; // Offset: 0xe4 // Size: 0x04
	struct UMediaTexture* MediaTexture; // Offset: 0xe8 // Size: 0x08
	struct UMediaSoundComponent* MediaSoundComponent; // Offset: 0xf0 // Size: 0x08
	bool bUseExternalMediaPlayer; // Offset: 0xf8 // Size: 0x01
	char pad_0xF9[0x7]; // Offset: 0xf9 // Size: 0x07
	struct UMediaPlayer* ExternalMediaPlayer; // Offset: 0x100 // Size: 0x08
};

// Object Name: Class MediaCompositing.MovieSceneMediaTrack
// Size: 0x68 // Inherited bytes: 0x58
struct UMovieSceneMediaTrack : UMovieSceneNameableTrack {
	// Fields
	struct TArray<struct UMovieSceneSection*> MediaSections; // Offset: 0x58 // Size: 0x10
};

