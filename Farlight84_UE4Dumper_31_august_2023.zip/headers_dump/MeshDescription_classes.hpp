#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class MeshDescription.MeshDescription
// Size: 0x28 // Inherited bytes: 0x28
struct UMeshDescription : UObject {
};

// Object Name: Class MeshDescription.MeshDescriptionBase
// Size: 0x390 // Inherited bytes: 0x28
struct UMeshDescriptionBase : UObject {
	// Fields
	char pad_0x28[0x368]; // Offset: 0x28 // Size: 0x368

	// Functions

	// Object Name: Function MeshDescription.MeshDescriptionBase.SetVertexPosition
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void SetVertexPosition(struct FVertexID VertexID, struct FVector& Position); // Offset: 0x10441e174 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function MeshDescription.MeshDescriptionBase.SetPolygonVertexInstance
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPolygonVertexInstance(struct FPolygonID PolygonID, int32_t PerimeterIndex, struct FVertexInstanceID VertexInstanceID); // Offset: 0x10441c4c0 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function MeshDescription.MeshDescriptionBase.SetPolygonPolygonGroup
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPolygonPolygonGroup(struct FPolygonID PolygonID, struct FPolygonGroupID PolygonGroupID); // Offset: 0x10441c3d8 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function MeshDescription.MeshDescriptionBase.ReversePolygonFacing
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ReversePolygonFacing(struct FPolygonID PolygonID); // Offset: 0x10441c34c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MeshDescription.MeshDescriptionBase.ReserveNewVertices
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ReserveNewVertices(int32_t NumberOfNewVertices); // Offset: 0x104420354 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MeshDescription.MeshDescriptionBase.ReserveNewVertexInstances
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ReserveNewVertexInstances(int32_t NumberOfNewVertexInstances); // Offset: 0x1044200ec // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MeshDescription.MeshDescriptionBase.ReserveNewTriangles
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ReserveNewTriangles(int32_t NumberOfNewTriangles); // Offset: 0x10441f924 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MeshDescription.MeshDescriptionBase.ReserveNewPolygons
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ReserveNewPolygons(int32_t NumberOfNewPolygons); // Offset: 0x10441f354 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MeshDescription.MeshDescriptionBase.ReserveNewPolygonGroups
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ReserveNewPolygonGroups(int32_t NumberOfNewPolygonGroups); // Offset: 0x10441ed84 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MeshDescription.MeshDescriptionBase.ReserveNewEdges
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ReserveNewEdges(int32_t NumberOfNewEdges); // Offset: 0x10441fd5c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MeshDescription.MeshDescriptionBase.IsVertexValid
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsVertexValid(struct FVertexID VertexID); // Offset: 0x10442016c // Return & Params: Num(2) Size(0x5)

	// Object Name: Function MeshDescription.MeshDescriptionBase.IsVertexOrphaned
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsVertexOrphaned(struct FVertexID VertexID); // Offset: 0x10441eb00 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function MeshDescription.MeshDescriptionBase.IsVertexInstanceValid
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsVertexInstanceValid(struct FVertexInstanceID VertexInstanceID); // Offset: 0x10441fddc // Return & Params: Num(2) Size(0x5)

	// Object Name: Function MeshDescription.MeshDescriptionBase.IsTriangleValid
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsTriangleValid(struct FTriangleID TriangleID); // Offset: 0x10441f3d4 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function MeshDescription.MeshDescriptionBase.IsTrianglePartOfNgon
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsTrianglePartOfNgon(struct FTriangleID TriangleID); // Offset: 0x10441d484 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function MeshDescription.MeshDescriptionBase.IsPolygonValid
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsPolygonValid(struct FPolygonID PolygonID); // Offset: 0x10441ee04 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function MeshDescription.MeshDescriptionBase.IsPolygonGroupValid
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsPolygonGroupValid(struct FPolygonGroupID PolygonGroupID); // Offset: 0x10441eb9c // Return & Params: Num(2) Size(0x5)

	// Object Name: Function MeshDescription.MeshDescriptionBase.IsEmpty
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsEmpty(); // Offset: 0x1044203d4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function MeshDescription.MeshDescriptionBase.IsEdgeValid
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsEdgeValid(struct FEdgeID EdgeID); // Offset: 0x10441f9a4 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function MeshDescription.MeshDescriptionBase.IsEdgeInternalToPolygon
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsEdgeInternalToPolygon(struct FEdgeID EdgeID, struct FPolygonID PolygonID); // Offset: 0x10441db44 // Return & Params: Num(3) Size(0x9)

	// Object Name: Function MeshDescription.MeshDescriptionBase.IsEdgeInternal
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsEdgeInternal(struct FEdgeID EdgeID); // Offset: 0x10441dc34 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetVertexVertexInstances
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetVertexVertexInstances(struct FVertexID VertexID, struct TArray<struct FVertexInstanceID>& OutVertexInstanceIDs); // Offset: 0x10441e794 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetVertexPosition
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FVector GetVertexPosition(struct FVertexID VertexID); // Offset: 0x10441e250 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetVertexPairEdge
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FEdgeID GetVertexPairEdge(struct FVertexID VertexID0, struct FVertexID VertexID1); // Offset: 0x10441ea10 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetVertexInstanceVertex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FVertexID GetVertexInstanceVertex(struct FVertexInstanceID VertexInstanceID); // Offset: 0x10441e0d8 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetVertexInstancePairEdge
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FEdgeID GetVertexInstancePairEdge(struct FVertexInstanceID VertexInstanceID0, struct FVertexInstanceID VertexInstanceID1); // Offset: 0x10441dfe8 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetVertexInstanceForTriangleVertex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FVertexInstanceID GetVertexInstanceForTriangleVertex(struct FTriangleID TriangleID, struct FVertexID VertexID); // Offset: 0x10441cef0 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetVertexInstanceForPolygonVertex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FVertexInstanceID GetVertexInstanceForPolygonVertex(struct FPolygonID PolygonID, struct FVertexID VertexID); // Offset: 0x10441c5f0 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetVertexInstanceConnectedTriangles
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetVertexInstanceConnectedTriangles(struct FVertexInstanceID VertexInstanceID, struct TArray<struct FTriangleID>& OutConnectedTriangleIDs); // Offset: 0x10441def8 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetVertexInstanceConnectedPolygons
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetVertexInstanceConnectedPolygons(struct FVertexInstanceID VertexInstanceID, struct TArray<struct FPolygonID>& OutConnectedPolygonIDs); // Offset: 0x10441dd6c // Return & Params: Num(2) Size(0x18)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetVertexConnectedTriangles
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetVertexConnectedTriangles(struct FVertexID VertexID, struct TArray<struct FTriangleID>& OutConnectedTriangleIDs); // Offset: 0x10441e608 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetVertexConnectedPolygons
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetVertexConnectedPolygons(struct FVertexID VertexID, struct TArray<struct FPolygonID>& OutConnectedPolygonIDs); // Offset: 0x10441e47c // Return & Params: Num(2) Size(0x18)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetVertexConnectedEdges
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetVertexConnectedEdges(struct FVertexID VertexID, struct TArray<struct FEdgeID>& OutEdgeIDs); // Offset: 0x10441e920 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetVertexAdjacentVertices
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetVertexAdjacentVertices(struct FVertexID VertexID, struct TArray<struct FVertexID>& OutAdjacentVertexIDs); // Offset: 0x10441e2f0 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetTriangleVertices
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetTriangleVertices(struct FTriangleID TriangleID, struct TArray<struct FVertexID>& OutVertexIDs); // Offset: 0x10441d1c0 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetTriangleVertexInstances
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetTriangleVertexInstances(struct FTriangleID TriangleID, struct TArray<struct FVertexInstanceID>& OutVertexInstanceIDs); // Offset: 0x10441d394 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetTriangleVertexInstance
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FVertexInstanceID GetTriangleVertexInstance(struct FTriangleID TriangleID, int32_t Index); // Offset: 0x10441d2b0 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetTrianglePolygonGroup
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FPolygonGroupID GetTrianglePolygonGroup(struct FTriangleID TriangleID); // Offset: 0x10441d520 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetTrianglePolygon
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FPolygonID GetTrianglePolygon(struct FTriangleID TriangleID); // Offset: 0x10441d5bc // Return & Params: Num(2) Size(0x8)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetTriangleEdges
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetTriangleEdges(struct FTriangleID TriangleID, struct TArray<struct FEdgeID>& OutEdgeIDs); // Offset: 0x10441d0d0 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetTriangleAdjacentTriangles
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetTriangleAdjacentTriangles(struct FTriangleID TriangleID, struct TArray<struct FTriangleID>& OutTriangleIDs); // Offset: 0x10441cfe0 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetPolygonVertices
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetPolygonVertices(struct FPolygonID PolygonID, struct TArray<struct FVertexID>& OutVertexIDs); // Offset: 0x10441cae8 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetPolygonVertexInstances
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetPolygonVertexInstances(struct FPolygonID PolygonID, struct TArray<struct FVertexInstanceID>& OutVertexInstanceIDs); // Offset: 0x10441cc74 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetPolygonTriangles
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetPolygonTriangles(struct FPolygonID PolygonID, struct TArray<struct FTriangleID>& OutTriangleIDs); // Offset: 0x10441ce00 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetPolygonPolygonGroup
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FPolygonGroupID GetPolygonPolygonGroup(struct FPolygonID PolygonID); // Offset: 0x10441c6e0 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetPolygonPerimeterEdges
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetPolygonPerimeterEdges(struct FPolygonID PolygonID, struct TArray<struct FEdgeID>& OutEdgeIDs); // Offset: 0x10441c9f8 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetPolygonInternalEdges
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetPolygonInternalEdges(struct FPolygonID PolygonID, struct TArray<struct FEdgeID>& OutEdgeIDs); // Offset: 0x10441c908 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetPolygonGroupPolygons
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetPolygonGroupPolygons(struct FPolygonGroupID PolygonGroupID, struct TArray<struct FPolygonID>& OutPolygonIDs); // Offset: 0x10441c1d0 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetPolygonAdjacentPolygons
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetPolygonAdjacentPolygons(struct FPolygonID PolygonID, struct TArray<struct FPolygonID>& OutPolygonIDs); // Offset: 0x10441c77c // Return & Params: Num(2) Size(0x18)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetNumVertexVertexInstances
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetNumVertexVertexInstances(struct FVertexID VertexID); // Offset: 0x10441e6f8 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetNumVertexInstanceConnectedTriangles
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetNumVertexInstanceConnectedTriangles(struct FVertexInstanceID VertexInstanceID); // Offset: 0x10441de5c // Return & Params: Num(2) Size(0x8)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetNumVertexInstanceConnectedPolygons
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetNumVertexInstanceConnectedPolygons(struct FVertexInstanceID VertexInstanceID); // Offset: 0x10441dcd0 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetNumVertexConnectedTriangles
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetNumVertexConnectedTriangles(struct FVertexID VertexID); // Offset: 0x10441e56c // Return & Params: Num(2) Size(0x8)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetNumVertexConnectedPolygons
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetNumVertexConnectedPolygons(struct FVertexID VertexID); // Offset: 0x10441e3e0 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetNumVertexConnectedEdges
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetNumVertexConnectedEdges(struct FVertexID VertexID); // Offset: 0x10441e884 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetNumPolygonVertices
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetNumPolygonVertices(struct FPolygonID PolygonID); // Offset: 0x10441cbd8 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetNumPolygonTriangles
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetNumPolygonTriangles(struct FPolygonID PolygonID); // Offset: 0x10441cd64 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetNumPolygonInternalEdges
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetNumPolygonInternalEdges(struct FPolygonID PolygonID); // Offset: 0x10441c86c // Return & Params: Num(2) Size(0x8)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetNumPolygonGroupPolygons
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetNumPolygonGroupPolygons(struct FPolygonGroupID PolygonGroupID); // Offset: 0x10441c134 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetNumEdgeConnectedTriangles
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetNumEdgeConnectedTriangles(struct FEdgeID EdgeID); // Offset: 0x10441d9b8 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetNumEdgeConnectedPolygons
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetNumEdgeConnectedPolygons(struct FEdgeID EdgeID); // Offset: 0x10441d82c // Return & Params: Num(2) Size(0x8)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetEdgeVertices
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetEdgeVertices(struct FEdgeID EdgeID, struct TArray<struct FVertexID>& OutVertexIDs); // Offset: 0x10441d658 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetEdgeVertex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FVertexID GetEdgeVertex(struct FEdgeID EdgeID, int32_t VertexNumber); // Offset: 0x10441d748 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetEdgeConnectedTriangles
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetEdgeConnectedTriangles(struct FEdgeID EdgeID, struct TArray<struct FTriangleID>& OutConnectedTriangleIDs); // Offset: 0x10441da54 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function MeshDescription.MeshDescriptionBase.GetEdgeConnectedPolygons
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetEdgeConnectedPolygons(struct FEdgeID EdgeID, struct TArray<struct FPolygonID>& OutConnectedPolygonIDs); // Offset: 0x10441d8c8 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function MeshDescription.MeshDescriptionBase.Empty
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Empty(); // Offset: 0x104420408 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function MeshDescription.MeshDescriptionBase.DeleteVertexInstance
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void DeleteVertexInstance(struct FVertexInstanceID VertexInstanceID, struct TArray<struct FVertexID>& OrphanedVertices); // Offset: 0x10441fe78 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function MeshDescription.MeshDescriptionBase.DeleteVertex
	// Flags: [Final|Native|Public|BlueprintCallable]
	void DeleteVertex(struct FVertexID VertexID); // Offset: 0x104420208 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MeshDescription.MeshDescriptionBase.DeleteTriangle
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void DeleteTriangle(struct FTriangleID TriangleID, struct TArray<struct FEdgeID>& OrphanedEdges, struct TArray<struct FVertexInstanceID>& OrphanedVertexInstances, struct TArray<struct FPolygonGroupID>& OrphanedPolygonGroupsPtr); // Offset: 0x10441f470 // Return & Params: Num(4) Size(0x38)

	// Object Name: Function MeshDescription.MeshDescriptionBase.DeletePolygonGroup
	// Flags: [Final|Native|Public|BlueprintCallable]
	void DeletePolygonGroup(struct FPolygonGroupID PolygonGroupID); // Offset: 0x10441ec38 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MeshDescription.MeshDescriptionBase.DeletePolygon
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void DeletePolygon(struct FPolygonID PolygonID, struct TArray<struct FEdgeID>& OrphanedEdges, struct TArray<struct FVertexInstanceID>& OrphanedVertexInstances, struct TArray<struct FPolygonGroupID>& OrphanedPolygonGroups); // Offset: 0x10441eea0 // Return & Params: Num(4) Size(0x38)

	// Object Name: Function MeshDescription.MeshDescriptionBase.DeleteEdge
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void DeleteEdge(struct FEdgeID EdgeID, struct TArray<struct FVertexID>& OrphanedVertices); // Offset: 0x10441fa40 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function MeshDescription.MeshDescriptionBase.CreateVertexWithID
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CreateVertexWithID(struct FVertexID VertexID); // Offset: 0x104420294 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MeshDescription.MeshDescriptionBase.CreateVertexInstanceWithID
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CreateVertexInstanceWithID(struct FVertexInstanceID VertexInstanceID, struct FVertexID VertexID); // Offset: 0x10441ff68 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function MeshDescription.MeshDescriptionBase.CreateVertexInstance
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FVertexInstanceID CreateVertexInstance(struct FVertexID VertexID); // Offset: 0x104420050 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function MeshDescription.MeshDescriptionBase.CreateVertex
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FVertexID CreateVertex(); // Offset: 0x104420320 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MeshDescription.MeshDescriptionBase.CreateTriangleWithID
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void CreateTriangleWithID(struct FTriangleID TriangleID, struct FPolygonGroupID PolygonGroupID, struct TArray<struct FVertexInstanceID>& VertexInstanceIDs, struct TArray<struct FEdgeID>& NewEdgeIDs); // Offset: 0x10441f620 // Return & Params: Num(4) Size(0x28)

	// Object Name: Function MeshDescription.MeshDescriptionBase.CreateTriangle
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	struct FTriangleID CreateTriangle(struct FPolygonGroupID PolygonGroupID, struct TArray<struct FVertexInstanceID>& VertexInstanceIDs, struct TArray<struct FEdgeID>& NewEdgeIDs); // Offset: 0x10441f7c8 // Return & Params: Num(4) Size(0x2c)

	// Object Name: Function MeshDescription.MeshDescriptionBase.CreatePolygonWithID
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void CreatePolygonWithID(struct FPolygonID PolygonID, struct FPolygonGroupID PolygonGroupID, struct TArray<struct FVertexInstanceID>& VertexInstanceIDs, struct TArray<struct FEdgeID>& NewEdgeIDs); // Offset: 0x10441f050 // Return & Params: Num(4) Size(0x28)

	// Object Name: Function MeshDescription.MeshDescriptionBase.CreatePolygonGroupWithID
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CreatePolygonGroupWithID(struct FPolygonGroupID PolygonGroupID); // Offset: 0x10441ecc4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MeshDescription.MeshDescriptionBase.CreatePolygonGroup
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FPolygonGroupID CreatePolygonGroup(); // Offset: 0x10441ed50 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MeshDescription.MeshDescriptionBase.CreatePolygon
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	struct FPolygonID CreatePolygon(struct FPolygonGroupID PolygonGroupID, struct TArray<struct FVertexInstanceID>& VertexInstanceIDs, struct TArray<struct FEdgeID>& NewEdgeIDs); // Offset: 0x10441f1f8 // Return & Params: Num(4) Size(0x2c)

	// Object Name: Function MeshDescription.MeshDescriptionBase.CreateEdgeWithID
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CreateEdgeWithID(struct FEdgeID EdgeID, struct FVertexID VertexID0, struct FVertexID VertexID1); // Offset: 0x10441fb30 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function MeshDescription.MeshDescriptionBase.CreateEdge
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FEdgeID CreateEdge(struct FVertexID VertexID0, struct FVertexID VertexID1); // Offset: 0x10441fc6c // Return & Params: Num(3) Size(0xc)

	// Object Name: Function MeshDescription.MeshDescriptionBase.ComputePolygonTriangulation
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ComputePolygonTriangulation(struct FPolygonID PolygonID); // Offset: 0x10441c2c0 // Return & Params: Num(1) Size(0x4)
};

