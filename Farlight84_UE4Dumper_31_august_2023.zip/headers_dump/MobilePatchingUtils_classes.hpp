#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class MobilePatchingUtils.MobileInstalledContent
// Size: 0x48 // Inherited bytes: 0x28
struct UMobileInstalledContent : UObject {
	// Fields
	char pad_0x28[0x20]; // Offset: 0x28 // Size: 0x20

	// Functions

	// Object Name: Function MobilePatchingUtils.MobileInstalledContent.Mount
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool Mount(int32_t PakOrder, struct FString MountPoint); // Offset: 0x101fe20bc // Return & Params: Num(3) Size(0x19)

	// Object Name: Function MobilePatchingUtils.MobileInstalledContent.GetInstalledContentSize
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	float GetInstalledContentSize(); // Offset: 0x101fe21a4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MobilePatchingUtils.MobileInstalledContent.GetDiskFreeSpace
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	float GetDiskFreeSpace(); // Offset: 0x101fe21d8 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class MobilePatchingUtils.MobilePendingContent
// Size: 0x88 // Inherited bytes: 0x48
struct UMobilePendingContent : UMobileInstalledContent {
	// Fields
	char pad_0x48[0x40]; // Offset: 0x48 // Size: 0x40

	// Functions

	// Object Name: Function MobilePatchingUtils.MobilePendingContent.StartInstall
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StartInstall(struct FDelegate OnSucceeded, struct FDelegate OnFailed); // Offset: 0x101fe2650 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function MobilePatchingUtils.MobilePendingContent.GetTotalDownloadedSize
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	float GetTotalDownloadedSize(); // Offset: 0x101fe286c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MobilePatchingUtils.MobilePendingContent.GetRequiredDiskSpace
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	float GetRequiredDiskSpace(); // Offset: 0x101fe28a0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MobilePatchingUtils.MobilePendingContent.GetInstallProgress
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	float GetInstallProgress(); // Offset: 0x101fe275c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MobilePatchingUtils.MobilePendingContent.GetDownloadStatusText
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	struct FText GetDownloadStatusText(); // Offset: 0x101fe2790 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function MobilePatchingUtils.MobilePendingContent.GetDownloadSpeed
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	float GetDownloadSpeed(); // Offset: 0x101fe2838 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MobilePatchingUtils.MobilePendingContent.GetDownloadSize
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	float GetDownloadSize(); // Offset: 0x101fe28d4 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class MobilePatchingUtils.MobilePatchingLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct UMobilePatchingLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function MobilePatchingUtils.MobilePatchingLibrary.RequestContent
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void RequestContent(struct FString RemoteManifestURL, struct FString CloudURL, struct FString InstallDirectory, struct FDelegate OnSucceeded, struct FDelegate OnFailed); // Offset: 0x101fe2f90 // Return & Params: Num(5) Size(0x50)

	// Object Name: Function MobilePatchingUtils.MobilePatchingLibrary.HasActiveWiFiConnection
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	bool HasActiveWiFiConnection(); // Offset: 0x101fe2f5c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function MobilePatchingUtils.MobilePatchingLibrary.GetSupportedPlatformNames
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct TArray<struct FString> GetSupportedPlatformNames(); // Offset: 0x101fe2de8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function MobilePatchingUtils.MobilePatchingLibrary.GetInstalledContent
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct UMobileInstalledContent* GetInstalledContent(struct FString InstallDirectory); // Offset: 0x101fe3190 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function MobilePatchingUtils.MobilePatchingLibrary.GetActiveDeviceProfileName
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FString GetActiveDeviceProfileName(); // Offset: 0x101fe2edc // Return & Params: Num(1) Size(0x10)
};

