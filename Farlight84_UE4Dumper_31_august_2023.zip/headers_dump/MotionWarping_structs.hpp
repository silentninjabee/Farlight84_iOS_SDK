#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct MotionWarping.MotionWarpingWindowData
// Size: 0x10 // Inherited bytes: 0x00
struct FMotionWarpingWindowData {
	// Fields
	struct UAnimNotifyState_MotionWarping* AnimNotify; // Offset: 0x00 // Size: 0x08
	float StartTime; // Offset: 0x08 // Size: 0x04
	float EndTime; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct MotionWarping.MotionWarpingTarget
// Size: 0x50 // Inherited bytes: 0x00
struct FMotionWarpingTarget {
	// Fields
	struct FTransform Transform; // Offset: 0x00 // Size: 0x30
	struct TWeakObjectPtr<struct USceneComponent> Component; // Offset: 0x30 // Size: 0x08
	struct FName BoneName; // Offset: 0x38 // Size: 0x08
	bool bFollowComponent; // Offset: 0x40 // Size: 0x01
	char pad_0x41[0xf]; // Offset: 0x41 // Size: 0x0f
};

// Object Name: ScriptStruct MotionWarping.MotionDeltaTrackContainer
// Size: 0x10 // Inherited bytes: 0x00
struct FMotionDeltaTrackContainer {
	// Fields
	struct TArray<struct FMotionDeltaTrack> Tracks; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct MotionWarping.MotionDeltaTrack
// Size: 0x48 // Inherited bytes: 0x00
struct FMotionDeltaTrack {
	// Fields
	struct TArray<struct FTransform> BoneTransformTrack; // Offset: 0x00 // Size: 0x10
	struct TArray<struct FVector> DeltaTranslationTrack; // Offset: 0x10 // Size: 0x10
	struct TArray<struct FRotator> DeltaRotationTrack; // Offset: 0x20 // Size: 0x10
	struct FVector TotalTranslation; // Offset: 0x30 // Size: 0x0c
	struct FRotator TotalRotation; // Offset: 0x3c // Size: 0x0c
};

