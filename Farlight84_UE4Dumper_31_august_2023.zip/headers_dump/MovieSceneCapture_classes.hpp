#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class MovieSceneCapture.MovieSceneCaptureProtocolBase
// Size: 0x58 // Inherited bytes: 0x28
struct UMovieSceneCaptureProtocolBase : UObject {
	// Fields
	char pad_0x28[0x28]; // Offset: 0x28 // Size: 0x28
	enum class EMovieSceneCaptureProtocolState State; // Offset: 0x50 // Size: 0x01
	char pad_0x51[0x7]; // Offset: 0x51 // Size: 0x07

	// Functions

	// Object Name: Function MovieSceneCapture.MovieSceneCaptureProtocolBase.IsCapturing
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsCapturing(); // Offset: 0x1044fd964 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function MovieSceneCapture.MovieSceneCaptureProtocolBase.GetState
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	enum class EMovieSceneCaptureProtocolState GetState(); // Offset: 0x1044fd9b4 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class MovieSceneCapture.MovieSceneAudioCaptureProtocolBase
// Size: 0x58 // Inherited bytes: 0x58
struct UMovieSceneAudioCaptureProtocolBase : UMovieSceneCaptureProtocolBase {
};

// Object Name: Class MovieSceneCapture.NullAudioCaptureProtocol
// Size: 0x58 // Inherited bytes: 0x58
struct UNullAudioCaptureProtocol : UMovieSceneAudioCaptureProtocolBase {
};

// Object Name: Class MovieSceneCapture.MasterAudioSubmixCaptureProtocol
// Size: 0x90 // Inherited bytes: 0x58
struct UMasterAudioSubmixCaptureProtocol : UMovieSceneAudioCaptureProtocolBase {
	// Fields
	struct FString Filename; // Offset: 0x58 // Size: 0x10
	char pad_0x68[0x28]; // Offset: 0x68 // Size: 0x28
};

// Object Name: Class MovieSceneCapture.MovieSceneImageCaptureProtocolBase
// Size: 0x58 // Inherited bytes: 0x58
struct UMovieSceneImageCaptureProtocolBase : UMovieSceneCaptureProtocolBase {
};

// Object Name: Class MovieSceneCapture.CompositionGraphCaptureProtocol
// Size: 0xc0 // Inherited bytes: 0x58
struct UCompositionGraphCaptureProtocol : UMovieSceneImageCaptureProtocolBase {
	// Fields
	struct FCompositionGraphCapturePasses IncludeRenderPasses; // Offset: 0x58 // Size: 0x10
	bool bCaptureFramesInHDR; // Offset: 0x68 // Size: 0x01
	char pad_0x69[0x3]; // Offset: 0x69 // Size: 0x03
	int32_t HDRCompressionQuality; // Offset: 0x6c // Size: 0x04
	enum class EHDRCaptureGamut CaptureGamut; // Offset: 0x70 // Size: 0x01
	char pad_0x71[0x7]; // Offset: 0x71 // Size: 0x07
	struct FSoftObjectPath PostProcessingMaterial; // Offset: 0x78 // Size: 0x18
	bool bDisableScreenPercentage; // Offset: 0x90 // Size: 0x01
	char pad_0x91[0x7]; // Offset: 0x91 // Size: 0x07
	struct UMaterialInterface* PostProcessingMaterialPtr; // Offset: 0x98 // Size: 0x08
	char pad_0xA0[0x20]; // Offset: 0xa0 // Size: 0x20
};

// Object Name: Class MovieSceneCapture.FrameGrabberProtocol
// Size: 0x68 // Inherited bytes: 0x58
struct UFrameGrabberProtocol : UMovieSceneImageCaptureProtocolBase {
	// Fields
	char pad_0x58[0x10]; // Offset: 0x58 // Size: 0x10
};

// Object Name: Class MovieSceneCapture.ImageSequenceProtocol
// Size: 0xd8 // Inherited bytes: 0x68
struct UImageSequenceProtocol : UFrameGrabberProtocol {
	// Fields
	char pad_0x68[0x70]; // Offset: 0x68 // Size: 0x70
};

// Object Name: Class MovieSceneCapture.CompressedImageSequenceProtocol
// Size: 0xe0 // Inherited bytes: 0xd8
struct UCompressedImageSequenceProtocol : UImageSequenceProtocol {
	// Fields
	int32_t CompressionQuality; // Offset: 0xd8 // Size: 0x04
	char pad_0xDC[0x4]; // Offset: 0xdc // Size: 0x04
};

// Object Name: Class MovieSceneCapture.ImageSequenceProtocol_BMP
// Size: 0xd8 // Inherited bytes: 0xd8
struct UImageSequenceProtocol_BMP : UImageSequenceProtocol {
};

// Object Name: Class MovieSceneCapture.ImageSequenceProtocol_PNG
// Size: 0xe0 // Inherited bytes: 0xe0
struct UImageSequenceProtocol_PNG : UCompressedImageSequenceProtocol {
};

// Object Name: Class MovieSceneCapture.ImageSequenceProtocol_JPG
// Size: 0xe0 // Inherited bytes: 0xe0
struct UImageSequenceProtocol_JPG : UCompressedImageSequenceProtocol {
};

// Object Name: Class MovieSceneCapture.ImageSequenceProtocol_EXR
// Size: 0xe8 // Inherited bytes: 0xd8
struct UImageSequenceProtocol_EXR : UImageSequenceProtocol {
	// Fields
	bool bCompressed; // Offset: 0xd8 // Size: 0x01
	enum class EHDRCaptureGamut CaptureGamut; // Offset: 0xd9 // Size: 0x01
	char pad_0xDA[0xe]; // Offset: 0xda // Size: 0x0e
};

// Object Name: Class MovieSceneCapture.MovieSceneCaptureInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UMovieSceneCaptureInterface : UInterface {
};

// Object Name: Class MovieSceneCapture.MovieSceneCapture
// Size: 0x220 // Inherited bytes: 0x28
struct UMovieSceneCapture : UObject {
	// Fields
	char pad_0x28[0x10]; // Offset: 0x28 // Size: 0x10
	struct FSoftClassPath ImageCaptureProtocolType; // Offset: 0x38 // Size: 0x18
	struct FSoftClassPath AudioCaptureProtocolType; // Offset: 0x50 // Size: 0x18
	struct UMovieSceneImageCaptureProtocolBase* ImageCaptureProtocol; // Offset: 0x68 // Size: 0x08
	struct UMovieSceneAudioCaptureProtocolBase* AudioCaptureProtocol; // Offset: 0x70 // Size: 0x08
	struct FMovieSceneCaptureSettings Settings; // Offset: 0x78 // Size: 0x70
	bool bUseSeparateProcess; // Offset: 0xe8 // Size: 0x01
	bool bCloseEditorWhenCaptureStarts; // Offset: 0xe9 // Size: 0x01
	char pad_0xEA[0x6]; // Offset: 0xea // Size: 0x06
	struct FString AdditionalCommandLineArguments; // Offset: 0xf0 // Size: 0x10
	struct FString InheritedCommandLineArguments; // Offset: 0x100 // Size: 0x10
	char pad_0x110[0x110]; // Offset: 0x110 // Size: 0x110

	// Functions

	// Object Name: Function MovieSceneCapture.MovieSceneCapture.SetImageCaptureProtocolType
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetImageCaptureProtocolType(struct UMovieSceneCaptureProtocolBase* ProtocolType); // Offset: 0x1044fcd40 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function MovieSceneCapture.MovieSceneCapture.SetAudioCaptureProtocolType
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAudioCaptureProtocolType(struct UMovieSceneCaptureProtocolBase* ProtocolType); // Offset: 0x1044fccc0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function MovieSceneCapture.MovieSceneCapture.GetImageCaptureProtocol
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UMovieSceneCaptureProtocolBase* GetImageCaptureProtocol(); // Offset: 0x1044fcddc // Return & Params: Num(1) Size(0x8)

	// Object Name: Function MovieSceneCapture.MovieSceneCapture.GetAudioCaptureProtocol
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct UMovieSceneCaptureProtocolBase* GetAudioCaptureProtocol(); // Offset: 0x1044fcdc0 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class MovieSceneCapture.LevelCapture
// Size: 0x240 // Inherited bytes: 0x220
struct ULevelCapture : UMovieSceneCapture {
	// Fields
	bool bAutoStartCapture; // Offset: 0x220 // Size: 0x01
	char pad_0x221[0xb]; // Offset: 0x221 // Size: 0x0b
	struct FGuid PrerequisiteActorId; // Offset: 0x22c // Size: 0x10
	char pad_0x23C[0x4]; // Offset: 0x23c // Size: 0x04
};

// Object Name: Class MovieSceneCapture.MovieSceneCaptureEnvironment
// Size: 0x28 // Inherited bytes: 0x28
struct UMovieSceneCaptureEnvironment : UObject {
	// Functions

	// Object Name: Function MovieSceneCapture.MovieSceneCaptureEnvironment.IsCaptureInProgress
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsCaptureInProgress(); // Offset: 0x1044fd3ac // Return & Params: Num(1) Size(0x1)

	// Object Name: Function MovieSceneCapture.MovieSceneCaptureEnvironment.GetCaptureFrameNumber
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	int32_t GetCaptureFrameNumber(); // Offset: 0x1044fd414 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MovieSceneCapture.MovieSceneCaptureEnvironment.GetCaptureElapsedTime
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	float GetCaptureElapsedTime(); // Offset: 0x1044fd3e0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MovieSceneCapture.MovieSceneCaptureEnvironment.FindImageCaptureProtocol
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UMovieSceneImageCaptureProtocolBase* FindImageCaptureProtocol(); // Offset: 0x1044fd378 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function MovieSceneCapture.MovieSceneCaptureEnvironment.FindAudioCaptureProtocol
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UMovieSceneAudioCaptureProtocolBase* FindAudioCaptureProtocol(); // Offset: 0x1044fd344 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class MovieSceneCapture.UserDefinedCaptureProtocol
// Size: 0xd8 // Inherited bytes: 0x58
struct UUserDefinedCaptureProtocol : UMovieSceneImageCaptureProtocolBase {
	// Fields
	struct UWorld* World; // Offset: 0x58 // Size: 0x08
	char pad_0x60[0x78]; // Offset: 0x60 // Size: 0x78

	// Functions

	// Object Name: Function MovieSceneCapture.UserDefinedCaptureProtocol.StopCapturingFinalPixels
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StopCapturingFinalPixels(); // Offset: 0x1044fe400 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function MovieSceneCapture.UserDefinedCaptureProtocol.StartCapturingFinalPixels
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void StartCapturingFinalPixels(struct FCapturedPixelsID& StreamID); // Offset: 0x1044fe414 // Return & Params: Num(1) Size(0x50)

	// Object Name: Function MovieSceneCapture.UserDefinedCaptureProtocol.ResolveBuffer
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void ResolveBuffer(struct UTexture* Buffer, struct FCapturedPixelsID& BufferID); // Offset: 0x1044fe4d4 // Return & Params: Num(2) Size(0x58)

	// Object Name: Function MovieSceneCapture.UserDefinedCaptureProtocol.OnWarmUp
	// Flags: [Event|Protected|BlueprintEvent]
	void OnWarmUp(); // Offset: 0x1032ea4b8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function MovieSceneCapture.UserDefinedCaptureProtocol.OnTick
	// Flags: [Event|Protected|BlueprintEvent]
	void OnTick(); // Offset: 0x1032ea4b8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function MovieSceneCapture.UserDefinedCaptureProtocol.OnStartCapture
	// Flags: [Event|Protected|BlueprintEvent]
	void OnStartCapture(); // Offset: 0x1032ea4b8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function MovieSceneCapture.UserDefinedCaptureProtocol.OnSetup
	// Flags: [Native|Event|Protected|BlueprintEvent]
	bool OnSetup(); // Offset: 0x1044fe610 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function MovieSceneCapture.UserDefinedCaptureProtocol.OnPreTick
	// Flags: [Event|Protected|BlueprintEvent]
	void OnPreTick(); // Offset: 0x1032ea4b8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function MovieSceneCapture.UserDefinedCaptureProtocol.OnPixelsReceived
	// Flags: [Event|Protected|HasOutParms|BlueprintEvent]
	void OnPixelsReceived(struct FCapturedPixels& Pixels, struct FCapturedPixelsID& ID, struct FFrameMetrics FrameMetrics); // Offset: 0x1032ea4b8 // Return & Params: Num(3) Size(0x70)

	// Object Name: Function MovieSceneCapture.UserDefinedCaptureProtocol.OnPauseCapture
	// Flags: [Event|Protected|BlueprintEvent]
	void OnPauseCapture(); // Offset: 0x1032ea4b8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function MovieSceneCapture.UserDefinedCaptureProtocol.OnFinalize
	// Flags: [Event|Protected|BlueprintEvent]
	void OnFinalize(); // Offset: 0x1032ea4b8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function MovieSceneCapture.UserDefinedCaptureProtocol.OnCaptureFrame
	// Flags: [Event|Protected|BlueprintEvent]
	void OnCaptureFrame(); // Offset: 0x1032ea4b8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function MovieSceneCapture.UserDefinedCaptureProtocol.OnCanFinalize
	// Flags: [Native|Event|Protected|BlueprintEvent|Const]
	bool OnCanFinalize(); // Offset: 0x1044fe5d4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function MovieSceneCapture.UserDefinedCaptureProtocol.OnBeginFinalize
	// Flags: [Event|Protected|BlueprintEvent]
	void OnBeginFinalize(); // Offset: 0x1032ea4b8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function MovieSceneCapture.UserDefinedCaptureProtocol.GetCurrentFrameMetrics
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FFrameMetrics GetCurrentFrameMetrics(); // Offset: 0x1044fe2f8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function MovieSceneCapture.UserDefinedCaptureProtocol.GenerateFilename
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	struct FString GenerateFilename(struct FFrameMetrics& InFrameMetrics); // Offset: 0x1044fe314 // Return & Params: Num(2) Size(0x20)
};

// Object Name: Class MovieSceneCapture.UserDefinedImageCaptureProtocol
// Size: 0xe0 // Inherited bytes: 0xd8
struct UUserDefinedImageCaptureProtocol : UUserDefinedCaptureProtocol {
	// Fields
	enum class EDesiredImageFormat Format; // Offset: 0xd8 // Size: 0x01
	bool bEnableCompression; // Offset: 0xd9 // Size: 0x01
	char pad_0xDA[0x2]; // Offset: 0xda // Size: 0x02
	int32_t CompressionQuality; // Offset: 0xdc // Size: 0x04

	// Functions

	// Object Name: Function MovieSceneCapture.UserDefinedImageCaptureProtocol.WriteImageToDisk
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void WriteImageToDisk(struct FCapturedPixels& PixelData, struct FCapturedPixelsID& StreamID, struct FFrameMetrics& FrameMetrics, bool bCopyImageData); // Offset: 0x1044ff148 // Return & Params: Num(4) Size(0x71)

	// Object Name: Function MovieSceneCapture.UserDefinedImageCaptureProtocol.GenerateFilenameForCurrentFrame
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString GenerateFilenameForCurrentFrame(); // Offset: 0x1044ff35c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function MovieSceneCapture.UserDefinedImageCaptureProtocol.GenerateFilenameForBuffer
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	struct FString GenerateFilenameForBuffer(struct UTexture* Buffer, struct FCapturedPixelsID& StreamID); // Offset: 0x1044ff3dc // Return & Params: Num(3) Size(0x68)
};

// Object Name: Class MovieSceneCapture.VideoCaptureProtocol
// Size: 0x80 // Inherited bytes: 0x68
struct UVideoCaptureProtocol : UFrameGrabberProtocol {
	// Fields
	bool bUseCompression; // Offset: 0x68 // Size: 0x01
	char pad_0x69[0x3]; // Offset: 0x69 // Size: 0x03
	float CompressionQuality; // Offset: 0x6c // Size: 0x04
	char pad_0x70[0x10]; // Offset: 0x70 // Size: 0x10
};

