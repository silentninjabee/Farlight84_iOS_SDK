#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class ProceduralMeshComponent.KismetProceduralMeshLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct UKismetProceduralMeshLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function ProceduralMeshComponent.KismetProceduralMeshLibrary.SliceProceduralMesh
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void SliceProceduralMesh(struct UProceduralMeshComponent* InProcMesh, struct FVector PlanePosition, struct FVector PlaneNormal, bool bCreateOtherHalf, struct UProceduralMeshComponent*& OutOtherHalfProcMesh, enum class EProcMeshSliceCapOption CapOption, struct UMaterialInterface* CapMaterial); // Offset: 0x1011b3df8 // Return & Params: Num(7) Size(0x40)

	// Object Name: Function ProceduralMeshComponent.KismetProceduralMeshLibrary.GetSectionFromStaticMesh
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetSectionFromStaticMesh(struct UStaticMesh* InMesh, int32_t LODIndex, int32_t SectionIndex, struct TArray<struct FVector>& Vertices, struct TArray<int32_t>& Triangles, struct TArray<struct FVector>& Normals, struct TArray<struct FVector2D>& UVs, struct TArray<struct FProcMeshTangent>& Tangents); // Offset: 0x1011b4460 // Return & Params: Num(8) Size(0x60)

	// Object Name: Function ProceduralMeshComponent.KismetProceduralMeshLibrary.GetSectionFromProceduralMesh
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetSectionFromProceduralMesh(struct UProceduralMeshComponent* InProcMesh, int32_t SectionIndex, struct TArray<struct FVector>& Vertices, struct TArray<int32_t>& Triangles, struct TArray<struct FVector>& Normals, struct TArray<struct FVector2D>& UVs, struct TArray<struct FProcMeshTangent>& Tangents); // Offset: 0x1011b4054 // Return & Params: Num(7) Size(0x60)

	// Object Name: Function ProceduralMeshComponent.KismetProceduralMeshLibrary.GenerateBoxMesh
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void GenerateBoxMesh(struct FVector BoxRadius, struct TArray<struct FVector>& Vertices, struct TArray<int32_t>& Triangles, struct TArray<struct FVector>& Normals, struct TArray<struct FVector2D>& UVs, struct TArray<struct FProcMeshTangent>& Tangents); // Offset: 0x1011b5144 // Return & Params: Num(6) Size(0x60)

	// Object Name: Function ProceduralMeshComponent.KismetProceduralMeshLibrary.CreateGridMeshWelded
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void CreateGridMeshWelded(int32_t NumX, int32_t NumY, struct TArray<int32_t>& Triangles, struct TArray<struct FVector>& Vertices, struct TArray<struct FVector2D>& UVs, float GridSpacing); // Offset: 0x1011b49dc // Return & Params: Num(6) Size(0x3c)

	// Object Name: Function ProceduralMeshComponent.KismetProceduralMeshLibrary.CreateGridMeshTriangles
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void CreateGridMeshTriangles(int32_t NumX, int32_t NumY, bool bWinding, struct TArray<int32_t>& Triangles); // Offset: 0x1011b4c04 // Return & Params: Num(4) Size(0x20)

	// Object Name: Function ProceduralMeshComponent.KismetProceduralMeshLibrary.CreateGridMeshSplit
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void CreateGridMeshSplit(int32_t NumX, int32_t NumY, struct TArray<int32_t>& Triangles, struct TArray<struct FVector>& Vertices, struct TArray<struct FVector2D>& UVs, struct TArray<struct FVector2D>& UV1s, float GridSpacing); // Offset: 0x1011b4750 // Return & Params: Num(7) Size(0x4c)

	// Object Name: Function ProceduralMeshComponent.KismetProceduralMeshLibrary.CopyProceduralMeshFromStaticMeshComponent
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void CopyProceduralMeshFromStaticMeshComponent(struct UStaticMeshComponent* StaticMeshComponent, int32_t LODIndex, struct UProceduralMeshComponent* ProcMeshComponent, bool bCreateCollision); // Offset: 0x1011b42fc // Return & Params: Num(4) Size(0x19)

	// Object Name: Function ProceduralMeshComponent.KismetProceduralMeshLibrary.ConvertQuadToTriangles
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void ConvertQuadToTriangles(struct TArray<int32_t>& Triangles, int32_t Vert0, int32_t Vert1, int32_t Vert2, int32_t Vert3); // Offset: 0x1011b4d84 // Return & Params: Num(5) Size(0x20)

	// Object Name: Function ProceduralMeshComponent.KismetProceduralMeshLibrary.CalculateTangentsForMesh
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void CalculateTangentsForMesh(struct TArray<struct FVector>& Vertices, struct TArray<int32_t>& Triangles, struct TArray<struct FVector2D>& UVs, struct TArray<struct FVector>& Normals, struct TArray<struct FProcMeshTangent>& Tangents); // Offset: 0x1011b4f34 // Return & Params: Num(5) Size(0x50)
};

// Object Name: Class ProceduralMeshComponent.ProceduralMeshComponent
// Size: 0x610 // Inherited bytes: 0x5b0
struct UProceduralMeshComponent : UMeshComponent {
	// Fields
	bool bUseComplexAsSimpleCollision; // Offset: 0x5b0 // Size: 0x01
	bool bUseAsyncCooking; // Offset: 0x5b1 // Size: 0x01
	char pad_0x5B2[0x6]; // Offset: 0x5b2 // Size: 0x06
	struct UBodySetup* ProcMeshBodySetup; // Offset: 0x5b8 // Size: 0x08
	struct TArray<struct FProcMeshSection> ProcMeshSections; // Offset: 0x5c0 // Size: 0x10
	struct TArray<struct FKConvexElem> CollisionConvexElems; // Offset: 0x5d0 // Size: 0x10
	struct FBoxSphereBounds LocalBounds; // Offset: 0x5e0 // Size: 0x1c
	char pad_0x5FC[0x4]; // Offset: 0x5fc // Size: 0x04
	struct TArray<struct UBodySetup*> AsyncBodySetupQueue; // Offset: 0x600 // Size: 0x10

	// Functions

	// Object Name: Function ProceduralMeshComponent.ProceduralMeshComponent.UpdateMeshSection_LinearColor
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void UpdateMeshSection_LinearColor(int32_t SectionIndex, struct TArray<struct FVector>& Vertices, struct TArray<struct FVector>& Normals, struct TArray<struct FVector2D>& UV0, struct TArray<struct FVector2D>& UV1, struct TArray<struct FVector2D>& UV2, struct TArray<struct FVector2D>& UV3, struct TArray<struct FLinearColor>& VertexColors, struct TArray<struct FProcMeshTangent>& Tangents); // Offset: 0x1011b5fa8 // Return & Params: Num(9) Size(0x88)

	// Object Name: Function ProceduralMeshComponent.ProceduralMeshComponent.UpdateMeshSection
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void UpdateMeshSection(int32_t SectionIndex, struct TArray<struct FVector>& Vertices, struct TArray<struct FVector>& Normals, struct TArray<struct FVector2D>& UV0, struct TArray<struct FColor>& VertexColors, struct TArray<struct FProcMeshTangent>& Tangents); // Offset: 0x1011b6330 // Return & Params: Num(6) Size(0x58)

	// Object Name: Function ProceduralMeshComponent.ProceduralMeshComponent.SetMeshSectionVisible
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMeshSectionVisible(int32_t SectionIndex, bool bNewVisibility); // Offset: 0x1011b5e44 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function ProceduralMeshComponent.ProceduralMeshComponent.IsMeshSectionVisible
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsMeshSectionVisible(int32_t SectionIndex); // Offset: 0x1011b5db4 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function ProceduralMeshComponent.ProceduralMeshComponent.GetNumSections
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetNumSections(); // Offset: 0x1011b5d80 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function ProceduralMeshComponent.ProceduralMeshComponent.CreateMeshSection_LinearColor
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void CreateMeshSection_LinearColor(int32_t SectionIndex, struct TArray<struct FVector>& Vertices, struct TArray<int32_t>& Triangles, struct TArray<struct FVector>& Normals, struct TArray<struct FVector2D>& UV0, struct TArray<struct FVector2D>& UV1, struct TArray<struct FVector2D>& UV2, struct TArray<struct FVector2D>& UV3, struct TArray<struct FLinearColor>& VertexColors, struct TArray<struct FProcMeshTangent>& Tangents, bool bCreateCollision); // Offset: 0x1011b65b0 // Return & Params: Num(11) Size(0x99)

	// Object Name: Function ProceduralMeshComponent.ProceduralMeshComponent.CreateMeshSection
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void CreateMeshSection(int32_t SectionIndex, struct TArray<struct FVector>& Vertices, struct TArray<int32_t>& Triangles, struct TArray<struct FVector>& Normals, struct TArray<struct FVector2D>& UV0, struct TArray<struct FColor>& VertexColors, struct TArray<struct FProcMeshTangent>& Tangents, bool bCreateCollision); // Offset: 0x1011b69e8 // Return & Params: Num(8) Size(0x69)

	// Object Name: Function ProceduralMeshComponent.ProceduralMeshComponent.ClearMeshSection
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearMeshSection(int32_t SectionIndex); // Offset: 0x1011b5f28 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function ProceduralMeshComponent.ProceduralMeshComponent.ClearCollisionConvexMeshes
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearCollisionConvexMeshes(); // Offset: 0x1011b5c78 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function ProceduralMeshComponent.ProceduralMeshComponent.ClearAllMeshSections
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearAllMeshSections(); // Offset: 0x1011b5f14 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function ProceduralMeshComponent.ProceduralMeshComponent.AddCollisionConvexMesh
	// Flags: [Final|Native|Public|BlueprintCallable]
	void AddCollisionConvexMesh(struct TArray<struct FVector> ConvexVerts); // Offset: 0x1011b5c8c // Return & Params: Num(1) Size(0x10)
};

