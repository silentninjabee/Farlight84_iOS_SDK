#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class ReplicationGraph.ReplicationGraph
// Size: 0x500 // Inherited bytes: 0x28
struct UReplicationGraph : UReplicationDriver {
	// Fields
	struct UNetReplicationGraphConnection* ReplicationConnectionManagerClass; // Offset: 0x28 // Size: 0x08
	struct UNetDriver* NetDriver; // Offset: 0x30 // Size: 0x08
	struct TArray<struct UNetReplicationGraphConnection*> Connections; // Offset: 0x38 // Size: 0x10
	struct TArray<struct UNetReplicationGraphConnection*> PendingConnections; // Offset: 0x48 // Size: 0x10
	char pad_0x58[0x40]; // Offset: 0x58 // Size: 0x40
	struct TArray<struct UReplicationGraphNode*> GlobalGraphNodes; // Offset: 0x98 // Size: 0x10
	struct TArray<struct UReplicationGraphNode*> PrepareForReplicationNodes; // Offset: 0xa8 // Size: 0x10
	struct TArray<struct UReplicationGraphNode*> PostReplicateNodes; // Offset: 0xb8 // Size: 0x10
	char pad_0xC8[0x3c0]; // Offset: 0xc8 // Size: 0x3c0
	struct TMap<struct UNetConnection*, struct FClassExtraReplicatedInfo> ConnectionInfos; // Offset: 0x488 // Size: 0x50
	char pad_0x4D8[0x28]; // Offset: 0x4d8 // Size: 0x28
};

// Object Name: Class ReplicationGraph.BasicReplicationGraph
// Size: 0x530 // Inherited bytes: 0x500
struct UBasicReplicationGraph : UReplicationGraph {
	// Fields
	struct UReplicationGraphNode_GridSpatialization2D* GridNode; // Offset: 0x4f8 // Size: 0x08
	struct UReplicationGraphNode_ActorList* AlwaysRelevantNode; // Offset: 0x500 // Size: 0x08
	struct TArray<struct FConnectionAlwaysRelevantNodePair> AlwaysRelevantForConnectionList; // Offset: 0x508 // Size: 0x10
	struct TArray<struct AActor*> ActorsWithoutNetConnection; // Offset: 0x518 // Size: 0x10
};

// Object Name: Class ReplicationGraph.ReplicationGraphNode
// Size: 0x50 // Inherited bytes: 0x28
struct UReplicationGraphNode : UObject {
	// Fields
	struct TArray<struct UReplicationGraphNode*> AllChildNodes; // Offset: 0x28 // Size: 0x10
	char pad_0x38[0x18]; // Offset: 0x38 // Size: 0x18
};

// Object Name: Class ReplicationGraph.ReplicationGraphNode_ActorList
// Size: 0xd0 // Inherited bytes: 0x50
struct UReplicationGraphNode_ActorList : UReplicationGraphNode {
	// Fields
	char pad_0x50[0x80]; // Offset: 0x50 // Size: 0x80
};

// Object Name: Class ReplicationGraph.ReplicationGraphNode_ActorListFrequencyBuckets
// Size: 0x108 // Inherited bytes: 0x50
struct UReplicationGraphNode_ActorListFrequencyBuckets : UReplicationGraphNode {
	// Fields
	char pad_0x50[0xb8]; // Offset: 0x50 // Size: 0xb8
};

// Object Name: Class ReplicationGraph.ReplicationGraphNode_DynamicSpatialFrequency
// Size: 0x100 // Inherited bytes: 0xd0
struct UReplicationGraphNode_DynamicSpatialFrequency : UReplicationGraphNode_ActorList {
	// Fields
	char pad_0xD0[0x30]; // Offset: 0xd0 // Size: 0x30
};

// Object Name: Class ReplicationGraph.ReplicationGraphNode_ConnectionDormancyNode
// Size: 0x148 // Inherited bytes: 0xd0
struct UReplicationGraphNode_ConnectionDormancyNode : UReplicationGraphNode_ActorList {
	// Fields
	char pad_0xD0[0x78]; // Offset: 0xd0 // Size: 0x78
};

// Object Name: Class ReplicationGraph.ReplicationGraphNode_DormancyNode
// Size: 0xe0 // Inherited bytes: 0xd0
struct UReplicationGraphNode_DormancyNode : UReplicationGraphNode_ActorList {
	// Fields
	char pad_0xD0[0x10]; // Offset: 0xd0 // Size: 0x10
};

// Object Name: Class ReplicationGraph.ReplicationGraphNode_GridCell
// Size: 0x120 // Inherited bytes: 0xd0
struct UReplicationGraphNode_GridCell : UReplicationGraphNode_ActorList {
	// Fields
	char pad_0xD0[0x40]; // Offset: 0xd0 // Size: 0x40
	struct UReplicationGraphNode* DynamicNode; // Offset: 0x110 // Size: 0x08
	struct UReplicationGraphNode_DormancyNode* DormancyNode; // Offset: 0x118 // Size: 0x08
};

// Object Name: Class ReplicationGraph.ReplicationGraphNode_GridSpatialization2D
// Size: 0x230 // Inherited bytes: 0x50
struct UReplicationGraphNode_GridSpatialization2D : UReplicationGraphNode {
	// Fields
	char pad_0x50[0x1e0]; // Offset: 0x50 // Size: 0x1e0
};

// Object Name: Class ReplicationGraph.ReplicationGraphNode_AlwaysRelevant
// Size: 0x68 // Inherited bytes: 0x50
struct UReplicationGraphNode_AlwaysRelevant : UReplicationGraphNode {
	// Fields
	struct UReplicationGraphNode* ChildNode; // Offset: 0x50 // Size: 0x08
	char pad_0x58[0x10]; // Offset: 0x58 // Size: 0x10
};

// Object Name: Class ReplicationGraph.ReplicationGraphNode_AlwaysRelevant_ForConnection
// Size: 0xf0 // Inherited bytes: 0xd0
struct UReplicationGraphNode_AlwaysRelevant_ForConnection : UReplicationGraphNode_ActorList {
	// Fields
	char pad_0xD0[0x10]; // Offset: 0xd0 // Size: 0x10
	struct TArray<struct FAlwaysRelevantActorInfo> PastRelevantActors; // Offset: 0xe0 // Size: 0x10
};

// Object Name: Class ReplicationGraph.ReplicationGraphNode_TearOff_ForConnection
// Size: 0x70 // Inherited bytes: 0x50
struct UReplicationGraphNode_TearOff_ForConnection : UReplicationGraphNode {
	// Fields
	struct TArray<struct FTearOffActorInfo> TearOffActors; // Offset: 0x50 // Size: 0x10
	char pad_0x60[0x10]; // Offset: 0x60 // Size: 0x10
};

// Object Name: Class ReplicationGraph.NetReplicationGraphConnection
// Size: 0x2d8 // Inherited bytes: 0x28
struct UNetReplicationGraphConnection : UReplicationConnectionDriver {
	// Fields
	struct UNetConnection* NetConnection; // Offset: 0x28 // Size: 0x08
	char pad_0x30[0x1e0]; // Offset: 0x30 // Size: 0x1e0
	struct AReplicationGraphDebugActor* DebugActor; // Offset: 0x210 // Size: 0x08
	char pad_0x218[0x10]; // Offset: 0x218 // Size: 0x10
	struct TArray<struct FLastLocationGatherInfo> LastGatherLocations; // Offset: 0x228 // Size: 0x10
	char pad_0x238[0x8]; // Offset: 0x238 // Size: 0x08
	struct TArray<struct UReplicationGraphNode*> ConnectionGraphNodes; // Offset: 0x240 // Size: 0x10
	struct UReplicationGraphNode_TearOff_ForConnection* TearOffNode; // Offset: 0x250 // Size: 0x08
	char pad_0x258[0x80]; // Offset: 0x258 // Size: 0x80
};

// Object Name: Class ReplicationGraph.ReplicationGraphDebugActor
// Size: 0x238 // Inherited bytes: 0x228
struct AReplicationGraphDebugActor : AActor {
	// Fields
	struct UReplicationGraph* ReplicationGraph; // Offset: 0x228 // Size: 0x08
	struct UNetReplicationGraphConnection* ConnectionManager; // Offset: 0x230 // Size: 0x08

	// Functions

	// Object Name: Function ReplicationGraph.ReplicationGraphDebugActor.ServerStopDebugging
	// Flags: [Net|NetReliableNative|Event|Public|NetServer]
	void ServerStopDebugging(); // Offset: 0x10105c6ec // Return & Params: Num(0) Size(0x0)

	// Object Name: Function ReplicationGraph.ReplicationGraphDebugActor.ServerStartDebugging
	// Flags: [Net|NetReliableNative|Event|Public|NetServer]
	void ServerStartDebugging(); // Offset: 0x10105c708 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function ReplicationGraph.ReplicationGraphDebugActor.ServerSetPeriodFrameForClass
	// Flags: [Net|NetReliableNative|Event|Public|NetServer]
	void ServerSetPeriodFrameForClass(struct UObject* Class, int32_t PeriodFrame); // Offset: 0x10105c494 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function ReplicationGraph.ReplicationGraphDebugActor.ServerSetCullDistanceForClass
	// Flags: [Net|NetReliableNative|Event|Public|NetServer]
	void ServerSetCullDistanceForClass(struct UObject* Class, float CullDistance); // Offset: 0x10105c568 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function ReplicationGraph.ReplicationGraphDebugActor.ServerSetConditionalActorBreakpoint
	// Flags: [Net|NetReliableNative|Event|Public|NetServer]
	void ServerSetConditionalActorBreakpoint(struct AActor* Actor); // Offset: 0x10105c40c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function ReplicationGraph.ReplicationGraphDebugActor.ServerPrintCullDistances
	// Flags: [Net|NetReliableNative|Event|Public|NetServer]
	void ServerPrintCullDistances(); // Offset: 0x10105c3f0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function ReplicationGraph.ReplicationGraphDebugActor.ServerPrintAllActorInfo
	// Flags: [Net|NetReliableNative|Event|Public|NetServer]
	void ServerPrintAllActorInfo(struct FString str); // Offset: 0x10105c63c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function ReplicationGraph.ReplicationGraphDebugActor.ServerCellInfo
	// Flags: [Net|NetReliableNative|Event|Public|NetServer]
	void ServerCellInfo(); // Offset: 0x10105c6d0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function ReplicationGraph.ReplicationGraphDebugActor.ClientCellInfo
	// Flags: [Net|NetReliableNative|Event|Public|HasDefaults|NetClient]
	void ClientCellInfo(struct FVector CellLocation, struct FVector CellExtent, struct TArray<struct AActor*> Actors); // Offset: 0x10105c2c8 // Return & Params: Num(3) Size(0x28)
};

