#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct RigVM.RigVMExecuteContext
// Size: 0x10 // Inherited bytes: 0x00
struct FRigVMExecuteContext {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct RigVM.RigVMStruct
// Size: 0x08 // Inherited bytes: 0x00
struct FRigVMStruct {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct RigVM.RigVMParameter
// Size: 0x30 // Inherited bytes: 0x00
struct FRigVMParameter {
	// Fields
	enum class ERigVMParameterType Type; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	struct FName Name; // Offset: 0x04 // Size: 0x08
	int32_t RegisterIndex; // Offset: 0x0c // Size: 0x04
	struct FString CPPType; // Offset: 0x10 // Size: 0x10
	struct UScriptStruct* ScriptStruct; // Offset: 0x20 // Size: 0x08
	struct FName ScriptStructPath; // Offset: 0x28 // Size: 0x08
};

// Object Name: ScriptStruct RigVM.RigVMByteCode
// Size: 0x10 // Inherited bytes: 0x00
struct FRigVMByteCode {
	// Fields
	struct TArray<char> ByteCode; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct RigVM.RigVMInstructionArray
// Size: 0x10 // Inherited bytes: 0x00
struct FRigVMInstructionArray {
	// Fields
	struct TArray<struct FRigVMInstruction> Instructions; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct RigVM.RigVMInstruction
// Size: 0x10 // Inherited bytes: 0x00
struct FRigVMInstruction {
	// Fields
	enum class ERigVMOpCode OpCode; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	uint64_t ByteCodeIndex; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct RigVM.RigVMMemoryContainer
// Size: 0xa0 // Inherited bytes: 0x00
struct FRigVMMemoryContainer {
	// Fields
	bool bUseNameMap; // Offset: 0x00 // Size: 0x01
	enum class ERigVMMemoryType MemoryType; // Offset: 0x01 // Size: 0x01
	char pad_0x2[0x6]; // Offset: 0x02 // Size: 0x06
	struct TArray<struct FRigVMRegister> Registers; // Offset: 0x08 // Size: 0x10
	struct TArray<struct FRigVMRegisterOffset> RegisterOffsets; // Offset: 0x18 // Size: 0x10
	struct TArray<char> Data; // Offset: 0x28 // Size: 0x10
	struct TArray<struct UScriptStruct*> ScriptStructs; // Offset: 0x38 // Size: 0x10
	struct TMap<struct FName, int32_t> NameMap; // Offset: 0x48 // Size: 0x50
	bool bEncounteredErrorDuringLoad; // Offset: 0x98 // Size: 0x01
	char pad_0x99[0x7]; // Offset: 0x99 // Size: 0x07
};

// Object Name: ScriptStruct RigVM.RigVMRegisterOffset
// Size: 0x38 // Inherited bytes: 0x00
struct FRigVMRegisterOffset {
	// Fields
	struct TArray<int32_t> Segments; // Offset: 0x00 // Size: 0x10
	enum class ERigVMRegisterType Type; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x3]; // Offset: 0x11 // Size: 0x03
	struct FName CPPType; // Offset: 0x14 // Size: 0x08
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
	struct UScriptStruct* ScriptStruct; // Offset: 0x20 // Size: 0x08
	struct FName ScriptStructPath; // Offset: 0x28 // Size: 0x08
	uint16_t ElementSize; // Offset: 0x30 // Size: 0x02
	char pad_0x32[0x6]; // Offset: 0x32 // Size: 0x06
};

// Object Name: ScriptStruct RigVM.RigVMRegister
// Size: 0x24 // Inherited bytes: 0x00
struct FRigVMRegister {
	// Fields
	enum class ERigVMRegisterType Type; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	uint32_t ByteIndex; // Offset: 0x04 // Size: 0x04
	uint16_t ElementSize; // Offset: 0x08 // Size: 0x02
	uint16_t ElementCount; // Offset: 0x0a // Size: 0x02
	uint16_t SliceIndex; // Offset: 0x0c // Size: 0x02
	uint16_t SliceCount; // Offset: 0x0e // Size: 0x02
	char AlignmentBytes; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x1]; // Offset: 0x11 // Size: 0x01
	uint16_t TrailingBytes; // Offset: 0x12 // Size: 0x02
	struct FName Name; // Offset: 0x14 // Size: 0x08
	int32_t ScriptStructIndex; // Offset: 0x1c // Size: 0x04
	bool bIsArray; // Offset: 0x20 // Size: 0x01
	char pad_0x21[0x3]; // Offset: 0x21 // Size: 0x03
};

// Object Name: ScriptStruct RigVM.RigVMOperand
// Size: 0x06 // Inherited bytes: 0x00
struct FRigVMOperand {
	// Fields
	enum class ERigVMMemoryType MemoryType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x1]; // Offset: 0x01 // Size: 0x01
	uint16_t RegisterIndex; // Offset: 0x02 // Size: 0x02
	uint16_t RegisterOffset; // Offset: 0x04 // Size: 0x02
};

// Object Name: ScriptStruct RigVM.RigVMStatistics
// Size: 0x2c // Inherited bytes: 0x00
struct FRigVMStatistics {
	// Fields
	uint32_t BytesForCDO; // Offset: 0x00 // Size: 0x04
	uint32_t BytesPerInstance; // Offset: 0x04 // Size: 0x04
	struct FRigVMMemoryStatistics LiteralMemory; // Offset: 0x08 // Size: 0x0c
	struct FRigVMMemoryStatistics WorkMemory; // Offset: 0x14 // Size: 0x0c
	uint32_t BytesForCaching; // Offset: 0x20 // Size: 0x04
	struct FRigVMByteCodeStatistics ByteCode; // Offset: 0x24 // Size: 0x08
};

// Object Name: ScriptStruct RigVM.RigVMByteCodeStatistics
// Size: 0x08 // Inherited bytes: 0x00
struct FRigVMByteCodeStatistics {
	// Fields
	uint32_t InstructionCount; // Offset: 0x00 // Size: 0x04
	uint32_t DataBytes; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct RigVM.RigVMMemoryStatistics
// Size: 0x0c // Inherited bytes: 0x00
struct FRigVMMemoryStatistics {
	// Fields
	uint32_t RegisterCount; // Offset: 0x00 // Size: 0x04
	uint32_t DataBytes; // Offset: 0x04 // Size: 0x04
	uint32_t TotalBytes; // Offset: 0x08 // Size: 0x04
};

