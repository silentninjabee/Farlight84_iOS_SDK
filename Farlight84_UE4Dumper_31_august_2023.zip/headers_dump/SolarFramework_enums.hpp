#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum SolarFramework.EScope
enum class EScope : uint8 {
	None = 0,
	Login = 1,
	Lobby = 2,
	Battle = 4,
	Settlement = 8,
	Game = 14,
	Global = 15,
	EScope_MAX = 16
};

