#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct SolarUtils.SolarAggregationTickFunction
// Size: 0x30 // Inherited bytes: 0x28
struct FSolarAggregationTickFunction : FTickFunction {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08
};

