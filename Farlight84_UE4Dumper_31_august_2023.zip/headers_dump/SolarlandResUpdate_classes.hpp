#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class SolarlandResUpdate.DownloadFileTask
// Size: 0xd8 // Inherited bytes: 0x28
struct UDownloadFileTask : UObject {
	// Fields
	struct FMulticastInlineDelegate OnDownloadComplete; // Offset: 0x28 // Size: 0x10
	struct FMulticastInlineDelegate OnDownloadProgress; // Offset: 0x38 // Size: 0x10
	struct FMulticastInlineDelegate OnDownloadFailed; // Offset: 0x48 // Size: 0x10
	char pad_0x58[0x80]; // Offset: 0x58 // Size: 0x80

	// Functions

	// Object Name: Function SolarlandResUpdate.DownloadFileTask.StartDownload
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StartDownload(); // Offset: 0x102f520fc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SolarlandResUpdate.DownloadFileTask.SetSaveToFile
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSaveToFile(bool InSet); // Offset: 0x102f51f68 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function SolarlandResUpdate.DownloadFileTask.SetNeedDecode
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetNeedDecode(bool InNeedDecode); // Offset: 0x102f51fec // Return & Params: Num(1) Size(0x1)

	// Object Name: Function SolarlandResUpdate.DownloadFileTask.SetForceRedownload
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetForceRedownload(bool inForceRedownload); // Offset: 0x102f52074 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function SolarlandResUpdate.DownloadFileTask.GetUrl
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FString GetUrl(); // Offset: 0x102f51ee8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function SolarlandResUpdate.DownloadFileTask.CreateNoFile
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UDownloadFileTask* CreateNoFile(struct FString URL, bool bByChunk); // Offset: 0x102f52110 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function SolarlandResUpdate.DownloadFileTask.Create
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UDownloadFileTask* Create(struct FString URL, struct FString FileDirectory, struct FString Filename, bool bByChunk, bool bForceWrite); // Offset: 0x102f521f0 // Return & Params: Num(6) Size(0x40)
};

// Object Name: Class SolarlandResUpdate.SolarlandResUpdater
// Size: 0x100 // Inherited bytes: 0x28
struct USolarlandResUpdater : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08
	struct TArray<struct FPakFileEntry> ToDownloadPakList; // Offset: 0x30 // Size: 0x10
	struct FDelegate OnPatchPrompt; // Offset: 0x40 // Size: 0x10
	struct FDelegate OnPatchComplete; // Offset: 0x50 // Size: 0x10
	struct FDelegate OnPatchFailed; // Offset: 0x60 // Size: 0x10
	struct FDelegate OnCDNDownloadFailed; // Offset: 0x70 // Size: 0x10
	struct FDelegate OnPatchProgress; // Offset: 0x80 // Size: 0x10
	struct FDelegate OnDownloadServerList; // Offset: 0x90 // Size: 0x10
	struct FDelegate OnServerClose; // Offset: 0xa0 // Size: 0x10
	struct FDelegate OnBackdoorComplete; // Offset: 0xb0 // Size: 0x10
	struct FDelegate OnBackdoorFaild; // Offset: 0xc0 // Size: 0x10
	struct FDelegate OnBackdoorProgress; // Offset: 0xd0 // Size: 0x10
	struct FDelegate OnAnnouncementGet; // Offset: 0xe0 // Size: 0x10
	struct FDelegate OnAnnouncementGetFail; // Offset: 0xf0 // Size: 0x10
};

