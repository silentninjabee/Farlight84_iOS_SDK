#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct SolarlandResUpdate.ServerInfo_Dep
// Size: 0x50 // Inherited bytes: 0x00
struct FServerInfo_Dep {
	// Fields
	struct TArray<struct FGateAddress_Dep> GateList; // Offset: 0x00 // Size: 0x10
	struct TArray<struct FString> CDNList; // Offset: 0x10 // Size: 0x10
	struct FString LatestBuildVersion; // Offset: 0x20 // Size: 0x10
	struct FString SourceBuildVersion; // Offset: 0x30 // Size: 0x10
	struct FString Name; // Offset: 0x40 // Size: 0x10
};

// Object Name: ScriptStruct SolarlandResUpdate.GateAddress_Dep
// Size: 0x20 // Inherited bytes: 0x00
struct FGateAddress_Dep {
	// Fields
	struct FString GateTCPAddr; // Offset: 0x00 // Size: 0x10
	struct FString GateUDPAddr; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct SolarlandResUpdate.PakFileEntry
// Size: 0x38 // Inherited bytes: 0x00
struct FPakFileEntry {
	// Fields
	struct FString Filename; // Offset: 0x00 // Size: 0x10
	struct FString Hash; // Offset: 0x10 // Size: 0x10
	int32_t Order; // Offset: 0x20 // Size: 0x04
	int32_t FileSize; // Offset: 0x24 // Size: 0x04
	struct FString Version; // Offset: 0x28 // Size: 0x10
};

