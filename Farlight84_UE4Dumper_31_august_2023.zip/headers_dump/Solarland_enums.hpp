#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum Solarland.ERoleSkillOperation
enum class ERoleSkillOperation : uint8 {
	None = 0,
	ToNormal = 1,
	ClearCD = 2,
	ResetCD = 3,
	Forbid = 4,
	Unforbid = 5,
	ERoleSkillOperation_MAX = 6
};

// Object Name: Enum Solarland.EBattleEndType
enum class EBattleEndType : uint8 {
	None = 0,
	BattleOver = 1,
	PlayerNotEnough = 2,
	BeginTimeOut = 3,
	Abandoned = 4,
	EBattleEndType_MAX = 5
};

// Object Name: Enum Solarland.ESCTournamentType
enum class ESCTournamentType : uint8 {
	None = 0,
	SingleRace = 1,
	PointRace = 2,
	KnockoutRace = 3,
	ESCTournamentType_MAX = 4
};

// Object Name: Enum Solarland.ESCRoomType
enum class ESCRoomType : uint8 {
	None = 0,
	Normal = 1,
	Tournament = 2,
	TournamentReply = 3,
	ESCRoomType_MAX = 4
};

// Object Name: Enum Solarland.ESCMInGameState
enum class ESCMInGameState : uint8 {
	None = 0,
	InPrepare = 1,
	InBattle = 2,
	InBattleEnd = 3,
	ESCMInGameState_MAX = 4
};

// Object Name: Enum Solarland.ESCMHostType
enum class ESCMHostType : uint8 {
	Global = 0,
	Side = 1,
	Player = 2,
	ESCMHostType_MAX = 3
};

// Object Name: Enum Solarland.ESCMDataRankType
enum class ESCMDataRankType : uint8 {
	None = 0,
	Ascending = 1,
	AscendingReplace = 2,
	Descending = 3,
	DescendingReplace = 4,
	ESCMDataRankType_MAX = 5
};

// Object Name: Enum Solarland.ESCMDataChangeType
enum class ESCMDataChangeType : uint8 {
	Add = 0,
	Change = 1,
	Delete = 2,
	DeleteAll = 3,
	ESCMDataChangeType_MAX = 4
};

// Object Name: Enum Solarland.EStatisticsType
enum class EStatisticsType : uint8 {
	None = 0,
	DSTime = 1,
	G_UnBattleEndPlayerCount = 2,
	G_UnBattleEndSideCount = 3,
	S_KillCount = 4,
	S_KillDownCount = 5,
	S_AssistCount = 6,
	S_DeathCount = 7,
	S_SaveCount = 8,
	S_UnBattleEndPlayerCount = 9,
	G_KillNum = 10,
	G_KillDown = 11,
	KillNum = 12,
	KillNumToRealPlayer = 13,
	P_KillStreak = 14,
	KillStreakHistory = 15,
	CharacterKillNumWithID = 16,
	KillDownNum = 17,
	AssistNum = 18,
	KillNpcNum = 19,
	KillMonster = 20,
	KillPlayer = 21,
	KillTeammate = 22,
	KillDownTeammate = 23,
	TotalWeaponKillNum = 24,
	WeaponAssistWithID = 25,
	WeaponKillNumWithID = 26,
	KillNumWithIDByVechile = 27,
	TotalVehicleKillNum = 28,
	RevengeNum = 29,
	AccurateKillTimes = 30,
	AccurateKillDownTimes = 31,
	WeaponSkillKillNum = 32,
	PunchKill = 33,
	AreaKillNum_Bubble = 34,
	DeathNum = 35,
	DyingCount = 36,
	DyingByNpc = 37,
	DyingByMonster = 38,
	DeathByVechile = 39,
	DeathByBombingArea = 40,
	CauseDamage = 41,
	CauseDamageToRealPlayer = 42,
	WeaponDamageWithIDToPlayer = 43,
	WeaponDamageWithTypeToPlayer = 44,
	VechileDamageWithIDToPlayer = 45,
	TotalVehicleDamage = 46,
	ReceivedDamage = 47,
	DamageByAI = 48,
	DamageByMonster = 49,
	DamageToMonster = 50,
	DamageToNpc = 51,
	AccurateDamage = 52,
	AttackTimes = 53,
	HitTimes = 54,
	HitedTimes = 55,
	AccurateDameageTimes = 56,
	BeAccurateDameageTimes = 57,
	LifeTime = 58,
	HealSelf = 59,
	SaveCount = 60,
	TeammateHeal = 61,
	ReceivedHeal = 62,
	ResurrectionCount = 63,
	CarSkillCount = 64,
	VechileDistance = 65,
	TotalVechileDistance = 66,
	VehicleTime = 67,
	UseVehicleTypes = 68,
	LastUseVehicleID = 69,
	TakeTheCarOfEnemy = 70,
	DriveCarInAirTime = 71,
	DriveHoverCarInWaterDistance = 72,
	WeaponID1 = 73,
	WeaponID2 = 74,
	WeaponLevel1 = 75,
	WeaponLevel2 = 76,
	UseWeaponSkillNum = 77,
	WeaponUseStartTimeWithID = 78,
	WeaponUseTimeWithID = 79,
	MaxGodWeaponNum = 80,
	CollectEnergy = 81,
	EscapeTimes = 82,
	CollectBoxNum = 83,
	CollectBoxNumWithHighQuality = 84,
	FlyCount = 85,
	ArmorUseCount = 86,
	ShieldRechargeCount = 87,
	EChestOpenNumForID = 88,
	DeathPos = 89,
	LandingPos = 90,
	LandingTime = 91,
	DropoutEvent = 92,
	DropoutTime = 93,
	MedicineUseCount = 94,
	RadarUseCount = 95,
	P_BattleResult = 96,
	OpenAirBoxNum = 97,
	KillInAirNum = 98,
	KillDownInAirNum = 99,
	ResurrectionNum = 100,
	ResurrectionCapsule = 101,
	TeamFriendRevive = 102,
	BuyESElectricNum = 103,
	CarFireCount = 104,
	HangTimeDuration = 105,
	SkydiveLandingDuration = 106,
	SwimDistance = 107,
	DanceCount = 108,
	PosionWalkDistance = 109,
	ShieldExpGainCount = 110,
	UpgradeShieldCount = 111,
	UpgradeRedShieldCount = 112,
	JumpBoardUseCount = 113,
	TerminaterCount = 114,
	UltimateSkillUseCount = 115,
	TacticalSkillUseCount = 116,
	UltimateSkillDamage = 117,
	TacticalSkillDamage = 118,
	UltimateSkillTakenDamage = 119,
	TacticalSkillTakenDamage = 120,
	UltimateSkillKillNum = 121,
	TacticalSkillKillNum = 122,
	HasHighlight = 123,
	MAX = 124
};

// Object Name: Enum Solarland.ERecordingType
enum class ERecordingType : uint8 {
	None = 0,
	Local = 1,
	NormalMatch = 2,
	Tournament = 3,
	LiveWatchOnly = 4,
	LocalHighlight = 5,
	ERecordingType_MAX = 6
};

// Object Name: Enum Solarland.EReplayManagerState
enum class EReplayManagerState : uint8 {
	Initializing = 0,
	Idle = 1,
	Recording = 2,
	PlayingTryToStart = 3,
	PlayingStarted = 4,
	PlayingLoadLevelsStarted = 5,
	PlayingLevelLoaded = 6,
	PlayingStreamReadied = 7,
	Playing = 8,
	PlayingAtEnd = 9,
	EReplayManagerState_MAX = 10
};

// Object Name: Enum Solarland.EReplayPlayingFinishReason
enum class EReplayPlayingFinishReason : uint8 {
	Normal = 0,
	GMForce = 1,
	StreamerDownloadChunkTimeout = 2,
	StreamerServiceUnavailable = 3,
	EReplayPlayingFinishReason_MAX = 4
};

// Object Name: Enum Solarland.EMultiplePassMaterialChangeCompatibilityMode
enum class EMultiplePassMaterialChangeCompatibilityMode : uint8 {
	Compatible = 0,
	Incompatible = 1,
	CompatibleWithSpecifiedPriorityTags = 2,
	IncompatibleWithSpecifiedPriorityTags = 3,
	EMultiplePassMaterialChangeCompatibilityMode_MAX = 4
};

// Object Name: Enum Solarland.EMaterialChangeConflictResolveStrategy
enum class EMaterialChangeConflictResolveStrategy : uint8 {
	KeepAll = 0,
	KeepNew = 1,
	KeepOld = 2,
	EMaterialChangeConflictResolveStrategy_MAX = 3
};

// Object Name: Enum Solarland.EWalkMode
enum class EWalkMode : uint8 {
	Idle = 0,
	Run = 1,
	Sprint = 2,
	CrouchIdle = 3,
	CrouchRun = 4,
	CrouchSprint = 5,
	Crawl = 6,
	EWalkMode_MAX = 7
};

// Object Name: Enum Solarland.EAirMoveMode
enum class EAirMoveMode : uint8 {
	None = 0,
	Jump = 1,
	JetFly = 2,
	Cruise = 3,
	Skydive = 4,
	Launch = 5,
	Fall = 6,
	Fly = 7,
	WallRun = 8,
	EAirMoveMode_MAX = 9
};

// Object Name: Enum Solarland.EClientMoveTrustType
enum class EClientMoveTrustType : uint8 {
	TrustLocation = 0,
	TrustLocationAndMovementMode = 1,
	EClientMoveTrustType_MAX = 2
};

// Object Name: Enum Solarland.EBoolean
enum class EBoolean : uint8 {
	BranchFalse = 0,
	BranchTrue = 1,
	EBoolean_MAX = 2
};

// Object Name: Enum Solarland.EActorRegisterType
enum class EActorRegisterType : uint8 {
	EART_None = 0,
	EART_Character = 1,
	EART_Vehicle = 2,
	EART_Turret = 4,
	EART_TreasureBox = 8,
	EART_ChargingPile = 16,
	EART_Summon = 32,
	EART_HumanoidTarget = 64,
	EART_Water = 128,
	EART_MAX = 129
};

// Object Name: Enum Solarland.ESolarNetMode
enum class ESolarNetMode : uint8 {
	NM_Standalone = 0,
	NM_DedicatedServer = 1,
	NM_ListenServer = 2,
	NM_Client = 3,
	NM_MAX = 4,
	NM_Unknown = 5
};

// Object Name: Enum Solarland.ESolarPlayStage
enum class ESolarPlayStage : uint8 {
	None = 0,
	Login = 1,
	Lobby = 2,
	Battle = 3,
	Settlement = 4,
	PlaceHolder1 = 5,
	PlaceHolder2 = 6,
	PlaceHolder3 = 7,
	ESolarPlayStage_MAX = 8
};

// Object Name: Enum Solarland.EItemModifyResult
enum class EItemModifyResult : uint8 {
	Succeed = 0,
	Overflow = 1,
	Deficient = 2,
	IllegalParam = 3,
	Error = 4,
	EItemModifyResult_MAX = 5
};

// Object Name: Enum Solarland.EEnergyUsage
enum class EEnergyUsage : uint8 {
	Box = 0,
	Weapon = 1,
	Ability = 2,
	Jet = 3,
	Pile = 4,
	Armor = 5,
	Shield = 6,
	Sky = 7,
	RadarStation = 8,
	ElectricShop = 9,
	DeathBox = 10,
	EEnergyUsage_MAX = 11
};

// Object Name: Enum Solarland.EItemAppearanceType
enum class EItemAppearanceType : uint8 {
	EApprenace_None = 0,
	EApprenace_Outline = 1,
	EApprenace_Float = 2,
	EApprenace_All = 3,
	EApprenace_MAX = 4
};

// Object Name: Enum Solarland.EItemType
enum class EItemType : int32 {
	NONE = 0,
	SHIELD = 101,
	ARMOR = 102,
	BULLET = 103,
	CARIRIDGE_BAG = 104,
	ARMOR_MATERIAL = 105,
	ENERGY_MODULE = 106,
	EXTRA_ENERGY = 107,
	RADAR_OPERATOR = 108,
	BACKPACK_ENERGY = 109,
	BACKUP_ENERGY = 110,
	SHIELD_RECHARGER = 112,
	BACKPACK_ITEM = 113,
	WEAPON_PARTS = 114,
	JETPACK_MODULE_HORIZONTAL = 111,
	JETPACK_MODULE_VERTICAL = 115,
	REVIVE_ITEM = 116,
	TREASUREBOX = 120,
	AIRDROPBOX = 121,
	DEATHBOX = 122,
	NEUTRAL_CARD = 130,
	SHIELD_UPGRADE_MATERIAL = 148,
	EXP_ITEM = 149,
	WEAPON = 151,
	WEAPON_SKIN = 171,
	BACKPACK = 201,
	TAILFLAME = 202,
	CARDPOSE = 203,
	CARDBACKGROUND = 204,
	CAPSULE = 251,
	CHAR_SKIN_MIN = 301,
	CHAR_ANIMATION_MVP = 302,
	CHAR_SKIN_MAX = 350,
	CHARACTER = 351,
	EXPERIENCE = 401,
	GIFTBAG = 404,
	CHARACTER_TRIALCARD = 405,
	CHARACTERSKIN_TRIALCARD = 406,
	ACTIVENESS = 411,
	WEAPONSKIN_TRIALCARD = 412,
	GIFTBAG_ONBACKPACK = 414,
	BACKPACK_TRIALCARD = 415,
	TAILFLAME_TRIALCARD = 416,
	DIAMOND_VOUCHER = 417,
	LOTCOIN = 421,
	ZOMBORG = 422,
	WISHCOIN = 423,
	SURPRISECOIN = 424,
	TOKEN = 430,
	BUSINESSCARDFRAME = 432,
	AVATARFRAME = 434,
	CHARACTER_SHARD = 435,
	CHARACTER_SKIN_SHARD = 436,
	WEAPON_SKIN_SHARD = 437,
	BACKPACK_SHARD = 438,
	TAILFLAME_SHARD = 439,
	CAPSULE_SHARD = 440,
	VEHICLE_SKIN_SHARD = 441,
	ACCOUNT_AVATAR = 443,
	EMOTE = 444,
	SIGNIN_CARD = 447,
	RAFFLE_TICKET = 448,
	HOMEBUILD = 501,
	HOMEINSTALLATION = 502,
	HOMEITEM = 503,
	HOMEDRAWING = 504,
	HOMEPART = 505,
	HOMEDEVICE = 506,
	HOMEMAX = 520,
	VEHICLE_SKIN = 701,
	SUPPLYBOX = 801,
	DISPLAY_ITEM = 999,
	EItemType_MAX = 1000
};

// Object Name: Enum Solarland.EWeaponSlotType
enum class EWeaponSlotType : int32 {
	EWeaponSlotType_UnArm = -1,
	EWeaponSlotType_Primary = 0,
	EWeaponSlotType_Secondary = 1,
	EWeaponSlotType_Tertiary = 2,
	EWeaponSlotType_MAX = 3
};

// Object Name: Enum Solarland.EGmType
enum class EGmType : uint8 {
	Fetch = 0,
	Discard = 1,
	ClearBackPack = 2,
	Use = 3,
	RemoveWeapon = 4,
	EGmType_MAX = 5
};

// Object Name: Enum Solarland.EEnergyState
enum class EEnergyState : uint8 {
	NORMAL = 0,
	SKY = 1,
	PILE = 2,
	BOX = 4,
	E2M = 8,
	M2E = 16,
	EEnergyState_MAX = 17
};

// Object Name: Enum Solarland.ESocialActionType
enum class ESocialActionType : uint8 {
	None = 0,
	Like = 1,
	Unlike = 2,
	Gift = 3,
	SendTask = 4,
	IncreaseTaskLevel = 5,
	FinishTask = 6,
	ESocialActionType_MAX = 7
};

// Object Name: Enum Solarland.EInteractiveTaskType
enum class EInteractiveTaskType : uint8 {
	None = 0,
	KillWithWeaponType = 1,
	KillWithAnyVehicle = 2,
	KillByFist = 3,
	OpenAirdrop = 4,
	EInteractiveTaskType_MAX = 5
};

// Object Name: Enum Solarland.ESocialCurrencyType
enum class ESocialCurrencyType : uint8 {
	None = 0,
	Gold = 1,
	Diamond = 2,
	ESocialCurrencyType_MAX = 3
};

// Object Name: Enum Solarland.EFindSpectateTargetType
enum class EFindSpectateTargetType : uint8 {
	Teammate = 0,
	PlayerKiller = 1,
	AIKiller = 2,
	AllNonBot = 3,
	All = 4,
	EFindSpectateTargetType_MAX = 5
};

// Object Name: Enum Solarland.EVehicleWeaponScopeType
enum class EVehicleWeaponScopeType : uint8 {
	None = 0,
	Magnifier_X2 = 1,
	Magnifier_X4 = 2,
	Magnifier_X8 = 3,
	Max = 4
};

// Object Name: Enum Solarland.ESpectatePhase
enum class ESpectatePhase : uint8 {
	NotSpectate = 0,
	LookAtSelfDeathBox = 1,
	SpectateTeammates = 2,
	BlockWhenAllTeammatesDead = 3,
	SpectateAllPlayers = 4,
	ESpectatePhase_MAX = 5
};

// Object Name: Enum Solarland.ESolarTablesEnum_BattleUpgradeEffectType
enum class ESolarTablesEnum_BattleUpgradeEffectType : uint8 {
	MaxHp = 0,
	BulletDamage = 1,
	CharacterSkillDamage = 2,
	VehicleWeaponDamage = 3,
	VehicleSkillDamage = 4,
	VehicleStrikeDamage = 5,
	CharacterPunchDamage = 6,
	CharacterUpgradeDamage = 7,
	_Count = 8,
	ESolarTablesEnum_MAX = 9
};

// Object Name: Enum Solarland.EPlayerStateRepType
enum class EPlayerStateRepType : uint8 {
	Character = 0,
	Controller = 1,
	EPlayerStateRepType_MAX = 2
};

// Object Name: Enum Solarland.EPlayerChangedGoldResult
enum class EPlayerChangedGoldResult : uint8 {
	None = 0,
	Success = 1,
	GoldIsNotEnough = 2,
	NetworkError = 3,
	EPlayerChangedGoldResult_MAX = 4
};

// Object Name: Enum Solarland.EPlayerChangedGoldType
enum class EPlayerChangedGoldType : uint8 {
	None = 0,
	CostedGold = 1,
	ReceivedGold = 2,
	EPlayerChangedGoldType_MAX = 3
};

// Object Name: Enum Solarland.EExpBehaviorType
enum class EExpBehaviorType : uint8 {
	None = 0,
	Kill = 1,
	Assist = 2,
	Damage = 3,
	Pickup = 4,
	Survival = 5,
	Spawner = 6,
	Device = 7,
	TreasureBox = 8,
	DeathBox = 9,
	Airdrop = 10,
	EExpBehaviorType_MAX = 11
};

// Object Name: Enum Solarland.EInteractableType
enum class EInteractableType : uint8 {
	FIRECIRCLE = 0,
	JUMPPAD = 1,
	VEHICLEPAD = 2,
	RADARSTATION = 3,
	ELECTRICSHOP = 4,
	CHARGINGPILE = 5,
	SHIELDUPGRADEITEM = 6,
	MAX = 7
};

// Object Name: Enum Solarland.EWorldMarkType
enum class EWorldMarkType : uint8 {
	ITEM = 0,
	INVALID = 1,
	WARNING = 2,
	MINIMAP = 3,
	BIGMAP = 4,
	VEHICLE = 5,
	INTERACTABLEACTOR = 6,
	QUICKCHATWHEEL = 7,
	ATTACHED = 8,
	MAX = 9
};

// Object Name: Enum Solarland.ECharacterStateInGame
enum class ECharacterStateInGame : uint8 {
	None = 0,
	InVehicle = 1,
	Dying = 2,
	Dead = 4,
	MaxState = 7,
	ECharacterStateInGame_MAX = 8
};

// Object Name: Enum Solarland.EPlayerStateInGame
enum class EPlayerStateInGame : uint8 {
	None = 0,
	AppHasDeactivated = 1,
	AppHasReactivated = 2,
	Talking = 4,
	MaxState = 7,
	EPlayerStateInGame_MAX = 8
};

// Object Name: Enum Solarland.EPlayerNetStateInGame
enum class EPlayerNetStateInGame : uint8 {
	None = 0,
	Online = 1,
	Offline = 2,
	EPlayerNetStateInGame_MAX = 3
};

// Object Name: Enum Solarland.ETeamType
enum class ETeamType : uint8 {
	PlayerTeam = 0,
	AITeam = 1,
	OnlyPlayerTeam = 2,
	EmptyTeam = 3,
	AnyTeam = 4,
	ETeamType_MAX = 5
};

// Object Name: Enum Solarland.ETalentState
enum class ETalentState : uint8 {
	Activating = 0,
	CoolingDown = 1,
	Unactivated = 2,
	Invalid = 3,
	ETalentState_MAX = 4
};

// Object Name: Enum Solarland.EAppLifetimeState
enum class EAppLifetimeState : uint8 {
	NONE = 0,
	NORMAL = 1,
	Background = 2,
	Deactive = 3,
	Terminated = 4,
	EAppLifetimeState_MAX = 5
};

// Object Name: Enum Solarland.ESkydivingState
enum class ESkydivingState : uint8 {
	NotStarted = 0,
	PreStart = 1,
	InProgress = 2,
	Completed = 3,
	ESkydivingState_MAX = 4
};

// Object Name: Enum Solarland.ESCMPlayerOutPath
enum class ESCMPlayerOutPath : uint8 {
	None = 0,
	OutFromSettingUI = 1,
	OutBySelf = 2,
	KickOutByServer = 3,
	OBSwitchScene = 4,
	ESCMPlayerOutPath_MAX = 5
};

// Object Name: Enum Solarland.ESCMPlayerPunishType
enum class ESCMPlayerPunishType : uint8 {
	None = 0,
	HangUp = 1,
	DropOut = 2,
	IsolationPool = 3,
	KillTeammate = 4,
	ESCMPlayerPunishType_MAX = 5
};

// Object Name: Enum Solarland.EReplayCameraMode
enum class EReplayCameraMode : uint8 {
	None = 0,
	ThirdPersonMode = 1,
	LockMode = 2,
	FreeMode = 3,
	LookAtMode = 4,
	CircularMode = 5,
	EReplayCameraMode_MAX = 6
};

// Object Name: Enum Solarland.ESkydiveStage
enum class ESkydiveStage : uint8 {
	None = 0,
	Flying = 1,
	Landing = 2,
	ESkydiveStage_MAX = 3
};

// Object Name: Enum Solarland.ESolarCharacterType
enum class ESolarCharacterType : uint8 {
	ESolarCharacterType_None = 0,
	ESolarCharacterType_Player = 1,
	ESolarCharacterType_Bot = 2,
	ESolarCharacterType_Monster = 3,
	ESolarCharacterType_MAX = 4
};

// Object Name: Enum Solarland.ECharacterSoundOpt
enum class ECharacterSoundOpt : uint8 {
	None = 0,
	Shield_Hit_1P = 1,
	Shield_Hit_3P = 2,
	Shield_Broken_1P = 3,
	Shield_Broken_3P = 4,
	Vehicle_Speedboard_1P = 5,
	Body_Hit_With_Bullet_Common_1P = 6,
	Body_Hit_By_Bullet_Common_1P = 7,
	Body_Hit_With_Punch_Common_1P = 8,
	Body_Hit_By_Punch_Common_1P = 9,
	Headshot_1P = 10,
	Headshot_Kill_UI = 11,
	Shot_Down_UI = 12,
	Shot_Down_1P = 13,
	Shot_Down_3P = 14,
	Shot_Down_3P_Enemy = 15,
	Death_UI = 16,
	Death_1P = 17,
	Death_3P = 18,
	Airborne_Fall_Start_1P = 19,
	Water_Fall_1P = 20,
	Water_Fall_3P = 21,
	Water_Fall_3P_Enemy = 22,
	Squat_1P = 23,
	Squat_3P = 24,
	Squat_3P_Enemy = 25,
	Stop_Climb_1P = 26,
	Stop_Climb_3P = 27,
	Stop_Climb_3P_Enemy = 28,
	Loop_Knapsack_Solar_Percent_1P = 29,
	Stop_Knapsack_Solar_Percent_1P = 30,
	Knapsack_Solar_Charging_Done_1P = 31,
	Knapsack_Solar_On_1P = 32,
	Knapsack_Solar_Off_1P = 33,
	Sniper_B01_Skill_On_1P = 34,
	Sniper_B01_Skill_Off_1P = 35,
	B9A04_Skill_Loop_1P = 36,
	B9A04_Skill_Loop_3P = 37,
	B9A04_Skill_Loop_3P_Enemy = 38,
	B9A04_Skill_Loop_End_1P = 39,
	B9A04_Skill_Loop_End_3P = 40,
	B9A04_Skill_Loop_End_3P_Enemy = 41,
	Knapsack_Landing_1P = 42,
	Knapsack_Landing_3P = 43,
	Knapsack_Landing_3P_Enemy = 44,
	Knapsack_Fly_Water_1P = 45,
	Knapsack_Fly_Water_3P = 46,
	Knapsack_Fly_Water_3P_Enemy = 47,
	Play_Shield_OneSet_1P = 48,
	Play_Shield_OneSet_3P = 49,
	Play_Shield_OneSet_3P_Enemy = 50,
	Play_Shield_Charging_1P = 51,
	Play_Shield_Multi_Charging_1P = 52,
	Play_Shield_Charging_3P = 53,
	Play_Shield_Charging_3P_Enemy = 54,
	Play_Shield_Charged_1P = 55,
	Play_Shield_Charged_3P = 56,
	Play_Shield_Charged_3P_Enemy = 57,
	Play_Shield_Charge_To_Max_1P = 58,
	Play_Shield_Charge_To_Max_3P = 59,
	Play_Shield_Charge_To_Max_3P_Enemy = 60,
	Play_Shield_Charge_Break_1P = 61,
	Play_Shield_Charge_Break_3P = 62,
	Play_Shield_Charge_Break_3P_Enemy = 63,
	Play_Hit_By_EMP_1P = 64,
	Play_Hit_By_EMP_3P = 65,
	Play_Hit_By_EMP_3P_Enemy = 66,
	Stop_Hit_By_EMP_1P = 67,
	Stop_Hit_By_EMP_3P = 68,
	Stop_Hit_By_EMP_3P_Enemy = 69,
	Play_Monster_Appear = 70,
	Play_Monster_Die = 71,
	Play_Heal_Wrap_1P = 72,
	Play_Heal_Wrap_3P = 73,
	Play_Heal_Wrap_3P_Enemy = 74,
	Stop_Heal_Wrap_1P = 75,
	Stop_Heal_Wrap_3P = 76,
	Stop_Heal_Wrap_3P_Enemy = 77,
	Play_Heal_Wrap_Cancel_1P = 78,
	Play_Heal_Wrap_Cancel_3P = 79,
	Play_Heal_Wrap_Cancel_3P_Enemy = 80,
	Play_Heal_Wrap_Complete_1P = 81,
	Play_Heal_Wrap_Complete_3P = 82,
	Play_Heal_Wrap_Complete_3P_Enemy = 83,
	Stop_Shield_Charging_1P = 84,
	Stop_Shield_Charging_3P = 85,
	Stop_Shield_Charging_3P_Enemy = 86,
	Mark_Select_Dial_UI = 87,
	Mark_Select_Pin_UI = 88,
	Mark_Select_Cancel_UI = 89,
	Mark_Select_Common_UI = 90,
	Mark_Danger_UI = 91,
	Play_Skill_Fast_Reload = 92,
	Play_char_skill_passive_targetlock = 93,
	Max = 94
};

// Object Name: Enum Solarland.EWeaponType
enum class EWeaponType : uint8 {
	AssualtRifle = 0,
	Submachinegun = 1,
	Shotgun = 2,
	Sniper = 3,
	VehicleMounted = 4,
	ItemWeapon = 5,
	SummonWeapon = 6,
	AntiVehicle = 7,
	Unarm = 8,
	Unknown = 9,
	EWeaponType_MAX = 10
};

// Object Name: Enum Solarland.ESCMDamageType
enum class ESCMDamageType : uint8 {
	Point = 0,
	Poison = 1,
	Bomb = 2,
	AirDrop = 3,
	Dying = 4,
	VehicleHit = 5,
	VehicleExplosion = 6,
	Weapon = 7,
	UnarmWeapon = 8,
	VehicleWeapon = 9,
	SummonWeapon = 10,
	VehicleAbility = 11,
	WeaponAbility = 12,
	HelplessDeathVerge = 13,
	DeathVergeInWater = 14,
	GMCmd = 15,
	BackToLobby = 16,
	AppEnterBackground = 17,
	LongTimeDisconnect = 18,
	ClassSkill = 19,
	TacticalSkill = 20,
	ESCMDamageType_MAX = 21
};

// Object Name: Enum Solarland.EDamageResultType
enum class EDamageResultType : uint8 {
	Normal = 0,
	Down = 1,
	Die = 2,
	EDamageResultType_MAX = 3
};

// Object Name: Enum Solarland.EHealthChangeType
enum class EHealthChangeType : uint8 {
	Normal = 0,
	Self = 1,
	Ability = 2,
	Ability_Deadly = 3,
	Item = 4,
	Teammate = 5,
	Environment = 6,
	EHealthChangeType_MAX = 7
};

// Object Name: Enum Solarland.ESolarAttributeType
enum class ESolarAttributeType : uint8 {
	ESolarAttributeType_None = 0,
	ESolarAttributeType_BasePhysicalDamage = 1,
	ESolarAttributeType_BaseEnergyDamage = 2,
	ESolarAttributeType_Health = 3,
	ESolarAttributeType_DeadlyDamage = 4,
	ESolarAttributeType_Energy = 5,
	ESolarAttributeType_Shield = 6,
	ESolarAttributeType_Weapon = 7,
	ESolarAttributeType_Mark = 8,
	ESolarAttributeType_MaxHealth = 9,
	ESolarAttributeType_MaxItemPile = 10,
	ESolarAttributeType_MoveSpeed = 11,
	ESolarAttributeType_ShieldRechargeCost = 12,
	ESolarAttributeType_Max = 13
};

// Object Name: Enum Solarland.EShieldUpgradeInteractAckType
enum class EShieldUpgradeInteractAckType : uint8 {
	Success = 0,
	ItemReachLimit = 1,
	AlreadyInteracted = 2,
	SuccessWithReconnect = 3,
	EShieldUpgradeInteractAckType_MAX = 4
};

// Object Name: Enum Solarland.EShieldCancelRechargeReason
enum class EShieldCancelRechargeReason : uint8 {
	None = 0,
	StopAutoRecharge = 1,
	EShieldCancelRechargeReason_MAX = 2
};

// Object Name: Enum Solarland.ESolarHitType
enum class ESolarHitType : uint8 {
	None = 0,
	Character_Hit = 1,
	Character_Kill = 2,
	Character_BreakArmor = 3,
	Character_BreakShield = 4,
	Character_PendingKill = 5,
	Character_Headshot = 6,
	Character_HitShield = 7,
	Character_HitArmor = 8,
	Character_HitDown = 9,
	Character_HeadshotKill = 10,
	Vehicle_Hit = 51,
	Vehicle_HitWeakness = 52,
	ESolarHitType_MAX = 53
};

// Object Name: Enum Solarland.EPlayerWeaponMsgType
enum class EPlayerWeaponMsgType : uint8 {
	EPlayerWeaponMsgType_HitPawn = 0,
	EPlayerWeaponMsgType_PlayerAssist = 1,
	EPlayerWeaponMsgType_NpcAssist = 2,
	EPlayerWeaponMsgType_SafeAreaUpdate = 3,
	EPlayerWeaponMsgType_ForbidShooting = 4,
	EPlayerWeaponMsgType_AddExp = 5,
	EPlayerWeaponMsgType_Max = 6
};

// Object Name: Enum Solarland.EShieldRechargeState
enum class EShieldRechargeState : uint8 {
	AutoRecharge = 0,
	ManualRecharge = 1,
	None = 2,
	EShieldRechargeState_MAX = 3
};

// Object Name: Enum Solarland.ECharacterOperation
enum class ECharacterOperation : uint8 {
	ECharacterOperation_None = 0,
	ECharacterOperation_OpenScope = 1,
	ECharacterOperation_CloseScope = 2,
	ECharacterOperation_OpenScopeInstant = 3,
	ECharacterOperation_MAX = 4
};

// Object Name: Enum Solarland.EItemChangeType
enum class EItemChangeType : uint8 {
	Default = 0,
	PickUp = 1,
	Drop = 2,
	EItemChangeType_MAX = 3
};

// Object Name: Enum Solarland.ECustomJumpType
enum class ECustomJumpType : uint8 {
	None = 0,
	Jump = 1,
	Launch = 2,
	ECustomJumpType_MAX = 3
};

// Object Name: Enum Solarland.EDriveState
enum class EDriveState : uint8 {
	None = 0,
	Driver = 1,
	Passenger = 2,
	EDriveState_MAX = 3
};

// Object Name: Enum Solarland.ERoleSkillStatus
enum class ERoleSkillStatus : uint8 {
	Normal = 0,
	InCD = 1,
	Forbidden = 2,
	ERoleSkillStatus_MAX = 3
};

// Object Name: Enum Solarland.ESpecAnimInstType
enum class ESpecAnimInstType : uint8 {
	Base = 0,
	Vehicle = 1,
	OneHandThrow = 2,
	KeepFiring = 3,
	Gatling = 4,
	CardsThrow = 5,
	DuckRolling = 6,
	ESpecAnimInstType_MAX = 7
};

// Object Name: Enum Solarland.EWeaponPartType
enum class EWeaponPartType : uint8 {
	Muzzle = 0,
	Scope = 1,
	Clip = 2,
	Rune = 3,
	Grip = 4,
	GunStock = 5,
	Scope2x = 6,
	Scope4x = 7,
	Scope8x = 8,
	MAX = 9
};

// Object Name: Enum Solarland.EVelocityStatus
enum class EVelocityStatus : uint8 {
	Any = 0,
	Stationary = 1,
	Moving = 2,
	EVelocityStatus_MAX = 3
};

// Object Name: Enum Solarland.EShieldWidgetState
enum class EShieldWidgetState : uint8 {
	None = 0,
	PreAdd = 1,
	DoAdd = 2,
	CancelAdd = 3,
	DoSub = 4,
	EShieldWidgetState_MAX = 5
};

// Object Name: Enum Solarland.EEnterBattleType
enum class EEnterBattleType : uint8 {
	OnHit = 0,
	OnWeaponFire = 1,
	NotEnter = 2,
	EEnterBattleType_MAX = 3
};

// Object Name: Enum Solarland.EShieldState
enum class EShieldState : uint8 {
	NONE = 0,
	SPAWN = 1,
	NORMAL = 2,
	RECHARGE = 3,
	BREAK = 4,
	PILE = 5,
	MAX = 6
};

// Object Name: Enum Solarland.ESolarTreatmentState
enum class ESolarTreatmentState : uint8 {
	None = 0,
	Treating = 1,
	End = 2,
	ESolarTreatmentState_MAX = 3
};

// Object Name: Enum Solarland.EShieldSoundType
enum class EShieldSoundType : uint8 {
	StartRecharge = 0,
	Charging = 1,
	Charged = 2,
	ChargedToMax = 3,
	ChargeBreak = 4,
	ShieldHitted = 5,
	ShieldBroken = 6,
	StopRecharge = 7,
	MultiCharging = 8,
	EShieldSoundType_MAX = 9
};

// Object Name: Enum Solarland.EShieldSoundEventType
enum class EShieldSoundEventType : uint8 {
	Type_1P = 0,
	Type_3P = 1,
	Type_3P_Enemy = 2,
	Type_MAX = 3
};

// Object Name: Enum Solarland.EIdleTurnType
enum class EIdleTurnType : uint8 {
	Turn_Idle = 0,
	Turn_Left = 1,
	Turn_Right = 2,
	Turn_MAX = 3
};

// Object Name: Enum Solarland.ETreasureBoxState
enum class ETreasureBoxState : uint8 {
	None = 0,
	Close = 1,
	Open = 2,
	ETreasureBoxState_MAX = 3
};

// Object Name: Enum Solarland.EWallRunState
enum class EWallRunState : uint8 {
	WallRunning = 0,
	Success = 1,
	EWallRunState_MAX = 2
};

// Object Name: Enum Solarland.ESkillAnimRightHandType
enum class ESkillAnimRightHandType : uint8 {
	Default = 0,
	Card = 1,
	ESkillAnimRightHandType_MAX = 2
};

// Object Name: Enum Solarland.ESkillAnimType
enum class ESkillAnimType : uint8 {
	None = 0,
	SkillWithoutAnim = 1,
	OneHandThrow = 2,
	DoubleHandsThrow = 3,
	KeepFiring = 4,
	Gatling = 5,
	CardsThrow = 6,
	DuckRolling = 7,
	ESkillAnimType_MAX = 8
};

// Object Name: Enum Solarland.ECruiseState
enum class ECruiseState : uint8 {
	None = 0,
	Boarded = 1,
	CruisePendingStarted = 2,
	CruiseStarted = 3,
	ParachuteAllowed = 4,
	ParachutePendingStarted = 5,
	ParachuteStarted = 6,
	End = 7,
	Max = 8
};

// Object Name: Enum Solarland.EJetFlyType
enum class EJetFlyType : uint8 {
	None = 0,
	VerticalJetFly = 1,
	HorizontalJetFly = 2,
	CustomJetFly = 3,
	EJetFlyType_MAX = 4
};

// Object Name: Enum Solarland.ERescueState
enum class ERescueState : uint8 {
	EState_None = 0,
	EState_Dying = 1,
	EState_Rescuing = 2,
	EState_BeingRescue = 3,
	EState_MAX = 4
};

// Object Name: Enum Solarland.EBackpackPropellingMode
enum class EBackpackPropellingMode : uint8 {
	Default = 0,
	Skydive = 1,
	EBackpackPropellingMode_MAX = 2
};

// Object Name: Enum Solarland.EFXJetType
enum class EFXJetType : uint8 {
	JetDefault = 0,
	JetSingle = 1,
	JetLoop = 2,
	VerticalLaunch = 3,
	WallRun = 4,
	EFXJetType_MAX = 5
};

// Object Name: Enum Solarland.ECharacterBodyScaleType
enum class ECharacterBodyScaleType : uint8 {
	None = 0,
	Woman = 1,
	Man = 2,
	DuckMan = 3,
	SmallWoman = 4,
	ECharacterBodyScaleType_MAX = 5
};

// Object Name: Enum Solarland.EAirDropOpenState
enum class EAirDropOpenState : uint8 {
	Closed = 0,
	Opening = 1,
	Opened = 2,
	EAirDropOpenState_MAX = 3
};

// Object Name: Enum Solarland.EAirDropMovementState
enum class EAirDropMovementState : uint8 {
	None = 0,
	Waiting = 1,
	Falling = 2,
	Landed = 3,
	Removed = 4,
	EAirDropMovementState_MAX = 5
};

// Object Name: Enum Solarland.EAlertDirection
enum class EAlertDirection : uint8 {
	Forward = 0,
	Backward = 1,
	Left = 2,
	Right = 3,
	EAlertDirection_MAX = 4
};

// Object Name: Enum Solarland.EShotMomentFlag
enum class EShotMomentFlag : uint8 {
	shotting = 0,
	hit = 1,
	killed = 2,
	invalid = 3,
	EShotMomentFlag_MAX = 4
};

// Object Name: Enum Solarland.EShotModeFlag
enum class EShotModeFlag : uint8 {
	orgin = 0,
	d3d = 1,
	dwm = 2,
	rand = 3,
	EShotModeFlag_MAX = 4
};

// Object Name: Enum Solarland.ESolarInputMode
enum class ESolarInputMode : uint8 {
	GameOnly = 0,
	GameAndUI = 1,
	UIOnly = 2,
	ESolarInputMode_MAX = 3
};

// Object Name: Enum Solarland.EPassiveTriggeredVoice
enum class EPassiveTriggeredVoice : int32 {
	NOVOICE = 0,
	TakeIt = 1002,
	Alright = 1003,
	GotIt = 1004,
	MarkLocation = 1005,
	AirdropsDelivering = 4001,
	AirdropsDelivered = 4002,
	Remaining3EnemySuqads = 4003,
	Remaining2EnemySuqads = 4004,
	Remaining1EnemySuqads = 4005,
	SafeZoneRetract30s = 4006,
	ResurrectionPeriodEnded = 4007,
	WelcomeToFarlight84 = 4008,
	AirdropsArriveIn60 = 4009,
	AirdropsArriveIn45 = 4010,
	AirdropsArriveIn30 = 4011,
	CharAppear = 5000,
	UsingMedicine = 5001,
	AddingShield = 5002,
	Reloading = 5003,
	HelpingTeammate = 5004,
	HitEnemy = 5005,
	KillEnemy = 5006,
	DestroyOtherTeam = 5007,
	ReviveTeammate = 5008,
	TakeDamage = 5009,
	Defeated = 5010,
	GetKilled = 5011,
	TeammataDefeated = 5012,
	TooFarApart = 5013,
	Charging50 = 5014,
	ChargingFinish = 5015,
	BecomeKillLeader = 5016,
	BackInTheFight = 5017,
	ParachuteFollowMe = 5018,
	ParachuteStartJump = 5019,
	NeedWeapons = 2009,
	NeedVehicle = 2010,
	NeedMuzzle = 3001,
	NeedGrip = 3002,
	NeedMagazine = 3003,
	NeedStock = 3004,
	NeedScope = 3005,
	NeedShield = 3006,
	NeedBatteryPack = 3007,
	NeedHorizontalCooldown = 3008,
	NeedVerticalCooldown = 3009,
	NeedSMGAmmo = 3010,
	NeedShutGunAmmo = 3011,
	NeedRifleAmmo = 3012,
	NeedSniperAmmo = 3013,
	NeedMedKit = 3014,
	NeedShieldRestorer = 3015,
	NeedSpecialWeapon = 3016,
	NeedRespawnPod = 3017,
	NeedBigShield = 3018,
	UseSuperSkill = 5021,
	Level1 = 2301,
	Level2 = 2303,
	Level3 = 2303,
	Level4 = 2304,
	Level5 = 2305,
	EPassiveTriggeredVoice_MAX = 5022
};

// Object Name: Enum Solarland.EInputSwitchType
enum class EInputSwitchType : uint8 {
	ActionBinding = 0,
	ActionRemove = 1,
	AxisBinding = 2,
	AxisRemove = 3,
	EInputSwitchType_MAX = 4
};

// Object Name: Enum Solarland.EVehicleClass
enum class EVehicleClass : uint8 {
	All = 0,
	Wheeled = 1,
	Legged = 2,
	Hover = 3,
	EVehicleClass_MAX = 4
};

// Object Name: Enum Solarland.EWeaponUIType
enum class EWeaponUIType : uint8 {
	All = 0,
	AssualtRifle = 1,
	Submachinegun = 2,
	Shotgun = 3,
	Sniper = 4,
	Others = 5,
	EWeaponUIType_MAX = 6
};

// Object Name: Enum Solarland.ECustomParamValueType
enum class ECustomParamValueType : uint8 {
	None = 0,
	Bool = 1,
	Int = 2,
	Float = 3,
	Enum_S = 4,
	Enum_M = 5,
	AvailableWeapons = 6,
	AvailableVehicles = 7,
	ECustomParamValueType_MAX = 8
};

// Object Name: Enum Solarland.ERemovedReasonType
enum class ERemovedReasonType : uint8 {
	None = 0,
	TimeOut = 1,
	Abandoned = 2,
	OwnerKick = 3,
	NotEnough = 4,
	ERemovedReasonType_MAX = 5
};

// Object Name: Enum Solarland.EResurrectionState
enum class EResurrectionState : uint8 {
	Alive = 0,
	WaitingTeammatesHelp = 1,
	TimeOut = 2,
	AllTeammatesDied = 3,
	LeaveBattle = 4,
	EResurrectionState_MAX = 5
};

// Object Name: Enum Solarland.ESCMPlayerOutType
enum class ESCMPlayerOutType : uint8 {
	None = 0,
	SelfLogout = 1,
	BattleEnd = 2,
	SelfEnd = 3,
	OfflineEnd = 4,
	Cheating = 5,
	Abnormal = 6,
	ESCMPlayerOutType_MAX = 7
};

// Object Name: Enum Solarland.EFileDownloadError
enum class EFileDownloadError : uint8 {
	None = 0,
	ConnectFailed = 1,
	RequestHeadFailed = 2,
	CreateFileFailed = 3,
	DownloadFailed = 4,
	WriteFailed = 5,
	DeleteOldFailed = 6,
	MoveFailed = 7,
	EFileDownloadError_MAX = 8
};

// Object Name: Enum Solarland.EDownloadFailedStep
enum class EDownloadFailedStep : uint8 {
	DownloadServerListFailed = 0,
	DownloadPakListFailed = 1,
	DownloadPakFileFailed = 2,
	MountPakFileFailed = 3,
	EDownloadFailedStep_MAX = 4
};

// Object Name: Enum Solarland.ESolarIgnoreCollisionType
enum class ESolarIgnoreCollisionType : uint8 {
	EnergyShield = 0,
	ESolarIgnoreCollisionType_MAX = 1
};

// Object Name: Enum Solarland.EPickupItemType
enum class EPickupItemType : uint8 {
	None = 0,
	Normal = 1,
	TreasureBox = 2,
	DeathBox = 3,
	HomeItem = 4,
	EPickupItemType_MAX = 5
};

// Object Name: Enum Solarland.EJetFlyForbiddenType
enum class EJetFlyForbiddenType : uint8 {
	Water = 0,
	Climb = 1,
	EJetFlyForbiddenType_MAX = 2
};

// Object Name: Enum Solarland.ECountDownState
enum class ECountDownState : uint8 {
	CD_Normal = 0,
	CD_Buff = 1,
	CD_MAX = 2
};

// Object Name: Enum Solarland.EHitTraceType
enum class EHitTraceType : uint8 {
	Default = 0,
	Sniper = 1,
	Melee = 2,
	Vehicle = 3,
	EHitTraceType_MAX = 4
};

// Object Name: Enum Solarland.EInputButton
enum class EInputButton : uint8 {
	EInputButton_None = 0,
	EInputButton_Jump = 1,
	EInputButton_RechargeShield = 2,
	EInputButton_BigRechargeShield = 3,
	EInputButton_Crouch = 4,
	EInputButton_JetVertical = 5,
	EInputButton_JetHorizontal = 6,
	EInputButton_Fire = 7,
	EInputButton_LeftFire = 8,
	EInputButton_AltFire = 9,
	EInputButton_QuickAds = 10,
	EInputButton_FreeLook = 11,
	EInputButton_Interact = 12,
	EInputButton_InteractAlternative = 13,
	EInputButton_Reload = 14,
	EInputButton_TogglePrimaryWeapon = 15,
	EInputButton_ToggleSecondaryWeapon = 16,
	EInputButton_ToggleTertiaryWeapon = 17,
	EInputButton_TogglePrimaryWeapon_Checkbox = 18,
	EInputButton_ToggleSecondaryWeapon_Checkbox = 19,
	EInputButton_ToggleTertiaryWeapon_Checkbox = 20,
	EInputButton_ToggleGunsight = 21,
	EInputButton_Gunsight = 22,
	EInputButton_SprintFreeOnPC = 23,
	EInputButton_SprintFreeOnMobile = 24,
	EInputButton_SprintLock = 25,
	EInputButton_Equip1 = 26,
	EInputButton_Equip2 = 27,
	EInputButton_Map = 28,
	EInputButton_Eject = 29,
	EInputButton_OutVehicle = 30,
	EInputButton_Backpack = 31,
	EInputButton_UseMedicine = 32,
	EInputButton_Pickup = 33,
	EInputButton_TogglePickup = 34,
	EInputButton_SwitchFireMode = 35,
	EInputButton_SwitchToSeat1 = 36,
	EInputButton_SwitchToSeat2 = 37,
	EInputButton_SwitchToSeat3 = 38,
	EInputButton_SwitchToSeat4 = 39,
	EInputButton_VehicleAbility1 = 40,
	EInputButton_VehicleAbility2 = 41,
	EInputButton_RoleSkillSuper = 42,
	EInputButton_RoleSkillTactical = 43,
	EInputButton_ShieldUpgrade = 44,
	EInputButton_ShieldUpgradeCancel = 45,
	EInputButton_Max = 46
};

// Object Name: Enum Solarland.EKillParamsCompressInfo
enum class EKillParamsCompressInfo : int32 {
	Default = 0,
	bKillLeaderChange = 1,
	bKillLeaderShutDown = 2,
	bRevenge = 4,
	bShutDown = 8,
	bDown = 16,
	bClearTeam = 32,
	bKillDefender = 64,
	bKillerDead = 128,
	bHitHead = 256,
	bKillLeaderKill = 512,
	EKillParamsCompressInfo_MAX = 513
};

// Object Name: Enum Solarland.ESpectateReferToState
enum class ESpectateReferToState : uint8 {
	Invalid = 0,
	Enter = 1,
	Change = 2,
	Exit = 3,
	ESpectateReferToState_MAX = 4
};

// Object Name: Enum Solarland.EVehicleInterationUIState
enum class EVehicleInterationUIState : uint8 {
	None = 0,
	Repair = 1,
	Drive = 2,
	Passenger = 4,
	Backpacker = 8,
	EVehicleInterationUIState_MAX = 9
};

// Object Name: Enum Solarland.ETransformerType
enum class ETransformerType : uint8 {
	Wheeled = 0,
	Legged = 1,
	Max = 2
};

// Object Name: Enum Solarland.EPlayerNamePanelScale
enum class EPlayerNamePanelScale : uint8 {
	ExtraSmallSize = 0,
	SmallSize = 1,
	DefaultSize = 2,
	LargeSize = 3,
	ExtraLargeSize = 4,
	EPlayerNamePanelScale_MAX = 5
};

// Object Name: Enum Solarland.EBattleOBHUDType
enum class EBattleOBHUDType : uint8 {
	None = 0,
	SpectatePlayer = 1,
	FreeView = 2,
	Director = 3,
	EBattleOBHUDType_MAX = 4
};

// Object Name: Enum Solarland.EReplayActivityHeatKillUseType
enum class EReplayActivityHeatKillUseType : uint8 {
	None = 0,
	Weapon = 1,
	Vehicle = 2,
	Skill = 3,
	EReplayActivityHeatKillUseType_MAX = 4
};

// Object Name: Enum Solarland.EPlayerActivityHeatType
enum class EPlayerActivityHeatType : uint8 {
	None = 0,
	Parachute = 1,
	ResurrectionParachute = 2,
	KillDown = 3,
	MultiKill = 4,
	BeKillDown = 5,
	Death = 6,
	Win = 7,
	Max = 8
};

// Object Name: Enum Solarland.EOBPlayerHeadInfoWidgetStyle
enum class EOBPlayerHeadInfoWidgetStyle : uint8 {
	NearMode = 0,
	MiddleMode = 1,
	FarMode = 2,
	MAX = 3
};

// Object Name: Enum Solarland.EUIPanelName
enum class EUIPanelName : uint8 {
	None = 0,
	SolarBattleControll = 1,
	WorldMarkPanel = 2,
	WeaponCrosshairPanel = 3,
	SolarBattle_Backpack = 4,
	Separate_Discarded_MultiItem = 5,
	HUD_ElectricShop = 6,
	BigMapUMG = 7,
	HUD_CustomizedNotice = 8,
	UI_Settings = 9,
	UI_OB_Root = 10,
	UI_OB_GlobalControl = 11,
	UI_OB_BigMap = 12,
	UI_OB_Settlement = 13,
	UI_OB_Settlement_InputMask = 14,
	UI_OB_HeadInfo = 15,
	UI_OB_ShortKeyboard = 16,
	UI_OpeningShow = 17,
	UI_Eliminate = 18,
	UI_Skill_Scan = 19,
	UI_HeroPick = 20,
	JobEffectDetailPanel = 21,
	UI_BuffEffectScreenPanel = 22,
	UI_TestCustomPanel = 23,
	Solarland_DevDebugUI_Widget = 24,
	UI_Highlight_Overview = 25,
	EUIPanelName_MAX = 26
};

// Object Name: Enum Solarland.EWidgetBackKeyType
enum class EWidgetBackKeyType : uint8 {
	Invalid = 0,
	FromKey = 1,
	FromClose = 2,
	EWidgetBackKeyType_MAX = 3
};

// Object Name: Enum Solarland.EInputCapture
enum class EInputCapture : uint8 {
	EIC_None = 0,
	EIC_Start = 1,
	EIC_End = 2,
	EIC_Move = 4,
	EIC_Transient = 3,
	EIC_All = 7,
	EIC_MAX = 8
};

// Object Name: Enum Solarland.EWidgetScope
enum class EWidgetScope : uint8 {
	World = 0,
	Global = 1,
	EWidgetScope_MAX = 2
};

// Object Name: Enum Solarland.EWidgetLayerLevel
enum class EWidgetLayerLevel : uint8 {
	NormalWidget = 0,
	SameLevelCacheWidget = 1,
	SameLevelReplaceWidget = 2,
	CloseAllBackKeyWidget = 3,
	CloseAllBackKeyAndNormalWidget = 4,
	EWidgetLayerLevel_MAX = 5
};

// Object Name: Enum Solarland.EImageURLDownloadState
enum class EImageURLDownloadState : uint8 {
	NotStarted = 0,
	Processing = 1,
	Success = 2,
	Failed = 3,
	EImageURLDownloadState_MAX = 4
};

// Object Name: Enum Solarland.ECustomGameModeTypeForUI
enum class ECustomGameModeTypeForUI : uint8 {
	Type_Default = 0,
	Type_Sabotage = 1,
	Type_MAX = 2
};

// Object Name: Enum Solarland.EShopWeaponUpgradeState
enum class EShopWeaponUpgradeState : uint8 {
	Upgrade_None = 0,
	Upgrade_Enable = 1,
	Upgrade_Max = 2,
	Upgrade_NotEnoughEnergy = 3
};

// Object Name: Enum Solarland.EActionWheelOperateType
enum class EActionWheelOperateType : uint8 {
	NeedClick = 0,
	AutoCommand = 1,
	EActionWheelOperateType_MAX = 2
};

// Object Name: Enum Solarland.EActionWheelCommandType
enum class EActionWheelCommandType : uint8 {
	None = 0,
	UseItem = 1,
	WorldMark = 2,
	UseSticker = 3,
	PlayAnimation = 4,
	Max = 5
};

// Object Name: Enum Solarland.EActorMaterialChangeRebuildReason
enum class EActorMaterialChangeRebuildReason : uint8 {
	OriginalMeshChanged = 0,
	MeshAddedOrRemoved = 1,
	EActorMaterialChangeRebuildReason_MAX = 2
};

// Object Name: Enum Solarland.EMaterialChangeTextureOverrideMode
enum class EMaterialChangeTextureOverrideMode : uint8 {
	None = 0,
	OverrideAllTextures = 1,
	OverrideSpecifiedTextures = 2,
	EMaterialChangeTextureOverrideMode_MAX = 3
};

// Object Name: Enum Solarland.EMaterialParameterTypeFlags
enum class EMaterialParameterTypeFlags : uint8 {
	None = 0,
	Scaler = 1,
	Vector = 2,
	Texture = 4,
	Font = 8,
	AllWithoutFont = 7,
	All = 15,
	EMaterialParameterTypeFlags_MAX = 16
};

// Object Name: Enum Solarland.EMaterialParameterType2
enum class EMaterialParameterType2 : uint8 {
	Scaler = 0,
	Vector = 1,
	Texture = 2,
	Font = 3,
	EMaterialParameterType2_MAX = 4
};

// Object Name: Enum Solarland.EMaterialChangeType
enum class EMaterialChangeType : uint8 {
	Normal = 0,
	MultiplePass = 1,
	EMaterialChangeType_MAX = 2
};

// Object Name: Enum Solarland.EActorParticleEffectAttachOption
enum class EActorParticleEffectAttachOption : uint8 {
	None = 0,
	AttachToActor = 1,
	AttachToMesh = 2,
	EActorParticleEffectAttachOption_MAX = 3
};

// Object Name: Enum Solarland.EOperator
enum class EOperator : uint8 {
	IDLE = 0,
	ADD = 1,
	MINUS = 2,
	CANCEL = 3,
	EOperator_MAX = 4
};

// Object Name: Enum Solarland.EBulletTraceTargetType
enum class EBulletTraceTargetType : uint8 {
	None = 0,
	Character = 1,
	Vehicle = 4,
	SummonItem = 8,
	EBulletTraceTargetType_MAX = 9
};

// Object Name: Enum Solarland.EBounceType
enum class EBounceType : uint8 {
	NONE = 0,
	ONCE = 1,
	STICK = 2,
	MAX = 3
};

// Object Name: Enum Solarland.ETriggerType
enum class ETriggerType : uint8 {
	KEY_DOWN = 0,
	KEY_UP = 1,
	KEY_HOLD = 2,
	MAX = 3
};

// Object Name: Enum Solarland.EHoldActionType
enum class EHoldActionType : uint8 {
	HT_Charge = 0,
	HT_Projectile = 1,
	HT_None = 2,
	HT_MAX = 3
};

// Object Name: Enum Solarland.EVirtualBulletType
enum class EVirtualBulletType : uint8 {
	LinearBullet = 0,
	CurveBullet = 1,
	GravityBullet = 2,
	TracingBullet = 3,
	EVirtualBulletType_MAX = 4
};

// Object Name: Enum Solarland.ETrajectoryType
enum class ETrajectoryType : uint8 {
	LINE = 0,
	LINE_GRAVITY = 1,
	CURVE = 2,
	CANISTER = 3,
	BEAM = 4,
	Rocket = 5,
	VirtualBullet = 6,
	MAX = 7
};

// Object Name: Enum Solarland.EWeaponSkillChargedState
enum class EWeaponSkillChargedState : uint8 {
	PREPARE = 0,
	START = 1,
	COMPLETECHARGE = 2,
	EXECUTE = 3,
	EWeaponSkillChargedState_MAX = 4
};

// Object Name: Enum Solarland.EFireMethodType
enum class EFireMethodType : uint8 {
	BULLET = 0,
	SKILL = 1,
	SUMMONBULLET = 2,
	MAX = 3
};

// Object Name: Enum Solarland.ECostFireType
enum class ECostFireType : uint8 {
	DESCRETE = 0,
	CONTINUOUS = 1,
	MAX = 2
};

// Object Name: Enum Solarland.EShootingSoundOpt
enum class EShootingSoundOpt : uint8 {
	EShootingSound_SINGLE_1P = 0,
	EShootingSound_SINGLE_3P = 1,
	EShootingSound_SINGLE_3P_ENEMY = 2,
	EShootingSound_AUTO_1P = 3,
	EShootingSound_AUTO_3P = 4,
	EShootingSound_AUTO_3P_ENEMY = 5,
	EShootingSound_BURST_1P = 6,
	EShootingSound_BURST_3P = 7,
	EShootingSound_BURST_3P_ENEMY = 8,
	EShootingSound_FIRE_LAST_1P = 9,
	EShootingSound_FIRE_LAST_3P = 10,
	EShootingSound_SKILL_CAST_1P = 11,
	EShootingSound_SKILL_CAST_3P = 12,
	EShootingSound_LAND_COMMON_HIT_3P = 13,
	EShootingSound_SKILL_FX_START_1P = 14,
	EShootingSound_SKILL_FX_START_3P = 15,
	EShootingSound_SHIELD_HIT_1P = 16,
	EShootingSound_SHIELD_HIT_3P = 17,
	EShootingSound_SHIELD_BROKEN_1P = 18,
	EShootingSound_SHIELD_BROKEN_3P = 19,
	EShootingSound_BODY_HIT_1P = 20,
	EShootingSound_BODY_HIT_3P = 21,
	EShootingSound_FIRE_OVERLOAD_1P = 22,
	EShootingSound_FIRE_OVERLOAD_3P = 23,
	EShootingSound_Fly_Loop = 24,
	EShootingSound_Fly_Once = 25,
	EShootingSound_Vehicle_Gun_On = 26,
	EShootingSound_Vehicle_Gun_Off = 27,
	EShootingSound_Smoke_Loop = 28,
	EShootingSound_B9A04Skill = 29,
	EShootingSound_Reload_1P_2 = 30,
	EShootingSound_Reload_3P_2 = 31,
	EShootingSound_Reload_1P_3 = 32,
	EShootingSound_Reload_3P_3 = 33,
	EShootingSound_Reload_1P_4 = 34,
	EShootingSound_Reload_3P_4 = 35,
	EShootingSound_Bolt_1P = 36,
	EShootingSound_Bolt_3P = 37,
	EShootingSound_MAX = 38
};

// Object Name: Enum Solarland.EShootingOpt
enum class EShootingOpt : uint8 {
	EShootingOpt_SINGLE = 0,
	EShootingOpt_AUTO = 1,
	EShootingOpt_BURST = 2,
	EShootingOpt_MAX = 3
};

// Object Name: Enum Solarland.EFootEffectType
enum class EFootEffectType : uint8 {
	Effect_None = 0,
	Effect_Water = 1,
	Effect_MAX = 2
};

// Object Name: Enum Solarland.EAttributeSubBehavior
enum class EAttributeSubBehavior : uint8 {
	Apply = 0,
	Cancel = 1,
	Update = 2,
	EAttributeSubBehavior_MAX = 3
};

// Object Name: Enum Solarland.EBackPackTransitionAnimState
enum class EBackPackTransitionAnimState : int32 {
	TransitionAnimStateDefault = 0,
	SkyCharge2NoCharge_NoFly = 535,
	SkyCharge2NoEnergy_NoFly = 545,
	SkyCharge2NoCharge_Fly = 636,
	SkyCharge2NoEnergy_Fly = 646,
	SkyCharge2NoCharge_IntoFly = 536,
	SkyCharge2NoEnergy_IntoFly = 546,
	NoCharge2SkyCharge_NoFly = 3505,
	NoEnergy2SkyCharge_NoFly = 4505,
	NoCharge2SkyCharge_Fly = 3606,
	NoEnergy2SkyCharge_Fly = 4606,
	NoCharge2SkyCharge_OutFly = 3605,
	NoEnergy2SkyCharge_OutFly = 4605,
	PileCharge2NoCharge_NoFly = 1535,
	PileCharge2NoEnergy_NoFly = 1545,
	PileCharge2NoCharge_Fly = 1636,
	PileCharge2NoEnergy_Fly = 1646,
	PileCharge2NoCharge_IntoFly = 1536,
	PileCharge2NoEnergy_IntoFly = 1546,
	NoCharge2PileCharge_NoFly = 3515,
	NoEnergy2PileCharge_NoFly = 4515,
	NoCharge2PileCharge_Fly = 3616,
	NoEnergy2PileCharge_Fly = 4616,
	NoCharge2PileCharge_OutFly = 3615,
	NoEnergy2PileCharge_OutFly = 4615,
	BoxCharge2NoCharge_NoFly = 2535,
	BoxCharge2NoEnergy_NoFly = 2545,
	BoxCharge2NoCharge_Fly = 2636,
	BoxCharge2NoEnergy_Fly = 2646,
	BoxCharge2NoCharge_IntoFly = 2536,
	BoxCharge2NoEnergy_IntoFly = 2546,
	NoCharge2BoxCharge_NoFly = 3525,
	NoEnergy2BoxCharge_NoFly = 4525,
	NoCharge2BoxCharge_Fly = 3626,
	NoEnergy2BoxCharge_Fly = 4626,
	NoCharge2BoxCharge_OutFly = 3625,
	NoEnergy2BoxCharge_OutFly = 4625,
	NoCharge2NoEnergy_NoFly = 3545,
	NoCharge2NoEnergy_IntoFly = 3546,
	NoEnergy2NoCharge_NoFly = 4535,
	NoEnergy2NoCharge_OutFly = 4635,
	EBackPackTransitionAnimState_MAX = 4636
};

// Object Name: Enum Solarland.EBackPackFixedAnimState
enum class EBackPackFixedAnimState : uint8 {
	FixedAnimStateDefault = 0,
	FixedSkyChargeNoFly = 5,
	FixedPileChargeNoFly = 15,
	FixedBoxChargeNoFly = 25,
	FixedNoChargeNoFly = 35,
	FixedNoEnergyNoFly = 45,
	FixedSkyChargeIsFly = 6,
	FixedPileChargeIsFly = 16,
	FixedBoxChargeIsFly = 26,
	FixedNoChargeIsFly = 36,
	FixedNoEnergyIsFly = 46,
	EBackPackFixedAnimState_MAX = 47
};

// Object Name: Enum Solarland.EBackPackAnimSubType
enum class EBackPackAnimSubType : uint8 {
	SkyChargeNoFly = 1,
	PileChargeNoFly = 2,
	BoxChargeNoFly = 3,
	NoChargeNoFly = 4,
	NoEnergyNoFly = 5,
	SkyChargeIsFly = 6,
	PileChargeIsFly = 7,
	BoxChargeIsFly = 8,
	NoChargeIsFly = 9,
	NoEnergyIsFly = 10,
	Charge2NoCharge_NoFly = 50,
	Charge2NoEnergy_NoFly = 51,
	Charge2NoCharge_Fly = 52,
	Charge2NoEnergy_Fly = 53,
	Charge2NoCharge_IntoFly = 54,
	Charge2NoEnergy_IntoFly = 55,
	NoCharge2Charge_NoFly = 56,
	NoEnergy2Charge_NoFly = 57,
	NoCharge2Charge_Fly = 58,
	NoEnergy2Charge_Fly = 59,
	NoCharge2Charge_OutFly = 60,
	NoEnergy2Charge_OutFly = 61,
	NoCharge2NoEnergy_NoFly = 62,
	NoCharge2NoEnergy_IntoFly = 63,
	NoEnergy2NoCharge_NoFly = 64,
	NoEnergy2NoCharge_OutFly = 65,
	ETypeDefault = 0,
	EBackPackAnimSubType_MAX = 66
};

// Object Name: Enum Solarland.EBackPackAnimType
enum class EBackPackAnimType : uint8 {
	SkyCharge = 0,
	PileCharge = 1,
	BoxCharge = 2,
	NoCharge = 3,
	NoEnergy = 4,
	NoFly = 5,
	IsFly = 6,
	EBackPackAnimType_MAX = 7
};

// Object Name: Enum Solarland.EBattleRoyalTimeLineEnum
enum class EBattleRoyalTimeLineEnum : uint8 {
	None = 0,
	CreateBombingZone = 1,
	CreateAirdrop = 2,
	ModifyEnvironmentState = 3,
	EBattleRoyalTimeLineEnum_MAX = 4
};

// Object Name: Enum Solarland.EBattleUpgradeEffectCategory
enum class EBattleUpgradeEffectCategory : uint8 {
	None = 0,
	Attack = 1,
	Defence = 2,
	Speed = 3,
	Bag = 4,
	Cooldown = 5,
	PlaceHolder1 = 6,
	PlaceHolder2 = 7,
	PlaceHolder3 = 8,
	PlaceHolder4 = 9,
	EBattleUpgradeEffectCategory_MAX = 10
};

// Object Name: Enum Solarland.EBombingZoneState
enum class EBombingZoneState : uint8 {
	Waiting = 0,
	Firing = 1,
	Ending = 2,
	End = 3,
	EBombingZoneState_MAX = 4
};

// Object Name: Enum Solarland.EBotAttrOperator
enum class EBotAttrOperator : uint8 {
	Equal = 0,
	Greater = 1,
	Less = 2,
	EBotAttrOperator_MAX = 3
};

// Object Name: Enum Solarland.EBotAttrValueType
enum class EBotAttrValueType : uint8 {
	Current = 0,
	Max = 1,
	Percent = 2
};

// Object Name: Enum Solarland.EBotAttrType
enum class EBotAttrType : uint8 {
	Health = 0,
	Shield = 1,
	Energy = 2,
	Difficulty = 3,
	EBotAttrType_MAX = 4
};

// Object Name: Enum Solarland.EBotCheckCondition
enum class EBotCheckCondition : uint8 {
	AlwaysPass = 0,
	ReadyFight = 1,
	CanJetVertical = 2,
	CanJetHorizontal = 3,
	ReadyWeaponSkill = 4,
	IsIndependent = 5,
	EBotCheckCondition_MAX = 6
};

// Object Name: Enum Solarland.EBotCheckAIServer
enum class EBotCheckAIServer : uint8 {
	AlwaysPass = 0,
	AIServerIsOnline = 1,
	EBotCheckAIServer_MAX = 2
};

// Object Name: Enum Solarland.EBotCheckNgaiMLAction
enum class EBotCheckNgaiMLAction : uint8 {
	AlwaysPass = 0,
	DoOnceFire = 1,
	DoJump = 2,
	DoJetVertical = 3,
	DoJetForward = 4,
	DoUseRoleSkillOne = 5,
	DoUseRoleSkillTwo = 6,
	DoContinueFire = 7,
	DoMoveTo = 8,
	DoUseMedicine = 9,
	DoUseShieldRecharger = 10,
	DoVehicleFire = 11,
	DoUseVehicleFirstSkill = 12,
	DoUseVehicleSecondSkill = 13,
	EBotCheckNgaiMLAction_MAX = 14
};

// Object Name: Enum Solarland.EBotCheckState
enum class EBotCheckState : uint8 {
	Falling = 0,
	Driving = 1,
	Passager = 2,
	Swiming = 3,
	Dying = 4,
	Dead = 5,
	WeaponReloading = 6,
	ShootAiming = 7,
	SiegeVehicleLocated = 8,
	BeingRescued = 9,
	Cruising = 10,
	Skydiving = 11,
	EBotCheckState_MAX = 12
};

// Object Name: Enum Solarland.EDistanceComparison
enum class EDistanceComparison : uint8 {
	Equal = 0,
	Greater = 1,
	Less = 2,
	EDistanceComparison_MAX = 3
};

// Object Name: Enum Solarland.ESameScreenEffectHandleType
enum class ESameScreenEffectHandleType : uint8 {
	Ignore = 0,
	StopPrev = 1,
	ESameScreenEffectHandleType_MAX = 2
};

// Object Name: Enum Solarland.EBuffEffectTagType
enum class EBuffEffectTagType : uint8 {
	None = 0,
	TopHalfPart = 1,
	BottomHalfPart = 2,
	TwoSidePart = 3,
	BorderPart = 4,
	FullPart = 5,
	EBuffEffectTagType_MAX = 6
};

// Object Name: Enum Solarland.EBuffEffectDurationType
enum class EBuffEffectDurationType : uint8 {
	Instant = 0,
	HasDuration = 1,
	EBuffEffectDurationType_MAX = 2
};

// Object Name: Enum Solarland.ELevelLoadType
enum class ELevelLoadType : uint8 {
	ClientAntServer = 0,
	ClientOnly = 1,
	ServerOnly = 2,
	ELevelLoadType_MAX = 3
};

// Object Name: Enum Solarland.EVaultType
enum class EVaultType : uint8 {
	None = 0,
	Step = 1,
	Step_Cross = 2,
	Step_Sprint = 3,
	Step_Sprint_Cross = 4,
	Vault = 5,
	Vault_Cross = 6,
	Vault_Sprint = 7,
	Vault_Sprint_Cross = 8,
	Climb = 9,
	Climb_Cross = 10,
	Climb_Sprint = 11,
	Climb_Sprint_Cross = 12,
	Climb_Water = 13,
	HighClimb = 14,
	HighClimb_Cross = 15,
	HighClimb_Sprint = 16,
	HighClimb_Sprint_Cross = 17,
	WallRun = 18,
	WallRunFailed = 19,
	EVaultType_MAX = 20
};

// Object Name: Enum Solarland.EObstacleDetectorType
enum class EObstacleDetectorType : uint8 {
	Knee = 0,
	Waist = 1,
	Chest = 2,
	Overhead = 3,
	Nullifier = 7,
	EObstacleDetectorType_MAX = 8
};

// Object Name: Enum Solarland.EActorEffectAffectedActorType
enum class EActorEffectAffectedActorType : uint8 {
	CharacterOnly = 0,
	All = 1,
	EActorEffectAffectedActorType_MAX = 2
};

// Object Name: Enum Solarland.ECueContentVisibleTargetFlag
enum class ECueContentVisibleTargetFlag : uint8 {
	None = 0,
	Self = 1,
	Teammate = 2,
	Other = 4,
	Observer = 8,
	Anyone = 15,
	ECueContentVisibleTargetFlag_MAX = 16
};

// Object Name: Enum Solarland.ECueContentPlayTiming
enum class ECueContentPlayTiming : uint8 {
	OnExecute = 0,
	OnActive = 1,
	WhileActive = 2,
	OnRemove = 3,
	OnCustomEvent = 4,
	ECueContentPlayTiming_MAX = 5
};

// Object Name: Enum Solarland.EUseType
enum class EUseType : uint8 {
	NORMAL = 0,
	HANDSETTING = 101,
	EUseType_MAX = 102
};

// Object Name: Enum Solarland.EWeaponEquipSlot
enum class EWeaponEquipSlot : uint8 {
	None = 0,
	First = 1,
	Second = 2,
	EWeaponEquipSlot_MAX = 3
};

// Object Name: Enum Solarland.ECrossHairState
enum class ECrossHairState : uint8 {
	None = 0,
	Normal = 1,
	Reload = 2,
	Overload = 3,
	Forbid = 4,
	ECrossHairState_MAX = 5
};

// Object Name: Enum Solarland.ESpreadType
enum class ESpreadType : uint8 {
	Absolute = 0,
	Relative = 1,
	ESpreadType_MAX = 2
};

// Object Name: Enum Solarland.ECrossHairSpecialFireState
enum class ECrossHairSpecialFireState : uint8 {
	PrepareFire = 0,
	ActivateFire = 1,
	KeepFiring = 2,
	EndFire = 3,
	ECrossHairSpecialFireState_MAX = 4
};

// Object Name: Enum Solarland.ECurvedEffectControllerStopMode
enum class ECurvedEffectControllerStopMode : uint8 {
	KeepCurrentProgress = 0,
	SetProgressToBegin = 1,
	SetProgressToEnd = 2,
	ECurvedEffectControllerStopMode_MAX = 3
};

// Object Name: Enum Solarland.ECustomNoticeColor
enum class ECustomNoticeColor : uint8 {
	None = 0,
	Red = 1,
	Green = 2,
	Blue = 3,
	Yellow = 4,
	ECustomNoticeColor_MAX = 5
};

// Object Name: Enum Solarland.ECustomNoticeType
enum class ECustomNoticeType : uint8 {
	SmallNotice = 0,
	MediumNotice = 1,
	BigNotice = 2,
	KillEffectNotice = 3,
	GlobalKillNotice = 4,
	LocalKillNotice = 5,
	PickUpNotice = 6,
	WeaponExpNotice = 7,
	EquipReplaceNotice = 8,
	TaskNotice = 9,
	ECustomNoticeType_MAX = 10
};

// Object Name: Enum Solarland.EUsePlayerType
enum class EUsePlayerType : uint8 {
	Self = 0,
	Teammate = 1,
	Enemy = 2,
	EUsePlayerType_MAX = 3
};

// Object Name: Enum Solarland.EUseEmojiScene
enum class EUseEmojiScene : uint8 {
	None = 0,
	Lobby = 1,
	Battle = 2,
	EUseEmojiScene_MAX = 3
};

// Object Name: Enum Solarland.EAnimationType
enum class EAnimationType : uint8 {
	Overload = 0,
	Overlay = 1,
	EAnimationType_MAX = 2
};

// Object Name: Enum Solarland.EWeaponInfiniteAmmoMode
enum class EWeaponInfiniteAmmoMode : uint8 {
	Default = 0,
	InfiniteClip = 1,
	InfinitePkg = 2,
	InfiniteBoth = 3,
	EWeaponInfiniteAmmoMode_MAX = 4
};

// Object Name: Enum Solarland.EJetAltitudeLimitationMode
enum class EJetAltitudeLimitationMode : uint8 {
	Default = 0,
	Home = 1,
	EJetAltitudeLimitationMode_MAX = 2
};

// Object Name: Enum Solarland.EWeaponVibrateFactor
enum class EWeaponVibrateFactor : uint8 {
	Off = 0,
	Low = 1,
	Middle = 2,
	High = 3,
	EWeaponVibrateFactor_MAX = 4
};

// Object Name: Enum Solarland.EWeaponVibrateType
enum class EWeaponVibrateType : uint8 {
	None = 0,
	Fire = 1,
	Reload_GetOld = 2,
	Reload_Restore = 3,
	Bolt = 4,
	Charge = 5,
	EWeaponVibrateType_MAX = 6
};

// Object Name: Enum Solarland.EGameplayVibrateIntensity
enum class EGameplayVibrateIntensity : uint8 {
	Off = 0,
	Low = 10,
	Middle = 20,
	High = 30,
	EGameplayVibrateIntensity_MAX = 31
};

// Object Name: Enum Solarland.EGameplayVibrateCategory
enum class EGameplayVibrateCategory : uint8 {
	None = 0,
	SelfBeingHit = 1,
	SelfJetpackFlying = 2,
	SelfContinuousDamaged = 3,
	TriggerCharacterDown = 4,
	TriggerCharacterDie = 5,
	EGameplayVibrateCategory_MAX = 6
};

// Object Name: Enum Solarland.ESCMDataGatherType_Settle
enum class ESCMDataGatherType_Settle : uint8 {
	None = 0,
	Self = 1,
	Side = 2,
	All = 3,
	ESCMDataGatherType_MAX = 4
};

// Object Name: Enum Solarland.ESCMDataReplicateType
enum class ESCMDataReplicateType : uint8 {
	None = 0,
	RepOwner = 1,
	RepSide = 2,
	RepGlobal = 3,
	ESCMDataReplicateType_MAX = 4
};

// Object Name: Enum Solarland.ESCMRankCheckType
enum class ESCMRankCheckType : uint8 {
	New = 0,
	Change = 1,
	Delete = 2,
	ESCMRankCheckType_MAX = 3
};

// Object Name: Enum Solarland.ESCMDataSetType
enum class ESCMDataSetType : uint8 {
	None = 0,
	Array = 1,
	Map = 2,
	ESCMDataSetType_MAX = 3
};

// Object Name: Enum Solarland.ESCMDataType
enum class ESCMDataType : uint8 {
	None = 0,
	Byte = 1,
	Int = 2,
	Float = 3,
	Bool = 4,
	FVector = 5,
	FString = 6,
	ESCMDataType_MAX = 7
};

// Object Name: Enum Solarland.EGaugeType
enum class EGaugeType : uint8 {
	None = 0,
	Degree_361 = 1,
	Degree_181 = 2,
	Degree_91 = 3,
	DownUp = 4,
	LeftRight = 5,
	EGaugeType_MAX = 6
};

// Object Name: Enum Solarland.EAimOffsetAdjustType
enum class EAimOffsetAdjustType : uint8 {
	None = 0,
	AdjustPitch = 1,
	AdjustYaw = 2,
	AdjustBoth = 3,
	EAimOffsetAdjustType_MAX = 4
};

// Object Name: Enum Solarland.EAimTraceOriginType
enum class EAimTraceOriginType : uint8 {
	Default = 0,
	Muzzle = 1,
	Camera = 2,
	EAimTraceOriginType_MAX = 3
};

// Object Name: Enum Solarland.EPosture
enum class EPosture : uint8 {
	Stand = 0,
	Crouch = 1,
	EPosture_MAX = 2
};

// Object Name: Enum Solarland.EUIHeroPickListCellState
enum class EUIHeroPickListCellState : uint8 {
	Show = 0,
	Lock = 1,
	Forbidden = 2,
	EUIHeroPickListCellState_MAX = 3
};

// Object Name: Enum Solarland.EHeroOwnedType
enum class EHeroOwnedType : uint8 {
	Own = 0,
	OwnForNow = 1,
	NotOwn = 2,
	EHeroOwnedType_MAX = 3
};

// Object Name: Enum Solarland.EHeroPickType
enum class EHeroPickType : uint8 {
	AllSidePlayer = 0,
	SpecificPlayer = 1,
	AllPlayer = 2,
	EHeroPickType_MAX = 3
};

// Object Name: Enum Solarland.EUIHeroPickPlayerState
enum class EUIHeroPickPlayerState : uint8 {
	Waiting = 0,
	Selecting = 1,
	Confirm = 2,
	Done = 3,
	EUIHeroPickPlayerState_MAX = 4
};

// Object Name: Enum Solarland.EHomeJetPackflag
enum class EHomeJetPackflag : uint8 {
	NONE = 0,
	Horizontal = 1,
	Vertical = 2,
	Stop = 3,
	EHomeJetPackflag_MAX = 4
};

// Object Name: Enum Solarland.ESkillStateType
enum class ESkillStateType : uint8 {
	Normal = 0,
	CD = 1,
	NoneSkill = 2,
	ESkillStateType_MAX = 3
};

// Object Name: Enum Solarland.EKeyMappingStatus
enum class EKeyMappingStatus : uint8 {
	EMPTY = 0,
	BASE = 1,
	OTHER = 2,
	OTHERANDBASE = 3,
	INVALID = 4,
	DONE = 5,
	EKeyMappingStatus_MAX = 6
};

// Object Name: Enum Solarland.EKillNoticeType
enum class EKillNoticeType : uint8 {
	BeKillLeader = 0,
	ShutDownKillLeader = 1,
	Revenge = 2,
	ShutDown = 3,
	CumulativeKill = 4,
	Down = 5,
	ClearTeam = 6,
	KillDefender = 7,
	SelfKillNotify = 8,
	KillLeaderChange = 9,
	KillLeaderShutDown = 10,
	GlobalKillNotify = 11,
	EKillNoticeType_MAX = 12
};

// Object Name: Enum Solarland.EMapCellSelectionAccess
enum class EMapCellSelectionAccess : uint8 {
	Can = 0,
	Cannot = 1,
	EMapCellSelectionAccess_MAX = 2
};

// Object Name: Enum Solarland.EMassInvState
enum class EMassInvState : uint8 {
	Begin = 0,
	Prepare = 1,
	Normal = 2,
	Sprint = 3,
	End = 4,
	EMassInvState_MAX = 5
};

// Object Name: Enum Solarland.EMapState
enum class EMapState : uint8 {
	Idle = 0,
	FOVScale = 1,
	EMapState_MAX = 2
};

// Object Name: Enum Solarland.EMapFOVParamType
enum class EMapFOVParamType : uint8 {
	VehicleSpeed = 0,
	PoisonCircle = 1,
	EMapFOVParamType_MAX = 2
};

// Object Name: Enum Solarland.EMapFOVState
enum class EMapFOVState : uint8 {
	Default = 0,
	Fov1 = 1,
	Fov2 = 2,
	EMapFOVState_MAX = 3
};

// Object Name: Enum Solarland.EAirdropStatus
enum class EAirdropStatus : uint8 {
	Default = 0,
	Coming = 1,
	Available = 2,
	Opening = 3,
	Opened = 4,
	EAirdropStatus_MAX = 5
};

// Object Name: Enum Solarland.EMeshWidgetDisplayType
enum class EMeshWidgetDisplayType : uint8 {
	Icon = 0,
	Flash = 1,
	Diffuse = 2,
	EMeshWidgetDisplayType_MAX = 3
};

// Object Name: Enum Solarland.EMeshProgressType
enum class EMeshProgressType : uint8 {
	Normal = 0,
	Damage = 1,
	Background = 2,
	EMeshProgressType_MAX = 3
};

// Object Name: Enum Solarland.E_Type_OB_Scoreboard
enum class E_Type_OB_Scoreboard : uint8 {
	OB_Settlement = 0,
	OB_InGame = 1,
	Lobby_League_Settlement = 2,
	Lobby_CreateRoom_Settlement = 3,
	E_Type_OB_MAX = 4
};

// Object Name: Enum Solarland.ERoleWidgetStatus
enum class ERoleWidgetStatus : uint8 {
	Normal = 0,
	InCD = 1,
	Forbidden = 2,
	SkillContinuous = 3,
	ERoleWidgetStatus_MAX = 4
};

// Object Name: Enum Solarland.ERoleWidgetType
enum class ERoleWidgetType : uint8 {
	Super = 0,
	Tactical = 1,
	ERoleWidgetType_MAX = 2
};

// Object Name: Enum Solarland.ESCMMapElementVisibilityType
enum class ESCMMapElementVisibilityType : uint8 {
	Visible = 0,
	Hidden = 1,
	ESCMMapElementVisibilityType_MAX = 2
};

// Object Name: Enum Solarland.ESCMMapElementStateType
enum class ESCMMapElementStateType : uint8 {
	Normal = 0,
	Suspend = 1,
	ESCMMapElementStateType_MAX = 2
};

// Object Name: Enum Solarland.ESCMMapElementType
enum class ESCMMapElementType : uint8 {
	PlayerStart = 0,
	ItemSpawner = 1,
	AirDrop = 2,
	ChargingPile = 3,
	JumpPad = 4,
	CarPad = 5,
	Vehicle = 6,
	Poison = 7,
	Custom = 8,
	ESCMMapElementType_MAX = 9
};

// Object Name: Enum Solarland.EMatchType
enum class EMatchType : uint8 {
	NONE = 0,
	Team = 1,
	AverageSide = 2,
	SingleSide = 3,
	EMatchType_MAX = 4
};

// Object Name: Enum Solarland.ESCMPlayerType
enum class ESCMPlayerType : uint8 {
	None = 0,
	Player = 1,
	BotAI = 2,
	Monster = 3,
	ESCMPlayerType_MAX = 4
};

// Object Name: Enum Solarland.ESCMPlayerState
enum class ESCMPlayerState : uint8 {
	None = 0,
	PreLogin = 1,
	NotJoin = 2,
	InBattle = 4,
	Suspend = 8,
	BattleEnd = 16,
	ESCMPlayerState_MAX = 17
};

// Object Name: Enum Solarland.ESCMPlayerGameRole
enum class ESCMPlayerGameRole : uint8 {
	StandBy = 0,
	OBPlayer = 1,
	Player = 2,
	Spectator = 3,
	ESCMPlayerGameRole_MAX = 4
};

// Object Name: Enum Solarland.EPlayerResurrectType
enum class EPlayerResurrectType : uint8 {
	NONE = 0,
	SelfResurrectionCoin = 1,
	RequestTeamResurrect = 2,
	EPlayerResurrectType_MAX = 3
};

// Object Name: Enum Solarland.EPlayerPawnType
enum class EPlayerPawnType : uint8 {
	NONE = 0,
	Character = 1,
	Vehicle = 2,
	Other = 3,
	EPlayerPawnType_MAX = 4
};

// Object Name: Enum Solarland.EDownloadState
enum class EDownloadState : uint8 {
	None = 0,
	Downloading = 1,
	Successful = 2,
	Failed = 3,
	EDownloadState_MAX = 4
};

// Object Name: Enum Solarland.EShieldUpgradeItemShopOpenState
enum class EShieldUpgradeItemShopOpenState : uint8 {
	Closed = 0,
	Opening = 1,
	Open = 2,
	Closing = 3,
	EShieldUpgradeItemShopOpenState_MAX = 4
};

// Object Name: Enum Solarland.ESolarWeaponBrand
enum class ESolarWeaponBrand : uint8 {
	WeaponBrand_None = 0,
	WeaponBrand_9A = 1,
	WeaponBrand_Wasteland = 2,
	WeaponBrand_Murphy = 3,
	WeaponBrand_Prism = 4,
	WeaponBrand_MAX = 5
};

// Object Name: Enum Solarland.ERoleAbilityVoiceTriggerTiming
enum class ERoleAbilityVoiceTriggerTiming : uint8 {
	None = 0,
	Active = 1,
	Commit = 2,
	ERoleAbilityVoiceTriggerTiming_MAX = 3
};

// Object Name: Enum Solarland.ESolarAbilityInstanceType
enum class ESolarAbilityInstanceType : uint8 {
	ESolarAbilityInstanceType_Multiple = 0,
	ESolarAbilityInstanceType_SingleReplace = 1,
	ESolarAbilityInstanceType_SingleYield = 2,
	ESolarAbilityInstanceType_Max = 3
};

// Object Name: Enum Solarland.ESolarAttributeDurationType
enum class ESolarAttributeDurationType : uint8 {
	Instant = 0,
	HasDuration = 1,
	Infinite = 2,
	ESolarAttributeDurationType_MAX = 3
};

// Object Name: Enum Solarland.ESolarAttributeValueSourceType
enum class ESolarAttributeValueSourceType : uint8 {
	Value = 0,
	FromConfig = 1,
	ESolarAttributeValueSourceType_MAX = 2
};

// Object Name: Enum Solarland.EAchievementCondition
enum class EAchievementCondition : uint8 {
	None = 0,
	AchTSubAchievement = 1,
	AchTMinuteKill = 2,
	AchTUseVehicle = 3,
	AchTHPKill = 4,
	AchTLimitWin = 5,
	AchTDyingWin = 6,
	AchTAssistWin = 7,
	AchTRescue = 8,
	AchTLevel = 9,
	AchTSkyKill = 10,
	AchTOnlyLiveWin = 11,
	AchTFirstKill = 12,
	AchTBlindSniper = 13,
	AchTFriendNum = 14,
	AchTOpenBoxNum = 15,
	AchTenemyVehicle = 16,
	AchTDie = 17,
	AchTMarsWin = 18,
	AchTFistKill = 19,
	AchTAirUmbrella = 20,
	AchTAirTrapeze = 21,
	AchTAirSpeed = 22,
	AchTBubbleKill = 23,
	AchTCharacterNum = 24,
	AchAdvancedWeapon = 25,
	AchTBombingDie = 26,
	AchTRevengeKill = 27,
	EAchievementCondition_MAX = 28
};

// Object Name: Enum Solarland.EAchievementReportType
enum class EAchievementReportType : uint8 {
	None = 0,
	SingleBattlle = 1,
	MultiBattle = 2,
	NoBattle = 3,
	EAchievementReportType_MAX = 4
};

// Object Name: Enum Solarland.ESigninItemState
enum class ESigninItemState : uint8 {
	Got = 0,
	UnGot = 1,
	No = 2,
	ESigninItemState_MAX = 3
};

// Object Name: Enum Solarland.EWidgetOverrideParamType
enum class EWidgetOverrideParamType : uint8 {
	None = 0,
	Text = 1,
	Image = 2,
	Custom = 3,
	EWidgetOverrideParamType_MAX = 4
};

// Object Name: Enum Solarland.EWidgetLoadType
enum class EWidgetLoadType : uint8 {
	Start = 0,
	Delay = 1,
	EWidgetLoadType_MAX = 2
};

// Object Name: Enum Solarland.EProgressBoardChannelState
enum class EProgressBoardChannelState : uint8 {
	None = 0,
	Add = 1,
	Minus = 2,
	HoldOn = 3,
	EProgressBoardChannelState_MAX = 4
};

// Object Name: Enum Solarland.EAirPlaneAnimState
enum class EAirPlaneAnimState : uint8 {
	Normal = 0,
	TakingOff = 1,
	Cruising = 2,
	EAirPlaneAnimState_MAX = 3
};

// Object Name: Enum Solarland.ESolarAIValueCompareOp
enum class ESolarAIValueCompareOp : uint8 {
	Equal = 0,
	Greater = 1,
	Less = 2,
	ESolarAIValueCompareOp_MAX = 3
};

// Object Name: Enum Solarland.ESolarAudioDetailCatalog
enum class ESolarAudioDetailCatalog : uint8 {
	SADC_Common = 0,
	SADC_Music = 1,
	SADC_UI = 2,
	SADC_Gun = 3,
	SADC_Vehicle = 4,
	SADC_Object = 5,
	SADC_Character = 6,
	SADC_Voice = 7,
	SADC_VoiceEx = 8,
	SADC_MAX = 9
};

// Object Name: Enum Solarland.ESolarAudioDetailUnloadMode
enum class ESolarAudioDetailUnloadMode : uint8 {
	SADU_NeverUnload = 0,
	SADU_SwitchLevel = 1,
	SADU_Manual = 2,
	SADU_EnterOtherScene = 3,
	SADU_LeaveLobby = 4,
	SADU_LeaveTutorial = 5,
	SADU_LeaveHome = 6,
	SADU_LeaveWaiting = 7,
	SADU_LeaveGame = 8,
	SADU_DontCare = 9,
	SADU_MAX = 10
};

// Object Name: Enum Solarland.ESolarAudioDetailLoadMode
enum class ESolarAudioDetailLoadMode : uint8 {
	SADL_BeginPlay = 0,
	SADL_OnDemand = 1,
	SADL_EnterBindScene = 2,
	SADL_EnterLobby = 3,
	SADL_EnterTutorial = 4,
	SADL_EnterHome = 5,
	SADL_EnterWaiting = 6,
	SADL_EnterGame = 7,
	SADL_NeverLoad = 8,
	SADL_MAX = 9
};

// Object Name: Enum Solarland.EBankLoadState
enum class EBankLoadState : uint8 {
	NotLoaded = 0,
	Loaded = 1,
	AsyncLoading = 2,
	AsyncUnloading = 3,
	EBankLoadState_MAX = 4
};

// Object Name: Enum Solarland.EInVehicleState
enum class EInVehicleState : uint8 {
	None = 0,
	Driving = 1,
	Riding = 2,
	StickingOut = 3,
	EInVehicleState_MAX = 4
};

// Object Name: Enum Solarland.ECruiseAnimState
enum class ECruiseAnimState : uint8 {
	None = 0,
	Looping = 1,
	Leaving = 2,
	End = 3,
	ECruiseAnimState_MAX = 4
};

// Object Name: Enum Solarland.ECharacterMontage
enum class ECharacterMontage : uint8 {
	Invalid = 0,
	Bolt = 1,
	Equip = 2,
	PreFire = 3,
	Rechamber = 4,
	Fire1 = 5,
	Reload = 6,
	ReloadWithBolt = 7,
	Max = 8
};

// Object Name: Enum Solarland.EVehicleAnimationType
enum class EVehicleAnimationType : uint8 {
	None = 0,
	Suv = 1,
	Sports = 2,
	MotorBike = 3,
	Hover = 4,
	Legged = 5,
	IronMan = 6,
	Backpacker = 7,
	EVehicleAnimationType_MAX = 8
};

// Object Name: Enum Solarland.EDriveTurnType
enum class EDriveTurnType : uint8 {
	EDriveTurnType_Idle = 0,
	EDriveTurnType_Left = 1,
	EDriveTurnType_Right = 2,
	EDriveTurnType_MAX = 3
};

// Object Name: Enum Solarland.EWeaponStatus
enum class EWeaponStatus : uint8 {
	NoWeapon = 0,
	Peace = 1,
	Aiming = 2,
	EWeaponStatus_MAX = 3
};

// Object Name: Enum Solarland.EAnoAntiDataType
enum class EAnoAntiDataType : uint8 {
	Unknown = 0,
	SecAntiDataFlow = 1,
	SecAttackFlow = 2,
	EAnoAntiDataType_MAX = 3
};

// Object Name: Enum Solarland.EItemLoadPriority
enum class EItemLoadPriority : int32 {
	DEFAULT = 0,
	ITEM_MIN = 1,
	ITEM_MAX = 99,
	WEAPON_MIN = 100,
	WEAPON_MAX = 199,
	VEHICLE_MIN = 200,
	VEHICLE_MAX = 299,
	CHARACTER_MIN = 300,
	CHARACTER_MAX = 399,
	CLASS_PRIORITY = 4294967295,
	EItemLoadPriority_MAX = 4294967296
};

// Object Name: Enum Solarland.EAutoSaveType
enum class EAutoSaveType : uint8 {
	Weapon = 0,
	ItemActor = 1,
	EAutoSaveType_MAX = 2
};

// Object Name: Enum Solarland.ESolarBotMemberState
enum class ESolarBotMemberState : uint8 {
	None = 0,
	Leader = 1,
	OnCall = 2,
	Separate = 3,
	Leaving = 4,
	Invalid = 5,
	ESolarBotMemberState_MAX = 6
};

// Object Name: Enum Solarland.ESolarAITagStateTimeType
enum class ESolarAITagStateTimeType : uint8 {
	DurationInCurrentState = 0,
	TimeSinceLastExitToState = 1,
	ESolarAITagStateTimeType_MAX = 2
};

// Object Name: Enum Solarland.EBotInteractCondition
enum class EBotInteractCondition : uint8 {
	Invalid = 0,
	NeedToResponsePoison = 1,
	FoundEnemyActor = 2,
	TeammateKillEnemy = 3,
	WeAreTheChampion = 4,
	TeammateMarkTargetLocation = 5,
	TeammateMarkTargetDangerPoint = 6,
	TeammateMarkTargetItem = 7,
	TeammateMarkTargetFootstep = 8,
	TeammateMarkFollowHe = 9,
	TeammateMarkGetOnVehicle = 10,
	TeammateMarkNeedVehicle = 11,
	TeammateMarkNeedWeapon = 12,
	TeammateMarkNeedHelp = 13,
	TeammateMarkAttack = 14,
	TeammateMarkDefend = 15,
	MockEnemy = 16,
	MockDyingEnemy = 17,
	EnterDying = 18,
	BoringEnough = 19,
	EBotInteractCondition_MAX = 20
};

// Object Name: Enum Solarland.EBotFocusType
enum class EBotFocusType : uint8 {
	FocusToNothing = 0,
	FocusToActor = 1,
	FocusToPoint = 2,
	FocusToDirection = 3,
	EBotFocusType_MAX = 4
};

// Object Name: Enum Solarland.EBotAIType
enum class EBotAIType : uint8 {
	BehaviorTree = 0,
	ImitationLearning = 1,
	ReinforcementLearning = 2,
	MAX = 3
};

// Object Name: Enum Solarland.EPopLocationType
enum class EPopLocationType : uint8 {
	Default = 0,
	ShowFight = 1,
	Guarantee = 2,
	EPopLocationType_MAX = 3
};

// Object Name: Enum Solarland.ESolarBotTimelineTriggerAction
enum class ESolarBotTimelineTriggerAction : uint8 {
	None = 0,
	Add = 1,
	Remove = 2,
	Clear = 3,
	ESolarBotTimelineTriggerAction_MAX = 4
};

// Object Name: Enum Solarland.ESolarBotTimelineFilterParameterType
enum class ESolarBotTimelineFilterParameterType : uint8 {
	None = 0,
	MoreThan = 1,
	LessThan = 2,
	Equal = 3,
	NotEqual = 4,
	Contain = 5,
	NotContain = 6,
	Radius = 7,
	Target = 8,
	ESolarBotTimelineFilterParameterType_MAX = 9
};

// Object Name: Enum Solarland.ESolarBotTimelineFilterType
enum class ESolarBotTimelineFilterType : uint8 {
	None = 0,
	RankPoint = 1,
	Equipment = 2,
	Disengagement = 3,
	KillNum = 4,
	DamageNum = 5,
	ItemNum = 6,
	SkillCoolingDown = 7,
	SurroundingTeammate = 8,
	SurroundingEnemy = 9,
	ESolarBotTimelineFilterType_MAX = 10
};

// Object Name: Enum Solarland.ESolarBotTimelineAIDataSettingType
enum class ESolarBotTimelineAIDataSettingType : uint8 {
	None = 0,
	Health = 1,
	Shield = 2,
	ESolarBotTimelineAIDataSettingType_MAX = 3
};

// Object Name: Enum Solarland.ESolarBotTimelineWeaponPartType
enum class ESolarBotTimelineWeaponPartType : uint8 {
	None = 0,
	Muzzle = 1,
	Grip = 2,
	Clip = 3,
	Scope = 4,
	GunStock = 5,
	ESolarBotTimelineWeaponPartType_MAX = 6
};

// Object Name: Enum Solarland.ESolarBotTimelineEquipmentSettingType
enum class ESolarBotTimelineEquipmentSettingType : uint8 {
	None = 0,
	PrimaryWeapon = 1,
	SecondaryWeapon = 2,
	Shield = 3,
	VerticalJet = 4,
	HorizontalJet = 5,
	SummonGun = 6,
	ESolarBotTimelineEquipmentSettingType_MAX = 7
};

// Object Name: Enum Solarland.ESolarBotTimelineTriggerType
enum class ESolarBotTimelineTriggerType : uint8 {
	None = 0,
	Timeline = 1,
	Guarantee = 2,
	ESolarBotTimelineTriggerType_MAX = 3
};

// Object Name: Enum Solarland.EBotOnVehicleFireType
enum class EBotOnVehicleFireType : uint8 {
	EBotOnVehicleFireType_None = 0,
	EBotOnVehicleFireType_FireOn = 1,
	EBotOnVehicleFireType_FireOnDelayOff = 2,
	EBotOnVehicleFireType_MAX = 3
};

// Object Name: Enum Solarland.EBotOnVehicleStopType
enum class EBotOnVehicleStopType : uint8 {
	EBotOnVehicleStopType_None = 0,
	EBotOnVehicleStopType_Delay = 1,
	EBotOnVehicleStopType_Stop = 2,
	EBotOnVehicleStopType_MAX = 3
};

// Object Name: Enum Solarland.EBotFirePolicy
enum class EBotFirePolicy : uint8 {
	AlwaysFire = 0,
	FirstRoughMoveDone = 1,
	FirstPreciseMoveDone = 2,
	PreciseMoveOrGreater = 3,
	FollowMoveOrGreater = 4,
	OnlyWhenHitSimulatedTarget = 5,
	OnlyWhenHitLockedTarget = 6,
	EBotFirePolicy_MAX = 7
};

// Object Name: Enum Solarland.EBotActionState
enum class EBotActionState : uint8 {
	EBotActionState_Sprite = 0,
	EBotActionState_Crouch = 1,
	EBotActionState_GunAim = 2,
	EBotActionState_MAX = 3
};

// Object Name: Enum Solarland.EBotBunkerType
enum class EBotBunkerType : uint8 {
	Invalid = 0,
	FullSize = 1,
	HalfSize = 2,
	EBotBunkerType_MAX = 3
};

// Object Name: Enum Solarland.EBotTeamVehicleDrivePolicy
enum class EBotTeamVehicleDrivePolicy : uint8 {
	DirectlyMove = 0,
	HoldAndWaitPassenger = 1,
	MoveAndTakePassenger = 2,
	EBotTeamVehicleDrivePolicy_MAX = 3
};

// Object Name: Enum Solarland.EPoisonResponseType
enum class EPoisonResponseType : uint8 {
	NoResponse = 0,
	LowPriority = 1,
	HighPriority = 2,
	Immediately = 3,
	EPoisonResponseType_MAX = 4
};

// Object Name: Enum Solarland.ESolarTaskScoringItemType
enum class ESolarTaskScoringItemType : uint8 {
	None = 0,
	CurrentHP = 1,
	IfSelfInBattle = 2,
	IfSelfInSafeArea = 3,
	IfSelfInPoisonCircle = 4,
	TimeToEnterSafeArea = 5,
	TimeToEnterPoisonCircleXPoisonDamage = 6,
	IfRelativeActorInSafeArea = 7,
	IfRelativeActorInPoisonCircle = 8,
	IfRescueTargetIsPlayer = 9,
	TimeToMovetoRescueTarget = 10,
	DistanceFromRescueTargetToSafeArea = 11,
	DistanceFromRescueTargetToPoisonCircleXPoisonDamage = 12,
	IfRescuingThisTarget = 13,
	IfRescuingOtherTarget = 14,
	TimePoisonToRescueTarget = 15,
	CurrentPoisonDamage = 16,
	ESolarTaskScoringItemType_MAX = 17
};

// Object Name: Enum Solarland.ESolarTeamTaskType
enum class ESolarTeamTaskType : uint8 {
	RescueTeammate = 0,
	ESolarTeamTaskType_MAX = 1
};

// Object Name: Enum Solarland.EJetTaskFinishMode
enum class EJetTaskFinishMode : uint8 {
	AfterResponded = 0,
	AfterDone = 1,
	EJetTaskFinishMode_MAX = 2
};

// Object Name: Enum Solarland.EJetPackMode
enum class EJetPackMode : uint8 {
	Horizontal = 0,
	Vertical = 1,
	EJetPackMode_MAX = 2
};

// Object Name: Enum Solarland.EJumpTaskFinishMode
enum class EJumpTaskFinishMode : uint8 {
	AfterResponded = 0,
	AfterApex = 1,
	AfterDone = 2,
	EJumpTaskFinishMode_MAX = 3
};

// Object Name: Enum Solarland.EBotShootTargetType
enum class EBotShootTargetType : uint8 {
	Player = 0,
	Bot = 1,
	Vehicle = 2,
	Monster = 3,
	EBotShootTargetType_MAX = 4
};

// Object Name: Enum Solarland.ECruiseStatePrivate
enum class ECruiseStatePrivate : uint8 {
	None = 0,
	Start = 1,
	CanParachute = 2,
	ForceParachute = 3,
	End = 4,
	ECruiseStatePrivate_MAX = 5
};

// Object Name: Enum Solarland.ERoleAbilityCancelPhase
enum class ERoleAbilityCancelPhase : uint8 {
	None = 0,
	Pressing = 1,
	Continuous = 2,
	All = 3,
	ERoleAbilityCancelPhase_MAX = 4
};

// Object Name: Enum Solarland.CharacterRoleAbilityEnum
enum class CharacterRoleAbilityEnum : uint8 {
	Super = 0,
	Tactical = 1,
	Count = 2,
	CharacterRoleAbilityEnum_MAX = 3
};

// Object Name: Enum Solarland.EMovementComponentEnableType
enum class EMovementComponentEnableType : uint8 {
	Default = 0,
	Dying = 1,
	OnLevelStreaming = 2,
	EMovementComponentEnableType_MAX = 3
};

// Object Name: Enum Solarland.EAntiCheatGameEvents
enum class EAntiCheatGameEvents : uint8 {
	ServerFire = 0,
	ServerHit = 1,
	ServerKill = 2,
	ServerKilled = 3,
	ClientFire = 4,
	ClientHit = 5,
	ClientKill = 6,
	ClientKilled = 7,
	ClientHitDown = 8,
	ClientBeHitDown = 9,
	EventMax = 10,
	EAntiCheatGameEvents_MAX = 11
};

// Object Name: Enum Solarland.EAnimReloadNotifyType
enum class EAnimReloadNotifyType : uint8 {
	InHand = 0,
	InHandAndDrop = 1,
	GetOld = 2,
	InPocket = 3,
	Restore = 4,
	SpawnFakeOldClip = 5,
	PhysicsDropOldClip = 6,
	SpawnFakeNewClip = 7,
	RestoreClip = 8,
	EAnimReloadNotifyType_MAX = 9
};

// Object Name: Enum Solarland.EWeaponSystemState
enum class EWeaponSystemState : uint8 {
	None = 0,
	PreReload = 1,
	PreOpenScope = 2,
	PreCloseScope = 3,
	PreFire = 4,
	PreSwitchWeapon = 5,
	PreDropCurrentWeapon = 6,
	PreFireOverload = 7,
	PreNeedBolt = 8,
	PreCharging = 9,
	PreReplaceWeapon = 10,
	PrePickupWeapon = 11,
	PreSwapWeapon = 12,
	Max = 13
};

// Object Name: Enum Solarland.ECamShakeType
enum class ECamShakeType : uint8 {
	Default = 0,
	JumpBegin = 1,
	JumpEndLight = 2,
	JumpEndHeavy = 3,
	FullBodyMeleeWithTarget = 4,
	FullBodyMeleeWithoutTarget = 5,
	TacticalDodgeForward = 6,
	TacticalDodgeBackward = 7,
	TacticalDodgeLeft = 8,
	TacticalDodgeRight = 9,
	ECamShakeType_MAX = 10
};

// Object Name: Enum Solarland.EGunsightCameraSwitchMode
enum class EGunsightCameraSwitchMode : uint8 {
	CloseScope = 0,
	CloseShoulderShot = 1,
	OpenShoulderShot = 2,
	OpenScope = 3,
	EGunsightCameraSwitchMode_MAX = 4
};

// Object Name: Enum Solarland.ESolarCameraSmoothType
enum class ESolarCameraSmoothType : uint8 {
	Default = 0,
	Instant = 1,
	Constant = 2,
	EaseOut = 3,
	EaseInEaseOut = 4,
	FloatCurve = 5,
	ESolarCameraSmoothType_MAX = 6
};

// Object Name: Enum Solarland.EReconnectionStatus
enum class EReconnectionStatus : uint8 {
	None = 0,
	Reconnecting = 1,
	Reconnected = 2,
	EReconnectionStatus_MAX = 3
};

// Object Name: Enum Solarland.EAnimDirection
enum class EAnimDirection : uint8 {
	AnimNone = 0,
	AnimForward = 1,
	AnimBackward = 2,
	AnimLeft = 3,
	AnimRight = 4,
	EAnimDirection_MAX = 5
};

// Object Name: Enum Solarland.ESkydiveEffectLifetime
enum class ESkydiveEffectLifetime : uint8 {
	DuringFlying = 0,
	DuringLanding = 1,
	DuringWholeSkydiving = 2,
	ESkydiveEffectLifetime_MAX = 3
};

// Object Name: Enum Solarland.EUpdateWarmServiceEventType
enum class EUpdateWarmServiceEventType : uint8 {
	None = 0,
	CharacterUpgrade = 1,
	WeaponUpgrade = 2,
	ShieldUpgrade = 3,
	SuperAbilityReady = 4,
	TacticalAbilityReady = 5,
	BattleStation = 6,
	EUpdateWarmServiceEventType_MAX = 7
};

// Object Name: Enum Solarland.EMassInVisibilityWarningType
enum class EMassInVisibilityWarningType : uint8 {
	None = 0,
	Character = 1,
	Vehicle = 2,
	EMassInVisibilityWarningType_MAX = 3
};

// Object Name: Enum Solarland.EHitRecoverType
enum class EHitRecoverType : uint8 {
	EHRT_Normal = 0,
	EHRT_DeathVerge = 1,
	EHRT_MAX = 2
};

// Object Name: Enum Solarland.EBResurrectionState
enum class EBResurrectionState : uint8 {
	NoneState = 0,
	WaitForApply = 1,
	NotApply = 2,
	Resurrected = 3,
	WaitForResurrect = 4,
	GiveUp = 5,
	Timeout = 6,
	AllTeammatesDied = 7,
	EBResurrectionState_MAX = 8
};

// Object Name: Enum Solarland.EDroppedItemType
enum class EDroppedItemType : uint8 {
	Weapons = 0,
	WeaponParts = 1,
	Consumables = 2,
	Equipments = 3,
	EDroppedItemType_MAX = 4
};

// Object Name: Enum Solarland.EBagScopeSlotType
enum class EBagScopeSlotType : uint8 {
	None = 0,
	Primary = 10,
	Second = 11,
	Bag = 12,
	EBagScopeSlotType_MAX = 13
};

// Object Name: Enum Solarland.EBagGridType
enum class EBagGridType : uint8 {
	None = 0,
	Pick = 1,
	Normal = 2,
	Lock = 3,
	Fix = 4,
	EBagGridType_MAX = 5
};

// Object Name: Enum Solarland.ETreatmentSoundType
enum class ETreatmentSoundType : uint8 {
	Healing = 0,
	Cancel = 1,
	StopHealing = 2,
	Completed = 3,
	ETreatmentSoundType_MAX = 4
};

// Object Name: Enum Solarland.EShieldAutoRechargeStopReason
enum class EShieldAutoRechargeStopReason : uint8 {
	SwitchShield = 0,
	OnWeaponFire = 1,
	OnHit = 2,
	Die = 3,
	ShieldFull = 4,
	ManualRecharge = 5,
	EShieldAutoRechargeStopReason_MAX = 6
};

// Object Name: Enum Solarland.ECharacterStateForWeapon
enum class ECharacterStateForWeapon : uint8 {
	Unknown = 0,
	Standing = 1,
	Crouching = 2,
	Running = 3,
	Sprinting = 4,
	Jumping = 5,
	Flying = 6,
	ECharacterStateForWeapon_MAX = 7
};

// Object Name: Enum Solarland.EPoseMode
enum class EPoseMode : uint8 {
	Stand = 0,
	Crouch = 1,
	Crawl = 2,
	Skydive = 3,
	EPoseMode_MAX = 4
};

// Object Name: Enum Solarland.EPickUpTargetType
enum class EPickUpTargetType : uint8 {
	Invalid = 0,
	Item = 1,
	Weapon = 2,
	TreasureItem = 3,
	HomeItem = 4,
	BoxHomeItem = 5,
	EPickUpTargetType_MAX = 6
};

// Object Name: Enum Solarland.ESolarExpBehaviorType
enum class ESolarExpBehaviorType : uint8 {
	SurvivalTime = 1,
	Kills = 2,
	Assists = 3,
	Selfhealing = 4,
	TeammateHealing = 5,
	Unpacking = 6,
	CollectElectricity = 7,
	PickExpPack = 8,
	EveryDamageDealt = 9,
	ESolarExpBehaviorType_MAX = 10
};

// Object Name: Enum Solarland.EClassLevelUpRewardType
enum class EClassLevelUpRewardType : uint8 {
	BattleUpgradeEffect = 0,
	UpgradeSkill1 = 1,
	UpgradeSkill2 = 2,
	ClassCommonPassiveSkill = 3,
	ClassSpecificPassiveSkill = 4,
	Max = 5
};

// Object Name: Enum Solarland.EClassType
enum class EClassType : uint8 {
	None = 0,
	Assault = 1,
	Defence = 2,
	Support = 3,
	Scout = 4,
	EClassType_MAX = 5
};

// Object Name: Enum Solarland.ESolarCrosshairType
enum class ESolarCrosshairType : uint8 {
	Weapon = 0,
	Feedback = 1,
	BulletContainer = 2,
	ESolarCrosshairType_MAX = 3
};

// Object Name: Enum Solarland.ESolarDamageTextType
enum class ESolarDamageTextType : uint8 {
	DamageTextType_None = 0,
	DamageTextType_Common = 1,
	DamageTextType_Headshot = 2,
	DamageTextType_HitShield = 3,
	DamageTextType_HeadshotWithShield = 4,
	DamageTextType_HitVehicle = 5,
	DamageTextType_HitVehicleWeak = 6,
	DamageTextType_BrokenShiled = 7,
	DamageTextType_BrokenShieldWithHeadShot = 8,
	DamageTextType_MAX = 9
};

// Object Name: Enum Solarland.EShopStatisticType
enum class EShopStatisticType : uint8 {
	OnActivated = 0,
	OnUpgradeWeapon = 1,
	OnPurchaseItem = 2,
	OnItemRefresh = 3,
	OnUpgradeShield = 4,
	EShopStatisticType_MAX = 5
};

// Object Name: Enum Solarland.EShopModelAnimType
enum class EShopModelAnimType : uint8 {
	Idle = 0,
	Upgrade = 1,
	Purchase = 2,
	EShopModelAnimType_MAX = 3
};

// Object Name: Enum Solarland.AIVehicleState
enum class AIVehicleState : uint8 {
	AIVehicleState_None = 0,
	AIVehicleState_Forward = 1,
	AIVehicleState_ReverseSolveBlock = 2,
	AIVehicleState_SolveBlockFoward = 3,
	AIVehicleState_ReverseToTarget = 4,
	AIVehicleState_MAX = 5
};

// Object Name: Enum Solarland.EAntiCheatReportType
enum class EAntiCheatReportType : uint8 {
	Player = 0,
	Weapon = 1,
	Vehicle = 2,
	EAntiCheatReportType_MAX = 3
};

// Object Name: Enum Solarland.ENgaiMLType
enum class ENgaiMLType : uint8 {
	None = 0,
	OnlyImitationLearning = 1,
	OnlyReinforcementLearning = 2,
	Both = 3,
	ENgaiMLType_MAX = 4
};

// Object Name: Enum Solarland.EActiveEffectDurationChangeProxy
enum class EActiveEffectDurationChangeProxy : uint8 {
	MaintainCurrent = 0,
	MaintainRemain = 1,
	ScalingCurrent = 2,
	EActiveEffectDurationChangeProxy_MAX = 3
};

// Object Name: Enum Solarland.ESolarGAInputID
enum class ESolarGAInputID : uint8 {
	None = 0,
	Jump = 1,
	Crouch = 2,
	Sprint = 3,
	JetVertical = 4,
	JetHorizontal = 5,
	Parachute = 6,
	SkydiveAccelerate = 7,
	Fire = 8,
	OutVehicle = 9,
	SkillTest = 10,
	RoleSkillOne = 11,
	RoleSkillTwo = 12,
	ESolarGAInputID_MAX = 13
};

// Object Name: Enum Solarland.ELogChannel
enum class ELogChannel : uint8 {
	General = 0,
	Mode = 1,
	Hunt = 2,
	BattleRoyal = 3,
	Weapon = 4,
	Character = 5,
	Vehicle = 6,
	Camera = 7,
	Animation = 8,
	Physics = 9,
	Inventory = 10,
	World = 11,
	ELogChannel_MAX = 12
};

// Object Name: Enum Solarland.EConfigVersion
enum class EConfigVersion : uint8 {
	BeforeCustomVersionWasAdded = 0,
	FixedCanAutoSteering = 1,
	VersionPlusOne = 2,
	LatestVersion = 1,
	EConfigVersion_MAX = 3
};

// Object Name: Enum Solarland.EBasicSettingBool
enum class EBasicSettingBool : uint8 {
	NotInit = 0,
	Off = 1,
	On = 2,
	EBasicSettingBool_MAX = 3
};

// Object Name: Enum Solarland.ESolarTouchAccMode
enum class ESolarTouchAccMode : uint8 {
	Velocity = 0,
	Constant = 1,
	Distance = 2,
	ESolarTouchAccMode_MAX = 3
};

// Object Name: Enum Solarland.ESolarAudioMode
enum class ESolarAudioMode : uint8 {
	PushToTalk = 0,
	FreeToTalk = 1,
	ESolarAudioMode_MAX = 2
};

// Object Name: Enum Solarland.ESolarSoundQuality
enum class ESolarSoundQuality : uint8 {
	NotInit = 0,
	Low = 1,
	High = 2,
	Ultra = 3,
	ESolarSoundQuality_MAX = 4
};

// Object Name: Enum Solarland.ESolarWeaponDoScopeMode
enum class ESolarWeaponDoScopeMode : uint8 {
	Click = 0,
	Press = 1,
	Mixed = 2,
	ESolarWeaponDoScopeMode_MAX = 3
};

// Object Name: Enum Solarland.EWheeledVehicleDriveUserType
enum class EWheeledVehicleDriveUserType : uint8 {
	DirectionalInput = 0,
	SteeringInput = 1,
	JoyStickInput = 2,
	EWheeledVehicleDriveUserType_MAX = 3
};

// Object Name: Enum Solarland.ESolarDamageTextDisplayModeType
enum class ESolarDamageTextDisplayModeType : uint8 {
	DamageTextDisplayMode_Off = 0,
	DamageTextDisplayMode_Stacked = 1,
	DamageTextDisplayMode_Floating = 2,
	DamageTextDisplayMode_Combined = 3,
	DamageTextDisplayMode_MAX = 4
};

// Object Name: Enum Solarland.ESolarGameUserSettingPart
enum class ESolarGameUserSettingPart : uint8 {
	PickupSettings = 0,
	GraphicsSettings = 1,
	WeaponSettings = 2,
	LanguageSettings = 3,
	SoundSettings = 4,
	BasicSettings = 5,
	SensitivitySettings = 6,
	ShakeSettings = 7,
	DriverSettings = 8,
	ChatOperatorSettings = 9,
	SensitivitySettingsKeyboard = 10,
	SensitivitySettingsGamepad = 11,
	KeyboardControlSettings = 12,
	GamepadSettings = 13,
	GamepadAdvancedSettings = 14,
	All = 15,
	ESolarGameUserSettingPart_MAX = 16
};

// Object Name: Enum Solarland.EGraphicQualitySelect
enum class EGraphicQualitySelect : uint8 {
	Default = 0,
	Lobby = 1,
	InGame = 2,
	EGraphicQualitySelect_MAX = 3
};

// Object Name: Enum Solarland.ESolarChatOperatorType
enum class ESolarChatOperatorType : uint8 {
	All = 0,
	Team = 1,
	Off = 2,
	ESolarChatOperatorType_MAX = 3
};

// Object Name: Enum Solarland.ESolarShakeMainType
enum class ESolarShakeMainType : uint8 {
	OFF = 0,
	LOW = 1,
	MEDIUM = 2,
	HIGH = 3,
	ESolarShakeMainType_MAX = 4
};

// Object Name: Enum Solarland.ESolarGyroscopeChooseType
enum class ESolarGyroscopeChooseType : uint8 {
	DefaultGyroscope = 0,
	ALWAYS = 1,
	FOCUS = 2,
	NEVER = 3,
	ESolarGyroscopeChooseType_MAX = 4
};

// Object Name: Enum Solarland.ESolarSprintModeType
enum class ESolarSprintModeType : uint8 {
	Default = 0,
	Pressing = 1,
	Toggle = 2,
	Auto = 3,
	ESolarSprintModeType_MAX = 4
};

// Object Name: Enum Solarland.ESolarAimModeType
enum class ESolarAimModeType : uint8 {
	Default = 0,
	Change = 1,
	Press = 2,
	ESolarAimModeType_MAX = 3
};

// Object Name: Enum Solarland.ESolarColorTheme
enum class ESolarColorTheme : uint8 {
	ESCT_Default = 0,
	ESCT_Bright = 1,
	ESCT_Soft = 2,
	ESCT_Cold = 3,
	ESCT_MAX = 4
};

// Object Name: Enum Solarland.ESolarFrameRateLevel
enum class ESolarFrameRateLevel : uint8 {
	ESFRL_NONE = 0,
	ESFRL_Low = 1,
	ESFRL_Mid = 2,
	ESFRL_High = 3,
	ESFRL_HighEnd = 4,
	ESFRL_EXTREME = 5,
	ESFRL_MAX = 6
};

// Object Name: Enum Solarland.ESolarContentScaleFactorLevel
enum class ESolarContentScaleFactorLevel : uint8 {
	ESCSFL_NONE = 0,
	ESCSFL_Low = 1,
	ESCSFL_Mid = 2,
	ESCSFL_High = 3,
	ESCSFL_HighEnd = 4,
	ESCSFL_MAX = 5
};

// Object Name: Enum Solarland.ESolarDeviceType
enum class ESolarDeviceType : uint8 {
	ESDT_Invalid = 0,
	ESDT_Windows = 1,
	ESDT_Android = 2,
	ESDT_IOS = 3,
	ESDT_Other = 4,
	ESDT_MAX = 5
};

// Object Name: Enum Solarland.ESolarDeviceLevel
enum class ESolarDeviceLevel : uint8 {
	ESDL_Invalid = 0,
	ESDL_Level1 = 1,
	ESDL_Level2 = 2,
	ESDL_Level3 = 3,
	ESDL_Level4 = 4,
	ESDL_Level5 = 5,
	ESDL_Level6 = 6,
	ESDL_Level7 = 7,
	ESDL_VALUE_MIN = 1,
	ESDL_VALUE_MAX = 7,
	ESDL_MAX = 8
};

// Object Name: Enum Solarland.ESolarGraphicsQualityLevel
enum class ESolarGraphicsQualityLevel : uint8 {
	ESGQL_Invalid = 0,
	ESGQL_Level1 = 1,
	ESGQL_Level2 = 2,
	ESGQL_Level3 = 3,
	ESGQL_Level4 = 4,
	ESGQL_Level5 = 5,
	ESGQL_Level6 = 6,
	ESGQL_Level7 = 7,
	ESGQL_VALUE_MIN = 1,
	ESGQL_VALUE_MAX = 7,
	ESGQL_MAX = 8
};

// Object Name: Enum Solarland.EHomeCameraMode
enum class EHomeCameraMode : uint8 {
	Normal = 0,
	Ceiling = 1,
	Panoramic = 2,
	Orthographic = 3,
	EHomeCameraMode_MAX = 4
};

// Object Name: Enum Solarland.EHomeLoadingChangeType
enum class EHomeLoadingChangeType : uint8 {
	NONE = 0,
	OPEN = 1,
	CLOSE = 2,
	EHomeLoadingChangeType_MAX = 3
};

// Object Name: Enum Solarland.EHomeOperationType
enum class EHomeOperationType : uint8 {
	NONE = 0,
	CREATE = 1,
	UPDATE = 2,
	REMOVE = 3,
	EHomeOperationType_MAX = 4
};

// Object Name: Enum Solarland.EHomeDragUIType
enum class EHomeDragUIType : uint8 {
	NONE = 0,
	ARROW = 1,
	ROUND = 2,
	EHomeDragUIType_MAX = 3
};

// Object Name: Enum Solarland.EHomeActorOwner
enum class EHomeActorOwner : uint8 {
	NOBODY = 0,
	SELF = 1,
	OTHERS = 2,
	EHomeActorOwner_MAX = 3
};

// Object Name: Enum Solarland.EHomeActorSurfaceDir
enum class EHomeActorSurfaceDir : uint8 {
	NONE = 0,
	FORWARD = 1,
	BACKWARD = 2,
	LEFT = 3,
	RIGHT = 4,
	UP = 5,
	DOWN = 6,
	EHomeActorSurfaceDir_MAX = 7
};

// Object Name: Enum Solarland.EHomeActor_SecondType
enum class EHomeActor_SecondType : uint8 {
	NONE = 0,
	CONSTRUCT_BASE = 1,
	CONSTRUCT_FLOOR = 2,
	CONSTRUCT_WALL = 3,
	DEVICE_ON_FLOOR = 4,
	DEVICE_ON_WALL = 5,
	DEVICE_ON_CEILING = 6,
	EHomeActor_MAX = 7
};

// Object Name: Enum Solarland.EHomeActor_FirstType
enum class EHomeActor_FirstType : uint8 {
	NONE = 0,
	CONSTRUCT = 1,
	DEVICE = 2,
	EHomeActor_MAX = 3
};

// Object Name: Enum Solarland.EHoverCraftHitType
enum class EHoverCraftHitType : uint8 {
	Default = 0,
	HoverCraftVehicle = 1,
	HoverVehicle = 2,
	LeggedVehicle = 3,
	WheeledVehicle = 4,
	EHoverCraftHitType_MAX = 5
};

// Object Name: Enum Solarland.EHoverVehicleVFXType
enum class EHoverVehicleVFXType : uint8 {
	Forward = 0,
	Backward = 1,
	Right = 2,
	Left = 3,
	Max = 4
};

// Object Name: Enum Solarland.EInputKeyMappingType
enum class EInputKeyMappingType : uint8 {
	KeyAndMouse1 = 0,
	KeyAndMouse2 = 1,
	Gamepad = 2,
	Count = 3,
	EInputKeyMappingType_MAX = 4
};

// Object Name: Enum Solarland.EInputActionContextType
enum class EInputActionContextType : uint8 {
	Pawn = 0,
	Controller = 1,
	LevelScriptActor = 2,
	UserWidget = 3,
	Count = 4,
	EInputActionContextType_MAX = 5
};

// Object Name: Enum Solarland.EGamepadDPad
enum class EGamepadDPad : uint8 {
	None = 0,
	Reset = 1,
	Up = 2,
	Down = 3,
	Right = 4,
	Left = 5,
	EGamepadDPad_MAX = 6
};

// Object Name: Enum Solarland.EInputActionFlags
enum class EInputActionFlags : uint8 {
	None = 0,
	FlagBigMap = 1,
	FlagBackpack = 2,
	FlagChatWheel = 3,
	FlagParachute = 4,
	FlagSpectate = 5,
	FlagTeamDeath = 6,
	FlagBlockAll = 31,
	FlagMax = 32,
	EInputActionFlags_MAX = 33
};

// Object Name: Enum Solarland.ESolarInteractionType
enum class ESolarInteractionType : uint8 {
	Invalid = 0,
	RescueTeammate = 1,
	ReviveTeammate = 2,
	OpenAirdrop = 3,
	ESolarInteractionType_MAX = 4
};

// Object Name: Enum Solarland.ESolarItemShowType
enum class ESolarItemShowType : uint8 {
	NOTSHOW = 0,
	SHOW = 1,
	ESolarItemShowType_MAX = 2
};

// Object Name: Enum Solarland.ESolarRedHintType
enum class ESolarRedHintType : uint8 {
	ZERO = 0,
	SHOW = 1,
	HIDE = 2,
	ESolarRedHintType_MAX = 3
};

// Object Name: Enum Solarland.ESolarItemOwnType
enum class ESolarItemOwnType : uint8 {
	ZERO = 0,
	NOOWN = 1,
	OWN = 2,
	ESolarItemOwnType_MAX = 3
};

// Object Name: Enum Solarland.ESolarItemBuyType
enum class ESolarItemBuyType : uint8 {
	ZERO = 0,
	NOBUY = 1,
	BUY = 2,
	CANTBUY = 3,
	ESolarItemBuyType_MAX = 4
};

// Object Name: Enum Solarland.ESolarItemUseType
enum class ESolarItemUseType : uint8 {
	ZERO = 0,
	NOUSE = 1,
	USING = 2,
	ESolarItemUseType_MAX = 3
};

// Object Name: Enum Solarland.ESolarItemLimitType
enum class ESolarItemLimitType : uint8 {
	ZERO = 0,
	NOLIMIT = 1,
	LIMITING = 2,
	ESolarItemLimitType_MAX = 3
};

// Object Name: Enum Solarland.ESolarItemMarkType
enum class ESolarItemMarkType : uint8 {
	ZERO = 0,
	NOMARK = 1,
	MARKED = 2,
	ESolarItemMarkType_MAX = 3
};

// Object Name: Enum Solarland.ESolarItemDownloadType
enum class ESolarItemDownloadType : uint8 {
	ZERO = 0,
	NOTDOWNLOAD = 1,
	DOWNLOADING = 2,
	DOWNLOADED = 3,
	PAUSING = 4,
	ESolarItemDownloadType_MAX = 5
};

// Object Name: Enum Solarland.ESolarItemLockType
enum class ESolarItemLockType : uint8 {
	ZERO = 0,
	NOLOCK = 1,
	LOCKED = 2,
	TEMPUNLOCK = 3,
	ESolarItemLockType_MAX = 4
};

// Object Name: Enum Solarland.ESolarItemSelectType
enum class ESolarItemSelectType : uint8 {
	ZERO = 0,
	NOTSELECT = 1,
	SELECTED = 2,
	ESolarItemSelectType_MAX = 3
};

// Object Name: Enum Solarland.ESolarItemQualityType
enum class ESolarItemQualityType : uint8 {
	ZERO = 0,
	N = 1,
	R = 2,
	SR = 3,
	SSR = 4,
	SSRPLUS = 5,
	ESolarItemQualityType_MAX = 6
};

// Object Name: Enum Solarland.ESpecialItemID
enum class ESpecialItemID : int32 {
	NONE = 0,
	CARIRIDGE_BAG = 1040101,
	REVIVE_ITEM = 1160501,
	RADAR_SCANNER = 1080101,
	SHIELD_RECHARGER = 1120100,
	SHIELD_BIG_RECHARGER = 1120101,
	AMMO_ASSAULT_RIFLE = 1030101,
	AMMO_RIFLE = 1030102,
	AMMO_SNIPER = 1030103,
	AMMO_SHOTGUN = 1030104,
	SHIELD_UPGRADE_MATERIAL = 148023,
	EXP_ITEM = 149022,
	ESpecialItemID_MAX = 1160502
};

// Object Name: Enum Solarland.EItemConfirmID
enum class EItemConfirmID : int32 {
	DropExtraEnergyConfirmID = 110003,
	ReplaceExtraEnergyConfirmID = 110004,
	DropEnergyModuleConfirmID = 110007,
	ReplaceEnergyModuleConfirmID = 110008,
	EItemConfirmID_MAX = 110009
};

// Object Name: Enum Solarland.EItemLocalTextID
enum class EItemLocalTextID : uint8 {
	LevelNumTextID = 40,
	EItemLocalTextID_MAX = 41
};

// Object Name: Enum Solarland.EItemNoticeID
enum class EItemNoticeID : int32 {
	BoxBeUsing = 900016,
	CantEquipThisScope = 900080,
	CantEquipThisPart = 900081,
	WillEquipLowLevelScope = 900082,
	WillEquipLowLevelPart = 900083,
	HasBetterPart = 900084,
	HasBetterScope = 900085,
	GetItem = 900003,
	GetHomeItem = 900005,
	EquipReplace = 900091,
	DropItemNotAutoPickup = 900094,
	ItemMaxPile = 900095,
	ReviveItemMaxPile = 900104,
	CantPickupReviveItem = 900105,
	EItemNoticeID_MAX = 900106
};

// Object Name: Enum Solarland.ESpawnStage
enum class ESpawnStage : uint8 {
	STAGE_NONE = 0,
	STAGE_READY = 1,
	STAGE_BATTLE = 2,
	STAGE_ALL = 3,
	STAGE_MAX = 4
};

// Object Name: Enum Solarland.EOutcomeType
enum class EOutcomeType : uint8 {
	None = 0,
	Single = 1,
	Pool = 2,
	DynamicPool = 3,
	EOutcomeType_MAX = 4
};

// Object Name: Enum Solarland.EItemSourceType
enum class EItemSourceType : uint8 {
	None = 0,
	DeathTreasureBox = 1,
	TreasureBox = 2,
	AirDropTreasureBox = 3,
	Max = 4
};

// Object Name: Enum Solarland.EItemDiscardState
enum class EItemDiscardState : uint8 {
	EItemDiscardState_DEFAULT = 0,
	EItemDiscardState_DEATHBOX = 1,
	EItemDiscardState_MAX = 2
};

// Object Name: Enum Solarland.EItemState
enum class EItemState : uint8 {
	EItemState_NONE = 0,
	EItemState_POSSESS = 1,
	EItemState_DISCARD = 2,
	EItemState_MAX = 3
};

// Object Name: Enum Solarland.EItemQualityType
enum class EItemQualityType : uint8 {
	None = 0,
	White = 1,
	Green = 2,
	Blue = 3,
	Purple = 4,
	Orange = 5,
	Red = 6,
	EItemQualityType_MAX = 7
};

// Object Name: Enum Solarland.ESpawnerLevel
enum class ESpawnerLevel : uint8 {
	LEVEL_1 = 0,
	LEVEL_2 = 1,
	LEVEL_3 = 2,
	LEVEL_4 = 3,
	LEVEL_MAX = 4
};

// Object Name: Enum Solarland.ESpawnerType
enum class ESpawnerType : uint8 {
	NONE = 0,
	NORMAL = 1,
	TREASUREBOX = 2,
	AIRDROP = 3,
	VEHICLE = 4,
	ESpawnerType_MAX = 5
};

// Object Name: Enum Solarland.EWalkingDirection
enum class EWalkingDirection : uint8 {
	None = 0,
	Forward = 1,
	Backward = 2,
	Left = 4,
	Right = 8,
	EWalkingDirection_MAX = 9
};

// Object Name: Enum Solarland.EVehicleShrinkCapsuleExtent
enum class EVehicleShrinkCapsuleExtent : uint8 {
	SHRINK_None = 0,
	SHRINK_RadiusCustom = 1,
	SHRINK_HeightCustom = 2,
	SHRINK_AllCustom = 3,
	SHRINK_MAX = 4
};

// Object Name: Enum Solarland.EVehicleLocomotionState
enum class EVehicleLocomotionState : uint8 {
	Walk = 0,
	Run = 1,
	Sprint = 2,
	Max = 3
};

// Object Name: Enum Solarland.ESolarBuildConfiguration
enum class ESolarBuildConfiguration : uint8 {
	Unknown = 0,
	Debug = 1,
	Development = 2,
	Shipping = 3,
	Test = 4,
	ESolarBuildConfiguration_MAX = 5
};

// Object Name: Enum Solarland.EElementVisibilityType
enum class EElementVisibilityType : uint8 {
	Visible = 0,
	Hidden = 1,
	EElementVisibilityType_MAX = 2
};

// Object Name: Enum Solarland.EElementStateType
enum class EElementStateType : uint8 {
	Normal = 0,
	Suspend = 1,
	EElementStateType_MAX = 2
};

// Object Name: Enum Solarland.ESolarMapElementPropertyType
enum class ESolarMapElementPropertyType : uint8 {
	String = 0,
	Float = 1,
	Int = 2,
	Bool = 3,
	ESolarMapElementPropertyType_MAX = 4
};

// Object Name: Enum Solarland.ESGameMode_ElementType
enum class ESGameMode_ElementType : uint8 {
	PlayerStart = 0,
	ItemSpawner = 1,
	AirDrop = 2,
	ChargingPile = 3,
	JumpPad = 4,
	CarPad = 5,
	Vehicle = 6,
	Poison = 7,
	Custom = 8,
	ESGameMode_MAX = 9
};

// Object Name: Enum Solarland.EMapDarkDataType
enum class EMapDarkDataType : uint8 {
	POISONCIRCLE = 0,
	EMapDarkDataType_MAX = 1
};

// Object Name: Enum Solarland.EMapAirlineType
enum class EMapAirlineType : uint8 {
	Default = 0,
	Capsule = 1,
	Airdrop = 2,
	EMapAirlineType_MAX = 3
};

// Object Name: Enum Solarland.EDirection
enum class EDirection : uint8 {
	TOP = 0,
	BOTTOM = 1,
	LEFT = 2,
	RIGHT = 3,
	EDirection_MAX = 4
};

// Object Name: Enum Solarland.EBattlePromptType
enum class EBattlePromptType : uint8 {
	None = 0,
	Player = 1,
	Vehicle = 4,
	Move = 8,
	Fire = 16,
	HeavyWeapon = 32,
	Crouch = 64,
	Skydive = 128,
	PlayerStep = 9,
	VehicleMove = 12,
	PlayerCrouchMove = 73,
	PlayerSkydive = 137,
	PlayerFire = 17,
	VehicleFire = 20,
	PlayerHeavyFire = 49,
	VehicleHeavyFire = 52,
	EBattlePromptType_MAX = 138
};

// Object Name: Enum Solarland.EMarkerType
enum class EMarkerType : uint8 {
	NONE = 0,
	ENEMYSTEP = 101,
	ENEMYFIGHT = 102,
	AIRDROPBOX = 103,
	REDZONE = 104,
	VEHICLEVOICE = 105,
	VEHICLEMARK = 106,
	ENEMYLAUNCH = 107,
	VEHICLELAUNCH = 108,
	SKILLBUFFMARK = 109,
	RADARCharacter = 110,
	RADARCharacterWithAngle = 111,
	RADARVehicle = 112,
	RADARTreasureBox = 113,
	RADARChargingPile = 114,
	RADAR = 115,
	ELECTRICSHOP = 116,
	PARACHUTE = 117,
	RESPAWN = 118,
	SHIELDUPGRADEITEMSHOP = 119,
	ReviveTeammate = 120,
	EMarkerType_MAX = 121
};

// Object Name: Enum Solarland.EMovablePadLimitationFlag
enum class EMovablePadLimitationFlag : uint8 {
	None = 0,
	NoPress = 1,
	NoRelease = 2,
	NoMove = 4,
	NoPressAndRelease = 3,
	NoPressAndMove = 5,
	NoReleaseAndMove = 6,
	EMovablePadLimitationFlag_MAX = 7
};

// Object Name: Enum Solarland.ENavLinkType
enum class ENavLinkType : uint8 {
	Jet = 0,
	Vault = 1,
	None = 2,
	ENavLinkType_MAX = 3
};

// Object Name: Enum Solarland.EOwnerType
enum class EOwnerType : uint8 {
	None = 0,
	Vehicle = 1,
	TreasureBox = 2,
	EOwnerType_MAX = 3
};

// Object Name: Enum Solarland.ERestState
enum class ERestState : uint8 {
	AT_REST = 0,
	JUST_STARTED_MOVING = 1,
	MOVING = 2,
	ERestState_MAX = 3
};

// Object Name: Enum Solarland.EExtrapolationMode
enum class EExtrapolationMode : uint8 {
	UNLIMITED = 0,
	LIMITED = 1,
	NONE = 2,
	EExtrapolationMode_MAX = 3
};

// Object Name: Enum Solarland.ESyncMode
enum class ESyncMode : uint8 {
	NONE = 0,
	X = 1,
	Y = 2,
	Z = 4,
	XY = 3,
	XZ = 5,
	YZ = 6,
	XYZ = 7,
	ESyncMode_MAX = 8
};

// Object Name: Enum Solarland.ENightComesState
enum class ENightComesState : uint8 {
	None = 0,
	Begin = 1,
	Ongoing = 2,
	End = 3,
	ENightComesState_MAX = 4
};

// Object Name: Enum Solarland.EPerceivableEffectAreaTendency
enum class EPerceivableEffectAreaTendency : uint8 {
	Hostile = 0,
	Neutral = 1,
	Friendly = 2,
	EPerceivableEffectAreaTendency_MAX = 3
};

// Object Name: Enum Solarland.EPerceivableEffectAreaType
enum class EPerceivableEffectAreaType : uint8 {
	Unknow = 0,
	SmokeGrenade = 1,
	NightCome = 2,
	AutomaticTurret = 3,
	BlackHole = 4,
	Incendiary = 5,
	EnergyBubble = 6,
	SummonWall = 7,
	UAVShield = 8,
	UAVRescue = 9,
	HealPile = 10,
	EPerceivableEffectAreaType_MAX = 11
};

// Object Name: Enum Solarland.EPickupListItemType
enum class EPickupListItemType : uint8 {
	None = 0,
	Single = 1,
	Merge = 2,
	Customize = 3,
	EPickupListItemType_MAX = 4
};

// Object Name: Enum Solarland.ESolarPileType
enum class ESolarPileType : uint8 {
	ChargingPile = 0,
	HealPile = 1,
	ESolarPileType_MAX = 2
};

// Object Name: Enum Solarland.EChargingChannel
enum class EChargingChannel : uint8 {
	MAIN = 0,
	EXTRA = 1,
	EChargingChannel_MAX = 2
};

// Object Name: Enum Solarland.EPileHealingType
enum class EPileHealingType : uint8 {
	None = 0,
	Health = 1,
	Armor = 2,
	EPileHealingType_MAX = 3
};

// Object Name: Enum Solarland.ELevelTickType
enum class ELevelTickType : uint8 {
	LEVELTICK_TimeOnly = 0,
	LEVELTICK_ViewportsOnly = 1,
	LEVELTICK_All = 2,
	LEVELTICK_PauseTick = 3,
	LEVELTICK_MAX = 4
};

// Object Name: Enum Solarland.EInteractiveFlag
enum class EInteractiveFlag : uint8 {
	None = 0,
	DanceLearder = 1,
	EInteractiveFlag_MAX = 2
};

// Object Name: Enum Solarland.ESolarPlayerSensitivitysType
enum class ESolarPlayerSensitivitysType : uint8 {
	None = 0,
	HoldWeaponSensitivity = 1,
	WeaponShootSensitivity = 2,
	WeaponShoulderNoShotSensitivity = 3,
	WeaponShoulderShotSensitivity = 4,
	WeaponSkillSensitivity = 5,
	SightSensitivity = 6,
	ScopeSensitivity = 7,
	ScopeShootSensitivity = 8,
	VehicleDriverSensitivity = 9,
	VehicleFireSensitivity = 10,
	SuperSkillSensitivity = 11,
	TacticalSkillSensitivity = 12,
	ESolarPlayerSensitivitysType_MAX = 13
};

// Object Name: Enum Solarland.EWeaponRVCmd
enum class EWeaponRVCmd : uint8 {
	Cmd_None = 0,
	LocalHold = 1,
	OtherHold = 2,
	Dropped = 4,
	ReplacePart = 8,
	SkinRefresh = 16,
	EWeaponRVCmd_MAX = 17
};

// Object Name: Enum Solarland.EPreservedBotType
enum class EPreservedBotType : uint8 {
	OnCall = 0,
	WaitingForSend = 1,
	Killer = 2,
	WaitingToDie = 3,
	EPreservedBotType_MAX = 4
};

// Object Name: Enum Solarland.ESolarProjBulletCollisionType
enum class ESolarProjBulletCollisionType : uint8 {
	Shape = 0,
	Box = 1,
	ESolarProjBulletCollisionType_MAX = 2
};

// Object Name: Enum Solarland.ERadarType
enum class ERadarType : uint8 {
	ERT_WholeMap = 0,
	ERT_FollowSpawner = 1,
	ERT_FixedRound = 2,
	ERT_UAV = 3,
	ERT_OneTimeScan = 4,
	ERT_MAX = 5
};

// Object Name: Enum Solarland.ERedHintPath
enum class ERedHintPath : uint8 {
	None = 0,
	Root = 1,
	Social = 2,
	Arsenal = 3,
	Arsenal_Weapon = 4,
	Arsenal_Skin = 5,
	Arsenal_Part = 6,
	Shop = 7,
	Mail = 8,
	Capsulers = 9,
	Capsulers_Detail = 10,
	Capsulers_Story = 11,
	Capsulers_Skin = 12,
	Capsulers_LevelUp = 13,
	Capsulers_Pose = 14,
	Capsulers_PoseTab = 15,
	Capsulers_BG = 16,
	Capsulers_BGTab = 17,
	WareHouse = 18,
	Task = 19,
	Activity = 20,
	RankFight = 21,
	Achievement = 22,
	EditBusinessCard = 23,
	PlayerInfo = 24,
	GameMode = 25,
	Raffle = 26,
	Vehicle = 27,
	Vehicle_Skin = 28,
	Clan = 29,
	ClanPermission = 30,
	Collection = 31,
	Tournament = 32,
	VipCard = 33,
	ClanMember = 34,
	Max = 35
};

// Object Name: Enum Solarland.ERedHintValueType
enum class ERedHintValueType : uint8 {
	Single = 0,
	MultiValue = 1,
	ERedHintValueType_MAX = 2
};

// Object Name: Enum Solarland.ECharacterSkydivingState
enum class ECharacterSkydivingState : uint8 {
	EveryBattle = 0,
	Flying = 1,
	Skydiving = 2,
	Landing = 3,
	Num = 4,
	ECharacterSkydivingState_MAX = 5
};

// Object Name: Enum Solarland.EReplayFindSpectateTargetApproach
enum class EReplayFindSpectateTargetApproach : uint8 {
	None = 0,
	SuggestTarget = 1,
	LastTarget = 2,
	ClosestToCamera = 3,
	FirstInPlayerList = 4,
	EReplayFindSpectateTargetApproach_MAX = 5
};

// Object Name: Enum Solarland.EPlayerHighlightMarkType
enum class EPlayerHighlightMarkType : uint8 {
	B = 0,
	A = 1,
	S = 2,
	Ex = 3,
	Max = 4
};

// Object Name: Enum Solarland.EClassRepNodeMapping
enum class EClassRepNodeMapping : uint8 {
	Missing = 0,
	NotRouted = 1,
	CustomRelevancy = 2,
	RelevantAllConnections = 3,
	Spatialize_Static = 4,
	Spatialize_Dynamic = 5,
	Spatialize_Dormancy = 6,
	EClassRepNodeMapping_MAX = 7
};

// Object Name: Enum Solarland.EIncreaseAndDecreaseTransitionMode
enum class EIncreaseAndDecreaseTransitionMode : uint8 {
	Continuously = 0,
	BreakAndKeepLast = 1,
	EIncreaseAndDecreaseTransitionMode_MAX = 2
};

// Object Name: Enum Solarland.EActorInSafeAreaStatus
enum class EActorInSafeAreaStatus : uint8 {
	InSafeArea = 0,
	InPoisonArea = 1,
	OutPoisonArea = 2,
	EActorInSafeAreaStatus_MAX = 3
};

// Object Name: Enum Solarland.ESafeAreaStatus
enum class ESafeAreaStatus : uint8 {
	WaittingForStart = 0,
	WaittingForShrink = 1,
	Shrink = 2,
	ShrinkEnd = 3,
	Pause = 4,
	End = 5,
	ESafeAreaStatus_MAX = 6
};

// Object Name: Enum Solarland.ENeverShowDuration
enum class ENeverShowDuration : uint8 {
	Day = 0,
	Week = 1,
	Month = 2,
	Year = 3,
	Never = 4,
	None = 5,
	ENeverShowDuration_MAX = 6
};

// Object Name: Enum Solarland.EShieldUpgradeItemShopState
enum class EShieldUpgradeItemShopState : uint8 {
	None = 0,
	Upgrading = 1,
	Done = 2,
	EShieldUpgradeItemShopState_MAX = 3
};

// Object Name: Enum Solarland.EParticleOptimization
enum class EParticleOptimization : uint8 {
	Origin = 0,
	LowPriorityOptimization = 1,
	MidPriorityOptimization = 2,
	HighPriorityOptimization = 3,
	UltraHighPriorityOptimization = 4,
	EParticleOptimization_MAX = 5
};

// Object Name: Enum Solarland.ESolarEMPParticleType
enum class ESolarEMPParticleType : uint8 {
	FadeIn = 0,
	FadeOut = 1,
	Loop = 2,
	ESolarEMPParticleType_MAX = 3
};

// Object Name: Enum Solarland.ESolarEMPForceFieldState
enum class ESolarEMPForceFieldState : uint8 {
	None = 0,
	Ready = 1,
	Active = 2,
	End = 3,
	ESolarEMPForceFieldState_MAX = 4
};

// Object Name: Enum Solarland.ESolarSurroundLightningApplyType
enum class ESolarSurroundLightningApplyType : uint8 {
	SurroundLightningApplyType_Character = 0,
	SurroundLightningApplyType_Vehicle = 1,
	SurroundLightningApplyType_Other = 2,
	SurroundLightningApplyType_MAX = 3
};

// Object Name: Enum Solarland.ESpectatorMode
enum class ESpectatorMode : uint8 {
	DeathWatch = 0,
	Replay = 1,
	ESpectatorMode_MAX = 2
};

// Object Name: Enum Solarland.ETabControlListStyle
enum class ETabControlListStyle : uint8 {
	None = 0,
	Text = 1,
	Icon = 2,
	ETabControlListStyle_MAX = 3
};

// Object Name: Enum Solarland.ETabControlListSlotType
enum class ETabControlListSlotType : uint8 {
	Leaf = 0,
	Compound = 1,
	ETabControlListSlotType_MAX = 2
};

// Object Name: Enum Solarland.ESolarSupportLanguages
enum class ESolarSupportLanguages : uint8 {
	DefaultLanguage = 0,
	SimplifiedChinese = 1,
	TraditionalChinese = 2,
	Arabic = 3,
	German = 4,
	English = 5,
	Spanish = 6,
	French = 7,
	Hindi = 8,
	Indonesian = 9,
	Italian = 10,
	Japanese = 11,
	Korean = 12,
	Malay = 13,
	Polish = 14,
	Portuguese = 15,
	Russian = 16,
	Thai = 17,
	Turkish = 18,
	Vietnamese = 19,
	Tagalog = 20,
	PO = 253,
	OP = 254,
	ESolarSupportLanguages_MAX = 255
};

// Object Name: Enum Solarland.ESolarTablesEnum_CalculatingSign
enum class ESolarTablesEnum_CalculatingSign : uint8 {
	Plus = 0,
	Multiplication = 1,
	Equal = 2,
	_Count = 3,
	ESolarTablesEnum_MAX = 4
};

// Object Name: Enum Solarland.ESolarTablesEnum_PartsType
enum class ESolarTablesEnum_PartsType : uint8 {
	Muzzle = 0,
	Scope = 1,
	Clip = 2,
	Runes = 3,
	Grip = 4,
	GunStock = 5,
	Scope2x = 6,
	Scope4x = 7,
	Scope8x = 8,
	_Count = 9,
	ESolarTablesEnum_MAX = 10
};

// Object Name: Enum Solarland.ESolarTablesEnum_AccessoryType
enum class ESolarTablesEnum_AccessoryType : uint8 {
	WeaponParts = 0,
	WeaponAmmo = 1,
	_Count = 2,
	ESolarTablesEnum_MAX = 3
};

// Object Name: Enum Solarland.ESolarTablesEnum_FireCostType
enum class ESolarTablesEnum_FireCostType : uint8 {
	Descrete = 0,
	Continuous = 1,
	_Count = 2,
	ESolarTablesEnum_MAX = 3
};

// Object Name: Enum Solarland.ESolarTablesEnum_TriggerType
enum class ESolarTablesEnum_TriggerType : uint8 {
	KeyDown = 0,
	KeyUp = 1,
	KeyHold = 2,
	_Count = 3,
	ESolarTablesEnum_MAX = 4
};

// Object Name: Enum Solarland.ESolarTablesEnum_TrajectoryType
enum class ESolarTablesEnum_TrajectoryType : uint8 {
	Line = 0,
	LineGravity = 1,
	Curve = 2,
	Canister = 3,
	Beam = 4,
	Rocket = 5,
	VirtualBullet = 6,
	_Count = 7,
	ESolarTablesEnum_MAX = 8
};

// Object Name: Enum Solarland.ESolarTablesEnum_FireMethodType
enum class ESolarTablesEnum_FireMethodType : uint8 {
	Bullet = 0,
	Skill = 1,
	SummonBullet = 2,
	_Count = 3,
	ESolarTablesEnum_MAX = 4
};

// Object Name: Enum Solarland.ESolarTablesEnum_WeaponType
enum class ESolarTablesEnum_WeaponType : uint8 {
	AssualtRifle = 0,
	Submachinegun = 1,
	Shotgun = 2,
	Sniper = 3,
	Vehicle = 4,
	ItemWeapon = 5,
	SummonWeapon = 6,
	AntiVehicle = 7,
	_Count = 8,
	ESolarTablesEnum_MAX = 9
};

// Object Name: Enum Solarland.ESolarTablesEnum_TrigerType
enum class ESolarTablesEnum_TrigerType : uint8 {
	GameTime = 0,
	AliveCount = 1,
	RealTime = 2,
	MatchRoundTime = 3,
	GameWorldTime = 4,
	_Count = 5,
	ESolarTablesEnum_MAX = 6
};

// Object Name: Enum Solarland.ESolarTablesEnum_CategoryType
enum class ESolarTablesEnum_CategoryType : uint8 {
	CategoryType_None = 0,
	CategoryType_Reco = 1,
	CategoryType_Character = 2,
	CategoryType_CharacterSkin = 3,
	CategoryType_WeaponSkin = 4,
	CategoryType_Capsule = 5,
	CategoryType_Bag = 6,
	CategoryType_Tail = 7,
	CategoryType_Home = 8,
	CategoryType_Others = 9,
	_Count = 10,
	ESolarTablesEnum_MAX = 11
};

// Object Name: Enum Solarland.ESolarTablesEnum_ShareType
enum class ESolarTablesEnum_ShareType : uint8 {
	ActionType_None = 0,
	ShareType_RankShare = 1,
	ShareType_BattlePassShare = 2,
	ShareType_AchieveItemShare = 3,
	ShareType_ScoreShare = 4,
	ShareType_LoginActivityShare = 5,
	ShareType_MedalShare = 6,
	ShareType_UserGrowthShare = 7,
	ShareType_FollowCommunity = 8,
	ShareType_PersonalHistory = 9,
	_Count = 10,
	ESolarTablesEnum_MAX = 11
};

// Object Name: Enum Solarland.ESolarTablesEnum_LobbyMatchEnterType
enum class ESolarTablesEnum_LobbyMatchEnterType : uint8 {
	CanClick = 0,
	PartialClick = 1,
	ForbidClick = 2,
	_Count = 3,
	ESolarTablesEnum_MAX = 4
};

// Object Name: Enum Solarland.ESolarTablesEnum_StackType
enum class ESolarTablesEnum_StackType : uint8 {
	StackByQTY = 0,
	StackByTime = 1,
	_Count = 2,
	ESolarTablesEnum_MAX = 3
};

// Object Name: Enum Solarland.ESolarTablesEnum_InputTriggerType
enum class ESolarTablesEnum_InputTriggerType : uint8 {
	InputTriggerPressed = 0,
	InputTriggerTap = 1,
	InputTriggerDoubleTap = 2,
	InputTriggerHold = 3,
	_Count = 4,
	ESolarTablesEnum_MAX = 5
};

// Object Name: Enum Solarland.ESolarTablesEnum_InputRelatedType
enum class ESolarTablesEnum_InputRelatedType : uint8 {
	InputRelatedNone = 0,
	Input_F = 1,
	InputRelated2 = 2,
	InputRelated3 = 3,
	InputRelated4 = 4,
	InputRelated5 = 5,
	InputRelated6 = 6,
	InputRelated7 = 7,
	InputRelated8 = 8,
	InputRelated9 = 9,
	InputRelated10 = 10,
	Input_J = 11,
	_Count = 12,
	ESolarTablesEnum_MAX = 13
};

// Object Name: Enum Solarland.ESolarTablesEnum_InputContextType
enum class ESolarTablesEnum_InputContextType : uint8 {
	InputCommon = 0,
	InputPlayer = 1,
	InputVehicle = 2,
	InputOB = 3,
	InputPlayerSkill = 4,
	InputActionWheel = 5,
	_Count = 6,
	ESolarTablesEnum_MAX = 7
};

// Object Name: Enum Solarland.ESolarTablesEnum_InputTabType
enum class ESolarTablesEnum_InputTabType : uint8 {
	InputTabPlayer = 0,
	InputTabVehicle = 1,
	InputTabOB = 2,
	InputTabMisc = 3,
	_Count = 4,
	ESolarTablesEnum_MAX = 5
};

// Object Name: Enum Solarland.ESolarTablesEnum_InputCtrlType
enum class ESolarTablesEnum_InputCtrlType : uint8 {
	InputCtrlHide = 0,
	InputCtrlShow = 1,
	InputCtrlCustom = 2,
	_Count = 3,
	ESolarTablesEnum_MAX = 4
};

// Object Name: Enum Solarland.ESolarTablesEnum_InputActionType
enum class ESolarTablesEnum_InputActionType : uint8 {
	Action = 0,
	Axis = 1,
	_Count = 2,
	ESolarTablesEnum_MAX = 3
};

// Object Name: Enum Solarland.ESolarTablesEnum_InputGroupType
enum class ESolarTablesEnum_InputGroupType : uint8 {
	InputNone = 0,
	InputKeyF = 1,
	InputKeyG = 2,
	InputKeyP = 3,
	_Count = 4,
	ESolarTablesEnum_MAX = 5
};

// Object Name: Enum Solarland.ESolarTablesEnum_GamepadCtrlType
enum class ESolarTablesEnum_GamepadCtrlType : uint8 {
	GamepadCtrlHide = 0,
	GamepadCtrlShowOnly = 1,
	GamepadCtrlCustom = 2,
	GamepadCtrlCustomAndCom = 3,
	_Count = 4,
	ESolarTablesEnum_MAX = 5
};

// Object Name: Enum Solarland.ESolarTablesEnum_InputGamepadType
enum class ESolarTablesEnum_InputGamepadType : uint8 {
	InputGamepadOneKey = 0,
	InputGamepadComKey = 1,
	InputGamepadFreeComKey = 2,
	_Count = 3,
	ESolarTablesEnum_MAX = 4
};

// Object Name: Enum Solarland.ESolarTablesEnum_ClassModeType
enum class ESolarTablesEnum_ClassModeType : uint8 {
	CLASS_MODE_NONE = 0,
	CLASS_MODE_V13_4 = 1,
	CLASS_MODE_UniqueSkill = 2,
	CLASS_MODE_RoleGrow = 3,
	_Count = 4,
	ESolarTablesEnum_MAX = 5
};

// Object Name: Enum Solarland.ESolarTablesEnum_ExcuterType
enum class ESolarTablesEnum_ExcuterType : uint8 {
	AirDrop = 0,
	GasCircle = 1,
	Bomb = 2,
	_Count = 3,
	ESolarTablesEnum_MAX = 4
};

// Object Name: Enum Solarland.ESolarTablesEnum_DisplayType
enum class ESolarTablesEnum_DisplayType : uint8 {
	None = 0,
	Tips = 1,
	Window = 2,
	_Count = 3,
	ESolarTablesEnum_MAX = 4
};

// Object Name: Enum Solarland.ESolarTablesEnum_ChestType
enum class ESolarTablesEnum_ChestType : uint8 {
	AirDrop = 0,
	ElecChest = 1,
	_Count = 2,
	ESolarTablesEnum_MAX = 3
};

// Object Name: Enum Solarland.ESolarTablesEnum_Duration
enum class ESolarTablesEnum_Duration : uint8 {
	Day = 0,
	Week = 1,
	Month = 2,
	Year = 3,
	Never = 4,
	None = 5,
	_Count = 6,
	ESolarTablesEnum_MAX = 7
};

// Object Name: Enum Solarland.ESolarTablesEnum_CharacterLevelUpType
enum class ESolarTablesEnum_CharacterLevelUpType : uint8 {
	Health = 0,
	Damage = 1,
	Movement = 2,
	FlyCooldown = 3,
	_Count = 4,
	ESolarTablesEnum_MAX = 5
};

// Object Name: Enum Solarland.ESolarTablesEnum_CharacterType
enum class ESolarTablesEnum_CharacterType : uint8 {
	None = 0,
	Assault = 1,
	Defence = 2,
	Support = 3,
	Scout = 4,
	_Count = 5,
	ESolarTablesEnum_MAX = 6
};

// Object Name: Enum Solarland.ESolarTablesEnum_BehaviorType
enum class ESolarTablesEnum_BehaviorType : uint8 {
	SurvivalTime = 0,
	Kills = 1,
	Assists = 2,
	Selfhealing = 3,
	TeammateHealing = 4,
	Unpacking = 5,
	CollectElectricity = 6,
	PickExpPack = 7,
	EveryDamageDealt = 8,
	NpcKills = 9,
	NpcAssists = 10,
	_Count = 11,
	ESolarTablesEnum_MAX = 12
};

// Object Name: Enum Solarland.ESolarTablesEnum_Enum_Behavior
enum class ESolarTablesEnum_Enum_Behavior : uint8 {
	Behavior1 = 0,
	Behavior2 = 1,
	Behavior3 = 2,
	Behavior4 = 3,
	Behavior5 = 4,
	Behavior6 = 5,
	Behavior7 = 6,
	Behavior8 = 7,
	Behavior9 = 8,
	Behavior10 = 9,
	Behavior11 = 10,
	_Count = 11,
	ESolarTablesEnum_Enum_MAX = 12
};

// Object Name: Enum Solarland.ESolarTablesEnum_ActionType
enum class ESolarTablesEnum_ActionType : uint8 {
	ActionType_None = 0,
	ActionType_OpenGift = 1,
	ActionType_Charge = 2,
	ActionType_Battle = 3,
	ActionType_Mail = 4,
	ActionType_ShopBuy = 5,
	ActionType_DailyTask = 6,
	ActionType_Activity = 7,
	ActionType_Guid = 8,
	ActionType_GM = 9,
	ActionType_BattleBag = 10,
	ActionType_ItemUse = 11,
	ActionType_Refund = 12,
	ActionType_BattleDouble = 13,
	ActionType_UnitProf = 14,
	ActionType_SanctuaryBuild = 15,
	ActionType_SanctuaryFacility = 16,
	ActionType_Weapon_Upgrade = 17,
	ActionType_Activereward = 18,
	ActionType_ComposeItem = 19,
	ActionType_LoginReward = 20,
	ActionType_NewUserLogin = 21,
	ActionType_HomeDailyTask = 22,
	ActionType_BattlePass = 23,
	ActionType_LevelReward = 24,
	ActionType_HomeUpgrade = 25,
	ActionType_BattlePassRepeat = 26,
	ActionType_TopUP = 27,
	ActionType_Achievement = 28,
	ActionType_LuckDraw = 29,
	ActionType_BattlePassShare = 30,
	ActionType_CDKey = 31,
	ActionType_HalfMonthLogin = 32,
	ActionType_MonthlyEvent = 33,
	ActionType_FriendEvent = 34,
	ActionType_WeekChanllenge = 35,
	ActionType_RoomCard = 36,
	ActionType_BindAccount = 37,
	ActionType_UserGrowthEvent = 38,
	ActionType_SendGift = 39,
	ActionType_SellItem = 40,
	ActionType_CollectRedeem = 41,
	ActionType_RandomPack = 42,
	ActionType_Clan = 43,
	ActionType_Bet = 44,
	ActionType_BetBonus = 45,
	ActionType_BetReturn = 46,
	ActionType_CarouselDraw = 47,
	ActionType_WeekFree = 48,
	ActionType_TutorialLevelReward = 49,
	ActionType_TournamentMiss = 50,
	ActionType_TournamentReward = 51,
	ActionType_RankingCard = 52,
	ActionType_BattleSupplyBox = 53,
	ActionType_BattlePassMission = 54,
	ActionType_SupplyBox = 55,
	ActionType_VipcardReceive = 56,
	ActionType_VipcardSign = 57,
	ActionType_Vipcard = 58,
	ActionType_Signcard = 59,
	ActionType_ChangeName = 60,
	_Count = 61,
	ESolarTablesEnum_MAX = 62
};

// Object Name: Enum Solarland.ETaskPage
enum class ETaskPage : uint8 {
	TPNone = 0,
	TPDaily = 1,
	TPGrow = 2,
	TPHomeDaily = 3,
	TPSeason = 4,
	TPPassDaily = 5,
	TPPassWelfare = 6,
	TPPassWeek = 7,
	TPMonthlyDaily = 8,
	TPMonthlyWeek = 9,
	TPHalMonth = 10,
	TPWeekChallenge = 11,
	TPShareCodeDaily = 12,
	TPShareCodePersonal = 13,
	TPShareCodeFriend = 14,
	TPCollectRedeem = 15,
	ETaskPage_MAX = 16
};

// Object Name: Enum Solarland.ETaskStatus
enum class ETaskStatus : uint8 {
	Runing = 0,
	Completed = 1,
	ReceiveAward = 2,
	ETaskStatus_MAX = 3
};

// Object Name: Enum Solarland.EBurstMethod
enum class EBurstMethod : uint8 {
	ParabCurveFitting = 0,
	GoldenSpiral = 1,
	EBurstMethod_MAX = 2
};

// Object Name: Enum Solarland.ECostType
enum class ECostType : uint8 {
	NONE = 0,
	ELECTRONIC = 1,
	ECostType_MAX = 2
};

// Object Name: Enum Solarland.ETreasureBoxSpawnType
enum class ETreasureBoxSpawnType : uint8 {
	SingleRandom = 0,
	Group = 1,
	ETreasureBoxSpawnType_MAX = 2
};

// Object Name: Enum Solarland.ETutorialUIType
enum class ETutorialUIType : uint8 {
	None = 0,
	Common = 1,
	Special = 2,
	ETutorialUIType_MAX = 3
};

// Object Name: Enum Solarland.ELevelRewardStatus
enum class ELevelRewardStatus : uint8 {
	NotClaimed = 0,
	Claimed = 1,
	Disable = 2,
	ELevelRewardStatus_MAX = 3
};

// Object Name: Enum Solarland.EWidgetPlayAnimationFlag
enum class EWidgetPlayAnimationFlag : uint8 {
	None = 0,
	Finish = 1,
	EWidgetPlayAnimationFlag_MAX = 2
};

// Object Name: Enum Solarland.EWidgetInteractionFlag
enum class EWidgetInteractionFlag : uint8 {
	None = 0,
	Pressed = 1,
	Released = 2,
	Clicked = 3,
	EWidgetInteractionFlag_MAX = 4
};

// Object Name: Enum Solarland.ETutorialStage
enum class ETutorialStage : uint8 {
	None = 0,
	Lobby = 1,
	BattleField = 2,
	Home = 3,
	TutorialLevel = 4,
	ETutorialStage_MAX = 5
};

// Object Name: Enum Solarland.ETutorialUIParent
enum class ETutorialUIParent : uint8 {
	Parent = 0,
	UnderBattleRoot = 1,
	BattleRoot = 2,
	BattleRootGuide = 3,
	MiddleRoot = 4,
	CommonRoot = 5,
	Map = 6,
	BattleNoticeRoot = 7,
	Guide = 8,
	PopRoot = 9,
	TipsRoot = 10,
	NoticeRoot = 11,
	Loading = 12,
	Reconnecting = 13,
	ExternalToolsRoot = 255,
	ETutorialUIParent_MAX = 256
};

// Object Name: Enum Solarland.ETutorialConditionType
enum class ETutorialConditionType : uint8 {
	None = 0,
	Trigger = 1,
	Interrupt = 2,
	Finish = 3,
	ForeverClose = 4,
	ETutorialConditionType_MAX = 5
};

// Object Name: Enum Solarland.ETutorialType
enum class ETutorialType : uint8 {
	TEvent = 0,
	TTick = 1,
	ETutorialType_MAX = 2
};

// Object Name: Enum Solarland.ETutorialTriggerType
enum class ETutorialTriggerType : uint8 {
	TickActivateTutorials = 0,
	AlreadyTriggeredMaxCount = 1,
	HasSpecifiedItem = 2,
	HasTakenDamage = 3,
	PlayerAcountLevel = 4,
	SprintingContinuously = 5,
	JumpBegin = 8,
	ShieldNotFull = 17,
	WidgetClicked = 19,
	CanUseSpecifiedVehicleAbility = 20,
	CanUseSpecifiedVehicleWeapon = 21,
	AirDropBoxLanded = 22,
	NearAirDropBox = 23,
	OpenBigMapUMG = 24,
	CanUseSpecifiedWeaponAbility = 25,
	CanOpenTreasureBox = 29,
	PlayerInTargetStage = 30,
	EquipSpecifiedWeapon = 34,
	FeatureUnlock = 35,
	ApproachTreasureBox = 36,
	BotAIDying = 38,
	RunningStep = 39,
	HasSpecifiedEquipmentByType = 40,
	TutorialLevelDone = 42,
	WeaponSlotHasSpecifiedItem = 45,
	HasUIPanelOpened = 48,
	SpecifiedPlayerProficiency = 53,
	PlayerUpgradeBattleLevel = 54,
	ETutorialTriggerType_MAX = 55
};

// Object Name: Enum Solarland.EPlayerProficiency
enum class EPlayerProficiency : uint8 {
	None = 0,
	Rookie = 1,
	FPS = 2,
	Veteran = 3,
	EPlayerProficiency_MAX = 4
};

// Object Name: Enum Solarland.EUAVRescueState
enum class EUAVRescueState : uint8 {
	None = 0,
	Idle = 1,
	Heal = 2,
	Navigate = 3,
	Rescue = 4,
	EUAVRescueState_MAX = 5
};

// Object Name: Enum Solarland.EWidgetPassiveMode
enum class EWidgetPassiveMode : uint8 {
	Normal = 0,
	Passive_Buff = 1,
	Passive_Debuff = 2,
	EWidgetPassiveMode_MAX = 3
};

// Object Name: Enum Solarland.EVehicleRotateAnimationType
enum class EVehicleRotateAnimationType : uint8 {
	None = 0,
	Right_91 = 1,
	Right_181 = 2,
	Left_91 = 3,
	Left_181 = 4,
	Right = 5,
	Left = 6,
	EVehicleRotateAnimationType_MAX = 7
};

// Object Name: Enum Solarland.EVehicleAnimationState
enum class EVehicleAnimationState : uint8 {
	None = 0,
	Jump = 1,
	Dash = 2,
	EVehicleAnimationState_MAX = 3
};

// Object Name: Enum Solarland.EVehicleSpawnSourceType
enum class EVehicleSpawnSourceType : uint8 {
	CommonSpawn = 0,
	VehicleSummonWeapon = 1,
	EVehicleSpawnSourceType_MAX = 2
};

// Object Name: Enum Solarland.EEnterWaterVFX
enum class EEnterWaterVFX : uint8 {
	HorizontalLightEffect = 0,
	HorizontalHeavyEffect = 1,
	VerticalLightEffect = 2,
	VerticalHeavyEffect = 3,
	MAX = 4
};

// Object Name: Enum Solarland.EVehicleControlUIType
enum class EVehicleControlUIType : uint8 {
	Vehicle = 0,
	Character = 1,
	EVehicleControlUIType_MAX = 2
};

// Object Name: Enum Solarland.EIronManHandPart
enum class EIronManHandPart : uint8 {
	LeftHand = 0,
	RightHand = 1,
	EIronManHandPart_MAX = 2
};

// Object Name: Enum Solarland.EIronManSoundEvent
enum class EIronManSoundEvent : uint8 {
	LaserHit = 0,
	EIronManSoundEvent_MAX = 1
};

// Object Name: Enum Solarland.EPlayerInputMask
enum class EPlayerInputMask : uint8 {
	Invalidated = 0,
	VehicleBraking = 1,
	VehicleTrumpet = 2,
	VehicleAutoMove = 4,
	All = 7,
	EPlayerInputMask_MAX = 8
};

// Object Name: Enum Solarland.EAssistLockState
enum class EAssistLockState : uint8 {
	None = 0,
	PreEnterAssistLock = 1,
	EnterAssistLock = 2,
	HoldAssistLock = 3,
	LeaveAssistLock = 4,
	EAssistLockState_MAX = 5
};

// Object Name: Enum Solarland.EVehicleRotateCondition
enum class EVehicleRotateCondition : uint8 {
	None = 0,
	Forward = 1,
	Backward = 2,
	Right = 4,
	Left = 8,
	All = 15,
	EVehicleRotateCondition_MAX = 16
};

// Object Name: Enum Solarland.EVehicleOpenTips
enum class EVehicleOpenTips : uint8 {
	FloorCanNotOpen = 0,
	SpeedCanNotOpen = 1,
	EVehicleOpenTips_MAX = 2
};

// Object Name: Enum Solarland.ESiegeVehicleAnimation
enum class ESiegeVehicleAnimation : uint8 {
	CloseIdle = 0,
	OpenIdle = 1,
	Fire = 2,
	ESiegeVehicleAnimation_MAX = 3
};

// Object Name: Enum Solarland.EVehicleDamageStatus
enum class EVehicleDamageStatus : uint8 {
	Normal = 0,
	Damaged = 1,
	SeriouslyDamaged = 2,
	BrokenDanger = 3,
	Broken = 4,
	MAX = 5
};

// Object Name: Enum Solarland.ERocketFireMode
enum class ERocketFireMode : uint8 {
	NomalFire = 0,
	PrecisionFire = 1,
	Max = 2
};

// Object Name: Enum Solarland.EVehiclePageType
enum class EVehiclePageType : uint8 {
	Lobby = 0,
	VehicleBag = 1,
	BattlePass = 2,
	LuckDraw = 3,
	GetReward = 4,
	GrowTask = 5,
	Shop = 6,
	CarouselDraw = 7,
	SupplyBoxDetail = 8,
	SupplyBoxRaffle = 9,
	Max = 10
};

// Object Name: Enum Solarland.EVehicleSpawnType
enum class EVehicleSpawnType : uint8 {
	SingleRandom = 0,
	Group = 1,
	EVehicleSpawnType_MAX = 2
};

// Object Name: Enum Solarland.EVehicleState
enum class EVehicleState : uint8 {
	None = 0,
	Ground = 1,
	Air = 2,
	Sliding = 3,
	EVehicleState_MAX = 4
};

// Object Name: Enum Solarland.ESolarWeaponSpreadState
enum class ESolarWeaponSpreadState : uint8 {
	Standby = 0,
	Approach = 1,
	Recover = 2,
	ESolarWeaponSpreadState_MAX = 3
};

// Object Name: Enum Solarland.ESolarBlackHoleParticle
enum class ESolarBlackHoleParticle : uint8 {
	ForceField = 0,
	CoreFadeIn = 1,
	CoreFadeOut = 2,
	CoreLoop = 3,
	CoreHit = 4,
	Explode = 5,
	CharacterDebuff = 6,
	ESolarBlackHoleParticle_MAX = 7
};

// Object Name: Enum Solarland.ESolarBlackHoleState
enum class ESolarBlackHoleState : uint8 {
	None = 0,
	Startup = 1,
	Ready = 2,
	Active = 3,
	End = 4,
	ESolarBlackHoleState_MAX = 5
};

// Object Name: Enum Solarland.EWeaponOverloadState
enum class EWeaponOverloadState : uint8 {
	NormalDecrease = 0,
	FireSuspend = 1,
	ForceOverload = 2,
	EWeaponOverloadState_MAX = 3
};

// Object Name: Enum Solarland.EWeaponFireModeType
enum class EWeaponFireModeType : int32 {
	EWeaponFireModeType_UnArm = -1,
	EWeaponFireModeType_Primary = 0,
	EWeaponFireModeType_Secondary = 1,
	EWeaponFireModeType_Tertiary = 2,
	EWeaponFireModeType_MAX = 3
};

// Object Name: Enum Solarland.EWeaponScopeType
enum class EWeaponScopeType : uint8 {
	None = 0,
	ScopeX0 = 1,
	ScopeX1 = 2,
	ScopeX2 = 3,
	ScopeX3 = 4,
	ScopeX4 = 5,
	ScopeX6 = 6,
	ScopeX8 = 7,
	Count = 8,
	EWeaponScopeType_MAX = 9
};

// Object Name: Enum Solarland.EGearState
enum class EGearState : uint8 {
	Reverse = 0,
	Neutral = 1,
	Forward = 2,
	EGearState_MAX = 3
};

// Object Name: Enum Solarland.EInputEventHandleType
enum class EInputEventHandleType : uint8 {
	Unhandle = 0,
	SimulateKey = 1,
	BroadcastEvent = 2,
	SimulateTouch = 4,
	NoKeyOnly = 6,
	NoEventOnly = 5,
	NoTouchOnly = 3,
	HandleAll = 7,
	EInputEventHandleType_MAX = 8
};

// Object Name: Enum Solarland.ETouchMovePriority
enum class ETouchMovePriority : uint8 {
	Highest = 0,
	Higher = 1,
	Normal = 2,
	Lower = 3,
	Lowest = 4,
	ETouchMovePriority_MAX = 5
};

// Object Name: Enum Solarland.EZiplineSide
enum class EZiplineSide : uint8 {
	None = 0,
	Cable = 1,
	A = 2,
	B = 3,
	EZiplineSide_MAX = 4
};

// Object Name: Enum Solarland.EZiplineType
enum class EZiplineType : uint8 {
	Horizontal = 0,
	Vertical = 1,
	EZiplineType_MAX = 2
};

// Object Name: Enum Solarland.ESolarImageProgressHalfCirclePrivotType
enum class ESolarImageProgressHalfCirclePrivotType : uint8 {
	MidLeft = 0,
	MidRight = 1,
	MidBottom = 2,
	MidTop = 4,
	ESolarImageProgressHalfCirclePrivotType_MAX = 5
};

// Object Name: Enum Solarland.ESolarImageProgressQuaterCirclePrivotType
enum class ESolarImageProgressQuaterCirclePrivotType : uint8 {
	LeftBottom = 0,
	RightBottom = 1,
	LeftTop = 16,
	RightTop = 17,
	ESolarImageProgressQuaterCirclePrivotType_MAX = 18
};

// Object Name: Enum Solarland.ESolarImageProgressLineDirType
enum class ESolarImageProgressLineDirType : uint8 {
	Horizantal = 0,
	Vertical = 1,
	ESolarImageProgressLineDirType_MAX = 2
};

// Object Name: Enum Solarland.ESolarImageProgressType
enum class ESolarImageProgressType : uint8 {
	None = 0,
	Line = 1,
	QuarterCircle = 2,
	HalfCircle = 3,
	Circle = 4,
	ESolarImageProgressType_MAX = 5
};

// Object Name: Enum Solarland.ESolarImageFillType
enum class ESolarImageFillType : uint8 {
	Normal = 0,
	Mirror = 1,
	Quarter = 2,
	ESolarImageFillType_MAX = 3
};

// Object Name: Enum Solarland.ESolarSummonDeathReason
enum class ESolarSummonDeathReason : uint8 {
	SelfTimeDecay = 0,
	SelfLifeDecay = 1,
	OtherDestroy = 2,
	ESolarSummonDeathReason_MAX = 3
};

// Object Name: Enum Solarland.ESolarSummonSoundType
enum class ESolarSummonSoundType : uint8 {
	SummonSoundType_1P = 0,
	SummonSoundType_3P = 1,
	SummonSoundType_3P_Enemy = 2,
	SummonSoundType_MAX = 3
};

// Object Name: Enum Solarland.ESplineMeshType
enum class ESplineMeshType : uint8 {
	DEFAULT = 0,
	START = 1,
	END = 2,
	ESplineMeshType_MAX = 3
};

// Object Name: Enum Solarland.ETweenInterpolationType
enum class ETweenInterpolationType : uint8 {
	Easing = 0,
	Curve = 1,
	ETweenInterpolationType_MAX = 2
};

// Object Name: Enum Solarland.EDefenderTeamType
enum class EDefenderTeamType : uint8 {
	MyTeam = 0,
	DefenderTeam = 1,
	EDefenderTeamType_MAX = 2
};

// Object Name: Enum Solarland.EPlayerWidgetState
enum class EPlayerWidgetState : uint8 {
	NORMAL = 0,
	DRIVER = 1,
	PASSGNER = 2,
	EQUIPVEHICLEWEAPON = 3,
	CRUISING = 4,
	PATACHUTING = 5,
	SWIMMING = 6,
	MAX = 7
};

// Object Name: Enum Solarland.EUIRoot
enum class EUIRoot : uint8 {
	None = 0,
	UnderBattleRoot = 1,
	BattleRoot = 2,
	BattleRootGuide = 3,
	MiddleRoot = 4,
	CommonRoot = 5,
	Map = 6,
	BattleNoticeRoot = 7,
	Guide = 8,
	PopRoot = 9,
	TipsRoot = 10,
	NoticeRoot = 11,
	Loading = 12,
	Reconnecting = 13,
	ExternalToolsRoot = 255,
	EUIRoot_MAX = 256
};

// Object Name: Enum Solarland.ELocalNoticeType
enum class ELocalNoticeType : uint8 {
	Revenge = 0,
	KillDown = 1,
	ClearTeam = 2,
	ShutDown = 3,
	KillDefender = 4,
	ELocalNoticeType_MAX = 5
};

// Object Name: Enum Solarland.EUIWeaponPartState
enum class EUIWeaponPartState : uint8 {
	NotEquip = 0,
	Equipped = 1,
	CantEquip = 2,
	EUIWeaponPartState_MAX = 3
};

// Object Name: Enum Solarland.EWidgetVisibilityFlags
enum class EWidgetVisibilityFlags : uint8 {
	None = 0,
	ChatSwitch = 1,
	ChatMsgSending = 2,
	ConnectionState = 3,
	TalentState = 4,
	TalentValidation = 5,
	EWidgetVisibilityFlags_MAX = 6
};

// Object Name: Enum Solarland.EStealthParamType
enum class EStealthParamType : uint8 {
	None = 0,
	Type_1P = 1,
	Type_3P = 2,
	Type_3P_Enemy = 3,
	EStealthParamType_MAX = 4
};

// Object Name: Enum Solarland.EWholeShieldState
enum class EWholeShieldState : uint8 {
	Begin = 0,
	InProgress = 1,
	End = 2,
	EWholeShieldState_MAX = 3
};

// Object Name: Enum Solarland.EWeaponAnimState
enum class EWeaponAnimState : uint8 {
	Idle = 0,
	Fire = 1,
	AltFire = 2,
	Reload = 3,
	Overload = 4,
	OpenScope = 5,
	CloseScope = 6,
	Bolt = 7,
	Preview = 8,
	Summon = 9,
	EWeaponAnimState_MAX = 10
};

// Object Name: Enum Solarland.ESolarWeaponLODState
enum class ESolarWeaponLODState : uint8 {
	Hold = 0,
	OpenScope = 1,
	Discard = 2,
	ESolarWeaponLODState_MAX = 3
};

// Object Name: Enum Solarland.EWeaponSkinType
enum class EWeaponSkinType : uint8 {
	Material = 0,
	Mesh = 1,
	EWeaponSkinType_MAX = 2
};

// Object Name: Enum Solarland.EWeaponMechanicalSideFlag
enum class EWeaponMechanicalSideFlag : int32 {
	None = 0,
	OnGround = 2,
	Unequip = 4,
	OpenScope = 8,
	ForceFiring = 16,
	ChargedFire = 32,
	NeedBolt = 64,
	GatlingRolling = 128,
	DetectedWall = 256,
	NeedRechamber = 512,
	NoAmmoReserved = 1024,
	EWeaponMechanicalSideFlag_MAX = 1025
};

// Object Name: Enum Solarland.EWeaponMechanicalUniqueState
enum class EWeaponMechanicalUniqueState : uint8 {
	None = 0,
	Idle = 1,
	PreFire = 2,
	RealFire = 3,
	Rechamber = 4,
	Reloading = 5,
	Bolting = 6,
	Charging = 7,
	Overloading = 8,
	KeyUPHolding = 9,
	EWeaponMechanicalUniqueState_MAX = 10
};

// Object Name: Enum Solarland.EWeaponUpgradeType
enum class EWeaponUpgradeType : uint8 {
	EWeaponUpgradeType_Part = 0,
	EWeaponUpgradeType_SecondaryAmmo = 1,
	EWeaponUpgradeType_MAX = 2
};

// Object Name: Enum Solarland.EWeaponNetToClientProto
enum class EWeaponNetToClientProto : uint8 {
	CSkin_RefreshSkin = 0,
	CUpgrade_UpLevel = 1,
	CUpgrade_ExpRefresh = 2,
	CUpgrade_ReplaceUpgradeRoute = 3,
	CParts_ReplacePart = 4,
	CParts_ReplaceAmmo = 5,
	CParts_InitFinish = 6,
	CAnimation_RefreshState = 7,
	EWeaponNetToClientProto_MAX = 8
};

// Object Name: Enum Solarland.EWeaponNetToServerProto
enum class EWeaponNetToServerProto : uint8 {
	SUpgrade_AddExp = 0,
	SParts_Hold = 1,
	SAnimation_RefreshState = 2,
	EWeaponNetToServerProto_MAX = 3
};

// Object Name: Enum Solarland.EWeaponPartVisibilityChangeFlag
enum class EWeaponPartVisibilityChangeFlag : uint8 {
	Default = 0,
	BySignificance = 1,
	EWeaponPartVisibilityChangeFlag_MAX = 2
};

// Object Name: Enum Solarland.EFixedValueMode
enum class EFixedValueMode : uint8 {
	Raw = 0,
	Increment = 1,
	EFixedValueMode_MAX = 2
};

// Object Name: Enum Solarland.EWeaponSkewAdjustmentType
enum class EWeaponSkewAdjustmentType : uint8 {
	Pitch = 0,
	Yaw = 1,
	Roll = 2,
	XOffset = 3,
	YOffset = 4,
	ZOffset = 5,
	EWeaponSkewAdjustmentType_MAX = 6
};

// Object Name: Enum Solarland.EWeaponSkewInputType
enum class EWeaponSkewInputType : uint8 {
	PitchSpeed = 0,
	YawSpeed = 1,
	HorizontalSpeed = 2,
	VerticalSpeed = 3,
	EWeaponSkewInputType_MAX = 4
};

// Object Name: Enum Solarland.ESprayingRecoveryMode
enum class ESprayingRecoveryMode : uint8 {
	SyncWithRecoil = 0,
	RecoverByCurve = 1,
	ESprayingRecoveryMode_MAX = 2
};

// Object Name: Enum Solarland.EWeaponAttributeParamType
enum class EWeaponAttributeParamType : uint8 {
	ParamA = 0,
	ParamB = 1,
	ParamC = 2,
	ParamD = 3,
	EWeaponAttributeParamType_MAX = 4
};

// Object Name: Enum Solarland.ESpreadScaleDecreaseMode
enum class ESpreadScaleDecreaseMode : uint8 {
	DecreaseByFixedSpeed = 0,
	DecreaseByFixedTime = 1,
	ESpreadScaleDecreaseMode_MAX = 2
};

// Object Name: Enum Solarland.ESolarWeaponFireInputButtonState
enum class ESolarWeaponFireInputButtonState : uint8 {
	FireWaiting = 0,
	FirePressed = 1,
	CancelWaiting = 2,
	CancelPressed = 3,
	Invalid = 4,
	ESolarWeaponFireInputButtonState_MAX = 5
};

// Object Name: Enum Solarland.EWSCurWeaponUpdateType
enum class EWSCurWeaponUpdateType : uint8 {
	Switch = 0,
	PartUpdate = 1,
	EWSCurWeaponUpdateType_MAX = 2
};

// Object Name: Enum Solarland.ECheckFireResultType
enum class ECheckFireResultType : uint8 {
	None = 0,
	Fire = 1,
	Reload = 2,
	OpenScope = 3,
	CloseScope = 4,
	Charge = 5,
	EndCharge = 6,
	ECheckFireResultType_MAX = 7
};

// Object Name: Enum Solarland.EOperateScopeStateReason
enum class EOperateScopeStateReason : uint8 {
	None = 0,
	OpenScopeButton = 1,
	OpenQuickAds = 2,
	Open = 3,
	CloseReload = 16,
	CloseBolt = 32,
	Close = 48,
	AllFlag = 51,
	EOperateScopeStateReason_MAX = 52
};

// Object Name: Enum Solarland.EBehaviorExpID
enum class EBehaviorExpID : uint8 {
	Default = 0,
	KillPlayer = 2,
	AssistPlayer = 3,
	DamageExp = 9,
	KillNpc = 11,
	AssistNpc = 12,
	EBehaviorExpID_MAX = 13
};

// Object Name: Enum Solarland.EClientRecieveProto
enum class EClientRecieveProto : uint8 {
	PickUpWeapon = 0,
	DropWeapon = 1,
	SwitchWeaponFinish = 2,
	ReplaceWeapon = 3,
	WeaponDataUpdate = 4,
	AddExpMsg = 5,
	ClearWeapons = 6,
	ReloadCompleted = 7,
	EClientRecieveProto_MAX = 8
};

// Object Name: Enum Solarland.EServerRecieveProto
enum class EServerRecieveProto : uint8 {
	SwitchWeapon = 0,
	Reload = 1,
	ShowOrHideCurrent = 2,
	GameStaticsWeaponSkill = 3,
	DropItemWeapon = 4,
	ReplaceUpgradeRoute = 5,
	SwapWeapon = 6,
	EServerRecieveProto_MAX = 7
};

// Object Name: Enum Solarland.EAIPlayerServerRecieveProto
enum class EAIPlayerServerRecieveProto : uint8 {
	PickUpWeapon = 0,
	EAIPlayerServerRecieveProto_MAX = 1
};

// Object Name: Enum Solarland.EAIPlayerClientRecieveProto
enum class EAIPlayerClientRecieveProto : uint8 {
	PickUpWeapon = 0,
	SwitchWeapon = 1,
	EAIPlayerClientRecieveProto_MAX = 2
};

// Object Name: Enum Solarland.EVehicleWeaponServerRecieveProto
enum class EVehicleWeaponServerRecieveProto : uint8 {
	Reload = 0,
	StartReload = 1,
	EVehicleWeaponServerRecieveProto_MAX = 2
};

// Object Name: Enum Solarland.EWeaponSystemVehicleState
enum class EWeaponSystemVehicleState : uint8 {
	PreCharging = 0,
	PreFire = 1,
	PreReload = 2,
	PreOpenScope = 3,
	PreCloseScope = 4,
	PreFireOverload = 5,
	EWeaponSystemVehicleState_MAX = 6
};

// Object Name: Enum Solarland.EWeaponSystemVehicleProto
enum class EWeaponSystemVehicleProto : uint8 {
	EWeaponSystemVehicleProto_Equip = 0,
	EWeaponSystemVehicleProto_UnEquip = 1,
	EWeaponSystemVehicleProto_StartReload = 2,
	EWeaponSystemVehicleProto_MAX = 3
};

// Object Name: Enum Solarland.EMarkButtonState
enum class EMarkButtonState : uint8 {
	Normal = 0,
	Pressed = 1,
	Selecting = 2,
	Canceled = 3,
	Respond = 4,
	EMarkButtonState_MAX = 5
};

