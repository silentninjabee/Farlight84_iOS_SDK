#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct Synthesis.ModularSynthPresetBankEntry
// Size: 0xe0 // Inherited bytes: 0x00
struct FModularSynthPresetBankEntry {
	// Fields
	struct FString PresetName; // Offset: 0x00 // Size: 0x10
	struct FModularSynthPreset Preset; // Offset: 0x10 // Size: 0xd0
};

// Object Name: ScriptStruct Synthesis.ModularSynthPreset
// Size: 0xd0 // Inherited bytes: 0x08
struct FModularSynthPreset : FTableRowBase {
	// Fields
	char bEnablePolyphony : 1; // Offset: 0x08 // Size: 0x01
	char pad_0x8_1 : 7; // Offset: 0x08 // Size: 0x01
	enum class ESynth1OscType Osc1Type; // Offset: 0x09 // Size: 0x01
	char pad_0xA[0x2]; // Offset: 0x0a // Size: 0x02
	float Osc1Gain; // Offset: 0x0c // Size: 0x04
	float Osc1Octave; // Offset: 0x10 // Size: 0x04
	float Osc1Semitones; // Offset: 0x14 // Size: 0x04
	float Osc1Cents; // Offset: 0x18 // Size: 0x04
	float Osc1PulseWidth; // Offset: 0x1c // Size: 0x04
	enum class ESynth1OscType Osc2Type; // Offset: 0x20 // Size: 0x01
	char pad_0x21[0x3]; // Offset: 0x21 // Size: 0x03
	float Osc2Gain; // Offset: 0x24 // Size: 0x04
	float Osc2Octave; // Offset: 0x28 // Size: 0x04
	float Osc2Semitones; // Offset: 0x2c // Size: 0x04
	float Osc2Cents; // Offset: 0x30 // Size: 0x04
	float Osc2PulseWidth; // Offset: 0x34 // Size: 0x04
	float Portamento; // Offset: 0x38 // Size: 0x04
	char bEnableUnison : 1; // Offset: 0x3c // Size: 0x01
	char bEnableOscillatorSync : 1; // Offset: 0x3c // Size: 0x01
	char pad_0x3C_2 : 6; // Offset: 0x3c // Size: 0x01
	char pad_0x3D[0x3]; // Offset: 0x3d // Size: 0x03
	float Spread; // Offset: 0x40 // Size: 0x04
	float Pan; // Offset: 0x44 // Size: 0x04
	float LFO1Frequency; // Offset: 0x48 // Size: 0x04
	float LFO1Gain; // Offset: 0x4c // Size: 0x04
	enum class ESynthLFOType LFO1Type; // Offset: 0x50 // Size: 0x01
	enum class ESynthLFOMode LFO1Mode; // Offset: 0x51 // Size: 0x01
	enum class ESynthLFOPatchType LFO1PatchType; // Offset: 0x52 // Size: 0x01
	char pad_0x53[0x1]; // Offset: 0x53 // Size: 0x01
	float LFO2Frequency; // Offset: 0x54 // Size: 0x04
	float LFO2Gain; // Offset: 0x58 // Size: 0x04
	enum class ESynthLFOType LFO2Type; // Offset: 0x5c // Size: 0x01
	enum class ESynthLFOMode LFO2Mode; // Offset: 0x5d // Size: 0x01
	enum class ESynthLFOPatchType LFO2PatchType; // Offset: 0x5e // Size: 0x01
	char pad_0x5F[0x1]; // Offset: 0x5f // Size: 0x01
	float GainDb; // Offset: 0x60 // Size: 0x04
	float AttackTime; // Offset: 0x64 // Size: 0x04
	float DecayTime; // Offset: 0x68 // Size: 0x04
	float SustainGain; // Offset: 0x6c // Size: 0x04
	float ReleaseTime; // Offset: 0x70 // Size: 0x04
	enum class ESynthModEnvPatch ModEnvPatchType; // Offset: 0x74 // Size: 0x01
	enum class ESynthModEnvBiasPatch ModEnvBiasPatchType; // Offset: 0x75 // Size: 0x01
	char bInvertModulationEnvelope : 1; // Offset: 0x76 // Size: 0x01
	char bInvertModulationEnvelopeBias : 1; // Offset: 0x76 // Size: 0x01
	char pad_0x76_2 : 6; // Offset: 0x76 // Size: 0x01
	char pad_0x77[0x1]; // Offset: 0x77 // Size: 0x01
	float ModulationEnvelopeDepth; // Offset: 0x78 // Size: 0x04
	float ModulationEnvelopeAttackTime; // Offset: 0x7c // Size: 0x04
	float ModulationEnvelopeDecayTime; // Offset: 0x80 // Size: 0x04
	float ModulationEnvelopeSustainGain; // Offset: 0x84 // Size: 0x04
	float ModulationEnvelopeReleaseTime; // Offset: 0x88 // Size: 0x04
	char bLegato : 1; // Offset: 0x8c // Size: 0x01
	char bRetrigger : 1; // Offset: 0x8c // Size: 0x01
	char pad_0x8C_2 : 6; // Offset: 0x8c // Size: 0x01
	char pad_0x8D[0x3]; // Offset: 0x8d // Size: 0x03
	float FilterFrequency; // Offset: 0x90 // Size: 0x04
	float FilterQ; // Offset: 0x94 // Size: 0x04
	enum class ESynthFilterType FilterType; // Offset: 0x98 // Size: 0x01
	enum class ESynthFilterAlgorithm FilterAlgorithm; // Offset: 0x99 // Size: 0x01
	char bStereoDelayEnabled : 1; // Offset: 0x9a // Size: 0x01
	char pad_0x9A_1 : 7; // Offset: 0x9a // Size: 0x01
	enum class ESynthStereoDelayMode StereoDelayMode; // Offset: 0x9b // Size: 0x01
	float StereoDelayTime; // Offset: 0x9c // Size: 0x04
	float StereoDelayFeedback; // Offset: 0xa0 // Size: 0x04
	float StereoDelayWetlevel; // Offset: 0xa4 // Size: 0x04
	float StereoDelayRatio; // Offset: 0xa8 // Size: 0x04
	char bChorusEnabled : 1; // Offset: 0xac // Size: 0x01
	char pad_0xAC_1 : 7; // Offset: 0xac // Size: 0x01
	char pad_0xAD[0x3]; // Offset: 0xad // Size: 0x03
	float ChorusDepth; // Offset: 0xb0 // Size: 0x04
	float ChorusFeedback; // Offset: 0xb4 // Size: 0x04
	float ChorusFrequency; // Offset: 0xb8 // Size: 0x04
	char pad_0xBC[0x4]; // Offset: 0xbc // Size: 0x04
	struct TArray<struct FEpicSynth1Patch> Patches; // Offset: 0xc0 // Size: 0x10
};

// Object Name: ScriptStruct Synthesis.EpicSynth1Patch
// Size: 0x18 // Inherited bytes: 0x00
struct FEpicSynth1Patch {
	// Fields
	enum class ESynth1PatchSource PatchSource; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct TArray<struct FSynth1PatchCable> PatchCables; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct Synthesis.Synth1PatchCable
// Size: 0x08 // Inherited bytes: 0x00
struct FSynth1PatchCable {
	// Fields
	float Depth; // Offset: 0x00 // Size: 0x04
	enum class ESynth1PatchDestination Destination; // Offset: 0x04 // Size: 0x01
	char pad_0x5[0x3]; // Offset: 0x05 // Size: 0x03
};

// Object Name: ScriptStruct Synthesis.PatchId
// Size: 0x04 // Inherited bytes: 0x00
struct FPatchId {
	// Fields
	int32_t ID; // Offset: 0x00 // Size: 0x04
};

// Object Name: ScriptStruct Synthesis.SourceEffectBitCrusherSettings
// Size: 0x08 // Inherited bytes: 0x00
struct FSourceEffectBitCrusherSettings {
	// Fields
	float CrushedSampleRate; // Offset: 0x00 // Size: 0x04
	float CrushedBits; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct Synthesis.SourceEffectChorusSettings
// Size: 0x18 // Inherited bytes: 0x00
struct FSourceEffectChorusSettings {
	// Fields
	float Depth; // Offset: 0x00 // Size: 0x04
	float Frequency; // Offset: 0x04 // Size: 0x04
	float Feedback; // Offset: 0x08 // Size: 0x04
	float WetLevel; // Offset: 0x0c // Size: 0x04
	float DryLevel; // Offset: 0x10 // Size: 0x04
	float Spread; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct Synthesis.SourceEffectDynamicsProcessorSettings
// Size: 0x28 // Inherited bytes: 0x00
struct FSourceEffectDynamicsProcessorSettings {
	// Fields
	enum class ESourceEffectDynamicsProcessorType DynamicsProcessorType; // Offset: 0x00 // Size: 0x01
	enum class ESourceEffectDynamicsPeakMode PeakMode; // Offset: 0x01 // Size: 0x01
	char pad_0x2[0x2]; // Offset: 0x02 // Size: 0x02
	float LookAheadMsec; // Offset: 0x04 // Size: 0x04
	float AttackTimeMsec; // Offset: 0x08 // Size: 0x04
	float ReleaseTimeMsec; // Offset: 0x0c // Size: 0x04
	float ThresholdDb; // Offset: 0x10 // Size: 0x04
	float Ratio; // Offset: 0x14 // Size: 0x04
	float KneeBandwidthDb; // Offset: 0x18 // Size: 0x04
	float InputGainDb; // Offset: 0x1c // Size: 0x04
	float OutputGainDb; // Offset: 0x20 // Size: 0x04
	char bStereoLinked : 1; // Offset: 0x24 // Size: 0x01
	char bAnalogMode : 1; // Offset: 0x24 // Size: 0x01
	char pad_0x24_2 : 6; // Offset: 0x24 // Size: 0x01
	char pad_0x25[0x3]; // Offset: 0x25 // Size: 0x03
};

// Object Name: ScriptStruct Synthesis.SourceEffectEnvelopeFollowerSettings
// Size: 0x0c // Inherited bytes: 0x00
struct FSourceEffectEnvelopeFollowerSettings {
	// Fields
	float AttackTime; // Offset: 0x00 // Size: 0x04
	float ReleaseTime; // Offset: 0x04 // Size: 0x04
	enum class EEnvelopeFollowerPeakMode PeakMode; // Offset: 0x08 // Size: 0x01
	bool bIsAnalogMode; // Offset: 0x09 // Size: 0x01
	char pad_0xA[0x2]; // Offset: 0x0a // Size: 0x02
};

// Object Name: ScriptStruct Synthesis.SourceEffectEQSettings
// Size: 0x10 // Inherited bytes: 0x00
struct FSourceEffectEQSettings {
	// Fields
	struct TArray<struct FSourceEffectEQBand> EQBands; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct Synthesis.SourceEffectEQBand
// Size: 0x10 // Inherited bytes: 0x00
struct FSourceEffectEQBand {
	// Fields
	float Frequency; // Offset: 0x00 // Size: 0x04
	float Bandwidth; // Offset: 0x04 // Size: 0x04
	float GainDb; // Offset: 0x08 // Size: 0x04
	char bEnabled : 1; // Offset: 0x0c // Size: 0x01
	char pad_0xC_1 : 7; // Offset: 0x0c // Size: 0x01
	char pad_0xD[0x3]; // Offset: 0x0d // Size: 0x03
};

// Object Name: ScriptStruct Synthesis.SourceEffectFilterSettings
// Size: 0x0c // Inherited bytes: 0x00
struct FSourceEffectFilterSettings {
	// Fields
	enum class ESourceEffectFilterCircuit FilterCircuit; // Offset: 0x00 // Size: 0x01
	enum class ESourceEffectFilterType FilterType; // Offset: 0x01 // Size: 0x01
	char pad_0x2[0x2]; // Offset: 0x02 // Size: 0x02
	float CutoffFrequency; // Offset: 0x04 // Size: 0x04
	float FilterQ; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct Synthesis.SourceEffectFoldbackDistortionSettings
// Size: 0x0c // Inherited bytes: 0x00
struct FSourceEffectFoldbackDistortionSettings {
	// Fields
	float InputGainDb; // Offset: 0x00 // Size: 0x04
	float ThresholdDb; // Offset: 0x04 // Size: 0x04
	float OutputGainDb; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct Synthesis.SourceEffectMidSideSpreaderSettings
// Size: 0x0c // Inherited bytes: 0x00
struct FSourceEffectMidSideSpreaderSettings {
	// Fields
	enum class EStereoChannelMode InputMode; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float SpreadAmount; // Offset: 0x04 // Size: 0x04
	enum class EStereoChannelMode OutputMode; // Offset: 0x08 // Size: 0x01
	bool bEqualPower; // Offset: 0x09 // Size: 0x01
	char pad_0xA[0x2]; // Offset: 0x0a // Size: 0x02
};

// Object Name: ScriptStruct Synthesis.SourceEffectPannerSettings
// Size: 0x08 // Inherited bytes: 0x00
struct FSourceEffectPannerSettings {
	// Fields
	float Spread; // Offset: 0x00 // Size: 0x04
	float Pan; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct Synthesis.SourceEffectPhaserSettings
// Size: 0x10 // Inherited bytes: 0x00
struct FSourceEffectPhaserSettings {
	// Fields
	float WetLevel; // Offset: 0x00 // Size: 0x04
	float Frequency; // Offset: 0x04 // Size: 0x04
	float Feedback; // Offset: 0x08 // Size: 0x04
	enum class EPhaserLFOType LFOType; // Offset: 0x0c // Size: 0x01
	bool UseQuadraturePhase; // Offset: 0x0d // Size: 0x01
	char pad_0xE[0x2]; // Offset: 0x0e // Size: 0x02
};

// Object Name: ScriptStruct Synthesis.SourceEffectRingModulationSettings
// Size: 0x14 // Inherited bytes: 0x00
struct FSourceEffectRingModulationSettings {
	// Fields
	enum class ERingModulatorTypeSourceEffect ModulatorType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float Frequency; // Offset: 0x04 // Size: 0x04
	float Depth; // Offset: 0x08 // Size: 0x04
	float DryLevel; // Offset: 0x0c // Size: 0x04
	float WetLevel; // Offset: 0x10 // Size: 0x04
};

// Object Name: ScriptStruct Synthesis.SourceEffectSimpleDelaySettings
// Size: 0x18 // Inherited bytes: 0x00
struct FSourceEffectSimpleDelaySettings {
	// Fields
	float SpeedOfSound; // Offset: 0x00 // Size: 0x04
	float DelayAmount; // Offset: 0x04 // Size: 0x04
	float DryAmount; // Offset: 0x08 // Size: 0x04
	float WetAmount; // Offset: 0x0c // Size: 0x04
	float Feedback; // Offset: 0x10 // Size: 0x04
	char bDelayBasedOnDistance : 1; // Offset: 0x14 // Size: 0x01
	char pad_0x14_1 : 7; // Offset: 0x14 // Size: 0x01
	char pad_0x15[0x3]; // Offset: 0x15 // Size: 0x03
};

// Object Name: ScriptStruct Synthesis.SourceEffectStereoDelaySettings
// Size: 0x14 // Inherited bytes: 0x00
struct FSourceEffectStereoDelaySettings {
	// Fields
	enum class EStereoDelaySourceEffect DelayMode; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float DelayTimeMsec; // Offset: 0x04 // Size: 0x04
	float Feedback; // Offset: 0x08 // Size: 0x04
	float DelayRatio; // Offset: 0x0c // Size: 0x04
	float WetLevel; // Offset: 0x10 // Size: 0x04
};

// Object Name: ScriptStruct Synthesis.SourceEffectWaveShaperSettings
// Size: 0x08 // Inherited bytes: 0x00
struct FSourceEffectWaveShaperSettings {
	// Fields
	float Amount; // Offset: 0x00 // Size: 0x04
	float OutputGainDb; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct Synthesis.SubmixEffectConvolutionReverbSettings
// Size: 0x20 // Inherited bytes: 0x00
struct FSubmixEffectConvolutionReverbSettings {
	// Fields
	float NormalizationVolumeDb; // Offset: 0x00 // Size: 0x04
	float SurroundRearChannelBleedDb; // Offset: 0x04 // Size: 0x04
	bool bInvertRearChannelBleedPhase; // Offset: 0x08 // Size: 0x01
	bool bSurroundRearChannelFlip; // Offset: 0x09 // Size: 0x01
	char pad_0xA[0x2]; // Offset: 0x0a // Size: 0x02
	float SurroundRearChannelBleedAmount; // Offset: 0x0c // Size: 0x04
	struct UAudioImpulseResponse* ImpulseResponse; // Offset: 0x10 // Size: 0x08
	bool AllowHArdwareAcceleration; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x7]; // Offset: 0x19 // Size: 0x07
};

// Object Name: ScriptStruct Synthesis.SubmixEffectDelaySettings
// Size: 0x0c // Inherited bytes: 0x00
struct FSubmixEffectDelaySettings {
	// Fields
	float MaximumDelayLength; // Offset: 0x00 // Size: 0x04
	float InterpolationTime; // Offset: 0x04 // Size: 0x04
	float DelayLength; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct Synthesis.SubmixEffectFilterSettings
// Size: 0x0c // Inherited bytes: 0x00
struct FSubmixEffectFilterSettings {
	// Fields
	enum class ESubmixFilterType FilterType; // Offset: 0x00 // Size: 0x01
	enum class ESubmixFilterAlgorithm FilterAlgorithm; // Offset: 0x01 // Size: 0x01
	char pad_0x2[0x2]; // Offset: 0x02 // Size: 0x02
	float FilterFrequency; // Offset: 0x04 // Size: 0x04
	float FilterQ; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct Synthesis.SubmixEffectFlexiverbSettings
// Size: 0x10 // Inherited bytes: 0x00
struct FSubmixEffectFlexiverbSettings {
	// Fields
	float PreDelay; // Offset: 0x00 // Size: 0x04
	float DecayTime; // Offset: 0x04 // Size: 0x04
	float RoomDampening; // Offset: 0x08 // Size: 0x04
	int32_t Complexity; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct Synthesis.SubmixEffectTapDelaySettings
// Size: 0x18 // Inherited bytes: 0x00
struct FSubmixEffectTapDelaySettings {
	// Fields
	float MaximumDelayLength; // Offset: 0x00 // Size: 0x04
	float InterpolationTime; // Offset: 0x04 // Size: 0x04
	struct TArray<struct FTapDelayInfo> Taps; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct Synthesis.TapDelayInfo
// Size: 0x18 // Inherited bytes: 0x00
struct FTapDelayInfo {
	// Fields
	enum class ETapLineMode TapLineMode; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float DelayLength; // Offset: 0x04 // Size: 0x04
	float Gain; // Offset: 0x08 // Size: 0x04
	int32_t OutputChannel; // Offset: 0x0c // Size: 0x04
	float PanInDegrees; // Offset: 0x10 // Size: 0x04
	int32_t TapId; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct Synthesis.Synth2DSliderStyle
// Size: 0x308 // Inherited bytes: 0x08
struct FSynth2DSliderStyle : FSlateWidgetStyle {
	// Fields
	struct FSlateBrush NormalThumbImage; // Offset: 0x08 // Size: 0x98
	struct FSlateBrush DisabledThumbImage; // Offset: 0xa0 // Size: 0x98
	struct FSlateBrush NormalBarImage; // Offset: 0x138 // Size: 0x98
	struct FSlateBrush DisabledBarImage; // Offset: 0x1d0 // Size: 0x98
	struct FSlateBrush BackgroundImage; // Offset: 0x268 // Size: 0x98
	float BarThickness; // Offset: 0x300 // Size: 0x04
	char pad_0x304[0x4]; // Offset: 0x304 // Size: 0x04
};

// Object Name: ScriptStruct Synthesis.SynthKnobStyle
// Size: 0x278 // Inherited bytes: 0x08
struct FSynthKnobStyle : FSlateWidgetStyle {
	// Fields
	struct FSlateBrush LargeKnob; // Offset: 0x08 // Size: 0x98
	struct FSlateBrush LargeKnobOverlay; // Offset: 0xa0 // Size: 0x98
	struct FSlateBrush MediumKnob; // Offset: 0x138 // Size: 0x98
	struct FSlateBrush MediumKnobOverlay; // Offset: 0x1d0 // Size: 0x98
	float MinValueAngle; // Offset: 0x268 // Size: 0x04
	float MaxValueAngle; // Offset: 0x26c // Size: 0x04
	enum class ESynthKnobSize KnobSize; // Offset: 0x270 // Size: 0x01
	char pad_0x271[0x7]; // Offset: 0x271 // Size: 0x07
};

// Object Name: ScriptStruct Synthesis.SynthSlateStyle
// Size: 0x10 // Inherited bytes: 0x08
struct FSynthSlateStyle : FSlateWidgetStyle {
	// Fields
	enum class ESynthSlateSizeType SizeType; // Offset: 0x08 // Size: 0x01
	enum class ESynthSlateColorStyle ColorStyle; // Offset: 0x09 // Size: 0x01
	char pad_0xA[0x6]; // Offset: 0x0a // Size: 0x06
};

