#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class TemplateLoadingSystem.LoadingScreenSubsystem
// Size: 0x40 // Inherited bytes: 0x30
struct ULoadingScreenSubsystem : UGameInstanceSubsystem {
	// Fields
	struct ULoadingWidgetBase* LoadingWidget; // Offset: 0x30 // Size: 0x08
	char pad_0x38[0x8]; // Offset: 0x38 // Size: 0x08

	// Functions

	// Object Name: Function TemplateLoadingSystem.LoadingScreenSubsystem.StopLoadingScreen
	// Flags: [Final|Native|Public|BlueprintCallable]
	void StopLoadingScreen(); // Offset: 0x101087c7c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function TemplateLoadingSystem.LoadingScreenSubsystem.StartLoadingScreen
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct ULoadingWidgetBase* StartLoadingScreen(struct ULoadingWidgetBase* InWidgetClass); // Offset: 0x101087c90 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function TemplateLoadingSystem.LoadingScreenSubsystem.Get
	// Flags: [Final|Native|Static|Private]
	struct ULoadingScreenSubsystem* Get(struct UObject* WorldContextObject); // Offset: 0x101087bfc // Return & Params: Num(2) Size(0x10)
};

// Object Name: Class TemplateLoadingSystem.LoadingWidgetBase
// Size: 0x260 // Inherited bytes: 0x260
struct ULoadingWidgetBase : UUserWidget {
	// Functions

	// Object Name: Function TemplateLoadingSystem.LoadingWidgetBase.LoadingStarted
	// Flags: [Native|Event|Protected|BlueprintEvent]
	void LoadingStarted(); // Offset: 0x10108827c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function TemplateLoadingSystem.LoadingWidgetBase.LoadingFinished
	// Flags: [Native|Event|Protected|BlueprintEvent]
	void LoadingFinished(); // Offset: 0x101088260 // Return & Params: Num(0) Size(0x0)
};

