#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UIServerList_Item.UIServerList_Item_C
// Size: 0x360 // Inherited bytes: 0x348
struct UUIServerList_Item_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x348 // Size: 0x08
	struct UImage* Img_Selected; // Offset: 0x350 // Size: 0x08
	struct USolarTextBlock* Txt_ServerName; // Offset: 0x358 // Size: 0x08

	// Functions

	// Object Name: Function UIServerList_Item.UIServerList_Item_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	struct FString GetModuleName(); // Offset: 0x1032ea4b8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UIServerList_Item.UIServerList_Item_C.BP_OnEntryReleased
	// Flags: [Event|Protected|BlueprintEvent]
	void BP_OnEntryReleased(); // Offset: 0x1032ea4b8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UIServerList_Item.UIServerList_Item_C.BP_OnItemExpansionChanged
	// Flags: [Event|Protected|BlueprintEvent]
	void BP_OnItemExpansionChanged(bool bIsExpanded); // Offset: 0x1032ea4b8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UIServerList_Item.UIServerList_Item_C.BP_OnItemSelectionChanged
	// Flags: [Event|Protected|BlueprintEvent]
	void BP_OnItemSelectionChanged(bool bIsSelected); // Offset: 0x1032ea4b8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UIServerList_Item.UIServerList_Item_C.OnListItemObjectSet
	// Flags: [Event|Protected|BlueprintEvent]
	void OnListItemObjectSet(struct UObject* ListItemObject); // Offset: 0x1032ea4b8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UIServerList_Item.UIServerList_Item_C.ExecuteUbergraph_UIServerList_Item
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_UIServerList_Item(int32_t EntryPoint); // Offset: 0x1032ea4b8 // Return & Params: Num(1) Size(0x4)
};

