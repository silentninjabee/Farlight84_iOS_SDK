#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class UnLua.UnLuaInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UUnLuaInterface : UInterface {
	// Functions

	// Object Name: Function UnLua.UnLuaInterface.GetModuleName
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	struct FString GetModuleName(); // Offset: 0x101412980 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class UnLua.UnLuaManager
// Size: 0x518 // Inherited bytes: 0x28
struct UUnLuaManager : UObject {
	// Fields
	char pad_0x28[0x4f0]; // Offset: 0x28 // Size: 0x4f0

	// Functions

	// Object Name: Function UnLua.UnLuaManager.TriggerAnimNotify
	// Flags: [Event|Public|BlueprintEvent]
	void TriggerAnimNotify(); // Offset: 0x1032ea4b8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UnLua.UnLuaManager.OnLatentActionCompleted
	// Flags: [Final|Native|Public]
	void OnLatentActionCompleted(int32_t LinkID); // Offset: 0x101412dcc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UnLua.UnLuaManager.OnActorDestroyed
	// Flags: [Final|Native|Public]
	void OnActorDestroyed(struct AActor* Actor); // Offset: 0x101412e4c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UnLua.UnLuaManager.InputVectorAxis
	// Flags: [Event|Public|HasOutParms|HasDefaults|BlueprintEvent]
	void InputVectorAxis(struct FVector& AxisValue); // Offset: 0x1032ea4b8 // Return & Params: Num(1) Size(0xc)

	// Object Name: Function UnLua.UnLuaManager.InputTouch
	// Flags: [Event|Public|HasOutParms|HasDefaults|BlueprintEvent]
	void InputTouch(enum class ETouchIndex FingerIndex, struct FVector& Location); // Offset: 0x1032ea4b8 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UnLua.UnLuaManager.InputGesture
	// Flags: [Event|Public|BlueprintEvent]
	void InputGesture(float Value); // Offset: 0x1032ea4b8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UnLua.UnLuaManager.InputAxis
	// Flags: [Event|Public|BlueprintEvent]
	void InputAxis(float AxisValue); // Offset: 0x1032ea4b8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UnLua.UnLuaManager.InputAction
	// Flags: [Event|Public|BlueprintEvent]
	void InputAction(struct FKey Key); // Offset: 0x1032ea4b8 // Return & Params: Num(1) Size(0x18)
};

// Object Name: Class UnLua.UnLuaPerformanceTestProxy
// Size: 0x288 // Inherited bytes: 0x228
struct AUnLuaPerformanceTestProxy : AActor {
	// Fields
	char pad_0x228[0x8]; // Offset: 0x228 // Size: 0x08
	int32_t MeshID; // Offset: 0x230 // Size: 0x04
	char pad_0x234[0x4]; // Offset: 0x234 // Size: 0x04
	struct FString MeshName; // Offset: 0x238 // Size: 0x10
	struct FVector COM; // Offset: 0x248 // Size: 0x0c
	char pad_0x254[0x4]; // Offset: 0x254 // Size: 0x04
	struct TArray<int32_t> Indices; // Offset: 0x258 // Size: 0x10
	struct TArray<struct FVector> Positions; // Offset: 0x268 // Size: 0x10
	struct TArray<struct FVector> PredictedPositions; // Offset: 0x278 // Size: 0x10

	// Functions

	// Object Name: Function UnLua.UnLuaPerformanceTestProxy.UpdatePositions
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void UpdatePositions(struct TArray<struct FVector>& NewPositions); // Offset: 0x101413690 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UnLua.UnLuaPerformanceTestProxy.UpdateMeshName
	// Flags: [Final|Native|Public|BlueprintCallable]
	struct FString UpdateMeshName(struct FString NewName); // Offset: 0x1014139dc // Return & Params: Num(2) Size(0x20)

	// Object Name: Function UnLua.UnLuaPerformanceTestProxy.UpdateMeshID
	// Flags: [Final|Native|Public|BlueprintCallable]
	int32_t UpdateMeshID(int32_t NewID); // Offset: 0x101413ab0 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function UnLua.UnLuaPerformanceTestProxy.UpdateIndices
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void UpdateIndices(struct TArray<int32_t>& NewIndices); // Offset: 0x1014137c0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UnLua.UnLuaPerformanceTestProxy.Simulate
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Simulate(float DeltaTime); // Offset: 0x101413c38 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UnLua.UnLuaPerformanceTestProxy.Raycast
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	bool Raycast(struct FVector& Origin, struct FVector& Direction); // Offset: 0x1014138f0 // Return & Params: Num(3) Size(0x19)

	// Object Name: Function UnLua.UnLuaPerformanceTestProxy.NOP
	// Flags: [Final|Native|Public|BlueprintCallable]
	void NOP(); // Offset: 0x101413cb8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UnLua.UnLuaPerformanceTestProxy.GetPredictedPositions
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct TArray<struct FVector> GetPredictedPositions(); // Offset: 0x101413608 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UnLua.UnLuaPerformanceTestProxy.GetPositions
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetPositions(struct TArray<struct FVector>& OutPositions); // Offset: 0x101413728 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UnLua.UnLuaPerformanceTestProxy.GetMeshName
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FString GetMeshName(); // Offset: 0x101413b80 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UnLua.UnLuaPerformanceTestProxy.GetMeshInfo
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	bool GetMeshInfo(int32_t& OutMeshID, struct FString& OutMeshName, struct FVector& OutCOM, struct TArray<int32_t>& OutIndices, struct TArray<struct FVector>& OutPositions, struct TArray<struct FVector>& OutPredictedPositions); // Offset: 0x1014133a0 // Return & Params: Num(7) Size(0x59)

	// Object Name: Function UnLua.UnLuaPerformanceTestProxy.GetMeshID
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetMeshID(); // Offset: 0x101413c04 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UnLua.UnLuaPerformanceTestProxy.GetIndices
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetIndices(struct TArray<int32_t>& OutIndices); // Offset: 0x101413858 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UnLua.UnLuaPerformanceTestProxy.GetCOM
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FVector GetCOM(); // Offset: 0x101413b40 // Return & Params: Num(1) Size(0xc)
};

