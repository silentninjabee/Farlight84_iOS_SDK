#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class ACLPlugin.AnimationCompressionLibraryDatabase
// Size: 0x158 // Inherited bytes: 0x28
struct UAnimationCompressionLibraryDatabase : UObject {
	// Fields
	struct TArray<char> CookedCompressedBytes; // Offset: 0x28 // Size: 0x10
	struct TArray<uint64_t> CookedAnimSequenceMappings; // Offset: 0x38 // Size: 0x10
	char pad_0x48[0x108]; // Offset: 0x48 // Size: 0x108
	uint32_t MaxStreamRequestSizeKB; // Offset: 0x150 // Size: 0x04
	char pad_0x154[0x4]; // Offset: 0x154 // Size: 0x04

	// Functions

	// Object Name: Function ACLPlugin.AnimationCompressionLibraryDatabase.SetVisualFidelity
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void SetVisualFidelity(struct UObject* WorldContextObject, struct FLatentActionInfo LatentInfo, struct UAnimationCompressionLibraryDatabase* DatabaseAsset, enum class ACLVisualFidelityChangeResult& Result, enum class ACLVisualFidelity VisualFidelity); // Offset: 0x101b8d4bc // Return & Params: Num(5) Size(0x2a)

	// Object Name: Function ACLPlugin.AnimationCompressionLibraryDatabase.GetVisualFidelity
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	enum class ACLVisualFidelity GetVisualFidelity(struct UAnimationCompressionLibraryDatabase* DatabaseAsset); // Offset: 0x101b8d440 // Return & Params: Num(2) Size(0x9)
};

// Object Name: Class ACLPlugin.AnimBoneCompressionCodec_ACLBase
// Size: 0x38 // Inherited bytes: 0x38
struct UAnimBoneCompressionCodec_ACLBase : UAnimBoneCompressionCodec {
};

// Object Name: Class ACLPlugin.AnimBoneCompressionCodec_ACL
// Size: 0x40 // Inherited bytes: 0x38
struct UAnimBoneCompressionCodec_ACL : UAnimBoneCompressionCodec_ACLBase {
	// Fields
	struct UAnimBoneCompressionCodec* SafetyFallbackCodec; // Offset: 0x38 // Size: 0x08
};

// Object Name: Class ACLPlugin.AnimBoneCompressionCodec_ACLCustom
// Size: 0x38 // Inherited bytes: 0x38
struct UAnimBoneCompressionCodec_ACLCustom : UAnimBoneCompressionCodec_ACLBase {
};

// Object Name: Class ACLPlugin.AnimBoneCompressionCodec_ACLDatabase
// Size: 0x40 // Inherited bytes: 0x38
struct UAnimBoneCompressionCodec_ACLDatabase : UAnimBoneCompressionCodec_ACLBase {
	// Fields
	struct UAnimationCompressionLibraryDatabase* DatabaseAsset; // Offset: 0x38 // Size: 0x08
};

// Object Name: Class ACLPlugin.AnimBoneCompressionCodec_ACLSafe
// Size: 0x38 // Inherited bytes: 0x38
struct UAnimBoneCompressionCodec_ACLSafe : UAnimBoneCompressionCodec_ACLBase {
};

// Object Name: Class ACLPlugin.AnimCurveCompressionCodec_ACL
// Size: 0x28 // Inherited bytes: 0x28
struct UAnimCurveCompressionCodec_ACL : UAnimCurveCompressionCodec {
};

