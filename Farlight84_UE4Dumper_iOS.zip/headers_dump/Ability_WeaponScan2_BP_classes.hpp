#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass Ability_WeaponScan2_BP.Ability_WeaponScan2_BP_C
// Size: 0x3a0 // Inherited bytes: 0x3a0
struct AAbility_WeaponScan2_BP_C : ASolarRadarBase {
};

