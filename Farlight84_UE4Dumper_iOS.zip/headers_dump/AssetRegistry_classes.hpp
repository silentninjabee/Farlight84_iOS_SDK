#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class AssetRegistry.AssetRegistryImpl
// Size: 0x778 // Inherited bytes: 0x28
struct UAssetRegistryImpl : UObject {
	// Fields
	char pad_0x28[0x750]; // Offset: 0x28 // Size: 0x750
};

// Object Name: Class AssetRegistry.AssetRegistryHelpers
// Size: 0x28 // Inherited bytes: 0x28
struct UAssetRegistryHelpers : UObject {
	// Functions

	// Object Name: Function AssetRegistry.AssetRegistryHelpers.ToSoftObjectPath
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	struct FSoftObjectPath ToSoftObjectPath(struct FAssetData& InAssetData); // Offset: 0x104039f78 // Return & Params: Num(2) Size(0x68)

	// Object Name: Function AssetRegistry.AssetRegistryHelpers.SetFilterTagsAndValues
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FARFilter SetFilterTagsAndValues(struct FARFilter& InFilter, struct TArray<struct FTagAndValue>& InTagsAndValues); // Offset: 0x1040396f4 // Return & Params: Num(3) Size(0x1e0)

	// Object Name: Function AssetRegistry.AssetRegistryHelpers.IsValid
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	bool IsValid(struct FAssetData& InAssetData); // Offset: 0x10403a3e0 // Return & Params: Num(2) Size(0x51)

	// Object Name: Function AssetRegistry.AssetRegistryHelpers.IsUAsset
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	bool IsUAsset(struct FAssetData& InAssetData); // Offset: 0x10403a2e4 // Return & Params: Num(2) Size(0x51)

	// Object Name: Function AssetRegistry.AssetRegistryHelpers.IsRedirector
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	bool IsRedirector(struct FAssetData& InAssetData); // Offset: 0x10403a1e8 // Return & Params: Num(2) Size(0x51)

	// Object Name: Function AssetRegistry.AssetRegistryHelpers.IsAssetLoaded
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	bool IsAssetLoaded(struct FAssetData& InAssetData); // Offset: 0x104039c84 // Return & Params: Num(2) Size(0x51)

	// Object Name: Function AssetRegistry.AssetRegistryHelpers.GetTagValue
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	bool GetTagValue(struct FAssetData& InAssetData, struct FName& InTagName, struct FString& OutTagValue); // Offset: 0x1040399a0 // Return & Params: Num(4) Size(0x69)

	// Object Name: Function AssetRegistry.AssetRegistryHelpers.GetFullName
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FString GetFullName(struct FAssetData& InAssetData); // Offset: 0x10403a0b4 // Return & Params: Num(2) Size(0x60)

	// Object Name: Function AssetRegistry.AssetRegistryHelpers.GetExportTextName
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FString GetExportTextName(struct FAssetData& InAssetData); // Offset: 0x104039b50 // Return & Params: Num(2) Size(0x60)

	// Object Name: Function AssetRegistry.AssetRegistryHelpers.GetClass
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct UObject* GetClass(struct FAssetData& InAssetData); // Offset: 0x104039e7c // Return & Params: Num(2) Size(0x58)

	// Object Name: Function AssetRegistry.AssetRegistryHelpers.GetAssetRegistry
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct TScriptInterface<IAssetRegistry> GetAssetRegistry(); // Offset: 0x10403a6d4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AssetRegistry.AssetRegistryHelpers.GetAsset
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct UObject* GetAsset(struct FAssetData& InAssetData); // Offset: 0x104039d80 // Return & Params: Num(2) Size(0x58)

	// Object Name: Function AssetRegistry.AssetRegistryHelpers.CreateAssetData
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FAssetData CreateAssetData(struct UObject* InAsset, bool bAllowBlueprintClass); // Offset: 0x10403a4dc // Return & Params: Num(3) Size(0x60)
};

// Object Name: Class AssetRegistry.AssetRegistry
// Size: 0x28 // Inherited bytes: 0x28
struct UAssetRegistry : UInterface {
	// Functions

	// Object Name: Function AssetRegistry.AssetRegistry.UseFilterToExcludeAssets
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|Const]
	void UseFilterToExcludeAssets(struct TArray<struct FAssetData>& AssetDataList, struct FARFilter& Filter); // Offset: 0x10403b2cc // Return & Params: Num(2) Size(0xf8)

	// Object Name: Function AssetRegistry.AssetRegistry.SearchAllAssets
	// Flags: [Native|Public|BlueprintCallable]
	void SearchAllAssets(bool bSynchronousSearch); // Offset: 0x10403aff8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AssetRegistry.AssetRegistry.ScanPathsSynchronous
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	void ScanPathsSynchronous(struct TArray<struct FString>& InPaths, bool bForceRescan); // Offset: 0x10403b1a8 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function AssetRegistry.AssetRegistry.ScanModifiedAssetFiles
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	void ScanModifiedAssetFiles(struct TArray<struct FString>& InFilePaths); // Offset: 0x10403ae94 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AssetRegistry.AssetRegistry.ScanFilesSynchronous
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	void ScanFilesSynchronous(struct TArray<struct FString>& InFilePaths, bool bForceRescan); // Offset: 0x10403b084 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function AssetRegistry.AssetRegistry.RunAssetsThroughFilter
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|Const]
	void RunAssetsThroughFilter(struct TArray<struct FAssetData>& AssetDataList, struct FARFilter& Filter); // Offset: 0x10403b4a8 // Return & Params: Num(2) Size(0xf8)

	// Object Name: Function AssetRegistry.AssetRegistry.PrioritizeSearchPath
	// Flags: [Native|Public|BlueprintCallable]
	void PrioritizeSearchPath(struct FString PathToPrioritize); // Offset: 0x10403af68 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AssetRegistry.AssetRegistry.K2_GetReferencers
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|Const]
	bool K2_GetReferencers(struct FName PackageName, struct FAssetRegistryDependencyOptions& ReferenceOptions, struct TArray<struct FName>& OutReferencers); // Offset: 0x10403b8d0 // Return & Params: Num(4) Size(0x21)

	// Object Name: Function AssetRegistry.AssetRegistry.K2_GetDependencies
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|Const]
	bool K2_GetDependencies(struct FName PackageName, struct FAssetRegistryDependencyOptions& DependencyOptions, struct TArray<struct FName>& OutDependencies); // Offset: 0x10403ba28 // Return & Params: Num(4) Size(0x21)

	// Object Name: Function AssetRegistry.AssetRegistry.IsLoadingAssets
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsLoadingAssets(); // Offset: 0x10403ae58 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AssetRegistry.AssetRegistry.HasAssets
	// Flags: [Native|Public|BlueprintCallable|Const]
	bool HasAssets(struct FName PackagePath, bool bRecursive); // Offset: 0x10403c6ac // Return & Params: Num(3) Size(0xa)

	// Object Name: Function AssetRegistry.AssetRegistry.GetSubPaths
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|Const]
	void GetSubPaths(struct FString InBasePath, struct TArray<struct FString>& OutPathList, bool bInRecurse); // Offset: 0x10403b684 // Return & Params: Num(3) Size(0x21)

	// Object Name: Function AssetRegistry.AssetRegistry.GetAssetsByPath
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|Const]
	bool GetAssetsByPath(struct FName PackagePath, struct TArray<struct FAssetData>& OutAssetData, bool bRecursive, bool bIncludeOnlyOnDiskAssets); // Offset: 0x10403c2bc // Return & Params: Num(5) Size(0x1b)

	// Object Name: Function AssetRegistry.AssetRegistry.GetAssetsByPackageName
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|Const]
	bool GetAssetsByPackageName(struct FName PackageName, struct TArray<struct FAssetData>& OutAssetData, bool bIncludeOnlyOnDiskAssets); // Offset: 0x10403c4e0 // Return & Params: Num(4) Size(0x1a)

	// Object Name: Function AssetRegistry.AssetRegistry.GetAssetsByClass
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|Const]
	bool GetAssetsByClass(struct FName ClassName, struct TArray<struct FAssetData>& OutAssetData, bool bSearchSubClasses); // Offset: 0x10403c0f0 // Return & Params: Num(4) Size(0x1a)

	// Object Name: Function AssetRegistry.AssetRegistry.GetAssets
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|Const]
	bool GetAssets(struct FARFilter& Filter, struct TArray<struct FAssetData>& OutAssetData); // Offset: 0x10403bf0c // Return & Params: Num(3) Size(0xf9)

	// Object Name: Function AssetRegistry.AssetRegistry.GetAssetByObjectPath
	// Flags: [Native|Public|BlueprintCallable|Const]
	struct FAssetData GetAssetByObjectPath(struct FName ObjectPath, bool bIncludeOnlyOnDiskAssets); // Offset: 0x10403bd04 // Return & Params: Num(3) Size(0x60)

	// Object Name: Function AssetRegistry.AssetRegistry.GetAllCachedPaths
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|Const]
	void GetAllCachedPaths(struct TArray<struct FString>& OutPathList); // Offset: 0x10403b7fc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AssetRegistry.AssetRegistry.GetAllAssets
	// Flags: [Native|Public|HasOutParms|BlueprintCallable|Const]
	bool GetAllAssets(struct TArray<struct FAssetData>& OutAssetData, bool bIncludeOnlyOnDiskAssets); // Offset: 0x10403bb80 // Return & Params: Num(3) Size(0x12)
};

