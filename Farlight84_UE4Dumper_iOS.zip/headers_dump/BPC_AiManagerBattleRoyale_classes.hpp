#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BPC_AiManagerBattleRoyale.BPC_AiManagerBattleRoyale_C
// Size: 0x250 // Inherited bytes: 0xe8
struct UBPC_AiManagerBattleRoyale_C : UBPC_AiManagerBase_C {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0xe8 // Size: 0x08
	struct TArray<struct ASCMPlayerState*> TempAI; // Offset: 0xf0 // Size: 0x10
	struct TMap<struct FString, int32_t> MemberAIOrder; // Offset: 0x100 // Size: 0x50
	int32_t SpawnIndex; // Offset: 0x150 // Size: 0x04
	bool bCanSpawn; // Offset: 0x154 // Size: 0x01
	char pad_0x155[0x3]; // Offset: 0x155 // Size: 0x03
	struct TMap<struct FString, int32_t> PureAIOrder; // Offset: 0x158 // Size: 0x50
	bool bSpawnPlayerTeammate; // Offset: 0x1a8 // Size: 0x01
	char pad_0x1A9[0x3]; // Offset: 0x1a9 // Size: 0x03
	int32_t AiCountPreSpawn; // Offset: 0x1ac // Size: 0x04
	int32_t RealPlayer; // Offset: 0x1b0 // Size: 0x04
	char pad_0x1B4[0x4]; // Offset: 0x1b4 // Size: 0x04
	struct TArray<struct ASCMPlayerState*> TeammateAI; // Offset: 0x1b8 // Size: 0x10
	bool bTeammateAiFinished; // Offset: 0x1c8 // Size: 0x01
	char pad_0x1C9[0x7]; // Offset: 0x1c9 // Size: 0x07
	struct FS_WarmGameConfig WarmGameConfig; // Offset: 0x1d0 // Size: 0x18
	bool bIsWarmGame; // Offset: 0x1e8 // Size: 0x01
	char pad_0x1E9[0x7]; // Offset: 0x1e9 // Size: 0x07
	struct TArray<struct FString> PureAiSides; // Offset: 0x1f0 // Size: 0x10
	struct TMap<struct FString, bool> TeammateAIConditions; // Offset: 0x200 // Size: 0x50

	// Functions

	// Object Name: Function BPC_AiManagerBattleRoyale.BPC_AiManagerBattleRoyale_C.ReplenishAITeammate
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void ReplenishAITeammate(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BPC_AiManagerBattleRoyale.BPC_AiManagerBattleRoyale_C.GetCountDownComponent
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	struct UBPC_CountDown_C* GetCountDownComponent(); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function BPC_AiManagerBattleRoyale.BPC_AiManagerBattleRoyale_C.StopAiBehavior
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void StopAiBehavior(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BPC_AiManagerBattleRoyale.BPC_AiManagerBattleRoyale_C.CanModeSpawnAiTeammate
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	bool CanModeSpawnAiTeammate(); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function BPC_AiManagerBattleRoyale.BPC_AiManagerBattleRoyale_C.GetAIController
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void GetAIController(struct ASolarPlayerState* PlayerState, struct ASolarBotAIController*& Controller); // Offset: 0x102f67d18 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function BPC_AiManagerBattleRoyale.BPC_AiManagerBattleRoyale_C.SpawnAI
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SpawnAI(bool bTeammateAI, struct FString Side, struct ASCMPlayerState*& PlayerState); // Offset: 0x102f67d18 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function BPC_AiManagerBattleRoyale.BPC_AiManagerBattleRoyale_C.GetSpawnInterval
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void GetSpawnInterval(float& Interval); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function BPC_AiManagerBattleRoyale.BPC_AiManagerBattleRoyale_C.UpdatePureAiOrder
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void UpdatePureAiOrder(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BPC_AiManagerBattleRoyale.BPC_AiManagerBattleRoyale_C.PickSide
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void PickSide(bool RealPlayerTeam, struct FString& Side); // Offset: 0x102f67d18 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function BPC_AiManagerBattleRoyale.BPC_AiManagerBattleRoyale_C.DeleteTempAI
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void DeleteTempAI(int32_t count); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function BPC_AiManagerBattleRoyale.BPC_AiManagerBattleRoyale_C.RunBehaviourTree
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void RunBehaviourTree(struct ASCMPlayerState* Player, struct UBehaviorTree* BTAsset); // Offset: 0x102f67d18 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function BPC_AiManagerBattleRoyale.BPC_AiManagerBattleRoyale_C.SpawnLocation
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	struct FVector SpawnLocation(); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0xc)

	// Object Name: Function BPC_AiManagerBattleRoyale.BPC_AiManagerBattleRoyale_C.IsPlayerFull
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	bool IsPlayerFull(); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function BPC_AiManagerBattleRoyale.BPC_AiManagerBattleRoyale_C.GetLogicComponent
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	struct UBP_Logic_BattleRoyale_C* GetLogicComponent(); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function BPC_AiManagerBattleRoyale.BPC_AiManagerBattleRoyale_C.MatchFinished
	// Flags: [BlueprintCallable|BlueprintEvent]
	void MatchFinished(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BPC_AiManagerBattleRoyale.BPC_AiManagerBattleRoyale_C.PreSpawnAI
	// Flags: [BlueprintCallable|BlueprintEvent]
	void PreSpawnAI(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BPC_AiManagerBattleRoyale.BPC_AiManagerBattleRoyale_C.ReceiveBeginPlay
	// Flags: [Event|Public|BlueprintEvent]
	void ReceiveBeginPlay(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BPC_AiManagerBattleRoyale.BPC_AiManagerBattleRoyale_C.SpawnAIDynamic
	// Flags: [BlueprintCallable|BlueprintEvent]
	void SpawnAIDynamic(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BPC_AiManagerBattleRoyale.BPC_AiManagerBattleRoyale_C.OnBattleStateChanged
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnBattleStateChanged(enum class E_BattleState_BattleRoyale NewState); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function BPC_AiManagerBattleRoyale.BPC_AiManagerBattleRoyale_C.CustomEvent_2
	// Flags: [BlueprintCallable|BlueprintEvent]
	void CustomEvent_2(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BPC_AiManagerBattleRoyale.BPC_AiManagerBattleRoyale_C.OnPlayerJoin
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnPlayerJoin(struct ASCMPlayerState* NewPlayer, bool bIsAi); // Offset: 0x102f67d18 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function BPC_AiManagerBattleRoyale.BPC_AiManagerBattleRoyale_C.CreateTeammateAIOrder
	// Flags: [BlueprintCallable|BlueprintEvent]
	void CreateTeammateAIOrder(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BPC_AiManagerBattleRoyale.BPC_AiManagerBattleRoyale_C.ExecuteUbergraph_BPC_AiManagerBattleRoyale
	// Flags: [Final|UbergraphFunction|HasDefaults]
	void ExecuteUbergraph_BPC_AiManagerBattleRoyale(int32_t EntryPoint); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x4)
};

