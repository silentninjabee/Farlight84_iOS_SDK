#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BPC_Death_BattleRoyale.BPC_Death_BattleRoyale_C
// Size: 0x240 // Inherited bytes: 0x112
struct UBPC_Death_BattleRoyale_C : UBPC_Death_Framework_C {
	// Fields
	char pad_0x112[0x6]; // Offset: 0x112 // Size: 0x06
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x118 // Size: 0x08
	struct ABP_ReviveItemManger_BattleRoyale_C* ReviveItemManger; // Offset: 0x120 // Size: 0x08
	struct ASCMPlayerState* Killer; // Offset: 0x128 // Size: 0x08
	struct ASCMPlayerState* Killed; // Offset: 0x130 // Size: 0x08
	struct FSolarPointDamageEvent DeathDamageEvent; // Offset: 0x138 // Size: 0x108

	// Functions

	// Object Name: Function BPC_Death_BattleRoyale.BPC_Death_BattleRoyale_C.Out Put Kill Log
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void Out Put Kill Log(bool InBool); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function BPC_Death_BattleRoyale.BPC_Death_BattleRoyale_C.SendSideSettle
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SendSideSettle(struct FString Side); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function BPC_Death_BattleRoyale.BPC_Death_BattleRoyale_C.TryRevivePlayerbyCoin
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void TryRevivePlayerbyCoin(struct ABP_PlayerState_BattleRoyale_C* Player, bool& Succeed); // Offset: 0x102f67d18 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function BPC_Death_BattleRoyale.BPC_Death_BattleRoyale_C.CanPlayerBattle
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	bool CanPlayerBattle(struct ASCMPlayerState* Player); // Offset: 0x102f67d18 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function BPC_Death_BattleRoyale.BPC_Death_BattleRoyale_C.GetMainLogic
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	struct UBP_Logic_BattleRoyale_C* GetMainLogic(); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function BPC_Death_BattleRoyale.BPC_Death_BattleRoyale_C.GetConiReviveManager
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void GetConiReviveManager(struct ABP_ReviveItemManger_BattleRoyale_C*& Output_Get); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function BPC_Death_BattleRoyale.BPC_Death_BattleRoyale_C.ReceiveBeginPlay
	// Flags: [Event|Public|BlueprintEvent]
	void ReceiveBeginPlay(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BPC_Death_BattleRoyale.BPC_Death_BattleRoyale_C.ReceivePlayerKill
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	void ReceivePlayerKill(struct ASCMPlayerState* Killer, struct ASCMPlayerState* Killed, struct TArray<struct ASCMPlayerState*>& Assists, struct FSolarPointDamageEvent& InDamageEvent, struct AActor* InDamageCauser); // Offset: 0x102f67d18 // Return & Params: Num(5) Size(0x130)

	// Object Name: Function BPC_Death_BattleRoyale.BPC_Death_BattleRoyale_C.OnBattleStateChanged
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnBattleStateChanged(enum class ESCMDataChangeType ChangeType, char OldValue, char NewValue); // Offset: 0x102f67d18 // Return & Params: Num(3) Size(0x3)

	// Object Name: Function BPC_Death_BattleRoyale.BPC_Death_BattleRoyale_C.ReceivePlayerDeathVerge
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	void ReceivePlayerDeathVerge(struct ASCMPlayerState* InAttacker, struct ASCMPlayerState* InDeathVergePlayer, struct FSolarPointDamageEvent& InDamageEvent, struct AActor* InDamageCauser); // Offset: 0x102f67d18 // Return & Params: Num(4) Size(0x120)

	// Object Name: Function BPC_Death_BattleRoyale.BPC_Death_BattleRoyale_C.ReceivePlayerResurrect
	// Flags: [Event|Public|BlueprintEvent]
	void ReceivePlayerResurrect(struct ASolarCharacter* ResurrectCharacter, struct ASCMPlayerState* ResurrectPlayer); // Offset: 0x102f67d18 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function BPC_Death_BattleRoyale.BPC_Death_BattleRoyale_C.ExecuteUbergraph_BPC_Death_BattleRoyale
	// Flags: [Final|UbergraphFunction|HasDefaults]
	void ExecuteUbergraph_BPC_Death_BattleRoyale(int32_t EntryPoint); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x4)
};

