#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BPC_RequestMessage.BPC_RequestMessage_C
// Size: 0x130 // Inherited bytes: 0xb0
struct UBPC_RequestMessage_C : UActorComponent {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0xb0 // Size: 0x08
	struct TMap<struct FString, struct UBP_MessageObj_C*> Queryer; // Offset: 0xb8 // Size: 0x50
	struct FMulticastInlineDelegate OnReceiveRequest; // Offset: 0x108 // Size: 0x10
	struct FMulticastInlineDelegate OnGetReply; // Offset: 0x118 // Size: 0x10
	struct ABP_RequestMessage_C* CommonMessageManager; // Offset: 0x128 // Size: 0x08

	// Functions

	// Object Name: Function BPC_RequestMessage.BPC_RequestMessage_C.GetOwnerPlayerID
	// Flags: [Private|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void GetOwnerPlayerID(int32_t& PlayerId); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function BPC_RequestMessage.BPC_RequestMessage_C.GetTargetComponent
	// Flags: [Private|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	struct UBPC_RequestMessage_C* GetTargetComponent(int32_t TargetPlayerID); // Offset: 0x102f67d18 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function BPC_RequestMessage.BPC_RequestMessage_C.[c]SendMessage
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void [c]SendMessage(struct FS_MessageRequest MessageInfo, int32_t Lifetime, struct FString& Key); // Offset: 0x102f67d18 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function BPC_RequestMessage.BPC_RequestMessage_C.ToMessageInfo
	// Flags: [Private|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void ToMessageInfo(struct FString Key, struct FS_MessageRequest& MessageInfo); // Offset: 0x102f67d18 // Return & Params: Num(2) Size(0x1c)

	// Object Name: Function BPC_RequestMessage.BPC_RequestMessage_C.ToString
	// Flags: [Private|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void ToString(struct FS_MessageRequest MessageInfo, struct FString& Key); // Offset: 0x102f67d18 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function BPC_RequestMessage.BPC_RequestMessage_C.ReceiveBeginPlay
	// Flags: [Event|Public|BlueprintEvent]
	void ReceiveBeginPlay(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BPC_RequestMessage.BPC_RequestMessage_C.MessageManage
	// Flags: [Net|NetServer|BlueprintCallable|BlueprintEvent]
	void MessageManage(struct FS_MessageRequest MessageInfo, int32_t Lifetime); // Offset: 0x102f67d18 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function BPC_RequestMessage.BPC_RequestMessage_C.ReceiveRequest
	// Flags: [Net|NetClient|BlueprintCallable|BlueprintEvent]
	void ReceiveRequest(struct FS_MessageRequest Info); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0xc)

	// Object Name: Function BPC_RequestMessage.BPC_RequestMessage_C.ReplyMessage
	// Flags: [BlueprintCallable|BlueprintEvent]
	void ReplyMessage(struct FString Handle, bool Reply, int32_t BlockTime); // Offset: 0x102f67d18 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function BPC_RequestMessage.BPC_RequestMessage_C.ReplyDeal
	// Flags: [Net|NetServer|BlueprintCallable|BlueprintEvent]
	void ReplyDeal(struct FString Handle, bool Reply, int32_t BlockTime); // Offset: 0x102f67d18 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function BPC_RequestMessage.BPC_RequestMessage_C.SendReply
	// Flags: [Net|NetClient|BlueprintCallable|BlueprintEvent]
	void SendReply(struct FS_MessageRequest Info, bool Reply); // Offset: 0x102f67d18 // Return & Params: Num(2) Size(0xd)

	// Object Name: Function BPC_RequestMessage.BPC_RequestMessage_C.Timeout
	// Flags: [BlueprintCallable|BlueprintEvent]
	void Timeout(struct FS_MessageRequest Info); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0xc)

	// Object Name: Function BPC_RequestMessage.BPC_RequestMessage_C.ExecuteUbergraph_BPC_RequestMessage
	// Flags: [Final|UbergraphFunction|HasDefaults]
	void ExecuteUbergraph_BPC_RequestMessage(int32_t EntryPoint); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function BPC_RequestMessage.BPC_RequestMessage_C.OnGetReply__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void OnGetReply__DelegateSignature(struct FString Handle, bool Reply, char Type, int32_t ReplierPlayerID); // Offset: 0x102f67d18 // Return & Params: Num(4) Size(0x18)

	// Object Name: Function BPC_RequestMessage.BPC_RequestMessage_C.OnReceiveRequest__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void OnReceiveRequest__DelegateSignature(struct FString Handle, char Type, int32_t SenderPlayerID); // Offset: 0x102f67d18 // Return & Params: Num(3) Size(0x18)
};

