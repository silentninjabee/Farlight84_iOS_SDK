#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BPI_ReviveItemCamera.BPI_ReviveItemCamera_C
// Size: 0x28 // Inherited bytes: 0x28
struct UBPI_ReviveItemCamera_C : UInterface {
	// Functions

	// Object Name: Function BPI_ReviveItemCamera.BPI_ReviveItemCamera_C.SetReviveCameraFade
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetReviveCameraFade(float Time); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x4)
};

