#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_Ability_SmokeGrenade.BP_Ability_SmokeGrenade_C
// Size: 0x3f0 // Inherited bytes: 0x3b0
struct ABP_Ability_SmokeGrenade_C : AWeaponHitAbility {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x3b0 // Size: 0x08
	struct USolarGameplaySmokeComponent* Smoke; // Offset: 0x3b8 // Size: 0x08
	struct UParticleSystemComponent* FX_SmokeShell; // Offset: 0x3c0 // Size: 0x08
	float SmokeFadeOut_Alpha_3E9C3E664BF7E30B8AC9DD9276A8ACCE; // Offset: 0x3c8 // Size: 0x04
	enum class ETimelineDirection SmokeFadeOut__Direction_3E9C3E664BF7E30B8AC9DD9276A8ACCE; // Offset: 0x3cc // Size: 0x01
	char pad_0x3CD[0x3]; // Offset: 0x3cd // Size: 0x03
	struct UTimelineComponent* SmokeFadeOut; // Offset: 0x3d0 // Size: 0x08
	float SmokeFadeIn_Alpha_3B8839634FFDF220C79937AFE6C47DC9; // Offset: 0x3d8 // Size: 0x04
	enum class ETimelineDirection SmokeFadeIn__Direction_3B8839634FFDF220C79937AFE6C47DC9; // Offset: 0x3dc // Size: 0x01
	char pad_0x3DD[0x3]; // Offset: 0x3dd // Size: 0x03
	struct UTimelineComponent* SmokeFadeIn; // Offset: 0x3e0 // Size: 0x08
	int32_t TranslucentSortPriority; // Offset: 0x3e8 // Size: 0x04
	float SmokeVFXLifeTime; // Offset: 0x3ec // Size: 0x04

	// Functions

	// Object Name: Function BP_Ability_SmokeGrenade.BP_Ability_SmokeGrenade_C.SmokeFadeIn__FinishedFunc
	// Flags: [BlueprintEvent]
	void SmokeFadeIn__FinishedFunc(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_Ability_SmokeGrenade.BP_Ability_SmokeGrenade_C.SmokeFadeIn__UpdateFunc
	// Flags: [BlueprintEvent]
	void SmokeFadeIn__UpdateFunc(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_Ability_SmokeGrenade.BP_Ability_SmokeGrenade_C.SmokeFadeOut__FinishedFunc
	// Flags: [BlueprintEvent]
	void SmokeFadeOut__FinishedFunc(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_Ability_SmokeGrenade.BP_Ability_SmokeGrenade_C.SmokeFadeOut__UpdateFunc
	// Flags: [BlueprintEvent]
	void SmokeFadeOut__UpdateFunc(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_Ability_SmokeGrenade.BP_Ability_SmokeGrenade_C.ReceiveBeginPlay
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveBeginPlay(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_Ability_SmokeGrenade.BP_Ability_SmokeGrenade_C.ReceiveEndPlay
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveEndPlay(enum class EEndPlayReason EndPlayReason); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function BP_Ability_SmokeGrenade.BP_Ability_SmokeGrenade_C.ExecuteUbergraph_BP_Ability_SmokeGrenade
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_BP_Ability_SmokeGrenade(int32_t EntryPoint); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x4)
};

