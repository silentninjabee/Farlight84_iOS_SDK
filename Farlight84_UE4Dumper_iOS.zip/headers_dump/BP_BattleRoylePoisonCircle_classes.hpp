#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_BattleRoylePoisonCircle.BP_BattleRoylePoisonCircle_C
// Size: 0x44c // Inherited bytes: 0x44c
struct ABP_BattleRoylePoisonCircle_C : ABP_CustomPoisonCircle_Template_C {
	// Functions

	// Object Name: Function BP_BattleRoylePoisonCircle.BP_BattleRoylePoisonCircle_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	struct FString GetModuleName(); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x10)
};

