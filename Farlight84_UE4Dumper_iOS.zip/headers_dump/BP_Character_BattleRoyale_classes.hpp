#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_Character_BattleRoyale.BP_Character_BattleRoyale_C
// Size: 0x2640 // Inherited bytes: 0x25a4
struct ABP_Character_BattleRoyale_C : ABP_Character_Framework_C {
	// Fields
	char pad_0x25A4[0x4]; // Offset: 0x25a4 // Size: 0x04
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x25a8 // Size: 0x08
	struct FMulticastInlineDelegate OnPlayerRevive; // Offset: 0x25b0 // Size: 0x10
	struct UActorMarkBase* DeathBoxMark; // Offset: 0x25c0 // Size: 0x08
	struct TArray<struct UMapMarkBase*> DeathBoxMiniMapMark; // Offset: 0x25c8 // Size: 0x10
	int32_t Index; // Offset: 0x25d8 // Size: 0x04
	int32_t UI_Relive_StartTime; // Offset: 0x25dc // Size: 0x04
	struct FTimerHandle LandedDetectionHandel; // Offset: 0x25e0 // Size: 0x08
	struct ABP_SI_RebornLine_C* RebornLine; // Offset: 0x25e8 // Size: 0x08
	struct TMap<int32_t, float> Level-Damage; // Offset: 0x25f0 // Size: 0x50

	// Functions

	// Object Name: Function BP_Character_BattleRoyale.BP_Character_BattleRoyale_C.GetWeaponLevelDamageBonus
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void GetWeaponLevelDamageBonus(float& Result); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function BP_Character_BattleRoyale.BP_Character_BattleRoyale_C.Death Cleanup UI
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void Death Cleanup UI(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_Character_BattleRoyale.BP_Character_BattleRoyale_C.TakeDamageResolve
	// Flags: [Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent]
	float TakeDamageResolve(float Damage, struct FSolarPointDamageEvent& DamageEvent, struct ASCMPlayerState* EventInstigator, struct AActor* DamageCauser); // Offset: 0x102f67d18 // Return & Params: Num(5) Size(0x124)

	// Object Name: Function BP_Character_BattleRoyale.BP_Character_BattleRoyale_C.OnShouldTakeDamage
	// Flags: [Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	bool OnShouldTakeDamage(float Damage, struct FSolarPointDamageEvent& DamageEvent, struct ASCMPlayerState* EventInstigator, struct AActor* DamageCauser); // Offset: 0x102f67d18 // Return & Params: Num(5) Size(0x121)

	// Object Name: Function BP_Character_BattleRoyale.BP_Character_BattleRoyale_C.SetReviveCameraFade
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetReviveCameraFade(float Time); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function BP_Character_BattleRoyale.BP_Character_BattleRoyale_C.ReceiveBeginPlay
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveBeginPlay(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_Character_BattleRoyale.BP_Character_BattleRoyale_C.Debug Set DayAndNightTime
	// Flags: [Net|NetServer|BlueprintCallable|BlueprintEvent]
	void Debug Set DayAndNightTime(float Time); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function BP_Character_BattleRoyale.BP_Character_BattleRoyale_C.SetMapID
	// Flags: [Net|NetMulticast|BlueprintCallable|BlueprintEvent]
	void SetMapID(int32_t MapID); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function BP_Character_BattleRoyale.BP_Character_BattleRoyale_C.Event_OnResBegin
	// Flags: [BlueprintCallable|BlueprintEvent]
	void Event_OnResBegin(int32_t Time, enum class E_ResurrectType Type, struct FVector Location, struct FS_ResurrectInfo options); // Offset: 0x102f67d18 // Return & Params: Num(4) Size(0x19)

	// Object Name: Function BP_Character_BattleRoyale.BP_Character_BattleRoyale_C.BeginPlayBlueprint
	// Flags: [Event|Protected|BlueprintEvent]
	void BeginPlayBlueprint(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_Character_BattleRoyale.BP_Character_BattleRoyale_C.OnCharacterEjectStateChanged
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnCharacterEjectStateChanged(enum class E_CharacterEjectState State); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function BP_Character_BattleRoyale.BP_Character_BattleRoyale_C.ExecuteUbergraph_BP_Character_BattleRoyale
	// Flags: [Final|UbergraphFunction|HasDefaults]
	void ExecuteUbergraph_BP_Character_BattleRoyale(int32_t EntryPoint); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function BP_Character_BattleRoyale.BP_Character_BattleRoyale_C.OnPlayerRevive__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void OnPlayerRevive__DelegateSignature(struct ASolarCharacter* TargetCharacter); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x8)
};

