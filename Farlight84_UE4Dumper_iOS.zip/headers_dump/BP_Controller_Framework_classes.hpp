#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_Controller_Framework.BP_Controller_Framework_C
// Size: 0xc68 // Inherited bytes: 0xc20
struct ABP_Controller_Framework_C : ASCMPlayerController {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0xc20 // Size: 0x08
	struct FPoseSnapshot Snapshot; // Offset: 0xc28 // Size: 0x38
	float TempMaxDist; // Offset: 0xc60 // Size: 0x04
	int32_t TempMaxIndex; // Offset: 0xc64 // Size: 0x04

	// Functions

	// Object Name: Function BP_Controller_Framework.BP_Controller_Framework_C.OnNotifyLockPlayer
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void OnNotifyLockPlayer(struct FString Name); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function BP_Controller_Framework.BP_Controller_Framework_C.RequestNotifyLockPlayer
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void RequestNotifyLockPlayer(struct FString Name); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function BP_Controller_Framework.BP_Controller_Framework_C.InpActEvt_GMT_K2Node_InputActionEvent_1
	// Flags: [BlueprintEvent]
	void InpActEvt_GMT_K2Node_InputActionEvent_1(struct FKey Key); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function BP_Controller_Framework.BP_Controller_Framework_C.InputReviveSelfReleased
	// Flags: [Event|Public|BlueprintEvent]
	void InputReviveSelfReleased(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_Controller_Framework.BP_Controller_Framework_C.AssembleCustomAntiCheatData
	// Flags: [Event|Public|BlueprintEvent]
	void AssembleCustomAntiCheatData(struct ASolarWeapon* ActiveWeapon, struct ASolarVehiclePawn* BoardedVehicle); // Offset: 0x102f67d18 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function BP_Controller_Framework.BP_Controller_Framework_C.CustomAntiCheatDataExport
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	void CustomAntiCheatDataExport(struct TArray<struct FString>& DataName, struct TArray<struct FString>& DataContent); // Offset: 0x102f67d18 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function BP_Controller_Framework.BP_Controller_Framework_C.ClientNotifyLockPlayer
	// Flags: [Net|NetClient|BlueprintCallable|BlueprintEvent]
	void ClientNotifyLockPlayer(struct FString Name); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function BP_Controller_Framework.BP_Controller_Framework_C.ExecuteUbergraph_BP_Controller_Framework
	// Flags: [Final|UbergraphFunction|HasDefaults]
	void ExecuteUbergraph_BP_Controller_Framework(int32_t EntryPoint); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x4)
};

