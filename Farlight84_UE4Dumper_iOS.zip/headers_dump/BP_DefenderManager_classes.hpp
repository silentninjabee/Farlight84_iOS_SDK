#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_DefenderManager.BP_DefenderManager_C
// Size: 0x2e9 // Inherited bytes: 0x2b8
struct ABP_DefenderManager_C : ADefenderManager {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x2b8 // Size: 0x08
	struct UUI_OpeningShow_C* DefenderUI; // Offset: 0x2c0 // Size: 0x08
	float ShowTime-Defender; // Offset: 0x2c8 // Size: 0x04
	float ShowTime-Self; // Offset: 0x2cc // Size: 0x04
	enum class E_State_DefenderManager UiState; // Offset: 0x2d0 // Size: 0x01
	char pad_0x2D1[0x3]; // Offset: 0x2d1 // Size: 0x03
	int32_t TerminatorReward; // Offset: 0x2d4 // Size: 0x04
	bool DataReady; // Offset: 0x2d8 // Size: 0x01
	char pad_0x2D9[0x7]; // Offset: 0x2d9 // Size: 0x07
	struct UUI_Common_Transition_Anim_C* Anim; // Offset: 0x2e0 // Size: 0x08
	bool bBattleStarted; // Offset: 0x2e8 // Size: 0x01

	// Functions

	// Object Name: Function BP_DefenderManager.BP_DefenderManager_C.OnRep_BattleStarted
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnRep_BattleStarted(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_DefenderManager.BP_DefenderManager_C.DataTraceDefender
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void DataTraceDefender(struct ASolarPlayerState* Target, struct FString& Name, struct FString& Data); // Offset: 0x102f67d18 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function BP_DefenderManager.BP_DefenderManager_C.GetExtraReward
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void GetExtraReward(int32_t& Reward); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function BP_DefenderManager.BP_DefenderManager_C.SetShowTime
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetShowTime(float ShowTime-Self, float ShowTime-Defender); // Offset: 0x102f67d18 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function BP_DefenderManager.BP_DefenderManager_C.GetTotalTime
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void GetTotalTime(float& TotalTime); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function BP_DefenderManager.BP_DefenderManager_C.GetUI
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void GetUI(struct UUI_OpeningShow_C*& Output_Get); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function BP_DefenderManager.BP_DefenderManager_C.OnRep_UIState
	// Flags: [HasDefaults|BlueprintCallable|BlueprintEvent]
	void OnRep_UIState(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_DefenderManager.BP_DefenderManager_C.ReceiveBeginPlay
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveBeginPlay(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_DefenderManager.BP_DefenderManager_C.[S]ShowDefenderUI
	// Flags: [BlueprintCallable|BlueprintEvent]
	void [S]ShowDefenderUI(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_DefenderManager.BP_DefenderManager_C.OnUIStateChanged
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnUIStateChanged(enum class E_State_DefenderManager UiState); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function BP_DefenderManager.BP_DefenderManager_C.OnDefenderDataReady
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnDefenderDataReady(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_DefenderManager.BP_DefenderManager_C.ShowDefenderUIForReplay
	// Flags: [Event|Public|BlueprintEvent]
	void ShowDefenderUIForReplay(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_DefenderManager.BP_DefenderManager_C.OnSideHeroPickEnd_Event_1
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnSideHeroPickEnd_Event_1(struct FString Side); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function BP_DefenderManager.BP_DefenderManager_C.CustomEvent_1
	// Flags: [BlueprintCallable|BlueprintEvent]
	void CustomEvent_1(enum class ESCMInGameState NewState); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function BP_DefenderManager.BP_DefenderManager_C.ExecuteUbergraph_BP_DefenderManager
	// Flags: [Final|UbergraphFunction|HasDefaults]
	void ExecuteUbergraph_BP_DefenderManager(int32_t EntryPoint); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x4)
};

