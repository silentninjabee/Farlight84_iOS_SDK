#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_DissolvedDeath.BP_DissolvedDeath_C
// Size: 0xd0 // Inherited bytes: 0xd0
struct UBP_DissolvedDeath_C : UMaterialVariableEffect {
};

