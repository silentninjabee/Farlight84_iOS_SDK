#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_Formula_BattleRoyale.BP_Formula_BattleRoyale_C
// Size: 0x308 // Inherited bytes: 0x25c
struct ABP_Formula_BattleRoyale_C : ABP_FormulaBase_C {
	// Fields
	int32_t WarmGameExp; // Offset: 0x25c // Size: 0x04
	struct TMap<struct ASolarPlayerState*, bool> WeaponExp; // Offset: 0x260 // Size: 0x50
	struct TSet<int32_t> WarmGameIdSet; // Offset: 0x2b0 // Size: 0x50
	struct ABP_DefenderManager_C* DefenderManager; // Offset: 0x300 // Size: 0x08

	// Functions

	// Object Name: Function BP_Formula_BattleRoyale.BP_Formula_BattleRoyale_C.GetSettlementRewards
	// Flags: [Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	struct TArray<struct FSettlementReward> GetSettlementRewards(struct ASolarPlayerState* InPS); // Offset: 0x102f67d18 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function BP_Formula_BattleRoyale.BP_Formula_BattleRoyale_C.IsSettlementBagItem
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	bool IsSettlementBagItem(struct ASolarPlayerState* InPS); // Offset: 0x102f67d18 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function BP_Formula_BattleRoyale.BP_Formula_BattleRoyale_C.GetDefenderManager
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void GetDefenderManager(struct ABP_DefenderManager_C*& Output_Get); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function BP_Formula_BattleRoyale.BP_Formula_BattleRoyale_C.MVPLifeTimeScore
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void MVPLifeTimeScore(float Life Time, float& LTMVPScore); // Offset: 0x102f67d18 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function BP_Formula_BattleRoyale.BP_Formula_BattleRoyale_C.GetStrategyGuideConditions
	// Flags: [Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void GetStrategyGuideConditions(struct ASolarPlayerState* InPS, struct TArray<int32_t>& OutResult); // Offset: 0x102f67d18 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function BP_Formula_BattleRoyale.BP_Formula_BattleRoyale_C.CalculateTeamRank
	// Flags: [Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	int32_t CalculateTeamRank(struct ASolarPlayerState* InPS); // Offset: 0x102f67d18 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function BP_Formula_BattleRoyale.BP_Formula_BattleRoyale_C.CalculatePlayerRank
	// Flags: [Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	int32_t CalculatePlayerRank(struct ASolarPlayerState* InPS); // Offset: 0x102f67d18 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function BP_Formula_BattleRoyale.BP_Formula_BattleRoyale_C.BattleStateDealFloat
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	float BattleStateDealFloat(float Input); // Offset: 0x102f67d18 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function BP_Formula_BattleRoyale.BP_Formula_BattleRoyale_C.BattleStateDealInt
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	int32_t BattleStateDealInt(int32_t Input); // Offset: 0x102f67d18 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function BP_Formula_BattleRoyale.BP_Formula_BattleRoyale_C.GetBattleState
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void GetBattleState(enum class E_BattleState_BattleRoyale& State); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function BP_Formula_BattleRoyale.BP_Formula_BattleRoyale_C.GetKDA
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	float GetKDA(struct ASolarPlayerState* InPS); // Offset: 0x102f67d18 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function BP_Formula_BattleRoyale.BP_Formula_BattleRoyale_C.GetExtraRewards
	// Flags: [Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	struct TArray<struct FSettlementParam_ExtraRewardInfo> GetExtraRewards(struct ASolarPlayerState* InPS); // Offset: 0x102f67d18 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function BP_Formula_BattleRoyale.BP_Formula_BattleRoyale_C.GetPlayerData
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void GetPlayerData(struct ASolarPlayerState* Player, int32_t& KillCount, int32_t& KillDown, int32_t& Assist, int32_t& SaveCount, float& Lifetime, float& CauseDamage, int32_t& Rank, int32_t& TeamRank, int32_t& DeathCount, bool& TeamAced, bool& IsMVP, bool& IsCustomRoomActive, enum class E_DefenderPlayerType& DefenderType); // Offset: 0x102f67d18 // Return & Params: Num(14) Size(0x30)

	// Object Name: Function BP_Formula_BattleRoyale.BP_Formula_BattleRoyale_C.CalculateMVPScore
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	float CalculateMVPScore(struct ASolarPlayerState* InPS); // Offset: 0x102f67d18 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function BP_Formula_BattleRoyale.BP_Formula_BattleRoyale_C.GetZomborg
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	int32_t GetZomborg(struct ASolarPlayerState* InPS); // Offset: 0x102f67d18 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function BP_Formula_BattleRoyale.BP_Formula_BattleRoyale_C.GetWeaponExp
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	int32_t GetWeaponExp(struct ASolarPlayerState* InPS, int32_t InWeaponID); // Offset: 0x102f67d18 // Return & Params: Num(3) Size(0x10)

	// Object Name: Function BP_Formula_BattleRoyale.BP_Formula_BattleRoyale_C.GetCharacterExp
	// Flags: [Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void GetCharacterExp(struct ASolarPlayerState* InPS, int32_t& OutGetExp, struct TArray<int32_t>& OutReason); // Offset: 0x102f67d18 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function BP_Formula_BattleRoyale.BP_Formula_BattleRoyale_C.GetAccountExp
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	int32_t GetAccountExp(struct ASolarPlayerState* InPS); // Offset: 0x102f67d18 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function BP_Formula_BattleRoyale.BP_Formula_BattleRoyale_C.GetShowPageIndexs
	// Flags: [Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void GetShowPageIndexs(struct ASolarPlayerState* InPS, struct FSettlePageParam& InParam, struct TArray<int32_t>& OutResult); // Offset: 0x102f67d18 // Return & Params: Num(3) Size(0x20)
};

