#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_GameState_BattleRoyale.BP_GameState_BattleRoyale_C
// Size: 0x5e8 // Inherited bytes: 0x591
struct ABP_GameState_BattleRoyale_C : ABP_GameState_Framework_C {
	// Fields
	char pad_0x591[0x7]; // Offset: 0x591 // Size: 0x07
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x598 // Size: 0x08
	struct UBPC_WarmGame_BattleRoyale_C* BPC_WarmGame_BattleRoyale; // Offset: 0x5a0 // Size: 0x08
	struct UBPC_CountDown_C* BPC_CountDown; // Offset: 0x5a8 // Size: 0x08
	int32_t MapID; // Offset: 0x5b0 // Size: 0x04
	int32_t AirLineID; // Offset: 0x5b4 // Size: 0x04
	enum class E_BattleState_BattleRoyale BattleState; // Offset: 0x5b8 // Size: 0x01
	char pad_0x5B9[0x7]; // Offset: 0x5b9 // Size: 0x07
	struct FMulticastInlineDelegate BroadcastBattleStateChange; // Offset: 0x5c0 // Size: 0x10
	struct FString WinSide; // Offset: 0x5d0 // Size: 0x10
	struct UUI_HUD_Notice_VICTORY_C* VICTORYUI; // Offset: 0x5e0 // Size: 0x08

	// Functions

	// Object Name: Function BP_GameState_BattleRoyale.BP_GameState_BattleRoyale_C.ShowVictoryUI
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void ShowVictoryUI(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_GameState_BattleRoyale.BP_GameState_BattleRoyale_C.OnRep_WinSide
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnRep_WinSide(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_GameState_BattleRoyale.BP_GameState_BattleRoyale_C.OnRep_BattleState
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnRep_BattleState(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_GameState_BattleRoyale.BP_GameState_BattleRoyale_C.OnRep_MapID
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnRep_MapID(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_GameState_BattleRoyale.BP_GameState_BattleRoyale_C.BattleEnd
	// Flags: [BlueprintCallable|BlueprintEvent]
	void BattleEnd(struct FString WinSide); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function BP_GameState_BattleRoyale.BP_GameState_BattleRoyale_C.StartCountDown
	// Flags: [BlueprintCallable|BlueprintEvent]
	void StartCountDown(int32_t Time); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function BP_GameState_BattleRoyale.BP_GameState_BattleRoyale_C.ReceiveBeginPlay
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveBeginPlay(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_GameState_BattleRoyale.BP_GameState_BattleRoyale_C.OnBattleStateChange
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnBattleStateChange(enum class E_BattleState_BattleRoyale ChangeType); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function BP_GameState_BattleRoyale.BP_GameState_BattleRoyale_C.OnConfigInit
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnConfigInit(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_GameState_BattleRoyale.BP_GameState_BattleRoyale_C.ExecuteUbergraph_BP_GameState_BattleRoyale
	// Flags: [Final|UbergraphFunction|HasDefaults]
	void ExecuteUbergraph_BP_GameState_BattleRoyale(int32_t EntryPoint); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function BP_GameState_BattleRoyale.BP_GameState_BattleRoyale_C.BroadcastBattleStateChange__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void BroadcastBattleStateChange__DelegateSignature(enum class E_BattleState_BattleRoyale Now State); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x1)
};

