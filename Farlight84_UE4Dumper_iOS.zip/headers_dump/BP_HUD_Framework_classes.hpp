#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_HUD_Framework.BP_HUD_Framework_C
// Size: 0x3a0 // Inherited bytes: 0x380
struct ABP_HUD_Framework_C : ABattleHUDForTechDesign {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x380 // Size: 0x08
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x388 // Size: 0x08
	struct FMulticastInlineDelegate OnWindowVisibiltyChanged; // Offset: 0x390 // Size: 0x10

	// Functions

	// Object Name: Function BP_HUD_Framework.BP_HUD_Framework_C.BP_SCustomHUDBase_AutoGenFunc
	// Flags: [Private|HasOutParms|BlueprintCallable|BlueprintEvent]
	void BP_SCustomHUDBase_AutoGenFunc(struct UObject* Publisher, struct UObject* Payload, struct TArray<struct FString>& MetaData); // Offset: 0x102f67d18 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function BP_HUD_Framework.BP_HUD_Framework_C.ReceiveBeginPlay
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveBeginPlay(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_HUD_Framework.BP_HUD_Framework_C.EventOnWindowVisibiltyChanged
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventOnWindowVisibiltyChanged(enum class E_BattleUIType UIType, enum class E_WidgetVisibility Visibility); // Offset: 0x102f67d18 // Return & Params: Num(2) Size(0x2)

	// Object Name: Function BP_HUD_Framework.BP_HUD_Framework_C.ExecuteUbergraph_BP_HUD_Framework
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_BP_HUD_Framework(int32_t EntryPoint); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function BP_HUD_Framework.BP_HUD_Framework_C.OnWindowVisibiltyChanged__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void OnWindowVisibiltyChanged__DelegateSignature(enum class E_BattleUIType UIType, enum class E_WidgetVisibility Visibility); // Offset: 0x102f67d18 // Return & Params: Num(2) Size(0x2)
};

