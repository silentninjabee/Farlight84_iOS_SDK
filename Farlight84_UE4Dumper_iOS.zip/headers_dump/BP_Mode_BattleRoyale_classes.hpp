#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_Mode_BattleRoyale.BP_Mode_BattleRoyale_C
// Size: 0x5a8 // Inherited bytes: 0x580
struct ABP_Mode_BattleRoyale_C : ABP_Mode_Framework_C {
	// Fields
	struct UBPC_AiManagerBattleRoyale_C* BPC_AiManagerBattleRoyale; // Offset: 0x580 // Size: 0x08
	struct UNgaiGameModeComponent* NgaiGameMode; // Offset: 0x588 // Size: 0x08
	struct UBattleRoyaleGameModeAIComp_Custom_C* BattleRoyaleGameModeAIComp_Custom; // Offset: 0x590 // Size: 0x08
	struct UBPC_AirlineCruise_C* BPC_AirlineCruise; // Offset: 0x598 // Size: 0x08
	struct UBP_MapInfoComponent_C* BP_MapInfoComponent; // Offset: 0x5a0 // Size: 0x08

	// Functions

	// Object Name: Function BP_Mode_BattleRoyale.BP_Mode_BattleRoyale_C.GetAirlineCruiseComponent
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	struct UAirlineCruiseComponent* GetAirlineCruiseComponent(); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x8)
};

