#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_Mode_Framework.BP_Mode_Framework_C
// Size: 0x580 // Inherited bytes: 0x578
struct ABP_Mode_Framework_C : ASCustomGameMode {
	// Fields
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x578 // Size: 0x08
};

