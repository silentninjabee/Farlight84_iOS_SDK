#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_PBagsOffgas_Common.BP_PBagsOffgas_Common_C
// Size: 0x298 // Inherited bytes: 0x280
struct ABP_PBagsOffgas_Common_C : ASolarBackpackSFX {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x280 // Size: 0x08
	struct UParticleSystemComponent* FX_PowerBag_MainJet; // Offset: 0x288 // Size: 0x08
	struct USceneComponent* VFX; // Offset: 0x290 // Size: 0x08

	// Functions

	// Object Name: Function BP_PBagsOffgas_Common.BP_PBagsOffgas_Common_C.BackpackSFXBegin
	// Flags: [Event|Public|BlueprintEvent]
	void BackpackSFXBegin(enum class EFXJetType InJetType, bool GroundDetected); // Offset: 0x102f67d18 // Return & Params: Num(2) Size(0x2)

	// Object Name: Function BP_PBagsOffgas_Common.BP_PBagsOffgas_Common_C.BackpackSFXEnd
	// Flags: [Event|Public|BlueprintEvent]
	void BackpackSFXEnd(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_PBagsOffgas_Common.BP_PBagsOffgas_Common_C.OnBackpackTrailAssembling
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	void OnBackpackTrailAssembling(struct FBackpackTrailAssemblingParams& Params, enum class EBackpackPropellingMode PropellingMode); // Offset: 0x102f67d18 // Return & Params: Num(2) Size(0x59)

	// Object Name: Function BP_PBagsOffgas_Common.BP_PBagsOffgas_Common_C.ExecuteUbergraph_BP_PBagsOffgas_Common
	// Flags: [Final|UbergraphFunction|HasDefaults]
	void ExecuteUbergraph_BP_PBagsOffgas_Common(int32_t EntryPoint); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x4)
};

