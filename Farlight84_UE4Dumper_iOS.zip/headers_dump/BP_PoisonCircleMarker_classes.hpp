#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_PoisonCircleMarker.BP_PoisonCircleMarker_C
// Size: 0x2a8 // Inherited bytes: 0x298
struct ABP_PoisonCircleMarker_C : ASolarMapElementBase {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x298 // Size: 0x08
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x2a0 // Size: 0x08

	// Functions

	// Object Name: Function BP_PoisonCircleMarker.BP_PoisonCircleMarker_C.ReceiveBeginPlay
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveBeginPlay(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_PoisonCircleMarker.BP_PoisonCircleMarker_C.ExecuteUbergraph_BP_PoisonCircleMarker
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_BP_PoisonCircleMarker(int32_t EntryPoint); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x4)
};

