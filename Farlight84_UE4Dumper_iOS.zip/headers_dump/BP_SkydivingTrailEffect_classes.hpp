#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: DynamicClass BP_SkydivingTrailEffect.BP_SkydivingTrailEffect_C
// Size: 0x2f0 // Inherited bytes: 0x230
struct ABP_SkydivingTrailEffect_C : ASkydiveTrailEffect {
	// Fields
	struct USplineComponent* Spline; // Offset: 0x230 // Size: 0x08
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x238 // Size: 0x08
	float ParticleAlphaFadeOut_Alpha_56079AFA4AF8F5EF2064FC9C87D0666D; // Offset: 0x240 // Size: 0x04
	enum class ETimelineDirection ParticleAlphaFadeOut__Direction_56079AFA4AF8F5EF2064FC9C87D0666D; // Offset: 0x244 // Size: 0x01
	char pad_0x245[0x3]; // Offset: 0x245 // Size: 0x03
	struct UTimelineComponent* ParticleAlphaFadeOut; // Offset: 0x248 // Size: 0x08
	struct TArray<float> SplinePointsTimeArray; // Offset: 0x250 // Size: 0x10
	float VelocityToTangentScale; // Offset: 0x260 // Size: 0x04
	float TrackDelay; // Offset: 0x264 // Size: 0x04
	struct UParticleSystem* TrailParticleAsset; // Offset: 0x268 // Size: 0x08
	struct UParticleSystem* DefenderTrailParticleAsset; // Offset: 0x270 // Size: 0x08
	struct UParticleSystemComponent* ParticleComponent; // Offset: 0x278 // Size: 0x08
	float ParticleDestroyDelay; // Offset: 0x280 // Size: 0x04
	int32_t SplinePointCountCheck; // Offset: 0x284 // Size: 0x04
	float CurrentTime; // Offset: 0x288 // Size: 0x04
	bool IsDefender; // Offset: 0x28c // Size: 0x01
	bool IsSameTeamWithLocalPlayer; // Offset: 0x28d // Size: 0x01
	char pad_0x28E[0x2]; // Offset: 0x28e // Size: 0x02
	struct FLinearColor EnemyTrailColor; // Offset: 0x290 // Size: 0x10
	struct FLinearColor TeammateTrailColor; // Offset: 0x2a0 // Size: 0x10
	float CallFunc_Array_Get_Item; // Offset: 0x2b0 // Size: 0x04
	struct FVector CallFunc_BreakTransform_Location; // Offset: 0x2b4 // Size: 0x0c
	struct FRotator CallFunc_BreakTransform_Rotation; // Offset: 0x2c0 // Size: 0x0c
	struct FVector CallFunc_BreakTransform_Scale; // Offset: 0x2cc // Size: 0x0c
	float K2Node_Event_CurrentTime; // Offset: 0x2d8 // Size: 0x04
	char pad_0x2DC[0x4]; // Offset: 0x2dc // Size: 0x04
	struct UParticleSystemComponent* K2Node_CustomEvent_Component; // Offset: 0x2e0 // Size: 0x08
	float CallFunc_Array_Get_Item_2; // Offset: 0x2e8 // Size: 0x04
	float CallFunc_Array_Get_Item_3; // Offset: 0x2ec // Size: 0x04

	// Functions

	// Object Name: Function BP_SkydivingTrailEffect.BP_SkydivingTrailEffect_C.UserConstructionScript
	// Flags: [Native|Event|Public|BlueprintCallable]
	void UserConstructionScript(); // Offset: 0x101960ccc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_SkydivingTrailEffect.BP_SkydivingTrailEffect_C.UpdateSplineDuration
	// Flags: [Native|Public|BlueprintCallable]
	void UpdateSplineDuration(); // Offset: 0x1019609a0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_SkydivingTrailEffect.BP_SkydivingTrailEffect_C.UpdateParticleTransform
	// Flags: [Native|Public|HasDefaults|BlueprintCallable]
	void UpdateParticleTransform(struct FVector bpp__WorldLocation__pf, struct FRotator bpp__WorldRotation__pf); // Offset: 0x1019609f4 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function BP_SkydivingTrailEffect.BP_SkydivingTrailEffect_C.TryRemoveSplinePoint
	// Flags: [Native|Public|BlueprintCallable]
	void TryRemoveSplinePoint(); // Offset: 0x1019609bc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_SkydivingTrailEffect.BP_SkydivingTrailEffect_C.ReceiveBeginPlay
	// Flags: [Native|Event|Public]
	void ReceiveBeginPlay(); // Offset: 0x101960d20 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_SkydivingTrailEffect.BP_SkydivingTrailEffect_C.ParticleAlphaFadeOut__UpdateFunc
	// Flags: [Native|Public]
	void ParticleAlphaFadeOut__UpdateFunc(); // Offset: 0x101960d04 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_SkydivingTrailEffect.BP_SkydivingTrailEffect_C.ParticleAlphaFadeOut__FinishedFunc
	// Flags: [Native|Public]
	void ParticleAlphaFadeOut__FinishedFunc(); // Offset: 0x101960ce8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_SkydivingTrailEffect.BP_SkydivingTrailEffect_C.MoveSpline
	// Flags: [Native|Public|HasDefaults|BlueprintCallable]
	void MoveSpline(struct FVector bpp__WorldDeltaLocation__pf); // Offset: 0x101960ab8 // Return & Params: Num(1) Size(0xc)

	// Object Name: Function BP_SkydivingTrailEffect.BP_SkydivingTrailEffect_C.MoveActor
	// Flags: [Native|Public|HasDefaults|BlueprintCallable]
	void MoveActor(struct FVector bpp__WorldLocationDelta__pf); // Offset: 0x101960b3c // Return & Params: Num(1) Size(0xc)

	// Object Name: Function BP_SkydivingTrailEffect.BP_SkydivingTrailEffect_C.InitEffectAppearance
	// Flags: [Native|Event|Public|BlueprintCallable]
	void InitEffectAppearance(bool bpp__IsDefender__pf, bool bpp__IsSameTeamWithLocalPlayer__pf); // Offset: 0x1019608bc // Return & Params: Num(2) Size(0x2)

	// Object Name: Function BP_SkydivingTrailEffect.BP_SkydivingTrailEffect_C.FadeOutAndDestroyParticle
	// Flags: [Native|Public|BlueprintCallable]
	void FadeOutAndDestroyParticle(struct UParticleSystemComponent* bpp__Component__pf); // Offset: 0x101960d3c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function BP_SkydivingTrailEffect.BP_SkydivingTrailEffect_C.ClearData
	// Flags: [Native|Public|BlueprintCallable]
	void ClearData(); // Offset: 0x1019609d8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_SkydivingTrailEffect.BP_SkydivingTrailEffect_C.AddTrailPointImpl
	// Flags: [Native|Public|HasDefaults|BlueprintCallable]
	void AddTrailPointImpl(struct FVector bpp__Location__pf, struct FRotator bpp__Rotation__pf, struct FVector bpp__Velocity__pf); // Offset: 0x101960bc0 // Return & Params: Num(3) Size(0x24)
};

