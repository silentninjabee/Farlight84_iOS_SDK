#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_SliencePosition.BP_SliencePosition_C
// Size: 0x288 // Inherited bytes: 0x280
struct ABP_SliencePosition_C : ASCMMapElementBase {
	// Fields
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x280 // Size: 0x08
};

