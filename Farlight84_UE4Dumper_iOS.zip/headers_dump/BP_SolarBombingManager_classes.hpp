#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_SolarBombingManager.BP_SolarBombingManager_C
// Size: 0x268 // Inherited bytes: 0x260
struct ABP_SolarBombingManager_C : ASolarBombingZoneManager {
	// Fields
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x260 // Size: 0x08

	// Functions

	// Object Name: Function BP_SolarBombingManager.BP_SolarBombingManager_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	struct FString GetModuleName(); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x10)
};

