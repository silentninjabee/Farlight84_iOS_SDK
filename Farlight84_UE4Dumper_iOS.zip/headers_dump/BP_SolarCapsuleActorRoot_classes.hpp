#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_SolarCapsuleActorRoot.BP_SolarCapsuleActorRoot_C
// Size: 0x400 // Inherited bytes: 0x400
struct ABP_SolarCapsuleActorRoot_C : ASolarCapsuleRoot {
};

