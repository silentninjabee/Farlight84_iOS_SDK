#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_SolarReplayPlayerController.BP_SolarReplayPlayerController_C
// Size: 0xd50 // Inherited bytes: 0xd48
struct ABP_SolarReplayPlayerController_C : ASolarReplayPlayerController {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0xd48 // Size: 0x08

	// Functions

	// Object Name: Function BP_SolarReplayPlayerController.BP_SolarReplayPlayerController_C.InpActEvt_Slash_K2Node_InputKeyEvent_1
	// Flags: [BlueprintEvent]
	void InpActEvt_Slash_K2Node_InputKeyEvent_1(struct FKey Key); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function BP_SolarReplayPlayerController.BP_SolarReplayPlayerController_C.ExecuteUbergraph_BP_SolarReplayPlayerController
	// Flags: [Final|UbergraphFunction|HasDefaults]
	void ExecuteUbergraph_BP_SolarReplayPlayerController(int32_t EntryPoint); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x4)
};

