#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_SolarVehicleSpawner.BP_SolarVehicleSpawner_C
// Size: 0x460 // Inherited bytes: 0x430
struct ABP_SolarVehicleSpawner_C : ASolarVehicleSpawner {
	// Fields
	struct UBoxComponent* Box; // Offset: 0x430 // Size: 0x08
	struct UStaticMeshComponent* Cube1; // Offset: 0x438 // Size: 0x08
	struct UStaticMeshComponent* Cube; // Offset: 0x440 // Size: 0x08
	struct UBillboardComponent* Billboard; // Offset: 0x448 // Size: 0x08
	struct USceneComponent* SceneRoot; // Offset: 0x450 // Size: 0x08
	struct ABP_SummonVehicle_SpawnEffect_C* BPVehicleSpawnEffect; // Offset: 0x458 // Size: 0x08
};

