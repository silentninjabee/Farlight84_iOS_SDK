#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_SolarWaterActor.BP_SolarWaterActor_C
// Size: 0x2d8 // Inherited bytes: 0x238
struct ABP_SolarWaterActor_C : ASolarWaterActorNew {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x238 // Size: 0x08
	struct TSoftObjectPtr<UMaterialInterface> HightLevelWater; // Offset: 0x240 // Size: 0x28
	struct TSoftObjectPtr<UMaterialInterface> MediamLevelWater; // Offset: 0x268 // Size: 0x28
	struct TSoftObjectPtr<UMaterialInterface> LowLevelWater; // Offset: 0x290 // Size: 0x28
	bool RefreshMaterial; // Offset: 0x2b8 // Size: 0x01
	char pad_0x2B9[0x7]; // Offset: 0x2b9 // Size: 0x07
	struct FTimerHandle NewVar_2; // Offset: 0x2c0 // Size: 0x08
	float StartDistance; // Offset: 0x2c8 // Size: 0x04
	float FogDensity; // Offset: 0x2cc // Size: 0x04
	float fogHeight Falloff; // Offset: 0x2d0 // Size: 0x04
	float FogMaxOpacity; // Offset: 0x2d4 // Size: 0x04

	// Functions

	// Object Name: Function BP_SolarWaterActor.BP_SolarWaterActor_C.QualitySwitch
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void QualitySwitch(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_SolarWaterActor.BP_SolarWaterActor_C.UserConstructionScript
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void UserConstructionScript(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_SolarWaterActor.BP_SolarWaterActor_C.fog
	// Flags: [BlueprintCallable|BlueprintEvent]
	void fog(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_SolarWaterActor.BP_SolarWaterActor_C.check fog distance
	// Flags: [BlueprintCallable|BlueprintEvent]
	void check fog distance(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_SolarWaterActor.BP_SolarWaterActor_C.ReceiveBeginPlay
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveBeginPlay(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_SolarWaterActor.BP_SolarWaterActor_C.ExecuteUbergraph_BP_SolarWaterActor
	// Flags: [Final|UbergraphFunction|HasDefaults]
	void ExecuteUbergraph_BP_SolarWaterActor(int32_t EntryPoint); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x4)
};

