#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_Summon_Placeholder.BP_Summon_Placeholder_C
// Size: 0x24c // Inherited bytes: 0x228
struct ABP_Summon_Placeholder_C : ASolarSummonPlaceholder {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x228 // Size: 0x08
	struct UBoxComponent* Box; // Offset: 0x230 // Size: 0x08
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x238 // Size: 0x08
	struct FVector CollisionSize; // Offset: 0x240 // Size: 0x0c

	// Functions

	// Object Name: Function BP_Summon_Placeholder.BP_Summon_Placeholder_C.ReceiveBeginPlay
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveBeginPlay(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_Summon_Placeholder.BP_Summon_Placeholder_C.SetCollisionSize
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	void SetCollisionSize(struct FVector& InSize); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0xc)

	// Object Name: Function BP_Summon_Placeholder.BP_Summon_Placeholder_C.ExecuteUbergraph_BP_Summon_Placeholder
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_BP_Summon_Placeholder(int32_t EntryPoint); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x4)
};

