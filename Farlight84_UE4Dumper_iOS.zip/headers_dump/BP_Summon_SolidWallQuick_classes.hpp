#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_Summon_SolidWallQuick.BP_Summon_SolidWallQuick_C
// Size: 0x3c // Inherited bytes: 0x38
struct UBP_Summon_SolidWallQuick_C : USolarQuickSummonProxy {
	// Fields
	float CheckDistance; // Offset: 0x38 // Size: 0x04

	// Functions

	// Object Name: Function BP_Summon_SolidWallQuick.BP_Summon_SolidWallQuick_C.IsPlaceable
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	bool IsPlaceable(struct AActor* Summoner); // Offset: 0x102f67d18 // Return & Params: Num(2) Size(0x9)
};

