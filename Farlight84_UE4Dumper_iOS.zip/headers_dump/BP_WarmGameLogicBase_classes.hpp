#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_WarmGameLogicBase.BP_WarmGameLogicBase_C
// Size: 0x238 // Inherited bytes: 0x228
struct ABP_WarmGameLogicBase_C : AActor {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x228 // Size: 0x08
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x230 // Size: 0x08

	// Functions

	// Object Name: Function BP_WarmGameLogicBase.BP_WarmGameLogicBase_C.Event_ExecLogic
	// Flags: [BlueprintCallable|BlueprintEvent]
	void Event_ExecLogic(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function BP_WarmGameLogicBase.BP_WarmGameLogicBase_C.ExecuteUbergraph_BP_WarmGameLogicBase
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_BP_WarmGameLogicBase(int32_t EntryPoint); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x4)
};

