#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_WarmGameLogic_HarderWarmGame.BP_WarmGameLogic_HarderWarmGame_C
// Size: 0x350 // Inherited bytes: 0x350
struct ABP_WarmGameLogic_HarderWarmGame_C : ABP_WarmGameLogic_NoramlWarmGame_C {
};

