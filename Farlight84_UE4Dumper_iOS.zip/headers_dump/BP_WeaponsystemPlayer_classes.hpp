#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_WeaponsystemPlayer.BP_WeaponsystemPlayer_C
// Size: 0x2f8 // Inherited bytes: 0x2f8
struct UBP_WeaponsystemPlayer_C : UWeaponSystemPlayer {
};

