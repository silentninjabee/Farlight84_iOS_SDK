#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BTDecorators_DoOnce.BTDecorators_DoOnce_C
// Size: 0xc0 // Inherited bytes: 0x98
struct UBTDecorators_DoOnce_C : UBTDecorator_BlueprintBase {
	// Fields
	struct FBlackboardKeySelector DoOnce; // Offset: 0x98 // Size: 0x28

	// Functions

	// Object Name: Function BTDecorators_DoOnce.BTDecorators_DoOnce_C.PerformConditionCheckAI
	// Flags: [Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent]
	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Offset: 0x102f67d18 // Return & Params: Num(3) Size(0x11)
};

