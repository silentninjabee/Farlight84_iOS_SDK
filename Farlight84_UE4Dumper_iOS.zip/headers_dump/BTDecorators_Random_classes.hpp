#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BTDecorators_Random.BTDecorators_Random_C
// Size: 0x9c // Inherited bytes: 0x98
struct UBTDecorators_Random_C : UBTDecorator_BlueprintBase {
	// Fields
	float NewVar_2; // Offset: 0x98 // Size: 0x04

	// Functions

	// Object Name: Function BTDecorators_Random.BTDecorators_Random_C.PerformConditionCheckAI
	// Flags: [Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent]
	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Offset: 0x102f67d18 // Return & Params: Num(3) Size(0x11)
};

