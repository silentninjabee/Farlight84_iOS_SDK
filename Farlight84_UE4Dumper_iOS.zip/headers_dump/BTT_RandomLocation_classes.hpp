#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BTT_RandomLocation.BTT_RandomLocation_C
// Size: 0x130 // Inherited bytes: 0xa8
struct UBTT_RandomLocation_C : UBTTask_BlueprintBase {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0xa8 // Size: 0x08
	struct FBlackboardKeySelector In; // Offset: 0xb0 // Size: 0x28
	float ; // Offset: 0xd8 // Size: 0x04
	char pad_0xDC[0x4]; // Offset: 0xdc // Size: 0x04
	struct FBlackboardKeySelector Out; // Offset: 0xe0 // Size: 0x28
	struct FBlackboardKeySelector NewVar_1; // Offset: 0x108 // Size: 0x28

	// Functions

	// Object Name: Function BTT_RandomLocation.BTT_RandomLocation_C.ReceiveExecuteAI
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Offset: 0x102f67d18 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function BTT_RandomLocation.BTT_RandomLocation_C.ExecuteUbergraph_BTT_RandomLocation
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_BTT_RandomLocation(int32_t EntryPoint); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x4)
};

