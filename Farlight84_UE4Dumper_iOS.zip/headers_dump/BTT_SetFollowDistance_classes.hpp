#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BTT_SetFollowDistance.BTT_SetFollowDistance_C
// Size: 0x110 // Inherited bytes: 0xa8
struct UBTT_SetFollowDistance_C : UBTTask_BlueprintBase {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0xa8 // Size: 0x08
	struct FBlackboardKeySelector Distance; // Offset: 0xb0 // Size: 0x28
	struct ASolarCharacter* SelfActor; // Offset: 0xd8 // Size: 0x08
	struct TArray<int32_t> Close; // Offset: 0xe0 // Size: 0x10
	struct TArray<int32_t> Middle; // Offset: 0xf0 // Size: 0x10
	struct TArray<int32_t> Far; // Offset: 0x100 // Size: 0x10

	// Functions

	// Object Name: Function BTT_SetFollowDistance.BTT_SetFollowDistance_C.ReceiveExecuteAI
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Offset: 0x102f67d18 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function BTT_SetFollowDistance.BTT_SetFollowDistance_C.ExecuteUbergraph_BTT_SetFollowDistance
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_BTT_SetFollowDistance(int32_t EntryPoint); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x4)
};

