#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass ChaGABP_Bolt.ChaGABP_Bolt_C
// Size: 0x460 // Inherited bytes: 0x460
struct UChaGABP_Bolt_C : UChaGA_Bolt {
};

