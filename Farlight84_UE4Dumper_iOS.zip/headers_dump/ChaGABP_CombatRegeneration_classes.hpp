#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass ChaGABP_CombatRegeneration.ChaGABP_CombatRegeneration_C
// Size: 0x490 // Inherited bytes: 0x490
struct UChaGABP_CombatRegeneration_C : UChaGA_CombatRegeneration {
};

