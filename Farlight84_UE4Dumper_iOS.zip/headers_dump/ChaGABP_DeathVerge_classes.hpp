#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass ChaGABP_DeathVerge.ChaGABP_DeathVerge_C
// Size: 0x488 // Inherited bytes: 0x488
struct UChaGABP_DeathVerge_C : UChaGA_DeathVerge {
};

