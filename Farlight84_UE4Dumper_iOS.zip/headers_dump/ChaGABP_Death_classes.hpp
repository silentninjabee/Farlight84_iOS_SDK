#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass ChaGABP_Death.ChaGABP_Death_C
// Size: 0x468 // Inherited bytes: 0x468
struct UChaGABP_Death_C : UChaGA_Death {
};

