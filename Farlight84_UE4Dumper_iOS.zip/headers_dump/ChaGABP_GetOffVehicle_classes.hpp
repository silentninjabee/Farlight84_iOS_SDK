#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass ChaGABP_GetOffVehicle.ChaGABP_GetOffVehicle_C
// Size: 0x458 // Inherited bytes: 0x458
struct UChaGABP_GetOffVehicle_C : UChaGA_GetOffVehicle {
};

