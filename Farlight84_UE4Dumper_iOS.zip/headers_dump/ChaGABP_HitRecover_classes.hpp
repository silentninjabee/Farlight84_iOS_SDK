#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass ChaGABP_HitRecover.ChaGABP_HitRecover_C
// Size: 0x4b0 // Inherited bytes: 0x4b0
struct UChaGABP_HitRecover_C : UChaGA_HitRecover {
};

