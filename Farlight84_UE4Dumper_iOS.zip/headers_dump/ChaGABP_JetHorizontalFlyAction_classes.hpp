#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass ChaGABP_JetHorizontalFlyAction.ChaGABP_JetHorizontalFlyAction_C
// Size: 0x468 // Inherited bytes: 0x468
struct UChaGABP_JetHorizontalFlyAction_C : UChaGA_JetFlyAction {
};

