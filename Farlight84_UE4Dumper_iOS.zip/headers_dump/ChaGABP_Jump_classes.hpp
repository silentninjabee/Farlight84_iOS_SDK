#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass ChaGABP_Jump.ChaGABP_Jump_C
// Size: 0x458 // Inherited bytes: 0x458
struct UChaGABP_Jump_C : UChaGA_Jump {
};

