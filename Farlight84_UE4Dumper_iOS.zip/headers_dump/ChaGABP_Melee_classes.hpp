#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass ChaGABP_Melee.ChaGABP_Melee_C
// Size: 0x488 // Inherited bytes: 0x488
struct UChaGABP_Melee_C : UChaGA_Melee {
};

