#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass ChaGABP_PickUp.ChaGABP_PickUp_C
// Size: 0x488 // Inherited bytes: 0x488
struct UChaGABP_PickUp_C : UChaGA_PickUp {
};

