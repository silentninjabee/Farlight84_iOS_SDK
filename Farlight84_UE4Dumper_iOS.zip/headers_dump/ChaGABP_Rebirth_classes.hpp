#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass ChaGABP_Rebirth.ChaGABP_Rebirth_C
// Size: 0x468 // Inherited bytes: 0x468
struct UChaGABP_Rebirth_C : UChaGA_Rebirth {
};

