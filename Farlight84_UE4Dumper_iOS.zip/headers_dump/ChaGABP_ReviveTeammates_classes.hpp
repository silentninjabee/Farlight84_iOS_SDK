#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass ChaGABP_ReviveTeammates.ChaGABP_ReviveTeammates_C
// Size: 0x468 // Inherited bytes: 0x460
struct UChaGABP_ReviveTeammates_C : UChaGA_ReviveTeammates {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x460 // Size: 0x08

	// Functions

	// Object Name: Function ChaGABP_ReviveTeammates.ChaGABP_ReviveTeammates_C.K2_OnEndAbility
	// Flags: [Event|Protected|BlueprintEvent]
	void K2_OnEndAbility(bool bWasCancelled); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function ChaGABP_ReviveTeammates.ChaGABP_ReviveTeammates_C.OnAbilityExec
	// Flags: [Event|Public|BlueprintEvent]
	void OnAbilityExec(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function ChaGABP_ReviveTeammates.ChaGABP_ReviveTeammates_C.ExecuteUbergraph_ChaGABP_ReviveTeammates
	// Flags: [Final|UbergraphFunction|HasDefaults]
	void ExecuteUbergraph_ChaGABP_ReviveTeammates(int32_t EntryPoint); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x4)
};

