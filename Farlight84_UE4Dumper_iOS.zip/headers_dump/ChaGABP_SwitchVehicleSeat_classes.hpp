#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass ChaGABP_SwitchVehicleSeat.ChaGABP_SwitchVehicleSeat_C
// Size: 0x458 // Inherited bytes: 0x458
struct UChaGABP_SwitchVehicleSeat_C : UChaGA_SwitchVehicleSeat {
};

