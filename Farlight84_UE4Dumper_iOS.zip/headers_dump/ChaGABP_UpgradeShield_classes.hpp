#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass ChaGABP_UpgradeShield.ChaGABP_UpgradeShield_C
// Size: 0x480 // Inherited bytes: 0x480
struct UChaGABP_UpgradeShield_C : UChaGA_UpgradeShield {
};

