#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass ChaGABP_VehicleFire.ChaGABP_VehicleFire_C
// Size: 0x468 // Inherited bytes: 0x468
struct UChaGABP_VehicleFire_C : UChaGA_VehicleFire {
};

