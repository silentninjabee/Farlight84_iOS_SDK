#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass ChaGEBP_AttributeCalculation.ChaGEBP_AttributeCalculation_C
// Size: 0x848 // Inherited bytes: 0x848
struct UChaGEBP_AttributeCalculation_C : UGameplayEffect {
};

