#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass ChaGEBP_ExtraVJetTimes.ChaGEBP_ExtraVJetTimes_C
// Size: 0x848 // Inherited bytes: 0x848
struct UChaGEBP_ExtraVJetTimes_C : UGameplayEffect {
};

