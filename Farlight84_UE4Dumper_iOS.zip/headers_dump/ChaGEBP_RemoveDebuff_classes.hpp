#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass ChaGEBP_RemoveDebuff.ChaGEBP_RemoveDebuff_C
// Size: 0x848 // Inherited bytes: 0x848
struct UChaGEBP_RemoveDebuff_C : UGameplayEffect {
};

