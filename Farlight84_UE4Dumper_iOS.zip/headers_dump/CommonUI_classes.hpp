#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class CommonUI.AnalogSlider
// Size: 0x5b8 // Inherited bytes: 0x598
struct UAnalogSlider : USlider {
	// Fields
	struct FMulticastInlineDelegate OnAnalogCapture; // Offset: 0x598 // Size: 0x10
	char pad_0x5A8[0x10]; // Offset: 0x5a8 // Size: 0x10
};

// Object Name: Class CommonUI.CommonActionHandlerInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UCommonActionHandlerInterface : UInterface {
};

// Object Name: Class CommonUI.CommonActionWidget
// Size: 0x380 // Inherited bytes: 0x138
struct UCommonActionWidget : UWidget {
	// Fields
	struct FMulticastInlineDelegate OnInputMethodChanged; // Offset: 0x138 // Size: 0x10
	struct FSlateBrush ProgressMaterialBrush; // Offset: 0x148 // Size: 0x98
	struct FName ProgressMaterialParam; // Offset: 0x1e0 // Size: 0x08
	struct FSlateBrush IconRimBrush; // Offset: 0x1e8 // Size: 0x98
	struct TArray<struct FDataTableRowHandle> InputActions; // Offset: 0x280 // Size: 0x10
	char pad_0x290[0x8]; // Offset: 0x290 // Size: 0x08
	struct UMaterialInstanceDynamic* ProgressDynamicMaterial; // Offset: 0x298 // Size: 0x08
	char pad_0x2A0[0xe0]; // Offset: 0x2a0 // Size: 0xe0

	// Functions

	// Object Name: Function CommonUI.CommonActionWidget.SetInputActions
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetInputActions(struct TArray<struct FDataTableRowHandle> NewInputActions); // Offset: 0x1014916a4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function CommonUI.CommonActionWidget.SetInputAction
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetInputAction(struct FDataTableRowHandle InputActionRow); // Offset: 0x101491790 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function CommonUI.CommonActionWidget.SetIconRimBrush
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetIconRimBrush(struct FSlateBrush InIconRimBrush); // Offset: 0x1014913b4 // Return & Params: Num(1) Size(0x98)

	// Object Name: DelegateFunction CommonUI.CommonActionWidget.OnInputMethodChanged__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnInputMethodChanged__DelegateSignature(bool bUsingGamepad); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function CommonUI.CommonActionWidget.IsHeldAction
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsHeldAction(); // Offset: 0x101491380 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function CommonUI.CommonActionWidget.GetIcon
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FSlateBrush GetIcon(); // Offset: 0x1014918b4 // Return & Params: Num(1) Size(0x98)

	// Object Name: Function CommonUI.CommonActionWidget.GetDisplayText
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FText GetDisplayText(); // Offset: 0x10149180c // Return & Params: Num(1) Size(0x18)
};

// Object Name: Class CommonUI.CommonUserWidget
// Size: 0x288 // Inherited bytes: 0x260
struct UCommonUserWidget : UUserWidget {
	// Fields
	bool bConsumePointerInput; // Offset: 0x260 // Size: 0x01
	char pad_0x261[0x27]; // Offset: 0x261 // Size: 0x27

	// Functions

	// Object Name: Function CommonUI.CommonUserWidget.SetConsumePointerInput
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetConsumePointerInput(bool bInConsumePointerInput); // Offset: 0x1014a63d8 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class CommonUI.CommonActivatableWidget
// Size: 0x320 // Inherited bytes: 0x288
struct UCommonActivatableWidget : UCommonUserWidget {
	// Fields
	bool bAutoActivate; // Offset: 0x288 // Size: 0x01
	bool bIsBackHandler; // Offset: 0x289 // Size: 0x01
	bool bSupportsActivationFocus; // Offset: 0x28a // Size: 0x01
	bool bIsModal; // Offset: 0x28b // Size: 0x01
	bool bAutoRestoreFocus; // Offset: 0x28c // Size: 0x01
	bool bSetVisibilityOnActivated; // Offset: 0x28d // Size: 0x01
	enum class ESlateVisibility ActivatedVisibility; // Offset: 0x28e // Size: 0x01
	bool bSetVisibilityOnDeactivated; // Offset: 0x28f // Size: 0x01
	enum class ESlateVisibility DeactivatedVisibility; // Offset: 0x290 // Size: 0x01
	char pad_0x291[0x7]; // Offset: 0x291 // Size: 0x07
	struct FMulticastInlineDelegate BP_OnWidgetActivated; // Offset: 0x298 // Size: 0x10
	struct FMulticastInlineDelegate BP_OnWidgetDeactivated; // Offset: 0x2a8 // Size: 0x10
	bool bIsActive; // Offset: 0x2b8 // Size: 0x01
	char pad_0x2B9[0x67]; // Offset: 0x2b9 // Size: 0x67

	// Functions

	// Object Name: Function CommonUI.CommonActivatableWidget.IsActivated
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsActivated(); // Offset: 0x101491f84 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function CommonUI.CommonActivatableWidget.DeactivateWidget
	// Flags: [Final|Native|Public|BlueprintCallable]
	void DeactivateWidget(); // Offset: 0x101491f5c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function CommonUI.CommonActivatableWidget.BP_OnHandleBackAction
	// Flags: [Event|Protected|BlueprintEvent]
	bool BP_OnHandleBackAction(); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function CommonUI.CommonActivatableWidget.BP_OnDeactivated
	// Flags: [Event|Protected|BlueprintEvent]
	void BP_OnDeactivated(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function CommonUI.CommonActivatableWidget.BP_OnActivated
	// Flags: [Event|Protected|BlueprintEvent]
	void BP_OnActivated(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function CommonUI.CommonActivatableWidget.BP_GetDesiredFocusTarget
	// Flags: [Event|Protected|BlueprintEvent|Const]
	struct UWidget* BP_GetDesiredFocusTarget(); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function CommonUI.CommonActivatableWidget.ActivateWidget
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ActivateWidget(); // Offset: 0x101491f70 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class CommonUI.CommonActivatableWidgetContainerBase
// Size: 0x238 // Inherited bytes: 0x138
struct UCommonActivatableWidgetContainerBase : UWidget {
	// Fields
	enum class ECommonSwitcherTransition TransitionType; // Offset: 0x138 // Size: 0x01
	enum class ETransitionCurve TransitionCurveType; // Offset: 0x139 // Size: 0x01
	char pad_0x13A[0x2]; // Offset: 0x13a // Size: 0x02
	float TransitionDuration; // Offset: 0x13c // Size: 0x04
	struct TArray<struct UCommonActivatableWidget*> WidgetList; // Offset: 0x140 // Size: 0x10
	struct UCommonActivatableWidget* DisplayedWidget; // Offset: 0x150 // Size: 0x08
	struct FUserWidgetPool GeneratedWidgetsPool; // Offset: 0x158 // Size: 0x80
	char pad_0x1D8[0x60]; // Offset: 0x1d8 // Size: 0x60

	// Functions

	// Object Name: Function CommonUI.CommonActivatableWidgetContainerBase.RemoveWidget
	// Flags: [Final|Native|Private|BlueprintCallable]
	void RemoveWidget(struct UCommonActivatableWidget* WidgetToRemove); // Offset: 0x101492738 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function CommonUI.CommonActivatableWidgetContainerBase.GetActiveWidget
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UCommonActivatableWidget* GetActiveWidget(); // Offset: 0x101492854 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function CommonUI.CommonActivatableWidgetContainerBase.ClearWidgets
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearWidgets(); // Offset: 0x101492840 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function CommonUI.CommonActivatableWidgetContainerBase.BP_AddWidget
	// Flags: [Final|Native|Private|BlueprintCallable]
	struct UCommonActivatableWidget* BP_AddWidget(struct UCommonActivatableWidget* ActivatableWidgetClass); // Offset: 0x1014927b4 // Return & Params: Num(2) Size(0x10)
};

// Object Name: Class CommonUI.CommonActivatableWidgetStack
// Size: 0x248 // Inherited bytes: 0x238
struct UCommonActivatableWidgetStack : UCommonActivatableWidgetContainerBase {
	// Fields
	struct UCommonActivatableWidget* RootContentWidgetClass; // Offset: 0x238 // Size: 0x08
	struct UCommonActivatableWidget* RootContentWidget; // Offset: 0x240 // Size: 0x08
};

// Object Name: Class CommonUI.CommonActivatableWidgetQueue
// Size: 0x238 // Inherited bytes: 0x238
struct UCommonActivatableWidgetQueue : UCommonActivatableWidgetContainerBase {
};

// Object Name: Class CommonUI.CommonAnimatedSwitcher
// Size: 0x1b8 // Inherited bytes: 0x160
struct UCommonAnimatedSwitcher : UWidgetSwitcher {
	// Fields
	char pad_0x160[0x18]; // Offset: 0x160 // Size: 0x18
	enum class ECommonSwitcherTransition TransitionType; // Offset: 0x178 // Size: 0x01
	enum class ETransitionCurve TransitionCurveType; // Offset: 0x179 // Size: 0x01
	char pad_0x17A[0x2]; // Offset: 0x17a // Size: 0x02
	float TransitionDuration; // Offset: 0x17c // Size: 0x04
	char pad_0x180[0x38]; // Offset: 0x180 // Size: 0x38

	// Functions

	// Object Name: Function CommonUI.CommonAnimatedSwitcher.SetDisableTransitionAnimation
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetDisableTransitionAnimation(bool bDisableAnimation); // Offset: 0x101493060 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function CommonUI.CommonAnimatedSwitcher.HasWidgets
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool HasWidgets(); // Offset: 0x1014930e4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function CommonUI.CommonAnimatedSwitcher.ActivatePreviousWidget
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ActivatePreviousWidget(bool bCanWrap); // Offset: 0x101493118 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function CommonUI.CommonAnimatedSwitcher.ActivateNextWidget
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ActivateNextWidget(bool bCanWrap); // Offset: 0x10149319c // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class CommonUI.CommonActivatableWidgetSwitcher
// Size: 0x1b8 // Inherited bytes: 0x1b8
struct UCommonActivatableWidgetSwitcher : UCommonAnimatedSwitcher {
};

// Object Name: Class CommonUI.CommonBorderStyle
// Size: 0xc0 // Inherited bytes: 0x28
struct UCommonBorderStyle : UObject {
	// Fields
	struct FSlateBrush Background; // Offset: 0x28 // Size: 0x98

	// Functions

	// Object Name: Function CommonUI.CommonBorderStyle.GetBackgroundBrush
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetBackgroundBrush(struct FSlateBrush& Brush); // Offset: 0x10149350c // Return & Params: Num(1) Size(0x98)
};

// Object Name: Class CommonUI.CommonBorder
// Size: 0x2c8 // Inherited bytes: 0x2a8
struct UCommonBorder : UBorder {
	// Fields
	struct UCommonBorderStyle* Style; // Offset: 0x2a8 // Size: 0x08
	bool bReducePaddingBySafezone; // Offset: 0x2b0 // Size: 0x01
	char pad_0x2B1[0x3]; // Offset: 0x2b1 // Size: 0x03
	struct FMargin MinimumPadding; // Offset: 0x2b4 // Size: 0x10
	char pad_0x2C4[0x4]; // Offset: 0x2c4 // Size: 0x04

	// Functions

	// Object Name: Function CommonUI.CommonBorder.SetStyle
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetStyle(struct UCommonBorderStyle* InStyle); // Offset: 0x101493a44 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class CommonUI.CommonBoundActionBar
// Size: 0x208 // Inherited bytes: 0x1f8
struct UCommonBoundActionBar : UDynamicEntryBoxBase {
	// Fields
	struct UCommonBoundActionButton* ActionButtonClass; // Offset: 0x1f8 // Size: 0x08
	bool bDisplayOwningPlayerActionsOnly; // Offset: 0x200 // Size: 0x01
	char pad_0x201[0x7]; // Offset: 0x201 // Size: 0x07

	// Functions

	// Object Name: Function CommonUI.CommonBoundActionBar.SetDisplayOwningPlayerActionsOnly
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetDisplayOwningPlayerActionsOnly(bool bShouldOnlyDisplayOwningPlayerActions); // Offset: 0x101493cf8 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class CommonUI.CommonButtonBase
// Size: 0xc60 // Inherited bytes: 0x288
struct UCommonButtonBase : UCommonUserWidget {
	// Fields
	int32_t MinWidth; // Offset: 0x288 // Size: 0x04
	int32_t MinHeight; // Offset: 0x28c // Size: 0x04
	struct UCommonButtonStyle* Style; // Offset: 0x290 // Size: 0x08
	bool bHideInputAction; // Offset: 0x298 // Size: 0x01
	char pad_0x299[0x7]; // Offset: 0x299 // Size: 0x07
	struct FSlateSound PressedSlateSoundOverride; // Offset: 0x2a0 // Size: 0x18
	struct FSlateSound HoveredSlateSoundOverride; // Offset: 0x2b8 // Size: 0x18
	char bApplyAlphaOnDisable : 1; // Offset: 0x2d0 // Size: 0x01
	char bSelectable : 1; // Offset: 0x2d0 // Size: 0x01
	char bShouldSelectUponReceivingFocus : 1; // Offset: 0x2d0 // Size: 0x01
	char bInteractableWhenSelected : 1; // Offset: 0x2d0 // Size: 0x01
	char bToggleable : 1; // Offset: 0x2d0 // Size: 0x01
	char bDisplayInputActionWhenNotInteractable : 1; // Offset: 0x2d0 // Size: 0x01
	char bHideInputActionWithKeyboard : 1; // Offset: 0x2d0 // Size: 0x01
	char bShouldUseFallbackDefaultInputAction : 1; // Offset: 0x2d0 // Size: 0x01
	char pad_0x2D1[0x1]; // Offset: 0x2d1 // Size: 0x01
	enum class EButtonClickMethod ClickMethod; // Offset: 0x2d2 // Size: 0x01
	enum class EButtonTouchMethod TouchMethod; // Offset: 0x2d3 // Size: 0x01
	enum class EButtonPressMethod PressMethod; // Offset: 0x2d4 // Size: 0x01
	char pad_0x2D5[0x3]; // Offset: 0x2d5 // Size: 0x03
	int32_t InputPriority; // Offset: 0x2d8 // Size: 0x04
	char pad_0x2DC[0x4]; // Offset: 0x2dc // Size: 0x04
	struct FDataTableRowHandle TriggeringInputAction; // Offset: 0x2e0 // Size: 0x10
	char pad_0x2F0[0x10]; // Offset: 0x2f0 // Size: 0x10
	struct FMulticastInlineDelegate OnSelectedChangedBase; // Offset: 0x300 // Size: 0x10
	struct FMulticastInlineDelegate OnButtonBaseClicked; // Offset: 0x310 // Size: 0x10
	struct FMulticastInlineDelegate OnButtonBaseDoubleClicked; // Offset: 0x320 // Size: 0x10
	struct FMulticastInlineDelegate OnButtonBaseHovered; // Offset: 0x330 // Size: 0x10
	struct FMulticastInlineDelegate OnButtonBaseUnhovered; // Offset: 0x340 // Size: 0x10
	char pad_0x350[0x4]; // Offset: 0x350 // Size: 0x04
	bool bIsPersistentBinding; // Offset: 0x354 // Size: 0x01
	enum class ECommonInputMode InputModeOverride; // Offset: 0x355 // Size: 0x01
	char pad_0x356[0x32]; // Offset: 0x356 // Size: 0x32
	struct UMaterialInstanceDynamic* SingleMaterialStyleMID; // Offset: 0x388 // Size: 0x08
	struct FButtonStyle NormalStyle; // Offset: 0x390 // Size: 0x2b8
	struct FButtonStyle SelectedStyle; // Offset: 0x648 // Size: 0x2b8
	struct FButtonStyle DisabledStyle; // Offset: 0x900 // Size: 0x2b8
	char bStopDoubleClickPropagation : 1; // Offset: 0xbb8 // Size: 0x01
	char pad_0xBB8_1 : 7; // Offset: 0xbb8 // Size: 0x01
	char pad_0xBB9[0x9f]; // Offset: 0xbb9 // Size: 0x9f
	struct UCommonActionWidget* InputActionWidget; // Offset: 0xc58 // Size: 0x08

	// Functions

	// Object Name: Function CommonUI.CommonButtonBase.StopDoubleClickPropagation
	// Flags: [Final|Native|Protected|BlueprintCallable]
	void StopDoubleClickPropagation(); // Offset: 0x1014961d0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function CommonUI.CommonButtonBase.SetTriggeringInputAction
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetTriggeringInputAction(struct FDataTableRowHandle& InputActionRow); // Offset: 0x1014967d8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function CommonUI.CommonButtonBase.SetTriggeredInputAction
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetTriggeredInputAction(struct FDataTableRowHandle& InputActionRow); // Offset: 0x101496864 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function CommonUI.CommonButtonBase.SetTouchMethod
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetTouchMethod(enum class EButtonTouchMethod InTouchMethod); // Offset: 0x101497044 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function CommonUI.CommonButtonBase.SetStyle
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetStyle(struct UCommonButtonStyle* InStyle); // Offset: 0x101496b60 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function CommonUI.CommonButtonBase.SetShouldUseFallbackDefaultInputAction
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetShouldUseFallbackDefaultInputAction(bool bInShouldUseFallbackDefaultInputAction); // Offset: 0x101496db8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function CommonUI.CommonButtonBase.SetShouldSelectUponReceivingFocus
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetShouldSelectUponReceivingFocus(bool bInShouldSelectUponReceivingFocus); // Offset: 0x101496c10 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function CommonUI.CommonButtonBase.SetSelectedInternal
	// Flags: [Final|Native|Protected|BlueprintCallable]
	void SetSelectedInternal(bool bInSelected, bool bAllowSound, bool bBroadcast); // Offset: 0x1014960a4 // Return & Params: Num(3) Size(0x3)

	// Object Name: Function CommonUI.CommonButtonBase.SetPressMethod
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPressMethod(enum class EButtonPressMethod InPressMethod); // Offset: 0x101496fc8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function CommonUI.CommonButtonBase.SetPressedSoundOverride
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPressedSoundOverride(struct USoundBase* Sound); // Offset: 0x1014963d0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function CommonUI.CommonButtonBase.SetMinDimensions
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMinDimensions(int32_t InMinWidth, int32_t InMinHeight); // Offset: 0x1014968f0 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function CommonUI.CommonButtonBase.SetIsToggleable
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetIsToggleable(bool bInIsToggleable); // Offset: 0x101496e3c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function CommonUI.CommonButtonBase.SetIsSelected
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetIsSelected(bool InSelected, bool bGiveClickFeedback); // Offset: 0x101496cdc // Return & Params: Num(2) Size(0x2)

	// Object Name: Function CommonUI.CommonButtonBase.SetIsSelectable
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetIsSelectable(bool bInIsSelectable); // Offset: 0x101496f44 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function CommonUI.CommonButtonBase.SetIsInteractionEnabled
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetIsInteractionEnabled(bool bInIsInteractionEnabled); // Offset: 0x1014971a4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function CommonUI.CommonButtonBase.SetIsInteractableWhenSelected
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetIsInteractableWhenSelected(bool bInInteractableWhenSelected); // Offset: 0x101496ec0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function CommonUI.CommonButtonBase.SetIsFocusable
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetIsFocusable(bool bInIsFocusable); // Offset: 0x1014966b8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function CommonUI.CommonButtonBase.SetInputActionProgressMaterial
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetInputActionProgressMaterial(struct FSlateBrush& InProgressMaterialBrush, struct FName& InProgressMaterialParam); // Offset: 0x10149644c // Return & Params: Num(2) Size(0xa0)

	// Object Name: Function CommonUI.CommonButtonBase.SetHoveredSoundOverride
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetHoveredSoundOverride(struct USoundBase* Sound); // Offset: 0x101496354 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function CommonUI.CommonButtonBase.SetClickMethod
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetClickMethod(enum class EButtonClickMethod InClickMethod); // Offset: 0x1014970c0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function CommonUI.CommonButtonBase.OnTriggeredInputActionChanged
	// Flags: [Event|Protected|HasOutParms|BlueprintEvent]
	void OnTriggeredInputActionChanged(struct FDataTableRowHandle& NewTriggeredAction); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function CommonUI.CommonButtonBase.OnInputMethodChanged
	// Flags: [Native|Protected]
	void OnInputMethodChanged(enum class ECommonInputType CurrentInputType); // Offset: 0x1014962d0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function CommonUI.CommonButtonBase.OnCurrentTextStyleChanged
	// Flags: [Event|Protected|BlueprintEvent]
	void OnCurrentTextStyleChanged(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function CommonUI.CommonButtonBase.OnActionProgress
	// Flags: [Event|Protected|BlueprintEvent]
	void OnActionProgress(float HeldPercent); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function CommonUI.CommonButtonBase.OnActionComplete
	// Flags: [Event|Protected|BlueprintEvent]
	void OnActionComplete(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function CommonUI.CommonButtonBase.NativeOnActionProgress
	// Flags: [Native|Protected]
	void NativeOnActionProgress(float HeldPercent); // Offset: 0x101496020 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function CommonUI.CommonButtonBase.NativeOnActionComplete
	// Flags: [Native|Protected]
	void NativeOnActionComplete(); // Offset: 0x101496004 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function CommonUI.CommonButtonBase.IsPressed
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsPressed(); // Offset: 0x10149713c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function CommonUI.CommonButtonBase.IsInteractionEnabled
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsInteractionEnabled(); // Offset: 0x101497170 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function CommonUI.CommonButtonBase.HandleTriggeringActionCommited
	// Flags: [Native|Protected|HasOutParms]
	void HandleTriggeringActionCommited(bool& bPassThrough); // Offset: 0x10149623c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function CommonUI.CommonButtonBase.HandleFocusReceived
	// Flags: [Native|Protected]
	void HandleFocusReceived(); // Offset: 0x10149620c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function CommonUI.CommonButtonBase.HandleButtonReleased
	// Flags: [Final|Native|Protected]
	void HandleButtonReleased(); // Offset: 0x1014961e4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function CommonUI.CommonButtonBase.HandleButtonPressed
	// Flags: [Final|Native|Protected]
	void HandleButtonPressed(); // Offset: 0x1014961f8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function CommonUI.CommonButtonBase.HandleButtonClicked
	// Flags: [Final|Native|Protected]
	void HandleButtonClicked(); // Offset: 0x101496228 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function CommonUI.CommonButtonBase.GetStyle
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UCommonButtonStyle* GetStyle(); // Offset: 0x101496b2c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function CommonUI.CommonButtonBase.GetSingleMaterialStyleMID
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UMaterialInstanceDynamic* GetSingleMaterialStyleMID(); // Offset: 0x101496650 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function CommonUI.CommonButtonBase.GetShouldSelectUponReceivingFocus
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool GetShouldSelectUponReceivingFocus(); // Offset: 0x101496bdc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function CommonUI.CommonButtonBase.GetSelected
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool GetSelected(); // Offset: 0x101496ca8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function CommonUI.CommonButtonBase.GetIsFocusable
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool GetIsFocusable(); // Offset: 0x101496684 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function CommonUI.CommonButtonBase.GetInputAction
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	bool GetInputAction(struct FDataTableRowHandle& InputActionRow); // Offset: 0x10149673c // Return & Params: Num(2) Size(0x11)

	// Object Name: Function CommonUI.CommonButtonBase.GetCurrentTextStyleClass
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UCommonTextStyle* GetCurrentTextStyleClass(); // Offset: 0x1014969ac // Return & Params: Num(1) Size(0x8)

	// Object Name: Function CommonUI.CommonButtonBase.GetCurrentTextStyle
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UCommonTextStyle* GetCurrentTextStyle(); // Offset: 0x1014969e0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function CommonUI.CommonButtonBase.GetCurrentCustomPadding
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetCurrentCustomPadding(struct FMargin& OutCustomPadding); // Offset: 0x101496a14 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function CommonUI.CommonButtonBase.GetCurrentButtonPadding
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetCurrentButtonPadding(struct FMargin& OutButtonPadding); // Offset: 0x101496aa0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function CommonUI.CommonButtonBase.DisableButtonWithReason
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void DisableButtonWithReason(struct FText& DisabledReason); // Offset: 0x101497228 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function CommonUI.CommonButtonBase.ClearSelection
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ClearSelection(); // Offset: 0x101496c94 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function CommonUI.CommonButtonBase.BP_OnUnhovered
	// Flags: [Event|Protected|BlueprintEvent]
	void BP_OnUnhovered(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function CommonUI.CommonButtonBase.BP_OnSelected
	// Flags: [Event|Protected|BlueprintEvent]
	void BP_OnSelected(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function CommonUI.CommonButtonBase.BP_OnHovered
	// Flags: [Event|Protected|BlueprintEvent]
	void BP_OnHovered(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function CommonUI.CommonButtonBase.BP_OnEnabled
	// Flags: [Event|Protected|BlueprintEvent]
	void BP_OnEnabled(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function CommonUI.CommonButtonBase.BP_OnDoubleClicked
	// Flags: [Event|Protected|BlueprintEvent]
	void BP_OnDoubleClicked(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function CommonUI.CommonButtonBase.BP_OnDisabled
	// Flags: [Event|Protected|BlueprintEvent]
	void BP_OnDisabled(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function CommonUI.CommonButtonBase.BP_OnDeselected
	// Flags: [Event|Protected|BlueprintEvent]
	void BP_OnDeselected(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function CommonUI.CommonButtonBase.BP_OnClicked
	// Flags: [Event|Protected|BlueprintEvent]
	void BP_OnClicked(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class CommonUI.CommonBoundActionButton
// Size: 0xc70 // Inherited bytes: 0xc60
struct UCommonBoundActionButton : UCommonButtonBase {
	// Fields
	struct UCommonTextBlock* Text_ActionName; // Offset: 0xc60 // Size: 0x08
	char pad_0xC68[0x8]; // Offset: 0xc68 // Size: 0x08

	// Functions

	// Object Name: Function CommonUI.CommonBoundActionButton.OnUpdateInputAction
	// Flags: [Event|Protected|BlueprintEvent]
	void OnUpdateInputAction(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class CommonUI.CommonButtonStyle
// Size: 0x5f0 // Inherited bytes: 0x28
struct UCommonButtonStyle : UObject {
	// Fields
	bool bSingleMaterial; // Offset: 0x28 // Size: 0x01
	char pad_0x29[0x7]; // Offset: 0x29 // Size: 0x07
	struct FSlateBrush SingleMaterialBrush; // Offset: 0x30 // Size: 0x98
	struct FSlateBrush NormalBase; // Offset: 0xc8 // Size: 0x98
	struct FSlateBrush NormalHovered; // Offset: 0x160 // Size: 0x98
	struct FSlateBrush NormalPressed; // Offset: 0x1f8 // Size: 0x98
	struct FSlateBrush SelectedBase; // Offset: 0x290 // Size: 0x98
	struct FSlateBrush SelectedHovered; // Offset: 0x328 // Size: 0x98
	struct FSlateBrush SelectedPressed; // Offset: 0x3c0 // Size: 0x98
	struct FSlateBrush Disabled; // Offset: 0x458 // Size: 0x98
	struct FMargin ButtonPadding; // Offset: 0x4f0 // Size: 0x10
	struct FMargin CustomPadding; // Offset: 0x500 // Size: 0x10
	int32_t MinWidth; // Offset: 0x510 // Size: 0x04
	int32_t MinHeight; // Offset: 0x514 // Size: 0x04
	struct UCommonTextStyle* NormalTextStyle; // Offset: 0x518 // Size: 0x08
	struct UCommonTextStyle* NormalHoveredTextStyle; // Offset: 0x520 // Size: 0x08
	struct UCommonTextStyle* SelectedTextStyle; // Offset: 0x528 // Size: 0x08
	struct UCommonTextStyle* SelectedHoveredTextStyle; // Offset: 0x530 // Size: 0x08
	struct UCommonTextStyle* DisabledTextStyle; // Offset: 0x538 // Size: 0x08
	struct FSlateSound PressedSlateSound; // Offset: 0x540 // Size: 0x18
	struct FCommonButtonStyleOptionalSlateSound SelectedPressedSlateSound; // Offset: 0x558 // Size: 0x20
	struct FCommonButtonStyleOptionalSlateSound DisabledPressedSlateSound; // Offset: 0x578 // Size: 0x20
	struct FSlateSound HoveredSlateSound; // Offset: 0x598 // Size: 0x18
	struct FCommonButtonStyleOptionalSlateSound SelectedHoveredSlateSound; // Offset: 0x5b0 // Size: 0x20
	struct FCommonButtonStyleOptionalSlateSound DisabledHoveredSlateSound; // Offset: 0x5d0 // Size: 0x20

	// Functions

	// Object Name: Function CommonUI.CommonButtonStyle.GetSelectedTextStyle
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UCommonTextStyle* GetSelectedTextStyle(); // Offset: 0x1014946fc // Return & Params: Num(1) Size(0x8)

	// Object Name: Function CommonUI.CommonButtonStyle.GetSelectedPressedBrush
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetSelectedPressedBrush(struct FSlateBrush& Brush); // Offset: 0x101494a64 // Return & Params: Num(1) Size(0x98)

	// Object Name: Function CommonUI.CommonButtonStyle.GetSelectedHoveredTextStyle
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UCommonTextStyle* GetSelectedHoveredTextStyle(); // Offset: 0x1014946c8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function CommonUI.CommonButtonStyle.GetSelectedHoveredBrush
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetSelectedHoveredBrush(struct FSlateBrush& Brush); // Offset: 0x101494c18 // Return & Params: Num(1) Size(0x98)

	// Object Name: Function CommonUI.CommonButtonStyle.GetSelectedBaseBrush
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetSelectedBaseBrush(struct FSlateBrush& Brush); // Offset: 0x101494dcc // Return & Params: Num(1) Size(0x98)

	// Object Name: Function CommonUI.CommonButtonStyle.GetNormalTextStyle
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UCommonTextStyle* GetNormalTextStyle(); // Offset: 0x101494764 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function CommonUI.CommonButtonStyle.GetNormalPressedBrush
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetNormalPressedBrush(struct FSlateBrush& Brush); // Offset: 0x101494f80 // Return & Params: Num(1) Size(0x98)

	// Object Name: Function CommonUI.CommonButtonStyle.GetNormalHoveredTextStyle
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UCommonTextStyle* GetNormalHoveredTextStyle(); // Offset: 0x101494730 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function CommonUI.CommonButtonStyle.GetNormalHoveredBrush
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetNormalHoveredBrush(struct FSlateBrush& Brush); // Offset: 0x101495134 // Return & Params: Num(1) Size(0x98)

	// Object Name: Function CommonUI.CommonButtonStyle.GetNormalBaseBrush
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetNormalBaseBrush(struct FSlateBrush& Brush); // Offset: 0x1014952e8 // Return & Params: Num(1) Size(0x98)

	// Object Name: Function CommonUI.CommonButtonStyle.GetMaterialBrush
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetMaterialBrush(struct FSlateBrush& Brush); // Offset: 0x10149549c // Return & Params: Num(1) Size(0x98)

	// Object Name: Function CommonUI.CommonButtonStyle.GetDisabledTextStyle
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UCommonTextStyle* GetDisabledTextStyle(); // Offset: 0x101494694 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function CommonUI.CommonButtonStyle.GetDisabledBrush
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetDisabledBrush(struct FSlateBrush& Brush); // Offset: 0x1014948b0 // Return & Params: Num(1) Size(0x98)

	// Object Name: Function CommonUI.CommonButtonStyle.GetCustomPadding
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetCustomPadding(struct FMargin& OutCustomPadding); // Offset: 0x101494798 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function CommonUI.CommonButtonStyle.GetButtonPadding
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetButtonPadding(struct FMargin& OutButtonPadding); // Offset: 0x101494824 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class CommonUI.CommonButtonInternalBase
// Size: 0x4f8 // Inherited bytes: 0x498
struct UCommonButtonInternalBase : UButton {
	// Fields
	char pad_0x498[0x10]; // Offset: 0x498 // Size: 0x10
	struct FMulticastInlineDelegate OnDoubleClicked; // Offset: 0x4a8 // Size: 0x10
	char pad_0x4B8[0x10]; // Offset: 0x4b8 // Size: 0x10
	int32_t MinWidth; // Offset: 0x4c8 // Size: 0x04
	int32_t MinHeight; // Offset: 0x4cc // Size: 0x04
	bool bButtonEnabled; // Offset: 0x4d0 // Size: 0x01
	bool bInteractionEnabled; // Offset: 0x4d1 // Size: 0x01
	char pad_0x4D2[0x26]; // Offset: 0x4d2 // Size: 0x26
};

// Object Name: Class CommonUI.CommonWidgetGroupBase
// Size: 0x28 // Inherited bytes: 0x28
struct UCommonWidgetGroupBase : UObject {
	// Functions

	// Object Name: Function CommonUI.CommonWidgetGroupBase.RemoveWidget
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RemoveWidget(struct UWidget* InWidget); // Offset: 0x1014a80e8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function CommonUI.CommonWidgetGroupBase.RemoveAll
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RemoveAll(); // Offset: 0x1014a80d4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function CommonUI.CommonWidgetGroupBase.AddWidget
	// Flags: [Final|Native|Public|BlueprintCallable]
	void AddWidget(struct UWidget* InWidget); // Offset: 0x1014a8164 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class CommonUI.CommonButtonGroupBase
// Size: 0x110 // Inherited bytes: 0x28
struct UCommonButtonGroupBase : UCommonWidgetGroupBase {
	// Fields
	struct FMulticastInlineDelegate OnSelectedButtonBaseChanged; // Offset: 0x28 // Size: 0x10
	char pad_0x38[0x18]; // Offset: 0x38 // Size: 0x18
	struct FMulticastInlineDelegate OnHoveredButtonBaseChanged; // Offset: 0x50 // Size: 0x10
	char pad_0x60[0x18]; // Offset: 0x60 // Size: 0x18
	struct FMulticastInlineDelegate OnButtonBaseClicked; // Offset: 0x78 // Size: 0x10
	char pad_0x88[0x18]; // Offset: 0x88 // Size: 0x18
	struct FMulticastInlineDelegate OnButtonBaseDoubleClicked; // Offset: 0xa0 // Size: 0x10
	char pad_0xB0[0x18]; // Offset: 0xb0 // Size: 0x18
	struct FMulticastInlineDelegate OnSelectionCleared; // Offset: 0xc8 // Size: 0x10
	char pad_0xD8[0x18]; // Offset: 0xd8 // Size: 0x18
	bool bSelectionRequired; // Offset: 0xf0 // Size: 0x01
	char pad_0xF1[0x1f]; // Offset: 0xf1 // Size: 0x1f

	// Functions

	// Object Name: Function CommonUI.CommonButtonGroupBase.SetSelectionRequired
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSelectionRequired(bool bRequireSelection); // Offset: 0x10149b350 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function CommonUI.CommonButtonGroupBase.SelectPreviousButton
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SelectPreviousButton(bool bAllowWrap); // Offset: 0x10149b234 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function CommonUI.CommonButtonGroupBase.SelectNextButton
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SelectNextButton(bool bAllowWrap); // Offset: 0x10149b2b8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function CommonUI.CommonButtonGroupBase.SelectButtonAtIndex
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SelectButtonAtIndex(int32_t ButtonIndex); // Offset: 0x10149b1b8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function CommonUI.CommonButtonGroupBase.OnSelectionStateChangedBase
	// Flags: [Native|Protected]
	void OnSelectionStateChangedBase(struct UCommonButtonBase* BaseButton, bool bIsSelected); // Offset: 0x10149aecc // Return & Params: Num(2) Size(0x9)

	// Object Name: Function CommonUI.CommonButtonGroupBase.OnHandleButtonBaseDoubleClicked
	// Flags: [Native|Protected]
	void OnHandleButtonBaseDoubleClicked(struct UCommonButtonBase* BaseButton); // Offset: 0x10149adc4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function CommonUI.CommonButtonGroupBase.OnHandleButtonBaseClicked
	// Flags: [Native|Protected]
	void OnHandleButtonBaseClicked(struct UCommonButtonBase* BaseButton); // Offset: 0x10149ae48 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function CommonUI.CommonButtonGroupBase.OnButtonBaseUnhovered
	// Flags: [Native|Protected]
	void OnButtonBaseUnhovered(struct UCommonButtonBase* BaseButton); // Offset: 0x10149acbc // Return & Params: Num(1) Size(0x8)

	// Object Name: Function CommonUI.CommonButtonGroupBase.OnButtonBaseHovered
	// Flags: [Native|Protected]
	void OnButtonBaseHovered(struct UCommonButtonBase* BaseButton); // Offset: 0x10149ad40 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function CommonUI.CommonButtonGroupBase.HasAnyButtons
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool HasAnyButtons(); // Offset: 0x10149afd0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function CommonUI.CommonButtonGroupBase.GetSelectedButtonIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetSelectedButtonIndex(); // Offset: 0x10149b184 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function CommonUI.CommonButtonGroupBase.GetSelectedButtonBase
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UCommonButtonBase* GetSelectedButtonBase(); // Offset: 0x10149b004 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function CommonUI.CommonButtonGroupBase.GetHoveredButtonIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetHoveredButtonIndex(); // Offset: 0x10149b150 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function CommonUI.CommonButtonGroupBase.GetButtonCount
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetButtonCount(); // Offset: 0x10149af9c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function CommonUI.CommonButtonGroupBase.GetButtonBaseAtIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UCommonButtonBase* GetButtonBaseAtIndex(int32_t Index); // Offset: 0x10149b038 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function CommonUI.CommonButtonGroupBase.FindButtonIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t FindButtonIndex(struct UCommonButtonBase* ButtonToFind); // Offset: 0x10149b0c4 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function CommonUI.CommonButtonGroupBase.DeselectAll
	// Flags: [Final|Native|Public|BlueprintCallable]
	void DeselectAll(); // Offset: 0x10149b33c // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class CommonUI.CommonCustomNavigation
// Size: 0x2b8 // Inherited bytes: 0x2a8
struct UCommonCustomNavigation : UBorder {
	// Fields
	struct FDelegate OnNavigationEvent; // Offset: 0x2a8 // Size: 0x10
};

// Object Name: Class CommonUI.CommonTextBlock
// Size: 0x318 // Inherited bytes: 0x2f0
struct UCommonTextBlock : UTextBlock {
	// Fields
	struct UCommonTextStyle* Style; // Offset: 0x2f0 // Size: 0x08
	struct UCommonTextScrollStyle* ScrollStyle; // Offset: 0x2f8 // Size: 0x08
	bool bDisplayAllCaps; // Offset: 0x300 // Size: 0x01
	bool bAutoCollapseWithEmptyText; // Offset: 0x301 // Size: 0x01
	char pad_0x302[0x2]; // Offset: 0x302 // Size: 0x02
	float MobileFontSizeMultiplier; // Offset: 0x304 // Size: 0x04
	char pad_0x308[0x10]; // Offset: 0x308 // Size: 0x10

	// Functions

	// Object Name: Function CommonUI.CommonTextBlock.SetWrapTextWidth
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetWrapTextWidth(int32_t InWrapTextAt); // Offset: 0x1014a4278 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function CommonUI.CommonTextBlock.SetTextCase
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetTextCase(bool bUseAllCaps); // Offset: 0x1014a41f4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function CommonUI.CommonTextBlock.SetStyle
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetStyle(struct UCommonTextStyle* InStyle); // Offset: 0x1014a4178 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function CommonUI.CommonTextBlock.ResetScrollState
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ResetScrollState(); // Offset: 0x1014a4164 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class CommonUI.CommonDateTimeTextBlock
// Size: 0x358 // Inherited bytes: 0x318
struct UCommonDateTimeTextBlock : UCommonTextBlock {
	// Fields
	char pad_0x318[0x40]; // Offset: 0x318 // Size: 0x40

	// Functions

	// Object Name: Function CommonUI.CommonDateTimeTextBlock.SetTimespanValue
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetTimespanValue(struct FTimespan InTimespan); // Offset: 0x10149bf7c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function CommonUI.CommonDateTimeTextBlock.SetDateTimeValue
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetDateTimeValue(struct FDateTime InDateTime, bool bShowAsCountdown, float InRefreshDelay); // Offset: 0x10149bff4 // Return & Params: Num(3) Size(0x10)

	// Object Name: Function CommonUI.CommonDateTimeTextBlock.SetCountDownCompletionText
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetCountDownCompletionText(struct FText InCompletionText); // Offset: 0x10149be24 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function CommonUI.CommonDateTimeTextBlock.GetDateTime
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FDateTime GetDateTime(); // Offset: 0x10149bdf0 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class CommonUI.CommonGameViewportClient
// Size: 0x368 // Inherited bytes: 0x328
struct UCommonGameViewportClient : UGameViewportClient {
	// Fields
	char pad_0x328[0x40]; // Offset: 0x328 // Size: 0x40
};

// Object Name: Class CommonUI.CommonHierarchicalScrollBox
// Size: 0x980 // Inherited bytes: 0x980
struct UCommonHierarchicalScrollBox : UScrollBox {
};

// Object Name: Class CommonUI.CommonLazyImage
// Size: 0x328 // Inherited bytes: 0x250
struct UCommonLazyImage : UImage {
	// Fields
	struct FSlateBrush LoadingBackgroundBrush; // Offset: 0x250 // Size: 0x98
	struct FName MaterialTextureParamName; // Offset: 0x2e8 // Size: 0x08
	struct FMulticastInlineDelegate BP_OnLoadingStateChanged; // Offset: 0x2f0 // Size: 0x10
	char pad_0x300[0x28]; // Offset: 0x300 // Size: 0x28

	// Functions

	// Object Name: Function CommonUI.CommonLazyImage.SetMaterialTextureParamName
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMaterialTextureParamName(struct FName TextureParamName); // Offset: 0x10149c7b0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function CommonUI.CommonLazyImage.SetBrushFromLazyTexture
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetBrushFromLazyTexture(struct TSoftObjectPtr<UTexture2D>& LazyTexture, bool bMatchSize); // Offset: 0x10149ca00 // Return & Params: Num(2) Size(0x29)

	// Object Name: Function CommonUI.CommonLazyImage.SetBrushFromLazyMaterial
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetBrushFromLazyMaterial(struct TSoftObjectPtr<UMaterialInterface>& LazyMaterial); // Offset: 0x10149c958 // Return & Params: Num(1) Size(0x28)

	// Object Name: Function CommonUI.CommonLazyImage.SetBrushFromLazyDisplayAsset
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetBrushFromLazyDisplayAsset(struct TSoftObjectPtr<UObject>& LazyObject, bool bMatchTextureSize); // Offset: 0x10149c860 // Return & Params: Num(2) Size(0x29)

	// Object Name: Function CommonUI.CommonLazyImage.IsLoading
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsLoading(); // Offset: 0x10149c82c // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class CommonUI.CommonLazyWidget
// Size: 0x250 // Inherited bytes: 0x138
struct UCommonLazyWidget : UWidget {
	// Fields
	struct FSlateBrush LoadingBackgroundBrush; // Offset: 0x138 // Size: 0x98
	struct UUserWidget* Content; // Offset: 0x1d0 // Size: 0x08
	char pad_0x1D8[0x28]; // Offset: 0x1d8 // Size: 0x28
	struct FMulticastInlineDelegate BP_OnLoadingStateChanged; // Offset: 0x200 // Size: 0x10
	char pad_0x210[0x40]; // Offset: 0x210 // Size: 0x40

	// Functions

	// Object Name: Function CommonUI.CommonLazyWidget.SetLazyContent
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetLazyContent(struct TSoftClassPtr<UObject> SoftWidget); // Offset: 0x10149cf0c // Return & Params: Num(1) Size(0x28)

	// Object Name: Function CommonUI.CommonLazyWidget.IsLoading
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsLoading(); // Offset: 0x10149cebc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function CommonUI.CommonLazyWidget.GetContent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UUserWidget* GetContent(); // Offset: 0x10149cef0 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class CommonUI.CommonListView
// Size: 0x950 // Inherited bytes: 0x950
struct UCommonListView : UListView {
	// Functions

	// Object Name: Function CommonUI.CommonListView.SetEntrySpacing
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetEntrySpacing(float InEntrySpacing); // Offset: 0x10149d2c8 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class CommonUI.LoadGuardSlot
// Size: 0x60 // Inherited bytes: 0x38
struct ULoadGuardSlot : UPanelSlot {
	// Fields
	struct FMargin Padding; // Offset: 0x38 // Size: 0x10
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0x48 // Size: 0x01
	enum class EVerticalAlignment VerticalAlignment; // Offset: 0x49 // Size: 0x01
	char pad_0x4A[0x16]; // Offset: 0x4a // Size: 0x16

	// Functions

	// Object Name: Function CommonUI.LoadGuardSlot.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment); // Offset: 0x10149d60c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function CommonUI.LoadGuardSlot.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPadding(struct FMargin InPadding); // Offset: 0x10149d704 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function CommonUI.LoadGuardSlot.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment); // Offset: 0x10149d688 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class CommonUI.CommonLoadGuard
// Size: 0x270 // Inherited bytes: 0x150
struct UCommonLoadGuard : UContentWidget {
	// Fields
	struct FSlateBrush LoadingBackgroundBrush; // Offset: 0x150 // Size: 0x98
	enum class EHorizontalAlignment ThrobberAlignment; // Offset: 0x1e8 // Size: 0x01
	char pad_0x1E9[0x3]; // Offset: 0x1e9 // Size: 0x03
	struct FMargin ThrobberPadding; // Offset: 0x1ec // Size: 0x10
	char pad_0x1FC[0x4]; // Offset: 0x1fc // Size: 0x04
	struct FText LoadingText; // Offset: 0x200 // Size: 0x18
	struct UCommonTextStyle* TextStyle; // Offset: 0x218 // Size: 0x08
	struct FMulticastInlineDelegate BP_OnLoadingStateChanged; // Offset: 0x220 // Size: 0x10
	struct FSoftObjectPath SpinnerMaterialPath; // Offset: 0x230 // Size: 0x18
	char pad_0x248[0x28]; // Offset: 0x248 // Size: 0x28

	// Functions

	// Object Name: Function CommonUI.CommonLoadGuard.SetLoadingText
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetLoadingText(struct FText& InLoadingText); // Offset: 0x10149dd28 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function CommonUI.CommonLoadGuard.SetIsLoading
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetIsLoading(bool bInIsLoading); // Offset: 0x10149dca4 // Return & Params: Num(1) Size(0x1)

	// Object Name: DelegateFunction CommonUI.CommonLoadGuard.OnAssetLoaded__DelegateSignature
	// Flags: [Public|Delegate]
	void OnAssetLoaded__DelegateSignature(struct UObject* Object); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function CommonUI.CommonLoadGuard.IsLoading
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsLoading(); // Offset: 0x10149dc70 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function CommonUI.CommonLoadGuard.BP_GuardAndLoadAsset
	// Flags: [Final|Native|Private|HasOutParms|BlueprintCallable]
	void BP_GuardAndLoadAsset(struct TSoftObjectPtr<UObject>& InLazyAsset, struct FDelegate& OnAssetLoaded); // Offset: 0x10149db28 // Return & Params: Num(2) Size(0x38)
};

// Object Name: Class CommonUI.CommonNumericTextBlock
// Size: 0x3b8 // Inherited bytes: 0x318
struct UCommonNumericTextBlock : UCommonTextBlock {
	// Fields
	struct FMulticastInlineDelegate OnInterpolationStartedEvent; // Offset: 0x318 // Size: 0x10
	struct FMulticastInlineDelegate OnInterpolationUpdatedEvent; // Offset: 0x328 // Size: 0x10
	struct FMulticastInlineDelegate OnOutroEvent; // Offset: 0x338 // Size: 0x10
	struct FMulticastInlineDelegate OnInterpolationEndedEvent; // Offset: 0x348 // Size: 0x10
	float CurrentNumericValue; // Offset: 0x358 // Size: 0x04
	enum class ECommonNumericType NumericType; // Offset: 0x35c // Size: 0x01
	char pad_0x35D[0x3]; // Offset: 0x35d // Size: 0x03
	struct FCommonNumberFormattingOptions FormattingSpecification; // Offset: 0x360 // Size: 0x14
	float EaseOutInterpolationExponent; // Offset: 0x374 // Size: 0x04
	float InterpolationUpdateInterval; // Offset: 0x378 // Size: 0x04
	float PostInterpolationShrinkDuration; // Offset: 0x37c // Size: 0x04
	bool PerformSizeInterpolation; // Offset: 0x380 // Size: 0x01
	bool IsPercentage; // Offset: 0x381 // Size: 0x01
	char pad_0x382[0x36]; // Offset: 0x382 // Size: 0x36

	// Functions

	// Object Name: Function CommonUI.CommonNumericTextBlock.SetNumericType
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetNumericType(enum class ECommonNumericType InNumericType); // Offset: 0x10149e4c0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function CommonUI.CommonNumericTextBlock.SetCurrentValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetCurrentValue(float NewValue); // Offset: 0x10149e6b0 // Return & Params: Num(1) Size(0x4)

	// Object Name: DelegateFunction CommonUI.CommonNumericTextBlock.OnOutro__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnOutro__DelegateSignature(struct UCommonNumericTextBlock* NumericTextBlock); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x8)

	// Object Name: DelegateFunction CommonUI.CommonNumericTextBlock.OnInterpolationUpdated__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnInterpolationUpdated__DelegateSignature(struct UCommonNumericTextBlock* NumericTextBlock, float LastValue, float NewValue); // Offset: 0x102f67d18 // Return & Params: Num(3) Size(0x10)

	// Object Name: DelegateFunction CommonUI.CommonNumericTextBlock.OnInterpolationStarted__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnInterpolationStarted__DelegateSignature(struct UCommonNumericTextBlock* NumericTextBlock); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x8)

	// Object Name: DelegateFunction CommonUI.CommonNumericTextBlock.OnInterpolationEnded__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnInterpolationEnded__DelegateSignature(struct UCommonNumericTextBlock* NumericTextBlock, bool HadCompleted); // Offset: 0x102f67d18 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function CommonUI.CommonNumericTextBlock.IsInterpolatingNumericValue
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsInterpolatingNumericValue(); // Offset: 0x10149e53c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function CommonUI.CommonNumericTextBlock.InterpolateToValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	void InterpolateToValue(float TargetValue, float MaximumInterpolationDuration, float MinimumChangeRate, float OutroOffset); // Offset: 0x10149e570 // Return & Params: Num(4) Size(0x10)

	// Object Name: Function CommonUI.CommonNumericTextBlock.GetTargetValue
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetTargetValue(); // Offset: 0x10149e72c // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class CommonUI.CommonPoolableWidgetInterface
// Size: 0x28 // Inherited bytes: 0x28
struct UCommonPoolableWidgetInterface : UInterface {
	// Functions

	// Object Name: Function CommonUI.CommonPoolableWidgetInterface.OnReleaseToPool
	// Flags: [Native|Event|Protected|BlueprintEvent]
	void OnReleaseToPool(); // Offset: 0x10149ea9c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function CommonUI.CommonPoolableWidgetInterface.OnAcquireFromPool
	// Flags: [Native|Event|Protected|BlueprintEvent]
	void OnAcquireFromPool(); // Offset: 0x10149eab8 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class CommonUI.CommonRichTextBlock
// Size: 0x748 // Inherited bytes: 0x710
struct UCommonRichTextBlock : URichTextBlock {
	// Fields
	enum class ERichTextInlineIconDisplayMode InlineIconDisplayMode; // Offset: 0x710 // Size: 0x01
	bool bTintInlineIcon; // Offset: 0x711 // Size: 0x01
	char pad_0x712[0x6]; // Offset: 0x712 // Size: 0x06
	struct UCommonTextStyle* DefaultTextStyleOverrideClass; // Offset: 0x718 // Size: 0x08
	float MobileTextBlockScale; // Offset: 0x720 // Size: 0x04
	char pad_0x724[0x4]; // Offset: 0x724 // Size: 0x04
	struct UCommonTextScrollStyle* ScrollStyle; // Offset: 0x728 // Size: 0x08
	bool bDisplayAllCaps; // Offset: 0x730 // Size: 0x01
	char pad_0x731[0x17]; // Offset: 0x731 // Size: 0x17
};

// Object Name: Class CommonUI.CommonRotator
// Size: 0xcb8 // Inherited bytes: 0xc60
struct UCommonRotator : UCommonButtonBase {
	// Fields
	char pad_0xC60[0x10]; // Offset: 0xc60 // Size: 0x10
	struct FMulticastInlineDelegate OnRotated; // Offset: 0xc70 // Size: 0x10
	char pad_0xC80[0x18]; // Offset: 0xc80 // Size: 0x18
	struct UCommonTextBlock* MyText; // Offset: 0xc98 // Size: 0x08
	char pad_0xCA0[0x18]; // Offset: 0xca0 // Size: 0x18

	// Functions

	// Object Name: Function CommonUI.CommonRotator.ShiftTextRight
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ShiftTextRight(); // Offset: 0x10149efd4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function CommonUI.CommonRotator.ShiftTextLeft
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ShiftTextLeft(); // Offset: 0x10149efe8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function CommonUI.CommonRotator.SetSelectedItem
	// Flags: [Native|Public|BlueprintCallable]
	void SetSelectedItem(int32_t InValue); // Offset: 0x10149f018 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function CommonUI.CommonRotator.PopulateTextLabels
	// Flags: [Final|Native|Public|BlueprintCallable]
	void PopulateTextLabels(struct TArray<struct FText> Labels); // Offset: 0x10149f144 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function CommonUI.CommonRotator.GetSelectedText
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FText GetSelectedText(); // Offset: 0x10149f09c // Return & Params: Num(1) Size(0x18)

	// Object Name: Function CommonUI.CommonRotator.GetSelectedIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetSelectedIndex(); // Offset: 0x10149effc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function CommonUI.CommonRotator.BP_OnOptionsPopulated
	// Flags: [Event|Protected|BlueprintEvent]
	void BP_OnOptionsPopulated(int32_t count); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function CommonUI.CommonRotator.BP_OnOptionSelected
	// Flags: [Event|Protected|BlueprintEvent]
	void BP_OnOptionSelected(int32_t Index); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class CommonUI.CommonTabListWidgetBase
// Size: 0x358 // Inherited bytes: 0x288
struct UCommonTabListWidgetBase : UCommonUserWidget {
	// Fields
	struct FMulticastInlineDelegate OnTabSelected; // Offset: 0x288 // Size: 0x10
	struct FMulticastInlineDelegate OnTabButtonCreation; // Offset: 0x298 // Size: 0x10
	struct FMulticastInlineDelegate OnTabButtonRemoval; // Offset: 0x2a8 // Size: 0x10
	struct FDataTableRowHandle NextTabInputActionData; // Offset: 0x2b8 // Size: 0x10
	struct FDataTableRowHandle PreviousTabInputActionData; // Offset: 0x2c8 // Size: 0x10
	bool bAutoListenForInput; // Offset: 0x2d8 // Size: 0x01
	char pad_0x2D9[0x3]; // Offset: 0x2d9 // Size: 0x03
	struct TWeakObjectPtr<struct UCommonAnimatedSwitcher> LinkedSwitcher; // Offset: 0x2dc // Size: 0x08
	char pad_0x2E4[0x4]; // Offset: 0x2e4 // Size: 0x04
	struct UCommonButtonGroupBase* TabButtonGroup; // Offset: 0x2e8 // Size: 0x08
	char pad_0x2F0[0x8]; // Offset: 0x2f0 // Size: 0x08
	struct TMap<struct FName, struct FCommonRegisteredTabInfo> RegisteredTabsByID; // Offset: 0x2f8 // Size: 0x50
	char pad_0x348[0x10]; // Offset: 0x348 // Size: 0x10

	// Functions

	// Object Name: Function CommonUI.CommonTabListWidgetBase.SetTabVisibility
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetTabVisibility(struct FName TabNameID, enum class ESlateVisibility NewVisibility); // Offset: 0x1014a0164 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function CommonUI.CommonTabListWidgetBase.SetTabInteractionEnabled
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetTabInteractionEnabled(struct FName TabNameID, bool bEnable); // Offset: 0x10149ffd4 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function CommonUI.CommonTabListWidgetBase.SetTabEnabled
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetTabEnabled(struct FName TabNameID, bool bEnable); // Offset: 0x1014a009c // Return & Params: Num(2) Size(0x9)

	// Object Name: Function CommonUI.CommonTabListWidgetBase.SetListeningForInput
	// Flags: [Native|Public|BlueprintCallable]
	void SetListeningForInput(bool bShouldListen); // Offset: 0x10149fe14 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function CommonUI.CommonTabListWidgetBase.SetLinkedSwitcher
	// Flags: [Native|Public|BlueprintCallable]
	void SetLinkedSwitcher(struct UCommonAnimatedSwitcher* CommonSwitcher); // Offset: 0x1014a05d4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function CommonUI.CommonTabListWidgetBase.SelectTabByID
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool SelectTabByID(struct FName TabNameID, bool bSuppressClickFeedback); // Offset: 0x1014a02e4 // Return & Params: Num(3) Size(0xa)

	// Object Name: Function CommonUI.CommonTabListWidgetBase.RemoveTab
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool RemoveTab(struct FName TabNameID); // Offset: 0x1014a0404 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function CommonUI.CommonTabListWidgetBase.RemoveAllTabs
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RemoveAllTabs(); // Offset: 0x1014a03f0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function CommonUI.CommonTabListWidgetBase.RegisterTab
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool RegisterTab(struct FName TabNameID, struct UCommonButtonBase* ButtonWidgetType, struct UWidget* ContentWidget); // Offset: 0x1014a0490 // Return & Params: Num(4) Size(0x19)

	// Object Name: DelegateFunction CommonUI.CommonTabListWidgetBase.OnTabSelected__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnTabSelected__DelegateSignature(struct FName TabId); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x8)

	// Object Name: DelegateFunction CommonUI.CommonTabListWidgetBase.OnTabButtonRemoval__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnTabButtonRemoval__DelegateSignature(struct FName TabId, struct UCommonButtonBase* TabButton); // Offset: 0x102f67d18 // Return & Params: Num(2) Size(0x10)

	// Object Name: DelegateFunction CommonUI.CommonTabListWidgetBase.OnTabButtonCreation__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnTabButtonCreation__DelegateSignature(struct FName TabId, struct UCommonButtonBase* TabButton); // Offset: 0x102f67d18 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function CommonUI.CommonTabListWidgetBase.HandleTabRemoval
	// Flags: [Native|Event|Protected|BlueprintEvent]
	void HandleTabRemoval(struct FName TabNameID, struct UCommonButtonBase* TabButton); // Offset: 0x10149fc8c // Return & Params: Num(2) Size(0x10)

	// Object Name: Function CommonUI.CommonTabListWidgetBase.HandleTabCreation
	// Flags: [Native|Event|Protected|BlueprintEvent]
	void HandleTabCreation(struct FName TabNameID, struct UCommonButtonBase* TabButton); // Offset: 0x10149fd50 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function CommonUI.CommonTabListWidgetBase.HandleTabButtonSelected
	// Flags: [Final|Native|Protected]
	void HandleTabButtonSelected(struct UCommonButtonBase* SelectedTabButton, int32_t ButtonIndex); // Offset: 0x10149fb40 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function CommonUI.CommonTabListWidgetBase.HandlePreviousTabInputAction
	// Flags: [Final|Native|Protected|HasOutParms]
	void HandlePreviousTabInputAction(bool& bPassThrough); // Offset: 0x10149fab4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function CommonUI.CommonTabListWidgetBase.HandlePreLinkedSwitcherChanged_BP
	// Flags: [Event|Protected|BlueprintEvent]
	void HandlePreLinkedSwitcherChanged_BP(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function CommonUI.CommonTabListWidgetBase.HandlePostLinkedSwitcherChanged_BP
	// Flags: [Event|Protected|BlueprintEvent]
	void HandlePostLinkedSwitcherChanged_BP(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function CommonUI.CommonTabListWidgetBase.HandleNextTabInputAction
	// Flags: [Final|Native|Protected|HasOutParms]
	void HandleNextTabInputAction(bool& bPassThrough); // Offset: 0x10149fa28 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function CommonUI.CommonTabListWidgetBase.GetTabIdAtIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FName GetTabIdAtIndex(int32_t Index); // Offset: 0x1014a0224 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function CommonUI.CommonTabListWidgetBase.GetTabCount
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetTabCount(); // Offset: 0x1014a03bc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function CommonUI.CommonTabListWidgetBase.GetTabButtonBaseByID
	// Flags: [Final|Native|Protected|BlueprintCallable]
	struct UCommonButtonBase* GetTabButtonBaseByID(struct FName TabNameID); // Offset: 0x10149fc00 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function CommonUI.CommonTabListWidgetBase.GetSelectedTabId
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FName GetSelectedTabId(); // Offset: 0x1014a02b0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function CommonUI.CommonTabListWidgetBase.GetLinkedSwitcher
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UCommonAnimatedSwitcher* GetLinkedSwitcher(); // Offset: 0x1014a05a0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function CommonUI.CommonTabListWidgetBase.GetActiveTab
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FName GetActiveTab(); // Offset: 0x1014a0658 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function CommonUI.CommonTabListWidgetBase.DisableTabWithReason
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void DisableTabWithReason(struct FName TabNameID, struct FText& Reason); // Offset: 0x10149fea0 // Return & Params: Num(2) Size(0x20)
};

// Object Name: Class CommonUI.CommonTextStyle
// Size: 0x160 // Inherited bytes: 0x28
struct UCommonTextStyle : UObject {
	// Fields
	struct FSlateFontInfo Font; // Offset: 0x28 // Size: 0x58
	struct FLinearColor Color; // Offset: 0x80 // Size: 0x10
	bool bUsesDropShadow; // Offset: 0x90 // Size: 0x01
	char pad_0x91[0x3]; // Offset: 0x91 // Size: 0x03
	struct FVector2D ShadowOffset; // Offset: 0x94 // Size: 0x08
	struct FLinearColor ShadowColor; // Offset: 0x9c // Size: 0x10
	struct FMargin Margin; // Offset: 0xac // Size: 0x10
	char pad_0xBC[0x4]; // Offset: 0xbc // Size: 0x04
	struct FSlateBrush StrikeBrush; // Offset: 0xc0 // Size: 0x98
	float LineHeightPercentage; // Offset: 0x158 // Size: 0x04
	char pad_0x15C[0x4]; // Offset: 0x15c // Size: 0x04

	// Functions

	// Object Name: Function CommonUI.CommonTextStyle.GetStrikeBrush
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetStrikeBrush(struct FSlateBrush& OutStrikeBrush); // Offset: 0x1014a3424 // Return & Params: Num(1) Size(0x98)

	// Object Name: Function CommonUI.CommonTextStyle.GetShadowOffset
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	void GetShadowOffset(struct FVector2D& OutShadowOffset); // Offset: 0x1014a3660 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function CommonUI.CommonTextStyle.GetShadowColor
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	void GetShadowColor(struct FLinearColor& OutColor); // Offset: 0x1014a35d8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function CommonUI.CommonTextStyle.GetMargin
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetMargin(struct FMargin& OutMargin); // Offset: 0x1014a371c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function CommonUI.CommonTextStyle.GetLineHeightPercentage
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetLineHeightPercentage(); // Offset: 0x1014a36e8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function CommonUI.CommonTextStyle.GetFont
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	void GetFont(struct FSlateFontInfo& OutFont); // Offset: 0x1014a3830 // Return & Params: Num(1) Size(0x58)

	// Object Name: Function CommonUI.CommonTextStyle.GetColor
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	void GetColor(struct FLinearColor& OutColor); // Offset: 0x1014a37a8 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class CommonUI.CommonTextScrollStyle
// Size: 0x40 // Inherited bytes: 0x28
struct UCommonTextScrollStyle : UObject {
	// Fields
	float Speed; // Offset: 0x28 // Size: 0x04
	float StartDelay; // Offset: 0x2c // Size: 0x04
	float EndDelay; // Offset: 0x30 // Size: 0x04
	float FadeInDelay; // Offset: 0x34 // Size: 0x04
	float FadeOutDelay; // Offset: 0x38 // Size: 0x04
	char pad_0x3C[0x4]; // Offset: 0x3c // Size: 0x04
};

// Object Name: Class CommonUI.CommonTileView
// Size: 0x968 // Inherited bytes: 0x968
struct UCommonTileView : UTileView {
};

// Object Name: Class CommonUI.CommonTreeView
// Size: 0x9a8 // Inherited bytes: 0x9a8
struct UCommonTreeView : UTreeView {
};

// Object Name: Class CommonUI.CommonUIActionRouterBase
// Size: 0x100 // Inherited bytes: 0x30
struct UCommonUIActionRouterBase : ULocalPlayerSubsystem {
	// Fields
	char pad_0x30[0xd0]; // Offset: 0x30 // Size: 0xd0
};

// Object Name: Class CommonUI.CommonUIEditorSettings
// Size: 0xa8 // Inherited bytes: 0x28
struct UCommonUIEditorSettings : UObject {
	// Fields
	struct TSoftClassPtr<UObject> TemplateTextStyle; // Offset: 0x28 // Size: 0x28
	struct TSoftClassPtr<UObject> TemplateButtonStyle; // Offset: 0x50 // Size: 0x28
	struct TSoftClassPtr<UObject> TemplateBorderStyle; // Offset: 0x78 // Size: 0x28
	char pad_0xA0[0x8]; // Offset: 0xa0 // Size: 0x08
};

// Object Name: Class CommonUI.CommonUIInputSettings
// Size: 0x78 // Inherited bytes: 0x28
struct UCommonUIInputSettings : UObject {
	// Fields
	bool bLinkCursorToGamepadFocus; // Offset: 0x28 // Size: 0x01
	char pad_0x29[0x3]; // Offset: 0x29 // Size: 0x03
	int32_t UIActionProcessingPriority; // Offset: 0x2c // Size: 0x04
	struct TArray<struct FUIInputAction> InputActions; // Offset: 0x30 // Size: 0x10
	struct TArray<struct FUIInputAction> ActionOverrides; // Offset: 0x40 // Size: 0x10
	struct FCommonAnalogCursorSettings AnalogCursorSettings; // Offset: 0x50 // Size: 0x24
	char pad_0x74[0x4]; // Offset: 0x74 // Size: 0x04
};

// Object Name: Class CommonUI.CommonUILibrary
// Size: 0x28 // Inherited bytes: 0x28
struct UCommonUILibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function CommonUI.CommonUILibrary.FindParentWidgetOfType
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UWidget* FindParentWidgetOfType(struct UWidget* StartingWidget, struct UWidget* Type); // Offset: 0x1014a52a0 // Return & Params: Num(3) Size(0x18)
};

// Object Name: Class CommonUI.CommonUIRichTextData
// Size: 0x30 // Inherited bytes: 0x28
struct UCommonUIRichTextData : UObject {
	// Fields
	struct UDataTable* InlineIconSet; // Offset: 0x28 // Size: 0x08
};

// Object Name: Class CommonUI.CommonUISettings
// Size: 0x160 // Inherited bytes: 0x28
struct UCommonUISettings : UObject {
	// Fields
	bool bAutoLoadData; // Offset: 0x28 // Size: 0x01
	char pad_0x29[0x7]; // Offset: 0x29 // Size: 0x07
	struct TSoftObjectPtr<UObject> DefaultImageResourceObject; // Offset: 0x30 // Size: 0x28
	struct TSoftObjectPtr<UMaterialInterface> DefaultThrobberMaterial; // Offset: 0x58 // Size: 0x28
	struct TSoftClassPtr<UObject> DefaultRichTextDataClass; // Offset: 0x80 // Size: 0x28
	char pad_0xA8[0x8]; // Offset: 0xa8 // Size: 0x08
	struct UObject* DefaultImageResourceObjectInstance; // Offset: 0xb0 // Size: 0x08
	struct UMaterialInterface* DefaultThrobberMaterialInstance; // Offset: 0xb8 // Size: 0x08
	struct FSlateBrush DefaultThrobberBrush; // Offset: 0xc0 // Size: 0x98
	struct UCommonUIRichTextData* RichTextDataInstance; // Offset: 0x158 // Size: 0x08
};

// Object Name: Class CommonUI.CommonUISubsystemBase
// Size: 0x40 // Inherited bytes: 0x30
struct UCommonUISubsystemBase : UGameInstanceSubsystem {
	// Fields
	char pad_0x30[0x10]; // Offset: 0x30 // Size: 0x10

	// Functions

	// Object Name: Function CommonUI.CommonUISubsystemBase.GetInputActionButtonIcon
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	struct FSlateBrush GetInputActionButtonIcon(struct FDataTableRowHandle& InputActionRowHandle, enum class ECommonInputType InputType, struct FName& GamepadName); // Offset: 0x1014a5af0 // Return & Params: Num(4) Size(0xb8)
};

// Object Name: Class CommonUI.CommonVideoPlayer
// Size: 0x258 // Inherited bytes: 0x138
struct UCommonVideoPlayer : UWidget {
	// Fields
	struct UMediaSource* Video; // Offset: 0x138 // Size: 0x08
	struct UMediaPlayer* MediaPlayer; // Offset: 0x140 // Size: 0x08
	struct UMediaTexture* MediaTexture; // Offset: 0x148 // Size: 0x08
	struct UMaterial* VideoMaterial; // Offset: 0x150 // Size: 0x08
	struct UMediaSoundComponent* SoundComponent; // Offset: 0x158 // Size: 0x08
	struct FSlateBrush VideoBrush; // Offset: 0x160 // Size: 0x98
	char pad_0x1F8[0x60]; // Offset: 0x1f8 // Size: 0x60
};

// Object Name: Class CommonUI.CommonVisibilitySwitcher
// Size: 0x188 // Inherited bytes: 0x160
struct UCommonVisibilitySwitcher : UOverlay {
	// Fields
	enum class ESlateVisibility ShownVisibility; // Offset: 0x160 // Size: 0x01
	char pad_0x161[0x3]; // Offset: 0x161 // Size: 0x03
	int32_t ActiveWidgetIndex; // Offset: 0x164 // Size: 0x04
	bool bAutoActivateSlot; // Offset: 0x168 // Size: 0x01
	bool bActivateFirstSlotOnAdding; // Offset: 0x169 // Size: 0x01
	char pad_0x16A[0x1e]; // Offset: 0x16a // Size: 0x1e

	// Functions

	// Object Name: Function CommonUI.CommonVisibilitySwitcher.SetActiveWidgetIndex
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetActiveWidgetIndex(int32_t Index); // Offset: 0x1014a69b0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function CommonUI.CommonVisibilitySwitcher.SetActiveWidget
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetActiveWidget(struct UWidget* Widget); // Offset: 0x1014a68e4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function CommonUI.CommonVisibilitySwitcher.IncrementActiveWidgetIndex
	// Flags: [Final|Native|Public|BlueprintCallable]
	void IncrementActiveWidgetIndex(bool bAllowWrapping); // Offset: 0x1014a6860 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function CommonUI.CommonVisibilitySwitcher.GetActiveWidgetIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetActiveWidgetIndex(); // Offset: 0x1014a6994 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function CommonUI.CommonVisibilitySwitcher.GetActiveWidget
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UWidget* GetActiveWidget(); // Offset: 0x1014a6960 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function CommonUI.CommonVisibilitySwitcher.DecrementActiveWidgetIndex
	// Flags: [Final|Native|Public|BlueprintCallable]
	void DecrementActiveWidgetIndex(bool bAllowWrapping); // Offset: 0x1014a67dc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function CommonUI.CommonVisibilitySwitcher.DeactivateVisibleSlot
	// Flags: [Final|Native|Public|BlueprintCallable]
	void DeactivateVisibleSlot(); // Offset: 0x1014a67b4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function CommonUI.CommonVisibilitySwitcher.ActivateVisibleSlot
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ActivateVisibleSlot(); // Offset: 0x1014a67c8 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class CommonUI.CommonVisibilitySwitcherSlot
// Size: 0x68 // Inherited bytes: 0x58
struct UCommonVisibilitySwitcherSlot : UOverlaySlot {
	// Fields
	char pad_0x58[0x10]; // Offset: 0x58 // Size: 0x10
};

// Object Name: Class CommonUI.CommonVisibilityWidgetBase
// Size: 0x320 // Inherited bytes: 0x2c8
struct UCommonVisibilityWidgetBase : UCommonBorder {
	// Fields
	struct TMap<struct FName, bool> VisibilityControls; // Offset: 0x2c8 // Size: 0x50
	bool bShowForGamepad; // Offset: 0x318 // Size: 0x01
	bool bShowForMouseAndKeyboard; // Offset: 0x319 // Size: 0x01
	bool bShowForTouch; // Offset: 0x31a // Size: 0x01
	enum class ESlateVisibility VisibleType; // Offset: 0x31b // Size: 0x01
	enum class ESlateVisibility HiddenType; // Offset: 0x31c // Size: 0x01
	char pad_0x31D[0x3]; // Offset: 0x31d // Size: 0x03

	// Functions

	// Object Name: Function CommonUI.CommonVisibilityWidgetBase.GetRegisteredPlatforms
	// Flags: [Final|Native|Static|Protected]
	struct TArray<struct FName> GetRegisteredPlatforms(); // Offset: 0x1014a70b8 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class CommonUI.CommonVisualAttachment
// Size: 0x1a0 // Inherited bytes: 0x188
struct UCommonVisualAttachment : USizeBox {
	// Fields
	struct FVector2D ContentAnchor; // Offset: 0x184 // Size: 0x08
	char pad_0x190[0x10]; // Offset: 0x190 // Size: 0x10
};

// Object Name: Class CommonUI.CommonWidgetCarousel
// Size: 0x188 // Inherited bytes: 0x150
struct UCommonWidgetCarousel : UPanelWidget {
	// Fields
	int32_t ActiveWidgetIndex; // Offset: 0x14c // Size: 0x04
	struct FMulticastInlineDelegate OnCurrentPageIndexChanged; // Offset: 0x150 // Size: 0x10
	char pad_0x164[0x24]; // Offset: 0x164 // Size: 0x24

	// Functions

	// Object Name: Function CommonUI.CommonWidgetCarousel.SetActiveWidgetIndex
	// Flags: [Native|Public|BlueprintCallable]
	void SetActiveWidgetIndex(int32_t Index); // Offset: 0x1014a7730 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function CommonUI.CommonWidgetCarousel.SetActiveWidget
	// Flags: [Native|Public|BlueprintCallable]
	void SetActiveWidget(struct UWidget* Widget); // Offset: 0x1014a76ac // Return & Params: Num(1) Size(0x8)

	// Object Name: Function CommonUI.CommonWidgetCarousel.PreviousPage
	// Flags: [Final|Native|Public|BlueprintCallable]
	void PreviousPage(); // Offset: 0x1014a7568 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function CommonUI.CommonWidgetCarousel.NextPage
	// Flags: [Final|Native|Public|BlueprintCallable]
	void NextPage(); // Offset: 0x1014a757c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function CommonUI.CommonWidgetCarousel.GetWidgetAtIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UWidget* GetWidgetAtIndex(int32_t Index); // Offset: 0x1014a7620 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function CommonUI.CommonWidgetCarousel.GetActiveWidgetIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetActiveWidgetIndex(); // Offset: 0x1014a77b4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function CommonUI.CommonWidgetCarousel.EndAutoScrolling
	// Flags: [Final|Native|Public|BlueprintCallable]
	void EndAutoScrolling(); // Offset: 0x1014a7590 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function CommonUI.CommonWidgetCarousel.BeginAutoScrolling
	// Flags: [Final|Native|Public|BlueprintCallable]
	void BeginAutoScrolling(float ScrollInterval); // Offset: 0x1014a75a4 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class CommonUI.CommonWidgetCarouselNavBar
// Size: 0x180 // Inherited bytes: 0x138
struct UCommonWidgetCarouselNavBar : UWidget {
	// Fields
	struct UCommonButtonBase* ButtonWidgetType; // Offset: 0x138 // Size: 0x08
	struct FMargin ButtonPadding; // Offset: 0x140 // Size: 0x10
	char pad_0x150[0x10]; // Offset: 0x150 // Size: 0x10
	struct UCommonWidgetCarousel* LinkedCarousel; // Offset: 0x160 // Size: 0x08
	struct UCommonButtonGroupBase* ButtonGroup; // Offset: 0x168 // Size: 0x08
	struct TArray<struct UCommonButtonBase*> Buttons; // Offset: 0x170 // Size: 0x10

	// Functions

	// Object Name: Function CommonUI.CommonWidgetCarouselNavBar.SetLinkedCarousel
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetLinkedCarousel(struct UCommonWidgetCarousel* CommonCarousel); // Offset: 0x1014a7da0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function CommonUI.CommonWidgetCarouselNavBar.HandlePageChanged
	// Flags: [Final|Native|Protected]
	void HandlePageChanged(struct UCommonWidgetCarousel* CommonCarousel, int32_t PageIndex); // Offset: 0x1014a7ce0 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function CommonUI.CommonWidgetCarouselNavBar.HandleButtonClicked
	// Flags: [Final|Native|Protected]
	void HandleButtonClicked(struct UCommonButtonBase* AssociatedButton, int32_t ButtonIndex); // Offset: 0x1014a7c20 // Return & Params: Num(2) Size(0xc)
};

