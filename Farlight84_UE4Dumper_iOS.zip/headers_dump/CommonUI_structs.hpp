#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct CommonUI.CommonNumberFormattingOptions
// Size: 0x14 // Inherited bytes: 0x00
struct FCommonNumberFormattingOptions {
	// Fields
	enum class ERoundingMode RoundingMode; // Offset: 0x00 // Size: 0x01
	bool UseGrouping; // Offset: 0x01 // Size: 0x01
	char pad_0x2[0x2]; // Offset: 0x02 // Size: 0x02
	int32_t MinimumIntegralDigits; // Offset: 0x04 // Size: 0x04
	int32_t MaximumIntegralDigits; // Offset: 0x08 // Size: 0x04
	int32_t MinimumFractionalDigits; // Offset: 0x0c // Size: 0x04
	int32_t MaximumFractionalDigits; // Offset: 0x10 // Size: 0x04
};

// Object Name: ScriptStruct CommonUI.CommonRegisteredTabInfo
// Size: 0x18 // Inherited bytes: 0x00
struct FCommonRegisteredTabInfo {
	// Fields
	int32_t TabIndex; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct UCommonButtonBase* TabButton; // Offset: 0x08 // Size: 0x08
	struct UWidget* ContentInstance; // Offset: 0x10 // Size: 0x08
};

// Object Name: ScriptStruct CommonUI.CommonInputActionHandlerData
// Size: 0x20 // Inherited bytes: 0x00
struct FCommonInputActionHandlerData {
	// Fields
	struct FDataTableRowHandle InputActionRow; // Offset: 0x00 // Size: 0x10
	enum class EInputActionState State; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0xf]; // Offset: 0x11 // Size: 0x0f
};

// Object Name: ScriptStruct CommonUI.CommonButtonStyleOptionalSlateSound
// Size: 0x20 // Inherited bytes: 0x00
struct FCommonButtonStyleOptionalSlateSound {
	// Fields
	bool bHasSound; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct FSlateSound Sound; // Offset: 0x08 // Size: 0x18
};

// Object Name: ScriptStruct CommonUI.CommonAnalogCursorSettings
// Size: 0x24 // Inherited bytes: 0x00
struct FCommonAnalogCursorSettings {
	// Fields
	int32_t PreprocessorPriority; // Offset: 0x00 // Size: 0x04
	bool bEnableCursorAcceleration; // Offset: 0x04 // Size: 0x01
	char pad_0x5[0x3]; // Offset: 0x05 // Size: 0x03
	float CursorAcceleration; // Offset: 0x08 // Size: 0x04
	float CursorMaxSpeed; // Offset: 0x0c // Size: 0x04
	float CursorDeadZone; // Offset: 0x10 // Size: 0x04
	float HoverSlowdownFactor; // Offset: 0x14 // Size: 0x04
	float ScrollDeadZone; // Offset: 0x18 // Size: 0x04
	float ScrollUpdatePeriod; // Offset: 0x1c // Size: 0x04
	float ScrollMultiplier; // Offset: 0x20 // Size: 0x04
};

// Object Name: ScriptStruct CommonUI.UIInputAction
// Size: 0x30 // Inherited bytes: 0x00
struct FUIInputAction {
	// Fields
	struct FUIActionTag ActionTag; // Offset: 0x00 // Size: 0x08
	struct FText DefaultDisplayName; // Offset: 0x08 // Size: 0x18
	struct TArray<struct FUIActionKeyMapping> KeyMappings; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct CommonUI.UIActionKeyMapping
// Size: 0x20 // Inherited bytes: 0x00
struct FUIActionKeyMapping {
	// Fields
	struct FKey Key; // Offset: 0x00 // Size: 0x18
	float HoldTime; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct CommonUI.UITag
// Size: 0x08 // Inherited bytes: 0x08
struct FUITag : FGameplayTag {
};

// Object Name: ScriptStruct CommonUI.UIActionTag
// Size: 0x08 // Inherited bytes: 0x08
struct FUIActionTag : FUITag {
};

// Object Name: ScriptStruct CommonUI.RichTextIconData
// Size: 0x50 // Inherited bytes: 0x08
struct FRichTextIconData : FTableRowBase {
	// Fields
	struct FText DisplayName; // Offset: 0x08 // Size: 0x18
	struct TSoftObjectPtr<UObject> ResourceObject; // Offset: 0x20 // Size: 0x28
	struct FVector2D ImageSize; // Offset: 0x48 // Size: 0x08
};

// Object Name: ScriptStruct CommonUI.CommonInputActionDataBase
// Size: 0x2b0 // Inherited bytes: 0x08
struct FCommonInputActionDataBase : FTableRowBase {
	// Fields
	struct FText DisplayName; // Offset: 0x08 // Size: 0x18
	struct FText HoldDisplayName; // Offset: 0x20 // Size: 0x18
	struct FCommonInputTypeInfo KeyboardInputTypeInfo; // Offset: 0x38 // Size: 0xb8
	struct FCommonInputTypeInfo DefaultGamepadInputTypeInfo; // Offset: 0xf0 // Size: 0xb8
	struct TMap<struct FName, struct FCommonInputTypeInfo> GamepadInputOverrides; // Offset: 0x1a8 // Size: 0x50
	struct FCommonInputTypeInfo TouchInputTypeInfo; // Offset: 0x1f8 // Size: 0xb8
};

// Object Name: ScriptStruct CommonUI.CommonInputTypeInfo
// Size: 0xb8 // Inherited bytes: 0x00
struct FCommonInputTypeInfo {
	// Fields
	struct FKey Key; // Offset: 0x00 // Size: 0x18
	enum class EInputActionState OverrrideState; // Offset: 0x18 // Size: 0x01
	bool bActionRequiresHold; // Offset: 0x19 // Size: 0x01
	char pad_0x1A[0x2]; // Offset: 0x1a // Size: 0x02
	float HoldTime; // Offset: 0x1c // Size: 0x04
	struct FSlateBrush OverrideBrush; // Offset: 0x20 // Size: 0x98
};

