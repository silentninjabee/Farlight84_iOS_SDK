#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass DefaultSolarLockSettings.DefaultSolarLockSettings_C
// Size: 0x78 // Inherited bytes: 0x78
struct UDefaultSolarLockSettings_C : USolarLockSettings {
};

