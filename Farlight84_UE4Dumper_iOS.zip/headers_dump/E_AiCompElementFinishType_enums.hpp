#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum E_AiCompElementFinishType.E_AiCompElementFinishType
enum class E_AiCompElementFinishType : uint8 {
	Success = 0,
	FilterChackFailed = 1,
	Timeout = 2,
	E MAX = 3
};

