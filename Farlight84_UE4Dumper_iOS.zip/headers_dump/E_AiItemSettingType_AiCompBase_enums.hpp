#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum E_AiItemSettingType_AiCompBase.E_AiItemSettingType_AiCompBase
enum class E_AiItemSettingType_AiCompBase : uint8 {
	None = 0,
	MedicKit = 1,
	SmallShieldBattery = 2,
	LargeShieldBattery = 3,
	RebirthCapsule = 4,
	SubmachingGunBullet = 5,
	RifleBullet = 6,
	SniperBullet = 7,
	ShotgunBullet = 8,
	NewEnumerator13 = 9,
	NewEnumerator14 = 10,
	E Ai Item Setting Type MAX = 11
};

