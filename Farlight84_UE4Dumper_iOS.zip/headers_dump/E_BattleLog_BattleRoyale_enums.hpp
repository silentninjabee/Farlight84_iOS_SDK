#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum E_BattleLog_BattleRoyale.E_BattleLog_BattleRoyale
enum class E_BattleLog_BattleRoyale : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator2 = 2,
	NewEnumerator3 = 3,
	NewEnumerator5 = 4,
	NewEnumerator6 = 5,
	NewEnumerator7 = 6,
	NewEnumerator8 = 7,
	E Battle Log MAX = 8
};

