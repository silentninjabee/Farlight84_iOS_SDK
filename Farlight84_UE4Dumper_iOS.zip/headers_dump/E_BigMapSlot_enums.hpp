#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum E_BigMapSlot.E_BigMapSlot
enum class E_BigMapSlot : uint8 {
	Panel_HuntGoal_Slot = 0,
	E MAX = 1
};

