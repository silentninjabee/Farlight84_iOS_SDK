#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum E_CommandTypeCommon.E_CommandTypeCommon
enum class E_CommandTypeCommon : uint8 {
	ChangeCharacter = 0,
	OpenDetailLog = 1,
	SetBackpack = 2,
	SetWeapon = 3,
	SpawnVehicle = 4,
	DrawingPoisonCircle = 5,
	ReCalculatePoisonCirclePointArray = 6,
	SetMapInfoComponentUseFakePoint = 7,
	EggAbility = 8,
	RandomKillOneAI = 9,
	SetAiComp = 10,
	ChangeAiCompTimeline = 11,
	ChangeAiCompWarmGame = 12,
	TransferCharacter = 13,
	DarkAreaTest = 14,
	NewEnumerator15 = 15,
	NewEnumerator16 = 16,
	NewEnumerator17 = 17,
	ApplayDamageToSelf = 18,
	NewEnumerator19 = 19,
	NewEnumerator20 = 20,
	NewEnumerator21 = 21,
	NewEnumerator22 = 22,
	NewEnumerator23 = 23,
	NewEnumerator24 = 24,
	NewEnumerator25 = 25,
	NewEnumerator26 = 26,
	ApplayShieldDamageToSelf = 27,
	E MAX = 28
};

