#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum E_FilterParameterType_AiCompBase.E_FilterParameterType_AiCompBase
enum class E_FilterParameterType_AiCompBase : uint8 {
	None = 0,
	MoreThan = 1,
	LessThan = 2,
	Equal = 3,
	NotEqual = 4,
	Contain = 5,
	NotContain = 6,
	Radius = 7,
	Target = 8,
	E Filter Parameter Type MAX = 9
};

