#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum E_GuidTargetType.E_GuidTargetType
enum class E_GuidTargetType : uint8 {
	Weapon = 0,
	Item = 1,
	Vehicle = 2,
	E MAX = 3
};

