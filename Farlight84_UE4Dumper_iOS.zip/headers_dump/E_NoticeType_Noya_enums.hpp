#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum E_NoticeType_Noya.E_NoticeType_Noya
enum class E_NoticeType_Noya : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	E Notice Type MAX = 2
};

