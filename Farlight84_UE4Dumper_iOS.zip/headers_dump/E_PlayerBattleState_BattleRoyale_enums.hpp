#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum E_PlayerBattleState_BattleRoyale.E_PlayerBattleState_BattleRoyale
enum class E_PlayerBattleState_BattleRoyale : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator3 = 2,
	E Player Battle State MAX = 3
};

