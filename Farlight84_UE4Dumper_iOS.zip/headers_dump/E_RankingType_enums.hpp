#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum E_RankingType.E_RankingType
enum class E_RankingType : uint8 {
	Division = 0,
	Country = 1,
	E MAX = 2
};

