#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum E_State_Btn.E_State_Btn
enum class E_State_Btn : uint8 {
	Normal = 0,
	hovered = 1,
	Pressed = 2,
	disabled = 3,
	E State MAX = 4
};

