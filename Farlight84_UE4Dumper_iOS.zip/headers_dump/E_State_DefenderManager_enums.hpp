#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum E_State_DefenderManager.E_State_DefenderManager
enum class E_State_DefenderManager : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator2 = 2,
	E State MAX = 3
};

