#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum E_Type_Team_Member.E_Type_Team_Member
enum class E_Type_Team_Member : uint8 {
	Member4 = 0,
	Member2 = 1,
	Member1 = 2,
	E Type Team MAX = 3
};

