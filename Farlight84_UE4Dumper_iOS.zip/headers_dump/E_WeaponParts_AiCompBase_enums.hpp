#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum E_WeaponParts_AiCompBase.E_WeaponParts_AiCompBase
enum class E_WeaponParts_AiCompBase : uint8 {
	None = 0,
	Muzzle = 1,
	Grip = 2,
	Clip = 3,
	Scope = 4,
	GunStock = 5,
	E Weapon Parts MAX = 6
};

