#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct EditableMesh.AdaptorPolygon2Group
// Size: 0x48 // Inherited bytes: 0x00
struct FAdaptorPolygon2Group {
	// Fields
	uint32_t RenderingSectionIndex; // Offset: 0x00 // Size: 0x04
	int32_t MaterialIndex; // Offset: 0x04 // Size: 0x04
	int32_t MaxTriangles; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x3c]; // Offset: 0x0c // Size: 0x3c
};

// Object Name: ScriptStruct EditableMesh.AdaptorPolygon
// Size: 0x18 // Inherited bytes: 0x00
struct FAdaptorPolygon {
	// Fields
	struct FPolygonGroupID PolygonGroupID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<struct FAdaptorTriangleID> TriangulatedPolygonTriangleIndices; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct EditableMesh.AdaptorTriangleID
// Size: 0x04 // Inherited bytes: 0x04
struct FAdaptorTriangleID : FElementID {
};

// Object Name: ScriptStruct EditableMesh.PolygonGroupForPolygon
// Size: 0x08 // Inherited bytes: 0x00
struct FPolygonGroupForPolygon {
	// Fields
	struct FPolygonID PolygonID; // Offset: 0x00 // Size: 0x04
	struct FPolygonGroupID PolygonGroupID; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct EditableMesh.PolygonGroupToCreate
// Size: 0x18 // Inherited bytes: 0x00
struct FPolygonGroupToCreate {
	// Fields
	struct FMeshElementAttributeList PolygonGroupAttributes; // Offset: 0x00 // Size: 0x10
	struct FPolygonGroupID OriginalPolygonGroupID; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct EditableMesh.MeshElementAttributeList
// Size: 0x10 // Inherited bytes: 0x00
struct FMeshElementAttributeList {
	// Fields
	struct TArray<struct FMeshElementAttributeData> Attributes; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct EditableMesh.MeshElementAttributeData
// Size: 0x60 // Inherited bytes: 0x00
struct FMeshElementAttributeData {
	// Fields
	struct FName AttributeName; // Offset: 0x00 // Size: 0x08
	int32_t AttributeIndex; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct FMeshElementAttributeValue AttributeValue; // Offset: 0x10 // Size: 0x50
};

// Object Name: ScriptStruct EditableMesh.MeshElementAttributeValue
// Size: 0x50 // Inherited bytes: 0x00
struct FMeshElementAttributeValue {
	// Fields
	char pad_0x0[0x50]; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct EditableMesh.VertexToMove
// Size: 0x10 // Inherited bytes: 0x00
struct FVertexToMove {
	// Fields
	struct FVertexID VertexID; // Offset: 0x00 // Size: 0x04
	struct FVector NewVertexPosition; // Offset: 0x04 // Size: 0x0c
};

// Object Name: ScriptStruct EditableMesh.ChangeVertexInstancesForPolygon
// Size: 0x28 // Inherited bytes: 0x00
struct FChangeVertexInstancesForPolygon {
	// Fields
	struct FPolygonID PolygonID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<struct FVertexIndexAndInstanceID> PerimeterVertexIndicesAndInstanceIDs; // Offset: 0x08 // Size: 0x10
	struct TArray<struct FVertexInstancesForPolygonHole> VertexIndicesAndInstanceIDsForEachHole; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct EditableMesh.VertexInstancesForPolygonHole
// Size: 0x10 // Inherited bytes: 0x00
struct FVertexInstancesForPolygonHole {
	// Fields
	struct TArray<struct FVertexIndexAndInstanceID> VertexIndicesAndInstanceIDs; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct EditableMesh.VertexIndexAndInstanceID
// Size: 0x08 // Inherited bytes: 0x00
struct FVertexIndexAndInstanceID {
	// Fields
	int32_t ContourIndex; // Offset: 0x00 // Size: 0x04
	struct FVertexInstanceID VertexInstanceID; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct EditableMesh.VertexAttributesForPolygon
// Size: 0x28 // Inherited bytes: 0x00
struct FVertexAttributesForPolygon {
	// Fields
	struct FPolygonID PolygonID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<struct FMeshElementAttributeList> PerimeterVertexAttributeLists; // Offset: 0x08 // Size: 0x10
	struct TArray<struct FVertexAttributesForPolygonHole> VertexAttributeListsForEachHole; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct EditableMesh.VertexAttributesForPolygonHole
// Size: 0x10 // Inherited bytes: 0x00
struct FVertexAttributesForPolygonHole {
	// Fields
	struct TArray<struct FMeshElementAttributeList> VertexAttributeList; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct EditableMesh.AttributesForEdge
// Size: 0x18 // Inherited bytes: 0x00
struct FAttributesForEdge {
	// Fields
	struct FEdgeID EdgeID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FMeshElementAttributeList EdgeAttributes; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct EditableMesh.AttributesForVertexInstance
// Size: 0x18 // Inherited bytes: 0x00
struct FAttributesForVertexInstance {
	// Fields
	struct FVertexInstanceID VertexInstanceID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FMeshElementAttributeList VertexInstanceAttributes; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct EditableMesh.AttributesForVertex
// Size: 0x18 // Inherited bytes: 0x00
struct FAttributesForVertex {
	// Fields
	struct FVertexID VertexID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FMeshElementAttributeList VertexAttributes; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct EditableMesh.PolygonToSplit
// Size: 0x18 // Inherited bytes: 0x00
struct FPolygonToSplit {
	// Fields
	struct FPolygonID PolygonID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<struct FVertexPair> VertexPairsToSplitAt; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct EditableMesh.VertexPair
// Size: 0x08 // Inherited bytes: 0x00
struct FVertexPair {
	// Fields
	struct FVertexID VertexID0; // Offset: 0x00 // Size: 0x04
	struct FVertexID VertexID1; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct EditableMesh.PolygonToCreate
// Size: 0x20 // Inherited bytes: 0x00
struct FPolygonToCreate {
	// Fields
	struct FPolygonGroupID PolygonGroupID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<struct FVertexAndAttributes> PerimeterVertices; // Offset: 0x08 // Size: 0x10
	struct FPolygonID OriginalPolygonID; // Offset: 0x18 // Size: 0x04
	enum class EPolygonEdgeHardness PolygonEdgeHardness; // Offset: 0x1c // Size: 0x01
	char pad_0x1D[0x3]; // Offset: 0x1d // Size: 0x03
};

// Object Name: ScriptStruct EditableMesh.VertexAndAttributes
// Size: 0x18 // Inherited bytes: 0x00
struct FVertexAndAttributes {
	// Fields
	struct FVertexInstanceID VertexInstanceID; // Offset: 0x00 // Size: 0x04
	struct FVertexID VertexID; // Offset: 0x04 // Size: 0x04
	struct FMeshElementAttributeList PolygonVertexAttributes; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct EditableMesh.EdgeToCreate
// Size: 0x20 // Inherited bytes: 0x00
struct FEdgeToCreate {
	// Fields
	struct FVertexID VertexID0; // Offset: 0x00 // Size: 0x04
	struct FVertexID VertexID1; // Offset: 0x04 // Size: 0x04
	struct FMeshElementAttributeList EdgeAttributes; // Offset: 0x08 // Size: 0x10
	struct FEdgeID OriginalEdgeID; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct EditableMesh.VertexInstanceToCreate
// Size: 0x20 // Inherited bytes: 0x00
struct FVertexInstanceToCreate {
	// Fields
	struct FVertexID VertexID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FMeshElementAttributeList VertexInstanceAttributes; // Offset: 0x08 // Size: 0x10
	struct FVertexInstanceID OriginalVertexInstanceID; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct EditableMesh.VertexToCreate
// Size: 0x18 // Inherited bytes: 0x00
struct FVertexToCreate {
	// Fields
	struct FMeshElementAttributeList VertexAttributes; // Offset: 0x00 // Size: 0x10
	struct FVertexID OriginalVertexID; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct EditableMesh.SubdivisionLimitData
// Size: 0x30 // Inherited bytes: 0x00
struct FSubdivisionLimitData {
	// Fields
	struct TArray<struct FVector> VertexPositions; // Offset: 0x00 // Size: 0x10
	struct TArray<struct FSubdivisionLimitSection> Sections; // Offset: 0x10 // Size: 0x10
	struct TArray<struct FSubdividedWireEdge> SubdividedWireEdges; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct EditableMesh.SubdividedWireEdge
// Size: 0x0c // Inherited bytes: 0x00
struct FSubdividedWireEdge {
	// Fields
	int32_t EdgeVertex0PositionIndex; // Offset: 0x00 // Size: 0x04
	int32_t EdgeVertex1PositionIndex; // Offset: 0x04 // Size: 0x04
	char pad_0x8[0x4]; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct EditableMesh.SubdivisionLimitSection
// Size: 0x10 // Inherited bytes: 0x00
struct FSubdivisionLimitSection {
	// Fields
	struct TArray<struct FSubdividedQuad> SubdividedQuads; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct EditableMesh.SubdividedQuad
// Size: 0xd0 // Inherited bytes: 0x00
struct FSubdividedQuad {
	// Fields
	struct FSubdividedQuadVertex QuadVertex0; // Offset: 0x00 // Size: 0x34
	struct FSubdividedQuadVertex QuadVertex1; // Offset: 0x34 // Size: 0x34
	struct FSubdividedQuadVertex QuadVertex2; // Offset: 0x68 // Size: 0x34
	struct FSubdividedQuadVertex QuadVertex3; // Offset: 0x9c // Size: 0x34
};

// Object Name: ScriptStruct EditableMesh.SubdividedQuadVertex
// Size: 0x34 // Inherited bytes: 0x00
struct FSubdividedQuadVertex {
	// Fields
	int32_t VertexPositionIndex; // Offset: 0x00 // Size: 0x04
	struct FVector2D TextureCoordinate0; // Offset: 0x04 // Size: 0x08
	struct FVector2D TextureCoordinate1; // Offset: 0x0c // Size: 0x08
	struct FColor VertexColor; // Offset: 0x14 // Size: 0x04
	struct FVector VertexNormal; // Offset: 0x18 // Size: 0x0c
	struct FVector VertexTangent; // Offset: 0x24 // Size: 0x0c
	float VertexBinormalSign; // Offset: 0x30 // Size: 0x04
};

// Object Name: ScriptStruct EditableMesh.RenderingPolygonGroup
// Size: 0x48 // Inherited bytes: 0x00
struct FRenderingPolygonGroup {
	// Fields
	uint32_t RenderingSectionIndex; // Offset: 0x00 // Size: 0x04
	int32_t MaterialIndex; // Offset: 0x04 // Size: 0x04
	int32_t MaxTriangles; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x3c]; // Offset: 0x0c // Size: 0x3c
};

// Object Name: ScriptStruct EditableMesh.RenderingPolygon
// Size: 0x18 // Inherited bytes: 0x00
struct FRenderingPolygon {
	// Fields
	struct FPolygonGroupID PolygonGroupID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<struct FTriangleID> TriangulatedPolygonTriangleIndices; // Offset: 0x08 // Size: 0x10
};

