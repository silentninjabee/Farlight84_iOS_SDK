#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass ExcludeWaterNavQueryFilter_LongRange.ExcludeWaterNavQueryFilter_LongRange_C
// Size: 0x48 // Inherited bytes: 0x48
struct UExcludeWaterNavQueryFilter_LongRange_C : USolarNavQueryFilter {
};

