#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class EyeTracker.EyeTrackerFunctionLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct UEyeTrackerFunctionLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function EyeTracker.EyeTrackerFunctionLibrary.SetEyeTrackedPlayer
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetEyeTrackedPlayer(struct APlayerController* PlayerController); // Offset: 0x1040fc5dc // Return & Params: Num(1) Size(0x8)

	// Object Name: Function EyeTracker.EyeTrackerFunctionLibrary.IsStereoGazeDataAvailable
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	bool IsStereoGazeDataAvailable(); // Offset: 0x1040fc778 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function EyeTracker.EyeTrackerFunctionLibrary.IsEyeTrackerConnected
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	bool IsEyeTrackerConnected(); // Offset: 0x1040fc7ac // Return & Params: Num(1) Size(0x1)

	// Object Name: Function EyeTracker.EyeTrackerFunctionLibrary.GetStereoGazeData
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool GetStereoGazeData(struct FEyeTrackerStereoGazeData& OutGazeData); // Offset: 0x1040fc650 // Return & Params: Num(2) Size(0x41)

	// Object Name: Function EyeTracker.EyeTrackerFunctionLibrary.GetGazeData
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	bool GetGazeData(struct FEyeTrackerGazeData& OutGazeData); // Offset: 0x1040fc6e4 // Return & Params: Num(2) Size(0x29)
};

