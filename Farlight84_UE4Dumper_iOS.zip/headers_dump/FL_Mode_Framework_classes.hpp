#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass FL_Mode_Framework.FL_Mode_Framework_C
// Size: 0x28 // Inherited bytes: 0x28
struct UFL_Mode_Framework_C : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function FL_Mode_Framework.FL_Mode_Framework_C.[s]SetCanBeSpectate
	// Flags: [Static|Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void [s]SetCanBeSpectate(struct ASolarPlayerState* Target, bool Can be Spectate, struct UObject* __WorldContext); // Offset: 0x102f67d18 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function FL_Mode_Framework.FL_Mode_Framework_C.[s]SetCharacterSkill
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void [s]SetCharacterSkill(struct ASolarCharacter* Character, struct FS_SkillState& SkillConfig, struct UObject* __WorldContext); // Offset: 0x102f67d18 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function FL_Mode_Framework.FL_Mode_Framework_C.[a]GetCharacterIDBySkinID
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void [a]GetCharacterIDBySkinID(int32_t SkinId, struct UObject* __WorldContext, int32_t& CharacterId); // Offset: 0x102f67d18 // Return & Params: Num(3) Size(0x14)

	// Object Name: Function FL_Mode_Framework.FL_Mode_Framework_C.SetSkillState
	// Flags: [Static|Public|BlueprintCallable|BlueprintEvent]
	void SetSkillState(struct ASolarCharacter* Character, enum class E_CharacterSkillType SkillType, enum class ERoleSkillOperation NewSate, struct UObject* __WorldContext); // Offset: 0x102f67d18 // Return & Params: Num(4) Size(0x18)

	// Object Name: Function FL_Mode_Framework.FL_Mode_Framework_C.HasTeammatesAI
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	bool HasTeammatesAI(struct FString Side, struct UObject* __WorldContext); // Offset: 0x102f67d18 // Return & Params: Num(3) Size(0x19)

	// Object Name: Function FL_Mode_Framework.FL_Mode_Framework_C.Set Skill State for Everybody
	// Flags: [Static|Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void Set Skill State for Everybody(enum class E_CharacterSkillType SkillType, enum class ERoleSkillOperation NewSate, struct UObject* __WorldContext); // Offset: 0x102f67d18 // Return & Params: Num(3) Size(0x10)

	// Object Name: Function FL_Mode_Framework.FL_Mode_Framework_C.SetWeaponPartByPartID
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void SetWeaponPartByPartID(struct ASolarWeapon* TargetWeapon, int32_t PartID, struct UObject* __WorldContext, bool& Success); // Offset: 0x102f67d18 // Return & Params: Num(4) Size(0x19)

	// Object Name: Function FL_Mode_Framework.FL_Mode_Framework_C.Distribute Experience to Side
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void Distribute Experience to Side(int32_t InExp, enum class EExpBehaviorType InType, struct TArray<struct FString>& , struct UObject* __WorldContext); // Offset: 0x102f67d18 // Return & Params: Num(4) Size(0x20)

	// Object Name: Function FL_Mode_Framework.FL_Mode_Framework_C.GetRandomCharacter
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void GetRandomCharacter(struct UObject* __WorldContext, int32_t& Output); // Offset: 0x102f67d18 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function FL_Mode_Framework.FL_Mode_Framework_C.RandomIntInRange
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	int32_t RandomIntInRange(struct FInt32Range Range, struct UObject* __WorldContext); // Offset: 0x102f67d18 // Return & Params: Num(3) Size(0x1c)

	// Object Name: Function FL_Mode_Framework.FL_Mode_Framework_C.GetLocText
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	struct FString GetLocText(struct FSolarTablesLocalText& InData, struct UObject* __WorldContext); // Offset: 0x102f67d18 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function FL_Mode_Framework.FL_Mode_Framework_C.GetCharacterList
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void GetCharacterList(struct UObject* __WorldContext, struct TArray<int32_t>& OutKeys); // Offset: 0x102f67d18 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function FL_Mode_Framework.FL_Mode_Framework_C.GetBackpackList
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void GetBackpackList(struct UObject* __WorldContext, struct TArray<int32_t>& OutKeys); // Offset: 0x102f67d18 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function FL_Mode_Framework.FL_Mode_Framework_C.GetTrailList
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void GetTrailList(struct UObject* __WorldContext, struct TArray<int32_t>& OutKeys); // Offset: 0x102f67d18 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function FL_Mode_Framework.FL_Mode_Framework_C.GetSkinList
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void GetSkinList(struct UObject* __WorldContext, struct TArray<int32_t>& OutKeys); // Offset: 0x102f67d18 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function FL_Mode_Framework.FL_Mode_Framework_C.GetTrailData
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	struct FSolarTablesData_BackpackTrailProperty GetTrailData(int32_t Key, struct UObject* __WorldContext); // Offset: 0x102f67d18 // Return & Params: Num(3) Size(0xc8)

	// Object Name: Function FL_Mode_Framework.FL_Mode_Framework_C.GetBackpackData
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	struct FSolarTablesData_BackpackProperty GetBackpackData(int32_t Key, struct UObject* __WorldContext); // Offset: 0x102f67d18 // Return & Params: Num(3) Size(0xb8)

	// Object Name: Function FL_Mode_Framework.FL_Mode_Framework_C.GetCharacterData
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	struct FSolarTablesData_UnitCharacter GetCharacterData(int32_t Key, struct UObject* __WorldContext); // Offset: 0x102f67d18 // Return & Params: Num(3) Size(0x178)

	// Object Name: Function FL_Mode_Framework.FL_Mode_Framework_C.GetTextureByPath
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	struct UObject* GetTextureByPath(struct FString Path, struct UObject* __WorldContext); // Offset: 0x102f67d18 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function FL_Mode_Framework.FL_Mode_Framework_C.GetSkinData
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	struct FSolarTablesData_Skin GetSkinData(int32_t Key, struct UObject* __WorldContext); // Offset: 0x102f67d18 // Return & Params: Num(3) Size(0xe8)
};

