#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass FX_BP_BombRange.FX_BP_BombRange_C
// Size: 0x290 // Inherited bytes: 0x280
struct AFX_BP_BombRange_C : ASolarBombActor {
	// Fields
	struct UStaticMeshComponent* FX_GuideLine; // Offset: 0x280 // Size: 0x08
	struct USceneComponent* PositionAdjiust; // Offset: 0x288 // Size: 0x08
};

