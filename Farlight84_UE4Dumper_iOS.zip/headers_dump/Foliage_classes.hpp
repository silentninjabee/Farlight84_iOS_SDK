#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class Foliage.FoliageInstancedStaticMeshComponent
// Size: 0x7f0 // Inherited bytes: 0x7c0
struct UFoliageInstancedStaticMeshComponent : UHierarchicalInstancedStaticMeshComponent {
	// Fields
	struct FMulticastInlineDelegate OnInstanceTakePointDamage; // Offset: 0x7b8 // Size: 0x10
	struct FMulticastInlineDelegate OnInstanceTakeRadialDamage; // Offset: 0x7c8 // Size: 0x10
	struct FGuid GenerationGuid; // Offset: 0x7d8 // Size: 0x10
};

// Object Name: Class Foliage.FoliageStatistics
// Size: 0x28 // Inherited bytes: 0x28
struct UFoliageStatistics : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function Foliage.FoliageStatistics.FoliageOverlappingSphereCount
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	int32_t FoliageOverlappingSphereCount(struct UObject* WorldContextObject, struct UStaticMesh* StaticMesh, struct FVector CenterPosition, float Radius); // Offset: 0x103c40738 // Return & Params: Num(5) Size(0x24)

	// Object Name: Function Foliage.FoliageStatistics.FoliageOverlappingBoxCount
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	int32_t FoliageOverlappingBoxCount(struct UObject* WorldContextObject, struct UStaticMesh* StaticMesh, struct FBox Box); // Offset: 0x103c40604 // Return & Params: Num(4) Size(0x30)
};

// Object Name: Class Foliage.FoliageType
// Size: 0x398 // Inherited bytes: 0x28
struct UFoliageType : UObject {
	// Fields
	struct FGuid UpdateGuid; // Offset: 0x28 // Size: 0x10
	float Density; // Offset: 0x38 // Size: 0x04
	float DensityAdjustmentFactor; // Offset: 0x3c // Size: 0x04
	float Radius; // Offset: 0x40 // Size: 0x04
	bool bSingleInstanceModeOverrideRadius; // Offset: 0x44 // Size: 0x01
	char pad_0x45[0x3]; // Offset: 0x45 // Size: 0x03
	float SingleInstanceModeRadius; // Offset: 0x48 // Size: 0x04
	enum class EFoliageScaling Scaling; // Offset: 0x4c // Size: 0x01
	char pad_0x4D[0x3]; // Offset: 0x4d // Size: 0x03
	struct FFloatInterval ScaleX; // Offset: 0x50 // Size: 0x08
	struct FFloatInterval ScaleY; // Offset: 0x58 // Size: 0x08
	struct FFloatInterval ScaleZ; // Offset: 0x60 // Size: 0x08
	struct FFoliageVertexColorChannelMask VertexColorMaskByChannel[0x4]; // Offset: 0x68 // Size: 0x30
	enum class FoliageVertexColorMask VertexColorMask; // Offset: 0x98 // Size: 0x01
	char pad_0x99[0x3]; // Offset: 0x99 // Size: 0x03
	float VertexColorMaskThreshold; // Offset: 0x9c // Size: 0x04
	char VertexColorMaskInvert : 1; // Offset: 0xa0 // Size: 0x01
	char pad_0xA0_1 : 7; // Offset: 0xa0 // Size: 0x01
	char pad_0xA1[0x3]; // Offset: 0xa1 // Size: 0x03
	struct FFloatInterval ZOffset; // Offset: 0xa4 // Size: 0x08
	char AlignToNormal : 1; // Offset: 0xac // Size: 0x01
	char pad_0xAC_1 : 7; // Offset: 0xac // Size: 0x01
	char pad_0xAD[0x3]; // Offset: 0xad // Size: 0x03
	float AlignMaxAngle; // Offset: 0xb0 // Size: 0x04
	char RandomYaw : 1; // Offset: 0xb4 // Size: 0x01
	char pad_0xB4_1 : 7; // Offset: 0xb4 // Size: 0x01
	char pad_0xB5[0x3]; // Offset: 0xb5 // Size: 0x03
	float RandomPitchAngle; // Offset: 0xb8 // Size: 0x04
	struct FFloatInterval GroundSlopeAngle; // Offset: 0xbc // Size: 0x08
	struct FFloatInterval Height; // Offset: 0xc4 // Size: 0x08
	char pad_0xCC[0x4]; // Offset: 0xcc // Size: 0x04
	struct TArray<struct FName> LandscapeLayers; // Offset: 0xd0 // Size: 0x10
	float MinimumLayerWeight; // Offset: 0xe0 // Size: 0x04
	char pad_0xE4[0x4]; // Offset: 0xe4 // Size: 0x04
	struct TArray<struct FName> ExclusionLandscapeLayers; // Offset: 0xe8 // Size: 0x10
	float MinimumExclusionLayerWeight; // Offset: 0xf8 // Size: 0x04
	struct FName LandscapeLayer; // Offset: 0xfc // Size: 0x08
	char CollisionWithWorld : 1; // Offset: 0x104 // Size: 0x01
	char pad_0x104_1 : 7; // Offset: 0x104 // Size: 0x01
	char pad_0x105[0x3]; // Offset: 0x105 // Size: 0x03
	struct FVector CollisionScale; // Offset: 0x108 // Size: 0x0c
	struct FBoxSphereBounds MeshBounds; // Offset: 0x114 // Size: 0x1c
	struct FVector LowBoundOriginRadius; // Offset: 0x130 // Size: 0x0c
	enum class EComponentMobility Mobility; // Offset: 0x13c // Size: 0x01
	char pad_0x13D[0x3]; // Offset: 0x13d // Size: 0x03
	struct FInt32Interval CullDistance; // Offset: 0x140 // Size: 0x08
	char bEnableStaticLighting : 1; // Offset: 0x148 // Size: 0x01
	char CastShadow : 1; // Offset: 0x148 // Size: 0x01
	char CastFarShadow : 1; // Offset: 0x148 // Size: 0x01
	char bAffectDynamicIndirectLighting : 1; // Offset: 0x148 // Size: 0x01
	char bAffectDistanceFieldLighting : 1; // Offset: 0x148 // Size: 0x01
	char bCastDynamicShadow : 1; // Offset: 0x148 // Size: 0x01
	char bCastStaticShadow : 1; // Offset: 0x148 // Size: 0x01
	char bCastShadowAsTwoSided : 1; // Offset: 0x148 // Size: 0x01
	char bReceivesDecals : 1; // Offset: 0x149 // Size: 0x01
	char bOverrideLightMapRes : 1; // Offset: 0x149 // Size: 0x01
	char pad_0x149_2 : 6; // Offset: 0x149 // Size: 0x01
	char pad_0x14A[0x2]; // Offset: 0x14a // Size: 0x02
	int32_t OverriddenLightMapRes; // Offset: 0x14c // Size: 0x04
	char bMinimizeLightmapRes : 1; // Offset: 0x150 // Size: 0x01
	char bForceGenLightmap : 1; // Offset: 0x150 // Size: 0x01
	char pad_0x150_2 : 6; // Offset: 0x150 // Size: 0x01
	enum class ELightmapType LightmapType; // Offset: 0x151 // Size: 0x01
	char bUseAsOccluder : 1; // Offset: 0x152 // Size: 0x01
	char pad_0x152_1 : 7; // Offset: 0x152 // Size: 0x01
	char pad_0x153[0x5]; // Offset: 0x153 // Size: 0x05
	struct FBodyInstance BodyInstance; // Offset: 0x158 // Size: 0x130
	enum class EHasCustomNavigableGeometry CustomNavigableGeometry; // Offset: 0x288 // Size: 0x01
	struct FLightingChannels LightingChannels; // Offset: 0x289 // Size: 0x01
	char bRenderCustomDepth : 1; // Offset: 0x28a // Size: 0x01
	char pad_0x28A_1 : 7; // Offset: 0x28a // Size: 0x01
	char pad_0x28B[0x1]; // Offset: 0x28b // Size: 0x01
	int32_t CustomDepthStencilValue; // Offset: 0x28c // Size: 0x04
	int32_t TranslucencySortPriority; // Offset: 0x290 // Size: 0x04
	char pad_0x294[0x4]; // Offset: 0x294 // Size: 0x04
	struct TArray<struct FSelectInstanceInfo> SelectInstancesData; // Offset: 0x298 // Size: 0x10
	char pad_0x2A8[0x8]; // Offset: 0x2a8 // Size: 0x08
	float CollisionRadius; // Offset: 0x2b0 // Size: 0x04
	float ShadeRadius; // Offset: 0x2b4 // Size: 0x04
	int32_t NumSteps; // Offset: 0x2b8 // Size: 0x04
	float InitialSeedDensity; // Offset: 0x2bc // Size: 0x04
	float AverageSpreadDistance; // Offset: 0x2c0 // Size: 0x04
	float SpreadVariance; // Offset: 0x2c4 // Size: 0x04
	int32_t SeedsPerStep; // Offset: 0x2c8 // Size: 0x04
	int32_t DistributionSeed; // Offset: 0x2cc // Size: 0x04
	float MaxInitialSeedOffset; // Offset: 0x2d0 // Size: 0x04
	bool bCanGrowInShade; // Offset: 0x2d4 // Size: 0x01
	bool bSpawnsInShade; // Offset: 0x2d5 // Size: 0x01
	char pad_0x2D6[0x2]; // Offset: 0x2d6 // Size: 0x02
	float MaxInitialAge; // Offset: 0x2d8 // Size: 0x04
	float MaxAge; // Offset: 0x2dc // Size: 0x04
	float OverlapPriority; // Offset: 0x2e0 // Size: 0x04
	struct FFloatInterval ProceduralScale; // Offset: 0x2e4 // Size: 0x08
	char pad_0x2EC[0x4]; // Offset: 0x2ec // Size: 0x04
	struct FRuntimeFloatCurve ScaleCurve; // Offset: 0x2f0 // Size: 0x88
	int32_t ChangeCount; // Offset: 0x378 // Size: 0x04
	char ReapplyDensity : 1; // Offset: 0x37c // Size: 0x01
	char ReapplyRadius : 1; // Offset: 0x37c // Size: 0x01
	char ReapplyAlignToNormal : 1; // Offset: 0x37c // Size: 0x01
	char ReapplyRandomYaw : 1; // Offset: 0x37c // Size: 0x01
	char ReapplyScaling : 1; // Offset: 0x37c // Size: 0x01
	char ReapplyScaleX : 1; // Offset: 0x37c // Size: 0x01
	char ReapplyScaleY : 1; // Offset: 0x37c // Size: 0x01
	char ReapplyScaleZ : 1; // Offset: 0x37c // Size: 0x01
	char ReapplyRandomPitchAngle : 1; // Offset: 0x37d // Size: 0x01
	char ReapplyGroundSlope : 1; // Offset: 0x37d // Size: 0x01
	char ReapplyHeight : 1; // Offset: 0x37d // Size: 0x01
	char ReapplyLandscapeLayers : 1; // Offset: 0x37d // Size: 0x01
	char ReapplyZOffset : 1; // Offset: 0x37d // Size: 0x01
	char ReapplyCollisionWithWorld : 1; // Offset: 0x37d // Size: 0x01
	char ReapplyVertexColorMask : 1; // Offset: 0x37d // Size: 0x01
	char bEnableDensityScaling : 1; // Offset: 0x37d // Size: 0x01
	char pad_0x37E[0x2]; // Offset: 0x37e // Size: 0x02
	struct TArray<struct URuntimeVirtualTexture*> RuntimeVirtualTextures; // Offset: 0x380 // Size: 0x10
	int32_t VirtualTextureCullMips; // Offset: 0x390 // Size: 0x04
	enum class ERuntimeVirtualTextureMainPassType VirtualTextureRenderPassType; // Offset: 0x394 // Size: 0x01
	char pad_0x395[0x3]; // Offset: 0x395 // Size: 0x03
};

// Object Name: Class Foliage.FoliageType_Actor
// Size: 0x3a8 // Inherited bytes: 0x398
struct UFoliageType_Actor : UFoliageType {
	// Fields
	struct AActor* ActorClass; // Offset: 0x398 // Size: 0x08
	bool bShouldAttachToBaseComponent; // Offset: 0x3a0 // Size: 0x01
	char pad_0x3A1[0x7]; // Offset: 0x3a1 // Size: 0x07
};

// Object Name: Class Foliage.FoliageType_InstancedStaticMesh
// Size: 0x3b8 // Inherited bytes: 0x398
struct UFoliageType_InstancedStaticMesh : UFoliageType {
	// Fields
	struct UStaticMesh* Mesh; // Offset: 0x398 // Size: 0x08
	struct TArray<struct UMaterialInterface*> OverrideMaterials; // Offset: 0x3a0 // Size: 0x10
	struct UFoliageInstancedStaticMeshComponent* ComponentClass; // Offset: 0x3b0 // Size: 0x08
};

// Object Name: Class Foliage.InstancedFoliageActor
// Size: 0x278 // Inherited bytes: 0x228
struct AInstancedFoliageActor : AActor {
	// Fields
	char pad_0x228[0x50]; // Offset: 0x228 // Size: 0x50
};

// Object Name: Class Foliage.InteractiveFoliageActor
// Size: 0x298 // Inherited bytes: 0x238
struct AInteractiveFoliageActor : AStaticMeshActor {
	// Fields
	struct UCapsuleComponent* CapsuleComponent; // Offset: 0x238 // Size: 0x08
	struct FVector TouchingActorEntryPosition; // Offset: 0x240 // Size: 0x0c
	struct FVector FoliageVelocity; // Offset: 0x24c // Size: 0x0c
	struct FVector FoliageForce; // Offset: 0x258 // Size: 0x0c
	struct FVector FoliagePosition; // Offset: 0x264 // Size: 0x0c
	float FoliageDamageImpulseScale; // Offset: 0x270 // Size: 0x04
	float FoliageTouchImpulseScale; // Offset: 0x274 // Size: 0x04
	float FoliageStiffness; // Offset: 0x278 // Size: 0x04
	float FoliageStiffnessQuadratic; // Offset: 0x27c // Size: 0x04
	float FoliageDamping; // Offset: 0x280 // Size: 0x04
	float MaxDamageImpulse; // Offset: 0x284 // Size: 0x04
	float MaxTouchImpulse; // Offset: 0x288 // Size: 0x04
	float MaxForce; // Offset: 0x28c // Size: 0x04
	float Mass; // Offset: 0x290 // Size: 0x04
	char pad_0x294[0x4]; // Offset: 0x294 // Size: 0x04

	// Functions

	// Object Name: Function Foliage.InteractiveFoliageActor.CapsuleTouched
	// Flags: [Final|Native|Protected|HasOutParms]
	void CapsuleTouched(struct UPrimitiveComponent* OverlappedComp, struct AActor* Other, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& OverlapInfo); // Offset: 0x103c41ab4 // Return & Params: Num(6) Size(0xa8)
};

// Object Name: Class Foliage.InteractiveFoliageComponent
// Size: 0x630 // Inherited bytes: 0x620
struct UInteractiveFoliageComponent : UStaticMeshComponent {
	// Fields
	char pad_0x620[0x10]; // Offset: 0x620 // Size: 0x10
};

// Object Name: Class Foliage.ProceduralFoliageBlockingVolume
// Size: 0x268 // Inherited bytes: 0x260
struct AProceduralFoliageBlockingVolume : AVolume {
	// Fields
	struct AProceduralFoliageVolume* ProceduralFoliageVolume; // Offset: 0x260 // Size: 0x08
};

// Object Name: Class Foliage.ProceduralFoliageComponent
// Size: 0xd8 // Inherited bytes: 0xb0
struct UProceduralFoliageComponent : UActorComponent {
	// Fields
	struct UProceduralFoliageSpawner* FoliageSpawner; // Offset: 0xb0 // Size: 0x08
	float TileOverlap; // Offset: 0xb8 // Size: 0x04
	char pad_0xBC[0x4]; // Offset: 0xbc // Size: 0x04
	struct AVolume* SpawningVolume; // Offset: 0xc0 // Size: 0x08
	struct FGuid ProceduralGuid; // Offset: 0xc8 // Size: 0x10
};

// Object Name: Class Foliage.ProceduralFoliageSpawner
// Size: 0x68 // Inherited bytes: 0x28
struct UProceduralFoliageSpawner : UObject {
	// Fields
	int32_t RandomSeed; // Offset: 0x28 // Size: 0x04
	float TileSize; // Offset: 0x2c // Size: 0x04
	int32_t NumUniqueTiles; // Offset: 0x30 // Size: 0x04
	float MinimumQuadTreeSize; // Offset: 0x34 // Size: 0x04
	char pad_0x38[0x8]; // Offset: 0x38 // Size: 0x08
	struct TArray<struct FFoliageTypeObject> FoliageTypes; // Offset: 0x40 // Size: 0x10
	char pad_0x50[0x18]; // Offset: 0x50 // Size: 0x18

	// Functions

	// Object Name: Function Foliage.ProceduralFoliageSpawner.Simulate
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Simulate(int32_t NumSteps); // Offset: 0x103c42878 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class Foliage.ProceduralFoliageTile
// Size: 0x158 // Inherited bytes: 0x28
struct UProceduralFoliageTile : UObject {
	// Fields
	struct UProceduralFoliageSpawner* FoliageSpawner; // Offset: 0x28 // Size: 0x08
	char pad_0x30[0xa0]; // Offset: 0x30 // Size: 0xa0
	struct TArray<struct FProceduralFoliageInstance> InstancesArray; // Offset: 0xd0 // Size: 0x10
	char pad_0xE0[0x78]; // Offset: 0xe0 // Size: 0x78
};

// Object Name: Class Foliage.ProceduralFoliageVolume
// Size: 0x268 // Inherited bytes: 0x260
struct AProceduralFoliageVolume : AVolume {
	// Fields
	struct UProceduralFoliageComponent* ProceduralComponent; // Offset: 0x260 // Size: 0x08
};

