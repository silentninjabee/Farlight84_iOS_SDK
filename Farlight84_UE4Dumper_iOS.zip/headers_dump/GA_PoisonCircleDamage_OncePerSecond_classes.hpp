#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass GA_PoisonCircleDamage_OncePerSecond.GA_PoisonCircleDamage_OncePerSecond_C
// Size: 0x40c // Inherited bytes: 0x400
struct UGA_PoisonCircleDamage_OncePerSecond_C : UGameplayAbility {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x400 // Size: 0x08
	float TimeInterval; // Offset: 0x408 // Size: 0x04

	// Functions

	// Object Name: Function GA_PoisonCircleDamage_OncePerSecond.GA_PoisonCircleDamage_OncePerSecond_C.ApplyPoisionDamage
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void ApplyPoisionDamage(struct APawn* HitPawn); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function GA_PoisonCircleDamage_OncePerSecond.GA_PoisonCircleDamage_OncePerSecond_C.OnFinished_458D02164F7130F5939345BFF276C957
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnFinished_458D02164F7130F5939345BFF276C957(int32_t ActionNumber); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function GA_PoisonCircleDamage_OncePerSecond.GA_PoisonCircleDamage_OncePerSecond_C.OnPerformAction_458D02164F7130F5939345BFF276C957
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnPerformAction_458D02164F7130F5939345BFF276C957(int32_t ActionNumber); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function GA_PoisonCircleDamage_OncePerSecond.GA_PoisonCircleDamage_OncePerSecond_C.OnFinish_47FC705841D6A0F464D998826CE125C4
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnFinish_47FC705841D6A0F464D998826CE125C4(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function GA_PoisonCircleDamage_OncePerSecond.GA_PoisonCircleDamage_OncePerSecond_C.K2_ActivateAbility
	// Flags: [Event|Protected|BlueprintEvent]
	void K2_ActivateAbility(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function GA_PoisonCircleDamage_OncePerSecond.GA_PoisonCircleDamage_OncePerSecond_C.ExecuteUbergraph_GA_PoisonCircleDamage_OncePerSecond
	// Flags: [Final|UbergraphFunction|HasDefaults]
	void ExecuteUbergraph_GA_PoisonCircleDamage_OncePerSecond(int32_t EntryPoint); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x4)
};

