#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class Gauntlet.GauntletTestController
// Size: 0x30 // Inherited bytes: 0x28
struct UGauntletTestController : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08
};

// Object Name: Class Gauntlet.GauntletTestControllerBootTest
// Size: 0x30 // Inherited bytes: 0x30
struct UGauntletTestControllerBootTest : UGauntletTestController {
};

// Object Name: Class Gauntlet.GauntletTestControllerErrorTest
// Size: 0x50 // Inherited bytes: 0x30
struct UGauntletTestControllerErrorTest : UGauntletTestController {
	// Fields
	char pad_0x30[0x20]; // Offset: 0x30 // Size: 0x20
};

