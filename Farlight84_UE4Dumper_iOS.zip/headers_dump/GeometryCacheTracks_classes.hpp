#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class GeometryCacheTracks.MovieSceneGeometryCacheSection
// Size: 0x118 // Inherited bytes: 0xd8
struct UMovieSceneGeometryCacheSection : UMovieSceneSection {
	// Fields
	struct FMovieSceneGeometryCacheParams Params; // Offset: 0xd8 // Size: 0x40
};

// Object Name: Class GeometryCacheTracks.MovieSceneGeometryCacheTrack
// Size: 0x68 // Inherited bytes: 0x58
struct UMovieSceneGeometryCacheTrack : UMovieSceneNameableTrack {
	// Fields
	struct TArray<struct UMovieSceneSection*> AnimationSections; // Offset: 0x58 // Size: 0x10
};

