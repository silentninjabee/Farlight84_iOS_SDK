#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class GeometryCollectionEngine.ChaosDestructionListener
// Size: 0x570 // Inherited bytes: 0x350
struct UChaosDestructionListener : USceneComponent {
	// Fields
	char bIsCollisionEventListeningEnabled : 1; // Offset: 0x344 // Size: 0x01
	char bIsBreakingEventListeningEnabled : 1; // Offset: 0x344 // Size: 0x01
	char bIsTrailingEventListeningEnabled : 1; // Offset: 0x344 // Size: 0x01
	struct FChaosCollisionEventRequestSettings CollisionEventRequestSettings; // Offset: 0x348 // Size: 0x18
	struct FChaosBreakingEventRequestSettings BreakingEventRequestSettings; // Offset: 0x360 // Size: 0x18
	struct FChaosTrailingEventRequestSettings TrailingEventRequestSettings; // Offset: 0x378 // Size: 0x18
	struct TSet<struct AChaosSolverActor*> ChaosSolverActors; // Offset: 0x390 // Size: 0x50
	struct TSet<struct AGeometryCollectionActor*> GeometryCollectionActors; // Offset: 0x3e0 // Size: 0x50
	struct FMulticastInlineDelegate OnCollisionEvents; // Offset: 0x430 // Size: 0x10
	struct FMulticastInlineDelegate OnBreakingEvents; // Offset: 0x440 // Size: 0x10
	struct FMulticastInlineDelegate OnTrailingEvents; // Offset: 0x450 // Size: 0x10
	char pad_0x468_3 : 5; // Offset: 0x468 // Size: 0x01
	char pad_0x469[0x107]; // Offset: 0x469 // Size: 0x107

	// Functions

	// Object Name: Function GeometryCollectionEngine.ChaosDestructionListener.SortTrailingEvents
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SortTrailingEvents(struct TArray<struct FChaosTrailingEventData>& TrailingEvents, enum class EChaosTrailingSortMethod SortMethod); // Offset: 0x104d878e8 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function GeometryCollectionEngine.ChaosDestructionListener.SortCollisionEvents
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SortCollisionEvents(struct TArray<struct FChaosCollisionEventData>& CollisionEvents, enum class EChaosCollisionSortMethod SortMethod); // Offset: 0x104d87aa8 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function GeometryCollectionEngine.ChaosDestructionListener.SortBreakingEvents
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SortBreakingEvents(struct TArray<struct FChaosBreakingEventData>& BreakingEvents, enum class EChaosBreakingSortMethod SortMethod); // Offset: 0x104d879c8 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function GeometryCollectionEngine.ChaosDestructionListener.SetTrailingEventRequestSettings
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetTrailingEventRequestSettings(struct FChaosTrailingEventRequestSettings& InSettings); // Offset: 0x104d87d48 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function GeometryCollectionEngine.ChaosDestructionListener.SetTrailingEventEnabled
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetTrailingEventEnabled(bool bIsEnabled); // Offset: 0x104d87bbc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function GeometryCollectionEngine.ChaosDestructionListener.SetCollisionEventRequestSettings
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetCollisionEventRequestSettings(struct FChaosCollisionEventRequestSettings& InSettings); // Offset: 0x104d87e78 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function GeometryCollectionEngine.ChaosDestructionListener.SetCollisionEventEnabled
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetCollisionEventEnabled(bool bIsEnabled); // Offset: 0x104d87cc4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function GeometryCollectionEngine.ChaosDestructionListener.SetBreakingEventRequestSettings
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetBreakingEventRequestSettings(struct FChaosBreakingEventRequestSettings& InSettings); // Offset: 0x104d87de0 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function GeometryCollectionEngine.ChaosDestructionListener.SetBreakingEventEnabled
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetBreakingEventEnabled(bool bIsEnabled); // Offset: 0x104d87c40 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function GeometryCollectionEngine.ChaosDestructionListener.RemoveGeometryCollectionActor
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RemoveGeometryCollectionActor(struct AGeometryCollectionActor* GeometryCollectionActor); // Offset: 0x104d87f10 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function GeometryCollectionEngine.ChaosDestructionListener.RemoveChaosSolverActor
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RemoveChaosSolverActor(struct AChaosSolverActor* ChaosSolverActor); // Offset: 0x104d88008 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function GeometryCollectionEngine.ChaosDestructionListener.IsEventListening
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsEventListening(); // Offset: 0x104d87b88 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function GeometryCollectionEngine.ChaosDestructionListener.AddGeometryCollectionActor
	// Flags: [Final|Native|Public|BlueprintCallable]
	void AddGeometryCollectionActor(struct AGeometryCollectionActor* GeometryCollectionActor); // Offset: 0x104d87f8c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function GeometryCollectionEngine.ChaosDestructionListener.AddChaosSolverActor
	// Flags: [Final|Native|Public|BlueprintCallable]
	void AddChaosSolverActor(struct AChaosSolverActor* ChaosSolverActor); // Offset: 0x104d88084 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class GeometryCollectionEngine.GeometryCollectionActor
// Size: 0x238 // Inherited bytes: 0x228
struct AGeometryCollectionActor : AActor {
	// Fields
	struct UGeometryCollectionComponent* GeometryCollectionComponent; // Offset: 0x228 // Size: 0x08
	struct UGeometryCollectionDebugDrawComponent* GeometryCollectionDebugDrawComponent; // Offset: 0x230 // Size: 0x08

	// Functions

	// Object Name: Function GeometryCollectionEngine.GeometryCollectionActor.RaycastSingle
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	bool RaycastSingle(struct FVector Start, struct FVector End, struct FHitResult& OutHit); // Offset: 0x104d88f44 // Return & Params: Num(4) Size(0xa1)
};

// Object Name: Class GeometryCollectionEngine.GeometryCollectionCache
// Size: 0x50 // Inherited bytes: 0x28
struct UGeometryCollectionCache : UObject {
	// Fields
	struct FRecordedTransformTrack RecordedData; // Offset: 0x28 // Size: 0x10
	struct UGeometryCollection* SupportedCollection; // Offset: 0x38 // Size: 0x08
	struct FGuid CompatibleCollectionState; // Offset: 0x40 // Size: 0x10
};

// Object Name: Class GeometryCollectionEngine.GeometryCollectionComponent
// Size: 0x9f0 // Inherited bytes: 0x5b0
struct UGeometryCollectionComponent : UMeshComponent {
	// Fields
	struct AChaosSolverActor* ChaosSolverActor; // Offset: 0x5b0 // Size: 0x08
	char pad_0x5B8[0xe0]; // Offset: 0x5b8 // Size: 0xe0
	struct UGeometryCollection* RestCollection; // Offset: 0x698 // Size: 0x08
	struct TArray<struct AFieldSystemActor*> InitializationFields; // Offset: 0x6a0 // Size: 0x10
	bool Simulating; // Offset: 0x6b0 // Size: 0x01
	char pad_0x6B1[0x7]; // Offset: 0x6b1 // Size: 0x07
	enum class EObjectStateTypeEnum ObjectType; // Offset: 0x6b8 // Size: 0x01
	bool EnableClustering; // Offset: 0x6b9 // Size: 0x01
	char pad_0x6BA[0x2]; // Offset: 0x6ba // Size: 0x02
	int32_t ClusterGroupIndex; // Offset: 0x6bc // Size: 0x04
	int32_t MaxClusterLevel; // Offset: 0x6c0 // Size: 0x04
	char pad_0x6C4[0x4]; // Offset: 0x6c4 // Size: 0x04
	struct TArray<float> DamageThreshold; // Offset: 0x6c8 // Size: 0x10
	enum class EClusterConnectionTypeEnum ClusterConnectionType; // Offset: 0x6d8 // Size: 0x01
	char pad_0x6D9[0x3]; // Offset: 0x6d9 // Size: 0x03
	int32_t CollisionGroup; // Offset: 0x6dc // Size: 0x04
	float CollisionSampleFraction; // Offset: 0x6e0 // Size: 0x04
	float LinearEtherDrag; // Offset: 0x6e4 // Size: 0x04
	float AngularEtherDrag; // Offset: 0x6e8 // Size: 0x04
	char pad_0x6EC[0x4]; // Offset: 0x6ec // Size: 0x04
	struct UChaosPhysicalMaterial* PhysicalMaterial; // Offset: 0x6f0 // Size: 0x08
	enum class EInitialVelocityTypeEnum InitialVelocityType; // Offset: 0x6f8 // Size: 0x01
	char pad_0x6F9[0x3]; // Offset: 0x6f9 // Size: 0x03
	struct FVector InitialLinearVelocity; // Offset: 0x6fc // Size: 0x0c
	struct FVector InitialAngularVelocity; // Offset: 0x708 // Size: 0x0c
	char pad_0x714[0x4]; // Offset: 0x714 // Size: 0x04
	struct FGeomComponentCacheParameters CacheParameters; // Offset: 0x718 // Size: 0x50
	struct FMulticastInlineDelegate NotifyGeometryCollectionPhysicsStateChange; // Offset: 0x768 // Size: 0x10
	struct FMulticastInlineDelegate NotifyGeometryCollectionPhysicsLoadingStateChange; // Offset: 0x778 // Size: 0x10
	char pad_0x788[0x18]; // Offset: 0x788 // Size: 0x18
	struct FMulticastInlineDelegate OnChaosBreakEvent; // Offset: 0x7a0 // Size: 0x10
	float DesiredCacheTime; // Offset: 0x7b0 // Size: 0x04
	bool CachePlayback; // Offset: 0x7b4 // Size: 0x01
	char pad_0x7B5[0x3]; // Offset: 0x7b5 // Size: 0x03
	struct FMulticastInlineDelegate OnChaosPhysicsCollision; // Offset: 0x7b8 // Size: 0x10
	bool bNotifyBreaks; // Offset: 0x7c8 // Size: 0x01
	bool bNotifyCollisions; // Offset: 0x7c9 // Size: 0x01
	char pad_0x7CA[0x1fe]; // Offset: 0x7ca // Size: 0x1fe
	struct UBodySetup* DummyBodySetup; // Offset: 0x9c8 // Size: 0x08
	char pad_0x9D0[0x20]; // Offset: 0x9d0 // Size: 0x20

	// Functions

	// Object Name: Function GeometryCollectionEngine.GeometryCollectionComponent.SetNotifyBreaks
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetNotifyBreaks(bool bNewNotifyBreaks); // Offset: 0x104d89a10 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function GeometryCollectionEngine.GeometryCollectionComponent.ReceivePhysicsCollision
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	void ReceivePhysicsCollision(struct FChaosPhysicsCollisionInfo& CollisionInfo); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x70)

	// Object Name: DelegateFunction GeometryCollectionEngine.GeometryCollectionComponent.NotifyGeometryCollectionPhysicsStateChange__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void NotifyGeometryCollectionPhysicsStateChange__DelegateSignature(struct UGeometryCollectionComponent* FracturedComponent); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x8)

	// Object Name: DelegateFunction GeometryCollectionEngine.GeometryCollectionComponent.NotifyGeometryCollectionPhysicsLoadingStateChange__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void NotifyGeometryCollectionPhysicsLoadingStateChange__DelegateSignature(struct UGeometryCollectionComponent* FracturedComponent); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function GeometryCollectionEngine.GeometryCollectionComponent.ApplyPhysicsField
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ApplyPhysicsField(bool Enabled, enum class EGeometryCollectionPhysicsTypeEnum Target, struct UFieldSystemMetaData* MetaData, struct UFieldNodeBase* Field); // Offset: 0x104d89a94 // Return & Params: Num(4) Size(0x18)

	// Object Name: Function GeometryCollectionEngine.GeometryCollectionComponent.ApplyKinematicField
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void ApplyKinematicField(float Radius, struct FVector Position); // Offset: 0x104d89bec // Return & Params: Num(2) Size(0x10)
};

// Object Name: Class GeometryCollectionEngine.GeometryCollectionDebugDrawActor
// Size: 0x310 // Inherited bytes: 0x228
struct AGeometryCollectionDebugDrawActor : AActor {
	// Fields
	struct FGeometryCollectionDebugDrawWarningMessage WarningMessage; // Offset: 0x228 // Size: 0x01
	char pad_0x229[0x7]; // Offset: 0x229 // Size: 0x07
	struct FGeometryCollectionDebugDrawActorSelectedRigidBody SelectedRigidBody; // Offset: 0x230 // Size: 0x18
	bool bDebugDrawWholeCollection; // Offset: 0x248 // Size: 0x01
	bool bDebugDrawHierarchy; // Offset: 0x249 // Size: 0x01
	bool bDebugDrawClustering; // Offset: 0x24a // Size: 0x01
	enum class EGeometryCollectionDebugDrawActorHideGeometry HideGeometry; // Offset: 0x24b // Size: 0x01
	bool bShowRigidBodyId; // Offset: 0x24c // Size: 0x01
	bool bShowRigidBodyCollision; // Offset: 0x24d // Size: 0x01
	bool bCollisionAtOrigin; // Offset: 0x24e // Size: 0x01
	bool bShowRigidBodyTransform; // Offset: 0x24f // Size: 0x01
	bool bShowRigidBodyInertia; // Offset: 0x250 // Size: 0x01
	bool bShowRigidBodyVelocity; // Offset: 0x251 // Size: 0x01
	bool bShowRigidBodyForce; // Offset: 0x252 // Size: 0x01
	bool bShowRigidBodyInfos; // Offset: 0x253 // Size: 0x01
	bool bShowTransformIndex; // Offset: 0x254 // Size: 0x01
	bool bShowTransform; // Offset: 0x255 // Size: 0x01
	bool bShowParent; // Offset: 0x256 // Size: 0x01
	bool bShowLevel; // Offset: 0x257 // Size: 0x01
	bool bShowConnectivityEdges; // Offset: 0x258 // Size: 0x01
	bool bShowGeometryIndex; // Offset: 0x259 // Size: 0x01
	bool bShowGeometryTransform; // Offset: 0x25a // Size: 0x01
	bool bShowBoundingBox; // Offset: 0x25b // Size: 0x01
	bool bShowFaces; // Offset: 0x25c // Size: 0x01
	bool bShowFaceIndices; // Offset: 0x25d // Size: 0x01
	bool bShowFaceNormals; // Offset: 0x25e // Size: 0x01
	bool bShowSingleFace; // Offset: 0x25f // Size: 0x01
	int32_t SingleFaceIndex; // Offset: 0x260 // Size: 0x04
	bool bShowVertices; // Offset: 0x264 // Size: 0x01
	bool bShowVertexIndices; // Offset: 0x265 // Size: 0x01
	bool bShowVertexNormals; // Offset: 0x266 // Size: 0x01
	bool bUseActiveVisualization; // Offset: 0x267 // Size: 0x01
	float PointThickness; // Offset: 0x268 // Size: 0x04
	float LineThickness; // Offset: 0x26c // Size: 0x04
	bool bTextShadow; // Offset: 0x270 // Size: 0x01
	char pad_0x271[0x3]; // Offset: 0x271 // Size: 0x03
	float TextScale; // Offset: 0x274 // Size: 0x04
	float NormalScale; // Offset: 0x278 // Size: 0x04
	float AxisScale; // Offset: 0x27c // Size: 0x04
	float ArrowScale; // Offset: 0x280 // Size: 0x04
	struct FColor RigidBodyIdColor; // Offset: 0x284 // Size: 0x04
	float RigidBodyTransformScale; // Offset: 0x288 // Size: 0x04
	struct FColor RigidBodyCollisionColor; // Offset: 0x28c // Size: 0x04
	struct FColor RigidBodyInertiaColor; // Offset: 0x290 // Size: 0x04
	struct FColor RigidBodyVelocityColor; // Offset: 0x294 // Size: 0x04
	struct FColor RigidBodyForceColor; // Offset: 0x298 // Size: 0x04
	struct FColor RigidBodyInfoColor; // Offset: 0x29c // Size: 0x04
	struct FColor TransformIndexColor; // Offset: 0x2a0 // Size: 0x04
	float TransformScale; // Offset: 0x2a4 // Size: 0x04
	struct FColor LevelColor; // Offset: 0x2a8 // Size: 0x04
	struct FColor ParentColor; // Offset: 0x2ac // Size: 0x04
	float ConnectivityEdgeThickness; // Offset: 0x2b0 // Size: 0x04
	struct FColor GeometryIndexColor; // Offset: 0x2b4 // Size: 0x04
	float GeometryTransformScale; // Offset: 0x2b8 // Size: 0x04
	struct FColor BoundingBoxColor; // Offset: 0x2bc // Size: 0x04
	struct FColor FaceColor; // Offset: 0x2c0 // Size: 0x04
	struct FColor FaceIndexColor; // Offset: 0x2c4 // Size: 0x04
	struct FColor FaceNormalColor; // Offset: 0x2c8 // Size: 0x04
	struct FColor SingleFaceColor; // Offset: 0x2cc // Size: 0x04
	struct FColor VertexColor; // Offset: 0x2d0 // Size: 0x04
	struct FColor VertexIndexColor; // Offset: 0x2d4 // Size: 0x04
	struct FColor VertexNormalColor; // Offset: 0x2d8 // Size: 0x04
	char pad_0x2DC[0x4]; // Offset: 0x2dc // Size: 0x04
	struct UBillboardComponent* SpriteComponent; // Offset: 0x2e0 // Size: 0x08
	char pad_0x2E8[0x28]; // Offset: 0x2e8 // Size: 0x28
};

// Object Name: Class GeometryCollectionEngine.GeometryCollectionDebugDrawComponent
// Size: 0xc8 // Inherited bytes: 0xb0
struct UGeometryCollectionDebugDrawComponent : UActorComponent {
	// Fields
	struct AGeometryCollectionDebugDrawActor* GeometryCollectionDebugDrawActor; // Offset: 0xb0 // Size: 0x08
	struct AGeometryCollectionRenderLevelSetActor* GeometryCollectionRenderLevelSetActor; // Offset: 0xb8 // Size: 0x08
	char pad_0xC0[0x8]; // Offset: 0xc0 // Size: 0x08
};

// Object Name: Class GeometryCollectionEngine.GeometryCollection
// Size: 0xd0 // Inherited bytes: 0x28
struct UGeometryCollection : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08
	struct TArray<struct UMaterialInterface*> Materials; // Offset: 0x30 // Size: 0x10
	enum class ECollisionTypeEnum CollisionType; // Offset: 0x40 // Size: 0x01
	enum class EImplicitTypeEnum ImplicitType; // Offset: 0x41 // Size: 0x01
	char pad_0x42[0x2]; // Offset: 0x42 // Size: 0x02
	int32_t MinLevelSetResolution; // Offset: 0x44 // Size: 0x04
	int32_t MaxLevelSetResolution; // Offset: 0x48 // Size: 0x04
	int32_t MinClusterLevelSetResolution; // Offset: 0x4c // Size: 0x04
	int32_t MaxClusterLevelSetResolution; // Offset: 0x50 // Size: 0x04
	float CollisionObjectReductionPercentage; // Offset: 0x54 // Size: 0x04
	bool bMassAsDensity; // Offset: 0x58 // Size: 0x01
	char pad_0x59[0x3]; // Offset: 0x59 // Size: 0x03
	float Mass; // Offset: 0x5c // Size: 0x04
	float MinimumMassClamp; // Offset: 0x60 // Size: 0x04
	float CollisionParticlesFraction; // Offset: 0x64 // Size: 0x04
	int32_t MaximumCollisionParticles; // Offset: 0x68 // Size: 0x04
	char pad_0x6C[0x4]; // Offset: 0x6c // Size: 0x04
	struct TArray<struct FGeometryCollectionSizeSpecificData> SizeSpecificData; // Offset: 0x70 // Size: 0x10
	bool EnableRemovePiecesOnFracture; // Offset: 0x80 // Size: 0x01
	char pad_0x81[0x7]; // Offset: 0x81 // Size: 0x07
	struct TArray<struct UMaterialInterface*> RemoveOnFractureMaterials; // Offset: 0x88 // Size: 0x10
	struct FGuid PersistentGuid; // Offset: 0x98 // Size: 0x10
	struct FGuid StateGuid; // Offset: 0xa8 // Size: 0x10
	int32_t BoneSelectedMaterialIndex; // Offset: 0xb8 // Size: 0x04
	char pad_0xBC[0x14]; // Offset: 0xbc // Size: 0x14
};

// Object Name: Class GeometryCollectionEngine.GeometryCollectionRenderLevelSetActor
// Size: 0x2c0 // Inherited bytes: 0x228
struct AGeometryCollectionRenderLevelSetActor : AActor {
	// Fields
	struct UVolumeTexture* TargetVolumeTexture; // Offset: 0x228 // Size: 0x08
	struct UMaterial* RayMarchMaterial; // Offset: 0x230 // Size: 0x08
	float SurfaceTolerance; // Offset: 0x238 // Size: 0x04
	float Isovalue; // Offset: 0x23c // Size: 0x04
	bool Enabled; // Offset: 0x240 // Size: 0x01
	bool RenderVolumeBoundingBox; // Offset: 0x241 // Size: 0x01
	char pad_0x242[0x7e]; // Offset: 0x242 // Size: 0x7e
};

// Object Name: Class GeometryCollectionEngine.SkeletalMeshSimulationComponent
// Size: 0x138 // Inherited bytes: 0xb0
struct USkeletalMeshSimulationComponent : UActorComponent {
	// Fields
	char pad_0xB0[0x8]; // Offset: 0xb0 // Size: 0x08
	struct UChaosPhysicalMaterial* PhysicalMaterial; // Offset: 0xb8 // Size: 0x08
	struct AChaosSolverActor* ChaosSolverActor; // Offset: 0xc0 // Size: 0x08
	struct UPhysicsAsset* OverridePhysicsAsset; // Offset: 0xc8 // Size: 0x08
	bool bSimulating; // Offset: 0xd0 // Size: 0x01
	bool bNotifyCollisions; // Offset: 0xd1 // Size: 0x01
	enum class EObjectStateTypeEnum ObjectType; // Offset: 0xd2 // Size: 0x01
	char pad_0xD3[0x1]; // Offset: 0xd3 // Size: 0x01
	float Density; // Offset: 0xd4 // Size: 0x04
	float MinMass; // Offset: 0xd8 // Size: 0x04
	float MaxMass; // Offset: 0xdc // Size: 0x04
	enum class ECollisionTypeEnum CollisionType; // Offset: 0xe0 // Size: 0x01
	char pad_0xE1[0x3]; // Offset: 0xe1 // Size: 0x03
	float ImplicitShapeParticlesPerUnitArea; // Offset: 0xe4 // Size: 0x04
	int32_t ImplicitShapeMinNumParticles; // Offset: 0xe8 // Size: 0x04
	int32_t ImplicitShapeMaxNumParticles; // Offset: 0xec // Size: 0x04
	int32_t MinLevelSetResolution; // Offset: 0xf0 // Size: 0x04
	int32_t MaxLevelSetResolution; // Offset: 0xf4 // Size: 0x04
	int32_t CollisionGroup; // Offset: 0xf8 // Size: 0x04
	enum class EInitialVelocityTypeEnum InitialVelocityType; // Offset: 0xfc // Size: 0x01
	char pad_0xFD[0x3]; // Offset: 0xfd // Size: 0x03
	struct FVector InitialLinearVelocity; // Offset: 0x100 // Size: 0x0c
	struct FVector InitialAngularVelocity; // Offset: 0x10c // Size: 0x0c
	struct FMulticastInlineDelegate OnChaosPhysicsCollision; // Offset: 0x118 // Size: 0x10
	char pad_0x128[0x10]; // Offset: 0x128 // Size: 0x10

	// Functions

	// Object Name: Function GeometryCollectionEngine.SkeletalMeshSimulationComponent.ReceivePhysicsCollision
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	void ReceivePhysicsCollision(struct FChaosPhysicsCollisionInfo& CollisionInfo); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x70)
};

// Object Name: Class GeometryCollectionEngine.StaticMeshSimulationComponent
// Size: 0x138 // Inherited bytes: 0xb0
struct UStaticMeshSimulationComponent : UActorComponent {
	// Fields
	char pad_0xB0[0x8]; // Offset: 0xb0 // Size: 0x08
	bool Simulating; // Offset: 0xb8 // Size: 0x01
	bool bNotifyCollisions; // Offset: 0xb9 // Size: 0x01
	enum class EObjectStateTypeEnum ObjectType; // Offset: 0xba // Size: 0x01
	char pad_0xBB[0x1]; // Offset: 0xbb // Size: 0x01
	float Mass; // Offset: 0xbc // Size: 0x04
	enum class ECollisionTypeEnum CollisionType; // Offset: 0xc0 // Size: 0x01
	enum class EImplicitTypeEnum ImplicitType; // Offset: 0xc1 // Size: 0x01
	char pad_0xC2[0x2]; // Offset: 0xc2 // Size: 0x02
	int32_t MinLevelSetResolution; // Offset: 0xc4 // Size: 0x04
	int32_t MaxLevelSetResolution; // Offset: 0xc8 // Size: 0x04
	enum class EInitialVelocityTypeEnum InitialVelocityType; // Offset: 0xcc // Size: 0x01
	char pad_0xCD[0x3]; // Offset: 0xcd // Size: 0x03
	struct FVector InitialLinearVelocity; // Offset: 0xd0 // Size: 0x0c
	struct FVector InitialAngularVelocity; // Offset: 0xdc // Size: 0x0c
	float DamageThreshold; // Offset: 0xe8 // Size: 0x04
	char pad_0xEC[0x4]; // Offset: 0xec // Size: 0x04
	struct UChaosPhysicalMaterial* PhysicalMaterial; // Offset: 0xf0 // Size: 0x08
	struct AChaosSolverActor* ChaosSolverActor; // Offset: 0xf8 // Size: 0x08
	struct FMulticastInlineDelegate OnChaosPhysicsCollision; // Offset: 0x100 // Size: 0x10
	char pad_0x110[0x10]; // Offset: 0x110 // Size: 0x10
	struct TArray<struct UPrimitiveComponent*> SimulatedComponents; // Offset: 0x120 // Size: 0x10
	char pad_0x130[0x8]; // Offset: 0x130 // Size: 0x08

	// Functions

	// Object Name: Function GeometryCollectionEngine.StaticMeshSimulationComponent.ReceivePhysicsCollision
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	void ReceivePhysicsCollision(struct FChaosPhysicsCollisionInfo& CollisionInfo); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x70)

	// Object Name: Function GeometryCollectionEngine.StaticMeshSimulationComponent.ForceRecreatePhysicsState
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ForceRecreatePhysicsState(); // Offset: 0x104d8afd0 // Return & Params: Num(0) Size(0x0)
};

