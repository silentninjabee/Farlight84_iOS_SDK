#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass I_PickableItem.I_PickableItem_C
// Size: 0x28 // Inherited bytes: 0x28
struct UI_PickableItem_C : UInterface {
	// Functions

	// Object Name: Function I_PickableItem.I_PickableItem_C.iPickupItem
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void iPickupItem(struct ABP_PlayerState_Framework_C* Player); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function I_PickableItem.I_PickableItem_C.iDiscardItem
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void iDiscardItem(struct ABP_PlayerState_Framework_C* Player); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x8)
};

