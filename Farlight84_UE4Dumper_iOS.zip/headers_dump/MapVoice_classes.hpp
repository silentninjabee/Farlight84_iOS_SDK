#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass MapVoice.MapVoice_C
// Size: 0x4b0 // Inherited bytes: 0x3f8
struct UMapVoice_C : UMapVoiceWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x3f8 // Size: 0x08
	struct UMarkIcon_C* MarkIcon1; // Offset: 0x400 // Size: 0x08
	struct UMarkIcon_C* MarkIcon2; // Offset: 0x408 // Size: 0x08
	struct UMarkIcon_C* MarkIcon3; // Offset: 0x410 // Size: 0x08
	struct UMarkIcon_C* MarkIcon4; // Offset: 0x418 // Size: 0x08
	struct UMarkIcon_C* MarkIcon5; // Offset: 0x420 // Size: 0x08
	struct UMarkIcon_C* MarkIcon6; // Offset: 0x428 // Size: 0x08
	struct UMarkIcon_C* MarkIcon7; // Offset: 0x430 // Size: 0x08
	struct UMarkIcon_C* MarkIcon8; // Offset: 0x438 // Size: 0x08
	struct UMarkIcon_C* MarkIcon9; // Offset: 0x440 // Size: 0x08
	struct UMarkIcon_C* MarkIconA; // Offset: 0x448 // Size: 0x08
	struct UMarkIcon_C* MarkIconB; // Offset: 0x450 // Size: 0x08
	struct UMarkIcon_C* MarkIconC; // Offset: 0x458 // Size: 0x08
	struct TMap<int32_t, struct UMarkIcon_C*> VoiceIconMap1; // Offset: 0x460 // Size: 0x50

	// Functions

	// Object Name: Function MapVoice.MapVoice_C.GetModuleName
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	struct FString GetModuleName(); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function MapVoice.MapVoice_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void PreConstruct(bool IsDesignTime); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function MapVoice.MapVoice_C.ExecuteUbergraph_MapVoice
	// Flags: [Final|UbergraphFunction|HasDefaults]
	void ExecuteUbergraph_MapVoice(int32_t EntryPoint); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x4)
};

