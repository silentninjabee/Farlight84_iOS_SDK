#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass NewRichTextBlockDecorator.NewRichTextBlockDecorator_C
// Size: 0x30 // Inherited bytes: 0x30
struct UNewRichTextBlockDecorator_C : URichTextBlockImageDecorator {
};

