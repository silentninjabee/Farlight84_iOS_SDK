#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: DynamicClass R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint.R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_C
// Size: 0x9e0 // Inherited bytes: 0x2d0
struct UR_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_C : UWeaponAnimInstance {
	// Fields
	struct FAnimNode_Root AnimGraphNode_Root; // Offset: 0x2d0 // Size: 0x30
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_19; // Offset: 0x300 // Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_18; // Offset: 0x328 // Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_17; // Offset: 0x350 // Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_16; // Offset: 0x378 // Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_15; // Offset: 0x3a0 // Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_14; // Offset: 0x3c8 // Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_13; // Offset: 0x3f0 // Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_12; // Offset: 0x418 // Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_11; // Offset: 0x440 // Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_10; // Offset: 0x468 // Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_9; // Offset: 0x490 // Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_8; // Offset: 0x4b8 // Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_7; // Offset: 0x4e0 // Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_6; // Offset: 0x508 // Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_5; // Offset: 0x530 // Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_4; // Offset: 0x558 // Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_3; // Offset: 0x580 // Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_2; // Offset: 0x5a8 // Size: 0x28
	struct FAnimNode_StateResult AnimGraphNode_StateResult_9; // Offset: 0x5d0 // Size: 0x30
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_3; // Offset: 0x600 // Size: 0x78
	struct FAnimNode_StateResult AnimGraphNode_StateResult_8; // Offset: 0x678 // Size: 0x30
	struct FAnimNode_StateResult AnimGraphNode_StateResult_7; // Offset: 0x6a8 // Size: 0x30
	struct FAnimNode_StateResult AnimGraphNode_StateResult_6; // Offset: 0x6d8 // Size: 0x30
	struct FAnimNode_StateResult AnimGraphNode_StateResult_5; // Offset: 0x708 // Size: 0x30
	struct FAnimNode_StateResult AnimGraphNode_StateResult_4; // Offset: 0x738 // Size: 0x30
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2; // Offset: 0x768 // Size: 0x78
	struct FAnimNode_StateResult AnimGraphNode_StateResult_3; // Offset: 0x7e0 // Size: 0x30
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer; // Offset: 0x810 // Size: 0x78
	struct FAnimNode_StateResult AnimGraphNode_StateResult_2; // Offset: 0x888 // Size: 0x30
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult; // Offset: 0x8b8 // Size: 0x28
	struct FAnimNode_StateResult AnimGraphNode_StateResult; // Offset: 0x8e0 // Size: 0x30
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine; // Offset: 0x910 // Size: 0xb0
	struct FAnimMsgData K2Node_MakeStruct_AnimMsgData; // Offset: 0x9c0 // Size: 0x08
	struct TArray<struct FAnimMsgData> K2Node_MakeArray_Array; // Offset: 0x9c8 // Size: 0x10
	char pad_0x9D8[0x8]; // Offset: 0x9d8 // Size: 0x08

	// Functions

	// Object Name: Function R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint.R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_C.TestAPI
	// Flags: [Native|Public|BlueprintCallable]
	void TestAPI(); // Offset: 0x10199925c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint.R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_C.InterruptAnim
	// Flags: [Native|Public|BlueprintCallable]
	void InterruptAnim(); // Offset: 0x101999304 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint.R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_FC0194B2401EA22381DBF39C55947FF9
	// Flags: [Native|Public]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_FC0194B2401EA22381DBF39C55947FF9(); // Offset: 0x101999080 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint.R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_E401BBA149B0DABC77E320A5D26F161C
	// Flags: [Native|Public]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_E401BBA149B0DABC77E320A5D26F161C(); // Offset: 0x1019990b8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint.R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_C959CBB24B6E3FBB125D5386BA83BA89
	// Flags: [Native|Public]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_C959CBB24B6E3FBB125D5386BA83BA89(); // Offset: 0x101999064 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint.R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_C56C131748626A9573F10282DB5E5052
	// Flags: [Native|Public]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_C56C131748626A9573F10282DB5E5052(); // Offset: 0x101999224 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint.R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_968E57334D0560E0D81E8F8CBF255866
	// Flags: [Native|Public]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_968E57334D0560E0D81E8F8CBF255866(); // Offset: 0x10199917c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint.R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_90C97F4B4CBC8816A38216BE138E6F89
	// Flags: [Native|Public]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_90C97F4B4CBC8816A38216BE138E6F89(); // Offset: 0x101999128 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint.R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_902489064567DB8F1C7F35A412FC55BD
	// Flags: [Native|Public]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_902489064567DB8F1C7F35A412FC55BD(); // Offset: 0x10199910c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint.R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_8E281982451991810FB1CDBE5C7AB333
	// Flags: [Native|Public]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_8E281982451991810FB1CDBE5C7AB333(); // Offset: 0x1019990f0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint.R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_75414DB244FBB7A53F3CE18A9FB7157B
	// Flags: [Native|Public]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_75414DB244FBB7A53F3CE18A9FB7157B(); // Offset: 0x101999048 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint.R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_73C2053F48EBA57AE80C7EB511A1ED8A
	// Flags: [Native|Public]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_73C2053F48EBA57AE80C7EB511A1ED8A(); // Offset: 0x1019990d4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint.R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_666390444F55176B8452A3ADD88C04EC
	// Flags: [Native|Public]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_666390444F55176B8452A3ADD88C04EC(); // Offset: 0x101999144 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint.R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_57FE46434F01218D85EC4697425396E0
	// Flags: [Native|Public]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_57FE46434F01218D85EC4697425396E0(); // Offset: 0x101999010 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint.R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_57691DF54B9855E9DD506B9FCCB61EA7
	// Flags: [Native|Public]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_57691DF54B9855E9DD506B9FCCB61EA7(); // Offset: 0x101999198 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint.R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_4ADDE6E04C5F8810E1EEA58820D214AE
	// Flags: [Native|Public]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_4ADDE6E04C5F8810E1EEA58820D214AE(); // Offset: 0x101999240 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint.R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_43F44591410E60EB2C5CD2B43DEB8E8E
	// Flags: [Native|Public]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_43F44591410E60EB2C5CD2B43DEB8E8E(); // Offset: 0x101999160 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint.R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_2C342F604862980A804FF2996F90C087
	// Flags: [Native|Public]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_2C342F604862980A804FF2996F90C087(); // Offset: 0x10199909c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint.R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_28F31C444D5EA218BB1A38AACC8722F3
	// Flags: [Native|Public]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_28F31C444D5EA218BB1A38AACC8722F3(); // Offset: 0x10199902c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint.R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_20E8B10A4E9FF7BA091039BFD5B13AD8
	// Flags: [Native|Public]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_20E8B10A4E9FF7BA091039BFD5B13AD8(); // Offset: 0x101999294 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint.R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_056EEB8B459D1AC625DFDB8AC5C35452
	// Flags: [Native|Public]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_TransitionResult_056EEB8B459D1AC625DFDB8AC5C35452(); // Offset: 0x1019991d0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint.R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_SequencePlayer_9CEFF7884F12CE6C82E80A8548619832
	// Flags: [Native|Public]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_SequencePlayer_9CEFF7884F12CE6C82E80A8548619832(); // Offset: 0x1019991b4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint.R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_SequencePlayer_696B215C4C93CC06D553F2B7970E6146
	// Flags: [Native|Public]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_SequencePlayer_696B215C4C93CC06D553F2B7970E6146(); // Offset: 0x1019991ec // Return & Params: Num(0) Size(0x0)

	// Object Name: Function R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint.R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_SequencePlayer_0D0A1C5849872911C76BD99ABCFFA34E
	// Flags: [Native|Public]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_AnimGraphNode_SequencePlayer_0D0A1C5849872911C76BD99ABCFFA34E(); // Offset: 0x101999208 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint.R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_C.AnimNotify_QuitIdle
	// Flags: [Native|Public|BlueprintCallable]
	void AnimNotify_QuitIdle(); // Offset: 0x1019992e8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint.R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_C.AnimNotify_QuitFire
	// Flags: [Native|Public|BlueprintCallable]
	void AnimNotify_QuitFire(); // Offset: 0x1019992b0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint.R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_C.AnimNotify_EnterIdle
	// Flags: [Native|Public|BlueprintCallable]
	void AnimNotify_EnterIdle(); // Offset: 0x1019992cc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint.R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_C.AnimNotify_EnterFire
	// Flags: [Native|Public|BlueprintCallable]
	void AnimNotify_EnterFire(); // Offset: 0x101999278 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint.R_Weapon_Mphy01_Set001_LODP_Skeleton_AnimBlueprint_C.AnimGraph
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	void AnimGraph(struct FPoseLink& bpp__AnimGraph__pf); // Offset: 0x101998f70 // Return & Params: Num(1) Size(0x10)
};

