#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct S_AiGroup_AiCompBase.S_AiGroup_AiCompBase
// Size: 0x20 // Inherited bytes: 0x00
struct FS_AiGroup_AiCompBase {
	// Fields
	struct TArray<struct FS_AiGroupSetting_AiCompBase> AiGroupSetting_14_A687F5C94BF1C7F5840FBB8AC4334C0A; // Offset: 0x00 // Size: 0x10
	int32_t TimeOut_9_F640B9744B21E97226F07583CDB4F870; // Offset: 0x10 // Size: 0x04
	int32_t NextWave_12_966ADD384DED2C469CAF52BC47BCDEB6; // Offset: 0x14 // Size: 0x04
	int32_t AiCapacity_18_F09CC6AC401197E66B6BB98EBC38EAE8; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
};

