#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct S_AiItemSetting_AiCompBase.S_AiItemSetting_AiCompBase
// Size: 0xf0 // Inherited bytes: 0x00
struct FS_AiItemSetting_AiCompBase {
	// Fields
	struct TMap<enum class E_AiEquipmentSettingType_AiCompBase, struct FS_EquipmentArray_AiCompBase> Equipment_18_9C814D4B443C3D40AEB7F7BA8C9347DC; // Offset: 0x00 // Size: 0x50
	struct TMap<enum class E_AiItemSettingType_AiCompBase, struct FIntPoint> Consumable_16_381728FD4CB1313E0D6308A986EE78AD; // Offset: 0x50 // Size: 0x50
	struct TMap<enum class E_WeaponParts_AiCompBase, struct FS_EquipmentArray_AiCompBase> WeaponPart_27_A0B9A42B41A500C81FF8A997BC5F7D70; // Offset: 0xa0 // Size: 0x50
};

