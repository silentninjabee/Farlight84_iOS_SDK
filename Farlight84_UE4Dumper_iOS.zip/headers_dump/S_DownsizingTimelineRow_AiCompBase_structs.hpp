#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct S_DownsizingTimelineRow_AiCompBase.S_DownsizingTimelineRow_AiCompBase
// Size: 0x10 // Inherited bytes: 0x00
struct FS_DownsizingTimelineRow_AiCompBase {
	// Fields
	int32_t StartTime_14_A273D8E04EE25E8D2D889AACBBA4C5B8; // Offset: 0x00 // Size: 0x04
	int32_t EndTime_17_228E647F4CA498BC72379791288866FB; // Offset: 0x04 // Size: 0x04
	int32_t Mix_9_99173A4E47CF385193A8FD8CB2562C9A; // Offset: 0x08 // Size: 0x04
	int32_t Max_10_E4F85214403C3476C6DC9C967BE82897; // Offset: 0x0c // Size: 0x04
};

