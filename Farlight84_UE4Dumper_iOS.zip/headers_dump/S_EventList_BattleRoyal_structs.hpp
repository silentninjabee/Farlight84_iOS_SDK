#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct S_EventList_BattleRoyal.S_EventList_BattleRoyal
// Size: 0x10 // Inherited bytes: 0x00
struct FS_EventList_BattleRoyal {
	// Fields
	struct TArray<struct FS_Event_BattleRoyale> EventList_3_9C55B4BD476EE1024C917DAC11DB6F31; // Offset: 0x00 // Size: 0x10
};

