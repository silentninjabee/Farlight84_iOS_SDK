#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct S_FilterItem_AiCompBase.S_FilterItem_AiCompBase
// Size: 0x58 // Inherited bytes: 0x00
struct FS_FilterItem_AiCompBase {
	// Fields
	enum class E_FilterType_AiCompBase Type_2_5F710F734E5DE42D8867F89EAEF8EDDA; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct TMap<enum class E_FilterParameterType_AiCompBase, struct FString> Parameter_9_BF9075834B62C964411A2E904F36CE16; // Offset: 0x08 // Size: 0x50
};

