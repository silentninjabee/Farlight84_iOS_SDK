#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct S_Filter_AiCompBase.S_Filter_AiCompBase
// Size: 0x18 // Inherited bytes: 0x00
struct FS_Filter_AiCompBase {
	// Fields
	struct TArray<struct FS_FilterGroup_AiCompBase> FilterGroup_5_1C1B853F44EB9276E78146B9041C055E; // Offset: 0x00 // Size: 0x10
	struct UActorComponent* FilterBP_11_A0A6C68E4056DF7081A4EB94A976515C; // Offset: 0x10 // Size: 0x08
};

