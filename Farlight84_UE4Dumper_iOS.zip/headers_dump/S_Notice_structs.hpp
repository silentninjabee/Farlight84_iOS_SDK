#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct S_Notice.S_Notice
// Size: 0x20 // Inherited bytes: 0x00
struct FS_Notice {
	// Fields
	struct UObject* Icon_23_BE1B67524B1209FD0942B6B9560F62CC; // Offset: 0x00 // Size: 0x08
	struct FString Text_24_2592C444471410BA3FD02289094D92BE; // Offset: 0x08 // Size: 0x10
	enum class E_NoticeLevel NoticeLevel_25_2D9897214095D9FC1F3636B3132BC0AD; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x7]; // Offset: 0x19 // Size: 0x07
};

