#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct S_NoyaNoticeInfo.S_NoyaNoticeInfo
// Size: 0x70 // Inherited bytes: 0x00
struct FS_NoyaNoticeInfo {
	// Fields
	enum class E_NoticeType_Noya Type_19_61521B0446EAF964ED4414B88CA78D95; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float LifeTime_20_BD882D5545761162ABC2D8B45FABE100; // Offset: 0x04 // Size: 0x04
	struct FString Text_21_231C41074F4B39F8D3276B9B458D1D31; // Offset: 0x08 // Size: 0x10
	struct TMap<char, bool> TriggerCondition_24_461190CB4B9B8C849665FEBEA709D091; // Offset: 0x18 // Size: 0x50
	int32_t MaxTiggerTimes_23_1487705444240010E31DD4A6A175CACD; // Offset: 0x68 // Size: 0x04
	char pad_0x6C[0x4]; // Offset: 0x6c // Size: 0x04
};

