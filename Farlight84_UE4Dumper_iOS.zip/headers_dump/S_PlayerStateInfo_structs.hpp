#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct S_PlayerStateInfo.S_PlayerStateInfo
// Size: 0x30 // Inherited bytes: 0x00
struct FS_PlayerStateInfo {
	// Fields
	struct TArray<struct FString> Side_7_608261C648D30F47D7145DA1BAECF195; // Offset: 0x00 // Size: 0x10
	struct TArray<struct FString> Job_6_34C0F29E43512B15F222B087F36445E7; // Offset: 0x10 // Size: 0x10
	struct TArray<enum class ESCMPlayerState> State_11_86968F0643706CFA3C5E93B4E1F22EF6; // Offset: 0x20 // Size: 0x10
};

