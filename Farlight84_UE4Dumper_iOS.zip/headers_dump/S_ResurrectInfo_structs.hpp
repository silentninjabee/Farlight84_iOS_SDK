#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct S_ResurrectInfo.S_ResurrectInfo
// Size: 0x05 // Inherited bytes: 0x00
struct FS_ResurrectInfo {
	// Fields
	bool bClearWeapons_8_85433FCD494E4E2DDCA2F6AB69D508C9; // Offset: 0x00 // Size: 0x01
	bool bClearAllItems_7_1B66870A49E70A4A31DBD1B93C1AE45D; // Offset: 0x01 // Size: 0x01
	bool bEmptyEnergy_9_422079A04E20412A0DD60594501D7D8C; // Offset: 0x02 // Size: 0x01
	bool bReChargeJetToFull_10_2649F2CB4F2A722D287E91848E966DBF; // Offset: 0x03 // Size: 0x01
	enum class EPlayerResurrectType ResurrectMethod_15_E3E0A84B479C7DB70DAAF88AAF99DA23; // Offset: 0x04 // Size: 0x01
};

