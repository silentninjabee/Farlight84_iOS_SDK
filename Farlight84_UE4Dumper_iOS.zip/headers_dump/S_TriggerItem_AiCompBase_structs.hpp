#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct S_TriggerItem_AiCompBase.S_TriggerItem_AiCompBase
// Size: 0x98 // Inherited bytes: 0x00
struct FS_TriggerItem_AiCompBase {
	// Fields
	enum class E_TriggerType_AiCompBase TriggerType_2_BEB26C2A4141C52136B9A19F8C06055C; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	int32_t CoolDown_30_5AF35B8D4693268D4C775B8ADDB18B5F; // Offset: 0x04 // Size: 0x04
	bool ApplyOnTeam_24_A1B578364A69FF58A4EE66B5A3E3B96F; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x3]; // Offset: 0x09 // Size: 0x03
	int32_t ApplyOnTeamRange_27_3936C50945C041ADEC41E09AFD20FC30; // Offset: 0x0c // Size: 0x04
	struct TArray<struct FS_AiGroup_AiCompBase> AiGroup_22_C14D1C57492200282B35DEBACC4305D7; // Offset: 0x10 // Size: 0x10
	struct FS_Filter_AiCompBase Filter_36_2B44835D40F02B33ACF96FBDC89C32CF; // Offset: 0x20 // Size: 0x18
	struct FS_RecheckSetting_AiCompBase Recheck_33_3A2B5E9C4CCDB711A3980798BDBBCB1C; // Offset: 0x38 // Size: 0x08
	struct TMap<struct FString, struct FString> Parameter_41_F3AAED884967B98F2AA588925201DCEA; // Offset: 0x40 // Size: 0x50
	enum class E_TriggerAction_AiCompBase Action_44_E917063042B97A3F6F6DBCB1464A2C87; // Offset: 0x90 // Size: 0x01
	char pad_0x91[0x7]; // Offset: 0x91 // Size: 0x07
};

