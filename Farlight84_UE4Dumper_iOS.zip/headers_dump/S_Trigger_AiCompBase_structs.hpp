#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct S_Trigger_AiCompBase.S_Trigger_AiCompBase
// Size: 0x10 // Inherited bytes: 0x00
struct FS_Trigger_AiCompBase {
	// Fields
	struct TArray<struct FS_TriggerItem_AiCompBase> Trigger_3_93BDA1884A2BBD87A3845FBBE4FA189F; // Offset: 0x00 // Size: 0x10
};

