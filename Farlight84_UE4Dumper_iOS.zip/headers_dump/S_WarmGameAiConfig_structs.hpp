#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct S_WarmGameAiConfig.S_WarmGameAiConfig
// Size: 0x0c // Inherited bytes: 0x00
struct FS_WarmGameAiConfig {
	// Fields
	int32_t Difficulty_2_BC1C176F4C7CBB4D6FC889B2806BF007; // Offset: 0x00 // Size: 0x04
	int32_t Preference_6_7DE61082428EF32F3BEFE6AFA07875B9; // Offset: 0x04 // Size: 0x04
	int32_t Substitute_5_5FA843ED4EF730ADF049548C170D13E7; // Offset: 0x08 // Size: 0x04
};

