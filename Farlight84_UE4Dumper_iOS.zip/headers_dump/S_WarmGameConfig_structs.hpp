#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct S_WarmGameConfig.S_WarmGameConfig
// Size: 0x18 // Inherited bytes: 0x00
struct FS_WarmGameConfig {
	// Fields
	struct UObject* WarmGameLogic_11_C4D3600041B8F0E806BDC09E30D6C1D0; // Offset: 0x00 // Size: 0x08
	struct TArray<struct FS_WarmGameAiConfig> AiTeammates_15_B5CA8DEC448F508FECCA08B77C240AFC; // Offset: 0x08 // Size: 0x10
};

