#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: DynamicClass SpecABP_Skill_Cards.SpecABP_Skill_Cards_C
// Size: 0x3f80 // Inherited bytes: 0x3f80
struct USpecABP_Skill_Cards_C : USpecABP_Skill_OneHandThrow_C {
};

