#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum T_Type_System_Push.T_Type_System_Push
enum class T_Type_System_Push : uint8 {
	Recruit = 0,
	Room = 1,
	Elimination1 = 2,
	Elimination2 = 3,
	BO1 = 4,
	Points = 5,
	T Type System MAX = 6
};

