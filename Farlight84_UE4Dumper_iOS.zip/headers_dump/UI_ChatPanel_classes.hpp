#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_ChatPanel.UI_ChatPanel_C
// Size: 0x378 // Inherited bytes: 0x340
struct UUI_ChatPanel_C : USolarUserWidget {
	// Fields
	struct UButton* Btn_Interaction; // Offset: 0x340 // Size: 0x08
	struct UWidgetSwitcher* Chat_Switcher; // Offset: 0x348 // Size: 0x08
	struct UImage* Img_message_bg03; // Offset: 0x350 // Size: 0x08
	struct URichTextBlock* Message; // Offset: 0x358 // Size: 0x08
	struct UTextBlock* UnreadMessageCount; // Offset: 0x360 // Size: 0x08
	struct UOverlay* UnreadMessageNotifyPanel; // Offset: 0x368 // Size: 0x08
	struct UWidgetSwitcher* WidgetSwitcher_ChatType; // Offset: 0x370 // Size: 0x08

	// Functions

	// Object Name: Function UI_ChatPanel.UI_ChatPanel_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	struct FString GetModuleName(); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UI_ChatPanel.UI_ChatPanel_C.SetMsgText
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void SetMsgText(char ChatType, struct FString playerName, struct FString Msg, struct FString& OutputText); // Offset: 0x102f67d18 // Return & Params: Num(4) Size(0x38)
};

