#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_Common_Transition_Anim.UI_Common_Transition_Anim_C
// Size: 0x350 // Inherited bytes: 0x340
struct UUI_Common_Transition_Anim_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x340 // Size: 0x08
	struct UWidgetAnimation* Anim_Transition; // Offset: 0x348 // Size: 0x08

	// Functions

	// Object Name: Function UI_Common_Transition_Anim.UI_Common_Transition_Anim_C.OnSolarUIOpened
	// Flags: [Event|Protected|BlueprintEvent]
	void OnSolarUIOpened(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Common_Transition_Anim.UI_Common_Transition_Anim_C.ExecuteUbergraph_UI_Common_Transition_Anim
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_UI_Common_Transition_Anim(int32_t EntryPoint); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x4)
};

