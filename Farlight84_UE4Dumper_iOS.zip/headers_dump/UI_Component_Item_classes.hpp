#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_Component_Item.UI_Component_Item_C
// Size: 0x42c // Inherited bytes: 0x340
struct UUI_Component_Item_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x340 // Size: 0x08
	struct UWidgetAnimation* Anim_Loop; // Offset: 0x348 // Size: 0x08
	struct UWidgetAnimation* Puzzle_Unlock_Anim; // Offset: 0x350 // Size: 0x08
	struct UWidgetAnimation* Sold_Anim; // Offset: 0x358 // Size: 0x08
	struct UWidgetAnimation* Enter_Anim; // Offset: 0x360 // Size: 0x08
	struct UWidgetAnimation* Receive_Anim; // Offset: 0x368 // Size: 0x08
	struct UButton* Btn_Item; // Offset: 0x370 // Size: 0x08
	struct UImage* Image_TrialTag; // Offset: 0x378 // Size: 0x08
	struct UImage* Img_BG; // Offset: 0x380 // Size: 0x08
	struct UImage* Img_BG_Light; // Offset: 0x388 // Size: 0x08
	struct UImage* img_Equiped; // Offset: 0x390 // Size: 0x08
	struct UImage* Img_Icon; // Offset: 0x398 // Size: 0x08
	struct UImage* Img_Light_Bg; // Offset: 0x3a0 // Size: 0x08
	struct UImage* Img_Light_Lines; // Offset: 0x3a8 // Size: 0x08
	struct UImage* Img_Light_Wipes; // Offset: 0x3b0 // Size: 0x08
	struct UImage* Img_Light_Wipes_2; // Offset: 0x3b8 // Size: 0x08
	struct UImage* Img_Loop_Light; // Offset: 0x3c0 // Size: 0x08
	struct UImage* Img_Puzzle; // Offset: 0x3c8 // Size: 0x08
	struct UImage* Img_Selected; // Offset: 0x3d0 // Size: 0x08
	struct UImage* Img_Sold_Mask; // Offset: 0x3d8 // Size: 0x08
	struct UCanvasPanel* Panel_Claim; // Offset: 0x3e0 // Size: 0x08
	struct UOverlay* Received; // Offset: 0x3e8 // Size: 0x08
	struct USizeBox* Size_Item; // Offset: 0x3f0 // Size: 0x08
	struct USolarRedHint_General_C* SolarRedHint_General; // Offset: 0x3f8 // Size: 0x08
	struct UTextBlock* Txt_Number; // Offset: 0x400 // Size: 0x08
	struct USolarTextBlock* Txt_Owned; // Offset: 0x408 // Size: 0x08
	struct UOverlay* Unlock; // Offset: 0x410 // Size: 0x08
	enum class E_Type_Item ItemState; // Offset: 0x418 // Size: 0x01
	char pad_0x419[0x3]; // Offset: 0x419 // Size: 0x03
	int32_t ; // Offset: 0x41c // Size: 0x04
	enum class E_Item_Quality Quality; // Offset: 0x420 // Size: 0x01
	bool Select; // Offset: 0x421 // Size: 0x01
	bool Experience; // Offset: 0x422 // Size: 0x01
	bool Num; // Offset: 0x423 // Size: 0x01
	bool Puzzle; // Offset: 0x424 // Size: 0x01
	bool Equiped; // Offset: 0x425 // Size: 0x01
	bool RedHint; // Offset: 0x426 // Size: 0x01
	char pad_0x427[0x1]; // Offset: 0x427 // Size: 0x01
	int32_t Txt_Size; // Offset: 0x428 // Size: 0x04

	// Functions

	// Object Name: Function UI_Component_Item.UI_Component_Item_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	struct FString GetModuleName(); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UI_Component_Item.UI_Component_Item_C.BP_OnEntryReleased
	// Flags: [Event|Protected|BlueprintEvent]
	void BP_OnEntryReleased(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Component_Item.UI_Component_Item_C.BP_OnItemExpansionChanged
	// Flags: [Event|Protected|BlueprintEvent]
	void BP_OnItemExpansionChanged(bool bIsExpanded); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Component_Item.UI_Component_Item_C.BP_OnItemSelectionChanged
	// Flags: [Event|Protected|BlueprintEvent]
	void BP_OnItemSelectionChanged(bool bIsSelected); // Offset: 0x10135fdbc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Component_Item.UI_Component_Item_C.OnListItemObjectSet
	// Flags: [Event|Protected|BlueprintEvent]
	void OnListItemObjectSet(struct UObject* ListItemObject); // Offset: 0x10135fdbc // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UI_Component_Item.UI_Component_Item_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void PreConstruct(bool IsDesignTime); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Component_Item.UI_Component_Item_C.ChangItemState
	// Flags: [BlueprintCallable|BlueprintEvent]
	void ChangItemState(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Component_Item.UI_Component_Item_C.PlayReceiveAnimEvent
	// Flags: [BlueprintCallable|BlueprintEvent]
	void PlayReceiveAnimEvent(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Component_Item.UI_Component_Item_C.StopReceiveAnimEvent
	// Flags: [BlueprintCallable|BlueprintEvent]
	void StopReceiveAnimEvent(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Component_Item.UI_Component_Item_C.ExecuteUbergraph_UI_Component_Item
	// Flags: [Final|UbergraphFunction|HasDefaults]
	void ExecuteUbergraph_UI_Component_Item(int32_t EntryPoint); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x4)
};

