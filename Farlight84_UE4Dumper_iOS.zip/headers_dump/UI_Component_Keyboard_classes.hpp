#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_Component_Keyboard.UI_Component_Keyboard_C
// Size: 0x2d1 // Inherited bytes: 0x2a0
struct UUI_Component_Keyboard_C : USolarComponentKeyWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x2a0 // Size: 0x08
	struct UImage* Img_BG; // Offset: 0x2a8 // Size: 0x08
	struct USizeBox* SizeBox_1; // Offset: 0x2b0 // Size: 0x08
	struct UTextBlock* Txt_Key; // Offset: 0x2b8 // Size: 0x08
	bool Red; // Offset: 0x2c0 // Size: 0x01
	bool Yellow; // Offset: 0x2c1 // Size: 0x01
	char pad_0x2C2[0x2]; // Offset: 0x2c2 // Size: 0x02
	int32_t Font_Size; // Offset: 0x2c4 // Size: 0x04
	struct FVector2D BG_Size; // Offset: 0x2c8 // Size: 0x08
	bool bCustomRefresh; // Offset: 0x2d0 // Size: 0x01

	// Functions

	// Object Name: Function UI_Component_Keyboard.UI_Component_Keyboard_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	struct FString GetModuleName(); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UI_Component_Keyboard.UI_Component_Keyboard_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void PreConstruct(bool IsDesignTime); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Component_Keyboard.UI_Component_Keyboard_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Construct(); // Offset: 0x10135fdbc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Component_Keyboard.UI_Component_Keyboard_C.OnUpdateKeyboard
	// Flags: [BlueprintCallable|BlueprintEvent]
	void OnUpdateKeyboard(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Component_Keyboard.UI_Component_Keyboard_C.OnInitialized
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void OnInitialized(); // Offset: 0x10135fdbc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Component_Keyboard.UI_Component_Keyboard_C.ExecuteUbergraph_UI_Component_Keyboard
	// Flags: [Final|UbergraphFunction|HasDefaults]
	void ExecuteUbergraph_UI_Component_Keyboard(int32_t EntryPoint); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x4)
};

