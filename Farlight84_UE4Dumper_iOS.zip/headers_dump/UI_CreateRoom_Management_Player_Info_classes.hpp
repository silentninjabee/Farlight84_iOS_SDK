#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_CreateRoom_Management_Player_Info.UI_CreateRoom_Management_Player_Info_C
// Size: 0x401 // Inherited bytes: 0x340
struct UUI_CreateRoom_Management_Player_Info_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x340 // Size: 0x08
	struct UButton* Btn_Delete; // Offset: 0x348 // Size: 0x08
	struct UButton* Btn_Portrait; // Offset: 0x350 // Size: 0x08
	struct USolarImage* Img_Frame; // Offset: 0x358 // Size: 0x08
	struct USolarImage* Img_Owner; // Offset: 0x360 // Size: 0x08
	struct USolarImage* Img_Portrait; // Offset: 0x368 // Size: 0x08
	struct USolarImage* Img_Selected; // Offset: 0x370 // Size: 0x08
	struct UOverlay* Overlay_Change; // Offset: 0x378 // Size: 0x08
	struct UOverlay* Overlay_Closed; // Offset: 0x380 // Size: 0x08
	struct UCanvasPanel* Overlay_Delete; // Offset: 0x388 // Size: 0x08
	struct UOverlay* Overlay_Locked; // Offset: 0x390 // Size: 0x08
	struct UOverlay* Overlay_Owner; // Offset: 0x398 // Size: 0x08
	struct UOverlay* Overlay_Portrait; // Offset: 0x3a0 // Size: 0x08
	struct UOverlay* overlay_yourself; // Offset: 0x3a8 // Size: 0x08
	struct UCanvasPanel* Panel_Name; // Offset: 0x3b0 // Size: 0x08
	struct USolarTextBlock* Txt_PlayerName; // Offset: 0x3b8 // Size: 0x08
	struct USolarTextBlock* Txt_YourSelf; // Offset: 0x3c0 // Size: 0x08
	struct UUI_Anim_Waiting_C* UI_Anim_Waiting; // Offset: 0x3c8 // Size: 0x08
	struct UUI_Component_PlayerHead_C* UI_Component_PlayerHead; // Offset: 0x3d0 // Size: 0x08
	bool Locked; // Offset: 0x3d8 // Size: 0x01
	bool Selected; // Offset: 0x3d9 // Size: 0x01
	bool Owner; // Offset: 0x3da // Size: 0x01
	bool Change_Btn; // Offset: 0x3db // Size: 0x01
	bool Delete_Btn; // Offset: 0x3dc // Size: 0x01
	char pad_0x3DD[0x3]; // Offset: 0x3dd // Size: 0x03
	struct FString Current_Player_ID; // Offset: 0x3e0 // Size: 0x10
	struct UUI_CreateRoom_Management_Team_C* Team UI Ref; // Offset: 0x3f0 // Size: 0x08
	bool Yourself; // Offset: 0x3f8 // Size: 0x01
	bool Closed; // Offset: 0x3f9 // Size: 0x01
	bool Waiting; // Offset: 0x3fa // Size: 0x01
	char pad_0x3FB[0x1]; // Offset: 0x3fb // Size: 0x01
	int32_t PosIndex; // Offset: 0x3fc // Size: 0x04
	enum class ERoomModeType RoomMode; // Offset: 0x400 // Size: 0x01

	// Functions

	// Object Name: Function UI_CreateRoom_Management_Player_Info.UI_CreateRoom_Management_Player_Info_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	struct FString GetModuleName(); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UI_CreateRoom_Management_Player_Info.UI_CreateRoom_Management_Player_Info_C.RestoreSelcetion
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void RestoreSelcetion(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_CreateRoom_Management_Player_Info.UI_CreateRoom_Management_Player_Info_C.SetSelectedState
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetSelectedState(bool bSelected); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_CreateRoom_Management_Player_Info.UI_CreateRoom_Management_Player_Info_C.SetDeleteState
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetDeleteState(bool bDelete); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_CreateRoom_Management_Player_Info.UI_CreateRoom_Management_Player_Info_C.SetChangeState
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetChangeState(bool bChange); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_CreateRoom_Management_Player_Info.UI_CreateRoom_Management_Player_Info_C.RefreshState
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void RefreshState(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_CreateRoom_Management_Player_Info.UI_CreateRoom_Management_Player_Info_C.CallLuaRefreshByPS
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void CallLuaRefreshByPS(struct ASCMPlayerState* PS); // Offset: 0x10135fdbc // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UI_CreateRoom_Management_Player_Info.UI_CreateRoom_Management_Player_Info_C.GetClickedEnable
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void GetClickedEnable(bool& Enable); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_CreateRoom_Management_Player_Info.UI_CreateRoom_Management_Player_Info_C.Setup State
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void Setup State(bool Locked, bool Selected, bool Owner, bool Change_Btn, bool Delete_Btn, bool Yourself, bool Closed, bool Waiting); // Offset: 0x102f67d18 // Return & Params: Num(8) Size(0x8)

	// Object Name: Function UI_CreateRoom_Management_Player_Info.UI_CreateRoom_Management_Player_Info_C.BP_OnEntryReleased
	// Flags: [Event|Protected|BlueprintEvent]
	void BP_OnEntryReleased(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_CreateRoom_Management_Player_Info.UI_CreateRoom_Management_Player_Info_C.BP_OnItemExpansionChanged
	// Flags: [Event|Protected|BlueprintEvent]
	void BP_OnItemExpansionChanged(bool bIsExpanded); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_CreateRoom_Management_Player_Info.UI_CreateRoom_Management_Player_Info_C.BP_OnItemSelectionChanged
	// Flags: [Event|Protected|BlueprintEvent]
	void BP_OnItemSelectionChanged(bool bIsSelected); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_CreateRoom_Management_Player_Info.UI_CreateRoom_Management_Player_Info_C.OnListItemObjectSet
	// Flags: [Event|Protected|BlueprintEvent]
	void OnListItemObjectSet(struct UObject* ListItemObject); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UI_CreateRoom_Management_Player_Info.UI_CreateRoom_Management_Player_Info_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void PreConstruct(bool IsDesignTime); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_CreateRoom_Management_Player_Info.UI_CreateRoom_Management_Player_Info_C.BndEvt__Btn_Portrait_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature
	// Flags: [BlueprintEvent]
	void BndEvt__Btn_Portrait_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_CreateRoom_Management_Player_Info.UI_CreateRoom_Management_Player_Info_C.BndEvt__Btn_Delete_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature
	// Flags: [BlueprintEvent]
	void BndEvt__Btn_Delete_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_CreateRoom_Management_Player_Info.UI_CreateRoom_Management_Player_Info_C.ExecuteUbergraph_UI_CreateRoom_Management_Player_Info
	// Flags: [Final|UbergraphFunction|HasDefaults]
	void ExecuteUbergraph_UI_CreateRoom_Management_Player_Info(int32_t EntryPoint); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x4)
};

