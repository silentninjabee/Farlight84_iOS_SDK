#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_CreateRoom_Management_Team_1M.UI_CreateRoom_Management_Team_1M_C
// Size: 0x418 // Inherited bytes: 0x3d1
struct UUI_CreateRoom_Management_Team_1M_C : UUI_CreateRoom_Management_Team_C {
	// Fields
	char pad_0x3D1[0x7]; // Offset: 0x3d1 // Size: 0x07
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x3d8 // Size: 0x08
	struct UHorizontalBox* HorizontalBox_4; // Offset: 0x3e0 // Size: 0x08
	struct UCanvasPanel* Panel_Owner; // Offset: 0x3e8 // Size: 0x08
	struct UOverlay* Panel_Team_2; // Offset: 0x3f0 // Size: 0x08
	struct USolarTextBlock* Txt_SideName_P1; // Offset: 0x3f8 // Size: 0x08
	struct USolarTextBlock* Txt_SideName_P2_2; // Offset: 0x400 // Size: 0x08
	struct UUI_CreateRoom_Management_Player_Info_C* UI_CreateRoom_Management_Player_Info; // Offset: 0x408 // Size: 0x08
	struct UWidgetSwitcher* WidgetSwitcher_IsOwner; // Offset: 0x410 // Size: 0x08

	// Functions

	// Object Name: Function UI_CreateRoom_Management_Team_1M.UI_CreateRoom_Management_Team_1M_C.Get UI Refs from Panel
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void Get UI Refs from Panel(struct UWidget*& Horizontal Box Ref, struct UWidgetSwitcher*& WidgetSwitcher_IsOwner); // Offset: 0x102f67d18 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UI_CreateRoom_Management_Team_1M.UI_CreateRoom_Management_Team_1M_C.Get SideText by Panel
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void Get SideText by Panel(struct USolarTextBlock*& Target Panel); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UI_CreateRoom_Management_Team_1M.UI_CreateRoom_Management_Team_1M_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void PreConstruct(bool IsDesignTime); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_CreateRoom_Management_Team_1M.UI_CreateRoom_Management_Team_1M_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Construct(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_CreateRoom_Management_Team_1M.UI_CreateRoom_Management_Team_1M_C.ExecuteUbergraph_UI_CreateRoom_Management_Team_1M
	// Flags: [Final|UbergraphFunction|HasDefaults]
	void ExecuteUbergraph_UI_CreateRoom_Management_Team_1M(int32_t EntryPoint); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x4)
};

