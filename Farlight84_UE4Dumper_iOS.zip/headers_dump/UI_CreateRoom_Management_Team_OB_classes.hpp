#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_CreateRoom_Management_Team_OB.UI_CreateRoom_Management_Team_OB_C
// Size: 0x428 // Inherited bytes: 0x3d1
struct UUI_CreateRoom_Management_Team_OB_C : UUI_CreateRoom_Management_Team_C {
	// Fields
	char pad_0x3D1[0x7]; // Offset: 0x3d1 // Size: 0x07
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x3d8 // Size: 0x08
	struct UOverlay* Panel_Spectator; // Offset: 0x3e0 // Size: 0x08
	struct UUI_CreateRoom_Management_Player_Info_C* UI_CreateRoom_Management_Player_Info_2; // Offset: 0x3e8 // Size: 0x08
	struct UUI_CreateRoom_Management_Player_Info_C* UI_CreateRoom_Management_Player_Info_3; // Offset: 0x3f0 // Size: 0x08
	struct UUI_CreateRoom_Management_Player_Info_C* UI_CreateRoom_Management_Player_Info_4; // Offset: 0x3f8 // Size: 0x08
	struct UUI_CreateRoom_Management_Player_Info_C* UI_CreateRoom_Management_Player_Info_5; // Offset: 0x400 // Size: 0x08
	struct UUI_CreateRoom_Management_Player_Info_C* UI_CreateRoom_Management_Player_Info_6; // Offset: 0x408 // Size: 0x08
	struct UUI_CreateRoom_Management_Player_Info_C* UI_CreateRoom_Management_Player_Info_7; // Offset: 0x410 // Size: 0x08
	struct UUI_CreateRoom_Management_Player_Info_C* UI_CreateRoom_Management_Player_Info_8; // Offset: 0x418 // Size: 0x08
	struct UUI_CreateRoom_Management_Player_Info_C* UI_CreateRoom_Management_Player_Info_9; // Offset: 0x420 // Size: 0x08

	// Functions

	// Object Name: Function UI_CreateRoom_Management_Team_OB.UI_CreateRoom_Management_Team_OB_C.UpdateOB
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void UpdateOB(struct TArray<struct ASCMPlayerState*>& PlayerStateList); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UI_CreateRoom_Management_Team_OB.UI_CreateRoom_Management_Team_OB_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void PreConstruct(bool IsDesignTime); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_CreateRoom_Management_Team_OB.UI_CreateRoom_Management_Team_OB_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Construct(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_CreateRoom_Management_Team_OB.UI_CreateRoom_Management_Team_OB_C.ExecuteUbergraph_UI_CreateRoom_Management_Team_OB
	// Flags: [Final|UbergraphFunction|HasDefaults]
	void ExecuteUbergraph_UI_CreateRoom_Management_Team_OB(int32_t EntryPoint); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x4)
};

