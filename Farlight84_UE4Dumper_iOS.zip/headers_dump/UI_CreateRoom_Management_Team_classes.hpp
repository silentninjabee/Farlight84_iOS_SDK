#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_CreateRoom_Management_Team.UI_CreateRoom_Management_Team_C
// Size: 0x3d1 // Inherited bytes: 0x340
struct UUI_CreateRoom_Management_Team_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x340 // Size: 0x08
	bool Team_Owner; // Offset: 0x348 // Size: 0x01
	bool Locked; // Offset: 0x349 // Size: 0x01
	char pad_0x34A[0x6]; // Offset: 0x34a // Size: 0x06
	struct FString SideName; // Offset: 0x350 // Size: 0x10
	struct TArray<struct FString> SolarPlayerId; // Offset: 0x360 // Size: 0x10
	enum class ENUM_RoomSlotType Initial State; // Offset: 0x370 // Size: 0x01
	bool HUD Initialized; // Offset: 0x371 // Size: 0x01
	bool bIsOB; // Offset: 0x372 // Size: 0x01
	char pad_0x373[0x5]; // Offset: 0x373 // Size: 0x05
	struct TArray<struct UUI_CreateRoom_Management_Player_Info_C*> Player Info Widget List; // Offset: 0x378 // Size: 0x10
	int32_t MaxOBCount; // Offset: 0x388 // Size: 0x04
	char pad_0x38C[0x4]; // Offset: 0x38c // Size: 0x04
	struct FMulticastInlineDelegate OnSlotClicked; // Offset: 0x390 // Size: 0x10
	struct FMulticastInlineDelegate OnDeleteClicked; // Offset: 0x3a0 // Size: 0x10
	struct FMulticastInlineDelegate OnTeamUpdated; // Offset: 0x3b0 // Size: 0x10
	struct FString Room Master Player ID; // Offset: 0x3c0 // Size: 0x10
	enum class ERoomModeType RoomMode; // Offset: 0x3d0 // Size: 0x01

	// Functions

	// Object Name: Function UI_CreateRoom_Management_Team.UI_CreateRoom_Management_Team_C.IsPreJobInThePos
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void IsPreJobInThePos(struct TArray<struct ASCMPlayerState*>& PreJob, int32_t Pos, bool& _Have); // Offset: 0x102f67d18 // Return & Params: Num(3) Size(0x15)

	// Object Name: Function UI_CreateRoom_Management_Team.UI_CreateRoom_Management_Team_C.IsPlayerInThePos
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void IsPlayerInThePos(struct TArray<struct ASCMPlayerState*>& PS, int32_t Pos, bool& _Have, struct ASCMPlayerState*& _OutPS); // Offset: 0x102f67d18 // Return & Params: Num(4) Size(0x20)

	// Object Name: Function UI_CreateRoom_Management_Team.UI_CreateRoom_Management_Team_C.CanBeSelected
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void CanBeSelected(struct FString SelectedPlayer, bool& bResult); // Offset: 0x102f67d18 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function UI_CreateRoom_Management_Team.UI_CreateRoom_Management_Team_C.Get UI Refs from Panel
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void Get UI Refs from Panel(struct UWidget*& Horizontal Box Ref, struct UWidgetSwitcher*& WidgetSwitcher_IsOwner); // Offset: 0x102f67d18 // Return & Params: Num(2) Size(0x10)

	// Object Name: Function UI_CreateRoom_Management_Team.UI_CreateRoom_Management_Team_C.InitOBCount
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void InitOBCount(int32_t count, enum class ERoomModeType RoomMode); // Offset: 0x102f67d18 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function UI_CreateRoom_Management_Team.UI_CreateRoom_Management_Team_C.Try Update Team Widget
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	void Try Update Team Widget(struct TArray<struct ASCMPlayerState*>& Updated Player List, struct TArray<struct UUI_CreateRoom_Management_Player_Info_C*>& Player Info Widget List); // Offset: 0x102f67d18 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function UI_CreateRoom_Management_Team.UI_CreateRoom_Management_Team_C.Get SideText by Panel
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void Get SideText by Panel(struct USolarTextBlock*& Target Panel); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UI_CreateRoom_Management_Team.UI_CreateRoom_Management_Team_C.Init Data
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void Init Data(struct FString Side Name, enum class ENUM_RoomSlotType Init State); // Offset: 0x102f67d18 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function UI_CreateRoom_Management_Team.UI_CreateRoom_Management_Team_C.Set State
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void Set State(bool Team Owner, bool Locked); // Offset: 0x102f67d18 // Return & Params: Num(2) Size(0x2)

	// Object Name: Function UI_CreateRoom_Management_Team.UI_CreateRoom_Management_Team_C.BP_OnEntryReleased
	// Flags: [Event|Protected|BlueprintEvent]
	void BP_OnEntryReleased(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_CreateRoom_Management_Team.UI_CreateRoom_Management_Team_C.BP_OnItemExpansionChanged
	// Flags: [Event|Protected|BlueprintEvent]
	void BP_OnItemExpansionChanged(bool bIsExpanded); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_CreateRoom_Management_Team.UI_CreateRoom_Management_Team_C.BP_OnItemSelectionChanged
	// Flags: [Event|Protected|BlueprintEvent]
	void BP_OnItemSelectionChanged(bool bIsSelected); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_CreateRoom_Management_Team.UI_CreateRoom_Management_Team_C.OnListItemObjectSet
	// Flags: [Event|Protected|BlueprintEvent]
	void OnListItemObjectSet(struct UObject* ListItemObject); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UI_CreateRoom_Management_Team.UI_CreateRoom_Management_Team_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void PreConstruct(bool IsDesignTime); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_CreateRoom_Management_Team.UI_CreateRoom_Management_Team_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Construct(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_CreateRoom_Management_Team.UI_CreateRoom_Management_Team_C.Update Team UI
	// Flags: [HasOutParms|BlueprintCallable|BlueprintEvent]
	void Update Team UI(struct TArray<struct ASCMPlayerState*>& Team Players); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UI_CreateRoom_Management_Team.UI_CreateRoom_Management_Team_C.Do Deselection
	// Flags: [BlueprintCallable|BlueprintEvent]
	void Do Deselection(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_CreateRoom_Management_Team.UI_CreateRoom_Management_Team_C.Portrait Clicked
	// Flags: [BlueprintCallable|BlueprintEvent]
	void Portrait Clicked(struct FString Solar Player ID, int32_t PosIndex, struct UUI_CreateRoom_Management_Player_Info_C* InfoWidget); // Offset: 0x102f67d18 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function UI_CreateRoom_Management_Team.UI_CreateRoom_Management_Team_C.Delete Clicked
	// Flags: [BlueprintCallable|BlueprintEvent]
	void Delete Clicked(struct FString Solar Player ID); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UI_CreateRoom_Management_Team.UI_CreateRoom_Management_Team_C.Do Selection
	// Flags: [BlueprintCallable|BlueprintEvent]
	void Do Selection(bool SelectedOB, struct UUI_CreateRoom_Management_Player_Info_C* SelectedInfoWidget, struct FString SelectedSide); // Offset: 0x102f67d18 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function UI_CreateRoom_Management_Team.UI_CreateRoom_Management_Team_C.Init OB UI
	// Flags: [BlueprintCallable|BlueprintEvent]
	void Init OB UI(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_CreateRoom_Management_Team.UI_CreateRoom_Management_Team_C.ExecuteUbergraph_UI_CreateRoom_Management_Team
	// Flags: [Final|UbergraphFunction|HasDefaults]
	void ExecuteUbergraph_UI_CreateRoom_Management_Team(int32_t EntryPoint); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UI_CreateRoom_Management_Team.UI_CreateRoom_Management_Team_C.OnTeamUpdated__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void OnTeamUpdated__DelegateSignature(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_CreateRoom_Management_Team.UI_CreateRoom_Management_Team_C.OnDeleteClicked__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void OnDeleteClicked__DelegateSignature(struct FString Clicked Player, struct FString Clicked Side); // Offset: 0x102f67d18 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function UI_CreateRoom_Management_Team.UI_CreateRoom_Management_Team_C.OnSlotClicked__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void OnSlotClicked__DelegateSignature(struct FString Clicked Player, struct FString Clicked Side, bool Is OB, int32_t PosIndex, struct UUI_CreateRoom_Management_Team_C* TeamWidget, struct UUI_CreateRoom_Management_Player_Info_C* InfoWidget); // Offset: 0x102f67d18 // Return & Params: Num(6) Size(0x38)
};

