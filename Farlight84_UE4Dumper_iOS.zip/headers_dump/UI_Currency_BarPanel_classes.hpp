#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_Currency_BarPanel.UI_Currency_BarPanel_C
// Size: 0x348 // Inherited bytes: 0x340
struct UUI_Currency_BarPanel_C : USolarUserWidget {
	// Fields
	struct UUI_Currency_Bar_C* UI_Currency_Bar; // Offset: 0x340 // Size: 0x08

	// Functions

	// Object Name: Function UI_Currency_BarPanel.UI_Currency_BarPanel_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	struct FString GetModuleName(); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x10)
};

