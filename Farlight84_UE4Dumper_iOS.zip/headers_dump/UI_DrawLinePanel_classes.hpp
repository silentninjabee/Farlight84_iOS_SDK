#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_DrawLinePanel.UI_DrawLinePanel_C
// Size: 0x448 // Inherited bytes: 0x448
struct UUI_DrawLinePanel_C : UDrawLinePanel {
};

