#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_HUD_Notice_CutIn_Normal.UI_HUD_Notice_CutIn_Normal_C
// Size: 0x288 // Inherited bytes: 0x260
struct UUI_HUD_Notice_CutIn_Normal_C : UUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x260 // Size: 0x08
	struct UWidgetAnimation* ant_exit; // Offset: 0x268 // Size: 0x08
	struct UWidgetAnimation* Loop_Noya_Anim; // Offset: 0x270 // Size: 0x08
	struct UWidgetAnimation* Appear_Anim; // Offset: 0x278 // Size: 0x08
	struct USolarTextBlock* Txt_Nova; // Offset: 0x280 // Size: 0x08

	// Functions

	// Object Name: Function UI_HUD_Notice_CutIn_Normal.UI_HUD_Notice_CutIn_Normal_C.Close
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void Close(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_HUD_Notice_CutIn_Normal.UI_HUD_Notice_CutIn_Normal_C.Show
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void Show(struct FString ); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UI_HUD_Notice_CutIn_Normal.UI_HUD_Notice_CutIn_Normal_C.ExecuteUbergraph_UI_HUD_Notice_CutIn_Normal
	// Flags: [Final|UbergraphFunction|HasDefaults]
	void ExecuteUbergraph_UI_HUD_Notice_CutIn_Normal(int32_t EntryPoint); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x4)
};

