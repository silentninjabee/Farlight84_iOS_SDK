#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_HUD_Notice_Lv2.UI_HUD_Notice_Lv2_C
// Size: 0x3a0 // Inherited bytes: 0x368
struct UUI_HUD_Notice_Lv2_C : UUI_NoticeBase_C {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x368 // Size: 0x08
	struct UWidgetAnimation* ant_exit; // Offset: 0x370 // Size: 0x08
	struct UWidgetAnimation* Appear_Anim; // Offset: 0x378 // Size: 0x08
	struct UImage* Img_Icon; // Offset: 0x380 // Size: 0x08
	struct UImage* Img_Icon_bg; // Offset: 0x388 // Size: 0x08
	struct UImage* Img_Txt_bg; // Offset: 0x390 // Size: 0x08
	struct USolarRichTextBlock* Txt_Ballte_Notice; // Offset: 0x398 // Size: 0x08

	// Functions

	// Object Name: Function UI_HUD_Notice_Lv2.UI_HUD_Notice_Lv2_C.GetExitAnimation
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	struct UWidgetAnimation* GetExitAnimation(); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UI_HUD_Notice_Lv2.UI_HUD_Notice_Lv2_C.GetEnterAnimation
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	struct UWidgetAnimation* GetEnterAnimation(); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function UI_HUD_Notice_Lv2.UI_HUD_Notice_Lv2_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Construct(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_HUD_Notice_Lv2.UI_HUD_Notice_Lv2_C.ExecuteUbergraph_UI_HUD_Notice_Lv2
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_UI_HUD_Notice_Lv2(int32_t EntryPoint); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x4)
};

