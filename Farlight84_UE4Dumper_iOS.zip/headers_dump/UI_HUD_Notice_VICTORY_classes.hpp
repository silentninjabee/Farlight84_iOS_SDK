#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_HUD_Notice_VICTORY.UI_HUD_Notice_VICTORY_C
// Size: 0x43c // Inherited bytes: 0x418
struct UUI_HUD_Notice_VICTORY_C : UUINoticeVictory {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x418 // Size: 0x08
	struct UWidgetAnimation* Appear_Anim; // Offset: 0x420 // Size: 0x08
	struct UButton* Btn_Return; // Offset: 0x428 // Size: 0x08
	struct USolarTextBlock* Txt_Ballte_Notice; // Offset: 0x430 // Size: 0x08
	int32_t CountDownTime; // Offset: 0x438 // Size: 0x04

	// Functions

	// Object Name: Function UI_HUD_Notice_VICTORY.UI_HUD_Notice_VICTORY_C.GetModuleName
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	struct FString GetModuleName(); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UI_HUD_Notice_VICTORY.UI_HUD_Notice_VICTORY_C.ShowVictory
	// Flags: [BlueprintCallable|BlueprintEvent]
	void ShowVictory(int32_t Time); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UI_HUD_Notice_VICTORY.UI_HUD_Notice_VICTORY_C.Tick Till End
	// Flags: [BlueprintCallable|BlueprintEvent]
	void Tick Till End(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_HUD_Notice_VICTORY.UI_HUD_Notice_VICTORY_C.ExecuteUbergraph_UI_HUD_Notice_VICTORY
	// Flags: [Final|UbergraphFunction|HasDefaults]
	void ExecuteUbergraph_UI_HUD_Notice_VICTORY(int32_t EntryPoint); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x4)
};

