#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_Lobby_Battery.UI_Lobby_Battery_C
// Size: 0x4d8 // Inherited bytes: 0x260
struct UUI_Lobby_Battery_C : UUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x260 // Size: 0x08
	struct UImage* Img_Charging; // Offset: 0x268 // Size: 0x08
	struct UProgressBar* ProgressBar_Battery; // Offset: 0x270 // Size: 0x08
	struct FSlateBrush ProgressBarBgImage; // Offset: 0x278 // Size: 0x98
	struct FSlateBrush ProgressBarMarqueeImage; // Offset: 0x310 // Size: 0x98
	struct FSlateBrush ProgressBarFillNormal; // Offset: 0x3a8 // Size: 0x98
	struct FSlateBrush ProgressBarFillCharging; // Offset: 0x440 // Size: 0x98

	// Functions

	// Object Name: Function UI_Lobby_Battery.UI_Lobby_Battery_C.ForceRefreshBatteryUI
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void ForceRefreshBatteryUI(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Lobby_Battery.UI_Lobby_Battery_C.RefreshBatteryUI
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void RefreshBatteryUI(int32_t BatteryLevelNewParam, bool bCharging); // Offset: 0x102f67d18 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function UI_Lobby_Battery.UI_Lobby_Battery_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void PreConstruct(bool IsDesignTime); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Lobby_Battery.UI_Lobby_Battery_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Construct(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Lobby_Battery.UI_Lobby_Battery_C.EventRefreshBatteryUI
	// Flags: [BlueprintCallable|BlueprintEvent]
	void EventRefreshBatteryUI(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Lobby_Battery.UI_Lobby_Battery_C.Destruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Destruct(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Lobby_Battery.UI_Lobby_Battery_C.ExecuteUbergraph_UI_Lobby_Battery
	// Flags: [Final|UbergraphFunction|HasDefaults]
	void ExecuteUbergraph_UI_Lobby_Battery(int32_t EntryPoint); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x4)
};

