#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_Lobby_Invite_Btn.UI_Lobby_Invite_Btn_C
// Size: 0x348 // Inherited bytes: 0x340
struct UUI_Lobby_Invite_Btn_C : USolarUserWidget {
	// Fields
	struct UButton* Btn_Invite; // Offset: 0x340 // Size: 0x08
};

