#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_Lobby_Mention_Container.UI_Lobby_Mention_Container_C
// Size: 0x368 // Inherited bytes: 0x340
struct UUI_Lobby_Mention_Container_C : USolarUserWidget {
	// Fields
	struct UCanvasPanel* Adapter; // Offset: 0x340 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_Container; // Offset: 0x348 // Size: 0x08
	struct UCanvasPanel* Panel; // Offset: 0x350 // Size: 0x08
	struct UUI_Lobby_RoomInvite_MIni_Popup_C* UI_Lobby_RoomInvite_MIni_Popup; // Offset: 0x358 // Size: 0x08
	struct UUI_Lobby_TeamInvite_Mini_Popup_C* UI_Lobby_TeamInvite_MIni_Popup; // Offset: 0x360 // Size: 0x08

	// Functions

	// Object Name: Function UI_Lobby_Mention_Container.UI_Lobby_Mention_Container_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	struct FString GetModuleName(); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x10)
};

