#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_Lobby_Profession.UI_Lobby_Profession_C
// Size: 0x380 // Inherited bytes: 0x340
struct UUI_Lobby_Profession_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x340 // Size: 0x08
	struct USolarButton* Btn_Change; // Offset: 0x348 // Size: 0x08
	struct UImage* Img_Icon; // Offset: 0x350 // Size: 0x08
	struct UImage* img_iconBg; // Offset: 0x358 // Size: 0x08
	struct UImage* img_iconBorder; // Offset: 0x360 // Size: 0x08
	struct UImage* img_iconBorder_2; // Offset: 0x368 // Size: 0x08
	struct UOverlay* Overlay_2; // Offset: 0x370 // Size: 0x08
	bool Myself; // Offset: 0x378 // Size: 0x01
	enum class E_ProfessionType ProfessionType; // Offset: 0x379 // Size: 0x01
	char pad_0x37A[0x2]; // Offset: 0x37a // Size: 0x02
	int32_t Index; // Offset: 0x37c // Size: 0x04

	// Functions

	// Object Name: Function UI_Lobby_Profession.UI_Lobby_Profession_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	struct FString GetModuleName(); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UI_Lobby_Profession.UI_Lobby_Profession_C.SetSelection
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetSelection(char Index); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Lobby_Profession.UI_Lobby_Profession_C.UpdateState
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void UpdateState(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Lobby_Profession.UI_Lobby_Profession_C.Render
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void Render(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Lobby_Profession.UI_Lobby_Profession_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void PreConstruct(bool IsDesignTime); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Lobby_Profession.UI_Lobby_Profession_C.ExecuteUbergraph_UI_Lobby_Profession
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_UI_Lobby_Profession(int32_t EntryPoint); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x4)
};

