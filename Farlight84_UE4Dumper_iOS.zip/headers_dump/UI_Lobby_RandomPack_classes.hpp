#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_Lobby_RandomPack.UI_Lobby_RandomPack_C
// Size: 0x388 // Inherited bytes: 0x340
struct UUI_Lobby_RandomPack_C : USolarUserWidget {
	// Fields
	struct UWidgetAnimation* Enter_Anim; // Offset: 0x340 // Size: 0x08
	struct USolarButton* Btn_RandomPack; // Offset: 0x348 // Size: 0x08
	struct UCanvasPanel* Bubble; // Offset: 0x350 // Size: 0x08
	struct UHorizontalBox* Bubble_ToBeClaimed; // Offset: 0x358 // Size: 0x08
	struct UImage* Img_XELB; // Offset: 0x360 // Size: 0x08
	struct UCanvasPanel* Panel_VX; // Offset: 0x368 // Size: 0x08
	struct USolarRedHint_General_C* SolarRedHint_General; // Offset: 0x370 // Size: 0x08
	struct UTickerWidget_C* Txt_Reminder; // Offset: 0x378 // Size: 0x08
	struct UTickerWidget_C* Txt_ToBeClaimed; // Offset: 0x380 // Size: 0x08

	// Functions

	// Object Name: Function UI_Lobby_RandomPack.UI_Lobby_RandomPack_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	struct FString GetModuleName(); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x10)
};

