#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C
// Size: 0x3bd // Inherited bytes: 0x340
struct UUI_Lobby_TeamMember_Operation_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x340 // Size: 0x08
	struct USolarButton* Btn_QuitTeam; // Offset: 0x348 // Size: 0x08
	struct USolarButton* Btn_ShowOperationPanel; // Offset: 0x350 // Size: 0x08
	struct UImage* Img_AppDeactivated_Mark; // Offset: 0x358 // Size: 0x08
	struct UImage* img_Captain; // Offset: 0x360 // Size: 0x08
	struct UImage* Img_Captain_Bg; // Offset: 0x368 // Size: 0x08
	struct UImage* Img_Captain_Bg1; // Offset: 0x370 // Size: 0x08
	struct UImage* Img_Captain_Bg2; // Offset: 0x378 // Size: 0x08
	struct UImage* Img_Captain_Mark; // Offset: 0x380 // Size: 0x08
	struct UImage* Img_MicroPhone_Mark; // Offset: 0x388 // Size: 0x08
	struct UImage* Img_Platform; // Offset: 0x390 // Size: 0x08
	struct UOverlay* Img_Ready_Mark; // Offset: 0x398 // Size: 0x08
	struct UCanvasPanel* Panel_Captain; // Offset: 0x3a0 // Size: 0x08
	struct USolarTextBlock* Text_NickName; // Offset: 0x3a8 // Size: 0x08
	struct UUI_Component_NationalFlag_C* UI_Component_NationalFlag; // Offset: 0x3b0 // Size: 0x08
	int32_t IndexInLobby; // Offset: 0x3b8 // Size: 0x04
	bool Steam; // Offset: 0x3bc // Size: 0x01

	// Functions

	// Object Name: Function UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	struct FString GetModuleName(); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.SetPlatform
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetPlatform(bool Steam); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void PreConstruct(bool IsDesignTime); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Construct(); // Offset: 0x10135fdbc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Lobby_TeamMember_Operation.UI_Lobby_TeamMember_Operation_C.ExecuteUbergraph_UI_Lobby_TeamMember_Operation
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_UI_Lobby_TeamMember_Operation(int32_t EntryPoint); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x4)
};

