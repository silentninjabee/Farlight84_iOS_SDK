#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_Lobby_Topup.UI_Lobby_Topup_C
// Size: 0x278 // Inherited bytes: 0x260
struct UUI_Lobby_Topup_C : UUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x260 // Size: 0x08
	struct UWidgetAnimation* Loop_Anim; // Offset: 0x268 // Size: 0x08
	struct UParticleSystemWidget* ParticleSystemWidget_29; // Offset: 0x270 // Size: 0x08

	// Functions

	// Object Name: Function UI_Lobby_Topup.UI_Lobby_Topup_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void PreConstruct(bool IsDesignTime); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Lobby_Topup.UI_Lobby_Topup_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Construct(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Lobby_Topup.UI_Lobby_Topup_C.ExecuteUbergraph_UI_Lobby_Topup
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_UI_Lobby_Topup(int32_t EntryPoint); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x4)
};

