#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_Lobby.UI_Lobby_C
// Size: 0x858 // Inherited bytes: 0x390
struct UUI_Lobby_C : USolarPanelWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x390 // Size: 0x08
	struct UWidgetAnimation* Anim_Loop; // Offset: 0x398 // Size: 0x08
	struct UWidgetAnimation* Anim_Enter; // Offset: 0x3a0 // Size: 0x08
	struct UCanvasPanel* Adapter; // Offset: 0x3a8 // Size: 0x08
	struct USolarButton* Btn_Activity; // Offset: 0x3b0 // Size: 0x08
	struct UButton* Btn_Character; // Offset: 0x3b8 // Size: 0x08
	struct UButton* Btn_Clan; // Offset: 0x3c0 // Size: 0x08
	struct UButton* Btn_Collection; // Offset: 0x3c8 // Size: 0x08
	struct UButton* Btn_Leaderboard; // Offset: 0x3d0 // Size: 0x08
	struct UButton* Btn_MailBox; // Offset: 0x3d8 // Size: 0x08
	struct USolarButton* Btn_MatchRoom; // Offset: 0x3e0 // Size: 0x08
	struct UButton* Btn_More; // Offset: 0x3e8 // Size: 0x08
	struct UButton* Btn_PopupLayer; // Offset: 0x3f0 // Size: 0x08
	struct UButton* Btn_Raffle; // Offset: 0x3f8 // Size: 0x08
	struct USolarButton* Btn_Rank; // Offset: 0x400 // Size: 0x08
	struct UButton* Btn_Settings; // Offset: 0x408 // Size: 0x08
	struct USolarButton* Btn_Shop; // Offset: 0x410 // Size: 0x08
	struct UButton* Btn_Social; // Offset: 0x418 // Size: 0x08
	struct UButton* Btn_Task; // Offset: 0x420 // Size: 0x08
	struct UButton* Btn_Topup; // Offset: 0x428 // Size: 0x08
	struct UButton* Btn_Tournament; // Offset: 0x430 // Size: 0x08
	struct UBtn_Unlock_Anim_1_C* Btn_Unlock_Anim_Activity; // Offset: 0x438 // Size: 0x08
	struct UBtn_Unlock_Anim_1_C* Btn_Unlock_Anim_Clan; // Offset: 0x440 // Size: 0x08
	struct UBtn_Unlock_Anim_1_C* Btn_Unlock_Anim_Collection; // Offset: 0x448 // Size: 0x08
	struct UBtn_Unlock_Anim_1_C* Btn_Unlock_Anim_Heros; // Offset: 0x450 // Size: 0x08
	struct UBtn_Unlock_Anim_1_C* Btn_Unlock_Anim_Leaderboard; // Offset: 0x458 // Size: 0x08
	struct UBtn_Unlock_Anim_1_C* Btn_Unlock_Anim_Raffle; // Offset: 0x460 // Size: 0x08
	struct UBtn_Unlock_Anim_1_C* Btn_Unlock_Anim_Rank; // Offset: 0x468 // Size: 0x08
	struct UBtn_Unlock_Anim_1_C* Btn_Unlock_Anim_Shop; // Offset: 0x470 // Size: 0x08
	struct UBtn_Unlock_Anim_1_C* Btn_Unlock_Anim_SupplyBox; // Offset: 0x478 // Size: 0x08
	struct UBtn_Unlock_Anim_1_C* Btn_Unlock_Anim_Task; // Offset: 0x480 // Size: 0x08
	struct UBtn_Unlock_Anim_1_C* Btn_Unlock_Anim_Tournament; // Offset: 0x488 // Size: 0x08
	struct USolarButton* Button_Emoji; // Offset: 0x490 // Size: 0x08
	struct USolarButton* Button_Emoji_Close; // Offset: 0x498 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_Container; // Offset: 0x4a0 // Size: 0x08
	struct UUI_Warehouse_DragPanel_C* DragPanel_2; // Offset: 0x4a8 // Size: 0x08
	struct UUI_Warehouse_DragPanel_C* DragPanel_3; // Offset: 0x4b0 // Size: 0x08
	struct UUI_Warehouse_DragPanel_C* DragPanel_4; // Offset: 0x4b8 // Size: 0x08
	struct UUI_Warehouse_DragPanel_C* DragPanel_5; // Offset: 0x4c0 // Size: 0x08
	struct UUI_Component_Emoji_List_C* Emoji_List; // Offset: 0x4c8 // Size: 0x08
	struct USolarCheckBox* EmojiBtn; // Offset: 0x4d0 // Size: 0x08
	struct UScaleBox* EmoteScaleBox_2; // Offset: 0x4d8 // Size: 0x08
	struct UScaleBox* EmoteScaleBox_3; // Offset: 0x4e0 // Size: 0x08
	struct UScaleBox* EmoteScaleBox_4; // Offset: 0x4e8 // Size: 0x08
	struct UScaleBox* EmoteScaleBox_5; // Offset: 0x4f0 // Size: 0x08
	struct USolarRedHint_General_C* HintPoint_Clan; // Offset: 0x4f8 // Size: 0x08
	struct UHorizontalBox* HorizontalBox_Coin; // Offset: 0x500 // Size: 0x08
	struct UHorizontalBox* HorizontalBox_Diamond; // Offset: 0x508 // Size: 0x08
	struct UHorizontalBox* HorizontalBox_Dollar; // Offset: 0x510 // Size: 0x08
	struct UImage* Image_64; // Offset: 0x518 // Size: 0x08
	struct UImage* Img_Activity; // Offset: 0x520 // Size: 0x08
	struct UImage* Img_Clan; // Offset: 0x528 // Size: 0x08
	struct UImage* Img_Matchroom_Tips_Arrow; // Offset: 0x530 // Size: 0x08
	struct UImage* Img_Ping; // Offset: 0x538 // Size: 0x08
	struct UImage* Img_UnlockAnim; // Offset: 0x540 // Size: 0x08
	struct UOverlay* Overlay_BattlePass; // Offset: 0x548 // Size: 0x08
	struct UOverlay* Overlay_Live; // Offset: 0x550 // Size: 0x08
	struct UOverlay* Overlay_Matchroom_Tips; // Offset: 0x558 // Size: 0x08
	struct UCanvasPanel* Panel; // Offset: 0x560 // Size: 0x08
	struct UCanvasPanel* Panel_Activity; // Offset: 0x568 // Size: 0x08
	struct UCanvasPanel* Panel_ActivityContent; // Offset: 0x570 // Size: 0x08
	struct UCanvasPanel* Panel_Clan; // Offset: 0x578 // Size: 0x08
	struct UCanvasPanel* Panel_Clan_Content; // Offset: 0x580 // Size: 0x08
	struct UCanvasPanel* Panel_Collection; // Offset: 0x588 // Size: 0x08
	struct UCanvasPanel* Panel_Collection_Content; // Offset: 0x590 // Size: 0x08
	struct UCanvasPanel* Panel_Commerce; // Offset: 0x598 // Size: 0x08
	struct UCanvasPanel* Panel_Emoji; // Offset: 0x5a0 // Size: 0x08
	struct UCanvasPanel* Panel_Heros; // Offset: 0x5a8 // Size: 0x08
	struct UCanvasPanel* Panel_Heros_Content; // Offset: 0x5b0 // Size: 0x08
	struct UCanvasPanel* Panel_Invite; // Offset: 0x5b8 // Size: 0x08
	struct UCanvasPanel* Panel_Leaderboard; // Offset: 0x5c0 // Size: 0x08
	struct UCanvasPanel* Panel_Leaderboard_Content; // Offset: 0x5c8 // Size: 0x08
	struct UCanvasPanel* Panel_MailBox; // Offset: 0x5d0 // Size: 0x08
	struct UCanvasPanel* Panel_MatchRoom; // Offset: 0x5d8 // Size: 0x08
	struct UCanvasPanel* Panel_More; // Offset: 0x5e0 // Size: 0x08
	struct UCanvasPanel* Panel_Profession; // Offset: 0x5e8 // Size: 0x08
	struct UCanvasPanel* Panel_Raffle; // Offset: 0x5f0 // Size: 0x08
	struct UCanvasPanel* Panel_RaffleContent; // Offset: 0x5f8 // Size: 0x08
	struct UCanvasPanel* Panel_Rank; // Offset: 0x600 // Size: 0x08
	struct UCanvasPanel* Panel_Rank_Content; // Offset: 0x608 // Size: 0x08
	struct UCanvasPanel* Panel_RedPacket; // Offset: 0x610 // Size: 0x08
	struct UCanvasPanel* Panel_Settings; // Offset: 0x618 // Size: 0x08
	struct UCanvasPanel* Panel_Shop; // Offset: 0x620 // Size: 0x08
	struct UCanvasPanel* Panel_Shop_Content; // Offset: 0x628 // Size: 0x08
	struct UCanvasPanel* Panel_Social; // Offset: 0x630 // Size: 0x08
	struct UCanvasPanel* Panel_SupplyBox; // Offset: 0x638 // Size: 0x08
	struct UCanvasPanel* Panel_SupplyBox_Content; // Offset: 0x640 // Size: 0x08
	struct UHorizontalBox* Panel_System; // Offset: 0x648 // Size: 0x08
	struct UCanvasPanel* Panel_Task; // Offset: 0x650 // Size: 0x08
	struct UCanvasPanel* Panel_Task_Content; // Offset: 0x658 // Size: 0x08
	struct UCanvasPanel* Panel_Topup; // Offset: 0x660 // Size: 0x08
	struct UCanvasPanel* Panel_Tournament; // Offset: 0x668 // Size: 0x08
	struct UCanvasPanel* Panel_Tournament_Content; // Offset: 0x670 // Size: 0x08
	struct UCanvasPanel* PopupLayer; // Offset: 0x678 // Size: 0x08
	struct UUI_Lobby_Profession_C* Profession_2; // Offset: 0x680 // Size: 0x08
	struct UUI_Lobby_Profession_C* Profession_3; // Offset: 0x688 // Size: 0x08
	struct UUI_Lobby_Profession_C* Profession_4; // Offset: 0x690 // Size: 0x08
	struct UUI_Lobby_Profession_C* Profession_5; // Offset: 0x698 // Size: 0x08
	struct USolarRedHint_General_C* Red_Rank; // Offset: 0x6a0 // Size: 0x08
	struct USolarRedHint_General_C* Red_Shop; // Offset: 0x6a8 // Size: 0x08
	struct USolarRedHint_General_C* RedHint_Capsulers; // Offset: 0x6b0 // Size: 0x08
	struct USolarRedHint_General_C* RedHint_Collection; // Offset: 0x6b8 // Size: 0x08
	struct USolarRedHint_General_C* RedHint_E-Mail; // Offset: 0x6c0 // Size: 0x08
	struct USolarRedHint_General_C* RedHint_More; // Offset: 0x6c8 // Size: 0x08
	struct USolarRedHint_General_C* RedHint_Social; // Offset: 0x6d0 // Size: 0x08
	struct USolarRedHint_General_C* RedHint_Task; // Offset: 0x6d8 // Size: 0x08
	struct USolarRedHint_General_C* RedHint_Tournament; // Offset: 0x6e0 // Size: 0x08
	struct USolarImageURL* SolarImageURL_Icon; // Offset: 0x6e8 // Size: 0x08
	struct USolarRedHint_General_C* SolarRedHint_General; // Offset: 0x6f0 // Size: 0x08
	struct USolarRedHint_General_C* SolarRedHint_General_2; // Offset: 0x6f8 // Size: 0x08
	struct USolarRichTextBlock* SolarRichTextBlock_Stage; // Offset: 0x700 // Size: 0x08
	struct URichTextBlock* STB_RewardCoinNum; // Offset: 0x708 // Size: 0x08
	struct URichTextBlock* STB_RewardDiamondNum; // Offset: 0x710 // Size: 0x08
	struct URichTextBlock* STB_RewardDollarNum; // Offset: 0x718 // Size: 0x08
	struct UUI_Lobby_TeamMember_Operation_C* TeamMember_CallingCard_2; // Offset: 0x720 // Size: 0x08
	struct UUI_Lobby_TeamMember_Operation_C* TeamMember_CallingCard_3; // Offset: 0x728 // Size: 0x08
	struct UUI_Lobby_TeamMember_Operation_C* TeamMember_CallingCard_4; // Offset: 0x730 // Size: 0x08
	struct UUI_Lobby_TeamMember_Operation_C* TeamMember_CallingCard_5; // Offset: 0x738 // Size: 0x08
	struct UTextBlock* Text_MatchInfo; // Offset: 0x740 // Size: 0x08
	struct UTextBlock* Text_RoomInfo; // Offset: 0x748 // Size: 0x08
	struct USolarTextBlock* Txt_Clan; // Offset: 0x750 // Size: 0x08
	struct USolarTextBlock* Txt_Season; // Offset: 0x758 // Size: 0x08
	struct UUI_ChatPanel_C* UI_ChatPanel; // Offset: 0x760 // Size: 0x08
	struct UUI_Lobby_Banner_C* UI_Lobby_Banner; // Offset: 0x768 // Size: 0x08
	struct UUI_Lobby_Battery_C* UI_Lobby_Battery; // Offset: 0x770 // Size: 0x08
	struct UUI_Lobby_BattlePass_C* UI_Lobby_BattlePass; // Offset: 0x778 // Size: 0x08
	struct UUI_Lobby_BattlePass_Next_C* UI_Lobby_BattlePass_Next; // Offset: 0x780 // Size: 0x08
	struct UUI_Currency_Bar_C* UI_Lobby_Currency; // Offset: 0x788 // Size: 0x08
	struct UUI_Lobby_DownLoad_C* UI_Lobby_DownLoad; // Offset: 0x790 // Size: 0x08
	struct UUI_Lobby_GameRecommend_C* UI_Lobby_GameRecommend; // Offset: 0x798 // Size: 0x08
	struct UUI_Lobby_Invite_Btn_C* UI_Lobby_Invite_Btn_3; // Offset: 0x7a0 // Size: 0x08
	struct UUI_Lobby_Invite_Btn_C* UI_Lobby_Invite_Btn_4; // Offset: 0x7a8 // Size: 0x08
	struct UUI_Lobby_Invite_Btn_C* UI_Lobby_Invite_Btn_5; // Offset: 0x7b0 // Size: 0x08
	struct UUI_Lobby_Mainmenu_C* UI_Lobby_MainMenu; // Offset: 0x7b8 // Size: 0x08
	struct UUI_Lobby_MedalShow_C* UI_Lobby_MedalShow_2; // Offset: 0x7c0 // Size: 0x08
	struct UUI_Lobby_MedalShow_C* UI_Lobby_MedalShow_3; // Offset: 0x7c8 // Size: 0x08
	struct UUI_Lobby_MedalShow_C* UI_Lobby_MedalShow_4; // Offset: 0x7d0 // Size: 0x08
	struct UUI_Lobby_MedalShow_C* UI_Lobby_MedalShow_5; // Offset: 0x7d8 // Size: 0x08
	struct UUI_Lobby_Mission_Reward_C* UI_Lobby_Mission_Reward; // Offset: 0x7e0 // Size: 0x08
	struct UUI_Lobby_PlayerInfo_C* UI_Lobby_PlayerInfo; // Offset: 0x7e8 // Size: 0x08
	struct UUI_Lobby_RandomPack_C* UI_Lobby_RandomPack; // Offset: 0x7f0 // Size: 0x08
	struct UUI_Lobby_Recruit_C* UI_Lobby_Recruit; // Offset: 0x7f8 // Size: 0x08
	struct UUI_Lobby_RedPacket_C* UI_Lobby_RedPacket; // Offset: 0x800 // Size: 0x08
	struct UUI_Lobby_Sanctuary_C* UI_Lobby_Sanctuary; // Offset: 0x808 // Size: 0x08
	struct UUI_Lobby_Social_Entrance_C* UI_Lobby_Social_Entrance; // Offset: 0x810 // Size: 0x08
	struct UUI_Lobby_StartBtn_C* UI_Lobby_StartBtn; // Offset: 0x818 // Size: 0x08
	struct UUI_Lobby_SupplyBox_C* UI_Lobby_SupplyBox; // Offset: 0x820 // Size: 0x08
	struct UUI_Lobby_Topup_C* UI_Lobby_Topup; // Offset: 0x828 // Size: 0x08
	struct UUI_MicroPhoneSetting_C* UI_MicroPhoneSetting; // Offset: 0x830 // Size: 0x08
	struct UUI_Rank_Icon_Small_C* UI_Rank_Icon_Small; // Offset: 0x838 // Size: 0x08
	struct UTextBlock* UserId; // Offset: 0x840 // Size: 0x08
	struct UCanvasPanel* Video; // Offset: 0x848 // Size: 0x08
	struct UWidgetSwitcher* WidgetSwitcher_Tournament; // Offset: 0x850 // Size: 0x08

	// Functions

	// Object Name: Function UI_Lobby.UI_Lobby_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	struct FString GetModuleName(); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UI_Lobby.UI_Lobby_C.SetLevel
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetLevel(int32_t Level); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UI_Lobby.UI_Lobby_C.SetClanLock
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetClanLock(int32_t ClanLock); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UI_Lobby.UI_Lobby_C.AddVideoPanel
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	void AddVideoPanel(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Lobby.UI_Lobby_C.ShowFlyAnimation
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void ShowFlyAnimation(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Lobby.UI_Lobby_C.GetAnimTargetLocation
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	void GetAnimTargetLocation(struct UWidget* TargetObject, struct UWidget* UserObject, struct FVector2D& TargetLocation); // Offset: 0x102f67d18 // Return & Params: Num(3) Size(0x18)

	// Object Name: Function UI_Lobby.UI_Lobby_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void PreConstruct(bool IsDesignTime); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Lobby.UI_Lobby_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Construct(); // Offset: 0x10135fdbc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Lobby.UI_Lobby_C.ReceiveShow
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveShow(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Lobby.UI_Lobby_C.ExecuteUbergraph_UI_Lobby
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_UI_Lobby(int32_t EntryPoint); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x4)
};

