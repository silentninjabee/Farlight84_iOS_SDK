#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_Marquees.UI_Marquees_C
// Size: 0x360 // Inherited bytes: 0x340
struct UUI_Marquees_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x340 // Size: 0x08
	struct UImage* Img_BG; // Offset: 0x348 // Size: 0x08
	struct UCanvasPanel* Panel_Marquees; // Offset: 0x350 // Size: 0x08
	struct USolarTextBlock* Txt_Marquees; // Offset: 0x358 // Size: 0x08

	// Functions

	// Object Name: Function UI_Marquees.UI_Marquees_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	struct FString GetModuleName(); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UI_Marquees.UI_Marquees_C.Tick
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Offset: 0x102f67d18 // Return & Params: Num(2) Size(0x3c)

	// Object Name: Function UI_Marquees.UI_Marquees_C.ExecuteUbergraph_UI_Marquees
	// Flags: [Final|UbergraphFunction|HasDefaults]
	void ExecuteUbergraph_UI_Marquees(int32_t EntryPoint); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x4)
};

