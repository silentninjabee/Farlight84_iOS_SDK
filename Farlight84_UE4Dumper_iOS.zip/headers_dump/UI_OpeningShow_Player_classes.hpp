#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_OpeningShow_Player.UI_OpeningShow_Player_C
// Size: 0x420 // Inherited bytes: 0x3c8
struct UUI_OpeningShow_Player_C : UUIDefenderPlaerShowWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x3c8 // Size: 0x08
	struct UImage* Img_InfoBgLight; // Offset: 0x3d0 // Size: 0x08
	struct UUI_Target_Bussinesscard_Proficiency_C* Proficiency; // Offset: 0x3d8 // Size: 0x08
	struct UUI_BusinessInfo_C* UI_BusinessInfo; // Offset: 0x3e0 // Size: 0x08
	struct TArray<struct FLinearColor> Color; // Offset: 0x3e8 // Size: 0x10
	struct TArray<struct UObject*> TeamPosImg; // Offset: 0x3f8 // Size: 0x10
	struct FLinearColor TargetColor; // Offset: 0x408 // Size: 0x10
	struct UObject* TargetImg; // Offset: 0x418 // Size: 0x08

	// Functions

	// Object Name: Function UI_OpeningShow_Player.UI_OpeningShow_Player_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	struct FString GetModuleName(); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UI_OpeningShow_Player.UI_OpeningShow_Player_C.SetBGLight
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetBGLight(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_OpeningShow_Player.UI_OpeningShow_Player_C.SetTeamPos
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void SetTeamPos(int32_t TeamPos); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UI_OpeningShow_Player.UI_OpeningShow_Player_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Construct(); // Offset: 0x102f67d18 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_OpeningShow_Player.UI_OpeningShow_Player_C.ExecuteUbergraph_UI_OpeningShow_Player
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_UI_OpeningShow_Player(int32_t EntryPoint); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x4)
};

