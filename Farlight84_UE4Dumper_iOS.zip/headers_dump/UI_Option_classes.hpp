#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_Option.UI_Option_C
// Size: 0x360 // Inherited bytes: 0x340
struct UUI_Option_C : USolarUserWidget {
	// Fields
	struct UImage* Img_Tick; // Offset: 0x340 // Size: 0x08
	struct UImage* Img_Tick_2; // Offset: 0x348 // Size: 0x08
	struct USolarCheckBox* SolarCheckBox_Switch; // Offset: 0x350 // Size: 0x08
	struct USolarTextBlock* SolarTxt_metion; // Offset: 0x358 // Size: 0x08

	// Functions

	// Object Name: Function UI_Option.UI_Option_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	struct FString GetModuleName(); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x10)
};

