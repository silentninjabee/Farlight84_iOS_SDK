#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_Root.UI_Root_C
// Size: 0x3c0 // Inherited bytes: 0x340
struct UUI_Root_C : USolarUIRoot {
	// Fields
	struct UCanvasPanel* BattleNoticeRoot; // Offset: 0x340 // Size: 0x08
	struct UCanvasPanel* BattleRoot; // Offset: 0x348 // Size: 0x08
	struct UCanvasPanel* BattleRootGuide; // Offset: 0x350 // Size: 0x08
	struct UCanvasPanel* BattleRootOverlay; // Offset: 0x358 // Size: 0x08
	struct UCanvasPanel* CommonRoot; // Offset: 0x360 // Size: 0x08
	struct UCanvasPanel* ExternalToolsRoot; // Offset: 0x368 // Size: 0x08
	struct UCanvasPanel* Guide; // Offset: 0x370 // Size: 0x08
	struct UCanvasPanel* Loading; // Offset: 0x378 // Size: 0x08
	struct UCanvasPanel* Map; // Offset: 0x380 // Size: 0x08
	struct UCanvasPanel* MiddleRoot; // Offset: 0x388 // Size: 0x08
	struct UCanvasPanel* NoticeRoot; // Offset: 0x390 // Size: 0x08
	struct UCanvasPanel* PopRoot; // Offset: 0x398 // Size: 0x08
	struct UCanvasPanel* Reconnecting; // Offset: 0x3a0 // Size: 0x08
	struct UCanvasPanel* TipsRoot; // Offset: 0x3a8 // Size: 0x08
	struct UCanvasPanel* UnderBattleRoot; // Offset: 0x3b0 // Size: 0x08
	float AdapterOffsetLeft; // Offset: 0x3b8 // Size: 0x04
	float AdapterOffsetRight; // Offset: 0x3bc // Size: 0x04

	// Functions

	// Object Name: Function UI_Root.UI_Root_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	struct FString GetModuleName(); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x10)
};

