#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class UObjectPlugin.MyPluginObject
// Size: 0x38 // Inherited bytes: 0x28
struct UMyPluginObject : UObject {
	// Fields
	struct FMyPluginStruct MyStruct; // Offset: 0x28 // Size: 0x10
};

