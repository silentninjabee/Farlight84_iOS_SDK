#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct UdpMessaging.UdpMockMessage
// Size: 0x10 // Inherited bytes: 0x00
struct FUdpMockMessage {
	// Fields
	struct TArray<char> Data; // Offset: 0x00 // Size: 0x10
};

