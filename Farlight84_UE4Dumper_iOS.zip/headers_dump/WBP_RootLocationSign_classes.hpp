#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass WBP_RootLocationSign.WBP_RootLocationSign_C
// Size: 0x268 // Inherited bytes: 0x260
struct UWBP_RootLocationSign_C : UUserWidget {
	// Fields
	struct UImage* ImgSign; // Offset: 0x260 // Size: 0x08
};

