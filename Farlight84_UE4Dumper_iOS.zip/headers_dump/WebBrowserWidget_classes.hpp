#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class WebBrowserWidget.WebBrowser
// Size: 0x180 // Inherited bytes: 0x138
struct UWebBrowser : UWidget {
	// Fields
	struct FMulticastInlineDelegate OnUrlChanged; // Offset: 0x138 // Size: 0x10
	struct FMulticastInlineDelegate OnBeforePopup; // Offset: 0x148 // Size: 0x10
	struct FString InitialURL; // Offset: 0x158 // Size: 0x10
	bool bSupportsTransparency; // Offset: 0x168 // Size: 0x01
	char pad_0x169[0x17]; // Offset: 0x169 // Size: 0x17

	// Functions

	// Object Name: DelegateFunction WebBrowserWidget.WebBrowser.OnUrlChanged__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void OnUrlChanged__DelegateSignature(struct FText& Text); // Offset: 0x102f67d18 // Return & Params: Num(1) Size(0x18)

	// Object Name: DelegateFunction WebBrowserWidget.WebBrowser.OnBeforePopup__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnBeforePopup__DelegateSignature(struct FString URL, struct FString Frame); // Offset: 0x102f67d18 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function WebBrowserWidget.WebBrowser.LoadURL
	// Flags: [Final|Native|Public|BlueprintCallable]
	void LoadURL(struct FString NewURL); // Offset: 0x1014ba3e0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function WebBrowserWidget.WebBrowser.LoadString
	// Flags: [Final|Native|Public|BlueprintCallable]
	void LoadString(struct FString Contents, struct FString DummyURL); // Offset: 0x1014ba248 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function WebBrowserWidget.WebBrowser.GetUrl
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FString GetUrl(); // Offset: 0x1014ba098 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function WebBrowserWidget.WebBrowser.GetTitleText
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FText GetTitleText(); // Offset: 0x1014ba118 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function WebBrowserWidget.WebBrowser.ExecuteJavascript
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ExecuteJavascript(struct FString ScriptText); // Offset: 0x1014ba1c0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function WebBrowserWidget.WebBrowser.CloseSelf
	// Flags: [Final|Native|Public|BlueprintCallable]
	void CloseSelf(); // Offset: 0x1014b9f6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function WebBrowserWidget.WebBrowser.BindUObject
	// Flags: [Final|Native|Public|BlueprintCallable]
	void BindUObject(struct FString Name, struct UObject* Object, bool bIsPermanent); // Offset: 0x1014b9f80 // Return & Params: Num(3) Size(0x19)
};

// Object Name: Class WebBrowserWidget.WebBrowserAssetManager
// Size: 0x78 // Inherited bytes: 0x28
struct UWebBrowserAssetManager : UObject {
	// Fields
	struct TSoftObjectPtr<UMaterial> DefaultMaterial; // Offset: 0x28 // Size: 0x28
	char pad_0x50[0x28]; // Offset: 0x50 // Size: 0x28
};

