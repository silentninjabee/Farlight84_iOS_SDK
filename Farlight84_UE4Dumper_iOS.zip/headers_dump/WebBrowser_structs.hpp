#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct WebBrowser.WebJSCallbackBase
// Size: 0x20 // Inherited bytes: 0x00
struct FWebJSCallbackBase {
	// Fields
	char pad_0x0[0x20]; // Offset: 0x00 // Size: 0x20
};

// Object Name: ScriptStruct WebBrowser.WebJSResponse
// Size: 0x20 // Inherited bytes: 0x20
struct FWebJSResponse : FWebJSCallbackBase {
};

// Object Name: ScriptStruct WebBrowser.WebJSFunction
// Size: 0x20 // Inherited bytes: 0x20
struct FWebJSFunction : FWebJSCallbackBase {
};

