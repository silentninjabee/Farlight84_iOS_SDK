#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: DynamicClass ABP_SolarCharacter_FPP.ABP_SolarCharacter_FPP_C
// Inherited Bytes: 0x2a0 | Struct Size: 0x730
struct UABP_SolarCharacter_FPP_C : UAnimInstance {
	// Fields
	struct FAnimNode_Root AnimGraphNode_Root; // Offset: 0x298 | Size: 0x30
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_2; // Offset: 0x2c8 | Size: 0x28
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult; // Offset: 0x2f0 | Size: 0x28
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_3; // Offset: 0x318 | Size: 0x88
	struct FAnimNode_StateResult AnimGraphNode_StateResult_2; // Offset: 0x3a0 | Size: 0x30
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2; // Offset: 0x3d0 | Size: 0x88
	struct FAnimNode_StateResult AnimGraphNode_StateResult; // Offset: 0x458 | Size: 0x30
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine; // Offset: 0x488 | Size: 0xb0
	struct FAnimNode_Slot AnimGraphNode_Slot; // Offset: 0x538 | Size: 0x48
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer; // Offset: 0x580 | Size: 0x88
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool; // Offset: 0x608 | Size: 0xa8
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace; // Offset: 0x6b0 | Size: 0x20
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace; // Offset: 0x6d0 | Size: 0x20
	struct ASolarCharacter* SolarCharacter; // Offset: 0x6f0 | Size: 0x8
	bool IsScopeAim; // Offset: 0x6f8 | Size: 0x1
	float ScopeFadeTime; // Offset: 0x6fc | Size: 0x4
	bool IsWalking; // Offset: 0x700 | Size: 0x1
	bool IsShooting; // Offset: 0x701 | Size: 0x1
	bool ShootDouble; // Offset: 0x702 | Size: 0x1
	float Horizontal; // Offset: 0x704 | Size: 0x4
	float Vertical; // Offset: 0x708 | Size: 0x4
	bool bUseAnim; // Offset: 0x70c | Size: 0x1
	float K2Node_Event_DeltaTimeX; // Offset: 0x710 | Size: 0x4
	char pad_0x715[0x3]; // Offset: 0x715 | Size: 0x3
	struct ASolarCharacter* K2Node_DynamicCast_AsSolar_Character; // Offset: 0x718 | Size: 0x8
	bool K2Node_DynamicCast_bSuccess; // Offset: 0x720 | Size: 0x1
	char pad_0x721[0xf]; // Offset: 0x721 | Size: 0xf

	// Functions

	// Object: Function ABP_SolarCharacter_FPP.ABP_SolarCharacter_FPP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_SolarCharacter_FPP_AnimGraphNode_TransitionResult_768665AB4918F96C9C3C8F92EF926EE4
	// Flags: [Native|Public]
	// Offset: 0x101df5cd8
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_SolarCharacter_FPP_AnimGraphNode_TransitionResult_768665AB4918F96C9C3C8F92EF926EE4();

	// Object: Function ABP_SolarCharacter_FPP.ABP_SolarCharacter_FPP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_SolarCharacter_FPP_AnimGraphNode_TransitionResult_01B670704C4A0F8E519CD8A192C5E1D6
	// Flags: [Native|Public]
	// Offset: 0x101df5ca0
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_SolarCharacter_FPP_AnimGraphNode_TransitionResult_01B670704C4A0F8E519CD8A192C5E1D6();

	// Object: Function ABP_SolarCharacter_FPP.ABP_SolarCharacter_FPP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_SolarCharacter_FPP_AnimGraphNode_BlendListByBool_F136F87A4DDCD2678555C9B592100DA7
	// Flags: [Native|Public]
	// Offset: 0x101df5cbc
	// Return & Params: [ Num(0) Size(0x0) ]
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_SolarCharacter_FPP_AnimGraphNode_BlendListByBool_F136F87A4DDCD2678555C9B592100DA7();

	// Object: Function ABP_SolarCharacter_FPP.ABP_SolarCharacter_FPP_C.BlueprintUpdateAnimation
	// Flags: [Native|Event|Public]
	// Offset: 0x101df5cf4
	// Return & Params: [ Num(1) Size(0x4) ]
	void BlueprintUpdateAnimation(float bpp__DeltaTimeX__pf);

	// Object: Function ABP_SolarCharacter_FPP.ABP_SolarCharacter_FPP_C.BlueprintInitializeAnimation
	// Flags: [Native|Event|Public]
	// Offset: 0x101df5d98
	// Return & Params: [ Num(0) Size(0x0) ]
	void BlueprintInitializeAnimation();

	// Object: Function ABP_SolarCharacter_FPP.ABP_SolarCharacter_FPP_C.BlueprintBeginPlay
	// Flags: [Native|Event|Public]
	// Offset: 0x101df5d7c
	// Return & Params: [ Num(0) Size(0x0) ]
	void BlueprintBeginPlay();

	// Object: Function ABP_SolarCharacter_FPP.ABP_SolarCharacter_FPP_C.AnimGraph
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101df5c00
	// Return & Params: [ Num(1) Size(0x10) ]
	void AnimGraph(struct FPoseLink& bpp__AnimGraph__pf);
};

