#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass Ability_VehicleWeapon_IronManLaser.Ability_VehicleWeapon_IronManLaser_C
// Inherited Bytes: 0x310 | Struct Size: 0x310
struct AAbility_VehicleWeapon_IronManLaser_C : ASolarAbility {
};

