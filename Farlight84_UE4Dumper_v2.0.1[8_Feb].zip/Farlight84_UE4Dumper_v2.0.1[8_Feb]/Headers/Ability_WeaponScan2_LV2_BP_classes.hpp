#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass Ability_WeaponScan2_LV2_BP.Ability_WeaponScan2_LV2_BP_C
// Inherited Bytes: 0x3d8 | Struct Size: 0x3d8
struct AAbility_WeaponScan2_LV2_BP_C : AAbility_WeaponScan2_BP_C {
};

