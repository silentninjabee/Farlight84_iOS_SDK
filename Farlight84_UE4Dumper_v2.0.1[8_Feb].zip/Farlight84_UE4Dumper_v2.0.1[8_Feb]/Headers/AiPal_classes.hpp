#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class AiPal.AiPalComponent
// Inherited Bytes: 0xb0 | Struct Size: 0xb0
struct UAiPalComponent : UActorComponent {
	// Functions

	// Object: Function AiPal.AiPalComponent.SetUserID
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101835290
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetUserID(struct FString UserId);

	// Object: Function AiPal.AiPalComponent.SetThreshold
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101835210
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetThreshold(float ThresholdPer);

	// Object: Function AiPal.AiPalComponent.SetMaxDetectTimes
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101835110
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetMaxDetectTimes(int32_t DetectGap_ms);

	// Object: Function AiPal.AiPalComponent.SetDetectGap_ms
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101835190
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetDetectGap_ms(int32_t DetectGap_ms);

	// Object: Function AiPal.AiPalComponent.EndDetect
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1018350e8
	// Return & Params: [ Num(0) Size(0x0) ]
	void EndDetect();

	// Object: Function AiPal.AiPalComponent.Capture
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1018350d4
	// Return & Params: [ Num(0) Size(0x0) ]
	void Capture();

	// Object: Function AiPal.AiPalComponent.BeginDetect
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1018350fc
	// Return & Params: [ Num(0) Size(0x0) ]
	void BeginDetect();
};

