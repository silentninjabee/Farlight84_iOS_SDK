#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class AnimationBudgetAllocator.AnimationBudgetBlueprintLibrary
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UAnimationBudgetBlueprintLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object: Function AnimationBudgetAllocator.AnimationBudgetBlueprintLibrary.SetAnimationBudgetParameters
	// Flags: [Final|Native|Static|Private|HasOutParms|BlueprintCallable]
	// Offset: 0x101161bc4
	// Return & Params: [ Num(2) Size(0x5c) ]
	void SetAnimationBudgetParameters(struct UObject* WorldContextObject, struct FAnimationBudgetAllocatorParameters& InParameters);

	// Object: Function AnimationBudgetAllocator.AnimationBudgetBlueprintLibrary.EnableAnimationBudget
	// Flags: [Final|Native|Static|Private|BlueprintCallable]
	// Offset: 0x101161d04
	// Return & Params: [ Num(2) Size(0x9) ]
	void EnableAnimationBudget(struct UObject* WorldContextObject, bool bEnabled);
};

// Object: Class AnimationBudgetAllocator.SkeletalMeshComponentBudgeted
// Inherited Bytes: 0xc80 | Struct Size: 0xcb0
struct USkeletalMeshComponentBudgeted : USkeletalMeshComponent {
	// Fields
	enum class ESkeletalMeshAnimDetailMode AnimDetailMode; // Offset: 0xc78 | Size: 0x1
	char pad_0xC81[0x1f]; // Offset: 0xc81 | Size: 0x1f
	char bAutoRegisterWithBudgetAllocator : 1; // Offset: 0xca0 | Size: 0x1
	char bAutoCalculateSignificance : 1; // Offset: 0xca0 | Size: 0x1
	char bShouldUseActorRenderedFlag : 1; // Offset: 0xca0 | Size: 0x1
	char pad_0xCA0_3 : 5; // Offset: 0xca0 | Size: 0x1
	char pad_0xCA1[0xf]; // Offset: 0xca1 | Size: 0xf

	// Functions

	// Object: Function AnimationBudgetAllocator.SkeletalMeshComponentBudgeted.SetAutoRegisterWithBudgetAllocator
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101162128
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetAutoRegisterWithBudgetAllocator(bool bInAutoRegisterWithBudgetAllocator);
};

