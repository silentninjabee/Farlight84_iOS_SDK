#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct AudioMixer.SubmixEffectDynamicsProcessorSettings
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FSubmixEffectDynamicsProcessorSettings {
	// Fields
	enum class ESubmixEffectDynamicsProcessorType DynamicsProcessorType; // Offset: 0x0 | Size: 0x1
	enum class ESubmixEffectDynamicsPeakMode PeakMode; // Offset: 0x1 | Size: 0x1
	enum class ESubmixEffectDynamicsChannelLinkMode LinkMode; // Offset: 0x2 | Size: 0x1
	char pad_0x3[0x1]; // Offset: 0x3 | Size: 0x1
	float InputGainDb; // Offset: 0x4 | Size: 0x4
	float ThresholdDb; // Offset: 0x8 | Size: 0x4
	float Ratio; // Offset: 0xc | Size: 0x4
	float KneeBandwidthDb; // Offset: 0x10 | Size: 0x4
	float LookAheadMsec; // Offset: 0x14 | Size: 0x4
	float AttackTimeMsec; // Offset: 0x18 | Size: 0x4
	float ReleaseTimeMsec; // Offset: 0x1c | Size: 0x4
	struct USoundSubmix* ExternalSubmix; // Offset: 0x20 | Size: 0x8
	char bChannelLinked : 1; // Offset: 0x28 | Size: 0x1
	char bAnalogMode : 1; // Offset: 0x28 | Size: 0x1
	char bKeyAudition : 1; // Offset: 0x28 | Size: 0x1
	char pad_0x28_3 : 5; // Offset: 0x28 | Size: 0x1
	char pad_0x29[0x3]; // Offset: 0x29 | Size: 0x3
	float KeyGainDb; // Offset: 0x2c | Size: 0x4
	float OutputGainDb; // Offset: 0x30 | Size: 0x4
	struct FSubmixEffectDynamicProcessorFilterSettings KeyHighshelf; // Offset: 0x34 | Size: 0xc
	struct FSubmixEffectDynamicProcessorFilterSettings KeyLowshelf; // Offset: 0x40 | Size: 0xc
	char pad_0x4C[0x4]; // Offset: 0x4c | Size: 0x4
};

// Object: ScriptStruct AudioMixer.SubmixEffectDynamicProcessorFilterSettings
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FSubmixEffectDynamicProcessorFilterSettings {
	// Fields
	char bEnabled : 1; // Offset: 0x0 | Size: 0x1
	char pad_0x0_1 : 7; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	float Cutoff; // Offset: 0x4 | Size: 0x4
	float GainDb; // Offset: 0x8 | Size: 0x4
};

// Object: ScriptStruct AudioMixer.SubmixEffectSubmixEQSettings
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FSubmixEffectSubmixEQSettings {
	// Fields
	struct TArray<struct FSubmixEffectEQBand> EQBands; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct AudioMixer.SubmixEffectEQBand
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FSubmixEffectEQBand {
	// Fields
	float Frequency; // Offset: 0x0 | Size: 0x4
	float Bandwidth; // Offset: 0x4 | Size: 0x4
	float GainDb; // Offset: 0x8 | Size: 0x4
	char bEnabled : 1; // Offset: 0xc | Size: 0x1
	char pad_0xC_1 : 7; // Offset: 0xc | Size: 0x1
	char pad_0xD[0x3]; // Offset: 0xd | Size: 0x3
};

// Object: ScriptStruct AudioMixer.SubmixEffectReverbSettings
// Inherited Bytes: 0x0 | Struct Size: 0x34
struct FSubmixEffectReverbSettings {
	// Fields
	float Density; // Offset: 0x0 | Size: 0x4
	float Diffusion; // Offset: 0x4 | Size: 0x4
	float Gain; // Offset: 0x8 | Size: 0x4
	float GainHF; // Offset: 0xc | Size: 0x4
	float DecayTime; // Offset: 0x10 | Size: 0x4
	float DecayHFRatio; // Offset: 0x14 | Size: 0x4
	float ReflectionsGain; // Offset: 0x18 | Size: 0x4
	float ReflectionsDelay; // Offset: 0x1c | Size: 0x4
	float LateGain; // Offset: 0x20 | Size: 0x4
	float LateDelay; // Offset: 0x24 | Size: 0x4
	float AirAbsorptionGainHF; // Offset: 0x28 | Size: 0x4
	float WetLevel; // Offset: 0x2c | Size: 0x4
	float DryLevel; // Offset: 0x30 | Size: 0x4
};

// Object: ScriptStruct AudioMixer.SubmixEffectReverbFastSettings
// Inherited Bytes: 0x0 | Struct Size: 0x38
struct FSubmixEffectReverbFastSettings {
	// Fields
	bool bBypass; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	float Density; // Offset: 0x4 | Size: 0x4
	float Diffusion; // Offset: 0x8 | Size: 0x4
	float Gain; // Offset: 0xc | Size: 0x4
	float GainHF; // Offset: 0x10 | Size: 0x4
	float DecayTime; // Offset: 0x14 | Size: 0x4
	float DecayHFRatio; // Offset: 0x18 | Size: 0x4
	float ReflectionsGain; // Offset: 0x1c | Size: 0x4
	float ReflectionsDelay; // Offset: 0x20 | Size: 0x4
	float LateGain; // Offset: 0x24 | Size: 0x4
	float LateDelay; // Offset: 0x28 | Size: 0x4
	float AirAbsorptionGainHF; // Offset: 0x2c | Size: 0x4
	float WetLevel; // Offset: 0x30 | Size: 0x4
	float DryLevel; // Offset: 0x34 | Size: 0x4
};

