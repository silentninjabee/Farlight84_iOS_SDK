#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BCP_BattleSection_Level_2.BCP_BattleSection_Level_1_C
// Inherited Bytes: 0x290 | Struct Size: 0x290
struct UBCP_BattleSection_Level_1_C : UBCP_BattleSection_C {
};

