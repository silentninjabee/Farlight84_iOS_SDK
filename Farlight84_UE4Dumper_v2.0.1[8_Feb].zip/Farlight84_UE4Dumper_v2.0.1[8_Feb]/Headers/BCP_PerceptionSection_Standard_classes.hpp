#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BCP_PerceptionSection_Standard.BCP_PerceptionSection_Standard_C
// Inherited Bytes: 0xf0 | Struct Size: 0xf0
struct UBCP_PerceptionSection_Standard_C : USolarBotConfigSection_Perception {
};

