#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BCP_SkyDiving_Default.BCP_SkyDiving_Default_C
// Inherited Bytes: 0x68 | Struct Size: 0x68
struct UBCP_SkyDiving_Default_C : USolarBotConfigSection_SkyDiving {
};

