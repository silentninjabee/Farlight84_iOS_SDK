#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BPC_AiManagerBattleRoyale.BPC_AiManagerBattleRoyale_C
// Inherited Bytes: 0xe8 | Struct Size: 0x201
struct UBPC_AiManagerBattleRoyale_C : UBPC_AiManagerBase_C {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0xe8 | Size: 0x8
	struct TArray<struct ASCMPlayerState*> TempAI; // Offset: 0xf0 | Size: 0x10
	struct TMap<struct FString, int32_t> MemberAIOrder; // Offset: 0x100 | Size: 0x50
	int32_t SpawnIndex; // Offset: 0x150 | Size: 0x4
	bool bCanSpawn; // Offset: 0x154 | Size: 0x1
	char pad_0x155[0x3]; // Offset: 0x155 | Size: 0x3
	struct TMap<struct FString, int32_t> PureAIOrder; // Offset: 0x158 | Size: 0x50
	bool bSpawnPlayerTeammate; // Offset: 0x1a8 | Size: 0x1
	char pad_0x1A9[0x3]; // Offset: 0x1a9 | Size: 0x3
	int32_t AiCountPreSpawn; // Offset: 0x1ac | Size: 0x4
	int32_t RealPlayer; // Offset: 0x1b0 | Size: 0x4
	char pad_0x1B4[0x4]; // Offset: 0x1b4 | Size: 0x4
	struct TArray<struct ASCMPlayerState*> TeammateAI; // Offset: 0x1b8 | Size: 0x10
	bool bTeammateAiFinished; // Offset: 0x1c8 | Size: 0x1
	char pad_0x1C9[0x7]; // Offset: 0x1c9 | Size: 0x7
	struct FS_WarmGameConfig WarmGameConfig; // Offset: 0x1d0 | Size: 0x18
	bool bIsWarmGame; // Offset: 0x1e8 | Size: 0x1
	char pad_0x1E9[0x7]; // Offset: 0x1e9 | Size: 0x7
	struct TArray<struct FString> PureAiTeams; // Offset: 0x1f0 | Size: 0x10
	bool NewVar_1; // Offset: 0x200 | Size: 0x1

	// Functions

	// Object: Function BPC_AiManagerBattleRoyale.BPC_AiManagerBattleRoyale_C.ReplenishAITeammate
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void ReplenishAITeammate();

	// Object: Function BPC_AiManagerBattleRoyale.BPC_AiManagerBattleRoyale_C.GetCountDownComponent
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UBPC_CountDown_C* GetCountDownComponent();

	// Object: Function BPC_AiManagerBattleRoyale.BPC_AiManagerBattleRoyale_C.StopAiBehavior
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void StopAiBehavior();

	// Object: Function BPC_AiManagerBattleRoyale.BPC_AiManagerBattleRoyale_C.CanModeSpawnAiTeammate
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	bool CanModeSpawnAiTeammate();

	// Object: Function BPC_AiManagerBattleRoyale.BPC_AiManagerBattleRoyale_C.GetAIController
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x10) ]
	void GetAIController(struct ASolarPlayerState* PlayerState, struct ASolarBotAIController*& Controller);

	// Object: Function BPC_AiManagerBattleRoyale.BPC_AiManagerBattleRoyale_C.SpawnAI
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0x20) ]
	void SpawnAI(bool bTeammateAI, struct FString Team, struct ASCMPlayerState*& PlayerState);

	// Object: Function BPC_AiManagerBattleRoyale.BPC_AiManagerBattleRoyale_C.GetSpawnInterval
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void GetSpawnInterval(float& Interval);

	// Object: Function BPC_AiManagerBattleRoyale.BPC_AiManagerBattleRoyale_C.UpdatePureAiOrder
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void UpdatePureAiOrder();

	// Object: Function BPC_AiManagerBattleRoyale.BPC_AiManagerBattleRoyale_C.Pick Team
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x18) ]
	void Pick Team(bool RealPlayerTeam, struct FString& Team);

	// Object: Function BPC_AiManagerBattleRoyale.BPC_AiManagerBattleRoyale_C.DeleteTempAI
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void DeleteTempAI(int32_t count);

	// Object: Function BPC_AiManagerBattleRoyale.BPC_AiManagerBattleRoyale_C.RunBehaviourTree
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x10) ]
	void RunBehaviourTree(struct ASCMPlayerState* Player, struct UBehaviorTree* BTAsset);

	// Object: Function BPC_AiManagerBattleRoyale.BPC_AiManagerBattleRoyale_C.SpawnLocation
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0xc) ]
	struct FVector SpawnLocation();

	// Object: Function BPC_AiManagerBattleRoyale.BPC_AiManagerBattleRoyale_C.IsPlayerFull
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsPlayerFull();

	// Object: Function BPC_AiManagerBattleRoyale.BPC_AiManagerBattleRoyale_C.GetLogicComponent
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UBP_Logic_BattleRoyale_C* GetLogicComponent();

	// Object: Function BPC_AiManagerBattleRoyale.BPC_AiManagerBattleRoyale_C.MatchFinished
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void MatchFinished();

	// Object: Function BPC_AiManagerBattleRoyale.BPC_AiManagerBattleRoyale_C.PreSpawnAI
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void PreSpawnAI();

	// Object: Function BPC_AiManagerBattleRoyale.BPC_AiManagerBattleRoyale_C.ReceiveBeginPlay
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void ReceiveBeginPlay();

	// Object: Function BPC_AiManagerBattleRoyale.BPC_AiManagerBattleRoyale_C.SpawnAIDynamic
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void SpawnAIDynamic();

	// Object: Function BPC_AiManagerBattleRoyale.BPC_AiManagerBattleRoyale_C.OnBattleStateChanged
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnBattleStateChanged(enum class E_BattleState_BattleRoyale NewState);

	// Object: Function BPC_AiManagerBattleRoyale.BPC_AiManagerBattleRoyale_C.CustomEvent_2
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void CustomEvent_2();

	// Object: Function BPC_AiManagerBattleRoyale.BPC_AiManagerBattleRoyale_C.OnPlayerJoin
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x9) ]
	void OnPlayerJoin(struct ASCMPlayerState* NewPlayer, bool bIsAi);

	// Object: Function BPC_AiManagerBattleRoyale.BPC_AiManagerBattleRoyale_C.HandleSelectHeros
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void HandleSelectHeros();

	// Object: Function BPC_AiManagerBattleRoyale.BPC_AiManagerBattleRoyale_C.HandleMatchHasStated
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void HandleMatchHasStated();

	// Object: Function BPC_AiManagerBattleRoyale.BPC_AiManagerBattleRoyale_C.ExecuteUbergraph_BPC_AiManagerBattleRoyale
	// Flags: [Final|UbergraphFunction|HasDefaults]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_BPC_AiManagerBattleRoyale(int32_t EntryPoint);
};

