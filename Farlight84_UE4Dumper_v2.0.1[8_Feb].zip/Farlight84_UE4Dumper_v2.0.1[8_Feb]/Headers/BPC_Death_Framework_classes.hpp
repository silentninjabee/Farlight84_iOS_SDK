#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BPC_Death_Framework.BPC_Death_Framework_C
// Inherited Bytes: 0xf0 | Struct Size: 0x134
struct UBPC_Death_Framework_C : UCGMDeathComponent {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0xf0 | Size: 0x8
	struct FMulticastInlineDelegate OnPlayerDie; // Offset: 0xf8 | Size: 0x10
	struct FMulticastInlineDelegate OnPlayerResurrect; // Offset: 0x108 | Size: 0x10
	struct FMulticastInlineDelegate OnPlayerKill; // Offset: 0x118 | Size: 0x10
	struct ABP_DefenderManager_C* DefenderManager; // Offset: 0x128 | Size: 0x8
	struct FS_SkillState SkillStateAfterRevive; // Offset: 0x130 | Size: 0x4

	// Functions

	// Object: Function BPC_Death_Framework.BPC_Death_Framework_C.GMRevive
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x9) ]
	void GMRevive(struct ASCMPlayerState* InKilled, bool& AutoRevive);

	// Object: Function BPC_Death_Framework.BPC_Death_Framework_C.Try Buy Resurrect
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0x121) ]
	void Try Buy Resurrect(struct ASCMPlayerState* Player, struct FSolarPointDamageEvent DamageEvent, bool& Succeed);

	// Object: Function BPC_Death_Framework.BPC_Death_Framework_C.CheckTerminator
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0x11) ]
	bool CheckTerminator(struct ASCMPlayerState* InKiller, struct ASCMPlayerState* InKilled);

	// Object: Function BPC_Death_Framework.BPC_Death_Framework_C.GetDefenderManager
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x8) ]
	void GetDefenderManager(struct ABP_DefenderManager_C*& AsBP Defender Manager);

	// Object: Function BPC_Death_Framework.BPC_Death_Framework_C.UpdateDataTrace
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(6) Size(0x188) ]
	void UpdateDataTrace(enum class E_DeathType Type, struct ASCMPlayerState* Killer, struct ASCMPlayerState* Killed, struct FSolarPointDamageEvent& DamageEvent, struct AActor* DamageCauser, struct TMap<struct FString, struct FString> AdditionalData);

	// Object: Function BPC_Death_Framework.BPC_Death_Framework_C.ReceivePlayerKill
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(5) Size(0x140) ]
	void ReceivePlayerKill(struct ASCMPlayerState* Killer, struct ASCMPlayerState* Killed, struct TArray<struct ASCMPlayerState*>& Assists, struct FSolarPointDamageEvent& InDamageEvent, struct AActor* InDamageCauser);

	// Object: Function BPC_Death_Framework.BPC_Death_Framework_C.ReceivePlayerDeathVerge
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(4) Size(0x130) ]
	void ReceivePlayerDeathVerge(struct ASCMPlayerState* InAttacker, struct ASCMPlayerState* InDeathVergePlayer, struct FSolarPointDamageEvent& InDamageEvent, struct AActor* InDamageCauser);

	// Object: Function BPC_Death_Framework.BPC_Death_Framework_C.ReceivePlayerResurrect
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x10) ]
	void ReceivePlayerResurrect(struct ASolarCharacter* ResurrectCharacter, struct ASCMPlayerState* ResurrectPlayer);

	// Object: Function BPC_Death_Framework.BPC_Death_Framework_C.ExecuteUbergraph_BPC_Death_Framework
	// Flags: [Final|UbergraphFunction|HasDefaults]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_BPC_Death_Framework(int32_t EntryPoint);

	// Object: Function BPC_Death_Framework.BPC_Death_Framework_C.OnPlayerKill__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x8) ]
	void OnPlayerKill__DelegateSignature(struct ABP_PlayerState_Framework_C* Player);

	// Object: Function BPC_Death_Framework.BPC_Death_Framework_C.OnPlayerResurrect__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x8) ]
	void OnPlayerResurrect__DelegateSignature(struct ABP_PlayerState_Framework_C* Player);

	// Object: Function BPC_Death_Framework.BPC_Death_Framework_C.OnPlayerDie__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x8) ]
	void OnPlayerDie__DelegateSignature(struct ABP_PlayerState_Framework_C* Player);
};

