#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BPC_EXPSpringPlayerComponent.BPC_EXPSpringPlayerComponent_C
// Inherited Bytes: 0xc8 | Struct Size: 0xc8
struct UBPC_EXPSpringPlayerComponent_C : USolarExpSpringPlayerComponent {
};

