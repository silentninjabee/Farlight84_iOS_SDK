#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BPC_WarmGame_BattleRoyale.BPC_WarmGame_BattleRoyale_C
// Inherited Bytes: 0xb0 | Struct Size: 0x210
struct UBPC_WarmGame_BattleRoyale_C : USolarWarmGameComponent {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0xb0 | Size: 0x8
	struct UBP_Logic_BattleRoyale_C* MainLogic; // Offset: 0xb8 | Size: 0x8
	struct ASCMPlayerState* RealPlayer; // Offset: 0xc0 | Size: 0x8
	struct TArray<struct FVector> VehiclePos; // Offset: 0xc8 | Size: 0x10
	bool GuidArrowVisibility; // Offset: 0xd8 | Size: 0x1
	char pad_0xD9[0x7]; // Offset: 0xd9 | Size: 0x7
	struct TArray<struct FVector> SafeAreaCenter; // Offset: 0xe0 | Size: 0x10
	struct TArray<struct FVector> WeaponPos; // Offset: 0xf0 | Size: 0x10
	struct TArray<struct FVector> ItemPos; // Offset: 0x100 | Size: 0x10
	struct ASolarCharacter* LocalCharacter; // Offset: 0x110 | Size: 0x8
	struct UUI_WorldMark_Common_C* WorldMark; // Offset: 0x118 | Size: 0x8
	struct FVector SafeCenter; // Offset: 0x120 | Size: 0xc
	char pad_0x12C[0x4]; // Offset: 0x12c | Size: 0x4
	struct UUI_HUD_Notice_Lv3_C* Notice; // Offset: 0x130 | Size: 0x8
	struct FMargin NoticePadding; // Offset: 0x138 | Size: 0x10
	float ArrowScale; // Offset: 0x148 | Size: 0x4
	char pad_0x14C[0x4]; // Offset: 0x14c | Size: 0x4
	struct ABP_DirectionArrow_C* DirectionArrow; // Offset: 0x150 | Size: 0x8
	bool isShowArrow; // Offset: 0x158 | Size: 0x1
	char pad_0x159[0x7]; // Offset: 0x159 | Size: 0x7
	struct TMap<int32_t, struct FS_WarmGameConfig> ; // Offset: 0x160 | Size: 0x50
	struct TMap<int32_t, struct USolarBotAIConfig*> TeammatesAIConfig; // Offset: 0x1b0 | Size: 0x50
	bool bCanAiReviveByItem; // Offset: 0x200 | Size: 0x1
	char pad_0x201[0x7]; // Offset: 0x201 | Size: 0x7
	struct USolarBotAIConfig* DefaultAccompanyBotConfig; // Offset: 0x208 | Size: 0x8

	// Functions

	// Object: Function BPC_WarmGame_BattleRoyale.BPC_WarmGame_BattleRoyale_C.IsWarmGame
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsWarmGame();

	// Object: Function BPC_WarmGame_BattleRoyale.BPC_WarmGame_BattleRoyale_C.GetAIPickResult
	// Flags: [Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0x18) ]
	void GetAIPickResult(struct TArray<int32_t>& InCharactetIDs, int32_t& OutCharacterID, int32_t& OutSkinId);

	// Object: Function BPC_WarmGame_BattleRoyale.BPC_WarmGame_BattleRoyale_C.Create Warm Logic Actor And Exec
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void Create Warm Logic Actor And Exec(bool& Success);

	// Object: Function BPC_WarmGame_BattleRoyale.BPC_WarmGame_BattleRoyale_C.CheckSpAIForWarmGame
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void CheckSpAIForWarmGame(bool& SpecialAI);

	// Object: Function BPC_WarmGame_BattleRoyale.BPC_WarmGame_BattleRoyale_C.[s]SetBotBT
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x8) ]
	void [s]SetBotBT(struct UBehaviorTree* BotBehaviorTree);

	// Object: Function BPC_WarmGame_BattleRoyale.BPC_WarmGame_BattleRoyale_C.[c]ShowNotice
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0x1c) ]
	void [c]ShowNotice(bool Visible, struct FString Text, float Duration);

	// Object: Function BPC_WarmGame_BattleRoyale.BPC_WarmGame_BattleRoyale_C.[c]RequestNearestPosition
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void [c]RequestNearestPosition(enum class E_GuidTargetType Target);

	// Object: Function BPC_WarmGame_BattleRoyale.BPC_WarmGame_BattleRoyale_C.OnRep_WeaponPos
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnRep_WeaponPos();

	// Object: Function BPC_WarmGame_BattleRoyale.BPC_WarmGame_BattleRoyale_C.UpdatePos
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void UpdatePos();

	// Object: Function BPC_WarmGame_BattleRoyale.BPC_WarmGame_BattleRoyale_C.[c]CreateWorldMark
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0x18) ]
	void [c]CreateWorldMark(struct FVector Pos, int32_t , struct UUI_WorldMark_Common_C*& AsUI World Mark Common);

	// Object: Function BPC_WarmGame_BattleRoyale.BPC_WarmGame_BattleRoyale_C.[c]LocalCharacter
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x8) ]
	struct ASolarCharacter* [c]LocalCharacter();

	// Object: Function BPC_WarmGame_BattleRoyale.BPC_WarmGame_BattleRoyale_C.[c]PlayerHasWeapon
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x2) ]
	void [c]PlayerHasWeapon(bool& HasWeapon, bool& HasVehicleWeapon);

	// Object: Function BPC_WarmGame_BattleRoyale.BPC_WarmGame_BattleRoyale_C.UpdateArrowDirection
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void UpdateArrowDirection();

	// Object: Function BPC_WarmGame_BattleRoyale.BPC_WarmGame_BattleRoyale_C.UpdateItemPos
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void UpdateItemPos();

	// Object: Function BPC_WarmGame_BattleRoyale.BPC_WarmGame_BattleRoyale_C.UpdateWeaponPos
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void UpdateWeaponPos();

	// Object: Function BPC_WarmGame_BattleRoyale.BPC_WarmGame_BattleRoyale_C.GetGuidArrow
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x8) ]
	void GetGuidArrow(struct ABP_DirectionArrow_C*& Output_Get);

	// Object: Function BPC_WarmGame_BattleRoyale.BPC_WarmGame_BattleRoyale_C.[C]ShowArrow
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void [C]ShowArrow(bool bNewVisibility);

	// Object: Function BPC_WarmGame_BattleRoyale.BPC_WarmGame_BattleRoyale_C.UpdateVehiclePos
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void UpdateVehiclePos();

	// Object: Function BPC_WarmGame_BattleRoyale.BPC_WarmGame_BattleRoyale_C.GetNearestPosition
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x10) ]
	void GetNearestPosition(enum class E_GuidTargetType Target, struct FVector& Location);

	// Object: Function BPC_WarmGame_BattleRoyale.BPC_WarmGame_BattleRoyale_C.[A]GetPlayBattleCount
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void [A]GetPlayBattleCount(int32_t& count);

	// Object: Function BPC_WarmGame_BattleRoyale.BPC_WarmGame_BattleRoyale_C.[ S]Game Mode Special Config
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0x9) ]
	void [ S]Game Mode Special Config(bool& SpecialConfig, int32_t& Order, bool& isB);

	// Object: Function BPC_WarmGame_BattleRoyale.BPC_WarmGame_BattleRoyale_C.[C]PlayerABTest
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void [C]PlayerABTest(bool& SpecialConfig);

	// Object: Function BPC_WarmGame_BattleRoyale.BPC_WarmGame_BattleRoyale_C.GetMainLogic
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x8) ]
	void GetMainLogic(struct UBP_Logic_BattleRoyale_C*& Output_Get);

	// Object: Function BPC_WarmGame_BattleRoyale.BPC_WarmGame_BattleRoyale_C.ReceiveBeginPlay
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void ReceiveBeginPlay();

	// Object: Function BPC_WarmGame_BattleRoyale.BPC_WarmGame_BattleRoyale_C.ReceiveTick
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ReceiveTick(float DeltaSeconds);

	// Object: Function BPC_WarmGame_BattleRoyale.BPC_WarmGame_BattleRoyale_C.OnSystemReady
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnSystemReady();

	// Object: Function BPC_WarmGame_BattleRoyale.BPC_WarmGame_BattleRoyale_C.PlanyerEnterSafeArea
	// Flags: [Net|NetMulticast|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x8) ]
	void PlanyerEnterSafeArea(struct AActor* Actor);

	// Object: Function BPC_WarmGame_BattleRoyale.BPC_WarmGame_BattleRoyale_C.PlayerLeaveSafeArea
	// Flags: [Net|NetMulticast|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x8) ]
	void PlayerLeaveSafeArea(struct AActor* Actor);

	// Object: Function BPC_WarmGame_BattleRoyale.BPC_WarmGame_BattleRoyale_C.OnNextSafeAreaSetted
	// Flags: [Net|NetMulticast|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(5) Size(0x1c) ]
	void OnNextSafeAreaSetted(struct FVector Center, float Radius, float WaitTime, float MoveTime, int32_t Index);

	// Object: Function BPC_WarmGame_BattleRoyale.BPC_WarmGame_BattleRoyale_C.OnRequestReceived
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x10) ]
	void OnRequestReceived(enum class E_GuidTargetType Type, struct FVector Pos);

	// Object: Function BPC_WarmGame_BattleRoyale.BPC_WarmGame_BattleRoyale_C.OnEjectStateChanged
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x10) ]
	void OnEjectStateChanged(enum class E_CharacterEjectState State, struct ASolarCharacter* TargetCharacter);

	// Object: Function BPC_WarmGame_BattleRoyale.BPC_WarmGame_BattleRoyale_C.ConfigFinished
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void ConfigFinished();

	// Object: Function BPC_WarmGame_BattleRoyale.BPC_WarmGame_BattleRoyale_C.CustomEvent_1
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void CustomEvent_1();

	// Object: Function BPC_WarmGame_BattleRoyale.BPC_WarmGame_BattleRoyale_C.ExecuteUbergraph_BPC_WarmGame_BattleRoyale
	// Flags: [Final|UbergraphFunction|HasDefaults]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_BPC_WarmGame_BattleRoyale(int32_t EntryPoint);
};

