#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_AE_BlindMark_SlownDown.BP_AE_BlindMark_SlownDown_C
// Inherited Bytes: 0x1c0 | Struct Size: 0x1c0
struct UBP_AE_BlindMark_SlownDown_C : UMaterialSimpleEffect {
};

