#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_BTS_AngleCal.BP_BTS_AngleCal_C
// Inherited Bytes: 0x90 | Struct Size: 0x120
struct UBP_BTS_AngleCal_C : UBTService_BlueprintBase {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x90 | Size: 0x8
	struct FBlackboardKeySelector TheOtherOne; // Offset: 0x98 | Size: 0x28
	struct FBlackboardKeySelector DotAngle; // Offset: 0xc0 | Size: 0x28
	struct FBlackboardKeySelector LeftOrRight; // Offset: 0xe8 | Size: 0x28
	struct ASolarBotAIController* SelfController; // Offset: 0x110 | Size: 0x8
	struct APawn* ControlledPawn; // Offset: 0x118 | Size: 0x8

	// Functions

	// Object: Function BP_BTS_AngleCal.BP_BTS_AngleCal_C.ReceiveTickAI
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0x14) ]
	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds);

	// Object: Function BP_BTS_AngleCal.BP_BTS_AngleCal_C.ReceiveSearchStartAI
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x10) ]
	void ReceiveSearchStartAI(struct AAIController* OwnerController, struct APawn* ControlledPawn);

	// Object: Function BP_BTS_AngleCal.BP_BTS_AngleCal_C.ReceiveActivationAI
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x10) ]
	void ReceiveActivationAI(struct AAIController* OwnerController, struct APawn* ControlledPawn);

	// Object: Function BP_BTS_AngleCal.BP_BTS_AngleCal_C.ExecuteUbergraph_BP_BTS_AngleCal
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_BP_BTS_AngleCal(int32_t EntryPoint);
};

