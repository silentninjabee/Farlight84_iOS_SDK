#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_BTS_CheckOnSight.BP_BTS_CheckOnSight_C
// Inherited Bytes: 0x90 | Struct Size: 0xec
struct UBP_BTS_CheckOnSight_C : UBTService_BlueprintBase {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x90 | Size: 0x8
	struct FBlackboardKeySelector CheckedPawnOrActor; // Offset: 0x98 | Size: 0x28
	struct FBlackboardKeySelector SeenByPlayer; // Offset: 0xc0 | Size: 0x28
	float Range; // Offset: 0xe8 | Size: 0x4

	// Functions

	// Object: Function BP_BTS_CheckOnSight.BP_BTS_CheckOnSight_C.ReceiveTickAI
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0x14) ]
	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds);

	// Object: Function BP_BTS_CheckOnSight.BP_BTS_CheckOnSight_C.ReceiveSearchStartAI
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x10) ]
	void ReceiveSearchStartAI(struct AAIController* OwnerController, struct APawn* ControlledPawn);

	// Object: Function BP_BTS_CheckOnSight.BP_BTS_CheckOnSight_C.ReceiveActivationAI
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x10) ]
	void ReceiveActivationAI(struct AAIController* OwnerController, struct APawn* ControlledPawn);

	// Object: Function BP_BTS_CheckOnSight.BP_BTS_CheckOnSight_C.ExecuteUbergraph_BP_BTS_CheckOnSight
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_BP_BTS_CheckOnSight(int32_t EntryPoint);
};

