#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_BTS_ParameterSet_BR.BP_BTS_ParameterSet_BR_C
// Inherited Bytes: 0x90 | Struct Size: 0x108
struct UBP_BTS_ParameterSet_BR_C : UBTService_BlueprintBase {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x90 | Size: 0x8
	struct FBlackboardKeySelector EnemyActor; // Offset: 0x98 | Size: 0x28
	struct FBlackboardKeySelector PoisonResponseLevel; // Offset: 0xc0 | Size: 0x28
	struct ASolarBotAIController* SelfController; // Offset: 0xe8 | Size: 0x8
	struct ASolarCharacter* ControlledPawn; // Offset: 0xf0 | Size: 0x8
	struct ASolarCharacter* Enemy; // Offset: 0xf8 | Size: 0x8
	bool HasPlayerNearby; // Offset: 0x100 | Size: 0x1
	char pad_0x101[0x3]; // Offset: 0x101 | Size: 0x3
	float PlayerNearDisToHenceDamage; // Offset: 0x104 | Size: 0x4

	// Functions

	// Object: Function BP_BTS_ParameterSet_BR.BP_BTS_ParameterSet_BR_C.ReceiveActivationAI
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x10) ]
	void ReceiveActivationAI(struct AAIController* OwnerController, struct APawn* ControlledPawn);

	// Object: Function BP_BTS_ParameterSet_BR.BP_BTS_ParameterSet_BR_C.ReceiveSearchStartAI
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x10) ]
	void ReceiveSearchStartAI(struct AAIController* OwnerController, struct APawn* ControlledPawn);

	// Object: Function BP_BTS_ParameterSet_BR.BP_BTS_ParameterSet_BR_C.ReceiveTickAI
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0x14) ]
	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds);

	// Object: Function BP_BTS_ParameterSet_BR.BP_BTS_ParameterSet_BR_C.ExecuteUbergraph_BP_BTS_ParameterSet_BR
	// Flags: [Final|UbergraphFunction|HasDefaults]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_BP_BTS_ParameterSet_BR(int32_t EntryPoint);
};

