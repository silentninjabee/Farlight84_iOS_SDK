#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_BTS_ParameterSet_ResetWarmType.BP_BTS_ParameterSet_ResetWarmType_C
// Inherited Bytes: 0x90 | Struct Size: 0xd4
struct UBP_BTS_ParameterSet_ResetWarmType_C : UBTService_BlueprintBase {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x90 | Size: 0x8
	struct ASolarBotAIController* SelfController; // Offset: 0x98 | Size: 0x8
	struct ASolarCharacter* ControlledPawn; // Offset: 0xa0 | Size: 0x8
	struct FBlackboardKeySelector WarmType; // Offset: 0xa8 | Size: 0x28
	float DistanceReset; // Offset: 0xd0 | Size: 0x4

	// Functions

	// Object: Function BP_BTS_ParameterSet_ResetWarmType.BP_BTS_ParameterSet_ResetWarmType_C.ReceiveTickAI
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0x14) ]
	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds);

	// Object: Function BP_BTS_ParameterSet_ResetWarmType.BP_BTS_ParameterSet_ResetWarmType_C.ReceiveSearchStartAI
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x10) ]
	void ReceiveSearchStartAI(struct AAIController* OwnerController, struct APawn* ControlledPawn);

	// Object: Function BP_BTS_ParameterSet_ResetWarmType.BP_BTS_ParameterSet_ResetWarmType_C.ReceiveActivationAI
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x10) ]
	void ReceiveActivationAI(struct AAIController* OwnerController, struct APawn* ControlledPawn);

	// Object: Function BP_BTS_ParameterSet_ResetWarmType.BP_BTS_ParameterSet_ResetWarmType_C.ExecuteUbergraph_BP_BTS_ParameterSet_ResetWarmType
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_BP_BTS_ParameterSet_ResetWarmType(int32_t EntryPoint);
};

