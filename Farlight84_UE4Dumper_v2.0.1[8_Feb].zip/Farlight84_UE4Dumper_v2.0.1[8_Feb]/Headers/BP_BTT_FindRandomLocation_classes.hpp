#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_BTT_FindRandomLocation.BP_BTT_FindRandomLocation_C
// Inherited Bytes: 0xc8 | Struct Size: 0xc8
struct UBP_BTT_FindRandomLocation_C : USolarBTT_FindRandomLocation {
};

