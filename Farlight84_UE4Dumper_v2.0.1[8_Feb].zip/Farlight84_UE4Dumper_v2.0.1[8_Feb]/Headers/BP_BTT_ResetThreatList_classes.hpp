#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_BTT_ResetThreatList.BP_BTT_ResetThreatList_C
// Inherited Bytes: 0xa8 | Struct Size: 0xb1
struct UBP_BTT_ResetThreatList_C : UBTTask_BlueprintBase {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0xa8 | Size: 0x8
	bool OpenOrClose; // Offset: 0xb0 | Size: 0x1

	// Functions

	// Object: Function BP_BTT_ResetThreatList.BP_BTT_ResetThreatList_C.ReceiveExecuteAI
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x10) ]
	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn);

	// Object: Function BP_BTT_ResetThreatList.BP_BTT_ResetThreatList_C.ExecuteUbergraph_BP_BTT_ResetThreatList
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_BP_BTT_ResetThreatList(int32_t EntryPoint);
};

