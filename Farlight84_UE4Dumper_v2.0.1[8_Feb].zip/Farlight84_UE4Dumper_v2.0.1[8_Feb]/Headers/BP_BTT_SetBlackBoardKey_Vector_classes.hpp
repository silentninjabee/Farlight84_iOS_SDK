#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_BTT_SetBlackBoardKey_Vector.BP_BTT_SetBlackBoardKey_Vector_C
// Inherited Bytes: 0xa8 | Struct Size: 0xe4
struct UBP_BTT_SetBlackBoardKey_Vector_C : UBTTask_BlueprintBase {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0xa8 | Size: 0x8
	struct FBlackboardKeySelector BlackboardKey; // Offset: 0xb0 | Size: 0x28
	struct FVector Int; // Offset: 0xd8 | Size: 0xc

	// Functions

	// Object: Function BP_BTT_SetBlackBoardKey_Vector.BP_BTT_SetBlackBoardKey_Vector_C.ReceiveExecuteAI
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x10) ]
	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn);

	// Object: Function BP_BTT_SetBlackBoardKey_Vector.BP_BTT_SetBlackBoardKey_Vector_C.ExecuteUbergraph_BP_BTT_SetBlackBoardKey_Vector
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_BP_BTT_SetBlackBoardKey_Vector(int32_t EntryPoint);
};

