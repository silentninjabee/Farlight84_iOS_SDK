#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_BTT_SetPlayerToWarmTarget.BP_BTT_SetPlayerToWarmTarget_C
// Inherited Bytes: 0xa8 | Struct Size: 0xd8
struct UBP_BTT_SetPlayerToWarmTarget_C : UBTTask_BlueprintBase {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0xa8 | Size: 0x8
	struct FBlackboardKeySelector WarmTarget; // Offset: 0xb0 | Size: 0x28

	// Functions

	// Object: Function BP_BTT_SetPlayerToWarmTarget.BP_BTT_SetPlayerToWarmTarget_C.ReceiveExecuteAI
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x10) ]
	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn);

	// Object: Function BP_BTT_SetPlayerToWarmTarget.BP_BTT_SetPlayerToWarmTarget_C.ExecuteUbergraph_BP_BTT_SetPlayerToWarmTarget
	// Flags: [Final|UbergraphFunction|HasDefaults]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_BP_BTT_SetPlayerToWarmTarget(int32_t EntryPoint);
};

