#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_BlackHole_Outline.BP_BlackHole_Outline_C
// Inherited Bytes: 0x1c8 | Struct Size: 0x1c8
struct UBP_BlackHole_Outline_C : UMultiplePassMaterialEffect {
};

