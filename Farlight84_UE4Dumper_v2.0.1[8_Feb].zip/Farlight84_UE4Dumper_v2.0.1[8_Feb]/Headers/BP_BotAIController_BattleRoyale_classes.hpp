#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_BotAIController_BattleRoyale.BP_BotAIController_BattleRoyale_C
// Inherited Bytes: 0x940 | Struct Size: 0x950
struct ABP_BotAIController_BattleRoyale_C : ABP_BotAIController_C {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x940 | Size: 0x8
	struct UNgaiAIControllerComponent* NgaiAIController; // Offset: 0x948 | Size: 0x8

	// Functions

	// Object: Function BP_BotAIController_BattleRoyale.BP_BotAIController_BattleRoyale_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();

	// Object: Function BP_BotAIController_BattleRoyale.BP_BotAIController_BattleRoyale_C.ReceiveBeginPlay
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void ReceiveBeginPlay();

	// Object: Function BP_BotAIController_BattleRoyale.BP_BotAIController_BattleRoyale_C.ReceiveTick
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ReceiveTick(float DeltaSeconds);

	// Object: Function BP_BotAIController_BattleRoyale.BP_BotAIController_BattleRoyale_C.CallAIBegin
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void CallAIBegin();

	// Object: Function BP_BotAIController_BattleRoyale.BP_BotAIController_BattleRoyale_C.
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void ();

	// Object: Function BP_BotAIController_BattleRoyale.BP_BotAIController_BattleRoyale_C.ExecuteUbergraph_BP_BotAIController_BattleRoyale
	// Flags: [Final|UbergraphFunction|HasDefaults]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_BP_BotAIController_BattleRoyale(int32_t EntryPoint);
};

