#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_CapsuleBase_InBattle.BP_CapsuleBase_InBattle_C
// Inherited Bytes: 0x390 | Struct Size: 0x390
struct ABP_CapsuleBase_InBattle_C : ASolarCapsuleActor {
};

