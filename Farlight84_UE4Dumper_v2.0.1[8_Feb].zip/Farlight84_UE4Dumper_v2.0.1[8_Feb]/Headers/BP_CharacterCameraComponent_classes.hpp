#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_CharacterCameraComponent.BP_CharacterCameraComponent_C
// Inherited Bytes: 0xb70 | Struct Size: 0xb70
struct UBP_CharacterCameraComponent_C : USolarCharacterCameraComponent {
};

