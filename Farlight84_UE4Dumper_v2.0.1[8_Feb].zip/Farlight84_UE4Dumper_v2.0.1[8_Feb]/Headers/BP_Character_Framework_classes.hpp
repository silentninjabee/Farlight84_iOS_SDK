#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_Character_Framework.BP_Character_Framework_C
// Inherited Bytes: 0x2658 | Struct Size: 0x267c
struct ABP_Character_Framework_C : ABP_SolarCharacterPlayer_C {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x2658 | Size: 0x8
	struct TArray<struct UGameplayAbility*> DefaultAbilitiesExtra; // Offset: 0x2660 | Size: 0x10
	struct FS_AiItem NewVar_1; // Offset: 0x2670 | Size: 0xc

	// Functions

	// Object: Function BP_Character_Framework.BP_Character_Framework_C.GetWeaponLevelDamageBonus
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void GetWeaponLevelDamageBonus(float& Result);

	// Object: Function BP_Character_Framework.BP_Character_Framework_C.[A]GetHealthState
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class E_CharacterHealthState [A]GetHealthState();

	// Object: Function BP_Character_Framework.BP_Character_Framework_C.[S]SkyDiveFly
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0x11) ]
	bool [S]SkyDiveFly(struct FVector Location, float Height);

	// Object: Function BP_Character_Framework.BP_Character_Framework_C.[S]Set Sky Dive State
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	bool [S]Set Sky Dive State();

	// Object: Function BP_Character_Framework.BP_Character_Framework_C.OnCompleted_84F20D844D539263D5B45F9EDF867241
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x8) ]
	void OnCompleted_84F20D844D539263D5B45F9EDF867241(struct ASolarPlayerWeapon* Weapon);

	// Object: Function BP_Character_Framework.BP_Character_Framework_C.OnCompleted_C9B9AA40496B70A95EF897A2092C6753
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x8) ]
	void OnCompleted_C9B9AA40496B70A95EF897A2092C6753(struct ASolarPlayerWeapon* Weapon);

	// Object: Function BP_Character_Framework.BP_Character_Framework_C.OnCompleted_9F8149E84A6F3575574B32ADD8BF2960
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x8) ]
	void OnCompleted_9F8149E84A6F3575574B32ADD8BF2960(struct ASolarPlayerWeapon* Weapon);

	// Object: Function BP_Character_Framework.BP_Character_Framework_C.BeginPlayBlueprint
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void BeginPlayBlueprint();

	// Object: Function BP_Character_Framework.BP_Character_Framework_C.SetWeapon
	// Flags: [HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0x1c) ]
	void SetWeapon(enum class EWeaponSlotType Slot, int32_t WeapoinId, struct FWeaponPartsData& Parts);

	// Object: Function BP_Character_Framework.BP_Character_Framework_C.BatchSetItem
	// Flags: [HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x10) ]
	void BatchSetItem(struct TArray<struct FS_AiItem>& ItemList);

	// Object: Function BP_Character_Framework.BP_Character_Framework_C.[s]GiveWeapon
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0x8) ]
	void [s]GiveWeapon(bool bDestroyPrevWeapon, enum class EWeaponSlotType Slot, int32_t ItemID);

	// Object: Function BP_Character_Framework.BP_Character_Framework_C.ExecuteUbergraph_BP_Character_Framework
	// Flags: [Final|UbergraphFunction|HasDefaults]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_BP_Character_Framework(int32_t EntryPoint);
};

