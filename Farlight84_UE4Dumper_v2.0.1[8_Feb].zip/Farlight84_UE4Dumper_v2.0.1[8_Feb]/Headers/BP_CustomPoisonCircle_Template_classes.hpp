#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_CustomPoisonCircle_Template.BP_CustomPoisonCircle_Template_C
// Inherited Bytes: 0x498 | Struct Size: 0x4cc
struct ABP_CustomPoisonCircle_Template_C : ASolarCircleSafeArea {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x498 | Size: 0x8
	struct UStaticMeshComponent* StaticMeshCicle; // Offset: 0x4a0 | Size: 0x8
	struct UStaticMeshComponent* SafeArea; // Offset: 0x4a8 | Size: 0x8
	struct USceneComponent* Scene; // Offset: 0x4b0 | Size: 0x8
	float Distance Threshold; // Offset: 0x4b8 | Size: 0x4
	float InitRadius; // Offset: 0x4bc | Size: 0x4
	struct FVector InitPosition; // Offset: 0x4c0 | Size: 0xc

	// Functions

	// Object: Function BP_CustomPoisonCircle_Template.BP_CustomPoisonCircle_Template_C.GetModuleName
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();

	// Object: Function BP_CustomPoisonCircle_Template.BP_CustomPoisonCircle_Template_C.SetMeshVisibility
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void SetMeshVisibility();

	// Object: Function BP_CustomPoisonCircle_Template.BP_CustomPoisonCircle_Template_C.DataTrace
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0x14) ]
	void DataTrace(int32_t inInt, struct FVector Vector, float InFloat);

	// Object: Function BP_CustomPoisonCircle_Template.BP_CustomPoisonCircle_Template_C.OnLoaded_2CF9BD9E4D7B992D773DE7AE62F29135
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x8) ]
	void OnLoaded_2CF9BD9E4D7B992D773DE7AE62F29135(struct UObject* Loaded);

	// Object: Function BP_CustomPoisonCircle_Template.BP_CustomPoisonCircle_Template_C.ReceiveBeginPlay
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void ReceiveBeginPlay();

	// Object: Function BP_CustomPoisonCircle_Template.BP_CustomPoisonCircle_Template_C.ReceiveTick
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ReceiveTick(float DeltaSeconds);

	// Object: Function BP_CustomPoisonCircle_Template.BP_CustomPoisonCircle_Template_C.[S]SetNextArea
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(5) Size(0x1c) ]
	void [S]SetNextArea(struct FVector Center, float Radius, float WaitTime, float MoveTime, int32_t DamageLevel);

	// Object: Function BP_CustomPoisonCircle_Template.BP_CustomPoisonCircle_Template_C.ShowEffectInside
	// Flags: [BlueprintCosmetic|Event|Protected|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void ShowEffectInside(bool bInside);

	// Object: Function BP_CustomPoisonCircle_Template.BP_CustomPoisonCircle_Template_C.Evnet_ResetMaterial
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void Evnet_ResetMaterial();

	// Object: Function BP_CustomPoisonCircle_Template.BP_CustomPoisonCircle_Template_C.ExecuteUbergraph_BP_CustomPoisonCircle_Template
	// Flags: [Final|UbergraphFunction|HasDefaults]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_BP_CustomPoisonCircle_Template(int32_t EntryPoint);
};

