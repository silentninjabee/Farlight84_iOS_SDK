#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_CustomRoomManager_BattleRoyale.BP_CustomRoomManager_BattleRoyale_C
// Inherited Bytes: 0x49c | Struct Size: 0x49c
struct ABP_CustomRoomManager_BattleRoyale_C : ABP_CustomroomManager_C {
};

