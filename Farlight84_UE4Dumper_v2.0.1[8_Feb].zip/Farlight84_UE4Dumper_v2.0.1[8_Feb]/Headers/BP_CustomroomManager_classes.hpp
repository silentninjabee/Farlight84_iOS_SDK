#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_CustomroomManager.BP_CustomroomManager_C
// Inherited Bytes: 0x470 | Struct Size: 0x49c
struct ABP_CustomroomManager_C : ACustomRoomManager {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x470 | Size: 0x8
	enum class E_Type_Team_Member TeamMemberCount; // Offset: 0x478 | Size: 0x1
	bool IsLocalPlayerOB; // Offset: 0x479 | Size: 0x1
	char pad_0x47A[0x6]; // Offset: 0x47a | Size: 0x6
	struct TArray<struct FString> PlayerPendingRemoval; // Offset: 0x480 | Size: 0x10
	int32_t TeamCount; // Offset: 0x490 | Size: 0x4
	int32_t DeathmatchModeGroupID; // Offset: 0x494 | Size: 0x4
	int32_t SoloGameModeID; // Offset: 0x498 | Size: 0x4

	// Functions

	// Object: Function BP_CustomroomManager.BP_CustomroomManager_C.GetSpawnList
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(4) Size(0x40) ]
	void GetSpawnList(struct TArray<int32_t>& , struct TArray<int32_t>& , struct TArray<int32_t>& , struct TArray<int32_t>& );

	// Object: Function BP_CustomroomManager.BP_CustomroomManager_C.GetModeRoomUIType
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void GetModeRoomUIType(enum class EModeRoomUIType& NewParam);

	// Object: Function BP_CustomroomManager.BP_CustomroomManager_C.GetRoomInfo
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0xe8) ]
	struct FCustomRoomData GetRoomInfo();

	// Object: Function BP_CustomroomManager.BP_CustomroomManager_C.IsPlayerLocalPendingKill
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x9) ]
	void IsPlayerLocalPendingKill(struct ASCMPlayerState* Player, bool& Result);

	// Object: Function BP_CustomroomManager.BP_CustomroomManager_C.IsRoomOwner
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x9) ]
	bool IsRoomOwner(struct ASCMPlayerState* Player);

	// Object: Function BP_CustomroomManager.BP_CustomroomManager_C.SwitchMgmtWidgetLuaCall
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void SwitchMgmtWidgetLuaCall();

	// Object: Function BP_CustomroomManager.BP_CustomroomManager_C.RemoveRoomWidgetsLuaCall
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void RemoveRoomWidgetsLuaCall();

	// Object: Function BP_CustomroomManager.BP_CustomroomManager_C.GetTeamMemberCount
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void GetTeamMemberCount(int32_t& Result);

	// Object: Function BP_CustomroomManager.BP_CustomroomManager_C.PreUpdateOB
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void PreUpdateOB();

	// Object: Function BP_CustomroomManager.BP_CustomroomManager_C.InitCustomRoomInfo
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void InitCustomRoomInfo();

	// Object: Function BP_CustomroomManager.BP_CustomroomManager_C.GetCustomRoomMode
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void GetCustomRoomMode(enum class ERoomModeType& RoomMode);

	// Object: Function BP_CustomroomManager.BP_CustomroomManager_C.GetModeNameLocalization
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x8) ]
	void GetModeNameLocalization(int32_t& Mode Local ID, int32_t& Group Local ID);

	// Object: Function BP_CustomroomManager.BP_CustomroomManager_C.OnGameStart
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	bool OnGameStart();

	// Object: Function BP_CustomroomManager.BP_CustomroomManager_C.OnTournamentDealy
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnTournamentDealy();

	// Object: Function BP_CustomroomManager.BP_CustomroomManager_C.OnClientRoomDataReady
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClientRoomDataReady();

	// Object: Function BP_CustomroomManager.BP_CustomroomManager_C.ExecuteUbergraph_BP_CustomroomManager
	// Flags: [Final|UbergraphFunction|HasDefaults]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_BP_CustomroomManager(int32_t EntryPoint);
};

