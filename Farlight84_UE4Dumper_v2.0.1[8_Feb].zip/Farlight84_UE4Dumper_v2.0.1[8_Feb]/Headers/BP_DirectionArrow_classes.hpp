#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_DirectionArrow.BP_DirectionArrow_C
// Inherited Bytes: 0x228 | Struct Size: 0x248
struct ABP_DirectionArrow_C : AActor {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x228 | Size: 0x8
	struct UStaticMeshComponent* FX_G_Mesh_Arrow_Guide_001; // Offset: 0x230 | Size: 0x8
	struct USceneComponent* Scene; // Offset: 0x238 | Size: 0x8
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x240 | Size: 0x8

	// Functions

	// Object: Function BP_DirectionArrow.BP_DirectionArrow_C.Init
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0x18) ]
	void Init(struct AActor* AttachTarget, float Scale, struct FVector Position);

	// Object: Function BP_DirectionArrow.BP_DirectionArrow_C.SetVisiblity
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetVisiblity(bool NewVisiblity);

	// Object: Function BP_DirectionArrow.BP_DirectionArrow_C.UpdateDirection
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0xc) ]
	void UpdateDirection(struct FRotator Rotation);

	// Object: Function BP_DirectionArrow.BP_DirectionArrow_C.ExecuteUbergraph_BP_DirectionArrow
	// Flags: [Final|UbergraphFunction|HasDefaults]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_BP_DirectionArrow(int32_t EntryPoint);
};

