#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_FX_Defenders.BP_FX_Defenders_C
// Inherited Bytes: 0x228 | Struct Size: 0x248
struct ABP_FX_Defenders_C : ASolarTrailEffect {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x228 | Size: 0x8
	struct UParticleSystemComponent* FX_DropPathSmallDefenderFinal_Trail; // Offset: 0x230 | Size: 0x8
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x238 | Size: 0x8
	bool IsPlayer; // Offset: 0x240 | Size: 0x1
	char pad_0x241[0x3]; // Offset: 0x241 | Size: 0x3
	float FXMulti; // Offset: 0x244 | Size: 0x4

	// Functions

	// Object: Function BP_FX_Defenders.BP_FX_Defenders_C.OnFinished
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnFinished();

	// Object: Function BP_FX_Defenders.BP_FX_Defenders_C.GetTrackingTransform
	// Flags: [Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x40) ]
	struct FTransform GetTrackingTransform(struct ASolarCharacter* Character);

	// Object: Function BP_FX_Defenders.BP_FX_Defenders_C.GetFXDistance
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void GetFXDistance(float& Distance);

	// Object: Function BP_FX_Defenders.BP_FX_Defenders_C.ReceiveBeginPlay
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void ReceiveBeginPlay();

	// Object: Function BP_FX_Defenders.BP_FX_Defenders_C.ReceiveTick
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ReceiveTick(float DeltaSeconds);

	// Object: Function BP_FX_Defenders.BP_FX_Defenders_C.AttachToCharacter
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x8) ]
	void AttachToCharacter(struct ASolarCharacter* Character);

	// Object: Function BP_FX_Defenders.BP_FX_Defenders_C.ExecuteUbergraph_BP_FX_Defenders
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_BP_FX_Defenders(int32_t EntryPoint);
};

