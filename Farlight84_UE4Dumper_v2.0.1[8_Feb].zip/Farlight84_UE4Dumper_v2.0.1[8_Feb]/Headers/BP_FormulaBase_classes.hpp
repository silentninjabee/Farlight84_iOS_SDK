#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_FormulaBase.BP_FormulaBase_C
// Inherited Bytes: 0x258 | Struct Size: 0x25c
struct ABP_FormulaBase_C : ACGFormula {
	// Fields
	float ExpGain-LifeTimeLimit; // Offset: 0x258 | Size: 0x4

	// Functions

	// Object: Function BP_FormulaBase.BP_FormulaBase_C.GetCollectionItemRewards
	// Flags: [Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x58) ]
	struct TMap<int32_t, int32_t> GetCollectionItemRewards(struct ASolarPlayerState* InPS);

	// Object: Function BP_FormulaBase.BP_FormulaBase_C.GetFixedLevelExp
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0x14) ]
	int32_t GetFixedLevelExp(int32_t Origin, struct ASolarPlayerState* Player);

	// Object: Function BP_FormulaBase.BP_FormulaBase_C.GetStrategyGuideConditions
	// Flags: [Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetStrategyGuideConditions(struct ASolarPlayerState* InPS, struct TArray<int32_t>& OutResult);
};

