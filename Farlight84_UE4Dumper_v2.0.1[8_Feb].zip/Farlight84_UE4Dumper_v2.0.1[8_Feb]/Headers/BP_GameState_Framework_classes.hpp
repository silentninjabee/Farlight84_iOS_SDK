#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_GameState_Framework.BP_GameState_Framework_C
// Inherited Bytes: 0x768 | Struct Size: 0x7a9
struct ABP_GameState_Framework_C : ASCustomGameState {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x768 | Size: 0x8
	struct UBPC_PlayerManager_C* PlayerManager; // Offset: 0x770 | Size: 0x8
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x778 | Size: 0x8
	struct FMulticastInlineDelegate OnBasicSystemReady_1; // Offset: 0x780 | Size: 0x10
	bool bBasicSystemReady_1; // Offset: 0x790 | Size: 0x1
	char pad_0x791[0x3]; // Offset: 0x791 | Size: 0x3
	int32_t WarmGameID; // Offset: 0x794 | Size: 0x4
	struct FMulticastInlineDelegate OnGameStateChanged; // Offset: 0x798 | Size: 0x10
	enum class ESCMInGameState GameState; // Offset: 0x7a8 | Size: 0x1

	// Functions

	// Object: Function BP_GameState_Framework.BP_GameState_Framework_C.OnRep_GameState
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnRep_GameState();

	// Object: Function BP_GameState_Framework.BP_GameState_Framework_C.SetGameState
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetGameState(enum class ESCMInGameState NewState);

	// Object: Function BP_GameState_Framework.BP_GameState_Framework_C.OnDataManagerPrepare
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnDataManagerPrepare();

	// Object: Function BP_GameState_Framework.BP_GameState_Framework_C.ReceiveBeginPlay
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void ReceiveBeginPlay();

	// Object: Function BP_GameState_Framework.BP_GameState_Framework_C.ExecuteUbergraph_BP_GameState_Framework
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_BP_GameState_Framework(int32_t EntryPoint);

	// Object: Function BP_GameState_Framework.BP_GameState_Framework_C.OnGameStateChanged__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnGameStateChanged__DelegateSignature(enum class ESCMInGameState NewState);

	// Object: Function BP_GameState_Framework.BP_GameState_Framework_C.OnBasicSystemReady_0__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnBasicSystemReady_0__DelegateSignature();
};

