#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_HUD_BattleRoyale.BP_HUD_BattleRoyale_C
// Inherited Bytes: 0x3c8 | Struct Size: 0x401
struct ABP_HUD_BattleRoyale_C : ABattleRoyaleHUD {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x3c8 | Size: 0x8
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x3d0 | Size: 0x8
	struct TSoftObjectPtr<UUI_CountDown_C> CountDownWidget; // Offset: 0x3d8 | Size: 0x28
	bool bIsCountDown; // Offset: 0x400 | Size: 0x1

	// Functions

	// Object: Function BP_HUD_BattleRoyale.BP_HUD_BattleRoyale_C.Close Count Down Widget
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void Close Count Down Widget();

	// Object: Function BP_HUD_BattleRoyale.BP_HUD_BattleRoyale_C.GetCountDownWidget
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x8) ]
	void GetCountDownWidget(struct UUI_CountDown_C*& UI_CountDown);

	// Object: Function BP_HUD_BattleRoyale.BP_HUD_BattleRoyale_C.K2_HandleCountDownToBegin
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void K2_HandleCountDownToBegin(char InValue);

	// Object: Function BP_HUD_BattleRoyale.BP_HUD_BattleRoyale_C.K2_HandleCountDownToStopMatching
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void K2_HandleCountDownToStopMatching(char InValue);

	// Object: Function BP_HUD_BattleRoyale.BP_HUD_BattleRoyale_C.K2_OnCountdownChanged
	// Flags: [Event|Protected|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void K2_OnCountdownChanged(char InValue);

	// Object: Function BP_HUD_BattleRoyale.BP_HUD_BattleRoyale_C.K2_InitBattleHUD
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void K2_InitBattleHUD();

	// Object: Function BP_HUD_BattleRoyale.BP_HUD_BattleRoyale_C.CustomEvent_1
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void CustomEvent_1(enum class ESCMInGameState NewState);

	// Object: Function BP_HUD_BattleRoyale.BP_HUD_BattleRoyale_C.ExecuteUbergraph_BP_HUD_BattleRoyale
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_BP_HUD_BattleRoyale(int32_t EntryPoint);
};

