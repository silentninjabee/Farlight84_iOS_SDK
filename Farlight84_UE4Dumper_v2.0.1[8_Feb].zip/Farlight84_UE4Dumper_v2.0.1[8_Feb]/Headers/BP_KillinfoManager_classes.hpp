#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_KillinfoManager.BP_KillinfoManager_C
// Inherited Bytes: 0x5b8 | Struct Size: 0x5b8
struct ABP_KillinfoManager_C : AKillInfoManager {
};

