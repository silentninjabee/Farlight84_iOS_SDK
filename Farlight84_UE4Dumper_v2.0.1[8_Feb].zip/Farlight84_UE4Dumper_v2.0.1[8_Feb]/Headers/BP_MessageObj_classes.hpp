#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_MessageObj.BP_MessageObj_C
// Inherited Bytes: 0x28 | Struct Size: 0x60
struct UBP_MessageObj_C : UObject {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x28 | Size: 0x8
	struct FMulticastInlineDelegate OnTimeOut; // Offset: 0x30 | Size: 0x10
	bool IsRunning; // Offset: 0x40 | Size: 0x1
	char pad_0x41[0x7]; // Offset: 0x41 | Size: 0x7
	struct FTimerHandle Timer; // Offset: 0x48 | Size: 0x8
	bool IsBlocking; // Offset: 0x50 | Size: 0x1
	char pad_0x51[0x3]; // Offset: 0x51 | Size: 0x3
	struct FS_MessageRequest NewVar_1; // Offset: 0x54 | Size: 0xc

	// Functions

	// Object: Function BP_MessageObj.BP_MessageObj_C.Init
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0x11) ]
	void Init(struct FS_MessageRequest MessageInfo, int32_t Time, bool& Return);

	// Object: Function BP_MessageObj.BP_MessageObj_C.ReplyDeal
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x5) ]
	void ReplyDeal(int32_t BlockTime, bool Reply);

	// Object: Function BP_MessageObj.BP_MessageObj_C.Timeout
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void Timeout();

	// Object: Function BP_MessageObj.BP_MessageObj_C.BlockTimeUp
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void BlockTimeUp();

	// Object: Function BP_MessageObj.BP_MessageObj_C.ExecuteUbergraph_BP_MessageObj
	// Flags: [Final|UbergraphFunction|HasDefaults]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_BP_MessageObj(int32_t EntryPoint);

	// Object: Function BP_MessageObj.BP_MessageObj_C.OnTimeOut__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0xc) ]
	void OnTimeOut__DelegateSignature(struct FS_MessageRequest Info);
};

