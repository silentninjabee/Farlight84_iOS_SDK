#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_Mode_BattleRoyale.BP_Mode_BattleRoyale_C
// Inherited Bytes: 0x918 | Struct Size: 0x960
struct ABP_Mode_BattleRoyale_C : ABattleRoyaleGameMode {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x918 | Size: 0x8
	struct UBPC_EXPSpringModeComponent_C* BPC_EXPSpringModeComponent; // Offset: 0x920 | Size: 0x8
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x928 | Size: 0x8
	struct UBPC_WarmGame_BattleRoyale_C* BPC_WarmGame_BattleRoyale; // Offset: 0x930 | Size: 0x8
	struct UBPC_AiManagerBattleRoyale_C* BPC_AiManagerBattleRoyale; // Offset: 0x938 | Size: 0x8
	struct UNgaiGameModeComponent* NgaiGameMode; // Offset: 0x940 | Size: 0x8
	struct UBattleRoyaleGameModeAIComp_Custom_C* BattleRoyaleGameModeAIComp_Custom; // Offset: 0x948 | Size: 0x8
	struct UBPC_AirlineCruise_C* BPC_AirlineCruise; // Offset: 0x950 | Size: 0x8
	struct UBP_MapInfoComponent_C* BP_MapInfoComponent; // Offset: 0x958 | Size: 0x8

	// Functions

	// Object: Function BP_Mode_BattleRoyale.BP_Mode_BattleRoyale_C.GetAirlineCruiseComponent
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UAirlineCruiseComponent* GetAirlineCruiseComponent();

	// Object: Function BP_Mode_BattleRoyale.BP_Mode_BattleRoyale_C.ReadyToFinal
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	bool ReadyToFinal();

	// Object: Function BP_Mode_BattleRoyale.BP_Mode_BattleRoyale_C.IsKillWhenPlayerOut
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x9) ]
	bool IsKillWhenPlayerOut(struct ASolarPlayerState* PlayerState);

	// Object: Function BP_Mode_BattleRoyale.BP_Mode_BattleRoyale_C.ReceiveBeginPlay
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void ReceiveBeginPlay();

	// Object: Function BP_Mode_BattleRoyale.BP_Mode_BattleRoyale_C.UpdateDeserterTag
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x8) ]
	void UpdateDeserterTag(struct ASolarPlayerState* PlayerState);

	// Object: Function BP_Mode_BattleRoyale.BP_Mode_BattleRoyale_C.K2_OnSetMatchState
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x8) ]
	void K2_OnSetMatchState(struct FName NewState);

	// Object: Function BP_Mode_BattleRoyale.BP_Mode_BattleRoyale_C.ExecuteUbergraph_BP_Mode_BattleRoyale
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_BP_Mode_BattleRoyale(int32_t EntryPoint);
};

