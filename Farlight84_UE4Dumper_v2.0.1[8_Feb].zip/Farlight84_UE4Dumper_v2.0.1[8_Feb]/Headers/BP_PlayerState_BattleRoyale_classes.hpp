#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_PlayerState_BattleRoyale.BP_PlayerState_BattleRoyale_C
// Inherited Bytes: 0xea0 | Struct Size: 0xed5
struct ABP_PlayerState_BattleRoyale_C : ABP_PlayerState_Framework_C {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0xea0 | Size: 0x8
	struct UBPC_BuyResurrection_C* BPC_BuyResurrection; // Offset: 0xea8 | Size: 0x8
	struct USolarUserWidget* DeathUI; // Offset: 0xeb0 | Size: 0x8
	enum class E_PlayerBattleState_BattleRoyale PlayerBattleState; // Offset: 0xeb8 | Size: 0x1
	char pad_0xEB9[0x7]; // Offset: 0xeb9 | Size: 0x7
	struct FMulticastInlineDelegate OnRequestReplied; // Offset: 0xec0 | Size: 0x10
	int32_t Intervened By AI; // Offset: 0xed0 | Size: 0x4
	bool bFirstDive; // Offset: 0xed4 | Size: 0x1

	// Functions

	// Object: Function BP_PlayerState_BattleRoyale.BP_PlayerState_BattleRoyale_C.PlayerCanRebirthBlueprint
	// Flags: [Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	bool PlayerCanRebirthBlueprint();

	// Object: Function BP_PlayerState_BattleRoyale.BP_PlayerState_BattleRoyale_C.PlayerIsResurrecting
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	bool PlayerIsResurrecting();

	// Object: Function BP_PlayerState_BattleRoyale.BP_PlayerState_BattleRoyale_C.IsPlayerWaitingForTeammatesHelp
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsPlayerWaitingForTeammatesHelp();

	// Object: Function BP_PlayerState_BattleRoyale.BP_PlayerState_BattleRoyale_C.GetItemData
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(4) Size(0x10) ]
	void GetItemData(int32_t ItemID, bool& Valid, int32_t& ID, int32_t& Quality);

	// Object: Function BP_PlayerState_BattleRoyale.BP_PlayerState_BattleRoyale_C.GetPlayerChestOpen
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x10) ]
	void GetPlayerChestOpen(struct FString& Output);

	// Object: Function BP_PlayerState_BattleRoyale.BP_PlayerState_BattleRoyale_C.GetSinglePlayerItem
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0xc) ]
	void GetSinglePlayerItem(int32_t ItemID, bool& HasItem, int32_t& count);

	// Object: Function BP_PlayerState_BattleRoyale.BP_PlayerState_BattleRoyale_C.GetWeaponPartData
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(4) Size(0x10) ]
	void GetWeaponPartData(int32_t ItemID, bool& Valid, int32_t& ID, int32_t& Quality);

	// Object: Function BP_PlayerState_BattleRoyale.BP_PlayerState_BattleRoyale_C.GetPlayerItems
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x10) ]
	void GetPlayerItems(struct FString& Output);

	// Object: Function BP_PlayerState_BattleRoyale.BP_PlayerState_BattleRoyale_C.Get Player Accessories
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x10) ]
	void Get Player Accessories(struct FString& Output);

	// Object: Function BP_PlayerState_BattleRoyale.BP_PlayerState_BattleRoyale_C.Set Intervened By AI
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void Set Intervened By AI();

	// Object: Function BP_PlayerState_BattleRoyale.BP_PlayerState_BattleRoyale_C.GetNearestPos
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void GetNearestPos(enum class E_GuidTargetType Index);

	// Object: Function BP_PlayerState_BattleRoyale.BP_PlayerState_BattleRoyale_C.OnRep_PlayerBattleState
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnRep_PlayerBattleState();

	// Object: Function BP_PlayerState_BattleRoyale.BP_PlayerState_BattleRoyale_C.[s]SetPlayerState
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void [s]SetPlayerState(enum class E_PlayerBattleState_BattleRoyale State);

	// Object: Function BP_PlayerState_BattleRoyale.BP_PlayerState_BattleRoyale_C.ReceiveBeginPlay
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void ReceiveBeginPlay();

	// Object: Function BP_PlayerState_BattleRoyale.BP_PlayerState_BattleRoyale_C.Event_RespondReconnection
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void Event_RespondReconnection();

	// Object: Function BP_PlayerState_BattleRoyale.BP_PlayerState_BattleRoyale_C.ResurrectionStateChange
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void ResurrectionStateChange(enum class EResurrectionState NewState);

	// Object: Function BP_PlayerState_BattleRoyale.BP_PlayerState_BattleRoyale_C.RequestNearestPos
	// Flags: [Net|NetServer|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void RequestNearestPos(enum class E_GuidTargetType Type);

	// Object: Function BP_PlayerState_BattleRoyale.BP_PlayerState_BattleRoyale_C.OnNearestPosReceived
	// Flags: [Net|NetClient|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x10) ]
	void OnNearestPosReceived(enum class E_GuidTargetType Type, struct FVector Pos);

	// Object: Function BP_PlayerState_BattleRoyale.BP_PlayerState_BattleRoyale_C.OnPlayerGainExperience
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(4) Size(0xd) ]
	void OnPlayerGainExperience(int32_t GainedExp, int32_t CurrentExp, int32_t TotalExp, enum class EExpBehaviorType BehaviorType);

	// Object: Function BP_PlayerState_BattleRoyale.BP_PlayerState_BattleRoyale_C.DelayAndBeginSpectate
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void DelayAndBeginSpectate();

	// Object: Function BP_PlayerState_BattleRoyale.BP_PlayerState_BattleRoyale_C.ExecuteUbergraph_BP_PlayerState_BattleRoyale
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_BP_PlayerState_BattleRoyale(int32_t EntryPoint);

	// Object: Function BP_PlayerState_BattleRoyale.BP_PlayerState_BattleRoyale_C.OnRequestReplied__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x10) ]
	void OnRequestReplied__DelegateSignature(enum class E_GuidTargetType Type, struct FVector Pos);
};

