#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_ReviveItemManger_1.BP_ReviveItemManger_0_C
// Inherited Bytes: 0x280 | Struct Size: 0x368
struct ABP_ReviveItemManger_0_C : AGameReviveItemManager {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x280 | Size: 0x8
	int32_t ReviveItem; // Offset: 0x288 | Size: 0x4
	char pad_0x28C[0x4]; // Offset: 0x28c | Size: 0x4
	struct TMap<struct ASolarPlayerState*, int32_t> Player_ReviveTimes; // Offset: 0x290 | Size: 0x50
	int32_t AdvanceNoticeTime; // Offset: 0x2e0 | Size: 0x4
	char pad_0x2E4[0x4]; // Offset: 0x2e4 | Size: 0x4
	struct TArray<struct FF_ReviveItemData> ReviveItemData; // Offset: 0x2e8 | Size: 0x10
	bool ClearItemNotice; // Offset: 0x2f8 | Size: 0x1
	bool AdvanceNotice; // Offset: 0x2f9 | Size: 0x1
	char pad_0x2FA[0x2]; // Offset: 0x2fa | Size: 0x2
	int32_t CurTime; // Offset: 0x2fc | Size: 0x4
	bool bCanReviveImmediatelyWhenDown; // Offset: 0x300 | Size: 0x1
	char pad_0x301[0x3]; // Offset: 0x301 | Size: 0x3
	int32_t ReviveDisableCountDown; // Offset: 0x304 | Size: 0x4
	int32_t ReviveStartRecycleTime; // Offset: 0x308 | Size: 0x4
	char pad_0x30C[0x4]; // Offset: 0x30c | Size: 0x4
	struct TMap<enum class E_ReviveItemSoundType, struct FString> NoticeSound; // Offset: 0x310 | Size: 0x50
	struct UUI_HUD_Notice_Revive_C* ReviveUI; // Offset: 0x360 | Size: 0x8

	// Functions

	// Object: Function BP_ReviveItemManger_1.BP_ReviveItemManger_0_C.On Player Battle End
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x8) ]
	void On Player Battle End(struct ASCMPlayerState* Player);

	// Object: Function BP_ReviveItemManger_1.BP_ReviveItemManger_0_C.GetResurrectByItemUI
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x8) ]
	void GetResurrectByItemUI(struct UUI_HUD_Notice_Revive_C*& Output_Get);

	// Object: Function BP_ReviveItemManger_1.BP_ReviveItemManger_0_C.SetPlayerReviveData
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x20) ]
	void SetPlayerReviveData(struct ASolarPlayerState* Player, struct FF_ReviveItemData Data);

	// Object: Function BP_ReviveItemManger_1.BP_ReviveItemManger_0_C.GetPlayerReviveData
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0x21) ]
	void GetPlayerReviveData(struct ASolarPlayerState* Player, struct FF_ReviveItemData& Data, bool& bFind);

	// Object: Function BP_ReviveItemManger_1.BP_ReviveItemManger_0_C.RemovePlayerFromRevivingPlayerArr
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x8) ]
	void RemovePlayerFromRevivingPlayerArr(struct ASolarPlayerState*& Player);

	// Object: Function BP_ReviveItemManger_1.BP_ReviveItemManger_0_C.AddPlayerIntoRevivingPlayerArr
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x8) ]
	void AddPlayerIntoRevivingPlayerArr(struct ASolarPlayerState*& Player);

	// Object: Function BP_ReviveItemManger_1.BP_ReviveItemManger_0_C.OnRep_AdvanceNotice
	// Flags: [HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnRep_AdvanceNotice();

	// Object: Function BP_ReviveItemManger_1.BP_ReviveItemManger_0_C.OnRep_ClearItemNotice
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnRep_ClearItemNotice();

	// Object: Function BP_ReviveItemManger_1.BP_ReviveItemManger_0_C.[ S]Try to Revive Player with Item
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x9) ]
	bool [ S]Try to Revive Player with Item(struct ASolarPlayerState* Player);

	// Object: Function BP_ReviveItemManger_1.BP_ReviveItemManger_0_C.Set Player Use Revive Item Times
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x8) ]
	void Set Player Use Revive Item Times(struct ASolarPlayerState* Player);

	// Object: Function BP_ReviveItemManger_1.BP_ReviveItemManger_0_C.[ A]Get Player Use Revive Item Times
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0xc) ]
	void [ A]Get Player Use Revive Item Times(struct ASolarPlayerState* Player, int32_t& Value);

	// Object: Function BP_ReviveItemManger_1.BP_ReviveItemManger_0_C.CanPlayerUseReviveItem
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0xa) ]
	bool CanPlayerUseReviveItem(struct ASolarPlayerState* InPlayerState, bool bCheckItemNum);

	// Object: Function BP_ReviveItemManger_1.BP_ReviveItemManger_0_C.CanGlobalUseReviveItem
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	bool CanGlobalUseReviveItem();

	// Object: Function BP_ReviveItemManger_1.BP_ReviveItemManger_0_C.RevivePlayer
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0x41) ]
	void RevivePlayer(struct ASolarCharacter* , struct FTransform& , bool& bool);

	// Object: Function BP_ReviveItemManger_1.BP_ReviveItemManger_0_C.ReceiveBeginPlay
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void ReceiveBeginPlay();

	// Object: Function BP_ReviveItemManger_1.BP_ReviveItemManger_0_C.Event_ClearRevive
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void Event_ClearRevive();

	// Object: Function BP_ReviveItemManger_1.BP_ReviveItemManger_0_C.OnPlayerResurrected
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x10) ]
	void OnPlayerResurrected(enum class E_ResurrectType ResurrectType, struct ABP_PlayerState_Framework_C* TargetPlayer);

	// Object: Function BP_ReviveItemManger_1.BP_ReviveItemManger_0_C.Event_ClearReviveNotifyInAdvance
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void Event_ClearReviveNotifyInAdvance();

	// Object: Function BP_ReviveItemManger_1.BP_ReviveItemManger_0_C.Event_InitReviveItem
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void Event_InitReviveItem();

	// Object: Function BP_ReviveItemManger_1.BP_ReviveItemManger_0_C.UpdateTime
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void UpdateTime();

	// Object: Function BP_ReviveItemManger_1.BP_ReviveItemManger_0_C.DownReviveImmediately
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x8) ]
	void DownReviveImmediately(struct ASolarPlayerState* Player);

	// Object: Function BP_ReviveItemManger_1.BP_ReviveItemManger_0_C.OnPlayerHealthStateChanged
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x9) ]
	void OnPlayerHealthStateChanged(struct ABP_PlayerState_Framework_C* InPlayerState, enum class E_CharacterHealthState NewState);

	// Object: Function BP_ReviveItemManger_1.BP_ReviveItemManger_0_C.ReviveDisableNotice
	// Flags: [Net|NetMulticast|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ReviveDisableNotice(int32_t Time);

	// Object: Function BP_ReviveItemManger_1.BP_ReviveItemManger_0_C.Event_PlayerReconnect
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x8) ]
	void Event_PlayerReconnect(struct ASCMPlayerState* Player);

	// Object: Function BP_ReviveItemManger_1.BP_ReviveItemManger_0_C.OnStartReviveItemRecycleCountDownDataRequested
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnStartReviveItemRecycleCountDownDataRequested();

	// Object: Function BP_ReviveItemManger_1.BP_ReviveItemManger_0_C.OnSpecTargetChanged_Event_1
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x10) ]
	void OnSpecTargetChanged_Event_1(struct ASolarPlayerState* OldTarget, struct ASolarPlayerState* NewTarget);

	// Object: Function BP_ReviveItemManger_1.BP_ReviveItemManger_0_C.ExecuteUbergraph_BP_ReviveItemManger_1
	// Flags: [Final|UbergraphFunction|HasDefaults]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_BP_ReviveItemManger_1(int32_t EntryPoint);
};

