#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_SI_JumpPad.BP_SI_JumpPad_C
// Inherited Bytes: 0x238 | Struct Size: 0x2d1
struct ABP_SI_JumpPad_C : ASolarInteractableActor {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x238 | Size: 0x8
	struct UStaticMeshComponent* FX_Center_Logo; // Offset: 0x240 | Size: 0x8
	struct UBoxComponent* Box; // Offset: 0x248 | Size: 0x8
	struct UParticleSystemComponent* FX_P_JumpPad_002; // Offset: 0x250 | Size: 0x8
	struct UStaticMeshComponent* VFX_Dark; // Offset: 0x258 | Size: 0x8
	struct USceneComponent* VFX; // Offset: 0x260 | Size: 0x8
	struct USceneComponent* point001; // Offset: 0x268 | Size: 0x8
	struct UStaticMeshComponent* Progress; // Offset: 0x270 | Size: 0x8
	struct UStaticMeshComponent* StaticMesh; // Offset: 0x278 | Size: 0x8
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x280 | Size: 0x8
	struct FVector Timeline_0_Scale_EDFE8BE84808C1122C8F3CA456F9CAC3; // Offset: 0x288 | Size: 0xc
	float Timeline_0_alpha_EDFE8BE84808C1122C8F3CA456F9CAC3; // Offset: 0x294 | Size: 0x4
	enum class ETimelineDirection Timeline_0__Direction_EDFE8BE84808C1122C8F3CA456F9CAC3; // Offset: 0x298 | Size: 0x1
	char pad_0x299[0x7]; // Offset: 0x299 | Size: 0x7
	struct UTimelineComponent* Timeline_1; // Offset: 0x2a0 | Size: 0x8
	float Zvelority; // Offset: 0x2a8 | Size: 0x4
	float OriginalZ; // Offset: 0x2ac | Size: 0x4
	float CD; // Offset: 0x2b0 | Size: 0x4
	float CoolDownTime; // Offset: 0x2b4 | Size: 0x4
	bool IsInCD; // Offset: 0x2b8 | Size: 0x1
	char pad_0x2B9[0x7]; // Offset: 0x2b9 | Size: 0x7
	struct TArray<struct ASolarCharacter*> Characters; // Offset: 0x2c0 | Size: 0x10
	bool TransientLaunch; // Offset: 0x2d0 | Size: 0x1

	// Functions

	// Object: Function BP_SI_JumpPad.BP_SI_JumpPad_C.ServerCheckLaunch
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void ServerCheckLaunch(bool& Launch);

	// Object: Function BP_SI_JumpPad.BP_SI_JumpPad_C.UpdateProgress
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void UpdateProgress(float Percent);

	// Object: Function BP_SI_JumpPad.BP_SI_JumpPad_C.ShowInCD
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void ShowInCD(bool InCD);

	// Object: Function BP_SI_JumpPad.BP_SI_JumpPad_C.Timeline_0__FinishedFunc
	// Flags: [BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void Timeline_0__FinishedFunc();

	// Object: Function BP_SI_JumpPad.BP_SI_JumpPad_C.Timeline_0__UpdateFunc
	// Flags: [BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void Timeline_0__UpdateFunc();

	// Object: Function BP_SI_JumpPad.BP_SI_JumpPad_C.ReceiveBeginPlay
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void ReceiveBeginPlay();

	// Object: Function BP_SI_JumpPad.BP_SI_JumpPad_C.ReceiveTick
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ReceiveTick(float DeltaSeconds);

	// Object: Function BP_SI_JumpPad.BP_SI_JumpPad_C.BreakLoop
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void BreakLoop();

	// Object: Function BP_SI_JumpPad.BP_SI_JumpPad_C.BndEvt__Box_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature
	// Flags: [HasOutParms|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(6) Size(0xa8) ]
	void BndEvt__Box_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult);

	// Object: Function BP_SI_JumpPad.BP_SI_JumpPad_C.BndEvt__Box_K2Node_ComponentBoundEvent_3_ComponentEndOverlapSignature__DelegateSignature
	// Flags: [BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(4) Size(0x1c) ]
	void BndEvt__Box_K2Node_ComponentBoundEvent_3_ComponentEndOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex);

	// Object: Function BP_SI_JumpPad.BP_SI_JumpPad_C.Launch
	// Flags: [HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x10) ]
	void Launch(struct TArray<struct ASolarCharacter*>& Characters);

	// Object: Function BP_SI_JumpPad.BP_SI_JumpPad_C.ClientFinishLaunch
	// Flags: [Net|NetMulticast|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void ClientFinishLaunch();

	// Object: Function BP_SI_JumpPad.BP_SI_JumpPad_C.LaunchEffect
	// Flags: [Net|NetMulticast|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void LaunchEffect();

	// Object: Function BP_SI_JumpPad.BP_SI_JumpPad_C.Set_CD
	// Flags: [Net|NetMulticast|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void Set_CD(float CD);

	// Object: Function BP_SI_JumpPad.BP_SI_JumpPad_C.Set_State
	// Flags: [Net|NetMulticast|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x8) ]
	void Set_State(bool InCD, float CD);

	// Object: Function BP_SI_JumpPad.BP_SI_JumpPad_C.ExecuteUbergraph_BP_SI_JumpPad
	// Flags: [Final|UbergraphFunction|HasDefaults]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_BP_SI_JumpPad(int32_t EntryPoint);
};

