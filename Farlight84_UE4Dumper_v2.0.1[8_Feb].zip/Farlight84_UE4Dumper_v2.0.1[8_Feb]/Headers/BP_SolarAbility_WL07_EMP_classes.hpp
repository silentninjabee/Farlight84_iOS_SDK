#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_SolarAbility_WL07_EMP.BP_SolarAbility_WL07_EMP_C
// Inherited Bytes: 0x320 | Struct Size: 0x320
struct ABP_SolarAbility_WL07_EMP_C : ASolarWeaponAbilityTemp {
};

