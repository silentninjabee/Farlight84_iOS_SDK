#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_SolarBackpackActor.BP_SolarBackpackActor_C
// Inherited Bytes: 0x320 | Struct Size: 0x320
struct ABP_SolarBackpackActor_C : ASolarBackpackActor {
	// Functions

	// Object: Function BP_SolarBackpackActor.BP_SolarBackpackActor_C.LobbyForceSetLOD
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void LobbyForceSetLOD();

	// Object: Function BP_SolarBackpackActor.BP_SolarBackpackActor_C.TryCreateDynamicMaterialInstance
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(5) Size(0x28) ]
	struct UMaterialInstanceDynamic* TryCreateDynamicMaterialInstance(struct UPrimitiveComponent* Component, int32_t ElementIndex, struct UMaterialInterface* SourceMaterial, struct FName OptionlName);

	// Object: Function BP_SolarBackpackActor.BP_SolarBackpackActor_C.FX_Idle
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void FX_Idle();

	// Object: Function BP_SolarBackpackActor.BP_SolarBackpackActor_C.FX_Flying
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void FX_Flying();

	// Object: Function BP_SolarBackpackActor.BP_SolarBackpackActor_C.FX_Charging
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void FX_Charging();

	// Object: Function BP_SolarBackpackActor.BP_SolarBackpackActor_C.FX_LowPower
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void FX_LowPower();

	// Object: Function BP_SolarBackpackActor.BP_SolarBackpackActor_C.FX_Default
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void FX_Default();
};

