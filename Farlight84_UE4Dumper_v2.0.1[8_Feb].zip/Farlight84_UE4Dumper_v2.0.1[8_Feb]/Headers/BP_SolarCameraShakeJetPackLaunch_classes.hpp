#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_SolarCameraShakeJetPackLaunch.BP_SolarCameraShakeJetPackLaunch_C
// Inherited Bytes: 0x160 | Struct Size: 0x160
struct UBP_SolarCameraShakeJetPackLaunch_C : UCameraShake {
};

