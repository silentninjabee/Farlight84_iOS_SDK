#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_SolarCapsuleActor.BP_SolarCapsuleActor_C
// Inherited Bytes: 0x390 | Struct Size: 0x398
struct ABP_SolarCapsuleActor_C : ABP_CapsuleBase_InBattle_C {
	// Fields
	struct UStaticMeshComponent* FX_G_Cricle_Spread_002; // Offset: 0x390 | Size: 0x8
};

