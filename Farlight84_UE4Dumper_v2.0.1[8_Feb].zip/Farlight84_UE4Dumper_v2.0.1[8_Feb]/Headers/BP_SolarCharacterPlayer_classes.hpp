#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_SolarCharacterPlayer.BP_SolarCharacterPlayer_C
// Inherited Bytes: 0x25a0 | Struct Size: 0x2658
struct ABP_SolarCharacterPlayer_C : ASolarCharacter {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x25a0 | Size: 0x8
	struct USolarAbilityComponent* SolarAbility; // Offset: 0x25a8 | Size: 0x8
	struct FVector PreviousLocation; // Offset: 0x25b0 | Size: 0xc
	float Time; // Offset: 0x25bc | Size: 0x4
	float CurrentTime; // Offset: 0x25c0 | Size: 0x4
	float PreviousTime; // Offset: 0x25c4 | Size: 0x4
	float DeltaTime; // Offset: 0x25c8 | Size: 0x4
	struct FVector DeltaLocation; // Offset: 0x25cc | Size: 0xc
	bool OnTouch; // Offset: 0x25d8 | Size: 0x1
	char pad_0x25D9[0x3]; // Offset: 0x25d9 | Size: 0x3
	float Speed; // Offset: 0x25dc | Size: 0x4
	struct FVector2D Direction; // Offset: 0x25e0 | Size: 0x8
	struct TArray<float> SpeedRecord; // Offset: 0x25e8 | Size: 0x10
	struct TArray<struct FVector> LocationRecord; // Offset: 0x25f8 | Size: 0x10
	struct TArray<float> Record_X; // Offset: 0x2608 | Size: 0x10
	struct TArray<float> Record_y; // Offset: 0x2618 | Size: 0x10
	float SpeedFixBase; // Offset: 0x2628 | Size: 0x4
	char pad_0x262C[0x4]; // Offset: 0x262c | Size: 0x4
	struct UCurveFloat* SpeedFix; // Offset: 0x2630 | Size: 0x8
	struct FMulticastInlineDelegate OnEjectingStateChanged; // Offset: 0x2638 | Size: 0x10
	enum class E_CharacterEjectState EjectState; // Offset: 0x2648 | Size: 0x1
	char pad_0x2649[0x3]; // Offset: 0x2649 | Size: 0x3
	int32_t PoisonDamageNum; // Offset: 0x264c | Size: 0x4
	struct ASolarCharacter* Shadow AI; // Offset: 0x2650 | Size: 0x8

	// Functions

	// Object: Function BP_SolarCharacterPlayer.BP_SolarCharacterPlayer_C.GetSolarCameraComponent
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x8) ]
	struct USolarCameraComponent* GetSolarCameraComponent();

	// Object: Function BP_SolarCharacterPlayer.BP_SolarCharacterPlayer_C.GetSolarSpringArmComponent
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x8) ]
	struct USolarSpringArmComponent* GetSolarSpringArmComponent();

	// Object: Function BP_SolarCharacterPlayer.BP_SolarCharacterPlayer_C.RefreshRenderConsoleVarForSkydive
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void RefreshRenderConsoleVarForSkydive();

	// Object: Function BP_SolarCharacterPlayer.BP_SolarCharacterPlayer_C.Is Observation Target
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	bool Is Observation Target();

	// Object: Function BP_SolarCharacterPlayer.BP_SolarCharacterPlayer_C.FixSpeed
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	float FixSpeed();

	// Object: Function BP_SolarCharacterPlayer.BP_SolarCharacterPlayer_C.FigureSpeed
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void FigureSpeed();

	// Object: Function BP_SolarCharacterPlayer.BP_SolarCharacterPlayer_C.GetFixedY
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x8) ]
	float GetFixedY(float NewParam);

	// Object: Function BP_SolarCharacterPlayer.BP_SolarCharacterPlayer_C.GetFixedX
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x8) ]
	float GetFixedX(float NewParam);

	// Object: Function BP_SolarCharacterPlayer.BP_SolarCharacterPlayer_C.SetCameraInput_3
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void SetCameraInput_3();

	// Object: Function BP_SolarCharacterPlayer.BP_SolarCharacterPlayer_C.SetCameraInput
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void SetCameraInput();

	// Object: Function BP_SolarCharacterPlayer.BP_SolarCharacterPlayer_C.GetFixedLocation
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x18) ]
	struct FVector GetFixedLocation(struct FVector InLocation);

	// Object: Function BP_SolarCharacterPlayer.BP_SolarCharacterPlayer_C.GetFixedSpeed
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x8) ]
	float GetFixedSpeed(float NewParam);

	// Object: Function BP_SolarCharacterPlayer.BP_SolarCharacterPlayer_C.DecelerationEffectUpdate
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x18) ]
	void DecelerationEffectUpdate(float& Altitude, struct TArray<struct UParticleSystemComponent*>& Effects);

	// Object: Function BP_SolarCharacterPlayer.BP_SolarCharacterPlayer_C.UndecelerationEffectUpdate
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x18) ]
	void UndecelerationEffectUpdate(float& Altitude, struct TArray<struct UParticleSystemComponent*>& Effects);

	// Object: Function BP_SolarCharacterPlayer.BP_SolarCharacterPlayer_C.InpActEvt_BackSpace_K2Node_InputKeyEvent_4
	// Flags: [BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x18) ]
	void InpActEvt_BackSpace_K2Node_InputKeyEvent_4(struct FKey Key);

	// Object: Function BP_SolarCharacterPlayer.BP_SolarCharacterPlayer_C.InpActEvt_Home_K2Node_InputKeyEvent_3
	// Flags: [BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x18) ]
	void InpActEvt_Home_K2Node_InputKeyEvent_3(struct FKey Key);

	// Object: Function BP_SolarCharacterPlayer.BP_SolarCharacterPlayer_C.InpActEvt_End_K2Node_InputKeyEvent_2
	// Flags: [BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x18) ]
	void InpActEvt_End_K2Node_InputKeyEvent_2(struct FKey Key);

	// Object: Function BP_SolarCharacterPlayer.BP_SolarCharacterPlayer_C.InpActEvt_Delete_K2Node_InputKeyEvent_1
	// Flags: [BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x18) ]
	void InpActEvt_Delete_K2Node_InputKeyEvent_1(struct FKey Key);

	// Object: Function BP_SolarCharacterPlayer.BP_SolarCharacterPlayer_C.ReceiveUpdateSkydiveLandingEffects
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ReceiveUpdateSkydiveLandingEffects(float DistanceToGround);

	// Object: Function BP_SolarCharacterPlayer.BP_SolarCharacterPlayer_C.ReceivePlaySkydiveLandingEndEffects
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void ReceivePlaySkydiveLandingEndEffects(bool bIsInWater);

	// Object: Function BP_SolarCharacterPlayer.BP_SolarCharacterPlayer_C.K2_OnMovementModeChanged
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(4) Size(0x4) ]
	void K2_OnMovementModeChanged(enum class EMovementMode PrevMovementMode, enum class EMovementMode NewMovementMode, char PrevCustomMode, char NewCustomMode);

	// Object: Function BP_SolarCharacterPlayer.BP_SolarCharacterPlayer_C.ReceiveUpdateSkydiveFlyingEffects
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ReceiveUpdateSkydiveFlyingEffects(float FallingRate);

	// Object: Function BP_SolarCharacterPlayer.BP_SolarCharacterPlayer_C.ReceiveEndPlay
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void ReceiveEndPlay(enum class EEndPlayReason EndPlayReason);

	// Object: Function BP_SolarCharacterPlayer.BP_SolarCharacterPlayer_C.ReceiveBeginPlay
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void ReceiveBeginPlay();

	// Object: Function BP_SolarCharacterPlayer.BP_SolarCharacterPlayer_C.SetOpenScopeDuration
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x5) ]
	void SetOpenScopeDuration(float InDuration, bool bInOpenScope);

	// Object: Function BP_SolarCharacterPlayer.BP_SolarCharacterPlayer_C.Event_UseReviveItem
	// Flags: [Net|NetMulticast|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x8) ]
	void Event_UseReviveItem(struct ASCMPlayerState* Player);

	// Object: Function BP_SolarCharacterPlayer.BP_SolarCharacterPlayer_C.OnSkydiveStageChanged
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x2) ]
	void OnSkydiveStageChanged(enum class ESkydiveStage LastStage, enum class ESkydiveStage CurrentStage);

	// Object: Function BP_SolarCharacterPlayer.BP_SolarCharacterPlayer_C.OnCharacterEjectStateChanged
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnCharacterEjectStateChanged(enum class E_CharacterEjectState State);

	// Object: Function BP_SolarCharacterPlayer.BP_SolarCharacterPlayer_C.ExecuteUbergraph_BP_SolarCharacterPlayer
	// Flags: [Final|UbergraphFunction|HasDefaults]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_BP_SolarCharacterPlayer(int32_t EntryPoint);

	// Object: Function BP_SolarCharacterPlayer.BP_SolarCharacterPlayer_C.OnEjectingStateChanged__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x10) ]
	void OnEjectingStateChanged__DelegateSignature(enum class E_CharacterEjectState State, struct ASolarCharacter* TargetCharacter);
};

