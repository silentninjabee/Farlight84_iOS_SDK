#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_SolarLobbyCharacter.BP_SolarLobbyCharacter_C
// Inherited Bytes: 0x448 | Struct Size: 0x4a8
struct ABP_SolarLobbyCharacter_C : ASolarLobbyCharacter {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x448 | Size: 0x8
	struct UMediaSoundComponent* MediaSound; // Offset: 0x450 | Size: 0x8
	struct TMap<int32_t, bool> NewVar_1; // Offset: 0x458 | Size: 0x50

	// Functions

	// Object: Function BP_SolarLobbyCharacter.BP_SolarLobbyCharacter_C.IsCanOpenChangeAnim
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x1015dbdd8
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsCanOpenChangeAnim();

	// Object: Function BP_SolarLobbyCharacter.BP_SolarLobbyCharacter_C.IsCanOpenMirror
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x1015dbdd8
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsCanOpenMirror();

	// Object: Function BP_SolarLobbyCharacter.BP_SolarLobbyCharacter_C.ClearCharacterByLua
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x1015dbdd8
	// Return & Params: [ Num(0) Size(0x0) ]
	void ClearCharacterByLua();

	// Object: Function BP_SolarLobbyCharacter.BP_SolarLobbyCharacter_C.InitCharacterByLua
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x1015dbdd8
	// Return & Params: [ Num(0) Size(0x0) ]
	void InitCharacterByLua();

	// Object: Function BP_SolarLobbyCharacter.BP_SolarLobbyCharacter_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();

	// Object: Function BP_SolarLobbyCharacter.BP_SolarLobbyCharacter_C.SetLightingChannelsByTeamPosition
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetLightingChannelsByTeamPosition(int32_t TeamPosition);

	// Object: Function BP_SolarLobbyCharacter.BP_SolarLobbyCharacter_C.ReceiveBeginPlay
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void ReceiveBeginPlay();

	// Object: Function BP_SolarLobbyCharacter.BP_SolarLobbyCharacter_C.ExecuteUbergraph_BP_SolarLobbyCharacter
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_BP_SolarLobbyCharacter(int32_t EntryPoint);
};

