#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_TP_Default_Set01A.BP_TP_Default_Set01A_C
// Inherited Bytes: 0x390 | Struct Size: 0x3a0
struct ABP_TP_Default_Set01A_C : ABP_CapsuleBase_InBattle_C {
	// Fields
	struct UParticleSystemComponent* FX_T_Cabin_PQ01; // Offset: 0x390 | Size: 0x8
	struct UParticleSystemComponent* FX_T_Cabin_PQ02; // Offset: 0x398 | Size: 0x8
};

