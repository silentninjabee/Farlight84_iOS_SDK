#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_WarmGameLogicBase.BP_WarmGameLogicBase_C
// Inherited Bytes: 0x228 | Struct Size: 0x238
struct ABP_WarmGameLogicBase_C : AActor {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x228 | Size: 0x8
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x230 | Size: 0x8

	// Functions

	// Object: Function BP_WarmGameLogicBase.BP_WarmGameLogicBase_C.Event_ExecLogic
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void Event_ExecLogic();

	// Object: Function BP_WarmGameLogicBase.BP_WarmGameLogicBase_C.ExecuteUbergraph_BP_WarmGameLogicBase
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_BP_WarmGameLogicBase(int32_t EntryPoint);
};

