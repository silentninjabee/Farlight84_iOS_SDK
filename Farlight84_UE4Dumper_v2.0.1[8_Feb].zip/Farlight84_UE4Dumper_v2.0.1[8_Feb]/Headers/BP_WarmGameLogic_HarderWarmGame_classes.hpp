#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BP_WarmGameLogic_HarderWarmGame.BP_WarmGameLogic_HarderWarmGame_C
// Inherited Bytes: 0x360 | Struct Size: 0x360
struct ABP_WarmGameLogic_HarderWarmGame_C : ABP_WarmGameLogic_NoramlWarmGame_C {
};

