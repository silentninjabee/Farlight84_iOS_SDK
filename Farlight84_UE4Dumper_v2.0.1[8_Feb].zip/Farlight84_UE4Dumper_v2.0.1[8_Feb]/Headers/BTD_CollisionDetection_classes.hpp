#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BTD_CollisionDetection.BTD_CollisionDetection_C
// Inherited Bytes: 0x98 | Struct Size: 0xf4
struct UBTD_CollisionDetection_C : UBTDecorator_BlueprintBase {
	// Fields
	float Height; // Offset: 0x98 | Size: 0x4
	bool IsActor; // Offset: 0x9c | Size: 0x1
	char pad_0x9D[0x3]; // Offset: 0x9d | Size: 0x3
	struct FBlackboardKeySelector CheckPointLocation; // Offset: 0xa0 | Size: 0x28
	struct FBlackboardKeySelector CheckPointActor; // Offset: 0xc8 | Size: 0x28
	float Radiu; // Offset: 0xf0 | Size: 0x4

	// Functions

	// Object: Function BTD_CollisionDetection.BTD_CollisionDetection_C.GetCircleInter
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(4) Size(0x10) ]
	void GetCircleInter(int32_t Index_01, int32_t Index_02, int32_t circleTimes, int32_t& Inter);

	// Object: Function BTD_CollisionDetection.BTD_CollisionDetection_C.PerformConditionCheckAI
	// Flags: [Event|Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0x11) ]
	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn);
};

