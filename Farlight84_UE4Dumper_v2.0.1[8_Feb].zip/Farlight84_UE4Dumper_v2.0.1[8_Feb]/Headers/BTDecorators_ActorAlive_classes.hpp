#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BTDecorators_ActorAlive.BTDecorators_ActorAlive_C
// Inherited Bytes: 0x98 | Struct Size: 0xc0
struct UBTDecorators_ActorAlive_C : UBTDecorator_BlueprintBase {
	// Fields
	struct FBlackboardKeySelector NewVar_2; // Offset: 0x98 | Size: 0x28

	// Functions

	// Object: Function BTDecorators_ActorAlive.BTDecorators_ActorAlive_C.PerformConditionCheckAI
	// Flags: [Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0x11) ]
	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn);
};

