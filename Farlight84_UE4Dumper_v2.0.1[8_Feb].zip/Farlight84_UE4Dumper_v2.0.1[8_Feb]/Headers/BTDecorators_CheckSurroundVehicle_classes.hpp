#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BTDecorators_CheckSurroundVehicle.BTDecorators_CheckSurroundVehicle_C
// Inherited Bytes: 0x98 | Struct Size: 0xa4
struct UBTDecorators_CheckSurroundVehicle_C : UBTDecorator_BlueprintBase {
	// Fields
	float HasPlayerRange; // Offset: 0x98 | Size: 0x4
	float HasDriverRange; // Offset: 0x9c | Size: 0x4
	int32_t DriverNum; // Offset: 0xa0 | Size: 0x4

	// Functions

	// Object: Function BTDecorators_CheckSurroundVehicle.BTDecorators_CheckSurroundVehicle_C.PerformConditionCheckAI
	// Flags: [Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0x11) ]
	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn);
};

