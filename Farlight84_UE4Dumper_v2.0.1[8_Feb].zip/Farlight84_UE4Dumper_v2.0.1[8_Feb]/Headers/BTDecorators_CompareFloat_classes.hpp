#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BTDecorators_CompareFloat.BTDecorators_CompareFloat_C
// Inherited Bytes: 0x98 | Struct Size: 0xc4
struct UBTDecorators_CompareFloat_C : UBTDecorator_BlueprintBase {
	// Fields
	struct FBlackboardKeySelector CurrentFloat; // Offset: 0x98 | Size: 0x28
	float HighLimitFloat; // Offset: 0xc0 | Size: 0x4

	// Functions

	// Object: Function BTDecorators_CompareFloat.BTDecorators_CompareFloat_C.PerformConditionCheckAI
	// Flags: [Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0x11) ]
	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn);
};

