#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BTDecorators_VehicleSkillReady.BTDecorators_VehicleSkillReady_C
// Inherited Bytes: 0x98 | Struct Size: 0xa0
struct UBTDecorators_VehicleSkillReady_C : UBTDecorator_BlueprintBase {
	// Fields
	int32_t SeatIndex; // Offset: 0x98 | Size: 0x4
	int32_t AbilityIndex; // Offset: 0x9c | Size: 0x4

	// Functions

	// Object: Function BTDecorators_VehicleSkillReady.BTDecorators_VehicleSkillReady_C.PerformConditionCheckAI
	// Flags: [Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0x11) ]
	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn);
};

