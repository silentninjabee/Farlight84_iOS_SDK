#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BTT_GetVectorLocation_behind.BTT_GetVectorLocation_behind_C
// Inherited Bytes: 0xa8 | Struct Size: 0x138
struct UBTT_GetVectorLocation_behind_C : UBTTask_BlueprintBase {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0xa8 | Size: 0x8
	struct FBlackboardKeySelector In; // Offset: 0xb0 | Size: 0x28
	int32_t ; // Offset: 0xd8 | Size: 0x4
	char pad_0xDC[0x4]; // Offset: 0xdc | Size: 0x4
	struct FBlackboardKeySelector Out; // Offset: 0xe0 | Size: 0x28
	float RandomRadius; // Offset: 0x108 | Size: 0x4
	char pad_0x10C[0x4]; // Offset: 0x10c | Size: 0x4
	struct FBlackboardKeySelector IN2; // Offset: 0x110 | Size: 0x28

	// Functions

	// Object: Function BTT_GetVectorLocation_behind.BTT_GetVectorLocation_behind_C.ReceiveExecuteAI
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x10) ]
	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn);

	// Object: Function BTT_GetVectorLocation_behind.BTT_GetVectorLocation_behind_C.ExecuteUbergraph_BTT_GetVectorLocation_behind
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_BTT_GetVectorLocation_behind(int32_t EntryPoint);
};

