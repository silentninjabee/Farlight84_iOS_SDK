#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass BTT_RandomLocationFromEffectArea.BTT_RandomLocationFromEffectArea_C
// Inherited Bytes: 0xa8 | Struct Size: 0x159
struct UBTT_RandomLocationFromEffectArea_C : UBTTask_BlueprintBase {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0xa8 | Size: 0x8
	struct FBlackboardKeySelector In; // Offset: 0xb0 | Size: 0x28
	float ; // Offset: 0xd8 | Size: 0x4
	char pad_0xDC[0x4]; // Offset: 0xdc | Size: 0x4
	struct FBlackboardKeySelector Out; // Offset: 0xe0 | Size: 0x28
	struct FBlackboardKeySelector NewVar_1; // Offset: 0x108 | Size: 0x28
	struct FBlackboardKeySelector Radius; // Offset: 0x130 | Size: 0x28
	bool ; // Offset: 0x158 | Size: 0x1

	// Functions

	// Object: Function BTT_RandomLocationFromEffectArea.BTT_RandomLocationFromEffectArea_C.ReceiveExecuteAI
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x10) ]
	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn);

	// Object: Function BTT_RandomLocationFromEffectArea.BTT_RandomLocationFromEffectArea_C.ExecuteUbergraph_BTT_RandomLocationFromEffectArea
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_BTT_RandomLocationFromEffectArea(int32_t EntryPoint);
};

