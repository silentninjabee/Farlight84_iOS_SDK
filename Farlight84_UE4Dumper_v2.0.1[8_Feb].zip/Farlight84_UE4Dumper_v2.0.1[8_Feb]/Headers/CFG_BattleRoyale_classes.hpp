#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass CFG_BattleRoyale.CFG_BattleRoyale_C
// Inherited Bytes: 0x6a0 | Struct Size: 0x8d0
struct UCFG_BattleRoyale_C : UCFG_Framework_C {
	// Fields
	int32_t ; // Offset: 0x6a0 | Size: 0x4
	int32_t ; // Offset: 0x6a4 | Size: 0x4
	int32_t ; // Offset: 0x6a8 | Size: 0x4
	char pad_0x6AC[0x4]; // Offset: 0x6ac | Size: 0x4
	struct TSoftObjectPtr<UBehaviorTree> ; // Offset: 0x6b0 | Size: 0x28
	struct TSoftObjectPtr<UBehaviorTree> ; // Offset: 0x6d8 | Size: 0x28
	struct TSoftObjectPtr<UBehaviorTree> ; // Offset: 0x700 | Size: 0x28
	int32_t ; // Offset: 0x728 | Size: 0x4
	char pad_0x72C[0x4]; // Offset: 0x72c | Size: 0x4
	struct UDataTable* ; // Offset: 0x730 | Size: 0x8
	int32_t ; // Offset: 0x738 | Size: 0x4
	char pad_0x73C[0x4]; // Offset: 0x73c | Size: 0x4
	struct TSoftClassPtr<UObject> AIController; // Offset: 0x740 | Size: 0x28
	bool ; // Offset: 0x768 | Size: 0x1
	char pad_0x769[0x3]; // Offset: 0x769 | Size: 0x3
	float ; // Offset: 0x76c | Size: 0x4
	float ; // Offset: 0x770 | Size: 0x4
	int32_t ; // Offset: 0x774 | Size: 0x4
	int32_t ; // Offset: 0x778 | Size: 0x4
	int32_t ; // Offset: 0x77c | Size: 0x4
	int32_t ; // Offset: 0x780 | Size: 0x4
	char pad_0x784[0x4]; // Offset: 0x784 | Size: 0x4
	struct UDataTable* ; // Offset: 0x788 | Size: 0x8
	int32_t ; // Offset: 0x790 | Size: 0x4
	struct FInt32Range ; // Offset: 0x794 | Size: 0x10
	struct FInt32Range ; // Offset: 0x7a4 | Size: 0x10
	float ; // Offset: 0x7b4 | Size: 0x4
	struct FS_SkillState ; // Offset: 0x7b8 | Size: 0x4
	struct FS_SkillState ; // Offset: 0x7bc | Size: 0x4
	struct TMap<int32_t, int32_t> ; // Offset: 0x7c0 | Size: 0x50
	struct TMap<int32_t, int32_t> ; // Offset: 0x810 | Size: 0x50
	struct FS_SkillState ; // Offset: 0x860 | Size: 0x4
	struct FS_SkillState ; // Offset: 0x864 | Size: 0x4
	bool ; // Offset: 0x868 | Size: 0x1
	struct FS_SkillState ; // Offset: 0x869 | Size: 0x4
	char pad_0x86D[0x3]; // Offset: 0x86d | Size: 0x3
	int32_t TopVictoryTeamRank; // Offset: 0x870 | Size: 0x4
	int32_t MaxBattleCountDown; // Offset: 0x874 | Size: 0x4
	bool ; // Offset: 0x878 | Size: 0x1
	bool ; // Offset: 0x879 | Size: 0x1
	char pad_0x87A[0x6]; // Offset: 0x87a | Size: 0x6
	struct TMap<int32_t, struct FString> ; // Offset: 0x880 | Size: 0x50

	// Functions

	// Object: Function CFG_BattleRoyale.CFG_BattleRoyale_C.GetSkillStateByNameEnum
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x5) ]
	void GetSkillStateByNameEnum(enum class ESkillStateNameEnum Enum, struct FS_SkillState& Out);
};

