#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass CS_TacticalDodge_B.CS_TacticalDodge_B_C
// Inherited Bytes: 0x160 | Struct Size: 0x160
struct UCS_TacticalDodge_B_C : UCameraShake {
};

