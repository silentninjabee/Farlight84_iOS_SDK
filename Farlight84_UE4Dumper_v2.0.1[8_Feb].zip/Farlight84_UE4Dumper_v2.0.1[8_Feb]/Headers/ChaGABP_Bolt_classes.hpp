#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGABP_Bolt.ChaGABP_Bolt_C
// Inherited Bytes: 0x460 | Struct Size: 0x460
struct UChaGABP_Bolt_C : UChaGA_Bolt {
};

