#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGABP_CancelSprint.ChaGABP_CancelSprint_C
// Inherited Bytes: 0x460 | Struct Size: 0x460
struct UChaGABP_CancelSprint_C : UChaGA_CancelSprint {
};

