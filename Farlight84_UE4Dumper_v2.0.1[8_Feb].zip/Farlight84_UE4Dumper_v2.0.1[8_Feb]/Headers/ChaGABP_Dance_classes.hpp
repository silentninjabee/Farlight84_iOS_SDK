#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGABP_Dance.ChaGABP_Dance_C
// Inherited Bytes: 0x4b8 | Struct Size: 0x4b8
struct UChaGABP_Dance_C : UChaGA_Dance {
};

