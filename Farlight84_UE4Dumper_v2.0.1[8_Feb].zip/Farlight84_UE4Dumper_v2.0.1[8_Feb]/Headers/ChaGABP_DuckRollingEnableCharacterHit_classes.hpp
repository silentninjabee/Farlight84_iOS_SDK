#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGABP_DuckRollingEnableCharacterHit.ChaGABP_DuckRollingEnableCharacterHit_C
// Inherited Bytes: 0x458 | Struct Size: 0x458
struct UChaGABP_DuckRollingEnableCharacterHit_C : USolarCharacterGameplayAbility_Blueprint {
};

