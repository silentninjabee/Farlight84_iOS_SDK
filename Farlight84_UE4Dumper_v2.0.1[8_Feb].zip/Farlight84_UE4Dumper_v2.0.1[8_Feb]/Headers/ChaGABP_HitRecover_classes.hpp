#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGABP_HitRecover.ChaGABP_HitRecover_C
// Inherited Bytes: 0x4b0 | Struct Size: 0x4b0
struct UChaGABP_HitRecover_C : UChaGA_HitRecover {
};

