#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGABP_OpenTreasureBox.ChaGABP_OpenTreasureBox_C
// Inherited Bytes: 0x460 | Struct Size: 0x460
struct UChaGABP_OpenTreasureBox_C : UChaGA_OpenTreasureBox {
};

