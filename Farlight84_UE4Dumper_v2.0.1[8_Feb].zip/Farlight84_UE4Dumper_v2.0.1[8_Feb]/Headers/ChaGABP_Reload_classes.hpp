#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGABP_Reload.ChaGABP_Reload_C
// Inherited Bytes: 0x480 | Struct Size: 0x480
struct UChaGABP_Reload_C : UChaGA_Reload {
};

