#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGABP_SingleCruise.ChaGABP_SingleCruise_C
// Inherited Bytes: 0x478 | Struct Size: 0x478
struct UChaGABP_SingleCruise_C : UChaGA_SingleCruise {
};

