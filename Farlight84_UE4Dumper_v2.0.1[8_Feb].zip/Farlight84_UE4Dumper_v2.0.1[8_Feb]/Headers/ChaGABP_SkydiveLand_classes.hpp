#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGABP_SkydiveLand.ChaGABP_SkydiveLand_C
// Inherited Bytes: 0x458 | Struct Size: 0x458
struct UChaGABP_SkydiveLand_C : UChaGA_SkydiveLand {
};

