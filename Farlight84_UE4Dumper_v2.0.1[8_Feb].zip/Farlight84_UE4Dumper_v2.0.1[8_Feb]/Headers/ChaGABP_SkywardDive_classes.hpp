#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGABP_SkywardDive.ChaGABP_SkywardDive_C
// Inherited Bytes: 0x470 | Struct Size: 0x470
struct UChaGABP_SkywardDive_C : UChaGA_SkywardDive {
};

