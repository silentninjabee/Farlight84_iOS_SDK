#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGABP_Swim.ChaGABP_Swim_C
// Inherited Bytes: 0x458 | Struct Size: 0x458
struct UChaGABP_Swim_C : UChaGA_Swim {
};

