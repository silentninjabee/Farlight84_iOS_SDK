#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGABP_UpgradeShield.ChaGABP_UpgradeShield_C
// Inherited Bytes: 0x480 | Struct Size: 0x480
struct UChaGABP_UpgradeShield_C : UChaGA_UpgradeShield {
};

