#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGCBP_BlindMark_Blind.ChaGCBP_BlindMark_Blind_C
// Inherited Bytes: 0x370 | Struct Size: 0x379
struct AChaGCBP_BlindMark_Blind_C : AChaGC_CharacterActorCueBase {
	// Fields
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x370 | Size: 0x8
	bool HasSetLowPassFilter; // Offset: 0x378 | Size: 0x1

	// Functions

	// Object: Function ChaGCBP_BlindMark_Blind.ChaGCBP_BlindMark_Blind_C.OnRemoveInternal
	// Flags: [Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0xc9) ]
	bool OnRemoveInternal(struct ASolarCharacter* NullableCharacter, struct FGameplayCueParameters& Parameters);

	// Object: Function ChaGCBP_BlindMark_Blind.ChaGCBP_BlindMark_Blind_C.WhileActiveInternal
	// Flags: [Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0xc9) ]
	bool WhileActiveInternal(struct ASolarCharacter* Character, struct FGameplayCueParameters& Parameters);
};

