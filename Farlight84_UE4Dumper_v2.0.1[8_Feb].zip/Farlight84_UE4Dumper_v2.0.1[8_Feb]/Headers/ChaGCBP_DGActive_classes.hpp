#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGCBP_DGActive.ChaGCBP_DGActive_C
// Inherited Bytes: 0x530 | Struct Size: 0x538
struct AChaGCBP_DGActive_C : AChaGC_DoppelgangerActive {
	// Fields
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x530 | Size: 0x8
};

