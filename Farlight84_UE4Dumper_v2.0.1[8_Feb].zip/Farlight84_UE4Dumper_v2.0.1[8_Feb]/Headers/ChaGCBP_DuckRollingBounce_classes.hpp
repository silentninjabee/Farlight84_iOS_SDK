#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGCBP_DuckRollingBounce.ChaGCBP_DuckRollingBounce_C
// Inherited Bytes: 0x370 | Struct Size: 0x380
struct AChaGCBP_DuckRollingBounce_C : AChaGC_CharacterActorCueBase {
	// Fields
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x370 | Size: 0x8
	struct UParticleSystem* ParticleAsset; // Offset: 0x378 | Size: 0x8

	// Functions

	// Object: Function ChaGCBP_DuckRollingBounce.ChaGCBP_DuckRollingBounce_C.OnExecuteInternal
	// Flags: [Event|Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0xc9) ]
	bool OnExecuteInternal(struct ASolarCharacter* Character, struct FGameplayCueParameters& Parameters);
};

