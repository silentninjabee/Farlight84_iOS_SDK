#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGCBP_JetSlowFalling.ChaGCBP_JetSlowFalling_C
// Inherited Bytes: 0x50 | Struct Size: 0x50
struct UChaGCBP_JetSlowFalling_C : UChaGC_JetSlowFalling {
};

