#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGCBP_LeadChargeBand.ChaGCBP_LeadChargeBand_C
// Inherited Bytes: 0x370 | Struct Size: 0x380
struct AChaGCBP_LeadChargeBand_C : AChaGC_CharacterActorCueBase {
	// Fields
	struct UParticleSystemComponent* ParticleSystem; // Offset: 0x370 | Size: 0x8
	struct USceneComponent* Scene; // Offset: 0x378 | Size: 0x8

	// Functions

	// Object: Function ChaGCBP_LeadChargeBand.ChaGCBP_LeadChargeBand_C.OnRemoveInternal
	// Flags: [Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0xc9) ]
	bool OnRemoveInternal(struct ASolarCharacter* NullableCharacter, struct FGameplayCueParameters& Parameters);

	// Object: Function ChaGCBP_LeadChargeBand.ChaGCBP_LeadChargeBand_C.WhileActiveInternal
	// Flags: [Event|Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0xc9) ]
	bool WhileActiveInternal(struct ASolarCharacter* Character, struct FGameplayCueParameters& Parameters);
};

