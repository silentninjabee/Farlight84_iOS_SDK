#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGCBP_RescueSuccceed.ChaGCBP_RescueSuccceed_C
// Inherited Bytes: 0x298 | Struct Size: 0x2a0
struct AChaGCBP_RescueSuccceed_C : AGameplayCueNotify_Actor {
	// Fields
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x298 | Size: 0x8

	// Functions

	// Object: Function ChaGCBP_RescueSuccceed.ChaGCBP_RescueSuccceed_C.OnRemove
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0xc9) ]
	bool OnRemove(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters);

	// Object: Function ChaGCBP_RescueSuccceed.ChaGCBP_RescueSuccceed_C.OnActive
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0xc9) ]
	bool OnActive(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters);
};

