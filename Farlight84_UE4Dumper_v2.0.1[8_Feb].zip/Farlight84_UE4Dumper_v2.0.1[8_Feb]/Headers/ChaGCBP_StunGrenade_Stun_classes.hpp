#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGCBP_StunGrenade_Stun.ChaGCBP_StunGrenade_Stun_C
// Inherited Bytes: 0x460 | Struct Size: 0x468
struct AChaGCBP_StunGrenade_Stun_C : AChaGC_Stun {
	// Fields
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x460 | Size: 0x8
};

