#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGCBP_WallRunPropelling.ChaGCBP_WallRunPropelling_C
// Inherited Bytes: 0x50 | Struct Size: 0x50
struct UChaGCBP_WallRunPropelling_C : UChaGC_BackpackPropelling {
};

