#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGEBP_DanceFollower.ChaGEBP_DanceFollower_C
// Inherited Bytes: 0x848 | Struct Size: 0x848
struct UChaGEBP_DanceFollower_C : UGameplayEffect {
};

