#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGEBP_HoldingSkill_Super.ChaGEBP_HoldingSkill_Super_C
// Inherited Bytes: 0x848 | Struct Size: 0x848
struct UChaGEBP_HoldingSkill_Super_C : UGameplayEffect {
};

