#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGEBP_RemoveDebuffOnDeath.ChaGEBP_RemoveDebuffOnDeath_C
// Inherited Bytes: 0x848 | Struct Size: 0x848
struct UChaGEBP_RemoveDebuffOnDeath_C : UGameplayEffect {
};

