#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGEBP_SlowDown.ChaGEBP_SlowDown_C
// Inherited Bytes: 0x848 | Struct Size: 0x848
struct UChaGEBP_SlowDown_C : UGameplayEffect {
};

