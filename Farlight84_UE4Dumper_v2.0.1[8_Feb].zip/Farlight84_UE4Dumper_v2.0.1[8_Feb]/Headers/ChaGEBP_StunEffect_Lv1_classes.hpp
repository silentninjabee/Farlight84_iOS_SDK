#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass ChaGEBP_StunEffect_Lv1.ChaGEBP_StunEffect_Lv1_C
// Inherited Bytes: 0x848 | Struct Size: 0x848
struct UChaGEBP_StunEffect_Lv1_C : UGameplayEffect {
};

