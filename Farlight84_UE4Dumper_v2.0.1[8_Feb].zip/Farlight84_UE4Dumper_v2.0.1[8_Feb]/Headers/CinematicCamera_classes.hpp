#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class CinematicCamera.CineCameraActor
// Inherited Bytes: 0x820 | Struct Size: 0x880
struct ACineCameraActor : ACameraActor {
	// Fields
	struct FCameraLookatTrackingSettings LookatTrackingSettings; // Offset: 0x820 | Size: 0x50
	char pad_0x870[0x10]; // Offset: 0x870 | Size: 0x10

	// Functions

	// Object: Function CinematicCamera.CineCameraActor.GetCineCameraComponent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ceb5b4
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UCineCameraComponent* GetCineCameraComponent();
};

// Object: Class CinematicCamera.CameraRig_Crane
// Inherited Bytes: 0x228 | Struct Size: 0x258
struct ACameraRig_Crane : AActor {
	// Fields
	float CranePitch; // Offset: 0x228 | Size: 0x4
	float CraneYaw; // Offset: 0x22c | Size: 0x4
	float CraneArmLength; // Offset: 0x230 | Size: 0x4
	bool bLockMountPitch; // Offset: 0x234 | Size: 0x1
	bool bLockMountYaw; // Offset: 0x235 | Size: 0x1
	char pad_0x236[0x2]; // Offset: 0x236 | Size: 0x2
	struct USceneComponent* TransformComponent; // Offset: 0x238 | Size: 0x8
	struct USceneComponent* CraneYawControl; // Offset: 0x240 | Size: 0x8
	struct USceneComponent* CranePitchControl; // Offset: 0x248 | Size: 0x8
	struct USceneComponent* CraneCameraMount; // Offset: 0x250 | Size: 0x8
};

// Object: Class CinematicCamera.CameraRig_Rail
// Inherited Bytes: 0x228 | Struct Size: 0x248
struct ACameraRig_Rail : AActor {
	// Fields
	float CurrentPositionOnRail; // Offset: 0x228 | Size: 0x4
	bool bLockOrientationToRail; // Offset: 0x22c | Size: 0x1
	char pad_0x22D[0x3]; // Offset: 0x22d | Size: 0x3
	struct USceneComponent* TransformComponent; // Offset: 0x230 | Size: 0x8
	struct USplineComponent* RailSplineComponent; // Offset: 0x238 | Size: 0x8
	struct USceneComponent* RailCameraMount; // Offset: 0x240 | Size: 0x8

	// Functions

	// Object: Function CinematicCamera.CameraRig_Rail.GetRailSplineComponent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x104ceb23c
	// Return & Params: [ Num(1) Size(0x8) ]
	struct USplineComponent* GetRailSplineComponent();
};

// Object: Class CinematicCamera.CineCameraComponent
// Inherited Bytes: 0x980 | Struct Size: 0xa80
struct UCineCameraComponent : UCameraComponent {
	// Fields
	struct FCameraFilmbackSettings FilmbackSettings; // Offset: 0x980 | Size: 0xc
	struct FCameraFilmbackSettings Filmback; // Offset: 0x98c | Size: 0xc
	struct FCameraLensSettings LensSettings; // Offset: 0x998 | Size: 0x18
	struct FCameraFocusSettings FocusSettings; // Offset: 0x9b0 | Size: 0x58
	float CurrentFocalLength; // Offset: 0xa08 | Size: 0x4
	float CurrentAperture; // Offset: 0xa0c | Size: 0x4
	float CurrentFocusDistance; // Offset: 0xa10 | Size: 0x4
	char pad_0xA14[0xc]; // Offset: 0xa14 | Size: 0xc
	struct TArray<struct FNamedFilmbackPreset> FilmbackPresets; // Offset: 0xa20 | Size: 0x10
	struct TArray<struct FNamedLensPreset> LensPresets; // Offset: 0xa30 | Size: 0x10
	struct FString DefaultFilmbackPresetName; // Offset: 0xa40 | Size: 0x10
	struct FString DefaultFilmbackPreset; // Offset: 0xa50 | Size: 0x10
	struct FString DefaultLensPresetName; // Offset: 0xa60 | Size: 0x10
	float DefaultLensFocalLength; // Offset: 0xa70 | Size: 0x4
	float DefaultLensFStop; // Offset: 0xa74 | Size: 0x4
	char pad_0xA78[0x8]; // Offset: 0xa78 | Size: 0x8

	// Functions

	// Object: Function CinematicCamera.CineCameraComponent.SetLensPresetByName
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cec12c
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetLensPresetByName(struct FString InPresetName);

	// Object: Function CinematicCamera.CineCameraComponent.SetFilmbackPresetByName
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cec238
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetFilmbackPresetByName(struct FString InPresetName);

	// Object: Function CinematicCamera.CineCameraComponent.SetCurrentFocalLength
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104cec474
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetCurrentFocalLength(float& InFocalLength);

	// Object: Function CinematicCamera.CineCameraComponent.GetVerticalFieldOfView
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cec40c
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetVerticalFieldOfView();

	// Object: Function CinematicCamera.CineCameraComponent.GetLensPresetsCopy
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104cec038
	// Return & Params: [ Num(1) Size(0x10) ]
	struct TArray<struct FNamedLensPreset> GetLensPresetsCopy();

	// Object: Function CinematicCamera.CineCameraComponent.GetLensPresetName
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cec1b8
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetLensPresetName();

	// Object: Function CinematicCamera.CineCameraComponent.GetHorizontalFieldOfView
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cec440
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetHorizontalFieldOfView();

	// Object: Function CinematicCamera.CineCameraComponent.GetFilmbackPresetName
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cec38c
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetFilmbackPresetName();

	// Object: Function CinematicCamera.CineCameraComponent.GetDefaultFilmbackPresetName
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cec2c4
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetDefaultFilmbackPresetName();
};

