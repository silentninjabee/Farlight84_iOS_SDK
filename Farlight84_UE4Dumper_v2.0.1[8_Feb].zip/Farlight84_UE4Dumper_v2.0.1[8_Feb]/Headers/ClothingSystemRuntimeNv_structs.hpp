#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct ClothingSystemRuntimeNv.ClothConstraintSetupNv
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FClothConstraintSetupNv {
	// Fields
	float Stiffness; // Offset: 0x0 | Size: 0x4
	float StiffnessMultiplier; // Offset: 0x4 | Size: 0x4
	float StretchLimit; // Offset: 0x8 | Size: 0x4
	float CompressionLimit; // Offset: 0xc | Size: 0x4
};

