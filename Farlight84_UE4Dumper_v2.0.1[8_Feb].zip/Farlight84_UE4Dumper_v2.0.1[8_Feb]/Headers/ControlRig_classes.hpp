#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class ControlRig.ControlRig
// Inherited Bytes: 0x28 | Struct Size: 0x360
struct UControlRig : UObject {
	// Fields
	char pad_0x28[0x48]; // Offset: 0x28 | Size: 0x48
	enum class ERigExecutionType ExecutionType; // Offset: 0x70 | Size: 0x1
	char pad_0x71[0x7]; // Offset: 0x71 | Size: 0x7
	struct URigVM* VM; // Offset: 0x78 | Size: 0x8
	struct FRigHierarchyContainer Hierarchy; // Offset: 0x80 | Size: 0x1b0
	struct TSoftObjectPtr<UControlRigGizmoLibrary> GizmoLibrary; // Offset: 0x230 | Size: 0x28
	char pad_0x258[0x10]; // Offset: 0x258 | Size: 0x10
	struct TMap<struct FName, struct FCachedPropertyPath> InputProperties; // Offset: 0x268 | Size: 0x50
	struct TMap<struct FName, struct FCachedPropertyPath> OutputProperties; // Offset: 0x2b8 | Size: 0x50
	struct FControlRigDrawContainer DrawContainer; // Offset: 0x308 | Size: 0x10
	char pad_0x318[0x8]; // Offset: 0x318 | Size: 0x8
	struct UAnimationDataSourceRegistry* DataSourceRegistry; // Offset: 0x320 | Size: 0x8
	char pad_0x328[0x38]; // Offset: 0x328 | Size: 0x38
};

// Object: Class ControlRig.AdditiveControlRig
// Inherited Bytes: 0x360 | Struct Size: 0x370
struct UAdditiveControlRig : UControlRig {
	// Fields
	char pad_0x360[0x10]; // Offset: 0x360 | Size: 0x10
};

// Object: Class ControlRig.ControlRigBindingTrack
// Inherited Bytes: 0x78 | Struct Size: 0x78
struct UControlRigBindingTrack : UMovieSceneSpawnTrack {
};

// Object: Class ControlRig.ControlRigBlueprintGeneratedClass
// Inherited Bytes: 0x418 | Struct Size: 0x418
struct UControlRigBlueprintGeneratedClass : UBlueprintGeneratedClass {
};

// Object: Class ControlRig.ControlRigComponent
// Inherited Bytes: 0xb0 | Struct Size: 0xf8
struct UControlRigComponent : UActorComponent {
	// Fields
	struct FMulticastInlineDelegate OnPreInitializeDelegate; // Offset: 0xb0 | Size: 0x10
	struct FMulticastInlineDelegate OnPostInitializeDelegate; // Offset: 0xc0 | Size: 0x10
	struct FMulticastInlineDelegate OnPreEvaluateDelegate; // Offset: 0xd0 | Size: 0x10
	struct FMulticastInlineDelegate OnPostEvaluateDelegate; // Offset: 0xe0 | Size: 0x10
	struct UControlRig* ControlRig; // Offset: 0xf0 | Size: 0x8

	// Functions

	// Object: Function ControlRig.ControlRigComponent.OnPreInitialize
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x1017ab55c
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnPreInitialize();

	// Object: Function ControlRig.ControlRigComponent.OnPreEvaluate
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x1017ab524
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnPreEvaluate();

	// Object: Function ControlRig.ControlRigComponent.OnPostInitialize
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x1017ab540
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnPostInitialize();

	// Object: Function ControlRig.ControlRigComponent.OnPostEvaluate
	// Flags: [Native|Event|Public|BlueprintEvent]
	// Offset: 0x1017ab508
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnPostEvaluate();

	// Object: Function ControlRig.ControlRigComponent.BP_GetControlRig
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1017ab578
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UControlRig* BP_GetControlRig();
};

// Object: Class ControlRig.ControlRigGizmoLibrary
// Inherited Bytes: 0x28 | Struct Size: 0xe0
struct UControlRigGizmoLibrary : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
	struct FControlRigGizmoDefinition DefaultGizmo; // Offset: 0x30 | Size: 0x60
	struct TSoftObjectPtr<UMaterial> DefaultMaterial; // Offset: 0x90 | Size: 0x28
	struct FName MaterialColorParameter; // Offset: 0xb8 | Size: 0x8
	struct TArray<struct FControlRigGizmoDefinition> Gizmos; // Offset: 0xc0 | Size: 0x10
	char pad_0xD0[0x10]; // Offset: 0xd0 | Size: 0x10
};

// Object: Class ControlRig.ControlRigLayerInstance
// Inherited Bytes: 0x2a0 | Struct Size: 0x2a0
struct UControlRigLayerInstance : UAnimInstance {
};

// Object: Class ControlRig.ControlRigObjectHolder
// Inherited Bytes: 0x28 | Struct Size: 0x38
struct UControlRigObjectHolder : UObject {
	// Fields
	struct TArray<struct UObject*> Objects; // Offset: 0x28 | Size: 0x10
};

// Object: Class ControlRig.ControlRigSequence
// Inherited Bytes: 0x498 | Struct Size: 0x4f0
struct UControlRigSequence : ULevelSequence {
	// Fields
	struct TSoftObjectPtr<UAnimSequence> LastExportedToAnimationSequence; // Offset: 0x498 | Size: 0x28
	struct TSoftObjectPtr<USkeletalMesh> LastExportedUsingSkeletalMesh; // Offset: 0x4c0 | Size: 0x28
	float LastExportedFrameRate; // Offset: 0x4e8 | Size: 0x4
	char pad_0x4EC[0x4]; // Offset: 0x4ec | Size: 0x4
};

// Object: Class ControlRig.ControlRigSequencerAnimInstance
// Inherited Bytes: 0x2a0 | Struct Size: 0x2b0
struct UControlRigSequencerAnimInstance : UAnimSequencerInstance {
	// Fields
	char pad_0x2A0[0x10]; // Offset: 0x2a0 | Size: 0x10
};

// Object: Class ControlRig.ControlRigSettings
// Inherited Bytes: 0x38 | Struct Size: 0x38
struct UControlRigSettings : UDeveloperSettings {
};

// Object: Class ControlRig.ControlRigManipulatable
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UControlRigManipulatable : UInterface {
};

// Object: Class ControlRig.MovieSceneControlRigParameterSection
// Inherited Bytes: 0x138 | Struct Size: 0x270
struct UMovieSceneControlRigParameterSection : UMovieSceneParameterSection {
	// Fields
	struct UControlRig* ControlRig; // Offset: 0x138 | Size: 0x8
	struct TArray<bool> ControlsMask; // Offset: 0x140 | Size: 0x10
	struct FMovieSceneTransformMask TransformMask; // Offset: 0x150 | Size: 0x4
	bool bAdditive; // Offset: 0x154 | Size: 0x1
	bool bApplyBoneFilter; // Offset: 0x155 | Size: 0x1
	char pad_0x156[0x2]; // Offset: 0x156 | Size: 0x2
	struct FInputBlendPose BoneFilter; // Offset: 0x158 | Size: 0x10
	struct FMovieSceneFloatChannel Weight; // Offset: 0x168 | Size: 0xa0
	struct TMap<struct FName, struct FChannelMapInfo> ControlChannelMap; // Offset: 0x208 | Size: 0x50
	char pad_0x258[0x18]; // Offset: 0x258 | Size: 0x18
};

// Object: Class ControlRig.MovieSceneControlRigParameterTrack
// Inherited Bytes: 0x58 | Struct Size: 0x80
struct UMovieSceneControlRigParameterTrack : UMovieSceneNameableTrack {
	// Fields
	struct UControlRig* ControlRig; // Offset: 0x58 | Size: 0x8
	struct UMovieSceneSection* SectionToKey; // Offset: 0x60 | Size: 0x8
	struct TArray<struct UMovieSceneSection*> Sections; // Offset: 0x68 | Size: 0x10
	struct FName TrackName; // Offset: 0x78 | Size: 0x8
};

// Object: Class ControlRig.MovieSceneControlRigSection
// Inherited Bytes: 0x150 | Struct Size: 0x208
struct UMovieSceneControlRigSection : UMovieSceneSubSection {
	// Fields
	bool bAdditive; // Offset: 0x150 | Size: 0x1
	bool bApplyBoneFilter; // Offset: 0x151 | Size: 0x1
	char pad_0x152[0x6]; // Offset: 0x152 | Size: 0x6
	struct FInputBlendPose BoneFilter; // Offset: 0x158 | Size: 0x10
	struct FMovieSceneFloatChannel Weight; // Offset: 0x168 | Size: 0xa0
};

// Object: Class ControlRig.MovieSceneControlRigTrack
// Inherited Bytes: 0x68 | Struct Size: 0x68
struct UMovieSceneControlRigTrack : UMovieSceneSubTrack {
};

