#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass Crosshair_CarWeapon_AssaultRifle.Crosshair_CarWeapon_AssaultRifle_C
// Inherited Bytes: 0x6e8 | Struct Size: 0x730
struct UCrosshair_CarWeapon_AssaultRifle_C : UVehicleWeaponCrossHairWidget {
	// Fields
	struct UCanvasPanel* Container_SecondReticle; // Offset: 0x6e8 | Size: 0x8
	struct UCanvasPanel* Coredot; // Offset: 0x6f0 | Size: 0x8
	struct UHUD_Overload_C* HUD_Overload; // Offset: 0x6f8 | Size: 0x8
	struct UImage* ReticleDirection; // Offset: 0x700 | Size: 0x8
	struct UImage* SpreadImg_coredot; // Offset: 0x708 | Size: 0x8
	struct UImage* SpreadImg_coredot_2; // Offset: 0x710 | Size: 0x8
	struct UImage* SpreadImg_Leftarrow_2; // Offset: 0x718 | Size: 0x8
	struct UImage* SpreadImg_Rightarrow_2; // Offset: 0x720 | Size: 0x8
	struct UImage* SpreadImg_uparrow_2; // Offset: 0x728 | Size: 0x8

	// Functions

	// Object: Function Crosshair_CarWeapon_AssaultRifle.Crosshair_CarWeapon_AssaultRifle_C.GetAmmoWidget
	// Flags: [Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UUserWidget* GetAmmoWidget();

	// Object: Function Crosshair_CarWeapon_AssaultRifle.Crosshair_CarWeapon_AssaultRifle_C.GetReloadWidget
	// Flags: [Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UUserWidget* GetReloadWidget();

	// Object: Function Crosshair_CarWeapon_AssaultRifle.Crosshair_CarWeapon_AssaultRifle_C.SetWidgetResources
	// Flags: [Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(7) Size(0x38) ]
	void SetWidgetResources(struct UCanvasPanel*& InSecondReticlePanel, struct UImage*& InReticleDirectionImage, struct UImage*& InRangedImage, struct USizeBox*& InAssistLockSizeBox, struct UCanvasPanel*& InChangeNewAssistLockPawnPanel, struct UCanvasPanel*& InEnterLockPawnPanel, struct UCanvasPanel*& InCanvas_Dynamic);
};

