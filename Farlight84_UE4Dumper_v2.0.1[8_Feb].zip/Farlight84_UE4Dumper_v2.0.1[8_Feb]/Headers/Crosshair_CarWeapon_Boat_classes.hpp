#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass Crosshair_CarWeapon_Boat.Crosshair_CarWeapon_Boat_C
// Inherited Bytes: 0x6e8 | Struct Size: 0x780
struct UCrosshair_CarWeapon_Boat_C : UVehicleWeaponCrossHairWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x6e8 | Size: 0x8
	struct UWidgetAnimation* Anim_Charging; // Offset: 0x6f0 | Size: 0x8
	struct UWidgetAnimation* Anim_Cooldown; // Offset: 0x6f8 | Size: 0x8
	struct UImage* Bullet_2; // Offset: 0x700 | Size: 0x8
	struct UImage* Bullet_3; // Offset: 0x708 | Size: 0x8
	struct UImage* Bullet_4; // Offset: 0x710 | Size: 0x8
	struct UImage* Bullet_5; // Offset: 0x718 | Size: 0x8
	struct UImage* Bullet_6; // Offset: 0x720 | Size: 0x8
	struct UImage* Bullet_7; // Offset: 0x728 | Size: 0x8
	struct UImage* Bullet_8; // Offset: 0x730 | Size: 0x8
	struct UImage* Bullet_9; // Offset: 0x738 | Size: 0x8
	struct UCanvasPanel* Container_SecondReticle; // Offset: 0x740 | Size: 0x8
	struct UCanvasPanel* Coredot; // Offset: 0x748 | Size: 0x8
	struct UImage* ReticleDirection; // Offset: 0x750 | Size: 0x8
	struct UImage* SpreadImg_coredot; // Offset: 0x758 | Size: 0x8
	int32_t PreBurstCount; // Offset: 0x760 | Size: 0x4
	char pad_0x764[0x4]; // Offset: 0x764 | Size: 0x4
	struct TArray<struct UImage*> BulletImages; // Offset: 0x768 | Size: 0x10
	bool IsCoolDown; // Offset: 0x778 | Size: 0x1
	bool IsPreCharging; // Offset: 0x779 | Size: 0x1
	char pad_0x77A[0x2]; // Offset: 0x77a | Size: 0x2
	float AnimationReversTime; // Offset: 0x77c | Size: 0x4

	// Functions

	// Object: Function Crosshair_CarWeapon_Boat.Crosshair_CarWeapon_Boat_C.SetWidgetResources
	// Flags: [Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(7) Size(0x38) ]
	void SetWidgetResources(struct UCanvasPanel*& InSecondReticlePanel, struct UImage*& InReticleDirectionImage, struct UImage*& InRangedImage, struct USizeBox*& InAssistLockSizeBox, struct UCanvasPanel*& InChangeNewAssistLockPawnPanel, struct UCanvasPanel*& InEnterLockPawnPanel, struct UCanvasPanel*& InCanvas_Dynamic);

	// Object: Function Crosshair_CarWeapon_Boat.Crosshair_CarWeapon_Boat_C.OnUpdateChargeProgress
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(4) Size(0x10) ]
	void OnUpdateChargeProgress(bool InbCharging, int32_t InChargeMode, float InChargeProgress, int32_t InChargeBurstCount);

	// Object: Function Crosshair_CarWeapon_Boat.Crosshair_CarWeapon_Boat_C.OnInitialized
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnInitialized();

	// Object: Function Crosshair_CarWeapon_Boat.Crosshair_CarWeapon_Boat_C.OnUpdateCoolDownProgress
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void OnUpdateCoolDownProgress(float InCoolDownProgress);

	// Object: Function Crosshair_CarWeapon_Boat.Crosshair_CarWeapon_Boat_C.ExecuteUbergraph_Crosshair_CarWeapon_Boat
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_Crosshair_CarWeapon_Boat(int32_t EntryPoint);
};

