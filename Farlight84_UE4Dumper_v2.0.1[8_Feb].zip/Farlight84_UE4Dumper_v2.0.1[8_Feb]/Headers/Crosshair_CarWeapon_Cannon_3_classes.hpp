#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass Crosshair_CarWeapon_Cannon_3.Crosshair_CarWeapon_Cannon_2_C
// Inherited Bytes: 0x6e8 | Struct Size: 0x710
struct UCrosshair_CarWeapon_Cannon_2_C : UVehicleWeaponCrossHairWidget {
	// Fields
	struct UWidgetAnimation* Anim_CD_Out; // Offset: 0x6e8 | Size: 0x8
	struct UWidgetAnimation* Anim_CD_Enter; // Offset: 0x6f0 | Size: 0x8
	struct UCanvasPanel* Canvas_Dynamic; // Offset: 0x6f8 | Size: 0x8
	struct UImage* ReticleDirection; // Offset: 0x700 | Size: 0x8
	struct UImage* SpreadImg_coredot; // Offset: 0x708 | Size: 0x8

	// Functions

	// Object: Function Crosshair_CarWeapon_Cannon_3.Crosshair_CarWeapon_Cannon_2_C.SetWidgetResources
	// Flags: [Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(7) Size(0x38) ]
	void SetWidgetResources(struct UCanvasPanel*& InSecondReticlePanel, struct UImage*& InReticleDirectionImage, struct UImage*& InRangedImage, struct USizeBox*& InAssistLockSizeBox, struct UCanvasPanel*& InChangeNewAssistLockPawnPanel, struct UCanvasPanel*& InEnterLockPawnPanel, struct UCanvasPanel*& InCanvas_Dynamic);
};

