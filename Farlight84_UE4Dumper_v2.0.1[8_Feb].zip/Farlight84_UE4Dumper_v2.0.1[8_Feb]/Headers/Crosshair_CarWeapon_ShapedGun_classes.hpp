#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass Crosshair_CarWeapon_ShapedGun.Crosshair_CarWeapon_ShapedGun_C
// Inherited Bytes: 0x6e8 | Struct Size: 0x790
struct UCrosshair_CarWeapon_ShapedGun_C : UVehicleWeaponCrossHairWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x6e8 | Size: 0x8
	struct UWidgetAnimation* Anim_Charging; // Offset: 0x6f0 | Size: 0x8
	struct UProgressBar* ChargeBar_1_2; // Offset: 0x6f8 | Size: 0x8
	struct UProgressBar* ChargeBar_1_3; // Offset: 0x700 | Size: 0x8
	struct UProgressBar* ChargeBar_1_4; // Offset: 0x708 | Size: 0x8
	struct UProgressBar* ChargeBar_1_5; // Offset: 0x710 | Size: 0x8
	struct UProgressBar* ChargeBar_2_2; // Offset: 0x718 | Size: 0x8
	struct UProgressBar* ChargeBar_2_3; // Offset: 0x720 | Size: 0x8
	struct UProgressBar* ChargeBar_2_4; // Offset: 0x728 | Size: 0x8
	struct UProgressBar* ChargeBar_2_5; // Offset: 0x730 | Size: 0x8
	struct UCanvasPanel* Charging_2; // Offset: 0x738 | Size: 0x8
	struct UCanvasPanel* Charging_3; // Offset: 0x740 | Size: 0x8
	struct UCanvasPanel* Container_SecondReticle; // Offset: 0x748 | Size: 0x8
	struct UCanvasPanel* Coredot; // Offset: 0x750 | Size: 0x8
	struct UImage* ReloadImg; // Offset: 0x758 | Size: 0x8
	struct UImageTween_C* ReloadImg_Tween; // Offset: 0x760 | Size: 0x8
	struct UImage* ReticleDirection; // Offset: 0x768 | Size: 0x8
	struct UImage* SpreadImg_coredot; // Offset: 0x770 | Size: 0x8
	struct UCanvasPanel* SpreadImg_coredot_2; // Offset: 0x778 | Size: 0x8
	struct UCanvasPanel* SpreadImg_coredot_3; // Offset: 0x780 | Size: 0x8
	int32_t LastChargeMode; // Offset: 0x788 | Size: 0x4
	float AnimationReversTime; // Offset: 0x78c | Size: 0x4

	// Functions

	// Object: Function Crosshair_CarWeapon_ShapedGun.Crosshair_CarWeapon_ShapedGun_C.SetPrograssPrecent
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0x10) ]
	void SetPrograssPrecent(float Percent, int32_t Index, struct UProgressBar* InProgressBar);

	// Object: Function Crosshair_CarWeapon_ShapedGun.Crosshair_CarWeapon_ShapedGun_C.GetChargeWidget
	// Flags: [Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UUserWidget* GetChargeWidget();

	// Object: Function Crosshair_CarWeapon_ShapedGun.Crosshair_CarWeapon_ShapedGun_C.SetWidgetResources
	// Flags: [Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(7) Size(0x38) ]
	void SetWidgetResources(struct UCanvasPanel*& InSecondReticlePanel, struct UImage*& InReticleDirectionImage, struct UImage*& InRangedImage, struct USizeBox*& InAssistLockSizeBox, struct UCanvasPanel*& InChangeNewAssistLockPawnPanel, struct UCanvasPanel*& InEnterLockPawnPanel, struct UCanvasPanel*& InCanvas_Dynamic);

	// Object: Function Crosshair_CarWeapon_ShapedGun.Crosshair_CarWeapon_ShapedGun_C.OnUpdateChargeProgress
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(4) Size(0x10) ]
	void OnUpdateChargeProgress(bool InbCharging, int32_t InChargeMode, float InChargeProgress, int32_t InChargeBurstCount);

	// Object: Function Crosshair_CarWeapon_ShapedGun.Crosshair_CarWeapon_ShapedGun_C.ExecuteUbergraph_Crosshair_CarWeapon_ShapedGun
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_Crosshair_CarWeapon_ShapedGun(int32_t EntryPoint);
};

