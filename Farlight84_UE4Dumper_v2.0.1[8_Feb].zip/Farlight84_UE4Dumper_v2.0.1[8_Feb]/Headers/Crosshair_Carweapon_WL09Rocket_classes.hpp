#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass Crosshair_Carweapon_WL09Rocket.Crosshair_Carweapon_WL09Rocket_C
// Inherited Bytes: 0x6e8 | Struct Size: 0x7a8
struct UCrosshair_Carweapon_WL09Rocket_C : UVehicleWeaponCrossHairWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x6e8 | Size: 0x8
	struct UCanvasPanel* Coredot; // Offset: 0x6f0 | Size: 0x8
	struct UImage* img_Bullet_2; // Offset: 0x6f8 | Size: 0x8
	struct UImage* img_Bullet_3; // Offset: 0x700 | Size: 0x8
	struct UImage* img_Bullet_4; // Offset: 0x708 | Size: 0x8
	struct UImage* img_Bullet_5; // Offset: 0x710 | Size: 0x8
	struct UImage* img_Bullet_6; // Offset: 0x718 | Size: 0x8
	struct UImage* img_Bullet_7; // Offset: 0x720 | Size: 0x8
	struct UImage* img_Bullet_8; // Offset: 0x728 | Size: 0x8
	struct UImage* img_Bullet_9; // Offset: 0x730 | Size: 0x8
	struct UImage* img_Bullet_10; // Offset: 0x738 | Size: 0x8
	struct UImage* img_Bullet_11; // Offset: 0x740 | Size: 0x8
	struct UImage* img_Bullet_12; // Offset: 0x748 | Size: 0x8
	struct UImage* img_Bullet_13; // Offset: 0x750 | Size: 0x8
	struct UImage* img_Bullet_14; // Offset: 0x758 | Size: 0x8
	struct UImage* img_Bullet_15; // Offset: 0x760 | Size: 0x8
	struct UImage* img_Bullet_16; // Offset: 0x768 | Size: 0x8
	struct UImage* img_Bullet_17; // Offset: 0x770 | Size: 0x8
	struct UCanvasPanel* Panel_Reload; // Offset: 0x778 | Size: 0x8
	struct UImage* SpreadImg_coredot; // Offset: 0x780 | Size: 0x8
	struct USolarTextBlock* Txt_Distance; // Offset: 0x788 | Size: 0x8
	int32_t LastRservedAmmo; // Offset: 0x790 | Size: 0x4
	char pad_0x794[0x4]; // Offset: 0x794 | Size: 0x4
	struct TArray<struct UImage*> BulletImage; // Offset: 0x798 | Size: 0x10

	// Functions

	// Object: Function Crosshair_Carweapon_WL09Rocket.Crosshair_Carweapon_WL09Rocket_C.OnAmmoCounterChanged
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void OnAmmoCounterChanged(int32_t Counter);

	// Object: Function Crosshair_Carweapon_WL09Rocket.Crosshair_Carweapon_WL09Rocket_C.OnAmmoChanged
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0x9) ]
	void OnAmmoChanged(int32_t InReservedAmmo, int32_t InMaxAmmo, bool InbFirst);

	// Object: Function Crosshair_Carweapon_WL09Rocket.Crosshair_Carweapon_WL09Rocket_C.OnUpdateReloadProgress
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0xc) ]
	void OnUpdateReloadProgress(float InReloadProgress, int32_t InReservedAmmo, int32_t InMaxAmmo);

	// Object: Function Crosshair_Carweapon_WL09Rocket.Crosshair_Carweapon_WL09Rocket_C.OnInitialized
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnInitialized();

	// Object: Function Crosshair_Carweapon_WL09Rocket.Crosshair_Carweapon_WL09Rocket_C.OnReloadFinished
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(4) Size(0x10) ]
	void OnReloadFinished(bool InbReloadSuccess, int32_t InReloadAmmo, int32_t InReservedAmmo, int32_t InMaxAmmo);

	// Object: Function Crosshair_Carweapon_WL09Rocket.Crosshair_Carweapon_WL09Rocket_C.OnUpdateAimTargetDistance
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void OnUpdateAimTargetDistance(float InDistance);

	// Object: Function Crosshair_Carweapon_WL09Rocket.Crosshair_Carweapon_WL09Rocket_C.ExecuteUbergraph_Crosshair_Carweapon_WL09Rocket
	// Flags: [Final|UbergraphFunction|HasDefaults]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_Crosshair_Carweapon_WL09Rocket(int32_t EntryPoint);
};

