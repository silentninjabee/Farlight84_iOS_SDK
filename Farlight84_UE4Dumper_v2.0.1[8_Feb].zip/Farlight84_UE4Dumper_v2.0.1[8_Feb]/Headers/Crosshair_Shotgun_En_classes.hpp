#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass Crosshair_Shotgun_En.Crosshair_Shotgun_En_C
// Inherited Bytes: 0x560 | Struct Size: 0x574
struct UCrosshair_Shotgun_En_C : UCrossHairWidget {
	// Fields
	struct UOverlay* SpreadImg_left; // Offset: 0x560 | Size: 0x8
	struct UOverlay* SpreadImg_Right; // Offset: 0x568 | Size: 0x8
	int32_t ; // Offset: 0x570 | Size: 0x4
};

