#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass Crosshair_VehicleSummon.Crosshair_VehicleSummon_C
// Inherited Bytes: 0x560 | Struct Size: 0x588
struct UCrosshair_VehicleSummon_C : UCrossHairWidget {
	// Fields
	struct UImage* SpreadImg_coredot; // Offset: 0x560 | Size: 0x8
	struct UImage* SpreadImg_Downarrow; // Offset: 0x568 | Size: 0x8
	struct UImage* SpreadImg_Leftarrow; // Offset: 0x570 | Size: 0x8
	struct UImage* SpreadImg_Rightarrow; // Offset: 0x578 | Size: 0x8
	struct UImage* SpreadImg_uparrow; // Offset: 0x580 | Size: 0x8
};

