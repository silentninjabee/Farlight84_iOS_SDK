#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass CustomModeFunctionLibrary.CustomModeFunctionLibrary_C
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UCustomModeFunctionLibrary_C : UBlueprintFunctionLibrary {
	// Functions

	// Object: Function CustomModeFunctionLibrary.CustomModeFunctionLibrary_C.LetPlayerOut
	// Flags: [Static|Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x10) ]
	void LetPlayerOut(struct ASCMPlayerState* Player, struct UObject* __WorldContext);

	// Object: Function CustomModeFunctionLibrary.CustomModeFunctionLibrary_C.[ A]Bind On Basic System Ready
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0x19) ]
	void [ A]Bind On Basic System Ready(struct FDelegate& Event, struct UObject* __WorldContext, bool& bReady);

	// Object: Function CustomModeFunctionLibrary.CustomModeFunctionLibrary_C.[s]GetPlayerManager
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UBPC_PlayerManager_C* [s]GetPlayerManager(struct UObject* __WorldContext);
};

