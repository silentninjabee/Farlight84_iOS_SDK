#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass EQC_FishingTarget.EQC_FishingTarget_C
// Inherited Bytes: 0x30 | Struct Size: 0x30
struct UEQC_FishingTarget_C : UEnvQueryContext_BlueprintBase {
	// Functions

	// Object: Function EQC_FishingTarget.EQC_FishingTarget_C.ProvideSingleLocation
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0x1c) ]
	void ProvideSingleLocation(struct UObject* QuerierObject, struct AActor* QuerierActor, struct FVector& ResultingLocation);
};

