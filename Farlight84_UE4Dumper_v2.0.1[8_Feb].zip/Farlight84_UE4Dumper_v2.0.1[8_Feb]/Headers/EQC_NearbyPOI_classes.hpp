#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass EQC_NearbyPOI.EQC_NearbyPOI_C
// Inherited Bytes: 0x30 | Struct Size: 0x30
struct UEQC_NearbyPOI_C : USolarEQC_NearbyPOILocation {
};

