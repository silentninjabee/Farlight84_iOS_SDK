#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass EQC_WarmTargetContext.EQC_WarmTargetContext_C
// Inherited Bytes: 0x30 | Struct Size: 0x30
struct UEQC_WarmTargetContext_C : UEnvQueryContext_BlueprintBase {
	// Functions

	// Object: Function EQC_WarmTargetContext.EQC_WarmTargetContext_C.ProvideSingleActor
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0x18) ]
	void ProvideSingleActor(struct UObject* QuerierObject, struct AActor* QuerierActor, struct AActor*& ResultingActor);
};

