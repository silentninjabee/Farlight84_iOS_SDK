#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: UserDefinedEnum ERoomModeType.ERoomModeType
enum class ERoomModeType : uint8_t {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator2 = 2,
	ERoomModeType_MAX = 3
};

