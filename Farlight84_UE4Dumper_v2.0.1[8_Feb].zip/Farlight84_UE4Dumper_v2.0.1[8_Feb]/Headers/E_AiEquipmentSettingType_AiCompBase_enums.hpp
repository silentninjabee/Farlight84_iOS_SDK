#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: UserDefinedEnum E_AiEquipmentSettingType_AiCompBase.E_AiEquipmentSettingType_AiCompBase
enum class E_AiEquipmentSettingType_AiCompBase : uint8_t {
	NewEnumerator10 = 0,
	NewEnumerator0 = 1,
	NewEnumerator11 = 2,
	NewEnumerator2 = 3,
	NewEnumerator4 = 4,
	NewEnumerator3 = 5,
	NewEnumerator5 = 6,
	E_AiEquipmentSettingType_MAX = 7
};

