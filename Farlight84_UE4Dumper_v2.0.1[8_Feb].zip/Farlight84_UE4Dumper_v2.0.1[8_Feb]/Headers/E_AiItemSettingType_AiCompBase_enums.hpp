#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: UserDefinedEnum E_AiItemSettingType_AiCompBase.E_AiItemSettingType_AiCompBase
enum class E_AiItemSettingType_AiCompBase : uint8_t {
	NewEnumerator12 = 0,
	NewEnumerator0 = 1,
	NewEnumerator1 = 2,
	NewEnumerator2 = 3,
	NewEnumerator4 = 4,
	NewEnumerator5 = 5,
	NewEnumerator6 = 6,
	NewEnumerator7 = 7,
	NewEnumerator8 = 8,
	NewEnumerator13 = 9,
	NewEnumerator14 = 10,
	E_AiItemSettingType_MAX = 11
};

