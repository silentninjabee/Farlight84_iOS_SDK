#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: UserDefinedEnum E_BackPackSlot.E_BackPackSlot
enum class E_BackPackSlot : uint8_t {
	NewEnumerator0 = 0,
	E_MAX = 1
};

