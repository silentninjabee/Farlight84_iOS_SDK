#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: UserDefinedEnum E_BattleState_BattleRoyale.E_BattleState_BattleRoyale
enum class E_BattleState_BattleRoyale : uint8_t {
	NewEnumerator3 = 0,
	NewEnumerator0 = 1,
	NewEnumerator5 = 2,
	NewEnumerator6 = 3,
	NewEnumerator7 = 4,
	NewEnumerator1 = 5,
	NewEnumerator2 = 6,
	NewEnumerator4 = 7,
	E_BattleState_MAX = 8
};

