#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: UserDefinedEnum E_CharacterSkillType.E_CharacterSkillType
enum class E_CharacterSkillType : uint8_t {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	E_MAX = 2
};

