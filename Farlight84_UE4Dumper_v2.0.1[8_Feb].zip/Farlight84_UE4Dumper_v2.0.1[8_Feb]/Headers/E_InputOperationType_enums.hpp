#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: UserDefinedEnum E_InputOperationType.E_InputOperationType
enum class E_InputOperationType : uint8_t {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	E_MAX = 2
};

