#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: UserDefinedEnum E_Type_Social.E_Type_Social
enum class E_Type_Social : uint8_t {
	NewEnumerator5 = 0,
	NewEnumerator0 = 1,
	NewEnumerator1 = 2,
	E_Type_MAX = 3
};

