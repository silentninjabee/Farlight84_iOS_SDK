#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: UserDefinedEnum E_WeaponParts_AiCompBase.E_WeaponParts_AiCompBase
enum class E_WeaponParts_AiCompBase : uint8_t {
	NewEnumerator6 = 0,
	NewEnumerator1 = 1,
	NewEnumerator2 = 2,
	NewEnumerator3 = 3,
	NewEnumerator4 = 4,
	NewEnumerator5 = 5,
	E_WeaponParts_MAX = 6
};

