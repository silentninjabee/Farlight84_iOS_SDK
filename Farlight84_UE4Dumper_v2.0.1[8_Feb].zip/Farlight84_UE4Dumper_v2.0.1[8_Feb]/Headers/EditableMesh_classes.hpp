#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class EditableMesh.EditableMeshAdapter
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UEditableMeshAdapter : UObject {
};

// Object: Class EditableMesh.EditableGeometryCollectionAdapter
// Inherited Bytes: 0x28 | Struct Size: 0xd8
struct UEditableGeometryCollectionAdapter : UEditableMeshAdapter {
	// Fields
	struct UGeometryCollection* GeometryCollection; // Offset: 0x28 | Size: 0x8
	struct UGeometryCollection* OriginalGeometryCollection; // Offset: 0x30 | Size: 0x8
	int32_t GeometryCollectionLODIndex; // Offset: 0x38 | Size: 0x4
	char pad_0x3C[0x9c]; // Offset: 0x3c | Size: 0x9c
};

// Object: Class EditableMesh.EditableMesh
// Inherited Bytes: 0x28 | Struct Size: 0x678
struct UEditableMesh : UObject {
	// Fields
	char pad_0x28[0x390]; // Offset: 0x28 | Size: 0x390
	struct TArray<struct UEditableMeshAdapter*> Adapters; // Offset: 0x3b8 | Size: 0x10
	char pad_0x3C8[0x8]; // Offset: 0x3c8 | Size: 0x8
	int32_t TextureCoordinateCount; // Offset: 0x3d0 | Size: 0x4
	char pad_0x3D4[0x148]; // Offset: 0x3d4 | Size: 0x148
	int32_t PendingCompactCounter; // Offset: 0x51c | Size: 0x4
	int32_t SubdivisionCount; // Offset: 0x520 | Size: 0x4
	char pad_0x524[0x154]; // Offset: 0x524 | Size: 0x154

	// Functions

	// Object: Function EditableMesh.EditableMesh.WeldVertices
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1013cee48
	// Return & Params: [ Num(2) Size(0x14) ]
	void WeldVertices(struct TArray<struct FVertexID>& VertexIDs, struct FVertexID& OutNewVertexID);

	// Object: Function EditableMesh.EditableMesh.TryToRemoveVertex
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1013d0018
	// Return & Params: [ Num(3) Size(0xc) ]
	void TryToRemoveVertex(struct FVertexID VertexID, bool& bOutWasVertexRemoved, struct FEdgeID& OutNewEdgeID);

	// Object: Function EditableMesh.EditableMesh.TryToRemovePolygonEdge
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1013d0168
	// Return & Params: [ Num(3) Size(0xc) ]
	void TryToRemovePolygonEdge(struct FEdgeID EdgeID, bool& bOutWasEdgeRemoved, struct FPolygonID& OutNewPolygonID);

	// Object: Function EditableMesh.EditableMesh.TriangulatePolygons
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1013cf1f8
	// Return & Params: [ Num(2) Size(0x20) ]
	void TriangulatePolygons(struct TArray<struct FPolygonID>& PolygonIDs, struct TArray<struct FPolygonID>& OutNewTrianglePolygons);

	// Object: Function EditableMesh.EditableMesh.TessellatePolygons
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1013ced00
	// Return & Params: [ Num(3) Size(0x28) ]
	void TessellatePolygons(struct TArray<struct FPolygonID>& PolygonIDs, enum class ETriangleTessellationMode TriangleTessellationMode, struct TArray<struct FPolygonID>& OutNewPolygonIDs);

	// Object: Function EditableMesh.EditableMesh.StartModification
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1013d4d4c
	// Return & Params: [ Num(2) Size(0x2) ]
	void StartModification(enum class EMeshModificationType MeshModificationType, enum class EMeshTopologyChange MeshTopologyChange);

	// Object: Function EditableMesh.EditableMesh.SplitPolygons
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1013d153c
	// Return & Params: [ Num(2) Size(0x20) ]
	void SplitPolygons(struct TArray<struct FPolygonToSplit>& PolygonsToSplit, struct TArray<struct FEdgeID>& OutNewEdgeIDs);

	// Object: Function EditableMesh.EditableMesh.SplitPolygonalMesh
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1013ce9a4
	// Return & Params: [ Num(4) Size(0x40) ]
	void SplitPolygonalMesh(struct FPlane& InPlane, struct TArray<struct FPolygonID>& PolygonIDs1, struct TArray<struct FPolygonID>& PolygonIDs2, struct TArray<struct FEdgeID>& BoundaryIDs);

	// Object: Function EditableMesh.EditableMesh.SplitEdge
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1013d17bc
	// Return & Params: [ Num(3) Size(0x28) ]
	void SplitEdge(struct FEdgeID EdgeID, struct TArray<float>& Splits, struct TArray<struct FVertexID>& OutNewVertexIDs);

	// Object: Function EditableMesh.EditableMesh.SetVerticesCornerSharpness
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1013cf668
	// Return & Params: [ Num(2) Size(0x20) ]
	void SetVerticesCornerSharpness(struct TArray<struct FVertexID>& VertexIDs, struct TArray<float>& VerticesNewCornerSharpness);

	// Object: Function EditableMesh.EditableMesh.SetVerticesAttributes
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1013d05f0
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetVerticesAttributes(struct TArray<struct FAttributesForVertex>& AttributesForVertices);

	// Object: Function EditableMesh.EditableMesh.SetVertexInstancesAttributes
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1013d0528
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetVertexInstancesAttributes(struct TArray<struct FAttributesForVertexInstance>& AttributesForVertexInstances);

	// Object: Function EditableMesh.EditableMesh.SetTextureCoordinateCount
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1013cec80
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetTextureCoordinateCount(int32_t NumTexCoords);

	// Object: Function EditableMesh.EditableMesh.SetSubdivisionCount
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1013d1a98
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetSubdivisionCount(int32_t NewSubdivisionCount);

	// Object: Function EditableMesh.EditableMesh.SetPolygonsVertexAttributes
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1013d03cc
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetPolygonsVertexAttributes(struct TArray<struct FVertexAttributesForPolygon>& VertexAttributesForPolygons);

	// Object: Function EditableMesh.EditableMesh.SetEdgesHardnessAutomatically
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1013cf38c
	// Return & Params: [ Num(2) Size(0x14) ]
	void SetEdgesHardnessAutomatically(struct TArray<struct FEdgeID>& EdgeIDs, float MaxDotProductForSoftEdge);

	// Object: Function EditableMesh.EditableMesh.SetEdgesHardness
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1013cf470
	// Return & Params: [ Num(2) Size(0x20) ]
	void SetEdgesHardness(struct TArray<struct FEdgeID>& EdgeIDs, struct TArray<bool>& EdgesNewIsHard);

	// Object: Function EditableMesh.EditableMesh.SetEdgesCreaseSharpness
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1013cf56c
	// Return & Params: [ Num(2) Size(0x20) ]
	void SetEdgesCreaseSharpness(struct TArray<struct FEdgeID>& EdgeIDs, struct TArray<float>& EdgesNewCreaseSharpness);

	// Object: Function EditableMesh.EditableMesh.SetEdgesAttributes
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1013d0460
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetEdgesAttributes(struct TArray<struct FAttributesForEdge>& AttributesForEdges);

	// Object: Function EditableMesh.EditableMesh.SetAllowUndo
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1013d3a70
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetAllowUndo(bool bInAllowUndo);

	// Object: Function EditableMesh.EditableMesh.SetAllowSpatialDatabase
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1013d39cc
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetAllowSpatialDatabase(bool bInAllowSpatialDatabase);

	// Object: Function EditableMesh.EditableMesh.SetAllowCompact
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1013d38f8
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetAllowCompact(bool bInAllowCompact);

	// Object: Function EditableMesh.EditableMesh.SearchSpatialDatabaseForPolygonsPotentiallyIntersectingPlane
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1013d1b18
	// Return & Params: [ Num(2) Size(0x20) ]
	void SearchSpatialDatabaseForPolygonsPotentiallyIntersectingPlane(struct FPlane& InPlane, struct TArray<struct FPolygonID>& OutPolygons);

	// Object: Function EditableMesh.EditableMesh.SearchSpatialDatabaseForPolygonsPotentiallyIntersectingLineSegment
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1013d1d00
	// Return & Params: [ Num(3) Size(0x28) ]
	void SearchSpatialDatabaseForPolygonsPotentiallyIntersectingLineSegment(struct FVector LineSegmentStart, struct FVector LineSegmentEnd, struct TArray<struct FPolygonID>& OutPolygons);

	// Object: Function EditableMesh.EditableMesh.SearchSpatialDatabaseForPolygonsInVolume
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1013d1c04
	// Return & Params: [ Num(2) Size(0x20) ]
	void SearchSpatialDatabaseForPolygonsInVolume(struct TArray<struct FPlane>& Planes, struct TArray<struct FPolygonID>& OutPolygons);

	// Object: Function EditableMesh.EditableMesh.RevertInstance
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1013d4b70
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UEditableMesh* RevertInstance();

	// Object: Function EditableMesh.EditableMesh.Revert
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1013d4ba4
	// Return & Params: [ Num(0) Size(0x0) ]
	void Revert();

	// Object: Function EditableMesh.EditableMesh.RebuildRenderMesh
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1013d4e18
	// Return & Params: [ Num(0) Size(0x0) ]
	void RebuildRenderMesh();

	// Object: Function EditableMesh.EditableMesh.QuadrangulateMesh
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1013cebe8
	// Return & Params: [ Num(1) Size(0x10) ]
	void QuadrangulateMesh(struct TArray<struct FPolygonID>& OutNewPolygonIDs);

	// Object: Function EditableMesh.EditableMesh.PropagateInstanceChanges
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1013d4b5c
	// Return & Params: [ Num(0) Size(0x0) ]
	void PropagateInstanceChanges();

	// Object: Function EditableMesh.EditableMesh.MoveVertices
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1013d1a00
	// Return & Params: [ Num(1) Size(0x10) ]
	void MoveVertices(struct TArray<struct FVertexToMove>& VerticesToMove);

	// Object: Function EditableMesh.EditableMesh.MakeVertexID
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1013d37ec
	// Return & Params: [ Num(2) Size(0x8) ]
	struct FVertexID MakeVertexID(int32_t VertexIndex);

	// Object: Function EditableMesh.EditableMesh.MakePolygonID
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1013d3678
	// Return & Params: [ Num(2) Size(0x8) ]
	struct FPolygonID MakePolygonID(int32_t PolygonIndex);

	// Object: Function EditableMesh.EditableMesh.MakePolygonGroupID
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1013d36f4
	// Return & Params: [ Num(2) Size(0x8) ]
	struct FPolygonGroupID MakePolygonGroupID(int32_t PolygonGroupIndex);

	// Object: Function EditableMesh.EditableMesh.MakeEdgeID
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1013d3770
	// Return & Params: [ Num(2) Size(0x8) ]
	struct FEdgeID MakeEdgeID(int32_t EdgeIndex);

	// Object: Function EditableMesh.EditableMesh.IsValidVertex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1013d4a8c
	// Return & Params: [ Num(2) Size(0x5) ]
	bool IsValidVertex(struct FVertexID VertexID);

	// Object: Function EditableMesh.EditableMesh.IsValidPolygonGroup
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1013d421c
	// Return & Params: [ Num(2) Size(0x5) ]
	bool IsValidPolygonGroup(struct FPolygonGroupID PolygonGroupID);

	// Object: Function EditableMesh.EditableMesh.IsValidPolygon
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1013d3fcc
	// Return & Params: [ Num(2) Size(0x5) ]
	bool IsValidPolygon(struct FPolygonID PolygonID);

	// Object: Function EditableMesh.EditableMesh.IsValidEdge
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1013d4550
	// Return & Params: [ Num(2) Size(0x5) ]
	bool IsValidEdge(struct FEdgeID EdgeID);

	// Object: Function EditableMesh.EditableMesh.IsUndoAllowed
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1013d3af4
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsUndoAllowed();

	// Object: Function EditableMesh.EditableMesh.IsSpatialDatabaseAllowed
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1013d3a54
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsSpatialDatabaseAllowed();

	// Object: Function EditableMesh.EditableMesh.IsPreviewingSubdivisions
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1013d35a8
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsPreviewingSubdivisions();

	// Object: Function EditableMesh.EditableMesh.IsOrphanedVertex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1013d49f0
	// Return & Params: [ Num(2) Size(0x5) ]
	bool IsOrphanedVertex(struct FVertexID VertexID);

	// Object: Function EditableMesh.EditableMesh.IsCompactAllowed
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1013d397c
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsCompactAllowed();

	// Object: Function EditableMesh.EditableMesh.IsCommittedAsInstance
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1013d4c5c
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsCommittedAsInstance();

	// Object: Function EditableMesh.EditableMesh.IsCommitted
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1013d4c90
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsCommitted();

	// Object: Function EditableMesh.EditableMesh.IsBeingModified
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1013d3b10
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsBeingModified();

	// Object: Function EditableMesh.EditableMesh.InvalidVertexID
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1013d38d4
	// Return & Params: [ Num(1) Size(0x4) ]
	struct FVertexID InvalidVertexID();

	// Object: Function EditableMesh.EditableMesh.InvalidPolygonID
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1013d3868
	// Return & Params: [ Num(1) Size(0x4) ]
	struct FPolygonID InvalidPolygonID();

	// Object: Function EditableMesh.EditableMesh.InvalidPolygonGroupID
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1013d388c
	// Return & Params: [ Num(1) Size(0x4) ]
	struct FPolygonGroupID InvalidPolygonGroupID();

	// Object: Function EditableMesh.EditableMesh.InvalidEdgeID
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1013d38b0
	// Return & Params: [ Num(1) Size(0x4) ]
	struct FEdgeID InvalidEdgeID();

	// Object: Function EditableMesh.EditableMesh.InsetPolygons
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1013cf950
	// Return & Params: [ Num(6) Size(0x40) ]
	void InsetPolygons(struct TArray<struct FPolygonID>& PolygonIDs, float InsetFixedDistance, float InsetProgressTowardCenter, enum class EInsetPolygonsMode Mode, struct TArray<struct FPolygonID>& OutNewCenterPolygonIDs, struct TArray<struct FPolygonID>& OutNewSidePolygonIDs);

	// Object: Function EditableMesh.EditableMesh.InsertEdgeLoop
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1013d1668
	// Return & Params: [ Num(3) Size(0x28) ]
	void InsertEdgeLoop(struct FEdgeID EdgeID, struct TArray<float>& Splits, struct TArray<struct FEdgeID>& OutNewEdgeIDs);

	// Object: Function EditableMesh.EditableMesh.InitializeAdapters
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1013d4e2c
	// Return & Params: [ Num(0) Size(0x0) ]
	void InitializeAdapters();

	// Object: Function EditableMesh.EditableMesh.GetVertexPairEdge
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1013d30a0
	// Return & Params: [ Num(4) Size(0x10) ]
	struct FEdgeID GetVertexPairEdge(struct FVertexID VertexID, struct FVertexID NextVertexID, bool& bOutEdgeWindingIsReversed);

	// Object: Function EditableMesh.EditableMesh.GetVertexInstanceVertex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1013d47a0
	// Return & Params: [ Num(2) Size(0x8) ]
	struct FVertexID GetVertexInstanceVertex(struct FVertexInstanceID VertexInstanceID);

	// Object: Function EditableMesh.EditableMesh.GetVertexInstanceCount
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1013d483c
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetVertexInstanceCount();

	// Object: Function EditableMesh.EditableMesh.GetVertexInstanceConnectedPolygons
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1013d32d8
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetVertexInstanceConnectedPolygons(struct FVertexInstanceID VertexInstanceID, struct TArray<struct FPolygonID>& OutConnectedPolygonIDs);

	// Object: Function EditableMesh.EditableMesh.GetVertexInstanceConnectedPolygonCount
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1013d4704
	// Return & Params: [ Num(2) Size(0x8) ]
	int32_t GetVertexInstanceConnectedPolygonCount(struct FVertexInstanceID VertexInstanceID);

	// Object: Function EditableMesh.EditableMesh.GetVertexInstanceConnectedPolygon
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1013d4620
	// Return & Params: [ Num(3) Size(0xc) ]
	struct FPolygonID GetVertexInstanceConnectedPolygon(struct FVertexInstanceID VertexInstanceID, int32_t ConnectedPolygonNumber);

	// Object: Function EditableMesh.EditableMesh.GetVertexCount
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1013d4b28
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetVertexCount();

	// Object: Function EditableMesh.EditableMesh.GetVertexConnectedPolygons
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1013d33c8
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetVertexConnectedPolygons(struct FVertexID VertexID, struct TArray<struct FPolygonID>& OutConnectedPolygonIDs);

	// Object: Function EditableMesh.EditableMesh.GetVertexConnectedEdges
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1013d34b8
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetVertexConnectedEdges(struct FVertexID VertexID, struct TArray<struct FEdgeID>& OutConnectedEdgeIDs);

	// Object: Function EditableMesh.EditableMesh.GetVertexConnectedEdgeCount
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1013d4954
	// Return & Params: [ Num(2) Size(0x8) ]
	int32_t GetVertexConnectedEdgeCount(struct FVertexID VertexID);

	// Object: Function EditableMesh.EditableMesh.GetVertexConnectedEdge
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1013d4870
	// Return & Params: [ Num(3) Size(0xc) ]
	struct FEdgeID GetVertexConnectedEdge(struct FVertexID VertexID, int32_t ConnectedEdgeNumber);

	// Object: Function EditableMesh.EditableMesh.GetVertexAdjacentVertices
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1013d31e8
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetVertexAdjacentVertices(struct FVertexID VertexID, struct TArray<struct FVertexID>& OutAdjacentVertexIDs);

	// Object: Function EditableMesh.EditableMesh.GetTextureCoordinateCount
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1013d3610
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetTextureCoordinateCount();

	// Object: Function EditableMesh.EditableMesh.GetSubdivisionLimitData
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1013d213c
	// Return & Params: [ Num(1) Size(0x30) ]
	struct FSubdivisionLimitData GetSubdivisionLimitData();

	// Object: Function EditableMesh.EditableMesh.GetSubdivisionCount
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1013d35dc
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetSubdivisionCount();

	// Object: Function EditableMesh.EditableMesh.GetPolygonTriangulatedTriangleCount
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1013d3c30
	// Return & Params: [ Num(2) Size(0x8) ]
	int32_t GetPolygonTriangulatedTriangleCount(struct FPolygonID PolygonID);

	// Object: Function EditableMesh.EditableMesh.GetPolygonTriangulatedTriangle
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1013d3b4c
	// Return & Params: [ Num(3) Size(0xc) ]
	struct FTriangleID GetPolygonTriangulatedTriangle(struct FPolygonID PolygonID, int32_t PolygonTriangleNumber);

	// Object: Function EditableMesh.EditableMesh.GetPolygonPerimeterVertices
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1013d2aec
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetPolygonPerimeterVertices(struct FPolygonID PolygonID, struct TArray<struct FVertexID>& OutPolygonPerimeterVertexIDs);

	// Object: Function EditableMesh.EditableMesh.GetPolygonPerimeterVertexInstances
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1013d29fc
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetPolygonPerimeterVertexInstances(struct FPolygonID PolygonID, struct TArray<struct FVertexInstanceID>& OutPolygonPerimeterVertexInstanceIDs);

	// Object: Function EditableMesh.EditableMesh.GetPolygonPerimeterVertexInstance
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1013d3ccc
	// Return & Params: [ Num(3) Size(0xc) ]
	struct FVertexInstanceID GetPolygonPerimeterVertexInstance(struct FPolygonID PolygonID, int32_t PolygonVertexNumber);

	// Object: Function EditableMesh.EditableMesh.GetPolygonPerimeterVertexCount
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1013d3e94
	// Return & Params: [ Num(2) Size(0x8) ]
	int32_t GetPolygonPerimeterVertexCount(struct FPolygonID PolygonID);

	// Object: Function EditableMesh.EditableMesh.GetPolygonPerimeterVertex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1013d3db0
	// Return & Params: [ Num(3) Size(0xc) ]
	struct FVertexID GetPolygonPerimeterVertex(struct FPolygonID PolygonID, int32_t PolygonVertexNumber);

	// Object: Function EditableMesh.EditableMesh.GetPolygonPerimeterEdges
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1013d27d0
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetPolygonPerimeterEdges(struct FPolygonID PolygonID, struct TArray<struct FEdgeID>& OutPolygonPerimeterEdgeIDs);

	// Object: Function EditableMesh.EditableMesh.GetPolygonPerimeterEdgeCount
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1013d2bdc
	// Return & Params: [ Num(2) Size(0x8) ]
	int32_t GetPolygonPerimeterEdgeCount(struct FPolygonID PolygonID);

	// Object: Function EditableMesh.EditableMesh.GetPolygonPerimeterEdge
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1013d28c0
	// Return & Params: [ Num(4) Size(0x10) ]
	struct FEdgeID GetPolygonPerimeterEdge(struct FPolygonID PolygonID, int32_t PerimeterEdgeNumber, bool& bOutEdgeWindingIsReversedForPolygon);

	// Object: Function EditableMesh.EditableMesh.GetPolygonInGroup
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1013d409c
	// Return & Params: [ Num(3) Size(0xc) ]
	struct FPolygonID GetPolygonInGroup(struct FPolygonGroupID PolygonGroupID, int32_t PolygonNumber);

	// Object: Function EditableMesh.EditableMesh.GetPolygonGroupCount
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1013d42b8
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetPolygonGroupCount();

	// Object: Function EditableMesh.EditableMesh.GetPolygonCountInGroup
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1013d4180
	// Return & Params: [ Num(2) Size(0x8) ]
	int32_t GetPolygonCountInGroup(struct FPolygonGroupID PolygonGroupID);

	// Object: Function EditableMesh.EditableMesh.GetPolygonCount
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1013d4068
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetPolygonCount();

	// Object: Function EditableMesh.EditableMesh.GetPolygonAdjacentPolygons
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1013d26e0
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetPolygonAdjacentPolygons(struct FPolygonID PolygonID, struct TArray<struct FPolygonID>& OutAdjacentPolygons);

	// Object: Function EditableMesh.EditableMesh.GetGroupForPolygon
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1013d3f30
	// Return & Params: [ Num(2) Size(0x8) ]
	struct FPolygonGroupID GetGroupForPolygon(struct FPolygonID PolygonID);

	// Object: Function EditableMesh.EditableMesh.GetFirstValidPolygonGroup
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1013d3644
	// Return & Params: [ Num(1) Size(0x4) ]
	struct FPolygonGroupID GetFirstValidPolygonGroup();

	// Object: Function EditableMesh.EditableMesh.GetEdgeVertices
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1013d2f48
	// Return & Params: [ Num(3) Size(0xc) ]
	void GetEdgeVertices(struct FEdgeID EdgeID, struct FVertexID& OutEdgeVertexID0, struct FVertexID& OutEdgeVertexID1);

	// Object: Function EditableMesh.EditableMesh.GetEdgeVertex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1013d446c
	// Return & Params: [ Num(3) Size(0xc) ]
	struct FVertexID GetEdgeVertex(struct FEdgeID EdgeID, int32_t EdgeVertexNumber);

	// Object: Function EditableMesh.EditableMesh.GetEdgeThatConnectsVertices
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1013d2c78
	// Return & Params: [ Num(3) Size(0xc) ]
	struct FEdgeID GetEdgeThatConnectsVertices(struct FVertexID VertexID0, struct FVertexID VertexID1);

	// Object: Function EditableMesh.EditableMesh.GetEdgeLoopElements
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1013d2d68
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetEdgeLoopElements(struct FEdgeID EdgeID, struct TArray<struct FEdgeID>& EdgeLoopIDs);

	// Object: Function EditableMesh.EditableMesh.GetEdgeCount
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1013d45ec
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetEdgeCount();

	// Object: Function EditableMesh.EditableMesh.GetEdgeConnectedPolygons
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1013d2e58
	// Return & Params: [ Num(2) Size(0x18) ]
	void GetEdgeConnectedPolygons(struct FEdgeID EdgeID, struct TArray<struct FPolygonID>& OutConnectedPolygonIDs);

	// Object: Function EditableMesh.EditableMesh.GetEdgeConnectedPolygonCount
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1013d43d0
	// Return & Params: [ Num(2) Size(0x8) ]
	int32_t GetEdgeConnectedPolygonCount(struct FEdgeID EdgeID);

	// Object: Function EditableMesh.EditableMesh.GetEdgeConnectedPolygon
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1013d42ec
	// Return & Params: [ Num(3) Size(0xc) ]
	struct FPolygonID GetEdgeConnectedPolygon(struct FEdgeID EdgeID, int32_t ConnectedPolygonNumber);

	// Object: Function EditableMesh.EditableMesh.GeneratePolygonTangentsAndNormals
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1013ceb50
	// Return & Params: [ Num(1) Size(0x10) ]
	void GeneratePolygonTangentsAndNormals(struct TArray<struct FPolygonID>& PolygonIDs);

	// Object: Function EditableMesh.EditableMesh.FlipPolygons
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1013cf2f4
	// Return & Params: [ Num(1) Size(0x10) ]
	void FlipPolygons(struct TArray<struct FPolygonID>& PolygonIDs);

	// Object: Function EditableMesh.EditableMesh.FindPolygonPerimeterVertexNumberForVertex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1013d25f0
	// Return & Params: [ Num(3) Size(0xc) ]
	int32_t FindPolygonPerimeterVertexNumberForVertex(struct FPolygonID PolygonID, struct FVertexID VertexID);

	// Object: Function EditableMesh.EditableMesh.FindPolygonPerimeterEdgeNumberForVertices
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1013d24ac
	// Return & Params: [ Num(4) Size(0x10) ]
	int32_t FindPolygonPerimeterEdgeNumberForVertices(struct FPolygonID PolygonID, struct FVertexID EdgeVertexID0, struct FVertexID EdgeVertexID1);

	// Object: Function EditableMesh.EditableMesh.FindPolygonLoop
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1013d1e2c
	// Return & Params: [ Num(5) Size(0x48) ]
	void FindPolygonLoop(struct FEdgeID EdgeID, struct TArray<struct FEdgeID>& OutEdgeLoopEdgeIDs, struct TArray<struct FEdgeID>& OutFlippedEdgeIDs, struct TArray<struct FEdgeID>& OutReversedEdgeIDPathToTake, struct TArray<struct FPolygonID>& OutPolygonIDsToSplit);

	// Object: Function EditableMesh.EditableMesh.ExtrudePolygons
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1013cfe78
	// Return & Params: [ Num(4) Size(0x28) ]
	void ExtrudePolygons(struct TArray<struct FPolygonID>& Polygons, float ExtrudeDistance, bool bKeepNeighborsTogether, struct TArray<struct FPolygonID>& OutNewExtrudedFrontPolygons);

	// Object: Function EditableMesh.EditableMesh.ExtendVertices
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x1013cfb88
	// Return & Params: [ Num(4) Size(0x30) ]
	void ExtendVertices(struct TArray<struct FVertexID>& VertexIDs, bool bOnlyExtendClosestEdge, struct FVector ReferencePosition, struct TArray<struct FVertexID>& OutNewExtendedVertexIDs);

	// Object: Function EditableMesh.EditableMesh.ExtendEdges
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1013cfd24
	// Return & Params: [ Num(3) Size(0x28) ]
	void ExtendEdges(struct TArray<struct FEdgeID>& EdgeIDs, bool bWeldNeighbors, struct TArray<struct FEdgeID>& OutNewExtendedEdgeIDs);

	// Object: Function EditableMesh.EditableMesh.EndModification
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1013d4cc4
	// Return & Params: [ Num(1) Size(0x1) ]
	void EndModification(bool bFromUndo);

	// Object: Function EditableMesh.EditableMesh.DeleteVertexInstances
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1013d0fc8
	// Return & Params: [ Num(2) Size(0x11) ]
	void DeleteVertexInstances(struct TArray<struct FVertexInstanceID>& VertexInstanceIDsToDelete, bool bDeleteOrphanedVertices);

	// Object: Function EditableMesh.EditableMesh.DeleteVertexAndConnectedEdgesAndPolygons
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1013d114c
	// Return & Params: [ Num(5) Size(0x8) ]
	void DeleteVertexAndConnectedEdgesAndPolygons(struct FVertexID VertexID, bool bDeleteOrphanedEdges, bool bDeleteOrphanedVertices, bool bDeleteOrphanedVertexInstances, bool bDeleteEmptyPolygonGroups);

	// Object: Function EditableMesh.EditableMesh.DeletePolygons
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1013d06b8
	// Return & Params: [ Num(5) Size(0x14) ]
	void DeletePolygons(struct TArray<struct FPolygonID>& PolygonIDsToDelete, bool bDeleteOrphanedEdges, bool bDeleteOrphanedVertices, bool bDeleteOrphanedVertexInstances, bool bDeleteEmptyPolygonGroups);

	// Object: Function EditableMesh.EditableMesh.DeletePolygonGroups
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1013cf030
	// Return & Params: [ Num(1) Size(0x10) ]
	void DeletePolygonGroups(struct TArray<struct FPolygonGroupID>& PolygonGroupIDs);

	// Object: Function EditableMesh.EditableMesh.DeleteOrphanVertices
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1013d10b4
	// Return & Params: [ Num(1) Size(0x10) ]
	void DeleteOrphanVertices(struct TArray<struct FVertexID>& VertexIDsToDelete);

	// Object: Function EditableMesh.EditableMesh.DeleteEdges
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1013d0edc
	// Return & Params: [ Num(2) Size(0x11) ]
	void DeleteEdges(struct TArray<struct FEdgeID>& EdgeIDsToDelete, bool bDeleteOrphanedVertices);

	// Object: Function EditableMesh.EditableMesh.DeleteEdgeAndConnectedPolygons
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1013d1344
	// Return & Params: [ Num(5) Size(0x8) ]
	void DeleteEdgeAndConnectedPolygons(struct FEdgeID EdgeID, bool bDeleteOrphanedEdges, bool bDeleteOrphanedVertices, bool bDeleteOrphanedVertexInstances, bool bDeleteEmptyPolygonGroups);

	// Object: Function EditableMesh.EditableMesh.CreateVertices
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1013d0cc8
	// Return & Params: [ Num(2) Size(0x20) ]
	void CreateVertices(struct TArray<struct FVertexToCreate>& VerticesToCreate, struct TArray<struct FVertexID>& OutNewVertexIDs);

	// Object: Function EditableMesh.EditableMesh.CreateVertexInstances
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1013d0b9c
	// Return & Params: [ Num(2) Size(0x20) ]
	void CreateVertexInstances(struct TArray<struct FVertexInstanceToCreate>& VertexInstancesToCreate, struct TArray<struct FVertexInstanceID>& OutNewVertexInstanceIDs);

	// Object: Function EditableMesh.EditableMesh.CreatePolygons
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1013d08b4
	// Return & Params: [ Num(3) Size(0x30) ]
	void CreatePolygons(struct TArray<struct FPolygonToCreate>& PolygonsToCreate, struct TArray<struct FPolygonID>& OutNewPolygonIDs, struct TArray<struct FEdgeID>& OutNewEdgeIDs);

	// Object: Function EditableMesh.EditableMesh.CreatePolygonGroups
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1013cf0c8
	// Return & Params: [ Num(2) Size(0x20) ]
	void CreatePolygonGroups(struct TArray<struct FPolygonGroupToCreate>& PolygonGroupsToCreate, struct TArray<struct FPolygonGroupID>& OutNewPolygonGroupIDs);

	// Object: Function EditableMesh.EditableMesh.CreateMissingPolygonPerimeterEdges
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1013d1910
	// Return & Params: [ Num(2) Size(0x18) ]
	void CreateMissingPolygonPerimeterEdges(struct FPolygonID PolygonID, struct TArray<struct FEdgeID>& OutNewEdgeIDs);

	// Object: Function EditableMesh.EditableMesh.CreateEmptyVertexRange
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1013d0df8
	// Return & Params: [ Num(2) Size(0x18) ]
	void CreateEmptyVertexRange(int32_t NumVerticesToCreate, struct TArray<struct FVertexID>& OutNewVertexIDs);

	// Object: Function EditableMesh.EditableMesh.CreateEdges
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1013d0a70
	// Return & Params: [ Num(2) Size(0x20) ]
	void CreateEdges(struct TArray<struct FEdgeToCreate>& EdgesToCreate, struct TArray<struct FEdgeID>& OutNewEdgeIDs);

	// Object: Function EditableMesh.EditableMesh.ComputePolygonsSharedEdges
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1013d2040
	// Return & Params: [ Num(2) Size(0x20) ]
	void ComputePolygonsSharedEdges(struct TArray<struct FPolygonID>& PolygonIDs, struct TArray<struct FEdgeID>& OutSharedEdgeIDs);

	// Object: Function EditableMesh.EditableMesh.ComputePolygonPlane
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1013d22cc
	// Return & Params: [ Num(2) Size(0x20) ]
	struct FPlane ComputePolygonPlane(struct FPolygonID PolygonID);

	// Object: Function EditableMesh.EditableMesh.ComputePolygonNormal
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1013d222c
	// Return & Params: [ Num(2) Size(0x10) ]
	struct FVector ComputePolygonNormal(struct FPolygonID PolygonID);

	// Object: Function EditableMesh.EditableMesh.ComputePolygonCenter
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1013d2374
	// Return & Params: [ Num(2) Size(0x10) ]
	struct FVector ComputePolygonCenter(struct FPolygonID PolygonID);

	// Object: Function EditableMesh.EditableMesh.ComputeBoundingBoxAndSphere
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1013d2414
	// Return & Params: [ Num(1) Size(0x1c) ]
	struct FBoxSphereBounds ComputeBoundingBoxAndSphere();

	// Object: Function EditableMesh.EditableMesh.ComputeBoundingBox
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1013d2460
	// Return & Params: [ Num(1) Size(0x1c) ]
	struct FBox ComputeBoundingBox();

	// Object: Function EditableMesh.EditableMesh.CommitInstance
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1013d4bb8
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UEditableMesh* CommitInstance(struct UPrimitiveComponent* ComponentToInstanceTo);

	// Object: Function EditableMesh.EditableMesh.Commit
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1013d4c48
	// Return & Params: [ Num(0) Size(0x0) ]
	void Commit();

	// Object: Function EditableMesh.EditableMesh.ChangePolygonsVertexInstances
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1013d02b8
	// Return & Params: [ Num(1) Size(0x10) ]
	void ChangePolygonsVertexInstances(struct TArray<struct FChangeVertexInstancesForPolygon>& VertexInstancesForPolygons);

	// Object: Function EditableMesh.EditableMesh.BevelPolygons
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1013cf764
	// Return & Params: [ Num(5) Size(0x38) ]
	void BevelPolygons(struct TArray<struct FPolygonID>& PolygonIDs, float BevelFixedDistance, float BevelProgressTowardCenter, struct TArray<struct FPolygonID>& OutNewCenterPolygonIDs, struct TArray<struct FPolygonID>& OutNewSidePolygonIDs);

	// Object: Function EditableMesh.EditableMesh.AssignPolygonsToPolygonGroups
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1013cef44
	// Return & Params: [ Num(2) Size(0x11) ]
	void AssignPolygonsToPolygonGroups(struct TArray<struct FPolygonGroupForPolygon>& PolygonGroupForPolygons, bool bDeleteOrphanedPolygonGroups);

	// Object: Function EditableMesh.EditableMesh.AnyChangesToUndo
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1013d3998
	// Return & Params: [ Num(1) Size(0x1) ]
	bool AnyChangesToUndo();
};

// Object: Class EditableMesh.EditableMeshFactory
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UEditableMeshFactory : UObject {
	// Functions

	// Object: Function EditableMesh.EditableMeshFactory.MakeEditableMesh
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1013d9e34
	// Return & Params: [ Num(3) Size(0x18) ]
	struct UEditableMesh* MakeEditableMesh(struct UPrimitiveComponent* PrimitiveComponent, int32_t LODIndex);
};

// Object: Class EditableMesh.EditableStaticMeshAdapter
// Inherited Bytes: 0x28 | Struct Size: 0xe0
struct UEditableStaticMeshAdapter : UEditableMeshAdapter {
	// Fields
	struct UStaticMesh* StaticMesh; // Offset: 0x28 | Size: 0x8
	struct UStaticMesh* OriginalStaticMesh; // Offset: 0x30 | Size: 0x8
	int32_t StaticMeshLODIndex; // Offset: 0x38 | Size: 0x4
	char pad_0x3C[0xa4]; // Offset: 0x3c | Size: 0xa4
};

