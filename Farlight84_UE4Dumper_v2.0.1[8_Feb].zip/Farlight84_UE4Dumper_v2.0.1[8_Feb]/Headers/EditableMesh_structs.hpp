#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct EditableMesh.AdaptorPolygon2Group
// Inherited Bytes: 0x0 | Struct Size: 0x48
struct FAdaptorPolygon2Group {
	// Fields
	uint32_t RenderingSectionIndex; // Offset: 0x0 | Size: 0x4
	int32_t MaterialIndex; // Offset: 0x4 | Size: 0x4
	int32_t MaxTriangles; // Offset: 0x8 | Size: 0x4
	char pad_0xC[0x3c]; // Offset: 0xc | Size: 0x3c
};

// Object: ScriptStruct EditableMesh.AdaptorPolygon
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FAdaptorPolygon {
	// Fields
	struct FPolygonGroupID PolygonGroupID; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct TArray<struct FAdaptorTriangleID> TriangulatedPolygonTriangleIndices; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct EditableMesh.AdaptorTriangleID
// Inherited Bytes: 0x4 | Struct Size: 0x4
struct FAdaptorTriangleID : FElementID {
};

// Object: ScriptStruct EditableMesh.PolygonGroupForPolygon
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FPolygonGroupForPolygon {
	// Fields
	struct FPolygonID PolygonID; // Offset: 0x0 | Size: 0x4
	struct FPolygonGroupID PolygonGroupID; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct EditableMesh.PolygonGroupToCreate
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FPolygonGroupToCreate {
	// Fields
	struct FMeshElementAttributeList PolygonGroupAttributes; // Offset: 0x0 | Size: 0x10
	struct FPolygonGroupID OriginalPolygonGroupID; // Offset: 0x10 | Size: 0x4
	char pad_0x14[0x4]; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct EditableMesh.MeshElementAttributeList
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FMeshElementAttributeList {
	// Fields
	struct TArray<struct FMeshElementAttributeData> Attributes; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct EditableMesh.MeshElementAttributeData
// Inherited Bytes: 0x0 | Struct Size: 0x60
struct FMeshElementAttributeData {
	// Fields
	struct FName AttributeName; // Offset: 0x0 | Size: 0x8
	int32_t AttributeIndex; // Offset: 0x8 | Size: 0x4
	char pad_0xC[0x4]; // Offset: 0xc | Size: 0x4
	struct FMeshElementAttributeValue AttributeValue; // Offset: 0x10 | Size: 0x50
};

// Object: ScriptStruct EditableMesh.MeshElementAttributeValue
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FMeshElementAttributeValue {
	// Fields
	char pad_0x0[0x50]; // Offset: 0x0 | Size: 0x50
};

// Object: ScriptStruct EditableMesh.VertexToMove
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FVertexToMove {
	// Fields
	struct FVertexID VertexID; // Offset: 0x0 | Size: 0x4
	struct FVector NewVertexPosition; // Offset: 0x4 | Size: 0xc
};

// Object: ScriptStruct EditableMesh.ChangeVertexInstancesForPolygon
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FChangeVertexInstancesForPolygon {
	// Fields
	struct FPolygonID PolygonID; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct TArray<struct FVertexIndexAndInstanceID> PerimeterVertexIndicesAndInstanceIDs; // Offset: 0x8 | Size: 0x10
	struct TArray<struct FVertexInstancesForPolygonHole> VertexIndicesAndInstanceIDsForEachHole; // Offset: 0x18 | Size: 0x10
};

// Object: ScriptStruct EditableMesh.VertexInstancesForPolygonHole
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FVertexInstancesForPolygonHole {
	// Fields
	struct TArray<struct FVertexIndexAndInstanceID> VertexIndicesAndInstanceIDs; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct EditableMesh.VertexIndexAndInstanceID
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FVertexIndexAndInstanceID {
	// Fields
	int32_t ContourIndex; // Offset: 0x0 | Size: 0x4
	struct FVertexInstanceID VertexInstanceID; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct EditableMesh.VertexAttributesForPolygon
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FVertexAttributesForPolygon {
	// Fields
	struct FPolygonID PolygonID; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct TArray<struct FMeshElementAttributeList> PerimeterVertexAttributeLists; // Offset: 0x8 | Size: 0x10
	struct TArray<struct FVertexAttributesForPolygonHole> VertexAttributeListsForEachHole; // Offset: 0x18 | Size: 0x10
};

// Object: ScriptStruct EditableMesh.VertexAttributesForPolygonHole
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FVertexAttributesForPolygonHole {
	// Fields
	struct TArray<struct FMeshElementAttributeList> VertexAttributeList; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct EditableMesh.AttributesForEdge
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FAttributesForEdge {
	// Fields
	struct FEdgeID EdgeID; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct FMeshElementAttributeList EdgeAttributes; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct EditableMesh.AttributesForVertexInstance
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FAttributesForVertexInstance {
	// Fields
	struct FVertexInstanceID VertexInstanceID; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct FMeshElementAttributeList VertexInstanceAttributes; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct EditableMesh.AttributesForVertex
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FAttributesForVertex {
	// Fields
	struct FVertexID VertexID; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct FMeshElementAttributeList VertexAttributes; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct EditableMesh.PolygonToSplit
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FPolygonToSplit {
	// Fields
	struct FPolygonID PolygonID; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct TArray<struct FVertexPair> VertexPairsToSplitAt; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct EditableMesh.VertexPair
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FVertexPair {
	// Fields
	struct FVertexID VertexID0; // Offset: 0x0 | Size: 0x4
	struct FVertexID VertexID1; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct EditableMesh.PolygonToCreate
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FPolygonToCreate {
	// Fields
	struct FPolygonGroupID PolygonGroupID; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct TArray<struct FVertexAndAttributes> PerimeterVertices; // Offset: 0x8 | Size: 0x10
	struct FPolygonID OriginalPolygonID; // Offset: 0x18 | Size: 0x4
	enum class EPolygonEdgeHardness PolygonEdgeHardness; // Offset: 0x1c | Size: 0x1
	char pad_0x1D[0x3]; // Offset: 0x1d | Size: 0x3
};

// Object: ScriptStruct EditableMesh.VertexAndAttributes
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FVertexAndAttributes {
	// Fields
	struct FVertexInstanceID VertexInstanceID; // Offset: 0x0 | Size: 0x4
	struct FVertexID VertexID; // Offset: 0x4 | Size: 0x4
	struct FMeshElementAttributeList PolygonVertexAttributes; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct EditableMesh.EdgeToCreate
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FEdgeToCreate {
	// Fields
	struct FVertexID VertexID0; // Offset: 0x0 | Size: 0x4
	struct FVertexID VertexID1; // Offset: 0x4 | Size: 0x4
	struct FMeshElementAttributeList EdgeAttributes; // Offset: 0x8 | Size: 0x10
	struct FEdgeID OriginalEdgeID; // Offset: 0x18 | Size: 0x4
	char pad_0x1C[0x4]; // Offset: 0x1c | Size: 0x4
};

// Object: ScriptStruct EditableMesh.VertexInstanceToCreate
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FVertexInstanceToCreate {
	// Fields
	struct FVertexID VertexID; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct FMeshElementAttributeList VertexInstanceAttributes; // Offset: 0x8 | Size: 0x10
	struct FVertexInstanceID OriginalVertexInstanceID; // Offset: 0x18 | Size: 0x4
	char pad_0x1C[0x4]; // Offset: 0x1c | Size: 0x4
};

// Object: ScriptStruct EditableMesh.VertexToCreate
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FVertexToCreate {
	// Fields
	struct FMeshElementAttributeList VertexAttributes; // Offset: 0x0 | Size: 0x10
	struct FVertexID OriginalVertexID; // Offset: 0x10 | Size: 0x4
	char pad_0x14[0x4]; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct EditableMesh.SubdivisionLimitData
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FSubdivisionLimitData {
	// Fields
	struct TArray<struct FVector> VertexPositions; // Offset: 0x0 | Size: 0x10
	struct TArray<struct FSubdivisionLimitSection> Sections; // Offset: 0x10 | Size: 0x10
	struct TArray<struct FSubdividedWireEdge> SubdividedWireEdges; // Offset: 0x20 | Size: 0x10
};

// Object: ScriptStruct EditableMesh.SubdividedWireEdge
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FSubdividedWireEdge {
	// Fields
	int32_t EdgeVertex0PositionIndex; // Offset: 0x0 | Size: 0x4
	int32_t EdgeVertex1PositionIndex; // Offset: 0x4 | Size: 0x4
	char pad_0x8[0x4]; // Offset: 0x8 | Size: 0x4
};

// Object: ScriptStruct EditableMesh.SubdivisionLimitSection
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FSubdivisionLimitSection {
	// Fields
	struct TArray<struct FSubdividedQuad> SubdividedQuads; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct EditableMesh.SubdividedQuad
// Inherited Bytes: 0x0 | Struct Size: 0xd0
struct FSubdividedQuad {
	// Fields
	struct FSubdividedQuadVertex QuadVertex0; // Offset: 0x0 | Size: 0x34
	struct FSubdividedQuadVertex QuadVertex1; // Offset: 0x34 | Size: 0x34
	struct FSubdividedQuadVertex QuadVertex2; // Offset: 0x68 | Size: 0x34
	struct FSubdividedQuadVertex QuadVertex3; // Offset: 0x9c | Size: 0x34
};

// Object: ScriptStruct EditableMesh.SubdividedQuadVertex
// Inherited Bytes: 0x0 | Struct Size: 0x34
struct FSubdividedQuadVertex {
	// Fields
	int32_t VertexPositionIndex; // Offset: 0x0 | Size: 0x4
	struct FVector2D TextureCoordinate0; // Offset: 0x4 | Size: 0x8
	struct FVector2D TextureCoordinate1; // Offset: 0xc | Size: 0x8
	struct FColor VertexColor; // Offset: 0x14 | Size: 0x4
	struct FVector VertexNormal; // Offset: 0x18 | Size: 0xc
	struct FVector VertexTangent; // Offset: 0x24 | Size: 0xc
	float VertexBinormalSign; // Offset: 0x30 | Size: 0x4
};

// Object: ScriptStruct EditableMesh.RenderingPolygonGroup
// Inherited Bytes: 0x0 | Struct Size: 0x48
struct FRenderingPolygonGroup {
	// Fields
	uint32_t RenderingSectionIndex; // Offset: 0x0 | Size: 0x4
	int32_t MaterialIndex; // Offset: 0x4 | Size: 0x4
	int32_t MaxTriangles; // Offset: 0x8 | Size: 0x4
	char pad_0xC[0x3c]; // Offset: 0xc | Size: 0x3c
};

// Object: ScriptStruct EditableMesh.RenderingPolygon
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FRenderingPolygon {
	// Fields
	struct FPolygonGroupID PolygonGroupID; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct TArray<struct FTriangleID> TriangulatedPolygonTriangleIndices; // Offset: 0x8 | Size: 0x10
};

