#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass Effect_VH_Leg_WL09_Rocket_ExplosionDamage.Effect_VH_Leg_WL09_Rocket_ExplosionDamage_C
// Inherited Bytes: 0x198 | Struct Size: 0x198
struct UEffect_VH_Leg_WL09_Rocket_ExplosionDamage_C : USolarAbilityEffect {
};

