#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class EyeTracker.EyeTrackerFunctionLibrary
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UEyeTrackerFunctionLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object: Function EyeTracker.EyeTrackerFunctionLibrary.SetEyeTrackedPlayer
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104e5fbbc
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetEyeTrackedPlayer(struct APlayerController* PlayerController);

	// Object: Function EyeTracker.EyeTrackerFunctionLibrary.IsStereoGazeDataAvailable
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x104e5fd5c
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsStereoGazeDataAvailable();

	// Object: Function EyeTracker.EyeTrackerFunctionLibrary.IsEyeTrackerConnected
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x104e5fd90
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsEyeTrackerConnected();

	// Object: Function EyeTracker.EyeTrackerFunctionLibrary.GetStereoGazeData
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104e5fc34
	// Return & Params: [ Num(2) Size(0x41) ]
	bool GetStereoGazeData(struct FEyeTrackerStereoGazeData& OutGazeData);

	// Object: Function EyeTracker.EyeTrackerFunctionLibrary.GetGazeData
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104e5fcc8
	// Return & Params: [ Num(2) Size(0x29) ]
	bool GetGazeData(struct FEyeTrackerGazeData& OutGazeData);
};

