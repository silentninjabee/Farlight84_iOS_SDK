#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass FL_SettlementFormula.FL_SettlementFormula_C
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UFL_SettlementFormula_C : UBlueprintFunctionLibrary {
	// Functions

	// Object: Function FL_SettlementFormula.FL_SettlementFormula_C.IntCompareReward
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(7) Size(0x88) ]
	void IntCompareReward(int32_t Source, int32_t Condition, struct TMap<int32_t, int32_t> Item-Count, float Weight, struct UObject* __WorldContext, struct FString& Desc, struct FString& ItemList);

	// Object: Function FL_SettlementFormula.FL_SettlementFormula_C.GetCommonExtraRewards
	// Flags: [Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(6) Size(0x28) ]
	void GetCommonExtraRewards(int32_t SaveNum, int32_t KillNum, int32_t AssitNum, float DamageValue, struct UObject* __WorldContext, struct TArray<struct FSettlementParam_ExtraRewardInfo>& NewParam);

	// Object: Function FL_SettlementFormula.FL_SettlementFormula_C.Combine Reward Item
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0x28) ]
	void Combine Reward Item(struct TArray<struct FString>& RewardList, struct UObject* __WorldContext, struct FString& RewardString);

	// Object: Function FL_SettlementFormula.FL_SettlementFormula_C.FormatRewardItem
	// Flags: [Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(5) Size(0x28) ]
	void FormatRewardItem(float Weight, int32_t ItemID, int32_t ItemCount, struct UObject* __WorldContext, struct FString& ItemString);
};

