#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass GA_Weapon_EMP_Throw.GA_Weapon_EMP_Throw_C
// Inherited Bytes: 0x420 | Struct Size: 0x428
struct UGA_Weapon_EMP_Throw_C : USolarWeaponGameplayAbility {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x420 | Size: 0x8

	// Functions

	// Object: Function GA_Weapon_EMP_Throw.GA_Weapon_EMP_Throw_C.K2_ActivateAbilityFromEvent
	// Flags: [Event|Protected|HasOutParms|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0xb0) ]
	void K2_ActivateAbilityFromEvent(struct FGameplayEventData& EventData);

	// Object: Function GA_Weapon_EMP_Throw.GA_Weapon_EMP_Throw_C.ExecuteUbergraph_GA_Weapon_EMP_Throw
	// Flags: [Final|UbergraphFunction|HasDefaults]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_GA_Weapon_EMP_Throw(int32_t EntryPoint);
};

