#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass GCBP_LaunchCharacter.GCBP_LaunchCharacter_C
// Inherited Bytes: 0x298 | Struct Size: 0x2a1
struct AGCBP_LaunchCharacter_C : AGameplayCueNotify_Actor {
	// Fields
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x298 | Size: 0x8
	bool IsSummonedJumpPad; // Offset: 0x2a0 | Size: 0x1

	// Functions

	// Object: Function GCBP_LaunchCharacter.GCBP_LaunchCharacter_C.OnActive
	// Flags: [Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0xc9) ]
	bool OnActive(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters);

	// Object: Function GCBP_LaunchCharacter.GCBP_LaunchCharacter_C.OnRemove
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0xc9) ]
	bool OnRemove(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters);
};

