#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass GC_SuperRadarChoose.GC_SuperRadarChoose_C
// Inherited Bytes: 0x298 | Struct Size: 0x2d0
struct AGC_SuperRadarChoose_C : AGameplayCueNotify_Actor {
	// Fields
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x298 | Size: 0x8
	int32_t FXRootHandle; // Offset: 0x2a0 | Size: 0x4
	int32_t FXEyeHandle; // Offset: 0x2a4 | Size: 0x4
	struct ASolarCharacter* CacheCharacter; // Offset: 0x2a8 | Size: 0x8
	struct FString OnsetSound_1P; // Offset: 0x2b0 | Size: 0x10
	struct FString OnsetSound_3P; // Offset: 0x2c0 | Size: 0x10

	// Functions

	// Object: Function GC_SuperRadarChoose.GC_SuperRadarChoose_C.PlayPlayerEffect
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void PlayPlayerEffect();

	// Object: Function GC_SuperRadarChoose.GC_SuperRadarChoose_C.OnRemove
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0xc9) ]
	bool OnRemove(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters);

	// Object: Function GC_SuperRadarChoose.GC_SuperRadarChoose_C.OnActive
	// Flags: [Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0xc9) ]
	bool OnActive(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters);
};

