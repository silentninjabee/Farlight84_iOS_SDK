#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass GC_UnlimitedAmmo.GC_UnlimitedAmmo_C
// Inherited Bytes: 0x298 | Struct Size: 0x2b8
struct AGC_UnlimitedAmmo_C : AGameplayCueNotify_Actor {
	// Fields
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x298 | Size: 0x8
	struct UParticleSystemComponent* CharacterVFX; // Offset: 0x2a0 | Size: 0x8
	struct UUserWidget* ScreenVFX; // Offset: 0x2a8 | Size: 0x8
	int32_t CharacterEffectHandle; // Offset: 0x2b0 | Size: 0x4
	int32_t ScreenEffectHandle; // Offset: 0x2b4 | Size: 0x4

	// Functions

	// Object: Function GC_UnlimitedAmmo.GC_UnlimitedAmmo_C.OnRemove
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0xc9) ]
	bool OnRemove(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters);

	// Object: Function GC_UnlimitedAmmo.GC_UnlimitedAmmo_C.OnActive
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0xc9) ]
	bool OnActive(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters);
};

