#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass GC_Vehicle_Status_BrokenDanger.GC_Vehicle_Status_BrokenDanger_C
// Inherited Bytes: 0xc8 | Struct Size: 0xc8
struct UGC_Vehicle_Status_BrokenDanger_C : USolarVehicleGC_BrokenDanger {
};

