#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass GC_Vehicle_Weapon_Burning.GC_Vehicle_Weapon_Burning_C
// Inherited Bytes: 0x2f8 | Struct Size: 0x300
struct AGC_Vehicle_Weapon_Burning_C : ASolarVehicleGC_Burning {
	// Fields
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x2f8 | Size: 0x8
};

