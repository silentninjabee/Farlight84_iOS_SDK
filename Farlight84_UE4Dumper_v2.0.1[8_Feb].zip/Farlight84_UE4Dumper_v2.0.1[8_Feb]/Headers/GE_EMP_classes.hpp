#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass GE_EMP.GE_EMP_C
// Inherited Bytes: 0x848 | Struct Size: 0x848
struct UGE_EMP_C : UGameplayEffect {
};

