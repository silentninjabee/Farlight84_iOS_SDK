#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class GameplayAbilities.AbilitySystemBlueprintLibrary
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UAbilitySystemBlueprintLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.TargetDataHasOrigin
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x10121b350
	// Return & Params: [ Num(3) Size(0x2d) ]
	bool TargetDataHasOrigin(struct FGameplayAbilityTargetDataHandle& TargetData, int32_t Index);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.TargetDataHasHitResult
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x10121b680
	// Return & Params: [ Num(3) Size(0x2d) ]
	bool TargetDataHasHitResult(struct FGameplayAbilityTargetDataHandle& HitResult, int32_t Index);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.TargetDataHasEndPoint
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x10121b01c
	// Return & Params: [ Num(3) Size(0x2d) ]
	bool TargetDataHasEndPoint(struct FGameplayAbilityTargetDataHandle& TargetData, int32_t Index);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.TargetDataHasActor
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x10121b7fc
	// Return & Params: [ Num(3) Size(0x2d) ]
	bool TargetDataHasActor(struct FGameplayAbilityTargetDataHandle& TargetData, int32_t Index);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.SetStackCountToMax
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101214bd0
	// Return & Params: [ Num(2) Size(0x20) ]
	struct FGameplayEffectSpecHandle SetStackCountToMax(struct FGameplayEffectSpecHandle SpecHandle);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.SetStackCount
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101214dfc
	// Return & Params: [ Num(3) Size(0x28) ]
	struct FGameplayEffectSpecHandle SetStackCount(struct FGameplayEffectSpecHandle SpecHandle, int32_t StackCount);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.SetDuration
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1012160b4
	// Return & Params: [ Num(3) Size(0x28) ]
	struct FGameplayEffectSpecHandle SetDuration(struct FGameplayEffectSpecHandle SpecHandle, float Duration);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.SendGameplayEventToActor
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10121e768
	// Return & Params: [ Num(3) Size(0xc0) ]
	void SendGameplayEventToActor(struct AActor* Actor, struct FGameplayTag EventTag, struct FGameplayEventData Payload);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.NotEqual_GameplayAttributeGameplayAttribute
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x10121d87c
	// Return & Params: [ Num(3) Size(0x71) ]
	bool NotEqual_GameplayAttributeGameplayAttribute(struct FGameplayAttribute AttributeA, struct FGameplayAttribute AttributeB);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.MakeSpecHandle
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x10121c128
	// Return & Params: [ Num(5) Size(0x30) ]
	struct FGameplayEffectSpecHandle MakeSpecHandle(struct UGameplayEffect* InGameplayEffect, struct AActor* InInstigator, struct AActor* InEffectCauser, float InLevel);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.MakeGameplayCueParameters
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x101216fb8
	// Return & Params: [ Num(17) Size(0x178) ]
	struct FGameplayCueParameters MakeGameplayCueParameters(float NormalizedMagnitude, float RawMagnitude, struct FGameplayEffectContextHandle EffectContext, struct FGameplayTag MatchedTagName, struct FGameplayTag OriginalTag, struct FGameplayTagContainer AggregatedSourceTags, struct FGameplayTagContainer AggregatedTargetTags, struct FVector Location, struct FVector Normal, struct AActor* Instigator, struct AActor* EffectCauser, struct UObject* SourceObject, struct UPhysicalMaterial* PhysicalMaterial, int32_t GameplayEffectLevel, int32_t AbilityLevel, struct USceneComponent* TargetAttachComponent);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.MakeFilterHandle
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x10121c360
	// Return & Params: [ Num(3) Size(0x40) ]
	struct FGameplayTargetDataFilterHandle MakeFilterHandle(struct FGameplayTargetDataFilter Filter, struct AActor* FilterActor);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.IsValid
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x10121e690
	// Return & Params: [ Num(2) Size(0x39) ]
	bool IsValid(struct FGameplayAttribute Attribute);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.IsInstigatorLocallyControlledPlayer
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x101219718
	// Return & Params: [ Num(2) Size(0xc1) ]
	bool IsInstigatorLocallyControlledPlayer(struct FGameplayCueParameters Parameters);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.IsInstigatorLocallyControlled
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x101219978
	// Return & Params: [ Num(2) Size(0xc1) ]
	bool IsInstigatorLocallyControlled(struct FGameplayCueParameters Parameters);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.HasHitResult
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x101218cd4
	// Return & Params: [ Num(2) Size(0xc1) ]
	bool HasHitResult(struct FGameplayCueParameters Parameters);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetTargetDataOrigin
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x10121b198
	// Return & Params: [ Num(3) Size(0x60) ]
	struct FTransform GetTargetDataOrigin(struct FGameplayAbilityTargetDataHandle& TargetData, int32_t Index);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetTargetDataEndPointTransform
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x10121ace4
	// Return & Params: [ Num(3) Size(0x60) ]
	struct FTransform GetTargetDataEndPointTransform(struct FGameplayAbilityTargetDataHandle& TargetData, int32_t Index);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetTargetDataEndPoint
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x10121ae9c
	// Return & Params: [ Num(3) Size(0x38) ]
	struct FVector GetTargetDataEndPoint(struct FGameplayAbilityTargetDataHandle& TargetData, int32_t Index);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetOrigin
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x10121822c
	// Return & Params: [ Num(2) Size(0xcc) ]
	struct FVector GetOrigin(struct FGameplayCueParameters Parameters);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetModifiedAttributeMagnitude
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101214514
	// Return & Params: [ Num(3) Size(0x4c) ]
	float GetModifiedAttributeMagnitude(struct FGameplayEffectSpecHandle SpecHandle, struct FGameplayAttribute Attribute);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetInstigatorTransform
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x101218494
	// Return & Params: [ Num(2) Size(0xf0) ]
	struct FTransform GetInstigatorTransform(struct FGameplayCueParameters Parameters);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetInstigatorActor
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x101218730
	// Return & Params: [ Num(2) Size(0xc8) ]
	struct AActor* GetInstigatorActor(struct FGameplayCueParameters Parameters);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetHitResultFromTargetData
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x10121b4cc
	// Return & Params: [ Num(3) Size(0xb4) ]
	struct FHitResult GetHitResultFromTargetData(struct FGameplayAbilityTargetDataHandle& HitResult, int32_t Index);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetHitResult
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x101218f34
	// Return & Params: [ Num(2) Size(0x148) ]
	struct FHitResult GetHitResult(struct FGameplayCueParameters Parameters);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetGameplayCueEndLocationAndNormal
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x101217e88
	// Return & Params: [ Num(5) Size(0xe1) ]
	bool GetGameplayCueEndLocationAndNormal(struct AActor* TargetActor, struct FGameplayCueParameters Parameters, struct FVector& Location, struct FVector& Normal);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetGameplayCueDirection
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x101217b40
	// Return & Params: [ Num(4) Size(0xd5) ]
	bool GetGameplayCueDirection(struct AActor* TargetActor, struct FGameplayCueParameters Parameters, struct FVector& Direction);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetFloatAttributeFromAbilitySystemComponent
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x10121e390
	// Return & Params: [ Num(4) Size(0x48) ]
	float GetFloatAttributeFromAbilitySystemComponent(struct UAbilitySystemComponent* AbilitySystem, struct FGameplayAttribute Attribute, bool& bSuccessfullyFoundAttribute);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetFloatAttributeBaseFromAbilitySystemComponent
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x10121e090
	// Return & Params: [ Num(4) Size(0x48) ]
	float GetFloatAttributeBaseFromAbilitySystemComponent(struct UAbilitySystemComponent* AbilitySystemComponent, struct FGameplayAttribute Attribute, bool& bSuccessfullyFoundAttribute);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetFloatAttributeBase
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x10121e210
	// Return & Params: [ Num(4) Size(0x48) ]
	float GetFloatAttributeBase(struct AActor* Actor, struct FGameplayAttribute Attribute, bool& bSuccessfullyFoundAttribute);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetFloatAttribute
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x10121e510
	// Return & Params: [ Num(4) Size(0x48) ]
	float GetFloatAttribute(struct AActor* Actor, struct FGameplayAttribute Attribute, bool& bSuccessfullyFoundAttribute);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetEffectContext
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1012149a0
	// Return & Params: [ Num(2) Size(0x28) ]
	struct FGameplayEffectContextHandle GetEffectContext(struct FGameplayEffectSpecHandle SpecHandle);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetDataCountFromTargetData
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x10121cd54
	// Return & Params: [ Num(2) Size(0x2c) ]
	int32_t GetDataCountFromTargetData(struct FGameplayAbilityTargetDataHandle& TargetData);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetAllLinkedGameplayEffectSpecHandles
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x101214700
	// Return & Params: [ Num(2) Size(0x20) ]
	struct TArray<struct FGameplayEffectSpecHandle> GetAllLinkedGameplayEffectSpecHandles(struct FGameplayEffectSpecHandle SpecHandle);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetAllActorsFromTargetData
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x10121bb40
	// Return & Params: [ Num(2) Size(0x38) ]
	struct TArray<struct AActor*> GetAllActorsFromTargetData(struct FGameplayAbilityTargetDataHandle& TargetData);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetActorsFromTargetData
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x10121bcb0
	// Return & Params: [ Num(3) Size(0x40) ]
	struct TArray<struct AActor*> GetActorsFromTargetData(struct FGameplayAbilityTargetDataHandle& TargetData, int32_t Index);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetActorCount
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1012194b8
	// Return & Params: [ Num(2) Size(0xc4) ]
	int32_t GetActorCount(struct FGameplayCueParameters Parameters);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetActorByIndex
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1012191ec
	// Return & Params: [ Num(3) Size(0xd0) ]
	struct AActor* GetActorByIndex(struct FGameplayCueParameters Parameters, int32_t Index);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetActiveGameplayEffectTotalDuration
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10121426c
	// Return & Params: [ Num(2) Size(0xc) ]
	float GetActiveGameplayEffectTotalDuration(struct FActiveGameplayEffectHandle ActiveHandle);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetActiveGameplayEffectStartTime
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10121437c
	// Return & Params: [ Num(2) Size(0xc) ]
	float GetActiveGameplayEffectStartTime(struct FActiveGameplayEffectHandle ActiveHandle);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetActiveGameplayEffectStackLimitCount
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101214404
	// Return & Params: [ Num(2) Size(0xc) ]
	int32_t GetActiveGameplayEffectStackLimitCount(struct FActiveGameplayEffectHandle ActiveHandle);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetActiveGameplayEffectStackCount
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10121448c
	// Return & Params: [ Num(2) Size(0xc) ]
	int32_t GetActiveGameplayEffectStackCount(struct FActiveGameplayEffectHandle ActiveHandle);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetActiveGameplayEffectRemainingDuration
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101214194
	// Return & Params: [ Num(3) Size(0x14) ]
	float GetActiveGameplayEffectRemainingDuration(struct UObject* WorldContextObject, struct FActiveGameplayEffectHandle ActiveHandle);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetActiveGameplayEffectExpectedEndTime
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1012142f4
	// Return & Params: [ Num(2) Size(0xc) ]
	float GetActiveGameplayEffectExpectedEndTime(struct FActiveGameplayEffectHandle ActiveHandle);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetActiveGameplayEffectDebugString
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x1012140c8
	// Return & Params: [ Num(2) Size(0x18) ]
	struct FString GetActiveGameplayEffectDebugString(struct FActiveGameplayEffectHandle ActiveHandle);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.GetAbilitySystemComponent
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x10121e9bc
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UAbilitySystemComponent* GetAbilitySystemComponent(struct AActor* Actor);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.ForwardGameplayCueToTarget
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101218990
	// Return & Params: [ Num(3) Size(0xd8) ]
	void ForwardGameplayCueToTarget(struct TScriptInterface<IGameplayCueInterface> TargetCueInterface, enum class EGameplayCueEvent EventType, struct FGameplayCueParameters Parameters);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.FilterTargetData
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x10121c52c
	// Return & Params: [ Num(3) Size(0x60) ]
	struct FGameplayAbilityTargetDataHandle FilterTargetData(struct FGameplayAbilityTargetDataHandle& TargetDataHandle, struct FGameplayTargetDataFilterHandle ActorFilterClass);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.EvaluateAttributeValueWithTagsAndBase
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x10121db74
	// Return & Params: [ Num(7) Size(0x8c) ]
	float EvaluateAttributeValueWithTagsAndBase(struct UAbilitySystemComponent* AbilitySystem, struct FGameplayAttribute Attribute, struct FGameplayTagContainer& SourceTags, struct FGameplayTagContainer& TargetTags, float BaseValue, bool& bSuccess);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.EvaluateAttributeValueWithTags
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x10121de28
	// Return & Params: [ Num(6) Size(0x88) ]
	float EvaluateAttributeValueWithTags(struct UAbilitySystemComponent* AbilitySystem, struct FGameplayAttribute Attribute, struct FGameplayTagContainer& SourceTags, struct FGameplayTagContainer& TargetTags, bool& bSuccess);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.EqualEqual_GameplayAttributeGameplayAttribute
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x10121d9f8
	// Return & Params: [ Num(3) Size(0x71) ]
	bool EqualEqual_GameplayAttributeGameplayAttribute(struct FGameplayAttribute AttributeA, struct FGameplayAttribute AttributeB);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.EffectContextSetOrigin
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x10121a198
	// Return & Params: [ Num(2) Size(0x24) ]
	void EffectContextSetOrigin(struct FGameplayEffectContextHandle EffectContext, struct FVector Origin);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.EffectContextIsValid
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x10121ab74
	// Return & Params: [ Num(2) Size(0x19) ]
	bool EffectContextIsValid(struct FGameplayEffectContextHandle EffectContext);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.EffectContextIsInstigatorLocallyControlled
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x10121aa04
	// Return & Params: [ Num(2) Size(0x19) ]
	bool EffectContextIsInstigatorLocallyControlled(struct FGameplayEffectContextHandle EffectContext);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.EffectContextHasHitResult
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x10121a6fc
	// Return & Params: [ Num(2) Size(0x19) ]
	bool EffectContextHasHitResult(struct FGameplayEffectContextHandle EffectContext);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.EffectContextGetSourceObject
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x101219bd8
	// Return & Params: [ Num(2) Size(0x20) ]
	struct UObject* EffectContextGetSourceObject(struct FGameplayEffectContextHandle EffectContext);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.EffectContextGetOriginalInstigatorActor
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x101219eb8
	// Return & Params: [ Num(2) Size(0x20) ]
	struct AActor* EffectContextGetOriginalInstigatorActor(struct FGameplayEffectContextHandle EffectContext);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.EffectContextGetOrigin
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x10121a348
	// Return & Params: [ Num(2) Size(0x24) ]
	struct FVector EffectContextGetOrigin(struct FGameplayEffectContextHandle EffectContext);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.EffectContextGetInstigatorActor
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x10121a028
	// Return & Params: [ Num(2) Size(0x20) ]
	struct AActor* EffectContextGetInstigatorActor(struct FGameplayEffectContextHandle EffectContext);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.EffectContextGetHitResult
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x10121a86c
	// Return & Params: [ Num(2) Size(0xa0) ]
	struct FHitResult EffectContextGetHitResult(struct FGameplayEffectContextHandle EffectContext);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.EffectContextGetEffectCauser
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x101219d48
	// Return & Params: [ Num(2) Size(0x20) ]
	struct AActor* EffectContextGetEffectCauser(struct FGameplayEffectContextHandle EffectContext);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.EffectContextAddHitResult
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10121a4bc
	// Return & Params: [ Num(3) Size(0xa1) ]
	void EffectContextAddHitResult(struct FGameplayEffectContextHandle EffectContext, struct FHitResult HitResult, bool bReset);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.DoesTargetDataContainActor
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x10121b978
	// Return & Params: [ Num(4) Size(0x39) ]
	bool DoesTargetDataContainActor(struct FGameplayAbilityTargetDataHandle& TargetData, int32_t Index, struct AActor* Actor);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.DoesGameplayCueMeetTagRequirements
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x10121779c
	// Return & Params: [ Num(4) Size(0x161) ]
	bool DoesGameplayCueMeetTagRequirements(struct FGameplayCueParameters Parameters, struct FGameplayTagRequirements& SourceTagReqs, struct FGameplayTagRequirements& TargetTagReqs);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.CloneSpecHandle
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x10121be64
	// Return & Params: [ Num(4) Size(0x30) ]
	struct FGameplayEffectSpecHandle CloneSpecHandle(struct AActor* InNewInstigator, struct AActor* InEffectCauser, struct FGameplayEffectSpecHandle GameplayEffectSpecHandle_Clone);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.BreakGameplayCueParameters
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x1012168b4
	// Return & Params: [ Num(17) Size(0x178) ]
	void BreakGameplayCueParameters(struct FGameplayCueParameters& Parameters, float& NormalizedMagnitude, float& RawMagnitude, struct FGameplayEffectContextHandle& EffectContext, struct FGameplayTag& MatchedTagName, struct FGameplayTag& OriginalTag, struct FGameplayTagContainer& AggregatedSourceTags, struct FGameplayTagContainer& AggregatedTargetTags, struct FVector& Location, struct FVector& Normal, struct AActor*& Instigator, struct AActor*& EffectCauser, struct UObject*& SourceObject, struct UPhysicalMaterial*& PhysicalMaterial, int32_t& GameplayEffectLevel, int32_t& AbilityLevel, struct USceneComponent*& TargetAttachComponent);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.AssignTagSetByCallerMagnitude
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10121632c
	// Return & Params: [ Num(4) Size(0x30) ]
	struct FGameplayEffectSpecHandle AssignTagSetByCallerMagnitude(struct FGameplayEffectSpecHandle SpecHandle, struct FGameplayTag DataTag, float Magnitude);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.AssignSetByCallerMagnitude
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1012165f0
	// Return & Params: [ Num(4) Size(0x30) ]
	struct FGameplayEffectSpecHandle AssignSetByCallerMagnitude(struct FGameplayEffectSpecHandle SpecHandle, struct FName DataName, float Magnitude);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.AppendTargetDataHandle
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x10121d3a4
	// Return & Params: [ Num(3) Size(0x78) ]
	struct FGameplayAbilityTargetDataHandle AppendTargetDataHandle(struct FGameplayAbilityTargetDataHandle TargetHandle, struct FGameplayAbilityTargetDataHandle& HandleToAdd);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.AddLinkedGameplayEffectSpec
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1012152ec
	// Return & Params: [ Num(3) Size(0x30) ]
	struct FGameplayEffectSpecHandle AddLinkedGameplayEffectSpec(struct FGameplayEffectSpecHandle SpecHandle, struct FGameplayEffectSpecHandle LinkedGameplayEffectSpec);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.AddLinkedGameplayEffect
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101215074
	// Return & Params: [ Num(3) Size(0x28) ]
	struct FGameplayEffectSpecHandle AddLinkedGameplayEffect(struct FGameplayEffectSpecHandle SpecHandle, struct UGameplayEffect* LinkedGameplayEffect);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.AddGrantedTags
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101215b78
	// Return & Params: [ Num(3) Size(0x40) ]
	struct FGameplayEffectSpecHandle AddGrantedTags(struct FGameplayEffectSpecHandle SpecHandle, struct FGameplayTagContainer NewGameplayTags);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.AddGrantedTag
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101215e3c
	// Return & Params: [ Num(3) Size(0x28) ]
	struct FGameplayEffectSpecHandle AddGrantedTag(struct FGameplayEffectSpecHandle SpecHandle, struct FGameplayTag NewGameplayTag);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.AddAssetTags
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10121563c
	// Return & Params: [ Num(3) Size(0x40) ]
	struct FGameplayEffectSpecHandle AddAssetTags(struct FGameplayEffectSpecHandle SpecHandle, struct FGameplayTagContainer NewGameplayTags);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.AddAssetTag
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101215900
	// Return & Params: [ Num(3) Size(0x28) ]
	struct FGameplayEffectSpecHandle AddAssetTag(struct FGameplayEffectSpecHandle SpecHandle, struct FGameplayTag NewGameplayTag);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.AbilityTargetDataFromLocations
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x10121d0b4
	// Return & Params: [ Num(3) Size(0xe8) ]
	struct FGameplayAbilityTargetDataHandle AbilityTargetDataFromLocations(struct FGameplayAbilityTargetingLocationInfo& SourceLocation, struct FGameplayAbilityTargetingLocationInfo& TargetLocation);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.AbilityTargetDataFromHitResult
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x10121ce88
	// Return & Params: [ Num(2) Size(0xb0) ]
	struct FGameplayAbilityTargetDataHandle AbilityTargetDataFromHitResult(struct FHitResult& HitResult);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.AbilityTargetDataFromActorArray
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x10121c8ec
	// Return & Params: [ Num(3) Size(0x40) ]
	struct FGameplayAbilityTargetDataHandle AbilityTargetDataFromActorArray(struct TArray<struct AActor*>& ActorArray, bool OneTargetPerHandle);

	// Object: Function GameplayAbilities.AbilitySystemBlueprintLibrary.AbilityTargetDataFromActor
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x10121cb48
	// Return & Params: [ Num(2) Size(0x30) ]
	struct FGameplayAbilityTargetDataHandle AbilityTargetDataFromActor(struct AActor* Actor);
};

// Object: Class GameplayAbilities.AbilitySystemComponent
// Inherited Bytes: 0x120 | Struct Size: 0x1300
struct UAbilitySystemComponent : UGameplayTasksComponent {
	// Fields
	char pad_0x120[0x10]; // Offset: 0x120 | Size: 0x10
	struct TArray<struct FAttributeDefaults> DefaultStartingData; // Offset: 0x130 | Size: 0x10
	struct TArray<struct UAttributeSet*> SpawnedAttributes; // Offset: 0x140 | Size: 0x10
	struct FName AffectedAnimInstanceTag; // Offset: 0x150 | Size: 0x8
	char pad_0x158[0x1a0]; // Offset: 0x158 | Size: 0x1a0
	float OutgoingDuration; // Offset: 0x2f8 | Size: 0x4
	float IncomingDuration; // Offset: 0x2fc | Size: 0x4
	char pad_0x300[0x20]; // Offset: 0x300 | Size: 0x20
	struct TArray<struct FString> ClientDebugStrings; // Offset: 0x320 | Size: 0x10
	struct TArray<struct FString> ServerDebugStrings; // Offset: 0x330 | Size: 0x10
	char pad_0x340[0x60]; // Offset: 0x340 | Size: 0x60
	bool UserAbilityActivationInhibited; // Offset: 0x3a0 | Size: 0x1
	bool ReplicationProxyEnabled; // Offset: 0x3a1 | Size: 0x1
	bool bSuppressGrantAbility; // Offset: 0x3a2 | Size: 0x1
	bool bSuppressGameplayCues; // Offset: 0x3a3 | Size: 0x1
	char pad_0x3A4[0x4]; // Offset: 0x3a4 | Size: 0x4
	struct TArray<struct AGameplayAbilityTargetActor*> SpawnedTargetActors; // Offset: 0x3a8 | Size: 0x10
	char pad_0x3B8[0x28]; // Offset: 0x3b8 | Size: 0x28
	struct AActor* OwnerActor; // Offset: 0x3e0 | Size: 0x8
	struct AActor* AvatarActor; // Offset: 0x3e8 | Size: 0x8
	char pad_0x3F0[0x10]; // Offset: 0x3f0 | Size: 0x10
	struct FGameplayAbilitySpecContainer ActivatableAbilities; // Offset: 0x400 | Size: 0x120
	char pad_0x520[0x30]; // Offset: 0x520 | Size: 0x30
	struct TArray<struct UGameplayAbility*> AllReplicatedInstancedAbilities; // Offset: 0x550 | Size: 0x10
	char pad_0x560[0x1d0]; // Offset: 0x560 | Size: 0x1d0
	struct FGameplayAbilityRepAnimMontage RepAnimMontageInfo; // Offset: 0x730 | Size: 0x38
	bool bCachedIsNetSimulated; // Offset: 0x768 | Size: 0x1
	bool bPendingMontageRep; // Offset: 0x769 | Size: 0x1
	char pad_0x76A[0x6]; // Offset: 0x76a | Size: 0x6
	struct FGameplayAbilityLocalAnimMontage LocalAnimMontageInfo; // Offset: 0x770 | Size: 0x30
	char pad_0x7A0[0xa0]; // Offset: 0x7a0 | Size: 0xa0
	struct FActiveGameplayEffectsContainer ActiveGameplayEffects; // Offset: 0x840 | Size: 0x488
	struct FActiveGameplayCueContainer ActiveGameplayCues; // Offset: 0xcc8 | Size: 0x128
	struct FActiveGameplayCueContainer MinimalReplicationGameplayCues; // Offset: 0xdf0 | Size: 0x128
	char pad_0xF18[0x128]; // Offset: 0xf18 | Size: 0x128
	struct TArray<char> BlockedAbilityBindings; // Offset: 0x1040 | Size: 0x10
	char pad_0x1050[0x128]; // Offset: 0x1050 | Size: 0x128
	struct FMinimalReplicationTagCountMap MinimalReplicationTags; // Offset: 0x1178 | Size: 0x60
	char pad_0x11D8[0x10]; // Offset: 0x11d8 | Size: 0x10
	struct FReplicatedPredictionKeyMap ReplicatedPredictionKeyMap; // Offset: 0x11e8 | Size: 0x118

	// Functions

	// Object: Function GameplayAbilities.AbilitySystemComponent.TryActivateAbilityByClass
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1012230fc
	// Return & Params: [ Num(3) Size(0xa) ]
	bool TryActivateAbilityByClass(struct UGameplayAbility* InAbilityToActivate, bool bAllowRemoteActivation);

	// Object: Function GameplayAbilities.AbilitySystemComponent.TryActivateAbilitiesByTag
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1012231e0
	// Return & Params: [ Num(3) Size(0x22) ]
	bool TryActivateAbilitiesByTag(struct FGameplayTagContainer& GameplayTagContainer, bool bAllowRemoteActivation);

	// Object: Function GameplayAbilities.AbilitySystemComponent.TargetConfirm
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x101222948
	// Return & Params: [ Num(0) Size(0x0) ]
	void TargetConfirm();

	// Object: Function GameplayAbilities.AbilitySystemComponent.TargetCancel
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x10122292c
	// Return & Params: [ Num(0) Size(0x0) ]
	void TargetCancel();

	// Object: Function GameplayAbilities.AbilitySystemComponent.SetUserAbilityActivationInhibited
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x101222964
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetUserAbilityActivationInhibited(bool NewInhibit);

	// Object: Function GameplayAbilities.AbilitySystemComponent.SetActiveGameplayEffectLevelUsingQuery
	// Flags: [BlueprintAuthorityOnly|Native|Public|BlueprintCallable]
	// Offset: 0x1012257a4
	// Return & Params: [ Num(2) Size(0x154) ]
	void SetActiveGameplayEffectLevelUsingQuery(struct FGameplayEffectQuery Query, int32_t NewLevel);

	// Object: Function GameplayAbilities.AbilitySystemComponent.SetActiveGameplayEffectLevel
	// Flags: [BlueprintAuthorityOnly|Native|Public|BlueprintCallable]
	// Offset: 0x1012258a0
	// Return & Params: [ Num(2) Size(0xc) ]
	void SetActiveGameplayEffectLevel(struct FActiveGameplayEffectHandle ActiveHandle, int32_t NewLevel);

	// Object: Function GameplayAbilities.AbilitySystemComponent.ServerTryActivateAbilityWithEventData
	// Flags: [Net|NetReliableNative|Event|Protected|NetServer|NetValidate]
	// Offset: 0x101221718
	// Return & Params: [ Num(4) Size(0xd0) ]
	void ServerTryActivateAbilityWithEventData(struct FGameplayAbilitySpecHandle AbilityToActivate, bool InputPressed, struct FPredictionKey PredictionKey, struct FGameplayEventData TriggerEventData);

	// Object: Function GameplayAbilities.AbilitySystemComponent.ServerTryActivateAbility
	// Flags: [Net|NetReliableNative|Event|Protected|NetServer|NetValidate]
	// Offset: 0x101221b4c
	// Return & Params: [ Num(3) Size(0x20) ]
	void ServerTryActivateAbility(struct FGameplayAbilitySpecHandle AbilityToActivate, bool InputPressed, struct FPredictionKey PredictionKey);

	// Object: Function GameplayAbilities.AbilitySystemComponent.ServerSetReplicatedTargetDataCancelled
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	// Offset: 0x101221e7c
	// Return & Params: [ Num(3) Size(0x38) ]
	void ServerSetReplicatedTargetDataCancelled(struct FGameplayAbilitySpecHandle AbilityHandle, struct FPredictionKey AbilityOriginalPredictionKey, struct FPredictionKey CurrentPredictionKey);

	// Object: Function GameplayAbilities.AbilitySystemComponent.ServerSetReplicatedTargetData
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	// Offset: 0x10122203c
	// Return & Params: [ Num(5) Size(0x68) ]
	void ServerSetReplicatedTargetData(struct FGameplayAbilitySpecHandle AbilityHandle, struct FPredictionKey AbilityOriginalPredictionKey, struct FGameplayAbilityTargetDataHandle ReplicatedTargetDataHandle, struct FGameplayTag ApplicationTag, struct FPredictionKey CurrentPredictionKey);

	// Object: Function GameplayAbilities.AbilitySystemComponent.ServerSetReplicatedEventWithPayload
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	// Offset: 0x10122248c
	// Return & Params: [ Num(5) Size(0x44) ]
	void ServerSetReplicatedEventWithPayload(enum class EAbilityGenericReplicatedEvent EventType, struct FGameplayAbilitySpecHandle AbilityHandle, struct FPredictionKey AbilityOriginalPredictionKey, struct FPredictionKey CurrentPredictionKey, struct FVector_NetQuantize100 VectorPayload);

	// Object: Function GameplayAbilities.AbilitySystemComponent.ServerSetReplicatedEvent
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	// Offset: 0x101222704
	// Return & Params: [ Num(4) Size(0x38) ]
	void ServerSetReplicatedEvent(enum class EAbilityGenericReplicatedEvent EventType, struct FGameplayAbilitySpecHandle AbilityHandle, struct FPredictionKey AbilityOriginalPredictionKey, struct FPredictionKey CurrentPredictionKey);

	// Object: Function GameplayAbilities.AbilitySystemComponent.ServerSetInputReleased
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	// Offset: 0x101221cfc
	// Return & Params: [ Num(1) Size(0x4) ]
	void ServerSetInputReleased(struct FGameplayAbilitySpecHandle AbilityHandle);

	// Object: Function GameplayAbilities.AbilitySystemComponent.ServerSetInputPressed
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	// Offset: 0x101221dbc
	// Return & Params: [ Num(1) Size(0x4) ]
	void ServerSetInputPressed(struct FGameplayAbilitySpecHandle AbilityHandle);

	// Object: Function GameplayAbilities.AbilitySystemComponent.ServerPrintDebug_RequestWithStrings
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	// Offset: 0x101222fa8
	// Return & Params: [ Num(1) Size(0x10) ]
	void ServerPrintDebug_RequestWithStrings(struct TArray<struct FString> Strings);

	// Object: Function GameplayAbilities.AbilitySystemComponent.ServerPrintDebug_Request
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	// Offset: 0x1012230a0
	// Return & Params: [ Num(0) Size(0x0) ]
	void ServerPrintDebug_Request();

	// Object: Function GameplayAbilities.AbilitySystemComponent.ServerEndAbility
	// Flags: [Net|NetReliableNative|Event|Protected|NetServer|NetValidate]
	// Offset: 0x1012214f0
	// Return & Params: [ Num(3) Size(0x40) ]
	void ServerEndAbility(struct FGameplayAbilitySpecHandle AbilityToEnd, struct FGameplayAbilityActivationInfo ActivationInfo, struct FPredictionKey PredictionKey);

	// Object: Function GameplayAbilities.AbilitySystemComponent.ServerCurrentMontageSetPlayRate
	// Flags: [Net|NetReliableNative|Event|Protected|NetServer|NetValidate]
	// Offset: 0x1012209d8
	// Return & Params: [ Num(2) Size(0xc) ]
	void ServerCurrentMontageSetPlayRate(struct UAnimMontage* ClientAnimMontage, float InPlayRate);

	// Object: Function GameplayAbilities.AbilitySystemComponent.ServerCurrentMontageSetNextSectionName
	// Flags: [Net|NetReliableNative|Event|Protected|NetServer|NetValidate]
	// Offset: 0x101220be8
	// Return & Params: [ Num(4) Size(0x1c) ]
	void ServerCurrentMontageSetNextSectionName(struct UAnimMontage* ClientAnimMontage, float ClientPosition, struct FName SectionName, struct FName NextSectionName);

	// Object: Function GameplayAbilities.AbilitySystemComponent.ServerCurrentMontageJumpToSectionName
	// Flags: [Net|NetReliableNative|Event|Protected|NetServer|NetValidate]
	// Offset: 0x101220ae4
	// Return & Params: [ Num(2) Size(0x10) ]
	void ServerCurrentMontageJumpToSectionName(struct UAnimMontage* ClientAnimMontage, struct FName SectionName);

	// Object: Function GameplayAbilities.AbilitySystemComponent.ServerCancelAbility
	// Flags: [Net|NetReliableNative|Event|Protected|NetServer|NetValidate]
	// Offset: 0x1012212e4
	// Return & Params: [ Num(2) Size(0x28) ]
	void ServerCancelAbility(struct FGameplayAbilitySpecHandle AbilityToCancel, struct FGameplayAbilityActivationInfo ActivationInfo);

	// Object: Function GameplayAbilities.AbilitySystemComponent.ServerAbilityRPCBatch
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	// Offset: 0x101222a28
	// Return & Params: [ Num(1) Size(0x50) ]
	void ServerAbilityRPCBatch(struct FServerAbilityRPCBatch BatchInfo);

	// Object: Function GameplayAbilities.AbilitySystemComponent.RemoveActiveGameplayEffectBySourceEffect
	// Flags: [BlueprintAuthorityOnly|Native|Public|BlueprintCallable]
	// Offset: 0x101225eac
	// Return & Params: [ Num(3) Size(0x14) ]
	void RemoveActiveGameplayEffectBySourceEffect(struct UGameplayEffect* GameplayEffect, struct UAbilitySystemComponent* InstigatorAbilitySystemComponent, int32_t StacksToRemove);

	// Object: Function GameplayAbilities.AbilitySystemComponent.RemoveActiveGameplayEffect
	// Flags: [BlueprintAuthorityOnly|Native|Public|BlueprintCallable]
	// Offset: 0x101225fc8
	// Return & Params: [ Num(3) Size(0xd) ]
	bool RemoveActiveGameplayEffect(struct FActiveGameplayEffectHandle Handle, int32_t StacksToRemove);

	// Object: Function GameplayAbilities.AbilitySystemComponent.RemoveActiveEffectsWithTags
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101224f44
	// Return & Params: [ Num(2) Size(0x24) ]
	int32_t RemoveActiveEffectsWithTags(struct FGameplayTagContainer Tags);

	// Object: Function GameplayAbilities.AbilitySystemComponent.RemoveActiveEffectsWithSourceTags
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101224e6c
	// Return & Params: [ Num(2) Size(0x24) ]
	int32_t RemoveActiveEffectsWithSourceTags(struct FGameplayTagContainer Tags);

	// Object: Function GameplayAbilities.AbilitySystemComponent.RemoveActiveEffectsWithGrantedTags
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101224cbc
	// Return & Params: [ Num(2) Size(0x24) ]
	int32_t RemoveActiveEffectsWithGrantedTags(struct FGameplayTagContainer Tags);

	// Object: Function GameplayAbilities.AbilitySystemComponent.RemoveActiveEffectsWithAppliedTags
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101224d94
	// Return & Params: [ Num(2) Size(0x24) ]
	int32_t RemoveActiveEffectsWithAppliedTags(struct FGameplayTagContainer Tags);

	// Object: Function GameplayAbilities.AbilitySystemComponent.OnRep_ServerDebugString
	// Flags: [Native|Public]
	// Offset: 0x101222e5c
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnRep_ServerDebugString();

	// Object: Function GameplayAbilities.AbilitySystemComponent.OnRep_ReplicatedAnimMontage
	// Flags: [Native|Protected]
	// Offset: 0x101220d8c
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnRep_ReplicatedAnimMontage();

	// Object: Function GameplayAbilities.AbilitySystemComponent.OnRep_OwningActor
	// Flags: [Final|Native|Public]
	// Offset: 0x101222918
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnRep_OwningActor();

	// Object: Function GameplayAbilities.AbilitySystemComponent.OnRep_ClientDebugString
	// Flags: [Native|Public]
	// Offset: 0x101222e78
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnRep_ClientDebugString();

	// Object: Function GameplayAbilities.AbilitySystemComponent.OnRep_ActivateAbilities
	// Flags: [Native|Protected]
	// Offset: 0x101221ce0
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnRep_ActivateAbilities();

	// Object: Function GameplayAbilities.AbilitySystemComponent.NetMulticast_InvokeGameplayCuesExecuted_WithParams
	// Flags: [Net|Native|Event|NetMulticast|Public]
	// Offset: 0x101223ff4
	// Return & Params: [ Num(3) Size(0xf8) ]
	void NetMulticast_InvokeGameplayCuesExecuted_WithParams(struct FGameplayTagContainer GameplayCueTags, struct FPredictionKey PredictionKey, struct FGameplayCueParameters GameplayCueParameters);

	// Object: Function GameplayAbilities.AbilitySystemComponent.NetMulticast_InvokeGameplayCuesExecuted
	// Flags: [Net|Native|Event|NetMulticast|Public]
	// Offset: 0x101224644
	// Return & Params: [ Num(3) Size(0x50) ]
	void NetMulticast_InvokeGameplayCuesExecuted(struct FGameplayTagContainer GameplayCueTags, struct FPredictionKey PredictionKey, struct FGameplayEffectContextHandle EffectContext);

	// Object: Function GameplayAbilities.AbilitySystemComponent.NetMulticast_InvokeGameplayCuesAddedAndWhileActive_WithParams
	// Flags: [Net|Native|Event|NetMulticast|Public]
	// Offset: 0x10122337c
	// Return & Params: [ Num(3) Size(0xf8) ]
	void NetMulticast_InvokeGameplayCuesAddedAndWhileActive_WithParams(struct FGameplayTagContainer GameplayCueTags, struct FPredictionKey PredictionKey, struct FGameplayCueParameters GameplayCueParameters);

	// Object: Function GameplayAbilities.AbilitySystemComponent.NetMulticast_InvokeGameplayCueExecuted_WithParams
	// Flags: [Net|Native|Event|NetMulticast|Public]
	// Offset: 0x10122433c
	// Return & Params: [ Num(3) Size(0xe0) ]
	void NetMulticast_InvokeGameplayCueExecuted_WithParams(struct FGameplayTag GameplayCueTag, struct FPredictionKey PredictionKey, struct FGameplayCueParameters GameplayCueParameters);

	// Object: Function GameplayAbilities.AbilitySystemComponent.NetMulticast_InvokeGameplayCueExecuted_FromSpec
	// Flags: [Net|Native|Event|NetMulticast|Public]
	// Offset: 0x101224ad4
	// Return & Params: [ Num(2) Size(0x90) ]
	void NetMulticast_InvokeGameplayCueExecuted_FromSpec(struct FGameplayEffectSpecForRPC Spec, struct FPredictionKey PredictionKey);

	// Object: Function GameplayAbilities.AbilitySystemComponent.NetMulticast_InvokeGameplayCueExecuted
	// Flags: [Net|Native|Event|NetMulticast|Public]
	// Offset: 0x1012248b4
	// Return & Params: [ Num(3) Size(0x38) ]
	void NetMulticast_InvokeGameplayCueExecuted(struct FGameplayTag GameplayCueTag, struct FPredictionKey PredictionKey, struct FGameplayEffectContextHandle EffectContext);

	// Object: Function GameplayAbilities.AbilitySystemComponent.NetMulticast_InvokeGameplayCueAddedAndWhileActive_WithParams
	// Flags: [Net|Native|Event|NetMulticast|Public]
	// Offset: 0x1012236c4
	// Return & Params: [ Num(3) Size(0xe0) ]
	void NetMulticast_InvokeGameplayCueAddedAndWhileActive_WithParams(struct FGameplayTag GameplayCueTag, struct FPredictionKey PredictionKey, struct FGameplayCueParameters GameplayCueParameters);

	// Object: Function GameplayAbilities.AbilitySystemComponent.NetMulticast_InvokeGameplayCueAddedAndWhileActive_FromSpec
	// Flags: [Net|Native|Event|NetMulticast|Public]
	// Offset: 0x1012239cc
	// Return & Params: [ Num(2) Size(0x90) ]
	void NetMulticast_InvokeGameplayCueAddedAndWhileActive_FromSpec(struct FGameplayEffectSpecForRPC Spec, struct FPredictionKey PredictionKey);

	// Object: Function GameplayAbilities.AbilitySystemComponent.NetMulticast_InvokeGameplayCueAdded_WithParams
	// Flags: [Net|Native|Event|NetMulticast|Public]
	// Offset: 0x101223acc
	// Return & Params: [ Num(3) Size(0xe0) ]
	void NetMulticast_InvokeGameplayCueAdded_WithParams(struct FGameplayTag GameplayCueTag, struct FPredictionKey PredictionKey, struct FGameplayCueParameters Parameters);

	// Object: Function GameplayAbilities.AbilitySystemComponent.NetMulticast_InvokeGameplayCueAdded
	// Flags: [Net|Native|Event|NetMulticast|Public]
	// Offset: 0x101223dd4
	// Return & Params: [ Num(3) Size(0x38) ]
	void NetMulticast_InvokeGameplayCueAdded(struct FGameplayTag GameplayCueTag, struct FPredictionKey PredictionKey, struct FGameplayEffectContextHandle EffectContext);

	// Object: Function GameplayAbilities.AbilitySystemComponent.MakeOutgoingSpec
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x101225bc8
	// Return & Params: [ Num(4) Size(0x38) ]
	struct FGameplayEffectSpecHandle MakeOutgoingSpec(struct UGameplayEffect* GameplayEffectClass, float Level, struct FGameplayEffectContextHandle Context);

	// Object: Function GameplayAbilities.AbilitySystemComponent.MakeEffectContext
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x101225aa8
	// Return & Params: [ Num(1) Size(0x18) ]
	struct FGameplayEffectContextHandle MakeEffectContext();

	// Object: Function GameplayAbilities.AbilitySystemComponent.K2_InitStats
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1012262f8
	// Return & Params: [ Num(2) Size(0x10) ]
	void K2_InitStats(struct UAttributeSet* Attributes, struct UDataTable* DataTable);

	// Object: Function GameplayAbilities.AbilitySystemComponent.IsGameplayCueActive
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1012232e4
	// Return & Params: [ Num(2) Size(0x9) ]
	bool IsGameplayCueActive(struct FGameplayTag GameplayCueTag);

	// Object: Function GameplayAbilities.AbilitySystemComponent.GetUserAbilityActivationInhibited
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1012229f4
	// Return & Params: [ Num(1) Size(0x1) ]
	bool GetUserAbilityActivationInhibited();

	// Object: Function GameplayAbilities.AbilitySystemComponent.GetGameplayEffectMagnitude
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x101225670
	// Return & Params: [ Num(3) Size(0x44) ]
	float GetGameplayEffectMagnitude(struct FActiveGameplayEffectHandle Handle, struct FGameplayAttribute Attribute);

	// Object: Function GameplayAbilities.AbilitySystemComponent.GetGameplayEffectCount
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x10122597c
	// Return & Params: [ Num(4) Size(0x18) ]
	int32_t GetGameplayEffectCount(struct UGameplayEffect* SourceGameplayEffect, struct UAbilitySystemComponent* OptionalInstigatorFilterComponent, bool bEnforceOnGoingCheck);

	// Object: Function GameplayAbilities.AbilitySystemComponent.GetActiveEffectsWithAllTags
	// Flags: [Final|Native|Public|BlueprintCallable|Const]
	// Offset: 0x10122501c
	// Return & Params: [ Num(2) Size(0x30) ]
	struct TArray<struct FActiveGameplayEffectHandle> GetActiveEffectsWithAllTags(struct FGameplayTagContainer Tags);

	// Object: Function GameplayAbilities.AbilitySystemComponent.GetActiveEffects
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|Const]
	// Offset: 0x101225130
	// Return & Params: [ Num(2) Size(0x160) ]
	struct TArray<struct FActiveGameplayEffectHandle> GetActiveEffects(struct FGameplayEffectQuery& Query);

	// Object: Function GameplayAbilities.AbilitySystemComponent.ClientTryActivateAbility
	// Flags: [Net|NetReliableNative|Event|Protected|NetClient]
	// Offset: 0x10122168c
	// Return & Params: [ Num(1) Size(0x4) ]
	void ClientTryActivateAbility(struct FGameplayAbilitySpecHandle AbilityToActivate);

	// Object: Function GameplayAbilities.AbilitySystemComponent.ClientSetReplicatedEvent
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	// Offset: 0x101222344
	// Return & Params: [ Num(3) Size(0x20) ]
	void ClientSetReplicatedEvent(enum class EAbilityGenericReplicatedEvent EventType, struct FGameplayAbilitySpecHandle AbilityHandle, struct FPredictionKey AbilityOriginalPredictionKey);

	// Object: Function GameplayAbilities.AbilitySystemComponent.ClientPrintDebug_Response
	// Flags: [Net|NetReliableNative|Event|Public|NetClient]
	// Offset: 0x101222e94
	// Return & Params: [ Num(2) Size(0x14) ]
	void ClientPrintDebug_Response(struct TArray<struct FString> Strings, int32_t GameFlags);

	// Object: Function GameplayAbilities.AbilitySystemComponent.ClientEndAbility
	// Flags: [Net|NetReliableNative|Event|Protected|NetClient]
	// Offset: 0x10122140c
	// Return & Params: [ Num(2) Size(0x28) ]
	void ClientEndAbility(struct FGameplayAbilitySpecHandle AbilityToEnd, struct FGameplayAbilityActivationInfo ActivationInfo);

	// Object: Function GameplayAbilities.AbilitySystemComponent.ClientCancelAbility
	// Flags: [Net|NetReliableNative|Event|Protected|NetClient]
	// Offset: 0x101221200
	// Return & Params: [ Num(2) Size(0x28) ]
	void ClientCancelAbility(struct FGameplayAbilitySpecHandle AbilityToCancel, struct FGameplayAbilityActivationInfo ActivationInfo);

	// Object: Function GameplayAbilities.AbilitySystemComponent.ClientActivateAbilitySucceedWithEventData
	// Flags: [Net|NetReliableNative|Event|Protected|NetClient]
	// Offset: 0x101220da8
	// Return & Params: [ Num(3) Size(0xd0) ]
	void ClientActivateAbilitySucceedWithEventData(struct FGameplayAbilitySpecHandle AbilityToActivate, struct FPredictionKey PredictionKey, struct FGameplayEventData TriggerEventData);

	// Object: Function GameplayAbilities.AbilitySystemComponent.ClientActivateAbilitySucceed
	// Flags: [Net|NetReliableNative|Event|Protected|NetClient]
	// Offset: 0x101221030
	// Return & Params: [ Num(2) Size(0x20) ]
	void ClientActivateAbilitySucceed(struct FGameplayAbilitySpecHandle AbilityToActivate, struct FPredictionKey PredictionKey);

	// Object: Function GameplayAbilities.AbilitySystemComponent.ClientActivateAbilityFailed
	// Flags: [Net|NetReliableNative|Event|Protected|NetClient]
	// Offset: 0x101221128
	// Return & Params: [ Num(2) Size(0x6) ]
	void ClientActivateAbilityFailed(struct FGameplayAbilitySpecHandle AbilityToActivate, int16_t PredictionKey);

	// Object: Function GameplayAbilities.AbilitySystemComponent.BP_ApplyGameplayEffectToTarget
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10122541c
	// Return & Params: [ Num(5) Size(0x38) ]
	struct FActiveGameplayEffectHandle BP_ApplyGameplayEffectToTarget(struct UGameplayEffect* GameplayEffectClass, struct UAbilitySystemComponent* Target, float Level, struct FGameplayEffectContextHandle Context);

	// Object: Function GameplayAbilities.AbilitySystemComponent.BP_ApplyGameplayEffectToSelf
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101225210
	// Return & Params: [ Num(4) Size(0x30) ]
	struct FActiveGameplayEffectHandle BP_ApplyGameplayEffectToSelf(struct UGameplayEffect* GameplayEffectClass, float Level, struct FGameplayEffectContextHandle EffectContext);

	// Object: Function GameplayAbilities.AbilitySystemComponent.BP_ApplyGameplayEffectSpecToTarget
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1012261b4
	// Return & Params: [ Num(3) Size(0x20) ]
	struct FActiveGameplayEffectHandle BP_ApplyGameplayEffectSpecToTarget(struct FGameplayEffectSpecHandle& SpecHandle, struct UAbilitySystemComponent* Target);

	// Object: Function GameplayAbilities.AbilitySystemComponent.BP_ApplyGameplayEffectSpecToSelf
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x1012260b4
	// Return & Params: [ Num(2) Size(0x18) ]
	struct FActiveGameplayEffectHandle BP_ApplyGameplayEffectSpecToSelf(struct FGameplayEffectSpecHandle& SpecHandle);

	// Object: DelegateFunction GameplayAbilities.AbilitySystemComponent.AbilityConfirmOrCancel__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void AbilityConfirmOrCancel__DelegateSignature();

	// Object: DelegateFunction GameplayAbilities.AbilitySystemComponent.AbilityAbilityKey__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void AbilityAbilityKey__DelegateSignature(int32_t InputID);
};

// Object: Class GameplayAbilities.AbilitySystemDebugHUD
// Inherited Bytes: 0x318 | Struct Size: 0x318
struct AAbilitySystemDebugHUD : AHUD {
};

// Object: Class GameplayAbilities.AbilitySystemGlobals
// Inherited Bytes: 0x28 | Struct Size: 0x260
struct UAbilitySystemGlobals : UObject {
	// Fields
	struct FSoftClassPath AbilitySystemGlobalsClassName; // Offset: 0x28 | Size: 0x18
	char pad_0x40[0x28]; // Offset: 0x40 | Size: 0x28
	struct FGameplayTag ActivateFailIsDeadTag; // Offset: 0x68 | Size: 0x8
	struct FName ActivateFailIsDeadName; // Offset: 0x70 | Size: 0x8
	struct FGameplayTag ActivateFailCooldownTag; // Offset: 0x78 | Size: 0x8
	struct FName ActivateFailCooldownName; // Offset: 0x80 | Size: 0x8
	struct FGameplayTag ActivateFailCostTag; // Offset: 0x88 | Size: 0x8
	struct FName ActivateFailCostName; // Offset: 0x90 | Size: 0x8
	struct FGameplayTag ActivateFailTagsBlockedTag; // Offset: 0x98 | Size: 0x8
	struct FName ActivateFailTagsBlockedName; // Offset: 0xa0 | Size: 0x8
	struct FGameplayTag ActivateFailTagsMissingTag; // Offset: 0xa8 | Size: 0x8
	struct FName ActivateFailTagsMissingName; // Offset: 0xb0 | Size: 0x8
	struct FGameplayTag ActivateFailNetworkingTag; // Offset: 0xb8 | Size: 0x8
	struct FName ActivateFailNetworkingName; // Offset: 0xc0 | Size: 0x8
	int32_t MinimalReplicationTagCountBits; // Offset: 0xc8 | Size: 0x4
	char pad_0xCC[0x4]; // Offset: 0xcc | Size: 0x4
	struct FNetSerializeScriptStructCache TargetDataStructCache; // Offset: 0xd0 | Size: 0x10
	bool bAllowGameplayModEvaluationChannels; // Offset: 0xe0 | Size: 0x1
	enum class EGameplayModEvaluationChannel DefaultGameplayModEvaluationChannel; // Offset: 0xe1 | Size: 0x1
	char pad_0xE2[0x2]; // Offset: 0xe2 | Size: 0x2
	struct FName GameplayModEvaluationChannelAliases[0xa]; // Offset: 0xe4 | Size: 0x50
	char pad_0x134[0x4]; // Offset: 0x134 | Size: 0x4
	struct FSoftObjectPath GlobalCurveTableName; // Offset: 0x138 | Size: 0x18
	struct UCurveTable* GlobalCurveTable; // Offset: 0x150 | Size: 0x8
	struct FSoftObjectPath GlobalAttributeMetaDataTableName; // Offset: 0x158 | Size: 0x18
	struct UDataTable* GlobalAttributeMetaDataTable; // Offset: 0x170 | Size: 0x8
	struct FSoftObjectPath GlobalAttributeSetDefaultsTableName; // Offset: 0x178 | Size: 0x18
	struct TArray<struct FSoftObjectPath> GlobalAttributeSetDefaultsTableNames; // Offset: 0x190 | Size: 0x10
	struct TArray<struct UCurveTable*> GlobalAttributeDefaultsTables; // Offset: 0x1a0 | Size: 0x10
	struct FSoftObjectPath GlobalGameplayCueManagerClass; // Offset: 0x1b0 | Size: 0x18
	struct FSoftObjectPath GlobalGameplayCueManagerName; // Offset: 0x1c8 | Size: 0x18
	struct TArray<struct FString> GameplayCueNotifyPaths; // Offset: 0x1e0 | Size: 0x10
	struct FSoftObjectPath GameplayTagResponseTableName; // Offset: 0x1f0 | Size: 0x18
	struct UGameplayTagReponseTable* GameplayTagResponseTable; // Offset: 0x208 | Size: 0x8
	bool PredictTargetGameplayEffects; // Offset: 0x210 | Size: 0x1
	char pad_0x211[0x7]; // Offset: 0x211 | Size: 0x7
	struct UGameplayCueManager* GlobalGameplayCueManager; // Offset: 0x218 | Size: 0x8
	char pad_0x220[0x40]; // Offset: 0x220 | Size: 0x40

	// Functions

	// Object: Function GameplayAbilities.AbilitySystemGlobals.ToggleIgnoreAbilitySystemCosts
	// Flags: [Exec|Native|Public]
	// Offset: 0x10122a4d0
	// Return & Params: [ Num(0) Size(0x0) ]
	void ToggleIgnoreAbilitySystemCosts();

	// Object: Function GameplayAbilities.AbilitySystemGlobals.ToggleIgnoreAbilitySystemCooldowns
	// Flags: [Exec|Native|Public]
	// Offset: 0x10122a4ec
	// Return & Params: [ Num(0) Size(0x0) ]
	void ToggleIgnoreAbilitySystemCooldowns();
};

// Object: Class GameplayAbilities.AbilitySystemInterface
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UAbilitySystemInterface : UInterface {
};

// Object: Class GameplayAbilities.AbilitySystemReplicationProxyInterface
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UAbilitySystemReplicationProxyInterface : UInterface {
};

// Object: Class GameplayAbilities.AttributeSet
// Inherited Bytes: 0x28 | Struct Size: 0x30
struct UAttributeSet : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
};

// Object: Class GameplayAbilities.AbilitySystemTestAttributeSet
// Inherited Bytes: 0x30 | Struct Size: 0x70
struct UAbilitySystemTestAttributeSet : UAttributeSet {
	// Fields
	float MaxHealth; // Offset: 0x2c | Size: 0x4
	float Health; // Offset: 0x30 | Size: 0x4
	float Mana; // Offset: 0x34 | Size: 0x4
	float MaxMana; // Offset: 0x38 | Size: 0x4
	float Damage; // Offset: 0x3c | Size: 0x4
	float SpellDamage; // Offset: 0x40 | Size: 0x4
	float PhysicalDamage; // Offset: 0x44 | Size: 0x4
	float CritChance; // Offset: 0x48 | Size: 0x4
	float CritMultiplier; // Offset: 0x4c | Size: 0x4
	float ArmorDamageReduction; // Offset: 0x50 | Size: 0x4
	float DodgeChance; // Offset: 0x54 | Size: 0x4
	float LifeSteal; // Offset: 0x58 | Size: 0x4
	float Strength; // Offset: 0x5c | Size: 0x4
	float StackingAttribute1; // Offset: 0x60 | Size: 0x4
	float StackingAttribute2; // Offset: 0x64 | Size: 0x4
	float NoStackAttribute; // Offset: 0x68 | Size: 0x4
};

// Object: Class GameplayAbilities.AbilitySystemTestPawn
// Inherited Bytes: 0x2b0 | Struct Size: 0x2d0
struct AAbilitySystemTestPawn : ADefaultPawn {
	// Fields
	char pad_0x2B0[0x18]; // Offset: 0x2b0 | Size: 0x18
	struct UAbilitySystemComponent* AbilitySystemComponent; // Offset: 0x2c8 | Size: 0x8
};

// Object: Class GameplayAbilities.AbilityTask
// Inherited Bytes: 0x60 | Struct Size: 0x78
struct UAbilityTask : UGameplayTask {
	// Fields
	struct UGameplayAbility* Ability; // Offset: 0x60 | Size: 0x8
	struct UAbilitySystemComponent* AbilitySystemComponent; // Offset: 0x68 | Size: 0x8
	char pad_0x70[0x8]; // Offset: 0x70 | Size: 0x8
};

// Object: Class GameplayAbilities.AbilityTask_ApplyRootMotion_Base
// Inherited Bytes: 0x78 | Struct Size: 0xa8
struct UAbilityTask_ApplyRootMotion_Base : UAbilityTask {
	// Fields
	struct FName ForceName; // Offset: 0x74 | Size: 0x8
	enum class ERootMotionFinishVelocityMode FinishVelocityMode; // Offset: 0x7c | Size: 0x1
	struct FVector FinishSetVelocity; // Offset: 0x80 | Size: 0xc
	float FinishClampVelocity; // Offset: 0x8c | Size: 0x4
	struct UCharacterMovementComponent* MovementComponent; // Offset: 0x90 | Size: 0x8
	char pad_0x99[0xf]; // Offset: 0x99 | Size: 0xf
};

// Object: Class GameplayAbilities.AbilityTask_ApplyRootMotionConstantForce
// Inherited Bytes: 0xa8 | Struct Size: 0xd8
struct UAbilityTask_ApplyRootMotionConstantForce : UAbilityTask_ApplyRootMotion_Base {
	// Fields
	struct FMulticastInlineDelegate OnFinish; // Offset: 0xa8 | Size: 0x10
	struct FVector WorldDirection; // Offset: 0xb8 | Size: 0xc
	float Strength; // Offset: 0xc4 | Size: 0x4
	float Duration; // Offset: 0xc8 | Size: 0x4
	bool bIsAdditive; // Offset: 0xcc | Size: 0x1
	char pad_0xCD[0x3]; // Offset: 0xcd | Size: 0x3
	struct UCurveFloat* StrengthOverTime; // Offset: 0xd0 | Size: 0x8

	// Functions

	// Object: Function GameplayAbilities.AbilityTask_ApplyRootMotionConstantForce.ApplyRootMotionConstantForce
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x10122b9a4
	// Return & Params: [ Num(11) Size(0x50) ]
	struct UAbilityTask_ApplyRootMotionConstantForce* ApplyRootMotionConstantForce(struct UGameplayAbility* OwningAbility, struct FName TaskInstanceName, struct FVector WorldDirection, float Strength, float Duration, bool bIsAdditive, struct UCurveFloat* StrengthOverTime, enum class ERootMotionFinishVelocityMode VelocityOnFinishMode, struct FVector SetVelocityOnFinish, float ClampVelocityOnFinish);
};

// Object: Class GameplayAbilities.AbilityTask_ApplyRootMotionJumpForce
// Inherited Bytes: 0xa8 | Struct Size: 0x100
struct UAbilityTask_ApplyRootMotionJumpForce : UAbilityTask_ApplyRootMotion_Base {
	// Fields
	struct FMulticastInlineDelegate OnFinish; // Offset: 0xa8 | Size: 0x10
	struct FMulticastInlineDelegate OnLanded; // Offset: 0xb8 | Size: 0x10
	struct FRotator Rotation; // Offset: 0xc8 | Size: 0xc
	float Distance; // Offset: 0xd4 | Size: 0x4
	float Height; // Offset: 0xd8 | Size: 0x4
	float Duration; // Offset: 0xdc | Size: 0x4
	float MinimumLandedTriggerTime; // Offset: 0xe0 | Size: 0x4
	bool bFinishOnLanded; // Offset: 0xe4 | Size: 0x1
	char pad_0xE5[0x3]; // Offset: 0xe5 | Size: 0x3
	struct UCurveVector* PathOffsetCurve; // Offset: 0xe8 | Size: 0x8
	struct UCurveFloat* TimeMappingCurve; // Offset: 0xf0 | Size: 0x8
	char pad_0xF8[0x8]; // Offset: 0xf8 | Size: 0x8

	// Functions

	// Object: Function GameplayAbilities.AbilityTask_ApplyRootMotionJumpForce.OnLandedCallback
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x10122c660
	// Return & Params: [ Num(1) Size(0x88) ]
	void OnLandedCallback(struct FHitResult& Hit);

	// Object: Function GameplayAbilities.AbilityTask_ApplyRootMotionJumpForce.Finish
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10122c708
	// Return & Params: [ Num(0) Size(0x0) ]
	void Finish();

	// Object: Function GameplayAbilities.AbilityTask_ApplyRootMotionJumpForce.ApplyRootMotionJumpForce
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x10122c248
	// Return & Params: [ Num(14) Size(0x58) ]
	struct UAbilityTask_ApplyRootMotionJumpForce* ApplyRootMotionJumpForce(struct UGameplayAbility* OwningAbility, struct FName TaskInstanceName, struct FRotator Rotation, float Distance, float Height, float Duration, float MinimumLandedTriggerTime, bool bFinishOnLanded, enum class ERootMotionFinishVelocityMode VelocityOnFinishMode, struct FVector SetVelocityOnFinish, float ClampVelocityOnFinish, struct UCurveVector* PathOffsetCurve, struct UCurveFloat* TimeMappingCurve);
};

// Object: Class GameplayAbilities.AbilityTask_ApplyRootMotionMoveToActorForce
// Inherited Bytes: 0xa8 | Struct Size: 0x120
struct UAbilityTask_ApplyRootMotionMoveToActorForce : UAbilityTask_ApplyRootMotion_Base {
	// Fields
	struct FMulticastInlineDelegate OnFinished; // Offset: 0xa8 | Size: 0x10
	char pad_0xB8[0x8]; // Offset: 0xb8 | Size: 0x8
	struct FVector StartLocation; // Offset: 0xc0 | Size: 0xc
	struct FVector TargetLocation; // Offset: 0xcc | Size: 0xc
	struct AActor* TargetActor; // Offset: 0xd8 | Size: 0x8
	struct FVector TargetLocationOffset; // Offset: 0xe0 | Size: 0xc
	enum class ERootMotionMoveToActorTargetOffsetType OffsetAlignment; // Offset: 0xec | Size: 0x1
	char pad_0xED[0x3]; // Offset: 0xed | Size: 0x3
	float Duration; // Offset: 0xf0 | Size: 0x4
	bool bDisableDestinationReachedInterrupt; // Offset: 0xf4 | Size: 0x1
	bool bSetNewMovementMode; // Offset: 0xf5 | Size: 0x1
	enum class EMovementMode NewMovementMode; // Offset: 0xf6 | Size: 0x1
	bool bRestrictSpeedToExpected; // Offset: 0xf7 | Size: 0x1
	struct UCurveVector* PathOffsetCurve; // Offset: 0xf8 | Size: 0x8
	struct UCurveFloat* TimeMappingCurve; // Offset: 0x100 | Size: 0x8
	struct UCurveFloat* TargetLerpSpeedHorizontalCurve; // Offset: 0x108 | Size: 0x8
	struct UCurveFloat* TargetLerpSpeedVerticalCurve; // Offset: 0x110 | Size: 0x8
	char pad_0x118[0x8]; // Offset: 0x118 | Size: 0x8

	// Functions

	// Object: Function GameplayAbilities.AbilityTask_ApplyRootMotionMoveToActorForce.OnTargetActorSwapped
	// Flags: [Final|Native|Public]
	// Offset: 0x10122ceb8
	// Return & Params: [ Num(2) Size(0x10) ]
	void OnTargetActorSwapped(struct AActor* OriginalTarget, struct AActor* NewTarget);

	// Object: Function GameplayAbilities.AbilityTask_ApplyRootMotionMoveToActorForce.OnRep_TargetLocation
	// Flags: [Final|Native|Protected]
	// Offset: 0x10122cea4
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnRep_TargetLocation();

	// Object: Function GameplayAbilities.AbilityTask_ApplyRootMotionMoveToActorForce.ApplyRootMotionMoveToTargetDataActorForce
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x10122cf80
	// Return & Params: [ Num(20) Size(0xa0) ]
	struct UAbilityTask_ApplyRootMotionMoveToActorForce* ApplyRootMotionMoveToTargetDataActorForce(struct UGameplayAbility* OwningAbility, struct FName TaskInstanceName, struct FGameplayAbilityTargetDataHandle TargetDataHandle, int32_t TargetDataIndex, int32_t TargetActorIndex, struct FVector TargetLocationOffset, enum class ERootMotionMoveToActorTargetOffsetType OffsetAlignment, float Duration, struct UCurveFloat* TargetLerpSpeedHorizontal, struct UCurveFloat* TargetLerpSpeedVertical, bool bSetNewMovementMode, enum class EMovementMode MovementMode, bool bRestrictSpeedToExpected, struct UCurveVector* PathOffsetCurve, struct UCurveFloat* TimeMappingCurve, enum class ERootMotionFinishVelocityMode VelocityOnFinishMode, struct FVector SetVelocityOnFinish, float ClampVelocityOnFinish, bool bDisableDestinationReachedInterrupt);

	// Object: Function GameplayAbilities.AbilityTask_ApplyRootMotionMoveToActorForce.ApplyRootMotionMoveToActorForce
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x10122d768
	// Return & Params: [ Num(18) Size(0x78) ]
	struct UAbilityTask_ApplyRootMotionMoveToActorForce* ApplyRootMotionMoveToActorForce(struct UGameplayAbility* OwningAbility, struct FName TaskInstanceName, struct AActor* TargetActor, struct FVector TargetLocationOffset, enum class ERootMotionMoveToActorTargetOffsetType OffsetAlignment, float Duration, struct UCurveFloat* TargetLerpSpeedHorizontal, struct UCurveFloat* TargetLerpSpeedVertical, bool bSetNewMovementMode, enum class EMovementMode MovementMode, bool bRestrictSpeedToExpected, struct UCurveVector* PathOffsetCurve, struct UCurveFloat* TimeMappingCurve, enum class ERootMotionFinishVelocityMode VelocityOnFinishMode, struct FVector SetVelocityOnFinish, float ClampVelocityOnFinish, bool bDisableDestinationReachedInterrupt);
};

// Object: Class GameplayAbilities.AbilityTask_ApplyRootMotionMoveToForce
// Inherited Bytes: 0xa8 | Struct Size: 0xf8
struct UAbilityTask_ApplyRootMotionMoveToForce : UAbilityTask_ApplyRootMotion_Base {
	// Fields
	struct FMulticastInlineDelegate OnTimedOut; // Offset: 0xa8 | Size: 0x10
	struct FMulticastInlineDelegate OnTimedOutAndDestinationReached; // Offset: 0xb8 | Size: 0x10
	struct FVector StartLocation; // Offset: 0xc8 | Size: 0xc
	struct FVector TargetLocation; // Offset: 0xd4 | Size: 0xc
	float Duration; // Offset: 0xe0 | Size: 0x4
	bool bSetNewMovementMode; // Offset: 0xe4 | Size: 0x1
	enum class EMovementMode NewMovementMode; // Offset: 0xe5 | Size: 0x1
	bool bRestrictSpeedToExpected; // Offset: 0xe6 | Size: 0x1
	char pad_0xE7[0x1]; // Offset: 0xe7 | Size: 0x1
	struct UCurveVector* PathOffsetCurve; // Offset: 0xe8 | Size: 0x8
	char pad_0xF0[0x8]; // Offset: 0xf0 | Size: 0x8

	// Functions

	// Object: Function GameplayAbilities.AbilityTask_ApplyRootMotionMoveToForce.ApplyRootMotionMoveToForce
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x10122e5dc
	// Return & Params: [ Num(12) Size(0x50) ]
	struct UAbilityTask_ApplyRootMotionMoveToForce* ApplyRootMotionMoveToForce(struct UGameplayAbility* OwningAbility, struct FName TaskInstanceName, struct FVector TargetLocation, float Duration, bool bSetNewMovementMode, enum class EMovementMode MovementMode, bool bRestrictSpeedToExpected, struct UCurveVector* PathOffsetCurve, enum class ERootMotionFinishVelocityMode VelocityOnFinishMode, struct FVector SetVelocityOnFinish, float ClampVelocityOnFinish);
};

// Object: Class GameplayAbilities.AbilityTask_ApplyRootMotionRadialForce
// Inherited Bytes: 0xa8 | Struct Size: 0x100
struct UAbilityTask_ApplyRootMotionRadialForce : UAbilityTask_ApplyRootMotion_Base {
	// Fields
	struct FMulticastInlineDelegate OnFinish; // Offset: 0xa8 | Size: 0x10
	struct FVector Location; // Offset: 0xb8 | Size: 0xc
	char pad_0xC4[0x4]; // Offset: 0xc4 | Size: 0x4
	struct AActor* LocationActor; // Offset: 0xc8 | Size: 0x8
	float Strength; // Offset: 0xd0 | Size: 0x4
	float Duration; // Offset: 0xd4 | Size: 0x4
	float Radius; // Offset: 0xd8 | Size: 0x4
	bool bIsPush; // Offset: 0xdc | Size: 0x1
	bool bIsAdditive; // Offset: 0xdd | Size: 0x1
	bool bNoZForce; // Offset: 0xde | Size: 0x1
	char pad_0xDF[0x1]; // Offset: 0xdf | Size: 0x1
	struct UCurveFloat* StrengthDistanceFalloff; // Offset: 0xe0 | Size: 0x8
	struct UCurveFloat* StrengthOverTime; // Offset: 0xe8 | Size: 0x8
	bool bUseFixedWorldDirection; // Offset: 0xf0 | Size: 0x1
	char pad_0xF1[0x3]; // Offset: 0xf1 | Size: 0x3
	struct FRotator FixedWorldDirection; // Offset: 0xf4 | Size: 0xc

	// Functions

	// Object: Function GameplayAbilities.AbilityTask_ApplyRootMotionRadialForce.ApplyRootMotionRadialForce
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x10122ef78
	// Return & Params: [ Num(18) Size(0x78) ]
	struct UAbilityTask_ApplyRootMotionRadialForce* ApplyRootMotionRadialForce(struct UGameplayAbility* OwningAbility, struct FName TaskInstanceName, struct FVector Location, struct AActor* LocationActor, float Strength, float Duration, float Radius, bool bIsPush, bool bIsAdditive, bool bNoZForce, struct UCurveFloat* StrengthDistanceFalloff, struct UCurveFloat* StrengthOverTime, bool bUseFixedWorldDirection, struct FRotator FixedWorldDirection, enum class ERootMotionFinishVelocityMode VelocityOnFinishMode, struct FVector SetVelocityOnFinish, float ClampVelocityOnFinish);
};

// Object: Class GameplayAbilities.AbilityTask_MoveToLocation
// Inherited Bytes: 0x78 | Struct Size: 0xc0
struct UAbilityTask_MoveToLocation : UAbilityTask {
	// Fields
	struct FMulticastInlineDelegate OnTargetLocationReached; // Offset: 0x78 | Size: 0x10
	char pad_0x88[0x4]; // Offset: 0x88 | Size: 0x4
	struct FVector StartLocation; // Offset: 0x8c | Size: 0xc
	struct FVector TargetLocation; // Offset: 0x98 | Size: 0xc
	float DurationOfMovement; // Offset: 0xa4 | Size: 0x4
	char pad_0xA8[0x8]; // Offset: 0xa8 | Size: 0x8
	struct UCurveFloat* LerpCurve; // Offset: 0xb0 | Size: 0x8
	struct UCurveVector* LerpCurveVector; // Offset: 0xb8 | Size: 0x8

	// Functions

	// Object: Function GameplayAbilities.AbilityTask_MoveToLocation.MoveToLocation
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x10122fc8c
	// Return & Params: [ Num(7) Size(0x38) ]
	struct UAbilityTask_MoveToLocation* MoveToLocation(struct UGameplayAbility* OwningAbility, struct FName TaskInstanceName, struct FVector Location, float Duration, struct UCurveFloat* OptionalInterpolationCurve, struct UCurveVector* OptionalVectorInterpolationCurve);
};

// Object: Class GameplayAbilities.AbilityTask_NetworkSyncPoint
// Inherited Bytes: 0x78 | Struct Size: 0x90
struct UAbilityTask_NetworkSyncPoint : UAbilityTask {
	// Fields
	struct FMulticastInlineDelegate OnSync; // Offset: 0x78 | Size: 0x10
	char pad_0x88[0x8]; // Offset: 0x88 | Size: 0x8

	// Functions

	// Object: Function GameplayAbilities.AbilityTask_NetworkSyncPoint.WaitNetSync
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101231b04
	// Return & Params: [ Num(3) Size(0x18) ]
	struct UAbilityTask_NetworkSyncPoint* WaitNetSync(struct UGameplayAbility* OwningAbility, enum class EAbilityTaskNetSyncType SyncType);

	// Object: Function GameplayAbilities.AbilityTask_NetworkSyncPoint.OnSignalCallback
	// Flags: [Final|Native|Public]
	// Offset: 0x101231bd0
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnSignalCallback();
};

// Object: Class GameplayAbilities.AbilityTask_PlayMontageAndWait
// Inherited Bytes: 0x78 | Struct Size: 0x100
struct UAbilityTask_PlayMontageAndWait : UAbilityTask {
	// Fields
	struct FMulticastInlineDelegate OnCompleted; // Offset: 0x78 | Size: 0x10
	struct FMulticastInlineDelegate OnBlendOut; // Offset: 0x88 | Size: 0x10
	struct FMulticastInlineDelegate OnInterrupted; // Offset: 0x98 | Size: 0x10
	struct FMulticastInlineDelegate OnCancelled; // Offset: 0xa8 | Size: 0x10
	char pad_0xB8[0x28]; // Offset: 0xb8 | Size: 0x28
	struct UAnimMontage* MontageToPlay; // Offset: 0xe0 | Size: 0x8
	float Rate; // Offset: 0xe8 | Size: 0x4
	struct FName StartSection; // Offset: 0xec | Size: 0x8
	float AnimRootMotionTranslationScale; // Offset: 0xf4 | Size: 0x4
	bool bStopWhenAbilityEnds; // Offset: 0xf8 | Size: 0x1
	bool bInterruptedCalledBeforeBlendingOut; // Offset: 0xf9 | Size: 0x1
	char pad_0xFA[0x6]; // Offset: 0xfa | Size: 0x6

	// Functions

	// Object: Function GameplayAbilities.AbilityTask_PlayMontageAndWait.OnMontageInterrupted
	// Flags: [Final|Native|Public]
	// Offset: 0x101232350
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnMontageInterrupted();

	// Object: Function GameplayAbilities.AbilityTask_PlayMontageAndWait.OnMontageEnded
	// Flags: [Final|Native|Public]
	// Offset: 0x10123227c
	// Return & Params: [ Num(2) Size(0x9) ]
	void OnMontageEnded(struct UAnimMontage* Montage, bool bInterrupted);

	// Object: Function GameplayAbilities.AbilityTask_PlayMontageAndWait.OnMontageBlendingOut
	// Flags: [Final|Native|Public]
	// Offset: 0x101232364
	// Return & Params: [ Num(2) Size(0x9) ]
	void OnMontageBlendingOut(struct UAnimMontage* Montage, bool bInterrupted);

	// Object: Function GameplayAbilities.AbilityTask_PlayMontageAndWait.CreatePlayMontageAndWaitProxy
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101232024
	// Return & Params: [ Num(8) Size(0x38) ]
	struct UAbilityTask_PlayMontageAndWait* CreatePlayMontageAndWaitProxy(struct UGameplayAbility* OwningAbility, struct FName TaskInstanceName, struct UAnimMontage* MontageToPlay, float Rate, struct FName StartSection, bool bStopWhenAbilityEnds, float AnimRootMotionTranslationScale);
};

// Object: Class GameplayAbilities.AbilityTask_Repeat
// Inherited Bytes: 0x78 | Struct Size: 0xb0
struct UAbilityTask_Repeat : UAbilityTask {
	// Fields
	struct FMulticastInlineDelegate OnPerformAction; // Offset: 0x78 | Size: 0x10
	struct FMulticastInlineDelegate OnFinished; // Offset: 0x88 | Size: 0x10
	char pad_0x98[0x18]; // Offset: 0x98 | Size: 0x18

	// Functions

	// Object: Function GameplayAbilities.AbilityTask_Repeat.RepeatAction
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10123294c
	// Return & Params: [ Num(4) Size(0x18) ]
	struct UAbilityTask_Repeat* RepeatAction(struct UGameplayAbility* OwningAbility, float TimeBetweenActions, int32_t TotalActionCount);
};

// Object: Class GameplayAbilities.AbilityTask_SpawnActor
// Inherited Bytes: 0x78 | Struct Size: 0xc0
struct UAbilityTask_SpawnActor : UAbilityTask {
	// Fields
	struct FMulticastInlineDelegate Success; // Offset: 0x78 | Size: 0x10
	struct FMulticastInlineDelegate DidNotSpawn; // Offset: 0x88 | Size: 0x10
	char pad_0x98[0x28]; // Offset: 0x98 | Size: 0x28

	// Functions

	// Object: Function GameplayAbilities.AbilityTask_SpawnActor.SpawnActor
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1012334a4
	// Return & Params: [ Num(4) Size(0x40) ]
	struct UAbilityTask_SpawnActor* SpawnActor(struct UGameplayAbility* OwningAbility, struct FGameplayAbilityTargetDataHandle TargetData, struct AActor* Class);

	// Object: Function GameplayAbilities.AbilityTask_SpawnActor.FinishSpawningActor
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101232e58
	// Return & Params: [ Num(3) Size(0x38) ]
	void FinishSpawningActor(struct UGameplayAbility* OwningAbility, struct FGameplayAbilityTargetDataHandle TargetData, struct AActor* SpawnedActor);

	// Object: Function GameplayAbilities.AbilityTask_SpawnActor.BeginSpawningActor
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101233148
	// Return & Params: [ Num(5) Size(0x41) ]
	bool BeginSpawningActor(struct UGameplayAbility* OwningAbility, struct FGameplayAbilityTargetDataHandle TargetData, struct AActor* Class, struct AActor*& SpawnedActor);
};

// Object: Class GameplayAbilities.AbilityTask_StartAbilityState
// Inherited Bytes: 0x78 | Struct Size: 0xb0
struct UAbilityTask_StartAbilityState : UAbilityTask {
	// Fields
	struct FMulticastInlineDelegate OnStateEnded; // Offset: 0x78 | Size: 0x10
	struct FMulticastInlineDelegate OnStateInterrupted; // Offset: 0x88 | Size: 0x10
	char pad_0x98[0x18]; // Offset: 0x98 | Size: 0x18

	// Functions

	// Object: Function GameplayAbilities.AbilityTask_StartAbilityState.StartAbilityState
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101233c2c
	// Return & Params: [ Num(4) Size(0x20) ]
	struct UAbilityTask_StartAbilityState* StartAbilityState(struct UGameplayAbility* OwningAbility, struct FName StateName, bool bEndCurrentState);
};

// Object: Class GameplayAbilities.AbilityTask_VisualizeTargeting
// Inherited Bytes: 0x78 | Struct Size: 0xa0
struct UAbilityTask_VisualizeTargeting : UAbilityTask {
	// Fields
	struct FMulticastInlineDelegate TimeElapsed; // Offset: 0x78 | Size: 0x10
	char pad_0x88[0x18]; // Offset: 0x88 | Size: 0x18

	// Functions

	// Object: Function GameplayAbilities.AbilityTask_VisualizeTargeting.VisualizeTargetingUsingActor
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101234340
	// Return & Params: [ Num(5) Size(0x28) ]
	struct UAbilityTask_VisualizeTargeting* VisualizeTargetingUsingActor(struct UGameplayAbility* OwningAbility, struct AGameplayAbilityTargetActor* TargetActor, struct FName TaskInstanceName, float Duration);

	// Object: Function GameplayAbilities.AbilityTask_VisualizeTargeting.VisualizeTargeting
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1012344a0
	// Return & Params: [ Num(5) Size(0x28) ]
	struct UAbilityTask_VisualizeTargeting* VisualizeTargeting(struct UGameplayAbility* OwningAbility, struct AGameplayAbilityTargetActor* Class, struct FName TaskInstanceName, float Duration);

	// Object: Function GameplayAbilities.AbilityTask_VisualizeTargeting.FinishSpawningActor
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101234148
	// Return & Params: [ Num(2) Size(0x10) ]
	void FinishSpawningActor(struct UGameplayAbility* OwningAbility, struct AGameplayAbilityTargetActor* SpawnedActor);

	// Object: Function GameplayAbilities.AbilityTask_VisualizeTargeting.BeginSpawningActor
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101234210
	// Return & Params: [ Num(4) Size(0x19) ]
	bool BeginSpawningActor(struct UGameplayAbility* OwningAbility, struct AGameplayAbilityTargetActor* Class, struct AGameplayAbilityTargetActor*& SpawnedActor);
};

// Object: Class GameplayAbilities.AbilityTask_WaitAbilityActivate
// Inherited Bytes: 0x78 | Struct Size: 0x140
struct UAbilityTask_WaitAbilityActivate : UAbilityTask {
	// Fields
	struct FMulticastInlineDelegate OnActivate; // Offset: 0x78 | Size: 0x10
	char pad_0x88[0xb8]; // Offset: 0x88 | Size: 0xb8

	// Functions

	// Object: Function GameplayAbilities.AbilityTask_WaitAbilityActivate.WaitForAbilityActivateWithTagRequirements
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101234ce4
	// Return & Params: [ Num(5) Size(0x68) ]
	struct UAbilityTask_WaitAbilityActivate* WaitForAbilityActivateWithTagRequirements(struct UGameplayAbility* OwningAbility, struct FGameplayTagRequirements TagRequirements, bool IncludeTriggeredAbilities, bool TriggerOnce);

	// Object: Function GameplayAbilities.AbilityTask_WaitAbilityActivate.WaitForAbilityActivate_Query
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101234ae4
	// Return & Params: [ Num(5) Size(0x60) ]
	struct UAbilityTask_WaitAbilityActivate* WaitForAbilityActivate_Query(struct UGameplayAbility* OwningAbility, struct FGameplayTagQuery Query, bool IncludeTriggeredAbilities, bool TriggerOnce);

	// Object: Function GameplayAbilities.AbilityTask_WaitAbilityActivate.WaitForAbilityActivate
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101234f40
	// Return & Params: [ Num(6) Size(0x28) ]
	struct UAbilityTask_WaitAbilityActivate* WaitForAbilityActivate(struct UGameplayAbility* OwningAbility, struct FGameplayTag WithTag, struct FGameplayTag WithoutTag, bool IncludeTriggeredAbilities, bool TriggerOnce);

	// Object: Function GameplayAbilities.AbilityTask_WaitAbilityActivate.OnAbilityActivate
	// Flags: [Final|Native|Public]
	// Offset: 0x101235108
	// Return & Params: [ Num(1) Size(0x8) ]
	void OnAbilityActivate(struct UGameplayAbility* ActivatedAbility);
};

// Object: Class GameplayAbilities.AbilityTask_WaitAbilityCommit
// Inherited Bytes: 0x78 | Struct Size: 0xf0
struct UAbilityTask_WaitAbilityCommit : UAbilityTask {
	// Fields
	struct FMulticastInlineDelegate OnCommit; // Offset: 0x78 | Size: 0x10
	char pad_0x88[0x68]; // Offset: 0x88 | Size: 0x68

	// Functions

	// Object: Function GameplayAbilities.AbilityTask_WaitAbilityCommit.WaitForAbilityCommit_Query
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1012356a8
	// Return & Params: [ Num(4) Size(0x60) ]
	struct UAbilityTask_WaitAbilityCommit* WaitForAbilityCommit_Query(struct UGameplayAbility* OwningAbility, struct FGameplayTagQuery Query, bool TriggerOnce);

	// Object: Function GameplayAbilities.AbilityTask_WaitAbilityCommit.WaitForAbilityCommit
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10123584c
	// Return & Params: [ Num(5) Size(0x28) ]
	struct UAbilityTask_WaitAbilityCommit* WaitForAbilityCommit(struct UGameplayAbility* OwningAbility, struct FGameplayTag WithTag, struct FGameplayTag WithoutTage, bool TriggerOnce);

	// Object: Function GameplayAbilities.AbilityTask_WaitAbilityCommit.OnAbilityCommit
	// Flags: [Final|Native|Public]
	// Offset: 0x1012359b4
	// Return & Params: [ Num(1) Size(0x8) ]
	void OnAbilityCommit(struct UGameplayAbility* ActivatedAbility);
};

// Object: Class GameplayAbilities.AbilityTask_WaitAttributeChange
// Inherited Bytes: 0x78 | Struct Size: 0xf0
struct UAbilityTask_WaitAttributeChange : UAbilityTask {
	// Fields
	struct FMulticastInlineDelegate OnChange; // Offset: 0x78 | Size: 0x10
	char pad_0x88[0x60]; // Offset: 0x88 | Size: 0x60
	struct UAbilitySystemComponent* ExternalOwner; // Offset: 0xe8 | Size: 0x8

	// Functions

	// Object: Function GameplayAbilities.AbilityTask_WaitAttributeChange.WaitForAttributeChangeWithComparison
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101235f74
	// Return & Params: [ Num(9) Size(0x70) ]
	struct UAbilityTask_WaitAttributeChange* WaitForAttributeChangeWithComparison(struct UGameplayAbility* OwningAbility, struct FGameplayAttribute InAttribute, struct FGameplayTag InWithTag, struct FGameplayTag InWithoutTag, enum class EWaitAttributeChangeComparison InComparisonType, float InComparisonValue, bool TriggerOnce, struct AActor* OptionalExternalOwner);

	// Object: Function GameplayAbilities.AbilityTask_WaitAttributeChange.WaitForAttributeChange
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101236270
	// Return & Params: [ Num(7) Size(0x68) ]
	struct UAbilityTask_WaitAttributeChange* WaitForAttributeChange(struct UGameplayAbility* OwningAbility, struct FGameplayAttribute Attribute, struct FGameplayTag WithSrcTag, struct FGameplayTag WithoutSrcTag, bool TriggerOnce, struct AActor* OptionalExternalOwner);
};

// Object: Class GameplayAbilities.AbilityTask_WaitAttributeChangeRatioThreshold
// Inherited Bytes: 0x78 | Struct Size: 0x138
struct UAbilityTask_WaitAttributeChangeRatioThreshold : UAbilityTask {
	// Fields
	struct FMulticastInlineDelegate OnChange; // Offset: 0x78 | Size: 0x10
	char pad_0x88[0xa8]; // Offset: 0x88 | Size: 0xa8
	struct UAbilitySystemComponent* ExternalOwner; // Offset: 0x130 | Size: 0x8

	// Functions

	// Object: Function GameplayAbilities.AbilityTask_WaitAttributeChangeRatioThreshold.WaitForAttributeChangeRatioThreshold
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101236934
	// Return & Params: [ Num(8) Size(0x98) ]
	struct UAbilityTask_WaitAttributeChangeRatioThreshold* WaitForAttributeChangeRatioThreshold(struct UGameplayAbility* OwningAbility, struct FGameplayAttribute AttributeNumerator, struct FGameplayAttribute AttributeDenominator, enum class EWaitAttributeChangeComparison ComparisonType, float ComparisonValue, bool bTriggerOnce, struct AActor* OptionalExternalOwner);
};

// Object: Class GameplayAbilities.AbilityTask_WaitAttributeChangeThreshold
// Inherited Bytes: 0x78 | Struct Size: 0xe8
struct UAbilityTask_WaitAttributeChangeThreshold : UAbilityTask {
	// Fields
	struct FMulticastInlineDelegate OnChange; // Offset: 0x78 | Size: 0x10
	char pad_0x88[0x58]; // Offset: 0x88 | Size: 0x58
	struct UAbilitySystemComponent* ExternalOwner; // Offset: 0xe0 | Size: 0x8

	// Functions

	// Object: Function GameplayAbilities.AbilityTask_WaitAttributeChangeThreshold.WaitForAttributeChangeThreshold
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101237040
	// Return & Params: [ Num(7) Size(0x60) ]
	struct UAbilityTask_WaitAttributeChangeThreshold* WaitForAttributeChangeThreshold(struct UGameplayAbility* OwningAbility, struct FGameplayAttribute Attribute, enum class EWaitAttributeChangeComparison ComparisonType, float ComparisonValue, bool bTriggerOnce, struct AActor* OptionalExternalOwner);
};

// Object: Class GameplayAbilities.AbilityTask_WaitCancel
// Inherited Bytes: 0x78 | Struct Size: 0x90
struct UAbilityTask_WaitCancel : UAbilityTask {
	// Fields
	struct FMulticastInlineDelegate OnCancel; // Offset: 0x78 | Size: 0x10
	char pad_0x88[0x8]; // Offset: 0x88 | Size: 0x8

	// Functions

	// Object: Function GameplayAbilities.AbilityTask_WaitCancel.WaitCancel
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1012376a4
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UAbilityTask_WaitCancel* WaitCancel(struct UGameplayAbility* OwningAbility);

	// Object: Function GameplayAbilities.AbilityTask_WaitCancel.OnLocalCancelCallback
	// Flags: [Final|Native|Public]
	// Offset: 0x101237724
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnLocalCancelCallback();

	// Object: Function GameplayAbilities.AbilityTask_WaitCancel.OnCancelCallback
	// Flags: [Final|Native|Public]
	// Offset: 0x101237738
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnCancelCallback();
};

// Object: Class GameplayAbilities.AbilityTask_WaitConfirm
// Inherited Bytes: 0x78 | Struct Size: 0x98
struct UAbilityTask_WaitConfirm : UAbilityTask {
	// Fields
	struct FMulticastInlineDelegate OnConfirm; // Offset: 0x78 | Size: 0x10
	char pad_0x88[0x10]; // Offset: 0x88 | Size: 0x10

	// Functions

	// Object: Function GameplayAbilities.AbilityTask_WaitConfirm.WaitConfirm
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101237b8c
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UAbilityTask_WaitConfirm* WaitConfirm(struct UGameplayAbility* OwningAbility);

	// Object: Function GameplayAbilities.AbilityTask_WaitConfirm.OnConfirmCallback
	// Flags: [Final|Native|Public]
	// Offset: 0x101237c0c
	// Return & Params: [ Num(1) Size(0x8) ]
	void OnConfirmCallback(struct UGameplayAbility* InAbility);
};

// Object: Class GameplayAbilities.AbilityTask_WaitConfirmCancel
// Inherited Bytes: 0x78 | Struct Size: 0xa0
struct UAbilityTask_WaitConfirmCancel : UAbilityTask {
	// Fields
	struct FMulticastInlineDelegate OnConfirm; // Offset: 0x78 | Size: 0x10
	struct FMulticastInlineDelegate OnCancel; // Offset: 0x88 | Size: 0x10
	char pad_0x98[0x8]; // Offset: 0x98 | Size: 0x8

	// Functions

	// Object: Function GameplayAbilities.AbilityTask_WaitConfirmCancel.WaitConfirmCancel
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1012380cc
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UAbilityTask_WaitConfirmCancel* WaitConfirmCancel(struct UGameplayAbility* OwningAbility);

	// Object: Function GameplayAbilities.AbilityTask_WaitConfirmCancel.OnLocalConfirmCallback
	// Flags: [Final|Native|Public]
	// Offset: 0x101238160
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnLocalConfirmCallback();

	// Object: Function GameplayAbilities.AbilityTask_WaitConfirmCancel.OnLocalCancelCallback
	// Flags: [Final|Native|Public]
	// Offset: 0x10123814c
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnLocalCancelCallback();

	// Object: Function GameplayAbilities.AbilityTask_WaitConfirmCancel.OnConfirmCallback
	// Flags: [Final|Native|Public]
	// Offset: 0x101238188
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnConfirmCallback();

	// Object: Function GameplayAbilities.AbilityTask_WaitConfirmCancel.OnCancelCallback
	// Flags: [Final|Native|Public]
	// Offset: 0x101238174
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnCancelCallback();
};

// Object: Class GameplayAbilities.AbilityTask_WaitDelay
// Inherited Bytes: 0x78 | Struct Size: 0x98
struct UAbilityTask_WaitDelay : UAbilityTask {
	// Fields
	struct FMulticastInlineDelegate OnFinish; // Offset: 0x78 | Size: 0x10
	char pad_0x88[0x10]; // Offset: 0x88 | Size: 0x10

	// Functions

	// Object: Function GameplayAbilities.AbilityTask_WaitDelay.WaitDelay
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1012386c0
	// Return & Params: [ Num(3) Size(0x18) ]
	struct UAbilityTask_WaitDelay* WaitDelay(struct UGameplayAbility* OwningAbility, float Time);
};

// Object: Class GameplayAbilities.AbilityTask_WaitGameplayEffectApplied
// Inherited Bytes: 0x78 | Struct Size: 0x1d0
struct UAbilityTask_WaitGameplayEffectApplied : UAbilityTask {
	// Fields
	char pad_0x78[0x148]; // Offset: 0x78 | Size: 0x148
	struct UAbilitySystemComponent* ExternalOwner; // Offset: 0x1c0 | Size: 0x8
	char pad_0x1C8[0x8]; // Offset: 0x1c8 | Size: 0x8

	// Functions

	// Object: Function GameplayAbilities.AbilityTask_WaitGameplayEffectApplied.OnApplyGameplayEffectCallback
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x101238b34
	// Return & Params: [ Num(3) Size(0x2a8) ]
	void OnApplyGameplayEffectCallback(struct UAbilitySystemComponent* Target, struct FGameplayEffectSpec& SpecApplied, struct FActiveGameplayEffectHandle ActiveHandle);
};

// Object: Class GameplayAbilities.AbilityTask_WaitGameplayEffectApplied_Self
// Inherited Bytes: 0x1d0 | Struct Size: 0x1f0
struct UAbilityTask_WaitGameplayEffectApplied_Self : UAbilityTask_WaitGameplayEffectApplied {
	// Fields
	struct FMulticastInlineDelegate OnApplied; // Offset: 0x1d0 | Size: 0x10
	char pad_0x1E0[0x10]; // Offset: 0x1e0 | Size: 0x10

	// Functions

	// Object: Function GameplayAbilities.AbilityTask_WaitGameplayEffectApplied_Self.WaitGameplayEffectAppliedToSelf_Query
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101238ee0
	// Return & Params: [ Num(8) Size(0xc8) ]
	struct UAbilityTask_WaitGameplayEffectApplied_Self* WaitGameplayEffectAppliedToSelf_Query(struct UGameplayAbility* OwningAbility, struct FGameplayTargetDataFilterHandle SourceFilter, struct FGameplayTagQuery SourceTagQuery, struct FGameplayTagQuery TargetTagQuery, bool TriggerOnce, struct AActor* OptionalExternalOwner, bool ListenForPeriodicEffect);

	// Object: Function GameplayAbilities.AbilityTask_WaitGameplayEffectApplied_Self.WaitGameplayEffectAppliedToSelf
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101239310
	// Return & Params: [ Num(8) Size(0xd8) ]
	struct UAbilityTask_WaitGameplayEffectApplied_Self* WaitGameplayEffectAppliedToSelf(struct UGameplayAbility* OwningAbility, struct FGameplayTargetDataFilterHandle SourceFilter, struct FGameplayTagRequirements SourceTagRequirements, struct FGameplayTagRequirements TargetTagRequirements, bool TriggerOnce, struct AActor* OptionalExternalOwner, bool ListenForPeriodicEffect);
};

// Object: Class GameplayAbilities.AbilityTask_WaitGameplayEffectApplied_Target
// Inherited Bytes: 0x1d0 | Struct Size: 0x1f0
struct UAbilityTask_WaitGameplayEffectApplied_Target : UAbilityTask_WaitGameplayEffectApplied {
	// Fields
	struct FMulticastInlineDelegate OnApplied; // Offset: 0x1d0 | Size: 0x10
	char pad_0x1E0[0x10]; // Offset: 0x1e0 | Size: 0x10

	// Functions

	// Object: Function GameplayAbilities.AbilityTask_WaitGameplayEffectApplied_Target.WaitGameplayEffectAppliedToTarget_Query
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10123b400
	// Return & Params: [ Num(8) Size(0xc8) ]
	struct UAbilityTask_WaitGameplayEffectApplied_Target* WaitGameplayEffectAppliedToTarget_Query(struct UGameplayAbility* OwningAbility, struct FGameplayTargetDataFilterHandle SourceFilter, struct FGameplayTagQuery SourceTagQuery, struct FGameplayTagQuery TargetTagQuery, bool TriggerOnce, struct AActor* OptionalExternalOwner, bool ListenForPeriodicEffect);

	// Object: Function GameplayAbilities.AbilityTask_WaitGameplayEffectApplied_Target.WaitGameplayEffectAppliedToTarget
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10123b830
	// Return & Params: [ Num(8) Size(0xd8) ]
	struct UAbilityTask_WaitGameplayEffectApplied_Target* WaitGameplayEffectAppliedToTarget(struct UGameplayAbility* OwningAbility, struct FGameplayTargetDataFilterHandle TargetFilter, struct FGameplayTagRequirements SourceTagRequirements, struct FGameplayTagRequirements TargetTagRequirements, bool TriggerOnce, struct AActor* OptionalExternalOwner, bool ListenForPeriodicEffects);
};

// Object: Class GameplayAbilities.AbilityTask_WaitGameplayEffectBlockedImmunity
// Inherited Bytes: 0x78 | Struct Size: 0x140
struct UAbilityTask_WaitGameplayEffectBlockedImmunity : UAbilityTask {
	// Fields
	struct FMulticastInlineDelegate bLocked; // Offset: 0x78 | Size: 0x10
	char pad_0x88[0xa8]; // Offset: 0x88 | Size: 0xa8
	struct UAbilitySystemComponent* ExternalOwner; // Offset: 0x130 | Size: 0x8
	char pad_0x138[0x8]; // Offset: 0x138 | Size: 0x8

	// Functions

	// Object: Function GameplayAbilities.AbilityTask_WaitGameplayEffectBlockedImmunity.WaitGameplayEffectBlockedByImmunity
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10123c208
	// Return & Params: [ Num(6) Size(0xc0) ]
	struct UAbilityTask_WaitGameplayEffectBlockedImmunity* WaitGameplayEffectBlockedByImmunity(struct UGameplayAbility* OwningAbility, struct FGameplayTagRequirements SourceTagRequirements, struct FGameplayTagRequirements TargetTagRequirements, struct AActor* OptionalExternalTarget, bool OnlyTriggerOnce);
};

// Object: Class GameplayAbilities.AbilityTask_WaitGameplayEffectRemoved
// Inherited Bytes: 0x78 | Struct Size: 0xb8
struct UAbilityTask_WaitGameplayEffectRemoved : UAbilityTask {
	// Fields
	struct FMulticastInlineDelegate OnRemoved; // Offset: 0x78 | Size: 0x10
	struct FMulticastInlineDelegate InvalidHandle; // Offset: 0x88 | Size: 0x10
	char pad_0x98[0x20]; // Offset: 0x98 | Size: 0x20

	// Functions

	// Object: Function GameplayAbilities.AbilityTask_WaitGameplayEffectRemoved.WaitForGameplayEffectRemoved
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10123c958
	// Return & Params: [ Num(3) Size(0x18) ]
	struct UAbilityTask_WaitGameplayEffectRemoved* WaitForGameplayEffectRemoved(struct UGameplayAbility* OwningAbility, struct FActiveGameplayEffectHandle Handle);

	// Object: Function GameplayAbilities.AbilityTask_WaitGameplayEffectRemoved.OnGameplayEffectRemoved
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x10123ca30
	// Return & Params: [ Num(1) Size(0x20) ]
	void OnGameplayEffectRemoved(struct FGameplayEffectRemovalInfo& InGameplayEffectRemovalInfo);
};

// Object: Class GameplayAbilities.AbilityTask_WaitGameplayEffectStackChange
// Inherited Bytes: 0x78 | Struct Size: 0xb0
struct UAbilityTask_WaitGameplayEffectStackChange : UAbilityTask {
	// Fields
	struct FMulticastInlineDelegate OnChange; // Offset: 0x78 | Size: 0x10
	struct FMulticastInlineDelegate InvalidHandle; // Offset: 0x88 | Size: 0x10
	char pad_0x98[0x18]; // Offset: 0x98 | Size: 0x18

	// Functions

	// Object: Function GameplayAbilities.AbilityTask_WaitGameplayEffectStackChange.WaitForGameplayEffectStackChange
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10123cf6c
	// Return & Params: [ Num(3) Size(0x18) ]
	struct UAbilityTask_WaitGameplayEffectStackChange* WaitForGameplayEffectStackChange(struct UGameplayAbility* OwningAbility, struct FActiveGameplayEffectHandle Handle);

	// Object: Function GameplayAbilities.AbilityTask_WaitGameplayEffectStackChange.OnGameplayEffectStackChange
	// Flags: [Final|Native|Public]
	// Offset: 0x10123d044
	// Return & Params: [ Num(3) Size(0x10) ]
	void OnGameplayEffectStackChange(struct FActiveGameplayEffectHandle Handle, int32_t NewCount, int32_t OldCount);
};

// Object: Class GameplayAbilities.AbilityTask_WaitGameplayEvent
// Inherited Bytes: 0x78 | Struct Size: 0xa8
struct UAbilityTask_WaitGameplayEvent : UAbilityTask {
	// Fields
	struct FMulticastInlineDelegate EventReceived; // Offset: 0x78 | Size: 0x10
	char pad_0x88[0x8]; // Offset: 0x88 | Size: 0x8
	struct UAbilitySystemComponent* OptionalExternalTarget; // Offset: 0x90 | Size: 0x8
	char pad_0x98[0x10]; // Offset: 0x98 | Size: 0x10

	// Functions

	// Object: Function GameplayAbilities.AbilityTask_WaitGameplayEvent.WaitGameplayEvent
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10123d5a0
	// Return & Params: [ Num(6) Size(0x28) ]
	struct UAbilityTask_WaitGameplayEvent* WaitGameplayEvent(struct UGameplayAbility* OwningAbility, struct FGameplayTag EventTag, struct AActor* OptionalExternalTarget, bool OnlyTriggerOnce, bool OnlyMatchExact);
};

// Object: Class GameplayAbilities.AbilityTask_WaitGameplayTag
// Inherited Bytes: 0x78 | Struct Size: 0x98
struct UAbilityTask_WaitGameplayTag : UAbilityTask {
	// Fields
	char pad_0x78[0x8]; // Offset: 0x78 | Size: 0x8
	struct UAbilitySystemComponent* OptionalExternalTarget; // Offset: 0x80 | Size: 0x8
	char pad_0x88[0x10]; // Offset: 0x88 | Size: 0x10

	// Functions

	// Object: Function GameplayAbilities.AbilityTask_WaitGameplayTag.GameplayTagCallback
	// Flags: [Native|Public]
	// Offset: 0x10123e6b8
	// Return & Params: [ Num(2) Size(0xc) ]
	void GameplayTagCallback(struct FGameplayTag Tag, int32_t NewCount);
};

// Object: Class GameplayAbilities.AbilityTask_WaitGameplayTagAdded
// Inherited Bytes: 0x98 | Struct Size: 0xa8
struct UAbilityTask_WaitGameplayTagAdded : UAbilityTask_WaitGameplayTag {
	// Fields
	struct FMulticastInlineDelegate Added; // Offset: 0x98 | Size: 0x10

	// Functions

	// Object: Function GameplayAbilities.AbilityTask_WaitGameplayTagAdded.WaitGameplayTagAdd
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10123db74
	// Return & Params: [ Num(5) Size(0x28) ]
	struct UAbilityTask_WaitGameplayTagAdded* WaitGameplayTagAdd(struct UGameplayAbility* OwningAbility, struct FGameplayTag Tag, struct AActor* InOptionalExternalTarget, bool OnlyTriggerOnce);
};

// Object: Class GameplayAbilities.AbilityTask_WaitGameplayTagRemoved
// Inherited Bytes: 0x98 | Struct Size: 0xa8
struct UAbilityTask_WaitGameplayTagRemoved : UAbilityTask_WaitGameplayTag {
	// Fields
	struct FMulticastInlineDelegate Removed; // Offset: 0x98 | Size: 0x10

	// Functions

	// Object: Function GameplayAbilities.AbilityTask_WaitGameplayTagRemoved.WaitGameplayTagRemove
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10123e19c
	// Return & Params: [ Num(5) Size(0x28) ]
	struct UAbilityTask_WaitGameplayTagRemoved* WaitGameplayTagRemove(struct UGameplayAbility* OwningAbility, struct FGameplayTag Tag, struct AActor* InOptionalExternalTarget, bool OnlyTriggerOnce);
};

// Object: Class GameplayAbilities.AbilityTask_WaitInputPress
// Inherited Bytes: 0x78 | Struct Size: 0x98
struct UAbilityTask_WaitInputPress : UAbilityTask {
	// Fields
	struct FMulticastInlineDelegate OnPress; // Offset: 0x78 | Size: 0x10
	char pad_0x88[0x10]; // Offset: 0x88 | Size: 0x10

	// Functions

	// Object: Function GameplayAbilities.AbilityTask_WaitInputPress.WaitInputPress
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10123e8f4
	// Return & Params: [ Num(3) Size(0x18) ]
	struct UAbilityTask_WaitInputPress* WaitInputPress(struct UGameplayAbility* OwningAbility, bool bTestAlreadyPressed);

	// Object: Function GameplayAbilities.AbilityTask_WaitInputPress.OnPressCallback
	// Flags: [Final|Native|Public]
	// Offset: 0x10123e9c8
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnPressCallback();
};

// Object: Class GameplayAbilities.AbilityTask_WaitInputRelease
// Inherited Bytes: 0x78 | Struct Size: 0x98
struct UAbilityTask_WaitInputRelease : UAbilityTask {
	// Fields
	struct FMulticastInlineDelegate OnRelease; // Offset: 0x78 | Size: 0x10
	char pad_0x88[0x10]; // Offset: 0x88 | Size: 0x10

	// Functions

	// Object: Function GameplayAbilities.AbilityTask_WaitInputRelease.WaitInputRelease
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10123ee28
	// Return & Params: [ Num(3) Size(0x18) ]
	struct UAbilityTask_WaitInputRelease* WaitInputRelease(struct UGameplayAbility* OwningAbility, bool bTestAlreadyReleased);

	// Object: Function GameplayAbilities.AbilityTask_WaitInputRelease.OnReleaseCallback
	// Flags: [Final|Native|Public]
	// Offset: 0x10123eefc
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnReleaseCallback();
};

// Object: Class GameplayAbilities.AbilityTask_WaitMovementModeChange
// Inherited Bytes: 0x78 | Struct Size: 0x98
struct UAbilityTask_WaitMovementModeChange : UAbilityTask {
	// Fields
	struct FMulticastInlineDelegate OnChange; // Offset: 0x78 | Size: 0x10
	char pad_0x88[0x10]; // Offset: 0x88 | Size: 0x10

	// Functions

	// Object: Function GameplayAbilities.AbilityTask_WaitMovementModeChange.OnMovementModeChange
	// Flags: [Final|Native|Public]
	// Offset: 0x10123f428
	// Return & Params: [ Num(3) Size(0xa) ]
	void OnMovementModeChange(struct ACharacter* Character, enum class EMovementMode PrevMovementMode, char PreviousCustomMode);

	// Object: Function GameplayAbilities.AbilityTask_WaitMovementModeChange.CreateWaitMovementModeChange
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10123f35c
	// Return & Params: [ Num(3) Size(0x18) ]
	struct UAbilityTask_WaitMovementModeChange* CreateWaitMovementModeChange(struct UGameplayAbility* OwningAbility, enum class EMovementMode NewMode);
};

// Object: Class GameplayAbilities.AbilityTask_WaitOverlap
// Inherited Bytes: 0x78 | Struct Size: 0x88
struct UAbilityTask_WaitOverlap : UAbilityTask {
	// Fields
	struct FMulticastInlineDelegate OnOverlap; // Offset: 0x78 | Size: 0x10

	// Functions

	// Object: Function GameplayAbilities.AbilityTask_WaitOverlap.WaitForOverlap
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10123f980
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UAbilityTask_WaitOverlap* WaitForOverlap(struct UGameplayAbility* OwningAbility);

	// Object: Function GameplayAbilities.AbilityTask_WaitOverlap.OnHitCallback
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults]
	// Offset: 0x10123fa00
	// Return & Params: [ Num(5) Size(0xac) ]
	void OnHitCallback(struct UPrimitiveComponent* HitComp, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult& Hit);
};

// Object: Class GameplayAbilities.AbilityTask_WaitTargetData
// Inherited Bytes: 0x78 | Struct Size: 0xb8
struct UAbilityTask_WaitTargetData : UAbilityTask {
	// Fields
	struct FMulticastInlineDelegate ValidData; // Offset: 0x78 | Size: 0x10
	struct FMulticastInlineDelegate Cancelled; // Offset: 0x88 | Size: 0x10
	struct AGameplayAbilityTargetActor* TargetClass; // Offset: 0x98 | Size: 0x8
	struct AGameplayAbilityTargetActor* TargetActor; // Offset: 0xa0 | Size: 0x8
	char pad_0xA8[0x10]; // Offset: 0xa8 | Size: 0x10

	// Functions

	// Object: Function GameplayAbilities.AbilityTask_WaitTargetData.WaitTargetDataUsingActor
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x1012402a8
	// Return & Params: [ Num(5) Size(0x28) ]
	struct UAbilityTask_WaitTargetData* WaitTargetDataUsingActor(struct UGameplayAbility* OwningAbility, struct FName TaskInstanceName, enum class EGameplayTargetingConfirmation ConfirmationType, struct AGameplayAbilityTargetActor* TargetActor);

	// Object: Function GameplayAbilities.AbilityTask_WaitTargetData.WaitTargetData
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x101240408
	// Return & Params: [ Num(5) Size(0x28) ]
	struct UAbilityTask_WaitTargetData* WaitTargetData(struct UGameplayAbility* OwningAbility, struct FName TaskInstanceName, enum class EGameplayTargetingConfirmation ConfirmationType, struct AGameplayAbilityTargetActor* Class);

	// Object: Function GameplayAbilities.AbilityTask_WaitTargetData.OnTargetDataReplicatedCancelledCallback
	// Flags: [Final|Native|Public]
	// Offset: 0x1012407d0
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnTargetDataReplicatedCancelledCallback();

	// Object: Function GameplayAbilities.AbilityTask_WaitTargetData.OnTargetDataReplicatedCallback
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x1012407e4
	// Return & Params: [ Num(2) Size(0x30) ]
	void OnTargetDataReplicatedCallback(struct FGameplayAbilityTargetDataHandle& Data, struct FGameplayTag ActivationTag);

	// Object: Function GameplayAbilities.AbilityTask_WaitTargetData.OnTargetDataReadyCallback
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x10124069c
	// Return & Params: [ Num(1) Size(0x28) ]
	void OnTargetDataReadyCallback(struct FGameplayAbilityTargetDataHandle& Data);

	// Object: Function GameplayAbilities.AbilityTask_WaitTargetData.OnTargetDataCancelledCallback
	// Flags: [Final|Native|Public|HasOutParms]
	// Offset: 0x101240568
	// Return & Params: [ Num(1) Size(0x28) ]
	void OnTargetDataCancelledCallback(struct FGameplayAbilityTargetDataHandle& Data);

	// Object: Function GameplayAbilities.AbilityTask_WaitTargetData.K2_ExternalConfirm
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101240020
	// Return & Params: [ Num(1) Size(0x1) ]
	void K2_ExternalConfirm(bool bEndTask);

	// Object: Function GameplayAbilities.AbilityTask_WaitTargetData.K2_ExternalCancel
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101240004
	// Return & Params: [ Num(0) Size(0x0) ]
	void K2_ExternalCancel();

	// Object: Function GameplayAbilities.AbilityTask_WaitTargetData.FinishSpawningActor
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x1012400b0
	// Return & Params: [ Num(2) Size(0x10) ]
	void FinishSpawningActor(struct UGameplayAbility* OwningAbility, struct AGameplayAbilityTargetActor* SpawnedActor);

	// Object: Function GameplayAbilities.AbilityTask_WaitTargetData.BeginSpawningActor
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x101240178
	// Return & Params: [ Num(4) Size(0x19) ]
	bool BeginSpawningActor(struct UGameplayAbility* OwningAbility, struct AGameplayAbilityTargetActor* Class, struct AGameplayAbilityTargetActor*& SpawnedActor);
};

// Object: Class GameplayAbilities.AbilityTask_WaitVelocityChange
// Inherited Bytes: 0x78 | Struct Size: 0xa0
struct UAbilityTask_WaitVelocityChange : UAbilityTask {
	// Fields
	struct FMulticastInlineDelegate OnVelocityChage; // Offset: 0x78 | Size: 0x10
	struct UMovementComponent* CachedMovementComponent; // Offset: 0x88 | Size: 0x8
	char pad_0x90[0x10]; // Offset: 0x90 | Size: 0x10

	// Functions

	// Object: Function GameplayAbilities.AbilityTask_WaitVelocityChange.CreateWaitVelocityChange
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x101241018
	// Return & Params: [ Num(4) Size(0x20) ]
	struct UAbilityTask_WaitVelocityChange* CreateWaitVelocityChange(struct UGameplayAbility* OwningAbility, struct FVector Direction, float MinimumMagnitude);
};

// Object: Class GameplayAbilities.GameplayAbility
// Inherited Bytes: 0x28 | Struct Size: 0x400
struct UGameplayAbility : UObject {
	// Fields
	char pad_0x28[0x80]; // Offset: 0x28 | Size: 0x80
	struct FGameplayTagContainer AbilityTags; // Offset: 0xa8 | Size: 0x20
	bool bReplicateInputDirectly; // Offset: 0xc8 | Size: 0x1
	bool RemoteInstanceEnded; // Offset: 0xc9 | Size: 0x1
	char pad_0xCA[0x4]; // Offset: 0xca | Size: 0x4
	enum class EGameplayAbilityReplicationPolicy ReplicationPolicy; // Offset: 0xce | Size: 0x1
	enum class EGameplayAbilityInstancingPolicy InstancingPolicy; // Offset: 0xcf | Size: 0x1
	bool bServerRespectsRemoteAbilityCancellation; // Offset: 0xd0 | Size: 0x1
	bool bRetriggerInstancedAbility; // Offset: 0xd1 | Size: 0x1
	char pad_0xD2[0x6]; // Offset: 0xd2 | Size: 0x6
	struct FGameplayAbilityActivationInfo CurrentActivationInfo; // Offset: 0xd8 | Size: 0x20
	struct FGameplayEventData CurrentEventData; // Offset: 0xf8 | Size: 0xb0
	enum class EGameplayAbilityNetExecutionPolicy NetExecutionPolicy; // Offset: 0x1a8 | Size: 0x1
	enum class EGameplayAbilityNetSecurityPolicy NetSecurityPolicy; // Offset: 0x1a9 | Size: 0x1
	char pad_0x1AA[0x6]; // Offset: 0x1aa | Size: 0x6
	struct UGameplayEffect* CostGameplayEffectClass; // Offset: 0x1b0 | Size: 0x8
	struct TArray<struct FAbilityTriggerData> AbilityTriggers; // Offset: 0x1b8 | Size: 0x10
	struct UGameplayEffect* CooldownGameplayEffectClass; // Offset: 0x1c8 | Size: 0x8
	struct FGameplayTagQuery CancelAbilitiesMatchingTagQuery; // Offset: 0x1d0 | Size: 0x48
	struct FGameplayTagContainer CancelAbilitiesWithTag; // Offset: 0x218 | Size: 0x20
	struct FGameplayTagContainer BlockAbilitiesWithTag; // Offset: 0x238 | Size: 0x20
	struct FGameplayTagContainer ActivationOwnedTags; // Offset: 0x258 | Size: 0x20
	struct FGameplayTagContainer ActivationRequiredTags; // Offset: 0x278 | Size: 0x20
	struct FGameplayTagContainer ActivationBlockedTags; // Offset: 0x298 | Size: 0x20
	struct FGameplayTagContainer SourceRequiredTags; // Offset: 0x2b8 | Size: 0x20
	struct FGameplayTagContainer SourceBlockedTags; // Offset: 0x2d8 | Size: 0x20
	struct FGameplayTagContainer TargetRequiredTags; // Offset: 0x2f8 | Size: 0x20
	struct FGameplayTagContainer TargetBlockedTags; // Offset: 0x318 | Size: 0x20
	char pad_0x338[0x20]; // Offset: 0x338 | Size: 0x20
	struct TArray<struct UGameplayTask*> ActiveTasks; // Offset: 0x358 | Size: 0x10
	char pad_0x368[0x10]; // Offset: 0x368 | Size: 0x10
	struct UAnimMontage* CurrentMontage; // Offset: 0x378 | Size: 0x8
	char pad_0x380[0x60]; // Offset: 0x380 | Size: 0x60
	bool bIsActive; // Offset: 0x3e0 | Size: 0x1
	bool bIsCancelable; // Offset: 0x3e1 | Size: 0x1
	bool bIsBlockingOtherAbilities; // Offset: 0x3e2 | Size: 0x1
	char pad_0x3E3[0x15]; // Offset: 0x3e3 | Size: 0x15
	bool bMarkPendingKillOnAbilityEnd; // Offset: 0x3f8 | Size: 0x1
	char pad_0x3F9[0x7]; // Offset: 0x3f9 | Size: 0x7

	// Functions

	// Object: Function GameplayAbilities.GameplayAbility.SetShouldBlockOtherAbilities
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x101243bf4
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetShouldBlockOtherAbilities(bool bShouldBlockAbilities);

	// Object: Function GameplayAbilities.GameplayAbility.SetCanBeCanceled
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x101243b50
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetCanBeCanceled(bool bCanBeCanceled);

	// Object: Function GameplayAbilities.GameplayAbility.SendGameplayEvent
	// Flags: [Native|Protected|BlueprintCallable]
	// Offset: 0x101243620
	// Return & Params: [ Num(2) Size(0xb8) ]
	void SendGameplayEvent(struct FGameplayTag EventTag, struct FGameplayEventData Payload);

	// Object: Function GameplayAbilities.GameplayAbility.RemoveGrantedByEffect
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x101243838
	// Return & Params: [ Num(0) Size(0x0) ]
	void RemoveGrantedByEffect();

	// Object: Function GameplayAbilities.GameplayAbility.MontageStop
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x101241d08
	// Return & Params: [ Num(1) Size(0x4) ]
	void MontageStop(float OverrideBlendOutTime);

	// Object: Function GameplayAbilities.GameplayAbility.MontageSetNextSectionName
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x101241d88
	// Return & Params: [ Num(2) Size(0x10) ]
	void MontageSetNextSectionName(struct FName FromSectionName, struct FName ToSectionName);

	// Object: Function GameplayAbilities.GameplayAbility.MontageJumpToSection
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x101241e50
	// Return & Params: [ Num(1) Size(0x8) ]
	void MontageJumpToSection(struct FName SectionName);

	// Object: Function GameplayAbilities.GameplayAbility.MakeTargetLocationInfoFromOwnerSkeletalMeshComponent
	// Flags: [Final|Native|Protected|BlueprintCallable|BlueprintPure]
	// Offset: 0x101241b84
	// Return & Params: [ Num(2) Size(0x70) ]
	struct FGameplayAbilityTargetingLocationInfo MakeTargetLocationInfoFromOwnerSkeletalMeshComponent(struct FName SocketName);

	// Object: Function GameplayAbilities.GameplayAbility.MakeTargetLocationInfoFromOwnerActor
	// Flags: [Final|Native|Protected|BlueprintCallable|BlueprintPure]
	// Offset: 0x101241c70
	// Return & Params: [ Num(1) Size(0x60) ]
	struct FGameplayAbilityTargetingLocationInfo MakeTargetLocationInfoFromOwnerActor();

	// Object: Function GameplayAbilities.GameplayAbility.MakeOutgoingGameplayEffectSpec
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x101243cb8
	// Return & Params: [ Num(3) Size(0x20) ]
	struct FGameplayEffectSpecHandle MakeOutgoingGameplayEffectSpec(struct UGameplayEffect* GameplayEffectClass, float Level);

	// Object: Function GameplayAbilities.GameplayAbility.K2_ShouldAbilityRespondToEvent
	// Flags: [Event|Protected|BlueprintEvent|Const]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0xf9) ]
	bool K2_ShouldAbilityRespondToEvent(struct FGameplayAbilityActorInfo ActorInfo, struct FGameplayEventData Payload);

	// Object: Function GameplayAbilities.GameplayAbility.K2_RemoveGameplayCue
	// Flags: [Native|Protected|BlueprintCallable]
	// Offset: 0x101242124
	// Return & Params: [ Num(1) Size(0x8) ]
	void K2_RemoveGameplayCue(struct FGameplayTag GameplayCueTag);

	// Object: Function GameplayAbilities.GameplayAbility.K2_OnEndAbility
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void K2_OnEndAbility(bool bWasCancelled);

	// Object: Function GameplayAbilities.GameplayAbility.K2_ExecuteGameplayCueWithParams
	// Flags: [Native|Protected|HasOutParms|BlueprintCallable]
	// Offset: 0x1012425c0
	// Return & Params: [ Num(2) Size(0xc8) ]
	void K2_ExecuteGameplayCueWithParams(struct FGameplayTag GameplayCueTag, struct FGameplayCueParameters& GameplayCueParameters);

	// Object: Function GameplayAbilities.GameplayAbility.K2_ExecuteGameplayCue
	// Flags: [Native|Protected|BlueprintCallable]
	// Offset: 0x10124277c
	// Return & Params: [ Num(2) Size(0x20) ]
	void K2_ExecuteGameplayCue(struct FGameplayTag GameplayCueTag, struct FGameplayEffectContextHandle Context);

	// Object: Function GameplayAbilities.GameplayAbility.K2_EndAbility
	// Flags: [Native|Protected|BlueprintCallable]
	// Offset: 0x101243604
	// Return & Params: [ Num(0) Size(0x0) ]
	void K2_EndAbility();

	// Object: Function GameplayAbilities.GameplayAbility.K2_CommitExecute
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void K2_CommitExecute();

	// Object: Function GameplayAbilities.GameplayAbility.K2_CommitAbilityCost
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x10124397c
	// Return & Params: [ Num(2) Size(0x2) ]
	bool K2_CommitAbilityCost(bool BroadcastCommitEvent);

	// Object: Function GameplayAbilities.GameplayAbility.K2_CommitAbilityCooldown
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x101243a1c
	// Return & Params: [ Num(3) Size(0x3) ]
	bool K2_CommitAbilityCooldown(bool BroadcastCommitEvent, bool ForceCooldown);

	// Object: Function GameplayAbilities.GameplayAbility.K2_CommitAbility
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x101243b14
	// Return & Params: [ Num(1) Size(0x1) ]
	bool K2_CommitAbility();

	// Object: Function GameplayAbilities.GameplayAbility.K2_CheckAbilityCost
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x101243904
	// Return & Params: [ Num(1) Size(0x1) ]
	bool K2_CheckAbilityCost();

	// Object: Function GameplayAbilities.GameplayAbility.K2_CheckAbilityCooldown
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x101243940
	// Return & Params: [ Num(1) Size(0x1) ]
	bool K2_CheckAbilityCooldown();

	// Object: Function GameplayAbilities.GameplayAbility.K2_CancelAbility
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x101243be0
	// Return & Params: [ Num(0) Size(0x0) ]
	void K2_CancelAbility();

	// Object: Function GameplayAbilities.GameplayAbility.K2_CanActivateAbility
	// Flags: [Event|Protected|HasOutParms|BlueprintEvent|Const]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0x69) ]
	bool K2_CanActivateAbility(struct FGameplayAbilityActorInfo ActorInfo, struct FGameplayTagContainer& RelevantTags);

	// Object: Function GameplayAbilities.GameplayAbility.K2_ApplyGameplayEffectSpecToTarget
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x101242c30
	// Return & Params: [ Num(3) Size(0x48) ]
	struct TArray<struct FActiveGameplayEffectHandle> K2_ApplyGameplayEffectSpecToTarget(struct FGameplayEffectSpecHandle EffectSpecHandle, struct FGameplayAbilityTargetDataHandle TargetData);

	// Object: Function GameplayAbilities.GameplayAbility.K2_ApplyGameplayEffectSpecToOwner
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x10124336c
	// Return & Params: [ Num(2) Size(0x18) ]
	struct FActiveGameplayEffectHandle K2_ApplyGameplayEffectSpecToOwner(struct FGameplayEffectSpecHandle EffectSpecHandle);

	// Object: Function GameplayAbilities.GameplayAbility.K2_AddGameplayCueWithParams
	// Flags: [Native|Protected|HasOutParms|BlueprintCallable]
	// Offset: 0x1012421ac
	// Return & Params: [ Num(3) Size(0xc9) ]
	void K2_AddGameplayCueWithParams(struct FGameplayTag GameplayCueTag, struct FGameplayCueParameters& GameplayCueParameter, bool bRemoveOnAbilityEnd);

	// Object: Function GameplayAbilities.GameplayAbility.K2_AddGameplayCue
	// Flags: [Native|Protected|BlueprintCallable]
	// Offset: 0x1012423b4
	// Return & Params: [ Num(3) Size(0x21) ]
	void K2_AddGameplayCue(struct FGameplayTag GameplayCueTag, struct FGameplayEffectContextHandle Context, bool bRemoveOnAbilityEnd);

	// Object: Function GameplayAbilities.GameplayAbility.K2_ActivateAbilityFromEvent
	// Flags: [Event|Protected|HasOutParms|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0xb0) ]
	void K2_ActivateAbilityFromEvent(struct FGameplayEventData& EventData);

	// Object: Function GameplayAbilities.GameplayAbility.K2_ActivateAbility
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void K2_ActivateAbility();

	// Object: Function GameplayAbilities.GameplayAbility.InvalidateClientPredictionKey
	// Flags: [Final|Native|Public|BlueprintCallable|Const]
	// Offset: 0x101243854
	// Return & Params: [ Num(0) Size(0x0) ]
	void InvalidateClientPredictionKey();

	// Object: Function GameplayAbilities.GameplayAbility.GetOwningComponentFromActorInfo
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x101244304
	// Return & Params: [ Num(1) Size(0x8) ]
	struct USkeletalMeshComponent* GetOwningComponentFromActorInfo();

	// Object: Function GameplayAbilities.GameplayAbility.GetOwningActorFromActorInfo
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10124436c
	// Return & Params: [ Num(1) Size(0x8) ]
	struct AActor* GetOwningActorFromActorInfo();

	// Object: Function GameplayAbilities.GameplayAbility.GetGrantedByEffectContext
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1012441b8
	// Return & Params: [ Num(1) Size(0x18) ]
	struct FGameplayEffectContextHandle GetGrantedByEffectContext();

	// Object: Function GameplayAbilities.GameplayAbility.GetCurrentSourceObject
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x101243868
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UObject* GetCurrentSourceObject();

	// Object: Function GameplayAbilities.GameplayAbility.GetCurrentMontage
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1012438d0
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UAnimMontage* GetCurrentMontage();

	// Object: Function GameplayAbilities.GameplayAbility.GetCooldownTimeRemaining
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x101243c84
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetCooldownTimeRemaining();

	// Object: Function GameplayAbilities.GameplayAbility.GetContextFromOwner
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x101243e6c
	// Return & Params: [ Num(2) Size(0x40) ]
	struct FGameplayEffectContextHandle GetContextFromOwner(struct FGameplayAbilityTargetDataHandle OptionalTargetData);

	// Object: Function GameplayAbilities.GameplayAbility.GetAvatarActorFromActorInfo
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x101244338
	// Return & Params: [ Num(1) Size(0x8) ]
	struct AActor* GetAvatarActorFromActorInfo();

	// Object: Function GameplayAbilities.GameplayAbility.GetActorInfo
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1012443a0
	// Return & Params: [ Num(1) Size(0x48) ]
	struct FGameplayAbilityActorInfo GetActorInfo();

	// Object: Function GameplayAbilities.GameplayAbility.GetAbilitySystemComponentFromActorInfo
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x1012442d0
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UAbilitySystemComponent* GetAbilitySystemComponentFromActorInfo();

	// Object: Function GameplayAbilities.GameplayAbility.GetAbilityLevel
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10124389c
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetAbilityLevel();

	// Object: Function GameplayAbilities.GameplayAbility.EndTaskByInstanceName
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x101241fd0
	// Return & Params: [ Num(1) Size(0x8) ]
	void EndTaskByInstanceName(struct FName InstanceName);

	// Object: Function GameplayAbilities.GameplayAbility.EndAbilityState
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x101241ed0
	// Return & Params: [ Num(1) Size(0x8) ]
	void EndAbilityState(struct FName OptionalStateNameToEnd);

	// Object: Function GameplayAbilities.GameplayAbility.ConfirmTaskByInstanceName
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x101242050
	// Return & Params: [ Num(2) Size(0x9) ]
	void ConfirmTaskByInstanceName(struct FName InstanceName, bool bEndTask);

	// Object: Function GameplayAbilities.GameplayAbility.CancelTaskByInstanceName
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x101241f50
	// Return & Params: [ Num(1) Size(0x8) ]
	void CancelTaskByInstanceName(struct FName InstanceName);

	// Object: Function GameplayAbilities.GameplayAbility.BP_RemoveGameplayEffectFromOwnerWithHandle
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x101242934
	// Return & Params: [ Num(2) Size(0xc) ]
	void BP_RemoveGameplayEffectFromOwnerWithHandle(struct FActiveGameplayEffectHandle Handle, int32_t StacksToRemove);

	// Object: Function GameplayAbilities.GameplayAbility.BP_RemoveGameplayEffectFromOwnerWithGrantedTags
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x101242a08
	// Return & Params: [ Num(2) Size(0x24) ]
	void BP_RemoveGameplayEffectFromOwnerWithGrantedTags(struct FGameplayTagContainer WithGrantedTags, int32_t StacksToRemove);

	// Object: Function GameplayAbilities.GameplayAbility.BP_RemoveGameplayEffectFromOwnerWithAssetTags
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x101242b1c
	// Return & Params: [ Num(2) Size(0x24) ]
	void BP_RemoveGameplayEffectFromOwnerWithAssetTags(struct FGameplayTagContainer WithAssetTags, int32_t StacksToRemove);

	// Object: Function GameplayAbilities.GameplayAbility.BP_ApplyGameplayEffectToTarget
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x101242fe8
	// Return & Params: [ Num(5) Size(0x48) ]
	struct TArray<struct FActiveGameplayEffectHandle> BP_ApplyGameplayEffectToTarget(struct FGameplayAbilityTargetDataHandle TargetData, struct UGameplayEffect* GameplayEffectClass, int32_t GameplayEffectLevel, int32_t Stacks);

	// Object: Function GameplayAbilities.GameplayAbility.BP_ApplyGameplayEffectToOwner
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x1012434d8
	// Return & Params: [ Num(4) Size(0x18) ]
	struct FActiveGameplayEffectHandle BP_ApplyGameplayEffectToOwner(struct UGameplayEffect* GameplayEffectClass, int32_t GameplayEffectLevel, int32_t Stacks);
};

// Object: Class GameplayAbilities.GameplayAbility_CharacterJump
// Inherited Bytes: 0x400 | Struct Size: 0x400
struct UGameplayAbility_CharacterJump : UGameplayAbility {
};

// Object: Class GameplayAbilities.GameplayAbility_Montage
// Inherited Bytes: 0x400 | Struct Size: 0x438
struct UGameplayAbility_Montage : UGameplayAbility {
	// Fields
	struct UAnimMontage* MontageToPlay; // Offset: 0x400 | Size: 0x8
	float PlayRate; // Offset: 0x408 | Size: 0x4
	struct FName SectionName; // Offset: 0x40c | Size: 0x8
	char pad_0x414[0x4]; // Offset: 0x414 | Size: 0x4
	struct TArray<struct UGameplayEffect*> GameplayEffectClassesWhileAnimating; // Offset: 0x418 | Size: 0x10
	struct TArray<struct UGameplayEffect*> GameplayEffectsWhileAnimating; // Offset: 0x428 | Size: 0x10
};

// Object: Class GameplayAbilities.GameplayAbilityBlueprint
// Inherited Bytes: 0xa0 | Struct Size: 0xa0
struct UGameplayAbilityBlueprint : UBlueprint {
};

// Object: Class GameplayAbilities.GameplayAbilitySet
// Inherited Bytes: 0x30 | Struct Size: 0x40
struct UGameplayAbilitySet : UDataAsset {
	// Fields
	struct TArray<struct FGameplayAbilityBindInfo> Abilities; // Offset: 0x30 | Size: 0x10
};

// Object: Class GameplayAbilities.GameplayAbilityTargetActor
// Inherited Bytes: 0x228 | Struct Size: 0x330
struct AGameplayAbilityTargetActor : AActor {
	// Fields
	bool ShouldProduceTargetDataOnServer; // Offset: 0x228 | Size: 0x1
	char pad_0x229[0x7]; // Offset: 0x229 | Size: 0x7
	struct FGameplayAbilityTargetingLocationInfo StartLocation; // Offset: 0x230 | Size: 0x60
	char pad_0x290[0x30]; // Offset: 0x290 | Size: 0x30
	struct APlayerController* MasterPC; // Offset: 0x2c0 | Size: 0x8
	struct UGameplayAbility* OwningAbility; // Offset: 0x2c8 | Size: 0x8
	bool bDestroyOnConfirmation; // Offset: 0x2d0 | Size: 0x1
	char pad_0x2D1[0x7]; // Offset: 0x2d1 | Size: 0x7
	struct AActor* SourceActor; // Offset: 0x2d8 | Size: 0x8
	struct FWorldReticleParameters ReticleParams; // Offset: 0x2e0 | Size: 0xc
	char pad_0x2EC[0x4]; // Offset: 0x2ec | Size: 0x4
	struct AGameplayAbilityWorldReticle* ReticleClass; // Offset: 0x2f0 | Size: 0x8
	struct FGameplayTargetDataFilterHandle Filter; // Offset: 0x2f8 | Size: 0x10
	bool bDebug; // Offset: 0x308 | Size: 0x1
	char pad_0x309[0x17]; // Offset: 0x309 | Size: 0x17
	struct UAbilitySystemComponent* GenericDelegateBoundASC; // Offset: 0x320 | Size: 0x8
	char pad_0x328[0x8]; // Offset: 0x328 | Size: 0x8

	// Functions

	// Object: Function GameplayAbilities.GameplayAbilityTargetActor.ConfirmTargeting
	// Flags: [Native|Public]
	// Offset: 0x101248834
	// Return & Params: [ Num(0) Size(0x0) ]
	void ConfirmTargeting();

	// Object: Function GameplayAbilities.GameplayAbilityTargetActor.CancelTargeting
	// Flags: [Native|Public]
	// Offset: 0x101248818
	// Return & Params: [ Num(0) Size(0x0) ]
	void CancelTargeting();
};

// Object: Class GameplayAbilities.GameplayAbilityTargetActor_Trace
// Inherited Bytes: 0x330 | Struct Size: 0x340
struct AGameplayAbilityTargetActor_Trace : AGameplayAbilityTargetActor {
	// Fields
	float MaxRange; // Offset: 0x328 | Size: 0x4
	struct FCollisionProfileName TraceProfile; // Offset: 0x32c | Size: 0x8
	bool bTraceAffectsAimPitch; // Offset: 0x334 | Size: 0x1
	char pad_0x33D[0x3]; // Offset: 0x33d | Size: 0x3
};

// Object: Class GameplayAbilities.GameplayAbilityTargetActor_GroundTrace
// Inherited Bytes: 0x340 | Struct Size: 0x360
struct AGameplayAbilityTargetActor_GroundTrace : AGameplayAbilityTargetActor_Trace {
	// Fields
	float CollisionRadius; // Offset: 0x340 | Size: 0x4
	float CollisionHeight; // Offset: 0x344 | Size: 0x4
	char pad_0x348[0x18]; // Offset: 0x348 | Size: 0x18
};

// Object: Class GameplayAbilities.GameplayAbilityTargetActor_ActorPlacement
// Inherited Bytes: 0x360 | Struct Size: 0x380
struct AGameplayAbilityTargetActor_ActorPlacement : AGameplayAbilityTargetActor_GroundTrace {
	// Fields
	struct UObject* PlacedActorClass; // Offset: 0x360 | Size: 0x8
	struct UMaterialInterface* PlacedActorMaterial; // Offset: 0x368 | Size: 0x8
	char pad_0x370[0x10]; // Offset: 0x370 | Size: 0x10
};

// Object: Class GameplayAbilities.GameplayAbilityTargetActor_Radius
// Inherited Bytes: 0x330 | Struct Size: 0x330
struct AGameplayAbilityTargetActor_Radius : AGameplayAbilityTargetActor {
	// Fields
	float Radius; // Offset: 0x328 | Size: 0x4
};

// Object: Class GameplayAbilities.GameplayAbilityTargetActor_SingleLineTrace
// Inherited Bytes: 0x340 | Struct Size: 0x340
struct AGameplayAbilityTargetActor_SingleLineTrace : AGameplayAbilityTargetActor_Trace {
};

// Object: Class GameplayAbilities.GameplayAbilityWorldReticle
// Inherited Bytes: 0x228 | Struct Size: 0x248
struct AGameplayAbilityWorldReticle : AActor {
	// Fields
	struct FWorldReticleParameters Parameters; // Offset: 0x228 | Size: 0xc
	bool bFaceOwnerFlat; // Offset: 0x234 | Size: 0x1
	bool bSnapToTargetedActor; // Offset: 0x235 | Size: 0x1
	bool bIsTargetValid; // Offset: 0x236 | Size: 0x1
	bool bIsTargetAnActor; // Offset: 0x237 | Size: 0x1
	struct APlayerController* MasterPC; // Offset: 0x238 | Size: 0x8
	struct AActor* TargetingActor; // Offset: 0x240 | Size: 0x8

	// Functions

	// Object: Function GameplayAbilities.GameplayAbilityWorldReticle.SetReticleMaterialParamVector
	// Flags: [Event|Public|HasDefaults|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x14) ]
	void SetReticleMaterialParamVector(struct FName ParamName, struct FVector Value);

	// Object: Function GameplayAbilities.GameplayAbilityWorldReticle.SetReticleMaterialParamFloat
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0xc) ]
	void SetReticleMaterialParamFloat(struct FName ParamName, float Value);

	// Object: Function GameplayAbilities.GameplayAbilityWorldReticle.OnValidTargetChanged
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnValidTargetChanged(bool bNewValue);

	// Object: Function GameplayAbilities.GameplayAbilityWorldReticle.OnTargetingAnActor
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnTargetingAnActor(bool bNewValue);

	// Object: Function GameplayAbilities.GameplayAbilityWorldReticle.OnParametersInitialized
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnParametersInitialized();

	// Object: Function GameplayAbilities.GameplayAbilityWorldReticle.FaceTowardSource
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10124aa44
	// Return & Params: [ Num(1) Size(0x1) ]
	void FaceTowardSource(bool bFaceIn2D);
};

// Object: Class GameplayAbilities.GameplayAbilityWorldReticle_ActorVisualization
// Inherited Bytes: 0x248 | Struct Size: 0x260
struct AGameplayAbilityWorldReticle_ActorVisualization : AGameplayAbilityWorldReticle {
	// Fields
	struct UCapsuleComponent* CollisionComponent; // Offset: 0x248 | Size: 0x8
	struct TArray<struct UActorComponent*> VisualizationComponents; // Offset: 0x250 | Size: 0x10
};

// Object: Class GameplayAbilities.GameplayCueInterface
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UGameplayCueInterface : UInterface {
	// Functions

	// Object: Function GameplayAbilities.GameplayCueInterface.ForwardGameplayCueToParent
	// Flags: [BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x101254c44
	// Return & Params: [ Num(0) Size(0x0) ]
	void ForwardGameplayCueToParent();

	// Object: Function GameplayAbilities.GameplayCueInterface.BlueprintCustomHandler
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0xc8) ]
	void BlueprintCustomHandler(enum class EGameplayCueEvent EventType, struct FGameplayCueParameters Parameters);
};

// Object: Class GameplayAbilities.GameplayCueManager
// Inherited Bytes: 0x30 | Struct Size: 0x310
struct UGameplayCueManager : UDataAsset {
	// Fields
	char pad_0x30[0x18]; // Offset: 0x30 | Size: 0x18
	struct FGameplayCueObjectLibrary RuntimeGameplayCueObjectLibrary; // Offset: 0x48 | Size: 0x50
	struct FGameplayCueObjectLibrary EditorGameplayCueObjectLibrary; // Offset: 0x98 | Size: 0x50
	char pad_0xE8[0x1c8]; // Offset: 0xe8 | Size: 0x1c8
	struct TArray<struct UObject*> LoadedGameplayCueNotifyClasses; // Offset: 0x2b0 | Size: 0x10
	struct TArray<struct AGameplayCueNotify_Actor*> GameplayCueClassesForPreallocation; // Offset: 0x2c0 | Size: 0x10
	struct TArray<struct FGameplayCuePendingExecute> PendingExecuteCues; // Offset: 0x2d0 | Size: 0x10
	int32_t GameplayCueSendContextCount; // Offset: 0x2e0 | Size: 0x4
	char pad_0x2E4[0x4]; // Offset: 0x2e4 | Size: 0x4
	struct TArray<struct FPreallocationInfo> PreallocationInfoList_Internal; // Offset: 0x2e8 | Size: 0x10
	char pad_0x2F8[0x18]; // Offset: 0x2f8 | Size: 0x18
};

// Object: Class GameplayAbilities.GameplayCueNotify_Actor
// Inherited Bytes: 0x228 | Struct Size: 0x298
struct AGameplayCueNotify_Actor : AActor {
	// Fields
	bool bAutoDestroyOnRemove; // Offset: 0x228 | Size: 0x1
	char pad_0x229[0x3]; // Offset: 0x229 | Size: 0x3
	float AutoDestroyDelay; // Offset: 0x22c | Size: 0x4
	bool WarnIfTimelineIsStillRunning; // Offset: 0x230 | Size: 0x1
	bool WarnIfLatentActionIsStillRunning; // Offset: 0x231 | Size: 0x1
	char pad_0x232[0x2]; // Offset: 0x232 | Size: 0x2
	struct FGameplayTag GameplayCueTag; // Offset: 0x234 | Size: 0x8
	char pad_0x23C[0x4]; // Offset: 0x23c | Size: 0x4
	struct FGameplayTagReferenceHelper ReferenceHelper; // Offset: 0x240 | Size: 0x10
	struct FName GameplayCueName; // Offset: 0x250 | Size: 0x8
	bool bAutoAttachToOwner; // Offset: 0x258 | Size: 0x1
	bool IsOverride; // Offset: 0x259 | Size: 0x1
	bool bUniqueInstancePerInstigator; // Offset: 0x25a | Size: 0x1
	bool bUniqueInstancePerSourceObject; // Offset: 0x25b | Size: 0x1
	bool bAllowMultipleOnActiveEvents; // Offset: 0x25c | Size: 0x1
	bool bAllowMultipleWhileActiveEvents; // Offset: 0x25d | Size: 0x1
	char pad_0x25E[0x2]; // Offset: 0x25e | Size: 0x2
	int32_t NumPreallocatedInstances; // Offset: 0x260 | Size: 0x4
	char pad_0x264[0x34]; // Offset: 0x264 | Size: 0x34

	// Functions

	// Object: Function GameplayAbilities.GameplayCueNotify_Actor.WhileActive
	// Flags: [Native|Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x101255674
	// Return & Params: [ Num(3) Size(0xc9) ]
	bool WhileActive(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters);

	// Object: Function GameplayAbilities.GameplayCueNotify_Actor.OnRemove
	// Flags: [Native|Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x1012554b0
	// Return & Params: [ Num(3) Size(0xc9) ]
	bool OnRemove(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters);

	// Object: Function GameplayAbilities.GameplayCueNotify_Actor.OnOwnerDestroyed
	// Flags: [Native|Public]
	// Offset: 0x101255bdc
	// Return & Params: [ Num(1) Size(0x8) ]
	void OnOwnerDestroyed(struct AActor* DestroyedActor);

	// Object: Function GameplayAbilities.GameplayCueNotify_Actor.OnExecute
	// Flags: [Native|Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x1012559fc
	// Return & Params: [ Num(3) Size(0xc9) ]
	bool OnExecute(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters);

	// Object: Function GameplayAbilities.GameplayCueNotify_Actor.OnActive
	// Flags: [Native|Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x101255838
	// Return & Params: [ Num(3) Size(0xc9) ]
	bool OnActive(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters);

	// Object: Function GameplayAbilities.GameplayCueNotify_Actor.K2_HandleGameplayCue
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0xd0) ]
	void K2_HandleGameplayCue(struct AActor* MyTarget, enum class EGameplayCueEvent EventType, struct FGameplayCueParameters& Parameters);

	// Object: Function GameplayAbilities.GameplayCueNotify_Actor.K2_EndGameplayCue
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x101255bc0
	// Return & Params: [ Num(0) Size(0x0) ]
	void K2_EndGameplayCue();
};

// Object: Class GameplayAbilities.GameplayCueNotify_Static
// Inherited Bytes: 0x28 | Struct Size: 0x50
struct UGameplayCueNotify_Static : UObject {
	// Fields
	struct FGameplayTag GameplayCueTag; // Offset: 0x28 | Size: 0x8
	struct FGameplayTagReferenceHelper ReferenceHelper; // Offset: 0x30 | Size: 0x10
	struct FName GameplayCueName; // Offset: 0x40 | Size: 0x8
	bool IsOverride; // Offset: 0x48 | Size: 0x1
	char pad_0x49[0x7]; // Offset: 0x49 | Size: 0x7

	// Functions

	// Object: Function GameplayAbilities.GameplayCueNotify_Static.WhileActive
	// Flags: [Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const]
	// Offset: 0x101257010
	// Return & Params: [ Num(3) Size(0xc9) ]
	bool WhileActive(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters);

	// Object: Function GameplayAbilities.GameplayCueNotify_Static.OnRemove
	// Flags: [Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const]
	// Offset: 0x101256e4c
	// Return & Params: [ Num(3) Size(0xc9) ]
	bool OnRemove(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters);

	// Object: Function GameplayAbilities.GameplayCueNotify_Static.OnExecute
	// Flags: [Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const]
	// Offset: 0x101257398
	// Return & Params: [ Num(3) Size(0xc9) ]
	bool OnExecute(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters);

	// Object: Function GameplayAbilities.GameplayCueNotify_Static.OnActive
	// Flags: [Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const]
	// Offset: 0x1012571d4
	// Return & Params: [ Num(3) Size(0xc9) ]
	bool OnActive(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters);

	// Object: Function GameplayAbilities.GameplayCueNotify_Static.K2_HandleGameplayCue
	// Flags: [Event|Public|HasOutParms|BlueprintEvent|Const]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0xd0) ]
	void K2_HandleGameplayCue(struct AActor* MyTarget, enum class EGameplayCueEvent EventType, struct FGameplayCueParameters& Parameters);
};

// Object: Class GameplayAbilities.GameplayCueNotify_HitImpact
// Inherited Bytes: 0x50 | Struct Size: 0x60
struct UGameplayCueNotify_HitImpact : UGameplayCueNotify_Static {
	// Fields
	struct USoundBase* Sound; // Offset: 0x50 | Size: 0x8
	struct UParticleSystem* ParticleSystem; // Offset: 0x58 | Size: 0x8
};

// Object: Class GameplayAbilities.GameplayCueSet
// Inherited Bytes: 0x30 | Struct Size: 0x90
struct UGameplayCueSet : UDataAsset {
	// Fields
	struct TArray<struct FGameplayCueNotifyData> GameplayCueData; // Offset: 0x30 | Size: 0x10
	char pad_0x40[0x50]; // Offset: 0x40 | Size: 0x50
};

// Object: Class GameplayAbilities.GameplayCueTranslator
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UGameplayCueTranslator : UObject {
};

// Object: Class GameplayAbilities.GameplayCueTranslator_Test
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UGameplayCueTranslator_Test : UGameplayCueTranslator {
};

// Object: Class GameplayAbilities.GameplayEffect
// Inherited Bytes: 0x28 | Struct Size: 0x848
struct UGameplayEffect : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 | Size: 0x8
	enum class EGameplayEffectDurationType DurationPolicy; // Offset: 0x30 | Size: 0x1
	char pad_0x31[0x7]; // Offset: 0x31 | Size: 0x7
	struct FGameplayEffectModifierMagnitude DurationMagnitude; // Offset: 0x38 | Size: 0x1a8
	struct FScalableFloat Period; // Offset: 0x1e0 | Size: 0x20
	bool bExecutePeriodicEffectOnApplication; // Offset: 0x200 | Size: 0x1
	enum class EGameplayEffectPeriodInhibitionRemovedPolicy PeriodicInhibitionPolicy; // Offset: 0x201 | Size: 0x1
	char pad_0x202[0x6]; // Offset: 0x202 | Size: 0x6
	struct TArray<struct FGameplayModifierInfo> Modifiers; // Offset: 0x208 | Size: 0x10
	struct TArray<struct FGameplayEffectExecutionDefinition> Executions; // Offset: 0x218 | Size: 0x10
	struct FScalableFloat ChanceToApplyToTarget; // Offset: 0x228 | Size: 0x20
	struct TArray<struct UGameplayEffectCustomApplicationRequirement*> ApplicationRequirements; // Offset: 0x248 | Size: 0x10
	struct TArray<struct UGameplayEffect*> TargetEffectClasses; // Offset: 0x258 | Size: 0x10
	struct TArray<struct FConditionalGameplayEffect> ConditionalGameplayEffects; // Offset: 0x268 | Size: 0x10
	struct TArray<struct UGameplayEffect*> OverflowEffects; // Offset: 0x278 | Size: 0x10
	bool bDenyOverflowApplication; // Offset: 0x288 | Size: 0x1
	bool bClearStackOnOverflow; // Offset: 0x289 | Size: 0x1
	char pad_0x28A[0x6]; // Offset: 0x28a | Size: 0x6
	struct TArray<struct UGameplayEffect*> PrematureExpirationEffectClasses; // Offset: 0x290 | Size: 0x10
	struct TArray<struct UGameplayEffect*> RoutineExpirationEffectClasses; // Offset: 0x2a0 | Size: 0x10
	bool bRequireModifierSuccessToTriggerCues; // Offset: 0x2b0 | Size: 0x1
	bool bSuppressStackingCues; // Offset: 0x2b1 | Size: 0x1
	char pad_0x2B2[0x6]; // Offset: 0x2b2 | Size: 0x6
	struct TArray<struct FGameplayEffectCue> GameplayCues; // Offset: 0x2b8 | Size: 0x10
	struct UGameplayEffectUIData* UIData; // Offset: 0x2c8 | Size: 0x8
	struct FInheritedTagContainer InheritableGameplayEffectTags; // Offset: 0x2d0 | Size: 0x60
	struct FInheritedTagContainer InheritableOwnedTagsContainer; // Offset: 0x330 | Size: 0x60
	struct FGameplayTagRequirements OngoingTagRequirements; // Offset: 0x390 | Size: 0x50
	struct FGameplayTagRequirements ApplicationTagRequirements; // Offset: 0x3e0 | Size: 0x50
	struct FGameplayTagRequirements RemovalTagRequirements; // Offset: 0x430 | Size: 0x50
	struct FGameplayTagRequirements RemovalSourceTagRequirements; // Offset: 0x480 | Size: 0x50
	struct FInheritedTagContainer RemoveGameplayEffectsWithTags; // Offset: 0x4d0 | Size: 0x60
	struct FGameplayTagRequirements GrantedApplicationImmunityTags; // Offset: 0x530 | Size: 0x50
	struct FGameplayEffectQuery GrantedApplicationImmunityQuery; // Offset: 0x580 | Size: 0x150
	char pad_0x6D0[0x8]; // Offset: 0x6d0 | Size: 0x8
	struct FGameplayEffectQuery RemoveGameplayEffectQuery; // Offset: 0x6d8 | Size: 0x150
	char pad_0x828[0x1]; // Offset: 0x828 | Size: 0x1
	enum class EGameplayEffectStackingType StackingType; // Offset: 0x829 | Size: 0x1
	char pad_0x82A[0x2]; // Offset: 0x82a | Size: 0x2
	int32_t StackLimitCount; // Offset: 0x82c | Size: 0x4
	enum class EGameplayEffectStackingDurationPolicy StackDurationRefreshPolicy; // Offset: 0x830 | Size: 0x1
	enum class EGameplayEffectStackingPeriodPolicy StackPeriodResetPolicy; // Offset: 0x831 | Size: 0x1
	enum class EGameplayEffectStackingExpirationPolicy StackExpirationPolicy; // Offset: 0x832 | Size: 0x1
	char pad_0x833[0x5]; // Offset: 0x833 | Size: 0x5
	struct TArray<struct FGameplayAbilitySpecDef> GrantedAbilities; // Offset: 0x838 | Size: 0x10
};

// Object: Class GameplayAbilities.GameplayEffectCalculation
// Inherited Bytes: 0x28 | Struct Size: 0x38
struct UGameplayEffectCalculation : UObject {
	// Fields
	struct TArray<struct FGameplayEffectAttributeCaptureDefinition> RelevantAttributesToCapture; // Offset: 0x28 | Size: 0x10
};

// Object: Class GameplayAbilities.GameplayEffectCustomApplicationRequirement
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UGameplayEffectCustomApplicationRequirement : UObject {
	// Functions

	// Object: Function GameplayAbilities.GameplayEffectCustomApplicationRequirement.CanApplyGameplayEffect
	// Flags: [Native|Event|Public|HasOutParms|BlueprintEvent|Const]
	// Offset: 0x101262d38
	// Return & Params: [ Num(4) Size(0x2a9) ]
	bool CanApplyGameplayEffect(struct UGameplayEffect* GameplayEffect, struct FGameplayEffectSpec& Spec, struct UAbilitySystemComponent* ASC);
};

// Object: Class GameplayAbilities.GameplayEffectExecutionCalculation
// Inherited Bytes: 0x38 | Struct Size: 0x40
struct UGameplayEffectExecutionCalculation : UGameplayEffectCalculation {
	// Fields
	bool bRequiresPassedInTags; // Offset: 0x38 | Size: 0x1
	char pad_0x39[0x7]; // Offset: 0x39 | Size: 0x7

	// Functions

	// Object: Function GameplayAbilities.GameplayEffectExecutionCalculation.Execute
	// Flags: [Native|Event|Public|HasOutParms|BlueprintEvent|Const]
	// Offset: 0x1012634ec
	// Return & Params: [ Num(2) Size(0x110) ]
	void Execute(struct FGameplayEffectCustomExecutionParameters& ExecutionParams, struct FGameplayEffectCustomExecutionOutput& OutExecutionOutput);
};

// Object: Class GameplayAbilities.GameplayEffectUIData
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UGameplayEffectUIData : UObject {
};

// Object: Class GameplayAbilities.GameplayEffectUIData_TextOnly
// Inherited Bytes: 0x28 | Struct Size: 0x40
struct UGameplayEffectUIData_TextOnly : UGameplayEffectUIData {
	// Fields
	struct FText Description; // Offset: 0x28 | Size: 0x18
};

// Object: Class GameplayAbilities.GameplayModMagnitudeCalculation
// Inherited Bytes: 0x38 | Struct Size: 0x40
struct UGameplayModMagnitudeCalculation : UGameplayEffectCalculation {
	// Fields
	bool bAllowNonNetAuthorityDependencyRegistration; // Offset: 0x38 | Size: 0x1
	char pad_0x39[0x7]; // Offset: 0x39 | Size: 0x7

	// Functions

	// Object: Function GameplayAbilities.GameplayModMagnitudeCalculation.CalculateBaseMagnitude
	// Flags: [Native|Event|Public|HasOutParms|BlueprintEvent|Const]
	// Offset: 0x101264fc0
	// Return & Params: [ Num(2) Size(0x29c) ]
	float CalculateBaseMagnitude(struct FGameplayEffectSpec& Spec);
};

// Object: Class GameplayAbilities.GameplayTagReponseTable
// Inherited Bytes: 0x30 | Struct Size: 0x1e8
struct UGameplayTagReponseTable : UDataAsset {
	// Fields
	struct TArray<struct FGameplayTagResponseTableEntry> Entries; // Offset: 0x30 | Size: 0x10
	char pad_0x40[0x1a8]; // Offset: 0x40 | Size: 0x1a8

	// Functions

	// Object: Function GameplayAbilities.GameplayTagReponseTable.TagResponseEvent
	// Flags: [Final|Native|Protected]
	// Offset: 0x1012658fc
	// Return & Params: [ Num(4) Size(0x1c) ]
	void TagResponseEvent(struct FGameplayTag Tag, int32_t NewCount, struct UAbilitySystemComponent* ASC, int32_t idx);
};

// Object: Class GameplayAbilities.TickableAttributeSetInterface
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UTickableAttributeSetInterface : UInterface {
};

