#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class GeometryCacheTracks.MovieSceneGeometryCacheSection
// Inherited Bytes: 0xd8 | Struct Size: 0x118
struct UMovieSceneGeometryCacheSection : UMovieSceneSection {
	// Fields
	struct FMovieSceneGeometryCacheParams Params; // Offset: 0xd8 | Size: 0x40
};

// Object: Class GeometryCacheTracks.MovieSceneGeometryCacheTrack
// Inherited Bytes: 0x58 | Struct Size: 0x68
struct UMovieSceneGeometryCacheTrack : UMovieSceneNameableTrack {
	// Fields
	struct TArray<struct UMovieSceneSection*> AnimationSections; // Offset: 0x58 | Size: 0x10
};

