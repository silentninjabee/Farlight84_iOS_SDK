#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class GeometryCollectionTracks.MovieSceneGeometryCollectionSection
// Inherited Bytes: 0xd8 | Struct Size: 0x108
struct UMovieSceneGeometryCollectionSection : UMovieSceneSection {
	// Fields
	struct FMovieSceneGeometryCollectionParams Params; // Offset: 0xd8 | Size: 0x30
};

// Object: Class GeometryCollectionTracks.MovieSceneGeometryCollectionTrack
// Inherited Bytes: 0x58 | Struct Size: 0x68
struct UMovieSceneGeometryCollectionTrack : UMovieSceneNameableTrack {
	// Fields
	struct TArray<struct UMovieSceneSection*> AnimationSections; // Offset: 0x58 | Size: 0x10
};

