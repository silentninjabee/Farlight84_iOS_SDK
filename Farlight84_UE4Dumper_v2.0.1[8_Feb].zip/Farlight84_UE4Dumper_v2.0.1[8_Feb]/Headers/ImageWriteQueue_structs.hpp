#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct ImageWriteQueue.ImageWriteOptions
// Inherited Bytes: 0x0 | Struct Size: 0x60
struct FImageWriteOptions {
	// Fields
	enum class EDesiredImageFormat Format; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	struct FDelegate OnComplete; // Offset: 0x4 | Size: 0x10
	int32_t CompressionQuality; // Offset: 0x14 | Size: 0x4
	bool bOverwriteFile; // Offset: 0x18 | Size: 0x1
	bool bAsync; // Offset: 0x19 | Size: 0x1
	char pad_0x1A[0x46]; // Offset: 0x1a | Size: 0x46
};

