#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass LaserVehicleBlockEffect.LaserVehicleBlockEffect_C
// Inherited Bytes: 0x848 | Struct Size: 0x848
struct ULaserVehicleBlockEffect_C : UGameplayEffect {
};

