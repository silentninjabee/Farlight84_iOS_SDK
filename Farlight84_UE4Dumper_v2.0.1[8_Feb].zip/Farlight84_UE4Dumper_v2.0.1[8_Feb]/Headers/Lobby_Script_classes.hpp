#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass Lobby_Script.Lobby_Script_C
// Inherited Bytes: 0x230 | Struct Size: 0x294
struct ALobby_Script_C : ALevelScriptActor {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x230 | Size: 0x8
	struct AActor* Loc_Hall; // Offset: 0x238 | Size: 0x8
	struct AActor* Loc_BattlePass; // Offset: 0x240 | Size: 0x8
	struct AActor* Loc_RankRace; // Offset: 0x248 | Size: 0x8
	struct AActor* Loc_RankList; // Offset: 0x250 | Size: 0x8
	struct AActor* Loc_Shop; // Offset: 0x258 | Size: 0x8
	struct AActor* Loc_Weapon; // Offset: 0x260 | Size: 0x8
	struct AActor* Loc_MVP; // Offset: 0x268 | Size: 0x8
	struct AActor* Loc_Character; // Offset: 0x270 | Size: 0x8
	struct TArray<struct AActor*> LocatorList; // Offset: 0x278 | Size: 0x10
	struct FVector CamRelativeLoc; // Offset: 0x288 | Size: 0xc

	// Functions

	// Object: Function Lobby_Script.Lobby_Script_C.ReceiveEndPlay
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x1015dbdd8
	// Return & Params: [ Num(1) Size(0x1) ]
	void ReceiveEndPlay(enum class EEndPlayReason EndPlayReason);

	// Object: Function Lobby_Script.Lobby_Script_C.ReceiveBeginPlayCopy
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void ReceiveBeginPlayCopy();

	// Object: Function Lobby_Script.Lobby_Script_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();

	// Object: Function Lobby_Script.Lobby_Script_C.ReceiveBeginPlay
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x1015dbdd8
	// Return & Params: [ Num(0) Size(0x0) ]
	void ReceiveBeginPlay();

	// Object: Function Lobby_Script.Lobby_Script_C.ExecuteUbergraph_Lobby_Script
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_Lobby_Script(int32_t EntryPoint);
};

