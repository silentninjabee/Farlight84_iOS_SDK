#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass Lobby.Lobby_C
// Inherited Bytes: 0x230 | Struct Size: 0x238
struct ALobby_C : ALevelScriptActor {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x230 | Size: 0x8

	// Functions

	// Object: Function Lobby.Lobby_C.CloseVictoryUI
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void CloseVictoryUI();

	// Object: Function Lobby.Lobby_C.ReceiveBeginPlay
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void ReceiveBeginPlay();

	// Object: Function Lobby.Lobby_C.ExecuteUbergraph_Lobby
	// Flags: [Final|UbergraphFunction|HasDefaults]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_Lobby(int32_t EntryPoint);
};

