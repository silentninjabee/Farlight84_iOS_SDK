#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass MassInvisibilityCameraModifierIn.MassInvisibilityCameraModifierIn_C
// Inherited Bytes: 0x160 | Struct Size: 0x160
struct UMassInvisibilityCameraModifierIn_C : UCameraShake {
};

