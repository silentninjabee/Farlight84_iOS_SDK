#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class MaterialShaderQualitySettings.MaterialShaderQualitySettings
// Inherited Bytes: 0x28 | Struct Size: 0x78
struct UMaterialShaderQualitySettings : UObject {
	// Fields
	struct TMap<struct FName, struct UShaderPlatformQualitySettings*> ForwardSettingMap; // Offset: 0x28 | Size: 0x50
};

// Object: Class MaterialShaderQualitySettings.ShaderPlatformQualitySettings
// Inherited Bytes: 0x28 | Struct Size: 0x58
struct UShaderPlatformQualitySettings : UObject {
	// Fields
	struct FMaterialQualityOverrides QualityOverrides[0x3]; // Offset: 0x28 | Size: 0x1b
	char pad_0x43[0x15]; // Offset: 0x43 | Size: 0x15
};

