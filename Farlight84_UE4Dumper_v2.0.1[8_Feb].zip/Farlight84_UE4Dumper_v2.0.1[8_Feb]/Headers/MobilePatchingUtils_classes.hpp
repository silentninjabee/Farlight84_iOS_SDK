#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class MobilePatchingUtils.MobileInstalledContent
// Inherited Bytes: 0x28 | Struct Size: 0x48
struct UMobileInstalledContent : UObject {
	// Fields
	char pad_0x28[0x20]; // Offset: 0x28 | Size: 0x20

	// Functions

	// Object: Function MobilePatchingUtils.MobileInstalledContent.Mount
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10226d244
	// Return & Params: [ Num(3) Size(0x19) ]
	bool Mount(int32_t PakOrder, struct FString MountPoint);

	// Object: Function MobilePatchingUtils.MobileInstalledContent.GetInstalledContentSize
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x10226d32c
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetInstalledContentSize();

	// Object: Function MobilePatchingUtils.MobileInstalledContent.GetDiskFreeSpace
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x10226d360
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetDiskFreeSpace();
};

// Object: Class MobilePatchingUtils.MobilePendingContent
// Inherited Bytes: 0x48 | Struct Size: 0x88
struct UMobilePendingContent : UMobileInstalledContent {
	// Fields
	char pad_0x48[0x40]; // Offset: 0x48 | Size: 0x40

	// Functions

	// Object: Function MobilePatchingUtils.MobilePendingContent.StartInstall
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x10226d7d8
	// Return & Params: [ Num(2) Size(0x20) ]
	void StartInstall(struct FDelegate OnSucceeded, struct FDelegate OnFailed);

	// Object: Function MobilePatchingUtils.MobilePendingContent.GetTotalDownloadedSize
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x10226d9f4
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetTotalDownloadedSize();

	// Object: Function MobilePatchingUtils.MobilePendingContent.GetRequiredDiskSpace
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x10226da28
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetRequiredDiskSpace();

	// Object: Function MobilePatchingUtils.MobilePendingContent.GetInstallProgress
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x10226d8e4
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetInstallProgress();

	// Object: Function MobilePatchingUtils.MobilePendingContent.GetDownloadStatusText
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x10226d918
	// Return & Params: [ Num(1) Size(0x18) ]
	struct FText GetDownloadStatusText();

	// Object: Function MobilePatchingUtils.MobilePendingContent.GetDownloadSpeed
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x10226d9c0
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetDownloadSpeed();

	// Object: Function MobilePatchingUtils.MobilePendingContent.GetDownloadSize
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x10226da5c
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetDownloadSize();
};

// Object: Class MobilePatchingUtils.MobilePatchingLibrary
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UMobilePatchingLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object: Function MobilePatchingUtils.MobilePatchingLibrary.RequestContent
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x10226e118
	// Return & Params: [ Num(5) Size(0x50) ]
	void RequestContent(struct FString RemoteManifestURL, struct FString CloudURL, struct FString InstallDirectory, struct FDelegate OnSucceeded, struct FDelegate OnFailed);

	// Object: Function MobilePatchingUtils.MobilePatchingLibrary.HasActiveWiFiConnection
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x10226e0e4
	// Return & Params: [ Num(1) Size(0x1) ]
	bool HasActiveWiFiConnection();

	// Object: Function MobilePatchingUtils.MobilePatchingLibrary.GetSupportedPlatformNames
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x10226df70
	// Return & Params: [ Num(1) Size(0x10) ]
	struct TArray<struct FString> GetSupportedPlatformNames();

	// Object: Function MobilePatchingUtils.MobilePatchingLibrary.GetInstalledContent
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x10226e318
	// Return & Params: [ Num(2) Size(0x18) ]
	struct UMobileInstalledContent* GetInstalledContent(struct FString InstallDirectory);

	// Object: Function MobilePatchingUtils.MobilePatchingLibrary.GetActiveDeviceProfileName
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x10226e064
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetActiveDeviceProfileName();
};

