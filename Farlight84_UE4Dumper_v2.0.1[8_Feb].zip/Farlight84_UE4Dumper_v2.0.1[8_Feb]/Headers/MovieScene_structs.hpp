#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct MovieScene.MovieSceneEvalTemplateBase
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FMovieSceneEvalTemplateBase {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct MovieScene.MovieSceneEvalTemplate
// Inherited Bytes: 0x10 | Struct Size: 0x18
struct FMovieSceneEvalTemplate : FMovieSceneEvalTemplateBase {
	// Fields
	enum class EMovieSceneCompletionMode CompletionMode; // Offset: 0x9 | Size: 0x1
	struct TWeakObjectPtr<struct UMovieSceneSection> SourceSectionPtr; // Offset: 0xc | Size: 0x8
};

// Object: ScriptStruct MovieScene.MovieSceneChannel
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FMovieSceneChannel {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
};

// Object: ScriptStruct MovieScene.MovieSceneBoolChannel
// Inherited Bytes: 0x8 | Struct Size: 0x90
struct FMovieSceneBoolChannel : FMovieSceneChannel {
	// Fields
	struct TArray<struct FFrameNumber> Times; // Offset: 0x8 | Size: 0x10
	bool DefaultValue; // Offset: 0x18 | Size: 0x1
	bool bHasDefaultValue; // Offset: 0x19 | Size: 0x1
	char pad_0x1A[0x6]; // Offset: 0x1a | Size: 0x6
	struct TArray<bool> Values; // Offset: 0x20 | Size: 0x10
	char pad_0x30[0x60]; // Offset: 0x30 | Size: 0x60
};

// Object: ScriptStruct MovieScene.MovieSceneSequenceInstanceData
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FMovieSceneSequenceInstanceData {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
};

// Object: ScriptStruct MovieScene.MovieSceneEvaluationOperand
// Inherited Bytes: 0x0 | Struct Size: 0x14
struct FMovieSceneEvaluationOperand {
	// Fields
	struct FGuid ObjectBindingID; // Offset: 0x0 | Size: 0x10
	struct FMovieSceneSequenceID SequenceID; // Offset: 0x10 | Size: 0x4
};

// Object: ScriptStruct MovieScene.MovieSceneSequenceID
// Inherited Bytes: 0x0 | Struct Size: 0x4
struct FMovieSceneSequenceID {
	// Fields
	uint32_t Value; // Offset: 0x0 | Size: 0x4
};

// Object: ScriptStruct MovieScene.MovieSceneFloatChannel
// Inherited Bytes: 0x8 | Struct Size: 0xa0
struct FMovieSceneFloatChannel : FMovieSceneChannel {
	// Fields
	enum class ERichCurveExtrapolation PreInfinityExtrap; // Offset: 0x8 | Size: 0x1
	enum class ERichCurveExtrapolation PostInfinityExtrap; // Offset: 0x9 | Size: 0x1
	char pad_0xA[0x6]; // Offset: 0xa | Size: 0x6
	struct TArray<struct FFrameNumber> Times; // Offset: 0x10 | Size: 0x10
	struct TArray<struct FMovieSceneFloatValue> Values; // Offset: 0x20 | Size: 0x10
	float DefaultValue; // Offset: 0x30 | Size: 0x4
	bool bHasDefaultValue; // Offset: 0x34 | Size: 0x1
	char pad_0x35[0x3]; // Offset: 0x35 | Size: 0x3
	struct FMovieSceneKeyHandleMap KeyHandles; // Offset: 0x38 | Size: 0x60
	struct FFrameRate TickResolution; // Offset: 0x98 | Size: 0x8
};

// Object: ScriptStruct MovieScene.MovieSceneKeyHandleMap
// Inherited Bytes: 0x60 | Struct Size: 0x60
struct FMovieSceneKeyHandleMap : FKeyHandleLookupTable {
};

// Object: ScriptStruct MovieScene.MovieSceneFloatValue
// Inherited Bytes: 0x0 | Struct Size: 0x1c
struct FMovieSceneFloatValue {
	// Fields
	float Value; // Offset: 0x0 | Size: 0x4
	struct FMovieSceneTangentData Tangent; // Offset: 0x4 | Size: 0x14
	enum class ERichCurveInterpMode InterpMode; // Offset: 0x18 | Size: 0x1
	enum class ERichCurveTangentMode TangentMode; // Offset: 0x19 | Size: 0x1
	char PaddingByte; // Offset: 0x1a | Size: 0x1
	char pad_0x1B[0x1]; // Offset: 0x1b | Size: 0x1
};

// Object: ScriptStruct MovieScene.MovieSceneTangentData
// Inherited Bytes: 0x0 | Struct Size: 0x14
struct FMovieSceneTangentData {
	// Fields
	float ArriveTangent; // Offset: 0x0 | Size: 0x4
	float LeaveTangent; // Offset: 0x4 | Size: 0x4
	float ArriveTangentWeight; // Offset: 0x8 | Size: 0x4
	float LeaveTangentWeight; // Offset: 0xc | Size: 0x4
	enum class ERichCurveTangentWeightMode TangentWeightMode; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x3]; // Offset: 0x11 | Size: 0x3
};

// Object: ScriptStruct MovieScene.MovieScenePropertySectionTemplate
// Inherited Bytes: 0x18 | Struct Size: 0x40
struct FMovieScenePropertySectionTemplate : FMovieSceneEvalTemplate {
	// Fields
	struct FMovieScenePropertySectionData PropertyData; // Offset: 0x18 | Size: 0x28
};

// Object: ScriptStruct MovieScene.MovieScenePropertySectionData
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FMovieScenePropertySectionData {
	// Fields
	struct FName PropertyName; // Offset: 0x0 | Size: 0x8
	struct FString PropertyPath; // Offset: 0x8 | Size: 0x10
	struct FName FunctionName; // Offset: 0x18 | Size: 0x8
	struct FName NotifyFunctionName; // Offset: 0x20 | Size: 0x8
};

// Object: ScriptStruct MovieScene.MovieSceneSectionGroup
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FMovieSceneSectionGroup {
	// Fields
	struct TArray<struct TWeakObjectPtr<struct UMovieSceneSection>> Sections; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct MovieScene.MovieSceneObjectBindingIDs
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FMovieSceneObjectBindingIDs {
	// Fields
	struct TArray<struct FMovieSceneObjectBindingID> Ids; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct MovieScene.MovieSceneObjectBindingID
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FMovieSceneObjectBindingID {
	// Fields
	int32_t SequenceID; // Offset: 0x0 | Size: 0x4
	enum class EMovieSceneObjectBindingSpace Space; // Offset: 0x4 | Size: 0x1
	char pad_0x5[0x3]; // Offset: 0x5 | Size: 0x3
	struct FGuid Guid; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct MovieScene.MovieSceneTrackLabels
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FMovieSceneTrackLabels {
	// Fields
	struct TArray<struct FString> Strings; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct MovieScene.MovieSceneEditorData
// Inherited Bytes: 0x0 | Struct Size: 0xf0
struct FMovieSceneEditorData {
	// Fields
	struct TMap<struct FString, struct FMovieSceneExpansionState> ExpansionStates; // Offset: 0x0 | Size: 0x50
	struct TArray<struct FString> PinnedNodes; // Offset: 0x50 | Size: 0x10
	double ViewStart; // Offset: 0x60 | Size: 0x8
	double ViewEnd; // Offset: 0x68 | Size: 0x8
	double WorkStart; // Offset: 0x70 | Size: 0x8
	double WorkEnd; // Offset: 0x78 | Size: 0x8
	struct TSet<struct FFrameNumber> MarkedFrames; // Offset: 0x80 | Size: 0x50
	struct FFloatRange WorkingRange; // Offset: 0xd0 | Size: 0x10
	struct FFloatRange ViewRange; // Offset: 0xe0 | Size: 0x10
};

// Object: ScriptStruct MovieScene.MovieSceneExpansionState
// Inherited Bytes: 0x0 | Struct Size: 0x1
struct FMovieSceneExpansionState {
	// Fields
	bool bExpanded; // Offset: 0x0 | Size: 0x1
};

// Object: ScriptStruct MovieScene.MovieSceneMarkedFrame
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FMovieSceneMarkedFrame {
	// Fields
	struct FFrameNumber FrameNumber; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct FString Label; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct MovieScene.MovieSceneTimecodeSource
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FMovieSceneTimecodeSource {
	// Fields
	struct FTimecode Timecode; // Offset: 0x0 | Size: 0x14
	struct FFrameNumber DeltaFrame; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct MovieScene.MovieSceneBinding
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FMovieSceneBinding {
	// Fields
	struct FGuid ObjectGuid; // Offset: 0x0 | Size: 0x10
	struct FString BindingName; // Offset: 0x10 | Size: 0x10
	struct TArray<struct UMovieSceneTrack*> Tracks; // Offset: 0x20 | Size: 0x10
};

// Object: ScriptStruct MovieScene.MovieSceneBindingOverrideData
// Inherited Bytes: 0x0 | Struct Size: 0x24
struct FMovieSceneBindingOverrideData {
	// Fields
	struct FMovieSceneObjectBindingID ObjectBindingID; // Offset: 0x0 | Size: 0x18
	struct TWeakObjectPtr<struct UObject> Object; // Offset: 0x18 | Size: 0x8
	bool bOverridesDefault; // Offset: 0x20 | Size: 0x1
	char pad_0x21[0x3]; // Offset: 0x21 | Size: 0x3
};

// Object: ScriptStruct MovieScene.OptionalMovieSceneBlendType
// Inherited Bytes: 0x0 | Struct Size: 0x2
struct FOptionalMovieSceneBlendType {
	// Fields
	enum class EMovieSceneBlendType BlendType; // Offset: 0x0 | Size: 0x1
	bool bIsValid; // Offset: 0x1 | Size: 0x1
};

// Object: ScriptStruct MovieScene.MovieSceneByteChannel
// Inherited Bytes: 0x8 | Struct Size: 0x98
struct FMovieSceneByteChannel : FMovieSceneChannel {
	// Fields
	struct TArray<struct FFrameNumber> Times; // Offset: 0x8 | Size: 0x10
	char DefaultValue; // Offset: 0x18 | Size: 0x1
	bool bHasDefaultValue; // Offset: 0x19 | Size: 0x1
	char pad_0x1A[0x6]; // Offset: 0x1a | Size: 0x6
	struct TArray<char> Values; // Offset: 0x20 | Size: 0x10
	struct UEnum* Enum; // Offset: 0x30 | Size: 0x8
	char pad_0x38[0x60]; // Offset: 0x38 | Size: 0x60
};

// Object: ScriptStruct MovieScene.MovieSceneEvalTemplatePtr
// Inherited Bytes: 0x0 | Struct Size: 0x88
struct FMovieSceneEvalTemplatePtr {
	// Fields
	char pad_0x0[0x88]; // Offset: 0x0 | Size: 0x88
};

// Object: ScriptStruct MovieScene.MovieSceneEmptyStruct
// Inherited Bytes: 0x0 | Struct Size: 0x1
struct FMovieSceneEmptyStruct {
	// Fields
	char pad_0x0[0x1]; // Offset: 0x0 | Size: 0x1
};

// Object: ScriptStruct MovieScene.MovieSceneEvaluationField
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FMovieSceneEvaluationField {
	// Fields
	struct TArray<struct FMovieSceneFrameRange> Ranges; // Offset: 0x0 | Size: 0x10
	struct TArray<struct FMovieSceneEvaluationGroup> Groups; // Offset: 0x10 | Size: 0x10
	struct TArray<struct FMovieSceneEvaluationMetaData> MetaData; // Offset: 0x20 | Size: 0x10
};

// Object: ScriptStruct MovieScene.MovieSceneEvaluationMetaData
// Inherited Bytes: 0x0 | Struct Size: 0x70
struct FMovieSceneEvaluationMetaData {
	// Fields
	struct TArray<struct FMovieSceneSequenceID> ActiveSequences; // Offset: 0x0 | Size: 0x10
	struct TArray<struct FMovieSceneOrderedEvaluationKey> ActiveEntities; // Offset: 0x10 | Size: 0x10
	struct TMap<struct FMovieSceneSequenceID, uint32_t> SubTemplateSerialNumbers; // Offset: 0x20 | Size: 0x50
};

// Object: ScriptStruct MovieScene.MovieSceneOrderedEvaluationKey
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FMovieSceneOrderedEvaluationKey {
	// Fields
	struct FMovieSceneEvaluationKey Key; // Offset: 0x0 | Size: 0xc
	uint16_t SetupIndex; // Offset: 0xc | Size: 0x2
	uint16_t TearDownIndex; // Offset: 0xe | Size: 0x2
};

// Object: ScriptStruct MovieScene.MovieSceneEvaluationKey
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FMovieSceneEvaluationKey {
	// Fields
	struct FMovieSceneSequenceID SequenceID; // Offset: 0x0 | Size: 0x4
	struct FMovieSceneTrackIdentifier TrackIdentifier; // Offset: 0x4 | Size: 0x4
	uint32_t SectionIndex; // Offset: 0x8 | Size: 0x4
};

// Object: ScriptStruct MovieScene.MovieSceneTrackIdentifier
// Inherited Bytes: 0x0 | Struct Size: 0x4
struct FMovieSceneTrackIdentifier {
	// Fields
	uint32_t Value; // Offset: 0x0 | Size: 0x4
};

// Object: ScriptStruct MovieScene.MovieSceneEvaluationGroup
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FMovieSceneEvaluationGroup {
	// Fields
	struct TArray<struct FMovieSceneEvaluationGroupLUTIndex> LUTIndices; // Offset: 0x0 | Size: 0x10
	struct TArray<struct FMovieSceneEvaluationFieldSegmentPtr> SegmentPtrLUT; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct MovieScene.MovieSceneEvaluationFieldTrackPtr
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FMovieSceneEvaluationFieldTrackPtr {
	// Fields
	struct FMovieSceneSequenceID SequenceID; // Offset: 0x0 | Size: 0x4
	struct FMovieSceneTrackIdentifier TrackIdentifier; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct MovieScene.MovieSceneEvaluationFieldSegmentPtr
// Inherited Bytes: 0x8 | Struct Size: 0xc
struct FMovieSceneEvaluationFieldSegmentPtr : FMovieSceneEvaluationFieldTrackPtr {
	// Fields
	struct FMovieSceneSegmentIdentifier SegmentID; // Offset: 0x8 | Size: 0x4
};

// Object: ScriptStruct MovieScene.MovieSceneSegmentIdentifier
// Inherited Bytes: 0x0 | Struct Size: 0x4
struct FMovieSceneSegmentIdentifier {
	// Fields
	int32_t IdentifierIndex; // Offset: 0x0 | Size: 0x4
};

// Object: ScriptStruct MovieScene.MovieSceneEvaluationGroupLUTIndex
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FMovieSceneEvaluationGroupLUTIndex {
	// Fields
	int32_t LUTOffset; // Offset: 0x0 | Size: 0x4
	int32_t NumInitPtrs; // Offset: 0x4 | Size: 0x4
	int32_t NumEvalPtrs; // Offset: 0x8 | Size: 0x4
};

// Object: ScriptStruct MovieScene.MovieSceneFrameRange
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FMovieSceneFrameRange {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct MovieScene.MovieSceneEvaluationTemplate
// Inherited Bytes: 0x0 | Struct Size: 0x2f0
struct FMovieSceneEvaluationTemplate {
	// Fields
	struct TMap<struct FMovieSceneTrackIdentifier, struct FMovieSceneEvaluationTrack> Tracks; // Offset: 0x0 | Size: 0x50
	char pad_0x50[0x50]; // Offset: 0x50 | Size: 0x50
	struct FMovieSceneEvaluationField EvaluationField; // Offset: 0xa0 | Size: 0x30
	struct FMovieSceneSequenceHierarchy Hierarchy; // Offset: 0xd0 | Size: 0xa0
	struct FGuid SequenceSignature; // Offset: 0x170 | Size: 0x10
	struct FMovieSceneEvaluationTemplateSerialNumber TemplateSerialNumber; // Offset: 0x180 | Size: 0x4
	char pad_0x184[0x4]; // Offset: 0x184 | Size: 0x4
	struct FMovieSceneTemplateGenerationLedger TemplateLedger; // Offset: 0x188 | Size: 0xa8
	struct FMovieSceneTrackFieldData TrackFieldData; // Offset: 0x230 | Size: 0x60
	struct FMovieSceneSubSectionFieldData SubSectionFieldData; // Offset: 0x290 | Size: 0x60
};

// Object: ScriptStruct MovieScene.MovieSceneSubSectionFieldData
// Inherited Bytes: 0x0 | Struct Size: 0x60
struct FMovieSceneSubSectionFieldData {
	// Fields
	char pad_0x0[0x60]; // Offset: 0x0 | Size: 0x60
};

// Object: ScriptStruct MovieScene.MovieSceneTrackFieldData
// Inherited Bytes: 0x0 | Struct Size: 0x60
struct FMovieSceneTrackFieldData {
	// Fields
	char pad_0x0[0x60]; // Offset: 0x0 | Size: 0x60
};

// Object: ScriptStruct MovieScene.MovieSceneTemplateGenerationLedger
// Inherited Bytes: 0x0 | Struct Size: 0xa8
struct FMovieSceneTemplateGenerationLedger {
	// Fields
	struct FMovieSceneTrackIdentifier LastTrackIdentifier; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct TMap<struct FGuid, struct FMovieSceneTrackIdentifier> TrackSignatureToTrackIdentifier; // Offset: 0x8 | Size: 0x50
	struct TMap<struct FGuid, struct FMovieSceneFrameRange> SubSectionRanges; // Offset: 0x58 | Size: 0x50
};

// Object: ScriptStruct MovieScene.MovieSceneEvaluationTemplateSerialNumber
// Inherited Bytes: 0x0 | Struct Size: 0x4
struct FMovieSceneEvaluationTemplateSerialNumber {
	// Fields
	uint32_t Value; // Offset: 0x0 | Size: 0x4
};

// Object: ScriptStruct MovieScene.MovieSceneSequenceHierarchy
// Inherited Bytes: 0x0 | Struct Size: 0xa0
struct FMovieSceneSequenceHierarchy {
	// Fields
	struct TMap<struct FMovieSceneSequenceID, struct FMovieSceneSubSequenceData> SubSequences; // Offset: 0x0 | Size: 0x50
	struct TMap<struct FMovieSceneSequenceID, struct FMovieSceneSequenceHierarchyNode> Hierarchy; // Offset: 0x50 | Size: 0x50
};

// Object: ScriptStruct MovieScene.MovieSceneSequenceHierarchyNode
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FMovieSceneSequenceHierarchyNode {
	// Fields
	struct FMovieSceneSequenceID ParentID; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct TArray<struct FMovieSceneSequenceID> Children; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct MovieScene.MovieSceneSubSequenceData
// Inherited Bytes: 0x0 | Struct Size: 0xe8
struct FMovieSceneSubSequenceData {
	// Fields
	struct FSoftObjectPath Sequence; // Offset: 0x0 | Size: 0x18
	struct FMovieSceneSequenceTransform RootToSequenceTransform; // Offset: 0x18 | Size: 0x20
	struct FFrameRate TickResolution; // Offset: 0x38 | Size: 0x8
	struct FMovieSceneSequenceID DeterministicSequenceID; // Offset: 0x40 | Size: 0x4
	struct FMovieSceneFrameRange PlayRange; // Offset: 0x44 | Size: 0x10
	struct FMovieSceneFrameRange FullPlayRange; // Offset: 0x54 | Size: 0x10
	struct FMovieSceneFrameRange UnwarpedPlayRange; // Offset: 0x64 | Size: 0x10
	struct FMovieSceneFrameRange PreRollRange; // Offset: 0x74 | Size: 0x10
	struct FMovieSceneFrameRange PostRollRange; // Offset: 0x84 | Size: 0x10
	int32_t HierarchicalBias; // Offset: 0x94 | Size: 0x4
	struct FMovieSceneSequenceInstanceDataPtr InstanceData; // Offset: 0x98 | Size: 0x18
	char pad_0xB0[0x8]; // Offset: 0xb0 | Size: 0x8
	struct FGuid SubSectionSignature; // Offset: 0xb8 | Size: 0x10
	struct FMovieSceneSequenceTransform OuterToInnerTransform; // Offset: 0xc8 | Size: 0x20
};

// Object: ScriptStruct MovieScene.MovieSceneSequenceTransform
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FMovieSceneSequenceTransform {
	// Fields
	struct FMovieSceneTimeTransform LinearTransform; // Offset: 0x0 | Size: 0xc
	char pad_0xC[0x4]; // Offset: 0xc | Size: 0x4
	struct TArray<struct FMovieSceneNestedSequenceTransform> NestedTransforms; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct MovieScene.MovieSceneNestedSequenceTransform
// Inherited Bytes: 0x0 | Struct Size: 0x14
struct FMovieSceneNestedSequenceTransform {
	// Fields
	struct FMovieSceneTimeTransform LinearTransform; // Offset: 0x0 | Size: 0xc
	struct FMovieSceneTimeWarping Warping; // Offset: 0xc | Size: 0x8
};

// Object: ScriptStruct MovieScene.MovieSceneTimeWarping
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FMovieSceneTimeWarping {
	// Fields
	struct FFrameNumber Start; // Offset: 0x0 | Size: 0x4
	struct FFrameNumber End; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct MovieScene.MovieSceneTimeTransform
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FMovieSceneTimeTransform {
	// Fields
	float TimeScale; // Offset: 0x0 | Size: 0x4
	struct FFrameTime Offset; // Offset: 0x4 | Size: 0x8
};

// Object: ScriptStruct MovieScene.MovieSceneSequenceInstanceDataPtr
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FMovieSceneSequenceInstanceDataPtr {
	// Fields
	char pad_0x0[0x18]; // Offset: 0x0 | Size: 0x18
};

// Object: ScriptStruct MovieScene.MovieSceneEvaluationTrack
// Inherited Bytes: 0x0 | Struct Size: 0xf8
struct FMovieSceneEvaluationTrack {
	// Fields
	struct FGuid ObjectBindingID; // Offset: 0x0 | Size: 0x10
	uint16_t EvaluationPriority; // Offset: 0x10 | Size: 0x2
	enum class EEvaluationMethod EvaluationMethod; // Offset: 0x12 | Size: 0x1
	char pad_0x13[0x5]; // Offset: 0x13 | Size: 0x5
	struct FMovieSceneEvaluationTrackSegments Segments; // Offset: 0x18 | Size: 0x20
	struct UMovieSceneTrack* SourceTrack; // Offset: 0x38 | Size: 0x8
	struct FSectionEvaluationDataTree EvaluationTree; // Offset: 0x40 | Size: 0x60
	struct TArray<struct FMovieSceneEvalTemplatePtr> ChildTemplates; // Offset: 0xa0 | Size: 0x10
	struct FMovieSceneTrackImplementationPtr TrackTemplate; // Offset: 0xb0 | Size: 0x38
	struct FName EvaluationGroup; // Offset: 0xe8 | Size: 0x8
	char bEvaluateInPreroll : 1; // Offset: 0xf0 | Size: 0x1
	char bEvaluateInPostroll : 1; // Offset: 0xf0 | Size: 0x1
	char bTearDownPriority : 1; // Offset: 0xf0 | Size: 0x1
	char pad_0xF0_3 : 5; // Offset: 0xf0 | Size: 0x1
	char pad_0xF1[0x7]; // Offset: 0xf1 | Size: 0x7
};

// Object: ScriptStruct MovieScene.MovieSceneTrackImplementationPtr
// Inherited Bytes: 0x0 | Struct Size: 0x38
struct FMovieSceneTrackImplementationPtr {
	// Fields
	char pad_0x0[0x38]; // Offset: 0x0 | Size: 0x38
};

// Object: ScriptStruct MovieScene.SectionEvaluationDataTree
// Inherited Bytes: 0x0 | Struct Size: 0x60
struct FSectionEvaluationDataTree {
	// Fields
	char pad_0x0[0x60]; // Offset: 0x0 | Size: 0x60
};

// Object: ScriptStruct MovieScene.MovieSceneEvaluationTrackSegments
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FMovieSceneEvaluationTrackSegments {
	// Fields
	struct TArray<int32_t> SegmentIdentifierToIndex; // Offset: 0x0 | Size: 0x10
	struct TArray<struct FMovieSceneSegment> SortedSegments; // Offset: 0x10 | Size: 0x10
};

// Object: ScriptStruct MovieScene.MovieSceneSegment
// Inherited Bytes: 0x0 | Struct Size: 0x58
struct FMovieSceneSegment {
	// Fields
	char pad_0x0[0x58]; // Offset: 0x0 | Size: 0x58
};

// Object: ScriptStruct MovieScene.MovieSceneSubSectionData
// Inherited Bytes: 0x0 | Struct Size: 0x1c
struct FMovieSceneSubSectionData {
	// Fields
	struct TWeakObjectPtr<struct UMovieSceneSubSection> Section; // Offset: 0x0 | Size: 0x8
	struct FGuid ObjectBindingID; // Offset: 0x8 | Size: 0x10
	enum class ESectionEvaluationFlags Flags; // Offset: 0x18 | Size: 0x1
	char pad_0x19[0x3]; // Offset: 0x19 | Size: 0x3
};

// Object: ScriptStruct MovieScene.MovieSceneRootEvaluationTemplateInstance
// Inherited Bytes: 0x0 | Struct Size: 0x320
struct FMovieSceneRootEvaluationTemplateInstance {
	// Fields
	char pad_0x0[0x18]; // Offset: 0x0 | Size: 0x18
	struct TMap<struct FMovieSceneSequenceID, struct UObject*> DirectorInstances; // Offset: 0x18 | Size: 0x50
	char pad_0x68[0x2b8]; // Offset: 0x68 | Size: 0x2b8
};

// Object: ScriptStruct MovieScene.MovieSceneIntegerChannel
// Inherited Bytes: 0x8 | Struct Size: 0x90
struct FMovieSceneIntegerChannel : FMovieSceneChannel {
	// Fields
	struct TArray<struct FFrameNumber> Times; // Offset: 0x8 | Size: 0x10
	int32_t DefaultValue; // Offset: 0x18 | Size: 0x4
	bool bHasDefaultValue; // Offset: 0x1c | Size: 0x1
	char pad_0x1D[0x3]; // Offset: 0x1d | Size: 0x3
	struct TArray<int32_t> Values; // Offset: 0x20 | Size: 0x10
	char pad_0x30[0x60]; // Offset: 0x30 | Size: 0x60
};

// Object: ScriptStruct MovieScene.MovieSceneKeyStruct
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FMovieSceneKeyStruct {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
};

// Object: ScriptStruct MovieScene.MovieSceneKeyTimeStruct
// Inherited Bytes: 0x8 | Struct Size: 0x28
struct FMovieSceneKeyTimeStruct : FMovieSceneKeyStruct {
	// Fields
	struct FFrameNumber Time; // Offset: 0x8 | Size: 0x4
	char pad_0xC[0x1c]; // Offset: 0xc | Size: 0x1c
};

// Object: ScriptStruct MovieScene.GeneratedMovieSceneKeyStruct
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FGeneratedMovieSceneKeyStruct {
	// Fields
	char pad_0x0[0x50]; // Offset: 0x0 | Size: 0x50
};

// Object: ScriptStruct MovieScene.MovieSceneObjectPathChannel
// Inherited Bytes: 0x8 | Struct Size: 0xc0
struct FMovieSceneObjectPathChannel : FMovieSceneChannel {
	// Fields
	struct UObject* PropertyClass; // Offset: 0x8 | Size: 0x8
	struct TArray<struct FFrameNumber> Times; // Offset: 0x10 | Size: 0x10
	struct TArray<struct FMovieSceneObjectPathChannelKeyValue> Values; // Offset: 0x20 | Size: 0x10
	struct FMovieSceneObjectPathChannelKeyValue DefaultValue; // Offset: 0x30 | Size: 0x30
	char pad_0x60[0x60]; // Offset: 0x60 | Size: 0x60
};

// Object: ScriptStruct MovieScene.MovieSceneObjectPathChannelKeyValue
// Inherited Bytes: 0x0 | Struct Size: 0x30
struct FMovieSceneObjectPathChannelKeyValue {
	// Fields
	struct TSoftObjectPtr<UObject> SoftPtr; // Offset: 0x0 | Size: 0x28
	struct UObject* HardPtr; // Offset: 0x28 | Size: 0x8
};

// Object: ScriptStruct MovieScene.MovieScenePossessable
// Inherited Bytes: 0x0 | Struct Size: 0x48
struct FMovieScenePossessable {
	// Fields
	struct TArray<struct FName> Tags; // Offset: 0x0 | Size: 0x10
	struct FGuid Guid; // Offset: 0x10 | Size: 0x10
	struct FString Name; // Offset: 0x20 | Size: 0x10
	struct UObject* PossessedObjectClass; // Offset: 0x30 | Size: 0x8
	struct FGuid ParentGuid; // Offset: 0x38 | Size: 0x10
};

// Object: ScriptStruct MovieScene.MovieSceneEasingSettings
// Inherited Bytes: 0x0 | Struct Size: 0x38
struct FMovieSceneEasingSettings {
	// Fields
	int32_t AutoEaseInDuration; // Offset: 0x0 | Size: 0x4
	int32_t AutoEaseOutDuration; // Offset: 0x4 | Size: 0x4
	struct TScriptInterface<IMovieSceneEasingFunction> EaseIn; // Offset: 0x8 | Size: 0x10
	bool bManualEaseIn; // Offset: 0x18 | Size: 0x1
	char pad_0x19[0x3]; // Offset: 0x19 | Size: 0x3
	int32_t ManualEaseInDuration; // Offset: 0x1c | Size: 0x4
	struct TScriptInterface<IMovieSceneEasingFunction> EaseOut; // Offset: 0x20 | Size: 0x10
	bool bManualEaseOut; // Offset: 0x30 | Size: 0x1
	char pad_0x31[0x3]; // Offset: 0x31 | Size: 0x3
	int32_t ManualEaseOutDuration; // Offset: 0x34 | Size: 0x4
};

// Object: ScriptStruct MovieScene.MovieSceneSectionEvalOptions
// Inherited Bytes: 0x0 | Struct Size: 0x2
struct FMovieSceneSectionEvalOptions {
	// Fields
	bool bCanEditCompletionMode; // Offset: 0x0 | Size: 0x1
	enum class EMovieSceneCompletionMode CompletionMode; // Offset: 0x1 | Size: 0x1
};

// Object: ScriptStruct MovieScene.MovieSceneSectionParameters
// Inherited Bytes: 0x0 | Struct Size: 0x24
struct FMovieSceneSectionParameters {
	// Fields
	struct FFrameNumber StartFrameOffset; // Offset: 0x0 | Size: 0x4
	bool bCanLoop; // Offset: 0x4 | Size: 0x1
	char pad_0x5[0x3]; // Offset: 0x5 | Size: 0x3
	struct FFrameNumber EndFrameOffset; // Offset: 0x8 | Size: 0x4
	struct FFrameNumber FirstLoopStartFrameOffset; // Offset: 0xc | Size: 0x4
	float TimeScale; // Offset: 0x10 | Size: 0x4
	int32_t HierarchicalBias; // Offset: 0x14 | Size: 0x4
	float StartOffset; // Offset: 0x18 | Size: 0x4
	float PrerollTime; // Offset: 0x1c | Size: 0x4
	float PostrollTime; // Offset: 0x20 | Size: 0x4
};

// Object: ScriptStruct MovieScene.SectionEvaluationData
// Inherited Bytes: 0x0 | Struct Size: 0xc
struct FSectionEvaluationData {
	// Fields
	int32_t ImplIndex; // Offset: 0x0 | Size: 0x4
	struct FFrameNumber ForcedTime; // Offset: 0x4 | Size: 0x4
	enum class ESectionEvaluationFlags Flags; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x3]; // Offset: 0x9 | Size: 0x3
};

// Object: ScriptStruct MovieScene.MovieSceneSequencePlaybackSettings
// Inherited Bytes: 0x0 | Struct Size: 0x14
struct FMovieSceneSequencePlaybackSettings {
	// Fields
	char bAutoPlay : 1; // Offset: 0x0 | Size: 0x1
	char pad_0x0_1 : 7; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
	struct FMovieSceneSequenceLoopCount LoopCount; // Offset: 0x4 | Size: 0x4
	float PlayRate; // Offset: 0x8 | Size: 0x4
	float StartTime; // Offset: 0xc | Size: 0x4
	char bRandomStartTime : 1; // Offset: 0x10 | Size: 0x1
	char bRestoreState : 1; // Offset: 0x10 | Size: 0x1
	char bDisableMovementInput : 1; // Offset: 0x10 | Size: 0x1
	char bDisableLookAtInput : 1; // Offset: 0x10 | Size: 0x1
	char bHidePlayer : 1; // Offset: 0x10 | Size: 0x1
	char bHideHud : 1; // Offset: 0x10 | Size: 0x1
	char bDisableCameraCuts : 1; // Offset: 0x10 | Size: 0x1
	char bPauseAtEnd : 1; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x3]; // Offset: 0x11 | Size: 0x3
};

// Object: ScriptStruct MovieScene.MovieSceneSequenceLoopCount
// Inherited Bytes: 0x0 | Struct Size: 0x4
struct FMovieSceneSequenceLoopCount {
	// Fields
	int32_t Value; // Offset: 0x0 | Size: 0x4
};

// Object: ScriptStruct MovieScene.MovieSceneSequenceReplProperties
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FMovieSceneSequenceReplProperties {
	// Fields
	struct FFrameTime LastKnownPosition; // Offset: 0x0 | Size: 0x8
	enum class EMovieScenePlayerStatus LastKnownStatus; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x3]; // Offset: 0x9 | Size: 0x3
	int32_t LastKnownNumLoops; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct MovieScene.MovieSceneWarpCounter
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FMovieSceneWarpCounter {
	// Fields
	struct TArray<uint32_t> WarpCounts; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct MovieScene.MovieSceneSpawnable
// Inherited Bytes: 0x0 | Struct Size: 0x90
struct FMovieSceneSpawnable {
	// Fields
	struct FTransform SpawnTransform; // Offset: 0x0 | Size: 0x30
	struct TArray<struct FName> Tags; // Offset: 0x30 | Size: 0x10
	bool bContinuouslyRespawn; // Offset: 0x40 | Size: 0x1
	char pad_0x41[0x3]; // Offset: 0x41 | Size: 0x3
	struct FGuid Guid; // Offset: 0x44 | Size: 0x10
	char pad_0x54[0x4]; // Offset: 0x54 | Size: 0x4
	struct FString Name; // Offset: 0x58 | Size: 0x10
	struct UObject* ObjectTemplate; // Offset: 0x68 | Size: 0x8
	struct TArray<struct FGuid> ChildPossessables; // Offset: 0x70 | Size: 0x10
	enum class ESpawnOwnership Ownership; // Offset: 0x80 | Size: 0x1
	char pad_0x81[0x3]; // Offset: 0x81 | Size: 0x3
	struct FName LevelName; // Offset: 0x84 | Size: 0x8
	char pad_0x8C[0x4]; // Offset: 0x8c | Size: 0x4
};

// Object: ScriptStruct MovieScene.TestMovieSceneEvalTemplate
// Inherited Bytes: 0x18 | Struct Size: 0x18
struct FTestMovieSceneEvalTemplate : FMovieSceneEvalTemplate {
};

// Object: ScriptStruct MovieScene.MovieSceneTrackDisplayOptions
// Inherited Bytes: 0x0 | Struct Size: 0x4
struct FMovieSceneTrackDisplayOptions {
	// Fields
	char bShowVerticalFrames : 1; // Offset: 0x0 | Size: 0x1
	char pad_0x0_1 : 7; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
};

// Object: ScriptStruct MovieScene.MovieSceneTrackEvalOptions
// Inherited Bytes: 0x0 | Struct Size: 0x4
struct FMovieSceneTrackEvalOptions {
	// Fields
	char bCanEvaluateNearestSection : 1; // Offset: 0x0 | Size: 0x1
	char bEvalNearestSection : 1; // Offset: 0x0 | Size: 0x1
	char bEvaluateInPreroll : 1; // Offset: 0x0 | Size: 0x1
	char bEvaluateInPostroll : 1; // Offset: 0x0 | Size: 0x1
	char bEvaluateNearestSection : 1; // Offset: 0x0 | Size: 0x1
	char pad_0x0_5 : 3; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x3]; // Offset: 0x1 | Size: 0x3
};

// Object: ScriptStruct MovieScene.MovieSceneTrackImplementation
// Inherited Bytes: 0x10 | Struct Size: 0x10
struct FMovieSceneTrackImplementation : FMovieSceneEvalTemplateBase {
};

