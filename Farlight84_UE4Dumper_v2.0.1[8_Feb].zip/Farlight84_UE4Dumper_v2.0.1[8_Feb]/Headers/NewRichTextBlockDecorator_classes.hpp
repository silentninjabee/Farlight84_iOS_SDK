#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: BlueprintGeneratedClass NewRichTextBlockDecorator.NewRichTextBlockDecorator_C
// Inherited Bytes: 0x30 | Struct Size: 0x30
struct UNewRichTextBlockDecorator_C : URichTextBlockImageDecorator {
};

