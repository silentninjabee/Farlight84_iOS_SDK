#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class ReplicationGraph.ReplicationGraph
// Inherited Bytes: 0x28 | Struct Size: 0x500
struct UReplicationGraph : UReplicationDriver {
	// Fields
	struct UNetReplicationGraphConnection* ReplicationConnectionManagerClass; // Offset: 0x28 | Size: 0x8
	struct UNetDriver* NetDriver; // Offset: 0x30 | Size: 0x8
	struct TArray<struct UNetReplicationGraphConnection*> Connections; // Offset: 0x38 | Size: 0x10
	struct TArray<struct UNetReplicationGraphConnection*> PendingConnections; // Offset: 0x48 | Size: 0x10
	char pad_0x58[0x40]; // Offset: 0x58 | Size: 0x40
	struct TArray<struct UReplicationGraphNode*> GlobalGraphNodes; // Offset: 0x98 | Size: 0x10
	struct TArray<struct UReplicationGraphNode*> PrepareForReplicationNodes; // Offset: 0xa8 | Size: 0x10
	struct TArray<struct UReplicationGraphNode*> PostReplicateNodes; // Offset: 0xb8 | Size: 0x10
	char pad_0xC8[0x3c0]; // Offset: 0xc8 | Size: 0x3c0
	struct TMap<struct UNetConnection*, struct FClassExtraReplicatedInfo> ConnectionInfos; // Offset: 0x488 | Size: 0x50
	char pad_0x4D8[0x28]; // Offset: 0x4d8 | Size: 0x28
};

// Object: Class ReplicationGraph.BasicReplicationGraph
// Inherited Bytes: 0x500 | Struct Size: 0x530
struct UBasicReplicationGraph : UReplicationGraph {
	// Fields
	struct UReplicationGraphNode_GridSpatialization2D* GridNode; // Offset: 0x4f8 | Size: 0x8
	struct UReplicationGraphNode_ActorList* AlwaysRelevantNode; // Offset: 0x500 | Size: 0x8
	struct TArray<struct FConnectionAlwaysRelevantNodePair> AlwaysRelevantForConnectionList; // Offset: 0x508 | Size: 0x10
	struct TArray<struct AActor*> ActorsWithoutNetConnection; // Offset: 0x518 | Size: 0x10
};

// Object: Class ReplicationGraph.ReplicationGraphNode
// Inherited Bytes: 0x28 | Struct Size: 0x50
struct UReplicationGraphNode : UObject {
	// Fields
	struct TArray<struct UReplicationGraphNode*> AllChildNodes; // Offset: 0x28 | Size: 0x10
	char pad_0x38[0x18]; // Offset: 0x38 | Size: 0x18
};

// Object: Class ReplicationGraph.ReplicationGraphNode_ActorList
// Inherited Bytes: 0x50 | Struct Size: 0xd0
struct UReplicationGraphNode_ActorList : UReplicationGraphNode {
	// Fields
	char pad_0x50[0x80]; // Offset: 0x50 | Size: 0x80
};

// Object: Class ReplicationGraph.ReplicationGraphNode_ActorListFrequencyBuckets
// Inherited Bytes: 0x50 | Struct Size: 0x108
struct UReplicationGraphNode_ActorListFrequencyBuckets : UReplicationGraphNode {
	// Fields
	char pad_0x50[0xb8]; // Offset: 0x50 | Size: 0xb8
};

// Object: Class ReplicationGraph.ReplicationGraphNode_DynamicSpatialFrequency
// Inherited Bytes: 0xd0 | Struct Size: 0x100
struct UReplicationGraphNode_DynamicSpatialFrequency : UReplicationGraphNode_ActorList {
	// Fields
	char pad_0xD0[0x30]; // Offset: 0xd0 | Size: 0x30
};

// Object: Class ReplicationGraph.ReplicationGraphNode_ConnectionDormancyNode
// Inherited Bytes: 0xd0 | Struct Size: 0x150
struct UReplicationGraphNode_ConnectionDormancyNode : UReplicationGraphNode_ActorList {
	// Fields
	char pad_0xD0[0x80]; // Offset: 0xd0 | Size: 0x80
};

// Object: Class ReplicationGraph.ReplicationGraphNode_DormancyNode
// Inherited Bytes: 0xd0 | Struct Size: 0xe0
struct UReplicationGraphNode_DormancyNode : UReplicationGraphNode_ActorList {
	// Fields
	char pad_0xD0[0x10]; // Offset: 0xd0 | Size: 0x10
};

// Object: Class ReplicationGraph.ReplicationGraphNode_GridCell
// Inherited Bytes: 0xd0 | Struct Size: 0x120
struct UReplicationGraphNode_GridCell : UReplicationGraphNode_ActorList {
	// Fields
	char pad_0xD0[0x40]; // Offset: 0xd0 | Size: 0x40
	struct UReplicationGraphNode* DynamicNode; // Offset: 0x110 | Size: 0x8
	struct UReplicationGraphNode_DormancyNode* DormancyNode; // Offset: 0x118 | Size: 0x8
};

// Object: Class ReplicationGraph.ReplicationGraphNode_GridSpatialization2D
// Inherited Bytes: 0x50 | Struct Size: 0x230
struct UReplicationGraphNode_GridSpatialization2D : UReplicationGraphNode {
	// Fields
	char pad_0x50[0x1e0]; // Offset: 0x50 | Size: 0x1e0
};

// Object: Class ReplicationGraph.ReplicationGraphNode_AlwaysRelevant
// Inherited Bytes: 0x50 | Struct Size: 0x68
struct UReplicationGraphNode_AlwaysRelevant : UReplicationGraphNode {
	// Fields
	struct UReplicationGraphNode* ChildNode; // Offset: 0x50 | Size: 0x8
	char pad_0x58[0x10]; // Offset: 0x58 | Size: 0x10
};

// Object: Class ReplicationGraph.ReplicationGraphNode_AlwaysRelevant_ForConnection
// Inherited Bytes: 0xd0 | Struct Size: 0xf0
struct UReplicationGraphNode_AlwaysRelevant_ForConnection : UReplicationGraphNode_ActorList {
	// Fields
	char pad_0xD0[0x10]; // Offset: 0xd0 | Size: 0x10
	struct TArray<struct FAlwaysRelevantActorInfo> PastRelevantActors; // Offset: 0xe0 | Size: 0x10
};

// Object: Class ReplicationGraph.ReplicationGraphNode_TearOff_ForConnection
// Inherited Bytes: 0x50 | Struct Size: 0x70
struct UReplicationGraphNode_TearOff_ForConnection : UReplicationGraphNode {
	// Fields
	struct TArray<struct FTearOffActorInfo> TearOffActors; // Offset: 0x50 | Size: 0x10
	char pad_0x60[0x10]; // Offset: 0x60 | Size: 0x10
};

// Object: Class ReplicationGraph.NetReplicationGraphConnection
// Inherited Bytes: 0x28 | Struct Size: 0x328
struct UNetReplicationGraphConnection : UReplicationConnectionDriver {
	// Fields
	struct UNetConnection* NetConnection; // Offset: 0x28 | Size: 0x8
	char pad_0x30[0x230]; // Offset: 0x30 | Size: 0x230
	struct AReplicationGraphDebugActor* DebugActor; // Offset: 0x260 | Size: 0x8
	char pad_0x268[0x10]; // Offset: 0x268 | Size: 0x10
	struct TArray<struct FLastLocationGatherInfo> LastGatherLocations; // Offset: 0x278 | Size: 0x10
	char pad_0x288[0x8]; // Offset: 0x288 | Size: 0x8
	struct TArray<struct UReplicationGraphNode*> ConnectionGraphNodes; // Offset: 0x290 | Size: 0x10
	struct UReplicationGraphNode_TearOff_ForConnection* TearOffNode; // Offset: 0x2a0 | Size: 0x8
	char pad_0x2A8[0x80]; // Offset: 0x2a8 | Size: 0x80
};

// Object: Class ReplicationGraph.ReplicationGraphDebugActor
// Inherited Bytes: 0x228 | Struct Size: 0x238
struct AReplicationGraphDebugActor : AActor {
	// Fields
	struct UReplicationGraph* ReplicationGraph; // Offset: 0x228 | Size: 0x8
	struct UNetReplicationGraphConnection* ConnectionManager; // Offset: 0x230 | Size: 0x8

	// Functions

	// Object: Function ReplicationGraph.ReplicationGraphDebugActor.ServerStopDebugging
	// Flags: [Net|NetReliableNative|Event|Public|NetServer]
	// Offset: 0x1012a4b78
	// Return & Params: [ Num(0) Size(0x0) ]
	void ServerStopDebugging();

	// Object: Function ReplicationGraph.ReplicationGraphDebugActor.ServerStartDebugging
	// Flags: [Net|NetReliableNative|Event|Public|NetServer]
	// Offset: 0x1012a4b94
	// Return & Params: [ Num(0) Size(0x0) ]
	void ServerStartDebugging();

	// Object: Function ReplicationGraph.ReplicationGraphDebugActor.ServerSetPeriodFrameForClass
	// Flags: [Net|NetReliableNative|Event|Public|NetServer]
	// Offset: 0x1012a4920
	// Return & Params: [ Num(2) Size(0xc) ]
	void ServerSetPeriodFrameForClass(struct UObject* Class, int32_t PeriodFrame);

	// Object: Function ReplicationGraph.ReplicationGraphDebugActor.ServerSetCullDistanceForClass
	// Flags: [Net|NetReliableNative|Event|Public|NetServer]
	// Offset: 0x1012a49f4
	// Return & Params: [ Num(2) Size(0xc) ]
	void ServerSetCullDistanceForClass(struct UObject* Class, float CullDistance);

	// Object: Function ReplicationGraph.ReplicationGraphDebugActor.ServerSetConditionalActorBreakpoint
	// Flags: [Net|NetReliableNative|Event|Public|NetServer]
	// Offset: 0x1012a4898
	// Return & Params: [ Num(1) Size(0x8) ]
	void ServerSetConditionalActorBreakpoint(struct AActor* Actor);

	// Object: Function ReplicationGraph.ReplicationGraphDebugActor.ServerPrintCullDistances
	// Flags: [Net|NetReliableNative|Event|Public|NetServer]
	// Offset: 0x1012a487c
	// Return & Params: [ Num(0) Size(0x0) ]
	void ServerPrintCullDistances();

	// Object: Function ReplicationGraph.ReplicationGraphDebugActor.ServerPrintAllActorInfo
	// Flags: [Net|NetReliableNative|Event|Public|NetServer]
	// Offset: 0x1012a4ac8
	// Return & Params: [ Num(1) Size(0x10) ]
	void ServerPrintAllActorInfo(struct FString str);

	// Object: Function ReplicationGraph.ReplicationGraphDebugActor.ServerCellInfo
	// Flags: [Net|NetReliableNative|Event|Public|NetServer]
	// Offset: 0x1012a4b5c
	// Return & Params: [ Num(0) Size(0x0) ]
	void ServerCellInfo();

	// Object: Function ReplicationGraph.ReplicationGraphDebugActor.ClientCellInfo
	// Flags: [Net|NetReliableNative|Event|Public|HasDefaults|NetClient]
	// Offset: 0x1012a4754
	// Return & Params: [ Num(3) Size(0x28) ]
	void ClientCellInfo(struct FVector CellLocation, struct FVector CellExtent, struct TArray<struct AActor*> Actors);
};

