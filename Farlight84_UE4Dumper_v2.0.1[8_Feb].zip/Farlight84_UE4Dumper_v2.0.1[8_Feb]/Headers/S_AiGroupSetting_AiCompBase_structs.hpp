#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: UserDefinedStruct S_AiGroupSetting_AiCompBase.S_AiGroupSetting_AiCompBase
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FS_AiGroupSetting_AiCompBase {
	// Fields
	struct TArray<struct FS_AiSetting_AiCompBase> Group_3_B8320C5A4C8302EBED3BC19B28B28E7E; // Offset: 0x0 | Size: 0x10
};

