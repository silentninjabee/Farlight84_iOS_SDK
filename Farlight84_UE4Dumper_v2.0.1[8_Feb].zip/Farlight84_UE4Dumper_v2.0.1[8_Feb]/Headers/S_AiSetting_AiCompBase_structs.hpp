#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: UserDefinedStruct S_AiSetting_AiCompBase.S_AiSetting_AiCompBase
// Inherited Bytes: 0x0 | Struct Size: 0x1bc
struct FS_AiSetting_AiCompBase {
	// Fields
	int32_t AiDifficulty_8_4974E4014585827DEEE7C4A2DD04C574; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct FS_VehicleSetting_AiCompBase Vehicle_31_62776A384FE3DF706792D787ECE21400; // Offset: 0x8 | Size: 0x58
	int32_t Character_5_1C83A7F644D28AEAEDC0E5A7C719F40D; // Offset: 0x60 | Size: 0x4
	char pad_0x64[0x4]; // Offset: 0x64 | Size: 0x4
	struct TMap<enum class E_AiDataSettingType_AiCompBase, struct FIntPoint> AiDataSetting_19_CE7523924778F4A2E8FB8E98FB609BC9; // Offset: 0x68 | Size: 0x50
	struct FS_AiItemSetting_AiCompBase AiItemSetting_24_C13AF7C7447904A20998EFA0633681A8; // Offset: 0xb8 | Size: 0xf0
	struct FS_TeleCenterSetting_AiCompBase TeleCenterSetting_29_19DB9A7E4832B3643DA07E85E3B0B87E; // Offset: 0x1a8 | Size: 0x14
};

