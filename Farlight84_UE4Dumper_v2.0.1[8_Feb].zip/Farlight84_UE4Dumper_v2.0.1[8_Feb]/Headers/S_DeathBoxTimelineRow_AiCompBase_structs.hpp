#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: UserDefinedStruct S_DeathBoxTimelineRow_AiCompBase.S_DeathBoxTimelineRow_AiCompBase
// Inherited Bytes: 0x0 | Struct Size: 0xf8
struct FS_DeathBoxTimelineRow_AiCompBase {
	// Fields
	int32_t Time_2_928EF68248A34D329E295D8A369D8D2F; // Offset: 0x0 | Size: 0x4
	char pad_0x4[0x4]; // Offset: 0x4 | Size: 0x4
	struct FS_AiItemSetting_AiCompBase Item_10_9E2EF34E44E80CF3DF7A459098D75A9C; // Offset: 0x8 | Size: 0xf0
};

