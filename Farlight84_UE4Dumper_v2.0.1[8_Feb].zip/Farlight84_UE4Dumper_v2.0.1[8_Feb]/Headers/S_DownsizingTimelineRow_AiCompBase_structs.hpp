#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: UserDefinedStruct S_DownsizingTimelineRow_AiCompBase.S_DownsizingTimelineRow_AiCompBase
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FS_DownsizingTimelineRow_AiCompBase {
	// Fields
	int32_t StartTime_14_A273D8E04EE25E8D2D889AACBBA4C5B8; // Offset: 0x0 | Size: 0x4
	int32_t EndTime_17_228E647F4CA498BC72379791288866FB; // Offset: 0x4 | Size: 0x4
	int32_t Mix_9_99173A4E47CF385193A8FD8CB2562C9A; // Offset: 0x8 | Size: 0x4
	int32_t Max_10_E4F85214403C3476C6DC9C967BE82897; // Offset: 0xc | Size: 0x4
};

