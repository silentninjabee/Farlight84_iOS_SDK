#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: UserDefinedStruct S_EquipmentArray_AiCompBase.S_EquipmentArray_AiCompBase
// Inherited Bytes: 0x0 | Struct Size: 0x50
struct FS_EquipmentArray_AiCompBase {
	// Fields
	struct TMap<int32_t, int32_t> IdArray_10_CAC6F5A640D7560BEC823F818F74414C; // Offset: 0x0 | Size: 0x50
};

