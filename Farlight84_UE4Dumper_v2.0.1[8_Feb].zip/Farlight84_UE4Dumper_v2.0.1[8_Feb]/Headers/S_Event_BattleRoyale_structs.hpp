#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: UserDefinedStruct S_Event_BattleRoyale.S_Event_BattleRoyale
// Inherited Bytes: 0x0 | Struct Size: 0x58
struct FS_Event_BattleRoyale {
	// Fields
	int32_t BattleTime_15_6488AAB44E84633B11E7DF844AD3B376; // Offset: 0x0 | Size: 0x4
	enum class E_BattleEvent_BattleRoyale EventType_11_8FC191774137C63ED18FD5987B59941D; // Offset: 0x4 | Size: 0x1
	char pad_0x5[0x3]; // Offset: 0x5 | Size: 0x3
	struct TMap<struct FString, struct FString> EventParam_10_DC47076342DAE72F001FD1A032026480; // Offset: 0x8 | Size: 0x50
};

