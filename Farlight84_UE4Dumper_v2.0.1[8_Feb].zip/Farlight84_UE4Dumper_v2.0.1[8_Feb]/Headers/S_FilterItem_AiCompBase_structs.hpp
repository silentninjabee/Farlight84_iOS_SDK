#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: UserDefinedStruct S_FilterItem_AiCompBase.S_FilterItem_AiCompBase
// Inherited Bytes: 0x0 | Struct Size: 0x58
struct FS_FilterItem_AiCompBase {
	// Fields
	enum class E_FilterType_AiCompBase Type_2_5F710F734E5DE42D8867F89EAEF8EDDA; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x7]; // Offset: 0x1 | Size: 0x7
	struct TMap<enum class E_FilterParameterType_AiCompBase, struct FString> Parameter_9_BF9075834B62C964411A2E904F36CE16; // Offset: 0x8 | Size: 0x50
};

