#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: UserDefinedStruct S_VehicleSetting_AiCompBase.S_VehicleSetting_AiCompBase
// Inherited Bytes: 0x0 | Struct Size: 0x58
struct FS_VehicleSetting_AiCompBase {
	// Fields
	bool HasVehicle_1_65D3F5CB42EABC653978A3BB187614F1; // Offset: 0x0 | Size: 0x1
	char pad_0x1[0x7]; // Offset: 0x1 | Size: 0x7
	struct TMap<int32_t, int32_t> VehicleId_6_1DD8025A4E78B76EFC5B37B83362D226; // Offset: 0x8 | Size: 0x50
};

