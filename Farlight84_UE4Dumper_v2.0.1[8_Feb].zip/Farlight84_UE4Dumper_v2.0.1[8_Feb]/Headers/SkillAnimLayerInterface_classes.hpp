#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: DynamicClass SkillAnimLayerInterface.SkillAnimLayerInterface_C
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct USkillAnimLayerInterface_C : UAnimLayerInterface {
	// Functions

	// Object: Function SkillAnimLayerInterface.SkillAnimLayerInterface_C.SkillAnimationLayer
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x20) ]
	void SkillAnimationLayer(struct FPoseLink bpp__BasePose__pf, struct FPoseLink& bpp__SkillAnimationLayer__pf);
};

