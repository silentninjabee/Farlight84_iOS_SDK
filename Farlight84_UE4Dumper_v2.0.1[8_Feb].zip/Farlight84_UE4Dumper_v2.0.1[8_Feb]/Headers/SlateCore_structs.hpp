#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct SlateCore.Geometry
// Inherited Bytes: 0x0 | Struct Size: 0x38
struct FGeometry {
	// Fields
	char pad_0x0[0x38]; // Offset: 0x0 | Size: 0x38
};

// Object: ScriptStruct SlateCore.SlateBrush
// Inherited Bytes: 0x0 | Struct Size: 0xe0
struct FSlateBrush {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
	struct FVector2D ImageSize; // Offset: 0x8 | Size: 0x8
	bool bLockRatio; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x3]; // Offset: 0x11 | Size: 0x3
	struct FVector2D LockedSize; // Offset: 0x14 | Size: 0x8
	bool bUsePixelMargin; // Offset: 0x1c | Size: 0x1
	char pad_0x1D[0x3]; // Offset: 0x1d | Size: 0x3
	struct FMargin Margin; // Offset: 0x20 | Size: 0x10
	struct FSlateColor TintColor; // Offset: 0x30 | Size: 0x28
	char pad_0x58[0x8]; // Offset: 0x58 | Size: 0x8
	struct FSlateBrushOutlineSettings OutlineSettings; // Offset: 0x60 | Size: 0x40
	struct UObject* ResourceObject; // Offset: 0xa0 | Size: 0x8
	struct FName ResourceName; // Offset: 0xa8 | Size: 0x8
	struct FBox2D UVRegion; // Offset: 0xb0 | Size: 0x14
	enum class ESlateBrushDrawType DrawAs; // Offset: 0xc4 | Size: 0x1
	enum class ESlateBrushTileType Tiling; // Offset: 0xc5 | Size: 0x1
	enum class ESlateBrushMirrorType Mirroring; // Offset: 0xc6 | Size: 0x1
	enum class ESlateBrushImageType ImageType; // Offset: 0xc7 | Size: 0x1
	char pad_0xC8[0x10]; // Offset: 0xc8 | Size: 0x10
	char bIsDynamicallyLoaded : 1; // Offset: 0xd8 | Size: 0x1
	char bHasUObject : 1; // Offset: 0xd8 | Size: 0x1
	char pad_0xD8_2 : 6; // Offset: 0xd8 | Size: 0x1
	char pad_0xD9[0x7]; // Offset: 0xd9 | Size: 0x7
};

// Object: ScriptStruct SlateCore.SlateBrushOutlineSettings
// Inherited Bytes: 0x0 | Struct Size: 0x40
struct FSlateBrushOutlineSettings {
	// Fields
	struct FVector4 CornerRadii; // Offset: 0x0 | Size: 0x10
	struct FSlateColor Color; // Offset: 0x10 | Size: 0x28
	float Width; // Offset: 0x38 | Size: 0x4
	enum class ESlateBrushRoundingType RoundingType; // Offset: 0x3c | Size: 0x1
	bool bUseBrushTransparency; // Offset: 0x3d | Size: 0x1
	char pad_0x3E[0x2]; // Offset: 0x3e | Size: 0x2
};

// Object: ScriptStruct SlateCore.SlateColor
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FSlateColor {
	// Fields
	struct FLinearColor SpecifiedColor; // Offset: 0x0 | Size: 0x10
	enum class ESlateColorStylingMode ColorUseRule; // Offset: 0x10 | Size: 0x1
	char pad_0x11[0x17]; // Offset: 0x11 | Size: 0x17
};

// Object: ScriptStruct SlateCore.Margin
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FMargin {
	// Fields
	float Left; // Offset: 0x0 | Size: 0x4
	float Top; // Offset: 0x4 | Size: 0x4
	float Right; // Offset: 0x8 | Size: 0x4
	float Bottom; // Offset: 0xc | Size: 0x4
};

// Object: ScriptStruct SlateCore.InputEvent
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FInputEvent {
	// Fields
	char pad_0x0[0x18]; // Offset: 0x0 | Size: 0x18
};

// Object: ScriptStruct SlateCore.PointerEvent
// Inherited Bytes: 0x18 | Struct Size: 0x70
struct FPointerEvent : FInputEvent {
	// Fields
	char pad_0x18[0x58]; // Offset: 0x18 | Size: 0x58
};

// Object: ScriptStruct SlateCore.CharacterEvent
// Inherited Bytes: 0x18 | Struct Size: 0x20
struct FCharacterEvent : FInputEvent {
	// Fields
	char pad_0x18[0x8]; // Offset: 0x18 | Size: 0x8
};

// Object: ScriptStruct SlateCore.KeyEvent
// Inherited Bytes: 0x18 | Struct Size: 0x38
struct FKeyEvent : FInputEvent {
	// Fields
	char pad_0x18[0x20]; // Offset: 0x18 | Size: 0x20
};

// Object: ScriptStruct SlateCore.NavigationEvent
// Inherited Bytes: 0x18 | Struct Size: 0x20
struct FNavigationEvent : FInputEvent {
	// Fields
	char pad_0x18[0x8]; // Offset: 0x18 | Size: 0x8
};

// Object: ScriptStruct SlateCore.AnalogInputEvent
// Inherited Bytes: 0x38 | Struct Size: 0x40
struct FAnalogInputEvent : FKeyEvent {
	// Fields
	char pad_0x38[0x8]; // Offset: 0x38 | Size: 0x8
};

// Object: ScriptStruct SlateCore.SlateFontInfo
// Inherited Bytes: 0x0 | Struct Size: 0x60
struct FSlateFontInfo {
	// Fields
	struct UObject* FontObject; // Offset: 0x0 | Size: 0x8
	struct UObject* FontMaterial; // Offset: 0x8 | Size: 0x8
	struct FFontOutlineSettings OutlineSettings; // Offset: 0x10 | Size: 0x28
	char pad_0x38[0x10]; // Offset: 0x38 | Size: 0x10
	struct FName TypefaceFontName; // Offset: 0x48 | Size: 0x8
	int32_t Size; // Offset: 0x50 | Size: 0x4
	int32_t LetterSpacing; // Offset: 0x54 | Size: 0x4
	char pad_0x58[0x8]; // Offset: 0x58 | Size: 0x8
};

// Object: ScriptStruct SlateCore.FontOutlineSettings
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FFontOutlineSettings {
	// Fields
	int32_t OutlineSize; // Offset: 0x0 | Size: 0x4
	int32_t OutlineBlur; // Offset: 0x4 | Size: 0x4
	bool bSeparateFillAlpha; // Offset: 0x8 | Size: 0x1
	bool bApplyOutlineToDropShadows; // Offset: 0x9 | Size: 0x1
	char pad_0xA[0x6]; // Offset: 0xa | Size: 0x6
	struct UObject* OutlineMaterial; // Offset: 0x10 | Size: 0x8
	struct FLinearColor OutlineColor; // Offset: 0x18 | Size: 0x10
};

// Object: ScriptStruct SlateCore.SlateWidgetStyle
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FSlateWidgetStyle {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
};

// Object: ScriptStruct SlateCore.TableRowStyle
// Inherited Bytes: 0x8 | Struct Size: 0xca0
struct FTableRowStyle : FSlateWidgetStyle {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FSlateBrush SelectorFocusedBrush; // Offset: 0x10 | Size: 0xe0
	struct FSlateBrush ActiveHoveredBrush; // Offset: 0xf0 | Size: 0xe0
	struct FSlateBrush ActiveBrush; // Offset: 0x1d0 | Size: 0xe0
	struct FSlateBrush InactiveHoveredBrush; // Offset: 0x2b0 | Size: 0xe0
	struct FSlateBrush InactiveBrush; // Offset: 0x390 | Size: 0xe0
	struct FSlateBrush EvenRowBackgroundHoveredBrush; // Offset: 0x470 | Size: 0xe0
	struct FSlateBrush EvenRowBackgroundBrush; // Offset: 0x550 | Size: 0xe0
	struct FSlateBrush OddRowBackgroundHoveredBrush; // Offset: 0x630 | Size: 0xe0
	struct FSlateBrush OddRowBackgroundBrush; // Offset: 0x710 | Size: 0xe0
	struct FSlateColor TextColor; // Offset: 0x7f0 | Size: 0x28
	struct FSlateColor SelectedTextColor; // Offset: 0x818 | Size: 0x28
	struct FSlateBrush DropIndicator_Above; // Offset: 0x840 | Size: 0xe0
	struct FSlateBrush DropIndicator_Onto; // Offset: 0x920 | Size: 0xe0
	struct FSlateBrush DropIndicator_Below; // Offset: 0xa00 | Size: 0xe0
	struct FSlateBrush ActiveHighlightedBrush; // Offset: 0xae0 | Size: 0xe0
	struct FSlateBrush InactiveHighlightedBrush; // Offset: 0xbc0 | Size: 0xe0
};

// Object: ScriptStruct SlateCore.ComboBoxStyle
// Inherited Bytes: 0x8 | Struct Size: 0x620
struct FComboBoxStyle : FSlateWidgetStyle {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FComboButtonStyle ComboButtonStyle; // Offset: 0x10 | Size: 0x5e0
	struct FSlateSound PressedSlateSound; // Offset: 0x5f0 | Size: 0x18
	struct FSlateSound SelectionChangeSlateSound; // Offset: 0x608 | Size: 0x18
};

// Object: ScriptStruct SlateCore.SlateSound
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FSlateSound {
	// Fields
	struct UObject* ResourceObject; // Offset: 0x0 | Size: 0x8
	char pad_0x8[0x10]; // Offset: 0x8 | Size: 0x10
};

// Object: ScriptStruct SlateCore.ComboButtonStyle
// Inherited Bytes: 0x8 | Struct Size: 0x5e0
struct FComboButtonStyle : FSlateWidgetStyle {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FButtonStyle ButtonStyle; // Offset: 0x10 | Size: 0x3e0
	struct FSlateBrush DownArrowImage; // Offset: 0x3f0 | Size: 0xe0
	struct FVector2D ShadowOffset; // Offset: 0x4d0 | Size: 0x8
	struct FLinearColor ShadowColorAndOpacity; // Offset: 0x4d8 | Size: 0x10
	char pad_0x4E8[0x8]; // Offset: 0x4e8 | Size: 0x8
	struct FSlateBrush MenuBorderBrush; // Offset: 0x4f0 | Size: 0xe0
	struct FMargin MenuBorderPadding; // Offset: 0x5d0 | Size: 0x10
};

// Object: ScriptStruct SlateCore.ButtonStyle
// Inherited Bytes: 0x8 | Struct Size: 0x3e0
struct FButtonStyle : FSlateWidgetStyle {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FSlateBrush Normal; // Offset: 0x10 | Size: 0xe0
	struct FSlateBrush Hovered; // Offset: 0xf0 | Size: 0xe0
	struct FSlateBrush Pressed; // Offset: 0x1d0 | Size: 0xe0
	struct FSlateBrush Disabled; // Offset: 0x2b0 | Size: 0xe0
	struct FMargin NormalPadding; // Offset: 0x390 | Size: 0x10
	struct FMargin PressedPadding; // Offset: 0x3a0 | Size: 0x10
	struct FSlateSound PressedSlateSound; // Offset: 0x3b0 | Size: 0x18
	struct FSlateSound HoveredSlateSound; // Offset: 0x3c8 | Size: 0x18
};

// Object: ScriptStruct SlateCore.EditableTextStyle
// Inherited Bytes: 0x8 | Struct Size: 0x330
struct FEditableTextStyle : FSlateWidgetStyle {
	// Fields
	struct FSlateFontInfo Font; // Offset: 0x8 | Size: 0x60
	struct FSlateColor ColorAndOpacity; // Offset: 0x68 | Size: 0x28
	struct FSlateBrush BackgroundImageSelected; // Offset: 0x90 | Size: 0xe0
	struct FSlateBrush BackgroundImageComposing; // Offset: 0x170 | Size: 0xe0
	struct FSlateBrush CaretImage; // Offset: 0x250 | Size: 0xe0
};

// Object: ScriptStruct SlateCore.EditableTextBoxStyle
// Inherited Bytes: 0x8 | Struct Size: 0xc90
struct FEditableTextBoxStyle : FSlateWidgetStyle {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FSlateBrush BackgroundImageNormal; // Offset: 0x10 | Size: 0xe0
	struct FSlateBrush BackgroundImageHovered; // Offset: 0xf0 | Size: 0xe0
	struct FSlateBrush BackgroundImageFocused; // Offset: 0x1d0 | Size: 0xe0
	struct FSlateBrush BackgroundImageReadOnly; // Offset: 0x2b0 | Size: 0xe0
	struct FMargin Padding; // Offset: 0x390 | Size: 0x10
	struct FSlateFontInfo Font; // Offset: 0x3a0 | Size: 0x60
	struct FSlateColor ForegroundColor; // Offset: 0x400 | Size: 0x28
	struct FSlateColor BackgroundColor; // Offset: 0x428 | Size: 0x28
	struct FSlateColor ReadOnlyForegroundColor; // Offset: 0x450 | Size: 0x28
	struct FMargin HScrollBarPadding; // Offset: 0x478 | Size: 0x10
	struct FMargin VScrollBarPadding; // Offset: 0x488 | Size: 0x10
	char pad_0x498[0x8]; // Offset: 0x498 | Size: 0x8
	struct FScrollBarStyle ScrollBarStyle; // Offset: 0x4a0 | Size: 0x7f0
};

// Object: ScriptStruct SlateCore.ScrollBarStyle
// Inherited Bytes: 0x8 | Struct Size: 0x7f0
struct FScrollBarStyle : FSlateWidgetStyle {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FSlateBrush HorizontalBackgroundImage; // Offset: 0x10 | Size: 0xe0
	struct FSlateBrush VerticalBackgroundImage; // Offset: 0xf0 | Size: 0xe0
	struct FSlateBrush VerticalTopSlotImage; // Offset: 0x1d0 | Size: 0xe0
	struct FSlateBrush HorizontalTopSlotImage; // Offset: 0x2b0 | Size: 0xe0
	struct FSlateBrush VerticalBottomSlotImage; // Offset: 0x390 | Size: 0xe0
	struct FSlateBrush HorizontalBottomSlotImage; // Offset: 0x470 | Size: 0xe0
	struct FSlateBrush NormalThumbImage; // Offset: 0x550 | Size: 0xe0
	struct FSlateBrush HoveredThumbImage; // Offset: 0x630 | Size: 0xe0
	struct FSlateBrush DraggedThumbImage; // Offset: 0x710 | Size: 0xe0
};

// Object: ScriptStruct SlateCore.TextBlockStyle
// Inherited Bytes: 0x8 | Struct Size: 0x460
struct FTextBlockStyle : FSlateWidgetStyle {
	// Fields
	struct FSlateFontInfo Font; // Offset: 0x8 | Size: 0x60
	struct FSlateColor ColorAndOpacity; // Offset: 0x68 | Size: 0x28
	struct FVector2D ShadowOffset; // Offset: 0x90 | Size: 0x8
	struct FLinearColor ShadowColorAndOpacity; // Offset: 0x98 | Size: 0x10
	struct FSlateColor SelectedBackgroundColor; // Offset: 0xa8 | Size: 0x28
	struct FLinearColor HighlightColor; // Offset: 0xd0 | Size: 0x10
	struct FSlateBrush HighlightShape; // Offset: 0xe0 | Size: 0xe0
	struct FSlateBrush StrikeBrush; // Offset: 0x1c0 | Size: 0xe0
	struct FSlateBrush UnderlineBrush; // Offset: 0x2a0 | Size: 0xe0
	struct FSlateBrush BackgroundBrush; // Offset: 0x380 | Size: 0xe0
};

// Object: ScriptStruct SlateCore.SpinBoxStyle
// Inherited Bytes: 0x8 | Struct Size: 0x4b0
struct FSpinBoxStyle : FSlateWidgetStyle {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FSlateBrush BackgroundBrush; // Offset: 0x10 | Size: 0xe0
	struct FSlateBrush HoveredBackgroundBrush; // Offset: 0xf0 | Size: 0xe0
	struct FSlateBrush ActiveFillBrush; // Offset: 0x1d0 | Size: 0xe0
	struct FSlateBrush InactiveFillBrush; // Offset: 0x2b0 | Size: 0xe0
	struct FSlateBrush ArrowsImage; // Offset: 0x390 | Size: 0xe0
	struct FSlateColor ForegroundColor; // Offset: 0x470 | Size: 0x28
	struct FMargin TextPadding; // Offset: 0x498 | Size: 0x10
	char pad_0x4A8[0x8]; // Offset: 0x4a8 | Size: 0x8
};

// Object: ScriptStruct SlateCore.FocusEvent
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FFocusEvent {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
};

// Object: ScriptStruct SlateCore.MotionEvent
// Inherited Bytes: 0x18 | Struct Size: 0x48
struct FMotionEvent : FInputEvent {
	// Fields
	char pad_0x18[0x30]; // Offset: 0x18 | Size: 0x30
};

// Object: ScriptStruct SlateCore.HyperlinkStyle
// Inherited Bytes: 0x8 | Struct Size: 0x860
struct FHyperlinkStyle : FSlateWidgetStyle {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FButtonStyle UnderlineStyle; // Offset: 0x10 | Size: 0x3e0
	struct FTextBlockStyle TextStyle; // Offset: 0x3f0 | Size: 0x460
	struct FMargin Padding; // Offset: 0x850 | Size: 0x10
};

// Object: ScriptStruct SlateCore.CompositeFont
// Inherited Bytes: 0x0 | Struct Size: 0x38
struct FCompositeFont {
	// Fields
	struct FTypeface DefaultTypeface; // Offset: 0x0 | Size: 0x10
	struct FCompositeFallbackFont FallbackTypeface; // Offset: 0x10 | Size: 0x18
	struct TArray<struct FCompositeSubFont> SubTypefaces; // Offset: 0x28 | Size: 0x10
};

// Object: ScriptStruct SlateCore.CompositeFallbackFont
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FCompositeFallbackFont {
	// Fields
	struct FTypeface Typeface; // Offset: 0x0 | Size: 0x10
	float ScalingFactor; // Offset: 0x10 | Size: 0x4
	char pad_0x14[0x4]; // Offset: 0x14 | Size: 0x4
};

// Object: ScriptStruct SlateCore.Typeface
// Inherited Bytes: 0x0 | Struct Size: 0x10
struct FTypeface {
	// Fields
	struct TArray<struct FTypefaceEntry> Fonts; // Offset: 0x0 | Size: 0x10
};

// Object: ScriptStruct SlateCore.TypefaceEntry
// Inherited Bytes: 0x0 | Struct Size: 0x28
struct FTypefaceEntry {
	// Fields
	struct FName Name; // Offset: 0x0 | Size: 0x8
	struct FFontData Font; // Offset: 0x8 | Size: 0x20
};

// Object: ScriptStruct SlateCore.FontData
// Inherited Bytes: 0x0 | Struct Size: 0x20
struct FFontData {
	// Fields
	struct FString FontFilename; // Offset: 0x0 | Size: 0x10
	enum class EFontHinting Hinting; // Offset: 0x10 | Size: 0x1
	enum class EFontLoadingPolicy LoadingPolicy; // Offset: 0x11 | Size: 0x1
	char pad_0x12[0x2]; // Offset: 0x12 | Size: 0x2
	int32_t SubFaceIndex; // Offset: 0x14 | Size: 0x4
	struct UObject* FontFaceAsset; // Offset: 0x18 | Size: 0x8
};

// Object: ScriptStruct SlateCore.CompositeSubFont
// Inherited Bytes: 0x18 | Struct Size: 0x38
struct FCompositeSubFont : FCompositeFallbackFont {
	// Fields
	struct TArray<struct FInt32Range> CharacterRanges; // Offset: 0x18 | Size: 0x10
	struct FString Cultures; // Offset: 0x28 | Size: 0x10
};

// Object: ScriptStruct SlateCore.CaptureLostEvent
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FCaptureLostEvent {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x0 | Size: 0x8
};

// Object: ScriptStruct SlateCore.WindowStyle
// Inherited Bytes: 0x8 | Struct Size: 0x1a70
struct FWindowStyle : FSlateWidgetStyle {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FButtonStyle MinimizeButtonStyle; // Offset: 0x10 | Size: 0x3e0
	struct FButtonStyle MaximizeButtonStyle; // Offset: 0x3f0 | Size: 0x3e0
	struct FButtonStyle RestoreButtonStyle; // Offset: 0x7d0 | Size: 0x3e0
	struct FButtonStyle CloseButtonStyle; // Offset: 0xbb0 | Size: 0x3e0
	struct FTextBlockStyle TitleTextStyle; // Offset: 0xf90 | Size: 0x460
	struct FSlateBrush ActiveTitleBrush; // Offset: 0x13f0 | Size: 0xe0
	struct FSlateBrush InactiveTitleBrush; // Offset: 0x14d0 | Size: 0xe0
	struct FSlateBrush FlashTitleBrush; // Offset: 0x15b0 | Size: 0xe0
	struct FSlateColor BackgroundColor; // Offset: 0x1690 | Size: 0x28
	char pad_0x16B8[0x8]; // Offset: 0x16b8 | Size: 0x8
	struct FSlateBrush OutlineBrush; // Offset: 0x16c0 | Size: 0xe0
	struct FSlateColor OutlineColor; // Offset: 0x17a0 | Size: 0x28
	char pad_0x17C8[0x8]; // Offset: 0x17c8 | Size: 0x8
	struct FSlateBrush BorderBrush; // Offset: 0x17d0 | Size: 0xe0
	struct FSlateBrush BackgroundBrush; // Offset: 0x18b0 | Size: 0xe0
	struct FSlateBrush ChildBackgroundBrush; // Offset: 0x1990 | Size: 0xe0
};

// Object: ScriptStruct SlateCore.ScrollBorderStyle
// Inherited Bytes: 0x8 | Struct Size: 0x1d0
struct FScrollBorderStyle : FSlateWidgetStyle {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FSlateBrush TopShadowBrush; // Offset: 0x10 | Size: 0xe0
	struct FSlateBrush BottomShadowBrush; // Offset: 0xf0 | Size: 0xe0
};

// Object: ScriptStruct SlateCore.ScrollBoxStyle
// Inherited Bytes: 0x8 | Struct Size: 0x390
struct FScrollBoxStyle : FSlateWidgetStyle {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FSlateBrush TopShadowBrush; // Offset: 0x10 | Size: 0xe0
	struct FSlateBrush BottomShadowBrush; // Offset: 0xf0 | Size: 0xe0
	struct FSlateBrush LeftShadowBrush; // Offset: 0x1d0 | Size: 0xe0
	struct FSlateBrush RightShadowBrush; // Offset: 0x2b0 | Size: 0xe0
};

// Object: ScriptStruct SlateCore.DockTabStyle
// Inherited Bytes: 0x8 | Struct Size: 0xb30
struct FDockTabStyle : FSlateWidgetStyle {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FButtonStyle CloseButtonStyle; // Offset: 0x10 | Size: 0x3e0
	struct FSlateBrush NormalBrush; // Offset: 0x3f0 | Size: 0xe0
	struct FSlateBrush ActiveBrush; // Offset: 0x4d0 | Size: 0xe0
	struct FSlateBrush ColorOverlayTabBrush; // Offset: 0x5b0 | Size: 0xe0
	struct FSlateBrush ColorOverlayIconBrush; // Offset: 0x690 | Size: 0xe0
	struct FSlateBrush ForegroundBrush; // Offset: 0x770 | Size: 0xe0
	struct FSlateBrush HoveredBrush; // Offset: 0x850 | Size: 0xe0
	struct FSlateBrush ContentAreaBrush; // Offset: 0x930 | Size: 0xe0
	struct FSlateBrush TabWellBrush; // Offset: 0xa10 | Size: 0xe0
	struct FMargin TabPadding; // Offset: 0xaf0 | Size: 0x10
	float OverlapWidth; // Offset: 0xb00 | Size: 0x4
	char pad_0xB04[0x4]; // Offset: 0xb04 | Size: 0x4
	struct FSlateColor FlashColor; // Offset: 0xb08 | Size: 0x28
};

// Object: ScriptStruct SlateCore.HeaderRowStyle
// Inherited Bytes: 0x8 | Struct Size: 0x12d0
struct FHeaderRowStyle : FSlateWidgetStyle {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FTableColumnHeaderStyle ColumnStyle; // Offset: 0x10 | Size: 0x7f0
	struct FTableColumnHeaderStyle LastColumnStyle; // Offset: 0x800 | Size: 0x7f0
	struct FSplitterStyle ColumnSplitterStyle; // Offset: 0xff0 | Size: 0x1d0
	struct FSlateBrush BackgroundBrush; // Offset: 0x11c0 | Size: 0xe0
	struct FSlateColor ForegroundColor; // Offset: 0x12a0 | Size: 0x28
	char pad_0x12C8[0x8]; // Offset: 0x12c8 | Size: 0x8
};

// Object: ScriptStruct SlateCore.SplitterStyle
// Inherited Bytes: 0x8 | Struct Size: 0x1d0
struct FSplitterStyle : FSlateWidgetStyle {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FSlateBrush HandleNormalBrush; // Offset: 0x10 | Size: 0xe0
	struct FSlateBrush HandleHighlightBrush; // Offset: 0xf0 | Size: 0xe0
};

// Object: ScriptStruct SlateCore.TableColumnHeaderStyle
// Inherited Bytes: 0x8 | Struct Size: 0x7f0
struct FTableColumnHeaderStyle : FSlateWidgetStyle {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FSlateBrush SortPrimaryAscendingImage; // Offset: 0x10 | Size: 0xe0
	struct FSlateBrush SortPrimaryDescendingImage; // Offset: 0xf0 | Size: 0xe0
	struct FSlateBrush SortSecondaryAscendingImage; // Offset: 0x1d0 | Size: 0xe0
	struct FSlateBrush SortSecondaryDescendingImage; // Offset: 0x2b0 | Size: 0xe0
	struct FSlateBrush NormalBrush; // Offset: 0x390 | Size: 0xe0
	struct FSlateBrush HoveredBrush; // Offset: 0x470 | Size: 0xe0
	struct FSlateBrush MenuDropdownImage; // Offset: 0x550 | Size: 0xe0
	struct FSlateBrush MenuDropdownNormalBorderBrush; // Offset: 0x630 | Size: 0xe0
	struct FSlateBrush MenuDropdownHoveredBorderBrush; // Offset: 0x710 | Size: 0xe0
};

// Object: ScriptStruct SlateCore.InlineTextImageStyle
// Inherited Bytes: 0x8 | Struct Size: 0x100
struct FInlineTextImageStyle : FSlateWidgetStyle {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FSlateBrush Image; // Offset: 0x10 | Size: 0xe0
	int16_t Baseline; // Offset: 0xf0 | Size: 0x2
	char pad_0xF2[0xe]; // Offset: 0xf2 | Size: 0xe
};

// Object: ScriptStruct SlateCore.VolumeControlStyle
// Inherited Bytes: 0x8 | Struct Size: 0x9d0
struct FVolumeControlStyle : FSlateWidgetStyle {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FSliderStyle SliderStyle; // Offset: 0x10 | Size: 0x560
	struct FSlateBrush HighVolumeImage; // Offset: 0x570 | Size: 0xe0
	struct FSlateBrush MidVolumeImage; // Offset: 0x650 | Size: 0xe0
	struct FSlateBrush LowVolumeImage; // Offset: 0x730 | Size: 0xe0
	struct FSlateBrush NoVolumeImage; // Offset: 0x810 | Size: 0xe0
	struct FSlateBrush MutedImage; // Offset: 0x8f0 | Size: 0xe0
};

// Object: ScriptStruct SlateCore.SliderStyle
// Inherited Bytes: 0x8 | Struct Size: 0x560
struct FSliderStyle : FSlateWidgetStyle {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FSlateBrush NormalBarImage; // Offset: 0x10 | Size: 0xe0
	struct FSlateBrush HoveredBarImage; // Offset: 0xf0 | Size: 0xe0
	struct FSlateBrush DisabledBarImage; // Offset: 0x1d0 | Size: 0xe0
	struct FSlateBrush NormalThumbImage; // Offset: 0x2b0 | Size: 0xe0
	struct FSlateBrush HoveredThumbImage; // Offset: 0x390 | Size: 0xe0
	struct FSlateBrush DisabledThumbImage; // Offset: 0x470 | Size: 0xe0
	float BarThickness; // Offset: 0x550 | Size: 0x4
	char pad_0x554[0xc]; // Offset: 0x554 | Size: 0xc
};

// Object: ScriptStruct SlateCore.SearchBoxStyle
// Inherited Bytes: 0x8 | Struct Size: 0x10a0
struct FSearchBoxStyle : FSlateWidgetStyle {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FEditableTextBoxStyle TextBoxStyle; // Offset: 0x10 | Size: 0xc90
	struct FSlateFontInfo ActiveFontInfo; // Offset: 0xca0 | Size: 0x60
	struct FSlateBrush UpArrowImage; // Offset: 0xd00 | Size: 0xe0
	struct FSlateBrush DownArrowImage; // Offset: 0xde0 | Size: 0xe0
	struct FSlateBrush GlassImage; // Offset: 0xec0 | Size: 0xe0
	struct FSlateBrush ClearImage; // Offset: 0xfa0 | Size: 0xe0
	struct FMargin ImagePadding; // Offset: 0x1080 | Size: 0x10
	bool bLeftAlignButtons; // Offset: 0x1090 | Size: 0x1
	char pad_0x1091[0xf]; // Offset: 0x1091 | Size: 0xf
};

// Object: ScriptStruct SlateCore.ExpandableAreaStyle
// Inherited Bytes: 0x8 | Struct Size: 0x1e0
struct FExpandableAreaStyle : FSlateWidgetStyle {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FSlateBrush CollapsedImage; // Offset: 0x10 | Size: 0xe0
	struct FSlateBrush ExpandedImage; // Offset: 0xf0 | Size: 0xe0
	float RolloutAnimationSeconds; // Offset: 0x1d0 | Size: 0x4
	char pad_0x1D4[0xc]; // Offset: 0x1d4 | Size: 0xc
};

// Object: ScriptStruct SlateCore.ProgressBarStyle
// Inherited Bytes: 0x8 | Struct Size: 0x2b0
struct FProgressBarStyle : FSlateWidgetStyle {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FSlateBrush BackgroundImage; // Offset: 0x10 | Size: 0xe0
	struct FSlateBrush FillImage; // Offset: 0xf0 | Size: 0xe0
	struct FSlateBrush MarqueeImage; // Offset: 0x1d0 | Size: 0xe0
};

// Object: ScriptStruct SlateCore.InlineEditableTextBlockStyle
// Inherited Bytes: 0x8 | Struct Size: 0x1100
struct FInlineEditableTextBlockStyle : FSlateWidgetStyle {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x8 | Size: 0x8
	struct FEditableTextBoxStyle EditableTextBoxStyle; // Offset: 0x10 | Size: 0xc90
	struct FTextBlockStyle TextStyle; // Offset: 0xca0 | Size: 0x460
};

// Object: ScriptStruct SlateCore.CheckBoxStyle
// Inherited Bytes: 0x8 | Struct Size: 0x8a0
struct FCheckBoxStyle : FSlateWidgetStyle {
	// Fields
	enum class ESlateCheckBoxType CheckBoxType; // Offset: 0x8 | Size: 0x1
	char pad_0x9[0x7]; // Offset: 0x9 | Size: 0x7
	struct FSlateBrush UncheckedImage; // Offset: 0x10 | Size: 0xe0
	struct FSlateBrush UncheckedHoveredImage; // Offset: 0xf0 | Size: 0xe0
	struct FSlateBrush UncheckedPressedImage; // Offset: 0x1d0 | Size: 0xe0
	struct FSlateBrush CheckedImage; // Offset: 0x2b0 | Size: 0xe0
	struct FSlateBrush CheckedHoveredImage; // Offset: 0x390 | Size: 0xe0
	struct FSlateBrush CheckedPressedImage; // Offset: 0x470 | Size: 0xe0
	struct FSlateBrush UndeterminedImage; // Offset: 0x550 | Size: 0xe0
	struct FSlateBrush UndeterminedHoveredImage; // Offset: 0x630 | Size: 0xe0
	struct FSlateBrush UndeterminedPressedImage; // Offset: 0x710 | Size: 0xe0
	struct FMargin Padding; // Offset: 0x7f0 | Size: 0x10
	struct FSlateColor ForegroundColor; // Offset: 0x800 | Size: 0x28
	struct FSlateColor BorderBackgroundColor; // Offset: 0x828 | Size: 0x28
	struct FSlateSound CheckedSlateSound; // Offset: 0x850 | Size: 0x18
	struct FSlateSound UncheckedSlateSound; // Offset: 0x868 | Size: 0x18
	struct FSlateSound HoveredSlateSound; // Offset: 0x880 | Size: 0x18
	char pad_0x898[0x8]; // Offset: 0x898 | Size: 0x8
};

