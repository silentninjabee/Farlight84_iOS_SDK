#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class SolarFramework.SolarContainer
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct USolarContainer : UObject {
	// Functions

	// Object: Function SolarFramework.SolarContainer.ReceiveInitialize
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void ReceiveInitialize();

	// Object: Function SolarFramework.SolarContainer.ReceiveDeinitialize
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void ReceiveDeinitialize();
};

// Object: Class SolarFramework.SolarAbstractManager
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct USolarAbstractManager : USolarContainer {
};

// Object: Class SolarFramework.SolarAbstractModel
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct USolarAbstractModel : USolarContainer {
};

// Object: Class SolarFramework.SolarArchitecture
// Inherited Bytes: 0x1a0 | Struct Size: 0x348
struct USolarArchitecture : UGameInstance {
	// Fields
	struct FMulticastInlineDelegate OnOnScopeChangeDelegate; // Offset: 0x1a0 | Size: 0x10
	char pad_0x1B0[0x198]; // Offset: 0x1b0 | Size: 0x198

	// Functions

	// Object: Function SolarFramework.SolarArchitecture.OnScopeChanged
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x2) ]
	void OnScopeChanged(enum class EScope InLastScope, enum class EScope InCurScope);

	// Object: Function SolarFramework.SolarArchitecture.IsScopeSettlement
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10397fb24
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsScopeSettlement();

	// Object: Function SolarFramework.SolarArchitecture.IsScopeLogin
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10397fb90
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsScopeLogin();

	// Object: Function SolarFramework.SolarArchitecture.IsScopeLobby
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10397fb6c
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsScopeLobby();

	// Object: Function SolarFramework.SolarArchitecture.IsScopeBattle
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10397fb48
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsScopeBattle();

	// Object: Function SolarFramework.SolarArchitecture.IsInScope
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10397fbb4
	// Return & Params: [ Num(2) Size(0x2) ]
	bool IsInScope(enum class EScope InScopeMask);

	// Object: Function SolarFramework.SolarArchitecture.GetModel
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10397fc60
	// Return & Params: [ Num(2) Size(0x10) ]
	struct USolarAbstractModel* GetModel(struct USolarAbstractModel*& ModelClass);

	// Object: Function SolarFramework.SolarArchitecture.GetManager
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10397fcfc
	// Return & Params: [ Num(2) Size(0x10) ]
	struct USolarAbstractManager* GetManager(struct USolarAbstractManager*& ManagerClass);

	// Object: Function SolarFramework.SolarArchitecture.GetCurScope
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x10397fc44
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class EScope GetCurScope();
};

// Object: Class SolarFramework.SolarFrameworkSettings
// Inherited Bytes: 0x38 | Struct Size: 0x58
struct USolarFrameworkSettings : UDeveloperSettings {
	// Fields
	struct TArray<struct FSolarConfigEntry> ManagerConfigs; // Offset: 0x38 | Size: 0x10
	struct TArray<struct FSolarConfigEntry> ModelConfigs; // Offset: 0x48 | Size: 0x10
};

