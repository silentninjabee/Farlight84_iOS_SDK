#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Enum SolarUI.EWidgetOverrideParamType
enum class EWidgetOverrideParamType : uint8_t {
	None = 0,
	Text = 1,
	Image = 2,
	Custom = 3,
	GameplayTag = 4,
	EWidgetOverrideParamType_MAX = 5
};

// Object: Enum SolarUI.EUseDesktopWidgetType
enum class EUseDesktopWidgetType : uint8_t {
	DesktopOverrideMobile = 0,
	OnlyDesktop = 1,
	OnlyMobile = 2,
	DesktopAndMobile = 3,
	EUseDesktopWidgetType_MAX = 4
};

// Object: Enum SolarUI.EWidgetLoadType
enum class EWidgetLoadType : uint8_t {
	Start = 0,
	Delay = 1,
	EWidgetLoadType_MAX = 2
};

// Object: Enum SolarUI.USolarWidgetLayoutType
enum class USolarWidgetLayoutType : uint8_t {
	Default = 0,
	Mobile = 1,
	DesktopCommon = 2,
	Count = 3,
	USolarWidgetLayoutType_MAX = 4
};

// Object: Enum SolarUI.ELayoutPreviewType
enum class ELayoutPreviewType : uint8_t {
	Mobile = 0,
	Desktop = 1,
	Deprecated = 2,
	ELayoutPreviewType_MAX = 3
};

