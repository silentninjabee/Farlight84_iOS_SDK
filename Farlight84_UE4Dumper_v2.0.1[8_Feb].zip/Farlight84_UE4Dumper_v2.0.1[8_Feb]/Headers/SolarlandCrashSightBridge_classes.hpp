#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class SolarlandCrashSightBridge.SolarCrashSettings
// Inherited Bytes: 0x38 | Struct Size: 0xe0
struct USolarCrashSettings : UDeveloperSettings {
	// Fields
	struct FString SolarCrashAndroidUploadUrl; // Offset: 0x38 | Size: 0x10
	struct FString SolarCrashAndroidUploadUrlDomestic; // Offset: 0x48 | Size: 0x10
	struct FString SolarCrashIosUploadUrl; // Offset: 0x58 | Size: 0x10
	struct FString SolarCrashIosUploadUrlDomestic; // Offset: 0x68 | Size: 0x10
	struct FString SolarCrashAndroidAppId; // Offset: 0x78 | Size: 0x10
	struct FString SolarCrashAndroidAppIdDomestic; // Offset: 0x88 | Size: 0x10
	struct FString SolarCrashIosAppId; // Offset: 0x98 | Size: 0x10
	struct FString SolarCrashIosAppIdDomestic; // Offset: 0xa8 | Size: 0x10
	struct FString SolarCrashWindowsAppKey; // Offset: 0xb8 | Size: 0x10
	struct FString SolarCrashWindowsAppKeyDomestic; // Offset: 0xc8 | Size: 0x10
	bool bUseCrashSightInWinPlatform; // Offset: 0xd8 | Size: 0x1
	char pad_0xD9[0x7]; // Offset: 0xd9 | Size: 0x7
};

// Object: Class SolarlandCrashSightBridge.SolarCrashReportManager
// Inherited Bytes: 0x28 | Struct Size: 0x48
struct USolarCrashReportManager : UObject {
	// Fields
	char pad_0x28[0x20]; // Offset: 0x28 | Size: 0x20
};

