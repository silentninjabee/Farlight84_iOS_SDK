#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class StaticMeshDescription.StaticMeshDescription
// Inherited Bytes: 0x390 | Struct Size: 0x390
struct UStaticMeshDescription : UMeshDescriptionBase {
	// Functions

	// Object: Function StaticMeshDescription.StaticMeshDescription.SetVertexInstanceUV
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x104e1389c
	// Return & Params: [ Num(3) Size(0x10) ]
	void SetVertexInstanceUV(struct FVertexInstanceID VertexInstanceID, struct FVector2D UV, int32_t UVIndex);

	// Object: Function StaticMeshDescription.StaticMeshDescription.SetPolygonGroupMaterialSlotName
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104e13438
	// Return & Params: [ Num(2) Size(0xc) ]
	void SetPolygonGroupMaterialSlotName(struct FPolygonGroupID PolygonGroupID, struct FName& SlotName);

	// Object: Function StaticMeshDescription.StaticMeshDescription.GetVertexInstanceUV
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104e139b8
	// Return & Params: [ Num(3) Size(0x10) ]
	struct FVector2D GetVertexInstanceUV(struct FVertexInstanceID VertexInstanceID, int32_t UVIndex);

	// Object: Function StaticMeshDescription.StaticMeshDescription.CreateCube
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x104e1351c
	// Return & Params: [ Num(9) Size(0x34) ]
	void CreateCube(struct FVector Center, struct FVector HalfExtents, struct FPolygonGroupID PolygonGroup, struct FPolygonID& PolygonID_PlusX, struct FPolygonID& PolygonID_MinusX, struct FPolygonID& PolygonID_PlusY, struct FPolygonID& PolygonID_MinusY, struct FPolygonID& PolygonID_PlusZ, struct FPolygonID& PolygonID_MinusZ);
};

