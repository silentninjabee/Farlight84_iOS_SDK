#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: UserDefinedStruct Str_DirectionalLightSetting.Str_DirectionalLightSetting
// Inherited Bytes: 0x0 | Struct Size: 0x38
struct FStr_DirectionalLightSetting {
	// Fields
	struct FRotator LightRotation_2_679B44D14D81D1F251E3DBBC76FA0E60; // Offset: 0x0 | Size: 0xc
	float Intensity_5_6E664CA840353E672B56C7BAEC146E40; // Offset: 0xc | Size: 0x4
	struct FColor LightColor_27_10C0A6C94689142FA397DEA5676FBAF0; // Offset: 0x10 | Size: 0x4
	float Temperature_11_824C212841FD90FBABA446940CDBE13B; // Offset: 0x14 | Size: 0x4
	float ShadowBias_13_FED2F29A4B8FBCD270993591477B57A9; // Offset: 0x18 | Size: 0x4
	float ShadowSlopeBias_15_7C56CCCB4CEEFA17E67D2195A7AF271E; // Offset: 0x1c | Size: 0x4
	bool LightChannel0_24_E3D186BA4C82C6B3BD72FB80ACF787E2; // Offset: 0x20 | Size: 0x1
	bool LightChannel1_25_019A668A4DD58574DE0AFDA2E4E3E9F0; // Offset: 0x21 | Size: 0x1
	bool LightChannel2_26_08AE8857406688F44FCD3EACD64C0879; // Offset: 0x22 | Size: 0x1
	char pad_0x23[0x1]; // Offset: 0x23 | Size: 0x1
	float DynamicShadowDistanceMovableLight_35_3BB5B38E40806965B2BE7FAE9A5E217E; // Offset: 0x24 | Size: 0x4
	int32_t NumDynamicShadowCascades_37_AC7F56B040BC6DBB939D1395BFD997C2; // Offset: 0x28 | Size: 0x4
	float DistributionExponent_41_6B5C490B4EE217C84292669D374C18B3; // Offset: 0x2c | Size: 0x4
	float TransitionFraction_42_57ACB1E4497EF7C0F6FC6EB9FF168B67; // Offset: 0x30 | Size: 0x4
	float DistanceFadeoutFraction_43_5D6DF3C34F38F6F7AA00B6AEC2D9DE92; // Offset: 0x34 | Size: 0x4
};

