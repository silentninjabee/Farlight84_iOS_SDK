#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: ScriptStruct TimeManagement.TimedDataInputEvaluationData
// Inherited Bytes: 0x0 | Struct Size: 0x8
struct FTimedDataInputEvaluationData {
	// Fields
	float DistanceToNewestSampleSeconds; // Offset: 0x0 | Size: 0x4
	float DistanceToOldestSampleSeconds; // Offset: 0x4 | Size: 0x4
};

// Object: ScriptStruct TimeManagement.TimedDataChannelSampleTime
// Inherited Bytes: 0x0 | Struct Size: 0x18
struct FTimedDataChannelSampleTime {
	// Fields
	char pad_0x0[0x18]; // Offset: 0x0 | Size: 0x18
};

