#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Button_ReduceCD_Clock.UI_Button_ReduceCD_Clock_C
// Inherited Bytes: 0x490 | Struct Size: 0x4c8
struct UUI_Button_ReduceCD_Clock_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x490 | Size: 0x8
	struct UImage* Img_Light; // Offset: 0x498 | Size: 0x8
	struct UImage* MI_Clock; // Offset: 0x4a0 | Size: 0x8
	struct FLinearColor ClockColor; // Offset: 0x4a8 | Size: 0x10
	struct FLinearColor LightColor; // Offset: 0x4b8 | Size: 0x10

	// Functions

	// Object: Function UI_Button_ReduceCD_Clock.UI_Button_ReduceCD_Clock_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_Button_ReduceCD_Clock.UI_Button_ReduceCD_Clock_C.ExecuteUbergraph_UI_Button_ReduceCD_Clock
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_Button_ReduceCD_Clock(int32_t EntryPoint);
};

