#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Button_Selected_Anim.UI_Button_Selected_Anim_C
// Inherited Bytes: 0x260 | Struct Size: 0x294
struct UUI_Button_Selected_Anim_C : UUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x260 | Size: 0x8
	struct UWidgetAnimation* Select_Anim; // Offset: 0x268 | Size: 0x8
	struct UImage* MI_Circle_01; // Offset: 0x270 | Size: 0x8
	struct USizeBox* SizeBox_1; // Offset: 0x278 | Size: 0x8
	float Size; // Offset: 0x280 | Size: 0x4
	struct FLinearColor Color; // Offset: 0x284 | Size: 0x10

	// Functions

	// Object: Function UI_Button_Selected_Anim.UI_Button_Selected_Anim_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_Button_Selected_Anim.UI_Button_Selected_Anim_C.OnAnimationFinished
	// Flags: [BlueprintCosmetic|Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x8) ]
	void OnAnimationFinished(struct UWidgetAnimation* Animation);

	// Object: Function UI_Button_Selected_Anim.UI_Button_Selected_Anim_C.OnAnimationStarted
	// Flags: [BlueprintCosmetic|Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x8) ]
	void OnAnimationStarted(struct UWidgetAnimation* Animation);

	// Object: Function UI_Button_Selected_Anim.UI_Button_Selected_Anim_C.ExecuteUbergraph_UI_Button_Selected_Anim
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_Button_Selected_Anim(int32_t EntryPoint);
};

