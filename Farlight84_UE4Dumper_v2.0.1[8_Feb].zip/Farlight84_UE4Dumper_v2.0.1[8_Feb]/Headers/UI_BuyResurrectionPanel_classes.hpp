#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_BuyResurrectionPanel.UI_BuyResurrectionPanel_C
// Inherited Bytes: 0x490 | Struct Size: 0x4c9
struct UUI_BuyResurrectionPanel_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x490 | Size: 0x8
	struct UPanel_Interact_Progress_C* Panel_Interact_Progress; // Offset: 0x498 | Size: 0x8
	struct UCanvasPanel* Root; // Offset: 0x4a0 | Size: 0x8
	struct UUI_HUD_Notice_BuyResurrection_C* UI_HUD_Notice_BuyResurrection; // Offset: 0x4a8 | Size: 0x8
	struct UBPC_BuyResurrection_C* BuyComp; // Offset: 0x4b0 | Size: 0x8
	struct FString NotifyString; // Offset: 0x4b8 | Size: 0x10
	bool IsBeingRevived; // Offset: 0x4c8 | Size: 0x1

	// Functions

	// Object: Function UI_BuyResurrectionPanel.UI_BuyResurrectionPanel_C.Set Btn Vis
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void Set Btn Vis(bool show);

	// Object: Function UI_BuyResurrectionPanel.UI_BuyResurrectionPanel_C.Set Btna And Tip Visibility
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void Set Btna And Tip Visibility(bool Visibility);

	// Object: Function UI_BuyResurrectionPanel.UI_BuyResurrectionPanel_C.Event_Init
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x8) ]
	void Event_Init(struct UBPC_BuyResurrection_C* BuyComp);

	// Object: Function UI_BuyResurrectionPanel.UI_BuyResurrectionPanel_C.EventOnStateChange
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void EventOnStateChange(enum class EResurrectionState NewState);

	// Object: Function UI_BuyResurrectionPanel.UI_BuyResurrectionPanel_C.Tick
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x3c) ]
	void Tick(struct FGeometry MyGeometry, float InDeltaTime);

	// Object: Function UI_BuyResurrectionPanel.UI_BuyResurrectionPanel_C.OnReviveStateChange
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x8) ]
	void OnReviveStateChange(struct ASolarPlayerState* RevivingMePlayer);

	// Object: Function UI_BuyResurrectionPanel.UI_BuyResurrectionPanel_C.BndEvt__Panel_Interact_Progress_K2Node_ComponentBoundEvent_1_SimpleDynamicMulticastDelegate__DelegateSignature
	// Flags: [BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void BndEvt__Panel_Interact_Progress_K2Node_ComponentBoundEvent_1_SimpleDynamicMulticastDelegate__DelegateSignature();

	// Object: Function UI_BuyResurrectionPanel.UI_BuyResurrectionPanel_C.Notify Teammate Revive
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void Notify Teammate Revive();

	// Object: Function UI_BuyResurrectionPanel.UI_BuyResurrectionPanel_C.ExecuteUbergraph_UI_BuyResurrectionPanel
	// Flags: [Final|UbergraphFunction|HasDefaults]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_BuyResurrectionPanel(int32_t EntryPoint);
};

