#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Component_Emoji_List.UI_Component_Emoji_List_C
// Inherited Bytes: 0x490 | Struct Size: 0x4e0
struct UUI_Component_Emoji_List_C : USolarUserWidget {
	// Fields
	struct UWidgetAnimation* Anim_Exit; // Offset: 0x490 | Size: 0x8
	struct UWidgetAnimation* Anim_Enter; // Offset: 0x498 | Size: 0x8
	struct USolarCheckButton* Btn_Action; // Offset: 0x4a0 | Size: 0x8
	struct USolarCheckButton* Btn_Emoji; // Offset: 0x4a8 | Size: 0x8
	struct USolarCheckButton* Btn_Voice; // Offset: 0x4b0 | Size: 0x8
	struct UTileView* List_Emoji; // Offset: 0x4b8 | Size: 0x8
	struct UListView* ListView_Voice; // Offset: 0x4c0 | Size: 0x8
	struct UCanvasPanel* Panel_Tab; // Offset: 0x4c8 | Size: 0x8
	struct USolarCheckButtonGroup* Tab; // Offset: 0x4d0 | Size: 0x8
	struct UWidgetSwitcher* WidgetSwitcher_Content; // Offset: 0x4d8 | Size: 0x8

	// Functions

	// Object: DelegateFunction UI_Component_Emoji_List.UI_Component_Emoji_List_C.OnStateChangedEvent_44A78CA3294BBC129D6FA1869846E0E1
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015c616c
	// Return & Params: [ Num(1) Size(0x4) ]
	void OnStateChangedEvent_44A78CA3294BBC129D6FA1869846E0E1(int32_t InLastButtonIndex);

	// Object: Function UI_Component_Emoji_List.UI_Component_Emoji_List_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x1015dbdd8
	// Return & Params: [ Num(0) Size(0x0) ]
	void Construct();

	// Object: Function UI_Component_Emoji_List.UI_Component_Emoji_List_C.Destruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x1015dbdd8
	// Return & Params: [ Num(0) Size(0x0) ]
	void Destruct();

	// Object: Function UI_Component_Emoji_List.UI_Component_Emoji_List_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();
};

