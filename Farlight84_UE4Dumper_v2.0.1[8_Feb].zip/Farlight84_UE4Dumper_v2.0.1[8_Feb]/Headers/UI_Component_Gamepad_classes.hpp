#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Component_Gamepad.UI_Component_Gamepad_C
// Inherited Bytes: 0x490 | Struct Size: 0x4f4
struct UUI_Component_Gamepad_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x490 | Size: 0x8
	struct UImage* img_DoubleClick; // Offset: 0x498 | Size: 0x8
	struct UImage* img_Hold; // Offset: 0x4a0 | Size: 0x8
	struct UImage* Img_MainKey; // Offset: 0x4a8 | Size: 0x8
	struct UImage* Img_ModifierKey; // Offset: 0x4b0 | Size: 0x8
	struct UTextBlock* Img_PlusIcon; // Offset: 0x4b8 | Size: 0x8
	struct UOverlay* Overlay_Normal; // Offset: 0x4c0 | Size: 0x8
	struct USizeBox* SizeBox_MainKey; // Offset: 0x4c8 | Size: 0x8
	struct USizeBox* SizeBox_ModifierKey; // Offset: 0x4d0 | Size: 0x8
	bool bCustomRefresh; // Offset: 0x4d8 | Size: 0x1
	char pad_0x4D9[0x7]; // Offset: 0x4d9 | Size: 0x7
	struct FString ActionName; // Offset: 0x4e0 | Size: 0x10
	float Size; // Offset: 0x4f0 | Size: 0x4

	// Functions

	// Object: Function UI_Component_Gamepad.UI_Component_Gamepad_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();

	// Object: Function UI_Component_Gamepad.UI_Component_Gamepad_C.SetGamepadCustomInfo
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetGamepadCustomInfo(struct FS_KeyPromptGamepad InInfo);

	// Object: Function UI_Component_Gamepad.UI_Component_Gamepad_C.SetSize
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetSize(float Size);

	// Object: Function UI_Component_Gamepad.UI_Component_Gamepad_C.SetMainKeySelection
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void SetMainKeySelection();

	// Object: Function UI_Component_Gamepad.UI_Component_Gamepad_C.SetMainKeyNormal
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void SetMainKeyNormal();

	// Object: Function UI_Component_Gamepad.UI_Component_Gamepad_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_Component_Gamepad.UI_Component_Gamepad_C.ExecuteUbergraph_UI_Component_Gamepad
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_Component_Gamepad(int32_t EntryPoint);
};

