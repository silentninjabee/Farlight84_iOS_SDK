#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Component_Mouse.UI_Component_Mouse_C
// Inherited Bytes: 0x260 | Struct Size: 0x284
struct UUI_Component_Mouse_C : USolarComponentMouse {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x260 | Size: 0x8
	struct UImage* Img_Mouse; // Offset: 0x268 | Size: 0x8
	struct USizeBox* SizeBox_1; // Offset: 0x270 | Size: 0x8
	enum class E_Type_Mouse Mouse; // Offset: 0x278 | Size: 0x1
	bool HUD; // Offset: 0x279 | Size: 0x1
	char pad_0x27A[0x2]; // Offset: 0x27a | Size: 0x2
	struct FVector2D Size; // Offset: 0x27c | Size: 0x8

	// Functions

	// Object: Function UI_Component_Mouse.UI_Component_Mouse_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();

	// Object: Function UI_Component_Mouse.UI_Component_Mouse_C.SetMouseCustomInfo
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetMouseCustomInfo(struct FS_KeyPromptMouse InMouseInfo);

	// Object: Function UI_Component_Mouse.UI_Component_Mouse_C.SetData
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0x1a) ]
	void SetData(struct FKey KeySetting, enum class E_Type_Mouse& Type, bool& Succeed);

	// Object: Function UI_Component_Mouse.UI_Component_Mouse_C.UpdateImage
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void UpdateImage();

	// Object: Function UI_Component_Mouse.UI_Component_Mouse_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_Component_Mouse.UI_Component_Mouse_C.RefreshMouseUIImpl
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x10) ]
	void RefreshMouseUIImpl(struct TArray<struct FInputChord>& InputChordArray);

	// Object: Function UI_Component_Mouse.UI_Component_Mouse_C.ExecuteUbergraph_UI_Component_Mouse
	// Flags: [Final|UbergraphFunction|HasDefaults]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_Component_Mouse(int32_t EntryPoint);
};

