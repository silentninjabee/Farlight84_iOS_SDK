#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Component_PlayerHead.UI_Component_PlayerHead_C
// Inherited Bytes: 0x490 | Struct Size: 0x55f
struct UUI_Component_PlayerHead_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x490 | Size: 0x8
	struct USolarButton* Btn_ShowCard; // Offset: 0x498 | Size: 0x8
	struct UCanvasPanel* Canvas_Frame; // Offset: 0x4a0 | Size: 0x8
	struct USolarImageURL* Img_Avatar; // Offset: 0x4a8 | Size: 0x8
	struct UImage* Img_AvatarFrame; // Offset: 0x4b0 | Size: 0x8
	struct UImage* Img_BG; // Offset: 0x4b8 | Size: 0x8
	struct UImage* Img_BGLine; // Offset: 0x4c0 | Size: 0x8
	struct UImage* Img_Empty; // Offset: 0x4c8 | Size: 0x8
	struct UImage* Img_Gender; // Offset: 0x4d0 | Size: 0x8
	struct UImage* Img_Gender_Bg; // Offset: 0x4d8 | Size: 0x8
	struct UImage* Img_Hover; // Offset: 0x4e0 | Size: 0x8
	struct UImage* Img_Social; // Offset: 0x4e8 | Size: 0x8
	struct UOverlay* Overlay_Normal; // Offset: 0x4f0 | Size: 0x8
	struct UCanvasPanel* Panel_FrameAnim; // Offset: 0x4f8 | Size: 0x8
	struct USizeBox* Size_2; // Offset: 0x500 | Size: 0x8
	struct USizeBox* Size_3; // Offset: 0x508 | Size: 0x8
	struct USizeBox* Size_Avatar; // Offset: 0x510 | Size: 0x8
	struct USizeBox* Size_Vip; // Offset: 0x518 | Size: 0x8
	struct UUI_Vip_Icon_Type_C* UI_Vip; // Offset: 0x520 | Size: 0x8
	bool ShowBusinessCardBtn; // Offset: 0x528 | Size: 0x1
	char pad_0x529[0x7]; // Offset: 0x529 | Size: 0x7
	struct FMulticastInlineDelegate OnClicked; // Offset: 0x530 | Size: 0x10
	struct FMulticastInlineDelegate OnReleased; // Offset: 0x540 | Size: 0x10
	bool IsNonuseFrame; // Offset: 0x550 | Size: 0x1
	bool Empty; // Offset: 0x551 | Size: 0x1
	enum class E_Type_Social Social; // Offset: 0x552 | Size: 0x1
	bool GenderOn; // Offset: 0x553 | Size: 0x1
	enum class E_Type_Gender Gender; // Offset: 0x554 | Size: 0x1
	char pad_0x555[0x3]; // Offset: 0x555 | Size: 0x3
	float Size; // Offset: 0x558 | Size: 0x4
	bool Vip; // Offset: 0x55c | Size: 0x1
	char StateHD; // Offset: 0x55d | Size: 0x1
	bool IsCustom; // Offset: 0x55e | Size: 0x1

	// Functions

	// Object: DelegateFunction UI_Component_PlayerHead.UI_Component_PlayerHead_C.OnClicked_0DD767235C49645DFC17C3AC4FD1A0F4
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015c616c
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_0DD767235C49645DFC17C3AC4FD1A0F4();

	// Object: DelegateFunction UI_Component_PlayerHead.UI_Component_PlayerHead_C.OnClicked_AC38689F2940BC3437E854BA6937F074
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015c616c
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_AC38689F2940BC3437E854BA6937F074();

	// Object: DelegateFunction UI_Component_PlayerHead.UI_Component_PlayerHead_C.OnClicked_CEC04A1FC34F440B2BE25E953976037E
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015c616c
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_CEC04A1FC34F440B2BE25E953976037E();

	// Object: DelegateFunction UI_Component_PlayerHead.UI_Component_PlayerHead_C.OnClicked_2887BB8610471F2A8D697DAE306CC83D
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015c616c
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_2887BB8610471F2A8D697DAE306CC83D();

	// Object: DelegateFunction UI_Component_PlayerHead.UI_Component_PlayerHead_C.OnURLDownloadFinish_FD53DD10E44C6C2B52706480DD4C561F
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015c616c
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnURLDownloadFinish_FD53DD10E44C6C2B52706480DD4C561F(bool bSuccess);

	// Object: DelegateFunction UI_Component_PlayerHead.UI_Component_PlayerHead_C.OnURLDownloadFinish_7574ABBE86409225E0CDE086B938643E
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015c616c
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnURLDownloadFinish_7574ABBE86409225E0CDE086B938643E(bool bSuccess);

	// Object: DelegateFunction UI_Component_PlayerHead.UI_Component_PlayerHead_C.OnURLDownloadFinish_4F66ED892C4A45D88C6E47B6C0B02453
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015c616c
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnURLDownloadFinish_4F66ED892C4A45D88C6E47B6C0B02453(bool bSuccess);

	// Object: DelegateFunction UI_Component_PlayerHead.UI_Component_PlayerHead_C.OnURLDownloadFinish_2B29CE7DE747D8525ED3CFA972935929
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015c616c
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnURLDownloadFinish_2B29CE7DE747D8525ED3CFA972935929(bool bSuccess);

	// Object: DelegateFunction UI_Component_PlayerHead.UI_Component_PlayerHead_C.OnClicked_3477306A8646565899A6A79B3CE43516
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015c616c
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_3477306A8646565899A6A79B3CE43516();

	// Object: DelegateFunction UI_Component_PlayerHead.UI_Component_PlayerHead_C.OnClicked_31FA479596406D17EB94918FE9D826D0
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015c616c
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_31FA479596406D17EB94918FE9D826D0();

	// Object: DelegateFunction UI_Component_PlayerHead.UI_Component_PlayerHead_C.OnClicked_4868E03B7C41F1DBF85AB78EDEAB86DC
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015c616c
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_4868E03B7C41F1DBF85AB78EDEAB86DC();

	// Object: DelegateFunction UI_Component_PlayerHead.UI_Component_PlayerHead_C.OnClicked_CEAC02EC2341A1A775045DAB72E28692
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015c616c
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_CEAC02EC2341A1A775045DAB72E28692();

	// Object: DelegateFunction UI_Component_PlayerHead.UI_Component_PlayerHead_C.OnURLDownloadFinish_B5F1982E3047B4969D276DA4CDE93E2F
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015c616c
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnURLDownloadFinish_B5F1982E3047B4969D276DA4CDE93E2F(bool bSuccess);

	// Object: DelegateFunction UI_Component_PlayerHead.UI_Component_PlayerHead_C.OnURLDownloadFinish_8882A3DCF447C557D123D78FA69D137E
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015c616c
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnURLDownloadFinish_8882A3DCF447C557D123D78FA69D137E(bool bSuccess);

	// Object: DelegateFunction UI_Component_PlayerHead.UI_Component_PlayerHead_C.OnURLDownloadFinish_7925098FD345F1550D8632BA14081245
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015c616c
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnURLDownloadFinish_7925098FD345F1550D8632BA14081245(bool bSuccess);

	// Object: DelegateFunction UI_Component_PlayerHead.UI_Component_PlayerHead_C.OnURLDownloadFinish_A8EA35A21D4370B37DF226895A8DA8EC
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015c616c
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnURLDownloadFinish_A8EA35A21D4370B37DF226895A8DA8EC(bool bSuccess);

	// Object: DelegateFunction UI_Component_PlayerHead.UI_Component_PlayerHead_C.OnClicked_F33CD507AE4190EAA257CD82D2983F36
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015c616c
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_F33CD507AE4190EAA257CD82D2983F36();

	// Object: DelegateFunction UI_Component_PlayerHead.UI_Component_PlayerHead_C.OnURLDownloadFinish_D06867102F40E8C00B26D4B357F86C7D
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015c616c
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnURLDownloadFinish_D06867102F40E8C00B26D4B357F86C7D(bool bSuccess);

	// Object: Function UI_Component_PlayerHead.UI_Component_PlayerHead_C.SetVipTypeCopy
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetVipTypeCopy(char VipType);

	// Object: Function UI_Component_PlayerHead.UI_Component_PlayerHead_C.SetAvatarCopy
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x18) ]
	void SetAvatarCopy(int32_t AvatarID, struct FString AvatarUrl);

	// Object: Function UI_Component_PlayerHead.UI_Component_PlayerHead_C.ForceShowFrameCopy
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ForceShowFrameCopy(int32_t FrameID);

	// Object: Function UI_Component_PlayerHead.UI_Component_PlayerHead_C.ConstructCopy
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void ConstructCopy();

	// Object: Function UI_Component_PlayerHead.UI_Component_PlayerHead_C.OnSolarUIClosed
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x1015dbdd8
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnSolarUIClosed();

	// Object: Function UI_Component_PlayerHead.UI_Component_PlayerHead_C.OnSolarUIOpened
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x1015dbdd8
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnSolarUIOpened();

	// Object: Function UI_Component_PlayerHead.UI_Component_PlayerHead_C.OnInitialized
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x1015dbdd8
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnInitialized();

	// Object: Function UI_Component_PlayerHead.UI_Component_PlayerHead_C.RefreshByPSCopy
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x9) ]
	void RefreshByPSCopy(struct ASolarPlayerState* PS, bool bWithoutGender);

	// Object: Function UI_Component_PlayerHead.UI_Component_PlayerHead_C.Destruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x1015dbdd8
	// Return & Params: [ Num(0) Size(0x0) ]
	void Destruct();

	// Object: Function UI_Component_PlayerHead.UI_Component_PlayerHead_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();

	// Object: Function UI_Component_PlayerHead.UI_Component_PlayerHead_C.ForceShowFrame
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x1015dbdd8
	// Return & Params: [ Num(1) Size(0x4) ]
	void ForceShowFrame(int32_t FrameID);

	// Object: Function UI_Component_PlayerHead.UI_Component_PlayerHead_C.RefreshByPS
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x1015dbdd8
	// Return & Params: [ Num(2) Size(0x9) ]
	void RefreshByPS(struct ASolarPlayerState* PS, bool bWithoutGender);

	// Object: Function UI_Component_PlayerHead.UI_Component_PlayerHead_C.SetAvatarSize
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetAvatarSize(bool IsCustom);

	// Object: Function UI_Component_PlayerHead.UI_Component_PlayerHead_C.SetAvatar
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x1015dbdd8
	// Return & Params: [ Num(2) Size(0x18) ]
	void SetAvatar(int32_t AvatarID, struct FString AvatarUrl);

	// Object: Function UI_Component_PlayerHead.UI_Component_PlayerHead_C.SetStateHD
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetStateHD(char StateHD);

	// Object: Function UI_Component_PlayerHead.UI_Component_PlayerHead_C.SetDefaultSteamAvatar
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void SetDefaultSteamAvatar();

	// Object: Function UI_Component_PlayerHead.UI_Component_PlayerHead_C.SetVipType
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x1015dbdd8
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetVipType(char VipType);

	// Object: Function UI_Component_PlayerHead.UI_Component_PlayerHead_C.OnTouchMoved
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0x160) ]
	struct FEventReply OnTouchMoved(struct FGeometry MyGeometry, struct FPointerEvent& InTouchEvent);

	// Object: Function UI_Component_PlayerHead.UI_Component_PlayerHead_C.SetAvatarState
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetAvatarState(bool IsCollapsed);

	// Object: Function UI_Component_PlayerHead.UI_Component_PlayerHead_C.SetAvatarIcon
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetAvatarIcon(int32_t InAvatarID);

	// Object: Function UI_Component_PlayerHead.UI_Component_PlayerHead_C.SetEmptyState
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetEmptyState(bool IsEmpty);

	// Object: Function UI_Component_PlayerHead.UI_Component_PlayerHead_C.SetPlayerGender
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetPlayerGender(enum class E_Type_Gender Gender);

	// Object: Function UI_Component_PlayerHead.UI_Component_PlayerHead_C.SetSocialIcon
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetSocialIcon(enum class E_Type_Social Social);

	// Object: Function UI_Component_PlayerHead.UI_Component_PlayerHead_C.Update
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void Update();

	// Object: Function UI_Component_PlayerHead.UI_Component_PlayerHead_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_Component_PlayerHead.UI_Component_PlayerHead_C.BndEvt__Btn_PlayerInfo_K2Node_ComponentBoundEvent_1_OnButtonReleasedEvent__DelegateSignature
	// Flags: [BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void BndEvt__Btn_PlayerInfo_K2Node_ComponentBoundEvent_1_OnButtonReleasedEvent__DelegateSignature();

	// Object: Function UI_Component_PlayerHead.UI_Component_PlayerHead_C.BndEvt__Btn_PlayerInfo_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature
	// Flags: [BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void BndEvt__Btn_PlayerInfo_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature();

	// Object: Function UI_Component_PlayerHead.UI_Component_PlayerHead_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x1015dbdd8
	// Return & Params: [ Num(0) Size(0x0) ]
	void Construct();

	// Object: Function UI_Component_PlayerHead.UI_Component_PlayerHead_C.ExecuteUbergraph_UI_Component_PlayerHead
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_Component_PlayerHead(int32_t EntryPoint);

	// Object: Function UI_Component_PlayerHead.UI_Component_PlayerHead_C.OnReleased__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnReleased__DelegateSignature();

	// Object: Function UI_Component_PlayerHead.UI_Component_PlayerHead_C.OnClicked__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked__DelegateSignature();
};

