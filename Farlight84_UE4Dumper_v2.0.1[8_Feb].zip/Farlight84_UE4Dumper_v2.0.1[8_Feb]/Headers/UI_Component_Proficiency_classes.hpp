#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Component_Proficiency.UI_Component_Proficiency_C
// Inherited Bytes: 0x260 | Struct Size: 0x281
struct UUI_Component_Proficiency_C : UUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x260 | Size: 0x8
	struct UImage* Img_ProficiencyIcon; // Offset: 0x268 | Size: 0x8
	struct USizeBox* SizeBox_1; // Offset: 0x270 | Size: 0x8
	float Size; // Offset: 0x278 | Size: 0x4
	int32_t Lvl; // Offset: 0x27c | Size: 0x4
	bool S; // Offset: 0x280 | Size: 0x1

	// Functions

	// Object: Function UI_Component_Proficiency.UI_Component_Proficiency_C.SetLvl
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x5) ]
	void SetLvl(int32_t Lvl, bool S);

	// Object: Function UI_Component_Proficiency.UI_Component_Proficiency_C.SetSize
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetSize(float Size);

	// Object: Function UI_Component_Proficiency.UI_Component_Proficiency_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_Component_Proficiency.UI_Component_Proficiency_C.ExecuteUbergraph_UI_Component_Proficiency
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_Component_Proficiency(int32_t EntryPoint);
};

