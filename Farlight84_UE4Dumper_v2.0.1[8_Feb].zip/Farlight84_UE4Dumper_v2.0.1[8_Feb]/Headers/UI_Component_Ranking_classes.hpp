#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Component_Ranking.UI_Component_Ranking_C
// Inherited Bytes: 0x490 | Struct Size: 0x4fc
struct UUI_Component_Ranking_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x490 | Size: 0x8
	struct UWidgetAnimation* Anim_Loop; // Offset: 0x498 | Size: 0x8
	struct UImage* Img_Glow; // Offset: 0x4a0 | Size: 0x8
	struct UImage* Img_Glow_2; // Offset: 0x4a8 | Size: 0x8
	struct UImage* Img_RankingBg; // Offset: 0x4b0 | Size: 0x8
	struct UImage* Img_Star; // Offset: 0x4b8 | Size: 0x8
	struct UImage* img_Top3; // Offset: 0x4c0 | Size: 0x8
	struct UImage* Img_Wipes; // Offset: 0x4c8 | Size: 0x8
	struct UImage* Img_Wipes_2; // Offset: 0x4d0 | Size: 0x8
	struct UImage* Img_Wipes_3; // Offset: 0x4d8 | Size: 0x8
	struct USizeBox* SizeBox_69; // Offset: 0x4e0 | Size: 0x8
	struct USolarTextBlock* Txt_Ranking; // Offset: 0x4e8 | Size: 0x8
	enum class E_RankingType RankingType; // Offset: 0x4f0 | Size: 0x1
	char pad_0x4F1[0x3]; // Offset: 0x4f1 | Size: 0x3
	struct FVector2D Size; // Offset: 0x4f4 | Size: 0x8

	// Functions

	// Object: Function UI_Component_Ranking.UI_Component_Ranking_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();

	// Object: Function UI_Component_Ranking.UI_Component_Ranking_C.Set Size
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x8) ]
	void Set Size(struct FVector2D Size);

	// Object: Function UI_Component_Ranking.UI_Component_Ranking_C.SetRankingState
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetRankingState(enum class E_RankingType RankingType);

	// Object: Function UI_Component_Ranking.UI_Component_Ranking_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_Component_Ranking.UI_Component_Ranking_C.ExecuteUbergraph_UI_Component_Ranking
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_Component_Ranking(int32_t EntryPoint);
};

