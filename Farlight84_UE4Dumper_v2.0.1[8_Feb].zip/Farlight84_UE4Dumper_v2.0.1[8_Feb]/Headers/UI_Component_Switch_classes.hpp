#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Component_Switch.UI_Component_Switch_C
// Inherited Bytes: 0x260 | Struct Size: 0x2e9
struct UUI_Component_Switch_C : UUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x260 | Size: 0x8
	struct UWidgetAnimation* Anim_SwitchCycle; // Offset: 0x268 | Size: 0x8
	struct UWidgetAnimation* Anim_Switch; // Offset: 0x270 | Size: 0x8
	struct UImage* Img_Line; // Offset: 0x278 | Size: 0x8
	struct UImage* Img_Switch; // Offset: 0x280 | Size: 0x8
	struct USizeBox* Size; // Offset: 0x288 | Size: 0x8
	struct USizeBox* SizeBox_1; // Offset: 0x290 | Size: 0x8
	struct USolarTextBlock* Text_Universal; // Offset: 0x298 | Size: 0x8
	struct UButton* TouchArea; // Offset: 0x2a0 | Size: 0x8
	bool IsCircleType; // Offset: 0x2a8 | Size: 0x1
	bool Switch_On; // Offset: 0x2a9 | Size: 0x1
	char pad_0x2AA[0x2]; // Offset: 0x2aa | Size: 0x2
	struct FVector2D TouchSize; // Offset: 0x2ac | Size: 0x8
	char pad_0x2B4[0x4]; // Offset: 0x2b4 | Size: 0x4
	struct FMulticastInlineDelegate OnStateChanged; // Offset: 0x2b8 | Size: 0x10
	struct FVector2D SwitchSize; // Offset: 0x2c8 | Size: 0x8
	bool bCustomClicked; // Offset: 0x2d0 | Size: 0x1
	char pad_0x2D1[0x7]; // Offset: 0x2d1 | Size: 0x7
	struct FMulticastInlineDelegate OnSwitchClicked; // Offset: 0x2d8 | Size: 0x10
	bool Text; // Offset: 0x2e8 | Size: 0x1

	// Functions

	// Object: Function UI_Component_Switch.UI_Component_Switch_C.SetType
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetType(bool IsCircleType);

	// Object: Function UI_Component_Switch.UI_Component_Switch_C.InitValue
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void InitValue(bool InValue);

	// Object: Function UI_Component_Switch.UI_Component_Switch_C.SetValue
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0x3) ]
	void SetValue(bool InValue, bool CallChangeEvent, bool PlayAnimation);

	// Object: Function UI_Component_Switch.UI_Component_Switch_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_Component_Switch.UI_Component_Switch_C.BndEvt__TouchArea_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature
	// Flags: [BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void BndEvt__TouchArea_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature();

	// Object: Function UI_Component_Switch.UI_Component_Switch_C.ExecuteUbergraph_UI_Component_Switch
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_Component_Switch(int32_t EntryPoint);

	// Object: Function UI_Component_Switch.UI_Component_Switch_C.OnSwitchClicked__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnSwitchClicked__DelegateSignature();

	// Object: Function UI_Component_Switch.UI_Component_Switch_C.OnStateChanged__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnStateChanged__DelegateSignature(bool NewValue);
};

