#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Component_Tips.UI_Component_Tips_C
// Inherited Bytes: 0x490 | Struct Size: 0x59f
struct UUI_Component_Tips_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x490 | Size: 0x8
	struct UWidgetAnimation* Anim_Exit; // Offset: 0x498 | Size: 0x8
	struct UWidgetAnimation* Anim_Loop; // Offset: 0x4a0 | Size: 0x8
	struct UWidgetAnimation* Anim_Enter; // Offset: 0x4a8 | Size: 0x8
	struct UOverlay* Arrow_B; // Offset: 0x4b0 | Size: 0x8
	struct UOverlay* Arrow_L; // Offset: 0x4b8 | Size: 0x8
	struct UOverlay* Arrow_R; // Offset: 0x4c0 | Size: 0x8
	struct USizeBox* Box_Reward; // Offset: 0x4c8 | Size: 0x8
	struct UImage* Img_BG; // Offset: 0x4d0 | Size: 0x8
	struct UImage* Img_Light; // Offset: 0x4d8 | Size: 0x8
	struct UImage* Img_Light_2; // Offset: 0x4e0 | Size: 0x8
	struct UImage* Img_Mininum; // Offset: 0x4e8 | Size: 0x8
	struct USolarListView* List_Item; // Offset: 0x4f0 | Size: 0x8
	struct UCommonTileView* List_Reward; // Offset: 0x4f8 | Size: 0x8
	struct UUI_Target_Medal_Challenge_S_C* Medal_2; // Offset: 0x500 | Size: 0x8
	struct UUI_Target_Medal_Challenge_S_C* Medal_3; // Offset: 0x508 | Size: 0x8
	struct UUI_Target_Medal_Challenge_S_C* Medal_4; // Offset: 0x510 | Size: 0x8
	struct UUI_Target_Medal_Challenge_S_C* Medal_5; // Offset: 0x518 | Size: 0x8
	struct UHorizontalBox* Panel_Medal; // Offset: 0x520 | Size: 0x8
	struct USizeBox* SizeBox_2; // Offset: 0x528 | Size: 0x8
	struct USpacer* Spacer_390; // Offset: 0x530 | Size: 0x8
	struct UUI_Component_HyperLink_C* Txt_Details; // Offset: 0x538 | Size: 0x8
	struct USolarTextBlock* Txt_Num; // Offset: 0x540 | Size: 0x8
	struct USolarTextBlock* Txt_Title; // Offset: 0x548 | Size: 0x8
	struct USolarTextBlock* Txt_Type; // Offset: 0x550 | Size: 0x8
	struct UUI_Component_Btn_C* UI_Component_Btn; // Offset: 0x558 | Size: 0x8
	struct UUI_Component_Item_C* UI_Component_Item; // Offset: 0x560 | Size: 0x8
	struct UUI_Shop_Tips_Video_C* UI_Shop_Tips_Video; // Offset: 0x568 | Size: 0x8
	struct UVerticalBox* VerticalBox_41; // Offset: 0x570 | Size: 0x8
	bool Left; // Offset: 0x578 | Size: 0x1
	bool Right; // Offset: 0x579 | Size: 0x1
	bool Btn; // Offset: 0x57a | Size: 0x1
	bool Num; // Offset: 0x57b | Size: 0x1
	bool Item; // Offset: 0x57c | Size: 0x1
	char pad_0x57D[0x3]; // Offset: 0x57d | Size: 0x3
	float Location; // Offset: 0x580 | Size: 0x4
	bool Title; // Offset: 0x584 | Size: 0x1
	bool Medal; // Offset: 0x585 | Size: 0x1
	bool Task; // Offset: 0x586 | Size: 0x1
	bool Detail; // Offset: 0x587 | Size: 0x1
	bool Bottom; // Offset: 0x588 | Size: 0x1
	enum class ESlateColorStylingMode NewVar_1; // Offset: 0x589 | Size: 0x1
	char pad_0x58A[0x2]; // Offset: 0x58a | Size: 0x2
	struct FLinearColor NewVar_2; // Offset: 0x58c | Size: 0x10
	bool IsHaveVideo; // Offset: 0x59c | Size: 0x1
	bool IsReward; // Offset: 0x59d | Size: 0x1
	bool bShowItemTypeTxt; // Offset: 0x59e | Size: 0x1

	// Functions

	// Object: Function UI_Component_Tips.UI_Component_Tips_C.OnInitialized
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x1015dbdd8
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnInitialized();

	// Object: Function UI_Component_Tips.UI_Component_Tips_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();

	// Object: Function UI_Component_Tips.UI_Component_Tips_C.SetBtnVideo
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetBtnVideo(bool NewParam);

	// Object: Function UI_Component_Tips.UI_Component_Tips_C.BP_OnEntryReleased
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void BP_OnEntryReleased();

	// Object: Function UI_Component_Tips.UI_Component_Tips_C.BP_OnItemExpansionChanged
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void BP_OnItemExpansionChanged(bool bIsExpanded);

	// Object: Function UI_Component_Tips.UI_Component_Tips_C.BP_OnItemSelectionChanged
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void BP_OnItemSelectionChanged(bool bIsSelected);

	// Object: Function UI_Component_Tips.UI_Component_Tips_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_Component_Tips.UI_Component_Tips_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void Construct();

	// Object: Function UI_Component_Tips.UI_Component_Tips_C.ChangeTipStatus
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void ChangeTipStatus();

	// Object: Function UI_Component_Tips.UI_Component_Tips_C.BndEvt__UI_Shop_Tips_Video_K2Node_ComponentBoundEvent_0_OnBtnPlayVideoClicked__DelegateSignature
	// Flags: [BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void BndEvt__UI_Shop_Tips_Video_K2Node_ComponentBoundEvent_0_OnBtnPlayVideoClicked__DelegateSignature();

	// Object: Function UI_Component_Tips.UI_Component_Tips_C.ExecuteUbergraph_UI_Component_Tips
	// Flags: [Final|UbergraphFunction|HasDefaults]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_Component_Tips(int32_t EntryPoint);
};

