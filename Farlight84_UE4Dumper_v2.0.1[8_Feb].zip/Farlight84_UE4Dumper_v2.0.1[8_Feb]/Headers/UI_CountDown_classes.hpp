#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_CountDown.UI_CountDown_C
// Inherited Bytes: 0x490 | Struct Size: 0x4d1
struct UUI_CountDown_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x490 | Size: 0x8
	struct UWidgetAnimation* Flip; // Offset: 0x498 | Size: 0x8
	struct UTextBlock* Number; // Offset: 0x4a0 | Size: 0x8
	struct UUI_HUD_Notice_Lv3_C* UI_HUD_Notice_Lv3; // Offset: 0x4a8 | Size: 0x8
	struct UWidgetSwitcher* wStyle; // Offset: 0x4b0 | Size: 0x8
	int32_t Time; // Offset: 0x4b8 | Size: 0x4
	char pad_0x4BC[0x4]; // Offset: 0x4bc | Size: 0x4
	struct FString TimeName; // Offset: 0x4c0 | Size: 0x10
	enum class E_CountDownStyle Type; // Offset: 0x4d0 | Size: 0x1

	// Functions

	// Object: Function UI_CountDown.UI_CountDown_C.SequenceEvent__ENTRYPOINTUI_CountDown_1
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x8) ]
	void SequenceEvent__ENTRYPOINTUI_CountDown_1(struct UOverlay* NumberContainer);

	// Object: Function UI_CountDown.UI_CountDown_C.UpdateCountDown
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void UpdateCountDown(int32_t NewTime);

	// Object: Function UI_CountDown.UI_CountDown_C.SetMiniCountDownText
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetMiniCountDownText(struct FString InText);

	// Object: Function UI_CountDown.UI_CountDown_C.SetCountDownStyle
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetCountDownStyle(enum class E_CountDownStyle Style);

	// Object: Function UI_CountDown.UI_CountDown_C.Finish
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void Finish();

	// Object: Function UI_CountDown.UI_CountDown_C.NumberContainer_Event_2
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x8) ]
	void NumberContainer_Event_2(struct UOverlay* NumberContainer);

	// Object: Function UI_CountDown.UI_CountDown_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_CountDown.UI_CountDown_C.
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void (int32_t Time);

	// Object: Function UI_CountDown.UI_CountDown_C.CustomEvent_3
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void CustomEvent_3();

	// Object: Function UI_CountDown.UI_CountDown_C.
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x10) ]
	void (struct FString );

	// Object: Function UI_CountDown.UI_CountDown_C.CountDownBySingleNumber
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void CountDownBySingleNumber(int32_t Number);

	// Object: Function UI_CountDown.UI_CountDown_C.CustomEvent_1
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0xc) ]
	void CustomEvent_1(enum class ESCMDataChangeType ChangeType, int32_t OldValue, int32_t NewValue);

	// Object: Function UI_CountDown.UI_CountDown_C.CustomEvent_2
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0xc) ]
	void CustomEvent_2(enum class ESCMDataChangeType ChangeType, int32_t OldValue, int32_t NewValue);

	// Object: Function UI_CountDown.UI_CountDown_C.ExecuteUbergraph_UI_CountDown
	// Flags: [Final|UbergraphFunction|HasDefaults]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_CountDown(int32_t EntryPoint);
};

