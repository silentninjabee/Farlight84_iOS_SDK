#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_CustomizeLayout_JoyStickControl_Mode3.UI_CustomizeLayout_JoyStickControl_Mode3_C
// Inherited Bytes: 0x490 | Struct Size: 0x810
struct UUI_CustomizeLayout_JoyStickControl_Mode3_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x490 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* BT_Cardown_Drag_2; // Offset: 0x498 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* BT_CarInfo_Drag; // Offset: 0x4a0 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* BT_Carup_Drag; // Offset: 0x4a8 | Size: 0x8
	struct USolarButton* BT_ChangeSeat; // Offset: 0x4b0 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* BT_Drive_Stop_Drag; // Offset: 0x4b8 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* BT_DriveJoyStick_Drag; // Offset: 0x4c0 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* BT_DriveLeft; // Offset: 0x4c8 | Size: 0x8
	struct UImage* BT_Driver_Fire; // Offset: 0x4d0 | Size: 0x8
	struct UImage* BT_Driver_Fire_2; // Offset: 0x4d8 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* BT_Driver_Fire_Drag; // Offset: 0x4e0 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* BT_Driver_Fire_Drag_2; // Offset: 0x4e8 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* BT_DriveRight; // Offset: 0x4f0 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* BT_DriveShot_Drag; // Offset: 0x4f8 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* BT_ExitWeapon_Drag; // Offset: 0x500 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* BT_Gunsight_Drag; // Offset: 0x508 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* BT_JoystickSprint_Drag; // Offset: 0x510 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* BT_OutVehicle_Drag; // Offset: 0x518 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* BT_QuickADS_Drag; // Offset: 0x520 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* BT_Reload_Drag; // Offset: 0x528 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* BT_Skill_Drag_1; // Offset: 0x530 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* BT_Skill_Drag_2; // Offset: 0x538 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* BT_Switch_Drag; // Offset: 0x540 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* BT_Trumpet_Drag; // Offset: 0x548 | Size: 0x8
	struct UUniformGridPanel* GridPanel_Normal; // Offset: 0x550 | Size: 0x8
	struct UImage* Image; // Offset: 0x558 | Size: 0x8
	struct UImage* Image_4; // Offset: 0x560 | Size: 0x8
	struct UImage* Image_5; // Offset: 0x568 | Size: 0x8
	struct UImage* Image_6; // Offset: 0x570 | Size: 0x8
	struct UImage* Image_7; // Offset: 0x578 | Size: 0x8
	struct UImage* Image_8; // Offset: 0x580 | Size: 0x8
	struct UImage* Image_9; // Offset: 0x588 | Size: 0x8
	struct UImage* Image_10; // Offset: 0x590 | Size: 0x8
	struct UImage* Image_11; // Offset: 0x598 | Size: 0x8
	struct UImage* Image_191; // Offset: 0x5a0 | Size: 0x8
	struct UImage* Image_242; // Offset: 0x5a8 | Size: 0x8
	struct UImage* Image_683; // Offset: 0x5b0 | Size: 0x8
	struct UImage* Image_792; // Offset: 0x5b8 | Size: 0x8
	struct UImage* Image_841; // Offset: 0x5c0 | Size: 0x8
	struct UImage* Image_Reload; // Offset: 0x5c8 | Size: 0x8
	struct UImage* Image_ReloadBg; // Offset: 0x5d0 | Size: 0x8
	struct UImage* Img_BG_2; // Offset: 0x5d8 | Size: 0x8
	struct UImage* Img_Body_2; // Offset: 0x5e0 | Size: 0x8
	struct UImage* img_Brand; // Offset: 0x5e8 | Size: 0x8
	struct UImage* Img_Cardown_2; // Offset: 0x5f0 | Size: 0x8
	struct UImage* Img_Carup_2; // Offset: 0x5f8 | Size: 0x8
	struct UImage* Img_Drive_Shot_Bg; // Offset: 0x600 | Size: 0x8
	struct UImage* Img_Drive_Shot_Icon; // Offset: 0x608 | Size: 0x8
	struct UImage* Img_DriverSeat; // Offset: 0x610 | Size: 0x8
	struct UImage* Img_Exit; // Offset: 0x618 | Size: 0x8
	struct UImage* Img_Icon; // Offset: 0x620 | Size: 0x8
	struct UImage* Img_Icon_3; // Offset: 0x628 | Size: 0x8
	struct UImage* Img_JoystickSprint_Select; // Offset: 0x630 | Size: 0x8
	struct UImage* Img_Select; // Offset: 0x638 | Size: 0x8
	struct UImage* Img_Select_2; // Offset: 0x640 | Size: 0x8
	struct UImage* Img_Select_4; // Offset: 0x648 | Size: 0x8
	struct UImage* Img_Select_5; // Offset: 0x650 | Size: 0x8
	struct UImage* Img_Select_6; // Offset: 0x658 | Size: 0x8
	struct UImage* Img_Select_7; // Offset: 0x660 | Size: 0x8
	struct UImage* Img_Select_8; // Offset: 0x668 | Size: 0x8
	struct UImage* Img_Select_9; // Offset: 0x670 | Size: 0x8
	struct UImage* Img_Select_10; // Offset: 0x678 | Size: 0x8
	struct UImage* Img_Select_11; // Offset: 0x680 | Size: 0x8
	struct UImage* Img_Select_12; // Offset: 0x688 | Size: 0x8
	struct UImage* Img_Select_13; // Offset: 0x690 | Size: 0x8
	struct UImage* Img_Select_14; // Offset: 0x698 | Size: 0x8
	struct UImage* Img_Select_16; // Offset: 0x6a0 | Size: 0x8
	struct UImage* Img_Select_17; // Offset: 0x6a8 | Size: 0x8
	struct UImage* Img_Select_19; // Offset: 0x6b0 | Size: 0x8
	struct UImage* Img_Select_25; // Offset: 0x6b8 | Size: 0x8
	struct UImage* Img_Select_CarInfo; // Offset: 0x6c0 | Size: 0x8
	struct UImage* Img_Select_QuickADS; // Offset: 0x6c8 | Size: 0x8
	struct UImage* Img_SkillOuter; // Offset: 0x6d0 | Size: 0x8
	struct UImage* Img_SkillOuter_2; // Offset: 0x6d8 | Size: 0x8
	struct UImage* Img_Stop; // Offset: 0x6e0 | Size: 0x8
	struct UImage* Img_WeakPoint; // Offset: 0x6e8 | Size: 0x8
	struct UImage* Img_WeakPoint_6; // Offset: 0x6f0 | Size: 0x8
	struct UImage* Img_WeakPoint_7; // Offset: 0x6f8 | Size: 0x8
	struct UImage* Img_WeakPoint_8; // Offset: 0x700 | Size: 0x8
	struct UUI_Customize_Data_C* LayoutData; // Offset: 0x708 | Size: 0x8
	struct UCanvasPanel* Panel_CarInfo; // Offset: 0x710 | Size: 0x8
	struct UCanvasPanel* Panel_DisableFire_Left; // Offset: 0x718 | Size: 0x8
	struct UCanvasPanel* Panel_DisableFire_Right; // Offset: 0x720 | Size: 0x8
	struct UCanvasPanel* Panel_Drive_Out; // Offset: 0x728 | Size: 0x8
	struct UCanvasPanel* Panel_DriveCardown; // Offset: 0x730 | Size: 0x8
	struct UCanvasPanel* Panel_DriveCarup; // Offset: 0x738 | Size: 0x8
	struct UCanvasPanel* Panel_DriveLeft_JoyStick; // Offset: 0x740 | Size: 0x8
	struct UCanvasPanel* Panel_DriveRight_JoyStick; // Offset: 0x748 | Size: 0x8
	struct UCanvasPanel* Panel_DriveShot; // Offset: 0x750 | Size: 0x8
	struct UCanvasPanel* Panel_Gunsight; // Offset: 0x758 | Size: 0x8
	struct UCanvasPanel* Panel_JoystickSprint; // Offset: 0x760 | Size: 0x8
	struct UCanvasPanel* Panel_Line; // Offset: 0x768 | Size: 0x8
	struct UCanvasPanel* Panel_MoveJoyStick; // Offset: 0x770 | Size: 0x8
	struct UCanvasPanel* Panel_MoveJoyStickScaleAndOpacity; // Offset: 0x778 | Size: 0x8
	struct UCanvasPanel* Panel_QuickADS; // Offset: 0x780 | Size: 0x8
	struct UCanvasPanel* Panel_Reload; // Offset: 0x788 | Size: 0x8
	struct UCanvasPanel* Panel_SwitchSeat; // Offset: 0x790 | Size: 0x8
	struct UCanvasPanel* Panel_Trumpet; // Offset: 0x798 | Size: 0x8
	struct UCanvasPanel* Panel_Vehicle_PrimaryFire; // Offset: 0x7a0 | Size: 0x8
	struct UCanvasPanel* Panel_Vehicle_SecondaryFire; // Offset: 0x7a8 | Size: 0x8
	struct UCanvasPanel* Panel_VehicleDrift; // Offset: 0x7b0 | Size: 0x8
	struct UCanvasPanel* Panel_VehicleSkill_1; // Offset: 0x7b8 | Size: 0x8
	struct UCanvasPanel* Panel_VehicleSkill_2; // Offset: 0x7c0 | Size: 0x8
	struct UCanvasPanel* Panel_Weapon_Exit; // Offset: 0x7c8 | Size: 0x8
	struct USolarCheckBox* Seat1; // Offset: 0x7d0 | Size: 0x8
	struct USolarCheckBox* Seat2; // Offset: 0x7d8 | Size: 0x8
	struct USolarCheckBox* Seat3; // Offset: 0x7e0 | Size: 0x8
	struct USolarCheckBox* Seat4; // Offset: 0x7e8 | Size: 0x8
	struct UCheckBoxGroup* SeatFlag; // Offset: 0x7f0 | Size: 0x8
	struct UTextBlock* Txt_Health; // Offset: 0x7f8 | Size: 0x8
	struct UTextBlock* Txt_Health_percent; // Offset: 0x800 | Size: 0x8
	struct UTextBlock* Txt_Speed_2; // Offset: 0x808 | Size: 0x8

	// Functions

	// Object: Function UI_CustomizeLayout_JoyStickControl_Mode3.UI_CustomizeLayout_JoyStickControl_Mode3_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();

	// Object: Function UI_CustomizeLayout_JoyStickControl_Mode3.UI_CustomizeLayout_JoyStickControl_Mode3_C.Get_Hero01_CheckedState_1
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class ECheckBoxState Get_Hero01_CheckedState_1();

	// Object: Function UI_CustomizeLayout_JoyStickControl_Mode3.UI_CustomizeLayout_JoyStickControl_Mode3_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_CustomizeLayout_JoyStickControl_Mode3.UI_CustomizeLayout_JoyStickControl_Mode3_C.ExecuteUbergraph_UI_CustomizeLayout_JoyStickControl_Mode3
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_CustomizeLayout_JoyStickControl_Mode3(int32_t EntryPoint);
};

