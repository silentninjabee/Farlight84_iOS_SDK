#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Lobby_Banner.UI_Lobby_Banner_C
// Inherited Bytes: 0x490 | Struct Size: 0x4d1
struct UUI_Lobby_Banner_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x490 | Size: 0x8
	struct USizeBox* BannerSizeBox; // Offset: 0x498 | Size: 0x8
	struct UUI_Warehouse_DragPanel_C* DragPanel; // Offset: 0x4a0 | Size: 0x8
	struct USolarImageURL* Image_URL; // Offset: 0x4a8 | Size: 0x8
	struct UImage* Img_Hover; // Offset: 0x4b0 | Size: 0x8
	struct UCanvasPanel* Panel_Shortcut_HD; // Offset: 0x4b8 | Size: 0x8
	struct USolarListView* SolarListView_Banner; // Offset: 0x4c0 | Size: 0x8
	struct USolarListView* SolarListView_Image; // Offset: 0x4c8 | Size: 0x8
	enum class E_TabLobbyItemState StateHD; // Offset: 0x4d0 | Size: 0x1

	// Functions

	// Object: DelegateFunction UI_Lobby_Banner.UI_Lobby_Banner_C.OnListViewScrolled_34E5B8DE8D4940CAF60BF69417A8B503
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015c616c
	// Return & Params: [ Num(2) Size(0x8) ]
	void OnListViewScrolled_34E5B8DE8D4940CAF60BF69417A8B503(float ItemOffset, float DistanceRemaining);

	// Object: DelegateFunction UI_Lobby_Banner.UI_Lobby_Banner_C.OnURLDownloadFinish_2CFA3450754EBAB8C9217DBB8C4F70AF
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015c616c
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnURLDownloadFinish_2CFA3450754EBAB8C9217DBB8C4F70AF(bool bSuccess);

	// Object: Function UI_Lobby_Banner.UI_Lobby_Banner_C.OnMouseButtonDown
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x1015dbdd8
	// Return & Params: [ Num(3) Size(0x160) ]
	struct FEventReply OnMouseButtonDown(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent);

	// Object: Function UI_Lobby_Banner.UI_Lobby_Banner_C.OnMouseButtonUp
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x1015dbdd8
	// Return & Params: [ Num(3) Size(0x160) ]
	struct FEventReply OnMouseButtonUp(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent);

	// Object: Function UI_Lobby_Banner.UI_Lobby_Banner_C.OnSolarUIClosed
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x1015dbdd8
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnSolarUIClosed();

	// Object: Function UI_Lobby_Banner.UI_Lobby_Banner_C.OnSolarUIOpened
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x1015dbdd8
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnSolarUIOpened();

	// Object: Function UI_Lobby_Banner.UI_Lobby_Banner_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();

	// Object: Function UI_Lobby_Banner.UI_Lobby_Banner_C.SetStateHD
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetStateHD(enum class E_TabLobbyItemState State);

	// Object: Function UI_Lobby_Banner.UI_Lobby_Banner_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_Lobby_Banner.UI_Lobby_Banner_C.OnMouseEnter
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0xa8) ]
	void OnMouseEnter(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent);

	// Object: Function UI_Lobby_Banner.UI_Lobby_Banner_C.OnMouseLeave
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x70) ]
	void OnMouseLeave(struct FPointerEvent& MouseEvent);

	// Object: Function UI_Lobby_Banner.UI_Lobby_Banner_C.ExecuteUbergraph_UI_Lobby_Banner
	// Flags: [Final|UbergraphFunction|HasDefaults]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_Lobby_Banner(int32_t EntryPoint);
};

