#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Lobby_DownLoad_Slot.UI_Lobby_DownLoad_Slot_C
// Inherited Bytes: 0x4a0 | Struct Size: 0x500
struct UUI_Lobby_DownLoad_Slot_C : USolarItemCardViewWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x4a0 | Size: 0x8
	struct USolarButton* Btn_Down; // Offset: 0x4a8 | Size: 0x8
	struct USolarButton* Btn_Downing; // Offset: 0x4b0 | Size: 0x8
	struct USolarButton* Btn_Pause; // Offset: 0x4b8 | Size: 0x8
	struct USolarImage* Img_Line; // Offset: 0x4c0 | Size: 0x8
	struct UOverlay* Overlay_Finish; // Offset: 0x4c8 | Size: 0x8
	struct UProgressBar* ProgressBar_Download; // Offset: 0x4d0 | Size: 0x8
	struct USolarTextBlock* Text_Title; // Offset: 0x4d8 | Size: 0x8
	struct USolarTextBlock* Txt_Numb; // Offset: 0x4e0 | Size: 0x8
	struct USolarTextBlock* Txt_Speed; // Offset: 0x4e8 | Size: 0x8
	struct UWidgetSwitcher* WidgetSwitcher_Btn; // Offset: 0x4f0 | Size: 0x8
	struct UWidgetSwitcher* WidgetSwitcher_Text; // Offset: 0x4f8 | Size: 0x8

	// Functions

	// Object: Function UI_Lobby_DownLoad_Slot.UI_Lobby_DownLoad_Slot_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();

	// Object: Function UI_Lobby_DownLoad_Slot.UI_Lobby_DownLoad_Slot_C.SetLineState
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetLineState(bool IsHide);

	// Object: Function UI_Lobby_DownLoad_Slot.UI_Lobby_DownLoad_Slot_C.DownStatusChanged
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void DownStatusChanged(enum class ESolarItemDownloadType NewParam);

	// Object: Function UI_Lobby_DownLoad_Slot.UI_Lobby_DownLoad_Slot_C.BP_OnEntryReleased
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void BP_OnEntryReleased();

	// Object: Function UI_Lobby_DownLoad_Slot.UI_Lobby_DownLoad_Slot_C.BP_OnItemExpansionChanged
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void BP_OnItemExpansionChanged(bool bIsExpanded);

	// Object: Function UI_Lobby_DownLoad_Slot.UI_Lobby_DownLoad_Slot_C.BP_OnItemSelectionChanged
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void BP_OnItemSelectionChanged(bool bIsSelected);

	// Object: Function UI_Lobby_DownLoad_Slot.UI_Lobby_DownLoad_Slot_C.OnListItemObjectSet
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x8) ]
	void OnListItemObjectSet(struct UObject* ListItemObject);

	// Object: Function UI_Lobby_DownLoad_Slot.UI_Lobby_DownLoad_Slot_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_Lobby_DownLoad_Slot.UI_Lobby_DownLoad_Slot_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void Construct();

	// Object: Function UI_Lobby_DownLoad_Slot.UI_Lobby_DownLoad_Slot_C.BndEvt__Btn_Downing_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature
	// Flags: [BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void BndEvt__Btn_Downing_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature();

	// Object: Function UI_Lobby_DownLoad_Slot.UI_Lobby_DownLoad_Slot_C.ExecuteUbergraph_UI_Lobby_DownLoad_Slot
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_Lobby_DownLoad_Slot(int32_t EntryPoint);
};

