#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Lobby_Invite_Btn.UI_Lobby_Invite_Btn_C
// Inherited Bytes: 0x490 | Struct Size: 0x4b2
struct UUI_Lobby_Invite_Btn_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x490 | Size: 0x8
	struct UButton* Btn_Invite; // Offset: 0x498 | Size: 0x8
	struct UImage* Img_BG_2; // Offset: 0x4a0 | Size: 0x8
	struct UOverlay* Overlay_Txt; // Offset: 0x4a8 | Size: 0x8
	bool IsDesktop; // Offset: 0x4b0 | Size: 0x1
	enum class E_Type_State_Button StateDesktop; // Offset: 0x4b1 | Size: 0x1

	// Functions

	// Object: Function UI_Lobby_Invite_Btn.UI_Lobby_Invite_Btn_C.SetStateDesktop
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x2) ]
	void SetStateDesktop(bool IsDesktop, enum class E_Type_State_Button StateDesktop);

	// Object: Function UI_Lobby_Invite_Btn.UI_Lobby_Invite_Btn_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_Lobby_Invite_Btn.UI_Lobby_Invite_Btn_C.ExecuteUbergraph_UI_Lobby_Invite_Btn
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_Lobby_Invite_Btn(int32_t EntryPoint);
};

