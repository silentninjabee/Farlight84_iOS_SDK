#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Lobby_Mission_Reward.UI_Lobby_Mission_Reward_C
// Inherited Bytes: 0x490 | Struct Size: 0x4b0
struct UUI_Lobby_Mission_Reward_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x490 | Size: 0x8
	struct UWidgetAnimation* Anim_Enter; // Offset: 0x498 | Size: 0x8
	struct UButton* Btn_MissionReward; // Offset: 0x4a0 | Size: 0x8
	struct UImage* Img_Icon; // Offset: 0x4a8 | Size: 0x8

	// Functions

	// Object: DelegateFunction UI_Lobby_Mission_Reward.UI_Lobby_Mission_Reward_C.OnClicked_77E52859364EC527254109A2A29CC73C
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015c616c
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_77E52859364EC527254109A2A29CC73C();

	// Object: Function UI_Lobby_Mission_Reward.UI_Lobby_Mission_Reward_C.ConstructCopy
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void ConstructCopy();

	// Object: Function UI_Lobby_Mission_Reward.UI_Lobby_Mission_Reward_C.Destruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x1015dbdd8
	// Return & Params: [ Num(0) Size(0x0) ]
	void Destruct();

	// Object: Function UI_Lobby_Mission_Reward.UI_Lobby_Mission_Reward_C.OnSolarUIClosed
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x1015dbdd8
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnSolarUIClosed();

	// Object: Function UI_Lobby_Mission_Reward.UI_Lobby_Mission_Reward_C.OnSolarUIOpened
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x1015dbdd8
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnSolarUIOpened();

	// Object: Function UI_Lobby_Mission_Reward.UI_Lobby_Mission_Reward_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();

	// Object: Function UI_Lobby_Mission_Reward.UI_Lobby_Mission_Reward_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x1015dbdd8
	// Return & Params: [ Num(0) Size(0x0) ]
	void Construct();

	// Object: Function UI_Lobby_Mission_Reward.UI_Lobby_Mission_Reward_C.ExecuteUbergraph_UI_Lobby_Mission_Reward
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_Lobby_Mission_Reward(int32_t EntryPoint);
};

