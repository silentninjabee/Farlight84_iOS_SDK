#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Lobby_PlayerInfo.UI_Lobby_PlayerInfo_C
// Inherited Bytes: 0x490 | Struct Size: 0x4d8
struct UUI_Lobby_PlayerInfo_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x490 | Size: 0x8
	struct UButton* Btn_PlayerInfo; // Offset: 0x498 | Size: 0x8
	struct UCanvasPanel* Panel_PlayerInformation; // Offset: 0x4a0 | Size: 0x8
	struct UProgressBar* ProgressBar_PlayerExp; // Offset: 0x4a8 | Size: 0x8
	struct USolarRedHint_General_C* SolarRedHint_General_4; // Offset: 0x4b0 | Size: 0x8
	struct UTextBlock* Txt_PlayerLevel; // Offset: 0x4b8 | Size: 0x8
	struct UUI_Component_NationalFlag_C* UI_Component_NationalFlag; // Offset: 0x4c0 | Size: 0x8
	struct UUI_Component_PlayerHead_C* UI_Component_PlayerHead; // Offset: 0x4c8 | Size: 0x8
	struct UUI_Component_PlayerName_C* UI_Component_PlayerName; // Offset: 0x4d0 | Size: 0x8

	// Functions

	// Object: DelegateFunction UI_Lobby_PlayerInfo.UI_Lobby_PlayerInfo_C.OnClicked_B2A890B3E641BE88035A20BE43A24DF0
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015c616c
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_B2A890B3E641BE88035A20BE43A24DF0();

	// Object: Function UI_Lobby_PlayerInfo.UI_Lobby_PlayerInfo_C.Destruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x1015dbdd8
	// Return & Params: [ Num(0) Size(0x0) ]
	void Destruct();

	// Object: Function UI_Lobby_PlayerInfo.UI_Lobby_PlayerInfo_C.OnSolarUIClosed
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x1015dbdd8
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnSolarUIClosed();

	// Object: Function UI_Lobby_PlayerInfo.UI_Lobby_PlayerInfo_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x1015dbdd8
	// Return & Params: [ Num(0) Size(0x0) ]
	void Construct();

	// Object: Function UI_Lobby_PlayerInfo.UI_Lobby_PlayerInfo_C.OnSolarUIOpened
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x1015dbdd8
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnSolarUIOpened();

	// Object: Function UI_Lobby_PlayerInfo.UI_Lobby_PlayerInfo_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();

	// Object: Function UI_Lobby_PlayerInfo.UI_Lobby_PlayerInfo_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_Lobby_PlayerInfo.UI_Lobby_PlayerInfo_C.ExecuteUbergraph_UI_Lobby_PlayerInfo
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_Lobby_PlayerInfo(int32_t EntryPoint);
};

