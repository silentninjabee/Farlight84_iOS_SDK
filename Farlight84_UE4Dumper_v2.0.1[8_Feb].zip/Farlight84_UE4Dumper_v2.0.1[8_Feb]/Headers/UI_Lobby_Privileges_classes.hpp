#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Lobby_Privileges.UI_Lobby_Privileges_C
// Inherited Bytes: 0x490 | Struct Size: 0x4e1
struct UUI_Lobby_Privileges_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x490 | Size: 0x8
	struct UWidgetAnimation* Anim_Loop; // Offset: 0x498 | Size: 0x8
	struct USolarButton* Btn_Privileges; // Offset: 0x4a0 | Size: 0x8
	struct UImage* Img_Line; // Offset: 0x4a8 | Size: 0x8
	struct USizeBox* SizeBox; // Offset: 0x4b0 | Size: 0x8
	struct UWidgetSwitcher* WidgetSwitcher; // Offset: 0x4b8 | Size: 0x8
	bool IsLobby; // Offset: 0x4c0 | Size: 0x1
	char pad_0x4C1[0x3]; // Offset: 0x4c1 | Size: 0x3
	float X; // Offset: 0x4c4 | Size: 0x4
	float Y; // Offset: 0x4c8 | Size: 0x4
	char pad_0x4CC[0x4]; // Offset: 0x4cc | Size: 0x4
	struct FMulticastInlineDelegate OnBtnNetBarClicked; // Offset: 0x4d0 | Size: 0x10
	bool IsLine; // Offset: 0x4e0 | Size: 0x1

	// Functions

	// Object: Function UI_Lobby_Privileges.UI_Lobby_Privileges_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();

	// Object: Function UI_Lobby_Privileges.UI_Lobby_Privileges_C.SetPrivileges
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void SetPrivileges();

	// Object: Function UI_Lobby_Privileges.UI_Lobby_Privileges_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_Lobby_Privileges.UI_Lobby_Privileges_C.BndEvt__Btn_Privileges_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature
	// Flags: [BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void BndEvt__Btn_Privileges_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature();

	// Object: Function UI_Lobby_Privileges.UI_Lobby_Privileges_C.ExecuteUbergraph_UI_Lobby_Privileges
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_Lobby_Privileges(int32_t EntryPoint);

	// Object: Function UI_Lobby_Privileges.UI_Lobby_Privileges_C.OnBtnNetBarClicked__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnBtnNetBarClicked__DelegateSignature();
};

