#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Lobby_Recruit.UI_Lobby_Recruit_C
// Inherited Bytes: 0x490 | Struct Size: 0x4f6
struct UUI_Lobby_Recruit_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x490 | Size: 0x8
	struct UWidgetAnimation* Loop_Anim; // Offset: 0x498 | Size: 0x8
	struct UButton* Btn_Recruit; // Offset: 0x4a0 | Size: 0x8
	struct UButton* Btn_Recruit_2; // Offset: 0x4a8 | Size: 0x8
	struct UImage* Img_BG_Invite; // Offset: 0x4b0 | Size: 0x8
	struct UImage* Img_BG_Recruit; // Offset: 0x4b8 | Size: 0x8
	struct USizeBox* SizeBox_1; // Offset: 0x4c0 | Size: 0x8
	struct USolarTextBlock* Txt_Invite; // Offset: 0x4c8 | Size: 0x8
	struct USolarTextBlock* Txt_Invite1; // Offset: 0x4d0 | Size: 0x8
	struct USolarTextBlock* Txt_Invite2; // Offset: 0x4d8 | Size: 0x8
	struct USolarTextBlock* Txt_Recruit; // Offset: 0x4e0 | Size: 0x8
	bool Recruiting; // Offset: 0x4e8 | Size: 0x1
	char pad_0x4E9[0x3]; // Offset: 0x4e9 | Size: 0x3
	int32_t Size W; // Offset: 0x4ec | Size: 0x4
	int32_t Size H; // Offset: 0x4f0 | Size: 0x4
	enum class E_Type_State_Button StateDesktopInvite; // Offset: 0x4f4 | Size: 0x1
	enum class E_Type_State_Button StateDesktopRecruit; // Offset: 0x4f5 | Size: 0x1

	// Functions

	// Object: DelegateFunction UI_Lobby_Recruit.UI_Lobby_Recruit_C.OnClicked_3CD3C7CFD94C07C79FBD01935BB17F28
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015c616c
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_3CD3C7CFD94C07C79FBD01935BB17F28();

	// Object: DelegateFunction UI_Lobby_Recruit.UI_Lobby_Recruit_C.OnClicked_D2FA32B63F4C9213E95FE693321C1B20
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015c616c
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_D2FA32B63F4C9213E95FE693321C1B20();

	// Object: Function UI_Lobby_Recruit.UI_Lobby_Recruit_C.Destruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x1015dbdd8
	// Return & Params: [ Num(0) Size(0x0) ]
	void Destruct();

	// Object: Function UI_Lobby_Recruit.UI_Lobby_Recruit_C.ConstructCopy
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void ConstructCopy();

	// Object: Function UI_Lobby_Recruit.UI_Lobby_Recruit_C.OnSolarUIClosed
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x1015dbdd8
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnSolarUIClosed();

	// Object: Function UI_Lobby_Recruit.UI_Lobby_Recruit_C.OnSolarUIOpened
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x1015dbdd8
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnSolarUIOpened();

	// Object: Function UI_Lobby_Recruit.UI_Lobby_Recruit_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();

	// Object: Function UI_Lobby_Recruit.UI_Lobby_Recruit_C.SetSize
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x8) ]
	void SetSize(int32_t Size H, int32_t Size W);

	// Object: Function UI_Lobby_Recruit.UI_Lobby_Recruit_C.SetStateDesktop
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x2) ]
	void SetStateDesktop(enum class E_Type_State_Button StateDesktopInvite, enum class E_Type_State_Button StateDesktopRecruit);

	// Object: Function UI_Lobby_Recruit.UI_Lobby_Recruit_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_Lobby_Recruit.UI_Lobby_Recruit_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x1015dbdd8
	// Return & Params: [ Num(0) Size(0x0) ]
	void Construct();

	// Object: Function UI_Lobby_Recruit.UI_Lobby_Recruit_C.ExecuteUbergraph_UI_Lobby_Recruit
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_Lobby_Recruit(int32_t EntryPoint);
};

