#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Lobby_TeamInvite_MIni_Popup.UI_Lobby_TeamInvite_Mini_Popup_C
// Inherited Bytes: 0x490 | Struct Size: 0x5d1
struct UUI_Lobby_TeamInvite_Mini_Popup_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x490 | Size: 0x8
	struct UWidgetAnimation* Anim_Enter; // Offset: 0x498 | Size: 0x8
	struct USolarButton* Btn_Join_Common; // Offset: 0x4a0 | Size: 0x8
	struct UButton* Btn_Player; // Offset: 0x4a8 | Size: 0x8
	struct UButton* Btn_Player_3; // Offset: 0x4b0 | Size: 0x8
	struct UHorizontalBox* HorizentalBox_Spectator; // Offset: 0x4b8 | Size: 0x8
	struct UHorizontalBox* HorizontalBox_CreateRoom_Invitation; // Offset: 0x4c0 | Size: 0x8
	struct UHorizontalBox* HorizontalBox_Player; // Offset: 0x4c8 | Size: 0x8
	struct UHorizontalBox* HorizontalBox_Skydiving_Invitation; // Offset: 0x4d0 | Size: 0x8
	struct UHorizontalBox* HorizontalBox_Skydiving_Transfer; // Offset: 0x4d8 | Size: 0x8
	struct UHorizontalBox* HorizontalBox_Team_Application; // Offset: 0x4e0 | Size: 0x8
	struct UHorizontalBox* HorizontalBox_Team_Invitation; // Offset: 0x4e8 | Size: 0x8
	struct UImage* Img_Btn_Join; // Offset: 0x4f0 | Size: 0x8
	struct UImage* Img_GameMode_Icon; // Offset: 0x4f8 | Size: 0x8
	struct UImage* Img_Join_Common_Light; // Offset: 0x500 | Size: 0x8
	struct UImage* Img_Team_Num; // Offset: 0x508 | Size: 0x8
	struct UImage* Img_Title_Bg_2; // Offset: 0x510 | Size: 0x8
	struct UOverlay* Overlay_Avatar; // Offset: 0x518 | Size: 0x8
	struct UOverlay* Overlay_Avatar_3; // Offset: 0x520 | Size: 0x8
	struct UCanvasPanel* Panel_Info_CreateRoom_Invitation; // Offset: 0x528 | Size: 0x8
	struct UCanvasPanel* Panel_Info_Invitation; // Offset: 0x530 | Size: 0x8
	struct UCanvasPanel* Panel_Pop_Common; // Offset: 0x538 | Size: 0x8
	struct UProgressBar* ProgressBar_CountDown; // Offset: 0x540 | Size: 0x8
	struct UOverlay* SizeBox_Team_Num; // Offset: 0x548 | Size: 0x8
	struct UTickerWidget_C* Text_NickName; // Offset: 0x550 | Size: 0x8
	struct USolarTextBlock* Txt_Capacity; // Offset: 0x558 | Size: 0x8
	struct USolarTextBlock* Txt_GameMode; // Offset: 0x560 | Size: 0x8
	struct USolarTextBlock* Txt_Invitation; // Offset: 0x568 | Size: 0x8
	struct USolarTextBlock* Txt_Join_Common; // Offset: 0x570 | Size: 0x8
	struct UTextBlock* Txt_OBCurr; // Offset: 0x578 | Size: 0x8
	struct USolarTextBlock* Txt_OBTotal; // Offset: 0x580 | Size: 0x8
	struct UTextBlock* Txt_Player; // Offset: 0x588 | Size: 0x8
	struct USolarTextBlock* Txt_PlayerIn; // Offset: 0x590 | Size: 0x8
	struct USolarTextBlock* Txt_Room_Name; // Offset: 0x598 | Size: 0x8
	struct USolarTextBlock* Txt_Skydiving; // Offset: 0x5a0 | Size: 0x8
	struct USolarTextBlock* Txt_Skydiving_2; // Offset: 0x5a8 | Size: 0x8
	struct UUI_Component_Close_C* UI_Component_Close; // Offset: 0x5b0 | Size: 0x8
	struct UUI_Component_PlayerHead_C* UI_Component_PlayerHead_2; // Offset: 0x5b8 | Size: 0x8
	struct UUI_Component_PlayerHead_C* UI_Component_PlayerHead_3; // Offset: 0x5c0 | Size: 0x8
	enum class T_Type_Invitation Pop_Type; // Offset: 0x5c8 | Size: 0x1
	char pad_0x5C9[0x3]; // Offset: 0x5c9 | Size: 0x3
	int32_t Player; // Offset: 0x5cc | Size: 0x4
	bool IsNeedShow; // Offset: 0x5d0 | Size: 0x1

	// Functions

	// Object: Function UI_Lobby_TeamInvite_MIni_Popup.UI_Lobby_TeamInvite_Mini_Popup_C.OnClicked_6B9B156B3E4A62EC7D36BA9CD4005605
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	// Offset: 0x1015c616c
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_6B9B156B3E4A62EC7D36BA9CD4005605();

	// Object: DelegateFunction UI_Lobby_TeamInvite_MIni_Popup.UI_Lobby_TeamInvite_Mini_Popup_C.OnClicked_24D9346F024788807CD12EBCB4B503B1
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015c616c
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_24D9346F024788807CD12EBCB4B503B1();

	// Object: Function UI_Lobby_TeamInvite_MIni_Popup.UI_Lobby_TeamInvite_Mini_Popup_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x1015dbdd8
	// Return & Params: [ Num(0) Size(0x0) ]
	void Construct();

	// Object: Function UI_Lobby_TeamInvite_MIni_Popup.UI_Lobby_TeamInvite_Mini_Popup_C.Destruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x1015dbdd8
	// Return & Params: [ Num(0) Size(0x0) ]
	void Destruct();

	// Object: Function UI_Lobby_TeamInvite_MIni_Popup.UI_Lobby_TeamInvite_Mini_Popup_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();

	// Object: Function UI_Lobby_TeamInvite_MIni_Popup.UI_Lobby_TeamInvite_Mini_Popup_C.SetPlayer
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetPlayer(int32_t Num);

	// Object: Function UI_Lobby_TeamInvite_MIni_Popup.UI_Lobby_TeamInvite_Mini_Popup_C.SetType
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetType(enum class T_Type_Invitation Pop_Type);

	// Object: Function UI_Lobby_TeamInvite_MIni_Popup.UI_Lobby_TeamInvite_Mini_Popup_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_Lobby_TeamInvite_MIni_Popup.UI_Lobby_TeamInvite_Mini_Popup_C.ExecuteUbergraph_UI_Lobby_TeamInvite_Mini_Popup
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_Lobby_TeamInvite_Mini_Popup(int32_t EntryPoint);
};

