#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Lobby_Tips_Container.UI_Lobby_Tips_Container_C
// Inherited Bytes: 0x490 | Struct Size: 0x4c0
struct UUI_Lobby_Tips_Container_C : USolarUserWidget {
	// Fields
	struct USolarButton* Btn_BlockAllBtn; // Offset: 0x490 | Size: 0x8
	struct USolarButton* Btn_BlockBtn01; // Offset: 0x498 | Size: 0x8
	struct USolarButton* Btn_BlockBtn02; // Offset: 0x4a0 | Size: 0x8
	struct USolarButton* Btn_BlockBtn03; // Offset: 0x4a8 | Size: 0x8
	struct USolarButton* Btn_BlockBtn04; // Offset: 0x4b0 | Size: 0x8
	struct UCanvasPanel* CanvasPanel_Container; // Offset: 0x4b8 | Size: 0x8

	// Functions

	// Object: DelegateFunction UI_Lobby_Tips_Container.UI_Lobby_Tips_Container_C.OnClicked_1FE5E4945E48C8EF8D572AA68D70310D
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015c616c
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_1FE5E4945E48C8EF8D572AA68D70310D();

	// Object: DelegateFunction UI_Lobby_Tips_Container.UI_Lobby_Tips_Container_C.OnPressed_8CF7CDF3134A4B41FDB0AB8D8DFDE392
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015c616c
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnPressed_8CF7CDF3134A4B41FDB0AB8D8DFDE392();

	// Object: Function UI_Lobby_Tips_Container.UI_Lobby_Tips_Container_C.OnHide
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x1015dbdd8
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnHide();

	// Object: Function UI_Lobby_Tips_Container.UI_Lobby_Tips_Container_C.OnShow
	// Flags: [Native|Event|Protected|BlueprintEvent]
	// Offset: 0x1015dbdd8
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnShow();

	// Object: Function UI_Lobby_Tips_Container.UI_Lobby_Tips_Container_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x1015dbdd8
	// Return & Params: [ Num(0) Size(0x0) ]
	void Construct();

	// Object: Function UI_Lobby_Tips_Container.UI_Lobby_Tips_Container_C.Destruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x1015dbdd8
	// Return & Params: [ Num(0) Size(0x0) ]
	void Destruct();

	// Object: Function UI_Lobby_Tips_Container.UI_Lobby_Tips_Container_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();
};

