#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_MapMark_ReviveTeammates.UI_MapMark_ReviveTeammates_C
// Inherited Bytes: 0x4d0 | Struct Size: 0x548
struct UUI_MapMark_ReviveTeammates_C : UMapMarkBase {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x4d0 | Size: 0x8
	struct UWidgetAnimation* Occupy_Loop_Anim; // Offset: 0x4d8 | Size: 0x8
	struct UImage* Img_BG; // Offset: 0x4e0 | Size: 0x8
	struct UImage* Img_Light; // Offset: 0x4e8 | Size: 0x8
	struct UImage* Img_Light_2; // Offset: 0x4f0 | Size: 0x8
	struct UImage* Img_Revival; // Offset: 0x4f8 | Size: 0x8
	struct UVerticalBox* Panel; // Offset: 0x500 | Size: 0x8
	struct UScaleBox* ScaleBox_1; // Offset: 0x508 | Size: 0x8
	int32_t HideDistance; // Offset: 0x510 | Size: 0x4
	char pad_0x514[0x4]; // Offset: 0x514 | Size: 0x4
	struct TArray<struct FLinearColor> Color_2; // Offset: 0x518 | Size: 0x10
	struct TArray<struct FLinearColor> Color_3; // Offset: 0x528 | Size: 0x10
	struct FString PlayerId; // Offset: 0x538 | Size: 0x10

	// Functions

	// Object: Function UI_MapMark_ReviveTeammates.UI_MapMark_ReviveTeammates_C.Set Player ID And Change Color
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x10) ]
	void Set Player ID And Change Color(struct FString PlayerId);

	// Object: Function UI_MapMark_ReviveTeammates.UI_MapMark_ReviveTeammates_C.SetColor
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetColor(char Index);

	// Object: Function UI_MapMark_ReviveTeammates.UI_MapMark_ReviveTeammates_C.SetIcon
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0xc) ]
	void SetIcon(struct UWidget* Content, int32_t );

	// Object: Function UI_MapMark_ReviveTeammates.UI_MapMark_ReviveTeammates_C.Event_PlayAnim
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void Event_PlayAnim();

	// Object: Function UI_MapMark_ReviveTeammates.UI_MapMark_ReviveTeammates_C.Tick
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x3c) ]
	void Tick(struct FGeometry MyGeometry, float InDeltaTime);

	// Object: Function UI_MapMark_ReviveTeammates.UI_MapMark_ReviveTeammates_C.ExecuteUbergraph_UI_MapMark_ReviveTeammates
	// Flags: [Final|UbergraphFunction|HasDefaults]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_MapMark_ReviveTeammates(int32_t EntryPoint);
};

