#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_MicroPhoneOperation_Item.UI_MicroPhoneOperation_Item_C
// Inherited Bytes: 0x490 | Struct Size: 0x53c
struct UUI_MicroPhoneOperation_Item_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x490 | Size: 0x8
	struct UImage* BackBG; // Offset: 0x498 | Size: 0x8
	struct UImage* Img_TeamPos; // Offset: 0x4a0 | Size: 0x8
	struct UOverlay* Overlay_PosInTeam; // Offset: 0x4a8 | Size: 0x8
	struct USolarCheckBox* SolarCheckBox_Switch; // Offset: 0x4b0 | Size: 0x8
	struct FLinearColor Color1; // Offset: 0x4b8 | Size: 0x10
	struct FLinearColor Color2; // Offset: 0x4c8 | Size: 0x10
	struct FLinearColor Color3; // Offset: 0x4d8 | Size: 0x10
	struct FLinearColor Color4; // Offset: 0x4e8 | Size: 0x10
	struct FLinearColor ColorBG1; // Offset: 0x4f8 | Size: 0x10
	struct FLinearColor ColorBG2; // Offset: 0x508 | Size: 0x10
	struct FLinearColor ColorBG3; // Offset: 0x518 | Size: 0x10
	struct FLinearColor ColorBG4; // Offset: 0x528 | Size: 0x10
	int32_t OrderId; // Offset: 0x538 | Size: 0x4

	// Functions

	// Object: DelegateFunction UI_MicroPhoneOperation_Item.UI_MicroPhoneOperation_Item_C.OnCheckStateChanged_C51B2DE4544557494B82BDA17C0E0E80
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015c616c
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnCheckStateChanged_C51B2DE4544557494B82BDA17C0E0E80(bool bIsChecked);

	// Object: DelegateFunction UI_MicroPhoneOperation_Item.UI_MicroPhoneOperation_Item_C.OnCheckStateChanged_96418044A549C97AA2415DA2C7D42FAA
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015c616c
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnCheckStateChanged_96418044A549C97AA2415DA2C7D42FAA(bool bIsChecked);

	// Object: DelegateFunction UI_MicroPhoneOperation_Item.UI_MicroPhoneOperation_Item_C.OnCheckStateChanged_5CA1E934D84A4170D43108A248B1DDBC
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015c616c
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnCheckStateChanged_5CA1E934D84A4170D43108A248B1DDBC(bool bIsChecked);

	// Object: DelegateFunction UI_MicroPhoneOperation_Item.UI_MicroPhoneOperation_Item_C.OnCheckStateChanged_8D930A18F240109688C3B98346677E08
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015c616c
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnCheckStateChanged_8D930A18F240109688C3B98346677E08(bool bIsChecked);

	// Object: DelegateFunction UI_MicroPhoneOperation_Item.UI_MicroPhoneOperation_Item_C.OnCheckStateChanged_9799620EFF4BFFA0EB1F25B544EAD185
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015c616c
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnCheckStateChanged_9799620EFF4BFFA0EB1F25B544EAD185(bool bIsChecked);

	// Object: DelegateFunction UI_MicroPhoneOperation_Item.UI_MicroPhoneOperation_Item_C.OnCheckStateChanged_2EBD88F69D4A6896A5AD0687735C9223
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015c616c
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnCheckStateChanged_2EBD88F69D4A6896A5AD0687735C9223(bool bIsChecked);

	// Object: DelegateFunction UI_MicroPhoneOperation_Item.UI_MicroPhoneOperation_Item_C.OnCheckStateChanged_5CDA1EFDB54735213BADA7B332CF3509
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015c616c
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnCheckStateChanged_5CDA1EFDB54735213BADA7B332CF3509(bool bIsChecked);

	// Object: DelegateFunction UI_MicroPhoneOperation_Item.UI_MicroPhoneOperation_Item_C.OnCheckStateChanged_65134648EE4D2F452AA91BB44D0580C0
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015c616c
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnCheckStateChanged_65134648EE4D2F452AA91BB44D0580C0(bool bIsChecked);

	// Object: DelegateFunction UI_MicroPhoneOperation_Item.UI_MicroPhoneOperation_Item_C.OnCheckStateChanged_F441713E9943FCCDE97C578FAAA21D36
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015c616c
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnCheckStateChanged_F441713E9943FCCDE97C578FAAA21D36(bool bIsChecked);

	// Object: DelegateFunction UI_MicroPhoneOperation_Item.UI_MicroPhoneOperation_Item_C.OnCheckStateChanged_343C9461C546EC8458038FAEC86D3C74
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015c616c
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnCheckStateChanged_343C9461C546EC8458038FAEC86D3C74(bool bIsChecked);

	// Object: DelegateFunction UI_MicroPhoneOperation_Item.UI_MicroPhoneOperation_Item_C.OnCheckStateChanged_8C042C0D264058937CA41DA3BB759046
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015c616c
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnCheckStateChanged_8C042C0D264058937CA41DA3BB759046(bool bIsChecked);

	// Object: DelegateFunction UI_MicroPhoneOperation_Item.UI_MicroPhoneOperation_Item_C.OnCheckStateChanged_F0E6A83A57447A124CE0F38B7229F7C7
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015c616c
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnCheckStateChanged_F0E6A83A57447A124CE0F38B7229F7C7(bool bIsChecked);

	// Object: DelegateFunction UI_MicroPhoneOperation_Item.UI_MicroPhoneOperation_Item_C.OnCheckStateChanged_EE55FA892641C50E67B9F6B28B2AC455
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015c616c
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnCheckStateChanged_EE55FA892641C50E67B9F6B28B2AC455(bool bIsChecked);

	// Object: DelegateFunction UI_MicroPhoneOperation_Item.UI_MicroPhoneOperation_Item_C.OnCheckStateChanged_AC71B6B982446756C822F5BC88102136
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015c616c
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnCheckStateChanged_AC71B6B982446756C822F5BC88102136(bool bIsChecked);

	// Object: DelegateFunction UI_MicroPhoneOperation_Item.UI_MicroPhoneOperation_Item_C.OnCheckStateChanged_A2F13CBA52480105FEB8B1BF9C494220
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015c616c
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnCheckStateChanged_A2F13CBA52480105FEB8B1BF9C494220(bool bIsChecked);

	// Object: DelegateFunction UI_MicroPhoneOperation_Item.UI_MicroPhoneOperation_Item_C.OnCheckStateChanged_365D2830BC4BA62B1A40CDBE7C5BCDFD
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015c616c
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnCheckStateChanged_365D2830BC4BA62B1A40CDBE7C5BCDFD(bool bIsChecked);

	// Object: DelegateFunction UI_MicroPhoneOperation_Item.UI_MicroPhoneOperation_Item_C.OnCheckStateChanged_E7B6A3E58F44090A9BC3D6829C3870F7
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015c616c
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnCheckStateChanged_E7B6A3E58F44090A9BC3D6829C3870F7(bool bIsChecked);

	// Object: DelegateFunction UI_MicroPhoneOperation_Item.UI_MicroPhoneOperation_Item_C.OnCheckStateChanged_B67010D7F24DE66AD1497D86C6910FEA
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015c616c
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnCheckStateChanged_B67010D7F24DE66AD1497D86C6910FEA(bool bIsChecked);

	// Object: DelegateFunction UI_MicroPhoneOperation_Item.UI_MicroPhoneOperation_Item_C.OnCheckStateChanged_9959EBA4414359E4B87441A83DA3D59B
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015c616c
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnCheckStateChanged_9959EBA4414359E4B87441A83DA3D59B(bool bIsChecked);

	// Object: DelegateFunction UI_MicroPhoneOperation_Item.UI_MicroPhoneOperation_Item_C.OnCheckStateChanged_25E3B8A24A4D74308D697BA7667DDAD6
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015c616c
	// Return & Params: [ Num(1) Size(0x1) ]
	void OnCheckStateChanged_25E3B8A24A4D74308D697BA7667DDAD6(bool bIsChecked);

	// Object: Function UI_MicroPhoneOperation_Item.UI_MicroPhoneOperation_Item_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x1015dbdd8
	// Return & Params: [ Num(0) Size(0x0) ]
	void Construct();

	// Object: Function UI_MicroPhoneOperation_Item.UI_MicroPhoneOperation_Item_C.Destruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x1015dbdd8
	// Return & Params: [ Num(0) Size(0x0) ]
	void Destruct();

	// Object: Function UI_MicroPhoneOperation_Item.UI_MicroPhoneOperation_Item_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();

	// Object: Function UI_MicroPhoneOperation_Item.UI_MicroPhoneOperation_Item_C.SetOrder
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetOrder(int32_t OrderId);

	// Object: Function UI_MicroPhoneOperation_Item.UI_MicroPhoneOperation_Item_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_MicroPhoneOperation_Item.UI_MicroPhoneOperation_Item_C.ExecuteUbergraph_UI_MicroPhoneOperation_Item
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_MicroPhoneOperation_Item(int32_t EntryPoint);
};

