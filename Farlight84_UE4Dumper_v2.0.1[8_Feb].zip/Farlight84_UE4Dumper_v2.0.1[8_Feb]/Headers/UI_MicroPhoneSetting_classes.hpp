#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_MicroPhoneSetting.UI_MicroPhoneSetting_C
// Inherited Bytes: 0x490 | Struct Size: 0x5bc
struct UUI_MicroPhoneSetting_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x490 | Size: 0x8
	struct UCanvasPanel* IntervalPanel; // Offset: 0x498 | Size: 0x8
	struct USolarButton* Mic_Button; // Offset: 0x4a0 | Size: 0x8
	struct UUI_MicroPhoneOperation_Item_C* Micro1; // Offset: 0x4a8 | Size: 0x8
	struct UUI_MicroPhoneOperation_Item_C* Micro2; // Offset: 0x4b0 | Size: 0x8
	struct UUI_MicroPhoneOperation_Item_C* Micro3; // Offset: 0x4b8 | Size: 0x8
	struct UUI_MicroPhoneOperation_Item_C* Micro4; // Offset: 0x4c0 | Size: 0x8
	struct USolarCheckBox* Microphone_AllOpen; // Offset: 0x4c8 | Size: 0x8
	struct USolarCheckBox* Microphone_MuteAll; // Offset: 0x4d0 | Size: 0x8
	struct USolarCheckBox* Microphone_TeamOpen; // Offset: 0x4d8 | Size: 0x8
	struct UCheckBoxGroup* MicroPhoneType; // Offset: 0x4e0 | Size: 0x8
	struct UWidgetSwitcher* OperatorSwitcher; // Offset: 0x4e8 | Size: 0x8
	struct UVerticalBox* PartnerList; // Offset: 0x4f0 | Size: 0x8
	struct USolarCheckBox* Speaker_AllOpen; // Offset: 0x4f8 | Size: 0x8
	struct USolarButton* Speaker_Button; // Offset: 0x500 | Size: 0x8
	struct USolarCheckBox* Speaker_MuteAll; // Offset: 0x508 | Size: 0x8
	struct USolarCheckBox* Speaker_TeamOpen; // Offset: 0x510 | Size: 0x8
	struct UCheckBoxGroup* SpeakerPanelType; // Offset: 0x518 | Size: 0x8
	struct UImage* TabMicroPhoneImg; // Offset: 0x520 | Size: 0x8
	struct USolarTextBlock* TabMicroPhoneText; // Offset: 0x528 | Size: 0x8
	struct UImage* TabSpeakerImg; // Offset: 0x530 | Size: 0x8
	struct USolarTextBlock* TabSpeakerText; // Offset: 0x538 | Size: 0x8
	struct TMap<int32_t, struct UUI_MicroPhoneOperation_Item_C*> PlayerChatMap; // Offset: 0x540 | Size: 0x50
	struct UObject* ImgClose; // Offset: 0x590 | Size: 0x8
	struct UObject* SpeakImgOn; // Offset: 0x598 | Size: 0x8
	struct UObject* SpeakImgOff; // Offset: 0x5a0 | Size: 0x8
	struct UObject* MicroImgOn; // Offset: 0x5a8 | Size: 0x8
	struct UObject* MicroImgOff; // Offset: 0x5b0 | Size: 0x8
	float Interval; // Offset: 0x5b8 | Size: 0x4

	// Functions

	// Object: DelegateFunction UI_MicroPhoneSetting.UI_MicroPhoneSetting_C.OnClicked_DDA1BB6AA14B34E7121FA2A617AFB32B
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015c616c
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_DDA1BB6AA14B34E7121FA2A617AFB32B();

	// Object: DelegateFunction UI_MicroPhoneSetting.UI_MicroPhoneSetting_C.OnClicked_35859BE6024B667AE993489EB5245CB4
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015c616c
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_35859BE6024B667AE993489EB5245CB4();

	// Object: DelegateFunction UI_MicroPhoneSetting.UI_MicroPhoneSetting_C.OnStateChangedEvent_BAABE249C44BA8BEC709F4A06A0C2B61
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x1015c616c
	// Return & Params: [ Num(2) Size(0x14) ]
	void OnStateChangedEvent_BAABE249C44BA8BEC709F4A06A0C2B61(struct TArray<struct UCheckBox*>& ChildChangedArray, int32_t CheckedChildIndex);

	// Object: DelegateFunction UI_MicroPhoneSetting.UI_MicroPhoneSetting_C.OnStateChangedEvent_A8C9AA36924060E01D495D8E509F7B86
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x1015c616c
	// Return & Params: [ Num(2) Size(0x14) ]
	void OnStateChangedEvent_A8C9AA36924060E01D495D8E509F7B86(struct TArray<struct UCheckBox*>& ChildChangedArray, int32_t CheckedChildIndex);

	// Object: DelegateFunction UI_MicroPhoneSetting.UI_MicroPhoneSetting_C.OnClicked_75EFEFDBCC4BF49489E817A9D6BC37D7
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015c616c
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_75EFEFDBCC4BF49489E817A9D6BC37D7();

	// Object: DelegateFunction UI_MicroPhoneSetting.UI_MicroPhoneSetting_C.OnClicked_E6EF53B5C341A56C08D28A9697032199
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015c616c
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_E6EF53B5C341A56C08D28A9697032199();

	// Object: DelegateFunction UI_MicroPhoneSetting.UI_MicroPhoneSetting_C.OnStateChangedEvent_126B2C15404E5C363CB47686C5C2D989
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x1015c616c
	// Return & Params: [ Num(2) Size(0x14) ]
	void OnStateChangedEvent_126B2C15404E5C363CB47686C5C2D989(struct TArray<struct UCheckBox*>& ChildChangedArray, int32_t CheckedChildIndex);

	// Object: DelegateFunction UI_MicroPhoneSetting.UI_MicroPhoneSetting_C.OnStateChangedEvent_D357C697BF4E2722D913F08491C96FE6
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x1015c616c
	// Return & Params: [ Num(2) Size(0x14) ]
	void OnStateChangedEvent_D357C697BF4E2722D913F08491C96FE6(struct TArray<struct UCheckBox*>& ChildChangedArray, int32_t CheckedChildIndex);

	// Object: DelegateFunction UI_MicroPhoneSetting.UI_MicroPhoneSetting_C.OnClicked_41B73BDE3E4CA57DA881AF96E9ECE3D7
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015c616c
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_41B73BDE3E4CA57DA881AF96E9ECE3D7();

	// Object: DelegateFunction UI_MicroPhoneSetting.UI_MicroPhoneSetting_C.OnClicked_897F2E6A264155FD66C2D4966C679DEB
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015c616c
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_897F2E6A264155FD66C2D4966C679DEB();

	// Object: DelegateFunction UI_MicroPhoneSetting.UI_MicroPhoneSetting_C.OnStateChangedEvent_009F8DEA034DADC6CE8C31B449EBEA90
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x1015c616c
	// Return & Params: [ Num(2) Size(0x14) ]
	void OnStateChangedEvent_009F8DEA034DADC6CE8C31B449EBEA90(struct TArray<struct UCheckBox*>& ChildChangedArray, int32_t CheckedChildIndex);

	// Object: DelegateFunction UI_MicroPhoneSetting.UI_MicroPhoneSetting_C.OnStateChangedEvent_A734707A1B48BB3F258D55ABFA3D689D
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x1015c616c
	// Return & Params: [ Num(2) Size(0x14) ]
	void OnStateChangedEvent_A734707A1B48BB3F258D55ABFA3D689D(struct TArray<struct UCheckBox*>& ChildChangedArray, int32_t CheckedChildIndex);

	// Object: DelegateFunction UI_MicroPhoneSetting.UI_MicroPhoneSetting_C.OnClicked_8C677FF2464FC711073723AF210FEAED
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015c616c
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_8C677FF2464FC711073723AF210FEAED();

	// Object: DelegateFunction UI_MicroPhoneSetting.UI_MicroPhoneSetting_C.OnClicked_D17B615C264919C64F4AADAB862968DE
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015c616c
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_D17B615C264919C64F4AADAB862968DE();

	// Object: DelegateFunction UI_MicroPhoneSetting.UI_MicroPhoneSetting_C.OnStateChangedEvent_CB9F52B132468547AAE3D9AE61765D85
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x1015c616c
	// Return & Params: [ Num(2) Size(0x14) ]
	void OnStateChangedEvent_CB9F52B132468547AAE3D9AE61765D85(struct TArray<struct UCheckBox*>& ChildChangedArray, int32_t CheckedChildIndex);

	// Object: DelegateFunction UI_MicroPhoneSetting.UI_MicroPhoneSetting_C.OnStateChangedEvent_5DB8F3B3E7424592662D14B1594233F6
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x1015c616c
	// Return & Params: [ Num(2) Size(0x14) ]
	void OnStateChangedEvent_5DB8F3B3E7424592662D14B1594233F6(struct TArray<struct UCheckBox*>& ChildChangedArray, int32_t CheckedChildIndex);

	// Object: DelegateFunction UI_MicroPhoneSetting.UI_MicroPhoneSetting_C.OnClicked_33506766EE42CB43364C32B3952EAEAC
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015c616c
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_33506766EE42CB43364C32B3952EAEAC();

	// Object: DelegateFunction UI_MicroPhoneSetting.UI_MicroPhoneSetting_C.OnClicked_054EF28ECC4A3F8CFC425A91F87B4444
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015c616c
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_054EF28ECC4A3F8CFC425A91F87B4444();

	// Object: DelegateFunction UI_MicroPhoneSetting.UI_MicroPhoneSetting_C.OnStateChangedEvent_6BCA9592C24A595E55E47EB94BA8D92D
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x1015c616c
	// Return & Params: [ Num(2) Size(0x14) ]
	void OnStateChangedEvent_6BCA9592C24A595E55E47EB94BA8D92D(struct TArray<struct UCheckBox*>& ChildChangedArray, int32_t CheckedChildIndex);

	// Object: DelegateFunction UI_MicroPhoneSetting.UI_MicroPhoneSetting_C.OnStateChangedEvent_28B1C8A22D4EA3E9D605629D574E2AD8
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x1015c616c
	// Return & Params: [ Num(2) Size(0x14) ]
	void OnStateChangedEvent_28B1C8A22D4EA3E9D605629D574E2AD8(struct TArray<struct UCheckBox*>& ChildChangedArray, int32_t CheckedChildIndex);

	// Object: Function UI_MicroPhoneSetting.UI_MicroPhoneSetting_C.Destruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x1015dbdd8
	// Return & Params: [ Num(0) Size(0x0) ]
	void Destruct();

	// Object: Function UI_MicroPhoneSetting.UI_MicroPhoneSetting_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x1015dbdd8
	// Return & Params: [ Num(0) Size(0x0) ]
	void Construct();

	// Object: Function UI_MicroPhoneSetting.UI_MicroPhoneSetting_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();

	// Object: Function UI_MicroPhoneSetting.UI_MicroPhoneSetting_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_MicroPhoneSetting.UI_MicroPhoneSetting_C.ExecuteUbergraph_UI_MicroPhoneSetting
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_MicroPhoneSetting(int32_t EntryPoint);
};

