#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Notice_Noya.UI_Notice_Noya_C
// Inherited Bytes: 0x490 | Struct Size: 0x628
struct UUI_Notice_Noya_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x490 | Size: 0x8
	struct UWidgetSwitcher* TypeSelect; // Offset: 0x498 | Size: 0x8
	struct UUI_HUD_Notice_CutIn_Crash_C* UI_HUD_Notice_CutIn_Crash; // Offset: 0x4a0 | Size: 0x8
	struct UUI_HUD_Notice_CutIn_Normal_C* UI_HUD_Notice_CutIn_Normal; // Offset: 0x4a8 | Size: 0x8
	struct TMap<enum class E_NoticeType_Noya, struct UUserWidget*> ; // Offset: 0x4b0 | Size: 0x50
	struct TMap<char, bool> ; // Offset: 0x500 | Size: 0x50
	struct TArray<struct FS_NoyaNoticeInfo> NoticeList; // Offset: 0x550 | Size: 0x10
	float ; // Offset: 0x560 | Size: 0x4
	char pad_0x564[0x4]; // Offset: 0x564 | Size: 0x4
	struct FS_NoyaNoticeInfo currentInfo; // Offset: 0x568 | Size: 0x70
	struct TMap<char, bool> TempConditionList; // Offset: 0x5d8 | Size: 0x50

	// Functions

	// Object: Function UI_Notice_Noya.UI_Notice_Noya_C.Init
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void Init();

	// Object: Function UI_Notice_Noya.UI_Notice_Noya_C.
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x70) ]
	void (struct FS_NoyaNoticeInfo );

	// Object: Function UI_Notice_Noya.UI_Notice_Noya_C.
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x71) ]
	void (struct FS_NoyaNoticeInfo& Output, bool& IsNotEmpty);

	// Object: Function UI_Notice_Noya.UI_Notice_Noya_C.
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x71) ]
	void (struct FS_NoyaNoticeInfo& S_NoyaNoticeInfo, bool& );

	// Object: Function UI_Notice_Noya.UI_Notice_Noya_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void Construct();

	// Object: Function UI_Notice_Noya.UI_Notice_Noya_C.
	// Flags: [HasOutParms|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x70) ]
	void (struct FS_NoyaNoticeInfo& );

	// Object: Function UI_Notice_Noya.UI_Notice_Noya_C.
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void ();

	// Object: Function UI_Notice_Noya.UI_Notice_Noya_C.
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void ();

	// Object: Function UI_Notice_Noya.UI_Notice_Noya_C.
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x70) ]
	void (struct FS_NoyaNoticeInfo NoticeInfo);

	// Object: Function UI_Notice_Noya.UI_Notice_Noya_C.
	// Flags: [BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x50) ]
	void (struct TMap<char, bool> );

	// Object: Function UI_Notice_Noya.UI_Notice_Noya_C.ExecuteUbergraph_UI_Notice_Noya
	// Flags: [Final|UbergraphFunction|HasDefaults]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_Notice_Noya(int32_t EntryPoint);
};

