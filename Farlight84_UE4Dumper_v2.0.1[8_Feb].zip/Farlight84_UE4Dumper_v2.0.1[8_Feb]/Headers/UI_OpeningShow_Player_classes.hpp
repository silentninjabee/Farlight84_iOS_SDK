#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_OpeningShow_Player.UI_OpeningShow_Player_C
// Inherited Bytes: 0x518 | Struct Size: 0x570
struct UUI_OpeningShow_Player_C : UUIDefenderPlayerShowWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x518 | Size: 0x8
	struct UImage* Img_InfoBgLight; // Offset: 0x520 | Size: 0x8
	struct UUI_Target_Bussinesscard_Proficiency_C* Proficiency; // Offset: 0x528 | Size: 0x8
	struct UUI_BusinessInfo_C* UI_BusinessInfo; // Offset: 0x530 | Size: 0x8
	struct TArray<struct FLinearColor> Color; // Offset: 0x538 | Size: 0x10
	struct TArray<struct UObject*> TeamPosImg; // Offset: 0x548 | Size: 0x10
	struct FLinearColor TargetColor; // Offset: 0x558 | Size: 0x10
	struct UObject* TargetImg; // Offset: 0x568 | Size: 0x8

	// Functions

	// Object: Function UI_OpeningShow_Player.UI_OpeningShow_Player_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();

	// Object: Function UI_OpeningShow_Player.UI_OpeningShow_Player_C.SetBGLight
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void SetBGLight();

	// Object: Function UI_OpeningShow_Player.UI_OpeningShow_Player_C.SetTeamPos
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetTeamPos(int32_t TeamPos);

	// Object: Function UI_OpeningShow_Player.UI_OpeningShow_Player_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void Construct();

	// Object: Function UI_OpeningShow_Player.UI_OpeningShow_Player_C.ExecuteUbergraph_UI_OpeningShow_Player
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_OpeningShow_Player(int32_t EntryPoint);
};

