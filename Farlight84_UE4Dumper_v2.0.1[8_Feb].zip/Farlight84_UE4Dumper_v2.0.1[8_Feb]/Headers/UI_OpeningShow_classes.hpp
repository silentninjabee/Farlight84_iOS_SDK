#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_OpeningShow.UI_OpeningShow_C
// Inherited Bytes: 0x5f8 | Struct Size: 0x640
struct UUI_OpeningShow_C : UUIDefenderTeamShowWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x5f8 | Size: 0x8
	struct UImage* Img_Title_Bg; // Offset: 0x600 | Size: 0x8
	struct UImage* Img_Title_Bg_2; // Offset: 0x608 | Size: 0x8
	struct UOverlay* Overlay_Tip; // Offset: 0x610 | Size: 0x8
	struct UHorizontalBox* Panel_DefenderTeam; // Offset: 0x618 | Size: 0x8
	struct UHorizontalBox* Panel_MyTeam; // Offset: 0x620 | Size: 0x8
	struct URichTextBlock* Txt_Tips; // Offset: 0x628 | Size: 0x8
	struct USolarTextBlock* Txt_Title; // Offset: 0x630 | Size: 0x8
	enum class EDefenderTeamType BP_TeamType; // Offset: 0x638 | Size: 0x1
	char pad_0x639[0x3]; // Offset: 0x639 | Size: 0x3
	int32_t TerminatorReward; // Offset: 0x63c | Size: 0x4

	// Functions

	// Object: Function UI_OpeningShow.UI_OpeningShow_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();

	// Object: Function UI_OpeningShow.UI_OpeningShow_C.SequenceEvent__ENTRYPOINTUI_OpeningShow_3
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void SequenceEvent__ENTRYPOINTUI_OpeningShow_3();

	// Object: Function UI_OpeningShow.UI_OpeningShow_C.SequenceEvent__ENTRYPOINTUI_OpeningShow_2
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void SequenceEvent__ENTRYPOINTUI_OpeningShow_2();

	// Object: Function UI_OpeningShow.UI_OpeningShow_C.SequenceEvent__ENTRYPOINTUI_OpeningShow_1
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void SequenceEvent__ENTRYPOINTUI_OpeningShow_1();

	// Object: Function UI_OpeningShow.UI_OpeningShow_C.StartShowDefenderBannerVoice
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void StartShowDefenderBannerVoice();

	// Object: Function UI_OpeningShow.UI_OpeningShow_C.StartShowMyTeamBannerVoice
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void StartShowMyTeamBannerVoice();

	// Object: Function UI_OpeningShow.UI_OpeningShow_C.HiddenBattleUIInLua
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void HiddenBattleUIInLua();

	// Object: Function UI_OpeningShow.UI_OpeningShow_C.UpdateTeamState
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void UpdateTeamState();

	// Object: Function UI_OpeningShow.UI_OpeningShow_C.UpdateOpeningShow
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void UpdateOpeningShow(enum class EDefenderTeamType TeamType);

	// Object: Function UI_OpeningShow.UI_OpeningShow_C.OnSolarUIOpened
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnSolarUIOpened();

	// Object: Function UI_OpeningShow.UI_OpeningShow_C.OnSolarUIClosed
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnSolarUIClosed();

	// Object: Function UI_OpeningShow.UI_OpeningShow_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_OpeningShow.UI_OpeningShow_C.UpdateMyTeamNum
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void UpdateMyTeamNum(int32_t Num);

	// Object: Function UI_OpeningShow.UI_OpeningShow_C.ExecuteUbergraph_UI_OpeningShow
	// Flags: [Final|UbergraphFunction|HasDefaults]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_OpeningShow(int32_t EntryPoint);
};

