#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_PassiveHead_item.UI_PassiveHead_item_C
// Inherited Bytes: 0x4a8 | Struct Size: 0x4b0
struct UUI_PassiveHead_item_C : UHUDPassiveHeadWidget {
	// Fields
	struct UCanvasPanel* Panel_PassiveBuff; // Offset: 0x4a8 | Size: 0x8
};

