#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Shop_Tips_Video.UI_Shop_Tips_Video_C
// Inherited Bytes: 0x490 | Struct Size: 0x4c8
struct UUI_Shop_Tips_Video_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x490 | Size: 0x8
	struct USolarButton* Btn_Play; // Offset: 0x498 | Size: 0x8
	struct UImage* Img_Video; // Offset: 0x4a0 | Size: 0x8
	struct USolarTextBlock* Txt_Special_effect; // Offset: 0x4a8 | Size: 0x8
	bool Is Special_Effect; // Offset: 0x4b0 | Size: 0x1
	char pad_0x4B1[0x7]; // Offset: 0x4b1 | Size: 0x7
	struct FMulticastInlineDelegate OnBtnPlayVideoClicked; // Offset: 0x4b8 | Size: 0x10

	// Functions

	// Object: Function UI_Shop_Tips_Video.UI_Shop_Tips_Video_C.SetSpecialEffect
	// Flags: [Public|HasDefaults|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetSpecialEffect(bool Is Special_Effect);

	// Object: Function UI_Shop_Tips_Video.UI_Shop_Tips_Video_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_Shop_Tips_Video.UI_Shop_Tips_Video_C.BndEvt__Btn_Play_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature
	// Flags: [BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void BndEvt__Btn_Play_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature();

	// Object: Function UI_Shop_Tips_Video.UI_Shop_Tips_Video_C.ExecuteUbergraph_UI_Shop_Tips_Video
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_Shop_Tips_Video(int32_t EntryPoint);

	// Object: Function UI_Shop_Tips_Video.UI_Shop_Tips_Video_C.OnBtnPlayVideoClicked__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnBtnPlayVideoClicked__DelegateSignature();
};

