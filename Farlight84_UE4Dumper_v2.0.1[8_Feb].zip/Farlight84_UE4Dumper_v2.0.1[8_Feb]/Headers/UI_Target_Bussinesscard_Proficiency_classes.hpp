#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Target_Bussinesscard_Proficiency.UI_Target_Bussinesscard_Proficiency_C
// Inherited Bytes: 0x490 | Struct Size: 0x4b0
struct UUI_Target_Bussinesscard_Proficiency_C : USolarUserWidget {
	// Fields
	struct UUI_Component_Proficiency_C* Proficiency; // Offset: 0x490 | Size: 0x8
	struct UUI_Component_Ranking_C* Ranking; // Offset: 0x498 | Size: 0x8
	struct USolarTextBlock* Txt_Proficiency; // Offset: 0x4a0 | Size: 0x8
	struct UWidgetSwitcher* WidgetSwitcher_Panel; // Offset: 0x4a8 | Size: 0x8
};

