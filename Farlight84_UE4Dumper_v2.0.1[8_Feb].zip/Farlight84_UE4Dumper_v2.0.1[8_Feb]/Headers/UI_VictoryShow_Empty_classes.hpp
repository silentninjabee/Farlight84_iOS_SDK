#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_VictoryShow_Empty.UI_VictoryShow_Empty_C
// Inherited Bytes: 0x490 | Struct Size: 0x490
struct UUI_VictoryShow_Empty_C : USolarUserWidget {
};

