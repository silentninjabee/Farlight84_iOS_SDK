#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Vip_Cards.UI_Vip_Cards_C
// Inherited Bytes: 0x490 | Struct Size: 0x500
struct UUI_Vip_Cards_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x490 | Size: 0x8
	struct UWidgetAnimation* Anim_Loop; // Offset: 0x498 | Size: 0x8
	struct UButton* Btn_Card; // Offset: 0x4a0 | Size: 0x8
	struct UImage* Img_Card; // Offset: 0x4a8 | Size: 0x8
	struct UImage* Img_Star; // Offset: 0x4b0 | Size: 0x8
	struct UImage* MI_Glow; // Offset: 0x4b8 | Size: 0x8
	struct UImage* MI_Glow_2; // Offset: 0x4c0 | Size: 0x8
	struct UImage* MI_Wipes; // Offset: 0x4c8 | Size: 0x8
	struct USizeBox* Size_Item; // Offset: 0x4d0 | Size: 0x8
	int32_t Type_Card; // Offset: 0x4d8 | Size: 0x4
	int32_t Size_W; // Offset: 0x4dc | Size: 0x4
	int32_t Size_H; // Offset: 0x4e0 | Size: 0x4
	char pad_0x4E4[0x4]; // Offset: 0x4e4 | Size: 0x4
	struct FSoftObjectPath OnClickedSound; // Offset: 0x4e8 | Size: 0x18

	// Functions

	// Object: DelegateFunction UI_Vip_Cards.UI_Vip_Cards_C.OnClicked_3DB441725940A2B9A257DD8F4B5A796B
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015c616c
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_3DB441725940A2B9A257DD8F4B5A796B();

	// Object: DelegateFunction UI_Vip_Cards.UI_Vip_Cards_C.OnClicked_BB92490CB84E3AF0F38535911397E587
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x1015c616c
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnClicked_BB92490CB84E3AF0F38535911397E587();

	// Object: Function UI_Vip_Cards.UI_Vip_Cards_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetModuleName();

	// Object: Function UI_Vip_Cards.UI_Vip_Cards_C.SetCardType
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetCardType(int32_t CardType);

	// Object: Function UI_Vip_Cards.UI_Vip_Cards_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_Vip_Cards.UI_Vip_Cards_C.ExecuteUbergraph_UI_Vip_Cards
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_Vip_Cards(int32_t EntryPoint);
};

