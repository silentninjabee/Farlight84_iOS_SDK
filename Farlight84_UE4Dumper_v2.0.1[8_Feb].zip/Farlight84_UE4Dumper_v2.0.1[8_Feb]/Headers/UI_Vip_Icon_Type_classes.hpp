#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_Vip_Icon_Type.UI_Vip_Icon_Type_C
// Inherited Bytes: 0x490 | Struct Size: 0x4b4
struct UUI_Vip_Icon_Type_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x490 | Size: 0x8
	struct USolarImage* Img_Vip_Icon; // Offset: 0x498 | Size: 0x8
	struct USizeBox* SizeBox_2; // Offset: 0x4a0 | Size: 0x8
	int32_t Type; // Offset: 0x4a8 | Size: 0x4
	float SizeX; // Offset: 0x4ac | Size: 0x4
	float SizeY; // Offset: 0x4b0 | Size: 0x4

	// Functions

	// Object: Function UI_Vip_Icon_Type.UI_Vip_Icon_Type_C.SetType
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetType(int32_t Type);

	// Object: Function UI_Vip_Icon_Type.UI_Vip_Icon_Type_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_Vip_Icon_Type.UI_Vip_Icon_Type_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void Construct();

	// Object: Function UI_Vip_Icon_Type.UI_Vip_Icon_Type_C.ExecuteUbergraph_UI_Vip_Icon_Type
	// Flags: [Final|UbergraphFunction]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_Vip_Icon_Type(int32_t EntryPoint);
};

