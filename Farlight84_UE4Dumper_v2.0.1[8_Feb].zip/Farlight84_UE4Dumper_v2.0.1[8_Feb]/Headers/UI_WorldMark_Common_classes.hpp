#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: WidgetBlueprintGeneratedClass UI_WorldMark_Common.UI_WorldMark_Common_C
// Inherited Bytes: 0x510 | Struct Size: 0x534
struct UUI_WorldMark_Common_C : UActorMarkBase {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x510 | Size: 0x8
	struct UTextBlock* Distance; // Offset: 0x518 | Size: 0x8
	struct UVerticalBox* Panel; // Offset: 0x520 | Size: 0x8
	struct UScaleBox* ScaleBox_1; // Offset: 0x528 | Size: 0x8
	int32_t HideDistance; // Offset: 0x530 | Size: 0x4

	// Functions

	// Object: Function UI_WorldMark_Common.UI_WorldMark_Common_C.GetVisibility_1
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class ESlateVisibility GetVisibility_1();

	// Object: Function UI_WorldMark_Common.UI_WorldMark_Common_C.Get_Distance_Text_1
	// Flags: [Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x18) ]
	struct FText Get_Distance_Text_1();

	// Object: Function UI_WorldMark_Common.UI_WorldMark_Common_C.SetIcon
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0xc) ]
	void SetIcon(struct UWidget* Content, int32_t );

	// Object: Function UI_WorldMark_Common.UI_WorldMark_Common_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UI_WorldMark_Common.UI_WorldMark_Common_C.Tick
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x3c) ]
	void Tick(struct FGeometry MyGeometry, float InDeltaTime);

	// Object: Function UI_WorldMark_Common.UI_WorldMark_Common_C.ExecuteUbergraph_UI_WorldMark_Common
	// Flags: [Final|UbergraphFunction|HasDefaults]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void ExecuteUbergraph_UI_WorldMark_Common(int32_t EntryPoint);
};

