#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object: Class UMG.Visual
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UVisual : UObject {
};

// Object: Class UMG.Widget
// Inherited Bytes: 0x28 | Struct Size: 0x138
struct UWidget : UVisual {
	// Fields
	struct UPanelSlot* Slot; // Offset: 0x28 | Size: 0x8
	struct FDelegate bIsEnabledDelegate; // Offset: 0x30 | Size: 0x10
	struct FText ToolTipText; // Offset: 0x40 | Size: 0x18
	struct FDelegate ToolTipTextDelegate; // Offset: 0x58 | Size: 0x10
	struct UWidget* ToolTipWidget; // Offset: 0x68 | Size: 0x8
	struct FDelegate ToolTipWidgetDelegate; // Offset: 0x70 | Size: 0x10
	struct FDelegate VisibilityDelegate; // Offset: 0x80 | Size: 0x10
	struct FWidgetTransform RenderTransform; // Offset: 0x90 | Size: 0x1c
	struct FVector2D RenderTransformPivot; // Offset: 0xac | Size: 0x8
	char bIsVariable : 1; // Offset: 0xb4 | Size: 0x1
	char bCreatedByConstructionScript : 1; // Offset: 0xb4 | Size: 0x1
	char bIsEnabled : 1; // Offset: 0xb4 | Size: 0x1
	char bOverride_Cursor : 1; // Offset: 0xb4 | Size: 0x1
	char pad_0xB4_4 : 4; // Offset: 0xb4 | Size: 0x1
	char pad_0xB5[0x3]; // Offset: 0xb5 | Size: 0x3
	struct USlateAccessibleWidgetData* AccessibleWidgetData; // Offset: 0xb8 | Size: 0x8
	char bIsVolatile : 1; // Offset: 0xc0 | Size: 0x1
	char pad_0xC0_1 : 7; // Offset: 0xc0 | Size: 0x1
	enum class EMouseCursor Cursor; // Offset: 0xc1 | Size: 0x1
	enum class EWidgetClipping Clipping; // Offset: 0xc2 | Size: 0x1
	enum class ESlateVisibility Visibility; // Offset: 0xc3 | Size: 0x1
	float RenderOpacity; // Offset: 0xc4 | Size: 0x4
	enum class ESlateDetailMode DetailMode; // Offset: 0xc8 | Size: 0x1
	bool bSelectedDetailModeOnly; // Offset: 0xc9 | Size: 0x1
	char pad_0xCA[0x2]; // Offset: 0xca | Size: 0x2
	int32_t WidthDivisor; // Offset: 0xcc | Size: 0x4
	int32_t HeightDivisor; // Offset: 0xd0 | Size: 0x4
	char pad_0xD4[0x4]; // Offset: 0xd4 | Size: 0x4
	struct UWidgetNavigation* Navigation; // Offset: 0xd8 | Size: 0x8
	enum class EFlowDirectionPreference FlowDirectionPreference; // Offset: 0xe0 | Size: 0x1
	char pad_0xE1[0x47]; // Offset: 0xe1 | Size: 0x47
	struct TArray<struct UPropertyBinding*> NativeBindings; // Offset: 0x128 | Size: 0x10

	// Functions

	// Object: Function UMG.Widget.SetWidthHeightDivisors
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cd41bc
	// Return & Params: [ Num(2) Size(0x8) ]
	void SetWidthHeightDivisors(int32_t InWidthDivisor, int32_t InHeightDivisor);

	// Object: Function UMG.Widget.SetVisibility
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104cd4440
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetVisibility(enum class ESlateVisibility InVisibility);

	// Object: Function UMG.Widget.SetUserFocus
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cd3cd4
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetUserFocus(struct APlayerController* PlayerController);

	// Object: Function UMG.Widget.SetToolTipText
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104cd4644
	// Return & Params: [ Num(1) Size(0x18) ]
	void SetToolTipText(struct FText& InToolTipText);

	// Object: Function UMG.Widget.SetToolTip
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cd45c4
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetToolTip(struct UWidget* Widget);

	// Object: Function UMG.Widget.SetSelectedDetailModeOnly
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cd4284
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetSelectedDetailModeOnly(bool InSelectedDetailModeOnly);

	// Object: Function UMG.Widget.SetRenderTranslation
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x104cd486c
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetRenderTranslation(struct FVector2D Translation);

	// Object: Function UMG.Widget.SetRenderTransformPivot
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x104cd47f0
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetRenderTransformPivot(struct FVector2D Pivot);

	// Object: Function UMG.Widget.SetRenderTransformAngle
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cd491c
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetRenderTransformAngle(float Angle);

	// Object: Function UMG.Widget.SetRenderTransform
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cd4a94
	// Return & Params: [ Num(1) Size(0x1c) ]
	void SetRenderTransform(struct FWidgetTransform InTransform);

	// Object: Function UMG.Widget.SetRenderShear
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x104cd499c
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetRenderShear(struct FVector2D Shear);

	// Object: Function UMG.Widget.SetRenderScale
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x104cd4a18
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetRenderScale(struct FVector2D Scale);

	// Object: Function UMG.Widget.SetRenderOpacity
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cd438c
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetRenderOpacity(float InOpacity);

	// Object: Function UMG.Widget.SetNavigationRuleExplicit
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cd38f8
	// Return & Params: [ Num(2) Size(0x10) ]
	void SetNavigationRuleExplicit(enum class EUINavigation Direction, struct UWidget* InWidget);

	// Object: Function UMG.Widget.SetNavigationRuleCustomBoundary
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cd3700
	// Return & Params: [ Num(2) Size(0x14) ]
	void SetNavigationRuleCustomBoundary(enum class EUINavigation Direction, struct FDelegate InCustomDelegate);

	// Object: Function UMG.Widget.SetNavigationRuleCustom
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cd37fc
	// Return & Params: [ Num(2) Size(0x14) ]
	void SetNavigationRuleCustom(enum class EUINavigation Direction, struct FDelegate InCustomDelegate);

	// Object: Function UMG.Widget.SetNavigationRuleBase
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cd39c4
	// Return & Params: [ Num(2) Size(0x2) ]
	void SetNavigationRuleBase(enum class EUINavigation Direction, enum class EUINavigationRule Rule);

	// Object: Function UMG.Widget.SetNavigationRule
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cd3a90
	// Return & Params: [ Num(3) Size(0xc) ]
	void SetNavigationRule(enum class EUINavigation Direction, enum class EUINavigationRule Rule, struct FName WidgetToFocus);

	// Object: Function UMG.Widget.SetKeyboardFocus
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cd3ef0
	// Return & Params: [ Num(0) Size(0x0) ]
	void SetKeyboardFocus();

	// Object: Function UMG.Widget.SetIsEnabled
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104cd472c
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetIsEnabled(bool bInIsEnabled);

	// Object: Function UMG.Widget.SetFocus
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cd3d54
	// Return & Params: [ Num(0) Size(0x0) ]
	void SetFocus();

	// Object: Function UMG.Widget.SetDetailMode
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cd430c
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetDetailMode(enum class ESlateDetailMode InDetailMode);

	// Object: Function UMG.Widget.SetCursor
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cd4544
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetCursor(enum class EMouseCursor InCursor);

	// Object: Function UMG.Widget.SetClipping
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cd4108
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetClipping(enum class EWidgetClipping InClipping);

	// Object: Function UMG.Widget.SetAllNavigationRules
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cd3ba8
	// Return & Params: [ Num(2) Size(0xc) ]
	void SetAllNavigationRules(enum class EUINavigationRule Rule, struct FName WidgetToFocus);

	// Object: Function UMG.Widget.ResetCursor
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cd4530
	// Return & Params: [ Num(0) Size(0x0) ]
	void ResetCursor();

	// Object: Function UMG.Widget.RemoveFromParent
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104cd36b0
	// Return & Params: [ Num(0) Size(0x0) ]
	void RemoveFromParent();

	// Object: DelegateFunction UMG.Widget.OnReply__DelegateSignature
	// Flags: [Public|Delegate]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0xb8) ]
	struct FEventReply OnReply__DelegateSignature();

	// Object: DelegateFunction UMG.Widget.OnPointerEvent__DelegateSignature
	// Flags: [Public|Delegate|HasOutParms]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0x160) ]
	struct FEventReply OnPointerEvent__DelegateSignature(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent);

	// Object: Function UMG.Widget.IsVisible
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cd44fc
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsVisible();

	// Object: Function UMG.Widget.IsHovered
	// Flags: [Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cd4044
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsHovered();

	// Object: Function UMG.Widget.InvalidateLayoutAndVolatility
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cd3cac
	// Return & Params: [ Num(0) Size(0x0) ]
	void InvalidateLayoutAndVolatility();

	// Object: Function UMG.Widget.HasUserFocusedDescendants
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cd3d68
	// Return & Params: [ Num(2) Size(0x9) ]
	bool HasUserFocusedDescendants(struct APlayerController* PlayerController);

	// Object: Function UMG.Widget.HasUserFocus
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cd3e60
	// Return & Params: [ Num(2) Size(0x9) ]
	bool HasUserFocus(struct APlayerController* PlayerController);

	// Object: Function UMG.Widget.HasMouseCaptureByUser
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cd3f04
	// Return & Params: [ Num(3) Size(0x9) ]
	bool HasMouseCaptureByUser(int32_t UserIndex, int32_t PointerIndex);

	// Object: Function UMG.Widget.HasMouseCapture
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cd3fdc
	// Return & Params: [ Num(1) Size(0x1) ]
	bool HasMouseCapture();

	// Object: Function UMG.Widget.HasKeyboardFocus
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cd4010
	// Return & Params: [ Num(1) Size(0x1) ]
	bool HasKeyboardFocus();

	// Object: Function UMG.Widget.HasFocusedDescendants
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cd3df8
	// Return & Params: [ Num(1) Size(0x1) ]
	bool HasFocusedDescendants();

	// Object: Function UMG.Widget.HasAnyUserFocus
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cd3e2c
	// Return & Params: [ Num(1) Size(0x1) ]
	bool HasAnyUserFocus();

	// Object: DelegateFunction UMG.Widget.GetWidget__DelegateSignature
	// Flags: [Public|Delegate]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UWidget* GetWidget__DelegateSignature();

	// Object: Function UMG.Widget.GetVisibility
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cd44c8
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class ESlateVisibility GetVisibility();

	// Object: Function UMG.Widget.GetTickSpaceGeometry
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cd3640
	// Return & Params: [ Num(1) Size(0x38) ]
	struct FGeometry GetTickSpaceGeometry();

	// Object: DelegateFunction UMG.Widget.GetText__DelegateSignature
	// Flags: [Public|Delegate]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x18) ]
	struct FText GetText__DelegateSignature();

	// Object: DelegateFunction UMG.Widget.GetSlateVisibility__DelegateSignature
	// Flags: [Public|Delegate]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class ESlateVisibility GetSlateVisibility__DelegateSignature();

	// Object: DelegateFunction UMG.Widget.GetSlateColor__DelegateSignature
	// Flags: [Public|Delegate]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x28) ]
	struct FSlateColor GetSlateColor__DelegateSignature();

	// Object: DelegateFunction UMG.Widget.GetSlateBrush__DelegateSignature
	// Flags: [Public|Delegate]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0xe0) ]
	struct FSlateBrush GetSlateBrush__DelegateSignature();

	// Object: Function UMG.Widget.GetRenderTransformAngle
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cd48e8
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetRenderTransformAngle();

	// Object: Function UMG.Widget.GetRenderOpacity
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cd440c
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetRenderOpacity();

	// Object: Function UMG.Widget.GetParent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cd36cc
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UPanelWidget* GetParent();

	// Object: Function UMG.Widget.GetPaintSpaceGeometry
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cd3608
	// Return & Params: [ Num(1) Size(0x38) ]
	struct FGeometry GetPaintSpaceGeometry();

	// Object: Function UMG.Widget.GetOwningPlayer
	// Flags: [BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cd3598
	// Return & Params: [ Num(1) Size(0x8) ]
	struct APlayerController* GetOwningPlayer();

	// Object: Function UMG.Widget.GetOwningLocalPlayer
	// Flags: [BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cd355c
	// Return & Params: [ Num(1) Size(0x8) ]
	struct ULocalPlayer* GetOwningLocalPlayer();

	// Object: DelegateFunction UMG.Widget.GetMouseCursor__DelegateSignature
	// Flags: [Public|Delegate]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class EMouseCursor GetMouseCursor__DelegateSignature();

	// Object: DelegateFunction UMG.Widget.GetLinearColor__DelegateSignature
	// Flags: [Public|Delegate|HasDefaults]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FLinearColor GetLinearColor__DelegateSignature();

	// Object: Function UMG.Widget.GetIsEnabled
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cd47bc
	// Return & Params: [ Num(1) Size(0x1) ]
	bool GetIsEnabled();

	// Object: DelegateFunction UMG.Widget.GetInt32__DelegateSignature
	// Flags: [Public|Delegate]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetInt32__DelegateSignature();

	// Object: Function UMG.Widget.GetGameInstance
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cd35d4
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UGameInstance* GetGameInstance();

	// Object: DelegateFunction UMG.Widget.GetFloat__DelegateSignature
	// Flags: [Public|Delegate]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetFloat__DelegateSignature();

	// Object: Function UMG.Widget.GetDesiredSize
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cd3c74
	// Return & Params: [ Num(1) Size(0x8) ]
	struct FVector2D GetDesiredSize();

	// Object: Function UMG.Widget.GetClipping
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cd4188
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class EWidgetClipping GetClipping();

	// Object: DelegateFunction UMG.Widget.GetCheckBoxState__DelegateSignature
	// Flags: [Public|Delegate]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class ECheckBoxState GetCheckBoxState__DelegateSignature();

	// Object: Function UMG.Widget.GetCachedGeometry
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cd3678
	// Return & Params: [ Num(1) Size(0x38) ]
	struct FGeometry GetCachedGeometry();

	// Object: DelegateFunction UMG.Widget.GetBool__DelegateSignature
	// Flags: [Public|Delegate]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	bool GetBool__DelegateSignature();

	// Object: DelegateFunction UMG.Widget.GenerateWidgetForString__DelegateSignature
	// Flags: [Public|Delegate]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x18) ]
	struct UWidget* GenerateWidgetForString__DelegateSignature(struct FString Item);

	// Object: DelegateFunction UMG.Widget.GenerateWidgetForObject__DelegateSignature
	// Flags: [Public|Delegate]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UWidget* GenerateWidgetForObject__DelegateSignature(struct UObject* Item);

	// Object: Function UMG.Widget.ForceVolatile
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cd4080
	// Return & Params: [ Num(1) Size(0x1) ]
	void ForceVolatile(bool bForce);

	// Object: Function UMG.Widget.ForceLayoutPrepass
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cd3cc0
	// Return & Params: [ Num(0) Size(0x0) ]
	void ForceLayoutPrepass();
};

// Object: Class UMG.UserWidget
// Inherited Bytes: 0x138 | Struct Size: 0x260
struct UUserWidget : UWidget {
	// Fields
	char pad_0x138[0x8]; // Offset: 0x138 | Size: 0x8
	struct FLinearColor ColorAndOpacity; // Offset: 0x140 | Size: 0x10
	struct FDelegate ColorAndOpacityDelegate; // Offset: 0x150 | Size: 0x10
	struct FSlateColor ForegroundColor; // Offset: 0x160 | Size: 0x28
	struct FDelegate ForegroundColorDelegate; // Offset: 0x188 | Size: 0x10
	struct FMargin Padding; // Offset: 0x198 | Size: 0x10
	struct TArray<struct UUMGSequencePlayer*> ActiveSequencePlayers; // Offset: 0x1a8 | Size: 0x10
	struct TArray<struct UUMGSequencePlayer*> StoppedSequencePlayers; // Offset: 0x1b8 | Size: 0x10
	struct TArray<struct FNamedSlotBinding> NamedSlotBindings; // Offset: 0x1c8 | Size: 0x10
	struct UWidgetTree* WidgetTree; // Offset: 0x1d8 | Size: 0x8
	int32_t Priority; // Offset: 0x1e0 | Size: 0x4
	char bSupportsKeyboardFocus : 1; // Offset: 0x1e4 | Size: 0x1
	char bIsFocusable : 1; // Offset: 0x1e4 | Size: 0x1
	char bStopAction : 1; // Offset: 0x1e4 | Size: 0x1
	char bHasScriptImplementedTick : 1; // Offset: 0x1e4 | Size: 0x1
	char bHasScriptImplementedPaint : 1; // Offset: 0x1e4 | Size: 0x1
	char pad_0x1E4_5 : 3; // Offset: 0x1e4 | Size: 0x1
	char pad_0x1E5[0xb]; // Offset: 0x1e5 | Size: 0xb
	enum class EWidgetTickFrequency TickFrequency; // Offset: 0x1f0 | Size: 0x1
	char pad_0x1F1[0x7]; // Offset: 0x1f1 | Size: 0x7
	struct UInputComponent* InputComponent; // Offset: 0x1f8 | Size: 0x8
	struct TArray<struct FAnimationEventBinding> AnimationCallbacks; // Offset: 0x200 | Size: 0x10
	char pad_0x210[0x50]; // Offset: 0x210 | Size: 0x50

	// Functions

	// Object: Function UMG.UserWidget.UnregisterInputComponent
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x104cc7aec
	// Return & Params: [ Num(0) Size(0x0) ]
	void UnregisterInputComponent();

	// Object: Function UMG.UserWidget.UnbindFromAnimationStarted
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cc92c4
	// Return & Params: [ Num(2) Size(0x18) ]
	void UnbindFromAnimationStarted(struct UWidgetAnimation* Animation, struct FDelegate Delegate);

	// Object: Function UMG.UserWidget.UnbindFromAnimationFinished
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cc904c
	// Return & Params: [ Num(2) Size(0x18) ]
	void UnbindFromAnimationFinished(struct UWidgetAnimation* Animation, struct FDelegate Delegate);

	// Object: Function UMG.UserWidget.UnbindAllFromAnimationStarted
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cc9244
	// Return & Params: [ Num(1) Size(0x8) ]
	void UnbindAllFromAnimationStarted(struct UWidgetAnimation* Animation);

	// Object: Function UMG.UserWidget.UnbindAllFromAnimationFinished
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cc8fcc
	// Return & Params: [ Num(1) Size(0x8) ]
	void UnbindAllFromAnimationFinished(struct UWidgetAnimation* Animation);

	// Object: Function UMG.UserWidget.Tick
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x3c) ]
	void Tick(struct FGeometry MyGeometry, float InDeltaTime);

	// Object: Function UMG.UserWidget.StopListeningForInputAction
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x104cc7b28
	// Return & Params: [ Num(2) Size(0x9) ]
	void StopListeningForInputAction(struct FName ActionName, enum class EInputEvent EventType);

	// Object: Function UMG.UserWidget.StopListeningForAllInputActions
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x104cc7b14
	// Return & Params: [ Num(0) Size(0x0) ]
	void StopListeningForAllInputActions();

	// Object: Function UMG.UserWidget.StopAnimationsAndLatentActions
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cc94bc
	// Return & Params: [ Num(0) Size(0x0) ]
	void StopAnimationsAndLatentActions();

	// Object: Function UMG.UserWidget.StopAnimation
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cc82dc
	// Return & Params: [ Num(1) Size(0x8) ]
	void StopAnimation(struct UWidgetAnimation* InAnimation);

	// Object: Function UMG.UserWidget.StopAllAnimations
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cc82c8
	// Return & Params: [ Num(0) Size(0x0) ]
	void StopAllAnimations();

	// Object: Function UMG.UserWidget.SetPositionInViewport
	// Flags: [Final|BlueprintCosmetic|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x104cc97f4
	// Return & Params: [ Num(2) Size(0x9) ]
	void SetPositionInViewport(struct FVector2D Position, bool bRemoveDPIScale);

	// Object: Function UMG.UserWidget.SetPlaybackSpeed
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x104cc7f4c
	// Return & Params: [ Num(2) Size(0xc) ]
	void SetPlaybackSpeed(struct UWidgetAnimation* InAnimation, float PlaybackSpeed);

	// Object: Function UMG.UserWidget.SetPadding
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x104cc8a2c
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetPadding(struct FMargin InPadding);

	// Object: Function UMG.UserWidget.SetOwningPlayer
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x104cc9518
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetOwningPlayer(struct APlayerController* LocalPlayerController);

	// Object: Function UMG.UserWidget.SetNumLoopsToPlay
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x104cc8018
	// Return & Params: [ Num(2) Size(0xc) ]
	void SetNumLoopsToPlay(struct UWidgetAnimation* InAnimation, int32_t NumLoopsToPlay);

	// Object: Function UMG.UserWidget.SetInputActionPriority
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x104cc79dc
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetInputActionPriority(int32_t NewPriority);

	// Object: Function UMG.UserWidget.SetInputActionBlocking
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x104cc7954
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetInputActionBlocking(bool bShouldBlock);

	// Object: Function UMG.UserWidget.SetForegroundColor
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x104cc8ab0
	// Return & Params: [ Num(1) Size(0x28) ]
	void SetForegroundColor(struct FSlateColor InForegroundColor);

	// Object: Function UMG.UserWidget.SetDesiredSizeInViewport
	// Flags: [Final|BlueprintCosmetic|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x104cc9778
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetDesiredSizeInViewport(struct FVector2D Size);

	// Object: Function UMG.UserWidget.SetColorAndOpacity
	// Flags: [Final|BlueprintCosmetic|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x104cc8c20
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetColorAndOpacity(struct FLinearColor InColorAndOpacity);

	// Object: Function UMG.UserWidget.SetAnchorsInViewport
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x104cc96f4
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetAnchorsInViewport(struct FAnchors Anchors);

	// Object: Function UMG.UserWidget.SetAlignmentInViewport
	// Flags: [Final|BlueprintCosmetic|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x104cc9678
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetAlignmentInViewport(struct FVector2D Alignment);

	// Object: Function UMG.UserWidget.ReverseAnimation
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x104cc7ecc
	// Return & Params: [ Num(1) Size(0x8) ]
	void ReverseAnimation(struct UWidgetAnimation* InAnimation);

	// Object: Function UMG.UserWidget.RemoveFromViewport
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x104cc98c4
	// Return & Params: [ Num(0) Size(0x0) ]
	void RemoveFromViewport();

	// Object: Function UMG.UserWidget.RegisterInputComponent
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x104cc7b00
	// Return & Params: [ Num(0) Size(0x0) ]
	void RegisterInputComponent();

	// Object: Function UMG.UserWidget.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void PreConstruct(bool IsDesignTime);

	// Object: Function UMG.UserWidget.PlaySound
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x104cc7dbc
	// Return & Params: [ Num(1) Size(0x8) ]
	void PlaySound(struct USoundBase* SoundToPlay);

	// Object: Function UMG.UserWidget.PlayEnterAnim
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void PlayEnterAnim();

	// Object: Function UMG.UserWidget.PlayAnimationTimeRange
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x104cc85bc
	// Return & Params: [ Num(8) Size(0x28) ]
	struct UUMGSequencePlayer* PlayAnimationTimeRange(struct UWidgetAnimation* InAnimation, float StartAtTime, float EndAtTime, int32_t NumLoopsToPlay, enum class EUMGSequencePlayMode PlayMode, float PlaybackSpeed, bool bRestoreState);

	// Object: Function UMG.UserWidget.PlayAnimationReverse
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x104cc835c
	// Return & Params: [ Num(4) Size(0x18) ]
	struct UUMGSequencePlayer* PlayAnimationReverse(struct UWidgetAnimation* InAnimation, float PlaybackSpeed, bool bRestoreState);

	// Object: Function UMG.UserWidget.PlayAnimationForward
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x104cc848c
	// Return & Params: [ Num(4) Size(0x18) ]
	struct UUMGSequencePlayer* PlayAnimationForward(struct UWidgetAnimation* InAnimation, float PlaybackSpeed, bool bRestoreState);

	// Object: Function UMG.UserWidget.PlayAnimation
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x104cc8818
	// Return & Params: [ Num(7) Size(0x28) ]
	struct UUMGSequencePlayer* PlayAnimation(struct UWidgetAnimation* InAnimation, float StartAtTime, int32_t NumLoopsToPlay, enum class EUMGSequencePlayMode PlayMode, float PlaybackSpeed, bool bRestoreState);

	// Object: Function UMG.UserWidget.PauseAnimation
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x104cc8238
	// Return & Params: [ Num(2) Size(0xc) ]
	float PauseAnimation(struct UWidgetAnimation* InAnimation);

	// Object: Function UMG.UserWidget.OnTouchStarted
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0x160) ]
	struct FEventReply OnTouchStarted(struct FGeometry MyGeometry, struct FPointerEvent& InTouchEvent);

	// Object: Function UMG.UserWidget.OnTouchMoved
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0x160) ]
	struct FEventReply OnTouchMoved(struct FGeometry MyGeometry, struct FPointerEvent& InTouchEvent);

	// Object: Function UMG.UserWidget.OnTouchGesture
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0x160) ]
	struct FEventReply OnTouchGesture(struct FGeometry MyGeometry, struct FPointerEvent& GestureEvent);

	// Object: Function UMG.UserWidget.OnTouchForceChanged
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0x160) ]
	struct FEventReply OnTouchForceChanged(struct FGeometry MyGeometry, struct FPointerEvent& InTouchEvent);

	// Object: Function UMG.UserWidget.OnTouchEnded
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0x160) ]
	struct FEventReply OnTouchEnded(struct FGeometry MyGeometry, struct FPointerEvent& InTouchEvent);

	// Object: Function UMG.UserWidget.OnRemovedFromFocusPath
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x8) ]
	void OnRemovedFromFocusPath(struct FFocusEvent InFocusEvent);

	// Object: Function UMG.UserWidget.OnPreviewMouseButtonDown
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0x160) ]
	struct FEventReply OnPreviewMouseButtonDown(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent);

	// Object: Function UMG.UserWidget.OnPreviewKeyDown
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0x128) ]
	struct FEventReply OnPreviewKeyDown(struct FGeometry MyGeometry, struct FKeyEvent InKeyEvent);

	// Object: Function UMG.UserWidget.OnPaint
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent|Const]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x30) ]
	void OnPaint(struct FPaintContext& Context);

	// Object: Function UMG.UserWidget.OnMouseWheel
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0x160) ]
	struct FEventReply OnMouseWheel(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent);

	// Object: Function UMG.UserWidget.OnMouseMove
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0x160) ]
	struct FEventReply OnMouseMove(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent);

	// Object: Function UMG.UserWidget.OnMouseLeave
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x70) ]
	void OnMouseLeave(struct FPointerEvent& MouseEvent);

	// Object: Function UMG.UserWidget.OnMouseEnter
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0xa8) ]
	void OnMouseEnter(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent);

	// Object: Function UMG.UserWidget.OnMouseCaptureLost
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnMouseCaptureLost();

	// Object: Function UMG.UserWidget.OnMouseButtonUp
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0x160) ]
	struct FEventReply OnMouseButtonUp(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent);

	// Object: Function UMG.UserWidget.OnMouseButtonDown
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0x160) ]
	struct FEventReply OnMouseButtonDown(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent);

	// Object: Function UMG.UserWidget.OnMouseButtonDoubleClick
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0x160) ]
	struct FEventReply OnMouseButtonDoubleClick(struct FGeometry InMyGeometry, struct FPointerEvent& InMouseEvent);

	// Object: Function UMG.UserWidget.OnMotionDetected
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0x138) ]
	struct FEventReply OnMotionDetected(struct FGeometry MyGeometry, struct FMotionEvent InMotionEvent);

	// Object: Function UMG.UserWidget.OnKeyUp
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0x128) ]
	struct FEventReply OnKeyUp(struct FGeometry MyGeometry, struct FKeyEvent InKeyEvent);

	// Object: Function UMG.UserWidget.OnKeyDown
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0x128) ]
	struct FEventReply OnKeyDown(struct FGeometry MyGeometry, struct FKeyEvent InKeyEvent);

	// Object: Function UMG.UserWidget.OnKeyChar
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0x110) ]
	struct FEventReply OnKeyChar(struct FGeometry MyGeometry, struct FCharacterEvent InCharacterEvent);

	// Object: Function UMG.UserWidget.OnInitialized
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnInitialized();

	// Object: Function UMG.UserWidget.OnFocusReceived
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0xf8) ]
	struct FEventReply OnFocusReceived(struct FGeometry MyGeometry, struct FFocusEvent InFocusEvent);

	// Object: Function UMG.UserWidget.OnFocusLost
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x8) ]
	void OnFocusLost(struct FFocusEvent InFocusEvent);

	// Object: Function UMG.UserWidget.OnDrop
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(4) Size(0xb1) ]
	bool OnDrop(struct FGeometry MyGeometry, struct FPointerEvent PointerEvent, struct UDragDropOperation* Operation);

	// Object: Function UMG.UserWidget.OnDragOver
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(4) Size(0xb1) ]
	bool OnDragOver(struct FGeometry MyGeometry, struct FPointerEvent PointerEvent, struct UDragDropOperation* Operation);

	// Object: Function UMG.UserWidget.OnDragLeave
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x78) ]
	void OnDragLeave(struct FPointerEvent PointerEvent, struct UDragDropOperation* Operation);

	// Object: Function UMG.UserWidget.OnDragEnter
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0xb0) ]
	void OnDragEnter(struct FGeometry MyGeometry, struct FPointerEvent PointerEvent, struct UDragDropOperation* Operation);

	// Object: Function UMG.UserWidget.OnDragDetected
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0xb0) ]
	void OnDragDetected(struct FGeometry MyGeometry, struct FPointerEvent& PointerEvent, struct UDragDropOperation*& Operation);

	// Object: Function UMG.UserWidget.OnDragCancelled
	// Flags: [BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x78) ]
	void OnDragCancelled(struct FPointerEvent& PointerEvent, struct UDragDropOperation* Operation);

	// Object: Function UMG.UserWidget.OnAnimationStarted
	// Flags: [BlueprintCosmetic|Native|Event|Protected|BlueprintEvent]
	// Offset: 0x104cc8d28
	// Return & Params: [ Num(1) Size(0x8) ]
	void OnAnimationStarted(struct UWidgetAnimation* Animation);

	// Object: Function UMG.UserWidget.OnAnimationFinished
	// Flags: [BlueprintCosmetic|Native|Event|Protected|BlueprintEvent]
	// Offset: 0x104cc8ca0
	// Return & Params: [ Num(1) Size(0x8) ]
	void OnAnimationFinished(struct UWidgetAnimation* Animation);

	// Object: Function UMG.UserWidget.OnAnalogValueChanged
	// Flags: [Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(3) Size(0x130) ]
	struct FEventReply OnAnalogValueChanged(struct FGeometry MyGeometry, struct FAnalogInputEvent InAnalogInputEvent);

	// Object: Function UMG.UserWidget.OnAddedToFocusPath
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x8) ]
	void OnAddedToFocusPath(struct FFocusEvent InFocusEvent);

	// Object: Function UMG.UserWidget.ListenForInputAction
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x104cc7bf4
	// Return & Params: [ Num(4) Size(0x1c) ]
	void ListenForInputAction(struct FName ActionName, enum class EInputEvent EventType, bool bConsume, struct FDelegate Callback);

	// Object: Function UMG.UserWidget.IsPlayingAnimation
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cc7d98
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsPlayingAnimation();

	// Object: Function UMG.UserWidget.IsListeningForInputAction
	// Flags: [Final|Native|Protected|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cc7a5c
	// Return & Params: [ Num(2) Size(0x9) ]
	bool IsListeningForInputAction(struct FName ActionName);

	// Object: Function UMG.UserWidget.IsInViewport
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cc9598
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsInViewport();

	// Object: Function UMG.UserWidget.IsInteractable
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent|Const]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsInteractable();

	// Object: Function UMG.UserWidget.IsAnyAnimationPlaying
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cc80e4
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsAnyAnimationPlaying();

	// Object: Function UMG.UserWidget.IsAnimationPlayingForward
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x104cc7e3c
	// Return & Params: [ Num(2) Size(0x9) ]
	bool IsAnimationPlayingForward(struct UWidgetAnimation* InAnimation);

	// Object: Function UMG.UserWidget.IsAnimationPlaying
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cc8118
	// Return & Params: [ Num(2) Size(0x9) ]
	bool IsAnimationPlaying(struct UWidgetAnimation* InAnimation);

	// Object: Function UMG.UserWidget.GetOwningPlayerPawn
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cc94e4
	// Return & Params: [ Num(1) Size(0x8) ]
	struct APawn* GetOwningPlayerPawn();

	// Object: Function UMG.UserWidget.GetOwningHUD
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cc7920
	// Return & Params: [ Num(1) Size(0x8) ]
	struct AHUD* GetOwningHUD();

	// Object: Function UMG.UserWidget.GetIsVisible
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cc95cc
	// Return & Params: [ Num(1) Size(0x1) ]
	bool GetIsVisible();

	// Object: Function UMG.UserWidget.GetAnimationCurrentTime
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cc81a8
	// Return & Params: [ Num(2) Size(0xc) ]
	float GetAnimationCurrentTime(struct UWidgetAnimation* InAnimation);

	// Object: Function UMG.UserWidget.GetAnchorsInViewport
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cc9638
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FAnchors GetAnchorsInViewport();

	// Object: Function UMG.UserWidget.GetAlignmentInViewport
	// Flags: [Final|BlueprintCosmetic|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cc9600
	// Return & Params: [ Num(1) Size(0x8) ]
	struct FVector2D GetAlignmentInViewport();

	// Object: Function UMG.UserWidget.DoPlayEnterAnim
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cc8db0
	// Return & Params: [ Num(1) Size(0x1) ]
	void DoPlayEnterAnim(bool InPlayFlag);

	// Object: Function UMG.UserWidget.Destruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void Destruct();

	// Object: Function UMG.UserWidget.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void Construct();

	// Object: Function UMG.UserWidget.CancelLatentActions
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cc94d0
	// Return & Params: [ Num(0) Size(0x0) ]
	void CancelLatentActions();

	// Object: Function UMG.UserWidget.BindToAnimationStarted
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cc93c0
	// Return & Params: [ Num(2) Size(0x18) ]
	void BindToAnimationStarted(struct UWidgetAnimation* Animation, struct FDelegate Delegate);

	// Object: Function UMG.UserWidget.BindToAnimationFinished
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cc9148
	// Return & Params: [ Num(2) Size(0x18) ]
	void BindToAnimationFinished(struct UWidgetAnimation* Animation, struct FDelegate Delegate);

	// Object: Function UMG.UserWidget.BindToAnimationEvent
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cc8e38
	// Return & Params: [ Num(4) Size(0x24) ]
	void BindToAnimationEvent(struct UWidgetAnimation* Animation, struct FDelegate Delegate, enum class EWidgetAnimationEvent AnimationEvent, struct FName UserTag);

	// Object: Function UMG.UserWidget.AddToViewport
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x104cc9968
	// Return & Params: [ Num(1) Size(0x4) ]
	void AddToViewport(int32_t ZOrder);

	// Object: Function UMG.UserWidget.AddToPlayerScreen
	// Flags: [Final|BlueprintCosmetic|Native|Public|BlueprintCallable]
	// Offset: 0x104cc98d8
	// Return & Params: [ Num(2) Size(0x5) ]
	bool AddToPlayerScreen(int32_t ZOrder);
};

// Object: Class UMG.Slider
// Inherited Bytes: 0x138 | Struct Size: 0x790
struct USlider : UWidget {
	// Fields
	float Value; // Offset: 0x138 | Size: 0x4
	struct FDelegate ValueDelegate; // Offset: 0x13c | Size: 0x10
	float MinValue; // Offset: 0x14c | Size: 0x4
	float MaxValue; // Offset: 0x150 | Size: 0x4
	char pad_0x154[0xc]; // Offset: 0x154 | Size: 0xc
	struct FSliderStyle WidgetStyle; // Offset: 0x160 | Size: 0x560
	enum class EOrientation Orientation; // Offset: 0x6c0 | Size: 0x1
	char pad_0x6C1[0x3]; // Offset: 0x6c1 | Size: 0x3
	struct FLinearColor SliderBarColor; // Offset: 0x6c4 | Size: 0x10
	struct FLinearColor SliderHandleColor; // Offset: 0x6d4 | Size: 0x10
	struct FVector2D SliderHandleOffset; // Offset: 0x6e4 | Size: 0x8
	bool CommitTouchStartValue; // Offset: 0x6ec | Size: 0x1
	bool IndentHandle; // Offset: 0x6ed | Size: 0x1
	bool Locked; // Offset: 0x6ee | Size: 0x1
	bool MouseUsesStep; // Offset: 0x6ef | Size: 0x1
	bool RequiresControllerLock; // Offset: 0x6f0 | Size: 0x1
	char pad_0x6F1[0x3]; // Offset: 0x6f1 | Size: 0x3
	float StepSize; // Offset: 0x6f4 | Size: 0x4
	bool IsFocusable; // Offset: 0x6f8 | Size: 0x1
	char pad_0x6F9[0x7]; // Offset: 0x6f9 | Size: 0x7
	struct FSoftObjectPath OnCaptureBeginSound; // Offset: 0x700 | Size: 0x18
	struct FSoftObjectPath OnCaptureEndSound; // Offset: 0x718 | Size: 0x18
	struct FMulticastInlineDelegate OnMouseCaptureBegin; // Offset: 0x730 | Size: 0x10
	struct FMulticastInlineDelegate OnMouseCaptureEnd; // Offset: 0x740 | Size: 0x10
	struct FMulticastInlineDelegate OnControllerCaptureBegin; // Offset: 0x750 | Size: 0x10
	struct FMulticastInlineDelegate OnControllerCaptureEnd; // Offset: 0x760 | Size: 0x10
	struct FMulticastInlineDelegate OnValueChanged; // Offset: 0x770 | Size: 0x10
	char pad_0x780[0x10]; // Offset: 0x780 | Size: 0x10

	// Functions

	// Object: Function UMG.Slider.SetValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cc0520
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetValue(float InValue);

	// Object: Function UMG.Slider.SetStepSize
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cc0290
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetStepSize(float InValue);

	// Object: Function UMG.Slider.SetSliderHandleOffset
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x104cc0114
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetSliderHandleOffset(struct FVector2D InValue);

	// Object: Function UMG.Slider.SetSliderHandleColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x104cc0190
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetSliderHandleColor(struct FLinearColor InValue);

	// Object: Function UMG.Slider.SetSliderBarColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x104cc0210
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetSliderBarColor(struct FLinearColor InValue);

	// Object: Function UMG.Slider.SetNormalBarImage
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104cbfe38
	// Return & Params: [ Num(1) Size(0xe0) ]
	void SetNormalBarImage(struct FSlateBrush& InImage);

	// Object: Function UMG.Slider.SetMinValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cc04a0
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetMinValue(float InValue);

	// Object: Function UMG.Slider.SetMaxValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cc0420
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetMaxValue(float InValue);

	// Object: Function UMG.Slider.SetLocked
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cc0310
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetLocked(bool InValue);

	// Object: Function UMG.Slider.SetIndentHandle
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cc0398
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetIndentHandle(bool InValue);

	// Object: Function UMG.Slider.SetHoveredBarImage
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104cbfbd8
	// Return & Params: [ Num(1) Size(0xe0) ]
	void SetHoveredBarImage(struct FSlateBrush& InImage);

	// Object: Function UMG.Slider.SetBarThickness
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cc0098
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetBarThickness(float InValue);

	// Object: Function UMG.Slider.GetValue
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cc05d4
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetValue();

	// Object: Function UMG.Slider.GetNormalizedValue
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cc05a0
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetNormalizedValue();
};

// Object: Class UMG.PanelWidget
// Inherited Bytes: 0x138 | Struct Size: 0x150
struct UPanelWidget : UWidget {
	// Fields
	struct TArray<struct UPanelSlot*> Slots; // Offset: 0x138 | Size: 0x10
	char pad_0x148[0x8]; // Offset: 0x148 | Size: 0x8

	// Functions

	// Object: Function UMG.PanelWidget.RemoveChildAt
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cb111c
	// Return & Params: [ Num(2) Size(0x5) ]
	bool RemoveChildAt(int32_t Index);

	// Object: Function UMG.PanelWidget.RemoveChild
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cb0ffc
	// Return & Params: [ Num(2) Size(0x9) ]
	bool RemoveChild(struct UWidget* Content);

	// Object: Function UMG.PanelWidget.HasChild
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cb11ac
	// Return & Params: [ Num(2) Size(0x9) ]
	bool HasChild(struct UWidget* Content);

	// Object: Function UMG.PanelWidget.HasAnyChildren
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cb0fc8
	// Return & Params: [ Num(1) Size(0x1) ]
	bool HasAnyChildren();

	// Object: Function UMG.PanelWidget.GetChildrenCount
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cb13dc
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetChildrenCount();

	// Object: Function UMG.PanelWidget.GetChildIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cb123c
	// Return & Params: [ Num(2) Size(0xc) ]
	int32_t GetChildIndex(struct UWidget* Content);

	// Object: Function UMG.PanelWidget.GetChildAt
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cb134c
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UWidget* GetChildAt(int32_t Index);

	// Object: Function UMG.PanelWidget.GetAllChildren
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cb12cc
	// Return & Params: [ Num(1) Size(0x10) ]
	struct TArray<struct UWidget*> GetAllChildren();

	// Object: Function UMG.PanelWidget.ClearChildren
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104cb0fac
	// Return & Params: [ Num(0) Size(0x0) ]
	void ClearChildren();

	// Object: Function UMG.PanelWidget.AddChild
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cb108c
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UPanelSlot* AddChild(struct UWidget* Content);
};

// Object: Class UMG.WidgetSwitcher
// Inherited Bytes: 0x150 | Struct Size: 0x160
struct UWidgetSwitcher : UPanelWidget {
	// Fields
	int32_t ActiveWidgetIndex; // Offset: 0x14c | Size: 0x4
	char pad_0x154[0xc]; // Offset: 0x154 | Size: 0xc

	// Functions

	// Object: Function UMG.WidgetSwitcher.SetActiveWidgetIndex
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104ce53a4
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetActiveWidgetIndex(int32_t Index);

	// Object: Function UMG.WidgetSwitcher.SetActiveWidget
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104ce531c
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetActiveWidget(struct UWidget* Widget);

	// Object: Function UMG.WidgetSwitcher.GetWidgetAtIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ce528c
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UWidget* GetWidgetAtIndex(int32_t Index);

	// Object: Function UMG.WidgetSwitcher.GetNumWidgets
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ce5460
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetNumWidgets();

	// Object: Function UMG.WidgetSwitcher.GetActiveWidgetIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ce542c
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetActiveWidgetIndex();

	// Object: Function UMG.WidgetSwitcher.GetActiveWidget
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ce5258
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UWidget* GetActiveWidget();
};

// Object: Class UMG.ContentWidget
// Inherited Bytes: 0x150 | Struct Size: 0x150
struct UContentWidget : UPanelWidget {
	// Functions

	// Object: Function UMG.ContentWidget.SetContent
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c9f54c
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UPanelSlot* SetContent(struct UWidget* Content);

	// Object: Function UMG.ContentWidget.GetContentSlot
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c9f5dc
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UPanelSlot* GetContentSlot();

	// Object: Function UMG.ContentWidget.GetContent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c9f518
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UWidget* GetContent();
};

// Object: Class UMG.Border
// Inherited Bytes: 0x150 | Struct Size: 0x2f0
struct UBorder : UContentWidget {
	// Fields
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0x149 | Size: 0x1
	enum class EVerticalAlignment VerticalAlignment; // Offset: 0x14a | Size: 0x1
	char bShowEffectWhenDisabled : 1; // Offset: 0x14b | Size: 0x1
	struct FLinearColor ContentColorAndOpacity; // Offset: 0x14c | Size: 0x10
	struct FDelegate ContentColorAndOpacityDelegate; // Offset: 0x15c | Size: 0x10
	struct FMargin Padding; // Offset: 0x16c | Size: 0x10
	struct FSlateBrush Background; // Offset: 0x180 | Size: 0xe0
	struct FDelegate BackgroundDelegate; // Offset: 0x260 | Size: 0x10
	struct FLinearColor BrushColor; // Offset: 0x270 | Size: 0x10
	struct FDelegate BrushColorDelegate; // Offset: 0x280 | Size: 0x10
	struct FVector2D DesiredSizeScale; // Offset: 0x290 | Size: 0x8
	bool bFlipForRightToLeftFlowDirection; // Offset: 0x298 | Size: 0x1
	char pad_0x29B_1 : 7; // Offset: 0x29b | Size: 0x1
	struct FDelegate OnMouseButtonDownEvent; // Offset: 0x29c | Size: 0x10
	struct FDelegate OnMouseButtonUpEvent; // Offset: 0x2ac | Size: 0x10
	struct FDelegate OnMouseMoveEvent; // Offset: 0x2bc | Size: 0x10
	struct FDelegate OnMouseDoubleClickEvent; // Offset: 0x2cc | Size: 0x10
	char pad_0x2DC[0x14]; // Offset: 0x2dc | Size: 0x14

	// Functions

	// Object: Function UMG.Border.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c9883c
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment);

	// Object: Function UMG.Border.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c9893c
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetPadding(struct FMargin InPadding);

	// Object: Function UMG.Border.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c988bc
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment);

	// Object: Function UMG.Border.SetDesiredSizeScale
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x104c9832c
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetDesiredSizeScale(struct FVector2D InScale);

	// Object: Function UMG.Border.SetContentColorAndOpacity
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x104c989c0
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetContentColorAndOpacity(struct FLinearColor InContentColorAndOpacity);

	// Object: Function UMG.Border.SetBrushFromTexture
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c9845c
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetBrushFromTexture(struct UTexture2D* Texture);

	// Object: Function UMG.Border.SetBrushFromMaterial
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c983dc
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetBrushFromMaterial(struct UMaterialInterface* Material);

	// Object: Function UMG.Border.SetBrushFromAsset
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c984dc
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetBrushFromAsset(struct USlateBrushAsset* Asset);

	// Object: Function UMG.Border.SetBrushColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x104c987bc
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetBrushColor(struct FLinearColor InBrushColor);

	// Object: Function UMG.Border.SetBrush
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104c9855c
	// Return & Params: [ Num(1) Size(0xe0) ]
	void SetBrush(struct FSlateBrush& InBrush);

	// Object: Function UMG.Border.GetDynamicMaterial
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c983a8
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UMaterialInstanceDynamic* GetDynamicMaterial();
};

// Object: Class UMG.DynamicEntryBoxBase
// Inherited Bytes: 0x138 | Struct Size: 0x1f8
struct UDynamicEntryBoxBase : UWidget {
	// Fields
	enum class EDynamicBoxType EntryBoxType; // Offset: 0x138 | Size: 0x1
	char pad_0x139[0x3]; // Offset: 0x139 | Size: 0x3
	struct FVector2D EntrySpacing; // Offset: 0x13c | Size: 0x8
	char pad_0x144[0x4]; // Offset: 0x144 | Size: 0x4
	struct TArray<struct FVector2D> SpacingPattern; // Offset: 0x148 | Size: 0x10
	struct FSlateChildSize EntrySizeRule; // Offset: 0x158 | Size: 0x8
	enum class EHorizontalAlignment EntryHorizontalAlignment; // Offset: 0x160 | Size: 0x1
	enum class EVerticalAlignment EntryVerticalAlignment; // Offset: 0x161 | Size: 0x1
	char pad_0x162[0x2]; // Offset: 0x162 | Size: 0x2
	int32_t MaxElementSize; // Offset: 0x164 | Size: 0x4
	char pad_0x168[0x10]; // Offset: 0x168 | Size: 0x10
	struct FUserWidgetPool EntryWidgetPool; // Offset: 0x178 | Size: 0x80

	// Functions

	// Object: Function UMG.DynamicEntryBoxBase.SetEntrySpacing
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x104ca0a94
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetEntrySpacing(struct FVector2D& InEntrySpacing);

	// Object: Function UMG.DynamicEntryBoxBase.GetNumEntries
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ca0b1c
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetNumEntries();

	// Object: Function UMG.DynamicEntryBoxBase.GetAllEntries
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ca0b50
	// Return & Params: [ Num(1) Size(0x10) ]
	struct TArray<struct UUserWidget*> GetAllEntries();
};

// Object: Class UMG.Button
// Inherited Bytes: 0x150 | Struct Size: 0x5e0
struct UButton : UContentWidget {
	// Fields
	struct USlateWidgetStyleAsset* Style; // Offset: 0x150 | Size: 0x8
	char pad_0x158[0x8]; // Offset: 0x158 | Size: 0x8
	struct FButtonStyle WidgetStyle; // Offset: 0x160 | Size: 0x3e0
	struct FLinearColor ColorAndOpacity; // Offset: 0x540 | Size: 0x10
	struct FLinearColor BackgroundColor; // Offset: 0x550 | Size: 0x10
	enum class EButtonClickMethod ClickMethod; // Offset: 0x560 | Size: 0x1
	enum class EButtonTouchMethod TouchMethod; // Offset: 0x561 | Size: 0x1
	enum class EButtonPressMethod PressMethod; // Offset: 0x562 | Size: 0x1
	bool IsFocusable; // Offset: 0x563 | Size: 0x1
	char pad_0x564[0x4]; // Offset: 0x564 | Size: 0x4
	struct FMulticastInlineDelegate OnClicked; // Offset: 0x568 | Size: 0x10
	struct FMulticastInlineDelegate OnPressed; // Offset: 0x578 | Size: 0x10
	struct FMulticastInlineDelegate OnReleased; // Offset: 0x588 | Size: 0x10
	struct FMulticastInlineDelegate OnHovered; // Offset: 0x598 | Size: 0x10
	struct FMulticastInlineDelegate OnUnhovered; // Offset: 0x5a8 | Size: 0x10
	struct FSoftObjectPath OnClickedSound; // Offset: 0x5b8 | Size: 0x18
	char pad_0x5D0[0x10]; // Offset: 0x5d0 | Size: 0x10

	// Functions

	// Object: Function UMG.Button.SetTouchMethod
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c99b40
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetTouchMethod(enum class EButtonTouchMethod InTouchMethod);

	// Object: Function UMG.Button.SetStyle
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104c99d74
	// Return & Params: [ Num(1) Size(0x3e0) ]
	void SetStyle(struct FButtonStyle& InStyle);

	// Object: Function UMG.Button.SetPressMethod
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c99ac0
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetPressMethod(enum class EButtonPressMethod InPressMethod);

	// Object: Function UMG.Button.SetColorAndOpacity
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x104c99cf4
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetColorAndOpacity(struct FLinearColor InColorAndOpacity);

	// Object: Function UMG.Button.SetClickMethod
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c99bc0
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetClickMethod(enum class EButtonClickMethod InClickMethod);

	// Object: Function UMG.Button.SetBackgroundColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x104c99c74
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetBackgroundColor(struct FLinearColor InBackgroundColor);

	// Object: Function UMG.Button.IsPressed
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c99c40
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsPressed();
};

// Object: Class UMG.TextLayoutWidget
// Inherited Bytes: 0x138 | Struct Size: 0x160
struct UTextLayoutWidget : UWidget {
	// Fields
	struct FShapedTextOptions ShapedTextOptions; // Offset: 0x138 | Size: 0x3
	enum class ETextJustify Justification; // Offset: 0x13b | Size: 0x1
	enum class ETextWrappingPolicy WrappingPolicy; // Offset: 0x13c | Size: 0x1
	char AutoWrapText : 1; // Offset: 0x13d | Size: 0x1
	char pad_0x13D_1 : 7; // Offset: 0x13d | Size: 0x1
	char pad_0x13E[0x2]; // Offset: 0x13e | Size: 0x2
	float WrapTextAt; // Offset: 0x140 | Size: 0x4
	struct FMargin Margin; // Offset: 0x144 | Size: 0x10
	float LineHeightPercentage; // Offset: 0x154 | Size: 0x4
	char AlwaysKeepJustification : 1; // Offset: 0x158 | Size: 0x1
	char pad_0x158_1 : 7; // Offset: 0x158 | Size: 0x1
	char pad_0x159[0x7]; // Offset: 0x159 | Size: 0x7

	// Functions

	// Object: Function UMG.TextLayoutWidget.SetJustification
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104cc5250
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetJustification(enum class ETextJustify InJustification);
};

// Object: Class UMG.TextBlock
// Inherited Bytes: 0x160 | Struct Size: 0x420
struct UTextBlock : UTextLayoutWidget {
	// Fields
	struct FText Text; // Offset: 0x160 | Size: 0x18
	struct FDelegate TextDelegate; // Offset: 0x178 | Size: 0x10
	struct FSlateColor ColorAndOpacity; // Offset: 0x188 | Size: 0x28
	struct FDelegate ColorAndOpacityDelegate; // Offset: 0x1b0 | Size: 0x10
	struct FSlateFontInfo Font; // Offset: 0x1c0 | Size: 0x60
	struct FSlateBrush StrikeBrush; // Offset: 0x220 | Size: 0xe0
	struct FSlateBrush BackgroundBrush; // Offset: 0x300 | Size: 0xe0
	struct FVector2D ShadowOffset; // Offset: 0x3e0 | Size: 0x8
	struct FLinearColor ShadowColorAndOpacity; // Offset: 0x3e8 | Size: 0x10
	struct FDelegate ShadowColorAndOpacityDelegate; // Offset: 0x3f8 | Size: 0x10
	float MinDesiredWidth; // Offset: 0x408 | Size: 0x4
	bool bWrapWithInvalidationPanel; // Offset: 0x40c | Size: 0x1
	bool bAutoWrapText; // Offset: 0x40d | Size: 0x1
	enum class ETextTransformPolicy TextTransformPolicy; // Offset: 0x40e | Size: 0x1
	bool bSimpleTextMode; // Offset: 0x40f | Size: 0x1
	char pad_0x410[0x10]; // Offset: 0x410 | Size: 0x10

	// Functions

	// Object: Function UMG.TextBlock.SetTextTransformPolicy
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cc3b9c
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetTextTransformPolicy(enum class ETextTransformPolicy InTransformPolicy);

	// Object: Function UMG.TextBlock.SetText
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104cc3928
	// Return & Params: [ Num(1) Size(0x18) ]
	void SetText(struct FText InText);

	// Object: Function UMG.TextBlock.SetStrikeBrush
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cc4160
	// Return & Params: [ Num(1) Size(0xe0) ]
	void SetStrikeBrush(struct FSlateBrush InStrikeBrush);

	// Object: Function UMG.TextBlock.SetShadowOffset
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x104cc4718
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetShadowOffset(struct FVector2D InShadowOffset);

	// Object: Function UMG.TextBlock.SetShadowColorAndOpacity
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x104cc4794
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetShadowColorAndOpacity(struct FLinearColor InShadowColorAndOpacity);

	// Object: Function UMG.TextBlock.SetOpacity
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cc4814
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetOpacity(float InOpacity);

	// Object: Function UMG.TextBlock.SetMinDesiredWidth
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cc3ca4
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetMinDesiredWidth(float InMinDesiredWidth);

	// Object: Function UMG.TextBlock.SetFont
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cc459c
	// Return & Params: [ Num(1) Size(0x60) ]
	void SetFont(struct FSlateFontInfo InFontInfo);

	// Object: Function UMG.TextBlock.SetColorAndOpacity
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cc4894
	// Return & Params: [ Num(1) Size(0x28) ]
	void SetColorAndOpacity(struct FSlateColor InColorAndOpacity);

	// Object: Function UMG.TextBlock.SetBackgroundBrush
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cc3d24
	// Return & Params: [ Num(1) Size(0xe0) ]
	void SetBackgroundBrush(struct FSlateBrush InBackgroundBrush);

	// Object: Function UMG.TextBlock.SetAutoWrapText
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cc3c1c
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetAutoWrapText(bool InAutoTextWrap);

	// Object: Function UMG.TextBlock.GetText
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cc3a8c
	// Return & Params: [ Num(1) Size(0x18) ]
	struct FText GetText();

	// Object: Function UMG.TextBlock.GetDynamicOutlineMaterial
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cc3b34
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UMaterialInstanceDynamic* GetDynamicOutlineMaterial();

	// Object: Function UMG.TextBlock.GetDynamicFontMaterial
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cc3b68
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UMaterialInstanceDynamic* GetDynamicFontMaterial();
};

// Object: Class UMG.ScrollBox
// Inherited Bytes: 0x150 | Struct Size: 0xd40
struct UScrollBox : UPanelWidget {
	// Fields
	struct FScrollBoxStyle WidgetStyle; // Offset: 0x150 | Size: 0x390
	struct FScrollBarStyle WidgetBarStyle; // Offset: 0x4e0 | Size: 0x7f0
	struct USlateWidgetStyleAsset* Style; // Offset: 0xcd0 | Size: 0x8
	struct USlateWidgetStyleAsset* BarStyle; // Offset: 0xcd8 | Size: 0x8
	enum class EOrientation Orientation; // Offset: 0xce0 | Size: 0x1
	enum class ESlateVisibility ScrollBarVisibility; // Offset: 0xce1 | Size: 0x1
	enum class EConsumeMouseWheel ConsumeMouseWheel; // Offset: 0xce2 | Size: 0x1
	char pad_0xCE3[0x1]; // Offset: 0xce3 | Size: 0x1
	struct FVector2D ScrollbarThickness; // Offset: 0xce4 | Size: 0x8
	struct FMargin ScrollbarPadding; // Offset: 0xcec | Size: 0x10
	bool AlwaysShowScrollbar; // Offset: 0xcfc | Size: 0x1
	bool AlwaysShowScrollbarTrack; // Offset: 0xcfd | Size: 0x1
	bool AllowOverscroll; // Offset: 0xcfe | Size: 0x1
	bool bAnimateWheelScrolling; // Offset: 0xcff | Size: 0x1
	enum class EDescendantScrollDestination NavigationDestination; // Offset: 0xd00 | Size: 0x1
	char pad_0xD01[0x3]; // Offset: 0xd01 | Size: 0x3
	float NavigationScrollPadding; // Offset: 0xd04 | Size: 0x4
	enum class EScrollWhenFocusChanges ScrollWhenFocusChanges; // Offset: 0xd08 | Size: 0x1
	bool bAllowRightClickDragScrolling; // Offset: 0xd09 | Size: 0x1
	char pad_0xD0A[0x2]; // Offset: 0xd0a | Size: 0x2
	float WheelScrollMultiplier; // Offset: 0xd0c | Size: 0x4
	struct FMulticastInlineDelegate OnUserScrolled; // Offset: 0xd10 | Size: 0x10
	char pad_0xD20[0x20]; // Offset: 0xd20 | Size: 0x20

	// Functions

	// Object: Function UMG.ScrollBox.SetWheelScrollMultiplier
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cb8c1c
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetWheelScrollMultiplier(float NewWheelScrollMultiplier);

	// Object: Function UMG.ScrollBox.SetScrollOffset
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cb8b88
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetScrollOffset(float NewScrollOffset);

	// Object: Function UMG.ScrollBox.SetScrollBarVisibility
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cb8f48
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetScrollBarVisibility(enum class ESlateVisibility NewScrollBarVisibility);

	// Object: Function UMG.ScrollBox.SetScrollbarThickness
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x104cb8ec0
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetScrollbarThickness(struct FVector2D& NewScrollbarThickness);

	// Object: Function UMG.ScrollBox.SetScrollbarPadding
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104cb8e34
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetScrollbarPadding(struct FMargin& NewScrollbarPadding);

	// Object: Function UMG.ScrollBox.SetOrientation
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cb8fc8
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetOrientation(enum class EOrientation NewOrientation);

	// Object: Function UMG.ScrollBox.SetConsumeMouseWheel
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cb9048
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetConsumeMouseWheel(enum class EConsumeMouseWheel NewConsumeMouseWheel);

	// Object: Function UMG.ScrollBox.SetAnimateWheelScrolling
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cb8c9c
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetAnimateWheelScrolling(bool bShouldAnimateWheelScrolling);

	// Object: Function UMG.ScrollBox.SetAlwaysShowScrollbar
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cb8dac
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetAlwaysShowScrollbar(bool NewAlwaysShowScrollbar);

	// Object: Function UMG.ScrollBox.SetAllowOverscroll
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cb8d24
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetAllowOverscroll(bool NewAllowOverscroll);

	// Object: Function UMG.ScrollBox.ScrollWidgetIntoView
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cb894c
	// Return & Params: [ Num(4) Size(0x10) ]
	void ScrollWidgetIntoView(struct UWidget* WidgetToFind, bool AnimateScroll, enum class EDescendantScrollDestination ScrollDestination, float Padding);

	// Object: Function UMG.ScrollBox.ScrollToStart
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cb8ad8
	// Return & Params: [ Num(0) Size(0x0) ]
	void ScrollToStart();

	// Object: Function UMG.ScrollBox.ScrollToEnd
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cb8ac4
	// Return & Params: [ Num(0) Size(0x0) ]
	void ScrollToEnd();

	// Object: Function UMG.ScrollBox.GetViewOffsetFraction
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cb8aec
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetViewOffsetFraction();

	// Object: Function UMG.ScrollBox.GetScrollOffsetOfEnd
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cb8b20
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetScrollOffsetOfEnd();

	// Object: Function UMG.ScrollBox.GetScrollOffset
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cb8b54
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetScrollOffset();

	// Object: Function UMG.ScrollBox.EndInertialScrolling
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cb8c08
	// Return & Params: [ Num(0) Size(0x0) ]
	void EndInertialScrolling();
};

// Object: Class UMG.Image
// Inherited Bytes: 0x138 | Struct Size: 0x2c0
struct UImage : UWidget {
	// Fields
	char pad_0x138[0x8]; // Offset: 0x138 | Size: 0x8
	struct FSlateBrush Brush; // Offset: 0x140 | Size: 0xe0
	struct FDelegate BrushDelegate; // Offset: 0x220 | Size: 0x10
	struct FLinearColor ColorAndOpacity; // Offset: 0x230 | Size: 0x10
	struct FDelegate ColorAndOpacityDelegate; // Offset: 0x240 | Size: 0x10
	bool bFlipForRightToLeftFlowDirection; // Offset: 0x250 | Size: 0x1
	char pad_0x251[0x3]; // Offset: 0x251 | Size: 0x3
	struct FDelegate OnMouseButtonDownEvent; // Offset: 0x254 | Size: 0x10
	char pad_0x264[0x4]; // Offset: 0x264 | Size: 0x4
	struct FSoftObjectPath OnClickedSound; // Offset: 0x268 | Size: 0x18
	char pad_0x280[0x40]; // Offset: 0x280 | Size: 0x40

	// Functions

	// Object: Function UMG.Image.SetOpacity
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ca6c44
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetOpacity(float InOpacity);

	// Object: Function UMG.Image.SetColorAndOpacity
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x104ca6cc4
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetColorAndOpacity(struct FLinearColor InColorAndOpacity);

	// Object: Function UMG.Image.SetBrushTintColor
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ca6a58
	// Return & Params: [ Num(1) Size(0x28) ]
	void SetBrushTintColor(struct FSlateColor TintColor);

	// Object: Function UMG.Image.SetBrushSize
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x104ca6bc8
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetBrushSize(struct FVector2D DesiredSize);

	// Object: Function UMG.Image.SetBrushResourceObject
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ca69d8
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetBrushResourceObject(struct UObject* ResourceObject);

	// Object: Function UMG.Image.SetBrushFromTextureDynamic
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104ca6444
	// Return & Params: [ Num(2) Size(0x9) ]
	void SetBrushFromTextureDynamic(struct UTexture2DDynamic* Texture, bool bMatchSize);

	// Object: Function UMG.Image.SetBrushFromTexture
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104ca660c
	// Return & Params: [ Num(2) Size(0x9) ]
	void SetBrushFromTexture(struct UTexture2D* Texture, bool bMatchSize);

	// Object: Function UMG.Image.SetBrushFromSoftTexture
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104ca6264
	// Return & Params: [ Num(2) Size(0x29) ]
	void SetBrushFromSoftTexture(struct TSoftObjectPtr<UTexture2D> SoftTexture, bool bMatchSize);

	// Object: Function UMG.Image.SetBrushFromSoftMaterial
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104ca6160
	// Return & Params: [ Num(1) Size(0x28) ]
	void SetBrushFromSoftMaterial(struct TSoftObjectPtr<UMaterialInterface> SoftMaterial);

	// Object: Function UMG.Image.SetBrushFromMaterial
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104ca63bc
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetBrushFromMaterial(struct UMaterialInterface* Material);

	// Object: Function UMG.Image.SetBrushFromAtlasInterface
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104ca6520
	// Return & Params: [ Num(2) Size(0x11) ]
	void SetBrushFromAtlasInterface(struct TScriptInterface<ISlateTextureAtlasInterface> AtlasRegion, bool bMatchSize);

	// Object: Function UMG.Image.SetBrushFromAsset
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104ca66e8
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetBrushFromAsset(struct USlateBrushAsset* Asset);

	// Object: Function UMG.Image.SetBrush
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104ca6770
	// Return & Params: [ Num(1) Size(0xe0) ]
	void SetBrush(struct FSlateBrush& InBrush);

	// Object: Function UMG.Image.GetDynamicMaterial
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ca612c
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UMaterialInstanceDynamic* GetDynamicMaterial();
};

// Object: Class UMG.ListViewBase
// Inherited Bytes: 0x138 | Struct Size: 0xa70
struct UListViewBase : UWidget {
	// Fields
	struct UUserWidget* EntryWidgetClass; // Offset: 0x138 | Size: 0x8
	float WheelScrollMultiplier; // Offset: 0x140 | Size: 0x4
	bool bEnableScrollAnimation; // Offset: 0x144 | Size: 0x1
	bool bEnableFixedLineOffset; // Offset: 0x145 | Size: 0x1
	bool bClampScroll; // Offset: 0x146 | Size: 0x1
	bool bDisableScroll; // Offset: 0x147 | Size: 0x1
	float FixedLineScrollOffset; // Offset: 0x148 | Size: 0x4
	char pad_0x14C[0x4]; // Offset: 0x14c | Size: 0x4
	struct FMulticastInlineDelegate BP_OnEntryGeneratedPre; // Offset: 0x150 | Size: 0x10
	struct FMulticastInlineDelegate BP_OnEntryGenerated; // Offset: 0x160 | Size: 0x10
	struct FMulticastInlineDelegate BP_OnEntryReleased; // Offset: 0x170 | Size: 0x10
	struct FUserWidgetPool EntryWidgetPool; // Offset: 0x180 | Size: 0x80
	struct FScrollBarStyle WidgetBarStyle; // Offset: 0x200 | Size: 0x7f0
	enum class ESlateVisibility ScrollBarVisibility; // Offset: 0x9f0 | Size: 0x1
	char pad_0x9F1[0x3]; // Offset: 0x9f1 | Size: 0x3
	struct FVector2D ScrollbarThickness; // Offset: 0x9f4 | Size: 0x8
	struct FMargin ScrollbarPadding; // Offset: 0x9fc | Size: 0x10
	bool AlwaysShowScrollbar; // Offset: 0xa0c | Size: 0x1
	bool AlwaysShowScrollbarTrack; // Offset: 0xa0d | Size: 0x1
	char pad_0xA0E[0x62]; // Offset: 0xa0e | Size: 0x62

	// Functions

	// Object: Function UMG.ListViewBase.SetWheelScrollMultiplier
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cac9a4
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetWheelScrollMultiplier(float NewWheelScrollMultiplier);

	// Object: Function UMG.ListViewBase.SetScrollOffset
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104caca58
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetScrollOffset(float InScrollOffset);

	// Object: Function UMG.ListViewBase.SetScrollBarVisibility
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cac924
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetScrollBarVisibility(enum class ESlateVisibility InVisibility);

	// Object: Function UMG.ListViewBase.SetScrollbarThickness
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x104cac744
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetScrollbarThickness(struct FVector2D& NewScrollbarThickness);

	// Object: Function UMG.ListViewBase.SetScrollbarPadding
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104cac6b8
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetScrollbarPadding(struct FMargin& NewScrollbarPadding);

	// Object: Function UMG.ListViewBase.SetEnableScrollAnimation
	// Flags: [Final|Native|Protected|BlueprintCallable]
	// Offset: 0x104cac7cc
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetEnableScrollAnimation(bool bNewEnableScrollAnimation);

	// Object: Function UMG.ListViewBase.SetDisableScroll
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cac89c
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetDisableScroll(bool bInDisableScroll);

	// Object: Function UMG.ListViewBase.SetAlwaysShowScrollbar
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cac630
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetAlwaysShowScrollbar(bool NewAlwaysShowScrollbar);

	// Object: Function UMG.ListViewBase.ScrollToTop
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cacaec
	// Return & Params: [ Num(0) Size(0x0) ]
	void ScrollToTop();

	// Object: Function UMG.ListViewBase.ScrollToBottom
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cacad8
	// Return & Params: [ Num(0) Size(0x0) ]
	void ScrollToBottom();

	// Object: Function UMG.ListViewBase.RequestRefresh
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cac854
	// Return & Params: [ Num(0) Size(0x0) ]
	void RequestRefresh();

	// Object: Function UMG.ListViewBase.RegenerateAllEntries
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cacb00
	// Return & Params: [ Num(0) Size(0x0) ]
	void RegenerateAllEntries();

	// Object: Function UMG.ListViewBase.GetScrollOffset
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104caca24
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetScrollOffset();

	// Object: Function UMG.ListViewBase.GetDisplayedEntryWidgets
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cacb14
	// Return & Params: [ Num(1) Size(0x10) ]
	struct TArray<struct UUserWidget*> GetDisplayedEntryWidgets();

	// Object: Function UMG.ListViewBase.GetDisableScroll
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cac868
	// Return & Params: [ Num(1) Size(0x1) ]
	bool GetDisableScroll();
};

// Object: Class UMG.ListView
// Inherited Bytes: 0xa70 | Struct Size: 0xbf0
struct UListView : UListViewBase {
	// Fields
	char pad_0xA70[0xb8]; // Offset: 0xa70 | Size: 0xb8
	enum class EOrientation Orientation; // Offset: 0xb28 | Size: 0x1
	enum class ESelectionMode SelectionMode; // Offset: 0xb29 | Size: 0x1
	enum class EConsumeMouseWheel ConsumeMouseWheel; // Offset: 0xb2a | Size: 0x1
	bool bClearSelectionOnClick; // Offset: 0xb2b | Size: 0x1
	bool bIsFocusable; // Offset: 0xb2c | Size: 0x1
	char pad_0xB2D[0x3]; // Offset: 0xb2d | Size: 0x3
	float EntrySpacing; // Offset: 0xb30 | Size: 0x4
	bool bReturnFocusToSelection; // Offset: 0xb34 | Size: 0x1
	char pad_0xB35[0x3]; // Offset: 0xb35 | Size: 0x3
	float ListItemStartPosOffset; // Offset: 0xb38 | Size: 0x4
	char pad_0xB3C[0x4]; // Offset: 0xb3c | Size: 0x4
	struct TArray<struct UObject*> ListItems; // Offset: 0xb40 | Size: 0x10
	char pad_0xB50[0x10]; // Offset: 0xb50 | Size: 0x10
	bool EnableDelayAdd; // Offset: 0xb60 | Size: 0x1
	char pad_0xB61[0x3]; // Offset: 0xb61 | Size: 0x3
	float DelayAddInterval; // Offset: 0xb64 | Size: 0x4
	int32_t NumInPanel; // Offset: 0xb68 | Size: 0x4
	char pad_0xB6C[0x4]; // Offset: 0xb6c | Size: 0x4
	struct TArray<struct UObject*> DelayAddedListItems; // Offset: 0xb70 | Size: 0x10
	bool DelayAddAnimFlag; // Offset: 0xb80 | Size: 0x1
	char pad_0xB81[0x7]; // Offset: 0xb81 | Size: 0x7
	struct FMulticastInlineDelegate BP_OnEntryInitialized; // Offset: 0xb88 | Size: 0x10
	struct FMulticastInlineDelegate BP_OnItemClicked; // Offset: 0xb98 | Size: 0x10
	struct FMulticastInlineDelegate BP_OnItemDoubleClicked; // Offset: 0xba8 | Size: 0x10
	struct FMulticastInlineDelegate BP_OnItemIsHoveredChanged; // Offset: 0xbb8 | Size: 0x10
	struct FMulticastInlineDelegate BP_OnItemSelectionChanged; // Offset: 0xbc8 | Size: 0x10
	struct FMulticastInlineDelegate BP_OnItemScrolledIntoView; // Offset: 0xbd8 | Size: 0x10
	char pad_0xBE8[0x8]; // Offset: 0xbe8 | Size: 0x8

	// Functions

	// Object: Function UMG.ListView.SetSelectionMode
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ca9e60
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetSelectionMode(enum class ESelectionMode SelectionMode);

	// Object: Function UMG.ListView.SetSelectedIndex
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ca9d2c
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetSelectedIndex(int32_t Index);

	// Object: Function UMG.ListView.ScrollIndexIntoView
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ca9dac
	// Return & Params: [ Num(1) Size(0x4) ]
	void ScrollIndexIntoView(int32_t Index);

	// Object: Function UMG.ListView.RemoveItem
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104caa048
	// Return & Params: [ Num(1) Size(0x8) ]
	void RemoveItem(struct UObject* Item);

	// Object: Function UMG.ListView.NavigateToIndex
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ca9cac
	// Return & Params: [ Num(1) Size(0x4) ]
	void NavigateToIndex(int32_t Index);

	// Object: Function UMG.ListView.IsRefreshPending
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ca9e2c
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsRefreshPending();

	// Object: Function UMG.ListView.GetNumItems
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ca9f84
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetNumItems();

	// Object: Function UMG.ListView.GetListItems
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104caa1cc
	// Return & Params: [ Num(1) Size(0x10) ]
	struct TArray<struct UObject*> GetListItems();

	// Object: Function UMG.ListView.GetItemAt
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ca9fb8
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UObject* GetItemAt(int32_t Index);

	// Object: Function UMG.ListView.GetIndexForItem
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ca9ef4
	// Return & Params: [ Num(2) Size(0xc) ]
	int32_t GetIndexForItem(struct UObject* Item);

	// Object: Function UMG.ListView.GetDelayAddedListItems
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104caa148
	// Return & Params: [ Num(1) Size(0x10) ]
	struct TArray<struct UObject*> GetDelayAddedListItems();

	// Object: Function UMG.ListView.ClearListItems
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ca9ee0
	// Return & Params: [ Num(0) Size(0x0) ]
	void ClearListItems();

	// Object: Function UMG.ListView.BP_SetSelectedItem
	// Flags: [Final|Native|Private|BlueprintCallable]
	// Offset: 0x104ca9c2c
	// Return & Params: [ Num(1) Size(0x8) ]
	void BP_SetSelectedItem(struct UObject* Item);

	// Object: Function UMG.ListView.BP_SetListItems
	// Flags: [Final|Native|Private|HasOutParms|BlueprintCallable]
	// Offset: 0x104ca982c
	// Return & Params: [ Num(1) Size(0x10) ]
	void BP_SetListItems(struct TArray<struct UObject*>& InListItems);

	// Object: Function UMG.ListView.BP_SetItemSelection
	// Flags: [Final|Native|Private|BlueprintCallable]
	// Offset: 0x104ca9b58
	// Return & Params: [ Num(2) Size(0x9) ]
	void BP_SetItemSelection(struct UObject* Item, bool bSelected);

	// Object: Function UMG.ListView.BP_SetDelayAddListItems
	// Flags: [Final|Native|Private|HasOutParms|BlueprintCallable]
	// Offset: 0x104ca9760
	// Return & Params: [ Num(1) Size(0x10) ]
	void BP_SetDelayAddListItems(struct TArray<struct UObject*>& InListItems);

	// Object: Function UMG.ListView.BP_ScrollItemIntoView
	// Flags: [Final|Native|Private|BlueprintCallable]
	// Offset: 0x104ca98d8
	// Return & Params: [ Num(1) Size(0x8) ]
	void BP_ScrollItemIntoView(struct UObject* Item);

	// Object: Function UMG.ListView.BP_NavigateToItem
	// Flags: [Final|Native|Private|BlueprintCallable]
	// Offset: 0x104ca9958
	// Return & Params: [ Num(1) Size(0x8) ]
	void BP_NavigateToItem(struct UObject* Item);

	// Object: Function UMG.ListView.BP_IsItemVisible
	// Flags: [Final|Native|Private|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ca99d8
	// Return & Params: [ Num(2) Size(0x9) ]
	bool BP_IsItemVisible(struct UObject* Item);

	// Object: Function UMG.ListView.BP_GetSelectedItems
	// Flags: [Final|Native|Private|HasOutParms|BlueprintCallable|Const]
	// Offset: 0x104ca9a68
	// Return & Params: [ Num(2) Size(0x11) ]
	bool BP_GetSelectedItems(struct TArray<struct UObject*>& Items);

	// Object: Function UMG.ListView.BP_GetSelectedItem
	// Flags: [Final|Native|Private|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ca97f8
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UObject* BP_GetSelectedItem();

	// Object: Function UMG.ListView.BP_GetNumItemsSelected
	// Flags: [Final|Native|Private|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ca9b10
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t BP_GetNumItemsSelected();

	// Object: Function UMG.ListView.BP_DoDelayAddTick
	// Flags: [Final|Native|Private|BlueprintCallable]
	// Offset: 0x104ca96e0
	// Return & Params: [ Num(1) Size(0x4) ]
	void BP_DoDelayAddTick(float DeltaTime);

	// Object: Function UMG.ListView.BP_ClearSelection
	// Flags: [Final|Native|Private|BlueprintCallable]
	// Offset: 0x104ca9b44
	// Return & Params: [ Num(0) Size(0x0) ]
	void BP_ClearSelection();

	// Object: Function UMG.ListView.BP_CancelScrollIntoView
	// Flags: [Final|Native|Private|BlueprintCallable]
	// Offset: 0x104ca98c4
	// Return & Params: [ Num(0) Size(0x0) ]
	void BP_CancelScrollIntoView();

	// Object: Function UMG.ListView.AddItem
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104caa0c8
	// Return & Params: [ Num(1) Size(0x8) ]
	void AddItem(struct UObject* Item);
};

// Object: Class UMG.PanelSlot
// Inherited Bytes: 0x28 | Struct Size: 0x38
struct UPanelSlot : UVisual {
	// Fields
	struct UPanelWidget* Parent; // Offset: 0x28 | Size: 0x8
	struct UWidget* Content; // Offset: 0x30 | Size: 0x8
};

// Object: Class UMG.RichTextBlock
// Inherited Bytes: 0x160 | Struct Size: 0xaa0
struct URichTextBlock : UTextLayoutWidget {
	// Fields
	struct FText Text; // Offset: 0x160 | Size: 0x18
	struct UDataTable* TextStyleSet; // Offset: 0x178 | Size: 0x8
	struct TArray<struct URichTextBlockDecorator*> DecoratorClasses; // Offset: 0x180 | Size: 0x10
	bool bOverrideDefaultStyle; // Offset: 0x190 | Size: 0x1
	char pad_0x191[0xf]; // Offset: 0x191 | Size: 0xf
	struct FTextBlockStyle DefaultTextStyleOverride; // Offset: 0x1a0 | Size: 0x460
	float MinDesiredWidth; // Offset: 0x600 | Size: 0x4
	enum class ETextTransformPolicy TextTransformPolicy; // Offset: 0x604 | Size: 0x1
	char pad_0x605[0xb]; // Offset: 0x605 | Size: 0xb
	struct FTextBlockStyle DefaultTextStyle; // Offset: 0x610 | Size: 0x460
	struct TArray<struct URichTextBlockDecorator*> InstanceDecorators; // Offset: 0xa70 | Size: 0x10
	char pad_0xA80[0x20]; // Offset: 0xa80 | Size: 0x20

	// Functions

	// Object: Function UMG.RichTextBlock.SetTextTransformPolicy
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cb5da4
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetTextTransformPolicy(enum class ETextTransformPolicy InTransformPolicy);

	// Object: Function UMG.RichTextBlock.SetTextStyleSet
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cb5aac
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetTextStyleSet(struct UDataTable* NewTextStyleSet);

	// Object: Function UMG.RichTextBlock.SetText
	// Flags: [Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104cb5b2c
	// Return & Params: [ Num(1) Size(0x18) ]
	void SetText(struct FText& InText);

	// Object: Function UMG.RichTextBlock.SetMinDesiredWidth
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cb5eac
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetMinDesiredWidth(float InMinDesiredWidth);

	// Object: Function UMG.RichTextBlock.SetDefaultTextStyle
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104cb5cd8
	// Return & Params: [ Num(1) Size(0x460) ]
	void SetDefaultTextStyle(struct FTextBlockStyle& InDefaultTextStyle);

	// Object: Function UMG.RichTextBlock.SetDefaultStrikeBrush
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104cb5f2c
	// Return & Params: [ Num(1) Size(0xe0) ]
	void SetDefaultStrikeBrush(struct FSlateBrush& InStrikeBrush);

	// Object: Function UMG.RichTextBlock.SetDefaultShadowOffset
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x104cb6308
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetDefaultShadowOffset(struct FVector2D InShadowOffset);

	// Object: Function UMG.RichTextBlock.SetDefaultShadowColorAndOpacity
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x104cb6384
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetDefaultShadowColorAndOpacity(struct FLinearColor InShadowColorAndOpacity);

	// Object: Function UMG.RichTextBlock.SetDefaultFont
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cb618c
	// Return & Params: [ Num(1) Size(0x60) ]
	void SetDefaultFont(struct FSlateFontInfo InFontInfo);

	// Object: Function UMG.RichTextBlock.SetDefaultColorAndOpacity
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cb6404
	// Return & Params: [ Num(1) Size(0x28) ]
	void SetDefaultColorAndOpacity(struct FSlateColor InColorAndOpacity);

	// Object: Function UMG.RichTextBlock.SetAutoWrapText
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cb5e24
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetAutoWrapText(bool InAutoTextWrap);

	// Object: Function UMG.RichTextBlock.GetText
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cb5c1c
	// Return & Params: [ Num(1) Size(0x18) ]
	struct FText GetText();

	// Object: Function UMG.RichTextBlock.GetDecoratorByClass
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cb5a1c
	// Return & Params: [ Num(2) Size(0x10) ]
	struct URichTextBlockDecorator* GetDecoratorByClass(struct URichTextBlockDecorator* DecoratorClass);

	// Object: Function UMG.RichTextBlock.ClearAllDefaultStyleOverrides
	// Flags: [Final|Native|Public]
	// Offset: 0x104cb5cc4
	// Return & Params: [ Num(0) Size(0x0) ]
	void ClearAllDefaultStyleOverrides();
};

// Object: Class UMG.TileView
// Inherited Bytes: 0xbf0 | Struct Size: 0xc10
struct UTileView : UListView {
	// Fields
	float EntryHeight; // Offset: 0xbec | Size: 0x4
	float EntryWidth; // Offset: 0xbf0 | Size: 0x4
	enum class EListItemAlignment TileAlignment; // Offset: 0xbf4 | Size: 0x1
	bool bWrapHorizontalNavigation; // Offset: 0xbf5 | Size: 0x1
	char pad_0xBFA[0x16]; // Offset: 0xbfa | Size: 0x16

	// Functions

	// Object: Function UMG.TileView.SetEntryWidth
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cc5a38
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetEntryWidth(float NewWidth);

	// Object: Function UMG.TileView.SetEntryHeight
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cc5ab8
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetEntryHeight(float NewHeight);
};

// Object: Class UMG.TreeView
// Inherited Bytes: 0xbf0 | Struct Size: 0xc50
struct UTreeView : UListView {
	// Fields
	char pad_0xBF0[0x10]; // Offset: 0xbf0 | Size: 0x10
	struct FDelegate BP_OnGetItemChildren; // Offset: 0xc00 | Size: 0x10
	struct FMulticastInlineDelegate BP_OnItemExpansionChanged; // Offset: 0xc10 | Size: 0x10
	char pad_0xC20[0x30]; // Offset: 0xc20 | Size: 0x30

	// Functions

	// Object: Function UMG.TreeView.SetItemExpansion
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cc5f38
	// Return & Params: [ Num(2) Size(0x9) ]
	void SetItemExpansion(struct UObject* Item, bool bExpandItem);

	// Object: Function UMG.TreeView.ExpandAll
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cc5f24
	// Return & Params: [ Num(0) Size(0x0) ]
	void ExpandAll();

	// Object: Function UMG.TreeView.CollapseAll
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cc5f10
	// Return & Params: [ Num(0) Size(0x0) ]
	void CollapseAll();
};

// Object: Class UMG.Overlay
// Inherited Bytes: 0x150 | Struct Size: 0x160
struct UOverlay : UPanelWidget {
	// Fields
	char pad_0x150[0x10]; // Offset: 0x150 | Size: 0x10

	// Functions

	// Object: Function UMG.Overlay.AddChildToOverlay
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cb045c
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UOverlaySlot* AddChildToOverlay(struct UWidget* Content);
};

// Object: Class UMG.OverlaySlot
// Inherited Bytes: 0x38 | Struct Size: 0x58
struct UOverlaySlot : UPanelSlot {
	// Fields
	char pad_0x38[0x8]; // Offset: 0x38 | Size: 0x8
	struct FMargin Padding; // Offset: 0x40 | Size: 0x10
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0x50 | Size: 0x1
	enum class EVerticalAlignment VerticalAlignment; // Offset: 0x51 | Size: 0x1
	char pad_0x52[0x6]; // Offset: 0x52 | Size: 0x6

	// Functions

	// Object: Function UMG.OverlaySlot.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cb08d0
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment);

	// Object: Function UMG.OverlaySlot.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cb09d0
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetPadding(struct FMargin InPadding);

	// Object: Function UMG.OverlaySlot.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cb0950
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment);
};

// Object: Class UMG.SizeBox
// Inherited Bytes: 0x150 | Struct Size: 0x188
struct USizeBox : UContentWidget {
	// Fields
	char pad_0x150[0x10]; // Offset: 0x150 | Size: 0x10
	float WidthOverride; // Offset: 0x160 | Size: 0x4
	float HeightOverride; // Offset: 0x164 | Size: 0x4
	float MinDesiredWidth; // Offset: 0x168 | Size: 0x4
	float MinDesiredHeight; // Offset: 0x16c | Size: 0x4
	float MaxDesiredWidth; // Offset: 0x170 | Size: 0x4
	float MaxDesiredHeight; // Offset: 0x174 | Size: 0x4
	float MinAspectRatio; // Offset: 0x178 | Size: 0x4
	float MaxAspectRatio; // Offset: 0x17c | Size: 0x4
	char bOverride_WidthOverride : 1; // Offset: 0x180 | Size: 0x1
	char bOverride_HeightOverride : 1; // Offset: 0x180 | Size: 0x1
	char bOverride_MinDesiredWidth : 1; // Offset: 0x180 | Size: 0x1
	char bOverride_MinDesiredHeight : 1; // Offset: 0x180 | Size: 0x1
	char bOverride_MaxDesiredWidth : 1; // Offset: 0x180 | Size: 0x1
	char bOverride_MaxDesiredHeight : 1; // Offset: 0x180 | Size: 0x1
	char bOverride_MinAspectRatio : 1; // Offset: 0x180 | Size: 0x1
	char bOverride_MaxAspectRatio : 1; // Offset: 0x180 | Size: 0x1
	char pad_0x181[0x7]; // Offset: 0x181 | Size: 0x7

	// Functions

	// Object: Function UMG.SizeBox.SetWidthOverride
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cba2a4
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetWidthOverride(float InWidthOverride);

	// Object: Function UMG.SizeBox.SetMinDesiredWidth
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cba17c
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetMinDesiredWidth(float InMinDesiredWidth);

	// Object: Function UMG.SizeBox.SetMinDesiredHeight
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cba0e8
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetMinDesiredHeight(float InMinDesiredHeight);

	// Object: Function UMG.SizeBox.SetMinAspectRatio
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cb9f2c
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetMinAspectRatio(float InMinAspectRatio);

	// Object: Function UMG.SizeBox.SetMaxDesiredWidth
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cba054
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetMaxDesiredWidth(float InMaxDesiredWidth);

	// Object: Function UMG.SizeBox.SetMaxDesiredHeight
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cb9fc0
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetMaxDesiredHeight(float InMaxDesiredHeight);

	// Object: Function UMG.SizeBox.SetMaxAspectRatio
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cb9eac
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetMaxAspectRatio(float InMaxAspectRatio);

	// Object: Function UMG.SizeBox.SetHeightOverride
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cba210
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetHeightOverride(float InHeightOverride);

	// Object: Function UMG.SizeBox.ClearWidthOverride
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cba290
	// Return & Params: [ Num(0) Size(0x0) ]
	void ClearWidthOverride();

	// Object: Function UMG.SizeBox.ClearMinDesiredWidth
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cba168
	// Return & Params: [ Num(0) Size(0x0) ]
	void ClearMinDesiredWidth();

	// Object: Function UMG.SizeBox.ClearMinDesiredHeight
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cba0d4
	// Return & Params: [ Num(0) Size(0x0) ]
	void ClearMinDesiredHeight();

	// Object: Function UMG.SizeBox.ClearMinAspectRatio
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cb9e98
	// Return & Params: [ Num(0) Size(0x0) ]
	void ClearMinAspectRatio();

	// Object: Function UMG.SizeBox.ClearMaxDesiredWidth
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cba040
	// Return & Params: [ Num(0) Size(0x0) ]
	void ClearMaxDesiredWidth();

	// Object: Function UMG.SizeBox.ClearMaxDesiredHeight
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cb9fac
	// Return & Params: [ Num(0) Size(0x0) ]
	void ClearMaxDesiredHeight();

	// Object: Function UMG.SizeBox.ClearMaxAspectRatio
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cb9e84
	// Return & Params: [ Num(0) Size(0x0) ]
	void ClearMaxAspectRatio();

	// Object: Function UMG.SizeBox.ClearHeightOverride
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cba1fc
	// Return & Params: [ Num(0) Size(0x0) ]
	void ClearHeightOverride();
};

// Object: Class UMG.NamedSlot
// Inherited Bytes: 0x150 | Struct Size: 0x160
struct UNamedSlot : UContentWidget {
	// Fields
	char pad_0x150[0x10]; // Offset: 0x150 | Size: 0x10
};

// Object: Class UMG.CanvasPanel
// Inherited Bytes: 0x150 | Struct Size: 0x160
struct UCanvasPanel : UPanelWidget {
	// Fields
	int32_t ReservedLayerSpace; // Offset: 0x14c | Size: 0x4
	char pad_0x154[0xc]; // Offset: 0x154 | Size: 0xc

	// Functions

	// Object: Function UMG.CanvasPanel.AddChildToCanvas
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c9a7f4
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UCanvasPanelSlot* AddChildToCanvas(struct UWidget* Content);
};

// Object: Class UMG.RichTextBlockDecorator
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct URichTextBlockDecorator : UObject {
};

// Object: Class UMG.CheckBox
// Inherited Bytes: 0x150 | Struct Size: 0xad0
struct UCheckBox : UContentWidget {
	// Fields
	enum class ECheckBoxState CheckedState; // Offset: 0x149 | Size: 0x1
	struct FDelegate CheckedStateDelegate; // Offset: 0x14c | Size: 0x10
	struct FCheckBoxStyle WidgetStyle; // Offset: 0x160 | Size: 0x8a0
	struct USlateWidgetStyleAsset* Style; // Offset: 0xa00 | Size: 0x8
	struct USlateBrushAsset* UncheckedImage; // Offset: 0xa08 | Size: 0x8
	struct USlateBrushAsset* UncheckedHoveredImage; // Offset: 0xa10 | Size: 0x8
	struct USlateBrushAsset* UncheckedPressedImage; // Offset: 0xa18 | Size: 0x8
	struct USlateBrushAsset* CheckedImage; // Offset: 0xa20 | Size: 0x8
	struct USlateBrushAsset* CheckedHoveredImage; // Offset: 0xa28 | Size: 0x8
	struct USlateBrushAsset* CheckedPressedImage; // Offset: 0xa30 | Size: 0x8
	struct USlateBrushAsset* UndeterminedImage; // Offset: 0xa38 | Size: 0x8
	struct USlateBrushAsset* UndeterminedHoveredImage; // Offset: 0xa40 | Size: 0x8
	struct USlateBrushAsset* UndeterminedPressedImage; // Offset: 0xa48 | Size: 0x8
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0xa50 | Size: 0x1
	char pad_0xA52[0x2]; // Offset: 0xa52 | Size: 0x2
	struct FMargin Padding; // Offset: 0xa54 | Size: 0x10
	char pad_0xA64[0x4]; // Offset: 0xa64 | Size: 0x4
	struct FSlateColor BorderBackgroundColor; // Offset: 0xa68 | Size: 0x28
	enum class EButtonClickMethod ClickMethod; // Offset: 0xa90 | Size: 0x1
	enum class EButtonTouchMethod TouchMethod; // Offset: 0xa91 | Size: 0x1
	enum class EButtonPressMethod PressMethod; // Offset: 0xa92 | Size: 0x1
	bool IsFocusable; // Offset: 0xa93 | Size: 0x1
	char pad_0xA94[0x4]; // Offset: 0xa94 | Size: 0x4
	struct FMulticastInlineDelegate OnCheckStateChanged; // Offset: 0xa98 | Size: 0x10
	struct FSoftObjectPath OnClickedSound; // Offset: 0xaa8 | Size: 0x18
	char pad_0xAC0[0x10]; // Offset: 0xac0 | Size: 0x10

	// Functions

	// Object: Function UMG.CheckBox.SetTouchMethod
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c9bccc
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetTouchMethod(enum class EButtonTouchMethod InTouchMethod);

	// Object: Function UMG.CheckBox.SetPressMethod
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c9bc4c
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetPressMethod(enum class EButtonPressMethod InPressMethod);

	// Object: Function UMG.CheckBox.SetIsChecked
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c9be4c
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetIsChecked(bool InIsChecked);

	// Object: Function UMG.CheckBox.SetClickMethod
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c9bd4c
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetClickMethod(enum class EButtonClickMethod InClickMethod);

	// Object: Function UMG.CheckBox.SetCheckedState
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c9bdcc
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetCheckedState(enum class ECheckBoxState InCheckedState);

	// Object: Function UMG.CheckBox.IsPressed
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c9bf3c
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsPressed();

	// Object: Function UMG.CheckBox.IsChecked
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c9bf08
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsChecked();

	// Object: Function UMG.CheckBox.GetCheckedState
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c9bed4
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class ECheckBoxState GetCheckedState();
};

// Object: Class UMG.DragDropOperation
// Inherited Bytes: 0x28 | Struct Size: 0x88
struct UDragDropOperation : UObject {
	// Fields
	struct FString Tag; // Offset: 0x28 | Size: 0x10
	struct UObject* Payload; // Offset: 0x38 | Size: 0x8
	struct UWidget* DefaultDragVisual; // Offset: 0x40 | Size: 0x8
	enum class EDragPivot Pivot; // Offset: 0x48 | Size: 0x1
	char pad_0x49[0x3]; // Offset: 0x49 | Size: 0x3
	struct FVector2D Offset; // Offset: 0x4c | Size: 0x8
	char pad_0x54[0x4]; // Offset: 0x54 | Size: 0x4
	struct FMulticastInlineDelegate OnDrop; // Offset: 0x58 | Size: 0x10
	struct FMulticastInlineDelegate OnDragCancelled; // Offset: 0x68 | Size: 0x10
	struct FMulticastInlineDelegate OnDragged; // Offset: 0x78 | Size: 0x10

	// Functions

	// Object: Function UMG.DragDropOperation.Drop
	// Flags: [Native|Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x104c9fdbc
	// Return & Params: [ Num(1) Size(0x70) ]
	void Drop(struct FPointerEvent& PointerEvent);

	// Object: Function UMG.DragDropOperation.Dragged
	// Flags: [Native|Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x104c9fb2c
	// Return & Params: [ Num(1) Size(0x70) ]
	void Dragged(struct FPointerEvent& PointerEvent);

	// Object: Function UMG.DragDropOperation.DragCancelled
	// Flags: [Native|Event|Public|HasOutParms|BlueprintEvent]
	// Offset: 0x104c9fc74
	// Return & Params: [ Num(1) Size(0x70) ]
	void DragCancelled(struct FPointerEvent& PointerEvent);
};

// Object: Class UMG.WidgetComponent
// Inherited Bytes: 0x5e0 | Struct Size: 0x700
struct UWidgetComponent : UMeshComponent {
	// Fields
	enum class EWidgetSpace Space; // Offset: 0x5d9 | Size: 0x1
	enum class EWidgetTimingPolicy TimingPolicy; // Offset: 0x5da | Size: 0x1
	struct UUserWidget* WidgetClass; // Offset: 0x5e0 | Size: 0x8
	struct FIntPoint DrawSize; // Offset: 0x5e8 | Size: 0x8
	bool bManuallyRedraw; // Offset: 0x5f0 | Size: 0x1
	bool bRedrawRequested; // Offset: 0x5f1 | Size: 0x1
	float RedrawTime; // Offset: 0x5f4 | Size: 0x4
	char pad_0x5F8[0x8]; // Offset: 0x5f8 | Size: 0x8
	struct FIntPoint CurrentDrawSize; // Offset: 0x600 | Size: 0x8
	bool bDrawAtDesiredSize; // Offset: 0x608 | Size: 0x1
	char pad_0x609[0x3]; // Offset: 0x609 | Size: 0x3
	struct FVector2D Pivot; // Offset: 0x60c | Size: 0x8
	bool bReceiveHardwareInput; // Offset: 0x614 | Size: 0x1
	bool bWindowFocusable; // Offset: 0x615 | Size: 0x1
	enum class EWindowVisibility WindowVisibility; // Offset: 0x616 | Size: 0x1
	bool bApplyGammaCorrection; // Offset: 0x617 | Size: 0x1
	struct ULocalPlayer* OwnerPlayer; // Offset: 0x618 | Size: 0x8
	struct FLinearColor BackgroundColor; // Offset: 0x620 | Size: 0x10
	struct FLinearColor TintColorAndOpacity; // Offset: 0x630 | Size: 0x10
	float OpacityFromTexture; // Offset: 0x640 | Size: 0x4
	enum class EWidgetBlendMode BlendMode; // Offset: 0x644 | Size: 0x1
	bool bIsTwoSided; // Offset: 0x645 | Size: 0x1
	bool TickWhenOffscreen; // Offset: 0x646 | Size: 0x1
	char pad_0x647[0x1]; // Offset: 0x647 | Size: 0x1
	struct UUserWidget* Widget; // Offset: 0x648 | Size: 0x8
	char pad_0x650[0x20]; // Offset: 0x650 | Size: 0x20
	struct UBodySetup* BodySetup; // Offset: 0x670 | Size: 0x8
	struct UMaterialInterface* TranslucentMaterial; // Offset: 0x678 | Size: 0x8
	struct UMaterialInterface* TranslucentMaterial_OneSided; // Offset: 0x680 | Size: 0x8
	struct UMaterialInterface* OpaqueMaterial; // Offset: 0x688 | Size: 0x8
	struct UMaterialInterface* OpaqueMaterial_OneSided; // Offset: 0x690 | Size: 0x8
	struct UMaterialInterface* MaskedMaterial; // Offset: 0x698 | Size: 0x8
	struct UMaterialInterface* MaskedMaterial_OneSided; // Offset: 0x6a0 | Size: 0x8
	struct UTextureRenderTarget2D* RenderTarget; // Offset: 0x6a8 | Size: 0x8
	struct UMaterialInstanceDynamic* MaterialInstance; // Offset: 0x6b0 | Size: 0x8
	bool bAddedToScreen; // Offset: 0x6b8 | Size: 0x1
	bool bEditTimeUsable; // Offset: 0x6b9 | Size: 0x1
	char pad_0x6BA[0x2]; // Offset: 0x6ba | Size: 0x2
	struct FName SharedLayerName; // Offset: 0x6bc | Size: 0x8
	int32_t LayerZOrder; // Offset: 0x6c4 | Size: 0x4
	enum class EWidgetGeometryMode GeometryMode; // Offset: 0x6c8 | Size: 0x1
	char pad_0x6C9[0x3]; // Offset: 0x6c9 | Size: 0x3
	float CylinderArcAngle; // Offset: 0x6cc | Size: 0x4
	char pad_0x6D0[0x30]; // Offset: 0x6d0 | Size: 0x30

	// Functions

	// Object: Function UMG.WidgetComponent.SetWindowVisibility
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cdf3a4
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetWindowVisibility(enum class EWindowVisibility InVisibility);

	// Object: Function UMG.WidgetComponent.SetWindowFocusable
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cdf440
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetWindowFocusable(bool bInWindowFocusable);

	// Object: Function UMG.WidgetComponent.SetWidgetSpace
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cdf614
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetWidgetSpace(enum class EWidgetSpace NewSpace);

	// Object: Function UMG.WidgetComponent.SetWidget
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104cdfd34
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetWidget(struct UUserWidget* Widget);

	// Object: Function UMG.WidgetComponent.SetTwoSided
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cdfa30
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetTwoSided(bool bWantTwoSided);

	// Object: Function UMG.WidgetComponent.SetTintColorAndOpacity
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x104cdf890
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetTintColorAndOpacity(struct FLinearColor NewTintColorAndOpacity);

	// Object: Function UMG.WidgetComponent.SetTickWhenOffscreen
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cdf990
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetTickWhenOffscreen(bool bWantTickWhenOffscreen);

	// Object: Function UMG.WidgetComponent.SetRedrawTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cdf6ac
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetRedrawTime(float InRedrawTime);

	// Object: Function UMG.WidgetComponent.SetPivot
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x104cdf7e4
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetPivot(struct FVector2D& InPivot);

	// Object: Function UMG.WidgetComponent.SetOwnerPlayer
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cdfcb4
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetOwnerPlayer(struct ULocalPlayer* LocalPlayer);

	// Object: Function UMG.WidgetComponent.SetManuallyRedraw
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cdfc10
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetManuallyRedraw(bool bUseManualRedraw);

	// Object: Function UMG.WidgetComponent.SetGeometryMode
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cdf57c
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetGeometryMode(enum class EWidgetGeometryMode InGeometryMode);

	// Object: Function UMG.WidgetComponent.SetDrawSize
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x104cdfaf0
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetDrawSize(struct FVector2D Size);

	// Object: Function UMG.WidgetComponent.SetDrawAtDesiredSize
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cdf744
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetDrawAtDesiredSize(bool bInDrawAtDesiredSize);

	// Object: Function UMG.WidgetComponent.SetCylinderArcAngle
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cdf4e4
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetCylinderArcAngle(float InCylinderArcAngle);

	// Object: Function UMG.WidgetComponent.SetBackgroundColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x104cdf910
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetBackgroundColor(struct FLinearColor NewBackgroundColor);

	// Object: Function UMG.WidgetComponent.RequestRedraw
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104cdfad4
	// Return & Params: [ Num(0) Size(0x0) ]
	void RequestRedraw();

	// Object: Function UMG.WidgetComponent.GetWindowVisiblility
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cdf424
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class EWindowVisibility GetWindowVisiblility();

	// Object: Function UMG.WidgetComponent.GetWindowFocusable
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cdf4c8
	// Return & Params: [ Num(1) Size(0x1) ]
	bool GetWindowFocusable();

	// Object: Function UMG.WidgetComponent.GetWidgetSpace
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cdf690
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class EWidgetSpace GetWidgetSpace();

	// Object: Function UMG.WidgetComponent.GetUserWidgetObject
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cdfe24
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UUserWidget* GetUserWidgetObject();

	// Object: Function UMG.WidgetComponent.GetTwoSided
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cdfab8
	// Return & Params: [ Num(1) Size(0x1) ]
	bool GetTwoSided();

	// Object: Function UMG.WidgetComponent.GetTickWhenOffscreen
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cdfa14
	// Return & Params: [ Num(1) Size(0x1) ]
	bool GetTickWhenOffscreen();

	// Object: Function UMG.WidgetComponent.GetRenderTarget
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cdfdf0
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UTextureRenderTarget2D* GetRenderTarget();

	// Object: Function UMG.WidgetComponent.GetRedrawTime
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cdf728
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetRedrawTime();

	// Object: Function UMG.WidgetComponent.GetPivot
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cdf870
	// Return & Params: [ Num(1) Size(0x8) ]
	struct FVector2D GetPivot();

	// Object: Function UMG.WidgetComponent.GetOwnerPlayer
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cdfbdc
	// Return & Params: [ Num(1) Size(0x8) ]
	struct ULocalPlayer* GetOwnerPlayer();

	// Object: Function UMG.WidgetComponent.GetMaterialInstance
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cdfdbc
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UMaterialInstanceDynamic* GetMaterialInstance();

	// Object: Function UMG.WidgetComponent.GetManuallyRedraw
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cdfc98
	// Return & Params: [ Num(1) Size(0x1) ]
	bool GetManuallyRedraw();

	// Object: Function UMG.WidgetComponent.GetGeometryMode
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cdf5f8
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class EWidgetGeometryMode GetGeometryMode();

	// Object: Function UMG.WidgetComponent.GetDrawSize
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cdfba4
	// Return & Params: [ Num(1) Size(0x8) ]
	struct FVector2D GetDrawSize();

	// Object: Function UMG.WidgetComponent.GetDrawAtDesiredSize
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cdf7c8
	// Return & Params: [ Num(1) Size(0x1) ]
	bool GetDrawAtDesiredSize();

	// Object: Function UMG.WidgetComponent.GetCylinderArcAngle
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cdf560
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetCylinderArcAngle();

	// Object: Function UMG.WidgetComponent.GetCurrentDrawSize
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cdfb6c
	// Return & Params: [ Num(1) Size(0x8) ]
	struct FVector2D GetCurrentDrawSize();
};

// Object: Class UMG.AsyncTaskDownloadImage
// Inherited Bytes: 0x30 | Struct Size: 0x50
struct UAsyncTaskDownloadImage : UBlueprintAsyncActionBase {
	// Fields
	struct FMulticastInlineDelegate OnSuccess; // Offset: 0x30 | Size: 0x10
	struct FMulticastInlineDelegate OnFail; // Offset: 0x40 | Size: 0x10

	// Functions

	// Object: Function UMG.AsyncTaskDownloadImage.DownloadImage
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104c96bfc
	// Return & Params: [ Num(2) Size(0x18) ]
	struct UAsyncTaskDownloadImage* DownloadImage(struct FString URL);
};

// Object: Class UMG.BackgroundBlur
// Inherited Bytes: 0x150 | Struct Size: 0x270
struct UBackgroundBlur : UContentWidget {
	// Fields
	struct FMargin Padding; // Offset: 0x14c | Size: 0x10
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0x15c | Size: 0x1
	enum class EVerticalAlignment VerticalAlignment; // Offset: 0x15d | Size: 0x1
	bool bBlurOnce; // Offset: 0x15e | Size: 0x1
	bool bBlurState; // Offset: 0x15f | Size: 0x1
	bool bApplyAlphaToBlur; // Offset: 0x160 | Size: 0x1
	float BlurStrength; // Offset: 0x164 | Size: 0x4
	bool bOverrideAutoRadiusCalculation; // Offset: 0x168 | Size: 0x1
	char pad_0x16A[0x2]; // Offset: 0x16a | Size: 0x2
	int32_t BlurRadius; // Offset: 0x16c | Size: 0x4
	struct FSlateBrush LowQualityFallbackBrush; // Offset: 0x170 | Size: 0xe0
	char pad_0x250[0x20]; // Offset: 0x250 | Size: 0x20

	// Functions

	// Object: Function UMG.BackgroundBlur.StopOnFirstBlur
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c97084
	// Return & Params: [ Num(0) Size(0x0) ]
	void StopOnFirstBlur();

	// Object: Function UMG.BackgroundBlur.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c97570
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment);

	// Object: Function UMG.BackgroundBlur.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c97670
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetPadding(struct FMargin InPadding);

	// Object: Function UMG.BackgroundBlur.SetLowQualityFallbackBrush
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104c97180
	// Return & Params: [ Num(1) Size(0xe0) ]
	void SetLowQualityFallbackBrush(struct FSlateBrush& InBrush);

	// Object: Function UMG.BackgroundBlur.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c975f0
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment);

	// Object: Function UMG.BackgroundBlur.SetBlurStrength
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104c973e0
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetBlurStrength(float InStrength);

	// Object: Function UMG.BackgroundBlur.SetBlurState
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c97098
	// Return & Params: [ Num(2) Size(0x2) ]
	void SetBlurState(bool BlurState, bool RefreshCount);

	// Object: Function UMG.BackgroundBlur.SetBlurRadius
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c97468
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetBlurRadius(int32_t InBlurRadius);

	// Object: Function UMG.BackgroundBlur.SetApplyAlphaToBlur
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c974e8
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetApplyAlphaToBlur(bool bInApplyAlphaToBlur);
};

// Object: Class UMG.BackgroundBlurSlot
// Inherited Bytes: 0x38 | Struct Size: 0x60
struct UBackgroundBlurSlot : UPanelSlot {
	// Fields
	struct FMargin Padding; // Offset: 0x38 | Size: 0x10
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0x48 | Size: 0x1
	enum class EVerticalAlignment VerticalAlignment; // Offset: 0x49 | Size: 0x1
	char pad_0x4A[0x16]; // Offset: 0x4a | Size: 0x16

	// Functions

	// Object: Function UMG.BackgroundBlurSlot.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c97bd4
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment);

	// Object: Function UMG.BackgroundBlurSlot.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c97cd4
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetPadding(struct FMargin InPadding);

	// Object: Function UMG.BackgroundBlurSlot.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c97c54
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment);
};

// Object: Class UMG.PropertyBinding
// Inherited Bytes: 0x28 | Struct Size: 0x60
struct UPropertyBinding : UObject {
	// Fields
	struct TWeakObjectPtr<struct UObject> SourceObject; // Offset: 0x28 | Size: 0x8
	struct FDynamicPropertyPath SourcePath; // Offset: 0x30 | Size: 0x28
	struct FName DestinationProperty; // Offset: 0x58 | Size: 0x8
};

// Object: Class UMG.BoolBinding
// Inherited Bytes: 0x60 | Struct Size: 0x60
struct UBoolBinding : UPropertyBinding {
	// Functions

	// Object: Function UMG.BoolBinding.GetValue
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x104c980cc
	// Return & Params: [ Num(1) Size(0x1) ]
	bool GetValue();
};

// Object: Class UMG.BorderSlot
// Inherited Bytes: 0x38 | Struct Size: 0x60
struct UBorderSlot : UPanelSlot {
	// Fields
	struct FMargin Padding; // Offset: 0x38 | Size: 0x10
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0x48 | Size: 0x1
	enum class EVerticalAlignment VerticalAlignment; // Offset: 0x49 | Size: 0x1
	char pad_0x4A[0x16]; // Offset: 0x4a | Size: 0x16

	// Functions

	// Object: Function UMG.BorderSlot.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c99030
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment);

	// Object: Function UMG.BorderSlot.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c99130
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetPadding(struct FMargin InPadding);

	// Object: Function UMG.BorderSlot.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c990b0
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment);
};

// Object: Class UMG.BrushBinding
// Inherited Bytes: 0x60 | Struct Size: 0x68
struct UBrushBinding : UPropertyBinding {
	// Fields
	char pad_0x60[0x8]; // Offset: 0x60 | Size: 0x8

	// Functions

	// Object: Function UMG.BrushBinding.GetValue
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x104c995e4
	// Return & Params: [ Num(1) Size(0xe0) ]
	struct FSlateBrush GetValue();
};

// Object: Class UMG.ButtonSlot
// Inherited Bytes: 0x38 | Struct Size: 0x60
struct UButtonSlot : UPanelSlot {
	// Fields
	struct FMargin Padding; // Offset: 0x38 | Size: 0x10
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0x48 | Size: 0x1
	enum class EVerticalAlignment VerticalAlignment; // Offset: 0x49 | Size: 0x1
	char pad_0x4A[0x16]; // Offset: 0x4a | Size: 0x16

	// Functions

	// Object: Function UMG.ButtonSlot.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c9a2fc
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment);

	// Object: Function UMG.ButtonSlot.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c9a3fc
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetPadding(struct FMargin InPadding);

	// Object: Function UMG.ButtonSlot.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c9a37c
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment);
};

// Object: Class UMG.CanvasPanelSlot
// Inherited Bytes: 0x38 | Struct Size: 0x78
struct UCanvasPanelSlot : UPanelSlot {
	// Fields
	struct FAnchorData LayoutData; // Offset: 0x38 | Size: 0x2c
	bool bAutoSize; // Offset: 0x64 | Size: 0x1
	char pad_0x65[0x3]; // Offset: 0x65 | Size: 0x3
	int32_t ZOrder; // Offset: 0x68 | Size: 0x4
	char pad_0x6C[0xc]; // Offset: 0x6c | Size: 0xc

	// Functions

	// Object: Function UMG.CanvasPanelSlot.SetZOrder
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c9ae2c
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetZOrder(int32_t InZOrder);

	// Object: Function UMG.CanvasPanelSlot.SetSize
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x104c9b1dc
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetSize(struct FVector2D InSize);

	// Object: Function UMG.CanvasPanelSlot.SetPosition
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x104c9b290
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetPosition(struct FVector2D InPosition);

	// Object: Function UMG.CanvasPanelSlot.SetOffsets
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c9b120
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetOffsets(struct FMargin InOffset);

	// Object: Function UMG.CanvasPanelSlot.SetMinimum
	// Flags: [Final|Native|Public|HasDefaults]
	// Offset: 0x104c9ad7c
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetMinimum(struct FVector2D InMinimumAnchors);

	// Object: Function UMG.CanvasPanelSlot.SetMaximum
	// Flags: [Final|Native|Public|HasDefaults]
	// Offset: 0x104c9ad00
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetMaximum(struct FVector2D InMaximumAnchors);

	// Object: Function UMG.CanvasPanelSlot.SetLayout
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104c9b358
	// Return & Params: [ Num(1) Size(0x2c) ]
	void SetLayout(struct FAnchorData& InLayoutData);

	// Object: Function UMG.CanvasPanelSlot.SetAutoSize
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c9aee0
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetAutoSize(bool InbAutoSize);

	// Object: Function UMG.CanvasPanelSlot.SetAnchors
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c9b05c
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetAnchors(struct FAnchors InAnchors);

	// Object: Function UMG.CanvasPanelSlot.SetAlignment
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x104c9afa0
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetAlignment(struct FVector2D InAlignment);

	// Object: Function UMG.CanvasPanelSlot.GetZOrder
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c9adf8
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetZOrder();

	// Object: Function UMG.CanvasPanelSlot.GetSize
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c9b1a4
	// Return & Params: [ Num(1) Size(0x8) ]
	struct FVector2D GetSize();

	// Object: Function UMG.CanvasPanelSlot.GetPosition
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c9b258
	// Return & Params: [ Num(1) Size(0x8) ]
	struct FVector2D GetPosition();

	// Object: Function UMG.CanvasPanelSlot.GetOffsets
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c9b0e0
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FMargin GetOffsets();

	// Object: Function UMG.CanvasPanelSlot.GetLayout
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c9b30c
	// Return & Params: [ Num(1) Size(0x2c) ]
	struct FAnchorData GetLayout();

	// Object: Function UMG.CanvasPanelSlot.GetAutoSize
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c9aeac
	// Return & Params: [ Num(1) Size(0x1) ]
	bool GetAutoSize();

	// Object: Function UMG.CanvasPanelSlot.GetAnchors
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c9b01c
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FAnchors GetAnchors();

	// Object: Function UMG.CanvasPanelSlot.GetAlignment
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c9af68
	// Return & Params: [ Num(1) Size(0x8) ]
	struct FVector2D GetAlignment();
};

// Object: Class UMG.CheckedStateBinding
// Inherited Bytes: 0x60 | Struct Size: 0x68
struct UCheckedStateBinding : UPropertyBinding {
	// Fields
	char pad_0x60[0x8]; // Offset: 0x60 | Size: 0x8

	// Functions

	// Object: Function UMG.CheckedStateBinding.GetValue
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x104c9c490
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class ECheckBoxState GetValue();
};

// Object: Class UMG.CircularThrobber
// Inherited Bytes: 0x138 | Struct Size: 0x250
struct UCircularThrobber : UWidget {
	// Fields
	int32_t NumberOfPieces; // Offset: 0x138 | Size: 0x4
	float Period; // Offset: 0x13c | Size: 0x4
	float Radius; // Offset: 0x140 | Size: 0x4
	char pad_0x144[0x4]; // Offset: 0x144 | Size: 0x4
	struct USlateBrushAsset* PieceImage; // Offset: 0x148 | Size: 0x8
	struct FSlateBrush Image; // Offset: 0x150 | Size: 0xe0
	bool bEnableRadius; // Offset: 0x230 | Size: 0x1
	char pad_0x231[0x1f]; // Offset: 0x231 | Size: 0x1f

	// Functions

	// Object: Function UMG.CircularThrobber.SetRadius
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c9c6e0
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetRadius(float InRadius);

	// Object: Function UMG.CircularThrobber.SetPeriod
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c9c760
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetPeriod(float InPeriod);

	// Object: Function UMG.CircularThrobber.SetNumberOfPieces
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c9c7e0
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetNumberOfPieces(int32_t InNumberOfPieces);
};

// Object: Class UMG.ColorBinding
// Inherited Bytes: 0x60 | Struct Size: 0x68
struct UColorBinding : UPropertyBinding {
	// Fields
	char pad_0x60[0x8]; // Offset: 0x60 | Size: 0x8

	// Functions

	// Object: Function UMG.ColorBinding.GetSlateValue
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x104c9e468
	// Return & Params: [ Num(1) Size(0x28) ]
	struct FSlateColor GetSlateValue();

	// Object: Function UMG.ColorBinding.GetLinearValue
	// Flags: [Final|Native|Public|HasDefaults|Const]
	// Offset: 0x104c9e428
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FLinearColor GetLinearValue();
};

// Object: Class UMG.ComboBox
// Inherited Bytes: 0x138 | Struct Size: 0x170
struct UComboBox : UWidget {
	// Fields
	struct TArray<struct UObject*> Items; // Offset: 0x138 | Size: 0x10
	struct FDelegate OnGenerateWidgetEvent; // Offset: 0x148 | Size: 0x10
	bool bIsFocusable; // Offset: 0x158 | Size: 0x1
	char pad_0x159[0x17]; // Offset: 0x159 | Size: 0x17
};

// Object: Class UMG.ComboBoxString
// Inherited Bytes: 0x138 | Struct Size: 0x1550
struct UComboBoxString : UWidget {
	// Fields
	struct TArray<struct FString> DefaultOptions; // Offset: 0x138 | Size: 0x10
	struct FString SelectedOption; // Offset: 0x148 | Size: 0x10
	char pad_0x158[0x8]; // Offset: 0x158 | Size: 0x8
	struct FComboBoxStyle WidgetStyle; // Offset: 0x160 | Size: 0x620
	struct FTableRowStyle ItemStyle; // Offset: 0x780 | Size: 0xca0
	struct FMargin ContentPadding; // Offset: 0x1420 | Size: 0x10
	float MaxListHeight; // Offset: 0x1430 | Size: 0x4
	bool HasDownArrow; // Offset: 0x1434 | Size: 0x1
	bool EnableGamepadNavigationMode; // Offset: 0x1435 | Size: 0x1
	char pad_0x1436[0x2]; // Offset: 0x1436 | Size: 0x2
	struct FSlateFontInfo Font; // Offset: 0x1438 | Size: 0x60
	struct FSlateColor ForegroundColor; // Offset: 0x1498 | Size: 0x28
	bool bIsFocusable; // Offset: 0x14c0 | Size: 0x1
	char pad_0x14C1[0x3]; // Offset: 0x14c1 | Size: 0x3
	struct FDelegate OnGenerateWidgetEvent; // Offset: 0x14c4 | Size: 0x10
	char pad_0x14D4[0x4]; // Offset: 0x14d4 | Size: 0x4
	struct FMulticastInlineDelegate OnSelectionChanged; // Offset: 0x14d8 | Size: 0x10
	struct FMulticastInlineDelegate OnOpening; // Offset: 0x14e8 | Size: 0x10
	char pad_0x14F8[0x58]; // Offset: 0x14f8 | Size: 0x58

	// Functions

	// Object: Function UMG.ComboBoxString.SetSelectedOption
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c9eb98
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetSelectedOption(struct FString Option);

	// Object: Function UMG.ComboBoxString.SetSelectedIndex
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c9eb18
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetSelectedIndex(int32_t Index);

	// Object: Function UMG.ComboBoxString.RemoveOption
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c9ee38
	// Return & Params: [ Num(2) Size(0x11) ]
	bool RemoveOption(struct FString Option);

	// Object: Function UMG.ComboBoxString.RefreshOptions
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c9ec88
	// Return & Params: [ Num(0) Size(0x0) ]
	void RefreshOptions();

	// Object: DelegateFunction UMG.ComboBoxString.OnSelectionChangedEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x11) ]
	void OnSelectionChangedEvent__DelegateSignature(struct FString SelectedItem, enum class ESelectInfo SelectionType);

	// Object: DelegateFunction UMG.ComboBoxString.OnOpeningEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnOpeningEvent__DelegateSignature();

	// Object: Function UMG.ComboBoxString.IsOpen
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c9e9fc
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsOpen();

	// Object: Function UMG.ComboBoxString.GetSelectedOption
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c9ea98
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetSelectedOption();

	// Object: Function UMG.ComboBoxString.GetSelectedIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c9ea64
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetSelectedIndex();

	// Object: Function UMG.ComboBoxString.GetOptionCount
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c9ea30
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetOptionCount();

	// Object: Function UMG.ComboBoxString.GetOptionAtIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c9ecc4
	// Return & Params: [ Num(2) Size(0x18) ]
	struct FString GetOptionAtIndex(int32_t Index);

	// Object: Function UMG.ComboBoxString.FindOptionIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104c9ed9c
	// Return & Params: [ Num(2) Size(0x14) ]
	int32_t FindOptionIndex(struct FString Option);

	// Object: Function UMG.ComboBoxString.ClearSelection
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c9ec9c
	// Return & Params: [ Num(0) Size(0x0) ]
	void ClearSelection();

	// Object: Function UMG.ComboBoxString.ClearOptions
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c9ecb0
	// Return & Params: [ Num(0) Size(0x0) ]
	void ClearOptions();

	// Object: Function UMG.ComboBoxString.AddOption
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104c9eed4
	// Return & Params: [ Num(1) Size(0x10) ]
	void AddOption(struct FString Option);
};

// Object: Class UMG.DynamicEntryBox
// Inherited Bytes: 0x1f8 | Struct Size: 0x200
struct UDynamicEntryBox : UDynamicEntryBoxBase {
	// Fields
	struct UUserWidget* EntryWidgetClass; // Offset: 0x1f8 | Size: 0x8

	// Functions

	// Object: Function UMG.DynamicEntryBox.Reset
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ca05f0
	// Return & Params: [ Num(1) Size(0x1) ]
	void Reset(bool bDeleteWidgets);

	// Object: Function UMG.DynamicEntryBox.RemoveEntry
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ca0570
	// Return & Params: [ Num(1) Size(0x8) ]
	void RemoveEntry(struct UUserWidget* EntryWidget);

	// Object: Function UMG.DynamicEntryBox.BP_CreateEntryOfClass
	// Flags: [Final|Native|Private|BlueprintCallable]
	// Offset: 0x104ca04ac
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UUserWidget* BP_CreateEntryOfClass(struct UUserWidget* EntryClass);

	// Object: Function UMG.DynamicEntryBox.BP_CreateEntry
	// Flags: [Final|Native|Private|BlueprintCallable]
	// Offset: 0x104ca053c
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UUserWidget* BP_CreateEntry();
};

// Object: Class UMG.EditableText
// Inherited Bytes: 0x138 | Struct Size: 0x5f0
struct UEditableText : UWidget {
	// Fields
	struct FText Text; // Offset: 0x138 | Size: 0x18
	struct FDelegate TextDelegate; // Offset: 0x150 | Size: 0x10
	struct FText HintText; // Offset: 0x160 | Size: 0x18
	struct FDelegate HintTextDelegate; // Offset: 0x178 | Size: 0x10
	char pad_0x188[0x8]; // Offset: 0x188 | Size: 0x8
	struct FEditableTextStyle WidgetStyle; // Offset: 0x190 | Size: 0x330
	struct USlateWidgetStyleAsset* Style; // Offset: 0x4c0 | Size: 0x8
	struct USlateBrushAsset* BackgroundImageSelected; // Offset: 0x4c8 | Size: 0x8
	struct USlateBrushAsset* BackgroundImageComposing; // Offset: 0x4d0 | Size: 0x8
	struct USlateBrushAsset* CaretImage; // Offset: 0x4d8 | Size: 0x8
	struct FSlateFontInfo Font; // Offset: 0x4e0 | Size: 0x60
	struct FSlateColor ColorAndOpacity; // Offset: 0x540 | Size: 0x28
	bool IsReadOnly; // Offset: 0x568 | Size: 0x1
	bool IsPassword; // Offset: 0x569 | Size: 0x1
	char pad_0x56A[0x2]; // Offset: 0x56a | Size: 0x2
	float MinimumDesiredWidth; // Offset: 0x56c | Size: 0x4
	bool IsCaretMovedWhenGainFocus; // Offset: 0x570 | Size: 0x1
	bool SelectAllTextWhenFocused; // Offset: 0x571 | Size: 0x1
	bool RevertTextOnEscape; // Offset: 0x572 | Size: 0x1
	bool ClearKeyboardFocusOnCommit; // Offset: 0x573 | Size: 0x1
	bool SelectAllTextOnCommit; // Offset: 0x574 | Size: 0x1
	bool AllowContextMenu; // Offset: 0x575 | Size: 0x1
	enum class EVirtualKeyboardType KeyboardType; // Offset: 0x576 | Size: 0x1
	struct FVirtualKeyboardOptions VirtualKeyboardOptions; // Offset: 0x577 | Size: 0x1
	enum class EVirtualKeyboardTrigger VirtualKeyboardTrigger; // Offset: 0x578 | Size: 0x1
	enum class EVirtualKeyboardDismissAction VirtualKeyboardDismissAction; // Offset: 0x579 | Size: 0x1
	enum class ETextJustify Justification; // Offset: 0x57a | Size: 0x1
	struct FShapedTextOptions ShapedTextOptions; // Offset: 0x57b | Size: 0x3
	char pad_0x57E[0x2]; // Offset: 0x57e | Size: 0x2
	struct FMulticastInlineDelegate OnTextChanged; // Offset: 0x580 | Size: 0x10
	struct FMulticastInlineDelegate OnTextCommitted; // Offset: 0x590 | Size: 0x10
	struct FMulticastInlineDelegate OnLongPressed; // Offset: 0x5a0 | Size: 0x10
	struct FMulticastInlineDelegate OnMenuSummoned; // Offset: 0x5b0 | Size: 0x10
	struct FMulticastInlineDelegate OnMenuDismissed; // Offset: 0x5c0 | Size: 0x10
	struct UWidget* CustomContextMenuWidget; // Offset: 0x5d0 | Size: 0x8
	char pad_0x5D8[0x18]; // Offset: 0x5d8 | Size: 0x18

	// Functions

	// Object: Function UMG.EditableText.SetText
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ca13d4
	// Return & Params: [ Num(1) Size(0x18) ]
	void SetText(struct FText InText);

	// Object: Function UMG.EditableText.SetJustification
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ca10e8
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetJustification(enum class ETextJustify InJustification);

	// Object: Function UMG.EditableText.SetIsReadOnly
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ca1168
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetIsReadOnly(bool InbIsReadyOnly);

	// Object: Function UMG.EditableText.SetIsPassword
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ca134c
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetIsPassword(bool InbIsPassword);

	// Object: Function UMG.EditableText.SetHintText
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ca11f0
	// Return & Params: [ Num(1) Size(0x18) ]
	void SetHintText(struct FText InHintText);

	// Object: DelegateFunction UMG.EditableText.OnEditableTextLongPressed__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnEditableTextLongPressed__DelegateSignature();

	// Object: DelegateFunction UMG.EditableText.OnEditableTextContextMenuSummoned__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnEditableTextContextMenuSummoned__DelegateSignature();

	// Object: DelegateFunction UMG.EditableText.OnEditableTextContextMenuDismissed__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnEditableTextContextMenuDismissed__DelegateSignature();

	// Object: DelegateFunction UMG.EditableText.OnEditableTextCommittedEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x19) ]
	void OnEditableTextCommittedEvent__DelegateSignature(struct FText& Text, enum class ETextCommit CommitMethod);

	// Object: DelegateFunction UMG.EditableText.OnEditableTextChangedEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x18) ]
	void OnEditableTextChangedEvent__DelegateSignature(struct FText& Text);

	// Object: Function UMG.EditableText.HasAnyTextSelected
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ca16a8
	// Return & Params: [ Num(1) Size(0x1) ]
	bool HasAnyTextSelected();

	// Object: Function UMG.EditableText.HandleSelectAll
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ca16dc
	// Return & Params: [ Num(0) Size(0x0) ]
	void HandleSelectAll();

	// Object: Function UMG.EditableText.HandlePaste
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ca16f0
	// Return & Params: [ Num(0) Size(0x0) ]
	void HandlePaste();

	// Object: Function UMG.EditableText.HandleCut
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ca1718
	// Return & Params: [ Num(0) Size(0x0) ]
	void HandleCut();

	// Object: Function UMG.EditableText.HandleCopy
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ca1704
	// Return & Params: [ Num(0) Size(0x0) ]
	void HandleCopy();

	// Object: Function UMG.EditableText.GetText
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ca1530
	// Return & Params: [ Num(1) Size(0x18) ]
	struct FText GetText();

	// Object: Function UMG.EditableText.CanExecuteSelectAll
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ca15d8
	// Return & Params: [ Num(1) Size(0x1) ]
	bool CanExecuteSelectAll();

	// Object: Function UMG.EditableText.CanExecutePaste
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ca160c
	// Return & Params: [ Num(1) Size(0x1) ]
	bool CanExecutePaste();

	// Object: Function UMG.EditableText.CanExecuteCut
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ca1674
	// Return & Params: [ Num(1) Size(0x1) ]
	bool CanExecuteCut();

	// Object: Function UMG.EditableText.CanExecuteCopy
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ca1640
	// Return & Params: [ Num(1) Size(0x1) ]
	bool CanExecuteCopy();
};

// Object: Class UMG.EditableTextBox
// Inherited Bytes: 0x138 | Struct Size: 0xf10
struct UEditableTextBox : UWidget {
	// Fields
	struct FText Text; // Offset: 0x138 | Size: 0x18
	struct FDelegate TextDelegate; // Offset: 0x150 | Size: 0x10
	struct FEditableTextBoxStyle WidgetStyle; // Offset: 0x160 | Size: 0xc90
	struct USlateWidgetStyleAsset* Style; // Offset: 0xdf0 | Size: 0x8
	struct FText HintText; // Offset: 0xdf8 | Size: 0x18
	struct FDelegate HintTextDelegate; // Offset: 0xe10 | Size: 0x10
	struct FSlateFontInfo Font; // Offset: 0xe20 | Size: 0x60
	struct FLinearColor ForegroundColor; // Offset: 0xe80 | Size: 0x10
	struct FLinearColor BackgroundColor; // Offset: 0xe90 | Size: 0x10
	struct FLinearColor ReadOnlyForegroundColor; // Offset: 0xea0 | Size: 0x10
	bool IsReadOnly; // Offset: 0xeb0 | Size: 0x1
	bool IsPassword; // Offset: 0xeb1 | Size: 0x1
	char pad_0xEB2[0x2]; // Offset: 0xeb2 | Size: 0x2
	float MinimumDesiredWidth; // Offset: 0xeb4 | Size: 0x4
	struct FMargin Padding; // Offset: 0xeb8 | Size: 0x10
	bool IsCaretMovedWhenGainFocus; // Offset: 0xec8 | Size: 0x1
	bool SelectAllTextWhenFocused; // Offset: 0xec9 | Size: 0x1
	bool RevertTextOnEscape; // Offset: 0xeca | Size: 0x1
	bool ClearKeyboardFocusOnCommit; // Offset: 0xecb | Size: 0x1
	bool SelectAllTextOnCommit; // Offset: 0xecc | Size: 0x1
	bool AllowContextMenu; // Offset: 0xecd | Size: 0x1
	enum class EVirtualKeyboardType KeyboardType; // Offset: 0xece | Size: 0x1
	struct FVirtualKeyboardOptions VirtualKeyboardOptions; // Offset: 0xecf | Size: 0x1
	enum class EVirtualKeyboardTrigger VirtualKeyboardTrigger; // Offset: 0xed0 | Size: 0x1
	enum class EVirtualKeyboardDismissAction VirtualKeyboardDismissAction; // Offset: 0xed1 | Size: 0x1
	enum class ETextJustify Justification; // Offset: 0xed2 | Size: 0x1
	struct FShapedTextOptions ShapedTextOptions; // Offset: 0xed3 | Size: 0x3
	char pad_0xED6[0x2]; // Offset: 0xed6 | Size: 0x2
	struct FMulticastInlineDelegate OnTextChanged; // Offset: 0xed8 | Size: 0x10
	struct FMulticastInlineDelegate OnTextCommitted; // Offset: 0xee8 | Size: 0x10
	char pad_0xEF8[0x18]; // Offset: 0xef8 | Size: 0x18

	// Functions

	// Object: Function UMG.EditableTextBox.SetText
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ca2350
	// Return & Params: [ Num(1) Size(0x18) ]
	void SetText(struct FText InText);

	// Object: Function UMG.EditableTextBox.SetJustification
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ca1ec0
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetJustification(enum class ETextJustify InJustification);

	// Object: Function UMG.EditableTextBox.SetIsReadOnly
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ca2010
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetIsReadOnly(bool bReadOnly);

	// Object: Function UMG.EditableTextBox.SetIsPassword
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ca1f88
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetIsPassword(bool bIsPassword);

	// Object: Function UMG.EditableTextBox.SetHintText
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ca21f4
	// Return & Params: [ Num(1) Size(0x18) ]
	void SetHintText(struct FText InText);

	// Object: Function UMG.EditableTextBox.SetError
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ca2098
	// Return & Params: [ Num(1) Size(0x18) ]
	void SetError(struct FText InError);

	// Object: DelegateFunction UMG.EditableTextBox.OnEditableTextBoxCommittedEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x19) ]
	void OnEditableTextBoxCommittedEvent__DelegateSignature(struct FText& Text, enum class ETextCommit CommitMethod);

	// Object: DelegateFunction UMG.EditableTextBox.OnEditableTextBoxChangedEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x18) ]
	void OnEditableTextBoxChangedEvent__DelegateSignature(struct FText& Text);

	// Object: Function UMG.EditableTextBox.HasError
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ca1f40
	// Return & Params: [ Num(1) Size(0x1) ]
	bool HasError();

	// Object: Function UMG.EditableTextBox.GetText
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ca24ac
	// Return & Params: [ Num(1) Size(0x18) ]
	struct FText GetText();

	// Object: Function UMG.EditableTextBox.ClearError
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ca1f74
	// Return & Params: [ Num(0) Size(0x0) ]
	void ClearError();
};

// Object: Class UMG.ExpandableArea
// Inherited Bytes: 0x138 | Struct Size: 0x480
struct UExpandableArea : UWidget {
	// Fields
	char pad_0x138[0x8]; // Offset: 0x138 | Size: 0x8
	struct FExpandableAreaStyle Style; // Offset: 0x140 | Size: 0x1e0
	struct FSlateBrush BorderBrush; // Offset: 0x320 | Size: 0xe0
	struct FSlateColor BorderColor; // Offset: 0x400 | Size: 0x28
	bool bIsExpanded; // Offset: 0x428 | Size: 0x1
	char pad_0x429[0x3]; // Offset: 0x429 | Size: 0x3
	float MaxHeight; // Offset: 0x42c | Size: 0x4
	struct FMargin HeaderPadding; // Offset: 0x430 | Size: 0x10
	struct FMargin AreaPadding; // Offset: 0x440 | Size: 0x10
	struct FMulticastInlineDelegate OnExpansionChanged; // Offset: 0x450 | Size: 0x10
	struct UWidget* HeaderContent; // Offset: 0x460 | Size: 0x8
	struct UWidget* BodyContent; // Offset: 0x468 | Size: 0x8
	char pad_0x470[0x10]; // Offset: 0x470 | Size: 0x10

	// Functions

	// Object: Function UMG.ExpandableArea.SetIsExpanded_Animated
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ca2b20
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetIsExpanded_Animated(bool IsExpanded);

	// Object: Function UMG.ExpandableArea.SetIsExpanded
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ca2ba8
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetIsExpanded(bool IsExpanded);

	// Object: Function UMG.ExpandableArea.GetIsExpanded
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ca2c30
	// Return & Params: [ Num(1) Size(0x1) ]
	bool GetIsExpanded();
};

// Object: Class UMG.FloatBinding
// Inherited Bytes: 0x60 | Struct Size: 0x60
struct UFloatBinding : UPropertyBinding {
	// Functions

	// Object: Function UMG.FloatBinding.GetValue
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x104ca44f8
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetValue();
};

// Object: Class UMG.GridPanel
// Inherited Bytes: 0x150 | Struct Size: 0x180
struct UGridPanel : UPanelWidget {
	// Fields
	struct TArray<float> ColumnFill; // Offset: 0x150 | Size: 0x10
	struct TArray<float> RowFill; // Offset: 0x160 | Size: 0x10
	char pad_0x170[0x10]; // Offset: 0x170 | Size: 0x10

	// Functions

	// Object: Function UMG.GridPanel.SetRowFill
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ca4748
	// Return & Params: [ Num(2) Size(0x8) ]
	void SetRowFill(int32_t ColumnIndex, float Coefficient);

	// Object: Function UMG.GridPanel.SetColumnFill
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ca4814
	// Return & Params: [ Num(2) Size(0x8) ]
	void SetColumnFill(int32_t ColumnIndex, float Coefficient);

	// Object: Function UMG.GridPanel.AddChildToGrid
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ca48e0
	// Return & Params: [ Num(4) Size(0x18) ]
	struct UGridSlot* AddChildToGrid(struct UWidget* Content, int32_t InRow, int32_t InColumn);
};

// Object: Class UMG.GridSlot
// Inherited Bytes: 0x38 | Struct Size: 0x70
struct UGridSlot : UPanelSlot {
	// Fields
	struct FMargin Padding; // Offset: 0x38 | Size: 0x10
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0x48 | Size: 0x1
	enum class EVerticalAlignment VerticalAlignment; // Offset: 0x49 | Size: 0x1
	char pad_0x4A[0x2]; // Offset: 0x4a | Size: 0x2
	int32_t Row; // Offset: 0x4c | Size: 0x4
	int32_t RowSpan; // Offset: 0x50 | Size: 0x4
	int32_t Column; // Offset: 0x54 | Size: 0x4
	int32_t ColumnSpan; // Offset: 0x58 | Size: 0x4
	int32_t Layer; // Offset: 0x5c | Size: 0x4
	struct FVector2D Nudge; // Offset: 0x60 | Size: 0x8
	char pad_0x68[0x8]; // Offset: 0x68 | Size: 0x8

	// Functions

	// Object: Function UMG.GridSlot.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ca4d78
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment);

	// Object: Function UMG.GridSlot.SetRowSpan
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ca5074
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetRowSpan(int32_t InRowSpan);

	// Object: Function UMG.GridSlot.SetRow
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ca50f4
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetRow(int32_t InRow);

	// Object: Function UMG.GridSlot.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ca5174
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetPadding(struct FMargin InPadding);

	// Object: Function UMG.GridSlot.SetNudge
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x104ca4e78
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetNudge(struct FVector2D InNudge);

	// Object: Function UMG.GridSlot.SetLayer
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ca4ef4
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetLayer(int32_t InLayer);

	// Object: Function UMG.GridSlot.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ca4df8
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment);

	// Object: Function UMG.GridSlot.SetColumnSpan
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ca4f74
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetColumnSpan(int32_t InColumnSpan);

	// Object: Function UMG.GridSlot.SetColumn
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ca4ff4
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetColumn(int32_t InColumn);
};

// Object: Class UMG.HorizontalBox
// Inherited Bytes: 0x150 | Struct Size: 0x160
struct UHorizontalBox : UPanelWidget {
	// Fields
	char pad_0x150[0x10]; // Offset: 0x150 | Size: 0x10

	// Functions

	// Object: Function UMG.HorizontalBox.AddChildToHorizontalBox
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ca5734
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UHorizontalBoxSlot* AddChildToHorizontalBox(struct UWidget* Content);
};

// Object: Class UMG.HorizontalBoxSlot
// Inherited Bytes: 0x38 | Struct Size: 0x60
struct UHorizontalBoxSlot : UPanelSlot {
	// Fields
	char pad_0x38[0x8]; // Offset: 0x38 | Size: 0x8
	struct FMargin Padding; // Offset: 0x40 | Size: 0x10
	struct FSlateChildSize Size; // Offset: 0x50 | Size: 0x8
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0x58 | Size: 0x1
	enum class EVerticalAlignment VerticalAlignment; // Offset: 0x59 | Size: 0x1
	char pad_0x5A[0x6]; // Offset: 0x5a | Size: 0x6

	// Functions

	// Object: Function UMG.HorizontalBoxSlot.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ca5b5c
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment);

	// Object: Function UMG.HorizontalBoxSlot.SetSize
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ca5c5c
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetSize(struct FSlateChildSize InSize);

	// Object: Function UMG.HorizontalBoxSlot.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ca5ce8
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetPadding(struct FMargin InPadding);

	// Object: Function UMG.HorizontalBoxSlot.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ca5bdc
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment);
};

// Object: Class UMG.InputKeySelector
// Inherited Bytes: 0x138 | Struct Size: 0xaa0
struct UInputKeySelector : UWidget {
	// Fields
	char pad_0x138[0x8]; // Offset: 0x138 | Size: 0x8
	struct FButtonStyle WidgetStyle; // Offset: 0x140 | Size: 0x3e0
	struct FTextBlockStyle TextStyle; // Offset: 0x520 | Size: 0x460
	struct FInputChord SelectedKey; // Offset: 0x980 | Size: 0x20
	struct FSlateFontInfo Font; // Offset: 0x9a0 | Size: 0x60
	struct FMargin Margin; // Offset: 0xa00 | Size: 0x10
	struct FLinearColor ColorAndOpacity; // Offset: 0xa10 | Size: 0x10
	struct FText KeySelectionText; // Offset: 0xa20 | Size: 0x18
	struct FText NoKeySpecifiedText; // Offset: 0xa38 | Size: 0x18
	bool bAllowModifierKeys; // Offset: 0xa50 | Size: 0x1
	bool bAllowGamepadKeys; // Offset: 0xa51 | Size: 0x1
	char pad_0xA52[0x6]; // Offset: 0xa52 | Size: 0x6
	struct TArray<struct FKey> EscapeKeys; // Offset: 0xa58 | Size: 0x10
	struct FMulticastInlineDelegate OnKeySelected; // Offset: 0xa68 | Size: 0x10
	struct FMulticastInlineDelegate OnIsSelectingKeyChanged; // Offset: 0xa78 | Size: 0x10
	char pad_0xA88[0x18]; // Offset: 0xa88 | Size: 0x18

	// Functions

	// Object: Function UMG.InputKeySelector.SetTextBlockVisibility
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ca763c
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetTextBlockVisibility(enum class ESlateVisibility InVisibility);

	// Object: Function UMG.InputKeySelector.SetSelectedKey
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104ca7ab8
	// Return & Params: [ Num(1) Size(0x20) ]
	void SetSelectedKey(struct FInputChord& InSelectedKey);

	// Object: Function UMG.InputKeySelector.SetNoKeySpecifiedText
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ca7800
	// Return & Params: [ Num(1) Size(0x18) ]
	void SetNoKeySpecifiedText(struct FText InNoKeySpecifiedText);

	// Object: Function UMG.InputKeySelector.SetKeySelectionText
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ca795c
	// Return & Params: [ Num(1) Size(0x18) ]
	void SetKeySelectionText(struct FText InKeySelectionText);

	// Object: Function UMG.InputKeySelector.SetEscapeKeys
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104ca751c
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetEscapeKeys(struct TArray<struct FKey>& InKeys);

	// Object: Function UMG.InputKeySelector.SetAllowModifierKeys
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ca7778
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetAllowModifierKeys(bool bInAllowModifierKeys);

	// Object: Function UMG.InputKeySelector.SetAllowGamepadKeys
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ca76f0
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetAllowGamepadKeys(bool bInAllowGamepadKeys);

	// Object: DelegateFunction UMG.InputKeySelector.OnKeySelected__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x20) ]
	void OnKeySelected__DelegateSignature(struct FInputChord SelectedKey);

	// Object: DelegateFunction UMG.InputKeySelector.OnIsSelectingKeyChanged__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnIsSelectingKeyChanged__DelegateSignature();

	// Object: Function UMG.InputKeySelector.GetIsSelectingKey
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ca76bc
	// Return & Params: [ Num(1) Size(0x1) ]
	bool GetIsSelectingKey();
};

// Object: Class UMG.Int32Binding
// Inherited Bytes: 0x60 | Struct Size: 0x60
struct UInt32Binding : UPropertyBinding {
	// Functions

	// Object: Function UMG.Int32Binding.GetValue
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x104ca8004
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetValue();
};

// Object: Class UMG.InvalidationBox
// Inherited Bytes: 0x150 | Struct Size: 0x160
struct UInvalidationBox : UContentWidget {
	// Fields
	bool bCanCache; // Offset: 0x149 | Size: 0x1
	bool CacheRelativeTransforms; // Offset: 0x14a | Size: 0x1
	char pad_0x152[0xe]; // Offset: 0x152 | Size: 0xe

	// Functions

	// Object: Function UMG.InvalidationBox.SetCanCache
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ca8254
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetCanCache(bool CanCache);

	// Object: Function UMG.InvalidationBox.InvalidateCache
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ca8310
	// Return & Params: [ Num(0) Size(0x0) ]
	void InvalidateCache();

	// Object: Function UMG.InvalidationBox.GetCanCache
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ca82dc
	// Return & Params: [ Num(1) Size(0x1) ]
	bool GetCanCache();
};

// Object: Class UMG.UserListEntry
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UUserListEntry : UInterface {
	// Functions

	// Object: Function UMG.UserListEntry.BP_OnItemSelectionChanged
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void BP_OnItemSelectionChanged(bool bIsSelected);

	// Object: Function UMG.UserListEntry.BP_OnItemExpansionChanged
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x1) ]
	void BP_OnItemExpansionChanged(bool bIsExpanded);

	// Object: Function UMG.UserListEntry.BP_OnEntryReleased
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void BP_OnEntryReleased();
};

// Object: Class UMG.UserListEntryLibrary
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UUserListEntryLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object: Function UMG.UserListEntryLibrary.IsListItemSelected
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x104ca8bc0
	// Return & Params: [ Num(2) Size(0x11) ]
	bool IsListItemSelected(struct TScriptInterface<IUserListEntry> UserListEntry);

	// Object: Function UMG.UserListEntryLibrary.IsListItemExpanded
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x104ca8b30
	// Return & Params: [ Num(2) Size(0x11) ]
	bool IsListItemExpanded(struct TScriptInterface<IUserListEntry> UserListEntry);

	// Object: Function UMG.UserListEntryLibrary.GetOwningListView
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x104ca8aa0
	// Return & Params: [ Num(2) Size(0x18) ]
	struct UListViewBase* GetOwningListView(struct TScriptInterface<IUserListEntry> UserListEntry);
};

// Object: Class UMG.UserObjectListEntry
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UUserObjectListEntry : UUserListEntry {
	// Functions

	// Object: Function UMG.UserObjectListEntry.OnListItemObjectSet
	// Flags: [Event|Protected|BlueprintEvent]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x8) ]
	void OnListItemObjectSet(struct UObject* ListItemObject);
};

// Object: Class UMG.UserObjectListEntryLibrary
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UUserObjectListEntryLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object: Function UMG.UserObjectListEntryLibrary.GetListItemObject
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x104ca9280
	// Return & Params: [ Num(2) Size(0x18) ]
	struct UObject* GetListItemObject(struct TScriptInterface<IUserObjectListEntry> UserObjectListEntry);
};

// Object: Class UMG.ListViewDesignerPreviewItem
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UListViewDesignerPreviewItem : UObject {
};

// Object: Class UMG.MenuAnchor
// Inherited Bytes: 0x150 | Struct Size: 0x190
struct UMenuAnchor : UContentWidget {
	// Fields
	struct UUserWidget* MenuClass; // Offset: 0x150 | Size: 0x8
	struct FDelegate OnGetMenuContentEvent; // Offset: 0x158 | Size: 0x10
	enum class EMenuPlacement Placement; // Offset: 0x168 | Size: 0x1
	bool bFitInWindow; // Offset: 0x169 | Size: 0x1
	bool ShouldDeferPaintingAfterWindowContent; // Offset: 0x16a | Size: 0x1
	bool UseApplicationMenuStack; // Offset: 0x16b | Size: 0x1
	char pad_0x16C[0x4]; // Offset: 0x16c | Size: 0x4
	struct FMulticastInlineDelegate OnMenuOpenChanged; // Offset: 0x170 | Size: 0x10
	char pad_0x180[0x10]; // Offset: 0x180 | Size: 0x10

	// Functions

	// Object: Function UMG.MenuAnchor.ToggleOpen
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cad628
	// Return & Params: [ Num(1) Size(0x1) ]
	void ToggleOpen(bool bFocusOnOpen);

	// Object: Function UMG.MenuAnchor.ShouldOpenDueToClick
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cad524
	// Return & Params: [ Num(1) Size(0x1) ]
	bool ShouldOpenDueToClick();

	// Object: Function UMG.MenuAnchor.SetPlacement
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cad738
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetPlacement(enum class EMenuPlacement InPlacement);

	// Object: Function UMG.MenuAnchor.Open
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cad5a0
	// Return & Params: [ Num(1) Size(0x1) ]
	void Open(bool bFocusMenu);

	// Object: Function UMG.MenuAnchor.IsOpen
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cad558
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsOpen();

	// Object: Function UMG.MenuAnchor.HasOpenSubMenus
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cad4b8
	// Return & Params: [ Num(1) Size(0x1) ]
	bool HasOpenSubMenus();

	// Object: Function UMG.MenuAnchor.GetMenuPosition
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cad4ec
	// Return & Params: [ Num(1) Size(0x8) ]
	struct FVector2D GetMenuPosition();

	// Object: Function UMG.MenuAnchor.FitInWindow
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cad6b0
	// Return & Params: [ Num(1) Size(0x1) ]
	void FitInWindow(bool bFit);

	// Object: Function UMG.MenuAnchor.Close
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cad58c
	// Return & Params: [ Num(0) Size(0x0) ]
	void Close();
};

// Object: Class UMG.MouseCursorBinding
// Inherited Bytes: 0x60 | Struct Size: 0x60
struct UMouseCursorBinding : UPropertyBinding {
	// Functions

	// Object: Function UMG.MouseCursorBinding.GetValue
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x104cadca4
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class EMouseCursor GetValue();
};

// Object: Class UMG.MovieScene2DTransformSection
// Inherited Bytes: 0xd8 | Struct Size: 0x548
struct UMovieScene2DTransformSection : UMovieSceneSection {
	// Fields
	struct FMovieScene2DTransformMask TransformMask; // Offset: 0xd8 | Size: 0x4
	char pad_0xDC[0x4]; // Offset: 0xdc | Size: 0x4
	struct FMovieSceneFloatChannel Translation[0x2]; // Offset: 0xe0 | Size: 0x140
	struct FMovieSceneFloatChannel Rotation; // Offset: 0x220 | Size: 0xa0
	struct FMovieSceneFloatChannel Scale[0x2]; // Offset: 0x2c0 | Size: 0x140
	struct FMovieSceneFloatChannel Shear[0x2]; // Offset: 0x400 | Size: 0x140
	char pad_0x540[0x8]; // Offset: 0x540 | Size: 0x8
};

// Object: Class UMG.MovieScene2DTransformTrack
// Inherited Bytes: 0x88 | Struct Size: 0x88
struct UMovieScene2DTransformTrack : UMovieScenePropertyTrack {
};

// Object: Class UMG.MovieSceneMarginSection
// Inherited Bytes: 0xd8 | Struct Size: 0x358
struct UMovieSceneMarginSection : UMovieSceneSection {
	// Fields
	struct FMovieSceneFloatChannel TopCurve; // Offset: 0xd8 | Size: 0xa0
	struct FMovieSceneFloatChannel LeftCurve; // Offset: 0x178 | Size: 0xa0
	struct FMovieSceneFloatChannel RightCurve; // Offset: 0x218 | Size: 0xa0
	struct FMovieSceneFloatChannel BottomCurve; // Offset: 0x2b8 | Size: 0xa0
};

// Object: Class UMG.MovieSceneMarginTrack
// Inherited Bytes: 0x88 | Struct Size: 0x88
struct UMovieSceneMarginTrack : UMovieScenePropertyTrack {
};

// Object: Class UMG.MovieSceneWidgetMaterialTrack
// Inherited Bytes: 0x68 | Struct Size: 0x80
struct UMovieSceneWidgetMaterialTrack : UMovieSceneMaterialTrack {
	// Fields
	struct TArray<struct FName> BrushPropertyNamePath; // Offset: 0x68 | Size: 0x10
	struct FName TrackName; // Offset: 0x78 | Size: 0x8
};

// Object: Class UMG.MultiLineEditableText
// Inherited Bytes: 0x160 | Struct Size: 0x6a0
struct UMultiLineEditableText : UTextLayoutWidget {
	// Fields
	struct FText Text; // Offset: 0x160 | Size: 0x18
	struct FText HintText; // Offset: 0x178 | Size: 0x18
	struct FDelegate HintTextDelegate; // Offset: 0x190 | Size: 0x10
	struct FTextBlockStyle WidgetStyle; // Offset: 0x1a0 | Size: 0x460
	bool bIsReadOnly; // Offset: 0x600 | Size: 0x1
	char pad_0x601[0x7]; // Offset: 0x601 | Size: 0x7
	struct FSlateFontInfo Font; // Offset: 0x608 | Size: 0x60
	bool SelectAllTextWhenFocused; // Offset: 0x668 | Size: 0x1
	bool ClearTextSelectionOnFocusLoss; // Offset: 0x669 | Size: 0x1
	bool RevertTextOnEscape; // Offset: 0x66a | Size: 0x1
	bool ClearKeyboardFocusOnCommit; // Offset: 0x66b | Size: 0x1
	bool AllowContextMenu; // Offset: 0x66c | Size: 0x1
	struct FVirtualKeyboardOptions VirtualKeyboardOptions; // Offset: 0x66d | Size: 0x1
	enum class EVirtualKeyboardDismissAction VirtualKeyboardDismissAction; // Offset: 0x66e | Size: 0x1
	char pad_0x66F[0x1]; // Offset: 0x66f | Size: 0x1
	struct FMulticastInlineDelegate OnTextChanged; // Offset: 0x670 | Size: 0x10
	struct FMulticastInlineDelegate OnTextCommitted; // Offset: 0x680 | Size: 0x10
	char pad_0x690[0x10]; // Offset: 0x690 | Size: 0x10

	// Functions

	// Object: Function UMG.MultiLineEditableText.SetWidgetStyle
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104caea58
	// Return & Params: [ Num(1) Size(0x460) ]
	void SetWidgetStyle(struct FTextBlockStyle& InWidgetStyle);

	// Object: Function UMG.MultiLineEditableText.SetText
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104caedb0
	// Return & Params: [ Num(1) Size(0x18) ]
	void SetText(struct FText InText);

	// Object: Function UMG.MultiLineEditableText.SetIsReadOnly
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104caeb24
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetIsReadOnly(bool bReadOnly);

	// Object: Function UMG.MultiLineEditableText.SetHintText
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104caebac
	// Return & Params: [ Num(1) Size(0x18) ]
	void SetHintText(struct FText InHintText);

	// Object: DelegateFunction UMG.MultiLineEditableText.OnMultiLineEditableTextCommittedEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x19) ]
	void OnMultiLineEditableTextCommittedEvent__DelegateSignature(struct FText& Text, enum class ETextCommit CommitMethod);

	// Object: DelegateFunction UMG.MultiLineEditableText.OnMultiLineEditableTextChangedEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x18) ]
	void OnMultiLineEditableTextChangedEvent__DelegateSignature(struct FText& Text);

	// Object: Function UMG.MultiLineEditableText.GetText
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104caef0c
	// Return & Params: [ Num(1) Size(0x18) ]
	struct FText GetText();

	// Object: Function UMG.MultiLineEditableText.GetHintText
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104caed08
	// Return & Params: [ Num(1) Size(0x18) ]
	struct FText GetHintText();
};

// Object: Class UMG.MultiLineEditableTextBox
// Inherited Bytes: 0x160 | Struct Size: 0x1360
struct UMultiLineEditableTextBox : UTextLayoutWidget {
	// Fields
	struct FText Text; // Offset: 0x160 | Size: 0x18
	struct FText HintText; // Offset: 0x178 | Size: 0x18
	struct FDelegate HintTextDelegate; // Offset: 0x190 | Size: 0x10
	struct FEditableTextBoxStyle WidgetStyle; // Offset: 0x1a0 | Size: 0xc90
	struct FTextBlockStyle TextStyle; // Offset: 0xe30 | Size: 0x460
	bool bIsReadOnly; // Offset: 0x1290 | Size: 0x1
	bool AllowContextMenu; // Offset: 0x1291 | Size: 0x1
	struct FVirtualKeyboardOptions VirtualKeyboardOptions; // Offset: 0x1292 | Size: 0x1
	enum class EVirtualKeyboardDismissAction VirtualKeyboardDismissAction; // Offset: 0x1293 | Size: 0x1
	char pad_0x1294[0x4]; // Offset: 0x1294 | Size: 0x4
	struct USlateWidgetStyleAsset* Style; // Offset: 0x1298 | Size: 0x8
	struct FSlateFontInfo Font; // Offset: 0x12a0 | Size: 0x60
	struct FLinearColor ForegroundColor; // Offset: 0x1300 | Size: 0x10
	struct FLinearColor BackgroundColor; // Offset: 0x1310 | Size: 0x10
	struct FLinearColor ReadOnlyForegroundColor; // Offset: 0x1320 | Size: 0x10
	struct FMulticastInlineDelegate OnTextChanged; // Offset: 0x1330 | Size: 0x10
	struct FMulticastInlineDelegate OnTextCommitted; // Offset: 0x1340 | Size: 0x10
	char pad_0x1350[0x10]; // Offset: 0x1350 | Size: 0x10

	// Functions

	// Object: Function UMG.MultiLineEditableTextBox.SetTextStyle
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104caf43c
	// Return & Params: [ Num(1) Size(0x460) ]
	void SetTextStyle(struct FTextBlockStyle& InTextStyle);

	// Object: Function UMG.MultiLineEditableTextBox.SetText
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104caf8f0
	// Return & Params: [ Num(1) Size(0x18) ]
	void SetText(struct FText InText);

	// Object: Function UMG.MultiLineEditableTextBox.SetIsReadOnly
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104caf508
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetIsReadOnly(bool bReadOnly);

	// Object: Function UMG.MultiLineEditableTextBox.SetHintText
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104caf6ec
	// Return & Params: [ Num(1) Size(0x18) ]
	void SetHintText(struct FText InHintText);

	// Object: Function UMG.MultiLineEditableTextBox.SetError
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104caf590
	// Return & Params: [ Num(1) Size(0x18) ]
	void SetError(struct FText InError);

	// Object: DelegateFunction UMG.MultiLineEditableTextBox.OnMultiLineEditableTextBoxCommittedEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x19) ]
	void OnMultiLineEditableTextBoxCommittedEvent__DelegateSignature(struct FText& Text, enum class ETextCommit CommitMethod);

	// Object: DelegateFunction UMG.MultiLineEditableTextBox.OnMultiLineEditableTextBoxChangedEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x18) ]
	void OnMultiLineEditableTextBoxChangedEvent__DelegateSignature(struct FText& Text);

	// Object: Function UMG.MultiLineEditableTextBox.GetText
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cafa4c
	// Return & Params: [ Num(1) Size(0x18) ]
	struct FText GetText();

	// Object: Function UMG.MultiLineEditableTextBox.GetHintText
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104caf848
	// Return & Params: [ Num(1) Size(0x18) ]
	struct FText GetHintText();
};

// Object: Class UMG.NamedSlotInterface
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UNamedSlotInterface : UInterface {
};

// Object: Class UMG.NativeWidgetHost
// Inherited Bytes: 0x138 | Struct Size: 0x148
struct UNativeWidgetHost : UWidget {
	// Fields
	char pad_0x138[0x10]; // Offset: 0x138 | Size: 0x10
};

// Object: Class UMG.ProgressBar
// Inherited Bytes: 0x138 | Struct Size: 0x460
struct UProgressBar : UWidget {
	// Fields
	char pad_0x138[0x8]; // Offset: 0x138 | Size: 0x8
	struct FProgressBarStyle WidgetStyle; // Offset: 0x140 | Size: 0x2b0
	struct USlateWidgetStyleAsset* Style; // Offset: 0x3f0 | Size: 0x8
	struct USlateBrushAsset* BackgroundImage; // Offset: 0x3f8 | Size: 0x8
	struct USlateBrushAsset* FillImage; // Offset: 0x400 | Size: 0x8
	struct USlateBrushAsset* MarqueeImage; // Offset: 0x408 | Size: 0x8
	float Percent; // Offset: 0x410 | Size: 0x4
	enum class EProgressBarFillType BarFillType; // Offset: 0x414 | Size: 0x1
	bool bIsMarquee; // Offset: 0x415 | Size: 0x1
	char pad_0x416[0x2]; // Offset: 0x416 | Size: 0x2
	struct FVector2D BorderPadding; // Offset: 0x418 | Size: 0x8
	struct FDelegate PercentDelegate; // Offset: 0x420 | Size: 0x10
	struct FLinearColor FillColorAndOpacity; // Offset: 0x430 | Size: 0x10
	struct FDelegate FillColorAndOpacityDelegate; // Offset: 0x440 | Size: 0x10
	char pad_0x450[0x10]; // Offset: 0x450 | Size: 0x10

	// Functions

	// Object: Function UMG.ProgressBar.SetPercent
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cb4c50
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetPercent(float InPercent);

	// Object: Function UMG.ProgressBar.SetIsMarquee
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cb4b48
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetIsMarquee(bool InbIsMarquee);

	// Object: Function UMG.ProgressBar.SetFillColorAndOpacity
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x104cb4bd0
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetFillColorAndOpacity(struct FLinearColor InColor);
};

// Object: Class UMG.RetainerBox
// Inherited Bytes: 0x150 | Struct Size: 0x178
struct URetainerBox : UContentWidget {
	// Fields
	bool bRetainRender; // Offset: 0x149 | Size: 0x1
	bool RenderOnInvalidation; // Offset: 0x14a | Size: 0x1
	bool RenderOnPhase; // Offset: 0x14b | Size: 0x1
	int32_t Phase; // Offset: 0x14c | Size: 0x4
	int32_t PhaseCount; // Offset: 0x150 | Size: 0x4
	struct UMaterialInterface* EffectMaterial; // Offset: 0x158 | Size: 0x8
	struct FName TextureParameter; // Offset: 0x160 | Size: 0x8
	char pad_0x16B[0xd]; // Offset: 0x16b | Size: 0xd

	// Functions

	// Object: Function UMG.RetainerBox.SetTextureParameter
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cb5368
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetTextureParameter(struct FName TextureParameter);

	// Object: Function UMG.RetainerBox.SetRetainRendering
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cb52e0
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetRetainRendering(bool bInRetainRendering);

	// Object: Function UMG.RetainerBox.SetRenderingPhase
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cb54b0
	// Return & Params: [ Num(2) Size(0x8) ]
	void SetRenderingPhase(int32_t RenderPhase, int32_t TotalPhases);

	// Object: Function UMG.RetainerBox.SetEffectMaterial
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cb53e8
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetEffectMaterial(struct UMaterialInterface* EffectMaterial);

	// Object: Function UMG.RetainerBox.RequestRender
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cb549c
	// Return & Params: [ Num(0) Size(0x0) ]
	void RequestRender();

	// Object: Function UMG.RetainerBox.GetEffectMaterial
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cb5468
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UMaterialInstanceDynamic* GetEffectMaterial();
};

// Object: Class UMG.RichTextBlockImageDecorator
// Inherited Bytes: 0x28 | Struct Size: 0x30
struct URichTextBlockImageDecorator : URichTextBlockDecorator {
	// Fields
	struct UDataTable* ImageSet; // Offset: 0x28 | Size: 0x8
};

// Object: Class UMG.RichTextBlockInlineTextDecorator
// Inherited Bytes: 0x28 | Struct Size: 0x30
struct URichTextBlockInlineTextDecorator : URichTextBlockDecorator {
	// Fields
	struct UDataTable* InlineTextStyleSet; // Offset: 0x28 | Size: 0x8
};

// Object: Class UMG.SafeZone
// Inherited Bytes: 0x150 | Struct Size: 0x160
struct USafeZone : UContentWidget {
	// Fields
	bool PadLeft; // Offset: 0x149 | Size: 0x1
	bool PadRight; // Offset: 0x14a | Size: 0x1
	bool PadTop; // Offset: 0x14b | Size: 0x1
	bool PadBottom; // Offset: 0x14c | Size: 0x1
	char pad_0x154[0xc]; // Offset: 0x154 | Size: 0xc

	// Functions

	// Object: Function UMG.SafeZone.SetSidesToPad
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cb722c
	// Return & Params: [ Num(4) Size(0x4) ]
	void SetSidesToPad(bool InPadLeft, bool InPadRight, bool InPadTop, bool InPadBottom);
};

// Object: Class UMG.SafeZoneSlot
// Inherited Bytes: 0x38 | Struct Size: 0x60
struct USafeZoneSlot : UPanelSlot {
	// Fields
	bool bIsTitleSafe; // Offset: 0x38 | Size: 0x1
	char pad_0x39[0x3]; // Offset: 0x39 | Size: 0x3
	struct FMargin SafeAreaScale; // Offset: 0x3c | Size: 0x10
	enum class EHorizontalAlignment HAlign; // Offset: 0x4c | Size: 0x1
	enum class EVerticalAlignment VAlign; // Offset: 0x4d | Size: 0x1
	char pad_0x4E[0x2]; // Offset: 0x4e | Size: 0x2
	struct FMargin Padding; // Offset: 0x50 | Size: 0x10
};

// Object: Class UMG.ScaleBox
// Inherited Bytes: 0x150 | Struct Size: 0x168
struct UScaleBox : UContentWidget {
	// Fields
	enum class EStretch Stretch; // Offset: 0x149 | Size: 0x1
	enum class EStretchDirection StretchDirection; // Offset: 0x14a | Size: 0x1
	float UserSpecifiedScale; // Offset: 0x14c | Size: 0x4
	bool IgnoreInheritedScale; // Offset: 0x150 | Size: 0x1
	float IgnoreSlightScaleModificationPercent; // Offset: 0x154 | Size: 0x4
	char pad_0x15B[0xd]; // Offset: 0x15b | Size: 0xd

	// Functions

	// Object: Function UMG.ScaleBox.SetUserSpecifiedScale
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cb7970
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetUserSpecifiedScale(float InUserSpecifiedScale);

	// Object: Function UMG.ScaleBox.SetStretchDirection
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cb79f0
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetStretchDirection(enum class EStretchDirection InStretchDirection);

	// Object: Function UMG.ScaleBox.SetStretch
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cb7a70
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetStretch(enum class EStretch InStretch);

	// Object: Function UMG.ScaleBox.SetIgnoreInheritedScale
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cb78e8
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetIgnoreInheritedScale(bool bInIgnoreInheritedScale);
};

// Object: Class UMG.ScaleBoxSlot
// Inherited Bytes: 0x38 | Struct Size: 0x60
struct UScaleBoxSlot : UPanelSlot {
	// Fields
	struct FMargin Padding; // Offset: 0x38 | Size: 0x10
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0x48 | Size: 0x1
	enum class EVerticalAlignment VerticalAlignment; // Offset: 0x49 | Size: 0x1
	char pad_0x4A[0x16]; // Offset: 0x4a | Size: 0x16

	// Functions

	// Object: Function UMG.ScaleBoxSlot.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cb7f90
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment);

	// Object: Function UMG.ScaleBoxSlot.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cb8090
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetPadding(struct FMargin InPadding);

	// Object: Function UMG.ScaleBoxSlot.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cb8010
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment);
};

// Object: Class UMG.ScrollBar
// Inherited Bytes: 0x138 | Struct Size: 0x970
struct UScrollBar : UWidget {
	// Fields
	char pad_0x138[0x8]; // Offset: 0x138 | Size: 0x8
	struct FScrollBarStyle WidgetStyle; // Offset: 0x140 | Size: 0x7f0
	struct USlateWidgetStyleAsset* Style; // Offset: 0x930 | Size: 0x8
	bool bAlwaysShowScrollbar; // Offset: 0x938 | Size: 0x1
	bool bAlwaysShowScrollbarTrack; // Offset: 0x939 | Size: 0x1
	enum class EOrientation Orientation; // Offset: 0x93a | Size: 0x1
	char pad_0x93B[0x1]; // Offset: 0x93b | Size: 0x1
	struct FVector2D Thickness; // Offset: 0x93c | Size: 0x8
	struct FMargin Padding; // Offset: 0x944 | Size: 0x10
	char pad_0x954[0x1c]; // Offset: 0x954 | Size: 0x1c

	// Functions

	// Object: Function UMG.ScrollBar.SetState
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cb8544
	// Return & Params: [ Num(2) Size(0x8) ]
	void SetState(float InOffsetFraction, float InThumbSizeFraction);
};

// Object: Class UMG.ScrollBoxSlot
// Inherited Bytes: 0x38 | Struct Size: 0x58
struct UScrollBoxSlot : UPanelSlot {
	// Fields
	struct FMargin Padding; // Offset: 0x38 | Size: 0x10
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0x48 | Size: 0x1
	enum class EVerticalAlignment VerticalAlignment; // Offset: 0x49 | Size: 0x1
	char pad_0x4A[0xe]; // Offset: 0x4a | Size: 0xe

	// Functions

	// Object: Function UMG.ScrollBoxSlot.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cb98d0
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment);

	// Object: Function UMG.ScrollBoxSlot.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cb99d0
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetPadding(struct FMargin InPadding);

	// Object: Function UMG.ScrollBoxSlot.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cb9950
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment);
};

// Object: Class UMG.SizeBoxSlot
// Inherited Bytes: 0x38 | Struct Size: 0x60
struct USizeBoxSlot : UPanelSlot {
	// Fields
	struct FMargin Padding; // Offset: 0x38 | Size: 0x10
	char pad_0x48[0x10]; // Offset: 0x48 | Size: 0x10
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0x58 | Size: 0x1
	enum class EVerticalAlignment VerticalAlignment; // Offset: 0x59 | Size: 0x1
	char pad_0x5A[0x6]; // Offset: 0x5a | Size: 0x6

	// Functions

	// Object: Function UMG.SizeBoxSlot.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cbcedc
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment);

	// Object: Function UMG.SizeBoxSlot.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cbcfdc
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetPadding(struct FMargin InPadding);

	// Object: Function UMG.SizeBoxSlot.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cbcf5c
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment);
};

// Object: Class UMG.SlateBlueprintLibrary
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct USlateBlueprintLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object: Function UMG.SlateBlueprintLibrary.WidgetGlobalPostionToSubWidgetLocal
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults]
	// Offset: 0x104cbd490
	// Return & Params: [ Num(4) Size(0x50) ]
	void WidgetGlobalPostionToSubWidgetLocal(struct UObject* WorldContextObject, struct FGeometry& Geometry, struct FVector2D ScreenUIPosition, struct FVector2D& OutLocalUIPostion);

	// Object: Function UMG.SlateBlueprintLibrary.TransformVectorLocalToAbsolute
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x104cbe1b4
	// Return & Params: [ Num(3) Size(0x48) ]
	struct FVector2D TransformVectorLocalToAbsolute(struct FGeometry& Geometry, struct FVector2D LocalVector);

	// Object: Function UMG.SlateBlueprintLibrary.TransformVectorAbsoluteToLocal
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x104cbe294
	// Return & Params: [ Num(3) Size(0x48) ]
	struct FVector2D TransformVectorAbsoluteToLocal(struct FGeometry& Geometry, struct FVector2D AbsoluteVector);

	// Object: Function UMG.SlateBlueprintLibrary.TransformScalarLocalToAbsolute
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x104cbe374
	// Return & Params: [ Num(3) Size(0x40) ]
	float TransformScalarLocalToAbsolute(struct FGeometry& Geometry, float LocalScalar);

	// Object: Function UMG.SlateBlueprintLibrary.TransformScalarAbsoluteToLocal
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x104cbe45c
	// Return & Params: [ Num(3) Size(0x40) ]
	float TransformScalarAbsoluteToLocal(struct FGeometry& Geometry, float AbsoluteScalar);

	// Object: Function UMG.SlateBlueprintLibrary.ScreenToWidgetLocal
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults]
	// Offset: 0x104cbd870
	// Return & Params: [ Num(5) Size(0x51) ]
	void ScreenToWidgetLocal(struct UObject* WorldContextObject, struct FGeometry& Geometry, struct FVector2D ScreenPosition, struct FVector2D& LocalCoordinate, bool bIncludeWindowPosition);

	// Object: Function UMG.SlateBlueprintLibrary.ScreenToWidgetAbsolute
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults]
	// Offset: 0x104cbd70c
	// Return & Params: [ Num(4) Size(0x19) ]
	void ScreenToWidgetAbsolute(struct UObject* WorldContextObject, struct FVector2D ScreenPosition, struct FVector2D& AbsoluteCoordinate, bool bIncludeWindowPosition);

	// Object: Function UMG.SlateBlueprintLibrary.ScreenToViewport
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults]
	// Offset: 0x104cbd600
	// Return & Params: [ Num(3) Size(0x18) ]
	void ScreenToViewport(struct UObject* WorldContextObject, struct FVector2D ScreenPosition, struct FVector2D& ViewportPosition);

	// Object: Function UMG.SlateBlueprintLibrary.LocalToViewport
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x104cbdba0
	// Return & Params: [ Num(5) Size(0x58) ]
	void LocalToViewport(struct UObject* WorldContextObject, struct FGeometry& Geometry, struct FVector2D LocalCoordinate, struct FVector2D& PixelPosition, struct FVector2D& ViewportPosition);

	// Object: Function UMG.SlateBlueprintLibrary.LocalToAbsolute
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x104cbe700
	// Return & Params: [ Num(3) Size(0x48) ]
	struct FVector2D LocalToAbsolute(struct FGeometry& Geometry, struct FVector2D LocalCoordinate);

	// Object: Function UMG.SlateBlueprintLibrary.IsUnderLocation
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x104cbe8c0
	// Return & Params: [ Num(3) Size(0x41) ]
	bool IsUnderLocation(struct FGeometry& Geometry, struct FVector2D& AbsoluteCoordinate);

	// Object: Function UMG.SlateBlueprintLibrary.GetLocalTopLeft
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x104cbe66c
	// Return & Params: [ Num(2) Size(0x40) ]
	struct FVector2D GetLocalTopLeft(struct FGeometry& Geometry);

	// Object: Function UMG.SlateBlueprintLibrary.GetLocalSize
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x104cbe5d8
	// Return & Params: [ Num(2) Size(0x40) ]
	struct FVector2D GetLocalSize(struct FGeometry& Geometry);

	// Object: Function UMG.SlateBlueprintLibrary.GetAbsoluteSize
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x104cbe544
	// Return & Params: [ Num(2) Size(0x40) ]
	struct FVector2D GetAbsoluteSize(struct FGeometry& Geometry);

	// Object: Function UMG.SlateBlueprintLibrary.EqualEqual_SlateBrush
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x104cbdd6c
	// Return & Params: [ Num(3) Size(0x1c1) ]
	bool EqualEqual_SlateBrush(struct FSlateBrush& A, struct FSlateBrush& B);

	// Object: Function UMG.SlateBlueprintLibrary.AbsoluteToViewport
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x104cbda40
	// Return & Params: [ Num(4) Size(0x20) ]
	void AbsoluteToViewport(struct UObject* WorldContextObject, struct FVector2D AbsoluteDesktopCoordinate, struct FVector2D& PixelPosition, struct FVector2D& ViewportPosition);

	// Object: Function UMG.SlateBlueprintLibrary.AbsoluteToLocal
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x104cbe7e0
	// Return & Params: [ Num(3) Size(0x48) ]
	struct FVector2D AbsoluteToLocal(struct FGeometry& Geometry, struct FVector2D AbsoluteCoordinate);
};

// Object: Class UMG.SlateVectorArtData
// Inherited Bytes: 0x28 | Struct Size: 0x60
struct USlateVectorArtData : UObject {
	// Fields
	struct TArray<struct FSlateMeshVertex> VertexData; // Offset: 0x28 | Size: 0x10
	struct TArray<uint32_t> IndexData; // Offset: 0x38 | Size: 0x10
	struct UMaterialInterface* Material; // Offset: 0x48 | Size: 0x8
	struct FVector2D ExtentMin; // Offset: 0x50 | Size: 0x8
	struct FVector2D ExtentMax; // Offset: 0x58 | Size: 0x8
};

// Object: Class UMG.SlateAccessibleWidgetData
// Inherited Bytes: 0x28 | Struct Size: 0x80
struct USlateAccessibleWidgetData : UObject {
	// Fields
	bool bCanChildrenBeAccessible; // Offset: 0x28 | Size: 0x1
	enum class ESlateAccessibleBehavior AccessibleBehavior; // Offset: 0x29 | Size: 0x1
	enum class ESlateAccessibleBehavior AccessibleSummaryBehavior; // Offset: 0x2a | Size: 0x1
	char pad_0x2B[0x5]; // Offset: 0x2b | Size: 0x5
	struct FText AccessibleText; // Offset: 0x30 | Size: 0x18
	struct FDelegate AccessibleTextDelegate; // Offset: 0x48 | Size: 0x10
	struct FText AccessibleSummaryText; // Offset: 0x58 | Size: 0x18
	struct FDelegate AccessibleSummaryTextDelegate; // Offset: 0x70 | Size: 0x10
};

// Object: Class UMG.Spacer
// Inherited Bytes: 0x138 | Struct Size: 0x150
struct USpacer : UWidget {
	// Fields
	struct FVector2D Size; // Offset: 0x138 | Size: 0x8
	char pad_0x140[0x10]; // Offset: 0x140 | Size: 0x10

	// Functions

	// Object: Function UMG.Spacer.SetSize
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x104cc0d20
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetSize(struct FVector2D InSize);
};

// Object: Class UMG.SpinBox
// Inherited Bytes: 0x138 | Struct Size: 0x720
struct USpinBox : UWidget {
	// Fields
	float Value; // Offset: 0x138 | Size: 0x4
	struct FDelegate ValueDelegate; // Offset: 0x13c | Size: 0x10
	char pad_0x14C[0x4]; // Offset: 0x14c | Size: 0x4
	struct FSpinBoxStyle WidgetStyle; // Offset: 0x150 | Size: 0x4b0
	struct USlateWidgetStyleAsset* Style; // Offset: 0x600 | Size: 0x8
	int32_t MinFractionalDigits; // Offset: 0x608 | Size: 0x4
	int32_t MaxFractionalDigits; // Offset: 0x60c | Size: 0x4
	bool bAlwaysUsesDeltaSnap; // Offset: 0x610 | Size: 0x1
	char pad_0x611[0x3]; // Offset: 0x611 | Size: 0x3
	float Delta; // Offset: 0x614 | Size: 0x4
	float SliderExponent; // Offset: 0x618 | Size: 0x4
	char pad_0x61C[0x4]; // Offset: 0x61c | Size: 0x4
	struct FSlateFontInfo Font; // Offset: 0x620 | Size: 0x60
	enum class ETextJustify Justification; // Offset: 0x680 | Size: 0x1
	char pad_0x681[0x3]; // Offset: 0x681 | Size: 0x3
	float MinDesiredWidth; // Offset: 0x684 | Size: 0x4
	bool ClearKeyboardFocusOnCommit; // Offset: 0x688 | Size: 0x1
	bool SelectAllTextOnCommit; // Offset: 0x689 | Size: 0x1
	char pad_0x68A[0x6]; // Offset: 0x68a | Size: 0x6
	struct FSlateColor ForegroundColor; // Offset: 0x690 | Size: 0x28
	struct FMulticastInlineDelegate OnValueChanged; // Offset: 0x6b8 | Size: 0x10
	struct FMulticastInlineDelegate OnValueCommitted; // Offset: 0x6c8 | Size: 0x10
	struct FMulticastInlineDelegate OnBeginSliderMovement; // Offset: 0x6d8 | Size: 0x10
	struct FMulticastInlineDelegate OnEndSliderMovement; // Offset: 0x6e8 | Size: 0x10
	char bOverride_MinValue : 1; // Offset: 0x6f8 | Size: 0x1
	char bOverride_MaxValue : 1; // Offset: 0x6f8 | Size: 0x1
	char bOverride_MinSliderValue : 1; // Offset: 0x6f8 | Size: 0x1
	char bOverride_MaxSliderValue : 1; // Offset: 0x6f8 | Size: 0x1
	char pad_0x6F8_4 : 4; // Offset: 0x6f8 | Size: 0x1
	char pad_0x6F9[0x3]; // Offset: 0x6f9 | Size: 0x3
	float MinValue; // Offset: 0x6fc | Size: 0x4
	float MaxValue; // Offset: 0x700 | Size: 0x4
	float MinSliderValue; // Offset: 0x704 | Size: 0x4
	float MaxSliderValue; // Offset: 0x708 | Size: 0x4
	char pad_0x70C[0x14]; // Offset: 0x70c | Size: 0x14

	// Functions

	// Object: Function UMG.SpinBox.SetValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cc1854
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetValue(float NewValue);

	// Object: Function UMG.SpinBox.SetMinValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cc14c8
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetMinValue(float NewValue);

	// Object: Function UMG.SpinBox.SetMinSliderValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cc1338
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetMinSliderValue(float NewValue);

	// Object: Function UMG.SpinBox.SetMinFractionalDigits
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cc17a0
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetMinFractionalDigits(int32_t NewValue);

	// Object: Function UMG.SpinBox.SetMaxValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cc1400
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetMaxValue(float NewValue);

	// Object: Function UMG.SpinBox.SetMaxSliderValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cc1270
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetMaxSliderValue(float NewValue);

	// Object: Function UMG.SpinBox.SetMaxFractionalDigits
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cc16ec
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetMaxFractionalDigits(int32_t NewValue);

	// Object: Function UMG.SpinBox.SetForegroundColor
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cc10ec
	// Return & Params: [ Num(1) Size(0x28) ]
	void SetForegroundColor(struct FSlateColor InForegroundColor);

	// Object: Function UMG.SpinBox.SetDelta
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cc157c
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetDelta(float NewValue);

	// Object: Function UMG.SpinBox.SetAlwaysUsesDeltaSnap
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cc1630
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetAlwaysUsesDeltaSnap(bool bNewValue);

	// Object: DelegateFunction UMG.SpinBox.OnSpinBoxValueCommittedEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(2) Size(0x5) ]
	void OnSpinBoxValueCommittedEvent__DelegateSignature(float InValue, enum class ETextCommit CommitMethod);

	// Object: DelegateFunction UMG.SpinBox.OnSpinBoxValueChangedEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(1) Size(0x4) ]
	void OnSpinBoxValueChangedEvent__DelegateSignature(float InValue);

	// Object: DelegateFunction UMG.SpinBox.OnSpinBoxBeginSliderMovement__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnSpinBoxBeginSliderMovement__DelegateSignature();

	// Object: Function UMG.SpinBox.GetValue
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cc18d4
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetValue();

	// Object: Function UMG.SpinBox.GetMinValue
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cc1548
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetMinValue();

	// Object: Function UMG.SpinBox.GetMinSliderValue
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cc13b8
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetMinSliderValue();

	// Object: Function UMG.SpinBox.GetMinFractionalDigits
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cc1820
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetMinFractionalDigits();

	// Object: Function UMG.SpinBox.GetMaxValue
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cc1480
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetMaxValue();

	// Object: Function UMG.SpinBox.GetMaxSliderValue
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cc12f0
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetMaxSliderValue();

	// Object: Function UMG.SpinBox.GetMaxFractionalDigits
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cc176c
	// Return & Params: [ Num(1) Size(0x4) ]
	int32_t GetMaxFractionalDigits();

	// Object: Function UMG.SpinBox.GetDelta
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cc15fc
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetDelta();

	// Object: Function UMG.SpinBox.GetAlwaysUsesDeltaSnap
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cc16b8
	// Return & Params: [ Num(1) Size(0x1) ]
	bool GetAlwaysUsesDeltaSnap();

	// Object: Function UMG.SpinBox.ClearMinValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cc14b4
	// Return & Params: [ Num(0) Size(0x0) ]
	void ClearMinValue();

	// Object: Function UMG.SpinBox.ClearMinSliderValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cc1324
	// Return & Params: [ Num(0) Size(0x0) ]
	void ClearMinSliderValue();

	// Object: Function UMG.SpinBox.ClearMaxValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cc13ec
	// Return & Params: [ Num(0) Size(0x0) ]
	void ClearMaxValue();

	// Object: Function UMG.SpinBox.ClearMaxSliderValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cc125c
	// Return & Params: [ Num(0) Size(0x0) ]
	void ClearMaxSliderValue();
};

// Object: Class UMG.TextBinding
// Inherited Bytes: 0x60 | Struct Size: 0x68
struct UTextBinding : UPropertyBinding {
	// Fields
	char pad_0x60[0x8]; // Offset: 0x60 | Size: 0x8

	// Functions

	// Object: Function UMG.TextBinding.GetTextValue
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x104cc35a8
	// Return & Params: [ Num(1) Size(0x18) ]
	struct FText GetTextValue();

	// Object: Function UMG.TextBinding.GetStringValue
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x104cc3528
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetStringValue();
};

// Object: Class UMG.Throbber
// Inherited Bytes: 0x138 | Struct Size: 0x240
struct UThrobber : UWidget {
	// Fields
	int32_t NumberOfPieces; // Offset: 0x138 | Size: 0x4
	bool bAnimateHorizontally; // Offset: 0x13c | Size: 0x1
	bool bAnimateVertically; // Offset: 0x13d | Size: 0x1
	bool bAnimateOpacity; // Offset: 0x13e | Size: 0x1
	char pad_0x13F[0x1]; // Offset: 0x13f | Size: 0x1
	struct USlateBrushAsset* PieceImage; // Offset: 0x140 | Size: 0x8
	char pad_0x148[0x8]; // Offset: 0x148 | Size: 0x8
	struct FSlateBrush Image; // Offset: 0x150 | Size: 0xe0
	char pad_0x230[0x10]; // Offset: 0x230 | Size: 0x10

	// Functions

	// Object: Function UMG.Throbber.SetNumberOfPieces
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cc566c
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetNumberOfPieces(int32_t InNumberOfPieces);

	// Object: Function UMG.Throbber.SetAnimateVertically
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cc555c
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetAnimateVertically(bool bInAnimateVertically);

	// Object: Function UMG.Throbber.SetAnimateOpacity
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cc54d4
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetAnimateOpacity(bool bInAnimateOpacity);

	// Object: Function UMG.Throbber.SetAnimateHorizontally
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cc55e4
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetAnimateHorizontally(bool bInAnimateHorizontally);
};

// Object: Class UMG.UMGSequencePlayer
// Inherited Bytes: 0x28 | Struct Size: 0x7a8
struct UUMGSequencePlayer : UObject {
	// Fields
	char pad_0x28[0x3e0]; // Offset: 0x28 | Size: 0x3e0
	struct UWidgetAnimation* Animation; // Offset: 0x408 | Size: 0x8
	char pad_0x410[0x398]; // Offset: 0x410 | Size: 0x398

	// Functions

	// Object: Function UMG.UMGSequencePlayer.SetUserTag
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cc6368
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetUserTag(struct FName InUserTag);

	// Object: Function UMG.UMGSequencePlayer.GetUserTag
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cc63e8
	// Return & Params: [ Num(1) Size(0x8) ]
	struct FName GetUserTag();
};

// Object: Class UMG.UniformGridPanel
// Inherited Bytes: 0x150 | Struct Size: 0x178
struct UUniformGridPanel : UPanelWidget {
	// Fields
	struct FMargin SlotPadding; // Offset: 0x14c | Size: 0x10
	float MinDesiredSlotWidth; // Offset: 0x15c | Size: 0x4
	float MinDesiredSlotHeight; // Offset: 0x160 | Size: 0x4
	char pad_0x168[0x10]; // Offset: 0x168 | Size: 0x10

	// Functions

	// Object: Function UMG.UniformGridPanel.SetSlotPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cc6a00
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetSlotPadding(struct FMargin InSlotPadding);

	// Object: Function UMG.UniformGridPanel.SetMinDesiredSlotWidth
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cc6980
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetMinDesiredSlotWidth(float InMinDesiredSlotWidth);

	// Object: Function UMG.UniformGridPanel.SetMinDesiredSlotHeight
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cc6900
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetMinDesiredSlotHeight(float InMinDesiredSlotHeight);

	// Object: Function UMG.UniformGridPanel.AddChildToUniformGrid
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cc67dc
	// Return & Params: [ Num(4) Size(0x18) ]
	struct UUniformGridSlot* AddChildToUniformGrid(struct UWidget* Content, int32_t InRow, int32_t InColumn);
};

// Object: Class UMG.UniformGridSlot
// Inherited Bytes: 0x38 | Struct Size: 0x50
struct UUniformGridSlot : UPanelSlot {
	// Fields
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0x38 | Size: 0x1
	enum class EVerticalAlignment VerticalAlignment; // Offset: 0x39 | Size: 0x1
	char pad_0x3A[0x2]; // Offset: 0x3a | Size: 0x2
	int32_t Row; // Offset: 0x3c | Size: 0x4
	int32_t Column; // Offset: 0x40 | Size: 0x4
	char pad_0x44[0xc]; // Offset: 0x44 | Size: 0xc

	// Functions

	// Object: Function UMG.UniformGridSlot.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cc6e44
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment);

	// Object: Function UMG.UniformGridSlot.SetRow
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cc6fc4
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetRow(int32_t InRow);

	// Object: Function UMG.UniformGridSlot.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cc6ec4
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment);

	// Object: Function UMG.UniformGridSlot.SetColumn
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cc6f44
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetColumn(int32_t InColumn);
};

// Object: Class UMG.VerticalBox
// Inherited Bytes: 0x150 | Struct Size: 0x160
struct UVerticalBox : UPanelWidget {
	// Fields
	char pad_0x150[0x10]; // Offset: 0x150 | Size: 0x10

	// Functions

	// Object: Function UMG.VerticalBox.AddChildToVerticalBox
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cd1c04
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UVerticalBoxSlot* AddChildToVerticalBox(struct UWidget* Content);
};

// Object: Class UMG.VerticalBoxSlot
// Inherited Bytes: 0x38 | Struct Size: 0x60
struct UVerticalBoxSlot : UPanelSlot {
	// Fields
	struct FSlateChildSize Size; // Offset: 0x38 | Size: 0x8
	struct FMargin Padding; // Offset: 0x40 | Size: 0x10
	char pad_0x50[0x8]; // Offset: 0x50 | Size: 0x8
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0x58 | Size: 0x1
	enum class EVerticalAlignment VerticalAlignment; // Offset: 0x59 | Size: 0x1
	char pad_0x5A[0x6]; // Offset: 0x5a | Size: 0x6

	// Functions

	// Object: Function UMG.VerticalBoxSlot.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cd20ec
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment);

	// Object: Function UMG.VerticalBoxSlot.SetSize
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cd21ec
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetSize(struct FSlateChildSize InSize);

	// Object: Function UMG.VerticalBoxSlot.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cd2278
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetPadding(struct FMargin InPadding);

	// Object: Function UMG.VerticalBoxSlot.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cd216c
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment);
};

// Object: Class UMG.Viewport
// Inherited Bytes: 0x150 | Struct Size: 0x178
struct UViewport : UContentWidget {
	// Fields
	struct FLinearColor BackgroundColor; // Offset: 0x14c | Size: 0x10
	char pad_0x160[0x18]; // Offset: 0x160 | Size: 0x18

	// Functions

	// Object: Function UMG.Viewport.Spawn
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cd26bc
	// Return & Params: [ Num(2) Size(0x10) ]
	struct AActor* Spawn(struct AActor* ActorClass);

	// Object: Function UMG.Viewport.SetViewRotation
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x104cd274c
	// Return & Params: [ Num(1) Size(0xc) ]
	void SetViewRotation(struct FRotator Rotation);

	// Object: Function UMG.Viewport.SetViewLocation
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x104cd2804
	// Return & Params: [ Num(1) Size(0xc) ]
	void SetViewLocation(struct FVector Location);

	// Object: Function UMG.Viewport.GetViewRotation
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cd27cc
	// Return & Params: [ Num(1) Size(0xc) ]
	struct FRotator GetViewRotation();

	// Object: Function UMG.Viewport.GetViewportWorld
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cd28bc
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UWorld* GetViewportWorld();

	// Object: Function UMG.Viewport.GetViewLocation
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cd2884
	// Return & Params: [ Num(1) Size(0xc) ]
	struct FVector GetViewLocation();
};

// Object: Class UMG.VisibilityBinding
// Inherited Bytes: 0x60 | Struct Size: 0x60
struct UVisibilityBinding : UPropertyBinding {
	// Functions

	// Object: Function UMG.VisibilityBinding.GetValue
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x104cd2c8c
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class ESlateVisibility GetValue();
};

// Object: Class UMG.WidgetAnimation
// Inherited Bytes: 0x348 | Struct Size: 0x3b0
struct UWidgetAnimation : UMovieSceneSequence {
	// Fields
	struct UMovieScene* MovieScene; // Offset: 0x348 | Size: 0x8
	struct TArray<struct FWidgetAnimationBinding> AnimationBindings; // Offset: 0x350 | Size: 0x10
	bool bLegacyFinishOnStop; // Offset: 0x360 | Size: 0x1
	char pad_0x361[0x7]; // Offset: 0x361 | Size: 0x7
	struct FString DisplayLabel; // Offset: 0x368 | Size: 0x10
	enum class ESlateDetailMode DetailMode; // Offset: 0x378 | Size: 0x1
	char pad_0x379[0x7]; // Offset: 0x379 | Size: 0x7
	struct FSoftObjectPath OnAnimationStartedSound; // Offset: 0x380 | Size: 0x18
	struct FSoftObjectPath OnAnimationFinishedSound; // Offset: 0x398 | Size: 0x18

	// Functions

	// Object: Function UMG.WidgetAnimation.UnbindFromAnimationStarted
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cd6284
	// Return & Params: [ Num(2) Size(0x18) ]
	void UnbindFromAnimationStarted(struct UUserWidget* Widget, struct FDelegate Delegate);

	// Object: Function UMG.WidgetAnimation.UnbindFromAnimationFinished
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cd600c
	// Return & Params: [ Num(2) Size(0x18) ]
	void UnbindFromAnimationFinished(struct UUserWidget* Widget, struct FDelegate Delegate);

	// Object: Function UMG.WidgetAnimation.UnbindAllFromAnimationStarted
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cd6204
	// Return & Params: [ Num(1) Size(0x8) ]
	void UnbindAllFromAnimationStarted(struct UUserWidget* Widget);

	// Object: Function UMG.WidgetAnimation.UnbindAllFromAnimationFinished
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cd5f8c
	// Return & Params: [ Num(1) Size(0x8) ]
	void UnbindAllFromAnimationFinished(struct UUserWidget* Widget);

	// Object: Function UMG.WidgetAnimation.SetDetailMode
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cd5f04
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetDetailMode(enum class ESlateDetailMode InDetailMode);

	// Object: Function UMG.WidgetAnimation.GetStartTime
	// Flags: [Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cd64b0
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetStartTime();

	// Object: Function UMG.WidgetAnimation.GetEndTime
	// Flags: [Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104cd647c
	// Return & Params: [ Num(1) Size(0x4) ]
	float GetEndTime();

	// Object: Function UMG.WidgetAnimation.GetDisplayLabel
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cd5e20
	// Return & Params: [ Num(1) Size(0x10) ]
	struct FString GetDisplayLabel();

	// Object: Function UMG.WidgetAnimation.GetDetailModeBP
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cd5ee8
	// Return & Params: [ Num(1) Size(0x1) ]
	enum class ESlateDetailMode GetDetailModeBP();

	// Object: Function UMG.WidgetAnimation.BindToAnimationStarted
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cd6380
	// Return & Params: [ Num(2) Size(0x18) ]
	void BindToAnimationStarted(struct UUserWidget* Widget, struct FDelegate Delegate);

	// Object: Function UMG.WidgetAnimation.BindToAnimationFinished
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104cd6108
	// Return & Params: [ Num(2) Size(0x18) ]
	void BindToAnimationFinished(struct UUserWidget* Widget, struct FDelegate Delegate);
};

// Object: Class UMG.WidgetAnimationDelegateBinding
// Inherited Bytes: 0x28 | Struct Size: 0x38
struct UWidgetAnimationDelegateBinding : UDynamicBlueprintBinding {
	// Fields
	struct TArray<struct FBlueprintWidgetAnimationDelegateBinding> WidgetAnimationDelegateBindings; // Offset: 0x28 | Size: 0x10
};

// Object: Class UMG.WidgetAnimationPlayCallbackProxy
// Inherited Bytes: 0x28 | Struct Size: 0x48
struct UWidgetAnimationPlayCallbackProxy : UObject {
	// Fields
	struct FMulticastInlineDelegate Finished; // Offset: 0x28 | Size: 0x10
	char pad_0x38[0x10]; // Offset: 0x38 | Size: 0x10

	// Functions

	// Object: Function UMG.WidgetAnimationPlayCallbackProxy.CreatePlayAnimationTimeRangeProxyObject
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104cd8028
	// Return & Params: [ Num(9) Size(0x38) ]
	struct UWidgetAnimationPlayCallbackProxy* CreatePlayAnimationTimeRangeProxyObject(struct UUMGSequencePlayer*& Result, struct UUserWidget* Widget, struct UWidgetAnimation* InAnimation, float StartAtTime, float EndAtTime, int32_t NumLoopsToPlay, enum class EUMGSequencePlayMode PlayMode, float PlaybackSpeed);

	// Object: Function UMG.WidgetAnimationPlayCallbackProxy.CreatePlayAnimationProxyObject
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104cd82cc
	// Return & Params: [ Num(8) Size(0x30) ]
	struct UWidgetAnimationPlayCallbackProxy* CreatePlayAnimationProxyObject(struct UUMGSequencePlayer*& Result, struct UUserWidget* Widget, struct UWidgetAnimation* InAnimation, float StartAtTime, int32_t NumLoopsToPlay, enum class EUMGSequencePlayMode PlayMode, float PlaybackSpeed);
};

// Object: Class UMG.WidgetBinding
// Inherited Bytes: 0x60 | Struct Size: 0x60
struct UWidgetBinding : UPropertyBinding {
	// Functions

	// Object: Function UMG.WidgetBinding.GetValue
	// Flags: [Final|Native|Public|Const]
	// Offset: 0x104cd88ec
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UWidget* GetValue();
};

// Object: Class UMG.WidgetBlueprintGeneratedClass
// Inherited Bytes: 0x418 | Struct Size: 0x458
struct UWidgetBlueprintGeneratedClass : UBlueprintGeneratedClass {
	// Fields
	struct UWidgetTree* WidgetTree; // Offset: 0x418 | Size: 0x8
	char bClassRequiresNativeTick : 1; // Offset: 0x420 | Size: 0x1
	char pad_0x420_1 : 7; // Offset: 0x420 | Size: 0x1
	char pad_0x421[0x7]; // Offset: 0x421 | Size: 0x7
	struct TArray<struct FDelegateRuntimeBinding> Bindings; // Offset: 0x428 | Size: 0x10
	struct TArray<struct UWidgetAnimation*> Animations; // Offset: 0x438 | Size: 0x10
	struct TArray<struct FName> NamedSlots; // Offset: 0x448 | Size: 0x10
};

// Object: Class UMG.WidgetBlueprintLibrary
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UWidgetBlueprintLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object: Function UMG.WidgetBlueprintLibrary.UnlockMouse
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x104cdc580
	// Return & Params: [ Num(2) Size(0x170) ]
	struct FEventReply UnlockMouse(struct FEventReply& Reply);

	// Object: Function UMG.WidgetBlueprintLibrary.Unhandled
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x104cdcaa0
	// Return & Params: [ Num(1) Size(0xb8) ]
	struct FEventReply Unhandled();

	// Object: Function UMG.WidgetBlueprintLibrary.SetWindowTitleBarState
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104cd9088
	// Return & Params: [ Num(5) Size(0xc) ]
	void SetWindowTitleBarState(struct UWidget* TitleBarContent, enum class EWindowTitleBarMode Mode, bool bTitleBarDragEnabled, bool bWindowButtonsVisible, bool bTitleBarVisible);

	// Object: Function UMG.WidgetBlueprintLibrary.SetWindowTitleBarOnCloseClickedDelegate
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104cd8fc0
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetWindowTitleBarOnCloseClickedDelegate(struct FDelegate Delegate);

	// Object: Function UMG.WidgetBlueprintLibrary.SetWindowTitleBarCloseButtonActive
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104cd8f40
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetWindowTitleBarCloseButtonActive(bool bActive);

	// Object: Function UMG.WidgetBlueprintLibrary.SetUserFocus
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x104cdc3bc
	// Return & Params: [ Num(4) Size(0x180) ]
	struct FEventReply SetUserFocus(struct FEventReply& Reply, struct UWidget* FocusWidget, bool bInAllUsers);

	// Object: Function UMG.WidgetBlueprintLibrary.SetMousePosition
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x104cdbda0
	// Return & Params: [ Num(3) Size(0x178) ]
	struct FEventReply SetMousePosition(struct FEventReply& Reply, struct FVector2D NewMousePosition);

	// Object: Function UMG.WidgetBlueprintLibrary.SetInputMode_UIOnlyEx
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104cdd884
	// Return & Params: [ Num(3) Size(0x11) ]
	void SetInputMode_UIOnlyEx(struct APlayerController* PlayerController, struct UWidget* InWidgetToFocus, enum class EMouseLockMode InMouseLockMode);

	// Object: Function UMG.WidgetBlueprintLibrary.SetInputMode_UIOnly
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104cdd990
	// Return & Params: [ Num(3) Size(0x11) ]
	void SetInputMode_UIOnly(struct APlayerController* Target, struct UWidget* InWidgetToFocus, bool bLockMouseToViewport);

	// Object: Function UMG.WidgetBlueprintLibrary.SetInputMode_GameOnly
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104cdd540
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetInputMode_GameOnly(struct APlayerController* PlayerController);

	// Object: Function UMG.WidgetBlueprintLibrary.SetInputMode_GameAndUIEx
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104cdd5b8
	// Return & Params: [ Num(4) Size(0x12) ]
	void SetInputMode_GameAndUIEx(struct APlayerController* PlayerController, struct UWidget* InWidgetToFocus, enum class EMouseLockMode InMouseLockMode, bool bHideCursorDuringCapture);

	// Object: Function UMG.WidgetBlueprintLibrary.SetInputMode_GameAndUI
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104cdd718
	// Return & Params: [ Num(4) Size(0x12) ]
	void SetInputMode_GameAndUI(struct APlayerController* Target, struct UWidget* InWidgetToFocus, bool bLockMouseToViewport, bool bHideCursorDuringCapture);

	// Object: Function UMG.WidgetBlueprintLibrary.SetHardwareCursor
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x104cd9258
	// Return & Params: [ Num(5) Size(0x1d) ]
	bool SetHardwareCursor(struct UObject* WorldContextObject, enum class EMouseCursor CursorShape, struct FName CursorName, struct FVector2D HotSpot);

	// Object: Function UMG.WidgetBlueprintLibrary.SetFocusToGameViewport
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104cdd52c
	// Return & Params: [ Num(0) Size(0x0) ]
	void SetFocusToGameViewport();

	// Object: Function UMG.WidgetBlueprintLibrary.SetColorVisionDeficiencyType
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104cd93b4
	// Return & Params: [ Num(4) Size(0xa) ]
	void SetColorVisionDeficiencyType(enum class EColorVisionDeficiency Type, float Severity, bool CorrectDeficiency, bool ShowCorrectionWithDeficiency);

	// Object: Function UMG.WidgetBlueprintLibrary.SetBrushResourceToTexture
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104cda620
	// Return & Params: [ Num(2) Size(0xe8) ]
	void SetBrushResourceToTexture(struct FSlateBrush& Brush, struct UTexture2D* Texture);

	// Object: Function UMG.WidgetBlueprintLibrary.SetBrushResourceToMaterial
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104cda384
	// Return & Params: [ Num(2) Size(0xe8) ]
	void SetBrushResourceToMaterial(struct FSlateBrush& Brush, struct UMaterialInterface* Material);

	// Object: Function UMG.WidgetBlueprintLibrary.RestorePreviousWindowTitleBarState
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104cd9074
	// Return & Params: [ Num(0) Size(0x0) ]
	void RestorePreviousWindowTitleBarState();

	// Object: Function UMG.WidgetBlueprintLibrary.ReleaseMouseCapture
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x104cdc810
	// Return & Params: [ Num(2) Size(0x170) ]
	struct FEventReply ReleaseMouseCapture(struct FEventReply& Reply);

	// Object: Function UMG.WidgetBlueprintLibrary.ReleaseJoystickCapture
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x104cdbf08
	// Return & Params: [ Num(3) Size(0x178) ]
	struct FEventReply ReleaseJoystickCapture(struct FEventReply& Reply, bool bInAllJoysticks);

	// Object: DelegateFunction UMG.WidgetBlueprintLibrary.OnGameWindowCloseButtonClickedDelegate__DelegateSignature
	// Flags: [Public|Delegate]
	// Offset: 0x103cd7c78
	// Return & Params: [ Num(0) Size(0x0) ]
	void OnGameWindowCloseButtonClickedDelegate__DelegateSignature();

	// Object: Function UMG.WidgetBlueprintLibrary.NoResourceBrush
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x104cda1f4
	// Return & Params: [ Num(1) Size(0xe0) ]
	struct FSlateBrush NoResourceBrush();

	// Object: Function UMG.WidgetBlueprintLibrary.MakeBrushFromTexture
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x104cdb244
	// Return & Params: [ Num(4) Size(0xf0) ]
	struct FSlateBrush MakeBrushFromTexture(struct UTexture2D* Texture, int32_t Width, int32_t Height);

	// Object: Function UMG.WidgetBlueprintLibrary.MakeBrushFromMaterial
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x104cdafdc
	// Return & Params: [ Num(4) Size(0xf0) ]
	struct FSlateBrush MakeBrushFromMaterial(struct UMaterialInterface* Material, int32_t Width, int32_t Height);

	// Object: Function UMG.WidgetBlueprintLibrary.MakeBrushFromAsset
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x104cdb4ac
	// Return & Params: [ Num(2) Size(0xf0) ]
	struct FSlateBrush MakeBrushFromAsset(struct USlateBrushAsset* BrushAsset);

	// Object: Function UMG.WidgetBlueprintLibrary.LockMouse
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x104cdc6a0
	// Return & Params: [ Num(3) Size(0x178) ]
	struct FEventReply LockMouse(struct FEventReply& Reply, struct UWidget* CapturingWidget);

	// Object: Function UMG.WidgetBlueprintLibrary.IsDragDropping
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x104cdb6c8
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsDragDropping();

	// Object: Function UMG.WidgetBlueprintLibrary.Handled
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x104cdcb1c
	// Return & Params: [ Num(1) Size(0xb8) ]
	struct FEventReply Handled();

	// Object: Function UMG.WidgetBlueprintLibrary.GetSafeZonePadding
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x104cd9524
	// Return & Params: [ Num(4) Size(0x40) ]
	void GetSafeZonePadding(struct UObject* WorldContextObject, struct FVector4& SafePadding, struct FVector2D& SafePaddingScale, struct FVector4& SpillOverPadding);

	// Object: Function UMG.WidgetBlueprintLibrary.GetKeyEventFromAnalogInputEvent
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x104cd9964
	// Return & Params: [ Num(2) Size(0x78) ]
	struct FKeyEvent GetKeyEventFromAnalogInputEvent(struct FAnalogInputEvent& Event);

	// Object: Function UMG.WidgetBlueprintLibrary.GetInputEventFromPointerEvent
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x104cd9768
	// Return & Params: [ Num(2) Size(0x88) ]
	struct FInputEvent GetInputEventFromPointerEvent(struct FPointerEvent& Event);

	// Object: Function UMG.WidgetBlueprintLibrary.GetInputEventFromNavigationEvent
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x104cd96b4
	// Return & Params: [ Num(2) Size(0x38) ]
	struct FInputEvent GetInputEventFromNavigationEvent(struct FNavigationEvent& Event);

	// Object: Function UMG.WidgetBlueprintLibrary.GetInputEventFromKeyEvent
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x104cd9b78
	// Return & Params: [ Num(2) Size(0x50) ]
	struct FInputEvent GetInputEventFromKeyEvent(struct FKeyEvent& Event);

	// Object: Function UMG.WidgetBlueprintLibrary.GetInputEventFromCharacterEvent
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x104cd98b0
	// Return & Params: [ Num(2) Size(0x38) ]
	struct FInputEvent GetInputEventFromCharacterEvent(struct FCharacterEvent& Event);

	// Object: Function UMG.WidgetBlueprintLibrary.GetDynamicMaterial
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x104cd9f94
	// Return & Params: [ Num(2) Size(0xe8) ]
	struct UMaterialInstanceDynamic* GetDynamicMaterial(struct FSlateBrush& Brush);

	// Object: Function UMG.WidgetBlueprintLibrary.GetDragDroppingContent
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x104cdb694
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UDragDropOperation* GetDragDroppingContent();

	// Object: Function UMG.WidgetBlueprintLibrary.GetBrushResourceAsTexture2D
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x104cdab1c
	// Return & Params: [ Num(2) Size(0xe8) ]
	struct UTexture2D* GetBrushResourceAsTexture2D(struct FSlateBrush& Brush);

	// Object: Function UMG.WidgetBlueprintLibrary.GetBrushResourceAsMaterial
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x104cda8bc
	// Return & Params: [ Num(2) Size(0xe8) ]
	struct UMaterialInterface* GetBrushResourceAsMaterial(struct FSlateBrush& Brush);

	// Object: Function UMG.WidgetBlueprintLibrary.GetBrushResource
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x104cdad7c
	// Return & Params: [ Num(2) Size(0xe8) ]
	struct UObject* GetBrushResource(struct FSlateBrush& Brush);

	// Object: Function UMG.WidgetBlueprintLibrary.GetAllWidgetsWithInterface
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104cd9c98
	// Return & Params: [ Num(4) Size(0x21) ]
	void GetAllWidgetsWithInterface(struct UObject* WorldContextObject, struct TArray<struct UUserWidget*>& FoundWidgets, struct UInterface* Interface, bool TopLevelOnly);

	// Object: Function UMG.WidgetBlueprintLibrary.GetAllWidgetsOfClass
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104cd9e0c
	// Return & Params: [ Num(4) Size(0x21) ]
	void GetAllWidgetsOfClass(struct UObject* WorldContextObject, struct TArray<struct UUserWidget*>& FoundWidgets, struct UUserWidget* WidgetClass, bool TopLevelOnly);

	// Object: Function UMG.WidgetBlueprintLibrary.EndDragDrop
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x104cdb6fc
	// Return & Params: [ Num(2) Size(0x170) ]
	struct FEventReply EndDragDrop(struct FEventReply& Reply);

	// Object: Function UMG.WidgetBlueprintLibrary.DrawTextFormatted
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x104cdcb98
	// Return & Params: [ Num(7) Size(0x74) ]
	void DrawTextFormatted(struct FPaintContext& Context, struct FText& Text, struct FVector2D Position, struct UFont* Font, int32_t FontSize, struct FName FontTypeFace, struct FLinearColor Tint);

	// Object: Function UMG.WidgetBlueprintLibrary.DrawText
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x104cdce40
	// Return & Params: [ Num(4) Size(0x58) ]
	void DrawText(struct FPaintContext& Context, struct FString inString, struct FVector2D Position, struct FLinearColor Tint);

	// Object: Function UMG.WidgetBlueprintLibrary.DrawLines
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x104cdcfa4
	// Return & Params: [ Num(5) Size(0x58) ]
	void DrawLines(struct FPaintContext& Context, struct TArray<struct FVector2D>& Points, struct FLinearColor Tint, bool bAntiAlias, float Thickness);

	// Object: Function UMG.WidgetBlueprintLibrary.DrawLine
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x104cdd178
	// Return & Params: [ Num(6) Size(0x58) ]
	void DrawLine(struct FPaintContext& Context, struct FVector2D PositionA, struct FVector2D PositionB, struct FLinearColor Tint, bool bAntiAlias, float Thickness);

	// Object: Function UMG.WidgetBlueprintLibrary.DrawBox
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	// Offset: 0x104cdd384
	// Return & Params: [ Num(5) Size(0x58) ]
	void DrawBox(struct FPaintContext& Context, struct FVector2D Position, struct FVector2D Size, struct USlateBrushAsset* Brush, struct FLinearColor Tint);

	// Object: Function UMG.WidgetBlueprintLibrary.DismissAllMenus
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104cd9f80
	// Return & Params: [ Num(0) Size(0x0) ]
	void DismissAllMenus();

	// Object: Function UMG.WidgetBlueprintLibrary.DetectDragIfPressed
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104cdb81c
	// Return & Params: [ Num(4) Size(0x148) ]
	struct FEventReply DetectDragIfPressed(struct FPointerEvent& PointerEvent, struct UWidget* WidgetDetectingDrag, struct FKey DragKey);

	// Object: Function UMG.WidgetBlueprintLibrary.DetectDrag
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x104cdbb14
	// Return & Params: [ Num(4) Size(0x190) ]
	struct FEventReply DetectDrag(struct FEventReply& Reply, struct UWidget* WidgetDetectingDrag, struct FKey DragKey);

	// Object: Function UMG.WidgetBlueprintLibrary.CreateDragDropOperation
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104cddaa4
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UDragDropOperation* CreateDragDropOperation(struct UDragDropOperation* OperationClass);

	// Object: Function UMG.WidgetBlueprintLibrary.Create
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104cddb24
	// Return & Params: [ Num(4) Size(0x20) ]
	struct UUserWidget* Create(struct UObject* WorldContextObject, struct UUserWidget* WidgetType, struct APlayerController* OwningPlayer);

	// Object: Function UMG.WidgetBlueprintLibrary.ClearUserFocus
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x104cdc080
	// Return & Params: [ Num(3) Size(0x178) ]
	struct FEventReply ClearUserFocus(struct FEventReply& Reply, bool bInAllUsers);

	// Object: Function UMG.WidgetBlueprintLibrary.CaptureMouse
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x104cdc930
	// Return & Params: [ Num(3) Size(0x178) ]
	struct FEventReply CaptureMouse(struct FEventReply& Reply, struct UWidget* CapturingWidget);

	// Object: Function UMG.WidgetBlueprintLibrary.CaptureJoystick
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x104cdc1f8
	// Return & Params: [ Num(4) Size(0x180) ]
	struct FEventReply CaptureJoystick(struct FEventReply& Reply, struct UWidget* CapturingWidget, bool bInAllJoysticks);

	// Object: Function UMG.WidgetBlueprintLibrary.CancelDragDrop
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104cdb680
	// Return & Params: [ Num(0) Size(0x0) ]
	void CancelDragDrop();
};

// Object: Class UMG.WidgetInteractionComponent
// Inherited Bytes: 0x350 | Struct Size: 0x540
struct UWidgetInteractionComponent : USceneComponent {
	// Fields
	struct FMulticastInlineDelegate OnHoveredWidgetChanged; // Offset: 0x348 | Size: 0x10
	char pad_0x360[0x8]; // Offset: 0x360 | Size: 0x8
	int32_t VirtualUserIndex; // Offset: 0x368 | Size: 0x4
	float PointerIndex; // Offset: 0x36c | Size: 0x4
	enum class ECollisionChannel TraceChannel; // Offset: 0x370 | Size: 0x1
	char pad_0x371[0x3]; // Offset: 0x371 | Size: 0x3
	float InteractionDistance; // Offset: 0x374 | Size: 0x4
	enum class EWidgetInteractionSource InteractionSource; // Offset: 0x378 | Size: 0x1
	bool bEnableHitTesting; // Offset: 0x379 | Size: 0x1
	bool bShowDebug; // Offset: 0x37a | Size: 0x1
	char pad_0x37B[0x1]; // Offset: 0x37b | Size: 0x1
	struct FLinearColor DebugColor; // Offset: 0x37c | Size: 0x10
	char pad_0x38C[0x7c]; // Offset: 0x38c | Size: 0x7c
	struct FHitResult CustomHitResult; // Offset: 0x408 | Size: 0x88
	struct FVector2D LocalHitLocation; // Offset: 0x490 | Size: 0x8
	struct FVector2D LastLocalHitLocation; // Offset: 0x498 | Size: 0x8
	struct UWidgetComponent* HoveredWidgetComponent; // Offset: 0x4a0 | Size: 0x8
	struct FHitResult LastHitResult; // Offset: 0x4a8 | Size: 0x88
	bool bIsHoveredWidgetInteractable; // Offset: 0x530 | Size: 0x1
	bool bIsHoveredWidgetFocusable; // Offset: 0x531 | Size: 0x1
	bool bIsHoveredWidgetHitTestVisible; // Offset: 0x532 | Size: 0x1
	char pad_0x533[0xd]; // Offset: 0x533 | Size: 0xd

	// Functions

	// Object: Function UMG.WidgetInteractionComponent.SetFocus
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ce2568
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetFocus(struct UWidget* FocusWidget);

	// Object: Function UMG.WidgetInteractionComponent.SetCustomHitResult
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	// Offset: 0x104ce25e8
	// Return & Params: [ Num(1) Size(0x88) ]
	void SetCustomHitResult(struct FHitResult& HitResult);

	// Object: Function UMG.WidgetInteractionComponent.SendKeyChar
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104ce2880
	// Return & Params: [ Num(3) Size(0x12) ]
	bool SendKeyChar(struct FString Characters, bool bRepeat);

	// Object: Function UMG.WidgetInteractionComponent.ScrollWheel
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104ce27f8
	// Return & Params: [ Num(1) Size(0x4) ]
	void ScrollWheel(float ScrollDelta);

	// Object: Function UMG.WidgetInteractionComponent.ReleasePointerKey
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104ce2e78
	// Return & Params: [ Num(1) Size(0x18) ]
	void ReleasePointerKey(struct FKey Key);

	// Object: Function UMG.WidgetInteractionComponent.ReleaseKey
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104ce2b3c
	// Return & Params: [ Num(2) Size(0x19) ]
	bool ReleaseKey(struct FKey Key);

	// Object: Function UMG.WidgetInteractionComponent.PressPointerKey
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104ce2fdc
	// Return & Params: [ Num(1) Size(0x18) ]
	void PressPointerKey(struct FKey Key);

	// Object: Function UMG.WidgetInteractionComponent.PressKey
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104ce2cb0
	// Return & Params: [ Num(3) Size(0x1a) ]
	bool PressKey(struct FKey Key, bool bRepeat);

	// Object: Function UMG.WidgetInteractionComponent.PressAndReleaseKey
	// Flags: [Native|Public|BlueprintCallable]
	// Offset: 0x104ce29c8
	// Return & Params: [ Num(2) Size(0x19) ]
	bool PressAndReleaseKey(struct FKey Key);

	// Object: Function UMG.WidgetInteractionComponent.IsOverInteractableWidget
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ce2790
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsOverInteractableWidget();

	// Object: Function UMG.WidgetInteractionComponent.IsOverHitTestVisibleWidget
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ce2728
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsOverHitTestVisibleWidget();

	// Object: Function UMG.WidgetInteractionComponent.IsOverFocusableWidget
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ce275c
	// Return & Params: [ Num(1) Size(0x1) ]
	bool IsOverFocusableWidget();

	// Object: Function UMG.WidgetInteractionComponent.GetLastHitResult
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ce26c8
	// Return & Params: [ Num(1) Size(0x88) ]
	struct FHitResult GetLastHitResult();

	// Object: Function UMG.WidgetInteractionComponent.GetHoveredWidgetComponent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ce27c4
	// Return & Params: [ Num(1) Size(0x8) ]
	struct UWidgetComponent* GetHoveredWidgetComponent();

	// Object: Function UMG.WidgetInteractionComponent.Get2DHitLocation
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	// Offset: 0x104ce2690
	// Return & Params: [ Num(1) Size(0x8) ]
	struct FVector2D Get2DHitLocation();
};

// Object: Class UMG.WidgetLayoutLibrary
// Inherited Bytes: 0x28 | Struct Size: 0x28
struct UWidgetLayoutLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object: Function UMG.WidgetLayoutLibrary.SlotAsWrapBoxSlot
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x104ce3930
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UWrapBoxSlot* SlotAsWrapBoxSlot(struct UWidget* Widget);

	// Object: Function UMG.WidgetLayoutLibrary.SlotAsWidgetSwitcherSlot
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x104ce38b0
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UWidgetSwitcherSlot* SlotAsWidgetSwitcherSlot(struct UWidget* Widget);

	// Object: Function UMG.WidgetLayoutLibrary.SlotAsVerticalBoxSlot
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x104ce3bb0
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UVerticalBoxSlot* SlotAsVerticalBoxSlot(struct UWidget* Widget);

	// Object: Function UMG.WidgetLayoutLibrary.SlotAsUniformGridSlot
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x104ce3c30
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UUniformGridSlot* SlotAsUniformGridSlot(struct UWidget* Widget);

	// Object: Function UMG.WidgetLayoutLibrary.SlotAsSizeBoxSlot
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x104ce39b0
	// Return & Params: [ Num(2) Size(0x10) ]
	struct USizeBoxSlot* SlotAsSizeBoxSlot(struct UWidget* Widget);

	// Object: Function UMG.WidgetLayoutLibrary.SlotAsScrollBoxSlot
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x104ce3b30
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UScrollBoxSlot* SlotAsScrollBoxSlot(struct UWidget* Widget);

	// Object: Function UMG.WidgetLayoutLibrary.SlotAsScaleBoxSlot
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x104ce3a30
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UScaleBoxSlot* SlotAsScaleBoxSlot(struct UWidget* Widget);

	// Object: Function UMG.WidgetLayoutLibrary.SlotAsSafeBoxSlot
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x104ce3ab0
	// Return & Params: [ Num(2) Size(0x10) ]
	struct USafeZoneSlot* SlotAsSafeBoxSlot(struct UWidget* Widget);

	// Object: Function UMG.WidgetLayoutLibrary.SlotAsOverlaySlot
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x104ce3cb0
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UOverlaySlot* SlotAsOverlaySlot(struct UWidget* Widget);

	// Object: Function UMG.WidgetLayoutLibrary.SlotAsHorizontalBoxSlot
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x104ce3d30
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UHorizontalBoxSlot* SlotAsHorizontalBoxSlot(struct UWidget* Widget);

	// Object: Function UMG.WidgetLayoutLibrary.SlotAsGridSlot
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x104ce3db0
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UGridSlot* SlotAsGridSlot(struct UWidget* Widget);

	// Object: Function UMG.WidgetLayoutLibrary.SlotAsCanvasSlot
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x104ce3e30
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UCanvasPanelSlot* SlotAsCanvasSlot(struct UWidget* Widget);

	// Object: Function UMG.WidgetLayoutLibrary.SlotAsBorderSlot
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x104ce3eb0
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UBorderSlot* SlotAsBorderSlot(struct UWidget* Widget);

	// Object: Function UMG.WidgetLayoutLibrary.RemoveAllWidgets
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104ce3838
	// Return & Params: [ Num(1) Size(0x8) ]
	void RemoveAllWidgets(struct UObject* WorldContextObject);

	// Object: Function UMG.WidgetLayoutLibrary.ProjectWorldLocationToWidgetPosition
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x104ce4344
	// Return & Params: [ Num(5) Size(0x1e) ]
	bool ProjectWorldLocationToWidgetPosition(struct APlayerController* PlayerController, struct FVector WorldLocation, struct FVector2D& ScreenPosition, bool bPlayerViewportRelative);

	// Object: Function UMG.WidgetLayoutLibrary.GetViewportWidgetGeometry
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104ce41b4
	// Return & Params: [ Num(2) Size(0x40) ]
	struct FGeometry GetViewportWidgetGeometry(struct UObject* WorldContextObject);

	// Object: Function UMG.WidgetLayoutLibrary.GetViewportSize
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	// Offset: 0x104ce4240
	// Return & Params: [ Num(2) Size(0x10) ]
	struct FVector2D GetViewportSize(struct UObject* WorldContextObject);

	// Object: Function UMG.WidgetLayoutLibrary.GetViewportScale
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable|BlueprintPure]
	// Offset: 0x104ce42c4
	// Return & Params: [ Num(2) Size(0xc) ]
	float GetViewportScale(struct UObject* WorldContextObject);

	// Object: Function UMG.WidgetLayoutLibrary.GetPlayerScreenWidgetGeometry
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	// Offset: 0x104ce4128
	// Return & Params: [ Num(2) Size(0x40) ]
	struct FGeometry GetPlayerScreenWidgetGeometry(struct APlayerController* PlayerController);

	// Object: Function UMG.WidgetLayoutLibrary.GetMousePositionScaledByDPI
	// Flags: [Final|BlueprintCosmetic|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	// Offset: 0x104ce3f30
	// Return & Params: [ Num(4) Size(0x11) ]
	bool GetMousePositionScaledByDPI(struct APlayerController* Player, float& LocationX, float& LocationY);

	// Object: Function UMG.WidgetLayoutLibrary.GetMousePositionOnViewport
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x104ce406c
	// Return & Params: [ Num(2) Size(0x10) ]
	struct FVector2D GetMousePositionOnViewport(struct UObject* WorldContextObject);

	// Object: Function UMG.WidgetLayoutLibrary.GetMousePositionOnPlatform
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x104ce40f0
	// Return & Params: [ Num(1) Size(0x8) ]
	struct FVector2D GetMousePositionOnPlatform();
};

// Object: Class UMG.WidgetNavigation
// Inherited Bytes: 0x28 | Struct Size: 0x100
struct UWidgetNavigation : UObject {
	// Fields
	struct FWidgetNavigationData Up; // Offset: 0x28 | Size: 0x24
	struct FWidgetNavigationData Down; // Offset: 0x4c | Size: 0x24
	struct FWidgetNavigationData Left; // Offset: 0x70 | Size: 0x24
	struct FWidgetNavigationData Right; // Offset: 0x94 | Size: 0x24
	struct FWidgetNavigationData Next; // Offset: 0xb8 | Size: 0x24
	struct FWidgetNavigationData Previous; // Offset: 0xdc | Size: 0x24
};

// Object: Class UMG.WidgetSwitcherSlot
// Inherited Bytes: 0x38 | Struct Size: 0x58
struct UWidgetSwitcherSlot : UPanelSlot {
	// Fields
	char pad_0x38[0x8]; // Offset: 0x38 | Size: 0x8
	struct FMargin Padding; // Offset: 0x40 | Size: 0x10
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0x50 | Size: 0x1
	enum class EVerticalAlignment VerticalAlignment; // Offset: 0x51 | Size: 0x1
	char pad_0x52[0x6]; // Offset: 0x52 | Size: 0x6

	// Functions

	// Object: Function UMG.WidgetSwitcherSlot.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ce58ec
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment);

	// Object: Function UMG.WidgetSwitcherSlot.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ce59ec
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetPadding(struct FMargin InPadding);

	// Object: Function UMG.WidgetSwitcherSlot.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ce596c
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment);
};

// Object: Class UMG.WidgetTree
// Inherited Bytes: 0x28 | Struct Size: 0x30
struct UWidgetTree : UObject {
	// Fields
	struct UWidget* RootWidget; // Offset: 0x28 | Size: 0x8
};

// Object: Class UMG.WindowTitleBarArea
// Inherited Bytes: 0x150 | Struct Size: 0x168
struct UWindowTitleBarArea : UContentWidget {
	// Fields
	bool bWindowButtonsEnabled; // Offset: 0x149 | Size: 0x1
	bool bDoubleClickTogglesFullscreen; // Offset: 0x14a | Size: 0x1
	char pad_0x152[0x16]; // Offset: 0x152 | Size: 0x16

	// Functions

	// Object: Function UMG.WindowTitleBarArea.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ce613c
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment);

	// Object: Function UMG.WindowTitleBarArea.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ce623c
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetPadding(struct FMargin InPadding);

	// Object: Function UMG.WindowTitleBarArea.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ce61bc
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment);
};

// Object: Class UMG.WindowTitleBarAreaSlot
// Inherited Bytes: 0x38 | Struct Size: 0x60
struct UWindowTitleBarAreaSlot : UPanelSlot {
	// Fields
	struct FMargin Padding; // Offset: 0x38 | Size: 0x10
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0x48 | Size: 0x1
	enum class EVerticalAlignment VerticalAlignment; // Offset: 0x49 | Size: 0x1
	char pad_0x4A[0x16]; // Offset: 0x4a | Size: 0x16

	// Functions

	// Object: Function UMG.WindowTitleBarAreaSlot.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ce6590
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment);

	// Object: Function UMG.WindowTitleBarAreaSlot.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ce6690
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetPadding(struct FMargin InPadding);

	// Object: Function UMG.WindowTitleBarAreaSlot.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ce6610
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment);
};

// Object: Class UMG.WrapBox
// Inherited Bytes: 0x150 | Struct Size: 0x170
struct UWrapBox : UPanelWidget {
	// Fields
	struct FVector2D InnerSlotPadding; // Offset: 0x14c | Size: 0x8
	float WrapWidth; // Offset: 0x154 | Size: 0x4
	bool bExplicitWrapWidth; // Offset: 0x158 | Size: 0x1
	char pad_0x15D[0x13]; // Offset: 0x15d | Size: 0x13

	// Functions

	// Object: Function UMG.WrapBox.SetInnerSlotPadding
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	// Offset: 0x104ce6b18
	// Return & Params: [ Num(1) Size(0x8) ]
	void SetInnerSlotPadding(struct FVector2D InPadding);

	// Object: Function UMG.WrapBox.AddChildToWrapBox
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ce6a88
	// Return & Params: [ Num(2) Size(0x10) ]
	struct UWrapBoxSlot* AddChildToWrapBox(struct UWidget* Content);
};

// Object: Class UMG.WrapBoxSlot
// Inherited Bytes: 0x38 | Struct Size: 0x60
struct UWrapBoxSlot : UPanelSlot {
	// Fields
	struct FMargin Padding; // Offset: 0x38 | Size: 0x10
	bool bFillEmptySpace; // Offset: 0x48 | Size: 0x1
	char pad_0x49[0x3]; // Offset: 0x49 | Size: 0x3
	float FillSpanWhenLessThan; // Offset: 0x4c | Size: 0x4
	enum class EHorizontalAlignment HorizontalAlignment; // Offset: 0x50 | Size: 0x1
	enum class EVerticalAlignment VerticalAlignment; // Offset: 0x51 | Size: 0x1
	char pad_0x52[0xe]; // Offset: 0x52 | Size: 0xe

	// Functions

	// Object: Function UMG.WrapBoxSlot.SetVerticalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ce6e0c
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment);

	// Object: Function UMG.WrapBoxSlot.SetPadding
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ce7014
	// Return & Params: [ Num(1) Size(0x10) ]
	void SetPadding(struct FMargin InPadding);

	// Object: Function UMG.WrapBoxSlot.SetHorizontalAlignment
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ce6e8c
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment);

	// Object: Function UMG.WrapBoxSlot.SetFillSpanWhenLessThan
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ce6f0c
	// Return & Params: [ Num(1) Size(0x4) ]
	void SetFillSpanWhenLessThan(float InFillSpanWhenLessThan);

	// Object: Function UMG.WrapBoxSlot.SetFillEmptySpace
	// Flags: [Final|Native|Public|BlueprintCallable]
	// Offset: 0x104ce6f8c
	// Return & Params: [ Num(1) Size(0x1) ]
	void SetFillEmptySpace(bool InbFillEmptySpace);
};

