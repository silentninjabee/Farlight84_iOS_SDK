#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class AiPal.AiPalComponent
// Size: 0xb0 // Inherited bytes: 0xb0
struct UAiPalComponent : UActorComponent {
	// Functions

	// Object Name: Function AiPal.AiPalComponent.SetUserID
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetUserID(struct FString UserId); // Offset: 0x1016eea80 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AiPal.AiPalComponent.SetThreshold
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetThreshold(float ThresholdPer); // Offset: 0x1016eea00 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function AiPal.AiPalComponent.SetMaxDetectTimes
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetMaxDetectTimes(int32_t DetectGap_ms); // Offset: 0x1016ee900 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function AiPal.AiPalComponent.SetDetectGap_ms
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetDetectGap_ms(int32_t DetectGap_ms); // Offset: 0x1016ee980 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function AiPal.AiPalComponent.EndDetect
	// Flags: [Final|Native|Public|BlueprintCallable]
	void EndDetect(); // Offset: 0x1016ee8d8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AiPal.AiPalComponent.Capture
	// Flags: [Final|Native|Public|BlueprintCallable]
	void Capture(); // Offset: 0x1016ee8c4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AiPal.AiPalComponent.BeginDetect
	// Flags: [Final|Native|Public|BlueprintCallable]
	void BeginDetect(); // Offset: 0x1016ee8ec // Return & Params: Num(0) Size(0x0)
};

