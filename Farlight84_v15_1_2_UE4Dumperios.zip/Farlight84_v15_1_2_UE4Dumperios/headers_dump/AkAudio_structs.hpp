#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct AkAudio.AKWaapiJsonObject
// Size: 0x10 // Inherited bytes: 0x00
struct FAKWaapiJsonObject {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AkAudio.AkWaapiSubscriptionId
// Size: 0x08 // Inherited bytes: 0x00
struct FAkWaapiSubscriptionId {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct AkAudio.AkAdvancedInitializationSettings
// Size: 0x2c // Inherited bytes: 0x00
struct FAkAdvancedInitializationSettings {
	// Fields
	uint32_t IO_MemorySize; // Offset: 0x00 // Size: 0x04
	uint32_t IO_Granularity; // Offset: 0x04 // Size: 0x04
	float TargetAutoStreamBufferLength; // Offset: 0x08 // Size: 0x04
	bool UseStreamCache; // Offset: 0x0c // Size: 0x01
	char pad_0xD[0x3]; // Offset: 0x0d // Size: 0x03
	uint32_t MaximumPinnedBytesInCache; // Offset: 0x10 // Size: 0x04
	bool EnableGameSyncPreparation; // Offset: 0x14 // Size: 0x01
	char pad_0x15[0x3]; // Offset: 0x15 // Size: 0x03
	uint32_t ContinuousPlaybackLookAhead; // Offset: 0x18 // Size: 0x04
	uint32_t MonitorQueuePoolSize; // Offset: 0x1c // Size: 0x04
	uint32_t MaximumHardwareTimeoutMs; // Offset: 0x20 // Size: 0x04
	bool DebugOutOfRangeCheckEnabled; // Offset: 0x24 // Size: 0x01
	char pad_0x25[0x3]; // Offset: 0x25 // Size: 0x03
	float DebugOutOfRangeLimit; // Offset: 0x28 // Size: 0x04
};

// Object Name: ScriptStruct AkAudio.AkAdvancedInitializationSettingsWithMultiCoreRendering
// Size: 0x30 // Inherited bytes: 0x2c
struct FAkAdvancedInitializationSettingsWithMultiCoreRendering : FAkAdvancedInitializationSettings {
	// Fields
	bool EnableMultiCoreRendering; // Offset: 0x2c // Size: 0x01
	char pad_0x2D[0x3]; // Offset: 0x2d // Size: 0x03
};

// Object Name: ScriptStruct AkAudio.AkAndroidAdvancedInitializationSettings
// Size: 0x38 // Inherited bytes: 0x30
struct FAkAndroidAdvancedInitializationSettings : FAkAdvancedInitializationSettingsWithMultiCoreRendering {
	// Fields
	uint32_t AudioAPI; // Offset: 0x30 // Size: 0x04
	bool RoundFrameSizeToHardwareSize; // Offset: 0x34 // Size: 0x01
	char pad_0x35[0x3]; // Offset: 0x35 // Size: 0x03
};

// Object Name: ScriptStruct AkAudio.AkAudioSession
// Size: 0x0c // Inherited bytes: 0x00
struct FAkAudioSession {
	// Fields
	enum class EAkAudioSessionCategory AudioSessionCategory; // Offset: 0x00 // Size: 0x04
	uint32_t AudioSessionCategoryOptions; // Offset: 0x04 // Size: 0x04
	enum class EAkAudioSessionMode AudioSessionMode; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct AkAudio.AkExternalSourceInfo
// Size: 0x38 // Inherited bytes: 0x00
struct FAkExternalSourceInfo {
	// Fields
	struct FString ExternalSrcName; // Offset: 0x00 // Size: 0x10
	enum class AkCodecId CodecID; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x7]; // Offset: 0x11 // Size: 0x07
	struct FString Filename; // Offset: 0x18 // Size: 0x10
	struct UAkExternalMediaAsset* ExternalSourceAsset; // Offset: 0x28 // Size: 0x08
	bool IsStreamed; // Offset: 0x30 // Size: 0x01
	char pad_0x31[0x7]; // Offset: 0x31 // Size: 0x07
};

// Object Name: ScriptStruct AkAudio.AkSegmentInfo
// Size: 0x24 // Inherited bytes: 0x00
struct FAkSegmentInfo {
	// Fields
	int32_t CurrentPosition; // Offset: 0x00 // Size: 0x04
	int32_t PreEntryDuration; // Offset: 0x04 // Size: 0x04
	int32_t ActiveDuration; // Offset: 0x08 // Size: 0x04
	int32_t PostExitDuration; // Offset: 0x0c // Size: 0x04
	int32_t RemainingLookAheadTime; // Offset: 0x10 // Size: 0x04
	float BeatDuration; // Offset: 0x14 // Size: 0x04
	float BarDuration; // Offset: 0x18 // Size: 0x04
	float GridDuration; // Offset: 0x1c // Size: 0x04
	float GridOffset; // Offset: 0x20 // Size: 0x04
};

// Object Name: ScriptStruct AkAudio.AkMidiEventBase
// Size: 0x02 // Inherited bytes: 0x00
struct FAkMidiEventBase {
	// Fields
	enum class EAkMidiEventType Type; // Offset: 0x00 // Size: 0x01
	char Chan; // Offset: 0x01 // Size: 0x01
};

// Object Name: ScriptStruct AkAudio.AkMidiProgramChange
// Size: 0x03 // Inherited bytes: 0x02
struct FAkMidiProgramChange : FAkMidiEventBase {
	// Fields
	char ProgramNum; // Offset: 0x02 // Size: 0x01
};

// Object Name: ScriptStruct AkAudio.AkMidiChannelAftertouch
// Size: 0x03 // Inherited bytes: 0x02
struct FAkMidiChannelAftertouch : FAkMidiEventBase {
	// Fields
	char Value; // Offset: 0x02 // Size: 0x01
};

// Object Name: ScriptStruct AkAudio.AkMidiNoteAftertouch
// Size: 0x04 // Inherited bytes: 0x02
struct FAkMidiNoteAftertouch : FAkMidiEventBase {
	// Fields
	char Note; // Offset: 0x02 // Size: 0x01
	char Value; // Offset: 0x03 // Size: 0x01
};

// Object Name: ScriptStruct AkAudio.AkMidiPitchBend
// Size: 0x08 // Inherited bytes: 0x02
struct FAkMidiPitchBend : FAkMidiEventBase {
	// Fields
	char ValueLsb; // Offset: 0x02 // Size: 0x01
	char ValueMsb; // Offset: 0x03 // Size: 0x01
	int32_t FullValue; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct AkAudio.AkMidiCc
// Size: 0x04 // Inherited bytes: 0x02
struct FAkMidiCc : FAkMidiEventBase {
	// Fields
	enum class EAkMidiCcValues Cc; // Offset: 0x02 // Size: 0x01
	char Value; // Offset: 0x03 // Size: 0x01
};

// Object Name: ScriptStruct AkAudio.AkMidiNoteOnOff
// Size: 0x04 // Inherited bytes: 0x02
struct FAkMidiNoteOnOff : FAkMidiEventBase {
	// Fields
	char Note; // Offset: 0x02 // Size: 0x01
	char Velocity; // Offset: 0x03 // Size: 0x01
};

// Object Name: ScriptStruct AkAudio.AkMidiGeneric
// Size: 0x04 // Inherited bytes: 0x02
struct FAkMidiGeneric : FAkMidiEventBase {
	// Fields
	char Param1; // Offset: 0x02 // Size: 0x01
	char Param2; // Offset: 0x03 // Size: 0x01
};

// Object Name: ScriptStruct AkAudio.AkOutputSettings
// Size: 0x18 // Inherited bytes: 0x00
struct FAkOutputSettings {
	// Fields
	struct FString AudioDeviceSharesetName; // Offset: 0x00 // Size: 0x10
	int32_t IdDevice; // Offset: 0x10 // Size: 0x04
	enum class PanningRule PanRule; // Offset: 0x14 // Size: 0x01
	enum class AkChannelConfiguration ChannelConfig; // Offset: 0x15 // Size: 0x01
	char pad_0x16[0x2]; // Offset: 0x16 // Size: 0x02
};

// Object Name: ScriptStruct AkAudio.AkChannelMask
// Size: 0x04 // Inherited bytes: 0x00
struct FAkChannelMask {
	// Fields
	int32_t ChannelMask; // Offset: 0x00 // Size: 0x04
};

// Object Name: ScriptStruct AkAudio.AkGeometrySurfaceOverride
// Size: 0x18 // Inherited bytes: 0x00
struct FAkGeometrySurfaceOverride {
	// Fields
	struct UAkAcousticTexture* AcousticTexture; // Offset: 0x00 // Size: 0x08
	char bEnableOcclusionOverride : 1; // Offset: 0x08 // Size: 0x01
	char pad_0x8_1 : 7; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x3]; // Offset: 0x09 // Size: 0x03
	float OcclusionValue; // Offset: 0x0c // Size: 0x04
	float SurfaceArea; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct AkAudio.AkGeometryData
// Size: 0x50 // Inherited bytes: 0x00
struct FAkGeometryData {
	// Fields
	struct TArray<struct FVector> Vertices; // Offset: 0x00 // Size: 0x10
	struct TArray<struct FAkAcousticSurface> Surfaces; // Offset: 0x10 // Size: 0x10
	struct TArray<struct FAkTriangle> Triangles; // Offset: 0x20 // Size: 0x10
	struct TArray<struct UPhysicalMaterial*> ToOverrideAcousticTexture; // Offset: 0x30 // Size: 0x10
	struct TArray<struct UPhysicalMaterial*> ToOverrideOcclusion; // Offset: 0x40 // Size: 0x10
};

// Object Name: ScriptStruct AkAudio.AkTriangle
// Size: 0x08 // Inherited bytes: 0x00
struct FAkTriangle {
	// Fields
	uint16_t Point0; // Offset: 0x00 // Size: 0x02
	uint16_t Point1; // Offset: 0x02 // Size: 0x02
	uint16_t Point2; // Offset: 0x04 // Size: 0x02
	uint16_t Surface; // Offset: 0x06 // Size: 0x02
};

// Object Name: ScriptStruct AkAudio.AkAcousticSurface
// Size: 0x18 // Inherited bytes: 0x00
struct FAkAcousticSurface {
	// Fields
	uint32_t Texture; // Offset: 0x00 // Size: 0x04
	float Occlusion; // Offset: 0x04 // Size: 0x04
	struct FString Name; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct AkAudio.AkHololensAdvancedInitializationSettings
// Size: 0x30 // Inherited bytes: 0x30
struct FAkHololensAdvancedInitializationSettings : FAkAdvancedInitializationSettingsWithMultiCoreRendering {
	// Fields
	bool UseHeadMountedDisplayAudioDevice; // Offset: 0x2d // Size: 0x01
};

// Object Name: ScriptStruct AkAudio.AkPluginInfo
// Size: 0x28 // Inherited bytes: 0x00
struct FAkPluginInfo {
	// Fields
	struct FString Name; // Offset: 0x00 // Size: 0x10
	uint32_t PluginID; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct FString DLL; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct AkAudio.AkCommonInitializationSettings
// Size: 0x60 // Inherited bytes: 0x00
struct FAkCommonInitializationSettings {
	// Fields
	uint32_t MaximumNumberOfMemoryPools; // Offset: 0x00 // Size: 0x04
	uint32_t MaximumNumberOfPositioningPaths; // Offset: 0x04 // Size: 0x04
	uint32_t CommandQueueSize; // Offset: 0x08 // Size: 0x04
	uint32_t SamplesPerFrame; // Offset: 0x0c // Size: 0x04
	struct FAkMainOutputSettings MainOutputSettings; // Offset: 0x10 // Size: 0x28
	float StreamingLookAheadRatio; // Offset: 0x38 // Size: 0x04
	uint16_t NumberOfRefillsInVoice; // Offset: 0x3c // Size: 0x02
	char pad_0x3E[0x2]; // Offset: 0x3e // Size: 0x02
	struct FAkSpatialAudioSettings SpatialAudioSettings; // Offset: 0x40 // Size: 0x20
};

// Object Name: ScriptStruct AkAudio.AkSpatialAudioSettings
// Size: 0x20 // Inherited bytes: 0x00
struct FAkSpatialAudioSettings {
	// Fields
	uint32_t MaxSoundPropagationDepth; // Offset: 0x00 // Size: 0x04
	float MovementThreshold; // Offset: 0x04 // Size: 0x04
	uint32_t NumberOfPrimaryRays; // Offset: 0x08 // Size: 0x04
	uint32_t ReflectionOrder; // Offset: 0x0c // Size: 0x04
	float MaximumPathLength; // Offset: 0x10 // Size: 0x04
	float CPULimitPercentage; // Offset: 0x14 // Size: 0x04
	bool EnableDiffractionOnReflections; // Offset: 0x18 // Size: 0x01
	bool EnableGeometricDiffractionAndTransmission; // Offset: 0x19 // Size: 0x01
	bool CalcEmitterVirtualPosition; // Offset: 0x1a // Size: 0x01
	bool UseObstruction; // Offset: 0x1b // Size: 0x01
	bool UseOcclusion; // Offset: 0x1c // Size: 0x01
	char pad_0x1D[0x3]; // Offset: 0x1d // Size: 0x03
};

// Object Name: ScriptStruct AkAudio.AkMainOutputSettings
// Size: 0x28 // Inherited bytes: 0x00
struct FAkMainOutputSettings {
	// Fields
	struct FString AudioDeviceShareset; // Offset: 0x00 // Size: 0x10
	uint32_t DeviceID; // Offset: 0x10 // Size: 0x04
	enum class EAkPanningRule PanningRule; // Offset: 0x14 // Size: 0x04
	enum class EAkChannelConfigType ChannelConfigType; // Offset: 0x18 // Size: 0x04
	uint32_t ChannelMask; // Offset: 0x1c // Size: 0x04
	uint32_t NumberOfChannels; // Offset: 0x20 // Size: 0x04
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
};

// Object Name: ScriptStruct AkAudio.AkCommonInitializationSettingsWithSampleRate
// Size: 0x68 // Inherited bytes: 0x60
struct FAkCommonInitializationSettingsWithSampleRate : FAkCommonInitializationSettings {
	// Fields
	uint32_t SampleRate; // Offset: 0x60 // Size: 0x04
	char pad_0x64[0x4]; // Offset: 0x64 // Size: 0x04
};

// Object Name: ScriptStruct AkAudio.AkCommunicationSettings
// Size: 0x20 // Inherited bytes: 0x00
struct FAkCommunicationSettings {
	// Fields
	uint32_t PoolSize; // Offset: 0x00 // Size: 0x04
	uint16_t DiscoveryBroadcastPort; // Offset: 0x04 // Size: 0x02
	uint16_t CommandPort; // Offset: 0x06 // Size: 0x02
	uint16_t NotificationPort; // Offset: 0x08 // Size: 0x02
	char pad_0xA[0x6]; // Offset: 0x0a // Size: 0x06
	struct FString NetworkName; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct AkAudio.AkCommunicationSettingsWithCommSelection
// Size: 0x28 // Inherited bytes: 0x20
struct FAkCommunicationSettingsWithCommSelection : FAkCommunicationSettings {
	// Fields
	enum class EAkCommSystem CommunicationSystem; // Offset: 0x20 // Size: 0x04
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
};

// Object Name: ScriptStruct AkAudio.AkCommunicationSettingsWithSystemInitialization
// Size: 0x28 // Inherited bytes: 0x20
struct FAkCommunicationSettingsWithSystemInitialization : FAkCommunicationSettings {
	// Fields
	bool InitializeSystemComms; // Offset: 0x20 // Size: 0x01
	char pad_0x21[0x7]; // Offset: 0x21 // Size: 0x07
};

// Object Name: ScriptStruct AkAudio.AkBoolPropertyToControl
// Size: 0x10 // Inherited bytes: 0x00
struct FAkBoolPropertyToControl {
	// Fields
	struct FString ItemProperty; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AkAudio.AkPropertyToControl
// Size: 0x10 // Inherited bytes: 0x00
struct FAkPropertyToControl {
	// Fields
	struct FString ItemProperty; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AkAudio.AkPS4AdvancedInitializationSettings
// Size: 0x38 // Inherited bytes: 0x30
struct FAkPS4AdvancedInitializationSettings : FAkAdvancedInitializationSettingsWithMultiCoreRendering {
	// Fields
	uint32_t ACPBatchBufferSize; // Offset: 0x30 // Size: 0x04
	bool UseHardwareCodecLowLatencyMode; // Offset: 0x34 // Size: 0x01
	char pad_0x35[0x3]; // Offset: 0x35 // Size: 0x03
};

// Object Name: ScriptStruct AkAudio.AkReverbDescriptor
// Size: 0x28 // Inherited bytes: 0x00
struct FAkReverbDescriptor {
	// Fields
	char pad_0x0[0x28]; // Offset: 0x00 // Size: 0x28
};

// Object Name: ScriptStruct AkAudio.AkAcousticTextureParams
// Size: 0x20 // Inherited bytes: 0x00
struct FAkAcousticTextureParams {
	// Fields
	struct FVector4 AbsorptionValues; // Offset: 0x00 // Size: 0x10
	char pad_0x10[0x10]; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct AkAudio.AkGeometrySurfacePropertiesToMap
// Size: 0x30 // Inherited bytes: 0x00
struct FAkGeometrySurfacePropertiesToMap {
	// Fields
	struct TSoftObjectPtr<UAkAcousticTexture> AcousticTexture; // Offset: 0x00 // Size: 0x28
	float OcclusionValue; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
};

// Object Name: ScriptStruct AkAudio.AkWwiseItemToControl
// Size: 0x40 // Inherited bytes: 0x00
struct FAkWwiseItemToControl {
	// Fields
	struct FAkWwiseObjectDetails ItemPicked; // Offset: 0x00 // Size: 0x30
	struct FString ItemPath; // Offset: 0x30 // Size: 0x10
};

// Object Name: ScriptStruct AkAudio.AkWwiseObjectDetails
// Size: 0x30 // Inherited bytes: 0x00
struct FAkWwiseObjectDetails {
	// Fields
	struct FString ItemName; // Offset: 0x00 // Size: 0x10
	struct FString ItemPath; // Offset: 0x10 // Size: 0x10
	struct FString ItemID; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct AkAudio.AkSurfaceProperties
// Size: 0x40 // Inherited bytes: 0x00
struct FAkSurfaceProperties {
	// Fields
	char pad_0x0[0x40]; // Offset: 0x00 // Size: 0x40
};

// Object Name: ScriptStruct AkAudio.AkEdgeInfo
// Size: 0x28 // Inherited bytes: 0x00
struct FAkEdgeInfo {
	// Fields
	char pad_0x0[0x28]; // Offset: 0x00 // Size: 0x28
};

// Object Name: ScriptStruct AkAudio.AkPoly
// Size: 0x18 // Inherited bytes: 0x00
struct FAkPoly {
	// Fields
	struct UAkAcousticTexture* Texture; // Offset: 0x00 // Size: 0x08
	float Occlusion; // Offset: 0x08 // Size: 0x04
	bool EnableSurface; // Offset: 0x0c // Size: 0x01
	char pad_0xD[0x3]; // Offset: 0x0d // Size: 0x03
	float SurfaceArea; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct AkAudio.AkWaapiFieldNames
// Size: 0x10 // Inherited bytes: 0x00
struct FAkWaapiFieldNames {
	// Fields
	struct FString FieldName; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AkAudio.AkWaapiUri
// Size: 0x10 // Inherited bytes: 0x00
struct FAkWaapiUri {
	// Fields
	struct FString Uri; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct AkAudio.AkWindowsAdvancedInitializationSettings
// Size: 0x34 // Inherited bytes: 0x30
struct FAkWindowsAdvancedInitializationSettings : FAkAdvancedInitializationSettingsWithMultiCoreRendering {
	// Fields
	bool UseHeadMountedDisplayAudioDevice; // Offset: 0x2d // Size: 0x01
	uint32_t MaxSystemAudioObjects; // Offset: 0x30 // Size: 0x04
};

// Object Name: ScriptStruct AkAudio.AkXboxOneApuHeapInitializationSettings
// Size: 0x08 // Inherited bytes: 0x00
struct FAkXboxOneApuHeapInitializationSettings {
	// Fields
	uint32_t CachedSize; // Offset: 0x00 // Size: 0x04
	uint32_t NonCachedSize; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct AkAudio.AkXboxOneAdvancedInitializationSettings
// Size: 0x34 // Inherited bytes: 0x30
struct FAkXboxOneAdvancedInitializationSettings : FAkAdvancedInitializationSettingsWithMultiCoreRendering {
	// Fields
	uint16_t MaximumNumberOfXMAVoices; // Offset: 0x2e // Size: 0x02
	bool UseHardwareCodecLowLatencyMode; // Offset: 0x30 // Size: 0x01
	char pad_0x33[0x1]; // Offset: 0x33 // Size: 0x01
};

// Object Name: ScriptStruct AkAudio.BankHandler
// Size: 0x40 // Inherited bytes: 0x00
struct FBankHandler {
	// Fields
	struct FString BankName; // Offset: 0x00 // Size: 0x10
	enum class EBankLoadStatus LoadStatus; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x3]; // Offset: 0x11 // Size: 0x03
	int32_t LoadCounter; // Offset: 0x14 // Size: 0x04
	int32_t CounterPendingIncrement; // Offset: 0x18 // Size: 0x04
	struct FDelegate LoadCallback; // Offset: 0x1c // Size: 0x10
	struct FDelegate UnloadCallback; // Offset: 0x2c // Size: 0x10
	char pad_0x3C[0x4]; // Offset: 0x3c // Size: 0x04
};

// Object Name: ScriptStruct AkAudio.EventCooldownData
// Size: 0x50 // Inherited bytes: 0x00
struct FEventCooldownData {
	// Fields
	struct TMap<struct FString, float> Data; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct AkAudio.CachedGameSyncData
// Size: 0xa0 // Inherited bytes: 0x00
struct FCachedGameSyncData {
	// Fields
	struct TMap<struct FString, float> RTPCData; // Offset: 0x00 // Size: 0x50
	struct TMap<struct FString, struct FString> SwitchData; // Offset: 0x50 // Size: 0x50
};

// Object Name: ScriptStruct AkAudio.AkAudioEventTrackKey
// Size: 0x20 // Inherited bytes: 0x00
struct FAkAudioEventTrackKey {
	// Fields
	float Time; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct UAkAudioEvent* AkAudioEvent; // Offset: 0x08 // Size: 0x08
	struct FString EventName; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct AkAudio.MovieSceneAkAudioEventTemplate
// Size: 0x20 // Inherited bytes: 0x18
struct FMovieSceneAkAudioEventTemplate : FMovieSceneEvalTemplate {
	// Fields
	struct UMovieSceneAkAudioEventSection* Section; // Offset: 0x18 // Size: 0x08
};

// Object Name: ScriptStruct AkAudio.MovieSceneAkAudioRTPCTemplate
// Size: 0x20 // Inherited bytes: 0x18
struct FMovieSceneAkAudioRTPCTemplate : FMovieSceneEvalTemplate {
	// Fields
	struct UMovieSceneAkAudioRTPCSection* Section; // Offset: 0x18 // Size: 0x08
};

// Object Name: ScriptStruct AkAudio.MovieSceneFloatChannelSerializationHelper
// Size: 0x30 // Inherited bytes: 0x00
struct FMovieSceneFloatChannelSerializationHelper {
	// Fields
	enum class ERichCurveExtrapolation PreInfinityExtrap; // Offset: 0x00 // Size: 0x01
	enum class ERichCurveExtrapolation PostInfinityExtrap; // Offset: 0x01 // Size: 0x01
	char pad_0x2[0x6]; // Offset: 0x02 // Size: 0x06
	struct TArray<int32_t> Times; // Offset: 0x08 // Size: 0x10
	struct TArray<struct FMovieSceneFloatValueSerializationHelper> Values; // Offset: 0x18 // Size: 0x10
	float DefaultValue; // Offset: 0x28 // Size: 0x04
	bool bHasDefaultValue; // Offset: 0x2c // Size: 0x01
	char pad_0x2D[0x3]; // Offset: 0x2d // Size: 0x03
};

// Object Name: ScriptStruct AkAudio.MovieSceneFloatValueSerializationHelper
// Size: 0x1c // Inherited bytes: 0x00
struct FMovieSceneFloatValueSerializationHelper {
	// Fields
	float Value; // Offset: 0x00 // Size: 0x04
	enum class ERichCurveInterpMode InterpMode; // Offset: 0x04 // Size: 0x01
	enum class ERichCurveTangentMode TangentMode; // Offset: 0x05 // Size: 0x01
	char pad_0x6[0x2]; // Offset: 0x06 // Size: 0x02
	struct FMovieSceneTangentDataSerializationHelper Tangent; // Offset: 0x08 // Size: 0x14
};

// Object Name: ScriptStruct AkAudio.MovieSceneTangentDataSerializationHelper
// Size: 0x14 // Inherited bytes: 0x00
struct FMovieSceneTangentDataSerializationHelper {
	// Fields
	float ArriveTangent; // Offset: 0x00 // Size: 0x04
	float LeaveTangent; // Offset: 0x04 // Size: 0x04
	enum class ERichCurveTangentWeightMode TangentWeightMode; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x3]; // Offset: 0x09 // Size: 0x03
	float ArriveTangentWeight; // Offset: 0x0c // Size: 0x04
	float LeaveTangentWeight; // Offset: 0x10 // Size: 0x04
};

// Object Name: ScriptStruct AkAudio.WwiseDataRow
// Size: 0x50 // Inherited bytes: 0x08
struct FWwiseDataRow : FTableRowBase {
	// Fields
	struct FString SoundbankName; // Offset: 0x08 // Size: 0x10
	struct TSoftObjectPtr<UAkAudioEvent> RealAkEvent; // Offset: 0x18 // Size: 0x28
	struct FGuid EventGuid; // Offset: 0x40 // Size: 0x10
};

