#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class AnimationCore.AnimationDataSourceRegistry
// Size: 0x78 // Inherited bytes: 0x28
struct UAnimationDataSourceRegistry : UObject {
	// Fields
	struct TMap<struct FName, struct TWeakObjectPtr<struct UObject>> DataSources; // Offset: 0x28 // Size: 0x50
};

