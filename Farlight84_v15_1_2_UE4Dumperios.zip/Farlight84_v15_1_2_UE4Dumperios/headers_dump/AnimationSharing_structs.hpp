#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct AnimationSharing.TickAnimationSharingFunction
// Size: 0x30 // Inherited bytes: 0x28
struct FTickAnimationSharingFunction : FTickFunction {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08
};

// Object Name: ScriptStruct AnimationSharing.AnimationSharingScalability
// Size: 0x10 // Inherited bytes: 0x00
struct FAnimationSharingScalability {
	// Fields
	struct FPerPlatformBool UseBlendTransitions; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	struct FPerPlatformFloat BlendSignificanceValue; // Offset: 0x04 // Size: 0x04
	struct FPerPlatformInt MaximumNumberConcurrentBlends; // Offset: 0x08 // Size: 0x04
	struct FPerPlatformFloat TickSignificanceValue; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct AnimationSharing.PerSkeletonAnimationSharingSetup
// Size: 0x38 // Inherited bytes: 0x00
struct FPerSkeletonAnimationSharingSetup {
	// Fields
	struct USkeleton* Skeleton; // Offset: 0x00 // Size: 0x08
	struct USkeletalMesh* SkeletalMesh; // Offset: 0x08 // Size: 0x08
	struct UAnimSharingTransitionInstance* BlendAnimBlueprint; // Offset: 0x10 // Size: 0x08
	struct UAnimSharingAdditiveInstance* AdditiveAnimBlueprint; // Offset: 0x18 // Size: 0x08
	struct UAnimationSharingStateProcessor* StateProcessorClass; // Offset: 0x20 // Size: 0x08
	struct TArray<struct FAnimationStateEntry> AnimationStates; // Offset: 0x28 // Size: 0x10
};

// Object Name: ScriptStruct AnimationSharing.AnimationStateEntry
// Size: 0x30 // Inherited bytes: 0x00
struct FAnimationStateEntry {
	// Fields
	char State; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct TArray<struct FAnimationSetup> AnimationSetups; // Offset: 0x08 // Size: 0x10
	bool bOnDemand; // Offset: 0x18 // Size: 0x01
	bool bAdditive; // Offset: 0x19 // Size: 0x01
	char pad_0x1A[0x2]; // Offset: 0x1a // Size: 0x02
	float BlendTime; // Offset: 0x1c // Size: 0x04
	bool bReturnToPreviousState; // Offset: 0x20 // Size: 0x01
	bool bSetNextState; // Offset: 0x21 // Size: 0x01
	char NextState; // Offset: 0x22 // Size: 0x01
	char pad_0x23[0x1]; // Offset: 0x23 // Size: 0x01
	struct FPerPlatformInt MaximumNumberOfConcurrentInstances; // Offset: 0x24 // Size: 0x04
	float WiggleTimePercentage; // Offset: 0x28 // Size: 0x04
	bool bRequiresCurves; // Offset: 0x2c // Size: 0x01
	char pad_0x2D[0x3]; // Offset: 0x2d // Size: 0x03
};

// Object Name: ScriptStruct AnimationSharing.AnimationSetup
// Size: 0x18 // Inherited bytes: 0x00
struct FAnimationSetup {
	// Fields
	struct UAnimSequence* AnimSequence; // Offset: 0x00 // Size: 0x08
	struct UAnimSharingStateInstance* AnimBlueprint; // Offset: 0x08 // Size: 0x08
	struct FPerPlatformInt NumRandomizedInstances; // Offset: 0x10 // Size: 0x04
	struct FPerPlatformBool Enabled; // Offset: 0x14 // Size: 0x01
	char pad_0x15[0x3]; // Offset: 0x15 // Size: 0x03
};

