#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class AnoSDK.AnoSDK
// Size: 0x88 // Inherited bytes: 0x28
struct UAnoSDK : UObject {
	// Fields
	struct FMulticastInlineDelegate OnAnoRecvAntiData; // Offset: 0x28 // Size: 0x10
	char pad_0x38[0x8]; // Offset: 0x38 // Size: 0x08
	struct FMulticastInlineDelegate OnAnoSentDataToSvr; // Offset: 0x40 // Size: 0x10
	char pad_0x50[0x8]; // Offset: 0x50 // Size: 0x08
	struct FMulticastInlineDelegate OnAnoSentCoreData; // Offset: 0x58 // Size: 0x10
	char pad_0x68[0x8]; // Offset: 0x68 // Size: 0x08
	struct FMulticastInlineDelegate OnAnoSentCoreTimeData; // Offset: 0x70 // Size: 0x10
	char pad_0x80[0x8]; // Offset: 0x80 // Size: 0x08

	// Functions

	// Object Name: DelegateFunction AnoSDK.AnoSDK.OnAnoSentAntiData__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnAnoSentAntiData__DelegateSignature(struct FAnoSDKAntiData AntiData); // Offset: 0x103938968 // Return & Params: Num(1) Size(0x18)

	// Object Name: DelegateFunction AnoSDK.AnoSDK.OnAnoRecvAntiData__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnAnoRecvAntiData__DelegateSignature(int32_t Type, struct FString AntiData); // Offset: 0x103938968 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function AnoSDK.AnoSDK.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UAnoSDK* GetInstance(); // Offset: 0x10227c8ac // Return & Params: Num(1) Size(0x8)

	// Object Name: Function AnoSDK.AnoSDK.DestoryInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void DestoryInstance(); // Offset: 0x10227c898 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AnoSDK.AnoSDK.AnoUESDKSetUserInfo
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void AnoUESDKSetUserInfo(enum class ETssSDKEntryId EntryId, struct FString OpenId); // Offset: 0x10227c2e0 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function AnoSDK.AnoSDK.AnoUESDKSetCSChannelDomain
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void AnoUESDKSetCSChannelDomain(struct FString DomainName); // Offset: 0x10227c658 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AnoSDK.AnoSDK.AnoUESDKSetChannelIP
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void AnoUESDKSetChannelIP(struct FString IP); // Offset: 0x10227c6dc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AnoSDK.AnoSDK.AnoUESDKSendSDKCoreData
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void AnoUESDKSendSDKCoreData(); // Offset: 0x10227c20c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AnoSDK.AnoSDK.AnoUESDKSendDataToSvr
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void AnoUESDKSendDataToSvr(); // Offset: 0x10227c220 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AnoSDK.AnoSDK.AnoUESDKSendCoreTimeData
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void AnoUESDKSendCoreTimeData(); // Offset: 0x10227c1f8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AnoSDK.AnoSDK.AnoUESDKReportThreadShutDown
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void AnoUESDKReportThreadShutDown(); // Offset: 0x10227c1bc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AnoSDK.AnoSDK.AnoUESDKReportThreadInit
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void AnoUESDKReportThreadInit(); // Offset: 0x10227c1d0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AnoSDK.AnoSDK.AnoUESDKRegistInfoListener
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void AnoUESDKRegistInfoListener(); // Offset: 0x10227c1e4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AnoSDK.AnoSDK.AnoUESDKOnResume
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void AnoUESDKOnResume(); // Offset: 0x10227c2cc // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AnoSDK.AnoSDK.AnoUESDKOnRecvSignature
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void AnoUESDKOnRecvSignature(struct FString Name, struct FString Buf, int32_t Len, int32_t Crc); // Offset: 0x10227c4e8 // Return & Params: Num(4) Size(0x28)

	// Object Name: Function AnoSDK.AnoSDK.AnoUESDKOnRecvData
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void AnoUESDKOnRecvData(struct FString Data); // Offset: 0x10227c234 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AnoSDK.AnoSDK.AnoUESDKOnPause
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void AnoUESDKOnPause(); // Offset: 0x10227c2b8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AnoSDK.AnoSDK.AnoUESDKIoctl
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void AnoUESDKIoctl(int32_t Request, struct FString Cmd); // Offset: 0x10227c760 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function AnoSDK.AnoSDK.AnoUESDKInit
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void AnoUESDKInit(int32_t GameID, struct FString Appkey); // Offset: 0x10227c418 // Return & Params: Num(2) Size(0x18)
};

// Object Name: Class AnoSDK.AnoSDKSettings
// Size: 0x40 // Inherited bytes: 0x38
struct UAnoSDKSettings : UDeveloperSettings {
	// Fields
	bool bEnableAnoSDK; // Offset: 0x38 // Size: 0x01
	char pad_0x39[0x7]; // Offset: 0x39 // Size: 0x07
};

