#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class AudioExtensions.SoundfieldEncodingSettingsBase
// Size: 0x28 // Inherited bytes: 0x28
struct USoundfieldEncodingSettingsBase : UObject {
};

// Object Name: Class AudioExtensions.AudioEndpointSettingsBase
// Size: 0x28 // Inherited bytes: 0x28
struct UAudioEndpointSettingsBase : UObject {
};

// Object Name: Class AudioExtensions.SpatializationPluginSourceSettingsBase
// Size: 0x28 // Inherited bytes: 0x28
struct USpatializationPluginSourceSettingsBase : UObject {
};

// Object Name: Class AudioExtensions.OcclusionPluginSourceSettingsBase
// Size: 0x28 // Inherited bytes: 0x28
struct UOcclusionPluginSourceSettingsBase : UObject {
};

// Object Name: Class AudioExtensions.SoundModulationPluginSourceSettingsBase
// Size: 0x28 // Inherited bytes: 0x28
struct USoundModulationPluginSourceSettingsBase : UObject {
};

// Object Name: Class AudioExtensions.ReverbPluginSourceSettingsBase
// Size: 0x28 // Inherited bytes: 0x28
struct UReverbPluginSourceSettingsBase : UObject {
};

// Object Name: Class AudioExtensions.SoundfieldEndpointSettingsBase
// Size: 0x28 // Inherited bytes: 0x28
struct USoundfieldEndpointSettingsBase : UObject {
};

// Object Name: Class AudioExtensions.SoundfieldEffectSettingsBase
// Size: 0x28 // Inherited bytes: 0x28
struct USoundfieldEffectSettingsBase : UObject {
};

// Object Name: Class AudioExtensions.SoundfieldEffectBase
// Size: 0x30 // Inherited bytes: 0x28
struct USoundfieldEffectBase : UObject {
	// Fields
	struct USoundfieldEffectSettingsBase* Settings; // Offset: 0x28 // Size: 0x08
};

