#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct AudioPlatformConfiguration.PlatformRuntimeAudioCompressionOverrides
// Size: 0x10 // Inherited bytes: 0x00
struct FPlatformRuntimeAudioCompressionOverrides {
	// Fields
	bool bOverrideCompressionTimes; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float DurationThreshold; // Offset: 0x04 // Size: 0x04
	int32_t MaxNumRandomBranches; // Offset: 0x08 // Size: 0x04
	int32_t SoundCueQualityIndex; // Offset: 0x0c // Size: 0x04
};

