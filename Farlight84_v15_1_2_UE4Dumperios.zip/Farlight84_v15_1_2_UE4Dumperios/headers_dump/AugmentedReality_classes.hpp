#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class AugmentedReality.ARBlueprintLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct UARBlueprintLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function AugmentedReality.ARBlueprintLibrary.UnpinComponent
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void UnpinComponent(struct USceneComponent* ComponentToUnpin); // Offset: 0x10403203c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function AugmentedReality.ARBlueprintLibrary.StopARSession
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void StopARSession(); // Offset: 0x1040331b4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AugmentedReality.ARBlueprintLibrary.StartARSession
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void StartARSession(struct UARSessionConfig* SessionConfig); // Offset: 0x1040331dc // Return & Params: Num(1) Size(0x8)

	// Object Name: Function AugmentedReality.ARBlueprintLibrary.SetAlignmentTransform
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void SetAlignmentTransform(struct FTransform& InAlignmentTransform); // Offset: 0x104033018 // Return & Params: Num(1) Size(0x30)

	// Object Name: Function AugmentedReality.ARBlueprintLibrary.RemovePin
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void RemovePin(struct UARPin* PinToRemove); // Offset: 0x104031fc4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function AugmentedReality.ARBlueprintLibrary.PinComponentToTraceResult
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct UARPin* PinComponentToTraceResult(struct USceneComponent* ComponentToPin, struct FARTraceResult& TraceResult, struct FName DebugName); // Offset: 0x1040320b4 // Return & Params: Num(4) Size(0x80)

	// Object Name: Function AugmentedReality.ARBlueprintLibrary.PinComponent
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable]
	struct UARPin* PinComponent(struct USceneComponent* ComponentToPin, struct FTransform& PinToWorldTransform, struct UARTrackedGeometry* TrackedGeometry, struct FName DebugName); // Offset: 0x104032260 // Return & Params: Num(5) Size(0x58)

	// Object Name: Function AugmentedReality.ARBlueprintLibrary.PauseARSession
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void PauseARSession(); // Offset: 0x1040331c8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AugmentedReality.ARBlueprintLibrary.LineTraceTrackedObjects3D
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	struct TArray<struct FARTraceResult> LineTraceTrackedObjects3D(struct FVector Start, struct FVector End, bool bTestFeaturePoints, bool bTestGroundPlane, bool bTestPlaneExtents, bool bTestPlaneBoundaryPolygon); // Offset: 0x104032964 // Return & Params: Num(7) Size(0x30)

	// Object Name: Function AugmentedReality.ARBlueprintLibrary.LineTraceTrackedObjects
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	struct TArray<struct FARTraceResult> LineTraceTrackedObjects(struct FVector2D ScreenCoord, bool bTestFeaturePoints, bool bTestGroundPlane, bool bTestPlaneExtents, bool bTestPlaneBoundaryPolygon); // Offset: 0x104032ce4 // Return & Params: Num(6) Size(0x20)

	// Object Name: Function AugmentedReality.ARBlueprintLibrary.IsSessionTypeSupported
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	bool IsSessionTypeSupported(enum class EARSessionType SessionType); // Offset: 0x104032794 // Return & Params: Num(2) Size(0x2)

	// Object Name: Function AugmentedReality.ARBlueprintLibrary.IsSessionTrackingFeatureSupported
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	bool IsSessionTrackingFeatureSupported(enum class EARSessionType SessionType, enum class EARSessionTrackingFeature SessionTrackingFeature); // Offset: 0x10403186c // Return & Params: Num(3) Size(0x3)

	// Object Name: Function AugmentedReality.ARBlueprintLibrary.IsARSupported
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsARSupported(); // Offset: 0x104033254 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AugmentedReality.ARBlueprintLibrary.GetWorldMappingStatus
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	enum class EARWorldMappingState GetWorldMappingStatus(); // Offset: 0x104031c48 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AugmentedReality.ARBlueprintLibrary.GetTrackingQualityReason
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	enum class EARTrackingQualityReason GetTrackingQualityReason(); // Offset: 0x1040328fc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AugmentedReality.ARBlueprintLibrary.GetTrackingQuality
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	enum class EARTrackingQuality GetTrackingQuality(); // Offset: 0x104032930 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AugmentedReality.ARBlueprintLibrary.GetSupportedVideoFormats
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct TArray<struct FARVideoFormat> GetSupportedVideoFormats(enum class EARSessionType SessionType); // Offset: 0x104031b04 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function AugmentedReality.ARBlueprintLibrary.GetSessionConfig
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct UARSessionConfig* GetSessionConfig(); // Offset: 0x1040330f0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function AugmentedReality.ARBlueprintLibrary.GetPointCloud
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct TArray<struct FVector> GetPointCloud(); // Offset: 0x104031bc8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AugmentedReality.ARBlueprintLibrary.GetPersonSegmentationImage
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UARTextureCameraImage* GetPersonSegmentationImage(); // Offset: 0x104031664 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function AugmentedReality.ARBlueprintLibrary.GetPersonSegmentationDepthImage
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UARTextureCameraImage* GetPersonSegmentationDepthImage(); // Offset: 0x104031630 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function AugmentedReality.ARBlueprintLibrary.GetCurrentLightEstimate
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct UARLightEstimate* GetCurrentLightEstimate(); // Offset: 0x104032420 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function AugmentedReality.ARBlueprintLibrary.GetCameraImage
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UARTextureCameraImage* GetCameraImage(); // Offset: 0x104032848 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function AugmentedReality.ARBlueprintLibrary.GetCameraDepth
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UARTextureCameraDepth* GetCameraDepth(); // Offset: 0x104032814 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function AugmentedReality.ARBlueprintLibrary.GetARSessionStatus
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FARSessionStatus GetARSessionStatus(); // Offset: 0x104033124 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function AugmentedReality.ARBlueprintLibrary.GetAllTrackedPoses
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct TArray<struct UARTrackedPose*> GetAllTrackedPoses(); // Offset: 0x104031698 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AugmentedReality.ARBlueprintLibrary.GetAllTrackedPoints
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct TArray<struct UARTrackedPoint*> GetAllTrackedPoints(); // Offset: 0x104031e44 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AugmentedReality.ARBlueprintLibrary.GetAllTrackedPlanes
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct TArray<struct UARPlaneGeometry*> GetAllTrackedPlanes(); // Offset: 0x104031ec4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AugmentedReality.ARBlueprintLibrary.GetAllTrackedImages
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct TArray<struct UARTrackedImage*> GetAllTrackedImages(); // Offset: 0x104031dc4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AugmentedReality.ARBlueprintLibrary.GetAllTrackedEnvironmentCaptureProbes
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct TArray<struct UAREnvironmentCaptureProbe*> GetAllTrackedEnvironmentCaptureProbes(); // Offset: 0x104031d44 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AugmentedReality.ARBlueprintLibrary.GetAllTracked2DPoses
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct TArray<struct FARPose2D> GetAllTracked2DPoses(); // Offset: 0x104031718 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AugmentedReality.ARBlueprintLibrary.GetAllPins
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct TArray<struct UARPin*> GetAllPins(); // Offset: 0x104031f44 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AugmentedReality.ARBlueprintLibrary.GetAllGeometries
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct TArray<struct UARTrackedGeometry*> GetAllGeometries(); // Offset: 0x10403287c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AugmentedReality.ARBlueprintLibrary.DebugDrawTrackedGeometry
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	void DebugDrawTrackedGeometry(struct UARTrackedGeometry* TrackedGeometry, struct UObject* WorldContextObject, struct FLinearColor Color, float OutlineThickness, float PersistForSeconds); // Offset: 0x1040325f4 // Return & Params: Num(5) Size(0x28)

	// Object Name: Function AugmentedReality.ARBlueprintLibrary.DebugDrawPin
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	void DebugDrawPin(struct UARPin* ARPin, struct UObject* WorldContextObject, struct FLinearColor Color, float Scale, float PersistForSeconds); // Offset: 0x104032454 // Return & Params: Num(5) Size(0x28)

	// Object Name: Function AugmentedReality.ARBlueprintLibrary.AddRuntimeCandidateImage
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UARCandidateImage* AddRuntimeCandidateImage(struct UARSessionConfig* SessionConfig, struct UTexture2D* CandidateTexture, struct FString FriendlyName, float PhysicalWidth); // Offset: 0x104031938 // Return & Params: Num(5) Size(0x30)

	// Object Name: Function AugmentedReality.ARBlueprintLibrary.AddManualEnvironmentCaptureProbe
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	bool AddManualEnvironmentCaptureProbe(struct FVector Location, struct FVector Extent); // Offset: 0x104031c7c // Return & Params: Num(3) Size(0x19)
};

// Object Name: Class AugmentedReality.ARTraceResultLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct UARTraceResultLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function AugmentedReality.ARTraceResultLibrary.GetTrackedGeometry
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct UARTrackedGeometry* GetTrackedGeometry(struct FARTraceResult& TraceResult); // Offset: 0x1040343d4 // Return & Params: Num(2) Size(0x68)

	// Object Name: Function AugmentedReality.ARTraceResultLibrary.GetTraceChannel
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	enum class EARLineTraceChannels GetTraceChannel(struct FARTraceResult& TraceResult); // Offset: 0x1040342c0 // Return & Params: Num(2) Size(0x61)

	// Object Name: Function AugmentedReality.ARTraceResultLibrary.GetLocalToWorldTransform
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	struct FTransform GetLocalToWorldTransform(struct FARTraceResult& TraceResult); // Offset: 0x1040344e8 // Return & Params: Num(2) Size(0x90)

	// Object Name: Function AugmentedReality.ARTraceResultLibrary.GetLocalToTrackingTransform
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	struct FTransform GetLocalToTrackingTransform(struct FARTraceResult& TraceResult); // Offset: 0x10403460c // Return & Params: Num(2) Size(0x90)

	// Object Name: Function AugmentedReality.ARTraceResultLibrary.GetDistanceFromCamera
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	float GetDistanceFromCamera(struct FARTraceResult& TraceResult); // Offset: 0x104034730 // Return & Params: Num(2) Size(0x64)
};

// Object Name: Class AugmentedReality.ARBaseAsyncTaskBlueprintProxy
// Size: 0x58 // Inherited bytes: 0x30
struct UARBaseAsyncTaskBlueprintProxy : UBlueprintAsyncActionBase {
	// Fields
	char pad_0x30[0x28]; // Offset: 0x30 // Size: 0x28
};

// Object Name: Class AugmentedReality.ARSaveWorldAsyncTaskBlueprintProxy
// Size: 0x88 // Inherited bytes: 0x58
struct UARSaveWorldAsyncTaskBlueprintProxy : UARBaseAsyncTaskBlueprintProxy {
	// Fields
	struct FMulticastInlineDelegate OnSuccess; // Offset: 0x58 // Size: 0x10
	struct FMulticastInlineDelegate OnFailed; // Offset: 0x68 // Size: 0x10
	char pad_0x78[0x10]; // Offset: 0x78 // Size: 0x10

	// Functions

	// Object Name: Function AugmentedReality.ARSaveWorldAsyncTaskBlueprintProxy.ARSaveWorld
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct UARSaveWorldAsyncTaskBlueprintProxy* ARSaveWorld(struct UObject* WorldContextObject); // Offset: 0x104034d6c // Return & Params: Num(2) Size(0x10)
};

// Object Name: Class AugmentedReality.ARGetCandidateObjectAsyncTaskBlueprintProxy
// Size: 0xa0 // Inherited bytes: 0x58
struct UARGetCandidateObjectAsyncTaskBlueprintProxy : UARBaseAsyncTaskBlueprintProxy {
	// Fields
	struct FMulticastInlineDelegate OnSuccess; // Offset: 0x58 // Size: 0x10
	struct FMulticastInlineDelegate OnFailed; // Offset: 0x68 // Size: 0x10
	char pad_0x78[0x28]; // Offset: 0x78 // Size: 0x28

	// Functions

	// Object Name: Function AugmentedReality.ARGetCandidateObjectAsyncTaskBlueprintProxy.ARGetCandidateObject
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable]
	struct UARGetCandidateObjectAsyncTaskBlueprintProxy* ARGetCandidateObject(struct UObject* WorldContextObject, struct FVector Location, struct FVector Extent); // Offset: 0x1040351bc // Return & Params: Num(4) Size(0x28)
};

// Object Name: Class AugmentedReality.ARLightEstimate
// Size: 0x28 // Inherited bytes: 0x28
struct UARLightEstimate : UObject {
};

// Object Name: Class AugmentedReality.ARBasicLightEstimate
// Size: 0x40 // Inherited bytes: 0x28
struct UARBasicLightEstimate : UARLightEstimate {
	// Fields
	float AmbientIntensityLumens; // Offset: 0x28 // Size: 0x04
	float AmbientColorTemperatureKelvin; // Offset: 0x2c // Size: 0x04
	struct FLinearColor AmbientColor; // Offset: 0x30 // Size: 0x10

	// Functions

	// Object Name: Function AugmentedReality.ARBasicLightEstimate.GetAmbientIntensityLumens
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetAmbientIntensityLumens(); // Offset: 0x104035844 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function AugmentedReality.ARBasicLightEstimate.GetAmbientColorTemperatureKelvin
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetAmbientColorTemperatureKelvin(); // Offset: 0x104035810 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function AugmentedReality.ARBasicLightEstimate.GetAmbientColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FLinearColor GetAmbientColor(); // Offset: 0x1040357d0 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class AugmentedReality.AROriginActor
// Size: 0x228 // Inherited bytes: 0x228
struct AAROriginActor : AActor {
};

// Object Name: Class AugmentedReality.ARPin
// Size: 0xf0 // Inherited bytes: 0x28
struct UARPin : UObject {
	// Fields
	struct UARTrackedGeometry* TrackedGeometry; // Offset: 0x28 // Size: 0x08
	struct USceneComponent* PinnedComponent; // Offset: 0x30 // Size: 0x08
	char pad_0x38[0x8]; // Offset: 0x38 // Size: 0x08
	struct FTransform LocalToTrackingTransform; // Offset: 0x40 // Size: 0x30
	struct FTransform LocalToAlignedTrackingTransform; // Offset: 0x70 // Size: 0x30
	enum class EARTrackingState TrackingState; // Offset: 0xa0 // Size: 0x01
	char pad_0xA1[0x1f]; // Offset: 0xa1 // Size: 0x1f
	struct FMulticastInlineDelegate OnARTrackingStateChanged; // Offset: 0xc0 // Size: 0x10
	struct FMulticastInlineDelegate OnARTransformUpdated; // Offset: 0xd0 // Size: 0x10
	char pad_0xE0[0x10]; // Offset: 0xe0 // Size: 0x10

	// Functions

	// Object Name: Function AugmentedReality.ARPin.GetTrackingState
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	enum class EARTrackingState GetTrackingState(); // Offset: 0x104035e84 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AugmentedReality.ARPin.GetTrackedGeometry
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UARTrackedGeometry* GetTrackedGeometry(); // Offset: 0x104035e50 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function AugmentedReality.ARPin.GetPinnedComponent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct USceneComponent* GetPinnedComponent(); // Offset: 0x104035e1c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function AugmentedReality.ARPin.GetLocalToWorldTransform
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FTransform GetLocalToWorldTransform(); // Offset: 0x104035eb8 // Return & Params: Num(1) Size(0x30)

	// Object Name: Function AugmentedReality.ARPin.GetLocalToTrackingTransform
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FTransform GetLocalToTrackingTransform(); // Offset: 0x104035f30 // Return & Params: Num(1) Size(0x30)

	// Object Name: Function AugmentedReality.ARPin.GetDebugName
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FName GetDebugName(); // Offset: 0x104035c70 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function AugmentedReality.ARPin.DebugDraw
	// Flags: [Native|Public|HasOutParms|HasDefaults|Const]
	void DebugDraw(struct UWorld* World, struct FLinearColor& Color, float Scale, float PersistForSeconds); // Offset: 0x104035ca4 // Return & Params: Num(4) Size(0x20)
};

// Object Name: Class AugmentedReality.ARSessionConfig
// Size: 0xa8 // Inherited bytes: 0x30
struct UARSessionConfig : UDataAsset {
	// Fields
	bool bGenerateMeshDataFromTrackedGeometry; // Offset: 0x30 // Size: 0x01
	bool bGenerateCollisionForMeshData; // Offset: 0x31 // Size: 0x01
	bool bGenerateNavMeshForMeshData; // Offset: 0x32 // Size: 0x01
	bool bUseMeshDataForOcclusion; // Offset: 0x33 // Size: 0x01
	bool bRenderMeshDataInWireframe; // Offset: 0x34 // Size: 0x01
	bool bTrackSceneObjects; // Offset: 0x35 // Size: 0x01
	bool bUsePersonSegmentationForOcclusion; // Offset: 0x36 // Size: 0x01
	enum class EARWorldAlignment WorldAlignment; // Offset: 0x37 // Size: 0x01
	enum class EARSessionType SessionType; // Offset: 0x38 // Size: 0x01
	enum class EARPlaneDetectionMode PlaneDetectionMode; // Offset: 0x39 // Size: 0x01
	bool bHorizontalPlaneDetection; // Offset: 0x3a // Size: 0x01
	bool bVerticalPlaneDetection; // Offset: 0x3b // Size: 0x01
	bool bEnableAutoFocus; // Offset: 0x3c // Size: 0x01
	enum class EARLightEstimationMode LightEstimationMode; // Offset: 0x3d // Size: 0x01
	enum class EARFrameSyncMode FrameSyncMode; // Offset: 0x3e // Size: 0x01
	bool bEnableAutomaticCameraOverlay; // Offset: 0x3f // Size: 0x01
	bool bEnableAutomaticCameraTracking; // Offset: 0x40 // Size: 0x01
	bool bResetCameraTracking; // Offset: 0x41 // Size: 0x01
	bool bResetTrackedObjects; // Offset: 0x42 // Size: 0x01
	char pad_0x43[0x5]; // Offset: 0x43 // Size: 0x05
	struct TArray<struct UARCandidateImage*> CandidateImages; // Offset: 0x48 // Size: 0x10
	int32_t MaxNumSimultaneousImagesTracked; // Offset: 0x58 // Size: 0x04
	enum class EAREnvironmentCaptureProbeType EnvironmentCaptureProbeType; // Offset: 0x5c // Size: 0x01
	char pad_0x5D[0x3]; // Offset: 0x5d // Size: 0x03
	struct TArray<char> WorldMapData; // Offset: 0x60 // Size: 0x10
	struct TArray<struct UARCandidateObject*> CandidateObjects; // Offset: 0x70 // Size: 0x10
	struct FARVideoFormat DesiredVideoFormat; // Offset: 0x80 // Size: 0x0c
	enum class EARFaceTrackingDirection FaceTrackingDirection; // Offset: 0x8c // Size: 0x01
	enum class EARFaceTrackingUpdate FaceTrackingUpdate; // Offset: 0x8d // Size: 0x01
	char pad_0x8E[0x2]; // Offset: 0x8e // Size: 0x02
	struct TArray<char> SerializedARCandidateImageDatabase; // Offset: 0x90 // Size: 0x10
	enum class EARSessionTrackingFeature EnabledSessionTrackingFeature; // Offset: 0xa0 // Size: 0x01
	char pad_0xA1[0x7]; // Offset: 0xa1 // Size: 0x07

	// Functions

	// Object Name: Function AugmentedReality.ARSessionConfig.ShouldResetTrackedObjects
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool ShouldResetTrackedObjects(); // Offset: 0x104037020 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AugmentedReality.ARSessionConfig.ShouldResetCameraTracking
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool ShouldResetCameraTracking(); // Offset: 0x1040370dc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AugmentedReality.ARSessionConfig.ShouldRenderCameraOverlay
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool ShouldRenderCameraOverlay(); // Offset: 0x104037200 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AugmentedReality.ARSessionConfig.ShouldEnableCameraTracking
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool ShouldEnableCameraTracking(); // Offset: 0x1040371cc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AugmentedReality.ARSessionConfig.ShouldEnableAutoFocus
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool ShouldEnableAutoFocus(); // Offset: 0x104037198 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AugmentedReality.ARSessionConfig.SetWorldMapData
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetWorldMapData(struct TArray<char> WorldMapData); // Offset: 0x104036cb8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AugmentedReality.ARSessionConfig.SetSessionTrackingFeatureToEnable
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSessionTrackingFeatureToEnable(enum class EARSessionTrackingFeature InSessionTrackingFeature); // Offset: 0x104036840 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AugmentedReality.ARSessionConfig.SetResetTrackedObjects
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetResetTrackedObjects(bool bNewValue); // Offset: 0x104036f98 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AugmentedReality.ARSessionConfig.SetResetCameraTracking
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetResetCameraTracking(bool bNewValue); // Offset: 0x104037054 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AugmentedReality.ARSessionConfig.SetFaceTrackingUpdate
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetFaceTrackingUpdate(enum class EARFaceTrackingUpdate InUpdate); // Offset: 0x1040368f4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AugmentedReality.ARSessionConfig.SetFaceTrackingDirection
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetFaceTrackingDirection(enum class EARFaceTrackingDirection InDirection); // Offset: 0x1040369a8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AugmentedReality.ARSessionConfig.SetEnableAutoFocus
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetEnableAutoFocus(bool bNewValue); // Offset: 0x104037110 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AugmentedReality.ARSessionConfig.SetDesiredVideoFormat
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetDesiredVideoFormat(struct FARVideoFormat NewFormat); // Offset: 0x104036a5c // Return & Params: Num(1) Size(0xc)

	// Object Name: Function AugmentedReality.ARSessionConfig.SetCandidateObjectList
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetCandidateObjectList(struct TArray<struct UARCandidateObject*>& InCandidateObjects); // Offset: 0x104036b9c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AugmentedReality.ARSessionConfig.GetWorldMapData
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct TArray<char> GetWorldMapData(); // Offset: 0x104036da8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AugmentedReality.ARSessionConfig.GetWorldAlignment
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	enum class EARWorldAlignment GetWorldAlignment(); // Offset: 0x104037304 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AugmentedReality.ARSessionConfig.GetSessionType
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	enum class EARSessionType GetSessionType(); // Offset: 0x1040372d0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AugmentedReality.ARSessionConfig.GetPlaneDetectionMode
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	enum class EARPlaneDetectionMode GetPlaneDetectionMode(); // Offset: 0x10403729c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AugmentedReality.ARSessionConfig.GetMaxNumSimultaneousImagesTracked
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetMaxNumSimultaneousImagesTracked(); // Offset: 0x104036e60 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function AugmentedReality.ARSessionConfig.GetLightEstimationMode
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	enum class EARLightEstimationMode GetLightEstimationMode(); // Offset: 0x104037268 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AugmentedReality.ARSessionConfig.GetFrameSyncMode
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	enum class EARFrameSyncMode GetFrameSyncMode(); // Offset: 0x104037234 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AugmentedReality.ARSessionConfig.GetFaceTrackingUpdate
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	enum class EARFaceTrackingUpdate GetFaceTrackingUpdate(); // Offset: 0x104036974 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AugmentedReality.ARSessionConfig.GetFaceTrackingDirection
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	enum class EARFaceTrackingDirection GetFaceTrackingDirection(); // Offset: 0x104036a28 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AugmentedReality.ARSessionConfig.GetEnvironmentCaptureProbeType
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	enum class EAREnvironmentCaptureProbeType GetEnvironmentCaptureProbeType(); // Offset: 0x104036e2c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AugmentedReality.ARSessionConfig.GetEnabledSessionTrackingFeature
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	enum class EARSessionTrackingFeature GetEnabledSessionTrackingFeature(); // Offset: 0x1040368c0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AugmentedReality.ARSessionConfig.GetDesiredVideoFormat
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FARVideoFormat GetDesiredVideoFormat(); // Offset: 0x104036ae4 // Return & Params: Num(1) Size(0xc)

	// Object Name: Function AugmentedReality.ARSessionConfig.GetCandidateObjectList
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct TArray<struct UARCandidateObject*> GetCandidateObjectList(); // Offset: 0x104036c34 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AugmentedReality.ARSessionConfig.GetCandidateImageList
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct TArray<struct UARCandidateImage*> GetCandidateImageList(); // Offset: 0x104036f14 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AugmentedReality.ARSessionConfig.AddCandidateObject
	// Flags: [Final|Native|Public|BlueprintCallable]
	void AddCandidateObject(struct UARCandidateObject* CandidateObject); // Offset: 0x104036b1c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function AugmentedReality.ARSessionConfig.AddCandidateImage
	// Flags: [Final|Native|Public|BlueprintCallable]
	void AddCandidateImage(struct UARCandidateImage* NewCandidateImage); // Offset: 0x104036e94 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class AugmentedReality.ARSharedWorldGameMode
// Size: 0x378 // Inherited bytes: 0x310
struct AARSharedWorldGameMode : AGameMode {
	// Fields
	int32_t BufferSizePerChunk; // Offset: 0x30c // Size: 0x04
	char pad_0x314[0x64]; // Offset: 0x314 // Size: 0x64

	// Functions

	// Object Name: Function AugmentedReality.ARSharedWorldGameMode.SetPreviewImageData
	// Flags: [Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable]
	void SetPreviewImageData(struct TArray<char> ImageData); // Offset: 0x104039234 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AugmentedReality.ARSharedWorldGameMode.SetARWorldSharingIsReady
	// Flags: [Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable]
	void SetARWorldSharingIsReady(); // Offset: 0x104039130 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AugmentedReality.ARSharedWorldGameMode.SetARSharedWorldData
	// Flags: [Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable]
	void SetARSharedWorldData(struct TArray<char> ARWorldData); // Offset: 0x104039144 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AugmentedReality.ARSharedWorldGameMode.GetARSharedWorldGameState
	// Flags: [Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable]
	struct AARSharedWorldGameState* GetARSharedWorldGameState(); // Offset: 0x1040390fc // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class AugmentedReality.ARSharedWorldGameState
// Size: 0x2e8 // Inherited bytes: 0x2b0
struct AARSharedWorldGameState : AGameState {
	// Fields
	struct TArray<char> PreviewImageData; // Offset: 0x2b0 // Size: 0x10
	struct TArray<char> ARWorldData; // Offset: 0x2c0 // Size: 0x10
	int32_t PreviewImageBytesTotal; // Offset: 0x2d0 // Size: 0x04
	int32_t ARWorldBytesTotal; // Offset: 0x2d4 // Size: 0x04
	int32_t PreviewImageBytesDelivered; // Offset: 0x2d8 // Size: 0x04
	int32_t ARWorldBytesDelivered; // Offset: 0x2dc // Size: 0x04
	char pad_0x2E0[0x8]; // Offset: 0x2e0 // Size: 0x08

	// Functions

	// Object Name: Function AugmentedReality.ARSharedWorldGameState.K2_OnARWorldMapIsReady
	// Flags: [Event|Public|BlueprintEvent]
	void K2_OnARWorldMapIsReady(); // Offset: 0x103938968 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class AugmentedReality.ARSharedWorldPlayerController
// Size: 0x5a8 // Inherited bytes: 0x5a8
struct AARSharedWorldPlayerController : APlayerController {
	// Functions

	// Object Name: Function AugmentedReality.ARSharedWorldPlayerController.ServerMarkReadyForReceiving
	// Flags: [Net|NetReliableNative|Event|Public|NetServer|NetValidate]
	void ServerMarkReadyForReceiving(); // Offset: 0x104039c88 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function AugmentedReality.ARSharedWorldPlayerController.ClientUpdatePreviewImageData
	// Flags: [Net|NetReliableNative|Event|Public|NetClient|NetValidate]
	void ClientUpdatePreviewImageData(int32_t Offset, struct TArray<char> Buffer); // Offset: 0x104039a70 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function AugmentedReality.ARSharedWorldPlayerController.ClientUpdateARWorldData
	// Flags: [Net|NetReliableNative|Event|Public|NetClient|NetValidate]
	void ClientUpdateARWorldData(int32_t Offset, struct TArray<char> Buffer); // Offset: 0x10403995c // Return & Params: Num(2) Size(0x18)

	// Object Name: Function AugmentedReality.ARSharedWorldPlayerController.ClientInitSharedWorld
	// Flags: [Net|NetReliableNative|Event|Public|NetClient|NetValidate]
	void ClientInitSharedWorld(int32_t PreviewImageSize, int32_t ARWorldDataSize); // Offset: 0x104039b84 // Return & Params: Num(2) Size(0x8)
};

// Object Name: Class AugmentedReality.ARSkyLight
// Size: 0x248 // Inherited bytes: 0x238
struct AARSkyLight : ASkyLight {
	// Fields
	struct UAREnvironmentCaptureProbe* CaptureProbe; // Offset: 0x238 // Size: 0x08
	char pad_0x240[0x8]; // Offset: 0x240 // Size: 0x08

	// Functions

	// Object Name: Function AugmentedReality.ARSkyLight.SetEnvironmentCaptureProbe
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetEnvironmentCaptureProbe(struct UAREnvironmentCaptureProbe* InCaptureProbe); // Offset: 0x10403a280 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class AugmentedReality.ARTexture
// Size: 0xd8 // Inherited bytes: 0xb8
struct UARTexture : UTexture {
	// Fields
	enum class EARTextureType TextureType; // Offset: 0xb8 // Size: 0x01
	char pad_0xB9[0x3]; // Offset: 0xb9 // Size: 0x03
	float Timestamp; // Offset: 0xbc // Size: 0x04
	struct FGuid ExternalTextureGuid; // Offset: 0xc0 // Size: 0x10
	struct FVector2D Size; // Offset: 0xd0 // Size: 0x08
};

// Object Name: Class AugmentedReality.ARTextureCameraImage
// Size: 0xd8 // Inherited bytes: 0xd8
struct UARTextureCameraImage : UARTexture {
};

// Object Name: Class AugmentedReality.ARTextureCameraDepth
// Size: 0xe0 // Inherited bytes: 0xd8
struct UARTextureCameraDepth : UARTexture {
	// Fields
	enum class EARDepthQuality DepthQuality; // Offset: 0xd8 // Size: 0x01
	enum class EARDepthAccuracy DepthAccuracy; // Offset: 0xd9 // Size: 0x01
	bool bIsTemporallySmoothed; // Offset: 0xda // Size: 0x01
	char pad_0xDB[0x5]; // Offset: 0xdb // Size: 0x05
};

// Object Name: Class AugmentedReality.AREnvironmentCaptureProbeTexture
// Size: 0x130 // Inherited bytes: 0x110
struct UAREnvironmentCaptureProbeTexture : UTextureCube {
	// Fields
	enum class EARTextureType TextureType; // Offset: 0x110 // Size: 0x01
	char pad_0x111[0x3]; // Offset: 0x111 // Size: 0x03
	float Timestamp; // Offset: 0x114 // Size: 0x04
	struct FGuid ExternalTextureGuid; // Offset: 0x118 // Size: 0x10
	struct FVector2D Size; // Offset: 0x128 // Size: 0x08
};

// Object Name: Class AugmentedReality.ARTraceResultDummy
// Size: 0x28 // Inherited bytes: 0x28
struct UARTraceResultDummy : UObject {
};

// Object Name: Class AugmentedReality.ARTrackedGeometry
// Size: 0xf0 // Inherited bytes: 0x28
struct UARTrackedGeometry : UObject {
	// Fields
	struct FGuid UniqueId; // Offset: 0x28 // Size: 0x10
	char pad_0x38[0x8]; // Offset: 0x38 // Size: 0x08
	struct FTransform LocalToTrackingTransform; // Offset: 0x40 // Size: 0x30
	struct FTransform LocalToAlignedTrackingTransform; // Offset: 0x70 // Size: 0x30
	enum class EARTrackingState TrackingState; // Offset: 0xa0 // Size: 0x01
	char pad_0xA1[0xf]; // Offset: 0xa1 // Size: 0x0f
	struct UMRMeshComponent* UnderlyingMesh; // Offset: 0xb0 // Size: 0x08
	enum class EARObjectClassification ObjectClassification; // Offset: 0xb8 // Size: 0x01
	char pad_0xB9[0x17]; // Offset: 0xb9 // Size: 0x17
	int32_t LastUpdateFrameNumber; // Offset: 0xd0 // Size: 0x04
	char pad_0xD4[0xc]; // Offset: 0xd4 // Size: 0x0c
	struct FName DebugName; // Offset: 0xe0 // Size: 0x08
	char pad_0xE8[0x8]; // Offset: 0xe8 // Size: 0x08

	// Functions

	// Object Name: Function AugmentedReality.ARTrackedGeometry.IsTracked
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsTracked(); // Offset: 0x10403b46c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AugmentedReality.ARTrackedGeometry.GetUnderlyingMesh
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	struct UMRMeshComponent* GetUnderlyingMesh(); // Offset: 0x10403b39c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function AugmentedReality.ARTrackedGeometry.GetTrackingState
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	enum class EARTrackingState GetTrackingState(); // Offset: 0x10403b4a0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AugmentedReality.ARTrackedGeometry.GetObjectClassification
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	enum class EARObjectClassification GetObjectClassification(); // Offset: 0x10403b380 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AugmentedReality.ARTrackedGeometry.GetLocalToWorldTransform
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FTransform GetLocalToWorldTransform(); // Offset: 0x10403b54c // Return & Params: Num(1) Size(0x30)

	// Object Name: Function AugmentedReality.ARTrackedGeometry.GetLocalToTrackingTransform
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FTransform GetLocalToTrackingTransform(); // Offset: 0x10403b4d4 // Return & Params: Num(1) Size(0x30)

	// Object Name: Function AugmentedReality.ARTrackedGeometry.GetLastUpdateTimestamp
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetLastUpdateTimestamp(); // Offset: 0x10403b3d0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function AugmentedReality.ARTrackedGeometry.GetLastUpdateFrameNumber
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetLastUpdateFrameNumber(); // Offset: 0x10403b404 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function AugmentedReality.ARTrackedGeometry.GetDebugName
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FName GetDebugName(); // Offset: 0x10403b438 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class AugmentedReality.ARPlaneGeometry
// Size: 0x120 // Inherited bytes: 0xf0
struct UARPlaneGeometry : UARTrackedGeometry {
	// Fields
	enum class EARPlaneOrientation Orientation; // Offset: 0xe8 // Size: 0x01
	struct FVector Center; // Offset: 0xec // Size: 0x0c
	struct FVector Extent; // Offset: 0xf8 // Size: 0x0c
	char pad_0x109[0xf]; // Offset: 0x109 // Size: 0x0f
	struct UARPlaneGeometry* SubsumedBy; // Offset: 0x118 // Size: 0x08

	// Functions

	// Object Name: Function AugmentedReality.ARPlaneGeometry.GetSubsumedBy
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UARPlaneGeometry* GetSubsumedBy(); // Offset: 0x10403baf0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function AugmentedReality.ARPlaneGeometry.GetOrientation
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	enum class EARPlaneOrientation GetOrientation(); // Offset: 0x10403bad4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AugmentedReality.ARPlaneGeometry.GetExtent
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FVector GetExtent(); // Offset: 0x10403bbd8 // Return & Params: Num(1) Size(0xc)

	// Object Name: Function AugmentedReality.ARPlaneGeometry.GetCenter
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FVector GetCenter(); // Offset: 0x10403bbfc // Return & Params: Num(1) Size(0xc)

	// Object Name: Function AugmentedReality.ARPlaneGeometry.GetBoundaryPolygonInLocalSpace
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct TArray<struct FVector> GetBoundaryPolygonInLocalSpace(); // Offset: 0x10403bb0c // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class AugmentedReality.ARTrackedPoint
// Size: 0xf0 // Inherited bytes: 0xf0
struct UARTrackedPoint : UARTrackedGeometry {
};

// Object Name: Class AugmentedReality.ARTrackedImage
// Size: 0x100 // Inherited bytes: 0xf0
struct UARTrackedImage : UARTrackedGeometry {
	// Fields
	struct UARCandidateImage* DetectedImage; // Offset: 0xe8 // Size: 0x08
	struct FVector2D EstimatedSize; // Offset: 0xf0 // Size: 0x08

	// Functions

	// Object Name: Function AugmentedReality.ARTrackedImage.GetEstimateSize
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	struct FVector2D GetEstimateSize(); // Offset: 0x10403c40c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function AugmentedReality.ARTrackedImage.GetDetectedImage
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UARCandidateImage* GetDetectedImage(); // Offset: 0x10403c444 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class AugmentedReality.ARTrackedQRCode
// Size: 0x110 // Inherited bytes: 0x100
struct UARTrackedQRCode : UARTrackedImage {
	// Fields
	struct FString QRCode; // Offset: 0xf8 // Size: 0x10
	int32_t Version; // Offset: 0x108 // Size: 0x04
};

// Object Name: Class AugmentedReality.ARFaceGeometry
// Size: 0x1e0 // Inherited bytes: 0xf0
struct UARFaceGeometry : UARTrackedGeometry {
	// Fields
	struct FVector LookAtTarget; // Offset: 0xe8 // Size: 0x0c
	bool bIsTracked; // Offset: 0xf4 // Size: 0x01
	struct TMap<enum class EARFaceBlendShape, float> BlendShapes; // Offset: 0xf8 // Size: 0x50
	char pad_0x14D[0x93]; // Offset: 0x14d // Size: 0x93

	// Functions

	// Object Name: Function AugmentedReality.ARFaceGeometry.GetWorldSpaceEyeTransform
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FTransform GetWorldSpaceEyeTransform(enum class EAREye Eye); // Offset: 0x10403ca58 // Return & Params: Num(2) Size(0x40)

	// Object Name: Function AugmentedReality.ARFaceGeometry.GetLocalSpaceEyeTransform
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FTransform GetLocalSpaceEyeTransform(enum class EAREye Eye); // Offset: 0x10403cb24 // Return & Params: Num(2) Size(0x40)

	// Object Name: Function AugmentedReality.ARFaceGeometry.GetBlendShapeValue
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetBlendShapeValue(enum class EARFaceBlendShape BlendShape); // Offset: 0x10403cc90 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function AugmentedReality.ARFaceGeometry.GetBlendShapes
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct TMap<enum class EARFaceBlendShape, float> GetBlendShapes(); // Offset: 0x10403cbc0 // Return & Params: Num(1) Size(0x50)
};

// Object Name: Class AugmentedReality.AREnvironmentCaptureProbe
// Size: 0x100 // Inherited bytes: 0xf0
struct UAREnvironmentCaptureProbe : UARTrackedGeometry {
	// Fields
	char pad_0xF0[0x8]; // Offset: 0xf0 // Size: 0x08
	struct UAREnvironmentCaptureProbeTexture* EnvironmentCaptureTexture; // Offset: 0xf8 // Size: 0x08

	// Functions

	// Object Name: Function AugmentedReality.AREnvironmentCaptureProbe.GetExtent
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FVector GetExtent(); // Offset: 0x10403d27c // Return & Params: Num(1) Size(0xc)

	// Object Name: Function AugmentedReality.AREnvironmentCaptureProbe.GetEnvironmentCaptureTexture
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure]
	struct UAREnvironmentCaptureProbeTexture* GetEnvironmentCaptureTexture(); // Offset: 0x10403d248 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class AugmentedReality.ARTrackedObject
// Size: 0xf0 // Inherited bytes: 0xf0
struct UARTrackedObject : UARTrackedGeometry {
	// Fields
	struct UARCandidateObject* DetectedObject; // Offset: 0xe8 // Size: 0x08

	// Functions

	// Object Name: Function AugmentedReality.ARTrackedObject.GetDetectedObject
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UARCandidateObject* GetDetectedObject(); // Offset: 0x10403d5d8 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class AugmentedReality.ARTrackedPose
// Size: 0x140 // Inherited bytes: 0xf0
struct UARTrackedPose : UARTrackedGeometry {
	// Fields
	char pad_0xF0[0x50]; // Offset: 0xf0 // Size: 0x50

	// Functions

	// Object Name: Function AugmentedReality.ARTrackedPose.GetTrackedPoseData
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FARPose3D GetTrackedPoseData(); // Offset: 0x10403da64 // Return & Params: Num(1) Size(0x50)
};

// Object Name: Class AugmentedReality.ARTrackableNotifyComponent
// Size: 0x200 // Inherited bytes: 0xb0
struct UARTrackableNotifyComponent : UActorComponent {
	// Fields
	struct FMulticastInlineDelegate OnAddTrackedGeometry; // Offset: 0xb0 // Size: 0x10
	struct FMulticastInlineDelegate OnUpdateTrackedGeometry; // Offset: 0xc0 // Size: 0x10
	struct FMulticastInlineDelegate OnRemoveTrackedGeometry; // Offset: 0xd0 // Size: 0x10
	struct FMulticastInlineDelegate OnAddTrackedPlane; // Offset: 0xe0 // Size: 0x10
	struct FMulticastInlineDelegate OnUpdateTrackedPlane; // Offset: 0xf0 // Size: 0x10
	struct FMulticastInlineDelegate OnRemoveTrackedPlane; // Offset: 0x100 // Size: 0x10
	struct FMulticastInlineDelegate OnAddTrackedPoint; // Offset: 0x110 // Size: 0x10
	struct FMulticastInlineDelegate OnUpdateTrackedPoint; // Offset: 0x120 // Size: 0x10
	struct FMulticastInlineDelegate OnRemoveTrackedPoint; // Offset: 0x130 // Size: 0x10
	struct FMulticastInlineDelegate OnAddTrackedImage; // Offset: 0x140 // Size: 0x10
	struct FMulticastInlineDelegate OnUpdateTrackedImage; // Offset: 0x150 // Size: 0x10
	struct FMulticastInlineDelegate OnRemoveTrackedImage; // Offset: 0x160 // Size: 0x10
	struct FMulticastInlineDelegate OnAddTrackedFace; // Offset: 0x170 // Size: 0x10
	struct FMulticastInlineDelegate OnUpdateTrackedFace; // Offset: 0x180 // Size: 0x10
	struct FMulticastInlineDelegate OnRemoveTrackedFace; // Offset: 0x190 // Size: 0x10
	struct FMulticastInlineDelegate OnAddTrackedEnvProbe; // Offset: 0x1a0 // Size: 0x10
	struct FMulticastInlineDelegate OnUpdateTrackedEnvProbe; // Offset: 0x1b0 // Size: 0x10
	struct FMulticastInlineDelegate OnRemoveTrackedEnvProbe; // Offset: 0x1c0 // Size: 0x10
	struct FMulticastInlineDelegate OnAddTrackedObject; // Offset: 0x1d0 // Size: 0x10
	struct FMulticastInlineDelegate OnUpdateTrackedObject; // Offset: 0x1e0 // Size: 0x10
	struct FMulticastInlineDelegate OnRemoveTrackedObject; // Offset: 0x1f0 // Size: 0x10
};

// Object Name: Class AugmentedReality.ARTypesDummyClass
// Size: 0x28 // Inherited bytes: 0x28
struct UARTypesDummyClass : UObject {
};

// Object Name: Class AugmentedReality.ARCandidateImage
// Size: 0x58 // Inherited bytes: 0x30
struct UARCandidateImage : UDataAsset {
	// Fields
	struct UTexture2D* CandidateTexture; // Offset: 0x30 // Size: 0x08
	struct FString FriendlyName; // Offset: 0x38 // Size: 0x10
	float Width; // Offset: 0x48 // Size: 0x04
	float Height; // Offset: 0x4c // Size: 0x04
	enum class EARCandidateImageOrientation Orientation; // Offset: 0x50 // Size: 0x01
	char pad_0x51[0x7]; // Offset: 0x51 // Size: 0x07

	// Functions

	// Object Name: Function AugmentedReality.ARCandidateImage.GetPhysicalWidth
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetPhysicalWidth(); // Offset: 0x10403ecfc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function AugmentedReality.ARCandidateImage.GetPhysicalHeight
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetPhysicalHeight(); // Offset: 0x10403ece0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function AugmentedReality.ARCandidateImage.GetOrientation
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	enum class EARCandidateImageOrientation GetOrientation(); // Offset: 0x10403ecc4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function AugmentedReality.ARCandidateImage.GetFriendlyName
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FString GetFriendlyName(); // Offset: 0x10403ed18 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AugmentedReality.ARCandidateImage.GetCandidateTexture
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UTexture2D* GetCandidateTexture(); // Offset: 0x10403ed9c // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class AugmentedReality.ARCandidateObject
// Size: 0x70 // Inherited bytes: 0x30
struct UARCandidateObject : UDataAsset {
	// Fields
	struct TArray<char> CandidateObjectData; // Offset: 0x30 // Size: 0x10
	struct FString FriendlyName; // Offset: 0x40 // Size: 0x10
	struct FBox BoundingBox; // Offset: 0x50 // Size: 0x1c
	char pad_0x6C[0x4]; // Offset: 0x6c // Size: 0x04

	// Functions

	// Object Name: Function AugmentedReality.ARCandidateObject.SetFriendlyName
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetFriendlyName(struct FString NewName); // Offset: 0x10403f2c4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AugmentedReality.ARCandidateObject.SetCandidateObjectData
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetCandidateObjectData(struct TArray<char>& InCandidateObject); // Offset: 0x10403f424 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AugmentedReality.ARCandidateObject.SetBoundingBox
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void SetBoundingBox(struct FBox& InBoundingBox); // Offset: 0x10403f1e4 // Return & Params: Num(1) Size(0x1c)

	// Object Name: Function AugmentedReality.ARCandidateObject.GetFriendlyName
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FString GetFriendlyName(); // Offset: 0x10403f3a0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AugmentedReality.ARCandidateObject.GetCandidateObjectData
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct TArray<char> GetCandidateObjectData(); // Offset: 0x10403f51c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function AugmentedReality.ARCandidateObject.GetBoundingBox
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FBox GetBoundingBox(); // Offset: 0x10403f2a0 // Return & Params: Num(1) Size(0x1c)
};

