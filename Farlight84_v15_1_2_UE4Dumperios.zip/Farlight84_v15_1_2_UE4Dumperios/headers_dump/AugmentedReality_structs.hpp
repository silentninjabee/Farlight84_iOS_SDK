#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct AugmentedReality.ARSharedWorldReplicationState
// Size: 0x08 // Inherited bytes: 0x00
struct FARSharedWorldReplicationState {
	// Fields
	int32_t PreviewImageOffset; // Offset: 0x00 // Size: 0x04
	int32_t ARWorldOffset; // Offset: 0x04 // Size: 0x04
};

// Object Name: ScriptStruct AugmentedReality.ARTraceResult
// Size: 0x60 // Inherited bytes: 0x00
struct FARTraceResult {
	// Fields
	float DistanceFromCamera; // Offset: 0x00 // Size: 0x04
	enum class EARLineTraceChannels TraceChannel; // Offset: 0x04 // Size: 0x01
	char pad_0x5[0xb]; // Offset: 0x05 // Size: 0x0b
	struct FTransform LocalToTrackingTransform; // Offset: 0x10 // Size: 0x30
	struct UARTrackedGeometry* TrackedGeometry; // Offset: 0x40 // Size: 0x08
	char pad_0x48[0x18]; // Offset: 0x48 // Size: 0x18
};

// Object Name: ScriptStruct AugmentedReality.ARPose3D
// Size: 0x50 // Inherited bytes: 0x00
struct FARPose3D {
	// Fields
	struct FARSkeletonDefinition SkeletonDefinition; // Offset: 0x00 // Size: 0x28
	struct TArray<struct FTransform> JointTransforms; // Offset: 0x28 // Size: 0x10
	struct TArray<bool> IsJointTracked; // Offset: 0x38 // Size: 0x10
	enum class EARJointTransformSpace JointTransformSpace; // Offset: 0x48 // Size: 0x01
	char pad_0x49[0x7]; // Offset: 0x49 // Size: 0x07
};

// Object Name: ScriptStruct AugmentedReality.ARSkeletonDefinition
// Size: 0x28 // Inherited bytes: 0x00
struct FARSkeletonDefinition {
	// Fields
	int32_t NumJoints; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<struct FName> JointNames; // Offset: 0x08 // Size: 0x10
	struct TArray<int32_t> ParentIndices; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct AugmentedReality.ARPose2D
// Size: 0x48 // Inherited bytes: 0x00
struct FARPose2D {
	// Fields
	struct FARSkeletonDefinition SkeletonDefinition; // Offset: 0x00 // Size: 0x28
	struct TArray<struct FVector2D> JointLocations; // Offset: 0x28 // Size: 0x10
	struct TArray<bool> IsJointTracked; // Offset: 0x38 // Size: 0x10
};

// Object Name: ScriptStruct AugmentedReality.ARVideoFormat
// Size: 0x0c // Inherited bytes: 0x00
struct FARVideoFormat {
	// Fields
	int32_t Fps; // Offset: 0x00 // Size: 0x04
	int32_t Width; // Offset: 0x04 // Size: 0x04
	int32_t Height; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct AugmentedReality.ARSessionStatus
// Size: 0x18 // Inherited bytes: 0x00
struct FARSessionStatus {
	// Fields
	struct FString AdditionalInfo; // Offset: 0x00 // Size: 0x10
	enum class EARSessionStatus status; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x7]; // Offset: 0x11 // Size: 0x07
};

