#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class AutomationUtils.AutomationUtilsBlueprintLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct UAutomationUtilsBlueprintLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function AutomationUtils.AutomationUtilsBlueprintLibrary.TakeGameplayAutomationScreenshot
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void TakeGameplayAutomationScreenshot(struct FString ScreenshotName, float MaxGlobalError, float MaxLocalError, struct FString MapNameOverride); // Offset: 0x10232b708 // Return & Params: Num(4) Size(0x28)
};

