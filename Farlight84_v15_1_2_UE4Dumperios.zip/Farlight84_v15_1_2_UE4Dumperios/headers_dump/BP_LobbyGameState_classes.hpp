#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_LobbyGameState.BP_LobbyGameState_C
// Size: 0x308 // Inherited bytes: 0x300
struct ABP_LobbyGameState_C : ASolarGameStateBase {
	// Fields
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x300 // Size: 0x08
};

