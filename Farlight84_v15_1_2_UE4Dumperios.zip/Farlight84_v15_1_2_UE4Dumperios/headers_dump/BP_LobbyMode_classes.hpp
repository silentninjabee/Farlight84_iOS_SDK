#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_LobbyMode.BP_LobbyMode_C
// Size: 0x2d0 // Inherited bytes: 0x2c8
struct ABP_LobbyMode_C : AGameModeBase {
	// Fields
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x2c8 // Size: 0x08
};

