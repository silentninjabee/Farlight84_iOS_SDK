#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class CascadeExtensionPlugin.AbstractParticleModule
// Size: 0x60 // Inherited bytes: 0x30
struct UAbstractParticleModule : UParticleModule {
	// Fields
	struct FParticleRandomSeedInfo RandomSeedInfo; // Offset: 0x30 // Size: 0x20
	int32_t StartDelay; // Offset: 0x50 // Size: 0x04
	int32_t MaxDuration; // Offset: 0x54 // Size: 0x04
	int32_t LoopAfter; // Offset: 0x58 // Size: 0x04
	char pad_0x5C[0x4]; // Offset: 0x5c // Size: 0x04
};

// Object Name: Class CascadeExtensionPlugin.ParticleModuleLocationHeightmap
// Size: 0xa8 // Inherited bytes: 0x60
struct UParticleModuleLocationHeightmap : UAbstractParticleModule {
	// Fields
	struct UTexture2D* HeightmapTexture; // Offset: 0x60 // Size: 0x08
	bool UpdateWithTick; // Offset: 0x68 // Size: 0x01
	bool SmoothUpdate; // Offset: 0x69 // Size: 0x01
	char pad_0x6A[0x2]; // Offset: 0x6a // Size: 0x02
	struct FBox MapBounds; // Offset: 0x6c // Size: 0x1c
	float Intensity; // Offset: 0x88 // Size: 0x04
	char pad_0x8C[0x1c]; // Offset: 0x8c // Size: 0x1c
};

// Object Name: Class CascadeExtensionPlugin.ParticleDataProvider
// Size: 0x28 // Inherited bytes: 0x28
struct UParticleDataProvider : UInterface {
	// Functions

	// Object Name: Function CascadeExtensionPlugin.ParticleDataProvider.UpdateParticle
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	struct FParticleProperties UpdateParticle(struct FParticleProperties currentParticleProperties); // Offset: 0x1016feb1c // Return & Params: Num(2) Size(0x88)

	// Object Name: Function CascadeExtensionPlugin.ParticleDataProvider.SpawnParticle
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	struct FParticleProperties SpawnParticle(struct FParticleProperties currentParticleProperties); // Offset: 0x1016febec // Return & Params: Num(2) Size(0x88)
};

// Object Name: Class CascadeExtensionPlugin.ParticleModuleCustomData
// Size: 0x70 // Inherited bytes: 0x60
struct UParticleModuleCustomData : UAbstractParticleModule {
	// Fields
	struct FName DataProviderParameterName; // Offset: 0x60 // Size: 0x08
	bool UpdatedSpawnedParticles; // Offset: 0x68 // Size: 0x01
	bool UpdatedTickedParticles; // Offset: 0x69 // Size: 0x01
	bool UseLocationFromProvider; // Offset: 0x6a // Size: 0x01
	bool UseVelocityFromProvider; // Offset: 0x6b // Size: 0x01
	bool UseSizeFromProvider; // Offset: 0x6c // Size: 0x01
	bool UseColorFromProvider; // Offset: 0x6d // Size: 0x01
	bool UseRotationFromProvider; // Offset: 0x6e // Size: 0x01
	bool UseRotationRateFromProvider; // Offset: 0x6f // Size: 0x01
};

// Object Name: Class CascadeExtensionPlugin.ParticleModuleSwarmMovement
// Size: 0xa0 // Inherited bytes: 0x60
struct UParticleModuleSwarmMovement : UAbstractParticleModule {
	// Fields
	float PerceptionRadius; // Offset: 0x60 // Size: 0x04
	float MaxAcceleration; // Offset: 0x64 // Size: 0x04
	float MaxVelocity; // Offset: 0x68 // Size: 0x04
	float SeparationWeight; // Offset: 0x6c // Size: 0x04
	float AlignmentWeight; // Offset: 0x70 // Size: 0x04
	float CohesionWeight; // Offset: 0x74 // Size: 0x04
	float BlindspotAngleDeg; // Offset: 0x78 // Size: 0x04
	enum class EDistanceWeight SeparationDistanceWeight; // Offset: 0x7c // Size: 0x01
	char pad_0x7D[0x3]; // Offset: 0x7d // Size: 0x03
	struct TArray<struct FVector> SteeringTargets; // Offset: 0x80 // Size: 0x10
	float SteeringWeight; // Offset: 0x90 // Size: 0x04
	enum class EDistanceWeight SteeringTargetDistanceWeight; // Offset: 0x94 // Size: 0x01
	char pad_0x95[0x3]; // Offset: 0x95 // Size: 0x03
	struct FName DynamicSteeringPointProviderName; // Offset: 0x98 // Size: 0x08
};

// Object Name: Class CascadeExtensionPlugin.ParticleModuleSortOrder
// Size: 0x68 // Inherited bytes: 0x60
struct UParticleModuleSortOrder : UAbstractParticleModule {
	// Fields
	int32_t SortOrder; // Offset: 0x60 // Size: 0x04
	char pad_0x64[0x4]; // Offset: 0x64 // Size: 0x04
};

// Object Name: Class CascadeExtensionPlugin.ParticleModuleDecalComponent
// Size: 0x120 // Inherited bytes: 0x60
struct UParticleModuleDecalComponent : UAbstractParticleModule {
	// Fields
	struct TArray<struct UMaterialInterface*> DecalMaterials; // Offset: 0x60 // Size: 0x10
	struct FRawDistributionVector DecalScale; // Offset: 0x70 // Size: 0x48
	bool ScaleWithParticleSize; // Offset: 0xb8 // Size: 0x01
	char pad_0xB9[0x7]; // Offset: 0xb9 // Size: 0x07
	struct FRawDistributionVector DecalRotation; // Offset: 0xc0 // Size: 0x48
	bool RotateToParticleVelocity; // Offset: 0x108 // Size: 0x01
	char pad_0x109[0x3]; // Offset: 0x109 // Size: 0x03
	int32_t SortOrder; // Offset: 0x10c // Size: 0x04
	bool OptimizeDecalComponentUsage; // Offset: 0x110 // Size: 0x01
	char pad_0x111[0x3]; // Offset: 0x111 // Size: 0x03
	struct FName MaterialColorParameter; // Offset: 0x114 // Size: 0x08
	char pad_0x11C[0x4]; // Offset: 0x11c // Size: 0x04
};

// Object Name: Class CascadeExtensionPlugin.ParticleModuleVelocityTurbulence
// Size: 0x80 // Inherited bytes: 0x60
struct UParticleModuleVelocityTurbulence : UAbstractParticleModule {
	// Fields
	struct FVector Intensity; // Offset: 0x60 // Size: 0x0c
	float LengthScale; // Offset: 0x6c // Size: 0x04
	float Tightness; // Offset: 0x70 // Size: 0x04
	float MaxAcceleration; // Offset: 0x74 // Size: 0x04
	float MaxVelocity; // Offset: 0x78 // Size: 0x04
	char pad_0x7C[0x4]; // Offset: 0x7c // Size: 0x04
};

// Object Name: Class CascadeExtensionPlugin.ParticleModuleLocationJiggle
// Size: 0xa8 // Inherited bytes: 0x60
struct UParticleModuleLocationJiggle : UAbstractParticleModule {
	// Fields
	struct FRawDistributionVector Intensity; // Offset: 0x60 // Size: 0x48
};

// Object Name: Class CascadeExtensionPlugin.ParticleModuleLocationSpiral
// Size: 0x120 // Inherited bytes: 0x60
struct UParticleModuleLocationSpiral : UAbstractParticleModule {
	// Fields
	struct FRawDistributionVector StartLocation; // Offset: 0x60 // Size: 0x48
	struct FRawDistributionFloat Radius; // Offset: 0xa8 // Size: 0x30
	float DeltaAngle; // Offset: 0xd8 // Size: 0x04
	float EllipseA; // Offset: 0xdc // Size: 0x04
	float EllipseB; // Offset: 0xe0 // Size: 0x04
	char pad_0xE4[0x4]; // Offset: 0xe4 // Size: 0x04
	struct FRawDistributionFloat DiscHeight; // Offset: 0xe8 // Size: 0x30
	float FalloffFactor; // Offset: 0x118 // Size: 0x04
	char pad_0x11C[0x4]; // Offset: 0x11c // Size: 0x04
};

// Object Name: Class CascadeExtensionPlugin.ParticleDecalComponent
// Size: 0x3a0 // Inherited bytes: 0x390
struct UParticleDecalComponent : UDecalComponent {
	// Fields
	int32_t ModuleID; // Offset: 0x388 // Size: 0x04
	float TimeLeftUntilDestruction; // Offset: 0x38c // Size: 0x04
	struct FVector BaseScale; // Offset: 0x390 // Size: 0x0c
};

// Object Name: Class CascadeExtensionPlugin.ParticleModuleForcePoints
// Size: 0x88 // Inherited bytes: 0x60
struct UParticleModuleForcePoints : UAbstractParticleModule {
	// Fields
	float Intensity; // Offset: 0x60 // Size: 0x04
	char pad_0x64[0x4]; // Offset: 0x64 // Size: 0x04
	struct TArray<struct FVector> Points; // Offset: 0x68 // Size: 0x10
	enum class EDistanceWeight SeparationDistanceWeight; // Offset: 0x78 // Size: 0x01
	char pad_0x79[0x3]; // Offset: 0x79 // Size: 0x03
	float DistanceScale; // Offset: 0x7c // Size: 0x04
	struct FName DynamicForcePointProviderName; // Offset: 0x80 // Size: 0x08
};

// Object Name: Class CascadeExtensionPlugin.ParticleModuleLocationMesh
// Size: 0x150 // Inherited bytes: 0x60
struct UParticleModuleLocationMesh : UAbstractParticleModule {
	// Fields
	struct UStaticMesh* SurfaceMesh; // Offset: 0x60 // Size: 0x08
	struct FName DynamicMeshParameterName; // Offset: 0x68 // Size: 0x08
	struct FTransform MeshTransform; // Offset: 0x70 // Size: 0x30
	bool EqualTriangeWeight; // Offset: 0xa0 // Size: 0x01
	char pad_0xA1[0x7]; // Offset: 0xa1 // Size: 0x07
	struct FRawDistributionFloat VelocityScale; // Offset: 0xa8 // Size: 0x30
	char pad_0xD8[0x78]; // Offset: 0xd8 // Size: 0x78

	// Functions

	// Object Name: Function CascadeExtensionPlugin.ParticleModuleLocationMesh.OnCachedActorDestroyed
	// Flags: [Final|Native|Private]
	void OnCachedActorDestroyed(struct AActor* DestroyedActor); // Offset: 0x101702f34 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class CascadeExtensionPlugin.ParticleModuleLocationDonut
// Size: 0x78 // Inherited bytes: 0x60
struct UParticleModuleLocationDonut : UAbstractParticleModule {
	// Fields
	struct FVector Center; // Offset: 0x60 // Size: 0x0c
	float MinRadius; // Offset: 0x6c // Size: 0x04
	float MaxRadius; // Offset: 0x70 // Size: 0x04
	bool SurfaceOnly; // Offset: 0x74 // Size: 0x01
	bool IsFlat; // Offset: 0x75 // Size: 0x01
	char pad_0x76[0x2]; // Offset: 0x76 // Size: 0x02
};

// Object Name: Class CascadeExtensionPlugin.ParticleModuleColorTexture
// Size: 0xb0 // Inherited bytes: 0x60
struct UParticleModuleColorTexture : UAbstractParticleModule {
	// Fields
	struct UTexture2D* ColorIndexTexture; // Offset: 0x60 // Size: 0x08
	bool UpdateWithTick; // Offset: 0x68 // Size: 0x01
	char pad_0x69[0x3]; // Offset: 0x69 // Size: 0x03
	struct FBox MapBounds; // Offset: 0x6c // Size: 0x1c
	enum class ESpaceAxis ParticleAxisToTextureX; // Offset: 0x88 // Size: 0x01
	enum class ESpaceAxis ParticleAxisToTextureY; // Offset: 0x89 // Size: 0x01
	char pad_0x8A[0x2]; // Offset: 0x8a // Size: 0x02
	float Intensity; // Offset: 0x8c // Size: 0x04
	bool UseTextureAlpha; // Offset: 0x90 // Size: 0x01
	char pad_0x91[0x1f]; // Offset: 0x91 // Size: 0x1f
};

// Object Name: Class CascadeExtensionPlugin.ParticleModuleSizeBySpeedOverTime
// Size: 0xc8 // Inherited bytes: 0x60
struct UParticleModuleSizeBySpeedOverTime : UAbstractParticleModule {
	// Fields
	struct FRawDistributionVector Size; // Offset: 0x60 // Size: 0x48
	bool InvertSpeed; // Offset: 0xa8 // Size: 0x01
	char pad_0xA9[0x3]; // Offset: 0xa9 // Size: 0x03
	struct FVector MaxSize; // Offset: 0xac // Size: 0x0c
	struct FVector MinSize; // Offset: 0xb8 // Size: 0x0c
	char pad_0xC4[0x4]; // Offset: 0xc4 // Size: 0x04
};

// Object Name: Class CascadeExtensionPlugin.MeshDataProvider
// Size: 0x28 // Inherited bytes: 0x28
struct UMeshDataProvider : UInterface {
	// Functions

	// Object Name: Function CascadeExtensionPlugin.MeshDataProvider.GetMeshTriangleData
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	struct FMeshTriangleData GetMeshTriangleData(); // Offset: 0x1017046d8 // Return & Params: Num(1) Size(0x20)

	// Object Name: Function CascadeExtensionPlugin.MeshDataProvider.GetDataRevision
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	int32_t GetDataRevision(); // Offset: 0x10170469c // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class CascadeExtensionPlugin.ForcePointDataProvider
// Size: 0x28 // Inherited bytes: 0x28
struct UForcePointDataProvider : UInterface {
	// Functions

	// Object Name: Function CascadeExtensionPlugin.ForcePointDataProvider.GetForcePoints
	// Flags: [Native|Event|Public|BlueprintEvent|Const]
	struct FForcePoints GetForcePoints(); // Offset: 0x1017058a8 // Return & Params: Num(1) Size(0x20)
};

