#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct CascadeExtensionPlugin.ParticleProperties
// Size: 0x44 // Inherited bytes: 0x00
struct FParticleProperties {
	// Fields
	int32_t ParticleId; // Offset: 0x00 // Size: 0x04
	float RelativeTime; // Offset: 0x04 // Size: 0x04
	struct FVector Location; // Offset: 0x08 // Size: 0x0c
	struct FVector Velocity; // Offset: 0x14 // Size: 0x0c
	struct FVector Size; // Offset: 0x20 // Size: 0x0c
	struct FLinearColor Color; // Offset: 0x2c // Size: 0x10
	float Rotation; // Offset: 0x3c // Size: 0x04
	float RotationRate; // Offset: 0x40 // Size: 0x04
};

// Object Name: ScriptStruct CascadeExtensionPlugin.MeshTriangleData
// Size: 0x20 // Inherited bytes: 0x00
struct FMeshTriangleData {
	// Fields
	struct TArray<struct FVector> Vertices; // Offset: 0x00 // Size: 0x10
	struct TArray<struct FTriangleIndices> Indices; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct CascadeExtensionPlugin.TriangleIndices
// Size: 0x0c // Inherited bytes: 0x00
struct FTriangleIndices {
	// Fields
	int32_t v0; // Offset: 0x00 // Size: 0x04
	int32_t v1; // Offset: 0x04 // Size: 0x04
	int32_t v2; // Offset: 0x08 // Size: 0x04
};

// Object Name: ScriptStruct CascadeExtensionPlugin.ForcePoints
// Size: 0x20 // Inherited bytes: 0x00
struct FForcePoints {
	// Fields
	float Intensity; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct TArray<struct FVector> PointLocations; // Offset: 0x08 // Size: 0x10
	enum class EDistanceWeight SeparationDistanceWeight; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x3]; // Offset: 0x19 // Size: 0x03
	float DistanceScale; // Offset: 0x1c // Size: 0x04
};

