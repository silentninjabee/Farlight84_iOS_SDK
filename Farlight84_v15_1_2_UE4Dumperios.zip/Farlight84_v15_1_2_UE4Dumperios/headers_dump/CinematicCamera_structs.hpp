#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct CinematicCamera.CameraLookatTrackingSettings
// Size: 0x50 // Inherited bytes: 0x00
struct FCameraLookatTrackingSettings {
	// Fields
	char bEnableLookAtTracking : 1; // Offset: 0x00 // Size: 0x01
	char bDrawDebugLookAtTrackingPosition : 1; // Offset: 0x00 // Size: 0x01
	char pad_0x0_2 : 6; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float LookAtTrackingInterpSpeed; // Offset: 0x04 // Size: 0x04
	char pad_0x8[0x10]; // Offset: 0x08 // Size: 0x10
	struct TSoftObjectPtr<AActor> ActorToTrack; // Offset: 0x18 // Size: 0x28
	struct FVector RelativeOffset; // Offset: 0x40 // Size: 0x0c
	char bAllowRoll : 1; // Offset: 0x4c // Size: 0x01
	char pad_0x4C_1 : 7; // Offset: 0x4c // Size: 0x01
	char pad_0x4D[0x3]; // Offset: 0x4d // Size: 0x03
};

// Object Name: ScriptStruct CinematicCamera.CameraFocusSettings
// Size: 0x58 // Inherited bytes: 0x00
struct FCameraFocusSettings {
	// Fields
	enum class ECameraFocusMethod FocusMethod; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	float ManualFocusDistance; // Offset: 0x04 // Size: 0x04
	struct FCameraTrackingFocusSettings TrackingFocusSettings; // Offset: 0x08 // Size: 0x38
	char bDrawDebugFocusPlane : 1; // Offset: 0x40 // Size: 0x01
	char pad_0x40_1 : 7; // Offset: 0x40 // Size: 0x01
	char pad_0x41[0x3]; // Offset: 0x41 // Size: 0x03
	struct FColor DebugFocusPlaneColor; // Offset: 0x44 // Size: 0x04
	char bSmoothFocusChanges : 1; // Offset: 0x48 // Size: 0x01
	char pad_0x48_1 : 7; // Offset: 0x48 // Size: 0x01
	char pad_0x49[0x3]; // Offset: 0x49 // Size: 0x03
	float FocusSmoothingInterpSpeed; // Offset: 0x4c // Size: 0x04
	float FocusOffset; // Offset: 0x50 // Size: 0x04
	char pad_0x54[0x4]; // Offset: 0x54 // Size: 0x04
};

// Object Name: ScriptStruct CinematicCamera.CameraTrackingFocusSettings
// Size: 0x38 // Inherited bytes: 0x00
struct FCameraTrackingFocusSettings {
	// Fields
	struct TSoftObjectPtr<AActor> ActorToTrack; // Offset: 0x00 // Size: 0x28
	struct FVector RelativeOffset; // Offset: 0x28 // Size: 0x0c
	char bDrawDebugTrackingFocusPoint : 1; // Offset: 0x34 // Size: 0x01
	char pad_0x34_1 : 7; // Offset: 0x34 // Size: 0x01
	char pad_0x35[0x3]; // Offset: 0x35 // Size: 0x03
};

// Object Name: ScriptStruct CinematicCamera.NamedLensPreset
// Size: 0x28 // Inherited bytes: 0x00
struct FNamedLensPreset {
	// Fields
	struct FString Name; // Offset: 0x00 // Size: 0x10
	struct FCameraLensSettings LensSettings; // Offset: 0x10 // Size: 0x18
};

// Object Name: ScriptStruct CinematicCamera.CameraLensSettings
// Size: 0x18 // Inherited bytes: 0x00
struct FCameraLensSettings {
	// Fields
	float MinFocalLength; // Offset: 0x00 // Size: 0x04
	float MaxFocalLength; // Offset: 0x04 // Size: 0x04
	float MinFStop; // Offset: 0x08 // Size: 0x04
	float MaxFStop; // Offset: 0x0c // Size: 0x04
	float MinimumFocusDistance; // Offset: 0x10 // Size: 0x04
	int32_t DiaphragmBladeCount; // Offset: 0x14 // Size: 0x04
};

// Object Name: ScriptStruct CinematicCamera.NamedFilmbackPreset
// Size: 0x20 // Inherited bytes: 0x00
struct FNamedFilmbackPreset {
	// Fields
	struct FString Name; // Offset: 0x00 // Size: 0x10
	struct FCameraFilmbackSettings FilmbackSettings; // Offset: 0x10 // Size: 0x0c
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct CinematicCamera.CameraFilmbackSettings
// Size: 0x0c // Inherited bytes: 0x00
struct FCameraFilmbackSettings {
	// Fields
	float SensorWidth; // Offset: 0x00 // Size: 0x04
	float SensorHeight; // Offset: 0x04 // Size: 0x04
	float SensorAspectRatio; // Offset: 0x08 // Size: 0x04
};

