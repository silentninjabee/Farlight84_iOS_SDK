#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct ClothingSystemRuntimeInterface.ClothCollisionData
// Size: 0x40 // Inherited bytes: 0x00
struct FClothCollisionData {
	// Fields
	struct TArray<struct FClothCollisionPrim_Sphere> Spheres; // Offset: 0x00 // Size: 0x10
	struct TArray<struct FClothCollisionPrim_SphereConnection> SphereConnections; // Offset: 0x10 // Size: 0x10
	struct TArray<struct FClothCollisionPrim_Convex> Convexes; // Offset: 0x20 // Size: 0x10
	struct TArray<struct FClothCollisionPrim_Box> Boxes; // Offset: 0x30 // Size: 0x10
};

// Object Name: ScriptStruct ClothingSystemRuntimeInterface.ClothCollisionPrim_Box
// Size: 0x30 // Inherited bytes: 0x00
struct FClothCollisionPrim_Box {
	// Fields
	struct FVector LocalPosition; // Offset: 0x00 // Size: 0x0c
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct FQuat LocalRotation; // Offset: 0x10 // Size: 0x10
	struct FVector HalfExtents; // Offset: 0x20 // Size: 0x0c
	int32_t BoneIndex; // Offset: 0x2c // Size: 0x04
};

// Object Name: ScriptStruct ClothingSystemRuntimeInterface.ClothCollisionPrim_Convex
// Size: 0x28 // Inherited bytes: 0x00
struct FClothCollisionPrim_Convex {
	// Fields
	struct TArray<struct FPlane> Planes; // Offset: 0x00 // Size: 0x10
	struct TArray<struct FVector> SurfacePoints; // Offset: 0x10 // Size: 0x10
	int32_t BoneIndex; // Offset: 0x20 // Size: 0x04
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
};

// Object Name: ScriptStruct ClothingSystemRuntimeInterface.ClothCollisionPrim_SphereConnection
// Size: 0x08 // Inherited bytes: 0x00
struct FClothCollisionPrim_SphereConnection {
	// Fields
	int32_t SphereIndices[0x2]; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct ClothingSystemRuntimeInterface.ClothCollisionPrim_Sphere
// Size: 0x14 // Inherited bytes: 0x00
struct FClothCollisionPrim_Sphere {
	// Fields
	int32_t BoneIndex; // Offset: 0x00 // Size: 0x04
	float Radius; // Offset: 0x04 // Size: 0x04
	struct FVector LocalPosition; // Offset: 0x08 // Size: 0x0c
};

// Object Name: ScriptStruct ClothingSystemRuntimeInterface.ClothVertBoneData
// Size: 0x4c // Inherited bytes: 0x00
struct FClothVertBoneData {
	// Fields
	int32_t NumInfluences; // Offset: 0x00 // Size: 0x04
	uint16_t BoneIndices[0xc]; // Offset: 0x04 // Size: 0x18
	float BoneWeights[0xc]; // Offset: 0x1c // Size: 0x30
};

