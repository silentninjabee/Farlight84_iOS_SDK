#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct ClothingSystemRuntimeNv.ClothConstraintSetupNv
// Size: 0x10 // Inherited bytes: 0x00
struct FClothConstraintSetupNv {
	// Fields
	float Stiffness; // Offset: 0x00 // Size: 0x04
	float StiffnessMultiplier; // Offset: 0x04 // Size: 0x04
	float StretchLimit; // Offset: 0x08 // Size: 0x04
	float CompressionLimit; // Offset: 0x0c // Size: 0x04
};

