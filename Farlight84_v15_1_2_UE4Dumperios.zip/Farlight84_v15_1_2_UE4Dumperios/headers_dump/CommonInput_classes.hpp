#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class CommonInput.CommonUIInputData
// Size: 0x48 // Inherited bytes: 0x28
struct UCommonUIInputData : UObject {
	// Fields
	struct FDataTableRowHandle DefaultClickAction; // Offset: 0x28 // Size: 0x10
	struct FDataTableRowHandle DefaultBackAction; // Offset: 0x38 // Size: 0x10
};

// Object Name: Class CommonInput.CommonInputBaseControllerData
// Size: 0x100 // Inherited bytes: 0x28
struct UCommonInputBaseControllerData : UObject {
	// Fields
	enum class ECommonInputType InputType; // Offset: 0x28 // Size: 0x01
	char pad_0x29[0x3]; // Offset: 0x29 // Size: 0x03
	struct FName GamepadName; // Offset: 0x2c // Size: 0x08
	char pad_0x34[0x4]; // Offset: 0x34 // Size: 0x04
	struct FText GamepadDisplayName; // Offset: 0x38 // Size: 0x18
	struct FText GamepadCategory; // Offset: 0x50 // Size: 0x18
	struct FText GamepadPlatformName; // Offset: 0x68 // Size: 0x18
	struct TArray<struct FInputDeviceIdentifierPair> GamepadHardwareIdMapping; // Offset: 0x80 // Size: 0x10
	struct TSoftObjectPtr<UTexture2D> ControllerTexture; // Offset: 0x90 // Size: 0x28
	struct TSoftObjectPtr<UTexture2D> ControllerButtonMaskTexture; // Offset: 0xb8 // Size: 0x28
	struct TArray<struct FCommonInputKeyBrushConfiguration> InputBrushDataMap; // Offset: 0xe0 // Size: 0x10
	struct TArray<struct FCommonInputKeySetBrushConfiguration> InputBrushKeySets; // Offset: 0xf0 // Size: 0x10

	// Functions

	// Object Name: Function CommonInput.CommonInputBaseControllerData.GetRegisteredGamepads
	// Flags: [Final|Native|Static|Public]
	struct TArray<struct FName> GetRegisteredGamepads(); // Offset: 0x1015f5968 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class CommonInput.CommonInputSettings
// Size: 0x110 // Inherited bytes: 0x28
struct UCommonInputSettings : UObject {
	// Fields
	struct TSoftClassPtr<UObject> InputData; // Offset: 0x28 // Size: 0x28
	struct TMap<struct FName, struct FCommonInputPlatformBaseData> CommonInputPlatformData; // Offset: 0x50 // Size: 0x50
	bool bEnableInputMethodThrashingProtection; // Offset: 0xa0 // Size: 0x01
	char pad_0xA1[0x3]; // Offset: 0xa1 // Size: 0x03
	int32_t InputMethodThrashingLimit; // Offset: 0xa4 // Size: 0x04
	double InputMethodThrashingWindowInSeconds; // Offset: 0xa8 // Size: 0x08
	double InputMethodThrashingCooldownInSeconds; // Offset: 0xb0 // Size: 0x08
	bool bAllowOutOfFocusDeviceInput; // Offset: 0xb8 // Size: 0x01
	char pad_0xB9[0x7]; // Offset: 0xb9 // Size: 0x07
	struct UCommonUIInputData* InputDataClass; // Offset: 0xc0 // Size: 0x08
	struct FCommonInputPlatformBaseData CurrentPlatform; // Offset: 0xc8 // Size: 0x48

	// Functions

	// Object Name: Function CommonInput.CommonInputSettings.GetRegisteredPlatforms
	// Flags: [Final|Native|Static|Private]
	struct TArray<struct FName> GetRegisteredPlatforms(); // Offset: 0x1015f5d34 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class CommonInput.CommonInputSubsystem
// Size: 0xf8 // Inherited bytes: 0x30
struct UCommonInputSubsystem : ULocalPlayerSubsystem {
	// Fields
	char pad_0x30[0x20]; // Offset: 0x30 // Size: 0x20
	struct FMulticastInlineDelegate OnInputMethodChanged; // Offset: 0x50 // Size: 0x10
	int32_t NumberOfInputMethodChangesRecently; // Offset: 0x60 // Size: 0x04
	char pad_0x64[0x4]; // Offset: 0x64 // Size: 0x04
	double LastInputMethodChangeTime; // Offset: 0x68 // Size: 0x08
	double LastTimeInputMethodThrashingBegan; // Offset: 0x70 // Size: 0x08
	enum class ECommonInputType LastInputType; // Offset: 0x78 // Size: 0x01
	enum class ECommonInputType CurrentInputType; // Offset: 0x79 // Size: 0x01
	char pad_0x7A[0x2]; // Offset: 0x7a // Size: 0x02
	struct FName GamepadInputType; // Offset: 0x7c // Size: 0x08
	char pad_0x84[0x4]; // Offset: 0x84 // Size: 0x04
	struct TMap<struct FName, enum class ECommonInputType> CurrentInputLocks; // Offset: 0x88 // Size: 0x50
	char pad_0xD8[0x18]; // Offset: 0xd8 // Size: 0x18
	bool bIsGamepadSimulatedClick; // Offset: 0xf0 // Size: 0x01
	char pad_0xF1[0x7]; // Offset: 0xf1 // Size: 0x07

	// Functions

	// Object Name: Function CommonInput.CommonInputSubsystem.ShouldShowInputKeys
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool ShouldShowInputKeys(); // Offset: 0x1015f6128 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function CommonInput.CommonInputSubsystem.SetGamepadInputType
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetGamepadInputType(struct FName InGamepadInputType); // Offset: 0x1015f6190 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function CommonInput.CommonInputSubsystem.SetCurrentInputType
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool SetCurrentInputType(enum class ECommonInputType NewInputType); // Offset: 0x1015f6244 // Return & Params: Num(2) Size(0x2)

	// Object Name: Function CommonInput.CommonInputSubsystem.SetCanChangeInputMethod
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetCanChangeInputMethod(bool bCanChange); // Offset: 0x1015f60a0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function CommonInput.CommonInputSubsystem.IsUsingPointerInput
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsUsingPointerInput(); // Offset: 0x1015f615c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function CommonInput.CommonInputSubsystem.IsInputMethodActive
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsInputMethodActive(enum class ECommonInputType InputMethod); // Offset: 0x1015f633c // Return & Params: Num(2) Size(0x2)

	// Object Name: Function CommonInput.CommonInputSubsystem.GetDefaultInputType
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	enum class ECommonInputType GetDefaultInputType(); // Offset: 0x1015f62d4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function CommonInput.CommonInputSubsystem.GetCurrentInputType
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	enum class ECommonInputType GetCurrentInputType(); // Offset: 0x1015f6308 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function CommonInput.CommonInputSubsystem.GetCurrentGamepadName
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct FName GetCurrentGamepadName(); // Offset: 0x1015f6210 // Return & Params: Num(1) Size(0x8)
};

