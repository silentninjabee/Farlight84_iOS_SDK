#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct CommonInput.CommonInputPlatformBaseData
// Size: 0x48 // Inherited bytes: 0x00
struct FCommonInputPlatformBaseData {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
	bool bSupported; // Offset: 0x08 // Size: 0x01
	enum class ECommonInputType DefaultInputType; // Offset: 0x09 // Size: 0x01
	bool bSupportsMouseAndKeyboard; // Offset: 0x0a // Size: 0x01
	bool bSupportsGamepad; // Offset: 0x0b // Size: 0x01
	struct FName DefaultGamepadName; // Offset: 0x0c // Size: 0x08
	bool bCanChangeGamepadType; // Offset: 0x14 // Size: 0x01
	bool bSupportsTouch; // Offset: 0x15 // Size: 0x01
	char pad_0x16[0x2]; // Offset: 0x16 // Size: 0x02
	struct TArray<struct TSoftClassPtr<UObject>> ControllerData; // Offset: 0x18 // Size: 0x10
	struct TArray<struct UCommonInputBaseControllerData*> ControllerDataClasses; // Offset: 0x28 // Size: 0x10
	struct TArray<struct FCommonInputControllerSimpleData> ControllerSimpleData; // Offset: 0x38 // Size: 0x10
};

// Object Name: ScriptStruct CommonInput.CommonInputControllerSimpleData
// Size: 0x18 // Inherited bytes: 0x00
struct FCommonInputControllerSimpleData {
	// Fields
	struct FName GamepadName; // Offset: 0x00 // Size: 0x08
	struct TArray<struct FInputDeviceIdentifierPair> GamepadHardwareIdMapping; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct CommonInput.InputDeviceIdentifierPair
// Size: 0x18 // Inherited bytes: 0x00
struct FInputDeviceIdentifierPair {
	// Fields
	struct FName InputDeviceName; // Offset: 0x00 // Size: 0x08
	struct FString HardwareDeviceIdentifier; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct CommonInput.CommonInputKeySetBrushConfiguration
// Size: 0xf0 // Inherited bytes: 0x00
struct FCommonInputKeySetBrushConfiguration {
	// Fields
	struct TArray<struct FKey> Keys; // Offset: 0x00 // Size: 0x10
	struct FSlateBrush KeyBrush; // Offset: 0x10 // Size: 0xe0
};

// Object Name: ScriptStruct CommonInput.CommonInputKeyBrushConfiguration
// Size: 0x100 // Inherited bytes: 0x00
struct FCommonInputKeyBrushConfiguration {
	// Fields
	struct FKey Key; // Offset: 0x00 // Size: 0x18
	char pad_0x18[0x8]; // Offset: 0x18 // Size: 0x08
	struct FSlateBrush KeyBrush; // Offset: 0x20 // Size: 0xe0
};

