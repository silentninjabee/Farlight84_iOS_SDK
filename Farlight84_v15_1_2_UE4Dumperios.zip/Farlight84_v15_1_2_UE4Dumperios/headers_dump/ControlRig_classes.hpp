#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class ControlRig.ControlRig
// Size: 0x360 // Inherited bytes: 0x28
struct UControlRig : UObject {
	// Fields
	char pad_0x28[0x48]; // Offset: 0x28 // Size: 0x48
	enum class ERigExecutionType ExecutionType; // Offset: 0x70 // Size: 0x01
	char pad_0x71[0x7]; // Offset: 0x71 // Size: 0x07
	struct URigVM* VM; // Offset: 0x78 // Size: 0x08
	struct FRigHierarchyContainer Hierarchy; // Offset: 0x80 // Size: 0x1b0
	struct TSoftObjectPtr<UControlRigGizmoLibrary> GizmoLibrary; // Offset: 0x230 // Size: 0x28
	char pad_0x258[0x10]; // Offset: 0x258 // Size: 0x10
	struct TMap<struct FName, struct FCachedPropertyPath> InputProperties; // Offset: 0x268 // Size: 0x50
	struct TMap<struct FName, struct FCachedPropertyPath> OutputProperties; // Offset: 0x2b8 // Size: 0x50
	struct FControlRigDrawContainer DrawContainer; // Offset: 0x308 // Size: 0x10
	char pad_0x318[0x8]; // Offset: 0x318 // Size: 0x08
	struct UAnimationDataSourceRegistry* DataSourceRegistry; // Offset: 0x320 // Size: 0x08
	char pad_0x328[0x38]; // Offset: 0x328 // Size: 0x38
};

// Object Name: Class ControlRig.AdditiveControlRig
// Size: 0x370 // Inherited bytes: 0x360
struct UAdditiveControlRig : UControlRig {
	// Fields
	char pad_0x360[0x10]; // Offset: 0x360 // Size: 0x10
};

// Object Name: Class ControlRig.ControlRigBindingTrack
// Size: 0x78 // Inherited bytes: 0x78
struct UControlRigBindingTrack : UMovieSceneSpawnTrack {
};

// Object Name: Class ControlRig.ControlRigBlueprintGeneratedClass
// Size: 0x418 // Inherited bytes: 0x418
struct UControlRigBlueprintGeneratedClass : UBlueprintGeneratedClass {
};

// Object Name: Class ControlRig.ControlRigComponent
// Size: 0xf8 // Inherited bytes: 0xb0
struct UControlRigComponent : UActorComponent {
	// Fields
	struct FMulticastInlineDelegate OnPreInitializeDelegate; // Offset: 0xb0 // Size: 0x10
	struct FMulticastInlineDelegate OnPostInitializeDelegate; // Offset: 0xc0 // Size: 0x10
	struct FMulticastInlineDelegate OnPreEvaluateDelegate; // Offset: 0xd0 // Size: 0x10
	struct FMulticastInlineDelegate OnPostEvaluateDelegate; // Offset: 0xe0 // Size: 0x10
	struct UControlRig* ControlRig; // Offset: 0xf0 // Size: 0x08

	// Functions

	// Object Name: Function ControlRig.ControlRigComponent.OnPreInitialize
	// Flags: [Native|Event|Public|BlueprintEvent]
	void OnPreInitialize(); // Offset: 0x101664d5c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function ControlRig.ControlRigComponent.OnPreEvaluate
	// Flags: [Native|Event|Public|BlueprintEvent]
	void OnPreEvaluate(); // Offset: 0x101664d24 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function ControlRig.ControlRigComponent.OnPostInitialize
	// Flags: [Native|Event|Public|BlueprintEvent]
	void OnPostInitialize(); // Offset: 0x101664d40 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function ControlRig.ControlRigComponent.OnPostEvaluate
	// Flags: [Native|Event|Public|BlueprintEvent]
	void OnPostEvaluate(); // Offset: 0x101664d08 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function ControlRig.ControlRigComponent.BP_GetControlRig
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct UControlRig* BP_GetControlRig(); // Offset: 0x101664d78 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class ControlRig.ControlRigGizmoLibrary
// Size: 0xe0 // Inherited bytes: 0x28
struct UControlRigGizmoLibrary : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08
	struct FControlRigGizmoDefinition DefaultGizmo; // Offset: 0x30 // Size: 0x60
	struct TSoftObjectPtr<UMaterial> DefaultMaterial; // Offset: 0x90 // Size: 0x28
	struct FName MaterialColorParameter; // Offset: 0xb8 // Size: 0x08
	struct TArray<struct FControlRigGizmoDefinition> Gizmos; // Offset: 0xc0 // Size: 0x10
	char pad_0xD0[0x10]; // Offset: 0xd0 // Size: 0x10
};

// Object Name: Class ControlRig.ControlRigLayerInstance
// Size: 0x270 // Inherited bytes: 0x270
struct UControlRigLayerInstance : UAnimInstance {
};

// Object Name: Class ControlRig.ControlRigObjectHolder
// Size: 0x38 // Inherited bytes: 0x28
struct UControlRigObjectHolder : UObject {
	// Fields
	struct TArray<struct UObject*> Objects; // Offset: 0x28 // Size: 0x10
};

// Object Name: Class ControlRig.ControlRigSequence
// Size: 0x4f0 // Inherited bytes: 0x498
struct UControlRigSequence : ULevelSequence {
	// Fields
	struct TSoftObjectPtr<UAnimSequence> LastExportedToAnimationSequence; // Offset: 0x498 // Size: 0x28
	struct TSoftObjectPtr<USkeletalMesh> LastExportedUsingSkeletalMesh; // Offset: 0x4c0 // Size: 0x28
	float LastExportedFrameRate; // Offset: 0x4e8 // Size: 0x04
	char pad_0x4EC[0x4]; // Offset: 0x4ec // Size: 0x04
};

// Object Name: Class ControlRig.ControlRigSequencerAnimInstance
// Size: 0x280 // Inherited bytes: 0x270
struct UControlRigSequencerAnimInstance : UAnimSequencerInstance {
	// Fields
	char pad_0x270[0x10]; // Offset: 0x270 // Size: 0x10
};

// Object Name: Class ControlRig.ControlRigSettings
// Size: 0x38 // Inherited bytes: 0x38
struct UControlRigSettings : UDeveloperSettings {
};

// Object Name: Class ControlRig.ControlRigManipulatable
// Size: 0x28 // Inherited bytes: 0x28
struct UControlRigManipulatable : UInterface {
};

// Object Name: Class ControlRig.MovieSceneControlRigParameterSection
// Size: 0x270 // Inherited bytes: 0x138
struct UMovieSceneControlRigParameterSection : UMovieSceneParameterSection {
	// Fields
	struct UControlRig* ControlRig; // Offset: 0x138 // Size: 0x08
	struct TArray<bool> ControlsMask; // Offset: 0x140 // Size: 0x10
	struct FMovieSceneTransformMask TransformMask; // Offset: 0x150 // Size: 0x04
	bool bAdditive; // Offset: 0x154 // Size: 0x01
	bool bApplyBoneFilter; // Offset: 0x155 // Size: 0x01
	char pad_0x156[0x2]; // Offset: 0x156 // Size: 0x02
	struct FInputBlendPose BoneFilter; // Offset: 0x158 // Size: 0x10
	struct FMovieSceneFloatChannel Weight; // Offset: 0x168 // Size: 0xa0
	struct TMap<struct FName, struct FChannelMapInfo> ControlChannelMap; // Offset: 0x208 // Size: 0x50
	char pad_0x258[0x18]; // Offset: 0x258 // Size: 0x18
};

// Object Name: Class ControlRig.MovieSceneControlRigParameterTrack
// Size: 0x80 // Inherited bytes: 0x58
struct UMovieSceneControlRigParameterTrack : UMovieSceneNameableTrack {
	// Fields
	struct UControlRig* ControlRig; // Offset: 0x58 // Size: 0x08
	struct UMovieSceneSection* SectionToKey; // Offset: 0x60 // Size: 0x08
	struct TArray<struct UMovieSceneSection*> Sections; // Offset: 0x68 // Size: 0x10
	struct FName TrackName; // Offset: 0x78 // Size: 0x08
};

// Object Name: Class ControlRig.MovieSceneControlRigSection
// Size: 0x208 // Inherited bytes: 0x150
struct UMovieSceneControlRigSection : UMovieSceneSubSection {
	// Fields
	bool bAdditive; // Offset: 0x150 // Size: 0x01
	bool bApplyBoneFilter; // Offset: 0x151 // Size: 0x01
	char pad_0x152[0x6]; // Offset: 0x152 // Size: 0x06
	struct FInputBlendPose BoneFilter; // Offset: 0x158 // Size: 0x10
	struct FMovieSceneFloatChannel Weight; // Offset: 0x168 // Size: 0xa0
};

// Object Name: Class ControlRig.MovieSceneControlRigTrack
// Size: 0x68 // Inherited bytes: 0x68
struct UMovieSceneControlRigTrack : UMovieSceneSubTrack {
};

