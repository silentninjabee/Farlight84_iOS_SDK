#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class DownloaderTool.DownloaderHttpTask
// Size: 0xc8 // Inherited bytes: 0x28
struct UDownloaderHttpTask : UObject {
	// Fields
	struct FMulticastInlineDelegate OnTaskProgress; // Offset: 0x28 // Size: 0x10
	struct FMulticastInlineDelegate OnTaskSuccess; // Offset: 0x38 // Size: 0x10
	struct FMulticastInlineDelegate OnTaskFailed; // Offset: 0x48 // Size: 0x10
	char pad_0x58[0x70]; // Offset: 0x58 // Size: 0x70
};

// Object Name: Class DownloaderTool.DownloaderUtils
// Size: 0x28 // Inherited bytes: 0x28
struct UDownloaderUtils : UObject {
	// Functions

	// Object Name: Function DownloaderTool.DownloaderUtils.StringFileRawData
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct FString StringFileRawData(struct FDownloaderResponse& InResponse); // Offset: 0x101717990 // Return & Params: Num(2) Size(0x58)

	// Object Name: Function DownloaderTool.DownloaderUtils.SaveResponseToCache
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void SaveResponseToCache(struct FDownloaderResponse& InResponse, struct FString CachePath); // Offset: 0x10171740c // Return & Params: Num(2) Size(0x58)

	// Object Name: Function DownloaderTool.DownloaderUtils.GetVerbFromJsonRequestStr
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetVerbFromJsonRequestStr(struct FString JsonRequestStr); // Offset: 0x10171773c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function DownloaderTool.DownloaderUtils.GetResponseFromCache
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FDownloaderResponse GetResponseFromCache(struct FString InUrl, struct FString CachePath); // Offset: 0x101717220 // Return & Params: Num(3) Size(0x68)

	// Object Name: Function DownloaderTool.DownloaderUtils.GetHeadersFromJsonRequestStr
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct TMap<struct FString, struct FString> GetHeadersFromJsonRequestStr(struct FString JsonRequestStr); // Offset: 0x1017175e0 // Return & Params: Num(2) Size(0x60)

	// Object Name: Function DownloaderTool.DownloaderUtils.execConvertRawDataToTexture
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct UTexture2DDynamic* execConvertRawDataToTexture(struct TArray<char>& Data, int32_t& DataLength); // Offset: 0x101717abc // Return & Params: Num(3) Size(0x20)

	// Object Name: Function DownloaderTool.DownloaderUtils.DecodeFileRawData
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct FString DecodeFileRawData(struct FDownloaderResponse& InResponse); // Offset: 0x101717864 // Return & Params: Num(2) Size(0x58)
};

