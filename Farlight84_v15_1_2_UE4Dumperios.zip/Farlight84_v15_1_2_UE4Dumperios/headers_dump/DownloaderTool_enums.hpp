#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum DownloaderTool.ERawDataAction
enum class ERawDataAction : uint8 {
	Default = 0,
	UTF8String = 1,
	ReverseDecryptString = 2,
	Texture2DDynamic = 3,
	ERawDataAction_MAX = 4
};

// Object Name: Enum DownloaderTool.EDownloaderFailedType
enum class EDownloaderFailedType : uint8 {
	ConnectFailed = 0,
	RequestHeadFailed = 1,
	CreateFileFailed = 2,
	DownloadFailed = 3,
	WriteFailed = 4,
	DeleteOldFailed = 5,
	MoveFailed = 6,
	CreateDownloadTaskFail = 7,
	GetPlatformFileFail = 8,
	GetWrongJsonFormat = 9,
	RequestTimeOut = 10,
	RequestInvalid = 11,
	ResponseInvalid = 12,
	RequestCanceled = 13,
	ResponseNoContent = 14,
	TaskHasCompleted = 15,
	FileIODownloadFailed = 16,
	EDownloaderFailedType_MAX = 17
};

// Object Name: Enum DownloaderTool.EServerInfoState
enum class EServerInfoState : uint8 {
	ESIS_NotReady = 0,
	ESIS_Downloading = 1,
	ESIS_Ready = 2,
	ESIS_Failed = 3,
	ESIS_OutOfDate = 4,
	ESIS_MAX = 5
};

// Object Name: Enum DownloaderTool.EDownloaderState
enum class EDownloaderState : uint8 {
	NotStart = 0,
	Downloading = 1,
	Pausing = 2,
	Completed = 3,
	EDownloaderState_MAX = 4
};

