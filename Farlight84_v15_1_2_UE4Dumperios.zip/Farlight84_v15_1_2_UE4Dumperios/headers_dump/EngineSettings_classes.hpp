#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class EngineSettings.ConsoleSettings
// Size: 0x70 // Inherited bytes: 0x28
struct UConsoleSettings : UObject {
	// Fields
	int32_t MaxScrollbackSize; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
	struct TArray<struct FAutoCompleteCommand> ManualAutoCompleteList; // Offset: 0x30 // Size: 0x10
	struct TArray<struct FString> AutoCompleteMapPaths; // Offset: 0x40 // Size: 0x10
	float BackgroundOpacityPercentage; // Offset: 0x50 // Size: 0x04
	bool bOrderTopToBottom; // Offset: 0x54 // Size: 0x01
	bool bDisplayHelpInAutoComplete; // Offset: 0x55 // Size: 0x01
	char pad_0x56[0x2]; // Offset: 0x56 // Size: 0x02
	struct FColor InputColor; // Offset: 0x58 // Size: 0x04
	struct FColor HistoryColor; // Offset: 0x5c // Size: 0x04
	struct FColor AutoCompleteCommandColor; // Offset: 0x60 // Size: 0x04
	struct FColor AutoCompleteCVarColor; // Offset: 0x64 // Size: 0x04
	struct FColor AutoCompleteFadedColor; // Offset: 0x68 // Size: 0x04
	char pad_0x6C[0x4]; // Offset: 0x6c // Size: 0x04
};

// Object Name: Class EngineSettings.GeneralProjectSettings
// Size: 0x118 // Inherited bytes: 0x28
struct UGeneralProjectSettings : UObject {
	// Fields
	struct FString CompanyName; // Offset: 0x28 // Size: 0x10
	struct FString CompanyDistinguishedName; // Offset: 0x38 // Size: 0x10
	struct FString CopyrightNotice; // Offset: 0x48 // Size: 0x10
	struct FString Description; // Offset: 0x58 // Size: 0x10
	struct FString Homepage; // Offset: 0x68 // Size: 0x10
	struct FString LicensingTerms; // Offset: 0x78 // Size: 0x10
	struct FString PrivacyPolicy; // Offset: 0x88 // Size: 0x10
	struct FGuid ProjectID; // Offset: 0x98 // Size: 0x10
	struct FString ProjectName; // Offset: 0xa8 // Size: 0x10
	struct FString ProjectVersion; // Offset: 0xb8 // Size: 0x10
	struct FString SupportContact; // Offset: 0xc8 // Size: 0x10
	struct FText ProjectDisplayedTitle; // Offset: 0xd8 // Size: 0x18
	struct FText ProjectDebugTitleInfo; // Offset: 0xf0 // Size: 0x18
	bool bShouldWindowPreserveAspectRatio; // Offset: 0x108 // Size: 0x01
	bool bUseBorderlessWindow; // Offset: 0x109 // Size: 0x01
	bool bStartInVR; // Offset: 0x10a // Size: 0x01
	bool bStartInAR; // Offset: 0x10b // Size: 0x01
	bool bSupportAR; // Offset: 0x10c // Size: 0x01
	bool bAllowWindowResize; // Offset: 0x10d // Size: 0x01
	bool bAllowClose; // Offset: 0x10e // Size: 0x01
	bool bAllowMaximize; // Offset: 0x10f // Size: 0x01
	bool bAllowMinimize; // Offset: 0x110 // Size: 0x01
	bool bPCSession; // Offset: 0x111 // Size: 0x01
	bool bSteamSession; // Offset: 0x112 // Size: 0x01
	bool bEpicSession; // Offset: 0x113 // Size: 0x01
	bool bOffcialWinSession; // Offset: 0x114 // Size: 0x01
	bool bSwitchSession; // Offset: 0x115 // Size: 0x01
	char pad_0x116[0x2]; // Offset: 0x116 // Size: 0x02
};

// Object Name: Class EngineSettings.GameMapsSettings
// Size: 0xf0 // Inherited bytes: 0x28
struct UGameMapsSettings : UObject {
	// Fields
	struct FString LocalMapOptions; // Offset: 0x28 // Size: 0x10
	struct FSoftObjectPath TransitionMap; // Offset: 0x38 // Size: 0x18
	bool bUseSplitscreen; // Offset: 0x50 // Size: 0x01
	enum class ETwoPlayerSplitScreenType TwoPlayerSplitscreenLayout; // Offset: 0x51 // Size: 0x01
	enum class EThreePlayerSplitScreenType ThreePlayerSplitscreenLayout; // Offset: 0x52 // Size: 0x01
	enum class EFourPlayerSplitScreenType FourPlayerSplitscreenLayout; // Offset: 0x53 // Size: 0x01
	bool bOffsetPlayerGamepadIds; // Offset: 0x54 // Size: 0x01
	char pad_0x55[0x3]; // Offset: 0x55 // Size: 0x03
	struct FSoftClassPath GameInstanceClass; // Offset: 0x58 // Size: 0x18
	struct FSoftObjectPath GameDefaultMap; // Offset: 0x70 // Size: 0x18
	struct FSoftObjectPath ServerDefaultMap; // Offset: 0x88 // Size: 0x18
	struct FSoftClassPath GlobalDefaultGameMode; // Offset: 0xa0 // Size: 0x18
	struct FSoftClassPath GlobalDefaultServerGameMode; // Offset: 0xb8 // Size: 0x18
	struct TArray<struct FGameModeName> GameModeMapPrefixes; // Offset: 0xd0 // Size: 0x10
	struct TArray<struct FGameModeName> GameModeClassAliases; // Offset: 0xe0 // Size: 0x10

	// Functions

	// Object Name: Function EngineSettings.GameMapsSettings.SetSkipAssigningGamepadToPlayer1
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSkipAssigningGamepadToPlayer1(bool bSkipFirstPlayer); // Offset: 0x103da9b9c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function EngineSettings.GameMapsSettings.GetSkipAssigningGamepadToPlayer1
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool GetSkipAssigningGamepadToPlayer1(); // Offset: 0x103da9b68 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function EngineSettings.GameMapsSettings.GetGameMapsSettings
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct UGameMapsSettings* GetGameMapsSettings(); // Offset: 0x103da9c24 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class EngineSettings.GameNetworkManagerSettings
// Size: 0x58 // Inherited bytes: 0x28
struct UGameNetworkManagerSettings : UObject {
	// Fields
	int32_t MinDynamicBandwidth; // Offset: 0x28 // Size: 0x04
	int32_t MaxDynamicBandwidth; // Offset: 0x2c // Size: 0x04
	int32_t TotalNetBandwidth; // Offset: 0x30 // Size: 0x04
	int32_t BadPingThreshold; // Offset: 0x34 // Size: 0x04
	char bIsStandbyCheckingEnabled : 1; // Offset: 0x38 // Size: 0x01
	char pad_0x38_1 : 7; // Offset: 0x38 // Size: 0x01
	char pad_0x39[0x3]; // Offset: 0x39 // Size: 0x03
	float StandbyRxCheatTime; // Offset: 0x3c // Size: 0x04
	float StandbyTxCheatTime; // Offset: 0x40 // Size: 0x04
	float PercentMissingForRxStandby; // Offset: 0x44 // Size: 0x04
	float PercentMissingForTxStandby; // Offset: 0x48 // Size: 0x04
	float PercentForBadPing; // Offset: 0x4c // Size: 0x04
	float JoinInProgressStandbyWaitTime; // Offset: 0x50 // Size: 0x04
	char pad_0x54[0x4]; // Offset: 0x54 // Size: 0x04
};

// Object Name: Class EngineSettings.GameSessionSettings
// Size: 0x38 // Inherited bytes: 0x28
struct UGameSessionSettings : UObject {
	// Fields
	int32_t MaxSpectators; // Offset: 0x28 // Size: 0x04
	int32_t MaxPlayers; // Offset: 0x2c // Size: 0x04
	char bRequiresPushToTalk : 1; // Offset: 0x30 // Size: 0x01
	char pad_0x30_1 : 7; // Offset: 0x30 // Size: 0x01
	char pad_0x31[0x7]; // Offset: 0x31 // Size: 0x07
};

// Object Name: Class EngineSettings.HudSettings
// Size: 0x40 // Inherited bytes: 0x28
struct UHudSettings : UObject {
	// Fields
	char bShowHUD : 1; // Offset: 0x28 // Size: 0x01
	char pad_0x28_1 : 7; // Offset: 0x28 // Size: 0x01
	char pad_0x29[0x7]; // Offset: 0x29 // Size: 0x07
	struct TArray<struct FName> DebugDisplay; // Offset: 0x30 // Size: 0x10
};

// Object Name: Class EngineSettings.GeneralEngineSettings
// Size: 0x28 // Inherited bytes: 0x28
struct UGeneralEngineSettings : UObject {
};

