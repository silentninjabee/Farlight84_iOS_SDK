#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass GE_VehicleWeaponFire.GE_VehicleWeaponFire_C
// Size: 0x848 // Inherited bytes: 0x848
struct UGE_VehicleWeaponFire_C : UGameplayEffect {
};

