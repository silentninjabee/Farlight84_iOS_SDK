#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct GeometryCollectionTracks.MovieSceneGeometryCollectionParams
// Size: 0x30 // Inherited bytes: 0x00
struct FMovieSceneGeometryCollectionParams {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
	struct FSoftObjectPath GeometryCollectionCache; // Offset: 0x08 // Size: 0x18
	struct FFrameNumber StartFrameOffset; // Offset: 0x20 // Size: 0x04
	struct FFrameNumber EndFrameOffset; // Offset: 0x24 // Size: 0x04
	float PlayRate; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
};

// Object Name: ScriptStruct GeometryCollectionTracks.MovieSceneGeometryCollectionSectionTemplate
// Size: 0x50 // Inherited bytes: 0x18
struct FMovieSceneGeometryCollectionSectionTemplate : FMovieSceneEvalTemplate {
	// Fields
	struct FMovieSceneGeometryCollectionSectionTemplateParameters Params; // Offset: 0x18 // Size: 0x38
};

// Object Name: ScriptStruct GeometryCollectionTracks.MovieSceneGeometryCollectionSectionTemplateParameters
// Size: 0x38 // Inherited bytes: 0x30
struct FMovieSceneGeometryCollectionSectionTemplateParameters : FMovieSceneGeometryCollectionParams {
	// Fields
	struct FFrameNumber SectionStartTime; // Offset: 0x2c // Size: 0x04
	struct FFrameNumber SectionEndTime; // Offset: 0x30 // Size: 0x04
};

