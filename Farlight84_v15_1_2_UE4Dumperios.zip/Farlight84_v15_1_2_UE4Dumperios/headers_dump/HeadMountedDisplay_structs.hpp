#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct HeadMountedDisplay.XRDeviceId
// Size: 0x0c // Inherited bytes: 0x00
struct FXRDeviceId {
	// Fields
	struct FName SystemName; // Offset: 0x00 // Size: 0x08
	int32_t DeviceID; // Offset: 0x08 // Size: 0x04
};

