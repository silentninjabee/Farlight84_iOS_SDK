#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct HoudiniEngineRuntime.HoudiniGenericAttribute
// Size: 0x50 // Inherited bytes: 0x00
struct FHoudiniGenericAttribute {
	// Fields
	struct FString AttributeName; // Offset: 0x00 // Size: 0x10
	enum class EAttribStorageType AttributeType; // Offset: 0x10 // Size: 0x01
	enum class EAttribOwner AttributeOwner; // Offset: 0x11 // Size: 0x01
	char pad_0x12[0x2]; // Offset: 0x12 // Size: 0x02
	int32_t AttributeCount; // Offset: 0x14 // Size: 0x04
	int32_t AttributeTupleSize; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
	struct TArray<double> DoubleValues; // Offset: 0x20 // Size: 0x10
	struct TArray<int64_t> IntValues; // Offset: 0x30 // Size: 0x10
	struct TArray<struct FString> StringValues; // Offset: 0x40 // Size: 0x10
};

// Object Name: ScriptStruct HoudiniEngineRuntime.HoudiniGenericAttributeChangedProperty
// Size: 0x98 // Inherited bytes: 0x00
struct FHoudiniGenericAttributeChangedProperty {
	// Fields
	struct UObject* Object; // Offset: 0x00 // Size: 0x08
	char pad_0x8[0x90]; // Offset: 0x08 // Size: 0x90
};

// Object Name: ScriptStruct HoudiniEngineRuntime.HoudiniPDGWorkResultObjectBakedOutput
// Size: 0x10 // Inherited bytes: 0x00
struct FHoudiniPDGWorkResultObjectBakedOutput {
	// Fields
	struct TArray<struct FHoudiniBakedOutput> BakedOutputs; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct HoudiniEngineRuntime.HoudiniBakedOutput
// Size: 0x50 // Inherited bytes: 0x00
struct FHoudiniBakedOutput {
	// Fields
	struct TMap<struct FHoudiniBakedOutputObjectIdentifier, struct FHoudiniBakedOutputObject> BakedOutputObjects; // Offset: 0x00 // Size: 0x50
};

// Object Name: ScriptStruct HoudiniEngineRuntime.HoudiniBakedOutputObjectIdentifier
// Size: 0x18 // Inherited bytes: 0x00
struct FHoudiniBakedOutputObjectIdentifier {
	// Fields
	int32_t PartID; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString SplitIdentifier; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct HoudiniEngineRuntime.HoudiniBakedOutputObject
// Size: 0xb8 // Inherited bytes: 0x00
struct FHoudiniBakedOutputObject {
	// Fields
	struct FString Actor; // Offset: 0x00 // Size: 0x10
	struct FString Blueprint; // Offset: 0x10 // Size: 0x10
	struct FName ActorBakeName; // Offset: 0x20 // Size: 0x08
	struct FString BakedObject; // Offset: 0x28 // Size: 0x10
	struct FString BakedComponent; // Offset: 0x38 // Size: 0x10
	struct TArray<struct FString> InstancedActors; // Offset: 0x48 // Size: 0x10
	struct TArray<struct FString> InstancedComponents; // Offset: 0x58 // Size: 0x10
	struct TMap<struct FName, struct FString> LandscapeLayers; // Offset: 0x68 // Size: 0x50
};

// Object Name: ScriptStruct HoudiniEngineRuntime.WorkItemTallyBase
// Size: 0x08 // Inherited bytes: 0x00
struct FWorkItemTallyBase {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct HoudiniEngineRuntime.AggregatedWorkItemTally
// Size: 0x28 // Inherited bytes: 0x08
struct FAggregatedWorkItemTally : FWorkItemTallyBase {
	// Fields
	int32_t TotalWorkItems; // Offset: 0x08 // Size: 0x04
	int32_t WaitingWorkItems; // Offset: 0x0c // Size: 0x04
	int32_t ScheduledWorkItems; // Offset: 0x10 // Size: 0x04
	int32_t CookingWorkItems; // Offset: 0x14 // Size: 0x04
	int32_t CookedWorkItems; // Offset: 0x18 // Size: 0x04
	int32_t ErroredWorkItems; // Offset: 0x1c // Size: 0x04
	int32_t CookCancelledWorkItems; // Offset: 0x20 // Size: 0x04
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
};

// Object Name: ScriptStruct HoudiniEngineRuntime.WorkItemTally
// Size: 0x238 // Inherited bytes: 0x08
struct FWorkItemTally : FWorkItemTallyBase {
	// Fields
	struct TSet<int32_t> AllWorkItems; // Offset: 0x08 // Size: 0x50
	struct TSet<int32_t> WaitingWorkItems; // Offset: 0x58 // Size: 0x50
	struct TSet<int32_t> ScheduledWorkItems; // Offset: 0xa8 // Size: 0x50
	struct TSet<int32_t> CookingWorkItems; // Offset: 0xf8 // Size: 0x50
	struct TSet<int32_t> CookedWorkItems; // Offset: 0x148 // Size: 0x50
	struct TSet<int32_t> ErroredWorkItems; // Offset: 0x198 // Size: 0x50
	struct TSet<int32_t> CookCancelledWorkItems; // Offset: 0x1e8 // Size: 0x50
};

// Object Name: ScriptStruct HoudiniEngineRuntime.TOPWorkResult
// Size: 0x18 // Inherited bytes: 0x00
struct FTOPWorkResult {
	// Fields
	int32_t WorkItemIndex; // Offset: 0x00 // Size: 0x04
	int32_t WorkItemID; // Offset: 0x04 // Size: 0x04
	struct TArray<struct FTOPWorkResultObject> ResultObjects; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct HoudiniEngineRuntime.TOPWorkResultObject
// Size: 0x58 // Inherited bytes: 0x00
struct FTOPWorkResultObject {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
	struct FString Name; // Offset: 0x08 // Size: 0x10
	struct FString FilePath; // Offset: 0x18 // Size: 0x10
	enum class EPDGWorkResultState State; // Offset: 0x28 // Size: 0x01
	char pad_0x29[0x3]; // Offset: 0x29 // Size: 0x03
	int32_t WorkItemResultInfoIndex; // Offset: 0x2c // Size: 0x04
	struct TArray<struct UHoudiniOutput*> ResultOutputs; // Offset: 0x30 // Size: 0x10
	bool bAutoBakedSinceLastLoad; // Offset: 0x40 // Size: 0x01
	char pad_0x41[0x7]; // Offset: 0x41 // Size: 0x07
	struct FOutputActorOwner OutputActorOwner; // Offset: 0x48 // Size: 0x10
};

// Object Name: ScriptStruct HoudiniEngineRuntime.OutputActorOwner
// Size: 0x10 // Inherited bytes: 0x00
struct FOutputActorOwner {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
	struct AActor* OutputActor; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct HoudiniEngineRuntime.HoudiniSplineComponentInstanceData
// Size: 0x88 // Inherited bytes: 0x58
struct FHoudiniSplineComponentInstanceData : FActorComponentInstanceData {
	// Fields
	struct TArray<struct FTransform> CurvePoints; // Offset: 0x58 // Size: 0x10
	struct TArray<struct FVector> DisplayPoints; // Offset: 0x68 // Size: 0x10
	struct TArray<int32_t> DisplayPointIndexDivider; // Offset: 0x78 // Size: 0x10
};

// Object Name: ScriptStruct HoudiniEngineRuntime.HoudiniOutputObject
// Size: 0xf8 // Inherited bytes: 0x00
struct FHoudiniOutputObject {
	// Fields
	struct UObject* OutputObject; // Offset: 0x00 // Size: 0x08
	struct UObject* OutputComponent; // Offset: 0x08 // Size: 0x08
	struct UObject* ProxyObject; // Offset: 0x10 // Size: 0x08
	struct UObject* ProxyComponent; // Offset: 0x18 // Size: 0x08
	bool bProxyIsCurrent; // Offset: 0x20 // Size: 0x01
	bool bIsImplicit; // Offset: 0x21 // Size: 0x01
	bool bIsGeometryCollectionPiece; // Offset: 0x22 // Size: 0x01
	char pad_0x23[0x5]; // Offset: 0x23 // Size: 0x05
	struct FString GeometryCollectionPieceName; // Offset: 0x28 // Size: 0x10
	struct FString BakeName; // Offset: 0x38 // Size: 0x10
	struct FHoudiniCurveOutputProperties CurveOutputProperty; // Offset: 0x48 // Size: 0x0c
	char pad_0x54[0x4]; // Offset: 0x54 // Size: 0x04
	struct TMap<struct FString, struct FString> CachedAttributes; // Offset: 0x58 // Size: 0x50
	struct TMap<struct FString, struct FString> CachedTokens; // Offset: 0xa8 // Size: 0x50
};

// Object Name: ScriptStruct HoudiniEngineRuntime.HoudiniCurveOutputProperties
// Size: 0x0c // Inherited bytes: 0x00
struct FHoudiniCurveOutputProperties {
	// Fields
	enum class EHoudiniCurveOutputType CurveOutputType; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	int32_t NumPoints; // Offset: 0x04 // Size: 0x04
	bool bClosed; // Offset: 0x08 // Size: 0x01
	enum class EHoudiniCurveType CurveType; // Offset: 0x09 // Size: 0x01
	enum class EHoudiniCurveMethod CurveMethod; // Offset: 0x0a // Size: 0x01
	char pad_0xB[0x1]; // Offset: 0x0b // Size: 0x01
};

// Object Name: ScriptStruct HoudiniEngineRuntime.HoudiniInstancedOutput
// Size: 0x88 // Inherited bytes: 0x00
struct FHoudiniInstancedOutput {
	// Fields
	struct TSoftObjectPtr<UObject> OriginalObject; // Offset: 0x00 // Size: 0x28
	int32_t OriginalObjectIndex; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
	struct TArray<struct FTransform> OriginalTransforms; // Offset: 0x30 // Size: 0x10
	struct TArray<struct TSoftObjectPtr<UObject>> VariationObjects; // Offset: 0x40 // Size: 0x10
	struct TArray<struct FTransform> VariationTransformOffsets; // Offset: 0x50 // Size: 0x10
	struct TArray<int32_t> TransformVariationIndices; // Offset: 0x60 // Size: 0x10
	struct TArray<int32_t> OriginalInstanceIndices; // Offset: 0x70 // Size: 0x10
	bool bChanged; // Offset: 0x80 // Size: 0x01
	bool bStale; // Offset: 0x81 // Size: 0x01
	char pad_0x82[0x6]; // Offset: 0x82 // Size: 0x06
};

// Object Name: ScriptStruct HoudiniEngineRuntime.HoudiniOutputObjectIdentifier
// Size: 0x40 // Inherited bytes: 0x00
struct FHoudiniOutputObjectIdentifier {
	// Fields
	int32_t ObjectId; // Offset: 0x00 // Size: 0x04
	int32_t GeoId; // Offset: 0x04 // Size: 0x04
	int32_t PartID; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct FString SplitIdentifier; // Offset: 0x10 // Size: 0x10
	struct FString PartName; // Offset: 0x20 // Size: 0x10
	int32_t PrimitiveIndex; // Offset: 0x30 // Size: 0x04
	int32_t PointIndex; // Offset: 0x34 // Size: 0x04
	char pad_0x38[0x8]; // Offset: 0x38 // Size: 0x08
};

// Object Name: ScriptStruct HoudiniEngineRuntime.HoudiniAssetBlueprintInstanceData
// Size: 0x110 // Inherited bytes: 0x58
struct FHoudiniAssetBlueprintInstanceData : FActorComponentInstanceData {
	// Fields
	struct UHoudiniAsset* HoudiniAsset; // Offset: 0x58 // Size: 0x08
	int32_t AssetId; // Offset: 0x60 // Size: 0x04
	enum class EHoudiniAssetState AssetState; // Offset: 0x64 // Size: 0x01
	char pad_0x65[0x3]; // Offset: 0x65 // Size: 0x03
	uint32_t SubAssetIndex; // Offset: 0x68 // Size: 0x04
	uint32_t AssetCookCount; // Offset: 0x6c // Size: 0x04
	bool bHasBeenLoaded; // Offset: 0x70 // Size: 0x01
	bool bHasBeenDuplicated; // Offset: 0x71 // Size: 0x01
	bool bPendingDelete; // Offset: 0x72 // Size: 0x01
	bool bRecookRequested; // Offset: 0x73 // Size: 0x01
	bool bRebuildRequested; // Offset: 0x74 // Size: 0x01
	bool bEnableCooking; // Offset: 0x75 // Size: 0x01
	bool bForceNeedUpdate; // Offset: 0x76 // Size: 0x01
	bool bLastCookSuccess; // Offset: 0x77 // Size: 0x01
	struct FGuid ComponentGUID; // Offset: 0x78 // Size: 0x10
	struct FGuid HapiGUID; // Offset: 0x88 // Size: 0x10
	bool bRegisteredComponentTemplate; // Offset: 0x98 // Size: 0x01
	char pad_0x99[0x7]; // Offset: 0x99 // Size: 0x07
	struct FString SourceName; // Offset: 0xa0 // Size: 0x10
	struct TMap<struct FHoudiniOutputObjectIdentifier, struct FHoudiniAssetBlueprintOutput> Outputs; // Offset: 0xb0 // Size: 0x50
	struct TArray<struct UHoudiniInput*> Inputs; // Offset: 0x100 // Size: 0x10
};

// Object Name: ScriptStruct HoudiniEngineRuntime.HoudiniAssetBlueprintOutput
// Size: 0x100 // Inherited bytes: 0x00
struct FHoudiniAssetBlueprintOutput {
	// Fields
	int32_t OutputIndex; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FHoudiniOutputObject OutputObject; // Offset: 0x08 // Size: 0xf8
};

// Object Name: ScriptStruct HoudiniEngineRuntime.HoudiniGeoPartObject
// Size: 0x230 // Inherited bytes: 0x00
struct FHoudiniGeoPartObject {
	// Fields
	int32_t AssetId; // Offset: 0x00 // Size: 0x04
	char pad_0x4[0x4]; // Offset: 0x04 // Size: 0x04
	struct FString AssetName; // Offset: 0x08 // Size: 0x10
	int32_t ObjectId; // Offset: 0x18 // Size: 0x04
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
	struct FString ObjectName; // Offset: 0x20 // Size: 0x10
	int32_t GeoId; // Offset: 0x30 // Size: 0x04
	int32_t PartID; // Offset: 0x34 // Size: 0x04
	struct FString PartName; // Offset: 0x38 // Size: 0x10
	bool bHasCustomPartName; // Offset: 0x48 // Size: 0x01
	char pad_0x49[0x7]; // Offset: 0x49 // Size: 0x07
	struct TArray<struct FString> SplitGroups; // Offset: 0x50 // Size: 0x10
	struct FTransform TransformMatrix; // Offset: 0x60 // Size: 0x30
	struct FString NodePath; // Offset: 0x90 // Size: 0x10
	enum class EHoudiniPartType Type; // Offset: 0xa0 // Size: 0x01
	enum class EHoudiniInstancerType InstancerType; // Offset: 0xa1 // Size: 0x01
	char pad_0xA2[0x6]; // Offset: 0xa2 // Size: 0x06
	struct FString VolumeName; // Offset: 0xa8 // Size: 0x10
	bool bHasEditLayers; // Offset: 0xb8 // Size: 0x01
	char pad_0xB9[0x7]; // Offset: 0xb9 // Size: 0x07
	struct FString VolumeLayerName; // Offset: 0xc0 // Size: 0x10
	int32_t VolumeTileIndex; // Offset: 0xd0 // Size: 0x04
	bool bIsVisible; // Offset: 0xd4 // Size: 0x01
	bool bIsEditable; // Offset: 0xd5 // Size: 0x01
	bool bIsTemplated; // Offset: 0xd6 // Size: 0x01
	bool bIsInstanced; // Offset: 0xd7 // Size: 0x01
	bool bHasGeoChanged; // Offset: 0xd8 // Size: 0x01
	bool bHasPartChanged; // Offset: 0xd9 // Size: 0x01
	bool bHasTransformChanged; // Offset: 0xda // Size: 0x01
	bool bHasMaterialsChanged; // Offset: 0xdb // Size: 0x01
	char pad_0xDC[0x144]; // Offset: 0xdc // Size: 0x144
	struct TArray<struct FHoudiniMeshSocket> AllMeshSockets; // Offset: 0x220 // Size: 0x10
};

// Object Name: ScriptStruct HoudiniEngineRuntime.HoudiniMeshSocket
// Size: 0x60 // Inherited bytes: 0x00
struct FHoudiniMeshSocket {
	// Fields
	char pad_0x0[0x60]; // Offset: 0x00 // Size: 0x60
};

// Object Name: ScriptStruct HoudiniEngineRuntime.HoudiniCurveInfo
// Size: 0x1c // Inherited bytes: 0x00
struct FHoudiniCurveInfo {
	// Fields
	char pad_0x0[0x1c]; // Offset: 0x00 // Size: 0x1c
};

// Object Name: ScriptStruct HoudiniEngineRuntime.HoudiniVolumeInfo
// Size: 0x80 // Inherited bytes: 0x00
struct FHoudiniVolumeInfo {
	// Fields
	char pad_0x0[0x80]; // Offset: 0x00 // Size: 0x80
};

// Object Name: ScriptStruct HoudiniEngineRuntime.HoudiniPartInfo
// Size: 0x48 // Inherited bytes: 0x00
struct FHoudiniPartInfo {
	// Fields
	char pad_0x0[0x48]; // Offset: 0x00 // Size: 0x48
};

// Object Name: ScriptStruct HoudiniEngineRuntime.HoudiniGeoInfo
// Size: 0x30 // Inherited bytes: 0x00
struct FHoudiniGeoInfo {
	// Fields
	char pad_0x0[0x30]; // Offset: 0x00 // Size: 0x30
};

// Object Name: ScriptStruct HoudiniEngineRuntime.HoudiniObjectInfo
// Size: 0x28 // Inherited bytes: 0x00
struct FHoudiniObjectInfo {
	// Fields
	char pad_0x0[0x28]; // Offset: 0x00 // Size: 0x28
};

// Object Name: ScriptStruct HoudiniEngineRuntime.HoudiniStaticMeshGenerationProperties
// Size: 0x180 // Inherited bytes: 0x00
struct FHoudiniStaticMeshGenerationProperties {
	// Fields
	char bGeneratedDoubleSidedGeometry : 1; // Offset: 0x00 // Size: 0x01
	char pad_0x0_1 : 7; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct UPhysicalMaterial* GeneratedPhysMaterial; // Offset: 0x08 // Size: 0x08
	struct FBodyInstance DefaultBodyInstance; // Offset: 0x10 // Size: 0x130
	enum class ECollisionTraceFlag GeneratedCollisionTraceFlag; // Offset: 0x140 // Size: 0x01
	char pad_0x141[0x3]; // Offset: 0x141 // Size: 0x03
	int32_t GeneratedLightMapResolution; // Offset: 0x144 // Size: 0x04
	struct FWalkableSlopeOverride GeneratedWalkableSlopeOverride; // Offset: 0x148 // Size: 0x10
	int32_t GeneratedLightMapCoordinateIndex; // Offset: 0x158 // Size: 0x04
	char bGeneratedUseMaximumStreamingTexelRatio : 1; // Offset: 0x15c // Size: 0x01
	char pad_0x15C_1 : 7; // Offset: 0x15c // Size: 0x01
	char pad_0x15D[0x3]; // Offset: 0x15d // Size: 0x03
	float GeneratedStreamingDistanceMultiplier; // Offset: 0x160 // Size: 0x04
	char pad_0x164[0x4]; // Offset: 0x164 // Size: 0x04
	struct UFoliageType_InstancedStaticMesh* GeneratedFoliageDefaultSettings; // Offset: 0x168 // Size: 0x08
	struct TArray<struct UAssetUserData*> GeneratedAssetUserData; // Offset: 0x170 // Size: 0x10
};

// Object Name: ScriptStruct HoudiniEngineRuntime.HoudiniBrushInfo
// Size: 0x70 // Inherited bytes: 0x00
struct FHoudiniBrushInfo {
	// Fields
	struct TWeakObjectPtr<struct ABrush> BrushActor; // Offset: 0x00 // Size: 0x08
	char pad_0x8[0x8]; // Offset: 0x08 // Size: 0x08
	struct FTransform CachedTransform; // Offset: 0x10 // Size: 0x30
	struct FVector CachedOrigin; // Offset: 0x40 // Size: 0x0c
	struct FVector CachedExtent; // Offset: 0x4c // Size: 0x0c
	enum class EBrushType CachedBrushType; // Offset: 0x58 // Size: 0x01
	char pad_0x59[0x7]; // Offset: 0x59 // Size: 0x07
	uint64_t CachedSurfaceHash; // Offset: 0x60 // Size: 0x08
	char pad_0x68[0x8]; // Offset: 0x68 // Size: 0x08
};

// Object Name: ScriptStruct HoudiniEngineRuntime.HoudiniInputLandscapeTransferParams
// Size: 0xc8 // Inherited bytes: 0x00
struct FHoudiniInputLandscapeTransferParams {
	// Fields
	enum class ETransferHeightMode TransferHeightMode; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x7]; // Offset: 0x01 // Size: 0x07
	struct TSet<struct FName> HeightSpecifiedLayerNames; // Offset: 0x08 // Size: 0x50
	struct FName HeightUnderSpecifiedLayerName; // Offset: 0x58 // Size: 0x08
	enum class ETransferLayerMode TransferLayerMode; // Offset: 0x60 // Size: 0x01
	char pad_0x61[0x7]; // Offset: 0x61 // Size: 0x07
	struct TSet<struct FName> LayerSpecifiedLayerNames; // Offset: 0x68 // Size: 0x50
	struct FName LayerUnderSpecifiedLayerName; // Offset: 0xb8 // Size: 0x08
	bool bTransferWeightmap; // Offset: 0xc0 // Size: 0x01
	char pad_0xC1[0x7]; // Offset: 0xc1 // Size: 0x07
};

