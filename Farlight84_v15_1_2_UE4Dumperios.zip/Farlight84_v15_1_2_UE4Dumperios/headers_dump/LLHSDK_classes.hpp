#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class LLHSDK.LLHSDKAppUtils
// Size: 0x38 // Inherited bytes: 0x28
struct ULLHSDKAppUtils : UObject {
	// Fields
	struct FMulticastInlineDelegate OnSteamUserStatesUpdate; // Offset: 0x28 // Size: 0x10

	// Functions

	// Object Name: Function LLHSDK.LLHSDKAppUtils.ShowSteamVirtualKeyboard
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool ShowSteamVirtualKeyboard(); // Offset: 0x101439c50 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LLHSDK.LLHSDKAppUtils.SDKConfigIsMultiDetect
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool SDKConfigIsMultiDetect(); // Offset: 0x10143a404 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LLHSDK.LLHSDKAppUtils.SDKConfigIsDebug
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool SDKConfigIsDebug(); // Offset: 0x10143a438 // Return & Params: Num(1) Size(0x1)

	// Object Name: DelegateFunction LLHSDK.LLHSDKAppUtils.OnSteamUserStatesUpdate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnSteamUserStatesUpdate__DelegateSignature(struct FString SteamId, bool IsFriend, bool Online, struct FString FriendName); // Offset: 0x103938968 // Return & Params: Num(4) Size(0x28)

	// Object Name: Function LLHSDK.LLHSDKAppUtils.IsSteamFriendOnline
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsSteamFriendOnline(struct FString SteamId); // Offset: 0x101439e40 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function LLHSDK.LLHSDKAppUtils.IsSimulator
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsSimulator(); // Offset: 0x10143a1ac // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LLHSDK.LLHSDKAppUtils.IsPlatformSteamDeck
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsPlatformSteamDeck(); // Offset: 0x101439c84 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LLHSDK.LLHSDKAppUtils.IsPackageInstalled
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsPackageInstalled(struct FString InPackageName); // Offset: 0x10143a294 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function LLHSDK.LLHSDKAppUtils.IsGrayRelease
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsGrayRelease(); // Offset: 0x10143a178 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LLHSDK.LLHSDKAppUtils.InviteSteamUserToGame
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool InviteSteamUserToGame(struct FString SteamId); // Offset: 0x10143a084 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function LLHSDK.LLHSDKAppUtils.GetVersionName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetVersionName(); // Offset: 0x10143a7ec // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKAppUtils.GetVersionCode
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetVersionCode(); // Offset: 0x10143a86c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKAppUtils.GetSteamFriendsOnlineList
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct TArray<bool> GetSteamFriendsOnlineList(); // Offset: 0x101439ccc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKAppUtils.GetSteamFriendsNameList
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct TArray<struct FString> GetSteamFriendsNameList(); // Offset: 0x101439d4c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKAppUtils.GetSteamFriendName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetSteamFriendName(struct FString SteamId); // Offset: 0x101439ecc // Return & Params: Num(2) Size(0x20)

	// Object Name: Function LLHSDK.LLHSDKAppUtils.GetSteamFriendIDList
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct TArray<struct FString> GetSteamFriendIDList(); // Offset: 0x101439f90 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKAppUtils.GetSteamFriendCount
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int32_t GetSteamFriendCount(); // Offset: 0x10143a110 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LLHSDK.LLHSDKAppUtils.GetSDKVersionName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetSDKVersionName(); // Offset: 0x10143a6ec // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKAppUtils.GetSDKVersionCode
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetSDKVersionCode(); // Offset: 0x10143a76c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKAppUtils.GetRunningProcessName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetRunningProcessName(); // Offset: 0x10143a214 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKAppUtils.GetOperatingSystemId
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetOperatingSystemId(); // Offset: 0x10143a96c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKAppUtils.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct ULLHSDKAppUtils* GetInstance(); // Offset: 0x10143aa80 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function LLHSDK.LLHSDKAppUtils.GetGameTime
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int64_t GetGameTime(); // Offset: 0x10143a1e0 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function LLHSDK.LLHSDKAppUtils.GetGameID
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetGameID(); // Offset: 0x10143a46c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKAppUtils.GetEnvId
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetEnvId(); // Offset: 0x10143a384 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKAppUtils.GetDeviceUUID
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetDeviceUUID(); // Offset: 0x10143a9ec // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKAppUtils.GetChannelID
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetChannelID(); // Offset: 0x10143a4ec // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKAppUtils.GetBiosUUID
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetBiosUUID(); // Offset: 0x10143a8ec // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKAppUtils.GetAppName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetAppName(); // Offset: 0x10143a56c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKAppUtils.GetAppIDRaw
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetAppIDRaw(); // Offset: 0x10143a5ec // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKAppUtils.GetAppID
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetAppID(); // Offset: 0x10143a66c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKAppUtils.DoesDistributeForDomestic
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool DoesDistributeForDomestic(); // Offset: 0x10143a144 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LLHSDK.LLHSDKAppUtils.DismissSteamVirtualKeyboard
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void DismissSteamVirtualKeyboard(); // Offset: 0x101439c3c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LLHSDK.LLHSDKAppUtils.DestoryInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void DestoryInstance(); // Offset: 0x10143aa6c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LLHSDK.LLHSDKAppUtils.BindOnlineSubsystemSteamPresence
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void BindOnlineSubsystemSteamPresence(); // Offset: 0x101439cb8 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class LLHSDK.LLHSDKCommunity
// Size: 0x78 // Inherited bytes: 0x28
struct ULLHSDKCommunity : UObject {
	// Fields
	struct FMulticastInlineDelegate OnInitCommunity; // Offset: 0x28 // Size: 0x10
	struct FMulticastInlineDelegate OnExitCommunity; // Offset: 0x38 // Size: 0x10
	struct FMulticastInlineDelegate OnGetCommunityRedhint; // Offset: 0x48 // Size: 0x10
	struct FMulticastInlineDelegate OnClearCommunityRedhint; // Offset: 0x58 // Size: 0x10
	struct FMulticastInlineDelegate OnImageDownload; // Offset: 0x68 // Size: 0x10

	// Functions

	// Object Name: DelegateFunction LLHSDK.LLHSDKCommunity.OnInitCommunity__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnInitCommunity__DelegateSignature(struct FString ResultStr); // Offset: 0x103938968 // Return & Params: Num(1) Size(0x10)

	// Object Name: DelegateFunction LLHSDK.LLHSDKCommunity.OnImageDownload__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnImageDownload__DelegateSignature(bool bSuccess); // Offset: 0x103938968 // Return & Params: Num(1) Size(0x1)

	// Object Name: DelegateFunction LLHSDK.LLHSDKCommunity.OnGetCommunityRedhint__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnGetCommunityRedhint__DelegateSignature(struct FString ResultStr); // Offset: 0x103938968 // Return & Params: Num(1) Size(0x10)

	// Object Name: DelegateFunction LLHSDK.LLHSDKCommunity.OnExitCommunity__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnExitCommunity__DelegateSignature(struct FString ResultStr); // Offset: 0x103938968 // Return & Params: Num(1) Size(0x10)

	// Object Name: DelegateFunction LLHSDK.LLHSDKCommunity.OnClearCommunityRedhint__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnClearCommunityRedhint__DelegateSignature(struct FString ResultStr); // Offset: 0x103938968 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKCommunity.InitCommunityConfig
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void InitCommunityConfig(struct FString UrlInfo, struct FString ReqMethod, struct FString ExtraHttpParams); // Offset: 0x10143bf84 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function LLHSDK.LLHSDKCommunity.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct ULLHSDKCommunity* GetInstance(); // Offset: 0x10143c0cc // Return & Params: Num(1) Size(0x8)

	// Object Name: Function LLHSDK.LLHSDKCommunity.GetCommunityRedHint
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void GetCommunityRedHint(struct FString URL, struct FString ReqMethod, struct FString ExtraHttpParams); // Offset: 0x10143bd1c // Return & Params: Num(3) Size(0x30)

	// Object Name: Function LLHSDK.LLHSDKCommunity.ExitCommunity
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void ExitCommunity(struct FString URL, struct FString ReqMethod, struct FString ExtraHttpParams); // Offset: 0x10143be50 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function LLHSDK.LLHSDKCommunity.DownloadImage
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void DownloadImage(struct FString URL, struct FString FilePath); // Offset: 0x10143bb0c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function LLHSDK.LLHSDKCommunity.DestoryInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void DestoryInstance(); // Offset: 0x10143c0b8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LLHSDK.LLHSDKCommunity.ClearCommunityRedHint
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void ClearCommunityRedHint(struct FString URL, struct FString ReqMethod, struct FString ExtraHttpParams); // Offset: 0x10143bbe8 // Return & Params: Num(3) Size(0x30)
};

// Object Name: Class LLHSDK.LLHSDKCustomerService
// Size: 0x40 // Inherited bytes: 0x28
struct ULLHSDKCustomerService : UObject {
	// Fields
	struct FMulticastInlineDelegate OnReceiveNotification; // Offset: 0x28 // Size: 0x10
	char pad_0x38[0x8]; // Offset: 0x38 // Size: 0x08

	// Functions

	// Object Name: Function LLHSDK.LLHSDKCustomerService.ShowCustomerServicePage
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void ShowCustomerServicePage(struct FString ExtInfoStr); // Offset: 0x10143c794 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKCustomerService.SetCustomerServiceDebug
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void SetCustomerServiceDebug(bool& bIsPspDebug, struct FString PlayerId, int64_t ServerId); // Offset: 0x10143c674 // Return & Params: Num(3) Size(0x20)

	// Object Name: DelegateFunction LLHSDK.LLHSDKCustomerService.OnReceiveNotification__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnReceiveNotification__DelegateSignature(int32_t NotificationType); // Offset: 0x103938968 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LLHSDK.LLHSDKCustomerService.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct ULLHSDKCustomerService* GetInstance(); // Offset: 0x10143c82c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function LLHSDK.LLHSDKCustomerService.DestoryInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void DestoryInstance(); // Offset: 0x10143c818 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class LLHSDK.LLHSDKDeviceUtils
// Size: 0x48 // Inherited bytes: 0x28
struct ULLHSDKDeviceUtils : UObject {
	// Fields
	struct FMulticastInlineDelegate OnGoogleAdID; // Offset: 0x28 // Size: 0x10
	struct FMulticastInlineDelegate OnDeviceScore; // Offset: 0x38 // Size: 0x10

	// Functions

	// Object Name: DelegateFunction LLHSDK.LLHSDKDeviceUtils.OnGoogleAdID__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnGoogleAdID__DelegateSignature(struct FString GoogleAdID); // Offset: 0x103938968 // Return & Params: Num(1) Size(0x10)

	// Object Name: DelegateFunction LLHSDK.LLHSDKDeviceUtils.OnDeviceScore__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnDeviceScore__DelegateSignature(int32_t DeviceScore); // Offset: 0x103938968 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LLHSDK.LLHSDKDeviceUtils.IsEmulator
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsEmulator(); // Offset: 0x1014409c8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LLHSDK.LLHSDKDeviceUtils.GetTotalRAM
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetTotalRAM(); // Offset: 0x1014408c8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKDeviceUtils.GetTotalMemorySize
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetTotalMemorySize(); // Offset: 0x1014409fc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKDeviceUtils.GetTimezoneName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetTimezoneName(); // Offset: 0x101440b7c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKDeviceUtils.GetOSVersion
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetOSVersion(); // Offset: 0x101440bfc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKDeviceUtils.GetNetworkTypeEnum
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	enum class ELLHSDKNetworkType GetNetworkTypeEnum(); // Offset: 0x101440e7c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LLHSDK.LLHSDKDeviceUtils.GetNetworkType
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetNetworkType(); // Offset: 0x101440eb0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKDeviceUtils.GetMacAddress
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetMacAddress(); // Offset: 0x101440f30 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKDeviceUtils.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct ULLHSDKDeviceUtils* GetInstance(); // Offset: 0x1014411d8 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function LLHSDK.LLHSDKDeviceUtils.GetIMSI
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetIMSI(); // Offset: 0x101440dfc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKDeviceUtils.GetIDFA
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetIDFA(); // Offset: 0x101441044 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKDeviceUtils.GetGoogleAdID
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void GetGoogleAdID(); // Offset: 0x101441030 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LLHSDK.LLHSDKDeviceUtils.GetDisplayMetrics
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct TArray<float> GetDisplayMetrics(); // Offset: 0x101440734 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKDeviceUtils.GetDisplayCutout
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct TArray<float> GetDisplayCutout(); // Offset: 0x1014407b4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKDeviceUtils.GetDeviceType
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetDeviceType(); // Offset: 0x101440d7c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKDeviceUtils.GetDeviceScore
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void GetDeviceScore(); // Offset: 0x101440834 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LLHSDK.LLHSDKDeviceUtils.GetDeviceModel
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetDeviceModel(); // Offset: 0x101440c7c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKDeviceUtils.GetDeviceID
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetDeviceID(); // Offset: 0x101441144 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKDeviceUtils.GetDeviceCarrier
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetDeviceCarrier(); // Offset: 0x101440fb0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKDeviceUtils.GetDeviceBrand
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetDeviceBrand(); // Offset: 0x101440cfc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKDeviceUtils.GetDeviceAbi
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetDeviceAbi(); // Offset: 0x101440948 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKDeviceUtils.GetCPUModel
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetCPUModel(); // Offset: 0x101440afc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKDeviceUtils.GetCPUHardWareName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetCPUHardWareName(); // Offset: 0x101440a7c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKDeviceUtils.GetAvailableRAM
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetAvailableRAM(); // Offset: 0x101440848 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKDeviceUtils.GetAndroidID
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetAndroidID(); // Offset: 0x1014410c4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKDeviceUtils.DestoryInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void DestoryInstance(); // Offset: 0x1014411c4 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class LLHSDK.LLHSDKLocalization
// Size: 0x28 // Inherited bytes: 0x28
struct ULLHSDKLocalization : UObject {
	// Functions

	// Object Name: Function LLHSDK.LLHSDKLocalization.SetLocaleName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetLocaleName(struct FString InLocale); // Offset: 0x101441e30 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKLocalization.SetLocale
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetLocale(enum class ELLHSDKSupportedLanguage InLocale); // Offset: 0x101441f0c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LLHSDK.LLHSDKLocalization.GetLocaleName
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetLocaleName(); // Offset: 0x101441cd8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKLocalization.GetLocaleInfo
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FLLHSDKLocaleInfo GetLocaleInfo(); // Offset: 0x101441d58 // Return & Params: Num(1) Size(0x20)

	// Object Name: Function LLHSDK.LLHSDKLocalization.GetLocaleEnum
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	enum class ELLHSDKSupportedLanguage GetLocaleEnum(); // Offset: 0x101441dfc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LLHSDK.LLHSDKLocalization.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct ULLHSDKLocalization* GetInstance(); // Offset: 0x101441f98 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function LLHSDK.LLHSDKLocalization.DestoryInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void DestoryInstance(); // Offset: 0x101441f84 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class LLHSDK.LLHSDKLogin
// Size: 0x1f8 // Inherited bytes: 0x28
struct ULLHSDKLogin : UObject {
	// Fields
	struct FMulticastInlineDelegate OnInitFinish; // Offset: 0x28 // Size: 0x10
	struct FMulticastInlineDelegate OnLoginFinish; // Offset: 0x38 // Size: 0x10
	struct FMulticastInlineDelegate OnLoginFailed; // Offset: 0x48 // Size: 0x10
	struct FMulticastInlineDelegate OnBindFinish; // Offset: 0x58 // Size: 0x10
	struct FMulticastInlineDelegate OnSwitchAccountFinish; // Offset: 0x68 // Size: 0x10
	struct FMulticastInlineDelegate OnSwitchAccountFailed; // Offset: 0x78 // Size: 0x10
	struct FMulticastInlineDelegate OnProtocolClick; // Offset: 0x88 // Size: 0x10
	struct FMulticastInlineDelegate OnLimSteamSDKInited; // Offset: 0x98 // Size: 0x10
	struct FMulticastInlineDelegate OnSteamAutoLogin; // Offset: 0xa8 // Size: 0x10
	struct FMulticastInlineDelegate OnSteamRegister; // Offset: 0xb8 // Size: 0x10
	struct FMulticastInlineDelegate OnGetSteamRegisterUrl; // Offset: 0xc8 // Size: 0x10
	struct FMulticastInlineDelegate OnGetThirdPartyLoginResult; // Offset: 0xd8 // Size: 0x10
	struct FMulticastInlineDelegate OnSteamBindUrlGet; // Offset: 0xe8 // Size: 0x10
	struct FMulticastInlineDelegate OnSteamLoginResultSet; // Offset: 0xf8 // Size: 0x10
	struct FMulticastInlineDelegate OnSteamGetAccountInfo; // Offset: 0x108 // Size: 0x10
	struct FMulticastInlineDelegate OnSteamBindFinish; // Offset: 0x118 // Size: 0x10
	struct FMulticastInlineDelegate OnNSSDKInited; // Offset: 0x128 // Size: 0x10
	struct FMulticastInlineDelegate OnNSLoginStart; // Offset: 0x138 // Size: 0x10
	struct FMulticastInlineDelegate OnNSAccountInfoGet; // Offset: 0x148 // Size: 0x10
	struct FMulticastInlineDelegate OnLimPCSDKInited; // Offset: 0x158 // Size: 0x10
	struct FMulticastInlineDelegate OnLimPCSDKEventCallback; // Offset: 0x168 // Size: 0x10
	struct FMulticastInlineDelegate OnLimPCSDKLogin; // Offset: 0x178 // Size: 0x10
	struct FMulticastInlineDelegate OnLimPCSDKLogout; // Offset: 0x188 // Size: 0x10
	struct FMulticastInlineDelegate OnLimPCSDKOpenAccountPage; // Offset: 0x198 // Size: 0x10
	struct FMulticastInlineDelegate OnLimPCSDKOpenSwitchAccountPage; // Offset: 0x1a8 // Size: 0x10
	struct FMulticastInlineDelegate OnLimPCSDKLanguageChange; // Offset: 0x1b8 // Size: 0x10
	struct FMulticastInlineDelegate OnLimPCSDKGetUserInfo; // Offset: 0x1c8 // Size: 0x10
	struct FMulticastInlineDelegate OnLimPCSDKCommonReportPoint; // Offset: 0x1d8 // Size: 0x10
	struct FString LimPCAlilogFields; // Offset: 0x1e8 // Size: 0x10

	// Functions

	// Object Name: Function LLHSDK.LLHSDKLogin.UpdateSteamCallBack
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void UpdateSteamCallBack(); // Offset: 0x101443068 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LLHSDK.LLHSDKLogin.SwitchOrLinkAccount
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SwitchOrLinkAccount(); // Offset: 0x101443b5c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LLHSDK.LLHSDKLogin.SteamRegister
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool SteamRegister(struct FString Params); // Offset: 0x1014433d8 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function LLHSDK.LLHSDKLogin.SteamLoginResultSet
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool SteamLoginResultSet(struct FString Params); // Offset: 0x101443220 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function LLHSDK.LLHSDKLogin.SteamGetAccountInfo
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool SteamGetAccountInfo(struct FString Params); // Offset: 0x101443108 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function LLHSDK.LLHSDKLogin.SteamFree
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SteamFree(); // Offset: 0x1014433c4 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LLHSDK.LLHSDKLogin.SteamBindUrlGet
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool SteamBindUrlGet(struct FString Params); // Offset: 0x101443194 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function LLHSDK.LLHSDKLogin.SteamAutoLogin
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool SteamAutoLogin(struct FString Params); // Offset: 0x101443464 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function LLHSDK.LLHSDKLogin.ShowProtocolViewV2Ok
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void ShowProtocolViewV2Ok(); // Offset: 0x10144357c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LLHSDK.LLHSDKLogin.ShowProtocolViewV2Confirm
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void ShowProtocolViewV2Confirm(); // Offset: 0x101443590 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LLHSDK.LLHSDKLogin.SetLimPCSDKLogHandler
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int32_t SetLimPCSDKLogHandler(); // Offset: 0x101442b8c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LLHSDK.LLHSDKLogin.SetLimPCSDKEventHandler
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int32_t SetLimPCSDKEventHandler(); // Offset: 0x101442b58 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LLHSDK.LLHSDKLogin.SetLimPCAlilogFieldsData
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetLimPCAlilogFieldsData(struct FString LimPCAlilogFieldsStr); // Offset: 0x101442f1c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKLogin.QueryCurrentUserInfo
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FLLHSDKLoginUserInfo QueryCurrentUserInfo(); // Offset: 0x1014436b0 // Return & Params: Num(1) Size(0x140)

	// Object Name: Function LLHSDK.LLHSDKLogin.QueryCurrentUser
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FLLHSDKLoginUser QueryCurrentUser(); // Offset: 0x1014439e8 // Return & Params: Num(1) Size(0x48)

	// Object Name: Function LLHSDK.LLHSDKLogin.OpenSteamBindPage
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool OpenSteamBindPage(struct FString URL); // Offset: 0x1014432ac // Return & Params: Num(2) Size(0x11)

	// Object Name: Function LLHSDK.LLHSDKLogin.OpenLIMPCSwitchAccPage
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int32_t OpenLIMPCSwitchAccPage(); // Offset: 0x1014429c4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LLHSDK.LLHSDKLogin.OpenLIMPCAccountPage
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int32_t OpenLIMPCAccountPage(struct FString Params); // Offset: 0x1014429f8 // Return & Params: Num(2) Size(0x14)

	// Object Name: DelegateFunction LLHSDK.LLHSDKLogin.OnProtocolClick__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnProtocolClick__DelegateSignature(bool bConfirmed); // Offset: 0x103938968 // Return & Params: Num(1) Size(0x1)

	// Object Name: DelegateFunction LLHSDK.LLHSDKLogin.OnLoginFinish__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnLoginFinish__DelegateSignature(struct FString AppUid, struct FString AppToken, enum class ELLHSDKLoginType LoginType); // Offset: 0x103938968 // Return & Params: Num(3) Size(0x21)

	// Object Name: DelegateFunction LLHSDK.LLHSDKLogin.OnLoginFailed__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnLoginFailed__DelegateSignature(enum class ELLHSDKLoginType LoginType, int32_t ErrorCode); // Offset: 0x103938968 // Return & Params: Num(2) Size(0x8)

	// Object Name: DelegateFunction LLHSDK.LLHSDKLogin.OnInitFinish__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnInitFinish__DelegateSignature(); // Offset: 0x103938968 // Return & Params: Num(0) Size(0x0)

	// Object Name: DelegateFunction LLHSDK.LLHSDKLogin.OnBindFinish__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnBindFinish__DelegateSignature(bool bSuccess, struct FString AppUid, struct FString AppToken, enum class ELLHSDKLoginType LoginType); // Offset: 0x103938968 // Return & Params: Num(4) Size(0x29)

	// Object Name: Function LLHSDK.LLHSDKLogin.NSLogout
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void NSLogout(); // Offset: 0x101442cd8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LLHSDK.LLHSDKLogin.NSLoginStart
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool NSLoginStart(struct FString Params); // Offset: 0x101442cec // Return & Params: Num(2) Size(0x11)

	// Object Name: Function LLHSDK.LLHSDKLogin.NSFinalize
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void NSFinalize(); // Offset: 0x101442d78 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LLHSDK.LLHSDKLogin.NSAccountInfoGet
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool NSAccountInfoGet(struct FString Params); // Offset: 0x101442c4c // Return & Params: Num(2) Size(0x11)

	// Object Name: Function LLHSDK.LLHSDKLogin.LogoutLimPCSDK
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int32_t LogoutLimPCSDK(); // Offset: 0x101442a84 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LLHSDK.LLHSDKLogin.Logout
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void Logout(); // Offset: 0x101443b14 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LLHSDK.LLHSDKLogin.LoginUserInfo_ToString
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct FString LoginUserInfo_ToString(struct FLLHSDKLoginUserInfo& InUserInfo); // Offset: 0x1014435d8 // Return & Params: Num(2) Size(0x150)

	// Object Name: Function LLHSDK.LLHSDKLogin.LoginUser_ToString
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct FString LoginUser_ToString(struct FLLHSDKLoginUser& InUser); // Offset: 0x101443894 // Return & Params: Num(2) Size(0x58)

	// Object Name: Function LLHSDK.LLHSDKLogin.LoginLimPCSDK
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int32_t LoginLimPCSDK(struct FString Params); // Offset: 0x101442ab8 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function LLHSDK.LLHSDKLogin.Login
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void Login(); // Offset: 0x101443b70 // Return & Params: Num(0) Size(0x0)

	// Object Name: DelegateFunction LLHSDK.LLHSDKLogin.LimSteamSDKCallBack__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void LimSteamSDKCallBack__DelegateSignature(struct FString Datas); // Offset: 0x103938968 // Return & Params: Num(1) Size(0x10)

	// Object Name: DelegateFunction LLHSDK.LLHSDKLogin.LimPCSDKCallBack__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void LimPCSDKCallBack__DelegateSignature(struct FString Datas); // Offset: 0x103938968 // Return & Params: Num(1) Size(0x10)

	// Object Name: DelegateFunction LLHSDK.LLHSDKLogin.LimOnSteamLoginResultSet__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void LimOnSteamLoginResultSet__DelegateSignature(struct FString AppUid, struct FString AppToken, struct FString AppId); // Offset: 0x103938968 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function LLHSDK.LLHSDKLogin.IsInitFinish
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsInitFinish(); // Offset: 0x101443b28 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LLHSDK.LLHSDKLogin.IsCurrentUserNewReg
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsCurrentUserNewReg(); // Offset: 0x1014435a4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LLHSDK.LLHSDKLogin.InitNSSDK
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool InitNSSDK(struct FString Params); // Offset: 0x101442d8c // Return & Params: Num(2) Size(0x11)

	// Object Name: Function LLHSDK.LLHSDKLogin.InitLimSteamSDK
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool InitLimSteamSDK(struct FString Params); // Offset: 0x1014434f0 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function LLHSDK.LLHSDKLogin.InitLimPCSDK
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int32_t InitLimPCSDK(struct FString Params); // Offset: 0x101442bc0 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function LLHSDK.LLHSDKLogin.GetSteamToken
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetSteamToken(); // Offset: 0x101442fa0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKLogin.GetSteamRegisterUrl
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool GetSteamRegisterUrl(struct FString Params); // Offset: 0x101443338 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function LLHSDK.LLHSDKLogin.GetLimPCUserInfo
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int32_t GetLimPCUserInfo(struct FString Params); // Offset: 0x1014428ac // Return & Params: Num(2) Size(0x14)

	// Object Name: Function LLHSDK.LLHSDKLogin.GetLimPCAlilogFieldsData
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetLimPCAlilogFieldsData(); // Offset: 0x101442e9c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKLogin.GetLimPCAlilogFields
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int32_t GetLimPCAlilogFields(); // Offset: 0x1014427ec // Return & Params: Num(1) Size(0x4)

	// Object Name: Function LLHSDK.LLHSDKLogin.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct ULLHSDKLogin* GetInstance(); // Offset: 0x101443b98 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function LLHSDK.LLHSDKLogin.FreeLimPCSDK
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void FreeLimPCSDK(); // Offset: 0x101442b44 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LLHSDK.LLHSDKLogin.DoSteamBind
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool DoSteamBind(struct FString URL); // Offset: 0x10144307c // Return & Params: Num(2) Size(0x11)

	// Object Name: Function LLHSDK.LLHSDKLogin.DestoryInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void DestoryInstance(); // Offset: 0x101443b84 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LLHSDK.LLHSDKLogin.DAPLogAdd
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void DAPLogAdd(struct FString Params); // Offset: 0x101442e18 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKLogin.CommonReportLimPCPoint
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int32_t CommonReportLimPCPoint(struct FString Params); // Offset: 0x101442820 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function LLHSDK.LLHSDKLogin.ClearAutoLogin
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool ClearAutoLogin(); // Offset: 0x101443ae0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LLHSDK.LLHSDKLogin.ChangeLIMPCLanguage
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int32_t ChangeLIMPCLanguage(struct FString Params); // Offset: 0x101442938 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function LLHSDK.LLHSDKLogin.CanContinueLogin
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool CanContinueLogin(); // Offset: 0x101443020 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LLHSDK.LLHSDKLogin.CancelSteamCallBack
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void CancelSteamCallBack(); // Offset: 0x101443054 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class LLHSDK.LLHSDKMisc
// Size: 0x148 // Inherited bytes: 0x28
struct ULLHSDKMisc : UObject {
	// Fields
	struct FMulticastInlineDelegate OnBrowserClosed; // Offset: 0x28 // Size: 0x10
	struct FMulticastInlineDelegate OnScreenshotCaptured; // Offset: 0x38 // Size: 0x10
	char pad_0x48[0x8]; // Offset: 0x48 // Size: 0x08
	struct FMulticastInlineDelegate OnFacebookPhotoShared; // Offset: 0x50 // Size: 0x10
	char pad_0x60[0x8]; // Offset: 0x60 // Size: 0x08
	struct FMulticastInlineDelegate OnSystemShared; // Offset: 0x68 // Size: 0x10
	char pad_0x78[0x8]; // Offset: 0x78 // Size: 0x08
	struct FMulticastInlineDelegate OnGetFacebookToken; // Offset: 0x80 // Size: 0x10
	char pad_0x90[0x8]; // Offset: 0x90 // Size: 0x08
	struct FMulticastInlineDelegate OnQueryThirdPartyUserInfo; // Offset: 0x98 // Size: 0x10
	char pad_0xA8[0x8]; // Offset: 0xa8 // Size: 0x08
	struct FMulticastInlineDelegate OnRefreshFirebaseToken; // Offset: 0xb0 // Size: 0x10
	char pad_0xC0[0x8]; // Offset: 0xc0 // Size: 0x08
	struct FMulticastInlineDelegate OnHttpDiagnosisCallBack; // Offset: 0xc8 // Size: 0x10
	struct FMulticastInlineDelegate OnPingDiagnosisCallBack; // Offset: 0xd8 // Size: 0x10
	struct FMulticastInlineDelegate OnTcpPingDiagnosisCallBack; // Offset: 0xe8 // Size: 0x10
	struct FMulticastInlineDelegate OnMtrDiagnosisCallBack; // Offset: 0xf8 // Size: 0x10
	struct FMulticastInlineDelegate OnDnsDiagnosisCallBack; // Offset: 0x108 // Size: 0x10
	struct FMulticastInlineDelegate OnLimPCOpenWebview; // Offset: 0x118 // Size: 0x10
	struct FMulticastInlineDelegate OnLimPCCloseWebview; // Offset: 0x128 // Size: 0x10
	struct FMulticastInlineDelegate OnPickFileFromAlbumCallBack; // Offset: 0x138 // Size: 0x10

	// Functions

	// Object Name: Function LLHSDK.LLHSDKMisc.UpdateNetworkExtensions
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void UpdateNetworkExtensions(struct FString InUserId, struct FString InDeviceID); // Offset: 0x101445620 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function LLHSDK.LLHSDKMisc.TwitterShareText
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void TwitterShareText(struct FString InText); // Offset: 0x101445dc8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKMisc.TwitterSharePhoto
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void TwitterSharePhoto(struct FString InText, struct FString InFilePath); // Offset: 0x101445cec // Return & Params: Num(2) Size(0x20)

	// Object Name: Function LLHSDK.LLHSDKMisc.TryToEnableAndroidNotification
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void TryToEnableAndroidNotification(); // Offset: 0x101445bb0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LLHSDK.LLHSDKMisc.TcpPingDetect
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void TcpPingDetect(struct FString InDomain, int32_t Port); // Offset: 0x101445344 // Return & Params: Num(2) Size(0x14)

	// Object Name: Function LLHSDK.LLHSDKMisc.SystemShare
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void SystemShare(int32_t& ShareType, struct FString Description, struct FString FilePath); // Offset: 0x10144614c // Return & Params: Num(3) Size(0x28)

	// Object Name: Function LLHSDK.LLHSDKMisc.StartIOSFarlightBrowserWithOrientation
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void StartIOSFarlightBrowserWithOrientation(struct FString URL, struct FString Title, enum class ELLHSDKScreenOrientation Orientation); // Offset: 0x1014464d4 // Return & Params: Num(3) Size(0x21)

	// Object Name: Function LLHSDK.LLHSDKMisc.StartBrowserWithOrientation
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void StartBrowserWithOrientation(struct FString URL, struct FString Title, enum class ELLHSDKScreenOrientation Orientation); // Offset: 0x1014465fc // Return & Params: Num(3) Size(0x21)

	// Object Name: Function LLHSDK.LLHSDKMisc.StartBrowser
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void StartBrowser(struct FString URL, struct FString Title); // Offset: 0x101446724 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function LLHSDK.LLHSDKMisc.SetNetworkPolicyDomain
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetNetworkPolicyDomain(struct FString InDomain); // Offset: 0x10144559c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKMisc.SetNetworkMultipleDetect
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetNetworkMultipleDetect(bool InEnable); // Offset: 0x10144551c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LLHSDK.LLHSDKMisc.SetNetworkDiagnosisDeviceID
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetNetworkDiagnosisDeviceID(struct FString InDeviceID); // Offset: 0x10144577c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKMisc.RestartApplication
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void RestartApplication(struct FString IntentString); // Offset: 0x1014468b4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKMisc.RefreshFirebaseMessagingToken
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void RefreshFirebaseMessagingToken(); // Offset: 0x1014462e0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LLHSDK.LLHSDKMisc.RefreshAndroidMediaScanner
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void RefreshAndroidMediaScanner(struct FString InFullFilePath); // Offset: 0x101445c68 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKMisc.QueryThirdPartUserInfo
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void QueryThirdPartUserInfo(); // Offset: 0x101445c2c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LLHSDK.LLHSDKMisc.PingDetect
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void PingDetect(struct FString InDomain); // Offset: 0x101445414 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKMisc.PickFileFromAlbum
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void PickFileFromAlbum(); // Offset: 0x101445c54 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LLHSDK.LLHSDKMisc.OpenSteamPayWebPage
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void OpenSteamPayWebPage(struct FString URL); // Offset: 0x101445b2c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKMisc.OpenLimPCWebPage
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void OpenLimPCWebPage(struct FString Params); // Offset: 0x101445aa8 // Return & Params: Num(1) Size(0x10)

	// Object Name: DelegateFunction LLHSDK.LLHSDKMisc.OnSystemShared__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnSystemShared__DelegateSignature(bool bSuccess); // Offset: 0x103938968 // Return & Params: Num(1) Size(0x1)

	// Object Name: DelegateFunction LLHSDK.LLHSDKMisc.OnScreenshotCapturedEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnScreenshotCapturedEvent__DelegateSignature(struct FString FullPath); // Offset: 0x103938968 // Return & Params: Num(1) Size(0x10)

	// Object Name: DelegateFunction LLHSDK.LLHSDKMisc.OnRefreshFirebaseToken__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnRefreshFirebaseToken__DelegateSignature(struct FString FirebaseToken); // Offset: 0x103938968 // Return & Params: Num(1) Size(0x10)

	// Object Name: DelegateFunction LLHSDK.LLHSDKMisc.OnQueryThirdPartUserInfo__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnQueryThirdPartUserInfo__DelegateSignature(bool Success, int32_t ErrorCode, struct TArray<struct FSDKSocialUserInfo> SocialUserInfoList); // Offset: 0x103938968 // Return & Params: Num(3) Size(0x18)

	// Object Name: DelegateFunction LLHSDK.LLHSDKMisc.OnPickFileFromAlbumFinishEvent__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnPickFileFromAlbumFinishEvent__DelegateSignature(struct FString PickFilePath, int32_t ErrorCode); // Offset: 0x103938968 // Return & Params: Num(2) Size(0x14)

	// Object Name: DelegateFunction LLHSDK.LLHSDKMisc.OnLimPCOpenWebview__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnLimPCOpenWebview__DelegateSignature(struct FString Params); // Offset: 0x103938968 // Return & Params: Num(1) Size(0x10)

	// Object Name: DelegateFunction LLHSDK.LLHSDKMisc.OnLimPCCloseWebview__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnLimPCCloseWebview__DelegateSignature(struct FString Params); // Offset: 0x103938968 // Return & Params: Num(1) Size(0x10)

	// Object Name: DelegateFunction LLHSDK.LLHSDKMisc.OnGetFacebookToken__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnGetFacebookToken__DelegateSignature(bool Result, struct FString Token, struct FString ApplicationId, struct FString UserId, struct FString GraphDomain); // Offset: 0x103938968 // Return & Params: Num(5) Size(0x48)

	// Object Name: DelegateFunction LLHSDK.LLHSDKMisc.OnFacebookPhotoShared__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnFacebookPhotoShared__DelegateSignature(struct FString FilePath, bool bSuccess); // Offset: 0x103938968 // Return & Params: Num(2) Size(0x11)

	// Object Name: DelegateFunction LLHSDK.LLHSDKMisc.OnBrowserClosed__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnBrowserClosed__DelegateSignature(); // Offset: 0x103938968 // Return & Params: Num(0) Size(0x0)

	// Object Name: DelegateFunction LLHSDK.LLHSDKMisc.NetworkDiagnosisCallback__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void NetworkDiagnosisCallback__DelegateSignature(struct FString Type, struct FString Ret); // Offset: 0x103938968 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function LLHSDK.LLHSDKMisc.MtrDetect
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void MtrDetect(struct FString InDomain); // Offset: 0x1014452c0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKMisc.JumpToMarket
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void JumpToMarket(struct FString InAppPkg, struct FString InMarketPkg); // Offset: 0x1014463f8 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function LLHSDK.LLHSDKMisc.JumpToAppStore
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void JumpToAppStore(struct FString AppStoreUrl); // Offset: 0x101446374 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKMisc.IsFacebookShareable
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsFacebookShareable(); // Offset: 0x101446278 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LLHSDK.LLHSDKMisc.IsAppRooted
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsAppRooted(); // Offset: 0x101445bf8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LLHSDK.LLHSDKMisc.IsAndroidNotificationEnabled
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IsAndroidNotificationEnabled(); // Offset: 0x101445bc4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LLHSDK.LLHSDKMisc.InitNetworkDiagnosis
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void InitNetworkDiagnosis(struct FString InProject, struct FString InSecretKey, struct FString InEndPoint, struct FString InAccessKeyId, struct FString InAccessKeySecret, struct FString InUid, struct FString InChannel); // Offset: 0x101445800 // Return & Params: Num(7) Size(0x70)

	// Object Name: Function LLHSDK.LLHSDKMisc.HttpDetect
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void HttpDetect(struct FString InUrl); // Offset: 0x101445498 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKMisc.GetNetworkDiagnosisDeviceID
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetNetworkDiagnosisDeviceID(); // Offset: 0x1014456fc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKMisc.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct ULLHSDKMisc* GetInstance(); // Offset: 0x10144694c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function LLHSDK.LLHSDKMisc.GetFirebaseMessagingToken
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetFirebaseMessagingToken(); // Offset: 0x1014462f4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKMisc.GetFacebookToken
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void GetFacebookToken(); // Offset: 0x101445c40 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LLHSDK.LLHSDKMisc.FacebookSharePhotoWithFileAndDescription
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void FacebookSharePhotoWithFileAndDescription(struct FString Description, struct FString FilePath); // Offset: 0x101445fd8 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function LLHSDK.LLHSDKMisc.FacebookSharePhotoByPath
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void FacebookSharePhotoByPath(struct FString InFilePath); // Offset: 0x1014460b4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKMisc.FacebookSharePhoto
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void FacebookSharePhoto(); // Offset: 0x101446138 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LLHSDK.LLHSDKMisc.FacebookShareLink
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void FacebookShareLink(struct FString InLinkURL, struct FString InPreviewURL, struct FString InTitle, struct FString InDesc); // Offset: 0x101445e4c // Return & Params: Num(4) Size(0x40)

	// Object Name: Function LLHSDK.LLHSDKMisc.DnsDetect
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void DnsDetect(struct FString InServer, struct FString InDomain); // Offset: 0x1014451e4 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function LLHSDK.LLHSDKMisc.DestoryInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void DestoryInstance(); // Offset: 0x101446938 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LLHSDK.LLHSDKMisc.CloseLimPCWebPageAll
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void CloseLimPCWebPageAll(); // Offset: 0x101445a94 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LLHSDK.LLHSDKMisc.CheckGyroSensorSupport
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool CheckGyroSensorSupport(); // Offset: 0x1014462ac // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class LLHSDK.LLHSDKPay
// Size: 0x160 // Inherited bytes: 0x28
struct ULLHSDKPay : UObject {
	// Fields
	struct FMulticastInlineDelegate OnLSteamQuerySkus; // Offset: 0x28 // Size: 0x10
	struct FMulticastInlineDelegate OnLSteamSDKPayApplied; // Offset: 0x38 // Size: 0x10
	struct FMulticastInlineDelegate OnLimPCQueryPriceLadder; // Offset: 0x48 // Size: 0x10
	struct FMulticastInlineDelegate OnLimPCQueryPriceLadderWithRegion; // Offset: 0x58 // Size: 0x10
	struct FMulticastInlineDelegate OnLimPCPayApplied; // Offset: 0x68 // Size: 0x10
	struct FMulticastInlineDelegate OnSwitchSDKPayGetConsumables; // Offset: 0x78 // Size: 0x10
	struct FMulticastInlineDelegate OnSwitchSDKPayGetConsumableItems; // Offset: 0x88 // Size: 0x10
	struct FMulticastInlineDelegate OnSwitchSDKPayEShopOpen; // Offset: 0x98 // Size: 0x10
	struct FMulticastInlineDelegate OnSwitchSDKPayOrdersCheck; // Offset: 0xa8 // Size: 0x10
	struct FMulticastInlineDelegate OnSwitchSDKPayOrdersConsume; // Offset: 0xb8 // Size: 0x10
	struct FMulticastInlineDelegate OnGooglePayFinished; // Offset: 0xc8 // Size: 0x10
	struct FMulticastInlineDelegate OnGoogleQuerySkuItemDetails; // Offset: 0xd8 // Size: 0x10
	struct FMulticastInlineDelegate OnGoogleQuerySkuItemDetailsSubscription; // Offset: 0xe8 // Size: 0x10
	struct FMulticastInlineDelegate OnGetGoogleConsumeGoods; // Offset: 0xf8 // Size: 0x10
	struct FMulticastInlineDelegate OnGetGoogleConsumePointsGoods; // Offset: 0x108 // Size: 0x10
	struct FMulticastInlineDelegate OnIOSQuerySkus; // Offset: 0x118 // Size: 0x10
	struct FMulticastInlineDelegate OnIOSLLHPayFinished; // Offset: 0x128 // Size: 0x10
	struct FMulticastInlineDelegate OnGetIOSPurchaseExtNull; // Offset: 0x138 // Size: 0x10
	char pad_0x148[0x18]; // Offset: 0x148 // Size: 0x18

	// Functions

	// Object Name: Function LLHSDK.LLHSDKPay.Test_Google_SkuItemDetailsToString
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString Test_Google_SkuItemDetailsToString(struct FLLHSDKGenericSkuItemsDetailList InDetails); // Offset: 0x1014494fc // Return & Params: Num(2) Size(0x20)

	// Object Name: DelegateFunction LLHSDK.LLHSDKPay.SwitchSDKPayOrdersConsume__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void SwitchSDKPayOrdersConsume__DelegateSignature(struct FString Datas); // Offset: 0x103938968 // Return & Params: Num(1) Size(0x10)

	// Object Name: DelegateFunction LLHSDK.LLHSDKPay.SwitchSDKPayOrdersCheck__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void SwitchSDKPayOrdersCheck__DelegateSignature(struct FString Datas); // Offset: 0x103938968 // Return & Params: Num(1) Size(0x10)

	// Object Name: DelegateFunction LLHSDK.LLHSDKPay.SwitchSDKPayGetConsumables__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void SwitchSDKPayGetConsumables__DelegateSignature(struct FString Datas); // Offset: 0x103938968 // Return & Params: Num(1) Size(0x10)

	// Object Name: DelegateFunction LLHSDK.LLHSDKPay.SwitchSDKPayGetConsumableItems__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void SwitchSDKPayGetConsumableItems__DelegateSignature(struct FString Datas); // Offset: 0x103938968 // Return & Params: Num(1) Size(0x10)

	// Object Name: DelegateFunction LLHSDK.LLHSDKPay.SwitchSDKPayEShopOpen__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void SwitchSDKPayEShopOpen__DelegateSignature(struct FString Datas); // Offset: 0x103938968 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKPay.Switch_OrdersConsume
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void Switch_OrdersConsume(struct FString Params); // Offset: 0x101448c0c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKPay.Switch_OrdersCheck
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void Switch_OrdersCheck(struct FString Params); // Offset: 0x101448c90 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKPay.Switch_GetConsumables
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void Switch_GetConsumables(struct FString Params); // Offset: 0x101448e1c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKPay.Switch_GetConsumableItems
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void Switch_GetConsumableItems(struct FString Params); // Offset: 0x101448d98 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKPay.Switch_EShopOpen
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void Switch_EShopOpen(struct FString Params); // Offset: 0x101448d14 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKPay.SteamQuerySkus
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SteamQuerySkus(struct FString Params); // Offset: 0x101449040 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKPay.Steam_StartPay
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void Steam_StartPay(struct FString SteamPayInfo); // Offset: 0x101448fbc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKPay.SetPayNotifyUrl
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetPayNotifyUrl(struct FString InNotifyUrl); // Offset: 0x1014490c4 // Return & Params: Num(1) Size(0x10)

	// Object Name: DelegateFunction LLHSDK.LLHSDKPay.OnLLHQuerySkus__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void OnLLHQuerySkus__DelegateSignature(struct FLLHSDKGenericSkuItemsDetailList ItemsDetailList, struct TArray<struct FString>& InvalidProductIDs); // Offset: 0x103938968 // Return & Params: Num(2) Size(0x20)

	// Object Name: DelegateFunction LLHSDK.LLHSDKPay.OnLLHPayFinished__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnLLHPayFinished__DelegateSignature(bool bSuccess, int32_t ErrorCode, struct FString ErrorMsg, int32_t PayValue, struct FString ProductID, enum class ELLHSDKPayType PayType); // Offset: 0x103938968 // Return & Params: Num(6) Size(0x31)

	// Object Name: DelegateFunction LLHSDK.LLHSDKPay.OnGoogleQuerySkuSubItemDetails__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnGoogleQuerySkuSubItemDetails__DelegateSignature(bool bSuccess, int32_t ErrorCode, struct FString ItemsDetailListJsonString); // Offset: 0x103938968 // Return & Params: Num(3) Size(0x18)

	// Object Name: DelegateFunction LLHSDK.LLHSDKPay.OnGoogleQuerySkuItemDetails__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnGoogleQuerySkuItemDetails__DelegateSignature(bool bSuccess, int32_t ErrorCode, struct FString ItemsDetailListJsonString); // Offset: 0x103938968 // Return & Params: Num(3) Size(0x18)

	// Object Name: DelegateFunction LLHSDK.LLHSDKPay.OnGooglePayFinished__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnGooglePayFinished__DelegateSignature(bool bSuccess, int32_t ErrorCode, int32_t Price, struct FString ItemID, enum class ELLHSDKPayType PayType); // Offset: 0x103938968 // Return & Params: Num(5) Size(0x21)

	// Object Name: DelegateFunction LLHSDK.LLHSDKPay.OnGetIOSPurchaseExtNull__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnGetIOSPurchaseExtNull__DelegateSignature(struct FString AppUid, struct FString ProductID); // Offset: 0x103938968 // Return & Params: Num(2) Size(0x20)

	// Object Name: DelegateFunction LLHSDK.LLHSDKPay.OnGetGoogleConsumeGoods__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void OnGetGoogleConsumeGoods__DelegateSignature(struct TArray<struct FString>& Skus); // Offset: 0x103938968 // Return & Params: Num(1) Size(0x10)

	// Object Name: DelegateFunction LLHSDK.LLHSDKPay.LSteamSDKQuerySkus__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void LSteamSDKQuerySkus__DelegateSignature(struct FString Datas); // Offset: 0x103938968 // Return & Params: Num(1) Size(0x10)

	// Object Name: DelegateFunction LLHSDK.LLHSDKPay.LSteamSDKPayApplied__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void LSteamSDKPayApplied__DelegateSignature(struct FString Datas); // Offset: 0x103938968 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKPay.LimPCStartPay
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void LimPCStartPay(struct FString Params); // Offset: 0x101448ea0 // Return & Params: Num(1) Size(0x10)

	// Object Name: DelegateFunction LLHSDK.LLHSDKPay.LimPCSDKQueryPriceLadder__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void LimPCSDKQueryPriceLadder__DelegateSignature(struct FString Datas); // Offset: 0x103938968 // Return & Params: Num(1) Size(0x10)

	// Object Name: DelegateFunction LLHSDK.LLHSDKPay.LimPCSDKPayApplied__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate]
	void LimPCSDKPayApplied__DelegateSignature(struct FString Datas); // Offset: 0x103938968 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKPay.LimPCQueryPriceLadderWithRegion
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void LimPCQueryPriceLadderWithRegion(struct FString Params); // Offset: 0x101448f24 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKPay.LimPCQueryPriceLadder
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void LimPCQueryPriceLadder(); // Offset: 0x101448fa8 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LLHSDK.LLHSDKPay.IOS_SetUserPayExtInCallback
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void IOS_SetUserPayExtInCallback(struct FString ProductID, struct FString PayExt); // Offset: 0x101449148 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function LLHSDK.LLHSDKPay.IOS_SetUserPayExt
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void IOS_SetUserPayExt(struct FString PayExt); // Offset: 0x101449224 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKPay.IOS_SetAutoPayExt
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void IOS_SetAutoPayExt(bool bEnabled); // Offset: 0x1014492dc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LLHSDK.LLHSDKPay.IOS_QuerySkus
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void IOS_QuerySkus(struct TArray<struct FString>& ProductIDs); // Offset: 0x101449438 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKPay.IOS_LLHPay
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void IOS_LLHPay(struct FString ProductID, struct FString PayExt); // Offset: 0x10144935c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function LLHSDK.LLHSDKPay.IOS_GetAutoPayExt
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool IOS_GetAutoPayExt(); // Offset: 0x1014492a8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LLHSDK.LLHSDKPay.Google_StartPaySubscription
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void Google_StartPaySubscription(struct FString PayItemID, struct FString PayContext); // Offset: 0x101449b88 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function LLHSDK.LLHSDKPay.Google_StartPay
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void Google_StartPay(struct FString PayItemID, struct FString PayContext); // Offset: 0x101449d18 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function LLHSDK.LLHSDKPay.Google_QuerySkuItemDetailsSubscription
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void Google_QuerySkuItemDetailsSubscription(struct TArray<struct FString> Items); // Offset: 0x101449ea8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKPay.Google_QuerySkuItemDetails
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void Google_QuerySkuItemDetails(struct TArray<struct FString> Items); // Offset: 0x10144a04c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKPay.Google_HasConsumePointsGoods
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool Google_HasConsumePointsGoods(); // Offset: 0x101449a2c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LLHSDK.LLHSDKPay.Google_HasConsumeGoods
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool Google_HasConsumeGoods(); // Offset: 0x101449b54 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function LLHSDK.LLHSDKPay.Google_GetConsumePointsGoods
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct TArray<struct FString> Google_GetConsumePointsGoods(); // Offset: 0x101449938 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKPay.Google_GetConsumeGoods
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct TArray<struct FString> Google_GetConsumeGoods(); // Offset: 0x101449a60 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LLHSDK.LLHSDKPay.Google_ConsumeGoods
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void Google_ConsumeGoods(struct TArray<struct FString> Skus, struct TArray<struct FString> Contexts); // Offset: 0x10144962c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function LLHSDK.LLHSDKPay.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct ULLHSDKPay* GetInstance(); // Offset: 0x10144a204 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function LLHSDK.LLHSDKPay.DestoryInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void DestoryInstance(); // Offset: 0x10144a1f0 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class LLHSDK.LLHSDKReport
// Size: 0x28 // Inherited bytes: 0x28
struct ULLHSDKReport : UObject {
	// Functions

	// Object Name: Function LLHSDK.LLHSDKReport.ReportToThirdParty_TwoParams
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool ReportToThirdParty_TwoParams(struct FString EventName, struct FString Parameter1, struct FString Parameter2); // Offset: 0x10144c058 // Return & Params: Num(4) Size(0x31)

	// Object Name: Function LLHSDK.LLHSDKReport.ReportToThirdParty_ThreeParams
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool ReportToThirdParty_ThreeParams(struct FString EventName, struct FString Parameter1, struct FString Parameter2, struct FString Parameter3); // Offset: 0x10144bec4 // Return & Params: Num(5) Size(0x41)

	// Object Name: Function LLHSDK.LLHSDKReport.ReportToThirdParty_OneParam
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool ReportToThirdParty_OneParam(struct FString EventName, struct FString Parameter); // Offset: 0x10144c194 // Return & Params: Num(3) Size(0x21)

	// Object Name: Function LLHSDK.LLHSDKReport.ReportToThirdParty_FourParams
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool ReportToThirdParty_FourParams(struct FString EventName, struct FString Parameter1, struct FString Parameter2, struct FString Parameter3, struct FString Parameter4); // Offset: 0x10144bcd8 // Return & Params: Num(6) Size(0x51)

	// Object Name: Function LLHSDK.LLHSDKReport.ReportToThirdParty_FiveParams
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool ReportToThirdParty_FiveParams(struct FString EventName, struct FString Parameter1, struct FString Parameter2, struct FString Parameter3, struct FString Parameter4, struct FString Parameter5); // Offset: 0x10144ba94 // Return & Params: Num(7) Size(0x61)

	// Object Name: Function LLHSDK.LLHSDKReport.ReportToThirdParty
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool ReportToThirdParty(struct FString EventName); // Offset: 0x10144c278 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function LLHSDK.LLHSDKReport.ReportRevenueToThirdParty_TwoParams
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool ReportRevenueToThirdParty_TwoParams(struct FString EventName, enum class ELLHSDKReportCurrencyType Currency, struct FString Revenue, struct FString Parameter1, struct FString Parameter2); // Offset: 0x10144b5fc // Return & Params: Num(6) Size(0x49)

	// Object Name: Function LLHSDK.LLHSDKReport.ReportRevenueToThirdParty_ThreeParams
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool ReportRevenueToThirdParty_ThreeParams(struct FString EventName, enum class ELLHSDKReportCurrencyType Currency, struct FString Revenue, struct FString Parameter1, struct FString Parameter2, struct FString Parameter3); // Offset: 0x10144b3c4 // Return & Params: Num(7) Size(0x59)

	// Object Name: Function LLHSDK.LLHSDKReport.ReportRevenueToThirdParty_OneParam
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool ReportRevenueToThirdParty_OneParam(struct FString EventName, enum class ELLHSDKReportCurrencyType Currency, struct FString Revenue, struct FString Parameter); // Offset: 0x10144b7dc // Return & Params: Num(5) Size(0x39)

	// Object Name: Function LLHSDK.LLHSDKReport.ReportRevenueToThirdParty_FourParams
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool ReportRevenueToThirdParty_FourParams(struct FString EventName, enum class ELLHSDKReportCurrencyType Currency, struct FString Revenue, struct FString Parameter1, struct FString Parameter2, struct FString Parameter3, struct FString Parameter4); // Offset: 0x10144b134 // Return & Params: Num(8) Size(0x69)

	// Object Name: Function LLHSDK.LLHSDKReport.ReportRevenueToThirdParty_FiveParams
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool ReportRevenueToThirdParty_FiveParams(struct FString EventName, enum class ELLHSDKReportCurrencyType Currency, struct FString Revenue, struct FString Parameter1, struct FString Parameter2, struct FString Parameter3, struct FString Parameter4, struct FString Parameter5); // Offset: 0x10144ae4c // Return & Params: Num(9) Size(0x79)

	// Object Name: Function LLHSDK.LLHSDKReport.ReportRevenueToThirdParty
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool ReportRevenueToThirdParty(struct FString EventName, enum class ELLHSDKReportCurrencyType Currency, struct FString Revenue); // Offset: 0x10144b964 // Return & Params: Num(4) Size(0x29)

	// Object Name: Function LLHSDK.LLHSDKReport.ReportJsonToLilithImmediate
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	bool ReportJsonToLilithImmediate(struct FString EventName, struct FString JsonContentStr); // Offset: 0x10144c304 // Return & Params: Num(3) Size(0x21)

	// Object Name: Function LLHSDK.LLHSDKReport.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct ULLHSDKReport* GetInstance(); // Offset: 0x10144c3fc // Return & Params: Num(1) Size(0x8)

	// Object Name: Function LLHSDK.LLHSDKReport.DestoryInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void DestoryInstance(); // Offset: 0x10144c3e8 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class LLHSDK.LLHSDKSettings
// Size: 0x338 // Inherited bytes: 0x38
struct ULLHSDKSettings : UDeveloperSettings {
	// Fields
	enum class EDistributionRegion DistributionRegion; // Offset: 0x38 // Size: 0x01
	enum class EReleaseType ReleaseType; // Offset: 0x39 // Size: 0x01
	bool bIsSDKDebuggable; // Offset: 0x3a // Size: 0x01
	bool bIsGrayRelease; // Offset: 0x3b // Size: 0x01
	char pad_0x3C[0x4]; // Offset: 0x3c // Size: 0x04
	struct FString SDKGroupName; // Offset: 0x40 // Size: 0x10
	struct FString SDKFeatureName; // Offset: 0x50 // Size: 0x10
	struct FString SDKVersion; // Offset: 0x60 // Size: 0x10
	bool bHasFacebook; // Offset: 0x70 // Size: 0x01
	bool bHasTiktok; // Offset: 0x71 // Size: 0x01
	bool bHasFirebaseMessaging; // Offset: 0x72 // Size: 0x01
	bool bHasJiGuangPush; // Offset: 0x73 // Size: 0x01
	char pad_0x74[0x4]; // Offset: 0x74 // Size: 0x04
	struct FString SDKAppIdForGrayRelease; // Offset: 0x78 // Size: 0x10
	struct FString SDKGameIdForGrayRelease; // Offset: 0x88 // Size: 0x10
	struct FString PspAppIdForGrayRelease; // Offset: 0x98 // Size: 0x10
	struct FString AndroidDebugParkwayEnvIdForGrayRelease; // Offset: 0xa8 // Size: 0x10
	struct FString AndroidReleaseParkwayEnvIdForGrayRelease; // Offset: 0xb8 // Size: 0x10
	struct FString FacebookAppIDForGrayRelease; // Offset: 0xc8 // Size: 0x10
	struct FString FacebookContentProviderForGrayRelease; // Offset: 0xd8 // Size: 0x10
	struct FString SDKAppId; // Offset: 0xe8 // Size: 0x10
	struct FString SDKGameId; // Offset: 0xf8 // Size: 0x10
	struct FString FacebookContentProvider; // Offset: 0x108 // Size: 0x10
	struct FString FacebookAppID; // Offset: 0x118 // Size: 0x10
	struct FString IOSFacebookContentProvider; // Offset: 0x128 // Size: 0x10
	struct FString IOSFacebookAppID; // Offset: 0x138 // Size: 0x10
	struct FString PspAppId; // Offset: 0x148 // Size: 0x10
	struct FString AndroidDebugParkwayEnvId; // Offset: 0x158 // Size: 0x10
	struct FString AndroidReleaseParkwayEnvId; // Offset: 0x168 // Size: 0x10
	struct FString IOSDebugParkwayEnvId; // Offset: 0x178 // Size: 0x10
	struct FString IOSReleaseParkwayEnvId; // Offset: 0x188 // Size: 0x10
	struct FString SteamDebugParkwayEnvId; // Offset: 0x198 // Size: 0x10
	struct FString SteamReleaseParkwayEnvId; // Offset: 0x1a8 // Size: 0x10
	struct FString OffcialWinDebugParkwayEnvId; // Offset: 0x1b8 // Size: 0x10
	struct FString OffcialWinReleaseParkwayEnvId; // Offset: 0x1c8 // Size: 0x10
	struct FString EpicDebugParkwayEnvId; // Offset: 0x1d8 // Size: 0x10
	struct FString EpicReleaseParkwayEnvId; // Offset: 0x1e8 // Size: 0x10
	struct FString SDKAppIdForDomesticRelease; // Offset: 0x1f8 // Size: 0x10
	struct FString SDKGameIdForDomesticRelease; // Offset: 0x208 // Size: 0x10
	struct FString AndroidDebugParkwayEnvIdForDomesticRelease; // Offset: 0x218 // Size: 0x10
	struct FString AndroidReleaseParkwayEnvIdForDomesticRelease; // Offset: 0x228 // Size: 0x10
	struct FString IOSDebugParkwayEnvIdForDomesticRelease; // Offset: 0x238 // Size: 0x10
	struct FString IOSReleaseParkwayEnvIdForDomesticRelease; // Offset: 0x248 // Size: 0x10
	struct FString PspAppIdForDomesticRelease; // Offset: 0x258 // Size: 0x10
	struct FString OffcialWinDebugParkwayEnvIdForDomesticRelease; // Offset: 0x268 // Size: 0x10
	struct FString OffcialWinReleaseParkwayEnvIdForDomesticRelease; // Offset: 0x278 // Size: 0x10
	bool bAndroidXEnabled; // Offset: 0x288 // Size: 0x01
	bool bMultiDexEnabled; // Offset: 0x289 // Size: 0x01
	bool bShouldUseOverridedConfig; // Offset: 0x28a // Size: 0x01
	char pad_0x28B[0x5]; // Offset: 0x28b // Size: 0x05
	struct FString FirebaseCoreVersion; // Offset: 0x290 // Size: 0x10
	struct FString FirebaseMessagingVersion; // Offset: 0x2a0 // Size: 0x10
	struct FString GoogleServicesVersion; // Offset: 0x2b0 // Size: 0x10
	struct FString PlayServicesBasementVersion; // Offset: 0x2c0 // Size: 0x10
	enum class ELLHSDKGravity PlayPhoneGravity; // Offset: 0x2d0 // Size: 0x01
	bool bEnableAndroidScreenshotListener; // Offset: 0x2d1 // Size: 0x01
	bool bEnableAndroidMultipleDetect; // Offset: 0x2d2 // Size: 0x01
	bool bShowLogo; // Offset: 0x2d3 // Size: 0x01
	enum class ELLHSDKLoginUIStyle LoginUIStyle; // Offset: 0x2d4 // Size: 0x01
	bool bIOSShouldUseOverridedConfig; // Offset: 0x2d5 // Size: 0x01
	bool bIOSShowTermsByServer; // Offset: 0x2d6 // Size: 0x01
	char pad_0x2D7[0x1]; // Offset: 0x2d7 // Size: 0x01
	struct FString FacebookDisplayName; // Offset: 0x2d8 // Size: 0x10
	struct FString QQAppID; // Offset: 0x2e8 // Size: 0x10
	struct FString WechatAppID; // Offset: 0x2f8 // Size: 0x10
	struct FString GoogleReversedClientID; // Offset: 0x308 // Size: 0x10
	struct FString TwitterAPIKey; // Offset: 0x318 // Size: 0x10
	struct FString DefaultNSUserTrackingUsageDescription; // Offset: 0x328 // Size: 0x10
};

