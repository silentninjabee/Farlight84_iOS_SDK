#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class LimNative.LimNative
// Size: 0x3f0 // Inherited bytes: 0x28
struct ULimNative : UObject {
	// Fields
	bool ShowLog; // Offset: 0x28 // Size: 0x01
	char pad_0x29[0x7]; // Offset: 0x29 // Size: 0x07
	struct FMulticastInlineDelegate OnLog; // Offset: 0x30 // Size: 0x10
	struct FMulticastInlineDelegate OnEvent; // Offset: 0x40 // Size: 0x10
	struct FMulticastInlineDelegate OnGetLanguage; // Offset: 0x50 // Size: 0x10
	struct FMulticastInlineDelegate OnSetLanguage; // Offset: 0x60 // Size: 0x10
	struct FMulticastInlineDelegate OnSetAllConfig; // Offset: 0x70 // Size: 0x10
	struct FMulticastInlineDelegate OnSetReportConfig; // Offset: 0x80 // Size: 0x10
	struct FMulticastInlineDelegate OnSetParkConfig; // Offset: 0x90 // Size: 0x10
	struct FMulticastInlineDelegate OnGetResDir; // Offset: 0xa0 // Size: 0x10
	struct FMulticastInlineDelegate OnSetResDir; // Offset: 0xb0 // Size: 0x10
	struct FMulticastInlineDelegate OnLogin; // Offset: 0xc0 // Size: 0x10
	struct FMulticastInlineDelegate OnLoginV2; // Offset: 0xd0 // Size: 0x10
	struct FMulticastInlineDelegate OnLogout; // Offset: 0xe0 // Size: 0x10
	struct FMulticastInlineDelegate OnCreateGroup; // Offset: 0xf0 // Size: 0x10
	struct FMulticastInlineDelegate OnJoinGroup; // Offset: 0x100 // Size: 0x10
	struct FMulticastInlineDelegate OnQuitGroup; // Offset: 0x110 // Size: 0x10
	struct FMulticastInlineDelegate OnDestoryGroup; // Offset: 0x120 // Size: 0x10
	struct FMulticastInlineDelegate OnGetGroup; // Offset: 0x130 // Size: 0x10
	struct FMulticastInlineDelegate OnGetGroups; // Offset: 0x140 // Size: 0x10
	struct FMulticastInlineDelegate OnGetAttr; // Offset: 0x150 // Size: 0x10
	struct FMulticastInlineDelegate OnGetAllGroupAttr; // Offset: 0x160 // Size: 0x10
	struct FMulticastInlineDelegate OnSetGroupAttr; // Offset: 0x170 // Size: 0x10
	struct FMulticastInlineDelegate OnGetGroupMembers; // Offset: 0x180 // Size: 0x10
	struct FMulticastInlineDelegate OnAddGroupMember; // Offset: 0x190 // Size: 0x10
	struct FMulticastInlineDelegate OnRemoveGroupMember; // Offset: 0x1a0 // Size: 0x10
	struct FMulticastInlineDelegate OnGetGroupMember; // Offset: 0x1b0 // Size: 0x10
	struct FMulticastInlineDelegate OnSetConvRead; // Offset: 0x1c0 // Size: 0x10
	struct FMulticastInlineDelegate OnSendMsg; // Offset: 0x1d0 // Size: 0x10
	struct FMulticastInlineDelegate OnRevokeMsg; // Offset: 0x1e0 // Size: 0x10
	struct FMulticastInlineDelegate OnGetBeforeMsg; // Offset: 0x1f0 // Size: 0x10
	struct FMulticastInlineDelegate OnGetAfterMsg; // Offset: 0x200 // Size: 0x10
	struct FMulticastInlineDelegate OnGetMsgsById; // Offset: 0x210 // Size: 0x10
	struct FMulticastInlineDelegate OnGetCommonMsgs; // Offset: 0x220 // Size: 0x10
	struct FMulticastInlineDelegate OnSetMsgState; // Offset: 0x230 // Size: 0x10
	struct FMulticastInlineDelegate OnConvHandle; // Offset: 0x240 // Size: 0x10
	struct FMulticastInlineDelegate OnConvsGet; // Offset: 0x250 // Size: 0x10
	struct FMulticastInlineDelegate OnGetFriends; // Offset: 0x260 // Size: 0x10
	struct FMulticastInlineDelegate OnRemoveFriend; // Offset: 0x270 // Size: 0x10
	struct FMulticastInlineDelegate OnCreateFriendRequest; // Offset: 0x280 // Size: 0x10
	struct FMulticastInlineDelegate OnGetFriendRequests; // Offset: 0x290 // Size: 0x10
	struct FMulticastInlineDelegate OnAcceptFriendRequest; // Offset: 0x2a0 // Size: 0x10
	struct FMulticastInlineDelegate OnRefuseFriendRequest; // Offset: 0x2b0 // Size: 0x10
	struct FMulticastInlineDelegate OnCancelFriendRequest; // Offset: 0x2c0 // Size: 0x10
	struct FMulticastInlineDelegate OnGetBlockees; // Offset: 0x2d0 // Size: 0x10
	struct FMulticastInlineDelegate OnAddToBlockee; // Offset: 0x2e0 // Size: 0x10
	struct FMulticastInlineDelegate OnRemoveFromBlockee; // Offset: 0x2f0 // Size: 0x10
	struct FMulticastInlineDelegate OnGetUser; // Offset: 0x300 // Size: 0x10
	struct FMulticastInlineDelegate OnGetUsers; // Offset: 0x310 // Size: 0x10
	struct FMulticastInlineDelegate OnGetUsersState; // Offset: 0x320 // Size: 0x10
	struct FMulticastInlineDelegate OnReportMsg; // Offset: 0x330 // Size: 0x10
	struct FMulticastInlineDelegate OnTranslateText; // Offset: 0x340 // Size: 0x10
	struct FMulticastInlineDelegate OnCheckImage; // Offset: 0x350 // Size: 0x10
	struct FMulticastInlineDelegate OnGetOssToken; // Offset: 0x360 // Size: 0x10
	struct FMulticastInlineDelegate OnGetGMEToken; // Offset: 0x370 // Size: 0x10
	struct FMulticastInlineDelegate OnMsgReceived; // Offset: 0x380 // Size: 0x10
	struct FMulticastInlineDelegate OnMsgLogicReceived; // Offset: 0x390 // Size: 0x10
	struct FMulticastInlineDelegate OnMsgRevoked; // Offset: 0x3a0 // Size: 0x10
	struct FMulticastInlineDelegate OnGetMiscConfigInfo; // Offset: 0x3b0 // Size: 0x10
	struct FMulticastInlineDelegate OnGetConvChatLevelConfig; // Offset: 0x3c0 // Size: 0x10
	struct FMulticastInlineDelegate OnGetConnState; // Offset: 0x3d0 // Size: 0x10
	struct FMulticastInlineDelegate OnNetState; // Offset: 0x3e0 // Size: 0x10

	// Functions

	// Object Name: Function LimNative.LimNative.TranslateText
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void TranslateText(struct FLimNativeLowLevelWrapper& InCtx, struct FString InText, enum class ELimNativeSupportedLanguage InLang, struct FString ExtraInfo); // Offset: 0x1013d158c // Return & Params: Num(4) Size(0x38)

	// Object Name: Function LimNative.LimNative.SetResDir
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void SetResDir(struct FLimNativeLowLevelWrapper& InCtx, struct FString InResDir); // Offset: 0x1013d7e5c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function LimNative.LimNative.SetMsgState
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void SetMsgState(struct FLimNativeLowLevelWrapper& InCtx, struct FLimNativeSetMsgState& SetMsgParams); // Offset: 0x1013d3590 // Return & Params: Num(2) Size(0x50)

	// Object Name: Function LimNative.LimNative.SetLogHandler
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void SetLogHandler(struct FLimNativeLowLevelWrapper& InCtx); // Offset: 0x1013d8390 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LimNative.LimNative.SetLanguage
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void SetLanguage(struct FLimNativeLowLevelWrapper& InCtx, enum class ELimNativeSupportedLanguage InLanguage); // Offset: 0x1013d8194 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function LimNative.LimNative.SetGroupAttr
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void SetGroupAttr(struct FLimNativeLowLevelWrapper& InCtx, struct FString groupid, struct FString Key, struct FString Value); // Offset: 0x1013d67d8 // Return & Params: Num(4) Size(0x40)

	// Object Name: Function LimNative.LimNative.SetEventHandler
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void SetEventHandler(struct FLimNativeLowLevelWrapper& InCtx); // Offset: 0x1013d82b4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LimNative.LimNative.SetConvRead
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void SetConvRead(struct FLimNativeLowLevelWrapper& InCtx, struct FString ConvID, enum class ELimNativeConvType ConvType, struct FString InMsgID, struct FString Extra); // Offset: 0x1013d7590 // Return & Params: Num(5) Size(0x48)

	// Object Name: Function LimNative.LimNative.SetAllConfig
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void SetAllConfig(struct FLimNativeLowLevelWrapper& InCtx, struct FLimNativeInitConfig InConfig); // Offset: 0x1013d7f88 // Return & Params: Num(2) Size(0x88)

	// Object Name: Function LimNative.LimNative.SendVoiceMsg
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void SendVoiceMsg(struct FLimNativeLowLevelWrapper& InCtx, struct FLimNativeIMVoiceMessage& VoiceMsg, struct FString ConvID, enum class ELimNativeConvType ConvType, struct FString Nonce, struct FString Timestamp, struct FString Extra); // Offset: 0x1013d524c // Return & Params: Num(7) Size(0xe8)

	// Object Name: Function LimNative.LimNative.SendTextWithAtMsg
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void SendTextWithAtMsg(struct FLimNativeLowLevelWrapper& InCtx, struct FLimNativeIMTextWithAtMessage& TextWithAtMsg, struct FString ConvID, enum class ELimNativeConvType ConvType, struct FString Nonce, struct FString Timestamp, struct FString Extra); // Offset: 0x1013d5c1c // Return & Params: Num(7) Size(0xc0)

	// Object Name: Function LimNative.LimNative.SendTextMsg
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void SendTextMsg(struct FLimNativeLowLevelWrapper& InCtx, struct FLimNativeIMTextMessage& TextMsg, struct FString ConvID, enum class ELimNativeConvType ConvType, struct FString Nonce, struct FString Timestamp, struct FString Extra); // Offset: 0x1013d5f88 // Return & Params: Num(7) Size(0xc0)

	// Object Name: Function LimNative.LimNative.SendShareMsg
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void SendShareMsg(struct FLimNativeLowLevelWrapper& InCtx, struct FLimNativeIMShareMessage& ShareMsg, struct FString ConvID, enum class ELimNativeConvType ConvType, struct FString Nonce, struct FString Timestamp, struct FString Extra); // Offset: 0x1013d4f2c // Return & Params: Num(7) Size(0x118)

	// Object Name: Function LimNative.LimNative.SendImageMsg
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void SendImageMsg(struct FLimNativeLowLevelWrapper& InCtx, struct FLimNativeIMImageMessage& ImageMsg, struct FString ConvID, enum class ELimNativeConvType ConvType, struct FString Nonce, struct FString Timestamp, struct FString Extra); // Offset: 0x1013d55d8 // Return & Params: Num(7) Size(0xf8)

	// Object Name: Function LimNative.LimNative.SendEmotionMsg
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void SendEmotionMsg(struct FLimNativeLowLevelWrapper& InCtx, struct FLimNativeIMEmotionMessage& EmotionMsg, struct FString ConvID, enum class ELimNativeConvType ConvType, struct FString Nonce, struct FString Timestamp, struct FString Extra); // Offset: 0x1013d58fc // Return & Params: Num(7) Size(0x108)

	// Object Name: Function LimNative.LimNative.RevokeVoiceMsg
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void RevokeVoiceMsg(struct FLimNativeLowLevelWrapper& InCtx, struct FLimNativeIMVoiceMessage& VoiceMsg, struct FString ConvID, enum class ELimNativeConvType ConvType, struct FString Nonce, struct FString Timestamp); // Offset: 0x1013d404c // Return & Params: Num(6) Size(0xd8)

	// Object Name: Function LimNative.LimNative.RevokeTextWithAtMsg
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void RevokeTextWithAtMsg(struct FLimNativeLowLevelWrapper& InCtx, struct FLimNativeIMTextWithAtMessage& TextWithAtMsg, struct FString ConvID, enum class ELimNativeConvType ConvType, struct FString Nonce, struct FString Timestamp); // Offset: 0x1013d4914 // Return & Params: Num(6) Size(0xb0)

	// Object Name: Function LimNative.LimNative.RevokeTextMsg
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void RevokeTextMsg(struct FLimNativeLowLevelWrapper& InCtx, struct FLimNativeIMTextMessage& TextMsg, struct FString ConvID, enum class ELimNativeConvType ConvType, struct FString Nonce, struct FString Timestamp); // Offset: 0x1013d4c20 // Return & Params: Num(6) Size(0xb0)

	// Object Name: Function LimNative.LimNative.RevokeShareMsg
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void RevokeShareMsg(struct FLimNativeLowLevelWrapper& InCtx, struct FLimNativeIMShareMessage& ShareMsg, struct FString ConvID, enum class ELimNativeConvType ConvType, struct FString Nonce, struct FString Timestamp); // Offset: 0x1013d3d84 // Return & Params: Num(6) Size(0x108)

	// Object Name: Function LimNative.LimNative.RevokeImageMsg
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void RevokeImageMsg(struct FLimNativeLowLevelWrapper& InCtx, struct FLimNativeIMImageMessage& ImageMsg, struct FString ConvID, enum class ELimNativeConvType ConvType, struct FString Nonce, struct FString Timestamp); // Offset: 0x1013d4380 // Return & Params: Num(6) Size(0xe8)

	// Object Name: Function LimNative.LimNative.RevokeEmotionMsg
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void RevokeEmotionMsg(struct FLimNativeLowLevelWrapper& InCtx, struct FLimNativeIMEmotionMessage& EmotionMsg, struct FString ConvID, enum class ELimNativeConvType ConvType, struct FString Nonce, struct FString Timestamp); // Offset: 0x1013d464c // Return & Params: Num(6) Size(0xf8)

	// Object Name: Function LimNative.LimNative.ReportMsg
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void ReportMsg(struct FLimNativeLowLevelWrapper& InCtx, struct FString InType, struct FString InMsg); // Offset: 0x1013d175c // Return & Params: Num(3) Size(0x30)

	// Object Name: Function LimNative.LimNative.RemoveGroupMember
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void RemoveGroupMember(struct FLimNativeLowLevelWrapper& InCtx, struct FString groupid, struct FString memberid); // Offset: 0x1013d62f4 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function LimNative.LimNative.RemoveFromBlockee
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void RemoveFromBlockee(struct FLimNativeLowLevelWrapper& InCtx, struct FString InUserId); // Offset: 0x1013d2174 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function LimNative.LimNative.RemoveFriend
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void RemoveFriend(struct FLimNativeLowLevelWrapper& InCtx, struct FString InUserId, struct FString InExtra); // Offset: 0x1013d2dd4 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function LimNative.LimNative.RefuseFriendRequest
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void RefuseFriendRequest(struct FLimNativeLowLevelWrapper& InCtx, struct FString InRequestID, struct FString InExtra); // Offset: 0x1013d2778 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function LimNative.LimNative.QuitGroup
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void QuitGroup(struct FLimNativeLowLevelWrapper& InCtx, struct FString groupid); // Offset: 0x1013d7040 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function LimNative.LimNative.PostInitLIM
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void PostInitLIM(struct FLimNativeLowLevelWrapper& ctx, struct FLimNativeReportConfig ReportConfig, struct FLimNativeParkConfig ParkConfig); // Offset: 0x1013d8650 // Return & Params: Num(3) Size(0x130)

	// Object Name: Function LimNative.LimNative.MsgsGetCommon
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void MsgsGetCommon(struct FLimNativeLowLevelWrapper& InCtx); // Offset: 0x1013d36f8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LimNative.LimNative.Logout
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void Logout(struct FLimNativeLowLevelWrapper& InCtx); // Offset: 0x1013d77b8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LimNative.LimNative.LoginV2
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void LoginV2(struct FLimNativeLowLevelWrapper& InCtx, struct FString InEnvId, struct FString InRoleID); // Offset: 0x1013d7894 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function LimNative.LimNative.Login
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void Login(struct FLimNativeLowLevelWrapper& InCtx, struct FString InAppId, struct FString InAppUserID, struct FString InToken, struct FString InRoleID, struct FString InExtra); // Offset: 0x1013d7a18 // Return & Params: Num(6) Size(0x60)

	// Object Name: DelegateFunction LimNative.LimNative.LIMOnTranslateTextDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void LIMOnTranslateTextDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeTextTranslateCallBack& RetData); // Offset: 0x103938968 // Return & Params: Num(2) Size(0x98)

	// Object Name: DelegateFunction LimNative.LimNative.LIMOnSetResDirDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void LIMOnSetResDirDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeResDirConfig& RetData); // Offset: 0x103938968 // Return & Params: Num(2) Size(0x28)

	// Object Name: DelegateFunction LimNative.LimNative.LIMOnSetReportConfigDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void LIMOnSetReportConfigDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeReportConfig& RetData); // Offset: 0x103938968 // Return & Params: Num(2) Size(0xd8)

	// Object Name: DelegateFunction LimNative.LimNative.LIMOnSetParkConfigDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void LIMOnSetParkConfigDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeParkConfig& RetData); // Offset: 0x103938968 // Return & Params: Num(2) Size(0x68)

	// Object Name: DelegateFunction LimNative.LimNative.LIMOnSetMsgStateDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void LIMOnSetMsgStateDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnSetMsgStateCallBack& RetData); // Offset: 0x103938968 // Return & Params: Num(2) Size(0x40)

	// Object Name: DelegateFunction LimNative.LimNative.LIMOnSetLanguageDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void LIMOnSetLanguageDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeLanguageConfig& RetData); // Offset: 0x103938968 // Return & Params: Num(2) Size(0x20)

	// Object Name: DelegateFunction LimNative.LimNative.LIMOnSetGroupAttrDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void LIMOnSetGroupAttrDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnGroupAttrSetCallBack& RetData); // Offset: 0x103938968 // Return & Params: Num(2) Size(0x40)

	// Object Name: DelegateFunction LimNative.LimNative.LIMOnSetConvReadDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void LIMOnSetConvReadDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnSetConvReadCallBack& RetData); // Offset: 0x103938968 // Return & Params: Num(2) Size(0x40)

	// Object Name: DelegateFunction LimNative.LimNative.LIMOnSetAllConfigDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void LIMOnSetAllConfigDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeInitConfig& RetData); // Offset: 0x103938968 // Return & Params: Num(2) Size(0x88)

	// Object Name: DelegateFunction LimNative.LimNative.LIMOnSendMsgDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void LIMOnSendMsgDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnSendMsgCallBack& RetData); // Offset: 0x103938968 // Return & Params: Num(2) Size(0xd0)

	// Object Name: DelegateFunction LimNative.LimNative.LIMOnRevokeMsgDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void LIMOnRevokeMsgDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnRevokeMsgCallBack& RetData); // Offset: 0x103938968 // Return & Params: Num(2) Size(0x40)

	// Object Name: DelegateFunction LimNative.LimNative.LIMOnReportMsgDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void LIMOnReportMsgDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeDataCallBackBase& RetData); // Offset: 0x103938968 // Return & Params: Num(2) Size(0x40)

	// Object Name: DelegateFunction LimNative.LimNative.LIMOnRemoveGroupMemberDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void LIMOnRemoveGroupMemberDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnGroupMemberRemoveCallBack& RetData); // Offset: 0x103938968 // Return & Params: Num(2) Size(0xa8)

	// Object Name: DelegateFunction LimNative.LimNative.LIMOnRemoveFromBlockeeDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void LIMOnRemoveFromBlockeeDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeFriendCommonCallBack& RetData); // Offset: 0x103938968 // Return & Params: Num(2) Size(0x68)

	// Object Name: DelegateFunction LimNative.LimNative.LIMOnRemoveFriendDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void LIMOnRemoveFriendDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeFriendCommonCallBack& RetData); // Offset: 0x103938968 // Return & Params: Num(2) Size(0x68)

	// Object Name: DelegateFunction LimNative.LimNative.LIMOnRefuseFriendRequestDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void LIMOnRefuseFriendRequestDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeFriendCommonCallBack& RetData); // Offset: 0x103938968 // Return & Params: Num(2) Size(0x68)

	// Object Name: DelegateFunction LimNative.LimNative.LIMOnQuitGroupDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void LIMOnQuitGroupDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnGroupQuitCallBack& RetData); // Offset: 0x103938968 // Return & Params: Num(2) Size(0x60)

	// Object Name: DelegateFunction LimNative.LimNative.LIMOnNetConnectStateDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void LIMOnNetConnectStateDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, int32_t EventCode); // Offset: 0x103938968 // Return & Params: Num(2) Size(0x14)

	// Object Name: DelegateFunction LimNative.LimNative.LIMOnMsgRevokedDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void LIMOnMsgRevokedDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnMsgRevokedEventCallBack& RetData); // Offset: 0x103938968 // Return & Params: Num(2) Size(0x70)

	// Object Name: DelegateFunction LimNative.LimNative.LIMOnMsgReceivedDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void LIMOnMsgReceivedDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnMsgReceivedEventCallBack& RetData); // Offset: 0x103938968 // Return & Params: Num(2) Size(0x50)

	// Object Name: DelegateFunction LimNative.LimNative.LIMOnMsgLogicReceivedDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void LIMOnMsgLogicReceivedDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnMsgLogicReceivedEventCallBack& RetData); // Offset: 0x103938968 // Return & Params: Num(2) Size(0x48)

	// Object Name: DelegateFunction LimNative.LimNative.LIMOnLogoutDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void LIMOnLogoutDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnLogoutCallBack& RetData); // Offset: 0x103938968 // Return & Params: Num(2) Size(0x40)

	// Object Name: DelegateFunction LimNative.LimNative.LIMOnLoginDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void LIMOnLoginDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnLoginCallBack& RetData); // Offset: 0x103938968 // Return & Params: Num(2) Size(0x40)

	// Object Name: DelegateFunction LimNative.LimNative.LIMOnJoinGroupDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void LIMOnJoinGroupDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnGroupJoinCallBack& RetData); // Offset: 0x103938968 // Return & Params: Num(2) Size(0x40)

	// Object Name: DelegateFunction LimNative.LimNative.LIMOnGetUsersStateDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void LIMOnGetUsersStateDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnGetUsersStateCallBack& RetData); // Offset: 0x103938968 // Return & Params: Num(2) Size(0xb8)

	// Object Name: DelegateFunction LimNative.LimNative.LIMOnGetUsersDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void LIMOnGetUsersDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnGetUsersCallBack& RetData); // Offset: 0x103938968 // Return & Params: Num(2) Size(0x78)

	// Object Name: DelegateFunction LimNative.LimNative.LIMOnGetUserDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void LIMOnGetUserDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnGetUserCallBack& RetData); // Offset: 0x103938968 // Return & Params: Num(2) Size(0x178)

	// Object Name: DelegateFunction LimNative.LimNative.LIMOnGetOssTokenDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void LIMOnGetOssTokenDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeGetOssTokenCallBack& RetData); // Offset: 0x103938968 // Return & Params: Num(2) Size(0xe0)

	// Object Name: DelegateFunction LimNative.LimNative.LIMOnGetMsgsDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void LIMOnGetMsgsDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnGetMsgsCallBack& RetData); // Offset: 0x103938968 // Return & Params: Num(2) Size(0x58)

	// Object Name: DelegateFunction LimNative.LimNative.LIMOnGetMiscConfigInfoDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void LIMOnGetMiscConfigInfoDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeGetMiscConfigInfoCallBack& RetData); // Offset: 0x103938968 // Return & Params: Num(2) Size(0x80)

	// Object Name: DelegateFunction LimNative.LimNative.LIMOnGetGroupsDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void LIMOnGetGroupsDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnGroupsGetCallBack& RetData); // Offset: 0x103938968 // Return & Params: Num(2) Size(0x60)

	// Object Name: DelegateFunction LimNative.LimNative.LIMOnGetGroupMembersDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void LIMOnGetGroupMembersDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnGroupMembersGetCallBack& RetData); // Offset: 0x103938968 // Return & Params: Num(2) Size(0xa8)

	// Object Name: DelegateFunction LimNative.LimNative.LIMOnGetGroupMemberDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void LIMOnGetGroupMemberDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnGroupMemberGetCallBack& RetData); // Offset: 0x103938968 // Return & Params: Num(2) Size(0x40)

	// Object Name: DelegateFunction LimNative.LimNative.LIMOnGetGroupDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void LIMOnGetGroupDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnGroupGetCallBack& RetData); // Offset: 0x103938968 // Return & Params: Num(2) Size(0xa8)

	// Object Name: DelegateFunction LimNative.LimNative.LIMOnGetGroupAttrDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void LIMOnGetGroupAttrDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnGroupAttrGetCallBack& RetData); // Offset: 0x103938968 // Return & Params: Num(2) Size(0x40)

	// Object Name: DelegateFunction LimNative.LimNative.LIMOnGetGMETokenDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void LIMOnGetGMETokenDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeGetGMETokenCallBack& RetData); // Offset: 0x103938968 // Return & Params: Num(2) Size(0x78)

	// Object Name: DelegateFunction LimNative.LimNative.LIMOnGetFriendsDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void LIMOnGetFriendsDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnGetFriendCallBack& RetData); // Offset: 0x103938968 // Return & Params: Num(2) Size(0x78)

	// Object Name: DelegateFunction LimNative.LimNative.LIMOnGetFriendRequestsDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void LIMOnGetFriendRequestsDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnGetFriendRequestCallBack& RetData); // Offset: 0x103938968 // Return & Params: Num(2) Size(0x88)

	// Object Name: DelegateFunction LimNative.LimNative.LIMOnGetConvChatLevelConfigDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void LIMOnGetConvChatLevelConfigDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnGetConvChatLevelConfigCallBack& RetData); // Offset: 0x103938968 // Return & Params: Num(2) Size(0x50)

	// Object Name: DelegateFunction LimNative.LimNative.LIMOnGetConnStateDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void LIMOnGetConnStateDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeGetConnStateCallBack& RetData); // Offset: 0x103938968 // Return & Params: Num(2) Size(0x50)

	// Object Name: DelegateFunction LimNative.LimNative.LIMOnGetConfigDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void LIMOnGetConfigDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnGetConfigCallBack& RetData); // Offset: 0x103938968 // Return & Params: Num(2) Size(0x60)

	// Object Name: DelegateFunction LimNative.LimNative.LIMOnGetCommonMsgsDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void LIMOnGetCommonMsgsDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnGetCommonMsgsCallBack& RetData); // Offset: 0x103938968 // Return & Params: Num(2) Size(0x78)

	// Object Name: DelegateFunction LimNative.LimNative.LIMOnGetBlockeesDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void LIMOnGetBlockeesDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnGetBlockeesCallBack& RetData); // Offset: 0x103938968 // Return & Params: Num(2) Size(0x78)

	// Object Name: DelegateFunction LimNative.LimNative.LIMOnGetAllGroupAttrDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void LIMOnGetAllGroupAttrDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnGroupAttrGetAllCallBack& RetData); // Offset: 0x103938968 // Return & Params: Num(2) Size(0x40)

	// Object Name: DelegateFunction LimNative.LimNative.LIMOnDestoryGroupDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void LIMOnDestoryGroupDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnGroupDestoryCallBack& RetData); // Offset: 0x103938968 // Return & Params: Num(2) Size(0x40)

	// Object Name: DelegateFunction LimNative.LimNative.LIMOnCreateGroupDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void LIMOnCreateGroupDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnCreateGroupCallBack& RetData); // Offset: 0x103938968 // Return & Params: Num(2) Size(0xa8)

	// Object Name: DelegateFunction LimNative.LimNative.LIMOnCreateFriendRequestDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void LIMOnCreateFriendRequestDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnCreateFriendRequestCallBack& RetData); // Offset: 0x103938968 // Return & Params: Num(2) Size(0x78)

	// Object Name: DelegateFunction LimNative.LimNative.LIMOnConvsGetDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void LIMOnConvsGetDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnConvsGetCallBack& RetData); // Offset: 0x103938968 // Return & Params: Num(2) Size(0x58)

	// Object Name: DelegateFunction LimNative.LimNative.LIMOnConvHandleynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void LIMOnConvHandleynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnConvHandleCallBack& RetData); // Offset: 0x103938968 // Return & Params: Num(2) Size(0x78)

	// Object Name: DelegateFunction LimNative.LimNative.LIMOnCheckImageDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void LIMOnCheckImageDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeDataCallBackBase& RetData); // Offset: 0x103938968 // Return & Params: Num(2) Size(0x40)

	// Object Name: DelegateFunction LimNative.LimNative.LIMOnCancelFriendRequestDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void LIMOnCancelFriendRequestDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeFriendCommonCallBack& RetData); // Offset: 0x103938968 // Return & Params: Num(2) Size(0x68)

	// Object Name: DelegateFunction LimNative.LimNative.LIMOnAddToBlockeeDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void LIMOnAddToBlockeeDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeFriendCommonCallBack& RetData); // Offset: 0x103938968 // Return & Params: Num(2) Size(0x68)

	// Object Name: DelegateFunction LimNative.LimNative.LIMOnAddGroupMemberDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void LIMOnAddGroupMemberDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeOnGroupMemberAddCallBack& RetData); // Offset: 0x103938968 // Return & Params: Num(2) Size(0xa8)

	// Object Name: DelegateFunction LimNative.LimNative.LIMOnAcceptFriendRequestDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void LIMOnAcceptFriendRequestDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FLimNativeFriendCommonCallBack& RetData); // Offset: 0x103938968 // Return & Params: Num(2) Size(0x68)

	// Object Name: DelegateFunction LimNative.LimNative.LIMLogDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void LIMLogDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FString InData); // Offset: 0x103938968 // Return & Params: Num(2) Size(0x20)

	// Object Name: DelegateFunction LimNative.LimNative.LIMEventDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void LIMEventDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FString InData); // Offset: 0x103938968 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function LimNative.LimNative.JoinGroup
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void JoinGroup(struct FLimNativeLowLevelWrapper& InCtx, struct FString groupid); // Offset: 0x1013d716c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function LimNative.LimNative.InitLIM
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FLimNativeLowLevelWrapper InitLIM(struct FString InServerEnvID, struct FLimNativeInitConfig InConfig); // Offset: 0x1013d88c8 // Return & Params: Num(3) Size(0x98)

	// Object Name: Function LimNative.LimNative.GetUsersState
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetUsersState(struct FLimNativeLowLevelWrapper& InCtx, struct TArray<struct FString>& InUserIDs); // Offset: 0x1013d1d50 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function LimNative.LimNative.GetUsers
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetUsers(struct FLimNativeLowLevelWrapper& InCtx, struct FUidList& InUserIDs); // Offset: 0x1013d1ebc // Return & Params: Num(2) Size(0x28)

	// Object Name: Function LimNative.LimNative.GetUser
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetUser(struct FLimNativeLowLevelWrapper& InCtx, struct FString InUserId); // Offset: 0x1013d2048 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function LimNative.LimNative.GetResDir
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetResDir(struct FLimNativeLowLevelWrapper& InCtx); // Offset: 0x1013d7ca4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LimNative.LimNative.GetOssToken
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetOssToken(struct FLimNativeLowLevelWrapper& InCtx); // Offset: 0x1013d1c74 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LimNative.LimNative.GetMiscConfigInfo
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetMiscConfigInfo(struct FLimNativeLowLevelWrapper& InCtx); // Offset: 0x1013d1b98 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LimNative.LimNative.GetMessagesByID
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetMessagesByID(struct FLimNativeLowLevelWrapper& InCtx, struct FString InConvID, enum class ELimNativeConvType InConvType, struct FString InFromMsgID, struct FString InToMsgID); // Offset: 0x1013d3998 // Return & Params: Num(5) Size(0x48)

	// Object Name: Function LimNative.LimNative.GetLIMVersion
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetLIMVersion(); // Offset: 0x1013d846c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LimNative.LimNative.GetLimNativeInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct ULimNative* GetLimNativeInstance(); // Offset: 0x1013d8b6c // Return & Params: Num(1) Size(0x8)

	// Object Name: Function LimNative.LimNative.GetLanguage
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetLanguage(struct FLimNativeLowLevelWrapper& InCtx); // Offset: 0x1013d7d80 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LimNative.LimNative.GetGroups
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetGroups(struct FLimNativeLowLevelWrapper& InCtx, struct FString Tag, struct FString Size); // Offset: 0x1013d6c64 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function LimNative.LimNative.GetGroupMembers
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetGroupMembers(struct FLimNativeLowLevelWrapper& InCtx, struct FString groupid, struct FString Tag, struct FString Size); // Offset: 0x1013d65fc // Return & Params: Num(4) Size(0x40)

	// Object Name: Function LimNative.LimNative.GetGroupAttr
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetGroupAttr(struct FLimNativeLowLevelWrapper& InCtx, struct FString groupid, struct FString Key); // Offset: 0x1013d6ae0 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function LimNative.LimNative.GetGroupAllAttr
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetGroupAllAttr(struct FLimNativeLowLevelWrapper& InCtx, struct FString groupid); // Offset: 0x1013d69b4 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function LimNative.LimNative.GetGroup
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetGroup(struct FLimNativeLowLevelWrapper& InCtx, struct FString groupid); // Offset: 0x1013d6de8 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function LimNative.LimNative.GetGMEToken
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetGMEToken(struct FLimNativeLowLevelWrapper& InCtx, struct FString InAppId, struct FString InUserId, struct FString InRoomId); // Offset: 0x1013d18e0 // Return & Params: Num(4) Size(0x40)

	// Object Name: Function LimNative.LimNative.GetFriendsV2
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetFriendsV2(struct FLimNativeLowLevelWrapper& InCtx, bool InNeedPresence); // Offset: 0x1013d2f58 // Return & Params: Num(2) Size(0x11)

	// Object Name: Function LimNative.LimNative.GetFriends
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetFriends(struct FLimNativeLowLevelWrapper& InCtx, int32_t InTag, struct FString InSize, struct FString InExtra); // Offset: 0x1013d3080 // Return & Params: Num(4) Size(0x38)

	// Object Name: Function LimNative.LimNative.GetFriendRequests
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetFriendRequests(struct FLimNativeLowLevelWrapper& InCtx, int32_t InTag, struct FString InSize, struct FString InExtra); // Offset: 0x1013d2a80 // Return & Params: Num(4) Size(0x38)

	// Object Name: Function LimNative.LimNative.GetConvChatLevelConfig
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetConvChatLevelConfig(struct FLimNativeLowLevelWrapper& InCtx); // Offset: 0x1013d74b4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LimNative.LimNative.GetConnState
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetConnState(struct FLimNativeLowLevelWrapper& InCtx); // Offset: 0x1013d1abc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LimNative.LimNative.GetBlockees
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetBlockees(struct FLimNativeLowLevelWrapper& InCtx, int32_t InTag, struct FString InSize, struct FString InExtra); // Offset: 0x1013d23cc // Return & Params: Num(4) Size(0x38)

	// Object Name: Function LimNative.LimNative.GetBeforeMessages
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetBeforeMessages(struct FLimNativeLowLevelWrapper& InCtx, struct FString ConvID, enum class ELimNativeConvType ConvType, int32_t MsgId); // Offset: 0x1013d3bc0 // Return & Params: Num(4) Size(0x28)

	// Object Name: Function LimNative.LimNative.GetAfterMessages
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetAfterMessages(struct FLimNativeLowLevelWrapper& InCtx, struct FString ConvID, enum class ELimNativeConvType ConvType, int32_t MsgId); // Offset: 0x1013d37d4 // Return & Params: Num(4) Size(0x28)

	// Object Name: Function LimNative.LimNative.DestoryLimNativeInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void DestoryLimNativeInstance(); // Offset: 0x1013d8b58 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LimNative.LimNative.DestoryGroup
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void DestoryGroup(struct FLimNativeLowLevelWrapper& InCtx, struct FString groupid); // Offset: 0x1013d6f14 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function LimNative.LimNative.CreateLIM
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FLimNativeLowLevelWrapper CreateLIM(struct FString InServerEnvID); // Offset: 0x1013d84ec // Return & Params: Num(2) Size(0x20)

	// Object Name: Function LimNative.LimNative.CreateGroup
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void CreateGroup(struct FLimNativeLowLevelWrapper& InCtx, struct FString Name, struct TArray<struct FString>& members, struct FString Extra); // Offset: 0x1013d7298 // Return & Params: Num(4) Size(0x40)

	// Object Name: Function LimNative.LimNative.CreateFriendRequest
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void CreateFriendRequest(struct FLimNativeLowLevelWrapper& InCtx, struct FString InUserId, struct FString InExtra); // Offset: 0x1013d2c50 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function LimNative.LimNative.ConversationsGet
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void ConversationsGet(struct FLimNativeLowLevelWrapper& InCtx, int32_t Size, struct FString Extra); // Offset: 0x1013d32a0 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function LimNative.LimNative.ConversationSetSticky
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void ConversationSetSticky(); // Offset: 0x1013d3278 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LimNative.LimNative.ConversationSetRead
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void ConversationSetRead(); // Offset: 0x1013d328c // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LimNative.LimNative.ConversationSetMute
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void ConversationSetMute(); // Offset: 0x1013d3264 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LimNative.LimNative.ConversationSetHide
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void ConversationSetHide(); // Offset: 0x1013d3250 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LimNative.LimNative.ConversationDiscard
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void ConversationDiscard(struct FLimNativeLowLevelWrapper& InCtx, struct FString ConvID, enum class ELimNativeConvType ConvType); // Offset: 0x1013d3418 // Return & Params: Num(3) Size(0x21)

	// Object Name: Function LimNative.LimNative.CheckImage
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void CheckImage(struct FLimNativeLowLevelWrapper& InCtx, struct FString InUrl); // Offset: 0x1013d1460 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function LimNative.LimNative.CancelFriendRequest
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void CancelFriendRequest(struct FLimNativeLowLevelWrapper& InCtx, struct FString InUserId, struct FString InRequestID, struct FString InExtra); // Offset: 0x1013d259c // Return & Params: Num(4) Size(0x40)

	// Object Name: Function LimNative.LimNative.AddToBlockee
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void AddToBlockee(struct FLimNativeLowLevelWrapper& InCtx, struct FString InUserId); // Offset: 0x1013d22a0 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function LimNative.LimNative.AddGroupMember
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void AddGroupMember(struct FLimNativeLowLevelWrapper& InCtx, struct FString groupid, struct FString memberid); // Offset: 0x1013d6478 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function LimNative.LimNative.AcceptFriendRequest
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void AcceptFriendRequest(struct FLimNativeLowLevelWrapper& InCtx, struct FString InRequestID, struct FString InExtra); // Offset: 0x1013d28fc // Return & Params: Num(3) Size(0x30)
};

// Object Name: Class LimNative.LimNativeChatMsgReader
// Size: 0x28 // Inherited bytes: 0x28
struct ULimNativeChatMsgReader : UObject {
	// Functions

	// Object Name: Function LimNative.LimNativeChatMsgReader.GetVoiceMessage
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct FLimNativeIMVoiceMessage GetVoiceMessage(struct FLimNativeIMChatMessage& MsgStructWrapper, struct FLimNativeIMChatMessageInfo& MsgInfo); // Offset: 0x1013e1448 // Return & Params: Num(3) Size(0x150)

	// Object Name: Function LimNative.LimNativeChatMsgReader.GetTextMessage
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct FLimNativeIMTextMessage GetTextMessage(struct FLimNativeIMChatMessage& MsgStructWrapper, struct FLimNativeIMChatMessageInfo& MsgInfo); // Offset: 0x1013e1e40 // Return & Params: Num(3) Size(0x128)

	// Object Name: Function LimNative.LimNativeChatMsgReader.GetShareMessage
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct FLimNativeIMShareMessage GetShareMessage(struct FLimNativeIMChatMessage& MsgStructWrapper, struct FLimNativeIMChatMessageInfo& MsgInfo); // Offset: 0x1013e110c // Return & Params: Num(3) Size(0x180)

	// Object Name: Function LimNative.LimNativeChatMsgReader.GetNotificationMessage
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct FLimNativeIMNotificationMessage GetNotificationMessage(struct FLimNativeIMChatMessage& MsgStructWrapper, struct FLimNativeIMChatMessageInfo& MsgInfo); // Offset: 0x1013e0dc0 // Return & Params: Num(3) Size(0x128)

	// Object Name: Function LimNative.LimNativeChatMsgReader.GetImageMessage
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct FLimNativeIMImageMessage GetImageMessage(struct FLimNativeIMChatMessage& MsgStructWrapper, struct FLimNativeIMChatMessageInfo& MsgInfo); // Offset: 0x1013e1804 // Return & Params: Num(3) Size(0x160)

	// Object Name: Function LimNative.LimNativeChatMsgReader.GetEmotionMessage
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	struct FLimNativeIMEmotionMessage GetEmotionMessage(struct FLimNativeIMChatMessage& MsgStructWrapper, struct FLimNativeIMChatMessageInfo& MsgInfo); // Offset: 0x1013e1b10 // Return & Params: Num(3) Size(0x170)
};

// Object Name: Class LimNative.LimNativeHelper
// Size: 0x28 // Inherited bytes: 0x28
struct ULimNativeHelper : UObject {
	// Functions

	// Object Name: Function LimNative.LimNativeHelper.NameStringToEnumValue
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	int32_t NameStringToEnumValue(struct FString Enum, struct FString EnumName); // Offset: 0x1013f7968 // Return & Params: Num(3) Size(0x24)

	// Object Name: Function LimNative.LimNativeHelper.GetUE4LogFilePath
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetUE4LogFilePath(); // Offset: 0x1013f7dec // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LimNative.LimNativeHelper.GetSavedPath
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetSavedPath(); // Offset: 0x1013f7e6c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LimNative.LimNativeHelper.GetProjectPath
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetProjectPath(); // Offset: 0x1013f7d6c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LimNative.LimNativeHelper.GetProjectContentPath
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetProjectContentPath(); // Offset: 0x1013f7cec // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LimNative.LimNativeHelper.GetGamePersistentDownloadDir
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetGamePersistentDownloadDir(); // Offset: 0x1013f7c6c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LimNative.LimNativeHelper.GetFileText
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetFileText(struct FString Path); // Offset: 0x1013f7594 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function LimNative.LimNativeHelper.GetFileBinary
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct TArray<char> GetFileBinary(struct FString Path); // Offset: 0x1013f74d0 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function LimNative.LimNativeHelper.EnumToStringArray
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct TArray<struct FString> EnumToStringArray(struct FString Enum, bool bExcludeHidden); // Offset: 0x1013f77e0 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function LimNative.LimNativeHelper.EnumToString
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString EnumToString(struct FString Enum, int32_t EnumValue); // Offset: 0x1013f7b5c // Return & Params: Num(3) Size(0x28)

	// Object Name: Function LimNative.LimNativeHelper.EnumToNameStringArray
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct TArray<struct FString> EnumToNameStringArray(struct FString Enum, bool bExcludeHidden); // Offset: 0x1013f7658 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function LimNative.LimNativeHelper.EnumToNameString
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString EnumToNameString(struct FString Enum, int32_t EnumValue); // Offset: 0x1013f7a4c // Return & Params: Num(3) Size(0x28)
};

// Object Name: Class LimNative.LimNativeLowLevel
// Size: 0x418 // Inherited bytes: 0x28
struct ULimNativeLowLevel : UObject {
	// Fields
	struct FMulticastInlineDelegate OnEvent; // Offset: 0x28 // Size: 0x10
	struct FMulticastInlineDelegate OnLog; // Offset: 0x38 // Size: 0x10
	struct FMulticastInlineDelegate OnCall; // Offset: 0x48 // Size: 0x10
	struct FMulticastInlineDelegate OnSetConfig; // Offset: 0x58 // Size: 0x10
	struct FMulticastInlineDelegate OnSetAllConfigs; // Offset: 0x68 // Size: 0x10
	struct FMulticastInlineDelegate OnGetConfig; // Offset: 0x78 // Size: 0x10
	struct FMulticastInlineDelegate OnGetAllConfigs; // Offset: 0x88 // Size: 0x10
	struct FMulticastInlineDelegate OnLogin; // Offset: 0x98 // Size: 0x10
	struct FMulticastInlineDelegate OnLoginV2; // Offset: 0xa8 // Size: 0x10
	struct FMulticastInlineDelegate OnLogout; // Offset: 0xb8 // Size: 0x10
	struct FMulticastInlineDelegate OnSendMsg; // Offset: 0xc8 // Size: 0x10
	struct FMulticastInlineDelegate OnRevokeMsg; // Offset: 0xd8 // Size: 0x10
	struct FMulticastInlineDelegate OnGetMsgs; // Offset: 0xe8 // Size: 0x10
	struct FMulticastInlineDelegate OnGetMsgsV2; // Offset: 0xf8 // Size: 0x10
	struct FMulticastInlineDelegate OnSetMsgRead; // Offset: 0x108 // Size: 0x10
	struct FMulticastInlineDelegate OnSetMsgState; // Offset: 0x118 // Size: 0x10
	struct FMulticastInlineDelegate OnCreateConv; // Offset: 0x128 // Size: 0x10
	struct FMulticastInlineDelegate OnDestroyConv; // Offset: 0x138 // Size: 0x10
	struct FMulticastInlineDelegate OnClearConv; // Offset: 0x148 // Size: 0x10
	struct FMulticastInlineDelegate OnGetConvs; // Offset: 0x158 // Size: 0x10
	struct FMulticastInlineDelegate OnGetConv; // Offset: 0x168 // Size: 0x10
	struct FMulticastInlineDelegate OnSetConvRead; // Offset: 0x178 // Size: 0x10
	struct FMulticastInlineDelegate OnSetConvSticky; // Offset: 0x188 // Size: 0x10
	struct FMulticastInlineDelegate OnSetConvMute; // Offset: 0x198 // Size: 0x10
	struct FMulticastInlineDelegate OnGetConvAttr; // Offset: 0x1a8 // Size: 0x10
	struct FMulticastInlineDelegate OnGetConvAllAttrs; // Offset: 0x1b8 // Size: 0x10
	struct FMulticastInlineDelegate OnSetConvAttr; // Offset: 0x1c8 // Size: 0x10
	struct FMulticastInlineDelegate OnCreateGroup; // Offset: 0x1d8 // Size: 0x10
	struct FMulticastInlineDelegate OnJoinGroup; // Offset: 0x1e8 // Size: 0x10
	struct FMulticastInlineDelegate OnQuitGroup; // Offset: 0x1f8 // Size: 0x10
	struct FMulticastInlineDelegate OnDestroyGroup; // Offset: 0x208 // Size: 0x10
	struct FMulticastInlineDelegate OnGetGroup; // Offset: 0x218 // Size: 0x10
	struct FMulticastInlineDelegate OnSetGroup; // Offset: 0x228 // Size: 0x10
	struct FMulticastInlineDelegate OnGetGroups; // Offset: 0x238 // Size: 0x10
	struct FMulticastInlineDelegate OnGetGroupAttr; // Offset: 0x248 // Size: 0x10
	struct FMulticastInlineDelegate OnGetGroupAllAttrs; // Offset: 0x258 // Size: 0x10
	struct FMulticastInlineDelegate OnSetGroupAttr; // Offset: 0x268 // Size: 0x10
	struct FMulticastInlineDelegate OnGetGroupMembers; // Offset: 0x278 // Size: 0x10
	struct FMulticastInlineDelegate OnGetGroupMember; // Offset: 0x288 // Size: 0x10
	struct FMulticastInlineDelegate OnAddGroupMember; // Offset: 0x298 // Size: 0x10
	struct FMulticastInlineDelegate OnRemoveGroupMember; // Offset: 0x2a8 // Size: 0x10
	struct FMulticastInlineDelegate OnGetFriends; // Offset: 0x2b8 // Size: 0x10
	struct FMulticastInlineDelegate OnRemoveFriend; // Offset: 0x2c8 // Size: 0x10
	struct FMulticastInlineDelegate OnGetFriendRequests; // Offset: 0x2d8 // Size: 0x10
	struct FMulticastInlineDelegate OnCreateFriendRequest; // Offset: 0x2e8 // Size: 0x10
	struct FMulticastInlineDelegate OnAcceptFriendRequest; // Offset: 0x2f8 // Size: 0x10
	struct FMulticastInlineDelegate OnRefuseFriendRequest; // Offset: 0x308 // Size: 0x10
	struct FMulticastInlineDelegate OnCancelFriendRequest; // Offset: 0x318 // Size: 0x10
	struct FMulticastInlineDelegate OnGetBlockees; // Offset: 0x328 // Size: 0x10
	struct FMulticastInlineDelegate OnAddToBlockee; // Offset: 0x338 // Size: 0x10
	struct FMulticastInlineDelegate OnRemoveFromBlockee; // Offset: 0x348 // Size: 0x10
	struct FMulticastInlineDelegate OnBlockeeExists; // Offset: 0x358 // Size: 0x10
	struct FMulticastInlineDelegate OnGetUser; // Offset: 0x368 // Size: 0x10
	struct FMulticastInlineDelegate OnGetUsers; // Offset: 0x378 // Size: 0x10
	struct FMulticastInlineDelegate OnGetUsersState; // Offset: 0x388 // Size: 0x10
	struct FMulticastInlineDelegate OnGetOssToken; // Offset: 0x398 // Size: 0x10
	struct FMulticastInlineDelegate OnGetGMEToken; // Offset: 0x3a8 // Size: 0x10
	struct FMulticastInlineDelegate OnReportMsg; // Offset: 0x3b8 // Size: 0x10
	struct FMulticastInlineDelegate OnTranslateText; // Offset: 0x3c8 // Size: 0x10
	struct FMulticastInlineDelegate OnCheckImage; // Offset: 0x3d8 // Size: 0x10
	struct FMulticastInlineDelegate OnGetMiscConfigInfo; // Offset: 0x3e8 // Size: 0x10
	struct FMulticastInlineDelegate OnGetConvChatLevelConfig; // Offset: 0x3f8 // Size: 0x10
	struct FMulticastInlineDelegate OnGetConnState; // Offset: 0x408 // Size: 0x10

	// Functions

	// Object Name: Function LimNative.LimNativeLowLevel.TranslateText
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void TranslateText(struct FLimNativeLowLevelWrapper& InCtx, struct FString InText, enum class ELimNativeSupportedLanguage InLang, struct FString ExtraInfo); // Offset: 0x1013f8a3c // Return & Params: Num(4) Size(0x38)

	// Object Name: Function LimNative.LimNativeLowLevel.SetMsgState
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void SetMsgState(struct FLimNativeLowLevelWrapper& InCtx, struct FString InMsgParams); // Offset: 0x1013fcda8 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function LimNative.LimNativeLowLevel.SetMsgRead
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void SetMsgRead(struct FLimNativeLowLevelWrapper& InCtx, struct FString InConvID, enum class ELimNativeConvType InConvType, struct FString InMsgID, struct FString InExtra); // Offset: 0x1013fced4 // Return & Params: Num(5) Size(0x48)

	// Object Name: Function LimNative.LimNativeLowLevel.SetLogHandler
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void SetLogHandler(struct FLimNativeLowLevelWrapper& InCtx); // Offset: 0x1013fe1c8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LimNative.LimNativeLowLevel.SetGroupAttr
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void SetGroupAttr(struct FLimNativeLowLevelWrapper& InCtx, struct FString InGroupID, struct FString InKey, struct FString InValue); // Offset: 0x1013fab08 // Return & Params: Num(4) Size(0x40)

	// Object Name: Function LimNative.LimNativeLowLevel.SetGroup
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void SetGroup(struct FLimNativeLowLevelWrapper& InCtx, struct FString InGroupID, struct FString InGroupName, struct FString InExtra); // Offset: 0x1013fb154 // Return & Params: Num(4) Size(0x40)

	// Object Name: Function LimNative.LimNativeLowLevel.SetEventHandler
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void SetEventHandler(struct FLimNativeLowLevelWrapper& InCtx); // Offset: 0x1013fe2a4 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LimNative.LimNativeLowLevel.SetConvSticky
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void SetConvSticky(struct FLimNativeLowLevelWrapper& InCtx, struct FString InConvID, enum class ELimNativeConvType InConvType, bool bSticky); // Offset: 0x1013fc204 // Return & Params: Num(4) Size(0x22)

	// Object Name: Function LimNative.LimNativeLowLevel.SetConvRead
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void SetConvRead(struct FLimNativeLowLevelWrapper& InCtx, struct FString InConvID, enum class ELimNativeConvType InConvType, struct FString InMsgID, struct FString InExtra); // Offset: 0x1013fc3d0 // Return & Params: Num(5) Size(0x48)

	// Object Name: Function LimNative.LimNativeLowLevel.SetConvMute
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void SetConvMute(struct FLimNativeLowLevelWrapper& InCtx, struct FString InConvID, enum class ELimNativeConvType InConvType, bool bMute); // Offset: 0x1013fc038 // Return & Params: Num(4) Size(0x22)

	// Object Name: Function LimNative.LimNativeLowLevel.SetConvAttr
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void SetConvAttr(struct FLimNativeLowLevelWrapper& InCtx, struct FString InConvID, enum class ELimNativeConvType InConvType, struct FString InKey, struct FString InValue); // Offset: 0x1013fbac8 // Return & Params: Num(5) Size(0x48)

	// Object Name: Function LimNative.LimNativeLowLevel.SetAllConfigs
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void SetAllConfigs(struct FLimNativeLowLevelWrapper& InCtx, struct FString InJsonString); // Offset: 0x1013fdf70 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function LimNative.LimNativeLowLevel.SendMsg
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void SendMsg(struct FLimNativeLowLevelWrapper& InCtx, struct FString InMsg); // Offset: 0x1013fd6c4 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function LimNative.LimNativeLowLevel.RevokeMsg
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void RevokeMsg(struct FLimNativeLowLevelWrapper& InCtx, struct FString InMsg); // Offset: 0x1013fd598 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function LimNative.LimNativeLowLevel.Resume
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void Resume(struct FLimNativeLowLevelWrapper& InCtx); // Offset: 0x1013fd7f0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LimNative.LimNativeLowLevel.ReportMsg
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void ReportMsg(struct FLimNativeLowLevelWrapper& InCtx, struct FString InMsg); // Offset: 0x1013f8c0c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function LimNative.LimNativeLowLevel.RemoveGroupMember
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void RemoveGroupMember(struct FLimNativeLowLevelWrapper& InCtx, struct FString InGroupID, struct FString InMemberID); // Offset: 0x1013fa464 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function LimNative.LimNativeLowLevel.RemoveFromBlockee
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void RemoveFromBlockee(struct FLimNativeLowLevelWrapper& InCtx, struct FString InUserId); // Offset: 0x1013f94e0 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function LimNative.LimNativeLowLevel.RemoveFriend
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void RemoveFriend(struct FLimNativeLowLevelWrapper& InCtx, struct FString InUserId, struct FString InExtra); // Offset: 0x1013fa120 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function LimNative.LimNativeLowLevel.RefuseFriendRequest
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void RefuseFriendRequest(struct FLimNativeLowLevelWrapper& InCtx, struct FString InRequestID, struct FString InExtra); // Offset: 0x1013f9ad4 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function LimNative.LimNativeLowLevel.QuitGroup
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void QuitGroup(struct FLimNativeLowLevelWrapper& InCtx, struct FString InGroupID); // Offset: 0x1013fb588 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function LimNative.LimNativeLowLevel.Pause
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void Pause(struct FLimNativeLowLevelWrapper& InCtx); // Offset: 0x1013fd8cc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LimNative.LimNativeLowLevel.Logout
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void Logout(struct FLimNativeLowLevelWrapper& InCtx); // Offset: 0x1013fd9a8 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LimNative.LimNativeLowLevel.LoginV2
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void LoginV2(struct FLimNativeLowLevelWrapper& InCtx, struct FString InEnv, struct FString InRoleID); // Offset: 0x1013fda84 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function LimNative.LimNativeLowLevel.Login
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void Login(struct FLimNativeLowLevelWrapper& InCtx, struct FString InAppId, struct FString InAppUserID, struct FString InToken, struct FString InRoleID, struct FString InExtra); // Offset: 0x1013fdc08 // Return & Params: Num(6) Size(0x60)

	// Object Name: DelegateFunction LimNative.LimNativeLowLevel.LIMResultDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void LIMResultDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FString InData); // Offset: 0x103938968 // Return & Params: Num(2) Size(0x20)

	// Object Name: DelegateFunction LimNative.LimNativeLowLevel.LIMLogDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void LIMLogDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FString InData); // Offset: 0x103938968 // Return & Params: Num(2) Size(0x20)

	// Object Name: DelegateFunction LimNative.LimNativeLowLevel.LIMEventDynamicDelegate__DelegateSignature
	// Flags: [MulticastDelegate|Public|Delegate|HasOutParms]
	void LIMEventDynamicDelegate__DelegateSignature(struct FLimNativeLowLevelWrapper& InWrapper, struct FString InData); // Offset: 0x103938968 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function LimNative.LimNativeLowLevel.JoinGroup
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void JoinGroup(struct FLimNativeLowLevelWrapper& InCtx, struct FString InGroupID); // Offset: 0x1013fb6b4 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function LimNative.LimNativeLowLevel.GetUsersState
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetUsersState(struct FLimNativeLowLevelWrapper& InCtx, struct TArray<struct FString>& InUserIDs); // Offset: 0x1013f8ff0 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function LimNative.LimNativeLowLevel.GetUsers
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetUsers(struct FLimNativeLowLevelWrapper& InCtx, struct FString InUserIDs); // Offset: 0x1013f915c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function LimNative.LimNativeLowLevel.GetUser
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetUser(struct FLimNativeLowLevelWrapper& InCtx, struct FString InUserId); // Offset: 0x1013f9288 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function LimNative.LimNativeLowLevel.GetOssToken
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetOssToken(struct FLimNativeLowLevelWrapper& InCtx); // Offset: 0x1013f8f14 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LimNative.LimNativeLowLevel.GetMsgsV2
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetMsgsV2(struct FLimNativeLowLevelWrapper& InCtx, struct FString InConvID, enum class ELimNativeConvType InConvType, struct FString InFromMsgID, struct FString InToMsgID); // Offset: 0x1013fd0fc // Return & Params: Num(5) Size(0x48)

	// Object Name: Function LimNative.LimNativeLowLevel.GetMsgs
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetMsgs(struct FLimNativeLowLevelWrapper& InCtx, struct FString InConvID, enum class ELimNativeConvType InConvType, enum class ELimNativeMsgDirType InDir, struct FString InMsgID, struct FString InExtra); // Offset: 0x1013fd324 // Return & Params: Num(6) Size(0x48)

	// Object Name: Function LimNative.LimNativeLowLevel.GetMiscConfigInfo
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetMiscConfigInfo(struct FLimNativeLowLevelWrapper& InCtx); // Offset: 0x1013f8834 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LimNative.LimNativeLowLevel.GetLIMVersion
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FString GetLIMVersion(); // Offset: 0x1013fe380 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LimNative.LimNativeLowLevel.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct ULimNativeLowLevel* GetInstance(); // Offset: 0x1013fe578 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function LimNative.LimNativeLowLevel.GetGroups
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetGroups(struct FLimNativeLowLevelWrapper& InCtx, int32_t InTag, int32_t InSize, struct FString InExtra); // Offset: 0x1013faf94 // Return & Params: Num(4) Size(0x28)

	// Object Name: Function LimNative.LimNativeLowLevel.GetGroupMembers
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetGroupMembers(struct FLimNativeLowLevelWrapper& InCtx, struct FString InGroupID, int32_t InTag, int32_t InSize, struct FString InExtra); // Offset: 0x1013fa8f0 // Return & Params: Num(5) Size(0x38)

	// Object Name: Function LimNative.LimNativeLowLevel.GetGroupMember
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetGroupMember(struct FLimNativeLowLevelWrapper& InCtx, struct FString InGroupID, struct FString InMemberID); // Offset: 0x1013fa76c // Return & Params: Num(3) Size(0x30)

	// Object Name: Function LimNative.LimNativeLowLevel.GetGroupAttr
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetGroupAttr(struct FLimNativeLowLevelWrapper& InCtx, struct FString InGroupID, struct FString InKey); // Offset: 0x1013fae10 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function LimNative.LimNativeLowLevel.GetGroupAllAttrs
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetGroupAllAttrs(struct FLimNativeLowLevelWrapper& InCtx, struct FString InGroupID); // Offset: 0x1013face4 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function LimNative.LimNativeLowLevel.GetGroup
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetGroup(struct FLimNativeLowLevelWrapper& InCtx, struct FString InGroupID); // Offset: 0x1013fb330 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function LimNative.LimNativeLowLevel.GetGMEToken
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetGMEToken(struct FLimNativeLowLevelWrapper& InCtx, struct FString InAppId, struct FString InUserId, struct FString InRoomId); // Offset: 0x1013f8d38 // Return & Params: Num(4) Size(0x40)

	// Object Name: Function LimNative.LimNativeLowLevel.GetFriends
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetFriends(struct FLimNativeLowLevelWrapper& InCtx, int32_t InTag, int32_t InSize, struct FString InExtra); // Offset: 0x1013fa2a4 // Return & Params: Num(4) Size(0x28)

	// Object Name: Function LimNative.LimNativeLowLevel.GetFriendRequests
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetFriendRequests(struct FLimNativeLowLevelWrapper& InCtx, int32_t InTag, int32_t InSize, struct FString InExtra); // Offset: 0x1013f9f60 // Return & Params: Num(4) Size(0x28)

	// Object Name: Function LimNative.LimNativeLowLevel.GetConvs
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetConvs(struct FLimNativeLowLevelWrapper& InCtx, int32_t InSize, struct FString InExtra); // Offset: 0x1013fc770 // Return & Params: Num(3) Size(0x28)

	// Object Name: Function LimNative.LimNativeLowLevel.GetConvChatLevelConfig
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetConvChatLevelConfig(struct FLimNativeLowLevelWrapper& InCtx); // Offset: 0x1013f867c // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LimNative.LimNativeLowLevel.GetConvAttr
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetConvAttr(struct FLimNativeLowLevelWrapper& InCtx, struct FString InConvID, enum class ELimNativeConvType InConvType, struct FString InKey); // Offset: 0x1013fbe68 // Return & Params: Num(4) Size(0x38)

	// Object Name: Function LimNative.LimNativeLowLevel.GetConvAllAttrs
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetConvAllAttrs(struct FLimNativeLowLevelWrapper& InCtx, struct FString InConvID, enum class ELimNativeConvType InConvType); // Offset: 0x1013fbcf0 // Return & Params: Num(3) Size(0x21)

	// Object Name: Function LimNative.LimNativeLowLevel.GetConv
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetConv(struct FLimNativeLowLevelWrapper& InCtx, struct FString InConvID, enum class ELimNativeConvType InConvType); // Offset: 0x1013fc5f8 // Return & Params: Num(3) Size(0x21)

	// Object Name: Function LimNative.LimNativeLowLevel.GetConnState
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetConnState(struct FLimNativeLowLevelWrapper& InCtx); // Offset: 0x1013f8758 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LimNative.LimNativeLowLevel.GetBlockees
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetBlockees(struct FLimNativeLowLevelWrapper& InCtx, int32_t InTag, int32_t InSize, struct FString InExtra); // Offset: 0x1013f9738 // Return & Params: Num(4) Size(0x28)

	// Object Name: Function LimNative.LimNativeLowLevel.GetAllConfigs
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void GetAllConfigs(struct FLimNativeLowLevelWrapper& InCtx); // Offset: 0x1013fde94 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function LimNative.LimNativeLowLevel.DestroyGroup
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void DestroyGroup(struct FLimNativeLowLevelWrapper& InCtx, struct FString InGroupID); // Offset: 0x1013fb45c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function LimNative.LimNativeLowLevel.DestroyConv
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void DestroyConv(struct FLimNativeLowLevelWrapper& InCtx, struct FString InConvID, enum class ELimNativeConvType InConvType); // Offset: 0x1013fca60 // Return & Params: Num(3) Size(0x21)

	// Object Name: Function LimNative.LimNativeLowLevel.DestoryInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void DestoryInstance(); // Offset: 0x1013fe564 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function LimNative.LimNativeLowLevel.CreateLIM
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct FLimNativeLowLevelWrapper CreateLIM(struct FString InServerEnvID); // Offset: 0x1013fe400 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function LimNative.LimNativeLowLevel.CreateGroup
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void CreateGroup(struct FLimNativeLowLevelWrapper& InCtx, struct TArray<struct FString> InMembers, struct FString InGroupName, struct FString InExtra); // Offset: 0x1013fb7e0 // Return & Params: Num(4) Size(0x40)

	// Object Name: Function LimNative.LimNativeLowLevel.CreateFriendRequest
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void CreateFriendRequest(struct FLimNativeLowLevelWrapper& InCtx, struct FString InUserId, struct FString InExtra); // Offset: 0x1013f9ddc // Return & Params: Num(3) Size(0x30)

	// Object Name: Function LimNative.LimNativeLowLevel.CreateConv
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void CreateConv(struct FLimNativeLowLevelWrapper& InCtx, struct FString InConvID, enum class ELimNativeConvType InConvType, struct FString InExtra); // Offset: 0x1013fcbd8 // Return & Params: Num(4) Size(0x38)

	// Object Name: Function LimNative.LimNativeLowLevel.ClearConv
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void ClearConv(struct FLimNativeLowLevelWrapper& InCtx, struct FString InConvID, enum class ELimNativeConvType InConvType); // Offset: 0x1013fc8e8 // Return & Params: Num(3) Size(0x21)

	// Object Name: Function LimNative.LimNativeLowLevel.CheckImage
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void CheckImage(struct FLimNativeLowLevelWrapper& InCtx, struct FString InUrl); // Offset: 0x1013f8910 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function LimNative.LimNativeLowLevel.CancelFriendRequest
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void CancelFriendRequest(struct FLimNativeLowLevelWrapper& InCtx, struct FString InUserId, struct FString InRequestID, struct FString InExtra); // Offset: 0x1013f98f8 // Return & Params: Num(4) Size(0x40)

	// Object Name: Function LimNative.LimNativeLowLevel.Call
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void Call(struct FLimNativeLowLevelWrapper& InCtx, struct FString InJsonString); // Offset: 0x1013fe09c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function LimNative.LimNativeLowLevel.BlockeeExists
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void BlockeeExists(struct FLimNativeLowLevelWrapper& InCtx, struct FString InUserId); // Offset: 0x1013f93b4 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function LimNative.LimNativeLowLevel.AddToBlockee
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void AddToBlockee(struct FLimNativeLowLevelWrapper& InCtx, struct FString InUserId); // Offset: 0x1013f960c // Return & Params: Num(2) Size(0x20)

	// Object Name: Function LimNative.LimNativeLowLevel.AddGroupMember
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void AddGroupMember(struct FLimNativeLowLevelWrapper& InCtx, struct FString InGroupID, struct FString InMemberID); // Offset: 0x1013fa5e8 // Return & Params: Num(3) Size(0x30)

	// Object Name: Function LimNative.LimNativeLowLevel.AcceptFriendRequest
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable]
	void AcceptFriendRequest(struct FLimNativeLowLevelWrapper& InCtx, struct FString InRequestID, struct FString InExtra); // Offset: 0x1013f9c58 // Return & Params: Num(3) Size(0x30)
};

