#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct LimNative.LimNativeLowLevelWrapper
// Size: 0x10 // Inherited bytes: 0x00
struct FLimNativeLowLevelWrapper {
	// Fields
	char pad_0x0[0x10]; // Offset: 0x00 // Size: 0x10
};

// Object Name: ScriptStruct LimNative.LimNativeDataObjectBase
// Size: 0x08 // Inherited bytes: 0x00
struct FLimNativeDataObjectBase {
	// Fields
	char pad_0x0[0x8]; // Offset: 0x00 // Size: 0x08
};

// Object Name: ScriptStruct LimNative.UidList
// Size: 0x18 // Inherited bytes: 0x08
struct FUidList : FLimNativeDataObjectBase {
	// Fields
	struct TArray<struct FString> Uids; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct LimNative.LimNativeInitConfig
// Size: 0x78 // Inherited bytes: 0x08
struct FLimNativeInitConfig : FLimNativeDataObjectBase {
	// Fields
	enum class ELimNativeSupportedLanguage Lang; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x3]; // Offset: 0x09 // Size: 0x03
	int32_t Mode; // Offset: 0x0c // Size: 0x04
	struct FString EnvId; // Offset: 0x10 // Size: 0x10
	struct FString AppId; // Offset: 0x20 // Size: 0x10
	struct FString SDKRegion; // Offset: 0x30 // Size: 0x10
	int32_t GameID; // Offset: 0x40 // Size: 0x04
	char pad_0x44[0x4]; // Offset: 0x44 // Size: 0x04
	struct FString SlsSvr; // Offset: 0x48 // Size: 0x10
	int32_t FarlightDomain; // Offset: 0x58 // Size: 0x04
	char pad_0x5C[0x4]; // Offset: 0x5c // Size: 0x04
	struct FString ParkEnvID; // Offset: 0x60 // Size: 0x10
	int32_t Timeout; // Offset: 0x70 // Size: 0x04
	int32_t UseHttps; // Offset: 0x74 // Size: 0x04
};

// Object Name: ScriptStruct LimNative.LimNativeDataCallBackBase
// Size: 0x30 // Inherited bytes: 0x08
struct FLimNativeDataCallBackBase : FLimNativeDataObjectBase {
	// Fields
	struct FString FuncName; // Offset: 0x08 // Size: 0x10
	enum class ELimNativeErrorType ErrorCode; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x3]; // Offset: 0x19 // Size: 0x03
	int32_t Code; // Offset: 0x1c // Size: 0x04
	struct FString Message; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct LimNative.LimNativeFriendCommonCallBack
// Size: 0x58 // Inherited bytes: 0x30
struct FLimNativeFriendCommonCallBack : FLimNativeDataCallBackBase {
	// Fields
	struct FLimNativeDataCallBackDataBase ResultData; // Offset: 0x30 // Size: 0x28
};

// Object Name: ScriptStruct LimNative.LimNativeDataCallBackDataBase
// Size: 0x28 // Inherited bytes: 0x08
struct FLimNativeDataCallBackDataBase : FLimNativeDataObjectBase {
	// Fields
	struct FLimNativeResult ResultData; // Offset: 0x08 // Size: 0x20
};

// Object Name: ScriptStruct LimNative.LimNativeResult
// Size: 0x20 // Inherited bytes: 0x08
struct FLimNativeResult : FLimNativeDataObjectBase {
	// Fields
	int32_t ErrCode; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct FString ErrMsg; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct LimNative.LimNativeOnGroupMemberAddCallBack
// Size: 0x98 // Inherited bytes: 0x30
struct FLimNativeOnGroupMemberAddCallBack : FLimNativeDataCallBackBase {
	// Fields
	struct FLimNativeIMGroup Data; // Offset: 0x30 // Size: 0x68
};

// Object Name: ScriptStruct LimNative.LimNativeIMGroupBrief
// Size: 0x38 // Inherited bytes: 0x08
struct FLimNativeIMGroupBrief : FLimNativeDataObjectBase {
	// Fields
	struct FString ChannelId; // Offset: 0x08 // Size: 0x10
	struct FString Name; // Offset: 0x18 // Size: 0x10
	struct FString Extra; // Offset: 0x28 // Size: 0x10
};

// Object Name: ScriptStruct LimNative.LimNativeIMGroup
// Size: 0x68 // Inherited bytes: 0x38
struct FLimNativeIMGroup : FLimNativeIMGroupBrief {
	// Fields
	struct FString GameID; // Offset: 0x38 // Size: 0x10
	struct FString Uid; // Offset: 0x48 // Size: 0x10
	struct TArray<struct FLimNativeIMChannelMember> members; // Offset: 0x58 // Size: 0x10
};

// Object Name: ScriptStruct LimNative.LimNativeIMChannelMember
// Size: 0x38 // Inherited bytes: 0x08
struct FLimNativeIMChannelMember : FLimNativeDataObjectBase {
	// Fields
	struct FString ChannelId; // Offset: 0x08 // Size: 0x10
	struct FString Uid; // Offset: 0x18 // Size: 0x10
	struct FString Role; // Offset: 0x28 // Size: 0x10
};

// Object Name: ScriptStruct LimNative.LimNativeOnConvHandleCallBack
// Size: 0x68 // Inherited bytes: 0x30
struct FLimNativeOnConvHandleCallBack : FLimNativeDataCallBackBase {
	// Fields
	struct FLimNativeConvHandleCallBackData Data; // Offset: 0x30 // Size: 0x38
};

// Object Name: ScriptStruct LimNative.LimNativeConvHandleCallBackData
// Size: 0x38 // Inherited bytes: 0x08
struct FLimNativeConvHandleCallBackData : FLimNativeDataObjectBase {
	// Fields
	struct FLimNativeResult Result; // Offset: 0x08 // Size: 0x20
	struct FString Msg; // Offset: 0x28 // Size: 0x10
};

// Object Name: ScriptStruct LimNative.LimNativeOnConvsGetCallBack
// Size: 0x48 // Inherited bytes: 0x30
struct FLimNativeOnConvsGetCallBack : FLimNativeDataCallBackBase {
	// Fields
	struct FLimNativeOnConvsGetCallBackData Data; // Offset: 0x30 // Size: 0x18
};

// Object Name: ScriptStruct LimNative.LimNativeOnConvsGetCallBackData
// Size: 0x18 // Inherited bytes: 0x08
struct FLimNativeOnConvsGetCallBackData : FLimNativeDataObjectBase {
	// Fields
	struct TArray<struct FLimNativeConversationData> ConvList; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct LimNative.LimNativeConversationData
// Size: 0xb0 // Inherited bytes: 0x08
struct FLimNativeConversationData : FLimNativeDataObjectBase {
	// Fields
	struct FString ConvID; // Offset: 0x08 // Size: 0x10
	enum class ELimNativeConvType ConvType; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x3]; // Offset: 0x19 // Size: 0x03
	int32_t SubType; // Offset: 0x1c // Size: 0x04
	struct FString Name; // Offset: 0x20 // Size: 0x10
	struct FString Avatar; // Offset: 0x30 // Size: 0x10
	int32_t UnreadCount; // Offset: 0x40 // Size: 0x04
	char pad_0x44[0x4]; // Offset: 0x44 // Size: 0x04
	struct FString LastMsgId; // Offset: 0x48 // Size: 0x10
	enum class ELimNativeMsgContentType LastMsgType; // Offset: 0x58 // Size: 0x01
	char pad_0x59[0x7]; // Offset: 0x59 // Size: 0x07
	struct FString LastMsgTs; // Offset: 0x60 // Size: 0x10
	struct FString LastReadMsgId; // Offset: 0x70 // Size: 0x10
	struct FString LastMsgContent; // Offset: 0x80 // Size: 0x10
	struct FString BaseMsgId; // Offset: 0x90 // Size: 0x10
	struct FString Flags; // Offset: 0xa0 // Size: 0x10
};

// Object Name: ScriptStruct LimNative.LimNativeOnCreateFriendRequestCallBack
// Size: 0x68 // Inherited bytes: 0x30
struct FLimNativeOnCreateFriendRequestCallBack : FLimNativeDataCallBackBase {
	// Fields
	struct FCreateFriendRequestData FriendRequestCallBackData; // Offset: 0x30 // Size: 0x38
};

// Object Name: ScriptStruct LimNative.CreateFriendRequestData
// Size: 0x38 // Inherited bytes: 0x28
struct FCreateFriendRequestData : FLimNativeDataCallBackDataBase {
	// Fields
	struct FString RequestID; // Offset: 0x28 // Size: 0x10
};

// Object Name: ScriptStruct LimNative.LimNativeOnCreateGroupCallBack
// Size: 0x98 // Inherited bytes: 0x30
struct FLimNativeOnCreateGroupCallBack : FLimNativeDataCallBackBase {
	// Fields
	struct FLimNativeIMGroup Data; // Offset: 0x30 // Size: 0x68
};

// Object Name: ScriptStruct LimNative.LimNativeOnGroupDestoryCallBack
// Size: 0x30 // Inherited bytes: 0x30
struct FLimNativeOnGroupDestoryCallBack : FLimNativeDataCallBackBase {
};

// Object Name: ScriptStruct LimNative.LimNativeOnGroupAttrGetAllCallBack
// Size: 0x30 // Inherited bytes: 0x30
struct FLimNativeOnGroupAttrGetAllCallBack : FLimNativeDataCallBackBase {
};

// Object Name: ScriptStruct LimNative.LimNativeOnGetBlockeesCallBack
// Size: 0x68 // Inherited bytes: 0x30
struct FLimNativeOnGetBlockeesCallBack : FLimNativeDataCallBackBase {
	// Fields
	struct FGetBlockeesData Data; // Offset: 0x30 // Size: 0x38
};

// Object Name: ScriptStruct LimNative.GetBlockeesData
// Size: 0x38 // Inherited bytes: 0x28
struct FGetBlockeesData : FLimNativeDataCallBackDataBase {
	// Fields
	struct TArray<struct FLimUserInfo> UserInfoList; // Offset: 0x28 // Size: 0x10
};

// Object Name: ScriptStruct LimNative.LimUserInfo
// Size: 0x38 // Inherited bytes: 0x08
struct FLimUserInfo : FLimNativeDataObjectBase {
	// Fields
	struct FString Uid; // Offset: 0x08 // Size: 0x10
	struct FString NickName; // Offset: 0x18 // Size: 0x10
	struct FString AvatarUrl; // Offset: 0x28 // Size: 0x10
};

// Object Name: ScriptStruct LimNative.LimNativeOnGetCommonMsgsCallBack
// Size: 0x68 // Inherited bytes: 0x30
struct FLimNativeOnGetCommonMsgsCallBack : FLimNativeDataCallBackBase {
	// Fields
	struct FLimNativeGetCommonCallBackData Data; // Offset: 0x30 // Size: 0x38
};

// Object Name: ScriptStruct LimNative.LimNativeGetCommonCallBackData
// Size: 0x38 // Inherited bytes: 0x08
struct FLimNativeGetCommonCallBackData : FLimNativeDataObjectBase {
	// Fields
	struct TArray<struct FLimNativeCommonMsg> CommonMessages; // Offset: 0x08 // Size: 0x10
	struct FLimNativeResult Result; // Offset: 0x18 // Size: 0x20
};

// Object Name: ScriptStruct LimNative.LimNativeCommonMsg
// Size: 0x60 // Inherited bytes: 0x08
struct FLimNativeCommonMsg : FLimNativeDataObjectBase {
	// Fields
	struct FString ServerMsgId; // Offset: 0x08 // Size: 0x10
	struct FString TargetId; // Offset: 0x18 // Size: 0x10
	int32_t TargetType; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
	struct FLimNativeCommonMsgData Data; // Offset: 0x30 // Size: 0x20
	struct FString Timestamp; // Offset: 0x50 // Size: 0x10
};

// Object Name: ScriptStruct LimNative.LimNativeCommonMsgData
// Size: 0x20 // Inherited bytes: 0x08
struct FLimNativeCommonMsgData : FLimNativeDataObjectBase {
	// Fields
	int32_t Type; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x14]; // Offset: 0x0c // Size: 0x14
};

// Object Name: ScriptStruct LimNative.LimNativeOnGetConfigCallBack
// Size: 0x50 // Inherited bytes: 0x30
struct FLimNativeOnGetConfigCallBack : FLimNativeDataCallBackBase {
	// Fields
	struct FLimNativeIMConfig Data; // Offset: 0x30 // Size: 0x20
};

// Object Name: ScriptStruct LimNative.LimNativeIMConfig
// Size: 0x20 // Inherited bytes: 0x08
struct FLimNativeIMConfig : FLimNativeDataObjectBase {
	// Fields
	enum class ELimNativeSupportedLanguage Lang; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x7]; // Offset: 0x09 // Size: 0x07
	struct FString ResDir; // Offset: 0x10 // Size: 0x10
};

// Object Name: ScriptStruct LimNative.LimNativeGetConnStateCallBack
// Size: 0x40 // Inherited bytes: 0x30
struct FLimNativeGetConnStateCallBack : FLimNativeDataCallBackBase {
	// Fields
	struct FLimNativConnStateData Data; // Offset: 0x30 // Size: 0x10
};

// Object Name: ScriptStruct LimNative.LimNativConnStateData
// Size: 0x10 // Inherited bytes: 0x08
struct FLimNativConnStateData : FLimNativeDataObjectBase {
	// Fields
	int32_t Connect_State; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct LimNative.LimNativeOnGetConvChatLevelConfigCallBack
// Size: 0x40 // Inherited bytes: 0x30
struct FLimNativeOnGetConvChatLevelConfigCallBack : FLimNativeDataCallBackBase {
	// Fields
	struct TArray<struct FLimNativeConvChatLevelConfigData> DataList; // Offset: 0x30 // Size: 0x10
};

// Object Name: ScriptStruct LimNative.LimNativeConvChatLevelConfigData
// Size: 0x48 // Inherited bytes: 0x28
struct FLimNativeConvChatLevelConfigData : FLimNativeDataCallBackDataBase {
	// Fields
	enum class ELimNativeConvType ConvType; // Offset: 0x28 // Size: 0x01
	char pad_0x29[0x3]; // Offset: 0x29 // Size: 0x03
	int32_t Level; // Offset: 0x2c // Size: 0x04
	int32_t Interval; // Offset: 0x30 // Size: 0x04
	char pad_0x34[0x4]; // Offset: 0x34 // Size: 0x04
	struct TArray<struct FLimNativeConvNumLimitData> NumLimits; // Offset: 0x38 // Size: 0x10
};

// Object Name: ScriptStruct LimNative.LimNativeConvNumLimitData
// Size: 0x10 // Inherited bytes: 0x08
struct FLimNativeConvNumLimitData : FLimNativeDataObjectBase {
	// Fields
	int32_t Duration; // Offset: 0x08 // Size: 0x04
	int32_t Number; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct LimNative.LimNativeOnGetFriendRequestCallBack
// Size: 0x78 // Inherited bytes: 0x30
struct FLimNativeOnGetFriendRequestCallBack : FLimNativeDataCallBackBase {
	// Fields
	struct FGetFriendRequestData GetFriendRequestData; // Offset: 0x30 // Size: 0x48
};

// Object Name: ScriptStruct LimNative.GetFriendRequestData
// Size: 0x48 // Inherited bytes: 0x28
struct FGetFriendRequestData : FLimNativeDataCallBackDataBase {
	// Fields
	struct TArray<struct FSendFriendRequestData> SendRequests; // Offset: 0x28 // Size: 0x10
	struct TArray<struct FReceivedFriendRequestData> ReceiveRequests; // Offset: 0x38 // Size: 0x10
};

// Object Name: ScriptStruct LimNative.ReceivedFriendRequestData
// Size: 0x60 // Inherited bytes: 0x08
struct FReceivedFriendRequestData : FLimNativeDataObjectBase {
	// Fields
	struct FString RequestID; // Offset: 0x08 // Size: 0x10
	struct FString TargetId; // Offset: 0x18 // Size: 0x10
	struct FString NickName; // Offset: 0x28 // Size: 0x10
	struct FString AvatarUrl; // Offset: 0x38 // Size: 0x10
	struct FString Timestamp; // Offset: 0x48 // Size: 0x10
	bool IsOffLineRequest; // Offset: 0x58 // Size: 0x01
	char pad_0x59[0x7]; // Offset: 0x59 // Size: 0x07
};

// Object Name: ScriptStruct LimNative.SendFriendRequestData
// Size: 0x58 // Inherited bytes: 0x08
struct FSendFriendRequestData : FLimNativeDataObjectBase {
	// Fields
	struct FString RequestID; // Offset: 0x08 // Size: 0x10
	struct FString TargetId; // Offset: 0x18 // Size: 0x10
	struct FString NickName; // Offset: 0x28 // Size: 0x10
	struct FString AvatarUrl; // Offset: 0x38 // Size: 0x10
	struct FString Timestamp; // Offset: 0x48 // Size: 0x10
};

// Object Name: ScriptStruct LimNative.LimNativeOnGetFriendCallBack
// Size: 0x68 // Inherited bytes: 0x30
struct FLimNativeOnGetFriendCallBack : FLimNativeDataCallBackBase {
	// Fields
	struct FFriendInfoList FriendData; // Offset: 0x30 // Size: 0x38
};

// Object Name: ScriptStruct LimNative.FriendInfoList
// Size: 0x38 // Inherited bytes: 0x28
struct FFriendInfoList : FLimNativeDataCallBackDataBase {
	// Fields
	struct TArray<struct FFriendInfo> FriendList; // Offset: 0x28 // Size: 0x10
};

// Object Name: ScriptStruct LimNative.FriendInfo
// Size: 0x1d0 // Inherited bytes: 0x08
struct FFriendInfo : FLimNativeDataObjectBase {
	// Fields
	struct FString Uid; // Offset: 0x08 // Size: 0x10
	struct FString NickName; // Offset: 0x18 // Size: 0x10
	struct FString AvatarUrl; // Offset: 0x28 // Size: 0x10
	enum class ELimNativeUserSexType Sex; // Offset: 0x38 // Size: 0x01
	char pad_0x39[0x7]; // Offset: 0x39 // Size: 0x07
	struct FGuild Guild; // Offset: 0x40 // Size: 0x48
	struct FKingdom Kingdom; // Offset: 0x88 // Size: 0x48
	struct TArray<struct FSubTitleItem> SubTitleList; // Offset: 0xd0 // Size: 0x10
	struct FString BadgeUrl; // Offset: 0xe0 // Size: 0x10
	struct FString AvatarFrameUrl; // Offset: 0xf0 // Size: 0x10
	struct FBubbleConfigs BubbleConfigs; // Offset: 0x100 // Size: 0xa8
	int32_t VipLevel; // Offset: 0x1a8 // Size: 0x04
	bool IsShowVip; // Offset: 0x1ac // Size: 0x01
	char pad_0x1AD[0x3]; // Offset: 0x1ad // Size: 0x03
	int32_t ServerTime; // Offset: 0x1b0 // Size: 0x04
	int32_t LastFetchTime; // Offset: 0x1b4 // Size: 0x04
	struct FPresence Presence; // Offset: 0x1b8 // Size: 0x18
};

// Object Name: ScriptStruct LimNative.Presence
// Size: 0x18 // Inherited bytes: 0x08
struct FPresence : FLimNativeDataObjectBase {
	// Fields
	bool IsOnline; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x3]; // Offset: 0x09 // Size: 0x03
	int32_t TeamID; // Offset: 0x0c // Size: 0x04
	int32_t TeamStatus; // Offset: 0x10 // Size: 0x04
	bool IsInMyTeam; // Offset: 0x14 // Size: 0x01
	enum class ELimNativeFriendStateType FriendState; // Offset: 0x15 // Size: 0x01
	char pad_0x16[0x2]; // Offset: 0x16 // Size: 0x02
};

// Object Name: ScriptStruct LimNative.BubbleConfigs
// Size: 0xa8 // Inherited bytes: 0x08
struct FBubbleConfigs : FLimNativeDataObjectBase {
	// Fields
	struct FBubbleConfig LeftNormal; // Offset: 0x08 // Size: 0x28
	struct FBubbleConfig LeftPressed; // Offset: 0x30 // Size: 0x28
	struct FBubbleConfig RightNormal; // Offset: 0x58 // Size: 0x28
	struct FBubbleConfig RightPressed; // Offset: 0x80 // Size: 0x28
};

// Object Name: ScriptStruct LimNative.BubbleConfig
// Size: 0x28 // Inherited bytes: 0x08
struct FBubbleConfig : FLimNativeDataObjectBase {
	// Fields
	struct FString URL; // Offset: 0x08 // Size: 0x10
	float Top; // Offset: 0x18 // Size: 0x04
	float Left; // Offset: 0x1c // Size: 0x04
	float Bottom; // Offset: 0x20 // Size: 0x04
	float Right; // Offset: 0x24 // Size: 0x04
};

// Object Name: ScriptStruct LimNative.SubTitleItem
// Size: 0x38 // Inherited bytes: 0x08
struct FSubTitleItem : FLimNativeDataObjectBase {
	// Fields
	struct FString Key; // Offset: 0x08 // Size: 0x10
	struct FString Content; // Offset: 0x18 // Size: 0x10
	struct FString BGUrl; // Offset: 0x28 // Size: 0x10
};

// Object Name: ScriptStruct LimNative.Kingdom
// Size: 0x48 // Inherited bytes: 0x08
struct FKingdom : FLimNativeDataObjectBase {
	// Fields
	struct FString StoryId; // Offset: 0x08 // Size: 0x10
	struct FString KingdomId; // Offset: 0x18 // Size: 0x10
	struct FString Name; // Offset: 0x28 // Size: 0x10
	struct FString AvatarUrl; // Offset: 0x38 // Size: 0x10
};

// Object Name: ScriptStruct LimNative.Guild
// Size: 0x48 // Inherited bytes: 0x08
struct FGuild : FLimNativeDataObjectBase {
	// Fields
	struct FString ID; // Offset: 0x08 // Size: 0x10
	struct FString Name; // Offset: 0x18 // Size: 0x10
	struct FString AvatarUrl; // Offset: 0x28 // Size: 0x10
	struct FString AbbrName; // Offset: 0x38 // Size: 0x10
};

// Object Name: ScriptStruct LimNative.LimNativeGetGMETokenCallBack
// Size: 0x68 // Inherited bytes: 0x30
struct FLimNativeGetGMETokenCallBack : FLimNativeDataCallBackBase {
	// Fields
	struct FLimNativeGetGMETokenData Data; // Offset: 0x30 // Size: 0x38
};

// Object Name: ScriptStruct LimNative.LimNativeGetGMETokenData
// Size: 0x38 // Inherited bytes: 0x28
struct FLimNativeGetGMETokenData : FLimNativeDataCallBackDataBase {
	// Fields
	struct TArray<char> AuthBuffer; // Offset: 0x28 // Size: 0x10
};

// Object Name: ScriptStruct LimNative.LimNativeOnGroupAttrGetCallBack
// Size: 0x30 // Inherited bytes: 0x30
struct FLimNativeOnGroupAttrGetCallBack : FLimNativeDataCallBackBase {
};

// Object Name: ScriptStruct LimNative.LimNativeOnGroupGetCallBack
// Size: 0x98 // Inherited bytes: 0x30
struct FLimNativeOnGroupGetCallBack : FLimNativeDataCallBackBase {
	// Fields
	struct FLimNativeIMGroup Data; // Offset: 0x30 // Size: 0x68
};

// Object Name: ScriptStruct LimNative.LimNativeOnGroupMemberGetCallBack
// Size: 0x30 // Inherited bytes: 0x30
struct FLimNativeOnGroupMemberGetCallBack : FLimNativeDataCallBackBase {
};

// Object Name: ScriptStruct LimNative.LimNativeOnGroupMembersGetCallBack
// Size: 0x98 // Inherited bytes: 0x30
struct FLimNativeOnGroupMembersGetCallBack : FLimNativeDataCallBackBase {
	// Fields
	struct FLimNativeIMGroup Data; // Offset: 0x30 // Size: 0x68
};

// Object Name: ScriptStruct LimNative.LimNativeOnGroupsGetCallBack
// Size: 0x50 // Inherited bytes: 0x30
struct FLimNativeOnGroupsGetCallBack : FLimNativeDataCallBackBase {
	// Fields
	struct FString GameID; // Offset: 0x30 // Size: 0x10
	struct TArray<struct FLimNativeIMGroupBrief> Channels; // Offset: 0x40 // Size: 0x10
};

// Object Name: ScriptStruct LimNative.LimNativeGetMiscConfigInfoCallBack
// Size: 0x70 // Inherited bytes: 0x30
struct FLimNativeGetMiscConfigInfoCallBack : FLimNativeDataCallBackBase {
	// Fields
	struct FLimNativeGetConfigInfoData Data; // Offset: 0x30 // Size: 0x40
};

// Object Name: ScriptStruct LimNative.LimNativeGetConfigInfoData
// Size: 0x40 // Inherited bytes: 0x28
struct FLimNativeGetConfigInfoData : FLimNativeDataCallBackDataBase {
	// Fields
	struct FLimNativConfigInfoData Data; // Offset: 0x28 // Size: 0x10
	int32_t ResultCode; // Offset: 0x38 // Size: 0x04
	char pad_0x3C[0x4]; // Offset: 0x3c // Size: 0x04
};

// Object Name: ScriptStruct LimNative.LimNativConfigInfoData
// Size: 0x10 // Inherited bytes: 0x08
struct FLimNativConfigInfoData : FLimNativeDataObjectBase {
	// Fields
	int32_t Interval; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
};

// Object Name: ScriptStruct LimNative.LimNativeOnGetMsgsCallBack
// Size: 0x48 // Inherited bytes: 0x30
struct FLimNativeOnGetMsgsCallBack : FLimNativeDataCallBackBase {
	// Fields
	struct FLimNativeMsgConvData Data; // Offset: 0x30 // Size: 0x18
};

// Object Name: ScriptStruct LimNative.LimNativeMsgConvData
// Size: 0x18 // Inherited bytes: 0x08
struct FLimNativeMsgConvData : FLimNativeDataObjectBase {
	// Fields
	struct TArray<struct FLimNativeMsgConvListData> MsgConvList; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct LimNative.LimNativeMsgConvListData
// Size: 0x30 // Inherited bytes: 0x08
struct FLimNativeMsgConvListData : FLimNativeDataObjectBase {
	// Fields
	struct FString ConvID; // Offset: 0x08 // Size: 0x10
	enum class ELimNativeConvType ConvType; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x7]; // Offset: 0x19 // Size: 0x07
	struct TArray<struct FLimNativeMsgListData> MsgList; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct LimNative.LimNativeOnChatMsgCallBackData
// Size: 0x90 // Inherited bytes: 0x08
struct FLimNativeOnChatMsgCallBackData : FLimNativeDataObjectBase {
	// Fields
	struct FString MsgId; // Offset: 0x08 // Size: 0x10
	enum class ELimNativeMsgState State; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x7]; // Offset: 0x19 // Size: 0x07
	struct FLimNativeIMChatMessage Msg; // Offset: 0x20 // Size: 0x70
};

// Object Name: ScriptStruct LimNative.LimNativeIMChatMessage
// Size: 0x70 // Inherited bytes: 0x08
struct FLimNativeIMChatMessage : FLimNativeDataObjectBase {
	// Fields
	struct FLimNativeIMChatMessageInfo BaseInfo; // Offset: 0x08 // Size: 0x50
	char pad_0x58[0x10]; // Offset: 0x58 // Size: 0x10
	enum class ELimNativeMsgContentType MsgType; // Offset: 0x68 // Size: 0x01
	char pad_0x69[0x7]; // Offset: 0x69 // Size: 0x07
};

// Object Name: ScriptStruct LimNative.LimNativeIMChatMessageInfo
// Size: 0x50 // Inherited bytes: 0x08
struct FLimNativeIMChatMessageInfo : FLimNativeDataObjectBase {
	// Fields
	struct FString ConvID; // Offset: 0x08 // Size: 0x10
	enum class ELimNativeConvType ConvType; // Offset: 0x18 // Size: 0x01
	enum class ELimNativeMsgContentType MsgType; // Offset: 0x19 // Size: 0x01
	char pad_0x1A[0x6]; // Offset: 0x1a // Size: 0x06
	struct FString Ext; // Offset: 0x20 // Size: 0x10
	struct FString Nonce; // Offset: 0x30 // Size: 0x10
	struct FString Timestamp; // Offset: 0x40 // Size: 0x10
};

// Object Name: ScriptStruct LimNative.LimNativeMsgListData
// Size: 0xa8 // Inherited bytes: 0x90
struct FLimNativeMsgListData : FLimNativeOnChatMsgCallBackData {
	// Fields
	struct FString SenderId; // Offset: 0x90 // Size: 0x10
	bool IsISent; // Offset: 0xa0 // Size: 0x01
	char pad_0xA1[0x7]; // Offset: 0xa1 // Size: 0x07
};

// Object Name: ScriptStruct LimNative.LimNativeGetOssTokenCallBack
// Size: 0xd0 // Inherited bytes: 0x30
struct FLimNativeGetOssTokenCallBack : FLimNativeDataCallBackBase {
	// Fields
	struct FLimNativeGetOssTokenData Data; // Offset: 0x30 // Size: 0xa0
};

// Object Name: ScriptStruct LimNative.LimNativeGetOssTokenData
// Size: 0xa0 // Inherited bytes: 0x28
struct FLimNativeGetOssTokenData : FLimNativeDataCallBackDataBase {
	// Fields
	struct FLimNativeOssTokenData Data; // Offset: 0x28 // Size: 0x70
	int32_t ResultCode; // Offset: 0x98 // Size: 0x04
	char pad_0x9C[0x4]; // Offset: 0x9c // Size: 0x04
};

// Object Name: ScriptStruct LimNative.LimNativeOssTokenData
// Size: 0x70 // Inherited bytes: 0x08
struct FLimNativeOssTokenData : FLimNativeDataObjectBase {
	// Fields
	struct FString AssessKeyID; // Offset: 0x08 // Size: 0x10
	struct FString AccessKeySecret; // Offset: 0x18 // Size: 0x10
	int32_t ExpirationUtc; // Offset: 0x28 // Size: 0x04
	char pad_0x2C[0x4]; // Offset: 0x2c // Size: 0x04
	struct FString SecurityToken; // Offset: 0x30 // Size: 0x10
	struct FString Bucket; // Offset: 0x40 // Size: 0x10
	struct FString EndPoint; // Offset: 0x50 // Size: 0x10
	struct FString FilePath; // Offset: 0x60 // Size: 0x10
};

// Object Name: ScriptStruct LimNative.LimNativeOnGetUserCallBack
// Size: 0x168 // Inherited bytes: 0x30
struct FLimNativeOnGetUserCallBack : FLimNativeDataCallBackBase {
	// Fields
	struct FLimNativeGetUserData Data; // Offset: 0x30 // Size: 0x138
};

// Object Name: ScriptStruct LimNative.LimNativeGetUserData
// Size: 0x138 // Inherited bytes: 0x28
struct FLimNativeGetUserData : FLimNativeDataCallBackDataBase {
	// Fields
	struct FString AvatarFrameUrl; // Offset: 0x28 // Size: 0x10
	struct FString AvatarUrl; // Offset: 0x38 // Size: 0x10
	int32_t CreateTime; // Offset: 0x48 // Size: 0x04
	char pad_0x4C[0x4]; // Offset: 0x4c // Size: 0x04
	struct FGuild Guild; // Offset: 0x50 // Size: 0x48
	struct FKingdom Kingdom; // Offset: 0x98 // Size: 0x48
	int32_t LastFetchTime; // Offset: 0xe0 // Size: 0x04
	char pad_0xE4[0x4]; // Offset: 0xe4 // Size: 0x04
	struct FString NickName; // Offset: 0xe8 // Size: 0x10
	int32_t ServerTime; // Offset: 0xf8 // Size: 0x04
	bool IsShowVip; // Offset: 0xfc // Size: 0x01
	char pad_0xFD[0x3]; // Offset: 0xfd // Size: 0x03
	struct TArray<struct FSubTitleItem> SubTitleList; // Offset: 0x100 // Size: 0x10
	struct FString Uid; // Offset: 0x110 // Size: 0x10
	int32_t VipLevel; // Offset: 0x120 // Size: 0x04
	char pad_0x124[0x4]; // Offset: 0x124 // Size: 0x04
	struct FString GameExtra; // Offset: 0x128 // Size: 0x10
};

// Object Name: ScriptStruct LimNative.LimNativeOnGetUsersCallBack
// Size: 0x68 // Inherited bytes: 0x30
struct FLimNativeOnGetUsersCallBack : FLimNativeDataCallBackBase {
	// Fields
	struct FLimNativeGetUsersData Data; // Offset: 0x30 // Size: 0x38
};

// Object Name: ScriptStruct LimNative.LimNativeGetUsersData
// Size: 0x38 // Inherited bytes: 0x28
struct FLimNativeGetUsersData : FLimNativeDataCallBackDataBase {
	// Fields
	struct TArray<struct FLimNativeGetUserData> DataResultList; // Offset: 0x28 // Size: 0x10
};

// Object Name: ScriptStruct LimNative.LimNativeOnGetUsersStateCallBack
// Size: 0xa8 // Inherited bytes: 0x30
struct FLimNativeOnGetUsersStateCallBack : FLimNativeDataCallBackBase {
	// Fields
	struct FUsersPresence Data; // Offset: 0x30 // Size: 0x78
};

// Object Name: ScriptStruct LimNative.UsersPresence
// Size: 0x78 // Inherited bytes: 0x28
struct FUsersPresence : FLimNativeDataCallBackDataBase {
	// Fields
	struct TMap<struct FString, struct FPresence> Result; // Offset: 0x28 // Size: 0x50
};

// Object Name: ScriptStruct LimNative.LimNativeOnGroupJoinCallBack
// Size: 0x30 // Inherited bytes: 0x30
struct FLimNativeOnGroupJoinCallBack : FLimNativeDataCallBackBase {
};

// Object Name: ScriptStruct LimNative.LimNativeOnLoginCallBack
// Size: 0x30 // Inherited bytes: 0x30
struct FLimNativeOnLoginCallBack : FLimNativeDataCallBackBase {
};

// Object Name: ScriptStruct LimNative.LimNativeOnLogoutCallBack
// Size: 0x30 // Inherited bytes: 0x30
struct FLimNativeOnLogoutCallBack : FLimNativeDataCallBackBase {
};

// Object Name: ScriptStruct LimNative.LimNativeOnMsgLogicReceivedEventCallBack
// Size: 0x38 // Inherited bytes: 0x08
struct FLimNativeOnMsgLogicReceivedEventCallBack : FLimNativeDataObjectBase {
	// Fields
	struct FLimNativeMsgLogiMsgData Data; // Offset: 0x08 // Size: 0x30
};

// Object Name: ScriptStruct LimNative.LimNativeMsgLogiMsgData
// Size: 0x30 // Inherited bytes: 0x08
struct FLimNativeMsgLogiMsgData : FLimNativeDataObjectBase {
	// Fields
	struct FLimNativeMsgLogiCommonMsgData Data; // Offset: 0x08 // Size: 0x28
};

// Object Name: ScriptStruct LimNative.LimNativeMsgLogiCommonMsgData
// Size: 0x28 // Inherited bytes: 0x08
struct FLimNativeMsgLogiCommonMsgData : FLimNativeDataObjectBase {
	// Fields
	int32_t Type; // Offset: 0x08 // Size: 0x04
	char pad_0xC[0x4]; // Offset: 0x0c // Size: 0x04
	struct FLimNativeDataBizFullObj BizObj; // Offset: 0x10 // Size: 0x18
};

// Object Name: ScriptStruct LimNative.LimNativeDataBizFullObj
// Size: 0x18 // Inherited bytes: 0x08
struct FLimNativeDataBizFullObj : FLimNativeDataObjectBase {
	// Fields
	struct FString Uid; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct LimNative.LimNativeOnMsgReceivedEventCallBack
// Size: 0x40 // Inherited bytes: 0x08
struct FLimNativeOnMsgReceivedEventCallBack : FLimNativeDataObjectBase {
	// Fields
	struct FLimNativeOnMsgReceivedData Data; // Offset: 0x08 // Size: 0x38
};

// Object Name: ScriptStruct LimNative.LimNativeOnMsgReceivedData
// Size: 0x38 // Inherited bytes: 0x28
struct FLimNativeOnMsgReceivedData : FLimNativeDataCallBackDataBase {
	// Fields
	struct TArray<struct FLimNativeReceivedMsgData> MsgDataList; // Offset: 0x28 // Size: 0x10
};

// Object Name: ScriptStruct LimNative.LimNativeReceivedMsgData
// Size: 0xc8 // Inherited bytes: 0x28
struct FLimNativeReceivedMsgData : FLimNativeDataCallBackDataBase {
	// Fields
	struct FString LanguageList; // Offset: 0x28 // Size: 0x10
	struct FString SenderId; // Offset: 0x38 // Size: 0x10
	struct FString MsgId; // Offset: 0x48 // Size: 0x10
	struct FLimNativeIMChatMessage Msg; // Offset: 0x58 // Size: 0x70
};

// Object Name: ScriptStruct LimNative.LimNativeOnMsgRevokedEventCallBack
// Size: 0x60 // Inherited bytes: 0x08
struct FLimNativeOnMsgRevokedEventCallBack : FLimNativeDataObjectBase {
	// Fields
	struct FLimNativeOnMsgRevokedData Data; // Offset: 0x08 // Size: 0x58
};

// Object Name: ScriptStruct LimNative.LimNativeOnMsgRevokedData
// Size: 0x58 // Inherited bytes: 0x28
struct FLimNativeOnMsgRevokedData : FLimNativeDataCallBackDataBase {
	// Fields
	struct FString ConvID; // Offset: 0x28 // Size: 0x10
	enum class ELimNativeConvType ConvType; // Offset: 0x38 // Size: 0x01
	char pad_0x39[0x7]; // Offset: 0x39 // Size: 0x07
	struct FString MessageId; // Offset: 0x40 // Size: 0x10
	int32_t SenderId; // Offset: 0x50 // Size: 0x04
	char pad_0x54[0x4]; // Offset: 0x54 // Size: 0x04
};

// Object Name: ScriptStruct LimNative.LimNativeOnGroupQuitCallBack
// Size: 0x50 // Inherited bytes: 0x30
struct FLimNativeOnGroupQuitCallBack : FLimNativeDataCallBackBase {
	// Fields
	struct FString GameID; // Offset: 0x30 // Size: 0x10
	struct FString ChannelId; // Offset: 0x40 // Size: 0x10
};

// Object Name: ScriptStruct LimNative.LimNativeOnGroupMemberRemoveCallBack
// Size: 0x98 // Inherited bytes: 0x30
struct FLimNativeOnGroupMemberRemoveCallBack : FLimNativeDataCallBackBase {
	// Fields
	struct FLimNativeIMGroup Data; // Offset: 0x30 // Size: 0x68
};

// Object Name: ScriptStruct LimNative.LimNativeOnRevokeMsgCallBack
// Size: 0x30 // Inherited bytes: 0x30
struct FLimNativeOnRevokeMsgCallBack : FLimNativeDataCallBackBase {
};

// Object Name: ScriptStruct LimNative.LimNativeOnSendMsgCallBack
// Size: 0xc0 // Inherited bytes: 0x30
struct FLimNativeOnSendMsgCallBack : FLimNativeDataCallBackBase {
	// Fields
	struct FLimNativeOnChatMsgCallBackData Data; // Offset: 0x30 // Size: 0x90
};

// Object Name: ScriptStruct LimNative.LimNativeOnSetConvReadCallBack
// Size: 0x30 // Inherited bytes: 0x30
struct FLimNativeOnSetConvReadCallBack : FLimNativeDataCallBackBase {
};

// Object Name: ScriptStruct LimNative.LimNativeOnGroupAttrSetCallBack
// Size: 0x30 // Inherited bytes: 0x30
struct FLimNativeOnGroupAttrSetCallBack : FLimNativeDataCallBackBase {
};

// Object Name: ScriptStruct LimNative.LimNativeLanguageConfig
// Size: 0x10 // Inherited bytes: 0x08
struct FLimNativeLanguageConfig : FLimNativeDataObjectBase {
	// Fields
	enum class ELimNativeSupportedLanguage Lang; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x7]; // Offset: 0x09 // Size: 0x07
};

// Object Name: ScriptStruct LimNative.LimNativeOnSetMsgStateCallBack
// Size: 0x30 // Inherited bytes: 0x30
struct FLimNativeOnSetMsgStateCallBack : FLimNativeDataCallBackBase {
};

// Object Name: ScriptStruct LimNative.LimNativeParkConfig
// Size: 0x58 // Inherited bytes: 0x08
struct FLimNativeParkConfig : FLimNativeDataObjectBase {
	// Fields
	struct FString App_Id; // Offset: 0x08 // Size: 0x10
	struct FString Sdk_Env; // Offset: 0x18 // Size: 0x10
	struct FString Sdk_Region; // Offset: 0x28 // Size: 0x10
	struct FString Gid; // Offset: 0x38 // Size: 0x10
	struct FString SlsSvr; // Offset: 0x48 // Size: 0x10
};

// Object Name: ScriptStruct LimNative.LimNativeReportConfig
// Size: 0xc8 // Inherited bytes: 0x08
struct FLimNativeReportConfig : FLimNativeDataObjectBase {
	// Fields
	struct FString PackageName; // Offset: 0x08 // Size: 0x10
	struct FString Android_Id; // Offset: 0x18 // Size: 0x10
	struct FString Goodle_Aid; // Offset: 0x28 // Size: 0x10
	struct FString Os_Version; // Offset: 0x38 // Size: 0x10
	struct FString Mac; // Offset: 0x48 // Size: 0x10
	struct FString Device_Model; // Offset: 0x58 // Size: 0x10
	struct FString Open_Id; // Offset: 0x68 // Size: 0x10
	struct FString Idfa; // Offset: 0x78 // Size: 0x10
	struct FString App_Version; // Offset: 0x88 // Size: 0x10
	struct FString Server_Id; // Offset: 0x98 // Size: 0x10
	struct FString Device_Id; // Offset: 0xa8 // Size: 0x10
	struct FString SlsSvr; // Offset: 0xb8 // Size: 0x10
};

// Object Name: ScriptStruct LimNative.LimNativeResDirConfig
// Size: 0x18 // Inherited bytes: 0x08
struct FLimNativeResDirConfig : FLimNativeDataObjectBase {
	// Fields
	struct FString ResDir; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct LimNative.LimNativeTextTranslateCallBack
// Size: 0x88 // Inherited bytes: 0x30
struct FLimNativeTextTranslateCallBack : FLimNativeDataCallBackBase {
	// Fields
	struct FLimNativeTextTranslateData Data; // Offset: 0x30 // Size: 0x58
};

// Object Name: ScriptStruct LimNative.LimNativeTextTranslateData
// Size: 0x58 // Inherited bytes: 0x28
struct FLimNativeTextTranslateData : FLimNativeDataCallBackDataBase {
	// Fields
	struct FString TranslatedText; // Offset: 0x28 // Size: 0x10
	struct FString Translator; // Offset: 0x38 // Size: 0x10
	struct FString ExtraInfo; // Offset: 0x48 // Size: 0x10
};

// Object Name: ScriptStruct LimNative.LimNativeIMChatMessageBase
// Size: 0x58 // Inherited bytes: 0x08
struct FLimNativeIMChatMessageBase : FLimNativeDataObjectBase {
	// Fields
	char pad_0x8[0x50]; // Offset: 0x08 // Size: 0x50
};

// Object Name: ScriptStruct LimNative.LimNativeIMEmotionMessage
// Size: 0xb0 // Inherited bytes: 0x58
struct FLimNativeIMEmotionMessage : FLimNativeIMChatMessageBase {
	// Fields
	struct FString PackName; // Offset: 0x58 // Size: 0x10
	enum class ELimNativePackType PackType; // Offset: 0x68 // Size: 0x01
	char pad_0x69[0x7]; // Offset: 0x69 // Size: 0x07
	struct FString EmotionName; // Offset: 0x70 // Size: 0x10
	struct FString EmotionId; // Offset: 0x80 // Size: 0x10
	struct FString EmotionUrl; // Offset: 0x90 // Size: 0x10
	struct FString Desc; // Offset: 0xa0 // Size: 0x10
};

// Object Name: ScriptStruct LimNative.LimNativeIMImageMessage
// Size: 0xa0 // Inherited bytes: 0x58
struct FLimNativeIMImageMessage : FLimNativeIMChatMessageBase {
	// Fields
	struct FString UUID; // Offset: 0x58 // Size: 0x10
	struct FString Fmt; // Offset: 0x68 // Size: 0x10
	struct FString URL; // Offset: 0x78 // Size: 0x10
	int32_t Width; // Offset: 0x88 // Size: 0x04
	int32_t Height; // Offset: 0x8c // Size: 0x04
	struct FString Size; // Offset: 0x90 // Size: 0x10
};

// Object Name: ScriptStruct LimNative.LimNativeIMShareMessage
// Size: 0xc0 // Inherited bytes: 0x58
struct FLimNativeIMShareMessage : FLimNativeIMChatMessageBase {
	// Fields
	int32_t Type; // Offset: 0x58 // Size: 0x04
	char pad_0x5C[0x4]; // Offset: 0x5c // Size: 0x04
	struct FString Text; // Offset: 0x60 // Size: 0x10
	struct FString Title; // Offset: 0x70 // Size: 0x10
	struct FString Detail; // Offset: 0x80 // Size: 0x10
	struct FString Img; // Offset: 0x90 // Size: 0x10
	struct FString URL; // Offset: 0xa0 // Size: 0x10
	struct FString Extra; // Offset: 0xb0 // Size: 0x10
};

// Object Name: ScriptStruct LimNative.LimNativeIMTextMessage
// Size: 0x68 // Inherited bytes: 0x58
struct FLimNativeIMTextMessage : FLimNativeIMChatMessageBase {
	// Fields
	struct FString Text; // Offset: 0x58 // Size: 0x10
};

// Object Name: ScriptStruct LimNative.LimNativeIMTextWithAtMessage
// Size: 0x68 // Inherited bytes: 0x58
struct FLimNativeIMTextWithAtMessage : FLimNativeIMChatMessageBase {
	// Fields
	struct FString Text; // Offset: 0x58 // Size: 0x10
};

// Object Name: ScriptStruct LimNative.LimNativeIMVoiceMessage
// Size: 0x90 // Inherited bytes: 0x58
struct FLimNativeIMVoiceMessage : FLimNativeIMChatMessageBase {
	// Fields
	struct FString UUID; // Offset: 0x58 // Size: 0x10
	struct FString URL; // Offset: 0x68 // Size: 0x10
	struct FString Size; // Offset: 0x78 // Size: 0x10
	int32_t Duration; // Offset: 0x88 // Size: 0x04
	char pad_0x8C[0x4]; // Offset: 0x8c // Size: 0x04
};

// Object Name: ScriptStruct LimNative.LimNativeSetMsgState
// Size: 0x40 // Inherited bytes: 0x08
struct FLimNativeSetMsgState : FLimNativeDataObjectBase {
	// Fields
	enum class ELimNativeConvType ConvType; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x7]; // Offset: 0x09 // Size: 0x07
	struct FString ConvID; // Offset: 0x10 // Size: 0x10
	enum class ELimNativeMsgContentType MsgType; // Offset: 0x20 // Size: 0x01
	char pad_0x21[0x7]; // Offset: 0x21 // Size: 0x07
	struct FString MsgId; // Offset: 0x28 // Size: 0x10
	enum class ELimNativeMsgState MsgState; // Offset: 0x38 // Size: 0x01
	char pad_0x39[0x7]; // Offset: 0x39 // Size: 0x07
};

// Object Name: ScriptStruct LimNative.LimNativeOnMsgLogicReceivedData
// Size: 0x38 // Inherited bytes: 0x28
struct FLimNativeOnMsgLogicReceivedData : FLimNativeDataCallBackDataBase {
	// Fields
	struct TArray<struct FLimNativeCommonMsg> CommonMessage; // Offset: 0x28 // Size: 0x10
};

// Object Name: ScriptStruct LimNative.LimNativeBizObjFriendBase
// Size: 0x48 // Inherited bytes: 0x08
struct FLimNativeBizObjFriendBase : FLimNativeDataObjectBase {
	// Fields
	struct FString Uid; // Offset: 0x08 // Size: 0x10
	struct FString NickName; // Offset: 0x18 // Size: 0x10
	struct FString AvatarUrl; // Offset: 0x28 // Size: 0x10
	struct FString AvatarFrameUrl; // Offset: 0x38 // Size: 0x10
};

// Object Name: ScriptStruct LimNative.LimNativeBizObjRefreshFriend
// Size: 0x58 // Inherited bytes: 0x48
struct FLimNativeBizObjRefreshFriend : FLimNativeBizObjFriendBase {
	// Fields
	struct FString EmblemUrls; // Offset: 0x48 // Size: 0x10
};

// Object Name: ScriptStruct LimNative.LimNativeBizObjFriendRequest
// Size: 0x98 // Inherited bytes: 0x48
struct FLimNativeBizObjFriendRequest : FLimNativeBizObjFriendBase {
	// Fields
	struct FString RequestID; // Offset: 0x48 // Size: 0x10
	struct FString RequestMsg; // Offset: 0x58 // Size: 0x10
	struct FString RequestSource; // Offset: 0x68 // Size: 0x10
	struct FString Timestamp; // Offset: 0x78 // Size: 0x10
	struct FString Lang; // Offset: 0x88 // Size: 0x10
};

// Object Name: ScriptStruct LimNative.LimNativeBizObjGroupBase
// Size: 0x18 // Inherited bytes: 0x08
struct FLimNativeBizObjGroupBase : FLimNativeDataObjectBase {
	// Fields
	struct FString groupid; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct LimNative.LimNativeBizObjExitGroup
// Size: 0x30 // Inherited bytes: 0x18
struct FLimNativeBizObjExitGroup : FLimNativeBizObjGroupBase {
	// Fields
	enum class ELimNativeGroupType Type; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x7]; // Offset: 0x19 // Size: 0x07
	struct FString Uid; // Offset: 0x20 // Size: 0x10
};

// Object Name: ScriptStruct LimNative.LimNativeBizObjGroupPerms
// Size: 0x28 // Inherited bytes: 0x18
struct FLimNativeBizObjGroupPerms : FLimNativeBizObjGroupBase {
	// Fields
	struct FString Perms; // Offset: 0x18 // Size: 0x10
};

// Object Name: ScriptStruct LimNative.LimNativeIMNotificationMessage
// Size: 0x68 // Inherited bytes: 0x58
struct FLimNativeIMNotificationMessage : FLimNativeIMChatMessageBase {
	// Fields
	struct FString Text; // Offset: 0x58 // Size: 0x10
};

// Object Name: ScriptStruct LimNative.LimNativeEventDataBase
// Size: 0x40 // Inherited bytes: 0x08
struct FLimNativeEventDataBase : FLimNativeDataObjectBase {
	// Fields
	struct FString JsonData; // Offset: 0x08 // Size: 0x10
	struct FString ErrorCode; // Offset: 0x18 // Size: 0x10
	struct FString Message; // Offset: 0x28 // Size: 0x10
	enum class ELimNativeEventType EventCode; // Offset: 0x38 // Size: 0x01
	char pad_0x39[0x7]; // Offset: 0x39 // Size: 0x07
};

