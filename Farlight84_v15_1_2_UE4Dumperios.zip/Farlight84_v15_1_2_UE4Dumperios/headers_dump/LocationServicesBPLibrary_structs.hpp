#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct LocationServicesBPLibrary.LocationServicesData
// Size: 0x18 // Inherited bytes: 0x00
struct FLocationServicesData {
	// Fields
	float Timestamp; // Offset: 0x00 // Size: 0x04
	float Longitude; // Offset: 0x04 // Size: 0x04
	float Latitude; // Offset: 0x08 // Size: 0x04
	float HorizontalAccuracy; // Offset: 0x0c // Size: 0x04
	float VerticalAccuracy; // Offset: 0x10 // Size: 0x04
	float Altitude; // Offset: 0x14 // Size: 0x04
};

