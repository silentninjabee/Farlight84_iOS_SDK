#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass Login.Login_C
// Size: 0x230 // Inherited bytes: 0x230
struct ALogin_C : ALevelScriptActor {
	// Functions

	// Object Name: Function Login.Login_C.ReceiveBeginPlay
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveBeginPlay(); // Offset: 0x10149b2f0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Login.Login_C.ReceiveEndPlay
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveEndPlay(enum class EEndPlayReason EndPlayReason); // Offset: 0x10149b2f0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Login.Login_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	struct FString GetModuleName(); // Offset: 0x103938968 // Return & Params: Num(1) Size(0x10)
};

