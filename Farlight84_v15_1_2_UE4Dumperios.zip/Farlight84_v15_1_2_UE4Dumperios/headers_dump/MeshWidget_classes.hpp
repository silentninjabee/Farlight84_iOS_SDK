#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class MeshWidget.MeshWidgetUWidget
// Size: 0x148 // Inherited bytes: 0x138
struct UMeshWidgetUWidget : UWidget {
	// Fields
	char pad_0x138[0x10]; // Offset: 0x138 // Size: 0x10
};

// Object Name: Class MeshWidget.ParticleWidget
// Size: 0x188 // Inherited bytes: 0x148
struct UParticleWidget : UMeshWidgetUWidget {
	// Fields
	struct USlateVectorArtData* TrailMeshAsset; // Offset: 0x148 // Size: 0x08
	int32_t MaxParticleCount; // Offset: 0x150 // Size: 0x04
	char pad_0x154[0x34]; // Offset: 0x154 // Size: 0x34
};

// Object Name: Class MeshWidget.MeshRectangleWidget
// Size: 0x170 // Inherited bytes: 0x148
struct UMeshRectangleWidget : UMeshWidgetUWidget {
	// Fields
	struct UMaterialInterface* BaseMaterial; // Offset: 0x148 // Size: 0x08
	int32_t NumFloat4PerInstance; // Offset: 0x150 // Size: 0x04
	char pad_0x154[0x1c]; // Offset: 0x154 // Size: 0x1c

	// Functions

	// Object Name: Function MeshWidget.MeshRectangleWidget.SetInstanceNum
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetInstanceNum(int32_t NewNum); // Offset: 0x102281e30 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MeshWidget.MeshRectangleWidget.ModifyInstanceNum
	// Flags: [Final|Native|Public|BlueprintCallable]
	void ModifyInstanceNum(int32_t dNum); // Offset: 0x102281db0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function MeshWidget.MeshRectangleWidget.InitUnitTestProvider
	// Flags: [Final|Native|Public|BlueprintCallable]
	void InitUnitTestProvider(); // Offset: 0x102281eb0 // Return & Params: Num(0) Size(0x0)
};

// Object Name: Class MeshWidget.TextMeshWidget
// Size: 0x178 // Inherited bytes: 0x148
struct UTextMeshWidget : UMeshWidgetUWidget {
	// Fields
	struct UMaterialInterface* BaseMaterial; // Offset: 0x148 // Size: 0x08
	char pad_0x150[0x28]; // Offset: 0x150 // Size: 0x28
};

// Object Name: Class MeshWidget.ProgressBarMeshWidget
// Size: 0x178 // Inherited bytes: 0x148
struct UProgressBarMeshWidget : UMeshWidgetUWidget {
	// Fields
	struct UMaterialInterface* BaseMaterial; // Offset: 0x148 // Size: 0x08
	char pad_0x150[0x28]; // Offset: 0x150 // Size: 0x28
};

