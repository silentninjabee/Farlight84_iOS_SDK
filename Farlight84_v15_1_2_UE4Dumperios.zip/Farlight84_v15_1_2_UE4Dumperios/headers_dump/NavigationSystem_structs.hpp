#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct NavigationSystem.NavCollisionBox
// Size: 0x18 // Inherited bytes: 0x00
struct FNavCollisionBox {
	// Fields
	struct FVector Offset; // Offset: 0x00 // Size: 0x0c
	struct FVector Extent; // Offset: 0x0c // Size: 0x0c
};

// Object Name: ScriptStruct NavigationSystem.NavCollisionCylinder
// Size: 0x14 // Inherited bytes: 0x00
struct FNavCollisionCylinder {
	// Fields
	struct FVector Offset; // Offset: 0x00 // Size: 0x0c
	float Radius; // Offset: 0x0c // Size: 0x04
	float Height; // Offset: 0x10 // Size: 0x04
};

// Object Name: ScriptStruct NavigationSystem.SupportedAreaData
// Size: 0x20 // Inherited bytes: 0x00
struct FSupportedAreaData {
	// Fields
	struct FString AreaClassName; // Offset: 0x00 // Size: 0x10
	int32_t AreaID; // Offset: 0x10 // Size: 0x04
	char pad_0x14[0x4]; // Offset: 0x14 // Size: 0x04
	struct UObject* AreaClass; // Offset: 0x18 // Size: 0x08
};

// Object Name: ScriptStruct NavigationSystem.NavGraphNode
// Size: 0x18 // Inherited bytes: 0x00
struct FNavGraphNode {
	// Fields
	struct UObject* Owner; // Offset: 0x00 // Size: 0x08
	char pad_0x8[0x10]; // Offset: 0x08 // Size: 0x10
};

// Object Name: ScriptStruct NavigationSystem.NavGraphEdge
// Size: 0x18 // Inherited bytes: 0x00
struct FNavGraphEdge {
	// Fields
	char pad_0x0[0x18]; // Offset: 0x00 // Size: 0x18
};

// Object Name: ScriptStruct NavigationSystem.NavigationFilterFlags
// Size: 0x04 // Inherited bytes: 0x00
struct FNavigationFilterFlags {
	// Fields
	char bNavFlag0 : 1; // Offset: 0x00 // Size: 0x01
	char bNavFlag1 : 1; // Offset: 0x00 // Size: 0x01
	char bNavFlag2 : 1; // Offset: 0x00 // Size: 0x01
	char bNavFlag3 : 1; // Offset: 0x00 // Size: 0x01
	char bNavFlag4 : 1; // Offset: 0x00 // Size: 0x01
	char bNavFlag5 : 1; // Offset: 0x00 // Size: 0x01
	char bNavFlag6 : 1; // Offset: 0x00 // Size: 0x01
	char bNavFlag7 : 1; // Offset: 0x00 // Size: 0x01
	char bNavFlag8 : 1; // Offset: 0x01 // Size: 0x01
	char bNavFlag9 : 1; // Offset: 0x01 // Size: 0x01
	char bNavFlag10 : 1; // Offset: 0x01 // Size: 0x01
	char bNavFlag11 : 1; // Offset: 0x01 // Size: 0x01
	char bNavFlag12 : 1; // Offset: 0x01 // Size: 0x01
	char bNavFlag13 : 1; // Offset: 0x01 // Size: 0x01
	char bNavFlag14 : 1; // Offset: 0x01 // Size: 0x01
	char bNavFlag15 : 1; // Offset: 0x01 // Size: 0x01
	char pad_0x2[0x2]; // Offset: 0x02 // Size: 0x02
};

// Object Name: ScriptStruct NavigationSystem.NavigationFilterArea
// Size: 0x18 // Inherited bytes: 0x00
struct FNavigationFilterArea {
	// Fields
	struct UNavArea* AreaClass; // Offset: 0x00 // Size: 0x08
	float TravelCostOverride; // Offset: 0x08 // Size: 0x04
	float EnteringCostOverride; // Offset: 0x0c // Size: 0x04
	char bIsExcluded : 1; // Offset: 0x10 // Size: 0x01
	char bOverrideTravelCost : 1; // Offset: 0x10 // Size: 0x01
	char bOverrideEnteringCost : 1; // Offset: 0x10 // Size: 0x01
	char pad_0x10_3 : 5; // Offset: 0x10 // Size: 0x01
	char pad_0x11[0x7]; // Offset: 0x11 // Size: 0x07
};

// Object Name: ScriptStruct NavigationSystem.NavLinkCustomInstanceData
// Size: 0x60 // Inherited bytes: 0x58
struct FNavLinkCustomInstanceData : FActorComponentInstanceData {
	// Fields
	uint32_t NavLinkUserId; // Offset: 0x58 // Size: 0x04
	char pad_0x5C[0x4]; // Offset: 0x5c // Size: 0x04
};

// Object Name: ScriptStruct NavigationSystem.RecastNavMeshGenerationProperties
// Size: 0x40 // Inherited bytes: 0x00
struct FRecastNavMeshGenerationProperties {
	// Fields
	int32_t TilePoolSize; // Offset: 0x00 // Size: 0x04
	float TileSizeUU; // Offset: 0x04 // Size: 0x04
	float CellSize; // Offset: 0x08 // Size: 0x04
	float CellHeight; // Offset: 0x0c // Size: 0x04
	float AgentRadius; // Offset: 0x10 // Size: 0x04
	float AgentHeight; // Offset: 0x14 // Size: 0x04
	float AgentMaxSlope; // Offset: 0x18 // Size: 0x04
	float AgentMaxStepHeight; // Offset: 0x1c // Size: 0x04
	float MinRegionArea; // Offset: 0x20 // Size: 0x04
	float MergeRegionSize; // Offset: 0x24 // Size: 0x04
	float MaxSimplificationError; // Offset: 0x28 // Size: 0x04
	int32_t TileNumberHardLimit; // Offset: 0x2c // Size: 0x04
	enum class ERecastPartitioning RegionPartitioning; // Offset: 0x30 // Size: 0x01
	enum class ERecastPartitioning LayerPartitioning; // Offset: 0x31 // Size: 0x01
	char pad_0x32[0x2]; // Offset: 0x32 // Size: 0x02
	int32_t RegionChunkSplits; // Offset: 0x34 // Size: 0x04
	int32_t LayerChunkSplits; // Offset: 0x38 // Size: 0x04
	char bSortNavigationAreasByCost : 1; // Offset: 0x3c // Size: 0x01
	char bPerformVoxelFiltering : 1; // Offset: 0x3c // Size: 0x01
	char bMarkLowHeightAreas : 1; // Offset: 0x3c // Size: 0x01
	char bFilterLowSpanSequences : 1; // Offset: 0x3c // Size: 0x01
	char bFilterLowSpanFromTileCache : 1; // Offset: 0x3c // Size: 0x01
	char bFixedTilePoolSize : 1; // Offset: 0x3c // Size: 0x01
	char pad_0x3C_6 : 2; // Offset: 0x3c // Size: 0x01
	char pad_0x3D[0x3]; // Offset: 0x3d // Size: 0x03
};

