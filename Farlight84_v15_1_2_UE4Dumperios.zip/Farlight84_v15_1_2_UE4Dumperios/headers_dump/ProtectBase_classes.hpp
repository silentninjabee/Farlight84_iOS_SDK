#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class ProtectBase.ProtectBaseComponent
// Size: 0x30 // Inherited bytes: 0x28
struct UProtectBaseComponent : UObject {
	// Fields
	char pad_0x28[0x8]; // Offset: 0x28 // Size: 0x08

	// Functions

	// Object Name: Function ProtectBase.ProtectBaseComponent.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct UProtectBaseComponent* GetInstance(); // Offset: 0x1016efd4c // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class ProtectBase.ProtectBaseManager
// Size: 0x28 // Inherited bytes: 0x28
struct UProtectBaseManager : UObject {
};

// Object Name: Class ProtectBase.SecDSComponent
// Size: 0xa0 // Inherited bytes: 0x28
struct USecDSComponent : UObject {
	// Fields
	char pad_0x28[0x78]; // Offset: 0x28 // Size: 0x78

	// Functions

	// Object Name: Function ProtectBase.SecDSComponent.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct USecDSComponent* GetInstance(); // Offset: 0x1016f0374 // Return & Params: Num(1) Size(0x8)
};

