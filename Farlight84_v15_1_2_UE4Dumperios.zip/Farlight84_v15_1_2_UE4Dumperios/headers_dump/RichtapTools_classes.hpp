#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class RichtapTools.RichtapController
// Size: 0x90 // Inherited bytes: 0x28
struct URichtapController : UObject {
	// Fields
	char pad_0x28[0x18]; // Offset: 0x28 // Size: 0x18
	struct TMap<struct FString, struct URichtapClip*> HeDataMap; // Offset: 0x40 // Size: 0x50

	// Functions

	// Object Name: Function RichtapTools.RichtapController.SetRichtapEnable
	// Flags: [Final|Native|Public]
	void SetRichtapEnable(bool On); // Offset: 0x10153b724 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function RichtapTools.RichtapController.SetEnableWinRichtap
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetEnableWinRichtap(bool bIsEnableWinRichtap); // Offset: 0x10153b624 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function RichtapTools.RichtapController.SetEnableRichtap
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	void SetEnableRichtap(bool bIsEnableRichtap); // Offset: 0x10153b6a4 // Return & Params: Num(1) Size(0x1)
};

