#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass SolarGameInstance.SolarGameInstance_C
// Size: 0xa58 // Inherited bytes: 0xa40
struct USolarGameInstance_C : USolarGameInstanceBase {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0xa40 // Size: 0x08
	struct FMulticastInlineDelegate OnBroadcastModeChanged; // Offset: 0xa48 // Size: 0x10

	// Functions

	// Object Name: Function SolarGameInstance.SolarGameInstance_C.LuaStartGameFrameWork
	// Flags: [Event|Protected|BlueprintEvent]
	void LuaStartGameFrameWork(); // Offset: 0x10149b2f0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SolarGameInstance.SolarGameInstance_C.HandleNetworkError
	// Flags: [Event|Public|BlueprintEvent]
	void HandleNetworkError(enum class ENetworkFailure FailureType, bool bIsServer); // Offset: 0x10149b2f0 // Return & Params: Num(2) Size(0x2)

	// Object Name: Function SolarGameInstance.SolarGameInstance_C.SolarGM_AddItemLua
	// Flags: [Event|Public|BlueprintEvent]
	void SolarGM_AddItemLua(int32_t ItemID, int32_t count); // Offset: 0x10149b2f0 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function SolarGameInstance.SolarGameInstance_C.SolarGM_TransmitGMLua
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	void SolarGM_TransmitGMLua(struct FString playerName, struct TArray<struct FString>& GmArray); // Offset: 0x10149b2f0 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function SolarGameInstance.SolarGameInstance_C.LuaGetBroadcastHeroNameCopy
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void LuaGetBroadcastHeroNameCopy(struct FString SolarPlayerID, struct FString& BroadcastPlayerName); // Offset: 0x103938968 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function SolarGameInstance.SolarGameInstance_C.ExecuteChangeAudioModeLuaCall
	// Flags: [Event|Public|BlueprintEvent]
	void ExecuteChangeAudioModeLuaCall(bool bTurnOn); // Offset: 0x10149b2f0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function SolarGameInstance.SolarGameInstance_C.SolarGM_LobbyLua
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	void SolarGM_LobbyLua(struct FString CmdName, struct TArray<struct FString>& Params); // Offset: 0x10149b2f0 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function SolarGameInstance.SolarGameInstance_C.CheckSavedDirFiles
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	void CheckSavedDirFiles(struct TArray<struct FString>& Files); // Offset: 0x10149b2f0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function SolarGameInstance.SolarGameInstance_C.InitLuaClasses
	// Flags: [Event|Protected|BlueprintEvent]
	void InitLuaClasses(); // Offset: 0x10149b2f0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SolarGameInstance.SolarGameInstance_C.GoHomeLuaCall
	// Flags: [Event|Public|BlueprintEvent]
	void GoHomeLuaCall(); // Offset: 0x10149b2f0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SolarGameInstance.SolarGameInstance_C.ReportLoadingInfoToBI
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	void ReportLoadingInfoToBI(struct TArray<struct FString>& LoadingInfo, float LoadingTime, bool bIsFinished); // Offset: 0x10149b2f0 // Return & Params: Num(3) Size(0x15)

	// Object Name: Function SolarGameInstance.SolarGameInstance_C.ExecuteBackKeyLuaCall
	// Flags: [Event|Public|BlueprintEvent]
	void ExecuteBackKeyLuaCall(); // Offset: 0x10149b2f0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SolarGameInstance.SolarGameInstance_C.ShutDownPCSDK
	// Flags: [Event|Protected|BlueprintEvent]
	void ShutDownPCSDK(); // Offset: 0x10149b2f0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SolarGameInstance.SolarGameInstance_C.RegisterNetworkManager
	// Flags: [Event|Protected|BlueprintEvent]
	void RegisterNetworkManager(); // Offset: 0x10149b2f0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SolarGameInstance.SolarGameInstance_C.LuaInitGameFrameWork
	// Flags: [Event|Protected|BlueprintEvent]
	void LuaInitGameFrameWork(); // Offset: 0x10149b2f0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SolarGameInstance.SolarGameInstance_C.SolarGM_AddWeaponExpLua
	// Flags: [Event|Public|BlueprintEvent]
	void SolarGM_AddWeaponExpLua(int32_t weaponid, int32_t count); // Offset: 0x10149b2f0 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function SolarGameInstance.SolarGameInstance_C.ReceiveShutdown
	// Flags: [Event|Public|BlueprintEvent]
	void ReceiveShutdown(); // Offset: 0x10149b2f0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SolarGameInstance.SolarGameInstance_C.OnScopeChanged
	// Flags: [Event|Public|BlueprintEvent]
	void OnScopeChanged(enum class EScope InLastScope, enum class EScope InCurScope); // Offset: 0x10149b2f0 // Return & Params: Num(2) Size(0x2)

	// Object Name: Function SolarGameInstance.SolarGameInstance_C.ShutDownLimSdk
	// Flags: [Event|Protected|BlueprintEvent]
	void ShutDownLimSdk(); // Offset: 0x10149b2f0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SolarGameInstance.SolarGameInstance_C.LuaGetBroadcastPlayerNameCopy
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void LuaGetBroadcastPlayerNameCopy(struct FString SolarPlayerID, struct FString& BroadcastPlayerName); // Offset: 0x103938968 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function SolarGameInstance.SolarGameInstance_C.ShutdownAnoSDK
	// Flags: [Event|Protected|BlueprintEvent]
	void ShutdownAnoSDK(); // Offset: 0x10149b2f0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SolarGameInstance.SolarGameInstance_C.OnDisconnect
	// Flags: [Event|Public|BlueprintEvent]
	void OnDisconnect(); // Offset: 0x10149b2f0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SolarGameInstance.SolarGameInstance_C.LuaOnBroadcastModeChanged
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void LuaOnBroadcastModeChanged(); // Offset: 0x103938968 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SolarGameInstance.SolarGameInstance_C.LuaGetBroadcastPlayerName
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void LuaGetBroadcastPlayerName(struct FString SolarPlayerID, struct FString& BroadcastPlayerName); // Offset: 0x10149b2f0 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function SolarGameInstance.SolarGameInstance_C.LuaGetBroadcastHeroName
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void LuaGetBroadcastHeroName(struct FString SolarPlayerID, struct FString& BroadcastPlayerName); // Offset: 0x10149b2f0 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function SolarGameInstance.SolarGameInstance_C.SolarGM_TestCrashWithBP
	// Flags: [Exec|Event|Public|BlueprintEvent]
	void SolarGM_TestCrashWithBP(); // Offset: 0x103938968 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SolarGameInstance.SolarGameInstance_C.SolarGM_TestEnsureMsgWithBP
	// Flags: [Exec|Event|Public|BlueprintEvent]
	void SolarGM_TestEnsureMsgWithBP(); // Offset: 0x103938968 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function SolarGameInstance.SolarGameInstance_C.ExecuteUbergraph_SolarGameInstance
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_SolarGameInstance(int32_t EntryPoint); // Offset: 0x103938968 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function SolarGameInstance.SolarGameInstance_C.OnBroadcastModeChanged__DelegateSignature
	// Flags: [Public|Delegate|BlueprintCallable|BlueprintEvent]
	void OnBroadcastModeChanged__DelegateSignature(); // Offset: 0x103938968 // Return & Params: Num(0) Size(0x0)
};

