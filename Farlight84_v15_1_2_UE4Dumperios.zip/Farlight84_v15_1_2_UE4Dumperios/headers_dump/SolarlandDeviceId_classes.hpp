#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class SolarlandDeviceId.SolarlandDeviceInfoSettings
// Size: 0x48 // Inherited bytes: 0x38
struct USolarlandDeviceInfoSettings : UDeveloperSettings {
	// Fields
	struct FString UserName; // Offset: 0x38 // Size: 0x10

	// Functions

	// Object Name: Function SolarlandDeviceId.SolarlandDeviceInfoSettings.GetInstance
	// Flags: [Final|Native|Static|Public|BlueprintCallable]
	struct USolarlandDeviceInfoSettings* GetInstance(); // Offset: 0x10359e4f0 // Return & Params: Num(1) Size(0x8)
};

