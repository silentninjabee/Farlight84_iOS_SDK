#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class StaticMeshDescription.StaticMeshDescription
// Size: 0x390 // Inherited bytes: 0x390
struct UStaticMeshDescription : UMeshDescriptionBase {
	// Functions

	// Object Name: Function StaticMeshDescription.StaticMeshDescription.SetVertexInstanceUV
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetVertexInstanceUV(struct FVertexInstanceID VertexInstanceID, struct FVector2D UV, int32_t UVIndex); // Offset: 0x104a812bc // Return & Params: Num(3) Size(0x10)

	// Object Name: Function StaticMeshDescription.StaticMeshDescription.SetPolygonGroupMaterialSlotName
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetPolygonGroupMaterialSlotName(struct FPolygonGroupID PolygonGroupID, struct FName& SlotName); // Offset: 0x104a80e58 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function StaticMeshDescription.StaticMeshDescription.GetVertexInstanceUV
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FVector2D GetVertexInstanceUV(struct FVertexInstanceID VertexInstanceID, int32_t UVIndex); // Offset: 0x104a813d8 // Return & Params: Num(3) Size(0x10)

	// Object Name: Function StaticMeshDescription.StaticMeshDescription.CreateCube
	// Flags: [Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable]
	void CreateCube(struct FVector Center, struct FVector HalfExtents, struct FPolygonGroupID PolygonGroup, struct FPolygonID& PolygonID_PlusX, struct FPolygonID& PolygonID_MinusX, struct FPolygonID& PolygonID_PlusY, struct FPolygonID& PolygonID_MinusY, struct FPolygonID& PolygonID_PlusZ, struct FPolygonID& PolygonID_MinusZ); // Offset: 0x104a80f3c // Return & Params: Num(9) Size(0x34)
};

