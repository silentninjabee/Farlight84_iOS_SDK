#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class Synthesis.ModularSynthPresetBank
// Size: 0x38 // Inherited bytes: 0x28
struct UModularSynthPresetBank : UObject {
	// Fields
	struct TArray<struct FModularSynthPresetBankEntry> Presets; // Offset: 0x28 // Size: 0x10
};

// Object Name: Class Synthesis.ModularSynthLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct UModularSynthLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function Synthesis.ModularSynthLibrary.AddModularSynthPresetToBankAsset
	// Flags: [Final|Native|Static|Private|HasOutParms|BlueprintCallable]
	void AddModularSynthPresetToBankAsset(struct UModularSynthPresetBank* InBank, struct FModularSynthPreset& Preset, struct FString PresetName); // Offset: 0x10249b5e0 // Return & Params: Num(3) Size(0xe8)
};

// Object Name: Class Synthesis.ModularSynthComponent
// Size: 0xea0 // Inherited bytes: 0x820
struct UModularSynthComponent : USynthComponent {
	// Fields
	int32_t VoiceCount; // Offset: 0x820 // Size: 0x04
	char pad_0x824[0x67c]; // Offset: 0x824 // Size: 0x67c

	// Functions

	// Object Name: Function Synthesis.ModularSynthComponent.SetSynthPreset
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetSynthPreset(struct FModularSynthPreset& SynthPreset); // Offset: 0x10249bcb0 // Return & Params: Num(1) Size(0xd0)

	// Object Name: Function Synthesis.ModularSynthComponent.SetSustainGain
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSustainGain(float SustainGain); // Offset: 0x10249cc88 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.ModularSynthComponent.SetStereoDelayWetlevel
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetStereoDelayWetlevel(float DelayWetlevel); // Offset: 0x10249c0e0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.ModularSynthComponent.SetStereoDelayTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetStereoDelayTime(float DelayTimeMsec); // Offset: 0x10249c1e0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.ModularSynthComponent.SetStereoDelayRatio
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetStereoDelayRatio(float DelayRatio); // Offset: 0x10249c060 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.ModularSynthComponent.SetStereoDelayMode
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetStereoDelayMode(enum class ESynthStereoDelayMode StereoDelayMode); // Offset: 0x10249c260 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Synthesis.ModularSynthComponent.SetStereoDelayIsEnabled
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetStereoDelayIsEnabled(bool StereoDelayEnabled); // Offset: 0x10249c2e0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Synthesis.ModularSynthComponent.SetStereoDelayFeedback
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetStereoDelayFeedback(float DelayFeedback); // Offset: 0x10249c160 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.ModularSynthComponent.SetSpread
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSpread(float Spread); // Offset: 0x10249d41c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.ModularSynthComponent.SetReleaseTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetReleaseTime(float ReleaseTimeMsec); // Offset: 0x10249cc08 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.ModularSynthComponent.SetPortamento
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPortamento(float Portamento); // Offset: 0x10249d6f8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.ModularSynthComponent.SetPitchBend
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPitchBend(float PitchBend); // Offset: 0x10249d778 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.ModularSynthComponent.SetPan
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPan(float Pan); // Offset: 0x10249d49c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.ModularSynthComponent.SetOscType
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetOscType(int32_t OscIndex, enum class ESynth1OscType OscType); // Offset: 0x10249da5c // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Synthesis.ModularSynthComponent.SetOscSync
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetOscSync(bool bIsSynced); // Offset: 0x10249d51c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Synthesis.ModularSynthComponent.SetOscSemitones
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetOscSemitones(int32_t OscIndex, float Semitones); // Offset: 0x10249d8c4 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Synthesis.ModularSynthComponent.SetOscPulsewidth
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetOscPulsewidth(int32_t OscIndex, float Pulsewidth); // Offset: 0x10249d62c // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Synthesis.ModularSynthComponent.SetOscOctave
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetOscOctave(int32_t OscIndex, float Octave); // Offset: 0x10249d990 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Synthesis.ModularSynthComponent.SetOscGainMod
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetOscGainMod(int32_t OscIndex, float OscGainMod); // Offset: 0x10249dbf4 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Synthesis.ModularSynthComponent.SetOscGain
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetOscGain(int32_t OscIndex, float OscGain); // Offset: 0x10249dcc0 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Synthesis.ModularSynthComponent.SetOscFrequencyMod
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetOscFrequencyMod(int32_t OscIndex, float OscFreqMod); // Offset: 0x10249db28 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Synthesis.ModularSynthComponent.SetOscCents
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetOscCents(int32_t OscIndex, float Cents); // Offset: 0x10249d7f8 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Synthesis.ModularSynthComponent.SetModEnvSustainGain
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetModEnvSustainGain(float SustainGain); // Offset: 0x10249c7f8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.ModularSynthComponent.SetModEnvReleaseTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetModEnvReleaseTime(float Release); // Offset: 0x10249c778 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.ModularSynthComponent.SetModEnvPatch
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetModEnvPatch(enum class ESynthModEnvPatch InPatchType); // Offset: 0x10249cb88 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Synthesis.ModularSynthComponent.SetModEnvInvert
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetModEnvInvert(bool bInvert); // Offset: 0x10249ca80 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Synthesis.ModularSynthComponent.SetModEnvDepth
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetModEnvDepth(float Depth); // Offset: 0x10249c978 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.ModularSynthComponent.SetModEnvDecayTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetModEnvDecayTime(float DecayTimeMsec); // Offset: 0x10249c878 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.ModularSynthComponent.SetModEnvBiasPatch
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetModEnvBiasPatch(enum class ESynthModEnvBiasPatch InPatchType); // Offset: 0x10249cb08 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Synthesis.ModularSynthComponent.SetModEnvBiasInvert
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetModEnvBiasInvert(bool bInvert); // Offset: 0x10249c9f8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Synthesis.ModularSynthComponent.SetModEnvAttackTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetModEnvAttackTime(float AttackTimeMsec); // Offset: 0x10249c8f8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.ModularSynthComponent.SetLFOType
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetLFOType(int32_t LFOIndex, enum class ESynthLFOType LFOType); // Offset: 0x10249d020 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Synthesis.ModularSynthComponent.SetLFOPatch
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetLFOPatch(int32_t LFOIndex, enum class ESynthLFOPatchType LFOPatchType); // Offset: 0x10249ce88 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Synthesis.ModularSynthComponent.SetLFOMode
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetLFOMode(int32_t LFOIndex, enum class ESynthLFOMode LFOMode); // Offset: 0x10249cf54 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Synthesis.ModularSynthComponent.SetLFOGainMod
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetLFOGainMod(int32_t LFOIndex, float GainMod); // Offset: 0x10249d0ec // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Synthesis.ModularSynthComponent.SetLFOGain
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetLFOGain(int32_t LFOIndex, float Gain); // Offset: 0x10249d1b8 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Synthesis.ModularSynthComponent.SetLFOFrequencyMod
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetLFOFrequencyMod(int32_t LFOIndex, float FrequencyModHz); // Offset: 0x10249d284 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Synthesis.ModularSynthComponent.SetLFOFrequency
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetLFOFrequency(int32_t LFOIndex, float FrequencyHz); // Offset: 0x10249d350 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Synthesis.ModularSynthComponent.SetGainDb
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetGainDb(float GainDb); // Offset: 0x10249ce08 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.ModularSynthComponent.SetFilterType
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetFilterType(enum class ESynthFilterType FilterType); // Offset: 0x10249c3e8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Synthesis.ModularSynthComponent.SetFilterQMod
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetFilterQMod(float FilterQ); // Offset: 0x10249c468 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.ModularSynthComponent.SetFilterQ
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetFilterQ(float FilterQ); // Offset: 0x10249c4e8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.ModularSynthComponent.SetFilterFrequencyMod
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetFilterFrequencyMod(float FilterFrequencyHz); // Offset: 0x10249c568 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.ModularSynthComponent.SetFilterFrequency
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetFilterFrequency(float FilterFrequencyHz); // Offset: 0x10249c5e8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.ModularSynthComponent.SetFilterAlgorithm
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetFilterAlgorithm(enum class ESynthFilterAlgorithm FilterAlgorithm); // Offset: 0x10249c368 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Synthesis.ModularSynthComponent.SetEnableUnison
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetEnableUnison(bool EnableUnison); // Offset: 0x10249d5a4 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Synthesis.ModularSynthComponent.SetEnableRetrigger
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetEnableRetrigger(bool RetriggerEnabled); // Offset: 0x10249c668 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Synthesis.ModularSynthComponent.SetEnablePolyphony
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetEnablePolyphony(bool bEnablePolyphony); // Offset: 0x10249dd8c // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Synthesis.ModularSynthComponent.SetEnablePatch
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool SetEnablePatch(struct FPatchId PatchId, bool bIsEnabled); // Offset: 0x10249ba8c // Return & Params: Num(3) Size(0x6)

	// Object Name: Function Synthesis.ModularSynthComponent.SetEnableLegato
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetEnableLegato(bool LegatoEnabled); // Offset: 0x10249c6f0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Synthesis.ModularSynthComponent.SetDecayTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetDecayTime(float DecayTimeMsec); // Offset: 0x10249cd08 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.ModularSynthComponent.SetChorusFrequency
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetChorusFrequency(float Frequency); // Offset: 0x10249be58 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.ModularSynthComponent.SetChorusFeedback
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetChorusFeedback(float Feedback); // Offset: 0x10249bed8 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.ModularSynthComponent.SetChorusEnabled
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetChorusEnabled(bool EnableChorus); // Offset: 0x10249bfd8 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Synthesis.ModularSynthComponent.SetChorusDepth
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetChorusDepth(float Depth); // Offset: 0x10249bf58 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.ModularSynthComponent.SetAttackTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAttackTime(float AttackTimeMsec); // Offset: 0x10249cd88 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.ModularSynthComponent.NoteOn
	// Flags: [Final|Native|Public|BlueprintCallable]
	void NoteOn(float Note, int32_t Velocity, float Duration); // Offset: 0x10249df48 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function Synthesis.ModularSynthComponent.NoteOff
	// Flags: [Final|Native|Public|BlueprintCallable]
	void NoteOff(float Note, bool bAllNotesOff, bool bKillAllNotes); // Offset: 0x10249de14 // Return & Params: Num(3) Size(0x6)

	// Object Name: Function Synthesis.ModularSynthComponent.CreatePatch
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	struct FPatchId CreatePatch(enum class ESynth1PatchSource PatchSource, struct TArray<struct FSynth1PatchCable>& PatchCables, bool bEnableByDefault); // Offset: 0x10249bb70 // Return & Params: Num(4) Size(0x20)
};

// Object Name: Class Synthesis.SourceEffectBitCrusherPreset
// Size: 0x90 // Inherited bytes: 0x40
struct USourceEffectBitCrusherPreset : USoundEffectSourcePreset {
	// Fields
	char pad_0x40[0x48]; // Offset: 0x40 // Size: 0x48
	struct FSourceEffectBitCrusherSettings Settings; // Offset: 0x88 // Size: 0x08

	// Functions

	// Object Name: Function Synthesis.SourceEffectBitCrusherPreset.SetSettings
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetSettings(struct FSourceEffectBitCrusherSettings& InSettings); // Offset: 0x1024a12c0 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class Synthesis.SourceEffectChorusPreset
// Size: 0xb0 // Inherited bytes: 0x40
struct USourceEffectChorusPreset : USoundEffectSourcePreset {
	// Fields
	char pad_0x40[0x58]; // Offset: 0x40 // Size: 0x58
	struct FSourceEffectChorusSettings Settings; // Offset: 0x98 // Size: 0x18

	// Functions

	// Object Name: Function Synthesis.SourceEffectChorusPreset.SetSettings
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetSettings(struct FSourceEffectChorusSettings& InSettings); // Offset: 0x1024a16e0 // Return & Params: Num(1) Size(0x18)
};

// Object Name: Class Synthesis.SourceEffectDynamicsProcessorPreset
// Size: 0xd0 // Inherited bytes: 0x40
struct USourceEffectDynamicsProcessorPreset : USoundEffectSourcePreset {
	// Fields
	char pad_0x40[0x68]; // Offset: 0x40 // Size: 0x68
	struct FSourceEffectDynamicsProcessorSettings Settings; // Offset: 0xa8 // Size: 0x28

	// Functions

	// Object Name: Function Synthesis.SourceEffectDynamicsProcessorPreset.SetSettings
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetSettings(struct FSourceEffectDynamicsProcessorSettings& InSettings); // Offset: 0x1024a1c74 // Return & Params: Num(1) Size(0x28)
};

// Object Name: Class Synthesis.EnvelopeFollowerListener
// Size: 0xd0 // Inherited bytes: 0xb0
struct UEnvelopeFollowerListener : UActorComponent {
	// Fields
	struct FMulticastInlineDelegate OnEnvelopeFollowerUpdate; // Offset: 0xb0 // Size: 0x10
	char pad_0xC0[0x10]; // Offset: 0xc0 // Size: 0x10
};

// Object Name: Class Synthesis.SourceEffectEnvelopeFollowerPreset
// Size: 0x98 // Inherited bytes: 0x40
struct USourceEffectEnvelopeFollowerPreset : USoundEffectSourcePreset {
	// Fields
	char pad_0x40[0x4c]; // Offset: 0x40 // Size: 0x4c
	struct FSourceEffectEnvelopeFollowerSettings Settings; // Offset: 0x8c // Size: 0x0c

	// Functions

	// Object Name: Function Synthesis.SourceEffectEnvelopeFollowerPreset.UnregisterEnvelopeFollowerListener
	// Flags: [Final|Native|Public|BlueprintCallable]
	void UnregisterEnvelopeFollowerListener(struct UEnvelopeFollowerListener* EnvelopeFollowerListener); // Offset: 0x1024a23f4 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Synthesis.SourceEffectEnvelopeFollowerPreset.SetSettings
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetSettings(struct FSourceEffectEnvelopeFollowerSettings& InSettings); // Offset: 0x1024a24f4 // Return & Params: Num(1) Size(0xc)

	// Object Name: Function Synthesis.SourceEffectEnvelopeFollowerPreset.RegisterEnvelopeFollowerListener
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RegisterEnvelopeFollowerListener(struct UEnvelopeFollowerListener* EnvelopeFollowerListener); // Offset: 0x1024a2474 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class Synthesis.SourceEffectEQPreset
// Size: 0xa0 // Inherited bytes: 0x40
struct USourceEffectEQPreset : USoundEffectSourcePreset {
	// Fields
	char pad_0x40[0x50]; // Offset: 0x40 // Size: 0x50
	struct FSourceEffectEQSettings Settings; // Offset: 0x90 // Size: 0x10

	// Functions

	// Object Name: Function Synthesis.SourceEffectEQPreset.SetSettings
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetSettings(struct FSourceEffectEQSettings& InSettings); // Offset: 0x1024a2aa8 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class Synthesis.SourceEffectFilterPreset
// Size: 0x98 // Inherited bytes: 0x40
struct USourceEffectFilterPreset : USoundEffectSourcePreset {
	// Fields
	char pad_0x40[0x4c]; // Offset: 0x40 // Size: 0x4c
	struct FSourceEffectFilterSettings Settings; // Offset: 0x8c // Size: 0x0c

	// Functions

	// Object Name: Function Synthesis.SourceEffectFilterPreset.SetSettings
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetSettings(struct FSourceEffectFilterSettings& InSettings); // Offset: 0x1024a2ffc // Return & Params: Num(1) Size(0xc)
};

// Object Name: Class Synthesis.SourceEffectFoldbackDistortionPreset
// Size: 0x98 // Inherited bytes: 0x40
struct USourceEffectFoldbackDistortionPreset : USoundEffectSourcePreset {
	// Fields
	char pad_0x40[0x4c]; // Offset: 0x40 // Size: 0x4c
	struct FSourceEffectFoldbackDistortionSettings Settings; // Offset: 0x8c // Size: 0x0c

	// Functions

	// Object Name: Function Synthesis.SourceEffectFoldbackDistortionPreset.SetSettings
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetSettings(struct FSourceEffectFoldbackDistortionSettings& InSettings); // Offset: 0x1024a3430 // Return & Params: Num(1) Size(0xc)
};

// Object Name: Class Synthesis.SourceEffectMidSideSpreaderPreset
// Size: 0x98 // Inherited bytes: 0x40
struct USourceEffectMidSideSpreaderPreset : USoundEffectSourcePreset {
	// Fields
	char pad_0x40[0x4c]; // Offset: 0x40 // Size: 0x4c
	struct FSourceEffectMidSideSpreaderSettings Settings; // Offset: 0x8c // Size: 0x0c

	// Functions

	// Object Name: Function Synthesis.SourceEffectMidSideSpreaderPreset.SetSettings
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetSettings(struct FSourceEffectMidSideSpreaderSettings& InSettings); // Offset: 0x1024a3908 // Return & Params: Num(1) Size(0xc)
};

// Object Name: Class Synthesis.SourceEffectPannerPreset
// Size: 0x90 // Inherited bytes: 0x40
struct USourceEffectPannerPreset : USoundEffectSourcePreset {
	// Fields
	char pad_0x40[0x48]; // Offset: 0x40 // Size: 0x48
	struct FSourceEffectPannerSettings Settings; // Offset: 0x88 // Size: 0x08

	// Functions

	// Object Name: Function Synthesis.SourceEffectPannerPreset.SetSettings
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetSettings(struct FSourceEffectPannerSettings& InSettings); // Offset: 0x1024a3d40 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class Synthesis.SourceEffectPhaserPreset
// Size: 0xa0 // Inherited bytes: 0x40
struct USourceEffectPhaserPreset : USoundEffectSourcePreset {
	// Fields
	char pad_0x40[0x50]; // Offset: 0x40 // Size: 0x50
	struct FSourceEffectPhaserSettings Settings; // Offset: 0x90 // Size: 0x10

	// Functions

	// Object Name: Function Synthesis.SourceEffectPhaserPreset.SetSettings
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetSettings(struct FSourceEffectPhaserSettings& InSettings); // Offset: 0x1024a4204 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class Synthesis.SourceEffectRingModulationPreset
// Size: 0xa8 // Inherited bytes: 0x40
struct USourceEffectRingModulationPreset : USoundEffectSourcePreset {
	// Fields
	char pad_0x40[0x54]; // Offset: 0x40 // Size: 0x54
	struct FSourceEffectRingModulationSettings Settings; // Offset: 0x94 // Size: 0x14

	// Functions

	// Object Name: Function Synthesis.SourceEffectRingModulationPreset.SetSettings
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetSettings(struct FSourceEffectRingModulationSettings& InSettings); // Offset: 0x1024a46e8 // Return & Params: Num(1) Size(0x14)
};

// Object Name: Class Synthesis.SourceEffectSimpleDelayPreset
// Size: 0xb0 // Inherited bytes: 0x40
struct USourceEffectSimpleDelayPreset : USoundEffectSourcePreset {
	// Fields
	char pad_0x40[0x58]; // Offset: 0x40 // Size: 0x58
	struct FSourceEffectSimpleDelaySettings Settings; // Offset: 0x98 // Size: 0x18

	// Functions

	// Object Name: Function Synthesis.SourceEffectSimpleDelayPreset.SetSettings
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetSettings(struct FSourceEffectSimpleDelaySettings& InSettings); // Offset: 0x1024a4b24 // Return & Params: Num(1) Size(0x18)
};

// Object Name: Class Synthesis.SourceEffectStereoDelayPreset
// Size: 0xa8 // Inherited bytes: 0x40
struct USourceEffectStereoDelayPreset : USoundEffectSourcePreset {
	// Fields
	char pad_0x40[0x54]; // Offset: 0x40 // Size: 0x54
	struct FSourceEffectStereoDelaySettings Settings; // Offset: 0x94 // Size: 0x14

	// Functions

	// Object Name: Function Synthesis.SourceEffectStereoDelayPreset.SetSettings
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetSettings(struct FSourceEffectStereoDelaySettings& InSettings); // Offset: 0x1024a500c // Return & Params: Num(1) Size(0x14)
};

// Object Name: Class Synthesis.SourceEffectWaveShaperPreset
// Size: 0x90 // Inherited bytes: 0x40
struct USourceEffectWaveShaperPreset : USoundEffectSourcePreset {
	// Fields
	char pad_0x40[0x48]; // Offset: 0x40 // Size: 0x48
	struct FSourceEffectWaveShaperSettings Settings; // Offset: 0x88 // Size: 0x08

	// Functions

	// Object Name: Function Synthesis.SourceEffectWaveShaperPreset.SetSettings
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetSettings(struct FSourceEffectWaveShaperSettings& InSettings); // Offset: 0x1024a5440 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class Synthesis.AudioImpulseResponse
// Size: 0x58 // Inherited bytes: 0x28
struct UAudioImpulseResponse : UObject {
	// Fields
	struct TArray<float> ImpulseResponse; // Offset: 0x28 // Size: 0x10
	int32_t NumChannels; // Offset: 0x38 // Size: 0x04
	int32_t SampleRate; // Offset: 0x3c // Size: 0x04
	float NormalizationVolumeDb; // Offset: 0x40 // Size: 0x04
	char pad_0x44[0x4]; // Offset: 0x44 // Size: 0x04
	struct TArray<float> IRData; // Offset: 0x48 // Size: 0x10
};

// Object Name: Class Synthesis.SubmixEffectConvolutionReverbPreset
// Size: 0xd0 // Inherited bytes: 0x40
struct USubmixEffectConvolutionReverbPreset : USoundEffectSubmixPreset {
	// Fields
	struct FSubmixEffectConvolutionReverbSettings Settings; // Offset: 0x40 // Size: 0x20
	struct UAudioImpulseResponse* ImpulseResponse; // Offset: 0x60 // Size: 0x08
	enum class ESubmixEffectConvolutionReverbBlockSize BlockSize; // Offset: 0x68 // Size: 0x01
	bool bEnableHardwareAcceleration; // Offset: 0x69 // Size: 0x01
	char pad_0x6A[0x66]; // Offset: 0x6a // Size: 0x66

	// Functions

	// Object Name: Function Synthesis.SubmixEffectConvolutionReverbPreset.SetSettings
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetSettings(struct FSubmixEffectConvolutionReverbSettings& InSettings); // Offset: 0x1024a5b64 // Return & Params: Num(1) Size(0x20)

	// Object Name: Function Synthesis.SubmixEffectConvolutionReverbPreset.SetImpulseResponse
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetImpulseResponse(struct UAudioImpulseResponse* InImpulseResponse); // Offset: 0x1024a5ae4 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class Synthesis.SubmixEffectDelayPreset
// Size: 0xa8 // Inherited bytes: 0x40
struct USubmixEffectDelayPreset : USoundEffectSubmixPreset {
	// Fields
	char pad_0x40[0x4c]; // Offset: 0x40 // Size: 0x4c
	struct FSubmixEffectDelaySettings Settings; // Offset: 0x8c // Size: 0x0c
	struct FSubmixEffectDelaySettings DynamicSettings; // Offset: 0x98 // Size: 0x0c
	char pad_0xA4[0x4]; // Offset: 0xa4 // Size: 0x04

	// Functions

	// Object Name: Function Synthesis.SubmixEffectDelayPreset.SetSettings
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetSettings(struct FSubmixEffectDelaySettings& InSettings); // Offset: 0x1024acf70 // Return & Params: Num(1) Size(0xc)

	// Object Name: Function Synthesis.SubmixEffectDelayPreset.SetInterpolationTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetInterpolationTime(float Time); // Offset: 0x1024aced4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.SubmixEffectDelayPreset.SetDelay
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetDelay(float Length); // Offset: 0x1024ace54 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.SubmixEffectDelayPreset.GetMaxDelayInMilliseconds
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetMaxDelayInMilliseconds(); // Offset: 0x1024acf54 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class Synthesis.SubmixEffectFilterPreset
// Size: 0x98 // Inherited bytes: 0x40
struct USubmixEffectFilterPreset : USoundEffectSubmixPreset {
	// Fields
	char pad_0x40[0x4c]; // Offset: 0x40 // Size: 0x4c
	struct FSubmixEffectFilterSettings Settings; // Offset: 0x8c // Size: 0x0c

	// Functions

	// Object Name: Function Synthesis.SubmixEffectFilterPreset.SetSettings
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetSettings(struct FSubmixEffectFilterSettings& InSettings); // Offset: 0x1024ad980 // Return & Params: Num(1) Size(0xc)

	// Object Name: Function Synthesis.SubmixEffectFilterPreset.SetFilterType
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetFilterType(enum class ESubmixFilterType InType); // Offset: 0x1024ad900 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Synthesis.SubmixEffectFilterPreset.SetFilterQMod
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetFilterQMod(float InQ); // Offset: 0x1024ad680 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.SubmixEffectFilterPreset.SetFilterQ
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetFilterQ(float InQ); // Offset: 0x1024ad700 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.SubmixEffectFilterPreset.SetFilterCutoffFrequencyMod
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetFilterCutoffFrequencyMod(float InFrequency); // Offset: 0x1024ad780 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.SubmixEffectFilterPreset.SetFilterCutoffFrequency
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetFilterCutoffFrequency(float InFrequency); // Offset: 0x1024ad800 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.SubmixEffectFilterPreset.SetFilterAlgorithm
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetFilterAlgorithm(enum class ESubmixFilterAlgorithm InAlgorithm); // Offset: 0x1024ad880 // Return & Params: Num(1) Size(0x1)
};

// Object Name: Class Synthesis.SubmixEffectFlexiverbPreset
// Size: 0xa0 // Inherited bytes: 0x40
struct USubmixEffectFlexiverbPreset : USoundEffectSubmixPreset {
	// Fields
	char pad_0x40[0x50]; // Offset: 0x40 // Size: 0x50
	struct FSubmixEffectFlexiverbSettings Settings; // Offset: 0x90 // Size: 0x10

	// Functions

	// Object Name: Function Synthesis.SubmixEffectFlexiverbPreset.SetSettings
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetSettings(struct FSubmixEffectFlexiverbSettings& InSettings); // Offset: 0x1024adf74 // Return & Params: Num(1) Size(0x10)
};

// Object Name: Class Synthesis.SubmixEffectTapDelayPreset
// Size: 0xc8 // Inherited bytes: 0x40
struct USubmixEffectTapDelayPreset : USoundEffectSubmixPreset {
	// Fields
	char pad_0x40[0x58]; // Offset: 0x40 // Size: 0x58
	struct FSubmixEffectTapDelaySettings Settings; // Offset: 0x98 // Size: 0x18
	char pad_0xB0[0x18]; // Offset: 0xb0 // Size: 0x18

	// Functions

	// Object Name: Function Synthesis.SubmixEffectTapDelayPreset.SetTap
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetTap(int32_t TapId, struct FTapDelayInfo& TapInfo); // Offset: 0x1024ae738 // Return & Params: Num(2) Size(0x1c)

	// Object Name: Function Synthesis.SubmixEffectTapDelayPreset.SetSettings
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void SetSettings(struct FSubmixEffectTapDelaySettings& InSettings); // Offset: 0x1024ae924 // Return & Params: Num(1) Size(0x18)

	// Object Name: Function Synthesis.SubmixEffectTapDelayPreset.SetInterpolationTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetInterpolationTime(float Time); // Offset: 0x1024ae524 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.SubmixEffectTapDelayPreset.RemoveTap
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RemoveTap(int32_t TapId); // Offset: 0x1024ae818 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.SubmixEffectTapDelayPreset.GetTapIds
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void GetTapIds(struct TArray<int32_t>& TapIds); // Offset: 0x1024ae5c0 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Synthesis.SubmixEffectTapDelayPreset.GetTap
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void GetTap(int32_t TapId, struct FTapDelayInfo& TapInfo); // Offset: 0x1024ae658 // Return & Params: Num(2) Size(0x1c)

	// Object Name: Function Synthesis.SubmixEffectTapDelayPreset.GetMaxDelayInMilliseconds
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetMaxDelayInMilliseconds(); // Offset: 0x1024ae5a4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.SubmixEffectTapDelayPreset.AddTap
	// Flags: [Final|Native|Public|HasOutParms|BlueprintCallable]
	void AddTap(int32_t& TapId); // Offset: 0x1024ae898 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class Synthesis.Synth2DSlider
// Size: 0x670 // Inherited bytes: 0x138
struct USynth2DSlider : UWidget {
	// Fields
	float ValueX; // Offset: 0x138 // Size: 0x04
	float ValueY; // Offset: 0x13c // Size: 0x04
	struct FDelegate ValueXDelegate; // Offset: 0x140 // Size: 0x10
	struct FDelegate ValueYDelegate; // Offset: 0x150 // Size: 0x10
	struct FSynth2DSliderStyle WidgetStyle; // Offset: 0x160 // Size: 0x480
	struct FLinearColor SliderHandleColor; // Offset: 0x5e0 // Size: 0x10
	bool IndentHandle; // Offset: 0x5f0 // Size: 0x01
	bool Locked; // Offset: 0x5f1 // Size: 0x01
	char pad_0x5F2[0x2]; // Offset: 0x5f2 // Size: 0x02
	float StepSize; // Offset: 0x5f4 // Size: 0x04
	bool IsFocusable; // Offset: 0x5f8 // Size: 0x01
	char pad_0x5F9[0x7]; // Offset: 0x5f9 // Size: 0x07
	struct FMulticastInlineDelegate OnMouseCaptureBegin; // Offset: 0x600 // Size: 0x10
	struct FMulticastInlineDelegate OnMouseCaptureEnd; // Offset: 0x610 // Size: 0x10
	struct FMulticastInlineDelegate OnControllerCaptureBegin; // Offset: 0x620 // Size: 0x10
	struct FMulticastInlineDelegate OnControllerCaptureEnd; // Offset: 0x630 // Size: 0x10
	struct FMulticastInlineDelegate OnValueChangedX; // Offset: 0x640 // Size: 0x10
	struct FMulticastInlineDelegate OnValueChangedY; // Offset: 0x650 // Size: 0x10
	char pad_0x660[0x10]; // Offset: 0x660 // Size: 0x10

	// Functions

	// Object Name: Function Synthesis.Synth2DSlider.SetValue
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetValue(struct FVector2D InValue); // Offset: 0x1024af2ec // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Synthesis.Synth2DSlider.SetStepSize
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetStepSize(float InValue); // Offset: 0x1024af15c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.Synth2DSlider.SetSliderHandleColor
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetSliderHandleColor(struct FLinearColor InValue); // Offset: 0x1024af0dc // Return & Params: Num(1) Size(0x10)

	// Object Name: Function Synthesis.Synth2DSlider.SetLocked
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetLocked(bool InValue); // Offset: 0x1024af1dc // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Synthesis.Synth2DSlider.SetIndentHandle
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetIndentHandle(bool InValue); // Offset: 0x1024af264 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Synthesis.Synth2DSlider.GetValue
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const]
	struct FVector2D GetValue(); // Offset: 0x1024af368 // Return & Params: Num(1) Size(0x8)
};

// Object Name: Class Synthesis.GranularSynth
// Size: 0xbe0 // Inherited bytes: 0x820
struct UGranularSynth : USynthComponent {
	// Fields
	struct USoundWave* GranulatedSoundWave; // Offset: 0x820 // Size: 0x08
	char pad_0x828[0x3b8]; // Offset: 0x828 // Size: 0x3b8

	// Functions

	// Object Name: Function Synthesis.GranularSynth.SetSustainGain
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSustainGain(float SustainGain); // Offset: 0x1024b033c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.GranularSynth.SetSoundWave
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSoundWave(struct USoundWave* InSoundWave); // Offset: 0x1024b04bc // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Synthesis.GranularSynth.SetScrubMode
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetScrubMode(bool bScrubMode); // Offset: 0x1024afb04 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Synthesis.GranularSynth.SetReleaseTimeMsec
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetReleaseTimeMsec(float ReleaseTimeMsec); // Offset: 0x1024b02bc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.GranularSynth.SetPlayheadTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPlayheadTime(float InPositionSec, float LerpTimeSec, enum class EGranularSynthSeekType SeekType); // Offset: 0x1024af9f0 // Return & Params: Num(3) Size(0x9)

	// Object Name: Function Synthesis.GranularSynth.SetPlaybackSpeed
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPlaybackSpeed(float InPlayheadRate); // Offset: 0x1024afed0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.GranularSynth.SetGrainVolume
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetGrainVolume(float BaseVolume, struct FVector2D VolumeRange); // Offset: 0x1024afd48 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Synthesis.GranularSynth.SetGrainsPerSecond
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetGrainsPerSecond(float InGrainsPerSecond); // Offset: 0x1024b0050 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.GranularSynth.SetGrainProbability
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetGrainProbability(float InGrainProbability); // Offset: 0x1024affd0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.GranularSynth.SetGrainPitch
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetGrainPitch(float BasePitch, struct FVector2D PitchRange); // Offset: 0x1024afe0c // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Synthesis.GranularSynth.SetGrainPan
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetGrainPan(float BasePan, struct FVector2D PanRange); // Offset: 0x1024afc84 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Synthesis.GranularSynth.SetGrainEnvelopeType
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetGrainEnvelopeType(enum class EGranularSynthEnvelopeType EnvelopeType); // Offset: 0x1024aff50 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Synthesis.GranularSynth.SetGrainDuration
	// Flags: [Final|Native|Public|HasDefaults|BlueprintCallable]
	void SetGrainDuration(float BaseDurationMsec, struct FVector2D DurationRange); // Offset: 0x1024afbc0 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function Synthesis.GranularSynth.SetDecayTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetDecayTime(float DecayTimeMsec); // Offset: 0x1024b03bc // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.GranularSynth.SetAttackTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAttackTime(float AttackTimeMsec); // Offset: 0x1024b043c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.GranularSynth.NoteOn
	// Flags: [Final|Native|Public|BlueprintCallable]
	void NoteOn(float Note, int32_t Velocity, float Duration); // Offset: 0x1024b01a4 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function Synthesis.GranularSynth.NoteOff
	// Flags: [Final|Native|Public|BlueprintCallable]
	void NoteOff(float Note, bool bKill); // Offset: 0x1024b00d0 // Return & Params: Num(2) Size(0x5)

	// Object Name: Function Synthesis.GranularSynth.IsLoaded
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsLoaded(); // Offset: 0x1024af988 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Synthesis.GranularSynth.GetSampleDuration
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetSampleDuration(); // Offset: 0x1024afb8c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.GranularSynth.GetCurrentPlayheadTime
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetCurrentPlayheadTime(); // Offset: 0x1024af9bc // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class Synthesis.MonoWaveTableSynthPreset
// Size: 0x170 // Inherited bytes: 0x28
struct UMonoWaveTableSynthPreset : UObject {
	// Fields
	struct FString PresetName; // Offset: 0x28 // Size: 0x10
	char bLockKeyframesToGridBool : 1; // Offset: 0x38 // Size: 0x01
	char pad_0x38_1 : 7; // Offset: 0x38 // Size: 0x01
	char pad_0x39[0x3]; // Offset: 0x39 // Size: 0x03
	int32_t LockKeyframesToGrid; // Offset: 0x3c // Size: 0x04
	int32_t WaveTableResolution; // Offset: 0x40 // Size: 0x04
	char pad_0x44[0x4]; // Offset: 0x44 // Size: 0x04
	struct TArray<struct FRuntimeFloatCurve> WaveTable; // Offset: 0x48 // Size: 0x10
	char bNormalizeWaveTables : 1; // Offset: 0x58 // Size: 0x01
	char pad_0x58_1 : 7; // Offset: 0x58 // Size: 0x01
	char pad_0x59[0x117]; // Offset: 0x59 // Size: 0x117
};

// Object Name: Class Synthesis.SynthComponentMonoWaveTable
// Size: 0xf40 // Inherited bytes: 0x820
struct USynthComponentMonoWaveTable : USynthComponent {
	// Fields
	struct FMulticastInlineDelegate OnTableAltered; // Offset: 0x820 // Size: 0x10
	struct FMulticastInlineDelegate OnNumTablesChanged; // Offset: 0x830 // Size: 0x10
	struct UMonoWaveTableSynthPreset* CurrentPreset; // Offset: 0x840 // Size: 0x08
	char pad_0x848[0x6f8]; // Offset: 0x848 // Size: 0x6f8

	// Functions

	// Object Name: Function Synthesis.SynthComponentMonoWaveTable.SetWaveTablePosition
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetWaveTablePosition(float InPosition); // Offset: 0x1024b2404 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.SynthComponentMonoWaveTable.SetSustainPedalState
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSustainPedalState(bool InSustainPedalState); // Offset: 0x1024b2604 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Synthesis.SynthComponentMonoWaveTable.SetPosLfoType
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPosLfoType(enum class ESynthLFOType InLfoType); // Offset: 0x1024b21f0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Synthesis.SynthComponentMonoWaveTable.SetPosLfoFrequency
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPosLfoFrequency(float InLfoFrequency); // Offset: 0x1024b22f0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.SynthComponentMonoWaveTable.SetPosLfoDepth
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPosLfoDepth(float InLfoDepth); // Offset: 0x1024b2270 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.SynthComponentMonoWaveTable.SetPositionEnvelopeSustainGain
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPositionEnvelopeSustainGain(float InSustainGain); // Offset: 0x1024b1750 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.SynthComponentMonoWaveTable.SetPositionEnvelopeReleaseTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPositionEnvelopeReleaseTime(float InReleaseTimeMsec); // Offset: 0x1024b16d0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.SynthComponentMonoWaveTable.SetPositionEnvelopeInvert
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPositionEnvelopeInvert(bool bInInvert); // Offset: 0x1024b1648 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Synthesis.SynthComponentMonoWaveTable.SetPositionEnvelopeDepth
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPositionEnvelopeDepth(float InDepth); // Offset: 0x1024b1540 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.SynthComponentMonoWaveTable.SetPositionEnvelopeDecayTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPositionEnvelopeDecayTime(float InDecayTimeMsec); // Offset: 0x1024b17d0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.SynthComponentMonoWaveTable.SetPositionEnvelopeBiasInvert
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPositionEnvelopeBiasInvert(bool bInBiasInvert); // Offset: 0x1024b15c0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Synthesis.SynthComponentMonoWaveTable.SetPositionEnvelopeBiasDepth
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPositionEnvelopeBiasDepth(float InDepth); // Offset: 0x1024b14c0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.SynthComponentMonoWaveTable.SetPositionEnvelopeAttackTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPositionEnvelopeAttackTime(float InAttackTimeMsec); // Offset: 0x1024b1850 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.SynthComponentMonoWaveTable.SetLowPassFilterResonance
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetLowPassFilterResonance(float InNewQ); // Offset: 0x1024b20f0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.SynthComponentMonoWaveTable.SetLowPassFilterFrequency
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetLowPassFilterFrequency(float InNewFrequency); // Offset: 0x1024b2170 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.SynthComponentMonoWaveTable.SetFrequencyWithMidiNote
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetFrequencyWithMidiNote(float InMidiNote); // Offset: 0x1024b2484 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.SynthComponentMonoWaveTable.SetFrequencyPitchBend
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetFrequencyPitchBend(float FrequencyOffsetCents); // Offset: 0x1024b2504 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.SynthComponentMonoWaveTable.SetFrequency
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetFrequency(float FrequencyHz); // Offset: 0x1024b2584 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.SynthComponentMonoWaveTable.SetFilterEnvelopeSustainGain
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetFilterEnvelopeSustainGain(float InSustainGain); // Offset: 0x1024b1b60 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.SynthComponentMonoWaveTable.SetFilterEnvelopeReleaseTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetFilterEnvelopeReleaseTime(float InReleaseTimeMsec); // Offset: 0x1024b1ae0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.SynthComponentMonoWaveTable.SetFilterEnvelopenDecayTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetFilterEnvelopenDecayTime(float InDecayTimeMsec); // Offset: 0x1024b1be0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.SynthComponentMonoWaveTable.SetFilterEnvelopeInvert
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetFilterEnvelopeInvert(bool bInInvert); // Offset: 0x1024b1a58 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Synthesis.SynthComponentMonoWaveTable.SetFilterEnvelopeDepth
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetFilterEnvelopeDepth(float InDepth); // Offset: 0x1024b1950 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.SynthComponentMonoWaveTable.SetFilterEnvelopeBiasInvert
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetFilterEnvelopeBiasInvert(bool bInBiasInvert); // Offset: 0x1024b19d0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Synthesis.SynthComponentMonoWaveTable.SetFilterEnvelopeBiasDepth
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetFilterEnvelopeBiasDepth(float InDepth); // Offset: 0x1024b18d0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.SynthComponentMonoWaveTable.SetFilterEnvelopeAttackTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetFilterEnvelopeAttackTime(float InAttackTimeMsec); // Offset: 0x1024b1c60 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.SynthComponentMonoWaveTable.SetCurveValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool SetCurveValue(int32_t TableIndex, int32_t KeyframeIndex, float NewValue); // Offset: 0x1024b1368 // Return & Params: Num(4) Size(0xd)

	// Object Name: Function Synthesis.SynthComponentMonoWaveTable.SetCurveTangent
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool SetCurveTangent(int32_t TableIndex, float InNewTangent); // Offset: 0x1024b11b0 // Return & Params: Num(3) Size(0x9)

	// Object Name: Function Synthesis.SynthComponentMonoWaveTable.SetCurveInterpolationType
	// Flags: [Final|Native|Public|BlueprintCallable]
	bool SetCurveInterpolationType(enum class CurveInterpolationType InterpolationType, int32_t TableIndex); // Offset: 0x1024b128c // Return & Params: Num(3) Size(0x9)

	// Object Name: Function Synthesis.SynthComponentMonoWaveTable.SetAmpEnvelopeSustainGain
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAmpEnvelopeSustainGain(float InSustainGain); // Offset: 0x1024b1f70 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.SynthComponentMonoWaveTable.SetAmpEnvelopeReleaseTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAmpEnvelopeReleaseTime(float InReleaseTimeMsec); // Offset: 0x1024b1ef0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.SynthComponentMonoWaveTable.SetAmpEnvelopeInvert
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAmpEnvelopeInvert(bool bInInvert); // Offset: 0x1024b1e68 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Synthesis.SynthComponentMonoWaveTable.SetAmpEnvelopeDepth
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAmpEnvelopeDepth(float InDepth); // Offset: 0x1024b1d60 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.SynthComponentMonoWaveTable.SetAmpEnvelopeDecayTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAmpEnvelopeDecayTime(float InDecayTimeMsec); // Offset: 0x1024b1ff0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.SynthComponentMonoWaveTable.SetAmpEnvelopeBiasInvert
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAmpEnvelopeBiasInvert(bool bInBiasInvert); // Offset: 0x1024b1de0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Synthesis.SynthComponentMonoWaveTable.SetAmpEnvelopeBiasDepth
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAmpEnvelopeBiasDepth(float InDepth); // Offset: 0x1024b1ce0 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.SynthComponentMonoWaveTable.SetAmpEnvelopeAttackTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetAmpEnvelopeAttackTime(float InAttackTimeMsec); // Offset: 0x1024b2070 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.SynthComponentMonoWaveTable.RefreshWaveTable
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RefreshWaveTable(int32_t Index); // Offset: 0x1024b2384 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.SynthComponentMonoWaveTable.RefreshAllWaveTables
	// Flags: [Final|Native|Public|BlueprintCallable]
	void RefreshAllWaveTables(); // Offset: 0x1024b2370 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function Synthesis.SynthComponentMonoWaveTable.NoteOn
	// Flags: [Final|Native|Public|BlueprintCallable]
	void NoteOn(float InMidiNote, float InVelocity); // Offset: 0x1024b270c // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Synthesis.SynthComponentMonoWaveTable.NoteOff
	// Flags: [Final|Native|Public|BlueprintCallable]
	void NoteOff(float InMidiNote); // Offset: 0x1024b268c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.SynthComponentMonoWaveTable.GetNumTableEntries
	// Flags: [Final|Native|Public|BlueprintCallable]
	int32_t GetNumTableEntries(); // Offset: 0x1024b27d4 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.SynthComponentMonoWaveTable.GetMaxTableIndex
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	int32_t GetMaxTableIndex(); // Offset: 0x1024b148c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.SynthComponentMonoWaveTable.GetKeyFrameValuesForTable
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	struct TArray<float> GetKeyFrameValuesForTable(float TableIndex); // Offset: 0x1024b1048 // Return & Params: Num(2) Size(0x18)

	// Object Name: Function Synthesis.SynthComponentMonoWaveTable.GetCurveTangent
	// Flags: [Final|Native|Public|BlueprintCallable]
	float GetCurveTangent(int32_t TableIndex); // Offset: 0x1024b1120 // Return & Params: Num(2) Size(0x8)
};

// Object Name: Class Synthesis.SynthSamplePlayer
// Size: 0x950 // Inherited bytes: 0x820
struct USynthSamplePlayer : USynthComponent {
	// Fields
	struct USoundWave* SoundWave; // Offset: 0x820 // Size: 0x08
	struct FMulticastInlineDelegate OnSampleLoaded; // Offset: 0x828 // Size: 0x10
	struct FMulticastInlineDelegate OnSamplePlaybackProgress; // Offset: 0x838 // Size: 0x10
	char pad_0x848[0x108]; // Offset: 0x848 // Size: 0x108

	// Functions

	// Object Name: Function Synthesis.SynthSamplePlayer.SetSoundWave
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetSoundWave(struct USoundWave* InSoundWave); // Offset: 0x1024b5d60 // Return & Params: Num(1) Size(0x8)

	// Object Name: Function Synthesis.SynthSamplePlayer.SetScrubTimeWidth
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetScrubTimeWidth(float InScrubTimeWidthSec); // Offset: 0x1024b5a70 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.SynthSamplePlayer.SetScrubMode
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetScrubMode(bool bScrubMode); // Offset: 0x1024b5af0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Synthesis.SynthSamplePlayer.SetPitch
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetPitch(float InPitch, float TimeSec); // Offset: 0x1024b5c98 // Return & Params: Num(2) Size(0x8)

	// Object Name: Function Synthesis.SynthSamplePlayer.SeekToTime
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SeekToTime(float TimeSec, enum class ESamplePlayerSeekType SeekType, bool bWrap); // Offset: 0x1024b5b78 // Return & Params: Num(3) Size(0x6)

	// Object Name: Function Synthesis.SynthSamplePlayer.IsLoaded
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	bool IsLoaded(); // Offset: 0x1024b59a0 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Synthesis.SynthSamplePlayer.GetSampleDuration
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetSampleDuration(); // Offset: 0x1024b5a3c // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.SynthSamplePlayer.GetCurrentPlaybackProgressTime
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetCurrentPlaybackProgressTime(); // Offset: 0x1024b5a08 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.SynthSamplePlayer.GetCurrentPlaybackProgressPercent
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetCurrentPlaybackProgressPercent(); // Offset: 0x1024b59d4 // Return & Params: Num(1) Size(0x4)
};

// Object Name: Class Synthesis.SynthKnob
// Size: 0x5a0 // Inherited bytes: 0x138
struct USynthKnob : UWidget {
	// Fields
	float Value; // Offset: 0x138 // Size: 0x04
	float StepSize; // Offset: 0x13c // Size: 0x04
	float MouseSpeed; // Offset: 0x140 // Size: 0x04
	float MouseFineTuneSpeed; // Offset: 0x144 // Size: 0x04
	char ShowTooltipInfo : 1; // Offset: 0x148 // Size: 0x01
	char pad_0x148_1 : 7; // Offset: 0x148 // Size: 0x01
	char pad_0x149[0x7]; // Offset: 0x149 // Size: 0x07
	struct FText ParameterName; // Offset: 0x150 // Size: 0x18
	struct FText ParameterUnits; // Offset: 0x168 // Size: 0x18
	struct FDelegate ValueDelegate; // Offset: 0x180 // Size: 0x10
	struct FSynthKnobStyle WidgetStyle; // Offset: 0x190 // Size: 0x3a0
	bool Locked; // Offset: 0x530 // Size: 0x01
	bool IsFocusable; // Offset: 0x531 // Size: 0x01
	char pad_0x532[0x6]; // Offset: 0x532 // Size: 0x06
	struct FMulticastInlineDelegate OnMouseCaptureBegin; // Offset: 0x538 // Size: 0x10
	struct FMulticastInlineDelegate OnMouseCaptureEnd; // Offset: 0x548 // Size: 0x10
	struct FMulticastInlineDelegate OnControllerCaptureBegin; // Offset: 0x558 // Size: 0x10
	struct FMulticastInlineDelegate OnControllerCaptureEnd; // Offset: 0x568 // Size: 0x10
	struct FMulticastInlineDelegate OnValueChanged; // Offset: 0x578 // Size: 0x10
	char pad_0x588[0x18]; // Offset: 0x588 // Size: 0x18

	// Functions

	// Object Name: Function Synthesis.SynthKnob.SetValue
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetValue(float InValue); // Offset: 0x1024b6510 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.SynthKnob.SetStepSize
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetStepSize(float InValue); // Offset: 0x1024b6408 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function Synthesis.SynthKnob.SetLocked
	// Flags: [Final|Native|Public|BlueprintCallable]
	void SetLocked(bool InValue); // Offset: 0x1024b6488 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function Synthesis.SynthKnob.GetValue
	// Flags: [Final|Native|Public|BlueprintCallable|BlueprintPure|Const]
	float GetValue(); // Offset: 0x1024b6590 // Return & Params: Num(1) Size(0x4)
};

