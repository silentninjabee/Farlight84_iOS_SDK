#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct TemplateSequence.TemplateSequenceBindingOverrideData
// Size: 0x0c // Inherited bytes: 0x00
struct FTemplateSequenceBindingOverrideData {
	// Fields
	struct TWeakObjectPtr<struct UObject> Object; // Offset: 0x00 // Size: 0x08
	bool bOverridesDefault; // Offset: 0x08 // Size: 0x01
	char pad_0x9[0x3]; // Offset: 0x09 // Size: 0x03
};

// Object Name: ScriptStruct TemplateSequence.TemplateSequenceInstanceData
// Size: 0x20 // Inherited bytes: 0x08
struct FTemplateSequenceInstanceData : FMovieSceneSequenceInstanceData {
	// Fields
	struct FMovieSceneEvaluationOperand Operand; // Offset: 0x08 // Size: 0x14
	char pad_0x1C[0x4]; // Offset: 0x1c // Size: 0x04
};

// Object Name: ScriptStruct TemplateSequence.TemplateSequenceSectionTemplate
// Size: 0x40 // Inherited bytes: 0x18
struct FTemplateSequenceSectionTemplate : FMovieSceneEvalTemplate {
	// Fields
	struct FFrameNumber SectionStartTime; // Offset: 0x14 // Size: 0x04
	struct FGuid OuterBindingId; // Offset: 0x18 // Size: 0x10
	struct FMovieSceneEvaluationOperand InnerOperand; // Offset: 0x28 // Size: 0x14
};

