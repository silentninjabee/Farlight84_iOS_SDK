#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Class TimeManagement.FixedFrameRateCustomTimeStep
// Size: 0x30 // Inherited bytes: 0x28
struct UFixedFrameRateCustomTimeStep : UEngineCustomTimeStep {
	// Fields
	struct FFrameRate FixedFrameRate; // Offset: 0x28 // Size: 0x08
};

// Object Name: Class TimeManagement.TimeManagementBlueprintLibrary
// Size: 0x28 // Inherited bytes: 0x28
struct UTimeManagementBlueprintLibrary : UBlueprintFunctionLibrary {
	// Functions

	// Object Name: Function TimeManagement.TimeManagementBlueprintLibrary.TransformTime
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FFrameTime TransformTime(struct FFrameTime& SourceTime, struct FFrameRate& SourceRate, struct FFrameRate& DestinationRate); // Offset: 0x1046b6abc // Return & Params: Num(4) Size(0x20)

	// Object Name: Function TimeManagement.TimeManagementBlueprintLibrary.Subtract_FrameNumberInteger
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	struct FFrameNumber Subtract_FrameNumberInteger(struct FFrameNumber A, int32_t B); // Offset: 0x1046b6648 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function TimeManagement.TimeManagementBlueprintLibrary.Subtract_FrameNumberFrameNumber
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	struct FFrameNumber Subtract_FrameNumberFrameNumber(struct FFrameNumber A, struct FFrameNumber B); // Offset: 0x1046b67d8 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function TimeManagement.TimeManagementBlueprintLibrary.SnapFrameTimeToRate
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FFrameTime SnapFrameTimeToRate(struct FFrameTime& SourceTime, struct FFrameRate& SourceRate, struct FFrameRate& SnapToRate); // Offset: 0x1046b6970 // Return & Params: Num(4) Size(0x20)

	// Object Name: Function TimeManagement.TimeManagementBlueprintLibrary.Multiply_SecondsFrameRate
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FFrameTime Multiply_SecondsFrameRate(float TimeInSeconds, struct FFrameRate& FrameRate); // Offset: 0x1046b6ee4 // Return & Params: Num(3) Size(0x14)

	// Object Name: Function TimeManagement.TimeManagementBlueprintLibrary.Multiply_FrameNumberInteger
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	struct FFrameNumber Multiply_FrameNumberInteger(struct FFrameNumber A, int32_t B); // Offset: 0x1046b6580 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function TimeManagement.TimeManagementBlueprintLibrary.IsValid_MultipleOf
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	bool IsValid_MultipleOf(struct FFrameRate& InFrameRate, struct FFrameRate& OtherFramerate); // Offset: 0x1046b6c08 // Return & Params: Num(3) Size(0x11)

	// Object Name: Function TimeManagement.TimeManagementBlueprintLibrary.IsValid_Framerate
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	bool IsValid_Framerate(struct FFrameRate& InFrameRate); // Offset: 0x1046b6d08 // Return & Params: Num(2) Size(0x9)

	// Object Name: Function TimeManagement.TimeManagementBlueprintLibrary.GetTimecodeFrameRate
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FFrameRate GetTimecodeFrameRate(); // Offset: 0x1046b63ac // Return & Params: Num(1) Size(0x8)

	// Object Name: Function TimeManagement.TimeManagementBlueprintLibrary.GetTimecode
	// Flags: [Final|Native|Static|Public|BlueprintCallable|BlueprintPure]
	struct FTimecode GetTimecode(); // Offset: 0x1046b63e0 // Return & Params: Num(1) Size(0x14)

	// Object Name: Function TimeManagement.TimeManagementBlueprintLibrary.Divide_FrameNumberInteger
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	struct FFrameNumber Divide_FrameNumberInteger(struct FFrameNumber A, int32_t B); // Offset: 0x1046b64b8 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function TimeManagement.TimeManagementBlueprintLibrary.Conv_TimecodeToString
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	struct FString Conv_TimecodeToString(struct FTimecode& InTimecode, bool bForceSignDisplay); // Offset: 0x1046b6d9c // Return & Params: Num(3) Size(0x28)

	// Object Name: Function TimeManagement.TimeManagementBlueprintLibrary.Conv_QualifiedFrameTimeToSeconds
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	float Conv_QualifiedFrameTimeToSeconds(struct FQualifiedFrameTime& InFrameTime); // Offset: 0x1046b6fcc // Return & Params: Num(2) Size(0x14)

	// Object Name: Function TimeManagement.TimeManagementBlueprintLibrary.Conv_FrameRateToSeconds
	// Flags: [Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure]
	float Conv_FrameRateToSeconds(struct FFrameRate& InFrameRate); // Offset: 0x1046b7064 // Return & Params: Num(2) Size(0xc)

	// Object Name: Function TimeManagement.TimeManagementBlueprintLibrary.Conv_FrameNumberToInteger
	// Flags: [Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure]
	int32_t Conv_FrameNumberToInteger(struct FFrameNumber& InFrameNumber); // Offset: 0x1046b642c // Return & Params: Num(2) Size(0x8)

	// Object Name: Function TimeManagement.TimeManagementBlueprintLibrary.Add_FrameNumberInteger
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	struct FFrameNumber Add_FrameNumberInteger(struct FFrameNumber A, int32_t B); // Offset: 0x1046b6710 // Return & Params: Num(3) Size(0xc)

	// Object Name: Function TimeManagement.TimeManagementBlueprintLibrary.Add_FrameNumberFrameNumber
	// Flags: [Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure]
	struct FFrameNumber Add_FrameNumberFrameNumber(struct FFrameNumber A, struct FFrameNumber B); // Offset: 0x1046b68a4 // Return & Params: Num(3) Size(0xc)
};

// Object Name: Class TimeManagement.TimeSynchronizationSource
// Size: 0x30 // Inherited bytes: 0x28
struct UTimeSynchronizationSource : UObject {
	// Fields
	bool bUseForSynchronization; // Offset: 0x28 // Size: 0x01
	char pad_0x29[0x3]; // Offset: 0x29 // Size: 0x03
	int32_t FrameOffset; // Offset: 0x2c // Size: 0x04
};

