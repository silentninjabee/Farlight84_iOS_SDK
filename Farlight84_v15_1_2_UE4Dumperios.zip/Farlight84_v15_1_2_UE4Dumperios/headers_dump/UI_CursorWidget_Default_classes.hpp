#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_CursorWidget_Default.UI_CursorWidget_Default_C
// Size: 0x268 // Inherited bytes: 0x260
struct UUI_CursorWidget_Default_C : UUserWidget {
	// Fields
	struct UCanvasPanel* CursorCanvas; // Offset: 0x260 // Size: 0x08

	// Functions

	// Object Name: Function UI_CursorWidget_Default.UI_CursorWidget_Default_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	struct FString GetModuleName(); // Offset: 0x103938968 // Return & Params: Num(1) Size(0x10)
};

