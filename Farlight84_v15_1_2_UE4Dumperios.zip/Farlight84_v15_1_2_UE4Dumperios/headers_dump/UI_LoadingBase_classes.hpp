#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_LoadingBase.UI_LoadingBase_C
// Size: 0x4b0 // Inherited bytes: 0x4a8
struct UUI_LoadingBase_C : ULoadingUIBase {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x4a8 // Size: 0x08

	// Functions

	// Object Name: Function UI_LoadingBase.UI_LoadingBase_C.StartLoading
	// Flags: [BlueprintCallable|BlueprintEvent]
	void StartLoading(); // Offset: 0x103938968 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_LoadingBase.UI_LoadingBase_C.FinishLoading
	// Flags: [BlueprintCallable|BlueprintEvent]
	void FinishLoading(); // Offset: 0x103938968 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_LoadingBase.UI_LoadingBase_C.ExecuteUbergraph_UI_LoadingBase
	// Flags: [Final|UbergraphFunction]
	void ExecuteUbergraph_UI_LoadingBase(int32_t EntryPoint); // Offset: 0x103938968 // Return & Params: Num(1) Size(0x4)
};

