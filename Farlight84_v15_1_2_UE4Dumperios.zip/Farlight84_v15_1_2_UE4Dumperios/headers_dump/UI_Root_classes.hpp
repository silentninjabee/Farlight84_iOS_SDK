#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_Root.UI_Root_C
// Size: 0x494 // Inherited bytes: 0x400
struct UUI_Root_C : USolarUIRoot {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x400 // Size: 0x08
	struct UCanvasPanel* BattleNoticeRoot; // Offset: 0x408 // Size: 0x08
	struct UCanvasPanel* BattleRoot; // Offset: 0x410 // Size: 0x08
	struct UCanvasPanel* BattleRootGuide; // Offset: 0x418 // Size: 0x08
	struct UCanvasPanel* BattleRootOverlay; // Offset: 0x420 // Size: 0x08
	struct UCanvasPanel* CommonRoot; // Offset: 0x428 // Size: 0x08
	struct UCanvasPanel* ExternalToolsRoot; // Offset: 0x430 // Size: 0x08
	struct UCanvasPanel* Guide; // Offset: 0x438 // Size: 0x08
	struct UCanvasPanel* Loading; // Offset: 0x440 // Size: 0x08
	struct UCanvasPanel* Map; // Offset: 0x448 // Size: 0x08
	struct UCanvasPanel* MiddleRoot; // Offset: 0x450 // Size: 0x08
	struct UCanvasPanel* NoticeRoot; // Offset: 0x458 // Size: 0x08
	struct UCanvasPanel* PopRoot; // Offset: 0x460 // Size: 0x08
	struct UCanvasPanel* Reconnecting; // Offset: 0x468 // Size: 0x08
	struct UCanvasPanel* TipsRoot; // Offset: 0x470 // Size: 0x08
	struct UCanvasPanel* UnderBattleRoot; // Offset: 0x478 // Size: 0x08
	float AdapterOffsetLeft; // Offset: 0x480 // Size: 0x04
	float AdapterOffsetRight; // Offset: 0x484 // Size: 0x04
	bool EnableAutoAdaptation; // Offset: 0x488 // Size: 0x01
	char pad_0x489[0x3]; // Offset: 0x489 // Size: 0x03
	float AdapterOffsetLeftDesktop; // Offset: 0x48c // Size: 0x04
	float AdapterOffsetRightDesktop; // Offset: 0x490 // Size: 0x04

	// Functions

	// Object Name: Function UI_Root.UI_Root_C.OnInitialized
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void OnInitialized(); // Offset: 0x10149b2f0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Root.UI_Root_C.Construct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Construct(); // Offset: 0x10149b2f0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Root.UI_Root_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	struct FString GetModuleName(); // Offset: 0x103938968 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UI_Root.UI_Root_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void PreConstruct(bool IsDesignTime); // Offset: 0x103938968 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Root.UI_Root_C.CustomEvent_1
	// Flags: [HasOutParms|BlueprintCallable|BlueprintEvent]
	void CustomEvent_1(struct UObject* Publisher, struct UObject* Payload, struct TArray<struct FString>& MetaData); // Offset: 0x103938968 // Return & Params: Num(3) Size(0x20)

	// Object Name: Function UI_Root.UI_Root_C.ExecuteUbergraph_UI_Root
	// Flags: [Final|UbergraphFunction|HasDefaults]
	void ExecuteUbergraph_UI_Root(int32_t EntryPoint); // Offset: 0x103938968 // Return & Params: Num(1) Size(0x4)
};

