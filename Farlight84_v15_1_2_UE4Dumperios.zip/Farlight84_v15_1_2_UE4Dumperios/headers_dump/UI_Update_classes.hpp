#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: WidgetBlueprintGeneratedClass UI_Update.UI_Update_C
// Size: 0x558 // Inherited bytes: 0x400
struct UUI_Update_C : USolarUserWidget {
	// Fields
	struct FPointerToUberGraphFrame UberGraphFrame; // Offset: 0x400 // Size: 0x08
	struct UWidgetAnimation* Anim_Enter; // Offset: 0x408 // Size: 0x08
	struct UButton* Btn_AgeLimit; // Offset: 0x410 // Size: 0x08
	struct UButton* Btn_Fix; // Offset: 0x418 // Size: 0x08
	struct USolarButton* btn_link; // Offset: 0x420 // Size: 0x08
	struct USolarButton* btn_new; // Offset: 0x428 // Size: 0x08
	struct UCanvasPanel* CanvasPanel_2; // Offset: 0x430 // Size: 0x08
	struct UHorizontalBox* HorizontalBox_1; // Offset: 0x438 // Size: 0x08
	struct UHorizontalBox* HorizontalBox_2; // Offset: 0x440 // Size: 0x08
	struct UImage* icon_link; // Offset: 0x448 // Size: 0x08
	struct UImage* Image_173; // Offset: 0x450 // Size: 0x08
	struct UImage* Img_Bg_Update; // Offset: 0x458 // Size: 0x08
	struct UImage* img_light_link; // Offset: 0x460 // Size: 0x08
	struct UImage* Img_Logo; // Offset: 0x468 // Size: 0x08
	struct UImage* img_Mask; // Offset: 0x470 // Size: 0x08
	struct UCanvasPanel* Panel_Load; // Offset: 0x478 // Size: 0x08
	struct USizeBox* Panel_ServerList; // Offset: 0x480 // Size: 0x08
	struct UProgressBar* ProgressBar_Download; // Offset: 0x488 // Size: 0x08
	struct UButton* StartGame; // Offset: 0x490 // Size: 0x08
	struct USolarTextBlock* StartGameText; // Offset: 0x498 // Size: 0x08
	struct USolarTextBlock* text_link; // Offset: 0x4a0 // Size: 0x08
	struct USolarTextBlock* text_new; // Offset: 0x4a8 // Size: 0x08
	struct USolarTextBlock* text_or; // Offset: 0x4b0 // Size: 0x08
	struct UTileView* TileView_ServerList; // Offset: 0x4b8 // Size: 0x08
	struct USolarTextBlock* Txt_GameInfo_CN; // Offset: 0x4c0 // Size: 0x08
	struct UTextBlock* Txt_LatestBuildNumber; // Offset: 0x4c8 // Size: 0x08
	struct USolarTextBlock* Txt_Loading_2; // Offset: 0x4d0 // Size: 0x08
	struct UTextBlock* Txt_SourceBuildNumber; // Offset: 0x4d8 // Size: 0x08
	struct USolarTextBlock* Txt_Speed; // Offset: 0x4e0 // Size: 0x08
	struct USolarTextBlock* Txt_Tips_2; // Offset: 0x4e8 // Size: 0x08
	struct UUI_UpdateLoadingBase_C* UpdateLoadingBase; // Offset: 0x4f0 // Size: 0x08
	struct UWidgetSwitcher* wgs_start; // Offset: 0x4f8 // Size: 0x08
	struct UMediaPlayer* MediaPlayer; // Offset: 0x500 // Size: 0x08
	struct FSlateColor Color_hoverd; // Offset: 0x508 // Size: 0x28
	struct FSlateColor Color_default; // Offset: 0x530 // Size: 0x28

	// Functions

	// Object Name: DelegateFunction UI_Update.UI_Update_C.OnClicked_3A254D6B574EA4FDE64A76B2096661A4
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnClicked_3A254D6B574EA4FDE64A76B2096661A4(); // Offset: 0x101486160 // Return & Params: Num(0) Size(0x0)

	// Object Name: DelegateFunction UI_Update.UI_Update_C.OnReleased_A82A0A0926475D9D3F88A194A568BD4F
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnReleased_A82A0A0926475D9D3F88A194A568BD4F(); // Offset: 0x101486160 // Return & Params: Num(0) Size(0x0)

	// Object Name: DelegateFunction UI_Update.UI_Update_C.OnAssetManagerPreloadCompleted_785A60696F480CEB897375B3E6420EB3
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnAssetManagerPreloadCompleted_785A60696F480CEB897375B3E6420EB3(); // Offset: 0x101486160 // Return & Params: Num(0) Size(0x0)

	// Object Name: DelegateFunction UI_Update.UI_Update_C.OnHandleLuaException_16A096A78F48D0223D9CDA86FA05821D
	// Flags: [MulticastDelegate|Public|Delegate]
	void OnHandleLuaException_16A096A78F48D0223D9CDA86FA05821D(struct FString ErrorMsg, struct FString StaceTrace); // Offset: 0x101486160 // Return & Params: Num(2) Size(0x20)

	// Object Name: Function UI_Update.UI_Update_C.ReceiveTick
	// Flags: [Event|Public|HasOutParms|BlueprintEvent]
	void ReceiveTick(struct FGeometry& MyGeometry, float InDeltaTime); // Offset: 0x10149b2f0 // Return & Params: Num(2) Size(0x3c)

	// Object Name: Function UI_Update.UI_Update_C.OnSolarUIOpened
	// Flags: [Native|Event|Protected|BlueprintEvent]
	void OnSolarUIOpened(); // Offset: 0x10149b2f0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Update.UI_Update_C.ConnectGateExecCopy
	// Flags: [BlueprintCallable|BlueprintEvent]
	void ConnectGateExecCopy(); // Offset: 0x103938968 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Update.UI_Update_C.OnSolarUIClosed
	// Flags: [Native|Event|Protected|BlueprintEvent]
	void OnSolarUIClosed(); // Offset: 0x10149b2f0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Update.UI_Update_C.Destruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Destruct(); // Offset: 0x10149b2f0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Update.UI_Update_C.GetModuleName
	// Flags: [Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const]
	struct FString GetModuleName(); // Offset: 0x103938968 // Return & Params: Num(1) Size(0x10)

	// Object Name: Function UI_Update.UI_Update_C.OnVideoReady
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void OnVideoReady(); // Offset: 0x103938968 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Update.UI_Update_C.InitMedia
	// Flags: [Public|HasOutParms|BlueprintCallable|BlueprintEvent]
	void InitMedia(bool& Result); // Offset: 0x103938968 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Update.UI_Update_C.FinishLoadLobby
	// Flags: [Public|BlueprintCallable|BlueprintEvent]
	void FinishLoadLobby(int32_t Type); // Offset: 0x103938968 // Return & Params: Num(1) Size(0x4)

	// Object Name: Function UI_Update.UI_Update_C.PreConstruct
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void PreConstruct(bool IsDesignTime); // Offset: 0x103938968 // Return & Params: Num(1) Size(0x1)

	// Object Name: Function UI_Update.UI_Update_C.Tick
	// Flags: [BlueprintCosmetic|Event|Public|BlueprintEvent]
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Offset: 0x103938968 // Return & Params: Num(2) Size(0x3c)

	// Object Name: Function UI_Update.UI_Update_C.ReceiveShow
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveShow(); // Offset: 0x103938968 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Update.UI_Update_C.ConnectGateExec
	// Flags: [BlueprintCallable|BlueprintEvent]
	void ConnectGateExec(); // Offset: 0x10149b2f0 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Update.UI_Update_C.ReceiveHide
	// Flags: [Event|Protected|BlueprintEvent]
	void ReceiveHide(); // Offset: 0x103938968 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Update.UI_Update_C.BndEvt__btn_link_K2Node_ComponentBoundEvent_0_OnButtonHoverEvent__DelegateSignature
	// Flags: [BlueprintEvent]
	void BndEvt__btn_link_K2Node_ComponentBoundEvent_0_OnButtonHoverEvent__DelegateSignature(); // Offset: 0x103938968 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Update.UI_Update_C.BndEvt__btn_link_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature
	// Flags: [BlueprintEvent]
	void BndEvt__btn_link_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature(); // Offset: 0x103938968 // Return & Params: Num(0) Size(0x0)

	// Object Name: Function UI_Update.UI_Update_C.ExecuteUbergraph_UI_Update
	// Flags: [Final|UbergraphFunction|HasDefaults]
	void ExecuteUbergraph_UI_Update(int32_t EntryPoint); // Offset: 0x103938968 // Return & Params: Num(1) Size(0x4)
};

