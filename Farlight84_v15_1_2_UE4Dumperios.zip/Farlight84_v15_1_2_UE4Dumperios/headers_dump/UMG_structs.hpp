#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct UMG.EventReply
// Size: 0xb8 // Inherited bytes: 0x00
struct FEventReply {
	// Fields
	char pad_0x0[0xb8]; // Offset: 0x00 // Size: 0xb8
};

// Object Name: ScriptStruct UMG.WidgetTransform
// Size: 0x1c // Inherited bytes: 0x00
struct FWidgetTransform {
	// Fields
	struct FVector2D Translation; // Offset: 0x00 // Size: 0x08
	struct FVector2D Scale; // Offset: 0x08 // Size: 0x08
	struct FVector2D Shear; // Offset: 0x10 // Size: 0x08
	float Angle; // Offset: 0x18 // Size: 0x04
};

// Object Name: ScriptStruct UMG.PaintContext
// Size: 0x30 // Inherited bytes: 0x00
struct FPaintContext {
	// Fields
	char pad_0x0[0x30]; // Offset: 0x00 // Size: 0x30
};

// Object Name: ScriptStruct UMG.ShapedTextOptions
// Size: 0x03 // Inherited bytes: 0x00
struct FShapedTextOptions {
	// Fields
	char bOverride_TextShapingMethod : 1; // Offset: 0x00 // Size: 0x01
	char bOverride_TextFlowDirection : 1; // Offset: 0x00 // Size: 0x01
	char pad_0x0_2 : 6; // Offset: 0x00 // Size: 0x01
	enum class ETextShapingMethod TextShapingMethod; // Offset: 0x01 // Size: 0x01
	enum class ETextFlowDirection TextFlowDirection; // Offset: 0x02 // Size: 0x01
};

// Object Name: ScriptStruct UMG.AnimationEventBinding
// Size: 0x28 // Inherited bytes: 0x00
struct FAnimationEventBinding {
	// Fields
	struct UWidgetAnimation* Animation; // Offset: 0x00 // Size: 0x08
	struct FDelegate Delegate; // Offset: 0x08 // Size: 0x10
	enum class EWidgetAnimationEvent AnimationEvent; // Offset: 0x18 // Size: 0x01
	char pad_0x19[0x3]; // Offset: 0x19 // Size: 0x03
	struct FName UserTag; // Offset: 0x1c // Size: 0x08
	char pad_0x24[0x4]; // Offset: 0x24 // Size: 0x04
};

// Object Name: ScriptStruct UMG.NamedSlotBinding
// Size: 0x10 // Inherited bytes: 0x00
struct FNamedSlotBinding {
	// Fields
	struct FName Name; // Offset: 0x00 // Size: 0x08
	struct UWidget* Content; // Offset: 0x08 // Size: 0x08
};

// Object Name: ScriptStruct UMG.AnchorData
// Size: 0x2c // Inherited bytes: 0x00
struct FAnchorData {
	// Fields
	struct FMargin Offsets; // Offset: 0x00 // Size: 0x10
	struct FAnchors Anchors; // Offset: 0x10 // Size: 0x10
	bool bLockRatio; // Offset: 0x20 // Size: 0x01
	char pad_0x21[0x3]; // Offset: 0x21 // Size: 0x03
	struct FVector2D Alignment; // Offset: 0x24 // Size: 0x08
};

// Object Name: ScriptStruct UMG.DynamicPropertyPath
// Size: 0x28 // Inherited bytes: 0x28
struct FDynamicPropertyPath : FCachedPropertyPath {
};

// Object Name: ScriptStruct UMG.MovieScene2DTransformMask
// Size: 0x04 // Inherited bytes: 0x00
struct FMovieScene2DTransformMask {
	// Fields
	uint32_t Mask; // Offset: 0x00 // Size: 0x04
};

// Object Name: ScriptStruct UMG.MovieScene2DTransformSectionTemplate
// Size: 0x4a8 // Inherited bytes: 0x40
struct FMovieScene2DTransformSectionTemplate : FMovieScenePropertySectionTemplate {
	// Fields
	struct FMovieSceneFloatChannel Translation[0x2]; // Offset: 0x40 // Size: 0x140
	struct FMovieSceneFloatChannel Rotation; // Offset: 0x180 // Size: 0xa0
	struct FMovieSceneFloatChannel Scale[0x2]; // Offset: 0x220 // Size: 0x140
	struct FMovieSceneFloatChannel Shear[0x2]; // Offset: 0x360 // Size: 0x140
	enum class EMovieSceneBlendType BlendType; // Offset: 0x4a0 // Size: 0x01
	char pad_0x4A1[0x3]; // Offset: 0x4a1 // Size: 0x03
	struct FMovieScene2DTransformMask Mask; // Offset: 0x4a4 // Size: 0x04
};

// Object Name: ScriptStruct UMG.MovieSceneMarginSectionTemplate
// Size: 0x2c8 // Inherited bytes: 0x40
struct FMovieSceneMarginSectionTemplate : FMovieScenePropertySectionTemplate {
	// Fields
	struct FMovieSceneFloatChannel TopCurve; // Offset: 0x40 // Size: 0xa0
	struct FMovieSceneFloatChannel LeftCurve; // Offset: 0xe0 // Size: 0xa0
	struct FMovieSceneFloatChannel RightCurve; // Offset: 0x180 // Size: 0xa0
	struct FMovieSceneFloatChannel BottomCurve; // Offset: 0x220 // Size: 0xa0
	enum class EMovieSceneBlendType BlendType; // Offset: 0x2c0 // Size: 0x01
	char pad_0x2C1[0x7]; // Offset: 0x2c1 // Size: 0x07
};

// Object Name: ScriptStruct UMG.MovieSceneWidgetMaterialSectionTemplate
// Size: 0x88 // Inherited bytes: 0x78
struct FMovieSceneWidgetMaterialSectionTemplate : FMovieSceneParameterSectionTemplate {
	// Fields
	struct TArray<struct FName> BrushPropertyNamePath; // Offset: 0x78 // Size: 0x10
};

// Object Name: ScriptStruct UMG.RichTextStyleRow
// Size: 0x470 // Inherited bytes: 0x08
struct FRichTextStyleRow : FTableRowBase {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x08 // Size: 0x08
	struct FTextBlockStyle TextStyle; // Offset: 0x10 // Size: 0x460
};

// Object Name: ScriptStruct UMG.RichInlineTextRow
// Size: 0x490 // Inherited bytes: 0x08
struct FRichInlineTextRow : FTableRowBase {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x08 // Size: 0x08
	struct FTextBlockStyle TextBlockStyle; // Offset: 0x10 // Size: 0x460
	struct FMargin Margin; // Offset: 0x470 // Size: 0x10
	float LineHeightPercentage; // Offset: 0x480 // Size: 0x04
	char pad_0x484[0xc]; // Offset: 0x484 // Size: 0x0c
};

// Object Name: ScriptStruct UMG.RichImageAttributes
// Size: 0x20 // Inherited bytes: 0x00
struct FRichImageAttributes {
	// Fields
	char pad_0x0[0x20]; // Offset: 0x00 // Size: 0x20
};

// Object Name: ScriptStruct UMG.RichImageRow
// Size: 0x100 // Inherited bytes: 0x08
struct FRichImageRow : FTableRowBase {
	// Fields
	char pad_0x8[0x8]; // Offset: 0x08 // Size: 0x08
	struct FSlateBrush Brush; // Offset: 0x10 // Size: 0xe0
	enum class EHorizontalAlignment HAlign; // Offset: 0xf0 // Size: 0x01
	char pad_0xF1[0x3]; // Offset: 0xf1 // Size: 0x03
	struct FVector2D Offset; // Offset: 0xf4 // Size: 0x08
	char pad_0xFC[0x4]; // Offset: 0xfc // Size: 0x04
};

// Object Name: ScriptStruct UMG.SlateMeshVertex
// Size: 0x3c // Inherited bytes: 0x00
struct FSlateMeshVertex {
	// Fields
	struct FVector2D Position; // Offset: 0x00 // Size: 0x08
	struct FColor Color; // Offset: 0x08 // Size: 0x04
	struct FVector2D UV0; // Offset: 0x0c // Size: 0x08
	struct FVector2D UV1; // Offset: 0x14 // Size: 0x08
	struct FVector2D UV2; // Offset: 0x1c // Size: 0x08
	struct FVector2D UV3; // Offset: 0x24 // Size: 0x08
	struct FVector2D UV4; // Offset: 0x2c // Size: 0x08
	struct FVector2D UV5; // Offset: 0x34 // Size: 0x08
};

// Object Name: ScriptStruct UMG.SlateChildSize
// Size: 0x08 // Inherited bytes: 0x00
struct FSlateChildSize {
	// Fields
	float Value; // Offset: 0x00 // Size: 0x04
	enum class ESlateSizeRule SizeRule; // Offset: 0x04 // Size: 0x01
	char pad_0x5[0x3]; // Offset: 0x05 // Size: 0x03
};

// Object Name: ScriptStruct UMG.UserWidgetPool
// Size: 0x80 // Inherited bytes: 0x00
struct FUserWidgetPool {
	// Fields
	struct TArray<struct UUserWidget*> ActiveWidgets; // Offset: 0x00 // Size: 0x10
	struct TArray<struct UUserWidget*> InactiveWidgets; // Offset: 0x10 // Size: 0x10
	char pad_0x20[0x60]; // Offset: 0x20 // Size: 0x60
};

// Object Name: ScriptStruct UMG.WidgetAnimationBinding
// Size: 0x24 // Inherited bytes: 0x00
struct FWidgetAnimationBinding {
	// Fields
	struct FName WidgetName; // Offset: 0x00 // Size: 0x08
	struct FName SlotWidgetName; // Offset: 0x08 // Size: 0x08
	struct FGuid AnimationGuid; // Offset: 0x10 // Size: 0x10
	bool bIsRootWidget; // Offset: 0x20 // Size: 0x01
	char pad_0x21[0x3]; // Offset: 0x21 // Size: 0x03
};

// Object Name: ScriptStruct UMG.BlueprintWidgetAnimationDelegateBinding
// Size: 0x1c // Inherited bytes: 0x00
struct FBlueprintWidgetAnimationDelegateBinding {
	// Fields
	enum class EWidgetAnimationEvent Action; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	struct FName AnimationToBind; // Offset: 0x04 // Size: 0x08
	struct FName FunctionNameToBind; // Offset: 0x0c // Size: 0x08
	struct FName UserTag; // Offset: 0x14 // Size: 0x08
};

// Object Name: ScriptStruct UMG.DelegateRuntimeBinding
// Size: 0x50 // Inherited bytes: 0x00
struct FDelegateRuntimeBinding {
	// Fields
	struct FString ObjectName; // Offset: 0x00 // Size: 0x10
	struct FName PropertyName; // Offset: 0x10 // Size: 0x08
	struct FName FunctionName; // Offset: 0x18 // Size: 0x08
	struct FDynamicPropertyPath SourcePath; // Offset: 0x20 // Size: 0x28
	enum class EBindingKind Kind; // Offset: 0x48 // Size: 0x01
	char pad_0x49[0x7]; // Offset: 0x49 // Size: 0x07
};

// Object Name: ScriptStruct UMG.WidgetComponentInstanceData
// Size: 0xb8 // Inherited bytes: 0xa8
struct FWidgetComponentInstanceData : FSceneComponentInstanceData {
	// Fields
	char pad_0xA8[0x10]; // Offset: 0xa8 // Size: 0x10
};

// Object Name: ScriptStruct UMG.WidgetNavigationData
// Size: 0x24 // Inherited bytes: 0x00
struct FWidgetNavigationData {
	// Fields
	enum class EUINavigationRule Rule; // Offset: 0x00 // Size: 0x01
	char pad_0x1[0x3]; // Offset: 0x01 // Size: 0x03
	struct FName WidgetToFocus; // Offset: 0x04 // Size: 0x08
	struct TWeakObjectPtr<struct UWidget> Widget; // Offset: 0x0c // Size: 0x08
	struct FDelegate CustomDelegate; // Offset: 0x14 // Size: 0x10
};

