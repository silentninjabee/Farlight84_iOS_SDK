#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: Enum UdpMessaging.EUdpMessageFormat
enum class EUdpMessageFormat : uint8 {
	None = 0,
	Json = 1,
	TaggedProperty = 2,
	CborPlatformEndianness = 3,
	CborStandardEndianness = 4,
	EUdpMessageFormat_MAX = 5
};

