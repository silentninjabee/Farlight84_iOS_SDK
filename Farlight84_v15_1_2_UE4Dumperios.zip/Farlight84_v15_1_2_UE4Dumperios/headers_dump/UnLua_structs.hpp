#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: ScriptStruct UnLua.PropertyCollector
// Size: 0x01 // Inherited bytes: 0x00
struct FPropertyCollector {
	// Fields
	struct FInputKeyMappingEntry None; // Offset: 0x00 // Size: 0x40
};

// Object Name: ScriptStruct UnLua.InSightEvent
// Size: 0x01 // Inherited bytes: 0x00
struct FInSightEvent {
	// Fields
	char pad_0x0[0x1]; // Offset: 0x00 // Size: 0x01
};

